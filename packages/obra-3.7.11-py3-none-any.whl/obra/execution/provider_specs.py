"""Provider-specific spec builders for the typed LLM pipeline.

Extracts all provider-specific command-building logic from obra/config/llm.py
into focused builder functions. Each builder translates a CommandSpec into a
ProviderSpec with provider-specific argv, environment, and execution details.

All platform-specific decisions (path format, encoding, preexec_fn) are received
via EnvironmentProfile — no direct OS detection calls in this module.

Related:
    - docs/design/briefs/ECL_PHASE2_TYPED_PIPELINE_BRIEF.md
    - obra/execution/pipeline_types.py (dataclass definitions)
    - obra/execution/os_compat.py (EnvironmentProfile)
"""

from __future__ import annotations

import uuid

from obra.config.llm import get_llm_cli
from obra.execution.os_compat import EnvironmentProfile
from obra.execution.pipeline_types import CommandSpec, ProviderSpec
from obra.model_registry import supports_anthropic_cli_effort


def _normalize_codex_feature_list(codex_config: dict, key: str) -> list[str]:
    """Normalize Codex feature list config to a de-duplicated list."""
    raw = codex_config.get(key)
    if raw is None:
        return []
    if not isinstance(raw, list):
        return []

    normalized: list[str] = []
    seen: set[str] = set()
    for item in raw:
        if not isinstance(item, str):
            continue
        feature = item.strip()
        if not feature or feature in seen:
            continue
        seen.add(feature)
        normalized.append(feature)
    return normalized


def _workspace_context_managed(cmd_spec: CommandSpec) -> bool:
    workspace_context = cmd_spec.workspace_context or {}
    return bool(
        workspace_context.get("enabled", False)
        and workspace_context.get("mode") == "managed"
    )


def build_anthropic_spec(
    cmd_spec: CommandSpec,
    profile: EnvironmentProfile,
) -> ProviderSpec:
    """Build ProviderSpec for Anthropic Claude Code CLI.

    Extracts logic from obra/config/llm.py lines 1638-1673.

    Args:
        cmd_spec: High-level command specification with user intent
        profile: Resolved OS environment profile for platform-specific decisions

    Returns:
        ProviderSpec with Anthropic-specific argv and execution configuration

    Notes:
        - Text mode uses --print for JSON output (no file writing)
        - Execute mode allows file operations (no --print)
        - Thinking enablement is binary: on/off (alwaysThinkingEnabled)
        - Reasoning depth uses --effort for Claude models that support it
        - Session isolation via --no-session-persistence and fresh UUID
        - Prompt delivery is always 'file' for Anthropic
    """
    args = []

    # Mode-aware argument building
    if cmd_spec.mode == "text":
        args.append("--print")  # Text generation mode (prevents code writing)
        # Only add --output-format json when JSON is expected
        if cmd_spec.response_format == "json":
            args.extend(["--output-format", "json"])

    # Execute mode: No --print flag - allows Claude Code to write files
    args.append("--dangerously-skip-permissions")

    # Model selection
    if cmd_spec.model and cmd_spec.model != "default":
        args.extend(["--model", cmd_spec.model])

    # Thinking configuration (binary: on/off)
    thinking_enabled = cmd_spec.reasoning_level != "off"
    args.extend(
        [
            "--settings",
            f'{{"alwaysThinkingEnabled": {str(thinking_enabled).lower()}}}',
        ]
    )

    effort_level = None
    if cmd_spec.provider_reasoning_level and supports_anthropic_cli_effort(cmd_spec.model):
        effort_level = cmd_spec.provider_reasoning_level
        args.extend(["--effort", effort_level])

    # Context isolation flags to prevent cross-session pollution
    session_id = str(uuid.uuid4())
    args.extend(["--no-session-persistence"])  # Don't persist session state
    args.extend(["--session-id", session_id])  # Fresh session each invocation
    args.extend(["--setting-sources", ""])  # Block user-level settings pollution

    env_overrides: dict[str, str] = {}
    if _workspace_context_managed(cmd_spec):
        env_overrides["CLAUDE_CODE_DISABLE_CLAUDE_MDS"] = "1"
        env_overrides["CLAUDE_CODE_DISABLE_AUTO_MEMORY"] = "1"

    return ProviderSpec(
        argv=args,
        cli_executable=get_llm_cli("anthropic"),
        env_overrides=env_overrides,
        prompt_delivery="file",  # Anthropic always uses prompt files
        stdin_content=None,  # Not used for Anthropic
        use_absolute_paths=profile.use_absolute_paths,  # OS default (False on Tier 1)
        provider_meta={
            "thinking_enabled": thinking_enabled,
            "effort_level": effort_level,
            "session_id": session_id,
            # Anthropic's CLI rejects reuse of a session-id while the prior
            # subprocess still holds it, so retry attempts must rotate the
            # value baked into argv. The retry loop reads this marker to
            # find the flag in cmd and replace its value with a fresh UUID
            # before each attempt. Other providers leave this key absent.
            "session_isolation_arg": "--session-id",
        },
        spec_id=cmd_spec.spec_id,  # Preserve correlation ID
    )


def rotate_session_isolation_argv(cmd: list[str], provider_meta: dict) -> str | None:
    """Rotate the per-invocation session-isolation argv value, in place.

    Reads ``provider_meta["session_isolation_arg"]`` (e.g. ``"--session-id"``)
    to locate the flag in *cmd*, then replaces the value with a fresh UUID.

    Called by the retry loop before each subprocess attempt so retries don't
    reuse a session id that the prior attempt already registered with the
    provider CLI's local session-tracking state.

    Returns the new id, or ``None`` if this provider does not declare a
    session-isolation arg (the common case for stateless provider CLIs).
    """
    flag = provider_meta.get("session_isolation_arg")
    if not flag:
        return None
    try:
        idx = cmd.index(flag)
    except ValueError:
        return None
    if idx + 1 >= len(cmd):
        return None
    new_id = str(uuid.uuid4())
    cmd[idx + 1] = new_id
    return new_id


def build_google_spec(
    cmd_spec: CommandSpec,
    profile: EnvironmentProfile,
) -> ProviderSpec:
    """Build ProviderSpec for Google Gemini CLI.

    Extracts logic from obra/config/llm.py lines 1675-1699.

    Args:
        cmd_spec: High-level command specification with user intent
        profile: Resolved OS environment profile for platform-specific decisions

    Returns:
        ProviderSpec with Google-specific argv and execution configuration

    Notes:
        - Text mode uses --sandbox=none to disable tools (prevents hijacking)
        - Execute mode uses --sandbox=permissive with --yolo for auto-approval
        - No reasoning level support (Google doesn't support it)
        - Model 'default' and 'auto' both mean let Gemini choose (no --model flag)
        - Prompt delivery uses stdin: Gemini CLI reads from stdin when -p is present
          (unlike Claude Code/Codex, Gemini has no native file-reading prompt pathway)
    """
    args = []

    # Mode-aware sandbox configuration
    if cmd_spec.mode == "text":
        # Text generation mode - disable tools
        args.append("--sandbox=none")
        # Only add --output-format json when caller expects JSON response
        if cmd_spec.response_format == "json":
            args.extend(["--output-format", "json"])
        sandbox_mode = "none"
    else:
        # Execute mode - MUST have --sandbox=permissive for file operations
        # and --yolo for auto-approval (Gemini waits for approval in headless mode)
        args.append("--sandbox=permissive")
        args.append("--yolo")
        sandbox_mode = "permissive"

    # Model selection: "default" and "auto" both mean let Gemini choose
    if cmd_spec.model and cmd_spec.model not in ("default", "auto"):
        args.extend(["--model", cmd_spec.model])

    # Gemini CLI requires -p for headless mode. Without it, Gemini enters
    # interactive TUI and hangs. With stdin delivery, -p "" triggers headless
    # mode while the actual prompt content is piped via stdin.
    args.extend(["-p", ""])

    provider_meta = {"sandbox_mode": sandbox_mode}
    if _workspace_context_managed(cmd_spec):
        provider_meta["gemini_settings"] = {"context": {"fileName": ["OBRA_CONTEXT.md"]}}

    return ProviderSpec(
        argv=args,
        cli_executable=get_llm_cli("google"),
        env_overrides={},  # No special env vars for Google
        prompt_delivery="stdin",  # Gemini CLI reads prompt from stdin
        stdin_content=None,  # Populated by build_exec_spec from prompt text
        use_absolute_paths=profile.use_absolute_paths,  # OS default (False on Tier 1)
        provider_meta=provider_meta,
        spec_id=cmd_spec.spec_id,  # Preserve correlation ID
    )


def build_openai_spec(
    cmd_spec: CommandSpec,
    profile: EnvironmentProfile,
) -> ProviderSpec:
    """Build ProviderSpec for OpenAI Codex CLI.

    Merges logic from BOTH build_llm_args() (lines 1701-1734) AND
    _build_codex_cmd() in subprocess_runner.py (lines 649-698).
    The _build_codex_cmd() output is what actually executes for Codex.

    Args:
        cmd_spec: High-level command specification with user intent
        profile: Resolved OS environment profile (ignored for OpenAI)

    Returns:
        ProviderSpec with OpenAI-specific argv and execution configuration

    Notes:
        - Base command starts with 'exec', '-C' + cwd
        - Text mode without bypass: --sandbox read-only
        - Text mode with bypass: --dangerously-bypass-approvals-and-sandbox
        - Execute mode without bypass: --sandbox workspace-write
        - Execute mode with bypass: --dangerously-bypass-approvals-and-sandbox
        - approval_mode from codex_config: --config defaults.approval_mode={mode}
        - skip_git_check from codex_config: --skip-git-repo-check
        - enable_features from codex_config: --enable <feature> (repeatable)
        - disable_features from codex_config: --disable <feature> (repeatable)
        - provider_reasoning_level: --config model_reasoning_effort={level}
        - use_absolute_paths=True (provider requirement, resolves BUG-c2e0a391)
    """
    import os

    # Extract Codex-specific config
    codex_config = cmd_spec.codex_config or {}
    bypass_sandbox = bool(codex_config.get("bypass_sandbox", False))
    approval_mode = codex_config.get("approval_mode")
    skip_git_check = bool(codex_config.get("skip_git_check", False))
    enable_features = _normalize_codex_feature_list(codex_config, "enable_features")
    disable_features = _normalize_codex_feature_list(codex_config, "disable_features")

    overlapping_features = set(enable_features) & set(disable_features)
    if overlapping_features:
        msg = (
            "Invalid Codex feature flags: same feature appears in both enable_features "
            f"and disable_features: {', '.join(sorted(overlapping_features))}"
        )
        raise ValueError(msg)

    # Base command: exec -C <cwd>
    args = [
        "exec",
        "-C",
        str(cmd_spec.cwd),
    ]

    # Mode-aware sandbox configuration
    if cmd_spec.mode == "text":
        if bypass_sandbox:
            args.append("--dangerously-bypass-approvals-and-sandbox")
        else:
            args.extend(["--sandbox", "read-only"])
            # Text mode can have approval_mode even without bypass
            if approval_mode:
                args.extend(["--config", f"defaults.approval_mode={approval_mode}"])
        sandbox_mode = "bypass" if bypass_sandbox else "read-only"
    else:  # execute mode
        if bypass_sandbox:
            args.append("--dangerously-bypass-approvals-and-sandbox")
        else:
            args.extend(["--sandbox", "workspace-write"])
            if approval_mode:
                args.extend(["--config", f"defaults.approval_mode={approval_mode}"])
        sandbox_mode = "bypass" if bypass_sandbox else "workspace-write"

    # Git check bypass
    if skip_git_check:
        args.append("--skip-git-repo-check")

    # Feature toggles
    for feature_name in enable_features:
        args.extend(["--enable", feature_name])
    for feature_name in disable_features:
        args.extend(["--disable", feature_name])

    # Model selection
    if cmd_spec.model and cmd_spec.model not in ("default", "auto"):
        args.extend(["--model", cmd_spec.model])

    # Reasoning effort (provider-specific thinking level)
    if cmd_spec.provider_reasoning_level:
        args.extend(["--config", f"model_reasoning_effort={cmd_spec.provider_reasoning_level}"])

    # Prompt delivery: default to 'file' for safety
    # Inline optimization (for short text mode prompts) can be added later
    # when prompt content is available at execution time
    force_prompt_file = os.environ.get("OBRA_OPENAI_TEXT_FORCE_PROMPT_FILE") == "1"
    prompt_delivery = "file"
    if cmd_spec.mode == "text" and not force_prompt_file:
        # Note: actual inline delivery requires prompt length check (<=4000 chars)
        # This will be validated at execution time in build_exec_spec()
        prompt_delivery = "inline"

    return ProviderSpec(
        argv=args,
        cli_executable=get_llm_cli("openai"),
        env_overrides={},  # No special env vars for OpenAI
        prompt_delivery=prompt_delivery,
        stdin_content=None,  # Not used for OpenAI
        use_absolute_paths=True,  # Provider requirement (resolves BUG-c2e0a391)
        provider_meta={
            "codex_backed": True,
            "local_provider": None,
            "bypass_sandbox": bypass_sandbox,
            "approval_mode": approval_mode,
            "sandbox_mode": sandbox_mode,
            "enable_features": enable_features,
            "disable_features": disable_features,
        },
        spec_id=cmd_spec.spec_id,  # Preserve correlation ID
    )


def build_ollama_spec(
    cmd_spec: CommandSpec,
    profile: EnvironmentProfile,
) -> ProviderSpec:
    """Build ProviderSpec for Ollama via Codex CLI local-provider mode.

    Ollama execution is codex-backed: `codex exec --oss --local-provider ollama ...`.
    This preserves tool-capable CLI behavior while routing inference to local models.
    """
    codex_config = cmd_spec.codex_config or {}
    bypass_sandbox = bool(codex_config.get("bypass_sandbox", False))
    approval_mode = codex_config.get("approval_mode")
    skip_git_check = bool(codex_config.get("skip_git_check", False))
    enable_features = _normalize_codex_feature_list(codex_config, "enable_features")
    disable_features = _normalize_codex_feature_list(codex_config, "disable_features")

    overlapping_features = set(enable_features) & set(disable_features)
    if overlapping_features:
        msg = (
            "Invalid Codex feature flags: same feature appears in both enable_features "
            f"and disable_features: {', '.join(sorted(overlapping_features))}"
        )
        raise ValueError(msg)

    args = [
        "exec",
        "-C",
        str(cmd_spec.cwd),
        "--oss",
        "--local-provider",
        "ollama",
    ]

    if cmd_spec.mode == "text":
        if bypass_sandbox:
            args.append("--dangerously-bypass-approvals-and-sandbox")
        else:
            args.extend(["--sandbox", "read-only"])
            if approval_mode:
                args.extend(["--config", f"defaults.approval_mode={approval_mode}"])
        sandbox_mode = "bypass" if bypass_sandbox else "read-only"
    else:
        if bypass_sandbox:
            args.append("--dangerously-bypass-approvals-and-sandbox")
        else:
            args.extend(["--sandbox", "workspace-write"])
            if approval_mode:
                args.extend(["--config", f"defaults.approval_mode={approval_mode}"])
        sandbox_mode = "bypass" if bypass_sandbox else "workspace-write"

    if skip_git_check:
        args.append("--skip-git-repo-check")

    for feature_name in enable_features:
        args.extend(["--enable", feature_name])
    for feature_name in disable_features:
        args.extend(["--disable", feature_name])

    if cmd_spec.model and cmd_spec.model not in ("default", "auto"):
        args.extend(["--model", cmd_spec.model])

    return ProviderSpec(
        argv=args,
        cli_executable=get_llm_cli("ollama"),
        env_overrides={},
        prompt_delivery="file",
        stdin_content=None,
        use_absolute_paths=True,
        provider_meta={
            "codex_backed": True,
            "local_provider": "ollama",
            "bypass_sandbox": bypass_sandbox,
            "approval_mode": approval_mode,
            "sandbox_mode": sandbox_mode,
            "enable_features": enable_features,
            "disable_features": disable_features,
        },
        spec_id=cmd_spec.spec_id,
    )


def build_default_spec(
    cmd_spec: CommandSpec,
    profile: EnvironmentProfile,
) -> ProviderSpec:
    """Build ProviderSpec for unknown/fallback providers.

    Extracts fallback logic from obra/config/llm.py line 1737.

    Args:
        cmd_spec: High-level command specification with user intent
        profile: Resolved OS environment profile for platform-specific decisions

    Returns:
        ProviderSpec with minimal fallback configuration

    Notes:
        - Produces minimal argv: ['--dangerously-skip-permissions']
        - Covers unknown provider strings only (Ollama has a dedicated builder)
        - Uses OS default path format (not provider-specific)
        - Prompt delivery is always 'file' for fallback providers
    """
    # Minimal fallback argv
    args = ["--dangerously-skip-permissions"]

    return ProviderSpec(
        argv=args,
        cli_executable=get_llm_cli(cmd_spec.provider),
        env_overrides={},  # No special env vars for fallback
        prompt_delivery="file",  # Always use prompt files for fallback
        stdin_content=None,  # Not used for fallback
        use_absolute_paths=profile.use_absolute_paths,  # OS default
        provider_meta={"fallback": True},
        spec_id=cmd_spec.spec_id,  # Preserve correlation ID
    )
