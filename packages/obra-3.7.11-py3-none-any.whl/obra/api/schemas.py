"""Pydantic v2 base schemas for Obra API.

This module provides base Pydantic models with standard configuration
for API request/response validation in the Hybrid Architecture.

Architecture:
    - BaseAPIModel: Base model with common configuration
    - Request/Response models inherit from BaseAPIModel
    - Strict validation with no extra fields allowed
    - Serialization to camelCase for JavaScript interop

Usage:
    >>> from obra.api.schemas import BaseAPIModel
    >>> class MyRequest(BaseAPIModel):
    ...     user_id: str
    ...     action_type: str

Related:
    - obra/api/protocol.py: Current dataclass-based protocol types
    - obra/schemas/plan_schema.py: Plan validation schemas
    - docs/design/prds/UNIFIED_HYBRID_ARCHITECTURE_PRD.md

Future:
    - Migration from dataclass protocol to Pydantic schemas
    - OpenAPI spec generation from schemas
    - Automatic request/response validation
"""

from datetime import datetime
from typing import Any, cast

from pydantic import BaseModel, ConfigDict, Field, field_validator


class BaseAPIModel(BaseModel):
    """Base Pydantic model with standard configuration for Obra API.

    Configuration:
        - extra='forbid': Reject any extra fields not defined in schema
        - validate_assignment=True: Validate field values on assignment
        - str_strip_whitespace=True: Strip whitespace from string fields
        - use_enum_values=True: Use enum values instead of enum objects in serialization
        - populate_by_name=True: Allow field population by both name and alias

    Example:
        >>> class UserRequest(BaseAPIModel):
        ...     user_id: str
        ...     email: str
        ...
        >>> req = UserRequest(user_id="123", email=" user@example.com ")
        >>> req.email
        'user@example.com'
        >>> req.model_dump()
        {'user_id': '123', 'email': 'user@example.com'}
    """

    model_config = ConfigDict(
        # Validation strictness
        extra="forbid",  # No undeclared fields allowed
        validate_assignment=True,  # Re-validate on assignment
        # String handling
        str_strip_whitespace=True,  # Auto-strip whitespace
        # Enum handling
        use_enum_values=True,  # Serialize enums as values
        # Field aliases
        populate_by_name=True,  # Allow both name and alias
        # JSON schema
        json_schema_extra={"description": "Base API model with standard Obra configuration"},
    )

    def model_dump_api(self, **kwargs: Any) -> dict[str, Any]:
        """Dump model for API transmission with standard settings.

        This method provides a consistent serialization format for API
        communication, excluding None values and using aliases.

        Args:
            **kwargs: Additional arguments passed to model_dump()

        Returns:
            Dictionary representation suitable for API transmission

        Example:
            >>> class MyRequest(BaseAPIModel):
            ...     user_id: str
            ...     optional_field: str | None = None
            ...
            >>> req = MyRequest(user_id="123")
            >>> req.model_dump_api()
            {'user_id': '123'}
        """
        return cast(
            dict[str, Any],
            self.model_dump(
                exclude_none=True,  # Omit None values
                by_alias=True,  # Use field aliases
                **kwargs,
            ),
        )


class BaseAPIRequest(BaseAPIModel):
    """Base class for API request models.

    All request models should inherit from this class to ensure
    consistent validation and serialization behavior.

    Example:
        >>> class DeriveRequest(BaseAPIRequest):
        ...     objective: str
        ...     context: dict[str, Any] | None = None
    """


class BaseAPIResponse(BaseAPIModel):
    """Base class for API response models.

    All response models should inherit from this class to ensure
    consistent validation and serialization behavior.

    Example:
        >>> class DeriveResponse(BaseAPIResponse):
        ...     session_id: str
        ...     plan_items: list[dict[str, Any]]
    """


class IssueItem(BaseAPIModel):
    """Structured issue item for review results.

    This schema prevents ISSUE-SAAS-009 type mismatches where the server
    returns issues as strings instead of structured dictionaries.

    Attributes:
        id: Unique identifier for the issue
        description: Human-readable description of the issue
        severity: Optional severity level (e.g., "critical", "high", "medium", "low")
        title: Optional short issue title
        priority: Optional priority label (P0-P3)
        issue_type: Optional issue classification (e.g., "test_gap")
        file_path: Optional file path for the issue
        line_number: Optional line number for the issue
        dimension: Optional quality dimension (security, testing, docs, maintainability)
        suggestion: Optional suggested fix
        target_test_file: Optional target test file for test gap issues
        target_paths: Optional list of acceptable target file paths
        test_name: Optional test function name for test gap issues
        arrange: Optional arrange steps for the test
        act: Optional act steps for the test
        assert_steps: Optional assert steps for the test

    Example:
        >>> issue = IssueItem(
        ...     id="SEC-001",
        ...     description="SQL injection vulnerability in query builder",
        ...     severity="critical"
        ... )
        >>> issue.model_dump()
        {'id': 'SEC-001', 'description': 'SQL injection vulnerability in query builder', 'severity': 'critical'}
    """

    id: str = Field(..., description="Unique identifier for the issue")
    description: str = Field(..., description="Human-readable description of the issue")
    severity: str | None = Field(None, description="Severity level of the issue")
    title: str | None = Field(None, description="Short issue title")
    priority: str | None = Field(None, description="Priority label (P0-P3)")
    issue_type: str | None = Field(None, description="Issue classification (e.g., test_gap)")
    file_path: str | None = Field(None, description="File path for the issue")
    line_number: int | None = Field(None, description="Line number for the issue")
    dimension: str | None = Field(None, description="Quality dimension for the issue")
    suggestion: str | None = Field(None, description="Suggested fix for the issue")
    target_test_file: str | None = Field(None, description="Target test file for test gap issues")
    target_paths: list[str] = Field(
        default_factory=list, description="Acceptable target file paths"
    )
    test_name: str | None = Field(None, description="Test function name for test gap issues")
    arrange: str | None = Field(None, description="Arrange steps for the test")
    act: str | None = Field(None, description="Act steps for the test")
    assert_steps: str | None = Field(
        None,
        description="Assert steps for the test",
        alias="assert",
    )


class ReviewResult(BaseAPIModel):
    """Review result containing structured issues.

    This schema ensures type safety for review agent results by using
    structured IssueItem objects instead of plain strings or untyped dicts.

    Attributes:
        issues: List of structured issues found during review
        agent_type: Optional agent type that generated this result
        status: Optional status of the review (e.g., "complete", "timeout", "error")

    Example:
        >>> result = ReviewResult(
        ...     issues=[
        ...         IssueItem(id="SEC-001", description="SQL injection", severity="critical"),
        ...         IssueItem(id="TEST-001", description="Missing tests", severity="high")
        ...     ],
        ...     agent_type="security",
        ...     status="complete"
        ... )
        >>> len(result.issues)
        2
    """

    issues: list[IssueItem] = Field(
        default_factory=list,
        description="List of structured issues found during review",
    )
    agent_type: str | None = Field(None, description="Agent type that generated this result")
    status: str | None = Field(None, description="Status of the review")


class FixRequest(BaseAPIRequest):
    """Request to fix issues found during review.

    Sent by server after AgentReport when issues need fixing.
    Matches protocol.FixRequest dataclass structure.

    Attributes:
        issues_to_fix: List of issues to fix
        execution_order: Order to fix issues (by ID)
        base_prompt: Optional base prompt from server (ADR-035 hybrid architecture)
        item_id: Optional plan item ID being fixed
        issue_details: Optional full issue dicts with metadata
        fix_history: Optional summary of previous fix attempts

    Example:
        >>> request = FixRequest(
        ...     issues_to_fix=[
        ...         {"id": "SEC-001", "description": "SQL injection", "severity": "critical"}
        ...     ],
        ...     execution_order=["SEC-001"],
        ...     base_prompt="Fix the security issues"
        ... )
        >>> len(request.issues_to_fix)
        1
    """

    issues_to_fix: list[dict[str, Any]] = Field(
        default_factory=list, description="List of issues to fix"
    )
    execution_order: list[str] = Field(
        default_factory=list, description="Order to fix issues (by ID)"
    )
    base_prompt: str | None = Field(None, description="Base prompt from server")
    item_id: str | None = Field(None, description="Plan item ID being fixed")
    issue_details: list[dict[str, Any]] = Field(
        default_factory=list, description="Full issue dicts with metadata"
    )
    fix_history: str | None = Field(None, description="Summary of previous fix attempts")


class ExecutionResult(BaseAPIResponse):
    """Report execution result to server.

    Sent by client after executing a plan item.
    Matches protocol.ExecutionResult dataclass structure.

    Attributes:
        session_id: Session identifier
        item_id: Plan item ID that was executed
        status: Execution status (success, failure, partial)
        summary: LLM-generated summary
        files_changed: Number of files changed
        tests_passed: Whether tests passed
        test_count: Number of tests run
        coverage_delta: Change in coverage percentage

    Example:
        >>> result = ExecutionResult(
        ...     session_id="sess_123",
        ...     item_id="item_1",
        ...     status="success",
        ...     summary="Implemented feature X",
        ...     files_changed=3,
        ...     tests_passed=True,
        ...     test_count=15,
        ...     coverage_delta=2.5
        ... )
        >>> result.status
        'success'
    """

    session_id: str = Field(..., description="Session identifier")
    item_id: str = Field(..., description="Plan item ID that was executed")
    status: str = Field(..., description="Execution status (success, failure, partial)")
    summary: str = Field(default="", description="LLM-generated summary")
    files_changed: int = Field(default=0, description="Number of files changed")
    tests_passed: bool = Field(default=False, description="Whether tests passed")
    test_count: int = Field(default=0, description="Number of tests run")
    coverage_delta: float = Field(default=0.0, description="Change in coverage percentage")
    skip_reason: str | None = Field(
        default=None,
        description="Optional execution skip reason when the item was intentionally not run",
    )


class DerivationResult(BaseAPIResponse):
    """Report derived plan to server.

    Sent by client after completing derivation.
    Matches protocol.DerivedPlan dataclass structure.

    Attributes:
        session_id: Session identifier
        plan_items: Derived plan items
        raw_response: Raw LLM response (for debugging)

    Example:
        >>> result = DerivationResult(
        ...     session_id="sess_123",
        ...     plan_items=[
        ...         {"id": "1", "description": "Set up database", "status": "pending"}
        ...     ],
        ...     raw_response="Here is the plan..."
        ... )
        >>> len(result.plan_items)
        1
    """

    session_id: str = Field(..., description="Session identifier")
    plan_items: list[dict[str, Any]] = Field(default_factory=list, description="Derived plan items")
    raw_response: str = Field(default="", description="Raw LLM response (for debugging)")


class PlanItem(BaseAPIModel):
    """Plan item schema for API transmission.

    Represents a single plan item with optional assumptions field.
    Aligned with obra/schemas/plan_schema.py TaskSchema.

    Attributes:
        id: Plan item identifier
        description: Description of the plan item
        status: Current status (pending, in_progress, completed, blocked)
        verify: Optional verification criteria
        depends_on: Optional list of dependency IDs
        assumptions: Optional list of assumptions for this item
        notes: Optional notes about the item
        work_phase: Optional agent work phase hint
        suggested_agent: Optional suggested agent type
        is_stale: Flag indicating if this derived item needs re-derivation (default False)
        stale_reason: Optional reason why this item is marked as stale
        source_step_id: Optional ID of the UserPlan step this item was derived from
        derived_at: Optional timestamp when this item was derived from UserPlan

    Example:
        >>> item = PlanItem(
        ...     id="1",
        ...     description="Set up database",
        ...     status="pending",
        ...     assumptions=["PostgreSQL is available", "User has admin access"]
        ... )
        >>> item.assumptions
        ['PostgreSQL is available', 'User has admin access']
    """

    id: str = Field(..., description="Plan item identifier")
    description: str = Field(..., description="Description of the plan item")
    status: str = Field(..., description="Current status")
    verify: str | None = Field(None, description="Verification criteria")
    depends_on: list[str] | None = Field(None, description="List of dependency IDs")
    assumptions: list[str] | None = Field(None, description="List of assumptions for this item")
    notes: str | None = Field(None, description="Notes about the item")
    work_phase: str | None = Field(
        None, description="Agent work phase hint (explore, plan, implement, commit)"
    )
    suggested_agent: str | None = Field(
        None, description="Suggested agent type for this task (e.g., 'Explore', 'Plan')"
    )
    # Staleness tracking fields (S9.T3a)
    is_stale: bool = Field(
        default=False,
        description="Flag indicating if this derived item needs re-derivation",
    )
    stale_reason: str | None = Field(None, description="Reason why this item is marked as stale")
    source_step_id: str | None = Field(
        None, description="ID of the UserPlan step this item was derived from"
    )
    derived_at: datetime | None = Field(
        None, description="Timestamp when this item was derived from UserPlan"
    )


class ServerActionSchema(BaseAPIResponse):
    """Action instruction from server to client.

    This is the Pydantic validation schema for ServerAction protocol type.
    Provides strict validation for server responses to prevent type mismatches
    and invalid action values (fixes C8 from hardening analysis).

    Attributes:
        action: Action type to perform (derive, story0, examine, revise, execute, review, fix, complete, escalate, wait, error)
        session_id: Session identifier
        iteration: Current iteration number
        payload: Action-specific data
        metadata: Additional metadata
        bypass_modes_active: List of active bypass modes (for warnings)
        error_code: Error code if action is ERROR
        error_message: Error message if action is ERROR
        timestamp: ISO-8601 timestamp

    Example:
        >>> action = ServerActionSchema(
        ...     action="derive",
        ...     session_id="sess_123",
        ...     iteration=1,
        ...     payload={"objective": "Build feature X"}
        ... )
        >>> action.action
        'derive'
    """

    action: str = Field(..., description="Action type to perform")
    session_id: str = Field(..., description="Session identifier")
    iteration: int = Field(default=0, description="Current iteration number")
    payload: dict[str, Any] = Field(default_factory=dict, description="Action-specific data")
    metadata: dict[str, Any] = Field(default_factory=dict, description="Additional metadata")
    bypass_modes_active: list[str] = Field(
        default_factory=list, description="List of active bypass modes"
    )

    @field_validator("bypass_modes_active", mode="before")
    @classmethod
    def _coerce_bypass_modes_none(cls, v: Any) -> list[str]:
        return v if v is not None else []

    error_code: str | None = Field(None, description="Error code if action is ERROR")
    error_message: str | None = Field(None, description="Error message if action is ERROR")
    timestamp: str | None = Field(None, description="ISO-8601 timestamp")
    rationale: str | None = Field(
        None, description="Rationale for action (ISSUE-SAAS-023)"
    )  # Server may include this


class StepPromptRequestSchema(BaseAPIRequest):
    """Pydantic schema for the per-step derivation prompt RPC (ADR-103)."""

    session_id: str = Field(..., description="Active derivation session identifier")
    step_kind: str = Field(
        ..., description="Builder discriminator (e.g. 'step1', 'step2_per_epic')"
    )
    inputs: dict[str, Any] = Field(
        default_factory=dict,
        description="Builder kwargs forwarded to the resolved ServerDerivationPromptFamily method",
    )


class StepPromptResponseSchema(BaseAPIResponse):
    """Server response carrying the server-authored prompt text (ADR-103)."""

    prompt_text: str = Field(..., description="Server-authored prompt, marker still embedded")
    family_name: str = Field(..., description="Resolved prompt family name (e.g. 'software')")
    family_version: str = Field(..., description="Prompt family semantic version")
    variant_id: str | None = Field(None, description="Variant/A-B-test id if assigned")
    session_id: str = Field(..., description="Session identifier for correlation")


class StepTemplateResponseSchema(BaseAPIResponse):
    """Server response carrying a per-step template skeleton (ADR-103)."""

    template: dict[str, Any] | str = Field(
        ...,
        description="Template dict (Step 1 epics) or prose skeleton (Step 2 per-epic/repair)",
    )
    family_name: str = Field(..., description="Resolved prompt family name (e.g. 'software')")
    family_version: str = Field(..., description="Prompt family semantic version")
    variant_id: str | None = Field(None, description="Variant/A-B-test id if assigned")
    session_id: str = Field(..., description="Session identifier for correlation")


IntentStepPromptRequestSchema = StepPromptRequestSchema
IntentStepPromptResponseSchema = StepPromptResponseSchema
IntentStepTemplateResponseSchema = StepTemplateResponseSchema
ExecuteStepPromptRequestSchema = StepPromptRequestSchema
ExecuteStepPromptResponseSchema = StepPromptResponseSchema
ExecuteStepTemplateResponseSchema = StepTemplateResponseSchema
ReviewStepPromptRequestSchema = StepPromptRequestSchema
ReviewStepPromptResponseSchema = StepPromptResponseSchema
ReviewStepTemplateResponseSchema = StepTemplateResponseSchema
Story0StepPromptRequestSchema = StepPromptRequestSchema
Story0StepPromptResponseSchema = StepPromptResponseSchema
Story0StepTemplateResponseSchema = StepTemplateResponseSchema
DeriveAuxStepPromptRequestSchema = StepPromptRequestSchema
DeriveAuxStepPromptResponseSchema = StepPromptResponseSchema
DeriveAuxStepTemplateResponseSchema = StepTemplateResponseSchema


# Convenience exports
__all__ = [
    "BaseAPIModel",
    "BaseAPIRequest",
    "BaseAPIResponse",
    "DerivationResult",
    "ExecutionResult",
    "FixRequest",
    "IssueItem",
    "PlanItem",
    "ReviewResult",
    "ServerActionSchema",
    "StepPromptRequestSchema",
    "StepPromptResponseSchema",
    "StepTemplateResponseSchema",
    "IntentStepPromptRequestSchema",
    "IntentStepPromptResponseSchema",
    "IntentStepTemplateResponseSchema",
    "ExecuteStepPromptRequestSchema",
    "ExecuteStepPromptResponseSchema",
    "ExecuteStepTemplateResponseSchema",
    "ReviewStepPromptRequestSchema",
    "ReviewStepPromptResponseSchema",
    "ReviewStepTemplateResponseSchema",
    "Story0StepPromptRequestSchema",
    "Story0StepPromptResponseSchema",
    "Story0StepTemplateResponseSchema",
    "DeriveAuxStepPromptRequestSchema",
    "DeriveAuxStepPromptResponseSchema",
    "DeriveAuxStepTemplateResponseSchema",
]
