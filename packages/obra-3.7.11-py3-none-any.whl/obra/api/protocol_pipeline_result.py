"""Result pipeline types for stage execution outcomes.

This module is part of the protocol*.py family and is kept byte-for-byte
in sync between:
- functions/src/orchestration/protocol_pipeline_result.py
- obra/api/protocol_pipeline_result.py

Contains PipelineStageResult and all result-specific helper functions,
extracted from protocol_pipeline.py to reduce cognitive load for LLM-led
development.
"""

from dataclasses import dataclass, field
from typing import Any

from obra.workflow.stage_artifacts import (
    collect_artifact_contract_issues,
    normalize_stage_output_artifacts,
    normalize_workflow_accumulation_artifact,
)

from .protocol_core import _coerce_lifecycle_payload, _coerce_optional_dict
from .protocol_pipeline import (
    ArtifactReferencePayload,
    LoopResumePayload,
    PendingManualPayload,
    ProducedArtifactPayload,
    RunnerDiagnosticPayload,
    StageLoopSignal,
    StageRoutingSignal,
    _parse_artifact_refs,
    _parse_produced_artifacts,
    _raise_artifact_contract_issues,
)


def _hydrate_result_signals(result: "PipelineStageResult") -> None:
    """Hydrate typed signal and lifecycle fields on a PipelineStageResult."""
    if isinstance(result.routing_signal, dict):
        result.routing_signal = StageRoutingSignal.from_dict(result.routing_signal)
    if isinstance(result.loop_signal, dict):
        result.loop_signal = StageLoopSignal.from_dict(result.loop_signal)
    if isinstance(result.pending_manual, dict):
        result.pending_manual = PendingManualPayload.from_dict(result.pending_manual)
    if isinstance(result.resume, dict):
        result.resume = LoopResumePayload.from_dict(result.resume)
    result.workflow_lifecycle = _coerce_lifecycle_payload(result.workflow_lifecycle)
    result.lifecycle_decisions = _coerce_optional_dict(result.lifecycle_decisions)
    result.legacy_phase_normalization = _coerce_optional_dict(result.legacy_phase_normalization)
    result.evidence = dict(result.evidence) if isinstance(result.evidence, dict) else {}
    if isinstance(result.runner_diagnostic, dict):
        result.runner_diagnostic = RunnerDiagnosticPayload.from_dict(result.runner_diagnostic)


def _validate_and_normalize_result_artifacts(result: "PipelineStageResult") -> None:
    """Validate artifact contract fields and normalize artifact payload shapes."""
    issues = collect_artifact_contract_issues(
        stage_output_artifacts=result.stage_output_artifacts,
        candidate_stage_output_artifacts=result.candidate_stage_output_artifacts,
        accepted_stage_output_artifact_refs=result.accepted_stage_output_artifact_refs,
        workflow_accumulation_artifact=result.workflow_accumulation_artifact,
        candidate_workflow_accumulation_artifact=result.candidate_workflow_accumulation_artifact,
        accepted_workflow_accumulation_artifact_ref=result.accepted_workflow_accumulation_artifact_ref,
    )
    if isinstance(result.metadata, dict) and (
        result.metadata.get("produced_outputs")
        or result.metadata.get("files_changed")
        or result.metadata.get("file_targets")
    ):
        issues.extend(collect_artifact_contract_issues(payload=result.metadata))
    _raise_artifact_contract_issues(issues)

    result.candidate_stage_output_artifacts = _parse_produced_artifacts(
        normalize_stage_output_artifacts(result.candidate_stage_output_artifacts)
    )
    result.accepted_stage_output_artifact_refs = _parse_artifact_refs(
        result.accepted_stage_output_artifact_refs
    )
    result.produced_stage_output_artifact_refs = _parse_artifact_refs(
        result.produced_stage_output_artifact_refs
    )
    result.candidate_produced_stage_output_artifact_refs = _parse_artifact_refs(
        result.candidate_produced_stage_output_artifact_refs
    )
    if isinstance(result.candidate_workflow_accumulation_artifact, dict):
        result.candidate_workflow_accumulation_artifact = ProducedArtifactPayload.from_dict(
            normalize_workflow_accumulation_artifact(result.candidate_workflow_accumulation_artifact)
        )
    if isinstance(result.accepted_workflow_accumulation_artifact_ref, dict):
        result.accepted_workflow_accumulation_artifact_ref = ArtifactReferencePayload.from_dict(
            result.accepted_workflow_accumulation_artifact_ref
        )
    result.stage_output_artifacts = _parse_produced_artifacts(
        normalize_stage_output_artifacts(result.stage_output_artifacts)
    )
    if isinstance(result.workflow_accumulation_artifact, dict):
        result.workflow_accumulation_artifact = ProducedArtifactPayload.from_dict(
            normalize_workflow_accumulation_artifact(result.workflow_accumulation_artifact)
        )


def _reconcile_result_fields(result: "PipelineStageResult") -> None:
    """Reconcile canonical result fields after signal and artifact hydration."""
    _reconcile_result_runner_metadata(result)
    _sync_result_findings_and_issues(result)
    _resolve_result_verdict_state(result)
    _enrich_result_metadata(result)


def _reconcile_result_runner_metadata(result: "PipelineStageResult") -> None:
    """Backfill runner fields and duration from metadata when omitted."""
    metadata = result.metadata if isinstance(result.metadata, dict) else None
    if metadata is None:
        return
    if not result.runner_id:
        result.runner_id = str(metadata.get("runner_id", "") or "")
    if not result.runner_version:
        result.runner_version = str(metadata.get("runner_version", "") or "")
    if not result.runner_selector:
        result.runner_selector = str(metadata.get("runner_selector", "") or "")
    if result.runner_diagnostic is None:
        result.runner_diagnostic = RunnerDiagnosticPayload.from_dict(
            metadata.get("runner_diagnostic")
        )
    if not result.duration_s and metadata.get("duration_s") is not None:
        result.duration_s = float(metadata.get("duration_s"))


def _sync_result_findings_and_issues(result: "PipelineStageResult") -> None:
    """Keep findings and issues populated from whichever side was provided."""
    if not result.findings and result.issues:
        result.findings = list(result.issues)
    if not result.issues and result.findings:
        result.issues = list(result.findings)


def _resolve_result_verdict_state(result: "PipelineStageResult") -> None:
    """Normalize verdict, outcome, and execution status defaults."""
    if not result.verdict:
        result.verdict = "sound" if result.outcome == "passed" and not result.issues else "issues"
    if not result.outcome:
        result.outcome = "passed" if result.verdict == "sound" else "issues_found"
    if not result.execution_status:
        result.execution_status = "complete"
    if result.verdict == "sound" and (result.issues or result.findings):
        result.verdict = "issues"
    if result.verdict != "sound" and result.outcome == "passed":
        result.outcome = "issues_found"


def _enrich_result_metadata(result: "PipelineStageResult") -> None:
    """Write canonical result fields back into metadata when absent."""
    if not isinstance(result.metadata, dict):
        return
    if result.runner_id and "runner_id" not in result.metadata:
        result.metadata["runner_id"] = result.runner_id
    if result.runner_version and "runner_version" not in result.metadata:
        result.metadata["runner_version"] = result.runner_version
    if result.runner_selector and "runner_selector" not in result.metadata:
        result.metadata["runner_selector"] = result.runner_selector
    if result.runner_diagnostic is not None and "runner_diagnostic" not in result.metadata:
        result.metadata["runner_diagnostic"] = result.runner_diagnostic.to_dict()
    if result.loop_verdict and "loop_verdict" not in result.metadata:
        result.metadata["loop_verdict"] = result.loop_verdict
    if result.loop_state and "loop_state" not in result.metadata:
        result.metadata["loop_state"] = result.loop_state


def _parse_result_signal_fields(data: dict[str, Any]) -> dict[str, Any]:
    """Build signal and lifecycle fields for PipelineStageResult.from_dict."""
    return {
        "routing_signal": StageRoutingSignal.from_dict(data.get("routing_signal")),
        "loop_signal": StageLoopSignal.from_dict(data.get("loop_signal")),
        "loop_verdict": str(data.get("loop_verdict") or ""),
        "loop_state": str(data.get("loop_state") or ""),
        "pending_manual": PendingManualPayload.from_dict(data.get("pending_manual")),
        "resume": LoopResumePayload.from_dict(data.get("resume")),
        "workflow_lifecycle": _coerce_lifecycle_payload(data.get("workflow_lifecycle")),
        "lifecycle_decisions": _coerce_optional_dict(data.get("lifecycle_decisions")),
        "legacy_phase_normalization": _coerce_optional_dict(data.get("legacy_phase_normalization")),
        "evidence": data.get("evidence", {}) if isinstance(data.get("evidence"), dict) else {},
    }


def _parse_result_runner_fields(data: dict[str, Any]) -> dict[str, Any]:
    """Build runner and verdict fields for PipelineStageResult.from_dict."""
    return {
        "runner_id": str(data.get("runner_id", "") or ""),
        "runner_version": str(data.get("runner_version", "") or ""),
        "runner_selector": str(data.get("runner_selector", "") or ""),
        "runner_diagnostic": RunnerDiagnosticPayload.from_dict(data.get("runner_diagnostic")),
        "metadata": data.get("metadata", {}) if isinstance(data.get("metadata"), dict) else {},
        "verdict": str(data.get("verdict", "sound") or "sound"),
        "issues": data.get("issues", []) if isinstance(data.get("issues"), list) else [],
        "iteration": int(data.get("iteration", 0) or 0),
        "duration_s": float(data.get("duration_s", 0.0) or 0.0),
    }


@dataclass
class PipelineStageResult:
    """Result from a custom pipeline stage execution."""

    stage_name: str
    stage_execution_id: str = ""
    execution_status: str = "complete"
    outcome: str = "passed"
    findings: list[dict[str, Any]] = field(default_factory=list)
    stage_output_artifacts: list[ProducedArtifactPayload] = field(default_factory=list)
    produced_stage_output_artifact_refs: list[ArtifactReferencePayload] = field(
        default_factory=list
    )
    workflow_accumulation_artifact: ProducedArtifactPayload | None = None
    candidate_stage_output_artifacts: list[ProducedArtifactPayload] = field(default_factory=list)
    candidate_produced_stage_output_artifact_refs: list[ArtifactReferencePayload] = field(
        default_factory=list
    )
    accepted_stage_output_artifact_refs: list[ArtifactReferencePayload] = field(
        default_factory=list
    )
    candidate_workflow_accumulation_artifact: ProducedArtifactPayload | None = None
    accepted_workflow_accumulation_artifact_ref: ArtifactReferencePayload | None = None
    routing_signal: StageRoutingSignal | None = None
    loop_signal: StageLoopSignal | None = None
    loop_verdict: str = ""
    loop_state: str = ""
    pending_manual: PendingManualPayload | None = None
    resume: LoopResumePayload | None = None
    workflow_lifecycle: dict[str, Any] = field(default_factory=dict)
    lifecycle_decisions: dict[str, Any] = field(default_factory=dict)
    legacy_phase_normalization: dict[str, Any] = field(default_factory=dict)
    evidence: dict[str, Any] = field(default_factory=dict)
    runner_id: str = ""
    runner_version: str = ""
    runner_selector: str = ""
    runner_diagnostic: "RunnerDiagnosticPayload | None" = None
    metadata: dict[str, Any] = field(default_factory=dict)
    verdict: str = "sound"
    issues: list[dict[str, Any]] = field(default_factory=list)
    iteration: int = 0
    duration_s: float = 0.0

    def __post_init__(self) -> None:
        """Hydrate canonical result fields while preserving diagnostic signals."""
        _hydrate_result_signals(self)
        _validate_and_normalize_result_artifacts(self)
        _reconcile_result_fields(self)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        return {
            "stage_name": self.stage_name,
            "stage_execution_id": self.stage_execution_id,
            "execution_status": self.execution_status,
            "outcome": self.outcome,
            "findings": self.findings,
            "stage_output_artifacts": [
                artifact.to_dict() for artifact in self.stage_output_artifacts
            ],
            "produced_stage_output_artifact_refs": [
                artifact_ref.to_dict()
                for artifact_ref in self.produced_stage_output_artifact_refs
            ],
            "workflow_accumulation_artifact": (
                self.workflow_accumulation_artifact.to_dict()
                if self.workflow_accumulation_artifact is not None
                else None
            ),
            "candidate_stage_output_artifacts": [
                artifact.to_dict() for artifact in self.candidate_stage_output_artifacts
            ],
            "candidate_produced_stage_output_artifact_refs": [
                artifact_ref.to_dict()
                for artifact_ref in self.candidate_produced_stage_output_artifact_refs
            ],
            "accepted_stage_output_artifact_refs": [
                artifact_ref.to_dict() for artifact_ref in self.accepted_stage_output_artifact_refs
            ],
            "candidate_workflow_accumulation_artifact": (
                self.candidate_workflow_accumulation_artifact.to_dict()
                if self.candidate_workflow_accumulation_artifact is not None
                else None
            ),
            "accepted_workflow_accumulation_artifact_ref": (
                self.accepted_workflow_accumulation_artifact_ref.to_dict()
                if self.accepted_workflow_accumulation_artifact_ref is not None
                else None
            ),
            "routing_signal": (self.routing_signal.to_dict() if self.routing_signal else None),
            "loop_signal": self.loop_signal.to_dict() if self.loop_signal else None,
            "loop_verdict": self.loop_verdict,
            "loop_state": self.loop_state,
            "pending_manual": (
                self.pending_manual.to_dict() if self.pending_manual is not None else None
            ),
            "resume": self.resume.to_dict() if self.resume is not None else None,
            "workflow_lifecycle": self.workflow_lifecycle,
            "lifecycle_decisions": self.lifecycle_decisions,
            "legacy_phase_normalization": self.legacy_phase_normalization,
            "evidence": self.evidence,
            "runner_id": self.runner_id,
            "runner_version": self.runner_version,
            "runner_selector": self.runner_selector,
            "runner_diagnostic": (
                self.runner_diagnostic.to_dict() if self.runner_diagnostic is not None else None
            ),
            "metadata": self.metadata,
            "verdict": self.verdict,
            "issues": self.issues,
            "iteration": self.iteration,
            "duration_s": self.duration_s,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "PipelineStageResult":
        """Create from dictionary."""
        _raise_artifact_contract_issues(
            collect_artifact_contract_issues(
                payload=data,
                stage_output_artifacts=(
                    data.get("stage_output_artifacts", [])
                    if isinstance(data.get("stage_output_artifacts"), list)
                    else None
                ),
                candidate_stage_output_artifacts=(
                    data.get("candidate_stage_output_artifacts", [])
                    if isinstance(data.get("candidate_stage_output_artifacts"), list)
                    else None
                ),
                accepted_stage_output_artifact_refs=(
                    data.get("accepted_stage_output_artifact_refs", [])
                    if isinstance(data.get("accepted_stage_output_artifact_refs"), list)
                    else None
                ),
                workflow_accumulation_artifact=data.get("workflow_accumulation_artifact"),
                candidate_workflow_accumulation_artifact=data.get(
                    "candidate_workflow_accumulation_artifact"
                ),
                accepted_workflow_accumulation_artifact_ref=data.get(
                    "accepted_workflow_accumulation_artifact_ref"
                ),
            )
        )
        artifact_fields = {
            "stage_output_artifacts": _parse_produced_artifacts(
                data.get("stage_output_artifacts") if isinstance(data.get("stage_output_artifacts"), list) else []
            ),
            "workflow_accumulation_artifact": ProducedArtifactPayload.from_dict(
                data.get("workflow_accumulation_artifact")
            ),
            "produced_stage_output_artifact_refs": _parse_artifact_refs(
                data.get("produced_stage_output_artifact_refs")
                if isinstance(data.get("produced_stage_output_artifact_refs"), list)
                else []
            ),
            "candidate_stage_output_artifacts": _parse_produced_artifacts(
                data.get("candidate_stage_output_artifacts")
                if isinstance(data.get("candidate_stage_output_artifacts"), list)
                else []
            ),
            "candidate_produced_stage_output_artifact_refs": _parse_artifact_refs(
                data.get("candidate_produced_stage_output_artifact_refs")
                if isinstance(data.get("candidate_produced_stage_output_artifact_refs"), list)
                else []
            ),
            "accepted_stage_output_artifact_refs": _parse_artifact_refs(
                data.get("accepted_stage_output_artifact_refs")
                if isinstance(data.get("accepted_stage_output_artifact_refs"), list)
                else []
            ),
            "candidate_workflow_accumulation_artifact": ProducedArtifactPayload.from_dict(
                data.get("candidate_workflow_accumulation_artifact")
            ),
            "accepted_workflow_accumulation_artifact_ref": ArtifactReferencePayload.from_dict(
                data.get("accepted_workflow_accumulation_artifact_ref")
            ),
        }
        signal_fields = _parse_result_signal_fields(data)
        runner_fields = _parse_result_runner_fields(data)
        return cls(
            stage_name=str(data.get("stage_name", "") or ""),
            stage_execution_id=str(data.get("stage_execution_id", "") or ""),
            execution_status=str(data.get("execution_status") or "complete"),
            outcome=str(
                data.get("outcome")
                or ("passed" if data.get("verdict", "sound") == "sound" else "issues_found")
            ),
            findings=(data.get("findings", []) if isinstance(data.get("findings"), list) else []),
            **artifact_fields,
            **signal_fields,
            **runner_fields,
        )
