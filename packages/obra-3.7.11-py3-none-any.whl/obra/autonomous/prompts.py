"""Shared prompt-rendering utilities for autonomous workers."""

from __future__ import annotations

import json
from typing import Any


def pretty_json(payload: dict[str, Any]) -> str:
    """Render a JSON payload deterministically for prompt inclusion."""
    return json.dumps(payload, indent=2, sort_keys=True)
