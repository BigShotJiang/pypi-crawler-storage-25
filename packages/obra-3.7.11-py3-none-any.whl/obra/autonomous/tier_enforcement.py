"""Shared top-tier enforcement helpers for autonomous worker stages."""

from __future__ import annotations

from typing import Any

from obra.config.llm import PROVIDER_TIER_DEFAULTS

ENFORCED_TOP_TIER_STAGES: frozenset[str] = frozenset(
    {
        "investigation",
        "verification",
        "patch",
    }
)


def top_tier_for_provider(provider: str) -> dict[str, str] | None:
    """Return the canonical high-tier model mapping for a provider."""
    provider_tiers = PROVIDER_TIER_DEFAULTS.get(provider)
    if not provider_tiers:
        return None
    high_model = provider_tiers.get("high")
    if not high_model:
        return None
    return {"model": str(high_model), "reasoning_level": "high"}


def enforce_top_tier(config: dict[str, Any], stage: str) -> dict[str, Any]:
    """Apply canonical top-tier overrides for autonomous remediation stages."""
    if stage not in ENFORCED_TOP_TIER_STAGES:
        return config
    provider = config.get("provider")
    if provider is None:
        return config
    enforced = top_tier_for_provider(str(provider))
    if not enforced:
        return config
    updated = dict(config)
    updated["model"] = enforced["model"]
    updated["reasoning_level"] = enforced["reasoning_level"]
    return updated
