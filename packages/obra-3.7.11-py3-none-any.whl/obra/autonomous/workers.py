"""Shared bounded analysis and fix worker helpers."""

from __future__ import annotations

import json
import logging
from collections.abc import Callable
from pathlib import Path
from typing import Any, TypeVar, cast

from obra.autonomous.validation_outcome import ValidationOutcome, parse_validation_outcome
from obra.hybrid.preexecution_pipeline import build_preexecution_pipeline
from obra.llm.cli_runner import invoke_llm_via_cli
from obra.llm.subprocess_config import is_codex_backed_provider

logger = logging.getLogger(__name__)


def _codex_defaults_for_provider(
    provider: object,
    git_config: dict[str, Any] | None = None,
    codex_config: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Resolve Codex CLI defaults that mirror ``_apply_provider_rules``.

    The harness fix/analysis worker resolves its model via ``resolve_tier_config``
    which returns a deliberately-narrow dict — no ``codex`` or ``git`` sections.
    Without this helper the worker invokes Codex CLI with default
    ``--sandbox workspace-write`` (Apple Seatbelt), which blocks ``/bin/ps`` and
    chromium-headless-shell spawns and prevents Playwright validation. The
    configured Obra baseline for ``openai``/``ollama`` is full bypass
    (default_config.yaml ``llm.codex.bypass_sandbox: true``); this restores
    that posture for the worker subprocess. Anthropic/Google paths unchanged.

    Explicit overrides in ``llm_config["codex"]`` / ``llm_config["git"]`` are
    preserved, so callers can tighten or loosen the defaults intentionally.
    """
    codex = codex_config if isinstance(codex_config, dict) else {}
    git = git_config if isinstance(git_config, dict) else {}
    codex_backed = is_codex_backed_provider(provider)
    bypass = bool(codex.get("bypass_sandbox", codex_backed))
    approval_raw = codex.get("approval_mode")
    approval: str | None = (
        str(approval_raw)
        if approval_raw
        else ("full-auto" if codex_backed else None)
    )
    skip_git = bool(git.get("skip_check", codex_backed))
    return {
        "bypass_sandbox": bypass,
        "approval_mode": approval,
        "skip_git_check": skip_git,
    }

AnalysisResultT = TypeVar("AnalysisResultT", bound=dict[str, Any])


def _build_diagnostic_hooks(
    diagnostic_dir: Path, action_name: str
) -> tuple[Callable[..., None], Callable[[str], None]]:
    """Return (log_event, on_stream) callbacks that persist to *diagnostic_dir*.

    Without these hooks the bounded analysis pipeline's parse/retry events
    disappear and the raw LLM stdout is never captured, leaving analyzer
    failures undiagnosable after the fact. The callbacks append one line per
    event to ``analyzer-events.jsonl`` and stream stdout to
    ``analyzer-stdout.txt`` under the attempt directory.
    """
    diagnostic_dir.mkdir(parents=True, exist_ok=True)
    events_path = diagnostic_dir / "analyzer-events.jsonl"
    stdout_path = diagnostic_dir / "analyzer-stdout.txt"

    def log_event(event_type: str, **fields: Any) -> None:
        record = {"event_type": event_type, "action": action_name, **fields}
        try:
            with events_path.open("a", encoding="utf-8") as handle:
                handle.write(json.dumps(record, default=str) + "\n")
        except OSError:
            logger.debug("Failed to write analyzer diagnostic event", exc_info=True)

    def on_stream(chunk: str) -> None:
        try:
            with stdout_path.open("a", encoding="utf-8") as handle:
                handle.write(chunk)
        except OSError:
            logger.debug("Failed to append analyzer stdout chunk", exc_info=True)

    return log_event, on_stream


def run_analysis_worker(
    *,
    working_dir: Path,
    action_name: str,
    llm_config: dict[str, Any],
    prompt: str,
    template_content: dict[str, Any],
    validator: Callable[[dict[str, Any] | str], tuple[bool, str | None]],
    fallback_fn: Callable[[], AnalysisResultT],
    timeout_s: int,
    output_schema: dict[str, Any] | None = None,
    post_validate: Callable[[dict[str, Any]], AnalysisResultT] | None = None,
    diagnostic_dir: Path | None = None,
) -> AnalysisResultT:
    """Run a bounded structured analysis worker with deterministic fallback."""
    pipeline_kwargs: dict[str, Any] = {
        "working_dir": working_dir,
        "action_name": action_name,
        "max_retries": 3,
    }
    if diagnostic_dir is not None:
        log_event, on_stream = _build_diagnostic_hooks(diagnostic_dir, action_name)
        pipeline_kwargs["log_event"] = log_event
        pipeline_kwargs["on_stream"] = on_stream
    try:
        pipeline = build_preexecution_pipeline(**pipeline_kwargs)
        result, _metadata = pipeline.execute(
            base_prompt=prompt,
            template_content=template_content,
            validator=validator,
            fallback_fn=fallback_fn,
            llm_config=llm_config,
            timeout_s=timeout_s,
            allow_unchanged=False,
            output_schema=output_schema,
        )
        if not isinstance(result, dict):
            raise TypeError("Analysis worker output must be a JSON object")
        if post_validate is not None:
            return post_validate(result)
        return cast(AnalysisResultT, result)
    except Exception:
        logger.warning(
            "Analysis worker LLM call failed, using deterministic fallback",
            exc_info=True,
        )
        return fallback_fn()


def run_fix_worker(
    *,
    working_dir: Path,
    call_site: str,
    llm_config: dict[str, Any],
    prompt: str,
    timeout_s: int,
) -> dict[str, Any]:
    """Run a bounded fix worker in execute mode and normalize its summary.

    The returned dict carries ``validation_outcome`` parsed from the worker's
    trailing JSON block. Callers gate auto-commit on this field — ``ran``
    permits commit; ``failed`` / ``skipped`` / ``no_outcome_emitted`` route
    the patch to revert + operator review. See
    ``obra/autonomous/validation_outcome.py`` for the contract.
    """
    git_section = llm_config.get("git") if isinstance(llm_config.get("git"), dict) else None
    codex_section = llm_config.get("codex") if isinstance(llm_config.get("codex"), dict) else None
    codex_defaults = _codex_defaults_for_provider(
        llm_config["provider"],
        git_config=git_section,
        codex_config=codex_section,
    )
    summary = invoke_llm_via_cli(
        prompt=prompt,
        cwd=working_dir,
        provider=str(llm_config["provider"]),
        model=str(llm_config["model"]),
        reasoning_level=str(llm_config["reasoning_level"]),
        auth_method=str(llm_config["auth_method"]),
        timeout_s=timeout_s,
        mode="execute",
        response_format="text",
        call_site=call_site,
        skip_git_check=codex_defaults["skip_git_check"],
        bypass_sandbox=codex_defaults["bypass_sandbox"],
        approval_mode=codex_defaults["approval_mode"],
        skip_interactive_guard=True,
    )
    summary_text = summary.strip()
    outcome: ValidationOutcome = parse_validation_outcome(summary_text)
    return {
        "status": "completed",
        "summary": summary_text,
        "validation_outcome": outcome.to_dict(),
    }
