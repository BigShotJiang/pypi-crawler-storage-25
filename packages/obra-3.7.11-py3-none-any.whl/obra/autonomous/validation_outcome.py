"""Structured validation outcome contract for the autonomous fix worker.

The fix worker emits a trailing fenced JSON block describing which test suites
it ran and whether they passed. The harness parses the block, surfaces it on
``state.json`` ``step_fix_attempts_history[i].validation_outcome``, and gates
auto-commit on the ``overall`` field. This replaces the prior fix_summary
text-search heuristic (matching strings like "could not run Playwright"),
which was easy to drift from and impossible to evolve.

Expected JSON shape (last fenced ``json`` block in the worker's stdout):

    {
      "validation_outcome": "ran" | "skipped" | "failed",
      "reason": "<short>",
      "suites": [
        {"name": "<id>", "outcome": "ran" | "skipped" | "failed", "detail": "<short>"},
        ...
      ]
    }

Missing or malformed blocks parse to ``overall=no_outcome_emitted``; the
harness gate then refuses the auto-commit (fail-closed).
"""

from __future__ import annotations

import json
import logging
import re
from dataclasses import asdict, dataclass, field
from typing import Any

logger = logging.getLogger(__name__)

__all__ = [
    "KNOWN_SUITE_NAMES",
    "OUTCOME_FAILED",
    "OUTCOME_NO_OUTCOME_EMITTED",
    "OUTCOME_RAN",
    "OUTCOME_SKIPPED",
    "SuiteResult",
    "ValidationOutcome",
    "parse_validation_outcome",
    "validation_outcome_instructions",
]

OUTCOME_RAN = "ran"
OUTCOME_SKIPPED = "skipped"
OUTCOME_FAILED = "failed"
OUTCOME_NO_OUTCOME_EMITTED = "no_outcome_emitted"

_VALID_SUITE_OUTCOMES = frozenset({OUTCOME_RAN, OUTCOME_SKIPPED, OUTCOME_FAILED})
_VALID_OVERALL = frozenset({OUTCOME_RAN, OUTCOME_SKIPPED, OUTCOME_FAILED})

KNOWN_SUITE_NAMES: frozenset[str] = frozenset(
    {
        "vitest",
        "tsc",
        "playwright:browser",
        "playwright:agentic",
        "pytest",
        "ruff",
        "mypy",
    }
)


@dataclass(frozen=True)
class SuiteResult:
    """One test suite's recorded outcome from the fix worker."""

    name: str
    outcome: str
    detail: str = ""

    def to_dict(self) -> dict[str, str]:
        return asdict(self)


@dataclass(frozen=True)
class ValidationOutcome:
    """Parsed result of the fix-worker's trailing validation_outcome block.

    ``overall`` is the gate the harness reads. ``suites`` carries the per-suite
    detail for operator review and for the next iteration's prompt context.
    ``reason`` is non-empty for any non-``ran`` overall.
    """

    overall: str
    reason: str = ""
    suites: tuple[SuiteResult, ...] = field(default_factory=tuple)

    @property
    def commit_allowed(self) -> bool:
        return self.overall == OUTCOME_RAN

    def to_dict(self) -> dict[str, Any]:
        return {
            "overall": self.overall,
            "reason": self.reason,
            "suites": [s.to_dict() for s in self.suites],
        }


# Last fenced ``json`` block in the worker stdout. Use ``re.DOTALL`` to span
# newlines and ``re.IGNORECASE`` so the worker can write ``JSON`` or ``json``.
_JSON_BLOCK_RE = re.compile(
    r"```\s*json\s*\n(?P<body>.*?)\n```",
    re.DOTALL | re.IGNORECASE,
)


def parse_validation_outcome(worker_stdout: str) -> ValidationOutcome:
    """Extract the trailing ``validation_outcome`` JSON block from worker stdout.

    Tolerates absent / malformed blocks by returning ``overall=no_outcome_emitted``
    with a parser-supplied ``reason``. Unknown suite names are preserved (so
    operators can debug what the worker thought it ran), but a warning is logged.
    Multiple JSON blocks: the **last** match wins, so the worker can include
    intermediate JSON examples without breaking parse.
    """
    if not worker_stdout:
        return ValidationOutcome(
            overall=OUTCOME_NO_OUTCOME_EMITTED,
            reason="parser_empty_stdout",
        )

    matches = list(_JSON_BLOCK_RE.finditer(worker_stdout))
    if not matches:
        return ValidationOutcome(
            overall=OUTCOME_NO_OUTCOME_EMITTED,
            reason="parser_no_json_block",
        )

    # Walk from the end, picking the last block that actually parses and
    # carries a validation_outcome field. The worker may have emitted earlier
    # JSON examples in its summary (e.g. illustrating a fix); we want the
    # contract block, not the example.
    last_error = ""
    for match in reversed(matches):
        body = match.group("body").strip()
        try:
            payload = json.loads(body)
        except json.JSONDecodeError as exc:
            last_error = f"parser_json_decode_error: {exc.msg}"
            continue
        if not isinstance(payload, dict):
            last_error = "parser_payload_not_object"
            continue
        if "validation_outcome" not in payload:
            # Probably an unrelated JSON block; keep walking.
            continue
        return _normalize(payload)

    return ValidationOutcome(
        overall=OUTCOME_NO_OUTCOME_EMITTED,
        reason=last_error or "parser_no_validation_outcome_field",
    )


def _normalize(payload: dict[str, Any]) -> ValidationOutcome:
    overall_raw = str(payload.get("validation_outcome", "")).strip().lower()
    if overall_raw not in _VALID_OVERALL:
        return ValidationOutcome(
            overall=OUTCOME_NO_OUTCOME_EMITTED,
            reason=f"parser_unknown_overall:{overall_raw or '<empty>'}",
        )

    reason = str(payload.get("reason", "") or "").strip()
    if overall_raw != OUTCOME_RAN and not reason:
        # Worker emitted skipped/failed without a reason — surface that
        # explicitly so operators can spot the prompt drift.
        reason = f"parser_missing_reason_for_{overall_raw}"

    raw_suites = payload.get("suites") or []
    suites: list[SuiteResult] = []
    if isinstance(raw_suites, list):
        for entry in raw_suites:
            if not isinstance(entry, dict):
                continue
            name = str(entry.get("name", "") or "").strip()
            if not name:
                continue
            suite_outcome = str(entry.get("outcome", "") or "").strip().lower()
            if suite_outcome not in _VALID_SUITE_OUTCOMES:
                logger.debug(
                    "validation_outcome: dropping suite %s with invalid outcome %s",
                    name,
                    suite_outcome,
                )
                continue
            if name not in KNOWN_SUITE_NAMES:
                logger.warning(
                    "validation_outcome: unknown suite name %s (kept as-is)",
                    name,
                )
            detail = str(entry.get("detail", "") or "").strip()
            suites.append(SuiteResult(name=name, outcome=suite_outcome, detail=detail))

    return ValidationOutcome(
        overall=overall_raw,
        reason=reason,
        suites=tuple(suites),
    )


_VALIDATION_OUTCOME_INSTRUCTIONS = """\
Validation outcome contract (REQUIRED before exiting):
- Run the test suites relevant to the failure. For Playwright-validated
  failures (Studio browser regression, agentic visual), run
  ``npx playwright test`` against the affected specs. For pytest leaves, run
  pytest. For component-level UI failures, run vitest.
- After running, emit a single fenced JSON block describing what you
  validated. Auto-commit is gated on this block — anything other than
  ``"ran"`` causes the harness to revert your patch.
- Schema:

```json
{
  "validation_outcome": "ran" | "skipped" | "failed",
  "reason": "<short>",
  "suites": [
    {"name": "playwright:browser", "outcome": "ran", "detail": "12 passed, 0 failed"},
    {"name": "vitest", "outcome": "ran", "detail": "all passing"}
  ]
}
```

- ``ran`` means every suite that should have validated this fix passed.
- ``failed`` means a suite ran but a relevant test failed; record that
  honestly even if the fix looked correct in unit tests.
- ``skipped`` means you could not run a suite due to environment limits
  (e.g. browser launcher unavailable). Mark it skipped with a one-line
  reason — do **not** silently omit it. The harness will reject the patch
  rather than ship something unverified, which is the correct behavior.
- Recognized suite names: vitest, tsc, playwright:browser, playwright:agentic,
  pytest, ruff, mypy. Use these exactly.
"""


def validation_outcome_instructions() -> str:
    """Return the prompt block that instructs the worker to emit the JSON tail."""
    return _VALIDATION_OUTCOME_INSTRUCTIONS
