"""Shared bounded worker helpers for autonomous Obra loops.

This package centralizes the common LLM worker seams used by nightly
simulation, campaign simulation, and benchmark remediation flows. The
deterministic controllers remain responsible for loop budgets, routing,
status persistence, and final outcome policy; this package only owns the
shared analysis/fix invocation helpers, prompt utilities, and remediation
top-tier enforcement logic.
"""

from __future__ import annotations

_SUBMODULE_EXPORTS = {
    "ENFORCED_TOP_TIER_STAGES": ".tier_enforcement",
    "enforce_top_tier": ".tier_enforcement",
    "pretty_json": ".prompts",
    "run_analysis_worker": ".workers",
    "run_fix_worker": ".workers",
    "top_tier_for_provider": ".tier_enforcement",
}

__all__ = list(_SUBMODULE_EXPORTS.keys())


def __getattr__(name: str):
    """Lazily load heavy worker helpers from their owning modules."""
    if name in _SUBMODULE_EXPORTS:
        from importlib import import_module

        module = import_module(_SUBMODULE_EXPORTS[name], package=__name__)
        return getattr(module, name)
    msg = f"module {__name__!r} has no attribute {name!r}"
    raise AttributeError(msg)


def __dir__() -> list[str]:
    """Return the public package exports."""
    return __all__
