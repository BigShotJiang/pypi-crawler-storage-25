"""Prompt resolution helpers for domain-aware quality agents."""

from typing import Any

from obra.prompts.agents import load_prompt


def resolve_quality_prompt(
    domain: Any,
    prompt_name: str,
    *,
    fallback: str | None = None,
) -> str:
    """Resolve a quality prompt through the active domain or fallback loader.

    Args:
        domain: Optional domain module implementing ``get_quality_prompts``.
        prompt_name: Quality prompt key (for example ``code_quality``).
        fallback: Optional prompt text fallback if loader lookup fails.

    Returns:
        Prompt template text.

    Raises:
        KeyError: If domain is provided but prompt_name is not defined.
        LookupError: If no prompt can be resolved without a silent domain fallback.
    """
    if domain is not None:
        return domain.get_quality_prompts()[prompt_name]

    try:
        return load_prompt(prompt_name)
    except FileNotFoundError as exc:
        if fallback is not None:
            return fallback
        raise LookupError(
            "resolve_quality_prompt requires an explicit domain or fallback; "
            f"no silent software fallback per ADR-080. prompt_name={prompt_name!r}"
        ) from exc


__all__ = ["resolve_quality_prompt"]
