"""Obra domain modules.

This package provides pluggable domain modules that customize Obra's
orchestration for different use cases (software development, business workflows).

Available Domains:
    - software: Software development workflows (default)
    - business: Business process automation

Usage:
    >>> from obra.domains import load_domain, get_available_domains
    >>> print(get_available_domains())
    ['business', 'software']
    >>> domain = load_domain("software")
    >>> print(domain.name)
    software

Related:
    - docs/guides/domains/domain-overview.md
    - docs/guides/domains/using-domains.md
"""

from .capabilities import Capability, DomainCapabilities
from .constraints import DomainPlanningConstraints
from .interface import INTERFACE_VERSION, DomainModule, FileFilterConfig
from .loader import (
    DomainNotFoundError,
    DomainValidationError,
    DomainInterfaceVersionError,
    clear_domain_cache,
    get_available_domains,
    load_domain,
)
from .vocabulary import DomainVocabulary

__all__ = [
    "Capability",
    "DomainCapabilities",
    "DomainInterfaceVersionError",
    "DomainPlanningConstraints",
    "DomainVocabulary",
    "INTERFACE_VERSION",
    # Interface
    "DomainModule",
    "DomainNotFoundError",
    "DomainValidationError",
    "FileFilterConfig",
    "clear_domain_cache",
    "get_available_domains",
    # Loader
    "load_domain",
]
