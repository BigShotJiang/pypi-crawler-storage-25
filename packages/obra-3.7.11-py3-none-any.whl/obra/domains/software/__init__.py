"""Software development domain module.

This domain provides specialized configuration for software development
workflows including feature implementation, bug fixes, refactoring, and more.

This is the default domain used when no --domain flag is specified.

Usage:
    >>> from obra.domains.software import SoftwareDomain
    >>> domain = SoftwareDomain()
    >>> print(domain.name)
    software
    >>> work_types = domain.get_work_type_patterns()
    >>> print(len(work_types['work_types']))
    10

Related:
    - obra/domains/interface.py (protocol definition)
    - docs/guides/domains/using-domains.md
"""

import importlib.resources
from collections.abc import Callable
from functools import lru_cache
from typing import Any

import yaml

from obra.domains.interface import FileFilterConfig, QualityDimension
from obra.domains.capabilities import Capability, DomainCapabilities
from obra.domains.constraints import DomainPlanningConstraints
from obra.domains.lifecycle import (
    ACTIVE_STATE,
    COMPATIBILITY_PATH_STATE,
    DERIVE_CAPABILITY,
    EXECUTE_CAPABILITY,
    GIT_REQUIRED_CAPABILITY,
    PREFLIGHT_CAPABILITY,
    REVIEW_CAPABILITY,
    STORY0_CAPABILITY,
    TOOLING_VERIFICATION_CAPABILITY,
    WAIT_RESUME_CAPABILITY,
    DomainLifecyclePolicy,
)
from obra.domains.vocabulary import (
    DomainHelpCopy,
    DomainVocabulary,
    VocabularyLane,
    VocabularyPipelineStage,
)

from .derivation import SIZING_GUIDANCE, WORK_TYPE_KEYWORDS
from .filters import (
    BINARY_EXTENSIONS,
    EXCLUDED_FILES,
    EXCLUDED_PATTERNS,
    IGNORE_DIR_SUFFIXES,
    IGNORE_DIRS,
)

INTERFACE_VERSION = "v3"


class SoftwareDomain:
    """Domain module for software development workflows.

    Provides work types, quality prompts, and file filters optimized for
    software development tasks.
    """

    @property
    def name(self) -> str:
        """Return domain name."""
        return "software"

    @property
    def display_name(self) -> str:
        """Return human-readable domain name."""
        return "Software Development"

    @property
    def description(self) -> str:
        """Return short description for this domain."""
        return "Orchestration for software engineering projects"

    @property
    def example_objectives(self) -> list[str]:
        """Return representative objective examples."""
        return [
            "Add OAuth2 authentication",
            "Fix pagination bug",
            "Refactor database layer",
        ]

    @property
    def requires_git(self) -> bool:
        """Return whether this domain requires a git repository."""
        return True

    @property
    def default_sandbox_policy(self) -> str:
        """Return default sandbox policy for this domain."""
        return "WORKSPACE_WRITE"

    @property
    def closeout_key(self) -> str:
        """Return closeout template key for this domain."""
        return "software-dev"

    @lru_cache(maxsize=1)  # noqa: B019 - singleton domain, no memory leak concern
    def _load_work_types(self) -> dict[str, Any]:
        """Load work type patterns from YAML."""
        files = importlib.resources.files("obra.domains.software")
        content = (files / "work_types.yaml").read_text()
        return yaml.safe_load(content)

    def get_work_type_patterns(self) -> dict[str, Any]:
        """Return work type definitions for software development.

        Returns:
            Dictionary with work_types list, detection_settings, and fallback
        """
        return self._load_work_types()

    def get_quality_prompts(self) -> dict[str, str]:
        """Return quality assessment prompts for software development.

        Returns:
            Dictionary mapping prompt name to prompt content
        """
        return self._load_prompts()

    def get_quality_dimensions(self) -> list[QualityDimension]:
        """Return quality assessment dimensions for software workflows."""
        return [
            QualityDimension(
                id="code_quality",
                display_name="Code Quality",
                description="Static analysis and design pattern review",
                default_enabled=True,
            ),
            QualityDimension(
                id="testing_coverage",
                display_name="Test Coverage",
                description="Test gap detection and coverage analysis",
                default_enabled=True,
            ),
            QualityDimension(
                id="security_sweep",
                display_name="Security",
                description="Vulnerability scanning and OWASP checks",
                default_enabled=False,
            ),
            QualityDimension(
                id="docs_analysis",
                display_name="Documentation",
                description="Documentation quality and completeness analysis",
                default_enabled=False,
            ),
        ]

    @lru_cache(maxsize=1)  # noqa: B019 - singleton domain, no memory leak concern
    def _load_prompts(self) -> dict[str, str]:
        """Load quality prompts from prompt files."""
        files = importlib.resources.files("obra.domains.software.prompts")
        prompts = {}
        prompt_names = [
            "code_quality",
            "testing_coverage",
            "docs_analysis",
            "security_sweep",
            "security_deep",
        ]
        for name in prompt_names:
            prompts[name] = (files / f"{name}.txt").read_text()
        return prompts

    def get_file_filters(self) -> FileFilterConfig:
        """Return file exclusion/inclusion patterns for software projects.

        Returns:
            FileFilterConfig with software-specific exclusion rules
        """
        return FileFilterConfig(
            excluded_files=EXCLUDED_FILES,
            excluded_patterns=EXCLUDED_PATTERNS,
            binary_extensions=BINARY_EXTENSIONS,
            ignore_dirs=IGNORE_DIRS,
            ignore_dir_suffixes=IGNORE_DIR_SUFFIXES,
        )

    def get_derivation_keywords(self) -> dict[str, list[str]]:
        """Return keywords for work type detection.

        Returns:
            Dictionary mapping work type ID to list of detection keywords
        """
        return WORK_TYPE_KEYWORDS

    def get_sizing_guidance(self) -> str:
        """Return sizing guidance text for software development.

        Returns:
            Markdown-formatted sizing guidance
        """
        return SIZING_GUIDANCE

    def get_lifecycle_policy(self) -> DomainLifecyclePolicy:
        """Return workflow-lifecycle defaults for software projects."""
        return DomainLifecyclePolicy(
            capability_states={
                DERIVE_CAPABILITY: ACTIVE_STATE,
                EXECUTE_CAPABILITY: ACTIVE_STATE,
                STORY0_CAPABILITY: COMPATIBILITY_PATH_STATE,
                PREFLIGHT_CAPABILITY: ACTIVE_STATE,
                REVIEW_CAPABILITY: COMPATIBILITY_PATH_STATE,
                WAIT_RESUME_CAPABILITY: ACTIVE_STATE,
                GIT_REQUIRED_CAPABILITY: ACTIVE_STATE,
                TOOLING_VERIFICATION_CAPABILITY: ACTIVE_STATE,
            }
        )

    def get_capabilities(self) -> DomainCapabilities:
        """Return stage-gating capabilities for software workflows."""
        return DomainCapabilities(
            spike_first_applicable=True,
            scaffolded_enrichment_applicable=True,
            intent_alignment_applicable=True,
            test_generation_supported=True,
            test_execution_supported=True,
            test_writer_supported=True,
            review_agents_supported=True,
            requires_git=True,
        )

    def supports(self, capability: Capability) -> bool:
        """Return whether software workflows support one capability."""
        return self.get_capabilities().supports(capability)

    def get_planning_constraints(self) -> DomainPlanningConstraints:
        """Return planning constraints for software workflows."""
        return DomainPlanningConstraints(default_work_type="general")

    def get_vocabulary(self) -> DomainVocabulary:
        """Return user-facing vocabulary labels for software workflows."""
        return DomainVocabulary(
            phase_labels={
                "intent": "Intent",
                "spike": "Spike",
                "derive": "Plan",
                "execute": "Implementation",
                "review": "Review",
                "USERPLAN_GENERATION": "plan — generating the user plan",
                "SPIKE": "spike — exploring implementation risk",
                "DERIVATION": "derive — detailing the execution plan",
                "REFINEMENT": "revise — refining the plan",
                "REVIEW": "review — preparing review agents",
                "EXECUTION": "execute — implementing plan items",
            },
            work_type_labels={
                "feature": "Feature",
                "bug_fix": "Bug Fix",
                "refactor": "Refactor",
            },
            quality_dimension_labels={
                "code_quality": "Code Quality",
                "security": "Security",
                "testing": "Testing",
                "docs": "Documentation",
            },
            pipeline_stage_labels={
                "intent_generation": "intent_generation — elaborating your request",
                "assumptions": "assumptions — resolving missing details",
                "analogues": "analogues — scanning similar solutions",
                "brief": "brief — consolidating intent into a planning brief",
                "spike": "spike — exploring implementation risk",
                "derive": "derive — detailing the execution plan",
                "revise": "revise — refining the plan",
                "intent_alignment": "intent_alignment — checking intent coverage",
                "review": "review — running review agents",
                "execute": "execute — implementing plan items",
                "validator": "validator — validating review output",
            },
            pipeline_definition=[
                VocabularyPipelineStage("Enrich", ["assumptions", "analogues", "brief"]),
                VocabularyPipelineStage("Plan", ["derive", "examine", "revise"]),
                VocabularyPipelineStage("Setup", ["dependencies", "prerequisites"]),
                VocabularyPipelineStage("Execute"),
                VocabularyPipelineStage("Review"),
                VocabularyPipelineStage("Fix"),
            ],
            stage_to_pipeline={
                "assumptions": "Enrich",
                "analogues": "Enrich",
                "brief": "Enrich",
                "derive": "Plan",
                "examine": "Plan",
                "revise": "Plan",
                "dependencies": "Setup",
                "prerequisites": "Setup",
                "execute": "Execute",
                "review": "Review",
                "fix": "Fix",
            },
            phase_to_pipeline={
                "USERPLAN_GENERATION": "Enrich",
                "REFINEMENT": "Plan",
                "STORY0": "Setup",
                "EXECUTION": "Execute",
                "REVIEW": "Review",
            },
            lanes=[
                VocabularyLane("intake", "Intake", ["intake"]),
                VocabularyLane("docs", "Docs and analysis", ["document"]),
                VocabularyLane("automation", "Implementation", ["automation"]),
                VocabularyLane("review", "Review and quality", ["review", "quality"]),
                VocabularyLane("approval", "Approval", ["approval"]),
                VocabularyLane("delivery", "Release", ["delivery"]),
            ],
            domain_help_copy=DomainHelpCopy(
                title="Software Development",
                description=self.description,
                lifecycle_heading="Software delivery lifecycle",
                lifecycle_steps=[
                    "Understand the existing code and constraints.",
                    "Plan the implementation and verification path.",
                    "Implement, review, fix, and verify the change.",
                ],
                example_invocations=[
                    f'obra run --domain software "{example}"'
                    for example in self.example_objectives[:3]
                ],
            ),
        )

    def get_stage_llm_tiering(self, plan_context: dict[str, Any]) -> dict[str, Any]:
        """Return neutral stage-type LLM defaults for software workflows."""
        return {}

    def get_plan_export_handler(self) -> Callable[..., None] | None:
        """Return no plan-export refresh handler for software workflows."""
        return None

    def execute_pipeline_stage(self, request: Any) -> None:
        """Return no domain-owned pipeline-stage result for software workflows."""
        return None

    def get_closeout_validator(self) -> None:
        """Return no domain-specific closeout validator for software workflows."""
        return None

    def get_runner_catalog_entries(self) -> list[dict[str, Any]]:
        """Return catalog-backed runner declarations for the software domain.

        This is a static seed covering common ecosystems. At runtime,
        ToolingDiscovery reads the actual project manifests (via LLM) and
        returns the correct tools for the detected language — those results
        take precedence over catalog entries. This catalog serves as a
        fallback and for tooling that doesn't need discovery (e.g., CI).

        Language tags on each entry enable filtering by detected project
        language. Adding entries here does NOT bias tool selection — the
        orchestrator matches tags against the discovered language.
        """
        base = {
            "kind": "command_runner",
            "version": "1.0.0",
            "scope": "domain",
            "domain_ids": ["software"],
            "portability": "portable",
            "compatibility": {"catalog_api_version": "1"},
            "source": {"source_type": "obra_builtin", "package": "obra"},
        }
        return [
            # Python
            {**base, "id": "software.test.pytest", "display_name": "Pytest Runner",
             "activation": {"command": ["pytest", "--tb=short", "-q"]},
             "description": "Run pytest test suite", "tags": ["software", "testing", "python", "pytest"]},
            {**base, "id": "software.lint.ruff", "display_name": "Ruff Linter",
             "activation": {"command": ["ruff", "check"]},
             "description": "Run ruff linter", "tags": ["software", "linting", "python", "ruff"]},
            # JavaScript / TypeScript
            {**base, "id": "software.test.jest", "display_name": "Jest Runner",
             "activation": {"command": ["npx", "jest"]},
             "description": "Run Jest test suite", "tags": ["software", "testing", "javascript", "jest"]},
            {**base, "id": "software.test.vitest", "display_name": "Vitest Runner",
             "activation": {"command": ["npx", "vitest", "run"]},
             "description": "Run Vitest test suite", "tags": ["software", "testing", "typescript", "vitest"]},
            {**base, "id": "software.lint.eslint", "display_name": "ESLint Linter",
             "activation": {"command": ["npx", "eslint", "."]},
             "description": "Run ESLint linter", "tags": ["software", "linting", "javascript", "eslint"]},
            # Go
            {**base, "id": "software.test.gotest", "display_name": "Go Test Runner",
             "activation": {"command": ["go", "test", "./..."]},
             "description": "Run Go tests", "tags": ["software", "testing", "go"]},
            {**base, "id": "software.lint.golangci", "display_name": "golangci-lint",
             "activation": {"command": ["golangci-lint", "run"]},
             "description": "Run golangci-lint", "tags": ["software", "linting", "go"]},
            # Rust
            {**base, "id": "software.test.cargo", "display_name": "Cargo Test Runner",
             "activation": {"command": ["cargo", "test"]},
             "description": "Run Cargo tests", "tags": ["software", "testing", "rust"]},
            {**base, "id": "software.lint.clippy", "display_name": "Clippy Linter",
             "activation": {"command": ["cargo", "clippy"]},
             "description": "Run Clippy linter", "tags": ["software", "linting", "rust"]},
        ]


def build_code_quality_prompt() -> str:
    """Return software domain code-quality prompt."""
    return SoftwareDomain().get_quality_prompts()["code_quality"]


def build_testing_coverage_prompt() -> str:
    """Return software domain testing-coverage prompt."""
    return SoftwareDomain().get_quality_prompts()["testing_coverage"]


def build_docs_analysis_prompt() -> str:
    """Return software domain docs-analysis prompt."""
    return SoftwareDomain().get_quality_prompts()["docs_analysis"]


def build_security_sweep_prompt() -> str:
    """Return software domain fast security prompt."""
    return SoftwareDomain().get_quality_prompts()["security_sweep"]


def build_security_deep_prompt() -> str:
    """Return software domain deep security prompt."""
    return SoftwareDomain().get_quality_prompts()["security_deep"]
