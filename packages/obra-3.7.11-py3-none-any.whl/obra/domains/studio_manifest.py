"""Canonical owner for Studio-only domain chrome, taxonomy, starters, and intent navigation."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from obra.domains.loader import get_available_domains, load_domain

_MANIFEST_PATH = Path(__file__).resolve().parents[1] / ".." / "config" / "workflow_studio_domain_manifest.json"
_STARTER_CATALOG_PATH = Path(__file__).resolve().parents[1] / ".." / "config" / "workflow_studio_starter_catalog.json"


def _load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def normalize_studio_domain_id(domain_id: str | None) -> str:
    normalized = str(domain_id or "").strip().lower()
    if normalized in {"", "neutral"}:
        return "neutral"
    if normalized in {"business", "obra_business"}:
        return "business"
    if normalized in {"software", "obra_software"}:
        return "software"
    return normalized or "neutral"


def _starter_catalog() -> dict[str, list[dict[str, Any]]]:
    payload = _load_json(_STARTER_CATALOG_PATH)
    domains = payload.get("domains")
    return domains if isinstance(domains, dict) else {}


def _runtime_metadata(domain_id: str) -> dict[str, Any]:
    if domain_id == "neutral":
        return {
            "name": "neutral",
            "display_name": "General",
            "description": "General workflow studio domain.",
            "example_objectives": [],
            "requires_git": False,
            "default_sandbox_policy": "workspace_write",
        }
    domain = load_domain(domain_id)
    return {
        "name": domain.name,
        "display_name": domain.display_name,
        "description": domain.description,
        "example_objectives": list(domain.example_objectives),
        "requires_git": domain.requires_git,
        "default_sandbox_policy": domain.default_sandbox_policy,
    }


def load_studio_manifest(domain_id: str | None) -> dict[str, Any]:
    payload = _load_json(_MANIFEST_PATH)
    domains = payload.get("domains") or {}
    domain_options = payload.get("domain_options") or []
    normalized = normalize_studio_domain_id(domain_id)
    raw = domains.get(normalized) or domains.get("neutral")
    if not isinstance(raw, dict):
        raise ValueError(f"Studio domain manifest not found: {domain_id}")
    runtime = _runtime_metadata(normalized)
    starters_domain = str(raw.get("starters_domain") or normalized)
    starters = _starter_catalog().get(starters_domain, [])
    return {
        "id": normalized,
        "normalized_domain_id": normalized,
        **runtime,
        "brand_subtitle": str(raw.get("brand_subtitle") or runtime["display_name"]),
        "chrome": raw.get("chrome") or {},
        "domain_options": domain_options,
        "taxonomy": raw.get("taxonomy") or {},
        "starters": starters,
        "navigation": raw.get("navigation") or {},
        "aliases": list(raw.get("aliases") or []),
    }


def list_studio_manifests() -> list[dict[str, Any]]:
    payload = _load_json(_MANIFEST_PATH)
    domain_order = ["neutral", *sorted(get_available_domains())]
    manifests: list[dict[str, Any]] = []
    seen: set[str] = set()
    for domain_id in domain_order:
        normalized = normalize_studio_domain_id(domain_id)
        if normalized in seen:
            continue
        manifests.append(load_studio_manifest(normalized))
        seen.add(normalized)
    return manifests
