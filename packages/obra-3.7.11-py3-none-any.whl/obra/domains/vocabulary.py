"""Domain vocabulary labels for client-side presentation surfaces."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True, slots=True)
class VocabularyPipelineStage:
    """Presentation definition for one pipeline stage."""

    name: str
    substages: list[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> "VocabularyPipelineStage | None":
        """Build a pipeline-stage definition from a JSON-safe mapping."""
        if not isinstance(data, dict):
            return None
        name = str(data.get("name") or "").strip()
        if not name:
            return None
        substages = data.get("substages", [])
        return cls(
            name=name,
            substages=[str(item) for item in substages] if isinstance(substages, list) else [],
        )

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-safe payload."""
        return {"name": self.name, "substages": list(self.substages)}


@dataclass(frozen=True, slots=True)
class VocabularyLane:
    """Studio lane presentation published by a domain."""

    lane_id: str
    title: str
    categories: list[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> "VocabularyLane | None":
        """Build a lane definition from a JSON-safe mapping."""
        if not isinstance(data, dict):
            return None
        lane_id = str(data.get("lane_id") or data.get("laneId") or "").strip()
        title = str(data.get("title") or "").strip()
        if not lane_id or not title:
            return None
        categories = data.get("categories", [])
        return cls(
            lane_id=lane_id,
            title=title,
            categories=[str(item) for item in categories] if isinstance(categories, list) else [],
        )

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-safe payload."""
        return {
            "laneId": self.lane_id,
            "title": self.title,
            "categories": list(self.categories),
        }


@dataclass(frozen=True, slots=True)
class DomainHelpCopy:
    """Domain-owned help text for CLI and documentation surfaces."""

    title: str = ""
    description: str = ""
    lifecycle_heading: str = ""
    lifecycle_steps: list[str] = field(default_factory=list)
    example_invocations: list[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> "DomainHelpCopy | None":
        """Build help copy from a JSON-safe mapping."""
        if not isinstance(data, dict):
            return None
        lifecycle_steps = data.get("lifecycle_steps", [])
        example_invocations = data.get("example_invocations", [])
        return cls(
            title=str(data.get("title") or ""),
            description=str(data.get("description") or ""),
            lifecycle_heading=str(data.get("lifecycle_heading") or ""),
            lifecycle_steps=(
                [str(item) for item in lifecycle_steps]
                if isinstance(lifecycle_steps, list)
                else []
            ),
            example_invocations=(
                [str(item) for item in example_invocations]
                if isinstance(example_invocations, list)
                else []
            ),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-safe payload."""
        return {
            "title": self.title,
            "description": self.description,
            "lifecycle_heading": self.lifecycle_heading,
            "lifecycle_steps": list(self.lifecycle_steps),
            "example_invocations": list(self.example_invocations),
        }


@dataclass(frozen=True, slots=True)
class DomainVocabulary:
    """Optional user-facing labels and presentation structures.

    Domain authors own labels, pipeline presentation, Studio lane metadata,
    and CLI help copy here so framework/UI layers do not hardcode software
    vocabulary.
    """

    phase_labels: dict[str, str] = field(default_factory=dict)
    work_type_labels: dict[str, str] = field(default_factory=dict)
    quality_dimension_labels: dict[str, str] = field(default_factory=dict)
    pipeline_stage_labels: dict[str, str] = field(default_factory=dict)
    pipeline_definition: list[VocabularyPipelineStage] = field(default_factory=list)
    stage_to_pipeline: dict[str, str] = field(default_factory=dict)
    phase_to_pipeline: dict[str, str] = field(default_factory=dict)
    lanes: list[VocabularyLane] = field(default_factory=list)
    domain_help_copy: DomainHelpCopy | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> "DomainVocabulary":
        """Build vocabulary labels from a JSON-safe mapping."""
        if not isinstance(data, dict):
            return cls()
        return cls(
            phase_labels=_string_dict(data.get("phase_labels")),
            work_type_labels=_string_dict(data.get("work_type_labels")),
            quality_dimension_labels=_string_dict(data.get("quality_dimension_labels")),
            pipeline_stage_labels=_string_dict(data.get("pipeline_stage_labels")),
            pipeline_definition=_pipeline_definition(data.get("pipeline_definition")),
            stage_to_pipeline=_string_dict(data.get("stage_to_pipeline")),
            phase_to_pipeline=_string_dict(data.get("phase_to_pipeline")),
            lanes=_lanes(data.get("lanes")),
            domain_help_copy=DomainHelpCopy.from_dict(data.get("domain_help_copy")),
        )

    def get(
        self,
        key: str,
        dimension: str = "phase",
        default: str | None = None,
    ) -> str | None:
        """Return a label for one dimension, or default when absent."""
        tables = {
            "phase": self.phase_labels,
            "work_type": self.work_type_labels,
            "quality_dimension": self.quality_dimension_labels,
            "pipeline_stage": self.pipeline_stage_labels,
        }
        try:
            table = tables[dimension]
        except KeyError as exc:
            raise ValueError(f"Unknown vocabulary dimension: {dimension!r}") from exc
        return table.get(key, default)

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-safe payload."""
        return {
            "phase_labels": dict(self.phase_labels),
            "work_type_labels": dict(self.work_type_labels),
            "quality_dimension_labels": dict(self.quality_dimension_labels),
            "pipeline_stage_labels": dict(self.pipeline_stage_labels),
            "pipeline_definition": [stage.to_dict() for stage in self.pipeline_definition],
            "stage_to_pipeline": dict(self.stage_to_pipeline),
            "phase_to_pipeline": dict(self.phase_to_pipeline),
            "lanes": [lane.to_dict() for lane in self.lanes],
            "domain_help_copy": (
                self.domain_help_copy.to_dict()
                if self.domain_help_copy is not None
                else None
            ),
        }


def _string_dict(value: Any) -> dict[str, str]:
    if not isinstance(value, dict):
        return {}
    return {str(key): str(item) for key, item in value.items()}


def _pipeline_definition(value: Any) -> list[VocabularyPipelineStage]:
    if not isinstance(value, list):
        return []
    stages: list[VocabularyPipelineStage] = []
    for item in value:
        stage = VocabularyPipelineStage.from_dict(item if isinstance(item, dict) else None)
        if stage is not None:
            stages.append(stage)
    return stages


def _lanes(value: Any) -> list[VocabularyLane]:
    if not isinstance(value, list):
        return []
    lanes: list[VocabularyLane] = []
    for item in value:
        lane = VocabularyLane.from_dict(item if isinstance(item, dict) else None)
        if lane is not None:
            lanes.append(lane)
    return lanes


__all__ = [
    "DomainHelpCopy",
    "DomainVocabulary",
    "VocabularyLane",
    "VocabularyPipelineStage",
]
