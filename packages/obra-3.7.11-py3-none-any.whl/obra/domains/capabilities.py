"""Domain capability surface for client-side orchestration.

ADR-104 replaces the former derivation-default workaround booleans with an
explicit capability model. R6 consumes this surface for gate reshaping; this
module only publishes the stable protocol objects.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any


class Capability(Enum):
    """Named domain capabilities used by orchestration gates."""

    SPIKE_FIRST = "spike_first_applicable"
    SCAFFOLDED_ENRICHMENT = "scaffolded_enrichment_applicable"
    INTENT_ALIGNMENT = "intent_alignment_applicable"
    TEST_GENERATION = "test_generation_supported"
    TEST_EXECUTION = "test_execution_supported"
    TEST_WRITER = "test_writer_supported"
    REVIEW_AGENTS = "review_agents_supported"
    GIT_REQUIRED = "requires_git"


@dataclass(frozen=True, slots=True)
class DomainCapabilities:
    """Stage and environment capabilities published by a domain."""

    spike_first_applicable: bool = False
    scaffolded_enrichment_applicable: bool = False
    intent_alignment_applicable: bool = False
    test_generation_supported: bool = False
    test_execution_supported: bool = False
    test_writer_supported: bool = False
    review_agents_supported: bool = False
    requires_git: bool = True

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> "DomainCapabilities":
        """Build capabilities from a JSON-safe mapping."""
        if not isinstance(data, dict):
            return cls()
        defaults = cls()
        return cls(
            spike_first_applicable=bool(
                data.get(
                    "spike_first_applicable",
                    defaults.spike_first_applicable,
                )
            ),
            scaffolded_enrichment_applicable=bool(
                data.get(
                    "scaffolded_enrichment_applicable",
                    defaults.scaffolded_enrichment_applicable,
                )
            ),
            intent_alignment_applicable=bool(
                data.get(
                    "intent_alignment_applicable",
                    defaults.intent_alignment_applicable,
                )
            ),
            test_generation_supported=bool(
                data.get(
                    "test_generation_supported",
                    defaults.test_generation_supported,
                )
            ),
            test_execution_supported=bool(
                data.get(
                    "test_execution_supported",
                    defaults.test_execution_supported,
                )
            ),
            test_writer_supported=bool(
                data.get(
                    "test_writer_supported",
                    defaults.test_writer_supported,
                )
            ),
            review_agents_supported=bool(
                data.get("review_agents_supported", defaults.review_agents_supported)
            ),
            requires_git=bool(data.get("requires_git", defaults.requires_git)),
        )

    def to_dict(self) -> dict[str, bool]:
        """Return a JSON-safe capability payload."""
        return {
            "spike_first_applicable": self.spike_first_applicable,
            "scaffolded_enrichment_applicable": self.scaffolded_enrichment_applicable,
            "intent_alignment_applicable": self.intent_alignment_applicable,
            "test_generation_supported": self.test_generation_supported,
            "test_execution_supported": self.test_execution_supported,
            "test_writer_supported": self.test_writer_supported,
            "review_agents_supported": self.review_agents_supported,
            "requires_git": self.requires_git,
        }

    def supports(self, capability: Capability) -> bool:
        """Return whether this domain supports one named capability."""
        if not isinstance(capability, Capability):
            raise KeyError(capability)
        return bool(getattr(self, capability.value))


__all__ = ["Capability", "DomainCapabilities"]
