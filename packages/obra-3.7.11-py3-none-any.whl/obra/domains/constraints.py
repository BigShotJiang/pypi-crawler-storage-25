"""Domain planning constraints for client-side orchestration."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True, slots=True)
class DomainPlanningConstraints:
    """Planning defaults and limits published by a domain."""

    default_work_type: str = "general"
    default_plan_depth: str = "standard"

    def __post_init__(self) -> None:
        normalized_work_type = str(self.default_work_type or "general").strip() or "general"
        if normalized_work_type != self.default_work_type:
            object.__setattr__(self, "default_work_type", normalized_work_type)

        normalized_depth = str(self.default_plan_depth or "standard").strip() or "standard"
        if normalized_depth != self.default_plan_depth:
            object.__setattr__(self, "default_plan_depth", normalized_depth)

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> "DomainPlanningConstraints":
        """Build constraints from a JSON-safe mapping."""
        if not isinstance(data, dict):
            return cls()
        return cls(
            default_work_type=str(data.get("default_work_type") or "general"),
            default_plan_depth=str(data.get("default_plan_depth") or "standard"),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-safe payload."""
        return {
            "default_work_type": self.default_work_type,
            "default_plan_depth": self.default_plan_depth,
        }


__all__ = ["DomainPlanningConstraints"]
