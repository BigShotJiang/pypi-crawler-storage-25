"""Domain-owned closeout validation hooks."""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class CloseoutValidator(Protocol):
    """Validate or enrich closeout context for one domain."""

    def validate(self, context: Any) -> list[str]:
        """Return validation issue messages for the closeout context."""
        ...


__all__ = ["CloseoutValidator"]
