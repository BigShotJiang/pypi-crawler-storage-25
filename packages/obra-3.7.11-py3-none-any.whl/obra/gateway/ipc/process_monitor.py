"""Monitor subprocess-backed gateway sessions and mirror events into the event bus."""

from __future__ import annotations

import asyncio
import logging
import subprocess
from typing import Any

from obra.api.protocol import CompletionNotice, EscalationNotice
from obra.config.loaders import get_timeout

logger = logging.getLogger(__name__)


async def _terminate_process(proc: subprocess.Popen[Any], timeout_s: float) -> None:
    if proc.poll() is not None:
        return
    proc.terminate()
    try:
        await asyncio.to_thread(proc.wait, timeout=timeout_s)
    except subprocess.TimeoutExpired:
        proc.kill()
        await asyncio.to_thread(proc.wait, timeout=timeout_s)


def _hybrid_session_id_from_event(event: dict[str, Any]) -> str | None:
    value = event.get("hybrid_session_id")
    if isinstance(value, str) and value:
        return str(value)
    return None


def _emit_cancelled_outcome(session_manager: Any, record: Any, session_id: str) -> None:
    session_manager._finalize_session_outcome(
        record,
        session_id,
        "cancelled",
        event_session_ref=session_id,
        log_message="Session %s cancelled via process monitor",
    )


def _emit_exit_without_event_outcome(
    session_manager: Any,
    record: Any,
    session_id: str,
    exit_code: int | None,
) -> None:
    if exit_code in (None, 0):
        session_manager._finalize_session_outcome(
            record,
            session_id,
            "failed",
            error_name_override="SessionWorkerProtocolError",
            extra_events=[
                (
                    "session_error",
                    {
                        "session_id": session_id,
                        "error": "SessionWorkerProtocolError",
                        "message": "Worker exited without terminal event",
                    },
                )
            ],
            log_message="Session %s worker exited without terminal event",
        )
    else:
        session_manager._finalize_session_outcome(
            record,
            session_id,
            "failed",
            error_name_override="SessionWorkerProcessError",
            extra_events=[
                (
                    "session_error",
                    {
                        "session_id": session_id,
                        "error": "SessionWorkerProcessError",
                        "exit_code": exit_code,
                    },
                )
            ],
            log_message="Session %s worker exited with a non-zero status",
        )


async def _await_next_event(
    ipc_server: Any, cancel_event: Any
) -> tuple[bool, dict[str, Any] | None]:
    """Wait for the next IPC event or cancel. Returns (cancelled, event_or_None)."""
    read_task = asyncio.create_task(ipc_server.read_event())
    cancel_task = asyncio.create_task(asyncio.to_thread(cancel_event.wait))
    done, pending = await asyncio.wait(
        {read_task, cancel_task},
        return_when=asyncio.FIRST_COMPLETED,
    )
    for task in pending:
        task.cancel()
    if cancel_task in done and cancel_task.result():
        return True, None
    return False, read_task.result()


async def _handle_progress_event(
    session_manager: Any,
    record: Any,
    session_id: str,
    event: dict[str, Any],
) -> None:
    action = str(event.get("action") or "").strip()
    payload = dict(event.get("payload") or {})
    session_manager._update_record_from_progress(session_id, action, payload)
    if action in {"stage_completed", "stage_failed"}:
        session_manager._enrich_stage_progress_payload(session_id, action, payload)
    record.event_bus.push_event("progress", {"action": action, **payload})


def _handle_stream_event(record: Any, event: dict[str, Any]) -> None:
    record.event_bus.push_event(
        "stream",
        {
            "event_type": str(event.get("event_type") or ""),
            "content": event.get("content"),
        },
    )


async def _handle_escalation_event(
    ipc_server: Any, record: Any, event: dict[str, Any]
) -> None:
    notice = EscalationNotice.from_payload(dict(event.get("notice") or {}))
    decision = await asyncio.to_thread(record.event_bus.push_escalation, notice)
    ipc_server.write_event(
        {
            "type": "escalation_response",
            "choice": decision.choice.value,
        }
    )


def _handle_completed_event(
    session_manager: Any, record: Any, session_id: str, event: dict[str, Any]
) -> None:
    session_manager._sync_hybrid_session_id(
        session_id,
        _hybrid_session_id_from_event(event),
    )
    summary = str(event.get("summary") or "")
    session_manager._finalize_session_completion(
        record,
        session_id,
        summary=summary,
        completion_notice=CompletionNotice(session_summary=summary),
        event_session_ref=session_id,
    )


def _handle_failed_event(
    session_manager: Any, record: Any, session_id: str, event: dict[str, Any]
) -> None:
    session_manager._sync_hybrid_session_id(
        session_id,
        _hybrid_session_id_from_event(event),
    )
    error_type = str(event.get("error_type") or "SessionWorkerError")
    error_message = str(event.get("error") or "")
    session_manager._finalize_session_outcome(
        record,
        session_id,
        "failed",
        error_name_override=error_type,
        extra_events=[
            (
                "session_error",
                {
                    "session_id": session_id,
                    "error": error_type,
                    "message": error_message,
                },
            )
        ],
        log_message="Session %s failed in worker",
    )


async def _process_worker_event(
    ipc_server: Any,
    session_manager: Any,
    session_id: str,
    record: Any,
    event: dict[str, Any],
) -> bool:
    """Dispatch one worker event. Returns True if this event terminated the session."""
    event_type = str(event.get("type") or "").strip().lower()
    if event_type == "progress":
        await _handle_progress_event(session_manager, record, session_id, event)
        return False
    if event_type == "stream":
        _handle_stream_event(record, event)
        return False
    if event_type == "escalation":
        await _handle_escalation_event(ipc_server, record, event)
        return False
    if event_type == "completed":
        _handle_completed_event(session_manager, record, session_id, event)
        return True
    if event_type == "failed":
        _handle_failed_event(session_manager, record, session_id, event)
        return True
    logger.warning(
        "Ignoring unknown session worker event %r for %s", event_type, session_id
    )
    return False


async def monitor_session_process(
    proc: subprocess.Popen[Any],
    ipc_server: Any,
    session_manager: Any,
    session_id: str,
    record: Any,
    cancel_event: Any,
    socket_connect_timeout_s: float,
) -> None:
    """Mirror worker IPC events into the existing SessionManager surfaces."""
    terminal_emitted = False
    process_wait_timeout_s = float(get_timeout("subprocess_runner", "process_wait_s"))
    try:
        await ipc_server.wait_for_connection(timeout_s=socket_connect_timeout_s)
        while True:
            cancelled, event = await _await_next_event(ipc_server, cancel_event)
            if cancelled:
                await _terminate_process(proc, timeout_s=process_wait_timeout_s)
                if not terminal_emitted:
                    _emit_cancelled_outcome(session_manager, record, session_id)
                    terminal_emitted = True
                break

            if event is None:
                if cancel_event.is_set():
                    await _terminate_process(proc, timeout_s=process_wait_timeout_s)
                    if not terminal_emitted:
                        _emit_cancelled_outcome(session_manager, record, session_id)
                        terminal_emitted = True
                    break
                exit_code = proc.poll()
                if not terminal_emitted:
                    _emit_exit_without_event_outcome(
                        session_manager, record, session_id, exit_code
                    )
                break

            if await _process_worker_event(
                ipc_server, session_manager, session_id, record, event
            ):
                terminal_emitted = True
                break
    except TimeoutError:
        session_manager._finalize_session_outcome(
            record,
            session_id,
            "failed",
            error_name_override="SessionWorkerConnectionTimeout",
            extra_events=[
                (
                    "session_error",
                    {
                        "session_id": session_id,
                        "error": "SessionWorkerConnectionTimeout",
                    },
                )
            ],
            log_message="Session %s worker failed to connect to the IPC socket",
        )
    except Exception:
        if not terminal_emitted:
            session_manager._finalize_session_outcome(
                record,
                session_id,
                "failed",
                error_name_override="SessionWorkerMonitorError",
                extra_events=[
                    (
                        "session_error",
                        {
                            "session_id": session_id,
                            "error": "SessionWorkerMonitorError",
                        },
                    )
                ],
                log_message="Session %s process monitor failed",
            )
    finally:
        session_manager._cleanup_process_artifacts(record)
        try:
            ipc_server.close()
        except Exception:
            logger.debug("Failed to close IPC server for session %s", session_id, exc_info=True)
