"""Summarize pending assistant proposal records for launch gating."""

from __future__ import annotations

from collections.abc import Iterable
from typing import Any, Mapping

from obra.gateway.workflow_studio.assistant_runnability_gate import (
    PendingAssistantProposalSummary,
)
from obra.workflow.stage_instruction_assets import (
    PRIMARY_STAGE_INSTRUCTION_ROLE,
    canonicalize_template_role,
)


def summarize_pending_assistant_proposals(
    turns: Iterable[Any],
    workflow_id: str | None = None,
) -> PendingAssistantProposalSummary:
    """Return compact counts for pending template proposals in assistant turns."""
    normalized_workflow_id = str(workflow_id or "").strip()
    pending_count = 0
    pending_template_count = 0
    pending_stage_instruction_count = 0
    pending_action_ids: list[str] = []
    proposal_groups: list[str] = []

    for record in _iter_pending_records(turns):
        if normalized_workflow_id and not _record_matches_workflow(record, normalized_workflow_id):
            continue
        action_id = str(record.get("action_id") or "").strip()
        template_roles = _template_roles_for_record(record)
        if not template_roles:
            continue
        pending_count += 1
        pending_template_count += 1
        if any(canonicalize_template_role(role) == PRIMARY_STAGE_INSTRUCTION_ROLE for role in template_roles):
            pending_stage_instruction_count += 1
        if action_id:
            pending_action_ids.append(action_id)
        group = str(record.get("proposal_group") or "").strip()
        if group and group not in proposal_groups:
            proposal_groups.append(group)

    return PendingAssistantProposalSummary(
        pending_count=pending_count,
        pending_template_count=pending_template_count,
        pending_stage_instruction_count=pending_stage_instruction_count,
        pending_action_ids=pending_action_ids,
        proposal_groups=proposal_groups,
    )


def _iter_pending_records(turns: Iterable[Any]) -> Iterable[Mapping[str, Any]]:
    for turn in turns:
        records = (
            turn.get("action_records")
            if isinstance(turn, Mapping)
            else getattr(turn, "action_records", None)
        )
        if not isinstance(records, list):
            continue
        for record in records:
            if (
                isinstance(record, Mapping)
                and str(record.get("status") or "").strip() == "pending"
            ):
                yield record


def _record_matches_workflow(record: Mapping[str, Any], workflow_id: str) -> bool:
    candidates = [
        record.get("workflow_id"),
        _mapping_value(record.get("action_inputs"), "workflow_id"),
    ]
    if any(str(candidate or "").strip() == workflow_id for candidate in candidates):
        return True
    operations = _mapping_value(record.get("action_inputs"), "operations")
    if isinstance(operations, list):
        return any(
            isinstance(operation, Mapping)
            and str(operation.get("workflow_id") or "").strip() == workflow_id
            for operation in operations
        )
    return not any(str(candidate or "").strip() for candidate in candidates)


def _template_roles_for_record(record: Mapping[str, Any]) -> list[str]:
    action_id = str(record.get("action_id") or "").strip()
    action_inputs = record.get("action_inputs")
    if action_id == "execute_template_edit":
        role = _mapping_value(action_inputs, "template_role") or record.get("template_role")
        return [str(role or "purpose")]
    if action_id != "execute_batch_mutation":
        return []
    operations = _mapping_value(action_inputs, "operations")
    if not isinstance(operations, list):
        operations = record.get("operations")
    if not isinstance(operations, list):
        return []
    roles: list[str] = []
    for operation in operations:
        if not isinstance(operation, Mapping):
            continue
        if str(operation.get("operation") or operation.get("op") or "").strip() != "edit_template":
            continue
        roles.append(str(operation.get("template_role") or "purpose"))
    return roles


def _mapping_value(value: Any, key: str) -> Any:
    return value.get(key) if isinstance(value, Mapping) else None
