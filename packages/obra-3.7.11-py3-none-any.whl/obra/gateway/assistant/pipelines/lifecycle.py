"""Pipeline lifecycle chat-turn helpers."""

from __future__ import annotations

from typing import Any, Callable, Literal

from obra.gateway.workflow_studio.assistant_session_logger import AssistantSessionLogger

PipelineOutcome = Literal["cancelled", "failed", "partial"]
TurnWriter = Callable[..., Any]

_EMITTED_OUTCOMES: set[tuple[str, str]] = set()


def clear_pipeline_outcome_dedupe() -> None:
    """Clear in-process pipeline outcome dedupe state for focused tests."""
    _EMITTED_OUTCOMES.clear()


def _reason_clause(reason: str | None) -> str:
    text = str(reason or "").strip()
    return f": {text}" if text else ""


def _message(pipeline_id: str, outcome: PipelineOutcome, reason: str | None) -> str:
    clause = _reason_clause(reason)
    if outcome == "cancelled":
        return f"The {pipeline_id} pipeline was cancelled{clause}."
    if outcome == "failed":
        return f"The {pipeline_id} pipeline failed{clause}."
    return f"The {pipeline_id} pipeline finished with partial results{clause}."


def _cta(
    pipeline_id: str,
    outcome: PipelineOutcome,
    workflow_id: str | None,
) -> dict[str, Any]:
    if outcome == "cancelled":
        suggested_inputs = (
            {"pipeline_id": pipeline_id, "workflow_id": workflow_id}
            if str(workflow_id or "").strip()
            else None
        )
        return {
            "intent": "retry_pipeline",
            "label": "Retry the pipeline",
            "rationale": "The pipeline was cancelled before it could finish.",
            "suggested_action_id": "propose_pipeline_execution" if suggested_inputs else None,
            "suggested_action_inputs": suggested_inputs,
        }
    if outcome == "partial":
        return {
            "intent": "skip_pipeline",
            "label": "Skip the pipeline for now",
            "rationale": "The pipeline produced partial results and may not need an immediate retry.",
            "suggested_action_id": None,
            "suggested_action_inputs": None,
        }
    return {
        "intent": "abandon_pipeline",
        "label": "Abandon the failed pipeline",
        "rationale": "The pipeline failed and needs inspection before another attempt.",
        "suggested_action_id": None,
        "suggested_action_inputs": None,
    }


def emit_pipeline_outcome_chat_turn(
    thread_id: str,
    pipeline_id: str,
    outcome: PipelineOutcome,
    reason: str | None,
    *,
    session_logger: AssistantSessionLogger | None,
    turn_writer: TurnWriter,
    workflow_id: str | None = None,
) -> dict[str, Any] | None:
    """Persist one assistant turn for a terminal pipeline outcome."""
    key = (str(thread_id), str(pipeline_id))
    if key in _EMITTED_OUTCOMES:
        return None
    _EMITTED_OUTCOMES.add(key)

    if session_logger is not None:
        session_logger.log_event(
            "asst.pipeline_outcome",
            thread_id=thread_id,
            pipeline_id=pipeline_id,
            outcome=outcome,
            reason=reason,
        )

    turn = turn_writer(
        thread_id,
        role="assistant",
        message=_message(pipeline_id, outcome, reason),
        outcome="advice",
        event_type="pipeline_outcome",
        event_title="Pipeline outcome",
        metadata={
            "pipeline_id": pipeline_id,
            "pipeline_status": outcome,
            "reason": reason,
        },
        recommended_next_cta=_cta(pipeline_id, outcome, workflow_id),
    )
    if hasattr(turn, "__dataclass_fields__"):
        from dataclasses import asdict

        return asdict(turn)
    if isinstance(turn, dict):
        return dict(turn)
    return None
