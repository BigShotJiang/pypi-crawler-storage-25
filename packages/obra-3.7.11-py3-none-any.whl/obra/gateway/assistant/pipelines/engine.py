"""Execution engine for assistant action pipelines."""

from __future__ import annotations

import asyncio
import inspect
import json
import time
from pathlib import Path
from typing import Any, AsyncIterator, Callable

from obra.gateway.assistant.pipelines.types import (
    PipelineDefinition,
    PipelineResult,
    PipelineStatus,
    PipelineTriggerSource,
    StepDefinition,
    StepResult,
)


class PipelineEngine:
    """Execute one registered assistant pipeline."""

    def __init__(
        self,
        pipeline_def: PipelineDefinition,
        workflow_context: dict[str, Any],
        llm_call: Any,
        timeout_s: int | None = None,
        *,
        thread_id: str | None = None,
        turn_id: str | None = None,
        working_dir: Path | None = None,
        llm_config: dict[str, Any] | None = None,
        log_event: Any = None,
        production_logger: Any | None = None,
        params: dict[str, Any] | None = None,
        on_progress: Callable[[str, dict[str, Any]], None] | None = None,
        per_step_timeout_budget_s: int = 3600,
    ) -> None:
        self.pipeline_def = pipeline_def
        self.workflow_context = workflow_context
        self.llm_call = llm_call
        self.thread_id = str(thread_id or "")
        self.turn_id = str(turn_id or "")
        base_timeout = int(timeout_s or pipeline_def.timeout_s)
        step_count = (
            len(pipeline_def.steps_factory(workflow_context))
            if pipeline_def.steps_factory
            else 0
        )
        # The pipeline timeout must never be stricter than the per-step LLM call
        # timeout.  Default aligns with orchestration.timeouts.llm_call_s (3600s).
        scaled_timeout = step_count * per_step_timeout_budget_s if step_count else 0
        self.timeout_s = max(base_timeout, scaled_timeout)
        self.working_dir = working_dir or Path.cwd()
        self.llm_config = dict(llm_config or {})
        self.log_event = log_event
        self.production_logger = production_logger
        self.params = dict(params or {})
        self._on_progress = on_progress
        self._cancelled = False
        self._step_handler = pipeline_def.step_executor
        self._pending_progress: list[dict[str, Any]] = []
        self._step_results: list[StepResult] = []
        self._result: PipelineResult | None = None

    @property
    def cancelled(self) -> bool:
        return self._cancelled

    @property
    def step_results(self) -> list[StepResult]:
        return list(self._step_results)

    @property
    def result(self) -> PipelineResult | None:
        return self._result

    def set_result(self, result: PipelineResult) -> None:
        """Persist the final pipeline result for route-level consumers."""
        self._result = result

    def set_step_handler(self, handler: Any) -> None:
        """Override the callable used for step execution."""
        self._step_handler = handler

    def cancel(self) -> None:
        """Request cancellation after the current step completes."""
        self._cancelled = True

    def emit_progress(
        self,
        step_id: str,
        message: str,
        detail: str | None = None,
        progress_pct: int | None = None,
    ) -> None:
        """Emit a buffered step-progress event via the Story0-style callback pattern.

        The callback signature is ``on_progress(event_type: str, payload: dict[str, Any]) -> None``.
        Events are buffered in ``_pending_progress`` and yielded between ``step_started`` and
        ``step_completed`` by ``execute_step_with_events``.

        Schema: ``{event: "step_progress", step_id: str, message: str, detail: str | None,
        progress_pct: int | None}``.
        """
        event = {
            "event": "step_progress",
            "step_id": step_id,
            "message": message,
            "detail": detail,
            "progress_pct": progress_pct,
        }
        self._pending_progress.append(event)
        if self._on_progress is not None:
            self._on_progress("step_progress", event)

    def predecessor_summaries(self) -> list[dict[str, Any]]:
        """Return the five most recent compact predecessor summaries."""
        summaries: list[dict[str, Any]] = []
        for result in self._step_results:
            if result.output is None:
                continue
            summary = json.dumps(result.output, sort_keys=True)[:200]
            summaries.append({"step_id": result.step_id, "summary": summary})
        return summaries[-5:]

    def get_step_result(self, step_id: str) -> StepResult | None:
        """Look up a stored step result by step id."""
        return next((result for result in self._step_results if result.step_id == step_id), None)

    def mark_pending_steps_skipped(self, steps: list[StepDefinition]) -> None:
        """Mark the provided steps as skipped if they have not run yet."""
        for step in steps:
            if self.get_step_result(step.step_id) is not None:
                continue
            self._upsert_step_result(
                StepResult(
                    step_id=step.step_id,
                    status="skipped",
                    output=None,
                    duration_ms=0,
                )
            )

    async def run(
        self,
        trigger_source: PipelineTriggerSource = "user_explicit",
    ) -> AsyncIterator[dict[str, Any]]:
        """Yield SSE-shaped events for the pipeline lifecycle."""
        if not self._trigger_source_allowed(trigger_source):
            yield {
                "event": "pipeline_error",
                "pipeline_id": self.pipeline_def.pipeline_id,
                "detail": (
                    f"Pipeline {self.pipeline_def.pipeline_id} does not allow "
                    f"trigger_source={trigger_source}"
                ),
            }
            return

        step_count = (
            len(self.pipeline_def.steps_factory(self.workflow_context))
            if self.pipeline_def.steps_factory
            else 0
        )
        yield {
            "event": "pipeline_started",
            "pipeline_id": self.pipeline_def.pipeline_id,
            "display_name": self.pipeline_def.display_name,
            "thread_id": self.thread_id,
            "turn_id": self.turn_id,
            "step_count": step_count,
            "pipeline_model": self._pipeline_model_metadata(),
        }

        try:
            async with asyncio.timeout(self.timeout_s):
                if self.pipeline_def.runner is not None:
                    async for event in self.pipeline_def.runner(self):
                        yield event
                else:
                    steps = (
                        self.pipeline_def.steps_factory(self.workflow_context)
                        if self.pipeline_def.steps_factory
                        else []
                    )
                    for step in steps:
                        for event in await self.execute_step_with_events(step):
                            yield event
                        if self._cancelled:
                            remaining = steps[steps.index(step) + 1 :]
                            self.mark_pending_steps_skipped(remaining)
                            break

                result = self._result or PipelineResult(
                    pipeline_id=self.pipeline_def.pipeline_id,
                    status=self._derive_default_status(),
                    step_results=self.step_results,
                    proposals=[],
                )
                self._result = result
                if result.status == "cancelled":
                    yield {
                        "event": "pipeline_cancelled",
                        "pipeline_id": result.pipeline_id,
                        "thread_id": self.thread_id,
                        "turn_id": self.turn_id,
                    }
                    return
                yield {
                    "event": "pipeline_done",
                    "pipeline_id": result.pipeline_id,
                    "status": result.status,
                    "proposal_count": len(result.proposals),
                }
        except TimeoutError:
            self._result = PipelineResult(
                pipeline_id=self.pipeline_def.pipeline_id,
                status="failed",
                step_results=self.step_results,
                proposals=[],
                summary_message=f"{self.pipeline_def.display_name} timed out.",
            )
            yield {
                "event": "pipeline_done",
                "pipeline_id": self.pipeline_def.pipeline_id,
                "status": "failed",
                "detail": f"Pipeline timed out after {self.timeout_s}s",
                "proposal_count": 0,
            }
        except Exception as exc:
            self._result = PipelineResult(
                pipeline_id=self.pipeline_def.pipeline_id,
                status="failed",
                step_results=self.step_results,
                proposals=[],
                summary_message=f"{self.pipeline_def.display_name} failed.",
            )
            yield {
                "event": "pipeline_done",
                "pipeline_id": self.pipeline_def.pipeline_id,
                "status": "failed",
                "detail": str(exc),
                "proposal_count": 0,
            }

    async def execute_step_with_events(
        self,
        step: StepDefinition,
        *,
        review_feedback: str | None = None,
    ) -> list[dict[str, Any]]:
        """Execute one step and return the started/completed events for it."""
        if self._cancelled:
            result = StepResult(
                step_id=step.step_id,
                status="skipped",
                output=None,
                duration_ms=0,
                review_feedback=review_feedback,
            )
            self._upsert_step_result(result)
            return []

        self._pending_progress.clear()
        events = [
            {
                "event": "step_started",
                "step_id": step.step_id,
                "description": step.description,
                "status": "reviewing" if review_feedback else "running",
            }
        ]
        started_at = time.perf_counter()
        try:
            result = await self._execute_step(
                step,
                self.predecessor_summaries(),
                review_feedback=review_feedback,
            )
        except Exception as exc:
            result = StepResult(
                step_id=step.step_id,
                status="failed",
                output={"detail": str(exc)},
                duration_ms=int((time.perf_counter() - started_at) * 1000),
                review_feedback=review_feedback,
            )
        self._upsert_step_result(result)
        events.extend(self._pending_progress)
        self._pending_progress.clear()
        events.append(
            {
                "event": "step_completed",
                "step_id": result.step_id,
                "status": result.status,
                "duration_ms": result.duration_ms,
                "output": result.output,
            }
        )
        return events

    async def _execute_step(
        self,
        step: StepDefinition,
        predecessors: list[dict[str, Any]],
        *,
        review_feedback: str | None = None,
    ) -> StepResult:
        if self._step_handler is None:
            raise RuntimeError(
                f"Pipeline {self.pipeline_def.pipeline_id} does not have a step handler"
            )

        started_at = time.perf_counter()
        response = self._step_handler(step, self.workflow_context, predecessors, review_feedback)
        if inspect.isawaitable(response):
            response = await response
        if not isinstance(response, dict):
            raise ValueError("Pipeline step handler must return a dict payload")
        return StepResult(
            step_id=step.step_id,
            status="completed",
            output=response,
            duration_ms=int((time.perf_counter() - started_at) * 1000),
            review_feedback=review_feedback,
        )

    def _trigger_source_allowed(self, trigger_source: PipelineTriggerSource) -> bool:
        if self.pipeline_def.trigger_mode == "auto":
            return True
        if self.pipeline_def.trigger_mode == "semi_auto":
            return trigger_source in {"llm_proposed", "user_explicit"}
        return trigger_source == "user_explicit"

    def _pipeline_model_metadata(self) -> dict[str, str]:
        """Return user-facing model metadata for progress displays."""
        fields = {
            "provider": self.llm_config.get("provider"),
            "model": self.llm_config.get("model"),
            "model_tier": self.llm_config.get("model_tier"),
            "reasoning_level": self.llm_config.get("reasoning_level"),
        }
        return {
            key: str(value).strip()
            for key, value in fields.items()
            if str(value or "").strip()
        }

    def _derive_default_status(self) -> PipelineStatus:
        if self._cancelled:
            return "cancelled"
        if any(result.status == "failed" for result in self._step_results):
            return "failed"
        if any(result.status == "skipped" for result in self._step_results):
            return "partial"
        return "completed"

    def _upsert_step_result(self, result: StepResult) -> None:
        for index, existing in enumerate(self._step_results):
            if existing.step_id == result.step_id:
                self._step_results[index] = result
                return
        self._step_results.append(result)
