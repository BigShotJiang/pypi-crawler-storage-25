"""Handlers for assistant pipeline proposal records."""

from __future__ import annotations

from typing import Any

from obra.gateway.assistant.action_broker import HandlerContext
from obra.gateway.assistant.pipelines.builtin import register_builtin_pipelines
from obra.gateway.assistant.pipelines.registry import get_pipeline, list_pipelines
from obra.gateway.assistant.proposal_records import build_proposal_record


def build_pipeline_proposal(
    *,
    workflow_id: str,
    pipeline_id: str,
    params: dict[str, Any] | None = None,
    trigger_source: str = "llm_proposed",
) -> dict[str, Any]:
    """Build the canonical pipeline proposal payload."""
    register_builtin_pipelines()
    wf_id = str(workflow_id or "").strip()
    normalized_pipeline_id = str(pipeline_id or "").strip()
    if not normalized_pipeline_id:
        return {"outcome": "invalid", "detail": "pipeline_id is required."}
    if not wf_id:
        return {"outcome": "invalid", "detail": "workflow_id is required."}

    definition = get_pipeline(normalized_pipeline_id)
    if definition is None:
        alternatives = sorted(pipeline.pipeline_id for pipeline in list_pipelines())
        detail = f"Pipeline not found: {normalized_pipeline_id}"
        if alternatives:
            detail += f". Valid pipeline IDs: {', '.join(alternatives)}"
        return {"outcome": "invalid", "detail": detail}
    if definition.trigger_mode == "manual" and trigger_source != "user_explicit":
        return {
            "outcome": "invalid",
            "detail": f"Pipeline {normalized_pipeline_id} requires explicit user launch.",
        }

    return build_proposal_record(
        action_id="execute_pipeline",
        action_type="propose_pipeline_execution",
        action_inputs={
            "pipeline_id": normalized_pipeline_id,
            "workflow_id": wf_id,
            "params": dict(params or {}),
            "trigger_source": trigger_source,
        },
        preview_type="pipeline_proposal",
        outcome="proposal",
        workflow_id=wf_id,
        pipeline_id=normalized_pipeline_id,
        pipeline_display_name=definition.display_name,
        trigger_mode=definition.trigger_mode,
    )


def propose_pipeline(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Return a pipeline execution proposal record for guided approval."""
    _ = ctx
    wf_id = str(workflow_id or inputs.get("workflow_id") or "").strip()
    return build_pipeline_proposal(
        workflow_id=wf_id,
        pipeline_id=str(inputs.get("pipeline_id") or ""),
        params=inputs.get("params") if isinstance(inputs.get("params"), dict) else {},
        trigger_source=str(inputs.get("trigger_source") or "llm_proposed"),
    )
