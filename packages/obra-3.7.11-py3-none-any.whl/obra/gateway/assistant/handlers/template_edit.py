"""Template edit action handlers — propose and execute template mutations."""

from __future__ import annotations

import copy
import difflib
from typing import Any

from obra.gateway.assistant.action_broker import HandlerContext
from obra.gateway.assistant.handlers.structural import _find_stage, _get_stages
from obra.gateway.assistant.proposal_records import build_proposal_record
from obra.gateway.workflow_studio.template_asset_store_resolver import resolve_template_asset_store
from obra.workflow.stage_instruction_assets import (
    PRIMARY_STAGE_INSTRUCTION_ROLE,
    PendingStageInstructionAssetWrite,
    apply_primary_stage_instruction_candidate_update,
    canonicalize_template_role,
    commit_pending_stage_instruction_asset_writes,
    resolve_primary_stage_instruction,
)
from obra.workflow.template_asset_store import TemplateAssetStore


def _resolve_template_content(
    workflow: dict[str, Any],
    stage_id: str | None,
    template_role: str,
    *,
    store: TemplateAssetStore | None = None,
) -> str | None:
    """Extract current template content from the workflow.

    For stage-level templates, locates the stage by *stage_id* and reads
    the binding matching *template_role*.  For workflow-level templates
    (stage_id is None), reads from the top-level workflow_definition.
    """
    defn = workflow.get("workflow_definition", {})

    if stage_id is None:
        # Workflow-level template (e.g., workflow description or top-level prompt)
        templates = defn.get("templates", {})
        return templates.get(template_role)

    # Stage-level template
    stages = _get_stages(workflow)
    stage = _find_stage(stages, stage_id)
    if stage is None:
        return None
    if template_role == PRIMARY_STAGE_INSTRUCTION_ROLE:
        workflow_id = str(workflow.get("workflow_id") or defn.get("workflow_id") or "").strip()
        resolution = resolve_primary_stage_instruction(
            stage,
            workflow_id,
            store,
            domain_id=str(workflow.get("domain_id") or defn.get("domain_id") or "business"),
        )
        return resolution.content

    # Check template_bindings first, then inline template fields
    for binding in stage.get("template_bindings", []):
        if binding.get("role") == template_role:
            return binding.get("content", "")

    # Fallback: inline template field (e.g., stage_prompt, input_template)
    return stage.get(template_role)


def _apply_template_to_workflow(
    workflow: dict[str, Any],
    stage_id: str | None,
    template_role: str,
    proposed_content: str,
) -> tuple[dict[str, Any], list[PendingStageInstructionAssetWrite]]:
    """Return a copy of *workflow* with the target template replaced."""
    candidate = copy.deepcopy(workflow)
    pending_writes = _apply_template_to_candidate(
        candidate,
        stage_id,
        template_role,
        proposed_content,
    )
    return candidate, pending_writes


def _apply_template_to_candidate(
    candidate: dict[str, Any],
    stage_id: str | None,
    template_role: str,
    proposed_content: str,
) -> list[PendingStageInstructionAssetWrite]:
    """Apply a template update directly to *candidate* in place."""
    defn = candidate.get("workflow_definition", {})

    if stage_id is None:
        templates = defn.setdefault("templates", {})
        templates[template_role] = proposed_content
        return []

    stages = _get_stages(candidate)
    stage = _find_stage(stages, stage_id)
    if stage is None:
        raise ValueError(f"Stage not found: {stage_id}")

    if template_role == PRIMARY_STAGE_INSTRUCTION_ROLE:
        workflow_id = str(candidate.get("workflow_id") or defn.get("workflow_id") or "").strip()
        pending = apply_primary_stage_instruction_candidate_update(
            candidate,
            workflow_id=workflow_id,
            stage_id=stage_id,
            content=proposed_content,
            workflow_version="current",
        )
        return [pending]

    # Update template_bindings if the role exists there
    for binding in stage.get("template_bindings", []):
        if binding.get("role") == template_role:
            binding["content"] = proposed_content
            return []

    # Fallback: set inline template field
    stage[template_role] = proposed_content
    return []


def build_template_edit_proposal(
    *,
    workflow: dict[str, Any],
    workflow_id: str,
    stage_id: str | None,
    template_role: str,
    proposed_content: str,
    expected_revision_id: str = "",
    proposal_group: str | None = None,
    store: TemplateAssetStore | None = None,
) -> dict[str, Any]:
    """Build the canonical template-edit proposal payload."""
    current_content = _resolve_template_content(
        workflow,
        stage_id,
        template_role,
        store=store,
    )
    if current_content is None:
        current_content = ""

    before_lines = current_content.splitlines(keepends=True)
    after_lines = proposed_content.splitlines(keepends=True)
    diff_lines = list(
        difflib.unified_diff(
            before_lines,
            after_lines,
            fromfile=f"{template_role} (current)",
            tofile=f"{template_role} (proposed)",
        )
    )

    return build_proposal_record(
        action_id="execute_template_edit",
        action_type="propose_template_edit",
        action_inputs={
            "workflow_id": workflow_id,
            "stage_id": stage_id,
            "template_role": template_role,
            "proposed_content": proposed_content,
            "expected_revision_id": expected_revision_id,
        },
        preview_type="diff",
        proposal_group=proposal_group,
        outcome="proposal",
        diff=diff_lines,
        before_content=current_content,
        after_content=proposed_content,
        workflow_id=workflow_id,
        stage_id=stage_id,
        template_role=template_role,
    )


def propose(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Propose a template edit and return a diff preview."""
    wf_id = workflow_id or inputs.get("workflow_id", "")
    stage_id: str | None = inputs.get("stage_id")
    template_role: str = canonicalize_template_role(inputs.get("template_role", ""))
    proposed_content: str = inputs.get("proposed_content", "")

    workflow = ctx.repository.get_workflow(wf_id)
    if workflow is None:
        return {"outcome": "invalid", "detail": f"Workflow not found: {wf_id}"}
    store = (
        resolve_template_asset_store(project_root=ctx.project_root)
        if template_role == PRIMARY_STAGE_INSTRUCTION_ROLE
        else None
    )
    return build_template_edit_proposal(
        workflow=workflow,
        workflow_id=wf_id,
        stage_id=stage_id,
        template_role=template_role,
        proposed_content=proposed_content,
        expected_revision_id=str(inputs.get("expected_revision_id") or ""),
        store=store,
    )


def execute(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Apply a previously proposed template edit."""
    wf_id = workflow_id or inputs.get("workflow_id", "")
    stage_id: str | None = inputs.get("stage_id")
    template_role: str = canonicalize_template_role(inputs.get("template_role", ""))
    proposed_content: str = inputs.get("proposed_content", "")
    expected_revision_id: str = inputs.get("expected_revision_id", "")

    workflow = ctx.repository.get_workflow(wf_id)
    if workflow is None:
        return {"outcome": "invalid", "detail": f"Workflow not found: {wf_id}"}

    # Build candidate with the proposed content applied
    candidate, pending_asset_writes = _apply_template_to_workflow(
        workflow,
        stage_id,
        template_role,
        proposed_content,
    )

    result = ctx.action_service.apply_workflow(
        wf_id,
        candidate,
        expected_revision_id=expected_revision_id,
    )

    outcome = result.get("outcome", "")

    if outcome == "conflict":
        return {
            "outcome": "conflict",
            "conflict_summary": result.get("conflict_summary", {}),
            "workflow_id": wf_id,
        }

    if outcome == "invalid":
        return {
            "outcome": "invalid",
            "validation_summary": result.get("validation_summary", {}),
            "workflow_id": wf_id,
        }

    committed_assets = []
    if pending_asset_writes:
        store = resolve_template_asset_store(project_root=ctx.project_root)
        committed_assets = commit_pending_stage_instruction_asset_writes(
            pending_asset_writes,
            store,
            author_id=ctx.user_id or "assistant",
        )

    # accepted
    return {
        "outcome": "applied",
        "resulting_revision_ref": result.get("resulting_revision_ref"),
        "workflow_id": wf_id,
        "stage_id": stage_id,
        "template_role": template_role,
        "template_assets": committed_assets,
    }
