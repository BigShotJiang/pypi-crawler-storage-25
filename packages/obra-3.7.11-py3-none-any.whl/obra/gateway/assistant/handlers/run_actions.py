"""Assistant handlers for canonical workflow-run actions."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from fastapi import HTTPException

from obra.gateway.assistant.action_broker import HandlerContext
from obra.gateway.automation.workspaces import validate_payload_filename
from obra.gateway.routes.crosswalk import serialize_crosswalk_payload
from obra_business.crosswalk.model_crosswalk import CrossWalkConfirmationRequired


def _coerce_input_payload(inputs: dict[str, Any]) -> dict[str, str] | None:
    """Return explicit launch input payload supplied by the assistant action."""
    raw_payload = inputs.get("input_payload")
    if isinstance(raw_payload, dict):
        payload: dict[str, str] = {}
        for raw_name, raw_content in raw_payload.items():
            filename = str(raw_name or "").strip()
            validate_payload_filename(filename)
            payload[filename] = str(raw_content or "")
        return payload or None

    execution_input = str(inputs.get("execution_input") or "").strip()
    if execution_input:
        return {"input_template.md": execution_input}
    objective = str(inputs.get("objective") or "").strip()
    if objective and str(inputs.get("domain_id") or "").strip() == "business":
        return {"input_template.md": objective}
    return None


def execute_launch_run(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Launch a workflow run through the canonical session substrate."""
    if ctx.run_action_service is None:
        return {"outcome": "invalid", "detail": "Run action service unavailable"}
    working_dir = str(inputs.get("working_dir") or "").strip()
    project_id = str(inputs.get("project_id") or "").strip()
    if not working_dir and project_id and callable(ctx.working_dir_resolver):
        try:
            working_dir = ctx.working_dir_resolver(project_id)
        except ValueError as exc:
            return {"outcome": "invalid", "detail": str(exc)}
    if not working_dir and not project_id and ctx.project_root is not None:
        working_dir = str(ctx.project_root)
    working_dir = working_dir or None
    if working_dir is None:
        detail = str(inputs.get("provisioning_error_detail") or "").strip()
        if detail:
            return {"outcome": "invalid", "detail": detail}
        return {
            "outcome": "invalid",
            "detail": (
                "Could not provision a workspace for workflow "
                f"'{inputs.get('workflow_id') or '<unknown>'}'. The workflow may have been "
                "deleted, or the gateway has no allowed_working_dir_base configured."
            ),
        }
    try:
        result = ctx.run_action_service.launch(
            objective=str(inputs.get("objective") or "").strip(),
            project_id=project_id,
            working_dir=working_dir,
            workflow_id=str(inputs.get("workflow_id") or workflow_id or "").strip(),
            revision_id=str(inputs.get("revision_id") or "").strip() or None,
            domain_id=str(inputs.get("domain_id") or "").strip() or None,
            input_payload=_coerce_input_payload(inputs),
            repository=ctx.repository,
        )
    except CrossWalkConfirmationRequired as exc:
        return {
            "outcome": "invalid",
            "detail": str(exc),
            "error_code": "crosswalk_confirmation_required",
            "workflow_id": exc.workflow_id,
            "path": str(exc.path),
            "crosswalk": serialize_crosswalk_payload(
                exc.workflow_id,
                exc.crosswalk,
                Path(exc.path).parent.parent.parent,
            ),
        }
    except HTTPException as exc:
        if isinstance(exc.detail, dict):
            return {
                "outcome": "invalid",
                "detail": exc.detail.get("error_message") or str(exc.detail),
                "error_code": exc.detail.get("error_code"),
            }
        return {"outcome": "invalid", "detail": str(exc.detail)}
    workflow_run = result.get("workflow_run", {})
    return {
        "outcome": "applied",
        "workflow_run": workflow_run,
        "run_id": workflow_run.get("workflow_run_id") or workflow_run.get("run_id"),
        "working_dir": working_dir,
    }


def execute_approve_operator_review(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Approve an operator-blocked run."""
    if ctx.run_action_service is None:
        return {"outcome": "invalid", "detail": "Run action service unavailable"}
    run_id = str(inputs.get("run_id") or "").strip()
    result = ctx.run_action_service.approve_operator_review(run_id)
    return {
        "outcome": "applied",
        "run_id": run_id,
        "run_action": result,
    }


def execute_resolve_escalation(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Resolve a pending run escalation."""
    if ctx.run_action_service is None:
        return {"outcome": "invalid", "detail": "Run action service unavailable"}
    run_id = str(inputs.get("run_id") or "").strip()
    escalation_id = str(inputs.get("escalation_id") or "").strip()
    choice = str(inputs.get("choice") or "").strip()
    result = ctx.run_action_service.resolve_escalation(
        run_id,
        escalation_id,
        choice=choice,
        was_timeout=bool(inputs.get("was_timeout", False)),
    )
    return {
        "outcome": "applied",
        "run_id": run_id,
        "escalation_id": escalation_id,
        "run_action": result,
    }
