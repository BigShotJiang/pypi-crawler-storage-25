"""Workflow metadata mutation handlers for the studio assistant."""

from __future__ import annotations

import copy
from typing import Any

from obra.gateway.assistant.action_broker import HandlerContext
from obra.gateway.assistant.proposal_records import build_proposal_record
from obra.gateway.workflow_studio.starter_catalog import normalize_starter_domain_id
from obra.workflow.readiness import validate_seed_document

_ALLOWED_METADATA_FIELDS = {
    "title",
    "description",
    "domain_id",
    "summary",
    "quality_dimensions",
    "lifecycle_capabilities",
}
_ALLOWED_WORKFLOW_METADATA_FIELDS = {"seed"}


def _normalize_updates(updates: dict[str, Any]) -> dict[str, Any]:
    """Return the explicit metadata updates the assistant is allowed to change."""
    normalized = {
        str(key): value
        for key, value in updates.items()
        if str(key).strip() in _ALLOWED_METADATA_FIELDS
    }
    if "domain_id" in normalized:
        # Coerce unregistered domain ids to the default; the LLM tool schema
        # constrains to {business, software} but providers don't always enforce
        # the enum, so this is the persistence-layer guardrail.
        raw_domain = str(normalized["domain_id"] or "").strip() or "business"
        normalized["domain_id"] = normalize_starter_domain_id(raw_domain) or "business"
    nested_metadata = updates.get("metadata")
    if isinstance(nested_metadata, dict):
        normalized_workflow_metadata: dict[str, Any] = {}
        if "seed" in nested_metadata:
            normalized_workflow_metadata["seed"] = validate_seed_document(nested_metadata.get("seed"))
        if normalized_workflow_metadata:
            normalized["metadata"] = normalized_workflow_metadata
    return normalized


def apply_metadata_updates_to_candidate(
    candidate: dict[str, Any], updates: dict[str, Any]
) -> dict[str, Any]:
    """Apply canonical workflow and workflow-definition metadata updates in place."""
    normalized_updates = _normalize_updates(updates)
    if not normalized_updates:
        raise ValueError("At least one workflow metadata update is required.")

    workflow_definition = candidate.setdefault("workflow_definition", {})
    if not isinstance(workflow_definition, dict):
        raise ValueError("Workflow definition is missing.")
    metadata_updates = normalized_updates.get("metadata")
    if metadata_updates is not None and not isinstance(metadata_updates, dict):
        raise ValueError("Workflow metadata must be an object.")

    changed = False
    for key, value in normalized_updates.items():
        if key == "metadata":
            workflow_metadata = candidate.get("metadata")
            normalized_workflow_metadata = (
                dict(workflow_metadata) if isinstance(workflow_metadata, dict) else {}
            )
            next_metadata = dict(normalized_workflow_metadata)
            next_metadata.update(value)
            if next_metadata != normalized_workflow_metadata:
                candidate["metadata"] = next_metadata
                changed = True
            continue
        previous_definition_value = workflow_definition.get(key)
        previous_candidate_value = candidate.get(key)
        workflow_definition[key] = value
        if key in {"title", "description", "domain_id"}:
            candidate[key] = value
        if previous_definition_value != value or (
            key in {"title", "description", "domain_id"} and previous_candidate_value != value
        ):
            changed = True
    if not changed:
        raise ValueError("No workflow changes to apply for update_workflow_metadata.")
    return normalized_updates


def _build_metadata_preview(
    workflow: dict[str, Any], updates: dict[str, Any]
) -> tuple[dict[str, Any], dict[str, Any]]:
    workflow_definition = workflow.get("workflow_definition", {})
    workflow_definition = workflow_definition if isinstance(workflow_definition, dict) else {}
    workflow_metadata = workflow.get("metadata")
    workflow_metadata = workflow_metadata if isinstance(workflow_metadata, dict) else {}
    before_metadata: dict[str, Any] = {}
    for key, value in updates.items():
        if key == "metadata" and isinstance(value, dict):
            before_metadata["metadata"] = {
                nested_key: workflow_metadata.get(nested_key)
                for nested_key in value
                if nested_key in _ALLOWED_WORKFLOW_METADATA_FIELDS
            }
            continue
        before_metadata[key] = workflow_definition.get(key)
    after_metadata = dict(before_metadata)
    for key, value in updates.items():
        if key == "metadata" and isinstance(value, dict):
            existing_metadata = after_metadata.get("metadata")
            normalized_existing = (
                dict(existing_metadata) if isinstance(existing_metadata, dict) else {}
            )
            normalized_existing.update(value)
            after_metadata["metadata"] = normalized_existing
            continue
        after_metadata[key] = value
    return before_metadata, after_metadata


def propose_update(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Propose updating canonical workflow metadata fields."""
    wf_id = workflow_id or inputs.get("workflow_id", "")
    updates = inputs.get("updates")
    normalized_updates = _normalize_updates(updates) if isinstance(updates, dict) else {}

    workflow = ctx.repository.get_workflow(wf_id)
    if workflow is None:
        return {"outcome": "invalid", "detail": f"Workflow not found: {wf_id}"}
    if not normalized_updates:
        return {
            "outcome": "invalid",
            "detail": "No workflow changes to apply for update_workflow_metadata.",
        }
    try:
        preview_candidate = copy.deepcopy(workflow)
        apply_metadata_updates_to_candidate(preview_candidate, normalized_updates)
    except ValueError as exc:
        return {"outcome": "invalid", "detail": str(exc)}

    before_metadata, after_metadata = _build_metadata_preview(workflow, normalized_updates)
    return build_proposal_record(
        action_id="execute_workflow_metadata_update",
        action_type="propose_workflow_metadata_update",
        action_inputs={
            "workflow_id": wf_id,
            "updates": normalized_updates,
            "expected_revision_id": inputs.get("expected_revision_id", ""),
        },
        preview_type="diff",
        outcome="proposal",
        workflow_id=wf_id,
        updates=normalized_updates,
        changed_fields=sorted(normalized_updates),
        before_metadata=before_metadata,
        after_metadata=after_metadata,
    )


def execute_update(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Apply canonical workflow metadata updates."""
    wf_id = workflow_id or inputs.get("workflow_id", "")
    updates = inputs.get("updates")
    expected_revision_id = str(inputs.get("expected_revision_id") or "")

    workflow = ctx.repository.get_workflow(wf_id)
    if workflow is None:
        return {"outcome": "invalid", "detail": f"Workflow not found: {wf_id}"}

    candidate = copy.deepcopy(workflow)
    try:
        apply_metadata_updates_to_candidate(candidate, updates if isinstance(updates, dict) else {})
    except ValueError as exc:
        return {"outcome": "invalid", "detail": str(exc)}

    result = ctx.action_service.apply_workflow(
        wf_id,
        candidate,
        expected_revision_id=expected_revision_id,
    )
    outcome = result.get("outcome", "")
    if outcome == "conflict":
        return {
            "outcome": "conflict",
            "conflict_summary": result.get("conflict_summary", {}),
            "workflow_id": wf_id,
        }
    if outcome == "invalid":
        return {
            "outcome": "invalid",
            "validation_summary": result.get("validation_summary", {}),
            "workflow_id": wf_id,
        }
    return {
        "outcome": "applied",
        "resulting_revision_ref": result.get("resulting_revision_ref"),
        "workflow_id": wf_id,
    }
