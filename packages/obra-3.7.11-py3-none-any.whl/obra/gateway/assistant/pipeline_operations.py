"""Workflow-scoped operation projection for assistant pipeline sessions."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any


TERMINAL_STATUSES = {"completed", "failed", "cancelled"}


def _utc_now() -> datetime:
    return datetime.now(tz=timezone.utc)


def _parse_timestamp(value: Any) -> datetime | None:
    if isinstance(value, datetime):
        return value if value.tzinfo else value.replace(tzinfo=timezone.utc)
    if not isinstance(value, str) or not value.strip():
        return None
    normalized = value.strip()
    if normalized.endswith("Z"):
        normalized = f"{normalized[:-1]}+00:00"
    try:
        parsed = datetime.fromisoformat(normalized)
    except ValueError:
        return None
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=timezone.utc)


def _isoformat(value: datetime | None) -> str | None:
    return value.isoformat() if value is not None else None


def _event_payload(event: dict[str, Any]) -> dict[str, Any]:
    payload = event.get("payload")
    return payload if isinstance(payload, dict) else {}


def _event_timestamp(event: dict[str, Any]) -> datetime | None:
    return _parse_timestamp(event.get("timestamp"))


def _proposal_count_from_result(result: dict[str, Any] | None) -> int | None:
    if not isinstance(result, dict):
        return None
    proposals = result.get("proposals")
    if isinstance(proposals, list):
        return len(proposals)
    raw = result.get("proposal_count")
    if isinstance(raw, int):
        return raw
    return None


def _turn_id_from_payload(payload: dict[str, Any], key: str) -> str | None:
    turn = payload.get(key)
    if isinstance(turn, dict):
        value = str(turn.get("turn_id") or "").strip()
        return value or None
    return None


def _result_summary(
    *,
    status: str,
    terminal_payload: dict[str, Any] | None,
    result: dict[str, Any] | None,
) -> dict[str, Any] | None:
    if status not in TERMINAL_STATUSES and not terminal_payload and not result:
        return None
    terminal_payload = terminal_payload if isinstance(terminal_payload, dict) else {}
    result = result if isinstance(result, dict) else {}
    proposal_count = terminal_payload.get("proposal_count")
    if not isinstance(proposal_count, int):
        proposal_count = _proposal_count_from_result(result)
    summary: dict[str, Any] = {
        "status": status,
        "proposal_count": proposal_count if isinstance(proposal_count, int) else 0,
    }
    summary_message = str(result.get("summary_message") or "").strip()
    if summary_message:
        summary["summary_message"] = summary_message
    detail = str(terminal_payload.get("detail") or "").strip()
    if detail:
        summary["detail"] = detail
    turn_id = _turn_id_from_payload(terminal_payload, "turn")
    if turn_id:
        summary["turn_id"] = turn_id
    followup_turn_id = _turn_id_from_payload(terminal_payload.get("turn") or {}, "followup_turn")
    if followup_turn_id:
        summary["followup_turn_id"] = followup_turn_id
    return summary


def project_pipeline_operation(
    record: Any,
    *,
    operation_stale_after_s: int,
    now: datetime | None = None,
) -> dict[str, Any]:
    """Project one pipeline session record into a workflow-scoped operation."""
    events = record.event_bus.snapshot()
    now = now or _utc_now()
    last_event = events[-1] if events else None
    last_payload = _event_payload(last_event) if last_event else {}
    last_event_at = _event_timestamp(last_event) if last_event else None
    created_at = getattr(record, "created_at", None)
    created_dt = created_at if isinstance(created_at, datetime) else _parse_timestamp(created_at)
    updated_dt = last_event_at or created_dt

    started_steps: dict[str, dict[str, Any]] = {}
    completed_steps: set[str] = set()
    current_step_id: str | None = None
    current_step_description: str | None = None
    total_step_count: int | None = None
    terminal_payload = getattr(record, "terminal_payload", None)
    if not isinstance(terminal_payload, dict):
        terminal_payload = None

    for event in events:
        event_type = str(event.get("event_type") or "")
        payload = _event_payload(event)
        if event_type == "pipeline_started":
            raw_count = payload.get("step_count")
            if isinstance(raw_count, int):
                total_step_count = raw_count
        elif event_type == "step_started":
            step_id = str(payload.get("step_id") or "").strip()
            if not step_id:
                continue
            started_steps[step_id] = payload
            current_step_id = step_id
            current_step_description = str(payload.get("description") or step_id)
        elif event_type == "step_progress":
            step_id = str(payload.get("step_id") or "").strip()
            if step_id and step_id not in completed_steps:
                current_step_id = step_id
                if not current_step_description:
                    current_step_description = str(payload.get("message") or step_id)
        elif event_type == "step_completed":
            step_id = str(payload.get("step_id") or "").strip()
            if step_id:
                completed_steps.add(step_id)
                if current_step_id == step_id:
                    current_step_id = None
                    current_step_description = None
        elif event_type in {"pipeline_done", "pipeline_cancelled"}:
            terminal_payload = payload

    if current_step_id is None:
        for step_id, payload in reversed(list(started_steps.items())):
            if step_id not in completed_steps:
                current_step_id = step_id
                current_step_description = str(payload.get("description") or step_id)
                break

    status = str(getattr(record, "status", "") or "running")
    stale = False
    if status == "running" and updated_dt is not None:
        stale = (now - updated_dt).total_seconds() > int(operation_stale_after_s)

    result = getattr(record, "result", None)
    result = result if isinstance(result, dict) else None
    result_summary = _result_summary(
        status=status,
        terminal_payload=terminal_payload,
        result=result,
    )

    operation_id = str(getattr(record, "id", "") or "")
    operation = {
        "id": operation_id,
        "operation_id": operation_id,
        "pipeline_session_id": operation_id,
        "pipeline_id": getattr(record, "pipeline_id", ""),
        "workflow_id": getattr(record, "workflow_id", None),
        "revision_id": getattr(record, "revision_id", None),
        "thread_id": getattr(record, "thread_id", ""),
        "turn_id": getattr(record, "turn_id", ""),
        "display_name": getattr(record, "display_name", None),
        "status": status,
        "status_label": "stale" if stale else status,
        "created_at": _isoformat(created_dt),
        "updated_at": _isoformat(updated_dt),
        "last_event_at": _isoformat(last_event_at),
        "last_event_type": str(last_event.get("event_type") or "") if last_event else None,
        "current_step_id": current_step_id,
        "current_step_description": current_step_description,
        "completed_step_count": len(completed_steps),
        "total_step_count": total_step_count,
        "event_count": max(record.event_bus.latest_sequence() + 1, 0),
        "stale": stale,
        "result_summary": result_summary,
        "proposal_count": (result_summary or {}).get("proposal_count", 0),
    }
    if last_payload.get("message"):
        operation["last_message"] = str(last_payload.get("message"))
    return operation


def project_pipeline_operations(
    records: list[Any],
    *,
    operation_stale_after_s: int,
    now: datetime | None = None,
) -> list[dict[str, Any]]:
    """Project and sort retained pipeline operations in server-authoritative order."""
    projected = [
        project_pipeline_operation(
            record,
            operation_stale_after_s=operation_stale_after_s,
            now=now,
        )
        for record in records
    ]

    def _sort_timestamp(operation: dict[str, Any]) -> float:
        parsed = _parse_timestamp(operation.get("created_at"))
        return parsed.timestamp() if parsed is not None else 0.0

    projected.sort(
        key=lambda operation: (
            0 if operation.get("status") == "running" else 1,
            -_sort_timestamp(operation),
        ),
    )
    return projected
