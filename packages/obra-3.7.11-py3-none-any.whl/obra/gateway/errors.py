"""Structured gateway API errors."""

from __future__ import annotations

from fastapi import HTTPException, Request
from fastapi.responses import JSONResponse

from obra.exceptions import APIError
from obra.gateway.error_codes import infer_gateway_error_code


class GatewayAPIError(Exception):
    """Exception carrying the public gateway API error envelope."""

    def __init__(
        self,
        *,
        error_code: str,
        message: str,
        status_code: int,
        hint: str | None = None,
        detail: dict | None = None,
    ) -> None:
        super().__init__(message)
        self.error_code = error_code
        self.message = message
        self.status_code = status_code
        self.hint = hint
        self.detail = detail

    @classmethod
    def from_api_error(
        cls,
        exc: APIError,
        *,
        default_error_code: str,
        default_message: str | None = None,
        hint: str | None = None,
    ) -> "GatewayAPIError":
        """Normalize an upstream APIError into the gateway envelope."""
        return cls(
            error_code=str(exc.error_code or default_error_code),
            message=default_message or str(exc),
            status_code=int(exc.status_code or 502),
            hint=hint or exc.recovery or None,
        )


# Keys that routes encode into HTTPException.detail dicts as structured
# diagnostics (conflict envelopes, action outcomes, revision refs, etc.).
# We preserve these in the wire envelope so clients can render conflict
# surfaces without losing the server-authored shape.
_STRUCTURED_DETAIL_PASSTHROUGH_KEYS: frozenset[str] = frozenset(
    {
        "outcome",
        "workflow",
        "base_revision_ref",
        "current_revision_ref",
        "resulting_revision_ref",
        "conflict_summary",
        "validation_summary",
        "diff_summary",
        "action_id",
        "idempotency_key",
        "required_action",
    }
)


def _extract_structured_detail(detail: object) -> dict | None:
    """Return a dict of structured diagnostic fields for the wire envelope.

    Skips the scalar `message`/`hint` fields (already flattened by the
    envelope) and returns None when nothing structured survives.
    """
    if not isinstance(detail, dict):
        return None
    structured = {
        key: value
        for key, value in detail.items()
        if key in _STRUCTURED_DETAIL_PASSTHROUGH_KEYS
    }
    return structured or None


async def gateway_error_handler(
    request: Request,
    exc: GatewayAPIError,
) -> JSONResponse:
    """Render GatewayAPIError as the canonical JSON envelope."""
    del request
    body: dict[str, object] = {
        "error_code": exc.error_code,
        "message": exc.message,
        "hint": exc.hint,
    }
    if exc.detail:
        body["detail"] = exc.detail
    return JSONResponse(status_code=exc.status_code, content=body)


def gateway_api_error_from_http_exception(exc: HTTPException) -> GatewayAPIError:
    """Normalize a FastAPI HTTPException into the canonical gateway envelope."""
    detail = exc.detail
    message = ""
    hint = None
    if isinstance(detail, dict):
        message = str(
            detail.get("message")
            or detail.get("detail")
            or detail.get("error")
            or detail.get("reason")
            or "Request failed"
        ).strip()
        raw_hint = detail.get("hint")
        if isinstance(raw_hint, str) and raw_hint.strip():
            hint = raw_hint.strip()
    else:
        message = str(detail).strip()
    if not message:
        message = "Request failed"
    return GatewayAPIError(
        error_code=infer_gateway_error_code(detail, status_code=exc.status_code),
        message=message,
        status_code=exc.status_code,
        hint=hint,
        detail=_extract_structured_detail(detail),
    )


async def gateway_http_exception_handler(
    request: Request,
    exc: HTTPException,
) -> JSONResponse:
    """Render FastAPI HTTPException through the canonical gateway error envelope."""
    return await gateway_error_handler(request, gateway_api_error_from_http_exception(exc))
