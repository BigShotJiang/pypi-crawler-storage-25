"""Ollama local provider: detection and auth handlers for desktop onboarding.

Ollama uses the Codex CLI binary with ``--oss --local-provider ollama`` but
requires no cloud authentication. Detection checks both the ``codex`` binary
and the Ollama endpoint reachability.
"""

from __future__ import annotations

import threading
import time
import urllib.request
from typing import Any

from obra.config.cli_resolution import resolve_cli_path, verify_provider_binary
from obra.config.loaders import get_gateway_onboarding_config
from obra.gateway.providers.codex_cli import CODEX_CLI_SIGNATURE

# Module-level cache for the endpoint reachability probe.  Both detection
# and auth-check need this result, and hitting a potentially-unreachable
# endpoint twice (each with a 5 s timeout) blocks the async event loop for
# 10 s when Ollama isn't running.
_endpoint_cache: tuple[dict[str, Any], float] | None = None
_endpoint_lock = threading.Lock()
_ENDPOINT_CACHE_TTL_S = 15.0


def _check_ollama_endpoint(timeout: int | float = 5) -> dict[str, Any]:
    """Check whether the Ollama endpoint is reachable (cached).

    Returns dict with ``reachable``, ``endpoint``, and optional ``issue``.
    Results are cached for ``_ENDPOINT_CACHE_TTL_S`` seconds so that the
    detection and auth-check calls within a single onboarding-status poll
    don't duplicate the (potentially slow) network probe.

    Uses a lock to prevent concurrent threads from stampeding through an
    expired cache and spawning parallel timeout-bound probes.
    """
    global _endpoint_cache
    # Fast path — cache hit, no lock needed.
    if _endpoint_cache is not None:
        cached_result, expiry = _endpoint_cache
        if time.monotonic() < expiry:
            return cached_result

    # Slow path — one thread probes, others wait.
    with _endpoint_lock:
        if _endpoint_cache is not None:
            cached_result, expiry = _endpoint_cache
            if time.monotonic() < expiry:
                return cached_result

        result = _probe_ollama_endpoint(timeout)
        _endpoint_cache = (result, time.monotonic() + _ENDPOINT_CACHE_TTL_S)
        return result


def _probe_ollama_endpoint(timeout: int | float) -> dict[str, Any]:
    """Uncached HTTP probe of the Ollama ``/api/tags`` endpoint."""
    try:
        from obra.llm.ollama_endpoint import resolve_ollama_endpoint

        endpoint = resolve_ollama_endpoint()
    except Exception:
        endpoint = "http://localhost:11434"

    tags_url = f"{endpoint.rstrip('/')}/api/tags"
    try:
        request = urllib.request.Request(tags_url, method="GET")
        with urllib.request.urlopen(request, timeout=timeout) as response:
            status = getattr(response, "status", None)
            if status == 200:
                return {"reachable": True, "endpoint": endpoint}
            return {
                "reachable": False,
                "endpoint": endpoint,
                "issue": f"HTTP {status}",
            }
    except Exception:
        return {
            "reachable": False,
            "endpoint": endpoint,
            "issue": "not_reachable",
        }


def detect_ollama_local() -> dict[str, Any]:
    """Detect whether Codex CLI and Ollama endpoint are available.

    Returns a composite dict:
    - ``installed``: True only when both codex binary exists AND Ollama is reachable
    - ``codex_installed``, ``codex_path``: Codex CLI detection
    - ``ollama_reachable``, ``ollama_endpoint``: Ollama endpoint status
    """
    config = get_gateway_onboarding_config()
    timeout = config["detection_timeout_s"]

    # Check codex binary — Ollama drives Codex CLI's ``--oss`` mode, so a
    # mismatched binary on PATH (e.g. an unrelated tool also named ``codex``)
    # would silently fail at LLM invocation time. Verify the signature.
    codex_path = resolve_cli_path("codex")
    codex_installed = False
    codex_issue: str | None = None
    codex_probe_output: str = ""
    codex_probe_exit_code: int | None = None
    if codex_path is not None:
        verification = verify_provider_binary(
            codex_path,
            probe_args=("--version",),
            signature_pattern=CODEX_CLI_SIGNATURE,
            timeout_s=timeout,
        )
        codex_installed = verification.matched
        if not verification.matched:
            codex_issue = verification.issue
            codex_probe_output = verification.probe_output
            codex_probe_exit_code = verification.exit_code

    # Check Ollama endpoint.
    ollama_status = _check_ollama_endpoint(timeout=timeout)
    ollama_reachable = ollama_status["reachable"]

    result: dict[str, Any] = {
        "installed": codex_installed and ollama_reachable,
        "codex_installed": codex_installed,
        "codex_path": codex_path if codex_installed else None,
        "ollama_reachable": ollama_reachable,
        "ollama_endpoint": ollama_status.get("endpoint", ""),
    }

    if not codex_installed:
        result["install_url"] = "https://ollama.com/download"
        result["install_command"] = "npm install -g @openai/codex"
        if codex_issue is not None:
            result["install_issue"] = codex_issue
            result["binary_path"] = codex_path
            result["probe_output"] = codex_probe_output
            result["probe_exit_code"] = codex_probe_exit_code

    if not ollama_reachable:
        result["ollama_issue"] = ollama_status.get("issue", "not_reachable")
        result["ollama_hint"] = "Start Ollama with: ollama serve"

    return result


def check_ollama_auth() -> dict[str, Any]:
    """Check Ollama 'auth' — endpoint reachability (no cloud auth needed).

    Function named ``check_ollama_auth`` to match the onboarding.py
    resolution convention ``check_{provider_id}_auth`` where provider_id
    is ``ollama``.

    Returns ``authenticated: True`` when the Ollama endpoint is reachable.
    """
    config = get_gateway_onboarding_config()
    timeout = config["auth_check_timeout_s"]

    status = _check_ollama_endpoint(timeout=timeout)
    if status["reachable"]:
        return {"authenticated": True, "auth_issue": None}
    return {"authenticated": False, "auth_issue": "ollama_unreachable"}


def authenticate_ollama_local() -> dict[str, Any]:
    """No-op auth for Ollama — local provider, no cloud auth flow.

    Returns ``skipped: True`` to signal the UI should auto-advance.
    """
    return {
        "triggered": False,
        "error": None,
        "skipped": True,
        "reason": "local_provider",
    }
