"""Claude Code provider: detection and auth handlers for desktop onboarding."""

from __future__ import annotations

import json
import re
import subprocess
import threading
from typing import Any

from obra.config.cli_resolution import (
    excerpt_diagnostic_text,
    resolve_cli_path,
    verify_provider_binary,
)
from obra.config.loaders import get_gateway_onboarding_config
from obra.execution.os_compat import build_popen_kwargs, is_interactive_context
from obra.gateway.providers._auth_process import (
    register_auth_process,
    terminate_auth_process,
    unregister_auth_process,
)
from obra.gateway.providers._terminal_handoff import open_command_in_terminal

# Module-level state for the background auth subprocess.
_auth_process: subprocess.Popen | None = None
_auth_lock = threading.Lock()


def _clear_completed_auth_process() -> None:
    global _auth_process
    if _auth_process is not None and _auth_process.poll() is not None:
        unregister_auth_process(_auth_process)
        _auth_process = None


# Claude Code's ``--version`` output includes the literal app name, e.g.
# ``2.1.116 (Claude Code)``. A plain PATH hit on an unrelated ``claude``
# binary (there is a Homebrew formula with the same name) won't match.
_CLAUDE_CODE_SIGNATURE = re.compile(r"Claude Code", re.IGNORECASE)


def detect_claude_code() -> dict[str, Any]:
    """Detect whether the Claude Code native binary is installed.

    Returns a dict with ``installed`` and one of the following payload shapes:

    * ``installed=True``: ``path``, ``version``.
    * ``installed=False, install_issue="binary_mismatch"``: ``binary_path``,
      ``probe_output`` — a different ``claude`` binary was found on PATH but
      it is not Claude Code.
    * ``installed=False, install_issue="binary_unresponsive"``: ``binary_path``,
      ``probe_output``, ``probe_exit_code`` — binary exists but ``--version``
      failed (timeout or non-zero exit).
    * ``installed=False`` (no ``install_issue``): ``install_url``,
      ``install_command`` — nothing found anywhere.
    """
    config = get_gateway_onboarding_config()
    timeout = config["detection_timeout_s"]

    binary_path = resolve_cli_path("claude")
    if not binary_path:
        return {
            "installed": False,
            "install_url": "https://claude.com/download",
            "install_command": "curl -fsSL https://claude.com/install.sh | sh",
        }

    verification = verify_provider_binary(
        binary_path,
        probe_args=("--version",),
        signature_pattern=_CLAUDE_CODE_SIGNATURE,
        timeout_s=timeout,
    )
    if not verification.matched:
        return {
            "installed": False,
            "install_issue": verification.issue,
            "binary_path": binary_path,
            "probe_output": verification.probe_output,
            "probe_exit_code": verification.exit_code,
            "install_url": "https://claude.com/download",
            "install_command": "curl -fsSL https://claude.com/install.sh | sh",
        }

    return {
        "installed": True,
        "path": binary_path,
        "version": verification.probe_output,
    }


def check_claude_code_auth() -> dict[str, Any]:
    """Check whether Claude Code is authenticated.

    Returns a dict with ``authenticated``, ``auth_issue``, and — when the
    check fails — diagnostic fields (``binary_path``, ``check_exit_code``,
    ``check_stderr_excerpt``) so the onboarding UI and support can triage
    without a second round trip.
    """
    config = get_gateway_onboarding_config()
    timeout = config["auth_check_timeout_s"]

    _clear_completed_auth_process()
    binary_path = resolve_cli_path("claude")
    if not binary_path:
        return {"authenticated": False, "auth_issue": "not_installed"}

    try:
        result = subprocess.run(
            [binary_path, "auth", "status"],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
    except subprocess.TimeoutExpired:
        return {
            "authenticated": False,
            "auth_issue": "connection_failed",
            "binary_path": binary_path,
            "check_exit_code": None,
            "check_stderr_excerpt": f"timed out after {timeout}s",
        }
    except OSError as err:
        return {
            "authenticated": False,
            "auth_issue": "not_installed",
            "binary_path": binary_path,
            "check_exit_code": None,
            "check_stderr_excerpt": f"{type(err).__name__}: {err}",
        }

    combined_lower = result.stdout.lower() + result.stderr.lower()

    if result.returncode == 0:
        # ``claude auth status`` returns JSON on recent versions.
        try:
            data = json.loads(result.stdout)
            if isinstance(data, dict):
                if data.get("loggedIn") is True:
                    return {"authenticated": True, "auth_issue": None}
                if data.get("loggedIn") is False:
                    return {
                        "authenticated": False,
                        "auth_issue": "not_authenticated",
                        "binary_path": binary_path,
                        "check_exit_code": 0,
                        "check_stderr_excerpt": excerpt_diagnostic_text(
                            result.stderr or result.stdout
                        ),
                    }
        except (json.JSONDecodeError, AttributeError):
            pass
        # Non-JSON output with exit 0: treat as authenticated unless the
        # word "expired" is explicit.
        if "expired" in combined_lower:
            return {
                "authenticated": False,
                "auth_issue": "expired",
                "binary_path": binary_path,
                "check_exit_code": 0,
                "check_stderr_excerpt": excerpt_diagnostic_text(result.stderr or result.stdout),
            }
        return {"authenticated": True, "auth_issue": None}

    # Non-zero exit.
    auth_issue = "expired" if "expired" in combined_lower else "not_authenticated"
    return {
        "authenticated": False,
        "auth_issue": auth_issue,
        "binary_path": binary_path,
        "check_exit_code": result.returncode,
        "check_stderr_excerpt": excerpt_diagnostic_text(result.stderr or result.stdout),
    }


def authenticate_claude_code() -> dict[str, Any]:
    """Trigger Claude Code OAuth login flow.

    Spawns ``claude auth login`` inline when invoked from an interactive
    context (e.g. ``obra gateway start`` from a terminal). When the gateway
    has no controlling TTY — the common desktop case — the login command is
    opened in the user's terminal emulator via
    :func:`obra.gateway.providers._terminal_handoff.open_command_in_terminal`.

    Only if terminal handoff fails (no supported terminal found, config
    disabled) do we fall back to the ``manual_action_required`` string.
    """
    global _auth_process

    config = get_gateway_onboarding_config()
    auth_timeout = config["auth_timeout_s"]

    binary_path = resolve_cli_path("claude")
    if not binary_path:
        return {"triggered": False, "error": "Claude Code is not installed"}

    if not is_interactive_context():
        handoff = open_command_in_terminal([binary_path, "auth", "login"])
        if handoff["launched"]:
            return {
                "triggered": True,
                "handoff": True,
                "terminal": handoff["terminal"],
                "method": handoff["method"],
            }
        return {
            "triggered": False,
            "needs_tty": True,
            "manual_action_required": True,
            "handoff_error": handoff.get("error"),
            "instructions": (
                "Run `claude auth login` in a terminal to sign in. We'll pick "
                "up the change automatically once you're done."
            ),
        }

    with _auth_lock:
        _clear_completed_auth_process()
        # Kill any existing auth process.
        if _auth_process is not None:
            terminate_auth_process(_auth_process)
            _auth_process = None

        try:
            _auth_process = subprocess.Popen(
                [binary_path, "auth", "login"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                **build_popen_kwargs(),
            )
            register_auth_process(_auth_process, "claude-auth-login")
        except OSError as e:
            return {"triggered": False, "error": str(e)}

    # Start a timer to kill the process if auth times out.
    def _timeout_killer():
        global _auth_process
        with _auth_lock:
            if _auth_process is not None:
                terminate_auth_process(_auth_process)
                _auth_process = None

    timer = threading.Timer(auth_timeout, _timeout_killer)
    timer.daemon = True
    timer.start()

    return {"triggered": True}
