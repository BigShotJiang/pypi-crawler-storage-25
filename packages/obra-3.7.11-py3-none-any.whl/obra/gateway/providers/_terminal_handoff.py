"""Open a login command in the user's terminal emulator.

GUI-spawned gateway processes (Obra Desktop on macOS, any ``.app``-style
launch, Windows Start menu, Linux ``.desktop`` file) have no controlling
TTY. Provider auth flows (``claude auth login``, ``codex --login``) need
a terminal to collect the OAuth response. This module takes the desired
login ``argv`` and opens it in whichever terminal the user actually uses,
platform-by-platform, returning a structured result the UI can act on.

Result shape:
    ``{"launched": bool, "terminal": str | None, "method": str | None,
       "error": str | None}``

``method`` describes *how* we opened the terminal (``iterm-applescript``,
``terminal-applescript``, ``command-file``, ``gnome-terminal-e``, …) —
useful for support diagnostics when a customer's terminal misbehaves.

The module is import-safe and never raises: on any failure it returns
``launched=False`` with a populated ``error`` field. Callers fall back
to manual instructions when that happens.
"""

from __future__ import annotations

import os
import platform
import shlex
import shutil
import stat
import subprocess
import tempfile
from pathlib import Path
from typing import Any, Sequence

from obra.config.loaders import get_gateway_onboarding_config

# AppleScript templates. Kept as constants to make the generated script
# readable in support captures (stdout shows what we ran).
_ITERM_APPLESCRIPT = """\
tell application "iTerm"
  activate
  if (count of windows) = 0 then
    create window with default profile
  else
    tell current window to create tab with default profile
  end if
  tell current window
    tell current session to write text {command_literal}
  end tell
end tell
"""

_TERMINAL_APPLESCRIPT = """\
tell application "Terminal"
  activate
  do script {command_literal}
end tell
"""


def _applescript_string(text: str) -> str:
    """Quote a string for safe embedding in an AppleScript literal.

    AppleScript string literals use double quotes and escape embedded
    quotes with a backslash. Backslashes themselves must be doubled.
    """
    escaped = text.replace("\\", "\\\\").replace('"', '\\"')
    return f'"{escaped}"'


def _shell_command_line(argv: Sequence[str]) -> str:
    """Join an argv list into a POSIX shell command string.

    Uses :func:`shlex.quote` on each element so whitespace or shell
    metacharacters in the binary path can't break the invocation.
    """
    return " ".join(shlex.quote(part) for part in argv)


def _terminal_preference(system: str) -> list[str]:
    """Return the ordered terminal preference list for the current OS."""
    config = get_gateway_onboarding_config()
    handoff = config.get("terminal_handoff", {})
    if system == "Darwin":
        return list(handoff.get("macos_preference", _DEFAULT_MACOS_PREFERENCE))
    if system == "Linux":
        return list(handoff.get("linux_preference", _DEFAULT_LINUX_PREFERENCE))
    if system == "Windows":
        return list(handoff.get("windows_preference", _DEFAULT_WINDOWS_PREFERENCE))
    return []


_DEFAULT_MACOS_PREFERENCE: tuple[str, ...] = (
    "iTerm",
    "WezTerm",
    "Warp",
    "Ghostty",
    "Alacritty",
    "kitty",
    "Hyper",
    "Terminal",
)

_DEFAULT_LINUX_PREFERENCE: tuple[str, ...] = (
    "gnome-terminal",
    "konsole",
    "xfce4-terminal",
    "alacritty",
    "kitty",
    "tilix",
    "x-terminal-emulator",
    "xterm",
)

_DEFAULT_WINDOWS_PREFERENCE: tuple[str, ...] = (
    "wt",
    "powershell",
    "cmd",
)


def _macos_app_installed(app_name: str) -> Path | None:
    """Return the bundle path if ``<app_name>.app`` is installed."""
    candidates = (
        Path("/Applications") / f"{app_name}.app",
        Path.home() / "Applications" / f"{app_name}.app",
        Path(f"/System/Applications/{app_name}.app"),
    )
    for path in candidates:
        if path.exists():
            return path
    return None


def _launch_iterm(command_line: str) -> dict[str, Any]:
    script = _ITERM_APPLESCRIPT.format(
        command_literal=_applescript_string(command_line),
    )
    try:
        subprocess.run(
            ["osascript", "-e", script], check=True, capture_output=True, text=True,
        )
    except (subprocess.CalledProcessError, OSError) as err:
        return {
            "launched": False,
            "terminal": "iTerm",
            "method": "iterm-applescript",
            "error": _subprocess_error(err),
        }
    return {
        "launched": True,
        "terminal": "iTerm",
        "method": "iterm-applescript",
        "error": None,
    }


def _launch_terminal_app(command_line: str) -> dict[str, Any]:
    script = _TERMINAL_APPLESCRIPT.format(
        command_literal=_applescript_string(command_line),
    )
    try:
        subprocess.run(
            ["osascript", "-e", script], check=True, capture_output=True, text=True,
        )
    except (subprocess.CalledProcessError, OSError) as err:
        return {
            "launched": False,
            "terminal": "Terminal",
            "method": "terminal-applescript",
            "error": _subprocess_error(err),
        }
    return {
        "launched": True,
        "terminal": "Terminal",
        "method": "terminal-applescript",
        "error": None,
    }


def _launch_macos_generic(app_name: str, command_line: str) -> dict[str, Any]:
    """Open a generic macOS terminal app by writing a ``.command`` trampoline.

    Terminals without a reliable AppleScript API (Warp, Ghostty, Alacritty,
    kitty, Hyper, WezTerm) are opened via ``open -a <App> <script.command>``.
    macOS launches the app with the script as its initial input — the app
    then executes the script in a new session. The trampoline prints a
    short notice so the user knows the window will stay open for sign-in.
    """
    trampoline = _write_command_trampoline(command_line)
    try:
        subprocess.run(
            ["open", "-a", app_name, str(trampoline)],
            check=True,
            capture_output=True,
            text=True,
        )
    except (subprocess.CalledProcessError, OSError) as err:
        return {
            "launched": False,
            "terminal": app_name,
            "method": "command-file",
            "error": _subprocess_error(err),
        }
    return {
        "launched": True,
        "terminal": app_name,
        "method": "command-file",
        "error": None,
    }


def _write_command_trampoline(command_line: str) -> Path:
    """Write a short-lived ``.command`` script that runs the login command.

    Added to /tmp so it's reaped by the OS; kept executable so Finder/Terminal
    can run it directly. The script waits for a key press after completion
    so the OAuth callback output stays visible.
    """
    fd, path_str = tempfile.mkstemp(suffix=".command", prefix="obra-login-")
    path = Path(path_str)
    # The file descriptor from mkstemp is still open; close it and write fresh.
    os.close(fd)
    script = (
        "#!/bin/sh\n"
        'printf "Completing sign-in… (close this window when finished)\\n\\n"\n'
        f"{command_line}\n"
        'printf "\\n[sign-in script finished — press Return to close]"\n'
        "read _\n"
    )
    path.write_text(script, encoding="utf-8")
    path.chmod(path.stat().st_mode | stat.S_IEXEC | stat.S_IXGRP | stat.S_IXOTH)
    return path


def _launch_linux(command_line: str, preference: list[str]) -> dict[str, Any]:
    """Spawn a new Linux terminal window running ``command_line``.

    Each terminal has a different flag to pass through a command — most
    accept ``-e`` followed by a shell invocation, ``gnome-terminal`` needs
    ``--`` instead. We wrap in ``sh -c`` + a trailing read so the window
    stays open after the OAuth flow completes.
    """
    tail = '; printf "\n[press Return to close]"; read _'
    inner_command = command_line + tail
    for candidate in preference:
        if not shutil.which(candidate):
            continue
        argv = _linux_argv_for(candidate, inner_command)
        try:
            subprocess.Popen(argv, close_fds=True)
        except OSError as err:
            return {
                "launched": False,
                "terminal": candidate,
                "method": f"{candidate}-spawn",
                "error": _subprocess_error(err),
            }
        return {
            "launched": True,
            "terminal": candidate,
            "method": f"{candidate}-spawn",
            "error": None,
        }
    return {
        "launched": False,
        "terminal": None,
        "method": None,
        "error": "No supported Linux terminal emulator found on PATH.",
    }


def _linux_argv_for(candidate: str, wrapped_command: str) -> list[str]:
    if candidate == "gnome-terminal":
        return ["gnome-terminal", "--", "sh", "-c", wrapped_command]
    # ``-e`` is accepted by konsole, xfce4-terminal, x-terminal-emulator,
    # xterm, tilix, and most minor emulators. For alacritty/kitty the same
    # flag exists but they also accept argv after ``-e``.
    return [candidate, "-e", "sh", "-c", wrapped_command]


def _launch_windows(command_line: str, preference: list[str]) -> dict[str, Any]:
    """Spawn a new Windows terminal window.

    ``wt`` (Windows Terminal), ``powershell``, and ``cmd`` are all launched
    via ``start``. ``pause`` keeps the window open after the login script
    exits so the user can see the confirmation output.
    """
    wrapped_cmd = f'{command_line} & pause'
    for candidate in preference:
        if candidate == "wt":
            argv = ["cmd", "/c", "start", "", "wt", "cmd", "/k", wrapped_cmd]
        elif candidate == "powershell":
            argv = ["cmd", "/c", "start", "", "powershell", "-NoExit", "-Command", wrapped_cmd]
        elif candidate == "cmd":
            argv = ["cmd", "/c", "start", "", "cmd", "/k", wrapped_cmd]
        else:
            continue
        try:
            subprocess.Popen(argv, close_fds=True)
        except OSError as err:
            return {
                "launched": False,
                "terminal": candidate,
                "method": f"{candidate}-start",
                "error": _subprocess_error(err),
            }
        return {
            "launched": True,
            "terminal": candidate,
            "method": f"{candidate}-start",
            "error": None,
        }
    return {
        "launched": False,
        "terminal": None,
        "method": None,
        "error": "No supported Windows terminal found.",
    }


def _subprocess_error(err: Exception) -> str:
    """Flatten a subprocess error into a string suitable for display."""
    if isinstance(err, subprocess.CalledProcessError):
        stderr = (err.stderr or "").strip() if isinstance(err.stderr, str) else ""
        return f"osascript exit {err.returncode}: {stderr[:200]}" if stderr else f"osascript exit {err.returncode}"
    return f"{type(err).__name__}: {err}"


def open_command_in_terminal(argv: Sequence[str]) -> dict[str, Any]:
    """Open ``argv`` in the user's terminal emulator.

    Returns ``{launched, terminal, method, error}``. On any failure (no
    supported terminal found, osascript/subprocess error, config disabled),
    ``launched`` is False and the caller falls back to manual instructions.
    """
    config = get_gateway_onboarding_config()
    handoff = config.get("terminal_handoff", {})
    if not handoff.get("enabled", True):
        return {
            "launched": False,
            "terminal": None,
            "method": None,
            "error": "Terminal handoff is disabled (gateway.onboarding.terminal_handoff.enabled=false).",
        }

    command_line = _shell_command_line(argv)
    system = platform.system()
    preference = _terminal_preference(system)

    if system == "Darwin":
        return _launch_macos(command_line, preference)
    if system == "Linux":
        return _launch_linux(command_line, preference)
    if system == "Windows":
        return _launch_windows(command_line, preference)
    return {
        "launched": False,
        "terminal": None,
        "method": None,
        "error": f"Unsupported platform for terminal handoff: {system}",
    }


def _launch_macos(command_line: str, preference: list[str]) -> dict[str, Any]:
    """Iterate through the macOS preference list and launch the first match.

    Native handlers exist for iTerm and Terminal.app (AppleScript). Other
    apps are launched via a ``.command`` trampoline file, which most modern
    terminals accept as an initial script argument.
    """
    for candidate in preference:
        bundle = _macos_app_installed(candidate)
        if bundle is None:
            continue
        if candidate == "iTerm":
            return _launch_iterm(command_line)
        if candidate == "Terminal":
            return _launch_terminal_app(command_line)
        return _launch_macos_generic(candidate, command_line)
    return {
        "launched": False,
        "terminal": None,
        "method": None,
        "error": (
            "No preferred terminal app found. Configure "
            "`gateway.onboarding.terminal_handoff.macos_preference` or install "
            "one of: " + ", ".join(preference)
        ),
    }
