"""Deterministic next-step CTA resolver for Studio Assistant turns."""

from __future__ import annotations

from typing import Any

from obra.gateway.assistant.action_registry import V1_ACTIONS
from obra.gateway.assistant.pipelines.builtin import register_builtin_pipelines
from obra.gateway.assistant.pipelines.registry import get_pipeline

RecommendedNextCta = dict[str, Any]

_PIPELINE_GENERATE_TEMPLATES = "pipeline_generate_templates"
_PIPELINE_SELF_REVIEW = "pipeline_self_review"


NEXT_STEP_TABLE: dict[str, dict[str, str]] = {
    "describe_goal_or_pick_starter": {
        "label": "Describe the workflow goal",
        "rationale": "No workflow is available yet, so the next useful step is to establish the goal.",
    },
    "clarify_intent": {
        "label": "Clarify the workflow intent",
        "rationale": "The workflow seed exists but needs a clearer objective before detailed authoring.",
    },
    "author_stage_instructions": {
        "label": "Author stage instructions",
        "rationale": "One or more stages are missing primary instructions.",
    },
    "add_quality_gates": {
        "label": "Add quality gates",
        "rationale": "Stage instructions exist, but the workflow still needs quality gates.",
    },
    "save_revision": {
        "label": "Save the current revision",
        "rationale": "The draft has unsaved changes that should be persisted before launch or review.",
    },
    "smoke_test": {
        "label": "Run a smoke test",
        "rationale": "The workflow is enriched enough to review before a full launch.",
    },
    "retry_pipeline": {
        "label": "Retry the pipeline",
        "rationale": "The previous pipeline was cancelled and can be retried from the current workflow.",
    },
    "abandon_pipeline": {
        "label": "Abandon the failed pipeline",
        "rationale": "The last pipeline failed, so the next step is to inspect or change course.",
    },
    "launch_run": {
        "label": "Launch a workflow run",
        "rationale": "The workflow is ready and has not been run yet.",
    },
    "review_run_output": {
        "label": "Review the run output",
        "rationale": "The latest run succeeded, so the next step is to inspect the result.",
    },
    "patch_failed_stage": {
        "label": "Patch the failed stage",
        "rationale": "The latest run failed and needs a targeted stage fix.",
    },
    "continue_guided_next_step": {
        "label": "Continue the guided next step",
        "rationale": "The workflow context is valid but does not match a more specific rule.",
    },
}


def _nonempty_string(value: Any) -> str | None:
    text = str(value or "").strip()
    return text or None


def _action_inputs_satisfy_schema(action_id: str, inputs: dict[str, Any] | None) -> bool:
    if not inputs:
        return False
    action = V1_ACTIONS.get(action_id)
    if action is None:
        return False
    schema = action.input_schema if isinstance(action.input_schema, dict) else {}
    for key, spec in schema.items():
        if not isinstance(spec, dict) or not spec.get("required"):
            continue
        value = inputs.get(key)
        if isinstance(value, str):
            if not value.strip():
                return False
            continue
        if value is None:
            return False
    return True


def _pipeline_inputs(pipeline_id: str, workflow_id: str | None) -> dict[str, Any] | None:
    if not workflow_id:
        return None
    register_builtin_pipelines()
    if get_pipeline(pipeline_id) is None:
        return None
    inputs = {"pipeline_id": pipeline_id, "workflow_id": workflow_id}
    return inputs if _action_inputs_satisfy_schema("propose_pipeline_execution", inputs) else None


def _run_inputs(resolved_context: dict[str, Any], workflow_id: str | None) -> dict[str, Any] | None:
    project_id = _nonempty_string(resolved_context.get("project_id"))
    if not workflow_id or not project_id:
        return None
    workflow = resolved_context.get("workflow")
    workflow_title = ""
    if isinstance(workflow, dict):
        workflow_title = _nonempty_string(
            workflow.get("title") or workflow.get("name") or workflow.get("workflow_name")
        ) or ""
    objective = f"Run {workflow_title}" if workflow_title else f"Run workflow {workflow_id}"
    inputs: dict[str, Any] = {
        "objective": objective,
        "project_id": project_id,
        "workflow_id": workflow_id,
    }
    revision_id = _nonempty_string(resolved_context.get("revision_id"))
    if revision_id:
        inputs["revision_id"] = revision_id
    domain_id = _nonempty_string(resolved_context.get("domain_id"))
    if domain_id:
        inputs["domain_id"] = domain_id
    return inputs if _action_inputs_satisfy_schema("execute_launch_run", inputs) else None


def _quality_gate_count(resolved_context: dict[str, Any]) -> int:
    readiness = resolved_context.get("workflow_readiness")
    stage_readiness = readiness.get("stage_readiness") if isinstance(readiness, dict) else []
    if isinstance(stage_readiness, list):
        count = sum(
            1
            for stage in stage_readiness
            if isinstance(stage, dict) and bool(stage.get("has_quality_gates"))
        )
        if count:
            return count
    workflow = resolved_context.get("workflow")
    definition = workflow.get("workflow_definition") if isinstance(workflow, dict) else None
    if not isinstance(definition, dict):
        definition = workflow if isinstance(workflow, dict) else {}
    stages = definition.get("stages") if isinstance(definition, dict) else []
    if not isinstance(stages, list):
        return 0
    gate_keys = ("quality_loop", "rule_pack_refs", "quality_pack_refs")
    return sum(1 for stage in stages if isinstance(stage, dict) and any(stage.get(key) for key in gate_keys))


def _empty_instruction_stage_count(resolved_context: dict[str, Any]) -> int:
    explicit = resolved_context.get("empty_instruction_stage_count")
    if isinstance(explicit, int):
        return max(explicit, 0)
    readiness = resolved_context.get("workflow_readiness")
    stage_readiness = readiness.get("stage_readiness") if isinstance(readiness, dict) else []
    if not isinstance(stage_readiness, list):
        return 0
    return sum(
        1
        for stage in stage_readiness
        if isinstance(stage, dict)
        and (
            not bool(stage.get("has_instructions"))
            or str(stage.get("status") or "") == "empty"
            or "instructions" in {str(item) for item in stage.get("missing_fields") or []}
        )
    )


def _pending_proposal_count(resolved_context: dict[str, Any]) -> int:
    explicit = resolved_context.get("pending_proposal_count")
    if isinstance(explicit, int):
        return max(explicit, 0)
    summary = resolved_context.get("pending_assistant_proposals")
    if isinstance(summary, dict):
        for key in ("pending_count", "total_count", "count"):
            value = summary.get(key)
            if isinstance(value, int):
                return max(value, 0)
    return 0


def _save_readiness(resolved_context: dict[str, Any]) -> str:
    explicit = _nonempty_string(resolved_context.get("save_readiness"))
    if explicit:
        return explicit
    ui_context = resolved_context.get("ui_context")
    if isinstance(ui_context, dict):
        explicit = _nonempty_string(ui_context.get("save_readiness"))
        if explicit:
            return explicit
        if bool(ui_context.get("dirty")):
            return "needs_save"
    return "ready"


def _latest_run_outcome(resolved_context: dict[str, Any]) -> str | None:
    explicit = _nonempty_string(resolved_context.get("latest_run_outcome"))
    if explicit:
        return explicit.lower()
    latest_run = resolved_context.get("latest_run")
    if isinstance(latest_run, dict):
        for key in ("outcome", "status"):
            value = _nonempty_string(latest_run.get(key))
            if value:
                return value.lower()
    return None


def _last_pipeline_outcome(resolved_context: dict[str, Any]) -> tuple[str | None, str | None]:
    outcome = resolved_context.get("last_pipeline_outcome")
    if not isinstance(outcome, dict):
        return None, None
    return (
        _nonempty_string(outcome.get("outcome")),
        _nonempty_string(outcome.get("pipeline_id")),
    )


def _build_cta(
    intent: str,
    *,
    action_id: str | None = None,
    action_inputs: dict[str, Any] | None = None,
) -> RecommendedNextCta:
    template = NEXT_STEP_TABLE[intent]
    if action_id and not _action_inputs_satisfy_schema(action_id, action_inputs):
        action_id = None
        action_inputs = None
    return {
        "intent": intent,
        "label": template["label"],
        "rationale": template["rationale"],
        "suggested_action_id": action_id,
        "suggested_action_inputs": action_inputs,
    }


def _has_turn_grounding(resolved_context: dict[str, Any]) -> bool:
    return any(
        key in resolved_context
        for key in (
            "thread_id",
            "session_id",
            "workflow",
            "workflow_id",
            "ui_context",
            "all_turns",
            "turn_history",
        )
    )


def compute_next_cta(resolved_context: dict[str, Any]) -> RecommendedNextCta | None:
    """Return the deterministic recommended next CTA for a resolved assistant context."""
    if not isinstance(resolved_context, dict) or not resolved_context:
        return None
    readiness = resolved_context.get("workflow_readiness")
    if not isinstance(readiness, dict) and not _has_turn_grounding(resolved_context):
        return None

    workflow_id = _nonempty_string(resolved_context.get("workflow_id"))
    workflow = resolved_context.get("workflow")
    has_workflow = bool(resolved_context.get("has_workflow"))
    if isinstance(workflow, dict) or workflow_id:
        has_workflow = True

    if not has_workflow:
        return _build_cta("describe_goal_or_pick_starter")

    phase = _nonempty_string(readiness.get("phase") if isinstance(readiness, dict) else None) or "seed"
    phase = phase.lower()
    empty_instruction_count = _empty_instruction_stage_count(resolved_context)
    save_readiness = _save_readiness(resolved_context)
    has_latest_run = bool(resolved_context.get("has_latest_run")) or resolved_context.get("latest_run") is not None
    latest_run_outcome = _latest_run_outcome(resolved_context)
    last_pipeline_outcome, last_pipeline_id = _last_pipeline_outcome(resolved_context)
    pending_count = _pending_proposal_count(resolved_context)

    if pending_count > 0:
        return _build_cta("continue_guided_next_step")
    if phase == "seed":
        return _build_cta("clarify_intent")
    if phase == "draft":
        if empty_instruction_count > 0:
            return _build_cta(
                "author_stage_instructions",
                action_id="propose_pipeline_execution",
                action_inputs=_pipeline_inputs(_PIPELINE_GENERATE_TEMPLATES, workflow_id),
            )
        if _quality_gate_count(resolved_context) == 0:
            return _build_cta("add_quality_gates")
    if phase == "enrich":
        if save_readiness == "needs_save":
            return _build_cta("save_revision")
        if last_pipeline_outcome == "cancelled":
            return _build_cta(
                "retry_pipeline",
                action_id="propose_pipeline_execution",
                action_inputs=_pipeline_inputs(last_pipeline_id or _PIPELINE_SELF_REVIEW, workflow_id),
            )
        if last_pipeline_outcome == "failed":
            return _build_cta("abandon_pipeline")
        if not has_latest_run:
            return _build_cta(
                "smoke_test",
                action_id="propose_pipeline_execution",
                action_inputs=_pipeline_inputs(_PIPELINE_SELF_REVIEW, workflow_id),
            )
    if phase == "ready":
        if not has_latest_run:
            return _build_cta(
                "launch_run",
                action_id="execute_launch_run",
                action_inputs=_run_inputs(resolved_context, workflow_id),
            )
        if latest_run_outcome == "success":
            return _build_cta("review_run_output")
        if latest_run_outcome == "failed":
            return _build_cta("patch_failed_stage")

    return _build_cta("continue_guided_next_step")
