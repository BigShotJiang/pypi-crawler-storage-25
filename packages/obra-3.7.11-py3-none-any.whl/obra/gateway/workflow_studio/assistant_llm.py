"""Assistant LLM provider resolution helpers.

Routes assistant turns through the configured LLM provider. Guided mode sends
tool definitions and parses tool call responses.
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, Callable

from obra.gateway.workflow_studio.assistant_types import AssistantLlmResponse
from obra.gateway.workflow_studio.tool_call_translator import (
    parse_tool_calls,
    translate_tool_calls,
)

logger = logging.getLogger(__name__)


def _coerce_suggested_actions(value: Any) -> list[str] | None:
    """Normalize suggested action ids from an advisory response payload."""
    if not isinstance(value, list):
        return None

    normalized: list[str] = []
    for item in value:
        if not isinstance(item, str):
            continue
        action_id = item.strip()
        if not action_id or action_id in normalized:
            continue
        normalized.append(action_id)
    return normalized or None


def _normalize_advisory_payload(
    payload: dict[str, Any],
    *,
    fallback_message: str | None = None,
) -> AssistantLlmResponse:
    """Normalize advisory JSON payloads into the shared response type."""
    return AssistantLlmResponse(
        message=str(payload.get("message") or payload.get("content") or fallback_message or "").strip(),
        outcome=str(payload.get("outcome") or "advice"),
        action_records=payload.get("action_records"),
        suggested_actions=_coerce_suggested_actions(payload.get("suggested_actions")),
    )


def _normalize_advisory_text(text: str) -> AssistantLlmResponse:
    """Clean advisory output that may contain reasoning preambles and/or JSON contracts.

    If the text contains an embedded JSON object with a ``message`` field,
    extract that message.  Otherwise strip common reasoning preambles
    (e.g. "The user is asking..." paragraphs before the real answer).
    """
    import re

    from obra.gateway.workflow_studio.assistant_response_planner import _extract_embedded_json

    stripped = text.strip()
    if not stripped:
        return stripped

    # If the text contains a JSON contract with a "message" key, extract it.
    data = _extract_embedded_json(stripped)
    if data is not None:
        return _normalize_advisory_payload(data, fallback_message=stripped)

    # Strip chain-of-thought reasoning that precedes the actual answer.
    divider = re.split(r"\n---+\n", stripped, maxsplit=1)
    if len(divider) == 2 and len(divider[1].strip()) > 20:
        return AssistantLlmResponse(message=divider[1].strip())

    return AssistantLlmResponse(message=stripped)


async def call_assistant_llm(
    system_prompt: str,
    user_message: str,
    *,
    app_state: Any | None = None,
    provider: Callable[..., Any] | None = None,
    resolved_context: dict[str, Any] | None = None,
    model_id: str | None = None,
    **kwargs: Any,
) -> AssistantLlmResponse:
    """Call the configured assistant LLM provider.

    Uses the CLI subprocess pipeline (claude/codex/gemini) by default.
    """
    safety_mode = str((resolved_context or {}).get("safety_mode") or "guided")

    llm_provider = provider or (
        getattr(app_state, "assistant_llm_provider", None) if app_state is not None else None
    )

    if llm_provider is None:
        raise RuntimeError(
            "Assistant LLM provider is not available. "
            "Verify the provider CLI is installed and authenticated "
            "(e.g. 'claude login' for Anthropic, 'codex --login' for OpenAI)."
        )

    # --- Provider is available: invoke via CLI subprocess pipeline ---

    if safety_mode == "guided":
        guided_result = await asyncio.to_thread(
            _invoke_provider_guided,
            llm_provider,
            system_prompt=system_prompt,
            user_message=user_message,
            model_id=model_id,
        )
        if isinstance(guided_result, dict):
            guided_text = json.dumps(guided_result)
        else:
            guided_text = str(guided_result)
        message, tool_calls = parse_tool_calls(guided_text)
        return translate_tool_calls(
            message,
            tool_calls,
            resolved_context=resolved_context,
            construction_context=(resolved_context or {}).get("construction_context"),
        )

    # Advisory mode: plain text response.
    text_result = await asyncio.to_thread(
        _invoke_provider_text,
        llm_provider,
        system_prompt=system_prompt,
        user_message=user_message,
        model_id=model_id,
    )
    # Normalize result — may be str, InvocationResult, or dict.
    if isinstance(text_result, str):
        return _normalize_advisory_text(text_result)
    if isinstance(text_result, dict):
        return _normalize_advisory_payload(text_result)
    if hasattr(text_result, "content"):
        return _normalize_advisory_text(str(getattr(text_result, "content", "")))
    return AssistantLlmResponse(message=str(text_result).strip())


def _resolve_provider_result(result: Any) -> Any:
    """Await coroutines and normalize provider results.

    Returns the result as-is if it's already a dict/str.
    """
    import asyncio as _aio

    if _aio.iscoroutine(result):
        result = _aio.run(result)
    # InvocationResult from LLMInvoker — check for failures.
    if hasattr(result, "success") and result.success is False:
        raise RuntimeError(str(getattr(result, "error_message", "") or "assistant LLM call failed"))
    return result


def _invoke_provider_text(
    llm_provider: Any,
    *,
    system_prompt: str,
    user_message: str,
    model_id: str | None,
) -> Any:
    """Synchronous helper — runs in a thread via asyncio.to_thread."""
    if hasattr(llm_provider, "generate_text"):
        result = llm_provider.generate_text(
            system_prompt=system_prompt,
            user_message=user_message,
            model_id=model_id,
        )
        return _resolve_provider_result(result)
    raise RuntimeError("LLM provider does not implement generate_text")


_THREAD_TITLE_SYSTEM_PROMPT_BASE = (
    "You generate short conversation titles. "
    "Given a transcript excerpt, output a 3-6 word title describing what THIS "
    "specific conversation is about. "
    "Plain text only — no quotes, no punctuation other than spaces, no leading/trailing whitespace. "
    "Use lowercase. Examples: 'failed run debug', 'standards mix experiment', 'lesson timing tweaks'."
)

_THREAD_TITLE_SYSTEM_PROMPT_WITH_WORKFLOW = (
    _THREAD_TITLE_SYSTEM_PROMPT_BASE
    + " The conversation is scoped to a specific workflow whose name will be given. "
    + "Do NOT restate the workflow name in the title — pick a title that captures what makes "
    + "THIS conversation distinct (the user's specific question, problem, or task within that workflow)."
)


async def generate_thread_title(
    *,
    user_message: str,
    assistant_message: str,
    workflow_title: str | None = None,
    app_state: Any | None = None,
    model_id: str | None = None,
) -> str | None:
    """Best-effort short conversation title from a recent transcript excerpt.

    When ``workflow_title`` is supplied the title is asked to discriminate from
    the workflow's general purpose — useful when a thread sits inside a
    workflow context the user already named.

    Returns None on any failure — the baseline slug remains in place.
    """
    llm_provider = (
        getattr(app_state, "assistant_llm_provider", None) if app_state is not None else None
    )
    if llm_provider is None:
        return None
    try:
        snippet_user = user_message.strip()[:1500]
        snippet_assistant = assistant_message.strip()[:1500]
        if workflow_title:
            system_prompt = _THREAD_TITLE_SYSTEM_PROMPT_WITH_WORKFLOW
            prompt = (
                f"Workflow name (do not restate): {workflow_title.strip()}\n\n"
                f"User turns:\n{snippet_user}\n\n"
                f"Assistant turns:\n{snippet_assistant}\n\n"
                f"Title:"
            )
        else:
            system_prompt = _THREAD_TITLE_SYSTEM_PROMPT_BASE
            prompt = (
                f"User turns:\n{snippet_user}\n\n"
                f"Assistant turns:\n{snippet_assistant}\n\n"
                f"Title:"
            )
        result = await asyncio.to_thread(
            _invoke_provider_text,
            llm_provider,
            system_prompt=system_prompt,
            user_message=prompt,
            model_id=model_id,
        )
        if isinstance(result, dict):
            text = str(result.get("message") or result.get("content") or "")
        elif hasattr(result, "content"):
            text = str(getattr(result, "content", ""))
        else:
            text = str(result or "")
        title = text.strip().strip('"').strip("'").strip()
        # Sanity-cap and reject empty / multi-line / suspiciously long output
        if not title or "\n" in title or len(title) > 80:
            return None
        return title
    except Exception:
        logger.debug("Thread title generation failed", exc_info=True)
        return None


def _invoke_provider_guided(
    llm_provider: Any,
    *,
    system_prompt: str,
    user_message: str,
    model_id: str | None,
) -> Any:
    """Synchronous helper — runs in a thread via asyncio.to_thread."""
    if hasattr(llm_provider, "generate_guided_contract"):
        result = llm_provider.generate_guided_contract(
            system_prompt=system_prompt,
            user_message=user_message,
            model_id=model_id,
        )
        return _resolve_provider_result(result)
    raise RuntimeError("LLM provider does not implement generate_guided_contract")


def call_assistant_llm_sync(
    system_prompt: str,
    user_message: str,
    *,
    app_state: Any | None = None,
    provider: Callable[..., Any] | None = None,
    resolved_context: dict[str, Any] | None = None,
    **kwargs: Any,
) -> AssistantLlmResponse:
    """Synchronous bridge for broker handlers executed from a worker thread."""
    return asyncio.run(
        call_assistant_llm(
            system_prompt,
            user_message,
            app_state=app_state,
            provider=provider,
            resolved_context=resolved_context,
            **kwargs,
        )
    )
