"""Workflow Studio connector-backed gateway routes."""

from __future__ import annotations

import asyncio
import importlib
import secrets
import time
from pathlib import Path
from typing import Any, Literal

from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.responses import HTMLResponse

from obra.config.loaders import (
    get_google_drive_oauth_config,
    get_google_drive_oauth_lifecycle_config,
)
from obra.connectors import (
    CredentialStore,
    ObraConnectorAuthError,
    ObraConnectorNotFoundError,
    ObraConnectorPermanentError,
    ObraConnectorTransientError,
    ObraConnectorValidationError,
    get_registered_operation,
)
from obra.connectors.credentials import OAuth2Credential, revoke_google_drive_oauth_credential
from obra.exceptions import ConfigurationError
from obra.connectors.oauth import OAuthBrowserFlow
from obra.gateway.errors import GatewayAPIError
from obra.gateway.security.scopes import GatewayScope, require_scope
from obra.gateway.routes.workflows import (
    _knowledge_repository,
    _local_workflow_store,
    _maybe_knowledge_repository,
    _placeholder_docs_dir,
)
from obra.gateway.workflow_studio.knowledge_repository import KnowledgeRepository
from obra.workflow.package import (
    WorkflowPackageBuilder,
    WorkflowPackageImporter,
    sanitize_package_filename_component,
)

router = APIRouter(prefix="/api/connectors", tags=["connectors"])
oauth_callback_router = APIRouter(tags=["connectors-oauth-callback"])

_READ_SCOPE = [Depends(require_scope(GatewayScope.READ))]
_OPERATE_SCOPE = [Depends(require_scope(GatewayScope.OPERATE))]

_GOOGLE_DRIVE_PROVIDER_ROOT = "obra_connector_google_drive"
_GOOGLE_DRIVE_VERSION = "1.0.0"
_GOOGLE_DRIVE_OAUTH_TTL_S = 600

_GOOGLE_DRIVE_CONFIGURATION_HINT = (
    "Set OBRA_GOOGLE_DRIVE_OAUTH_CLIENT_ID and "
    "OBRA_GOOGLE_DRIVE_OAUTH_CLIENT_SECRET, or configure "
    "connectors.google_drive.oauth.client_id and "
    "connectors.google_drive.oauth.client_secret, then retry."
)


def _pending_oauth_flows(request: Request) -> dict[str, dict[str, Any]]:
    pending = getattr(request.app.state, "_oauth_pending_flows", None)
    if not isinstance(pending, dict):
        pending = {}
        request.app.state._oauth_pending_flows = pending
    return pending


def _prune_expired_pending_flows(
    pending_flows: dict[str, dict[str, Any]],
    *,
    now: float | None = None,
) -> None:
    timestamp = time.time() if now is None else now
    expired_states = [
        state
        for state, entry in pending_flows.items()
        if timestamp >= float(entry.get("expires_at", 0))
    ]
    for state in expired_states:
        pending_flows.pop(state, None)


def _map_store_status_to_api(store_status: str) -> str:
    return "valid" if store_status == "ok" else "error"


def _google_drive_redirect_uri(request: Request) -> str:
    port = request.url.port or int(getattr(request.app.state, "gateway_config", {}).get("port", 18790))
    return f"http://127.0.0.1:{port}/api/connectors/oauth/google-drive/callback"


def _load_google_drive_operation(operation_id: str):
    provider = importlib.import_module("obra_connector_google_drive")
    get_entries = getattr(provider, "get_runner_catalog_entries", None)
    if callable(get_entries):
        get_entries()
    try:
        return get_registered_operation(
            _GOOGLE_DRIVE_PROVIDER_ROOT,
            operation_id,
            _GOOGLE_DRIVE_VERSION,
        )
    except KeyError as exc:
        raise GatewayAPIError(
            error_code="connector_operation_unavailable",
            message=f"Connector operation is unavailable: {operation_id}",
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
        ) from exc


def _connector_call_kwargs(
    definition: Any,
    inputs: dict[str, Any],
    credentials: Any | None = None,
) -> dict[str, Any]:
    kwargs = {str(definition.start_param_name): inputs}
    if definition.credential_param_name is not None:
        kwargs[str(definition.credential_param_name)] = credentials
    return kwargs


def _raise_google_drive_configuration_error(exc: Exception) -> None:
    raise GatewayAPIError(
        error_code="connector_configuration_error",
        message="Google Drive is not configured on this gateway.",
        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
        hint=_GOOGLE_DRIVE_CONFIGURATION_HINT,
    ) from exc


def _resolve_google_drive_oauth_config() -> dict[str, Any]:
    try:
        return get_google_drive_oauth_config()
    except (ConfigurationError, ValueError) as exc:
        _raise_google_drive_configuration_error(exc)


def _resolve_google_drive_oauth_lifecycle_config() -> dict[str, Any] | None:
    try:
        return get_google_drive_oauth_lifecycle_config()
    except (ConfigurationError, ValueError):
        return None


def _raise_connector_error(exc: Exception) -> None:
    if isinstance(exc, ObraConnectorAuthError):
        raise GatewayAPIError(
            error_code="connector_auth_error",
            message=str(exc) or "Connector authentication failed",
            status_code=status.HTTP_401_UNAUTHORIZED,
            hint=getattr(exc, "recovery", None),
        ) from exc
    if isinstance(exc, ObraConnectorValidationError):
        raise GatewayAPIError(
            error_code="connector_validation_error",
            message=str(exc) or "Connector input validation failed",
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            hint=getattr(exc, "recovery", None),
        ) from exc
    if isinstance(exc, ObraConnectorNotFoundError):
        raise GatewayAPIError(
            error_code="connector_not_found",
            message=str(exc) or "Connector resource not found",
            status_code=status.HTTP_404_NOT_FOUND,
            hint=getattr(exc, "recovery", None),
        ) from exc
    if isinstance(exc, ObraConnectorTransientError):
        raise GatewayAPIError(
            error_code="connector_transient_error",
            message=str(exc) or "Connector service is temporarily unavailable",
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            hint=getattr(exc, "recovery", None),
        ) from exc
    if isinstance(exc, ObraConnectorPermanentError):
        raise GatewayAPIError(
            error_code="connector_permanent_error",
            message=str(exc) or "Connector operation failed",
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            hint=getattr(exc, "recovery", None),
        ) from exc
    raise exc


async def _invoke_google_drive_operation(
    operation_id: str,
    *,
    inputs: dict[str, Any],
    credentials: Any,
) -> dict[str, Any]:
    definition = await asyncio.to_thread(_load_google_drive_operation, operation_id)
    try:
        return await asyncio.to_thread(
            definition.function,
            **_connector_call_kwargs(definition, inputs, credentials),
        )
    except Exception as exc:  # pragma: no cover - exercised by targeted route tests
        _raise_connector_error(exc)
        raise


def _credential_store() -> CredentialStore:
    return CredentialStore()


def _lookup_credential_status(credential_name: str) -> dict[str, str]:
    entries = _credential_store().list_credentials()
    for entry in entries:
        if str(entry.get("name") or "") == credential_name:
            return {
                "name": credential_name,
                "type": str(entry.get("type") or ""),
                "status": _map_store_status_to_api(str(entry.get("status") or "error")),
            }
    raise HTTPException(
        status_code=status.HTTP_404_NOT_FOUND,
        detail=f"Credential not found: {credential_name}",
    )


def _configured_google_drive_credential() -> tuple[str, dict[str, Any]]:
    config = _resolve_google_drive_oauth_config()
    credential_name = str(config["credential_name"])
    return credential_name, config


def _google_drive_provider_status() -> dict[str, Any]:
    lifecycle = _resolve_google_drive_oauth_lifecycle_config()
    credential_name = str((lifecycle or {}).get("credential_name") or "").strip() or None
    if credential_name is None:
        return {
            "provider": "google-drive",
            "credential_name": None,
            "connection_status": "unconfigured",
            "message": "Google Drive is not configured on this gateway.",
            "hint": _GOOGLE_DRIVE_CONFIGURATION_HINT,
        }

    try:
        _resolve_google_drive_oauth_config()
    except GatewayAPIError:
        return {
            "provider": "google-drive",
            "credential_name": credential_name,
            "connection_status": "unconfigured",
            "message": "Google Drive is not configured on this gateway.",
            "hint": _GOOGLE_DRIVE_CONFIGURATION_HINT,
        }

    try:
        credential_status = _lookup_credential_status(credential_name)
    except HTTPException:
        return {
            "provider": "google-drive",
            "credential_name": credential_name,
            "connection_status": "disconnected",
            "message": "Google Drive is not connected.",
            "hint": None,
        }

    return {
        "provider": "google-drive",
        "credential_name": credential_name,
        "connection_status": (
            "connected" if credential_status["status"] == "valid" else "disconnected"
        ),
        "message": (
            "Google Drive is connected."
            if credential_status["status"] == "valid"
            else "Google Drive is not connected."
        ),
        "hint": None,
    }


def _build_google_drive_disconnect_result(
    *,
    credential_name: str | None,
    disconnect_status: str,
    credential_removed: bool,
    revocation_outcome: str,
    revocation_attempted: bool,
    message: str,
    hint: str | None = None,
) -> dict[str, Any]:
    return {
        "provider": "google-drive",
        "credential_name": credential_name,
        "disconnect_status": disconnect_status,
        "credential_removed": credential_removed,
        "revocation_outcome": revocation_outcome,
        "revocation_attempted": revocation_attempted,
        "message": message,
        "hint": hint,
    }


def _disconnect_google_drive() -> dict[str, Any]:
    lifecycle = _resolve_google_drive_oauth_lifecycle_config()
    credential_name = str((lifecycle or {}).get("credential_name") or "").strip() or None
    if credential_name is None:
        return _build_google_drive_disconnect_result(
            credential_name=None,
            disconnect_status="already_disconnected",
            credential_removed=False,
            revocation_outcome="not_attempted",
            revocation_attempted=False,
            message="Google Drive is not configured on this gateway.",
            hint=_GOOGLE_DRIVE_CONFIGURATION_HINT,
        )

    store = _credential_store()
    try:
        payload = store.get_payload(credential_name)
    except ObraConnectorAuthError as exc:
        removed = store.remove(credential_name)
        if removed:
            return _build_google_drive_disconnect_result(
                credential_name=credential_name,
                disconnect_status="disconnected",
                credential_removed=True,
                revocation_outcome="not_attempted",
                revocation_attempted=False,
                message="Removed the local Google Drive credential. Remote revocation was not attempted because the stored credential could not be read.",
                hint=str(exc) or getattr(exc, "recovery", None),
            )
        return _build_google_drive_disconnect_result(
            credential_name=credential_name,
            disconnect_status="already_disconnected",
            credential_removed=False,
            revocation_outcome="not_attempted",
            revocation_attempted=False,
            message="Google Drive is already disconnected.",
            hint=None,
        )

    revocation_result = revoke_google_drive_oauth_credential(
        OAuth2Credential(
            name=credential_name,
            access_token=str(payload.get("access_token") or ""),
            refresh_token=str(payload.get("refresh_token") or ""),
            token_url=str((lifecycle or {}).get("token_url") or ""),
            client_id=str((lifecycle or {}).get("client_id") or ""),
            client_secret=str((lifecycle or {}).get("client_secret") or ""),
            expires_at=float(payload["expires_at"]) if payload.get("expires_at") else None,
            scope=str(payload.get("scope") or ""),
            token_type=str(payload.get("token_type") or "Bearer"),
        )
    )
    removed = store.remove(credential_name)

    if not removed:
        return _build_google_drive_disconnect_result(
            credential_name=credential_name,
            disconnect_status="partial",
            credential_removed=False,
            revocation_outcome=revocation_result.outcome,
            revocation_attempted=revocation_result.attempted,
            message="Google Drive disconnect could not remove the local encrypted credential.",
            hint=revocation_result.hint,
        )

    if revocation_result.outcome == "failed":
        return _build_google_drive_disconnect_result(
            credential_name=credential_name,
            disconnect_status="partial",
            credential_removed=True,
            revocation_outcome=revocation_result.outcome,
            revocation_attempted=revocation_result.attempted,
            message="Removed the local Google Drive credential, but Google revocation failed.",
            hint=revocation_result.hint
            or "Disconnect completed locally. Revoke Google Drive access from your Google account if you want to invalidate the remote token immediately.",
        )

    return _build_google_drive_disconnect_result(
        credential_name=credential_name,
        disconnect_status="disconnected",
        credential_removed=True,
        revocation_outcome=revocation_result.outcome,
        revocation_attempted=revocation_result.attempted,
        message=(
            "Disconnected Google Drive and removed the local encrypted credential."
            if revocation_result.outcome in {"revoked", "already_revoked"}
            else "Removed the local Google Drive credential."
        ),
        hint=revocation_result.hint,
    )


async def _load_google_drive_credential() -> Any:
    credential_name, _ = _configured_google_drive_credential()
    try:
        return await asyncio.to_thread(_credential_store().get, credential_name)
    except ObraConnectorAuthError as exc:
        raise GatewayAPIError(
            error_code="connector_auth_error",
            message="Google Drive not connected.",
            status_code=status.HTTP_401_UNAUTHORIZED,
            hint=getattr(exc, "recovery", None),
        ) from exc


def _workflow_package_documents(
    knowledge_repository: KnowledgeRepository | None,
    workflow_id: str,
) -> list[dict[str, Any]]:
    if knowledge_repository is None:
        return []
    return knowledge_repository.list_documents("workflow", workflow_id)


@router.get("/credentials/{credential_name}/status", dependencies=_READ_SCOPE)
async def get_credential_status(credential_name: str) -> dict[str, str]:
    return await asyncio.to_thread(_lookup_credential_status, credential_name)


@router.get("/google-drive/status", dependencies=_READ_SCOPE)
async def get_google_drive_status() -> dict[str, Any]:
    return await asyncio.to_thread(_google_drive_provider_status)


@router.post("/google-drive/disconnect", dependencies=_OPERATE_SCOPE)
async def disconnect_google_drive() -> dict[str, Any]:
    return await asyncio.to_thread(_disconnect_google_drive)


@router.get("/oauth/google-drive/authorize", dependencies=_OPERATE_SCOPE)
async def get_google_drive_authorize_url(
    request: Request,
    mode: Literal["connect", "reconnect"] = "connect",
) -> dict[str, str]:
    config = _resolve_google_drive_oauth_config()
    redirect_uri = _google_drive_redirect_uri(request)
    state = secrets.token_urlsafe(32)
    flow = OAuthBrowserFlow(
        client_id=str(config["client_id"]),
        client_secret=str(config["client_secret"]),
        authorize_url=str(config["authorize_url"]),
        token_url=str(config["token_url"]),
        scopes=[str(scope) for scope in config["scopes"]],
        redirect_uri=redirect_uri,
    )
    authorize_url = flow.build_authorize_url_for_mode(state, reconnect=mode == "reconnect")
    pending = _pending_oauth_flows(request)
    _prune_expired_pending_flows(pending)
    pending[state] = {
        "provider": "google-drive",
        "flow": flow,
        "credential_name": str(config["credential_name"]),
        "mode": mode,
        "expires_at": time.time() + _GOOGLE_DRIVE_OAUTH_TTL_S,
    }
    return {"authorize_url": authorize_url}


@oauth_callback_router.get("/api/connectors/oauth/google-drive/callback")
async def google_drive_oauth_callback(
    request: Request,
    code: str,
    state: str,
) -> HTMLResponse:
    pending = _pending_oauth_flows(request)
    entry = pending.get(state)
    if entry is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="OAuth state is missing or expired.",
        )

    now = time.time()
    if now >= float(entry.get("expires_at", 0)):
        pending.pop(state, None)
        _prune_expired_pending_flows(pending, now=now)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="OAuth state is missing or expired.",
        )

    flow = entry.get("flow")
    if not isinstance(flow, OAuthBrowserFlow):
        pending.pop(state, None)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="OAuth state is invalid.",
        )

    try:
        token_payload = await asyncio.to_thread(flow.exchange_code, code, state)
        expires_in = token_payload.get("expires_in")
        expires_at = None
        if expires_in is not None:
            expires_at = time.time() + float(expires_in)
        await asyncio.to_thread(
            _credential_store().put,
            str(entry["credential_name"]),
            {
                "type": "oauth2",
                "access_token": token_payload.get("access_token"),
                "refresh_token": token_payload.get("refresh_token"),
                "expires_at": expires_at,
                "token_type": token_payload.get("token_type") or "Bearer",
            },
        )
    except ObraConnectorAuthError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(exc) or "OAuth callback failed.",
        ) from exc
    finally:
        pending.pop(state, None)

    return HTMLResponse("Google Drive connected. You can close this tab.")


@router.post("/google-drive/export-package", dependencies=_OPERATE_SCOPE)
async def export_workflow_package_to_drive(
    payload: dict[str, Any],
    request: Request,
) -> dict[str, Any]:
    workflow_id = str(payload.get("workflow_id") or "").strip()
    project_id = str(payload.get("project_id") or "").strip() or None
    folder_id = str(payload.get("folder_id") or "").strip()
    working_dir = payload.get("working_dir")
    normalized_working_dir = str(working_dir).strip() if isinstance(working_dir, str) else None
    if not workflow_id or not folder_id:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="workflow_id, folder_id, and working_dir-aware workspace context are required.",
        )

    store = _local_workflow_store(request)
    workflow = await asyncio.to_thread(store.get_workflow_head, workflow_id)
    if workflow is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Workflow not found")

    revisions = await asyncio.to_thread(store.list_workflow_revisions, workflow_id)
    knowledge_repository = _maybe_knowledge_repository(
        request,
        project_id=project_id,
        working_dir=normalized_working_dir,
    )
    documents = await asyncio.to_thread(
        _workflow_package_documents,
        knowledge_repository,
        workflow_id,
    )
    try:
        package = await asyncio.to_thread(
            WorkflowPackageBuilder(
                workflow=workflow,
                revisions=revisions,
                knowledge_documents=documents,
                knowledge_docs_dir=(
                    knowledge_repository.docs_dir
                    if knowledge_repository is not None
                    else _placeholder_docs_dir()
                ),
            ).build
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=str(exc),
        ) from exc

    title = str((package.get("manifest") or {}).get("title") or workflow.get("title") or "").strip()
    filename = f"{sanitize_package_filename_component(title, fallback=workflow_id)}.obra"
    credential = await _load_google_drive_credential()
    result = await _invoke_google_drive_operation(
        "google_drive.workflow.export",
        inputs={
            "folder_id": folder_id,
            "workflow": package,
            "name": filename,
        },
        credentials=credential,
    )
    return {
        "file_id": result.get("file_id"),
        "name": result.get("name"),
        "web_view_link": result.get("web_view_link"),
        "folder_id": result.get("folder_id"),
    }


@router.get("/google-drive/files", dependencies=_READ_SCOPE)
async def list_google_drive_files(folder_id: str) -> dict[str, Any]:
    normalized_folder_id = str(folder_id or "").strip()
    if not normalized_folder_id:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="folder_id is required.",
        )
    credential = await _load_google_drive_credential()
    result = await _invoke_google_drive_operation(
        "google_drive.workflow.list",
        inputs={"folder_id": normalized_folder_id},
        credentials=credential,
    )
    return {
        "folder_id": result.get("folder_id"),
        "files": result.get("files", []),
    }


@router.post(
    "/google-drive/import-package",
    status_code=status.HTTP_201_CREATED,
    dependencies=_OPERATE_SCOPE,
)
async def import_workflow_package_from_drive(
    payload: dict[str, Any],
    request: Request,
) -> dict[str, Any]:
    file_id = str(payload.get("file_id") or "").strip()
    project_id = str(payload.get("project_id") or "").strip() or None
    working_dir = payload.get("working_dir")
    normalized_working_dir = str(working_dir).strip() if isinstance(working_dir, str) else None
    if not file_id:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="file_id and working_dir-aware workspace context are required.",
        )

    credential = await _load_google_drive_credential()
    result = await _invoke_google_drive_operation(
        "google_drive.workflow.import",
        inputs={"file_id": file_id},
        credentials=credential,
    )
    package = result.get("workflow")
    if not isinstance(package, dict):
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="Google Drive import did not return a workflow package.",
        )

    store = _local_workflow_store(request)
    has_knowledge_docs = bool(
        isinstance(package.get("knowledge_documents"), list)
        and len(package["knowledge_documents"]) > 0
    )
    if has_knowledge_docs:
        try:
            knowledge_repository: KnowledgeRepository | None = _knowledge_repository(
                request,
                project_id=project_id,
                working_dir=normalized_working_dir,
            )
        except ValueError as exc:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=(
                    f"Cannot import knowledge documents: {exc}. "
                    "Select a project with a configured working directory, "
                    "or remove knowledge documents from the package."
                ),
            ) from exc
    else:
        knowledge_repository = _maybe_knowledge_repository(
            request,
            project_id=project_id,
            working_dir=normalized_working_dir,
        )

    try:
        return await asyncio.to_thread(
            WorkflowPackageImporter(
                package=package,
                workflow_store=store,
                knowledge_repository=knowledge_repository,
            ).import_package
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=str(exc),
        ) from exc
