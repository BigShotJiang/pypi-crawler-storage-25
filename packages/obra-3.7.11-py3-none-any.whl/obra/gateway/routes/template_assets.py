"""Canonical Workflow Studio template-asset routes."""

from __future__ import annotations

import asyncio
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Request, status

from obra.gateway.pagination import paginate_collection, pagination_params_from_request
from obra.gateway.security.scopes import GatewayScope, require_scope
from obra.gateway.workflow_studio.repository import WorkflowStudioRepository
from obra.gateway.workflow_studio.template_asset_store_resolver import resolve_template_asset_store
from obra.workflow.template_asset_store import TemplateAssetStore

router = APIRouter(tags=["workflow-studio"])

_READ_SCOPE = [Depends(require_scope(GatewayScope.READ))]
_OPERATE_SCOPE = [Depends(require_scope(GatewayScope.OPERATE))]


@router.get("/api/template-assets/", dependencies=_READ_SCOPE)
async def list_template_assets(request: Request) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    return paginate_collection(
        collection_key="template_assets",
        items=repository.list_template_assets(),
        params=pagination_params_from_request(request),
    )


@router.get("/api/template-assets/{asset_id:path}/revisions", dependencies=_READ_SCOPE)
async def list_template_asset_revisions(
    asset_id: str,
    request: Request,
) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    revisions = repository.list_template_asset_revisions(asset_id)
    if revisions is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Template asset not found"
        )
    return paginate_collection(
        collection_key="revisions",
        items=revisions,
        params=pagination_params_from_request(request),
        extra={"asset_id": asset_id},
    )


@router.get("/api/template-assets/{asset_id:path}/bindings", dependencies=_READ_SCOPE)
async def list_template_asset_bindings(
    asset_id: str,
    request: Request,
) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    bindings = repository.list_template_asset_bindings(asset_id)
    if bindings is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Template asset not found"
        )
    return paginate_collection(
        collection_key="bindings",
        items=bindings,
        params=pagination_params_from_request(request),
        extra={"asset_id": asset_id},
    )


@router.get("/api/template-assets/{asset_id:path}", dependencies=_READ_SCOPE)
async def get_template_asset(asset_id: str, request: Request) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    asset = repository.get_template_asset(asset_id)
    if asset is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Template asset not found"
        )
    return {"template_asset": asset}


@router.get("/api/workflows/{workflow_id}/template-assets", dependencies=_READ_SCOPE)
async def list_workflow_template_assets(
    workflow_id: str,
    request: Request,
) -> dict[str, object]:
    store = _template_asset_store(request)
    items = await asyncio.to_thread(store.list_assets, workflow_id)
    return paginate_collection(
        collection_key="template_assets",
        items=items,
        params=pagination_params_from_request(request),
        extra={"workflow_id": workflow_id},
    )


@router.get(
    "/api/workflows/{workflow_id}/template-assets/{stage_id}/{role}",
    dependencies=_READ_SCOPE,
)
async def get_workflow_template_asset(
    workflow_id: str,
    stage_id: str,
    role: str,
    request: Request,
) -> dict[str, object]:
    store = _template_asset_store(request)
    revision = await asyncio.to_thread(store.resolve, workflow_id, stage_id, role)
    if revision is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Workflow template asset not found",
        )
    revisions = await asyncio.to_thread(store.list_revisions, workflow_id, stage_id, role)
    return {
        "template_asset": {
            "resource_type": "template_asset",
            "asset_id": revision.artifact_id,
            "workflow_id": workflow_id,
            "stage_id": stage_id,
            "role": role,
            "version": revision.version,
            "content": revision.content,
            "content_format": revision.content_format,
            "created_at": revision.created_at.isoformat(),
            "revisions": [item.version for item in revisions],
        }
    }


@router.put(
    "/api/workflows/{workflow_id}/template-assets/{stage_id}/{role}",
    dependencies=_OPERATE_SCOPE,
)
async def put_workflow_template_asset(
    workflow_id: str,
    stage_id: str,
    role: str,
    payload: dict[str, Any],
    request: Request,
) -> dict[str, object]:
    content = str(payload.get("content") or "")
    if not content:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Template asset content is required",
        )
    author_id = str(payload.get("author_id") or "gateway")
    content_format = str(payload.get("content_format") or "markdown")
    store = _template_asset_store(request)
    revision = await asyncio.to_thread(
        store.store,
        workflow_id,
        stage_id,
        role,
        content,
        author_id=author_id,
        content_format=content_format,
    )
    return {
        "template_asset": {
            "resource_type": "template_asset",
            "asset_id": revision.artifact_id,
            "workflow_id": workflow_id,
            "stage_id": stage_id,
            "role": role,
            "version": revision.version,
            "content": revision.content,
            "content_format": revision.content_format,
            "created_at": revision.created_at.isoformat(),
            "author_id": revision.author_id,
        }
    }


def _template_asset_store(request: Request) -> TemplateAssetStore:
    return resolve_template_asset_store(request.app.state)
