"""Catalog discovery routes."""

from __future__ import annotations

from fastapi import APIRouter

from obra.domains import get_available_domains
from obra.gateway.errors import GatewayAPIError
from obra.workflow.runner_catalog_sources import (
    effective_catalog_for_domain,
    project_catalog_entry,
)

router = APIRouter(prefix="/api/catalog", tags=["catalog"])


def _require_known_domain(domain_id: str) -> str:
    normalized = str(domain_id or "").strip()
    if not normalized:
        raise GatewayAPIError(
            error_code="invalid_domain",
            message="domain_id is required",
            status_code=400,
        )
    available = set(get_available_domains())
    if normalized not in available:
        raise GatewayAPIError(
            error_code="unknown_domain",
            message=f"Unknown domain: {normalized}",
            hint=f"Available domains: {', '.join(sorted(available))}",
            status_code=404,
        )
    return normalized


@router.get("/runners")
async def list_catalog_runners(
    domain_id: str,
    kind: str | None = None,
) -> dict[str, object]:
    """Return the effective runner catalog for one domain."""
    normalized_domain = _require_known_domain(domain_id)
    payload = [project_catalog_entry(entry) for entry in effective_catalog_for_domain(normalized_domain)]
    normalized_kind = str(kind or "").strip()
    if normalized_kind:
        payload = [entry for entry in payload if str(entry.get("kind") or "") == normalized_kind]
    return {"runners": payload}
