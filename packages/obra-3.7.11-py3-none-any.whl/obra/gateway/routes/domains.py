"""Gateway route/serialization owner for the Studio domain-manifest contract."""

from __future__ import annotations

from fastapi import APIRouter, Request

from obra.domains.studio_manifest import list_studio_manifests
from obra.gateway.pagination import paginate_collection, pagination_params_from_request

router = APIRouter(prefix="/api/domains", tags=["discovery"])


@router.get("/")
async def list_domains(request: Request) -> dict[str, object]:
    """Return Studio-ready domain manifests."""
    domains = list_studio_manifests()
    return paginate_collection(
        collection_key="domains",
        items=domains,
        params=pagination_params_from_request(request),
    )
