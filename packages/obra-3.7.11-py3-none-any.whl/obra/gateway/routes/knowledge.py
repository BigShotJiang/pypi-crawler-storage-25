"""Knowledge document management API routes."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from fastapi import APIRouter, Depends, File, Form, HTTPException, Request, UploadFile, status
from pydantic import BaseModel, ConfigDict, Field

from obra.gateway.pagination import paginate_collection, pagination_params_from_request
from obra.gateway.routes.assistant_context import build_assistant_request_context
from obra.gateway.security.scopes import GatewayScope, require_scope
from obra.gateway.workflow_studio.policy_memory import PolicyMemoryRecordMutation

router = APIRouter(prefix="/api/knowledge", tags=["knowledge"])

_READ_SCOPE = [Depends(require_scope(GatewayScope.READ))]
_OPERATE_SCOPE = [Depends(require_scope(GatewayScope.OPERATE))]


def _get_knowledge_repo(
    request: Request,
    project_id: str | None = None,
    working_dir: str | None = None,
):
    from obra.config.loaders import get_gateway_assistant_config
    from obra.gateway.workflow_studio.knowledge_repository import KnowledgeRepository

    config = get_gateway_assistant_config()
    context = build_assistant_request_context(
        request,
        project_id=project_id,
        working_dir=working_dir,
        require_working_dir=True,
    )
    if context.working_dir is None:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail="working_dir is required when project_id is omitted",
        )
    project_root = Path(context.working_dir)
    return KnowledgeRepository(
        project_root,
        max_document_bytes=config["knowledge_max_document_bytes"],
        max_total_bytes=config["knowledge_max_total_bytes"],
    )


def _get_policy_memory_repo(
    request: Request,
    project_id: str | None = None,
    working_dir: str | None = None,
):
    from obra.gateway.workflow_studio.policy_memory_repository import PolicyMemoryRepository

    knowledge_repo = _get_knowledge_repo(request, project_id, working_dir)
    context = build_assistant_request_context(
        request,
        project_id=project_id,
        working_dir=working_dir,
        require_working_dir=True,
    )
    if context.working_dir is None:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail="working_dir is required when project_id is omitted",
        )
    project_root = Path(context.working_dir)
    return PolicyMemoryRepository(project_root, knowledge_repository=knowledge_repo)


class PolicyMemoryStatusRequest(BaseModel):
    """Status transition body for typed policy/memory records."""

    model_config = ConfigDict(extra="forbid")

    status: str = Field(..., min_length=1, max_length=64)


@router.get("/records", dependencies=_READ_SCOPE)
async def list_policy_memory_records(
    request: Request,
    project_id: str | None = None,
    workflow_id: str | None = None,
    family: str | None = None,
    status_filter: str | None = None,
    include_legacy_sources: bool = False,
    working_dir: str | None = None,
) -> dict[str, Any]:
    repo = _get_policy_memory_repo(request, project_id, working_dir)
    records = repo.list_records(
        family=family,
        status=status_filter,
        project_id=project_id,
        workflow_id=workflow_id,
    )
    payload = paginate_collection(
        collection_key="records",
        items=records,
        params=pagination_params_from_request(request),
    )
    if include_legacy_sources:
        payload["legacy_sources"] = repo.list_legacy_sources(workflow_id=workflow_id)
    return payload


@router.post("/records", status_code=status.HTTP_201_CREATED, dependencies=_OPERATE_SCOPE)
async def create_policy_memory_record(
    body: PolicyMemoryRecordMutation,
    request: Request,
    project_id: str | None = None,
    working_dir: str | None = None,
) -> dict[str, Any]:
    repo = _get_policy_memory_repo(request, project_id, working_dir)
    try:
        record = repo.create_record(body.model_dump(mode="json"))
    except FileNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(exc)) from exc
    return {"record": record}


@router.get("/records/{record_id}", dependencies=_READ_SCOPE)
async def get_policy_memory_record(
    record_id: str,
    request: Request,
    project_id: str | None = None,
    working_dir: str | None = None,
) -> dict[str, Any]:
    repo = _get_policy_memory_repo(request, project_id, working_dir)
    try:
        record = repo.get_record(record_id)
    except FileNotFoundError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Record not found",
        ) from exc
    return {"record": record}


@router.patch("/records/{record_id}", dependencies=_OPERATE_SCOPE)
async def update_policy_memory_record(
    record_id: str,
    body: PolicyMemoryRecordMutation,
    request: Request,
    project_id: str | None = None,
    working_dir: str | None = None,
) -> dict[str, Any]:
    repo = _get_policy_memory_repo(request, project_id, working_dir)
    try:
        record = repo.update_record(record_id, body.model_dump(mode="json"))
    except FileNotFoundError as exc:
        detail = "Record not found" if "Record not found" in str(exc) else str(exc)
        status_code = status.HTTP_404_NOT_FOUND if detail == "Record not found" else status.HTTP_422_UNPROCESSABLE_ENTITY
        raise HTTPException(status_code=status_code, detail=detail) from exc
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(exc)) from exc
    return {"record": record}


@router.post("/records/{record_id}/status", dependencies=_OPERATE_SCOPE)
async def set_policy_memory_record_status(
    record_id: str,
    body: PolicyMemoryStatusRequest,
    request: Request,
    project_id: str | None = None,
    working_dir: str | None = None,
) -> dict[str, Any]:
    repo = _get_policy_memory_repo(request, project_id, working_dir)
    try:
        record = repo.set_record_status(record_id, body.status)
    except FileNotFoundError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Record not found",
        ) from exc
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(exc)) from exc
    return {"record": record}


@router.get("/resolve", dependencies=_READ_SCOPE)
async def resolve_policy_memory_records(
    request: Request,
    project_id: str | None = None,
    workflow_id: str | None = None,
    family: str | None = None,
    include_draft: bool = False,
    include_legacy_sources: bool = False,
    working_dir: str | None = None,
) -> dict[str, Any]:
    repo = _get_policy_memory_repo(request, project_id, working_dir)
    return repo.resolve_records(
        project_id=project_id,
        workflow_id=workflow_id,
        family=family,
        include_draft=include_draft,
        include_legacy_sources=include_legacy_sources,
    )


@router.post("/documents", status_code=status.HTTP_201_CREATED, dependencies=_OPERATE_SCOPE)
async def upload_document(
    request: Request,
    file: UploadFile = File(...),
    name: str = Form(...),
    scope: str = Form(...),
    project_id: str | None = Form(default=None),
    workflow_id: str | None = Form(default=None),
    description: str | None = Form(default=None),
    working_dir: str | None = Form(default=None),
) -> dict[str, Any]:
    repo = _get_knowledge_repo(request, project_id, working_dir)
    content = await file.read()
    content_type = file.content_type or "text/plain"
    try:
        metadata = repo.add_document(
            name=name,
            content=content,
            content_type=content_type,
            scope=scope,
            workflow_id=workflow_id,
            description=description,
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=str(exc),
        ) from exc
    return {"document": metadata}


@router.get("/documents", dependencies=_READ_SCOPE)
async def list_documents(
    request: Request,
    project_id: str | None = None,
    scope: str | None = None,
    workflow_id: str | None = None,
    working_dir: str | None = None,
) -> dict[str, Any]:
    repo = _get_knowledge_repo(request, project_id, working_dir)
    documents = repo.list_documents(scope=scope, workflow_id=workflow_id)
    return paginate_collection(
        collection_key="documents",
        items=documents,
        params=pagination_params_from_request(request),
    )


@router.get("/documents/{doc_id}", dependencies=_READ_SCOPE)
async def get_document(
    doc_id: str,
    request: Request,
    project_id: str | None = None,
    working_dir: str | None = None,
) -> dict[str, Any]:
    repo = _get_knowledge_repo(request, project_id, working_dir)
    try:
        metadata, content_text = repo.get_document(doc_id)
    except FileNotFoundError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Document not found",
        ) from exc
    return {"document": metadata, "content_text": content_text}


@router.delete(
    "/documents/{doc_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    dependencies=_OPERATE_SCOPE,
)
async def delete_document(
    doc_id: str,
    request: Request,
    project_id: str | None = None,
    working_dir: str | None = None,
) -> None:
    repo = _get_knowledge_repo(request, project_id, working_dir)
    if not repo.delete_document(doc_id):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Document not found",
        )
