"""Canonical Workflow Studio workflow-run routes."""

from __future__ import annotations

import asyncio
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from fastapi.responses import JSONResponse
from obra_business.crosswalk.model_crosswalk import CrossWalkConfirmationRequired
from pydantic import BaseModel, ConfigDict, Field, field_validator

from obra.domains.resolution import DomainResolutionError
from obra.exceptions import APIError
from obra.gateway.automation.workspaces import (
    ensure_project_working_dir,
    validate_payload_filename,
)
from obra.gateway.error_codes import (
    CONFLICT,
    INVALID_REQUEST,
    QUALITY_SCORECARD_FETCH_FAILED,
    RUN_NOT_FOUND,
    STAGE_NOT_FOUND,
    WORKING_DIRECTORY_NOT_ALLOWED,
)
from obra.gateway.errors import GatewayAPIError
from obra.gateway.output_destination import OutputDestination
from obra.gateway.pagination import paginate_collection, pagination_params_from_request
from obra.gateway.routes.crosswalk import (
    raise_crosswalk_confirmation_required,
    serialize_crosswalk_payload,
)
from obra.gateway.security.scopes import GatewayScope, require_scope
from obra.gateway.session_manager import (
    SessionNotFoundError,
    WorkflowRunIdempotencyError,
)
from obra.gateway.studio_browser import is_studio_browser_authenticated_request
from obra.gateway.validation import (
    resolve_input_document_from_workflow,
    validate_input_against_spec,
)
from obra.gateway.workflow_studio.artifacts import build_stage_output_payload
from obra.gateway.workflow_studio.comparison import build_run_comparison
from obra.gateway.workflow_studio.operator_actions import (
    WorkflowMaterializationError,
    WorkflowRunActionService,
    ensure_materialized_execution_input,
    prepare_materialized_workflow_launch,
    require_materialized_crosswalk_confirmation,
)
from obra.gateway.workflow_studio.repository import WorkflowStudioRepository
from obra.gateway.workflow_studio.runs import (
    stage_failure_detail as _stage_failure_detail,
)
from obra.gateway.workflow_studio.runs import (
    stage_quality_loop_state as _stage_quality_loop_state,
)

router = APIRouter(prefix="/api/workflow-runs", tags=["workflow-studio"])

_READ_SCOPE = [Depends(require_scope(GatewayScope.READ))]
_OPERATE_SCOPE = [Depends(require_scope(GatewayScope.OPERATE))]


class CreateWorkflowRunRequest(BaseModel):
    """Request body for creating a canonical workflow run."""

    model_config = ConfigDict(extra="forbid")

    objective: str = Field(..., max_length=10_000)
    project_id: str | None = Field(default=None, max_length=256)
    working_dir: str | None = Field(default=None, min_length=1, max_length=4096)
    workflow_id: str | None = None
    revision_id: str | None = None
    domain_id: str | None = None
    parent_payload: dict[str, Any] = Field(default_factory=dict)
    launch_metadata: dict[str, Any] = Field(default_factory=dict)
    input_manifest: list[str] | None = None
    input_payload: dict[str, str] | None = None
    idempotency_key: str | None = Field(default=None, max_length=256)
    output_destination: OutputDestination | None = None

    @field_validator(
        "project_id", "workflow_id", "revision_id", "domain_id", "idempotency_key", mode="before"
    )
    @classmethod
    def _normalize_optional_strings(cls, value: Any) -> str | None:
        if value is None:
            return None
        if isinstance(value, str):
            normalized = value.strip()
            return normalized or None
        return value

    @field_validator("input_payload")
    @classmethod
    def _validate_input_payload(cls, value: dict[str, str] | None) -> dict[str, str] | None:
        for filename in (value or {}):
            validate_payload_filename(filename)
        return value


class BatchCreateWorkflowRunRequest(BaseModel):
    """Request body for batch workflow run creation."""

    model_config = ConfigDict(extra="forbid")

    items: list[CreateWorkflowRunRequest] = Field(..., min_length=1, max_length=50)


class ResumeWorkflowRunRequest(BaseModel):
    """Request body for resuming a workflow run."""

    resume_target: str | None = None


class ValidateInputRequest(BaseModel):
    """Request body for workflow input pre-flight validation."""

    model_config = ConfigDict(extra="forbid")

    workflow_id: str = Field(..., max_length=256)
    input_payload: dict[str, str] | None = None


class OperatorActionRequest(BaseModel):
    """Request body for operator actions."""

    action: str = Field(..., max_length=128)
    payload: dict[str, Any] = Field(default_factory=dict)


class ResolveEscalationRequest(BaseModel):
    """Request body for escalation resolution."""

    choice: str = Field(..., max_length=128)
    was_timeout: bool = False


@router.get("/", dependencies=_READ_SCOPE)
async def list_workflow_runs(
    request: Request,
    workflow_id: str | None = Query(default=None, max_length=256),
) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    return paginate_collection(
        collection_key="workflow_runs",
        items=repository.list_runs(workflow_id=workflow_id),
        params=pagination_params_from_request(request),
    )


@router.get("/compare", dependencies=_READ_SCOPE)
async def compare_workflow_runs(
    request: Request,
    run_ids: str = Query(..., description="Comma-separated run IDs"),
) -> dict[str, Any]:
    normalized_run_ids = list(
        dict.fromkeys(run_id.strip() for run_id in run_ids.split(",") if run_id.strip())
    )
    if len(normalized_run_ids) < 2:
        raise GatewayAPIError(
            error_code=INVALID_REQUEST,
            message="At least two run_ids are required",
            status_code=status.HTTP_400_BAD_REQUEST,
        )
    if len(normalized_run_ids) > 10:
        raise GatewayAPIError(
            error_code=INVALID_REQUEST,
            message="At most 10 run_ids are allowed",
            status_code=status.HTTP_400_BAD_REQUEST,
        )

    repository = WorkflowStudioRepository.from_request(request)
    bundles = []
    for run_id in normalized_run_ids:
        try:
            bundles.append(repository.get_run_bundle(run_id))
        except (KeyError, SessionNotFoundError) as exc:
            raise GatewayAPIError(
                error_code=RUN_NOT_FOUND,
                message=f"Run not found: {run_id}",
                status_code=status.HTTP_404_NOT_FOUND,
            ) from exc
    try:
        quality_scorecards_by_run = repository.list_quality_scorecards_for_runs(bundles)
    except APIError as exc:
        raise GatewayAPIError.from_api_error(
            exc,
            default_error_code=QUALITY_SCORECARD_FETCH_FAILED,
            default_message="Failed to load quality scorecards for run comparison",
        ) from exc
    policy_memory_records_by_run = repository.list_policy_memory_records_for_runs(bundles)
    return build_run_comparison(
        bundles,
        quality_scorecards_by_run=quality_scorecards_by_run,
        policy_memory_records_by_run=policy_memory_records_by_run,
    )


@router.post("/", status_code=status.HTTP_201_CREATED, dependencies=_OPERATE_SCOPE)
async def create_workflow_run(
    body: CreateWorkflowRunRequest,
    request: Request,
) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    validation_errors = _validate_workflow_run_inputs(body, repository)
    if validation_errors:
        return JSONResponse(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            content={
                "error_code": "validation_error",
                "message": "Request failed",
                "hint": None,
                "validation_errors": validation_errors,
            },
        )
    try:
        workflow_run = _create_workflow_run_record(body, request, repository=repository)
    except CrossWalkConfirmationRequired as exc:
        return JSONResponse(
            status_code=status.HTTP_409_CONFLICT,
            content={
                "error_code": "crosswalk_confirmation_required",
                "message": str(exc),
                "hint": None,
                "workflow_id": exc.workflow_id,
                "path": str(exc.path),
                "crosswalk": serialize_crosswalk_payload(
                    exc.workflow_id,
                    exc.crosswalk,
                    Path(exc.path).parent.parent.parent,
                ),
            },
        )
    return {"workflow_run": workflow_run}


@router.post("/batch", status_code=status.HTTP_201_CREATED, dependencies=_OPERATE_SCOPE)
async def create_workflow_run_batch(
    body: BatchCreateWorkflowRunRequest,
    request: Request,
) -> dict[str, Any]:
    repository = WorkflowStudioRepository.from_request(request)
    max_concurrency = int(request.app.state.gateway_config["batch_max_concurrency"])
    semaphore = asyncio.Semaphore(max_concurrency)

    async def _process_item(index: int, item: CreateWorkflowRunRequest) -> dict[str, Any]:
        async with semaphore:
            validation_errors = _validate_workflow_run_inputs(item, repository)
            if validation_errors:
                return {
                    "index": index,
                    "error": {
                        "error_code": "validation_error",
                        "message": "Request failed",
                        "status_code": status.HTTP_422_UNPROCESSABLE_CONTENT,
                        "validation_errors": validation_errors,
                    },
                }
            try:
                workflow_run = await asyncio.to_thread(
                    _create_workflow_run_record,
                    item,
                    request,
                    repository,
                )
            except GatewayAPIError as exc:
                return {
                    "index": index,
                    "error": {
                        "error_code": exc.error_code,
                        "message": exc.message,
                        "status_code": exc.status_code,
                        "hint": exc.hint,
                    },
                }
            except CrossWalkConfirmationRequired as exc:
                return {
                    "index": index,
                    "error": {
                        "error_code": "crosswalk_confirmation_required",
                        "message": str(exc),
                        "status_code": status.HTTP_409_CONFLICT,
                        "hint": None,
                        "workflow_id": exc.workflow_id,
                        "path": str(exc.path),
                        "crosswalk": serialize_crosswalk_payload(
                            exc.workflow_id,
                            exc.crosswalk,
                            Path(exc.path).parent.parent.parent,
                        ),
                    },
                }
            run_id = str(workflow_run.get("workflow_run_id") or workflow_run.get("run_id") or "")
            return {
                "index": index,
                "run_id": run_id,
                "workflow_run": workflow_run,
            }

    results = await asyncio.gather(
        *(_process_item(index, item) for index, item in enumerate(body.items))
    )
    return {"results": results}


@router.post("/validate-input", dependencies=_READ_SCOPE)
async def validate_input(body: ValidateInputRequest, request: Request) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    workflow = repository.get_workflow(body.workflow_id)
    if workflow is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Workflow not found")

    input_document = resolve_input_document_from_workflow(workflow)
    if input_document is None:
        return {
            "valid": True,
            "errors": [],
            "workflow_id": body.workflow_id,
            "note": "No input spec defined for this workflow",
        }

    errors = validate_input_against_spec(input_document, body.input_payload)
    return {
        "valid": len(errors) == 0,
        "errors": errors,
        "workflow_id": body.workflow_id,
    }


@router.get("/{run_id}", dependencies=_READ_SCOPE)
async def get_workflow_run(run_id: str, request: Request) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    workflow_run = repository.get_run(run_id)
    if workflow_run is None:
        raise GatewayAPIError(
            error_code=RUN_NOT_FOUND,
            message="Workflow run not found",
            status_code=status.HTTP_404_NOT_FOUND,
        )
    return {"workflow_run": workflow_run}


@router.get("/{run_id}/wait", dependencies=_READ_SCOPE)
async def wait_for_workflow_run(
    run_id: str,
    request: Request,
    since_status: str | None = Query(default=None),
    timeout_s: float | None = Query(default=None, gt=0),
) -> dict[str, object]:
    """Long-poll for a workflow-run status change with a configured timeout cap.

    The cap prevents indefinite request occupation under load while matching
    LLM-operator clients that wait with a reasonable upper bound and then
    re-poll when needed.
    """
    gateway_config = request.app.state.gateway_config
    resolved_timeout_s = (
        float(timeout_s)
        if timeout_s is not None
        else float(gateway_config["workflow_run_wait_default_timeout_s"])
    )
    max_timeout_s = float(gateway_config["workflow_run_wait_max_timeout_s"])
    if resolved_timeout_s > max_timeout_s:
        raise GatewayAPIError(
            error_code=INVALID_REQUEST,
            message="Requested timeout exceeds configured workflow-run wait maximum",
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
        )
    repository = WorkflowStudioRepository.from_request(request)
    try:
        workflow_run = await repository.wait_for_status_change(
            run_id,
            since_status=since_status,
            timeout_s=resolved_timeout_s,
        )
    except SessionNotFoundError as exc:
        raise GatewayAPIError(
            error_code=RUN_NOT_FOUND,
            message="Workflow run not found",
            status_code=status.HTTP_404_NOT_FOUND,
        ) from exc
    return {"workflow_run": workflow_run}


@router.get("/{run_id}/lineage", dependencies=_READ_SCOPE)
async def get_workflow_run_lineage(run_id: str, request: Request) -> dict[str, Any]:
    repository = WorkflowStudioRepository.from_request(request)
    try:
        lineage = repository.get_run_lineage(run_id)
    except SessionNotFoundError as exc:
        raise GatewayAPIError(
            error_code=RUN_NOT_FOUND,
            message="Workflow run not found",
            status_code=status.HTTP_404_NOT_FOUND,
        ) from exc
    return {"lineage": lineage}


@router.post("/{run_id}/cancel", dependencies=_OPERATE_SCOPE)
async def cancel_workflow_run(run_id: str, request: Request) -> dict[str, object]:
    service = WorkflowRunActionService(request.app.state.session_manager)
    try:
        return service.cancel(
            run_id,
            client_request_id=_client_request_id(request),
        )
    except Exception as exc:
        raise GatewayAPIError(
            error_code=RUN_NOT_FOUND,
            message="Workflow run not found",
            status_code=status.HTTP_404_NOT_FOUND,
        ) from exc


@router.post("/{run_id}/resume", dependencies=_OPERATE_SCOPE)
async def resume_workflow_run(
    run_id: str,
    body: ResumeWorkflowRunRequest,
    request: Request,
) -> dict[str, object]:
    service = WorkflowRunActionService(request.app.state.session_manager)
    try:
        return service.resume(
            run_id,
            resume_target=body.resume_target,
            client_request_id=_client_request_id(request),
        )
    except ValueError as exc:
        raise GatewayAPIError(
            error_code=CONFLICT,
            message=str(exc),
            status_code=status.HTTP_409_CONFLICT,
        ) from exc
    except Exception as exc:
        raise GatewayAPIError(
            error_code=RUN_NOT_FOUND,
            message="Workflow run not found",
            status_code=status.HTTP_404_NOT_FOUND,
        ) from exc


@router.post("/{run_id}/operator-actions", dependencies=_OPERATE_SCOPE)
async def perform_operator_action(
    run_id: str,
    body: OperatorActionRequest,
    request: Request,
) -> dict[str, object]:
    service = WorkflowRunActionService(request.app.state.session_manager)
    return service.dispatch(
        run_id,
        action=body.action,
        payload=body.payload,
        client_request_id=_client_request_id(request),
    )


@router.post(
    "/{run_id}/escalations/{escalation_id}/resolve",
    dependencies=_OPERATE_SCOPE,
)
async def resolve_workflow_run_escalation(
    run_id: str,
    escalation_id: str,
    body: ResolveEscalationRequest,
    request: Request,
) -> dict[str, object]:
    service = WorkflowRunActionService(request.app.state.session_manager)
    return service.resolve_escalation(
        run_id,
        escalation_id,
        choice=body.choice,
        was_timeout=body.was_timeout,
        client_request_id=_client_request_id(request),
    )


@router.get("/{run_id}/stages", dependencies=_READ_SCOPE)
async def list_run_stages(run_id: str, request: Request) -> dict[str, Any]:
    bundle = _get_run_bundle(request, run_id)
    stages = _project_pipeline_stages_for_terminal_run(bundle)
    return paginate_collection(
        collection_key="stages",
        items=[_stage_summary(stage) for stage in stages],
        params=pagination_params_from_request(request),
    )


@router.get("/{run_id}/stages/{stage_name}", dependencies=_READ_SCOPE)
async def get_run_stage(run_id: str, stage_name: str, request: Request) -> dict[str, Any]:
    bundle = _get_run_bundle(request, run_id)
    stages = _project_pipeline_stages_for_terminal_run(bundle)
    stage = next(
        (
            candidate
            for candidate in stages
            if str(candidate.get("stage_name") or candidate.get("trigger") or "") == stage_name
        ),
        None,
    )
    if stage is None:
        raise GatewayAPIError(
            error_code=STAGE_NOT_FOUND,
            message=f"Stage {stage_name} not found in run {run_id}",
            status_code=404,
        )

    execution_status = stage.get("execution_status") or stage.get("status")
    quality_loop_state = _stage_quality_loop_state(stage)
    return {
        "stage": {
            "stage_name": str(stage.get("stage_name") or stage.get("trigger") or ""),
            "status": stage.get("status"),
            "runner_kind": stage.get("runner_kind"),
            "execution_status": execution_status,
            "duration_s": _stage_duration_s(stage),
            "iteration_count": _stage_iteration_count(stage),
            "output_artifacts": _stage_output_artifacts(stage),
            "metadata": {
                "last_result": dict(stage.get("last_result") or {}),
                "started_at": stage.get("started_at"),
                "completed_at": stage.get("completed_at"),
                "resume_metadata": dict(stage.get("resume_metadata") or {}),
                "pending_manual_metadata": dict(stage.get("pending_manual_metadata") or {}),
            },
            "quality_loop_state": quality_loop_state,
            "failure_detail": _stage_failure_detail(
                stage,
                execution_status=execution_status,
                quality_loop_state=quality_loop_state,
            ),
        }
    }


@router.get("/{run_id}/summary", dependencies=_READ_SCOPE)
async def get_run_summary(run_id: str, request: Request) -> dict[str, Any]:
    bundle = _get_run_bundle(request, run_id)
    stages = _project_pipeline_stages_for_terminal_run(bundle)
    normalized_statuses = [
        str(stage.get("execution_status") or stage.get("status") or "unknown") for stage in stages
    ]
    stages_by_status = Counter(normalized_statuses)
    total_duration_s = sum(
        duration
        for duration in (_stage_duration_s(stage) for stage in stages)
        if duration is not None
    )
    failed_stages = []
    for stage in stages:
        execution_status = str(stage.get("execution_status") or stage.get("status") or "")
        if execution_status.lower() not in {"failed", "error"}:
            continue
        last_result = stage.get("last_result")
        if not isinstance(last_result, dict):
            last_result = {}
        failed_stages.append(
            {
                "stage_name": str(stage.get("stage_name") or stage.get("trigger") or ""),
                "reason_code": (
                    last_result.get("reason_code")
                    or last_result.get("error_code")
                    or stage.get("outcome")
                    or execution_status
                ),
            }
        )

    overall_outcome = "in_progress"
    lowered_statuses = [status_name.lower() for status_name in normalized_statuses]
    if stages and all(
        status_name in {"completed", "passed", "success"} for status_name in lowered_statuses
    ):
        overall_outcome = "success"
    elif stages and all(status_name in {"failed", "error"} for status_name in lowered_statuses):
        overall_outcome = "failure"
    elif any(status_name in {"failed", "error"} for status_name in lowered_statuses):
        overall_outcome = "partial_failure"

    return {
        "summary": {
            "total_stages": len(stages),
            "stages_by_status": dict(stages_by_status),
            "total_duration_s": total_duration_s,
            "failed_stages": failed_stages,
            "overall_outcome": overall_outcome,
        }
    }


def _project_pipeline_stages_for_terminal_run(bundle: Any) -> list[dict[str, Any]]:
    """Return stage rows with terminal run status reflected in wrapper stages."""
    stages = [dict(stage) for stage in (bundle.pipeline_stages or []) if isinstance(stage, dict)]
    record_status = str(getattr(bundle.record, "status", "") or "").strip().lower()
    if record_status not in {"completed", "cancelled"}:
        return stages

    terminal_stage_status = "completed" if record_status == "completed" else "cancelled"
    terminal_outcome = "passed" if record_status == "completed" else "cancelled"
    updated_at = (
        bundle.remote_session.get("updated_at")
        if isinstance(getattr(bundle, "remote_session", None), dict)
        else None
    )
    for stage in stages:
        stage_status = str(stage.get("execution_status") or stage.get("status") or "").strip().lower()
        if stage_status in {"running", "in_progress", "started", "pending", ""}:
            stage["execution_status"] = terminal_stage_status
            stage["status"] = terminal_stage_status
            stage.setdefault("outcome", terminal_outcome)
            if updated_at and not stage.get("completed_at"):
                stage["completed_at"] = updated_at
    return stages


@router.get("/{run_id}/escalations", dependencies=_READ_SCOPE)
async def list_run_escalations(run_id: str, request: Request) -> dict[str, Any]:
    bundle = _get_run_bundle(request, run_id)
    by_escalation_id: dict[str, dict[str, Any]] = {}
    active_escalation_id = str(bundle.record.escalation_id or "").strip()
    blocking_summary = (
        dict(bundle.record.blocking_summary)
        if isinstance(bundle.record.blocking_summary, dict)
        else {}
    )
    current_stage = (
        dict(bundle.record.current_stage) if isinstance(bundle.record.current_stage, dict) else {}
    )

    if active_escalation_id:
        by_escalation_id[active_escalation_id] = {
            "escalation_id": active_escalation_id,
            "reason": str(
                blocking_summary.get("reason") or blocking_summary.get("state") or "pending"
            ),
            "status": "pending",
            "stage_name": current_stage.get("stage_name"),
            "created": bundle.record.created_at.isoformat(),
        }

    for event in bundle.remote_events:
        payload = event.get("payload")
        if not isinstance(payload, dict):
            payload = {}
        event_type = str(event.get("event_type") or event.get("type") or "")
        escalation_id = str(
            event.get("escalation_id") or payload.get("escalation_id") or ""
        ).strip()
        if not escalation_id:
            if event_type != "escalation_notice":
                continue
            escalation_id = str(payload.get("id") or "").strip()
            if not escalation_id:
                continue
        created = _event_timestamp(event, default=bundle.record.created_at.isoformat())
        entry = {
            "escalation_id": escalation_id,
            "reason": str(payload.get("reason") or event.get("message") or "escalation"),
            "status": "pending" if escalation_id == active_escalation_id else "resolved",
            "stage_name": payload.get("stage_name") or event.get("stage_name"),
            "created": created,
        }
        existing = by_escalation_id.get(escalation_id)
        if existing is None or created >= str(existing.get("created") or ""):
            by_escalation_id[escalation_id] = entry

    return paginate_collection(
        collection_key="escalations",
        items=sorted(
            by_escalation_id.values(),
            key=lambda item: str(item.get("created") or ""),
            reverse=True,
        ),
        params=pagination_params_from_request(request),
    )


@router.get("/{run_id}/review-state", dependencies=_READ_SCOPE)
async def get_run_review_state(run_id: str, request: Request) -> dict[str, Any]:
    bundle = _get_run_bundle(request, run_id)
    quality_loop_decisions = _collect_quality_loop_decisions(bundle)
    reviewer_findings = _collect_reviewer_findings(bundle)
    iteration_counts = {
        str(stage.get("stage_name") or stage.get("trigger") or ""): _stage_iteration_count(stage)
        for stage in bundle.pipeline_stages
        if str(stage.get("stage_name") or stage.get("trigger") or "").strip()
    }
    quality_scorecards = _fetch_quality_scorecards(request, run_id, bundle)
    return {
        "review_state": {
            "quality_loop_decisions": quality_loop_decisions,
            "iteration_counts": iteration_counts,
            "reviewer_findings": reviewer_findings,
            "quality_scorecards": quality_scorecards,
        }
    }


@router.get("/{run_id}/outputs", dependencies=_READ_SCOPE)
async def get_run_outputs(run_id: str, request: Request) -> dict[str, Any]:
    bundle = _get_run_bundle(request, run_id)
    return build_stage_output_payload(
        workflow_artifacts=bundle.workflow_artifacts,
        pipeline_stages=bundle.pipeline_stages,
    )


def _validate_workflow_run_inputs(
    body: CreateWorkflowRunRequest,
    repository: WorkflowStudioRepository,
) -> list[str]:
    if body.workflow_id is None:
        return []
    workflow = repository.get_workflow(body.workflow_id)
    if workflow is None:
        return []
    input_document = resolve_input_document_from_workflow(workflow)
    if input_document is None:
        return []
    return validate_input_against_spec(input_document, body.input_payload)


def _create_workflow_run_record(
    body: CreateWorkflowRunRequest,
    request: Request,
    repository: WorkflowStudioRepository,
) -> dict[str, Any]:
    session_manager = request.app.state.session_manager
    client_factory = getattr(request.app.state, "workflow_studio_client_factory", None)
    if callable(client_factory):
        session_manager.set_client_factory(client_factory)
    working_dir = _resolve_workflow_run_working_dir(body, request)
    if body.workflow_id is not None and is_studio_browser_authenticated_request(request):
        raise_crosswalk_confirmation_required(
            request,
            workflow_id=body.workflow_id,
            project_id=body.project_id,
            working_dir=working_dir,
            revision_id=body.revision_id,
            domain_id=body.domain_id,
        )
    try:
        materialized = prepare_materialized_workflow_launch(
            working_dir=working_dir,
            workflow_id=body.workflow_id,
            revision_id=body.revision_id,
            repository=repository,
        )
        require_materialized_crosswalk_confirmation(
            materialized=materialized,
            workflow_id=body.workflow_id,
        )
        ensure_materialized_execution_input(
            materialized=materialized,
            objective=body.objective,
            input_manifest=body.input_manifest,
            input_payload=body.input_payload,
        )
    except WorkflowMaterializationError as exc:
        raise GatewayAPIError(
            error_code=exc.code,
            message=str(exc),
            status_code=status.HTTP_400_BAD_REQUEST,
        ) from exc
    try:
        run_id = session_manager.create_workflow_run(
            objective=body.objective,
            project_id=body.project_id,
            working_dir=working_dir,
            workflow_id=body.workflow_id,
            revision_id=body.revision_id,
            domain_id=body.domain_id,
            parent_payload=body.parent_payload,
            launch_metadata=body.launch_metadata,
            input_manifest=body.input_manifest,
            input_payload=body.input_payload,
            idempotency_key=body.idempotency_key,
            output_destination=(
                body.output_destination.model_dump() if body.output_destination is not None else None
            ),
        )
    except DomainResolutionError as exc:
        raise GatewayAPIError(
            error_code=exc.code,
            message=str(exc),
            status_code=exc.http_status.value,
        ) from exc
    except WorkflowRunIdempotencyError as exc:
        raise GatewayAPIError(
            error_code=CONFLICT,
            message=str(exc),
            status_code=status.HTTP_409_CONFLICT,
        ) from exc
    except ValueError as exc:
        from obra.utils.obra_home import resolve_runtime_dir

        log_path = resolve_runtime_dir() / "studio" / "gateway.log"
        raise GatewayAPIError(
            error_code=WORKING_DIRECTORY_NOT_ALLOWED,
            message=f"Working directory invalid: {exc}",
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            hint=f"Check the gateway log for details: {log_path}",
        ) from exc

    return repository.get_run(run_id) or {"run_id": run_id, "workflow_run_id": run_id}


def _client_request_id(request: Request) -> str | None:
    value = (
        request.headers.get("X-Obra-Client-Request-Id", "").strip()
        or request.headers.get("X-Client-Request-Id", "").strip()
    )
    return value or None


def _resolve_workflow_run_working_dir(
    body: CreateWorkflowRunRequest,
    request: Request,
) -> str:
    if body.working_dir is not None:
        return body.working_dir

    if body.project_id is None:
        raise GatewayAPIError(
            error_code=INVALID_REQUEST,
            message="working_dir is required when project_id is omitted",
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        )

    try:
        return ensure_project_working_dir(request, project_id=body.project_id)
    except APIError as exc:
        raise GatewayAPIError.from_api_error(
            exc,
            default_error_code="project_not_found",
            default_message=f"Failed to load project {body.project_id}",
        ) from exc
    except ValueError as exc:
        raise GatewayAPIError(
            error_code=INVALID_REQUEST,
            message=str(exc),
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        ) from exc


def _get_run_bundle(request: Request, run_id: str) -> Any:
    repository = WorkflowStudioRepository.from_request(request)
    try:
        return repository.get_run_bundle(run_id)
    except SessionNotFoundError as exc:
        raise GatewayAPIError(
            error_code=RUN_NOT_FOUND,
            message=f"Workflow run {run_id} not found",
            status_code=404,
        ) from exc


def _stage_summary(stage: dict[str, Any]) -> dict[str, Any]:
    execution_status = stage.get("execution_status") or stage.get("status")
    return {
        "stage_name": str(stage.get("stage_name") or stage.get("trigger") or ""),
        "status": stage.get("status"),
        "runner_kind": stage.get("runner_kind"),
        "execution_status": execution_status,
        "duration_s": _stage_duration_s(stage),
        "iteration_count": _stage_iteration_count(stage),
        "reason_code": _stage_reason_code(stage, execution_status=execution_status),
    }


def _stage_iteration_count(stage: dict[str, Any]) -> int:
    try:
        return int(stage.get("iteration") or 0)
    except (TypeError, ValueError):
        return 0


def _stage_duration_s(stage: dict[str, Any]) -> float | None:
    last_result = stage.get("last_result")
    if isinstance(last_result, dict):
        duration = last_result.get("duration_s")
        if isinstance(duration, int | float):
            return float(duration)
        if isinstance(duration, str):
            try:
                return float(duration)
            except ValueError:
                pass
    started_at = _parse_datetime(stage.get("started_at"))
    completed_at = _parse_datetime(stage.get("completed_at"))
    if started_at is None or completed_at is None:
        return None
    return max((completed_at - started_at).total_seconds(), 0.0)


def _parse_datetime(value: Any) -> datetime | None:
    if not isinstance(value, str) or not value:
        return None
    normalized = value.replace("Z", "+00:00")
    try:
        return datetime.fromisoformat(normalized)
    except ValueError:
        return None


def _stage_output_artifacts(stage: dict[str, Any]) -> list[dict[str, Any]]:
    output_artifacts: list[dict[str, Any]] = []
    for field_name in (
        "stage_output_artifact_refs",
        "accepted_stage_output_artifact_refs",
        "candidate_stage_output_artifact_refs",
    ):
        raw_refs = stage.get(field_name)
        if not isinstance(raw_refs, list):
            continue
        for item in raw_refs:
            if isinstance(item, dict):
                output_artifacts.append(dict(item))
    return output_artifacts


def _stage_reason_code(
    stage: dict[str, Any],
    *,
    execution_status: Any,
) -> str | None:
    if str(execution_status or "").lower() not in {"failed", "error"}:
        return None
    last_result = stage.get("last_result")
    if not isinstance(last_result, dict):
        last_result = {}
    reason_code = (
        last_result.get("reason_code")
        or last_result.get("error_code")
        or stage.get("outcome")
        or None
    )
    return str(reason_code) if reason_code is not None else None


def _event_timestamp(event: dict[str, Any], *, default: str) -> str:
    for key in ("timestamp", "created_at", "occurred_at", "updated_at"):
        value = event.get(key)
        if isinstance(value, str) and value:
            return value
    payload = event.get("payload")
    if isinstance(payload, dict):
        for key in ("timestamp", "created_at", "occurred_at", "updated_at"):
            value = payload.get(key)
            if isinstance(value, str) and value:
                return value
    return default


def _collect_quality_loop_decisions(bundle: Any) -> list[dict[str, Any]]:
    decisions: list[dict[str, Any]] = []
    for source_name, payload in (
        ("workflow_lifecycle_decisions", bundle.remote_session.get("workflow_lifecycle_decisions")),
        (
            "resume_context.lifecycle_decisions",
            _dict_value(bundle.remote_session.get("resume_context")).get("lifecycle_decisions"),
        ),
    ):
        if isinstance(payload, dict) and payload:
            decisions.append({"source": source_name, **dict(payload)})

    for stage in bundle.pipeline_stages:
        quality_loop_state = _stage_quality_loop_state(stage)
        if quality_loop_state is None:
            continue
        decisions.append(
            {
                "source": "pipeline_stage",
                "stage_name": stage.get("stage_name") or stage.get("trigger"),
                **quality_loop_state,
            }
        )

    for event in bundle.remote_events:
        payload = event.get("payload")
        if not isinstance(payload, dict):
            continue
        if any(key in payload for key in ("loop_verdict", "loop_state", "quality_decision")):
            decisions.append(
                {
                    "source": "remote_event",
                    "event_type": event.get("event_type") or event.get("type"),
                    "stage_name": payload.get("stage_name"),
                    **dict(payload),
                }
            )
    return decisions


def _collect_reviewer_findings(bundle: Any) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    for event in bundle.remote_events:
        payload = event.get("payload")
        if not isinstance(payload, dict):
            payload = {}
        if isinstance(payload.get("reviewer_findings"), list):
            for finding in payload["reviewer_findings"]:
                if isinstance(finding, dict):
                    findings.append(
                        {
                            "source": "remote_event",
                            "event_type": event.get("event_type") or event.get("type"),
                            **dict(finding),
                        }
                    )
            continue
        if any(
            key in payload for key in ("review_feedback", "finding", "quality_verdict", "issues")
        ):
            findings.append(
                {
                    "source": "remote_event",
                    "event_type": event.get("event_type") or event.get("type"),
                    **dict(payload),
                }
            )
    return findings


def _fetch_quality_scorecards(request: Request, run_id: str, bundle: Any) -> list[dict[str, Any]]:
    repository = WorkflowStudioRepository.from_request(request)
    try:
        return repository.get_run_quality_scorecards(run_id, bundle=bundle)
    except APIError as exc:
        raise GatewayAPIError.from_api_error(
            exc,
            default_error_code=QUALITY_SCORECARD_FETCH_FAILED,
            default_message=f"Failed to load quality scorecard for run {run_id}",
        ) from exc


def _dict_value(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return dict(value)
    return {}
