"""Onboarding API routes for desktop provider setup.

These endpoints live on the Studio browser-session surface (no global
bearer dependency) but require an active Studio browser session.
"""

from __future__ import annotations

import asyncio
import threading
import time
from http import HTTPStatus
from typing import Any

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import JSONResponse

from obra.config.loaders import get_gateway_onboarding_config
from obra.gateway.providers.onboarding_state import OnboardingState
from obra.gateway.providers.registry import ProviderEntry, ProviderRegistry
from obra.gateway.studio_browser import (
    is_studio_browser_authenticated_request,
)

router = APIRouter(prefix="/api/onboarding", tags=["onboarding"])

# Module-level singletons (initialized lazily on first request).
_registry: ProviderRegistry | None = None
_onboarding_state: OnboardingState | None = None

# Server-side cache for provider health checks.  Keyed by provider_id,
# values are ``(result_dict, expiry_monotonic)``.  Prevents repeated
# subprocess invocations when the frontend polls every N seconds.
_health_cache: dict[str, tuple[dict[str, Any], float]] = {}

# Per-provider locks to prevent cache stampedes.  Without these, two
# concurrent ``asyncio.to_thread`` workers hitting the same expired
# cache entry would both spawn a subprocess / network probe.
_health_check_locks: dict[str, threading.Lock] = {}
_health_check_locks_guard = threading.Lock()

# Session-scoped dismissed providers (in-memory, resets on gateway
# restart).  Dismissed providers are not checked during status polls.
_dismissed_providers: set[str] = set()


def _provider_lock(provider_id: str) -> threading.Lock:
    """Return (or lazily create) the per-provider stampede lock."""
    lock = _health_check_locks.get(provider_id)
    if lock is not None:
        return lock
    with _health_check_locks_guard:
        # Double-check after acquiring the guard.
        if provider_id not in _health_check_locks:
            _health_check_locks[provider_id] = threading.Lock()
        return _health_check_locks[provider_id]


def _invalidate_health_cache(provider_id: str) -> None:
    """Remove a provider's cached health result."""
    _health_cache.pop(provider_id, None)


def _get_cached_auth_check(
    provider_id: str,
    check_fn: Any,
    ttl_s: float,
) -> dict[str, Any]:
    """Return a cached auth check result, or run *check_fn* and cache it.

    Uses a per-provider lock so concurrent threads (from parallel
    ``asyncio.to_thread`` calls) don't stampede through an expired
    cache entry and spawn duplicate subprocess / network checks.
    """
    # Fast path — cache hit, no lock needed.
    cached = _health_cache.get(provider_id)
    if cached is not None:
        result, expiry = cached
        if time.monotonic() < expiry:
            return result

    # Slow path — acquire the provider lock, re-check, then run.
    with _provider_lock(provider_id):
        cached = _health_cache.get(provider_id)
        if cached is not None:
            result, expiry = cached
            if time.monotonic() < expiry:
                return result

        try:
            result = check_fn()
        except Exception:
            result = {"authenticated": False, "auth_issue": "check_failed"}

        _health_cache[provider_id] = (result, time.monotonic() + ttl_s)
        return result


def _get_registry() -> ProviderRegistry:
    global _registry
    if _registry is None:
        config = get_gateway_onboarding_config()
        _registry = ProviderRegistry(config.get("providers"))
    return _registry


def _get_state() -> OnboardingState:
    global _onboarding_state
    if _onboarding_state is None:
        _onboarding_state = OnboardingState()
    return _onboarding_state


def _require_session(request: Request) -> None:
    """Enforce an active Studio browser session."""
    if not is_studio_browser_authenticated_request(request):
        raise HTTPException(
            status_code=HTTPStatus.UNAUTHORIZED,
            detail="Studio browser session required",
        )


def _check_single_provider(
    provider: ProviderEntry,
    registry: ProviderRegistry,
    health_ttl_s: float,
) -> tuple[str, dict[str, Any]]:
    """Run detection + cached auth check for one provider (blocking).

    Returns ``(provider_id, status_dict)``.  Designed to be called via
    ``asyncio.to_thread`` so it doesn't block the event loop.
    """
    if provider.provider_id in _dismissed_providers:
        return provider.provider_id, {
            "installed": False,
            "authenticated": False,
            "auth_healthy": False,
            "auth_issue": "dismissed",
            "auth_method": provider.auth_method,
            "display_name": provider.display_name,
        }

    # Live detection.
    try:
        detection_handler = registry.resolve_detection_handler(provider.provider_id)
        detection = detection_handler()
    except Exception:
        detection = {"installed": False}

    # Cached auth check.
    check_fn = registry.resolve_check_handler(provider.provider_id)
    auth_status = _get_cached_auth_check(provider.provider_id, check_fn, health_ttl_s)

    status: dict[str, Any] = {
        "installed": detection.get("installed", False),
        "authenticated": auth_status.get("authenticated", False),
        "auth_healthy": auth_status.get("authenticated", False),
        "auth_issue": auth_status.get("auth_issue"),
        "auth_method": provider.auth_method,
        "display_name": provider.display_name,
        "version": detection.get("version"),
        "path": detection.get("path"),
        "install_url": detection.get("install_url"),
        "install_command": detection.get("install_command"),
        # Ollama-specific sub-fields (passed through if present).
        **(
            {
                "codex_installed": detection.get("codex_installed"),
                "ollama_reachable": detection.get("ollama_reachable"),
                "ollama_endpoint": detection.get("ollama_endpoint"),
                "ollama_issue": detection.get("ollama_issue"),
                "ollama_hint": detection.get("ollama_hint"),
            }
            if detection.get("codex_installed") is not None
            else {}
        ),
    }
    # Detection-side diagnostic fields (binary mismatch / unresponsive).
    for diag_key in ("install_issue", "binary_path", "probe_output", "probe_exit_code"):
        if detection.get(diag_key) is not None:
            status[diag_key] = detection[diag_key]
    # Auth-check-side diagnostic fields (populated on unhealthy auth).
    # Note the distinct field names: detection's ``binary_path`` describes
    # the resolved CLI path, while ``check_exit_code`` / ``check_stderr_excerpt``
    # describe the auth probe outcome. They may coexist on the same status.
    for diag_key in ("check_exit_code", "check_stderr_excerpt"):
        if diag_key in auth_status and auth_status[diag_key] is not None:
            status[diag_key] = auth_status[diag_key]
    # Auth check may also report a binary_path when detection did not
    # (e.g. detection cached vs. fresh auth probe); don't clobber.
    if "binary_path" not in status and auth_status.get("binary_path"):
        status["binary_path"] = auth_status["binary_path"]
    return provider.provider_id, status


# Rate-limit state for the ``?force=1`` path. We track the last time any
# force-refresh was honored to prevent a tab-flicker loop from stampeding
# subprocess probes. Keyed to a single float rather than per-client because
# the bottleneck is shared subprocess/network cost, not per-session fairness.
_last_force_refresh_at: float = 0.0


def _force_refresh_allowed(rate_limit_s: float) -> bool:
    """Return True if a ``?force=1`` refresh may run now, and record the time."""
    global _last_force_refresh_at
    now = time.monotonic()
    if now - _last_force_refresh_at < rate_limit_s:
        return False
    _last_force_refresh_at = now
    return True


@router.get("/status")
async def onboarding_status(request: Request) -> JSONResponse:
    """Overall onboarding status with per-provider state and UI timing hints.

    Provider checks run concurrently in the thread pool so they don't
    block the async event loop (each provider may spawn subprocesses or
    make network calls that take several seconds).

    When ``?force=1`` is supplied and the rate-limit window has elapsed,
    the cached health entries are invalidated before fanning out. This
    lets the client recover from a stale "needs setup" banner after the
    user authenticates in a terminal without waiting for the cache TTL.
    """
    _require_session(request)

    config = get_gateway_onboarding_config()
    registry = _get_registry()
    state = _get_state()

    health_ttl_s = float(config.get("health_cache_ttl_s", 30))
    rate_limit_s = float(config.get("force_refresh_rate_limit_s", 5))

    force_requested = request.query_params.get("force") in ("1", "true")
    force_applied = False
    if force_requested and _force_refresh_allowed(rate_limit_s):
        _health_cache.clear()
        force_applied = True

    # Fan out all provider checks concurrently, each in its own thread.
    results = await asyncio.gather(
        *(
            asyncio.to_thread(
                _check_single_provider, provider, registry, health_ttl_s,
            )
            for provider in registry.list_providers()
        )
    )

    providers_status: dict[str, Any] = {}
    for provider_id, status in results:
        providers_status[provider_id] = status
        if status.get("installed"):
            state.mark_provider_installed(provider_id)
        if status.get("authenticated"):
            state.mark_provider_authenticated(provider_id)

    # Auto-complete onboarding when at least one provider is authenticated.
    any_authenticated = any(
        p.get("authenticated") for p in providers_status.values()
    ) if providers_status else False
    if any_authenticated and not state.is_completed():
        state.mark_completed()

    # UI timing hints (milliseconds for the web client).
    ui_timing = {
        "status_poll_interval_ms": config["status_poll_interval_s"] * 1000,
        "banner_poll_interval_ms": config["banner_poll_interval_s"] * 1000,
        "success_dwell_ms": config["success_dwell_s"] * 1000,
        "ready_retry_interval_ms": config["ready_retry_interval_s"] * 1000,
    }

    return JSONResponse(
        {
            "completed": state.is_completed(),
            "providers": providers_status,
            "ui_timing": ui_timing,
            "force_refresh": {
                "requested": force_requested,
                "applied": force_applied,
                "rate_limit_s": rate_limit_s,
            },
        }
    )


@router.get("/providers")
async def list_providers(request: Request) -> JSONResponse:
    """List available providers with metadata.

    Includes detection diagnostics (``install_issue``, ``binary_path``,
    ``probe_output``, ``probe_exit_code``) so the UI can differentiate
    "nothing on PATH" from "wrong binary found" from "binary failed to
    execute" — each needs different remediation copy.
    """
    _require_session(request)

    registry = _get_registry()
    providers = []
    for p in registry.list_providers():
        # Quick detection check.
        try:
            handler = registry.resolve_detection_handler(p.provider_id)
            detection = handler()
        except Exception:
            detection = {"installed": False}

        entry: dict[str, Any] = {
            "provider_id": p.provider_id,
            "display_name": p.display_name,
            "auth_method": p.auth_method,
            "installed": detection.get("installed", False),
            "install_url": detection.get("install_url") or p.install_url,
            "install_command": detection.get("install_command") or p.install_command,
        }
        for diag_key in ("install_issue", "binary_path", "probe_output", "probe_exit_code"):
            if detection.get(diag_key) is not None:
                entry[diag_key] = detection[diag_key]
        providers.append(entry)

    return JSONResponse({"providers": providers})


@router.post("/providers/{provider_id}/authenticate")
async def authenticate_provider(provider_id: str, request: Request) -> JSONResponse:
    """Trigger the provider's auth flow."""
    _require_session(request)

    config = get_gateway_onboarding_config()
    registry = _get_registry()

    try:
        auth_handler = registry.resolve_auth_handler(provider_id)
    except KeyError:
        raise HTTPException(
            status_code=HTTPStatus.NOT_FOUND,
            detail=f"Unknown provider: {provider_id}",
        )

    result = auth_handler()
    _invalidate_health_cache(provider_id)

    return JSONResponse(
        {
            **result,
            "poll_endpoint": f"/api/onboarding/providers/{provider_id}/auth-status",
            "poll_interval_ms": config["status_poll_interval_s"] * 1000,
            "auth_timeout_s": config["auth_timeout_s"],
        }
    )


@router.get("/providers/{provider_id}/auth-status")
async def provider_auth_status(provider_id: str, request: Request) -> JSONResponse:
    """Check auth completion status for a provider.

    Honors ``?force=1`` (subject to the global force-refresh rate limit)
    so the banner's post-handoff polling loop can see newly-authenticated
    state without waiting for the cache TTL.
    """
    _require_session(request)

    registry = _get_registry()
    provider = registry.get(provider_id)
    if not provider:
        raise HTTPException(
            status_code=HTTPStatus.NOT_FOUND,
            detail=f"Unknown provider: {provider_id}",
        )

    config = get_gateway_onboarding_config()
    health_ttl_s = float(config.get("health_cache_ttl_s", 30))
    rate_limit_s = float(config.get("force_refresh_rate_limit_s", 5))

    force_requested = request.query_params.get("force") in ("1", "true")
    if force_requested and _force_refresh_allowed(rate_limit_s):
        _invalidate_health_cache(provider_id)

    check_fn = registry.resolve_check_handler(provider_id)
    auth_status = _get_cached_auth_check(provider_id, check_fn, health_ttl_s)

    # Update persisted state on success.
    if auth_status.get("authenticated"):
        state = _get_state()
        state.mark_provider_authenticated(provider_id)

    return JSONResponse(auth_status)


@router.post("/providers/{provider_id}/dismiss")
async def dismiss_provider(provider_id: str, request: Request) -> JSONResponse:
    """Dismiss a provider for the current session.

    Stops auth health checks until the gateway is restarted (next
    ``obra studio`` launch).
    """
    _require_session(request)
    _dismissed_providers.add(provider_id)
    _invalidate_health_cache(provider_id)
    return JSONResponse({"dismissed": True, "provider_id": provider_id})


@router.post("/providers/{provider_id}/undismiss")
async def undismiss_provider(provider_id: str, request: Request) -> JSONResponse:
    """Re-enable auth checks for a previously dismissed provider."""
    _require_session(request)
    _dismissed_providers.discard(provider_id)
    _invalidate_health_cache(provider_id)
    return JSONResponse({"dismissed": False, "provider_id": provider_id})


@router.post("/complete")
async def complete_onboarding(request: Request) -> JSONResponse:
    """Mark onboarding as complete."""
    _require_session(request)
    state = _get_state()
    state.mark_completed()
    return JSONResponse({"completed": True})
