"""Workflow crosswalk preview and confirmation routes for Studio browser sessions."""

from __future__ import annotations

import asyncio
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Literal

from fastapi import APIRouter, Body, HTTPException, Query, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ConfigDict, Field

from obra.config.loaders import get_gateway_onboarding_config
from obra.gateway.automation.workspaces import ensure_project_working_dir
from obra.gateway.plan_context import _load_gateway_workflow_run_plan_context
from obra.gateway.providers.registry import ProviderRegistry
from obra.gateway.studio_browser import (
    is_studio_browser_authenticated_request,
    require_studio_or_bearer_auth,
)
from obra.hybrid.preexecution_pipeline import build_preexecution_pipeline

from obra_business.complexity.stage_complexity_gate import (
    StageComplexityAssessmentError,
    StageComplexityGate,
)
from obra_business.compilation.compiler import _compute_workflow_content_hash, load_cached_grades
from obra_business.config.loader import get_config_value, load_config
from obra_business.crosswalk.model_crosswalk import (
    CrossWalk,
    CrossWalkConfirmationRequired,
    build_crosswalk,
    carry_forward_confirmation,
    crosswalk_path,
    enumerate_available_models,
    load_crosswalk,
    save_crosswalk,
)
from obra_business.runtime.canonical_executor import _load_plan_payload, _write_plan_payload

router = APIRouter(prefix="/api/workflows", tags=["crosswalk"])


@dataclass(frozen=True)
class CrosswalkPreviewResolution:
    status: Literal["ready", "no_crosswalk_required"]
    workflow_dir: Path
    workflow_id: str
    crosswalk: CrossWalk | None


class CrosswalkSelectionInput(BaseModel):
    model_config = ConfigDict(extra="forbid")

    grade: Literal["low", "medium", "high"]
    provider: str = Field(..., min_length=1, max_length=256)
    model: str = Field(..., min_length=1, max_length=256)
    reasoning_level: str | None = Field(default=None, max_length=64)
    auth_method: str | None = Field(default=None, max_length=64)


class ConfirmCrosswalkRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    selections: list[CrosswalkSelectionInput] = Field(..., min_length=1, max_length=3)


def _require_session(request: Request) -> None:
    try:
        require_studio_or_bearer_auth(request)
    except HTTPException as exc:
        raise HTTPException(
            status_code=exc.status_code,
            detail="Studio browser session or bearer token required",
        ) from exc


@contextmanager
def _pushd(path: Path):
    previous = Path.cwd()
    try:
        import os

        if path.exists():
            os.chdir(path)
        yield
    finally:
        os.chdir(previous)


def _resolve_launch_working_dir(
    request: Request,
    *,
    project_id: str | None,
    working_dir: str | None,
) -> str:
    if working_dir is not None:
        return working_dir
    if project_id is None:
        raise ValueError("working_dir is required when project_id is omitted")
    return ensure_project_working_dir(request, project_id=project_id)


def _resolve_crosswalk_workflow_dir(working_dir: Path, workflow_id: str) -> Path:
    materialized_workflow_dir = working_dir / ".obra-biz" / "workflows" / workflow_id
    if materialized_workflow_dir.is_dir():
        return materialized_workflow_dir
    return working_dir


def _build_synthetic_compiled_plan(
    *,
    workflow_id: str,
    workflow_definition: dict[str, Any],
    plan_context: dict[str, Any],
) -> dict[str, Any]:
    title = str(
        plan_context.get("title")
        or workflow_definition.get("title")
        or workflow_id
    ).strip()
    description = str(
        plan_context.get("description")
        or workflow_definition.get("description")
        or ""
    ).strip()
    stories: list[dict[str, Any]] = []
    for stage in workflow_definition.get("stages", []):
        if not isinstance(stage, dict):
            continue
        stage_id = str(stage.get("id") or stage.get("stage_id") or "").strip()
        if not stage_id:
            continue
        stories.append(
            {
                "id": stage_id,
                "stage_id": stage_id,
                "title": str(stage.get("title") or stage.get("name") or stage_id).strip(),
                "description": str(
                    stage.get("description") or stage.get("purpose") or ""
                ).strip(),
                "stage_type": str(stage.get("type") or stage.get("stage_type") or "").strip(),
                "depends_on": [
                    str(item).strip()
                    for item in stage.get("depends_on", [])
                    if str(item).strip()
                ]
                if isinstance(stage.get("depends_on"), list)
                else [],
                "inputs": [
                    str(item).strip()
                    for item in stage.get("inputs", [])
                    if str(item).strip()
                ]
                if isinstance(stage.get("inputs"), list)
                else [],
                "outputs": [
                    str(item).strip()
                    for item in stage.get("outputs", [])
                    if str(item).strip()
                ]
                if isinstance(stage.get("outputs"), list)
                else [],
                "prompt_template": stage.get("prompt_template"),
                "input_schema": stage.get("input_schema"),
                "output_schema": stage.get("output_schema"),
            }
        )
    return {
        "work_id": workflow_id,
        "workflow_source_summary": {
            "title": title,
            "description": description,
            "workflow_id": workflow_id,
            "domain_id": str(
                plan_context.get("domain_id") or workflow_definition.get("domain_id") or ""
            ).strip(),
        },
        "epics": [
            {
                "id": "E1",
                "title": title,
                "description": description,
                "stories": stories,
            }
        ],
    }


def _persist_grades(
    *,
    compiled_plan: dict[str, Any],
    workflow_definition: dict[str, Any],
    grades: list[Any],
    plan_path: Path | None,
) -> None:
    if plan_path is None:
        return
    compiled_plan["complexity_grades"] = {
        "workflow_content_hash": _compute_workflow_content_hash(workflow_definition),
        "graded_at": datetime.now(UTC).isoformat(),
        "grades": [
            {
                "stage_id": grade.stage_id,
                "grade": grade.grade,
                "rationale": grade.rationale,
            }
            for grade in grades
        ],
    }
    _write_plan_payload(plan_path, compiled_plan)


def _resolve_grades(
    *,
    workflow_dir: Path,
    workflow_definition: dict[str, Any],
    compiled_plan: dict[str, Any],
    plan_path: Path | None,
    config: dict[str, Any],
) -> list[Any] | None:
    if not bool(get_config_value(config, "business.complexity.estimator.enabled")):
        return None
    cached_grades = load_cached_grades(compiled_plan, workflow_definition)
    if cached_grades is not None:
        return cached_grades
    try:
        pipeline = build_preexecution_pipeline(
            workflow_dir,
            "stage_complexity_gate",
            max_retries=int(get_config_value(config, "business.complexity.estimator.max_retries")),
        )
        grades = asyncio.run(StageComplexityGate(config).assess(compiled_plan, pipeline))
    except StageComplexityAssessmentError:
        return None
    except Exception:
        return None
    if grades:
        _persist_grades(
            compiled_plan=compiled_plan,
            workflow_definition=workflow_definition,
            grades=grades,
            plan_path=plan_path,
        )
    return grades


def serialize_crosswalk_payload(workflow_id: str, crosswalk: CrossWalk, workflow_dir: Path) -> dict[str, Any]:
    return {
        "workflow_id": workflow_id,
        "path": str(crosswalk_path(workflow_dir, workflow_id)),
        "workflow_content_hash": crosswalk.workflow_content_hash,
        "available_models_hash": crosswalk.available_models_hash,
        "confirmed_at": crosswalk.confirmed_at,
        "entries": [
            {
                "grade": entry.grade,
                "rationale": entry.rationale,
                "selected": dict(entry.selected),
                "available": [dict(item) for item in entry.available],
                "confirmed": entry.confirmed,
                "fallback_reason": entry.fallback_reason,
            }
            for entry in crosswalk.entries
        ],
    }


def resolve_workflow_crosswalk_preview(
    request: Request,
    *,
    workflow_id: str,
    project_id: str | None,
    working_dir: str | None,
    revision_id: str | None,
    domain_id: str | None = None,
) -> CrosswalkPreviewResolution:
    resolved_working_dir = Path(
        _resolve_launch_working_dir(
            request,
            project_id=project_id,
            working_dir=working_dir,
        )
    ).expanduser().resolve()
    workflow_dir = _resolve_crosswalk_workflow_dir(resolved_working_dir, workflow_id)
    existing = load_crosswalk(workflow_dir, workflow_id)
    client_factory = getattr(request.app.state, "workflow_studio_client_factory", None)
    try:
        plan_context = _load_gateway_workflow_run_plan_context(
            objective=f"Run workflow {workflow_id}",
            working_dir=str(resolved_working_dir),
            workflow_id=workflow_id,
            revision_id=revision_id,
            domain_id=domain_id,
            client_factory=client_factory if callable(client_factory) else None,
        )
    except Exception:
        plan_context = None
    if not isinstance(plan_context, dict):
        if existing is not None:
            return CrosswalkPreviewResolution(
                status="ready",
                workflow_dir=workflow_dir,
                workflow_id=workflow_id,
                crosswalk=existing,
            )
        return CrosswalkPreviewResolution(
            status="no_crosswalk_required",
            workflow_dir=workflow_dir,
            workflow_id=workflow_id,
            crosswalk=None,
        )
    workflow_definition = (
        dict(plan_context.get("workflow_definition"))
        if isinstance(plan_context.get("workflow_definition"), dict)
        else {}
    )
    if not workflow_definition:
        if existing is not None:
            return CrosswalkPreviewResolution(
                status="ready",
                workflow_dir=workflow_dir,
                workflow_id=workflow_id,
                crosswalk=existing,
            )
        return CrosswalkPreviewResolution(
            status="no_crosswalk_required",
            workflow_dir=workflow_dir,
            workflow_id=workflow_id,
            crosswalk=None,
        )
    resolved_domain_id = str(
        domain_id or plan_context.get("domain_id") or workflow_definition.get("domain_id") or ""
    ).strip()
    if resolved_domain_id != "business":
        return CrosswalkPreviewResolution(
            status="no_crosswalk_required",
            workflow_dir=workflow_dir,
            workflow_id=workflow_id,
            crosswalk=None,
        )
    with _pushd(workflow_dir):
        config = load_config()
    if not bool(get_config_value(config, "business.crosswalk.enforce_confirmation")):
        return CrosswalkPreviewResolution(
            status="no_crosswalk_required",
            workflow_dir=workflow_dir,
            workflow_id=workflow_id,
            crosswalk=None,
        )

    registry = ProviderRegistry(get_gateway_onboarding_config().get("providers"))
    available, available_hash = enumerate_available_models(registry)
    workflow_content_hash = _compute_workflow_content_hash(workflow_definition)
    if (
        existing is not None
        and existing.workflow_content_hash == workflow_content_hash
        and existing.available_models_hash == available_hash
    ):
        return CrosswalkPreviewResolution(
            status="ready",
            workflow_dir=workflow_dir,
            workflow_id=workflow_id,
            crosswalk=existing,
        )

    plan_path = workflow_dir / "WORKFLOW_PLAN.json"
    compiled_plan = (
        _load_plan_payload(plan_path)
        if plan_path.exists()
        else _build_synthetic_compiled_plan(
            workflow_id=workflow_id,
            workflow_definition=workflow_definition,
            plan_context=plan_context,
        )
    )
    grades = _resolve_grades(
        workflow_dir=workflow_dir,
        workflow_definition=workflow_definition,
        compiled_plan=compiled_plan,
        plan_path=plan_path if plan_path.exists() else None,
        config=config,
    )
    if not grades:
        if existing is not None:
            return CrosswalkPreviewResolution(
                status="ready",
                workflow_dir=workflow_dir,
                workflow_id=workflow_id,
                crosswalk=existing,
            )
        return CrosswalkPreviewResolution(
            status="no_crosswalk_required",
            workflow_dir=workflow_dir,
            workflow_id=workflow_id,
            crosswalk=None,
        )

    existing = build_crosswalk(
        grades=grades,
        available=available,
        available_hash=available_hash,
        workflow_content_hash=workflow_content_hash,
        config=config,
    )
    existing = carry_forward_confirmation(load_crosswalk(workflow_dir, workflow_id), existing)
    save_crosswalk(workflow_dir, workflow_id, existing)

    return CrosswalkPreviewResolution(
        status="ready",
        workflow_dir=workflow_dir,
        workflow_id=workflow_id,
        crosswalk=existing,
    )


def raise_crosswalk_confirmation_required(
    request: Request,
    *,
    workflow_id: str,
    project_id: str | None,
    working_dir: str | None,
    revision_id: str | None,
    domain_id: str | None = None,
) -> None:
    resolution = resolve_workflow_crosswalk_preview(
        request,
        workflow_id=workflow_id,
        project_id=project_id,
        working_dir=working_dir,
        revision_id=revision_id,
        domain_id=domain_id,
    )
    if resolution.status != "ready" or resolution.crosswalk is None:
        return
    if all(entry.confirmed for entry in resolution.crosswalk.entries):
        return
    raise CrossWalkConfirmationRequired(
        crosswalk_path(resolution.workflow_dir, workflow_id),
        workflow_id,
        resolution.crosswalk,
    )


@router.get("/{workflow_id}/crosswalk")
async def get_workflow_crosswalk(
    workflow_id: str,
    request: Request,
    project_id: str | None = Query(default=None, max_length=256),
    working_dir: str | None = Query(default=None, max_length=4096),
    revision_id: str | None = Query(default=None, max_length=256),
) -> JSONResponse:
    _require_session(request)
    resolution = resolve_workflow_crosswalk_preview(
        request,
        workflow_id=workflow_id,
        project_id=project_id,
        working_dir=working_dir,
        revision_id=revision_id,
    )
    if resolution.status == "no_crosswalk_required" or resolution.crosswalk is None:
        return JSONResponse(status_code=404, content={"detail": "no_crosswalk_required"})
    return JSONResponse(
        status_code=200,
        content=serialize_crosswalk_payload(
            resolution.workflow_id,
            resolution.crosswalk,
            resolution.workflow_dir,
        ),
    )


@router.post("/{workflow_id}/crosswalk/confirm")
async def confirm_workflow_crosswalk(
    workflow_id: str,
    request: Request,
    body: ConfirmCrosswalkRequest = Body(...),
    project_id: str | None = Query(default=None, max_length=256),
    working_dir: str | None = Query(default=None, max_length=4096),
    revision_id: str | None = Query(default=None, max_length=256),
) -> dict[str, Any]:
    _require_session(request)
    resolution = resolve_workflow_crosswalk_preview(
        request,
        workflow_id=workflow_id,
        project_id=project_id,
        working_dir=working_dir,
        revision_id=revision_id,
    )
    if resolution.status == "no_crosswalk_required" or resolution.crosswalk is None:
        raise HTTPException(status_code=404, detail="no_crosswalk_required")

    selections_by_grade = {selection.grade: selection for selection in body.selections}
    expected_grades = {entry.grade for entry in resolution.crosswalk.entries}
    if set(selections_by_grade) != expected_grades:
        raise HTTPException(
            status_code=422,
            detail="Selections must provide exactly one choice for each crosswalk grade",
        )

    confirmed_entries = []
    for entry in resolution.crosswalk.entries:
        selection = selections_by_grade.get(entry.grade)
        if selection is None:
            raise HTTPException(status_code=422, detail=f"Missing selection for grade {entry.grade}")
        confirmed_entries.append(
            entry.__class__(
                grade=entry.grade,
                rationale=entry.rationale,
                selected={
                    "provider": selection.provider,
                    "model": selection.model,
                    "reasoning_level": selection.reasoning_level,
                    "auth_method": selection.auth_method,
                },
                available=[dict(item) for item in entry.available],
                confirmed=True,
                fallback_reason=entry.fallback_reason,
            )
        )

    confirmed_at = datetime.now(UTC).isoformat()
    updated_crosswalk = CrossWalk(
        workflow_content_hash=resolution.crosswalk.workflow_content_hash,
        available_models_hash=resolution.crosswalk.available_models_hash,
        entries=confirmed_entries,
        confirmed_at=confirmed_at,
    )
    save_crosswalk(resolution.workflow_dir, workflow_id, updated_crosswalk)
    return {"status": "confirmed", "confirmed_at": confirmed_at}
