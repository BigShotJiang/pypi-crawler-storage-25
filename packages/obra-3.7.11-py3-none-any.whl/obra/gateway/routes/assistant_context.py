"""Assistant route request-context resolution."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal

from fastapi import HTTPException, Request, status

from obra.gateway.automation.workspaces import (
    derive_workspace_id,
    resolve_gateway_workspace_from_request,
)

AssistantContextSource = Literal[
    "project_id_workspace_id",
    "explicit_working_dir",
    "project_metadata",
    "allowed_base_project_id",
    "allowed_base_default",
]


@dataclass(frozen=True)
class AssistantRequestContext:
    """Resolved request context shared by assistant route families."""

    project_id: str | None
    workspace_id: str
    working_dir: str | None
    safety_mode: str | None
    fallback_source: AssistantContextSource


def _normalize_nonempty_string(value: Any) -> str | None:
    if not isinstance(value, str):
        return None
    normalized = value.strip()
    return normalized or None


def _allowed_working_dir_base(request: Request) -> str | None:
    gateway_config = getattr(request.app.state, "gateway_config", {}) or {}
    return _normalize_nonempty_string(gateway_config.get("allowed_working_dir_base"))


def _workspace_unresolved(
    request: Request,
    *,
    project_id: str | None,
    working_dir: str | None,
    message: str,
) -> HTTPException:
    return HTTPException(
        status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
        detail={
            "code": "assistant_workspace_unresolved",
            "message": message,
            "project_id": project_id,
            "working_dir": working_dir,
            "allowed_working_dir_base": _allowed_working_dir_base(request),
            "user_action": (
                "Select a valid Studio workspace directory or restart the gateway "
                "with WORKFLOW_STUDIO_ALLOWED_WORKING_DIR_BASE set to the project root family."
            ),
        },
    )


def _thread_context_working_dir(thread_last_context: dict[str, Any] | None) -> str | None:
    if not isinstance(thread_last_context, dict):
        return None
    return _normalize_nonempty_string(thread_last_context.get("working_dir"))


def build_assistant_request_context(
    request: Request,
    *,
    project_id: str | None,
    working_dir: str | None,
    safety_mode: str | None = None,
    thread_last_context: dict[str, Any] | None = None,
    require_working_dir: bool = False,
) -> AssistantRequestContext:
    """Resolve assistant workspace identity and optional canonical working directory."""
    normalized_project_id = _normalize_nonempty_string(project_id)
    normalized_working_dir = _normalize_nonempty_string(working_dir)
    candidate_working_dir = normalized_working_dir or _thread_context_working_dir(
        thread_last_context
    )

    if require_working_dir or candidate_working_dir is not None:
        try:
            resolution = resolve_gateway_workspace_from_request(
                request,
                project_id=normalized_project_id,
                working_dir=candidate_working_dir,
            )
        except ValueError as exc:
            raise _workspace_unresolved(
                request,
                project_id=normalized_project_id,
                working_dir=candidate_working_dir,
                message=str(exc),
            ) from exc
        # When the caller supplies an explicit project_id, it is the
        # authoritative workspace identity. The resolved working_dir is still
        # validated against the allowed base above, but we must not let a
        # path-derived workspace id override the project_id the client asked
        # for — otherwise threads scoped to project_id="X" become invisible
        # the moment the client also passes working_dir.
        return AssistantRequestContext(
            project_id=normalized_project_id,
            workspace_id=normalized_project_id or resolution.workspace_id,
            working_dir=resolution.working_dir,
            safety_mode=_normalize_nonempty_string(safety_mode),
            fallback_source=resolution.source,  # type: ignore[arg-type]
        )

    if normalized_project_id is not None:
        return AssistantRequestContext(
            project_id=normalized_project_id,
            workspace_id=normalized_project_id,
            working_dir=None,
            safety_mode=_normalize_nonempty_string(safety_mode),
            fallback_source="project_id_workspace_id",
        )

    raise HTTPException(
        status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
        detail="working_dir is required when project_id is omitted",
    )


def resolve_assistant_project_root_or_none(
    request: Request,
    *,
    project_id: str | None,
    working_dir: str | None,
    thread_last_context: dict[str, Any] | None = None,
) -> Path | None:
    """Best-effort working-dir resolver for optional context assembly."""
    try:
        context = build_assistant_request_context(
            request,
            project_id=project_id,
            working_dir=working_dir,
            thread_last_context=thread_last_context,
            require_working_dir=True,
        )
    except HTTPException:
        return None
    if context.working_dir is None:
        return None
    return Path(context.working_dir)


def workspace_id_from_working_dir(working_dir: str) -> str:
    """Derive the assistant workspace id for an explicit local workspace."""
    return derive_workspace_id(Path(working_dir).expanduser().resolve(strict=False))
