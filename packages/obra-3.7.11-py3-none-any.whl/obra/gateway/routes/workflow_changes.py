"""Workflow change-log routes.

Every mutation goes through persist_and_broadcast(); WS sequence == change-log
sequence by construction.
"""

from __future__ import annotations

from datetime import UTC, datetime
from uuid import uuid4

from fastapi import APIRouter, HTTPException, Query, Request, status
from fastapi.applications import FastAPI

from obra.gateway.pagination import paginate_collection, pagination_params_from_request
from obra.gateway.schemas.workflow_mutations import WorkflowMutationRecord
from obra.gateway.storage.workflow_changes_store import WorkflowChangesStore

router = APIRouter(tags=["workflow-studio"])


def _store(request: Request) -> WorkflowChangesStore:
    store = getattr(request.app.state, "workflow_changes_store", None)
    if not isinstance(store, WorkflowChangesStore):
        raise HTTPException(status_code=500, detail="Workflow changes store unavailable")
    return store


def _app(source: Request | FastAPI) -> FastAPI:
    return source.app if hasattr(source, "app") else source


def persist_and_broadcast(source: Request | FastAPI, record: WorkflowMutationRecord) -> WorkflowMutationRecord:
    app = _app(source)
    session_manager = app.state.session_manager
    store = getattr(app.state, "workflow_changes_store", None)
    emit_lock = getattr(app.state, "workflow_changes_emit_lock", None)
    if not isinstance(store, WorkflowChangesStore) or emit_lock is None:
        raise HTTPException(status_code=500, detail="Workflow changes store unavailable")

    with emit_lock:
        event_bus = session_manager.get_workflow_event_bus(record.workflow_id)
        next_sequence = max(event_bus.latest_sequence() + 1, store.next_sequence(record.workflow_id))
        final_record = record.model_copy(update={"sequence": next_sequence})
        store.append(final_record)
        session_manager.emit_workflow_event(
            final_record.workflow_id,
            {
                "event_name": "workflow.updated",
                "workflow_id": final_record.workflow_id,
                "change_id": final_record.change_id,
                "sequence": final_record.sequence,
                "proposal_status": final_record.proposal_status,
                "origin": final_record.origin,
                "change": final_record.model_dump(mode="json"),
            },
        )
    return final_record


@router.get("/api/workflows/{workflow_id}/changes")
async def list_workflow_changes(
    workflow_id: str,
    request: Request,
    since: int = Query(default=0, ge=0),
) -> dict[str, object]:
    records = [
        record.model_dump(mode="json")
        for record in _store(request).list_changes(workflow_id)
        if record.sequence >= since
    ]
    return paginate_collection(
        collection_key="changes",
        items=records,
        params=pagination_params_from_request(request),
        extra={"workflow_id": workflow_id},
        total_count=len(records),
    )


@router.post("/api/workflows/{workflow_id}/changes/{change_id}/revert")
async def revert_workflow_change(workflow_id: str, change_id: str, request: Request) -> dict[str, object]:
    original = _store(request).get_change(workflow_id, change_id)
    if original is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Workflow change not found")
    reverted = WorkflowMutationRecord(
        change_id=f"chg_{uuid4().hex}",
        sequence=0,
        workflow_id=workflow_id,
        action=original.action,
        stage_id=original.stage_id,
        summary=f"Reverted: {original.summary}",
        patch=original.inverse_patch,
        inverse_patch=original.patch,
        origin="user-edit",
        actor_id="gateway-user",
        session_id=f"revert:{change_id}",
        ts=datetime.now(UTC),
        proposal_status="applied",
    )
    record = persist_and_broadcast(request, reverted)
    return {"change": record.model_dump(mode="json")}
