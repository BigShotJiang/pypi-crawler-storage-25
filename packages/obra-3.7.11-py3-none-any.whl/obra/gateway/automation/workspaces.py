"""Workspace resolution owners for automation-facing gateway flows."""

from __future__ import annotations

import json
import hashlib
import logging
import secrets
import shutil
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Callable

from fastapi import Request

from obra.gateway.session_helpers import _validate_working_dir
from obra.workflow.normalization import slugify

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class WorkspaceResolution:
    """Resolved project/workspace launch context."""

    workspace_id: str
    project_id: str
    working_dir: str
    source: str
    stored_working_dir: str | None = None

    def to_payload(self) -> dict[str, str | None]:
        return {
            "workspace_id": self.workspace_id,
            "project_id": self.project_id,
            "working_dir": self.working_dir,
            "source": self.source,
            "stored_working_dir": self.stored_working_dir,
        }


def resolve_gateway_workspace(
    *,
    project_id: str | None,
    working_dir: str | None,
    allowed_base: Path | None = None,
    client_factory: Callable[[], Any] | None = None,
) -> WorkspaceResolution:
    """Resolve the canonical gateway workspace.

    When *allowed_base* is provided (automation workspaces), the resolved
    path must fall within it.  Interactive callers pass ``None`` to skip
    the base-path restriction — OS filesystem permissions are the
    access-control layer for user-chosen paths.
    """
    normalized_project_id = _normalize_optional_string(project_id)
    allowed_base_resolved = allowed_base.expanduser().resolve() if allowed_base is not None else None

    explicit_working_dir = _normalize_optional_string(working_dir)
    if explicit_working_dir is not None:
        resolved = _validate_working_dir(explicit_working_dir, allowed_base_resolved)
        workspace_id = derive_workspace_id(resolved)
        return WorkspaceResolution(
            workspace_id=workspace_id,
            project_id=normalized_project_id or workspace_id,
            working_dir=str(resolved),
            source="explicit_working_dir",
        )

    if normalized_project_id is not None:
        project_metadata_dir = _resolve_project_metadata_working_dir(
            normalized_project_id,
            allowed_base=allowed_base_resolved,
            client_factory=client_factory,
        )
        if project_metadata_dir is not None:
            workspace_id = derive_workspace_id(project_metadata_dir)
            return WorkspaceResolution(
                workspace_id=workspace_id,
                project_id=normalized_project_id,
                working_dir=str(project_metadata_dir),
                source="project_metadata",
                stored_working_dir=str(project_metadata_dir),
            )

    if allowed_base_resolved is not None and normalized_project_id is not None:
        candidate = allowed_base_resolved / normalized_project_id
        if candidate.exists():
            resolved = _validate_working_dir(str(candidate), allowed_base_resolved)
            workspace_id = derive_workspace_id(resolved)
            return WorkspaceResolution(
                workspace_id=workspace_id,
                project_id=normalized_project_id,
                working_dir=str(resolved),
                source="allowed_base_project_id",
            )

    if normalized_project_id is None:
        raise ValueError("working_dir is required when project_id is omitted")
    raise ValueError(
        f"No working directory is configured for project '{normalized_project_id}'. "
        "Set the project's working_directory or pass working_dir explicitly."
    )


def resolve_gateway_workspace_from_request(
    request: Request,
    *,
    project_id: str | None,
    working_dir: str | None,
) -> WorkspaceResolution:
    """Resolve workspace precedence from request-bound gateway state."""
    gateway_config = getattr(request.app.state, "gateway_config", {})
    allowed_base = Path(str(gateway_config["allowed_working_dir_base"]))
    client_factory = getattr(request.app.state, "workflow_studio_client_factory", None)
    return resolve_gateway_workspace(
        project_id=project_id,
        working_dir=working_dir,
        allowed_base=allowed_base,
        client_factory=client_factory if callable(client_factory) else None,
    )


def ensure_project_working_dir(
    request: Request,
    *,
    project_id: str,
) -> str:
    """Resolve a working directory for *project_id*, provisioning if absent.

    Mirrors the behavior the workflow-run launch route relies on so the
    assistant launch path and the explicit launch endpoint stay aligned:

    1. Try the standard precedence (project metadata, allowed_base/project_id).
    2. If unresolved, fetch the project, provision a fresh project directory,
       and persist the working directory back to project metadata so future
       resolutions hit the fast path.

    Raises ``ValueError`` when no working directory could be established
    (missing project_id, project lookup failed, or provisioning was rejected).
    """
    normalized_project_id = _normalize_optional_string(project_id)
    if normalized_project_id is None:
        raise ValueError("project_id is required to ensure a project working directory")

    try:
        resolution = resolve_gateway_workspace_from_request(
            request,
            project_id=normalized_project_id,
            working_dir=None,
        )
    except ValueError:
        client = _resolve_api_client(request)
        project = _fetch_project(client, normalized_project_id)
        project_name = (
            _normalize_optional_string(project.get("project_name"))
            or _normalize_optional_string(project.get("name"))
            or normalized_project_id
        )
        allowed_base = _allowed_base_from_request(request)
        working_dir = str(
            provision_project_directory(
                base_dir=allowed_base,
                project_name=project_name,
                allowed_base=allowed_base,
            )
        )
        _persist_project_working_dir(
            request,
            client,
            project_id=normalized_project_id,
            working_dir=working_dir,
        )
        return working_dir

    if resolution.source != "project_metadata":
        client = _resolve_api_client(request)
        _persist_project_working_dir(
            request,
            client,
            project_id=normalized_project_id,
            working_dir=resolution.working_dir,
        )
    return resolution.working_dir


def ensure_workflow_working_dir(
    request: Request,
    *,
    workflow_id: str,
) -> str:
    """Resolve or provision a workflow-keyed working directory."""
    normalized_workflow_id = _normalize_optional_string(workflow_id)
    if normalized_workflow_id is None:
        raise ValueError("workflow_id is required to ensure a workflow working directory")

    repository = _resolve_workflow_repository(request)
    workflow = repository.get_workflow(normalized_workflow_id)
    if workflow is None:
        raise ValueError(
            f"Workflow '{normalized_workflow_id}' not found; cannot provision workspace"
        )

    title = _normalize_optional_string(workflow.get("title")) or "untitled-workflow"
    allowed_base = _allowed_base_from_request(request)
    path = provision_workflow_workspace(normalized_workflow_id, title, allowed_base)

    registry = getattr(request.app.state, "local_workspace_registry", None)
    if registry is not None and hasattr(registry, "remember_working_dir"):
        registry.remember_working_dir(str(path), source="ensure_workflow_working_dir")
    return str(path)


def _resolve_workflow_repository(request: Request) -> Any:
    repository_factory = getattr(request.app.state, "workflow_studio_repository_factory", None)
    if callable(repository_factory):
        return repository_factory()
    from obra.gateway.workflow_studio.repository import WorkflowStudioRepository

    return WorkflowStudioRepository.from_request(request)


def _resolve_api_client(request: Request) -> Any:
    client_factory = getattr(request.app.state, "workflow_studio_client_factory", None)
    if callable(client_factory):
        return client_factory()
    try:
        from obra.api import APIClient
    except Exception as exc:
        raise ValueError("API client is unavailable for project metadata access") from exc
    return APIClient.from_config()


def _fetch_project(client: Any, project_id: str) -> dict[str, Any]:
    if not hasattr(client, "get_project"):
        raise ValueError("API client does not support project metadata lookup")
    try:
        return client.get_project(project_id)
    except Exception as exc:
        raise ValueError(f"Failed to load project '{project_id}': {exc}") from exc


def _allowed_base_from_request(request: Request) -> Path:
    gateway_config = getattr(request.app.state, "gateway_config", {}) or {}
    base = gateway_config.get("allowed_working_dir_base")
    if not base:
        raise ValueError("gateway_config.allowed_working_dir_base is not configured")
    return Path(str(base)).expanduser().resolve()


def _persist_project_working_dir(
    request: Request,
    client: Any,
    *,
    project_id: str,
    working_dir: str,
) -> None:
    if project_id and hasattr(client, "update_project"):
        try:
            client.update_project(project_id, working_dir=working_dir)
        except Exception:
            logger.warning(
                "Failed to persist provisioned working_dir to project metadata",
                extra={"project_id": project_id, "working_dir": working_dir},
                exc_info=True,
            )
    registry = getattr(request.app.state, "local_workspace_registry", None)
    if registry is not None and hasattr(registry, "remember_working_dir"):
        registry.remember_working_dir(working_dir, source="ensure_project_working_dir")


def derive_workspace_id(working_dir: str | Path) -> str:
    """Return the stable workspace identifier for a resolved working directory."""
    path = Path(working_dir).expanduser().resolve()
    resolved = str(path)
    path_hash = hashlib.sha256(resolved.encode()).hexdigest()[:8]
    name = path.name
    if name and all(char.isalnum() or char in "-_" for char in name):
        return f"{name.lower()}-{path_hash}"
    return hashlib.sha256(resolved.encode()).hexdigest()[:16]


def provision_project_directory(
    *,
    base_dir: Path,
    project_name: str,
    allowed_base: Path | None = None,
) -> Path:
    """Create a durable project directory under the configured base."""
    slug = _truncate_project_slug(slugify(project_name, default="obra-project"))
    validated_base = _validate_working_dir(str(base_dir), allowed_base)
    for _attempt in range(5):
        candidate_name = slug
        candidate = validated_base / candidate_name
        if candidate.exists():
            candidate_name = f"{slug}-{secrets.token_hex(2)}"
            candidate = validated_base / candidate_name
        resolved_candidate = _validate_working_dir(str(candidate), allowed_base)
        try:
            resolved_candidate.mkdir(parents=True, exist_ok=False)
        except FileExistsError:
            continue
        return resolved_candidate
    raise ValueError(
        f"Could not provision a unique project directory for {project_name!r} under {validated_base}"
    )


def provision_workflow_workspace(
    workflow_id: str,
    workflow_title: str | None,
    allowed_base: Path,
) -> Path:
    """Create or reuse a durable workflow directory under the configured base."""
    normalized_workflow_id = _normalize_optional_string(workflow_id)
    if normalized_workflow_id is None:
        raise ValueError("workflow_id is required to provision a workflow workspace")
    title = workflow_title or "untitled-workflow"
    slug = slugify(title, default="untitled-workflow")
    suffix_source = normalized_workflow_id.rsplit("_", 1)[-1]
    short_id = (suffix_source or normalized_workflow_id)[:6].lower()
    validated_base = _validate_working_dir(str(allowed_base), allowed_base)
    workspace = _validate_working_dir(str(validated_base / f"{slug}-{short_id}"), validated_base)
    workspace.mkdir(parents=True, exist_ok=True)
    readme = workspace / "README.md"
    if not readme.exists():
        readme.write_text(
            f'Run outputs for "{title}" ({normalized_workflow_id}).\n',
            encoding="utf-8",
        )
    return workspace


def provision_run_workspace(
    *,
    project_dir: Path,
    run_id: str,
    workflow_id: str | None,
    input_manifest: list[str] | None,
    input_payload: dict[str, str] | None,
    allowed_base: Path,
) -> Path:
    """Create an isolated run workspace and stage input files.

    Returns the path to the provisioned run workspace directory.
    """
    run_workspace = project_dir / ".obra" / "runs" / run_id
    run_workspace.mkdir(parents=True, exist_ok=False)

    if workflow_id:
        workflow_source = project_dir / ".obra-biz" / "workflows" / workflow_id
        if workflow_source.is_dir():
            workflow_dest = run_workspace / ".obra-biz" / "workflows" / workflow_id
            shutil.copytree(workflow_source, workflow_dest)

    for relative_path in input_manifest or []:
        source = project_dir / relative_path
        _validate_working_dir(str(source), allowed_base)
        dest = run_workspace / Path(relative_path).name
        shutil.copy2(source, dest)

    for filename, content in (input_payload or {}).items():
        validate_payload_filename(filename)
        (run_workspace / filename).write_text(content)

    (run_workspace / ".obra-run-metadata.json").write_text(
        json.dumps(
            {
                "run_id": run_id,
                "workflow_id": workflow_id,
                "project_dir": str(project_dir),
                "input_manifest": input_manifest or [],
                "input_payload_keys": list((input_payload or {}).keys()),
                "provisioned_at": datetime.now(UTC).isoformat(),
            }
        )
    )

    logger.info(
        "Provisioned run workspace",
        extra={
            "run_id": run_id,
            "project_id": project_dir.name,
            "workspace": str(run_workspace),
            "manifest_count": len(input_manifest or []),
            "payload_count": len(input_payload or {}),
        },
    )

    return run_workspace


def cleanup_run_workspace(workspace_path: Path, *, project_dir: Path) -> bool:
    """Remove a provisioned run workspace directory.

    Returns True if the directory was removed, False if it was already gone
    or removal failed.
    """
    modern_runs_dir = project_dir / ".obra" / "runs"
    legacy_runs_dir = project_dir / "runs"
    try:
        workspace_path.relative_to(modern_runs_dir)
    except ValueError as modern_error:
        try:
            workspace_path.relative_to(legacy_runs_dir)
        except ValueError:
            raise ValueError(
                f"workspace_path must be under {modern_runs_dir} or {legacy_runs_dir}, "
                f"got {workspace_path}"
            ) from modern_error

    if not workspace_path.exists():
        logger.info(
            "Run workspace already removed",
            extra={"workspace": str(workspace_path)},
        )
        return False

    try:
        shutil.rmtree(workspace_path)
    except OSError:
        logger.warning(
            "Failed to remove run workspace",
            extra={"workspace": str(workspace_path)},
            exc_info=True,
        )
        return False

    logger.info(
        "Cleaned up run workspace",
        extra={"workspace": str(workspace_path)},
    )
    return True


def validate_payload_filename(filename: str) -> None:
    """Reject payload filenames that attempt path traversal."""
    if (
        not filename
        or filename.startswith("~")
        or "/" in filename
        or "\\" in filename
        or ".." in filename
    ):
        raise ValueError(f"Invalid payload filename: {filename!r}")


def _resolve_project_metadata_working_dir(
    project_id: str,
    *,
    allowed_base: Path | None = None,
    client_factory: Callable[[], Any] | None = None,
) -> Path | None:
    client = _create_api_client(client_factory)
    if client is None:
        return None
    try:
        project = client.get_project(project_id)
    except Exception:
        return None
    configured = _normalize_optional_string(
        project.get("working_directory") or project.get("working_dir")
    )
    if configured is None:
        return None
    return _validate_working_dir(configured, allowed_base)


def _create_api_client(client_factory: Callable[[], Any] | None) -> Any | None:
    if callable(client_factory):
        return client_factory()
    try:
        from obra.api import APIClient
    except Exception:
        return None
    try:
        return APIClient.from_config()
    except Exception:
        return None


def _normalize_optional_string(value: Any) -> str | None:
    if isinstance(value, str):
        normalized = value.strip()
        if normalized:
            return normalized
    return None


def _normalize_required_string(value: Any, *, field_name: str) -> str:
    normalized = _normalize_optional_string(value)
    if normalized is None:
        raise ValueError(f"{field_name} is required")
    return normalized


def _truncate_project_slug(value: str, *, max_length: int = 64) -> str:
    if len(value) <= max_length:
        return value
    truncated = value[:max_length].rstrip("-")
    hyphen_index = truncated.rfind("-")
    if hyphen_index >= max_length // 2:
        truncated = truncated[:hyphen_index]
    return truncated.rstrip("-") or value[:max_length].strip("-") or "obra-project"
