"""Tracks gateway subsystem initialization progress.

Provides a thread-safe tracker that background initialization tasks update as
they complete.  The ``/ready`` health endpoint exposes the tracker snapshot so
that the CLI launcher (and eventually the browser) can show progressive
readiness instead of a binary healthy/not-healthy signal.
"""

from __future__ import annotations

import threading
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class SubsystemStatus:
    """Immutable snapshot of a single subsystem's readiness."""

    state: str  # "pending" | "ready" | "failed"
    label: str
    detail: str = ""
    interactive: bool = True


class StartupTracker:
    """Thread-safe registry of subsystem initialization progress.

    Register subsystems before the server starts accepting connections, then
    mark them ready/failed from background tasks.  The ``snapshot`` property
    returns a JSON-serializable dict suitable for the ``/ready`` endpoint.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._subsystems: dict[str, SubsystemStatus] = {}

    # ── mutation ──────────────────────────────────────────────────────

    def register(self, name: str, label: str, *, interactive: bool = True) -> None:
        """Register a subsystem as *pending*."""
        with self._lock:
            self._subsystems[name] = SubsystemStatus(
                state="pending",
                label=label,
                interactive=interactive,
            )

    def mark_ready(self, name: str, detail: str = "") -> None:
        with self._lock:
            existing = self._subsystems.get(name)
            if existing is None:
                return
            self._subsystems[name] = SubsystemStatus(
                state="ready",
                label=existing.label,
                detail=detail,
                interactive=existing.interactive,
            )

    def mark_failed(self, name: str, detail: str = "") -> None:
        with self._lock:
            existing = self._subsystems.get(name)
            if existing is None:
                return
            self._subsystems[name] = SubsystemStatus(
                state="failed",
                label=existing.label,
                detail=detail,
                interactive=existing.interactive,
            )

    # ── queries ───────────────────────────────────────────────────────

    @property
    def all_settled(self) -> bool:
        """True when every subsystem is either *ready* or *failed*."""
        with self._lock:
            return bool(self._subsystems) and all(
                s.state in ("ready", "failed") for s in self._subsystems.values()
            )

    @property
    def snapshot(self) -> dict[str, Any]:
        """JSON-serializable readiness snapshot for the ``/ready`` endpoint."""
        with self._lock:
            subsystems = {
                name: {
                    "state": s.state,
                    "label": s.label,
                    "detail": s.detail,
                    "interactive": s.interactive,
                }
                for name, s in self._subsystems.items()
            }
            ready = bool(self._subsystems) and all(
                s.state in ("ready", "failed") for s in self._subsystems.values()
            )
            interactive_ready = bool(self._subsystems) and all(
                s.state in ("ready", "failed")
                for s in self._subsystems.values()
                if s.interactive
            )
        return {
            "ready": ready,
            "interactive_ready": interactive_ready,
            "subsystems": subsystems,
        }
