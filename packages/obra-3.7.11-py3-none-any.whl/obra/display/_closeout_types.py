"""Shared closeout types and helpers.

This module exists to keep closeout type definitions importable from both
``closeout.py`` and ``closeout_context.py`` without circular imports.
"""

from dataclasses import dataclass
from enum import Enum
from typing import Any


class TerminationState(str, Enum):
    """Session termination states for closeout messaging."""

    COMPLETED = "completed"
    ESCALATED = "escalated"
    INTERRUPTED = "interrupted"
    FAILED = "failed"
    EXPIRED = "expired"
    ABANDONED = "abandoned"


@dataclass
class CloseoutContext:
    """Data for building closeout message."""

    state: TerminationState
    session_id: str
    objective: str = ""
    work_summary: list[str] | None = None
    items_completed: int = 0
    items_total: int = 0
    quality_score: float | None = 0.0
    quality_status: str = "finalized"
    duration_seconds: float = 0.0
    total_duration_seconds: float = 0.0
    invocation_count: int = 1
    files_created: list[str] | None = None
    files_modified: list[str] | None = None
    git_branch: str = ""
    git_commit_hash: str = ""
    termination_reason: str = ""
    warnings: list[str] | None = None
    spike_fallback_summary: str = ""
    terminal_phase: str = ""
    suppress_interrupt_hint: bool = False
    epics_completed: int = 0
    epics_total: int = 0
    stories_completed: int = 0
    stories_total: int = 0
    tasks_completed: int = 0
    tasks_total: int = 0
    pending_skips: list[dict[str, str]] | None = None


def _normalize_quality_score(value: Any) -> float:
    """Normalize a quality score to a 0-100 float."""
    if not isinstance(value, (int, float)):
        return 0.0
    score = float(value)
    if score <= 1.0:
        score = score * 100
    return score


__all__ = [
    "CloseoutContext",
    "TerminationState",
    "_normalize_quality_score",
]
