from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class H5Compression:
    """Normalised compression settings for h5py dataset creation."""

    compression: Any = None
    compression_opts: Any = None
    shuffle: bool = False
    plugin_required: bool = False
    name: str = "none"

    def kwargs(self) -> dict[str, Any]:
        out: dict[str, Any] = {
            "compression": self.compression,
            "compression_opts": self.compression_opts,
            "shuffle": self.shuffle,
        }
        return {k: v for k, v in out.items() if v is not None}


def normalise_compression(
    compression: str | None = "gzip",
    level: int | None = 4,
    *,
    shuffle: bool = True,
) -> H5Compression:
    """Return h5py-compatible compression settings.

    Supported values:
      - none
      - gzip
      - lzf
      - zstd      (requires hdf5plugin)
      - blosc-zstd (requires hdf5plugin)
    """

    name = (compression or "none").lower().replace("_", "-")

    if name in {"none", "off", "false", "0"}:
        return H5Compression(name="none")

    if name == "gzip":
        return H5Compression(
            compression="gzip",
            compression_opts=4 if level is None else int(level),
            shuffle=shuffle,
            name="gzip",
        )

    if name == "lzf":
        return H5Compression(
            compression="lzf",
            compression_opts=None,
            shuffle=shuffle,
            name="lzf",
        )

    if name == "zstd":
        try:
            import hdf5plugin  # type: ignore
        except ImportError as exc:  # pragma: no cover - depends on optional dep
            raise ImportError(
                "zstd compression requires the optional dependency: "
                "pip install dumpduck[compression]"
            ) from exc

        # hdf5plugin objects are passed as **kwargs to create_dataset.
        return H5Compression(
            compression=hdf5plugin.Zstd(clevel=7 if level is None else int(level)),
            compression_opts=None,
            shuffle=False,
            plugin_required=True,
            name="zstd",
        )

    if name in {"blosc", "blosc-zstd"}:
        try:
            import hdf5plugin  # type: ignore
        except ImportError as exc:  # pragma: no cover - depends on optional dep
            raise ImportError(
                "Blosc compression requires the optional dependency: "
                "pip install dumpduck[compression]"
            ) from exc

        return H5Compression(
            compression=hdf5plugin.Blosc(
                cname="zstd",
                clevel=7 if level is None else int(level),
                shuffle=hdf5plugin.Blosc.SHUFFLE if shuffle else hdf5plugin.Blosc.NOSHUFFLE,
            ),
            compression_opts=None,
            shuffle=False,
            plugin_required=True,
            name="blosc-zstd",
        )

    raise ValueError(
        f"Unsupported compression {compression!r}. "
        "Choose one of: none, gzip, lzf, zstd, blosc-zstd."
    )
