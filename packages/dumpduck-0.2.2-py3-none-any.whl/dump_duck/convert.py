from __future__ import annotations

from collections.abc import Iterator
from pathlib import Path
from typing import Literal

import numpy as np
from ase import Atoms
from ase.io import iread as ase_iread

from .compression import normalise_compression
from .h5traj import H5Trajectory
from .lammpsdump import (
    count_lammpstrj_frames,
    iread_lammps_dump,
    iread_lammps_frames,
    parse_type_map,
)

Compression = Literal['gzip', 'lzf', 'none', 'zstd', 'blosc-zstd']


def _is_lammps_format(input_file: str | Path, input_format: str | None) -> bool:
    fmt = (input_format or 'auto').lower()
    if fmt in {'dump', 'lammps-dump', 'lammpsdump', 'lammpstrj'}:
        return True
    if fmt == 'auto':
        suffixes = ''.join(Path(input_file).suffixes[-2:]).lower()
        suffix = Path(input_file).suffix.lower()
        return suffix in {'.lammpstrj', '.dump'} or suffixes in {'.lammpstrj.gz', '.dump.gz'}
    return False


def _atoms_iter(input_file: str, input_format: str | None, type_map: dict[int, int]) -> Iterator[Atoms]:
    if _is_lammps_format(input_file, input_format):
        yield from iread_lammps_dump(input_file, type_map=type_map)
        return

    fmt = (input_format or 'auto').lower()
    if fmt == 'auto':
        yield from ase_iread(input_file, index=':')
    else:
        yield from ase_iread(input_file, index=':', format=input_format)


def _array_or_none(atoms: Atoms, *names: str) -> np.ndarray | None:
    for name in names:
        if name in atoms.arrays:
            return np.asarray(atoms.arrays[name])
    return None


def _ids_from_atoms(atoms: Atoms) -> np.ndarray:
    if 'id' in atoms.arrays:
        return np.asarray(atoms.arrays['id'], dtype=np.int64)
    return np.arange(1, len(atoms) + 1, dtype=np.int64)


def _get_tqdm(progress: bool):
    if not progress:
        return None
    try:
        from tqdm.auto import tqdm
    except ImportError as exc:
        raise ImportError('Progress bars require tqdm: pip install tqdm') from exc
    return tqdm


def _write_lammps_fast(
    input_file: str,
    output_file: str,
    *,
    type_mapping: dict[int, int],
    compression: Compression,
    compression_level: int | None,
    float_dtype: str,
    chunk_frames: int,
    limit: int | None,
    overwrite: bool,
    progress: bool,
    n_frames: int | None,
    count_frames: bool,
) -> None:
    """Fast path for numeric LAMMPS dumps.

    It avoids constructing an ASE Atoms object for every frame and writes HDF5
    in blocks instead of resizing/writing one frame at a time.
    """
    input_path = Path(input_file)
    if n_frames is None and count_frames:
        if progress:
            print('Counting LAMMPS frames...')
        n_frames = count_lammpstrj_frames(input_path)
    if limit is not None:
        n_frames = min(n_frames, limit) if n_frames is not None else limit

    frames = iter(iread_lammps_frames(input_path, type_map=type_mapping))
    try:
        first = next(frames)
    except StopIteration as exc:
        raise ValueError(f'No frames found in {input_file!r}') from exc

    comp = normalise_compression(None if compression == 'none' else compression, compression_level)
    dtype = np.dtype(float_dtype)
    chunk_frames = max(1, int(chunk_frames))

    with H5Trajectory.create(
        output_file,
        atomic_numbers=first.atomic_numbers,
        ids=first.ids,
        lammps_types=first.types,
        mol_ids=first.mol_ids,
        image_flags=first.image_flags is not None,
        n_frames=n_frames,
        float_dtype=float_dtype,
        compression=None if compression == 'none' else compression,
        compression_level=compression_level,
        chunk_frames=chunk_frames,
        overwrite=overwrite,
        attrs={'source_file': str(input_file), 'source_format': 'lammpstrj'},
    ) as traj:
        h5 = traj.h5
        positions_ds = h5['positions']
        cells_ds = h5['cells']
        pbc_ds = h5['pbc']
        timesteps_ds = h5['timesteps']
        image_ds = h5.get('image_flags')

        tqdm = _get_tqdm(progress)
        total = n_frames
        pbar = tqdm(total=total, desc='Converting', unit='frame', dynamic_ncols=True) if tqdm else None

        block_positions: list[np.ndarray] = []
        block_cells: list[np.ndarray] = []
        block_pbc: list[tuple[bool, bool, bool]] = []
        block_timesteps: list[int] = []
        block_images: list[np.ndarray] = []
        start = 0
        n_written = 0

        def flush_block() -> None:
            nonlocal start, n_written, block_positions, block_cells, block_pbc, block_timesteps, block_images
            if not block_positions:
                return
            m = len(block_positions)
            end = start + m
            if positions_ds.shape[0] < end:
                for ds in (positions_ds, cells_ds, pbc_ds, timesteps_ds):
                    shape = list(ds.shape)
                    shape[0] = end
                    ds.resize(tuple(shape))
                if image_ds is not None:
                    shape = list(image_ds.shape)
                    shape[0] = end
                    image_ds.resize(tuple(shape))

            positions_ds[start:end] = np.asarray(block_positions, dtype=dtype)
            cells_ds[start:end] = np.asarray(block_cells, dtype=dtype)
            pbc_ds[start:end] = np.asarray(block_pbc, dtype=np.bool_)
            timesteps_ds[start:end] = np.asarray(block_timesteps, dtype=np.int64)
            if image_ds is not None:
                image_ds[start:end] = np.asarray(block_images, dtype=np.int32)

            h5.attrs['n_frames'] = end
            if pbar is not None:
                pbar.update(m)
            n_written = end
            start = end
            block_positions = []
            block_cells = []
            block_pbc = []
            block_timesteps = []
            block_images = []

        def add(frame) -> None:
            # The first frame fixed identity is used for the whole trajectory.
            # If the dump is not sorted, iread_lammps_frames sorts by id.
            if frame.ids.shape != first.ids.shape or not np.array_equal(frame.ids, first.ids):
                raise ValueError('Frame atom ids/order do not match the first frame')
            if not np.array_equal(frame.atomic_numbers, first.atomic_numbers):
                raise ValueError('Frame atomic numbers do not match the first frame')
            block_positions.append(frame.positions)
            block_cells.append(frame.cell)
            block_pbc.append(frame.pbc)
            block_timesteps.append(frame.timestep)
            if image_ds is not None:
                if frame.image_flags is None:
                    raise ValueError('First frame has image flags but a later frame does not')
                block_images.append(frame.image_flags)

        try:
            add(first)
            if len(block_positions) >= chunk_frames:
                flush_block()

            for frame in frames:
                if limit is not None and n_written + len(block_positions) >= limit:
                    break
                add(frame)
                if len(block_positions) >= chunk_frames:
                    flush_block()
            flush_block()
        finally:
            if pbar is not None:
                pbar.close()

        # Trim if the user supplied a larger n_frames than was actually present.
        if n_frames is not None and n_written != n_frames:
            for name in ('positions', 'cells', 'pbc', 'timesteps'):
                ds = h5[name]
                shape = list(ds.shape)
                shape[0] = n_written
                ds.resize(tuple(shape))
            if 'image_flags' in h5:
                ds = h5['image_flags']
                shape = list(ds.shape)
                shape[0] = n_written
                ds.resize(tuple(shape))
            h5.attrs['n_frames'] = n_written


def _write_generic(
    input_file: str,
    output_file: str,
    *,
    input_format: str | None,
    type_mapping: dict[int, int],
    compression: Compression,
    compression_level: int | None,
    float_dtype: str,
    chunk_frames: int,
    limit: int | None,
    overwrite: bool,
    progress: bool,
    n_frames: int | None,
) -> None:
    frames = iter(_atoms_iter(input_file, input_format, type_mapping))
    try:
        first = next(frames)
    except StopIteration as exc:
        raise ValueError(f'No frames found in {input_file!r}') from exc

    ids = _ids_from_atoms(first)
    lammps_types = _array_or_none(first, 'lammps_type', 'type')
    mol_ids = _array_or_none(first, 'mol_id', 'mol-id', 'mol')
    image_flags = _array_or_none(first, 'image_flags') is not None

    tqdm = _get_tqdm(progress)
    pbar = tqdm(total=n_frames, desc='Converting', unit='frame', dynamic_ncols=True) if tqdm else None

    with H5Trajectory.create(
        output_file,
        atomic_numbers=np.asarray(first.get_atomic_numbers(), dtype=np.int16),
        ids=ids,
        lammps_types=lammps_types,
        mol_ids=mol_ids,
        image_flags=image_flags,
        n_frames=None,
        float_dtype=float_dtype,
        compression=None if compression == 'none' else compression,
        compression_level=compression_level,
        chunk_frames=chunk_frames,
        overwrite=overwrite,
        attrs={'source_file': str(input_file), 'source_format': input_format or 'auto'},
    ) as traj:
        traj.append_frame(first)
        if pbar is not None:
            pbar.update(1)
        for frame_index, atoms in enumerate(frames, start=1):
            if limit is not None and frame_index >= limit:
                break
            traj.append_frame(atoms)
            if pbar is not None:
                pbar.update(1)
        if pbar is not None:
            pbar.close()


def convert(
    input_file: str | Path,
    output_file: str | Path,
    *,
    input_format: str | None = None,
    type_map: str | dict[int, int] | None = None,
    compression: Compression = 'gzip',
    compression_level: int | None = 6,
    float_dtype: str = 'float32',
    chunk_frames: int = 16,
    limit: int | None = None,
    overwrite: bool = True,
    progress: bool = True,
    n_frames: int | None = None,
    count_frames: bool = True,
    fast_lammps: bool = True,
) -> None:
    """Convert an ASE-readable trajectory or LAMMPS dump to dumpDUCK HDF5.

    LAMMPS numeric text dumps use a fast vectorised parser and block-wise HDF5
    writes. Other formats stream through ASE one frame at a time.
    """
    input_file = str(input_file)
    output_file = str(output_file)

    if isinstance(type_map, str) or type_map is None:
        type_mapping = parse_type_map(type_map)
    else:
        type_mapping = {int(k): int(v) for k, v in type_map.items()}

    if fast_lammps and _is_lammps_format(input_file, input_format):
        _write_lammps_fast(
            input_file,
            output_file,
            type_mapping=type_mapping,
            compression=compression,
            compression_level=compression_level,
            float_dtype=float_dtype,
            chunk_frames=chunk_frames,
            limit=limit,
            overwrite=overwrite,
            progress=progress,
            n_frames=n_frames,
            count_frames=count_frames,
        )
        return

    _write_generic(
        input_file,
        output_file,
        input_format=input_format,
        type_mapping=type_mapping,
        compression=compression,
        compression_level=compression_level,
        float_dtype=float_dtype,
        chunk_frames=chunk_frames,
        limit=limit,
        overwrite=overwrite,
        progress=progress,
        n_frames=n_frames,
    )
