from __future__ import annotations

from collections.abc import Iterator, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any, overload

import h5py
import numpy as np
import numpy.typing as npt
from ase import Atoms

try:
    import hdf5plugin  # noqa: F401
except ImportError:
    pass

from .compression import normalise_compression

FORMAT_NAME = "dumpduck-hdf5"
FORMAT_VERSION = "0.2.0"


@dataclass(frozen=True)
class PropertyInfo:
    name: str
    kind: str
    shape: tuple[int, ...]
    dtype: str
    chunks: tuple[int, ...] | None
    compression: str | None
    compression_opts: Any
    valid_frames: int
    total_frames: int
    units: str
    description: str
    attrs: dict[str, Any]


def _as_attr_value(value: Any) -> Any:
    if value is None:
        return ""
    if isinstance(value, (str, int, float, bool, np.number)):
        return value
    return np.asarray(value)


def _normalise_kind(kind: str) -> str:
    kind = kind.lower()
    if kind not in {"atomic", "frame"}:
        raise ValueError("kind must be 'atomic' or 'frame'")
    return kind


def _ensure_tuple(
    shape: int | Sequence[int] | tuple[int, ...] | None,
) -> tuple[int, ...]:
    if shape is None:
        return ()
    if isinstance(shape, int):
        return (shape,)
    return tuple(int(x) for x in shape)


def _resize_axis0(ds: h5py.Dataset, size: int) -> None:
    shape = list(ds.shape)
    shape[0] = size
    ds.resize(tuple(shape))


class H5Trajectory:
    """Lazy reader/writer for dumpDUCK HDF5 trajectories.

    The trajectory stores fixed atom identities plus frame-wise geometry. New
    frame-wise or atom-wise properties can be added later and filled one frame
    at a time without rewriting the file.
    """

    def __init__(self, filename: str | Path, mode: str = "r") -> None:
        self.filename = str(filename)
        self._h5 = h5py.File(self.filename, mode)

        try:
            self._validate()
        except Exception:
            self._h5.close()
            raise

    def _validate(self) -> None:
        required = {"positions", "cells", "pbc", "atomic_numbers"}
        missing = sorted(required.difference(self._h5.keys()))
        if missing:
            raise ValueError(
                f"{self.filename!r} is not a dumpDUCK 0.2 file; missing {missing}"
            )

    @classmethod
    def create(
        cls,
        filename: str | Path,
        *,
        atomic_numbers: npt.ArrayLike,
        ids: npt.ArrayLike | None = None,
        lammps_types: npt.ArrayLike | None = None,
        mol_ids: npt.ArrayLike | None = None,
        image_flags: bool = False,
        n_frames: int | None = None,
        float_dtype: str | np.dtype = "float32",
        compression: str | None = "gzip",
        compression_level: int | None = 4,
        chunk_frames: int = 16,
        attrs: dict[str, Any] | None = None,
        overwrite: bool = False,
    ) -> "H5Trajectory":
        """Create an empty dumpDUCK file ready for append_frame calls."""

        path = Path(filename)
        if path.exists() and not overwrite:
            raise FileExistsError(path)
        path.parent.mkdir(parents=True, exist_ok=True)

        mode = "w" if overwrite else "x"
        h5 = h5py.File(path, mode)
        try:
            numbers = np.asarray(atomic_numbers, dtype=np.int16)
            if numbers.ndim != 1:
                raise ValueError("atomic_numbers must be one-dimensional")
            n_atoms = int(numbers.shape[0])

            comp = normalise_compression(compression, compression_level)
            dtype = np.dtype(float_dtype)
            chunk_frames = max(1, int(chunk_frames))

            h5.attrs["format"] = FORMAT_NAME
            h5.attrs["format_version"] = FORMAT_VERSION
            h5.attrs["n_atoms"] = n_atoms
            initial_frames = 0 if n_frames is None else int(n_frames)
            if initial_frames < 0:
                raise ValueError("n_frames must be non-negative")
            h5.attrs["n_frames"] = 0
            h5.attrs["float_dtype"] = str(dtype)
            h5.attrs["default_compression"] = comp.name
            h5.attrs["plugin_required"] = bool(comp.plugin_required)
            if attrs:
                for key, value in attrs.items():
                    h5.attrs[key] = _as_attr_value(value)

            h5.create_dataset("atomic_numbers", data=numbers, dtype=np.int16)

            if ids is None:
                ids_array = np.arange(1, n_atoms + 1, dtype=np.int64)
            else:
                ids_array = np.asarray(ids, dtype=np.int64)
            if ids_array.shape != (n_atoms,):
                raise ValueError("ids must have shape (n_atoms,)")
            h5.create_dataset("ids", data=ids_array, dtype=np.int64)

            if lammps_types is not None:
                arr = np.asarray(lammps_types, dtype=np.int32)
                if arr.shape != (n_atoms,):
                    raise ValueError("lammps_types must have shape (n_atoms,)")
                h5.create_dataset("lammps_types", data=arr, dtype=np.int32)

            if mol_ids is not None:
                arr = np.asarray(mol_ids, dtype=np.int64)
                if arr.shape != (n_atoms,):
                    raise ValueError("mol_ids must have shape (n_atoms,)")
                h5.create_dataset("mol_ids", data=arr, dtype=np.int64)

            h5.create_dataset(
                "positions",
                shape=(initial_frames, n_atoms, 3),
                maxshape=(None, n_atoms, 3),
                chunks=(chunk_frames, n_atoms, 3),
                dtype=dtype,
                **comp.kwargs(),
            )
            h5.create_dataset(
                "cells",
                shape=(initial_frames, 3, 3),
                maxshape=(None, 3, 3),
                chunks=(min(chunk_frames, 1024), 3, 3),
                dtype=dtype,
                **comp.kwargs(),
            )
            h5.create_dataset(
                "pbc",
                shape=(initial_frames, 3),
                maxshape=(None, 3),
                chunks=(min(max(chunk_frames, 1), 4096), 3),
                dtype=np.bool_,
                compression=comp.compression if comp.name in {"gzip", "lzf"} else None,
                compression_opts=comp.compression_opts if comp.name == "gzip" else None,
            )
            h5.create_dataset(
                "timesteps",
                shape=(initial_frames,),
                maxshape=(None,),
                chunks=(min(max(chunk_frames, 1), 4096),),
                dtype=np.int64,
                compression=comp.compression if comp.name in {"gzip", "lzf"} else None,
                compression_opts=comp.compression_opts if comp.name == "gzip" else None,
            )
            if image_flags:
                h5.create_dataset(
                    "image_flags",
                    shape=(initial_frames, n_atoms, 3),
                    maxshape=(None, n_atoms, 3),
                    chunks=(chunk_frames, n_atoms, 3),
                    dtype=np.int32,
                    **comp.kwargs(),
                )

            h5.require_group("properties").require_group("atomic")
            h5["properties"].require_group("frame")
        except Exception:
            h5.close()
            if mode == "x" and path.exists():
                path.unlink(missing_ok=True)
            raise

        h5.close()
        return cls(path, mode="r+")

    def close(self) -> None:
        self._h5.close()

    def flush(self) -> None:
        self._h5.flush()

    def __enter__(self) -> "H5Trajectory":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    @property
    def h5(self) -> h5py.File:
        return self._h5

    def __len__(self) -> int:
        return int(self._h5.attrs.get("n_frames", self._h5["positions"].shape[0]))

    @property
    def n_frames(self) -> int:
        return len(self)

    @property
    def n_atoms(self) -> int:
        return int(self._h5["positions"].shape[1])

    @property
    def atomic_numbers(self) -> np.ndarray:
        return self._h5["atomic_numbers"][:]

    @property
    def ids(self) -> np.ndarray:
        return self._h5["ids"][:]

    def _normalise_index(self, index: int) -> int:
        n = len(self)
        if index < 0:
            index += n
        if index < 0 or index >= n:
            raise IndexError(index)
        return index

    def append_frame(self, atoms: Atoms, *, timestep: int | None = None) -> int:
        """Append one ASE Atoms frame and resize existing property datasets."""

        if len(atoms) != self.n_atoms:
            raise ValueError(f"Frame has {len(atoms)} atoms, expected {self.n_atoms}")

        numbers = np.asarray(atoms.get_atomic_numbers(), dtype=np.int16)
        if not np.array_equal(numbers, self._h5["atomic_numbers"][:]):
            raise ValueError(
                "Frame atomic numbers do not match the fixed trajectory identity"
            )

        if "id" in atoms.arrays:
            ids = np.asarray(atoms.arrays["id"], dtype=np.int64)
            if not np.array_equal(ids, self._h5["ids"][:]):
                raise ValueError(
                    "Frame atom ids/order do not match the fixed trajectory identity"
                )

        i = len(self)
        for name in ("positions", "cells", "pbc", "timesteps"):
            if self._h5[name].shape[0] < i + 1:
                _resize_axis0(self._h5[name], i + 1)
        if "image_flags" in self._h5 and self._h5["image_flags"].shape[0] < i + 1:
            _resize_axis0(self._h5["image_flags"], i + 1)

        self._h5["positions"][i] = np.asarray(
            atoms.positions, dtype=self._h5["positions"].dtype
        )
        self._h5["cells"][i] = np.asarray(
            atoms.cell.array, dtype=self._h5["cells"].dtype
        )
        self._h5["pbc"][i] = np.asarray(atoms.pbc, dtype=np.bool_)
        self._h5["timesteps"][i] = int(
            atoms.info.get("timestep", i) if timestep is None else timestep
        )
        if "image_flags" in self._h5:
            if "image_flags" not in atoms.arrays:
                raise ValueError("Trajectory expects image_flags, but frame does not contain them")
            self._h5["image_flags"][i] = np.asarray(atoms.arrays["image_flags"], dtype=np.int32)

        self._resize_properties(i + 1)
        self._h5.attrs["n_frames"] = i + 1
        return i

    def _resize_properties(self, n_frames: int) -> None:
        props = self._h5.get("properties")
        if props is None:
            return
        for kind in ("atomic", "frame"):
            if kind not in props:
                continue
            for group in props[kind].values():
                for ds_name in ("data", "valid"):
                    if ds_name in group and group[ds_name].shape[0] != n_frames:
                        _resize_axis0(group[ds_name], n_frames)

    def get_frame(
        self,
        index: int,
        *,
        include_properties: bool = False,
        only_valid_properties: bool = True,
    ) -> Atoms:
        """Read one frame by index without reading other frames."""
        i = self._normalise_index(index)
        h5 = self._h5

        atoms = Atoms(
            numbers=h5["atomic_numbers"][:],
            positions=h5["positions"][i],
            cell=h5["cells"][i],
            pbc=h5["pbc"][i],
        )

        atoms.arrays["id"] = h5["ids"][:]
        if "mol_ids" in h5:
            atoms.arrays["mol_id"] = h5["mol_ids"][:]
        if "lammps_types" in h5:
            atoms.arrays["lammps_type"] = h5["lammps_types"][:]
        if "image_flags" in h5:
            atoms.arrays["image_flags"] = h5["image_flags"][i]

        atoms.info["timestep"] = int(h5["timesteps"][i])
        atoms.info["dumpduck_frame"] = i

        if include_properties:
            for info in self.property_info():
                if only_valid_properties and not self.property_valid(
                    info.name, i, kind=info.kind
                ):
                    continue
                value = self.read_property(
                    info.name, i, kind=info.kind, require_valid=only_valid_properties
                )
                if info.kind == "atomic":
                    atoms.arrays[info.name] = value
                else:
                    atoms.info[info.name] = (
                        value.item() if np.ndim(value) == 0 else value
                    )

        return atoms

    def iter_frames(
        self,
        start: int | None = None,
        stop: int | None = None,
        step: int | None = None,
        *,
        include_properties: bool = False,
        only_valid_properties: bool = True,
    ) -> Iterator[Atoms]:
        """Iterate lazily over a slice of frames."""
        for i in range(*slice(start, stop, step).indices(len(self))):
            yield self.get_frame(
                i,
                include_properties=include_properties,
                only_valid_properties=only_valid_properties,
            )

    @overload
    def __getitem__(self, item: int) -> Atoms: ...

    @overload
    def __getitem__(self, item: slice) -> Iterator[Atoms]: ...

    def __getitem__(self, item: int | slice) -> Atoms | Iterator[Atoms]:
        if isinstance(item, slice):
            return self.iter_frames(item.start, item.stop, item.step)
        return self.get_frame(item)

    def create_property(
        self,
        name: str,
        *,
        kind: str,
        frame_shape: int | Sequence[int] | None = None,
        dtype: str | np.dtype = "float32",
        units: str | None = None,
        description: str | None = None,
        compression: str | None = "gzip",
        compression_level: int | None = 4,
        chunk_frames: int = 1,
        fillvalue: Any | None = None,
        overwrite: bool = False,
        attrs: dict[str, Any] | None = None,
    ) -> h5py.Dataset:
        """Create a lazily-fillable property dataset.

        kind='atomic': data shape is (n_frames, n_atoms, *frame_shape).
        kind='frame': data shape is (n_frames, *frame_shape).
        """

        kind = _normalise_kind(kind)
        frame_shape_tuple = _ensure_tuple(frame_shape)
        dtype = np.dtype(dtype)
        chunk_frames = max(1, int(chunk_frames))
        comp = normalise_compression(compression, compression_level)

        root = self._h5.require_group("properties").require_group(kind)
        if name in root:
            if not overwrite:
                raise ValueError(
                    f"Property {name!r} already exists in properties/{kind}"
                )
            del root[name]

        group = root.create_group(name)

        if kind == "atomic":
            shape = (len(self), self.n_atoms, *frame_shape_tuple)
            maxshape = (None, self.n_atoms, *frame_shape_tuple)
            chunks = (chunk_frames, self.n_atoms, *frame_shape_tuple)
        else:
            shape = (len(self), *frame_shape_tuple)
            maxshape = (None, *frame_shape_tuple)
            chunks = (chunk_frames, *frame_shape_tuple)

        if fillvalue is None:
            if dtype.kind == "f":
                fillvalue = np.nan
            elif dtype.kind in {"i", "u"}:
                fillvalue = 0
            elif dtype.kind == "b":
                fillvalue = False

        data = group.create_dataset(
            "data",
            shape=shape,
            maxshape=maxshape,
            chunks=chunks,
            dtype=dtype,
            fillvalue=fillvalue,
            **comp.kwargs(),
        )
        group.create_dataset(
            "valid",
            shape=(len(self),),
            maxshape=(None,),
            chunks=(min(max(chunk_frames, 1), 4096),),
            dtype=np.bool_,
            compression="gzip" if compression not in {None, "none"} else None,
            compression_opts=1 if compression not in {None, "none"} else None,
            fillvalue=False,
        )

        group.attrs["kind"] = kind
        group.attrs["frame_shape"] = frame_shape_tuple
        group.attrs["dtype"] = str(dtype)
        group.attrs["units"] = units or ""
        group.attrs["description"] = description or ""
        group.attrs["compression"] = comp.name
        group.attrs["plugin_required"] = bool(comp.plugin_required)
        if attrs:
            for key, value in attrs.items():
                group.attrs[key] = _as_attr_value(value)

        return data

    def has_property(self, name: str, *, kind: str | None = None) -> bool:
        props = self._h5.get("properties")
        if props is None:
            return False
        if kind is not None:
            kind = _normalise_kind(kind)
            return kind in props and name in props[kind]
        return any(k in props and name in props[k] for k in ("atomic", "frame"))

    def property_group(self, name: str, *, kind: str | None = None) -> h5py.Group:
        props = self._h5.get("properties")
        if props is None:
            raise KeyError("No properties group is present")

        if kind is not None:
            kind = _normalise_kind(kind)
            if kind not in props or name not in props[kind]:
                raise KeyError(f"Property properties/{kind}/{name} does not exist")
            return props[kind][name]

        matches = []
        for candidate_kind in ("atomic", "frame"):
            if candidate_kind in props and name in props[candidate_kind]:
                matches.append(props[candidate_kind][name])
        if not matches:
            raise KeyError(name)
        if len(matches) > 1:
            raise KeyError(
                f"Property {name!r} exists as both atomic and frame; specify kind"
            )
        return matches[0]

    def write_property(
        self,
        name: str,
        frame_index: int,
        value: npt.ArrayLike,
        *,
        kind: str | None = None,
    ) -> None:
        """Write one property value for one frame and mark it valid."""
        i = self._normalise_index(frame_index)
        group = self.property_group(name, kind=kind)
        data = group["data"]
        expected_shape = tuple(data.shape[1:])
        arr = np.asarray(value, dtype=data.dtype)

        if arr.shape != expected_shape:
            raise ValueError(
                f"Property {name!r} frame has shape {arr.shape}; expected {expected_shape}"
            )

        data[i] = arr
        group["valid"][i] = True

    def read_property(
        self,
        name: str,
        frame_index: int,
        *,
        kind: str | None = None,
        require_valid: bool = True,
    ) -> np.ndarray:
        i = self._normalise_index(frame_index)
        group = self.property_group(name, kind=kind)
        if require_valid and not bool(group["valid"][i]):
            raise KeyError(f"Property {name!r} has not been written for frame {i}")
        return group["data"][i]

    def property_valid(
        self, name: str, frame_index: int, *, kind: str | None = None
    ) -> bool:
        i = self._normalise_index(frame_index)
        group = self.property_group(name, kind=kind)
        return bool(group["valid"][i])

    def valid_frames(self, name: str, *, kind: str | None = None) -> np.ndarray:
        group = self.property_group(name, kind=kind)
        return np.flatnonzero(group["valid"][:])

    def property_info(self) -> list[PropertyInfo]:
        props = self._h5.get("properties")
        if props is None:
            return []

        rows: list[PropertyInfo] = []
        for kind in ("atomic", "frame"):
            if kind not in props:
                continue
            for name, group in props[kind].items():
                data = group["data"]
                valid = group["valid"]
                attrs = {k: group.attrs[k] for k in group.attrs.keys()}
                rows.append(
                    PropertyInfo(
                        name=name,
                        kind=kind,
                        shape=tuple(int(x) for x in data.shape),
                        dtype=str(data.dtype),
                        chunks=None
                        if data.chunks is None
                        else tuple(int(x) for x in data.chunks),
                        compression=data.compression
                        or str(group.attrs.get("compression", "none")),
                        compression_opts=data.compression_opts,
                        valid_frames=int(np.count_nonzero(valid[:])),
                        total_frames=len(self),
                        units=str(group.attrs.get("units", "")),
                        description=str(group.attrs.get("description", "")),
                        attrs=attrs,
                    )
                )
        return rows

    def dataset_info(self) -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []
        for name, obj in self._h5.items():
            if isinstance(obj, h5py.Dataset):
                rows.append(
                    {
                        "name": name,
                        "shape": tuple(int(x) for x in obj.shape),
                        "dtype": str(obj.dtype),
                        "chunks": obj.chunks,
                        "compression": obj.compression,
                        "compression_opts": obj.compression_opts,
                        "nbytes": int(np.prod(obj.shape) * obj.dtype.itemsize),
                        "storage_size": int(obj.id.get_storage_size()),
                    }
                )
        return rows


def read_frame(
    filename: str | Path, index: int = 0, *, include_properties: bool = False
) -> Atoms:
    with H5Trajectory(filename) as traj:
        return traj.get_frame(index, include_properties=include_properties)


def iread(
    filename: str | Path,
    index: int | slice | Sequence[int] | None = None,
    *,
    include_properties: bool = False,
) -> Iterator[Atoms]:
    """Yield ASE Atoms lazily from a dumpDUCK HDF5 file."""
    with H5Trajectory(filename) as traj:
        if index is None:
            yield from traj.iter_frames(include_properties=include_properties)
        elif isinstance(index, int):
            yield traj.get_frame(index, include_properties=include_properties)
        elif isinstance(index, slice):
            yield from traj.iter_frames(
                index.start,
                index.stop,
                index.step,
                include_properties=include_properties,
            )
        else:
            for i in index:
                yield traj.get_frame(int(i), include_properties=include_properties)
