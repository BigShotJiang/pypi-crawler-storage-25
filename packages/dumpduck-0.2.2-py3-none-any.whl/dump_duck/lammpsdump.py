from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, TextIO
import gzip
import mmap

import numpy as np
from ase import Atoms


@dataclass(frozen=True)
class DumpFrame:
    timestep: int
    atoms: Atoms


@dataclass(frozen=True)
class LammpsFrame:
    timestep: int
    ids: np.ndarray
    types: np.ndarray
    atomic_numbers: np.ndarray
    positions: np.ndarray
    cell: np.ndarray
    pbc: tuple[bool, bool, bool]
    mol_ids: np.ndarray | None = None
    image_flags: np.ndarray | None = None


def parse_type_map(spec: str | None) -> dict[int, int]:
    """Parse strings like '1:C,2:H,3:N,4:Zn' or '1:6,2:1'."""
    if not spec:
        return {}

    from ase.data import atomic_numbers

    mapping: dict[int, int] = {}
    for item in spec.split(','):
        item = item.strip()
        if not item:
            continue
        if ':' not in item:
            raise ValueError(f"Invalid type-map item {item!r}; expected TYPE:ELEMENT")
        key, value = item.split(':', 1)
        lammps_type = int(key.strip())
        value = value.strip()
        mapping[lammps_type] = int(value) if value.isdigit() else int(atomic_numbers[value])
    return mapping


def _read_required_line(handle: TextIO) -> str:
    line = handle.readline()
    if line == '':
        raise EOFError('Unexpected end of LAMMPS dump')
    return line.rstrip('\n')


def _open_text_maybe_gz(path: str | Path):
    path = Path(path)
    if ''.join(path.suffixes[-2:]).lower().endswith('.gz') or path.suffix.lower() == '.gz':
        return gzip.open(path, 'rt', encoding='utf-8', errors='replace')
    return path.open('rt', encoding='utf-8', errors='replace')


def count_lammpstrj_frames(path: str | Path) -> int:
    """Count frames by counting ``ITEM: TIMESTEP`` records.

    Uses mmap for uncompressed files, which is usually much faster than Python
    line iteration. Falls back to streaming decompression for .gz files.
    """
    path = Path(path)
    is_gz = path.suffix.lower() == '.gz' or ''.join(path.suffixes[-2:]).lower().endswith('.gz')
    needle = b'ITEM: TIMESTEP'
    if is_gz:
        n = 0
        with gzip.open(path, 'rb') as handle:
            for line in handle:
                if line.startswith(needle):
                    n += 1
        return n

    with path.open('rb') as handle:
        with mmap.mmap(handle.fileno(), 0, access=mmap.ACCESS_READ) as mm:
            n = 0
            pos = 0
            while True:
                pos = mm.find(needle, pos)
                if pos < 0:
                    break
                n += 1
                pos += len(needle)
            return n


def _cell_from_bounds(bounds: list[list[float]]) -> np.ndarray:
    triclinic = any(len(row) >= 3 for row in bounds)
    if triclinic:
        xlo_bound, xhi_bound, xy = bounds[0][:3]
        ylo_bound, yhi_bound, xz = bounds[1][:3]
        zlo_bound, zhi_bound, yz = bounds[2][:3]

        xlo = xlo_bound - min(0.0, xy, xz, xy + xz)
        xhi = xhi_bound - max(0.0, xy, xz, xy + xz)
        ylo = ylo_bound - min(0.0, yz)
        yhi = yhi_bound - max(0.0, yz)
        zlo = zlo_bound
        zhi = zhi_bound

        return np.array(
            [[xhi - xlo, 0.0, 0.0], [xy, yhi - ylo, 0.0], [xz, yz, zhi - zlo]],
            dtype=np.float64,
        )

    xlo, xhi = bounds[0][:2]
    ylo, yhi = bounds[1][:2]
    zlo, zhi = bounds[2][:2]
    return np.diag([xhi - xlo, yhi - ylo, zhi - zlo]).astype(np.float64)


def _origin_from_bounds(bounds: list[list[float]]) -> np.ndarray:
    triclinic = any(len(row) >= 3 for row in bounds)
    if triclinic:
        xlo_bound, _xhi_bound, xy = bounds[0][:3]
        ylo_bound, _yhi_bound, xz = bounds[1][:3]
        zlo_bound, _zhi_bound, yz = bounds[2][:3]
        xlo = xlo_bound - min(0.0, xy, xz, xy + xz)
        ylo = ylo_bound - min(0.0, yz)
        return np.array([xlo, ylo, zlo], dtype=np.float64)
    return np.array([bounds[0][0], bounds[1][0], bounds[2][0]], dtype=np.float64)


def _pbc_from_box_header(box_header: str) -> tuple[bool, bool, bool]:
    tokens = box_header.split()[3:]
    flags = [token for token in tokens if token in {'p', 'f', 's', 'm'}]
    if len(flags) >= 6:
        return flags[0] == 'p', flags[2] == 'p', flags[4] == 'p'
    return True, True, True


def _numbers_from_types(types: np.ndarray, type_map: dict[int, int]) -> np.ndarray:
    if not type_map:
        return types.astype(np.int16, copy=False)
    max_type = int(max(max(type_map), np.max(types)))
    lookup = np.zeros(max_type + 1, dtype=np.int16)
    for lmp_type, number in type_map.items():
        lookup[int(lmp_type)] = int(number)
    if np.any(types > max_type) or np.any(lookup[types] == 0):
        missing = sorted(set(int(t) for t in np.unique(types) if int(t) >= len(lookup) or lookup[int(t)] == 0))
        raise ValueError(f'Missing entries in --type-map for LAMMPS types: {missing}')
    return lookup[types]


def read_lammps_frame_fast(handle: TextIO, type_map: dict[int, int] | None = None) -> LammpsFrame | None:
    """Read one LAMMPS frame using vectorised numeric parsing.

    This is much faster than splitting each atom line in Python. It supports
    numeric custom dumps such as ``id mol type x y z ix iy iz``. If an ``element``
    column is present, use ``read_dump_frame`` instead.
    """
    type_map = type_map or {}

    line = handle.readline()
    if line == '':
        return None
    line = line.rstrip('\n')
    if not line.startswith('ITEM: TIMESTEP'):
        raise ValueError(f"Expected 'ITEM: TIMESTEP', got {line!r}")

    timestep = int(_read_required_line(handle))

    line = _read_required_line(handle)
    if not line.startswith('ITEM: NUMBER OF ATOMS'):
        raise ValueError(f"Expected 'ITEM: NUMBER OF ATOMS', got {line!r}")
    n_atoms = int(_read_required_line(handle))

    box_header = _read_required_line(handle)
    if not box_header.startswith('ITEM: BOX BOUNDS'):
        raise ValueError(f"Expected 'ITEM: BOX BOUNDS', got {box_header!r}")
    bounds = [[float(x) for x in _read_required_line(handle).split()] for _ in range(3)]
    cell = _cell_from_bounds(bounds)
    origin = _origin_from_bounds(bounds)
    pbc = _pbc_from_box_header(box_header)

    atoms_header = _read_required_line(handle)
    if not atoms_header.startswith('ITEM: ATOMS'):
        raise ValueError(f"Expected 'ITEM: ATOMS', got {atoms_header!r}")
    columns = atoms_header.split()[2:]
    col = {name: i for i, name in enumerate(columns)}

    if 'element' in col:
        # Numeric np.fromstring cannot parse element symbols.
        frame = read_dump_frame_from_header(handle, timestep, n_atoms, cell, origin, pbc, columns, type_map)
        return _frame_to_lammps_frame(frame, type_map)

    if 'id' not in col:
        raise ValueError("LAMMPS dump must contain an 'id' column.")
    if 'type' not in col:
        raise ValueError("Numeric fast parser requires a 'type' column. Use a type-map.")

    coord_cols: tuple[str, str, str] | None = None
    for names in [('x', 'y', 'z'), ('xu', 'yu', 'zu'), ('xs', 'ys', 'zs'), ('xsu', 'ysu', 'zsu')]:
        if all(name in col for name in names):
            coord_cols = names
            break
    if coord_cols is None:
        raise ValueError('Could not find x/y/z, xu/yu/zu, xs/ys/zs, or xsu/ysu/zsu coordinates.')

    # Read the whole atom table for this frame, then parse in C via numpy.
    atom_lines = [handle.readline() for _ in range(n_atoms)]
    if any(line == '' for line in atom_lines):
        raise EOFError('Unexpected end of LAMMPS dump while reading atom table')
    block = ''.join(atom_lines)
    arr = np.fromstring(block, sep=' ', dtype=np.float64)
    n_cols = len(columns)
    expected = n_atoms * n_cols
    if arr.size != expected:
        raise ValueError(
            f'Could not parse atom table as a numeric block: got {arr.size} values, '
            f'expected {expected}. Columns were: {columns}'
        )
    arr = arr.reshape(n_atoms, n_cols)

    ids = arr[:, col['id']].astype(np.int64, copy=False)
    types = arr[:, col['type']].astype(np.int32, copy=False)
    positions = arr[:, [col[c] for c in coord_cols]].astype(np.float64, copy=True)
    if coord_cols in [('xs', 'ys', 'zs'), ('xsu', 'ysu', 'zsu')]:
        positions = positions @ cell + origin

    mol_col = 'mol-id' if 'mol-id' in col else 'mol' if 'mol' in col else None
    mol_ids = arr[:, col[mol_col]].astype(np.int64, copy=False) if mol_col is not None else None

    image_flags = None
    if all(name in col for name in ('ix', 'iy', 'iz')):
        image_flags = arr[:, [col['ix'], col['iy'], col['iz']]].astype(np.int32, copy=False)

    if ids.size > 1 and not np.all(ids[:-1] <= ids[1:]):
        order = np.argsort(ids)
        ids = ids[order]
        types = types[order]
        positions = positions[order]
        if mol_ids is not None:
            mol_ids = mol_ids[order]
        if image_flags is not None:
            image_flags = image_flags[order]

    numbers = _numbers_from_types(types, type_map)
    return LammpsFrame(
        timestep=timestep,
        ids=ids,
        types=types,
        atomic_numbers=numbers.astype(np.int16, copy=False),
        positions=positions,
        cell=cell,
        pbc=pbc,
        mol_ids=mol_ids,
        image_flags=image_flags,
    )


def _frame_to_lammps_frame(frame: DumpFrame, type_map: dict[int, int] | None = None) -> LammpsFrame:
    atoms = frame.atoms
    ids = np.asarray(atoms.arrays.get('id', np.arange(1, len(atoms) + 1)), dtype=np.int64)
    types = np.asarray(atoms.arrays.get('lammps_type', atoms.get_atomic_numbers()), dtype=np.int32)
    mol_ids = np.asarray(atoms.arrays['mol_id'], dtype=np.int64) if 'mol_id' in atoms.arrays else None
    image_flags = np.asarray(atoms.arrays['image_flags'], dtype=np.int32) if 'image_flags' in atoms.arrays else None
    return LammpsFrame(
        timestep=frame.timestep,
        ids=ids,
        types=types,
        atomic_numbers=np.asarray(atoms.get_atomic_numbers(), dtype=np.int16),
        positions=np.asarray(atoms.positions, dtype=np.float64),
        cell=np.asarray(atoms.cell.array, dtype=np.float64),
        pbc=tuple(bool(x) for x in atoms.pbc),
        mol_ids=mol_ids,
        image_flags=image_flags,
    )


def read_dump_frame_from_header(
    handle: TextIO,
    timestep: int,
    n_atoms: int,
    cell: np.ndarray,
    origin: np.ndarray,
    pbc: tuple[bool, bool, bool],
    columns: list[str],
    type_map: dict[int, int] | None = None,
) -> DumpFrame:
    """Slow fallback when the atom table contains non-numeric fields."""
    type_map = type_map or {}
    col = {name: i for i, name in enumerate(columns)}
    ids = np.empty(n_atoms, dtype=np.int64)
    types = np.empty(n_atoms, dtype=np.int32)
    positions = np.empty((n_atoms, 3), dtype=np.float64)
    mol_col = 'mol-id' if 'mol-id' in col else 'mol' if 'mol' in col else None
    mol_ids = np.empty(n_atoms, dtype=np.int64) if mol_col is not None else None
    image_flags = np.empty((n_atoms, 3), dtype=np.int32) if all(name in col for name in ('ix', 'iy', 'iz')) else None

    from ase.data import atomic_numbers

    symbols: list[str] | None = [] if 'element' in col else None
    coord_cols = None
    for names in [('x', 'y', 'z'), ('xu', 'yu', 'zu'), ('xs', 'ys', 'zs'), ('xsu', 'ysu', 'zsu')]:
        if all(name in col for name in names):
            coord_cols = names
            break
    if coord_cols is None:
        raise ValueError('Could not find coordinate columns.')

    for i in range(n_atoms):
        parts = _read_required_line(handle).split()
        ids[i] = int(parts[col['id']])
        if 'type' in col:
            types[i] = int(parts[col['type']])
        else:
            assert symbols is not None
            symbol = parts[col['element']]
            symbols.append(symbol)
            types[i] = atomic_numbers[symbol]
        if mol_ids is not None and mol_col is not None:
            mol_ids[i] = int(parts[col[mol_col]])
        raw = np.array([float(parts[col[c]]) for c in coord_cols], dtype=np.float64)
        positions[i] = raw @ cell + origin if coord_cols in [('xs', 'ys', 'zs'), ('xsu', 'ysu', 'zsu')] else raw
        if image_flags is not None:
            image_flags[i] = [int(parts[col['ix']]), int(parts[col['iy']]), int(parts[col['iz']])]

    order = np.argsort(ids)
    ids = ids[order]
    types = types[order]
    positions = positions[order]
    if mol_ids is not None:
        mol_ids = mol_ids[order]
    if image_flags is not None:
        image_flags = image_flags[order]

    if symbols is not None:
        ordered_symbols = np.array(symbols, dtype=object)[order].tolist()
        atoms = Atoms(symbols=ordered_symbols, positions=positions, cell=cell, pbc=pbc)
    else:
        atoms = Atoms(numbers=_numbers_from_types(types, type_map), positions=positions, cell=cell, pbc=pbc)
    atoms.arrays['id'] = ids
    atoms.arrays['lammps_type'] = types
    if mol_ids is not None:
        atoms.arrays['mol_id'] = mol_ids
    if image_flags is not None:
        atoms.arrays['image_flags'] = image_flags
    atoms.info['timestep'] = timestep
    return DumpFrame(timestep=timestep, atoms=atoms)


def read_dump_frame(handle: TextIO, type_map: dict[int, int] | None = None) -> DumpFrame | None:
    """Read one LAMMPS dump frame and return an ASE Atoms object."""
    fast = read_lammps_frame_fast(handle, type_map=type_map)
    if fast is None:
        return None
    atoms = Atoms(
        numbers=fast.atomic_numbers,
        positions=fast.positions,
        cell=fast.cell,
        pbc=fast.pbc,
    )
    atoms.arrays['id'] = fast.ids
    atoms.arrays['lammps_type'] = fast.types
    if fast.mol_ids is not None:
        atoms.arrays['mol_id'] = fast.mol_ids
    if fast.image_flags is not None:
        atoms.arrays['image_flags'] = fast.image_flags
    atoms.info['timestep'] = fast.timestep
    return DumpFrame(timestep=fast.timestep, atoms=atoms)


def iread_lammps_frames(path: str | Path, type_map: dict[int, int] | None = None) -> Iterable[LammpsFrame]:
    with _open_text_maybe_gz(path) as handle:
        while True:
            frame = read_lammps_frame_fast(handle, type_map=type_map)
            if frame is None:
                break
            yield frame


def iread_lammps_dump(path: str | Path, type_map: dict[int, int] | None = None) -> Iterable[Atoms]:
    for frame in iread_lammps_frames(path, type_map=type_map):
        atoms = Atoms(
            numbers=frame.atomic_numbers,
            positions=frame.positions,
            cell=frame.cell,
            pbc=frame.pbc,
        )
        atoms.arrays['id'] = frame.ids
        atoms.arrays['lammps_type'] = frame.types
        if frame.mol_ids is not None:
            atoms.arrays['mol_id'] = frame.mol_ids
        if frame.image_flags is not None:
            atoms.arrays['image_flags'] = frame.image_flags
        atoms.info['timestep'] = frame.timestep
        yield atoms
