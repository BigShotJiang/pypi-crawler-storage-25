"""dumpDUCK: compact lazy HDF5 trajectories with incremental properties."""

from .convert import convert
from .h5traj import H5Trajectory, PropertyInfo, iread, read_frame
from .lammpsdump import count_lammpstrj_frames, iread_lammps_dump, iread_lammps_frames, parse_type_map, read_dump_frame

__version__ = "0.2.0"

__all__ = [
    "H5Trajectory",
    "PropertyInfo",
    "convert",
    "iread",
    "count_lammpstrj_frames",
    "iread_lammps_dump",
    "iread_lammps_frames",
    "parse_type_map",
    "read_dump_frame",
    "read_frame",
]
