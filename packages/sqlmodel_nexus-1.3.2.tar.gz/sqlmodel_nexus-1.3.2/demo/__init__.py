"""SQLModel Nexus Demo application."""
