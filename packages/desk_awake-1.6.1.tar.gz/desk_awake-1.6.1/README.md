# Desk Awake

Cross-platform idle activity simulator with a web control panel. Keeps your session active over AnyDesk by generating mouse movements and keyboard actions.

Features:
- Auto-detects OS (macOS/Linux/Windows) and uses appropriate keys and commands
- **Web dashboard** — control run/pause/stop and AnyDesk connections from any browser
- **Connection monitoring** — detects AnyDesk drops, auto-reconnects, sends alerts
- **Notifications** — Slack, Discord, or generic webhook alerts on connection issues
- **Multi-day scheduling** — run daily on a schedule until an end date
- Expose via ngrok for remote control from anywhere

## Installation

```bash
pip install desk-awake

# On macOS, include optional mac dependencies
pip install "desk-awake[mac]"
```

## Usage

### Web Dashboard Mode (recommended)

Start the control panel:

```bash
desk-awake serve
desk-awake serve --port 8080
```

Then open `http://localhost:5000` in your browser. From the dashboard you can:
- **Run / Pause / Stop** the activity simulator
- **Connect to AnyDesk** by entering a remote address
- **Monitor connection health** — auto-reconnects on drops
- **Set webhook URL** for Slack/Discord alerts
- **View live logs**

To access remotely via ngrok:

```bash
# In another terminal
ngrok http 5000
```

### Headless Mode (no web UI)

```bash
# Run until a specific time
desk-awake run --until "18:30"

# Multi-day: run 09:00–18:30 daily until a date
desk-awake run -u "18:30" -s "09:00" -e "2026-06-15"

# Skip sleep on exit
desk-awake run -u "18:30" --no-sleep
```

### Exit behavior flags (headless mode)

| Flag | Description |
|------|-------------|
| `--close-anydesk` | Close AnyDesk when done (default) |
| `--no-close-anydesk` | Don't close AnyDesk when done |
| `--sleep` | Put machine to sleep when done |
| `--no-sleep` | Don't sleep when done |

### OS-specific defaults

| OS | Close AnyDesk | Sleep |
|----|---------------|-------|
| macOS | ✅ | ✅ |
| Linux | ✅ | ❌ |
| Windows | ✅ | ✅ |

## Connection Monitoring

When running in web dashboard mode with an AnyDesk address configured:
- Checks connection every 15 seconds
- On disconnect: attempts up to 5 reconnections
- Sends webhook notification on connection loss and recovery
- If all reconnect attempts fail, stops and sends a final alert

## Webhook Notifications

Set a webhook URL in the dashboard settings to receive alerts:
- Slack: `https://hooks.slack.com/services/...`
- Discord: `https://discord.com/api/webhooks/...`
- Any endpoint accepting JSON POST with `title` and `message` fields

## Running without installing

```bash
python -m desk_awake serve
python -m desk_awake run --until "18:30"
```

## Requirements

- Python 3.8+
- `pynput` (installed automatically)
- `flask` (installed automatically)
- On macOS: `pyobjc` packages (install with `pip install "desk-awake[mac]"`)
- On Linux: may need `xdotool` or X11 libs depending on your display server
