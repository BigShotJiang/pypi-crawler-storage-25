import argparse
import sys
from datetime import datetime

from .core import CURRENT_OS, parse_datetime, parse_date, perform_actions


def main():
    """CLI entry point for desk-awake."""
    parser = argparse.ArgumentParser(
        prog='desk-awake',
        description='Cross-platform idle activity simulator with web control panel.',
    )
    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # --- "run" subcommand (original headless mode) ---
    run_parser = subparsers.add_parser('run', help='Run in headless mode (no web UI)')
    run_parser.add_argument('--until', '-u', type=str, required=True,
                            help='Daily stop time in format "YYYY-MM-DD HH:MM" or "HH:MM" (24h format)')
    run_parser.add_argument('--end-date', '-e', type=str, default=None,
                            help='Run daily until this date (format: YYYY-MM-DD)')
    run_parser.add_argument('--start', '-s', type=str, default=None,
                            help='Daily start time in "HH:MM" format (used with --end-date)')
    run_parser.add_argument('--close-anydesk', action='store_true', dest='close_anydesk', default=None,
                            help='Close AnyDesk when done')
    run_parser.add_argument('--no-close-anydesk', action='store_false', dest='close_anydesk',
                            help='Do NOT close AnyDesk when done')
    run_parser.add_argument('--sleep', action='store_true', dest='sleep', default=None,
                            help='Put machine to sleep when done')
    run_parser.add_argument('--no-sleep', action='store_false', dest='sleep',
                            help='Do NOT put machine to sleep when done')

    # --- "serve" subcommand (web dashboard mode) ---
    serve_parser = subparsers.add_parser('serve', help='Start web control panel')
    serve_parser.add_argument('--port', '-p', type=int, default=5000,
                              help='Port for the web server (default: 5000)')
    serve_parser.add_argument('--host', type=str, default='0.0.0.0',
                              help='Host to bind to (default: 0.0.0.0)')
    serve_parser.add_argument('--ngrok', action='store_true', default=False,
                              help='Expose dashboard publicly via ngrok tunnel')
    serve_parser.add_argument('--ngrok-domain', type=str, default=None,
                              help='Use a static ngrok domain (e.g. your-name.ngrok-free.app)')
    serve_parser.add_argument('--password', type=str, default=None,
                              help='Set/update the dashboard password')

    # --- "set-password" subcommand ---
    pw_parser = subparsers.add_parser('set-password', help='Set or change the dashboard password')
    pw_parser.add_argument('password', type=str, help='The new password')

    # --- "install-service" subcommand (Linux systemd) ---
    svc_parser = subparsers.add_parser('install-service',
                                       help='Install as a systemd service (Linux, auto-start on boot)')
    svc_parser.add_argument('--port', '-p', type=int, default=5000,
                            help='Port for the web server (default: 5000)')
    svc_parser.add_argument('--ngrok', action='store_true', default=False,
                            help='Enable ngrok tunnel in the service')
    svc_parser.add_argument('--ngrok-domain', type=str, default=None,
                            help='Use a static ngrok domain')

    args = parser.parse_args()

    if args.command == 'serve':
        return _handle_serve(args)
    elif args.command == 'run':
        return _handle_run(args)
    elif args.command == 'set-password':
        return _handle_set_password(args)
    elif args.command == 'install-service':
        return _handle_install_service(args)
    else:
        parser.print_help()
        return 0


def _handle_serve(args):
    """Start the web dashboard server."""
    from .server import run_server
    from .auth import set_password, is_password_set

    # Set password if provided
    if args.password:
        set_password(args.password)
        print(f"Dashboard password set.")

    if not is_password_set():
        print("⚠️  No password set. Dashboard is open to anyone with the URL.")
        print("   Set one with: desk-awake set-password YOUR_PASSWORD")
        print("   Or: desk-awake serve --password YOUR_PASSWORD\n")

    if args.ngrok or args.ngrok_domain:
        from .tunnel import start_ngrok
        public_url = start_ngrok(args.port, domain=args.ngrok_domain)
        if public_url:
            from .server import app_state
            app_state.log(f"Public URL: {public_url}")

    run_server(host=args.host, port=args.port)
    return 0


def _handle_run(args):
    """Run in headless mode (original behavior)."""
    if args.close_anydesk is None:
        close_anydesk_on_exit = True
    else:
        close_anydesk_on_exit = args.close_anydesk

    if args.sleep is None:
        sleep_on_exit = CURRENT_OS != "linux"
    else:
        sleep_on_exit = args.sleep

    end_date = None
    if args.end_date:
        try:
            end_date = parse_date(args.end_date)
        except ValueError as e:
            print(f"Error: {e}")
            return 1

        from datetime import date as date_cls
        if end_date < date_cls.today():
            print("Error: --end-date must be today or in the future!")
            return 1

    try:
        stop_time = parse_datetime(args.until)

        if not end_date and stop_time <= datetime.now():
            print("Error: Stop time must be in the future!")
            return 1

        print(f"Starting activity simulation: ~50 keys/min, ~60 mouse movements/min")
        perform_actions(stop_time, close_anydesk_on_exit, sleep_on_exit,
                        end_date=end_date, start_time_str=args.start)
        return 0
    except ValueError as e:
        print(f"Error: {e}")
        return 1


def _handle_set_password(args):
    """Set the dashboard password."""
    from .auth import set_password
    set_password(args.password)
    print(f"✅ Dashboard password set successfully.")
    print(f"   Stored in: ~/.desk-awake/config.json")
    return 0


def _handle_install_service(args):
    """Install desk-awake as a systemd service."""
    import os
    import shutil
    import pwd

    if CURRENT_OS != 'linux':
        print("Error: install-service is only supported on Linux.")
        return 1

    user = os.environ.get('SUDO_USER', os.environ.get('USER', 'root'))
    home = os.path.expanduser(f'~{user}')

    # Get UID for the user (needed for XDG_RUNTIME_DIR and DBUS)
    try:
        uid = pwd.getpwnam(user).pw_uid
    except KeyError:
        uid = 1000  # fallback

    # Find the desk-awake binary
    desk_awake_bin = shutil.which('desk-awake')
    if not desk_awake_bin:
        possible_paths = [
            os.path.join(home, '.local', 'bin', 'desk-awake'),
            '/usr/local/bin/desk-awake',
            '/usr/bin/desk-awake',
        ]
        for p in possible_paths:
            if os.path.isfile(p):
                desk_awake_bin = p
                break

    if not desk_awake_bin:
        print("Error: desk-awake binary not found. Provide the full path manually.")
        return 1

    ngrok_flag = ''
    if args.ngrok:
        ngrok_flag = ' --ngrok'
    if args.ngrok_domain:
        ngrok_flag = f' --ngrok-domain {args.ngrok_domain}'

    # Auto-detect display environment
    display = os.environ.get('DISPLAY', ':0')
    xauthority = os.environ.get('XAUTHORITY', f'{home}/.Xauthority')
    wayland_display = os.environ.get('WAYLAND_DISPLAY', '')
    session_type = os.environ.get('XDG_SESSION_TYPE', 'x11')

    # Build environment lines
    env_lines = f"""Environment=HOME={home}
Environment=DISPLAY={display}
Environment=XAUTHORITY={xauthority}
Environment=DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/{uid}/bus
Environment=XDG_RUNTIME_DIR=/run/user/{uid}"""

    if wayland_display or session_type == 'wayland':
        wd = wayland_display or 'wayland-0'
        env_lines += f"\nEnvironment=WAYLAND_DISPLAY={wd}"

    service_content = f"""[Unit]
Description=Desk Awake - Activity Simulator Dashboard
After=network.target graphical.target
Wants=graphical.target

[Service]
Type=simple
User={user}
{env_lines}
ExecStart={desk_awake_bin} serve --port {args.port}{ngrok_flag}
Restart=on-failure
RestartSec=10

[Install]
WantedBy=multi-user.target
"""

    service_path = '/etc/systemd/system/desk-awake.service'

    # Check if we have permission
    if os.geteuid() != 0:
        print("Need sudo to install the service. Run:")
        print(f"  sudo -E /home/{user}/.local/bin/desk-awake install-service --port {args.port}" +
              (f' --ngrok-domain {args.ngrok_domain}' if args.ngrok_domain else
               ' --ngrok' if args.ngrok else ''))
        print(f"\n  (Use sudo -E to preserve display environment variables)\n")
        print(f"Or manually create {service_path} with:\n")
        print(service_content)
        return 1

    with open(service_path, 'w') as f:
        f.write(service_content)

    os.system('systemctl daemon-reload')
    os.system('systemctl enable desk-awake')
    os.system('systemctl start desk-awake')

    print(f"✅ Service installed and started!")
    print(f"   Display: {display} ({session_type})")
    print(f"   Status:  sudo systemctl status desk-awake")
    print(f"   Logs:    sudo journalctl -u desk-awake -f")
    print(f"   Stop:    sudo systemctl stop desk-awake")
    print(f"   Disable: sudo systemctl disable desk-awake")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
