"""Allow running the package directly with: python -m desk_awake"""

from .cli import main

raise SystemExit(main())
