import time
import subprocess
import random
import platform
from datetime import datetime, timedelta, date
from pynput.mouse import Controller as MouseController
from pynput.keyboard import Controller as KeyboardController, Key

# Initialize pynput controllers
mouse = MouseController()
keyboard = KeyboardController()

# Detect OS
CURRENT_OS = platform.system().lower()  # 'darwin' for macOS, 'linux' for Ubuntu/Linux, 'windows' for Windows


def get_modifier_key():
    """Return the appropriate modifier key for the current OS."""
    if CURRENT_OS == "darwin":
        return Key.cmd
    else:
        return Key.ctrl


def close_anydesk():
    """Close AnyDesk based on the current OS."""
    try:
        if CURRENT_OS == "darwin":
            subprocess.run(['osascript', '-e', 'tell application "AnyDesk" to quit'], check=False)
            subprocess.run(['pkill', '-f', 'AnyDesk'], check=False)
        elif CURRENT_OS == "linux":
            subprocess.run(['pkill', '-f', 'anydesk'], check=False)
        elif CURRENT_OS == "windows":
            subprocess.run(['taskkill', '/F', '/IM', 'AnyDesk.exe'], check=False)
        print("AnyDesk closed.")
    except Exception as e:
        print(f"Error closing AnyDesk: {e}")


def put_to_sleep():
    """Put the machine to sleep based on the current OS."""
    try:
        if CURRENT_OS == "darwin":
            subprocess.run(['osascript', '-e', 'tell application "System Events" to sleep'], check=False)
            print("Mac is going to sleep...")
        elif CURRENT_OS == "linux":
            subprocess.run(['systemctl', 'suspend'], check=False)
            print("Linux is going to sleep...")
        elif CURRENT_OS == "windows":
            subprocess.run(['rundll32.exe', 'powrprof.dll,SetSuspendState', '0,1,0'], check=False)
            print("Windows is going to sleep...")
    except Exception as e:
        print(f"Error putting machine to sleep: {e}")


def parse_datetime(datetime_str):
    """Parse datetime string in format YYYY-MM-DD HH:MM or HH:MM."""
    try:
        return datetime.strptime(datetime_str, '%Y-%m-%d %H:%M')
    except ValueError:
        try:
            return datetime.strptime(datetime_str, '%H:%M').replace(
                year=datetime.now().year,
                month=datetime.now().month,
                day=datetime.now().day
            )
        except ValueError:
            raise ValueError("Invalid datetime format. Use 'YYYY-MM-DD HH:MM' or 'HH:MM'")


def parse_date(date_str):
    """Parse date string in format YYYY-MM-DD."""
    try:
        return datetime.strptime(date_str, '%Y-%m-%d').date()
    except ValueError:
        raise ValueError("Invalid date format. Use 'YYYY-MM-DD'")


def random_mouse_movement():
    """Move the mouse by a small random offset."""
    dx = random.randint(-30, 30)
    dy = random.randint(-30, 30)
    mouse.move(dx, dy)


def random_keyboard_action():
    """Press a random navigation key."""
    actions = [Key.page_up, Key.page_down, Key.up, Key.down, Key.left, Key.right]
    if random.random() < 0.8:
        key = random.choice(actions)
        keyboard.press(key)
        time.sleep(random.uniform(0.02, 0.08))
        keyboard.release(key)


def _run_activity_loop(stop_time):
    """Core activity loop — runs until stop_time."""
    actions_per_second = (50 + 60) / 60  # ~1.83 actions per second

    while datetime.now() < stop_time:
        start_time = time.time()

        # Perform a burst of actions
        actions_this_cycle = random.randint(3, 8)

        for _ in range(actions_this_cycle):
            if random.random() < 0.55:  # Slightly favor mouse movements
                random_mouse_movement()
            else:
                random_keyboard_action()

            time.sleep(random.uniform(0.02, 0.1))

        # Maintain target rate
        elapsed = time.time() - start_time
        target_time = actions_this_cycle / actions_per_second

        if elapsed < target_time:
            time.sleep(target_time - elapsed)

        # Occasionally add a brief pause (10% chance)
        if random.random() < 0.1:
            idle_time = random.uniform(0.5, 2.0)
            print(f"Brief pause for {idle_time:.2f} seconds...")
            time.sleep(idle_time)


def perform_actions(stop_time, close_anydesk_on_exit, sleep_on_exit, end_date=None, start_time_str=None):
    """
    Run simulated activity until stop_time, then optionally close AnyDesk and sleep.

    If end_date is provided, the script runs daily:
      - Each day it runs from start_time_str (or now) until the --until time.
      - After each day's session, it sleeps until the next day's start time.
      - On the final day (end_date), it runs the last session and then exits.
    """
    print(f"Detected OS: {CURRENT_OS}")
    print(f"Modifier key: {'Cmd' if CURRENT_OS == 'darwin' else 'Ctrl'}")
    print(f"On exit: close AnyDesk={'yes' if close_anydesk_on_exit else 'no'}, "
          f"sleep={'yes' if sleep_on_exit else 'no'}")

    if end_date:
        daily_stop_hour = stop_time.hour
        daily_stop_minute = stop_time.minute
        daily_start_hour = int(start_time_str.split(':')[0]) if start_time_str else datetime.now().hour
        daily_start_minute = int(start_time_str.split(':')[1]) if start_time_str else datetime.now().minute

        print(f"Multi-day mode: running daily {daily_start_hour:02d}:{daily_start_minute:02d} → "
              f"{daily_stop_hour:02d}:{daily_stop_minute:02d} until {end_date}")
        print("-" * 50)

        current_date = date.today()

        while current_date <= end_date:
            today_start = datetime(current_date.year, current_date.month, current_date.day,
                                   daily_start_hour, daily_start_minute)
            today_stop = datetime(current_date.year, current_date.month, current_date.day,
                                  daily_stop_hour, daily_stop_minute)

            now = datetime.now()

            # If we haven't reached start time yet today, wait
            if now < today_start:
                wait_seconds = (today_start - now).total_seconds()
                print(f"[{current_date}] Waiting {wait_seconds/60:.0f} min until start time "
                      f"{daily_start_hour:02d}:{daily_start_minute:02d}...")
                time.sleep(wait_seconds)

            # If we've already passed today's stop time, skip to next day
            if datetime.now() >= today_stop:
                print(f"[{current_date}] Already past stop time, skipping to next day.")
                current_date += timedelta(days=1)
                continue

            print(f"[{current_date}] Running until {today_stop.strftime('%H:%M')}...")
            _run_activity_loop(today_stop)
            print(f"[{current_date}] Day session complete.")

            current_date += timedelta(days=1)

            # If there are more days, sleep overnight (idle wait)
            if current_date <= end_date:
                next_start = datetime(current_date.year, current_date.month, current_date.day,
                                      daily_start_hour, daily_start_minute)
                wait_seconds = (next_start - datetime.now()).total_seconds()
                if wait_seconds > 0:
                    print(f"Sleeping until next session: {next_start.strftime('%Y-%m-%d %H:%M')} "
                          f"({wait_seconds/3600:.1f} hours)")
                    time.sleep(wait_seconds)

        print("End date reached. All sessions complete.")
    else:
        # Single-run mode (original behavior)
        print(f"Running until {stop_time.strftime('%Y-%m-%d %H:%M')}...")
        print("-" * 50)
        _run_activity_loop(stop_time)
        print("Stop time reached. Exiting script.")

    if close_anydesk_on_exit:
        close_anydesk()

    if sleep_on_exit:
        put_to_sleep()
