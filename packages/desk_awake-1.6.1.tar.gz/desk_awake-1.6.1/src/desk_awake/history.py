"""Session history tracking with SQLite."""

import sqlite3
import os
import threading
from datetime import datetime, timedelta, date


DB_DIR = os.path.expanduser('~/.desk-awake')
DB_PATH = os.path.join(DB_DIR, 'history.db')

_local = threading.local()


def _get_conn():
    """Get a thread-local database connection."""
    if not hasattr(_local, 'conn') or _local.conn is None:
        os.makedirs(DB_DIR, exist_ok=True)
        _local.conn = sqlite3.connect(DB_PATH, check_same_thread=False)
        _local.conn.row_factory = sqlite3.Row
        _init_db(_local.conn)
    return _local.conn


def _init_db(conn):
    """Create tables if they don't exist."""
    conn.execute('''
        CREATE TABLE IF NOT EXISTS sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            start_time TEXT NOT NULL,
            end_time TEXT,
            duration_minutes REAL,
            anydesk_address TEXT,
            disconnects INTEGER DEFAULT 0,
            reconnects INTEGER DEFAULT 0,
            status TEXT DEFAULT 'running'
        )
    ''')
    conn.commit()


def start_session(anydesk_address=None):
    """Record a new session start. Returns session ID."""
    conn = _get_conn()
    cursor = conn.execute(
        'INSERT INTO sessions (start_time, anydesk_address, status) VALUES (?, ?, ?)',
        (datetime.now().isoformat(), anydesk_address, 'running')
    )
    conn.commit()
    return cursor.lastrowid


def end_session(session_id, disconnects=0, reconnects=0):
    """Mark a session as complete."""
    conn = _get_conn()
    now = datetime.now()

    # Get start time to calculate duration
    row = conn.execute('SELECT start_time FROM sessions WHERE id = ?', (session_id,)).fetchone()
    if row:
        start = datetime.fromisoformat(row['start_time'])
        duration = (now - start).total_seconds() / 60.0
    else:
        duration = 0

    conn.execute('''
        UPDATE sessions SET end_time = ?, duration_minutes = ?, 
        disconnects = ?, reconnects = ?, status = ?
        WHERE id = ?
    ''', (now.isoformat(), duration, disconnects, reconnects, 'completed', session_id))
    conn.commit()


def record_disconnect(session_id):
    """Increment disconnect count for a session."""
    conn = _get_conn()
    conn.execute('UPDATE sessions SET disconnects = disconnects + 1 WHERE id = ?', (session_id,))
    conn.commit()


def record_reconnect(session_id):
    """Increment reconnect count for a session."""
    conn = _get_conn()
    conn.execute('UPDATE sessions SET reconnects = reconnects + 1 WHERE id = ?', (session_id,))
    conn.commit()


def get_recent_sessions(limit=20):
    """Get the most recent sessions."""
    conn = _get_conn()
    rows = conn.execute(
        'SELECT * FROM sessions ORDER BY id DESC LIMIT ?', (limit,)
    ).fetchall()
    return [dict(row) for row in rows]


def get_stats_for_period(start_date, end_date):
    """Get total runtime stats for a date range."""
    conn = _get_conn()
    row = conn.execute('''
        SELECT 
            COUNT(*) as total_sessions,
            COALESCE(SUM(duration_minutes), 0) as total_minutes,
            COALESCE(SUM(disconnects), 0) as total_disconnects,
            COALESCE(SUM(reconnects), 0) as total_reconnects
        FROM sessions 
        WHERE start_time >= ? AND start_time < ?
        AND status = 'completed'
    ''', (start_date.isoformat(), end_date.isoformat())).fetchone()
    return dict(row)


def get_weekly_stats():
    """Get stats for the current week (Monday to now)."""
    today = date.today()
    monday = today - timedelta(days=today.weekday())
    start = datetime(monday.year, monday.month, monday.day)
    end = datetime.now()
    return get_stats_for_period(start, end)


def get_monthly_stats():
    """Get stats for the current month."""
    today = date.today()
    start = datetime(today.year, today.month, 1)
    end = datetime.now()
    return get_stats_for_period(start, end)


def get_daily_breakdown(days=7):
    """Get daily runtime for the last N days."""
    conn = _get_conn()
    results = []
    for i in range(days - 1, -1, -1):
        d = date.today() - timedelta(days=i)
        start = datetime(d.year, d.month, d.day)
        end = start + timedelta(days=1)
        row = conn.execute('''
            SELECT COALESCE(SUM(duration_minutes), 0) as minutes
            FROM sessions 
            WHERE start_time >= ? AND start_time < ?
            AND status = 'completed'
        ''', (start.isoformat(), end.isoformat())).fetchone()
        results.append({
            'date': d.isoformat(),
            'day': d.strftime('%a'),
            'hours': round(row['minutes'] / 60, 1)
        })
    return results
