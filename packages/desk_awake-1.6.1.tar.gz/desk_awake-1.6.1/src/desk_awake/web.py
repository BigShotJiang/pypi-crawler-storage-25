"""Web dashboard for controlling desk-awake remotely."""

import secrets
from flask import Flask, jsonify, request, render_template_string, session, redirect
from .state import AppState, Status
from .auth import require_auth, verify_password, is_password_set, LOGIN_HTML
from .ratelimit import rate_limit, login_rate_limit

app = Flask(__name__)
app.secret_key = secrets.token_hex(32)
state: AppState = None  # Set by server.py before starting


HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Desk Awake - Control Panel</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
               background: #1a1a2e; color: #eee; min-height: 100vh; padding: 20px; }
        .container { max-width: 800px; margin: 0 auto; }
        h1 { text-align: center; margin-bottom: 30px; color: #00d4aa; font-size: 1.8em; }
        .card { background: #16213e; border-radius: 12px; padding: 24px; margin-bottom: 20px;
                border: 1px solid #0f3460; }
        .card h2 { color: #00d4aa; margin-bottom: 16px; font-size: 1.2em; }
        .status-badge { display: inline-block; padding: 6px 16px; border-radius: 20px;
                        font-weight: bold; font-size: 0.9em; text-transform: uppercase; }
        .status-running { background: #00d4aa33; color: #00d4aa; }
        .status-paused { background: #f0a50033; color: #f0a500; }
        .status-stopped { background: #e7305b33; color: #e7305b; }
        .status-idle { background: #ffffff22; color: #aaa; }
        .status-reconnecting { background: #f0a50033; color: #f0a500; }
        .btn { padding: 10px 20px; border: none; border-radius: 8px; cursor: pointer;
               font-size: 0.95em; font-weight: 600; margin: 4px; transition: all 0.2s; position: relative; }
        .btn:hover { opacity: 0.85; }
        .btn:disabled { opacity: 0.5; cursor: not-allowed; }
        .btn.loading { pointer-events: none; }
        .btn.loading::after { content: ''; position: absolute; right: 8px; top: 50%;
               width: 14px; height: 14px; margin-top: -7px; border: 2px solid transparent;
               border-top-color: currentColor; border-radius: 50%; animation: spin 0.6s linear infinite; }
        @keyframes spin { to { transform: rotate(360deg); } }
        .btn-run { background: #00d4aa; color: #1a1a2e; }
        .btn-pause { background: #f0a500; color: #1a1a2e; }
        .btn-stop { background: #e7305b; color: #fff; }
        .btn-connect { background: #4a90d9; color: #fff; }
        .btn-disconnect { background: #666; color: #fff; }
        .btn-sm { padding: 6px 12px; font-size: 0.8em; }
        .form-group { margin-bottom: 14px; }
        .form-group label { display: block; margin-bottom: 6px; color: #aaa; font-size: 0.85em; }
        .form-group input { width: 100%; padding: 10px; border-radius: 6px; border: 1px solid #0f3460;
                            background: #1a1a2e; color: #eee; font-size: 0.95em; }
        .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
        .info-item { padding: 12px; background: #1a1a2e; border-radius: 8px; }
        .info-item .label { color: #888; font-size: 0.8em; text-transform: uppercase; }
        .info-item .value { color: #eee; font-size: 1.1em; margin-top: 4px; }
        .stats-grid { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 12px; }
        .stat-card { padding: 16px; background: #1a1a2e; border-radius: 8px; text-align: center; }
        .stat-card .stat-value { font-size: 1.6em; font-weight: bold; color: #00d4aa; }
        .stat-card .stat-label { font-size: 0.75em; color: #888; text-transform: uppercase; margin-top: 4px; }
        .daily-bar { display: flex; align-items: flex-end; gap: 6px; height: 80px; margin-top: 12px; }
        .daily-bar .bar-item { flex: 1; display: flex; flex-direction: column; align-items: center; }
        .daily-bar .bar { background: #00d4aa; border-radius: 4px 4px 0 0; min-height: 2px; width: 100%; transition: height 0.3s; }
        .daily-bar .bar-label { font-size: 0.65em; color: #888; margin-top: 4px; }
        .session-table { width: 100%; border-collapse: collapse; font-size: 0.8em; }
        .session-table th { text-align: left; padding: 8px; color: #888; border-bottom: 1px solid #0f3460; }
        .session-table td { padding: 8px; border-bottom: 1px solid #0f346033; }
        .session-table tr:hover { background: #1a1a2e; }
        .logs { background: #0d1117; border-radius: 8px; padding: 16px; max-height: 300px;
                overflow-y: auto; font-family: monospace; font-size: 0.8em; line-height: 1.6; }
        .logs p { color: #8b949e; margin: 2px 0; }
        .connection-dot { display: inline-block; width: 10px; height: 10px; border-radius: 50%;
                          margin-right: 8px; }
        .dot-green { background: #00d4aa; }
        .dot-red { background: #e7305b; }
        .dot-yellow { background: #f0a500; animation: pulse 1s ease-in-out infinite; }
        @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.4; } }
        .toast { position: fixed; bottom: 20px; left: 50%; transform: translateX(-50%);
                 padding: 12px 24px; border-radius: 8px; font-size: 0.9em; font-weight: 500;
                 z-index: 1000; transition: all 0.3s ease; opacity: 0; pointer-events: none; }
        .toast.show { opacity: 1; pointer-events: auto; }
        .toast-success { background: #00d4aa; color: #1a1a2e; }
        .toast-error { background: #e7305b; color: #fff; }
        .toast-info { background: #4a90d9; color: #fff; }
        .logout-link { position: absolute; top: 20px; right: 20px; color: #888; font-size: 0.85em;
                       text-decoration: none; }
        .logout-link:hover { color: #e7305b; }
        @media (max-width: 600px) { 
            .info-grid { grid-template-columns: 1fr; }
            .stats-grid { grid-template-columns: 1fr 1fr; }
        }
    </style>
</head>
<body>
    <a href="/logout" class="logout-link">🔒 Logout</a>
    <div class="container">
        <h1>🖥️ Desk Awake</h1>

        <!-- Status Card -->
        <div class="card">
            <h2>Status</h2>
            <div style="display: flex; align-items: center; gap: 16px; flex-wrap: wrap;">
                <span id="status-badge" class="status-badge status-idle">IDLE</span>
                <span id="connection-status">
                    <span class="connection-dot" style="background:#666"></span>No address configured
                </span>
            </div>
            <div class="info-grid" style="margin-top: 16px;">
                <div class="info-item">
                    <div class="label">Stop Time</div>
                    <div class="value" id="stop-time">—</div>
                </div>
                <div class="info-item">
                    <div class="label">End Date</div>
                    <div class="value" id="end-date">—</div>
                </div>
                <div class="info-item">
                    <div class="label">Last Activity</div>
                    <div class="value" id="last-activity">—</div>
                </div>
                <div class="info-item">
                    <div class="label">Reconnect Attempts</div>
                    <div class="value" id="reconnect-attempts">0</div>
                </div>
            </div>
        </div>

        <!-- Stats Card -->
        <div class="card">
            <h2>Runtime Stats</h2>
            <div class="stats-grid" id="stats-grid">
                <div class="stat-card">
                    <div class="stat-value" id="stat-today">0h</div>
                    <div class="stat-label">Today</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value" id="stat-week">0h</div>
                    <div class="stat-label">This Week</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value" id="stat-month">0h</div>
                    <div class="stat-label">This Month</div>
                </div>
            </div>
            <div class="daily-bar" id="daily-bar"></div>
        </div>

        <!-- Controls Card -->
        <div class="card">
            <h2>Controls</h2>
            <div style="margin-bottom: 16px;">
                <button class="btn btn-run" onclick="controlAction('run')">▶ Run</button>
                <button class="btn btn-pause" onclick="controlAction('pause')">⏸ Pause</button>
                <button class="btn btn-stop" onclick="controlAction('stop')">⏹ Stop</button>
            </div>
            <div class="form-group">
                <label>Activity Profile</label>
                <div id="profile-selector" style="display:flex; flex-wrap:wrap; gap:6px; margin-bottom:14px;"></div>
            </div>
            <div class="form-group">
                <label>Stop Time (HH:MM or YYYY-MM-DD HH:MM)</label>
                <input type="text" id="input-until" placeholder="18:30">
            </div>
            <div class="form-group">
                <label>End Date (YYYY-MM-DD, optional for multi-day)</label>
                <input type="text" id="input-end-date" placeholder="2026-06-15">
            </div>
            <div class="form-group">
                <label>Daily Start Time (HH:MM, optional)</label>
                <input type="text" id="input-start" placeholder="09:00">
            </div>
        </div>

        <!-- AnyDesk Card -->
        <div class="card">
            <h2>AnyDesk Connection</h2>
            <div class="form-group">
                <label>AnyDesk Address / ID</label>
                <input type="text" id="input-address" placeholder="123 456 789">
            </div>
            <div class="form-group">
                <label>Password (optional, for unattended access)</label>
                <input type="password" id="input-password" placeholder="password">
            </div>
            <div>
                <button class="btn btn-connect" onclick="connectAnydesk()">🔗 Connect</button>
                <button class="btn btn-disconnect" onclick="disconnectAnydesk()">✂️ Disconnect</button>
            </div>
        </div>

        <!-- Saved Devices Card -->
        <div class="card">
            <h2>⭐ Saved Devices</h2>
            <div id="devices-list" style="margin-bottom: 16px;"></div>
            <details style="margin-top: 12px;">
                <summary style="cursor: pointer; color: #00d4aa; font-size: 0.9em;">+ Add New Device</summary>
                <div style="margin-top: 12px;">
                    <div class="form-group">
                        <label>Device Name</label>
                        <input type="text" id="new-device-name" placeholder="Work Laptop">
                    </div>
                    <div class="form-group">
                        <label>AnyDesk Address / ID</label>
                        <input type="text" id="new-device-address" placeholder="123 456 789">
                    </div>
                    <div class="form-group">
                        <label>Password (optional)</label>
                        <input type="password" id="new-device-password" placeholder="password">
                    </div>
                    <button class="btn btn-run" onclick="addDevice()">💾 Save Device</button>
                </div>
            </details>
        </div>

        <!-- Session History Card -->
        <div class="card">
            <h2>Session History</h2>
            <table class="session-table" id="session-table">
                <thead>
                    <tr><th>Date</th><th>Duration</th><th>Address</th><th>Disconnects</th><th>Status</th></tr>
                </thead>
                <tbody id="session-tbody">
                    <tr><td colspan="5" style="color:#888">Loading...</td></tr>
                </tbody>
            </table>
        </div>

        <!-- Settings Card -->
        <div class="card">
            <h2>Settings</h2>
            <div class="form-group">
                <label>Webhook URL (Slack/Discord/generic, for alerts)</label>
                <input type="text" id="input-webhook" placeholder="https://hooks.slack.com/...">
            </div>
            <div style="margin-top: 10px;">
                <button class="btn btn-run" onclick="saveSettings()">💾 Save Settings</button>
            </div>
        </div>

        <!-- Logs Card -->
        <div class="card">
            <h2>Logs</h2>
            <div class="logs" id="logs-container">
                <p>Waiting for activity...</p>
            </div>
        </div>
    </div>

    <!-- Toast notification -->
    <div class="toast" id="toast"></div>

    <script>
        let toastTimeout = null;
        function showToast(message, type) {
            const toast = document.getElementById('toast');
            toast.textContent = message;
            toast.className = 'toast toast-' + (type || 'info') + ' show';
            if (toastTimeout) clearTimeout(toastTimeout);
            toastTimeout = setTimeout(() => { toast.classList.remove('show'); }, 3000);
        }

        function setButtonLoading(btn, loading) {
            if (loading) {
                btn.classList.add('loading');
                btn.disabled = true;
                btn._originalText = btn.textContent;
                btn.textContent = btn.textContent + '  ';
            } else {
                btn.classList.remove('loading');
                btn.disabled = false;
                if (btn._originalText) btn.textContent = btn._originalText;
            }
        }

        function updateStatus() {
            fetch('/api/status')
                .then(r => { if (r.status === 401) { window.location='/login'; } return r.json(); })
                .then(data => {
                    const badge = document.getElementById('status-badge');
                    badge.textContent = data.status.toUpperCase();
                    badge.className = 'status-badge status-' + data.status;

                    document.getElementById('stop-time').textContent = data.stop_time || '—';
                    document.getElementById('end-date').textContent = data.end_date || '—';
                    document.getElementById('last-activity').textContent = data.last_activity || '—';
                    document.getElementById('reconnect-attempts').textContent = data.reconnect_attempts;

                    const connEl = document.getElementById('connection-status');
                    if (!data.anydesk_address) {
                        connEl.innerHTML = '<span class="connection-dot" style="background:#666"></span>No address configured';
                    } else if (data.connection_healthy) {
                        connEl.innerHTML = '<span class="connection-dot dot-green"></span>Connected to ' + data.anydesk_address;
                    } else if (data.status === 'reconnecting') {
                        connEl.innerHTML = '<span class="connection-dot dot-yellow"></span>Reconnecting...';
                    } else {
                        connEl.innerHTML = '<span class="connection-dot dot-red"></span>Disconnected';
                    }
                }).catch(() => {});
        }

        function updateLogs() {
            fetch('/api/logs').then(r => r.json()).then(data => {
                const container = document.getElementById('logs-container');
                if (data.logs && data.logs.length > 0) {
                    container.innerHTML = data.logs.map(l => '<p>' + l + '</p>').join('');
                    container.scrollTop = container.scrollHeight;
                }
            }).catch(() => {});
        }

        function updateStats() {
            fetch('/api/stats').then(r => r.json()).then(data => {
                document.getElementById('stat-today').textContent = data.today_hours + 'h';
                document.getElementById('stat-week').textContent = data.week_hours + 'h';
                document.getElementById('stat-month').textContent = data.month_hours + 'h';

                // Daily bar chart
                const barContainer = document.getElementById('daily-bar');
                if (data.daily && data.daily.length > 0) {
                    const maxH = Math.max(...data.daily.map(d => d.hours), 1);
                    barContainer.innerHTML = data.daily.map(d => {
                        const pct = (d.hours / maxH) * 100;
                        return '<div class="bar-item">' +
                            '<div class="bar" style="height:' + Math.max(pct, 3) + '%"></div>' +
                            '<div class="bar-label">' + d.day + '</div></div>';
                    }).join('');
                }
            }).catch(() => {});
        }

        function updateHistory() {
            fetch('/api/history').then(r => r.json()).then(data => {
                const tbody = document.getElementById('session-tbody');
                if (data.sessions && data.sessions.length > 0) {
                    tbody.innerHTML = data.sessions.map(s => {
                        const dur = s.duration_minutes ? (s.duration_minutes / 60).toFixed(1) + 'h' : '—';
                        const dt = s.start_time ? s.start_time.split('T')[0] + ' ' + s.start_time.split('T')[1].substring(0,5) : '—';
                        const addr = s.anydesk_address || '—';
                        const disc = s.disconnects || 0;
                        const st = s.status || '—';
                        return '<tr><td>' + dt + '</td><td>' + dur + '</td><td>' + addr + '</td><td>' + disc + '</td><td>' + st + '</td></tr>';
                    }).join('');
                } else {
                    tbody.innerHTML = '<tr><td colspan="5" style="color:#888">No sessions yet</td></tr>';
                }
            }).catch(() => {});
        }

        function controlAction(action) {
            const btn = event.target;
            setButtonLoading(btn, true);
            showToast('Processing ' + action + '...', 'info');

            const body = { action: action };
            if (action === 'run') {
                const until = document.getElementById('input-until').value;
                const endDate = document.getElementById('input-end-date').value;
                const start = document.getElementById('input-start').value;
                if (until) body.until = until;
                if (endDate) body.end_date = endDate;
                if (start) body.start = start;
            }
            fetch('/api/control', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body)
            }).then(r => r.json()).then(data => {
                setButtonLoading(btn, false);
                if (data.error) { showToast(data.error, 'error'); }
                else { showToast(action.charAt(0).toUpperCase() + action.slice(1) + ' successful', 'success'); }
                updateStatus(); updateLogs();
            }).catch(() => { setButtonLoading(btn, false); showToast('Request failed', 'error'); });
        }

        function connectAnydesk() {
            const address = document.getElementById('input-address').value;
            const password = document.getElementById('input-password').value;
            if (!address) { showToast('Enter an AnyDesk address', 'error'); return; }

            const btn = event.target;
            setButtonLoading(btn, true);
            const connEl = document.getElementById('connection-status');
            connEl.innerHTML = '<span class="connection-dot dot-yellow"></span>Connecting to ' + address + '...';
            showToast('Connecting to ' + address + '...', 'info');

            fetch('/api/anydesk/connect', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ address: address, password: password || null })
            }).then(r => r.json()).then(data => {
                setButtonLoading(btn, false);
                if (data.error) { showToast('Connection failed: ' + data.error, 'error'); }
                else { showToast('Connected to ' + address, 'success'); }
                updateStatus(); updateLogs();
            }).catch(() => { setButtonLoading(btn, false); showToast('Connection request failed', 'error'); updateStatus(); });
        }

        function disconnectAnydesk() {
            const btn = event.target;
            setButtonLoading(btn, true);
            const connEl = document.getElementById('connection-status');
            connEl.innerHTML = '<span class="connection-dot dot-yellow"></span>Disconnecting...';
            showToast('Disconnecting...', 'info');

            fetch('/api/anydesk/disconnect', { method: 'POST' }).then(r => r.json()).then(() => {
                setButtonLoading(btn, false);
                showToast('Disconnected', 'success');
                updateStatus(); updateLogs();
            }).catch(() => { setButtonLoading(btn, false); showToast('Disconnect failed', 'error'); updateStatus(); });
        }

        function saveSettings() {
            const btn = event.target;
            setButtonLoading(btn, true);
            const webhook = document.getElementById('input-webhook').value;
            fetch('/api/settings', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ webhook_url: webhook || null })
            }).then(r => r.json()).then(() => {
                setButtonLoading(btn, false);
                showToast('Settings saved', 'success');
            }).catch(() => { setButtonLoading(btn, false); showToast('Failed to save settings', 'error'); });
        }

        // --- Profiles ---
        function loadProfiles() {
            fetch('/api/profiles').then(r => {
                if (!r.ok) throw new Error('Status ' + r.status);
                return r.json();
            }).then(data => {
                const container = document.getElementById('profile-selector');
                container.innerHTML = data.profiles.map(p => {
                    const active = p.id === data.current;
                    const style = active
                        ? 'background:#00d4aa;color:#1a1a2e;'
                        : 'background:#1a1a2e;color:#aaa;border:1px solid #0f3460;';
                    return '<button onclick="setProfile(\'' + p.id + '\')" ' +
                        'style="padding:8px 14px;border-radius:8px;border:none;cursor:pointer;font-size:0.8em;' + style + '" ' +
                        'title="' + p.description + '">' +
                        p.icon + ' ' + p.name + '</button>';
                }).join('');
            }).catch(err => { console.error('loadProfiles failed:', err); });
        }

        function setProfile(profileId) {
            fetch('/api/profiles', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ profile: profileId })
            }).then(r => r.json()).then(data => {
                if (data.error) { showToast(data.error, 'error'); }
                else { showToast('Profile: ' + profileId, 'success'); loadProfiles(); }
            }).catch(() => { showToast('Failed', 'error'); });
        }

        // --- Saved Devices ---
        function loadDevices() {
            fetch('/api/devices').then(r => r.json()).then(data => {
                const container = document.getElementById('devices-list');
                if (!data.devices || data.devices.length === 0) {
                    container.innerHTML = '<p style="color:#888; font-size:0.85em;">No saved devices yet. Add one below.</p>';
                    return;
                }
                container.innerHTML = data.devices.map(d => {
                    return '<div style="display:flex; align-items:center; gap:8px; padding:10px; background:#1a1a2e; border-radius:8px; margin-bottom:8px;">' +
                        '<div style="flex:1;">' +
                            '<div style="font-weight:600;">' + d.name + '</div>' +
                            '<div style="font-size:0.8em; color:#888;">' + d.address + (d.has_password ? ' 🔑' : '') + '</div>' +
                        '</div>' +
                        '<button class="btn btn-connect btn-sm" onclick="quickConnect(' + d.id + ')">⚡ Connect</button>' +
                        '<button class="btn btn-sm" style="background:#e7305b33;color:#e7305b;" onclick="deleteDevice(' + d.id + ')">✕</button>' +
                    '</div>';
                }).join('');
            }).catch(() => {});
        }

        function quickConnect(deviceId) {
            const btn = event.target;
            setButtonLoading(btn, true);
            showToast('Connecting...', 'info');
            const connEl = document.getElementById('connection-status');
            connEl.innerHTML = '<span class="connection-dot dot-yellow"></span>Connecting...';

            fetch('/api/devices/' + deviceId + '/connect', { method: 'POST' })
                .then(r => r.json()).then(data => {
                    setButtonLoading(btn, false);
                    if (data.error) { showToast(data.error, 'error'); }
                    else { showToast('Connected to ' + (data.name || 'device'), 'success'); }
                    updateStatus(); updateLogs();
                }).catch(() => { setButtonLoading(btn, false); showToast('Failed', 'error'); });
        }

        function addDevice() {
            const name = document.getElementById('new-device-name').value;
            const address = document.getElementById('new-device-address').value;
            const password = document.getElementById('new-device-password').value;
            if (!name || !address) { showToast('Name and address required', 'error'); return; }

            fetch('/api/devices', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name, address, password: password || null })
            }).then(r => r.json()).then(data => {
                if (data.error) { showToast(data.error, 'error'); }
                else {
                    showToast('Device saved', 'success');
                    document.getElementById('new-device-name').value = '';
                    document.getElementById('new-device-address').value = '';
                    document.getElementById('new-device-password').value = '';
                    loadDevices();
                }
            }).catch(() => { showToast('Failed to save', 'error'); });
        }

        function deleteDevice(deviceId) {
            if (!confirm('Remove this device?')) return;
            fetch('/api/devices/' + deviceId, { method: 'DELETE' })
                .then(r => r.json()).then(() => {
                    showToast('Device removed', 'success');
                    loadDevices();
                }).catch(() => { showToast('Failed', 'error'); });
        }

        // Polling
        setInterval(updateStatus, 2000);
        setInterval(updateLogs, 3000);
        setInterval(updateStats, 30000);
        updateStatus(); updateLogs(); updateStats(); updateHistory(); loadDevices(); loadProfiles();
    </script>
</body>
</html>
"""


# --- Routes ---

@app.route('/login', methods=['GET', 'POST'])
@login_rate_limit
def login():
    if not is_password_set():
        return redirect('/')
    if request.method == 'POST':
        password = request.form.get('password', '')
        if verify_password(password):
            session['authenticated'] = True
            return redirect('/')
        return render_template_string(LOGIN_HTML, error='Invalid password')
    return render_template_string(LOGIN_HTML, error=None)


@app.route('/logout')
def logout():
    session.pop('authenticated', None)
    return redirect('/login')


@app.route('/')
@require_auth
def index():
    return render_template_string(HTML_TEMPLATE)


@app.route('/api/status')
@require_auth
def api_status():
    return jsonify(state.get_info())


@app.route('/api/logs')
@require_auth
def api_logs():
    return jsonify({"logs": state.logs[-50:]})


@app.route('/api/stats')
@rate_limit
@require_auth
def api_stats():
    from .history import get_weekly_stats, get_monthly_stats, get_daily_breakdown
    weekly = get_weekly_stats()
    monthly = get_monthly_stats()
    daily = get_daily_breakdown(7)

    # Today's hours from daily breakdown
    today_hours = daily[-1]['hours'] if daily else 0

    return jsonify({
        "today_hours": today_hours,
        "week_hours": round(weekly['total_minutes'] / 60, 1),
        "month_hours": round(monthly['total_minutes'] / 60, 1),
        "week_sessions": weekly['total_sessions'],
        "month_sessions": monthly['total_sessions'],
        "daily": daily
    })


@app.route('/api/history')
@rate_limit
@require_auth
def api_history():
    from .history import get_recent_sessions
    sessions = get_recent_sessions(20)
    return jsonify({"sessions": sessions})


@app.route('/api/control', methods=['POST'])
@rate_limit
@require_auth
def api_control():
    from .core import parse_datetime, parse_date

    data = request.get_json() or {}
    action = data.get('action')

    if action == 'run':
        if state.status == Status.RUNNING:
            return jsonify({"error": "Already running"})

        until_str = data.get('until')
        if not until_str and not state.stop_time:
            return jsonify({"error": "Provide 'until' time"})

        if until_str:
            try:
                state.stop_time = parse_datetime(until_str)
            except ValueError as e:
                return jsonify({"error": str(e)})

        end_date_str = data.get('end_date')
        if end_date_str:
            try:
                state.end_date = parse_date(end_date_str)
            except ValueError as e:
                return jsonify({"error": str(e)})

        start_str = data.get('start')
        if start_str:
            state.start_time_str = start_str

        state.status = Status.RUNNING
        return jsonify({"ok": True, "status": "running"})

    elif action == 'pause':
        if state.status != Status.RUNNING:
            return jsonify({"error": "Not running"})
        state.status = Status.PAUSED
        return jsonify({"ok": True, "status": "paused"})

    elif action == 'stop':
        state.status = Status.STOPPED
        return jsonify({"ok": True, "status": "stopped"})

    else:
        return jsonify({"error": f"Unknown action: {action}"})


@app.route('/api/anydesk/connect', methods=['POST'])
@rate_limit
@require_auth
def api_anydesk_connect():
    from .anydesk import connect_to_address

    data = request.get_json() or {}
    address = data.get('address')
    password = data.get('password')

    if not address:
        return jsonify({"error": "Address required"})

    state.anydesk_address = address
    state.anydesk_password = password
    state.log(f"Connecting to AnyDesk: {address}")

    success = connect_to_address(address, password)
    if success:
        state.connection_healthy = True
        state.reconnect_attempts = 0
        state.log("AnyDesk connected.")
        return jsonify({"ok": True})
    else:
        state.connection_healthy = False
        state.log("AnyDesk connection failed — could not verify session.")
        return jsonify({"error": "Connection not established. Check address/password."})


@app.route('/api/anydesk/disconnect', methods=['POST'])
@rate_limit
@require_auth
def api_anydesk_disconnect():
    from .anydesk import close_anydesk

    close_anydesk()
    state.connection_healthy = False
    state.anydesk_address = None
    state.log("AnyDesk disconnected.")
    return jsonify({"ok": True})


@app.route('/api/settings', methods=['POST'])
@rate_limit
@require_auth
def api_settings():
    data = request.get_json() or {}

    if 'webhook_url' in data:
        state.webhook_url = data['webhook_url']
        state.log(f"Webhook URL updated.")

    if 'close_anydesk_on_exit' in data:
        state.close_anydesk_on_exit = bool(data['close_anydesk_on_exit'])

    if 'sleep_on_exit' in data:
        state.sleep_on_exit = bool(data['sleep_on_exit'])

    return jsonify({"ok": True})


# --- Device Management Routes ---

@app.route('/api/devices', methods=['GET'])
@rate_limit
@require_auth
def api_devices_list():
    from .devices import get_all_devices
    return jsonify({"devices": get_all_devices()})


@app.route('/api/devices', methods=['POST'])
@rate_limit
@require_auth
def api_devices_add():
    from .devices import add_device

    data = request.get_json() or {}
    name = data.get('name')
    address = data.get('address')
    password = data.get('password')

    if not name or not address:
        return jsonify({"error": "Name and address are required"})

    device_id = add_device(name, address, password)
    state.log(f"Device saved: {name} ({address})")
    return jsonify({"ok": True, "id": device_id})


@app.route('/api/devices/<int:device_id>', methods=['DELETE'])
@rate_limit
@require_auth
def api_devices_delete(device_id):
    from .devices import delete_device
    delete_device(device_id)
    state.log(f"Device #{device_id} removed.")
    return jsonify({"ok": True})


@app.route('/api/devices/<int:device_id>/connect', methods=['POST'])
@rate_limit
@require_auth
def api_devices_connect(device_id):
    from .devices import get_device
    from .anydesk import connect_to_address

    device = get_device(device_id)
    if not device:
        return jsonify({"error": "Device not found"})

    address = device['address']
    password = device.get('password')

    state.anydesk_address = address
    state.anydesk_password = password
    state.log(f"Quick connecting to: {device['name']} ({address})")

    success = connect_to_address(address, password)
    if success:
        state.connection_healthy = True
        state.reconnect_attempts = 0
        state.log(f"Connected to {device['name']}.")
        return jsonify({"ok": True, "name": device['name']})
    else:
        state.connection_healthy = False
        state.log(f"Failed to connect to {device['name']}.")
        return jsonify({"error": f"Failed to connect to {device['name']}. Check address/password."})


# --- Profile Routes ---

@app.route('/api/profiles', methods=['GET'])
@require_auth
def api_profiles():
    from .profiles import get_profile_list
    profiles = get_profile_list()
    current = state.profile
    return jsonify({"profiles": profiles, "current": current})


@app.route('/api/profiles', methods=['POST'])
@rate_limit
@require_auth
def api_set_profile():
    from .profiles import PROFILES
    data = request.get_json() or {}
    profile_id = data.get('profile')
    if profile_id not in PROFILES:
        return jsonify({"error": f"Unknown profile: {profile_id}"})
    state.profile = profile_id
    return jsonify({"ok": True, "profile": profile_id})
