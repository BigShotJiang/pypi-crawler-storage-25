"""Saved devices / quick connect management."""

import os
import json
import base64

CONFIG_DIR = os.path.expanduser('~/.desk-awake')
DEVICES_PATH = os.path.join(CONFIG_DIR, 'devices.json')


def _load_devices():
    """Load saved devices from disk."""
    if os.path.exists(DEVICES_PATH):
        with open(DEVICES_PATH, 'r') as f:
            return json.load(f)
    return []


def _save_devices(devices):
    """Save devices to disk."""
    os.makedirs(CONFIG_DIR, exist_ok=True)
    with open(DEVICES_PATH, 'w') as f:
        json.dump(devices, f, indent=2)


def _encode_password(password):
    """Simple obfuscation for stored passwords (not encryption, just not plaintext)."""
    if not password:
        return None
    return base64.b64encode(password.encode()).decode()


def _decode_password(encoded):
    """Decode an obfuscated password."""
    if not encoded:
        return None
    return base64.b64decode(encoded.encode()).decode()


def get_all_devices():
    """Get all saved devices (passwords masked for display)."""
    devices = _load_devices()
    result = []
    for d in devices:
        result.append({
            'id': d.get('id'),
            'name': d.get('name'),
            'address': d.get('address'),
            'has_password': bool(d.get('password')),
        })
    return result


def get_device(device_id):
    """Get a device by ID including decoded password."""
    devices = _load_devices()
    for d in devices:
        if d.get('id') == device_id:
            return {
                'id': d['id'],
                'name': d.get('name'),
                'address': d['address'],
                'password': _decode_password(d.get('password')),
            }
    return None


def add_device(name, address, password=None):
    """Add a new saved device. Returns the device ID."""
    devices = _load_devices()

    # Generate a simple incremental ID
    max_id = max([d.get('id', 0) for d in devices], default=0)
    new_id = max_id + 1

    devices.append({
        'id': new_id,
        'name': name,
        'address': address,
        'password': _encode_password(password),
    })
    _save_devices(devices)
    return new_id


def update_device(device_id, name=None, address=None, password=None):
    """Update an existing device."""
    devices = _load_devices()
    for d in devices:
        if d.get('id') == device_id:
            if name is not None:
                d['name'] = name
            if address is not None:
                d['address'] = address
            if password is not None:
                d['password'] = _encode_password(password) if password else None
            _save_devices(devices)
            return True
    return False


def delete_device(device_id):
    """Delete a saved device."""
    devices = _load_devices()
    devices = [d for d in devices if d.get('id') != device_id]
    _save_devices(devices)
    return True
