"""Activity profiles — different simulation behaviors."""

import time
import random
import string
from pynput.keyboard import Controller as KeyboardController, Key
from pynput.mouse import Controller as MouseController

keyboard = KeyboardController()
mouse = MouseController()


# --- Profile Definitions ---

PROFILES = {
    "normal": {
        "name": "Normal",
        "description": "Balanced mix of mouse and keys (~50 keys/min, ~60 mouse/min)",
        "icon": "⚖️",
    },
    "aggressive": {
        "name": "Aggressive",
        "description": "Heavy typing bursts + rapid mouse movement (~120 keys/min, ~100 mouse/min)",
        "icon": "🔥",
    },
    "developer": {
        "name": "Developer",
        "description": "Typing bursts with pauses (like coding), tab switching, scrolling",
        "icon": "💻",
    },
    "reader": {
        "name": "Reader",
        "description": "Mostly scrolling and occasional mouse movement (reading docs/web)",
        "icon": "📖",
    },
    "meeting": {
        "name": "Meeting",
        "description": "Minimal activity — just enough to stay online (mouse wiggle every few seconds)",
        "icon": "🎧",
    },
}


def get_profile_list():
    """Get all available profiles for the UI."""
    return [{"id": k, **v} for k, v in PROFILES.items()]


# --- Activity Executors ---

def execute_normal_cycle():
    """Normal balanced activity."""
    actions = random.randint(3, 8)
    for _ in range(actions):
        if random.random() < 0.55:
            _mouse_move()
        else:
            _nav_key()
        time.sleep(random.uniform(0.02, 0.1))

    # Rate: ~1.83 actions/sec
    return actions / 1.83


def execute_aggressive_cycle():
    """Heavy rapid activity — typing + fast mouse."""
    actions = random.randint(8, 15)

    for _ in range(actions):
        r = random.random()
        if r < 0.35:
            # Rapid mouse movement (larger range)
            _mouse_move(amplitude=60)
        elif r < 0.7:
            # Type random characters (simulates fast typing)
            _type_chars(random.randint(3, 10))
        else:
            # Navigation keys rapidly
            _nav_key()
            _nav_key()
        time.sleep(random.uniform(0.01, 0.05))

    # Occasionally do a big mouse sweep
    if random.random() < 0.3:
        _mouse_sweep()

    # Rate: ~3.6 actions/sec
    return actions / 3.6


def execute_developer_cycle():
    """Developer-like activity — typing bursts, tab switching, scrolling."""
    r = random.random()

    if r < 0.4:
        # Typing burst (like writing code)
        chars = random.randint(5, 30)
        _type_chars(chars)
        time.sleep(random.uniform(0.1, 0.4))
        # Sometimes hit enter or tab
        if random.random() < 0.3:
            keyboard.press(Key.enter)
            keyboard.release(Key.enter)
        if random.random() < 0.2:
            keyboard.press(Key.tab)
            keyboard.release(Key.tab)
        return random.uniform(0.5, 1.5)

    elif r < 0.6:
        # Tab/window switching
        _switch_tab()
        time.sleep(random.uniform(0.3, 0.8))
        return random.uniform(0.5, 1.0)

    elif r < 0.8:
        # Scrolling through code
        scrolls = random.randint(2, 6)
        for _ in range(scrolls):
            key = random.choice([Key.up, Key.down, Key.page_up, Key.page_down])
            keyboard.press(key)
            keyboard.release(key)
            time.sleep(random.uniform(0.05, 0.15))
        return random.uniform(0.3, 0.8)

    else:
        # Mouse movement (clicking around IDE)
        _mouse_move(amplitude=50)
        time.sleep(random.uniform(0.1, 0.3))
        _mouse_move(amplitude=30)
        return random.uniform(0.3, 0.6)


def execute_reader_cycle():
    """Reader activity — mostly scrolling, occasional mouse."""
    r = random.random()

    if r < 0.6:
        # Scroll down (reading)
        scrolls = random.randint(1, 4)
        for _ in range(scrolls):
            key = random.choice([Key.down, Key.down, Key.down, Key.page_down])
            keyboard.press(key)
            keyboard.release(key)
            time.sleep(random.uniform(0.2, 0.5))
        return random.uniform(1.0, 3.0)

    elif r < 0.8:
        # Mouse movement (following text)
        _mouse_move(amplitude=20)
        return random.uniform(1.5, 3.0)

    elif r < 0.95:
        # Scroll up (re-reading)
        keyboard.press(Key.up)
        keyboard.release(Key.up)
        time.sleep(0.1)
        keyboard.press(Key.up)
        keyboard.release(Key.up)
        return random.uniform(1.0, 2.0)

    else:
        # Tab switch (opening new article/doc)
        _switch_tab()
        return random.uniform(2.0, 4.0)


def execute_meeting_cycle():
    """Minimal activity — just stay alive."""
    r = random.random()

    if r < 0.7:
        # Small mouse wiggle
        mouse.move(random.randint(-5, 5), random.randint(-5, 5))
        return random.uniform(3.0, 8.0)
    else:
        # Occasional key press
        _nav_key()
        return random.uniform(5.0, 12.0)


# --- Profile Executor Map ---

PROFILE_EXECUTORS = {
    "normal": execute_normal_cycle,
    "aggressive": execute_aggressive_cycle,
    "developer": execute_developer_cycle,
    "reader": execute_reader_cycle,
    "meeting": execute_meeting_cycle,
}


def execute_cycle(profile_id="normal"):
    """Execute one activity cycle for the given profile. Returns sleep time."""
    executor = PROFILE_EXECUTORS.get(profile_id, execute_normal_cycle)
    return executor()


# --- Helper Functions ---

def _mouse_move(amplitude=30):
    """Move mouse by random offset."""
    dx = random.randint(-amplitude, amplitude)
    dy = random.randint(-amplitude, amplitude)
    mouse.move(dx, dy)


def _mouse_sweep():
    """Large mouse sweep across screen."""
    for _ in range(5):
        mouse.move(random.randint(-80, 80), random.randint(-40, 40))
        time.sleep(random.uniform(0.02, 0.05))


def _nav_key():
    """Press a random navigation key."""
    keys = [Key.page_up, Key.page_down, Key.up, Key.down, Key.left, Key.right]
    key = random.choice(keys)
    keyboard.press(key)
    time.sleep(random.uniform(0.02, 0.06))
    keyboard.release(key)


def _type_chars(count):
    """Type random characters (simulates typing)."""
    chars = string.ascii_lowercase + '    \n'  # weighted toward spaces
    for _ in range(count):
        c = random.choice(chars)
        if c == '\n':
            keyboard.press(Key.enter)
            keyboard.release(Key.enter)
        else:
            keyboard.press(c)
            keyboard.release(c)
        time.sleep(random.uniform(0.02, 0.08))


def _switch_tab():
    """Switch tab/window using OS-appropriate shortcut."""
    import platform
    mod = Key.cmd if platform.system().lower() == 'darwin' else Key.alt
    keyboard.press(mod)
    keyboard.press(Key.tab)
    keyboard.release(Key.tab)
    keyboard.release(mod)
