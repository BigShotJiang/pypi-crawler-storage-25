"""Simple password-based authentication for the web dashboard."""

import hashlib
import secrets
import os
import json
from functools import wraps
from flask import request, jsonify, session, redirect, url_for, render_template_string

CONFIG_DIR = os.path.expanduser('~/.desk-awake')
CONFIG_PATH = os.path.join(CONFIG_DIR, 'config.json')


def _load_config():
    """Load config from disk."""
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH, 'r') as f:
            return json.load(f)
    return {}


def _save_config(config):
    """Save config to disk."""
    os.makedirs(CONFIG_DIR, exist_ok=True)
    with open(CONFIG_PATH, 'w') as f:
        json.dump(config, f, indent=2)


def _hash_password(password, salt=None):
    """Hash a password with a salt."""
    if salt is None:
        salt = secrets.token_hex(16)
    hashed = hashlib.sha256(f"{salt}{password}".encode()).hexdigest()
    return f"{salt}:{hashed}"


def set_password(password):
    """Set the dashboard password."""
    config = _load_config()
    config['password_hash'] = _hash_password(password)
    _save_config(config)


def verify_password(password):
    """Verify a password against the stored hash."""
    config = _load_config()
    stored = config.get('password_hash')
    if not stored:
        return True  # No password set = open access

    salt, expected_hash = stored.split(':', 1)
    actual = _hash_password(password, salt)
    return actual == stored


def is_password_set():
    """Check if a password has been configured."""
    config = _load_config()
    return 'password_hash' in config


def require_auth(f):
    """Decorator to require authentication on a route."""
    @wraps(f)
    def decorated(*args, **kwargs):
        if not is_password_set():
            return f(*args, **kwargs)

        # Check session
        if session.get('authenticated'):
            return f(*args, **kwargs)

        # Check Authorization header (for API calls)
        auth_header = request.headers.get('Authorization')
        if auth_header and auth_header.startswith('Bearer '):
            token = auth_header[7:]
            if verify_password(token):
                return f(*args, **kwargs)

        # Check X-Password header (simpler for fetch calls)
        password = request.headers.get('X-Password')
        if password and verify_password(password):
            return f(*args, **kwargs)

        # Not authenticated
        if request.is_json or request.path.startswith('/api/'):
            return jsonify({"error": "Authentication required"}), 401
        else:
            return redirect('/login')

    return decorated


LOGIN_HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Desk Awake - Login</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
               background: #1a1a2e; color: #eee; min-height: 100vh; 
               display: flex; align-items: center; justify-content: center; }
        .login-card { background: #16213e; border-radius: 12px; padding: 40px;
                      border: 1px solid #0f3460; width: 100%; max-width: 400px; }
        .login-card h1 { color: #00d4aa; text-align: center; margin-bottom: 8px; }
        .login-card p { color: #888; text-align: center; margin-bottom: 24px; font-size: 0.9em; }
        .form-group { margin-bottom: 16px; }
        .form-group label { display: block; margin-bottom: 6px; color: #aaa; font-size: 0.85em; }
        .form-group input { width: 100%; padding: 12px; border-radius: 8px; border: 1px solid #0f3460;
                            background: #1a1a2e; color: #eee; font-size: 1em; }
        .btn { width: 100%; padding: 12px; border: none; border-radius: 8px; cursor: pointer;
               font-size: 1em; font-weight: 600; background: #00d4aa; color: #1a1a2e; }
        .btn:hover { opacity: 0.9; }
        .error { color: #e7305b; text-align: center; margin-bottom: 16px; font-size: 0.9em; }
    </style>
</head>
<body>
    <div class="login-card">
        <h1>🖥️ Desk Awake</h1>
        <p>Enter password to access the control panel</p>
        {% if error %}<div class="error">{{ error }}</div>{% endif %}
        <form method="POST" action="/login">
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" autofocus placeholder="Enter password">
            </div>
            <button type="submit" class="btn">Login</button>
        </form>
    </div>
</body>
</html>
"""
