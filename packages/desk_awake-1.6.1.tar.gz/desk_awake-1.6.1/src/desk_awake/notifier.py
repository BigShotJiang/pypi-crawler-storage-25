"""Notification system for desk-awake alerts."""

import subprocess
import platform
import urllib.request
import urllib.parse
import json

CURRENT_OS = platform.system().lower()


def send_notification(title, message, webhook_url=None):
    """
    Send a notification. Tries multiple methods:
    1. Webhook (Slack/Discord/generic) if URL provided
    2. OS-native notification as fallback
    
    Args:
        title: Notification title
        message: Notification body
        webhook_url: Optional webhook URL for remote notifications
    """
    print(f"[ALERT] {title}: {message}")

    # Try webhook first (works remotely)
    if webhook_url:
        _send_webhook(title, message, webhook_url)

    # Also send OS notification if possible
    _send_os_notification(title, message)


def _send_webhook(title, message, webhook_url):
    """Send notification via webhook (supports Slack, Discord, or generic JSON)."""
    try:
        if 'discord' in webhook_url:
            payload = json.dumps({
                "content": f"**{title}**\n{message}"
            }).encode('utf-8')
        elif 'slack' in webhook_url:
            payload = json.dumps({
                "text": f"*{title}*\n{message}"
            }).encode('utf-8')
        else:
            # Generic webhook
            payload = json.dumps({
                "title": title,
                "message": message
            }).encode('utf-8')

        req = urllib.request.Request(
            webhook_url,
            data=payload,
            headers={'Content-Type': 'application/json'}
        )
        urllib.request.urlopen(req, timeout=10)
        print(f"Webhook notification sent.")
    except Exception as e:
        print(f"Failed to send webhook: {e}")


def _send_os_notification(title, message):
    """Send OS-native desktop notification."""
    try:
        if CURRENT_OS == "darwin":
            subprocess.run([
                'osascript', '-e',
                f'display notification "{message}" with title "{title}"'
            ], check=False)
        elif CURRENT_OS == "linux":
            subprocess.run(['notify-send', title, message], check=False)
        elif CURRENT_OS == "windows":
            # PowerShell toast notification
            ps_cmd = (
                f'[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, '
                f'ContentType = WindowsRuntime] > $null; '
                f'$template = [Windows.UI.Notifications.ToastNotificationManager]::'
                f'GetTemplateContent([Windows.UI.Notifications.ToastTemplateType]::ToastText02); '
                f'$template.GetElementsByTagName("text")[0].AppendChild($template.CreateTextNode("{title}")); '
                f'$template.GetElementsByTagName("text")[1].AppendChild($template.CreateTextNode("{message}")); '
                f'[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier("desk-awake")'
                f'.Show([Windows.UI.Notifications.ToastNotification]::new($template))'
            )
            subprocess.run(['powershell', '-Command', ps_cmd], check=False)
    except Exception:
        pass  # OS notification is best-effort
