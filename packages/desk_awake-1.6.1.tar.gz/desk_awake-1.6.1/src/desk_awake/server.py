"""Main server that runs the web dashboard + automator + connection monitor."""

import threading
import time
import random
from datetime import datetime, timedelta, date

from .state import AppState, Status
from .anydesk import is_anydesk_connected, connect_to_address, close_anydesk
from .notifier import send_notification
from .core import random_mouse_movement, random_keyboard_action, put_to_sleep, CURRENT_OS
from . import history

# Global shared state
app_state = AppState()

# Current session tracking
_current_session_id = None
_session_lock = threading.Lock()


def connection_monitor_loop():
    """Background thread: monitors AnyDesk connection and attempts reconnection."""
    CHECK_INTERVAL = 15  # seconds between checks
    RECONNECT_DELAY = 10  # seconds between reconnect attempts

    while True:
        time.sleep(CHECK_INTERVAL)

        # Only monitor when running and we have an address to reconnect to
        if app_state.status not in (Status.RUNNING, Status.PAUSED):
            continue

        if not app_state.anydesk_address:
            continue

        connected = is_anydesk_connected()

        if connected:
            if not app_state.connection_healthy:
                app_state.connection_healthy = True
                app_state.reconnect_attempts = 0
                app_state.log("Connection restored.")
            continue

        # Connection dropped
        if app_state.connection_healthy:
            app_state.connection_healthy = False
            app_state.log("⚠️ AnyDesk connection lost! Attempting reconnect...")
            # Record disconnect in session history
            with _session_lock:
                if _current_session_id is not None:
                    history.record_disconnect(_current_session_id)
            send_notification(
                "Desk Awake - Connection Lost",
                f"AnyDesk connection to {app_state.anydesk_address} dropped. Attempting reconnect...",
                app_state.webhook_url
            )

        # Attempt reconnection
        if app_state.reconnect_attempts < app_state.max_reconnect_attempts:
            app_state.status = Status.RECONNECTING
            app_state.reconnect_attempts += 1
            app_state.log(f"Reconnect attempt {app_state.reconnect_attempts}/{app_state.max_reconnect_attempts}...")

            time.sleep(RECONNECT_DELAY)
            success = connect_to_address(app_state.anydesk_address, app_state.anydesk_password)

            if success:
                # Give it a moment to establish
                time.sleep(5)
                if is_anydesk_connected():
                    app_state.connection_healthy = True
                    app_state.reconnect_attempts = 0
                    app_state.status = Status.RUNNING
                    app_state.log("✅ Reconnected successfully!")
                    # Record reconnect in session history
                    with _session_lock:
                        if _current_session_id is not None:
                            history.record_reconnect(_current_session_id)
                    send_notification(
                        "Desk Awake - Reconnected",
                        f"Successfully reconnected to {app_state.anydesk_address}.",
                        app_state.webhook_url
                    )
                else:
                    app_state.log("Reconnect attempt failed, will retry...")
            else:
                app_state.log("Reconnect attempt failed, will retry...")
        else:
            # Max attempts reached
            app_state.status = Status.STOPPED
            app_state.log("❌ Max reconnect attempts reached. Stopping.")
            send_notification(
                "Desk Awake - FAILED",
                f"Could not reconnect to {app_state.anydesk_address} after "
                f"{app_state.max_reconnect_attempts} attempts. Script stopped.",
                app_state.webhook_url
            )


def automator_loop():
    """Background thread: performs mouse/keyboard activity based on state."""
    global _current_session_id
    actions_per_second = (50 + 60) / 60  # ~1.83 actions per second

    while True:
        if app_state.status == Status.STOPPED:
            # End current session if one is active
            with _session_lock:
                if _current_session_id is not None:
                    history.end_session(
                        _current_session_id,
                        disconnects=app_state.reconnect_attempts,
                        reconnects=app_state.reconnect_attempts
                    )
                    app_state.log(f"Session #{_current_session_id} ended.")
                    _current_session_id = None
            time.sleep(1)
            continue

        if app_state.status in (Status.IDLE, Status.PAUSED, Status.RECONNECTING):
            time.sleep(1)
            continue

        if app_state.status != Status.RUNNING:
            time.sleep(1)
            continue

        # Start a new session if none active
        with _session_lock:
            if _current_session_id is None:
                _current_session_id = history.start_session(app_state.anydesk_address)
                app_state.log(f"Session #{_current_session_id} started.")

        # Check if we've passed stop time
        if app_state.stop_time and datetime.now() >= app_state.stop_time:
            # In multi-day mode, advance to next day
            if app_state.end_date and date.today() < app_state.end_date:
                # End today's session
                with _session_lock:
                    if _current_session_id is not None:
                        history.end_session(_current_session_id)
                        _current_session_id = None
                app_state.log("Daily stop time reached. Waiting for next day...")
                _wait_for_next_day()
                continue
            else:
                app_state.log("Stop time reached. Session complete.")
                app_state.status = Status.STOPPED
                _on_session_complete()
                continue

        # Perform activity burst using current profile
        from .profiles import execute_cycle
        sleep_time = execute_cycle(app_state.profile)

        app_state.last_activity = datetime.now()

        # Sleep based on profile's recommended pace
        if sleep_time > 0:
            time.sleep(sleep_time)

        # Occasional brief pause
        if random.random() < 0.1:
            idle_time = random.uniform(0.5, 2.0)
            time.sleep(idle_time)


def _wait_for_next_day():
    """Wait until the next day's start time in multi-day mode."""
    start_str = app_state.start_time_str
    if start_str:
        start_hour = int(start_str.split(':')[0])
        start_minute = int(start_str.split(':')[1])
    else:
        start_hour = 9
        start_minute = 0

    tomorrow = date.today() + timedelta(days=1)
    next_start = datetime(tomorrow.year, tomorrow.month, tomorrow.day, start_hour, start_minute)

    # Update stop_time for tomorrow
    if app_state.stop_time:
        stop_hour = app_state.stop_time.hour
        stop_minute = app_state.stop_time.minute
        app_state.stop_time = datetime(tomorrow.year, tomorrow.month, tomorrow.day, stop_hour, stop_minute)

    wait_seconds = (next_start - datetime.now()).total_seconds()
    if wait_seconds > 0:
        app_state.log(f"Sleeping until {next_start.strftime('%Y-%m-%d %H:%M')} ({wait_seconds/3600:.1f}h)")
        # Sleep in chunks so we can respond to stop commands
        while wait_seconds > 0 and app_state.status != Status.STOPPED:
            time.sleep(min(30, wait_seconds))
            wait_seconds = (next_start - datetime.now()).total_seconds()

    if app_state.status != Status.STOPPED:
        app_state.log(f"New day started. Resuming activity.")
        app_state.status = Status.RUNNING


def _on_session_complete():
    """Handle end-of-session cleanup."""
    if app_state.close_anydesk_on_exit:
        close_anydesk()
        app_state.log("AnyDesk closed.")

    if app_state.sleep_on_exit:
        app_state.log("Putting machine to sleep...")
        put_to_sleep()

    send_notification(
        "Desk Awake - Session Complete",
        "Activity simulation finished.",
        app_state.webhook_url
    )


def run_server(host='0.0.0.0', port=5000):
    """Start the web server and background threads."""
    from .web import app as flask_app
    import desk_awake.web as web_module

    # Share state with web module
    web_module.state = app_state

    # Start background threads
    monitor_thread = threading.Thread(target=connection_monitor_loop, daemon=True)
    monitor_thread.start()
    app_state.log("Connection monitor started.")

    automator_thread = threading.Thread(target=automator_loop, daemon=True)
    automator_thread.start()
    app_state.log("Automator engine started.")

    app_state.log(f"Web dashboard running on http://{host}:{port}")
    print(f"\n{'='*50}")
    print(f"  Desk Awake - Control Panel")
    print(f"  http://{host}:{port}")
    print(f"  OS: {CURRENT_OS}")
    print(f"{'='*50}\n")

    flask_app.run(host=host, port=port, debug=False, use_reloader=False)
