"""Ngrok tunnel integration for public HTTPS access."""


def start_ngrok(port=5000, domain=None):
    """
    Start an ngrok HTTPS tunnel to expose the web dashboard publicly.
    Ngrok always provides HTTPS by default on free and paid plans.
    
    Args:
        port: Local port to tunnel.
        domain: Optional static domain (e.g. 'your-name.ngrok-free.app').
                Get one free at https://dashboard.ngrok.com/domains
    
    Returns the public HTTPS URL or None if ngrok isn't available.
    """
    try:
        from pyngrok import ngrok

        # Use static domain if provided, otherwise random
        if domain:
            tunnel = ngrok.connect(port, "http", domain=domain)
        else:
            tunnel = ngrok.connect(port, "http", bind_tls=True)

        public_url = tunnel.public_url

        # Ensure we're using https
        if public_url.startswith('http://'):
            public_url = public_url.replace('http://', 'https://', 1)

        print(f"\n{'='*50}")
        print(f"  🔒 Public URL (HTTPS): {public_url}")
        if domain:
            print(f"  Static domain — same URL every time")
        print(f"  Access from anywhere (phone, other network, etc.)")
        print(f"{'='*50}\n")

        return public_url

    except ImportError:
        print("\n⚠️  pyngrok not installed. Install it for ngrok support:")
        print("   pip install desk-awake[tunnel]")
        print("   Then run: desk-awake serve --ngrok\n")
        return None
    except Exception as e:
        print(f"\n⚠️  Failed to start ngrok tunnel: {e}")
        print("   Make sure ngrok is configured: ngrok config add-authtoken YOUR_TOKEN")
        print("   Get a free token at: https://dashboard.ngrok.com/get-started/your-authtoken\n")
        return None


def stop_ngrok():
    """Stop all ngrok tunnels."""
    try:
        from pyngrok import ngrok
        ngrok.kill()
    except Exception:
        pass
