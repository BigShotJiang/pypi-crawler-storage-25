"""Simple in-memory rate limiter for the web dashboard."""

import time
import threading
from functools import wraps
from flask import request, jsonify


class RateLimiter:
    """
    Token bucket rate limiter.
    Tracks requests per IP address.
    """

    def __init__(self, requests_per_minute=30, burst=10):
        """
        Args:
            requests_per_minute: Sustained rate limit.
            burst: Maximum burst size (bucket capacity).
        """
        self._lock = threading.Lock()
        self._buckets = {}  # ip -> {tokens, last_refill}
        self._rate = requests_per_minute / 60.0  # tokens per second
        self._burst = burst
        self._login_attempts = {}  # ip -> {count, first_attempt}
        self._login_limit = 5  # max login attempts per window
        self._login_window = 300  # 5 minute window

    def _get_bucket(self, ip):
        """Get or create a token bucket for an IP."""
        now = time.time()
        with self._lock:
            if ip not in self._buckets:
                self._buckets[ip] = {'tokens': self._burst, 'last_refill': now}
            bucket = self._buckets[ip]

            # Refill tokens based on elapsed time
            elapsed = now - bucket['last_refill']
            bucket['tokens'] = min(self._burst, bucket['tokens'] + elapsed * self._rate)
            bucket['last_refill'] = now

            return bucket

    def is_allowed(self, ip):
        """Check if a request from this IP is allowed."""
        bucket = self._get_bucket(ip)
        with self._lock:
            if bucket['tokens'] >= 1:
                bucket['tokens'] -= 1
                return True
            return False

    def check_login_attempt(self, ip):
        """Check if a login attempt from this IP is allowed (stricter limit)."""
        now = time.time()
        with self._lock:
            if ip not in self._login_attempts:
                self._login_attempts[ip] = {'count': 0, 'first_attempt': now}

            record = self._login_attempts[ip]

            # Reset window if expired
            if now - record['first_attempt'] > self._login_window:
                record['count'] = 0
                record['first_attempt'] = now

            if record['count'] >= self._login_limit:
                return False

            record['count'] += 1
            return True

    def cleanup(self):
        """Remove stale entries (call periodically)."""
        now = time.time()
        with self._lock:
            stale_ips = [ip for ip, b in self._buckets.items()
                         if now - b['last_refill'] > 600]
            for ip in stale_ips:
                del self._buckets[ip]

            stale_logins = [ip for ip, r in self._login_attempts.items()
                           if now - r['first_attempt'] > self._login_window * 2]
            for ip in stale_logins:
                del self._login_attempts[ip]


# Global rate limiter instance
limiter = RateLimiter(requests_per_minute=60, burst=20)


def rate_limit(f):
    """Decorator to apply rate limiting to a route."""
    @wraps(f)
    def decorated(*args, **kwargs):
        ip = request.remote_addr or '127.0.0.1'
        if not limiter.is_allowed(ip):
            return jsonify({"error": "Rate limit exceeded. Try again shortly."}), 429
        return f(*args, **kwargs)
    return decorated


def login_rate_limit(f):
    """Stricter rate limit for login attempts (5 per 5 minutes)."""
    @wraps(f)
    def decorated(*args, **kwargs):
        ip = request.remote_addr or '127.0.0.1'
        if not limiter.check_login_attempt(ip):
            return jsonify({"error": "Too many login attempts. Try again in 5 minutes."}), 429
        return f(*args, **kwargs)
    return decorated
