"""Gateway config getter owners."""

from __future__ import annotations

import os

from obra.config.loaders import _core, _defaults
from obra.exceptions import ConfigurationError
from obra.gateway.automation.profile import (
    GATEWAY_PROFILE_STANDARD,
    OBRA_GATEWAY_AUTH_TOKEN_ENV,
    OBRA_GATEWAY_PROFILE_ENV,
)

from ._helpers import resolve_bool_config, resolve_float_config, resolve_int_config

__all__ = [
    "get_phase_detection_draft_instruction_threshold",
    "get_phase_detection_entry_point_defaults",
    "get_phase_detection_enabled",
    "get_gateway_session_timeout",
    "get_phase_detection_min_stages_for_full_model",
    "get_phase_detection_stable_run_threshold",
    "get_phase_detection_validate_min_run_count",
    "get_readiness_next_action_priorities",
    "get_readiness_first_use_intro_enabled",
    "get_readiness_prompt_section_max_tokens",
    "get_readiness_prompt_section_priority",
    "get_readiness_recap_enabled",
    "get_readiness_seed_alignment_min_keyword_matches",
    "get_gateway_assistant_config",
    "get_gateway_config",
    "get_gateway_desktop_config",
    "get_gateway_onboarding_config",
    "get_gateway_transcription_config",
]

_WORKFLOW_STORAGE_ENV = "OBRA_GATEWAY_WORKFLOW_STORAGE"
_WORKFLOW_STORE_REFRESH_COOLDOWN_ENV = "OBRA_GATEWAY_WORKFLOW_STORE_REFRESH_COOLDOWN_S"
_WORKFLOW_STORE_REFRESH_FAILURE_BACKOFF_ENV = (
    "OBRA_GATEWAY_WORKFLOW_STORE_REFRESH_FAILURE_BACKOFF_S"
)
_WORKFLOW_STORE_REMOTE_REVISION_CONCURRENCY_ENV = (
    "OBRA_GATEWAY_WORKFLOW_STORE_REMOTE_REVISION_CONCURRENCY"
)
_WORKFLOW_RUN_WAIT_DEFAULT_TIMEOUT_ENV = "OBRA_GATEWAY_WORKFLOW_RUN_WAIT_DEFAULT_TIMEOUT_S"
_WORKFLOW_RUN_WAIT_MAX_TIMEOUT_ENV = "OBRA_GATEWAY_WORKFLOW_RUN_WAIT_MAX_TIMEOUT_S"
_WORKFLOW_RUN_WAIT_POLL_INTERVAL_ENV = "OBRA_GATEWAY_WORKFLOW_RUN_WAIT_POLL_INTERVAL_S"
_ASSISTANT_ACTION_CATALOG_CACHE_MAX_AGE_ENV = (
    "OBRA_GATEWAY_ASSISTANT_ACTION_CATALOG_CACHE_MAX_AGE_S"
)
_SESSION_TIMEOUT_ENV = "OBRA_GATEWAY_SESSION_TIMEOUT_S"
_VALID_WORKFLOW_STORAGE_VALUES = {"cloud", "local"}
_DESKTOP_PATH_PREFIXES_ENV = "OBRA_GATEWAY_DESKTOP_PATH_PREFIXES"
_DESKTOP_PRESERVED_ENV_VARS_ENV = "OBRA_GATEWAY_DESKTOP_PRESERVED_ENV_VARS"
_DESKTOP_STDOUT_LOG_FILENAME_ENV = "OBRA_GATEWAY_DESKTOP_STDOUT_LOG_FILENAME"
_DESKTOP_STDERR_LOG_FILENAME_ENV = "OBRA_GATEWAY_DESKTOP_STDERR_LOG_FILENAME"
_DESKTOP_EXCLUDED_ENV_VARS = {"GOOGLE_APPLICATION_CREDENTIALS"}

_PHASE_DETECTION_ENV_PREFIX = "OBRA_GATEWAY_ASSISTANT_PHASE_DETECTION_"
_READINESS_ENV_PREFIX = "OBRA_GATEWAY_ASSISTANT_READINESS_"
_PROMPT_SECTIONS_ENV_PREFIX = "OBRA_GATEWAY_ASSISTANT_PROMPT_SECTIONS_"
_VALID_GATEWAY_SCOPE_VALUES = {"read", "operate", "admin"}


def _resolve_workflow_storage(gateway_section: dict) -> str:
    raw_value = os.getenv(_WORKFLOW_STORAGE_ENV, gateway_section.get("workflow_storage", "cloud"))
    normalized = str(raw_value or "").strip().lower()
    if normalized in _VALID_WORKFLOW_STORAGE_VALUES:
        return normalized
    raise ConfigurationError(
        "gateway.workflow_storage must be one of: cloud, local"
    )


def _resolve_workflow_run_wait_config() -> dict[str, float]:
    default_timeout_s = resolve_float_config(
        _WORKFLOW_RUN_WAIT_DEFAULT_TIMEOUT_ENV,
        "gateway.workflow_run_wait.default_timeout_s",
        default=None,
        min_val=1.0,
        fail_fast=True,
        include_defaults=True,
        label="Gateway workflow-run wait default timeout",
    )
    max_timeout_s = resolve_float_config(
        _WORKFLOW_RUN_WAIT_MAX_TIMEOUT_ENV,
        "gateway.workflow_run_wait.max_timeout_s",
        default=None,
        min_val=1.0,
        fail_fast=True,
        include_defaults=True,
        label="Gateway workflow-run wait maximum timeout",
    )
    poll_interval_s = resolve_float_config(
        _WORKFLOW_RUN_WAIT_POLL_INTERVAL_ENV,
        "gateway.workflow_run_wait.poll_interval_s",
        default=None,
        min_val=0.0,
        fail_fast=True,
        include_defaults=True,
        label="Gateway workflow-run wait poll interval",
    )
    if poll_interval_s <= 0:
        raise ConfigurationError("gateway.workflow_run_wait.poll_interval_s must be > 0")
    if default_timeout_s > max_timeout_s:
        raise ConfigurationError(
            "gateway.workflow_run_wait.default_timeout_s must be <= "
            "gateway.workflow_run_wait.max_timeout_s"
        )
    return {
        "workflow_run_wait_default_timeout_s": default_timeout_s,
        "workflow_run_wait_max_timeout_s": max_timeout_s,
        "workflow_run_wait_poll_interval_s": poll_interval_s,
    }


def _resolve_assistant_action_catalog_cache_max_age_s() -> int:
    return resolve_int_config(
        _ASSISTANT_ACTION_CATALOG_CACHE_MAX_AGE_ENV,
        "gateway.assistant.action_catalog_cache_max_age_s",
        default=None,
        min_val=0,
        fail_fast=True,
        include_defaults=True,
        label="Gateway assistant action catalog cache max age",
    )


def _normalize_gateway_auth_tokens(gateway_section: dict) -> list[dict[str, object]]:
    raw_registry = gateway_section.get("auth_tokens", [])
    if raw_registry is None:
        return []
    if not isinstance(raw_registry, list):
        raise ConfigurationError("gateway.auth_tokens must be a list of {token, scopes, label} objects")

    normalized_registry: list[dict[str, object]] = []
    for index, entry in enumerate(raw_registry, start=1):
        if not isinstance(entry, dict):
            raise ConfigurationError(
                f"gateway.auth_tokens[{index}] must be an object with token, scopes, and label"
            )

        token = str(entry.get("token") or "").strip()
        label = str(entry.get("label") or "").strip()
        raw_scopes = entry.get("scopes")
        if not token:
            raise ConfigurationError(f"gateway.auth_tokens[{index}].token must be a non-empty string")
        if not label:
            raise ConfigurationError(f"gateway.auth_tokens[{index}].label must be a non-empty string")
        if not isinstance(raw_scopes, list) or not raw_scopes:
            raise ConfigurationError(
                f"gateway.auth_tokens[{index}].scopes must be a non-empty list of scope names"
            )

        normalized_scopes: list[str] = []
        for raw_scope in raw_scopes:
            normalized_scope = str(raw_scope or "").strip().lower()
            if normalized_scope not in _VALID_GATEWAY_SCOPE_VALUES:
                raise ConfigurationError(
                    f"gateway.auth_tokens[{index}].scopes contains unsupported scope "
                    f"'{raw_scope}'. Valid scopes: read, operate, admin"
                )
            if normalized_scope not in normalized_scopes:
                normalized_scopes.append(normalized_scope)

        normalized_registry.append(
            {
                "token": token,
                "label": label,
                "scopes": tuple(normalized_scopes),
            }
        )
    return normalized_registry


def get_gateway_config() -> dict:
    """Get gateway server configuration.

    Returns dict with host, port, max_sessions, auth_token, escalation_timeout_s,
    enable_cors, cors_origins, allowed_working_dir_base, max_event_queue_size,
    session_eviction_ttl_seconds, max_objective_length, max_project_id_length,
    max_working_dir_length, cors_allow_credentials, allow_public_bind,
    public_bind_tls_terminated, trusted_proxy_cidrs, ws_auth_timeout_s,
    max_ws_connections_total, max_ws_connections_per_ip, ws_max_message_bytes,
    enable_app_rate_limit, rest_rate_limit_per_minute, rest_rate_limit_burst,
    ws_rate_limit_per_minute, ws_rate_limit_burst, logs_session_cookie_name,
    logs_session_ttl_s, logs_session_cookie_secure, studio_session_cookie_name,
    studio_session_ttl_s, studio_session_cookie_secure, studio_launch_token_ttl_s,
    logs_stream_max_clients_total, logs_stream_max_clients_per_ip,
    logs_stream_idle_timeout_s, logs_expose_absolute_paths, pagination_default_limit,
    pagination_max_limit, webhooks_max_per_owner, webhooks_failure_threshold_failing,
    webhooks_failure_threshold_disabled, webhooks_delivery_timeout_s,
    webhooks_retry_backoff_schedule, webhooks_retention_seconds,
    webhooks_cleanup_interval_s, webhooks_allow_private_networks,
    idempotency_key_ttl_s, batch_max_concurrency, output_delivery_timeout_s,
    output_delivery_retry_backoff_schedule, auth_tokens from gateway section.
    """
    config, _, _ = _core.load_layered_config(include_defaults=True)
    try:
        gw = config["gateway"]
        workflow_events = gw["workflow_events"]
        workflow_changes = gw["workflow_changes"]
        workflow_run_wait = _resolve_workflow_run_wait_config()
        return {
            "profile": str(
                gw.get("profile") or os.getenv(OBRA_GATEWAY_PROFILE_ENV, GATEWAY_PROFILE_STANDARD)
            ),
            "host": gw["host"],
            "port": gw["port"],
            "max_sessions": gw["max_sessions"],
            "auth_token": os.getenv(OBRA_GATEWAY_AUTH_TOKEN_ENV, gw.get("auth_token")),
            "auth_tokens": _normalize_gateway_auth_tokens(gw),
            "escalation_timeout_s": float(gw["escalation_timeout_s"]),
            "enable_cors": gw["enable_cors"],
            "cors_origins": gw["cors_origins"],
            "workflow_storage": _resolve_workflow_storage(gw),
            "workflow_store_refresh_cooldown_s": resolve_float_config(
                _WORKFLOW_STORE_REFRESH_COOLDOWN_ENV,
                "gateway.workflow_store_refresh_cooldown_s",
                default=None,
                min_val=0.0,
                include_defaults=True,
                label="Gateway config",
            ),
            "workflow_store_refresh_failure_backoff_s": resolve_float_config(
                _WORKFLOW_STORE_REFRESH_FAILURE_BACKOFF_ENV,
                "gateway.workflow_store_refresh_failure_backoff_s",
                default=None,
                min_val=0.0,
                include_defaults=True,
                label="Gateway config",
            ),
            "workflow_store_remote_revision_concurrency": resolve_int_config(
                _WORKFLOW_STORE_REMOTE_REVISION_CONCURRENCY_ENV,
                "gateway.workflow_store_remote_revision_concurrency",
                default=None,
                min_val=1,
                include_defaults=True,
                label="Gateway config",
            ),
            **workflow_run_wait,
            "assistant_action_catalog_cache_max_age_s": (
                _resolve_assistant_action_catalog_cache_max_age_s()
            ),
            "allowed_working_dir_base": gw.get("allowed_working_dir_base", "~/obra-projects"),
            "max_event_queue_size": int(gw.get("max_event_queue_size", 1000)),
            "session_eviction_ttl_seconds": int(gw.get("session_eviction_ttl_seconds", 3600)),
            "session_timeout_s": int(gw.get("session_timeout_s", 7200)),
            "max_objective_length": int(gw.get("max_objective_length", 10000)),
            "max_project_id_length": int(gw.get("max_project_id_length", 256)),
            "max_working_dir_length": int(gw.get("max_working_dir_length", 4096)),
            "cors_allow_credentials": gw.get("cors_allow_credentials", True),
            "allow_public_bind": gw.get("allow_public_bind", False),
            "public_bind_tls_terminated": gw.get("public_bind_tls_terminated", False),
            "trusted_proxy_cidrs": list(gw.get("trusted_proxy_cidrs", [])),
            "ws_auth_timeout_s": float(gw.get("ws_auth_timeout_s", 5)),
            "max_ws_connections_total": int(gw.get("max_ws_connections_total", 200)),
            "max_ws_connections_per_ip": int(gw.get("max_ws_connections_per_ip", 20)),
            "ws_max_message_bytes": int(gw.get("ws_max_message_bytes", 1_048_576)),
            "enable_app_rate_limit": gw.get("enable_app_rate_limit", True),
            "rest_rate_limit_per_minute": int(gw.get("rest_rate_limit_per_minute", 120)),
            "rest_rate_limit_burst": int(gw.get("rest_rate_limit_burst", 60)),
            "ws_rate_limit_per_minute": int(gw.get("ws_rate_limit_per_minute", 240)),
            "ws_rate_limit_burst": int(gw.get("ws_rate_limit_burst", 120)),
            "workflow_events_heartbeat_seconds": float(workflow_events["heartbeat_seconds"]),
            "workflow_events_stale_after_missed_heartbeats": int(
                workflow_events["stale_after_missed_heartbeats"]
            ),
            "workflow_changes_proposal_ttl_seconds": int(workflow_changes["proposal_ttl_seconds"]),
            "workflow_changes_retention_days": workflow_changes["retention_days"],
            "pagination_default_limit": int(gw["pagination_default_limit"]),
            "pagination_max_limit": int(gw["pagination_max_limit"]),
            "logs_session_cookie_name": gw["logs_session_cookie_name"],
            "logs_session_ttl_s": int(gw["logs_session_ttl_s"]),
            "logs_session_cookie_secure": bool(gw["logs_session_cookie_secure"]),
            "studio_session_cookie_name": str(
                gw.get("studio_session_cookie_name", "obra_studio_session")
            ),
            "studio_session_ttl_s": int(gw.get("studio_session_ttl_s", 43_200)),
            "studio_session_cookie_secure": bool(gw.get("studio_session_cookie_secure", False)),
            "studio_launch_token_ttl_s": int(gw.get("studio_launch_token_ttl_s", 120)),
            "logs_stream_max_clients_total": int(gw["logs_stream_max_clients_total"]),
            "logs_stream_max_clients_per_ip": int(gw["logs_stream_max_clients_per_ip"]),
            "logs_stream_idle_timeout_s": float(gw["logs_stream_idle_timeout_s"]),
            "logs_expose_absolute_paths": bool(gw["logs_expose_absolute_paths"]),
            "webhooks_max_per_owner": int(gw["webhooks_max_per_owner"]),
            "webhooks_failure_threshold_failing": int(gw["webhooks_failure_threshold_failing"]),
            "webhooks_failure_threshold_disabled": int(gw["webhooks_failure_threshold_disabled"]),
            "webhooks_delivery_timeout_s": float(gw["webhooks_delivery_timeout_s"]),
            "webhooks_retry_backoff_schedule": tuple(float(item) for item in gw["webhooks_retry_backoff_schedule"]),
            "webhooks_retention_seconds": int(gw["webhooks_retention_seconds"]),
            "webhooks_cleanup_interval_s": float(gw["webhooks_cleanup_interval_s"]),
            "webhooks_allow_private_networks": bool(gw["webhooks_allow_private_networks"]),
            "idempotency_key_ttl_s": int(gw["idempotency_key_ttl_s"]),
            "batch_max_concurrency": int(gw["batch_max_concurrency"]),
            "output_delivery_timeout_s": float(gw["output_delivery_timeout_s"]),
            "output_delivery_retry_backoff_schedule": tuple(
                float(item) for item in gw["output_delivery_retry_backoff_schedule"]
            ),
            "workspace_isolation": str(gw.get("workspace_isolation", "off")),
            "session_isolation": str(gw.get("session_isolation", "thread")),
            "workspace_cleanup": str(gw.get("workspace_cleanup", "retain")),
        }
    except (KeyError, TypeError):
        workflow_run_wait = _resolve_workflow_run_wait_config()
        fallback_gw = config.get("gateway", {}) if isinstance(config, dict) else {}
        return {
            "profile": os.getenv(OBRA_GATEWAY_PROFILE_ENV, GATEWAY_PROFILE_STANDARD),
            "host": _defaults.DEFAULT_GATEWAY_HOST,
            "port": _defaults.DEFAULT_GATEWAY_PORT,
            "max_sessions": _defaults.DEFAULT_GATEWAY_MAX_SESSIONS,
            "auth_token": os.getenv(OBRA_GATEWAY_AUTH_TOKEN_ENV),
            "auth_tokens": [],
            "escalation_timeout_s": _defaults.DEFAULT_GATEWAY_ESCALATION_TIMEOUT_S,
            "enable_cors": _defaults.DEFAULT_GATEWAY_ENABLE_CORS,
            "cors_origins": _defaults.DEFAULT_GATEWAY_CORS_ORIGINS,
            "workflow_storage": _resolve_workflow_storage(fallback_gw),
            "workflow_store_refresh_cooldown_s": resolve_float_config(
                _WORKFLOW_STORE_REFRESH_COOLDOWN_ENV,
                "gateway.workflow_store_refresh_cooldown_s",
                default=None,
                min_val=0.0,
                include_defaults=True,
                label="Gateway config",
            ),
            "workflow_store_refresh_failure_backoff_s": resolve_float_config(
                _WORKFLOW_STORE_REFRESH_FAILURE_BACKOFF_ENV,
                "gateway.workflow_store_refresh_failure_backoff_s",
                default=None,
                min_val=0.0,
                include_defaults=True,
                label="Gateway config",
            ),
            "workflow_store_remote_revision_concurrency": resolve_int_config(
                _WORKFLOW_STORE_REMOTE_REVISION_CONCURRENCY_ENV,
                "gateway.workflow_store_remote_revision_concurrency",
                default=None,
                min_val=1,
                include_defaults=True,
                label="Gateway config",
            ),
            **workflow_run_wait,
            "assistant_action_catalog_cache_max_age_s": (
                _resolve_assistant_action_catalog_cache_max_age_s()
            ),
            "allowed_working_dir_base": "~/obra-projects",
            "max_event_queue_size": 1000,
            "session_eviction_ttl_seconds": 3600,
            "session_timeout_s": 7200,
            "max_objective_length": 10000,
            "max_project_id_length": 256,
            "max_working_dir_length": 4096,
            "cors_allow_credentials": True,
            "allow_public_bind": False,
            "public_bind_tls_terminated": False,
            "trusted_proxy_cidrs": [],
            "ws_auth_timeout_s": 5.0,
            "max_ws_connections_total": 200,
            "max_ws_connections_per_ip": 20,
            "ws_max_message_bytes": 1_048_576,
            "enable_app_rate_limit": True,
            "rest_rate_limit_per_minute": 120,
            "rest_rate_limit_burst": 60,
            "ws_rate_limit_per_minute": 240,
            "ws_rate_limit_burst": 120,
            "workflow_events_heartbeat_seconds": 15.0,
            "workflow_events_stale_after_missed_heartbeats": 3,
            "workflow_changes_proposal_ttl_seconds": 1800,
            "workflow_changes_retention_days": None,
            "pagination_default_limit": 50,
            "pagination_max_limit": 200,
            "logs_session_cookie_name": "obra_logs_session",
            "logs_session_ttl_s": 900,
            "logs_session_cookie_secure": False,
            "studio_session_cookie_name": "obra_studio_session",
            "studio_session_ttl_s": 43_200,
            "studio_session_cookie_secure": False,
            "studio_launch_token_ttl_s": 120,
            "logs_stream_max_clients_total": 100,
            "logs_stream_max_clients_per_ip": 20,
            "logs_stream_idle_timeout_s": 900.0,
            "logs_expose_absolute_paths": False,
            "webhooks_max_per_owner": 50,
            "webhooks_failure_threshold_failing": 5,
            "webhooks_failure_threshold_disabled": 20,
            "webhooks_delivery_timeout_s": 10.0,
            "webhooks_retry_backoff_schedule": (1.0, 5.0, 30.0),
            "webhooks_retention_seconds": 86400,
            "webhooks_cleanup_interval_s": 60.0,
            "webhooks_allow_private_networks": False,
            "idempotency_key_ttl_s": 3600,
            "batch_max_concurrency": 10,
            "output_delivery_timeout_s": 10.0,
            "output_delivery_retry_backoff_schedule": (1.0, 5.0, 30.0),
            "workspace_isolation": "off",
            "session_isolation": "thread",
            "workspace_cleanup": "retain",
        }


def get_gateway_session_timeout() -> int:
    """Return the gateway session timeout in seconds."""
    return resolve_int_config(
        _SESSION_TIMEOUT_ENV,
        "gateway.session_timeout_s",
        default=7200,
        min_val=60,
        include_defaults=True,
        label="Gateway session timeout",
    )


def get_gateway_assistant_config() -> dict:
    """Get gateway assistant context pipeline configuration.

    Returns a flat dict with all assistant operational parameters from
    gateway.assistant config section plus orchestration.content.chars_per_token.
    """
    config, _, _ = _core.load_layered_config(include_defaults=True)
    try:
        assistant = config["gateway"]["assistant"]
    except (KeyError, TypeError):
        assistant = {}

    # Also pull chars_per_token from orchestration.content for token estimation
    try:
        chars_per_token = int(config["orchestration"]["content"]["chars_per_token"])
    except (KeyError, TypeError, ValueError):
        chars_per_token = 4

    section_priorities = assistant.get("section_priorities", {})
    conv_history = assistant.get("conversation_history", {})
    memory = assistant.get("memory", {})
    persistence = assistant.get("persistence", {})
    retention = assistant.get("retention", {})
    proposal_operation_retention = assistant["proposal_operation_retention"]
    strategy = assistant.get("strategy", {})
    revision_history = assistant.get("revision_history", {})
    knowledge = assistant.get("knowledge", {})
    screenshot = assistant.get("screenshot", {})
    run_timeline = assistant.get("run_timeline", {})
    stage_detail = assistant.get("stage_detail", {})
    prompt_sections = assistant.get("prompt_sections", {})
    model = assistant.get("model", {})
    logging_section = assistant.get("logging", {})
    pipelines = assistant.get("pipelines", {})
    pipeline_operation_stale_after_s = int(pipelines["operation_stale_after_s"])
    pipeline_per_step_timeout_budget_s = int(pipelines["per_step_timeout_budget_s"])
    pipeline_sse_heartbeat_interval_s = int(pipelines["sse_heartbeat_interval_s"])
    minimum_operation_stale_after_s = (
        pipeline_per_step_timeout_budget_s + 2 * pipeline_sse_heartbeat_interval_s
    )
    if pipeline_operation_stale_after_s < minimum_operation_stale_after_s:
        msg = (
            "gateway.assistant.pipelines.operation_stale_after_s must be at least "
            "per_step_timeout_budget_s + 2 * sse_heartbeat_interval_s"
        )
        raise ValueError(msg)

    return {
        "prompt_budget_tokens": int(assistant.get("prompt_budget_tokens", 16000)),
        "chars_per_token": chars_per_token,
        "section_priorities": {
            "preamble": int(section_priorities.get("preamble", 1)),
            "selected_stage": int(section_priorities.get("selected_stage", 2)),
            "workflow_definition": int(section_priorities.get("workflow_definition", 3)),
            "workflow_readiness": int(
                prompt_sections.get(
                    "workflow_readiness_priority",
                    section_priorities.get("workflow_readiness", 3),
                )
            ),
            "knowledge_docs": int(section_priorities.get("knowledge_docs", 4)),
            "recent_transcript": int(section_priorities.get("recent_transcript", 4)),
            "thread_summary": int(section_priorities.get("thread_summary", 4)),
            "carry_forward_context": int(section_priorities.get("carry_forward_context", 4)),
            "conversation_history": int(section_priorities.get("conversation_history", 5)),
            "run_comparison": int(section_priorities.get("run_comparison", 5)),
            "latest_run": int(section_priorities.get("latest_run", 6)),
            "ui_state": int(section_priorities.get("ui_state", 7)),
            "graph_structure": int(section_priorities.get("graph_structure", 7)),
            "proactive_guidance": int(section_priorities.get("proactive_guidance", 7)),
            "recent_changes": int(section_priorities.get("recent_changes", 8)),
            "interaction_log": int(section_priorities.get("interaction_log", 9)),
            "revision_history": int(section_priorities.get("revision_history", 10)),
        },
        "conversation_history_max_proposal_turns": int(conv_history.get("max_proposal_turns", 10)),
        "conversation_history_message_preview_chars": int(
            conv_history.get("message_preview_chars", 80)
        ),
        "memory_recent_turns": int(memory.get("recent_turns", 6)),
        "memory_summary_turns": int(memory.get("summary_turns", 12)),
        "memory_summary_message_chars": int(memory.get("summary_message_chars", 160)),
        "memory_mode_event_limit": int(memory.get("mode_event_limit", 6)),
        "persistence_storage_path": str(persistence.get("storage_path", "assistant/threads.json")),
        "retention": {
            "max_active_threads": int(retention.get("max_active_threads", 20)),
            "archive_after_days": int(retention.get("archive_after_days", 30)),
            "delete_after_days": int(retention.get("delete_after_days", 180)),
        },
        "proposal_operation_retention": {
            "terminal_threshold_days": int(
                proposal_operation_retention["terminal_threshold_days"]
            ),
            "conflict_threshold_days": int(
                proposal_operation_retention["conflict_threshold_days"]
            ),
            "cleanup_interval_seconds": int(
                proposal_operation_retention["cleanup_interval_seconds"]
            ),
        },
        "strategy_design_guidance_max_stages": int(strategy.get("design_guidance_max_stages", 3)),
        "revision_history_max_revisions": int(revision_history.get("max_revisions", 5)),
        "knowledge_max_document_bytes": int(knowledge.get("max_document_bytes", 102400)),
        "knowledge_max_total_bytes": int(knowledge.get("max_total_bytes", 2097152)),
        "knowledge_token_budget": int(knowledge.get("token_budget", 2000)),
        "screenshot_max_bytes": int(screenshot.get("max_bytes", 204800)),
        "screenshot_initial_scale": float(screenshot.get("initial_scale", 0.5)),
        "screenshot_jpeg_quality": float(screenshot.get("jpeg_quality", 0.7)),
        "screenshot_fallback_scale": float(screenshot.get("fallback_scale", 0.3)),
        "screenshot_fallback_quality": float(screenshot.get("fallback_quality", 0.5)),
        "workflow_readiness_max_tokens": int(prompt_sections.get("workflow_readiness_max_tokens", 800)),
        "run_timeline_max_events": int(run_timeline.get("max_events", 10)),
        "stage_detail_max_dependency_chain_stages": int(
            stage_detail.get("max_dependency_chain_stages", 20)
        ),
        "latest_run_failure_excerpt_chars": int(
            stage_detail.get("latest_run_failure_excerpt_chars", 500)
        ),
        "recent_run_failure_excerpt_chars": int(
            stage_detail.get("recent_run_failure_excerpt_chars", 200)
        ),
        "model_default_model": str(model.get("default_model", "auto")),
        "model_default_provider": str(model.get("default_provider", "anthropic")),
        "model_health_check_on_startup": bool(model.get("health_check_on_startup", True)),
        "model_health_check_cache_ttl_s": int(model.get("health_check_cache_ttl_s", 300)),
        "auth_method": str(model.get("auth_method", "oauth")),
        "logging": dict(logging_section),
        "pipelines": {
            "default_timeout_s": int(pipelines.get("default_timeout_s", 600)),
            "per_step_timeout_budget_s": pipeline_per_step_timeout_budget_s,
            "sse_heartbeat_interval_s": pipeline_sse_heartbeat_interval_s,
            "operation_stale_after_s": pipeline_operation_stale_after_s,
            "bulk_template_timeout_s": int(pipelines.get("bulk_template_timeout_s", 600)),
            "self_review_timeout_s": int(pipelines.get("self_review_timeout_s", 600)),
            "self_review_auto_min_stage_count": int(
                pipelines.get("self_review_auto_min_stage_count", 5)
            ),
            "diagnostic_timeout_s": int(pipelines.get("diagnostic_timeout_s", 600)),
            "compliance_audit_timeout_s": int(pipelines.get("compliance_audit_timeout_s", 600)),
            "llm_model_tier": str(pipelines.get("llm_model_tier", "fast")),
            "llm_reasoning_level": str(pipelines.get("llm_reasoning_level", "default")),
            "max_pipeline_sessions": int(pipelines["max_pipeline_sessions"]),
            "pipeline_session_eviction_ttl_seconds": int(
                pipelines["pipeline_session_eviction_ttl_seconds"]
            ),
        },
    }


def get_phase_detection_enabled() -> bool:
    """Get gateway assistant phase-detection enabled flag with env override support."""
    return resolve_bool_config(
        f"{_PHASE_DETECTION_ENV_PREFIX}ENABLED",
        "gateway.assistant.phase_detection.enabled",
        default=True,
        include_defaults=True,
    )


def get_phase_detection_draft_instruction_threshold() -> float:
    """Get draft-phase instruction threshold with env override support."""
    return resolve_float_config(
        f"{_PHASE_DETECTION_ENV_PREFIX}DRAFT_INSTRUCTION_THRESHOLD",
        "gateway.assistant.phase_detection.draft_instruction_threshold",
        default=0.5,
        min_val=0.0,
        max_val=1.0,
        include_defaults=True,
    )


def get_phase_detection_validate_min_run_count() -> int:
    """Get minimum persisted workflow runs needed to enter validate phase."""
    return resolve_int_config(
        f"{_PHASE_DETECTION_ENV_PREFIX}VALIDATE_MIN_RUN_COUNT",
        "gateway.assistant.phase_detection.validate_min_run_count",
        default=1,
        min_val=0,
        include_defaults=True,
    )


def get_phase_detection_min_stages_for_full_model() -> int:
    """Get minimum stage count before full readiness phase model applies."""
    return resolve_int_config(
        f"{_PHASE_DETECTION_ENV_PREFIX}MIN_STAGES_FOR_FULL_MODEL",
        "gateway.assistant.phase_detection.min_stages_for_full_model",
        default=3,
        min_val=1,
        include_defaults=True,
    )


def get_phase_detection_stable_run_threshold() -> int:
    """Get run-count threshold for stable-workflow guidance."""
    return resolve_int_config(
        f"{_PHASE_DETECTION_ENV_PREFIX}STABLE_RUN_THRESHOLD",
        "gateway.assistant.phase_detection.stable_run_threshold",
        default=3,
        min_val=1,
        include_defaults=True,
    )


def get_phase_detection_entry_point_defaults() -> dict[str, str]:
    """Get phase overrides for guided-development entry points."""
    env_keys = {
        "clone": f"{_PHASE_DETECTION_ENV_PREFIX}ENTRY_POINT_DEFAULT_CLONE",
        "starter": f"{_PHASE_DETECTION_ENV_PREFIX}ENTRY_POINT_DEFAULT_STARTER",
        "import": f"{_PHASE_DETECTION_ENV_PREFIX}ENTRY_POINT_DEFAULT_IMPORT",
    }
    config, _, _ = _core.load_layered_config(include_defaults=True)
    configured_defaults = (
        config.get("gateway", {})
        .get("assistant", {})
        .get("phase_detection", {})
        .get("entry_point_defaults", {})
    )
    normalized: dict[str, str] = {}
    for entry_point, env_key in env_keys.items():
        raw_value = os.getenv(
            env_key,
            (
                configured_defaults.get(entry_point)
                if isinstance(configured_defaults, dict)
                else None
            ),
        )
        value = str(raw_value or "").strip().lower()
        normalized[entry_point] = value or "computed"
    return normalized


def get_readiness_recap_enabled() -> bool:
    """Get readiness recap toggle with env override support."""
    return resolve_bool_config(
        f"{_READINESS_ENV_PREFIX}RECAP_ENABLED",
        "gateway.assistant.readiness.recap_enabled",
        default=True,
        include_defaults=True,
    )


def get_readiness_seed_alignment_min_keyword_matches() -> int:
    """Get deterministic seed-alignment overlap threshold."""
    return resolve_int_config(
        f"{_READINESS_ENV_PREFIX}SEED_ALIGNMENT_MIN_KEYWORD_MATCHES",
        "gateway.assistant.readiness.seed_alignment_min_keyword_matches",
        default=2,
        min_val=1,
        include_defaults=True,
    )


def get_readiness_first_use_intro_enabled() -> bool:
    """Get first-use introduction toggle with env override support."""
    return resolve_bool_config(
        f"{_READINESS_ENV_PREFIX}FIRST_USE_INTRO_ENABLED",
        "gateway.assistant.readiness.first_use_intro_enabled",
        default=True,
        include_defaults=True,
    )


def get_readiness_next_action_priorities() -> list[str]:
    """Get readiness next-action priority list with env override support."""
    env_value = os.environ.get(f"{_READINESS_ENV_PREFIX}NEXT_ACTION_PRIORITIES")
    if env_value is not None:
        return [item.strip() for item in env_value.split(",") if item.strip()]

    config, _, _ = _core.load_layered_config(include_defaults=True)
    priorities = (
        config.get("gateway", {}).get("assistant", {}).get("readiness", {}).get("next_action_priorities")
    )
    if isinstance(priorities, list):
        return [str(item).strip() for item in priorities if str(item).strip()]
    return [
        "fix_blocking_issues",
        "fix_improvement_issues",
        "enrich_least_complete_stage",
        "add_missing_quality_gates",
        "review_against_seed",
        "run_with_test_data",
        "iterate_on_results",
        "stable_workflow_guidance",
    ]


def get_readiness_prompt_section_priority() -> int:
    """Get workflow-readiness prompt section priority."""
    return resolve_int_config(
        f"{_PROMPT_SECTIONS_ENV_PREFIX}WORKFLOW_READINESS_PRIORITY",
        "gateway.assistant.prompt_sections.workflow_readiness_priority",
        default=3,
        min_val=1,
        include_defaults=True,
    )


def get_readiness_prompt_section_max_tokens() -> int:
    """Get workflow-readiness prompt section max token budget."""
    return resolve_int_config(
        f"{_PROMPT_SECTIONS_ENV_PREFIX}WORKFLOW_READINESS_MAX_TOKENS",
        "gateway.assistant.prompt_sections.workflow_readiness_max_tokens",
        default=800,
        min_val=1,
        include_defaults=True,
    )


def get_gateway_transcription_config() -> dict:
    """Get gateway transcription configuration."""
    config, _, _ = _core.load_layered_config(include_defaults=True)
    transcription = config["gateway"]["transcription"]
    return {
        "provider": str(transcription["provider"]),
        "model_size": str(transcription["model_size"]),
        "max_audio_bytes": int(transcription["max_audio_bytes"]),
    }


def get_gateway_desktop_config() -> dict:
    """Get gateway desktop app operational configuration.

    Returns dict with shutdown_timeout_s, port_scan_start, port_scan_end,
    monitor_interval_s, restart_backoff_s, restart_max_attempts,
    restart_failure_window_s, stable_window_s, path_prefixes,
    preserved_env_vars, stdout_log_filename, stderr_log_filename.
    """
    config, _, _ = _core.load_layered_config(include_defaults=True)
    desktop = config["gateway"]["desktop"]
    return {
        "shutdown_timeout_s": int(desktop["shutdown_timeout_s"]),
        "port_scan_start": int(desktop["port_scan_start"]),
        "port_scan_end": int(desktop["port_scan_end"]),
        "monitor_interval_s": int(desktop["monitor_interval_s"]),
        "restart_backoff_s": int(desktop["restart_backoff_s"]),
        "restart_max_attempts": int(desktop["restart_max_attempts"]),
        "restart_failure_window_s": int(desktop["restart_failure_window_s"]),
        "stable_window_s": int(desktop["stable_window_s"]),
        "path_prefixes": _resolve_desktop_string_list(
            env_key=_DESKTOP_PATH_PREFIXES_ENV,
            config_value=desktop["path_prefixes"],
        ),
        "preserved_env_vars": _resolve_desktop_string_list(
            env_key=_DESKTOP_PRESERVED_ENV_VARS_ENV,
            config_value=desktop["preserved_env_vars"],
            excluded_values=_DESKTOP_EXCLUDED_ENV_VARS,
        ),
        "stdout_log_filename": _resolve_desktop_log_filename(
            env_key=_DESKTOP_STDOUT_LOG_FILENAME_ENV,
            config_value=desktop["stdout_log_filename"],
            label="gateway.desktop.stdout_log_filename",
        ),
        "stderr_log_filename": _resolve_desktop_log_filename(
            env_key=_DESKTOP_STDERR_LOG_FILENAME_ENV,
            config_value=desktop["stderr_log_filename"],
            label="gateway.desktop.stderr_log_filename",
        ),
    }


def _resolve_desktop_string_list(
    *,
    env_key: str,
    config_value: object,
    excluded_values: set[str] | None = None,
) -> list[str]:
    excluded_values = excluded_values or set()
    raw_env = os.getenv(env_key)
    if raw_env is not None:
        raw_values = [item.strip() for item in raw_env.split(",")]
    else:
        if not isinstance(config_value, list):
            raise ConfigurationError(f"{env_key} expects a list-backed config value")
        raw_values = [str(item).strip() for item in config_value]

    normalized: list[str] = []
    for value in raw_values:
        if not value or value in excluded_values or value in normalized:
            continue
        normalized.append(value)
    return normalized


def _resolve_desktop_log_filename(
    *,
    env_key: str,
    config_value: object,
    label: str,
) -> str:
    raw_value = os.getenv(env_key)
    value = raw_value if raw_value is not None else config_value
    normalized = str(value or "").strip()
    if not normalized:
        raise ConfigurationError(f"{label} must be a non-empty filename")
    if normalized in {".", ".."} or normalized != os.path.basename(normalized):
        raise ConfigurationError(f"{label} must be a filename, not a path")
    return normalized


def _reconcile_onboarding_providers(
    effective_providers: list,
    default_providers: list,
) -> list:
    """Backfill declared provider fields from defaults for per-id matches.

    Layered config merges ``gateway.onboarding.providers`` by whole-list
    replacement. Existing user configs authored before a field was added
    to ``default_config.yaml`` therefore silently drop that field at
    load time (e.g. a user config written before ``llm_provider_id``
    existed wipes the default's ``llm_provider_id: anthropic`` entry
    for ``claude_code``). Rather than expand the generic merger with a
    provider-keyed per-item merge, we backfill here: when a user-layer
    provider entry matches a default entry by ``provider_id``, any key
    present on the default and missing from the override is copied in.
    Explicit user overrides are preserved. See ADR-101 for the
    provider-id canonicalization contract.
    """
    defaults_by_id: dict[str, dict] = {}
    if isinstance(default_providers, list):
        for entry in default_providers:
            if not isinstance(entry, dict):
                continue
            provider_id = str(entry.get("provider_id") or "").strip()
            if provider_id:
                defaults_by_id[provider_id] = entry

    reconciled: list[dict] = []
    for entry in effective_providers or []:
        if not isinstance(entry, dict):
            reconciled.append(entry)
            continue
        merged = dict(entry)
        provider_id = str(entry.get("provider_id") or "").strip()
        default_entry = defaults_by_id.get(provider_id)
        if default_entry is not None:
            for key, default_value in default_entry.items():
                if key not in merged and default_value is not None:
                    merged[key] = default_value
        reconciled.append(merged)
    return reconciled


def get_gateway_onboarding_config() -> dict:
    """Get gateway provider onboarding configuration.

    Returns dict with detection_timeout_s, auth_check_timeout_s, auth_timeout_s,
    ready_retry_interval_s, status_poll_interval_s, banner_poll_interval_s,
    success_dwell_s, health_cache_ttl_s, force_refresh_rate_limit_s,
    providers list, terminal_handoff dict, and shell_path_probe dict.
    """
    config, _, _ = _core.load_layered_config(include_defaults=True)
    try:
        onboarding = config["gateway"]["onboarding"]
    except (KeyError, TypeError):
        onboarding = {}
    try:
        default_onboarding = _core._load_default_schema()["gateway"]["onboarding"]
    except (KeyError, TypeError):
        default_onboarding = {}
    effective_providers = _reconcile_onboarding_providers(
        onboarding.get("providers", []),
        default_onboarding.get("providers", []),
    )
    return {
        "detection_timeout_s": int(onboarding.get("detection_timeout_s", 5)),
        "auth_check_timeout_s": int(onboarding.get("auth_check_timeout_s", 5)),
        "auth_timeout_s": int(onboarding.get("auth_timeout_s", 300)),
        "ready_retry_interval_s": int(onboarding.get("ready_retry_interval_s", 2)),
        "status_poll_interval_s": int(onboarding.get("status_poll_interval_s", 3)),
        "banner_poll_interval_s": int(onboarding.get("banner_poll_interval_s", 60)),
        "success_dwell_s": int(onboarding.get("success_dwell_s", 2)),
        "health_cache_ttl_s": int(onboarding.get("health_cache_ttl_s", 30)),
        "force_refresh_rate_limit_s": int(
            onboarding.get("force_refresh_rate_limit_s", 5)
        ),
        "providers": effective_providers,
        "terminal_handoff": dict(onboarding.get("terminal_handoff") or {}),
        "shell_path_probe": dict(onboarding.get("shell_path_probe") or {}),
    }
