"""Context assembler for assistant conversation turns."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from pydantic import BaseModel

from obra.gateway.assistant.pipeline_operations import project_pipeline_operations
from obra.gateway.workflow_studio.assistant_next_step import compute_next_cta
from obra.gateway.workflow_studio.assistant_runnability_gate import (
    PendingAssistantProposalSummary,
)
from obra.gateway.workflow_studio.comparison import build_run_comparison
from obra.gateway.workflow_studio.output_review_context import build_output_review_context
from obra.gateway.workflow_studio.repository import WorkflowStudioRepository
from obra.gateway.workflow_studio.starter_catalog import (
    normalize_starter_domain_id,
    resolve_domain_starters,
)
from obra.gateway.workflow_studio.template_asset_store_resolver import resolve_template_asset_store
from obra.workflow.readiness import build_seed_summary, extract_workflow_seed
from obra.workflow.runnability_validation import (
    augment_validation_summary_with_runnability_issues,
)

logger = logging.getLogger(__name__)


def _resolve_business_tier_defaults(
    *,
    domain_id: str | None,
    workflow: dict[str, Any] | None,
) -> dict[str, Any]:
    """Return configured business tier defaults for prompt guidance."""
    normalized_domain_id = normalize_starter_domain_id(domain_id)
    if not normalized_domain_id and isinstance(workflow, dict):
        normalized_domain_id = normalize_starter_domain_id(
            str(workflow.get("domain_id") or workflow.get("domain") or "")
        )
    if normalized_domain_id != "business":
        return {}

    try:
        from obra_business.config.loader import (
            get_config_value,
            load_config,
            normalize_stage_type_tiers,
        )

        config = load_config()
        return {
            "business_execution_tier": get_config_value(config, "business.llm.execution_tier"),
            "business_execution_timeout_s": get_config_value(
                config, "business.llm.execution_timeout_s"
            ),
            "business_context_budget": {
                "excerpt_chars": get_config_value(
                    config,
                    "business.llm.context_budget.excerpt_chars",
                ),
                "total_chars": get_config_value(
                    config,
                    "business.llm.context_budget.total_chars",
                ),
                "full_recent_count": get_config_value(
                    config,
                    "business.llm.context_budget.full_recent_count",
                ),
            },
            "business_stage_type_tiers": normalize_stage_type_tiers(
                get_config_value(config, "business.llm.stage_type_tiers")
            ),
        }
    except Exception as exc:
        logger.warning("Failed to resolve business tier defaults for assistant context: %s", exc)
        return {}


def _extract_latest_stage_context_hydration_report(*sources: Any) -> dict[str, Any] | None:
    """Return the last context_hydration_report found in resolved run data."""
    reports: list[dict[str, Any]] = []

    def visit(value: Any) -> None:
        if isinstance(value, dict):
            metadata = value.get("metadata")
            if isinstance(metadata, dict) and isinstance(
                metadata.get("context_hydration_report"),
                dict,
            ):
                reports.append(dict(metadata["context_hydration_report"]))
            direct_report = value.get("context_hydration_report")
            if isinstance(direct_report, dict):
                reports.append(dict(direct_report))
            for child in value.values():
                if isinstance(child, (dict, list)):
                    visit(child)
        elif isinstance(value, list):
            for child in value:
                if isinstance(child, (dict, list)):
                    visit(child)

    for source in sources:
        visit(source)
    return reports[-1] if reports else None


class UIState(BaseModel):
    """Typed UI state fields matching client EditorContext interface."""

    editor_surface: str | None = None
    editor_mode: str | None = None
    dirty: bool = False
    stage_count: int = 0
    last_change_kind: str | None = None
    last_change_summary: str | None = None
    has_validation_errors: bool = False
    validation_error_count: int = 0
    validation_error_stages: list[str] = []
    validation_issues: list[dict[str, Any]] = []
    has_conflict: bool = False
    last_save_status: str | None = None
    save_readiness: str | None = None
    semantic_projection: dict[str, Any] | None = None
    recent_interactions: list[dict[str, Any]] | None = None
    last_diff_summary: dict[str, Any] | None = None
    screenshot: str | None = None


class ContextAttachment(BaseModel):
    """Client-supplied context for a conversation turn."""

    project_id: str | None = None
    safety_mode: str = "guided"
    working_dir: str | None = None
    domain_id: str | None = None
    workflow_id: str | None = None
    revision_id: str | None = None
    run_id: str | None = None
    artifact_id: str | None = None
    derivation_id: str | None = None
    selected_nodes: list[str] | None = None
    current_route: str | None = None
    ui_state: dict[str, Any] | None = None
    recent_runs: list[dict[str, Any]] | None = None

    def resolve_ui_state(self) -> UIState:
        """Parse ui_state dict into typed UIState with defaults."""
        if self.ui_state is None:
            return UIState()
        return UIState.model_validate(self.ui_state)


def _workflow_id_from_selected_run(selected_run: dict[str, Any] | None) -> str | None:
    if not isinstance(selected_run, dict):
        return None
    workflow_ref = selected_run.get("workflow_ref")
    if isinstance(workflow_ref, dict):
        workflow_id = str(workflow_ref.get("workflow_id") or "").strip()
        if workflow_id:
            return workflow_id
    workflow_id = str(selected_run.get("workflow_id") or "").strip()
    return workflow_id or None


def _selected_run_id(selected_run: dict[str, Any] | None) -> str | None:
    if not isinstance(selected_run, dict):
        return None
    run_id = str(selected_run.get("workflow_run_id") or selected_run.get("run_id") or "").strip()
    return run_id or None


def _issue_key(issue: Any) -> tuple[str, str | None, str]:
    if not isinstance(issue, dict):
        return ("", None, str(issue))
    return (
        str(issue.get("code") or "").strip(),
        str(issue.get("stage_id") or "").strip() or None,
        str(issue.get("message") or issue.get("plain_description") or "").strip(),
    )


def _build_ui_context(context: ContextAttachment, resolved_domain_id: str | None) -> dict[str, Any]:
    ui_context: dict[str, Any] = {}
    if context.selected_nodes is not None:
        ui_context["selected_nodes"] = context.selected_nodes
    if context.current_route is not None:
        ui_context["current_route"] = context.current_route
    if context.ui_state is not None:
        ui_context.update(context.ui_state)
    if resolved_domain_id:
        ui_context["domain_id"] = resolved_domain_id
    return ui_context


_RECENT_RUNS_LIMIT = 10


def _filter_recent_runs(
    candidates: list[dict[str, Any]] | None,
    active_workflow_id: str | None,
) -> list[dict[str, Any]]:
    """Return up to N recent runs scoped to the active workflow.

    Trusts the client to supply the runs already known to the user (Studio Web's
    runs collection); the gateway filters to the active workflow and picks a
    compact projection so the assistant prompt stays small.
    """
    if not candidates:
        return []
    out: list[dict[str, Any]] = []
    target = (active_workflow_id or "").strip()
    for raw in candidates:
        if not isinstance(raw, dict):
            continue
        run_workflow_id = ""
        ref = raw.get("workflow_ref")
        if isinstance(ref, dict):
            run_workflow_id = str(ref.get("workflow_id") or "").strip()
        if not run_workflow_id:
            run_workflow_id = str(raw.get("workflow_id") or "").strip()
        if target and run_workflow_id and run_workflow_id != target:
            continue
        run_id = str(raw.get("workflow_run_id") or raw.get("run_id") or "").strip()
        if not run_id:
            continue
        current_stage = raw.get("current_stage")
        current_stage_label = ""
        if isinstance(current_stage, dict):
            current_stage_label = str(
                current_stage.get("title")
                or current_stage.get("stage_name")
                or current_stage.get("stage_id")
                or ""
            ).strip()
        objective = str(raw.get("objective") or "").strip()
        if len(objective) > 140:
            objective = objective[:137].rstrip() + "..."
        out.append(
            {
                "run_id": run_id,
                "status": str(raw.get("status") or "").strip(),
                "created_at": str(raw.get("created_at") or "").strip() or None,
                "current_stage": current_stage_label or None,
                "objective": objective or None,
            }
        )
        if len(out) >= _RECENT_RUNS_LIMIT:
            break
    return out


def _semantic_projection(ui_context: dict[str, Any] | None) -> dict[str, Any] | None:
    if not isinstance(ui_context, dict):
        return None
    projection = ui_context.get("semantic_projection")
    return projection if isinstance(projection, dict) else None


def _semantic_workflow_definition(ui_context: dict[str, Any] | None) -> dict[str, Any] | None:
    projection = _semantic_projection(ui_context)
    workflow_definition = projection.get("workflow_definition") if isinstance(projection, dict) else None
    return workflow_definition if isinstance(workflow_definition, dict) else None


def _has_unsaved_semantic_workflow_changes(ui_context: dict[str, Any] | None) -> bool:
    if not isinstance(ui_context, dict):
        return False
    if bool(ui_context.get("dirty")) or bool(ui_context.get("has_conflict")):
        return True
    save_readiness = str(ui_context.get("save_readiness") or "").strip().lower()
    return bool(save_readiness and save_readiness not in {"ready", "saved"})


def _semantic_entry_point(ui_context: dict[str, Any] | None) -> str | None:
    projection = _semantic_projection(ui_context)
    entry_point = str(projection.get("entry_point") or "").strip() if isinstance(projection, dict) else ""
    return entry_point or None


def _workflow_metadata_working_dir(resolved_workflow: dict[str, Any] | None) -> str | None:
    if not isinstance(resolved_workflow, dict):
        return None
    metadata = resolved_workflow.get("metadata")
    if not isinstance(metadata, dict):
        return None
    working_dir = str(metadata.get("working_dir") or "").strip()
    return working_dir or None


def _resolve_context_working_dir(
    context_working_dir: str | None,
    resolved_workflow: dict[str, Any] | None,
) -> str | None:
    workflow_working_dir = _workflow_metadata_working_dir(resolved_workflow)
    if workflow_working_dir is None:
        return context_working_dir
    if not str(context_working_dir or "").strip():
        return workflow_working_dir
    try:
        context_path = Path(str(context_working_dir)).expanduser().resolve(strict=False)
        workflow_path = Path(workflow_working_dir).expanduser().resolve(strict=False)
    except (OSError, RuntimeError):
        return context_working_dir
    if context_path == workflow_path:
        return str(context_path)
    if context_path in workflow_path.parents:
        return str(workflow_path)
    return context_working_dir


def _template_asset_project_root(
    resolved_context: dict[str, Any],
    fallback_project_root: Any | None,
) -> Any | None:
    """Prefer the workflow-resolved directory for template asset lookups."""
    working_dir = resolved_context.get("working_dir")
    if isinstance(working_dir, str) and working_dir.strip():
        return working_dir
    return fallback_project_root


def _run_sort_key(run: dict[str, Any]) -> str:
    return str(run.get("created_at") or "")


def _revision_sort_key(revision: dict[str, Any]) -> str:
    return str(revision.get("created_at") or revision.get("updated_at") or "")


def _build_starter_catalog(resolved_domain_id: str | None) -> list[dict[str, Any]]:
    return [
        {
            "id": str(starter.get("id") or ""),
            "title": str(starter.get("title") or ""),
            "description": str(starter.get("description") or ""),
            "intended_use_cases": starter.get("intended_use_cases") or [],
        }
        for starter in resolve_domain_starters(resolved_domain_id)
    ]


class AssistantContextAssembler:
    """Resolves Studio context for an assistant conversation turn.

    Reads from the existing WorkflowStudioRepository to populate workflow
    and run context alongside client-supplied UI state.
    """

    def __init__(
        self,
        repository: WorkflowStudioRepository,
        project_root: Any | None = None,
        pipeline_session_manager: Any | None = None,
        operation_stale_after_s: int | None = None,
        app_state: Any | None = None,
        pending_assistant_proposals: PendingAssistantProposalSummary | None = None,
    ) -> None:
        self._repository = repository
        self._project_root = project_root
        self._pipeline_session_manager = pipeline_session_manager
        self._operation_stale_after_s = operation_stale_after_s
        self._app_state = app_state
        self._pending_assistant_proposals = (
            pending_assistant_proposals or PendingAssistantProposalSummary()
        )

    def _list_workflow_runs(
        self,
        workflow_id: str | None,
    ) -> list[dict[str, Any]]:
        normalized_workflow_id = str(workflow_id or "").strip()
        if not normalized_workflow_id:
            return []
        try:
            runs = self._repository.list_runs(workflow_id=normalized_workflow_id)
        except Exception as exc:
            logger.warning(
                "Failed to list runs for workflow %s: %s", normalized_workflow_id, exc
            )
            return []
        if not isinstance(runs, list):
            return []
        return sorted(
            [run for run in runs if isinstance(run, dict)],
            key=_run_sort_key,
            reverse=True,
        )

    def _resolve_workflow_and_runs(
        self,
        context: ContextAttachment,
    ) -> tuple[dict[str, Any] | None, dict[str, Any] | None, dict[str, Any] | None, Any | None, dict[str, Any] | None]:
        resolved_workflow: dict[str, Any] | None = None
        resolved_latest_run: dict[str, Any] | None = None
        resolved_selected_run: dict[str, Any] | None = None
        selected_run_bundle: Any | None = None
        resolved_run_replay: dict[str, Any] | None = None

        if context.workflow_id is not None:
            try:
                resolved_workflow = self._repository.get_workflow(context.workflow_id)
            except Exception as exc:
                logger.warning("Failed to resolve workflow %s: %s", context.workflow_id, exc)
                resolved_workflow = None

            if resolved_workflow is not None:
                matching_runs = self._list_workflow_runs(context.workflow_id)
                if matching_runs:
                    resolved_latest_run = matching_runs[0]

        if context.run_id is None:
            return (
                resolved_workflow,
                resolved_latest_run,
                resolved_selected_run,
                selected_run_bundle,
                resolved_run_replay,
            )

        try:
            resolved_selected_run = self._repository.get_run(context.run_id)
        except Exception as exc:
            logger.warning("Failed to resolve run %s: %s", context.run_id, exc)
            resolved_selected_run = None
        try:
            selected_run_bundle = self._repository.get_run_bundle(context.run_id)
        except Exception as exc:
            logger.warning("Failed to resolve run bundle %s: %s", context.run_id, exc)
            selected_run_bundle = None
        if resolved_selected_run is None:
            return (
                resolved_workflow,
                resolved_latest_run,
                resolved_selected_run,
                selected_run_bundle,
                resolved_run_replay,
            )

        try:
            resolved_run_replay = self._repository.get_run_replay(context.run_id)
        except Exception as exc:
            logger.warning("Failed to resolve run replay %s: %s", context.run_id, exc)
            resolved_run_replay = None
        if resolved_workflow is None:
            selected_workflow_id = _workflow_id_from_selected_run(resolved_selected_run)
            if selected_workflow_id:
                try:
                    resolved_workflow = self._repository.get_workflow(selected_workflow_id)
                except Exception as exc:
                    logger.warning(
                        "Failed to resolve workflow %s from run: %s",
                        selected_workflow_id,
                        exc,
                    )
                    resolved_workflow = None
        return (
            resolved_workflow,
            resolved_latest_run,
            resolved_selected_run,
            selected_run_bundle,
            resolved_run_replay,
        )

    def _resolve_artifact_context(
        self,
        context: ContextAttachment,
        resolved_workflow: dict[str, Any] | None,
        resolved_selected_run: dict[str, Any] | None,
        selected_run_bundle: Any | None,
        resolved_run_replay: dict[str, Any] | None,
    ) -> tuple[
        dict[str, Any] | None,
        str | None,
        dict[str, Any] | None,
        Any | None,
        dict[str, Any] | None,
        dict[str, Any] | None,
    ]:
        resolved_selected_artifact: dict[str, Any] | None = None
        artifact_content: str | None = None

        if context.artifact_id is None:
            return (
                resolved_selected_artifact,
                artifact_content,
                resolved_selected_run,
                selected_run_bundle,
                resolved_run_replay,
                resolved_workflow,
            )

        try:
            resolved_selected_artifact = self._repository.get_artifact(context.artifact_id)
        except Exception as exc:
            logger.warning("Failed to resolve artifact %s: %s", context.artifact_id, exc)
            resolved_selected_artifact = None
        try:
            artifact_content = self._repository.get_artifact_content(context.artifact_id)
        except Exception as exc:
            logger.warning("Failed to resolve artifact content %s: %s", context.artifact_id, exc)
            artifact_content = None

        if resolved_selected_artifact is not None:
            producer_run_id = resolved_selected_artifact.get("producer_run_id")
            if producer_run_id and resolved_selected_run is None:
                try:
                    resolved_selected_run = self._repository.get_run(str(producer_run_id))
                except Exception as exc:
                    logger.warning("Failed to resolve producer run %s: %s", producer_run_id, exc)
                    resolved_selected_run = None
                try:
                    selected_run_bundle = self._repository.get_run_bundle(str(producer_run_id))
                except Exception as exc:
                    logger.warning(
                        "Failed to resolve producer run bundle %s: %s", producer_run_id, exc
                    )
                    selected_run_bundle = None
                if resolved_selected_run is not None:
                    try:
                        resolved_run_replay = self._repository.get_run_replay(str(producer_run_id))
                    except Exception as exc:
                        logger.warning(
                            "Failed to resolve producer run replay %s: %s", producer_run_id, exc
                        )
                        resolved_run_replay = None
            if resolved_workflow is None and resolved_selected_run is not None:
                selected_workflow_id = _workflow_id_from_selected_run(resolved_selected_run)
                if selected_workflow_id:
                    try:
                        resolved_workflow = self._repository.get_workflow(selected_workflow_id)
                    except Exception as exc:
                        logger.warning(
                            "Failed to resolve workflow %s from artifact: %s",
                            selected_workflow_id,
                            exc,
                        )
                        resolved_workflow = None
        return (
            resolved_selected_artifact,
            artifact_content,
            resolved_selected_run,
            selected_run_bundle,
            resolved_run_replay,
            resolved_workflow,
        )

    def _resolve_derivation(self, context: ContextAttachment) -> dict[str, Any] | None:
        if context.derivation_id is None:
            return None
        try:
            return self._repository.get_derivation(context.derivation_id)
        except Exception as exc:
            logger.warning("Failed to resolve derivation %s: %s", context.derivation_id, exc)
            return None

    def _resolve_revision_history(
        self,
        context: ContextAttachment,
        resolved_workflow: dict[str, Any] | None,
    ) -> list[dict[str, Any]]:
        if context.workflow_id is None or resolved_workflow is None:
            return []
        try:
            from obra.config.loaders import get_gateway_assistant_config

            assistant_config = get_gateway_assistant_config()
            max_revisions = assistant_config.get("revision_history_max_revisions", 5)
            revisions = self._repository.list_workflow_revisions(context.workflow_id)
            return revisions[-max_revisions:]
        except Exception as exc:
            logger.warning(
                "Failed to resolve revision history for workflow %s: %s",
                context.workflow_id,
                exc,
            )
            return []

    def _resolve_template_assets(
        self,
        resolved_workflow: dict[str, Any] | None,
    ) -> dict[str, str]:
        template_assets: dict[str, str] = {}
        if resolved_workflow is None:
            return template_assets
        stages = (
            resolved_workflow.get("stages")
            or resolved_workflow.get("definition", {}).get("stages")
            or []
        )
        for stage in stages:
            bindings = stage.get("template_asset_bindings") or []
            stage_id = stage.get("stage_id") or stage.get("id") or ""
            for binding in bindings:
                asset_id = binding.get("asset_id") or binding.get("template_id")
                if not asset_id:
                    continue
                try:
                    content = self._repository.get_template_asset(asset_id)
                    if content:
                        template_assets[stage_id] = content
                except Exception as exc:
                    logger.warning(
                        "Failed to resolve template asset %s for stage %s: %s",
                        asset_id,
                        stage_id,
                        exc,
                    )
        return template_assets

    def _resolve_policy_memory_records(
        self,
        context: ContextAttachment,
        resolved_workflow: dict[str, Any] | None,
        resolved_selected_run: dict[str, Any] | None,
    ) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
        policy_memory_records: list[dict[str, Any]] = []
        legacy_sources: list[dict[str, Any]] = []
        if self._project_root is None:
            return policy_memory_records, legacy_sources
        try:
            from obra.config.loaders import get_gateway_assistant_config as _get_kac
            from obra.gateway.workflow_studio.knowledge_repository import KnowledgeRepository
            from obra.gateway.workflow_studio.policy_memory_repository import PolicyMemoryRepository

            assistant_config = _get_kac()
            knowledge_repository = KnowledgeRepository(
                self._project_root,
                max_document_bytes=assistant_config["knowledge_max_document_bytes"],
                max_total_bytes=assistant_config["knowledge_max_total_bytes"],
            )
            policy_repository = PolicyMemoryRepository(
                self._project_root,
                knowledge_repository=knowledge_repository,
            )
            workflow_id = (
                str((resolved_workflow or {}).get("workflow_id") or "").strip()
                or str(((resolved_selected_run or {}).get("workflow_ref") or {}).get("workflow_id") or "").strip()
                or str(context.workflow_id or "").strip()
                or None
            )
            resolution = policy_repository.resolve_records(
                project_id=context.project_id,
                workflow_id=workflow_id,
                include_legacy_sources=True,
            )
            policy_memory_records = list(resolution.get("records") or [])
            legacy_sources = list(resolution.get("legacy_sources") or [])
        except Exception as exc:
            logger.warning("Failed to initialize policy/memory repository: %s", exc)
            return [], []
        return policy_memory_records, legacy_sources

    def _resolve_run_timeline(
        self,
        resolved_latest_run: dict[str, Any] | None,
        resolved_run_replay: dict[str, Any] | None,
    ) -> list[dict[str, Any]]:
        if not isinstance(resolved_latest_run, dict):
            return []
        run_status = str(resolved_latest_run.get("status") or "")
        if run_status not in {"failed", "cancelled"}:
            return []
        run_id = resolved_latest_run.get("run_id") or resolved_latest_run.get("id")
        if not run_id:
            return []
        try:
            from obra.config.loaders import get_gateway_assistant_config as _get_ac

            assistant_config = _get_ac()
            max_events = assistant_config.get("run_timeline_max_events", 10)
            replay = resolved_run_replay
            if not isinstance(replay, dict):
                replay = self._repository.get_run_replay(run_id)
            if replay and isinstance(replay, dict):
                return (replay.get("entries") or [])[-max_events:]
        except Exception as exc:
            logger.warning("Failed to resolve run timeline for run %s: %s", run_id, exc)
        return []

    def _resolve_workflow_run_count(
        self,
        context: ContextAttachment,
        resolved_workflow: dict[str, Any] | None,
    ) -> int:
        workflow_id = (
            str(context.workflow_id or "").strip()
            or str((resolved_workflow or {}).get("workflow_id") or "").strip()
        )
        if not workflow_id:
            return 0
        try:
            return len(self._repository.list_runs(workflow_id=workflow_id))
        except Exception as exc:
            logger.warning("Failed to resolve run count for workflow %s: %s", workflow_id, exc)
            return 0

    def _resolve_assistant_pipeline_operations(
        self,
        *,
        workflow_id: str | None,
        thread_id: str | None,
    ) -> list[dict[str, Any]]:
        if self._pipeline_session_manager is None or self._operation_stale_after_s is None:
            return []
        normalized_workflow_id = str(workflow_id or "").strip() or None
        normalized_thread_id = str(thread_id or "").strip() or None
        if normalized_workflow_id is None and normalized_thread_id is None:
            return []
        try:
            records = self._pipeline_session_manager.list_records(
                workflow_id=normalized_workflow_id,
                thread_id=normalized_thread_id,
            )
            return project_pipeline_operations(
                records,
                operation_stale_after_s=self._operation_stale_after_s,
            )
        except Exception as exc:
            logger.warning("Failed to resolve assistant pipeline operations: %s", exc)
            return []

    def _resolve_workflow_readiness(
        self,
        resolved_workflow: dict[str, Any] | None,
        resolved_context: dict[str, Any],
        *,
        workflow_run_count: int,
        construction_context: dict[str, Any] | None,
    ) -> dict[str, Any] | None:
        try:
            ui_context = resolved_context.get("ui_context")
            semantic_workflow_definition = _semantic_workflow_definition(
                ui_context if isinstance(ui_context, dict) else None
            )
            semantic_entry_point = _semantic_entry_point(
                ui_context if isinstance(ui_context, dict) else None
            )
            if isinstance(resolved_workflow, dict):
                workflow_definition = resolved_workflow.get("workflow_definition")
                if not isinstance(workflow_definition, dict):
                    workflow_definition = resolved_workflow
                workflow_metadata = resolved_workflow.get("metadata")
                workflow_metadata = (
                    workflow_metadata if isinstance(workflow_metadata, dict) else {}
                )
                validation_summary = resolved_workflow.get("validation_summary")
            else:
                workflow_definition = {"stages": []}
                workflow_metadata = {}
                validation_summary = {}
            if isinstance(semantic_workflow_definition, dict) and (
                not isinstance(resolved_workflow, dict)
                or _has_unsaved_semantic_workflow_changes(
                    ui_context if isinstance(ui_context, dict) else None
                )
            ):
                workflow_definition = semantic_workflow_definition
            if not isinstance(validation_summary, dict):
                workflow_payload = resolved_context.get("workflow")
                if isinstance(workflow_payload, dict):
                    fallback_summary = workflow_payload.get("validation_summary")
                    validation_summary = fallback_summary if isinstance(fallback_summary, dict) else {}
            else:
                validation_summary = {}
            if isinstance(workflow_definition, dict):
                validation_summary = augment_validation_summary_with_runnability_issues(
                    workflow_definition,
                    workflow_id=str(
                        resolved_context.get("workflow_id")
                        or workflow_definition.get("workflow_id")
                        or ""
                    ),
                    validation_summary=validation_summary,
                    template_asset_store=resolve_template_asset_store(
                        self._app_state,
                        project_root=_template_asset_project_root(
                            resolved_context,
                            self._project_root,
                        ),
                    ),
                    pending_proposals=self._pending_assistant_proposals,
                )

            validation_outcome = None
            if validation_summary:
                from obra.workflow.readiness import normalize_validation_outcome

                validation_outcome = normalize_validation_outcome(validation_summary)

            from obra.workflow.readiness import compute_workflow_readiness

            return compute_workflow_readiness(
                workflow_definition,
                validation_outcome,
                workflow_run_count,
                workflow_metadata=workflow_metadata,
                construction_context=construction_context,
                entry_point=semantic_entry_point,
            )
        except Exception as exc:
            logger.warning("Failed to resolve workflow readiness: %s", exc)
            return None

    def _resolve_run_comparison(
        self,
        workflow_id: str | None,
    ) -> dict[str, Any] | None:
        workflow_runs = self._list_workflow_runs(workflow_id)
        if len(workflow_runs) < 2:
            return None

        bundles = []
        for run in workflow_runs[:2]:
            run_id = _selected_run_id(run)
            if not run_id:
                return None
            try:
                bundles.append(self._repository.get_run_bundle(run_id))
            except Exception as exc:
                logger.warning("Failed to resolve run bundle %s: %s", run_id, exc)
                return None
        if len(bundles) < 2:
            return None
        try:
            return build_run_comparison(bundles)
        except Exception as exc:
            logger.warning("Failed to build run comparison for workflow %s: %s", workflow_id, exc)
            return None

    def _resolve_workflow_revisions(
        self,
        workflow_id: str | None,
    ) -> list[dict[str, Any]]:
        normalized_workflow_id = str(workflow_id or "").strip()
        if not normalized_workflow_id:
            return []
        try:
            revisions = self._repository.list_workflow_revisions(normalized_workflow_id)
        except Exception as exc:
            logger.warning(
                "Failed to resolve revisions for workflow %s: %s",
                normalized_workflow_id,
                exc,
            )
            return []
        if not isinstance(revisions, list):
            return []
        return sorted(
            [revision for revision in revisions if isinstance(revision, dict)],
            key=_revision_sort_key,
            reverse=True,
        )

    def _resolve_selected_run_comparison(
        self,
        *,
        resolved_selected_run: dict[str, Any] | None,
        selected_run_bundle: Any | None,
        resolved_workflow: dict[str, Any] | None,
    ) -> dict[str, Any] | None:
        if not isinstance(resolved_selected_run, dict):
            return None
        selected_run_id = _selected_run_id(resolved_selected_run)
        workflow_id = _workflow_id_from_selected_run(resolved_selected_run) or str(
            (resolved_workflow or {}).get("workflow_id") or ""
        ).strip()
        if not selected_run_id or not workflow_id:
            return None

        workflow_runs = self._list_workflow_runs(workflow_id)
        if len(workflow_runs) < 2:
            return None
        revisions = self._resolve_workflow_revisions(workflow_id)
        baseline_run = self._resolve_selected_run_baseline(
            selected_run=resolved_selected_run,
            selected_run_bundle=selected_run_bundle,
            workflow_runs=workflow_runs,
            revisions=revisions,
        )
        if not isinstance(baseline_run, dict):
            return None
        baseline_run_id = _selected_run_id(baseline_run)
        if not baseline_run_id or baseline_run_id == selected_run_id:
            return None
        try:
            bundles = [
                self._repository.get_run_bundle(selected_run_id),
                self._repository.get_run_bundle(baseline_run_id),
            ]
            quality_scorecards_by_run = self._repository.list_quality_scorecards_for_runs(bundles)
            return build_run_comparison(
                bundles,
                quality_scorecards_by_run=quality_scorecards_by_run,
            )
        except Exception as exc:
            logger.warning(
                "Failed to build selected-run comparison for %s vs %s: %s",
                selected_run_id,
                baseline_run_id,
                exc,
            )
            return None

    def _resolve_selected_run_baseline(
        self,
        *,
        selected_run: dict[str, Any],
        selected_run_bundle: Any | None,
        workflow_runs: list[dict[str, Any]],
        revisions: list[dict[str, Any]],
    ) -> dict[str, Any] | None:
        selected_run_id = _selected_run_id(selected_run)
        selected_revision_id = str(
            ((selected_run.get("workflow_ref") or {}).get("revision_id") if isinstance(selected_run.get("workflow_ref"), dict) else "")
            or selected_run.get("revision_id")
            or ""
        ).strip()
        runs_by_revision: dict[str, list[dict[str, Any]]] = {}
        for run in workflow_runs:
            if not isinstance(run, dict):
                continue
            run_revision_id = str(
                ((run.get("workflow_ref") or {}).get("revision_id") if isinstance(run.get("workflow_ref"), dict) else "")
                or run.get("revision_id")
                or ""
            ).strip()
            if not run_revision_id:
                continue
            runs_by_revision.setdefault(run_revision_id, []).append(run)

        explicit_baseline_revision_id = self._explicit_baseline_revision_id(
            selected_run=selected_run,
            selected_run_bundle=selected_run_bundle,
            revisions=revisions,
            selected_revision_id=selected_revision_id,
        )
        if explicit_baseline_revision_id:
            explicit_run = self._latest_run_for_revision(
                explicit_baseline_revision_id,
                runs_by_revision,
                exclude_run_id=selected_run_id,
            )
            if explicit_run is not None:
                return explicit_run

        ancestor_revision_ids = self._ancestor_revision_ids(selected_revision_id, revisions)
        for revision_id in ancestor_revision_ids:
            ancestor_run = self._latest_run_for_revision(
                revision_id,
                runs_by_revision,
                exclude_run_id=selected_run_id,
            )
            if ancestor_run is not None:
                return ancestor_run
        return None

    def _explicit_baseline_revision_id(
        self,
        *,
        selected_run: dict[str, Any],
        selected_run_bundle: Any | None,
        revisions: list[dict[str, Any]],
        selected_revision_id: str,
    ) -> str | None:
        if selected_run_bundle is not None:
            remote_session = (
                selected_run_bundle.remote_session
                if isinstance(getattr(selected_run_bundle, "remote_session", None), dict)
                else {}
            )
            derivation_state = (
                remote_session.get("workflow_derivation_state")
                if isinstance(remote_session.get("workflow_derivation_state"), dict)
                else {}
            )
            expected_baseline_ref = (
                derivation_state.get("expected_baseline_ref")
                if isinstance(derivation_state.get("expected_baseline_ref"), dict)
                else {}
            )
            baseline_revision_id = str(
                expected_baseline_ref.get("revision_id")
                or expected_baseline_ref.get("version")
                or ""
            ).strip()
            if baseline_revision_id:
                return baseline_revision_id

        run_outcome_summary = (
            selected_run.get("outcome_summary") if isinstance(selected_run.get("outcome_summary"), dict) else {}
        )
        comparison_context = (
            run_outcome_summary.get("comparison_context")
            if isinstance(run_outcome_summary.get("comparison_context"), dict)
            else {}
        )
        outcome_baseline_revision_id = str(
            comparison_context.get("baseline_revision_id") or ""
        ).strip()
        if outcome_baseline_revision_id:
            return outcome_baseline_revision_id

        for revision in revisions:
            if str(revision.get("revision_id") or "").strip() != selected_revision_id:
                continue
            diff_summary = (
                revision.get("diff_summary") if isinstance(revision.get("diff_summary"), dict) else {}
            )
            baseline_revision_id = str(
                diff_summary.get("base_revision_id") or revision.get("previous_revision_id") or ""
            ).strip()
            if baseline_revision_id:
                return baseline_revision_id
            break
        return None

    def _ancestor_revision_ids(
        self,
        selected_revision_id: str,
        revisions: list[dict[str, Any]],
    ) -> list[str]:
        if not selected_revision_id:
            return []
        revisions_by_id = {
            str(revision.get("revision_id") or "").strip(): revision
            for revision in revisions
            if isinstance(revision, dict) and str(revision.get("revision_id") or "").strip()
        }
        ancestor_revision_ids: list[str] = []
        seen: set[str] = set()
        current_revision_id = selected_revision_id
        while current_revision_id and current_revision_id not in seen:
            seen.add(current_revision_id)
            revision = revisions_by_id.get(current_revision_id)
            if not isinstance(revision, dict):
                break
            diff_summary = (
                revision.get("diff_summary") if isinstance(revision.get("diff_summary"), dict) else {}
            )
            previous_revision_id = str(
                diff_summary.get("base_revision_id") or revision.get("previous_revision_id") or ""
            ).strip()
            if not previous_revision_id:
                break
            ancestor_revision_ids.append(previous_revision_id)
            current_revision_id = previous_revision_id
        return ancestor_revision_ids

    def _latest_run_for_revision(
        self,
        revision_id: str,
        runs_by_revision: dict[str, list[dict[str, Any]]],
        *,
        exclude_run_id: str | None = None,
    ) -> dict[str, Any] | None:
        candidates = []
        for run in runs_by_revision.get(revision_id, []):
            run_id = _selected_run_id(run)
            if exclude_run_id and run_id == exclude_run_id:
                continue
            candidates.append(run)
        if not candidates:
            return None
        return sorted(candidates, key=_run_sort_key, reverse=True)[0]

    def resolve(
        self,
        context: ContextAttachment,
        construction_context: dict[str, Any] | None = None,
        thread_id: str | None = None,
    ) -> dict[str, Any]:
        """Resolve full context from a client-supplied attachment.

        Returns a dict with keys: project_id, workflow, latest_run,
        ui_context, safety_mode.
        """
        resolved_domain_id = normalize_starter_domain_id(context.domain_id)
        (
            resolved_workflow,
            resolved_latest_run,
            resolved_selected_run,
            selected_run_bundle,
            resolved_run_replay,
        ) = self._resolve_workflow_and_runs(context)
        (
            resolved_selected_artifact,
            artifact_content,
            resolved_selected_run,
            selected_run_bundle,
            resolved_run_replay,
            resolved_workflow,
        ) = self._resolve_artifact_context(
            context,
            resolved_workflow,
            resolved_selected_run,
            selected_run_bundle,
            resolved_run_replay,
        )
        resolved_selected_derivation = self._resolve_derivation(context)

        if resolved_selected_run is not None:
            resolved_latest_run = resolved_selected_run

        selected_run_bundle = self._ensure_selected_run_bundle(
            selected_run_bundle, resolved_selected_run
        )

        resolved_domain_id = self._infer_domain_id_from_workflow(
            resolved_domain_id, resolved_workflow
        )

        workflow_run_count = self._resolve_workflow_run_count(context, resolved_workflow)
        ui_context = _build_ui_context(context, resolved_domain_id)
        revision_history = self._resolve_revision_history(context, resolved_workflow)
        run_timeline = self._resolve_run_timeline(resolved_latest_run, resolved_run_replay)
        run_comparison = self._resolve_run_comparison_for_context(
            context=context,
            resolved_workflow=resolved_workflow,
            resolved_selected_run=resolved_selected_run,
            selected_run_bundle=selected_run_bundle,
        )
        template_assets = self._resolve_template_assets(resolved_workflow)
        policy_memory_records, legacy_knowledge_sources = self._resolve_policy_memory_records(
            context,
            resolved_workflow,
            resolved_selected_run,
        )
        starter_catalog = _build_starter_catalog(resolved_domain_id)
        output_review = build_output_review_context(
            bundle=selected_run_bundle,
            selected_run=resolved_selected_run,
            selected_artifact=resolved_selected_artifact,
            artifact_content=artifact_content,
            run_replay=resolved_run_replay,
        )
        business_tier_defaults = _resolve_business_tier_defaults(
            domain_id=resolved_domain_id,
            workflow=resolved_workflow,
        )
        resolved_context = self._assemble_resolved_context(
            context=context,
            resolved_domain_id=resolved_domain_id,
            resolved_workflow=resolved_workflow,
            resolved_latest_run=resolved_latest_run,
            resolved_selected_run=resolved_selected_run,
            resolved_selected_artifact=resolved_selected_artifact,
            resolved_selected_derivation=resolved_selected_derivation,
            resolved_run_replay=resolved_run_replay,
            artifact_content=artifact_content,
            ui_context=ui_context,
            revision_history=revision_history,
            run_timeline=run_timeline,
            run_comparison=run_comparison,
            template_assets=template_assets,
            starter_catalog=starter_catalog,
            policy_memory_records=policy_memory_records,
            legacy_knowledge_sources=legacy_knowledge_sources,
            output_review=output_review,
            business_tier_defaults=business_tier_defaults,
        )
        resolved_context["pending_assistant_proposals"] = (
            self._pending_assistant_proposals.to_dict()
        )
        workflow_seed = extract_workflow_seed(
            resolved_workflow.get("metadata") if isinstance(resolved_workflow, dict) else None
        )
        resolved_context["workflow_seed_summary"] = build_seed_summary(workflow_seed)
        resolved_context["workflow_readiness"] = self._resolve_workflow_readiness(
            resolved_workflow,
            resolved_context,
            workflow_run_count=workflow_run_count,
            construction_context=construction_context,
        )
        workflow_readiness = resolved_context["workflow_readiness"]
        readiness_issues = (
            workflow_readiness.get("readiness_issues")
            if isinstance(workflow_readiness, dict)
            else None
        )
        if isinstance(readiness_issues, list):
            resolved_context["readiness_issues"] = readiness_issues[:5]
        resolved_context["recommended_next_cta"] = compute_next_cta(resolved_context)
        resolved_context["assistant_pipeline_operations"] = (
            self._resolve_assistant_pipeline_operations(
                workflow_id=str(resolved_context.get("workflow_id") or "").strip() or None,
                thread_id=thread_id,
            )
        )

        return resolved_context

    def _ensure_selected_run_bundle(
        self,
        selected_run_bundle: Any | None,
        resolved_selected_run: dict[str, Any] | None,
    ) -> Any | None:
        if selected_run_bundle is not None or resolved_selected_run is None:
            return selected_run_bundle
        selected_run_id = _selected_run_id(resolved_selected_run)
        if not selected_run_id:
            return selected_run_bundle
        try:
            return self._repository.get_run_bundle(selected_run_id)
        except Exception as exc:
            logger.warning(
                "Failed to resolve run bundle %s (fallback): %s", selected_run_id, exc
            )
            return None

    @staticmethod
    def _infer_domain_id_from_workflow(
        resolved_domain_id: str | None,
        resolved_workflow: dict[str, Any] | None,
    ) -> str | None:
        if resolved_domain_id or not isinstance(resolved_workflow, dict):
            return resolved_domain_id
        return normalize_starter_domain_id(
            str(resolved_workflow.get("domain_id") or resolved_workflow.get("domain") or "")
        )

    def _resolve_run_comparison_for_context(
        self,
        *,
        context: ContextAttachment,
        resolved_workflow: dict[str, Any] | None,
        resolved_selected_run: dict[str, Any] | None,
        selected_run_bundle: Any | None,
    ) -> dict[str, Any] | None:
        if resolved_selected_run is not None:
            return self._resolve_selected_run_comparison(
                resolved_selected_run=resolved_selected_run,
                selected_run_bundle=selected_run_bundle,
                resolved_workflow=resolved_workflow,
            )
        return self._resolve_run_comparison(
            str((resolved_workflow or {}).get("workflow_id") or context.workflow_id or "").strip()
        )

    @staticmethod
    def _assemble_resolved_context(
        *,
        context: ContextAttachment,
        resolved_domain_id: str | None,
        resolved_workflow: dict[str, Any] | None,
        resolved_latest_run: dict[str, Any] | None,
        resolved_selected_run: dict[str, Any] | None,
        resolved_selected_artifact: dict[str, Any] | None,
        resolved_selected_derivation: dict[str, Any] | None,
        resolved_run_replay: dict[str, Any] | None,
        artifact_content: str | None,
        ui_context: dict[str, Any],
        revision_history: list[dict[str, Any]],
        run_timeline: list[dict[str, Any]],
        run_comparison: dict[str, Any] | None,
        template_assets: dict[str, str],
        starter_catalog: list[dict[str, Any]],
        policy_memory_records: list[dict[str, Any]],
        legacy_knowledge_sources: list[dict[str, Any]],
        output_review: dict[str, Any] | None,
        business_tier_defaults: dict[str, Any],
    ) -> dict[str, Any]:
        active_run = resolved_selected_run or resolved_latest_run
        active_run_is_dict = isinstance(active_run, dict)
        comparison_is_dict = isinstance(run_comparison, dict)
        active_workflow_id = (
            str((resolved_workflow or {}).get("workflow_id") or "").strip()
            or context.workflow_id
        )
        recent_runs = _filter_recent_runs(context.recent_runs, active_workflow_id)
        live_runs = [
            run
            for run in recent_runs
            if str(run.get("status") or "").lower()
            in {"running", "in_progress", "awaiting_operator", "waiting"}
        ]
        working_dir = _resolve_context_working_dir(context.working_dir, resolved_workflow)
        last_stage_context_hydration_report = (
            _extract_latest_stage_context_hydration_report(
                resolved_selected_run,
                resolved_latest_run,
                resolved_run_replay,
                run_timeline,
            )
        )
        return {
            "project_id": context.project_id,
            "working_dir": working_dir,
            "domain_id": resolved_domain_id or None,
            "workflow_id": (
                str((resolved_workflow or {}).get("workflow_id") or "").strip()
                or context.workflow_id
            ),
            "revision_id": context.revision_id,
            "workflow": resolved_workflow,
            "latest_run": resolved_latest_run,
            "selected_run": resolved_selected_run,
            "selected_artifact": resolved_selected_artifact,
            "selected_derivation": resolved_selected_derivation,
            "run_replay": resolved_run_replay,
            "artifact_content": artifact_content,
            "ui_context": ui_context,
            "safety_mode": context.safety_mode,
            "revision_history": revision_history,
            "run_timeline": run_timeline,
            "run_comparison": run_comparison,
            "run_outcome_summary": (
                (active_run or {}).get("outcome_summary") if active_run_is_dict else None
            ),
            "run_outcome_comparison": (
                run_comparison.get("outcome_comparison")
                if comparison_is_dict
                and isinstance(run_comparison.get("outcome_comparison"), dict)
                else None
            ),
            "run_optimization_summary": (
                (active_run or {}).get("optimization_summary") if active_run_is_dict else None
            ),
            "run_optimization_comparison": (
                run_comparison.get("optimization_comparison")
                if comparison_is_dict
                and isinstance(run_comparison.get("optimization_comparison"), dict)
                else None
            ),
            "template_assets": template_assets,
            "starter_catalog": starter_catalog,
            "knowledge_documents": legacy_knowledge_sources,
            "policy_memory_records": policy_memory_records,
            "legacy_knowledge_sources": legacy_knowledge_sources,
            "output_review": output_review,
            "recent_runs": recent_runs,
            "live_runs": live_runs,
            "last_stage_context_hydration_report": last_stage_context_hydration_report,
            **business_tier_defaults,
        }
