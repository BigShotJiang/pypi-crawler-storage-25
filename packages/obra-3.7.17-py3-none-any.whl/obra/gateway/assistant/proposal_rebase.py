"""Rebase strategy registry for assistant proposal apply.

Proposal apply owns a small rebase decision before execution: some action
records can safely move from the revision they were generated against to the
current workflow head, while others must fail as conflicts. This module is the
single registry for that decision. New proposal action ids register a strategy
in ``REBASE_REGISTRY``; unregistered ids resolve to ``NoneStrategy`` and do not
rebase.

The module deliberately avoids runtime imports from ``proposal_operations`` so
the apply path can import the registry without creating a cycle. Apply-path
types are imported only for type checking, and rewritten frozen refs are
created with ``dataclasses.replace``.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, replace
from typing import TYPE_CHECKING, Any, Literal, Protocol

from obra.workflow.stage_instruction_assets import (
    PRIMARY_STAGE_INSTRUCTION_ROLE,
    canonicalize_template_role,
    resolve_primary_stage_instruction,
)

if TYPE_CHECKING:
    from obra.gateway.assistant.proposal_operations import (
        ProposalOperationRecordRef,
        WorkflowRevisionResolver,
    )


@dataclass(frozen=True, slots=True)
class RebaseOutcome:
    """Strategy result consumed by ``apply_proposal_operation``."""

    kind: Literal["noop", "rebased", "conflict"]
    conflict_summary: dict[str, Any] | None = None
    rebased_refs: list[ProposalOperationRecordRef] | None = None
    current_revision_id: str = ""

    @classmethod
    def noop(cls, current_revision_id: str = "") -> RebaseOutcome:
        return cls(kind="noop", current_revision_id=current_revision_id)

    @classmethod
    def rebased(
        cls,
        refs: list[ProposalOperationRecordRef],
        current_revision_id: str,
    ) -> RebaseOutcome:
        return cls(
            kind="rebased",
            rebased_refs=refs,
            current_revision_id=current_revision_id,
        )

    @classmethod
    def conflict(
        cls,
        summary: dict[str, Any],
        current_revision_id: str = "",
    ) -> RebaseOutcome:
        return cls(
            kind="conflict",
            conflict_summary=summary,
            current_revision_id=current_revision_id,
        )


class RebaseStrategy(Protocol):
    """Action-id-specific proposal rebase behavior."""

    def maybe_rebase(
        self,
        refs: list[ProposalOperationRecordRef],
        *,
        current_workflow: Mapping[str, Any] | None,
        current_revision_id: str,
        resolve_workflow_revision: WorkflowRevisionResolver,
    ) -> RebaseOutcome:
        """Return whether refs should be rebased, rejected, or left unchanged."""


class NoneStrategy:
    """Default-deny fallback for action ids without registered rebase support."""

    def maybe_rebase(
        self,
        refs: list[ProposalOperationRecordRef],
        *,
        current_workflow: Mapping[str, Any] | None,
        current_revision_id: str,
        resolve_workflow_revision: WorkflowRevisionResolver,
    ) -> RebaseOutcome:
        return RebaseOutcome.noop(current_revision_id=current_revision_id)


class CoordinateOnlyStrategy:
    """Rebase refs when their target template content is unchanged."""

    def maybe_rebase(
        self,
        refs: list[ProposalOperationRecordRef],
        *,
        current_workflow: Mapping[str, Any] | None,
        current_revision_id: str,
        resolve_workflow_revision: WorkflowRevisionResolver,
    ) -> RebaseOutcome:
        if not current_revision_id or not isinstance(current_workflow, Mapping):
            return RebaseOutcome.conflict(
                {
                    "reason": "template_rebase_unavailable",
                    "message": "The current workflow revision could not be resolved before applying proposed template edits.",
                },
                current_revision_id=current_revision_id,
            )

        conflicts: list[dict[str, Any]] = []
        for ref in refs:
            expected_revision_id = _normalize(ref.action_inputs.get("expected_revision_id"))
            if not expected_revision_id or expected_revision_id == current_revision_id:
                continue
            workflow_id = _normalize(ref.workflow_id) or _normalize(
                ref.action_inputs.get("workflow_id")
            )
            base_workflow = (
                resolve_workflow_revision(workflow_id, expected_revision_id)
                if workflow_id
                else None
            )
            if not isinstance(base_workflow, Mapping):
                conflicts.append(
                    {
                        "stage_id": _normalize(ref.action_inputs.get("stage_id")),
                        "template_role": _normalize(ref.action_inputs.get("template_role")),
                        "base_revision_id": expected_revision_id,
                        "current_revision_id": current_revision_id,
                        "reason": "base_revision_unavailable",
                    }
                )
                continue
            stage_id = _normalize(ref.action_inputs.get("stage_id"))
            template_role = canonicalize_template_role(
                _normalize(ref.action_inputs.get("template_role"))
            )
            base_content = _workflow_template_content(base_workflow, stage_id, template_role)
            current_content = _workflow_template_content(
                current_workflow,
                stage_id,
                template_role,
            )
            if base_content != current_content:
                conflicts.append(
                    {
                        "stage_id": stage_id,
                        "template_role": template_role,
                        "base_revision_id": expected_revision_id,
                        "current_revision_id": current_revision_id,
                        "reason": "target_template_changed",
                    }
                )

        if conflicts:
            return RebaseOutcome.conflict(
                {
                    "reason": "template_rebase_overlap",
                    "message": "One or more proposed template edits target content that changed on the latest workflow revision.",
                    "conflicts": conflicts,
                },
                current_revision_id=current_revision_id,
            )

        rebased_refs: list[ProposalOperationRecordRef] = []
        rewritten = False
        for ref in refs:
            action_inputs = dict(ref.action_inputs)
            if _normalize(action_inputs.get("expected_revision_id")) != current_revision_id:
                action_inputs["expected_revision_id"] = current_revision_id
                rewritten = True
            rebased_refs.append(replace(ref, action_inputs=action_inputs))
        if not rewritten:
            return RebaseOutcome.noop(current_revision_id=current_revision_id)
        return RebaseOutcome.rebased(refs=rebased_refs, current_revision_id=current_revision_id)


class ReplayAndValidateStrategy:
    """Placeholder for structural proposal rebasing."""

    def maybe_rebase(
        self,
        refs: list[ProposalOperationRecordRef],
        *,
        current_workflow: Mapping[str, Any] | None,
        current_revision_id: str,
        resolve_workflow_revision: WorkflowRevisionResolver,
    ) -> RebaseOutcome:
        raise NotImplementedError(
            "ReplayAndValidateStrategy is registered as a placeholder for structural proposals but no body is wired yet. Bind a concrete implementation in REBASE_REGISTRY before using this strategy."
        )


def resolve_strategy(action_id: str) -> RebaseStrategy:
    """Return the rebase strategy registered for ``action_id``."""

    return REBASE_REGISTRY.get(action_id, NONE_STRATEGY)


def _workflow_template_content(
    workflow: Mapping[str, Any],
    stage_id: str | None,
    template_role: str,
) -> str | None:
    definition = workflow.get("workflow_definition")
    definition_map = definition if isinstance(definition, Mapping) else {}
    if stage_id is None:
        templates = definition_map.get("templates")
        if isinstance(templates, Mapping):
            value = templates.get(template_role)
            return str(value) if value is not None else None
        return None

    stages = definition_map.get("stages")
    if not isinstance(stages, list):
        return None
    stage = next(
        (
            item
            for item in stages
            if isinstance(item, Mapping)
            and _normalize(item.get("id") or item.get("stage_id")) == stage_id
        ),
        None,
    )
    if stage is None:
        return None
    if template_role == PRIMARY_STAGE_INSTRUCTION_ROLE:
        workflow_id = _normalize(workflow.get("workflow_id")) or _normalize(
            definition_map.get("workflow_id")
        )
        resolution = resolve_primary_stage_instruction(
            stage,
            workflow_id,
            None,
            domain_id=_normalize(workflow.get("domain_id"))
            or _normalize(definition_map.get("domain_id"))
            or "business",
        )
        return resolution.content
    template_bindings = stage.get("template_bindings")
    if isinstance(template_bindings, list):
        for binding in template_bindings:
            if isinstance(binding, Mapping) and binding.get("role") == template_role:
                content = binding.get("content")
                return str(content) if content is not None else ""
    value = stage.get(template_role)
    return str(value) if value is not None else None


def _normalize(value: Any) -> str | None:
    normalized = str(value or "").strip()
    return normalized or None


NONE_STRATEGY = NoneStrategy()
COORDINATE_ONLY_STRATEGY = CoordinateOnlyStrategy()
REPLAY_AND_VALIDATE_STRATEGY = ReplayAndValidateStrategy()
REBASE_REGISTRY: dict[str, RebaseStrategy] = {
    "execute_template_edit": COORDINATE_ONLY_STRATEGY,
}
