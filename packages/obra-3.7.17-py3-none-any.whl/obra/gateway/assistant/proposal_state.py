"""Summarize pending assistant proposal records for launch gating."""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass
from typing import Any, Mapping

from obra.gateway.assistant.proposal_operations import (
    ProposalOperation,
    proposal_operation_id_for_records,
)
from obra.gateway.workflow_studio.assistant_runnability_gate import (
    PendingAssistantProposalSummary,
)
from obra.workflow.readiness import ApplySummary
from obra.workflow.stage_instruction_assets import (
    PRIMARY_STAGE_INSTRUCTION_ROLE,
    canonicalize_template_role,
)

_MAX_GROUP_STAGE_IDS = 50
_MAX_GROUP_RECORD_INDEXES = 50


@dataclass(frozen=True, slots=True)
class _PendingRecordRef:
    record: Mapping[str, Any]
    source_thread_id: str | None
    source_turn_id: str | None
    source_record_index: int | None


def summarize_pending_assistant_proposals(
    turns: Iterable[Any] | None = None,
    workflow_id: str | None = None,
    *,
    operations: Iterable[ProposalOperation] | None = None,
    draft_assets: Iterable[Any] | None = None,
) -> PendingAssistantProposalSummary:
    """Return compact counts for pending template proposals from operations."""
    del draft_assets
    normalized_workflow_id = str(workflow_id or "").strip()
    pending_count = 0
    pending_template_count = 0
    pending_stage_instruction_count = 0
    pending_action_ids: list[str] = []
    proposal_groups: list[str] = []
    group_details_by_id: dict[str, dict[str, Any]] = {}

    if operations is None:
        for record_ref in _iter_pending_records(turns or []):
            record = record_ref.record
            if normalized_workflow_id and not _record_matches_workflow(record, normalized_workflow_id):
                continue
            action_id = str(record.get("action_id") or "").strip()
            template_roles = _template_roles_for_record(record)
            if not template_roles:
                continue
            pending_count += 1
            pending_template_count += 1
            if any(
                canonicalize_template_role(role) == PRIMARY_STAGE_INSTRUCTION_ROLE
                for role in template_roles
            ):
                pending_stage_instruction_count += 1
                _update_group_details(
                    group_details_by_id,
                    record,
                    record_ref,
                )
            if action_id:
                pending_action_ids.append(action_id)
            group = str(record.get("proposal_group") or "").strip()
            if group and group not in proposal_groups:
                proposal_groups.append(group)

    operation_items = list(operations or [])
    for operation in operation_items:
        if normalized_workflow_id and str(operation.workflow_id or "").strip() != normalized_workflow_id:
            continue
        if operation.status != "pending":
            continue
        pending_count += len(operation.source_refs)
        pending_template_count += len(operation.source_refs)
        pending_stage_instruction_count += len(operation.source_refs)
        for ref in operation.source_refs:
            if ref.action_id and ref.action_id not in pending_action_ids:
                pending_action_ids.append(ref.action_id)
        if operation.proposal_group and operation.proposal_group not in proposal_groups:
            proposal_groups.append(operation.proposal_group)
        detail = group_details_by_id.setdefault(
            operation.proposal_group or operation.operation_id,
            {
                "group_id": operation.proposal_group or operation.operation_id,
                "proposal_operation_id": operation.operation_id,
                "pending_count": 0,
                "pending_stage_ids": [],
                "source_thread_id": operation.thread_id or None,
                "source_turn_id": operation.turn_id or None,
                "source_record_indexes": [],
            },
        )
        detail["pending_count"] = int(detail.get("pending_count") or 0) + len(operation.source_refs)
        for ref in operation.source_refs:
            source_indexes = detail.get("source_record_indexes")
            if isinstance(source_indexes, list) and len(source_indexes) < _MAX_GROUP_RECORD_INDEXES:
                source_indexes.append(ref.source_record_index)
            pending_stage_ids = detail.get("pending_stage_ids")
            if (
                isinstance(pending_stage_ids, list)
                and len(pending_stage_ids) < _MAX_GROUP_STAGE_IDS
            ):
                for stage_id in ref.stage_ids:
                    if (
                        stage_id not in pending_stage_ids
                        and len(pending_stage_ids) < _MAX_GROUP_STAGE_IDS
                    ):
                        pending_stage_ids.append(stage_id)

    return PendingAssistantProposalSummary(
        pending_count=pending_count,
        pending_template_count=pending_template_count,
        pending_stage_instruction_count=pending_stage_instruction_count,
        pending_action_ids=pending_action_ids,
        proposal_groups=proposal_groups,
        proposal_group_details=_public_group_details(group_details_by_id),
    )


def compute_apply_summary(
    turns: Iterable[Any] | None = None,
    workflow_id: str | None = None,
    *,
    operations: Iterable[ProposalOperation] | None = None,
    draft_assets: Iterable[Any] | None = None,
    operation: ProposalOperation | None = None,
) -> ApplySummary | None:
    """Return a compact summary of the latest proposal apply state."""
    del turns, draft_assets
    operation_list = list(operations or [])
    if workflow_id:
        operation_list = [
            item
            for item in operation_list
            if str(item.workflow_id or "").strip() == str(workflow_id or "").strip()
        ]
    if operation is not None:
        operation_list = [op for op in operation_list if op.operation_id != operation.operation_id]
        operation_list.append(operation)
    if not operation_list:
        return None
    latest = sorted(
        operation_list,
        key=lambda item: (
            1 if item.last_attempt and item.last_attempt.created_at else 0,
            item.last_attempt.created_at if item.last_attempt else "",
            item.operation_id,
        ),
    )[-1]
    applied_count = sum(1 for ref in latest.source_refs if ref.status in {"applied", "accepted"})
    pending_count = sum(1 for ref in latest.source_refs if ref.status in {"pending", "partial"})
    failed_count = sum(
        1 for ref in latest.source_refs if ref.status in {"failed", "invalid", "conflict"}
    )
    if latest.status == "applied" and applied_count == 0:
        applied_count = len(latest.source_refs)
    elif latest.status == "partial" and applied_count == 0:
        results = (
            latest.last_attempt.response.get("results")
            if latest.last_attempt and latest.last_attempt.response
            else None
        )
        if isinstance(results, list):
            applied_count = sum(
                1
                for result in results
                if isinstance(result, Mapping)
                and str(result.get("outcome") or "").strip().lower() == "applied"
            )
            pending_count = max(0, len(latest.source_refs) - applied_count)
    return ApplySummary(
        status=latest.status,
        operation_id=latest.operation_id,
        applied_count=applied_count,
        pending_count=pending_count,
        failed_count=failed_count,
        last_error=latest.last_error,
    )


def _iter_pending_records(turns: Iterable[Any]) -> Iterable[_PendingRecordRef]:
    for turn in turns:
        source_thread_id = _turn_value(turn, "thread_id")
        source_turn_id = _turn_value(turn, "turn_id")
        records = (
            turn.get("action_records")
            if isinstance(turn, Mapping)
            else getattr(turn, "action_records", None)
        )
        if not isinstance(records, list):
            continue
        for index, record in enumerate(records):
            if isinstance(record, Mapping) and str(record.get("status") or "").strip() == "pending":
                yield _PendingRecordRef(
                    record=record,
                    source_thread_id=source_thread_id,
                    source_turn_id=source_turn_id,
                    source_record_index=index,
                )


def _record_matches_workflow(record: Mapping[str, Any], workflow_id: str) -> bool:
    candidates = [
        record.get("workflow_id"),
        _mapping_value(record.get("action_inputs"), "workflow_id"),
    ]
    if any(str(candidate or "").strip() == workflow_id for candidate in candidates):
        return True
    operations = _mapping_value(record.get("action_inputs"), "operations")
    if isinstance(operations, list):
        return any(
            isinstance(operation, Mapping)
            and str(operation.get("workflow_id") or "").strip() == workflow_id
            for operation in operations
        )
    return not any(str(candidate or "").strip() for candidate in candidates)


def _template_roles_for_record(record: Mapping[str, Any]) -> list[str]:
    action_id = str(record.get("action_id") or "").strip()
    action_inputs = record.get("action_inputs")
    if action_id == "execute_template_edit":
        role = _mapping_value(action_inputs, "template_role") or record.get("template_role")
        return [str(role or "purpose")]
    if action_id != "execute_batch_mutation":
        return []
    operations = _mapping_value(action_inputs, "operations")
    if not isinstance(operations, list):
        operations = record.get("operations")
    if not isinstance(operations, list):
        return []
    roles: list[str] = []
    for operation in operations:
        if not isinstance(operation, Mapping):
            continue
        if str(operation.get("operation") or operation.get("op") or "").strip() != "edit_template":
            continue
        roles.append(str(operation.get("template_role") or "purpose"))
    return roles


def _stage_ids_for_record(record: Mapping[str, Any]) -> list[str]:
    action_id = str(record.get("action_id") or "").strip()
    action_inputs = record.get("action_inputs")
    if action_id == "execute_template_edit":
        stage_id = _mapping_value(action_inputs, "stage_id") or record.get("stage_id")
        normalized = str(stage_id or "").strip()
        return [normalized] if normalized else []
    if action_id != "execute_batch_mutation":
        return []
    operations = _mapping_value(action_inputs, "operations")
    if not isinstance(operations, list):
        operations = record.get("operations")
    if not isinstance(operations, list):
        return []
    stage_ids: list[str] = []
    for operation in operations:
        if not isinstance(operation, Mapping):
            continue
        if str(operation.get("operation") or operation.get("op") or "").strip() != "edit_template":
            continue
        if (
            canonicalize_template_role(str(operation.get("template_role") or "purpose"))
            != PRIMARY_STAGE_INSTRUCTION_ROLE
        ):
            continue
        stage_id = str(operation.get("stage_id") or "").strip()
        if stage_id and stage_id not in stage_ids:
            stage_ids.append(stage_id)
    return stage_ids


def _update_group_details(
    group_details_by_id: dict[str, dict[str, Any]],
    record: Mapping[str, Any],
    record_ref: _PendingRecordRef,
) -> None:
    group_id = str(record.get("proposal_group") or "").strip()
    if not group_id:
        group_id = str(record_ref.source_turn_id or "ungrouped").strip() or "ungrouped"
    detail = group_details_by_id.setdefault(
        group_id,
        {
            "group_id": group_id,
            "proposal_operation_id": _record_operation_id(
                record,
                record_ref=record_ref,
                group_id=group_id,
                source_record_indexes=(
                    [record_ref.source_record_index]
                    if record_ref.source_record_index is not None
                    else []
                ),
                records=[record],
            ),
            "pending_count": 0,
            "pending_stage_ids": [],
            "source_thread_id": record_ref.source_thread_id,
            "source_turn_id": record_ref.source_turn_id,
            "source_record_indexes": [],
            "_proposal_operation_records": [],
        },
    )
    detail["pending_count"] = int(detail.get("pending_count") or 0) + 1
    operation_records = detail.get("_proposal_operation_records")
    if isinstance(operation_records, list):
        operation_records.append(record)
    pending_stage_ids = detail["pending_stage_ids"]
    if isinstance(pending_stage_ids, list) and len(pending_stage_ids) < _MAX_GROUP_STAGE_IDS:
        for stage_id in _stage_ids_for_record(record):
            if stage_id not in pending_stage_ids and len(pending_stage_ids) < _MAX_GROUP_STAGE_IDS:
                pending_stage_ids.append(stage_id)
    source_indexes = detail["source_record_indexes"]
    if (
        isinstance(source_indexes, list)
        and record_ref.source_record_index is not None
        and len(source_indexes) < _MAX_GROUP_RECORD_INDEXES
    ):
        source_indexes.append(record_ref.source_record_index)
        detail["proposal_operation_id"] = _record_operation_id(
            record,
            record_ref=record_ref,
            group_id=group_id,
            source_record_indexes=source_indexes,
            records=operation_records if isinstance(operation_records, list) else [record],
        )


def _public_group_details(details: dict[str, dict[str, Any]]) -> list[dict[str, Any]]:
    public_details: list[dict[str, Any]] = []
    for detail in details.values():
        public_detail = dict(detail)
        public_detail.pop("_proposal_operation_records", None)
        public_details.append(public_detail)
    return public_details


def _record_operation_id(
    record: Mapping[str, Any],
    *,
    record_ref: _PendingRecordRef,
    group_id: str,
    source_record_indexes: Iterable[int | None],
    records: Iterable[Mapping[str, Any]],
) -> str:
    explicit = str(record.get("proposal_operation_id") or "").strip()
    if explicit:
        return explicit
    return proposal_operation_id_for_records(
        workflow_id=_record_workflow_id(record),
        thread_id=record_ref.source_thread_id,
        turn_id=record_ref.source_turn_id,
        proposal_group=group_id,
        source_record_indexes=source_record_indexes,
        records=records,
    )


def _turn_value(turn: Any, key: str) -> str | None:
    value = turn.get(key) if isinstance(turn, Mapping) else getattr(turn, key, None)
    normalized = str(value or "").strip()
    return normalized or None


def _mapping_value(value: Any, key: str) -> Any:
    return value.get(key) if isinstance(value, Mapping) else None


def _record_workflow_id(record: Mapping[str, Any]) -> str | None:
    workflow_id = _mapping_value(record.get("action_inputs"), "workflow_id") or record.get(
        "workflow_id"
    )
    normalized = str(workflow_id or "").strip()
    return normalized or None
