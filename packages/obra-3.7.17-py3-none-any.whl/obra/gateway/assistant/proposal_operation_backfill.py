"""Backfill projected proposal operations into the durable operation store."""

from __future__ import annotations

import json
import logging
from dataclasses import asdict, dataclass, replace
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from obra.gateway.assistant.proposal_operation_writer import ProposalOperationWriter
from obra.gateway.assistant.proposal_operations import (
    ProposalOperation,
    _project_proposal_operations_from_draft_assets,
    _project_proposal_operations_from_turns,
)
from obra.gateway.workflow_studio.assistant_repository import AssistantRepository
from obra.gateway.workflow_studio.template_asset_store_resolver import resolve_template_asset_store
from obra.utils.obra_home import get_runtime_dir
from obra.workflow.template_asset_store import TemplateAssetStore

logger = logging.getLogger(__name__)
MARKER_PATH = get_runtime_dir() / "assistant" / ".proposal_operation_backfill_complete"


@dataclass(frozen=True, slots=True)
class BackfillReport:
    """Result of one proposal operation backfill run."""

    operations_written: int
    operations_skipped: int
    discrepancies_logged: int
    validation_passed: bool

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def run_backfill(
    repository: AssistantRepository,
    asset_store: TemplateAssetStore,
    writer: ProposalOperationWriter,
) -> BackfillReport:
    """Project existing turns/assets into the durable proposal operation store."""
    turns = [
        turn
        for thread in repository.list_all_threads()
        for turn in repository.list_turns(thread.thread_id)
    ]
    operations_by_id: dict[str, ProposalOperation] = {}
    discrepancies_logged = 0
    for operation in _project_proposal_operations_from_turns(turns):
        operations_by_id[operation.operation_id] = operation
    for operation in _project_proposal_operations_from_draft_assets(asset_store.list_proposed_assets()):
        existing = operations_by_id.get(operation.operation_id)
        if existing is None:
            operations_by_id[operation.operation_id] = operation
            continue
        merged_ref_keys = {
            (ref.thread_id, ref.turn_id, ref.source_record_index)
            for ref in existing.source_refs
        }
        merged_refs = [
            *existing.source_refs,
            *[
                ref
                for ref in operation.source_refs
                if (ref.thread_id, ref.turn_id, ref.source_record_index) not in merged_ref_keys
            ],
        ]
        operations_by_id[operation.operation_id] = replace(existing, source_refs=merged_refs)

    written = 0
    skipped = 0
    for operation in operations_by_id.values():
        if writer.store.get(operation.operation_id) is not None:
            logger.info("Proposal operation already backfilled: %s", operation.operation_id)
            skipped += 1
            continue
        writer.create(operation)
        written += 1

    validation_passed = all(
        writer.store.get(operation_id) is not None for operation_id in operations_by_id
    )
    return BackfillReport(
        operations_written=written,
        operations_skipped=skipped,
        discrepancies_logged=discrepancies_logged,
        validation_passed=validation_passed,
    )


def run_startup_backfill(app_state: object, *, marker_path: Path | None = None) -> BackfillReport | None:
    """Run the one-shot startup backfill when the marker is absent."""
    marker = marker_path or MARKER_PATH
    if marker.exists():
        return None
    repository = AssistantRepository.from_request(_request_like(app_state))
    asset_store = resolve_template_asset_store(app_state)
    writer = ProposalOperationWriter.from_app_state(app_state)
    report = run_backfill(repository, asset_store, writer)
    if report.validation_passed:
        marker.parent.mkdir(parents=True, exist_ok=True)
        marker.write_text(
            json.dumps(
                {
                    "completed_at": datetime.now(tz=timezone.utc).isoformat(),
                    "operations_written": report.operations_written,
                    "operations_skipped": report.operations_skipped,
                },
                indent=2,
                sort_keys=True,
            ),
            encoding="utf-8",
        )
    else:
        logger.error("Proposal operation backfill validation failed: %s", report.to_dict())
    return report


class _App:
    def __init__(self, state: object) -> None:
        self.state = state


class _Request:
    def __init__(self, state: object) -> None:
        self.app = _App(state)


def _request_like(app_state: object) -> Any:
    return _Request(app_state)
