"""Shared shapes for assistant action batch execution."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True, slots=True)
class ActionBatchRecord:
    """One persisted proposal record prepared for batch execution."""

    source_record_index: int
    action_id: str
    action_inputs: dict[str, Any] = field(default_factory=dict)
    workflow_id: str | None = None
    expected_revision_id: str | None = None
    working_dir: str | None = None


@dataclass(frozen=True, slots=True)
class ActionBatchRequest:
    """Batch execution request independent of HTTP route models."""

    thread_id: str
    turn_id: str
    safety_mode: str
    records: list[ActionBatchRecord]
    working_dir: str | None = None


def compute_batch_overall_outcome(results: list[dict[str, Any]]) -> str:
    """Return the aggregate outcome string for per-action batch results."""
    if not results:
        return "applied"
    first_non_applied = next(
        (result for result in results if str(result.get("outcome") or "") != "applied"),
        None,
    )
    if first_non_applied is None:
        return "applied"
    if first_non_applied is results[0]:
        return str(first_non_applied.get("outcome") or "invalid")
    return "partial"
