"""Workflow-scoped proposal operation projection and lifecycle helpers."""

from __future__ import annotations

import hashlib
import json
from collections.abc import Awaitable, Callable, Iterable
from dataclasses import asdict, dataclass, field, replace
from datetime import datetime, timezone
from typing import Any, Literal, Mapping

from obra.gateway.assistant.action_batch_execution import ActionBatchRecord
from obra.gateway.assistant.proposal_rebase import (
    NONE_STRATEGY,
    resolve_strategy,
)

ProposalOperationStatus = Literal[
    "pending",
    "applying",
    "failed",
    "invalid",
    "conflict",
    "partial",
    "applied",
    "rejected",
]

_RETRYABLE_STATUSES = {"pending", "failed", "invalid", "conflict", "partial"}
_EXECUTABLE_ACTION_PREFIXES = ("execute_",)


@dataclass(frozen=True, slots=True)
class ProposalOperationRecordRef:
    """Reference to one source action record inside assistant history."""

    thread_id: str
    turn_id: str
    source_record_index: int
    action_id: str
    action_inputs: dict[str, Any]
    workflow_id: str | None
    status: str
    proposal_group: str | None = None
    preview_type: str | None = None
    stage_ids: list[str] = field(default_factory=list)
    resulting_revision_ref: Any = None
    audit_id: str | None = None
    draft_backed: bool = False
    conflict_summary: dict[str, Any] | None = None
    last_error: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class ProposalOperationAttempt:
    """One apply attempt recorded on proposal source records."""

    attempt_id: str
    status: ProposalOperationStatus
    created_at: str
    idempotency_key: str | None = None
    error_detail: str | None = None
    conflict_summary: dict[str, Any] | None = None
    resulting_revision_ref: Any = None
    response: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class ProposalOperation:
    """A durable workflow-level operation projected from assistant proposals."""

    operation_id: str
    workflow_id: str | None
    thread_id: str
    turn_id: str
    proposal_group: str | None
    status: ProposalOperationStatus
    source_refs: list[ProposalOperationRecordRef]
    attempt_count: int = 0
    last_attempt: ProposalOperationAttempt | None = None
    last_error: str | None = None
    conflict_summary: dict[str, Any] | None = None
    resulting_revision_ref: Any = None
    preview_summary: str | None = None
    stage_ids: list[str] = field(default_factory=list)
    created_at: str = ""
    updated_at: str = ""
    attempt_history: list[ProposalOperationAttempt] = field(default_factory=list)
    created_by: str | None = None

    def to_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["source_refs"] = [ref.to_dict() for ref in self.source_refs]
        payload["last_attempt"] = (
            self.last_attempt.to_dict() if self.last_attempt is not None else None
        )
        payload["attempt_history"] = [attempt.to_dict() for attempt in self.attempt_history]
        return payload


ProposalBatchExecutor = Callable[
    [str, str, str, str | None, list[ActionBatchRecord]],
    Awaitable[dict[str, Any]],
]
WorkflowRevisionResolver = Callable[[str, str], Mapping[str, Any] | None]
CurrentWorkflowResolver = Callable[[str], Mapping[str, Any] | None]


def _project_proposal_operations_from_turns(
    turns: Iterable[Any],
    workflow_id: str | None = None,
) -> list[ProposalOperation]:
    """Project assistant turns into deterministic proposal operations."""
    normalized_workflow_id = _normalize(workflow_id)
    grouped: dict[
        tuple[str, str, str], list[tuple[Mapping[str, Any], ProposalOperationRecordRef]]
    ] = {}
    for turn in turns:
        thread_id = _turn_value(turn, "thread_id")
        turn_id = _turn_value(turn, "turn_id")
        if not thread_id or not turn_id:
            continue
        records = (
            turn.get("action_records")
            if isinstance(turn, Mapping)
            else getattr(turn, "action_records", None)
        )
        if not isinstance(records, list):
            continue
        for index, record in enumerate(records):
            if not isinstance(record, Mapping) or not _is_proposal_record(record):
                continue
            record_workflow_id = _record_workflow_id(record)
            if normalized_workflow_id and not _record_matches_workflow(
                record,
                normalized_workflow_id,
            ):
                continue
            ref = _record_ref(
                record,
                thread_id=thread_id,
                turn_id=turn_id,
                source_record_index=index,
                workflow_id=record_workflow_id,
            )
            group_key = ref.proposal_group or f"record-{index}"
            grouped.setdefault((thread_id, turn_id, group_key), []).append((record, ref))

    operations = [
        _build_operation(records, refs, group_key=group_key)
        for (_thread_id, _turn_id, group_key), pairs in grouped.items()
        for records, refs in [([pair[0] for pair in pairs], [pair[1] for pair in pairs])]
    ]
    return sorted(
        operations,
        key=lambda operation: (
            _status_sort_key(operation.status),
            operation.thread_id,
            operation.turn_id,
            operation.operation_id,
        ),
    )


def _project_proposal_operations_from_draft_assets(
    draft_assets: Iterable[Any],
    workflow_id: str | None = None,
) -> list[ProposalOperation]:
    """Project proposed template assets into workflow-scoped operations."""
    normalized_workflow_id = _normalize(workflow_id)
    grouped: dict[str, list[ProposalOperationRecordRef]] = {}
    for fallback_index, draft in enumerate(draft_assets):
        draft_payload = draft.to_dict() if hasattr(draft, "to_dict") else dict(draft)
        draft_workflow_id = _normalize(draft_payload.get("workflow_id"))
        if normalized_workflow_id and draft_workflow_id != normalized_workflow_id:
            continue
        operation_id = _normalize(draft_payload.get("operation_id"))
        if not operation_id:
            operation_id = proposal_operation_id_for_records(
                workflow_id=draft_workflow_id,
                thread_id="",
                turn_id="",
                proposal_group=_normalize(draft_payload.get("proposal_group")),
                source_record_indexes=[_draft_source_record_index(draft_payload, fallback_index)],
                records=[_draft_record_payload(draft_payload)],
            )
        grouped.setdefault(operation_id, []).append(
            _draft_record_ref(
                draft_payload,
                source_record_index=_draft_source_record_index(draft_payload, fallback_index),
            )
        )

    operations: list[ProposalOperation] = []
    for operation_id, refs in grouped.items():
        workflow_id_for_operation = next((ref.workflow_id for ref in refs if ref.workflow_id), None)
        proposal_group = next((ref.proposal_group for ref in refs if ref.proposal_group), None)
        stage_ids: list[str] = []
        for ref in refs:
            for stage_id in ref.stage_ids:
                if stage_id not in stage_ids:
                    stage_ids.append(stage_id)
        operations.append(
            ProposalOperation(
                operation_id=operation_id,
                workflow_id=workflow_id_for_operation,
                thread_id=_draft_metadata_value(refs[0], "thread_id") or "",
                turn_id=_draft_metadata_value(refs[0], "turn_id") or "",
                proposal_group=proposal_group,
                status="pending",
                source_refs=refs,
                preview_summary=_preview_summary(refs),
                stage_ids=stage_ids,
                created_at=_draft_metadata_value(refs[0], "created_at") or "",
                updated_at=_draft_metadata_value(refs[0], "updated_at") or "",
                created_by=_draft_metadata_value(refs[0], "created_by")
                or _draft_metadata_value(refs[0], "user_id")
                or "current-user",
            )
        )
    return sorted(
        operations,
        key=lambda operation: (
            _status_sort_key(operation.status),
            operation.operation_id,
        ),
    )


def proposal_operation_id_for_records(
    *,
    workflow_id: str | None,
    thread_id: str | None,
    turn_id: str | None,
    proposal_group: str | None,
    source_record_indexes: Iterable[int | None],
    records: Iterable[Mapping[str, Any]],
) -> str:
    """Build the deterministic id used by operation projection."""
    normalized_indexes = [
        int(index) for index in source_record_indexes if isinstance(index, int) and index >= 0
    ]
    identity = {
        "workflow_id": _normalize(workflow_id),
        "thread_id": _normalize(thread_id),
        "turn_id": _normalize(turn_id),
        "proposal_group": _normalize(proposal_group),
        "source_record_indexes": normalized_indexes,
        "records": [
            {
                "action_id": str(record.get("action_id") or ""),
                "action_inputs": record.get("action_inputs") or {},
            }
            for record in records
        ],
    }
    digest = hashlib.sha1(
        json.dumps(identity, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")
    ).hexdigest()[:16]
    return f"proposal-{digest}"


def find_proposal_operation(
    turns: Iterable[Any],
    operation_id: str,
) -> ProposalOperation | None:
    """Return a projected operation by deterministic id."""
    normalized_operation_id = _normalize(operation_id)
    if not normalized_operation_id:
        return None
    for operation in _project_proposal_operations_from_turns(turns):
        if operation.operation_id == normalized_operation_id:
            return operation
    return None


def proposal_operation_from_dict(payload: Mapping[str, Any]) -> ProposalOperation:
    """Deserialize one stored proposal operation payload."""
    source_refs = [
        proposal_operation_record_ref_from_dict(ref)
        for ref in payload.get("source_refs", [])
        if isinstance(ref, Mapping)
    ]
    attempt_history = [
        proposal_operation_attempt_from_dict(attempt)
        for attempt in payload.get("attempt_history", [])
        if isinstance(attempt, Mapping)
    ]
    last_attempt_payload = payload.get("last_attempt")
    last_attempt = (
        proposal_operation_attempt_from_dict(last_attempt_payload)
        if isinstance(last_attempt_payload, Mapping)
        else (attempt_history[-1] if attempt_history else None)
    )
    return ProposalOperation(
        operation_id=str(payload.get("operation_id") or ""),
        workflow_id=_normalize(payload.get("workflow_id")) or None,
        thread_id=str(payload.get("thread_id") or ""),
        turn_id=str(payload.get("turn_id") or ""),
        proposal_group=_normalize(payload.get("proposal_group")),
        status=_coerce_operation_status(payload.get("status")),
        source_refs=source_refs,
        attempt_count=int(payload.get("attempt_count") or len(attempt_history)),
        last_attempt=last_attempt,
        last_error=_normalize(payload.get("last_error")),
        conflict_summary=payload.get("conflict_summary")
        if isinstance(payload.get("conflict_summary"), dict)
        else None,
        resulting_revision_ref=payload.get("resulting_revision_ref"),
        preview_summary=_normalize(payload.get("preview_summary")),
        stage_ids=[
            str(stage_id)
            for stage_id in payload.get("stage_ids", [])
            if str(stage_id or "").strip()
        ],
        created_at=str(payload.get("created_at") or ""),
        updated_at=str(payload.get("updated_at") or ""),
        attempt_history=attempt_history,
        created_by=_normalize(payload.get("created_by")),
    )


def proposal_operation_record_ref_from_dict(
    payload: Mapping[str, Any],
) -> ProposalOperationRecordRef:
    """Deserialize one stored proposal operation source reference."""
    return ProposalOperationRecordRef(
        thread_id=str(payload.get("thread_id") or ""),
        turn_id=str(payload.get("turn_id") or ""),
        source_record_index=int(payload.get("source_record_index") or 0),
        action_id=str(payload.get("action_id") or ""),
        action_inputs=dict(payload.get("action_inputs") or {}),
        workflow_id=_normalize(payload.get("workflow_id")) or None,
        status=str(payload.get("status") or "pending").strip().lower() or "pending",
        proposal_group=_normalize(payload.get("proposal_group")),
        preview_type=_normalize(payload.get("preview_type")),
        stage_ids=[
            str(stage_id)
            for stage_id in payload.get("stage_ids", [])
            if str(stage_id or "").strip()
        ],
        resulting_revision_ref=payload.get("resulting_revision_ref"),
        audit_id=_normalize(payload.get("audit_id")),
        draft_backed=bool(payload.get("draft_backed")),
        conflict_summary=payload.get("conflict_summary")
        if isinstance(payload.get("conflict_summary"), dict)
        else None,
        last_error=_normalize(payload.get("last_error")),
    )


def proposal_operation_attempt_from_dict(payload: Mapping[str, Any]) -> ProposalOperationAttempt:
    """Deserialize one stored proposal operation attempt."""
    return ProposalOperationAttempt(
        attempt_id=str(payload.get("attempt_id") or ""),
        status=_coerce_operation_status(payload.get("status")),
        created_at=str(payload.get("created_at") or ""),
        idempotency_key=_normalize(payload.get("idempotency_key")),
        error_detail=_normalize(payload.get("error_detail")),
        conflict_summary=payload.get("conflict_summary")
        if isinstance(payload.get("conflict_summary"), dict)
        else None,
        resulting_revision_ref=payload.get("resulting_revision_ref"),
        response=payload.get("response") if isinstance(payload.get("response"), dict) else None,
    )


def _coerce_operation_status(value: Any) -> ProposalOperationStatus:
    status = str(value or "pending").strip().lower()
    if status in {
        "pending",
        "applying",
        "failed",
        "invalid",
        "conflict",
        "partial",
        "applied",
        "rejected",
    }:
        return status  # type: ignore[return-value]
    return "pending"


async def apply_proposal_operation(
    *,
    repository: Any,
    writer: Any | None = None,
    operation: ProposalOperation,
    safety_mode: str,
    working_dir: str | None,
    idempotency_key: str | None,
    revision_override: str | None,
    record_indexes: Iterable[int] | None = None,
    execute_batch: ProposalBatchExecutor,
    resolve_current_revision: CurrentWorkflowResolver | None = None,
    resolve_workflow_revision: WorkflowRevisionResolver | None = None,
) -> dict[str, Any]:
    """Apply one proposal operation through the supplied batch executor."""
    if operation.status == "applied":
        return _terminal_operation_response(operation, "applied")
    if operation.status == "rejected":
        return _terminal_operation_response(operation, "rejected")
    if idempotency_key:
        attempts = operation.attempt_history or (
            [] if operation.last_attempt is None else [operation.last_attempt]
        )
        for attempt in attempts:
            if attempt.idempotency_key != idempotency_key:
                continue
            previous = attempt.response
            if isinstance(previous, dict):
                return previous

    target_indexes: set[int] = set()
    for index in record_indexes or []:
        try:
            normalized_index = int(index)
        except (TypeError, ValueError):
            continue
        if normalized_index >= 0:
            target_indexes.add(normalized_index)
    executable_refs = [
        ref
        for ref in operation.source_refs
        if ref.status in _RETRYABLE_STATUSES
        and (not target_indexes or ref.source_record_index in target_indexes)
    ]
    if not executable_refs:
        return _terminal_operation_response(operation, operation.status)

    refs_for_execution = executable_refs
    if revision_override is None:
        current_workflow = None
        current_revision_id = ""

        def workflow_revision_resolver(
            _workflow_id: str,
            _revision_id: str,
        ) -> Mapping[str, Any] | None:
            return None

        if resolve_current_revision is None or resolve_workflow_revision is None:
            strategy = NONE_STRATEGY
        else:
            workflow_id = _operation_workflow_id(operation, executable_refs)
            current_workflow = resolve_current_revision(workflow_id) if workflow_id else None
            current_revision_id = _workflow_revision_id(current_workflow)
            action_ids = {ref.action_id for ref in executable_refs}
            strategy = (
                resolve_strategy(executable_refs[0].action_id)
                if len(action_ids) == 1
                else NONE_STRATEGY
            )
            workflow_revision_resolver = resolve_workflow_revision
        outcome = strategy.maybe_rebase(
            executable_refs,
            current_workflow=current_workflow,
            current_revision_id=current_revision_id,
            resolve_workflow_revision=workflow_revision_resolver,
        )
        if outcome.kind == "conflict" and outcome.conflict_summary is not None:
            response = _conflict_response_for_refs(executable_refs, outcome.conflict_summary)
            return _finalize_apply_response(
                response,
                repository=repository,
                writer=writer,
                operation=operation,
                executable_refs=executable_refs,
                idempotency_key=idempotency_key,
            )
        if outcome.kind == "rebased" and outcome.rebased_refs is not None:
            refs_for_execution = outcome.rebased_refs

    records = []
    for ref in refs_for_execution:
        action_inputs = dict(ref.action_inputs)
        if revision_override:
            action_inputs["expected_revision_id"] = revision_override
        records.append(
            ActionBatchRecord(
                source_record_index=ref.source_record_index,
                action_id=ref.action_id,
                action_inputs=action_inputs,
                workflow_id=ref.workflow_id,
                expected_revision_id=revision_override
                or _normalize(action_inputs.get("expected_revision_id")),
                working_dir=working_dir,
            )
        )
    response = await execute_batch(
        operation.thread_id,
        operation.turn_id,
        safety_mode,
        working_dir,
        records,
    )
    return _finalize_apply_response(
        response,
        repository=repository,
        writer=writer,
        operation=operation,
        executable_refs=executable_refs,
        idempotency_key=idempotency_key,
    )


def _finalize_apply_response(
    response: dict[str, Any],
    *,
    repository: Any,
    writer: Any | None,
    operation: ProposalOperation,
    executable_refs: list[ProposalOperationRecordRef],
    idempotency_key: str | None,
) -> dict[str, Any]:
    status = _status_from_batch_response(response)
    attempt = ProposalOperationAttempt(
        attempt_id=_attempt_id(operation.operation_id, operation.attempt_count + 1),
        status=status,
        created_at=_utc_now(),
        idempotency_key=_normalize(idempotency_key),
        error_detail=_response_error_detail(response),
        conflict_summary=_response_conflict_summary(response),
        resulting_revision_ref=_response_revision_ref(response),
        response=response,
    )
    del repository
    refreshed = (
        writer.append_attempt(
            operation.operation_id,
            attempt,
            source_record_indexes=[ref.source_record_index for ref in executable_refs],
        )
        if writer is not None
        else operation
    )
    response["operation"] = refreshed.to_dict()
    response["operation"]["status"] = status
    response["operation_status"] = status
    return response


def dismiss_proposal_operation(
    *,
    repository: Any,
    writer: Any | None = None,
    operation: ProposalOperation,
) -> ProposalOperation:
    """Mark retryable source records rejected by explicit user action."""
    del repository
    if writer is None:
        return replace(operation, status="rejected", updated_at=_utc_now())
    return writer.dismiss(
        operation.operation_id,
        {ref.source_record_index for ref in operation.source_refs},
    )


def _operation_workflow_id(
    operation: ProposalOperation,
    refs: list[ProposalOperationRecordRef],
) -> str:
    candidates = [operation.workflow_id]
    for ref in refs:
        candidates.extend([ref.workflow_id, ref.action_inputs.get("workflow_id")])
    for candidate in candidates:
        normalized = _normalize(candidate)
        if normalized:
            return normalized
    return ""


def _workflow_revision_id(workflow: Mapping[str, Any] | None) -> str:
    if not isinstance(workflow, Mapping):
        return ""
    definition = workflow.get("workflow_definition")
    definition_map = definition if isinstance(definition, Mapping) else {}
    for key in ("latest_revision_id", "head_revision_id", "revision_id"):
        normalized = _normalize(workflow.get(key))
        if normalized:
            return normalized
    for key in ("latest_revision_id", "head_revision_id", "revision_id"):
        normalized = _normalize(definition_map.get(key))
        if normalized:
            return normalized
    return ""


def _conflict_response_for_refs(
    refs: list[ProposalOperationRecordRef],
    conflict_summary: dict[str, Any],
) -> dict[str, Any]:
    return {
        "results": [
            {
                "source_record_index": ref.source_record_index,
                "action_id": ref.action_id,
                "workflow_id": ref.workflow_id,
                "outcome": "conflict",
                "conflict_summary": conflict_summary,
            }
            for ref in refs
        ],
        "overall_outcome": "conflict",
    }


def _build_operation(
    records: list[Mapping[str, Any]],
    refs: list[ProposalOperationRecordRef],
    *,
    group_key: str,
) -> ProposalOperation:
    workflow_id = next((ref.workflow_id for ref in refs if ref.workflow_id), None)
    proposal_group = refs[0].proposal_group if refs else None
    attempts = [
        attempt
        for record in records
        for attempt in _attempt_history(record)
    ]
    latest_attempt = attempts[-1] if attempts else None
    status = _derive_status(records, latest_attempt)
    resulting_revision_ref = next(
        (ref.resulting_revision_ref for ref in refs if ref.resulting_revision_ref),
        latest_attempt.resulting_revision_ref if latest_attempt else None,
    )
    conflict_summary = next(
        (
            record.get("conflict_summary")
            for record in records
            if isinstance(record.get("conflict_summary"), dict)
        ),
        latest_attempt.conflict_summary if latest_attempt else None,
    )
    stage_ids: list[str] = []
    for ref in refs:
        for stage_id in ref.stage_ids:
            if stage_id not in stage_ids:
                stage_ids.append(stage_id)
    explicit_operation_ids = {
        str(record.get("proposal_operation_id") or "").strip()
        for record in records
        if str(record.get("proposal_operation_id") or "").strip()
    }
    operation_id = (
        next(iter(explicit_operation_ids))
        if len(explicit_operation_ids) == 1
        else proposal_operation_id_for_records(
            workflow_id=workflow_id,
            thread_id=refs[0].thread_id if refs else None,
            turn_id=refs[0].turn_id if refs else None,
            proposal_group=proposal_group or group_key,
            source_record_indexes=[ref.source_record_index for ref in refs],
            records=records,
        )
    )
    return ProposalOperation(
        operation_id=operation_id,
        workflow_id=workflow_id,
        thread_id=refs[0].thread_id,
        turn_id=refs[0].turn_id,
        proposal_group=proposal_group,
        status=status,
        source_refs=refs,
        attempt_count=sum(_attempt_count(record) for record in records),
        last_attempt=latest_attempt,
        last_error=latest_attempt.error_detail if latest_attempt else None,
        conflict_summary=conflict_summary,
        resulting_revision_ref=resulting_revision_ref,
        preview_summary=_preview_summary(refs),
        stage_ids=stage_ids,
        created_at=_operation_created_at(records, refs),
        updated_at=_operation_updated_at(records, latest_attempt),
        attempt_history=attempts,
        created_by=_operation_created_by(records),
    )


def _record_ref(
    record: Mapping[str, Any],
    *,
    thread_id: str,
    turn_id: str,
    source_record_index: int,
    workflow_id: str | None,
) -> ProposalOperationRecordRef:
    action_inputs = record.get("action_inputs")
    return ProposalOperationRecordRef(
        thread_id=thread_id,
        turn_id=turn_id,
        source_record_index=source_record_index,
        action_id=str(record.get("action_id") or ""),
        action_inputs=dict(action_inputs if isinstance(action_inputs, Mapping) else {}),
        workflow_id=workflow_id,
        status=str(record.get("status") or "pending").strip().lower() or "pending",
        proposal_group=_normalize(record.get("proposal_group")),
        preview_type=_normalize(record.get("preview_type")),
        stage_ids=_stage_ids_for_record(record),
        resulting_revision_ref=record.get("resulting_revision_ref"),
        audit_id=_normalize(record.get("audit_id")),
        conflict_summary=record.get("conflict_summary")
        if isinstance(record.get("conflict_summary"), dict)
        else None,
        last_error=_normalize(record.get("last_error") or record.get("error_detail")),
    )


def _derive_status(
    records: list[Mapping[str, Any]],
    latest_attempt: ProposalOperationAttempt | None,
) -> ProposalOperationStatus:
    statuses = {
        str(record.get("status") or "pending").strip().lower() or "pending" for record in records
    }
    applied_statuses = {"applied", "accepted"}
    if statuses and statuses <= applied_statuses:
        return "applied"
    if statuses & applied_statuses:
        return "partial"
    if statuses and statuses <= {"rejected"}:
        return "rejected"
    if "conflict" in statuses:
        return "conflict"
    if latest_attempt and latest_attempt.status in {"failed", "invalid", "conflict", "partial"}:
        return latest_attempt.status
    if "failed" in statuses:
        return "failed"
    if "invalid" in statuses:
        return "invalid"
    if "applying" in statuses:
        return "applying"
    return "pending"


def _is_proposal_record(record: Mapping[str, Any]) -> bool:
    action_id = str(record.get("action_id") or "").strip()
    if not action_id.startswith(_EXECUTABLE_ACTION_PREFIXES):
        return False
    action_type = str(record.get("action_type") or "").strip()
    action_inputs = record.get("action_inputs")
    has_proposal_marker = bool(
        record.get("proposal_group")
        or record.get("proposal_operation_id")
        or record.get("preview_type")
        or action_type.startswith("propose")
        or _mapping_value(action_inputs, "proposal_operation_id")
        or _mapping_value(action_inputs, "proposed_content")
    )
    if not has_proposal_marker:
        return False
    status = str(record.get("status") or "pending").strip().lower() or "pending"
    if status in {
        "pending",
        "applied",
        "accepted",
        "rejected",
        "conflict",
        "failed",
        "invalid",
        "applying",
    }:
        return True
    return bool(record.get("proposal_group") or record.get("preview_type"))


def _record_matches_workflow(record: Mapping[str, Any], workflow_id: str) -> bool:
    candidates = [
        record.get("workflow_id"),
        _mapping_value(record.get("action_inputs"), "workflow_id"),
    ]
    if any(str(candidate or "").strip() == workflow_id for candidate in candidates):
        return True
    operations = _mapping_value(record.get("action_inputs"), "operations")
    if isinstance(operations, list):
        return any(
            isinstance(operation, Mapping)
            and str(operation.get("workflow_id") or "").strip() == workflow_id
            for operation in operations
        )
    return not any(str(candidate or "").strip() for candidate in candidates)


def _record_workflow_id(record: Mapping[str, Any]) -> str | None:
    workflow_id = _normalize(record.get("workflow_id")) or _normalize(
        _mapping_value(record.get("action_inputs"), "workflow_id")
    )
    if workflow_id:
        return workflow_id
    operations = _mapping_value(record.get("action_inputs"), "operations")
    if isinstance(operations, list):
        for operation in operations:
            if isinstance(operation, Mapping):
                workflow_id = _normalize(operation.get("workflow_id"))
                if workflow_id:
                    return workflow_id
    return None


def _stage_ids_for_record(record: Mapping[str, Any]) -> list[str]:
    values = [
        record.get("stage_id"),
        _mapping_value(record.get("action_inputs"), "stage_id"),
    ]
    stage_definition = _mapping_value(record.get("action_inputs"), "stage_definition")
    if isinstance(stage_definition, Mapping):
        values.append(stage_definition.get("stage_id") or stage_definition.get("id"))
    operations = _mapping_value(record.get("action_inputs"), "operations")
    if isinstance(operations, list):
        for operation in operations:
            if isinstance(operation, Mapping):
                values.append(operation.get("stage_id"))
    stage_ids: list[str] = []
    for value in values:
        normalized = _normalize(value)
        if normalized and normalized not in stage_ids:
            stage_ids.append(normalized)
    return stage_ids


def _latest_attempt(record: Mapping[str, Any]) -> ProposalOperationAttempt | None:
    attempts = _attempt_history(record)
    return attempts[-1] if attempts else None


def _attempt_history(record: Mapping[str, Any]) -> list[ProposalOperationAttempt]:
    attempts = record.get("proposal_attempts")
    if not isinstance(attempts, list) or not attempts:
        return []
    parsed: list[ProposalOperationAttempt] = []
    for raw in attempts:
        if not isinstance(raw, Mapping):
            continue
        parsed.append(_attempt_from_raw(raw))
    return parsed


def _attempt_from_raw(raw: Mapping[str, Any]) -> ProposalOperationAttempt:
    if not isinstance(raw, Mapping):
        return ProposalOperationAttempt(
            attempt_id="",
            status="failed",
            created_at="",
        )
    status = str(raw.get("status") or "failed").strip().lower()
    if status not in {
        "pending",
        "applying",
        "failed",
        "invalid",
        "conflict",
        "partial",
        "applied",
        "rejected",
    }:
        status = "failed"
    return ProposalOperationAttempt(
        attempt_id=str(raw.get("attempt_id") or ""),
        status=status,  # type: ignore[arg-type]
        created_at=str(raw.get("created_at") or ""),
        idempotency_key=_normalize(raw.get("idempotency_key")),
        error_detail=_normalize(raw.get("error_detail")),
        conflict_summary=raw.get("conflict_summary")
        if isinstance(raw.get("conflict_summary"), dict)
        else None,
        resulting_revision_ref=raw.get("resulting_revision_ref"),
        response=raw.get("response") if isinstance(raw.get("response"), dict) else None,
    )


def _attempt_count(record: Mapping[str, Any]) -> int:
    attempts = record.get("proposal_attempts")
    return len(attempts) if isinstance(attempts, list) else 0


def _operation_created_at(
    records: list[Mapping[str, Any]],
    refs: list[ProposalOperationRecordRef],
) -> str:
    candidates: list[Any] = []
    for record in records:
        candidates.extend(
            [
                record.get("created_at"),
                record.get("timestamp"),
                record.get("proposed_at"),
            ]
        )
    for ref in refs:
        candidates.append(ref.action_inputs.get("created_at"))
    return next((str(candidate) for candidate in candidates if str(candidate or "").strip()), "")


def _operation_updated_at(
    records: list[Mapping[str, Any]],
    latest_attempt: ProposalOperationAttempt | None,
) -> str:
    candidates: list[Any] = [latest_attempt.created_at if latest_attempt else None]
    for record in records:
        candidates.extend(
            [
                record.get("updated_at"),
                record.get("dismissed_at"),
                record.get("created_at"),
                record.get("timestamp"),
            ]
        )
    return next((str(candidate) for candidate in candidates if str(candidate or "").strip()), "")


def _operation_created_by(records: list[Mapping[str, Any]]) -> str | None:
    for record in records:
        metadata = record.get("metadata")
        action_inputs = record.get("action_inputs")
        candidates = [
            record.get("created_by"),
            record.get("user_id"),
            _mapping_value(metadata, "created_by"),
            _mapping_value(metadata, "user_id"),
            _mapping_value(action_inputs, "created_by"),
            _mapping_value(action_inputs, "user_id"),
        ]
        for candidate in candidates:
            normalized = _normalize(candidate)
            if normalized:
                return normalized
    return "current-user"


def _append_attempt_to_records(
    repository: Any,
    *,
    operation: ProposalOperation,
    attempt: ProposalOperationAttempt,
    source_refs: Iterable[ProposalOperationRecordRef] | None = None,
) -> None:
    target_indexes = {
        ref.source_record_index
        for ref in (list(source_refs) if source_refs is not None else operation.source_refs)
    }
    attempt_payload = attempt.to_dict()

    def updater(records: list[dict[str, Any]]) -> list[dict[str, Any]]:
        next_records = [dict(record) for record in records]
        for index, record in enumerate(next_records):
            if index not in target_indexes:
                continue
            attempts = record.get("proposal_attempts")
            record["proposal_attempts"] = [
                *(attempts if isinstance(attempts, list) else []),
                dict(attempt_payload),
            ]
            if attempt.status in {"failed", "invalid"} and record.get("status") == "pending":
                record["status"] = attempt.status
        return next_records

    repository.update_action_records(operation.thread_id, operation.turn_id, updater)


def _terminal_operation_response(operation: ProposalOperation, status: str) -> dict[str, Any]:
    return {
        "results": [],
        "overall_outcome": status,
        "operation_status": operation.status,
        "operation": operation.to_dict(),
    }


def _status_from_batch_response(response: Mapping[str, Any]) -> ProposalOperationStatus:
    overall = str(response.get("overall_outcome") or "").strip().lower()
    if overall == "applied":
        return "applied"
    if overall == "partial":
        return "partial"
    if overall == "conflict":
        return "conflict"
    if overall == "invalid":
        return "invalid"
    return "failed"


def _response_error_detail(response: Mapping[str, Any]) -> str | None:
    results = response.get("results")
    for result in results if isinstance(results, list) else []:
        if not isinstance(result, Mapping):
            continue
        detail = result.get("detail") or result.get("error") or result.get("validation_summary")
        if detail:
            return (
                json.dumps(detail, sort_keys=True, default=str)
                if not isinstance(detail, str)
                else detail
            )
    return None


def _response_conflict_summary(response: Mapping[str, Any]) -> dict[str, Any] | None:
    results = response.get("results")
    for result in results if isinstance(results, list) else []:
        if isinstance(result, Mapping) and isinstance(result.get("conflict_summary"), dict):
            return dict(result["conflict_summary"])
    return None


def _response_revision_ref(response: Mapping[str, Any]) -> Any:
    results = response.get("results")
    for result in results if isinstance(results, list) else []:
        if not isinstance(result, Mapping):
            continue
        payload = result.get("payload")
        if isinstance(payload, Mapping) and payload.get("resulting_revision_ref"):
            return payload.get("resulting_revision_ref")
        if result.get("resulting_revision_ref"):
            return result.get("resulting_revision_ref")
    return None


def _attempt_id(operation_id: str, attempt_number: int) -> str:
    return f"{operation_id}-attempt-{attempt_number}"


def _preview_summary(refs: list[ProposalOperationRecordRef]) -> str:
    if len(refs) == 1:
        ref = refs[0]
        return ref.stage_ids[0] if ref.stage_ids else ref.action_id
    return f"{len(refs)} proposed changes"


def _status_sort_key(status: str) -> int:
    order = {
        "failed": 0,
        "invalid": 1,
        "conflict": 2,
        "partial": 3,
        "pending": 4,
        "applying": 5,
        "applied": 6,
        "rejected": 7,
    }
    return order.get(status, 99)


def _draft_record_payload(draft_payload: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "action_id": str(draft_payload.get("action_kind") or "execute_template_edit"),
        "action_inputs": _draft_action_inputs(draft_payload),
    }


def _draft_record_ref(
    draft_payload: Mapping[str, Any],
    *,
    source_record_index: int,
) -> ProposalOperationRecordRef:
    stage_id = _normalize(draft_payload.get("stage_id"))
    action_inputs = _draft_action_inputs(draft_payload)
    metadata = draft_payload.get("metadata") if isinstance(draft_payload.get("metadata"), Mapping) else {}
    return ProposalOperationRecordRef(
        thread_id=_normalize(_mapping_value(metadata, "thread_id")) or "",
        turn_id=_normalize(_mapping_value(metadata, "turn_id")) or "",
        source_record_index=source_record_index,
        action_id=str(draft_payload.get("action_kind") or "execute_template_edit"),
        action_inputs=action_inputs,
        workflow_id=_normalize(draft_payload.get("workflow_id")),
        status="pending",
        proposal_group=_normalize(draft_payload.get("proposal_group")),
        preview_type="template_asset_draft",
        stage_ids=[stage_id] if stage_id else [],
        draft_backed=True,
    )


def _draft_action_inputs(draft_payload: Mapping[str, Any]) -> dict[str, Any]:
    role = str(draft_payload.get("role") or "").strip()
    metadata = draft_payload.get("metadata") if isinstance(draft_payload.get("metadata"), Mapping) else {}
    return {
        "workflow_id": _normalize(draft_payload.get("workflow_id")),
        "stage_id": _normalize(draft_payload.get("stage_id")),
        "template_role": role,
        "draft_backed": True,
        "proposed_content_hash": _normalize(draft_payload.get("content_hash")),
        "thread_id": _normalize(_mapping_value(metadata, "thread_id")),
        "turn_id": _normalize(_mapping_value(metadata, "turn_id")),
        "created_at": _normalize(_mapping_value(metadata, "created_at")),
        "updated_at": _normalize(draft_payload.get("updated_at")),
        "created_by": _normalize(_mapping_value(metadata, "created_by"))
        or _normalize(_mapping_value(metadata, "user_id")),
    }


def _draft_source_record_index(draft_payload: Mapping[str, Any], fallback_index: int) -> int:
    source_record_index = draft_payload.get("source_record_index")
    if isinstance(source_record_index, int) and source_record_index >= 0:
        return source_record_index
    return fallback_index


def _draft_metadata_value(ref: ProposalOperationRecordRef, key: str) -> str | None:
    return _normalize(ref.action_inputs.get(key))


def _turn_value(turn: Any, key: str) -> str | None:
    value = turn.get(key) if isinstance(turn, Mapping) else getattr(turn, key, None)
    return _normalize(value)


def _mapping_value(value: Any, key: str) -> Any:
    return value.get(key) if isinstance(value, Mapping) else None


def _normalize(value: Any) -> str | None:
    normalized = str(value or "").strip()
    return normalized or None


def _utc_now() -> str:
    return datetime.now(tz=timezone.utc).isoformat()
