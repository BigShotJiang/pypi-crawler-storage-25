"""
test_client.py — SDK end-to-end self-test.

Usage: python tests/test_client.py YOUR_API_KEY
"""

import sys
from vaultstream import VaultStreamClient


def main(api_key: str):
    print("━" * 60)
    print("  VaultStream SDK Self-Test")
    print("━" * 60)

    client = VaultStreamClient(
        api_url="https://vaultstream.centralindia.cloudapp.azure.com",
        api_key=api_key,
        scheme="ckks"
    )

    print("\n[1] ping()")
    print(f"    {client.ping()}")

    print("\n[2] whoami()")
    print(f"    {client.whoami()}")

    print("\n[3] generate_keys()")
    client.generate_keys()
    print("    ✓ Context + keys generated locally")

    salaries = [45000, 62000, 78000, 91000, 55000, 83000, 67000, 74000, 88000, 51000]
    weights  = [1.0, 1.2, 1.5, 2.0, 1.0, 1.8, 1.3, 1.6, 1.9, 1.1]

    print(f"\n[4] encrypted_sum({len(salaries)} values)")
    print(f"    Result: {client.encrypted_sum(salaries):.2f}  (expected {sum(salaries)})")

    print(f"\n[5] encrypted_average({len(salaries)} values)")
    print(f"    Result: {client.encrypted_average(salaries):.2f}  (expected {sum(salaries)/len(salaries):.2f})")

    print(f"\n[6] encrypted_min_max")
    mn, mx = client.encrypted_min_max(salaries)
    print(f"    Min: {mn:.2f}  Max: {mx:.2f}  (expected {min(salaries)}, {max(salaries)})")

    print(f"\n[7] encrypted_variance")
    var, std = client.encrypted_variance(salaries)
    print(f"    Variance: {var:.2f}   Std Dev: {std:.2f}")

    print(f"\n[8] encrypted_threshold_count(threshold=70000)")
    count = client.encrypted_threshold_count(salaries, 70000, "above")
    expected = sum(1 for v in salaries if v > 70000)
    print(f"    Above 70k: {count}  (expected {expected})")

    print(f"\n[9] encrypted_weighted_average")
    wavg = client.encrypted_weighted_average(salaries, weights)
    plain = sum(v*w for v,w in zip(salaries, weights)) / sum(weights)
    print(f"    Weighted avg: {wavg:.2f}  (expected {plain:.2f})")

    print(f"\n[10] encrypted_correlation(salaries, weights)")
    r = client.encrypted_correlation(salaries, weights)
    print(f"    Pearson r: {r:.4f}")

    print(f"\n[11] encrypted_percentiles")
    pcts = client.encrypted_percentiles(salaries, [25, 50, 75, 90])
    print(f"    {pcts}")

    print(f"\n[12] encrypted_histogram(bins=5)")
    hist = client.encrypted_histogram(salaries, bins=5)
    for label, n in hist.items():
        print(f"    {label}: {'█' * n} ({n})")

    client.close()

    print("\n" + "━" * 60)
    print("  ✅ SDK fully working — every operation executed end-to-end")
    print("  ✅ Private key never left the client")
    print("━" * 60)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python tests/test_client.py YOUR_API_KEY")
        sys.exit(1)
    main(sys.argv[1])
