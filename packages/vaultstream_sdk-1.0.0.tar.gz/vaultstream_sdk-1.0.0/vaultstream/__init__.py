"""
VaultStream Python SDK
======================

from vaultstream import VaultStreamClient

client = VaultStreamClient(api_url="...", api_key="vs_live_...", scheme="ckks")
client.generate_keys()
result = client.encrypted_sum([100, 200, 300])
"""

from vaultstream.client import VaultStreamClient

__version__ = "1.0.0"
__all__     = ["VaultStreamClient"]
