"""
vaultstream/encryption.py — Client-side encryption primitives.

This module owns the HE context and keys. The PRIVATE KEY NEVER leaves
this module — the client serialises only the PUBLIC context to send to
the server.
"""

import base64
import tenseal as ts


# ── Serialisation helpers (same as server) ───────────────────────── #

def b64e(raw: bytes) -> str:
    return base64.b64encode(raw).decode("ascii")

def b64d(s: str) -> bytes:
    return base64.b64decode(s.encode("ascii"))


# ── Context creation ─────────────────────────────────────────────── #

def create_ckks_context() -> ts.Context:
    """Create a CKKS context for floating-point HE."""
    ctx = ts.context(
        ts.SCHEME_TYPE.CKKS,
        poly_modulus_degree=8192,
        coeff_mod_bit_sizes=[60, 40, 40, 60]
    )
    ctx.global_scale = 2 ** 40
    ctx.generate_galois_keys()
    return ctx


def create_bfv_context() -> ts.Context:
    """Create a BFV context for integer HE."""
    ctx = ts.context(
        ts.SCHEME_TYPE.BFV,
        poly_modulus_degree=4096,
        plain_modulus=1032193
    )
    ctx.generate_galois_keys()
    return ctx


# ── Public-context export ────────────────────────────────────────── #

def export_public_context(ctx: ts.Context) -> str:
    """
    Export the context WITHOUT the secret key. This is what gets sent
    to the server. The server can encrypt and operate on ciphertexts
    but cannot decrypt them.
    """
    public_only = ts.context_from(ctx.serialize(save_secret_key=False))
    return b64e(public_only.serialize())


# ── Encrypt / decrypt ────────────────────────────────────────────── #

def encrypt_ckks(ctx: ts.Context, values: list) -> str:
    vec = ts.ckks_vector(ctx, [float(v) for v in values])
    return b64e(vec.serialize())


def encrypt_bfv(ctx: ts.Context, values: list) -> str:
    vec = ts.bfv_vector(ctx, [int(v) for v in values])
    return b64e(vec.serialize())


def decrypt_ckks(ctx: ts.Context, ciphertext_b64: str) -> list:
    vec = ts.ckks_vector_from(ctx, b64d(ciphertext_b64))
    return vec.decrypt()


def decrypt_bfv(ctx: ts.Context, ciphertext_b64: str) -> list:
    vec = ts.bfv_vector_from(ctx, b64d(ciphertext_b64))
    return vec.decrypt()
