"""
vaultstream/client.py — VaultStream Python SDK Client.

UPDATED: Context caching.

  - generate_keys() uploads the public context to the server ONCE,
    stores the returned context_id, and reuses it for every subsequent
    operation. Cuts per-operation wire bytes from ~47 MB → ~5 KB.
  - On cache miss (server returned 404 on context_id), the SDK
    transparently re-uploads and retries the original operation once.
  - Older servers that don't have the cache endpoint still work — the
    SDK falls back to embedding context_b64 in every request.

PRIVATE KEY NEVER LEAVES THIS CLASS.
"""

import math
import httpx
import tenseal as ts
from typing import List, Optional, Dict, Tuple

from vaultstream.encryption import (
    create_ckks_context, create_bfv_context,
    export_public_context,
    encrypt_ckks, encrypt_bfv,
    decrypt_ckks, decrypt_bfv,
)


class VaultStreamClient:
    """
    Client for VaultStream Homomorphic Encryption-as-a-Service.

    Example:
        client = VaultStreamClient(api_url="https://...",
                                    api_key="vs_live_xxx")
        client.generate_keys()
        result = client.encrypted_sum([100, 200, 300])
        print(result)  # 600
    """

    def __init__(
        self,
        api_url: str,
        api_key: str,
        scheme:  str = "ckks",
        timeout: int = 600,    # bumped from 60 for WAN deployment (one-time context upload)
    ):
        if not api_url:
            raise ValueError("api_url is required")
        if not api_key:
            raise ValueError("api_key is required")
        if scheme not in ("ckks", "bfv"):
            raise ValueError("scheme must be 'ckks' or 'bfv'")

        self.api_url = api_url.rstrip("/")
        self.api_key = api_key
        self.scheme  = scheme
        self.timeout = timeout

        # Private encryption state (never sent to server)
        self._context:        Optional[ts.Context] = None
        self._public_ctx_b64: Optional[str]        = None

        # Server-side cache identifier — populated after first upload.
        # When set, operations send context_id (~64 bytes) instead of
        # context_b64 (~47 MB).
        self._context_id:     Optional[str]        = None

        # Set to True if the server returned 404 on /context/upload —
        # means we're talking to an older API that doesn't have the
        # cache feature. Fall back to embedding context_b64 in every request.
        self._cache_unsupported: bool              = False

        self._http = httpx.Client(
            base_url=self.api_url,
            timeout=self.timeout,
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type":  "application/json",
                "User-Agent":    "vaultstream-sdk/1.1",
            }
        )

    # ── Lifecycle ────────────────────────────────────────────── #

    def __enter__(self): return self
    def __exit__(self, *args): self.close()
    def close(self):
        if self._http: self._http.close()

    def ping(self) -> dict:
        r = self._http.get("/health")
        r.raise_for_status()
        return r.json()

    def whoami(self) -> dict:
        r = self._http.get("/auth/me")
        r.raise_for_status()
        return r.json()

    # ── Key generation ───────────────────────────────────────── #

    def generate_keys(self):
        """
        Generate HE context + key pair, then upload the public context to
        the server (one-time ~47 MB). Subsequent operations reference it
        by context_id (~64 bytes).

        Private key stays in self._context — never serialised, never sent.
        """
        if self.scheme == "ckks":
            self._context = create_ckks_context()
        else:
            self._context = create_bfv_context()

        self._public_ctx_b64 = export_public_context(self._context)

        # Pre-upload the context so the first real op is fast too.
        # If the server is old (no cache endpoint), fall back silently.
        self._upload_context_if_needed()
        return self

    def _require_keys(self):
        if self._context is None or self._public_ctx_b64 is None:
            raise RuntimeError("Call generate_keys() before performing operations")

    # ── Context cache integration ────────────────────────────── #

    def _upload_context_if_needed(self) -> None:
        """
        Upload the public context to the server cache, if we haven't
        already and the server supports it. Idempotent.
        """
        if self._context_id is not None:
            return
        if self._cache_unsupported:
            return
        assert self._public_ctx_b64 is not None

        try:
            r = self._http.post(
                "/operations/context/upload",
                json={"context_b64": self._public_ctx_b64},
            )
        except httpx.HTTPError as e:
            # Network blip — try again on the next operation
            raise RuntimeError(f"Context upload failed: {e}") from e

        if r.status_code == 404:
            # Server is older (no cache endpoint). Fall back to legacy mode.
            self._cache_unsupported = True
            return

        if r.status_code != 200:
            raise RuntimeError(
                f"Context upload error {r.status_code}: {r.text[:300]}"
            )

        self._context_id = r.json()["context_id"]

    def _context_payload(self) -> dict:
        """
        Build the context-source portion of a request payload.
        Prefers context_id when available; falls back to context_b64.
        """
        self._upload_context_if_needed()
        if self._context_id is not None:
            return {"context_id": self._context_id}
        return {"context_b64": self._public_ctx_b64}

    # ── Internals ────────────────────────────────────────────── #

    def _enc(self, values) -> str:
        assert self._context is not None, "generate_keys() must be called first"
        if self.scheme == "ckks":
            return encrypt_ckks(self._context, values)
        return encrypt_bfv(self._context, values)

    def _dec(self, b64: str) -> list:
        assert self._context is not None, "generate_keys() must be called first"
        if self.scheme == "ckks":
            return decrypt_ckks(self._context, b64)
        return decrypt_bfv(self._context, b64)

    def _post(self, endpoint: str, payload: dict) -> dict:
        """
        POST to /operations/{endpoint}. If the server returns 404 with a
        cache-related message (context_id evicted), re-upload the context
        once and retry transparently.
        """
        r = self._http.post(f"/operations/{endpoint}", json=payload)

        # Cache miss path — drop the stale id, re-upload, retry once
        if r.status_code == 404 and self._context_id and "context_id" in payload:
            self._context_id = None
            self._upload_context_if_needed()
            payload = {**payload}
            payload.pop("context_b64", None)
            payload.pop("context_id",  None)
            payload.update(self._context_payload())
            r = self._http.post(f"/operations/{endpoint}", json=payload)

        if r.status_code != 200:
            raise RuntimeError(f"VaultStream API error {r.status_code}: {r.text[:300]}")
        return r.json()

    def _payload(self, **extra) -> dict:
        """Helper — merge context source + scheme + extras into one dict."""
        p = self._context_payload()
        p["scheme"] = self.scheme
        p.update(extra)
        return p

    # ═══════════════════════════════════════════════════════════ #
    #  OPERATIONS                                                  #
    # ═══════════════════════════════════════════════════════════ #

    # ── 1. Sum ───────────────────────────────────────────────── #

    def encrypted_sum(self, values: List[float]) -> float:
        self._require_keys()
        n = len(values)
        r = self._post("sum", self._payload(
            ciphertext_b64=self._enc(values), n=n,
        ))
        return self._dec(r["result_b64"])[0]

    # ── 2. Average ───────────────────────────────────────────── #

    def encrypted_average(self, values: List[float]) -> float:
        self._require_keys()
        n = len(values)
        r = self._post("average", self._payload(
            ciphertext_b64=self._enc(values), n=n,
        ))
        return self._dec(r["result_b64"])[0]

    # ── 3. Min / Max ─────────────────────────────────────────── #

    def encrypted_min_max(self, values: List[float]) -> Tuple[float, float]:
        """Returns (min, max). Cloud sees only ciphertext throughout."""
        self._require_keys()
        n = len(values)
        r = self._post("min-max", self._payload(
            ciphertext_b64=self._enc(values), n=n,
        ))
        decrypted = self._dec(r["result_b64"])[:n]
        return min(decrypted), max(decrypted)

    # ── 4. Variance + Std Dev ────────────────────────────────── #

    def encrypted_variance(self, values: List[float]) -> Tuple[float, float]:
        """Returns (variance, std_dev)."""
        self._require_keys()
        n = len(values)
        sq = [v * v for v in values]
        r = self._post("variance", self._payload(
            ciphertext_b64=self._enc(values),
            ciphertext_sq_b64=self._enc(sq),
            n=n,
        ))
        e_x  = self._dec(r["result_a_b64"])[0]
        e_x2 = self._dec(r["result_b_b64"])[0]
        variance = e_x2 - e_x ** 2
        std_dev  = math.sqrt(abs(variance))
        return variance, std_dev

    # ── 5. Threshold Alert ───────────────────────────────────── #

    def encrypted_threshold_count(
        self, values: List[float], threshold: float, direction: str = "above"
    ) -> int:
        """Count records breaching the threshold. direction = 'above' or 'below'."""
        self._require_keys()
        n = len(values)
        r = self._post("threshold", self._payload(
            ciphertext_b64=self._enc(values),
            threshold=threshold,
            n=n,
        ))
        shifted = self._dec(r["result_b64"])[:n]
        if direction == "above":
            return sum(1 for v in shifted if v > 0)
        return sum(1 for v in shifted if v < 0)

    # ── 6. Weighted Average ──────────────────────────────────── #

    def encrypted_weighted_average(
        self, values: List[float], weights: List[float]
    ) -> float:
        self._require_keys()
        if len(values) != len(weights):
            raise ValueError("values and weights must have equal length")
        n = len(values)
        r = self._post("weighted-average", self._payload(
            ciphertext_values_b64=self._enc(values),
            ciphertext_weights_b64=self._enc(weights),
            n=n,
        ))
        sum_vw = self._dec(r["result_a_b64"])[0]
        sum_w  = self._dec(r["result_b_b64"])[0]
        return sum_vw / sum_w if sum_w != 0 else 0.0

    # ── 7. Pearson Correlation ───────────────────────────────── #

    def encrypted_correlation(
        self, x: List[float], y: List[float]
    ) -> float:
        self._require_keys()
        if len(x) != len(y):
            raise ValueError("x and y must have equal length")
        n = len(x)
        r = self._post("correlation", self._payload(
            ctx_x_b64=self._enc(x),
            ctx_y_b64=self._enc(y),
            ctx_x2_b64=self._enc([v ** 2 for v in x]),
            ctx_y2_b64=self._enc([v ** 2 for v in y]),
            ctx_xy_b64=self._enc([xi * yi for xi, yi in zip(x, y)]),
            n=n,
        ))
        sx  = self._dec(r["results"]["sum_x_b64"])[0]
        sy  = self._dec(r["results"]["sum_y_b64"])[0]
        sx2 = self._dec(r["results"]["sum_x2_b64"])[0]
        sy2 = self._dec(r["results"]["sum_y2_b64"])[0]
        sxy = self._dec(r["results"]["sum_xy_b64"])[0]
        num = n * sxy - sx * sy
        den = math.sqrt(abs((n * sx2 - sx ** 2) * (n * sy2 - sy ** 2)))
        return num / den if den > 0 else 0.0

    # ── 8. Percentile ────────────────────────────────────────── #

    def encrypted_percentiles(
        self, values: List[float], percentiles: List[int] = [25, 50, 75, 90, 95]
    ) -> Dict[int, float]:
        self._require_keys()
        n = len(values)
        r = self._post("percentile", self._payload(
            ciphertext_b64=self._enc(values), n=n,
        ))
        decrypted = sorted(self._dec(r["result_b64"])[:n])
        out = {}
        for p in percentiles:
            idx = min(int(p / 100 * n), n - 1)
            out[p] = decrypted[idx]
        return out

    # ── 9. Histogram ─────────────────────────────────────────── #

    def encrypted_histogram(
        self, values: List[float], bins: int = 10
    ) -> Dict[str, int]:
        self._require_keys()
        n = len(values)
        r = self._post("histogram", self._payload(
            ciphertext_b64=self._enc(values), n=n,
        ))
        decrypted = self._dec(r["result_b64"])[:n]
        lo, hi = min(decrypted), max(decrypted)
        if hi == lo:
            return {f"{lo:.0f}": n}
        width = (hi - lo) / bins
        counts: Dict[str, int] = {}
        for v in decrypted:
            idx = min(int((v - lo) / width), bins - 1)
            label = f"{lo + idx * width:.0f}-{lo + (idx + 1) * width:.0f}"
            counts[label] = counts.get(label, 0) + 1
        return counts

    # ── 10. Count by Category ────────────────────────────────── #

    def encrypted_count_by_category(
        self, categories: List[int]
    ) -> Dict[int, int]:
        """BFV-only. Categories must be integer codes (e.g. 0=Branch_A, 1=Branch_B)."""
        if self.scheme != "bfv":
            raise ValueError("count_by_category requires scheme='bfv'")
        self._require_keys()
        n = len(categories)
        r = self._post("count", self._payload(
            ciphertext_b64=self._enc(categories), n=n,
        ))
        decrypted = self._dec(r["result_b64"])[:n]
        counts: Dict[int, int] = {}
        for c in decrypted:
            counts[c] = counts.get(c, 0) + 1
        return counts

    # ═══════════════════════════════════════════════════════════ #
    #  MULTI-PARTY                                                 #
    # ═══════════════════════════════════════════════════════════ #
    # Multi-party endpoints currently embed context_b64 explicitly
    # (they may receive a context from a partner organisation, so the
    # SDK cache id may not match). Left untouched for backwards
    # compatibility — the savings are smaller anyway because multi-party
    # demos run infrequently.

    def joint_sum_with_party(
        self,
        my_values:                List[float],
        other_party_ciphertext_b64: str,
        other_party_n:            int,
        my_label:                 str = "Our Organisation",
        other_label:              str = "Partner Organisation",
    ) -> float:
        self._require_keys()
        my_n = len(my_values)
        my_ciphertext_b64 = self._enc(my_values)

        r = self._http.post("/multi-party/joint-sum", json={
            "context_b64":      self._public_ctx_b64,
            "ciphertext_a_b64": my_ciphertext_b64,
            "ciphertext_b_b64": other_party_ciphertext_b64,
            "n_a":              my_n,
            "n_b":              other_party_n,
            "scheme":           self.scheme,
            "party_a_label":    my_label,
            "party_b_label":    other_label,
        })
        if r.status_code != 200:
            raise RuntimeError(f"Joint-sum failed: {r.status_code} {r.text[:300]}")

        return self._dec(r.json()["result_b64"])[0]

    def joint_average_with_party(
        self,
        my_values:                List[float],
        other_party_ciphertext_b64: str,
        other_party_n:            int,
        my_label:                 str = "Our Organisation",
        other_label:              str = "Partner Organisation",
    ) -> float:
        self._require_keys()
        my_n = len(my_values)
        my_ciphertext_b64 = self._enc(my_values)

        r = self._http.post("/multi-party/joint-average", json={
            "context_b64":      self._public_ctx_b64,
            "ciphertext_a_b64": my_ciphertext_b64,
            "ciphertext_b_b64": other_party_ciphertext_b64,
            "n_a":              my_n,
            "n_b":              other_party_n,
            "scheme":           self.scheme,
            "party_a_label":    my_label,
            "party_b_label":    other_label,
        })
        if r.status_code != 200:
            raise RuntimeError(f"Joint-average failed: {r.status_code} {r.text[:300]}")

        return self._dec(r.json()["result_b64"])[0]
