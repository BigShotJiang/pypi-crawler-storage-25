"""Pydantic models for AgentGovern SDK action payloads and agent registration."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any
from uuid import UUID

from pydantic import BaseModel, Field


class Environment(str, Enum):
    PRODUCTION = "production"
    STAGING = "staging"
    DEVELOPMENT = "development"


class ActionType(str, Enum):
    TOOL_CALL = "tool_call"
    API_REQUEST = "api_request"
    DATA_ACCESS = "data_access"
    DECISION = "decision"
    MESSAGE = "message"
    CODE_EXECUTION = "code_execution"
    FILE_OPERATION = "file_operation"
    CUSTOM = "custom"
    TOOL_ORCHESTRATION = "tool_orchestration"  # LangGraph ToolNode coordination (STORY-085)
    CONTROL_FLOW = "control_flow"  # Pure routing/state-mutation step with no LLM or tool call


class ActionStatus(str, Enum):
    STARTED = "started"
    COMPLETED = "completed"
    FAILED = "failed"
    BLOCKED = "blocked"


class AgentRegistration(BaseModel):
    """Payload for POST /v1/ingest/agents/register."""

    external_id: str = Field(..., description="Your internal identifier for this agent")
    name: str
    description: str | None = None
    framework: str = "custom"
    framework_version: str | None = None
    environment: Environment = Environment.PRODUCTION
    owner_email: str | None = None
    tags: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class ActionRecord(BaseModel):
    """A single agent action to be ingested via POST /v1/ingest/actions."""

    agent_id: str
    action_type: ActionType
    action_name: str
    status: ActionStatus = ActionStatus.COMPLETED
    duration_ms: int | None = None
    model_id: str | None = None
    token_count: int | None = None
    trace_id: str | None = None
    span_id: str | None = None
    parent_action_id: UUID | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)
    timestamp: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc)
    )

    # Optional full payloads — increases ingest payload size
    input_payload: dict[str, Any] | None = None
    output_payload: dict[str, Any] | None = None
    reasoning_chain: dict[str, Any] | None = None


class BatchIngestPayload(BaseModel):
    """Batch request body for POST /v1/ingest/actions."""

    actions: list[ActionRecord] = Field(..., min_length=1, max_length=1000)


class HeartbeatResponse(BaseModel):
    """Response from POST /v1/ingest/heartbeat."""

    status: str
    agent_id: str | None = None
    environment: str | None = None
    pending_evaluations: int = 0


# ---------------------------------------------------------------------------
# Gate 1 evaluation types (synchronous input evaluation)
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class RuleViolation:
    """A single policy rule violation returned by Gate 1."""

    rule_code: str
    reason: str
    framework_ref: str | None = None
    enforcement_mode: str | None = None  # 'enforce'|'warn'|'log'|'disabled'


@dataclass(frozen=True)
class InputEvaluation:
    """Result of a Gate 1 synchronous input evaluation."""

    allowed: bool
    violations: list[RuleViolation] = field(default_factory=list)
    evaluation_id: str | None = None
    action_taken: str = "pass"  # 'pass' | 'warn' | 'block' (server 'log' → 'warn' client-side)
