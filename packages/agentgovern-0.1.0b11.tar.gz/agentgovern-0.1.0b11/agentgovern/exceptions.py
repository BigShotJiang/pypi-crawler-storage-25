"""AgentGovern SDK exceptions."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from agentgovern.types import InputEvaluation


class PolicyViolation(Exception):
    """
    Raised by Gate 1 when enforcement_mode=enforce and the input is blocked.

    Gate 2 (async ingest) never raises — it fails silently per the fail-open guarantee.
    """

    def __init__(self, evaluation: InputEvaluation) -> None:
        first = evaluation.violations[0] if evaluation.violations else None
        msg = first.reason if first else "Input blocked by compliance policy."
        super().__init__(msg)
        self.evaluation = evaluation

    @property
    def rule_code(self) -> str | None:
        return self.evaluation.violations[0].rule_code if self.evaluation.violations else None

    @property
    def reason(self) -> str:
        return str(self.args[0])

    @property
    def framework_ref(self) -> str | None:
        return self.evaluation.violations[0].framework_ref if self.evaluation.violations else None

    def __repr__(self) -> str:
        return (
            f"PolicyViolation(rule_code={self.rule_code!r}, "
            f"reason={self.reason!r}, "
            f"framework_ref={self.framework_ref!r})"
        )


class GateUnavailable(Exception):
    """
    Raised when Gate 1 is unreachable and fail_closed=True.

    With the default fail_closed=False, Gate 1 errors are silently treated as
    allowed=True so the agent continues unaffected.
    """


class OutputBlocked(Exception):  # noqa: N818
    """
    Raised by Gate 2 when the agent's output is blocked in enforce mode.

    The output is never returned to the caller. Catch this to handle a blocked
    response (e.g. show an error message, fall back to a safe default, log to
    your own audit trail).
    """

    def __init__(self, reason: str, *, evaluation_id: str | None = None) -> None:
        super().__init__(reason)
        self.reason = reason
        self.evaluation_id = evaluation_id

    def __repr__(self) -> str:
        return (
            f"OutputBlocked(reason={self.reason!r}, "
            f"evaluation_id={self.evaluation_id!r})"
        )


class OutputEscalated(Exception):  # noqa: N818
    """
    Raised by Gate 2 when the agent's output is escalated for human review.

    A review_queue row has been created. The output is held until a human
    approves or rejects it. Catch this to notify the caller that a review
    is in progress and surface the review_id so they can poll for a decision.
    """

    def __init__(self, review_id: str, *, evaluation_id: str | None = None) -> None:
        super().__init__(f"Output escalated for human review: {review_id}")
        self.review_id = review_id
        self.evaluation_id = evaluation_id

    def __repr__(self) -> str:
        return (
            f"OutputEscalated(review_id={self.review_id!r}, "
            f"evaluation_id={self.evaluation_id!r})"
        )


class ClientError(Exception):
    """
    Raised on 4xx responses from the AgentGovern API.

    This always propagates regardless of fail_silently — a 4xx indicates a
    configuration problem (wrong API key, invalid payload) that the caller
    should fix, not a transient network issue.
    """

    def __init__(self, message: str, *, status_code: int) -> None:
        super().__init__(message)
        self.status_code = status_code

    def __repr__(self) -> str:
        return f"ClientError(status_code={self.status_code}, message={str(self.args[0])!r})"
