"""
AgentGovern HTTP client with background batching, retry, and fail-open guarantees.

Design constraints:
- track_action() is synchronous and returns in < 5ms (deque-append only, no I/O)
- All HTTP I/O happens in a background daemon thread with its own asyncio event loop
- Flush triggers: every 1 second OR when buffer reaches 100 actions
- Retry: exponential backoff starting at 1s, doubling to max 30s
- After 3 consecutive failures, prints a warning to stderr (never raises)
- Buffer is capped at 10,000 actions; oldest entries dropped when full
- SDK NEVER raises exceptions into customer code (fail_silently=True by default)
"""

from __future__ import annotations

import asyncio
import collections
import json
import os
import sys
import threading
import time
from datetime import datetime, timezone
from typing import Any

import httpx
from pydantic import ValidationError

from agentgovern._version import __version__

from agentgovern.exceptions import ClientError, GateUnavailable, PolicyViolation
from agentgovern.types import (
    ActionRecord,
    ActionStatus,
    ActionType,
    AgentRegistration,
    BatchIngestPayload,
    Environment,
    HeartbeatResponse,
    InputEvaluation,
    RuleViolation,
)

def _iso_timestamp_utc(dt: datetime | None = None) -> str:
    """Return an RFC 3339 timestamp with Z suffix and millisecond precision.

    Zod's .datetime() validator requires exactly 3 fractional-second digits and
    a literal 'Z' suffix. Python's isoformat() produces 6-digit microseconds and
    '+00:00' — both rejected by the ingest endpoint's Zod schema.
    """
    if dt is None:
        dt = datetime.now(timezone.utc)
    elif dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    else:
        dt = dt.astimezone(timezone.utc)
    return dt.strftime('%Y-%m-%dT%H:%M:%S.') + f'{dt.microsecond // 1000:03d}Z'


_FLUSH_INTERVAL = 1.0       # seconds between automatic flushes
_BATCH_SIZE = 100            # flush early when buffer hits this
_BUFFER_MAXLEN = 10_000      # drop oldest when full
_WARN_AFTER_FAILURES = 3     # consecutive failures before stderr warning
_BACKOFF_BASE = 1.0          # initial retry delay in seconds
_BACKOFF_MAX = 30.0          # maximum retry delay in seconds


class AgentGovernClient:
    """
    Thread-safe AgentGovern ingest client.

    Usage::

        client = AgentGovernClient(api_key="ag_prod_...", environment="production")
        client.track_action(
            agent_external_id="my-agent",
            action_type=ActionType.TOOL_CALL,
            action_name="web_search",
        )
        client.shutdown()
    """

    def __init__(
        self,
        api_key: str,
        *,
        environment: str = "production",
        base_url: str = "https://agentgovern.zirahn.com",
        policy_engine_url: str | None = None,
        fail_silently: bool = True,
        batch_size: int = _BATCH_SIZE,
        flush_interval: float = _FLUSH_INTERVAL,
    ) -> None:
        self.api_key = api_key
        self.environment = environment
        self.base_url = base_url.rstrip("/")
        self.policy_engine_url = (
            (policy_engine_url or os.environ.get("AGENTGOVERN_POLICY_ENGINE_URL") or "https://agentgovern.onrender.com")
            .rstrip("/")
        )
        self.fail_silently = fail_silently
        self.batch_size = batch_size
        self.flush_interval = flush_interval

        self._buffer: collections.deque[ActionRecord] = collections.deque(
            maxlen=_BUFFER_MAXLEN
        )
        self._consecutive_failures = 0
        self._shutdown_event = threading.Event()
        self._loop: asyncio.AbstractEventLoop | None = None
        self._thread = threading.Thread(
            target=self._run_loop, name="agentgovern-flush", daemon=True
        )
        self._thread.start()

    # ------------------------------------------------------------------
    # Public sync API (hot path — must stay < 5ms)
    # ------------------------------------------------------------------

    def track_action(
        self,
        agent_external_id: str,
        action_type: ActionType,
        action_name: str,
        *,
        status: ActionStatus = ActionStatus.COMPLETED,
        duration_ms: int | None = None,
        input_payload: dict[str, Any] | None = None,
        output_payload: dict[str, Any] | None = None,
        model_id: str | None = None,
        token_count: int | None = None,
        trace_id: str | None = None,
        span_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """
        Enqueue an action record for async ingest. Returns immediately (<5ms).
        Never raises regardless of fail_silently setting.
        """
        try:
            record = ActionRecord(
                agent_id=agent_external_id,
                action_type=action_type,
                action_name=action_name,
                status=status,
                duration_ms=duration_ms,
                input_payload=input_payload,
                output_payload=output_payload,
                model_id=model_id,
                token_count=token_count,
                trace_id=trace_id,
                span_id=span_id,
                metadata=metadata or {},
            )
            self._buffer.append(record)
            if len(self._buffer) >= self.batch_size:
                self._trigger_flush()
        except Exception:  # noqa: BLE001
            pass  # fail-open always

    def register_agent(
        self,
        external_id: str,
        name: str,
        *,
        description: str | None = None,
        framework: str = "custom",
        framework_version: str | None = None,
        owner_email: str | None = None,
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Fire-and-forget agent registration. Never raises."""
        try:
            payload = AgentRegistration(
                external_id=external_id,
                name=name,
                description=description,
                framework=framework,
                framework_version=framework_version,
                environment=Environment(self.environment),
                owner_email=owner_email,
                tags=tags or [],
                metadata=metadata or {},
            )
            if self._loop is not None and self._loop.is_running():
                asyncio.run_coroutine_threadsafe(
                    self._post_register(payload), self._loop
                )
        except Exception:  # noqa: BLE001
            pass

    def heartbeat(self) -> dict[str, Any]:
        """
        Synchronous heartbeat — POSTs to /v1/ingest/heartbeat and returns the
        parsed response dict. Returns {"status": "error"} on failure.
        """
        try:
            with httpx.Client(
                headers=self._auth_headers(), timeout=5.0
            ) as client:
                resp = client.post(
                    f"{self.base_url}/api/v1/ingest/heartbeat",
                    json={"environment": self.environment},
                )
                resp.raise_for_status()
                return resp.json().get("data", resp.json())
        except Exception:  # noqa: BLE001
            return {"status": "error"}

    def evaluate_input(
        self,
        agent_external_id: str,
        prompt: str,
        *,
        context: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
        fail_closed: bool = False,
    ) -> InputEvaluation:
        """
        Gate 1 synchronous input evaluation. Call before passing a prompt to an LLM.

        Raises:
            PolicyViolation: when the input is blocked (allowed=false).
            GateUnavailable: only when fail_closed=True and the endpoint is unreachable.
            ClientError: on 4xx responses (misconfigured API key, bad payload).

        With fail_closed=False (default), any network or 5xx error returns
        InputEvaluation(allowed=True) so the agent continues unaffected.
        """
        body: dict[str, Any] = {
            "agent_id": agent_external_id,
            "input": {"prompt": prompt},
            "environment": self.environment,
        }
        if context:
            body["context"] = context
        if metadata:
            body["metadata"] = metadata

        try:
            with httpx.Client(headers=self._auth_headers(), timeout=5.0) as client:
                resp = client.post(
                    f"{self.policy_engine_url}/api/v1/evaluate/input",
                    json=body,
                )
                if 400 <= resp.status_code < 500:
                    raise ClientError(
                        f"AgentGovern Gate 1 returned {resp.status_code}: {resp.text[:200]}",
                        status_code=resp.status_code,
                    )
                resp.raise_for_status()
                data = resp.json().get("data", {})
        except (ClientError, PolicyViolation):
            raise
        except Exception as exc:
            if fail_closed:
                raise GateUnavailable(f"Gate 1 unavailable: {exc}") from exc
            return InputEvaluation(allowed=True)

        # Server is the authoritative source for action_taken.
        # Defensive default: if server hasn't shipped this field yet, treat as 'pass'
        # to avoid false blocks on stale deployments.
        raw_action = data.get("action_taken", "pass")
        # server's 'log' → SDK's 'warn' (client behavior is identical: log + continue)
        action_taken = "warn" if raw_action == "log" else raw_action

        evaluation = data.get("evaluation") or {}

        violations: list[RuleViolation] = []
        if action_taken != "pass":
            rule_code = evaluation.get("rule_code") or "UNKNOWN"
            reason = evaluation.get("reason") or "Policy violation."
            framework_ref = evaluation.get("framework") or None
            enforcement_mode = evaluation.get("enforcement_mode") or None
            violations.append(
                RuleViolation(
                    rule_code=rule_code,
                    reason=reason,
                    framework_ref=framework_ref,
                    enforcement_mode=enforcement_mode,
                )
            )

        result = InputEvaluation(
            allowed=action_taken != "block",
            violations=violations,
            evaluation_id=evaluation.get("policy_id"),
            action_taken=action_taken,
        )

        if action_taken == "block":
            raise PolicyViolation(result)

        return result

    def evaluate_output(
        self,
        agent_external_id: str,
        action_type: str,
        action_name: str,
        output_payload: dict[str, Any] | None = None,
        *,
        status: str = "completed",
        gate_2_enforcement_mode: str | None = None,
        gate_2_failure_mode: str = "fail_open",
        gate_2_timeout_ms: int = 500,
        metadata: dict[str, Any] | None = None,
    ) -> "Any":
        """
        Gate 2 synchronous output evaluation.

        Call after the agent produces output but before returning it to the caller.

        Returns a VerdictResult. Raises OutputBlocked in enforce+block mode.
        Raises OutputEscalated in enforce+escalate mode.
        When gate_2_enforcement_mode=None (default), returns allow immediately.
        """
        from agentgovern.gate2 import Gate2Config, VerdictHandler

        config = Gate2Config(
            enforcement_mode=gate_2_enforcement_mode,
            failure_mode=gate_2_failure_mode,
            timeout_ms=gate_2_timeout_ms,
        )
        handler = VerdictHandler(
            config=config,
            policy_engine_url=self.policy_engine_url,
            api_key=self.api_key,
            agent_id=agent_external_id,
            environment=self.environment,
        )
        return handler.evaluate(
            action_type=action_type,
            action_name=action_name,
            status=status,
            output_payload=output_payload,
            metadata=metadata,
        )

    def status(self) -> dict[str, Any]:
        return {
            "initialized": True,
            "environment": self.environment,
            "base_url": self.base_url,
            "policy_engine_url": self.policy_engine_url,
            "buffer_size": len(self._buffer),
            "consecutive_failures": self._consecutive_failures,
        }

    def shutdown(self, timeout: float = 5.0) -> None:
        """Flush remaining actions and stop the background thread."""
        self._shutdown_event.set()
        self._thread.join(timeout=timeout)

    # ------------------------------------------------------------------
    # Background thread / asyncio internals
    # ------------------------------------------------------------------

    def _run_loop(self) -> None:
        """Entry point for the background daemon thread."""
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        try:
            self._loop.run_until_complete(self._flush_loop())
        finally:
            self._loop.close()

    async def _flush_loop(self) -> None:
        """Periodically flush the buffer until shutdown."""
        while not self._shutdown_event.is_set():
            await asyncio.sleep(self.flush_interval)
            await self._flush()
        # Final flush on shutdown
        await self._flush()

    def _trigger_flush(self) -> None:
        """Schedule an early flush from the hot path (sync)."""
        if self._loop is not None and self._loop.is_running():
            asyncio.run_coroutine_threadsafe(self._flush(), self._loop)

    async def _flush(self) -> None:
        """Drain the buffer and POST to the ingest endpoint."""
        if not self._buffer:
            return

        batch: list[ActionRecord] = []
        while self._buffer and len(batch) < self.batch_size:
            try:
                batch.append(self._buffer.popleft())
            except IndexError:
                break

        if not batch:
            return

        delay = _BACKOFF_BASE
        for attempt in range(1, 4):  # up to 3 attempts per flush
            try:
                await self._post_batch(batch)
                self._consecutive_failures = 0
                return
            except httpx.HTTPStatusError as exc:
                self._consecutive_failures += 1
                if self._consecutive_failures >= _WARN_AFTER_FAILURES:
                    print(
                        f"[agentgovern] WARNING: {self._consecutive_failures} consecutive "
                        f"flush failures (HTTP {exc.response.status_code}: "
                        f"{exc.response.text[:200]}). Actions may be lost.",
                        file=sys.stderr,
                    )
                if attempt < 3:
                    await asyncio.sleep(min(delay, _BACKOFF_MAX))
                    delay = min(delay * 2, _BACKOFF_MAX)
            except Exception as exc:  # noqa: BLE001
                self._consecutive_failures += 1
                if self._consecutive_failures >= _WARN_AFTER_FAILURES:
                    print(
                        f"[agentgovern] WARNING: {self._consecutive_failures} consecutive "
                        f"flush failures ({type(exc).__name__}: {exc}). "
                        "Actions may be lost. Check your API key and network connectivity.",
                        file=sys.stderr,
                    )
                if attempt < 3:
                    await asyncio.sleep(min(delay, _BACKOFF_MAX))
                    delay = min(delay * 2, _BACKOFF_MAX)

    async def _post_batch(self, batch: list[ActionRecord]) -> None:
        actions = []
        for record in batch:
            d = record.model_dump(mode='json')

            # (1) Field rename: Pydantic model uses agent_id; server requires agent_external_id
            d['agent_external_id'] = d.pop('agent_id')

            # (2) Timestamp: Zod .datetime() requires Z suffix + ms precision (fixed in b3)
            d['timestamp'] = _iso_timestamp_utc(record.timestamp)

            # (3) Integer coercion: Zod number.int() rejects floats; LangChain may yield float
            if d.get('duration_ms') is not None:
                d['duration_ms'] = int(d['duration_ms'])
            if d.get('token_count') is not None:
                d['token_count'] = int(d['token_count'])

            # (4) Payload nesting: server expects payload.{input, output}; SDK has flat fields
            input_p = d.pop('input_payload', None)
            output_p = d.pop('output_payload', None)
            d.pop('reasoning_chain', None)  # server expects payload.reasoning: string, not dict
            payload_obj: dict[str, Any] = {}
            if input_p is not None:
                payload_obj['input'] = input_p
            if output_p is not None:
                payload_obj['output'] = output_p
            if payload_obj:
                d['payload'] = payload_obj

            # (5) Null stripping: Zod .optional() = absent key; null fails validation
            d = {k: v for k, v in d.items() if v is not None}

            actions.append(d)
        body = json.dumps({"actions": actions})
        async with httpx.AsyncClient(
            headers=self._auth_headers(), timeout=10.0
        ) as client:
            resp = await client.post(
                f"{self.base_url}/api/v1/ingest/actions",
                content=body,
                headers={"Content-Type": "application/json"},
            )
            resp.raise_for_status()

    async def _post_register(self, payload: AgentRegistration) -> None:
        try:
            async with httpx.AsyncClient(
                headers=self._auth_headers(), timeout=10.0
            ) as client:
                resp = await client.post(
                    f"{self.base_url}/api/v1/ingest/agents/register",
                    content=payload.model_dump_json(),
                    headers={"Content-Type": "application/json"},
                )
                resp.raise_for_status()
        except Exception:  # noqa: BLE001
            pass

    def _auth_headers(self) -> dict[str, str]:
        return {
            "X-API-Key": self.api_key,
            "User-Agent": f"agentgovern-python/{__version__}",
        }
