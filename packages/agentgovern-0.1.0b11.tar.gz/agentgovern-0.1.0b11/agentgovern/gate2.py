"""
Gate 2 synchronous output verdict handling.

VerdictHandler calls the policy engine and applies enforcement logic.
It has no knowledge of LangChain — it receives a plain dict payload and
returns a VerdictResult (or raises OutputBlocked / OutputEscalated).
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

import httpx

from agentgovern.exceptions import OutputBlocked, OutputEscalated

logger = logging.getLogger("agentgovern.gate2")


@dataclass(frozen=True)
class Gate2Config:
    """Per-agent Gate 2 configuration. None enforcement_mode = entirely disabled."""

    enforcement_mode: str | None  # None | "enforce" | "warn"
    failure_mode: str = "fail_open"  # "fail_open" | "fail_closed"
    timeout_ms: int = 500


@dataclass
class VerdictResult:
    """Result of a Gate 2 evaluation. Returned when no exception is raised."""

    verdict: str  # "allow" | "block" | "redact" | "escalate" | "error"
    allowed: bool
    redacted_output: dict[str, Any] | None = None
    review_id: str | None = None
    evaluation_ids: list[str] = field(default_factory=list)
    error: str | None = None  # set when policy engine was unreachable


class VerdictHandler:
    """
    Synchronous Gate 2 verdict handler.

    Call evaluate() after the agent produces output but before the output
    reaches the caller. Raises OutputBlocked or OutputEscalated in enforce
    mode. Returns VerdictResult in all other cases.
    """

    def __init__(
        self,
        config: Gate2Config,
        *,
        policy_engine_url: str,
        api_key: str,
        agent_id: str,
        environment: str = "production",
    ) -> None:
        self.config = config
        self.policy_engine_url = policy_engine_url.rstrip("/")
        self.api_key = api_key
        self.agent_id = agent_id
        self.environment = environment

    def evaluate(
        self,
        action_type: str,
        action_name: str,
        status: str,
        output_payload: dict[str, Any] | None,
        *,
        metadata: dict[str, Any] | None = None,
    ) -> VerdictResult:
        """
        Evaluate agent output against Gate 2 policies.

        Returns VerdictResult for allow / redact verdicts, and all warn-mode outcomes.
        Raises OutputBlocked for block verdict in enforce mode.
        Raises OutputEscalated for escalate verdict in enforce mode.
        """
        if self.config.enforcement_mode is None:
            return VerdictResult(verdict="allow", allowed=True)

        try:
            response = self._call_engine(
                action_type=action_type,
                action_name=action_name,
                status=status,
                output_payload=output_payload,
                metadata=metadata,
            )
        except Exception as exc:  # noqa: BLE001
            return self._handle_engine_error(str(exc))

        return self._apply_verdict(response)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _call_engine(
        self,
        *,
        action_type: str,
        action_name: str,
        status: str,
        output_payload: dict[str, Any] | None,
        metadata: dict[str, Any] | None,
    ) -> dict[str, Any]:
        timeout = self.config.timeout_ms / 1000.0
        body: dict[str, Any] = {
            "agent_id": self.agent_id,
            "environment": self.environment,
            "action": {
                "action_type": action_type,
                "action_name": action_name,
                "status": status,
                "output_payload": output_payload,
                "metadata": metadata or {},
            },
        }
        with httpx.Client(
            headers={"X-API-Key": self.api_key},
            timeout=timeout,
        ) as client:
            resp = client.post(
                f"{self.policy_engine_url}/api/v1/evaluate/action",
                json=body,
            )
            resp.raise_for_status()
            return resp.json()  # type: ignore[no-any-return]

    def _handle_engine_error(self, error: str) -> VerdictResult:
        logger.warning("Gate 2 policy engine unavailable: %s", error)
        # Warn mode: never raises even if fail_closed
        if self.config.enforcement_mode != "warn" and self.config.failure_mode == "fail_closed":
            raise OutputBlocked("policy engine unavailable")
        return VerdictResult(
            verdict="error",
            allowed=True,
            error=f"policy engine unavailable: {error}",
        )

    def _apply_verdict(self, response: dict[str, Any]) -> VerdictResult:
        data = response.get("data") or {}
        verdict = data.get("verdict", "allow")
        review_id = data.get("review_id")
        redacted_output = data.get("redacted_output")
        evaluations = data.get("evaluations") or []
        evaluation_ids = [
            str(e["policy_id"])
            for e in evaluations
            if e.get("policy_id")
        ]

        # Warn mode: log the verdict but never raise, never mutate output
        if self.config.enforcement_mode == "warn":
            logger.info(
                "Gate 2 [warn mode] verdict=%s agent=%s",
                verdict,
                self.agent_id,
            )
            return VerdictResult(
                verdict=verdict,
                allowed=True,
                evaluation_ids=evaluation_ids,
                review_id=review_id,
            )

        # Enforce mode
        if verdict == "allow":
            return VerdictResult(verdict="allow", allowed=True, evaluation_ids=evaluation_ids)

        if verdict == "block":
            reason = (
                (evaluations[0].get("reason") or "Policy violation")
                if evaluations
                else "Policy violation"
            )
            eval_id = evaluation_ids[0] if evaluation_ids else None
            raise OutputBlocked(reason, evaluation_id=eval_id)

        if verdict == "redact":
            return VerdictResult(
                verdict="redact",
                allowed=True,
                redacted_output=redacted_output,
                evaluation_ids=evaluation_ids,
            )

        if verdict == "escalate":
            eval_id = evaluation_ids[0] if evaluation_ids else None
            raise OutputEscalated(review_id or "", evaluation_id=eval_id)

        # Unknown verdict: fail-open, log for investigation
        logger.warning(
            "Gate 2: unknown verdict %r from policy engine, treating as allow",
            verdict,
        )
        return VerdictResult(verdict=verdict, allowed=True, evaluation_ids=evaluation_ids)
