"""
LangChain callback handler for AgentGovern (STORY-011).

Attaches to any LangChain chain or agent via the callbacks= parameter::

    from agentgovern.instrumentors.langchain import AgentGovernCallbackHandler

    handler = AgentGovernCallbackHandler(client=client, agent_external_id="my-agent")
    chain.invoke({"input": "..."}, config={"callbacks": [handler]})

Or via the module-level helper::

    import agentgovern
    agentgovern.init(api_key="ag_prod_...")
    handler = agentgovern.instrument_langchain("my-agent")

Requires the 'langchain' extra:
    pip install agentgovern[langchain]
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any
from uuid import UUID

# ---------------------------------------------------------------------------
# Conditional base class — inherits from BaseCallbackHandler when langchain-core
# is installed, falls back to object so the module is always importable.
# ---------------------------------------------------------------------------
try:
    from langchain_core.callbacks import BaseCallbackHandler as _BaseCallbackHandler
except ImportError:  # langchain-core not installed
    _BaseCallbackHandler = object  # type: ignore[misc,assignment]

if TYPE_CHECKING:
    from langchain_core.outputs import LLMResult

from agentgovern.client import AgentGovernClient
from agentgovern.exceptions import GateUnavailable, PolicyViolation
from agentgovern.gate2 import Gate2Config, VerdictHandler, VerdictResult
from agentgovern.instrumentors._base import BaseInstrumentor
from agentgovern.types import ActionStatus, ActionType


class AgentGovernCallbackHandler(BaseInstrumentor, _BaseCallbackHandler):
    """
    LangChain callback handler that records tool calls and LLM messages.

    Each LangChain run_id maps to a span_id. The parent_run_id becomes the
    trace_id so all spans within a single chain invocation are correlated.

    Gate 2 (synchronous output gating) fires in on_agent_finish when
    gate_2_enforcement_mode is set. Streaming agents are detected via
    on_llm_new_token and skip the sync gate (async path still runs).
    """

    def __init__(
        self,
        client: AgentGovernClient,
        agent_external_id: str | None = None,
        *,
        auto_evaluate_input: bool = True,
        fail_open: bool = True,
        gate_2_enforcement_mode: str | None = None,
        gate_2_failure_mode: str = "fail_open",
        gate_2_timeout_ms: int = 500,
    ) -> None:
        try:
            _BaseCallbackHandler.__init__(self)
        except TypeError:
            pass  # object.__init__ does not accept extra args

        BaseInstrumentor.__init__(
            self,
            client,
            agent_external_id or "",
            fail_open=fail_open,
        )

        self._auto_evaluate_input = auto_evaluate_input
        self._gate2_enforcement_mode = gate_2_enforcement_mode
        self._gate2_failure_mode = gate_2_failure_mode
        self._gate2_timeout_ms = gate_2_timeout_ms
        # LLM parent run_ids that had streaming tokens — used to skip sync Gate 2
        self._streaming_run_ids: set[str] = set()
        # Agent run_ids for which Gate 2 has already fired — prevents double evaluation
        self._gate2_evaluated_runs: set[str] = set()

    # ------------------------------------------------------------------
    # Tool events
    # ------------------------------------------------------------------

    def on_tool_start(
        self,
        serialized: dict[str, Any],
        input_str: str,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        with self._guard():
            tool_name = serialized.get("name", "unknown_tool")
            span_id = str(run_id)
            trace_id = str(parent_run_id) if parent_run_id else span_id
            record = self._start_span(
                span_id=span_id,
                trace_id=trace_id,
                action_type=ActionType.TOOL_CALL,
                action_name=tool_name,
                input_payload={"input": input_str} if input_str else {"input": ""},
                metadata={"framework": "langchain", "tool_name": tool_name},
            )
            record.extra["input_str"] = input_str

    def on_tool_end(
        self,
        output: Any,
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        with self._guard():
            span_id = str(run_id)
            info = self._peek_run(span_id)
            tool_name = info.get("action_name") or info.get("tool_name", "unknown_tool")
            self._finish_span(
                span_id=span_id,
                action_type=ActionType.TOOL_CALL,
                status=ActionStatus.COMPLETED,
                output_payload={"output": str(output)} if output is not None else None,
                metadata={"framework": "langchain", "tool_name": tool_name},
            )

    def on_tool_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        with self._guard():
            span_id = str(run_id)
            info = self._peek_run(span_id)
            tool_name = info.get("action_name") or info.get("tool_name", "unknown_tool")
            self._finish_span(
                span_id=span_id,
                action_type=ActionType.TOOL_CALL,
                status=ActionStatus.FAILED,
                metadata={"framework": "langchain", "tool_name": tool_name, "error": str(error)},
            )

    # ------------------------------------------------------------------
    # LLM events
    # ------------------------------------------------------------------

    def on_chat_model_start(
        self,
        serialized: dict[str, Any],
        messages: list[list[Any]],
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        if self._auto_evaluate_input:
            prompt_parts: list[str] = []
            for batch in messages:
                for msg in batch:
                    content = getattr(msg, "content", None)
                    if content:
                        prompt_parts.append(str(content))
            prompt = "\n".join(prompt_parts)[:4000]
            if prompt:
                model_name = (serialized.get("id") or ["unknown"])[-1]
                try:
                    self._client.evaluate_input(
                        self._agent_id,
                        prompt,
                        metadata={"model_id": model_name, "framework": "langchain"},
                        fail_closed=not self._fail_open,
                    )
                except PolicyViolation:
                    raise
                except GateUnavailable:
                    if not self._fail_open:
                        raise
                except Exception:  # noqa: BLE001
                    pass  # fail-open for unexpected errors

        self.on_llm_start(
            serialized,
            [str(msg) for batch in messages for msg in batch],
            run_id=run_id,
            parent_run_id=parent_run_id,
            **kwargs,
        )

    def on_llm_start(
        self,
        serialized: dict[str, Any],
        prompts: list[str],
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        with self._guard():
            model_name = (serialized.get("id") or ["unknown"])[-1]
            span_id = str(run_id)
            trace_id = str(parent_run_id) if parent_run_id else span_id
            self._start_span(
                span_id=span_id,
                trace_id=trace_id,
                action_type=ActionType.MESSAGE,
                action_name=f"llm/{model_name}",
                input_payload={"prompts": [str(p)[:2000] for p in prompts]} if prompts else {"prompts": []},
                metadata={"framework": "langchain", "model_id": model_name},
                model_id=model_name,
            )

    def on_llm_end(
        self,
        response: LLMResult,
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        with self._guard():
            span_id = str(run_id)
            info = self._peek_run(span_id)
            action_name = info.get("action_name", "")
            # action_name is "llm/<model>" from _start_span; legacy dict seeds use "model_id"
            if action_name.startswith("llm/"):
                model_id = action_name[4:]
            else:
                model_id = info.get("model_id", "unknown")

            token_count: int | None = None
            try:
                usage = response.llm_output or {}
                token_count = (
                    usage.get("token_usage", {}).get("total_tokens")
                    or usage.get("usage", {}).get("total_tokens")
                )
            except Exception:  # noqa: BLE001
                pass

            self._finish_span(
                span_id=span_id,
                action_type=ActionType.MESSAGE,
                status=ActionStatus.COMPLETED,
                output_payload=self._extract_llm_output(response),
                metadata={"framework": "langchain", "model_id": model_id},
                model_id=model_id,
                token_count=token_count,
            )

    def on_llm_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        with self._guard():
            span_id = str(run_id)
            info = self._peek_run(span_id)
            action_name = info.get("action_name", "")
            model_id = action_name[4:] if action_name.startswith("llm/") else info.get("model_id", "unknown")
            self._finish_span(
                span_id=span_id,
                action_type=ActionType.MESSAGE,
                status=ActionStatus.FAILED,
                metadata={"framework": "langchain", "model_id": model_id, "error": str(error)},
                model_id=model_id,
            )

    # ------------------------------------------------------------------
    # Streaming detection
    # ------------------------------------------------------------------

    def on_llm_new_token(
        self,
        token: str,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        # LangChain only calls this during streaming. Record the LLM's parent
        # so on_agent_finish can detect that the run involved streaming.
        if parent_run_id is not None:
            self._streaming_run_ids.add(str(parent_run_id))

    # ------------------------------------------------------------------
    # Gate 2 — agent and chain finish
    # ------------------------------------------------------------------

    def on_agent_finish(
        self,
        finish: Any,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        run_key = str(run_id)
        trace_id = str(parent_run_id) if parent_run_id else run_key
        output_text = str(finish.return_values.get("output", ""))

        # Always enqueue async ingest (fail-open, never raises)
        self._client.track_action(
            self._agent_id,
            ActionType.DECISION,
            "agent_output",
            status=ActionStatus.COMPLETED,
            output_payload={"output": output_text},
            trace_id=trace_id,
            span_id=run_key,
            metadata={"framework": "langchain"},
        )

        # Skip sync Gate 2 for streaming runs
        if run_key in self._streaming_run_ids:
            return

        if self._gate2_enforcement_mode is None:
            return

        self._gate2_evaluated_runs.add(run_key)
        result = self._intercept_output(output_text)

        # Transparent redact: mutate finish.return_values in-place before returning
        if result.verdict == "redact" and self._gate2_enforcement_mode == "enforce":
            if result.redacted_output is not None:
                finish.return_values["output"] = result.redacted_output.get(
                    "output", output_text
                )

    def on_chain_end(
        self,
        outputs: dict[str, Any],
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        # Fast exit for disabled agents — no cost for existing customers
        if self._gate2_enforcement_mode is None:
            return

        run_key = str(run_id)

        # Skip if on_agent_finish already handled Gate 2 for this run
        if run_key in self._gate2_evaluated_runs:
            return

        # Only fire for root chains (parent_run_id is None = outermost chain)
        if parent_run_id is not None:
            return

        # Skip streaming runs
        if run_key in self._streaming_run_ids:
            return

        # Extract output text from chain outputs
        raw_output = outputs.get("output", "")
        output_text = str(raw_output) if raw_output is not None else ""
        if not output_text:
            return

        self._gate2_evaluated_runs.add(run_key)
        result = self._intercept_output(output_text)

        # Transparent redact: mutate outputs dict in-place so caller receives masked content
        if result.verdict == "redact" and self._gate2_enforcement_mode == "enforce":
            if result.redacted_output is not None:
                outputs["output"] = result.redacted_output.get("output", output_text)

    # ------------------------------------------------------------------
    # Internal Gate 2 helper
    # ------------------------------------------------------------------

    def _intercept_output(self, output_text: str) -> VerdictResult:
        """Call the policy engine and apply the verdict. May raise OutputBlocked/OutputEscalated."""
        config = Gate2Config(
            enforcement_mode=self._gate2_enforcement_mode,
            failure_mode=self._gate2_failure_mode,
            timeout_ms=self._gate2_timeout_ms,
        )
        handler = VerdictHandler(
            config=config,
            policy_engine_url=self._client.policy_engine_url,
            api_key=self._client.api_key,
            agent_id=self._agent_id,
            environment=self._client.environment,
        )
        return handler.evaluate(
            action_type="decision",
            action_name="agent_output",
            status="completed",
            output_payload={"output": output_text},
            metadata={"framework": "langchain"},
        )
