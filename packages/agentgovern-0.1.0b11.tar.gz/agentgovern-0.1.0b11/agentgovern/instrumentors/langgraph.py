"""
LangGraph instrumentor for AgentGovern (STORY-017, STORY-085).

Attaches to any LangGraph StateGraph via the callbacks= parameter::

    from agentgovern.instrumentors.langgraph import AgentGovernLangGraphInstrumentor

    handler = AgentGovernLangGraphInstrumentor(client=client, agent_external_id="my-agent")
    graph.invoke({"input": "..."}, config={"callbacks": [handler]})

Or via the module-level helper::

    import agentgovern
    agentgovern.init(api_key="ag_prod_...")
    handler = agentgovern.instrument_langgraph("my-agent")

For state-delta tracking via stream mode::

    for chunk in graph.stream(input, stream_mode="updates"):
        handler.process_stream_event(chunk)

Requires the 'langgraph' extra:
    pip install agentgovern[langgraph]

Tested against langgraph>=1.0.0, langchain-core>=1.0.0.

Action-type classification (STORY-085, Option B)
-------------------------------------------------
STARTED spans always record action_type=DECISION (provisional — node output is not
yet known at on_chain_start time). COMPLETED spans use _classify_node_action_type()
to assign the correct type based on the node's output state:

    messages[-1].type == "tool"  → TOOL_ORCHESTRATION  (LangGraph ToolNode)
    messages[-1].type == "ai"    → DECISION             (LLM agent node)
    non-empty dict, no messages  → CONTROL_FLOW         (routing/state-mutation)
    fallback / error             → DECISION             (safe default)

The server upserts on (span_id, status), so the COMPLETED type wins over the
provisional DECISION written by the STARTED span. Historical rows created before
SDK 0.1.0b11 remain as DECISION (no backfill per Q4 decision).

Use ``node_type_overrides`` for explicit per-node overrides, bypassing the
content-based classifier entirely::

    handler = AgentGovernLangGraphInstrumentor(
        client=client,
        agent_external_id="my-agent",
        node_type_overrides={"summarise_node": "custom"},
    )

Phase 1 audit (docs/audit-reports/langgraph-coverage-2026-05-14.md) informed
all design decisions here. Key findings:
- on_chain_start fires for every node with name= kwarg (langchain-core 1.4+)
- graph:step:N tag discriminates node executions from routing functions
- graph root run_id must be used as trace_id for all events in one invocation
- state_keys_modified is derivable from on_chain_start/on_chain_end input/output diff
"""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING, Any
from uuid import UUID

# ---------------------------------------------------------------------------
# Conditional base class — inherits from BaseCallbackHandler when langchain-core
# is installed, falls back to object so the module is always importable.
# ---------------------------------------------------------------------------
try:
    from langchain_core.callbacks import BaseCallbackHandler as _BaseCallbackHandler
except ImportError:  # langchain-core not installed
    _BaseCallbackHandler = object  # type: ignore[misc,assignment]

if TYPE_CHECKING:
    from langchain_core.outputs import LLMResult

from agentgovern.client import AgentGovernClient
from agentgovern.exceptions import GateUnavailable, PolicyViolation
from agentgovern.gate2 import Gate2Config, VerdictHandler, VerdictResult
from agentgovern.instrumentors._base import BaseInstrumentor
from agentgovern.types import ActionStatus, ActionType

logger = logging.getLogger("agentgovern.langgraph")

# LangGraph tags that distinguish real graph node executions from sub-chains.
_GRAPH_NODE_TAG_PREFIX = "graph:step:"
# LangGraph name for the root graph run.
_LANGGRAPH_ROOT_NAME = "LangGraph"
# Maximum Gate 2 payload size sent to the policy engine.
# Graphs with large state (document chunks, embeddings) can produce payloads
# that exceed engine request limits or the gate_2_timeout_ms deadline, causing
# silent fail-open. Truncate with a warning instead.
_GATE2_MAX_PAYLOAD_BYTES = 65536  # 64KB


class AgentGovernLangGraphInstrumentor(BaseInstrumentor, _BaseCallbackHandler):
    """
    LangGraph instrumentor that records node transitions, tool calls, LLM calls,
    state mutations, and (optionally) stream-mode state deltas.

    STARTED spans use action_type=DECISION (provisional). COMPLETED spans are
    classified by _classify_node_action_type() using the node's output state
    (Option B — see module docstring). This means ToolNode spans receive
    TOOL_ORCHESTRATION and routing nodes receive CONTROL_FLOW in the audit trail.

    Tool calls and LLM calls within a node become child spans that all share
    the graph_run_id as their trace_id — ensuring a single invocation produces
    one correlated trace regardless of how many nodes it visits.

    Identifier conventions (LangGraph-specific):
    - graph_run_id (the root LangGraph on_chain_start run_id) → trace_id
    - node run_id (on_chain_start with graph:step:N tag) → span_id
    - tool/LLM run_ids within a node → child span_ids, same graph_run_id trace_id

    Graph topology metadata per node span:
    - node_id: the LangGraph node name (e.g. "triage_node")
    - node_type: always "function" (subgraph support deferred)
    - previous_node_id: the preceding node in execution order, or None for the first
    - state_keys_modified: state keys this node added or changed

    Gate 2 fires when the root LangGraph run completes (on_chain_end with
    parent_run_id=None). The entire final state dict is passed as the output payload.

    See docs/audit-reports/langgraph-coverage-2026-05-14.md for the full
    Phase 1 findings that determined this design.
    """

    def __init__(
        self,
        client: AgentGovernClient,
        agent_external_id: str | None = None,
        *,
        auto_evaluate_input: bool = True,
        fail_open: bool = True,
        gate_2_enforcement_mode: str | None = None,
        gate_2_failure_mode: str = "fail_open",
        gate_2_timeout_ms: int = 500,
        node_type_overrides: dict[str, str] | None = None,
    ) -> None:
        try:
            _BaseCallbackHandler.__init__(self)
        except TypeError:
            pass  # object.__init__ does not accept extra args

        BaseInstrumentor.__init__(
            self,
            client,
            agent_external_id or "",
            fail_open=fail_open,
        )

        if node_type_overrides:
            valid_values = {at.value for at in ActionType}
            for node_name_key, at_val in node_type_overrides.items():
                if at_val not in valid_values:
                    raise ValueError(
                        f"node_type_overrides[{node_name_key!r}] = {at_val!r} is not a valid "
                        f"ActionType value. Valid values: {sorted(valid_values)}"
                    )

        self._auto_evaluate_input = auto_evaluate_input
        self._gate2_enforcement_mode = gate_2_enforcement_mode
        self._gate2_failure_mode = gate_2_failure_mode
        self._gate2_timeout_ms = gate_2_timeout_ms
        self._node_type_overrides: dict[str, str] | None = node_type_overrides

        # Maps any chain run_id → its root graph_run_id.
        # Populated in on_chain_start; used by tool/LLM hooks to set trace_id.
        self._graph_run_ids: dict[str, str] = {}

        # Maps graph_run_id → ordered list of (step_number, node_name).
        # Used to compute previous_node_id for each node span.
        self._step_sequences: dict[str, list[tuple[int, str]]] = {}

        # Graph run_ids for which Gate 2 has already fired — prevents double eval.
        self._gate2_evaluated_runs: set[str] = set()

    # ------------------------------------------------------------------
    # Chain events — capture graph structure
    # ------------------------------------------------------------------

    def on_chain_start(
        self,
        serialized: dict[str, Any],
        inputs: dict[str, Any],
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        tags: list[str] | None = None,
        name: str | None = None,
        **kwargs: Any,
    ) -> None:
        run_key = str(run_id)
        parent_key = str(parent_run_id) if parent_run_id else None
        tags = tags or []
        # langchain-core 1.4+ passes the node name via name=; older versions use serialized
        node_name = name or (serialized or {}).get("id", ["unknown"])[-1]

        # --- Root graph invocation ---
        if parent_run_id is None:
            # Store this run as its own graph root. No span — it is the trace container.
            self._graph_run_ids[run_key] = run_key
            self._step_sequences[run_key] = []
            return

        # --- All other chain runs: inherit graph_run_id from parent ---
        graph_run_id = self._graph_run_ids.get(parent_key, parent_key or run_key)
        self._graph_run_ids[run_key] = graph_run_id

        # Only record spans for actual graph node executions (graph:step:N tag).
        # Routing functions (seq:step:N) and other sub-chains are skipped.
        if not any(t.startswith(_GRAPH_NODE_TAG_PREFIX) for t in tags):
            return

        # --- Node execution span ---
        with self._guard():
            step_num = _extract_step_number(tags, _GRAPH_NODE_TAG_PREFIX)

            # Compute previous_node_id from execution sequence
            seq = self._step_sequences.get(graph_run_id, [])
            previous_node_id: str | None = seq[-1][1] if seq else None

            # Record this node in the sequence
            seq.append((step_num, node_name))
            self._step_sequences[graph_run_id] = seq

            # Stash input state for state_keys_modified computation in on_chain_end
            input_state = dict(inputs) if isinstance(inputs, dict) else {}

            record = self._start_span(
                span_id=run_key,
                trace_id=graph_run_id,
                action_type=ActionType.DECISION,
                action_name=node_name,
                input_payload={"state_keys": sorted(input_state.keys())} if input_state else None,
                metadata={
                    "framework": "langgraph",
                    "node_id": node_name,
                    "node_type": "function",
                    "previous_node_id": previous_node_id,
                    "state_keys_modified": [],
                },
            )
            record.extra["node_name"] = node_name
            record.extra["input_state"] = input_state
            record.extra["graph_run_id"] = graph_run_id

    def on_chain_end(
        self,
        outputs: dict[str, Any],
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        run_key = str(run_id)

        # --- Root graph completion: fire Gate 2 and clean up ---
        if parent_run_id is None:
            self._handle_root_graph_end(run_key, outputs)
            self._step_sequences.pop(run_key, None)
            self._graph_run_ids.pop(run_key, None)
            self._gate2_evaluated_runs.discard(run_key)
            return

        # --- Node span completion ---
        info = self._peek_run(run_key)
        if not info:
            # Routing function or sub-chain we didn't track — just clean up mapping
            self._graph_run_ids.pop(run_key, None)
            return

        with self._guard():
            input_state: dict[str, Any] = info.get("input_state", {})
            node_name_from_record: str | None = info.get("node_name") or info.get("action_name")

            # Classify this node's action_type from its output content (Option B).
            classified_type = self._classify_node_action_type(
                outputs,
                node_name=node_name_from_record,
                overrides=self._node_type_overrides,
            )

            # Compute which state keys this node added or mutated
            if isinstance(outputs, dict):
                state_keys_modified = sorted(
                    k for k in outputs
                    if k not in input_state or outputs[k] != input_state.get(k)
                )
            else:
                state_keys_modified = []

            serialized_state = (
                self._serialize_state(outputs) if isinstance(outputs, dict) else None
            )
            node_output_payload: dict[str, Any] | None = None
            if state_keys_modified or serialized_state is not None:
                node_output_payload = {}
                if state_keys_modified:
                    node_output_payload["state_keys_modified"] = state_keys_modified
                if serialized_state is not None:
                    node_output_payload["state_values"] = serialized_state

            self._finish_span(
                span_id=run_key,
                action_type=classified_type,
                status=ActionStatus.COMPLETED,
                output_payload=node_output_payload,
                metadata={
                    "framework": "langgraph",
                    "node_id": info.get("action_name", "unknown"),
                    "state_keys_modified": state_keys_modified,
                },
            )

        self._graph_run_ids.pop(run_key, None)

    def on_chain_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        run_key = str(run_id)
        info = self._peek_run(run_key)
        if not info:
            # Root graph error (parent_run_id=None) or untracked sub-chain.
            # Mirror the on_chain_end cleanup to prevent state leaks.
            self._step_sequences.pop(run_key, None)
            self._graph_run_ids.pop(run_key, None)
            self._gate2_evaluated_runs.discard(run_key)
            return

        with self._guard():
            node_name_err: str | None = info.get("node_name") or info.get("action_name")
            # No output available on error — apply override if present, else DECISION.
            error_type = self._classify_node_action_type(
                None,
                node_name=node_name_err,
                overrides=self._node_type_overrides,
            )
            self._finish_span(
                span_id=run_key,
                action_type=error_type,
                status=ActionStatus.FAILED,
                metadata={
                    "framework": "langgraph",
                    "node_id": info.get("action_name", "unknown"),
                    "error": str(error)[:200],
                },
            )

        self._graph_run_ids.pop(run_key, None)

    # ------------------------------------------------------------------
    # Tool events
    # ------------------------------------------------------------------

    def on_tool_start(
        self,
        serialized: dict[str, Any],
        input_str: str,
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        name: str | None = None,
        **kwargs: Any,
    ) -> None:
        with self._guard():
            tool_name = name or (serialized or {}).get("name", "unknown_tool")
            span_id = str(run_id)
            # Use graph_run_id from the calling node as trace_id — not the node run_id.
            # This is the critical fix over the plain LangChain handler, which would use
            # the node's run_id as trace_id and fragment multi-node traces.
            trace_id = self._graph_run_ids.get(str(parent_run_id)) if parent_run_id else None
            if trace_id is None:
                trace_id = span_id
            record = self._start_span(
                span_id=span_id,
                trace_id=trace_id,
                action_type=ActionType.TOOL_CALL,
                action_name=tool_name,
                input_payload={"input": input_str} if input_str else {"input": ""},
                metadata={"framework": "langgraph", "tool_name": tool_name},
            )
            record.extra["input_str"] = input_str

    def on_tool_end(
        self,
        output: Any,
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        with self._guard():
            span_id = str(run_id)
            info = self._peek_run(span_id)
            tool_name = info.get("action_name", "unknown_tool")
            self._finish_span(
                span_id=span_id,
                action_type=ActionType.TOOL_CALL,
                status=ActionStatus.COMPLETED,
                output_payload={"output": str(output)} if output is not None else None,
                metadata={"framework": "langgraph", "tool_name": tool_name},
            )

    def on_tool_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        with self._guard():
            span_id = str(run_id)
            info = self._peek_run(span_id)
            tool_name = info.get("action_name", "unknown_tool")
            self._finish_span(
                span_id=span_id,
                action_type=ActionType.TOOL_CALL,
                status=ActionStatus.FAILED,
                metadata={"framework": "langgraph", "tool_name": tool_name, "error": str(error)},
            )

    # ------------------------------------------------------------------
    # LLM events
    # ------------------------------------------------------------------

    def on_chat_model_start(
        self,
        serialized: dict[str, Any],
        messages: list[list[Any]],
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        if self._auto_evaluate_input:
            prompt_parts: list[str] = []
            for batch in messages:
                for msg in batch:
                    content = getattr(msg, "content", None)
                    if content:
                        prompt_parts.append(str(content))
            prompt = "\n".join(prompt_parts)[:4000]
            if prompt:
                model_name = (serialized.get("id") or ["unknown"])[-1]
                try:
                    self._client.evaluate_input(
                        self._agent_id,
                        prompt,
                        metadata={"model_id": model_name, "framework": "langgraph"},
                        fail_closed=not self._fail_open,
                    )
                except PolicyViolation:
                    raise
                except GateUnavailable:
                    if not self._fail_open:
                        raise
                except Exception:  # noqa: BLE001
                    pass

        self.on_llm_start(
            serialized,
            [str(msg) for batch in messages for msg in batch],
            run_id=run_id,
            parent_run_id=parent_run_id,
            **kwargs,
        )

    def on_llm_start(
        self,
        serialized: dict[str, Any],
        prompts: list[str],
        *,
        run_id: UUID,
        parent_run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        with self._guard():
            model_name = (serialized.get("id") or ["unknown"])[-1]
            span_id = str(run_id)
            # Same trace_id fix as tool calls: use graph_run_id, not node run_id
            trace_id = self._graph_run_ids.get(str(parent_run_id)) if parent_run_id else None
            if trace_id is None:
                trace_id = span_id
            self._start_span(
                span_id=span_id,
                trace_id=trace_id,
                action_type=ActionType.MESSAGE,
                action_name=f"llm/{model_name}",
                input_payload=(
                    {"prompts": [str(p)[:2000] for p in prompts]} if prompts else {"prompts": []}
                ),
                metadata={"framework": "langgraph", "model_id": model_name},
                model_id=model_name,
            )

    def on_llm_end(
        self,
        response: LLMResult,
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        with self._guard():
            span_id = str(run_id)
            info = self._peek_run(span_id)
            action_name = info.get("action_name", "")
            model_id = (
                action_name[4:] if action_name.startswith("llm/")
                else info.get("model_id", "unknown")
            )

            token_count: int | None = None
            try:
                usage = response.llm_output or {}
                token_count = (
                    usage.get("token_usage", {}).get("total_tokens")
                    or usage.get("usage", {}).get("total_tokens")
                )
            except Exception:  # noqa: BLE001
                pass

            self._finish_span(
                span_id=span_id,
                action_type=ActionType.MESSAGE,
                status=ActionStatus.COMPLETED,
                output_payload=self._extract_llm_output(response),
                metadata={"framework": "langgraph", "model_id": model_id},
                model_id=model_id,
                token_count=token_count,
            )

    def on_llm_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        **kwargs: Any,
    ) -> None:
        with self._guard():
            span_id = str(run_id)
            info = self._peek_run(span_id)
            action_name = info.get("action_name", "")
            model_id = (
                action_name[4:] if action_name.startswith("llm/")
                else info.get("model_id", "unknown")
            )
            self._finish_span(
                span_id=span_id,
                action_type=ActionType.MESSAGE,
                status=ActionStatus.FAILED,
                metadata={"framework": "langgraph", "model_id": model_id, "error": str(error)},
                model_id=model_id,
            )

    # ------------------------------------------------------------------
    # Stream event processing (supplemental path)
    # ------------------------------------------------------------------

    def process_stream_event(self, event: dict[str, Any]) -> None:
        """
        Process a LangGraph stream chunk for graph-topology state-delta tracking.

        Handles graph.stream(stream_mode='updates') chunks::

            for chunk in graph.stream(input, stream_mode='updates'):
                handler.process_stream_event(chunk)

        Each chunk has the shape ``{"node_name": {modified_key: new_value, ...}}``.
        This method records a CUSTOM action containing the exact set of state keys
        each node modified, derived directly from LangGraph's output rather than
        from the input/output diffing the callback path uses.

        This path is optional and supplemental. The callback path (on_chain_start /
        on_chain_end) already captures state_keys_modified via diffing. Use this
        for higher-fidelity state tracking when using graph.stream() instead of invoke().

        Note: astream_events v2 events (``event.get('event') == 'on_chain_start'``
        etc.) are already handled by the standard callback path when the handler is
        passed via ``config={'callbacks': [handler]}``. Do not pass astream_events
        dicts here — this method ignores them.
        """
        with self._guard():
            # Ignore astream_events v2 format — those fire callbacks automatically
            if "event" in event:
                logger.debug(
                    "process_stream_event: ignoring astream_events event (use callbacks path)"
                )
                return

            # Handle stream_mode='updates' chunks: {node_name: {state_delta}}
            for node_name, state_delta in event.items():
                if not isinstance(state_delta, dict):
                    continue
                state_keys_modified = sorted(state_delta.keys())
                self._client.track_action(
                    self._agent_id,
                    ActionType.CUSTOM,
                    f"state_delta/{node_name}",
                    status=ActionStatus.COMPLETED,
                    metadata={
                        "framework": "langgraph",
                        "node_id": node_name,
                        "state_keys_modified": state_keys_modified,
                        "source": "stream_updates",
                    },
                )

    # ------------------------------------------------------------------
    # Gate 2 — root graph completion
    # ------------------------------------------------------------------

    def _handle_root_graph_end(self, run_key: str, outputs: dict[str, Any]) -> None:
        """Fire Gate 2 evaluation when the root LangGraph run completes."""
        if self._gate2_enforcement_mode is None:
            return
        if run_key in self._gate2_evaluated_runs:
            return
        self._gate2_evaluated_runs.add(run_key)

        if isinstance(outputs, dict):
            try:
                output_text = json.dumps(outputs, default=str)
            except Exception:  # noqa: BLE001
                output_text = str(outputs)
        else:
            output_text = str(outputs)

        if not output_text:
            return

        if len(output_text) > _GATE2_MAX_PAYLOAD_BYTES:
            logger.warning(
                "Gate 2 payload truncated from %d to %d bytes — large graph state "
                "may indicate more output than the policy engine should evaluate.",
                len(output_text),
                _GATE2_MAX_PAYLOAD_BYTES,
            )
            output_text = output_text[:_GATE2_MAX_PAYLOAD_BYTES]

        self._intercept_output(output_text)

    def _intercept_output(self, output_text: str) -> VerdictResult:
        """Call the policy engine and apply the Gate 2 verdict."""
        config = Gate2Config(
            enforcement_mode=self._gate2_enforcement_mode,
            failure_mode=self._gate2_failure_mode,
            timeout_ms=self._gate2_timeout_ms,
        )
        handler = VerdictHandler(
            config=config,
            policy_engine_url=self._client.policy_engine_url,
            api_key=self._client.api_key,
            agent_id=self._agent_id,
            environment=self._client.environment,
        )
        return handler.evaluate(
            action_type="decision",
            action_name="graph_output",
            status="completed",
            output_payload={"output": output_text},
            metadata={"framework": "langgraph"},
        )


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------


def _extract_step_number(tags: list[str], prefix: str) -> int:
    """Extract the integer N from a tag like 'graph:step:N'. Returns 0 if not found."""
    for tag in tags:
        if tag.startswith(prefix):
            try:
                return int(tag.split(":")[-1])
            except ValueError:
                pass
    return 0
