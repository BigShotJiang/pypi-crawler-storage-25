"""
BaseInstrumentor — framework-agnostic foundation for AgentGovern SDK instrumentors.

Overview
--------
AgentGovern intercepts AI agent actions at the framework layer: LangChain callbacks,
OpenAI Agents API event hooks, CrewAI lifecycle hooks, etc. Each framework exposes a
different hook surface, but the *data model* is identical across all of them:

    - A **trace** is one top-level agent invocation (one user request → one agent run).
    - A **span** is one observable event within that trace (tool call, LLM message, decision).
    - trace_id and span_id are derived from the framework's native run identifiers.

BaseInstrumentor owns everything that is framework-agnostic:

    - The AgentGovernClient reference and the agent_external_id.
    - The in-flight run map (span_id → RunRecord), which tracks start_time, trace_id,
      and framework-specific metadata for each in-flight span.
    - Shared helpers: _start_span() and _finish_span() that call client.track_action()
      with the correct ActionType, ActionStatus, and metadata.
    - The fail-open contract: _guard() wraps any block that might raise so that
      instrumentor errors never propagate into the customer's agent framework.

Subclassing contract
--------------------
A new instrumentor MUST:

1. Inherit from BaseInstrumentor (and, if required, from the framework's own base class).
2. Call super().__init__(client, agent_external_id, fail_open=...) first.
3. Map the framework's native run-identifier hierarchy to (trace_id, span_id) by
   following the convention described in ``_derive_ids()``.
4. Call ``self._start_span()`` at the start of each observable event.
5. Call ``self._finish_span()`` at the end (or error) of each observable event.
6. Wrap every framework hook body in ``with self._guard():`` so that SDK errors never
   surface to the framework and crash the customer's agent.
7. Never raise from a framework hook (this is the fail-open contract).

Trace/span identifier conventions
----------------------------------
Every framework has a native concept of a "run" with a unique identifier. The mapping
to AgentGovern's model is:

    - ``span_id``:   the current run's native identifier, stringified.
    - ``trace_id``:  the *parent* run's native identifier (if one exists), or the
                     current run's identifier if the run is the root.

This mirrors the LangChain implementation:
    ``trace_id = str(parent_run_id) if parent_run_id else str(run_id)``

Frameworks without an explicit parent hierarchy (e.g., CrewAI task-level hooks)
should synthesize a stable trace_id from the agent/crew's session identifier so
that spans from a single invocation remain correlated.

Fail-open behavior contract
----------------------------
``_guard()`` is a context manager that catches all exceptions raised inside its block,
logs them at DEBUG level (never ERROR — to avoid polluting customer logs), and returns
normally. The customer's agent execution must never be affected by AgentGovern errors.

The only exception to fail-open behavior is ``PolicyViolation``: when raised by the
policy engine, it represents a deliberate gate and MUST propagate. ``_guard()`` re-raises
``PolicyViolation`` (and ``GateUnavailable`` when the instrumentor is configured
``fail_open=False``). All other exceptions are swallowed.

Patent reference (Claim 6)
--------------------------
This abstraction directly implements the "extensible hook pattern" described in the
patent application: a framework-agnostic base class with a stable contract for
framework-specific subclasses, enabling new framework integrations without modifying
the core SDK or policy engine. The _start_span / _finish_span helpers correspond to
the "structured observation points" claimed in the hook pattern.
"""

from __future__ import annotations

import json
import logging
import time
from abc import ABC
from contextlib import contextmanager
from typing import Any, Generator

from agentgovern.client import AgentGovernClient
from agentgovern.exceptions import GateUnavailable, PolicyViolation
from agentgovern.types import ActionStatus, ActionType

logger = logging.getLogger(__name__)


class RunRecord:
    """State held for one in-flight span, from hook start to hook end/error."""

    __slots__ = ("start_time", "trace_id", "action_name", "extra")

    def __init__(
        self,
        *,
        start_time: float,
        trace_id: str,
        action_name: str,
        extra: dict[str, Any] | None = None,
    ) -> None:
        self.start_time = start_time
        self.trace_id = trace_id
        self.action_name = action_name
        self.extra = extra or {}


class BaseInstrumentor(ABC):
    """
    Abstract base class for all AgentGovern framework instrumentors.

    Subclasses inherit:
    - _client: AgentGovernClient — the shared HTTP client
    - _agent_id: str — the customer's agent identifier
    - _fail_open: bool — whether unexpected errors are swallowed (True) or raised (False)
    - _runs: dict[str, RunRecord] — the in-flight span registry
    - _start_span() — record the start of an observable event
    - _finish_span() — record the completion or failure of an observable event
    - _guard() — context manager that enforces fail-open behavior
    - _elapsed_ms() — compute duration from a RunRecord start_time

    Subclasses MUST provide:
    - Their own __init__ (must call super().__init__() first)
    - Framework-specific hook methods that call _start_span/_finish_span within _guard()
    """

    def __init__(
        self,
        client: AgentGovernClient,
        agent_external_id: str,
        *,
        fail_open: bool = True,
    ) -> None:
        """
        Parameters
        ----------
        client:
            Initialized AgentGovernClient. The instrumentor does not own the client's
            lifecycle; callers are responsible for flush-on-shutdown.
        agent_external_id:
            The stable identifier for the agent being instrumented. Must match the
            agent registered with AgentGovern (used for policy lookup and audit trail).
        fail_open:
            If True (default), unexpected SDK errors are logged at DEBUG and swallowed
            so that the customer's agent continues running. If False, errors propagate
            (useful for testing). PolicyViolation is always re-raised regardless of
            this setting.
        """
        if not agent_external_id:
            raise ValueError(
                f"{type(self).__name__} requires agent_external_id. "
                "Pass it explicitly or use the agentgovern.instrument_*() helpers."
            )
        self._client = client
        self._agent_id = agent_external_id
        self._fail_open = fail_open
        # span_id (str) → RunRecord for all in-flight spans
        self._runs: dict[str, RunRecord] = {}

    # ------------------------------------------------------------------
    # Shared span lifecycle helpers
    # ------------------------------------------------------------------

    def _start_span(
        self,
        *,
        span_id: str,
        trace_id: str,
        action_type: ActionType,
        action_name: str,
        input_payload: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
        model_id: str | None = None,
    ) -> RunRecord:
        """
        Record the start of an observable event and register it in the run map.

        Stores a RunRecord keyed by span_id so that _finish_span can compute the
        elapsed duration and retrieve the trace_id without requiring the framework
        to re-supply it on the end hook.

        Returns the RunRecord so subclasses can attach extra framework-specific data
        (e.g., ``record.extra["input_str"] = input_str``).
        """
        record = RunRecord(
            start_time=time.monotonic(),
            trace_id=trace_id,
            action_name=action_name,
        )
        self._runs[span_id] = record

        self._client.track_action(
            self._agent_id,
            action_type,
            action_name,
            status=ActionStatus.STARTED,
            trace_id=trace_id,
            span_id=span_id,
            input_payload=input_payload,
            metadata=metadata,
            model_id=model_id,
        )
        return record

    def _finish_span(
        self,
        *,
        span_id: str,
        action_type: ActionType,
        status: ActionStatus,
        output_payload: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
        model_id: str | None = None,
        token_count: int | None = None,
    ) -> RunRecord | None:
        """
        Record the completion or failure of an observable event and remove it from
        the run map.

        Returns the RunRecord (for callers that need extra data), or None if the
        span_id was not found (e.g., missed on_start due to import-order issues).

        Accepts both RunRecord objects (normal path) and plain dicts (for tests
        that seed _runs directly to isolate end-hook behaviour).
        """
        raw = self._runs.pop(span_id, None)
        record: RunRecord | None

        if isinstance(raw, RunRecord):
            record = raw
            duration_ms = self._elapsed_ms(record.start_time)
            trace_id = record.trace_id
            action_name = record.action_name
        elif isinstance(raw, dict):
            # Backward-compat: tests may seed _runs with plain dicts
            record = None
            duration_ms = self._elapsed_ms(raw.get("start_time"))
            trace_id = raw.get("trace_id")
            action_name = raw.get("tool_name") or raw.get("model_id") or span_id
        else:
            record = None
            duration_ms = None
            trace_id = None
            action_name = span_id

        self._client.track_action(
            self._agent_id,
            action_type,
            action_name,
            status=status,
            duration_ms=duration_ms,
            trace_id=trace_id,
            span_id=span_id,
            output_payload=output_payload,
            metadata=metadata,
            model_id=model_id,
            token_count=token_count,
        )
        return record

    def _peek_run(self, span_id: str) -> dict[str, Any]:
        """
        Return a plain-dict view of the in-flight run record for span_id, or {}
        if the span was not found.

        Normalises both RunRecord objects and legacy plain-dict entries so
        callers can use dict key access uniformly before calling _finish_span.
        """
        raw = self._runs.get(span_id)
        if isinstance(raw, RunRecord):
            return {"action_name": raw.action_name, "trace_id": raw.trace_id, **raw.extra}
        if isinstance(raw, dict):
            return raw
        return {}

    # ------------------------------------------------------------------
    # Fail-open guard
    # ------------------------------------------------------------------

    @contextmanager
    def _guard(self) -> Generator[None, None, None]:
        """
        Context manager that enforces the fail-open contract.

        Usage::

            def on_tool_start(self, ...) -> None:
                with self._guard():
                    span_id = str(run_id)
                    trace_id = str(parent_run_id) if parent_run_id else span_id
                    self._start_span(span_id=span_id, trace_id=trace_id, ...)

        Behavior:
        - PolicyViolation: always re-raised (it is an intentional gate, not an error).
        - GateUnavailable: re-raised when fail_open=False; swallowed when fail_open=True.
        - All other exceptions: swallowed when fail_open=True; re-raised when fail_open=False.
        """
        try:
            yield
        except PolicyViolation:
            raise
        except GateUnavailable:
            if not self._fail_open:
                raise
        except Exception:  # noqa: BLE001
            if not self._fail_open:
                raise
            logger.debug(
                "AgentGovern instrumentor error suppressed (fail_open=True)",
                exc_info=True,
            )

    # ------------------------------------------------------------------
    # Output extraction helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _extract_llm_output(response: Any) -> dict[str, Any] | None:
        """
        Extract a structured output dict from a LangChain LLMResult.

        Handles both plain Generation (.text only) and ChatGeneration
        (.text + .message.content + .message.tool_calls for function-calling).

        Returns None when the response carries no extractable content (e.g.
        empty generations list), so callers can omit output_payload entirely
        rather than sending an empty dict.
        """
        try:
            generations_batches = getattr(response, "generations", None)
            if not generations_batches:
                return None

            all_generations = [g for batch in generations_batches for g in batch]
            if not all_generations:
                return None

            texts: list[str] = []
            message_contents: list[str] = []
            tool_calls_all: list[dict[str, Any]] = []

            for gen in all_generations:
                text = getattr(gen, "text", None)
                if text:
                    texts.append(str(text))

                message = getattr(gen, "message", None)
                if message is not None:
                    content = getattr(message, "content", None)
                    if content:
                        if isinstance(content, str):
                            message_contents.append(content)
                        elif isinstance(content, list):
                            for block in content:
                                if isinstance(block, dict) and block.get("type") == "text":
                                    message_contents.append(block.get("text", ""))
                                elif isinstance(block, str):
                                    message_contents.append(block)

                    tool_calls = getattr(message, "tool_calls", None)
                    if tool_calls:
                        for tc in tool_calls:
                            if hasattr(tc, "name"):
                                tool_calls_all.append({
                                    "name": str(tc.name),
                                    "args": dict(getattr(tc, "args", {}) or {}),
                                    "id": str(getattr(tc, "id", "") or ""),
                                })
                            elif isinstance(tc, dict):
                                tool_calls_all.append({
                                    "name": str(tc.get("name", "")),
                                    "args": dict(tc.get("args", {}) or {}),
                                    "id": str(tc.get("id", "") or ""),
                                })

            if not texts and not message_contents and not tool_calls_all:
                return None

            result: dict[str, Any] = {"generation_count": len(all_generations)}
            if texts:
                result["text"] = "\n---\n".join(texts)
            if message_contents:
                result["message_content"] = "\n---\n".join(message_contents)
            if tool_calls_all:
                result["tool_calls"] = tool_calls_all

            try:
                llm_output = getattr(response, "llm_output", None) or {}
                model_name = llm_output.get("model_name") or llm_output.get("model")
                if model_name:
                    result["model_name"] = str(model_name)
            except Exception:  # noqa: BLE001
                pass

            return result
        except Exception:  # noqa: BLE001
            return None

    @staticmethod
    def _serialize_state(state: Any) -> dict[str, Any] | None:
        """
        Serialize a LangGraph node state dict for output_payload capture.

        Handles: plain dicts, Pydantic v2 models (.model_dump()), lists,
        and JSON-serializable primitives. Non-serializable values are replaced
        with a descriptor dict. Circular references (detected via object id()
        within the current call stack) are replaced with a sentinel. Dicts
        serializing to more than 64 KB are replaced with a truncation summary
        containing the top-level key list.

        Returns None for non-dict inputs (LangGraph always produces dict state,
        so None signals an unexpected type rather than an empty payload).
        """
        _SIZE_CAP = 65536  # 64 KB

        def _serialize(obj: Any, seen: set[int]) -> Any:
            if obj is None or isinstance(obj, (bool, int, float, str)):
                return obj

            obj_id = id(obj)
            if obj_id in seen:
                return {"__circular_reference__": type(obj).__name__}
            seen.add(obj_id)
            try:
                if hasattr(obj, "model_dump") and callable(obj.model_dump):
                    return _serialize(obj.model_dump(), seen)
                if isinstance(obj, dict):
                    return {str(k): _serialize(v, seen) for k, v in obj.items()}
                if isinstance(obj, (list, tuple)):
                    return [_serialize(item, seen) for item in obj]
                try:
                    json.dumps(obj)
                    return obj
                except (TypeError, ValueError):
                    pass
                return {
                    "__non_serializable__": str(type(obj)),
                    "__repr__": repr(obj)[:200],
                }
            finally:
                seen.discard(obj_id)

        if not isinstance(state, dict):
            return None

        try:
            serialized = _serialize(state, set())
            try:
                encoded = json.dumps(serialized)
            except Exception:  # noqa: BLE001
                return None
            if len(encoded) > _SIZE_CAP:
                return {
                    "__truncated__": True,
                    "original_size": len(encoded),
                    "state_keys": sorted(state.keys()),
                }
            return serialized
        except Exception:  # noqa: BLE001
            return None

    # ------------------------------------------------------------------
    # LangGraph node-type classifier (STORY-085)
    # ------------------------------------------------------------------

    @staticmethod
    def _classify_node_action_type(
        outputs: Any,
        node_name: str | None = None,
        overrides: dict[str, str] | None = None,
    ) -> ActionType:
        """
        Classify a LangGraph node's ActionType from its output state.

        Decision tree (evaluated in order):
        1. ``overrides[node_name]`` — explicit caller mapping wins unconditionally.
        2. ``outputs["messages"][-1].type == "tool"`` → TOOL_ORCHESTRATION
        3. ``outputs["messages"][-1].type == "ai"``  → DECISION
        4. ``outputs`` is a non-empty dict with no "messages" key → CONTROL_FLOW
        5. Default → DECISION (safe fallback for unknown / empty / error cases)

        Handles Pydantic state models (``model_dump()``), message objects
        (``getattr(msg, "type", None)``), and all pathological inputs (None,
        non-dict, empty messages). Never raises — returns DECISION on exception.

        Parameters
        ----------
        outputs:
            The raw output value supplied to ``on_chain_end``. Typically a dict
            (LangGraph state delta), a Pydantic model, or None.
        node_name:
            The name of the node being classified. Used for override lookup only.
        overrides:
            Optional ``{node_name: action_type_value}`` mapping supplied at
            instrumentor construction time via ``node_type_overrides``.
        """
        try:
            # 1. Explicit override takes priority.
            if overrides and node_name and node_name in overrides:
                return ActionType(overrides[node_name])

            # Normalise to dict — Pydantic models support model_dump().
            if outputs is None:
                return ActionType.DECISION
            if hasattr(outputs, "model_dump") and callable(outputs.model_dump):
                outputs = outputs.model_dump()
            if not isinstance(outputs, dict):
                return ActionType.DECISION

            # 2/3. Classify by the last message's type.
            messages = outputs.get("messages")
            if messages is not None:
                if not messages:
                    return ActionType.DECISION
                last = messages[-1]
                last_type = (
                    last.get("type") if isinstance(last, dict)
                    else getattr(last, "type", None)
                )
                if last_type == "tool":
                    return ActionType.TOOL_ORCHESTRATION
                # "ai", unknown, or None → DECISION
                return ActionType.DECISION

            # 4. Non-empty dict with no messages key → routing / control-flow node.
            if outputs:
                return ActionType.CONTROL_FLOW

        except Exception:  # noqa: BLE001
            logger.debug("classify_node_action_type failed, defaulting to DECISION", exc_info=True)

        return ActionType.DECISION

    # ------------------------------------------------------------------
    # Utilities
    # ------------------------------------------------------------------

    @staticmethod
    def _elapsed_ms(start: float | None) -> int | None:
        """Return elapsed milliseconds since start, or None if start is None."""
        if start is None:
            return None
        return int((time.monotonic() - start) * 1000)
