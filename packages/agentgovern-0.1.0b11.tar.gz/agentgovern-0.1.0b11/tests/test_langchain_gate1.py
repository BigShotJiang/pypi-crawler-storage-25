"""Tests for Gate 1 auto-invoke in AgentGovernCallbackHandler.on_chat_model_start."""

from __future__ import annotations

from typing import Any
from unittest.mock import MagicMock, patch
from uuid import uuid4

import pytest

from agentgovern.exceptions import GateUnavailable, PolicyViolation
from agentgovern.instrumentors.langchain import AgentGovernCallbackHandler
from agentgovern.types import InputEvaluation, RuleViolation


def _make_handler(
    evaluate_input_return=None,
    evaluate_input_raise=None,
    auto_evaluate_input=True,
    fail_open=True,
) -> AgentGovernCallbackHandler:
    client = MagicMock()
    if evaluate_input_raise:
        client.evaluate_input.side_effect = evaluate_input_raise
    else:
        client.evaluate_input.return_value = evaluate_input_return or InputEvaluation(allowed=True, action_taken="pass")
    return AgentGovernCallbackHandler(
        client=client,
        agent_external_id="test-agent",
        auto_evaluate_input=auto_evaluate_input,
        fail_open=fail_open,
    )


def _make_messages(content: str) -> list[list[Any]]:
    msg = MagicMock()
    msg.content = content
    return [[msg]]


# ---------------------------------------------------------------------------
# Gate 1 called on chat model start
# ---------------------------------------------------------------------------

def test_evaluate_input_called_on_chat_model_start():
    handler = _make_handler()
    handler.on_chat_model_start(
        {"id": ["openai", "gpt-4o"]},
        _make_messages("Hello world"),
        run_id=uuid4(),
    )
    handler._client.evaluate_input.assert_called_once()
    call_args = handler._client.evaluate_input.call_args
    assert call_args[0][0] == "test-agent"
    assert "Hello world" in call_args[0][1]


def test_evaluate_input_not_called_when_disabled():
    handler = _make_handler(auto_evaluate_input=False)
    handler.on_chat_model_start(
        {"id": ["openai", "gpt-4o"]},
        _make_messages("Hello"),
        run_id=uuid4(),
    )
    handler._client.evaluate_input.assert_not_called()


# ---------------------------------------------------------------------------
# PolicyViolation propagates
# ---------------------------------------------------------------------------

def test_policy_violation_propagates_from_chat_model_start():
    violation = RuleViolation(rule_code="BAD-001", reason="Blocked", enforcement_mode="enforce")
    evaluation = InputEvaluation(allowed=False, violations=[violation], action_taken="block")
    handler = _make_handler(evaluate_input_raise=PolicyViolation(evaluation))
    with pytest.raises(PolicyViolation):
        handler.on_chat_model_start(
            {"id": ["openai", "gpt-4o"]},
            _make_messages("bypass"),
            run_id=uuid4(),
        )


# ---------------------------------------------------------------------------
# GateUnavailable propagates when fail_closed
# ---------------------------------------------------------------------------

def test_gate_unavailable_propagates_when_fail_closed():
    handler = _make_handler(
        evaluate_input_raise=GateUnavailable("unreachable"),
        fail_open=False,
    )
    with pytest.raises(GateUnavailable):
        handler.on_chat_model_start(
            {"id": ["openai", "gpt-4o"]},
            _make_messages("Hello"),
            run_id=uuid4(),
        )


def test_gate_unavailable_swallowed_when_fail_open():
    handler = _make_handler(
        evaluate_input_raise=GateUnavailable("unreachable"),
        fail_open=True,
    )
    # Should not raise
    handler.on_chat_model_start(
        {"id": ["openai", "gpt-4o"]},
        _make_messages("Hello"),
        run_id=uuid4(),
    )


# ---------------------------------------------------------------------------
# Empty prompt — no evaluate_input call
# ---------------------------------------------------------------------------

def test_no_evaluate_input_call_when_prompt_is_empty():
    handler = _make_handler()
    msg = MagicMock()
    msg.content = ""
    handler.on_chat_model_start(
        {"id": ["openai", "gpt-4o"]},
        [[msg]],
        run_id=uuid4(),
    )
    handler._client.evaluate_input.assert_not_called()


# ---------------------------------------------------------------------------
# fail_closed param forwarded to client.evaluate_input
# ---------------------------------------------------------------------------

def test_fail_closed_forwarded_to_client():
    handler = _make_handler(fail_open=False)
    handler.on_chat_model_start(
        {"id": ["openai", "gpt-4o"]},
        _make_messages("Hello"),
        run_id=uuid4(),
    )
    call_kwargs = handler._client.evaluate_input.call_args[1]
    assert call_kwargs.get("fail_closed") is True


def test_fail_open_forwarded_to_client():
    handler = _make_handler(fail_open=True)
    handler.on_chat_model_start(
        {"id": ["openai", "gpt-4o"]},
        _make_messages("Hello"),
        run_id=uuid4(),
    )
    call_kwargs = handler._client.evaluate_input.call_args[1]
    assert call_kwargs.get("fail_closed") is False
