"""Unit tests for AgentGovernLangGraphInstrumentor (STORY-017).

Covers:
- Root graph run registration and cleanup
- Multi-node trace_id correlation (fragmentation fix)
- Conditional edge previous_node_id tracking
- Tool/LLM trace_id correctness (uses graph root, not node run_id)
- State delta computation from input/output diffing
- Fail-open / fail-closed behavior
- process_stream_event for stream_mode='updates' chunks
- Gate 2 trigger on root graph completion
- PolicyViolation propagation
- Per-invocation overhead < 5ms
"""

from __future__ import annotations

import json
import time
from unittest.mock import MagicMock
from uuid import uuid4

import httpx
import pytest
import respx

from agentgovern.exceptions import PolicyViolation
from agentgovern.instrumentors.langgraph import AgentGovernLangGraphInstrumentor
from agentgovern.types import ActionStatus, ActionType

_ENGINE_URL = "https://engine.test"
_EVAL_URL = f"{_ENGINE_URL}/api/v1/evaluate/action"


# ---------------------------------------------------------------------------
# Fixtures / helpers
# ---------------------------------------------------------------------------


def _make_handler(
    agent_id: str = "test-agent",
    *,
    fail_open: bool = True,
    gate_2_enforcement_mode: str | None = None,
) -> tuple[AgentGovernLangGraphInstrumentor, MagicMock]:
    mock_client = MagicMock()
    mock_client.policy_engine_url = _ENGINE_URL
    mock_client.api_key = "ag_test_key"
    mock_client.environment = "production"
    handler = AgentGovernLangGraphInstrumentor(
        client=mock_client,
        agent_external_id=agent_id,
        fail_open=fail_open,
        gate_2_enforcement_mode=gate_2_enforcement_mode,
    )
    return handler, mock_client


def _engine_response(verdict: str, **extras: object) -> dict:
    data: dict = {
        "verdict": verdict,
        "allowed": verdict in ("allow", "redact"),
        "evaluations": [],
        "review_id": None,
        "redacted_output": None,
    }
    data.update(extras)
    return {"data": data, "error": None, "meta": {}}


def _root_start(
    handler: AgentGovernLangGraphInstrumentor,
    root_id=None,
) -> uuid4:
    """Fire on_chain_start for the root LangGraph run."""
    if root_id is None:
        root_id = uuid4()
    handler.on_chain_start(
        {},
        {},
        run_id=root_id,
        parent_run_id=None,
        tags=[],
        name="LangGraph",
    )
    return root_id


def _node_start(
    handler: AgentGovernLangGraphInstrumentor,
    *,
    node_name: str,
    step_num: int = 1,
    parent_run_id,
    node_id=None,
    inputs: dict | None = None,
) -> uuid4:
    """Fire on_chain_start for a graph node (graph:step:N tag)."""
    if node_id is None:
        node_id = uuid4()
    handler.on_chain_start(
        {},
        inputs if inputs is not None else {"state_key": "value"},
        run_id=node_id,
        parent_run_id=parent_run_id,
        tags=[f"graph:step:{step_num}"],
        name=node_name,
    )
    return node_id


# ---------------------------------------------------------------------------
# 1. Root graph handling
# ---------------------------------------------------------------------------


class TestBasicGraphInvocation:
    def test_basic_graph_invocation(self) -> None:
        """Root start registers graph_run_id; root end cleans up. No spans created."""
        handler, mock_client = _make_handler()
        root_id = uuid4()

        handler.on_chain_start(
            {},
            {},
            run_id=root_id,
            parent_run_id=None,
            tags=[],
            name="LangGraph",
        )

        # Root is registered as its own trace container
        assert str(root_id) in handler._graph_run_ids
        assert handler._graph_run_ids[str(root_id)] == str(root_id)
        # No span is emitted for the graph container itself
        mock_client.track_action.assert_not_called()

        handler.on_chain_end({}, run_id=root_id, parent_run_id=None)

        # Cleanup: root run_id removed from tracking dicts
        assert str(root_id) not in handler._graph_run_ids
        # Still no track_action calls (Gate 2 is disabled)
        mock_client.track_action.assert_not_called()


# ---------------------------------------------------------------------------
# 2. Multi-node trace_id correlation
# ---------------------------------------------------------------------------


class TestMultiNodeGraph:
    def test_multi_node_graph(self) -> None:
        """All nodes in the same graph share the graph root run_id as trace_id."""
        handler, mock_client = _make_handler()
        root_id = _root_start(handler)

        _node_start(handler, node_name="triage_node", step_num=1, parent_run_id=root_id)
        _node_start(handler, node_name="approval_node", step_num=2, parent_run_id=root_id)

        calls = mock_client.track_action.call_args_list
        assert len(calls) == 2  # one STARTED per node

        for call in calls:
            args, kwargs = call
            assert kwargs["trace_id"] == str(root_id), (
                f"trace_id fragmentation: expected graph root {root_id!s}, "
                f"got {kwargs['trace_id']!r}"
            )
            assert kwargs["status"] == ActionStatus.STARTED


# ---------------------------------------------------------------------------
# 3. Conditional edge previous_node_id
# ---------------------------------------------------------------------------


class TestConditionalEdge:
    def test_conditional_edge(self) -> None:
        """Second node records the first node's name as previous_node_id in metadata."""
        handler, mock_client = _make_handler()
        root_id = _root_start(handler)

        _node_start(handler, node_name="triage_node", step_num=1, parent_run_id=root_id)
        _node_start(handler, node_name="approval_node", step_num=2, parent_run_id=root_id)

        calls = mock_client.track_action.call_args_list
        # Second STARTED call is for approval_node
        _, kwargs = calls[1]
        assert kwargs["metadata"]["node_id"] == "approval_node"
        assert kwargs["metadata"]["previous_node_id"] == "triage_node"


# ---------------------------------------------------------------------------
# 4 & 5. Tool / LLM trace_id uses graph root (fragmentation fix)
# ---------------------------------------------------------------------------


class TestToolAndLLMEvents:
    def test_tool_call_within_node(self) -> None:
        """Tool trace_id = graph root run_id, NOT the calling node's run_id.

        This is the critical fix for the trace_id fragmentation bug documented
        in docs/audit-reports/langgraph-coverage-2026-05-14.md (Finding 4).
        """
        handler, mock_client = _make_handler()
        root_id = _root_start(handler)
        node_id = _node_start(handler, node_name="triage_node", step_num=1, parent_run_id=root_id)

        tool_id = uuid4()
        handler.on_tool_start(
            {"name": "credit_score_lookup"},
            "customer_id=C001",
            run_id=tool_id,
            parent_run_id=node_id,
            name="credit_score_lookup",
        )

        args, kwargs = mock_client.track_action.call_args_list[-1]
        assert args[1] == ActionType.TOOL_CALL
        assert kwargs["span_id"] == str(tool_id)
        # Must be graph root, not node_id
        assert kwargs["trace_id"] == str(root_id), (
            f"Expected graph root trace_id={root_id!s}, got {kwargs['trace_id']!r}"
        )

    def test_llm_call_within_node(self) -> None:
        """LLM trace_id = graph root run_id, NOT the calling node's run_id."""
        handler, mock_client = _make_handler()
        handler._auto_evaluate_input = False  # skip Gate 1 evaluate_input side path

        root_id = _root_start(handler)
        node_id = _node_start(handler, node_name="decision_node", step_num=1, parent_run_id=root_id)

        llm_id = uuid4()
        handler.on_llm_start(
            {"id": ["langchain", "chat_models", "gpt-4o"]},
            ["Evaluate this loan application"],
            run_id=llm_id,
            parent_run_id=node_id,
        )

        args, kwargs = mock_client.track_action.call_args_list[-1]
        assert args[1] == ActionType.MESSAGE
        assert kwargs["span_id"] == str(llm_id)
        assert kwargs["trace_id"] == str(root_id), (
            f"Expected graph root trace_id={root_id!s}, got {kwargs['trace_id']!r}"
        )


# ---------------------------------------------------------------------------
# 6. State mutation metadata
# ---------------------------------------------------------------------------


class TestStateMutationMetadata:
    def test_state_mutation_metadata(self) -> None:
        """state_keys_modified is computed by diffing node inputs vs outputs."""
        handler, mock_client = _make_handler()
        root_id = _root_start(handler)
        node_id = uuid4()

        handler.on_chain_start(
            {},
            {"credit_score": 600, "decision": None},
            run_id=node_id,
            parent_run_id=root_id,
            tags=["graph:step:1"],
            name="triage_node",
        )

        # credit_score unchanged, decision modified, new_key added
        handler.on_chain_end(
            {"credit_score": 600, "decision": "approved", "new_key": True},
            run_id=node_id,
            parent_run_id=root_id,
        )

        # Last call is the COMPLETED finish_span call
        _, kwargs = mock_client.track_action.call_args_list[-1]
        assert kwargs["status"] == ActionStatus.COMPLETED
        assert sorted(kwargs["metadata"]["state_keys_modified"]) == ["decision", "new_key"]


# ---------------------------------------------------------------------------
# 7 & 8. Fail-open / fail-closed behavior
# ---------------------------------------------------------------------------


class TestFailOpenBehavior:
    def test_fail_open_when_handler_errors(self) -> None:
        """Errors inside callbacks are swallowed when fail_open=True (default)."""
        handler, mock_client = _make_handler(fail_open=True)

        root_id = _root_start(handler)
        mock_client.track_action.side_effect = RuntimeError("unexpected SDK error")

        # Must not raise even though track_action raises
        node_id = uuid4()
        handler.on_chain_start(
            {},
            {},
            run_id=node_id,
            parent_run_id=root_id,
            tags=["graph:step:1"],
            name="some_node",
        )
        # Reached here without exception — fail-open confirmed

    def test_fail_closed_with_fail_open_false(self) -> None:
        """Errors propagate from callbacks when fail_open=False."""
        handler, mock_client = _make_handler(fail_open=False)
        root_id = _root_start(handler)
        mock_client.track_action.side_effect = RuntimeError("propagated error")

        node_id = uuid4()
        with pytest.raises(RuntimeError, match="propagated error"):
            handler.on_chain_start(
                {},
                {},
                run_id=node_id,
                parent_run_id=root_id,
                tags=["graph:step:1"],
                name="failing_node",
            )


# ---------------------------------------------------------------------------
# 9. Stream event processing
# ---------------------------------------------------------------------------


class TestStreamEvents:
    def test_stream_event_processing(self) -> None:
        """process_stream_event handles stream_mode='updates' chunks and emits CUSTOM actions."""
        handler, mock_client = _make_handler()
        chunk = {"triage_node": {"credit_score": 720, "triage_done": True}}

        handler.process_stream_event(chunk)

        mock_client.track_action.assert_called_once()
        args, kwargs = mock_client.track_action.call_args
        assert args[1] == ActionType.CUSTOM
        assert args[2] == "state_delta/triage_node"
        assert kwargs["metadata"]["node_id"] == "triage_node"
        assert sorted(kwargs["metadata"]["state_keys_modified"]) == ["credit_score", "triage_done"]
        assert kwargs["metadata"]["source"] == "stream_updates"

    def test_stream_event_ignores_astream_events_format(self) -> None:
        """process_stream_event silently ignores astream_events v2 dicts (wrong path)."""
        handler, mock_client = _make_handler()
        astream_chunk = {"event": "on_chain_start", "name": "some_node", "data": {}}

        handler.process_stream_event(astream_chunk)

        mock_client.track_action.assert_not_called()


# ---------------------------------------------------------------------------
# 10. Gate 2 fires on root graph completion
# ---------------------------------------------------------------------------


class TestGate2:
    @respx.mock
    def test_gate_2_fires_on_final_state(self) -> None:
        """Gate 2 evaluation is triggered when the root LangGraph run completes."""
        respx.post(_EVAL_URL).mock(
            return_value=httpx.Response(200, json=_engine_response("allow"))
        )

        handler, _ = _make_handler(gate_2_enforcement_mode="enforce")
        root_id = uuid4()

        handler.on_chain_start({}, {}, run_id=root_id, parent_run_id=None, name="LangGraph")
        handler.on_chain_end({"decision": "loan approved"}, run_id=root_id, parent_run_id=None)

        assert respx.calls.call_count == 1
        body = json.loads(respx.calls[0].request.content)
        assert body["action"]["action_name"] == "graph_output"
        assert body["action"]["action_type"] == "decision"


# ---------------------------------------------------------------------------
# 11. PolicyViolation propagates through _guard()
# ---------------------------------------------------------------------------


class TestPolicyViolation:
    def test_policy_violation_propagates(self) -> None:
        """PolicyViolation always propagates from _guard(), even with fail_open=True."""
        handler, mock_client = _make_handler(fail_open=True)

        fake_eval = MagicMock()
        fake_eval.violations = []
        pv = PolicyViolation(fake_eval)

        root_id = _root_start(handler)
        mock_client.track_action.side_effect = pv

        node_id = uuid4()
        with pytest.raises(PolicyViolation):
            handler.on_chain_start(
                {},
                {},
                run_id=node_id,
                parent_run_id=root_id,
                tags=["graph:step:1"],
                name="gated_node",
            )


# ---------------------------------------------------------------------------
# 12. Per-invocation overhead < 5ms
# ---------------------------------------------------------------------------


class TestPerformance:
    def test_overhead_under_5ms(self) -> None:
        """Instrumentor adds < 5ms overhead per node invocation with a no-op mock client."""
        handler, mock_client = _make_handler()
        mock_client.track_action.return_value = None

        root_id = _root_start(handler)
        iterations = 100

        start = time.monotonic()
        for i in range(iterations):
            node_id = uuid4()
            handler.on_chain_start(
                {},
                {"state_key": "value"},
                run_id=node_id,
                parent_run_id=root_id,
                tags=[f"graph:step:{i + 1}"],
                name=f"node_{i}",
            )
            handler.on_chain_end(
                {"state_key": "value", "result": "done"},
                run_id=node_id,
                parent_run_id=root_id,
            )
        elapsed_ms = (time.monotonic() - start) * 1000
        per_invocation_ms = elapsed_ms / iterations

        assert per_invocation_ms < 5.0, (
            f"Overhead {per_invocation_ms:.2f}ms/invocation exceeds 5ms budget. "
            f"Total={elapsed_ms:.1f}ms over {iterations} iterations."
        )


# ---------------------------------------------------------------------------
# Integration tests — create_react_agent + FakeLLM  (STORY-085)
# ---------------------------------------------------------------------------
# These tests run only when the langgraph extra is installed:
#   pip install agentgovern[langgraph]
# They are skipped silently otherwise.
# ---------------------------------------------------------------------------

try:
    from langchain_core.language_models.chat_models import BaseChatModel as _BaseChatModel
    from langchain_core.messages import AIMessage as _AIMessage
    from langchain_core.messages import HumanMessage as _HumanMessage
    from langchain_core.outputs import ChatGeneration as _ChatGeneration
    from langchain_core.outputs import ChatResult as _ChatResult
    from langchain_core.tools import tool as _lc_tool
    from langgraph.graph import END as _LG_END
    from langgraph.graph import StateGraph as _StateGraph
    from langgraph.prebuilt import create_react_agent as _create_react_agent
    from pydantic import PrivateAttr as _PrivateAttr

    _LANGGRAPH_AVAILABLE = True

    class _FakeChatModel(_BaseChatModel):
        """Stateful fake LLM: returns pre-configured AIMessage responses in order."""

        responses: list
        _call_idx: int = _PrivateAttr(default=0)

        model_config = {"arbitrary_types_allowed": True}

        def _generate(self, messages, stop=None, run_manager=None, **kwargs):
            idx = min(self._call_idx, len(self.responses) - 1)
            msg = self.responses[idx]
            self._call_idx += 1
            return _ChatResult(generations=[_ChatGeneration(message=msg)])

        @property
        def _llm_type(self) -> str:
            return "fake"

        def bind_tools(self, tools, **kwargs):
            return self

except ImportError:
    _LANGGRAPH_AVAILABLE = False


def _collect_node_spans(call_args_list):
    """
    Filter track_action calls to return only graph-node spans (not LLM/tool child spans).
    Returns list of (action_name, action_type, status) tuples.
    """
    results = []
    for call in call_args_list:
        args, kwargs = call
        _agent_id, action_type, action_name = args[0], args[1], args[2]
        status = kwargs.get("status")
        if action_name.startswith("llm/") or action_type == ActionType.TOOL_CALL:
            continue
        results.append((action_name, action_type, status))
    return results


def _make_integration_handler(**kwargs):
    mock_client = MagicMock()
    mock_client.policy_engine_url = _ENGINE_URL
    mock_client.api_key = "ag_test_key"
    mock_client.environment = "production"
    mock_client.evaluate_input = MagicMock(return_value=MagicMock(allowed=True))
    handler = AgentGovernLangGraphInstrumentor(
        client=mock_client,
        agent_external_id="test-agent",
        **kwargs,
    )
    return handler, mock_client


@pytest.mark.skipif(not _LANGGRAPH_AVAILABLE, reason="langgraph extra not installed")
class TestCreateReactAgentIntegration:
    """Integration tests using a real create_react_agent graph and FakeLLM."""

    def test_create_react_agent_classifies_agent_node_as_decision(self) -> None:
        """Agent node (LLM returns final answer, no tool calls) → DECISION on COMPLETED."""

        @_lc_tool
        def dummy_tool(query: str) -> str:
            """A dummy tool."""
            return "dummy result"

        llm = _FakeChatModel(responses=[_AIMessage(content="The answer is 42.")])
        handler, mock_client = _make_integration_handler()
        app = _create_react_agent(llm, tools=[dummy_tool])
        app.invoke(
            {"messages": [_HumanMessage(content="What is the answer?")]},
            config={"callbacks": [handler]},
        )

        spans = _collect_node_spans(mock_client.track_action.call_args_list)
        completed_agent = [
            (name, atype) for name, atype, status in spans
            if name == "agent" and status == ActionStatus.COMPLETED
        ]
        assert completed_agent, "Expected at least one completed agent node span"
        assert all(atype == ActionType.DECISION for _, atype in completed_agent), (
            f"Expected DECISION for agent node, got {completed_agent}"
        )

    def test_create_react_agent_classifies_tools_node_as_tool_orchestration(self) -> None:
        """Tools node (ToolNode output has ToolMessages) → TOOL_ORCHESTRATION on COMPLETED."""

        @_lc_tool
        def search_tool(query: str) -> str:
            """A search tool."""
            return f"Search result for {query}"

        llm = _FakeChatModel(responses=[
            _AIMessage(
                content="",
                tool_calls=[{"id": "call_1", "name": "search_tool", "args": {"query": "test"}}],
            ),
            _AIMessage(content="Based on the search, the answer is X."),
        ])
        handler, mock_client = _make_integration_handler()
        app = _create_react_agent(llm, tools=[search_tool])
        app.invoke(
            {"messages": [_HumanMessage(content="Search for something.")]},
            config={"callbacks": [handler]},
        )

        spans = _collect_node_spans(mock_client.track_action.call_args_list)
        completed_tools = [
            (name, atype) for name, atype, status in spans
            if name == "tools" and status == ActionStatus.COMPLETED
        ]
        assert completed_tools, "Expected at least one completed tools node span"
        assert all(atype == ActionType.TOOL_ORCHESTRATION for _, atype in completed_tools), (
            f"Expected TOOL_ORCHESTRATION for tools node, got {completed_tools}"
        )

    def test_create_react_agent_multi_turn(self) -> None:
        """Multi-turn agent→tools→agent: each node type classified correctly."""

        @_lc_tool
        def lookup_tool(key: str) -> str:
            """Look up a value by key."""
            return f"value_for_{key}"

        llm = _FakeChatModel(responses=[
            _AIMessage(
                content="",
                tool_calls=[{"id": "c1", "name": "lookup_tool", "args": {"key": "x"}}],
            ),
            _AIMessage(content="Final answer based on lookup."),
        ])
        handler, mock_client = _make_integration_handler()
        app = _create_react_agent(llm, tools=[lookup_tool])
        app.invoke(
            {"messages": [_HumanMessage(content="Look up x and tell me.")]},
            config={"callbacks": [handler]},
        )

        spans = _collect_node_spans(mock_client.track_action.call_args_list)
        completed = [(name, atype) for name, atype, status in spans if status == ActionStatus.COMPLETED]

        agent_types = {atype for name, atype in completed if name == "agent"}
        tools_types = {atype for name, atype in completed if name == "tools"}

        assert agent_types == {ActionType.DECISION}, (
            f"All agent node COMPLETED spans should be DECISION, got {agent_types}"
        )
        assert tools_types == {ActionType.TOOL_ORCHESTRATION}, (
            f"All tools node COMPLETED spans should be TOOL_ORCHESTRATION, got {tools_types}"
        )

    def test_node_type_overrides_explicit_mapping(self) -> None:
        """node_type_overrides bypass the classifier — override value wins unconditionally."""

        @_lc_tool
        def override_tool(query: str) -> str:
            """A test tool."""
            return "result"

        llm = _FakeChatModel(responses=[_AIMessage(content="Override test answer.")])
        handler, mock_client = _make_integration_handler(
            node_type_overrides={"agent": "custom"},
        )
        app = _create_react_agent(llm, tools=[override_tool])
        app.invoke(
            {"messages": [_HumanMessage(content="Test override.")]},
            config={"callbacks": [handler]},
        )

        spans = _collect_node_spans(mock_client.track_action.call_args_list)
        completed_agent = [
            atype for name, atype, status in spans
            if name == "agent" and status == ActionStatus.COMPLETED
        ]
        assert completed_agent, "Expected completed agent node span"
        assert all(atype == ActionType.CUSTOM for atype in completed_agent), (
            f"Expected CUSTOM (override), got {completed_agent}"
        )

    def test_plain_state_graph_backwards_compat(self) -> None:
        """Non-messages StateGraph node → CONTROL_FLOW (backwards compat for plain graphs)."""
        from typing import TypedDict

        class RouterState(TypedDict):
            input: str
            next_step: str

        def router_node(state: RouterState) -> dict:
            return {"next_step": "approve"}

        graph_builder = _StateGraph(RouterState)
        graph_builder.add_node("router", router_node)
        graph_builder.set_entry_point("router")
        graph_builder.add_edge("router", _LG_END)
        app = graph_builder.compile()

        handler, mock_client = _make_integration_handler()
        app.invoke(
            {"input": "test", "next_step": ""},
            config={"callbacks": [handler]},
        )

        spans = _collect_node_spans(mock_client.track_action.call_args_list)
        completed_router = [
            atype for name, atype, status in spans
            if name == "router" and status == ActionStatus.COMPLETED
        ]
        assert completed_router, "Expected completed router node span"
        assert all(atype == ActionType.CONTROL_FLOW for atype in completed_router), (
            f"Expected CONTROL_FLOW for plain state router node, got {completed_router}"
        )
