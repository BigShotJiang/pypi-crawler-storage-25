"""
Tests for VerdictHandler Gate 2 verdict logic.

Covers: allow/block/redact/escalate verdict handling in enforce and warn modes,
fail_open/fail_closed timeout behavior, and VerdictResult field population.
"""

from __future__ import annotations

import httpx
import pytest
import respx

from agentgovern.exceptions import OutputBlocked, OutputEscalated
from agentgovern.gate2 import Gate2Config, VerdictHandler, VerdictResult

_ENGINE_URL = "https://engine.test"
_API_KEY = "ag_test_key"
_AGENT_ID = "agent-123"

_EVAL_ACTION_URL = f"{_ENGINE_URL}/api/v1/evaluate/action"


def _handler(enforcement_mode: str | None, failure_mode: str = "fail_open") -> VerdictHandler:
    return VerdictHandler(
        config=Gate2Config(
            enforcement_mode=enforcement_mode,
            failure_mode=failure_mode,
            timeout_ms=500,
        ),
        policy_engine_url=_ENGINE_URL,
        api_key=_API_KEY,
        agent_id=_AGENT_ID,
        environment="production",
    )


def _response(verdict: str, **extras: object) -> dict:
    data: dict = {
        "verdict": verdict,
        "allowed": verdict in ("allow", "redact"),
        "evaluations": [],
        "review_id": None,
        "redacted_output": None,
    }
    data.update(extras)
    return {"data": data, "error": None, "meta": {}}


def _run(handler: VerdictHandler) -> VerdictResult:
    return handler.evaluate(
        action_type="decision",
        action_name="agent_output",
        status="completed",
        output_payload={"output": "The loan is approved."},
    )


# ---------------------------------------------------------------------------
# Allow verdict
# ---------------------------------------------------------------------------


@respx.mock
def test_allow_verdict_returns_quietly():
    respx.post(_EVAL_ACTION_URL).mock(
        return_value=httpx.Response(200, json=_response("allow"))
    )
    result = _run(_handler("enforce"))
    assert result.verdict == "allow"
    assert result.allowed is True
    assert result.error is None


# ---------------------------------------------------------------------------
# Block verdict
# ---------------------------------------------------------------------------


@respx.mock
def test_block_verdict_enforce_raises_output_blocked():
    respx.post(_EVAL_ACTION_URL).mock(
        return_value=httpx.Response(
            200,
            json=_response(
                "block",
                evaluations=[{
                    "policy_id": "pol-1",
                    "reason": "PII detected",
                    "rule_code": "FORBID-001",
                    "result": "fail",
                    "severity": "high",
                    "enforcement_mode": "enforce",
                }],
            ),
        )
    )
    with pytest.raises(OutputBlocked) as exc_info:
        _run(_handler("enforce"))
    assert "PII detected" in str(exc_info.value)


@respx.mock
def test_block_verdict_warn_returns_quietly():
    respx.post(_EVAL_ACTION_URL).mock(
        return_value=httpx.Response(200, json=_response("block"))
    )
    result = _run(_handler("warn"))
    assert result.verdict == "block"
    assert result.allowed is True  # warn mode never blocks


# ---------------------------------------------------------------------------
# Redact verdict
# ---------------------------------------------------------------------------


@respx.mock
def test_redact_verdict_enforce_mutates_output():
    """VerdictHandler returns normally for redact, carrying the masked output."""
    redacted = {"output": "Card: ****-****-****-****"}
    respx.post(_EVAL_ACTION_URL).mock(
        return_value=httpx.Response(
            200,
            json=_response("redact", redacted_output=redacted),
        )
    )
    result = _run(_handler("enforce"))
    # No exception raised
    assert result.verdict == "redact"
    assert result.allowed is True
    assert result.redacted_output == redacted


# ---------------------------------------------------------------------------
# Escalate verdict
# ---------------------------------------------------------------------------


@respx.mock
def test_escalate_verdict_enforce_raises_output_escalated():
    respx.post(_EVAL_ACTION_URL).mock(
        return_value=httpx.Response(
            200,
            json=_response("escalate", review_id="rev-abc-123"),
        )
    )
    with pytest.raises(OutputEscalated) as exc_info:
        _run(_handler("enforce"))
    assert exc_info.value.review_id == "rev-abc-123"


# ---------------------------------------------------------------------------
# Timeout / engine unreachable
# ---------------------------------------------------------------------------


@respx.mock
def test_fail_open_on_timeout():
    """TimeoutException + fail_open → no exception, result.error set."""
    respx.post(_EVAL_ACTION_URL).mock(side_effect=httpx.TimeoutException("timed out"))
    result = _run(_handler("enforce", failure_mode="fail_open"))
    assert result.allowed is True
    assert result.error is not None
    assert "policy engine unavailable" in result.error


@respx.mock
def test_fail_closed_on_timeout():
    """TimeoutException + fail_closed → OutputBlocked raised."""
    respx.post(_EVAL_ACTION_URL).mock(side_effect=httpx.TimeoutException("timed out"))
    with pytest.raises(OutputBlocked) as exc_info:
        _run(_handler("enforce", failure_mode="fail_closed"))
    assert "policy engine unavailable" in str(exc_info.value)


@respx.mock
def test_warn_mode_overrides_fail_closed():
    """Even fail_closed does not raise when enforcement_mode=warn."""
    respx.post(_EVAL_ACTION_URL).mock(side_effect=httpx.TimeoutException("timed out"))
    result = _run(_handler("warn", failure_mode="fail_closed"))
    assert result.allowed is True  # warn never raises


# ---------------------------------------------------------------------------
# VerdictResult fields
# ---------------------------------------------------------------------------


@respx.mock
def test_verdict_result_fields_populated():
    """VerdictResult carries evaluation_ids, review_id, and verdict from response."""
    evaluations = [
        {
            "policy_id": "pol-aaa",
            "rule_code": "FORBID-001",
            "result": "fail",
            "severity": "high",
            "reason": "Sensitive data detected",
            "enforcement_mode": "enforce",
        }
    ]
    respx.post(_EVAL_ACTION_URL).mock(
        return_value=httpx.Response(
            200,
            json=_response("escalate", review_id="rev-xyz", evaluations=evaluations),
        )
    )
    with pytest.raises(OutputEscalated) as exc_info:
        _run(_handler("enforce"))
    assert exc_info.value.review_id == "rev-xyz"
    assert exc_info.value.evaluation_id == "pol-aaa"


# ---------------------------------------------------------------------------
# Disabled (enforcement_mode=None)
# ---------------------------------------------------------------------------


def test_disabled_mode_returns_allow_without_calling_engine():
    """enforcement_mode=None skips the engine entirely."""
    handler = _handler(None)
    result = _run(handler)
    assert result.verdict == "allow"
    assert result.allowed is True
    assert result.error is None


# ---------------------------------------------------------------------------
# VerdictResult is a plain dataclass (no exceptions)
# ---------------------------------------------------------------------------


def test_verdict_result_is_dataclass():
    r = VerdictResult(verdict="allow", allowed=True)
    assert r.verdict == "allow"
    assert r.redacted_output is None
    assert r.evaluation_ids == []
    assert r.error is None


# ---------------------------------------------------------------------------
# OutputBlocked and OutputEscalated carry structured fields
# ---------------------------------------------------------------------------


def test_output_blocked_carries_reason_and_evaluation_id():
    exc = OutputBlocked("PII in output", evaluation_id="eval-1")
    assert exc.reason == "PII in output"
    assert exc.evaluation_id == "eval-1"
    assert "PII in output" in str(exc)


def test_output_escalated_carries_review_id():
    exc = OutputEscalated("rev-999", evaluation_id="eval-2")
    assert exc.review_id == "rev-999"
    assert exc.evaluation_id == "eval-2"
    assert "rev-999" in str(exc)
