"""
E2E tests for Gate 2 full-path flow (SDK + mocked policy engine).

Tests the complete Gate 1 → Gate 2 sequence through AgentGovernCallbackHandler,
verifying no double-evaluation, correct verdict propagation, and that the
async ingest path still fires alongside the sync gate.
"""

from __future__ import annotations

from unittest.mock import MagicMock
from uuid import uuid4

import httpx
import pytest
import respx

from agentgovern.exceptions import OutputBlocked, OutputEscalated
from agentgovern.instrumentors.langchain import AgentGovernCallbackHandler

_ENGINE = "https://engine.test"
_INGEST = "https://ingest.test"
_EVAL_INPUT = f"{_ENGINE}/api/v1/evaluate/input"
_EVAL_ACTION = f"{_ENGINE}/api/v1/evaluate/action"


def _mock_client() -> MagicMock:
    client = MagicMock()
    client.policy_engine_url = _ENGINE
    client.api_key = "ag_test_key"
    client.environment = "production"
    return client


def _handler(enforcement_mode: str | None = "enforce") -> AgentGovernCallbackHandler:
    return AgentGovernCallbackHandler(
        client=_mock_client(),
        agent_external_id="test-agent",
        gate_2_enforcement_mode=enforcement_mode,
        gate_2_failure_mode="fail_open",
        gate_2_timeout_ms=500,
    )


def _engine_response(verdict: str, **extras: object) -> dict:
    data: dict = {
        "verdict": verdict,
        "allowed": verdict in ("allow", "redact"),
        "evaluations": [],
        "review_id": None,
        "redacted_output": None,
    }
    data.update(extras)
    return {"data": data, "error": None, "meta": {}}


def _input_eval_response(allowed: bool = True) -> dict:
    return {
        "data": {
            "allowed": allowed,
            "action_taken": "pass" if allowed else "block",
            "evaluation": {
                "rule_code": "PASS-001",
                "result": "pass",
                "reason": None,
                "framework": None,
            },
        },
        "error": None,
        "meta": {},
    }


def _agent_finish(output: str = "The loan is approved.") -> MagicMock:
    finish = MagicMock()
    finish.return_values = {"output": output}
    return finish


# ---------------------------------------------------------------------------
# Gate 1 + Gate 2 in sequence — no double evaluation
# ---------------------------------------------------------------------------


@respx.mock
def test_gate1_and_gate2_fire_in_sequence():
    """Gate 1 fires on on_chat_model_start; Gate 2 fires on on_agent_finish; no double-eval."""
    gate1_calls = 0
    gate2_calls = 0

    def count_gate1(request: httpx.Request) -> httpx.Response:
        nonlocal gate1_calls
        gate1_calls += 1
        return httpx.Response(200, json=_input_eval_response())

    def count_gate2(request: httpx.Request) -> httpx.Response:
        nonlocal gate2_calls
        gate2_calls += 1
        return httpx.Response(200, json=_engine_response("allow"))

    respx.post(_EVAL_INPUT).mock(side_effect=count_gate1)
    respx.post(_EVAL_ACTION).mock(side_effect=count_gate2)

    client = _mock_client()
    handler = AgentGovernCallbackHandler(
        client=client,
        agent_external_id="test-agent",
        auto_evaluate_input=False,  # Use manual Gate 1 call in test
        gate_2_enforcement_mode="enforce",
        gate_2_timeout_ms=500,
    )

    agent_run_id = uuid4()

    # Gate 2 fires on on_agent_finish
    handler.on_agent_finish(_agent_finish(), run_id=agent_run_id)
    # on_chain_end fires with same run_id — must NOT call Gate 2 again
    handler.on_chain_end({"output": "The loan is approved."}, run_id=agent_run_id)

    assert gate2_calls == 1, f"Gate 2 was called {gate2_calls} times; expected exactly 1"


@respx.mock
def test_gate2_does_not_fire_twice_when_chain_end_follows_agent_finish():
    """on_chain_end with same run_id as on_agent_finish must skip Gate 2."""
    call_count = 0

    def count(request: httpx.Request) -> httpx.Response:
        nonlocal call_count
        call_count += 1
        return httpx.Response(200, json=_engine_response("allow"))

    respx.post(_EVAL_ACTION).mock(side_effect=count)
    handler = _handler("enforce")
    run_id = uuid4()

    handler.on_agent_finish(_agent_finish(), run_id=run_id)
    handler.on_chain_end({"output": "final"}, run_id=run_id, parent_run_id=None)

    assert call_count == 1


# ---------------------------------------------------------------------------
# Block verdict propagation
# ---------------------------------------------------------------------------


@respx.mock
def test_full_path_block_raises_output_blocked():
    """Block verdict from the engine raises OutputBlocked through on_agent_finish."""
    respx.post(_EVAL_ACTION).mock(
        return_value=httpx.Response(
            200,
            json=_engine_response(
                "block",
                evaluations=[{
                    "policy_id": "pol-1",
                    "rule_code": "FORBID-PII",
                    "result": "fail",
                    "reason": "SSN detected",
                    "severity": "critical",
                    "enforcement_mode": "enforce",
                }],
            ),
        )
    )
    with pytest.raises(OutputBlocked) as exc_info:
        _handler("enforce").on_agent_finish(_agent_finish(), run_id=uuid4())
    assert "SSN detected" in str(exc_info.value)


# ---------------------------------------------------------------------------
# Redact verdict propagation
# ---------------------------------------------------------------------------


@respx.mock
def test_full_path_redact_mutates_agent_output():
    """Redact verdict from the engine mutates the AgentFinish output in-place."""
    redacted = {"output": "SSN: ***-**-****"}
    respx.post(_EVAL_ACTION).mock(
        return_value=httpx.Response(
            200,
            json=_engine_response("redact", redacted_output=redacted),
        )
    )
    finish = _agent_finish("SSN: 123-45-6789")
    _handler("enforce").on_agent_finish(finish, run_id=uuid4())
    assert finish.return_values["output"] == "SSN: ***-**-****"


# ---------------------------------------------------------------------------
# Escalate verdict propagation
# ---------------------------------------------------------------------------


@respx.mock
def test_full_path_escalate_raises_output_escalated():
    """Escalate verdict raises OutputEscalated with the review_id from the engine."""
    respx.post(_EVAL_ACTION).mock(
        return_value=httpx.Response(
            200,
            json=_engine_response("escalate", review_id="rev-full-path-test"),
        )
    )
    with pytest.raises(OutputEscalated) as exc_info:
        _handler("enforce").on_agent_finish(_agent_finish(), run_id=uuid4())
    assert exc_info.value.review_id == "rev-full-path-test"


# ---------------------------------------------------------------------------
# async ingest (track_action) fires even when Gate 2 is active
# ---------------------------------------------------------------------------


@respx.mock
def test_async_ingest_fires_alongside_gate2():
    """track_action (async path) is called even when sync Gate 2 is active."""
    respx.post(_EVAL_ACTION).mock(
        return_value=httpx.Response(200, json=_engine_response("allow"))
    )
    handler = _handler("enforce")
    handler.on_agent_finish(_agent_finish("hello world"), run_id=uuid4())
    handler._client.track_action.assert_called_once()


# ---------------------------------------------------------------------------
# Warn mode full path — no exception, original output preserved
# ---------------------------------------------------------------------------


@respx.mock
def test_warn_mode_full_path_block_does_not_raise():
    """Block verdict in warn mode: no exception, track_action fires."""
    respx.post(_EVAL_ACTION).mock(
        return_value=httpx.Response(200, json=_engine_response("block"))
    )
    finish = _agent_finish("original")
    _handler("warn").on_agent_finish(finish, run_id=uuid4())
    assert finish.return_values["output"] == "original"


# ---------------------------------------------------------------------------
# Disabled mode (enforcement_mode=None) — zero engine calls
# ---------------------------------------------------------------------------


def test_disabled_mode_no_engine_calls():
    """enforcement_mode=None: no policy engine call, no exceptions, no mutation."""
    handler = _handler(enforcement_mode=None)
    finish = _agent_finish("original output")
    handler.on_agent_finish(finish, run_id=uuid4())
    assert finish.return_values["output"] == "original output"
    # track_action still called (async path)
    handler._client.track_action.assert_called_once()
