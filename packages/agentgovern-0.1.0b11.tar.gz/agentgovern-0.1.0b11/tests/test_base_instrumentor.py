"""
Tests for BaseInstrumentor._extract_llm_output and ._serialize_state helpers.
These static methods are the shared extraction layer used by both the LangChain
and LangGraph instrumentors (STORY-080).
"""

from __future__ import annotations

import json
from typing import Any
from unittest.mock import MagicMock

import pytest

from agentgovern.instrumentors._base import BaseInstrumentor


# ---------------------------------------------------------------------------
# Helpers to build fake LLMResult / Generation objects without importing
# langchain-core (the SDK must not hard-depend on langchain at test time).
# ---------------------------------------------------------------------------


def _make_response(
    generations: list[list[Any]] | None = None,
    llm_output: dict | None = None,
) -> MagicMock:
    r = MagicMock()
    r.generations = generations if generations is not None else []
    r.llm_output = llm_output
    return r


def _make_generation(text: str = "", message: Any = None) -> MagicMock:
    gen = MagicMock()
    gen.text = text
    gen.message = message
    return gen


def _make_chat_message(
    content: str | list = "",
    tool_calls: list | None = None,
) -> MagicMock:
    msg = MagicMock()
    msg.content = content
    msg.tool_calls = tool_calls or []
    return msg


def _make_tool_call_obj(name: str, args: dict, tc_id: str = "tc_01") -> MagicMock:
    """Simulate a LangChain ToolCall object (has .name/.args/.id attrs)."""
    tc = MagicMock()
    tc.name = name
    tc.args = args
    tc.id = tc_id
    return tc


# ===========================================================================
# _extract_llm_output
# ===========================================================================


class TestExtractLlmOutput:
    def test_empty_generations_returns_none(self) -> None:
        response = _make_response(generations=[])
        assert BaseInstrumentor._extract_llm_output(response) is None

    def test_none_generations_returns_none(self) -> None:
        response = MagicMock()
        response.generations = None
        assert BaseInstrumentor._extract_llm_output(response) is None

    def test_simple_text_extraction(self) -> None:
        gen = _make_generation(text="Paris is the capital of France.")
        gen.message = None
        response = _make_response(generations=[[gen]])

        result = BaseInstrumentor._extract_llm_output(response)

        assert result is not None
        assert result["text"] == "Paris is the capital of France."
        assert result["generation_count"] == 1

    def test_chat_generation_extracts_message_content(self) -> None:
        msg = _make_chat_message(content="The answer is 42.")
        gen = _make_generation(text="The answer is 42.", message=msg)
        response = _make_response(generations=[[gen]])

        result = BaseInstrumentor._extract_llm_output(response)

        assert result is not None
        assert result["text"] == "The answer is 42."
        assert result["message_content"] == "The answer is 42."

    def test_tool_calls_dict_format(self) -> None:
        tc_dict = {"name": "web_search", "args": {"query": "capital of France"}, "id": "tc_1"}
        msg = _make_chat_message(content="", tool_calls=[tc_dict])
        gen = _make_generation(text="", message=msg)
        response = _make_response(generations=[[gen]])

        result = BaseInstrumentor._extract_llm_output(response)

        assert result is not None
        assert "tool_calls" in result
        assert len(result["tool_calls"]) == 1
        assert result["tool_calls"][0]["name"] == "web_search"
        assert result["tool_calls"][0]["args"] == {"query": "capital of France"}
        assert result["tool_calls"][0]["id"] == "tc_1"

    def test_tool_calls_object_format(self) -> None:
        tc_obj = _make_tool_call_obj("credit_check", {"customer_id": "c123"}, "tc_002")
        msg = _make_chat_message(content="", tool_calls=[tc_obj])
        gen = _make_generation(text="", message=msg)
        response = _make_response(generations=[[gen]])

        result = BaseInstrumentor._extract_llm_output(response)

        assert result is not None
        assert result["tool_calls"][0]["name"] == "credit_check"
        assert result["tool_calls"][0]["args"] == {"customer_id": "c123"}
        assert result["tool_calls"][0]["id"] == "tc_002"

    def test_multi_generation_joined_with_separator(self) -> None:
        gen1 = _make_generation(text="Option A")
        gen1.message = None
        gen2 = _make_generation(text="Option B")
        gen2.message = None
        response = _make_response(generations=[[gen1, gen2]])

        result = BaseInstrumentor._extract_llm_output(response)

        assert result is not None
        assert result["text"] == "Option A\n---\nOption B"
        assert result["generation_count"] == 2

    def test_model_name_from_llm_output(self) -> None:
        gen = _make_generation(text="hi")
        gen.message = None
        response = _make_response(
            generations=[[gen]],
            llm_output={"model_name": "gpt-4o", "token_usage": {}},
        )

        result = BaseInstrumentor._extract_llm_output(response)

        assert result is not None
        assert result["model_name"] == "gpt-4o"

    def test_none_text_is_skipped(self) -> None:
        gen = MagicMock()
        gen.text = None
        gen.message = None
        response = _make_response(generations=[[gen]])

        # No text, no message, no tool_calls — result is None
        assert BaseInstrumentor._extract_llm_output(response) is None

    def test_exception_returns_none(self) -> None:
        bad = MagicMock()
        bad.generations = MagicMock(side_effect=RuntimeError("boom"))
        # Must not raise
        assert BaseInstrumentor._extract_llm_output(bad) is None

    def test_message_content_list_extracts_text_blocks(self) -> None:
        content_blocks = [
            {"type": "text", "text": "Here is my answer."},
            {"type": "tool_use", "id": "tc_1", "name": "lookup", "input": {}},
        ]
        msg = _make_chat_message(content=content_blocks)
        gen = _make_generation(text="", message=msg)
        response = _make_response(generations=[[gen]])

        result = BaseInstrumentor._extract_llm_output(response)

        assert result is not None
        assert result["message_content"] == "Here is my answer."


# ===========================================================================
# _serialize_state
# ===========================================================================


class TestSerializeState:
    def test_non_dict_returns_none(self) -> None:
        assert BaseInstrumentor._serialize_state("not a dict") is None
        assert BaseInstrumentor._serialize_state(42) is None
        assert BaseInstrumentor._serialize_state(["a", "b"]) is None
        assert BaseInstrumentor._serialize_state(None) is None

    def test_empty_dict(self) -> None:
        result = BaseInstrumentor._serialize_state({})
        assert result == {}

    def test_primitives_round_trip(self) -> None:
        state = {
            "name": "loan_agent",
            "score": 720,
            "approved": True,
            "notes": None,
        }
        result = BaseInstrumentor._serialize_state(state)
        assert result == state

    def test_nested_dict(self) -> None:
        state = {"outer": {"inner": {"deep": "value"}}}
        result = BaseInstrumentor._serialize_state(state)
        assert result == {"outer": {"inner": {"deep": "value"}}}

    def test_list_in_state(self) -> None:
        state = {"flags": ["pii", "financial"], "scores": [0.1, 0.9]}
        result = BaseInstrumentor._serialize_state(state)
        assert result == state

    def test_pydantic_model_calls_model_dump(self) -> None:
        mock_model = MagicMock()
        mock_model.model_dump.return_value = {"field": "value"}
        state = {"model": mock_model}

        result = BaseInstrumentor._serialize_state(state)

        assert result == {"model": {"field": "value"}}
        mock_model.model_dump.assert_called_once()

    def test_circular_reference_returns_sentinel(self) -> None:
        a: dict = {}
        a["self"] = a  # direct cycle

        result = BaseInstrumentor._serialize_state(a)

        assert result is not None
        assert result["self"] == {"__circular_reference__": "dict"}

    def test_non_serializable_returns_descriptor(self) -> None:
        class Unpicklable:
            def __repr__(self) -> str:
                return "Unpicklable()"

        state = {"obj": Unpicklable()}
        result = BaseInstrumentor._serialize_state(state)

        assert result is not None
        assert "__non_serializable__" in result["obj"]
        assert "__repr__" in result["obj"]

    def test_size_cap_returns_truncation_summary(self) -> None:
        large_value = "x" * 70000
        state = {"big_key": large_value, "other_key": 1}

        result = BaseInstrumentor._serialize_state(state)

        assert result is not None
        assert result["__truncated__"] is True
        assert result["original_size"] > 65536
        assert "big_key" in result["state_keys"]
        assert "other_key" in result["state_keys"]

    def test_json_serializable_custom_object_passes_through(self) -> None:
        from enum import Enum

        class Status(Enum):
            APPROVED = "approved"

        state = {"decision": "approved", "count": 3}
        result = BaseInstrumentor._serialize_state(state)
        assert result == {"decision": "approved", "count": 3}

    def test_result_is_json_serializable(self) -> None:
        state = {
            "score": 720,
            "flags": ["pii"],
            "nested": {"key": "val"},
        }
        result = BaseInstrumentor._serialize_state(state)
        # Must be JSON-serializable — no MagicMock or other non-serializable leftovers
        encoded = json.dumps(result)
        assert len(encoded) > 0


# ===========================================================================
# _classify_node_action_type  (STORY-085)
# ===========================================================================


def _msg_dict(msg_type: str) -> dict:
    return {"type": msg_type, "content": "..."}


def _msg_obj(msg_type: str) -> MagicMock:
    """Simulate a LangChain BaseMessage object with a .type attribute."""
    obj = MagicMock()
    obj.type = msg_type
    return obj


class TestClassifyNodeActionType:
    def test_tool_message_last_returns_tool_orchestration(self) -> None:
        outputs = {"messages": [_msg_dict("tool")]}
        result = BaseInstrumentor._classify_node_action_type(outputs)
        from agentgovern.types import ActionType
        assert result == ActionType.TOOL_ORCHESTRATION

    def test_ai_message_with_tool_calls_returns_decision(self) -> None:
        outputs = {"messages": [_msg_dict("ai")]}
        result = BaseInstrumentor._classify_node_action_type(outputs)
        from agentgovern.types import ActionType
        assert result == ActionType.DECISION

    def test_ai_message_without_tool_calls_returns_decision(self) -> None:
        outputs = {"messages": [{"type": "ai", "content": "final answer"}]}
        result = BaseInstrumentor._classify_node_action_type(outputs)
        from agentgovern.types import ActionType
        assert result == ActionType.DECISION

    def test_empty_messages_list_returns_decision(self) -> None:
        outputs = {"messages": []}
        result = BaseInstrumentor._classify_node_action_type(outputs)
        from agentgovern.types import ActionType
        assert result == ActionType.DECISION

    def test_no_messages_key_non_empty_dict_returns_control_flow(self) -> None:
        outputs = {"next": "agent", "step": 2}
        result = BaseInstrumentor._classify_node_action_type(outputs)
        from agentgovern.types import ActionType
        assert result == ActionType.CONTROL_FLOW

    def test_override_match_returns_override_type(self) -> None:
        outputs = {"messages": [_msg_dict("tool")]}
        overrides = {"my_node": "message"}
        result = BaseInstrumentor._classify_node_action_type(
            outputs, node_name="my_node", overrides=overrides
        )
        from agentgovern.types import ActionType
        assert result == ActionType.MESSAGE

    def test_override_miss_falls_through_to_content_classifier(self) -> None:
        outputs = {"messages": [_msg_dict("tool")]}
        overrides = {"other_node": "message"}
        result = BaseInstrumentor._classify_node_action_type(
            outputs, node_name="my_node", overrides=overrides
        )
        from agentgovern.types import ActionType
        assert result == ActionType.TOOL_ORCHESTRATION

    def test_none_outputs_returns_decision(self) -> None:
        result = BaseInstrumentor._classify_node_action_type(None)
        from agentgovern.types import ActionType
        assert result == ActionType.DECISION

    def test_non_dict_string_returns_decision(self) -> None:
        result = BaseInstrumentor._classify_node_action_type("some string")
        from agentgovern.types import ActionType
        assert result == ActionType.DECISION

    def test_non_dict_int_returns_decision(self) -> None:
        result = BaseInstrumentor._classify_node_action_type(42)
        from agentgovern.types import ActionType
        assert result == ActionType.DECISION

    def test_multiple_messages_last_is_tool_returns_tool_orchestration(self) -> None:
        outputs = {"messages": [_msg_dict("ai"), _msg_dict("human"), _msg_dict("tool")]}
        result = BaseInstrumentor._classify_node_action_type(outputs)
        from agentgovern.types import ActionType
        assert result == ActionType.TOOL_ORCHESTRATION

    def test_multiple_messages_last_is_ai_returns_decision(self) -> None:
        outputs = {"messages": [_msg_dict("tool"), _msg_dict("tool"), _msg_dict("ai")]}
        result = BaseInstrumentor._classify_node_action_type(outputs)
        from agentgovern.types import ActionType
        assert result == ActionType.DECISION

    def test_pydantic_state_model_classified_via_model_dump(self) -> None:
        mock_model = MagicMock()
        mock_model.model_dump.return_value = {"messages": [_msg_dict("tool")]}
        result = BaseInstrumentor._classify_node_action_type(mock_model)
        from agentgovern.types import ActionType
        assert result == ActionType.TOOL_ORCHESTRATION

    def test_ai_message_object_returns_decision(self) -> None:
        outputs = {"messages": [_msg_obj("ai")]}
        result = BaseInstrumentor._classify_node_action_type(outputs)
        from agentgovern.types import ActionType
        assert result == ActionType.DECISION

    def test_tool_message_object_returns_tool_orchestration(self) -> None:
        outputs = {"messages": [_msg_obj("tool")]}
        result = BaseInstrumentor._classify_node_action_type(outputs)
        from agentgovern.types import ActionType
        assert result == ActionType.TOOL_ORCHESTRATION
