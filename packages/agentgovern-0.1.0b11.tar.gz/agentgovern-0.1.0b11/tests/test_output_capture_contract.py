"""
Contract tests: _finish_span call sites produce output_payload for LLM completions.

These freeze the wire format for on_llm_end in both the LangChain and LangGraph
instrumentors (STORY-080). A passing test suite with no output_payload assertions
is what caused the original regression — this file is the guard against regression.
"""

from __future__ import annotations

import time
from typing import Any
from unittest.mock import MagicMock
from uuid import uuid4

import pytest

from agentgovern.client import AgentGovernClient
from agentgovern.instrumentors.langchain import AgentGovernCallbackHandler
from agentgovern.instrumentors.langgraph import AgentGovernLangGraphInstrumentor
from agentgovern.types import ActionStatus, ActionType


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _make_langchain_handler() -> tuple[AgentGovernCallbackHandler, MagicMock]:
    mock_client = MagicMock(spec=AgentGovernClient)
    handler = AgentGovernCallbackHandler(client=mock_client, agent_external_id="test-agent")
    return handler, mock_client


def _make_langgraph_handler() -> tuple[AgentGovernLangGraphInstrumentor, MagicMock]:
    mock_client = MagicMock(spec=AgentGovernClient)
    handler = AgentGovernLangGraphInstrumentor(
        client=mock_client,
        agent_external_id="test-agent",
        auto_evaluate_input=False,
    )
    return handler, mock_client


def _make_llm_result(text: str = "The answer is 42.") -> MagicMock:
    gen = MagicMock()
    gen.text = text
    gen.message = None
    response = MagicMock()
    response.generations = [[gen]]
    response.llm_output = {"token_usage": {"total_tokens": 10}}
    return response


def _make_chat_result(text: str = "", tool_call_name: str | None = None) -> MagicMock:
    tc = None
    if tool_call_name:
        tc = MagicMock()
        tc.name = tool_call_name
        tc.args = {"q": "query"}
        tc.id = "tc_1"

    msg = MagicMock()
    msg.content = text
    msg.tool_calls = [tc] if tc else []

    gen = MagicMock()
    gen.text = text
    gen.message = msg

    response = MagicMock()
    response.generations = [[gen]]
    response.llm_output = {}
    return response


# ---------------------------------------------------------------------------
# LangChain: on_llm_end output_payload contract
# ---------------------------------------------------------------------------


class TestLangChainLlmEndOutputPayload:
    def test_on_llm_end_sends_output_payload(self) -> None:
        """_finish_span must receive output_payload with 'text' key for text responses."""
        handler, mock_client = _make_langchain_handler()
        run_id = uuid4()

        handler._runs[str(run_id)] = {
            "start_time": time.monotonic(),
            "model_id": "gpt-4o",
            "trace_id": "trace-1",
        }
        response = _make_llm_result("Paris is the capital of France.")
        handler.on_llm_end(response, run_id=run_id)

        _, kwargs = mock_client.track_action.call_args
        assert kwargs["output_payload"] is not None, (
            "on_llm_end must pass output_payload to track_action; "
            "None means LLM responses are lost from compliance evidence"
        )
        assert "text" in kwargs["output_payload"]
        assert "Paris is the capital of France." in kwargs["output_payload"]["text"]

    def test_on_llm_end_tool_calls_in_output_payload(self) -> None:
        """Tool-call responses must surface the call name in output_payload."""
        handler, mock_client = _make_langchain_handler()
        run_id = uuid4()

        handler._runs[str(run_id)] = {
            "start_time": time.monotonic(),
            "model_id": "gpt-4o",
            "trace_id": "trace-2",
        }
        response = _make_chat_result(tool_call_name="credit_check")
        handler.on_llm_end(response, run_id=run_id)

        _, kwargs = mock_client.track_action.call_args
        assert kwargs["output_payload"] is not None
        assert "tool_calls" in kwargs["output_payload"]
        assert kwargs["output_payload"]["tool_calls"][0]["name"] == "credit_check"

    def test_on_llm_end_empty_response_sends_no_output_payload(self) -> None:
        """An LLMResult with no generations must not send output_payload."""
        handler, mock_client = _make_langchain_handler()
        run_id = uuid4()

        handler._runs[str(run_id)] = {
            "start_time": time.monotonic(),
            "model_id": "gpt-4o",
            "trace_id": "trace-3",
        }
        response = MagicMock()
        response.generations = []
        response.llm_output = {}
        handler.on_llm_end(response, run_id=run_id)

        _, kwargs = mock_client.track_action.call_args
        assert kwargs["output_payload"] is None

    def test_on_llm_end_generation_count_present(self) -> None:
        """generation_count field must be present when output_payload is sent."""
        handler, mock_client = _make_langchain_handler()
        run_id = uuid4()

        handler._runs[str(run_id)] = {
            "start_time": time.monotonic(),
            "model_id": "gpt-4o",
            "trace_id": "trace-4",
        }
        response = _make_llm_result("ok")
        handler.on_llm_end(response, run_id=run_id)

        _, kwargs = mock_client.track_action.call_args
        assert kwargs["output_payload"]["generation_count"] == 1


# ---------------------------------------------------------------------------
# LangGraph: on_llm_end output_payload contract
# ---------------------------------------------------------------------------


class TestLangGraphLlmEndOutputPayload:
    def test_on_llm_end_sends_output_payload(self) -> None:
        """LangGraph on_llm_end must also send output_payload (same fix as LangChain)."""
        handler, mock_client = _make_langgraph_handler()
        run_id = uuid4()
        root_id = uuid4()

        # Seed a root to get trace propagation right
        handler._graph_run_ids[str(root_id)] = str(root_id)
        handler._graph_run_ids[str(run_id)] = str(root_id)

        handler._runs[str(run_id)] = {
            "start_time": time.monotonic(),
            "model_id": "gpt-4o",
            "trace_id": str(root_id),
        }
        response = _make_llm_result("Loan approved for applicant.")
        handler.on_llm_end(response, run_id=run_id)

        _, kwargs = mock_client.track_action.call_args
        assert kwargs["output_payload"] is not None
        assert "text" in kwargs["output_payload"]
        assert "Loan approved for applicant." in kwargs["output_payload"]["text"]


# ---------------------------------------------------------------------------
# LangGraph: on_chain_end node state values contract
# ---------------------------------------------------------------------------


class TestLangGraphChainEndStateValues:
    def _root_start(self, handler: AgentGovernLangGraphInstrumentor) -> uuid4:
        root_id = uuid4()
        handler.on_chain_start({}, {}, run_id=root_id, parent_run_id=None, name="LangGraph")
        return root_id

    def test_on_chain_end_includes_state_values(self) -> None:
        """Node on_chain_end must include full state values in output_payload.state_values."""
        handler, mock_client = _make_langgraph_handler()
        root_id = self._root_start(handler)
        node_id = uuid4()

        handler.on_chain_start(
            {},
            {"credit_score": 600},
            run_id=node_id,
            parent_run_id=root_id,
            tags=["graph:step:1"],
            name="triage_node",
        )
        handler.on_chain_end(
            {"credit_score": 600, "decision": "approved"},
            run_id=node_id,
            parent_run_id=root_id,
        )

        # Last call is COMPLETED
        _, kwargs = mock_client.track_action.call_args_list[-1]
        assert kwargs["output_payload"] is not None, (
            "on_chain_end must include state_values in output_payload for compliance evidence"
        )
        assert "state_values" in kwargs["output_payload"], (
            "output_payload must contain 'state_values' with the actual state dict"
        )
        state_values = kwargs["output_payload"]["state_values"]
        assert state_values["credit_score"] == 600
        assert state_values["decision"] == "approved"

    def test_on_chain_end_state_keys_modified_still_in_metadata(self) -> None:
        """state_keys_modified must still be present in metadata (backward compat)."""
        handler, mock_client = _make_langgraph_handler()
        root_id = self._root_start(handler)
        node_id = uuid4()

        handler.on_chain_start(
            {},
            {"credit_score": 600, "decision": None},
            run_id=node_id,
            parent_run_id=root_id,
            tags=["graph:step:1"],
            name="triage_node",
        )
        handler.on_chain_end(
            {"credit_score": 600, "decision": "approved", "new_key": True},
            run_id=node_id,
            parent_run_id=root_id,
        )

        _, kwargs = mock_client.track_action.call_args_list[-1]
        # Metadata backward compat
        assert sorted(kwargs["metadata"]["state_keys_modified"]) == ["decision", "new_key"]
        # output_payload contains state_keys_modified too
        assert "state_keys_modified" in kwargs["output_payload"]

    def test_on_chain_end_empty_state_sends_state_values(self) -> None:
        """Even with no state modifications, state_values is captured if outputs is a dict."""
        handler, mock_client = _make_langgraph_handler()
        root_id = self._root_start(handler)
        node_id = uuid4()

        handler.on_chain_start(
            {},
            {"unchanged": "same"},
            run_id=node_id,
            parent_run_id=root_id,
            tags=["graph:step:1"],
            name="passthrough_node",
        )
        # Outputs identical to inputs — state_keys_modified will be []
        handler.on_chain_end(
            {"unchanged": "same"},
            run_id=node_id,
            parent_run_id=root_id,
        )

        _, kwargs = mock_client.track_action.call_args_list[-1]
        # state_values must be present even when nothing changed
        assert kwargs["output_payload"] is not None
        assert "state_values" in kwargs["output_payload"]
        assert kwargs["output_payload"]["state_values"]["unchanged"] == "same"
