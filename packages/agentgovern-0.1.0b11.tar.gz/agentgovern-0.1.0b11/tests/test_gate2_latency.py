"""
Gate 2 latency benchmark: p99 < 500ms for 50 sequential evaluations.

This is a @pytest.mark.slow test excluded from standard CI.
Run manually before the PR merges:
    pytest tests/test_gate2_latency.py -m slow -v

Requires a running policy engine. Set AGENTGOVERN_POLICY_ENGINE_URL env var
(default: http://localhost:8000) and ensure it is reachable before running.
"""

from __future__ import annotations

import os
import statistics
import time

import pytest

from agentgovern.gate2 import Gate2Config, VerdictHandler

_POLICY_ENGINE_URL = os.environ.get("AGENTGOVERN_POLICY_ENGINE_URL", "http://localhost:8000")
_API_KEY = os.environ.get("AGENTGOVERN_API_KEY", "ag_test_latency_key")
_ITERATIONS = 50
_P99_LIMIT_MS = 500.0


@pytest.mark.slow
def test_gate2_p99_latency_under_500ms() -> None:
    """
    Measure p99 latency of 50 sequential Gate 2 evaluations.

    Assert p99 < 500ms. This exercises the full round-trip:
    VerdictHandler._call_engine() → httpx POST → policy engine → response.

    Skip if the policy engine is not reachable.
    """
    import httpx

    # Skip if engine is unreachable
    try:
        with httpx.Client(timeout=2.0) as client:
            resp = client.get(f"{_POLICY_ENGINE_URL}/health")
            if resp.status_code != 200:
                pytest.skip(f"Policy engine at {_POLICY_ENGINE_URL} returned {resp.status_code}")
    except Exception as exc:
        pytest.skip(f"Policy engine not reachable at {_POLICY_ENGINE_URL}: {exc}")

    config = Gate2Config(enforcement_mode="enforce", failure_mode="fail_open", timeout_ms=500)
    handler = VerdictHandler(
        config=config,
        policy_engine_url=_POLICY_ENGINE_URL,
        api_key=_API_KEY,
        agent_id="latency-test-agent",
        environment="development",
    )

    latencies: list[float] = []
    for _ in range(_ITERATIONS):
        start = time.perf_counter()
        try:
            handler.evaluate(
                action_type="decision",
                action_name="agent_output",
                status="completed",
                output_payload={"output": "This is a latency test output."},
            )
        except Exception:  # noqa: BLE001
            pass  # verdict errors are not latency failures
        latencies.append((time.perf_counter() - start) * 1000)

    latencies.sort()
    p99_index = int(len(latencies) * 0.99)
    p99_ms = latencies[min(p99_index, len(latencies) - 1)]
    p50_ms = statistics.median(latencies)

    print(f"\nGate 2 latency ({_ITERATIONS} iterations):")
    print(f"  p50  = {p50_ms:.1f}ms")
    print(f"  p99  = {p99_ms:.1f}ms")
    print(f"  min  = {latencies[0]:.1f}ms")
    print(f"  max  = {latencies[-1]:.1f}ms")

    assert p99_ms < _P99_LIMIT_MS, (
        f"Gate 2 p99 latency {p99_ms:.1f}ms exceeds {_P99_LIMIT_MS}ms limit. "
        f"Check policy engine performance at {_POLICY_ENGINE_URL}."
    )
