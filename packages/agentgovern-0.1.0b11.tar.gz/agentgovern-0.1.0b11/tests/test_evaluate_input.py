"""Tests for Gate 1 evaluate_input() — client and module-level wrapper."""

from __future__ import annotations

import json as _json
from unittest.mock import MagicMock, patch

import httpx
import pytest
import respx

import agentgovern
from agentgovern.client import AgentGovernClient
from agentgovern.exceptions import ClientError, GateUnavailable, PolicyViolation
from agentgovern.types import InputEvaluation


POLICY_ENGINE_URL = "http://test-engine"
EVALUATE_URL = f"{POLICY_ENGINE_URL}/api/v1/evaluate/input"


@pytest.fixture(autouse=True)
def reset_module_state():
    agentgovern._client = None
    agentgovern._last_registered_agent = None
    yield
    agentgovern._client = None
    agentgovern._last_registered_agent = None


@pytest.fixture
def client():
    return AgentGovernClient(
        api_key="ag_test_key",
        base_url="http://localhost:3000",
        policy_engine_url=POLICY_ENGINE_URL,
    )


def _pass_response(policy_id: str = "pol_123") -> dict:
    return {
        "data": {
            "allowed": True,
            "action_taken": "pass",
            "evaluation": {
                "policy_id": policy_id,
                "rule_code": "INPUT-PASS-ALL",
                "result": "pass",
                "reason": None,
                "framework": None,
                "enforcement_mode": None,
            },
        },
        "error": None,
        "meta": {"request_id": "req_abc", "timestamp": "2026-04-19T00:00:00Z", "latency_ms": 8},
    }


def _block_response(policy_id: str = "pol_xyz") -> dict:
    return {
        "data": {
            "allowed": False,
            "action_taken": "block",
            "evaluation": {
                "policy_id": policy_id,
                "rule_code": "INPUT-SCOPE-003",
                "result": "fail",
                "reason": "Prompt requests bypassing risk controls",
                "framework": "EU AI Act Article 9",
                "enforcement_mode": "enforce",
            },
        },
        "error": None,
        "meta": {"request_id": "req_xyz", "timestamp": "2026-04-19T00:00:00Z", "latency_ms": 12},
    }


def _warn_response() -> dict:
    return {
        "data": {
            "allowed": True,
            "action_taken": "warn",
            "evaluation": {
                "policy_id": "pol_warn",
                "rule_code": "EUAI-PII-001",
                "result": "fail",
                "reason": "PII detected in prompt",
                "framework": "EU AI Act Article 10",
                "enforcement_mode": "warn",
            },
        },
        "error": None,
        "meta": {"request_id": "req_warn", "timestamp": "2026-04-19T00:00:00Z", "latency_ms": 10},
    }


def _log_response() -> dict:
    return {
        "data": {
            "allowed": True,
            "action_taken": "log",
            "evaluation": {
                "policy_id": "pol_log",
                "rule_code": "EUAI-LOG-001",
                "result": "fail",
                "reason": "Sensitive operation logged",
                "framework": None,
                "enforcement_mode": "log",
            },
        },
        "error": None,
        "meta": {"request_id": "req_log", "timestamp": "2026-04-19T00:00:00Z", "latency_ms": 9},
    }


# ---------------------------------------------------------------------------
# Allowed / pass response
# ---------------------------------------------------------------------------

@respx.mock
def test_returns_allowed_true_on_pass(client):
    respx.post(EVALUATE_URL).mock(return_value=httpx.Response(200, json=_pass_response()))
    result = client.evaluate_input("my-agent", "What is the weather?")
    assert result.allowed is True
    assert result.violations == []
    assert result.action_taken == "pass"


@respx.mock
def test_returns_evaluation_id_from_response(client):
    respx.post(EVALUATE_URL).mock(return_value=httpx.Response(200, json=_pass_response("pol_abc123")))
    result = client.evaluate_input("my-agent", "Hello")
    assert result.evaluation_id == "pol_abc123"


@respx.mock
def test_request_body_uses_agent_id_and_input_fields(client):
    route = respx.post(EVALUATE_URL).mock(return_value=httpx.Response(200, json=_pass_response()))
    client.evaluate_input("credit-scoring-v2", "Approve this loan")
    sent = route.calls[0].request
    body = _json.loads(sent.content)
    assert body["agent_id"] == "credit-scoring-v2"
    assert body["input"] == {"prompt": "Approve this loan"}
    assert "agent_external_id" not in body


# ---------------------------------------------------------------------------
# Block response → PolicyViolation
# ---------------------------------------------------------------------------

@respx.mock
def test_raises_policy_violation_when_blocked(client):
    respx.post(EVALUATE_URL).mock(return_value=httpx.Response(200, json=_block_response()))
    with pytest.raises(PolicyViolation) as exc_info:
        client.evaluate_input("my-agent", "bypass risk checks")
    exc = exc_info.value
    assert exc.rule_code == "INPUT-SCOPE-003"
    assert "bypass" in exc.reason
    assert exc.framework_ref == "EU AI Act Article 9"


@respx.mock
def test_policy_violation_carries_evaluation(client):
    respx.post(EVALUATE_URL).mock(return_value=httpx.Response(200, json=_block_response()))
    with pytest.raises(PolicyViolation) as exc_info:
        client.evaluate_input("my-agent", "bad input")
    assert isinstance(exc_info.value.evaluation, InputEvaluation)
    assert exc_info.value.evaluation.allowed is False
    assert exc_info.value.evaluation.action_taken == "block"


@respx.mock
def test_block_mode_violation_has_enforcement_mode(client):
    respx.post(EVALUATE_URL).mock(return_value=httpx.Response(200, json=_block_response()))
    with pytest.raises(PolicyViolation) as exc_info:
        client.evaluate_input("my-agent", "bypass")
    violation = exc_info.value.evaluation.violations[0]
    assert violation.enforcement_mode == "enforce"


# ---------------------------------------------------------------------------
# Warn mode — returns InputEvaluation with action_taken='warn', no raise
# ---------------------------------------------------------------------------

@respx.mock
def test_warn_mode_returns_warn_action_taken(client):
    respx.post(EVALUATE_URL).mock(return_value=httpx.Response(200, json=_warn_response()))
    result = client.evaluate_input("my-agent", "SSN: 123-45-6789")
    assert result.allowed is True
    assert result.action_taken == "warn"
    assert len(result.violations) == 1
    assert result.violations[0].rule_code == "EUAI-PII-001"
    assert result.violations[0].enforcement_mode == "warn"


@respx.mock
def test_warn_mode_does_not_raise(client):
    respx.post(EVALUATE_URL).mock(return_value=httpx.Response(200, json=_warn_response()))
    # Should not raise PolicyViolation
    result = client.evaluate_input("my-agent", "SSN: 123-45-6789")
    assert result is not None


# ---------------------------------------------------------------------------
# Log mode — server 'log' maps to SDK 'warn' (identical client behavior)
# ---------------------------------------------------------------------------

@respx.mock
def test_log_mode_maps_to_warn_action_taken(client):
    respx.post(EVALUATE_URL).mock(return_value=httpx.Response(200, json=_log_response()))
    result = client.evaluate_input("my-agent", "sensitive operation")
    assert result.allowed is True
    assert result.action_taken == "warn"  # server 'log' → SDK 'warn'
    assert len(result.violations) == 1


@respx.mock
def test_log_mode_does_not_raise(client):
    respx.post(EVALUATE_URL).mock(return_value=httpx.Response(200, json=_log_response()))
    result = client.evaluate_input("my-agent", "sensitive operation")
    assert result is not None


# ---------------------------------------------------------------------------
# Defensive default: server omits action_taken (old server version)
# ---------------------------------------------------------------------------

@respx.mock
def test_defensive_default_when_server_omits_action_taken(client):
    response_without_action_taken = {
        "data": {
            "allowed": True,
            "evaluation": {
                "policy_id": "pol_old",
                "rule_code": "INPUT-PASS-ALL",
                "result": "pass",
                "reason": None,
                "framework": None,
            },
        },
        "error": None,
        "meta": {},
    }
    respx.post(EVALUATE_URL).mock(return_value=httpx.Response(200, json=response_without_action_taken))
    result = client.evaluate_input("my-agent", "Hello")
    assert result.allowed is True
    assert result.action_taken == "pass"  # default prevents false blocks on stale server


# ---------------------------------------------------------------------------
# Network errors — fail-open by default
# ---------------------------------------------------------------------------

@respx.mock
def test_fail_open_on_network_error(client):
    respx.post(EVALUATE_URL).mock(side_effect=httpx.ConnectError("refused"))
    result = client.evaluate_input("my-agent", "Hello")
    assert result.allowed is True
    assert result.violations == []


@respx.mock
def test_fail_open_on_timeout(client):
    respx.post(EVALUATE_URL).mock(side_effect=httpx.TimeoutException("timeout"))
    result = client.evaluate_input("my-agent", "Hello")
    assert result.allowed is True


@respx.mock
def test_fail_closed_raises_gate_unavailable(client):
    respx.post(EVALUATE_URL).mock(side_effect=httpx.ConnectError("refused"))
    with pytest.raises(GateUnavailable):
        client.evaluate_input("my-agent", "Hello", fail_closed=True)


# ---------------------------------------------------------------------------
# 4xx → ClientError (always propagates)
# ---------------------------------------------------------------------------

@respx.mock
def test_raises_client_error_on_401(client):
    respx.post(EVALUATE_URL).mock(return_value=httpx.Response(401, json={"error": "Unauthorized"}))
    with pytest.raises(ClientError) as exc_info:
        client.evaluate_input("my-agent", "Hello")
    assert exc_info.value.status_code == 401


# ---------------------------------------------------------------------------
# Module-level wrapper
# ---------------------------------------------------------------------------

def test_module_level_returns_allowed_when_not_initialized():
    result = agentgovern.evaluate_input("my-agent", "Hello")
    assert result.allowed is True
