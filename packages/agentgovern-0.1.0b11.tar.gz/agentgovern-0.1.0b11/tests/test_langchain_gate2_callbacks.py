"""
Tests for Gate 2 callbacks in AgentGovernCallbackHandler.

Covers: on_agent_finish Gate 2 trigger, block/redact verdicts, on_chain_end
deduplication, streaming detection, and enforcement_mode=None passthrough.
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch
from uuid import uuid4

import httpx
import pytest
import respx

from agentgovern.exceptions import OutputBlocked, OutputEscalated
from agentgovern.instrumentors.langchain import AgentGovernCallbackHandler

_ENGINE_URL = "https://engine.test"
_EVAL_URL = f"{_ENGINE_URL}/api/v1/evaluate/action"


def _mock_client(enforcement_mode: str | None = "enforce") -> MagicMock:
    client = MagicMock()
    client.policy_engine_url = _ENGINE_URL
    client.api_key = "ag_test_key"
    client.environment = "production"
    return client


def _handler(
    enforcement_mode: str | None = "enforce",
    failure_mode: str = "fail_open",
) -> AgentGovernCallbackHandler:
    return AgentGovernCallbackHandler(
        client=_mock_client(enforcement_mode),
        agent_external_id="test-agent",
        gate_2_enforcement_mode=enforcement_mode,
        gate_2_failure_mode=failure_mode,
        gate_2_timeout_ms=500,
    )


def _agent_finish(output: str = "Loan is approved.") -> MagicMock:
    finish = MagicMock()
    finish.return_values = {"output": output}
    return finish


def _engine_response(verdict: str, **extras: object) -> dict:
    data: dict = {
        "verdict": verdict,
        "allowed": verdict in ("allow", "redact"),
        "evaluations": [],
        "review_id": None,
        "redacted_output": None,
    }
    data.update(extras)
    return {"data": data, "error": None, "meta": {}}


# ---------------------------------------------------------------------------
# on_agent_finish Gate 2 trigger
# ---------------------------------------------------------------------------


@respx.mock
def test_on_agent_finish_triggers_gate2_in_enforce_mode():
    """Allow verdict: no exception raised, track_action called for async ingest."""
    respx.post(_EVAL_URL).mock(
        return_value=httpx.Response(200, json=_engine_response("allow"))
    )
    handler = _handler("enforce")
    finish = _agent_finish()
    run_id = uuid4()
    handler.on_agent_finish(finish, run_id=run_id)

    handler._client.track_action.assert_called_once()


@respx.mock
def test_on_agent_finish_block_verdict_raises_output_blocked():
    """Block verdict in enforce mode: OutputBlocked raised."""
    respx.post(_EVAL_URL).mock(
        return_value=httpx.Response(
            200,
            json=_engine_response(
                "block",
                evaluations=[{
                    "policy_id": "pol-1",
                    "reason": "PII detected",
                    "rule_code": "FORBID-001",
                    "result": "fail",
                    "severity": "high",
                    "enforcement_mode": "enforce",
                }],
            ),
        )
    )
    handler = _handler("enforce")
    with pytest.raises(OutputBlocked):
        handler.on_agent_finish(_agent_finish(), run_id=uuid4())


@respx.mock
def test_on_agent_finish_redact_mutates_finish_output():
    """Redact verdict in enforce mode: finish.return_values["output"] is mutated."""
    redacted_payload = {"output": "Card: ****-****-****-****"}
    respx.post(_EVAL_URL).mock(
        return_value=httpx.Response(
            200,
            json=_engine_response("redact", redacted_output=redacted_payload),
        )
    )
    handler = _handler("enforce")
    finish = _agent_finish("Card: 1234-5678-9012-3456")
    handler.on_agent_finish(finish, run_id=uuid4())
    # Mutation applied
    assert finish.return_values["output"] == "Card: ****-****-****-****"


@respx.mock
def test_on_agent_finish_escalate_raises_output_escalated():
    """Escalate verdict in enforce mode: OutputEscalated raised with review_id."""
    respx.post(_EVAL_URL).mock(
        return_value=httpx.Response(
            200,
            json=_engine_response("escalate", review_id="rev-abc"),
        )
    )
    handler = _handler("enforce")
    with pytest.raises(OutputEscalated) as exc_info:
        handler.on_agent_finish(_agent_finish(), run_id=uuid4())
    assert exc_info.value.review_id == "rev-abc"


# ---------------------------------------------------------------------------
# on_chain_end deduplication
# ---------------------------------------------------------------------------


@respx.mock
def test_on_chain_end_skipped_when_gate2_already_fired():
    """on_agent_finish fires first; on_chain_end must NOT fire Gate 2 again."""
    call_count = 0
    original_post = respx.post(_EVAL_URL)

    def count_calls(request: httpx.Request) -> httpx.Response:
        nonlocal call_count
        call_count += 1
        return httpx.Response(200, json=_engine_response("allow"))

    original_post.mock(side_effect=count_calls)

    handler = _handler("enforce")
    run_id = uuid4()

    # on_agent_finish fires (Gate 2 fires once)
    handler.on_agent_finish(_agent_finish(), run_id=run_id)
    # on_chain_end fires with same run_id (should skip)
    handler.on_chain_end({"output": "Loan is approved."}, run_id=run_id)

    assert call_count == 1, "Gate 2 engine called more than once for the same run"


@respx.mock
def test_on_chain_end_skipped_for_non_root_chains():
    """on_chain_end with parent_run_id set (intermediate chain step) must be skipped."""
    respx.post(_EVAL_URL).mock(
        return_value=httpx.Response(200, json=_engine_response("allow"))
    )
    handler = _handler("enforce")
    # No engine calls should happen
    with respx.mock:
        respx.post(_EVAL_URL).mock(side_effect=AssertionError("should not call engine"))
        handler.on_chain_end(
            {"output": "Hello"},
            run_id=uuid4(),
            parent_run_id=uuid4(),  # non-root
        )


# ---------------------------------------------------------------------------
# Streaming detection
# ---------------------------------------------------------------------------


def test_streaming_agent_skips_gate2():
    """on_llm_new_token fires → streaming run recorded → on_agent_finish skips Gate 2."""
    handler = _handler("enforce")
    agent_run_id = uuid4()

    # Simulate streaming: on_llm_new_token fires with parent_run_id = agent_run_id
    handler.on_llm_new_token("Hello", run_id=uuid4(), parent_run_id=agent_run_id)

    # Verify the streaming run was recorded
    assert str(agent_run_id) in handler._streaming_run_ids

    # on_agent_finish fires: Gate 2 should be skipped (no httpx calls)
    with patch.object(handler, "_intercept_output") as mock_intercept:
        handler.on_agent_finish(_agent_finish(), run_id=agent_run_id)
        mock_intercept.assert_not_called()


# ---------------------------------------------------------------------------
# enforcement_mode=None passthrough
# ---------------------------------------------------------------------------


def test_gate2_disabled_when_enforcement_mode_none():
    """enforcement_mode=None: on_agent_finish must not call the engine."""
    handler = _handler(enforcement_mode=None)
    with patch.object(handler, "_intercept_output") as mock_intercept:
        handler.on_agent_finish(_agent_finish(), run_id=uuid4())
        mock_intercept.assert_not_called()


def test_gate2_disabled_on_chain_end_when_enforcement_mode_none():
    """enforcement_mode=None: on_chain_end (root chain) must not call the engine."""
    handler = _handler(enforcement_mode=None)
    with patch.object(handler, "_intercept_output") as mock_intercept:
        handler.on_chain_end({"output": "Hello"}, run_id=uuid4(), parent_run_id=None)
        mock_intercept.assert_not_called()


# ---------------------------------------------------------------------------
# Warn mode — no exception even for block verdict
# ---------------------------------------------------------------------------


@respx.mock
def test_warn_mode_block_verdict_does_not_raise():
    """Warn mode: block verdict must not raise, original output unchanged."""
    respx.post(_EVAL_URL).mock(
        return_value=httpx.Response(200, json=_engine_response("block"))
    )
    handler = _handler("warn")
    finish = _agent_finish("original output")
    handler.on_agent_finish(finish, run_id=uuid4())
    assert finish.return_values["output"] == "original output"


@respx.mock
def test_warn_mode_redact_does_not_mutate_output():
    """Warn mode: redact verdict must not mutate the output."""
    respx.post(_EVAL_URL).mock(
        return_value=httpx.Response(
            200,
            json=_engine_response("redact", redacted_output={"output": "masked"}),
        )
    )
    handler = _handler("warn")
    finish = _agent_finish("original output")
    handler.on_agent_finish(finish, run_id=uuid4())
    assert finish.return_values["output"] == "original output"


# ---------------------------------------------------------------------------
# on_chain_end redact mutation
# ---------------------------------------------------------------------------


@respx.mock
def test_on_chain_end_redact_mutates_outputs_dict():
    """on_chain_end with redact verdict in enforce mode mutates outputs['output'] in-place."""
    redacted_payload = {"output": "Card: ****-****-****-****"}
    respx.post(_EVAL_URL).mock(
        return_value=httpx.Response(
            200,
            json=_engine_response("redact", redacted_output=redacted_payload),
        )
    )
    handler = _handler("enforce")
    run_id = uuid4()
    outputs = {"output": "Card: 1234-5678-9012-3456"}
    # Plain root chain — no prior on_agent_finish
    handler.on_chain_end(outputs, run_id=run_id, parent_run_id=None)
    assert outputs["output"] == "Card: ****-****-****-****"


# ---------------------------------------------------------------------------
# Instance attributes
# ---------------------------------------------------------------------------


def test_handler_has_gate2_instance_attributes():
    """Verify _streaming_run_ids and _gate2_evaluated_runs are initialized as sets."""
    handler = _handler("enforce")
    assert isinstance(handler._streaming_run_ids, set)
    assert isinstance(handler._gate2_evaluated_runs, set)
    assert len(handler._streaming_run_ids) == 0
    assert len(handler._gate2_evaluated_runs) == 0
