"""
LangGraph credit decision agent — AgentGovern integration example.

Demonstrates how to attach AgentGovernLangGraphInstrumentor to a LangGraph
StateGraph for compliance tracking. The graph models a simplified credit
decision workflow used in financial services:

    customer_id input
         │
    [triage_node]  ← looks up credit score via tool call
         │
         ├── credit_score >= 700 ──► [approval_node]
         │
         └── credit_score < 700  ──► [rejection_node]

Each node execution is recorded as a DECISION span. Tool calls within a node
are TOOL_CALL spans. All spans from one graph.invoke() share the same trace_id
(the graph root run_id), so the complete audit trail can be reconstructed.

Requirements:
    pip install agentgovern[langgraph] langchain-openai

Run:
    AGENTGOVERN_API_KEY=ag_prod_... python examples/langgraph_credit_decision_agent.py
"""

from __future__ import annotations

import os
from typing import TypedDict

import agentgovern

# ---------------------------------------------------------------------------
# AgentGovern setup
# ---------------------------------------------------------------------------

agentgovern.init(
    api_key=os.environ.get("AGENTGOVERN_API_KEY", "ag_dev_example"),
    environment="development",
)

agentgovern.register_agent(
    "credit-decision-agent",
    name="Credit Decision Agent",
    framework="langgraph",
    tags=["credit", "lending", "eu-ai-act-high-risk"],
)

# Attach instrumentor. Pass gate_2_enforcement_mode="enforce" in production
# to block non-compliant outputs before they reach the caller.
handler = agentgovern.instrument_langgraph(
    "credit-decision-agent",
    gate_2_enforcement_mode=None,  # "enforce" in production
)

# ---------------------------------------------------------------------------
# Graph state schema
# ---------------------------------------------------------------------------


class CreditState(TypedDict):
    customer_id: str
    credit_score: int | None
    decision: str | None
    reason: str | None


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------

try:
    from langchain_core.tools import tool

    @tool
    def credit_score_lookup(customer_id: str) -> int:
        """Look up the credit score for a customer."""
        # In a real system this calls a credit bureau API.
        # Simulated scores for demonstration.
        scores = {"C001": 750, "C002": 620, "C003": 700}
        return scores.get(customer_id, 650)

except ImportError:
    pass  # langchain-core not installed

# ---------------------------------------------------------------------------
# Node functions
# ---------------------------------------------------------------------------


def triage_node(state: CreditState) -> CreditState:
    """Look up credit score and attach it to state."""
    # In a real LangChain-integrated graph, the tool would be invoked via
    # tool.invoke() and the callback system would capture on_tool_start/end.
    # For clarity, we call it directly here.
    score = credit_score_lookup.invoke({"customer_id": state["customer_id"]})
    return {**state, "credit_score": score}


def approval_node(state: CreditState) -> CreditState:
    """Approve the application."""
    return {
        **state,
        "decision": "approved",
        "reason": f"Credit score {state['credit_score']} meets minimum threshold (700)",
    }


def rejection_node(state: CreditState) -> CreditState:
    """Reject the application."""
    return {
        **state,
        "decision": "rejected",
        "reason": f"Credit score {state['credit_score']} below minimum threshold (700)",
    }


def route(state: CreditState) -> str:
    """Conditional edge: route based on credit score."""
    if (state.get("credit_score") or 0) >= 700:
        return "approval_node"
    return "rejection_node"


# ---------------------------------------------------------------------------
# Graph construction
# ---------------------------------------------------------------------------


def build_graph():
    from langgraph.graph import END, StateGraph

    sg = StateGraph(CreditState)
    sg.add_node("triage_node", triage_node)
    sg.add_node("approval_node", approval_node)
    sg.add_node("rejection_node", rejection_node)

    sg.set_entry_point("triage_node")
    sg.add_conditional_edges(
        "triage_node",
        route,
        {"approval_node": "approval_node", "rejection_node": "rejection_node"},
    )
    sg.add_edge("approval_node", END)
    sg.add_edge("rejection_node", END)

    return sg.compile()


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def run_example() -> None:
    graph = build_graph()

    customers = [
        ("C001", "expected: approved"),   # score=750
        ("C002", "expected: rejected"),   # score=620
        ("C003", "expected: approved"),   # score=700
    ]

    for customer_id, note in customers:
        print(f"\n--- Customer {customer_id} ({note}) ---")
        try:
            result = graph.invoke(
                {"customer_id": customer_id, "credit_score": None, "decision": None, "reason": None},
                config={"callbacks": [handler]},
            )
            print(f"Decision: {result['decision']}")
            print(f"Reason:   {result['reason']}")
            print(f"Score:    {result['credit_score']}")
        except Exception as exc:
            print(f"Error: {exc}")

    # Optional: flush remaining spans before exiting
    agentgovern.shutdown()
    print("\nAll invocations complete. Spans flushed to AgentGovern.")


if __name__ == "__main__":
    run_example()
