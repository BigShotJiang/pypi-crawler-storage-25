import threading

import fastmcp
from serial import Serial  # type: ignore[import-untyped]
from serial.tools import list_ports as list_ports_module  # type: ignore[import-untyped]

mcp = fastmcp.FastMCP("mcp-rs232")

_open_ports: dict[str, Serial] = {}
_port_lock = threading.Lock()


class PortNotFoundError(Exception):
    """Raised when the specified port does not exist."""

    pass


class PortAlreadyOpenError(Exception):
    """Raised when attempting to open a port that is already open."""

    pass


class PortNotOpenError(Exception):
    """Raised when attempting to read/write to a port that is not open."""

    pass


class PortInUseError(Exception):
    """Raised when the port is in use by another process."""

    pass


class InvalidParameterError(Exception):
    """Raised when an invalid parameter is provided."""

    pass


class SerialTimeoutError(Exception):
    """Raised when a serial operation times out."""

    pass


def _validate_port_name(port: str) -> None:
    if not port:
        raise InvalidParameterError("Port name cannot be empty")


def _get_serial_port_class() -> type[Serial]:
    return Serial  # type: ignore[no-any-return]


@mcp.resource("serial://ports")
def list_ports() -> list[dict[str, str]]:
    """List all available serial ports on the system.

    Returns:
        List of dictionaries containing port information including
        name, description, and hardware ID for each available port.
    """
    ports = list_ports_module.comports()
    return [
        {
            "name": port.name,
            "description": port.description,
            "hwid": port.hwid,
        }
        for port in ports
    ]


@mcp.resource("serial://port/{port_name}")
def get_port_info(port_name: str) -> dict[str, str]:
    """Get detailed information about a specific serial port.

    Args:
        port_name: The name of the port to query.

    Returns:
        Dictionary containing port details.

    Raises:
        PortNotFoundError: If the port does not exist.
    """
    ports = list_ports_module.comports()
    for port in ports:
        if port.name == port_name:
            return {
                "name": port.name,
                "description": port.description,
                "hwid": port.hwid,
            }
    raise PortNotFoundError(f"Port '{port_name}' not found")


@mcp.tool()
def list_ports_tool() -> list[dict[str, str]]:
    """Tool to list all available serial ports.

    Returns:
        List of available serial ports with their details.
    """
    return list_ports()


def _validate_baud_rate(baud_rate: int) -> None:
    valid_baud_rates = [
        50,
        75,
        110,
        134,
        150,
        200,
        300,
        600,
        1200,
        1800,
        2400,
        4800,
        9600,
        19200,
        38400,
        57600,
        115200,
        230400,
        460800,
        921600,
    ]
    if baud_rate not in valid_baud_rates:
        raise InvalidParameterError(
            f"Invalid baud rate: {baud_rate}. Valid rates: {valid_baud_rates}"
        )


def _validate_parity(parity: str) -> None:
    valid_parities = {"none", "even", "odd", "mark", "space"}
    if parity not in valid_parities:
        raise InvalidParameterError(
            f"Invalid parity: {parity}. Valid options: {valid_parities}"
        )


def _validate_stop_bits(stop_bits: float) -> None:
    valid_stop_bits = {1, 1.5, 2}
    if stop_bits not in valid_stop_bits:
        raise InvalidParameterError(
            f"Invalid stop bits: {stop_bits}. Valid options: {valid_stop_bits}"
        )


def _validate_data_bits(data_bits: int) -> None:
    valid_data_bits = {5, 6, 7, 8}
    if data_bits not in valid_data_bits:
        raise InvalidParameterError(
            f"Invalid data bits: {data_bits}. Valid options: {valid_data_bits}"
        )


@mcp.tool()
def open_port(
    port: str,
    baud_rate: int = 9600,
    parity: str = "none",
    stop_bits: float = 1,
    data_bits: int = 8,
    timeout: float = 1.0,
) -> bool:
    """Open a serial port connection.

    Args:
        port: The name of the port (e.g., "COM1", "/dev/ttyUSB0").
        baud_rate: The baud rate for communication (default: 9600).
        parity: Parity mode - "none", "even", "odd", "mark", "space" (default: "none").
        stop_bits: Number of stop bits - 1, 1.5, or 2 (default: 1).
        data_bits: Number of data bits - 5, 6, 7, or 8 (default: 8).
        timeout: Read timeout in seconds (default: 1.0).

    Returns:
        True if the port was opened successfully.

    Raises:
        PortNotFoundError: If the port does not exist.
        PortAlreadyOpenError: If the port is already open.
        PortInUseError: If the port is in use by another process.
        InvalidParameterError: If any parameter is invalid.
    """
    _validate_port_name(port)
    _validate_baud_rate(baud_rate)
    _validate_parity(parity)
    _validate_stop_bits(stop_bits)
    _validate_data_bits(data_bits)

    with _port_lock:
        if port in _open_ports:
            raise PortAlreadyOpenError(f"Port '{port}' is already open")

        available_ports = [p.name for p in list_ports_module.comports()]
        if port not in available_ports:
            raise PortNotFoundError(f"Port '{port}' not found")

        try:
            serial = Serial(
                port=port,
                baudrate=baud_rate,
                parity=parity.upper()[:1],
                stopbits=stop_bits,
                bytesize=data_bits,
                timeout=timeout,
            )
            _open_ports[port] = serial
            return True
        except OSError as e:
            if "Permission" in str(e) or "Access denied" in str(e):
                raise PortInUseError(f"Port '{port}' is in use by another process")
            raise


@mcp.tool()
def close_port(port: str) -> bool:
    """Close an open serial port connection.

    Args:
        port: The name of the port to close.

    Returns:
        True if the port was closed successfully.

    Raises:
        PortNotFoundError: If the port does not exist or is not open.
    """
    _validate_port_name(port)

    with _port_lock:
        if port not in _open_ports:
            raise PortNotFoundError(f"Port '{port}' is not open")

        serial = _open_ports.pop(port)
        serial.close()
        return True


@mcp.tool()
def read_port(port: str, size: int = 4096, timeout: float | None = None) -> str:
    """Read data from an open serial port.

    Args:
        port: The name of the port to read from.
        size: Maximum number of bytes to read (default: 4096, max: 4096).
        timeout: Optional timeout override in seconds.

    Returns:
        Hex-encoded string of the data read. Empty string if no data available.

    Raises:
        PortNotFoundError: If the port is not open.
    """
    _validate_port_name(port)

    if size > 4096:
        size = 4096
    if size <= 0:
        return ""

    with _port_lock:
        if port not in _open_ports:
            raise PortNotOpenError(f"Port '{port}' is not open")

        serial = _open_ports[port]

        if timeout is not None:
            original_timeout = serial.timeout
            serial.timeout = timeout

        try:
            data = serial.read(size)
            return data.hex()  # type: ignore[no-any-return]
        finally:
            if timeout is not None:
                serial.timeout = original_timeout


@mcp.tool()
def write_port(port: str, data: str) -> int:
    """Write data to an open serial port.

    Args:
        port: The name of the port to write to.
        data: Hex-encoded string of data to write (e.g., "48656c6c6f" for "Hello").

    Returns:
        Number of bytes written.

    Raises:
        PortNotFoundError: If the port is not open.
        InvalidParameterError: If the data is not valid hex.
    """
    _validate_port_name(port)

    try:
        byte_data = bytes.fromhex(data)
    except ValueError:
        raise InvalidParameterError("Data must be a valid hex string")

    with _port_lock:
        if port not in _open_ports:
            raise PortNotOpenError(f"Port '{port}' is not open")

        serial = _open_ports[port]
        written = serial.write(byte_data)
        return written  # type: ignore[no-any-return]


@mcp.tool()
def get_port_config(port: str) -> dict[str, object]:
    """Get the current configuration of an open serial port.

    Args:
        port: The name of the port to query.

    Returns:
        Dictionary containing the port configuration.

    Raises:
        PortNotFoundError: If the port is not open.
    """
    _validate_port_name(port)

    with _port_lock:
        if port not in _open_ports:
            raise PortNotOpenError(f"Port '{port}' is not open")

        serial = _open_ports[port]
        return {
            "port": serial.port,
            "baud_rate": serial.baudrate,
            "parity": serial.parity,
            "stop_bits": serial.stopbits,
            "data_bits": serial.bytesize,
            "timeout": serial.timeout,
            "is_open": serial.is_open,
        }
