__version__ = "0.1.0"
__all__ = [
    "mcp",
    "list_ports",
    "open_port",
    "close_port",
    "read_port",
    "write_port",
    "get_port_config",
]

from ._core import (
    close_port,
    get_port_config,
    list_ports,
    mcp,
    open_port,
    read_port,
    write_port,
)
