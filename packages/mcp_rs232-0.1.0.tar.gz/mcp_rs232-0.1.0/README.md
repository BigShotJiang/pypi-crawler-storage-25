# mcp-rs232

> An MCP server that exposes RS232 serial port connectivity

[![PyPI](https://img.shields.io/pypi/v/mcp-rs232.svg)](https://pypi.org/project/mcp-rs232/)
[![Python](https://img.shields.io/pypi/pyversions/mcp-rs232.svg)](https://pypi.org/project/mcp-rs232/)
[![Ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json)](https://github.com/astral-sh/ruff)

mcp-name: io.github.daedalus/mcp-rs232

## Install

```bash
pip install mcp-rs232
```

## Usage

```python
from mcp_rs232 import list_ports, open_port, close_port, read_port, write_port

# List available ports
ports = list_ports()
print(ports)

# Open a port
open_port("COM1", baud_rate=9600)

# Write data (hex encoded)
write_port("COM1", "48656c6c6f")  # "Hello"

# Read data (returns hex encoded)
data = read_port("COM1")

# Close the port
close_port("COM1")
```

## CLI

```bash
mcp-rs232 --help
```

## API

### Resources

- `serial://ports` - Lists all available serial ports with their details
- `serial://port/{port_name}` - Get details about a specific port

### Tools

- `list_ports_tool()` - Returns list of available serial ports
- `open_port(port, baud_rate, ...)` - Opens a serial connection
- `close_port(port)` - Closes a serial connection
- `read_port(port, size, timeout)` - Reads data from port (hex encoded)
- `write_port(port, data)` - Writes hex-encoded data to port
- `get_port_config(port)` - Returns current port configuration

## Development

```bash
git clone https://github.com/daedalus/mcp-rs232.git
cd mcp-rs232
pip install -e ".[test]"

# run tests
pytest

# format
ruff format src/ tests/

# lint
ruff check src/ tests/

# type check
mypy src/
```
