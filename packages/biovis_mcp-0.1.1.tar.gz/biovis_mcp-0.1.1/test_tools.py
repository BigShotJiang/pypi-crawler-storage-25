import sys
import os
import json
import numpy as np
import pandas as pd

# Add current and src directories to path for imports
sys.path.append(os.getcwd())
sys.path.append(os.path.join(os.getcwd(), "src"))

from biovis_mcp.tools.volcano import plot_volcano
from biovis_mcp.tools.enrichment import plot_bar_enrichment
from biovis_mcp.tools.heatmap import plot_heatmap
from biovis_mcp.tools.pca import plot_pca
from biovis_mcp.tools.bubble_enrichment import plot_bubble_enrichment
from biovis_mcp.tools.ma_plot import plot_ma
from biovis_mcp.tools.report import generate_figure_caption, create_comprehensive_report

def run_full_pipeline():
    print("Running full BioVis-MCP Pipeline (Plot -> Caption -> Report)...")
    
    report_figures = []
    
    # 1. Volcano Plot
    print("\n- Generating Volcano Plot...")
    v_data = [{"gene_id": f"G_{i}", "log2_fold_change": np.random.uniform(-3, 3), "p_value": np.random.uniform(0.0001, 0.1)} for i in range(100)]
    v_res = plot_volcano(v_data)
    if v_res["status"] == "success":
        caption = generate_figure_caption("volcano", v_res["stats"])
        report_figures.append({"path": v_res["file_path"], "caption": caption})
        print(f"  Done: {os.path.basename(v_res['file_path'])}")
    
    # 2. PCA Plot
    print("\n- Generating PCA Plot...")
    genes = [f"G_{i}" for i in range(50)]
    samples = [f"S_{j}" for j in range(6)]
    p_data = [{"gene_id": g, **{s: np.random.randn() for s in samples}} for g in genes]
    p_res = plot_pca(p_data)
    if p_res["status"] == "success":
        caption = generate_figure_caption("pca", p_res["stats"])
        report_figures.append({"path": p_res["file_path"], "caption": caption})
        print(f"  Done: {os.path.basename(p_res['file_path'])}")

    # 3. Heatmap Plot
    print("\n- Generating Heatmap Plot...")
    h_data = [{"gene_id": f"G_{i}", **{f"S_{j}": np.random.randn() for j in range(5)}} for i in range(20)]
    h_res = plot_heatmap(h_data)
    if h_res["status"] == "success":
        caption = generate_figure_caption("heatmap", h_res["stats"])
        report_figures.append({"path": h_res["file_path"], "caption": caption})
        print(f"  Done: {os.path.basename(h_res['file_path'])}")

    # 4. Bubble Enrichment Plot
    print("\n- Generating Bubble Enrichment Plot...")
    b_data = [{"pathway_name": f"Pathway {i}", "gene_count": np.random.randint(5, 50), "p_value": np.random.uniform(0.0001, 0.05)} for i in range(15)]
    b_res = plot_bubble_enrichment(b_data)
    if b_res["status"] == "success":
        caption = generate_figure_caption("bubble", b_res["stats"])
        report_figures.append({"path": b_res["file_path"], "caption": caption})
        print(f"  Done: {os.path.basename(b_res['file_path'])}")

    # 5. MA Plot
    print("\n- Generating MA Plot...")
    m_data = [{"gene_id": f"G_{i}", "mean_expression": np.random.uniform(0, 10), "log2_fold_change": np.random.uniform(-4, 4), "p_value": np.random.uniform(0.0001, 0.1)} for i in range(100)]
    m_res = plot_ma(m_data)
    if m_res["status"] == "success":
        caption = generate_figure_caption("ma", m_res["stats"])
        report_figures.append({"path": m_res["file_path"], "caption": caption})
        print(f"  Done: {os.path.basename(m_res['file_path'])}")

    # 6. Bar Enrichment Plot
    print("\n- Generating Bar Enrichment Plot...")
    e_data = [{"pathway_name": f"Pathway {i}", "gene_count": i * 10} for i in range(1, 6)]
    e_res = plot_bar_enrichment(e_data)
    if e_res["status"] == "success":
        caption = generate_figure_caption("enrichment", e_res["stats"])
        report_figures.append({"path": e_res["file_path"], "caption": caption})
        print(f"  Done: {os.path.basename(e_res['file_path'])}")

    # 7. Generate PDF Report
    print("\n- Creating PDF Report...")
    pdf_res = create_comprehensive_report(report_figures, format="pdf", report_name="Comprehensive_BioVis_Report")
    if pdf_res["status"] == "success":
        print(f"  SUCCESS: PDF Report saved to {pdf_res['file_path']}")
    else:
        print(f"  FAILED: {pdf_res['message']}")

    # 8. Generate DOCX Report
    print("\n- Creating DOCX Report...")
    docx_res = create_comprehensive_report(report_figures, format="docx", report_name="Comprehensive_BioVis_Report")
    if docx_res["status"] == "success":
        print(f"  SUCCESS: DOCX Report saved to {docx_res['file_path']}")
    else:
        print(f"  FAILED: {docx_res['message']}")

if __name__ == "__main__":
    run_full_pipeline()
