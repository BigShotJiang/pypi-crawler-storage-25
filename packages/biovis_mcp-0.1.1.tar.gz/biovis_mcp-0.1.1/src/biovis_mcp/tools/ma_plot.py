import os
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np
from datetime import datetime
from biovis_mcp.utils.style import set_pub_style, cleanup_plot

def plot_ma(data: list[dict], title: str = "MA Plot", pval_threshold: float = 0.05):
    """
    Generate an MA plot.
    
    Expected schema for records in data:
    {
        "gene_id": str,
        "mean_expression": float, # A-value (intensity)
        "log2_fold_change": float, # M-value (ratio)
        "p_value": float
    }
    """
    if not data:
        return {"status": "error", "message": "Data list is empty.", "code": "EMPTY_DATA"}
    
    try:
        df = pd.DataFrame(data)
        required_keys = ["gene_id", "mean_expression", "log2_fold_change", "p_value"]
        for key in required_keys:
            if key not in df.columns:
                return {"status": "error", "message": f"Missing required key: {key}", "code": "MISSING_KEY"}
        
        # Classification
        df['sig_group'] = 'Non-significant'
        df.loc[df['p_value'] < pval_threshold, 'sig_group'] = 'Significant'
        
        # Style
        set_pub_style()
        
        plt.figure(figsize=(10, 8))
        
        # Plotting
        color_map = {
            'Significant': '#d62728', # Red
            'Non-significant': 'gray'
        }
        
        for group, color in color_map.items():
            mask = df['sig_group'] == group
            plt.scatter(df.loc[mask, 'mean_expression'], df.loc[mask, 'log2_fold_change'], 
                        color=color, alpha=0.6, label=group, s=20)
        
        plt.axhline(0, color='black', linestyle='--', linewidth=0.8)
        
        plt.xlabel('Mean Expression (A)')
        plt.ylabel('log2 Fold Change (M)')
        plt.title(title)
        
        plt.legend()
        cleanup_plot()
        
        # Output directory
        output_dir = "figures"
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
            
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"ma_{timestamp}.png"
        filepath = os.path.abspath(os.path.join(output_dir, filename))
        
        plt.savefig(filepath, dpi=300, bbox_inches='tight')
        plt.close()
        
        return {
            "status": "success",
            "file_path": filepath,
            "stats": {
                "total_genes": len(df),
                "significant": int((df['sig_group'] == 'Significant').sum())
            },
            "next_tool_hint": {
                 "tool": "plot_volcano",
                 "reason": "Visualize significance vs fold change using Volcano plot."
            }
        }
    except Exception as e:
        return {"status": "error", "message": str(e), "code": "RUNTIME_ERROR"}
