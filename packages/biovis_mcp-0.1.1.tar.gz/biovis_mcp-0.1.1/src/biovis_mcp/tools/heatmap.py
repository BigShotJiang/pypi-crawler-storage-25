import os
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from datetime import datetime
from biovis_mcp.utils.style import set_pub_style, cleanup_plot

def plot_heatmap(data: list[dict], title: str = "Expression Heatmap", cluster: bool = True, cmap: str = "RdBu_r"):
    """
    Generate a heatmap from an expression matrix.
    
    Expected schema for records in data:
    {
        "gene_id": str,
        "sample1": float,
        "sample2": float,
        ...
    }
    """
    if not data:
        return {"status": "error", "message": "Data list is empty.", "code": "EMPTY_DATA"}
    
    try:
        df = pd.DataFrame(data)
        if "gene_id" not in df.columns:
            return {"status": "error", "message": "Missing required key: gene_id", "code": "MISSING_KEY"}
        
        df = df.set_index("gene_id")
        
        # Style
        set_pub_style()
        
        if cluster:
            # Using sns.clustermap for hierarchical clustering
            g = sns.clustermap(df, cmap=cmap, center=0, 
                               linewidths=.5, figsize=(10, 10))
            g.fig.suptitle(title, y=1.02)
            plt.setp(g.ax_heatmap.get_yticklabels(), rotation=0)
            fig = g.fig
        else:
            plt.figure(figsize=(10, 8))
            sns.heatmap(df, cmap=cmap, center=0, annot=False)
            plt.title(title)
            cleanup_plot()
            fig = plt.gcf()
            
        # Output directory
        output_dir = "figures"
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
            
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"heatmap_{timestamp}.png"
        filepath = os.path.abspath(os.path.join(output_dir, filename))
        
        fig.savefig(filepath, dpi=300, bbox_inches='tight')
        plt.close('all')
        
        return {
            "status": "success",
            "file_path": filepath,
            "stats": {
                "num_genes": len(df),
                "num_samples": len(df.columns)
            },
            "next_tool_hint": {
                 "tool": "plot_pca",
                 "reason": "Visualize sample relationships using PCA."
            }
        }
    except Exception as e:
        return {"status": "error", "message": str(e), "code": "RUNTIME_ERROR"}
