import os
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime
from biovis_mcp.utils.style import set_pub_style, cleanup_plot

def plot_bar_enrichment(data: list[dict], title: str = "Pathway Enrichment", top_n: int = 20, color: str = "#2196F3"):
    """
    Generate a horizontal bar chart of pathway enrichment results.
    
    Expected schema for records in data:
    {
        "pathway_name": str,
        "gene_count": int
    }
    """
    if not data:
        return {"status": "error", "message": "Data list is empty.", "code": "EMPTY_DATA"}
    
    try:
        df = pd.DataFrame(data)
        required_keys = ["pathway_name", "gene_count"]
        for key in required_keys:
            if key not in df.columns:
                return {"status": "error", "message": f"Missing required key: {key}", "code": "MISSING_KEY"}
        
        # Validation: Check for gene_count being numeric
        if not pd.to_numeric(df['gene_count'], errors='coerce').notnull().all():
            return {"status": "error", "message": "gene_count contains non-numeric values.", "code": "INVALID_VALUE"}
            
        df['gene_count'] = pd.to_numeric(df['gene_count'])
        df = df.sort_values(by='gene_count', ascending=True) # Barh expects bottom-up for highest at top
        
        # Take Top N
        df = df.tail(top_n)
        
        # Style
        set_pub_style()
        
        plt.figure(figsize=(10, 0.5 * len(df) + 2))
        
        # Plotting
        bars = plt.barh(df['pathway_name'].apply(lambda x: (x[:47] + '...') if len(x) > 50 else x), 
                        df['gene_count'], color=color)
        
        # Add labels
        for bar in bars:
            width = bar.get_width()
            plt.text(width + 0.3, bar.get_y() + bar.get_height()/2, 
                     f'{int(width)}', va='center', fontsize=9)
            
        plt.xlabel('Gene Count')
        plt.title(title)
        
        # Horizontal grids
        plt.gca().xaxis.grid(True, linestyle='--', alpha=0.6)
        
        cleanup_plot()
        
        # Output directory
        output_dir = "figures"
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
            
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"enrichment_{timestamp}.png"
        filepath = os.path.abspath(os.path.join(output_dir, filename))
        
        plt.savefig(filepath, dpi=300, bbox_inches='tight')
        plt.close()
        
        # Stats
        stats = {
            "total_pathways_input": len(data),
            "pathways_shown": len(df),
            "max_gene_count": int(df['gene_count'].max())
        }
        
        return {
            "status": "success",
            "file_path": filepath,
            "stats": stats,
            "next_tool_hint": {
                 "tool": "search_literature",
                 "reason": "Use BioCite-MCP's search_literature to find papers on the top enriched pathways."
            }
        }
    except Exception as e:
        return {"status": "error", "message": str(e), "code": "RUNTIME_ERROR"}
