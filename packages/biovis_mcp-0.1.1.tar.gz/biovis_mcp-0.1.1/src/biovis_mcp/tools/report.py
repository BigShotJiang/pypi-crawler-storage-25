import os
from datetime import datetime
from fpdf import FPDF
from docx import Document
from docx.shared import Inches

def generate_figure_caption(tool_type: str, stats: dict) -> str:
    """Generates a professional scientific caption based on tool statistics."""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")
    
    if tool_type == "volcano":
        return (f"Figure: Volcano plot generated on {timestamp}. "
                f"Analysis shows {stats.get('total_genes', 0)} total genes, "
                f"with {stats.get('upregulated', 0)} significantly upregulated (red) and "
                f"{stats.get('downregulated', 0)} significantly downregulated (blue).")
    
    elif tool_type == "enrichment":
        return (f"Figure: Pathway enrichment bar chart generated on {timestamp}. "
                f"Showing top {stats.get('pathways_shown', 0)} pathways out of "
                f"{stats.get('total_pathways_input', 0)} total input pathways. "
                f"Maximum gene count observed is {stats.get('max_gene_count', 0)}.")
    
    elif tool_type == "heatmap":
        return (f"Figure: Expression heatmap generated on {timestamp}. "
                f"Visualizing expression levels of {stats.get('num_genes', 0)} genes across "
                f"{stats.get('num_samples', 0)} samples. "
                f"Hierarchical clustering applied to reveal expression patterns.")
    
    elif tool_type == "pca":
        return (f"Figure: PCA plot generated on {timestamp}. "
                f"Principal Component Analysis of {stats.get('num_samples', 0)} samples. "
                f"PC1 accounts for {stats.get('pc1_variance', '0%')} and "
                f"PC2 accounts for {stats.get('pc2_variance', '0%')} of total variance.")
    
    elif tool_type == "bubble":
        return (f"Figure: Enrichment bubble chart generated on {timestamp}. "
                f"Showing {stats.get('pathways_shown', 0)} pathways. "
                f"Point size indicates gene count, and color indicates significance (-log10 p-value).")
    
    elif tool_type == "ma":
        return (f"Figure: MA plot generated on {timestamp}. "
                f"Comparison of {stats.get('total_genes', 0)} genes. "
                f"Red points indicate {stats.get('significant', 0)} statistically significant genes.")
    
    return f"Figure: Automated visualization generated on {timestamp}."

def create_comprehensive_report(figures: list[dict], format: str = "pdf", report_name: str = "BioVis_Report"):
    """
    Creates a comprehensive report in PDF or DOCX format.
    
    'figures' should be a list of dicts: [{'path': str, 'caption': str}, ...]
    """
    output_dir = "reports"
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{report_name}_{timestamp}.{format}"
    filepath = os.path.abspath(os.path.join(output_dir, filename))
    
    try:
        if format.lower() == "pdf":
            pdf = FPDF()
            pdf.set_auto_page_break(auto=True, margin=15)
            pdf.add_page()
            
            # Title
            pdf.set_font("Arial", 'B', 16)
            pdf.cell(0, 10, "BioVis-MCP Automated Analysis Report", 0, 1, 'C')
            pdf.set_font("Arial", '', 10)
            pdf.cell(0, 10, f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", 0, 1, 'C')
            pdf.ln(10)
            
            for fig in figures:
                if os.path.exists(fig['path']):
                    # Add Image
                    pdf.image(fig['path'], x=10, w=190)
                    pdf.ln(5)
                    # Add Caption
                    pdf.set_font("Arial", 'I', 10)
                    pdf.multi_cell(0, 5, fig['caption'])
                    pdf.ln(10)
            
            pdf.output(filepath)
            
        elif format.lower() == "docx":
            doc = Document()
            doc.add_heading("BioVis-MCP Automated Analysis Report", 0)
            doc.add_paragraph(f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
            
            for fig in figures:
                if os.path.exists(fig['path']):
                    doc.add_picture(fig['path'], width=Inches(6))
                    p = doc.add_paragraph()
                    p.add_run(fig['caption']).italic = True
            
            doc.save(filepath)
            
        else:
            return {"status": "error", "message": f"Unsupported format: {format}", "code": "INVALID_FORMAT"}
            
        return {
            "status": "success",
            "file_path": filepath,
            "message": f"Report successfully generated at {filepath}"
        }
        
    except Exception as e:
        return {"status": "error", "message": str(e), "code": "REPORT_ERROR"}
