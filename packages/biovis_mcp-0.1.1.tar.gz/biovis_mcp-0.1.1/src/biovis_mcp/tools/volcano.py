import os
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from datetime import datetime
from biovis_mcp.utils.style import set_pub_style, cleanup_plot

def plot_volcano(data: list[dict], title: str = "Volcano Plot", fc_threshold: float = 1.0, pval_threshold: float = 0.05):
    """
    Generate a Volcano plot from gene records.
    
    Expected schema for records in data:
    {
        "gene_id": str,
        "log2_fold_change": float,
        "p_value": float
    }
    """
    if not data:
        return {"status": "error", "message": "Data list is empty.", "code": "EMPTY_DATA"}
    
    try:
        df = pd.DataFrame(data)
        required_keys = ["gene_id", "log2_fold_change", "p_value"]
        for key in required_keys:
            if key not in df.columns:
                return {"status": "error", "message": f"Missing required key: {key}", "code": "MISSING_KEY"}
        
        # Validation: Check for p-values being 0
        if (df['p_value'] == 0).any():
             return {"status": "error", "message": "p_value cannot be 0 (log10 is undefined).", "code": "INVALID_VALUE"}

        # Calculate -log10(p-value)
        df['-log10_p'] = -np.log10(df['p_value'])
        
        # Classification
        df['sig_group'] = 'Non-significant'
        df.loc[(df['log2_fold_change'] > fc_threshold) & (df['p_value'] < pval_threshold), 'sig_group'] = 'Upregulated'
        df.loc[(df['log2_fold_change'] < -fc_threshold) & (df['p_value'] < pval_threshold), 'sig_group'] = 'Downregulated'

        # Set style
        set_pub_style()
        
        plt.figure(figsize=(10, 8))
        
        # Plotting
        color_map = {
            'Upregulated': '#d62728', # Red
            'Downregulated': '#1f77b4', # Blue
            'Non-significant': 'gray'
        }
        
        for group, color in color_map.items():
            mask = df['sig_group'] == group
            plt.scatter(df.loc[mask, 'log2_fold_change'], df.loc[mask, '-log10_p'], 
                        color=color, alpha=0.6, label=group, s=20)
        
        # Threshold lines
        plt.axhline(-np.log10(pval_threshold), color='black', linestyle='--', linewidth=0.8)
        plt.axvline(fc_threshold, color='black', linestyle='--', linewidth=0.8)
        plt.axvline(-fc_threshold, color='black', linestyle='--', linewidth=0.8)
        
        plt.xlabel('log2 Fold Change')
        plt.ylabel('-log10(p-value)')
        plt.title(title)
        
        plt.legend()
        cleanup_plot()
        
        # Output directory
        output_dir = "figures"
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
            
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"volcano_{timestamp}.png"
        filepath = os.path.abspath(os.path.join(output_dir, filename))
        
        plt.savefig(filepath, dpi=300, bbox_inches='tight')
        plt.close()
        
        # Stats
        stats = {
            "total_genes": len(df),
            "upregulated": int((df['sig_group'] == 'Upregulated').sum()),
            "downregulated": int((df['sig_group'] == 'Downregulated').sum()),
            "non_significant": int((df['sig_group'] == 'Non-significant').sum())
        }
        
        return {
            "status": "success",
            "file_path": filepath,
            "stats": stats,
            "next_tool_hint": {
                 "tool": "plot_bar_enrichment",
                 "reason": "Run pathway enrichment on the significant genes and visualize with plot_bar_enrichment."
            }
        }
    except Exception as e:
        return {"status": "error", "message": str(e), "code": "RUNTIME_ERROR"}
