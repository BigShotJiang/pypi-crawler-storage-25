import os
import sys
from mcp.server.fastmcp import FastMCP
from biovis_mcp.tools.volcano import plot_volcano
from biovis_mcp.tools.enrichment import plot_bar_enrichment
from biovis_mcp.tools.heatmap import plot_heatmap
from biovis_mcp.tools.pca import plot_pca
from biovis_mcp.tools.bubble_enrichment import plot_bubble_enrichment
from biovis_mcp.tools.ma_plot import plot_ma
from biovis_mcp.tools.report import generate_figure_caption, create_comprehensive_report

# Initialize FastMCP server
mcp = FastMCP("BioVis-MCP")

# Ensure figures and reports directories exist on startup
for directory in ["figures", "reports"]:
    if not os.path.exists(directory):
        os.makedirs(directory)
        print(f"Created '{directory}' directory.")

@mcp.tool()
def generate_volcano_plot(data: list[dict], title: str = "Volcano Plot", fc_threshold: float = 1.0, pval_threshold: float = 0.05):
    """
    Generate a publication-quality Volcano plot from differential expression data.
    
    Args:
        data: List of dicts, each with 'gene_id', 'log2_fold_change', and 'p_value'.
        title: Optional plot title.
        fc_threshold: Fold change threshold for significance (default 1.0).
        pval_threshold: P-value threshold for significance (default 0.05).
    """
    return plot_volcano(data, title, fc_threshold, pval_threshold)

@mcp.tool()
def generate_bar_enrichment(data: list[dict], title: str = "Pathway Enrichment", top_n: int = 20, color: str = "#2196F3"):
    """
    Generate a horizontal bar chart for pathway enrichment results.
    
    Args:
        data: List of dicts, each with 'pathway_name' and 'gene_count'.
        title: Optional plot title.
        top_n: Number of top pathways to show (default 20).
        color: Bar color hex code (default #2196F3).
    """
    return plot_bar_enrichment(data, title, top_n, color)

@mcp.tool()
def generate_heatmap_plot(data: list[dict], title: str = "Expression Heatmap", cluster: bool = True, cmap: str = "RdBu_r"):
    """
    Generate a heatmap from an expression matrix.
    
    Args:
        data: List of dicts, each with 'gene_id' and sample values.
        title: Optional plot title.
        cluster: Whether to perform hierarchical clustering (default True).
        cmap: Colormap (default 'RdBu_r').
    """
    return plot_heatmap(data, title, cluster, cmap)

@mcp.tool()
def generate_pca_plot(data: list[dict], metadata: list[dict] = None, title: str = "PCA Plot", group_col: str = None):
    """
    Generate a Principal Component Analysis (PCA) plot.
    
    Args:
        data: List of dicts, each with 'gene_id' and sample values.
        metadata: Optional metadata for samples.
        title: Optional plot title.
        group_col: Column name in metadata to color points by.
    """
    return plot_pca(data, metadata, title, group_col)

@mcp.tool()
def generate_bubble_enrichment(data: list[dict], title: str = "Enrichment Bubble Chart", top_n: int = 20):
    """
    Generate a bubble chart for pathway enrichment results.
    
    Args:
        data: List of dicts, with 'pathway_name', 'gene_count' and 'p_value'.
        title: Optional plot title.
        top_n: Number of top pathways to show (default 20).
    """
    return plot_bubble_enrichment(data, title, top_n)

@mcp.tool()
def generate_ma_plot(data: list[dict], title: str = "MA Plot", pval_threshold: float = 0.05):
    """
    Generate an MA plot.
    
    Args:
        data: List of dicts, with 'gene_id', 'mean_expression', 'log2_fold_change' and 'p_value'.
        title: Optional plot title.
        pval_threshold: P-value threshold for significance (default 0.05).
    """
    return plot_ma(data, title, pval_threshold)

@mcp.tool()
def get_figure_caption(tool_type: str, stats: dict) -> str:
    """
    Generate a professional scientific caption for a figure based on its statistics.
    
    Args:
        tool_type: Type of visualization tool ('volcano', 'enrichment', 'heatmap', 'pca', 'bubble', 'ma').
        stats: Statistics dictionary returned from the visualization tool.
    """
    return generate_figure_caption(tool_type, stats)

@mcp.tool()
def create_report(figures_with_captions: list[dict], format: str = "pdf", report_name: str = "BioVis_Report"):
    """
    Create a comprehensive report (PDF or DOCX) containing multiple figures and their captions.
    
    Args:
        figures_with_captions: List of dicts, each with 'path' (str) and 'caption' (str).
        format: Output format ('pdf' or 'docx').
        report_name: Optional custom name for the report file.
    """
    return create_comprehensive_report(figures_with_captions, format, report_name)

def main():
    mcp.run()

if __name__ == "__main__":
    main()
