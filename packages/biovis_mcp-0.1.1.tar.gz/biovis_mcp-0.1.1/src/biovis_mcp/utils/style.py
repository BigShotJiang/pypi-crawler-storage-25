import matplotlib.pyplot as plt
import seaborn as sns

def set_pub_style():
    """Sets a standard publication-ready style for matplotlib figures."""
    sns.set_theme(style="white", palette="muted")
    
    # Global RcParams
    plt.rcParams.update({
        'figure.dpi': 300,
        'savefig.dpi': 300,
        'savefig.bbox': 'tight',
        'font.family': 'sans-serif',
        'font.sans-serif': ['Arial', 'DejaVu Sans'],
        'font.size': 10,
        'axes.labelsize': 12,
        'axes.titlesize': 14,
        'xtick.labelsize': 10,
        'ytick.labelsize': 10,
        'legend.fontsize': 10,
        'axes.spines.top': False,
        'axes.spines.right': False,
    })

def cleanup_plot():
    """Final adjustments before saving a plot."""
    sns.despine()
    plt.tight_layout()
