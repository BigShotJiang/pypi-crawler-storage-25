# PRD: BioVis-MCP
**Product Requirements Document — v1.0**
*Last Updated: 2026-04-06*

---

## 1. Overview

### 1.1 Problem Statement

Generating publication-quality figures is a significant bottleneck in bioinformatics workflows. Researchers either spend hours manually tweaking matplotlib/seaborn code, or submit figures at inadequate resolution. LLMs can generate plotting code but cannot natively render or save high-DPI images. There is no standard MCP tool that accepts raw biological data and returns a manuscript-ready figure path.

### 1.2 Product Vision

`BioVis-MCP` is a FastMCP server that acts as a local figure-rendering engine. The LLM host sends raw biological data (JSON lists) as tool inputs, and the server returns absolute paths to publication-quality (300 DPI) PNG figures saved to a local `figures/` directory. The LLM never touches plotting code — it just receives a verified file path, ready for manuscript insertion.

### 1.3 Target Users

- Bioinformaticians and computational biologists generating manuscript figures
- PhD students automating results visualization
- Developers building AI-assisted bioinformatics reporting pipelines

---

## 2. Goals & Non-Goals

### 2.1 Goals (Phase 1)

- Implement `plot_volcano` tool to generate Volcano plots from differential expression data
- Implement `plot_bar_enrichment` tool to generate horizontal bar charts from pathway enrichment data
- Ensure all output figures meet Q1 journal standards (300 DPI, `bbox_inches='tight'`)
- Create `figures/` output directory automatically at server startup
- Handle empty or malformed data gracefully
- Include `next_tool_hint` in every successful response

### 2.2 Non-Goals (Phase 1)

- Interactive/HTML figures (plotly, bokeh) — deferred to Phase 2
- Heatmap generation — deferred to Phase 2
- PCA plots, GO term bubble charts — deferred to Phase 2
- Figure captioning or legend generation via LLM — deferred to Phase 2
- Direct figure embedding into .docx or PDF files — deferred to Phase 3

---

## 3. Tech Stack

| Component | Choice | Rationale |
|---|---|---|
| MCP Framework | `mcp` (FastMCP) | Standard, minimal boilerplate |
| Language | Python 3.10+ | Rich scientific Python ecosystem |
| Data Handling | `pandas` | DataFrame manipulation for plot inputs |
| Plotting | `matplotlib` + `seaborn` | Industry standard for publication figures |
| Output Format | PNG @ 300 DPI | Universal journal submission format |

---

## 4. Architecture

```
LLM Host (Claude Desktop)
        │
        │  MCP Protocol (stdio)
        ▼
┌──────────────────────────────┐
│         BioVis-MCP           │
│  ┌──────────────────────┐    │
│  │    plot_volcano       │    │──► figures/volcano_[ts].png
│  ├──────────────────────┤    │
│  │  plot_bar_enrichment  │    │──► figures/enrichment_[ts].png
│  └──────────────────────┘    │
│                              │
│  [figures/ dir auto-created] │
└──────────────────────────────┘
```

All rendering happens locally. No external API calls. The server is stateless between calls; figures are persisted on disk only.

---

## 5. Startup Behavior

On server start, `BioVis-MCP` must:

```python
import os
os.makedirs("figures", exist_ok=True)
```

The `figures/` directory is created relative to the working directory from which the server is launched. This must happen before any tool is registered or called.

---

## 6. Tool Specifications

### 6.1 `plot_volcano`

**Purpose:** Generate a Volcano plot from differential gene expression results.

**Input Parameters:**

| Parameter | Type | Required | Description |
|---|---|---|---|
| `data` | `list[dict]` | ✅ | List of gene records |
| `title` | `str` | ❌ | Optional plot title (default: `"Volcano Plot"`) |
| `fc_threshold` | `float` | ❌ | log2 fold-change threshold (default: `1.0`) |
| `pval_threshold` | `float` | ❌ | p-value significance threshold (default: `0.05`) |

**Input Record Schema:**

```json
{
  "gene_id": "AT2G21220",
  "log2_fold_change": 2.34,
  "p_value": 0.0012
}
```

**Logic:**
1. Validate input list is non-empty; validate required keys exist in each record
2. Convert to pandas DataFrame
3. Compute `-log10(p_value)` column
4. Classify each gene:
   - **Up-regulated (red):** `log2FC > fc_threshold` AND `p_value < pval_threshold`
   - **Down-regulated (blue):** `log2FC < -fc_threshold` AND `p_value < pval_threshold`
   - **Non-significant (gray):** all others
5. Plot using `matplotlib` scatter:
   - x-axis: `log2_fold_change`
   - y-axis: `-log10(p_value)`
   - Draw dashed threshold lines (horizontal at `-log10(pval_threshold)`, vertical at `±fc_threshold`)
6. Apply publication style: remove top/right spines, use `Arial` or `DejaVu Sans`, font size ≥10
7. Save as `figures/volcano_{timestamp}.png` at 300 DPI with `bbox_inches='tight'`

**Output Schema:**

```json
{
  "status": "success",
  "file_path": "/abs/path/to/figures/volcano_20260406_153012.png",
  "stats": {
    "total_genes": 1200,
    "upregulated": 87,
    "downregulated": 54,
    "non_significant": 1059
  },
  "next_tool_hint": {
    "tool": "plot_bar_enrichment",
    "reason": "Run pathway enrichment on the significant genes and visualize with plot_bar_enrichment."
  }
}
```

**Error Cases:**

| Condition | Behavior |
|---|---|
| Empty `data` list | Return error: `"data list is empty"` |
| Missing required keys in records | Return error with missing key name |
| All p-values are 0 | Return error: `"p_value cannot be 0 (log10 undefined)"` |
| Disk write failure | Return error with OS message |

---

### 6.2 `plot_bar_enrichment`

**Purpose:** Generate a horizontal bar chart visualizing pathway enrichment results (e.g., KEGG, GO).

**Input Parameters:**

| Parameter | Type | Required | Description |
|---|---|---|---|
| `data` | `list[dict]` | ✅ | List of pathway enrichment records |
| `title` | `str` | ❌ | Optional plot title (default: `"Pathway Enrichment"`) |
| `top_n` | `int` | ❌ | Show only top N pathways, sorted by gene_count (default: `20`) |
| `color` | `str` | ❌ | Bar color hex code (default: `"#2196F3"`) |

**Input Record Schema:**

```json
{
  "pathway_name": "Plant hormone signal transduction",
  "gene_count": 23
}
```

**Logic:**
1. Validate input list is non-empty
2. Convert to pandas DataFrame
3. Sort by `gene_count` descending; take top `top_n` rows
4. Generate horizontal bar chart using `matplotlib.pyplot.barh`
5. Add value labels at end of each bar
6. Apply publication style: clean grid (x-axis only), no top/right spines
7. Truncate long pathway names at 50 characters with `…`
8. Save as `figures/enrichment_{timestamp}.png` at 300 DPI with `bbox_inches='tight'`

**Output Schema:**

```json
{
  "status": "success",
  "file_path": "/abs/path/to/figures/enrichment_20260406_153045.png",
  "stats": {
    "total_pathways_input": 85,
    "pathways_shown": 20,
    "max_gene_count": 23
  },
  "next_tool_hint": {
    "tool": "search_literature",
    "reason": "Use BioCite-MCP's search_literature to find papers on the top enriched pathways."
  }
}
```

**Error Cases:**

| Condition | Behavior |
|---|---|
| Empty `data` list | Return error: `"data list is empty"` |
| Missing `pathway_name` or `gene_count` | Return error with missing key name |
| `gene_count` contains non-numeric values | Return error with offending value |
| Disk write failure | Return error with OS message |

---

## 7. Figure Quality Standards

All figures generated by `BioVis-MCP` must comply with the following:

| Setting | Value |
|---|---|
| DPI | 300 |
| `bbox_inches` | `'tight'` |
| Format | PNG |
| Font | DejaVu Sans (matplotlib default) or Arial if available |
| Min font size | 10pt |
| Spine style | Top and right spines removed |
| Figure size | At least 8×6 inches (adjustable per tool) |

---

## 8. Error Handling Strategy

All tools return a consistent error envelope:

```json
{
  "status": "error",
  "message": "Human-readable error description",
  "code": "EMPTY_DATA | MISSING_KEY | INVALID_VALUE | DISK_ERROR",
  "next_tool_hint": null
}
```

No raw Python exceptions propagate to the MCP host.

---

## 9. Project Structure

```
biovis-mcp/
├── server.py              # FastMCP server entry point, figures/ dir creation
├── tools/
│   ├── __init__.py
│   ├── volcano.py         # plot_volcano implementation
│   └── enrichment.py      # plot_bar_enrichment implementation
├── utils/
│   ├── __init__.py
│   └── style.py           # Shared matplotlib style settings
├── figures/               # Auto-created at startup (gitignored)
├── requirements.txt
└── README.md
```

---

## 10. Phase Roadmap

| Phase | Scope |
|---|---|
| **Phase 1 (Current)** | Volcano plot + Pathway enrichment bar chart |
| **Phase 2** | Heatmap, PCA plot, GO bubble chart, MA plot |
| **Phase 3** | Figure captioning via LLM, direct .docx/.pdf insertion |

---

## 11. Success Criteria (Phase 1)

- [ ] `plot_volcano` produces a correctly colored, threshold-annotated PNG at 300 DPI
- [ ] `plot_bar_enrichment` produces a sorted, labeled horizontal bar chart at 300 DPI
- [ ] `figures/` directory is created automatically on server startup
- [ ] Both tools return absolute file paths in their output
- [ ] All error cases return structured error dicts (no raw exceptions)
- [ ] `next_tool_hint` present in 100% of successful responses
- [ ] Server starts cleanly with `fastmcp run server.py`
