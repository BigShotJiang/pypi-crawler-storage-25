"""
WordlistLoader  – 大文件词表加载器，支持 O(1) 随机行访问、断点续传、二进制索引缓存。
PayloadLoader   – 多字段组合包装器，支持 PARALLEL / PRODUCT 策略。
"""

from __future__ import annotations

import array
import hashlib
import json
import struct
from enum import Enum, auto
from pathlib import Path
from typing import IO, Iterator, Optional

import xxhash

_DEFAULT_CACHE_DIR = Path.home() / ".cache" / "wordlist"


# ---------------------------------------------------------------------------
# WordlistLoader
# ---------------------------------------------------------------------------


class WordlistLoader:
    """
    大文件词表加载器。

    特性
    ----
    - O(1) 随机行访问（字节偏移索引）
    - 断点续传（持久化 checkpoint）
    - 高效二进制索引缓存，校验 mtime / size / content_hash / encoding / strip
    - 文件耗尽时自动持久化最终 checkpoint

    注意：非线程安全，多线程场景请在外部加锁。请使用 with 语句确保资源正确释放。
    """

    _CACHE_VERSION = 5
    _MAGIC = b"WLIDX\x00\x00\x05"
    _SAMPLE_SIZE = 65_536

    # ------------------------------------------------------------------
    # 构造
    # ------------------------------------------------------------------

    def __init__(
        self,
        path: str | Path,
        encoding: str = "utf-8",
        strip: bool = True,
        tag: str | None = None,
        continue_: bool = False,
        cache_dir: Path | None = None,
        checkpoint_interval: int = 1000,
        use_empty_password: bool = False,
        rollback: int = 1,
    ) -> None:
        self._use_empty_password = use_empty_password
        self.use_empty_password_done = False
        self.path = Path(path).resolve()
        self.encoding = encoding
        self.errors = "ignore"
        self.strip = strip
        self.continue_ = continue_
        self.checkpoint_interval = checkpoint_interval

        cache_dir = Path(cache_dir) if cache_dir else _DEFAULT_CACHE_DIR
        cache_dir.mkdir(parents=True, exist_ok=True)
        cache_key = tag if tag else hashlib.md5(str(self.path).encode()).hexdigest()[:12]
        self._index_path = cache_dir / f"{cache_key}.index.bin"
        self._checkpoint_path = cache_dir / f"{cache_key}.checkpoint.json"

        self._offsets: array.array = array.array("Q")
        self._line_index: int = 0
        self._dirty: int = 0
        self._fp: IO[bytes] | None = None

        self._load_or_build_cache()
        self._fp = open(self.path, mode="rb")
        self._rollback = max(0, rollback)

        if continue_:
            cp = self._load_checkpoint()
            if cp and self._checkpoint_valid(cp):
                self._restore_checkpoint(cp)

    def close(self) -> None:
        if self._fp is not None and not self._fp.closed:
            self._save_checkpoint()
            self._fp.close()
        self._fp = None

    def __enter__(self) -> "WordlistLoader":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    # ------------------------------------------------------------------
    # 索引缓存
    # ------------------------------------------------------------------

    @classmethod
    def _fast_hash(cls, path: Path) -> str:
        h = xxhash.xxh64()
        s = cls._SAMPLE_SIZE
        file_size = path.stat().st_size
        with open(path, "rb") as f:
            h.update(f.read(s))
            mid = file_size // 2
            if mid > s:
                f.seek(mid)
                h.update(f.read(s))
            tail = file_size - s
            if tail > mid + s:
                f.seek(tail)
                h.update(f.read(s))
        return h.hexdigest()

    @classmethod
    def _write_index(cls, bin_path: Path, offsets: array.array, meta: dict) -> None:
        meta_bytes = json.dumps(meta, separators=(",", ":")).encode()
        with open(bin_path, "wb") as f:
            f.write(cls._MAGIC)
            f.write(struct.pack(">I", len(meta_bytes)))
            f.write(meta_bytes)
            offsets.tofile(f)

    @classmethod
    def _read_index(cls, bin_path: Path) -> tuple[array.array, dict] | None:
        try:
            with open(bin_path, "rb") as f:
                if f.read(8) != cls._MAGIC:
                    return None
                (meta_len,) = struct.unpack(">I", f.read(4))
                meta = json.loads(f.read(meta_len))
                buf: array.array = array.array("Q")
                buf.fromfile(f, meta["line_count"])
            return buf, meta
        except Exception:
            return None

    def _file_meta(self) -> dict:
        stat = self.path.stat()
        return {
            "version": self._CACHE_VERSION,
            "path": str(self.path),
            "mtime": stat.st_mtime,
            "size": stat.st_size,
            "encoding": self.encoding,
            "strip": self.strip,
            "content_hash": self._fast_hash(self.path),
        }

    def _cache_valid(self, cached_meta: dict) -> bool:
        if cached_meta.get("version") != self._CACHE_VERSION:
            return False
        cur = self._file_meta()
        return (
            cached_meta.get("mtime") == cur["mtime"]
            and cached_meta.get("size") == cur["size"]
            and cached_meta.get("content_hash") == cur["content_hash"]
            and cached_meta.get("encoding") == cur["encoding"]
            and cached_meta.get("strip") == cur["strip"]
        )

    def _build_index(self) -> None:
        file_size = self.path.stat().st_size
        if file_size == 0:
            self._offsets = array.array("Q")
            return
        offsets: list[int] = [0]
        pos = 0
        with open(self.path, "rb") as bf:
            while True:
                chunk = bf.read(1 << 20)
                if not chunk:
                    break
                start = 0
                while True:
                    idx = chunk.find(b"\n", start)
                    if idx == -1:
                        break
                    offsets.append(pos + idx + 1)
                    start = idx + 1
                pos += len(chunk)
        if offsets and offsets[-1] == file_size:
            offsets.pop()
        self._offsets = array.array("Q", offsets)

    def _load_or_build_cache(self) -> None:
        result = self._read_index(self._index_path)
        if result is not None:
            offsets, meta = result
            if self._cache_valid(meta):
                self._offsets = offsets
                return
        self._build_index()
        meta = {**self._file_meta(), "line_count": len(self._offsets)}
        try:
            self._write_index(self._index_path, self._offsets, meta)
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Checkpoint
    # ------------------------------------------------------------------

    def _save_checkpoint(self) -> None:
        try:
            payload = {
                "line_index": self._line_index,
                "empty_password_done": self.use_empty_password_done,
            }
            self._checkpoint_path.write_text(json.dumps(payload, separators=(",", ":")))
            self._dirty = 0
        except Exception:
            pass

    def _load_checkpoint(self) -> dict | None:
        try:
            return json.loads(self._checkpoint_path.read_text())
        except Exception:
            return None

    def _checkpoint_valid(self, cp: dict) -> bool:
        try:
            line_index = cp.get("line_index", -1)
            return isinstance(line_index, int) and 0 <= line_index <= len(self._offsets)
        except Exception:
            return False

    def _restore_checkpoint(self, cp: dict) -> None:
        line_index: int = cp["line_index"]
        empty_done: bool = cp.get("empty_password_done", False) and self._use_empty_password
        if self._rollback > 0:
            rolled = min(line_index, self._rollback)
            line_index -= rolled
            if rolled > 0 and line_index == 0:
                empty_done = False
        self._line_index = line_index
        self.use_empty_password_done = empty_done
        assert self._fp is not None
        if line_index < len(self._offsets):
            self._fp.seek(self._offsets[line_index])
        else:
            self._fp.seek(0, 2)

    # ------------------------------------------------------------------
    # 读取接口
    # ------------------------------------------------------------------

    def next_word(self) -> Optional[str]:
        """返回下一个非空词，文件耗尽时返回 None 并持久化最终 checkpoint。"""
        if self._use_empty_password and not self.use_empty_password_done:
            self.use_empty_password_done = True
            return ""

        if self._fp is None or self._fp.closed:
            return None

        while True:
            raw = self._fp.readline()
            if raw == b"":
                self._save_checkpoint()
                return None
            self._line_index += 1
            line = raw.decode(self.encoding, errors=self.errors)
            word = line.strip() if self.strip else line.rstrip("\r\n")
            if not word:
                continue
            self._dirty += 1
            if self._dirty >= self.checkpoint_interval:
                self._save_checkpoint()
            return word

    def next(self) -> Optional[str]:
        return self.next_word()

    def seek_to_line(self, n: int) -> None:
        """
        跳转到第 n 物理行（0-based）并持久化 checkpoint。
        n == line_count 为合法值，语义为"已耗尽/EOF 位置"。
        """
        self._seek_raw(n)
        self._save_checkpoint()

    def _seek_raw(self, n: int) -> None:
        """
        内部跳转，不持久化 checkpoint。
        供 PayloadLoader 进位/恢复路径调用，避免污染各 loader 独立的 checkpoint
        文件，同时减少不必要的磁盘写入。
        """
        if not self._offsets and n != 0:
            raise RuntimeError("Index not built yet.")
        total = len(self._offsets)
        if not (0 <= n <= total):
            raise IndexError(
                f"Line {n} out of range [0, {total}]. "
                f"File has {total} lines (pass n={total} to seek to EOF)."
            )
        if self._fp is None or self._fp.closed:
            raise RuntimeError("File is not open.")
        if n < total:
            self._fp.seek(self._offsets[n])
        else:
            self._fp.seek(0, 2)
        self._line_index = n
        self._dirty = 0

    def _reset_empty_password(self) -> None:
        """将空密码标志重置为未消耗状态。由 reset() 及 PayloadLoader 进位路径调用。"""
        self.use_empty_password_done = False

    def reset(self) -> None:
        """重置到文件起点并清除 checkpoint。"""
        self._seek_raw(0)
        self._reset_empty_password()
        try:
            self._checkpoint_path.unlink(missing_ok=True)
        except Exception:
            pass

    # ------------------------------------------------------------------
    # 属性
    # ------------------------------------------------------------------

    @property
    def line_count(self) -> int:
        """文件物理行数（含空行）。"""
        return len(self._offsets)

    @property
    def current_line(self) -> int:
        """下一次 readline() 将读取的物理行号（0-based）。"""
        return self._line_index

    @property
    def remaining_count(self) -> int:
        """
        剩余物理行数的上界估算（含空行 + 未消耗的空密码）。
        实际返回的非空词数可能更少（文件含空行时）。
        """
        remaining = max(0, self.line_count - self._line_index)
        if self._use_empty_password and not self.use_empty_password_done:
            remaining += 1
        return remaining

    # ------------------------------------------------------------------
    # 迭代器协议
    # ------------------------------------------------------------------

    def __iter__(self) -> Iterator[str]:
        while (word := self.next_word()) is not None:
            yield word

    def __next__(self) -> str:
        word = self.next_word()
        if word is None:
            raise StopIteration
        return word

    def __repr__(self) -> str:
        status = (
            "closed"
            if (self._fp is None or self._fp.closed)
            else f"line {self._line_index}/{self.line_count}"
        )
        return (
            f"<WordlistLoader path={self.path.name!r} "
            f"lines={self.line_count} {status}>"
        )


# ---------------------------------------------------------------------------
# PayloadLoader
# ---------------------------------------------------------------------------


class CombineStrategy(Enum):
    PARALLEL = auto()   # zip：所有字段同步前进，最短词表耗尽即停
    PRODUCT = auto()    # itertools.product：全排列


class _ProductCheckpoint:
    """
    PRODUCT 模式下的组合状态 checkpoint。

    保存：
    - indices : 所有层的 current_line，用于 _seek_raw 恢复文件指针
    - slots   : 外层槽位词（长度 = n-1），续传时直接填充，不消耗 loader

    格式：{"indices": [int, ...], "slots": [str, ...]}
    """

    __slots__ = ("path",)

    def __init__(self, path: Path) -> None:
        self.path = path

    def save(self, line_indices: list[int], outer_slots: list[str]) -> None:
        try:
            self.path.write_text(
                json.dumps({"indices": line_indices, "slots": outer_slots},
                           separators=(",", ":"))
            )
        except Exception:
            pass

    def load(self) -> tuple[list[int], list[str]] | None:
        try:
            data = json.loads(self.path.read_text())
            indices = data.get("indices")
            slots = data.get("slots")
            if (
                isinstance(indices, list)
                and isinstance(slots, list)
                and all(isinstance(i, int) for i in indices)
                and all(isinstance(s, str) for s in slots)
            ):
                return indices, slots
        except Exception:
            pass
        return None

    def delete(self) -> None:
        try:
            self.path.unlink(missing_ok=True)
        except Exception:
            pass


class PayloadLoader:
    """
    WordlistLoader 的多字段组合包装器。

    策略
    ----
    PARALLEL : zip 语义，所有字段同步推进，最短词表耗尽即停。
               支持断点续传（各 loader 独立 checkpoint）。
    PRODUCT  : 全排列，第 0 个字段最慢（外层），最后字段最快（内层）。
               使用独立的组合状态 checkpoint，保存行号和外层槽位词，
               续传时直接恢复槽位，不额外消耗外层 loader。

    注意：非线程安全，多线程场景请在外部加锁。

    用法示例
    --------
    loader = PayloadLoader(
        [("user", "users.txt"), ("pass", "passwords.txt")],
        strategy=CombineStrategy.PRODUCT,
        continue_=True,
        tag="my_task",
    )
    with loader:
        while (payload := loader.next()) is not None:
            print(payload)  # {"user": "admin", "pass": "123456"}
    """

    def __init__(
        self,
        fields: list[tuple[str, str | Path]],
        strategy: CombineStrategy = CombineStrategy.PRODUCT,
        *,
        encoding: str = "utf-8",
        strip: bool = True,
        tag: str | None = None,
        continue_: bool = False,
        cache_dir: Path | None = None,
        checkpoint_interval: int = 1000,
        use_empty_password: bool = False,
        rollback: int = 1,
    ) -> None:
        if not fields:
            raise ValueError("fields 不能为空")

        self._names: list[str] = [name for name, _ in fields]
        self._strategy = strategy
        self._continue = continue_

        cache_dir = Path(cache_dir) if cache_dir else _DEFAULT_CACHE_DIR
        cache_dir.mkdir(parents=True, exist_ok=True)

        self._loaders: list[WordlistLoader] = []
        for i, (name, path) in enumerate(fields):
            path_hash = hashlib.md5(str(Path(path).resolve()).encode()).hexdigest()[:8]
            field_tag = f"{tag}_{i}_{name}_{path_hash}" if tag else None
            self._loaders.append(
                WordlistLoader(
                    path,
                    encoding=encoding,
                    strip=strip,
                    tag=field_tag,
                    continue_=continue_ and strategy == CombineStrategy.PARALLEL,
                    cache_dir=cache_dir,
                    checkpoint_interval=checkpoint_interval,
                    rollback=rollback,
                    use_empty_password=use_empty_password,
                )
            )

        product_tag = tag or hashlib.md5(
            "".join(str(Path(p).resolve()) for _, p in fields).encode()
        ).hexdigest()[:12]
        self._product_cp = _ProductCheckpoint(
            cache_dir / f"{product_tag}.product_cp.json"
        )

        # 惰性迭代器，首次 next() 时构建
        self._iter: Iterator[tuple[str, ...]] | None = None

        # PRODUCT + continue_：None 表示无有效 checkpoint，_product_iter 将全新开始
        self._restored_outer_slots: list[str] | None = None
        if continue_ and strategy == CombineStrategy.PRODUCT:
            self._restored_outer_slots = self._restore_product_checkpoint()

    # ------------------------------------------------------------------
    # 上下文管理
    # ------------------------------------------------------------------

    def __enter__(self) -> "PayloadLoader":
        return self

    def __exit__(self, *_) -> None:
        self.close()

    def close(self) -> None:
        for loader in self._loaders:
            loader.close()

    # ------------------------------------------------------------------
    # PRODUCT checkpoint
    # ------------------------------------------------------------------

    def _restore_product_checkpoint(self) -> list[str] | None:
        """
        恢复 PRODUCT checkpoint。
        成功时各 loader _seek_raw 至对应行并返回外层槽位词；失败返回 None。
        使用 _seek_raw 避免污染各 loader 独立的 checkpoint 文件。
        """
        result = self._product_cp.load()
        if result is None:
            return None
        indices, outer_slots = result
        n = len(self._loaders)
        if len(indices) != n or len(outer_slots) != n - 1:
            return None
        for loader, idx in zip(self._loaders, indices):
            if not (0 <= idx <= loader.line_count):
                return None
            try:
                loader._seek_raw(idx)
            except Exception:
                return None
        return outer_slots

    def _save_product_checkpoint(self, slots: list[str | None]) -> None:
        """
        持久化当前组合状态。
        外层槽位（slots[:-1]）必须全部非 None 才保存，防止保存半初始化状态。
        """
        outer_slots = slots[: len(self._loaders) - 1]
        if any(s is None for s in outer_slots):
            return
        indices = [loader.current_line for loader in self._loaders]
        self._product_cp.save(indices, outer_slots)  # type: ignore[arg-type]

    # ------------------------------------------------------------------
    # 迭代器构建（惰性）
    # ------------------------------------------------------------------

    def _build_iter(self) -> Iterator[tuple[str, ...]]:
        match self._strategy:
            case CombineStrategy.PARALLEL:
                return self._parallel_iter()
            case CombineStrategy.PRODUCT:
                return self._product_iter(self._restored_outer_slots)
            case _:
                raise ValueError(f"未知策略: {self._strategy}")

    def _parallel_iter(self) -> Iterator[tuple[str, ...]]:
        """所有 loader 同步推进，任一耗尽即停（zip 语义）。"""
        while True:
            words: list[str] = []
            for loader in self._loaders:
                word = loader.next_word()
                if word is None:
                    return
                words.append(word)
            yield tuple(words)

    # ------------------------------------------------------------------
    # PRODUCT 迭代器（三个职责清晰的辅助方法 + 主循环）
    # ------------------------------------------------------------------

    def _reset_layer(self, level: int) -> None:
        """将指定层重置到起点（不持久化 checkpoint）。"""
        loader = self._loaders[level]
        loader._seek_raw(0)
        loader._reset_empty_password()

    def _carry_with_word(self, from_level: int) -> tuple[int, str] | None:
        """
        从 from_level 层开始向外层进位。

        逐层向外尝试：先重置当前层，再对外一层取下一个词。
        - 外层取到词 → 返回 (成功进位的层号, 该层新词)
        - 所有外层全部耗尽 → 返回 None

        调用时 from_level 已耗尽，本方法负责重置它。
        """
        for level in range(from_level, -1, -1):
            self._reset_layer(level)
            outer = level - 1
            if outer < 0:
                return None  # 最外层也耗尽，全部结束
            word = self._loaders[outer].next_word()
            if word is not None:
                return outer, word
            # outer 层也耗尽，继续向外
        return None  # unreachable，满足类型检查

    def _reset_middle_layers(
        self, carry_level: int, slots: list[str | None]
    ) -> bool:
        """
        carry_level 成功进位后，将 carry_level+1 到 n-2 层重置并取首词填入 slots。
        任意层取词失败（词表为空）返回 False。
        """
        for i in range(carry_level + 1, len(self._loaders) - 1):
            self._reset_layer(i)
            word = self._loaders[i].next_word()
            if word is None:
                return False
            slots[i] = word
        return True

    def _product_iter(
        self,
        restored_outer_slots: list[str] | None = None,
    ) -> Iterator[tuple[str, ...]]:
        """
        全排列迭代器。第 0 个字段最慢（最外层），最后字段最快（最内层）。

        restored_outer_slots:
            非 None → 从 checkpoint 恢复，直接填充外层槽位，不消耗 loader。
            None    → 全新开始，消耗外层第一个词。
        """
        n = len(self._loaders)
        if n == 0:
            return

        slots: list[str | None] = [None] * n

        # 初始化外层槽位
        if restored_outer_slots is not None:
            for i, word in enumerate(restored_outer_slots):
                slots[i] = word
        else:
            for i in range(n - 1):
                word = self._loaders[i].next_word()
                if word is None:
                    return
                slots[i] = word

        # 主循环：内层推进 → 耗尽时进位 → 重置中间层
        while True:
            word = self._loaders[-1].next_word()
            if word is not None:
                slots[-1] = word
                self._save_product_checkpoint(slots)
                yield tuple(slots)  # type: ignore[arg-type]
                continue

            # 内层耗尽 → 进位
            carry_result = self._carry_with_word(n - 1)
            if carry_result is None:
                return  # 全部耗尽

            carry_level, new_word = carry_result
            slots[carry_level] = new_word

            # 重置 carry_level+1 到 n-2 层
            if not self._reset_middle_layers(carry_level, slots):
                return  # 某中间层词表为空

            # 进位完成后立即保存，防止进位点中断导致状态回滚
            self._save_product_checkpoint(slots)

    # ------------------------------------------------------------------
    # 核心接口
    # ------------------------------------------------------------------

    def next(self) -> Optional[dict[str, str]]:
        """返回下一个组合 payload，耗尽返回 None。"""
        if self._iter is None:
            self._iter = self._build_iter()
        try:
            assert self._iter is not None
            values = next(self._iter)
            return dict(zip(self._names, values))
        except StopIteration:
            return None

    # ------------------------------------------------------------------
    # 迭代器协议
    # ------------------------------------------------------------------

    def __iter__(self) -> Iterator[dict[str, str]]:
        while (payload := self.next()) is not None:
            yield payload

    def __next__(self) -> dict[str, str]:
        payload = self.next()
        if payload is None:
            raise StopIteration
        return payload

    # ------------------------------------------------------------------
    # 状态查询
    # ------------------------------------------------------------------

    @property
    def strategy(self) -> CombineStrategy:
        return self._strategy

    @property
    def remaining_count(self) -> int:
        """
        剩余组合数上界估算（从当前位置到耗尽）。

        PARALLEL : min(loader.remaining_count for loader in loaders)
        PRODUCT  : ∏ loader.remaining_count

        注意：文件含空行时实际输出的非空组合数可能更少（上界估算）。
        """
        counts = [loader.remaining_count for loader in self._loaders]
        match self._strategy:
            case CombineStrategy.PARALLEL:
                return min(counts)
            case CombineStrategy.PRODUCT:
                result = 1
                for c in counts:
                    result *= c
                return result
            case _:
                raise ValueError(f"未知策略: {self._strategy}")

    def __repr__(self) -> str:
        fields = ", ".join(
            f"{name}={loader!r}"
            for name, loader in zip(self._names, self._loaders)
        )
        return f"<PayloadLoader strategy={self._strategy.name} fields=[{fields}]>"