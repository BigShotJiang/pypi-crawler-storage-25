# DeadDrop

Secure secret sharing with Google identity. Store secrets, share them by email, revoke access anytime. Everything encrypted with AWS KMS. No passwords, no API keys — just Google sign-in.

## Quick Start

```bash
drop setup          # enter https://api.deaddrop.one
drop login          # sign in with Google
```

## Store & Retrieve

```bash
$ drop put openai-key "sk-proj-abc123..."
Stored "openai-key"

$ drop get openai-key
sk-proj-abc123...

$ drop ls
  openai-key
  db-password
  stripe-secret
```

## Share & Revoke

Share a secret with someone by their Google email. They authenticate with Google too — no tokens or passwords to manage.

```bash
$ drop share openai-key alice@company.com
Shared "openai-key" with alice@company.com

$ drop who openai-key
  alice@company.com
  bob@company.com
```

Alice retrieves it with your email as the prefix:

```bash
$ drop get david@company.com/openai-key
sk-proj-abc123...
```

You rotate the key? Just update it — Alice always gets the latest value. Alice leaves the team?

```bash
$ drop revoke openai-key alice@company.com
Revoked access for alice@company.com
```

Done. Instant. No key rotation needed.

## Why Not Just Slack the Key?

- **No revocation** — once sent, you can't unsend it
- **No audit trail** — who accessed what, when?
- **Stale values** — rotate a key and now you're chasing everyone to update
- **Copy-paste chains** — secrets end up in logs, screenshots, chat history

DeadDrop gives you **indirection**. You share *access*, not the secret itself. The actual value is encrypted at rest with KMS and only decrypted on authorized retrieval.

## Environment Variables

Inject secrets directly into your shell:

```bash
eval $(drop env openai-key)
# → export OPENAI_KEY="sk-proj-abc123..."

# Custom variable name
eval $(drop env openai-key OPENAI_API_KEY)

# Shared secrets work too
eval $(drop env alice@company.com/db-password DB_PASS)
```

Add to `.bashrc` / `.zshrc` so they're always loaded:

```bash
eval $(drop env openai-key OPENAI_API_KEY)
eval $(drop env db-host DB_HOST)
```

## MCP Server (AI Agent Integration)

DeadDrop includes an MCP server so AI agents (Windsurf Cascade, Claude Desktop, etc.) can manage secrets directly as tools.

```bash
drop mcp-install    # auto-configures Windsurf + Claude Desktop
# restart your editor
```

Then just talk to your agent:

> "Store my OpenAI key as openai-prod"
>
> "Share the database password with ops@company.com"
>
> "What secrets do I have?"
>
> "Get the Stripe key that alice@company.com shared with me"

The agent calls the right tool automatically. No copy-paste needed.

### Manual MCP Config

Add to `~/.codeium/windsurf/mcp_config.json`:

```json
{
  "mcpServers": {
    "deaddrop": {
      "command": "python3",
      "args": ["/path/to/deaddrop-mcp.py"]
    }
  }
}
```

## CLI Reference

| Command | Description |
|---------|-------------|
| `drop setup` | Configure CLI endpoint |
| `drop login` | Sign in with Google |
| `drop whoami` | Show current identity |
| `drop put <name> <value>` | Store a secret |
| `drop get <name>` | Get your own secret |
| `drop get <owner>/<name>` | Get a shared secret |
| `drop rm <name>` | Delete a secret |
| `drop ls` | List your secrets |
| `drop share <name> <email>` | Share with someone |
| `drop revoke <name> <email>` | Revoke access |
| `drop who <name>` | See who has access |
| `drop shared` | List secrets shared with you |
| `drop env <name> [VAR]` | Print export statement |
| `drop mcp-install` | Install MCP server for AI agents |

## Security

- **Auth**: Google OAuth 2.0 — ID tokens verified server-side
- **Encryption**: AWS KMS envelope encryption — no plaintext at rest
- **Transport**: HTTPS only
- **Access**: Owner-based — only you and the emails you explicitly share with
- **Audit**: Every retrieval logged with identity and timestamp
