"""DeadDrop CLI — secure secret sharing with Google identity."""
__version__ = '1.0.0'
