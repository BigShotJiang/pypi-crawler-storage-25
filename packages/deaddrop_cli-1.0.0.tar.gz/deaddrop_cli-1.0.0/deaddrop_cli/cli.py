#!/usr/bin/env python3
"""DeadDrop CLI — secure secret sharing with Google identity."""
import sys
import os
import json
import base64
import secrets as secrets_mod
import time
import webbrowser
import platform
from urllib.request import urlopen, Request
from urllib.parse import urlencode
from urllib.error import HTTPError

CONFIG_DIR = os.path.join(os.path.expanduser('~'), '.deaddrop')
CONFIG_FILE = os.path.join(CONFIG_DIR, 'config.json')
TOKEN_FILE = os.path.join(CONFIG_DIR, 'tokens.json')


def _secure_write(path, content):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w') as f:
        if isinstance(content, str):
            f.write(content)
        else:
            json.dump(content, f, indent=2)
    try:
        os.chmod(path, 0o600)
    except (OSError, NotImplementedError):
        pass


# ------------------------------------------------------------------ config

def load_config():
    if not os.path.exists(CONFIG_FILE):
        print('Not configured. Run: drop setup')
        sys.exit(1)
    with open(CONFIG_FILE) as f:
        return json.load(f)


def save_config(cfg):
    _secure_write(CONFIG_FILE, cfg)


# ------------------------------------------------------------------ oauth

def get_id_token():
    cfg = load_config()

    if os.path.exists(TOKEN_FILE):
        with open(TOKEN_FILE) as f:
            tokens = json.load(f)

        id_token = tokens.get('id_token', '')
        if id_token and not _expired(id_token):
            return id_token

        rt = tokens.get('refresh_token')
        if rt:
            new = _refresh(cfg, rt)
            if new:
                tokens.update(new)
                _save_tokens(tokens)
                return new['id_token']

    return _login(cfg)


def _expired(id_token):
    try:
        payload = id_token.split('.')[1]
        payload += '=' * (4 - len(payload) % 4)
        data = json.loads(base64.urlsafe_b64decode(payload))
        return data.get('exp', 0) < time.time() + 60
    except Exception:
        return True


def _login(cfg):
    base_url = cfg['url'].rstrip('/')
    session_id = secrets_mod.token_urlsafe(32)

    url = f'{base_url}/auth/start?session={session_id}'
    print('Opening browser for Google sign-in...')
    webbrowser.open(url)

    print('Waiting for authentication...', end='', flush=True)
    for _ in range(60):
        time.sleep(2)
        print('.', end='', flush=True)
        try:
            req = Request(f'{base_url}/auth/poll?session={session_id}')
            result = json.loads(urlopen(req, timeout=5).read())
            if result.get('status') == 'complete':
                print()
                tokens = {
                    'id_token': result['id_token'],
                    'refresh_token': result.get('refresh_token', ''),
                }
                _save_tokens(tokens)
                email = _email(tokens['id_token'])
                print(f'Signed in as {email}')
                return tokens['id_token']
        except Exception:
            pass

    print('\nTimeout waiting for authentication.', file=sys.stderr)
    sys.exit(1)


def _refresh(cfg, refresh_token):
    try:
        data = urlencode({
            'refresh_token': refresh_token,
            'client_id': cfg.get('client_id', ''),
            'client_secret': cfg.get('client_secret', ''),
            'grant_type': 'refresh_token',
        }).encode()
        return json.loads(urlopen(Request('https://oauth2.googleapis.com/token', data=data)).read())
    except Exception:
        return None


def _save_tokens(tokens):
    _secure_write(TOKEN_FILE, tokens)


def _email(id_token):
    try:
        payload = id_token.split('.')[1]
        payload += '=' * (4 - len(payload) % 4)
        return json.loads(base64.urlsafe_b64decode(payload)).get('email', '?')
    except Exception:
        return '?'


# ------------------------------------------------------------------ api

def api(method, path, body=None):
    cfg = load_config()
    token = get_id_token()
    url = cfg['url'].rstrip('/') + '/' + path.lstrip('/')

    data = json.dumps(body).encode() if body else None
    req = Request(url, data=data, method=method)
    req.add_header('Authorization', f'Bearer {token}')
    req.add_header('Content-Type', 'application/json')

    try:
        return json.loads(urlopen(req).read())
    except HTTPError as e:
        try:
            err = json.loads(e.read())
            print(f"Error: {err.get('error', e)}", file=sys.stderr)
        except Exception:
            print(f'Error: HTTP {e.code}', file=sys.stderr)
        sys.exit(1)


# ------------------------------------------------------------------ cmds

def cmd_setup():
    print('DeadDrop Setup')
    print('-' * 40)
    url = input('DeadDrop URL (e.g. https://api.deaddrop.one): ').strip()
    save_config({'url': url})
    print(f'\nSaved to {CONFIG_FILE}')
    print('Now run: drop login')


def cmd_login():
    load_config()
    _login(load_config())


def cmd_whoami():
    if os.path.exists(TOKEN_FILE):
        with open(TOKEN_FILE) as f:
            t = json.load(f)
        e = _email(t.get('id_token', ''))
        exp = _expired(t.get('id_token', ''))
        print(f'{e}' + (' (expired — run: drop login)' if exp else ''))
    else:
        print('Not signed in. Run: drop login')


def cmd_put(name, value):
    api('POST', '/secrets', {'name': name, 'value': value})
    print(f"Stored \"{name}\"")


def cmd_get(ref):
    if '/' in ref:
        owner, name = ref.split('/', 1)
        r = api('GET', f'/shared/{owner}/{name}')
    else:
        r = api('GET', f'/secrets/{ref}')
    print(r['value'])


def cmd_rm(name):
    api('DELETE', f'/secrets/{name}')
    print(f'Deleted "{name}"')


def cmd_ls():
    r = api('GET', '/secrets')
    for s in r.get('secrets', []):
        print(f"  {s['name']}")


def cmd_share(name, email):
    r = api('POST', f'/secrets/{name}/share', {'email': email})
    print(f"Shared \"{name}\" with {email}")
    if r.get('email_sent'):
        print(f"  Email sent to {email} with instructions")
    elif r.get('gmail_upgrade_needed'):
        ans = input('  Send email notification? Requires one-time Gmail permission. [y/N] ').strip().lower()
        if ans == 'y':
            _gmail_upgrade()
            nr = api('POST', f'/secrets/{name}/notify', {'email': email})
            if nr.get('email_sent'):
                print(f"  Email sent to {email} with instructions")
            else:
                print(f"  Email failed. Tell them: drop get {r.get('hint', '')}")
        else:
            print(f"  Tell them: drop get {r.get('hint', '')}")
    else:
        print(f"  Tell them: drop get {r.get('hint', '')}")


def _gmail_upgrade():
    cfg = load_config()
    base_url = cfg['url'].rstrip('/')
    session_id = secrets_mod.token_urlsafe(32)

    url = f'{base_url}/auth/upgrade?session={session_id}'
    print('  Opening browser for Gmail permission...')
    webbrowser.open(url)

    print('  Waiting...', end='', flush=True)
    for _ in range(60):
        time.sleep(2)
        print('.', end='', flush=True)
        try:
            req = Request(f'{base_url}/auth/poll?session={session_id}')
            result = json.loads(urlopen(req, timeout=5).read())
            if result.get('status') == 'complete':
                print()
                tokens = {
                    'id_token': result['id_token'],
                    'refresh_token': result.get('refresh_token', ''),
                }
                _save_tokens(tokens)
                return
        except Exception:
            pass

    print('\n  Timeout.', file=sys.stderr)


def cmd_revoke(name, email):
    api('POST', f'/secrets/{name}/unshare', {'email': email})
    print(f'Revoked access for {email}')


def cmd_who(name):
    r = api('GET', f'/secrets/{name}/who')
    for e in r.get('shared_with', []):
        print(f'  {e}')
    if not r.get('shared_with'):
        print('  (not shared)')


def cmd_shared():
    r = api('GET', '/shared')
    for s in r.get('shared', []):
        print(f"  {s['owner']}/{s['name']}")
    if not r.get('shared'):
        print('  (none)')


def cmd_env(ref, var_name=None):
    if '/' in ref:
        owner, name = ref.split('/', 1)
        r = api('GET', f'/shared/{owner}/{name}')
    else:
        name = ref
        r = api('GET', f'/secrets/{ref}')
    if not var_name:
        var_name = name.upper().replace('-', '_')
    print(f'export {var_name}="{r["value"]}"')


def _mcp_config_paths():
    """Return list of (label, path) for MCP config files, cross-platform."""
    system = platform.system()
    paths = []

    # Windsurf
    if system == 'Windows':
        appdata = os.environ.get('APPDATA', '')
        if appdata:
            paths.append(('Windsurf', os.path.join(appdata, 'Windsurf', 'mcp_config.json')))
    else:
        paths.append(('Windsurf', os.path.join(os.path.expanduser('~'), '.codeium', 'windsurf', 'mcp_config.json')))

    # Claude Desktop
    if system == 'Darwin':
        paths.append(('Claude Desktop', os.path.join(os.path.expanduser('~'), 'Library', 'Application Support', 'Claude', 'claude_desktop_config.json')))
    elif system == 'Windows':
        appdata = os.environ.get('APPDATA', '')
        if appdata:
            paths.append(('Claude Desktop', os.path.join(appdata, 'Claude', 'claude_desktop_config.json')))
    else:
        paths.append(('Claude Desktop', os.path.join(os.path.expanduser('~'), '.config', 'Claude', 'claude_desktop_config.json')))

    return paths


def cmd_mcp_install():
    mcp_script = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'mcp_server.py')
    if not os.path.exists(mcp_script):
        print(f'Error: {mcp_script} not found', file=sys.stderr)
        sys.exit(1)

    python = sys.executable or 'python3'
    entry = {'command': python, 'args': [mcp_script]}
    installed = []

    for label, path in _mcp_config_paths():
        installed += _inject_mcp(path, entry, label)

    if not installed:
        print('No MCP configs found. Manual config:')
        print(json.dumps({'mcpServers': {'deaddrop': entry}}, indent=2))
    else:
        print(f"\nInstalled to: {', '.join(installed)}")
        print('Restart your editor to pick up the new MCP server.')


def _inject_mcp(path, entry, label):
    try:
        if os.path.exists(path):
            with open(path) as f:
                cfg = json.load(f)
        else:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            cfg = {}

        if 'mcpServers' not in cfg:
            cfg['mcpServers'] = {}
        cfg['mcpServers']['deaddrop'] = entry

        with open(path, 'w') as f:
            json.dump(cfg, f, indent=2)
        print(f'  {label}: {path}')
        return [label]
    except Exception as e:
        print(f'  {label}: skipped ({e})')
        return []


# ------------------------------------------------------------------ main

USAGE = """  DeadDrop — secure secret sharing

  drop setup                        Configure CLI
  drop login                        Sign in with Google
  drop whoami                       Show current identity

  drop put <name> <value>           Store a secret
  drop get <name>                   Get your own secret
  drop get <owner>/<name>           Get a shared secret
  drop rm <name>                    Delete a secret
  drop ls                           List your secrets

  drop share <name> <email>         Share with someone
  drop revoke <name> <email>        Revoke access
  drop who <name>                   Who has access

  drop shared                       Secrets shared with you
  drop env <name> [VAR]             Print export statement
  drop mcp-install                  Install MCP server for Windsurf/Claude
"""


def main():
    a = sys.argv[1:]
    if not a:
        print(USAGE); sys.exit(1)
    c = a[0]

    if   c == 'setup':   cmd_setup()
    elif c == 'login':   cmd_login()
    elif c == 'whoami':  cmd_whoami()
    elif c == 'put':     len(a) >= 3 or (print('Usage: drop put <name> <value>'), sys.exit(1)); cmd_put(a[1], a[2])
    elif c == 'get':     len(a) >= 2 or (print('Usage: drop get <name>'), sys.exit(1)); cmd_get(a[1])
    elif c == 'rm':      len(a) >= 2 or (print('Usage: drop rm <name>'), sys.exit(1)); cmd_rm(a[1])
    elif c == 'ls':      cmd_ls()
    elif c == 'share':   len(a) >= 3 or (print('Usage: drop share <name> <email>'), sys.exit(1)); cmd_share(a[1], a[2])
    elif c == 'revoke':  len(a) >= 3 or (print('Usage: drop revoke <name> <email>'), sys.exit(1)); cmd_revoke(a[1], a[2])
    elif c == 'who':     len(a) >= 2 or (print('Usage: drop who <name>'), sys.exit(1)); cmd_who(a[1])
    elif c == 'shared':  cmd_shared()
    elif c == 'env':         len(a) >= 2 or (print('Usage: drop env <name> [VAR]'), sys.exit(1)); cmd_env(a[1], a[2] if len(a) > 2 else None)
    elif c == 'mcp-install': cmd_mcp_install()
    else:                    print(USAGE); sys.exit(1)


if __name__ == '__main__':
    main()
