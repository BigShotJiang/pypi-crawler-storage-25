#!/usr/bin/env python3
"""DeadDrop MCP Server — stdio transport, zero external dependencies."""
import sys
import os
import json
import base64
import time
from urllib.request import urlopen, Request
from urllib.parse import urlencode
from urllib.error import HTTPError

CONFIG_DIR = os.path.join(os.path.expanduser('~'), '.deaddrop')
CONFIG_FILE = os.path.join(CONFIG_DIR, 'config.json')
TOKEN_FILE = os.path.join(CONFIG_DIR, 'tokens.json')

TOOLS = [
    {
        "name": "deaddrop_put",
        "description": "Store a secret in DeadDrop. The secret is encrypted at rest with KMS. You become the owner and can later share it with others by email.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Name/key for the secret (e.g. 'openai-api-key', 'db-password')"},
                "value": {"type": "string", "description": "The secret value to store"},
            },
            "required": ["name", "value"],
        },
    },
    {
        "name": "deaddrop_get",
        "description": "Retrieve a secret value. Use just the name for your own secrets, or 'owner@email.com/name' to get a secret someone shared with you.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Secret name (e.g. 'my-key') or owner/name for shared secrets (e.g. 'alice@company.com/api-key')"},
            },
            "required": ["name"],
        },
    },
    {
        "name": "deaddrop_list",
        "description": "List all secrets you own in DeadDrop.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "deaddrop_shared",
        "description": "List all secrets that other people have shared with you.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "deaddrop_share",
        "description": "Share one of your secrets with another user by their Google email. They can then retrieve it with 'deaddrop_get' using your-email/secret-name.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Name of your secret to share"},
                "email": {"type": "string", "description": "Google email of the recipient"},
            },
            "required": ["name", "email"],
        },
    },
    {
        "name": "deaddrop_revoke",
        "description": "Revoke a user's access to one of your secrets. They will no longer be able to retrieve it.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Name of your secret"},
                "email": {"type": "string", "description": "Google email of the user to revoke"},
            },
            "required": ["name", "email"],
        },
    },
    {
        "name": "deaddrop_who",
        "description": "Show who has access to one of your secrets (list of emails you've shared it with).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Name of your secret"},
            },
            "required": ["name"],
        },
    },
    {
        "name": "deaddrop_delete",
        "description": "Permanently delete one of your secrets and revoke all shares.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Name of your secret to delete"},
            },
            "required": ["name"],
        },
    },
    {
        "name": "deaddrop_env",
        "description": "Get a secret formatted as a shell export statement, e.g. 'export MY_KEY=\"value\"'. Useful for setting environment variables.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Secret name or owner/name for shared secrets"},
                "var_name": {"type": "string", "description": "Optional env var name. Defaults to uppercased secret name with hyphens replaced by underscores."},
            },
            "required": ["name"],
        },
    },
]


# ------------------------------------------------------------------ config/auth

def load_config():
    if not os.path.exists(CONFIG_FILE):
        return None
    with open(CONFIG_FILE) as f:
        return json.load(f)


def get_id_token():
    cfg = load_config()
    if not cfg:
        return None, "Not configured. Run: drop setup && drop login"

    if not os.path.exists(TOKEN_FILE):
        return None, "Not signed in. Run: drop login"

    with open(TOKEN_FILE) as f:
        tokens = json.load(f)

    id_token = tokens.get('id_token', '')
    if id_token and not _expired(id_token):
        return id_token, None

    rt = tokens.get('refresh_token')
    if rt:
        new = _refresh(cfg, rt)
        if new:
            tokens.update(new)
            _save_tokens(tokens)
            return new['id_token'], None

    return None, "Token expired. Run: drop login"


def _expired(id_token):
    try:
        payload = id_token.split('.')[1]
        payload += '=' * (4 - len(payload) % 4)
        data = json.loads(base64.urlsafe_b64decode(payload))
        return data.get('exp', 0) < time.time() + 60
    except Exception:
        return True


def _refresh(cfg, refresh_token):
    try:
        data = urlencode({
            'refresh_token': refresh_token,
            'client_id': cfg.get('client_id', ''),
            'client_secret': cfg.get('client_secret', ''),
            'grant_type': 'refresh_token',
        }).encode()
        return json.loads(urlopen(Request('https://oauth2.googleapis.com/token', data=data)).read())
    except Exception:
        return None


def _save_tokens(tokens):
    os.makedirs(CONFIG_DIR, exist_ok=True)
    with open(TOKEN_FILE, 'w') as f:
        json.dump(tokens, f, indent=2)
    try:
        os.chmod(TOKEN_FILE, 0o600)
    except (OSError, NotImplementedError):
        pass


# ------------------------------------------------------------------ api

def api(method, path, body=None):
    cfg = load_config()
    if not cfg:
        return None, "Not configured. Run: drop setup && drop login"

    token, err = get_id_token()
    if err:
        return None, err

    url = cfg['url'].rstrip('/') + '/' + path.lstrip('/')
    data = json.dumps(body).encode() if body else None
    req = Request(url, data=data, method=method)
    req.add_header('Authorization', f'Bearer {token}')
    req.add_header('Content-Type', 'application/json')

    try:
        return json.loads(urlopen(req).read()), None
    except HTTPError as e:
        try:
            err = json.loads(e.read())
            return None, err.get('error', f'HTTP {e.code}')
        except Exception:
            return None, f'HTTP {e.code}'


# ------------------------------------------------------------------ tool handlers

def handle_tool(name, args):
    if name == 'deaddrop_put':
        r, err = api('POST', '/secrets', {'name': args['name'], 'value': args['value']})
        if err:
            return err
        return f"Stored secret \"{args['name']}\""

    elif name == 'deaddrop_get':
        ref = args['name']
        if '/' in ref:
            owner, sname = ref.split('/', 1)
            r, err = api('GET', f'/shared/{owner}/{sname}')
        else:
            r, err = api('GET', f'/secrets/{ref}')
        if err:
            return err
        return r.get('value', '')

    elif name == 'deaddrop_list':
        r, err = api('GET', '/secrets')
        if err:
            return err
        secrets = r.get('secrets', [])
        if not secrets:
            return "No secrets stored."
        return '\n'.join(s['name'] for s in secrets)

    elif name == 'deaddrop_shared':
        r, err = api('GET', '/shared')
        if err:
            return err
        shared = r.get('shared', [])
        if not shared:
            return "No secrets shared with you."
        return '\n'.join(f"{s['owner']}/{s['name']}" for s in shared)

    elif name == 'deaddrop_share':
        r, err = api('POST', f"/secrets/{args['name']}/share", {'email': args['email']})
        if err:
            return err
        return f"Shared \"{args['name']}\" with {args['email']}. They can retrieve it with: deaddrop_get {r.get('hint', '')}"

    elif name == 'deaddrop_revoke':
        r, err = api('POST', f"/secrets/{args['name']}/unshare", {'email': args['email']})
        if err:
            return err
        return f"Revoked access for {args['email']}"

    elif name == 'deaddrop_who':
        r, err = api('GET', f"/secrets/{args['name']}/who")
        if err:
            return err
        shared_with = r.get('shared_with', [])
        if not shared_with:
            return f"\"{args['name']}\" is not shared with anyone."
        return "Shared with:\n" + '\n'.join(f"  {e}" for e in shared_with)

    elif name == 'deaddrop_delete':
        r, err = api('DELETE', f"/secrets/{args['name']}")
        if err:
            return err
        return f"Deleted \"{args['name']}\""

    elif name == 'deaddrop_env':
        ref = args['name']
        if '/' in ref:
            owner, sname = ref.split('/', 1)
            r, err = api('GET', f'/shared/{owner}/{sname}')
            vname = sname
        else:
            r, err = api('GET', f'/secrets/{ref}')
            vname = ref
        if err:
            return err
        var = args.get('var_name') or vname.upper().replace('-', '_')
        return f'export {var}="{r["value"]}"'

    return f"Unknown tool: {name}"


# ------------------------------------------------------------------ MCP protocol

def send(msg):
    out = json.dumps(msg)
    sys.stdout.write(f'Content-Length: {len(out)}\r\n\r\n{out}')
    sys.stdout.flush()


def read_message():
    headers = {}
    while True:
        line = sys.stdin.readline()
        if not line:
            return None
        line = line.strip()
        if not line:
            break
        if ':' in line:
            k, v = line.split(':', 1)
            headers[k.strip().lower()] = v.strip()

    length = int(headers.get('content-length', 0))
    if length == 0:
        return None

    body = sys.stdin.read(length)
    return json.loads(body)


def main():
    while True:
        msg = read_message()
        if msg is None:
            break

        method = msg.get('method', '')
        msg_id = msg.get('id')

        if method == 'initialize':
            send({
                "jsonrpc": "2.0",
                "id": msg_id,
                "result": {
                    "protocolVersion": "2024-11-05",
                    "capabilities": {"tools": {}},
                    "serverInfo": {
                        "name": "deaddrop",
                        "version": "1.0.0",
                    },
                },
            })

        elif method == 'notifications/initialized':
            pass

        elif method == 'tools/list':
            send({
                "jsonrpc": "2.0",
                "id": msg_id,
                "result": {"tools": TOOLS},
            })

        elif method == 'tools/call':
            params = msg.get('params', {})
            tool_name = params.get('name', '')
            tool_args = params.get('arguments', {})

            try:
                result = handle_tool(tool_name, tool_args)
                is_error = result.startswith("Not configured") or result.startswith("Not signed in") or result.startswith("Token expired") or result.startswith("HTTP ")
            except Exception as e:
                result = str(e)
                is_error = True

            send({
                "jsonrpc": "2.0",
                "id": msg_id,
                "result": {
                    "content": [{"type": "text", "text": result}],
                    "isError": is_error,
                },
            })

        elif method == 'ping':
            send({"jsonrpc": "2.0", "id": msg_id, "result": {}})

        elif msg_id is not None:
            send({
                "jsonrpc": "2.0",
                "id": msg_id,
                "error": {"code": -32601, "message": f"Method not found: {method}"},
            })


if __name__ == '__main__':
    main()
