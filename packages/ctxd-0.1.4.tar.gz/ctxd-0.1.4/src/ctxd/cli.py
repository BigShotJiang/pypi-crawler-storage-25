"""Public command-line interface for ctxd."""

import argparse
import json
import sys
import webbrowser
from typing import Sequence

from ctxd import Client, CtxdError
from ctxd.auth import logout as logout_credentials
from ctxd.auth import start_device_login, wait_for_device_login


def main(argv: Sequence[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)

    try:
        if args.command == "login":
            return _handle_login(args)
        if args.command == "logout":
            return _handle_logout(args)

        client = Client()

        if args.command == "search":
            result = client.search(args.query)
            return _emit_result(result.model_dump(), as_json=args.json)
        if args.command == "fetch-document":
            result = client.fetch_document(args.document_uid)
            return _emit_result(result.model_dump(), as_json=args.json)
        if args.command == "profile":
            result = client.get_profile()
            return _emit_result(result.model_dump(), as_json=args.json)
    except (CtxdError, ValueError) as exc:
        print(str(exc), file=sys.stderr)
        return 1

    parser.error(f"Unknown command: {args.command}")
    return 2


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="ctxd")

    subparsers = parser.add_subparsers(dest="command", required=True)

    login_parser = subparsers.add_parser("login")
    login_parser.add_argument("--no-browser", action="store_true")
    login_parser.add_argument("--timeout", type=float, default=300.0)

    subparsers.add_parser("logout")

    search_parser = subparsers.add_parser("search")
    search_parser.add_argument("query")
    search_parser.add_argument("--json", action="store_true")

    fetch_parser = subparsers.add_parser("fetch-document")
    fetch_parser.add_argument("document_uid")
    fetch_parser.add_argument("--json", action="store_true")

    profile_parser = subparsers.add_parser("profile")
    profile_parser.add_argument("--json", action="store_true")

    return parser


def _handle_login(args: argparse.Namespace) -> int:
    device_login = start_device_login()

    print("Open this URL to continue authentication:")
    print(device_login.verification_uri_complete)
    print(f"Code: {device_login.user_code}")

    if not args.no_browser:
        webbrowser.open(device_login.verification_uri_complete)

    credentials = wait_for_device_login(
        device_login=device_login,
        timeout_seconds=args.timeout,
        persist_credentials=True,
    )

    print(f"Logged in to {credentials.base_url}")
    return 0


def _handle_logout(args: argparse.Namespace) -> int:
    del args
    logout_credentials(keep_base_url=True)
    print("Cleared stored ctxd credentials.")
    return 0


def _emit_result(payload: dict, *, as_json: bool) -> int:
    if as_json:
        print(json.dumps(payload, indent=2, sort_keys=True))
        return 1 if _payload_has_error(payload) else 0

    if "results" in payload:
        error = payload.get("error")
        dsl_parse_error = payload.get("dsl_parse_error")
        if error:
            print(f"Error: {error}")
        if dsl_parse_error:
            print(f"DSL parse error: {dsl_parse_error}")
        if not payload["results"] and not error and not dsl_parse_error:
            print("No results found.")
        for item in payload["results"]:
            print(f"- {item['title']} [{item['id']}]")
            print(f"  URL: {item['url']}")
            if item.get("text"):
                print(f"  Text: {item['text']}")
        return 1 if error or dsl_parse_error else 0

    if "integration_access" in payload:
        print(payload["integration_access"])
        if payload.get("file_tree"):
            print()
            print(payload["file_tree"])
        return 0

    if payload.get("error"):
        print(f"Error: {payload['error']}")
        return 1

    title = payload.get("title") or payload.get("id") or "Document"
    print(title)
    if payload.get("url"):
        print(payload["url"])
    if payload.get("text"):
        print()
        print(payload["text"])
    return 0


def _payload_has_error(payload: dict) -> bool:
    if payload.get("error"):
        return True
    return bool(payload.get("dsl_parse_error"))
