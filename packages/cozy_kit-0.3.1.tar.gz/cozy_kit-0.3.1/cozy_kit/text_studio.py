import string
from . import data, errors

"""A text utility module:
        to_morse() converts text to morse code,
        to_upper() converts text to upper case,
        to_title() converts text to title case,
        to_lower() converts text to lower case,
        replace_with_spaces(replacement) replaces the given replacement in the text with a space,
        space_out_letters() adds a space after each letter in the text,
        reverse() reverses the text,
        word_count() returns the number of words in the text,
        char_count() returns the number of characters in the text,
        remove_punctuation() removes punctuation in the text,
        remove_spaces() removes spaces in the text,
        snake() turns the text to snake case,
        caesar(shift) shifts each letter in the text by the number of shifts.
        """

class TextStudio:

    def to_morse(self, text):
        """This method converts text to morse code"""
        result = ''

        for letter in text.upper():
            result += f"{data.morse_code.get(letter, '?')} "

        return result.strip()

    def to_upper(self, text):
        """This method converts text to upper case"""
        return text.upper()

    def to_title(self, text):
        """This method converts text to title case"""
        return text.title()

    def to_lower(self, text):
        """This method converts text to lower case"""
        return text.lower()

    def replace_with_spaces(self, text, replacement):
        """This method replaces the given replacement with a space in the text"""
        return text.replace(replacement, ' ')

    def space_out_letters(self, text):
        """This method adds a space after each letter in the text"""
        result = ''

        for char in text:
            result += f'{char} '

        return result.strip()

    def reverse(self, text):
        """This method reverses the text"""
        return text[::-1]

    def word_count(self, text):
        """This method returns the number of words in the text"""
        return len(text.split())

    def char_count(self, text):
        """This method returns the number of characters in the text"""
        return len(text)

    def remove_spaces(self, text):
        """This method removes the spaces in the text"""
        return text.replace(' ', '')

    def snake(self, text):
        """This method turns the text to snake case"""
        return text.lower().replace(' ', '_')

    def caesar(self, text, shift):
        """This method shifts each letter in the text by the number of shifts"""
        if not isinstance(shift, int):
            raise errors.InvalidShiftError(
                f"{shift} is an invalid shift number. {shift} must be an integer."
            )
        result = ''

        for char in text:
            if char.isalpha():

                start = ord('A') if char.isupper() else ord('a')

                shifted = (
                    (ord(char) - start + shift) % 26
                ) + start

                result += chr(shifted)

            else:
                result += char

        return result

    def remove_punctuation(self, text):
        """This method removes punctuation in the text"""
        result = ''

        for char in text:
            if char not in string.punctuation:
                result += char

        return result
