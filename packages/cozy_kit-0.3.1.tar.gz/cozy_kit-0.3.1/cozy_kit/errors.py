class CozyKitError(Exception):
    pass

class InvalidTimeTypeError(CozyKitError):
    pass

class InvalidShiftError(CozyKitError):
    pass

class InvalidTimeAmountError(CozyKitError):
    pass

class InvalidStoryError(CozyKitError):
    pass

class StopWatchNotStartedError(CozyKitError):
    pass

class DatabaseNotFoundError(CozyKitError):
    pass