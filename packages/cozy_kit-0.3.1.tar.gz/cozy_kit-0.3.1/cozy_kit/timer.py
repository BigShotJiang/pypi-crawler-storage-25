import time
import datetime as dt
from . import errors

"""
A timer utility module.

Features:
    - countdown timers
    - pomodoro timers
    - stopwatch support
    - waiting utilities

Methods:
    countdown(count, time_type, show)
        Starts a countdown timer.

    pomodoro(work_time, break_time,
              long_break_time, show)
        Starts a pomodoro timer.

    wait(count, time_type)
        Pauses execution for the
        specified duration.

    get_time()
        Returns the current time.

    start_stopwatch()
        Starts the stopwatch.

    end_stopwatch()
        Stops the stopwatch and
        returns elapsed time.
"""

class Timer:
    TIME_TYPES = {
        'min':60,
        'sec':1,
        'hour':3600
                  }

    def __format_type(self, count, time_type):
        """
            Converts a time amount into
            seconds.

            Parameters:
                count:
                    Time amount.

                time_type:
                    sec, min, or hour.

            Returns:
                int:
                    Time converted to
                    seconds.
            """
        if time_type not in self.TIME_TYPES:
            raise errors.InvalidTimeTypeError(f'"{time_type}" is not a valid time type. Choose: sec, min, or hour')

        elif count <= 0:
            raise errors.InvalidTimeAmountError(f'"{count}" is and invalid amount. {count} Must be greater than 0')
        count *= self.TIME_TYPES[time_type]

        return count

    def __format_time(self, count, show):
        """
            Formats and displays a live
            countdown timer.

            Parameters:
                count:
                    Countdown duration in
                    seconds.

                show:
                    Function used to display
                    timer output.
            """
        for i in range(count, 0, -1):

            hours, remainder = divmod(i, 3600)

            mins, secs = divmod(remainder, 60)

            if hours > 0:

                show(
                    f"{hours:02}:{mins:02}:{secs:02}"
                )

            else:

                show(
                    f"{mins:02}:{secs:02}"
                )

            time.sleep(1)

    def countdown(self, count, time_type, show):
        """
        Starts a countdown timer.

        Parameters:
            count:
                Time amount.

            time_type:
                sec, min, or hour.

            show:
                Function used to display
                timer output.
        """

        count = self.__format_type(
            count,
            time_type
        )

        self.__format_time(
            count,
            show
        )

        show("⏰ Time's up!")
    def pomodoro(self, work_time, break_time, long_break_time, show):
        """
        Starts a fully implemented
        pomodoro timer with work,
        short break, and long break
        sessions.

        Parameters:
            work_time:
                Work session duration
                in minutes.

            break_time:
                Short break duration
                in minutes.

            long_break_time:
                Long break duration
                in minutes.

            show:
                Function used to display
                timer output.
        """
        reps = 0
        work_time *= 60
        break_time *= 60
        long_break_time *= 60
        running = True
        while running:
            reps += 1
            if reps % 8 == 0:
                show("⏰ Long Break Time")
                self.__format_time(count=long_break_time, show=show)
                break
            elif reps % 2 == 0:
                show("☕ Short Break Time")
                self.__format_time(count=break_time, show=show)
            else:
                show("💻 Work Time")
                self.__format_time(count=work_time, show=show)

    def wait(self, count, time_type):
        """
            Pauses execution for the
            specified duration.

            Parameters:
                count:
                    Time amount.

                time_type:
                    sec, min, or hour.
            """
        sleep_count = self.__format_type(count=count, time_type=time_type)

        time.sleep(sleep_count)

    def get_time(self):
        """
          Returns the current time.

          Returns:
              str:
                  Current time formatted
                  as HH:MM:SS.
          """
        now = dt.datetime.now()
        return now.strftime("%H:%M:%S")

    def start_stopwatch(self):
        """Starts the stopwatch"""
        self.start_time = dt.datetime.now()

    def end_stopwatch(self):
        """Ends the stopwatch and returns the elapsed time"""
        end = dt.datetime.now()
        try:
            elapsed = end - self.start_time
        except AttributeError:
            raise errors.StopwatchNotStartedError('Stopwatch not started! Please run start_stopwatch first.')

        return elapsed