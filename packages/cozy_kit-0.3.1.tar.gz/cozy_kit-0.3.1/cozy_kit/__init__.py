from importlib.metadata import version

from .core import Greeting
from .timer import Timer
from .text_studio import TextStudio

__version__ = version("cozy-kit")
__version_info__ = tuple(map(int, __version__.split(".")))


__author__ = 'Youssef Ahmed'
__author_email__ = "youssef.ahmed.29062017@gmail.com"


__description__ = (
    "A cozy Python package with "
    "greetings, timers, and "
    "text utilities."
)

__github__ = "https://github.com/youssefahmed2017/cozy-kit"
__pypi__ = "https://pypi.org/project/cozy-kit/"

__license__ = "MIT"

__details__ = {
    "version": __version__,
    "version_info": __version_info__,
    "author": __author__,
    "author_email": __author_email__,
    "description": __description__,
    "github": __github__,
    "pypi": __pypi__,
    "license": __license__
}
details = __details__
__all__ = ['Greeting', 'Timer', 'TextStudio', 'details']