import json, random
from pathlib import Path
import datetime
from . import errors

"""The module for greeting:
        welcome() welcomes you,
        bye() says goodbye to you,
        good_morning() gives you a morning quote from its database,
        good_afternoon() gives you an afternoon quote from its database,
        good_evening() gives you an evening quote from its database,
        good_night() tells you a bedtime story from its database,
        auto_greet() greets you depending on the season and time,
        motivate() motivates you,
        fun_fact() gives you a fun fact,
        add_bedtime_story() adds a bedtime story to the bedtime stories database.
        """

BASE_DIR = Path(__file__).resolve().parent

class Greeting:
    def __init__(self, **details):
        """Here is what you can enter:
                name,
                age,
                gender,
                and nickname"""
        self.details = details
        self.name = details.get("name", "User").title()
        self.age = details.get('age')
        self.gender = details.get('gender', "").title()
        self.nickname = details.get('nickname', "").title()

    def __say(self, something):
        message = f'{something.title()} {self.name}!'


        if self.nickname:
            message += f'\nOr {something} {self.nickname}!'

        return message

    def welcome(self):
        """This method welcomes you"""
        return self.__say(something='welcome')

    def bye(self, destination="Where ever you're gonna go"):
        """This method tells you goodbye.
            Parameters: destination which is set default as 'Where ever you're gonna go' """
        message = f'Bye {self.name}! Have a nice day at {destination}!'
        if self.nickname:
            message += f'\nOr bye {self.nickname}!'
        return message

    def good_morning(self):
        """This method tells you a morning quote from its database"""
        message = self.__say('good morning')

        message += "\nAnyways, here's a quick morning quote."

        mornings_path = BASE_DIR / "jsons" / "mornings.json"

        try:
            with open(mornings_path, 'r', encoding='utf-8') as morning_quotes:
                quotes = json.load(morning_quotes)
        except FileNotFoundError:
            raise errors.DatabaseNotFoundError('Database not found. Check if there is a typo in the database name.')

        morning = random.choice(
            quotes['mornings']
        )

        morning_quote = (
            f"{morning['name']}\n\n"
            f"{morning['content']}"
        )

        return f"{message}\n\n{morning_quote}"

    def good_afternoon(self):
        """This method tells you an afternoon quote from its database"""
        message = self.__say('good afternoon')

        message += "\nAnyways, here's a quick afternoon quote.\n"

        afternoons_path = BASE_DIR / "jsons" / "afternoons.json"

        try:
            with open(afternoons_path, 'r', encoding='utf-8') as afternoon_quotes:
                quotes = json.load(afternoon_quotes)
        except FileNotFoundError:
            raise errors.DatabaseNotFoundError('Database not found. Check if there is a typo in the database name.')

        quote = random.choice(quotes['afternoons'])

        return f"{message}\n{quote['name']}\n\n{quote['content']}"

    def good_evening(self):
        """This method tells you an evening quote from its database"""
        message = self.__say('good evening')

        message += "\nAnyways, here's a quick evening quote.\n"

        afternoons_path = BASE_DIR / "jsons" / "afternoons.json"

        try:
            with open(afternoons_path, 'r', encoding='utf-8') as afternoon_quotes:
                quotes = json.load(afternoon_quotes)
        except FileNotFoundError:
            raise errors.DatabaseNotFoundError('Database not found. Check if there is a typo in the database name.')

        quote = random.choice(quotes['afternoons'])

        return f"{message}\n{quote['name']}\n\n{quote['content']}"

    def good_night(self):
        """This method tells you a bedtime story from its database"""
        message = self.__say('good night')

        message += "\nAnyways, here's a quick bedtime story.\n"

        bedtime_path = BASE_DIR / "jsons" / "bedtime_stories.json"

        try:
            with open(bedtime_path, 'r', encoding='utf-8') as bedtime_stories:
                stories = json.load(bedtime_stories)
        except FileNotFoundError:
            raise errors.DatabaseNotFoundError('Database not found. Check if there is a typo in the database name.')

        random_title = random.choice(
            list(stories['bedtime_stories'].keys())
        )

        random_story = stories['bedtime_stories'][random_title]

        bedtime = f'{random_title}\n\n{random_story}'

        return f"{message}\n\n{bedtime}"

    def auto_greet(self):
        """This method greets you depending on the time and season"""
        hour = datetime.datetime.now().hour
        month = datetime.datetime.now().month

        # Detect season
        if month in [12, 1, 2]:
            season = "winter"

        elif month in [3, 4, 5]:
            season = "spring"

        elif month in [6, 7, 8]:
            season = "summer"

        else:
            season = "autumn"

        # Winter times
        if season == "winter":
            if 6 <= hour < 11:
                return self.good_morning()

            elif 11 <= hour < 16:
                return self.good_afternoon()

            elif 16 <= hour < 20:
                return self.good_evening()

            else:
                return self.good_night()

        # Summer times
        elif season == "summer":
            if 5 <= hour < 12:
                return self.good_morning()

            elif 12 <= hour < 18:
                return self.good_afternoon()

            elif 18 <= hour < 22:
                return self.good_evening()

            else:
                return self.good_night()

        # Spring & autumn
        else:
            if 6 <= hour < 12:
                return self.good_morning()

            elif 12 <= hour < 17:
                return self.good_afternoon()

            elif 17 <= hour < 21:
                return self.good_evening()

            else:
                return self.good_night()

    def motivate(self):
        """This method motivates you"""
        mots_path = BASE_DIR / "jsons" / "motivations.json"

        try:
            with open(mots_path, 'r', encoding='utf-8') as file:
                motivates = json.load(file)
        except FileNotFoundError:
            raise errors.DatabaseNotFoundError('Database not found. Check if there is a typo in the database name.')

        motivation = random.choice(
            motivates['motivations']
        )

        return motivation['name'], motivation['content']

    def fun_fact(self):
        """This method tells you a fun fact from its database"""
        facts_path = BASE_DIR / "jsons" / "fun_facts.json"

        try:
            with open(facts_path, 'r') as file:
                fun_facts = json.load(file)
        except FileNotFoundError:
            raise errors.DatabaseNotFoundError('Database not found. Check if there is a typo in the database name.')

        fun_fact = random.choice(fun_facts['facts'])

        return f"{fun_fact['name']}\n\n{fun_fact['content']}"

    def add_bedtime_story(self, title, content):
        """This method adds a bedtime story to the bedtime story database
        Parameters: title and content"""

        if not title.strip():
            raise errors.InvalidStoryError(
                "Story title cannot be empty."
            )

        if not content.strip():
            raise errors.InvalidStoryError(
                "Story content cannot be empty."
            )

        bedtime_stories_path = BASE_DIR / "jsons" / "bedtime_stories.json"
        try:
            with open(bedtime_stories_path, "r", encoding="utf-8") as file:
                data = json.load(file)
        except FileNotFoundError:
            raise errors.DatabaseNotFoundError('Database not found. Check if there is a typo in the database name.')

        data["bedtime_stories"][title] = content
        try:
            with open(bedtime_stories_path, "w", encoding="utf-8") as file:
                json.dump(data, file, indent=4)
        except FileNotFoundError:
            raise errors.DatabaseNotFoundError('Database not found. Check if there is a typo in the database name.')