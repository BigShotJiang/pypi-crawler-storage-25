import math
import re
from dataclasses import dataclass, field
from typing import Any, List, Mapping, Optional, Tuple

from flyql.core.exceptions import FlyqlError
from flyql.core.expression import Expression
from flyql.types import ValueType
from flyql.core.key import Key, parse_key
from flyql.core.constants import (
    Operator,
    VALID_KEY_VALUE_OPERATORS,
    VALID_BOOL_OPERATORS,
)
from flyql.core.tree import Node

from flyql.generators.postgresql.column import Column
from flyql.generators.postgresql.helpers import (
    validate_operation,
    validate_in_list_types,
)
from flyql.generators.postgresql.constants import (
    NORMALIZED_TYPE_STRING,
    NORMALIZED_TYPE_INT,
    NORMALIZED_TYPE_FLOAT,
    NORMALIZED_TYPE_BOOL,
    NORMALIZED_TYPE_DATE,
)
from flyql.generators.transformer_helpers import (
    apply_transformer_sql,
    get_transformer_output_type,
    validate_transformer_chain,
)
from flyql.transformers.registry import TransformerRegistry

BOOL_OP_TO_SQL = {
    "and": "AND",
    "or": "OR",
}

JSON_KEY_PATTERN = re.compile(r"^[a-zA-Z_][.a-zA-Z0-9_-]*$")

ESCAPE_CHARS_MAP = {
    "\b": "\\b",
    "\f": "\\f",
    "\r": "\\r",
    "\n": "\\n",
    "\t": "\\t",
    "\0": "\\0",
    "\a": "\\a",
    "\v": "\\v",
    "\\": "\\\\",
    "'": "\\'",
}


def validate_json_path_part(part: str, quoted: bool) -> None:
    if quoted:
        return
    if not part:
        raise FlyqlError("invalid JSON path part")
    try:
        idx = int(part)
        if idx >= 0 and str(idx) == part:
            return
    except ValueError:
        pass
    if not JSON_KEY_PATTERN.match(part):
        raise FlyqlError("invalid JSON path part")


def validate_operator(op: str) -> None:
    if op not in VALID_KEY_VALUE_OPERATORS:
        raise FlyqlError(f"invalid operator: {op}")


def validate_bool_operator(op: str) -> None:
    if op not in VALID_BOOL_OPERATORS:
        raise FlyqlError(f"invalid bool operator: {op}")


def _escape_like_param(value: str) -> str:
    s = str(value)
    like_escaped = ""
    i = 0
    while i < len(s):
        c = s[i]
        if c == "\\":
            if i + 1 < len(s) and s[i + 1] in ("%", "_"):
                like_escaped += c + s[i + 1]
                i += 2
                continue
            else:
                like_escaped += "\\\\"
        else:
            like_escaped += c
        i += 1
    return escape_param(like_escaped)


def escape_param(item: Any) -> str:
    if item is None:
        return "NULL"
    elif isinstance(item, str):
        return f"'{''.join(ESCAPE_CHARS_MAP.get(c, c) for c in item)}'"
    elif isinstance(item, bool):
        return "true" if item else "false"
    elif isinstance(item, float):
        if not math.isfinite(item):
            raise FlyqlError(f"unsupported numeric value for escape_param: {item}")
        return str(int(item)) if item == int(item) else str(item)
    elif isinstance(item, int):
        return str(item)
    else:
        raise FlyqlError(f"unsupported type for escape_param: {type(item).__name__}")


def escape_identifier(name: str) -> str:
    escaped = name.replace('"', '""')
    return f'"{escaped}"'


def get_identifier(column: Column) -> str:
    if column.raw_identifier:
        return column.raw_identifier
    return escape_identifier(column.name)


def _build_jsonb_path(
    identifier: str, path_parts: List[str], quoted: List[bool]
) -> str:
    if not path_parts:
        return identifier
    result = identifier
    for i, part in enumerate(path_parts):
        is_quoted = i < len(quoted) and quoted[i]
        is_last = i == len(path_parts) - 1
        if not is_quoted:
            try:
                idx = int(part)
                if idx >= 0 and str(idx) == part:
                    result += f"->>{idx}" if is_last else f"->{idx}"
                    continue
            except ValueError:
                pass
        escaped = escape_param(part)
        result += f"->>{escaped}" if is_last else f"->{escaped}"
    return result


def _build_jsonb_path_raw(
    identifier: str, path_parts: List[str], quoted: List[bool]
) -> str:
    if not path_parts:
        return identifier
    result = identifier
    for i, part in enumerate(path_parts):
        is_quoted = i < len(quoted) and quoted[i]
        if not is_quoted:
            try:
                idx = int(part)
                if idx >= 0 and str(idx) == part:
                    result += f"->{idx}"
                    continue
            except ValueError:
                pass
        escaped = escape_param(part)
        result += f"->{escaped}"
    return result


def expression_to_sql_simple(
    expression: Expression,
    columns: Mapping[str, Column],
    registry: Optional[TransformerRegistry] = None,
) -> str:
    column_name = expression.key.segments[0]
    if column_name not in columns:
        raise FlyqlError(f"unknown column: {column_name}")

    column = columns[column_name]

    rhs_ref = None
    if expression.value_type == ValueType.COLUMN:
        rhs_ref = _resolve_rhs_column_ref(str(expression.value), columns)

    if rhs_ref is not None:
        identifier = get_identifier(column)
        if expression.key.transformers:
            validate_transformer_chain(expression.key.transformers, registry=registry)
            identifier = apply_transformer_sql(
                identifier, expression.key.transformers, "postgresql", registry=registry
            )
        if expression.operator == Operator.REGEX.value:
            return f"{identifier} ~ {rhs_ref}"
        elif expression.operator == Operator.NOT_REGEX.value:
            return f"{identifier} !~ {rhs_ref}"
        elif expression.operator in (
            Operator.LIKE.value,
            Operator.NOT_LIKE.value,
            Operator.ILIKE.value,
            Operator.NOT_ILIKE.value,
        ):
            like_op = {
                Operator.LIKE.value: "LIKE",
                Operator.NOT_LIKE.value: "NOT LIKE",
                Operator.ILIKE.value: "ILIKE",
                Operator.NOT_ILIKE.value: "NOT ILIKE",
            }[expression.operator]
            return f"{identifier} {like_op} {rhs_ref}"
        else:
            return f"{identifier} {expression.operator} {rhs_ref}"
    else:
        if column.values and str(expression.value) not in column.values:
            raise FlyqlError(f"unknown value: {expression.value}")

        if column.normalized_type is not None and not expression.key.transformers:
            validate_operation(
                expression.value, column.normalized_type, expression.operator
            )

        identifier = get_identifier(column)
        if expression.key.transformers:
            validate_transformer_chain(expression.key.transformers, registry=registry)
            identifier = apply_transformer_sql(
                identifier, expression.key.transformers, "postgresql", registry=registry
            )

        if expression.operator == Operator.REGEX.value:
            value = escape_param(str(expression.value))
            return f"{identifier} ~ {value}"
        elif expression.operator == Operator.NOT_REGEX.value:
            value = escape_param(str(expression.value))
            return f"{identifier} !~ {value}"
        elif expression.operator == Operator.LIKE.value:
            value = _escape_like_param(expression.value)
            return f"{identifier} LIKE {value}"
        elif expression.operator == Operator.NOT_LIKE.value:
            value = _escape_like_param(expression.value)
            return f"{identifier} NOT LIKE {value}"
        elif expression.operator == Operator.ILIKE.value:
            value = _escape_like_param(expression.value)
            return f"{identifier} ILIKE {value}"
        elif expression.operator == Operator.NOT_ILIKE.value:
            value = _escape_like_param(expression.value)
            return f"{identifier} NOT ILIKE {value}"
        elif expression.operator in (Operator.EQUALS.value, Operator.NOT_EQUALS.value):
            if expression.value_type == ValueType.NULL:
                return (
                    f"{identifier} IS NULL"
                    if expression.operator == Operator.EQUALS.value
                    else f"{identifier} IS NOT NULL"
                )
            elif expression.value_type == ValueType.BOOLEAN:
                bool_literal = "TRUE" if expression.value else "FALSE"
                return f"{identifier} {expression.operator} {bool_literal}"
            else:
                value = escape_param(str(expression.value))
                return f"{identifier} {expression.operator} {value}"
        else:
            value = escape_param(expression.value)
            return f"{identifier} {expression.operator} {value}"


def expression_to_sql_segmented(
    expression: Expression, columns: Mapping[str, Column]
) -> str:
    column_name = expression.key.segments[0]
    if column_name not in columns:
        raise FlyqlError(f"unknown column: {column_name}")

    column = columns[column_name]

    if (
        column.normalized_type is not None
        and not column.jsonstring
        and not expression.key.transformers
    ):
        validate_operation(
            expression.value, column.normalized_type, expression.operator
        )

    identifier = get_identifier(column)

    if column.is_jsonb or column.jsonstring:
        cast_identifier = f"({identifier}::jsonb)" if column.jsonstring else identifier
        json_path = expression.key.segments[1:]
        json_path_quoted = expression.key.quoted_segments[1:]
        for i, part in enumerate(json_path):
            validate_json_path_part(
                part, json_path_quoted[i] if i < len(json_path_quoted) else False
            )

        path_expr = _build_jsonb_path(cast_identifier, json_path, json_path_quoted)
        if expression.key.transformers:
            path_expr = apply_transformer_sql(
                path_expr, expression.key.transformers, "postgresql"
            )
        rhs_ref = None
        if expression.value_type == ValueType.COLUMN:
            rhs_ref = _resolve_rhs_column_ref(str(expression.value), columns)

        if rhs_ref is not None:
            if expression.operator == Operator.REGEX.value:
                return f"{path_expr} ~ {rhs_ref}"
            elif expression.operator == Operator.NOT_REGEX.value:
                return f"{path_expr} !~ {rhs_ref}"
            else:
                return f"{path_expr} {expression.operator} {rhs_ref}"

        value = escape_param(expression.value)

        if expression.operator == Operator.REGEX.value:
            return f"{path_expr} ~ {value}"
        elif expression.operator == Operator.NOT_REGEX.value:
            return f"{path_expr} !~ {value}"
        elif isinstance(expression.value, (int, float)) and not isinstance(
            expression.value, bool
        ):
            jsonb_raw = _build_jsonb_path_raw(
                cast_identifier, json_path, json_path_quoted
            )
            return (
                f"(jsonb_typeof({jsonb_raw}) = 'number' AND "
                f"({path_expr})::numeric {expression.operator} {value})"
            )
        elif isinstance(expression.value, str):
            jsonb_raw = _build_jsonb_path_raw(
                cast_identifier, json_path, json_path_quoted
            )
            return (
                f"(jsonb_typeof({jsonb_raw}) = 'string' AND "
                f"{path_expr} {expression.operator} {value})"
            )
        else:
            return f"{path_expr} {expression.operator} {value}"

    elif column.is_hstore:
        map_key = ".".join(expression.key.segments[1:])
        escaped_map_key = escape_param(map_key)
        rhs_ref = None
        if expression.value_type == ValueType.COLUMN:
            rhs_ref = _resolve_rhs_column_ref(str(expression.value), columns)
        value = rhs_ref if rhs_ref is not None else escape_param(expression.value)
        access_expr = f"{identifier}->{escaped_map_key}"
        if expression.key.transformers:
            access_expr = apply_transformer_sql(
                access_expr, expression.key.transformers, "postgresql"
            )

        if expression.operator == Operator.REGEX.value:
            return f"{access_expr} ~ {value}"
        elif expression.operator == Operator.NOT_REGEX.value:
            return f"{access_expr} !~ {value}"
        else:
            return f"{access_expr} {expression.operator} {value}"

    elif column.is_array:
        array_index_str = ".".join(expression.key.segments[1:])
        try:
            array_index = int(array_index_str)
        except ValueError as err:
            raise FlyqlError(
                f"invalid array index, expected number: {array_index_str}"
            ) from err
        rhs_ref = None
        if expression.value_type == ValueType.COLUMN:
            rhs_ref = _resolve_rhs_column_ref(str(expression.value), columns)
        value = rhs_ref if rhs_ref is not None else escape_param(expression.value)
        pg_index = array_index + 1
        access_expr = f"{identifier}[{pg_index}]"
        if expression.key.transformers:
            access_expr = apply_transformer_sql(
                access_expr, expression.key.transformers, "postgresql"
            )

        if expression.operator == Operator.REGEX.value:
            return f"{access_expr} ~ {value}"
        elif expression.operator == Operator.NOT_REGEX.value:
            return f"{access_expr} !~ {value}"
        else:
            return f"{access_expr} {expression.operator} {value}"

    else:
        raise FlyqlError("path search for unsupported column type")


def in_expression_to_sql_where(
    expression: Expression, columns: Mapping[str, Column]
) -> str:
    is_not_in = expression.operator == Operator.NOT_IN.value

    if not expression.values:
        return "TRUE" if is_not_in else "FALSE"

    column_name = expression.key.segments[0]
    if column_name not in columns:
        raise FlyqlError(f"unknown column: {column_name}")

    column = columns[column_name]

    is_heterogeneous = (
        expression.values_types is not None and len(set(expression.values_types)) > 1
    )
    if (
        column.normalized_type is not None
        and not expression.key.is_segmented
        and not is_heterogeneous
    ):
        validate_in_list_types(expression.values, column.normalized_type)

    values_parts: List[str] = []
    for i, v in enumerate(expression.values):
        rhs_ref = None
        if (
            expression.values_types is not None
            and i < len(expression.values_types)
            and expression.values_types[i] == ValueType.COLUMN
        ):
            rhs_ref = _resolve_rhs_column_ref(str(v), columns)
        values_parts.append(rhs_ref if rhs_ref is not None else escape_param(v))
    values_sql = ", ".join(values_parts)
    sql_op = "NOT IN" if is_not_in else "IN"
    identifier = get_identifier(column)

    if expression.key.is_segmented:
        if column.is_jsonb or column.jsonstring:
            cast_identifier = (
                f"({identifier}::jsonb)" if column.jsonstring else identifier
            )
            json_path = expression.key.segments[1:]
            json_path_quoted = expression.key.quoted_segments[1:]
            for i, part in enumerate(json_path):
                validate_json_path_part(
                    part, json_path_quoted[i] if i < len(json_path_quoted) else False
                )
            path_expr = _build_jsonb_path(cast_identifier, json_path, json_path_quoted)
            if expression.key.transformers:
                path_expr = apply_transformer_sql(
                    path_expr, expression.key.transformers, "postgresql"
                )
            return f"{path_expr} {sql_op} ({values_sql})"
        elif column.is_hstore:
            map_key = ".".join(expression.key.segments[1:])
            escaped_map_key = escape_param(map_key)
            leaf_expr = f"{identifier}->{escaped_map_key}"
            if expression.key.transformers:
                leaf_expr = apply_transformer_sql(
                    leaf_expr, expression.key.transformers, "postgresql"
                )
            return f"{leaf_expr} {sql_op} ({values_sql})"
        elif column.is_array:
            array_index_str = ".".join(expression.key.segments[1:])
            try:
                array_index = int(array_index_str)
            except ValueError as err:
                raise FlyqlError(
                    f"invalid array index, expected number: {array_index_str}"
                ) from err
            leaf_expr = f"{identifier}[{array_index + 1}]"
            if expression.key.transformers:
                leaf_expr = apply_transformer_sql(
                    leaf_expr, expression.key.transformers, "postgresql"
                )
            return f"{leaf_expr} {sql_op} ({values_sql})"
        else:
            raise FlyqlError("path search for unsupported column type")

    if expression.key.transformers:
        identifier = apply_transformer_sql(
            identifier, expression.key.transformers, "postgresql"
        )
    return f"{identifier} {sql_op} ({values_sql})"


def truthy_expression_to_sql_where(
    expression: Expression, columns: Mapping[str, Column]
) -> str:
    column_name = expression.key.segments[0]
    if column_name not in columns:
        raise FlyqlError(f"unknown column: {column_name}")

    column = columns[column_name]
    identifier = get_identifier(column)

    if expression.key.is_segmented:
        if column.is_jsonb or column.jsonstring:
            cast_identifier = (
                f"({identifier}::jsonb)" if column.jsonstring else identifier
            )
            json_path = expression.key.segments[1:]
            json_path_quoted = expression.key.quoted_segments[1:]
            for i, part in enumerate(json_path):
                validate_json_path_part(
                    part, json_path_quoted[i] if i < len(json_path_quoted) else False
                )
            path_expr = _build_jsonb_path(cast_identifier, json_path, json_path_quoted)
            if expression.key.transformers:
                path_expr = apply_transformer_sql(
                    path_expr, expression.key.transformers, "postgresql"
                )
            return f"({path_expr} IS NOT NULL AND {path_expr} != '')"
        elif column.is_hstore:
            map_key = ".".join(expression.key.segments[1:])
            escaped_map_key = escape_param(map_key)
            leaf_expr = f"{identifier}->{escaped_map_key}"
            if expression.key.transformers:
                leaf_expr = apply_transformer_sql(
                    leaf_expr, expression.key.transformers, "postgresql"
                )
            return f"({identifier} ? {escaped_map_key} AND " f"{leaf_expr} != '')"
        elif column.is_array:
            array_index_str = ".".join(expression.key.segments[1:])
            try:
                array_index = int(array_index_str)
            except ValueError as err:
                raise FlyqlError(
                    f"invalid array index, expected number: {array_index_str}"
                ) from err
            pg_index = array_index + 1
            leaf_expr = f"{identifier}[{pg_index}]"
            if expression.key.transformers:
                leaf_expr = apply_transformer_sql(
                    leaf_expr, expression.key.transformers, "postgresql"
                )
            return (
                f"(array_length({identifier}, 1) >= {pg_index} AND "
                f"{leaf_expr} != '')"
            )
        else:
            raise FlyqlError("path search for unsupported column type")

    if expression.key.transformers:
        col_ref = apply_transformer_sql(
            identifier, expression.key.transformers, "postgresql"
        )
        return f"({col_ref} IS NOT NULL AND {col_ref} != '')"

    if column.jsonstring:
        empty_obj = "'{}'::jsonb"
        return (
            f"({identifier} IS NOT NULL AND {identifier} != '' AND "
            f"CASE jsonb_typeof({identifier}::jsonb) "
            f"WHEN 'array' THEN jsonb_array_length({identifier}::jsonb) > 0 "
            f"WHEN 'object' THEN {identifier}::jsonb != {empty_obj} "
            f"ELSE false END)"
        )

    if column.normalized_type == NORMALIZED_TYPE_BOOL:
        return identifier
    elif column.normalized_type == NORMALIZED_TYPE_STRING:
        return f"({identifier} IS NOT NULL AND {identifier} != '')"
    elif column.normalized_type in (NORMALIZED_TYPE_INT, NORMALIZED_TYPE_FLOAT):
        return f"({identifier} IS NOT NULL AND {identifier} != 0)"
    elif column.normalized_type == NORMALIZED_TYPE_DATE:
        return f"({identifier} IS NOT NULL)"
    else:
        return f"({identifier} IS NOT NULL)"


def falsy_expression_to_sql_where(
    expression: Expression, columns: Mapping[str, Column]
) -> str:
    column_name = expression.key.segments[0]
    if column_name not in columns:
        raise FlyqlError(f"unknown column: {column_name}")

    column = columns[column_name]
    identifier = get_identifier(column)

    if expression.key.is_segmented:
        if column.is_jsonb or column.jsonstring:
            cast_identifier = (
                f"({identifier}::jsonb)" if column.jsonstring else identifier
            )
            json_path = expression.key.segments[1:]
            json_path_quoted = expression.key.quoted_segments[1:]
            for i, part in enumerate(json_path):
                validate_json_path_part(
                    part, json_path_quoted[i] if i < len(json_path_quoted) else False
                )
            path_expr = _build_jsonb_path(cast_identifier, json_path, json_path_quoted)
            if expression.key.transformers:
                path_expr = apply_transformer_sql(
                    path_expr, expression.key.transformers, "postgresql"
                )
            return f"({path_expr} IS NULL OR {path_expr} = '')"
        elif column.is_hstore:
            map_key = ".".join(expression.key.segments[1:])
            escaped_map_key = escape_param(map_key)
            leaf_expr = f"{identifier}->{escaped_map_key}"
            if expression.key.transformers:
                leaf_expr = apply_transformer_sql(
                    leaf_expr, expression.key.transformers, "postgresql"
                )
            return f"(NOT ({identifier} ? {escaped_map_key}) OR " f"{leaf_expr} = '')"
        elif column.is_array:
            array_index_str = ".".join(expression.key.segments[1:])
            try:
                array_index = int(array_index_str)
            except ValueError as err:
                raise FlyqlError(
                    f"invalid array index, expected number: {array_index_str}"
                ) from err
            pg_index = array_index + 1
            leaf_expr = f"{identifier}[{pg_index}]"
            if expression.key.transformers:
                leaf_expr = apply_transformer_sql(
                    leaf_expr, expression.key.transformers, "postgresql"
                )
            return (
                f"(array_length({identifier}, 1) < {pg_index} OR " f"{leaf_expr} = '')"
            )
        else:
            raise FlyqlError("path search for unsupported column type")

    if expression.key.transformers:
        col_ref = apply_transformer_sql(
            identifier, expression.key.transformers, "postgresql"
        )
        return f"({col_ref} IS NULL OR {col_ref} = '')"

    if column.jsonstring:
        empty_obj = "'{}'::jsonb"
        return (
            f"({identifier} IS NULL OR {identifier} = '' OR "
            f"CASE jsonb_typeof({identifier}::jsonb) "
            f"WHEN 'array' THEN jsonb_array_length({identifier}::jsonb) = 0 "
            f"WHEN 'object' THEN {identifier}::jsonb = {empty_obj} "
            f"ELSE true END)"
        )

    if column.normalized_type == NORMALIZED_TYPE_BOOL:
        return f"NOT {identifier}"
    elif column.normalized_type == NORMALIZED_TYPE_STRING:
        return f"({identifier} IS NULL OR {identifier} = '')"
    elif column.normalized_type in (NORMALIZED_TYPE_INT, NORMALIZED_TYPE_FLOAT):
        return f"({identifier} IS NULL OR {identifier} = 0)"
    elif column.normalized_type == NORMALIZED_TYPE_DATE:
        return f"({identifier} IS NULL)"
    else:
        return f"({identifier} IS NULL)"


def has_expression_to_sql_where(
    expression: Expression, columns: Mapping[str, Column]
) -> str:
    column_name = expression.key.segments[0]
    if column_name not in columns:
        raise FlyqlError(f"unknown column: {column_name}")

    column = columns[column_name]
    is_not_has = expression.operator == Operator.NOT_HAS.value
    identifier = get_identifier(column)
    rhs_ref = None
    if expression.value_type == ValueType.COLUMN:
        rhs_ref = _resolve_rhs_column_ref(str(expression.value), columns)
    value = rhs_ref if rhs_ref is not None else escape_param(expression.value)

    if expression.key.is_segmented:
        if column.is_jsonb or column.jsonstring:
            cast_identifier = (
                f"({identifier}::jsonb)" if column.jsonstring else identifier
            )
            json_path = expression.key.segments[1:]
            json_path_quoted = expression.key.quoted_segments[1:]
            for i, part in enumerate(json_path):
                validate_json_path_part(
                    part, json_path_quoted[i] if i < len(json_path_quoted) else False
                )
            path_expr = _build_jsonb_path(cast_identifier, json_path, json_path_quoted)
            if expression.key.transformers:
                path_expr = apply_transformer_sql(
                    path_expr, expression.key.transformers, "postgresql"
                )
            if is_not_has:
                return f"position({value} in {path_expr}) = 0"
            return f"position({value} in {path_expr}) > 0"
        elif column.is_hstore:
            map_key = ".".join(expression.key.segments[1:])
            escaped_map_key = escape_param(map_key)
            leaf_expr = f"{identifier}->{escaped_map_key}"
            if expression.key.transformers:
                leaf_expr = apply_transformer_sql(
                    leaf_expr, expression.key.transformers, "postgresql"
                )
            if is_not_has:
                return f"position({value} in {leaf_expr}) = 0"
            return f"position({value} in {leaf_expr}) > 0"
        elif column.is_array:
            array_index_str = ".".join(expression.key.segments[1:])
            try:
                array_index = int(array_index_str)
            except ValueError as err:
                raise FlyqlError(
                    f"invalid array index, expected number: {array_index_str}"
                ) from err
            pg_index = array_index + 1
            leaf_expr = f"{identifier}[{pg_index}]"
            if expression.key.transformers:
                leaf_expr = apply_transformer_sql(
                    leaf_expr, expression.key.transformers, "postgresql"
                )
            if is_not_has:
                return f"position({value} in {leaf_expr}) = 0"
            return f"position({value} in {leaf_expr}) > 0"
        else:
            raise FlyqlError("path search for unsupported column type")

    if expression.key.transformers:
        identifier = apply_transformer_sql(
            identifier, expression.key.transformers, "postgresql"
        )

    is_array_result = column.is_array
    out_type = get_transformer_output_type(expression.key.transformers)
    if out_type and out_type.value == "array":
        is_array_result = True

    if is_array_result:
        if is_not_has:
            return f"NOT ({value} = ANY({identifier}))"
        return f"{value} = ANY({identifier})"
    elif column.is_jsonb or column.jsonstring:
        cast_identifier = f"({identifier}::jsonb)" if column.jsonstring else identifier
        if is_not_has:
            return f"NOT ({cast_identifier} ? {value})"
        return f"{cast_identifier} ? {value}"
    elif column.is_hstore:
        if is_not_has:
            return f"NOT ({identifier} ? {value})"
        return f"{identifier} ? {value}"
    elif column.normalized_type == NORMALIZED_TYPE_STRING:
        if is_not_has:
            return f"({identifier} IS NULL OR position({value} in {identifier}) = 0)"
        return f"position({value} in {identifier}) > 0"
    else:
        raise FlyqlError(
            f"has operator is not supported for column type: {column.normalized_type}"
        )


def expression_to_sql_where(
    expression: Expression,
    columns: Mapping[str, Column],
    registry: Optional[TransformerRegistry] = None,
) -> str:
    if expression.operator == Operator.TRUTHY.value:
        return truthy_expression_to_sql_where(expression, columns)
    if expression.operator in (Operator.IN.value, Operator.NOT_IN.value):
        return in_expression_to_sql_where(expression, columns)
    if expression.operator in (Operator.HAS.value, Operator.NOT_HAS.value):
        return has_expression_to_sql_where(expression, columns)
    validate_operator(expression.operator)
    if expression.key.is_segmented:
        return expression_to_sql_segmented(expression, columns)
    return expression_to_sql_simple(expression, columns, registry=registry)


def _find_single_leaf_expression(node: Optional[Node]) -> Optional[Expression]:
    if node is None:
        return None
    if getattr(node, "negated", False):
        return None
    if node.expression is not None:
        return node.expression
    if node.left is not None and node.right is None:
        return _find_single_leaf_expression(node.left)
    if node.right is not None and node.left is None:
        return _find_single_leaf_expression(node.right)
    return None


def to_sql_where(
    root: Node,
    columns: Mapping[str, Column],
    registry: Optional[TransformerRegistry] = None,
) -> str:
    """Returns PostgreSQL WHERE clause for given tree and columns."""
    left = ""
    right = ""
    text = ""
    is_negated = getattr(root, "negated", False)

    if root.expression is not None:
        if is_negated and root.expression.operator == Operator.TRUTHY.value:
            text = falsy_expression_to_sql_where(
                expression=root.expression, columns=columns
            )
            is_negated = False
        else:
            text = expression_to_sql_where(
                expression=root.expression, columns=columns, registry=registry
            )
    elif (
        is_negated
        and root.expression is None
        and not (root.left is not None and root.right is not None)
    ):
        child = root.left if root.left is not None else root.right
        leaf_expr = _find_single_leaf_expression(child)
        if leaf_expr is not None and leaf_expr.operator == Operator.TRUTHY.value:
            return falsy_expression_to_sql_where(expression=leaf_expr, columns=columns)

    if root.left is not None:
        left = to_sql_where(root=root.left, columns=columns, registry=registry)

    if root.right is not None:
        right = to_sql_where(root=root.right, columns=columns, registry=registry)

    if len(left) > 0 and len(right) > 0:
        validate_bool_operator(root.bool_operator)
        sql_bool_op = BOOL_OP_TO_SQL[root.bool_operator]
        text = f"({left} {sql_bool_op} {right})"
    elif len(left) > 0:
        text = left
    elif len(right) > 0:
        text = right

    if is_negated and text:
        text = f"NOT ({text})"

    return text


# SELECT clause generation


@dataclass
class SelectColumn:
    key: Key
    alias: str
    column: Column
    sql_expr: str


@dataclass
class SelectResult:
    columns: List[SelectColumn] = field(default_factory=list)
    sql: str = ""


def _parse_raw_select_columns(text: str) -> List[Tuple[str, str]]:
    parts = text.split(",")
    result: List[Tuple[str, str]] = []
    for part in parts:
        part = part.strip()
        if not part:
            continue
        lower = part.lower()
        idx = lower.find(" as ")
        if idx >= 0:
            name = part[:idx].strip()
            alias = part[idx + 4 :].strip()
        else:
            name = part
            alias = ""
        if not name:
            raise FlyqlError("empty column name")
        result.append((name, alias))
    return result


def _resolve_column(
    key: Key, columns: Mapping[str, Column]
) -> Tuple[Column, List[str], List[bool]]:
    segments = key.segments
    for i in range(len(segments), 0, -1):
        candidate_key = ".".join(segments[:i])
        if candidate_key in columns:
            return columns[candidate_key], segments[i:], key.quoted_segments[i:]
    raise FlyqlError(f"unknown column: {key.raw}")


def _resolve_rhs_column_ref(value: str, columns: Mapping[str, Column]) -> Optional[str]:
    try:
        key = parse_key(value)
    except Exception:
        return None
    try:
        column, path, path_quoted = _resolve_column(key, columns)
    except FlyqlError:
        return None
    return _build_select_expr(get_identifier(column), column, path, path_quoted)


def _build_select_expr(
    identifier: str, column: Column, path: List[str], path_quoted: List[bool]
) -> str:
    if not path:
        return identifier

    if column.is_jsonb or column.jsonstring:
        cast_identifier = f"({identifier}::jsonb)" if column.jsonstring else identifier
        for i, part in enumerate(path):
            validate_json_path_part(
                part, path_quoted[i] if i < len(path_quoted) else False
            )
        return _build_jsonb_path_raw(cast_identifier, path, path_quoted)

    if column.is_hstore:
        map_key = ".".join(path)
        escaped_key = escape_param(map_key)
        return f"{identifier}->{escaped_key}"

    if column.is_array:
        index_str = ".".join(path)
        try:
            index = int(index_str)
        except ValueError as err:
            raise FlyqlError(
                f"invalid array index, expected number: {index_str}"
            ) from err
        return f"{identifier}[{index + 1}]"

    raise FlyqlError(f"path access on non-composite column type: {column.name}")


def to_sql_select(
    text: str,
    columns: Mapping[str, Column],
    registry: Optional[TransformerRegistry] = None,
) -> SelectResult:
    """Generate a PostgreSQL SELECT clause from a column expression string."""
    raws = _parse_raw_select_columns(text)
    select_columns: List[SelectColumn] = []
    exprs: List[str] = []

    for name, alias in raws:
        key = parse_key(name)
        column, path, path_quoted = _resolve_column(key, columns)

        identifier = get_identifier(column)
        sql_expr = _build_select_expr(identifier, column, path, path_quoted)
        if key.transformers:
            validate_transformer_chain(key.transformers, registry=registry)
            if path and (column.is_jsonb or column.jsonstring):
                sql_expr = f"({sql_expr})::text"
            sql_expr = apply_transformer_sql(
                sql_expr, key.transformers, "postgresql", registry=registry
            )

        if alias:
            sql_expr = f"{sql_expr} AS {escape_identifier(alias)}"
        elif path:
            alias = key.raw.split("|")[0]
            sql_expr = f"{sql_expr} AS {escape_identifier(alias)}"

        select_columns.append(
            SelectColumn(key=key, alias=alias, column=column, sql_expr=sql_expr)
        )
        exprs.append(sql_expr)

    return SelectResult(columns=select_columns, sql=", ".join(exprs))
