"""Tests for ``claw_forge.agent.sandbox`` — Level 2 OS-level filesystem
jail (v0.8.18).  Most assertions exercise the macOS sandbox-exec path
since that's what v0.8.18 ships; Linux bwrap lands in a follow-up.

These tests skip on platforms where the sandbox isn't available so
the suite still passes on Linux CI runners (which can't validate
macOS sandbox semantics) and on Windows.
"""
from __future__ import annotations

import os
import platform
import shutil
import subprocess
from pathlib import Path

import pytest

from claw_forge.agent.sandbox import (
    _macos_sandbox_profile,
    is_sandbox_available,
    make_sandbox_wrapper,
    write_macos_sandbox_wrapper,
)

_NEEDS_MACOS = pytest.mark.skipif(
    platform.system() != "Darwin",
    reason="macOS sandbox-exec required",
)
_NEEDS_SANDBOX_BIN = pytest.mark.skipif(
    shutil.which("sandbox-exec") is None,
    reason="sandbox-exec not on PATH",
)


class TestIsSandboxAvailable:
    def test_returns_tuple(self) -> None:
        """Always returns ``(bool, str_mechanism)`` regardless of OS so
        callers can branch on availability AND log the mechanism name."""
        available, mechanism = is_sandbox_available()
        assert isinstance(available, bool)
        assert mechanism in ("sandbox-exec", "bwrap", "none")

    @_NEEDS_MACOS
    def test_macos_reports_sandbox_exec(self) -> None:
        """On macOS, mechanism must be ``sandbox-exec``."""
        _, mechanism = is_sandbox_available()
        assert mechanism == "sandbox-exec"


class TestMacosSandboxProfile:
    """Profile-string contract — covers the canonical-path landmine
    that silently no-ops the deny rule (the bug we hit during impl)."""

    def test_profile_contains_default_allow(self, tmp_path: Path) -> None:
        """Default-allow + targeted deny model — needed to keep the
        agent's normal operations (stdout, network, /tmp scratch)
        working without enumerating every permission."""
        worktree = tmp_path / "wt"
        profile = _macos_sandbox_profile(
            project_canonical=tmp_path.resolve(),
            worktree_canonical=worktree.resolve(),
        )
        assert "(allow default)" in profile

    def test_profile_denies_project_path(self, tmp_path: Path) -> None:
        """Resolved project path appears in the deny rule.  This is
        the canonical path; symlink paths silently don't match the
        kernel's canonicalised view."""
        worktree = tmp_path / "wt"
        profile = _macos_sandbox_profile(
            project_canonical=tmp_path.resolve(),
            worktree_canonical=worktree.resolve(),
        )
        assert f'(deny file-write* (subpath "{tmp_path.resolve()}"))' in profile

    def test_profile_carves_out_worktree(self, tmp_path: Path) -> None:
        """Worktree allow rule comes after the project deny so writes
        under the worktree still work despite the deny.  Last rule wins
        in sandbox-exec; ordering is part of the contract."""
        worktree = tmp_path / "wt"
        profile = _macos_sandbox_profile(
            project_canonical=tmp_path.resolve(),
            worktree_canonical=worktree.resolve(),
        )
        deny_idx = profile.find("(deny file-write*")
        allow_idx = profile.find("(allow file-write*")
        assert deny_idx > -1 and allow_idx > -1
        assert allow_idx > deny_idx, (
            "worktree allow must come AFTER project deny "
            "so it wins via last-rule-wins"
        )


@_NEEDS_MACOS
@_NEEDS_SANDBOX_BIN
class TestWriteMacosSandboxWrapper:
    """End-to-end: build a wrapper, exec a write command through it,
    verify the kernel actually denies the write outside the worktree
    and allows it inside.  These tests fail loudly if Apple ever
    changes sandbox-exec semantics in a way that breaks our profile."""

    @pytest.fixture
    def setup(self, tmp_path: Path) -> tuple[Path, Path, Path]:
        """Return ``(project, worktree, wrapper_path)``."""
        project = tmp_path / "proj"
        worktree = project / ".claw-forge" / "worktrees" / "feat"
        worktree.mkdir(parents=True)
        # Use /bin/sh as the "claude" stand-in — we just want to
        # exec a command and verify the sandbox kicks in.  The real
        # claude binary isn't needed for these assertions.
        wrapper = write_macos_sandbox_wrapper(
            project_path=project,
            worktree_path=worktree,
            output_dir=worktree / ".claw-forge" / "sandbox",
            claude_path=Path("/bin/sh"),
        )
        return project, worktree, wrapper

    def test_wrapper_is_executable(
        self, setup: tuple[Path, Path, Path],
    ) -> None:
        _, _, wrapper = setup
        assert wrapper.exists()
        assert os.access(wrapper, os.X_OK)

    def test_profile_written_alongside_wrapper(
        self, setup: tuple[Path, Path, Path],
    ) -> None:
        _, _, wrapper = setup
        profile = wrapper.parent / "sandbox.sb"
        assert profile.exists()
        content = profile.read_text()
        assert "(version 1)" in content

    def test_wrapper_denies_write_to_project_root(
        self, setup: tuple[Path, Path, Path],
    ) -> None:
        """The leak we're preventing: a write to the project root that
        bypasses every static check (Bash/exempt-command/tool sandbox).
        With Level 2 the kernel itself denies it."""
        project, _, wrapper = setup
        target = project / "leaked.txt"
        result = subprocess.run(
            [str(wrapper), "-c", f'touch "{target}" 2>&1; echo exit=$?'],
            capture_output=True, text=True, timeout=10,
        )
        # The touch's exit code should be non-zero AND the file must
        # not exist.  Note: ``echo`` after touch always succeeds, so
        # we check the captured ``exit=N`` line.
        assert "Operation not permitted" in result.stdout
        assert "exit=1" in result.stdout
        assert not target.exists()

    def test_wrapper_allows_write_inside_worktree(
        self, setup: tuple[Path, Path, Path],
    ) -> None:
        """Carve-out: writes under the worktree path go through
        normally — the agent's intended work lands where it should."""
        _, worktree, wrapper = setup
        target = worktree / "in_worktree.txt"
        result = subprocess.run(
            [str(wrapper), "-c", f'touch "{target}"; echo exit=$?'],
            capture_output=True, text=True, timeout=10,
        )
        assert "exit=0" in result.stdout
        assert target.exists()

    def test_wrapper_denies_via_python(
        self, setup: tuple[Path, Path, Path],
    ) -> None:
        """The escape pattern Layer 1–3 can't statically catch:
        ``python -c "open('/abs', 'w')…"``.  The sandbox sees the
        ``open(2)`` syscall regardless of how the Python literal was
        constructed and denies it."""
        project, _, wrapper = setup
        target = project / "via_python.txt"
        # Use shell to invoke python — same way Claude's Bash tool
        # would.  The agent could embed any literal here.
        cmd = (
            f'/usr/bin/python3 -c "'
            f"open(r'{target}', 'w').write('leak')"
            f'" 2>&1; echo exit=$?'
        )
        result = subprocess.run(
            [str(wrapper), "-c", cmd],
            capture_output=True, text=True, timeout=10,
        )
        assert "exit=1" in result.stdout
        assert not target.exists()


class TestMakeSandboxWrapperFallback:
    """``make_sandbox_wrapper`` returns ``None`` when no sandbox is
    available so the dispatcher can degrade to the behavioural-only
    stack without raising."""

    def test_returns_none_when_claude_not_on_path(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """If ``claude`` isn't installed (API-only mode, fresh CI),
        we can't wrap it — fall back to bare cli_path."""
        # Make ``shutil.which`` return None for "claude".
        real_which = shutil.which

        def fake_which(name: str, *args: object, **kwargs: object) -> str | None:
            if name == "claude":
                return None
            return real_which(name)

        monkeypatch.setattr("claw_forge.agent.sandbox.shutil.which", fake_which)
        result = make_sandbox_wrapper(
            project_path=tmp_path,
            worktree_path=tmp_path / "wt",
            output_dir=tmp_path / "out",
        )
        assert result is None

    def test_returns_none_on_unsupported_os(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """On Windows / BSD / anything that isn't macOS or Linux,
        no sandbox available — fall back."""
        monkeypatch.setattr(
            "claw_forge.agent.sandbox.platform.system",
            lambda: "Windows",
        )
        result = make_sandbox_wrapper(
            project_path=tmp_path,
            worktree_path=tmp_path / "wt",
            output_dir=tmp_path / "out",
        )
        assert result is None
