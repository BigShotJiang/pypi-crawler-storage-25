"""OS-level filesystem jail per agent process (v0.8.18 Level 2).

The architectural step beyond v0.8.17's snapshot-rollback.  v0.8.17
*detects and recovers* from leaks; this module makes leaks
*physically impossible* by wrapping the agent's ``claude`` CLI
subprocess in a kernel-enforced sandbox where writes outside the
worktree return ``EACCES``.

Why this matters: the v0.8.16 layers (file-tool sandbox, exempt-
command jail check, system-prompt directive) each block one
escape pattern.  v0.8.17 captures the leftovers.  None of them stop
a determined or dynamically-built escape (``python -c "open('/abs',
'w')…"``, ``os.system('git -C /...')``, FFI through ctypes).  The
OS sandbox closes that gap at the syscall level — no user-space
guess-the-pattern logic is needed because the kernel itself denies
the write.

## OS support

  * **macOS**: ``sandbox-exec(1)`` with a generated profile that
    denies ``file-write*`` to the parent project's canonical path,
    with a carve-out allowing writes under the worktree.  The
    canonical-path resolution is critical — ``/tmp`` is a symlink to
    ``/private/tmp`` and the sandbox kernel hook compares against
    the resolved path; using the symlink path silently makes the
    deny rule non-matching.

  * **Linux**: ``bwrap(1)`` (bubblewrap) with ``--ro-bind`` on the
    parent project and ``--bind`` on the worktree.  Same effect:
    writes outside the worktree fail at ``open(2)``.  *Implemented
    in a follow-up — v0.8.18 ships macOS-only.*

  * **Other platforms** (Windows, BSD): no sandbox available.  The
    dispatcher logs at ``warning`` level and falls back to the
    behavioural-only stack (Layers 1–3 + snapshot-rollback).  The
    user-visible promise downgrades from "leaks impossible" to
    "leaks contained, work preserved in stash".

## Usage

The dispatcher generates a per-task wrapper script in the worktree's
``.claw-forge/`` dir, points ``ClaudeAgentOptions.cli_path`` at it,
and the SDK invokes the wrapper instead of the bare ``claude``
binary.  The wrapper sets up the sandbox and ``exec``s the real
``claude`` with the SDK's args intact.
"""
from __future__ import annotations

import logging
import platform
import shutil
import stat
from pathlib import Path

_log = logging.getLogger(__name__)


def is_sandbox_available() -> tuple[bool, str]:
    """Return ``(available, mechanism)``.

    ``mechanism`` is ``"sandbox-exec"`` on macOS when the binary is
    on PATH, ``"bwrap"`` on Linux when bubblewrap is installed, or
    ``"none"`` when no sandbox is available on this OS.  The
    dispatcher uses the mechanism string for log/warning output so
    operators know which OS path is in effect.
    """
    system = platform.system()
    if system == "Darwin":
        return (shutil.which("sandbox-exec") is not None, "sandbox-exec")
    if system == "Linux":
        return (shutil.which("bwrap") is not None, "bwrap")
    return (False, "none")


def _macos_sandbox_profile(
    *, project_canonical: Path, worktree_canonical: Path,
) -> str:
    """Generate a macOS sandbox-exec profile.

    The profile is **default-allow** (``(allow default)``) with a
    targeted ``deny file-write*`` against the parent project, and
    a carve-out ``allow file-write*`` for the worktree subtree
    (since the worktree is at ``<project>/.claw-forge/worktrees/<slug>``,
    the deny would otherwise also block legitimate worktree writes).

    Both paths MUST be canonical (``Path.resolve()``).  macOS
    sandbox compares against canonicalised paths internally — a
    profile referencing ``/tmp/foo`` silently doesn't match writes
    to ``/private/tmp/foo`` (which the kernel sees), and the deny
    rule becomes a no-op without any error.

    Path values are interpolated as scheme strings; we don't escape
    embedded quotes because filesystem paths shouldn't contain ``"``.
    If they do, the profile is malformed and ``sandbox-exec`` fails
    fast at startup — the dispatcher catches the failure and falls
    back to non-sandboxed mode with a logged warning.
    """
    return (
        "(version 1)\n"
        "(allow default)\n"
        f'(deny file-write* (subpath "{project_canonical}"))\n'
        f'(allow file-write* (subpath "{worktree_canonical}"))\n'
    )


def write_macos_sandbox_wrapper(
    *,
    project_path: Path,
    worktree_path: Path,
    output_dir: Path,
    claude_path: Path,
) -> Path:
    """Write a sandbox-exec wrapper script + profile to *output_dir*.

    Returns the absolute path to the wrapper script, suitable for
    ``ClaudeAgentOptions.cli_path``.  The SDK invokes the wrapper
    with claude's CLI args; the wrapper exec's the real ``claude``
    binary under the sandbox-exec'd profile so the agent's tool
    invocations (Bash, Write, subprocess via FFI) all inherit the
    jail.

    The profile + wrapper are written into ``output_dir`` (typically
    ``<worktree>/.claw-forge/sandbox/``) so they're scoped to the
    task's lifetime and cleaned up when the worktree is removed.
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    profile_path = output_dir / "sandbox.sb"
    profile_path.write_text(
        _macos_sandbox_profile(
            project_canonical=project_path.resolve(),
            worktree_canonical=worktree_path.resolve(),
        ),
    )

    # ``exec`` so the wrapper doesn't sit as a parent process
    # consuming a PID slot — the SDK's process tree is shallower this
    # way and signals from the dispatcher reach the real claude
    # process directly.
    wrapper_path = output_dir / "claude_sandboxed"
    wrapper_path.write_text(
        '#!/bin/bash\n'
        f'exec /usr/bin/sandbox-exec -f "{profile_path}" '
        f'"{claude_path}" "$@"\n'
    )
    # Make executable for owner + group + others (the SDK might run
    # as a different effective user than the wrapper-writer in some
    # CI/container setups).
    wrapper_path.chmod(
        wrapper_path.stat().st_mode
        | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH,
    )
    return wrapper_path


def make_sandbox_wrapper(
    *,
    project_path: Path,
    worktree_path: Path,
    output_dir: Path,
) -> Path | None:
    """High-level entrypoint: build a sandbox wrapper for the current
    OS, or return ``None`` when no sandbox is available.

    The dispatcher calls this once per task right before constructing
    ``ClaudeAgentOptions``.  When ``None`` is returned, the dispatcher
    sets ``cli_path`` to its default (the bare ``claude`` binary) and
    relies on the v0.8.16 + v0.8.17 behavioural layers — leak
    prevention degrades to "contained + recovered", not "impossible".
    """
    available, mechanism = is_sandbox_available()
    if not available:
        _log.debug(
            "sandbox: no OS-level sandbox available (mechanism=%s); "
            "falling back to behavioural layers", mechanism,
        )
        return None
    claude_path = shutil.which("claude")
    if claude_path is None:
        _log.warning(
            "sandbox: ``claude`` CLI not on PATH — cannot wrap; "
            "falling back to behavioural layers",
        )
        return None

    if mechanism == "sandbox-exec":
        return write_macos_sandbox_wrapper(
            project_path=project_path,
            worktree_path=worktree_path,
            output_dir=output_dir,
            claude_path=Path(claude_path),
        )
    # Linux bwrap path lands in a follow-up release.
    _log.warning(
        "sandbox: %s not yet implemented in v0.8.18 — falling back",
        mechanism,
    )
    return None
