from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_serializer

from labels.model.package import Package


class SbomDetails(BaseModel):
    name: str | None
    version: str | None
    timestamp: str | None
    tool: str | None
    organization: str | None


class SbomRelationship(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    from_: str = Field(alias="from")
    to: list[str]
    type: str


class FluidSBOM(BaseModel):
    sbom_details: SbomDetails
    packages: list[Package]
    relationships: list[SbomRelationship]

    @field_serializer("packages")  # type: ignore[misc]
    def _serialize_packages(self, packages: list[Package]) -> list[dict[str, Any]]:  # type: ignore[explicit-any, misc]
        return [pkg.serialize() for pkg in packages]  # type: ignore[misc]
