from io import TextIOWrapper

from labels.model.file import DependencyType, Location, LocationReadCloser, Scope


def new_location(real_path: str) -> Location:
    return Location(
        access_path=real_path,
        real_path=real_path,
    )


def new_default_location_from_path(real_path: str, line: int | None = None) -> Location:
    return Location(
        access_path=real_path,
        real_path=real_path,
        line=line,
        scope=Scope.UNDETERMINABLE,
        dependency_type=DependencyType.UNDETERMINABLE,
        reachable_cves=[],
    )


def new_default_location_read_closer(
    str_path: str, read_closer: TextIOWrapper
) -> LocationReadCloser:
    location = new_default_location_from_path(str_path)
    return LocationReadCloser(location=location, read_closer=read_closer)
