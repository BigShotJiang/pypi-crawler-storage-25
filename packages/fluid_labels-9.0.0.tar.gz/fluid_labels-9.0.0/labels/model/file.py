import hashlib
from enum import StrEnum
from io import TextIOWrapper
from typing import TextIO

from pydantic import BaseModel, ConfigDict, Field, field_serializer

from labels.model.package_manager import PackageManager


class DependencyType(StrEnum):
    DIRECT = "DIRECT"
    TRANSITIVE = "TRANSITIVE"
    ROOT = "ROOT"
    UNDETERMINABLE = "UNDETERMINABLE"


class Scope(StrEnum):
    BUILD = "BUILD"
    RUN = "RUN"
    UNDETERMINABLE = "UNDETERMINABLE"


class DependencyChain(BaseModel):
    depth: int
    chain: list[str]


class Location(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    scope: Scope = Scope.UNDETERMINABLE
    real_path: str | None = Field(None, exclude=True)
    line: int | None = None
    layer: str | None = None
    access_path: str | None = Field(None, alias="path")
    dependency_type: DependencyType = DependencyType.UNDETERMINABLE
    reachable_cves: list[str] = []
    top_parents: list[str] | None = None
    dependency_chains: list[DependencyChain] | None = None
    package_manager: PackageManager = PackageManager.UNKNOWN

    def path(self) -> str:
        path = self.access_path or self.real_path
        if not path:
            error_msg = "Both access_path and real_path are empty"
            raise ValueError(error_msg)
        return path

    def location_id(self) -> str:
        path = self.path()
        line = self.line or 0
        location_str = f"{path}:{line}"
        return hashlib.sha256(location_str.encode()).hexdigest()[:16]

    @field_serializer("access_path")
    def _serialize_path(self, _value: str | None) -> str | None:
        return self.access_path or self.real_path

    @field_serializer("layer")
    def _serialize_layer(self, _value: str | None) -> str | None:
        return self.layer or None


class LocationReadCloser(BaseModel):
    location: Location
    read_closer: TextIO | TextIOWrapper
    model_config = ConfigDict(arbitrary_types_allowed=True)
