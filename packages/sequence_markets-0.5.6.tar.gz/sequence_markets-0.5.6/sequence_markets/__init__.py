"""Sequence Markets Python SDK — the trading OS client.

Usage:
    from sequence_markets import Sequence

    seq = Sequence("seq_live_...")

    # Level 1: See
    quote = seq.quote("ETH-USD")
    print(f"ETH mid: {quote['nbbo']['mid']}")

    # Level 2: Trade
    order = seq.buy("ETH-USD", 50, urgency="medium")

    # Level 3: Orchestrate
    graph = seq.graph([
        seq.node("spot", "ETH-USD", "buy", 200),
        seq.node("hedge", "ETH-USD-PERP", "sell", 200, venue="hyperliquid"),
    ], edges=[
        seq.edge("spot", "hedge", trigger="fill_pct", value=0.5),
    ])
"""

from .client import Sequence, SequenceError

__all__ = ["Sequence", "SequenceError"]

# Hardcoded so the auto-vendored copy (dropped into hosted-strategy tarballs,
# not pip-installed) reports a real version. importlib.metadata.version()
# would raise PackageNotFoundError there since no METADATA is shipped, and
# falling back to "0.0.0+unknown" made SDK-version mismatches impossible to
# diagnose. Bump in lockstep with pyproject.toml on every release.
__version__ = "0.5.6"
