# Publishing `vwp-sdk` to PyPI

The `pypi-token` secret in `vwp-keyvault` is the publish credential.

```powershell
# From C:\Claude\VWP\vwp-sdk-python
.\.venv\Scripts\Activate.ps1
pip install --quiet build twine
python -m build --sdist --wheel --outdir dist
$token = az keyvault secret show --vault-name vwp-keyvault --name pypi-token --query value -o tsv
twine upload --non-interactive -u __token__ -p $token dist/*
```

Verify from a fresh venv on a different working directory:

```powershell
python -m venv C:\tmp\verify-vwp-sdk
C:\tmp\verify-vwp-sdk\Scripts\python.exe -m pip install vwp-sdk
C:\tmp\verify-vwp-sdk\Scripts\python.exe -c "import vwp; print(vwp.__version__)"
```

After the first publish, narrow the token scope from account-wide to project-scoped:
1. <https://pypi.org/manage/account/token/> -> revoke the broad token
2. Create a new token scoped to `vwp-sdk` only
3. `az keyvault secret set --vault-name vwp-keyvault --name pypi-token --value <new>`
