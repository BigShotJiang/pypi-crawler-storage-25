"""Magic-link SDK behaviors (mocked HTTP)."""

from __future__ import annotations

import json as _json

import pytest
from pytest_httpx import HTTPXMock

import vwp


BASE = "https://api.vibewithprimitiveai.com/v1"


def test_request_success(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        method="POST",
        url=f"{BASE}/auth/magic-link/request",
        json={
            "requestId": "req_01HV0000000000000000000000",
            "email": "user@example.com",
            "expiresAt": "2026-05-11T22:33:00Z",
            "deliveryStatus": "queued",
        },
    )
    client = vwp.Client(api_key="vwp_test_abc")
    r = client.auth.magic_link.request(
        email="user@example.com",
        return_to="https://example.com/dashboard",
    )
    assert r.request_id.startswith("req_")
    assert r.email == "user@example.com"
    assert r.delivery_status == "queued"


def test_request_payload_shape(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        method="POST",
        url=f"{BASE}/auth/magic-link/request",
        json={
            "requestId": "req_x",
            "email": "u@e.com",
            "expiresAt": "2026-05-11T22:33:00Z",
            "deliveryStatus": "queued",
        },
    )
    client = vwp.Client(api_key="vwp_test_abc")
    client.auth.magic_link.request(
        email="u@e.com",
        return_to="https://e.com/dash",
        metadata={"source": "homepage"},
        tenant_id="acme",
    )
    sent = httpx_mock.get_request()
    body = _json.loads(sent.content)
    assert body == {
        "email": "u@e.com",
        "returnTo": "https://e.com/dash",
        "metadata": {"source": "homepage"},
        "tenantId": "acme",
    }


def test_exchange_success(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        method="POST",
        url=f"{BASE}/auth/magic-link/exchange",
        json={
            "session": {
                "id": "sess_abc",
                "userId": "usr_xyz",
                "email": "user@example.com",
                "tenantId": None,
                "createdAt": "2026-05-11T22:33:00Z",
                "expiresAt": "2026-05-18T22:33:00Z",
                "metadata": {},
            },
            "jwt": "eyJhbGciOiJIUzI1NiJ9.test.signature",
            "refreshToken": "rfr_def",
            "returnTo": "https://example.com/dashboard",
        },
    )
    client = vwp.Client(api_key="vwp_test_abc")
    r = client.auth.magic_link.exchange(handle="abc123")
    assert r.session.user_id == "usr_xyz"
    assert r.session.email == "user@example.com"
    assert r.jwt.startswith("eyJ")
    assert r.refresh_token == "rfr_def"
    assert r.return_to == "https://example.com/dashboard"


def test_exchange_from_url_string(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        method="POST",
        url=f"{BASE}/auth/magic-link/exchange",
        json={
            "session": {
                "id": "sess_a", "userId": "usr_a", "email": "u@e.com",
                "tenantId": None, "createdAt": "x", "expiresAt": "y", "metadata": {},
            },
            "jwt": "j", "refreshToken": "rfr_a", "returnTo": "https://example.com/dashboard",
        },
    )
    client = vwp.Client(api_key="vwp_test_abc")
    url = "https://example.com/auth/magic-link/callback?_vwp_h=xyz789&other=ignored"
    r = client.auth.magic_link.exchange(url)
    assert r.session.user_id == "usr_a"
    sent = httpx_mock.get_request()
    body = _json.loads(sent.content)
    assert body == {"handle": "xyz789"}


def test_exchange_from_request_dict(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        method="POST",
        url=f"{BASE}/auth/magic-link/exchange",
        json={
            "session": {
                "id": "s", "userId": "u", "email": "e@e.com",
                "tenantId": None, "createdAt": "x", "expiresAt": "y", "metadata": {},
            },
            "jwt": "j", "refreshToken": "rfr_q", "returnTo": "https://e.com/d",
        },
    )
    client = vwp.Client(api_key="vwp_test_abc")
    fake_req = {"url": "https://e.com/auth/magic-link/callback?_vwp_h=fromdict"}
    r = client.auth.magic_link.exchange(fake_req)
    assert r.refresh_token == "rfr_q"
    sent = httpx_mock.get_request()
    assert _json.loads(sent.content)["handle"] == "fromdict"


def test_exchange_token_invalid(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        method="POST",
        url=f"{BASE}/auth/magic-link/exchange",
        status_code=401,
        json={
            "error": "token_invalid",
            "message": "Magic link is no longer valid. Issue a new one.",
            "reason": "expired",
            "requestId": "req_x",
        },
    )
    client = vwp.Client(api_key="vwp_test_abc")
    with pytest.raises(vwp.ApiKeyError) as e:
        client.auth.magic_link.exchange(handle="expired")
    assert e.value.status_code == 401
    assert e.value.body and e.value.body.get("reason") == "expired"


def test_exchange_missing_handle_raises():
    client = vwp.Client(api_key="vwp_test_abc")
    with pytest.raises(ValueError):
        client.auth.magic_link.exchange("https://example.com/no-handle-here")


def test_module_surface_has_auth():
    assert hasattr(vwp.auth, "request_magic_link")
    assert hasattr(vwp.auth, "exchange_magic_link")
    # Stubs we deliberately replaced earlier:
    assert callable(vwp.auth.request_magic_link)
    assert callable(vwp.auth.exchange_magic_link)
