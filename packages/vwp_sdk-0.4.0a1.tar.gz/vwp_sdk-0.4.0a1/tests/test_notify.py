"""vwp.notify.email.send tests."""

from __future__ import annotations

import json as _json

import pytest
from pytest_httpx import HTTPXMock

import vwp


BASE = "https://api.vibewithprimitiveai.com/v1"


def test_send_with_html(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        method="POST",
        url=f"{BASE}/notify/email/send",
        json={
            "messageId": "inmem-1",
            "status": "queued",
            "requestId": "req_x",
            "to": ["u@e.com"],
        },
    )
    client = vwp.Client(api_key="vwp_test_abc")
    r = client.notify.email.send(to="u@e.com", subject="Hi", html="<p>Welcome</p>")
    assert r.status == "queued"
    assert r.to == ["u@e.com"]
    assert r.message_id == "inmem-1"


def test_send_payload_shape(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        method="POST",
        url=f"{BASE}/notify/email/send",
        json={"messageId": "x", "status": "queued", "requestId": "r", "to": ["a@e.com", "b@e.com"]},
    )
    client = vwp.Client(api_key="vwp_test_abc")
    client.notify.email.send(
        to=["a@e.com", "b@e.com"],
        subject="Hello",
        text="Plain body",
        reply_to="support@e.com",
        metadata={"campaign": "summer"},
    )
    sent = httpx_mock.get_request()
    body = _json.loads(sent.content)
    assert body == {
        "to": ["a@e.com", "b@e.com"],
        "subject": "Hello",
        "text": "Plain body",
        "replyTo": "support@e.com",
        "metadata": {"campaign": "summer"},
    }


def test_send_requires_body(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        method="POST",
        url=f"{BASE}/notify/email/send",
        status_code=400,
        json={"error": "invalid_input", "field": "body", "message": "Either html or text required", "requestId": "r"},
    )
    client = vwp.Client(api_key="vwp_test_abc")
    with pytest.raises(vwp.BadRequestError):
        client.notify.email.send(to="u@e.com", subject="Empty")


def test_module_level_send(httpx_mock: HTTPXMock, monkeypatch):
    monkeypatch.setenv("VWP_API_KEY", "vwp_test_env")
    httpx_mock.add_response(
        method="POST",
        url=f"{BASE}/notify/email/send",
        json={"messageId": "x", "status": "queued", "requestId": "r", "to": ["u@e.com"]},
    )
    r = vwp.notify.send_email(to="u@e.com", subject="S", text="T")
    assert r.status == "queued"


def test_sms_stub_still_raises():
    with pytest.raises(NotImplementedError):
        vwp.notify.send_sms()
