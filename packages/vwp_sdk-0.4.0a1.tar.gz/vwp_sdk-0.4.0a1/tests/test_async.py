"""Async client smoke test."""

from __future__ import annotations

import pytest
from pytest_httpx import HTTPXMock

import vwp


BASE = "https://api.vibewithprimitiveai.com/v1"


@pytest.mark.asyncio
async def test_async_allowed(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        method="POST",
        url=f"{BASE}/security/rate-limit/check",
        json={
            "allowed": True,
            "remaining": 4,
            "limit": 5,
            "resetAt": "2026-05-11T16:00:00Z",
            "key": "k",
            "requestId": "req_async",
        },
    )
    async with vwp.AsyncClient(api_key="vwp_test_x") as client:
        result = await client.rate_limit.check(key="k", limit=5, window="1m")
    assert result.allowed
    assert result.request_id == "req_async"
