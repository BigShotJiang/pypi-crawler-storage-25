"""vwp.auth.session — create / verify / refresh."""

from __future__ import annotations

import json as _json

import pytest
from pytest_httpx import HTTPXMock

import vwp


BASE = "https://api.vibewithprimitiveai.com/v1"


def _session_body():
    return {
        "session": {
            "id": "sess_a",
            "userId": "usr_a",
            "email": "u@e.com",
            "tenantId": None,
            "createdAt": "2026-05-11T22:33:00Z",
            "expiresAt": "2026-05-18T22:33:00Z",
            "metadata": {},
        },
        "jwt": "eyJhbGciOiJIUzI1NiJ9.test.signature",
        "refreshToken": "rfr_a",
    }


def test_create_session(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        method="POST",
        url=f"{BASE}/auth/session/create",
        json=_session_body(),
    )
    client = vwp.Client(api_key="vwp_test_abc")
    r = client.auth.session.create(email="u@e.com", metadata={"src": "test"}, tenant_id="acme")
    assert r.session.user_id == "usr_a"
    assert r.refresh_token == "rfr_a"
    sent = httpx_mock.get_request()
    assert _json.loads(sent.content) == {
        "email": "u@e.com",
        "metadata": {"src": "test"},
        "tenantId": "acme",
    }


def test_create_session_with_custom_ttl(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        method="POST",
        url=f"{BASE}/auth/session/create",
        json=_session_body(),
    )
    client = vwp.Client(api_key="vwp_test_abc")
    client.auth.session.create(email="u@e.com", ttl_seconds=3600)
    body = _json.loads(httpx_mock.get_request().content)
    assert body["ttlSeconds"] == 3600


def test_verify_valid(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        method="POST",
        url=f"{BASE}/auth/session/verify",
        json={
            "valid": True,
            "session": _session_body()["session"],
            "reason": "valid",
        },
    )
    client = vwp.Client(api_key="vwp_test_abc")
    r = client.auth.session.verify("some.jwt.value")
    assert r.valid is True
    assert r.reason == "valid"
    assert r.session and r.session.user_id == "usr_a"


def test_verify_expired(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        method="POST",
        url=f"{BASE}/auth/session/verify",
        json={"valid": False, "reason": "expired", "session": None},
    )
    client = vwp.Client(api_key="vwp_test_abc")
    r = client.auth.session.verify("expired.jwt.value")
    assert r.valid is False
    assert r.reason == "expired"
    assert r.session is None


def test_refresh_success(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        method="POST",
        url=f"{BASE}/auth/session/refresh",
        json={
            "session": _session_body()["session"],
            "jwt": "new.jwt.here",
            "refreshToken": "rfr_new",
        },
    )
    client = vwp.Client(api_key="vwp_test_abc")
    r = client.auth.session.refresh("rfr_old")
    assert r.refresh_token == "rfr_new"
    assert r.jwt == "new.jwt.here"


def test_refresh_replayed(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        method="POST",
        url=f"{BASE}/auth/session/refresh",
        status_code=401,
        json={
            "error": "token_invalid",
            "reason": "replayed",
            "message": "already used",
            "requestId": "req_x",
        },
    )
    client = vwp.Client(api_key="vwp_test_abc")
    with pytest.raises(vwp.ApiKeyError) as e:
        client.auth.session.refresh("rfr_used")
    assert (e.value.body or {}).get("reason") == "replayed"
