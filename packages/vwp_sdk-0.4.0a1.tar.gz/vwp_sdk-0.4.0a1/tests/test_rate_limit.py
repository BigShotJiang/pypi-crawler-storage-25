"""Rate-limit SDK behavior using pytest-httpx for mocked HTTP."""

from __future__ import annotations

import pytest
from pytest_httpx import HTTPXMock

import vwp


BASE = "https://api.vibewithprimitiveai.com/v1"


def test_allowed(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        method="POST",
        url=f"{BASE}/security/rate-limit/check",
        json={
            "allowed": True,
            "remaining": 4,
            "limit": 5,
            "resetAt": "2026-05-11T16:00:00Z",
            "key": "login:user@example.com",
            "requestId": "req_01HV0000000000000000000000",
        },
    )
    client = vwp.Client(api_key="vwp_test_abc")
    result = client.rate_limit.check(key="login:user@example.com", limit=5, window="15m")
    assert result.allowed is True
    assert result.remaining == 4
    assert result.limit == 5
    assert result.retry_after_seconds is None
    assert result.request_id.startswith("req_")


def test_blocked(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        method="POST",
        url=f"{BASE}/security/rate-limit/check",
        json={
            "allowed": False,
            "remaining": 0,
            "limit": 5,
            "resetAt": "2026-05-11T16:00:00Z",
            "retryAfterSeconds": 487,
            "key": "login:user@example.com",
            "requestId": "req_01HV0000000000000000000001",
        },
    )
    client = vwp.Client(api_key="vwp_test_abc")
    result = client.rate_limit.check(key="login:user@example.com", limit=5, window="15m")
    assert result.allowed is False
    assert result.retry_after_seconds == 487


def test_unauthorized(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        method="POST",
        url=f"{BASE}/security/rate-limit/check",
        status_code=401,
        json={"error": "unauthorized", "message": "bad key", "requestId": "req_x"},
    )
    client = vwp.Client(api_key="vwp_test_bogus")
    with pytest.raises(vwp.ApiKeyError) as excinfo:
        client.rate_limit.check(key="u", limit=5, window="1m")
    assert excinfo.value.status_code == 401
    assert excinfo.value.request_id == "req_x"


def test_bad_request(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        method="POST",
        url=f"{BASE}/security/rate-limit/check",
        status_code=400,
        json={
            "error": "invalid_input",
            "field": "window",
            "message": "bad window",
            "requestId": "req_y",
        },
    )
    client = vwp.Client(api_key="vwp_test_abc")
    with pytest.raises(vwp.BadRequestError) as excinfo:
        client.rate_limit.check(key="u", limit=5, window="15 minutes")
    assert excinfo.value.field == "window"


def test_server_error(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        method="POST",
        url=f"{BASE}/security/rate-limit/check",
        status_code=500,
        json={"error": "server_error", "requestId": "req_z"},
    )
    client = vwp.Client(api_key="vwp_test_abc")
    with pytest.raises(vwp.ServerError):
        client.rate_limit.check(key="u", limit=5, window="1m")


def test_meta_rate_limited(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        method="POST",
        url=f"{BASE}/security/rate-limit/check",
        status_code=429,
        json={
            "error": "meta_rate_limited",
            "message": "slow down",
            "retryAfterSeconds": 1,
            "requestId": "req_q",
        },
    )
    client = vwp.Client(api_key="vwp_test_abc")
    with pytest.raises(vwp.MetaRateLimitedError) as excinfo:
        client.rate_limit.check(key="u", limit=5, window="1m")
    assert excinfo.value.retry_after_seconds == 1


def test_payload_includes_optional_fields(httpx_mock: HTTPXMock):
    httpx_mock.add_response(
        method="POST",
        url=f"{BASE}/security/rate-limit/check",
        json={
            "allowed": True,
            "remaining": 2,
            "limit": 5,
            "resetAt": "2026-05-11T16:00:00Z",
            "key": "k",
            "requestId": "req_a",
        },
    )
    client = vwp.Client(api_key="vwp_test_abc")
    client.rate_limit.check(key="k", limit=5, window="1m", cost=3, tenant_id="acme")
    sent = httpx_mock.get_request()
    import json as _json
    payload = _json.loads(sent.content)
    assert payload == {"key": "k", "limit": 5, "window": "1m", "cost": 3, "tenantId": "acme"}


def test_module_level_check_uses_env(httpx_mock: HTTPXMock, monkeypatch):
    monkeypatch.setenv("VWP_API_KEY", "vwp_test_envkey")
    httpx_mock.add_response(
        method="POST",
        url=f"{BASE}/security/rate-limit/check",
        json={
            "allowed": True,
            "remaining": 9,
            "limit": 10,
            "resetAt": "2026-05-11T16:00:00Z",
            "key": "k",
            "requestId": "req_b",
        },
    )
    result = vwp.rate_limit.check(key="k", limit=10, window="1m")
    assert result.allowed
    sent = httpx_mock.get_request()
    assert sent.headers["Authorization"] == "Bearer vwp_test_envkey"


def test_missing_api_key_raises(monkeypatch):
    monkeypatch.delenv("VWP_API_KEY", raising=False)
    with pytest.raises(vwp.ApiKeyError):
        vwp.Client()


def test_module_surface():
    assert hasattr(vwp, "rate_limit")
    assert hasattr(vwp, "auth")
    assert hasattr(vwp, "notify")
    assert hasattr(vwp, "data")
    assert hasattr(vwp, "queue")


def test_stub_modules_raise():
    # vwp.auth (magic link) and vwp.notify.send_email are now implemented.
    # Remaining stubs: notify.send_sms, data.*, queue.*
    with pytest.raises(NotImplementedError):
        vwp.notify.send_sms()
    with pytest.raises(NotImplementedError):
        vwp.data.kv_get()
    with pytest.raises(NotImplementedError):
        vwp.queue.enqueue()
