"""Rate limiting primitive — SECURITY-RATE-LIMIT-001.

Module-level call (uses ``VWP_API_KEY`` from env)::

    import vwp
    result = vwp.rate_limit.check(key="login:user@example.com", limit=5, window="15m")
    if not result.allowed:
        ...

Or via an explicit client::

    client = vwp.Client(api_key="vwp_test_...")
    client.rate_limit.check(key="...", limit=5, window="15m")

Async::

    async with vwp.AsyncClient(api_key="...") as c:
        result = await c.rate_limit.check(key="...", limit=5, window="15m")
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Optional

if TYPE_CHECKING:
    from .client import AsyncClient, Client


@dataclass
class CheckResult:
    """Result of a rate-limit check.

    Mirrors the public API response. ``retry_after_seconds`` is ``None`` when ``allowed`` is True.
    """

    allowed: bool
    remaining: int
    limit: int
    reset_at: str
    key: str
    request_id: str
    retry_after_seconds: Optional[int] = None

    @classmethod
    def _from_response(cls, body: dict) -> "CheckResult":
        return cls(
            allowed=bool(body.get("allowed")),
            remaining=int(body.get("remaining", 0)),
            limit=int(body.get("limit", 0)),
            reset_at=str(body.get("resetAt", "")),
            key=str(body.get("key", "")),
            request_id=str(body.get("requestId", "")),
            retry_after_seconds=(
                int(body["retryAfterSeconds"])
                if body.get("retryAfterSeconds") is not None
                else None
            ),
        )


_CHECK_PATH = "/security/rate-limit/check"


def _build_payload(
    key: str,
    limit: int,
    window: str,
    cost: int = 1,
    tenant_id: Optional[str] = None,
) -> dict:
    payload: dict[str, Any] = {
        "key": key,
        "limit": limit,
        "window": window,
        "cost": cost,
    }
    if tenant_id is not None:
        payload["tenantId"] = tenant_id
    return payload


class RateLimitNamespace:
    """Bound to a sync :class:`vwp.Client`."""

    def __init__(self, client: "Client") -> None:
        self._client = client

    def check(
        self,
        *,
        key: str,
        limit: int,
        window: str,
        cost: int = 1,
        tenant_id: Optional[str] = None,
    ) -> CheckResult:
        body = self._client._post(
            _CHECK_PATH, _build_payload(key, limit, window, cost, tenant_id)
        )
        return CheckResult._from_response(body)


class AsyncRateLimitNamespace:
    """Bound to a :class:`vwp.AsyncClient`."""

    def __init__(self, client: "AsyncClient") -> None:
        self._client = client

    async def check(
        self,
        *,
        key: str,
        limit: int,
        window: str,
        cost: int = 1,
        tenant_id: Optional[str] = None,
    ) -> CheckResult:
        body = await self._client._post(
            _CHECK_PATH, _build_payload(key, limit, window, cost, tenant_id)
        )
        return CheckResult._from_response(body)


def check(
    *,
    key: str,
    limit: int,
    window: str,
    cost: int = 1,
    tenant_id: Optional[str] = None,
) -> CheckResult:
    """Module-level convenience. Reads VWP_API_KEY from the environment.

    Equivalent to ``vwp.Client().rate_limit.check(...)``. For high-throughput callers, instantiate
    a long-lived ``vwp.Client`` so HTTP connections are reused.
    """
    from .client import Client

    with Client() as client:
        return client.rate_limit.check(
            key=key, limit=limit, window=window, cost=cost, tenant_id=tenant_id
        )
