"""HTTP client core. Holds config, builds the httpx clients, dispatches API errors.

Two clients ship: :class:`Client` (sync) and :class:`AsyncClient` (async). Both share the same
transport logic in :class:`_Transport`.
"""

from __future__ import annotations

import os
from typing import Any, Optional

import httpx

from .errors import (
    ApiKeyError,
    BadRequestError,
    MetaRateLimitedError,
    NetworkError,
    ServerError,
    VWPError,
)
from .version import __version__

DEFAULT_BASE_URL = "https://api.vibewithprimitiveai.com/v1"
DEFAULT_TIMEOUT_SECONDS = 10.0
USER_AGENT = f"vwp-sdk-python/{__version__}"


class _Transport:
    """Shared response handling — same shape for sync and async."""

    @staticmethod
    def headers(api_key: str, extra: Optional[dict] = None) -> dict:
        h = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "User-Agent": USER_AGENT,
            "Accept": "application/json",
        }
        if extra:
            h.update(extra)
        return h

    @staticmethod
    def handle(resp: httpx.Response) -> dict:
        """Turn an httpx response into a parsed dict or raise a typed VWPError."""
        try:
            body = resp.json() if resp.content else {}
        except ValueError:
            body = {}
        request_id = body.get("requestId") if isinstance(body, dict) else None

        if resp.status_code == 200:
            return body if isinstance(body, dict) else {}
        if resp.status_code == 400:
            raise BadRequestError(
                body.get("message", "Bad request") if isinstance(body, dict) else "Bad request",
                field=body.get("field") if isinstance(body, dict) else None,
                request_id=request_id,
                status_code=400,
                body=body if isinstance(body, dict) else None,
            )
        if resp.status_code == 401:
            raise ApiKeyError(
                body.get("message", "Unauthorized") if isinstance(body, dict) else "Unauthorized",
                request_id=request_id,
                status_code=401,
                body=body if isinstance(body, dict) else None,
            )
        if resp.status_code == 429:
            retry_after = 1
            if isinstance(body, dict):
                retry_after = int(body.get("retryAfterSeconds", 1))
            raise MetaRateLimitedError(
                body.get("message", "Rate limited") if isinstance(body, dict) else "Rate limited",
                retry_after_seconds=retry_after,
                request_id=request_id,
                status_code=429,
                body=body if isinstance(body, dict) else None,
            )
        if 500 <= resp.status_code < 600:
            raise ServerError(
                "VWP API server error.",
                request_id=request_id,
                status_code=resp.status_code,
                body=body if isinstance(body, dict) else None,
            )
        raise VWPError(
            f"Unexpected response: HTTP {resp.status_code}.",
            request_id=request_id,
            status_code=resp.status_code,
            body=body if isinstance(body, dict) else None,
        )


def _resolve_api_key(api_key: Optional[str]) -> str:
    key = api_key or os.environ.get("VWP_API_KEY")
    if not key:
        raise ApiKeyError(
            "No API key found. Pass api_key=... or set VWP_API_KEY in the environment."
        )
    return key


def _resolve_base_url(base_url: Optional[str]) -> str:
    return base_url or os.environ.get("VWP_BASE_URL") or DEFAULT_BASE_URL


class Client:
    """Synchronous client. One instance per process; thread-safe under httpx."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        *,
        base_url: Optional[str] = None,
        timeout: float = DEFAULT_TIMEOUT_SECONDS,
        transport: Optional[httpx.BaseTransport] = None,
    ) -> None:
        self.api_key = _resolve_api_key(api_key)
        self.base_url = _resolve_base_url(base_url).rstrip("/")
        self._http = httpx.Client(
            base_url=self.base_url,
            timeout=timeout,
            headers=_Transport.headers(self.api_key),
            transport=transport,
        )
        # Lazy-attached namespaces (avoid circular imports).
        from .auth import AuthNamespace
        from .notify import NotifyNamespace
        from .rate_limit import RateLimitNamespace

        self.rate_limit = RateLimitNamespace(self)
        self.auth = AuthNamespace(self)
        self.notify = NotifyNamespace(self)

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> "Client":
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()

    def _post(self, path: str, json: dict) -> dict:
        try:
            resp = self._http.post(path, json=json)
        except httpx.HTTPError as exc:
            raise NetworkError(str(exc)) from exc
        return _Transport.handle(resp)

    def _get(self, path: str) -> dict:
        try:
            resp = self._http.get(path)
        except httpx.HTTPError as exc:
            raise NetworkError(str(exc)) from exc
        return _Transport.handle(resp)


class AsyncClient:
    """Async client. Use inside an event loop; share across coroutines."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        *,
        base_url: Optional[str] = None,
        timeout: float = DEFAULT_TIMEOUT_SECONDS,
        transport: Optional[httpx.AsyncBaseTransport] = None,
    ) -> None:
        self.api_key = _resolve_api_key(api_key)
        self.base_url = _resolve_base_url(base_url).rstrip("/")
        self._http = httpx.AsyncClient(
            base_url=self.base_url,
            timeout=timeout,
            headers=_Transport.headers(self.api_key),
            transport=transport,
        )
        from .auth import AsyncAuthNamespace
        from .notify import AsyncNotifyNamespace
        from .rate_limit import AsyncRateLimitNamespace

        self.rate_limit = AsyncRateLimitNamespace(self)
        self.auth = AsyncAuthNamespace(self)
        self.notify = AsyncNotifyNamespace(self)

    async def aclose(self) -> None:
        await self._http.aclose()

    async def __aenter__(self) -> "AsyncClient":
        return self

    async def __aexit__(self, *exc: Any) -> None:
        await self.aclose()

    async def _post(self, path: str, json: dict) -> dict:
        try:
            resp = await self._http.post(path, json=json)
        except httpx.HTTPError as exc:
            raise NetworkError(str(exc)) from exc
        return _Transport.handle(resp)

    async def _get(self, path: str) -> dict:
        try:
            resp = await self._http.get(path)
        except httpx.HTTPError as exc:
            raise NetworkError(str(exc)) from exc
        return _Transport.handle(resp)
