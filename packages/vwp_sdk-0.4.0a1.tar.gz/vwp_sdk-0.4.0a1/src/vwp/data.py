"""Stub for the DATA-* primitives. Lands in Phase 2+."""

from __future__ import annotations


def _not_yet(name: str):
    def _raise(*_a, **_kw):
        raise NotImplementedError(
            f"vwp.data.{name}() ships in Phase 2+."
        )

    return _raise


kv_get = _not_yet("kv_get")
kv_set = _not_yet("kv_set")
