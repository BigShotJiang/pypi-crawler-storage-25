"""Email + notification primitives.

`vwp.notify.email.send(...)` — NOTIFY-EMAIL-TRANSACTIONAL-001
SMS lands in a future release.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Iterable, Optional, Union

if TYPE_CHECKING:
    from .client import AsyncClient, Client


_SEND_PATH = "/notify/email/send"


@dataclass
class SendResult:
    message_id: Optional[str]
    status: str
    request_id: str
    to: list[str]

    @classmethod
    def _from_response(cls, body: dict) -> "SendResult":
        return cls(
            message_id=body.get("messageId"),
            status=str(body.get("status", "")),
            request_id=str(body.get("requestId", "")),
            to=list(body.get("to") or []),
        )


def _build_payload(
    to: Union[str, Iterable[str]],
    subject: str,
    html: Optional[str],
    text: Optional[str],
    reply_to: Optional[str],
    metadata: Optional[dict],
) -> dict[str, Any]:
    payload: dict[str, Any] = {"to": list(to) if not isinstance(to, str) else to, "subject": subject}
    if html is not None:
        payload["html"] = html
    if text is not None:
        payload["text"] = text
    if reply_to is not None:
        payload["replyTo"] = reply_to
    if metadata is not None:
        payload["metadata"] = metadata
    return payload


class _SyncEmail:
    def __init__(self, client: "Client") -> None:
        self._client = client

    def send(
        self,
        *,
        to: Union[str, Iterable[str]],
        subject: str,
        html: Optional[str] = None,
        text: Optional[str] = None,
        reply_to: Optional[str] = None,
        metadata: Optional[dict] = None,
    ) -> SendResult:
        return SendResult._from_response(
            self._client._post(
                _SEND_PATH, _build_payload(to, subject, html, text, reply_to, metadata)
            )
        )


class NotifyNamespace:
    def __init__(self, client: "Client") -> None:
        self.email = _SyncEmail(client)


class _AsyncEmail:
    def __init__(self, client: "AsyncClient") -> None:
        self._client = client

    async def send(
        self,
        *,
        to: Union[str, Iterable[str]],
        subject: str,
        html: Optional[str] = None,
        text: Optional[str] = None,
        reply_to: Optional[str] = None,
        metadata: Optional[dict] = None,
    ) -> SendResult:
        return SendResult._from_response(
            await self._client._post(
                _SEND_PATH, _build_payload(to, subject, html, text, reply_to, metadata)
            )
        )


class AsyncNotifyNamespace:
    def __init__(self, client: "AsyncClient") -> None:
        self.email = _AsyncEmail(client)


def send_email(
    *,
    to: Union[str, Iterable[str]],
    subject: str,
    html: Optional[str] = None,
    text: Optional[str] = None,
    reply_to: Optional[str] = None,
    metadata: Optional[dict] = None,
) -> SendResult:
    """Module-level helper. Reads ``VWP_API_KEY`` from env.

    Equivalent to ``vwp.Client().notify.email.send(...)``.
    """
    from .client import Client

    with Client() as client:
        return client.notify.email.send(
            to=to,
            subject=subject,
            html=html,
            text=text,
            reply_to=reply_to,
            metadata=metadata,
        )


def send_sms(*_args, **_kwargs):
    """SMS — landing in a future release."""
    raise NotImplementedError(
        "vwp.notify.send_sms() ships in a later release. SMS via ACS is on the roadmap."
    )
