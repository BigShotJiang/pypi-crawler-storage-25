"""Auth primitives — magic link in this release. Session helpers + OAuth coming in 0.3+.

The magic-link flow is two HTTP calls, but the SDK shapes them as:

    client = vwp.Client(api_key="vwp_test_...")

    # Step 1 — user submits email
    result = client.auth.magic_link.request(
        email="user@example.com",
        return_to="https://example.com/dashboard",
    )

    # Step 2 — user clicks the link; your callback handler does:
    exchanged = client.auth.magic_link.exchange(handle=<value of _vwp_h from the URL>)
    # exchanged.session, exchanged.jwt, exchanged.refresh_token, exchanged.return_to

The handle is in the request URL as the ``_vwp_h`` query parameter. Read it however your
framework reads query params. The SDK does the rest.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Optional
from urllib.parse import parse_qs, urlparse

if TYPE_CHECKING:
    from .client import AsyncClient, Client


_REQUEST_PATH = "/auth/magic-link/request"
_EXCHANGE_PATH = "/auth/magic-link/exchange"
_SESSION_CREATE_PATH = "/auth/session/create"
_SESSION_VERIFY_PATH = "/auth/session/verify"
_SESSION_REFRESH_PATH = "/auth/session/refresh"


@dataclass
class RequestResult:
    request_id: str
    email: str
    expires_at: str
    delivery_status: str

    @classmethod
    def _from_response(cls, body: dict) -> "RequestResult":
        return cls(
            request_id=str(body.get("requestId", "")),
            email=str(body.get("email", "")),
            expires_at=str(body.get("expiresAt", "")),
            delivery_status=str(body.get("deliveryStatus", "")),
        )


@dataclass
class Session:
    id: str
    user_id: str
    email: str
    tenant_id: Optional[str]
    created_at: str
    expires_at: str
    metadata: dict = field(default_factory=dict)

    @classmethod
    def _from_response(cls, body: dict) -> "Session":
        return cls(
            id=str(body.get("id", "")),
            user_id=str(body.get("userId", "")),
            email=str(body.get("email", "")),
            tenant_id=body.get("tenantId"),
            created_at=str(body.get("createdAt", "")),
            expires_at=str(body.get("expiresAt", "")),
            metadata=dict(body.get("metadata") or {}),
        )


@dataclass
class ExchangeResult:
    session: Session
    jwt: str
    refresh_token: str
    return_to: str

    @classmethod
    def _from_response(cls, body: dict) -> "ExchangeResult":
        return cls(
            session=Session._from_response(body.get("session") or {}),
            jwt=str(body.get("jwt", "")),
            refresh_token=str(body.get("refreshToken", "")),
            return_to=str(body.get("returnTo", "")),
        )


def _extract_handle(source: Any) -> str:
    """Best-effort: pull ``_vwp_h`` from a string URL, dict, or framework request object.

    Accepted shapes:

    - ``str`` — a URL with ``?_vwp_h=...`` in the query string
    - ``dict`` — query-param mapping (``{"_vwp_h": "..."}``) or a request-like dict with
      either a ``query`` key or a ``url`` key
    - Any object with a ``.url`` attribute (string) — pulled from the query string

    Raises :class:`ValueError` if the handle can't be found.
    """
    if source is None:
        raise ValueError("No source given to extract handle from.")
    if isinstance(source, str):
        qs = parse_qs(urlparse(source).query)
        handles = qs.get("_vwp_h") or []
        if handles:
            return handles[0]
        raise ValueError("No _vwp_h in URL query string.")
    if isinstance(source, dict):
        if "_vwp_h" in source:
            return str(source["_vwp_h"])
        if "query" in source and isinstance(source["query"], dict) and "_vwp_h" in source["query"]:
            return str(source["query"]["_vwp_h"])
        if "url" in source and isinstance(source["url"], str):
            return _extract_handle(source["url"])
        raise ValueError("dict did not contain a _vwp_h key.")
    url = getattr(source, "url", None)
    if isinstance(url, str):
        return _extract_handle(url)
    if hasattr(source, "query_params") and "_vwp_h" in source.query_params:
        return str(source.query_params["_vwp_h"])
    raise ValueError(
        "Could not extract _vwp_h handle. Pass a string URL, dict with _vwp_h or url, "
        "or use client.auth.magic_link.exchange(handle=...)."
    )


# ---------- Sync namespaces ----------


class _SyncMagicLink:
    def __init__(self, client: "Client") -> None:
        self._client = client

    def request(
        self,
        *,
        email: str,
        return_to: str,
        metadata: Optional[dict] = None,
        tenant_id: Optional[str] = None,
    ) -> RequestResult:
        payload: dict[str, Any] = {"email": email, "returnTo": return_to}
        if metadata is not None:
            payload["metadata"] = metadata
        if tenant_id is not None:
            payload["tenantId"] = tenant_id
        return RequestResult._from_response(self._client._post(_REQUEST_PATH, payload))

    def exchange(
        self,
        request: Any = None,
        *,
        handle: Optional[str] = None,
        fingerprint: Optional[str] = None,
    ) -> ExchangeResult:
        if handle is None:
            handle = _extract_handle(request)
        payload: dict[str, Any] = {"handle": handle}
        if fingerprint is not None:
            payload["fingerprint"] = fingerprint
        return ExchangeResult._from_response(self._client._post(_EXCHANGE_PATH, payload))


@dataclass
class VerifyResult:
    valid: bool
    session: Optional[Session]
    reason: Optional[str]

    @classmethod
    def _from_response(cls, body: dict) -> "VerifyResult":
        sess_body = body.get("session")
        return cls(
            valid=bool(body.get("valid")),
            session=Session._from_response(sess_body) if sess_body else None,
            reason=body.get("reason"),
        )


class _SyncSession:
    def __init__(self, client: "Client") -> None:
        self._client = client

    def create(
        self,
        *,
        email: str,
        metadata: Optional[dict] = None,
        tenant_id: Optional[str] = None,
        ttl_seconds: Optional[int] = None,
    ) -> ExchangeResult:
        payload: dict[str, Any] = {"email": email}
        if metadata is not None:
            payload["metadata"] = metadata
        if tenant_id is not None:
            payload["tenantId"] = tenant_id
        if ttl_seconds is not None:
            payload["ttlSeconds"] = ttl_seconds
        body = self._client._post(_SESSION_CREATE_PATH, payload)
        # Reuse ExchangeResult shape since session/create returns the same envelope.
        # returnTo is not present here; default to empty string.
        body.setdefault("returnTo", "")
        return ExchangeResult._from_response(body)

    def verify(self, jwt: str) -> VerifyResult:
        return VerifyResult._from_response(
            self._client._post(_SESSION_VERIFY_PATH, {"jwt": jwt})
        )

    def refresh(self, refresh_token: str) -> ExchangeResult:
        body = self._client._post(_SESSION_REFRESH_PATH, {"refreshToken": refresh_token})
        body.setdefault("returnTo", "")
        return ExchangeResult._from_response(body)


class AuthNamespace:
    def __init__(self, client: "Client") -> None:
        self._client = client
        self.magic_link = _SyncMagicLink(client)
        self.session = _SyncSession(client)


# ---------- Async namespaces ----------


class _AsyncMagicLink:
    def __init__(self, client: "AsyncClient") -> None:
        self._client = client

    async def request(
        self,
        *,
        email: str,
        return_to: str,
        metadata: Optional[dict] = None,
        tenant_id: Optional[str] = None,
    ) -> RequestResult:
        payload: dict[str, Any] = {"email": email, "returnTo": return_to}
        if metadata is not None:
            payload["metadata"] = metadata
        if tenant_id is not None:
            payload["tenantId"] = tenant_id
        return RequestResult._from_response(await self._client._post(_REQUEST_PATH, payload))

    async def exchange(
        self,
        request: Any = None,
        *,
        handle: Optional[str] = None,
        fingerprint: Optional[str] = None,
    ) -> ExchangeResult:
        if handle is None:
            handle = _extract_handle(request)
        payload: dict[str, Any] = {"handle": handle}
        if fingerprint is not None:
            payload["fingerprint"] = fingerprint
        return ExchangeResult._from_response(await self._client._post(_EXCHANGE_PATH, payload))


class _AsyncSession:
    def __init__(self, client: "AsyncClient") -> None:
        self._client = client

    async def create(
        self,
        *,
        email: str,
        metadata: Optional[dict] = None,
        tenant_id: Optional[str] = None,
        ttl_seconds: Optional[int] = None,
    ) -> ExchangeResult:
        payload: dict[str, Any] = {"email": email}
        if metadata is not None:
            payload["metadata"] = metadata
        if tenant_id is not None:
            payload["tenantId"] = tenant_id
        if ttl_seconds is not None:
            payload["ttlSeconds"] = ttl_seconds
        body = await self._client._post(_SESSION_CREATE_PATH, payload)
        body.setdefault("returnTo", "")
        return ExchangeResult._from_response(body)

    async def verify(self, jwt: str) -> VerifyResult:
        return VerifyResult._from_response(
            await self._client._post(_SESSION_VERIFY_PATH, {"jwt": jwt})
        )

    async def refresh(self, refresh_token: str) -> ExchangeResult:
        body = await self._client._post(_SESSION_REFRESH_PATH, {"refreshToken": refresh_token})
        body.setdefault("returnTo", "")
        return ExchangeResult._from_response(body)


class AsyncAuthNamespace:
    def __init__(self, client: "AsyncClient") -> None:
        self._client = client
        self.magic_link = _AsyncMagicLink(client)
        self.session = _AsyncSession(client)


# ---------- Module-level convenience ----------


def request_magic_link(
    *,
    email: str,
    return_to: str,
    metadata: Optional[dict] = None,
    tenant_id: Optional[str] = None,
) -> RequestResult:
    """Module-level helper. Reads ``VWP_API_KEY`` from env."""
    from .client import Client

    with Client() as client:
        return client.auth.magic_link.request(
            email=email, return_to=return_to, metadata=metadata, tenant_id=tenant_id
        )


def exchange_magic_link(
    request: Any = None,
    *,
    handle: Optional[str] = None,
    fingerprint: Optional[str] = None,
) -> ExchangeResult:
    """Module-level helper. Reads ``VWP_API_KEY`` from env."""
    from .client import Client

    with Client() as client:
        return client.auth.magic_link.exchange(
            request=request, handle=handle, fingerprint=fingerprint
        )
