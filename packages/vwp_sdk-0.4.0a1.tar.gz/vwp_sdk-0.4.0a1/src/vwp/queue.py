"""Stub for the QUEUE-* primitives. Lands in Phase 2+."""

from __future__ import annotations


def _not_yet(name: str):
    def _raise(*_a, **_kw):
        raise NotImplementedError(
            f"vwp.queue.{name}() ships in Phase 2+."
        )

    return _raise


enqueue = _not_yet("enqueue")
dequeue = _not_yet("dequeue")
