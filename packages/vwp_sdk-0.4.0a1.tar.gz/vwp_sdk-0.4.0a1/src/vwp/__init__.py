"""VWP — primitives for vibe-coded backends.

A single function call per primitive. Drop-in for any Python web framework.

Quick start::

    import vwp

    client = vwp.Client(api_key="vwp_test_...")
    result = client.rate_limit.check(key="login:user@example.com", limit=5, window="15m")
    if not result.allowed:
        # 429 your end user
        ...

Module surface:

* ``vwp.Client``        — sync client (see also :class:`vwp.AsyncClient`)
* ``vwp.rate_limit``    — see :mod:`vwp.rate_limit`
* ``vwp.auth``          — stub (Phase 2)
* ``vwp.notify``        — stub (Phase 2)
* ``vwp.data``          — stub (Phase 2)
* ``vwp.queue``         — stub (Phase 2)
"""

from __future__ import annotations

from . import auth, data, notify, queue, rate_limit
from .auth import ExchangeResult, RequestResult, Session, VerifyResult
from .client import AsyncClient, Client
from .errors import (
    ApiKeyError,
    BadRequestError,
    MetaRateLimitedError,
    NetworkError,
    ServerError,
    VWPError,
)
from .version import __version__

__all__ = [
    "ApiKeyError",
    "AsyncClient",
    "BadRequestError",
    "Client",
    "ExchangeResult",
    "MetaRateLimitedError",
    "NetworkError",
    "RequestResult",
    "ServerError",
    "Session",
    "VWPError",
    "VerifyResult",
    "__version__",
    "auth",
    "data",
    "notify",
    "queue",
    "rate_limit",
]
