"""Typed exception hierarchy for the SDK."""

from __future__ import annotations

from typing import Any, Optional


class VWPError(Exception):
    """Base class for every SDK error."""

    def __init__(
        self,
        message: str,
        *,
        request_id: Optional[str] = None,
        status_code: Optional[int] = None,
        body: Optional[dict] = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.request_id = request_id
        self.status_code = status_code
        self.body = body

    def __repr__(self) -> str:
        bits = [f"status={self.status_code}"] if self.status_code else []
        if self.request_id:
            bits.append(f"requestId={self.request_id}")
        suffix = f" ({', '.join(bits)})" if bits else ""
        return f"{type(self).__name__}: {self.message}{suffix}"


class ApiKeyError(VWPError):
    """401 — missing, invalid, or revoked API key."""


class BadRequestError(VWPError):
    """400 — malformed request (bad window string, missing field, etc.)."""

    def __init__(self, message: str, *, field: Optional[str] = None, **kw: Any) -> None:
        super().__init__(message, **kw)
        self.field = field


class MetaRateLimitedError(VWPError):
    """429 — you're calling the rate-limit API itself too fast."""

    def __init__(self, message: str, *, retry_after_seconds: int, **kw: Any) -> None:
        super().__init__(message, **kw)
        self.retry_after_seconds = retry_after_seconds


class ServerError(VWPError):
    """5xx — something broke on our side. Include ``request_id`` in support cases."""


class NetworkError(VWPError):
    """No HTTP response received. Timeout, DNS, TLS, connection refused, etc."""
