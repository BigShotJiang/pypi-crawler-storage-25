# mvulib

## Description
Maximum Variance Unfolding (MVU) dimensionality reduction
algorithm implemented in MATLAB with use of SeDuMi 
(Self Dual Minimization) package for solving semidefinite
programming. 

## Installation and Requirements
MATLAB Runtime 24.1 installation is required. It 
can be downloaded from the following address:
[MATLAB Runtime 24.1](https://www.mathworks.com/products/compiler/matlab-runtime.html).
Runtime must be added to the PATH upon installation.
Supported Python versions are >=3.9, <=3.11. 
Installation of numpy, scipy and scikit-learn is required.

## Usage
Package includes Mvu Python class that serves as an interface to 
MATLAB implementation. Upon installation the Mvu class is 
instantiated and operated in a way similar to that of other 
sklearn dimensionality reduction classes. For example:

```
from mvulib.mvu import Mvu
from sklearn.datasets import make_swiss_roll
X, t=make_swiss_roll(n_samples=1000, random_state=0)
mvu=Mvu(n_neighbors=6, angles=2) # angles=0 is much faster
Y=mvu.fit_transform(X, 2) # Two dimensional embedding.
```

## References
Implementation is based on the following paper:

K.Q.Weinberger, L.K.Saul. "Unsupervised Learning of Image Manifolds by Semidefinite Programming".

## Documentation
Documentation .ipynb notebooks can be obtained upon request.
Contact e-mail address: stanicrikard7@gmail.com.

## License

This project is licensed under the **GNU General Public License v2.0 or later (GPL‑2.0‑or‑later)**.

The choice of this license is required because the project depends on **SeDuMi**, which is distributed under the GNU GPL. 
Any software that incorporates or links to SeDuMi must also be released under a GPL‑compatible license.

By using, modifying, or distributing this project, you agree to the terms of the GPL‑2.0‑or‑later.  
A full copy of the license is provided in the `LICENSE` file included with this distribution.



