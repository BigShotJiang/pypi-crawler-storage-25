# PyRel, The RelationalAI Python SDK

Use PyRel to build and query semantic models with advanced reasoning capabilities powered by RelationalAI.

Learn more at [https://docs.relational.ai](https://docs.relational.ai).
