import warnings

from v0.relationalai.semantics.lqp import lqp_bundle, model2lqp, result_helpers, utils

ir = lqp_bundle.ir

__all__ = ['ir', 'model2lqp', 'result_helpers', 'utils']

warnings.warn(
    "relationalai.early_access.lqp.* is deprecated. "
    "Please migrate to relationalai.semantics.lqp.*",
    DeprecationWarning,
    stacklevel=2,
)
