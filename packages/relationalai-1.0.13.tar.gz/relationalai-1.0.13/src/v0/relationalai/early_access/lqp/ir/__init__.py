import warnings

from v0.relationalai.semantics.lqp import lqp_bundle

ir_to_proto = lqp_bundle.ir_to_proto

__all__ = ["ir_to_proto"]

warnings.warn(
    "relationalai.early_access.lqp.ir is deprecated. "
    "Please migrate to relationalai.semantics.lqp.ir",
    DeprecationWarning,
    stacklevel=2,
)
