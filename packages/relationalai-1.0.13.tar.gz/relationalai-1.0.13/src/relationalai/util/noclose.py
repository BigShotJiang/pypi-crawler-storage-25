from __future__ import annotations

from typing import Any


class NoClose:
    """Delegate attribute access but ignore `aclose()`.

    Useful when a higher-level object (root client) owns shared transports/resources and
    service clients/gateways should not close them.
    """

    def __init__(self, target: Any) -> None:  # noqa: ANN401
        self._target = target

    def __getattr__(self, name: str) -> Any:  # noqa: ANN401
        return getattr(self._target, name)

    async def aclose(self) -> None:
        return None

