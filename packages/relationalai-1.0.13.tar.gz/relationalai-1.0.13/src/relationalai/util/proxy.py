from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class ExecutionMetricsProxy:
    """Mutable proxy for execution metrics.

    Some clients (e.g. async Direct Access wiring) may need to choose a transport lazily.
    This proxy lets higher-level APIs expose a stable `execution_metrics` handle while
    the real underlying metrics object becomes available later.
    """

    _target: Any | None = field(default=None, repr=False)

    def set_target(self, target: Any | None) -> None:  # noqa: ANN401
        self._target = target

    def __getattr__(self, name: str) -> Any:  # noqa: ANN401
        target = self._target
        if target is None:
            raise AttributeError(name)
        return getattr(target, name)

