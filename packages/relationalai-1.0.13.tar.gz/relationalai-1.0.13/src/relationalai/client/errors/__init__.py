"""Client error types and error-mapping helpers.

This package exposes the shared client exception hierarchy and the handler
chain used to normalize backend-specific failures.
"""

__include_in_docs__ = True

from .exceptions import *  # noqa: F403
from .handlers import *  # noqa: F403

