"""Authentication helpers (Direct Access + Snowflake OAuth/JWT/PAT)."""

from __future__ import annotations

__include_in_docs__ = True

from .handlers import (
    TokenHandler,
    DirectAccessAuthError,
    DirectAccessConfigError,
    DirectAccessOAuthError,
    DirectAccessOAuthInvalidClientError,
    DirectAccessOAuthTimeoutError,
    DirectAccessOAuthStateMismatchError,
    DirectAccessOAuthBrowserOpenError,
    DirectAccessEndpointStaleError,
    SnowflakeOAuthTokenHandler,
    SnowflakePATHandler,
    SnowflakeKeyFileHandler,
)

__all__ = [
    "TokenHandler",
    "DirectAccessAuthError",
    "DirectAccessConfigError",
    "DirectAccessOAuthError",
    "DirectAccessOAuthInvalidClientError",
    "DirectAccessOAuthTimeoutError",
    "DirectAccessOAuthStateMismatchError",
    "DirectAccessOAuthBrowserOpenError",
    "DirectAccessEndpointStaleError",
    "SnowflakeOAuthTokenHandler",
    "SnowflakePATHandler",
    "SnowflakeKeyFileHandler",
]

