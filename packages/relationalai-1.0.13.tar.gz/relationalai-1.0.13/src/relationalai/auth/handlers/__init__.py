"""Direct Access authentication handlers and exported auth error types."""

from __future__ import annotations

__include_in_docs__ = True

from .base import (
    DirectAccessAuthError,
    DirectAccessConfigError,
    DirectAccessEndpointStaleError,
    DirectAccessOAuthBrowserOpenError,
    DirectAccessOAuthError,
    DirectAccessOAuthInvalidClientError,
    DirectAccessOAuthStateMismatchError,
    DirectAccessOAuthTimeoutError,
    TokenHandler,
)
from .oauth_authorization_code import SnowflakeOAuthTokenHandler
from .programmatic_access_token import SnowflakePATHandler
from .snowflake_jwt import SnowflakeKeyFileHandler

__all__ = [
    "TokenHandler",
    "DirectAccessAuthError",
    "DirectAccessConfigError",
    "DirectAccessOAuthError",
    "DirectAccessOAuthInvalidClientError",
    "DirectAccessOAuthTimeoutError",
    "DirectAccessOAuthStateMismatchError",
    "DirectAccessOAuthBrowserOpenError",
    "DirectAccessEndpointStaleError",
    "SnowflakeOAuthTokenHandler",
    "SnowflakePATHandler",
    "SnowflakeKeyFileHandler",
]

