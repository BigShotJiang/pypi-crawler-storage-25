from __future__ import annotations

from typing import Final

JOB_TYPE_LOGIC: Final[str] = "LOGIC"
JOB_TYPE_SOLVER: Final[str] = "SOLVER"
JOB_TYPE_ML: Final[str] = "ML"

JOB_TYPES: Final[tuple[str, ...]] = (JOB_TYPE_LOGIC, JOB_TYPE_SOLVER, JOB_TYPE_ML)

# User-facing labels used in CLI output/help.
JOB_TYPE_LABELS: Final[dict[str, str]] = {
    JOB_TYPE_LOGIC: "Logic",
    JOB_TYPE_SOLVER: "Prescriptive",
    JOB_TYPE_ML: "Predictive",
}

# Accepted CLI inputs (case-insensitive) -> canonical job type.
_NORMALIZE: Final[dict[str, str]] = {
    # canonical
    "LOGIC": JOB_TYPE_LOGIC,
    "SOLVER": JOB_TYPE_SOLVER,
    "ML": JOB_TYPE_ML,
    # reasoner-type strings (common mental model)
    "PRESCRIPTIVE": JOB_TYPE_SOLVER,
    "PREDICTIVE": JOB_TYPE_ML,
}


def normalize_job_type(value: str | None) -> str:
    """Normalize a jobs `--type` value to a canonical job type.

    Canonical job types used by the Jobs gateway:
    - `LOGIC` (transactions)
    - `SOLVER` (prescriptive jobs)
    - `ML` (predictive jobs)
    """
    raw = (value or "").strip()
    if not raw:
        raise ValueError("Job type is required.")
    key = raw.upper()
    if key in _NORMALIZE:
        return _NORMALIZE[key]
    raise ValueError(f"Invalid job type {value!r}. Expected: Logic, Prescriptive, or Predictive.")


def job_type_label(value: str | None) -> str | None:
    """Return a stable CLI label for a job type-like string (best-effort)."""
    if value is None:
        return None
    raw = str(value).strip()
    if not raw:
        return None
    try:
        t = normalize_job_type(raw)
    except Exception:
        return raw
    return JOB_TYPE_LABELS.get(t, t)


