#pyright: reportPrivateImportUsage=false
from __future__ import annotations

from typing import Any, Callable

import click


def text_prompt(
    message: str,
    *,
    default: str | None = None,
    validator: Callable[[str], Any] | None = None,
    invalid_message: str = "Invalid input",
) -> str:
    """Prompt for a text value with optional validation.

    Uses InquirerPy's text input with consistent abort keybindings.
    """
    from InquirerPy import inquirer

    # Upstream-style keybindings: escape / ctrl-c / ctrl-d abort.
    keybindings: Any = {
        "interrupt": [{"key": "escape"}, {"key": "c-c"}, {"key": "c-d"}],
    }

    try:
        return inquirer.text(
            message,
            default=default or "",
            keybindings=keybindings,
            validate=validator,
            invalid_message=invalid_message,
        ).execute()
    except KeyboardInterrupt as e:
        raise click.Abort() from e
    except Exception as e:
        msg = str(e)
        if "Return value already set" in msg and "Application.exit()" in msg:
            raise click.Abort() from e
        raise

