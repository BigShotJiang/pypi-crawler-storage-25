"""Shared helpers for the Click CLI (connection, errors, jobs/reasoners resolution).

Kept out of ``cli.py`` so that module focuses on command registration and wiring.
"""

from __future__ import annotations

import functools
import json
import sys
from collections.abc import Callable, Iterator, Mapping
from contextlib import contextmanager
from datetime import date, datetime, timedelta
from typing import Any, TypeVar, cast, TYPE_CHECKING

import click
from rich.console import Console

if TYPE_CHECKING:
    from relationalai.client.client_sync import ClientSync
    from relationalai.config.config import Config

from .error_handlers import CliErrorContext, DEFAULT_CLI_ERROR_HANDLER_CHAIN, emit_cli_diagnostic
from .execution_diagnostics import enable_execution_logging_buffer
from .markup import tip

CliCommandCallback = TypeVar("CliCommandCallback", bound=Callable[..., Any])

console = Console()


def configure_cli_console(*, no_color: bool) -> None:
    """Rebuild the shared Rich :class:`~rich.console.Console` (e.g. after parsing ``--no-color`` / ``NO_COLOR``)."""
    global console
    console = Console(no_color=no_color)


def cli_wants_json() -> bool:
    """True when the current command was run with global ``--json``."""
    ctx = click.get_current_context(silent=True)
    if ctx is None:
        return False
    return bool(ctx.obj.get("json_output"))


def emit_cli_json(data: Any) -> None:
    """Print JSON to stdout (no Rich markup)."""
    click.echo(json.dumps(data, indent=2, default=_json_default))


def _json_default(obj: Any) -> Any:
    if isinstance(obj, (datetime, date)):
        return obj.isoformat()
    if isinstance(obj, timedelta):
        return str(obj)
    raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")


def _maybe_model_dump(obj: Any) -> dict[str, Any] | None:
    md = getattr(obj, "model_dump", None)
    if not callable(md):
        return None
    try:
        out = md(mode="json")
        return dict(out) if isinstance(out, Mapping) else None
    except Exception:
        try:
            out = md()
            return dict(out) if isinstance(out, Mapping) else None
        except Exception:
            return None


_REASONER_ATTRS = (
    "id",
    "name",
    "type",
    "size",
    "state",
    "created_by",
    "created_on",
    "updated_on",
    "version",
    "auto_suspend_mins",
    "suspends_at",
    "settings",
    "runtime",
)

_JOB_ATTRS = (
    "id",
    "reasoner_type",
    "name",
    "state",
    "created_by",
    "created_on",
    "finished_at",
    "duration",
    "abort_reason",
    "details",
    "artifacts",
    "events",
    "problems",
    "raw",
)


def reasoner_record_as_json(obj: Any) -> dict[str, Any]:
    """Serialize a reasoner record for global ``--json``."""
    dumped = _maybe_model_dump(obj)
    if dumped is not None:
        return dumped
    return {k: _jsonify_scalar(getattr(obj, k, None)) for k in _REASONER_ATTRS}


def job_record_as_json(obj: Any) -> dict[str, Any]:
    """Serialize a job record for global ``--json``."""
    dumped = _maybe_model_dump(obj)
    if dumped is not None:
        return dumped
    out: dict[str, Any] = {k: _jsonify_scalar(getattr(obj, k, None)) for k in _JOB_ATTRS}
    ev = out.get("events")
    if ev is not None and not isinstance(ev, (dict, list, str, int, float, bool, type(None))):
        out["events"] = {
            "events": list(getattr(ev, "events", [])),
            "continuation_token": getattr(ev, "continuation_token", None),
        }
    return out


def _jsonify_scalar(v: Any) -> Any:
    if v is None:
        return None
    if isinstance(v, timedelta):
        return str(v)
    if isinstance(v, (datetime, date)):
        return v.isoformat()
    if isinstance(v, Mapping):
        return dict(v)
    if isinstance(v, (list, tuple)):
        return [_jsonify_scalar(x) for x in v]
    return v


def reasoner_options_type_name_filter(cmd: CliCommandCallback) -> CliCommandCallback:
    """`--type` / `--name` for commands that filter or select a reasoner (delete, suspend, resume)."""
    cmd = click.option(
        "--type",
        "reasoner_type",
        required=False,
        default=None,
        help="Reasoner type filter (Logic/Prescriptive/Predictive) (optional).",
    )(cmd)
    cmd = click.option(
        "--name", "reasoner_name", required=False, default=None, help="Reasoner name (optional)."
    )(cmd)
    return cmd


def reasoner_options_type_name_direct(cmd: CliCommandCallback) -> CliCommandCallback:
    """`--type` / `--name` for commands that address one reasoner by identity (alter, get)."""
    cmd = click.option(
        "--type",
        "reasoner_type",
        required=False,
        default=None,
        help="Reasoner type (Logic/Prescriptive/Predictive) (optional).",
    )(cmd)
    cmd = click.option(
        "--name", "reasoner_name", required=False, default=None, help="Reasoner name (optional)."
    )(cmd)
    return cmd


def print_reasoner_async_operation_started(*, verb: str, operation_id: str, t_label: str, name: str) -> None:
    """Shared messaging after a background reasoner create/resume operation is accepted."""
    console.print(f"[green]{verb}: OK[/green] (operation_id={operation_id})")
    console.print("")
    if verb == "create":
        console.print("Reasoner creation has started and will continue in the background.")
    else:
        console.print("Reasoner resume has started and will continue in the background.")
    console.print(f"Check status: [green]rai reasoners:get --type {t_label} --name {name}[/green]")
    console.print(tip("use [cyan]--wait[/cyan] flag to block until reasoner is in READY status."))


def exit_on_docs_subcommand_failure(exc: BaseException, *, headline: str) -> None:
    """Emit a diagnostic and exit(1) for docs subcommands (matches prior ClickException vs Exception handling)."""
    if isinstance(exc, click.ClickException):
        emit_cli_diagnostic(
            name="docs",
            message=headline,
            details=exc.message,
            escape_details=True,
        )
    else:
        emit_cli_diagnostic(
            name="docs",
            message=headline,
            details=str(exc) or repr(exc),
            escape_details=True,
        )
    sys.exit(1)


@contextmanager
def cli_connect_sync(config: "Config") -> Iterator["ClientSync"]:
    """Connect a sync client and (optionally) emit execution diagnostics."""
    from relationalai.client import connect_sync

    handler = enable_execution_logging_buffer(config)
    ctx = click.get_current_context(silent=True)
    if ctx is not None:
        ctx.ensure_object(dict)
        if handler is not None:
            ctx.obj["_execution_log_handler"] = handler
        ctx.obj["_execution_diag_config"] = config

    with connect_sync(config=config) as client:
        try:
            yield client
        finally:
            if ctx is not None:
                ctx.obj["_execution_metrics"] = getattr(client, "execution_metrics", None)


def is_interactive() -> bool:
    """Return True when CLI can prompt interactively."""
    try:
        return bool(getattr(sys.stdin, "isatty", lambda: False)())
    except Exception:
        return False


def emit_cli_error(*, name: str, message: str, details: str | None = None) -> None:
    """Emit a pretty diagnostic for CLI failures (stderr)."""
    emit_cli_diagnostic(name=name, message=message, details=details)


def _emit_cli_error_handled(
    *,
    name: str,
    message: str,
    error: Exception,
    params: dict[str, Any] | None = None,
) -> None:
    ctx = CliErrorContext(command=name, params=params or {})
    details = DEFAULT_CLI_ERROR_HANDLER_CHAIN.format_details(error, ctx)
    emit_cli_error(name=name, message=message, details=details)


def cli_fail(
    *,
    name: str,
    message: str,
    error: Exception,
    click_message: str,
    params: dict[str, Any] | None = None,
) -> None:
    """Emit a handled error then raise a ClickException."""
    if isinstance(error, click.Abort):
        raise click.exceptions.Exit(0) from error
    _emit_cli_error_handled(name=name, message=message, error=error, params=params)
    raise click.ClickException(click_message) from error


def handle_cli_errors(
    *,
    name: str,
    message: str,
    click_message: str,
    params: Callable[..., dict[str, Any]] | None = None,
) -> Callable[[CliCommandCallback], CliCommandCallback]:
    """Wrap a Click command callback; uncaught exceptions become ``cli_fail``.

    Lets `click.UsageError` propagate (e.g. guards before the main body). Commands that need
    error ``params`` from partially completed work should keep an explicit ``try``/``except``.
    """

    def decorator(f: CliCommandCallback) -> CliCommandCallback:
        @functools.wraps(f)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            try:
                return f(*args, **kwargs)
            except click.UsageError:
                raise
            except Exception as e:
                built = params(*args, **kwargs) if params is not None else None
                cli_fail(
                    name=name,
                    message=message,
                    error=e,
                    click_message=click_message,
                    params=built,
                )

        return cast(CliCommandCallback, wrapper)

    return decorator


def job_include_from_flags(includes: tuple[str, ...]):
    """Convert repeated `--include` flags into a typed `JobIncludeDict`."""
    if not includes:
        return None

    from relationalai.services.jobs.util import JobIncludeDict

    inc: JobIncludeDict = {}
    for k in includes:
        kk = str(k).strip().lower()
        match kk:
            case "details":
                inc["details"] = True
            case "events":
                inc["events"] = True
            case "artifacts":
                inc["artifacts"] = True
            case "problems":
                inc["problems"] = True
            case "raw":
                inc["raw"] = True
    return inc


def jobs_get_with_spinner(jobs: Any, job_type: str, job_id: str, *, include: Any = None) -> Any:
    from relationalai.tools.cli.components import WaitSpinner

    with WaitSpinner(f"Fetching job {job_id}..."):
        return jobs.get(str(job_type), str(job_id), include=include)


def jobs_wait_with_spinner(
    jobs: Any,
    job_type: str,
    job_id: str,
    *,
    timeout_s: float,
    poll_interval_s: float,
) -> Any:
    from relationalai.tools.cli.components import WaitSpinner

    with WaitSpinner(f"Waiting for job {job_id}..."):
        return jobs.wait(str(job_type), str(job_id), timeout_s=timeout_s, poll_interval_s=poll_interval_s)


def print_job_background_instructions(*, job_type_label: str, job_id: str, created: bool = True) -> None:
    if created:
        console.print("")
        console.print("Job started and will continue running in the background.")
    console.print(f"Wait for completion: [green]rai jobs:wait --type {job_type_label} --id {job_id}[/green]")
    console.print(tip("use [cyan]--wait[/cyan] flag to block until job is in COMPLETED state."))


def ensure_job_identity(
    jobs: Any,
    *,
    config: "Config",
    job_type: str | None,
    job_id: str | None,
    interactive: bool,
    prompt: str,
    only_active: bool = False,
) -> tuple[str, str] | None:
    """Return `(job_type, job_id)` for a job, prompting when needed."""
    from relationalai.tools.cli.flows import select_job

    rt = job_type
    jid = job_id

    if jid and not (rt and str(rt).strip()):
        xs: list[Any] = []
        try:
            xs = jobs.list(None, job_id=jid, limit=5)
        except Exception:
            xs = []
        if len(xs) == 1:
            rt = getattr(xs[0], "reasoner_type", None)
        elif len(xs) > 1 and interactive:
            picked = select_job(
                jobs,
                config=config,
                reasoner_type=None,
                job_id=jid,
                interactive=interactive,
                console=console,
                prompt=prompt,
                only_active=only_active,
            )
            if picked is None:
                return None
            rt, jid = picked

    if not (rt and str(rt).strip() and jid and str(jid).strip()):
        if not interactive:
            raise click.ClickException("--type and --id are required (or run interactively).")
        picked = select_job(
            jobs,
            config=config,
            reasoner_type=rt,
            job_id=jid,
            interactive=interactive,
            console=console,
            prompt=prompt,
            only_active=only_active,
        )
        if picked is None:
            return None
        rt, jid = picked

    from relationalai.tools.cli.job_types import job_type_label

    t_public = job_type_label(str(rt)) or str(rt)
    return str(t_public), str(jid)


def _require_reasoner_identity_non_interactive(
    *,
    reasoner_type: str | None,
    reasoner_name: str | None,
    interactive: bool,
) -> None:
    if interactive:
        return
    if not (reasoner_type or "").strip():
        raise click.ClickException("Reasoner type is required. Use --type.")
    if not (reasoner_name or "").strip():
        raise click.ClickException("Reasoner name is required. Use --name.")


def resolve_reasoner_target(
    reasoners: Any,
    *,
    reasoner_type: str | None,
    reasoner_name: str | None,
    interactive: bool,
    prompt: str,
    state: str | None = None,
    exclude_states: set[str] | None = None,
) -> tuple[str, str, str] | None:
    """Resolve a reasoner target to `(normalized_type, display_label, name)`."""
    from relationalai.tools.cli.flows import ensure_reasoner_name, ensure_reasoner_type, select_reasoner

    _require_reasoner_identity_non_interactive(
        reasoner_type=reasoner_type,
        reasoner_name=reasoner_name,
        interactive=interactive,
    )

    if reasoner_name and not reasoner_type:
        t_norm, t_label = ensure_reasoner_type(None, interactive=interactive, console=console)
        name = ensure_reasoner_name(reasoner_name, interactive=interactive, console=console)
        return t_norm, t_label, name

    if reasoner_type and reasoner_name:
        t_norm, t_label = ensure_reasoner_type(reasoner_type, interactive=interactive, console=console)
        return t_norm, t_label, reasoner_name

    picked = select_reasoner(
        reasoners,
        reasoner_type=reasoner_type,
        reasoner_name=reasoner_name,
        state=state,
        exclude_states=exclude_states,
        interactive=interactive,
        console=console,
        prompt=prompt,
    )
    if picked is None:
        return None

    r_type, r_name = picked
    t_norm, t_label = ensure_reasoner_type(r_type, interactive=interactive, console=console)
    return t_norm, t_label, r_name


def reasoner_with_state(*, reasoner: Any | None, reasoner_type: str, reasoner_name: str, state: str) -> Any:
    """Return a displayable reasoner-like mapping with an overridden state."""
    data: dict[str, Any] = {
        "name": reasoner_name,
        "type": reasoner_type,
        "state": state,
    }
    if reasoner is not None:
        for key in (
            "id",
            "name",
            "type",
            "size",
            "state",
            "created_by",
            "created_on",
            "updated_on",
            "auto_suspend_mins",
            "suspends_at",
            "settings",
        ):
            value = getattr(reasoner, key, None)
            if value is not None:
                data[key] = value
        data["state"] = state
    return data


def load_config():
    """Load config using the unified create_config() factory (rai yaml → snowflake toml → dbt profiles)."""
    try:
        from relationalai.config import create_config

        return create_config()
    except ModuleNotFoundError as e:
        raise click.ClickException(
            "Failed to load config. Ensure optional config dependencies are installed "
            "(e.g. `pydantic-settings`) and that your configuration is valid."
        ) from e
    except Exception as e:
        raise click.ClickException(f"Failed to load config: {e}") from e
