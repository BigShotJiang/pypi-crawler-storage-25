from __future__ import annotations

from typing import Callable

from relationalai.semantics import (
    Integer, AnyEntity, Model, Variable, Fragment, Relationship,
)
from relationalai.semantics.std.paths import PathTraversal
from relationalai.semantics.std.common import hash, Hash


def enumerate_all_paths_on_DAG_naive_BFS(
    m: Model,
    edge_fn: Callable[[Variable], Variable],
    src: Variable | Fragment,
    dst: Variable | Fragment | None,
    repeats: tuple[int, int],
) -> Relationship:
    """
    Naive BFS algorithm for enumerating all paths on a supplied DAG, between src and dst,
    with optional min/max repeat counts.

    This follows essentially the same loop as a standard BFS, or transitive closure, but
    rather than computing reachability we are computing a unique Hash for every _path_
    traversed, and storing the nodes visited along it. We achieve that by growing a
    linked-list for each path, reusing the tails of the paths that are the same (so it's
    actually a tree with only backedges, rooted from nil).

    ASSUMES: the graph is a DAG. If there are cycles, this algorithm will not terminate.
    Complexity: Exponential in the number of nodes, since each path is tracked separately,
    and there can be exponentially many paths in a DAG.

    Args:
        m: The Model instance used to define relationships, properties, and procedures.
        edge_fn: A callable that takes a node variable and returns the set of successor
            nodes, e.g. `lambda x: Person(x).follows`. Note that the argument will be an
            instance of AnyEntity, so edge_fn must handle that (e.g. by casting to the
            expected Concept).
        src: Source node(s) to start the BFS from. Can be any Variable (e.g. a Concept
            population, a specific instance via `.new()`, or an expression that evaluates to
            nodes), or a Fragment (a filtered selection).
        dst: Destination node(s) — same types as src, or None to match any destination.
            Only paths ending at a dst node are included in the result.
        repeats: A tuple (min_repeats, max_repeats) specifying the allowed range of hops
            for matched paths.

    IMPLEMENTATION NOTE:
        We considered stopping iteration of a path after it reaches a node in `dst`, but
        if there is more than one node in `dst`, we need to continue traversing in case
        we can reach other `dst` nodes. So this optimization is not valid.

    """
    min_repeats, max_repeats = repeats
    _validate_repeats(min_repeats, max_repeats)

    nil = Hash(0)

    path_length = m.Property(f"{PathTraversal:path} has {Integer:length} hops")

    # The linked-lists of PathTraversal objects.
    path_head = m.Property(f"{PathTraversal:path} has {AnyEntity:node}")
    path_tail = m.Property(f"{PathTraversal:path} has {PathTraversal:tail}")
    with m._procedure(path_length, path_head, path_tail) as p:
        frontier_paths = m.Relationship(f"{PathTraversal:path} points to {AnyEntity:node}")
        start_path = PathTraversal(hash(src, nil))
        p.assign(frontier_paths(start_path, src))

        step = m.Property(f"{Integer}")
        p.assign(step(0))
        p.assign(path_length(start_path, step))
        p.assign(path_head(start_path, src))
        p.assign(path_tail(start_path, nil))

        with p.loop():
            p.break_if(step >= max_repeats)
            p.assign(step(step + 1))

            # Match a single step
            next_node, next_path = m.where(
                current_node := frontier_paths["node"],
                current_path := frontier_paths["path"],
                successor := edge_fn(current_node),
            ).select(successor, PathTraversal(hash(successor, current_path)))

            p.break_if(m.not_(next_path))

            p.with_arity(0).upsert(path_tail(next_path, current_path))
            p.with_arity(0).upsert(path_length(next_path, step))
            p.with_arity(0).upsert(path_head(next_path, next_node))

            p.assign(frontier_paths(next_path, next_node))

    # Now store the results of the paths traversal into the model:
    paths = m.Relationship(f"{PathTraversal:path}")
    m.define(paths(PathTraversal)).where(
        path_len := path_length(PathTraversal),
        path_len >= min_repeats,
        # NOTE: We stop iteration after max_repeats, so all paths will have:
        #   path_len <= max_repeats,
        (path_head(PathTraversal, dst) if dst is not None else True),
    )

    # - paths() already contains the set of paths that match the min/max repeat pattern.
    # - Save the length for each of the matched paths.
    # - Note: `paths` is a unary Relationship with a named field (`:path`), so using it
    #   directly (e.g. `paths` in `path_length(paths)`) binds its trailing slot as a
    #   variable. Because the field is named, repeated uses of `paths` in the same
    #   expression unify on that name — so both occurrences of `paths` below refer to
    #   the same PathTraversal.
    m.define(PathTraversal.length(paths, path_length(paths)))

    # - Traverse the linked lists backwards to get the Nodes matched for each path:
    path_ancestor = m.Relationship(f"{PathTraversal} has {PathTraversal:ancestor}")
    m.define(
        path_ancestor(paths, paths),
        path_ancestor(paths, path_tail(path_ancestor(paths))),
    )

    # Finally, store the head node at each ancestor as a node along the path:
    m.where(
        ancestor := path_ancestor(PathTraversal)
    ).define(PathTraversal.nodes(path_length(ancestor), path_head(ancestor)))

    return paths


def _validate_repeats(min_repeats: int, max_repeats: int) -> None:
    if min_repeats < 0:
        raise ValueError(
            f"The `repeats` argument must have non-negative min_repeats, "
            f"but got min_repeats={min_repeats}."
        )
    if max_repeats < 0:
        raise ValueError(
            f"The `repeats` argument must have non-negative max_repeats, "
            f"but got max_repeats={max_repeats}."
        )
    if min_repeats > max_repeats:
        raise ValueError(
            f"The `repeats` argument must satisfy min_repeats <= max_repeats, "
            f"but got min_repeats={min_repeats} and max_repeats={max_repeats}."
        )
