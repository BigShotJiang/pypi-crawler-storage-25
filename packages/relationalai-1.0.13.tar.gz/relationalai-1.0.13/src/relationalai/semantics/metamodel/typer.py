from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from typing import Optional, Union, Iterable, TypeVar, Tuple
from decimal import Decimal

from ...util import tracing
from ...util.error import err, exc, Source, Part
from ...util.naming import sanitize
from ...util.structures import OrderedSet

from . import metamodel as mm, builtins as bt
from .rewriter import Walker, Rewriter
from .builtins import builtins as b

from contextlib import contextmanager


#--------------------------------------------------
# Typer Testing
#--------------------------------------------------
COLLECTED_ERRORS = None
@contextmanager
def errors(error_type):
    """
    Check that this type error is raised within the context.

    :param error_type: the type of the expected error.
    """
    global COLLECTED_ERRORS
    COLLECTED_ERRORS = []
    try:
        yield
    except Exception:
        # we expect the typer to raise an error
        pass
    finally:
        if not any(isinstance(error, error_type) for error in COLLECTED_ERRORS):
            exc("ExpectedWarning", f"Expected warning of type {error_type.__name__} but none was raised.")
        COLLECTED_ERRORS = None


#--------------------------------------------------
# Typer
#--------------------------------------------------

T = TypeVar("T", bound=mm.Model | mm.Task)

class Typer:
    def __init__(self, enforce=False):
        self.enforce = enforce
        self.model_net: Optional[PropagationNetwork] = None
        # TODO: remove this once we are using spans for the debugger
        self.last_net: Optional[PropagationNetwork] = None

    def infer_model(self, model: mm.Model) -> mm.Model:
        """
        Infer types for the given model, returning a new model with updated types and
        storing the results within this typer so that subsequent calls can reuse them.
        """
        # create a brand new network with data from this model
        self.model_net = PropagationNetwork(model)
        return self._infer(model, self.model_net)

    def infer_query(self, query: mm.Task) -> mm.Task:
        """
        Infer types for the given query, returning a new query with updated types. If the
        typer was used to infer a model previously, the information from that model analysis
        will be reused.
        """
        if self.model_net is not None:
            net = PropagationNetwork(self.model_net.model)
            net.load_types(self.model_net)
        else:
            net = PropagationNetwork(mm.Model(root=query))
        self.last_net = net
        return self._infer(query, net)

    #--------------------------------------------------
    # Internal implementation
    #--------------------------------------------------

    def _infer(self, node: T, net: PropagationNetwork) -> T:
        # build the propagation network by analyzing the model
        with tracing.span("typer.analyze"):
            Analyzer(net).analyze(node)

        # propagate the types through the network
        with tracing.span("typer.propagate"): # as span:
            net.propagate()
            # span["type_graph"] = net.to_mermaid()

        # replace the fields in the model with the new types
        with tracing.span("typer.replace"):
            replacer = Replacer(net)
            final = replacer.rewrite(node)
            if isinstance(final, mm.Model):
                net.model = final

        # report any errors found during type inference
        if net.errors:
            if COLLECTED_ERRORS is not None:
                # collecting errors for tests, just add them to the list
                COLLECTED_ERRORS.extend(net.errors)
                # raise to avoid further processing
                raise Exception("Typer errors collected.")
            else:
                for error in net.errors:
                    error.report()
                if self.enforce:
                    exc("TyperError", "Type errors detected during type inference (see above for details).")
        return final


#--------------------------------------------------
# Propagation Network
#--------------------------------------------------

# The core idea of the typer is to build a propagation network that represents data
# dependencies between nodes. Nodes can be variables, literals, fields and tasks that refer
# to relations (lookups, aggregates, updates). An edge from node A to node B means that
# in order to resolve references and types for node B we need to know the type of node A.
#
# After building the network, we start with roots that have known types (literals, fields
# loaded from previous analysis and vars with concrete types) and propagate their types via
# the edges to other nodes. It is possible that the network contains cycles, so we iterate
# on the work list until fixpoint is reached, i.e. when we cannot propagate any new type.
#
# During the propagation, we are only gathering information about the types and references
# of nodes. Once we reach a fixpoint, we do a final pass to rewrite the model with the new
# type information, which may include adding casts to convert between types where needed.
#
Node = Union[mm.Var, mm.Field, mm.Literal, mm.Lookup, mm.Aggregate, mm.Update]

class PropagationNetwork():
    def __init__(self, model: mm.Model):
        # the model that is either being analyzed or that is the context for a query
        self.model = model

        # all nodes in the network, by id
        self.nodes: dict[int, Node] = {}

        # the resolved types of nodes in the network; we track by node id because literals
        # (and potentially other nodes) have equality by value.
        self.resolved_types: dict[int, mm.Type] = {}

        # ids of vars that were narrowed to a specific type due to being used in a
        # population lookup.
        self.narrowed_types: set[int] = set()

        # map from unresolved placeholder relations to their potential target replacements
        self.potential_targets: dict[mm.Relation, list[mm.Relation]] = {}

        # nodes loaded from previous analysis, which we use as roots to start propagation
        self.loaded_roots:set[int] = set()

        # edges in the propagation network, from one node to potentially many
        self.edges:dict[int, OrderedSet[int]] = defaultdict(lambda: OrderedSet())
        self.back_edges:dict[int, OrderedSet[int]] = defaultdict(lambda: OrderedSet())

        # fields whose updated were already visited; used to guarantee that we only resolve
        # lookups on those fields after the field update is visited
        self.field_updated:set[mm.Field] = set()

        # all errors collected during inference
        self.errors:list[TyperError] = []

        # overloads resolved for a lookup/update/aggregate, by node id. This is only for
        # relations that declare overloads
        self.resolved_overload:dict[int, mm.Overload] = {}

        # placeholders resolved for a lookup, by node id. This is only for relations that
        # are placeholders (i.e. only Any fields) and will be replaced by references to
        # these concrete relations. E.g. a query for "name(Any, Any)" may be replaced by
        # the union of "name(Dog, String)" and name(Cat, String)".
        self.resolved_placeholder:dict[int, list[mm.Relation]] = {}

        # for a given lookup/update/aggregate that involves numbers, the specific number
        # type resolved for it.
        self.resolved_number:dict[int, mm.NumberType] = {}

    #--------------------------------------------------
    # Error reporting
    #--------------------------------------------------

    def type_mismatch(self, node: Node|mm.Update, expected: mm.Type, actual: mm.Type):
        self.errors.append(TypeMismatch(node, expected, actual))

    def invalid_type(self, node: Node, type: mm.Type):
        self.errors.append(InvalidType(node, type))

    def unresolved_overload(self, node: mm.Lookup|mm.Aggregate):
        # TODO - consider renaming this to UnresolvedReference
        self.errors.append(UnresolvedOverload(node, [self.resolve(a) for a in node.args]))

    def unresolved_type(self, node: mm.Lookup|mm.Aggregate, arg: mm.Var):
        self.errors.append(UnresolvedType(node, arg))

    def has_errors(self, node: Node) -> bool:
        for mismatch in self.errors:
            if mismatch.node == node:
                return True
        return False

    #--------------------------------------------------
    # Types and Edges
    #--------------------------------------------------

    def add_edge(self, source: Node, target: Node):
        self.nodes[source.id] = source
        self.nodes[target.id] = target
        self.edges[source.id].add(target.id)
        self.back_edges[target.id].add(source.id)

    def add_resolved_type(self, node: Node, type: mm.Type):
        """ Register that this node was resolved to have this type. """
        # ensure the node is mapped
        self.nodes[node.id] = node
        # previously resolved type or the type of the node itself
        prev_type = self.resolved_types.get(node.id) if node.id in self.resolved_types else None
        if not prev_type and isinstance(node, (mm.Var|mm.Field|mm.Literal)):
            prev_type = self.resolve(node)
        # if there is a prev_type, check validity and adjust accordingly
        if prev_type and prev_type != type:
                merged = merge_types(prev_type, type)
                if invalid_type(merged):
                    self.invalid_type(node, merged)
                elif node.id in self.narrowed_types:
                    if type_narrows(type, prev_type):
                        self.resolved_types[node.id] = type
                    else:
                        # maintain the previous type, which is narrower
                        pass
                else:
                    self.resolved_types[node.id] = merged
        else:
            # nothing previously known, just record the type
            self.resolved_types[node.id] = type

    def narrow_resolved_type(self, node: mm.Var, prev_type: mm.Type, type: mm.Type, is_population_lookup):
        """ Register that this variable is resolved to have exactly this type. If there's a
        compatible type already registered, just replace it, otherwise report a type
        mismatch error. """
        if type_narrows(type, prev_type):
            # this is a narrower type, so we can just replace it
            self.resolved_types[node.id] = type
        elif not type_matches(prev_type, type, accept_expected_super_types=is_population_lookup):
            # the previous type is not compatible with the new type, so report a mismatch
            self.type_mismatch(node, type, prev_type)
        else:
            # the previous type is compatible with the new type, but it's not narrower
            # so we merge the types (e.g. a variable that is used in 2 population
            # lookups should be of either type)
            merged = merge_types(prev_type, type)
            if invalid_type(merged):
                self.invalid_type(node, merged)
            else:
                self.resolved_types[node.id] = merged
        self.nodes[node.id] = node
        self.narrowed_types.add(node.id)

    #--------------------------------------------------
    # Load types from a previous analysis
    #--------------------------------------------------

    def load_types(self, net: PropagationNetwork):
        for id, type in net.resolved_types.items():
            node = net.nodes[id]
            if isinstance(node, (mm.Field)):
                self.add_resolved_type(node, type)
                self.loaded_roots.add(node.id)
                self.nodes[node.id] = node

    #--------------------------------------------------
    # Resolve Values
    #--------------------------------------------------

    def resolve(self, value: mm.Value) -> mm.Type:
        if isinstance(value, (mm.Var, mm.Literal)):
            return self.resolved_types.get(value.id) or to_type(value)
        if isinstance(value, mm.Field):
            return self.resolved_types.get(value.id) or value.type
        assert not isinstance(value, (mm.Task)), "Should never try to resolve a task"
        return to_type(value)

    #--------------------------------------------------
    # Resolve References
    #--------------------------------------------------

    def all_dependencies_resolved(self, op:mm.Lookup|mm.Aggregate):
        """ True iff all dependencies required to resolve this reference are met. """
        rel = get_relation(op)
        # if this is a placeholder, eq or cast, we assume all possible args were resolved
        if bt.is_placeholder(rel) or rel == b.core.eq or rel == b.core.cast:
            return True

        # else, find whether all back-edges were resolved
        for node_id in self.back_edges[op.id]:
            node = self.nodes[node_id]
            if isinstance(node, mm.Field) and node not in self.field_updated:
                return False
            # cannot resolve if a required var, literal or input field is still abstract
            if isinstance(node, (mm.Var, mm.Literal)) or (isinstance(node, mm.Field) and node.input):
                node_type = self.resolve(node)
                if bt.is_abstract(node_type):
                    return False
        return True

    def resolve_reference(self, op: mm.Lookup|mm.Aggregate) -> Optional[mm.Overload|list[mm.Relation]]:
        # check if all dependencies required to resolve this reference are met
        if not self.all_dependencies_resolved(op):
            return None

        relation = get_relation(op)
        if bt.is_placeholder(relation):
            # when replacing a placeholder, we may have multiple matches
            matches = []
            resolved_args = [self.resolve(arg) for arg in op.args]
            for target in self.potential_targets.get(relation, []):
                fields = get_relation_fields(target, relation.name)
                if all(type_matches(arg, self.resolve(field))
                        for arg, field in zip(resolved_args, fields)):
                    matches.append(target)
            return matches

        elif relation.overloads:
            # when resolving an overload for a concrete relation, we can only have one
            resolved_args = [self.resolve(arg) for arg in op.args]
            is_function = bt.is_function(relation)
            for overload in relation.overloads:
                # note that for functions we only consider input fields when matching
                if all(type_matches(arg, field_type) or conversion_allowed(arg, field_type)
                       for arg, field, field_type in zip(resolved_args, relation.fields, overload.types)
                       if field.input or not is_function):
                    self.resolved_overload[op.id] = overload
                    return overload
            return []  # no matches found

        else:
            # this is a relation with type vars or numbers that needs to be specialized
            return [relation]

    #--------------------------------------------------
    # Propagation
    #--------------------------------------------------

    def propagate(self):
        edges = self.edges
        work_list: list[int] = []

        # start with the loaded roots + all literals + sources of edges without back edges
        work_list.extend(self.loaded_roots)
        for source_id in self.edges.keys():
            source = self.nodes[source_id]
            if isinstance(source, (mm.Literal)) or source_id not in self.back_edges:
                work_list.append(source_id)

        # limit the number of iterations to avoid infinite loops
        i = 0
        max_iterations = 100 * (len(self.edges) + len(work_list))

        # propagate types until we reach a fixed point
        while work_list:
            i += 1
            if i > max_iterations:
                err("Infinite Loop", "Infinite loop detected in the typer. Please, report this as a bug.")
                break

            node_id = work_list.pop(0)
            node = self.nodes[node_id]
            next: Optional[Iterable[Node]] = None
            if isinstance(node, mm.Field):
                # this is a field loaded from a previous analysis, so all we need to do is
                # propagate its type to its output edges
                next = [self.nodes[id] for id in self.edges.get(node.id, [])]
            elif isinstance(node, mm.Update):
                # this is a population update for a variable, just derive that variables type
                # and keep traversing the output edges
                assert(isinstance(node.relation, mm.ScalarType))
                self.add_resolved_type(node.relation.fields[0], node.relation)
                next = [self.nodes[id] for id in self.edges.get(node.id, [])]
            elif isinstance(node, (mm.Lookup, mm.Aggregate)):
                # this is a lookup/aggregate that may be overloaded or a placeholder; try
                # to resolve its reference, i.e. determine which specific relation or
                # overload it refers to
                found = self.resolve_reference(node)
                if found is not None:
                    # if found is None it means that we need more info to resolve the
                    # reference; otherwise it was possible to resolve it (even if to no matches)

                    # keep the resolved args before propagation to see if they will change
                    resolved_args = [self.resolve(arg) for arg in node.args]
                    # propagate the reference resolution
                    self.propagate_reference(node, resolved_args, found)
                    if found:
                        # the next nodes to process are all the outgoing edges plus any arg that
                        # changed during propagation
                        next = []
                        next.extend([self.nodes[id] for id in self.edges.get(node.id, [])])
                        next.extend([arg for idx, arg in enumerate(node.args) if isinstance(arg, mm.Var) and not (self.resolve(arg) == resolved_args[idx])])
                    else:
                        # the reference is unresolved, so remove from the worklist the args
                        # because they depend on this being resolved
                        for arg in node.args:
                            if isinstance(arg, mm.Node) and arg.id in work_list:
                                work_list.remove(arg.id)
            else:
                assert isinstance(node, (mm.Var, mm.Literal))
                resolved = self.resolve(node)
                # if we ended up with an invalid type, report it on a next edge (which is
                # where the var or literal is going to be used)
                if invalid_type(resolved):
                    id = edges.get(node.id, [node.id])[0]
                    self.invalid_type(self.nodes[id], resolved)

                # if the var is still abstract, add it to the work list to try again later
                if isinstance(node, mm.Var) and bt.is_abstract(resolved):
                    # but if everything that is left are vars, we cannot make progress
                    if not all(isinstance(self.nodes[id], mm.Var) for id in work_list):
                        next = [node]
                else:
                    # otherwise, check all outgoing edges
                    next = []
                    for out_id in edges.get(node.id, []):
                        out = self.nodes[out_id]
                        if isinstance(out, mm.Update):
                            # this is an update to a field. We have to check that the type is
                            # valid for the field and if the field is abstract we can refine the
                            # type. But if the field is concrete we have to check that the type
                            # matches or can be converted.
                            for field in get_update_fields(node, out):
                                # accept super types for population updates
                                is_population_update = isinstance(out.relation, mm.ScalarType)
                                self.field_updated.add(field)
                                if not type_matches(resolved, field.type, accept_expected_super_types=is_population_update) and not conversion_allowed(resolved, field.type):
                                    self.type_mismatch(out, field.type, resolved)
                                elif bt.is_abstract(field.type):
                                    # if the field type changed, propagate further
                                    if resolved != self.resolve(field):
                                        next.append(field)
                                    self.add_resolved_type(field, resolved)
                                elif isinstance(node, mm.Literal):
                                    # if the field is a literal, and it matches the type of the
                                    # field, make it be the type of the field.
                                    self.add_resolved_type(node, field.type)
                        else:
                            # this is an arg flowing into a task, so resolve the task next
                            next.append(out)

            # add the new nodes to the work list
            if next is not None:
                for n in next:
                    if n.id not in work_list:
                        work_list.append(n.id)
                        self.nodes[n.id] = n


    def _print_propagation_state(self, node: Node, work_list: list[int]):
        """ Helper function to print the current node and work list for debugging purposes. """
        print(f"Current Node: {node.id} ({type(node).__name__}): {node} (resolved type: {self.resolved_types.get(node.id)})")
        print("Worklist:")
        for id in work_list:
            n = self.nodes[id]
            print(f"  {id} ({type(n).__name__}): {n} (resolved type: {self.resolved_types.get(id)})")
        print()


    def propagate_reference(self, task:mm.Lookup|mm.Aggregate, resolved_args:list[mm.Type], references:mm.Overload|list[mm.Relation]):
        # TODO: distinguish between overloads and placeholders better when raising errors
        if not references:
            return self.unresolved_overload(task)

        relation = get_relation(task)

        # special case cast: just propagate the type to the target
        if relation == b.core.cast:
            cast_type, target = task.args[0], task.args[2]
            assert isinstance(cast_type, mm.Type)
            assert isinstance(target, mm.Var)
            self.add_resolved_type(target, cast_type)
            return

        # special case eq: check that types are valid and propagate to abstract types
        if relation == b.core.eq:
            left, right = task.args[0], task.args[1]
            left_type, right_type = resolved_args[0], resolved_args[1]

            merged_type = merge_types(left_type, right_type)
            if invalid_type(merged_type):
                self.type_mismatch(task, left_type, right_type)
            else:
                if isinstance(left, mm.Var) and bt.is_abstract(left.type) and left_type != merged_type:
                    self.add_resolved_type(left, merged_type)
                if isinstance(right, mm.Var) and bt.is_abstract(right.type) and right_type != merged_type:
                    self.add_resolved_type(right, merged_type)
            return

        # special case placeholders
        if bt.is_placeholder(relation):
            assert(references and isinstance(references, list))
            # we've resolved the placeholder, so store that
            self.resolved_placeholder[task.id] = references

            # we need to determine the final types of our args by taking all the references
            # and adding the type of their fields back to the args.
            for reference in references:
                resolved_field_types = [self.resolve(f) for f in get_relation_fields(reference, relation.name)]
                for field_type, arg_type, arg in zip(resolved_field_types, resolved_args, task.args):
                    if bt.is_abstract(arg_type) and isinstance(arg, mm.Var):
                        self.add_resolved_type(arg, field_type)
            return

        # determine the field types to use
        if isinstance(references, mm.Overload):
            # we resolved an overload, use its types
            field_types = list(references.types)
        else:
            # we resolved to a single concrete relation, use that relation's field types
            field_types = list([self.resolve(f) for f in relation.fields])

        # if this is a function that preserves types we propagate the input types to the
        # output, but only if all input types are the same, and match the field types, i.e.
        # no conversions are needed.
        resolved_field_types = field_types
        if self.should_preserve_type(relation, resolved_field_types, resolved_args, field_types):
            input_types = set([arg_type for field, arg_type
                                in zip(relation.fields, resolved_args) if field.input])
            if out_type := self.try_preserve_type(input_types):
                resolved_field_types = [field_type if field.input else out_type
                                    for field, field_type in zip(relation.fields, field_types)]

        # if there's a type var, ensure all uses of the same type var get a consistent type
        computed_arg_types = []
        typevar_type = None
        has_typevar = b.core.TypeVar in field_types
        if has_typevar:
            # find which arg is bound to the type var and check that they are all consistent
            for arg_type, field_type in zip(resolved_args, field_types):
                if field_type == b.core.TypeVar:
                    if typevar_type is None:
                        typevar_type = arg_type
                    else:
                        merged_type = merge_types(typevar_type, arg_type)
                        if invalid_type(merged_type):
                            self.type_mismatch(task, typevar_type, arg_type)
                            return
                        typevar_type = merged_type
            assert typevar_type is not None

            # compute the final arg types by replacing type vars with the typevar_type
            for arg_type, field_type in zip(resolved_args, field_types):
                # check that the arg type matches the type var type
                if not type_matches(typevar_type, arg_type) and not conversion_allowed(arg_type, typevar_type):
                    self.type_mismatch(task, typevar_type, arg_type)
                if field_type == b.core.TypeVar:
                    computed_arg_types.append(typevar_type)
                else:
                    computed_arg_types.append(arg_type)

            # update types and resolved_field_types with the resolved TypeVar
            resolved_field_types = [typevar_type if ft == b.core.TypeVar else ft for ft in field_types]

        # if there's a Number in the fields, we need to specialized it to a specific number
        # to enforce monotyped operations
        needs_number_specialization = b.core.Number in field_types
        if needs_number_specialization:
            # Use computed_arg_types if we resolved TypeVars, otherwise use resolved_args
            args_for_specialization = computed_arg_types if has_typevar else resolved_args
            number, resolved_field_types = self.specialize_number(relation, resolved_field_types, args_for_specialization)
            self.resolved_number[task.id] = number

            # If we have TypeVars that resolved to numbers, update computed_arg_types with specialized number
            if has_typevar and computed_arg_types is not None:
                computed_arg_types = [number if bt.is_number(t) else t for t in computed_arg_types]

        # finally, propagate types back to args
        if has_typevar:
            # For TypeVar case, propagate the computed (and possibly specialized) arg types to all args
            if computed_arg_types is not None and len(computed_arg_types) == len(task.args):
                for field, computed_type, arg, arg_type in zip(relation.fields, computed_arg_types, task.args, resolved_args):
                    if isinstance(typevar_type, mm.NumberType) and field.input:
                        # this will be converted by the replacer
                        self.resolved_number[task.id] = typevar_type
                    else:
                        # TODO: we could allow for non-numeric/string literals because this means
                        # the literal is being used as a value type, but the backend emitters
                        # would have to deal with that.
                        if isinstance(arg, mm.Var) or (isinstance(arg, mm.Literal) and (bt.is_numeric(computed_type) or computed_type == b.core.String)):
                            self.add_resolved_type(arg, computed_type)

        else:
            # no typevar or number specialization shenanigans, just propagate field types to args
            is_population_lookup = isinstance(relation, mm.TypeNode)
            for field, field_type, arg, arg_type in zip(relation.fields, resolved_field_types, task.args, resolved_args):
                # if the arg does not match the declared field type, and cannot be converted into it, it's a mismatch
                # note that we use the declared field type here, field.type, not the resolved field type, which may
                # have been refined by updates
                if not type_matches(arg_type, field.type, accept_expected_super_types=is_population_lookup) and not conversion_allowed(arg_type, field.type):
                    # if the field is an output and the arg is still abstract, we may be able to refine it later,
                    # as long as they are compatible, so skip reporting as it will come back later
                    # TODO - replace this with the analyzer reversing an edge for this case
                    if not field.input and bt.is_abstract(arg_type) and (type_matches(field.type, arg_type, accept_expected_super_types=is_population_lookup) or conversion_allowed(field.type, arg_type)):
                        continue
                    self.type_mismatch(task, field.type, arg_type)
                else:
                    if bt.is_abstract(field_type) and bt.is_abstract(arg_type):
                        # if the resolved field type is still abstract, we cannot resolve the type of the arg
                        assert isinstance(arg, mm.Var)
                        self.unresolved_type(task, arg)
                    elif isinstance(arg, mm.Var) and is_population_lookup:
                        # the variable is a population lookup arg, narrow the type
                        self.narrow_resolved_type(arg, arg_type, field_type, is_population_lookup)
                    elif isinstance(arg, mm.Literal):
                        # for literals we can just propagate the field type
                        self.add_resolved_type(arg, field_type)
                    elif isinstance(arg, mm.Var) and not field.input and bt.is_abstract(field_type) and not bt.extends(field_type, arg_type):
                        # if this is an output field and the field type is abstract, and it is
                        # not a sub-type of the arg type, this is a mismatch
                        self.type_mismatch(task, arg_type, field_type)
                    elif isinstance(arg, mm.Var) and (not field.input or bt.is_abstract(arg_type) or bt.extends(field_type, arg_type)):
                        # for args, we only propagate in certain conditions
                        self.add_resolved_type(arg, field_type)

    # we try to preserve types for relations that are functions (i.e. potentially multiple
    # input but a single output) and where all types are the same. However, there are some
    # exceptions to this rule, e.g. range() always returns int regardless of whether the
    # input type is an int or a value type that extends int.
    NON_TYPE_PRESERVERS = [
        b.common.range
    ]
    def should_preserve_type(self, relation, resolved_field_types, resolved_args, types) -> bool:
        # a function where all types are the same and all input args match the field type
        return (
            relation not in self.NON_TYPE_PRESERVERS and
            bt.is_function(relation) and
            len(set(resolved_field_types)) == 1 and
            all(type_matches(arg_type, field_type) for arg_type, field_type, field in zip(resolved_args, resolved_field_types, relation.fields) if field.input)
        )

    def try_preserve_type(self, types:set[mm.Type]) -> Optional[mm.Type]:
        # we keep the input type as the output type if either all inputs are the exact same
        # type or there's one nominal and its base primitive type, e.g. USD + Decimal
        if len(types) == 1:
            return next(iter(types))
        if len(types) == 2:
            t1, t2 = types
            t1_base = bt.get_primitive_supertype(t1)
            t2_base = bt.get_primitive_supertype(t2)
            if t1_base is None or t2_base is None:
                base_equivalent = type_matches(t1, t2, accept_expected_super_types=True)
            else:
                base_equivalent = type_matches(t1_base, t2_base)
            if base_equivalent:
                # as long as one of the types is a base primitive, we can use the
                # other type as final preserved type
                if bt.is_primitive(t1):
                    return t2
                elif bt.is_primitive(t2):
                    return t1
        return None

    def specialize_number(self, op, field_types:list[mm.Type], arg_types:list[mm.Type]) -> Tuple[mm.NumberType, list[mm.Type]]:
        """
        Find the number type to use for an overload that has Number in its field_types, and
        which is being referred to with these arg_types.

        Return a tuple where the first element is the specialized number type, and the second
        element is a new list that contains the same types as field_types but with
        Number replaced by this specialized number.
        """
        # special case a few operators according to Snowflake's rules in
        # https://docs.snowflake.com/en/sql-reference/operators-arithmetic#scale-and-precision-in-arithmetic-operations
        if op == b.core.div:
            # see https://docs.snowflake.com/en/sql-reference/operators-arithmetic#division
            numerator, denominator = get_number_type(arg_types[0]), get_number_type(arg_types[1])
            s = max(numerator.scale, min(numerator.scale + 6, 12))
            # if we already have resolved a result type, and it has a larger scale, use it instead
            if isinstance(arg_types[2], mm.NumberType) and arg_types[2].scale > s:
                number = arg_types[2]
            else:
                number = mm.NumberType(name=f"Number(38,{s})", precision=38, scale=s, source=op.source, super_types=(b.core.Numeric,))
            return number, [numerator, denominator, number]
        elif op == b.core.mul:
            # see https://docs.snowflake.com/en/sql-reference/operators-arithmetic#multiplication
            t1, t2 = get_number_type(arg_types[0]), get_number_type(arg_types[1])
            S1 = t1.scale
            S2 = t2.scale
            s = min(S1 + S2, max(S1, S2, 12))
            # if we already have resolved a result type, and it has a larger scale, use it instead
            if isinstance(arg_types[2], mm.NumberType) and arg_types[2].scale > s:
                number = arg_types[2]
            else:
                number = mm.NumberType(name=f"Number(38,{s})", precision=38, scale=s, source=op.source, super_types=(b.core.Numeric,))
            return number, [t1, t2, number]
        elif op == b.aggregates.avg:
            input = get_number_type(arg_types[0])
            s = max(input.scale, min(input.scale + 6, 12))
            number = mm.NumberType(name=f"Number(38,{s})", precision=38, scale=s, source=op.source, super_types=(b.core.Numeric,))
            return number, [input, number]

        # fall back to the the current specialization policy, which is to select the number
        # with largest scale and, if there multiple with the largest scale, the one with the
        # largest precision. This is safe because when converting a number to the
        # specialized number, we never truncate fractional digits (because we selected the
        # largest scale) and, if the non-fractional digits are too large to fit the
        # specialized number, we will have a runtime overflow, which should alert the user
        # of the problem.
        number = None
        flattened_types =[]
        for t in arg_types:
            if isinstance(t, mm.TupleType):
                flattened_types.extend(t.element_types)
            elif isinstance(t, mm.ListType):
                flattened_types.append(t.element_type)
            elif isinstance(t, mm.UnionType):
                flattened_types.extend(t.types)
            else:
                flattened_types.append(t)
        for arg_type in flattened_types:
            x = bt.get_number_supertype(arg_type)
            if isinstance(x, mm.NumberType):
                if number is None or x.scale > number.scale or (x.scale == number.scale and x.precision > number.precision):
                    number = x
        if number is None:
            number = b.core.DefaultNumber
        return number, [number if bt.is_number(t) else t for t in field_types]


    #--------------------------------------------------
    # Display
    #--------------------------------------------------

    # draw the network as a mermaid graph for the debugger
    def to_mermaid(self, max_edges=500) -> str:
        # add links for edges while collecting nodes
        nodes = dict()
        link_strs = []
        # edges
        for src, dsts in self.edges.items():
            nodes[src] = self.nodes[src]
            for dst in dsts:
                if len(link_strs) > max_edges:
                    break
                nodes[dst] = self.nodes[dst]
                link_strs.append(f"n{src} --> n{dst}")
            if len(link_strs) > max_edges:
                break

        def type_span(t:mm.Type) -> str:
            type_str = t.name if isinstance(t, mm.ScalarType) else str(t)
            return f"<span style='color:cyan;'>{type_str.strip()}</span>"

        def reference_span(node:mm.Node, rel:mm.Relation, arg_types:list[mm.Type]) -> str:
            args = []
            for field, arg_type in zip(rel.fields, arg_types):
                field_type = self.resolve(field)
                if isinstance(node, Node) and self.has_errors(node):
                    args.append(f"<span style='color:yellow;'>{str(arg_type).strip()} -> {str(field_type).strip()}</span>")
                elif isinstance(arg_type, mm.UnionType):
                    args.append(type_span(field_type))
                else:
                    args.append(type_span(arg_type))
            return f'{rel.name}({", ".join(args)})'

        resolved = self.resolved_types
        node_strs = []
        for _, node in nodes.items():
            klass = ""
            if isinstance(node, mm.Var):
                ir_type = resolved.get(node.id) or self.resolve(node)
                type_str = type_span(ir_type)
                label = f'(["{node.name}:{type_str}"])'
            elif isinstance(node, mm.Literal):
                ir_type = resolved.get(node.id) or self.resolve(node)
                type_str = type_span(ir_type)
                klass = ":::literal"
                label = f'(["{node.value}: {type_str}"])'
            elif isinstance(node, mm.Field):
                ir_type = resolved.get(node.id) or self.resolve(node)
                type_str = type_span(ir_type)
                klass = ":::field"
                rel = node._relation
                if rel is not None:
                    rel = str(node._relation)
                    label = f'[/"{node.name}:{type_str}\nfrom {rel}"\\]'
                else:
                    label = f'[/"{node.name}:\n{type_str}"\\]'
            elif isinstance(node, (mm.Lookup, mm.Aggregate, mm.Update)):
                arg_types = [self.resolve(arg) for arg in node.args]
                if node.id in self.resolved_placeholder:
                    overloads = self.resolved_placeholder[node.id]
                    content = "<br/>".join([reference_span(node, o, arg_types) for o in overloads])
                else:
                    content = reference_span(node, get_relation(node), arg_types)
                if isinstance(node, mm.Update):
                    klass = ":::update"
                    label = f'{{{{"{content}"}}}}'
                else:
                    klass = ":::reference"
                    label = f'[/"{content}"/]'
            else:
                raise NotImplementedError(f"Unknown node type: {type(node)}")
            if self.has_errors(node):
                klass = ":::error"
            node_strs.append(f'n{node.id}{label}{klass}')

        node_str = "\n                ".join(node_strs)
        link_str = "\n                ".join(link_strs)
        template = f"""
            %%{{init: {{'theme':'dark', 'flowchart':{{'useMaxWidth':false, 'htmlLabels': true}}}}}}%%
            flowchart TD
                linkStyle default stroke:#666
                classDef field fill:#245,stroke:#478
                classDef update fill:#245,stroke:#478
                classDef literal fill:#452,stroke:#784
                classDef error fill:#624,stroke:#945,color:#f9a
                classDef default stroke:#444,stroke-width:2px, font-size:12px

                %% nodes
                {node_str}

                %% edges
                {link_str}
        """
        return template

#--------------------------------------------------
# Analyzer
#--------------------------------------------------

class Analyzer(Walker):
    """ Walks the metamodel and builds the propagation network. """

    def __init__(self, net:PropagationNetwork):
        super().__init__()
        self.net = net
        # all fields that received an update somewhere in the model
        self.updated_fields = set()
        # edges between fields and lookups/aggregates reading from them; at the end, if the
        # field was written to (i.e. is in updated_fields), we add the edge to the network
        self.field_edges = []
        # lookups and aggregates that read from this var; used to ensure that population
        # lookups are resolved before any other task that reads from the same var, to ensure
        # that we know the narrowed type of the var before resolving the other tasks
        self.var_reads:dict[mm.Var, list[mm.Lookup|mm.Aggregate]] = defaultdict(lambda: list())

    def analyze(self, node: mm.Node):
        self(node)
        # if the field was updated somewhere, we need to resolve it before resolving
        # tasks that use it
        for field, task in self.field_edges:
            if field in self.updated_fields:
                self.net.add_edge(field, task)
        # add edges from population lookups to the tasks reading from the same vars
        for readers in self.var_reads.values():
            pop_lookups = list(filter(lambda t: isinstance(get_relation(t), mm.TypeNode), readers))
            for lookup in pop_lookups:
                for task in readers:
                    if task not in pop_lookups:
                        self.net.add_edge(lookup, task)

    def compute_potential_targets(self, relation: mm.Relation):
        # register potential targets for placeholders
        if bt.is_placeholder(relation):
            self.net.potential_targets[relation] = get_potential_targets(self.net.model, relation)

    #--------------------------------------------------
    # Walk Update
    #--------------------------------------------------

    def update(self, node: mm.Update):
        rel = node.relation
        self.compute_potential_targets(rel)

        is_population_update = isinstance(rel, mm.ScalarType)
        # arg is flowing into a field
        for arg, field in zip(node.args, rel.fields):
            self.updated_fields.add(field)
            if isinstance(arg, (mm.Var, mm.Literal)):
                if is_population_update:
                    # we want first to process the update because it will give a narrower
                    # type to the var in the arg
                    self.net.add_edge(node, arg)
                    self.net.add_edge(arg, field)
                else:
                    # we want to first process the arg to resolve its type, which may allow
                    # us to narrow the type of the field
                    self.net.add_edge(arg, node)
                    self.net.add_edge(node, field)

    #--------------------------------------------------
    # Walk Lookups + Aggregates
    #--------------------------------------------------

    def lookup(self, task: mm.Lookup):
        self.compute_potential_targets(task.relation)
        self.visit_rel_op(task)

    def aggregate(self, task: mm.Aggregate):
        self.visit_rel_op(task)

    def visit_rel_op(self, task: mm.Lookup|mm.Aggregate):
        relation = get_relation(task)

        is_placeholder = bt.is_placeholder(relation)
        for field, arg in zip(relation.fields, task.args):
            if isinstance(arg, (mm.Var, mm.Literal)):
                if field.input or isinstance(arg, mm.Literal):
                    # we need to resolve all inputs before resolving the relation
                    self.net.add_edge(arg, task)
                else:
                    self.var_reads[arg].append(task)
                    # placeholders also need the output to be resolved
                    if is_placeholder:
                        self.net.add_edge(arg, task)
                    else:
                        # args bound to outputs can be resolved after
                        self.net.add_edge(task, arg)
                        # if the field is abstract, it needs to be resolved before we can
                        # resolve the task. We delay actually adding an edge to the end
                        # because this is only valid if we are updating the field.
                        if bt.is_abstract(self.net.resolve(field)):
                            self.field_edges.append((field, task))


#--------------------------------------------------
# Replacer
#--------------------------------------------------

# Once we've pushed all the types through the network, we need to replace the types of
# fields and vars that we may have discovered. We also need to replace placeholder lookups
# with the chosen relations and do any conversions that are needed.
class Replacer(Rewriter):
    def __init__(self, net:PropagationNetwork):
        super().__init__()
        self.net = net
        # map from relation id to rewritten relation, to make sure that lookups/updates
        # point to the correct object in case we refined the relation field types
        self.relations:dict[int, mm.Relation] = {}
        # logicals created during rewriting (to inline only the ones we created)
        self.logicals = set()

    def rewrite(self, node: T) -> T:
        try:
            if isinstance(node, mm.Model):
                # first rewrite all relations to update their field types
                relations = self(node.relations) # type: ignore
                assert isinstance(relations, tuple)
                # index the rewritten relations
                self.relations = {r.id: r for r in relations}
                # then rewrite the root with the updated relations
                root = self(node.root) # type: ignore
                return node.mut(relations = relations, root = root)
            else:
                self.relations = {r.id: r for r in self.net.model.relations}
                return self(node)  # type: ignore
        finally:
            self.relations = {}
            self.logicals = set()

    def wrap(self, body: tuple) -> mm.Logical:
        """ Wrap the given body in a logical and track it for inlining later. """
        logical = mm.Logical(body)
        self.logicals.add(logical.id)
        return logical

    def logical(self, logical: mm.Logical):
        if len(logical.body) == 0:
            return logical
        # inline logicals that are just there to group other nodes during rewrite
        body = []
        for child in logical.body:
            if isinstance(child, mm.Logical) and not child.optional and not child.scope and child.id in self.logicals:
                body.extend(child.body)
            else:
                body.append(child)
        return logical.mut(body = tuple(body))

    #--------------------------------------------------
    # Rewriter handlers
    #--------------------------------------------------

    def field(self, node: mm.Field):
        if node.id in self.net.resolved_types:
            return node.mut(type = self.net.resolved_types[node.id])
        return node

    def var(self, node: mm.Var):
        if node.id in self.net.resolved_types:
            return mm.Var(self.net.resolved_types[node.id], node.name, source=node.source)
        return node

    def literal(self, node: mm.Literal):
        if node.id in self.net.resolved_types:
            return fix_literal(node, self.net.resolved_types[node.id])
        return node

    def update(self, node: mm.Update):
        return self.convert_arguments(node, node.relation)

    def aggregate(self, node: mm.Aggregate):
        return self.convert_arguments(node, node.aggregation)

    def lookup(self, node: mm.Lookup):
        # We need to handle eq specially because its arguments can be converted symmetrically
        if node.relation == b.core.eq:
            return self.visit_eq_lookup(node)

        args = types = None
        if node.id in self.net.resolved_placeholder:
            # placeholder resolved to multiple relations
            resolved_relations = self.net.resolved_placeholder[node.id]
            args = get_lookup_args(node, resolved_relations[0])
            types = [f.type for f in resolved_relations[0].fields]
        elif node.id in self.net.resolved_overload:
            # overload resolved to a specific relation
            resolved_relations = [node.relation]
            types = self.net.resolved_overload[node.id].types
        else:
            # single relation
            resolved_relations = [node.relation]

        if len(resolved_relations) == 1:
            # single relation, just convert arguments
            x = self.convert_arguments(node, resolved_relations[0], args, types)
            if isinstance(x, mm.Logical) and len(x.body) == 1:
                return x.body[0]
            else:
                return x

        # multiple relations, create a union
        branches:list = []
        for target in resolved_relations:
            args = get_lookup_args(node, target)
            types = [f.type for f in get_relation_fields(resolved_relations[0], node.relation.name)]
            # adding this logical to avoid issues in the old backend
            branches.append(self.wrap((self.convert_arguments(node, target, args, types=types, force_copy=True),)))
        outputs = tuple(arg for arg in node.args[-1:] if isinstance(arg, mm.Var))
        assert len(outputs) == len(node.args[-1:]), "Union outputs must be Vars."
        return mm.Union(tuple(branches), outputs=outputs)

    def convert_arguments(self, node: mm.Lookup|mm.Update|mm.Aggregate, relation: mm.Relation, args: Iterable[mm.Value]|None=None, types: Iterable[mm.Type]|None=None, force_copy=False) -> mm.Logical|mm.Lookup|mm.Update|mm.Aggregate:
        """ This node was resolved to target this relation using these args, which should
        have these types. Convert any arguments as needed and return a new node with the
        proper relation and converted args. If multiple conversions are needed, return a
        logical that contains all the conversion tasks plus the final node. """
        # ensure we use the rewritten relation if available
        if relation.id in self.relations:
            relation = self.relations[relation.id]
        args = args or node.args
        types = types or [self.net.resolve(f) for f in relation.fields]
        number_type = self.net.resolved_number.get(node.id)
        is_function = bt.is_function(relation)
        tasks = []
        final_args = []
        for arg, field, field_type in zip(args, relation.fields, types):
            if isinstance(arg, (mm.Var, mm.Literal)) and (not is_function or field.input):
                arg_type = to_type(arg)
                if number_type and (bt.is_number(arg_type) or bt.is_number_value_type(arg_type)) and not arg_type == b.core.ScaledNumber:
                    field_type = number_type
                # the typer previously made sure that this should be valid so a type mismatch
                # means we need to convert
                if not type_matches(arg_type, field_type):
                    final_args.append(convert(arg, field_type, tasks))
                else:
                    final_args.append(arg)
            else:
                final_args.append(arg)
        # add the original node with the proper target relation and converted args;
        # here we want to use mut because we keep information about nodes based on their ids
        # (e.g. we store resolved types based on ids), so we want to keep the same id. But
        # when a lookup is being converted as part of a union (i.e. multiple targets for a
        # placeholder), we need to create nodes with new ids to avoid conflicts.
        if force_copy:
            tasks.append(node.replace(relation = relation, args = tuple(final_args)))
        else:
            if isinstance(node, mm.Aggregate):
                # for aggregates, we need to insert the conversion tasks in the body of the
                # aggregate; if it is a logical we extend, otherwise we create a new logical
                if isinstance(node.body, mm.Logical):
                    body = node.body.mut(body = node.body.body + tuple(tasks))
                else:
                    body = mm.Logical(tuple(tasks) + (node.body,))
                tasks = [node.mut(
                    aggregation = relation,
                    args = tuple(final_args),
                    body = body
                )]
            else:
                tasks.append(node.mut(relation = relation, args = tuple(final_args)))
        # if we need conversion tasks, wrap in a logical
        if len(tasks) == 1:
            return tasks[0]
        return self.wrap(tuple(tasks))

    def add_task(self, container: mm.Node, task: mm.Task):
        if isinstance(container, mm.Logical):
            return container.mut(body = container.body + (task,))
        else:
            return self.wrap((container, task))

    def visit_eq_lookup(self, node: mm.Lookup):
        (left, right) = node.args
        left_type = to_type(left)
        right_type = to_type(right)

        if type_matches(left_type, right_type):
            return node

        assert isinstance(left, (mm.Var, mm.Literal)) and isinstance(right, (mm.Var, mm.Literal))
        final_args = []
        tasks = []
        if conversion_allowed(left_type, right_type):
            final_args = [convert(left, right_type, tasks), right]
        elif conversion_allowed(right_type, left_type):
            final_args = [left, convert(right, left_type, tasks)]
        else:
            # this type mismatch was reported during propagation, so just return the node
            return node

        tasks.append(mm.Lookup(b.core.eq, tuple(final_args)))
        return self.wrap(tuple(tasks))

#--------------------------------------------------
# Helpers
#--------------------------------------------------

def get_relation(node: mm.Lookup|mm.Update|mm.Aggregate) -> mm.Relation:
    if isinstance(node, mm.Aggregate):
        return node.aggregation
    return node.relation

def get_name(type: mm.Type) -> str:
    if isinstance(type, mm.ScalarType):
        return type.name
    elif isinstance(type, mm.UnionType):
        return '|'.join([get_name(t) for t in type.types])
    elif isinstance(type, mm.ListType):
        return f'List[{get_name(type.element_type)}]'
    elif isinstance(type, mm.TupleType):
        return f'Tuple[{", ".join([get_name(t) for t in type.element_types])}]'
    else:
        raise TypeError(f"Unknown type: {type}")

#--------------------------------------------------
# Type and Relation helpers
#--------------------------------------------------

def get_update_fields(arg, update: mm.Update) -> Iterable[mm.Field]:
    """Get the fields of the relation being updated by this arg. Note that an arg can be
    bound to multiple fields at the same time.

    Uses identity (``is``) rather than ``==``: ``mm.Literal`` has value-based equality,
    so ``==`` would entangle distinct literal nodes that happen to share a value and
    let their inferred types leak across positional slots.
    """
    for x, field in zip(update.args, update.relation.fields):
        if arg is x:
            yield field

def get_relation_fields(relation: mm.Relation, name: str) -> Iterable[mm.Field]:
    """ Get the fields of this relation, potentially reordered to match the reading with the given name."""
    if name == relation.name:
        return relation.fields
    for reading in relation.readings:
        if reading.name == name:
            # reorder the fields to match the correct ordering
            fields = []
            for idx in reading.field_order:
                fields.append(relation.fields[idx])
            return fields
    return []

def get_lookup_args(node: mm.Lookup, target: mm.Relation):
    """ Get the args of this lookup, potentially reordered to match the reading with the given name."""
    for reading in target.readings:
        if reading.name == node.relation.name:
            # reorder the args to match the correct ordering
            args = []
            for idx in reading.field_order:
                args.append(node.args[idx])
            return args
    return node.args

def get_number_type(t: mm.Type) -> mm.NumberType:
    # Get a number type from the given type, if it is Number return the default number
    x = bt.get_number_supertype(t)
    if isinstance(x, mm.NumberType):
        return x
    return b.core.DefaultNumber

def is_potential_target(placeholder: mm.Relation, target: mm.Relation) -> bool:
    """ Whether this target is matches the placeholder signature and, thus, can be a potential target. """
    if placeholder != target and len(placeholder.fields) == len(target.fields) and not bt.is_placeholder(target):
        return placeholder.name == target.name or any(placeholder.name == reading.name for reading in target.readings)
    return False

def get_potential_targets(model: mm.Model, placeholder: mm.Relation) -> list[mm.Relation]:
    """ Get all potential target relations in the model that match the placeholder signature. """
    return list(filter(lambda r: is_potential_target(placeholder, r), model.relations))

def fix_literal(value: mm.Literal, to_type: mm.Type):
    if to_type == b.core.Float and isinstance(value.value, (Decimal, int)):
        return mm.Literal(to_type, float(value.value))
    return mm.Literal(to_type, value.value)

def to_type(value: mm.Value|mm.Field|mm.Literal) -> mm.Type:
    if isinstance(value, (mm.Var, mm.Literal)):
        return value.type

    if isinstance(value, mm.Type):
        return b.core.Type

    if isinstance(value, mm.Field):
        return b.core.Field

    if isinstance(value, mm.Relation):
        return b.core.Relation

    if isinstance(value, tuple):
        return mm.TupleType(element_types=tuple(to_type(v) for v in value))

    raise TypeError(f"Cannot determine IR type for value: {value} of type {type(value).__name__}")

def convert(value: mm.Var|mm.Literal, to_type: mm.Type, tasks: list[mm.Task]) -> mm.Value:
    # if the arg is a literal, we can just change its type
    if isinstance(value, mm.Literal):
        return fix_literal(value, to_type)

    # cannot convert unless the target is scalar
    if not isinstance(to_type, mm.ScalarType):
        return value

    # otherise we need to add a cast
    name = sanitize(value.name + "_" + get_name(to_type))
    to_type_base = bt.get_primitive_supertype(to_type) or to_type
    new_value = mm.Var(to_type_base, name)
    tasks.append(mm.Lookup(b.core.cast, (to_type_base, value, new_value)))
    return new_value

def conversion_allowed(from_type: mm.Type, to_type: mm.Type) -> bool:
    # value type conversion is allowed only if the value types are related by inheritance
    if bt.is_value_type(from_type) and bt.is_value_type(to_type) and not bt.extends(from_type, to_type):
        return False
    # value type conversion is allowed
    x = bt.get_primitive_supertype(from_type)
    y = bt.get_primitive_supertype(to_type)
    if x and y and (x != from_type or y != to_type) and conversion_allowed(x, y):
        return True

    # numbers can be converted to floats
    if bt.is_numeric(from_type) and to_type == b.core.Float:
        return True

    # a number can be converted to another number of larger scale
    if isinstance(from_type, mm.NumberType) and isinstance(to_type, mm.NumberType):
        if to_type.scale >= from_type.scale:
            return True

    if from_type == b.core.Number and isinstance(to_type, mm.NumberType):
        return True

    # if we are converting to AnyEntity, the from_type must be only entities
    if bt.extends(to_type, b.core.AnyEntity):
        if bt.is_entity_type(from_type):
            return True
        if isinstance(from_type, mm.UnionType):
            for t in from_type.types:
                if not bt.is_entity_type(t):
                    return False
            return True

    return False

def type_narrows(narrow: mm.Type, broad: mm.Type) -> bool:
    """ True if the narrow type is an equal or more precise type than the broad type. """
    if narrow == broad:
        return True

    # if narrow is a union, all components must narrow the broad type
    if isinstance(narrow, mm.UnionType):
        for n in narrow.types:
            if not type_narrows(n, broad):
                return False
        return True

    # if broad is a union, narrow must narrow all of them
    if isinstance(broad, mm.UnionType):
        for b in broad.types:
            if not type_narrows(narrow, b):
                return False
        return True

    # if both are scalar types, narrow must extend broad
    if isinstance(narrow, mm.ScalarType) and isinstance(broad, mm.ScalarType):
        return bt.extends(narrow, broad)

    return False


def type_matches(actual: mm.Type, expected: mm.Type, accept_expected_super_types=False) -> bool:
    """
    True iff we can use a value of the actual type when expecting the expected type, without
    conversions.

    Any super-type of `actual` can match `expected`. For example if we expect a `Person`, we
    can use an `Employee` if `Employee < Person`.

    In general, the other way around is not true: if we expect an `Employee` we cannot use a
    `Person` instead.

    However, when the relation is a Type (previsously known as "population relations"), it
    is valid to provide sub-types of the expected type. For example, `Employee(Person)` is
    a valid way to check that `Person` is an `Employee` on a `Lookup`, or to assert that a
    particular `Person` is an `Employee` on an `Update`.
    """
    # exact match
    if actual == expected:
        return True

    # any matches anything
    if actual == b.core.Any or expected == b.core.Any:
        return True

    # type vars match anything
    if expected == b.core.TypeVar:
        return True

    # if an entity type var or any entity is expected, it matches any actual entity type
    if (expected == b.core.EntityTypeVar or (accept_expected_super_types and bt.extends(expected, b.core.AnyEntity))) and not bt.is_primitive(actual):
        return True

    # the abstract Number type and the number type variable match any number type
    if (expected == b.core.Number) and bt.is_number(actual):
        return True

    if (expected == b.core.Numeric) and bt.is_numeric(actual):
        return True

    # different value types never match
    if bt.is_value_type(actual) and bt.is_value_type(expected) and not bt.extends(actual, expected):
        return False

    # if actual is scalar, any of its parents may match the expected type
    if isinstance(actual, mm.ScalarType) and any([type_matches(parent, expected) for parent in actual.super_types]):
        return True

    # if expected is a value type or this is a check for a type relation, any of the expected type's parents may match the actual type
    if (accept_expected_super_types or bt.is_value_type(expected)) and isinstance(expected, mm.ScalarType) and any([type_matches(actual, parent, accept_expected_super_types) for parent in expected.super_types]):
        return True

    # if we expect a union, the actual can match any of its types
    if isinstance(expected, mm.UnionType):
        for t in expected.types:
            if type_matches(actual, t, accept_expected_super_types):
                return True

    # if actual is a union, every one of its types must match the expected type
    # if isinstance(actual, mm.UnionType):
    #     for t in actual.types:
    #         if not type_matches(t, expected, accept_expected_super_types):
    #             return False
    #     return True
    # TODO - we have to distinguish between when we are checking that a specific arg matches
    # a relation vs when we are selecting relations for the placeholders; then we have to
    # decide between the above and this.
    if isinstance(actual, mm.UnionType):
        for t in actual.types:
            if type_matches(t, expected, accept_expected_super_types):
                return True

    # a list type matches if their element types match
    if isinstance(actual, (mm.ListType, mm.TupleType)) and isinstance(expected, mm.ListType):
        if isinstance(actual, mm.TupleType):
            for et in actual.element_types:
                if not type_matches(et, expected.element_type):
                    return False
            return True
        return type_matches(actual.element_type, expected.element_type)

    # a tuple types match if any of all their types match
    if isinstance(actual, mm.TupleType) and isinstance(expected, mm.TupleType):
        return all([type_matches(ae, ee) for ae, ee in zip(actual.element_types, expected.element_types)])

    # accept tuples with a single element type to match a list with that type
    if isinstance(actual, mm.TupleType) and isinstance(expected, mm.ListType):
        return type_matches(actual.element_types[0], expected.element_type)

    # otherwise no match
    return False

def merge_numeric_types(type1: mm.Type, type2: mm.Type) -> Optional[mm.Type]:
    # if one of them is the abstract Number type, pick the other
    if type1 == b.core.Number and isinstance(type2, mm.NumberType):
        return type2
    if type2 == b.core.Number and isinstance(type1, mm.NumberType):
        return type1

    # if both are number types, pick the one with larger scale/precision
    if isinstance(type1, mm.NumberType) and isinstance(type2, mm.NumberType):
        if type1.scale > type2.scale or (type1.scale == type2.scale and type1.precision > type2.precision):
            return type1
        else:
            return type2

    # if we are overriding a number with a float, pick float
    if isinstance(type1, mm.NumberType) and type2 == b.core.Float:
        return type2
    if isinstance(type2, mm.NumberType) and type1 == b.core.Float:
        return type1

    return None

def merge_types(type1: mm.Type, type2: mm.Type) -> mm.Type:
    if type1 == type2:
        return type1
    if bt.is_type_var(type1):
        return type2
    if bt.is_type_var(type2):
        return type1

    types_to_process = [type1, type2]

    numeric_merge = merge_numeric_types(type1, type2)
    if numeric_merge is not None:
        return numeric_merge

    # if one extends the other, pick the most specific one
    if bt.extends(type1, type2):
        return type1
    if bt.extends(type2, type1):
        return type2

    if not (bt.is_value_type(type1) and bt.is_value_type(type2)):
        # cannot merge different value types, but if one of them is a value type,
        # give precedence to it (e.g. merging USD(decimal) with decimal gives USD(decimal))
        base_primitive_type1 = bt.get_primitive_supertype(type1)
        base_primitive_type2 = bt.get_primitive_supertype(type2)
        if base_primitive_type1 == base_primitive_type2:
            if bt.is_primitive(type1):
                return type2
            elif bt.is_primitive(type2):
                return type1

        if base_primitive_type1 and base_primitive_type2 :
            numeric_merge = merge_numeric_types(base_primitive_type1, base_primitive_type2)
            if numeric_merge == base_primitive_type1:
                return type1
            elif numeric_merge == base_primitive_type2:
                return type2

    combined = OrderedSet()
    # Iterative flattening of union types
    while types_to_process:
        t = types_to_process.pop()
        if isinstance(t, mm.UnionType):
            types_to_process.extend(t.types)
        else:
            combined.add(t)

    # If we have multiple types and Any or AnyEntity is one of them, remove Any
    if len(combined) > 1:
        if b.core.Any in combined:
            combined.remove(b.core.Any)
        if b.core.AnyEntity in combined:
            combined.remove(b.core.AnyEntity)

    # If we still have multiple types, make sure supertypes are removed to keep only the
    # most specific types
    if len(combined) > 1:
        to_remove = set()
        for t1 in combined:
            for t2 in combined:
                if t1 != t2 and bt.extends(t1, t2):
                    to_remove.add(t2)
        for r in to_remove:
            combined.remove(r)

    # Return single type or create a union
    return next(iter(combined)) if len(combined) == 1 else mm.UnionType(types=tuple(combined))

def invalid_type(type:mm.Type) -> bool:
    if isinstance(type, mm.UnionType):
        # if there are multiple primitives, or a primitive and a non-primitive
        # then we have an invalid type
        if len(type.types) > 1:
            return any([bt.is_primitive(t) or bt.is_value_type(t) for t in type.types])
    return False


#--------------------------------------------------
# Type Errors
#--------------------------------------------------

@dataclass
class TyperError():
    node: mm.Node

    def report(self):
        err(self.name(), self.message(), self.parts())

    def name(self) -> str:
        return type(self).__name__

    def message(self) -> str:
        raise NotImplementedError()

    def parts(self) -> list[Part]:
        if self.node.source is None:
            return [str(self.node)]
        return [str(self.node), Source(self.node.source)]

@dataclass
class TypeMismatch(TyperError):
    expected: mm.Type
    actual: mm.Type

    def message(self) -> str:
        return f"Expected '{get_name(self.expected)}', got '{get_name(self.actual)}'"

@dataclass
class InvalidType(TyperError):
    type: mm.Type

    def message(self) -> str:
        return f"Incompatible types infered: {get_name(self.type)}"

@dataclass
class UnresolvedOverload(TyperError):
    arg_types: list[mm.Type]

    def message(self) -> str:
        assert isinstance(self.node, (mm.Lookup, mm.Update, mm.Aggregate))
        rel = get_relation(self.node)
        types = ', '.join([get_name(t) for t in self.arg_types])
        return f"Unresolved overload: '{rel.name}({types})'"

@dataclass
class UnresolvedType(TyperError):
    arg: mm.Var

    def message(self) -> str:
        return f"Unable to determine concrete type for argument '{self.arg.name}'."
