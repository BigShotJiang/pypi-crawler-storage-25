"""
LQP Debug Primitives — call server-side debug/diagnostic primitives from PyRel.

Overview
--------
``lqp_debug_call(name, *args)`` lets you invoke Rel primitives such as
``rel_primitive_debug_sleep`` directly from the PyRel DSL.  The result is a
normal Expression you can pass to ``relationalai.semantics.select()``::

    from relationalai.semantics import Model, select
    from relationalai.semantics.experimental._internal_debug import lqp_debug_call

    Model("my_model")
    select(lqp_debug_call("sleep", 10)).inspect()

Design constraints & key decisions
-----------------------------------

1. **Registering as a v0 builtin.**
   Library.Relation() automatically registers the relation in the v1 builtins.
   However, the v0 LQP compiler has its *own* ``is_builtin()`` check that
   decides whether a relation compiles to an LQP ``primitive`` node (correct)
   or a regular ``atom`` node (wrong — the server wouldn't recognise it).
   We therefore monkey-patch ``v0_builtins.is_builtin`` at import time so our
   debug relations are treated as primitives.  Only the debug *primitive*
   relations are patched; the intermediate arg relations are intentionally left
   unpatched so they compile to atoms.

2. **Preventing constant-folding (the "2× sleep" bug).**
   If the primitive's arguments are inlined as literal constants in the LQP::

       (def :output ([result::INT] (primitive :rel_primitive_debug_sleep 3 result)))

   the server's constant-folder will evaluate the primitive at compile time
   *and* at read time, causing side-effecting primitives like sleep to execute
   twice.  To prevent this we define each argument in a separate model relation
   (via ``model.define()``) and pass the *variable reference* to the primitive
   instead::

       ;; model epoch — argument intermediates
       (def :_debug_arg_sleep_1_0 ([value::INT] (= value 3)))

       ;; query epoch
       (def :output ([result::INT]
           (exists [value::INT]
               (and (atom :_debug_arg_sleep_1_0 value)
                    (primitive :rel_primitive_debug_sleep value result)))))

   Ideally the intermediates would live in the *query* fragment (local to the
   epoch), but the LQP rewrite passes (e.g. ``ExtractKeys``) do not expect
   ``Update`` nodes in a query context, so we use ``model.define()`` which
   places them in the model epoch.  Each call gets a unique counter id so
   successive calls do not collide.

3. **Matching the server's type signature.**
   The server's debug primitives are typed — ``rel_primitive_debug_sleep``
   expects ``(Int64, Int64)``.  We pick the DSL type from the Python value:
   ``int`` → ``Int64``, ``float`` → ``Float``.  Using the generic ``Numeric``
   type maps to ``Int128`` on the wire, which the server rejects.  The
   primitive relation is cached per ``(name, type_names)`` so a single
   function name can have overloads for different type combinations.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from relationalai.semantics.frontend.base import Relationship

#------------------------------------------------------
# LQP Debug Primitives
#------------------------------------------------------

_debug_library = None
_debug_relations: dict[tuple, "Relationship"] = {}
_debug_call_counter = 0

def _get_debug_library():
    global _debug_library
    if _debug_library is None:
        from relationalai.semantics.frontend.base import Library
        _debug_library = Library("lqp_debug")
    return _debug_library

def _type_for_value(value):
    """Return the appropriate DSL type for a Python value."""
    from relationalai.semantics.frontend.core import Int64, Float
    if isinstance(value, float):
        return Float
    return Int64

def _get_debug_relation(function_name: str, arg_types: tuple) -> "Relationship":
    """Get or create a Library Relationship for the given debug primitive and arg types."""
    from relationalai.semantics.frontend.base import Field

    type_names = tuple(t._name for t in arg_types)
    key = (function_name, type_names)
    if key not in _debug_relations:
        fields = [Field.input(f"arg{i}", t) for i, t in enumerate(arg_types)]
        fields.append(Field("result", arg_types[0] if arg_types else _type_for_value(0)))
        rel = _get_debug_library().Relation(
            f"rel_primitive_debug_{function_name}",
            fields,
        )
        # Also register in v0 builtins so the LQP translator recognizes it as a primitive
        _register_v0_builtin(rel)
        _debug_relations[key] = rel
    return _debug_relations[key]

def _make_arg_relation(function_name: str, call_id: int, arg_index: int, typ) -> "Relationship":
    """Create a Library Relationship that holds a single argument value."""
    from relationalai.semantics.frontend.base import Field

    return _get_debug_library().Relation(
        f"_debug_arg_{function_name}_{call_id}_{arg_index}",
        [Field("value", typ)],
    )

_patched_v0_is_builtin = False
_debug_primitive_names: set[str] = set()

def _register_v0_builtin(rel: "Relationship") -> None:
    """Patch v0's is_builtin to recognize our debug primitives by name."""
    global _patched_v0_is_builtin
    from v0.relationalai.semantics.metamodel import builtins as v0_builtins

    lib = _get_debug_library()
    v1_relation = lib._compiler.to_relation(rel)
    _debug_primitive_names.add(v1_relation.name)

    if not _patched_v0_is_builtin:
        _orig_is_builtin = v0_builtins.is_builtin
        def _patched(r):
            if r.name in _debug_primitive_names:
                return True
            return _orig_is_builtin(r)
        v0_builtins.is_builtin = _patched
        _patched_v0_is_builtin = True

def lqp_debug_call(function_name: str, *args: int | float | str):
    """Emit an LQP debug primitive call.

    Returns an Expression that can be used in select(), define(), where(), etc.

    Each argument is defined in an intermediate model relation so that the
    server cannot constant-fold literals into the primitive body (which would
    cause side-effecting primitives to be evaluated twice).

    Example: ``relationalai.semantics.select(lqp_debug_call("sleep", 10)).inspect()``
    """
    from relationalai.semantics import _check_model

    global _debug_call_counter
    _debug_call_counter += 1
    call_id = _debug_call_counter

    model = _check_model()
    arg_types = tuple(_type_for_value(a) for a in args)

    # Define each argument in an intermediate relation on the model so that
    # the primitive receives a variable reference, not an inlined constant.
    arg_refs = []
    for i, arg in enumerate(args):
        arg_rel = _make_arg_relation(function_name, call_id, i, arg_types[i])
        model.define(arg_rel(arg))
        arg_refs.append(arg_rel)

    # Call the primitive with the intermediate references
    prim_rel = _get_debug_relation(function_name, arg_types)
    return prim_rel(*arg_refs)
