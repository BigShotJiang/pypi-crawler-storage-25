"""Prescriptive reasoning: define and solve decision problems.

Provides a declarative Python API for formulating decision problems — optimization,
constraint satisfaction, or feasibility — and solving them with external solvers
(HiGHS, Gurobi, Ipopt, MiniZinc, etc.).

## Quick Start

A small knapsack: pick how many of each item to take to maximize value
without exceeding the weight budget.

```python
from relationalai.semantics import Model, Float, Integer, sum
from relationalai.semantics.reasoners.prescriptive import Problem

model = Model("knapsack")

# Data: items with weight and value.
Item = model.Concept("Item", identify_by={"i": Integer})
Item.weight = model.Property(f"{Item} has {Float:weight}")
Item.value = model.Property(f"{Item} has {Float:value}")
model.define(Item.new(i=0, weight=3.0, value=4.0))
model.define(Item.new(i=1, weight=4.0, value=5.0))
model.define(Item.new(i=2, weight=2.0, value=3.0))

# Decision variable: quantity of each item to take.
Item.qty = model.Property(f"{Item} has {Float:qty}")

problem = Problem(model, Float)  # Float for HiGHS/Gurobi/Ipopt, Integer for MiniZinc
problem.solve_for(Item.qty, name=["qty", Item.i], lower=0, upper=10)
problem.maximize(sum(Item.value * Item.qty))
problem.satisfy(model.require(sum(Item.weight * Item.qty) <= 10))
problem.solve("highs")

# Read solved values from the populated property.
model.select(Item.i, Item.qty).inspect()
```
"""

from __future__ import annotations

from .problem import Problem, SolveInfoData, make_name
from .components import ProblemConstraint, ProblemObjective, ProblemVariable
from .constraints import all_different, implies, special_ordered_set_type_1, special_ordered_set_type_2

# Include this package in the docs
__include_in_docs__ = True

# Package version.
__version__ = "0.0.0"

__all__ = [
    "Problem",
    "ProblemConstraint",
    "ProblemObjective",
    "ProblemVariable",
    "SolveInfoData",
    "all_different",
    "implies",
    "make_name",
    "special_ordered_set_type_1",
    "special_ordered_set_type_2",
]
