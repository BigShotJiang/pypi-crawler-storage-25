"""Problem components: variable, objective, and constraint Concept subtypes.

Defines the restricted Concept subtypes returned by :meth:`Problem.solve_for`,
:meth:`Problem.minimize`, :meth:`Problem.maximize`, and :meth:`Problem.satisfy`.
"""

from __future__ import annotations

from typing import Any

from relationalai.semantics.frontend import base as b


def _priv(obj: Any, attr: str) -> Any:
    """Read a private field stored via ``object.__setattr__``, bypassing Concept attribute machinery.

    ``b.Concept`` overrides attribute access to dispatch to its relationships /
    properties, so ``self._dsl_expr`` would not return the value placed there
    by ``object.__setattr__``. ``object.__getattribute__`` reads straight from
    the instance ``__dict__`` and avoids that dispatch.
    """
    return object.__getattribute__(obj, attr)


class _ProblemConcept(b.Concept):
    """Base for solver-managed Concept subtypes (variables, objectives, constraints).

    Subclasses ARE Concepts — ``model.define()``, ``model.select()``, and
    ``.ref()`` work directly — but are not general-purpose: custom properties
    and ``.new()`` are disallowed to prevent misuse.
    """

    _ALLOWED_PROPERTIES: frozenset[str] = frozenset()

    def __setattr__(self, name: str, value: Any) -> None:
        if isinstance(value, b.Relationship) and name.lower() not in self._ALLOWED_PROPERTIES:
            cls_name = type(self).__name__
            allowed = ", ".join(sorted(self._ALLOWED_PROPERTIES))
            raise TypeError(f"Cannot add property '{name}' to {cls_name}. Allowed properties: {allowed}.")
        super().__setattr__(name, value)

    def _new(self, *args: Any, **kwargs: Any) -> Any:
        """Internal: Problem machinery creates instances via this method."""
        return super().new(*args, **kwargs)

    def new(self, *args: Any, **kwargs: Any) -> Any:
        cls_name = type(self).__name__
        raise TypeError(
            f"Cannot create {cls_name} instances directly. "
            f"Use Problem.solve_for(), Problem.satisfy(), "
            f"Problem.minimize(), or Problem.maximize()."
        )


class ProblemVariable(_ProblemConcept):
    """Variable subconcept returned by :meth:`Problem.solve_for`.

    **Engine-side Properties** (queryable via ``model.select(...).where(...)``):

    - ``name``, ``lower``, ``upper``, ``start`` — settable via ``model.define()``.
    - ``type`` — set at construction by ``solve_for(type=...)``.
    - ``values`` — read-only arity-2 Property mapping ``(sol_index, value)``,
      0-based, populated after ``solve()``. Query via::

          sol_idx, val = Integer.ref(), Float.ref()
          model.select(sol_idx, val).where(var.values(sol_idx, val))

      To get values for a specific solution ``k``::

          model.select(val).where(var.values(k, val))

    **Python @property accessors** (construction metadata, evaluated in Python):
    :attr:`dsl_expr`, :attr:`concept_name`, :attr:`property_name`,
    :attr:`var_type`, :attr:`var_where`, :attr:`populate`. These return Python
    values (not Relationships) and are distinct from the engine-side Properties
    above — note ``var_type`` (Python) vs ``type`` (engine) and that ``name``
    has no Python accessor (query it engine-side).
    """

    _ALLOWED_PROPERTIES = frozenset({"name", "type", "lower", "upper", "start", "values"})

    def __init__(
        self,
        name: str,
        extends: list,
        identify_by: dict,
        model: b.Model,
        *,
        dsl_expr: Any,
        concept_name: str | None,
        property_name: str,
        var_type: str,
        var_where: tuple | None,
        populate: bool,
    ) -> None:
        super().__init__(name, extends, identify_by, model)
        object.__setattr__(self, "_dsl_expr", dsl_expr)
        object.__setattr__(self, "_concept_name", concept_name)
        object.__setattr__(self, "_property_name", property_name)
        object.__setattr__(self, "_var_type", var_type)
        object.__setattr__(self, "_var_where", var_where)
        object.__setattr__(self, "_populate", populate)

    @property
    def dsl_expr(self) -> Any:
        """Original DSL expression passed to ``solve_for()``."""
        return _priv(self, "_dsl_expr")

    @property
    def concept_name(self) -> str | None:
        """Concept name (e.g. ``"Food"`` for ``Food.amount``), or None for scalars."""
        return _priv(self, "_concept_name")

    @property
    def property_name(self) -> str:
        """Property name (e.g. ``"amount"``)."""
        return _priv(self, "_property_name")

    @property
    def var_type(self) -> str:
        """Variable type: ``"cont"``, ``"int"``, or ``"bin"``."""
        return _priv(self, "_var_type")

    @property
    def var_where(self) -> tuple | None:
        """Where conditions restricting which variable instances are created."""
        return _priv(self, "_var_where")

    @property
    def populate(self) -> bool:
        """Whether solved values are written back to the relationship."""
        return _priv(self, "_populate")

    def __repr__(self) -> str:
        label = repr(_priv(self, "_dsl_expr"))
        parts = [f"ProblemVariable({label}"]
        var_type = _priv(self, "_var_type")
        var_where = _priv(self, "_var_where")
        if var_type:
            parts.append(f", type={var_type!r}")
        if var_where:
            parts.append(f", where=[{', '.join(repr(w) for w in var_where)}]")
        return "".join(parts) + ")"


class ProblemObjective(_ProblemConcept):
    """Objective subconcept returned by :meth:`Problem.minimize` / :meth:`Problem.maximize`.

    Settable properties (via ``model.define()``): ``name``.

    Managed by Problem: ``root``, ``type``, ``sense``. The ``sense``
    Property holds ``"minimize"`` or ``"maximize"`` and is queryable
    engine-side via ``Problem.Objective.sense``.

    Python ``@property`` accessors: :attr:`dsl_expr` (the original
    expression passed to ``minimize()``/``maximize()``) and :attr:`sense`
    (``"minimize"`` or ``"maximize"``). For introspection and tooling.
    """

    _ALLOWED_PROPERTIES = frozenset({"root", "name", "type"})

    def __init__(
        self,
        name: str,
        extends: list,
        identify_by: dict,
        model: b.Model,
        *,
        dsl_expr: Any,
        sense: str,
    ) -> None:
        super().__init__(name, extends, identify_by, model)
        object.__setattr__(self, "_dsl_expr", dsl_expr)
        object.__setattr__(self, "_sense", sense)

    @property
    def dsl_expr(self) -> Any:
        """Original DSL expression passed to ``minimize()`` or ``maximize()``."""
        return _priv(self, "_dsl_expr")

    @property
    def sense(self) -> str:
        """Objective sense: ``"minimize"`` or ``"maximize"``."""
        return _priv(self, "_sense")

    def __repr__(self) -> str:
        sense = _priv(self, "_sense")
        expr_str = repr(_priv(self, "_dsl_expr"))
        return f"ProblemObjective({sense}, expr={expr_str})"


class ProblemConstraint(_ProblemConcept):
    """Constraint subconcept returned by :meth:`Problem.satisfy`.

    Settable properties (via ``model.define()``): ``name``.

    Managed by Problem: ``root``, ``type``.

    Python ``@property`` accessor: :attr:`dsl_expr` exposes the original
    fragment passed to ``satisfy()``. For introspection and tooling.
    """

    _ALLOWED_PROPERTIES = frozenset({"root", "name", "type"})

    def __init__(
        self,
        name: str,
        extends: list,
        identify_by: dict,
        model: b.Model,
        *,
        dsl_expr: Any,
    ) -> None:
        super().__init__(name, extends, identify_by, model)
        object.__setattr__(self, "_dsl_expr", dsl_expr)

    @property
    def dsl_expr(self) -> Any:
        """Original DSL expression passed to ``satisfy()``."""
        return _priv(self, "_dsl_expr")

    def __repr__(self) -> str:
        expr_str = repr(_priv(self, "_dsl_expr"))
        return f"ProblemConstraint(expr={expr_str})"
