"""Display formatting: AST/variable/expression → human-readable strings.

Converts AST DataFrames (queried from the model) into human-readable
expression strings for ``Problem.display()``. The formatting functions
are pure — they take DataFrames and return strings, with no model or
engine dependencies.
"""

from __future__ import annotations

import re
import textwrap
from collections import defaultdict
from dataclasses import dataclass
from typing import Any

from pandas import DataFrame

from .wire_format import (
    _CODE_TO_NAME,
    _EXPR_CODES,
    _EXPR_TYPE_LABELS,
    _HIGHER_ORDER_CODES,
    _INFIX,
    _INFIX_AND_CMP,
)

_MAX_FMT_DEPTH = 400

# Default wrap width for expression formatting. Fixed (not terminal-derived) so the
# returned string from ``Problem.display(print_output=False)`` is deterministic across
# environments — golden-file tests, captured logs, and downstream parsers all see the
# same output regardless of the caller's terminal size.
_DEFAULT_WIDTH = 100

_NAT_SPLIT = re.compile(r"(\d+)")


def _require_columns(df: DataFrame, name: str, required: tuple[str, ...]) -> None:
    """Raise ``ValueError`` if *df* is missing any of *required* columns.

    Completely empty DataFrames (no rows and no columns) are allowed
    because ``model.select(...).to_df()`` can return such a frame when
    the query has no results — the ``.alias()`` hints don't materialize
    columns in that case. DataFrames with *some* columns are validated
    strictly so fixture/query mismatches still fail fast.
    """
    if df.empty and len(df.columns) == 0:
        return
    missing = [col for col in required if col not in df.columns]
    if missing:
        raise ValueError(
            f"AstQueryResults.{name}: missing required column(s) {missing}; got columns {list(df.columns)}"
        )


@dataclass(frozen=True)
class AstQueryResults:
    """The four AST query result DataFrames consumed by ``format_ast_to_strings``.

    Constructed by ``Problem._query_ast``. The ``__post_init__`` validator
    fails fast if any DataFrame is missing its expected columns, which
    catches fixture/query mismatches at construction time instead of
    producing cryptic ``KeyError`` failures deep inside the formatter.
    """

    operators: DataFrame
    ordered_hash: DataFrame
    ordered_data: DataFrame
    unordered: DataFrame

    def __post_init__(self) -> None:
        # Column names match the ``.alias()`` labels in ``Problem._query_ast``.
        # Note: ``ordered_data``'s third column is ``value`` (a numeric literal),
        # whereas ``ordered_hash``'s third column is ``arg`` (a Hash reference);
        # ``format_ast_to_strings`` reads these positionally via ``itertuples``
        # so the names are purely for contract documentation and validation.
        _require_columns(self.operators, "operators", ("node", "op"))
        _require_columns(self.ordered_hash, "ordered_hash", ("node", "index", "arg"))
        _require_columns(self.ordered_data, "ordered_data", ("node", "index", "value"))
        _require_columns(self.unordered, "unordered", ("node", "arg"))


def _natural_sort_key(s: Any) -> list[Any]:
    """Sort key that orders ``w_2`` before ``w_10`` instead of lexicographically."""
    return [int(tok) if tok.isdigit() else tok for tok in _NAT_SPLIT.split(str(s))]


def _plural(n: int, word: str) -> str:
    """Return ``"1 word"`` / ``"N words"``."""
    return f"{n} {word}" if n == 1 else f"{n} {word}s"


def _wrap_expression(text: str, initial_indent: str, hanging_indent: str, width: int) -> str:
    """Wrap *text* at *width* with hanging indent for continuation lines.

    Wrapping happens at internal whitespace (which only follows commas in
    the AST output), so each continuation line starts with a clean argument.
    Words longer than the available width are not broken — they overflow
    the nominal width and remain intact on one line (e.g. a single
    multi-thousand-character operand name will not be chopped mid-token).

    ``width`` is clamped to a minimum of 1 before calling ``textwrap.fill``
    (which raises ``ValueError`` on non-positive widths). Callers that pass
    a width <= 0 will still get output, though it will degenerate to one
    token per line.
    """
    return textwrap.fill(
        text,
        width=max(1, width),
        initial_indent=initial_indent,
        subsequent_indent=hanging_indent,
        break_long_words=False,
        break_on_hyphens=False,
    )


def format_summary(
    numeric_type_name: str,
    *,
    n_cont: int,
    n_int: int,
    n_bin: int,
    n_min_obj: int,
    n_max_obj: int,
    n_con: int,
) -> list[str]:
    """Build the header and bullet-list summary for ``Problem.display()``.

    Zero-count categories are omitted. Singular/plural is handled. The
    model name is intentionally omitted because multiple ``Problem``
    instances can attach to the same ``Model``.

    Parameters
    ----------
    numeric_type_name : str
        ``"Float"`` or ``"Integer"``.
    n_cont, n_int, n_bin : int
        Counts of continuous, integer, and binary variables.
    n_min_obj, n_max_obj, n_con : int
        Counts of minimization objectives, maximization objectives,
        and constraints.

    Returns
    -------
    list[str]
        Header line followed by zero or more bullet lines.
    """
    header = f"Problem (numeric type: {numeric_type_name}):"

    n_vars = n_cont + n_int + n_bin
    if n_vars == 0 and n_min_obj == 0 and n_max_obj == 0 and n_con == 0:
        return [f"{header} empty"]

    lines = [header]
    if n_vars:
        type_parts = [
            f"{count} {label}" for count, label in ((n_cont, "cont"), (n_int, "int"), (n_bin, "bin")) if count
        ]
        lines.append(f"\u2022 {_plural(n_vars, 'variable')} ({', '.join(type_parts)})")
    for count, label in (
        (n_min_obj, "minimization objective"),
        (n_max_obj, "maximization objective"),
        (n_con, "constraint"),
    ):
        if count:
            lines.append(f"\u2022 {_plural(count, label)}")
    return lines


def format_ast_to_strings(expr_df: DataFrame, var_df: DataFrame, ast: AstQueryResults) -> None:
    """Add 'expression' column with human-readable strings to *expr_df*.

    Builds lookup tables from query result DataFrames, then recursively
    formats each expression tree from its root Hash node. Always adds
    the ``expression`` column, including on empty inputs, so downstream
    code can rely on its presence without an emptiness check.

    Parameters
    ----------
    expr_df : DataFrame
        Expression DataFrame with 'root' column (mutated in place).
    var_df : DataFrame
        Variable DataFrame with 'variable' and 'name' columns.
    ast : AstQueryResults
        Operator + argument query results.

    Raises
    ------
    RuntimeError
        If a root expression node has no operator entry, indicating the
        engine returned incomplete AST data.
    """
    if expr_df.empty:
        # Consistent mutation contract: always produce the `expression`
        # column, even if there are zero rows.
        expr_df["expression"] = []
        return

    # Build lookups from query results.
    variables: dict[Any, str] = dict(zip(var_df["variable"], var_df["name"])) if not var_df.empty else {}
    operators: dict[Any, int] = dict(zip(ast.operators["node"], ast.operators["op"])) if not ast.operators.empty else {}

    # Build args dict: node -> [child values in order].
    args: dict[Any, list[Any]] = defaultdict(list)
    for node, child in ast.unordered.itertuples(index=False):
        args[node].append(child)
    ordered: dict[Any, list[tuple[Any, Any]]] = defaultdict(list)
    for df in (ast.ordered_data, ast.ordered_hash):
        for node, idx, child in df.itertuples(index=False):
            ordered[node].append((idx, child))
    for node, indexed_children in ordered.items():
        indexed_children.sort(key=lambda x: x[0])
        args[node].extend(child for _, child in indexed_children)

    def fmt(node: Any, _depth: int = 0, _is_root: bool = False) -> str:
        if _depth > _MAX_FMT_DEPTH:
            return "<expression too deep>"
        if node in variables:
            return variables[node]
        op_code = operators.get(node)
        if op_code is None:
            if _is_root:
                raise RuntimeError(
                    "display() received incomplete expression data from the engine. "
                    "This can happen under heavy concurrent load. "
                    "Retrying may resolve the issue."
                )
            return str(node)
        op = _CODE_TO_NAME.get(op_code)
        if op is None:
            return f"<unknown_op:{op_code}>"
        children = args.get(node, [])
        is_infix = op in _INFIX
        parts: list[str] = []
        for child in children:
            s = fmt(child, _depth + 1)
            if is_infix:
                child_op = operators.get(child)
                if child_op is not None and _CODE_TO_NAME.get(child_op, "") in _INFIX_AND_CMP:
                    s = f"({s})"
            parts.append(s)
        # Sort for stable display (natural sort: x_2 before x_10).
        # SOS1/SOS2 excluded since their index order is meaningful.
        if op in _HIGHER_ORDER_CODES and op not in ("special_ordered_set_type_1", "special_ordered_set_type_2"):
            parts.sort(key=_natural_sort_key)
        if op in _INFIX_AND_CMP:
            return f"{parts[0]} {op} {parts[1]}"
        return f"{op}({', '.join(parts)})"

    expr_df["expression"] = [fmt(root, _is_root=True) for root in expr_df["root"]]


def format_variable_table(var_df: Any, var_types: Any) -> list[str]:
    """Format variable DataFrame into display lines.

    Rows are naturally sorted by name (``w_2`` before ``w_10``). Bound
    columns containing only NaN are hidden. All rows are shown — no
    truncation.

    Parameters
    ----------
    var_df : DataFrame
        Variable DataFrame with columns: name, type, lower, upper.
    var_types : Series
        Series of integer type codes.

    Returns
    -------
    list[str]
        Display lines (empty if no variables).
    """
    if var_df.empty:
        return []
    var_df = var_df.copy()
    var_df["type"] = var_types.map(_CODE_TO_NAME)
    cols = ["name", "type"] + [c for c in ("lower", "upper") if var_df[c].notna().any()]
    sorted_df = var_df.sort_values(by="name", key=lambda col: col.map(_natural_sort_key))[cols]  # type: ignore[call-overload]
    # Caller is responsible for inserting blank-line separators between sections.
    return ["Variables:", sorted_df.to_string(index=False, max_colwidth=None)]


def format_expression_table(
    expr_df: Any,
    expr_types: Any,
    var_df: Any,
    ast: AstQueryResults,
    width: int | None = None,
) -> list[str]:
    """Format expression DataFrame into display lines grouped by type.

    Expressions are printed one per line with ``"  name: expr"`` formatting
    (or just ``"  expr"`` if none of the rows have names). Lines that exceed
    *width* characters wrap at internal whitespace (which only follows
    commas in the AST output) with a hanging indent so continuation lines
    align cleanly.

    Parameters
    ----------
    expr_df : DataFrame
        Expression DataFrame with type, name, root columns.
    expr_types : Series
        Series of integer type codes.
    var_df : DataFrame
        Variable DataFrame (needed for variable name lookups).
    ast : AstQueryResults
        Operator + argument query results.
    width : int, optional
        Maximum line width for wrapping. Defaults to ``_DEFAULT_WIDTH`` (100)
        for deterministic output across environments.

    Returns
    -------
    list[str]
        Display lines (empty if no expressions).
    """
    from pandas import isna

    format_ast_to_strings(expr_df, var_df, ast)
    has_names = "name" in expr_df.columns and expr_df["name"].notna().any()
    effective_width = _DEFAULT_WIDTH if width is None else width
    initial = "  "
    hanging = "      "  # 6 spaces — pad past leading "  " plus a tab-feel for alignment

    def _row_text(name: Any, expression: str) -> str:
        # Per-row name check: a section may mix named and unnamed rows.
        # Unnamed rows render without a "name: " prefix rather than emitting "nan: ...".
        return f"{name}: {expression}" if not isna(name) else expression

    # Caller is responsible for inserting blank-line separators between sections.
    lines: list[str] = []
    for type_key, label in _EXPR_TYPE_LABELS:
        type_code = _EXPR_CODES[type_key]
        subset = expr_df[expr_types == type_code]
        if subset.empty:
            continue
        if lines:
            lines.append("")
        lines.append(f"{label}:")
        if has_names:
            named = subset.sort_values(by="name", key=lambda col: col.map(_natural_sort_key))  # type: ignore[call-overload]
            # ``zip`` over the underlying arrays is ~10× faster than ``iterrows``
            # at large E and avoids per-row Series construction.
            raw_rows = (_row_text(n, e) for n, e in zip(named["name"], named["expression"]))
        else:
            raw_rows = (str(e) for e in sorted(subset["expression"], key=_natural_sort_key))
        lines.extend(_wrap_expression(row, initial, hanging, effective_width) for row in raw_rows)
    return lines
