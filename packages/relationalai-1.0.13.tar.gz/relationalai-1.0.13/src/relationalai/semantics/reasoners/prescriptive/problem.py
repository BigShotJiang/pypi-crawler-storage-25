"""Prescriptive reasoning: define and solve decision problems.

Provides Problem for defining and solving decision problems — optimization,
constraint satisfaction, and feasibility — with variables, objectives, and
constraints. Problems are serialized and sent to an external solver service;
results are imported back after the solve completes.
"""

from __future__ import annotations

from dataclasses import dataclass
from functools import cached_property
from typing import Any, Literal, Optional, cast
from weakref import WeakKeyDictionary
from decimal import Decimal
import json
import logging
import math
import uuid
import warnings

from pandas import DataFrame, Series

from relationalai.util.error import warn as _warn
from relationalai.semantics.frontend import base as b
from relationalai.semantics import std, String, Float, Integer
from relationalai.semantics.std.floats import parse_float as _parse_float
from relationalai.semantics.frontend.core import Hash, cast as core_cast
from relationalai.util.schema import get_provider
from relationalai.client import connect_sync
from v0.relationalai.clients.resources.snowflake import Resources as SnowflakeResources
from v0.relationalai.errors import RAIAbortedTransactionError, RAIException

from .wire_format import (
    _VAR_CODES,
    _EXPR_CODES,
)
from .rewriter import ExpressionCompiler, SymbolicNode, _expr_dict_key
from .display import AstQueryResults, format_expression_table, format_summary, format_variable_table
from .components import (
    ProblemVariable,
    ProblemObjective,
    ProblemConstraint,
)
from ....util.docutils import include_in_docs

# include this module in documentation
__include_in_docs__ = True

logger = logging.getLogger(__name__)

# Tracks which variable relationships have populate=True per Model, to warn on
# duplicate populate rules (FD violations). WeakKeyDictionary so entries are
# cleaned up when the Model is garbage-collected.
_populated_relationships: WeakKeyDictionary[b.Model, set[int]] = WeakKeyDictionary()

# =============================================================================
# Constants
# =============================================================================
REASONER_TYPE = "PRESCRIPTIVE"


# =============================================================================
# Utilities
# =============================================================================


def _check_name_arg(arg: Any) -> None:
    """Raise if *arg* is a bare Concept or nested list (not a scalar DSL expression)."""
    if isinstance(arg, b.Concept):
        raise TypeError(
            f"Cannot use Concept '{arg._name}' as a name component. "
            f"Use a property that returns a scalar value instead "
            f'(for example, name=["x", {arg._name}.id]).'
        )
    if isinstance(arg, list):
        raise TypeError(
            "Nested lists are not supported as name components. "
            "Pass a flat list of parts instead "
            '(for example, name=["x", X.i], not name=[["x"], X.i]).'
        )


def make_name(*args: Any, sep: Optional[str] = "_") -> Any:
    """Construct a variable/objective/constraint name from concatenated parts.

    Use this to build names when annotating a :class:`ProblemVariable`,
    :class:`ProblemObjective`, or :class:`ProblemConstraint` after creation
    via ``model.define(var.name(...))``. The ``name=`` parameter on
    :meth:`Problem.solve_for`, :meth:`~Problem.satisfy`,
    :meth:`~Problem.minimize`, and :meth:`~Problem.maximize` calls this
    helper internally on the value you pass.

    Parameters
    ----------
    *args : Any
        Parts to concatenate. Strings are kept verbatim; numbers and DSL
        expressions (e.g. ``Item.id``) are converted to strings. A single
        list argument is unpacked.
    sep : str or None, optional
        Separator between parts. Defaults to ``"_"``. Pass ``None`` to
        concatenate without a separator.

    Returns
    -------
    str or Expression
        A plain ``str`` if all parts are static strings, otherwise a DSL
        string expression evaluated per-entity at solve time.

    Raises
    ------
    ValueError
        If no arguments are provided.
    TypeError
        If a part is a bare :class:`~relationalai.semantics.frontend.base.Concept`
        rather than a scalar property of one (e.g. pass ``Item.id``, not ``Item``),
        or if a part is a nested list (pass a flat list of parts instead).

    Examples
    --------
    Annotate variables after :meth:`Problem.solve_for`:

    >>> var = problem.solve_for(X.v)
    >>> model.define(var.name(make_name("x", X.i))).where(var)

    Static-only parts return a plain string:

    >>> make_name("budget", "total")
    'budget_total'
    """
    if not args:
        raise ValueError("No arguments provided to `make_name`")

    if len(args) == 1:
        arg = args[0]
        if isinstance(arg, str):
            return arg
        elif isinstance(arg, list):
            return make_name(*arg, sep=sep)
        else:
            _check_name_arg(arg)
            return std.strings.string(arg)

    for a in args:
        if not isinstance(a, str):
            _check_name_arg(a)

    if sep:
        str_args: list[Any] = []
        for a in args:
            str_args.append(std.strings.string(a))
            str_args.append(sep)
        str_args.pop()  # Remove trailing separator.
    else:
        str_args = [std.strings.string(a) for a in args]

    return std.strings.concat(*str_args)



# =============================================================================
# Result Import Utilities
# =============================================================================


def _load_data_with_retry(
    model: Any,
    resources: Any,
    app_name: str,
    table_fqns: list[str],
    engine_name: str,
    sources: dict[str, str] | None = None,
    max_retries: int = 6,
    initial_delay: float = 2.0,
) -> None:
    """Load result tables via batched ``experimental.load_data`` with retries.

    This sends all result views in a single payload, so table registration and
    loading happen in one call.

    If the logic engine transaction aborted we retry with exponential backoff + jitter.
    """
    import random
    import time

    if not table_fqns:
        return

    def target_relation_name(fqn: str) -> str:
        # experimental.load_data registers data under this name in the logic engine.
        return fqn.lower().replace(".", "_")

    payload = {
        "tables": [
            {
                "table_reference": sources.get(fqn, fqn) if sources else fqn,
                "target_relation": target_relation_name(fqn),
            }
            for fqn in table_fqns
        ]
    }
    payload_json = json.dumps(payload)

    total_backoff = 0.0
    for attempt in range(max_retries):
        try:
            resources._exec(
                f"call {app_name}.experimental.load_data(?, ?, parse_json(?))",
                [model.name, engine_name, payload_json],
                skip_engine_db_error_retry=True,  # type: ignore[reportCallIssue]
            )
            if attempt > 0:
                logger.warning(
                    "load_data succeeded after %d retries (%.1fs total backoff)",
                    attempt,
                    total_backoff,
                )
            return
        # RuntimeError: resources._exec() wraps some Snowflake errors this way.
        except (RAIException, RuntimeError) as e:
            is_aborted = isinstance(e, RAIAbortedTransactionError) or "aborted" in str(e).lower()
            if is_aborted and attempt < max_retries - 1:
                delay = initial_delay * (2**attempt) + random.uniform(0, 2)
                total_backoff += delay
                logger.warning(
                    "load_data ABORTED (attempt %d/%d), retrying in %.1fs: %s", attempt + 1, max_retries, delay, e
                )
                time.sleep(delay)
                continue
            raise


# =============================================================================
# Solver Result Snapshot
# =============================================================================


@dataclass(frozen=True)
class SolveInfoData:
    """Concrete snapshot of solver result metadata.

    Returned by :meth:`Problem.solve_info`. Cached until the next
    :meth:`~Problem.solve`.
    """

    termination_status: str | None
    objective_value: float | int | None
    solve_time_sec: float | None
    num_points: int | None
    solver_version: str | None
    error: tuple[str, ...]
    printed_model: str | None

    def __repr__(self) -> str:
        parts: list[str] = []
        if self.termination_status is not None:
            parts.append(f"status: {self.termination_status}")
        if self.objective_value is not None:
            parts.append(f"objective: {self.objective_value}")
        if self.solve_time_sec is not None:
            parts.append(f"solve time: {self.solve_time_sec:.2f}s")
        if self.num_points is not None:
            parts.append(f"num_points: {self.num_points}")
        if self.solver_version is not None:
            parts.append(f"solver: {self.solver_version}")
        if self.error:
            parts.extend(f"error: {e}" for e in self.error)
        if self.printed_model is not None:
            parts.append(f"printed model: {len(self.printed_model)} chars")
        lines = ["Solve result:"] + [f"\u2022 {p}" for p in parts]
        return "\n".join(lines)

    def display(self) -> str:
        """Print and return a formatted summary."""
        output = repr(self)
        print(output, end="\n\n")
        return output


# =============================================================================
# Main Problem Class
# =============================================================================


@include_in_docs
class Problem:
    """Define and solve a decision problem on a model.

    Use :meth:`solve_for` to declare decision variables, :meth:`minimize`/
    :meth:`maximize` to add objectives, and :meth:`satisfy` to add constraints.
    Then call :meth:`solve` and read results via populated properties (the
    default — e.g. ``model.select(X.v)``), the ``Variable.values`` Property
    for engine-side queries (``model.select(sol_idx, val).where(var.values(sol_idx, val))``),
    or :meth:`solve_info` for a Python-side metadata snapshot.

    Parameters
    ----------
    model : Model
        The :class:`~relationalai.semantics.frontend.base.Model` to attach solver
        constructs (variables, objectives, constraints, and results) to.
    numeric_type : Concept
        Numeric type used for bounds, solution values, and numeric literals.
        Use :data:`~relationalai.semantics.Float` for HiGHS/Gurobi/Ipopt (even
        for MIPs), and :data:`~relationalai.semantics.Integer` for MiniZinc.

    Attributes
    ----------
    numeric_type : Concept
        :data:`~relationalai.semantics.Float` or :data:`~relationalai.semantics.Integer`.
    variables : list[ProblemVariable]
        Variable components registered via :meth:`solve_for`.
    objectives : list[ProblemObjective]
        Objective components registered via :meth:`minimize` / :meth:`maximize`.
    constraints : list[ProblemConstraint]
        Constraint components registered via :meth:`satisfy`.
    Variable : Concept
        Engine-side aggregate Concept covering all declared decision variables.
        Use it to query across all variables of this problem — for example,
        ``model.select(p.Variable.name, p.Variable.lower).where(p.Variable)``
        to list every variable's name and lower bound.
    Objective : Concept
        Engine-side aggregate Concept covering all objectives. Each
        :class:`ProblemObjective` extends this Concept; use it to query
        names, types, and (in future) duals or printed expressions.
    Constraint : Concept
        Engine-side aggregate Concept covering all constraints. Each
        :class:`ProblemConstraint` extends this Concept; use it to query
        names, types, and (in future) duals or printed expressions.

    Examples
    --------
    Declare a variable and objective:

    >>> from relationalai.semantics import Float, Model
    >>> from relationalai.semantics.reasoners.prescriptive import Problem
    >>> m = Model("demo")
    >>> x = m.Relationship(f"{Float:x}")
    >>> problem = Problem(m, Float)
    >>> problem.solve_for(x, name="x", lower=0)
    >>> problem.minimize(x)

    Notes
    -----
    Calling :meth:`solve` invalidates the Python-side ``solve_info()`` cache.
    Result accessors like ``termination_status()`` return engine-side
    Relationships that reflect the most recent successful solve.
    """

    # Removed attributes — __getattr__ catches access and raises a clear
    # migration error. Only fires for names NOT defined as methods on Problem
    # (i.e. fully removed names, not property→method renames).
    # TODO: remove once prescriptive_assistant migration is complete.
    _REMOVED_ATTRS: dict[str, str] = {
        "result_count": "Use 'p.num_points()' (Relationship) or 'p.solve_info().num_points' (int).",
        "display_solve_info": "Use 'p.solve_info().display()'.",
    }

    def __getattr__(self, name: str) -> Any:
        if name in self._REMOVED_ATTRS:
            raise AttributeError(f"'{name}' has been removed. {self._REMOVED_ATTRS[name]}")
        raise AttributeError(f"'{type(self).__name__}' object has no attribute '{name}'")

    def __repr__(self) -> str:
        model_name = getattr(self._model, "name", None)
        nt = repr(self.numeric_type)
        counts = []
        for n, label in [
            (len(self.variables), "variable"),
            (sum(1 for o in self.objectives if o.sense == "maximize"), "max objective"),
            (sum(1 for o in self.objectives if o.sense == "minimize"), "min objective"),
            (len(self.constraints), "constraint"),
        ]:
            if n:
                counts.append(f"{n} {label}{'s' if n != 1 else ''}")
        summary = ", ".join(counts) if counts else "empty"
        return f"Problem({model_name!r}, {nt}, {summary})"

    def __init__(self, model: b.Model, numeric_type: b.Concept) -> None:
        if not (numeric_type is Float or numeric_type is Integer):
            raise ValueError(f"Invalid numeric type '{numeric_type}'. Must be Float or Integer.")
        self._model = model
        self.numeric_type = numeric_type
        self._model_id = str(uuid.uuid4()).upper().replace("-", "_")
        self._result_rules_defined = False
        self._result_tables: dict[str, Any] = {}
        self._solve_info_cache: SolveInfoData | None = None
        # Maps relationships to their corresponding variable concepts.
        self._variable_relationships: dict[int, b.Concept] = {}
        # Registered definitions (for introspection and display).
        self.variables: list[ProblemVariable] = []
        self.objectives: list[ProblemObjective] = []
        self.constraints: list[ProblemConstraint] = []

        Concept = model.Concept
        Property = model.Property

        # Variable concept and its properties.
        Variable = self.Variable = Concept("Variable")
        Variable.name = Property(f"{Variable} has {String:name}")
        Variable.type = Property(f"{Variable} has {Integer:type}")
        Variable.lower = Property(f"{Variable} has {numeric_type:lower}")
        Variable.upper = Property(f"{Variable} has {numeric_type:upper}")
        Variable.start = Property(f"{Variable} has {numeric_type:start}")

        # Expression concept and its properties (internal base for Constraint/Objective).
        Expression = self._Expression = Concept("Expression")
        Expression.name = Property(f"{Expression} has {String:name}")
        Expression.type = Property(f"{Expression} has {Integer:type}")
        Expression.root = Property(f"{Expression} has {Hash:root}")

        # User-facing aggregate Concepts for constraints and objectives.
        # Both extend Expression and inherit its name/type/root properties.
        Objective = self.Objective = Concept("Objective", extends=[Expression])
        Objective.sense = Property(f"{Objective} has {String:sense}")
        self.Constraint = Concept("Constraint", extends=[Expression])

        self._expr_counter = 0

        # AST structure properties for expression nodes.
        self._operator = Property(f"{Hash:node} has {Integer:op}")
        self._ordered_args_hash = Property(f"{Hash:node} arg {Integer:i} is {Hash:arg}")
        self._ordered_args_data = Property(f"{Hash:node} arg {Integer:i} is {numeric_type:arg}")
        self._unordered_args_hash = Property(f"{Hash:node} arg {Hash:i} is {Hash:arg}")

        # Reachability: transitive closure from Expression roots through AST args.
        # Filters out orphaned AST nodes (from expressions where one arm is empty).
        n0, n1, i_, h_ = Hash.ref(), Hash.ref(), Integer.ref(), Hash.ref()
        self._reachable = model.Relationship(f"{Hash}")
        model.define(self._reachable(Expression.root))
        ctx = model.where(self._reachable(n0))
        ctx.define(self._reachable(n1)).where(self._ordered_args_hash(n0, i_, n1))
        ctx.define(self._reachable(n1)).where(self._unordered_args_hash(n0, h_, n1))

        # Solve output relations.
        self._solve_info = model.Relationship(f"{String:key} has {String:val}")
        self._points = Property(f"{Integer:sol_index} has {Hash:var_hash} with {numeric_type:value}")
        self._point = Property(f"{Hash:var_hash} has {numeric_type:value}")
        self._objective_values = Property(f"{Integer:sol_index} has {numeric_type:obj_value}")

        # _point pins populated properties and `variable_values()` to the first
        # solution (sol_index = 1). Users who need per-solution access should
        # query `Variable.values(sol_idx, val)` directly.
        var_hash = Hash.ref()
        point_val = self.numeric_type.ref()
        model.where(self._points(1, var_hash, point_val)).define(self._point(var_hash, point_val))

        # Variable.values: all solutions' values (0-based sol_index).
        Variable.values = Property(f"{Variable} at {Integer:sol_index} has {numeric_type:value}")
        val_ref = numeric_type.ref()
        var_ref_val = Variable.ref()
        var_hash_val = core_cast(b.MetaRef(Hash), var_ref_val)
        raw_index = Integer.ref()
        model.where(self._points(raw_index, var_hash_val, val_ref)).define(var_ref_val.values(raw_index - 1, val_ref))

    # =========================================================================
    # Subconcept Creation
    # =========================================================================

    def _register_concept(self, concept: b.Concept) -> None:
        """Register a directly-constructed concept with the model (mirrors model.Concept())."""
        self._model.concepts.append(concept)
        self._model.concept_index[concept._name] = concept
        self._model._bump_version()

    def _create_variable_subconcept(
        self,
        relationship: b.Relationship,
        var_type: str,
        name: Optional[str] = None,
        *,
        dsl_expr: Any,
        concept_name: str | None,
        property_name: str,
        var_where: tuple | None,
        populate: bool,
        identify_by: dict,
    ) -> "ProblemVariable":
        """Create a ProblemVariable subconcept with standing type rule (and name if scalar)."""
        Var = ProblemVariable(
            f"Variable_{relationship._id}",
            [self.Variable],
            identify_by,
            self._model,
            dsl_expr=dsl_expr,
            concept_name=concept_name,
            property_name=property_name,
            var_type=var_type,
            var_where=var_where,
            populate=populate,
        )
        self._register_concept(Var)
        ref = Var.ref()
        standing = [ref.type(_VAR_CODES[var_type])]
        if name is not None:
            standing.append(ref.name(name))
        self._model.define(*standing).where(ref)
        return Var

    def _create_constraint_subconcept(
        self,
        name: Optional[str] = None,
        *,
        dsl_expr: Any,
    ) -> "ProblemConstraint":
        """Create a ProblemConstraint subconcept with standing type rule (and name if scalar)."""
        self._expr_counter += 1
        sub = ProblemConstraint(
            f"Constraint_{self._expr_counter}",
            [self.Constraint],
            {},
            self._model,
            dsl_expr=dsl_expr,
        )
        self._register_concept(sub)
        ref = sub.ref()
        standing = [ref.type(_EXPR_CODES["constraint"])]
        if name is not None:
            standing.append(ref.name(name))
        self._model.define(*standing).where(ref)
        return sub

    def _create_objective_subconcept(
        self,
        expr_type: str,
        name: Optional[str] = None,
        *,
        dsl_expr: Any,
    ) -> "ProblemObjective":
        """Create a ProblemObjective subconcept with standing type rule (and name if scalar)."""
        self._expr_counter += 1
        sense = "minimize" if expr_type == "min_objective" else "maximize"
        sub = ProblemObjective(
            f"Objective_{self._expr_counter}",
            [self.Objective],
            {},
            self._model,
            dsl_expr=dsl_expr,
            sense=sense,
        )
        self._register_concept(sub)
        ref = sub.ref()
        standing = [ref.type(_EXPR_CODES[expr_type]), ref.sense(sense)]
        if name is not None:
            standing.append(ref.name(name))
        self._model.define(*standing).where(ref)
        return sub

    # =========================================================================
    # Variable Handling
    # =========================================================================

    @include_in_docs
    def solve_for(
        self,
        expr: b.Relationship | b.Chain | b.Expression,
        where: Optional[list[Any]] = None,
        populate: bool = True,
        name: Optional[Any | list[Any]] = None,
        type: Optional[str] = None,
        lower: Optional[std.NumberValue] = None,
        upper: Optional[std.NumberValue] = None,
        start: Optional[std.NumberValue] = None,
    ) -> "ProblemVariable":
        """Declare decision variables for the problem.

        Call this before adding objectives or constraints. The returned
        :class:`ProblemVariable` IS a Concept — use it directly with
        ``model.define()``, ``model.select()``, and ``.ref()`` to annotate and
        query declared variables.

        Parameters
        ----------
        expr : Relationship or Chain or Expression
            Expression describing the variable(s) to create (for example,
            a scalar relationship like ``x`` or an indexed property like
            ``Item.cost``).
        where : list[Any], optional
            Optional conditions restricting which variable instances are created.
        populate : bool, optional
            If True (default), write solved values back to the original
            relationship/property after :meth:`solve`. Set to False when you
            create multiple :class:`Problem` instances that solve for the same
            relationship on the same model.
        name : Any or list[Any], optional
            Display name for variables. Use a string for scalars or a list
            pattern for indexed variables (for example, ``["x", Item.i]``).
        type : str, optional
            Variable type: ``"cont"`` (default for ``Float``), ``"int"``
            (default for ``Integer``), or ``"bin"`` (binary 0/1).
        lower, upper, start : Variable or float or int or Decimal, optional
            Lower/upper bounds and an optional initial value hint.

        Returns
        -------
        ProblemVariable
            The variable subconcept. Annotate via
            ``model.define(var.lower(0))``, query values after solve via
            ``model.select(sol_idx, val).where(var.values(sol_idx, val))``.

            **Back-pointer fields.** The subconcept exposes one property per
            non-value field of the underlying relationship, named after the
            field's own name (the explicit ``:name`` from the format string,
            or the lowercased type name if no explicit name was given). Use
            these to query "which domain entity does this variable
            represent?". Examples for the common shapes::

                # Entity property: f"{Queen} is in {Integer:column}"
                #   → var.queen   (back to the Queen instance)
                var = p.solve_for(Queen.column, ...)
                model.select(sol_idx, var.queen.row, val).where(var.values(sol_idx, val))

                # Explicit field name: f"{Edge:e} has {Float:flow}"
                #   → var.e       (uses the explicit name, not "edge")
                var = p.solve_for(Edge.flow, ...)
                model.select(sol_idx, var.e.id, val).where(var.values(sol_idx, val))

                # Multi-arity entity property:
                # f"{Player} in {Integer:week} is in {Integer:group}"
                #   → var.player + var.week
                var = p.solve_for(Player.assign(w, x), ...)
                model.select(sol_idx, var.player.p, var.week, val).where(var.values(sol_idx, val))

                # Bare multi-arity (no entity):
                # f"cell {Integer:i} {Integer:j} is {Integer:x}"
                #   → var.i + var.j
                var = p.solve_for(cell(i, j, x), ...)
                model.select(sol_idx, var.i, var.j, val).where(var.values(sol_idx, val))

                # Bare scalar relationship: f"{Float:x}" — no back-pointer.
                #   Query var.values directly.
                var = p.solve_for(x, name="x", ...)
                model.select(sol_idx, val).where(var.values(sol_idx, val))

        Raises
        ------
        ValueError
            If variables are already defined for this relationship, if an
            argument has an invalid value (for example, an unknown ``type``),
            or if a non-value field name would shadow an intrinsic attribute
            on the Variable subconcept. Shadow categories include engine-side
            Properties (``name``, ``type``, ``lower``, ``upper``, ``start``,
            ``values``), Python ``@property`` descriptors (``dsl_expr``,
            ``concept_name``, ``property_name``, ``var_type``, ``var_where``,
            ``populate``), and ``Concept.RESERVED_NAMES`` methods (``ref``,
            ``new``, ``alias``, ``where``, ``select``, ``define``, ``require``,
            etc.). See :meth:`Problem._reserved_variable_field_names` for the
            authoritative list — the error message lists the full set. Rename
            the conflicting field in the relationship's format string.
        TypeError
            If an argument has an invalid type.
        """
        relationship, args = self._extract_relationship(expr)
        key = _expr_dict_key(relationship)

        if key in self._variable_relationships:
            raise ValueError(
                "Variables already defined for this relationship. "
                "Each relationship can only be used once in solve_for()."
            )

        # Resolve name: scalar names go in the standing rule, DSL names go per-entity.
        # When name is None, skip entirely so names can be set later via model.define().
        scalar_name, dsl_name = self._extract_scalar_name(name)

        # Build the (field-name → arg) mapping for non-value fields. This is the
        # single source of truth for both the Variable subconcept's back-pointer
        # surface (`var.<f.name>`) and its identity. Validate field names before
        # going any further so users get a clear error at solve_for time.
        non_value_fields = {f.name: args[i] for i, f in enumerate(relationship._fields[:-1])}
        self._validate_solve_for_field_names(relationship)

        # Single-entity Chain shape (`Entity.value`, exactly 2 fields) uses
        # entity-keyed identity so each entity instance gets exactly one
        # Variable. Every other shape (multi-arity, expression-call,
        # bare scalar) uses `var_id` as a constant discriminator and treats
        # the non-value fields as additional properties on the subconcept.
        is_single_entity_chain = (
            isinstance(expr, b.Chain) and isinstance(expr._start, b.Concept) and len(relationship._fields) == 2
        )
        if is_single_entity_chain:
            # `is_single_entity_chain` already guarantees these, but pyright
            # can't propagate the narrowing into this branch, so re-assert.
            assert isinstance(expr, b.Chain)
            assert isinstance(expr._start, b.Concept)
            entity_field_name = relationship._fields[0].name
            identify_by: dict = {entity_field_name: expr._start}
            concept_name: str | None = expr._start._name
        else:
            identify_by = {}
            concept_name = relationship._fields[0].type._name if len(relationship._fields) > 1 else None
        property_name = relationship._short_name or relationship._fields[-1].name

        resolved_type = self._resolve_var_type(type)
        Var = self._create_variable_subconcept(
            relationship,
            resolved_type,
            name=scalar_name,
            dsl_expr=expr,
            concept_name=concept_name,
            property_name=property_name,
            var_where=tuple(where) if where else None,
            populate=populate,
            identify_by=identify_by,
        )
        self._variable_relationships[key] = Var

        # Entity creation: instantiate one Variable per (non-value field tuple).
        # Entity-keyed Chain shape needs no extra discriminator; everything else
        # gets `var_id` so the subconcept has stable identity (in particular for
        # bare scalars where `non_value_fields` is empty).
        if is_single_entity_chain:
            var = Var._new(**non_value_fields)
        else:
            var = Var._new(var_id=relationship._id, **non_value_fields)

        var_defs: list[Any] = [var]
        if dsl_name is not None:
            var_defs.append(var.name(dsl_name))

        # Scalar-valued optional properties: uses ref() for cleaner IR.
        ref = Var.ref()
        ref_defs: list[Any] = []
        for attr, val in [("lower", lower), ("upper", upper), ("start", start)]:
            if val is not None:
                val = self._validate_numeric_bound(attr, val)
                if isinstance(val, b.DSLBase):
                    var_defs.append(getattr(var, attr)(val))
                else:
                    ref_defs.append(getattr(ref, attr)(val))

        # Warn if binary variable has non-standard bounds (after validation).
        if resolved_type == "bin":
            for attr, val in [("lower", lower), ("upper", upper)]:
                if val is not None and not isinstance(val, b.Variable) and val not in (0, 1):
                    _warn(
                        "Non-standard binary bounds",
                        f"Binary variable has {attr}={val}. Binary variables are "
                        f"restricted to 0/1; non-standard bounds may be ignored by the solver.",
                    )

        self._model.define(*var_defs).where(*(where or []))
        if ref_defs:
            self._model.define(*ref_defs).where(ref)

        if populate:
            populated = _populated_relationships.setdefault(self._model, set())
            if key in populated:
                _warn(
                    "Duplicate relationship population",
                    "Multiple Problems populating the same relationship will cause "
                    "a functional dependency violation. Use populate=False on all but one, "
                    "or use variable_values() to read results instead.",
                )
            populated.add(key)

            val_ref = self.numeric_type.ref()
            pop_var = Var.ref()
            var_hash = core_cast(b.MetaRef(Hash), pop_var)
            # Look up each non-value field on the Variable subconcept by its
            # `f.name`. Same source of truth as the entity-creation block above
            # and `_create_variable_subconcept`'s identify_by.
            field_args = [getattr(pop_var, f.name) for f in relationship._fields[:-1]]
            self._model.where(self._point(var_hash, val_ref), *(where or [])).define(relationship(*field_args, val_ref))

        self.variables.append(Var)
        return Var

    @staticmethod
    def _check_not_reading(rel: b.Relationship, context: str) -> None:
        """Raise if rel is a Reading (.alt()). Readings cannot be used in solve_for()."""
        if isinstance(rel, b.Reading):
            parent_name = rel._relationship._short_name or rel._relationship._name  # type: ignore[operator]
            raise TypeError(
                f"Cannot use alternative reading (`.alt()`) in {context}. "
                f"Use the original relationship '{parent_name}' instead."
            )

    def _extract_relationship(self, expr: b.Relationship | b.Chain | b.Expression) -> tuple[b.Relationship, list[Any]]:
        """Extract relationship and args from variable expression."""
        if isinstance(expr, b.Relationship):
            self._check_not_reading(expr, "solve_for()")
            rel, args = expr, [f.type for f in expr._fields]
        elif isinstance(expr, b.Chain):
            if not isinstance(expr._start, b.Concept) or not isinstance(expr._next, b.Relationship):
                raise TypeError("Chain must have Concept start and Relationship next. Example: solve_for(Entity.value)")
            self._check_not_reading(expr._next, "solve_for()")
            rel, args = expr._next, [f.type for f in expr._next._fields]
        elif isinstance(expr, b.Expression):
            rel = expr._op
            if not isinstance(rel, b.Relationship):
                raise TypeError(
                    f"Expression operator must be Relationship, got {type(rel).__name__}. "
                    f"Example: solve_for(my_relation(x, y))"
                )
            self._check_not_reading(rel, "solve_for()")
            if len(expr._args) != len(rel._fields):
                field_names = [f.name for f in rel._fields]
                raise ValueError(
                    f"Argument count mismatch: {len(expr._args)} arguments provided, "
                    f"but relationship '{rel._name}' expects {len(rel._fields)} fields: {', '.join(field_names)}. "
                    f"Example: solve_for({rel._name}({', '.join('...' for _ in rel._fields)}))"
                )
            rel, args = rel, expr._args
        else:
            raise TypeError(
                f"Invalid expression type: {type(expr).__name__}. "
                f"Expected Relationship, Chain, or Expression. "
                f"Example: solve_for(my_relation) or solve_for(Entity.value)"
            )

        # The last field is the value — it must be numeric.
        value_type = rel._fields[-1].type
        if value_type is not Float and value_type is not Integer:
            raise TypeError(
                f"solve_for() requires a numeric (Float or Integer) property, "
                f"but '{rel._short_name}' has value type {value_type._name}. "
                f"Create a separate numeric property for decision variables."
            )
        return rel, args

    @classmethod
    def _reserved_variable_field_names(cls) -> tuple[frozenset[str], frozenset[str]]:
        """Names that collide with ``ProblemVariable``'s intrinsic surface.

        A relationship whose non-value field shares one of these names cannot
        be used in ``solve_for()`` because the back-pointer ``var.<f.name>``
        would shadow an intrinsic attribute. Returns **two** sets because the
        two categories have different case-sensitivity semantics.

        Returns
        -------
        (case_insensitive, case_sensitive) : tuple of frozenset
            * ``case_insensitive`` — resolved through PyRel's lowercasing
              attribute path (``Concept._dot_recur`` does ``name.lower()``
              before dict lookup), so a collision fires regardless of the
              field's case. Contains ``ProblemVariable._ALLOWED_PROPERTIES``
              (engine-side Properties: ``name``, ``type``, ``lower``, …) and
              :attr:`Concept.RESERVED_NAMES` (``ref``, ``new``, ``alias``,
              ``where``, ``select``, ``define``, ``require``, …).
            * ``case_sensitive`` — resolved through Python's normal class
              attribute lookup, which is case-sensitive, so
              ``var.RESERVED_NAMES`` collides but ``var.reserved_names`` does
              not (the latter falls through to ``__getattr__`` and resolves
              to the back-pointer relationship). Contains every public
              class-level attribute on ``ProblemVariable.__mro__``
              (``@property`` descriptors like ``dsl_expr`` and ``populate``,
              inherited methods like ``to_dict_key``, class-level data like
              ``RESERVED_NAMES`` and ``lookup_by_id``) plus the internal
              ``var_id`` discriminator.

        The split matters: folding both categories into a single
        case-insensitive check would reject valid field names like
        ``reserved_names`` that do not actually shadow at runtime.
        """
        case_insensitive = ProblemVariable._ALLOWED_PROPERTIES | b.Concept.RESERVED_NAMES
        mro_public_attrs = {
            name for klass in ProblemVariable.__mro__ for name in vars(klass) if not name.startswith("_")
        }
        case_sensitive = mro_public_attrs | frozenset({"var_id"})
        return frozenset(case_insensitive), frozenset(case_sensitive)

    def _validate_solve_for_field_names(self, relationship: b.Relationship) -> None:
        """Reject relationships whose non-value field names collide with Variable's
        intrinsic properties.

        Each non-value field becomes a property on the ``ProblemVariable``
        subconcept under the same name (``var.<f.name>``). Collisions with
        reserved attributes produce ambiguous back-pointer access — fail
        loudly here so the user can rename the offending field.

        Applies two complementary checks (see
        :meth:`_reserved_variable_field_names`):

        - **Case-insensitive** against ``_ALLOWED_PROPERTIES`` and
          ``Concept.RESERVED_NAMES``. PyRel lowercases names in its
          attribute resolution path, so ``var.NAME`` hits the engine-side
          ``name`` Property and ``var.REF`` hits the reserved-name guard.
        - **Case-sensitive** against the ``__mro__`` walk of public class
          attributes. Python class-attribute lookup is case-sensitive, so
          ``var.RESERVED_NAMES`` returns the inherited frozenset but
          ``var.reserved_names`` falls through to ``__getattr__`` and
          resolves to a valid back-pointer.

        Note: PyRel auto-disambiguates duplicate field names (e.g.
        ``f"{{Integer:a}} {{Integer:a}}"`` becomes ``a`` and ``a_2``), so we
        do not need to check for duplicates here.
        """
        case_insensitive, case_sensitive = self._reserved_variable_field_names()
        non_value_field_names = [f.name for f in relationship._fields[:-1]]
        reserved = sorted({n for n in non_value_field_names if n in case_sensitive or n.lower() in case_insensitive})
        if reserved:
            rel_name = relationship._short_name or getattr(relationship, "_name", "<anonymous>")
            display_set = sorted(case_insensitive | case_sensitive)
            raise ValueError(
                f"solve_for() cannot accept relationship '{rel_name}': non-value "
                f"field name(s) {reserved} collide with ProblemVariable's "
                f"intrinsic properties (reserved: {display_set}). "
                f"Rename the conflicting field(s) in the relationship's format "
                f"string, e.g. f'{{Concept:my_field}}' instead of "
                f"f'{{Concept:name}}'."
            )

    def _resolve_var_type(self, var_type: Optional[str]) -> str:
        """Resolve variable type, defaulting based on model's numeric type."""
        if var_type is None:
            return "cont" if self.numeric_type is Float else "int"
        if not isinstance(var_type, str):
            raise TypeError(
                f"Variable type must be a string, got {type(var_type).__name__}. Example: solve_for(x, type='int')"
            )
        if var_type not in _VAR_CODES:
            valid_types = ", ".join(f"'{t}'" for t in _VAR_CODES.keys())
            raise ValueError(
                f"Invalid variable type '{var_type}'. Valid types are: {valid_types}. "
                f"Example: solve_for(x, type='cont', lower=0, upper=10)"
            )
        return var_type

    def _validate_numeric_bound(self, name: str, val: Any) -> Any:
        """Validate and coerce a bound value to a DSL-compatible numeric type.

        Returns the (possibly coerced) value. Numpy float/int subclasses are
        converted to plain Python types since the DSL uses ``type(v) is float``
        identity checks.
        """
        if isinstance(val, bool):
            raise TypeError(
                f"Parameter '{name}' must be numeric (Variable, float, int, or Decimal), "
                f"got bool. Use 0/1 instead of False/True. "
                f"Example: solve_for(x, {name}=0)"
            )
        if not isinstance(val, (b.Variable, float, int, Decimal)):
            raise TypeError(
                f"Parameter '{name}' must be numeric (Variable, float, int, or Decimal), "
                f"got {type(val).__name__}. "
                f"Example: solve_for(x, {name}=0.0)"
            )
        if isinstance(val, float) and not math.isfinite(val):
            raise ValueError(
                f"Parameter '{name}' must be a finite number, got {val}. Example: solve_for(x, {name}=0.0)"
            )
        if isinstance(val, Decimal) and not val.is_finite():
            raise ValueError(
                f"Parameter '{name}' must be a finite number, got {val}. Example: solve_for(x, {name}=0.0)"
            )
        # Coerce numpy subclasses to plain Python types (DSL requires exact types).
        if isinstance(val, float) and type(val) is not float:
            return float(val)
        if isinstance(val, int) and type(val) is not int:
            return int(val)
        return val

    # =========================================================================
    # Expression Handling
    # =========================================================================

    @include_in_docs
    def minimize(
        self,
        expr: b.Variable | float | int | b.Fragment,
        name: Optional[Any | list[Any]] = None,
    ) -> "ProblemObjective":
        """Add a minimization objective.

        The expression must reference at least one decision variable declared via
        :meth:`solve_for`.

        Parameters
        ----------
        expr : Variable or float or int or Fragment
            Objective expression to minimize.
        name : Any or list[Any], optional
            Optional objective name (string for scalar, or a list pattern for
            indexed objectives).

        Returns
        -------
        ProblemObjective
            The objective subconcept (IS a Concept).

        Raises
        ------
        ValueError
            If the objective does not reference any declared decision variables.
        """
        return self._add_objective("min_objective", expr, name)

    @include_in_docs
    def maximize(
        self,
        expr: b.Variable | float | int | b.Fragment,
        name: Optional[Any | list[Any]] = None,
    ) -> "ProblemObjective":
        """Add a maximization objective.

        The expression must reference at least one decision variable declared via
        :meth:`solve_for`.

        Parameters
        ----------
        expr : Variable or float or int or Fragment
            Objective expression to maximize.
        name : Any or list[Any], optional
            Optional objective name (string for scalar, or a list pattern for
            indexed objectives).

        Returns
        -------
        ProblemObjective
            The objective subconcept (IS a Concept).

        Raises
        ------
        ValueError
            If the objective does not reference any declared decision variables.
        """
        return self._add_objective("max_objective", expr, name)

    def _add_objective(
        self,
        expr_type: Literal["min_objective", "max_objective"],
        expr: b.Variable | float | int | b.Fragment,
        name: Optional[Any | list[Any]],
    ) -> "ProblemObjective":
        """Add an objective (minimize or maximize)."""
        scalar_name, dsl_name = self._extract_scalar_name(name)
        sub = self._create_objective_subconcept(expr_type, name=scalar_name, dsl_expr=expr)
        self._add_expression(sub, expr, dsl_name)
        self.objectives.append(sub)
        return sub

    @include_in_docs
    def satisfy(
        self,
        expr: b.Fragment,
        name: Optional[Any | list[Any]] = None,
    ) -> "ProblemConstraint":
        """Add constraints from a ``model.require(...)`` fragment.

        Use this to turn a require-clause fragment into solver constraints.
        The returned :class:`ProblemConstraint` IS a Concept — annotate via
        ``model.define(constr.name("budget"))``, query via
        ``model.select(constr.name).where(constr)``.

        Passing a ``model.require(...)`` fragment to ``satisfy`` detaches it
        from the model's active integrity constraints — the solver enforces
        it instead, and it no longer fires engine-side. To also check it
        engine-side against the current solution after :meth:`solve`, call
        :meth:`verify` — it temporarily reinstalls the fragment as an IC,
        evaluates it, and removes it (one-shot).

        .. note::

            LP and MIP solvers return floating-point solutions that satisfy
            constraints within solver tolerance (e.g. ``1e-8``), but engine
            ICs check exact inequality.  For continuous-variable constraints,
            use a tolerant ``model.require()`` post-solve instead
            (e.g. ``model.require(x <= bound + 1e-6)``).

        Parameters
        ----------
        expr : Fragment
            A fragment created by :meth:`~relationalai.semantics.frontend.base.Model.require`
            (optionally scoped with :meth:`~relationalai.semantics.frontend.base.Model.where`).
        name : Any or list[Any], optional
            Optional constraint name (string for scalar, or a list pattern for
            indexed constraints).

        Returns
        -------
        ProblemConstraint
            The constraint subconcept (IS a Concept).

        Raises
        ------
        TypeError
            If ``expr`` is not a fragment.
        ValueError
            If the fragment has no require clause, or if it includes select/define
            clauses.
        """
        if not isinstance(expr, b.Fragment):
            raise TypeError(
                f"satisfy() expects a Fragment from model.require(...), "
                f"got {type(expr).__name__}. "
                f"Example: s.satisfy(model.require(x >= 5))"
            )
        if not expr._require:
            raise ValueError("Fragment must have a require clause. Example: s.satisfy(model.require(x >= 5))")
        if expr._select or expr._define:
            raise ValueError("Fragment must not have select or define clauses.")

        # Remove constraint from model roots to prevent pre-solve firing.
        if expr in self._model.requires:
            self._model._remove_rule(expr)

        scalar_name, dsl_name = self._extract_scalar_name(name)
        sub = self._create_constraint_subconcept(name=scalar_name, dsl_expr=expr)
        for req in expr._require:
            self._add_expression(sub, req, dsl_name, expr._where)
        self.constraints.append(sub)
        return sub

    # ------------------------------------------------------------------
    # Introspection — Python-level access to registered definitions
    # ------------------------------------------------------------------

    @include_in_docs
    def verify(self, *fragments: b.Fragment) -> None:
        """One-shot constraint verification against the current solution.

        Temporarily installs each fragment as an integrity constraint,
        triggers a model query to evaluate them, then removes them.
        A :class:`~v0.relationalai.errors.ModelWarning` is raised if
        any constraint is violated.

        Emits a :class:`UserWarning` and returns without checking if the
        most recent solve did not produce a successful solution (i.e.
        ``termination_status`` is not ``OPTIMAL``, ``LOCALLY_SOLVED``,
        or ``SOLUTION_LIMIT``).

        .. note::

            LP and MIP solvers return floating-point solutions that satisfy
            constraints within solver tolerance (e.g. ``1e-8``), but engine
            ICs check exact inequality.  For continuous-variable constraints,
            use a tolerant ``model.require()`` post-solve instead
            (e.g. ``model.require(x <= bound + 1e-6)``).

        Parameters
        ----------
        *fragments : Fragment
            One or more fragments previously passed to :meth:`satisfy`.
        """
        if not fragments:
            return
        # Check termination status first — skip IC check for non-successful solves.
        _VERIFY_OK = {"OPTIMAL", "LOCALLY_SOLVED", "SOLUTION_LIMIT"}
        info = self.solve_info()  # uses cache if available (no extra query after solve)
        status = (info.termination_status or "").upper()
        if not status:
            _warn(
                "No termination status",
                "verify(): no termination_status available (solve() may not have been called).",
            )
            return
        if status not in _VERIFY_OK:
            _warn(
                "Unsupported termination status",
                f"verify(): termination_status is '{status}' — "
                f"constraint verification is only meaningful for {' or '.join(sorted(_VERIFY_OK))}.",
            )
            return

        # One-shot: install ICs, trigger a query to evaluate them, remove ICs.
        # Installation is inside try so partial failures still clean up.
        installed: list[b.Fragment] = []
        try:
            for frag in fragments:
                if frag not in self._model.requires:
                    self._model._add_rule(frag)
                    installed.append(frag)
            # _add_rule bumps model._version, so solve_info() forces a
            # model re-install which evaluates the active ICs.
            self._solve_info_cache = None
            self.solve_info()
        finally:
            for frag in installed:
                if frag in self._model.requires:
                    self._model._remove_rule(frag)

    @staticmethod
    def _extract_scalar_name(name: Optional[Any | list[Any]]) -> tuple[Optional[str], Optional[Any]]:
        """Split a name into scalar and DSL components.

        Returns ``(scalar_name, dsl_name)`` where exactly one is set (or both
        ``None`` if *name* is ``None``). The DSL component is the
        ``make_name``-resolved value, not the raw input — callers can pass it
        straight to ``ent.name(...)`` without re-running ``make_name``.

        Scalar names go in standing rules; DSL names go per-entity.
        """
        if name is None:
            return None, None
        val = make_name(name)
        if isinstance(val, b.DSLBase):
            return None, val
        return val, None

    def _add_expression(
        self,
        subconcept: Any,
        expr: Any,
        name: Optional[Any | list[Any]],
        where: Optional[list[Any]] = None,
    ) -> None:
        """Add an objective or constraint expression to the model."""
        if expr is None:
            raise TypeError("Expression must not be None.")
        compiler = ExpressionCompiler(self)
        if where:
            compiler.wheres.extend(compiler.rewrite_where(*where))
        result = compiler.rewrite(expr)
        if not isinstance(result, SymbolicNode):
            raise ValueError(
                "Expression does not reference any decision variables. "
                "Ensure it contains at least one variable declared via solve_for(). "
                "Constant objectives and constraints are not supported."
            )

        # Create expression entity keyed by root hash (gives each expression a unique identity).
        ent = subconcept._new(root=result.expr)
        compiler.defines.append(ent)
        if name is not None:
            compiler.defines.append(ent.name(name))

        self._emit_defines(compiler)

    def _emit_defines(self, compiler: ExpressionCompiler) -> None:
        """Recursively emit model.define calls from the compiler's output.

        Each scope emits only the defines it *owns* — the slice past
        ``_owned_defines_start``. Entries before that index were copied from a
        parent scope for the child's internal ``select().where()`` use, and
        re-emitting them here would produce redundant define rules (the parent
        already owns them). The full ``compiler.wheres`` is still used as the
        grounding clause so that a child's defines retain access to the outer
        bindings.
        """
        own_defines = compiler.defines[compiler._owned_defines_start :]
        if own_defines:
            self._model.define(*own_defines).where(*compiler.wheres)
        for child in compiler.children:
            self._emit_defines(child)

    # =========================================================================
    # Model Inspection and Display
    # =========================================================================

    # =========================================================================
    # Problem & Solve Metadata (Graph-style Relationships)
    # =========================================================================
    #
    # These methods return Relationships, not plain values — they are usable
    # in model rules, ICs, and queries (e.g. model.require(p.num_variables() == 5)).
    # This is a deliberate API design: the prescriptive library is pre-release
    # and has no external users.  The previous @property accessors returned
    # Python scalars and could not be used in rules.
    #
    # For Python-side scalar access (e.g. printing results), use solve_info():
    #   info = p.solve_info()
    #   print(info.termination_status, info.objective_value)
    #
    # Lazily defined via cached_property — the derivation rule is installed once.
    #
    # Structural (pre-solve):
    #   p.num_variables(), p.num_constraints(),
    #   p.num_min_objectives(), p.num_max_objectives()
    #
    # Solve results (post-solve):
    #   p.termination_status(), p.objective_value(), p.solve_time_sec(),
    #   p.num_points(), p.solver_version(), p.printed_model(), p.error()

    def _ancillary_string_rel(self, key: str) -> Any:
        """Create a String Relationship derived from the _solve_info ancillary key-value store."""
        rel = self._model.Relationship(f"Problem {key} is {String:val}")
        val = String.ref()
        self._model.where(self._solve_info(key, val)).define(rel(val))
        return rel

    @include_in_docs
    def num_variables(self) -> b.Relationship:
        """Number of declared decision variables. Usable in rules and ICs.

        Returns
        -------
        Relationship
            An Integer Relationship counting the declared variables.
        """
        return self._num_variables

    @cached_property
    def _num_variables(self) -> Any:
        rel = self._model.Relationship(f"Problem has {Integer:num_variables} variables")
        self._model.define(rel(std.aggregates.count(self.Variable) | 0))
        return rel

    @include_in_docs
    def num_constraints(self) -> b.Relationship:
        """Number of declared constraints. Usable in rules and ICs.

        Returns
        -------
        Relationship
            An Integer Relationship counting the declared constraints.
        """
        return self._num_constraints

    @cached_property
    def _num_constraints(self) -> Any:
        rel = self._model.Relationship(f"Problem has {Integer:num_constraints} constraints")
        self._model.define(rel(std.aggregates.count(self.Constraint) | 0))
        return rel

    @include_in_docs
    def num_min_objectives(self) -> b.Relationship:
        """Number of minimization objectives. Usable in rules and ICs.

        Returns
        -------
        Relationship
            An Integer Relationship counting the minimization objectives.
        """
        return self._num_min_objectives

    @cached_property
    def _num_min_objectives(self) -> Any:
        rel = self._model.Relationship(f"Problem has {Integer:num_min_objectives} min objectives")
        self._model.define(rel(std.aggregates.count(self.Objective).where(self.Objective.sense == "minimize") | 0))
        return rel

    @include_in_docs
    def num_max_objectives(self) -> b.Relationship:
        """Number of maximization objectives. Usable in rules and ICs.

        Returns
        -------
        Relationship
            An Integer Relationship counting the maximization objectives.
        """
        return self._num_max_objectives

    @cached_property
    def _num_max_objectives(self) -> Any:
        rel = self._model.Relationship(f"Problem has {Integer:num_max_objectives} max objectives")
        self._model.define(rel(std.aggregates.count(self.Objective).where(self.Objective.sense == "maximize") | 0))
        return rel

    @include_in_docs
    def termination_status(self) -> b.Relationship:
        """Solver termination status (e.g. ``"OPTIMAL"``). Usable in rules and ICs.

        Returns
        -------
        Relationship
            A String Relationship containing the termination status.
        """
        return self._termination_status

    @cached_property
    def _termination_status(self) -> Any:
        return self._ancillary_string_rel("termination_status")

    @include_in_docs
    def objective_value(self) -> b.Relationship:
        """Objective value reported by the solver. Usable in rules and ICs.

        Solvers report a single objective per solve (the primary/best
        solution), not per-point objectives. This Relationship reflects the
        solver-reported value.

        Returns
        -------
        Relationship
            A numeric Relationship containing the objective value.
        """
        return self._objective_value

    @cached_property
    def _objective_value(self) -> Any:
        rel = self._model.Relationship(f"Problem objective value is {self.numeric_type:val}")
        val = self.numeric_type.ref()
        # Derive from solution 1 (the primary/best solution).  Multi-solution
        # solves (MiniZinc CP) report the same objective for all solutions.
        self._model.where(self._objective_values(1, val)).define(rel(val))
        return rel

    @include_in_docs
    def solve_time_sec(self) -> b.Relationship:
        """Solve time in seconds (Float Relationship). Usable in rules and ICs.

        Returns
        -------
        Relationship
            A Float Relationship containing the solve time in seconds.
        """
        return self._solve_time_sec

    @cached_property
    def _solve_time_sec(self) -> Any:
        rel = self._model.Relationship(f"Problem solve time is {Float:sec}")
        val = String.ref()
        sec = Float.ref()
        self._model.where(
            self._solve_info("solve_time_sec", val),
            _parse_float(val) == sec,
        ).define(rel(sec))
        return rel

    @include_in_docs
    def num_points(self) -> b.Relationship:
        """Number of solution points. Usable in rules and ICs.

        Returns
        -------
        Relationship
            An Integer Relationship counting the solution points.
        """
        return self._num_points

    @cached_property
    def _num_points(self) -> Any:
        rel = self._model.Relationship(f"Problem has {Integer:num_points} solution points")
        sol_idx = Integer.ref()
        var_hash = Hash.ref()
        val = self.numeric_type.ref()
        n = Integer.ref()
        # Project _points to distinct sol_index (dedup across var_hash × value).
        _sol = self._model.Relationship(f"Problem has solution {Integer:sol_idx}")
        self._model.where(self._points(sol_idx, var_hash, val)).define(_sol(sol_idx))
        self._model.where(std.aggregates.count(sol_idx, _sol(sol_idx)) == n).define(rel(n))
        return rel

    @include_in_docs
    def solver_version(self) -> b.Relationship:
        """Solver version string. Usable in rules and ICs.

        Returns
        -------
        Relationship
            A String Relationship containing the solver version.
        """
        return self._solver_version

    @cached_property
    def _solver_version(self) -> Any:
        return self._ancillary_string_rel("solver_version")

    @include_in_docs
    def printed_model(self) -> b.Relationship:
        """Solver-provided text representation of the problem. Usable in rules and ICs.

        Returns
        -------
        Relationship
            A String Relationship containing the printed model text.
        """
        return self._printed_model

    @cached_property
    def _printed_model(self) -> Any:
        return self._ancillary_string_rel("printed_model")

    @include_in_docs
    def error(self) -> b.Relationship:
        """Solver error message(s). Usable in rules and ICs.

        Returns
        -------
        Relationship
            A String Relationship containing solver error messages.
        """
        return self._error

    @cached_property
    def _error(self) -> Any:
        return self._ancillary_string_rel("error")

    @include_in_docs
    def display(self, part: Optional[b.Concept] = None, *, print_output: bool = True) -> str:
        """Print and return a human-readable summary of the problem.

        With no arguments, this shows a header with the numeric type, a
        bullet-list summary of variable/objective/constraint counts (zero
        categories are omitted), and tables of all declared variables,
        objectives, and constraints. Nothing is truncated — long expressions
        and large tables are emitted in full.

        Pass a :class:`ProblemVariable`, :class:`ProblemObjective`, or
        :class:`ProblemConstraint` returned by :meth:`solve_for`,
        :meth:`minimize`, :meth:`maximize`, or :meth:`satisfy` to display only
        that component.

        Parameters
        ----------
        part : ProblemVariable or ProblemObjective or ProblemConstraint, optional
            Specific component to display. Pass the value returned by the
            builder methods directly.
        print_output : bool, keyword-only, default True
            If ``True``, print the formatted output to stdout as a side
            effect. Set to ``False`` to receive the string without printing.

        Returns
        -------
        str
            The formatted summary.

        Raises
        ------
        ValueError
            If ``part`` is not a subconcept returned by :meth:`solve_for`,
            :meth:`minimize`, :meth:`maximize`, or :meth:`satisfy`.

        Examples
        --------
        Display the full problem:

        >>> from relationalai.semantics import Float, Model
        >>> from relationalai.semantics.reasoners.prescriptive import Problem
        >>> m = Model("demo")
        >>> x = m.Relationship(f"{Float:x}")
        >>> problem = Problem(m, Float)
        >>> x_vars = problem.solve_for(x, name="x", lower=0)
        >>> problem.minimize(x)
        >>> problem.display()

        Display a single component (returned by ``solve_for``/``minimize``/``satisfy``):

        >>> problem.display(x_vars)

        Capture output without printing:

        >>> text = problem.display(print_output=False)

        Notes
        -----
        This method queries the model.
        """
        if part is None:
            lines = self._display_full()
        else:
            lines = self._display_parts(part)
        output = "\n".join(lines)
        if print_output:
            print(output, end="\n\n")
        return output

    def _query_variables(self, source: b.Concept) -> tuple[DataFrame, Series]:
        """Query (var_df, var_types) from a Variable concept (root or subconcept).

        Empty result DataFrames may have no columns at all, so the integer
        type Series is constructed independently rather than via column access.
        The ``cast`` is needed because pandas-stubs types ``df[str]`` as
        ``Series | DataFrame`` (a single-string selector could theoretically
        be a MultiIndex), and narrowing is not inferred automatically.
        """
        var_df = self._model.select(source.type, source, source.name, source.lower, source.upper).to_df()
        if var_df.empty:
            return var_df, Series(dtype=int)
        return var_df, cast(Series, var_df["type"].astype(int))

    def _query_expressions(self, source: b.Concept) -> tuple[DataFrame, Series]:
        """Query (expr_df, expr_types) from an Expression concept (root or subconcept)."""
        expr_df = self._model.select(source.type, source.name, source.root).to_df()
        if expr_df.empty:
            return expr_df, Series(dtype=int)
        return expr_df, cast(Series, expr_df["type"].astype(int))

    @staticmethod
    def _join_sections(*sections: list[str]) -> list[str]:
        """Join non-empty section line-lists with single blank-line separators.

        Empty sections are skipped, so a problem with no expressions does not
        produce trailing blank lines. Each non-empty section is preceded by a
        single blank line *except* the first.
        """
        out: list[str] = []
        for section in sections:
            if not section:
                continue
            if out:
                out.append("")
            out.extend(section)
        return out

    def _display_full(self) -> list[str]:
        """Build display lines for the full model."""
        # TODO(coey): In future, issue multiple queries at the same time to reduce overhead.
        # Currently causes failures when running the pytest suite or the run_all.py script.
        # See https://relationalai.slack.com/archives/C08ATF88BC6/p1770146491179649?thread_ts=1768955416.245459&cid=C08ATF88BC6
        var_df, var_types = self._query_variables(self.Variable)
        expr_df, expr_types = self._query_expressions(self._Expression)
        ast = self._query_ast(self._reachable)

        # Counts come from query results (authoritative per-instance counts) rather
        # than len(self.variables) (declaration counts).
        def n_var(key: str) -> int:
            return int((var_types == _VAR_CODES[key]).sum())

        def n_expr(key: str) -> int:
            return int((expr_types == _EXPR_CODES[key]).sum())

        summary = format_summary(
            numeric_type_name=repr(self.numeric_type),
            n_cont=n_var("cont"),
            n_int=n_var("int"),
            n_bin=n_var("bin"),
            n_min_obj=n_expr("min_objective"),
            n_max_obj=n_expr("max_objective"),
            n_con=n_expr("constraint"),
        )
        return self._join_sections(
            summary,
            format_variable_table(var_df, var_types),
            format_expression_table(expr_df, expr_types, var_df, ast),
        )

    def _display_parts(self, part: b.Concept) -> list[str]:
        """Build display lines for a single variable or expression subconcept."""
        if any(part is v for v in self.variables):
            var_df, var_types = self._query_variables(part)
            return format_variable_table(var_df, var_types)

        if any(part is e for e in self.constraints + self.objectives):
            # Query all variables (needed for formatting variable references in expressions).
            var_df, _ = self._query_variables(self.Variable)

            # Reachability scoped to this subconcept's roots. These define()
            # calls add rules to the model that persist (PyRel defines are additive).
            # Transitive closure requires recursive rules, so there's no pure-query
            # alternative. The rules are cheap (anonymous Hash relationships) but each
            # call bumps the model version. For frequent partial display calls, prefer
            # display() with no argument (uses the standing _reachable rule).
            model = self._model
            n0, n1, i_, h_ = Hash.ref(), Hash.ref(), Integer.ref(), Hash.ref()
            reachable = model.Relationship(f"{Hash}")
            sub_ref = part.ref()
            model.define(reachable(sub_ref.root)).where(sub_ref)
            ctx = model.where(reachable(n0))
            ctx.define(reachable(n1)).where(self._ordered_args_hash(n0, i_, n1))
            ctx.define(reachable(n1)).where(self._unordered_args_hash(n0, h_, n1))

            expr_df, expr_types = self._query_expressions(part)
            return format_expression_table(expr_df, expr_types, var_df, self._query_ast(reachable))

        raise ValueError(
            f"Unrecognized display part: {part!r}. "
            f"Pass a subconcept returned by solve_for(), minimize(), maximize(), or satisfy()."
        )

    def _query_ast(self, reachable: Any) -> AstQueryResults:
        """Query AST nodes filtered by a reachability relation."""
        model = self._model
        n0 = Hash.ref().alias("node")
        n1 = Hash.ref().alias("arg")
        i = Integer.ref().alias("index")
        h = Hash.ref().alias("hash")
        op = Integer.ref().alias("op")
        v = self.numeric_type.ref().alias("value")

        return AstQueryResults(
            operators=model.select(n0, op).where(self._operator(n0, op), reachable(n0)).to_df(),
            ordered_hash=model.select(n0, i, n1).where(self._ordered_args_hash(n0, i, n1), reachable(n0)).to_df(),
            ordered_data=model.select(n0, i, v).where(self._ordered_args_data(n0, i, v), reachable(n0)).to_df(),
            unordered=model.select(n0, n1).where(self._unordered_args_hash(n0, h, n1), reachable(n0)).to_df(),
        )

    # =========================================================================
    # Solve
    # =========================================================================

    def _export_model_to_csv(self) -> dict[str, str]:
        """Export model relations to CSV files for solver service.

        AST nodes are filtered through the standing _reachable relation to
        exclude orphaned nodes (from expressions where one arm is empty).
        """
        from relationalai.shims.executor import export_to_csv

        model = self._model
        Var, Expr = self.Variable, self._Expression
        reachable = self._reachable

        # Create fresh ref variables per fragment so that batching into a single
        # transaction does not create unintended cross-fragment joins.
        n0_op, op_ = Hash.ref().alias("NODE"), Integer.ref().alias("OP")
        n0_oh, i_oh, n1_oh = (
            Hash.ref().alias("NODE"),
            Integer.ref().alias("INDEX"),
            Hash.ref().alias("ARG"),
        )
        n0_od, i_od, v_od = (
            Hash.ref().alias("NODE"),
            Integer.ref().alias("INDEX"),
            self.numeric_type.ref().alias("VALUE"),
        )
        n0_uh, h_uh, n1_uh = (
            Hash.ref().alias("NODE"),
            Hash.ref().alias("HASH"),
            Hash.ref().alias("ARG"),
        )

        keys = [
            "variables",
            "expressions",
            "operators",
            "ordered_args_hash",
            "ordered_args_data",
            "unordered_args_hash",
        ]
        fragments = [
            model.select(
                Var.alias("VARIABLE"),
                Var.name.alias("NAME"),
                Var.type.alias("TYPE"),
                Var.lower.alias("LOWER"),
                Var.upper.alias("UPPER"),
                Var.start.alias("START"),
            ),
            model.select(Expr.root.alias("NODE"), Expr.name.alias("NAME"), Expr.type.alias("TYPE")),
            model.select(n0_op, op_).where(self._operator(n0_op, op_), reachable(n0_op)),
            model.select(n0_oh, i_oh, n1_oh).where(self._ordered_args_hash(n0_oh, i_oh, n1_oh), reachable(n0_oh)),
            model.select(n0_od, i_od, v_od).where(self._ordered_args_data(n0_od, i_od, v_od), reachable(n0_od)),
            model.select(n0_uh, n1_uh).where(self._unordered_args_hash(n0_uh, h_uh, n1_uh), reachable(n0_uh)),
        ]
        paths = export_to_csv(fragments)
        return dict(zip(keys, paths))

    def _import_solver_results(self, result_views: dict[str, str] | None = None) -> None:
        """Import solver results into model relations.

        All solver result views (ancillary, points, objective_values) are loaded
        in one batched payload and mapped to target relations in a single call.
        Data stays in Snowflake and is consumed directly by the logic engine.

        ``experimental.load_data`` has replace semantics, so each solve refreshes
        the same target relations and this model can reuse one set of derivation
        rules for all solves. ``result_views`` may override the source view for
        each result table while keeping stable target relations.
        """
        model = self._model
        self._solve_info_cache = None

        resources = get_provider(config=model.config).resources
        if not isinstance(resources, SnowflakeResources):
            raise TypeError(f"Importing solver results requires Snowflake resources, got {type(resources).__name__}.")
        app_name = resources.get_app_name()
        logic_engine_name = resources.get_default_engine_name()
        num_type = self.numeric_type

        schemas: dict[str, dict[str, Any]] = {
            "ancillary": {"NAME": String, "VALUE": String},
            "points": {"SOL_INDEX": Integer, "VAR_HASH": String, "VALUE": num_type},
            "objective_values": {"SOL_INDEX": Integer, "VALUE": num_type},
        }

        if result_views is not None:
            expected = set(schemas.keys())
            actual = set(result_views.keys())
            if actual != expected:
                raise ValueError(
                    f"result_views must contain exactly {sorted(expected)}, got {sorted(actual)}"
                )

        if not self._result_tables:
            for name, schema in schemas.items():
                fqn = f"{app_name}.RESULTS.SOLVERS_{self._model_id}_{name.upper()}"
                table = model.Table(fqn, schema)
                # Skip CDC tracking — result tables use replace semantics,
                # so incremental change capture is unnecessary overhead.
                table._skip_cdc = True  # type: ignore[attr-defined]
                self._result_tables[name] = table

        table_fqns = [table._name for table in self._result_tables.values()]
        sources: dict[str, str] | None = None
        if result_views is not None:
            sources = {
                self._result_tables[name]._name: result_views[name]
                for name in schemas.keys()
            }
        _load_data_with_retry(
            model,
            resources,
            app_name,
            table_fqns,
            logic_engine_name,
            sources=sources,
        )

        # Rules are defined once; subsequent solves reuse them because
        # experimental.load_data replaces the underlying Table data in place.
        if not self._result_rules_defined:
            ancillary_tbl = self._result_tables["ancillary"]
            points_tbl = self._result_tables["points"]
            obj_vals_tbl = self._result_tables["objective_values"]

            model.define(self._solve_info(ancillary_tbl["NAME"], ancillary_tbl["VALUE"]))
            model.define(self._objective_values(obj_vals_tbl["SOL_INDEX"], obj_vals_tbl["VALUE"]))

            # Derive objective_value from objective_values table into ancillary
            # so solve_info() works without solver service ancillary changes.
            obj_val = self.numeric_type.ref()
            model.where(self._objective_values(1, obj_val)).define(
                self._solve_info("objective_value", std.strings.string(obj_val))
            )

            sol_idx = Integer.ref()
            var_hash_str = String.ref()
            val_ref = self.numeric_type.ref()
            model.where(
                points_tbl["SOL_INDEX"] == sol_idx,
                points_tbl["VAR_HASH"] == var_hash_str,
                points_tbl["VALUE"] == val_ref,
            ).define(self._points(sol_idx, std.common.parse_uuid(var_hash_str), val_ref))

            self._result_rules_defined = True

    def _wait_for_job(
        self,
        client: Any,
        job_id: str,
        log_to_console: bool = False,
        timeout_s: float = 900,
        poll_interval_s: float = 0.5,
    ) -> Any:
        """Poll job status until it reaches a terminal state, returning the job.

        Streams LogMessage events to stdout when *log_to_console* is True,
        using continuation tokens to avoid replaying events. Event streaming
        is best-effort — failures are silently ignored so they don't kill the
        solve. Performs a final event drain after the job reaches a terminal
        state (COMPLETED, FAILED, CANCELED, or ABORTED).

        Raises TimeoutError if the job has not reached a terminal state
        within *timeout_s* seconds.
        """
        import time as _time
        from relationalai.services.jobs.constants import JOB_TERMINAL_STATES

        continuation_token = ""
        deadline = _time.monotonic() + timeout_s

        def _drain_events() -> None:
            """Print LogMessage events, best-effort (errors silently ignored)."""
            nonlocal continuation_token
            try:
                events = client.jobs.get_events(
                    REASONER_TYPE,
                    job_id,
                    continuation_token=continuation_token,
                )
                for event in events.events:
                    msg = event.get("event", {}).get("message")
                    if event.get("type") == "LogMessage" and msg is not None:
                        print(msg)
                if events.continuation_token:
                    continuation_token = events.continuation_token
            except Exception:
                logger.debug("Failed to drain solver events", exc_info=True)

        while True:
            if log_to_console:
                _drain_events()

            job = client.jobs.get(REASONER_TYPE, job_id)
            if job and job.state and job.state.upper() in JOB_TERMINAL_STATES:
                if log_to_console:
                    _drain_events()
                return job

            if _time.monotonic() >= deadline:
                last_state = job.state if job and job.state else "not found"
                raise TimeoutError(f"Solver job {job_id} timed out after {timeout_s}s (last state: {last_state})")

            _time.sleep(poll_interval_s)

    @include_in_docs
    def solve(
        self,
        solver: str,
        *,
        time_limit_sec: float | None = None,
        silent: bool | None = None,
        solution_limit: int | None = None,
        relative_gap_tolerance: float | None = None,
        absolute_gap_tolerance: float | None = None,
        log_to_console: bool = False,
        print_only: bool = False,
        print_format: str | None = None,
        **solver_params: int | float | str | bool,
    ) -> None:
        """Solve the decision problem using a solver backend.

        Declare decision variables first with :meth:`solve_for`. After solving,
        inspect results via :meth:`variable_values` and result accessors such as
        :meth:`termination_status` and :meth:`objective_value`, or use
        :meth:`solve_info` for a Python-side snapshot.

        Parameters
        ----------
        solver : str
            Solver name (for example ``"highs"``, ``"minizinc"``, ``"ipopt"``).
        time_limit_sec : float, optional
            Maximum solve time in seconds. The solver service defaults to 300s
            if not provided.
        silent : bool, optional
            Whether to suppress solver output.
        solution_limit : int, optional
            Maximum number of solutions to return (when supported).
        relative_gap_tolerance : float, optional
            Relative optimality gap tolerance in ``[0, 1]``.
        absolute_gap_tolerance : float, optional
            Absolute optimality gap tolerance (>= 0).
        log_to_console : bool, default False
            Whether to stream solver logs to stdout while the job runs.
        print_only : bool, default False
            If True, request a text representation without solving. Results
            such as :meth:`printed_model` are still accessible afterward.
        print_format : str, optional
            Text format for the printed model. Supported formats: ``"moi"``
            (MOI text), ``"latex"``, ``"mof"`` (MOI JSON), ``"lp"``, ``"mps"``,
            ``"nl"`` (AMPL).
        **solver_params : int or float or str or bool
            Raw solver-specific parameters passed through to the solver service.

        Raises
        ------
        ValueError
            If no decision variables have been declared via :meth:`solve_for`.
        TypeError
            If any solver-specific parameter value is not an ``int``, ``float``,
            ``str``, or ``bool``.
        RuntimeError
            If the solver job fails.
        TimeoutError
            If the solver job does not reach a terminal state in time.

        Notes
        -----
        Passing ``**solver_params`` emits a warning because options may not be
        portable across solvers.
        """
        if not self._variable_relationships:
            raise ValueError("Cannot solve: no decision variables declared. Call solve_for() first.")
        if not isinstance(solver, str):
            raise TypeError(f"solver must be a string, got {type(solver).__name__}.")
        if "_server_side_import" in solver_params:
            raise TypeError(
                "The '_server_side_import' parameter has been removed. "
                "Simply remove it from your solve() call — result import is now handled automatically."
            )

        # Invalidate previous results before starting (see docstring above).
        self._solve_info_cache = None

        options: dict[str, Any] = {}
        if time_limit_sec is not None:
            options["time_limit_sec"] = float(time_limit_sec)
        if silent is not None:
            options["silent"] = bool(silent)
        if solution_limit is not None:
            options["solution_limit"] = int(solution_limit)
        if relative_gap_tolerance is not None:
            options["relative_gap_tolerance"] = float(relative_gap_tolerance)
        if absolute_gap_tolerance is not None:
            options["absolute_gap_tolerance"] = float(absolute_gap_tolerance)
        if print_only:
            options["print_only"] = True
        if print_format is not None:
            options["print_format"] = str(print_format)

        if solver_params:
            for value in solver_params.values():
                if not isinstance(value, (int, float, str, bool)):
                    raise TypeError(
                        f"Solver parameter values must be int, float, str, or bool, got {type(value).__name__}."
                    )
            _warn(
                "Solver-specific parameters",
                f"Solver-specific parameters {set(solver_params)} may not be portable across solvers.",
            )
            options.update(solver_params)

        import time

        client = connect_sync(config=self._model.config)
        ensure_op = client.reasoners.ensure(REASONER_TYPE)

        t0 = time.perf_counter()
        inputs = self._export_model_to_csv()
        logger.info("Exported CSV (%.2fs)", time.perf_counter() - t0)

        payload: dict[str, Any] = {
            "solver": solver.lower(),
            "version": 1,
            "options": options,
            "inputs": inputs,
            "model_id": self._model_id,
        }

        t1 = time.perf_counter()
        engine = ensure_op.wait()
        logger.info(
            "Solve: solver=%s, engine=%s, model_id=%s, options=%s",
            solver,
            engine.name,
            self._model_id,
            options,
        )
        op = client.jobs.create(REASONER_TYPE, engine.name, payload)
        # Add a 60s buffer on top of the solver's time limit so the client
        # doesn't time out before the solver does.
        wait_kwargs: dict[str, float] = {}
        if time_limit_sec is not None:
            wait_kwargs["timeout_s"] = float(time_limit_sec) + 60
        job = self._wait_for_job(client, op.id, log_to_console=log_to_console, **wait_kwargs)
        if (job.state or "").upper() != "COMPLETED":
            state = (job.state or "UNKNOWN").lower()
            reason = job.abort_reason or "no details available"
            raise RuntimeError(f"Solver job {job.id} {state}: {reason}")
        logger.info("Solver job %s completed (%.2fs)", job.id, time.perf_counter() - t1)
        t2 = time.perf_counter()
        self._import_solver_results()
        logger.info("Imported results (%.2fs)", time.perf_counter() - t2)

        return None

    # =========================================================================
    # Result Handling
    # =========================================================================

    @include_in_docs
    def variable_values(self, multiple: bool = False) -> b.Fragment:
        """Return decision variable values from the first solution.

        .. deprecated::
            Use ``Variable.values`` instead for composable engine-side queries::

                Var = problem.Variable
                val = Float.ref()  # or Integer.ref() for Integer-typed problems
                model.select(Var.name, val).where(Var.values(0, val))  # first solution

                # Multi-solution form (matches multiple=True):
                sol_idx = Integer.ref()
                model.select(sol_idx, Var.name, val).where(Var.values(sol_idx, val))

        Use this after :meth:`solve` to read variable values as a fragment you
        can materialize with ``.to_df()`` or print with ``.inspect()``. Without
        *multiple*, the returned fragment reflects the first solution only.

        Parameters
        ----------
        multiple : bool, default False
            If True, return values for all solutions from the most recent
            :meth:`solve` call and include a 0-based ``sol_index`` column.

        Returns
        -------
        Fragment
            A fragment with columns ``name`` and ``value`` (and ``sol_index`` if
            *multiple* is True). Returns an empty DataFrame if :meth:`solve`
            has not been called.
        """
        warnings.warn(
            "variable_values() is deprecated. Use the Variable.values Property: "
            "Var = problem.Variable; val = <NumericType>.ref(); "
            "model.select(Var.name, val).where(Var.values(0, val))",
            DeprecationWarning,
            stacklevel=2,
        )
        Var = self.Variable
        val_ref = self.numeric_type.ref()
        sol_idx = Integer.ref()
        if multiple:
            return self._model.select(
                sol_idx.alias("sol_index"),
                Var.name.alias("name"),
                val_ref.alias("value"),
            ).where(Var.values(sol_idx, val_ref))

        var_hash = core_cast(b.MetaRef(Hash), Var)
        return self._model.select(
            Var.name.alias("name"),
            val_ref.alias("value"),
        ).where(self._point(var_hash, val_ref))

    @include_in_docs
    def load_point(self, point_index: int) -> None:
        """Deprecated: switching the active solution point is no longer supported.

        .. deprecated::
            Populated properties and :meth:`variable_values` always reflect the
            first solution (``sol_index = 0``, matching Python 0-based
            indexing). ``load_point(0)`` is a no-op kept for backward
            compatibility and emits a :class:`DeprecationWarning`. Any other
            index raises :class:`NotImplementedError` — use
            ``Variable.values(sol_idx, val)`` to query a specific solution::

                Var = problem.Variable
                val = Float.ref()  # or Integer.ref() for Integer-typed problems
                model.select(Var.name, val).where(Var.values(2, val))  # 3rd solution

        Parameters
        ----------
        point_index : int
            Must be ``0``. Any other value raises :class:`NotImplementedError`.

        Raises
        ------
        ValueError
            If *point_index* is not a non-negative integer.
        NotImplementedError
            If *point_index* is not ``0``.
        """
        if isinstance(point_index, bool) or not isinstance(point_index, int) or point_index < 0:
            raise ValueError(f"Point index must be a non-negative integer, got {point_index!r}")
        if point_index != 0:
            # Map self.numeric_type back to the user-facing import name — its
            # internal _name is `"Number(38,0)"` for Integer and `"Float"` for
            # Float, so use identity checks rather than the engine name.
            numeric_type_name = "Integer" if self.numeric_type is Integer else "Float"
            raise NotImplementedError(
                f"load_point({point_index}) is no longer supported. Populated properties "
                "and variable_values() always reflect the first solution. To inspect "
                "another solution, query Variable.values directly: "
                f"Var = problem.Variable; val = {numeric_type_name}.ref(); "
                f"model.select(Var.name, val).where(Var.values({point_index}, val))."
            )
        warnings.warn(
            "load_point() is deprecated. Populated properties and variable_values() "
            "already reflect the first solution; calls to load_point(0) are no-ops. "
            "To inspect other solutions, query Variable.values directly: "
            "Var = problem.Variable; val = <NumericType>.ref(); "
            "model.select(Var.name, val).where(Var.values(sol_idx, val)).",
            DeprecationWarning,
            stacklevel=2,
        )

    # =========================================================================
    # Solve Info (Python Access)
    # =========================================================================

    @include_in_docs
    def solve_info(self) -> SolveInfoData:
        """Return solver result metadata as a cached :class:`SolveInfoData`.

        Fetches all result metadata in a single query. Subsequent calls
        return the cached snapshot until the next :meth:`solve`.

        Returns
        -------
        SolveInfoData
            Frozen dataclass with typed fields. Use ``print(si)`` or
            ``si.display()`` for a formatted summary. If :meth:`solve`
            has not been called, all fields are None (``error`` is ``()``).
        """
        if self._solve_info_cache is not None:
            return self._solve_info_cache

        # One query: batch-fetch all _solve_info key-value pairs.
        key_ref, val_ref = String.ref(), String.ref()
        df = self._model.select(key_ref, val_ref).where(self._solve_info(key_ref, val_ref)).to_df()
        info: dict[str, list[str]] = {}
        for _, row in df.iterrows():
            k, v = str(row.iloc[0]), str(row.iloc[1])
            info.setdefault(k, []).append(v)

        def _first(key: str) -> str | None:
            vals = info.get(key)
            return vals[0] if vals else None

        def _parse_num(s: str | None, as_int: bool = False) -> float | int | None:
            if s is None:
                return None
            try:
                return int(s) if as_int else float(s)
            except (ValueError, OverflowError):
                logger.warning("Could not parse ancillary value %r as %s", s, "int" if as_int else "float")
                return None

        stv = _first("solve_time_sec")
        obj_str = _first("objective_value")
        obj_value = _parse_num(obj_str, as_int=(self.numeric_type is Integer))

        # num_points from the Relationship (counts distinct sol_index in _points).
        # Falls back to ancillary string if Relationship returns empty (e.g. set_fake_results).
        np_df = self._model.select(self.num_points()).to_df()
        if not np_df.empty:
            np_value = int(np_df.iloc[0, 0])  # type: ignore[arg-type]
        else:
            np_value = _parse_num(_first("num_points"), as_int=True)

        self._solve_info_cache = SolveInfoData(
            termination_status=_first("termination_status"),
            objective_value=obj_value,
            solve_time_sec=_parse_num(stv),
            num_points=int(np_value) if np_value is not None else None,
            solver_version=_first("solver_version"),
            error=tuple(info.get("error", ())),
            printed_model=_first("printed_model"),
        )
        return self._solve_info_cache
