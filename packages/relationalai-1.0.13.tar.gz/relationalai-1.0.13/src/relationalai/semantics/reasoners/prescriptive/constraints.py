"""Structured constraint constructors for prescriptive problems.

Provides global constraint functions — implication, all-different, and special
ordered sets — for use inside ``model.require()`` fragments passed to
:meth:`~relationalai.semantics.reasoners.prescriptive.problem.Problem.satisfy`.
"""

from __future__ import annotations

from typing import Any

from relationalai.semantics.frontend import base as b
from relationalai.semantics import Integer, Any as CoreAny
from relationalai.semantics.frontend.core import TypeVar

from .wire_format import _library
from ....util.docutils import include_in_docs


_implies = _library.Relation("implies", fields=[b.Field.input("left", CoreAny), b.Field.input("right", CoreAny)])


@include_in_docs
def implies(left: Any, right: Any) -> b.Expression:
    """Return an implication constraint (``left`` => ``right``).

    Use this inside :meth:`~relationalai.semantics.frontend.base.Model.require` and
    pass the resulting fragment to :meth:`~relationalai.semantics.reasoners.prescriptive.problem.Problem.satisfy`.
    When passed to :meth:`~relationalai.semantics.reasoners.prescriptive.problem.Problem.satisfy`,
    both sides must reference at least one decision variable declared via
    :meth:`~relationalai.semantics.reasoners.prescriptive.problem.Problem.solve_for`.

    Parameters
    ----------
    left : Any
        Antecedent condition (a comparison or constraint).
    right : Any
        Consequent condition (a comparison or constraint).

    Returns
    -------
    Expression
        A solver expression representing the implication constraint.

    Examples
    --------
    Constrain two binary variables:

    >>> from relationalai.semantics import Float, Model
    >>> from relationalai.semantics.reasoners.prescriptive import Problem, implies
    >>> m = Model("implies_demo")
    >>> x = m.Relationship(f"{Float:x}")
    >>> y = m.Relationship(f"{Float:y}")
    >>> problem = Problem(m, Float)
    >>> problem.solve_for(x, name="x", type="bin")
    >>> problem.solve_for(y, name="y", type="bin")
    >>> problem.satisfy(m.require(implies(x == 1, y == 1)))
    """
    return _implies(left, right)


_all_different = _library.Relation("all_different", fields=[b.Field.input("over", TypeVar)])


@include_in_docs
def all_different(*args: b.Value) -> b.Aggregate:
    """Return an all-different constraint.

    Use this inside :meth:`~relationalai.semantics.frontend.base.Model.require` and
    pass the resulting fragment to :meth:`~relationalai.semantics.reasoners.prescriptive.problem.Problem.satisfy`.
    Arguments must reference decision variables declared via
    :meth:`~relationalai.semantics.reasoners.prescriptive.problem.Problem.solve_for`.
    For grouped constraints (for example, "all values are distinct per row"),
    scope it with :meth:`~relationalai.semantics.frontend.base.Aggregate.per`.

    Parameters
    ----------
    *args : Value
        One or more decision-variable expressions that must take distinct values.

    Returns
    -------
    Aggregate
        A solver aggregate representing the all-different constraint.

    Examples
    --------
    Constrain values to be distinct per row:

    >>> from relationalai.semantics import Integer, Model
    >>> from relationalai.semantics.reasoners.prescriptive import Problem, all_different
    >>> m = Model("all_different_demo")
    >>> Cell = m.Concept("Cell", identify_by={"row": Integer, "col": Integer})
    >>> Cell.val = m.Property(f"{Cell} has {Integer:val}")
    >>> m.define(
    ...     Cell.new(row=0, col=0),
    ...     Cell.new(row=0, col=1),
    ...     Cell.new(row=1, col=0),
    ...     Cell.new(row=1, col=1),
    ... )
    >>> problem = Problem(m, Integer)
    >>> problem.solve_for(Cell.val, name=["x", Cell.row, Cell.col], lower=1, upper=4)
    >>> problem.satisfy(m.require(all_different(Cell.val).per(Cell.row)).where(Cell))
    """
    return b.Aggregate(_all_different, *args)


_sos1 = _library.Relation(
    "special_ordered_set_type_1", fields=[b.Field.input("index", Integer), b.Field.input("variables", CoreAny)]
)


@include_in_docs
def special_ordered_set_type_1(index: Any, variables: Any) -> b.Aggregate:
    """Return an SOS1 constraint (at most one variable is non-zero).

    Use this inside :meth:`~relationalai.semantics.frontend.base.Model.require` and
    pass the resulting fragment to :meth:`~relationalai.semantics.reasoners.prescriptive.problem.Problem.satisfy`.
    Arguments must reference decision variables declared via
    :meth:`~relationalai.semantics.reasoners.prescriptive.problem.Problem.solve_for`.
    Commonly used for piecewise-linear formulations.

    Parameters
    ----------
    index : Any
        Ordering index used to define the set.
    variables : Any
        Decision-variable expression(s) in the SOS1 set.

    Returns
    -------
    Aggregate
        A solver aggregate representing the SOS1 constraint.

    Examples
    --------
    Create nonnegative weights and constrain them with SOS1:

    >>> from relationalai.semantics import Float, Integer, Model, std
    >>> from relationalai.semantics.reasoners.prescriptive import Problem, special_ordered_set_type_1
    >>> m = Model("sos1_demo")
    >>> Point = m.Concept("Point", identify_by={"i": Integer})
    >>> Point.w = m.Property(f"{Point} has {Float:w}")
    >>> m.define(Point.new(i=std.common.range(3)))
    >>> problem = Problem(m, Float)
    >>> problem.solve_for(Point.w, name=["w", Point.i], lower=0)
    >>> problem.satisfy(m.require(special_ordered_set_type_1(Point.i, Point.w)))
    """
    return b.Aggregate(_sos1, index, variables)


_sos2 = _library.Relation(
    "special_ordered_set_type_2", fields=[b.Field.input("index", Integer), b.Field.input("variables", CoreAny)]
)


@include_in_docs
def special_ordered_set_type_2(index: Any, variables: Any) -> b.Aggregate:
    """Return an SOS2 constraint (at most two consecutive variables are non-zero).

    Use this inside :meth:`~relationalai.semantics.frontend.base.Model.require` and
    pass the resulting fragment to :meth:`~relationalai.semantics.reasoners.prescriptive.problem.Problem.satisfy`.
    Arguments must reference decision variables declared via
    :meth:`~relationalai.semantics.reasoners.prescriptive.problem.Problem.solve_for`.
    The ordering in the set is defined by ``index`` (often a rank or position),
    and the constraint is commonly used for piecewise-linear formulations.
    For the SOS1 variant, see :func:`~relationalai.semantics.reasoners.prescriptive.problem.special_ordered_set_type_1`.

    Parameters
    ----------
    index : Any
        Ordering index that defines adjacency in the set.
    variables : Any
        Decision-variable expression(s) in the SOS2 set.

    Returns
    -------
    Aggregate
        A solver aggregate representing the SOS2 constraint.

    Examples
    --------
    See :func:`special_ordered_set_type_1` for a usage example; the call shape
    is identical (``special_ordered_set_type_2(index, variables)``).
    """
    return b.Aggregate(_sos2, index, variables)
