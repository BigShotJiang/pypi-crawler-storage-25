from . import Pass
from ....metamodel.metamodel import Model, Task
from .....config import Config
from typing import Tuple

class PassSequence(Pass):
    """
    A pass that applies a sequence of passes in order.
    """

    _passes: Tuple[Pass, ...]

    @property
    def name(self):
        name = "PassSequence(" + ", ".join(p.name for p in self._passes) + ")"
        return name

    def __init__(self, *passes: Pass):
        self._passes = passes

    def rewrite_model(self, model: Model, config:Config) -> Model:
        for p in self._passes:
            model = p.rewrite_model(model, config)
        return model

    def rewrite_task(self, node: Task, config:Config) -> Task:
        for p in self._passes:
            node = p.rewrite_task(node, config)
        return node
