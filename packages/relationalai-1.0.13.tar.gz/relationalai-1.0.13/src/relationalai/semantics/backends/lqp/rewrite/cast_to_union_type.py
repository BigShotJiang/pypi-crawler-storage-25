from . import Pass
from ....metamodel import metamodel as mm, builtins as bt
from ....metamodel.builtins import builtins, combine_types
from ....metamodel.rewriter import Rewriter, Walker
from .....config import Config

from collections import defaultdict

class CastToUnionType(Pass):
    """
    Removes casts between entity types, replacing them with a unified variable that has a
    union type. This is possible because entity types are physically represented by hashes
    and the typer already ensured that the model and query are correctly typed.

    From:
        Logical{…}
            Dog(dog::Dog)
            ◇ cast(Node, dog::Dog, node::Node)
            degree(node::Node, number::Number(38,0))
    To:
        Logical{…}
            Dog(dog::Node | Dog)
            degree(dog::Node | Dog, number::Number(38,0))
    """
    def _rewrite_task(self, node: mm.Task, config:Config) -> mm.Task:
        # find all casts between entity types and group variables by their source variable
        # (i.e., the variable being cast)
        cast_finder = self.CastFinder()
        cast_finder(node)
        if not cast_finder.casts_to_remove:
            return node

        # create a single variable for each group
        var_map:dict[int, mm.Var] = dict()
        for source, group in cast_finder.var_groups.items():
            union_type = combine_types([cast_finder.vars[var_id].type for var_id in group])
            var = mm.Var(type=union_type, name=cast_finder.vars[source].name)
            for var_id in group:
                var_map[var_id] = var

        # finally, remove casts and replace variables with their unified variable
        r = self.CastToUnionTypeRewriter(var_map, cast_finder.casts_to_remove)
        return r(node)


    class CastFinder(Walker):
        def __init__(self):
            super().__init__()
            self.vars:dict[int, mm.Var] = dict()
            self.var_groups:dict[int, set[int]] = defaultdict(set)
            self.casts_to_remove: set[int] = set()
            self.scope = []

        def enter_logical(self, node: mm.Logical) -> None:
            if node.scope:
                self.scope.append(node.id)

        def logical(self, node: mm.Logical) -> mm.Logical:
            if node.scope:
                self.scope.pop()
            return node

        def lookup(self, node: mm.Lookup):
            if node.relation == builtins.core.cast:
                source = node.args[1]
                target = node.args[2]
                if isinstance(source, mm.Var) and isinstance(target, mm.Var) and bt.only_entity_types(source.type) and bt.only_entity_types(target.type):
                    self.casts_to_remove.add(node.id)
                    # group variables by their source variable (i.e., the variable being cast)
                    self.var_groups[source.id].add(source.id)
                    self.var_groups[source.id].add(target.id)
                    # record variables by id (to lookup data later)
                    self.vars[source.id] = source
                    self.vars[target.id] = target


    class CastToUnionTypeRewriter(Rewriter):
        def __init__(self, vars_to_replace: dict[int, mm.Var], casts_to_remove: set[int]):
            super().__init__()
            self.vars_to_replace = vars_to_replace
            self.casts_to_remove = casts_to_remove
            self.scope = []

        def logical(self, node: mm.Logical) -> mm.Logical:
            # if there are casts to remove in the body of this logical, remove them
            if any(c.id in self.casts_to_remove for c in node.body):
                return node.replace(body=tuple(b for b in node.body if b.id not in self.casts_to_remove))
            return node

        def var(self, node: mm.Var) -> mm.Var:
            if node.id in self.vars_to_replace:
                return self.vars_to_replace[node.id]
            return node
