from dataclasses import dataclass
from ....metamodel.metamodel import Model, Task
from .....config import Config

from v0.relationalai import debugging

@dataclass
class Pass():
    """
    A compiler rewrite pass.
    """
    @property
    def name(self):
        return self.__class__.__name__

    def _rewrite_model(self, model: Model, config:Config) -> Model:
        new_root = self._rewrite_task(model.root, config)
        if new_root is model.root:
            return model
        return model.mut(root=new_root)

    def rewrite_model(self, model: Model, config:Config) -> Model:
        with debugging.span(f"{self.name} (Logic)") as span:
            new_model = self._rewrite_model(model, config)
            if new_model is not model:
                if debugging.DEBUG:
                    span["metamodel"] = str(new_model.root)

        return new_model

    def _rewrite_task(self, node: Task, config:Config) -> Task:
        raise NotImplementedError(f"{self.name} rewrite_task not implemented")

    def rewrite_task(self, node: Task, config:Config) -> Task:
        with debugging.span(f"{self.name} (Logic)") as span:
            new_task = self._rewrite_task(node, config)
            if new_task is not node:
                if debugging.DEBUG:
                    span["metamodel"] = str(new_task)

        return new_task

    def reset(self):
        pass
