"""Base Executor class for all PyRel backends."""

from __future__ import annotations

from typing import TYPE_CHECKING
from pandas import DataFrame

if TYPE_CHECKING:
    from relationalai.semantics.frontend.base import Model, Fragment

#------------------------------------------------------
# Executor (base)
#------------------------------------------------------

class Executor:
    """Backend-agnostic executor: takes a model+fragment, returns a DataFrame."""

    def execute_query(self, model: "Model", fragment: "Fragment", **kwargs) -> DataFrame:
        raise NotImplementedError(f"execute_query: {self}")
