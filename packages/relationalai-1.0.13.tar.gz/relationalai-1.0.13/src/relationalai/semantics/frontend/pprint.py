# pretty.py

from __future__ import annotations
from typing import Any, Iterable

from .base import (
    Aggregate,
    Alias,
    Chain,
    Concept,
    CoreLibrary,
    DSLBase,
    DerivedColumn,
    Distinct,
    Expression,
    Field,
    FieldRef,
    Fragment,
    Group,
    Literal,
    Match,
    New,
    Not,
    Reading,
    Ref,
    Relationship,
    Table,
    TupleVariable,
    Union,
    Variable,
)

#------------------------------------------------------
# Utility helpers
#------------------------------------------------------

def _is_multiline(s: str) -> bool:
    return "\n" in s

def _indent(s: str, level: int, unit: str) -> str:
    pad = unit * level
    return "\n".join(pad + line if line else pad for line in s.splitlines())

def _join_inline(parts: Iterable[str]) -> str:
    return ", ".join(parts)

# Maps internal operator short_name to Python display string.
_INFIX_TO_STR: dict[str, str] = {
    ">": ">",
    "<": "<",
    ">=": ">=",
    "<=": "<=",
    "=": "==",
    "!=": "!=",
    "+": "+",
    "-": "-",
    "*": "*",
    "/": "/",
    "//": "//",
    "%": "%",
    "^": "**",
}


def _infix_symbol(rel: Relationship | Concept) -> str | None:
    """Return the Python infix symbol if *rel* is a known binary operator, else None."""
    if not isinstance(rel, Relationship):
        return None
    return _INFIX_TO_STR.get(getattr(rel, "_short_name", ""))


def _relationship_label(rel: Relationship, *, include_owner: bool = True) -> str:
    short = getattr(rel, "_short_name", "")
    if short:
        model = getattr(rel, "_model", None)
        if model is CoreLibrary:
            return short
        if not include_owner:
            return short
        fields = getattr(rel, "_fields", [])
        if fields:
            owner = fields[0].type
            owner_name = getattr(owner, "_name", None)
            if owner_name:
                return f"{owner_name}.{short}"
        return short
    reading = getattr(rel, "_reading", "")
    if reading:
        return reading
    readings = getattr(rel, "_readings", None)
    if readings:
        return readings[0]._reading
    return ""

def _block(name: str, body_lines: list[str], level: int, unit: str, max_inline_len: int | None = None) -> str:
    """
    Renders:
    (name
      line1
      line2)
    """
    if not body_lines:
        return ""
    if (
        max_inline_len is not None
        and len(body_lines) == 1
        and not _is_multiline(body_lines[0])
    ):
        inline_form = f"({name} {body_lines[0]})"
        if len(inline_form) <= max_inline_len:
            return inline_form
    head = f"({name}"
    inner_lines = [_indent(line, 1, unit) for line in body_lines]
    if inner_lines:
        inner_lines[-1] = f"{inner_lines[-1]})"
    return "\n".join([head] + inner_lines)

#------------------------------------------------------
# The Pretty Printer
#------------------------------------------------------

class PrettyPrinter:
    def __init__(
        self,
        indent_unit: str = "  ",
        max_inline_len: int = 80,
        inline_args_threshold: int = 3,
    ):
        self.indent_unit = indent_unit
        self.max_inline_len = max_inline_len
        self.inline_args_threshold = inline_args_threshold
        # cache already-rendered nodes (protects against cycles / re-visits)
        self._seen = {}

    _CYCLE = "<...>"

    # Public entrypoint
    def format(self, obj: Any, level: int = 0) -> str:
        key = (id(obj), level)
        if key in self._seen:
            return self._seen[key]

        # Pre-insert sentinel to guard against cycles mid-format
        self._seen[key] = self._CYCLE

        # dynamic single-dispatch
        meth = None
        for cls in type(obj).__mro__:
            meth = getattr(self, f"_fmt_{cls.__name__}", None)
            if meth:
                break
        if meth is None:
            # Non-DSL objects (int, str, bool, etc.): use repr().
            # Unknown DSL subtypes: use ClassName() fallback.
            out = repr(obj) if not isinstance(obj, DSLBase) else f"{type(obj).__name__}()"
            self._seen[key] = out
            return out

        out = meth(obj, level)
        self._seen[key] = out
        return out

    #------------------------------------------------------
    # Leaf-ish nodes
    #------------------------------------------------------

    def _fmt_Concept(self, c: Concept, level: int) -> str:
        return getattr(c, "_repr_name", None) or c._name

    def _fmt_Table(self, t: Table, level: int) -> str:
        return t._name

    def _fmt_Literal(self, lit: Literal, level: int) -> str:
        v = lit._value
        return repr(v)

    def _fmt_Alias(self, a: Alias, level: int) -> str:
        src = self.format(a._source_item, level)
        return f"{src} AS {a._alias}"

    def _fmt_FieldRef(self, fr: FieldRef, level: int) -> str:
        src = self.format(fr._root, level)
        if isinstance(fr._field, (int,)):
            key = f"{fr._field}"
        elif hasattr(fr._field, "_name"):
            key = getattr(fr._field, "_name")
        else:
            key = str(fr._field)
        return f"{src}[{key}]"

    def _fmt_Ref(self, ref: Ref, level: int) -> str:
        concept = getattr(ref, "_concept", None)
        if concept is None:
            return "<ref>"
        concept_label = self.format(concept, level) if isinstance(concept, Variable) else str(concept)
        if getattr(ref, "_explicit_name", False):
            return f"{concept_label}.ref({ref._name!r})"
        return f"{concept_label}.ref"

    def _fmt_DerivedColumn(self, col: DerivedColumn, level: int) -> str:
        if col._name:
            return col._name

        table = col._table
        index = col._index

        if table is not None and isinstance(index, int):
            if isinstance(table, Fragment):
                source_values = table._select
                if isinstance(source_values, (list, tuple)) and 0 <= index < len(source_values):
                    return self.format(source_values[index], level)
            table_label = table.__class__.__name__
            return f"{table_label}[{index}]"

        return f"col{index}" if index is not None else "<col>"

    # ------------------------------------------------------
    # Standalone types (Model, Library, Data, Ordering, Per)
    # ------------------------------------------------------

    def _fmt_Model(self, m: Any, level: int) -> str:
        name = getattr(m, "name", None)
        cls = "Library" if getattr(m, "is_library", False) else "Model"
        if name:
            return f"{cls}({name!r})"
        return f"{cls}()"

    # Library inherits Model, so _fmt_Model handles it via is_library check.
    # MRO dispatch finds _fmt_Library first if we define it, so alias it.
    _fmt_Library = _fmt_Model

    def _fmt_Data(self, d: Any, level: int) -> str:
        cols = [r._short_name for r in getattr(d, "_known_columns", [])]
        return f"Data(columns={cols!r})"

    def _fmt_Ordering(self, o: Any, level: int) -> str:
        values = [self.format(v, level) for v in getattr(o, "_values", [])]
        is_asc = getattr(o, "_is_asc", True)
        label = "asc" if is_asc else "desc"
        inline = _join_inline(values)
        return f"({label} {inline})" if values else f"({label})"

    def _fmt_Per(self, p: Any, level: int) -> str:
        items = [self.format(it, level) for it in getattr(p, "_args", [])]
        inline = _join_inline(items)
        return f"(per {inline})" if items else "(per)"

    #------------------------------------------------------
    # Relationship / Reading
    #------------------------------------------------------

    def _fmt_Field(self, f: Field, level: int) -> str:
        t = self.format(f.type, level)
        if f.is_list:
            t = f"[{t}]"
        result = f"{f.name}: {t}"
        if f.is_input:
            result += " (input)"
        return result

    def _fmt_Relationship(self, r: Relationship, level: int) -> str:
        label = _relationship_label(r)
        if label:
            return label
        fields = ", ".join(self._fmt_Field(f, level) for f in r._fields)
        return f"rel({fields})"

    def _fmt_Reading(self, rd: Reading, level: int) -> str:
        label = _relationship_label(rd)
        if label:
            return label
        return rd._reading

    #------------------------------------------------------
    # Chains & Expressions
    #------------------------------------------------------

    def _fmt_Chain(self, p: Chain, level: int) -> str:
        start = self.format(p._start, level)
        nxt = _relationship_label(p._next, include_owner=False)
        if not nxt:
            nxt = self.format(p._next, level)
        return f"{start}.{nxt}"

    def _fmt_New(self, new: New, level: int) -> str:
        concept_label = self.format(new._op, level)
        op = f"{concept_label}.new"
        if new._identity_only:
            op += "_identity"
        arg_strs = [self.format(a, level) for a in new._args]
        kw_strs = [f"{k}={self.format(v, level)}" for k, v in (new._kwargs or {}).items()]
        parts = arg_strs + kw_strs

        if not parts:
            return op

        unit = self.indent_unit
        inline_pieces = [op] + parts
        inline_str = " ".join(inline_pieces)
        if (
            len(parts) <= self.inline_args_threshold
            and len(inline_str) + 2 <= self.max_inline_len
            and not any(_is_multiline(p) for p in parts)
        ):
            return f"({inline_str})"

        return _block(op, parts, level, unit, self.max_inline_len)

    def _fmt_Expression(self, e: Expression, level: int) -> str:
        # Infix rendering for binary operators
        symbol = _infix_symbol(e._op) if isinstance(e._op, Relationship) else None
        if symbol and len(e._args) >= 2:
            left_obj, right_obj = e._args[0], e._args[1]
            left = self.format(left_obj, level)
            right = self.format(right_obj, level)
            # Parenthesize nested infix sub-expressions
            if isinstance(left_obj, Expression) and _infix_symbol(left_obj._op):
                left = f"({left})"
            if isinstance(right_obj, Expression) and _infix_symbol(right_obj._op):
                right = f"({right})"
            return f"{left} {symbol} {right}"

        op = self.format(e._op, level)
        # Strip owner concept and output refs (non-input fields)
        args = list(e._args)
        if isinstance(e._op, (Relationship, Reading)) and args:
            fields: list[Field] = getattr(e._op, "_fields", [])
            if fields:
                owner = fields[0].type
                if args and args[0] is owner:
                    args = args[1:]
                # Strip auto-filled output refs, but only when the
                # relationship uses the input/output distinction (library
                # operators). Reading-parsed fields all have is_input=False.
                if any(f.is_input for f in fields):
                    if len(args) == len(fields):
                        args = [a for a, f in zip(args, fields) if f.is_input]
                    elif len(args) == len(fields) - 1:
                        args = [a for a, f in zip(args, fields[1:]) if f.is_input]
        arg_strs = []
        for a in args:
            s = self.format(a, level)
            # Parenthesize infix sub-expressions inside function calls
            if isinstance(a, Expression) and _infix_symbol(a._op):
                s = f"({s})"
            arg_strs.append(s)
        kw_strs = [f"{k}={self.format(v, level)}" for k, v in (e._kwargs or {}).items()]
        parts = arg_strs + kw_strs

        if not parts:
            return op

        unit = self.indent_unit
        inline_pieces = [op] + parts
        inline_str = " ".join(inline_pieces)
        if (
            len(parts) <= self.inline_args_threshold
            and len(inline_str) + 2 <= self.max_inline_len
            and not any(_is_multiline(p) for p in parts)
        ):
            return f"({inline_str})"

        return _block(op, parts, level, unit, self.max_inline_len)

    #------------------------------------------------------
    # Match, Union, Not, Distinct
    #------------------------------------------------------

    def _fmt_Match(self, m: Match, level: int) -> str:
        unit = self.indent_unit
        items = [self.format(it, level + 1) for it in m._items]
        inline = " | ".join(items)
        if len(inline) <= self.max_inline_len and all(not _is_multiline(s) for s in items):
            return f"(match {inline})"
        body = [s for s in items]
        return _block("match", body, level, unit)

    def _fmt_Union(self, u: Union, level: int) -> str:
        unit = self.indent_unit
        items = [self.format(it, level + 1) for it in u._items]
        inline = " & ".join(items)
        if len(inline) <= self.max_inline_len and all(not _is_multiline(s) for s in items):
            return f"(union {inline})"
        body = [s for s in items]
        return _block("union", body, level, unit)

    def _fmt_Not(self, n: Not, level: int) -> str:
        unit = self.indent_unit
        items = [self.format(it, level + 1) for it in n._items]
        inline = _join_inline(items)
        if len(inline) <= self.max_inline_len and all(not _is_multiline(s) for s in items):
            return f"(not {inline})"
        return _block("not", items, level, unit)

    def _fmt_Distinct(self, d: Distinct, level: int) -> str:
        unit = self.indent_unit
        items = [self.format(it, level + 1) for it in d._items]
        inline = _join_inline(items)
        if len(inline) <= self.max_inline_len and all(not _is_multiline(s) for s in items):
            return f"(distinct {inline})"
        return _block("distinct", items, level, unit)

    def _fmt_Group(self, group: Group, level: int) -> str:
        unit = self.indent_unit
        items = [self.format(it, level + 1) for it in group._args]
        if not items:
            return "(group)"
        inline = _join_inline(items)
        if len(inline) <= self.max_inline_len and all(not _is_multiline(s) for s in items):
            return f"(group {inline})"
        return _block("group", items, level, unit)

    def _fmt_Aggregate(self, agg: Aggregate, level: int) -> str:
        unit = self.indent_unit

        op_label = _relationship_label(agg._op, include_owner=False)
        if not op_label:
            op_label = self.format(agg._op, level)

        # Show projection args and input args, strip output refs.
        # Primitive input args (int, str, float, bool) get field-name labels
        # so internal parameters like index=1 are identifiable.
        fields = getattr(agg._op, "_fields", ())
        parts: list[str] = [self.format(arg, level + 1) for arg in agg._projection_args]
        if fields:
            for arg, field in zip(agg._args, fields):
                if not field.is_input:
                    continue
                s = self.format(arg, level + 1)
                if isinstance(arg, (int, float, str, bool)):
                    s = f"{field.name}={s}"
                parts.append(s)
        else:
            parts.extend(self.format(arg, level + 1) for arg in agg._args)

        group_args = getattr(agg._group, "_args", [])
        if group_args:
            pretty_group = [self.format(x, level + 1) for x in group_args]
            inline = _join_inline(pretty_group)
            if len(inline) <= self.max_inline_len and all(not _is_multiline(s) for s in pretty_group):
                parts.append(f"(per {inline})")
            else:
                parts.append(_block("per", pretty_group, level, unit, self.max_inline_len))

        where_fragment = agg._where
        if where_fragment is not None:
            where_items = where_fragment._where
            if where_items:
                pretty_where = [self.format(x, level + 1) for x in where_items]
                inline = _join_inline(pretty_where)
                if len(inline) <= self.max_inline_len and all(not _is_multiline(s) for s in pretty_where):
                    parts.append(f"(where {inline})")
                else:
                    parts.append(_block("where", pretty_where, level, unit, self.max_inline_len))

        if not parts:
            return op_label

        inline_pieces = [op_label] + parts
        inline_str = " ".join(inline_pieces)
        if (
            len(parts) <= self.inline_args_threshold
            and len(inline_str) + 2 <= self.max_inline_len
            and not any(_is_multiline(p) for p in parts)
        ):
            return f"({inline_str})"

        return _block(op_label, parts, level, unit, self.max_inline_len)

    #------------------------------------------------------
    # Fragment
    #------------------------------------------------------

    def _fmt_Fragment(self, f: Fragment, level: int) -> str:
        """
        Root label is the dominant clause (select/define/require/where).
        The dominant clause's items are promoted to top level to avoid
        redundancy like ``(select (select ...))``.
        """
        unit = self.indent_unit

        # Determine dominant clause
        if f._select:
            label = "select"
        elif f._define:
            label = "define"
        elif f._require:
            label = "require"
        else:
            label = "where"

        sections: list[str] = []

        for name, items in [
            ("select", f._select),
            ("define", f._define),
            ("require", f._require),
            ("where", f._where),
        ]:
            if not items:
                continue
            pretty_items = [self.format(x, level + 1) for x in items]
            if name == label:
                sections.extend(pretty_items)
            else:
                sections.append(_block(name, pretty_items, level, unit, self.max_inline_len))

        if f._order_by:
            pretty_items = [self.format(x, level + 1) for x in f._order_by]
            inline = _join_inline(pretty_items)
            if len(inline) <= self.max_inline_len and all(not _is_multiline(s) for s in pretty_items):
                sections.append(f"(order_by {inline})")
            else:
                sections.append(_block("order_by", pretty_items, level, unit, self.max_inline_len))
        if getattr(f, "_limit", 0):
            sections.append(f"(limit {f._limit})")

        sections = [s for s in sections if s]
        if not sections:
            return f"({label})"
        return _block(label, sections, level, unit, self.max_inline_len)

    #------------------------------------------------------
    # TupleVariable (wraps multiple values into one arg)
    # ------------------------------------------------------

    def _fmt_TupleVariable(self, tv: TupleVariable, level: int) -> str:
        items = [self.format(it, level) for it in tv._items]
        return _join_inline(items) if items else ""

    # ------------------------------------------------------
    # Fallback
    #------------------------------------------------------

    def _fmt_Variable(self, v: Variable, level: int) -> str:
        return f"{v.__class__.__name__}()"

#------------------------------------------------------
# Convenience API
#------------------------------------------------------

def format(obj: Any, **opts) -> str:
    """
    Pretty-format any DSL object.
    Example: print(format(fragment))
    """
    return PrettyPrinter(**opts).format(obj)

def pprint(obj: Any, **opts):
    """
    Pretty-print any DSL object.
    Example: print(pp(fragment))
    """
    print(format(obj, **opts))
