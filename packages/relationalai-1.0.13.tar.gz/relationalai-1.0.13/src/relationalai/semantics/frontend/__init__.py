"""User-facing frontend for the semantics DSL.

Use this package to construct and work with semantics DSL objects.
"""


__include_in_docs__ = True