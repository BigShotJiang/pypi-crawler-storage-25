"""Runtime-layer error taxonomy."""

from __future__ import annotations

from relationalai.util.docutils import include_in_docs


__include_in_docs__ = True


@include_in_docs
class RuntimeError(Exception):
    """Base error for runtime transport/session/execution operations."""


@include_in_docs
class RuntimeAuthError(RuntimeError):
    """Authentication/authorization error (transport-level)."""


@include_in_docs
class RuntimeConnectionError(RuntimeError):
    """Connection/session creation error (transport-level)."""


@include_in_docs
class RuntimeExecutionError(RuntimeError):
    """SQL execution error (transport-level)."""


@include_in_docs
class RuntimeValidationError(RuntimeExecutionError):
    """Invalid request / validation error returned by a remote service."""


@include_in_docs
class RuntimeUnknownError(RuntimeError):
    """Fallback when we cannot classify a runtime failure."""

