from __future__ import annotations

SUMMARY_EVENT_GRAPH_INDEX_ENABLED = "graph_index_enabled"
SUMMARY_EVENT_SERVICE_ENDPOINT_CACHE_HIT = "service_endpoint_cache_hit"
SUMMARY_EVENT_TOKEN_CACHE_HIT = "token_cache_hit"

__all__ = [
    "SUMMARY_EVENT_GRAPH_INDEX_ENABLED",
    "SUMMARY_EVENT_SERVICE_ENDPOINT_CACHE_HIT",
    "SUMMARY_EVENT_TOKEN_CACHE_HIT",
]
