# Environment variable names used by the config system.

#: Env var that pins an explicit config file path, bypassing auto-discovery.
RAI_CONFIG_FILE_PATH_ENV_VAR = "RAI_CONFIG_FILE_PATH"

#: Env var that overrides the build output directory (default: "build").
RAI_BUILD_DIR_ENV_VAR = "RAI_BUILD_DIR"
