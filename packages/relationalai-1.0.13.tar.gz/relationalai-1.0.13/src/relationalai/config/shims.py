from typing import Optional
from datetime import datetime

# Configuration shims for tests and CLI

# Do not execute, just generate code
DRY_RUN = False
# Use a specific model name for all tests
FORCE_MODEL_NAME = ""
# Force LQP's datetime_now to this value for consistent snapshots
DATETIME_NOW: Optional[datetime] = None
