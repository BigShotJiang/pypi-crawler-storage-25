"""Exceptions and context helpers for configuration errors.

These errors are raised when loading or validating configuration with the
:func:`~relationalai.config.create_config` factory function.
"""

__include_in_docs__ = True

from .exceptions import (
    ConfigError,
    ConfigFileNotFoundError,
    ConfigValidationError,
    ConfigFieldMissingError,
    ConfigFieldTypeError,
    AttemptedSource,
)
from .context import ConfigErrorContext, ConfigSourceType

__all__ = [
    "ConfigError",
    "ConfigFileNotFoundError",
    "ConfigValidationError",
    "ConfigFieldMissingError",
    "ConfigFieldTypeError",
    "AttemptedSource",
    "ConfigErrorContext",
    "ConfigSourceType",
]
