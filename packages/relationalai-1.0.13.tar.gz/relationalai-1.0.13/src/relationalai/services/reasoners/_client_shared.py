from __future__ import annotations

import re
from typing import Any, TYPE_CHECKING, cast

from . import constants as c
from .errors import (
    ReasonerConflictError,
    ReasonerInvalidRequestError,
    ReasonerNotFoundError,
    ReasonerNotReadyError,
)
from .models import Reasoner, ReasonerType
from .util import sanitize_user_name

if TYPE_CHECKING:
    from relationalai.config.config import Config

    from .operations import _EnsureRequested

_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]*$")


def normalize_reasoner_type(reasoner_type: str) -> str:
    if not isinstance(reasoner_type, str) or not reasoner_type.strip():
        raise ReasonerInvalidRequestError(
            "Reasoner `reasoner_type` is required (Logic, Prescriptive, or Predictive)."
        )
    try:
        return ReasonerType.normalize(reasoner_type)
    except ValueError as e:
        raise ReasonerInvalidRequestError(str(e)) from e


def normalize_name_optional(name: str | None) -> str | None:
    if name is None:
        return None
    if not isinstance(name, str):
        raise ReasonerInvalidRequestError("Reasoner `reasoner_name` must be a string.")
    value = name.strip()
    if not value:
        return None
    if not _NAME_RE.match(value):
        raise ReasonerInvalidRequestError(
            "Invalid reasoner `name`. Use letters/digits plus '_' or '-', "
            "starting with a letter or digit (e.g. 'my_solver', 'user-1')."
        )
    return value


def normalize_reasoner_type_optional(reasoner_type: str | None) -> str | None:
    if reasoner_type is None:
        return None
    return normalize_reasoner_type(reasoner_type)


def check_reasoner_ready(
    reasoner: Reasoner | None, reasoner_name: str, reasoner_type: str, context: str
) -> Reasoner:
    if reasoner is None:
        raise ReasonerNotFoundError(
            f"Reasoner not found {context}: reasoner_name={reasoner_name} reasoner_type={reasoner_type}"
        )
    if (reasoner.state or "").upper() != c.REASONER_STATE_READY:
        raise ReasonerNotReadyError(f"Reasoner is not READY {context}: state={reasoner.state}")
    return reasoner


def mismatch_message(
    *,
    reasoner_name: str,
    reasoner_type: str,
    requested: "_EnsureRequested",
    existing: Reasoner,
) -> str | None:
    diffs: list[str] = []
    if requested.size is not None and existing.size != requested.size:
        diffs.append(f"size (requested={requested.size!r}, existing={existing.size!r})")
    if requested.auto_suspend_mins is not None and existing.auto_suspend_mins != requested.auto_suspend_mins:
        diffs.append(
            f"auto_suspend_mins (requested={requested.auto_suspend_mins!r}, existing={existing.auto_suspend_mins!r})"
        )
    existing_await_storage_vacuum = None
    if isinstance(existing.settings, dict) and "await_storage_vacuum" in existing.settings:
        existing_await_storage_vacuum = existing.settings.get("await_storage_vacuum")
    if (
        requested.await_storage_vacuum is not None
        and isinstance(existing.settings, dict)
        and "await_storage_vacuum" in existing.settings
        and existing_await_storage_vacuum != requested.await_storage_vacuum
    ):
        diffs.append(
            "await_storage_vacuum "
            f"(requested={requested.await_storage_vacuum!r}, existing={existing_await_storage_vacuum!r})"
        )
    if requested.settings is not None and existing.settings != requested.settings:
        diffs.append(f"settings (requested={requested.settings!r}, existing={existing.settings!r})")
    if not diffs:
        return None
    return (
        "Reasoner already exists but does not match requested configuration: "
        f"name={reasoner_name!r} type={reasoner_type!r}. Mismatches: " + ", ".join(diffs)
    )


def raise_on_mismatch(
    *,
    reasoner_name: str,
    reasoner_type: str,
    requested: "_EnsureRequested",
    existing: Reasoner,
) -> None:
    msg = mismatch_message(
        reasoner_name=reasoner_name,
        reasoner_type=reasoner_type,
        requested=requested,
        existing=existing,
    )
    if msg is not None:
        raise ReasonerConflictError(msg)


def default_username(config: "Config | None") -> str:
    if config is None:
        return "default"
    try:
        conn = config.get_default_connection()
    except Exception:
        return "default"
    user = getattr(conn, "user", None)
    if isinstance(user, str) and user.strip():
        sanitized = sanitize_user_name(user)
        return sanitized or "default"
    return "default"


def reasoner_defaults(
    config: "Config | None", reasoner_type: str
) -> tuple[str | None, str | None, int | None, bool | None, dict[str, Any] | None]:
    if config is None:
        return None, None, None, None, None

    if reasoner_type == c.REASONER_TYPE_LOGIC:
        section = config.reasoners.logic
    elif reasoner_type == c.REASONER_TYPE_PREDICTIVE:
        section = config.reasoners.predictive
    elif reasoner_type == c.REASONER_TYPE_PRESCRIPTIVE:
        section = config.reasoners.prescriptive
    else:
        section = config.reasoners.logic

    return (
        section.name,
        cast(str | None, section.size),
        cast(int | None, None),
        cast(bool | None, None),
        section.settings,
    )


def resolve_identity_and_defaults(
    config: "Config | None",
    reasoner_type: str,
    reasoner_name: str | None,
    *,
    size: str | None,
    auto_suspend_mins: int | None,
    await_storage_vacuum: bool | None,
    settings: dict[str, Any] | None,
) -> tuple[str, str | None, int | None, bool | None, dict[str, Any] | None]:
    normalized_type = normalize_reasoner_type(reasoner_type)
    cfg_name, cfg_size, cfg_auto, cfg_await_storage_vacuum, cfg_settings = reasoner_defaults(config, normalized_type)
    normalized_name = normalize_name_optional(reasoner_name)
    normalized_cfg_name = normalize_name_optional(cfg_name)
    normalized_default_name = normalize_name_optional(default_username(config))
    resolved_name = normalized_name or normalized_cfg_name or (normalized_default_name or "default")
    resolved_size = size if size is not None else cfg_size
    resolved_auto = auto_suspend_mins if auto_suspend_mins is not None else cfg_auto
    resolved_await_storage_vacuum = (
        await_storage_vacuum if await_storage_vacuum is not None else cfg_await_storage_vacuum
    )
    resolved_settings = settings if settings is not None else cfg_settings
    return resolved_name, resolved_size, resolved_auto, resolved_await_storage_vacuum, resolved_settings


def polling_cfg(config: "Config | None") -> tuple[float, float, float]:
    if config is None:
        return 0.01, 0.1, 0.5
    reasoners_cfg = config.reasoners
    return (
        float(reasoners_cfg.poll_initial_delay_s),
        float(reasoners_cfg.poll_overhead_rate),
        float(reasoners_cfg.poll_max_delay_s),
    )
