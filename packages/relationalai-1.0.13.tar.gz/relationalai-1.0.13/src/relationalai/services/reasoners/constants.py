"""
Reasoners package constants.

Why this lives in `relationalai.services.reasoners` (not `relationalai.runtime`):
- These values are domain-specific to the reasoners API surface and its backends
  (Snowflake SQL app schema names, reasoner/job/operation states, keyword matching, etc.).
- `runtime/` is intended to stay generic (execution/middleware/retry) and reusable.
"""

from __future__ import annotations

from typing import Final

from relationalai.services.constants import (
    REASONER_TYPE_LOGIC,
    REASONER_TYPE_PREDICTIVE,
    REASONER_TYPE_PRESCRIPTIVE,
)

# --- wiring / defaults ---

DEFAULT_REASONERS_SCHEMA: Final[str] = "api"
EXECUTION_LOGGER_NAME: Final[str] = "relationalai.client.execution"

# Direct Access API base path for reasoners endpoints.
REASONERS_DA_BASE_PATH: Final[str] = "/v1alpha1/engines"

# --- reasoner types ---

DEFAULT_REASONER_TYPE: Final[str] = REASONER_TYPE_LOGIC

REASONER_TYPE_LABELS: Final[dict[str, str]] = {
    REASONER_TYPE_LOGIC: "Logic",
    REASONER_TYPE_PRESCRIPTIVE: "Prescriptive",
    REASONER_TYPE_PREDICTIVE: "Predictive",
}

REASONER_TYPE_DESCRIPTIONS: Final[dict[str, str]] = {
    REASONER_TYPE_LOGIC: "Logic reasoner for deductive reasoning and relational queries",
    REASONER_TYPE_PRESCRIPTIVE: "Optimization reasoner for prescriptive reasoning",
    REASONER_TYPE_PREDICTIVE: "Predictive reasoner for pattern recognition and forecasting",
}

# --- operation/job status ---

STATUS_PENDING: Final[str] = "PENDING"
STATUS_RUNNING: Final[str] = "RUNNING"
STATUS_SUCCEEDED: Final[str] = "SUCCEEDED"
STATUS_FAILED: Final[str] = "FAILED"
STATUS_CANCELLED: Final[str] = "CANCELLED"

TERMINAL_STATUSES: Final[set[str]] = {STATUS_SUCCEEDED, STATUS_FAILED, STATUS_CANCELLED}

# --- reasoner lifecycle state (backend state) ---

REASONER_STATE_READY: Final[str] = "READY"
REASONER_STATE_SUSPENDED: Final[str] = "SUSPENDED"
REASONER_STATE_PENDING: Final[str] = "PENDING"
REASONER_STATE_PROVISIONING: Final[str] = "PROVISIONING"
REASONER_STATE_FAILED: Final[str] = "FAILED"
REASONER_STATE_ERROR: Final[str] = "ERROR"

REASONER_FAILED_STATES: Final[set[str]] = {REASONER_STATE_FAILED, REASONER_STATE_ERROR}

# --- reasoner sizes ---

REASONER_SIZES_INTERNAL: Final[list[str]] = ["XS", "S", "M", "L"]
REASONER_SIZES_AWS: Final[list[str]] = ["HIGHMEM_X64_S", "HIGHMEM_X64_M", "HIGHMEM_X64_L"]
REASONER_SIZES_AZURE: Final[list[str]] = ["HIGHMEM_X64_S", "HIGHMEM_X64_M", "HIGHMEM_X64_SL"]

# --- error keyword matching (Snowflake / backend message parsing) ---

# Note: backend error messages still use the word "engine" (native app implementation detail).
REASONER_RESOURCE_ERRORS: Final[tuple[str, ...]] = (
    "engine is suspended",
    "create/resume",
    "engine not found",
    "no engines found",
    "engine was deleted",
)
REASONER_RESOURCE_NOT_READY_MSGS: Final[tuple[str, ...]] = ("engine is in pending", "engine is provisioning")
DATABASE_ERRORS: Final[tuple[str, ...]] = ("database not found",)

