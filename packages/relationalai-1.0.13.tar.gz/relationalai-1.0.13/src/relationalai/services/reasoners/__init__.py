"""Reasoners service package.

This package contains the public service clients (`ReasonersClient`, `ReasonersClientSync`),
their domain models, and the wiring/gateway adapters used to talk to different backends
(Snowflake SQL app vs Direct Access HTTP).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .client import ReasonersClient as ReasonersClient
    from .client_sync import ReasonersClientSync as ReasonersClientSync

__include_in_docs__ = True


def __getattr__(name: str) -> object:
    # Keep package import lightweight and avoid import cycles when callers import
    # submodules (e.g. `from relationalai.services.reasoners.models import ...`).
    if name == "ReasonersClient":
        from .client import ReasonersClient as _ReasonersClient

        return _ReasonersClient
    if name == "ReasonersClientSync":
        from .client_sync import ReasonersClientSync as _ReasonersClientSync

        return _ReasonersClientSync
    raise AttributeError(name)


__all__ = ["ReasonersClient", "ReasonersClientSync"]
