"""Synchronous Reasoners service client.

This module provides the blocking (sync) API used by `relationalai.client.connect_sync()`.
The client delegates backend-specific behavior to a `ReasonersGatewaySync`.
"""

from __future__ import annotations

from typing import Any, TYPE_CHECKING

from relationalai.util.docutils import include_in_docs
from relationalai.util.polling import poll_until_sync

from . import constants as c
from ._client_shared import (
    check_reasoner_ready,
    default_username,
    mismatch_message,
    normalize_name_optional,
    normalize_reasoner_type,
    normalize_reasoner_type_optional,
    polling_cfg,
    raise_on_mismatch,
    reasoner_defaults,
    resolve_identity_and_defaults,
)
from .errors import (
    ReasonerConflictError,
    ReasonerNotFoundError,
    ReasonerNotReadyError,
    ReasonerTimeoutError,
)
from .models import Operation, Reasoner
from .operations import ReasonerOperationSync, _EnsureRequested, _op_id
from .protocol import ReasonersGatewaySync
from .util import _pick_reasoner_match

if TYPE_CHECKING:
    from relationalai.config.config import Config

__include_in_docs__ = True


@include_in_docs
class ReasonersClientSync:
    """Synchronous reasoners client (public API for `connect_sync()`)."""

    def __init__(
        self,
        gateway: ReasonersGatewaySync,
        *,
        config: "Config | None" = None,
    ):
        """Create a synchronous reasoners client.

        Args:
            gateway: Backend adapter implementing `ReasonersGatewaySync`.
            config: Optional config used for defaults (name/size/settings) and polling knobs.
        """
        self._gateway = gateway
        self._config = config

    @include_in_docs
    def close(self) -> None:
        """Close the client (no-op).

        Note: gateways do not own shared transports; the root platform client is
        responsible for closing transports/sessions.

        Returns
        -------
        None
            Always returns `None`.
        """
        # Gateways do not own shared transports; the root client closes them.
        return None

    # ---- shared helpers ----
    def _normalize_reasoner_type(self, reasoner_type: str) -> str:
        return normalize_reasoner_type(reasoner_type)

    def _normalize_name_optional(self, name: str | None) -> str | None:
        return normalize_name_optional(name)

    def _normalize_reasoner_type_optional(self, reasoner_type: str | None) -> str | None:
        return normalize_reasoner_type_optional(reasoner_type)

    def _check_reasoner_ready(
        self, r: Reasoner | None, reasoner_name: str, reasoner_type: str, context: str
    ) -> Reasoner:
        return check_reasoner_ready(r, reasoner_name, reasoner_type, context)

    def _mismatch_message(
        self,
        *,
        reasoner_name: str,
        reasoner_type: str,
        requested: _EnsureRequested,
        existing: Reasoner,
    ) -> str | None:
        return mismatch_message(
            reasoner_name=reasoner_name,
            reasoner_type=reasoner_type,
            requested=requested,
            existing=existing,
        )

    def _raise_on_mismatch(
        self,
        *,
        reasoner_name: str,
        reasoner_type: str,
        requested: _EnsureRequested,
        existing: Reasoner,
    ) -> None:
        raise_on_mismatch(
            reasoner_name=reasoner_name,
            reasoner_type=reasoner_type,
            requested=requested,
            existing=existing,
        )

    def _default_username(self) -> str:
        return default_username(self._config)

    def _reasoner_defaults(
        self, t: str
    ) -> tuple[str | None, str | None, int | None, bool | None, dict[str, Any] | None]:
        return reasoner_defaults(self._config, t)

    def _resolve_identity_and_defaults(
        self,
        reasoner_type: str,
        reasoner_name: str | None,
        *,
        size: str | None,
        auto_suspend_mins: int | None,
        await_storage_vacuum: bool | None,
        settings: dict[str, Any] | None,
    ) -> tuple[str, str | None, int | None, bool | None, dict[str, Any] | None]:
        return resolve_identity_and_defaults(
            self._config,
            reasoner_type,
            reasoner_name,
            size=size,
            auto_suspend_mins=auto_suspend_mins,
            await_storage_vacuum=await_storage_vacuum,
            settings=settings,
        )

    def _polling_cfg(self) -> tuple[float, float, float]:
        return polling_cfg(self._config)

    def _get_existing_reasoner(self, reasoner_type: str, reasoner_name: str) -> Reasoner | None:
        """Get a reasoner by canonical `(type, name)` without list fallback."""
        return self._gateway.get(reasoner_type, reasoner_name)

    def _lookup_existing_reasoner(self, reasoner_type: str, reasoner_name: str) -> Reasoner | None:
        """Resolve a reasoner even when backend get/list filters are case-sensitive."""
        direct = self._get_existing_reasoner(reasoner_type, reasoner_name)
        if direct is not None:
            return direct
        candidates = self._gateway.list()
        return _pick_reasoner_match(candidates, reasoner_type, reasoner_name)

    # --- lifecycle (sync) ---
    @include_in_docs
    def list(
        self,
        *,
        state: str | None = None,
        reasoner_name: str | None = None,
        reasoner_type: str | None = None,
        reasoner_size: str | None = None,
        created_by: str | None = None,
    ) -> list[Reasoner]:
        """List reasoners, optionally filtering by attributes.

        Returns
        -------
        list[Reasoner]
            Matching reasoners.
        """
        t = self._normalize_reasoner_type_optional(reasoner_type)
        return self._gateway.list(
            state=state,
            reasoner_name=reasoner_name,
            reasoner_type=t,
            reasoner_size=reasoner_size,
            created_by=created_by,
        )

    @include_in_docs
    def get(self, reasoner_type: str, reasoner_name: str) -> Reasoner | None:
        """Get a reasoner by `(type, name)`, returning `None` if not found.

        Returns
        -------
        Reasoner | None
            The reasoner, or `None` if not found.
        """
        t = self._normalize_reasoner_type(reasoner_type)
        return self._lookup_existing_reasoner(t, reasoner_name)

    @include_in_docs
    def create(
        self,
        reasoner_type: str,
        reasoner_name: str | None = None,
        *,
        reasoner_size: str | None = None,
        auto_suspend_mins: int | None = None,
        await_storage_vacuum: bool | None = None,
        settings: dict[str, Any] | None = None,
    ) -> ReasonerOperationSync:
        """Create a reasoner and return an operation handle (non-blocking).

        Returns
        -------
        ReasonerOperationSync
            An operation handle; call `op.wait(...)` to block for readiness.
        """

        t = self._normalize_reasoner_type(reasoner_type)
        resolved_name, resolved_size, resolved_auto, resolved_await_storage_vacuum, resolved_settings = (
            self._resolve_identity_and_defaults(
                t,
                reasoner_name,
                size=reasoner_size,
                auto_suspend_mins=auto_suspend_mins,
                await_storage_vacuum=await_storage_vacuum,
                settings=settings,
            )
        )
        existing = self._lookup_existing_reasoner(t, resolved_name)
        if existing is not None:
            resolved_name = existing.name
            raise ReasonerConflictError(
                f"Reasoner already exists: name={resolved_name} type={t} state={existing.state}"
            )

        op = self._gateway.create(
            t,
            resolved_name,
            reasoner_size=resolved_size,
            auto_suspend_mins=resolved_auto,
            await_storage_vacuum=resolved_await_storage_vacuum,
            settings=resolved_settings,
        )
        return ReasonerOperationSync(
            client=self, id=op.id, metadata={"reasoner_name": resolved_name, "reasoner_type": t}
        )

    @include_in_docs
    def delete(self, reasoner_type: str, reasoner_name: str | None = None) -> None:
        """Delete a reasoner.

        Args:
            reasoner_type: Reasoner type (Logic, Prescriptive, Predictive).
            reasoner_name: Optional name (defaults to config/user-derived).
        Returns
        -------
        None
            Always returns `None`.
        """
        t = self._normalize_reasoner_type(reasoner_type)
        resolved_name, _size, _auto, _await_storage_vacuum, _settings = self._resolve_identity_and_defaults(
            t, reasoner_name, size=None, auto_suspend_mins=None, await_storage_vacuum=None, settings=None
        )
        existing = self._lookup_existing_reasoner(t, resolved_name)
        return self._gateway.delete(t, existing.name if existing is not None else resolved_name)

    @include_in_docs
    def alter_auto_suspend_mins(self, reasoner_type: str, reasoner_name: str, auto_suspend_mins: int) -> None:
        """Alter the auto-suspend timeout for an existing reasoner.

        Parameters
        ----------
        reasoner_type : str
            Reasoner type (Logic, Prescriptive, Predictive).
        reasoner_name : str
            Name of the reasoner to alter.
        auto_suspend_mins : int
            New auto-suspend timeout in minutes.
        """
        t = self._normalize_reasoner_type(reasoner_type)
        self._gateway.alter_auto_suspend_mins(t, reasoner_name, auto_suspend_mins)

    @include_in_docs
    def suspend(self, reasoner_type: str, reasoner_name: str | None = None) -> None:
        """Suspend a reasoner.

        Returns
        -------
        None
            Always returns `None`.
        """
        t = self._normalize_reasoner_type(reasoner_type)
        resolved_name, _size, _auto, _await_storage_vacuum, _settings = self._resolve_identity_and_defaults(
            t, reasoner_name, size=None, auto_suspend_mins=None, await_storage_vacuum=None, settings=None
        )
        existing = self._lookup_existing_reasoner(t, resolved_name)
        return self._gateway.suspend(t, existing.name if existing is not None else resolved_name)

    @include_in_docs
    def resume(self, reasoner_type: str, reasoner_name: str | None = None) -> ReasonerOperationSync:
        """Resume a reasoner and return an operation handle (non-blocking).

        Returns
        -------
        ReasonerOperationSync
            An operation handle; call `op.wait(...)` to block for readiness.
        """
        t = self._normalize_reasoner_type(reasoner_type)
        resolved_name, _size, _auto, _await_storage_vacuum, _settings = self._resolve_identity_and_defaults(
            t, reasoner_name, size=None, auto_suspend_mins=None, await_storage_vacuum=None, settings=None
        )
        existing = self._lookup_existing_reasoner(t, resolved_name)
        actual_name = existing.name if existing is not None else resolved_name
        op = self._gateway.resume(t, actual_name)
        return ReasonerOperationSync(
            client=self, id=op.id, metadata={"reasoner_name": actual_name, "reasoner_type": t}
        )

    @include_in_docs
    def ensure(
        self,
        reasoner_type: str,
        reasoner_name: str | None = None,
        *,
        reasoner_size: str | None = None,
        auto_suspend_mins: int | None = None,
        await_storage_vacuum: bool | None = None,
        settings: dict[str, Any] | None = None,
        create: bool = True,
        resume: bool = True,
    ) -> ReasonerOperationSync:
        """Ensure a reasoner exists and is READY, returning an operation handle (non-blocking).

        - If missing and `create=True`, creates it.
        - If SUSPENDED and `resume=True`, resumes it.
        - Otherwise returns an operation handle derived from reasoner state.
        Returns
        -------
        ReasonerOperationSync
            An operation handle representing the ensure workflow.
        """
        t = self._normalize_reasoner_type(reasoner_type)
        resolved_name, resolved_size, resolved_auto, resolved_await_storage_vacuum, resolved_settings = (
            self._resolve_identity_and_defaults(
                t,
                reasoner_name,
                size=reasoner_size,
                auto_suspend_mins=auto_suspend_mins,
                await_storage_vacuum=await_storage_vacuum,
                settings=settings,
            )
        )

        existing = self._lookup_existing_reasoner(t, resolved_name)
        if existing is None:
            if not create:
                raise ReasonerNotFoundError(f"Reasoner not found: name={resolved_name} type={t}")
            try:
                op = self._gateway.create(
                    t,
                    resolved_name,
                    reasoner_size=resolved_size,
                    auto_suspend_mins=resolved_auto,
                    await_storage_vacuum=resolved_await_storage_vacuum,
                    settings=resolved_settings,
                )
            except ReasonerConflictError as e:
                # Another caller created the engine between our get() and create().
                # Re-fetch and fall through to the existing-engine path.
                existing = self._lookup_existing_reasoner(t, resolved_name)
                if existing is None:
                    raise ReasonerNotFoundError(
                        f"Reasoner not found after create conflict: name={resolved_name} type={t}"
                    ) from e
            else:
                return ReasonerOperationSync(
                    client=self,
                    id=op.id,
                    metadata={"reasoner_name": resolved_name, "reasoner_type": t},
                    _ensure_requested=_EnsureRequested(
                        size=reasoner_size,
                        auto_suspend_mins=auto_suspend_mins,
                        await_storage_vacuum=await_storage_vacuum,
                        settings=settings,
                    ),
                )
        if existing is not None:
            # Existing reasoner: validate explicitly requested details before proceeding.
            self._raise_on_mismatch(
                reasoner_name=resolved_name,
                reasoner_type=t,
                requested=_EnsureRequested(
                    size=reasoner_size,
                    auto_suspend_mins=auto_suspend_mins,
                    await_storage_vacuum=await_storage_vacuum,
                    settings=settings,
                ),
                existing=existing,
            )
            state = (existing.state or "").upper()
            if state == c.REASONER_STATE_READY:
                return ReasonerOperationSync(
                    client=self,
                    id=_op_id("ensure", reasoner_type=t, reasoner_name=resolved_name),
                    metadata={"reasoner_name": resolved_name, "reasoner_type": t},
                    _result=existing,
                    _ensure_requested=_EnsureRequested(
                        size=reasoner_size,
                        auto_suspend_mins=auto_suspend_mins,
                        await_storage_vacuum=await_storage_vacuum,
                        settings=settings,
                    ),
                )
            if state in c.REASONER_FAILED_STATES:
                raise ReasonerNotReadyError(f"Reasoner exists but is not READY: state={existing.state}")
            if state == c.REASONER_STATE_SUSPENDED:
                if not resume:
                    raise ReasonerNotReadyError(f"Reasoner is SUSPENDED: name={resolved_name} type={t}")
                try:
                    op = self._gateway.resume(t, resolved_name)
                except ReasonerConflictError:
                    # Another caller already started the resume — fall through to polling.
                    pass
                else:
                    return ReasonerOperationSync(
                        client=self,
                        id=op.id,
                        metadata={"reasoner_name": resolved_name, "reasoner_type": t},
                        _ensure_requested=_EnsureRequested(
                            size=reasoner_size,
                            auto_suspend_mins=auto_suspend_mins,
                            await_storage_vacuum=await_storage_vacuum,
                            settings=settings,
                        ),
                    )

        # Provisioning/pending/etc: represent as a derived operation from reasoner state.
        return ReasonerOperationSync(
            client=self,
            id=_op_id("ensure", reasoner_type=t, reasoner_name=resolved_name),
            metadata={"reasoner_name": resolved_name, "reasoner_type": t},
            _ensure_requested=_EnsureRequested(
                size=reasoner_size,
                auto_suspend_mins=auto_suspend_mins,
                await_storage_vacuum=await_storage_vacuum,
                settings=settings,
            ),
        )

    @include_in_docs
    def create_ready(
        self,
        reasoner_type: str,
        reasoner_name: str | None = None,
        *,
        reasoner_size: str | None = None,
        auto_suspend_mins: int | None = None,
        await_storage_vacuum: bool | None = None,
        settings: dict[str, Any] | None = None,
        timeout_s: int = 900,
    ) -> Reasoner:
        """Create a reasoner and block until it is READY.

        Returns
        -------
        Reasoner
            The created reasoner in READY state.
        """
        op = self.create(
            reasoner_type,
            reasoner_name,
            reasoner_size=reasoner_size,
            auto_suspend_mins=auto_suspend_mins,
            await_storage_vacuum=await_storage_vacuum,
            settings=settings,
        )
        return op.wait(timeout_s=timeout_s)

    @include_in_docs
    def resume_ready(
        self, reasoner_type: str, reasoner_name: str | None = None, *, timeout_s: int = 900
    ) -> Reasoner:
        """Resume a reasoner and block until it is READY.

        Returns
        -------
        Reasoner
            The reasoner in READY state.
        """
        op = self.resume(reasoner_type, reasoner_name)
        return op.wait(timeout_s=timeout_s)

    @include_in_docs
    def ensure_ready(
        self,
        reasoner_type: str,
        reasoner_name: str | None = None,
        *,
        reasoner_size: str | None = None,
        auto_suspend_mins: int | None = None,
        await_storage_vacuum: bool | None = None,
        settings: dict[str, Any] | None = None,
        create: bool = True,
        resume: bool = True,
        timeout_s: int = 900,
    ) -> Reasoner:
        """Ensure a reasoner exists and is READY, blocking until completion.

        Returns
        -------
        Reasoner
            The reasoner in READY state.
        """
        op = self.ensure(
            reasoner_type,
            reasoner_name,
            reasoner_size=reasoner_size,
            auto_suspend_mins=auto_suspend_mins,
            await_storage_vacuum=await_storage_vacuum,
            settings=settings,
            create=create,
            resume=resume,
        )
        return op.wait(timeout_s=timeout_s)

    @include_in_docs
    def wait_until_ready(self, reasoner_type: str, reasoner_name: str, *, timeout_s: float = 900) -> Reasoner:
        """Poll until the reasoner is READY (or raise on timeout/not-found).

        Returns
        -------
        Reasoner
            The reasoner in READY state.
        """
        t = self._normalize_reasoner_type(reasoner_type)
        return self._wait_until_ready(reasoner_name=reasoner_name, reasoner_type=t, timeout_s=timeout_s)

    def _wait_until_ready(self, *, reasoner_name: str, reasoner_type: str, timeout_s: float) -> Reasoner:
        """Poll until a reasoner is READY and return the final resolved record."""
        resolved_name = reasoner_name
        use_direct_get_only = False
        resolved_ready: Reasoner | None = None

        def ready() -> bool:
            """Return True when the reasoner reaches READY state."""
            nonlocal resolved_name, use_direct_get_only, resolved_ready
            if use_direct_get_only:
                r = self._get_existing_reasoner(reasoner_type, resolved_name)
            else:
                r = self._lookup_existing_reasoner(reasoner_type, resolved_name)
            if r is not None:
                resolved_name = r.name
                use_direct_get_only = True
            state = ((r.state if r is not None else None) or "").upper()
            if state == c.REASONER_STATE_READY:
                resolved_ready = r
                return True
            return False

        initial_delay, overhead_rate, max_delay = self._polling_cfg()
        poll_until_sync(
            ready,
            timeout_s=float(timeout_s),
            initial_delay=initial_delay,
            overhead_rate=overhead_rate,
            max_delay=max_delay,
            timeout_error=lambda secs: ReasonerTimeoutError(f"Timed out after {secs}s waiting for completion"),
        )
        r = resolved_ready
        return self._check_reasoner_ready(r, resolved_name, reasoner_type, "after wait")

    @include_in_docs
    def sizes(self) -> list[str]:
        """Return supported reasoner sizes for the configured backend.

        Returns
        -------
        list[str]
            Allowed size identifiers.
        """
        return self._gateway.sizes()

    @include_in_docs
    def validate_size(self, size: str | None) -> tuple[bool, list[str]]:
        """Validate a size, returning `(is_valid, allowed_sizes)`.

        Returns
        -------
        tuple[bool, list[str]]
            A `(is_valid, allowed_sizes)` pair.
        """
        return self._gateway.validate_size(size)

    # --- operations (sync) ---
    @include_in_docs
    def get_operation(self, operation_id: str) -> Operation:
        """Fetch an operation by id.

        Returns
        -------
        Operation
            The operation status.
        """
        return self._gateway.get_operation(operation_id)

    @include_in_docs
    def wait_for_operation(self, operation_id: str, *, timeout_s: int = 900) -> Operation:
        """Block until an operation completes (or fails on timeout).

        Returns
        -------
        Operation
            The final operation status.
        """
        return self._gateway.wait_for_operation(operation_id, timeout_s=timeout_s)

