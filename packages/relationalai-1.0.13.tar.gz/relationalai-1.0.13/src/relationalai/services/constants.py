from __future__ import annotations

from typing import Final

# Shared defaults/constants across domain services.
#
# Keep this module small and high-signal: only place values here when they are
# truly shared by 2+ services. Service-specific constants should remain in
# `services/<service>/constants.py`.

# Shared reasoner/engine type strings (used by multiple services).
REASONER_TYPE_LOGIC: Final[str] = "LOGIC"
REASONER_TYPE_PRESCRIPTIVE: Final[str] = "PRESCRIPTIVE"
REASONER_TYPE_PREDICTIVE: Final[str] = "PREDICTIVE"

REASONER_TYPES: Final[set[str]] = {REASONER_TYPE_LOGIC, REASONER_TYPE_PRESCRIPTIVE, REASONER_TYPE_PREDICTIVE}

__all__ = [
    "REASONER_TYPE_LOGIC",
    "REASONER_TYPE_PRESCRIPTIVE",
    "REASONER_TYPE_PREDICTIVE",
    "REASONER_TYPES",
]

