"""Shared service-layer helpers.

This package holds small utilities that are shared across multiple services
(`reasoners`, `jobs`, etc.) but are not themselves a domain service.
"""

from __future__ import annotations

__all__ = []

