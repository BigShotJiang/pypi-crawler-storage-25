from __future__ import annotations

from typing import Any, Mapping


def uppercase_keys(d: Mapping[str, Any]) -> dict[str, Any]:
    return {str(k).upper(): v for k, v in d.items()}


def coerce_da_artifact_results(results_obj: Any) -> dict[str, dict[str, Any]]:
    """Normalize DA artifact payload into `{filename -> metadata}` with uppercase keys."""
    out: dict[str, dict[str, Any]] = {}
    if isinstance(results_obj, dict) and "results" in results_obj:
        results_obj = results_obj.get("results")
    if not isinstance(results_obj, list):
        return out
    for r in results_obj:
        if not isinstance(r, dict):
            continue
        fn = r.get("filename") or r.get("FILENAME")
        if not fn:
            continue
        out[str(fn)] = uppercase_keys(r)
    return out


__all__ = ["coerce_da_artifact_results", "uppercase_keys"]

