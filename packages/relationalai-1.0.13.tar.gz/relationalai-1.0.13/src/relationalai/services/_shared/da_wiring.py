from __future__ import annotations

from typing import TYPE_CHECKING

from .da_request import BaseUrlProvider

if TYPE_CHECKING:
    from relationalai.client.core import ClientCore


def build_da_base_url_provider(core: "ClientCore") -> BaseUrlProvider:
    """Return a provider that resolves the current Direct Access base URL on demand."""

    def _provider(enforce_update: bool = False) -> str:
        return core.direct_access_base_url(enforce_update=bool(enforce_update))

    return _provider


__all__ = ["build_da_base_url_provider"]
