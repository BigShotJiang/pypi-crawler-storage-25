from __future__ import annotations

from datetime import datetime, timezone
from decimal import Decimal
from typing import Any


def coerce_datetime(value: Any) -> datetime | None:
    """Best-effort datetime coercion across SQL and Direct Access timestamp shapes.

    Supported inputs include:
    - `datetime`
    - SQL-style strings like `2026-03-06 13:39:54`
    - ISO 8601 strings, including trailing `Z`
    - Unix epoch seconds / milliseconds as `int`, `float`, `Decimal`, or numeric strings
    """
    if value is None:
        return None
    if isinstance(value, datetime):
        return value
    if isinstance(value, bool):
        return None
    if isinstance(value, Decimal):
        value = int(value)
    if isinstance(value, (int, float)):
        raw = float(value)
        candidates: list[datetime] = []
        raw_candidates = [raw / 1000.0, raw] if abs(raw) >= 1e10 else [raw]
        for candidate in raw_candidates:
            try:
                candidates.append(datetime.fromtimestamp(candidate, tz=timezone.utc))
            except Exception:
                continue
        if not candidates:
            return None
        for candidate in candidates:
            if 1900 <= candidate.year <= 3000:
                return candidate
        return candidates[0]
    if isinstance(value, str):
        s = value.strip()
        if not s:
            return None
        if s.isdigit():
            return coerce_datetime(int(s))
        try:
            return datetime.fromisoformat(s.replace("Z", "+00:00"))
        except Exception:
            return None
    return None


__all__ = ["coerce_datetime"]
