from __future__ import annotations

from typing import Mapping
from urllib.parse import quote, urlencode


def build_url(
    base_url: str,
    endpoint: str,
    *,
    path_params: Mapping[str, object] | None = None,
    query_params: Mapping[str, object] | None = None,
) -> str:
    """Build an endpoint URL with escaped path/query params."""
    url = f"{base_url}{endpoint}"
    if path_params:
        escaped = {k: quote(str(v), safe="") for k, v in path_params.items()}
        url = url.format(**escaped)
    if query_params:
        url += "?" + urlencode({k: str(v) for k, v in query_params.items()})
    return url


__all__ = ["build_url"]

