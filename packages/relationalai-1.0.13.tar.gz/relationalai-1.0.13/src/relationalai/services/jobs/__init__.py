"""Jobs service package."""

from __future__ import annotations

from .models import Job, JobEvents, JobExpanded, JobInclude
from .operations import JobOperation, JobOperationSync
from .util import compose_payload, make_job_payload, make_txn_payload
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .client import JobsClient as JobsClient
    from .client_sync import JobsClientSync as JobsClientSync

__include_in_docs__ = True


def __getattr__(name: str) -> Any:  # noqa: ANN401
    # Keep package import lightweight (avoid importing config/pydantic unless needed).
    if name == "JobsClient":
        from .client import JobsClient as _JobsClient

        return _JobsClient
    if name == "JobsClientSync":
        from .client_sync import JobsClientSync as _JobsClientSync

        return _JobsClientSync
    raise AttributeError(name)


__all__ = [
    "Job",
    "JobEvents",
    "JobExpanded",
    "JobInclude",
    "JobOperation",
    "JobOperationSync",
    "JobsClient",
    "JobsClientSync",
    "compose_payload",
    "make_job_payload",
    "make_txn_payload",
]

