# Code generated from JSON Schema. DO NOT EDIT.
from __future__ import annotations
from typing import Any, Dict, Optional


class ValidateBody:
    identifier: Optional[str]
    context: Optional[Dict[str, Any]]

    def __init__(self, identifier: Optional[str] = None, context: Optional[Dict[str, Any]] = None) -> None:
        self.identifier = identifier
        self.context = context

    def to_dict(self) -> Dict[str, Any]:
        result: Dict[str, Any] = {}
        if self.identifier is not None:
            result["identifier"] = self.identifier
        if self.context is not None:
            result["context"] = self.context
        return result

    @staticmethod
    def from_dict(d: Dict[str, Any]) -> "ValidateBody":
        return ValidateBody(identifier=d.get("identifier"), context=d.get("context"))


class ReceiveMessage:
    identifier: str
    slug: str
    company_id: Optional[float]
    context: Optional[Dict[str, Any]]

    def __init__(self, identifier: str, slug: str, company_id: Optional[float] = None, context: Optional[Dict[str, Any]] = None) -> None:
        self.identifier = identifier
        self.slug = slug
        self.company_id = company_id
        self.context = context

    def to_dict(self) -> Dict[str, Any]:
        result: Dict[str, Any] = {"identifier": self.identifier, "slug": self.slug}
        if self.company_id is not None:
            result["companyId"] = self.company_id
        if self.context is not None:
            result["context"] = self.context
        return result

    @staticmethod
    def from_dict(d: Dict[str, Any]) -> "ReceiveMessage":
        return ReceiveMessage(
            identifier=d["identifier"],
            slug=d["slug"],
            company_id=d.get("companyId"),
            context=d.get("context"),
        )
