"""HTTP client for the Flagly feature-flag API."""

from __future__ import annotations

import json
import urllib.parse
import urllib.request
from typing import Any, Dict, Optional

from .models import ValidateBody, ReceiveMessage


DEFAULT_BASE_URL = "https://api.useflagly.com.br"


class UseFlaglyClient:
    """Client for the Flagly /validate API."""

    def __init__(self, base_url: str = DEFAULT_BASE_URL, token: Optional[str] = None, timeout: float = 10.0) -> None:
        self._base_url = base_url.rstrip("/")
        self._token = token
        self._timeout = timeout

    def _headers(self, environment: Optional[str] = None) -> Dict[str, str]:
        h = {"Content-Type": "application/json"}
        if self._token:
            h["Authorization"] = f"Bearer {self._token}"
        if environment:
            h["environment"] = environment
        return h

    def _request(self, method: str, path: str, body: Any = None, environment: Optional[str] = None) -> Any:
        url = self._base_url + path
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(url, data=data, headers=self._headers(environment), method=method)
        with urllib.request.urlopen(req, timeout=self._timeout) as resp:
            raw = resp.read()
            if not raw:
                return None
            return json.loads(raw)

    def health_check(self) -> Dict[str, Any]:
        """GET /validate/health"""
        return self._request("GET", "/validate/health")

    def validate_flag(self, slug: str, body: ValidateBody, environment: Optional[str] = None) -> Dict[str, Any]:
        """POST /validate/flag/:slug"""
        return self._request("POST", f"/validate/flag/{urllib.parse.quote(slug)}", body.to_dict(), environment)

    def get_flag_cache(self, slug: str, identifier: Optional[str] = None) -> Dict[str, Any]:
        """GET /validate/flag/:slug"""
        path = f"/validate/flag/{urllib.parse.quote(slug)}"
        if identifier:
            path += f"?identifier={urllib.parse.quote(identifier)}"
        return self._request("GET", path)

    def validate_flow(self, slug: str, body: ValidateBody, environment: Optional[str] = None) -> Dict[str, Any]:
        """POST /validate/flow/:slug"""
        return self._request("POST", f"/validate/flow/{urllib.parse.quote(slug)}", body.to_dict(), environment)

    def get_flow_cache(self, slug: str, identifier: Optional[str] = None) -> Dict[str, Any]:
        """GET /validate/flow/:slug"""
        path = f"/validate/flow/{urllib.parse.quote(slug)}"
        if identifier:
            path += f"?identifier={urllib.parse.quote(identifier)}"
        return self._request("GET", path)

    def validate_flow_part(self, slug: str, body: ValidateBody, environment: Optional[str] = None) -> Dict[str, Any]:
        """POST /validate/flow-part/:slug"""
        return self._request("POST", f"/validate/flow-part/{urllib.parse.quote(slug)}", body.to_dict(), environment)

    def get_flow_part_cache(self, slug: str, identifier: Optional[str] = None) -> Dict[str, Any]:
        """GET /validate/flow-part/:slug"""
        path = f"/validate/flow-part/{urllib.parse.quote(slug)}"
        if identifier:
            path += f"?identifier={urllib.parse.quote(identifier)}"
        return self._request("GET", path)

    def validate_scenario(self, slug: str, body: ValidateBody, environment: Optional[str] = None) -> Dict[str, Any]:
        """POST /validate/scenario/:slug"""
        return self._request("POST", f"/validate/scenario/{urllib.parse.quote(slug)}", body.to_dict(), environment)

    def get_scenario_cache(self, slug: str, identifier: Optional[str] = None) -> Dict[str, Any]:
        """GET /validate/scenario/:slug"""
        path = f"/validate/scenario/{urllib.parse.quote(slug)}"
        if identifier:
            path += f"?identifier={urllib.parse.quote(identifier)}"
        return self._request("GET", path)

    def initialize(self, body: ReceiveMessage, environment: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """POST /validate/initialize"""
        return self._request("POST", "/validate/initialize", body.to_dict(), environment)

    def get_result(self, identifier: str) -> Dict[str, Any]:
        """GET /validate/result/:identifier"""
        return self._request("GET", f"/validate/result/{urllib.parse.quote(identifier)}")
