# useflagly-sdk — SDK para Python

SDK Python para a API de feature flags da UseFlagly.

## Instalação

```bash
pip install useflagly-sdk
```

## Uso

```python
from useflagly import UseFlaglyClient
from useflagly.models import ValidateBody, ReceiveMessage

client = UseFlaglyClient(token="seu-api-token")
# A URL padrão é https://api.useflagly.com.br — pode ser sobrescrita com base_url='...'

# Validar flag
result = client.validate_flag("minha-flag", ValidateBody(identifier="00000000000"), environment="PRD")

# Ler cache de flag
cache = client.get_flag_cache("minha-flag", identifier="00000000000")

# Validar flow
result = client.validate_flow("meu-flow", ValidateBody(identifier="00000000000"), environment="PRD")

# Validar flow-part
result = client.validate_flow_part("meu-flow-part", ValidateBody(identifier="00000000000"), environment="PRD")

# Validar scenario
result = client.validate_scenario("meu-scenario", ValidateBody(identifier="00000000000"), environment="PRD")

# Inicializar (producer)
client.initialize(ReceiveMessage(identifier="...", slug="...", company_id=1), environment="PRD")

# Buscar resultado
result = client.get_result("00000000000")
```

## Métodos

| Método | Descrição |
|---|---|
| `health_check()` | Verifica saúde da API |
| `validate_flag(slug, body, environment?)` | Valida uma feature flag |
| `get_flag_cache(slug, identifier?)` | Lê o cache de uma flag |
| `validate_flow(slug, body, environment?)` | Valida um flow |
| `get_flow_cache(slug, identifier?)` | Lê o cache de um flow |
| `validate_flow_part(slug, body, environment?)` | Valida um flow-part |
| `get_flow_part_cache(slug, identifier?)` | Lê o cache de um flow-part |
| `validate_scenario(slug, body, environment?)` | Valida um scenario |
| `get_scenario_cache(slug, identifier?)` | Lê o cache de um scenario |
| `initialize(payload, environment?)` | Inicializa flags (producer) |
| `get_result(identifier)` | Busca resultado por identifier |




