from __future__ import annotations

import sys
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest
from fastapi.testclient import TestClient
from sqlmodel import Session

from deathstar_server.db.models import Conversation
from deathstar_server.web.linear_store import LinearStore


def _build_linear_app(tmp_path: Path, test_engine, *, linear_api_key: str = "test-key"):
    """Build a minimal FastAPI app with Linear routes and mocked dependencies.

    Uses a real LinearStore backed by PostgreSQL for DB operations, but mocks
    LinearService (HTTP calls to Linear API) and Settings.
    """
    store = LinearStore(test_engine)

    # Mock Linear API service
    mock_linear_service = AsyncMock()
    mock_linear_service.list_teams = AsyncMock(return_value=[])
    mock_linear_service.list_projects = AsyncMock(return_value=[])
    mock_linear_service.get_project = AsyncMock(return_value=None)
    mock_linear_service.list_project_issues = AsyncMock(return_value=[])

    # Mock settings
    mock_settings = MagicMock()
    mock_settings.linear_api_key = linear_api_key
    mock_settings.linear_webhook_secret = "test-secret"
    mock_settings.api_token = None  # No auth for tests
    mock_settings.workspace_root = tmp_path
    mock_settings.projects_root = tmp_path / "projects"
    mock_settings.log_path = tmp_path / "log.txt"
    mock_settings.backup_directory = tmp_path / "backups"
    mock_settings.backup_bucket = None
    mock_settings.github_token = None
    mock_settings.tailscale_enabled = False
    mock_settings.tailscale_hostname = None
    mock_settings.ssh_user = "ubuntu"

    # Build mock app_state module
    mock_app_state = MagicMock()
    mock_app_state.settings = mock_settings
    mock_app_state.linear_service = mock_linear_service
    mock_app_state.linear_store = store
    mock_app_state.linear_sync = MagicMock()
    mock_app_state.event_bus = MagicMock()
    mock_app_state.event_bus.publish.return_value = 0
    mock_app_state.engine = test_engine
    mock_app_state.git_service = MagicMock()
    mock_app_state.github_service = MagicMock()
    mock_app_state.backup_service = MagicMock()
    mock_app_state.conversation_store = MagicMock()
    mock_app_state.memory_bank = MagicMock()
    mock_app_state.feedback_store = MagicMock()
    mock_app_state.document_store = MagicMock()
    mock_app_state.queue_store = MagicMock()
    mock_app_state.agent_runner = MagicMock()
    mock_app_state.queue_worker = MagicMock()
    mock_app_state.worktree_manager = MagicMock()
    mock_app_state.render_preview = MagicMock()

    # Clear cached module imports so the fresh mock takes effect
    for mod_name in list(sys.modules):
        if (
            mod_name.startswith("deathstar_server.app")
            or mod_name.startswith("deathstar_server.routes")
            or mod_name.startswith("deathstar_server.web")
            or mod_name.startswith("deathstar_server.session")
        ):
            sys.modules.pop(mod_name, None)

    sys.modules["deathstar_server.app_state"] = mock_app_state

    import deathstar_server.app as _app_mod  # noqa: F811

    app = _app_mod.app

    client = TestClient(app)
    return client, mock_linear_service, store, mock_settings, test_engine


# ------------------------------------------------------------------
# Fixtures
# ------------------------------------------------------------------


@pytest.fixture
def linear_client(tmp_path, db_engine):
    client, svc, store, settings, engine = _build_linear_app(tmp_path, db_engine)
    yield client, svc, store, settings, engine


@pytest.fixture
def linear_client_unconfigured(tmp_path, db_engine):
    client, svc, store, settings, engine = _build_linear_app(tmp_path, db_engine, linear_api_key="")
    yield client, svc, store, settings, engine


def _create_conversation(engine, conv_id: str = "conv-abc", repo: str = "my-repo") -> str:
    """Insert a bare conversation row into the DB and return its ID."""
    now = datetime.now(timezone.utc).isoformat()
    with Session(engine) as session:
        session.add(Conversation(
            id=conv_id,
            repo=repo,
            title="Test Conversation",
            created_at=now,
            updated_at=now,
        ))
        session.commit()
    return conv_id


def _link_project(store: LinearStore, **overrides) -> str:
    """Helper: link a project and return its internal PK."""
    defaults = {
        "repo": "my-repo",
        "linear_project_id": "lp-abc",
        "conversation_id": None,
        "team_id": "team-1",
        "project_data": {
            "name": "Sprint 1",
            "slugId": "sprint-1",
            "status": {"id": "s1", "name": "Started", "type": "started"},
            "url": "https://linear.app/project/1",
        },
    }
    defaults.update(overrides)
    project = store.link_project(**defaults)
    return project.id


# ------------------------------------------------------------------
# GET /linear/teams
# ------------------------------------------------------------------


class TestListTeams:
    def test_returns_teams(self, linear_client):
        client, svc, _, _, _ = linear_client
        svc.list_teams.return_value = [
            {"id": "t1", "name": "Engineering", "key": "ENG"},
            {"id": "t2", "name": "Design", "key": "DES"},
        ]
        resp = client.get("/web/api/linear/teams")
        assert resp.status_code == 200
        data = resp.json()
        assert len(data) == 2
        assert data[0]["id"] == "t1"
        assert data[0]["name"] == "Engineering"
        assert data[0]["key"] == "ENG"

    def test_returns_empty_list(self, linear_client):
        client, svc, _, _, _ = linear_client
        svc.list_teams.return_value = []
        resp = client.get("/web/api/linear/teams")
        assert resp.status_code == 200
        assert resp.json() == []


# ------------------------------------------------------------------
# GET /linear/projects
# ------------------------------------------------------------------


class TestListProjects:
    def test_remote_projects_with_team_id(self, linear_client):
        client, svc, _, _, _ = linear_client
        svc.list_projects.return_value = [
            {
                "id": "proj-1",
                "name": "Roadmap Q1",
                "slugId": "roadmap-q1",
                "status": {"type": "started"},
                "url": "https://linear.app/proj/1",
            },
        ]
        resp = client.get("/web/api/linear/projects", params={"team_id": "t1"})
        assert resp.status_code == 200
        data = resp.json()
        assert len(data) == 1
        assert data[0]["name"] == "Roadmap Q1"
        assert data[0]["linear_project_id"] == "proj-1"
        assert data[0]["linear_team_id"] == "t1"
        # Remote projects have no repo link yet
        assert data[0]["repo"] == ""
        # Remote projects are not linked — `id` is the Linear API UUID, not
        # an internal PK, so the frontend must not use it for /link/ or /sync/.
        assert data[0]["linked"] is False
        svc.list_projects.assert_called_once_with("t1")

    def test_remote_projects_skips_missing_id(self, linear_client):
        """Projects with missing/empty id from the API should be skipped."""
        client, svc, _, _, _ = linear_client
        svc.list_projects.return_value = [
            {"name": "No ID Project", "slugId": "no-id", "status": {"type": "planned"}, "url": ""},
            {"id": "", "name": "Empty ID", "slugId": "empty", "status": {"type": "planned"}, "url": ""},
            {"id": "proj-ok", "name": "Valid", "slugId": "valid", "status": {"type": "started"}, "url": ""},
        ]
        resp = client.get("/web/api/linear/projects", params={"team_id": "t1"})
        assert resp.status_code == 200
        data = resp.json()
        assert len(data) == 1
        assert data[0]["linear_project_id"] == "proj-ok"

    def test_local_linked_projects_without_team_id(self, linear_client):
        client, _, store, _, _ = linear_client
        pid = _link_project(store)
        # Add some issues to verify count
        store.sync_issues(pid, [
            {"id": "i1", "identifier": "ENG-1", "title": "Issue 1", "state": {"name": "Todo"}, "priority": 0, "url": ""},
            {"id": "i2", "identifier": "ENG-2", "title": "Issue 2", "state": {"name": "Done"}, "priority": 1, "url": ""},
        ])

        resp = client.get("/web/api/linear/projects")
        assert resp.status_code == 200
        data = resp.json()
        assert len(data) == 1
        assert data[0]["name"] == "Sprint 1"
        assert data[0]["repo"] == "my-repo"
        assert data[0]["issue_count"] == 2
        # Linked projects have `linked=True` — `id` is the internal PK safe
        # for use in /link/{project_id}, /sync/{project_id}, etc.
        assert data[0]["linked"] is True

    def test_local_projects_empty(self, linear_client):
        client, _, _, _, _ = linear_client
        resp = client.get("/web/api/linear/projects")
        assert resp.status_code == 200
        assert resp.json() == []


# ------------------------------------------------------------------
# POST /linear/link
# ------------------------------------------------------------------


class TestLinkProject:
    def test_links_and_syncs(self, linear_client):
        client, svc, store, _, _ = linear_client
        svc.get_project.return_value = {
            "id": "proj-new",
            "name": "New Project",
            "slugId": "new-project",
            "status": {"type": "planned"},
            "url": "https://linear.app/proj/new",
        }
        svc.list_project_issues.return_value = [
            {
                "id": "i1",
                "identifier": "ENG-1",
                "title": "Setup",
                "state": {"name": "Backlog"},
                "priority": 0,
                "url": "https://linear.app/issue/1",
            },
        ]

        resp = client.post("/web/api/linear/link", json={
            "repo": "my-repo",
            "linear_project_id": "proj-new",
            "team_id": "t1",
        })
        assert resp.status_code == 200
        data = resp.json()
        assert data["name"] == "New Project"
        assert data["repo"] == "my-repo"
        assert data["issue_count"] == 1
        assert data["linear_project_id"] == "proj-new"
        # last_synced_at should reflect the sync that just ran, not be stale
        assert data["last_synced_at"] is not None

        # Verify API calls
        svc.get_project.assert_called_once_with("proj-new")
        svc.list_project_issues.assert_called_once_with("proj-new")

    def test_link_with_conversation_id(self, linear_client):
        client, svc, _, _, engine = linear_client
        # conversation_id is a FK — create a real row first
        _create_conversation(engine, conv_id="conv-abc", repo="my-repo")

        svc.get_project.return_value = {
            "id": "proj-1",
            "name": "P1",
            "slugId": "p1",
            "status": {"type": "started"},
            "url": "https://linear.app/p1",
        }
        svc.list_project_issues.return_value = []

        resp = client.post("/web/api/linear/link", json={
            "repo": "my-repo",
            "linear_project_id": "proj-1",
            "team_id": "t1",
            "conversation_id": "conv-abc",
        })
        assert resp.status_code == 200
        assert resp.json()["conversation_id"] == "conv-abc"

    def test_link_project_not_found(self, linear_client):
        client, svc, _, _, _ = linear_client
        svc.get_project.return_value = None

        resp = client.post("/web/api/linear/link", json={
            "repo": "my-repo",
            "linear_project_id": "nonexistent",
            "team_id": "t1",
        })
        assert resp.status_code == 404

    def test_link_invalid_conversation_id_returns_400(self, linear_client):
        """P1 fix: non-existent conversation_id should return 400, not 500."""
        client, svc, _, _, _ = linear_client
        svc.get_project.return_value = {
            "id": "proj-1",
            "name": "P1",
            "slugId": "p1",
            "status": {"type": "started"},
            "url": "https://linear.app/p1",
        }

        resp = client.post("/web/api/linear/link", json={
            "repo": "my-repo",
            "linear_project_id": "proj-1",
            "team_id": "t1",
            "conversation_id": "nonexistent-conv-id",
        })
        assert resp.status_code == 400
        assert "not found" in resp.json()["message"].lower()

    def test_link_validation_rejects_empty_repo(self, linear_client):
        client, _, _, _, _ = linear_client
        resp = client.post("/web/api/linear/link", json={
            "repo": "",
            "linear_project_id": "p1",
            "team_id": "t1",
        })
        assert resp.status_code == 422

    def test_link_validation_rejects_repo_traversal(self, linear_client):
        client, _, _, _, _ = linear_client
        resp = client.post("/web/api/linear/link", json={
            "repo": "../etc",
            "linear_project_id": "p1",
            "team_id": "t1",
        })
        assert resp.status_code == 422

    def test_relink_updates_existing_project(self, linear_client):
        """Linking the same linear_project_id twice should update, not duplicate."""
        client, svc, store, _, _ = linear_client
        project_data = {
            "id": "proj-relink",
            "name": "Original Name",
            "slugId": "original",
            "status": {"type": "planned"},
            "url": "https://linear.app/proj/relink",
        }
        svc.get_project.return_value = project_data
        svc.list_project_issues.return_value = []

        resp1 = client.post("/web/api/linear/link", json={
            "repo": "my-repo",
            "linear_project_id": "proj-relink",
            "team_id": "t1",
        })
        assert resp1.status_code == 200
        first_id = resp1.json()["id"]

        # Re-link with updated name
        svc.get_project.return_value = {**project_data, "name": "Updated Name"}
        resp2 = client.post("/web/api/linear/link", json={
            "repo": "my-repo",
            "linear_project_id": "proj-relink",
            "team_id": "t1",
        })
        assert resp2.status_code == 200
        data = resp2.json()
        assert data["id"] == first_id  # Same internal PK
        assert data["name"] == "Updated Name"
        assert data["linked"] is True

        # Should still be one project, not two
        all_projects = store.list_all_projects()
        assert len(all_projects) == 1

    def test_link_timeout_returns_retryable_error(self, linear_client):
        """Network timeout from Linear API should return a 504 with retryable flag.

        LinearService._execute() wraps httpx timeouts as AppError(INTERNAL_ERROR,
        status_code=504, retryable=True). This test verifies the route propagates it.
        """
        from deathstar_server.errors import AppError
        from deathstar_shared.models import ErrorCode

        client, svc, _, _, _ = linear_client
        svc.get_project.side_effect = AppError(
            ErrorCode.INTERNAL_ERROR,
            "Linear API request timed out",
            status_code=504,
            retryable=True,
        )

        resp = client.post("/web/api/linear/link", json={
            "repo": "my-repo",
            "linear_project_id": "proj-1",
            "team_id": "t1",
        })
        assert resp.status_code == 504
        assert resp.json()["code"] == "internal_error"
        assert resp.json()["retryable"] is True


# ------------------------------------------------------------------
# DELETE /linear/link/{project_id}
# ------------------------------------------------------------------


class TestUnlinkProject:
    def test_unlinks_existing_project(self, linear_client):
        client, _, store, _, _ = linear_client
        pid = _link_project(store)

        resp = client.delete(f"/web/api/linear/link/{pid}")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "unlinked"
        assert data["project_id"] == pid

        # Verify project is gone
        assert store.get_project_by_pk(pid) is None

    def test_unlink_cascades_to_issues(self, linear_client):
        client, _, store, _, _ = linear_client
        pid = _link_project(store)
        store.sync_issues(pid, [
            {"id": "i1", "identifier": "ENG-1", "title": "T", "state": {"name": "Todo"}, "priority": 0, "url": ""},
        ])
        assert len(store.list_issues_for_project(pid)) == 1

        resp = client.delete(f"/web/api/linear/link/{pid}")
        assert resp.status_code == 200

        # Issues should also be deleted
        assert store.list_issues_for_project(pid) == []
        assert store.get_issue_by_linear_id("i1") is None

    def test_unlink_not_found(self, linear_client):
        client, _, _, _, _ = linear_client
        resp = client.delete("/web/api/linear/link/nonexistent-id")
        assert resp.status_code == 404


# ------------------------------------------------------------------
# GET /linear/projects/{project_id}/issues
# ------------------------------------------------------------------


class TestListIssues:
    def test_returns_issues(self, linear_client):
        client, _, store, _, _ = linear_client
        pid = _link_project(store)
        store.sync_issues(pid, [
            {
                "id": "i1",
                "identifier": "ENG-1",
                "title": "First",
                "state": {"name": "Todo"},
                "priority": 1,
                "url": "https://linear.app/1",
            },
            {
                "id": "i2",
                "identifier": "ENG-2",
                "title": "Second",
                "state": {"name": "In Progress"},
                "priority": 2,
                "url": "https://linear.app/2",
            },
        ])

        resp = client.get(f"/web/api/linear/projects/{pid}/issues")
        assert resp.status_code == 200
        data = resp.json()
        assert len(data) == 2
        # Priority order: Urgent(1) before High(2)
        assert data[0]["identifier"] == "ENG-1"
        assert data[0]["priority"] == 1
        assert data[1]["identifier"] == "ENG-2"

    def test_returns_issue_fields(self, linear_client):
        client, _, store, _, _ = linear_client
        pid = _link_project(store)
        store.sync_issues(pid, [
            {
                "id": "i1",
                "identifier": "ENG-42",
                "title": "Add auth",
                "description": "Implement OAuth",
                "state": {"name": "In Progress"},
                "priority": 2,
                "url": "https://linear.app/42",
                "assignee": {"displayName": "Alice"},
            },
        ])

        resp = client.get(f"/web/api/linear/projects/{pid}/issues")
        assert resp.status_code == 200
        issue = resp.json()[0]
        assert issue["identifier"] == "ENG-42"
        assert issue["title"] == "Add auth"
        assert issue["description"] == "Implement OAuth"
        assert issue["status"] == "In Progress"
        assert issue["priority"] == 2
        assert issue["assignee"] == "Alice"
        assert issue["url"] == "https://linear.app/42"
        assert issue["branch"] == "eng-42/add-auth"

    def test_project_not_found(self, linear_client):
        client, _, _, _, _ = linear_client
        resp = client.get("/web/api/linear/projects/nonexistent/issues")
        assert resp.status_code == 404

    def test_empty_issues(self, linear_client):
        client, _, store, _, _ = linear_client
        pid = _link_project(store)
        resp = client.get(f"/web/api/linear/projects/{pid}/issues")
        assert resp.status_code == 200
        assert resp.json() == []


# ------------------------------------------------------------------
# POST /linear/sync/{project_id}
# ------------------------------------------------------------------


class TestForceSync:
    def test_syncs_issues(self, linear_client):
        client, svc, store, _, _ = linear_client
        pid = _link_project(store)

        svc.list_project_issues.return_value = [
            {
                "id": "i1",
                "identifier": "ENG-1",
                "title": "New Issue",
                "state": {"name": "Todo"},
                "priority": 0,
                "url": "https://linear.app/1",
            },
            {
                "id": "i2",
                "identifier": "ENG-2",
                "title": "Another",
                "state": {"name": "Backlog"},
                "priority": 3,
                "url": "https://linear.app/2",
            },
        ]

        resp = client.post(f"/web/api/linear/sync/{pid}")
        assert resp.status_code == 200
        data = resp.json()
        assert data["created"] == 2
        assert data["updated"] == 0
        assert data["deleted"] == 0

        # Verify API was called with Linear project ID (not internal PK)
        svc.list_project_issues.assert_called_once_with("lp-abc")

    def test_sync_updates_existing(self, linear_client):
        client, svc, store, _, _ = linear_client
        pid = _link_project(store)

        # Initial sync
        store.sync_issues(pid, [
            {"id": "i1", "identifier": "ENG-1", "title": "Old Title", "state": {"name": "Todo"}, "priority": 0, "url": ""},
        ])

        # Force sync with updated data
        svc.list_project_issues.return_value = [
            {"id": "i1", "identifier": "ENG-1", "title": "New Title", "state": {"name": "Done"}, "priority": 1, "url": ""},
        ]

        resp = client.post(f"/web/api/linear/sync/{pid}")
        assert resp.status_code == 200
        data = resp.json()
        assert data["updated"] == 1
        assert data["created"] == 0

    def test_sync_project_not_found(self, linear_client):
        client, _, _, _, _ = linear_client
        resp = client.post("/web/api/linear/sync/nonexistent")
        assert resp.status_code == 404


# ------------------------------------------------------------------
# GET /linear/status
# ------------------------------------------------------------------


class TestSyncStatus:
    def test_configured_with_projects(self, linear_client):
        client, _, store, _, _ = linear_client
        _link_project(store)

        resp = client.get("/web/api/linear/status")
        assert resp.status_code == 200
        data = resp.json()
        assert data["configured"] is True
        assert data["linked_projects"] == 1
        assert data["last_synced_at"] is not None

    def test_configured_no_projects(self, linear_client):
        client, _, _, _, _ = linear_client
        resp = client.get("/web/api/linear/status")
        assert resp.status_code == 200
        data = resp.json()
        assert data["configured"] is True
        assert data["linked_projects"] == 0
        assert data["last_synced_at"] is None

    def test_not_configured(self, linear_client_unconfigured):
        client, _, _, _, _ = linear_client_unconfigured
        resp = client.get("/web/api/linear/status")
        assert resp.status_code == 200
        data = resp.json()
        assert data["configured"] is False


# ------------------------------------------------------------------
# Service error propagation
# ------------------------------------------------------------------


class TestServiceErrorPropagation:
    def test_teams_auth_error_propagates(self, linear_client):
        """LinearService AppError should propagate through the route."""
        from deathstar_server.errors import AppError
        from deathstar_shared.models import ErrorCode

        client, svc, _, _, _ = linear_client
        svc.list_teams.side_effect = AppError(
            ErrorCode.AUTH_ERROR,
            "Linear rejected the request (HTTP 401)",
            status_code=401,
        )
        resp = client.get("/web/api/linear/teams")
        assert resp.status_code == 401
        assert resp.json()["code"] == "auth_error"

    def test_sync_rate_limit_propagates(self, linear_client):
        from deathstar_server.errors import AppError
        from deathstar_shared.models import ErrorCode

        client, svc, store, _, _ = linear_client
        pid = _link_project(store)
        svc.list_project_issues.side_effect = AppError(
            ErrorCode.RATE_LIMITED,
            "Linear API rate limit exceeded after retries",
            status_code=429,
        )
        resp = client.post(f"/web/api/linear/sync/{pid}")
        assert resp.status_code == 429
        assert resp.json()["code"] == "rate_limited"


# ------------------------------------------------------------------
# LinearStore.count_issues_by_project
# ------------------------------------------------------------------


class TestCountIssuesByProject:
    @pytest.fixture
    def store(self, db_engine) -> LinearStore:
        return LinearStore(db_engine)

    def test_counts_across_projects(self, store: LinearStore) -> None:
        p1 = store.link_project(
            repo="r", linear_project_id="lp-1",
            conversation_id=None, team_id="t",
            project_data={"name": "P1"},
        )
        p2 = store.link_project(
            repo="r", linear_project_id="lp-2",
            conversation_id=None, team_id="t",
            project_data={"name": "P2"},
        )
        store.sync_issues(p1.id, [
            {"id": "i1", "identifier": "E-1", "title": "A", "state": {"name": "Todo"}, "priority": 0, "url": ""},
            {"id": "i2", "identifier": "E-2", "title": "B", "state": {"name": "Todo"}, "priority": 0, "url": ""},
        ])
        store.sync_issues(p2.id, [
            {"id": "i3", "identifier": "E-3", "title": "C", "state": {"name": "Todo"}, "priority": 0, "url": ""},
        ])
        counts = store.count_issues_by_project()
        assert counts[p1.id] == 2
        assert counts[p2.id] == 1

    def test_empty(self, store: LinearStore) -> None:
        assert store.count_issues_by_project() == {}


# ------------------------------------------------------------------
# LinearStore.unlink_project
# ------------------------------------------------------------------


class TestUnlinkProjectStore:
    """Direct store tests for the new unlink_project method."""

    @pytest.fixture
    def store(self, db_engine) -> LinearStore:
        return LinearStore(db_engine)

    def test_unlink_existing(self, store: LinearStore) -> None:
        project = store.link_project(
            repo="r",
            linear_project_id="p1",
            conversation_id=None,
            team_id="t",
            project_data={"name": "P"},
        )
        assert store.unlink_project(project.id) is True
        assert store.get_project_by_pk(project.id) is None

    def test_unlink_nonexistent(self, store: LinearStore) -> None:
        assert store.unlink_project("no-such-id") is False

    def test_unlink_cascade_deletes_issues(self, store: LinearStore) -> None:
        project = store.link_project(
            repo="r",
            linear_project_id="p1",
            conversation_id=None,
            team_id="t",
            project_data={"name": "P"},
        )
        store.sync_issues(project.id, [
            {"id": "i1", "identifier": "ENG-1", "title": "T", "state": {"name": "Todo"}, "priority": 0, "url": ""},
            {"id": "i2", "identifier": "ENG-2", "title": "T2", "state": {"name": "Done"}, "priority": 1, "url": ""},
        ])
        assert len(store.list_issues_for_project(project.id)) == 2

        store.unlink_project(project.id)
        assert store.list_issues_for_project(project.id) == []
        assert store.get_issue_by_linear_id("i1") is None
        assert store.get_issue_by_linear_id("i2") is None
