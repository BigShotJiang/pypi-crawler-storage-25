from __future__ import annotations

import logging

from fastapi import APIRouter
from sqlmodel import Session

from deathstar_server.app_state import (
    engine as db_engine,
    linear_service,
    linear_store,
    settings,
)
from deathstar_server.db.models import Conversation, LinearIssue, LinearProject
from deathstar_server.errors import AppError
from deathstar_shared.models import (
    ErrorCode,
    LinearIssueInfo,
    LinearProjectInfo,
    LinearSyncStatusResponse,
    LinearTeamInfo,
    LinkLinearProjectRequest,
)

logger = logging.getLogger(__name__)

linear_router = APIRouter(prefix="/web/api/linear", tags=["linear"])


# ------------------------------------------------------------------
# Converters
# ------------------------------------------------------------------


def _project_to_response(row: LinearProject, issue_count: int = 0) -> LinearProjectInfo:
    return LinearProjectInfo(
        id=row.id,
        name=row.name,
        slug=row.slug,
        state=row.state,
        url=row.url,
        linear_project_id=row.linear_project_id,
        linear_team_id=row.linear_team_id,
        repo=row.repo,
        conversation_id=row.conversation_id,
        issue_count=issue_count,
        last_synced_at=row.last_synced_at,
        linked=True,
    )


def _issue_to_response(row: LinearIssue) -> LinearIssueInfo:
    return LinearIssueInfo(
        id=row.id,
        identifier=row.identifier,
        title=row.title,
        description=row.description,
        status=row.status,
        priority=row.priority,
        branch=row.branch,
        assignee=row.assignee,
        url=row.url,
    )


# ------------------------------------------------------------------
# Teams (proxied from Linear API)
# ------------------------------------------------------------------


@linear_router.get("/teams", response_model=list[LinearTeamInfo])
async def list_teams():
    """List Linear teams accessible to the configured API key."""
    teams = await linear_service.list_teams()
    return [
        LinearTeamInfo(
            id=t.get("id", ""),
            name=t.get("name", ""),
            key=t.get("key", ""),
        )
        for t in teams
    ]


# ------------------------------------------------------------------
# Projects
# ------------------------------------------------------------------


@linear_router.get("/projects", response_model=list[LinearProjectInfo])
async def list_projects(team_id: str | None = None):
    """List Linear projects.

    When ``team_id`` is provided, fetches remote projects from the
    Linear API.  Otherwise returns locally-linked projects.
    """
    if team_id:
        # Remote: fetch from Linear API
        remote = await linear_service.list_projects(team_id)
        results: list[LinearProjectInfo] = []
        for p in remote:
            project_id = p.get("id", "")
            if not project_id:
                continue
            status_obj = p.get("status")
            state = ""
            if isinstance(status_obj, dict):
                state = status_obj.get("type", "")
            elif isinstance(status_obj, str):
                state = status_obj

            results.append(LinearProjectInfo(
                id=project_id,
                name=p.get("name", ""),
                slug=p.get("slugId", ""),
                state=state,
                url=p.get("url", ""),
                linear_project_id=project_id,
                linear_team_id=team_id,
                repo="",
                conversation_id=None,
                issue_count=0,
                last_synced_at=None,
            ))
        return results

    # Local: return linked projects with issue counts (single COUNT query)
    projects = linear_store.list_all_projects()
    counts = linear_store.count_issues_by_project()
    return [
        _project_to_response(proj, issue_count=counts.get(proj.id, 0))
        for proj in projects
    ]


@linear_router.post("/link", response_model=LinearProjectInfo)
async def link_project(body: LinkLinearProjectRequest):
    """Link a Linear project to a repo and perform initial issue sync."""
    # Validate conversation_id FK before hitting the store — a missing
    # conversation would cause an IntegrityError that the store's TOCTOU
    # handler doesn't distinguish from a uniqueness race.
    if body.conversation_id:
        with Session(db_engine) as session:
            if not session.get(Conversation, body.conversation_id):
                raise AppError(
                    ErrorCode.INVALID_REQUEST,
                    f"Conversation '{body.conversation_id}' not found",
                    status_code=400,
                )

    # Fetch project data from Linear API to populate name/slug/state
    project_data = await linear_service.get_project(body.linear_project_id)
    if not project_data:
        raise AppError(
            ErrorCode.INVALID_REQUEST,
            f"Linear project '{body.linear_project_id}' not found",
            status_code=404,
        )

    # Create or update the local project link
    project = linear_store.link_project(
        repo=body.repo,
        linear_project_id=body.linear_project_id,
        conversation_id=body.conversation_id,
        team_id=body.team_id,
        project_data=project_data,
    )

    # Initial issue sync — fetch all issues and upsert
    issues = await linear_service.list_project_issues(body.linear_project_id)
    sync_result = linear_store.sync_issues(project.id, issues)
    logger.info(
        "Linked Linear project %s (%s): synced %d created, %d updated, %d deleted",
        project.name,
        project.linear_project_id,
        sync_result.created,
        sync_result.updated,
        len(sync_result.deleted_ids),
    )

    # Re-read the project so last_synced_at reflects the sync that just ran
    # (sync_issues updates the row but the local object is stale).
    project = linear_store.get_project_by_pk(project.id) or project
    all_issues = linear_store.list_issues_for_project(project.id)
    return _project_to_response(project, issue_count=len(all_issues))


@linear_router.delete("/link/{project_id}")
def unlink_project(project_id: str):
    """Unlink a Linear project (cascade-deletes synced issues)."""
    removed = linear_store.unlink_project(project_id)
    if not removed:
        raise AppError(
            ErrorCode.INVALID_REQUEST,
            f"Linked project '{project_id}' not found",
            status_code=404,
        )
    return {"status": "unlinked", "project_id": project_id}


# ------------------------------------------------------------------
# Issues
# ------------------------------------------------------------------


@linear_router.get(
    "/projects/{project_id}/issues",
    response_model=list[LinearIssueInfo],
)
def list_issues(project_id: str):
    """List synced issues for a linked project."""
    project = linear_store.get_project_by_pk(project_id)
    if not project:
        raise AppError(
            ErrorCode.INVALID_REQUEST,
            f"Linked project '{project_id}' not found",
            status_code=404,
        )
    rows = linear_store.list_issues_for_project(project_id)
    return [_issue_to_response(r) for r in rows]


# ------------------------------------------------------------------
# Sync
# ------------------------------------------------------------------


@linear_router.post("/sync/{project_id}")
async def force_sync(project_id: str):
    """Force a full re-sync of issues for a linked project."""
    project = linear_store.get_project_by_pk(project_id)
    if not project:
        raise AppError(
            ErrorCode.INVALID_REQUEST,
            f"Linked project '{project_id}' not found",
            status_code=404,
        )

    issues = await linear_service.list_project_issues(project.linear_project_id)
    result = linear_store.sync_issues(project_id, issues)
    logger.info(
        "Force sync project %s: %d created, %d updated, %d deleted",
        project.name,
        result.created,
        result.updated,
        len(result.deleted_ids),
    )
    return {
        "created": result.created,
        "updated": result.updated,
        "deleted": len(result.deleted_ids),
    }


# ------------------------------------------------------------------
# Status
# ------------------------------------------------------------------


@linear_router.get("/status", response_model=LinearSyncStatusResponse)
def sync_status():
    """Return Linear integration status overview."""
    configured = bool(settings.linear_api_key)
    projects = linear_store.list_all_projects()

    last_synced: str | None = None
    for p in projects:
        if p.last_synced_at:
            if last_synced is None or p.last_synced_at > last_synced:
                last_synced = p.last_synced_at

    return LinearSyncStatusResponse(
        configured=configured,
        linked_projects=len(projects),
        last_synced_at=last_synced,
    )
