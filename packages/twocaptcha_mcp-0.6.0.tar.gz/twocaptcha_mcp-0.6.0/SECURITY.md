# Security policy

## Reporting a vulnerability

**Do not open a public issue for security vulnerabilities.**

Instead use [GitHub's private vulnerability reporting](https://docs.github.com/en/code-security/security-advisories/guidance-on-reporting-and-writing-information-about-vulnerabilities/privately-reporting-a-security-vulnerability):

- Repository → **Security** tab → **Report a vulnerability**

We will acknowledge the report in a few days and keep you informed as we investigate. Once a fix is ready we publish a coordinated GitHub Security Advisory and a patched release.

## Threat surface

`twocaptcha-mcp` ships two console scripts with very different security profiles.

### `twocaptcha-mcp` (stdio MCP server, default)

- Reads a single API key from environment / `.env`.
- Talks HTTPS to `2captcha.com` (or `rucaptcha.com`) via the official `2captcha-python` SDK on `httpx`.
- Does not bind any network port and does not host any HTTP endpoint.
- Writes only to stderr (stdout is reserved for the MCP stdio channel) and the optional pingback SQLite store under `TWOCAPTCHA_WEBHOOK_DB_PATH`.

### `twocaptcha-mcp-webhook` (optional pingback receiver, since 0.3.0)

- Binds a Starlette + uvicorn HTTP server on a configurable host/port (default `127.0.0.1:8787`).
- Routes: `POST /2captcha/pingback`, `GET /health`. No other endpoints.
- Optional shared secret via `TWOCAPTCHA_WEBHOOK_SECRET`, validated with constant-time compare against `?secret=` query param or `X-Webhook-Secret` header.
- Persists callbacks to SQLite (WAL mode, idempotent on `captcha_id` PRIMARY KEY).
- Production deployment guidance (TLS, reverse proxy, systemd sandboxing) is in [`docs/DEPLOY-WEBHOOK.md`](docs/DEPLOY-WEBHOOK.md). **Do not expose the receiver directly to the public internet without TLS in front of it.**

### Realistic attack vectors

- **Supply chain** (a malicious dependency upgrade). Mitigated by `dependabot.yml` weekly scans, `2captcha-python>=2.0,<3.0` upper bound, snapshot test of the SDK public surface.
- **Credential leak** (the API key surfaced in a log line or error message). The codebase logs only to stderr and never prints the API key; tool error envelopes wrap and re-emit only the SDK's own error string.
- **Untrusted input on stdio** (a malicious MCP client sending malformed tool calls). Pydantic `extra="forbid"` strict validation in every schema; unhandled exceptions never leak the API key.
- **Forged pingback callbacks** (the webhook receiver receiving traffic that wasn't from 2Captcha). Mitigated by the optional shared secret and by binding to `127.0.0.1` behind a reverse proxy by default.

### Out of scope

- DOS protection on the MCP transport — handled by the MCP client (Claude Code).
- Outbound 2Captcha API abuse — handled by 2Captcha's own rate limiting plus the per-method limiter built into `SolverClient`.
- Network-layer DOS / reverse-proxy hardening for the webhook receiver — that is the operator's responsibility (see `docs/DEPLOY-WEBHOOK.md`).

## Supported versions

Only the latest minor version receives security fixes. See `CHANGELOG.md`.

| Version | Supported |
|---|---|
| 0.5.x   | ✅ |
| ≤ 0.4.x | ❌ |

## Disclosure timeline

| Day | Step |
|---|---|
| 0 | Report received via private advisory |
| ~1-3 | Triage + ack |
| ~7-30 | Fix prepared, security release cut, advisory published |
