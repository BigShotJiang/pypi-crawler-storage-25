# CLAUDE.md — Project rules for `twocaptcha-mcp`

This file is read on every Claude Code session opened in this repository.

## What this project is

An MCP server that exposes the official **2Captcha** API to Claude Code. **43 tools** across:
- 31 captcha solvers (every method `AsyncTwoCaptcha` exposes)
- 5 management tools (`balance`, `report_good`, `report_bad`, `get_result`, `send_raw`)
- 3 pingback CRUD tools
- 3 webhook event-store tools (`pingback_events_list`, `pingback_events_get`, `pingback_events_clear`)
- 1 composite tool (`solve_and_wait_pingback`)

## Critical principles

1. **No mocks or workarounds in production code.** Mocks live in `tests/` only.
2. **SOLID / KISS / DRY.** Tool handlers should be ≤ 5 lines; every cross-captcha concern belongs in `schemas/common.py`.
3. **Root-cause fixes only.** When a test fails, fix the underlying issue, never the symptom.
4. **First-principles thinking** for every architectural decision.

## Repository layout

```
twocaptcha_mcp/
├── __main__.py            # stdio entrypoint
├── server.py              # MCP Server bootstrap + dispatcher
├── config.py              # pydantic-settings (.env)
├── logger.py              # stderr-only (stdout is the MCP stdio channel!)
├── client/
│   ├── solver.py          # SolverClient — wraps AsyncTwoCaptcha (DIP boundary)
│   ├── pingback.py        # httpx → legacy res.php (no SDK helpers exist for this)
│   ├── rate_limiter.py    # async sliding-window per-method rate limiter
│   └── errors.py          # CaptchaApiError / Network / Timeout / Validation
├── schemas/               # one module per captcha family
├── tools/                 # one module per captcha family + composite
└── webhook_receiver/      # Starlette app (twocaptcha-mcp-webhook console script)
tests/                     # one test module per source module + parametrised solver tests
docs/
├── RELEASE.md             # PyPI Trusted Publisher setup + per-release workflow
├── DEPLOY-WEBHOOK.md      # production webhook deployment guide
└── release/               # repo metadata, awesome-mcp PR text, sample systemd unit, checklists
```

## Conventions for adding a new captcha type

1. Add a `<Family>Request(SolverKwargs)` (or `ProxyRequiredKwargs` if proxy is mandatory) in `schemas/<family>.py` with a `to_sdk_call_kwargs()` method.
2. Add a `@captcha_tool(...)` handler in `tools/<family>.py` — body should be exactly:
   ```python
   payload = await ctx.solver.call("<sdk_method>", **req.to_sdk_call_kwargs())
   return SolverResult.from_sdk(payload)
   ```
3. Bump `EXPECTED_TOOL_COUNT` in `tests/test_tools_snapshot.py` and add the new tool name to `required` set.
4. Add the new module to `twocaptcha_mcp/tools/__init__.py:load_all_tool_modules()`.
5. Run `pytest -k snapshot` — must stay green.

## Local commands

The examples below assume an active virtual environment. On POSIX use `./.venv/bin/python`, on Windows use `./.venv/Scripts/python.exe` — or just call `python` directly once the venv is activated.

```sh
# install
python -m pip install -e ".[dev]"

# tests + branch coverage (≥ 92 % required)
python -m pytest --cov=twocaptcha_mcp --cov-branch --cov-fail-under=92

# lint + format
python -m ruff check .
python -m ruff format --check .

# strict types
python -m mypy --strict twocaptcha_mcp

# live smoke (consumes 2Captcha credits)
python -m pytest -m live --run-live

# end-to-end MCP protocol tests (consumes 2Captcha credits)
python -m pytest -m e2e --run-e2e

# build wheel + sdist
python -m build
```

## Testing strategy

- **Unit**: every schema + every handler + dispatcher (`tests/test_dispatcher.py`).
- **Integration**: SDK is monkey-patched via `unittest.mock.AsyncMock`; respx covers the pingback HTTP layer.
- **Snapshot**: `tests/test_tools_snapshot.py` keeps the public tool surface stable.
- **Live**: `pytest -m live --run-live` exercises the real API. Skipped by default.
- **E2E**: `pytest -m e2e --run-e2e` spawns `python -m twocaptcha_mcp` as a subprocess and exercises the full MCP protocol via `mcp.client.session`. Skipped by default.

## Git workflow

- One commit per coherent change. Reference the version in the message (e.g. `feat(0.5.0): ...`).
- Never commit `.env`. `.env.example` is the source-of-truth schema.
- Never bypass hooks (`--no-verify`); fix the underlying issue.

## Definition of done for a release

- `pytest --cov-fail-under=92` green on Windows + Linux
- `ruff check` and `ruff format --check` clean
- `mypy --strict twocaptcha_mcp` clean
- `python -m twocaptcha_mcp` boots the server end-to-end
- `twocaptcha-mcp-webhook --help` works
- Live `twocaptcha_balance` returns a real number
- `python -m build` produces wheel + sdist; install in a fresh venv smokes
- `CHANGELOG.md` updated with the new version block
