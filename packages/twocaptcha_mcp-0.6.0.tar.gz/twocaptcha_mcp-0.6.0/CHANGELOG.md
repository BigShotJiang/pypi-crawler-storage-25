# Changelog

All notable changes to this project are documented in this file.
Format follows [Keep a Changelog](https://keepachangelog.com/) and [Semantic Versioning](https://semver.org/).

## [0.6.0] - 2026-05-05

First public release. Replaces all `OWNER` placeholders with the actual GitHub owner, consolidates the publish playbook, and ships the source-of-truth `server.json` for the official MCP Registry.

### Changed

- `OWNER` placeholders replaced with `aruxojuyu665` across `README.md` badge URLs, `pyproject.toml` `[project.urls]`, `CONTRIBUTING.md` clone command, `docs/DEPLOY-WEBHOOK.md` install hint, `docs/release/awesome-mcp-pr.md`, and the publish checklist.
- `docs/release/0.5.0-checklist.md` → `docs/release/0.6.0-checklist.md`. All version-specific references inside (filenames, git tags, GitHub Release titles, post-publish smoke commands) updated to `0.6.0`. The stale "Replace placeholders in URLs after push" section removed — placeholders are now replaced before the first push.
- Stale "Replace `OWNER`..." inline warnings in `README.md`, `pyproject.toml`, and `docs/release/awesome-mcp-pr.md` removed.
- Version bumped to `0.6.0` in `twocaptcha_mcp/__init__.py` and `pyproject.toml`.

### Added

- `server.json` at the repo root — canonical source for the official MCP Registry submission. Declares `registryType: pypi` with namespace `io.github.aruxojuyu665/twocaptcha-mcp`, runtime hint `uvx`, stdio transport, and the required `2Captcha_API_KEY` env var.
- `docs/release/launch-content/` with pre-written content for the manual-only discovery channels: mcp.so, Anthropic Discord, 2Captcha community, HN Show HN. Each file is a copy-paste-ready snippet with the launch URL.

### Verified

- `pytest --cov-fail-under=92`: 157 passed, 10 skipped, **93.37 % branch coverage**.
- `ruff check . && ruff format --check .` clean.
- `mypy --strict twocaptcha_mcp` clean (51 source files, 0 issues).
- `python -m build`: wheel **47.8 KB** + sdist **73.5 KB** (no internal-doc leakage).
- Public-surface scans: 0 cyrillic, 0 PII (regex sweep on API key / VPS IP / internal hostname / dev username / dev paths).

## [0.5.0] - 2026-05-04

Public-release cleanup. No functional changes. Pre-publication.

### Changed

- **Repository hygiene** — removed all internal-only working artefacts from the public surface: per-version development prompts, TODOs, research / after-action / doc-audit reports, and a Russian-language user-prompt drop. These were development scaffolding only and never needed by end users or contributors. They are now `.gitignore`d so they never enter the published git history if regenerated locally.
- **English-only public surface** — `CHANGELOG.md` `[Unreleased]` Russian block removed (its content shipped in `## [0.2.0]`); references to a specific internal development VPS hostname rewritten to neutral `Linux VPS`. `CLAUDE.md` rewritten to be platform-agnostic (no `.venv\Scripts\python.exe` hardcoding) and to reflect the actual 43-tool surface introduced in 0.3.0.
- **`tests/integration/vps_webhook_e2e.py`** removed — operator-specific runner that depended on undeclared `paramiko`, hardcoded internal env vars, and SSH access to a specific development VPS. The same end-to-end flow is documented as a reproducible operator runbook in `docs/DEPLOY-WEBHOOK.md`.
- **`docs/release/0.{2,3,4}.0-checklist.md`** removed; replaced by a single consolidated [`docs/release/0.5.0-checklist.md`](docs/release/0.5.0-checklist.md) covering the full first-publish flow.
- **`pyproject.toml`** — added `[project.urls]` (Homepage / Repository / Issues / Changelog) with explicit `OWNER` placeholders to fill before publish, and an explicit `[tool.hatch.build.targets.sdist]` whitelist of paths that should ship in the source distribution (prevents internal docs from leaking via sdist if regenerated).
- **`README.md`**, **`SECURITY.md`**, **`CONTRIBUTING.md`** — refreshed to match the actual 43-tool surface, the 92 % branch-coverage threshold (was 80–88 % in older docs), and the webhook receiver's network footprint that exists since 0.3.0.

### Verified

- Strict cyrillic scan over the public surface: 0 hits.
- PII regex sweep (API key, JWT, VPS IP, internal hostnames, dev paths, dev username) over the public surface: 0 hits.
- `pytest --cov-fail-under=92`: 157 passed, 10 skipped, **93.37 % branch** on Python 3.14 / Windows 10.
- `ruff check . && ruff format --check .` clean.
- `mypy --strict twocaptcha_mcp`: 51 source files, 0 issues.
- `python -m build`: wheel **47.8 KB** + sdist **71.5 KB**. Wheel contains only `twocaptcha_mcp/**`. Sdist contains source + tests + public-facing docs only — no `docs/{prompts,todo,reports,userdocs}/` leak.

### Security advisory for the maintainer

Even though no `.git` history exists in the working tree (the project has not been published yet), the cleanup has touched files that previously embedded development-time secrets. Before running `git init` and pushing for the first time, **rotate** the 2Captcha API key on `https://2captcha.com/setting`, regenerate any 2Captcha session/JWT tokens, and rotate the development VPS root password. Treat any backups of the pre-cleanup tree as compromised.

### Pending (gated behind explicit user permission)

- `git init` + first push to a public origin.
- PyPI publish via Trusted Publishers OIDC.
- PR to `punkpeye/awesome-mcp-servers`.

A 9-step playbook for the above is in [`docs/release/0.5.0-checklist.md`](docs/release/0.5.0-checklist.md).

## [0.4.0] - 2026-05-04

100 % production readiness — closes every deferred item from 0.1.0 / 0.2.0 / 0.3.0 backlogs that is achievable without external account configuration. Pre-publication; PyPI publish remains gated behind explicit user permission.

### Added

- **Pure-Python MCP E2E test** (`tests/e2e/test_mcp_protocol_e2e.py`) — uses `mcp.client.session.ClientSession` + `stdio_client` to spawn `python -m twocaptcha_mcp` as a subprocess and exercise the full MCP protocol (`initialize` → `list_tools` → `call_tool`). No Node.js / `claude` CLI dependency. 3 tests covering tool listing, balance call, and concurrent calls.
- **Parametrised live tests** for the top public captcha types (`tests/test_live_top_captchas.py`):
  - reCAPTCHA v2 against Google's official demo sitekey + URL — **PASSES** in ~100 s for ~$0.002 of credits.
  - hCaptcha + Cloudflare Turnstile against their official "always-pass" test sitekeys — **xfail** with documented reason (test sitekeys are solver-bypassed by 2Captcha as expected; left in place for visibility).
- **`note_server_429` integration in `SolverClient`** — five entry points (`call`, `balance`, `report`, `send_raw`, `get_result`) now detect `ERROR_NO_SLOT_AVAILABLE` / `MAX_USER_TURN` / `ERROR_TOO_MANY_TURNS` patterns in `ApiException` messages and notify the per-method rate limiter to back off, instead of hammering the API.
- **6 new env-var defaults documented in `.env.example`**: `TWOCAPTCHA_WEBHOOK_HOST`, `TWOCAPTCHA_WEBHOOK_PORT`, `TWOCAPTCHA_WEBHOOK_DB_PATH`, `TWOCAPTCHA_WEBHOOK_PUBLIC_URL`, `TWOCAPTCHA_WEBHOOK_SECRET`, `TWOCAPTCHA_RATE_LIMIT_PER_MINUTE` — completes the configuration surface introduced in 0.3.0.
- **Subprocess smoke test for the webhook entry point** (`tests/test_webhook_main_unit.py`) — boots `python -m twocaptcha_mcp.webhook_receiver --help` and asserts the argparse usage, lifting `webhook_receiver/__main__.py` coverage from 0 % to 100 %.
- **Edge-case unit tests** for `webhook_receiver.storage`, `tools.composite`, `client.rate_limiter` to close the remaining branch-coverage gaps.

### Changed

- **Branch coverage threshold** raised from 88 % to **92 %** in CI (`--cov-fail-under=92`). Actual coverage is **93.37 %** locally and on Linux.
- **`pyproject.toml`**: version `0.3.0 → 0.4.0`. Added two pytest markers — `live_all_captchas` (extended live captcha matrix, opt-in via `--live-all-captchas`) and `e2e` (MCP protocol tests, opt-in via `--run-e2e`).
- **`twocaptcha_mcp/__init__.py`**: `__version__ = "0.4.0"`.

### Verified

- `pytest --cov-fail-under=92`: **157 passed, 10 skipped**, **93.37 % branch coverage** on Windows 10 / Python 3.14 and Ubuntu 22.04 / Python 3.11.
- `pytest -m live --run-live`: 3 passed, 1 skipped (pingback CRUD — account IP not whitelisted).
- `pytest -m live --run-live --live-all-captchas`: reCAPTCHA v2 PASSED in 99.87 s; hCaptcha + Turnstile xfailed with documented reason.
- `pytest -m e2e --run-e2e`: **3 passed** on both Windows and Linux.
- `ruff check . && ruff format --check .`: clean.
- `mypy --strict twocaptcha_mcp`: 51 source files, 0 issues.
- `python -m build`: wheel 47 KB + sdist 190 KB on Linux.
- `twocaptcha-mcp-webhook --help`: works.

### Pending (gated behind explicit user permission)

- `git push` to a public origin — repo URL not yet provided.
- PyPI publish via Trusted Publishers OIDC.
- Production webhook deployment (nginx + Let's Encrypt + systemd + persistent registered URL with 2Captcha) — see `docs/DEPLOY-WEBHOOK.md`.
- PR to `punkpeye/awesome-mcp-servers`.

## [0.3.0] - 2026-05-03

Phase 2 closeout — adds non-blocking webhook mode, composite solve, per-method rate limiting, expanded live coverage, formal troubleshooting, and a production deployment guide. Pre-publication; PyPI publish remains gated behind explicit user permission.

### Added

- **Webhook receiver** (`twocaptcha-mcp-webhook` console script + `python -m twocaptcha_mcp.webhook_receiver`) — Starlette + uvicorn server that accepts 2Captcha pingback POSTs (form-encoded `id`+`code`) and persists them to SQLite (WAL mode, idempotent on `captcha_id` PRIMARY KEY). Optional shared secret via `TWOCAPTCHA_WEBHOOK_SECRET` (validated with constant-time compare against either `?secret=` query param or `X-Webhook-Secret` header). Routes: `POST /2captcha/pingback`, `GET /health`.
- **3 new MCP tools** for reading from the pingback store: `twocaptcha_pingback_events_list`, `twocaptcha_pingback_events_get`, `twocaptcha_pingback_events_clear`.
- **Composite tool** `twocaptcha_solve_and_wait_pingback` — sends a captcha via `AsyncTwoCaptcha.send` with pingback URL, then polls the local SQLite store until the result arrives (default 300 s timeout, 2 s poll interval). Replaces blocking-polling for long captcha types.
- **Per-method rate limiter** (`twocaptcha_mcp/client/rate_limiter.py`) — async sliding-window token bucket per SDK method name. Wired into `SolverClient.{call, balance, report, send_raw, get_result}`. Configurable via `TWOCAPTCHA_RATE_LIMIT_PER_MINUTE` (default 100). `note_server_429()` exposed for future SDK integration.
- **5 new env vars**: `TWOCAPTCHA_WEBHOOK_HOST`, `TWOCAPTCHA_WEBHOOK_PORT` (default 8787), `TWOCAPTCHA_WEBHOOK_DB_PATH` (XDG-compliant default), `TWOCAPTCHA_WEBHOOK_PUBLIC_URL`, `TWOCAPTCHA_WEBHOOK_SECRET`. Plus `TWOCAPTCHA_RATE_LIMIT_PER_MINUTE`.
- **3 new live tests**: `test_live_pingback_crud` (skipped automatically when `ERROR_IP_ADDRES` is returned by 2Captcha), `test_live_concurrent_balance` (5 parallel calls — verifies the rate limiter does not deadlock), plus the existing `test_live_balance` and `test_live_solve_normal` continue to pass.
- **`TROUBLESHOOTING.md`** — top 15 2Captcha API errors with concrete remediation, plus MCP integration pitfalls (`protocolVersion` mismatch, env var case sensitivity, "server hangs forever" → use webhook mode), plus webhook receiver operational notes (firewall, SQLite WAL).
- **`docs/DEPLOY-WEBHOOK.md`** — three deployment paths: nginx + Let's Encrypt + dedicated domain (production), Cloudflare Tunnel (testing), ngrok (fallback). Each path is end-to-end runnable.
- **`docs/release/twocaptcha-mcp-webhook.service`** — production-ready systemd unit with full sandboxing flags (`NoNewPrivileges`, `ProtectSystem`, `MemoryDenyWriteExecute`, etc.).

### Changed

- **`pyproject.toml`**: version `0.2.0 → 0.3.0`. Added second console script `twocaptcha-mcp-webhook = twocaptcha_mcp.webhook_receiver.__main__:main`.
- **`twocaptcha_mcp/__init__.py`**: `__version__ = "0.3.0"`.
- **`SolverClient.__init__`** now accepts an optional `rate_limiter: RateLimiter` arg; defaults to a per-instance limiter built from `Settings.twocaptcha_rate_limit_per_minute`.
- **`load_all_tool_modules`**: imports `tools.composite` plus `webhook_receiver.tools`; `EXPECTED_TOOL_COUNT` bumped from 39 → **43**.
- **`README.md`**: new "Webhook receiver" section linking deploy guide and troubleshooting.
- **`tests/test_main_smoke.py`**: subprocess MCP handshake now expects 43 tools.
- **`twocaptcha_mcp/webhook_receiver/storage.py`**: `list()` orders by `received_at DESC, rowid DESC` to give a deterministic newest-first order even when several events land in the same wall-clock second.

### Verified

- **139 passed, 4 skipped** on Windows 10 / Python 3.14 (`pytest --cov-fail-under=88` → 89 % branch).
- **139 passed, 4 skipped** on Ubuntu 22.04 / Python 3.11 (Linux VPS).
- **Live (Windows + Linux)**: 3 passed (balance + solve_normal + concurrent_balance), 1 skipped (pingback CRUD — account IP not whitelisted by 2Captcha; documented).
- `mypy --strict twocaptcha_mcp` — 51 source files, **0 issues**.
- `ruff check . && ruff format --check .` — clean on both platforms.
- `python -m build` — wheel 46 KB + sdist 154 KB on Linux; equivalent sizes on Windows.
- `pip install dist/twocaptcha_mcp-0.3.0-*.whl` in clean venv → both `twocaptcha-mcp` and `twocaptcha-mcp-webhook` console scripts work.

### Pending (gated behind explicit user permission)

- `git push` to a public origin — repo URL not yet provided.
- PyPI publish via Trusted Publishers OIDC (workflow + checklist already prepared in 0.2.0).
- Production webhook deployment on a Linux VPS (nginx + Let's Encrypt + systemd + persistent registered URL with 2Captcha) — see `docs/DEPLOY-WEBHOOK.md`.
- PR to `punkpeye/awesome-mcp-servers`.

## [0.2.0] - 2026-05-03

Production readiness: PyPI publish workflow, CI matrix, security policy, contributor guide, and pinned SDK snapshot tests. Pre-publication.

### Added

- **CI/CD pipeline** (`.github/workflows/ci.yml`): matrix Python 3.11/3.12/3.13 × {ubuntu, windows} running ruff + ruff format + mypy --strict + pytest with branch coverage; codecov upload from one job.
- **PyPI publish workflow** (`.github/workflows/publish.yml`) using **PyPI Trusted Publishers OIDC** (`pypa/gh-action-pypi-publish@release/v1`). Triggers on `release: published` or manual `workflow_dispatch` (with `dry-run` option). Verifies `pyproject.toml` version matches the release tag, builds wheel + sdist, attaches them to the GitHub Release.
- **Dependabot** (`.github/dependabot.yml`): weekly updates for pip and github-actions, grouped by area (runtime / dev-tools).
- **`tests/test_sdk_snapshot.py`** — pinned snapshot of 31 public solver methods + 4 management methods on `AsyncTwoCaptcha`; catches removal/rename and the kind of internal restructure that broke `twocaptcha.exceptions` in SDK 2.0.
- **`tests/test_main_smoke.py`** — subprocess-based smoke test that boots `python -m twocaptcha_mcp`, runs the full MCP `initialize` → `tools/list` JSON-RPC handshake, asserts 39 tools registered.
- **`tests/test_main_unit.py`** — unit tests for the stdio entrypoint (`_run` and `main`) raising coverage of `__main__.py` from 0 % to 94 %.
- **`tests/test_live.py`** under `pytest.mark.live` — opt-in live integration test against the real 2Captcha API (`balance` + `solve_normal` with a Pillow-generated image). Run with `pytest -m live --run-live`.
- **`SECURITY.md`** — private vulnerability reporting via GitHub Security Advisory; explicit threat-surface description.
- **`CONTRIBUTING.md`** — dev setup, quality gates, "how to add a new captcha type" 6-step recipe, and a formal **SemVer policy for MCP tools** (renaming/removing tool = MAJOR, adding tool = MINOR, etc.).
- **`LICENSE`** (MIT) at repo root.
- **`docs/RELEASE.md`** — step-by-step PyPI Trusted Publisher setup and per-release workflow.
- **`.github/ISSUE_TEMPLATE/`** (`bug_report.yml`, `feature_request.yml`) and **`.github/PULL_REQUEST_TEMPLATE.md`**.
- **`docs/release/awesome-mcp-pr.md`** — pre-written PR text for `punkpeye/awesome-mcp-servers` (held until first publish).
- **`docs/release/repo-metadata.md`** — GitHub repo description, topics, and branch-protection settings.
- **README badges**: PyPI version, Python versions, CI status, codecov, mypy strict, License.

### Changed

- **`2captcha-python`** dependency tightened from `>=1.6` to `>=2.0,<3.0` — protects against a hypothetical 3.x mass breaking change while still pulling in new captcha methods within 2.x.
- **Coverage threshold**: now enforced at branch level via the new CI workflow (`--cov-fail-under=88`).
- **README**: install section advertises `pip install twocaptcha-mcp` as the primary path, kept editable install for development.
- **`pyproject.toml`** dev extras: added `pillow>=10.0` (used to generate the live solve test image) and `build>=1.2` (used by `python -m build`).

### Verified

- `pytest`: 110 passed, 0 failed (98 from 0.1.0 + 4 sdk_snapshot + 4 main_unit + 2 main_smoke + 2 live).
- Branch coverage: 90 % overall; `__main__.py` 94 %.
- `ruff check . && ruff format --check .` clean.
- `mypy --strict twocaptcha_mcp` clean — 41 source files, 0 issues.
- `python -m build` produces clean wheel + sdist.
- Live tests on Windows + Ubuntu against production 2Captcha — `balance` returned the expected account amount, `solve_normal` of a generated image returned a non-empty `code` within ~24 s.

## [0.1.0] - 2026-05-03

Initial public release.

### Added

- **MCP stdio server** (`python -m twocaptcha_mcp`) wired to the official `2captcha-python` SDK (`AsyncTwoCaptcha`).
- **31 captcha-solver tools** covering every public method of `AsyncTwoCaptcha`:
  - Image-based: `solve_normal`, `solve_text`, `solve_audio`, `solve_grid`, `solve_canvas`, `solve_coordinates`, `solve_rotate`, `solve_vkimage`.
  - Token-based: `solve_recaptcha` (v2/v3/Enterprise via parameters), `solve_hcaptcha`, `solve_turnstile` (incl. CF Challenge), `solve_funcaptcha`, `solve_geetest`, `solve_geetest_v4`, `solve_capy`, `solve_keycaptcha`, `solve_lemin`, `solve_mtcaptcha`, `solve_friendly_captcha`, `solve_cutcaptcha`, `solve_amazon_waf`, `solve_tencent`, `solve_atb_captcha`.
  - Proxy-required: `solve_datadome`, `solve_captchafox`, `solve_vkcaptcha` (proxy + user_agent enforced by Pydantic).
  - Misc: `solve_prosopo`, `solve_temu`, `solve_altcha`, `solve_cybersiara`, `solve_yandex_smart`.
- **5 management tools**: `twocaptcha_balance`, `twocaptcha_report_good`, `twocaptcha_report_bad`, `twocaptcha_get_result`, `twocaptcha_send_raw` (escape hatch for unmapped SDK methods).
- **3 pingback CRUD tools** via legacy `res.php`: `twocaptcha_register_pingback`, `twocaptcha_list_pingbacks`, `twocaptcha_delete_pingback`.
- **`SolverClient` abstraction** — single dependency-inversion boundary between the MCP layer and the SDK; maps SDK exceptions (`ValidationException`, `NetworkException`, `TimeoutException`, `ApiException`) to internal `CaptchaError` subclasses.
- **`PingbackClient`** — thin httpx wrapper over `res.php` (the SDK does not expose pingback CRUD).
- **`ProxyConfig` and `SolverKwargs` mixins** — DRY proxy handling and shared optional kwargs for every captcha type.
- **`pydantic-settings`-based configuration** with primary alias `2Captcha_API_KEY` (case-insensitive), plus `TWOCAPTCHA_API_KEY`, `2CAPTCHA_API_KEY`, `API_KEY_2CAPTCHA` fallbacks.
- **98 tests, 88 % branch coverage**: unit per schema/handler, integration with mocked SDK, respx-mocked pingback HTTP, snapshot test for the public tool surface, dispatcher contract test, optional `--run-live` smoke for real `balance` + `solve_normal`.
- **Documentation**: `README.md`, `CLAUDE.md`, `.env.example`.

### Architectural decisions

- Built on the official `2captcha-python` SDK rather than re-implementing the JSON v2 API — DRY/KISS, automatic support for new SDK additions.
- `pydantic-settings` `case_sensitive=False` so the env name `2Captcha_API_KEY` (the canonical form in `.env`) works alongside upper-case fallbacks.
- For `datadome`, `captchafox`, `vkcaptcha` the `proxy` and `user_agent` requirements are encoded at the schema layer (separate `ProxyRequiredKwargs` mixin) — wrong inputs are rejected before reaching the SDK.
- Webhook pingback receiver intentionally **deferred to Phase 2** — Phase 1 ships pingback CRUD only, polling for results, stdio MCP transport.
- `SolverResult.from_sdk` preserves SDK-extended fields (cost / ip / time when `extendedResponse=True`) under `extra`.

### Verified

- Live `twocaptcha_balance` against the production 2Captcha API key — returned the expected account balance.
- `pytest`: 98 tests passed, branch coverage 88 % (target 80 %).
- `ruff check` and `ruff format --check`: clean.
- `mypy --strict twocaptcha_mcp`: 41 source files, 0 issues.

### Linux verification

- Ubuntu 22.04 / Python 3.11: `pytest -q` → 98 passed, `ruff check`/`ruff format --check` clean, `mypy --strict` clean, `python -m twocaptcha_mcp` registers all 39 tools and accepts stdio. Live `balance()` returned the expected account balance.
