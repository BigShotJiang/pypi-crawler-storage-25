# Troubleshooting

The most common errors you will see when running `twocaptcha-mcp` and what to
do about each. Errors arrive in MCP responses prefixed with one of:

- `api_error:` — 2Captcha API returned a logical error
- `network_error:` — transport-level failure
- `timeout_error:` — polling exceeded the configured timeout
- `invalid_argument:` — input validation failed (Pydantic or SDK)
- `internal_error:` — unexpected server-side bug; please file an issue

---

## 2Captcha API errors

### `ERROR_KEY_DOES_NOT_EXIST` / `ERROR_WRONG_USER_KEY`

Your API key is wrong or was revoked. Check:

- `2Captcha_API_KEY` env var (or `.env`) matches the key from <https://2captcha.com/setting>
- No leading/trailing whitespace
- Account is active and not banned

### `ERROR_ZERO_BALANCE`

You ran out of credits. Top up at <https://2captcha.com/pay>. Live solves cost
~$0.001-0.003 each.

### `ERROR_NO_SLOT_AVAILABLE`

All workers are busy. The SDK retries automatically, but if you see this
repeatedly:

- Reduce concurrency via `TWOCAPTCHA_RATE_LIMIT_PER_MINUTE` (default 100)
- Wait — peak hours have global capacity bottlenecks
- For ImageToText jobs only: try `ImageToTextTask` parameters such as `case`/`numeric`
  to narrow the worker pool

### `ERROR_BAD_PROXY` / `ERROR_PROXY_CONNECTION_FAILED`

The proxy you sent is invalid or unreachable from 2Captcha's workers.

- Check `proxy.uri` matches `[user:pass@]host:port`
- Ensure proxy is reachable from the public internet (workers connect from various IPs)
- For `solve_datadome` / `solve_captchafox` / `solve_vkcaptcha` — proxy is **mandatory** by SDK signature

### `ERROR_PINGBACK_NOT_ALLOWED` / `ERROR_IP_ADDRES`

The pingback URL you tried to register is not whitelisted. Two layers of allowlist:

1. **Domain allowlist** — register the host (or full URL) via
   `twocaptcha_register_pingback` first; only then can you pass `pingback=<url>` to a solver.
2. **IP allowlist** — add the public IP you call the API from at
   <https://2captcha.com/setting> → "Pingback IP". This is required for `add_pingback`
   itself to succeed.

### `ERROR_CAPTCHA_UNSOLVABLE`

The worker tried but could not solve. Common causes:

- Image is too distorted / corrupt
- For reCAPTCHA: `sitekey` or `url` mismatch — the worker loads the page and fails
- The captcha is configured with custom scoring that always fails for this user agent

Use `twocaptcha_report_bad <captcha_id>` within 15 minutes for a partial refund.

### `ERROR_TOO_BIG_CAPTCHA_FILESIZE`

The image you posted exceeds 100 KB after base64. Reduce dimensions / quality
client-side before sending.

### `ERROR_TASK_NOT_SUPPORTED`

The SDK forwarded a `method` that 2Captcha doesn't support. Most often:

- Using `twocaptcha_send_raw` with a typo in `method` (e.g. `userrecapcha` instead of `userrecaptcha`)
- Method available in newer SDK than what 2Captcha currently supports

### `ERROR_BAD_DUPLICATES`

You sent the same captcha within a short window — happens with retry loops on
`solve_normal`. Wait 5-10 seconds before retrying.

### `ERROR_REPORT_NOT_RECORDED` / `ERROR_DUPLICATE_REPORT`

You reported the same `captcha_id` twice or after the 15-minute window. Each
captcha can only be reported once.

### `MAX_USER_TURN`

Your account hit a global throughput limit. Spread requests over time or contact
2Captcha support to raise the limit.

---

## MCP integration

### `claude mcp add 2captcha -- python -m twocaptcha_mcp` succeeds but Claude shows no tools

- Restart Claude Code completely after `mcp add` — the in-process MCP client
  caches the tool list.
- Verify the server actually starts: run `python -m twocaptcha_mcp` manually,
  then in another terminal pipe `{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-06-18","capabilities":{},"clientInfo":{"name":"x","version":"0"}}}` to its stdin.
  You should see a JSON response.
- Check Claude Code's MCP log (`claude mcp logs 2captcha` if available) for stderr.

### `protocolVersion` mismatch

If the Claude Code build is older than this server's MCP SDK:

```
{"error":{"code":-32602,"message":"Unsupported protocol version"}}
```

Upgrade Claude Code (`npm i -g @anthropic-ai/claude-code@latest`) or pin
`mcp<X` in `pyproject.toml` to match.

### Env var case sensitivity

The primary alias is `2Captcha_API_KEY` (the canonical form 2Captcha uses), but
on Linux env vars are case-sensitive. Either:

- Use `TWOCAPTCHA_API_KEY` (all caps) for portability
- Or pass via `claude mcp add 2captcha -e 2Captcha_API_KEY=... -- ...` (Claude
  Code preserves case)

### Server hangs forever on a `solve_recaptcha` call

You hit the polling limitation — the MCP request slot is held by the handler
until 2Captcha returns. Switch to webhook mode:

1. Run `twocaptcha-mcp-webhook` separately (see `docs/DEPLOY-WEBHOOK.md`)
2. Use `twocaptcha_solve_and_wait_pingback` instead of direct `solve_recaptcha`
3. The handler is no longer blocked on upstream; it polls the local SQLite store

---

## Webhook receiver

### Pingback callbacks never arrive

In order:

1. Confirm `TWOCAPTCHA_WEBHOOK_PUBLIC_URL` resolves from outside (try
   `curl https://your-domain/health` from a different machine — must return 200).
2. Confirm the URL is registered: `twocaptcha_list_pingbacks` should include it.
3. Confirm the firewall allows inbound 443 (and 80 for Let's Encrypt renewal).
4. Check `2Captcha` solved the captcha at all — query `getbalance` and
   `pingback_events_list` in tandem. If the solver returned `code` in the SDK
   response but no pingback was sent, the URL might have been rejected silently.

### `SQLite database is locked`

WAL mode (`PRAGMA journal_mode=WAL`) is enabled, but multi-process writers can
still collide. Make sure only **one** `twocaptcha-mcp-webhook` process writes
to a given `TWOCAPTCHA_WEBHOOK_DB_PATH`. The MCP server (`twocaptcha-mcp`)
opens it read-only via SQLite library defaults.

### `pingback.db-wal` / `pingback.db-shm` files growing

These are SQLite WAL artifacts. They auto-checkpoint every 1000 pages. To
force a checkpoint manually:

```pwsh
sqlite3 pingback.db "PRAGMA wal_checkpoint(TRUNCATE);"
```

### Bad shared secret

If `TWOCAPTCHA_WEBHOOK_SECRET` is set and the URL you registered does not
include `?secret=<value>` (or 2Captcha doesn't include the matching header),
every pingback POST gets `401 unauthorized`. Either:

- Register the URL with the secret: `twocaptcha_register_pingback https://domain/2captcha/pingback?secret=<your-value>`
- Or unset `TWOCAPTCHA_WEBHOOK_SECRET` and rely on URL unguessability + IP allowlist (not recommended for production)

---

## Reporting a bug

When opening an issue please include:

- `python --version`, `pip show twocaptcha-mcp twocaptcha-python mcp`
- The exact MCP request that failed (sanitised — no API keys)
- The full `error` field from the response
- OS (Linux / Windows / macOS)
