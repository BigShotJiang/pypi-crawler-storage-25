# Contributing to `twocaptcha-mcp`

Thanks for considering a contribution. This document covers the dev loop, the
code conventions, the SemVer policy, and how to add support for a new captcha
type.

---

## Dev setup

```sh
git clone https://github.com/aruxojuyu665/2Captcha-MCP
cd 2Captcha-MCP
python -m venv .venv

# Activate the venv (POSIX): source .venv/bin/activate
# Activate the venv (Windows PowerShell): .venv\Scripts\Activate.ps1
# Then install the project in editable mode with dev extras:
python -m pip install -e ".[dev]"

cp .env.example .env   # add your 2Captcha_API_KEY
```

## Local quality gates

Run these before opening a PR. CI repeats all of them in matrix mode (Python 3.11/3.12/3.13 × ubuntu/windows).

```sh
ruff check .
ruff format --check .
mypy --strict twocaptcha_mcp
pytest --cov=twocaptcha_mcp --cov-branch --cov-fail-under=92
```

The full live test suite (consumes 2Captcha credits, ~$0.005) is opt-in:

```pwsh
pytest -m live --run-live
```

## Code conventions

- **No mocks in production code.** Mocks live in `tests/` only.
- **Tool handlers ≤ 5 lines.** All cross-captcha concerns belong in `schemas/common.py`.
- **DI boundary**: handlers depend only on `SolverClient` / `PingbackClient`, never the SDK directly.
- **PEP 8** + **type hints on every signature** (enforced by `mypy --strict`).
- Files under `~400` lines, functions under `~50` lines.
- Prefer immutable data structures and early returns over deep nesting.

## How to add a new captcha type

When `2captcha-python` adds a new method `AsyncTwoCaptcha.<name>(...)`:

1. **Schema.** Create `twocaptcha_mcp/schemas/<family>.py` with a `<Name>Request(SolverKwargs)`
   (or `ProxyRequiredKwargs` if proxy is mandatory by SDK signature) including a
   `to_sdk_call_kwargs()` method.
2. **Tool handler.** Create `twocaptcha_mcp/tools/<family>.py` decorated with
   `@captcha_tool(...)`, body should be exactly:
   ```python
   payload = await ctx.solver.call("<sdk_method>", **req.to_sdk_call_kwargs())
   return SolverResult.from_sdk(payload)
   ```
3. **Snapshot test.** Add the SDK method name to `REQUIRED_SOLVER_METHODS` in
   `tests/test_sdk_snapshot.py`, and the new tool name to `tests/test_tools_snapshot.py`.
   Bump `EXPECTED_TOOL_COUNT` accordingly.
4. **Loader.** Append the new tool module name to `twocaptcha_mcp/tools/__init__.py:load_all_tool_modules()`.
5. **README.** Add a row to the "Captcha solvers" table.
6. **Tests.** Add a happy-path test, mocking `SolverClient.call` and asserting the
   kwargs forwarded to the SDK match expectations.

Run `pytest -k snapshot` after every change — it must stay green.

---

## SemVer policy for the MCP tool surface

Treat MCP tools as a public API contract. The following changes determine the
version bump:

| Change | Bump |
|---|---|
| Renaming a tool (`twocaptcha_solve_X` → `twocaptcha_solve_Y`) | **MAJOR** |
| Removing a tool | **MAJOR** |
| Removing or renaming a required input field | **MAJOR** |
| Changing a field's type (e.g., `int` → `str`) | **MAJOR** |
| Tightening a constraint that previously-valid input now fails | **MAJOR** |
| Adding a new tool | **MINOR** |
| Adding a new optional input field | **MINOR** |
| Loosening a constraint (previously-invalid input now passes) | **MINOR** |
| Bug fix without changing tool surface | **PATCH** |
| Documentation, CI, dependency updates with no surface change | **PATCH** |

When in doubt, choose the more conservative bump.

---

## PR checklist

- [ ] Branch name follows `<type>/<short-description>` (e.g. `feat/add-newcaptcha-tool`)
- [ ] Title uses [Conventional Commits](https://www.conventionalcommits.org/) (`feat:`, `fix:`, `docs:`, `chore:`, `ci:`, `refactor:`, `test:`)
- [ ] All quality gates pass locally (ruff/mypy/pytest with branch coverage ≥ 92 %)
- [ ] New tests added for new behaviour
- [ ] `CHANGELOG.md` updated under the current in-progress version block
- [ ] If touching MCP tool surface: snapshot tests updated, SemVer bump justified

---

## Code of conduct

Be respectful. Don't be a jerk. We follow the spirit of the [Contributor Covenant](https://www.contributor-covenant.org/version/2/1/code_of_conduct/). Disagreement on technical decisions is fine; ad hominem is not.
