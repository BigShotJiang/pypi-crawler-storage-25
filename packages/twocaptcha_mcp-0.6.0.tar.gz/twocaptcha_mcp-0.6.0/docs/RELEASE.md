# Release process — `twocaptcha-mcp`

Versioning follows [SemVer](https://semver.org/) (see `CONTRIBUTING.md` § "SemVer policy" for what counts as breaking).

> **All publication steps require human action.** This document describes them step-by-step. Nothing in this repository auto-publishes without an explicit GitHub Release being created.

---

## One-time setup (do this only before the very first PyPI release)

### 1. Create the GitHub Environment

In GitHub → Repo → Settings → Environments → New environment:

- Name: `pypi`
- Deployment branch and tag rule: **Selected branches and tags** → add tag pattern `v*`
- (Optional) Required reviewers: yourself, for an extra confirmation step before publish

### 2. Create the PyPI Trusted Publisher (pending mode)

PyPI lets you authorise a GitHub workflow without storing API tokens. While the project does not yet exist on PyPI, you create it as a **pending publisher**; the first successful publish converts it to active.

Visit [pypi.org/manage/account/publishing/](https://pypi.org/manage/account/publishing/) and click **Add a new pending publisher**:

| Field | Value |
|---|---|
| PyPI Project Name | `twocaptcha-mcp` |
| Owner | `<your-github-username-or-org>` |
| Repository name | `2Captcha-MCP` (the GitHub repository name) |
| Workflow name | `publish.yml` |
| Environment name | `pypi` |

Save. The pending publisher will be listed under your account; it has no effect until the first publish.

### 3. (Optional) Create a Codecov account

Visit [codecov.io](https://about.codecov.io/) and link the GitHub repository. The CI workflow already uploads `coverage.xml` to Codecov via `codecov/codecov-action@v5`. If you skip this step, the upload step prints a warning but does not fail CI (`fail_ci_if_error: false`).

---

## Per-release workflow

### 1. Bump version locally

Edit two files in lockstep:

```python
# twocaptcha_mcp/__init__.py
__version__ = "X.Y.Z"
```

```toml
# pyproject.toml
[project]
version = "X.Y.Z"
```

The publish workflow has a guard that fails if these two diverge from the git tag.

### 2. Update CHANGELOG

Add a `## [X.Y.Z] - YYYY-MM-DD` section in `CHANGELOG.md` summarising what changed since the previous release.

### 3. Run the local pre-flight

```pwsh
# All gates must be green
ruff check .
ruff format --check .
mypy --strict twocaptcha_mcp
pytest --cov=twocaptcha_mcp --cov-branch --cov-fail-under=88

# Build artifacts locally to confirm packaging integrity
python -m build
ls dist/

# Sanity-install the wheel into an empty venv
python -m venv .release-check
.release-check/bin/python -m pip install dist/twocaptcha_mcp-X.Y.Z-*.whl
.release-check/bin/python -m twocaptcha_mcp   # Ctrl+C after seeing "Registering 39 tools"
rm -rf .release-check dist
```

### 4. Run live tests once

```pwsh
pytest -m live --run-live
```

This consumes a few cents of 2Captcha credits and confirms the round-trip
end-to-end (`balance` + `solve_normal`).

### 5. Commit, tag, push

```pwsh
git commit -am "release: vX.Y.Z"
git tag vX.Y.Z
git push origin main
git push origin vX.Y.Z
```

### 6. Create the GitHub Release

Go to GitHub → Releases → "Draft a new release":

- Tag: select the `vX.Y.Z` tag you just pushed
- Title: `vX.Y.Z`
- Description: copy the relevant `## [X.Y.Z]` block from `CHANGELOG.md`
- (Optional) Mark as latest

Click **Publish release**.

### 7. Watch the publish workflow

The `release: published` event triggers `.github/workflows/publish.yml`. It:

1. Checks out the tag
2. Verifies `pyproject.toml` version matches `vX.Y.Z`
3. Builds wheel + sdist via `python -m build`
4. Uploads the artifacts to the GitHub Release
5. Publishes to PyPI via `pypa/gh-action-pypi-publish` using OIDC (no token)

After ~30-60 seconds the package is live at `https://pypi.org/project/twocaptcha-mcp/X.Y.Z/`.

### 8. Verify the publish

```pwsh
# Wait ~1 minute for PyPI CDN propagation, then:
python -m venv .verify
.verify/bin/python -m pip install twocaptcha-mcp==X.Y.Z
.verify/bin/python -m twocaptcha_mcp   # should boot, then Ctrl+C
rm -rf .verify
```

### 9. Submit to MCP registries (first release only)

After `0.2.0` is live:

1. Open a PR against [`punkpeye/awesome-mcp-servers`](https://github.com/punkpeye/awesome-mcp-servers) using the prepared text in `docs/release/awesome-mcp-pr.md`.
2. Add the project to [`modelcontextprotocol/servers`](https://github.com/modelcontextprotocol/servers) under "Community Servers" if appropriate.

---

## Manual dry-run (anytime)

To validate the publish workflow without publishing:

GitHub → Actions → "Publish to PyPI" → "Run workflow" → set `dry-run = true`.

This builds the artifacts and skips the upload step. Useful when you reorganise `pyproject.toml` or test new build options.

---

## Yanking a release

If a release goes wrong, **yank** rather than delete (PyPI never lets you re-upload the same version):

```pwsh
twine upload --skip-existing  # explicitly forbidden — does not work
```

Instead:

1. PyPI → Project → Manage → Releases → "..." → **Yank release**
2. Cut a new patch version (`X.Y.Z+1`) with the fix and follow steps 1-8.
