# Deploying the webhook receiver

`twocaptcha-mcp-webhook` is a small Starlette + uvicorn HTTP server that listens
for 2Captcha pingback POSTs and persists them to SQLite. The MCP stdio server
(`twocaptcha-mcp`) reads from the same SQLite file via the `twocaptcha_pingback_events_*`
tools and the composite `twocaptcha_solve_and_wait_pingback`.

This document covers three deployment options, ordered by stability.

---

## Option 1 — nginx + Let's Encrypt + dedicated domain (recommended for production)

Stable URL, auto-renewing TLS, survives reboots.

### 1.1 Prerequisites

- A Linux VPS with public IPv4 + open ports 80/443
- A domain or subdomain with an A record pointing at the VPS (e.g. `2captcha.example.com`)
- Python 3.11+ on the VPS
- `2Captcha_API_KEY` exported (from <https://2captcha.com/setting>)

### 1.2 Install the package

```bash
python3.11 -m venv /opt/twocaptcha-mcp/venv
/opt/twocaptcha-mcp/venv/bin/pip install --upgrade pip
/opt/twocaptcha-mcp/venv/bin/pip install twocaptcha-mcp     # or git+https://github.com/aruxojuyu665/2Captcha-MCP
```

### 1.3 Create the systemd unit

Copy `docs/release/twocaptcha-mcp-webhook.service` to `/etc/systemd/system/` and
edit the `Environment=` lines. Then:

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now twocaptcha-mcp-webhook
sudo systemctl status twocaptcha-mcp-webhook   # should be active (running)
```

The service binds `127.0.0.1:8787` by default — no external traffic yet.

### 1.4 nginx as TLS-terminating reverse proxy

```nginx
# /etc/nginx/sites-available/twocaptcha-mcp
server {
    listen 80;
    server_name 2captcha.example.com;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl http2;
    server_name 2captcha.example.com;

    # certbot will fill these in
    ssl_certificate     /etc/letsencrypt/live/2captcha.example.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/2captcha.example.com/privkey.pem;

    location / {
        proxy_pass http://127.0.0.1:8787;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

```bash
sudo ln -s /etc/nginx/sites-available/twocaptcha-mcp /etc/nginx/sites-enabled/
sudo nginx -t && sudo systemctl reload nginx
sudo apt-get install -y certbot python3-certbot-nginx
sudo certbot --nginx -d 2captcha.example.com
```

Verify:

```bash
curl https://2captcha.example.com/health
# {"ok":true,"service":"twocaptcha-mcp-webhook","version":"0.3.0"}
```

### 1.5 Whitelist the URL with 2Captcha

From any environment with `2Captcha_API_KEY` (your laptop is fine):

```bash
python -m twocaptcha_mcp   # then call from MCP:
# twocaptcha_register_pingback {"addr":"https://2captcha.example.com/2captcha/pingback"}
```

Now `solve_*` tools accept `pingback=https://2captcha.example.com/2captcha/pingback`
and the composite tool `twocaptcha_solve_and_wait_pingback` works against this URL.

### 1.6 Optional shared secret

For an extra defence-in-depth layer (in case someone discovers the URL):

```bash
# /etc/systemd/system/twocaptcha-mcp-webhook.service.d/secret.conf
[Service]
Environment="TWOCAPTCHA_WEBHOOK_SECRET=$(openssl rand -hex 32)"
```

Then register the URL with the secret:

```
twocaptcha_register_pingback https://2captcha.example.com/2captcha/pingback?secret=<the_value>
```

The receiver checks both `?secret=` query param and `X-Webhook-Secret` header.

---

## Option 2 — Cloudflare Tunnel (recommended for testing / dev)

Exposes `localhost:8787` to a public `*.trycloudflare.com` URL without opening
ports or buying a domain. Tunnel terminates when the process dies.

### 2.1 Install cloudflared

```bash
# Debian/Ubuntu
curl -fsSL https://pkg.cloudflare.com/cloudflared.gpg | sudo tee /usr/share/keyrings/cloudflare.asc
echo "deb [signed-by=/usr/share/keyrings/cloudflare.asc] https://pkg.cloudflare.com/cloudflared stable main" \
    | sudo tee /etc/apt/sources.list.d/cloudflared.list
sudo apt-get update && sudo apt-get install -y cloudflared
```

### 2.2 Run

In one terminal:

```bash
twocaptcha-mcp-webhook --host 127.0.0.1 --port 8787
```

In another:

```bash
cloudflared tunnel --url http://localhost:8787
# 2025-XX-XX … +-------------------------------------------+
# 2025-XX-XX … |  https://random-words-1234.trycloudflare.com  |
# 2025-XX-XX … +-------------------------------------------+
```

Whitelist that URL via `twocaptcha_register_pingback`. Submit a captcha with
`pingback=https://random-words-1234.trycloudflare.com/2captcha/pingback`.

### 2.3 Limitations

- **URL is ephemeral.** Each `cloudflared tunnel --url` invocation generates a
  new random subdomain. Don't use for production.
- **Latency**: ~50-200 ms extra round-trip.
- **Cloudflare can rate-limit** abusive trycloudflare URLs without warning.

---

## Option 3 — ngrok fallback

Functionally similar to cloudflared. Free tier rotates URLs on every restart;
paid tier offers stable subdomains.

```bash
ngrok http 8787
# Forwarding   https://abcd-1234.ngrok-free.app -> http://localhost:8787
```

---

## Verifying end-to-end

```bash
# 1. Health
curl https://your-domain/health
# expect {"ok":true,"service":"twocaptcha-mcp-webhook",...}

# 2. Submit a real captcha with pingback set
# (do this from MCP client; with the composite tool):
# twocaptcha_solve_and_wait_pingback {
#   "params": {"method":"userrecaptcha","googlekey":"<sitekey>","pageurl":"https://example.com/"},
#   "pingback_url": "https://your-domain/2captcha/pingback",
#   "timeout": 300
# }

# 3. Inspect the local store
# twocaptcha_pingback_events_list {"limit": 10}

# 4. Cleanup
# twocaptcha_pingback_events_clear {"before_received_at": <unix-sec-of-yesterday>}
```

## Operational notes

- **One writer process.** Only one `twocaptcha-mcp-webhook` should write to a given
  `TWOCAPTCHA_WEBHOOK_DB_PATH`. Multiple readers (MCP servers) are fine.
- **Backups.** The SQLite file at `TWOCAPTCHA_WEBHOOK_DB_PATH` (default
  `/var/lib/twocaptcha-mcp/pingback.db`) holds your captcha solutions. If you
  charge per solve, back it up.
- **Log rotation.** uvicorn writes to stdout; let systemd / journalctl handle rotation.
- **Reboots.** With the systemd unit `WantedBy=multi-user.target`, the service
  auto-starts on boot.
