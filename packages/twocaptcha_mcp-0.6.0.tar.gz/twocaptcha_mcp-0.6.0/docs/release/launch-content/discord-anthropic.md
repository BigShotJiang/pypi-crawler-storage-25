# Anthropic Discord — `#mcp` channel post

**Destination**: Anthropic's official Discord server, channel `#mcp` (or whichever MCP-themed channel is currently active — channel names rotate; if `#mcp` doesn't exist, look for `#mcp-servers`, `#community-mcp-servers`, or post in `#projects` / `#showcase` if no MCP-specific channel).

**Etiquette**:
- One post in one channel. Do **not** cross-post to multiple channels.
- No `@everyone` / `@here` / role pings.
- Plain text + Markdown links is fine; no images / GIFs / banners.

## Post (≤ 2000 chars — Discord limit)

```
Hey 👋 — I've published a new MCP server: **2Captcha MCP** (`pip install twocaptcha-mcp`).

It exposes the full **2Captcha** API surface to MCP clients — 43 tools covering 31 captcha types (reCAPTCHA v2/v3/Enterprise, hCaptcha, Cloudflare Turnstile, FunCaptcha, GeeTest v3/v4, image/text/audio/grid/canvas/coordinates/rotate, plus 17 more), 5 management tools, 3 pingback CRUD tools, 3 webhook event-store tools, and 1 composite `solve_and_wait_pingback` for non-blocking solves.

Strict pydantic v2 schemas, `mypy --strict` clean, ≥ 92 % branch coverage, CI matrix Python 3.11–3.13 × {Ubuntu, Windows}. Built on the official `2captcha-python` `AsyncTwoCaptcha` SDK so retry/polling/parsing happen upstream.

For long-running solves (reCAPTCHA v3 up to 600 s) there's an optional `twocaptcha-mcp-webhook` receiver — 2Captcha POSTs the result to your URL and the MCP tools read asynchronously without blocking the MCP request slot.

GitHub: <https://github.com/aruxojuyu665/2Captcha-MCP>
PyPI:   <https://pypi.org/project/twocaptcha-mcp/>
MIT licensed.

Feedback / issues / PRs all welcome 🙏 — especially around the 31-family schema design, since every captcha type has different required arguments and proxy semantics.
```
