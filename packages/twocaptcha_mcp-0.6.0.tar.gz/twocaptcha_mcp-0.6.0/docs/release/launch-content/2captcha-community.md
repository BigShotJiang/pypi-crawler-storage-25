# 2Captcha community announcement

**Destinations** (post once per medium that's actually active for your account):

- **2Captcha Telegram channel** — find via the link on the 2Captcha homepage footer or in account settings; usually `t.me/Twocaptcha` or similar.
- **2Captcha Discord** (if you're a member) — the official 2Captcha server's announcements / community channel.
- **2Captcha forum** (if active in your locale) — usually has a "tools / integrations" subforum.
- **Reddit `r/2Captcha`** (if it exists and is active) — usually low traffic but targeted.

**Audience profile**: developers who already use the 2Captcha API directly via SDK / HTTP, often automating browser flows, scrapers, or QA pipelines. They care about: reliability, cost transparency, supported captcha types, latency. Lead with concrete numbers, not marketing.

## Long form (forum / Discord / Telegram with markdown)

```
**2Captcha MCP — official 2Captcha API exposed as a Model Context Protocol server**

For developers using AI agents (Claude Code, Continue, Cursor, etc.), there's now a Model Context Protocol (MCP) server that wraps the full **2Captcha** API into 43 callable tools the agent can use directly.

**What's covered (43 tools, 1:1 with the upstream `2captcha-python` SDK):**

- 31 captcha solvers: reCAPTCHA v2 / v3 / Enterprise, hCaptcha, Cloudflare Turnstile, FunCaptcha, GeeTest v3 / v4, image / text / audio / grid / canvas / coordinates / rotate / vkimage, plus DataDome, CaptchaFox, Lemin, MTCaptcha, FriendlyCaptcha, CutCaptcha, Amazon WAF, Tencent, ATB, Prosopo, Temu, Altcha, CyberSiARA, Yandex Smart, KeyCaptcha, Capy, VK
- 5 management tools: balance, report_good, report_bad, get_result, send_raw
- 3 pingback CRUD tools: register / list / delete pingback URLs
- 3 webhook event-store tools + 1 composite `solve_and_wait_pingback` (non-blocking solve via the bundled `twocaptcha-mcp-webhook` server — fire a captcha, the result arrives at your endpoint, the MCP tool reads from local SQLite)

**Tech**: built on the official `2captcha-python` `AsyncTwoCaptcha` SDK. Strict pydantic v2 schemas, `mypy --strict` clean, ≥ 92 % branch coverage, CI matrix Python 3.11–3.13 on Ubuntu + Windows.

**Install**: `pip install twocaptcha-mcp`

**License**: MIT — no telemetry, no opinions on what you build with the solutions.

**GitHub**: https://github.com/aruxojuyu665/2Captcha-MCP
**PyPI**: https://pypi.org/project/twocaptcha-mcp/

Issue tracker open for new captcha types and feature requests. Pull requests very welcome — `CONTRIBUTING.md` describes the 5-step recipe for adding a new captcha family.
```

## Short form (Telegram channel announcement, ≤ 600 chars)

```
🤖 New: 2Captcha MCP — full 2Captcha API as a Model Context Protocol server for AI agents (Claude Code, Continue, Cursor).

43 tools: 31 captcha solvers, 5 management, 3 pingback CRUD, 3 webhook event-store, 1 composite solve-and-wait. Built on the official 2captcha-python AsyncTwoCaptcha SDK with strict pydantic v2 schemas and ≥ 92 % test coverage.

📦 pip install twocaptcha-mcp
🔗 https://github.com/aruxojuyu665/2Captcha-MCP
📄 MIT
```

## What NOT to do

- Don't post on the same medium twice — even with edits.
- Don't promise "pricing", "support", or anything that implies an official 2Captcha endorsement; this is a community wrapper.
- Don't include screenshots of agent-driven captcha-bypass flows — keep it about the API tooling, not specific use cases.
