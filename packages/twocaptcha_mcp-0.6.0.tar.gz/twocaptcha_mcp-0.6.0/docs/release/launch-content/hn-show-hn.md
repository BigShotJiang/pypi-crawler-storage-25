# Hacker News — Show HN

**Destination**: <https://news.ycombinator.com/submit>

**Timing**: Tuesday–Thursday, **08:00–10:00 UTC** (peak US-East-Coast morning, when most active readers check HN). Avoid weekends, US holidays, and any time outside this window — front-page ranking depends heavily on early-vote velocity.

**Posting rules** (per <https://news.ycombinator.com/showhn.html>):
- One Show HN per project, ever — pivots to a different angle (e.g. "Show HN: I rewrote …") are fine months later, but the *same* URL twice is frowned on.
- The link must point to something a HN reader can interact with. Our GitHub repo with `pip install twocaptcha-mcp` qualifies.
- Don't ask for upvotes anywhere (Discord, Twitter). HN punishes solicited voting and will sink the post.

## Title

> **Note**: HN limits titles to 80 chars. Avoid hype words ("revolutionary", "the best", "amazing") — moderators dock points for them.

```
Show HN: 2Captcha MCP – full 2Captcha API surface for Claude Code (43 tools)
```

(78 chars; safe.)

## URL field

```
https://github.com/aruxojuyu665/2Captcha-MCP
```

## Text field (optional but recommended)

> Keep it 3–6 short paragraphs. HN readers like terseness; the more you describe, the less they read.

```
2Captcha MCP is a Model Context Protocol server that exposes the full 2Captcha API surface to MCP clients (Claude Code, Continue, etc.) over stdio.

Tools: 31 captcha solvers (reCAPTCHA v2/v3/Enterprise, hCaptcha, Cloudflare Turnstile, FunCaptcha, GeeTest v3/v4, image/text/audio/grid/canvas/coordinates/rotate, plus 17 more), 5 management tools, 3 pingback CRUD tools, 3 webhook event-store tools, and 1 composite solve-and-wait. 43 in total.

The MCP layer is strictly typed (pydantic v2, mypy --strict), with 93 % branch coverage and a CI matrix across Python 3.11–3.13 on Ubuntu and Windows. Built on the official 2captcha-python AsyncTwoCaptcha SDK so retry/polling/parsing are handled upstream — when 2Captcha adds a new captcha type, it's available the moment the SDK adds it.

For long-running solves (reCAPTCHA v3 up to 600 s) the polling-mode SDK call holds the MCP request slot. The optional twocaptcha-mcp-webhook receiver flips into pingback mode — 2Captcha POSTs the result to your URL, the receiver writes it to SQLite, and the MCP tools read asynchronously without blocking.

pip install twocaptcha-mcp / MIT licensed / no telemetry / no opinions on what you do with the captcha solutions you get.

Feedback welcome — particularly on the schema design for the 31 solver families (every captcha type has different required arguments and proxy semantics; we lean hard on pydantic to enforce this at the schema layer).
```

## After submitting

- Stay near the post for the first 30–60 minutes to answer questions in good faith.
- Do not engage in karma-chasing, do not delete the post if it underperforms, do not edit the title after submission.
- If it lands on the front page, the corresponding bump in PyPI downloads + GitHub stars typically arrives within 4–8 hours.
