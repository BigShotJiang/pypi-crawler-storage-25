# Launch content — copy-paste ready

Pre-written submissions for community channels that don't expose a public API and therefore require manual posting. Each file below is a copy-paste-ready snippet plus the destination URL.

| Channel | File | Destination |
|---|---|---|
| mcp.so | [mcp-so-submission.md](mcp-so-submission.md) | <https://mcp.so/> (look for "Submit" link) |
| Hacker News (Show HN) | [hn-show-hn.md](hn-show-hn.md) | <https://news.ycombinator.com/submit> |
| Anthropic Discord (#mcp) | [discord-anthropic.md](discord-anthropic.md) | Anthropic's official Discord, channel `#mcp` (or current MCP-themed channel) |
| 2Captcha community | [2captcha-community.md](2captcha-community.md) | 2Captcha forum / Telegram channel / Discord (whichever is active) |

**Order of posting (recommended)**:

1. **mcp.so** — first; small footprint, gets the listing visible.
2. **2Captcha community** — second; targeted audience already familiar with the underlying service.
3. **Anthropic Discord `#mcp`** — third; targeted audience already using MCP.
4. **HN Show HN** — last, and only on **Tue–Thu, 8–10 UTC** for peak US-morning ranking. Posting outside that window halves your chance of front-page visibility. You can post once. If it doesn't land, do not re-submit the same URL — pivot to a different angle a few weeks later.
