# mcp.so submission

**Destination**: <https://mcp.so/> — look for a "Submit" / "Add Server" / "Submit Server" button (anti-bot blocks WebFetch from auto-discovering it; if no obvious button on the homepage, check the footer or contact the maintainer via the GitHub repo linked from the site footer).

**Estimated time**: 3–5 minutes.

## Form fields (copy-paste)

### Server name

```
2Captcha MCP
```

### GitHub URL

```
https://github.com/aruxojuyu665/2Captcha-MCP
```

### PyPI URL (if asked)

```
https://pypi.org/project/twocaptcha-mcp/
```

### Description (short — usually a tagline, ≤ 150 chars)

```
Full 2Captcha API (43 tools) for Claude Code — 31 captcha solvers, management, pingback CRUD, webhook receiver. Built on the official AsyncTwoCaptcha SDK.
```

### Description (long — usually a paragraph)

```
2Captcha MCP exposes the full 2Captcha API surface to MCP clients (Claude Code, Continue, etc.) over stdio.

43 tools: 31 captcha-solver tools (reCAPTCHA v2/v3/Enterprise, hCaptcha, Cloudflare Turnstile, FunCaptcha, GeeTest v3/v4, image / text / audio / grid / canvas / coordinates / rotate, plus 17 more), 5 management tools (balance, report_good, report_bad, get_result, send_raw), 3 pingback CRUD tools, 3 webhook event-store tools, and 1 composite solve_and_wait_pingback for non-blocking solves.

Built on the official 2captcha-python AsyncTwoCaptcha SDK; the MCP layer is strictly typed (pydantic v2, mypy --strict), with ≥ 92 % branch coverage and a CI matrix across Python 3.11–3.13 × {ubuntu, windows}.

Install: pip install twocaptcha-mcp
License: MIT
```

### Categories / Tags (whichever the form supports)

```
captcha, captcha-solver, recaptcha, hcaptcha, turnstile, automation, browser-automation, ai-agent, claude-code, python, async, pydantic
```

### Logo / Icon

If asked for one and you don't have a custom one, leave blank or use the GitHub repository's auto-generated avatar. (We'll add a real icon in a future release.)

### Author / Maintainer

```
aruxojuyu665
```

### License

```
MIT
```
