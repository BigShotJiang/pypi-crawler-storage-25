# GitHub repository metadata

Used when you create the public GitHub repo for the first time. Paste these
into Repo → Settings.

## Description (≤ 350 chars)

```
MCP server exposing the full 2Captcha API to Claude Code: 43 tools (31 captcha solvers + 5 management + 3 pingback CRUD + 3 webhook event-store + 1 composite solve-and-wait), built on the official 2captcha-python AsyncTwoCaptcha SDK. Strict pydantic v2 schemas, mypy --strict clean, ≥ 92 % branch coverage, CI matrix Python 3.11–3.13 × Linux/Windows.
```

## Topics

```
mcp
mcp-server
2captcha
captcha
captcha-solver
recaptcha
hcaptcha
turnstile
claude-code
ai-agent
python
asyncio
pydantic
```

## Settings

- Visibility: **Public**
- Default branch: `main`
- Features: Issues ✅, Discussions (optional), Projects (optional)
- Pull requests: "Allow squash merging" only; "Automatically delete head branches" ✅
- Branch protection (`main`):
  - Require a pull request before merging
  - Require status checks to pass: `lint-types`, `test (3.11, ubuntu-latest)`, `test (3.12, ubuntu-latest)`, `test (3.13, ubuntu-latest)`, `test (3.11, windows-latest)`, `test (3.12, windows-latest)`, `test (3.13, windows-latest)`
  - Require branches to be up to date before merging
- Tag protection rule: `v*` — match the tags that trigger publish

## Environment

- Name: `pypi`
- Deployment branch and tag rule: tags matching `v*`
- (Optional) Required reviewers: yourself
