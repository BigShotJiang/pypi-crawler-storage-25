# Draft PR for `punkpeye/awesome-mcp-servers`

> Submit only after `twocaptcha-mcp` is live on PyPI.

## PR title

```
Add twocaptcha-mcp — full 2Captcha API surface (43 tools)
```

## PR description

```markdown
## What

Adds `twocaptcha-mcp` to the list — an MCP server that exposes the full
[2Captcha](https://2captcha.com/) API surface to MCP clients (Claude Code,
Continue, etc.) over stdio.

- 31 captcha-solver tools (reCAPTCHA v2/v3/Enterprise, hCaptcha, Cloudflare
  Turnstile, FunCaptcha, GeeTest v3/v4, image / text / audio / grid / canvas
  / coordinates / rotate, plus 17 more)
- 5 management tools (`balance`, `report_good`, `report_bad`, `get_result`, `send_raw`)
- 3 pingback CRUD tools
- 3 webhook event-store tools + 1 composite `solve_and_wait_pingback`
  for non-blocking solves over the optional `twocaptcha-mcp-webhook` receiver

Built on the official `2captcha-python` `AsyncTwoCaptcha` SDK; the MCP layer is
strictly typed (`pydantic v2`, `mypy --strict`), ≥ 92 % branch coverage, CI matrix
3.11/3.12/3.13 × {ubuntu, windows}.

## Repo

- GitHub: https://github.com/aruxojuyu665/2Captcha-MCP
- PyPI: https://pypi.org/project/twocaptcha-mcp/
- License: MIT
- Python: ≥ 3.11
```

## README addition

Insert under the appropriate category (likely **🌐 Browser Automation** or
**🔐 Security & Privacy**, depending on maintainer's preference):

```markdown
- [twocaptcha-mcp](https://github.com/aruxojuyu665/2Captcha-MCP) — Full [2Captcha](https://2captcha.com/) API surface (43 tools: 31 solvers + management + pingback CRUD). Stdio MCP server in Python.
```

## Notes for the submitter

- Keep PR description short; maintainers prefer minimal noise.
- Preserve the alphabetical ordering of the section.
- If the maintainer asks for an emoji icon, the project uses 🤖 (it's an MCP
  server) and 🛡️ (it deals with captcha bypass).
