"""Per-method async rate limiter for SolverClient.

Sliding-window over `_WINDOW_SECONDS` (60 s by default). One bucket per method
name (e.g. "recaptcha", "balance"). Limit is shared across the whole process —
parallel `asyncio.gather` of 200 `solve_recaptcha` calls will queue up locally
instead of hammering 2Captcha and triggering ERROR_NO_SLOT_AVAILABLE.
"""

from __future__ import annotations

import asyncio
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Final

_WINDOW_SECONDS: Final = 60.0


@dataclass
class _Bucket:
    limit: int
    timestamps: deque[float] = field(default_factory=deque)
    lock: asyncio.Lock = field(default_factory=asyncio.Lock)


class RateLimiter:
    """Async sliding-window limiter. Awaits a free slot before allowing a call."""

    def __init__(self, default_per_minute: int = 100) -> None:
        if default_per_minute < 1:
            raise ValueError("default_per_minute must be >= 1")
        self._default = default_per_minute
        self._buckets: dict[str, _Bucket] = {}
        self._buckets_lock = asyncio.Lock()

    async def _get_bucket(self, key: str) -> _Bucket:
        async with self._buckets_lock:
            bucket = self._buckets.get(key)
            if bucket is None:
                bucket = _Bucket(limit=self._default)
                self._buckets[key] = bucket
            return bucket

    async def acquire(self, key: str) -> None:
        """Block until a slot is available for `key` within the rolling window."""
        bucket = await self._get_bucket(key)
        while True:
            async with bucket.lock:
                now = time.monotonic()
                cutoff = now - _WINDOW_SECONDS
                while bucket.timestamps and bucket.timestamps[0] <= cutoff:
                    bucket.timestamps.popleft()
                if len(bucket.timestamps) < bucket.limit:
                    bucket.timestamps.append(now)
                    return
                wait_for = _WINDOW_SECONDS - (now - bucket.timestamps[0]) + 0.01
            await asyncio.sleep(max(wait_for, 0.05))

    def note_server_429(self, key: str) -> None:
        """Pre-fill the bucket on remote 429 / ERROR_NO_SLOT to back off locally."""
        bucket = self._buckets.get(key)
        if bucket is None:
            return
        now = time.monotonic()
        while len(bucket.timestamps) < bucket.limit:
            bucket.timestamps.append(now)
