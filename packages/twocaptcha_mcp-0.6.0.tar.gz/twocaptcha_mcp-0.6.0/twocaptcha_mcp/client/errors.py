"""Internal error hierarchy. Maps 1:1 from `twocaptcha.exceptions.*`."""

from __future__ import annotations


class CaptchaError(Exception):
    """Base for all 2captcha client errors."""

    code: str = "captcha_error"

    def __init__(self, message: str, *, original: BaseException | None = None) -> None:
        super().__init__(message)
        self.message = message
        self.original = original

    def __str__(self) -> str:
        return f"{self.code}: {self.message}"


class CaptchaValidationError(CaptchaError):
    """Bad arguments passed to the SDK (maps from twocaptcha ValidationException)."""

    code = "validation_error"


class CaptchaNetworkError(CaptchaError):
    """Transport-level failure (maps from twocaptcha NetworkException)."""

    code = "network_error"


class CaptchaTimeoutError(CaptchaError):
    """Polling exceeded the configured timeout (maps from twocaptcha TimeoutException)."""

    code = "timeout_error"


class CaptchaApiError(CaptchaError):
    """The 2Captcha API returned a logical error (ERROR_*, balance issues, etc)."""

    code = "api_error"
