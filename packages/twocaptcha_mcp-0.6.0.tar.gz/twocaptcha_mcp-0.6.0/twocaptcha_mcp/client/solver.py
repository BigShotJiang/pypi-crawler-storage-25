"""Async wrapper around `twocaptcha.AsyncTwoCaptcha`."""

from __future__ import annotations

from typing import Any

from twocaptcha import (
    ApiException,
    AsyncTwoCaptcha,
    NetworkException,
    TimeoutException,
    ValidationException,
)

from twocaptcha_mcp.client.errors import (
    CaptchaApiError,
    CaptchaNetworkError,
    CaptchaTimeoutError,
    CaptchaValidationError,
)
from twocaptcha_mcp.client.rate_limiter import RateLimiter
from twocaptcha_mcp.config import Settings
from twocaptcha_mcp.logger import get_logger

_LOG = get_logger("client.solver")

# 2Captcha error codes that signal we hit a per-account rate limit. When we see
# any of these in the SDK exception message, we mark the corresponding bucket as
# full so the *next* local call to the same method blocks briefly instead of
# spamming the upstream.
_RATE_LIMIT_PATTERNS: tuple[str, ...] = (
    "ERROR_NO_SLOT_AVAILABLE",
    "MAX_USER_TURN",
    "ERROR_TOO_MANY_TURNS",
)


def _is_rate_limited(exc: Exception) -> bool:
    msg = str(exc).upper()
    return any(p in msg for p in _RATE_LIMIT_PATTERNS)


def _wrap(exc: Exception) -> Exception:
    """Map a 2captcha SDK exception into our internal hierarchy."""
    if isinstance(exc, ValidationException):
        return CaptchaValidationError(str(exc), original=exc)
    if isinstance(exc, NetworkException):
        return CaptchaNetworkError(str(exc), original=exc)
    if isinstance(exc, TimeoutException):
        return CaptchaTimeoutError(str(exc), original=exc)
    if isinstance(exc, ApiException):
        return CaptchaApiError(str(exc), original=exc)
    return exc


class SolverClient:
    """All tool handlers depend on this abstraction; the SDK is internal detail."""

    def __init__(self, settings: Settings, *, rate_limiter: RateLimiter | None = None) -> None:
        self._settings = settings
        self._impl = AsyncTwoCaptcha(
            apiKey=settings.twocaptcha_api_key,
            softId=settings.twocaptcha_soft_id,
            callback=settings.twocaptcha_default_callback,
            defaultTimeout=int(settings.twocaptcha_default_timeout),
            recaptchaTimeout=int(settings.twocaptcha_recaptcha_timeout),
            pollingInterval=int(settings.twocaptcha_polling_interval),
            server=settings.twocaptcha_server,
        )
        self._rate_limiter = rate_limiter or RateLimiter(
            default_per_minute=settings.twocaptcha_rate_limit_per_minute
        )

    async def aclose(self) -> None:
        """Best-effort shutdown — newer SDKs expose `close()` on the underlying api client."""
        api = getattr(self._impl, "api_client", None)
        if api is None:
            return
        close = getattr(api, "close", None)
        if close is None:
            return
        try:
            result = close()
            if hasattr(result, "__await__"):
                await result
        except Exception as exc:  # pragma: no cover — defensive
            _LOG.debug("api_client.close raised %r", exc)

    def _maybe_note_rate_limited(self, exc: Exception, method_name: str) -> None:
        """If exc is an ApiException with a rate-limit code, mark the bucket full."""
        if isinstance(exc, ApiException) and _is_rate_limited(exc):
            self._rate_limiter.note_server_429(method_name)

    async def call(self, method_name: str, /, **kwargs: Any) -> dict[str, Any]:
        """Invoke an arbitrary SDK solver method by name and return its dict response."""
        method = getattr(self._impl, method_name, None)
        if method is None or not callable(method):
            raise CaptchaValidationError(f"Unknown 2Captcha method: {method_name!r}")
        await self._rate_limiter.acquire(method_name)
        try:
            result = await method(**kwargs)
        except (
            ValidationException,
            NetworkException,
            TimeoutException,
            ApiException,
        ) as exc:
            self._maybe_note_rate_limited(exc, method_name)
            raise _wrap(exc) from exc
        if not isinstance(result, dict):
            raise CaptchaApiError(
                f"Unexpected SDK response shape for {method_name}: {type(result).__name__}"
            )
        return result

    async def balance(self) -> float:
        await self._rate_limiter.acquire("balance")
        try:
            value = await self._impl.balance()
        except (
            ValidationException,
            NetworkException,
            TimeoutException,
            ApiException,
        ) as exc:
            self._maybe_note_rate_limited(exc, "balance")
            raise _wrap(exc) from exc
        return float(value)

    async def report(self, captcha_id: str, *, correct: bool) -> None:
        await self._rate_limiter.acquire("report")
        try:
            await self._impl.report(captcha_id, correct)
        except (
            ValidationException,
            NetworkException,
            TimeoutException,
            ApiException,
        ) as exc:
            self._maybe_note_rate_limited(exc, "report")
            raise _wrap(exc) from exc

    async def send_raw(self, **kwargs: Any) -> str:
        await self._rate_limiter.acquire("send")
        try:
            value = await self._impl.send(**kwargs)
        except (
            ValidationException,
            NetworkException,
            TimeoutException,
            ApiException,
        ) as exc:
            self._maybe_note_rate_limited(exc, "send")
            raise _wrap(exc) from exc
        return str(value)

    async def get_result(self, captcha_id: str) -> str:
        await self._rate_limiter.acquire("get_result")
        try:
            value = await self._impl.get_result(captcha_id)
        except (
            ValidationException,
            NetworkException,
            TimeoutException,
            ApiException,
        ) as exc:
            self._maybe_note_rate_limited(exc, "get_result")
            raise _wrap(exc) from exc
        return str(value)
