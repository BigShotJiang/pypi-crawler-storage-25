"""Async HTTP client for legacy 2Captcha pingback CRUD (`res.php`)."""

from __future__ import annotations

import httpx

from twocaptcha_mcp.client.errors import CaptchaApiError, CaptchaNetworkError
from twocaptcha_mcp.config import Settings
from twocaptcha_mcp.logger import get_logger

_LOG = get_logger("client.pingback")


def _parse_ok_or_raise(body: str) -> str:
    """`OK_<addr>` / `OK|a|b|c` / `OK` → return body without leading `OK`. Else raise."""
    body = body.strip()
    if body == "OK" or body.startswith("OK_") or body.startswith("OK|"):
        return body
    raise CaptchaApiError(body or "<empty>")


class PingbackClient:
    """Thin wrapper around `https://<server>/res.php?action=*_pingback`."""

    def __init__(self, settings: Settings) -> None:
        self._api_key = settings.twocaptcha_api_key
        self._client = httpx.AsyncClient(
            base_url=f"https://{settings.twocaptcha_server}",
            timeout=settings.twocaptcha_default_timeout,
        )

    async def aclose(self) -> None:
        await self._client.aclose()

    async def _get(self, params: dict[str, str]) -> str:
        params = {"key": self._api_key, **params}
        try:
            response = await self._client.get("/res.php", params=params)
        except (httpx.TimeoutException, httpx.TransportError) as exc:
            raise CaptchaNetworkError(f"{type(exc).__name__}: {exc}", original=exc) from exc
        if response.status_code >= 500:
            raise CaptchaApiError(f"http_{response.status_code}: {response.text[:200]}")
        return response.text

    async def add(self, addr: str) -> str:
        """Whitelist `addr` for use as a pingback URL. Returns the registered address."""
        body = _parse_ok_or_raise(await self._get({"action": "add_pingback", "addr": addr}))
        if body.startswith("OK_"):
            return body[3:]
        # Some servers reply with bare "OK" — fall back to the input.
        return addr

    async def list(self) -> list[str]:
        """List all currently-whitelisted pingback addresses (may be empty)."""
        body = _parse_ok_or_raise(await self._get({"action": "get_pingback"}))
        if body == "OK":
            return []
        # Format: "OK|addr1|addr2|..."
        parts = body.split("|")
        return [p for p in parts[1:] if p]

    async def delete(self, addr: str) -> int:
        """Delete one pingback address (or all when `addr == "all"`). Returns count removed."""
        if addr == "all":
            before = await self.list()
            _parse_ok_or_raise(await self._get({"action": "del_pingback", "addr": "all"}))
            return len(before)
        before = await self.list()
        _parse_ok_or_raise(await self._get({"action": "del_pingback", "addr": addr}))
        after = await self.list()
        return max(len(before) - len(after), 0)
