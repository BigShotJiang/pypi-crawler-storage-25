"""MCP server bootstrap: wires SolverClient + PingbackClient into an MCP Server."""

from __future__ import annotations

import json
from typing import Any

from mcp import types
from mcp.server.lowlevel import Server
from pydantic import BaseModel, ValidationError

from twocaptcha_mcp import __version__
from twocaptcha_mcp.client import (
    CaptchaApiError,
    CaptchaNetworkError,
    CaptchaTimeoutError,
    CaptchaValidationError,
    PingbackClient,
    SolverClient,
)
from twocaptcha_mcp.config import Settings
from twocaptcha_mcp.logger import get_logger
from twocaptcha_mcp.tools import ToolCtx, ToolDef, all_tools, load_all_tool_modules

_LOG = get_logger("server")


def _input_schema_for(model: type[BaseModel]) -> dict[str, Any]:
    schema = model.model_json_schema()
    if schema.get("type") != "object":
        schema = {"type": "object", "properties": {}, "allOf": [schema]}
    return schema


def list_registered_tools() -> list[types.Tool]:
    return [
        types.Tool(
            name=t.name,
            description=t.description,
            inputSchema=_input_schema_for(t.input_schema),
        )
        for t in all_tools()
    ]


async def dispatch_tool_call(
    name: str,
    arguments: dict[str, Any],
    *,
    tools_by_name: dict[str, ToolDef[Any, Any]],
    ctx: ToolCtx,
) -> list[types.ContentBlock]:
    tool = tools_by_name.get(name)
    if tool is None:
        raise ValueError(f"Unknown tool: {name}")

    try:
        validated = tool.input_schema.model_validate(arguments or {})
    except ValidationError as exc:
        return [types.TextContent(type="text", text=f"invalid_argument: {exc}")]

    try:
        result = await tool.handler(validated, ctx)
    except CaptchaValidationError as exc:
        return [types.TextContent(type="text", text=f"invalid_argument: {exc.message}")]
    except CaptchaTimeoutError as exc:
        return [types.TextContent(type="text", text=f"timeout_error: {exc.message}")]
    except CaptchaNetworkError as exc:
        return [types.TextContent(type="text", text=f"network_error: {exc.message}")]
    except CaptchaApiError as exc:
        return [types.TextContent(type="text", text=f"api_error: {exc.message}")]
    except Exception as exc:
        _LOG.exception("Tool %s failed", name)
        return [types.TextContent(type="text", text=f"internal_error: {exc}")]

    payload = result.model_dump(mode="json", by_alias=True, exclude_none=True)
    return [types.TextContent(type="text", text=json.dumps(payload, ensure_ascii=False))]


def build_server(settings: Settings) -> tuple[Server, SolverClient, PingbackClient]:
    """Construct the MCP Server wired to live clients. Caller drives the transport."""
    load_all_tool_modules()
    tools = all_tools()
    _LOG.info("Registering %d tools", len(tools))

    solver = SolverClient(settings)
    pingback = PingbackClient(settings)
    ctx = ToolCtx(solver=solver, pingback=pingback)
    tools_by_name = {t.name: t for t in tools}

    server: Server = Server(name="twocaptcha-mcp", version=__version__)

    @server.list_tools()
    async def _list_tools() -> list[types.Tool]:
        return list_registered_tools()

    @server.call_tool()
    async def _call_tool(name: str, arguments: dict[str, Any]) -> list[types.ContentBlock]:
        return await dispatch_tool_call(name, arguments, tools_by_name=tools_by_name, ctx=ctx)

    return server, solver, pingback
