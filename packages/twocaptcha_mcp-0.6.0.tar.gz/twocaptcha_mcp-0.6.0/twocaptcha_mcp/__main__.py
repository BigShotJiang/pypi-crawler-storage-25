"""Stdio entrypoint: `python -m twocaptcha_mcp`."""

from __future__ import annotations

import asyncio
import contextlib
import sys

from mcp.server.stdio import stdio_server
from pydantic import ValidationError

from twocaptcha_mcp.config import load_settings
from twocaptcha_mcp.logger import get_logger, set_level
from twocaptcha_mcp.server import build_server


async def _run() -> None:
    try:
        settings = load_settings()
    except ValidationError as exc:
        sys.stderr.write(
            "twocaptcha-mcp: configuration error.\n"
            "Set 2Captcha_API_KEY in your environment or in a .env file next to the server.\n"
            f"Details: {exc}\n"
        )
        raise SystemExit(2) from exc

    set_level(settings.twocaptcha_log_level)
    log = get_logger()
    log.info("twocaptcha-mcp starting server=%s", settings.twocaptcha_server)

    server, solver, pingback = build_server(settings)
    try:
        async with stdio_server() as (read_stream, write_stream):
            init_options = server.create_initialization_options()
            await server.run(read_stream, write_stream, init_options)
    finally:
        await solver.aclose()
        await pingback.aclose()


def main() -> None:
    with contextlib.suppress(KeyboardInterrupt):
        asyncio.run(_run())


if __name__ == "__main__":
    main()
