"""Optional webhook receiver — accepts 2Captcha pingback callbacks and stores them in SQLite.

Run as a separate process via `python -m twocaptcha_mcp.webhook_receiver` or the
`twocaptcha-mcp-webhook` console script. The MCP stdio server (`twocaptcha-mcp`)
exposes three tools (`twocaptcha_pingback_events_list/get/clear`) that read from
the same SQLite store.
"""
