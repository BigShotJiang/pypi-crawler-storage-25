"""Optional shared-secret authentication for the 2Captcha pingback endpoint.

2Captcha does NOT cryptographically sign pingback POSTs. Two practical defences:

1. **Shared secret in URL** — register the pingback URL with a long random
   query parameter (e.g. `?secret=<32-byte-hex>`); we verify it matches.
2. **IP allowlist** — outside the scope of this module (nginx / firewall layer).

The shared secret is opt-in. When `TWOCAPTCHA_WEBHOOK_SECRET` is unset we accept
every POST (relying on the unguessable URL itself).
"""

from __future__ import annotations

import hmac
from dataclasses import dataclass


@dataclass(frozen=True)
class VerificationResult:
    valid: bool
    reason: str | None = None


def verify_secret(*, expected: str | None, provided: str | None) -> VerificationResult:
    """Constant-time comparison. Empty `expected` means no auth configured."""
    if not expected:
        return VerificationResult(valid=True)
    if not provided:
        return VerificationResult(valid=False, reason="missing_secret")
    if hmac.compare_digest(expected, provided):
        return VerificationResult(valid=True)
    return VerificationResult(valid=False, reason="bad_secret")
