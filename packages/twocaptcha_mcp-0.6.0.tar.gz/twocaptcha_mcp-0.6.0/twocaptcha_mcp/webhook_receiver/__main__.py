"""CLI entrypoint: `python -m twocaptcha_mcp.webhook_receiver` / `twocaptcha-mcp-webhook`."""

from __future__ import annotations

import argparse
import sys

import uvicorn
from pydantic import ValidationError

from twocaptcha_mcp.config import load_settings
from twocaptcha_mcp.logger import get_logger, set_level
from twocaptcha_mcp.webhook_receiver.server import create_app


def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(prog="twocaptcha-mcp-webhook")
    p.add_argument("--host", default=None, help="Bind host (default 127.0.0.1)")
    p.add_argument("--port", type=int, default=None, help="Bind port (default 8787)")
    p.add_argument(
        "--public-url",
        default=None,
        help="Public URL where 2Captcha will POST callbacks (informational; "
        "register it via twocaptcha_register_pingback)",
    )
    return p.parse_args()


def main() -> None:
    args = _parse_args()
    try:
        settings = load_settings()
    except ValidationError as exc:
        sys.stderr.write(
            "twocaptcha-mcp-webhook: configuration error.\n"
            "Set 2Captcha_API_KEY in your environment or in a .env file.\n"
            f"Details: {exc}\n"
        )
        raise SystemExit(2) from exc

    if args.public_url:
        settings = settings.model_copy(update={"twocaptcha_webhook_public_url": args.public_url})

    set_level(settings.twocaptcha_log_level)
    log = get_logger("webhook")

    app = create_app(settings)
    host = args.host or settings.twocaptcha_webhook_host
    port = args.port or settings.twocaptcha_webhook_port
    log.info(
        "starting webhook receiver on %s:%d (public_url=%s, secret=%s)",
        host,
        port,
        settings.twocaptcha_webhook_public_url or "<none>",
        "set" if settings.twocaptcha_webhook_secret else "unset",
    )
    uvicorn.run(app, host=host, port=port, log_level=settings.twocaptcha_log_level.lower())


if __name__ == "__main__":
    main()
