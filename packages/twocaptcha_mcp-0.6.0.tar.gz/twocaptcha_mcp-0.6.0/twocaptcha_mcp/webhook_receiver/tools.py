"""MCP tools that read events from the local pingback SQLite store.

The webhook receiver process (`twocaptcha-mcp-webhook`) writes; the stdio MCP
server reads through these tools.
"""

from __future__ import annotations

from twocaptcha_mcp.config import load_settings
from twocaptcha_mcp.schemas.webhook import (
    PingbackEvent,
    PingbackEventsClearRequest,
    PingbackEventsClearResponse,
    PingbackEventsGetRequest,
    PingbackEventsGetResponse,
    PingbackEventsListRequest,
    PingbackEventsListResponse,
)
from twocaptcha_mcp.tools.registry import ToolCtx, captcha_tool
from twocaptcha_mcp.webhook_receiver.storage import EventStore, StoredPingback


def _store() -> EventStore:
    return EventStore(load_settings().twocaptcha_webhook_db_path)


def _to_dto(e: StoredPingback) -> PingbackEvent:
    return PingbackEvent(
        captcha_id=e.captcha_id,
        code=e.code,
        received_at=e.received_at,
        raw_body=e.raw_body,
    )


@captcha_tool(
    name="twocaptcha_pingback_events_list",
    description=(
        "List pingback events received by the local webhook receiver "
        "(see twocaptcha-mcp-webhook). Filter by `since_received_at` (Unix sec) "
        "to poll only new events. Returns {events, count}."
    ),
    input_schema=PingbackEventsListRequest,
    output_schema=PingbackEventsListResponse,
)
async def pingback_events_list(
    req: PingbackEventsListRequest, _ctx: ToolCtx
) -> PingbackEventsListResponse:
    events = _store().list(
        since_received_at=req.since_received_at, limit=req.limit, order=req.order
    )
    dtos = [_to_dto(e) for e in events]
    return PingbackEventsListResponse(events=dtos, count=len(dtos))


@captcha_tool(
    name="twocaptcha_pingback_events_get",
    description="Fetch a single pingback event by captcha_id. Returns {event} or {event: null}.",
    input_schema=PingbackEventsGetRequest,
    output_schema=PingbackEventsGetResponse,
)
async def pingback_events_get(
    req: PingbackEventsGetRequest, _ctx: ToolCtx
) -> PingbackEventsGetResponse:
    e = _store().get(req.captcha_id)
    return PingbackEventsGetResponse(event=_to_dto(e) if e else None)


@captcha_tool(
    name="twocaptcha_pingback_events_clear",
    description=(
        "Delete pingback events from the local store. Combine filters or pass {} to wipe all. "
        "Returns {deleted: int}."
    ),
    input_schema=PingbackEventsClearRequest,
    output_schema=PingbackEventsClearResponse,
)
async def pingback_events_clear(
    req: PingbackEventsClearRequest, _ctx: ToolCtx
) -> PingbackEventsClearResponse:
    n = _store().clear(
        before_received_at=req.before_received_at,
        captcha_id=req.captcha_id,
    )
    return PingbackEventsClearResponse(deleted=n)
