"""Starlette HTTP app that receives 2Captcha pingbacks and persists them."""

from __future__ import annotations

from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import JSONResponse
from starlette.routing import Route

from twocaptcha_mcp import __version__
from twocaptcha_mcp.config import Settings
from twocaptcha_mcp.logger import get_logger
from twocaptcha_mcp.webhook_receiver.signature import verify_secret
from twocaptcha_mcp.webhook_receiver.storage import EventStore

_LOG = get_logger("webhook")


def create_app(settings: Settings) -> Starlette:
    """Build the Starlette app. Reads pingback_db_path / pingback_secret from settings."""
    store = EventStore(settings.twocaptcha_webhook_db_path)
    expected_secret = settings.twocaptcha_webhook_secret

    async def health(_: Request) -> JSONResponse:
        return JSONResponse(
            {"ok": True, "service": "twocaptcha-mcp-webhook", "version": __version__}
        )

    async def receive(request: Request) -> JSONResponse:
        # 1. Authenticate (optional shared secret via query param OR header).
        provided = request.query_params.get("secret") or request.headers.get("x-webhook-secret")
        verification = verify_secret(expected=expected_secret, provided=provided)
        if not verification.valid:
            _LOG.warning("Rejected pingback: %s", verification.reason)
            return JSONResponse(
                {"ok": False, "error": "unauthorized", "reason": verification.reason},
                status_code=401,
            )

        # 2. Parse form-encoded body — 2Captcha sends `id=<captchaId>&code=<solution>`.
        try:
            form = await request.form()
        except Exception as exc:
            return JSONResponse(
                {"ok": False, "error": "invalid_form", "detail": str(exc)}, status_code=400
            )
        captcha_id = str(form.get("id") or "").strip()
        code = str(form.get("code") or "").strip()
        if not captcha_id or not code:
            return JSONResponse(
                {"ok": False, "error": "missing_fields", "got": dict(form)}, status_code=400
            )

        raw_body = "&".join(f"{k}={v}" for k, v in form.items())
        inserted = store.insert(captcha_id=captcha_id, code=code, raw_body=raw_body)
        if inserted:
            _LOG.info("stored pingback captcha_id=%s", captcha_id)
        else:
            _LOG.info("duplicate pingback captcha_id=%s (already stored)", captcha_id)
        return JSONResponse({"ok": True, "captcha_id": captcha_id})

    return Starlette(
        routes=[
            Route("/2captcha/pingback", receive, methods=["POST"]),
            Route("/health", health, methods=["GET"]),
        ]
    )
