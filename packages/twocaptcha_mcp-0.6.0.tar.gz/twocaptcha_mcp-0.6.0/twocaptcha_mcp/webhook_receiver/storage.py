"""SQLite-backed storage for received 2Captcha pingback events.

2Captcha posts `id`+`code` form-encoded when a captcha is solved. We store one row
per captcha_id (PRIMARY KEY → idempotent on duplicate POSTs).
"""

from __future__ import annotations

import sqlite3
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

_SCHEMA = """
CREATE TABLE IF NOT EXISTS pingback_events (
    captcha_id  TEXT PRIMARY KEY,
    code        TEXT NOT NULL,
    received_at INTEGER NOT NULL,
    raw_body    TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_pingback_received ON pingback_events(received_at DESC);
"""


@dataclass(frozen=True)
class StoredPingback:
    captcha_id: str
    code: str
    received_at: int
    raw_body: str


class EventStore:
    """Thread-safe SQLite store. Single-writer (webhook process) + many readers (MCP tools)."""

    def __init__(self, db_path: Path) -> None:
        self._path = Path(db_path)
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._connect().executescript(_SCHEMA)

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self._path, isolation_level=None, check_same_thread=False)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA busy_timeout=5000")
        conn.row_factory = sqlite3.Row
        return conn

    def insert(self, *, captcha_id: str, code: str, raw_body: str) -> bool:
        """Insert pingback. Returns False on duplicate captcha_id (idempotent)."""
        payload = (captcha_id, code, int(time.time()), raw_body)
        with self._lock:
            try:
                self._connect().execute(
                    "INSERT INTO pingback_events(captcha_id, code, received_at, raw_body)"
                    " VALUES (?, ?, ?, ?)",
                    payload,
                )
                return True
            except sqlite3.IntegrityError:
                return False

    def get(self, captcha_id: str) -> StoredPingback | None:
        row = (
            self._connect()
            .execute(
                "SELECT captcha_id, code, received_at, raw_body"
                " FROM pingback_events WHERE captcha_id = ?",
                (captcha_id,),
            )
            .fetchone()
        )
        return _row_to_event(row) if row else None

    def list(
        self,
        *,
        since_received_at: int | None = None,
        limit: int = 50,
        order: str = "desc",
    ) -> list[StoredPingback]:
        limit = max(1, min(limit, 500))
        clauses: list[str] = []
        args: list[Any] = []
        if since_received_at is not None:
            clauses.append("received_at > ?")
            args.append(since_received_at)
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        direction = "DESC" if order.lower() == "desc" else "ASC"
        sql = (
            f"SELECT captcha_id, code, received_at, raw_body FROM pingback_events"
            f" {where} ORDER BY received_at {direction}, rowid {direction} LIMIT ?"
        )
        args.append(limit)
        rows = self._connect().execute(sql, args).fetchall()
        return [_row_to_event(r) for r in rows]

    def clear(
        self,
        *,
        before_received_at: int | None = None,
        captcha_id: str | None = None,
    ) -> int:
        clauses: list[str] = []
        args: list[Any] = []
        if before_received_at is not None:
            clauses.append("received_at < ?")
            args.append(before_received_at)
        if captcha_id is not None:
            clauses.append("captcha_id = ?")
            args.append(captcha_id)
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        with self._lock:
            cur = self._connect().execute(f"DELETE FROM pingback_events {where}", args)
            return cur.rowcount or 0


def _row_to_event(row: sqlite3.Row) -> StoredPingback:
    return StoredPingback(
        captcha_id=row["captcha_id"],
        code=row["code"],
        received_at=row["received_at"],
        raw_body=row["raw_body"],
    )
