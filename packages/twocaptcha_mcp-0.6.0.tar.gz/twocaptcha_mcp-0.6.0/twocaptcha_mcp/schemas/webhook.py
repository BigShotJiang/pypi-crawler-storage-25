"""Schemas for the pingback receiver MCP tools."""

from __future__ import annotations

from pydantic import Field

from twocaptcha_mcp.schemas.common import CaptchaModel


class PingbackEvent(CaptchaModel):
    captcha_id: str
    code: str
    received_at: int = Field(description="Unix seconds (when our receiver stored it).")
    raw_body: str = Field(description="Form-encoded payload as received from 2Captcha.")


class PingbackEventsListRequest(CaptchaModel):
    since_received_at: int | None = Field(
        default=None,
        description="Unix seconds. Only events with received_at > this value are returned.",
    )
    limit: int = Field(default=50, ge=1, le=500)
    order: str = Field(default="desc", pattern="^(asc|desc)$")


class PingbackEventsListResponse(CaptchaModel):
    events: list[PingbackEvent]
    count: int


class PingbackEventsGetRequest(CaptchaModel):
    captcha_id: str = Field(min_length=1)


class PingbackEventsGetResponse(CaptchaModel):
    event: PingbackEvent | None = None


class PingbackEventsClearRequest(CaptchaModel):
    before_received_at: int | None = Field(
        default=None, description="Unix seconds. Delete events strictly older than this."
    )
    captcha_id: str | None = Field(
        default=None, description="Delete only this specific captcha_id."
    )


class PingbackEventsClearResponse(CaptchaModel):
    deleted: int
