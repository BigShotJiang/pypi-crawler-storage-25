"""Schemas for pingback CRUD tools."""

from __future__ import annotations

from typing import Literal

from pydantic import HttpUrl

from twocaptcha_mcp.schemas.common import CaptchaModel


class RegisterPingbackRequest(CaptchaModel):
    addr: HttpUrl


class RegisterPingbackResponse(CaptchaModel):
    addr: str


class ListPingbacksRequest(CaptchaModel):
    """Empty."""


class ListPingbacksResponse(CaptchaModel):
    pingbacks: list[str]


class DeletePingbackRequest(CaptchaModel):
    addr: HttpUrl | Literal["all"]


class DeletePingbackResponse(CaptchaModel):
    deleted: int
