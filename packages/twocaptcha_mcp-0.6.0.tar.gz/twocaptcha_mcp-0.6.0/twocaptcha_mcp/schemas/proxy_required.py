"""Schemas for solvers that REQUIRE both `proxy` and `userAgent` (per SDK signatures)."""

from __future__ import annotations

from typing import Any

from pydantic import Field, HttpUrl

from twocaptcha_mcp.schemas.common import ProxyRequiredKwargs


class DatadomeRequest(ProxyRequiredKwargs):
    captcha_url: HttpUrl
    pageurl: HttpUrl

    def to_sdk_call_kwargs(self) -> dict[str, Any]:
        out = self.to_sdk_kwargs()
        out["captcha_url"] = str(self.captcha_url)
        out["pageurl"] = str(self.pageurl)
        return out


class CaptchafoxRequest(ProxyRequiredKwargs):
    sitekey: str = Field(min_length=1)
    pageurl: HttpUrl

    def to_sdk_call_kwargs(self) -> dict[str, Any]:
        out = self.to_sdk_kwargs()
        out["sitekey"] = self.sitekey
        out["pageurl"] = str(self.pageurl)
        return out


class VkcaptchaRequest(ProxyRequiredKwargs):
    redirect_uri: HttpUrl

    def to_sdk_call_kwargs(self) -> dict[str, Any]:
        out = self.to_sdk_kwargs()
        out["redirect_uri"] = str(self.redirect_uri)
        return out
