"""Schemas for GeeTest v3 and v4."""

from __future__ import annotations

from typing import Any

from pydantic import Field, HttpUrl

from twocaptcha_mcp.schemas.common import SolverKwargs


class GeetestRequest(SolverKwargs):
    """GeeTest v3 challenge."""

    gt: str = Field(min_length=1)
    challenge: str = Field(min_length=1)
    url: HttpUrl
    api_server: str | None = Field(default=None, alias="apiServer")
    new_captcha: bool | None = None

    def to_sdk_call_kwargs(self) -> dict[str, Any]:
        out = self.to_sdk_kwargs()
        out["gt"] = self.gt
        out["challenge"] = self.challenge
        out["url"] = str(self.url)
        if self.api_server is not None:
            out["api_server"] = self.api_server
        if self.new_captcha is not None:
            out["new_captcha"] = 1 if self.new_captcha else 0
        return out


class GeetestV4Request(SolverKwargs):
    """GeeTest v4 challenge."""

    captcha_id: str = Field(min_length=1)
    url: HttpUrl

    def to_sdk_call_kwargs(self) -> dict[str, Any]:
        out = self.to_sdk_kwargs()
        out["captcha_id"] = self.captcha_id
        out["url"] = str(self.url)
        return out
