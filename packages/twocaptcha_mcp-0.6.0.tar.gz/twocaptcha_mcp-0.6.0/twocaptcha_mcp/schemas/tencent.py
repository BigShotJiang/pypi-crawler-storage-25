"""Schema for Tencent captcha solver."""

from __future__ import annotations

from typing import Any

from pydantic import Field, HttpUrl

from twocaptcha_mcp.schemas.common import SolverKwargs


class TencentRequest(SolverKwargs):
    app_id: str = Field(min_length=1)
    url: HttpUrl

    def to_sdk_call_kwargs(self) -> dict[str, Any]:
        out = self.to_sdk_kwargs()
        out["app_id"] = self.app_id
        out["url"] = str(self.url)
        return out
