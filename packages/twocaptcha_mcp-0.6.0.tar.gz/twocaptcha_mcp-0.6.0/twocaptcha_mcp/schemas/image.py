"""Schemas for image-based and audio captcha solvers.

Covers SDK methods: normal, text, audio, grid, canvas, coordinates, rotate, vkimage.
"""

from __future__ import annotations

import asyncio
import base64
import os
from typing import Any

from pydantic import Field, model_validator

from twocaptcha_mcp.schemas.common import CaptchaModel, SolverKwargs


class _SingleFileMixin(CaptchaModel):
    """Exactly one of `file_path` (absolute) or `file_base64` is required."""

    file_path: str | None = Field(default=None, description="Absolute path to the file.")
    file_base64: str | None = Field(default=None, description="Raw base64 of the file bytes.")

    @model_validator(mode="after")
    def _exactly_one_file(self) -> _SingleFileMixin:
        a = self.file_path is not None
        b = self.file_base64 is not None
        if a == b:
            raise ValueError("Exactly one of `file_path` or `file_base64` must be set.")
        return self


async def _resolve_file_b64(file_path: str | None, file_base64: str | None) -> str:
    """Return a base64 string the SDK can pass as `file=`."""
    if file_base64 is not None:
        return file_base64
    assert file_path is not None
    if not os.path.isabs(file_path):
        raise ValueError("file_path must be absolute")
    if not os.path.exists(file_path):
        raise ValueError(f"file_path does not exist: {file_path}")

    def _read() -> bytes:
        with open(file_path, "rb") as fh:
            return fh.read()

    data = await asyncio.to_thread(_read)
    return base64.b64encode(data).decode("ascii")


async def _resolve_files_b64(items: list[str]) -> list[str]:
    """Resolve a list of mixed paths/base64 strings into a list of base64 strings."""
    out: list[str] = []
    for item in items:
        if os.path.isabs(item) and os.path.exists(item):

            def _read(p: str = item) -> bytes:
                with open(p, "rb") as fh:
                    return fh.read()

            data = await asyncio.to_thread(_read)
            out.append(base64.b64encode(data).decode("ascii"))
        else:
            out.append(item)
    return out


class NormalRequest(SolverKwargs, _SingleFileMixin):
    phrase: bool | None = None
    case_sensitive: bool | None = Field(default=None, alias="caseSensitive")
    numeric: int | None = Field(default=None, ge=0, le=4)
    calc: bool | None = None
    min_len: int | None = Field(default=None, alias="minLen", ge=1, le=20)
    max_len: int | None = Field(default=None, alias="maxLen", ge=1, le=20)
    img_instructions: str | None = Field(default=None, alias="imgInstructions")
    text_instructions: str | None = Field(default=None, alias="textinstructions")

    async def to_sdk_call_kwargs(self) -> dict[str, Any]:
        kwargs = self.to_sdk_kwargs()
        # Strip our own fields that don't belong in SolverKwargs.to_sdk_kwargs.
        for k in ("file_path", "file_base64"):
            kwargs.pop(k, None)
        kwargs["file"] = await _resolve_file_b64(self.file_path, self.file_base64)
        for fld in (
            "phrase",
            "case_sensitive",
            "numeric",
            "calc",
            "min_len",
            "max_len",
            "img_instructions",
            "text_instructions",
        ):
            value = getattr(self, fld)
            if value is None:
                continue
            kwargs[
                {
                    "case_sensitive": "caseSensitive",
                    "min_len": "minLen",
                    "max_len": "maxLen",
                    "img_instructions": "imgInstructions",
                    "text_instructions": "textinstructions",
                }.get(fld, fld)
            ] = value
        return kwargs


class TextRequest(SolverKwargs):
    text: str = Field(min_length=1)

    def to_sdk_call_kwargs(self) -> dict[str, Any]:
        out = self.to_sdk_kwargs()
        out["text"] = self.text
        return out


class AudioRequest(SolverKwargs, _SingleFileMixin):
    audio_lang: str = Field(min_length=2, description="2-letter language code (e.g. en, ru).")

    async def to_sdk_call_kwargs(self) -> dict[str, Any]:
        out = self.to_sdk_kwargs()
        for k in ("file_path", "file_base64"):
            out.pop(k, None)
        # `audio_lang` is the audio language; `lang` (in SolverKwargs) is the worker language.
        out.pop("audio_lang", None)
        out["file"] = await _resolve_file_b64(self.file_path, self.file_base64)
        # SDK signature: audio(file, lang, **kwargs) — `lang` here is the audio language.
        out["lang"] = self.audio_lang
        return out


class _GridLikeRequest(SolverKwargs, _SingleFileMixin):
    img_instructions: str | None = Field(default=None, alias="imgInstructions")
    text_instructions: str | None = Field(default=None, alias="textinstructions")

    async def _base_kwargs(self) -> dict[str, Any]:
        out = self.to_sdk_kwargs()
        for k in ("file_path", "file_base64", "img_instructions", "text_instructions"):
            out.pop(k, None)
        out["file"] = await _resolve_file_b64(self.file_path, self.file_base64)
        if self.img_instructions is not None:
            out["imgInstructions"] = self.img_instructions
        if self.text_instructions is not None:
            out["textinstructions"] = self.text_instructions
        return out


class GridRequest(_GridLikeRequest):
    rows: int | None = Field(default=None, ge=1, le=10)
    cols: int | None = Field(default=None, ge=1, le=10)
    previous_id: str | None = Field(default=None, alias="previousId")

    async def to_sdk_call_kwargs(self) -> dict[str, Any]:
        out = await self._base_kwargs()
        if self.rows is not None:
            out["rows"] = self.rows
        if self.cols is not None:
            out["cols"] = self.cols
        if self.previous_id is not None:
            out["previousID"] = self.previous_id
        return out


class CanvasRequest(_GridLikeRequest):
    previous_id: str | None = Field(default=None, alias="previousId")

    async def to_sdk_call_kwargs(self) -> dict[str, Any]:
        out = await self._base_kwargs()
        if self.previous_id is not None:
            out["previousID"] = self.previous_id
        return out


class CoordinatesRequest(_GridLikeRequest):
    async def to_sdk_call_kwargs(self) -> dict[str, Any]:
        return await self._base_kwargs()


class RotateRequest(SolverKwargs):
    files: list[str] = Field(min_length=1, max_length=10)
    angle: int | None = Field(default=None, ge=1, le=180)

    async def to_sdk_call_kwargs(self) -> dict[str, Any]:
        out = self.to_sdk_kwargs()
        out.pop("files", None)
        out.pop("angle", None)
        out["files"] = await _resolve_files_b64(self.files)
        if self.angle is not None:
            out["angle"] = self.angle
        return out


class VkimageRequest(SolverKwargs):
    files: list[str] = Field(min_length=1)
    steps: dict[str, str] = Field(description="Per-step instructions, e.g. {'1': 'click cat'}.")

    async def to_sdk_call_kwargs(self) -> dict[str, Any]:
        out = self.to_sdk_kwargs()
        out.pop("files", None)
        out.pop("steps", None)
        out["files"] = await _resolve_files_b64(self.files)
        out["steps"] = self.steps
        return out
