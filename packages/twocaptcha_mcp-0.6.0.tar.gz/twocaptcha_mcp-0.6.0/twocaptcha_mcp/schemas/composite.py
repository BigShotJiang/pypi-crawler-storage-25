"""Schema for the composite `solve_and_wait_pingback` tool."""

from __future__ import annotations

from typing import Any

from pydantic import Field, HttpUrl

from twocaptcha_mcp.schemas.common import CaptchaModel, SolverResult


class SolveAndWaitPingbackRequest(CaptchaModel):
    """Send a captcha via 2Captcha pingback mode and wait for the answer in the local store.

    Replaces blocking polling: the SDK call returns just a `captchaId` and
    2Captcha POSTs the result to our webhook receiver as soon as it is solved.
    The handler then polls the local SQLite store for that captcha_id.

    `params` is forwarded as kwargs to `AsyncTwoCaptcha.send` and must include
    `method` (e.g. "userrecaptcha", "hcaptcha", "turnstile") plus the type-specific
    fields. See 2Captcha docs for the legacy in.php parameter set per method.
    """

    params: dict[str, Any] = Field(
        description="Raw kwargs forwarded to AsyncTwoCaptcha.send (must include `method`).",
    )
    pingback_url: HttpUrl = Field(
        description=(
            "Public URL of the running webhook receiver "
            "(e.g. https://my.domain/2captcha/pingback). Must already be whitelisted "
            "via twocaptcha_register_pingback."
        ),
    )
    timeout: float = Field(
        default=300.0,
        ge=10.0,
        le=1800.0,
        description="Maximum seconds to wait for the pingback (default 5 min).",
    )
    poll_interval: float = Field(
        default=2.0,
        ge=0.5,
        le=30.0,
        description="How often to poll the local SQLite store while waiting.",
    )


class SolveAndWaitPingbackResponse(SolverResult):
    """Same envelope as direct solver tools: {captchaId, code, extra}."""
