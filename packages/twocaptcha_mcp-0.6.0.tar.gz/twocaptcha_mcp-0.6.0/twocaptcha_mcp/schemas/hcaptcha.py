"""Schema for the hCaptcha solver."""

from __future__ import annotations

from typing import Any

from pydantic import Field, HttpUrl

from twocaptcha_mcp.schemas.common import SolverKwargs


class HcaptchaRequest(SolverKwargs):
    sitekey: str = Field(min_length=1)
    url: HttpUrl
    invisible: bool | None = None
    domain: str | None = None
    data: str | None = Field(default=None, description="rqdata payload (hCaptcha Enterprise).")
    enterprise: bool | None = None

    def to_sdk_call_kwargs(self) -> dict[str, Any]:
        out = self.to_sdk_kwargs()
        out["sitekey"] = self.sitekey
        out["url"] = str(self.url)
        if self.invisible is not None:
            out["invisible"] = 1 if self.invisible else 0
        if self.domain is not None:
            out["domain"] = self.domain
        if self.data is not None:
            out["data"] = self.data
        if self.enterprise is not None:
            out["enterprise"] = 1 if self.enterprise else 0
        return out
