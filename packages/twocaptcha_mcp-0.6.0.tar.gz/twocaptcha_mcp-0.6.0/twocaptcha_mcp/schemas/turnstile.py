"""Schema for the Cloudflare Turnstile solver."""

from __future__ import annotations

from typing import Any

from pydantic import Field, HttpUrl

from twocaptcha_mcp.schemas.common import SolverKwargs


class TurnstileRequest(SolverKwargs):
    sitekey: str = Field(min_length=1)
    url: HttpUrl
    action: str | None = None
    data: str | None = Field(
        default=None, description="`cData` for Cloudflare Turnstile Challenge."
    )
    pagedata: str | None = Field(default=None, description="`chlPageData` for Turnstile Challenge.")
    cdata: str | None = None

    def to_sdk_call_kwargs(self) -> dict[str, Any]:
        out = self.to_sdk_kwargs()
        out["sitekey"] = self.sitekey
        out["url"] = str(self.url)
        if self.action is not None:
            out["action"] = self.action
        if self.data is not None:
            out["data"] = self.data
        if self.pagedata is not None:
            out["pagedata"] = self.pagedata
        if self.cdata is not None:
            out["cdata"] = self.cdata
        return out
