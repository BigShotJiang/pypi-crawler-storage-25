"""Schema for the Arkose Labs FunCaptcha solver."""

from __future__ import annotations

from typing import Any

from pydantic import Field, HttpUrl

from twocaptcha_mcp.schemas.common import SolverKwargs


class FuncaptchaRequest(SolverKwargs):
    sitekey: str = Field(min_length=1, description="`publickey` value.")
    url: HttpUrl
    surl: str | None = Field(default=None, description="ApiServer URL (`surl`).")
    data: dict[str, str] | None = Field(
        default=None, description="Additional `data[key]=value` parameters."
    )

    def to_sdk_call_kwargs(self) -> dict[str, Any]:
        out = self.to_sdk_kwargs()
        out["sitekey"] = self.sitekey
        out["url"] = str(self.url)
        if self.surl is not None:
            out["surl"] = self.surl
        if self.data is not None:
            for k, v in self.data.items():
                out[f"data[{k}]"] = v
        return out
