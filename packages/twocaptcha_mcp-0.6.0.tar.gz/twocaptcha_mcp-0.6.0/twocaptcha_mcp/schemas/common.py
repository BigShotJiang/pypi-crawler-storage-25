"""Common pydantic models shared by every solver tool."""

from __future__ import annotations

import re
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, HttpUrl, field_validator

# `[user:pass@]host:port` — host may be IP or DNS, port is required.
_PROXY_URI_RE = re.compile(r"^(?:[^:@/\s]+(?::[^@/\s]+)?@)?[^:/\s]+:\d{1,5}$")


class CaptchaModel(BaseModel):
    """Base for every request/response schema. Strict by default."""

    model_config = ConfigDict(extra="forbid", populate_by_name=True)


class ProxyConfig(CaptchaModel):
    """Represents a 2Captcha SDK proxy kwarg: `{type, uri}`."""

    type: Literal["HTTP", "HTTPS", "SOCKS4", "SOCKS5"]
    uri: str = Field(description="`[user:pass@]host:port`")

    @field_validator("uri")
    @classmethod
    def _validate_uri(cls, v: str) -> str:
        if not _PROXY_URI_RE.match(v):
            raise ValueError("uri must match `[user:pass@]host:port`")
        return v

    def to_sdk(self) -> dict[str, str]:
        return {"type": self.type, "uri": self.uri}


_KWARG_RENAMES: dict[str, str] = {
    "soft_id": "softId",
    "user_agent": "userAgent",
    "header_acao": "header_acao",  # SDK accepts both forms; passthrough.
    # "cookies", "lang", "pingback", "proxy" — verbatim.
}


class SolverKwargs(CaptchaModel):
    """Optional kwargs accepted by the majority of solver methods.

    Methods that mandate proxy/userAgent (datadome, captchafox, vkcaptcha) inherit
    from `ProxyRequiredKwargs` instead — see `schemas/common.py:ProxyRequiredKwargs`.
    """

    proxy: ProxyConfig | None = Field(default=None, description="Optional proxy.")
    pingback: HttpUrl | None = Field(default=None, description="Per-call pingback URL.")
    soft_id: int | None = None
    cookies: str | None = None
    user_agent: str | None = None
    lang: str | None = None
    header_acao: int | None = Field(default=None, ge=0, le=1)

    def to_sdk_kwargs(self) -> dict[str, Any]:
        """Return a dict of non-None kwargs, with names mapped to the SDK form."""
        out: dict[str, Any] = {}
        for field, value in self.__dict__.items():
            if value is None:
                continue
            if field == "proxy" and isinstance(value, ProxyConfig):
                out["proxy"] = value.to_sdk()
                continue
            if field == "pingback":
                out["pingback"] = str(value)
                continue
            target = _KWARG_RENAMES.get(field, field)
            out[target] = value
        return out


class ProxyRequiredKwargs(CaptchaModel):
    """Variant of SolverKwargs where `proxy` and `user_agent` are required.

    Used by `datadome`, `captchafox`, `vkcaptcha` — these SDK methods reject the
    request without a proxy.
    """

    proxy: ProxyConfig
    user_agent: str = Field(min_length=1)
    pingback: HttpUrl | None = None
    soft_id: int | None = None
    cookies: str | None = None
    lang: str | None = None
    header_acao: int | None = Field(default=None, ge=0, le=1)

    def to_sdk_kwargs(self) -> dict[str, Any]:
        out: dict[str, Any] = {
            "proxy": self.proxy.to_sdk(),
            "userAgent": self.user_agent,
        }
        if self.pingback is not None:
            out["pingback"] = str(self.pingback)
        if self.soft_id is not None:
            out["softId"] = self.soft_id
        if self.cookies is not None:
            out["cookies"] = self.cookies
        if self.lang is not None:
            out["lang"] = self.lang
        if self.header_acao is not None:
            out["header_acao"] = self.header_acao
        return out


class SolverResult(CaptchaModel):
    """Standard response envelope returned by every solver tool."""

    captcha_id: str = Field(alias="captchaId")
    code: str
    extra: dict[str, Any] | None = None

    @classmethod
    def from_sdk(cls, payload: dict[str, Any]) -> SolverResult:
        captcha_id = str(payload.get("captchaId", payload.get("captcha_id", "")))
        code = str(payload.get("code", ""))
        # Anything beyond captchaId/code goes into extra (extendedResponse=True case).
        extra = {
            k: v for k, v in payload.items() if k not in {"captchaId", "captcha_id", "code"}
        } or None
        return cls.model_validate({"captchaId": captcha_id, "code": code, "extra": extra})


class Empty(CaptchaModel):
    """Empty response body for tools that return nothing meaningful (report, delete)."""
