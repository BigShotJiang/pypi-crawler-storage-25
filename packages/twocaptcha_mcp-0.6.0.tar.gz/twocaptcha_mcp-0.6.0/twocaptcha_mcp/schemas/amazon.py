"""Schema for Amazon WAF captcha solver."""

from __future__ import annotations

from typing import Any

from pydantic import Field, HttpUrl

from twocaptcha_mcp.schemas.common import SolverKwargs


class AmazonWafRequest(SolverKwargs):
    sitekey: str = Field(min_length=1)
    iv: str = Field(min_length=1)
    context: str = Field(min_length=1)
    url: HttpUrl
    challenge_script: str | None = None
    captcha_script: str | None = None

    def to_sdk_call_kwargs(self) -> dict[str, Any]:
        out = self.to_sdk_kwargs()
        out["sitekey"] = self.sitekey
        out["iv"] = self.iv
        out["context"] = self.context
        out["url"] = str(self.url)
        if self.challenge_script is not None:
            out["challenge_script"] = self.challenge_script
        if self.captcha_script is not None:
            out["captcha_script"] = self.captcha_script
        return out
