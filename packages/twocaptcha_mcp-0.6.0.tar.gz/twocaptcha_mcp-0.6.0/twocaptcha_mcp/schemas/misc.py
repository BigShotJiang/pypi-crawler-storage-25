"""Schemas for the remaining solvers: prosopo, temu, altcha, cybersiara, yandex_smart."""

from __future__ import annotations

from typing import Any

from pydantic import Field, HttpUrl

from twocaptcha_mcp.schemas.common import SolverKwargs


class ProsopoRequest(SolverKwargs):
    sitekey: str = Field(min_length=1)
    pageurl: HttpUrl

    def to_sdk_call_kwargs(self) -> dict[str, Any]:
        out = self.to_sdk_kwargs()
        out["sitekey"] = self.sitekey
        out["pageurl"] = str(self.pageurl)
        return out


class TemuRequest(SolverKwargs):
    body: str = Field(min_length=1)
    part1: str = Field(min_length=1)
    part2: str = Field(min_length=1)
    part3: str = Field(min_length=1)

    def to_sdk_call_kwargs(self) -> dict[str, Any]:
        out = self.to_sdk_kwargs()
        out["body"] = self.body
        out["part1"] = self.part1
        out["part2"] = self.part2
        out["part3"] = self.part3
        return out


class AltchaRequest(SolverKwargs):
    pageurl: HttpUrl

    def to_sdk_call_kwargs(self) -> dict[str, Any]:
        out = self.to_sdk_kwargs()
        out["pageurl"] = str(self.pageurl)
        return out


class CybersiaraRequest(SolverKwargs):
    master_url_id: str = Field(min_length=1)
    pageurl: HttpUrl
    cyber_user_agent: str = Field(
        min_length=1, description="User-Agent (required by SDK signature)."
    )

    def to_sdk_call_kwargs(self) -> dict[str, Any]:
        out = self.to_sdk_kwargs()
        out["master_url_id"] = self.master_url_id
        out["pageurl"] = str(self.pageurl)
        # SDK uses `userAgent` keyword; SolverKwargs already maps `user_agent` → `userAgent`,
        # but cybersiara mandates it, so we route via a dedicated field to keep the contract
        # explicit.
        out["userAgent"] = self.cyber_user_agent
        return out


class YandexSmartRequest(SolverKwargs):
    sitekey: str = Field(min_length=1)
    url: HttpUrl

    def to_sdk_call_kwargs(self) -> dict[str, Any]:
        out = self.to_sdk_kwargs()
        out["sitekey"] = self.sitekey
        out["url"] = str(self.url)
        return out
