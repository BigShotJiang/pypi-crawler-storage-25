"""Schemas for token-based captcha types: capy, keycaptcha, lemin, mtcaptcha, friendly, cutcaptcha."""

from __future__ import annotations

from typing import Any

from pydantic import Field, HttpUrl

from twocaptcha_mcp.schemas.common import SolverKwargs


class CapyRequest(SolverKwargs):
    sitekey: str = Field(min_length=1)
    url: HttpUrl
    api_server: str | None = None

    def to_sdk_call_kwargs(self) -> dict[str, Any]:
        out = self.to_sdk_kwargs()
        out["sitekey"] = self.sitekey
        out["url"] = str(self.url)
        if self.api_server is not None:
            out["api_server"] = self.api_server
        return out


class KeycaptchaRequest(SolverKwargs):
    s_s_c_user_id: str = Field(min_length=1)
    s_s_c_session_id: str = Field(min_length=1)
    s_s_c_web_server_sign: str = Field(min_length=1)
    s_s_c_web_server_sign2: str = Field(min_length=1)
    url: HttpUrl

    def to_sdk_call_kwargs(self) -> dict[str, Any]:
        out = self.to_sdk_kwargs()
        out["s_s_c_user_id"] = self.s_s_c_user_id
        out["s_s_c_session_id"] = self.s_s_c_session_id
        out["s_s_c_web_server_sign"] = self.s_s_c_web_server_sign
        out["s_s_c_web_server_sign2"] = self.s_s_c_web_server_sign2
        out["url"] = str(self.url)
        return out


class LeminRequest(SolverKwargs):
    captcha_id: str = Field(min_length=1)
    div_id: str = Field(min_length=1)
    url: HttpUrl
    api_server: str | None = None

    def to_sdk_call_kwargs(self) -> dict[str, Any]:
        out = self.to_sdk_kwargs()
        out["captcha_id"] = self.captcha_id
        out["div_id"] = self.div_id
        out["url"] = str(self.url)
        if self.api_server is not None:
            out["api_server"] = self.api_server
        return out


class MtcaptchaRequest(SolverKwargs):
    sitekey: str = Field(min_length=1)
    url: HttpUrl

    def to_sdk_call_kwargs(self) -> dict[str, Any]:
        out = self.to_sdk_kwargs()
        out["sitekey"] = self.sitekey
        out["url"] = str(self.url)
        return out


class FriendlyCaptchaRequest(SolverKwargs):
    sitekey: str = Field(min_length=1)
    url: HttpUrl

    def to_sdk_call_kwargs(self) -> dict[str, Any]:
        out = self.to_sdk_kwargs()
        out["sitekey"] = self.sitekey
        out["url"] = str(self.url)
        return out


class CutcaptchaRequest(SolverKwargs):
    misery_key: str = Field(min_length=1)
    apikey: str = Field(min_length=1)
    url: HttpUrl

    def to_sdk_call_kwargs(self) -> dict[str, Any]:
        out = self.to_sdk_kwargs()
        out["misery_key"] = self.misery_key
        out["apikey"] = self.apikey
        out["url"] = str(self.url)
        return out
