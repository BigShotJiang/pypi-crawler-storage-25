"""Schema for the reCAPTCHA tool (handles v2 / v3 / Enterprise via parameters)."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import Field, HttpUrl

from twocaptcha_mcp.schemas.common import SolverKwargs


class RecaptchaRequest(SolverKwargs):
    sitekey: str = Field(min_length=1)
    url: HttpUrl
    version: Literal["v2", "v3"] = "v2"
    enterprise: bool = False
    invisible: bool | None = None
    data_s: str | None = Field(default=None, alias="data-s")
    action: str | None = Field(default=None, description="reCAPTCHA v3 action.")
    min_score: float | None = Field(default=None, ge=0.0, le=1.0)
    domain: str | None = None

    def to_sdk_call_kwargs(self) -> dict[str, Any]:
        out = self.to_sdk_kwargs()
        out["sitekey"] = self.sitekey
        out["url"] = str(self.url)
        out["version"] = self.version
        out["enterprise"] = 1 if self.enterprise else 0
        if self.invisible is not None:
            out["invisible"] = 1 if self.invisible else 0
        if self.data_s is not None:
            out["data-s"] = self.data_s
        if self.action is not None:
            out["action"] = self.action
        if self.min_score is not None:
            out["min_score"] = self.min_score
        if self.domain is not None:
            out["domain"] = self.domain
        return out
