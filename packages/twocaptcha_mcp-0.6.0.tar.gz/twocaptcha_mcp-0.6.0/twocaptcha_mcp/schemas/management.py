"""Schemas for management tools: balance, report, get_result, send_raw."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import Field

from twocaptcha_mcp.schemas.common import CaptchaModel


class BalanceRequest(CaptchaModel):
    """Empty input."""


class BalanceResponse(CaptchaModel):
    balance: float
    currency: Literal["USD"] = "USD"


class ReportRequest(CaptchaModel):
    captcha_id: str = Field(min_length=1)


class ReportResponse(CaptchaModel):
    captcha_id: str
    correct: bool


class GetResultRequest(CaptchaModel):
    captcha_id: str = Field(min_length=1)


class GetResultResponse(CaptchaModel):
    captcha_id: str
    code: str


class SendRawRequest(CaptchaModel):
    """Escape hatch for SDK methods this server doesn't expose explicitly."""

    params: dict[str, Any] = Field(
        description="Raw kwargs forwarded to AsyncTwoCaptcha.send (e.g. {method: 'userrecaptcha', ...})."
    )
    file_base64: str | None = Field(
        default=None, description="Optional base64 file body (for image-based methods)."
    )


class SendRawResponse(CaptchaModel):
    captcha_id: str
