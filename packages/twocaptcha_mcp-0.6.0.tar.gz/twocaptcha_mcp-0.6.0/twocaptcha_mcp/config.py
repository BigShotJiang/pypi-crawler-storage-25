"""Runtime configuration loaded from environment and .env file."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Literal

from pydantic import AliasChoices, Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


def _default_webhook_db_path() -> Path:
    """Per-platform default for the SQLite store backing the webhook receiver."""
    if os.name == "nt":
        base = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
    else:
        base = os.environ.get("XDG_DATA_HOME") or str(Path.home() / ".local" / "share")
    return Path(base) / "twocaptcha-mcp" / "pingback.db"


_ALLOWED_LOG_LEVELS = frozenset({"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"})


class Settings(BaseSettings):
    """Process configuration. process.env wins over .env (pydantic-settings default)."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    twocaptcha_api_key: str = Field(
        ...,
        validation_alias=AliasChoices(
            "2Captcha_API_KEY",
            "TWOCAPTCHA_API_KEY",
            "2CAPTCHA_API_KEY",
            "API_KEY_2CAPTCHA",
            "twocaptcha_api_key",
        ),
        description="2Captcha account API key (https://2captcha.com/setting).",
    )
    twocaptcha_server: Literal["2captcha.com", "rucaptcha.com"] = Field(
        default="2captcha.com",
        validation_alias=AliasChoices("TWOCAPTCHA_SERVER", "twocaptcha_server"),
    )
    twocaptcha_default_timeout: float = Field(
        default=120.0,
        ge=1.0,
        le=600.0,
        validation_alias=AliasChoices("TWOCAPTCHA_DEFAULT_TIMEOUT", "twocaptcha_default_timeout"),
    )
    twocaptcha_recaptcha_timeout: float = Field(
        default=600.0,
        ge=1.0,
        le=1200.0,
        validation_alias=AliasChoices(
            "TWOCAPTCHA_RECAPTCHA_TIMEOUT", "twocaptcha_recaptcha_timeout"
        ),
    )
    twocaptcha_polling_interval: float = Field(
        default=10.0,
        ge=1.0,
        le=120.0,
        validation_alias=AliasChoices("TWOCAPTCHA_POLLING_INTERVAL", "twocaptcha_polling_interval"),
    )
    twocaptcha_soft_id: int = Field(
        default=4580,
        validation_alias=AliasChoices("TWOCAPTCHA_SOFT_ID", "twocaptcha_soft_id"),
    )
    twocaptcha_log_level: str = Field(
        default="INFO",
        validation_alias=AliasChoices("TWOCAPTCHA_LOG_LEVEL", "twocaptcha_log_level"),
    )
    twocaptcha_default_callback: str | None = Field(
        default=None,
        validation_alias=AliasChoices("TWOCAPTCHA_DEFAULT_CALLBACK", "twocaptcha_default_callback"),
    )

    # ---- webhook receiver ----
    twocaptcha_webhook_host: str = Field(
        default="127.0.0.1",
        validation_alias=AliasChoices("TWOCAPTCHA_WEBHOOK_HOST", "twocaptcha_webhook_host"),
    )
    twocaptcha_webhook_port: int = Field(
        default=8787,
        ge=1,
        le=65535,
        validation_alias=AliasChoices("TWOCAPTCHA_WEBHOOK_PORT", "twocaptcha_webhook_port"),
    )
    twocaptcha_webhook_db_path: Path = Field(
        default_factory=_default_webhook_db_path,
        validation_alias=AliasChoices("TWOCAPTCHA_WEBHOOK_DB_PATH", "twocaptcha_webhook_db_path"),
    )
    twocaptcha_webhook_public_url: str | None = Field(
        default=None,
        validation_alias=AliasChoices(
            "TWOCAPTCHA_WEBHOOK_PUBLIC_URL", "twocaptcha_webhook_public_url"
        ),
    )
    twocaptcha_webhook_secret: str | None = Field(
        default=None,
        validation_alias=AliasChoices("TWOCAPTCHA_WEBHOOK_SECRET", "twocaptcha_webhook_secret"),
    )

    # ---- rate limiter ----
    twocaptcha_rate_limit_per_minute: int = Field(
        default=100,
        ge=1,
        le=10_000,
        validation_alias=AliasChoices(
            "TWOCAPTCHA_RATE_LIMIT_PER_MINUTE", "twocaptcha_rate_limit_per_minute"
        ),
    )

    @field_validator("twocaptcha_log_level")
    @classmethod
    def _normalize_log_level(cls, v: str) -> str:
        upper = v.upper()
        if upper not in _ALLOWED_LOG_LEVELS:
            raise ValueError(
                f"twocaptcha_log_level must be one of {sorted(_ALLOWED_LOG_LEVELS)}, got {v!r}"
            )
        return upper


def load_settings() -> Settings:
    """Load settings. Raises pydantic.ValidationError if API key is missing."""
    return Settings()
