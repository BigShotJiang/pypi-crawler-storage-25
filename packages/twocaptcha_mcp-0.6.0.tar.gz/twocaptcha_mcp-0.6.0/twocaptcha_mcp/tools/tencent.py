"""Tencent captcha solver tool."""

from __future__ import annotations

from twocaptcha_mcp.schemas.common import SolverResult
from twocaptcha_mcp.schemas.tencent import TencentRequest
from twocaptcha_mcp.tools.registry import ToolCtx, captcha_tool


@captcha_tool(
    name="twocaptcha_solve_tencent",
    description="Solve Tencent captcha. Required: `app_id`, `url`. Returns {captchaId, code}.",
    input_schema=TencentRequest,
    output_schema=SolverResult,
)
async def solve_tencent(req: TencentRequest, ctx: ToolCtx) -> SolverResult:
    payload = await ctx.solver.call("tencent", **req.to_sdk_call_kwargs())
    return SolverResult.from_sdk(payload)
