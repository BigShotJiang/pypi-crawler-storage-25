"""hCaptcha solver tool."""

from __future__ import annotations

from twocaptcha_mcp.schemas.common import SolverResult
from twocaptcha_mcp.schemas.hcaptcha import HcaptchaRequest
from twocaptcha_mcp.tools.registry import ToolCtx, captcha_tool


@captcha_tool(
    name="twocaptcha_solve_hcaptcha",
    description=(
        "Solve hCaptcha. Required: `sitekey`, `url`. Optional: invisible, domain, "
        "data (rqdata payload for Enterprise), enterprise. Returns {captchaId, code} where "
        "`code` is the h-captcha-response token."
    ),
    input_schema=HcaptchaRequest,
    output_schema=SolverResult,
)
async def solve_hcaptcha(req: HcaptchaRequest, ctx: ToolCtx) -> SolverResult:
    payload = await ctx.solver.call("hcaptcha", **req.to_sdk_call_kwargs())
    return SolverResult.from_sdk(payload)
