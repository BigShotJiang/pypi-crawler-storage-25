"""Misc solvers: prosopo, temu, altcha, cybersiara, yandex_smart."""

from __future__ import annotations

from twocaptcha_mcp.schemas.common import SolverResult
from twocaptcha_mcp.schemas.misc import (
    AltchaRequest,
    CybersiaraRequest,
    ProsopoRequest,
    TemuRequest,
    YandexSmartRequest,
)
from twocaptcha_mcp.tools.registry import ToolCtx, captcha_tool


@captcha_tool(
    name="twocaptcha_solve_prosopo",
    description="Solve Prosopo Procaptcha. Required: `sitekey`, `pageurl`. Returns {captchaId, code}.",
    input_schema=ProsopoRequest,
    output_schema=SolverResult,
)
async def solve_prosopo(req: ProsopoRequest, ctx: ToolCtx) -> SolverResult:
    payload = await ctx.solver.call("prosopo", **req.to_sdk_call_kwargs())
    return SolverResult.from_sdk(payload)


@captcha_tool(
    name="twocaptcha_solve_temu",
    description=(
        "Solve Temu captcha. All of `body`, `part1`, `part2`, `part3` are required. "
        "Returns {captchaId, code}."
    ),
    input_schema=TemuRequest,
    output_schema=SolverResult,
)
async def solve_temu(req: TemuRequest, ctx: ToolCtx) -> SolverResult:
    payload = await ctx.solver.call("temu", **req.to_sdk_call_kwargs())
    return SolverResult.from_sdk(payload)


@captcha_tool(
    name="twocaptcha_solve_altcha",
    description="Solve Altcha. Required: `pageurl`. Returns {captchaId, code}.",
    input_schema=AltchaRequest,
    output_schema=SolverResult,
)
async def solve_altcha(req: AltchaRequest, ctx: ToolCtx) -> SolverResult:
    payload = await ctx.solver.call("altcha", **req.to_sdk_call_kwargs())
    return SolverResult.from_sdk(payload)


@captcha_tool(
    name="twocaptcha_solve_cybersiara",
    description=(
        "Solve CyberSiARA. Required: `master_url_id`, `pageurl`, `cyber_user_agent` "
        "(passed to SDK as userAgent). Returns {captchaId, code}."
    ),
    input_schema=CybersiaraRequest,
    output_schema=SolverResult,
)
async def solve_cybersiara(req: CybersiaraRequest, ctx: ToolCtx) -> SolverResult:
    payload = await ctx.solver.call("cybersiara", **req.to_sdk_call_kwargs())
    return SolverResult.from_sdk(payload)


@captcha_tool(
    name="twocaptcha_solve_yandex_smart",
    description="Solve Yandex SmartCaptcha. Required: `sitekey`, `url`. Returns {captchaId, code}.",
    input_schema=YandexSmartRequest,
    output_schema=SolverResult,
)
async def solve_yandex_smart(req: YandexSmartRequest, ctx: ToolCtx) -> SolverResult:
    payload = await ctx.solver.call("yandex_smart", **req.to_sdk_call_kwargs())
    return SolverResult.from_sdk(payload)
