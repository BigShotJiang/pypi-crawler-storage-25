"""Solvers that REQUIRE proxy + userAgent: datadome, captchafox, vkcaptcha."""

from __future__ import annotations

from twocaptcha_mcp.schemas.common import SolverResult
from twocaptcha_mcp.schemas.proxy_required import (
    CaptchafoxRequest,
    DatadomeRequest,
    VkcaptchaRequest,
)
from twocaptcha_mcp.tools.registry import ToolCtx, captcha_tool


@captcha_tool(
    name="twocaptcha_solve_datadome",
    description=(
        "Solve DataDome anti-bot captcha. ALL of `proxy`, `user_agent`, `captcha_url`, "
        "`pageurl` are REQUIRED — the SDK rejects requests without a residential proxy. "
        "Returns {captchaId, code}."
    ),
    input_schema=DatadomeRequest,
    output_schema=SolverResult,
)
async def solve_datadome(req: DatadomeRequest, ctx: ToolCtx) -> SolverResult:
    payload = await ctx.solver.call("datadome", **req.to_sdk_call_kwargs())
    return SolverResult.from_sdk(payload)


@captcha_tool(
    name="twocaptcha_solve_captchafox",
    description=(
        "Solve CaptchaFox. `proxy`, `user_agent`, `sitekey`, `pageurl` are REQUIRED. "
        "Returns {captchaId, code}."
    ),
    input_schema=CaptchafoxRequest,
    output_schema=SolverResult,
)
async def solve_captchafox(req: CaptchafoxRequest, ctx: ToolCtx) -> SolverResult:
    payload = await ctx.solver.call("captchafox", **req.to_sdk_call_kwargs())
    return SolverResult.from_sdk(payload)


@captcha_tool(
    name="twocaptcha_solve_vkcaptcha",
    description=(
        "Solve VK login captcha. `proxy`, `user_agent`, `redirect_uri` are REQUIRED. "
        "Returns {captchaId, code}."
    ),
    input_schema=VkcaptchaRequest,
    output_schema=SolverResult,
)
async def solve_vkcaptcha(req: VkcaptchaRequest, ctx: ToolCtx) -> SolverResult:
    payload = await ctx.solver.call("vkcaptcha", **req.to_sdk_call_kwargs())
    return SolverResult.from_sdk(payload)
