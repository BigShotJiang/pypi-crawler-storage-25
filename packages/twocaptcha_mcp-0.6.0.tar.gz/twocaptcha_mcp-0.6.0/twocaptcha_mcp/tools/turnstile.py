"""Cloudflare Turnstile solver tool."""

from __future__ import annotations

from twocaptcha_mcp.schemas.common import SolverResult
from twocaptcha_mcp.schemas.turnstile import TurnstileRequest
from twocaptcha_mcp.tools.registry import ToolCtx, captcha_tool


@captcha_tool(
    name="twocaptcha_solve_turnstile",
    description=(
        "Solve Cloudflare Turnstile. Required: `sitekey`, `url`. For Cloudflare Challenge "
        "page (full anti-bot): pass `data`, `pagedata`, `action`. Returns {captchaId, code} "
        "where `code` is the cf-turnstile-response token."
    ),
    input_schema=TurnstileRequest,
    output_schema=SolverResult,
)
async def solve_turnstile(req: TurnstileRequest, ctx: ToolCtx) -> SolverResult:
    payload = await ctx.solver.call("turnstile", **req.to_sdk_call_kwargs())
    return SolverResult.from_sdk(payload)
