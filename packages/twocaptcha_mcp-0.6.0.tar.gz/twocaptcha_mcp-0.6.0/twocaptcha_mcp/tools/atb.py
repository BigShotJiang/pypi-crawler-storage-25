"""atbCAPTCHA solver tool."""

from __future__ import annotations

from twocaptcha_mcp.schemas.atb import AtbCaptchaRequest
from twocaptcha_mcp.schemas.common import SolverResult
from twocaptcha_mcp.tools.registry import ToolCtx, captcha_tool


@captcha_tool(
    name="twocaptcha_solve_atb_captcha",
    description="Solve atbCAPTCHA. Required: `app_id`, `api_server`, `url`. Returns {captchaId, code}.",
    input_schema=AtbCaptchaRequest,
    output_schema=SolverResult,
)
async def solve_atb_captcha(req: AtbCaptchaRequest, ctx: ToolCtx) -> SolverResult:
    payload = await ctx.solver.call("atb_captcha", **req.to_sdk_call_kwargs())
    return SolverResult.from_sdk(payload)
