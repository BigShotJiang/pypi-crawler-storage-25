"""Composite tool: send a captcha with pingback mode and wait for the local store."""

from __future__ import annotations

import asyncio
import time

from twocaptcha_mcp.client.errors import CaptchaTimeoutError
from twocaptcha_mcp.config import load_settings
from twocaptcha_mcp.schemas.common import SolverResult
from twocaptcha_mcp.schemas.composite import (
    SolveAndWaitPingbackRequest,
    SolveAndWaitPingbackResponse,
)
from twocaptcha_mcp.tools.registry import ToolCtx, captcha_tool
from twocaptcha_mcp.webhook_receiver.storage import EventStore


def _store() -> EventStore:
    """Return an EventStore pointing at the configured DB.

    Indirected through a function so tests can monkeypatch this single seam.
    """
    return EventStore(load_settings().twocaptcha_webhook_db_path)


@captcha_tool(
    name="twocaptcha_solve_and_wait_pingback",
    description=(
        "Solve any captcha in pingback mode and wait for the result via the local "
        "webhook receiver — no SDK polling, no blocking on the upstream API. "
        "Required: `params` (kwargs for AsyncTwoCaptcha.send incl. `method`), "
        "`pingback_url` (already whitelisted via twocaptcha_register_pingback). "
        "Optional: `timeout` (default 300 s), `poll_interval` (default 2 s). "
        "Returns {captchaId, code} just like the direct solver tools."
    ),
    input_schema=SolveAndWaitPingbackRequest,
    output_schema=SolveAndWaitPingbackResponse,
)
async def solve_and_wait_pingback(
    req: SolveAndWaitPingbackRequest, ctx: ToolCtx
) -> SolveAndWaitPingbackResponse:
    send_kwargs = dict(req.params)
    send_kwargs.setdefault("pingback", str(req.pingback_url))

    captcha_id = await ctx.solver.send_raw(**send_kwargs)

    deadline = time.monotonic() + req.timeout
    store = _store()
    while time.monotonic() < deadline:
        event = store.get(captcha_id)
        if event is not None:
            payload = {"captchaId": captcha_id, "code": event.code}
            return SolveAndWaitPingbackResponse(
                **SolverResult.from_sdk(payload).model_dump(by_alias=True)
            )
        await asyncio.sleep(req.poll_interval)

    raise CaptchaTimeoutError(
        f"timed out after {req.timeout}s waiting for pingback of captcha_id={captcha_id}"
    )
