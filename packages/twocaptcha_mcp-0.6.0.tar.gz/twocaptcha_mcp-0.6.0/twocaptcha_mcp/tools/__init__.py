"""Tool registration package. Importing `load_all_tool_modules()` triggers @captcha_tool."""

from twocaptcha_mcp.tools.registry import (
    ToolCtx,
    ToolDef,
    all_tools,
    captcha_tool,
    clear_registry,
)

__all__ = [
    "ToolCtx",
    "ToolDef",
    "all_tools",
    "captcha_tool",
    "clear_registry",
    "load_all_tool_modules",
]


def load_all_tool_modules() -> None:
    """Import every tool module so @captcha_tool decorators fire."""
    from twocaptcha_mcp.tools import (  # noqa: F401
        amazon,
        atb,
        composite,
        funcaptcha,
        geetest,
        hcaptcha,
        image,
        management,
        misc,
        pingback,
        proxy_required,
        recaptcha,
        tencent,
        tokens,
        turnstile,
    )
    from twocaptcha_mcp.webhook_receiver import tools as _webhook_tools  # noqa: F401
