"""Image / audio / grid / vkimage solver tools."""

from __future__ import annotations

from twocaptcha_mcp.schemas.common import SolverResult
from twocaptcha_mcp.schemas.image import (
    AudioRequest,
    CanvasRequest,
    CoordinatesRequest,
    GridRequest,
    NormalRequest,
    RotateRequest,
    TextRequest,
    VkimageRequest,
)
from twocaptcha_mcp.tools.registry import ToolCtx, captcha_tool


@captcha_tool(
    name="twocaptcha_solve_normal",
    description=(
        "Solve a classic image captcha. Provide either `file_path` (absolute) or "
        "`file_base64`. Optional knobs: phrase, caseSensitive, numeric (0..4), calc, "
        "minLen, maxLen, imgInstructions, textinstructions. Returns {captchaId, code}."
    ),
    input_schema=NormalRequest,
    output_schema=SolverResult,
)
async def solve_normal(req: NormalRequest, ctx: ToolCtx) -> SolverResult:
    payload = await ctx.solver.call("normal", **(await req.to_sdk_call_kwargs()))
    return SolverResult.from_sdk(payload)


@captcha_tool(
    name="twocaptcha_solve_text",
    description="Solve a text-based captcha (CAPTCHA question in plain English). Returns {captchaId, code}.",
    input_schema=TextRequest,
    output_schema=SolverResult,
)
async def solve_text(req: TextRequest, ctx: ToolCtx) -> SolverResult:
    payload = await ctx.solver.call("text", **req.to_sdk_call_kwargs())
    return SolverResult.from_sdk(payload)


@captcha_tool(
    name="twocaptcha_solve_audio",
    description=(
        "Solve an audio captcha. Provide either `file_path` (absolute, mp3/wav) or "
        "`file_base64`. `audio_lang` is the spoken language (en/ru/de/...). "
        "Returns {captchaId, code}."
    ),
    input_schema=AudioRequest,
    output_schema=SolverResult,
)
async def solve_audio(req: AudioRequest, ctx: ToolCtx) -> SolverResult:
    payload = await ctx.solver.call("audio", **(await req.to_sdk_call_kwargs()))
    return SolverResult.from_sdk(payload)


@captcha_tool(
    name="twocaptcha_solve_grid",
    description=(
        "Solve a grid (cell-selection) captcha. Provide image via `file_path` or "
        "`file_base64`, plus optional rows/cols/imgInstructions/textinstructions. "
        "Returns {captchaId, code} where `code` is a comma-separated list of cell numbers."
    ),
    input_schema=GridRequest,
    output_schema=SolverResult,
)
async def solve_grid(req: GridRequest, ctx: ToolCtx) -> SolverResult:
    payload = await ctx.solver.call("grid", **(await req.to_sdk_call_kwargs()))
    return SolverResult.from_sdk(payload)


@captcha_tool(
    name="twocaptcha_solve_canvas",
    description=(
        "Solve a draw-around captcha (canvas). Worker draws a path; the response is the "
        "list of (x,y) points as JSON. Returns {captchaId, code}."
    ),
    input_schema=CanvasRequest,
    output_schema=SolverResult,
)
async def solve_canvas(req: CanvasRequest, ctx: ToolCtx) -> SolverResult:
    payload = await ctx.solver.call("canvas", **(await req.to_sdk_call_kwargs()))
    return SolverResult.from_sdk(payload)


@captcha_tool(
    name="twocaptcha_solve_coordinates",
    description=(
        "Solve a click-coordinates captcha (clickcaptcha). Returns {captchaId, code} where "
        "`code` is a coordinate list."
    ),
    input_schema=CoordinatesRequest,
    output_schema=SolverResult,
)
async def solve_coordinates(req: CoordinatesRequest, ctx: ToolCtx) -> SolverResult:
    payload = await ctx.solver.call("coordinates", **(await req.to_sdk_call_kwargs()))
    return SolverResult.from_sdk(payload)


@captcha_tool(
    name="twocaptcha_solve_rotate",
    description=(
        "Solve a rotate captcha. Provide a list of `files` (paths or base64). "
        "Optional `angle` is the rotation step. Returns {captchaId, code}."
    ),
    input_schema=RotateRequest,
    output_schema=SolverResult,
)
async def solve_rotate(req: RotateRequest, ctx: ToolCtx) -> SolverResult:
    payload = await ctx.solver.call("rotate", **(await req.to_sdk_call_kwargs()))
    return SolverResult.from_sdk(payload)


@captcha_tool(
    name="twocaptcha_solve_vkimage",
    description=(
        "Solve a VK image captcha (multi-step). `files` is a list of paths/base64; "
        "`steps` is a dict like {'1': 'click bird', '2': 'click car'}. Returns {captchaId, code}."
    ),
    input_schema=VkimageRequest,
    output_schema=SolverResult,
)
async def solve_vkimage(req: VkimageRequest, ctx: ToolCtx) -> SolverResult:
    payload = await ctx.solver.call("vkimage", **(await req.to_sdk_call_kwargs()))
    return SolverResult.from_sdk(payload)
