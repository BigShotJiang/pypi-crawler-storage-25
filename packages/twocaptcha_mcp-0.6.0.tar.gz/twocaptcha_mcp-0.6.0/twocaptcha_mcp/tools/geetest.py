"""GeeTest v3 + v4 solver tools."""

from __future__ import annotations

from twocaptcha_mcp.schemas.common import SolverResult
from twocaptcha_mcp.schemas.geetest import GeetestRequest, GeetestV4Request
from twocaptcha_mcp.tools.registry import ToolCtx, captcha_tool


@captcha_tool(
    name="twocaptcha_solve_geetest",
    description=(
        "Solve GeeTest v3. Required: `gt`, `challenge`, `url`. Optional `apiServer`, "
        "`new_captcha`. Returns {captchaId, code} where `code` is a JSON object with "
        "challenge/validate/seccode."
    ),
    input_schema=GeetestRequest,
    output_schema=SolverResult,
)
async def solve_geetest(req: GeetestRequest, ctx: ToolCtx) -> SolverResult:
    payload = await ctx.solver.call("geetest", **req.to_sdk_call_kwargs())
    return SolverResult.from_sdk(payload)


@captcha_tool(
    name="twocaptcha_solve_geetest_v4",
    description=(
        "Solve GeeTest v4. Required: `captcha_id`, `url`. Returns {captchaId, code} where "
        "`code` is a JSON object with the v4 token payload."
    ),
    input_schema=GeetestV4Request,
    output_schema=SolverResult,
)
async def solve_geetest_v4(req: GeetestV4Request, ctx: ToolCtx) -> SolverResult:
    payload = await ctx.solver.call("geetest_v4", **req.to_sdk_call_kwargs())
    return SolverResult.from_sdk(payload)
