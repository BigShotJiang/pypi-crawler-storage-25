"""Token-based solvers: capy, keycaptcha, lemin, mtcaptcha, friendly, cutcaptcha."""

from __future__ import annotations

from twocaptcha_mcp.schemas.common import SolverResult
from twocaptcha_mcp.schemas.tokens import (
    CapyRequest,
    CutcaptchaRequest,
    FriendlyCaptchaRequest,
    KeycaptchaRequest,
    LeminRequest,
    MtcaptchaRequest,
)
from twocaptcha_mcp.tools.registry import ToolCtx, captcha_tool


@captcha_tool(
    name="twocaptcha_solve_capy",
    description="Solve Capy Puzzle. Required: `sitekey`, `url`. Optional `api_server`. Returns {captchaId, code}.",
    input_schema=CapyRequest,
    output_schema=SolverResult,
)
async def solve_capy(req: CapyRequest, ctx: ToolCtx) -> SolverResult:
    payload = await ctx.solver.call("capy", **req.to_sdk_call_kwargs())
    return SolverResult.from_sdk(payload)


@captcha_tool(
    name="twocaptcha_solve_keycaptcha",
    description=(
        "Solve KeyCaptcha. Required: `s_s_c_user_id`, `s_s_c_session_id`, "
        "`s_s_c_web_server_sign`, `s_s_c_web_server_sign2`, `url`. Returns {captchaId, code}."
    ),
    input_schema=KeycaptchaRequest,
    output_schema=SolverResult,
)
async def solve_keycaptcha(req: KeycaptchaRequest, ctx: ToolCtx) -> SolverResult:
    payload = await ctx.solver.call("keycaptcha", **req.to_sdk_call_kwargs())
    return SolverResult.from_sdk(payload)


@captcha_tool(
    name="twocaptcha_solve_lemin",
    description=(
        "Solve Lemin captcha. Required: `captcha_id`, `div_id`, `url`. Optional `api_server`. "
        "Returns {captchaId, code}."
    ),
    input_schema=LeminRequest,
    output_schema=SolverResult,
)
async def solve_lemin(req: LeminRequest, ctx: ToolCtx) -> SolverResult:
    payload = await ctx.solver.call("lemin", **req.to_sdk_call_kwargs())
    return SolverResult.from_sdk(payload)


@captcha_tool(
    name="twocaptcha_solve_mtcaptcha",
    description="Solve MTCaptcha. Required: `sitekey`, `url`. Returns {captchaId, code}.",
    input_schema=MtcaptchaRequest,
    output_schema=SolverResult,
)
async def solve_mtcaptcha(req: MtcaptchaRequest, ctx: ToolCtx) -> SolverResult:
    payload = await ctx.solver.call("mtcaptcha", **req.to_sdk_call_kwargs())
    return SolverResult.from_sdk(payload)


@captcha_tool(
    name="twocaptcha_solve_friendly_captcha",
    description="Solve Friendly Captcha. Required: `sitekey`, `url`. Returns {captchaId, code}.",
    input_schema=FriendlyCaptchaRequest,
    output_schema=SolverResult,
)
async def solve_friendly_captcha(req: FriendlyCaptchaRequest, ctx: ToolCtx) -> SolverResult:
    payload = await ctx.solver.call("friendly_captcha", **req.to_sdk_call_kwargs())
    return SolverResult.from_sdk(payload)


@captcha_tool(
    name="twocaptcha_solve_cutcaptcha",
    description="Solve CutCaptcha. Required: `misery_key`, `apikey`, `url`. Returns {captchaId, code}.",
    input_schema=CutcaptchaRequest,
    output_schema=SolverResult,
)
async def solve_cutcaptcha(req: CutcaptchaRequest, ctx: ToolCtx) -> SolverResult:
    payload = await ctx.solver.call("cutcaptcha", **req.to_sdk_call_kwargs())
    return SolverResult.from_sdk(payload)
