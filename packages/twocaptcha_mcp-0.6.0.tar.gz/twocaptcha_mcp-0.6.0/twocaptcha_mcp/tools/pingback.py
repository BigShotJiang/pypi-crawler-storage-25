"""Pingback CRUD tools."""

from __future__ import annotations

from twocaptcha_mcp.schemas.pingback import (
    DeletePingbackRequest,
    DeletePingbackResponse,
    ListPingbacksRequest,
    ListPingbacksResponse,
    RegisterPingbackRequest,
    RegisterPingbackResponse,
)
from twocaptcha_mcp.tools.registry import ToolCtx, captcha_tool


@captcha_tool(
    name="twocaptcha_register_pingback",
    description=(
        "Whitelist a callback URL so 2Captcha can send pingback notifications to it. "
        "The URL must be publicly reachable. After registration the address can be passed "
        "as `pingback` to any solver tool, or set as the global default via "
        "TWOCAPTCHA_DEFAULT_CALLBACK."
    ),
    input_schema=RegisterPingbackRequest,
    output_schema=RegisterPingbackResponse,
)
async def register_pingback(req: RegisterPingbackRequest, ctx: ToolCtx) -> RegisterPingbackResponse:
    addr = await ctx.pingback.add(str(req.addr))
    return RegisterPingbackResponse(addr=addr)


@captcha_tool(
    name="twocaptcha_list_pingbacks",
    description="List every currently-whitelisted pingback URL.",
    input_schema=ListPingbacksRequest,
    output_schema=ListPingbacksResponse,
)
async def list_pingbacks(_: ListPingbacksRequest, ctx: ToolCtx) -> ListPingbacksResponse:
    addrs = await ctx.pingback.list()
    return ListPingbacksResponse(pingbacks=addrs)


@captcha_tool(
    name="twocaptcha_delete_pingback",
    description=(
        "Delete a single pingback URL or ALL of them (`addr='all'`). "
        "Returns the number of removed addresses."
    ),
    input_schema=DeletePingbackRequest,
    output_schema=DeletePingbackResponse,
)
async def delete_pingback(req: DeletePingbackRequest, ctx: ToolCtx) -> DeletePingbackResponse:
    addr: str = "all" if req.addr == "all" else str(req.addr)
    removed = await ctx.pingback.delete(addr)
    return DeletePingbackResponse(deleted=removed)
