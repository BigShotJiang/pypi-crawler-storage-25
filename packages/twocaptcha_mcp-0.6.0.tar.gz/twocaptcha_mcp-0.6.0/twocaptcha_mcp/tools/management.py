"""Management tools: balance, report_good, report_bad, get_result, send_raw."""

from __future__ import annotations

from twocaptcha_mcp.schemas.management import (
    BalanceRequest,
    BalanceResponse,
    GetResultRequest,
    GetResultResponse,
    ReportRequest,
    ReportResponse,
    SendRawRequest,
    SendRawResponse,
)
from twocaptcha_mcp.tools.registry import ToolCtx, captcha_tool


@captcha_tool(
    name="twocaptcha_balance",
    description="Return the current 2Captcha account balance in USD.",
    input_schema=BalanceRequest,
    output_schema=BalanceResponse,
)
async def balance(_: BalanceRequest, ctx: ToolCtx) -> BalanceResponse:
    value = await ctx.solver.balance()
    return BalanceResponse(balance=value)


@captcha_tool(
    name="twocaptcha_report_good",
    description=(
        "Report a captchaId as CORRECT (will refund the user partially if the worker was wrong). "
        "Must be called within 15 minutes of solving."
    ),
    input_schema=ReportRequest,
    output_schema=ReportResponse,
)
async def report_good(req: ReportRequest, ctx: ToolCtx) -> ReportResponse:
    await ctx.solver.report(req.captcha_id, correct=True)
    return ReportResponse(captcha_id=req.captcha_id, correct=True)


@captcha_tool(
    name="twocaptcha_report_bad",
    description=("Report a captchaId as INCORRECT. Must be called within 15 minutes of solving."),
    input_schema=ReportRequest,
    output_schema=ReportResponse,
)
async def report_bad(req: ReportRequest, ctx: ToolCtx) -> ReportResponse:
    await ctx.solver.report(req.captcha_id, correct=False)
    return ReportResponse(captcha_id=req.captcha_id, correct=False)


@captcha_tool(
    name="twocaptcha_get_result",
    description=(
        "Manually fetch the solution for a captchaId previously created via twocaptcha_send_raw."
    ),
    input_schema=GetResultRequest,
    output_schema=GetResultResponse,
)
async def get_result(req: GetResultRequest, ctx: ToolCtx) -> GetResultResponse:
    code = await ctx.solver.get_result(req.captcha_id)
    return GetResultResponse(captcha_id=req.captcha_id, code=code)


@captcha_tool(
    name="twocaptcha_send_raw",
    description=(
        "Escape-hatch: forward arbitrary kwargs to AsyncTwoCaptcha.send and return the captchaId. "
        "Use this for captcha types not yet exposed as their own tool. Pair with "
        "twocaptcha_get_result to fetch the solution."
    ),
    input_schema=SendRawRequest,
    output_schema=SendRawResponse,
)
async def send_raw(req: SendRawRequest, ctx: ToolCtx) -> SendRawResponse:
    kwargs = dict(req.params)
    if req.file_base64 is not None:
        kwargs["body"] = req.file_base64
    captcha_id = await ctx.solver.send_raw(**kwargs)
    return SendRawResponse(captcha_id=captcha_id)
