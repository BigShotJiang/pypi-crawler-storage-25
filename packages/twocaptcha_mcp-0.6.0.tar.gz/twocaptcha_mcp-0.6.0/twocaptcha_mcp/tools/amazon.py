"""Amazon WAF captcha solver tool."""

from __future__ import annotations

from twocaptcha_mcp.schemas.amazon import AmazonWafRequest
from twocaptcha_mcp.schemas.common import SolverResult
from twocaptcha_mcp.tools.registry import ToolCtx, captcha_tool


@captcha_tool(
    name="twocaptcha_solve_amazon_waf",
    description=(
        "Solve Amazon WAF captcha (AWS WAF Bot Control challenge). "
        "Required: `sitekey`, `iv`, `context`, `url`. "
        "Optional `challenge_script`, `captcha_script`. Returns {captchaId, code}."
    ),
    input_schema=AmazonWafRequest,
    output_schema=SolverResult,
)
async def solve_amazon_waf(req: AmazonWafRequest, ctx: ToolCtx) -> SolverResult:
    payload = await ctx.solver.call("amazon_waf", **req.to_sdk_call_kwargs())
    return SolverResult.from_sdk(payload)
