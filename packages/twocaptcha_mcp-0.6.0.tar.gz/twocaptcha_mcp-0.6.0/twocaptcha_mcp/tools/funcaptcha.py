"""Arkose Labs FunCaptcha solver tool."""

from __future__ import annotations

from twocaptcha_mcp.schemas.common import SolverResult
from twocaptcha_mcp.schemas.funcaptcha import FuncaptchaRequest
from twocaptcha_mcp.tools.registry import ToolCtx, captcha_tool


@captcha_tool(
    name="twocaptcha_solve_funcaptcha",
    description=(
        "Solve Arkose Labs FunCaptcha (RotateCaptcha). Required: `sitekey`, `url`. "
        "Optional `surl` (ApiServer override) and `data` for `data[key]=value` query "
        "parameters. Returns {captchaId, code}."
    ),
    input_schema=FuncaptchaRequest,
    output_schema=SolverResult,
)
async def solve_funcaptcha(req: FuncaptchaRequest, ctx: ToolCtx) -> SolverResult:
    payload = await ctx.solver.call("funcaptcha", **req.to_sdk_call_kwargs())
    return SolverResult.from_sdk(payload)
