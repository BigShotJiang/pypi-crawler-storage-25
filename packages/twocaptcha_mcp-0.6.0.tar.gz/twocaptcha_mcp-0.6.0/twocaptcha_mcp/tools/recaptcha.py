"""reCAPTCHA solver tool (v2 / v3 / Enterprise)."""

from __future__ import annotations

from twocaptcha_mcp.schemas.common import SolverResult
from twocaptcha_mcp.schemas.recaptcha import RecaptchaRequest
from twocaptcha_mcp.tools.registry import ToolCtx, captcha_tool


@captcha_tool(
    name="twocaptcha_solve_recaptcha",
    description=(
        "Solve Google reCAPTCHA v2 / v3 / Enterprise. Required: `sitekey`, `url`. "
        "Use version='v3' + action + min_score for reCAPTCHA v3. Set enterprise=true "
        "for the Enterprise variant. Optional invisible, data-s (Google `data-s`), domain. "
        "Returns {captchaId, code} where `code` is the g-recaptcha-response token."
    ),
    input_schema=RecaptchaRequest,
    output_schema=SolverResult,
)
async def solve_recaptcha(req: RecaptchaRequest, ctx: ToolCtx) -> SolverResult:
    payload = await ctx.solver.call("recaptcha", **req.to_sdk_call_kwargs())
    return SolverResult.from_sdk(payload)
