"""2Captcha MCP server — exposes the full 2Captcha API surface to Claude Code."""

from __future__ import annotations

__version__ = "0.6.0"
__all__ = ["__version__"]
