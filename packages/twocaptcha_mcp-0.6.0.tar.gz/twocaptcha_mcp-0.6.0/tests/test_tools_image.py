"""Tests for image-based solver tools."""

from __future__ import annotations

import base64
from pathlib import Path
from unittest.mock import AsyncMock

import pytest
from pydantic import ValidationError

from twocaptcha_mcp.schemas.image import (
    AudioRequest,
    NormalRequest,
    RotateRequest,
    TextRequest,
    VkimageRequest,
)
from twocaptcha_mcp.tools.image import (
    solve_audio,
    solve_normal,
    solve_rotate,
    solve_text,
    solve_vkimage,
)
from twocaptcha_mcp.tools.registry import ToolCtx


@pytest.fixture
def ctx() -> ToolCtx:
    solver = AsyncMock()
    solver.call = AsyncMock(return_value={"captchaId": "1", "code": "ok"})
    return ToolCtx(solver=solver, pingback=None)  # type: ignore[arg-type]


def test_normal_requires_exactly_one_file() -> None:
    with pytest.raises(ValidationError):
        NormalRequest()
    with pytest.raises(ValidationError):
        NormalRequest(file_path="/a", file_base64="ZGF0YQ==")


async def test_normal_uses_base64_directly(ctx: ToolCtx) -> None:
    req = NormalRequest(file_base64="ZGF0YQ==")
    await solve_normal(req, ctx)
    kwargs = ctx.solver.call.await_args.kwargs  # type: ignore[attr-defined]
    assert kwargs["file"] == "ZGF0YQ=="


async def test_normal_reads_file_path_to_base64(ctx: ToolCtx, tmp_path: Path) -> None:
    p = tmp_path / "img.bin"
    p.write_bytes(b"hello")
    req = NormalRequest(file_path=str(p))
    await solve_normal(req, ctx)
    kwargs = ctx.solver.call.await_args.kwargs  # type: ignore[attr-defined]
    assert kwargs["file"] == base64.b64encode(b"hello").decode()


async def test_normal_rejects_relative_path(ctx: ToolCtx) -> None:
    req = NormalRequest(file_path="relative/path.png")
    with pytest.raises(ValueError, match="absolute"):
        await solve_normal(req, ctx)


async def test_normal_rejects_missing_file(ctx: ToolCtx, tmp_path: Path) -> None:
    req = NormalRequest(file_path=str(tmp_path / "nope.png"))
    with pytest.raises(ValueError, match="does not exist"):
        await solve_normal(req, ctx)


async def test_text_passes_text(ctx: ToolCtx) -> None:
    await solve_text(TextRequest(text="What colour is the sun?"), ctx)
    kwargs = ctx.solver.call.await_args.kwargs  # type: ignore[attr-defined]
    assert kwargs["text"] == "What colour is the sun?"


async def test_audio_uses_audio_lang(ctx: ToolCtx) -> None:
    req = AudioRequest(file_base64="ZA==", audio_lang="en")
    await solve_audio(req, ctx)
    kwargs = ctx.solver.call.await_args.kwargs  # type: ignore[attr-defined]
    assert kwargs["lang"] == "en"
    assert kwargs["file"] == "ZA=="


async def test_audio_audio_lang_is_required() -> None:
    with pytest.raises(ValidationError):
        AudioRequest(file_base64="ZA==")


async def test_rotate_resolves_each_file(ctx: ToolCtx, tmp_path: Path) -> None:
    a = tmp_path / "a.png"
    a.write_bytes(b"xx")
    req = RotateRequest(files=[str(a), "b64string"])
    await solve_rotate(req, ctx)
    kwargs = ctx.solver.call.await_args.kwargs  # type: ignore[attr-defined]
    assert kwargs["files"][0] == base64.b64encode(b"xx").decode()
    assert kwargs["files"][1] == "b64string"


async def test_vkimage_passes_steps(ctx: ToolCtx) -> None:
    req = VkimageRequest(files=["b64a", "b64b"], steps={"1": "click cat"})
    await solve_vkimage(req, ctx)
    kwargs = ctx.solver.call.await_args.kwargs  # type: ignore[attr-defined]
    assert kwargs["files"] == ["b64a", "b64b"]
    assert kwargs["steps"] == {"1": "click cat"}
