"""Unit tests for the SQLite-backed pingback EventStore."""

from __future__ import annotations

import time
from pathlib import Path

import pytest

from twocaptcha_mcp.webhook_receiver.storage import EventStore


@pytest.fixture
def store(tmp_path: Path) -> EventStore:
    return EventStore(tmp_path / "pingback.db")


def test_insert_then_get(store: EventStore) -> None:
    assert store.insert(captcha_id="cid-1", code="abc123", raw_body="id=cid-1&code=abc123") is True
    e = store.get("cid-1")
    assert e is not None
    assert e.captcha_id == "cid-1"
    assert e.code == "abc123"
    assert e.raw_body == "id=cid-1&code=abc123"
    assert int(time.time()) - e.received_at <= 5


def test_duplicate_insert_is_idempotent(store: EventStore) -> None:
    assert store.insert(captcha_id="dup", code="first", raw_body="id=dup&code=first") is True
    assert store.insert(captcha_id="dup", code="second", raw_body="id=dup&code=second") is False
    e = store.get("dup")
    assert e is not None and e.code == "first", "first write must win"


def test_get_missing_returns_none(store: EventStore) -> None:
    assert store.get("never-stored") is None


def test_list_default_order_desc(store: EventStore) -> None:
    for cid in ("a", "b", "c"):
        store.insert(captcha_id=cid, code=cid * 3, raw_body=f"id={cid}&code={cid * 3}")
        time.sleep(0.01)
    out = store.list(limit=10)
    assert next(e.captcha_id for e in out) == "c", "newest first by default"


def test_list_filter_since(store: EventStore) -> None:
    store.insert(captcha_id="old", code="x", raw_body="id=old&code=x")
    cutoff = int(time.time())
    time.sleep(1.1)
    store.insert(captcha_id="new", code="y", raw_body="id=new&code=y")
    out = store.list(since_received_at=cutoff)
    assert [e.captcha_id for e in out] == ["new"]


def test_clear_with_filter(store: EventStore) -> None:
    for cid in ("k", "m", "n"):
        store.insert(captcha_id=cid, code=cid, raw_body=f"id={cid}&code={cid}")
    deleted = store.clear(captcha_id="m")
    assert deleted == 1
    assert store.get("m") is None
    assert store.get("k") is not None
    assert store.get("n") is not None


def test_clear_all(store: EventStore) -> None:
    for cid in ("p", "q"):
        store.insert(captcha_id=cid, code=cid, raw_body=f"id={cid}")
    assert store.clear() == 2
    assert store.list() == []


def test_clear_with_both_filters(store: EventStore) -> None:
    """before_received_at + captcha_id together — combined WHERE clause."""
    store.insert(captcha_id="match", code="x", raw_body="id=match")
    cutoff = int(time.time()) + 100  # generous cutoff so the event qualifies
    deleted = store.clear(before_received_at=cutoff, captcha_id="match")
    assert deleted == 1


def test_list_with_order_asc(store: EventStore) -> None:
    for cid in ("a", "b", "c"):
        store.insert(captcha_id=cid, code=cid, raw_body=f"id={cid}")
        time.sleep(0.005)
    out = store.list(limit=10, order="asc")
    assert next(e.captcha_id for e in out) == "a", "oldest first when order=asc"


def test_list_clamps_limit_above_500(store: EventStore) -> None:
    """Defence-in-depth: limit caps at 500 even if caller passes 99999."""
    out = store.list(limit=99_999)
    assert len(out) == 0  # empty store, just verifies no crash from invalid limit
