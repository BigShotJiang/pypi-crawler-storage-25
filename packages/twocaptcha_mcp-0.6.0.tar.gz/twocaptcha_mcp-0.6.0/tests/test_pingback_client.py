"""Tests for twocaptcha_mcp.client.pingback — respx mocks res.php."""

from __future__ import annotations

import httpx
import pytest
import respx

from twocaptcha_mcp.client.errors import CaptchaApiError, CaptchaNetworkError
from twocaptcha_mcp.client.pingback import PingbackClient
from twocaptcha_mcp.config import Settings


def _settings() -> Settings:
    return Settings.model_construct(
        twocaptcha_api_key="K",
        twocaptcha_server="2captcha.com",
        twocaptcha_default_timeout=30.0,
        twocaptcha_recaptcha_timeout=600.0,
        twocaptcha_polling_interval=10.0,
        twocaptcha_soft_id=4580,
        twocaptcha_log_level="INFO",
        twocaptcha_default_callback=None,
    )


@pytest.fixture
async def client():  # type: ignore[no-untyped-def]
    c = PingbackClient(_settings())
    try:
        yield c
    finally:
        await c.aclose()


@respx.mock
async def test_add_pingback_ok(client: PingbackClient) -> None:
    route = respx.get("https://2captcha.com/res.php").mock(
        return_value=httpx.Response(200, text="OK_https://example.com/cb")
    )
    out = await client.add("https://example.com/cb")
    assert out == "https://example.com/cb"
    assert route.called
    request = route.calls.last.request
    assert "action=add_pingback" in request.url.query.decode()
    assert "key=K" in request.url.query.decode()


@respx.mock
async def test_add_pingback_bare_ok_returns_input(client: PingbackClient) -> None:
    respx.get("https://2captcha.com/res.php").mock(return_value=httpx.Response(200, text="OK"))
    out = await client.add("https://example.com/cb")
    assert out == "https://example.com/cb"


@respx.mock
async def test_add_pingback_error_raises(client: PingbackClient) -> None:
    respx.get("https://2captcha.com/res.php").mock(
        return_value=httpx.Response(200, text="ERROR_PINGBACK_NOT_ALLOWED")
    )
    with pytest.raises(CaptchaApiError) as ei:
        await client.add("https://example.com/cb")
    assert "ERROR_PINGBACK_NOT_ALLOWED" in str(ei.value)


@respx.mock
async def test_list_pingbacks_three(client: PingbackClient) -> None:
    respx.get("https://2captcha.com/res.php").mock(
        return_value=httpx.Response(200, text="OK|a.com|b.com|c.com")
    )
    out = await client.list()
    assert out == ["a.com", "b.com", "c.com"]


@respx.mock
async def test_list_pingbacks_empty(client: PingbackClient) -> None:
    respx.get("https://2captcha.com/res.php").mock(return_value=httpx.Response(200, text="OK"))
    assert await client.list() == []


@respx.mock
async def test_delete_one_returns_diff(client: PingbackClient) -> None:
    responses = iter(
        [
            httpx.Response(200, text="OK|a.com|b.com"),  # before list
            httpx.Response(200, text="OK_a.com"),  # delete
            httpx.Response(200, text="OK|b.com"),  # after list
        ]
    )
    respx.get("https://2captcha.com/res.php").mock(side_effect=lambda _request: next(responses))
    assert await client.delete("a.com") == 1


@respx.mock
async def test_delete_all_uses_before_count(client: PingbackClient) -> None:
    responses = iter(
        [
            httpx.Response(200, text="OK|x.com|y.com|z.com"),
            httpx.Response(200, text="OK"),
        ]
    )
    respx.get("https://2captcha.com/res.php").mock(side_effect=lambda _request: next(responses))
    assert await client.delete("all") == 3


@respx.mock
async def test_network_error_wrapped(client: PingbackClient) -> None:
    respx.get("https://2captcha.com/res.php").mock(side_effect=httpx.ConnectError("nope"))
    with pytest.raises(CaptchaNetworkError):
        await client.list()


@respx.mock
async def test_5xx_wrapped_as_api_error(client: PingbackClient) -> None:
    respx.get("https://2captcha.com/res.php").mock(return_value=httpx.Response(503, text="boom"))
    with pytest.raises(CaptchaApiError):
        await client.list()
