"""Snapshot test for the public MCP tool surface."""

from __future__ import annotations

import hashlib
import json

from twocaptcha_mcp.tools import all_tools, load_all_tool_modules

# When you intentionally add/rename/remove a tool, update this constant by running
# the test once with the assertion stripped, copying the actual hash, and checking
# the rendered list in the failure message.
EXPECTED_TOOL_COUNT = 43


def _registry_signature() -> tuple[str, list[str]]:
    """Return (sha256, sorted tool name list) for stability checks."""
    items = []
    for tool in all_tools():
        fields = sorted(tool.input_schema.model_fields.keys())
        items.append({"name": tool.name, "fields": fields})
    payload = json.dumps(items, sort_keys=True).encode("utf-8")
    return hashlib.sha256(payload).hexdigest(), [t.name for t in all_tools()]


def test_tool_count_is_stable() -> None:
    load_all_tool_modules()
    _, names = _registry_signature()
    assert len(names) == EXPECTED_TOOL_COUNT, "\n".join(names)


def test_required_tools_present() -> None:
    load_all_tool_modules()
    _, names = _registry_signature()
    required = {
        # Image-based
        "twocaptcha_solve_normal",
        "twocaptcha_solve_text",
        "twocaptcha_solve_audio",
        "twocaptcha_solve_grid",
        "twocaptcha_solve_canvas",
        "twocaptcha_solve_coordinates",
        "twocaptcha_solve_rotate",
        "twocaptcha_solve_vkimage",
        # Token-based
        "twocaptcha_solve_recaptcha",
        "twocaptcha_solve_hcaptcha",
        "twocaptcha_solve_turnstile",
        "twocaptcha_solve_funcaptcha",
        "twocaptcha_solve_geetest",
        "twocaptcha_solve_geetest_v4",
        "twocaptcha_solve_capy",
        "twocaptcha_solve_keycaptcha",
        "twocaptcha_solve_lemin",
        "twocaptcha_solve_mtcaptcha",
        "twocaptcha_solve_friendly_captcha",
        "twocaptcha_solve_cutcaptcha",
        "twocaptcha_solve_amazon_waf",
        "twocaptcha_solve_tencent",
        "twocaptcha_solve_atb_captcha",
        # Proxy-required
        "twocaptcha_solve_datadome",
        "twocaptcha_solve_captchafox",
        "twocaptcha_solve_vkcaptcha",
        # Misc
        "twocaptcha_solve_prosopo",
        "twocaptcha_solve_temu",
        "twocaptcha_solve_altcha",
        "twocaptcha_solve_cybersiara",
        "twocaptcha_solve_yandex_smart",
        # Management
        "twocaptcha_balance",
        "twocaptcha_report_good",
        "twocaptcha_report_bad",
        "twocaptcha_get_result",
        "twocaptcha_send_raw",
        # Pingback CRUD (URL whitelist)
        "twocaptcha_register_pingback",
        "twocaptcha_list_pingbacks",
        "twocaptcha_delete_pingback",
        # Pingback receiver (event store)
        "twocaptcha_pingback_events_list",
        "twocaptcha_pingback_events_get",
        "twocaptcha_pingback_events_clear",
        # Composite (non-blocking solve via pingback)
        "twocaptcha_solve_and_wait_pingback",
    }
    missing = required - set(names)
    extra = set(names) - required
    assert not missing, f"missing tools: {sorted(missing)}"
    assert not extra, f"unexpected tools: {sorted(extra)}"


def test_signature_is_deterministic() -> None:
    load_all_tool_modules()
    sig1, _ = _registry_signature()
    sig2, _ = _registry_signature()
    assert sig1 == sig2
