"""Tests for twocaptcha_mcp.client.solver — exception mapping + kwargs flow."""

from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock

import pytest
from twocaptcha import (  # type: ignore[import-not-found]
    ApiException,
    NetworkException,
    TimeoutException,
    ValidationException,
)

from twocaptcha_mcp.client.errors import (
    CaptchaApiError,
    CaptchaNetworkError,
    CaptchaTimeoutError,
    CaptchaValidationError,
)
from twocaptcha_mcp.client.solver import SolverClient
from twocaptcha_mcp.config import Settings


def _settings() -> Settings:
    return Settings.model_construct(
        twocaptcha_api_key="k",
        twocaptcha_server="2captcha.com",
        twocaptcha_default_timeout=120.0,
        twocaptcha_recaptcha_timeout=600.0,
        twocaptcha_polling_interval=10.0,
        twocaptcha_soft_id=4580,
        twocaptcha_log_level="INFO",
        twocaptcha_default_callback=None,
    )


@pytest.fixture
def client(monkeypatch: pytest.MonkeyPatch) -> SolverClient:
    """Build SolverClient with a stub AsyncTwoCaptcha that records calls."""

    _ALLOWED = {
        "recaptcha",
        "hcaptcha",
        "turnstile",
        "balance",
        "report",
        "send",
        "get_result",
    }

    class _StubImpl:
        def __init__(self, **_: Any) -> None:
            self.api_client = AsyncMock()
            self.last_call: tuple[str, dict[str, Any]] | None = None

        def __getattr__(self, name: str) -> Any:
            if name not in _ALLOWED:
                raise AttributeError(name)

            async def _method(**kwargs: Any) -> dict[str, Any]:
                self.last_call = (name, kwargs)
                return {"captchaId": "1", "code": "ok"}

            return _method

    monkeypatch.setattr("twocaptcha_mcp.client.solver.AsyncTwoCaptcha", _StubImpl)
    return SolverClient(_settings())


async def test_call_returns_dict(client: SolverClient) -> None:
    out = await client.call("recaptcha", sitekey="k", url="https://example.com")
    assert out == {"captchaId": "1", "code": "ok"}


async def test_call_passes_kwargs_unmodified(client: SolverClient) -> None:
    await client.call(
        "recaptcha",
        sitekey="key",
        url="https://example.com",
        proxy={"type": "HTTPS", "uri": "u:p@h:1"},
        pingback="https://cb",
    )
    name, kwargs = client._impl.last_call  # type: ignore[attr-defined]
    assert name == "recaptcha"
    assert kwargs["proxy"] == {"type": "HTTPS", "uri": "u:p@h:1"}
    assert kwargs["pingback"] == "https://cb"


async def test_unknown_method_raises_validation(client: SolverClient) -> None:
    with pytest.raises(CaptchaValidationError):
        await client.call("not_a_real_method", a=1)


@pytest.mark.parametrize(
    "sdk_exc, mapped",
    [
        (ValidationException("bad"), CaptchaValidationError),
        (NetworkException("net"), CaptchaNetworkError),
        (TimeoutException("slow"), CaptchaTimeoutError),
        (ApiException("api"), CaptchaApiError),
    ],
)
async def test_exception_mapping(
    monkeypatch: pytest.MonkeyPatch,
    sdk_exc: Exception,
    mapped: type[Exception],
) -> None:
    class _ExplodingImpl:
        def __init__(self, **_: Any) -> None:
            self.api_client = None

        async def recaptcha(self, **kwargs: Any) -> dict[str, Any]:
            raise sdk_exc

        async def balance(self) -> float:
            raise sdk_exc

        async def report(self, *_: Any, **__: Any) -> None:
            raise sdk_exc

        async def send(self, **_: Any) -> str:
            raise sdk_exc

        async def get_result(self, *_: Any) -> str:
            raise sdk_exc

    monkeypatch.setattr("twocaptcha_mcp.client.solver.AsyncTwoCaptcha", _ExplodingImpl)
    c = SolverClient(_settings())
    with pytest.raises(mapped):
        await c.call("recaptcha", sitekey="k", url="https://x")
    with pytest.raises(mapped):
        await c.balance()
    with pytest.raises(mapped):
        await c.report("id", correct=True)
    with pytest.raises(mapped):
        await c.send_raw(method="userrecaptcha")
    with pytest.raises(mapped):
        await c.get_result("id")


async def test_balance_returns_float(monkeypatch: pytest.MonkeyPatch) -> None:
    class _Impl:
        def __init__(self, **_: Any) -> None:
            self.api_client = None

        async def balance(self) -> float:
            return 12.34

    monkeypatch.setattr("twocaptcha_mcp.client.solver.AsyncTwoCaptcha", _Impl)
    c = SolverClient(_settings())
    assert await c.balance() == pytest.approx(12.34)


async def test_send_and_get_result_roundtrip(monkeypatch: pytest.MonkeyPatch) -> None:
    class _Impl:
        def __init__(self, **_: Any) -> None:
            self.api_client = None
            self.sent: dict[str, Any] | None = None

        async def send(self, **kwargs: Any) -> str:
            self.sent = kwargs
            return "id-42"

        async def get_result(self, captcha_id: str) -> str:
            assert captcha_id == "id-42"
            return "solved"

    monkeypatch.setattr("twocaptcha_mcp.client.solver.AsyncTwoCaptcha", _Impl)
    c = SolverClient(_settings())
    captcha_id = await c.send_raw(method="userrecaptcha", sitekey="k")
    assert captcha_id == "id-42"
    code = await c.get_result(captcha_id)
    assert code == "solved"


async def test_aclose_calls_close_when_present(monkeypatch: pytest.MonkeyPatch) -> None:
    closed: list[bool] = []

    class _ApiClient:
        async def close(self) -> None:
            closed.append(True)

    class _Impl:
        def __init__(self, **_: Any) -> None:
            self.api_client = _ApiClient()

    monkeypatch.setattr("twocaptcha_mcp.client.solver.AsyncTwoCaptcha", _Impl)
    c = SolverClient(_settings())
    await c.aclose()
    assert closed == [True]


async def test_aclose_noop_when_missing(monkeypatch: pytest.MonkeyPatch) -> None:
    class _Impl:
        def __init__(self, **_: Any) -> None:
            self.api_client = None

    monkeypatch.setattr("twocaptcha_mcp.client.solver.AsyncTwoCaptcha", _Impl)
    c = SolverClient(_settings())
    await c.aclose()


async def test_rate_limit_pattern_marks_bucket(monkeypatch: pytest.MonkeyPatch) -> None:
    """ApiException with ERROR_NO_SLOT_AVAILABLE must call note_server_429."""

    class _Impl:
        def __init__(self, **_: Any) -> None:
            self.api_client = None

        async def recaptcha(self, **_: Any) -> dict[str, Any]:
            raise ApiException("ERROR_NO_SLOT_AVAILABLE")

    monkeypatch.setattr("twocaptcha_mcp.client.solver.AsyncTwoCaptcha", _Impl)
    c = SolverClient(_settings())
    noted: list[str] = []
    monkeypatch.setattr(c._rate_limiter, "note_server_429", lambda key: noted.append(key))
    with pytest.raises(CaptchaApiError):
        await c.call("recaptcha", sitekey="k", url="https://x")
    assert noted == ["recaptcha"], "rate-limit pattern must trigger note_server_429"


async def test_non_rate_limit_pattern_does_not_mark(monkeypatch: pytest.MonkeyPatch) -> None:
    """Generic ApiException (e.g. ERROR_KEY_DOES_NOT_EXIST) must NOT mark bucket."""

    class _Impl:
        def __init__(self, **_: Any) -> None:
            self.api_client = None

        async def recaptcha(self, **_: Any) -> dict[str, Any]:
            raise ApiException("ERROR_KEY_DOES_NOT_EXIST")

    monkeypatch.setattr("twocaptcha_mcp.client.solver.AsyncTwoCaptcha", _Impl)
    c = SolverClient(_settings())
    noted: list[str] = []
    monkeypatch.setattr(c._rate_limiter, "note_server_429", lambda key: noted.append(key))
    with pytest.raises(CaptchaApiError):
        await c.call("recaptcha", sitekey="k", url="https://x")
    assert noted == [], "non-rate-limit api errors must not trip the limiter"


async def test_balance_rate_limit_pattern_marks_balance_bucket(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    class _Impl:
        def __init__(self, **_: Any) -> None:
            self.api_client = None

        async def balance(self) -> float:
            raise ApiException("MAX_USER_TURN")

    monkeypatch.setattr("twocaptcha_mcp.client.solver.AsyncTwoCaptcha", _Impl)
    c = SolverClient(_settings())
    noted: list[str] = []
    monkeypatch.setattr(c._rate_limiter, "note_server_429", lambda key: noted.append(key))
    with pytest.raises(CaptchaApiError):
        await c.balance()
    assert noted == ["balance"]
