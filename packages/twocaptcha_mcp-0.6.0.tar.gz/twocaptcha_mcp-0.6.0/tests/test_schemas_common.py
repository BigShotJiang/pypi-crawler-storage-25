"""Tests for twocaptcha_mcp.schemas.common."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from twocaptcha_mcp.schemas.common import (
    ProxyConfig,
    ProxyRequiredKwargs,
    SolverKwargs,
    SolverResult,
)


def test_proxy_config_to_sdk() -> None:
    p = ProxyConfig(type="HTTPS", uri="user:pass@host.example.com:8080")
    assert p.to_sdk() == {"type": "HTTPS", "uri": "user:pass@host.example.com:8080"}


def test_proxy_config_uri_must_have_port() -> None:
    with pytest.raises(ValidationError):
        ProxyConfig(type="HTTP", uri="host-without-port")


def test_proxy_config_uri_no_anonymous_userpass() -> None:
    p = ProxyConfig(type="SOCKS5", uri="1.2.3.4:1080")
    assert p.to_sdk()["uri"] == "1.2.3.4:1080"


def test_solver_kwargs_filters_none() -> None:
    k = SolverKwargs()
    assert k.to_sdk_kwargs() == {}


def test_solver_kwargs_renames_and_packs_proxy() -> None:
    k = SolverKwargs(
        proxy=ProxyConfig(type="HTTP", uri="h:1"),
        pingback="https://cb.example.com/p",  # type: ignore[arg-type]
        soft_id=999,
        user_agent="UA/1.0",
        cookies="a=b",
        lang="en",
        header_acao=1,
    )
    out = k.to_sdk_kwargs()
    assert out["proxy"] == {"type": "HTTP", "uri": "h:1"}
    assert out["pingback"] == "https://cb.example.com/p"
    assert out["softId"] == 999
    assert out["userAgent"] == "UA/1.0"
    assert out["cookies"] == "a=b"
    assert out["lang"] == "en"
    assert out["header_acao"] == 1
    # No leftover snake_case names.
    assert "soft_id" not in out
    assert "user_agent" not in out


def test_solver_kwargs_extra_forbidden() -> None:
    with pytest.raises(ValidationError):
        SolverKwargs.model_validate({"unexpected": True})


def test_proxy_required_kwargs_requires_proxy_and_ua() -> None:
    with pytest.raises(ValidationError):
        ProxyRequiredKwargs.model_validate({})
    with pytest.raises(ValidationError):
        ProxyRequiredKwargs.model_validate({"proxy": {"type": "HTTP", "uri": "h:1"}})


def test_proxy_required_kwargs_to_sdk_kwargs() -> None:
    k = ProxyRequiredKwargs(
        proxy=ProxyConfig(type="HTTP", uri="h:1"),
        user_agent="UA",
        pingback="https://cb.example.com/p",  # type: ignore[arg-type]
        soft_id=1,
        cookies="c=d",
        lang="en",
        header_acao=0,
    )
    out = k.to_sdk_kwargs()
    assert out["proxy"] == {"type": "HTTP", "uri": "h:1"}
    assert out["userAgent"] == "UA"
    assert out["pingback"] == "https://cb.example.com/p"
    assert out["softId"] == 1
    assert out["cookies"] == "c=d"
    assert out["lang"] == "en"
    assert out["header_acao"] == 0


def test_solver_result_from_sdk_minimal() -> None:
    r = SolverResult.from_sdk({"captchaId": "1", "code": "abc"})
    assert r.captcha_id == "1"
    assert r.code == "abc"
    assert r.extra is None


def test_solver_result_from_sdk_extended() -> None:
    r = SolverResult.from_sdk({"captchaId": "1", "code": "abc", "cost": "0.001"})
    assert r.extra == {"cost": "0.001"}


def test_solver_result_serialisation_round_trip() -> None:
    r = SolverResult.from_sdk({"captchaId": "x", "code": "y"})
    payload = r.model_dump(by_alias=True, exclude_none=True)
    assert payload["captchaId"] == "x"
    assert payload["code"] == "y"
