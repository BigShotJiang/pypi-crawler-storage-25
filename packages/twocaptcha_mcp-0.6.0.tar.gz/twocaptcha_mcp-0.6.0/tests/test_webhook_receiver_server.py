"""Unit tests for the Starlette pingback receiver via httpx ASGI client."""

from __future__ import annotations

from pathlib import Path

import httpx
import pytest

from twocaptcha_mcp.config import Settings
from twocaptcha_mcp.webhook_receiver.server import create_app


def _settings(tmp_path: Path, *, secret: str | None = None) -> Settings:
    return Settings.model_construct(
        twocaptcha_api_key="k",
        twocaptcha_server="2captcha.com",
        twocaptcha_default_timeout=120.0,
        twocaptcha_recaptcha_timeout=600.0,
        twocaptcha_polling_interval=10.0,
        twocaptcha_soft_id=4580,
        twocaptcha_log_level="INFO",
        twocaptcha_default_callback=None,
        twocaptcha_webhook_host="127.0.0.1",
        twocaptcha_webhook_port=8787,
        twocaptcha_webhook_db_path=tmp_path / "pb.db",
        twocaptcha_webhook_public_url=None,
        twocaptcha_webhook_secret=secret,
        twocaptcha_rate_limit_per_minute=100,
    )


@pytest.fixture
async def client_and_db(tmp_path: Path):  # type: ignore[no-untyped-def]
    settings = _settings(tmp_path)
    app = create_app(settings)
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as c:
        yield c, settings.twocaptcha_webhook_db_path


@pytest.fixture
async def secured_client(tmp_path: Path):  # type: ignore[no-untyped-def]
    settings = _settings(tmp_path, secret="topsecret")
    app = create_app(settings)
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


async def test_health(client_and_db) -> None:  # type: ignore[no-untyped-def]
    client, _ = client_and_db
    resp = await client.get("/health")
    assert resp.status_code == 200
    body = resp.json()
    assert body["ok"] is True
    assert body["service"] == "twocaptcha-mcp-webhook"


async def test_pingback_form_encoded(client_and_db) -> None:  # type: ignore[no-untyped-def]
    client, db_path = client_and_db
    resp = await client.post("/2captcha/pingback", data={"id": "cap-1", "code": "abcd1234"})
    assert resp.status_code == 200, resp.text
    assert resp.json() == {"ok": True, "captcha_id": "cap-1"}

    from twocaptcha_mcp.webhook_receiver.storage import EventStore

    e = EventStore(db_path).get("cap-1")
    assert e is not None
    assert e.code == "abcd1234"


async def test_pingback_idempotent_on_duplicate(client_and_db) -> None:  # type: ignore[no-untyped-def]
    client, _ = client_and_db
    await client.post("/2captcha/pingback", data={"id": "x", "code": "first"})
    resp = await client.post("/2captcha/pingback", data={"id": "x", "code": "second"})
    assert resp.status_code == 200, "duplicate must not error"


async def test_pingback_missing_fields_400(client_and_db) -> None:  # type: ignore[no-untyped-def]
    client, _ = client_and_db
    resp = await client.post("/2captcha/pingback", data={"id": "only-id"})
    assert resp.status_code == 400
    assert resp.json()["error"] == "missing_fields"


async def test_secret_required_when_configured(secured_client) -> None:  # type: ignore[no-untyped-def]
    resp = await secured_client.post("/2captcha/pingback", data={"id": "x", "code": "y"})
    assert resp.status_code == 401
    assert resp.json()["reason"] == "missing_secret"


async def test_secret_via_query_param(secured_client) -> None:  # type: ignore[no-untyped-def]
    resp = await secured_client.post(
        "/2captcha/pingback?secret=topsecret", data={"id": "x", "code": "y"}
    )
    assert resp.status_code == 200


async def test_secret_via_header(secured_client) -> None:  # type: ignore[no-untyped-def]
    resp = await secured_client.post(
        "/2captcha/pingback",
        data={"id": "h", "code": "z"},
        headers={"x-webhook-secret": "topsecret"},
    )
    assert resp.status_code == 200


async def test_secret_wrong_returns_401(secured_client) -> None:  # type: ignore[no-untyped-def]
    resp = await secured_client.post(
        "/2captcha/pingback?secret=nope", data={"id": "x", "code": "y"}
    )
    assert resp.status_code == 401
    assert resp.json()["reason"] == "bad_secret"
