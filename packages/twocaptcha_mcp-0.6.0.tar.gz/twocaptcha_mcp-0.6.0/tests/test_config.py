"""Tests for twocaptcha_mcp.config."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from twocaptcha_mcp.config import Settings, load_settings


@pytest.fixture(autouse=True)
def _isolate_env(monkeypatch: pytest.MonkeyPatch, tmp_path) -> None:  # type: ignore[no-untyped-def]
    """Strip every alias for the API key + chdir to empty temp dir to avoid .env pickup."""
    for var in (
        "2Captcha_API_KEY",
        "TWOCAPTCHA_API_KEY",
        "2CAPTCHA_API_KEY",
        "API_KEY_2CAPTCHA",
        "twocaptcha_api_key",
        "TWOCAPTCHA_SERVER",
        "TWOCAPTCHA_DEFAULT_TIMEOUT",
        "TWOCAPTCHA_RECAPTCHA_TIMEOUT",
        "TWOCAPTCHA_POLLING_INTERVAL",
        "TWOCAPTCHA_SOFT_ID",
        "TWOCAPTCHA_LOG_LEVEL",
        "TWOCAPTCHA_DEFAULT_CALLBACK",
    ):
        monkeypatch.delenv(var, raising=False)
    monkeypatch.chdir(tmp_path)


def test_loads_with_primary_alias(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("2Captcha_API_KEY", "abc123")
    s = load_settings()
    assert s.twocaptcha_api_key == "abc123"
    assert s.twocaptcha_server == "2captcha.com"
    assert s.twocaptcha_default_timeout == 120.0
    assert s.twocaptcha_log_level == "INFO"
    assert s.twocaptcha_default_callback is None


def test_loads_with_uppercase_alias(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("TWOCAPTCHA_API_KEY", "xyz")
    s = load_settings()
    assert s.twocaptcha_api_key == "xyz"


def test_loads_with_legacy_alias(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("API_KEY_2CAPTCHA", "legacy")
    s = load_settings()
    assert s.twocaptcha_api_key == "legacy"


def test_missing_key_raises(monkeypatch: pytest.MonkeyPatch) -> None:
    with pytest.raises(ValidationError):
        load_settings()


def test_log_level_normalised(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("2Captcha_API_KEY", "k")
    monkeypatch.setenv("TWOCAPTCHA_LOG_LEVEL", "debug")
    s = load_settings()
    assert s.twocaptcha_log_level == "DEBUG"


def test_invalid_log_level_rejected(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("2Captcha_API_KEY", "k")
    monkeypatch.setenv("TWOCAPTCHA_LOG_LEVEL", "VERBOSE")
    with pytest.raises(ValidationError):
        load_settings()


def test_invalid_server_rejected(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("2Captcha_API_KEY", "k")
    monkeypatch.setenv("TWOCAPTCHA_SERVER", "rogue.example.com")
    with pytest.raises(ValidationError):
        load_settings()


def test_timeout_out_of_range_rejected(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("2Captcha_API_KEY", "k")
    monkeypatch.setenv("TWOCAPTCHA_DEFAULT_TIMEOUT", "0")
    with pytest.raises(ValidationError):
        load_settings()


def test_explicit_overrides(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("2Captcha_API_KEY", "k")
    monkeypatch.setenv("TWOCAPTCHA_SERVER", "rucaptcha.com")
    monkeypatch.setenv("TWOCAPTCHA_DEFAULT_TIMEOUT", "60")
    monkeypatch.setenv("TWOCAPTCHA_POLLING_INTERVAL", "5")
    monkeypatch.setenv("TWOCAPTCHA_SOFT_ID", "9999")
    s = load_settings()
    assert s.twocaptcha_server == "rucaptcha.com"
    assert s.twocaptcha_default_timeout == 60.0
    assert s.twocaptcha_polling_interval == 5.0
    assert s.twocaptcha_soft_id == 9999


def test_settings_immutable_dump(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("2Captcha_API_KEY", "k")
    s = load_settings()
    payload = s.model_dump()
    assert payload["twocaptcha_api_key"] == "k"
    assert isinstance(s, Settings)
