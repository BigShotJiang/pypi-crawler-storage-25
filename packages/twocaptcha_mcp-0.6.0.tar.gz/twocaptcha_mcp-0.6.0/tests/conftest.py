"""Global pytest configuration."""

from __future__ import annotations

import pytest


def pytest_addoption(parser: pytest.Parser) -> None:
    parser.addoption(
        "--run-live",
        action="store_true",
        default=False,
        help="Run integration tests that hit the real 2Captcha API.",
    )
    parser.addoption(
        "--live-all-captchas",
        action="store_true",
        default=False,
        help="Run live tests for every supported captcha type with public test sitekeys.",
    )
    parser.addoption(
        "--run-e2e",
        action="store_true",
        default=False,
        help="Run end-to-end MCP protocol tests (spawns real `python -m twocaptcha_mcp`).",
    )


def pytest_collection_modifyitems(config: pytest.Config, items: list[pytest.Item]) -> None:
    if not config.getoption("--run-live"):
        skip_live = pytest.mark.skip(reason="needs --run-live")
        for item in items:
            if "live" in item.keywords:
                item.add_marker(skip_live)
    if not config.getoption("--live-all-captchas"):
        skip_all = pytest.mark.skip(reason="needs --live-all-captchas")
        for item in items:
            if "live_all_captchas" in item.keywords:
                item.add_marker(skip_all)
    if not config.getoption("--run-e2e"):
        skip_e2e = pytest.mark.skip(reason="needs --run-e2e")
        for item in items:
            if "e2e" in item.keywords:
                item.add_marker(skip_e2e)
