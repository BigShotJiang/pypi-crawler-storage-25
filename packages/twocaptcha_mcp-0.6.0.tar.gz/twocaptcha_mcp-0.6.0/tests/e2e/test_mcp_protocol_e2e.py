"""End-to-end MCP protocol test — pure Python, no external CLI dependency.

Spawns `python -m twocaptcha_mcp` as a real stdio MCP server and drives it through
the official `mcp.client` library: initialize → list_tools → call_tool. This is
the *real* behavioural counterpart to `test_main_smoke.py` (which only does a
hand-rolled JSON-RPC handshake).

Skipped by default; run with `pytest -m e2e --run-e2e`.

Note: each test owns its own session/stdio context — pytest-asyncio's
`yield`-based fixtures don't compose well with `mcp.client.stdio.stdio_client`'s
internal anyio task group, which is why everything lives inline.
"""

from __future__ import annotations

import json
import os
import sys
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

import pytest
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client


def _api_key_present() -> bool:
    for var in (
        "2Captcha_API_KEY",
        "TWOCAPTCHA_API_KEY",
        "2CAPTCHA_API_KEY",
        "API_KEY_2CAPTCHA",
        "twocaptcha_api_key",
    ):
        if os.environ.get(var):
            return True
    return os.path.exists(".env")


pytestmark = [
    pytest.mark.e2e,
    pytest.mark.skipif(not _api_key_present(), reason="API key required for live MCP roundtrip"),
]


@asynccontextmanager
async def _session() -> AsyncIterator[ClientSession]:
    server_params = StdioServerParameters(
        command=sys.executable,
        args=["-m", "twocaptcha_mcp"],
        env=os.environ.copy(),
    )
    async with (
        stdio_client(server_params) as (read, write),
        ClientSession(read, write) as session,
    ):
        await session.initialize()
        yield session


async def test_list_tools_returns_43() -> None:
    """The full public surface should be visible to a real MCP client."""
    async with _session() as session:
        response = await session.list_tools()
        names = {t.name for t in response.tools}
    assert len(names) == 43, f"Expected 43 tools, got {len(names)}: {sorted(names)}"
    assert "twocaptcha_balance" in names
    assert "twocaptcha_solve_recaptcha" in names
    assert "twocaptcha_pingback_events_list" in names
    assert "twocaptcha_solve_and_wait_pingback" in names


async def test_call_balance_returns_float() -> None:
    """Real round-trip: client invokes a tool, server hits 2Captcha, returns balance."""
    async with _session() as session:
        result = await session.call_tool("twocaptcha_balance", {})
    assert not result.isError, f"tool reported error: {result.content}"
    assert result.content
    text_block = result.content[0]
    assert getattr(text_block, "type", None) == "text", text_block
    payload = json.loads(text_block.text)  # type: ignore[union-attr]
    assert "balance" in payload
    assert isinstance(payload["balance"], (int, float))
    assert payload["balance"] >= 0
    assert payload.get("currency") == "USD"


async def test_invalid_tool_args_rejected() -> None:
    """Schema-violating input must surface as a validation error.

    The official `mcp` SDK validates JSON-Schema client-side before sending,
    so the response carries either a "validation error" message OR `isError=True`.
    Either way the request must NOT silently succeed.
    """
    async with _session() as session:
        result = await session.call_tool("twocaptcha_solve_recaptcha", {"sitekey": ""})
    text = ""
    if result.content:
        text = (getattr(result.content[0], "text", "") or "").lower()
    assert result.isError or "validation error" in text or "invalid_argument" in text, (
        f"expected validation rejection, got: text={text!r} isError={result.isError}"
    )
