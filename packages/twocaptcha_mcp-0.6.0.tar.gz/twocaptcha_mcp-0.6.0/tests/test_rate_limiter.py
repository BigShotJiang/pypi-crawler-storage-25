"""Tests for the per-method async rate limiter."""

from __future__ import annotations

import asyncio
import time

import pytest

from twocaptcha_mcp.client.rate_limiter import RateLimiter


async def test_under_limit_immediate() -> None:
    limiter = RateLimiter(default_per_minute=10)
    start = time.monotonic()
    for _ in range(5):
        await limiter.acquire("solve_normal")
    assert time.monotonic() - start < 0.5, "no waits expected below limit"


async def test_per_method_independence() -> None:
    """Filling one bucket must not block another method."""
    limiter = RateLimiter(default_per_minute=2)
    await limiter.acquire("recaptcha")
    await limiter.acquire("recaptcha")
    # `hcaptcha` bucket is empty.
    start = time.monotonic()
    await limiter.acquire("hcaptcha")
    assert time.monotonic() - start < 0.1


async def test_blocks_when_full(monkeypatch: pytest.MonkeyPatch) -> None:
    """When bucket fills the next acquire must wait until a slot frees."""
    limiter = RateLimiter(default_per_minute=2)
    await limiter.acquire("balance")
    await limiter.acquire("balance")
    # 3rd acquire should block briefly. We patch sleep to no-op + advance fake clock.
    waited: list[float] = []

    real_sleep = asyncio.sleep

    async def fake_sleep(delay: float) -> None:
        waited.append(delay)
        # Drop the oldest timestamp so the next loop iteration succeeds.
        bucket = limiter._buckets["balance"]
        if bucket.timestamps:
            bucket.timestamps.popleft()
        await real_sleep(0)

    monkeypatch.setattr(asyncio, "sleep", fake_sleep)
    await limiter.acquire("balance")
    assert waited, "limiter must have called asyncio.sleep at least once"


async def test_note_server_429_pre_fills_bucket() -> None:
    limiter = RateLimiter(default_per_minute=5)
    await limiter.acquire("recaptcha")
    limiter.note_server_429("recaptcha")
    assert len(limiter._buckets["recaptcha"].timestamps) == 5


def test_default_per_minute_validation() -> None:
    with pytest.raises(ValueError):
        RateLimiter(default_per_minute=0)


def test_note_server_429_for_unknown_key_is_noop() -> None:
    """Calling note_server_429 with a key never seen before must not crash."""
    limiter = RateLimiter(default_per_minute=5)
    limiter.note_server_429("never_used")
    assert "never_used" not in limiter._buckets, "note_server_429 must not lazy-create"
