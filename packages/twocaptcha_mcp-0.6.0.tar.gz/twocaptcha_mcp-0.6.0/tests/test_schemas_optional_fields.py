"""Coverage for the optional-field branches in solver schemas.

Each `to_sdk_call_kwargs()` has a tail of `if x is not None: out[...]=x` lines
that the parametrised happy-path tests don't exercise (they pass only the
required fields). This file ensures every optional kwarg is exercised at
least once for the high-traffic schemas.
"""

from __future__ import annotations

from twocaptcha_mcp.schemas.funcaptcha import FuncaptchaRequest
from twocaptcha_mcp.schemas.hcaptcha import HcaptchaRequest
from twocaptcha_mcp.schemas.recaptcha import RecaptchaRequest
from twocaptcha_mcp.schemas.turnstile import TurnstileRequest


def test_recaptcha_all_optional_fields_serialised() -> None:
    req = RecaptchaRequest(
        sitekey="K",
        url="https://example.com",  # type: ignore[arg-type]
        version="v3",
        enterprise=True,
        invisible=True,
        data_s="data_s_value",
        action="login",
        min_score=0.7,
        domain="example.com",
    )
    out = req.to_sdk_call_kwargs()
    assert out["invisible"] == 1
    assert out["data-s"] == "data_s_value"
    assert out["action"] == "login"
    assert out["min_score"] == 0.7
    assert out["domain"] == "example.com"


def test_recaptcha_invisible_false() -> None:
    req = RecaptchaRequest(
        sitekey="K",
        url="https://example.com",  # type: ignore[arg-type]
        invisible=False,
    )
    out = req.to_sdk_call_kwargs()
    assert out["invisible"] == 0


def test_funcaptcha_optional_surl_and_data() -> None:
    req = FuncaptchaRequest(
        sitekey="K",
        url="https://example.com",  # type: ignore[arg-type]
        surl="https://api.surl.example",
        data={"key1": "v1", "key2": "v2"},
    )
    out = req.to_sdk_call_kwargs()
    assert out["surl"] == "https://api.surl.example"
    assert out["data[key1]"] == "v1"
    assert out["data[key2]"] == "v2"


def test_hcaptcha_all_optional_fields() -> None:
    req = HcaptchaRequest(
        sitekey="K",
        url="https://example.com",  # type: ignore[arg-type]
        invisible=True,
        domain="example.com",
        data="rqdata-value",
        enterprise=True,
    )
    out = req.to_sdk_call_kwargs()
    assert out["invisible"] == 1
    assert out["domain"] == "example.com"
    assert out["data"] == "rqdata-value"
    assert out["enterprise"] == 1


def test_hcaptcha_invisible_false() -> None:
    req = HcaptchaRequest(
        sitekey="K",
        url="https://example.com",  # type: ignore[arg-type]
        invisible=False,
        enterprise=False,
    )
    out = req.to_sdk_call_kwargs()
    assert out["invisible"] == 0
    assert out["enterprise"] == 0


def test_turnstile_all_optional_fields() -> None:
    req = TurnstileRequest(
        sitekey="K",
        url="https://example.com",  # type: ignore[arg-type]
        action="submit",
        data="cdata-value",
        pagedata="chl-page-data",
        cdata="cdata2",
    )
    out = req.to_sdk_call_kwargs()
    assert out["action"] == "submit"
    assert out["data"] == "cdata-value"
    assert out["pagedata"] == "chl-page-data"
    assert out["cdata"] == "cdata2"
