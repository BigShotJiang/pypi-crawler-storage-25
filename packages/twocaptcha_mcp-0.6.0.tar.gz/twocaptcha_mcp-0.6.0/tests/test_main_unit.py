"""Unit-coverage for `twocaptcha_mcp/__main__.py` — complements the subprocess smoke test."""

from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock, MagicMock

import pytest
from pydantic import ValidationError

from twocaptcha_mcp import __main__ as main_module


@pytest.fixture(autouse=True)
def _strip_keys(monkeypatch: pytest.MonkeyPatch) -> None:
    for var in (
        "2Captcha_API_KEY",
        "TWOCAPTCHA_API_KEY",
        "2CAPTCHA_API_KEY",
        "API_KEY_2CAPTCHA",
        "twocaptcha_api_key",
    ):
        monkeypatch.delenv(var, raising=False)


async def test_run_exits_2_on_missing_config(
    capsys: pytest.CaptureFixture[str], tmp_path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.chdir(tmp_path)
    with pytest.raises(SystemExit) as ei:
        await main_module._run()
    assert ei.value.code == 2
    assert "configuration error" in capsys.readouterr().err


async def test_run_happy_path_drives_server_then_closes(
    monkeypatch: pytest.MonkeyPatch, tmp_path
) -> None:
    monkeypatch.setenv("2Captcha_API_KEY", "k")
    monkeypatch.chdir(tmp_path)

    server = MagicMock()
    server.create_initialization_options.return_value = {"opt": True}
    server.run = AsyncMock()
    solver = MagicMock()
    solver.aclose = AsyncMock()
    pingback = MagicMock()
    pingback.aclose = AsyncMock()
    monkeypatch.setattr(main_module, "build_server", lambda settings: (server, solver, pingback))

    class _StdioCM:
        async def __aenter__(self) -> tuple[Any, Any]:
            return ("read", "write")

        async def __aexit__(self, *_: object) -> None:
            return None

    monkeypatch.setattr(main_module, "stdio_server", lambda: _StdioCM())

    await main_module._run()

    server.run.assert_awaited_once_with("read", "write", {"opt": True})
    solver.aclose.assert_awaited_once()
    pingback.aclose.assert_awaited_once()


def test_main_swallows_keyboard_interrupt(monkeypatch: pytest.MonkeyPatch) -> None:
    def _boom(_coro: Any) -> None:
        if hasattr(_coro, "close"):
            _coro.close()
        raise KeyboardInterrupt

    monkeypatch.setattr(main_module.asyncio, "run", _boom)
    main_module.main()


async def test_run_propagates_validation_error_as_systemexit(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """Exhaustive guard: any pydantic.ValidationError → SystemExit(2)."""
    fake_err = ValidationError.from_exception_data(
        "Settings", [{"type": "missing", "loc": ("twocaptcha_api_key",)}]
    )

    def _raise() -> None:
        raise fake_err

    monkeypatch.setattr(main_module, "load_settings", _raise)
    with pytest.raises(SystemExit) as ei:
        await main_module._run()
    assert ei.value.code == 2
    assert "configuration error" in capsys.readouterr().err
