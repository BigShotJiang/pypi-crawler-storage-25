"""Parametrised live tests for the top-3 captcha types using publicly stable test sitekeys.

These are the *official test/demo* sitekeys provided by the captcha vendors —
guaranteed to remain stable and to either always-pass (Turnstile) or to be
solvable by 2Captcha workers (recaptcha-v2, hCaptcha).

Skipped by default; run with `pytest -m live --run-live --live-all-captchas`.
Real cost: ~$0.005 per full run (3 captcha solves at fractions of a cent each).
"""

from __future__ import annotations

import os

import pytest

from twocaptcha_mcp.client import SolverClient
from twocaptcha_mcp.config import load_settings


def _api_key_present() -> bool:
    for var in (
        "2Captcha_API_KEY",
        "TWOCAPTCHA_API_KEY",
        "2CAPTCHA_API_KEY",
        "API_KEY_2CAPTCHA",
        "twocaptcha_api_key",
    ):
        if os.environ.get(var):
            return True
    return os.path.exists(".env")


pytestmark = [
    pytest.mark.live,
    pytest.mark.live_all_captchas,
    pytest.mark.skipif(not _api_key_present(), reason="2Captcha_API_KEY required"),
]

# (label, sdk_method, kwargs) — using the vendors' OFFICIAL test sitekeys, which
# are documented as forever-stable. See research §2 in 0.4.0_research.md.
CASES = [
    pytest.param(
        "recaptcha-v2",
        "recaptcha",
        {
            "sitekey": "6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI",
            "url": "https://www.google.com/recaptcha/api2/demo",
            "version": "v2",
        },
        id="recaptcha-v2",
    ),
    # hCaptcha "always-pass" test sitekey (10000000-ffff-...) — solver-bypassed
    # client-side, so 2Captcha returns ERROR_SITEKEY (no real challenge to solve).
    # Same applies to Cloudflare's "always passes" Turnstile sitekey (1x000...).
    # We mark these xfail with an explicit reason; finding a *real* public hCaptcha /
    # Turnstile sitekey that 2Captcha will accept is beyond our control (each
    # production site uses its own private key).
    pytest.param(
        "hcaptcha",
        "hcaptcha",
        {
            "sitekey": "10000000-ffff-ffff-ffff-000000000001",
            "url": "https://accounts.hcaptcha.com/demo",
        },
        id="hcaptcha",
        marks=pytest.mark.xfail(
            reason="hCaptcha 'always-pass' demo sitekey is solver-bypassed; "
            "2Captcha returns ERROR_SITEKEY. No public real-challenge sitekey "
            "available outside production sites.",
            strict=True,
        ),
    ),
    pytest.param(
        "turnstile",
        "turnstile",
        {
            "sitekey": "1x00000000000000000000AA",
            "url": "https://demo.turnstile.workers.dev/",
        },
        id="turnstile",
        marks=pytest.mark.xfail(
            reason="Cloudflare 'always-passes' test sitekey returns "
            "ERROR_SITEKEY from 2Captcha (no real challenge).",
            strict=True,
        ),
    ),
]


@pytest.mark.parametrize("label,sdk_method,kwargs", CASES)
async def test_solve_top_captcha(label: str, sdk_method: str, kwargs: dict) -> None:
    """For each top captcha type: live `solve_*` → assert non-empty `code`."""
    solver = SolverClient(load_settings())
    try:
        result = await solver.call(sdk_method, **kwargs)
    finally:
        await solver.aclose()
    assert "captchaId" in result, f"{label}: missing captchaId in {result}"
    assert "code" in result, f"{label}: missing code in {result}"
    assert isinstance(result["code"], str) and result["code"].strip(), (
        f"{label}: empty code: {result}"
    )
