"""Parametrised tests for all solver tools (excluding image/proxy-required which have their own files)."""

from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock

import pytest

from twocaptcha_mcp.schemas.amazon import AmazonWafRequest
from twocaptcha_mcp.schemas.atb import AtbCaptchaRequest
from twocaptcha_mcp.schemas.funcaptcha import FuncaptchaRequest
from twocaptcha_mcp.schemas.geetest import GeetestRequest, GeetestV4Request
from twocaptcha_mcp.schemas.hcaptcha import HcaptchaRequest
from twocaptcha_mcp.schemas.misc import (
    AltchaRequest,
    CybersiaraRequest,
    ProsopoRequest,
    TemuRequest,
    YandexSmartRequest,
)
from twocaptcha_mcp.schemas.recaptcha import RecaptchaRequest
from twocaptcha_mcp.schemas.tencent import TencentRequest
from twocaptcha_mcp.schemas.tokens import (
    CapyRequest,
    CutcaptchaRequest,
    FriendlyCaptchaRequest,
    KeycaptchaRequest,
    LeminRequest,
    MtcaptchaRequest,
)
from twocaptcha_mcp.schemas.turnstile import TurnstileRequest
from twocaptcha_mcp.tools import (
    amazon,
    atb,
    funcaptcha,
    geetest,
    hcaptcha,
    misc,
    recaptcha,
    tencent,
    tokens,
    turnstile,
)
from twocaptcha_mcp.tools.registry import ToolCtx


@pytest.fixture
def ctx_with_mock_solver() -> ToolCtx:
    solver = AsyncMock()
    solver.call = AsyncMock(return_value={"captchaId": "id-1", "code": "RESULT"})
    return ToolCtx(solver=solver, pingback=None)  # type: ignore[arg-type]


CASES: list[tuple[str, Any, str, dict[str, Any]]] = [
    (
        "recaptcha",
        RecaptchaRequest(sitekey="K", url="https://example.com", version="v2"),  # type: ignore[arg-type]
        "solve_recaptcha",
        {"sitekey": "K", "url": "https://example.com/", "version": "v2", "enterprise": 0},
    ),
    (
        "hcaptcha",
        HcaptchaRequest(sitekey="K", url="https://example.com"),  # type: ignore[arg-type]
        "solve_hcaptcha",
        {"sitekey": "K", "url": "https://example.com/"},
    ),
    (
        "turnstile",
        TurnstileRequest(sitekey="K", url="https://example.com"),  # type: ignore[arg-type]
        "solve_turnstile",
        {"sitekey": "K", "url": "https://example.com/"},
    ),
    (
        "funcaptcha",
        FuncaptchaRequest(sitekey="K", url="https://example.com"),  # type: ignore[arg-type]
        "solve_funcaptcha",
        {"sitekey": "K", "url": "https://example.com/"},
    ),
    (
        "geetest",
        GeetestRequest(gt="g", challenge="c", url="https://example.com"),  # type: ignore[arg-type]
        "solve_geetest",
        {"gt": "g", "challenge": "c", "url": "https://example.com/"},
    ),
    (
        "geetest_v4",
        GeetestV4Request(captcha_id="cid", url="https://example.com"),  # type: ignore[arg-type]
        "solve_geetest_v4",
        {"captcha_id": "cid", "url": "https://example.com/"},
    ),
    (
        "amazon_waf",
        AmazonWafRequest(sitekey="K", iv="iv", context="c", url="https://example.com"),  # type: ignore[arg-type]
        "solve_amazon_waf",
        {"sitekey": "K", "iv": "iv", "context": "c", "url": "https://example.com/"},
    ),
    (
        "tencent",
        TencentRequest(app_id="A", url="https://example.com"),  # type: ignore[arg-type]
        "solve_tencent",
        {"app_id": "A", "url": "https://example.com/"},
    ),
    (
        "atb_captcha",
        AtbCaptchaRequest(app_id="A", api_server="srv", url="https://example.com"),  # type: ignore[arg-type]
        "solve_atb_captcha",
        {"app_id": "A", "api_server": "srv", "url": "https://example.com/"},
    ),
    (
        "capy",
        CapyRequest(sitekey="K", url="https://example.com"),  # type: ignore[arg-type]
        "solve_capy",
        {"sitekey": "K", "url": "https://example.com/"},
    ),
    (
        "keycaptcha",
        KeycaptchaRequest(
            s_s_c_user_id="u",
            s_s_c_session_id="s",
            s_s_c_web_server_sign="w1",
            s_s_c_web_server_sign2="w2",
            url="https://example.com",  # type: ignore[arg-type]
        ),
        "solve_keycaptcha",
        {
            "s_s_c_user_id": "u",
            "s_s_c_session_id": "s",
            "s_s_c_web_server_sign": "w1",
            "s_s_c_web_server_sign2": "w2",
            "url": "https://example.com/",
        },
    ),
    (
        "lemin",
        LeminRequest(captcha_id="cid", div_id="div", url="https://example.com"),  # type: ignore[arg-type]
        "solve_lemin",
        {"captcha_id": "cid", "div_id": "div", "url": "https://example.com/"},
    ),
    (
        "mtcaptcha",
        MtcaptchaRequest(sitekey="K", url="https://example.com"),  # type: ignore[arg-type]
        "solve_mtcaptcha",
        {"sitekey": "K", "url": "https://example.com/"},
    ),
    (
        "friendly_captcha",
        FriendlyCaptchaRequest(sitekey="K", url="https://example.com"),  # type: ignore[arg-type]
        "solve_friendly_captcha",
        {"sitekey": "K", "url": "https://example.com/"},
    ),
    (
        "cutcaptcha",
        CutcaptchaRequest(misery_key="m", apikey="a", url="https://example.com"),  # type: ignore[arg-type]
        "solve_cutcaptcha",
        {"misery_key": "m", "apikey": "a", "url": "https://example.com/"},
    ),
    (
        "prosopo",
        ProsopoRequest(sitekey="K", pageurl="https://example.com"),  # type: ignore[arg-type]
        "solve_prosopo",
        {"sitekey": "K", "pageurl": "https://example.com/"},
    ),
    (
        "temu",
        TemuRequest(body="b", part1="1", part2="2", part3="3"),  # type: ignore[arg-type]
        "solve_temu",
        {"body": "b", "part1": "1", "part2": "2", "part3": "3"},
    ),
    (
        "altcha",
        AltchaRequest(pageurl="https://example.com"),  # type: ignore[arg-type]
        "solve_altcha",
        {"pageurl": "https://example.com/"},
    ),
    (
        "cybersiara",
        CybersiaraRequest(
            master_url_id="m",
            pageurl="https://example.com",
            cyber_user_agent="UA",  # type: ignore[arg-type]
        ),
        "solve_cybersiara",
        {"master_url_id": "m", "pageurl": "https://example.com/", "userAgent": "UA"},
    ),
    (
        "yandex_smart",
        YandexSmartRequest(sitekey="K", url="https://example.com"),  # type: ignore[arg-type]
        "solve_yandex_smart",
        {"sitekey": "K", "url": "https://example.com/"},
    ),
]


def _get_handler(method: str) -> Any:
    """Look up the @captcha_tool handler by SDK method name."""
    handlers: dict[str, Any] = {}
    for module in (
        recaptcha,
        hcaptcha,
        turnstile,
        funcaptcha,
        geetest,
        amazon,
        tencent,
        atb,
        tokens,
        misc,
    ):
        for name, value in vars(module).items():
            if name in {
                "solve_recaptcha",
                "solve_hcaptcha",
                "solve_turnstile",
                "solve_funcaptcha",
                "solve_geetest",
                "solve_geetest_v4",
                "solve_amazon_waf",
                "solve_tencent",
                "solve_atb_captcha",
                "solve_capy",
                "solve_keycaptcha",
                "solve_lemin",
                "solve_mtcaptcha",
                "solve_friendly_captcha",
                "solve_cutcaptcha",
                "solve_prosopo",
                "solve_temu",
                "solve_altcha",
                "solve_cybersiara",
                "solve_yandex_smart",
            }:
                handlers[name] = value
    return handlers[method]


@pytest.mark.parametrize("sdk_method, request_obj, handler_name, expected_kwargs", CASES)
async def test_tool_calls_solver_with_correct_kwargs(
    ctx_with_mock_solver: ToolCtx,
    sdk_method: str,
    request_obj: Any,
    handler_name: str,
    expected_kwargs: dict[str, Any],
) -> None:
    handler = _get_handler(handler_name)
    result = await handler(request_obj, ctx_with_mock_solver)
    ctx_with_mock_solver.solver.call.assert_awaited_once()  # type: ignore[attr-defined]
    name, kwargs = (
        ctx_with_mock_solver.solver.call.await_args.args[0],
        ctx_with_mock_solver.solver.call.await_args.kwargs,
    )  # type: ignore[attr-defined]
    assert name == sdk_method
    for k, v in expected_kwargs.items():
        assert kwargs[k] == v, f"{handler_name}: kwarg {k} expected {v!r}, got {kwargs.get(k)!r}"
    assert result.captcha_id == "id-1"
    assert result.code == "RESULT"


async def test_solver_kwargs_propagated(ctx_with_mock_solver: ToolCtx) -> None:
    handler = _get_handler("solve_recaptcha")
    req = RecaptchaRequest(
        sitekey="K",
        url="https://example.com",  # type: ignore[arg-type]
        version="v3",
        action="login",
        min_score=0.7,
        enterprise=True,
        soft_id=42,
        proxy={"type": "HTTPS", "uri": "u:p@h:80"},  # type: ignore[arg-type]
    )
    await handler(req, ctx_with_mock_solver)
    kwargs = ctx_with_mock_solver.solver.call.await_args.kwargs  # type: ignore[attr-defined]
    assert kwargs["version"] == "v3"
    assert kwargs["action"] == "login"
    assert kwargs["min_score"] == 0.7
    assert kwargs["enterprise"] == 1
    assert kwargs["softId"] == 42
    assert kwargs["proxy"] == {"type": "HTTPS", "uri": "u:p@h:80"}
