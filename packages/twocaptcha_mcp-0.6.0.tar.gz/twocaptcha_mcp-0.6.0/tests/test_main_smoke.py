"""Subprocess-based smoke test for the stdio entrypoint `python -m twocaptcha_mcp`.

The unit test suite mocks `AsyncTwoCaptcha`, but `__main__.py` and `build_server`
live and breathe only when the real binary boots — that's what this test exercises.

Strategy: spawn the server in a child process, drive it with a hand-rolled MCP
JSON-RPC `initialize` + `initialized` + `tools/list` sequence over stdin/stdout,
verify the response carries our 39 tools, then close stdin and assert clean exit.

If this test starts being flaky on slow CI runners, raise the per-step timeout
(currently generous) before reaching for retry plugins.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from collections.abc import Iterator

import pytest

PROTOCOL_VERSION = "2025-06-18"


def _read_message(proc: subprocess.Popen[bytes], deadline: float) -> dict[str, object]:
    """Read a single newline-delimited JSON message from the server's stdout."""
    assert proc.stdout is not None
    while True:
        if time.monotonic() > deadline:
            raise TimeoutError("Timed out waiting for stdout line from server")
        line = proc.stdout.readline()
        if not line:
            if proc.poll() is not None:
                raise RuntimeError(
                    f"Server exited prematurely (rc={proc.returncode}). "
                    f"stderr: {proc.stderr.read().decode('utf-8', 'replace') if proc.stderr else '<no stderr>'}"
                )
            time.sleep(0.05)
            continue
        text = line.decode("utf-8").strip()
        if not text:
            continue
        return json.loads(text)


def _send(proc: subprocess.Popen[bytes], payload: dict[str, object]) -> None:
    assert proc.stdin is not None
    proc.stdin.write((json.dumps(payload) + "\n").encode("utf-8"))
    proc.stdin.flush()


@pytest.fixture
def server_proc() -> Iterator[subprocess.Popen[bytes]]:
    env = os.environ.copy()
    # Ensure we have the API key set even on CI runners with no .env.
    env.setdefault("2Captcha_API_KEY", "smoke-test-fake-key")
    env["PYTHONUNBUFFERED"] = "1"
    proc = subprocess.Popen(
        [sys.executable, "-m", "twocaptcha_mcp"],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=env,
    )
    try:
        yield proc
    finally:
        if proc.poll() is None:
            try:
                if proc.stdin is not None:
                    proc.stdin.close()
            except Exception:
                pass
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait(timeout=5)


def test_stdio_initialize_and_tools_list(server_proc: subprocess.Popen[bytes]) -> None:
    """Full MCP handshake then tools/list — all 39 tools must surface."""
    deadline = time.monotonic() + 30.0

    _send(
        server_proc,
        {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "initialize",
            "params": {
                "protocolVersion": PROTOCOL_VERSION,
                "capabilities": {},
                "clientInfo": {"name": "smoke-test", "version": "0.0.0"},
            },
        },
    )
    init_resp = _read_message(server_proc, deadline)
    assert init_resp.get("id") == 1, f"Bad initialize response: {init_resp}"
    assert "result" in init_resp, f"initialize returned error: {init_resp}"
    server_info = init_resp["result"]["serverInfo"]  # type: ignore[index]
    assert server_info["name"] == "twocaptcha-mcp"

    _send(
        server_proc,
        {"jsonrpc": "2.0", "method": "notifications/initialized"},
    )

    _send(server_proc, {"jsonrpc": "2.0", "id": 2, "method": "tools/list"})
    tools_resp = _read_message(server_proc, deadline)
    assert tools_resp.get("id") == 2, f"Bad tools/list response: {tools_resp}"
    tools = tools_resp["result"]["tools"]  # type: ignore[index]
    names = {t["name"] for t in tools}

    assert "twocaptcha_balance" in names
    assert "twocaptcha_solve_recaptcha" in names
    assert "twocaptcha_register_pingback" in names
    assert len(names) == 43, f"Expected 43 tools, got {len(names)}: {sorted(names)}"


def test_missing_api_key_exits_with_code_2(tmp_path) -> None:  # type: ignore[no-untyped-def]
    """When 2Captcha_API_KEY is unset, the entrypoint must fail with rc=2 (config error)."""
    env = {
        k: v
        for k, v in os.environ.items()
        if k.lower() not in {"2captcha_api_key", "twocaptcha_api_key", "api_key_2captcha"}
    }
    # Run from an empty temp directory so the project's .env is not picked up.
    proc = subprocess.run(
        [sys.executable, "-m", "twocaptcha_mcp"],
        env=env,
        cwd=str(tmp_path),
        capture_output=True,
        timeout=15,
        check=False,
    )
    assert proc.returncode == 2, (
        f"Expected exit code 2 on missing API key, got {proc.returncode}. "
        f"stderr: {proc.stderr.decode('utf-8', 'replace')}"
    )
    assert b"configuration error" in proc.stderr, proc.stderr
