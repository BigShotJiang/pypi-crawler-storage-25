"""Unit tests for the composite `solve_and_wait_pingback` tool."""

from __future__ import annotations

import asyncio
from pathlib import Path
from unittest.mock import AsyncMock

import pytest

from twocaptcha_mcp.client.errors import CaptchaTimeoutError
from twocaptcha_mcp.schemas.composite import SolveAndWaitPingbackRequest
from twocaptcha_mcp.tools import composite as composite_tool
from twocaptcha_mcp.tools.registry import ToolCtx
from twocaptcha_mcp.webhook_receiver.storage import EventStore


@pytest.fixture
def store_and_ctx(monkeypatch: pytest.MonkeyPatch, tmp_path: Path):  # type: ignore[no-untyped-def]
    db_path = tmp_path / "pb.db"
    store = EventStore(db_path)
    monkeypatch.setattr(composite_tool, "_store", lambda: EventStore(db_path))

    solver = AsyncMock()
    solver.send_raw = AsyncMock(return_value="captcha-id-1")
    ctx = ToolCtx(solver=solver, pingback=None)  # type: ignore[arg-type]
    return store, ctx


async def test_returns_when_event_already_present(store_and_ctx) -> None:  # type: ignore[no-untyped-def]
    store, ctx = store_and_ctx
    store.insert(captcha_id="captcha-id-1", code="solved", raw_body="id=captcha-id-1&code=solved")

    req = SolveAndWaitPingbackRequest(
        params={"method": "userrecaptcha", "googlekey": "k", "pageurl": "https://x.com/"},
        pingback_url="https://my.domain/2captcha/pingback",  # type: ignore[arg-type]
        timeout=30,
        poll_interval=0.5,
    )
    out = await composite_tool.solve_and_wait_pingback(req, ctx)
    assert out.captcha_id == "captcha-id-1"
    assert out.code == "solved"
    ctx.solver.send_raw.assert_awaited_once()


async def test_pingback_url_forwarded_to_send(store_and_ctx) -> None:  # type: ignore[no-untyped-def]
    store, ctx = store_and_ctx
    store.insert(captcha_id="captcha-id-1", code="ok", raw_body="id=captcha-id-1&code=ok")
    req = SolveAndWaitPingbackRequest(
        params={"method": "userrecaptcha", "googlekey": "k", "pageurl": "https://x.com/"},
        pingback_url="https://my.domain/2captcha/pingback",  # type: ignore[arg-type]
        timeout=10,
        poll_interval=0.5,
    )
    await composite_tool.solve_and_wait_pingback(req, ctx)
    sent_kwargs = ctx.solver.send_raw.await_args.kwargs
    assert sent_kwargs["pingback"] == "https://my.domain/2captcha/pingback"
    assert sent_kwargs["method"] == "userrecaptcha"


async def test_explicit_pingback_in_params_preserved(store_and_ctx) -> None:  # type: ignore[no-untyped-def]
    """If the caller already passed pingback in params we should NOT overwrite it."""
    store, ctx = store_and_ctx
    store.insert(captcha_id="captcha-id-1", code="ok", raw_body="id=captcha-id-1&code=ok")
    req = SolveAndWaitPingbackRequest(
        params={
            "method": "userrecaptcha",
            "googlekey": "k",
            "pageurl": "https://x.com/",
            "pingback": "https://override.example/2captcha/pingback",
        },
        pingback_url="https://my.domain/2captcha/pingback",  # type: ignore[arg-type]
        timeout=10,
        poll_interval=0.5,
    )
    await composite_tool.solve_and_wait_pingback(req, ctx)
    sent_kwargs = ctx.solver.send_raw.await_args.kwargs
    assert sent_kwargs["pingback"] == "https://override.example/2captcha/pingback"


async def test_polls_until_event_arrives(store_and_ctx) -> None:  # type: ignore[no-untyped-def]
    store, ctx = store_and_ctx

    async def _arrive_after_delay() -> None:
        await asyncio.sleep(0.6)
        store.insert(captcha_id="captcha-id-1", code="late", raw_body="id=captcha-id-1&code=late")

    arrival = asyncio.create_task(_arrive_after_delay())

    req = SolveAndWaitPingbackRequest(
        params={"method": "userrecaptcha", "googlekey": "k", "pageurl": "https://x.com/"},
        pingback_url="https://my.domain/2captcha/pingback",  # type: ignore[arg-type]
        timeout=10,
        poll_interval=0.5,
    )
    out = await composite_tool.solve_and_wait_pingback(req, ctx)
    assert out.code == "late"
    await arrival


async def test_timeout_raises_captcha_timeout_error(store_and_ctx) -> None:  # type: ignore[no-untyped-def]
    _store, ctx = store_and_ctx  # never insert anything
    req = SolveAndWaitPingbackRequest(
        params={"method": "userrecaptcha", "googlekey": "k", "pageurl": "https://x.com/"},
        pingback_url="https://my.domain/2captcha/pingback",  # type: ignore[arg-type]
        timeout=10,
        poll_interval=0.5,
    )
    with pytest.raises(CaptchaTimeoutError):
        # Use a tiny effective timeout to keep the test fast.
        await asyncio.wait_for(
            composite_tool.solve_and_wait_pingback(
                req.model_copy(update={"timeout": 1.0, "poll_interval": 0.5}), ctx
            ),
            timeout=5,
        )
