"""Tests for proxy-required solver tools (datadome, captchafox, vkcaptcha)."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest
from pydantic import ValidationError

from twocaptcha_mcp.schemas.proxy_required import (
    CaptchafoxRequest,
    DatadomeRequest,
    VkcaptchaRequest,
)
from twocaptcha_mcp.tools.proxy_required import (
    solve_captchafox,
    solve_datadome,
    solve_vkcaptcha,
)
from twocaptcha_mcp.tools.registry import ToolCtx


@pytest.fixture
def ctx() -> ToolCtx:
    solver = AsyncMock()
    solver.call = AsyncMock(return_value={"captchaId": "1", "code": "ok"})
    return ToolCtx(solver=solver, pingback=None)  # type: ignore[arg-type]


def test_datadome_proxy_required() -> None:
    with pytest.raises(ValidationError):
        DatadomeRequest.model_validate(
            {
                "captcha_url": "https://x.com/c",
                "pageurl": "https://x.com/",
                "user_agent": "UA",
            }
        )


def test_captchafox_user_agent_required() -> None:
    with pytest.raises(ValidationError):
        CaptchafoxRequest.model_validate(
            {
                "sitekey": "K",
                "pageurl": "https://x.com/",
                "proxy": {"type": "HTTP", "uri": "h:1"},
            }
        )


async def test_datadome_happy_path(ctx: ToolCtx) -> None:
    req = DatadomeRequest(
        proxy={"type": "HTTPS", "uri": "u:p@h:1"},  # type: ignore[arg-type]
        user_agent="UA",
        captcha_url="https://x.com/c",  # type: ignore[arg-type]
        pageurl="https://x.com/",  # type: ignore[arg-type]
    )
    await solve_datadome(req, ctx)
    name, kwargs = ctx.solver.call.await_args.args[0], ctx.solver.call.await_args.kwargs  # type: ignore[attr-defined]
    assert name == "datadome"
    assert kwargs["proxy"] == {"type": "HTTPS", "uri": "u:p@h:1"}
    assert kwargs["userAgent"] == "UA"
    assert kwargs["captcha_url"] == "https://x.com/c"
    assert kwargs["pageurl"] == "https://x.com/"


async def test_captchafox_happy_path(ctx: ToolCtx) -> None:
    req = CaptchafoxRequest(
        proxy={"type": "HTTP", "uri": "h:1"},  # type: ignore[arg-type]
        user_agent="UA",
        sitekey="K",
        pageurl="https://x.com/",  # type: ignore[arg-type]
    )
    await solve_captchafox(req, ctx)
    name, kwargs = ctx.solver.call.await_args.args[0], ctx.solver.call.await_args.kwargs  # type: ignore[attr-defined]
    assert name == "captchafox"
    assert kwargs["sitekey"] == "K"
    assert kwargs["userAgent"] == "UA"


async def test_vkcaptcha_happy_path(ctx: ToolCtx) -> None:
    req = VkcaptchaRequest(
        proxy={"type": "SOCKS5", "uri": "h:1080"},  # type: ignore[arg-type]
        user_agent="UA",
        redirect_uri="https://vk.com/redir",  # type: ignore[arg-type]
    )
    await solve_vkcaptcha(req, ctx)
    name, kwargs = ctx.solver.call.await_args.args[0], ctx.solver.call.await_args.kwargs  # type: ignore[attr-defined]
    assert name == "vkcaptcha"
    assert kwargs["redirect_uri"] == "https://vk.com/redir"
