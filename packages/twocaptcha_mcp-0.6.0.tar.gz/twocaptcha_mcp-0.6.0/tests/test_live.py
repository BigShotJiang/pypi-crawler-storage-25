"""Live integration tests against the real 2Captcha API.

Skipped by default; run with `pytest -m live --run-live`. Each `solve_*` test
consumes real 2Captcha credits (cents per solve). Keep this list short.

Image fixture: a known-stable demo captcha image hosted on 2Captcha's CDN.
"""

from __future__ import annotations

import asyncio
import contextlib
import os

import pytest

from twocaptcha_mcp.client import SolverClient
from twocaptcha_mcp.config import load_settings


def _api_key_present() -> bool:
    for var in (
        "2Captcha_API_KEY",
        "TWOCAPTCHA_API_KEY",
        "2CAPTCHA_API_KEY",
        "API_KEY_2CAPTCHA",
        "twocaptcha_api_key",
    ):
        if os.environ.get(var):
            return True
    # .env in cwd will also be picked up by pydantic-settings
    return os.path.exists(".env")


pytestmark = [
    pytest.mark.live,
    pytest.mark.skipif(
        not _api_key_present(),
        reason="2Captcha_API_KEY not configured (env or .env)",
    ),
]


@pytest.fixture
async def solver():  # type: ignore[no-untyped-def]
    s = SolverClient(load_settings())
    try:
        yield s
    finally:
        await s.aclose()


async def test_live_balance(solver: SolverClient) -> None:
    balance = await solver.balance()
    assert isinstance(balance, float)
    assert balance >= 0.0, f"balance must be non-negative, got {balance}"


def _generate_captcha_image_b64(text: str = "ABCD42") -> str:
    """Generate a simple captcha image with the given text and return its base64."""
    import base64
    import io

    from PIL import Image, ImageDraw, ImageFont

    img = Image.new("RGB", (200, 70), color=(245, 245, 245))
    draw = ImageDraw.Draw(img)
    try:
        font = ImageFont.truetype("arial.ttf", 38)
    except OSError:
        font = ImageFont.load_default()
    draw.text((20, 12), text, fill=(20, 20, 20), font=font)
    # Light noise — a few horizontal lines so 2Captcha treats it as a captcha.
    for y in (15, 30, 50):
        draw.line([(0, y), (200, y)], fill=(180, 180, 180), width=1)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return base64.b64encode(buf.getvalue()).decode("ascii")


async def test_live_pingback_crud(solver: SolverClient) -> None:
    """Real round-trip: add → list (sees us) → del → list (gone).

    Skipped automatically if the account's IP allowlist for pingback registrations
    is empty (yields ERROR_IP_ADDRES from 2Captcha) — this is an account
    configuration concern, not an implementation defect. To enable, whitelist
    your IP at https://2captcha.com/setting under "Pingback IP".
    """
    from twocaptcha_mcp.client import PingbackClient
    from twocaptcha_mcp.client.errors import CaptchaApiError

    test_url = "https://example.com/2captcha-mcp-test-do-not-call"
    pb = PingbackClient(load_settings())
    try:
        # Cleanup leftovers from previous failed runs.
        with contextlib.suppress(Exception):
            await pb.delete(test_url)

        try:
            registered = await pb.add(test_url)
        except CaptchaApiError as exc:
            if "IP_ADDRES" in str(exc) or "PINGBACK" in str(exc).upper():
                pytest.skip(
                    f"2Captcha rejected pingback registration ({exc}); "
                    "whitelist this IP at https://2captcha.com/setting"
                )
            raise

        assert registered

        urls = await pb.list()
        assert test_url in urls or any(test_url in u for u in urls), (
            f"registered URL not found in list: {urls}"
        )

        deleted = await pb.delete(test_url)
        assert deleted >= 0
    finally:
        await pb.aclose()


async def test_live_concurrent_balance(solver: SolverClient) -> None:
    """5 parallel `balance()` calls — must all return without rate-limit errors."""
    results = await asyncio.gather(*(solver.balance() for _ in range(5)))
    assert all(isinstance(b, float) and b >= 0 for b in results)


async def test_live_solve_normal(solver: SolverClient) -> None:
    """Send a generated captcha image; expect captchaId+non-empty code within ~120 s.

    We generate the image in-process to avoid depending on any external CDN that
    might rotate URLs. The text matters less than the round-trip itself — we
    verify auth + send + polling + response parsing end-to-end.
    """
    image_b64 = _generate_captcha_image_b64()
    result = await asyncio.wait_for(solver.call("normal", file=image_b64), timeout=180.0)

    assert "captchaId" in result, f"missing captchaId in response: {result}"
    assert "code" in result, f"missing code in response: {result}"
    assert isinstance(result["code"], str) and result["code"].strip(), (
        f"empty code in response: {result}"
    )
