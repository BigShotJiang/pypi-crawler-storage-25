"""Tests for management tools (balance, report, get_result, send_raw)."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from twocaptcha_mcp.schemas.management import (
    BalanceRequest,
    GetResultRequest,
    ReportRequest,
    SendRawRequest,
)
from twocaptcha_mcp.tools.management import (
    balance,
    get_result,
    report_bad,
    report_good,
    send_raw,
)
from twocaptcha_mcp.tools.registry import ToolCtx


@pytest.fixture
def ctx() -> ToolCtx:
    solver = AsyncMock()
    solver.balance = AsyncMock(return_value=12.5)
    solver.report = AsyncMock(return_value=None)
    solver.get_result = AsyncMock(return_value="solved!")
    solver.send_raw = AsyncMock(return_value="id-99")
    return ToolCtx(solver=solver, pingback=None)  # type: ignore[arg-type]


async def test_balance(ctx: ToolCtx) -> None:
    out = await balance(BalanceRequest(), ctx)
    assert out.balance == 12.5
    assert out.currency == "USD"


async def test_report_good(ctx: ToolCtx) -> None:
    out = await report_good(ReportRequest(captcha_id="id-1"), ctx)
    ctx.solver.report.assert_awaited_once_with("id-1", correct=True)  # type: ignore[attr-defined]
    assert out.correct is True


async def test_report_bad(ctx: ToolCtx) -> None:
    out = await report_bad(ReportRequest(captcha_id="id-1"), ctx)
    ctx.solver.report.assert_awaited_once_with("id-1", correct=False)  # type: ignore[attr-defined]
    assert out.correct is False


async def test_get_result(ctx: ToolCtx) -> None:
    out = await get_result(GetResultRequest(captcha_id="id-1"), ctx)
    assert out.code == "solved!"


async def test_send_raw_with_file_b64(ctx: ToolCtx) -> None:
    req = SendRawRequest(params={"method": "userrecaptcha"}, file_base64="ZA==")
    out = await send_raw(req, ctx)
    assert out.captcha_id == "id-99"
    kwargs = ctx.solver.send_raw.await_args.kwargs  # type: ignore[attr-defined]
    assert kwargs["method"] == "userrecaptcha"
    assert kwargs["body"] == "ZA=="


async def test_send_raw_without_file(ctx: ToolCtx) -> None:
    await send_raw(SendRawRequest(params={"method": "turnstile"}), ctx)
    kwargs = ctx.solver.send_raw.await_args.kwargs  # type: ignore[attr-defined]
    assert "body" not in kwargs
