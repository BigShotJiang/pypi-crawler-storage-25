"""Tests for twocaptcha_mcp.server.dispatch_tool_call."""

from __future__ import annotations

import json

import pytest
from pydantic import Field

from twocaptcha_mcp.client import (
    CaptchaApiError,
    CaptchaNetworkError,
    CaptchaTimeoutError,
    CaptchaValidationError,
)
from twocaptcha_mcp.schemas.common import CaptchaModel
from twocaptcha_mcp.server import dispatch_tool_call
from twocaptcha_mcp.tools.registry import (
    ToolCtx,
    all_tools,
    captcha_tool,
)


class _FakeIn(CaptchaModel):
    n: int = Field(ge=0)


class _FakeOut(CaptchaModel):
    n: int


@pytest.fixture(autouse=True)
def _isolated_registry():  # type: ignore[no-untyped-def]
    """Snapshot global registry, run with empty one, restore after the test."""
    from twocaptcha_mcp.tools import registry as _registry_module

    snapshot = dict(_registry_module._REGISTRY)
    _registry_module._REGISTRY.clear()
    try:
        yield
    finally:
        _registry_module._REGISTRY.clear()
        _registry_module._REGISTRY.update(snapshot)


@pytest.fixture
def ctx() -> ToolCtx:
    # Solver/Pingback never invoked in dispatcher tests.
    return ToolCtx(solver=None, pingback=None)  # type: ignore[arg-type]


async def test_happy_path(ctx: ToolCtx) -> None:
    @captcha_tool(
        name="t_ok",
        description="ok",
        input_schema=_FakeIn,
        output_schema=_FakeOut,
    )
    async def handler(req: _FakeIn, _: ToolCtx) -> _FakeOut:
        return _FakeOut(n=req.n + 1)

    by_name = {t.name: t for t in all_tools()}
    out = await dispatch_tool_call("t_ok", {"n": 41}, tools_by_name=by_name, ctx=ctx)
    assert len(out) == 1
    payload = json.loads(out[0].text)  # type: ignore[attr-defined]
    assert payload == {"n": 42}


async def test_validation_error_returns_invalid_argument(ctx: ToolCtx) -> None:
    @captcha_tool(
        name="t_v",
        description="",
        input_schema=_FakeIn,
        output_schema=_FakeOut,
    )
    async def handler(req: _FakeIn, _: ToolCtx) -> _FakeOut:
        return _FakeOut(n=req.n)

    by_name = {t.name: t for t in all_tools()}
    out = await dispatch_tool_call("t_v", {"n": -5}, tools_by_name=by_name, ctx=ctx)
    assert "invalid_argument" in out[0].text  # type: ignore[attr-defined]


@pytest.mark.parametrize(
    "exc_cls, prefix",
    [
        (CaptchaValidationError, "invalid_argument"),
        (CaptchaTimeoutError, "timeout_error"),
        (CaptchaNetworkError, "network_error"),
        (CaptchaApiError, "api_error"),
    ],
)
async def test_known_errors_mapped(ctx: ToolCtx, exc_cls: type[Exception], prefix: str) -> None:
    @captcha_tool(
        name=f"t_err_{prefix}",
        description="",
        input_schema=_FakeIn,
        output_schema=_FakeOut,
    )
    async def handler(req: _FakeIn, _: ToolCtx) -> _FakeOut:
        raise exc_cls("boom")

    by_name = {t.name: t for t in all_tools()}
    out = await dispatch_tool_call(f"t_err_{prefix}", {"n": 1}, tools_by_name=by_name, ctx=ctx)
    assert out[0].text.startswith(f"{prefix}: ")  # type: ignore[attr-defined]


async def test_unknown_tool_raises(ctx: ToolCtx) -> None:
    with pytest.raises(ValueError):
        await dispatch_tool_call("missing", {}, tools_by_name={}, ctx=ctx)


async def test_internal_error_caught(ctx: ToolCtx) -> None:
    @captcha_tool(
        name="t_boom",
        description="",
        input_schema=_FakeIn,
        output_schema=_FakeOut,
    )
    async def handler(req: _FakeIn, _: ToolCtx) -> _FakeOut:
        raise RuntimeError("oops")

    by_name = {t.name: t for t in all_tools()}
    out = await dispatch_tool_call("t_boom", {"n": 1}, tools_by_name=by_name, ctx=ctx)
    assert out[0].text.startswith("internal_error: ")  # type: ignore[attr-defined]
