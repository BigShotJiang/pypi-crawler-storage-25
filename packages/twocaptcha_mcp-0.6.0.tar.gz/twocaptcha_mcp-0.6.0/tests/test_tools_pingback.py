"""Tests for pingback CRUD tools."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from twocaptcha_mcp.schemas.pingback import (
    DeletePingbackRequest,
    ListPingbacksRequest,
    RegisterPingbackRequest,
)
from twocaptcha_mcp.tools.pingback import (
    delete_pingback,
    list_pingbacks,
    register_pingback,
)
from twocaptcha_mcp.tools.registry import ToolCtx


@pytest.fixture
def ctx() -> ToolCtx:
    pb = AsyncMock()
    pb.add = AsyncMock(return_value="https://example.com/p")
    pb.list = AsyncMock(return_value=["https://a.com", "https://b.com"])
    pb.delete = AsyncMock(return_value=2)
    return ToolCtx(solver=None, pingback=pb)  # type: ignore[arg-type]


async def test_register(ctx: ToolCtx) -> None:
    out = await register_pingback(
        RegisterPingbackRequest(addr="https://example.com/p"),
        ctx,  # type: ignore[arg-type]
    )
    ctx.pingback.add.assert_awaited_once_with("https://example.com/p")  # type: ignore[attr-defined]
    assert out.addr == "https://example.com/p"


async def test_list(ctx: ToolCtx) -> None:
    out = await list_pingbacks(ListPingbacksRequest(), ctx)
    assert out.pingbacks == ["https://a.com", "https://b.com"]


async def test_delete_one(ctx: ToolCtx) -> None:
    await delete_pingback(
        DeletePingbackRequest(addr="https://x.com/p"),
        ctx,  # type: ignore[arg-type]
    )
    ctx.pingback.delete.assert_awaited_once_with("https://x.com/p")  # type: ignore[attr-defined]


async def test_delete_all(ctx: ToolCtx) -> None:
    out = await delete_pingback(DeletePingbackRequest(addr="all"), ctx)
    ctx.pingback.delete.assert_awaited_once_with("all")  # type: ignore[attr-defined]
    assert out.deleted == 2
