"""Unit tests for `twocaptcha_mcp/webhook_receiver/__main__.py` — closes 0 % coverage gap."""

from __future__ import annotations

from typing import Any
from unittest.mock import MagicMock

import pytest
from pydantic import ValidationError

from twocaptcha_mcp.webhook_receiver import __main__ as wh_main


@pytest.fixture(autouse=True)
def _strip_keys(monkeypatch: pytest.MonkeyPatch) -> None:
    for var in (
        "2Captcha_API_KEY",
        "TWOCAPTCHA_API_KEY",
        "2CAPTCHA_API_KEY",
        "API_KEY_2CAPTCHA",
        "twocaptcha_api_key",
    ):
        monkeypatch.delenv(var, raising=False)


def test_parse_args_defaults(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr("sys.argv", ["twocaptcha-mcp-webhook"])
    args = wh_main._parse_args()
    assert args.host is None
    assert args.port is None
    assert args.public_url is None


def test_parse_args_overrides(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        "sys.argv",
        [
            "twocaptcha-mcp-webhook",
            "--host",
            "0.0.0.0",
            "--port",
            "9999",
            "--public-url",
            "https://my.example.com/2captcha/pingback",
        ],
    )
    args = wh_main._parse_args()
    assert args.host == "0.0.0.0"
    assert args.port == 9999
    assert args.public_url == "https://my.example.com/2captcha/pingback"


def test_main_exits_2_on_missing_config(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path,  # type: ignore[no-untyped-def]
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr("sys.argv", ["twocaptcha-mcp-webhook"])
    with pytest.raises(SystemExit) as ei:
        wh_main.main()
    assert ei.value.code == 2
    assert "configuration error" in capsys.readouterr().err


def test_main_happy_path_calls_uvicorn_run(monkeypatch: pytest.MonkeyPatch, tmp_path) -> None:  # type: ignore[no-untyped-def]
    monkeypatch.setenv("2Captcha_API_KEY", "k")
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(
        "sys.argv", ["twocaptcha-mcp-webhook", "--host", "127.0.0.1", "--port", "1"]
    )

    captured: dict[str, Any] = {}

    def _fake_run(app: object, *, host: str, port: int, log_level: str) -> None:
        captured["app"] = app
        captured["host"] = host
        captured["port"] = port
        captured["log_level"] = log_level

    monkeypatch.setattr(wh_main, "uvicorn", MagicMock(run=_fake_run))
    monkeypatch.setattr(wh_main, "create_app", lambda settings: object())

    wh_main.main()
    assert captured["host"] == "127.0.0.1"
    assert captured["port"] == 1
    assert captured["log_level"] == "info"


def test_main_propagates_validation_error(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path,  # type: ignore[no-untyped-def]
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.setattr("sys.argv", ["twocaptcha-mcp-webhook"])
    monkeypatch.chdir(tmp_path)

    err = ValidationError.from_exception_data(
        "Settings", [{"type": "missing", "loc": ("twocaptcha_api_key",)}]
    )

    def _raise() -> None:
        raise err

    monkeypatch.setattr(wh_main, "load_settings", _raise)
    with pytest.raises(SystemExit) as ei:
        wh_main.main()
    assert ei.value.code == 2
    assert "configuration error" in capsys.readouterr().err
