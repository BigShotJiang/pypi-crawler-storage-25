"""Unit tests for the pingback receiver MCP tools."""

from __future__ import annotations

import time
from pathlib import Path

import pytest

from twocaptcha_mcp.schemas.webhook import (
    PingbackEventsClearRequest,
    PingbackEventsGetRequest,
    PingbackEventsListRequest,
)
from twocaptcha_mcp.webhook_receiver import tools as wh_tools
from twocaptcha_mcp.webhook_receiver.storage import EventStore


@pytest.fixture
def configured_store(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> EventStore:
    """Point both `_store()` calls (in production) at a tmp SQLite database."""
    db_path = tmp_path / "pb.db"
    monkeypatch.setattr(wh_tools, "_store", lambda: EventStore(db_path))
    return EventStore(db_path)


async def test_events_list_empty(configured_store: EventStore) -> None:
    out = await wh_tools.pingback_events_list(PingbackEventsListRequest(), None)  # type: ignore[arg-type]
    assert out.count == 0
    assert out.events == []


async def test_events_list_returns_inserted(configured_store: EventStore) -> None:
    configured_store.insert(captcha_id="c1", code="x", raw_body="id=c1&code=x")
    configured_store.insert(captcha_id="c2", code="y", raw_body="id=c2&code=y")
    out = await wh_tools.pingback_events_list(PingbackEventsListRequest(limit=10), None)  # type: ignore[arg-type]
    assert out.count == 2
    assert {e.captcha_id for e in out.events} == {"c1", "c2"}


async def test_events_get_existing(configured_store: EventStore) -> None:
    configured_store.insert(captcha_id="abc", code="solved", raw_body="id=abc&code=solved")
    out = await wh_tools.pingback_events_get(PingbackEventsGetRequest(captcha_id="abc"), None)  # type: ignore[arg-type]
    assert out.event is not None
    assert out.event.code == "solved"


async def test_events_get_missing(configured_store: EventStore) -> None:
    out = await wh_tools.pingback_events_get(PingbackEventsGetRequest(captcha_id="?"), None)  # type: ignore[arg-type]
    assert out.event is None


async def test_events_clear_specific_captcha(configured_store: EventStore) -> None:
    for cid in ("a", "b", "c"):
        configured_store.insert(captcha_id=cid, code=cid, raw_body=f"id={cid}&code={cid}")
    out = await wh_tools.pingback_events_clear(
        PingbackEventsClearRequest(captcha_id="b"),
        None,  # type: ignore[arg-type]
    )
    assert out.deleted == 1


async def test_events_clear_before_timestamp(configured_store: EventStore) -> None:
    configured_store.insert(captcha_id="old", code="x", raw_body="id=old")
    cutoff = int(time.time())
    time.sleep(1.1)
    configured_store.insert(captcha_id="new", code="y", raw_body="id=new")
    out = await wh_tools.pingback_events_clear(
        PingbackEventsClearRequest(before_received_at=cutoff + 1),
        None,  # type: ignore[arg-type]
    )
    # Both might be deleted depending on time → be permissive but require ≥ 1 old gone.
    assert out.deleted >= 1
