"""Snapshot of the public AsyncTwoCaptcha surface used by SolverClient.

Catches:
    1. Removal or rename of any solver method we expose as an MCP tool.
    2. Removal or rename of management methods (balance, report, send, get_result).
    3. Internal restructure of `twocaptcha.exceptions` (we re-import via top-level twocaptcha).

Sourced from `docs/reports/Claude Code/0.1.0_research.md` § 1.2 — 31 solver methods +
4 management methods. Update intentionally when we add support for new SDK methods.
"""

from __future__ import annotations

from twocaptcha import (  # type: ignore[import-not-found]
    ApiException,
    AsyncTwoCaptcha,
    NetworkException,
    TimeoutException,
    ValidationException,
)

REQUIRED_SOLVER_METHODS: frozenset[str] = frozenset(
    {
        "altcha",
        "amazon_waf",
        "atb_captcha",
        "audio",
        "canvas",
        "capy",
        "captchafox",
        "coordinates",
        "cutcaptcha",
        "cybersiara",
        "datadome",
        "friendly_captcha",
        "funcaptcha",
        "geetest",
        "geetest_v4",
        "grid",
        "hcaptcha",
        "keycaptcha",
        "lemin",
        "mtcaptcha",
        "normal",
        "prosopo",
        "recaptcha",
        "rotate",
        "temu",
        "tencent",
        "text",
        "turnstile",
        "vkcaptcha",
        "vkimage",
        "yandex_smart",
    }
)

REQUIRED_MANAGEMENT_METHODS: frozenset[str] = frozenset({"balance", "report", "send", "get_result"})

REQUIRED_EXCEPTIONS: frozenset[str] = frozenset(
    {"ValidationException", "NetworkException", "TimeoutException", "ApiException"}
)


def _public_async_methods(cls: type) -> set[str]:
    out: set[str] = set()
    for name in dir(cls):
        if name.startswith("_"):
            continue
        attr = getattr(cls, name)
        if callable(attr):
            out.add(name)
    return out


def test_all_solver_methods_present() -> None:
    available = _public_async_methods(AsyncTwoCaptcha)
    missing = REQUIRED_SOLVER_METHODS - available
    assert not missing, (
        f"AsyncTwoCaptcha is missing expected solver methods: {sorted(missing)}. "
        "If the SDK renamed/removed them, update REQUIRED_SOLVER_METHODS and the "
        "matching tool module."
    )


def test_all_management_methods_present() -> None:
    available = _public_async_methods(AsyncTwoCaptcha)
    missing = REQUIRED_MANAGEMENT_METHODS - available
    assert not missing, f"AsyncTwoCaptcha is missing management methods: {sorted(missing)}"


def test_exceptions_importable_from_top_level() -> None:
    """SDK 2.0.x reorganised exceptions — they must remain importable from `twocaptcha`."""
    available = {
        "ValidationException": ValidationException,
        "NetworkException": NetworkException,
        "TimeoutException": TimeoutException,
        "ApiException": ApiException,
    }
    for name in REQUIRED_EXCEPTIONS:
        cls = available[name]
        assert isinstance(cls, type), f"{name} is not a class"
        assert issubclass(cls, Exception), f"{name} does not derive from Exception"


def test_no_unexpected_methods_used_internally() -> None:
    """Cross-check: every method referenced by `tools/__init__.py` exists in SDK."""
    from twocaptcha_mcp.tools import load_all_tool_modules

    load_all_tool_modules()
    available = _public_async_methods(AsyncTwoCaptcha)
    for name in REQUIRED_SOLVER_METHODS | REQUIRED_MANAGEMENT_METHODS:
        assert name in available, f"Tool layer expects SDK method {name!r} which no longer exists"
