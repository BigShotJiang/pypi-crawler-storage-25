import sqlite3
import struct

import numpy as np

from shrot.circular_sequence import CircularSequence, SynapseMeasurement, SynapseMission
from shrot.shrot import RFSequence


def _create_test_db(path, frames):
    """Create a radar.db with the given list of (rx1, rx2) tuples."""
    conn = sqlite3.connect(path)
    conn.execute(
        """CREATE TABLE frames (
            frame_counter INTEGER,
            polarization  TEXT,
            adc1_level    INTEGER,
            adc2_level    INTEGER,
            cpu_temp      REAL,
            board_temp    REAL,
            timestamp_ns  INTEGER,
            rx1           BLOB,
            rx2           BLOB
        )"""
    )
    for i, (rx1, rx2) in enumerate(frames):
        n = len(rx1)
        conn.execute(
            "INSERT INTO frames VALUES (?,?,?,?,?,?,?,?,?)",
            (
                i,
                "HHH",
                50,
                60,
                42.0,
                38.0,
                1000000 * i,
                struct.pack(f"<{n}i", *rx1),
                struct.pack(f"<{n}i", *rx2),
            ),
        )
    conn.commit()
    conn.close()


def test_from_synapse_file_reads_single_frame(tmp_path):
    db_path = tmp_path / "radar.db"
    rx1 = [100, 200, 300, 400]
    rx2 = [500, 600, 700, 800]
    _create_test_db(str(db_path), [(rx1, rx2)])

    measurements = CircularSequence.from_synapse_file(str(db_path))
    assert len(measurements) == 1
    m = measurements[0]
    assert isinstance(m, SynapseMeasurement)
    np.testing.assert_array_equal(m.rx_1.values, np.array(rx1, dtype=np.float64))
    np.testing.assert_array_equal(m.rx_2.values, np.array(rx2, dtype=np.float64))


def test_from_synapse_file_reads_multiple_frames(tmp_path):
    db_path = tmp_path / "radar.db"
    frames = [
        ([i * 10 + j for j in range(8)], [i * 100 + j for j in range(8)])
        for i in range(5)
    ]
    _create_test_db(str(db_path), frames)

    measurements = CircularSequence.from_synapse_file(str(db_path))
    assert len(measurements) == 5
    for i, m in enumerate(measurements):
        expected_rx1 = np.array([i * 10 + j for j in range(8)], dtype=np.float64)
        np.testing.assert_array_equal(m.rx_1.values, expected_rx1)


def test_from_synapse_file_empty_db(tmp_path):
    db_path = tmp_path / "radar.db"
    _create_test_db(str(db_path), [])

    measurements = CircularSequence.from_synapse_file(str(db_path))
    assert measurements == []


def test_rfsequence_from_synapse_file(tmp_path):
    """Test that RFSequence.from_synapse_file also works (shrot.py version)."""
    db_path = tmp_path / "radar.db"
    rx1 = [10, 20, 30, 40]
    rx2 = [50, 60, 70, 80]
    _create_test_db(str(db_path), [(rx1, rx2)])

    measurements = RFSequence.from_synapse_file(str(db_path))
    assert len(measurements) == 1
    np.testing.assert_array_equal(
        measurements[0].rx_1.values, np.array(rx1, dtype=np.float64)
    )


def _create_mission_dir(tmp_path, frames, mission_id="test-mission-123"):
    """Create a mission directory with mission.db (metadata + radar frames)."""
    mission_dir = tmp_path / mission_id
    mission_dir.mkdir()
    db_path = str(mission_dir / "mission.db")
    conn = sqlite3.connect(db_path)
    conn.execute("CREATE TABLE metadata (key TEXT PRIMARY KEY, value TEXT)")
    conn.execute(
        "INSERT INTO metadata VALUES (?, ?)", ("mission_id", f'"{mission_id}"')
    )
    conn.execute(
        "INSERT INTO metadata VALUES (?, ?)", ("date", '"2026-05-03T00:00:00"')
    )
    conn.execute(
        """CREATE TABLE frames (
            frame_counter INTEGER,
            polarization  TEXT,
            adc1_level    INTEGER,
            adc2_level    INTEGER,
            cpu_temp      REAL,
            board_temp    REAL,
            timestamp_ns  INTEGER,
            rx1           BLOB,
            rx2           BLOB
        )"""
    )
    conn.execute("CREATE TABLE rtk_frames (timestamp_ns INTEGER, data BLOB)")
    for i, (rx1, rx2) in enumerate(frames):
        n = len(rx1)
        conn.execute(
            "INSERT INTO frames VALUES (?,?,?,?,?,?,?,?,?)",
            (
                i,
                "HHH",
                50,
                60,
                42.0,
                38.0,
                1000000 * i,
                struct.pack(f"<{n}i", *rx1),
                struct.pack(f"<{n}i", *rx2),
            ),
        )
    conn.commit()
    conn.close()
    return mission_dir


def test_synapse_mission_load(tmp_path):
    frames = [
        ([100, 200, 300], [400, 500, 600]),
        ([700, 800, 900], [10, 20, 30]),
    ]
    mission_dir = _create_mission_dir(tmp_path, frames)

    mission = SynapseMission.load(mission_dir)
    assert mission.mission_id == "test-mission-123"
    assert mission.date == "2026-05-03T00:00:00"
    assert len(mission.measurements) == 2
    assert mission.polarizations == ["HHH", "HHH"]
    assert mission.timestamps_ns == [0, 1000000]
    np.testing.assert_array_equal(
        mission.measurements[0].rx_1.values, np.array([100, 200, 300], dtype=np.float64)
    )


def test_synapse_mission_load_empty(tmp_path):
    mission_dir = _create_mission_dir(tmp_path, [])
    mission = SynapseMission.load(mission_dir)
    assert mission.measurements == []
    assert mission.polarizations == []


def test_synapse_mission_load_no_db(tmp_path):
    import pytest

    mission_dir = tmp_path / "empty-mission"
    mission_dir.mkdir()

    with pytest.raises(FileNotFoundError):
        SynapseMission.load(mission_dir)
