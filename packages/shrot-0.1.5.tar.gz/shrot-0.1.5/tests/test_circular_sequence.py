import matplotlib
import numpy as np
import pytest

matplotlib.use("Agg", force=True)
import matplotlib.pyplot as plt

from shrot.circular_sequence import RADAR_SAMPLING_FREQUENCY, CircularSequence


def make_sequence(values, sampling_frequency=8.0):
    return CircularSequence.from_values(
        np.array(values, dtype=float), sampling_frequency
    )


def test_from_values_sets_metadata_and_fft():
    values = np.array([1.0, -2.0, 3.5, 0.5])
    seq = CircularSequence.from_values(values, sampling_frequency=16.0)

    assert seq.n_samples == 4
    assert seq.sampling_frequency == 16.0
    assert np.allclose(seq.values, values)
    assert np.allclose(seq.ft, np.fft.fft(values))


def test_from_ft_reconstructs_values():
    values = np.array([0.0, 1.0, 0.5, -1.0])
    ft = np.fft.fft(values)

    seq = CircularSequence.from_ft(ft, sampling_frequency=8.0, n_samples=len(values))

    assert seq.n_samples == len(values)
    assert np.allclose(seq.values, values)
    assert np.allclose(seq.ft, ft)


def test_zero_factory_creates_zero_sequence():
    seq = CircularSequence.zero(sampling_frequency=4.0, n_samples=5)

    assert seq.n_samples == 5
    assert np.allclose(seq.values, np.zeros(5))
    assert np.allclose(seq.ft, np.zeros(5))


def test_str_and_repr_are_consistent():
    seq = make_sequence([1.0, 2.0])

    assert str(seq).startswith("CircularSequence(")
    assert repr(seq) == str(seq)


def test_addition_and_subtraction():
    left = make_sequence([1, 2, 3, 4])
    right = make_sequence([4, 3, 2, 1])

    summed = left + right
    diff = left - right

    assert np.allclose(summed.values, np.array([5, 5, 5, 5]))
    assert np.allclose(diff.values, np.array([-3, -1, 1, 3]))


def test_addition_validates_sampling_frequency_and_length():
    seq = make_sequence([1, 2, 3])
    different_sf = make_sequence([1, 2, 3], sampling_frequency=9.0)
    different_len = make_sequence([1, 2, 3, 4])

    with pytest.raises(ValueError, match="sampling frequencies"):
        _ = seq + different_sf

    with pytest.raises(ValueError, match="different length"):
        _ = seq + different_len


def test_multiplication_and_division():
    seq = make_sequence([2, -4, 6])

    multiplied = seq * 2
    divided = seq / 2

    assert np.allclose(multiplied.values, np.array([4, -8, 12]))
    assert np.allclose(divided.values, np.array([1, -2, 3]))


def test_scalar_operations_validate_input():
    seq = make_sequence([1, 2, 3])

    with pytest.raises(TypeError, match="not supported"):
        _ = seq * "x"

    with pytest.raises(TypeError, match="not supported"):
        _ = seq / "x"

    with pytest.raises(ZeroDivisionError, match="zero"):
        _ = seq / 0


def test_right_and_left_shift_are_circular():
    seq = make_sequence([1, 0, 0, 0], sampling_frequency=4.0)
    one_sample = 1 / seq.sampling_frequency

    shifted_right = seq >> one_sample
    shifted_back = shifted_right << one_sample

    assert np.allclose(shifted_right.values, np.array([0, 1, 0, 0]), atol=1e-9)
    assert np.allclose(shifted_back.values, seq.values, atol=1e-9)


def test_duration_property():
    seq = make_sequence([1, 2, 3, 4], sampling_frequency=2.0)

    assert seq.duration == 2.0


def test_correlation_and_matmul_alias():
    first = make_sequence([1, -1, 0, 2])
    second = make_sequence([0.5, 3, -1, 1])

    corr = first.correlation(second)
    via_matmul = first @ second

    expected = np.real(
        np.fft.ifft(np.conj(np.fft.fft(first.values)) * np.fft.fft(second.values), 4)
    )

    assert np.allclose(corr.values, expected)
    assert np.allclose(via_matmul.values, corr.values)


def test_correlation_validates_inputs_and_supports_small_sf_diff():
    base = make_sequence([1, 2, 3], sampling_frequency=10.0)
    close = make_sequence([1, 2, 3], sampling_frequency=9.0)
    far = make_sequence([1, 2, 3], sampling_frequency=7.0)
    different_len = make_sequence([1, 2, 3, 4], sampling_frequency=10.0)

    assert isinstance(base.correlation(close), CircularSequence)

    with pytest.raises(ValueError, match="sampling frequencies"):
        _ = base.correlation(far)

    with pytest.raises(NotImplementedError, match="different length"):
        _ = base.correlation(different_len)


def test_correlation_switch_sequences_changes_formula():
    first = make_sequence([1, -1, 2, 0])
    second = make_sequence([0, 2, -1, 0.5])

    switched = first.correlation(second, switch_sequences=True)

    expected = np.real(
        np.fft.ifft(np.fft.fft(first.values) * np.conj(np.fft.fft(second.values)), 4)
    )

    assert np.allclose(switched.values, expected)


def test_filter_updates_sequence_in_place():
    seq = make_sequence([1, 2, 3, 4], sampling_frequency=4.0)

    seq.filter(lambda frequencies: np.where(frequencies == 0, 1, 0))

    assert np.allclose(seq.values, np.full(4, 2.5))
    assert np.allclose(seq.ft[1:], 0)


def test_filtered_returns_new_sequence_without_mutating_source():
    source = make_sequence([1, 2, 3, 4], sampling_frequency=4.0)

    filtered = source.filtered(lambda frequencies: np.zeros_like(frequencies))

    assert np.allclose(filtered.values, np.zeros(4))
    assert np.allclose(source.values, np.array([1, 2, 3, 4], dtype=float))


def test_plot_adds_line_to_axis():
    seq = make_sequence([1, 3, 2, 4], sampling_frequency=2.0)
    fig, ax = plt.subplots()

    seq.plot(ax=ax)

    assert len(ax.lines) == 1
    x_data = ax.lines[0].get_xdata()
    y_data = ax.lines[0].get_ydata()
    assert len(x_data) == seq.n_samples
    assert np.allclose(y_data, seq.values)
    plt.close(fig)


def test_from_synapse_file_parses_csv(tmp_path):
    import sqlite3
    import struct

    db_path = tmp_path / "radar.db"
    conn = sqlite3.connect(str(db_path))
    conn.execute(
        """CREATE TABLE frames (
            frame_counter INTEGER, polarization TEXT,
            adc1_level INTEGER, adc2_level INTEGER,
            cpu_temp REAL, board_temp REAL,
            timestamp_ns INTEGER, rx1 BLOB, rx2 BLOB
        )"""
    )
    conn.execute(
        "INSERT INTO frames VALUES (?,?,?,?,?,?,?,?,?)",
        (
            0,
            "HHH",
            50,
            60,
            42.0,
            38.0,
            0,
            struct.pack("<2i", 1, 2),
            struct.pack("<2i", 10, 20),
        ),
    )
    conn.commit()
    conn.close()

    measurements = CircularSequence.from_synapse_file(db_path)
    assert len(measurements) == 1
    measurement = measurements[0]
    assert np.allclose(measurement.rx_1.values, np.array([1, 2]))
    assert np.allclose(measurement.rx_2.values, np.array([10, 20]))
    assert measurement.rx_1.sampling_frequency == RADAR_SAMPLING_FREQUENCY
    assert measurement.rx_2.sampling_frequency == RADAR_SAMPLING_FREQUENCY
