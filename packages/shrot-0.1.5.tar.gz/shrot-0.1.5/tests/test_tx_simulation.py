import numpy as np
import pytest

from shrot import tx_simulation as tx_module

generate_next_m_sequence_value = tx_module.generate_next_m_sequence_value
generate_m_sequence = tx_module.generate_m_sequence


def test_generate_next_m_sequence_value_uses_taps_formula():
    m_sequence = np.array([1, -1, 1, 1, -1], dtype=int)
    taps = [1, 3]

    expected = (m_sequence[-1] + m_sequence[-3] + len(taps)) % 4 - 1

    assert generate_next_m_sequence_value(m_sequence, taps) == expected


def test_generate_m_sequence_rejects_non_sequence_initial_state():
    with pytest.raises(TypeError, match="initial state"):
        _ = generate_m_sequence(
            sampling_frequency=10.0,
            taps=[1],
            initial_state=5,
        )


def test_generate_m_sequence_minimal_order_raises_for_zero_length_fft():
    seq = generate_m_sequence(
        sampling_frequency=5.0,
        taps=[1],
        initial_state=[1],
    )
    assert seq.n_samples == 1
    assert np.array_equal(seq.values, np.array([1.0]))


def test_generate_m_sequence_calls_next_value_expected_times(monkeypatch):
    calls = []

    def fake_next_value(m_sequence, taps):
        calls.append(tuple(taps))
        return 1

    monkeypatch.setattr(tx_module, "generate_next_m_sequence_value", fake_next_value)

    sequence = generate_m_sequence(
        sampling_frequency=20.0,
        taps=[1, 3],
        initial_state=[1, 1, 1],
    )

    assert len(calls) == 4
    assert all(call == (1, 3) for call in calls)
    assert np.array_equal(sequence.values, np.ones(7, dtype=int))


def test_generate_m_sequence_defaults(monkeypatch):
    calls = []

    def fake_next_value(m_sequence, taps):
        calls.append(tuple(taps))
        return -1

    monkeypatch.setattr(tx_module, "generate_next_m_sequence_value", fake_next_value)

    sequence = generate_m_sequence(sampling_frequency=2.0)

    assert len(calls) == 502
    assert all(call == (4, 9) for call in calls)
    assert sequence.n_samples == 511
    assert np.array_equal(sequence.values[:9], np.ones(9, dtype=int))
    assert np.array_equal(sequence.values[9:], np.full(502, -1, dtype=int))
