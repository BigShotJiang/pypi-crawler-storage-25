def test_exists():
    import shrot

    assert shrot is not None
