# shrot
Processing library for Aerostacks mission data
