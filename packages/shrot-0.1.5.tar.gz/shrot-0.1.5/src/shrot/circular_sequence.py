from __future__ import annotations

import dataclasses
import json
import sqlite3
import struct
from pathlib import Path

import numpy as np
import numpy.fft as fft
from typing import Self, Callable
from os import PathLike
import matplotlib.pyplot as plt

RADAR_SAMPLING_FREQUENCY = 13.312e9  # TODO nech to vzdy cita zo suboru napisaneho synapse lebo je to configurable


@dataclasses.dataclass
class SynapseMeasurement:
    rx_1: CircularSequence
    rx_2: CircularSequence


class CircularSequence:
    sampling_frequency: float
    n_samples: int
    values: np.ndarray
    ft: np.ndarray

    def __init__(self, values: np.ndarray, ft: np.ndarray, sampling_frequency: float):
        self.n_samples = len(values)
        self.sampling_frequency = sampling_frequency
        self.values = values
        self.ft = ft

    @classmethod
    def from_values(cls, values: np.ndarray, sampling_frequency: float) -> Self:
        return cls(values, fft.fft(values), sampling_frequency)

    @classmethod
    def from_ft(cls, ft: np.ndarray, sampling_frequency: float, n_samples: int) -> Self:
        return cls(np.real(fft.ifft(ft, n_samples)), ft, sampling_frequency)

    @classmethod
    def zero(cls, sampling_frequency: float, n_samples: int) -> Self:
        return cls.from_values(np.zeros(n_samples), sampling_frequency)

    @classmethod
    def from_synapse_file(cls, path: PathLike) -> list[SynapseMeasurement]:
        """Read all radar frames from a synapse SQLite database.

        :param path: Path to the radar.db SQLite file
        :return: List of SynapseMeasurement, one per frame
        """
        conn = sqlite3.connect(path)
        rows = conn.execute("SELECT rx1, rx2 FROM frames").fetchall()
        conn.close()
        measurements = []
        for rx1_blob, rx2_blob in rows:
            n = len(rx1_blob) // 4
            rx1 = np.array(struct.unpack(f"<{n}i", rx1_blob), dtype=np.float64)
            rx2 = np.array(struct.unpack(f"<{n}i", rx2_blob), dtype=np.float64)
            measurements.append(
                SynapseMeasurement(
                    rx_1=cls.from_values(rx1, RADAR_SAMPLING_FREQUENCY),
                    rx_2=cls.from_values(rx2, RADAR_SAMPLING_FREQUENCY),
                )
            )
        return measurements

    def __str__(self):
        return f"{type(self).__name__}({', '.join([f'{_:02f}' for _ in self.values])})"

    def __repr__(self):
        return str(self)

    def __add__(self, other: CircularSequence) -> CircularSequence:
        if self.sampling_frequency != other.sampling_frequency:
            raise ValueError("Adding sequences with different sampling frequencies")
        if self.n_samples != other.n_samples:
            raise ValueError("Adding sequences of different length")
        return_type = (
            CircularSequence
            if isinstance(self, CircularSequence)
            and isinstance(other, CircularSequence)
            else CircularSequence
        )
        return return_type(
            self.values + other.values, self.ft + other.ft, self.sampling_frequency
        )

    def __sub__(self, other: CircularSequence) -> CircularSequence:
        return self + (other * -1)

    def __mul__(self, other: int | float) -> Self:
        if not isinstance(other, (float, int)):
            raise TypeError(
                f"Multiplication of CircularSequence by type {type(other)} not supported (only int and float)"
            )
        return CircularSequence(
            self.values * other, self.ft * other, self.sampling_frequency
        )

    def __truediv__(self, other: int | float) -> Self:
        if not isinstance(other, (float, int)):
            raise TypeError(
                f"Division of CircularSequence by type {type(other)} not supported (only int and float)"
            )
        if other == 0:
            raise ZeroDivisionError("Division of CircularSequence by zero")
        return self * (1 / other)

    def __matmul__(self, other: CircularSequence) -> CircularSequence:
        """
        Alias for correlation
        """
        return self.correlation(other)

    def __rshift__(self, amount: float | int) -> CircularSequence:
        """
        We do this by using the fft because this way we can do non-whole number shifts

        :param amount: Amount to shift by
        :return: A CircularSequence shifted by amount
        """
        return CircularSequence.from_ft(
            ft=self.ft
            * np.exp(
                fft.fftfreq(self.n_samples, 1 / self.sampling_frequency)
                * (-1j * amount * np.pi * 2)
            ),
            sampling_frequency=self.sampling_frequency,
            n_samples=self.n_samples,
        )

    def __lshift__(self, amount: float | int) -> CircularSequence:
        return self >> -amount

    @property
    def duration(self) -> float:
        return self.n_samples / self.sampling_frequency

    def plot(self, ax=None):
        if ax is None:
            fig, ax = plt.subplots()
        ax.plot(
            np.linspace(
                0, (self.n_samples - 1) / self.sampling_frequency, self.n_samples
            ),
            self.values,
        )

    def correlation(
        self, other_seq: CircularSequence, switch_sequences: bool = False
    ) -> CircularSequence:

        if abs(self.sampling_frequency - other_seq.sampling_frequency) > 1:
            raise ValueError(
                "Correlation of sequences of different sampling frequencies"
            )

        if self.n_samples != other_seq.n_samples:
            raise NotImplementedError("Correlation of sequences of different length")

        if not switch_sequences:
            return CircularSequence.from_ft(
                self.ft.conj() * other_seq.ft,
                self.sampling_frequency,
                other_seq.n_samples,
            )
        else:
            return CircularSequence.from_ft(
                self.ft * other_seq.ft.conj(),
                self.sampling_frequency,
                other_seq.n_samples,
            )

    def filter(self, filter_callback: Callable[[np.ndarray], np.ndarray]):
        """
        Filter a sequence's frequencies in-place

        :param filter_callback: A function taking frequency as its input and outputting complex number for the frequency to be multiplied by. **MUST BE HERMITIAN ( f(x) = conjugate of f(-x) )**
        :type filter_callback: function: np.array of floats -> np.array of complex
        """
        self.ft *= filter_callback(
            fft.fftfreq(self.n_samples, 1 / self.sampling_frequency)
        )
        self.values = np.real(fft.ifft(self.ft, self.n_samples))

    def filtered(self, filter: Callable[[np.ndarray], np.ndarray]) -> Self:
        return type(self).from_ft(
            self.ft * filter(fft.fftfreq(self.n_samples, 1 / self.sampling_frequency)),
            self.sampling_frequency,
            self.n_samples,
        )


@dataclasses.dataclass
class SynapseMission:
    """A radar mission loaded from a synapse mission.db file.

    The mission.db SQLite file contains:
      - metadata table: key-value pairs (mission_id, date, etc.)
      - frames table: radar frames with rx1/rx2 BLOBs
      - rtk_frames table: RTK correction BLOBs
    """

    mission_id: str
    date: str
    measurements: list[SynapseMeasurement]
    polarizations: list[str]
    timestamps_ns: list[int]

    @classmethod
    def load(cls, path: str | PathLike) -> SynapseMission:
        """Load a mission from a mission.db SQLite file or a mission directory.

        :param path: Path to mission.db file, or a directory containing it
        :return: SynapseMission with metadata and all radar frames
        """
        path = Path(path)
        if path.is_dir():
            path = path / "mission.db"
        if not path.exists():
            raise FileNotFoundError(f"mission.db not found at {path}")

        conn = sqlite3.connect(f"file:{path}?mode=ro", uri=True)

        # Read metadata
        meta_rows = conn.execute("SELECT key, value FROM metadata").fetchall()
        metadata: dict = {}
        for key, value in meta_rows:
            try:
                metadata[key] = json.loads(value)
            except (json.JSONDecodeError, TypeError):
                metadata[key] = value
        mission_id = metadata.get("mission_id", path.parent.name)
        date = metadata.get("date", "")

        # Read radar frames
        rows = conn.execute(
            "SELECT polarization, timestamp_ns, rx1, rx2 FROM frames "
            "ORDER BY frame_counter"
        ).fetchall()
        conn.close()

        measurements = []
        polarizations = []
        timestamps_ns = []
        for polarization, ts_ns, rx1_blob, rx2_blob in rows:
            n = len(rx1_blob) // 4
            rx1 = np.array(struct.unpack(f"<{n}i", rx1_blob), dtype=np.float64)
            rx2 = np.array(struct.unpack(f"<{n}i", rx2_blob), dtype=np.float64)
            measurements.append(
                SynapseMeasurement(
                    rx_1=CircularSequence.from_values(rx1, RADAR_SAMPLING_FREQUENCY),
                    rx_2=CircularSequence.from_values(rx2, RADAR_SAMPLING_FREQUENCY),
                )
            )
            polarizations.append(polarization)
            timestamps_ns.append(ts_ns)

        return cls(
            mission_id=mission_id,
            date=date,
            measurements=measurements,
            polarizations=polarizations,
            timestamps_ns=timestamps_ns,
        )
