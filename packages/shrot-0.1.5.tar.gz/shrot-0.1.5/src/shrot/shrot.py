from __future__ import annotations
import dataclasses
import sqlite3
import struct

import numpy as np
import numpy.fft as fft
from typing import Self, Sequence, Callable
from os import PathLike
import matplotlib.pyplot as plt

RADAR_SAMPLING_FREQUENCY = 13.312e9  # TODO nech to vzdy cita zo suboru napisaneho synapse lebo je to configurable


@dataclasses.dataclass
class SynapseMeasurement:
    rx_1: CircularSequence
    rx_2: CircularSequence


class RFSequence:
    sampling_frequency: float
    n_samples: int
    values: np.ndarray
    ft: np.ndarray

    # region initialization functions
    def __init__(self, values: Sequence, ft: Sequence, sampling_frequency: float):

        # Ensure `values` and `ft` are numpy arrays
        if not isinstance(values, np.ndarray):
            values = np.array(values)
        if not isinstance(ft, np.ndarray):
            ft = np.array(ft)

        # Assign attributes
        self.n_samples = len(values)
        self.sampling_frequency = sampling_frequency
        self.values = values
        self.ft = ft

    @classmethod
    def from_values(cls, values: Sequence, sampling_frequency: float) -> Self:
        return cls(values, fft.fft(values), sampling_frequency)

    @classmethod
    def from_ft(cls, ft: Sequence, sampling_frequency: float, n_samples: int) -> Self:
        return cls(np.real(fft.ifft(ft, n_samples)), ft, sampling_frequency)

    @classmethod
    def zero(cls, sampling_frequency: float, n_samples: int) -> Self:
        return cls(np.zeros(n_samples), np.zeros(n_samples), sampling_frequency)

    @classmethod
    def from_synapse_file(cls, path: PathLike) -> list[SynapseMeasurement]:
        """Read all radar frames from a synapse SQLite database.

        :param path: Path to the radar.db SQLite file
        :return: List of SynapseMeasurement, one per frame
        """
        conn = sqlite3.connect(path)
        rows = conn.execute("SELECT rx1, rx2 FROM frames").fetchall()
        conn.close()
        measurements = []
        for rx1_blob, rx2_blob in rows:
            n = len(rx1_blob) // 4
            rx1 = np.array(struct.unpack(f"<{n}i", rx1_blob), dtype=np.float64)
            rx2 = np.array(struct.unpack(f"<{n}i", rx2_blob), dtype=np.float64)
            measurements.append(
                SynapseMeasurement(
                    rx_1=cls.from_values(rx1, RADAR_SAMPLING_FREQUENCY),
                    rx_2=cls.from_values(rx2, RADAR_SAMPLING_FREQUENCY),
                )
            )
        return measurements

    def is_anomaly(self):
        for value in self.values:
            if value >= 10**9:
                return True
        return False

    # endregion

    # region magic functions
    def __str__(self):
        return f"{type(self).__name__}({', '.join([f'{_:02f}' for _ in self.values])})"

    def __repr__(self):
        return str(self)

    def __add__(self, other: RFSequence) -> RFSequence:
        if self.sampling_frequency != other.sampling_frequency:
            raise NotImplementedError(
                "Adding sequences with different sampling frequencies"
            )
        if self.n_samples != other.n_samples:
            raise NotImplementedError("Adding sequences of different length")
        return_type = (
            CircularSequence
            if isinstance(self, CircularSequence)
            and isinstance(other, CircularSequence)
            else RFSequence
        )
        return return_type(
            self.values + other.values, self.ft + other.ft, self.sampling_frequency
        )

    def __sub__(self, other: RFSequence) -> RFSequence:
        return self + (-1) * other

    def __mul__(self, other: int | float) -> Self:
        if not isinstance(other, (float, int)):
            raise TypeError(
                f"Multiplication of RFSequence by type {type(other)} not supported (only int and float)"
            )
        return type(self)(self.values * other, self.ft * other, self.sampling_frequency)

    def __rmul__(self, other: int | float) -> Self:
        return self * other

    def __truediv__(self, other: int | float) -> Self:
        if not isinstance(other, (float, int)):
            raise TypeError(
                f"Division of RFSequence by type {type(other)} not supported (only int and float)"
            )
        if other == 0:
            raise ZeroDivisionError("Division of RFSequence by zero")
        return self * (1 / other)

    def __matmul__(self, other: RFSequence) -> RFSequence:
        """
        Alias for correlation
        """
        return self.correlation(other)

    # endregion

    @property
    def duration(self) -> float:
        return self.n_samples / self.sampling_frequency

    def plot(self, ax=None, color=None, meters=False):
        if ax is None:
            fig, ax = plt.subplots()
        ax.plot(
            np.linspace(
                0,
                (self.n_samples - 1)
                / self.sampling_frequency
                * (1 if not meters else 3e8 / 2),
                self.n_samples,
            ),
            self.values,
            color=color,
        )

    def correlation(
        self, other_seq: RFSequence, switch_sequences: bool = False
    ) -> RFSequence:
        """
        Correlates two sequences

        :param self: The base sequence (TX)
        :param other_seq: The shifted / modulated sequence
        :type other_seq: RFSequence
        :param switch_sequences: If true, the first sequence is interpreted as the modulated and the second as the base
        :type switch_sequences: bool
        :return: Correlation
        :rtype: RFSequence
        """

        if abs(self.sampling_frequency - other_seq.sampling_frequency) > 1:
            raise NotImplementedError(
                "Correlation of sequences of different sampling frequencies"
            )
        if isinstance(other_seq, CircularSequence):
            return other_seq.correlation(self, not switch_sequences)


class CircularSequence(RFSequence):
    def correlation(
        self, other_seq: RFSequence, switch_sequences: bool = False
    ) -> RFSequence:

        if abs(self.sampling_frequency - other_seq.sampling_frequency) > 1:
            raise NotADirectoryError(
                "Correlation of sequences of different sampling frequencies"
            )
        # if isinstance(other_seq, CircularSequence) and self.n_samples != other_seq.n_samples:
        #     raise NotImplementedError("Correlation of circular sequences of different length")
        if self.n_samples != other_seq.n_samples:
            raise NotImplementedError("Correlation of sequences of different length")

        if not switch_sequences:
            return CircularSequence.from_ft(
                self.ft.conj() * other_seq.ft,
                self.sampling_frequency,
                other_seq.n_samples,
            )
        else:
            return CircularSequence.from_ft(
                self.ft * other_seq.ft.conj(),
                self.sampling_frequency,
                other_seq.n_samples,
            )

    def __rshift__(self, amount: float | int) -> CircularSequence:
        return type(self).from_ft(
            ft=self.ft
            * np.exp(
                fft.fftfreq(self.n_samples, 1 / self.sampling_frequency)
                * (-1j * amount * np.pi * 2)
            ),
            sampling_frequency=self.sampling_frequency,
            n_samples=self.n_samples,
        )

    def __lshift__(self, amount: float | int) -> CircularSequence:
        return self >> -amount

    def filter(
        self, filter: Callable[[np.ndarray[np.float64]], np.ndarray[np.complex128]]
    ):
        """
        Filter a sequence's frequencies in-place

        :param filter: A function taking frequency as its input and outputting complex number for the frequency to be multiplied by. **MUST BE HERMITIAN ( f(x) = conjugate of f(-x) )**
        :type filter: function: np.array of floats -> np.array of complex
        """
        self.ft *= filter(fft.fftfreq(self.n_samples, 1 / self.sampling_frequency))
        self.values = np.real(fft.ifft(self.ft, self.n_samples))

    def filtered(
        self, filter: Callable[[np.ndarray[np.float64]], np.ndarray[np.complex128]]
    ) -> Self:
        return type(self).from_ft(
            self.ft * filter(fft.fftfreq(self.n_samples, 1 / self.sampling_frequency)),
            self.sampling_frequency,
            self.n_samples,
        )

    def __mul__(
        self,
        other: float
        | int
        | Callable[[np.ndarray[np.float64]], np.ndarray[np.complex128]],
    ):
        if isinstance(other, (int, float)):
            return super().__mul__(other)
        return self.filtered(other)
