from __future__ import annotations
from typing import Sequence

from shrot.shrot import CircularSequence


def generate_m_sequence(
    sampling_frequency: float, taps: list[int] = None, initial_state: list[int] = None
) -> CircularSequence:
    """
    Generates an m_sequence as a CircularSequence of 1 and -1.

    :param sampling_frequency: The sampling frequency of the m_sequence
    :param taps: https://en.wikipedia.org/wiki/Maximum_length_sequence#Generation
    :param initial_state: Iterable of 1 and -1, all ones by default
    """
    if taps is None:
        taps = [4, 9]

    order = max(taps)
    if initial_state is None:
        initial_state = [1] * order

    if not isinstance(initial_state, Sequence):
        raise TypeError(f"initial state must be Iterable, not {type(initial_state)}")

    length = 2**order - 1
    generated_length = length - len(initial_state)
    m_sequence = initial_state

    for i in range(generated_length):
        m_sequence.append(generate_next_m_sequence_value(m_sequence, taps))
    return CircularSequence.from_values(m_sequence, sampling_frequency)


def generate_next_m_sequence_value(m_sequence: list[int], taps: list[int]) -> int:
    return (sum([m_sequence[-i] for i in taps]) + len(taps)) % 4 - 1
