"""Tests for /runs routes."""

import pytest
from uuid import UUID


@pytest.mark.anyio
async def test_list_runs_empty(client):
    r = await client.get("/runs")
    assert r.status_code == 200
    assert r.json()["runs"] == []


@pytest.mark.anyio
async def test_get_run_after_completion(client):
    # Start a run and wait for it
    post_r = await client.post(
        "/agents/echo/run", json={"payload": "poll-test", "wait": True}
    )
    run_id = post_r.json()["run_id"]

    r = await client.get(f"/runs/{run_id}")
    assert r.status_code == 200
    data = r.json()
    assert data["run_id"] == run_id
    assert data["status"] == "completed"
    assert data["result"] == "poll-test"
    assert data["completed_at"] is not None


@pytest.mark.anyio
async def test_get_run_not_found(client):
    r = await client.get("/runs/00000000-0000-0000-0000-000000000000")
    assert r.status_code == 404


@pytest.mark.anyio
async def test_list_runs_shows_all(client):
    await client.post("/agents/echo/run", json={"payload": "a", "wait": True})
    await client.post("/agents/upper/run", json={"payload": "b", "wait": True})

    r = await client.get("/runs")
    assert r.status_code == 200
    runs = r.json()["runs"]
    assert len(runs) == 2
    statuses = {run["status"] for run in runs}
    assert statuses == {"completed"}


@pytest.mark.anyio
async def test_run_record_has_required_fields(client):
    r = await client.post(
        "/agents/echo/run", json={"payload": "fields-test", "wait": True}
    )
    data = r.json()
    for field in ["run_id", "trace_id", "kind", "name", "status", "created_at"]:
        assert field in data, f"Missing field: {field}"
    # UUIDs are valid
    UUID(data["run_id"])
    UUID(data["trace_id"])
