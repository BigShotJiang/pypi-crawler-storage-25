"""Tests for /events routes."""

import pytest


@pytest.mark.anyio
async def test_events_empty_initially(client):
    r = await client.get("/events")
    assert r.status_code == 200
    data = r.json()
    assert data["count"] == 0
    assert data["events"] == []


@pytest.mark.anyio
async def test_events_populated_after_run(client):
    await client.post("/agents/echo/run", json={"payload": "logged", "wait": True})

    r = await client.get("/events")
    assert r.status_code == 200
    data = r.json()
    assert data["count"] > 0
    event = data["events"][0]
    for field in ["id", "type", "from_agent", "to_agent", "trace_id", "timestamp"]:
        assert field in event


@pytest.mark.anyio
async def test_events_filter_by_agent(client):
    await client.post("/agents/echo/run", json={"payload": "x", "wait": True})
    await client.post("/agents/upper/run", json={"payload": "y", "wait": True})

    r = await client.get("/events?agent=echo")
    assert r.status_code == 200
    events = r.json()["events"]
    assert all(
        e["from_agent"] == "echo" or e["to_agent"] == "echo"
        for e in events
    )


@pytest.mark.anyio
async def test_events_filter_by_trace_id(client):
    r1 = await client.post("/agents/echo/run", json={"payload": "t1", "wait": True})
    trace_id = r1.json()["trace_id"]

    await client.post("/agents/echo/run", json={"payload": "t2", "wait": True})

    r = await client.get(f"/events?trace_id={trace_id[:8]}")
    assert r.status_code == 200
    events = r.json()["events"]
    assert len(events) > 0
    # All returned events should belong to the trace
    for e in events:
        assert e["trace_id"].startswith(trace_id[:8])


@pytest.mark.anyio
async def test_event_fields(client):
    await client.post("/agents/echo/run", json={"payload": "fields", "wait": True})

    r = await client.get("/events?agent=echo")
    assert r.status_code == 200
    events = r.json()["events"]
    assert len(events) >= 1
    e = events[0]
    assert e["type"] in ("task", "result", "error", "broadcast", "budget_exceeded")
    assert e["from_agent"] is not None
    assert e["to_agent"] is not None
