"""Tests for /agents routes."""

import pytest


@pytest.mark.anyio
async def test_list_agents(client):
    r = await client.get("/agents")
    assert r.status_code == 200
    agents = r.json()["agents"]
    assert "echo" in agents
    assert "upper" in agents
    assert "failing" in agents


@pytest.mark.anyio
async def test_run_agent_wait(client):
    """wait=True — blocks until complete, returns result immediately."""
    r = await client.post("/agents/echo/run", json={"payload": "hello", "wait": True})
    assert r.status_code == 200
    data = r.json()
    assert data["status"] == "completed"
    assert data["result"] == "hello"
    assert data["kind"] == "agent"
    assert data["name"] == "echo"


@pytest.mark.anyio
async def test_run_agent_transforms_payload(client):
    r = await client.post(
        "/agents/upper/run", json={"payload": "hello world", "wait": True}
    )
    assert r.status_code == 200
    assert r.json()["result"] == "HELLO WORLD"


@pytest.mark.anyio
async def test_run_agent_failing(client):
    r = await client.post("/agents/failing/run", json={"payload": "x", "wait": True})
    assert r.status_code == 200
    data = r.json()
    assert data["status"] == "failed"
    assert "boom" in data["error"]


@pytest.mark.anyio
async def test_run_agent_not_found(client):
    r = await client.post("/agents/ghost/run", json={"payload": "x"})
    assert r.status_code == 404


@pytest.mark.anyio
async def test_run_agent_background_returns_run_id(client):
    """wait=False — returns immediately with a run_id."""
    r = await client.post("/agents/echo/run", json={"payload": "bg", "wait": False})
    assert r.status_code == 200
    data = r.json()
    assert "run_id" in data
    assert data["status"] == "running"


@pytest.mark.anyio
async def test_run_agent_null_payload(client):
    r = await client.post("/agents/echo/run", json={"wait": True})
    assert r.status_code == 200
    assert r.json()["status"] == "completed"


@pytest.mark.anyio
async def test_lifecycle_pause_resume_stop(client):
    r = await client.post("/agents/echo/pause")
    assert r.status_code == 200
    assert r.json()["action"] == "paused"

    r = await client.post("/agents/echo/resume")
    assert r.status_code == 200
    assert r.json()["action"] == "resumed"

    r = await client.post("/agents/echo/stop")
    assert r.status_code == 200
    assert r.json()["action"] == "stopped"


@pytest.mark.anyio
async def test_lifecycle_unknown_agent(client):
    r = await client.post("/agents/ghost/pause")
    assert r.status_code == 404
