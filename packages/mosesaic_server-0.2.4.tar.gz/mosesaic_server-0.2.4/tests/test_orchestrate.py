from __future__ import annotations
import json
import pytest
from fastapi.testclient import TestClient
from mosesaic.core.runtime import AgentRuntime
from mosesaic.workflow.runtime import WorkflowRuntime
from mosesaic.server.app import create_app
from mosesaic.team.orchestrator.director import chief_director
from mosesaic.team.orchestrator.directors import (
    clarify_director, architect_director,
    deploy_director, monitor_director,
    build_director, verify_director,
)
from mosesaic.team.orchestrator.workflow import orchestrate_workflow
from mosesaic.llm.providers.mock import MockProvider
from mosesaic.llm.registry import ProviderRegistry
from mosesaic.llm.provider import Capabilities


def _make_app(chief_response: dict):
    """Create app with full workflow wired.

    Uses stub-only phases so the mock response is only consumed by chief_director.
    """
    caps = {"mock-model": Capabilities(
        vision=False, tools=False, thinking=False,
        context_k=32, cost_per_1m_input=0.0, cost_per_1m_output=0.0,
    )}

    class _FixedMock(MockProvider):
        @property
        def name(self) -> str:
            return "fixed-mock"

        def all_models(self):
            return caps

    provider = _FixedMock(capabilities=caps)
    provider._next_response = json.dumps(chief_response)

    registry = ProviderRegistry()
    registry.register(provider)

    # AgentRuntime still needed for agent-only routes
    agent_rt = AgentRuntime(llm=registry)
    agent_rt.register(chief_director)

    # WorkflowRuntime with all phase directors and the orchestrate workflow
    wf_rt = WorkflowRuntime(llm=registry)
    wf_rt.register_agent(chief_director)
    wf_rt.register_agent(clarify_director)
    wf_rt.register_agent(architect_director)
    wf_rt.register_agent(build_director)
    wf_rt.register_agent(verify_director)
    wf_rt.register_agent(deploy_director)
    wf_rt.register_agent(monitor_director)
    wf_rt.register_workflow(orchestrate_workflow)

    return create_app(agent_rt, wf_rt)


@pytest.fixture
def client():
    app = _make_app({
        "request_type": "feature",
        "phases": ["clarify", "architect"],
        "reasoning": "Needs design.",
    })
    with TestClient(app) as c:
        yield c


def test_post_orchestrate_returns_run_id(client):
    resp = client.post("/orchestrate", json={"prompt": "Add a health check"})
    assert resp.status_code == 202
    data = resp.json()
    assert "run_id" in data
    assert data["status"] in ("running", "completed", "failed", "timed_out")


def test_post_orchestrate_missing_prompt_returns_422(client):
    resp = client.post("/orchestrate", json={})
    assert resp.status_code == 422


def test_get_orchestrate_run_returns_record(client):
    post_resp = client.post(
        "/orchestrate",
        json={"prompt": "Add a health check", "wait": True},
    )
    run_id = post_resp.json()["run_id"]
    get_resp = client.get(f"/orchestrate/{run_id}")
    assert get_resp.status_code == 200
    data = get_resp.json()
    assert data["run_id"] == run_id


def test_get_orchestrate_unknown_id_returns_404(client):
    resp = client.get("/orchestrate/00000000-0000-0000-0000-000000000000")
    assert resp.status_code == 404


def test_stream_orchestrate_emits_events(client):
    """GET /orchestrate/{id}/stream returns text/event-stream with at least one event."""
    post_resp = client.post(
        "/orchestrate",
        json={"prompt": "Add a health check", "wait": True},
    )
    assert post_resp.status_code == 202
    run_id = post_resp.json()["run_id"]

    with client.stream("GET", f"/orchestrate/{run_id}/stream") as resp:
        assert resp.status_code == 200
        assert "text/event-stream" in resp.headers["content-type"]
        chunks = []
        for line in resp.iter_lines():
            if line.startswith("data:"):
                chunks.append(line)
            if line == "data: [DONE]":
                break
        assert len(chunks) >= 1


def test_post_orchestrate_wait_true_returns_non_running_status(client):
    resp = client.post(
        "/orchestrate",
        json={"prompt": "Add a health check", "wait": True},
    )
    assert resp.status_code == 202
    data = resp.json()
    # With wait=True the workflow runs synchronously; status must not be 'running'
    assert data["status"] in ("completed", "failed", "timed_out")


def test_get_orchestrate_returns_run_log_and_cost(client):
    """GET /orchestrate/{run_id} for a completed run includes run_log and total_cost_usd."""
    post_resp = client.post(
        "/orchestrate",
        json={"prompt": "Add a health check", "wait": True},
    )
    assert post_resp.status_code == 202
    run_id = post_resp.json()["run_id"]

    get_resp = client.get(f"/orchestrate/{run_id}")
    assert get_resp.status_code == 200
    data = get_resp.json()
    assert "run_log" in data
    assert "total_cost_usd" in data
    assert isinstance(data["run_log"], list)
    assert isinstance(data["total_cost_usd"], float)
    # clarify + architect phases were run (per client fixture)
    assert len(data["run_log"]) == 2
    phases = [e["phase"] for e in data["run_log"]]
    assert "clarify" in phases
    assert "architect" in phases
