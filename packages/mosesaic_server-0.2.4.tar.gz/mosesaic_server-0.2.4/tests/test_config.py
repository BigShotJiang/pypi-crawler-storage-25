# python/mosesaic-server/tests/test_config.py
from __future__ import annotations

import warnings
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from mosesaic.server.config import load_config, ServerConfig


# ── helpers ───────────────────────────────────────────────────────────────────

def _write_toml(tmp_path: Path, filename: str, content: str) -> Path:
    p = tmp_path / filename
    p.write_text(content)
    return p


def _mock_provider(name: str):
    """A mock provider instance that reports its name and one model."""
    p = MagicMock()
    p.name = name
    p.models = {"mock-model": MagicMock()}
    return p


# ── tests ─────────────────────────────────────────────────────────────────────

def test_load_minimal_config_with_provider(tmp_path, monkeypatch):
    """A single provider block with api_key from file is initialised."""
    project_toml = _write_toml(tmp_path, "mosesaic.toml", """
[server]
host = "127.0.0.1"
port = 9000

[[provider]]
name = "groq"
api_key = "gsk-test"
""")
    with patch("mosesaic.server.config._HOME_CONFIG", tmp_path / "nonexistent.toml"), \
         patch("mosesaic.server.config._PROJECT_CONFIG", project_toml), \
         patch("mosesaic.server.config._build_provider", return_value=_mock_provider("groq")):
        cfg = load_config()

    assert cfg.host == "127.0.0.1"
    assert cfg.port == 9000
    assert cfg.registry is not None


def test_env_var_overrides_toml_api_key(tmp_path, monkeypatch):
    """ANTHROPIC_API_KEY env var overrides api_key in [[provider]] block."""
    monkeypatch.setenv("ANTHROPIC_API_KEY", "env-key")

    project_toml = _write_toml(tmp_path, "mosesaic.toml", """
[[provider]]
name = "anthropic"
api_key = "file-key"
""")

    captured = {}

    def fake_build(name, api_key, base_url):
        captured["api_key"] = api_key
        return _mock_provider(name)

    with patch("mosesaic.server.config._HOME_CONFIG", tmp_path / "nonexistent.toml"), \
         patch("mosesaic.server.config._PROJECT_CONFIG", project_toml), \
         patch("mosesaic.server.config._build_provider", side_effect=fake_build):
        load_config()

    assert captured["api_key"] == "env-key"


def test_missing_key_skips_provider_with_warning(tmp_path, monkeypatch):
    """Provider whose API key is missing is skipped with a warning."""
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)

    project_toml = _write_toml(tmp_path, "mosesaic.toml", """
[[provider]]
name = "openai"

[[provider]]
name = "groq"
api_key = "gsk-test"
""")

    def fake_build(name, api_key, base_url):
        if name == "openai" and not api_key:
            raise ValueError("No API key")
        return _mock_provider(name)

    with patch("mosesaic.server.config._HOME_CONFIG", tmp_path / "nonexistent.toml"), \
         patch("mosesaic.server.config._PROJECT_CONFIG", project_toml), \
         patch("mosesaic.server.config._build_provider", side_effect=fake_build):
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            cfg = load_config()

    assert any("openai" in str(warning.message).lower() for warning in w)
    assert cfg.registry is not None


def test_zero_providers_raises(tmp_path, monkeypatch):
    """RuntimeError if every provider fails to initialise."""
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)

    project_toml = _write_toml(tmp_path, "mosesaic.toml", """
[[provider]]
name = "openai"
""")

    def fake_build(name, api_key, base_url):
        raise ValueError("No key")

    with patch("mosesaic.server.config._HOME_CONFIG", tmp_path / "nonexistent.toml"), \
         patch("mosesaic.server.config._PROJECT_CONFIG", project_toml), \
         patch("mosesaic.server.config._build_provider", side_effect=fake_build):
        with warnings.catch_warnings(record=True):
            warnings.simplefilter("always")
            with pytest.raises(RuntimeError, match="No providers"):
                load_config()


def test_director_overrides_parsed(tmp_path):
    """[director.X] blocks map to director_overrides dict."""
    project_toml = _write_toml(tmp_path, "mosesaic.toml", """
[[provider]]
name = "groq"
api_key = "gsk-test"

[director.chief]
provider = "anthropic"
model = "claude-opus-4-6"

[director.build]
provider = "groq"
model = "llama-3.3-70b-versatile"
""")

    with patch("mosesaic.server.config._HOME_CONFIG", tmp_path / "nonexistent.toml"), \
         patch("mosesaic.server.config._PROJECT_CONFIG", project_toml), \
         patch("mosesaic.server.config._build_provider", return_value=_mock_provider("groq")):
        cfg = load_config()

    assert cfg.director_overrides["chief_director"] == "claude-opus-4-6"
    assert cfg.director_overrides["build_director"] == "llama-3.3-70b-versatile"


def test_user_config_overridden_by_project_config(tmp_path):
    """Project-level config values override user-level values."""
    user_toml = _write_toml(tmp_path, "user.toml", """
[server]
host = "127.0.0.1"
port = 8000
""")
    project_toml = _write_toml(tmp_path, "mosesaic.toml", """
[server]
port = 9999

[[provider]]
name = "groq"
api_key = "gsk-test"
""")

    with patch("mosesaic.server.config._HOME_CONFIG", user_toml), \
         patch("mosesaic.server.config._PROJECT_CONFIG", project_toml), \
         patch("mosesaic.server.config._build_provider", return_value=_mock_provider("groq")):
        cfg = load_config()

    assert cfg.port == 9999
    assert cfg.host == "127.0.0.1"  # from user config, not overridden
