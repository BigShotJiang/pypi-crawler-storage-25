"""Tests for /workflows routes."""

import pytest


@pytest.mark.anyio
async def test_list_workflows(client):
    r = await client.get("/workflows")
    assert r.status_code == 200
    assert "echo-wf" in r.json()["workflows"]


@pytest.mark.anyio
async def test_run_workflow_wait(client):
    r = await client.post(
        "/workflows/echo-wf/run",
        json={"input": "workflow-input", "wait": True},
    )
    assert r.status_code == 200
    data = r.json()
    assert data["status"] == "completed"
    assert data["result"] == "workflow-input"
    assert data["kind"] == "workflow"
    assert data["name"] == "echo-wf"


@pytest.mark.anyio
async def test_run_workflow_not_found(client):
    r = await client.post("/workflows/ghost/run", json={"input": "x"})
    assert r.status_code == 404


@pytest.mark.anyio
async def test_run_workflow_background(client):
    r = await client.post(
        "/workflows/echo-wf/run",
        json={"input": "bg", "wait": False},
    )
    assert r.status_code == 200
    data = r.json()
    assert "run_id" in data
    assert data["status"] == "running"
