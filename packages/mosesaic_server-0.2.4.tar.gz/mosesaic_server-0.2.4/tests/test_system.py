"""Tests for /health and /version."""

import pytest


@pytest.mark.anyio
async def test_health(client):
    r = await client.get("/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"


@pytest.mark.anyio
async def test_version(client):
    r = await client.get("/version")
    assert r.status_code == 200
    data = r.json()
    assert "version" in data
    assert data["package"] == "mosesaic-server"
