"""Shared fixtures for mosesaic-server tests."""

import anyio
import pytest
from httpx import AsyncClient, ASGITransport

from mosesaic.core.agent import agent, AgentDefinition
from mosesaic.core.context import AgentContext
from mosesaic.workflow import workflow, WorkflowDefinition, step
from mosesaic.core.runtime import AgentRuntime
from mosesaic.workflow.runtime import WorkflowRuntime
from mosesaic.server.app import create_app


@pytest.fixture
def echo_agent() -> AgentDefinition:
    @agent(name="echo")
    async def _echo(ctx: AgentContext) -> None:
        msg = await ctx.receive()
        await ctx.send("__out__", msg.payload)
    return _echo


@pytest.fixture
def upper_agent() -> AgentDefinition:
    @agent(name="upper")
    async def _upper(ctx: AgentContext) -> None:
        msg = await ctx.receive()
        await ctx.send("__out__", str(msg.payload).upper())
    return _upper


@pytest.fixture
def failing_agent() -> AgentDefinition:
    @agent(name="failing")
    async def _failing(ctx: AgentContext) -> None:
        await ctx.receive()
        raise ValueError("boom")
    return _failing


@pytest.fixture
def echo_workflow(echo_agent) -> WorkflowDefinition:
    @workflow(name="echo-wf")
    async def _wf(ctx):
        return await step("echo", input=ctx.input)
    return _wf


@pytest.fixture
def app(echo_agent, upper_agent, failing_agent, echo_workflow):
    agent_rt = AgentRuntime()
    agent_rt.register(echo_agent)
    agent_rt.register(upper_agent)
    agent_rt.register(failing_agent)

    wf_rt = WorkflowRuntime()
    wf_rt.register_agent(echo_agent)
    wf_rt.register_agent(upper_agent)
    wf_rt.register_workflow(echo_workflow)

    return create_app(agent_rt, wf_rt)


@pytest.fixture
async def client(app):
    async with anyio.create_task_group() as tg:
        app.state.registry._background_tg = tg
        async with AsyncClient(
            transport=ASGITransport(app=app), base_url="http://test"
        ) as c:
            yield c
        tg.cancel_scope.cancel()
