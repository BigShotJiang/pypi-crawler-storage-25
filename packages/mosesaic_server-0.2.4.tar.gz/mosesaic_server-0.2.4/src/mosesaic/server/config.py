"""Config loader for mosesaic-server.

Merges (in order, later wins):
  1. ~/.mosesaic/config.toml     — user-level defaults
  2. ./mosesaic.toml             — project-level overrides
  3. Environment variables       — highest priority (override api_key fields)

Raises RuntimeError at startup if zero providers could be initialised.
"""
from __future__ import annotations

import os
import tomllib
import warnings
from dataclasses import dataclass, field
from pathlib import Path

from mosesaic.llm.registry import ProviderRegistry

# Paths that load_config() reads (can be patched in tests)
_HOME_CONFIG = Path.home() / ".mosesaic" / "config.toml"
_PROJECT_CONFIG = Path("mosesaic.toml")

# Maps provider name → env var that holds the API key
_ENV_KEYS: dict[str, str] = {
    "anthropic": "ANTHROPIC_API_KEY",
    "openai": "OPENAI_API_KEY",
    "groq": "GROQ_API_KEY",
    "gemini": "GEMINI_API_KEY",
    "openrouter": "OPENROUTER_API_KEY",
    "cerebras": "CEREBRAS_API_KEY",
}


@dataclass
class ServerConfig:
    host: str = "127.0.0.1"
    port: int = 8000
    registry: ProviderRegistry = field(default_factory=ProviderRegistry)
    director_overrides: dict[str, str] = field(default_factory=dict)  # agent_name → model_id


def _load_toml(path: Path) -> dict:
    """Load a TOML file; return empty dict if it doesn't exist."""
    if not path.exists():
        return {}
    with path.open("rb") as f:
        return tomllib.load(f)


def _deep_merge(base: dict, override: dict) -> dict:
    """Recursively merge override into base. override wins on conflict."""
    result = dict(base)
    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def _build_provider(name: str, api_key: str | None, base_url: str | None):
    """Instantiate a provider by name. Raises ValueError if key is missing."""
    from mosesaic.llm.providers.anthropic import AnthropicProvider
    from mosesaic.llm.providers.cerebras import CerebrasProvider
    from mosesaic.llm.providers.gemini import GeminiProvider
    from mosesaic.llm.providers.groq import GroqProvider
    from mosesaic.llm.providers.ollama import OllamaProvider
    from mosesaic.llm.providers.openai import OpenAIProvider
    from mosesaic.llm.providers.openrouter import OpenRouterProvider

    if name == "anthropic":
        return AnthropicProvider(api_key=api_key)
    if name == "openai":
        return OpenAIProvider(api_key=api_key)
    if name == "groq":
        return GroqProvider(api_key=api_key)
    if name == "gemini":
        return GeminiProvider(api_key=api_key)
    if name == "openrouter":
        return OpenRouterProvider(api_key=api_key)
    if name == "cerebras":
        return CerebrasProvider(api_key=api_key)
    if name == "ollama":
        return OllamaProvider(base_url=base_url or "http://localhost:11434")
    raise ValueError(f"Unknown provider: {name!r}")


def load_config() -> ServerConfig:
    """Load and merge config files + env vars into a ServerConfig."""
    # Step 1: merge TOML files (project overrides user)
    raw = _deep_merge(_load_toml(_HOME_CONFIG), _load_toml(_PROJECT_CONFIG))

    # Step 2: extract [server] section
    server_section = raw.get("server", {})
    host = server_section.get("host", "127.0.0.1")
    port = int(server_section.get("port", 8000))

    # Step 3: build providers from [[provider]] blocks
    registry = ProviderRegistry()
    skipped: list[str] = []
    initialised: list[str] = []

    explicit_names: set[str] = set()
    for block in raw.get("provider", []):
        name = block.get("name", "").lower()
        explicit_names.add(name)
        # Env var overrides file api_key
        env_key = _ENV_KEYS.get(name)
        api_key = (os.environ.get(env_key) if env_key else None) or block.get("api_key")
        base_url = block.get("base_url")

        try:
            provider = _build_provider(name, api_key=api_key, base_url=base_url)
            registry.register(provider)
            initialised.append(name)
        except (ValueError, Exception) as exc:
            warnings.warn(
                f"Skipping provider {name!r}: {exc}",
                stacklevel=2,
            )
            skipped.append(name)

    # Auto-detect providers from env vars that weren't listed in TOML
    for name, env_var in _ENV_KEYS.items():
        if name in explicit_names:
            continue
        api_key = os.environ.get(env_var)
        if not api_key:
            continue
        try:
            provider = _build_provider(name, api_key=api_key, base_url=None)
            registry.register(provider)
            initialised.append(name)
        except Exception as exc:
            warnings.warn(f"Skipping auto-detected provider {name!r}: {exc}", stacklevel=2)

    if not initialised:
        raise RuntimeError(
            "No providers could be initialised. "
            "Set at least one API key env var (e.g. ANTHROPIC_API_KEY, GROQ_API_KEY) "
            "or add [[provider]] blocks to mosesaic.toml."
        )

    # Step 4: parse [director.X] blocks → director_overrides
    director_overrides: dict[str, str] = {}
    for director_name, director_cfg in raw.get("director", {}).items():
        model = director_cfg.get("model")
        if model:
            director_overrides[f"{director_name}_director"] = model

    return ServerConfig(
        host=host,
        port=port,
        registry=registry,
        director_overrides=director_overrides,
    )
