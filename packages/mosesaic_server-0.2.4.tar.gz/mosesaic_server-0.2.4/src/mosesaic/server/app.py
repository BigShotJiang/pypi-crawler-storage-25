"""
FastAPI application factory.

Usage::

    from mosesaic.core.runtime import AgentRuntime
    from mosesaic.workflow.runtime import WorkflowRuntime
    from mosesaic.server.app import create_app

    agent_rt = AgentRuntime()
    agent_rt.register(my_agent)

    wf_rt = WorkflowRuntime()
    wf_rt.register_agent(my_agent)
    wf_rt.register_workflow(my_workflow)

    app = create_app(agent_rt, wf_rt)
    # uvicorn.run(app, host="0.0.0.0", port=8000)
"""

from __future__ import annotations

from contextlib import asynccontextmanager
from typing import AsyncGenerator

import anyio
from fastapi import FastAPI

from mosesaic.core.runtime import AgentRuntime
from mosesaic.workflow.runtime import WorkflowRuntime
from mosesaic.server.registry import RunRegistry
from mosesaic.server.routes import agents, workflows, runs, events, system, orchestrate


def create_app(
    agent_runtime: AgentRuntime,
    workflow_runtime: WorkflowRuntime | None = None,
    *,
    title: str = "Mosesaic Server",
    version: str = "0.1.0",
) -> FastAPI:
    """
    Create and configure the FastAPI application.

    Args:
        agent_runtime:    Pre-configured AgentRuntime with registered agents.
        workflow_runtime: Optional WorkflowRuntime with registered workflows.
        title:            OpenAPI docs title.
        version:          API version string.
    """
    registry = RunRegistry(
        agent_runtime=agent_runtime,
        workflow_runtime=workflow_runtime or WorkflowRuntime(),
    )

    @asynccontextmanager
    async def _lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
        async with anyio.create_task_group() as tg:
            app.state.registry._background_tg = tg
            yield
            tg.cancel_scope.cancel()

    app = FastAPI(
        title=title,
        version=version,
        description=(
            "Mosesaic REST API — run agents and workflows over HTTP, "
            "query event logs, and control agent lifecycle."
        ),
        lifespan=_lifespan,
    )

    # Attach the registry to app.state so routes can access it
    app.state.registry = registry

    # Mount routers
    app.include_router(system.router)
    app.include_router(agents.router)
    app.include_router(workflows.router)
    app.include_router(runs.router)
    app.include_router(events.router)
    app.include_router(orchestrate.router)

    return app
