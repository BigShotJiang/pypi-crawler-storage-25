"""GET /health and GET /version."""

from fastapi import APIRouter
from importlib.metadata import version, PackageNotFoundError

router = APIRouter(tags=["system"])


@router.get("/health")
async def health() -> dict:
    return {"status": "ok"}


@router.get("/version")
async def get_version() -> dict:
    try:
        v = version("mosesaic-server")
    except PackageNotFoundError:
        v = "0.1.0-dev"
    return {"version": v, "package": "mosesaic-server"}
