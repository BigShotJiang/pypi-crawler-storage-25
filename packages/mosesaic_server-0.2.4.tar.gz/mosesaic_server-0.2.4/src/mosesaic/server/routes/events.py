"""Event log routes: GET /events with optional trace_id / agent filters."""

from __future__ import annotations
from typing import Any

from fastapi import APIRouter, Query, Request

router = APIRouter(prefix="/events", tags=["events"])


@router.get("")
async def list_events(
    request: Request,
    trace_id: str | None = Query(default=None),
    agent: str | None = Query(default=None),
) -> dict:
    reg = request.app.state.registry

    if trace_id:
        # Find runs whose trace_id starts with the prefix and return their events
        events: list[Any] = []
        for record in reg.all_runs():
            if str(record.trace_id).startswith(trace_id):
                events.extend(record.events)
    else:
        events = reg.all_events()

    if agent:
        events = [
            e for e in events
            if e.from_agent == agent or e.to_agent == agent
        ]

    return {
        "count": len(events),
        "events": [_serialize_event(e) for e in events],
    }


def _serialize_event(msg: Any) -> dict:
    return {
        "id": str(msg.id),
        "type": msg.type.value if hasattr(msg.type, "value") else str(msg.type),
        "from_agent": msg.from_agent,
        "to_agent": msg.to_agent,
        "payload": msg.payload,
        "trace_id": str(msg.trace_id),
        "parent_message_id": (
            str(msg.parent_message_id) if msg.parent_message_id else None
        ),
        "timestamp": msg.timestamp.isoformat(),
    }
