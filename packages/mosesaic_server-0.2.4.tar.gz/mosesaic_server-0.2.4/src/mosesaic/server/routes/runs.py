"""Run routes: poll status, list all runs."""

from __future__ import annotations
from uuid import UUID

from fastapi import APIRouter, HTTPException, Request

router = APIRouter(prefix="/runs", tags=["runs"])


@router.get("")
async def list_runs(request: Request) -> dict:
    reg = request.app.state.registry
    return {"runs": [r.to_dict() for r in reg.all_runs()]}


@router.get("/{run_id}")
async def get_run(run_id: UUID, request: Request) -> dict:
    reg = request.app.state.registry
    record = reg.get_run(run_id)
    if record is None:
        raise HTTPException(status_code=404, detail=f"Run '{run_id}' not found")
    return record.to_dict()
