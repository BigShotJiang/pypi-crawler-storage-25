"""Workflow routes: list, run."""

from __future__ import annotations
from typing import Any

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

router = APIRouter(prefix="/workflows", tags=["workflows"])


class RunWorkflowRequest(BaseModel):
    input: Any = None
    timeout_seconds: float | None = None
    wait: bool = False


@router.get("")
async def list_workflows(request: Request) -> dict:
    reg = request.app.state.registry
    names = reg.workflow_runtime.registered_workflows
    return {"workflows": names}


@router.post("/{name}/run")
async def run_workflow(name: str, body: RunWorkflowRequest, request: Request) -> dict:
    reg = request.app.state.registry
    if name not in reg.workflow_runtime.registered_workflows:
        raise HTTPException(status_code=404, detail=f"Workflow '{name}' not registered")

    record = await reg.start_workflow_run(
        name,
        input=body.input,
        timeout_seconds=body.timeout_seconds,
        wait=body.wait,
    )
    return record.to_dict()
