"""Agent routes: list, run, lifecycle."""

from __future__ import annotations
from typing import Any
from uuid import UUID

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel
from mosesaic.exceptions import MosesaicAgentNotFound

router = APIRouter(prefix="/agents", tags=["agents"])


class RunAgentRequest(BaseModel):
    payload: Any = None
    timeout_seconds: float | None = None
    wait: bool = False


@router.get("")
async def list_agents(request: Request) -> dict:
    reg = request.app.state.registry
    names = list(reg.agent_runtime._definitions.keys())
    return {"agents": names}


@router.post("/{name}/run")
async def run_agent(name: str, body: RunAgentRequest, request: Request) -> dict:
    reg = request.app.state.registry
    if name not in reg.agent_runtime._definitions:
        raise HTTPException(status_code=404, detail=f"Agent '{name}' not registered")

    record = await reg.start_agent_run(
        name,
        payload=body.payload,
        timeout_seconds=body.timeout_seconds,
        wait=body.wait,
    )
    return record.to_dict()


@router.post("/{name}/pause")
async def pause_agent(name: str, request: Request) -> dict:
    reg = request.app.state.registry
    try:
        reg.pause_agent(name)
    except (KeyError, MosesaicAgentNotFound):
        raise HTTPException(status_code=404, detail=f"Agent '{name}' not registered")
    return {"ok": True, "agent": name, "action": "paused"}


@router.post("/{name}/resume")
async def resume_agent(name: str, request: Request) -> dict:
    reg = request.app.state.registry
    try:
        reg.resume_agent(name)
    except (KeyError, MosesaicAgentNotFound):
        raise HTTPException(status_code=404, detail=f"Agent '{name}' not registered")
    return {"ok": True, "agent": name, "action": "resumed"}


@router.post("/{name}/stop")
async def stop_agent(name: str, request: Request) -> dict:
    reg = request.app.state.registry
    try:
        reg.stop_agent(name)
    except (KeyError, MosesaicAgentNotFound):
        raise HTTPException(status_code=404, detail=f"Agent '{name}' not registered")
    return {"ok": True, "agent": name, "action": "stopped"}
