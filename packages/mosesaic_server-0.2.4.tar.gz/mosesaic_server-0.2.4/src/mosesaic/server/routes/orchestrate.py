"""Orchestrate routes — run the full orchestration workflow and poll results."""
from __future__ import annotations

import asyncio
import json as _json
from uuid import UUID

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

router = APIRouter(prefix="/orchestrate", tags=["orchestrate"])


class OrchestrateRequest(BaseModel):
    prompt: str
    budget_usd: float = 1.0
    wait: bool = False          # if True, block until workflow finishes


class OrchestrateResponse(BaseModel):
    run_id: str
    status: str


@router.post("", status_code=202, response_model=OrchestrateResponse)
async def start_orchestration(req: OrchestrateRequest, request: Request):
    """Start a full orchestration workflow run.

    The orchestrate_workflow runs: chief_director → phase directors.
    Poll GET /orchestrate/{run_id} for the result, or stream it via
    GET /orchestrate/{run_id}/stream.
    """
    from mosesaic.team.orchestrator.director import DirectorInput

    registry = request.app.state.registry
    payload = DirectorInput(prompt=req.prompt)

    record = await registry.start_workflow_run(
        "orchestrate",
        input=payload,
        wait=req.wait,
    )
    return OrchestrateResponse(run_id=str(record.run_id), status=record.status)


@router.get("/{run_id}/stream")
async def stream_orchestration(run_id: str, request: Request):
    """Stream orchestration events as Server-Sent Events.

    Streams all events from the run's event log, then emits [DONE].
    For completed runs, emits the full log immediately.
    For running runs, polls every 0.25s until completion (max 120s).
    """
    try:
        uid = UUID(run_id)
    except ValueError:
        raise HTTPException(status_code=422, detail="Invalid run_id format")

    registry = request.app.state.registry
    record = registry.get_run(uid)
    if record is None:
        raise HTTPException(status_code=404, detail=f"Run {run_id!r} not found")

    async def event_stream():
        import dataclasses
        emitted = 0
        deadline = asyncio.get_running_loop().time() + 120.0

        while True:
            current = registry.get_run(uid)

            # Drain progress events from the workflow's queue
            q = getattr(current, "progress_queue", None)
            if q is not None:
                while not q.empty():
                    try:
                        prog = q.get_nowait()
                        yield f"data: {_json.dumps({'progress': True, **dataclasses.asdict(prog)})}\n\n"
                    except Exception:
                        break

            # Regular bus events (agent runs only; workflows don't populate this)
            events = getattr(current, "events", None) or []
            for evt in events[emitted:]:
                payload = _json.dumps({
                    "from": evt.from_agent,
                    "to": evt.to_agent,
                    "type": evt.type.value if hasattr(evt.type, "value") else str(evt.type),
                    "payload": str(evt.payload)[:500],
                })
                yield f"data: {payload}\n\n"
                emitted += 1

            if current.status not in ("running",):
                # Drain any remaining progress events before closing
                if q is not None:
                    while not q.empty():
                        try:
                            prog = q.get_nowait()
                            yield f"data: {_json.dumps({'progress': True, **dataclasses.asdict(prog)})}\n\n"
                        except Exception:
                            break
                yield f"data: {_json.dumps({'status': current.status, 'result': str(current.result)})}\n\n"
                yield "data: [DONE]\n\n"
                return

            if asyncio.get_running_loop().time() > deadline:
                yield "data: [TIMEOUT]\n\n"
                return

            await asyncio.sleep(0.25)

    return StreamingResponse(event_stream(), media_type="text/event-stream")


@router.get("/{run_id}")
async def get_orchestration(run_id: str, request: Request):
    """Return the current state of an orchestration run.

    For completed runs, includes run_log and total_cost_usd from OrchestrateResult.
    """
    try:
        uid = UUID(run_id)
    except ValueError:
        raise HTTPException(status_code=422, detail="Invalid run_id format")

    registry = request.app.state.registry
    record = registry.get_run(uid)
    if record is None:
        raise HTTPException(status_code=404, detail=f"Run {run_id!r} not found")

    response: dict = {
        "run_id": str(record.run_id),
        "status": record.status,
        "error": record.error,
        "completed_at": record.completed_at.isoformat() if record.completed_at else None,
    }

    result = record.result
    if result is not None:
        from mosesaic.team.orchestrator.protocol import OrchestrateResult
        if isinstance(result, OrchestrateResult):
            response["request_type"] = result.request_type
            response["phases_run"] = result.phases_run
            response["reasoning"] = result.reasoning
            response["total_cost_usd"] = result.total_cost_usd
            response["run_log"] = [
                {"phase": e.phase, "summary": e.summary, "cost_usd": e.cost_usd}
                for e in result.run_log
            ]
        else:
            response["result"] = str(result)

    return response
