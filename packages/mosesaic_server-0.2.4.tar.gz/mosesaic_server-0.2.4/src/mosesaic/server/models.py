"""Request and response Pydantic models for the Mosesaic REST API."""

from __future__ import annotations
import asyncio
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Literal
from uuid import UUID, uuid4


# ── Run records ──────────────────────────────────────────────────────────────

RunStatus = Literal["running", "completed", "failed", "timed_out"]


@dataclass
class RunRecord:
    """In-memory record of a single agent or workflow run."""

    run_id: UUID
    trace_id: UUID
    kind: Literal["agent", "workflow"]
    name: str
    status: RunStatus
    result: Any = None
    error: str | None = None
    events: list[Any] = field(default_factory=list)
    progress_queue: asyncio.Queue | None = None
    created_at: datetime = field(
        default_factory=lambda: datetime.now(timezone.utc)
    )
    completed_at: datetime | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "run_id": str(self.run_id),
            "trace_id": str(self.trace_id),
            "kind": self.kind,
            "name": self.name,
            "status": self.status,
            "result": self.result,
            "error": self.error,
            "created_at": self.created_at.isoformat(),
            "completed_at": (
                self.completed_at.isoformat() if self.completed_at else None
            ),
        }
