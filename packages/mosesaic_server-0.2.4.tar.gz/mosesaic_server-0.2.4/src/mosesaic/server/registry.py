"""
RunRegistry — in-memory store of all run records.
Drives agent/workflow execution and captures per-run event logs.
"""

from __future__ import annotations
import asyncio
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Any
from uuid import UUID, uuid4

from mosesaic.core.runtime import AgentRuntime
from mosesaic.workflow.runtime import WorkflowRuntime
from mosesaic.server.models import RunRecord

if TYPE_CHECKING:
    import anyio.abc


class RunRegistry:
    def __init__(
        self,
        agent_runtime: AgentRuntime,
        workflow_runtime: WorkflowRuntime | None = None,
    ) -> None:
        self._agent_runtime = agent_runtime
        self._workflow_runtime = workflow_runtime or WorkflowRuntime()
        self._runs: dict[UUID, RunRecord] = {}
        # Injected by app lifespan; enables anyio-native fire-and-forget (trio-safe).
        # Falls back to asyncio.ensure_future when None (asyncio-only contexts).
        self._background_tg: anyio.abc.TaskGroup | None = None

    @property
    def agent_runtime(self) -> AgentRuntime:
        return self._agent_runtime

    @property
    def workflow_runtime(self) -> WorkflowRuntime:
        return self._workflow_runtime

    # ── Queries ───────────────────────────────────────────────────────────────

    def get_run(self, run_id: UUID) -> RunRecord | None:
        return self._runs.get(run_id)

    def all_runs(self) -> list[RunRecord]:
        return list(self._runs.values())

    def all_events(self) -> list[Any]:
        """Aggregate events across all completed runs."""
        events: list[Any] = []
        for record in self._runs.values():
            events.extend(record.events)
        return events

    # ── Agent runs ────────────────────────────────────────────────────────────

    async def start_agent_run(
        self,
        agent_name: str,
        payload: Any = None,
        *,
        timeout_seconds: float | None = None,
        wait: bool = False,
    ) -> RunRecord:
        run_id = uuid4()
        trace_id = uuid4()
        record = RunRecord(
            run_id=run_id,
            trace_id=trace_id,
            kind="agent",
            name=agent_name,
            status="running",
        )
        self._runs[run_id] = record

        if wait:
            await self._execute_agent(record, payload, timeout_seconds)
        elif self._background_tg is not None:
            self._background_tg.start_soon(
                self._execute_agent, record, payload, timeout_seconds
            )
        else:
            asyncio.ensure_future(
                self._execute_agent(record, payload, timeout_seconds)
            )

        return record

    async def _execute_agent(
        self,
        record: RunRecord,
        payload: Any,
        timeout_seconds: float | None,
    ) -> None:
        from mosesaic.core.bus import MessageBus
        from mosesaic.core.cost import CostTracker
        from mosesaic.core.message import AgentMessage, MessageType
        from mosesaic.core.lifecycle import AgentLifecycle
        from mosesaic.core.context import AgentContext
        from mosesaic.workflow.result import StepError
        import anyio

        definition = self._agent_runtime._definitions.get(record.name)
        if definition is None:
            record.status = "failed"
            record.error = f"Agent '{record.name}' is not registered"
            record.completed_at = datetime.now(timezone.utc)
            return

        bus = MessageBus()
        bus.register(definition.name)

        input_msg = AgentMessage(
            from_agent="__server__",
            to_agent=definition.name,
            type=MessageType.TASK,
            payload=payload,
            trace_id=record.trace_id,
        )
        await bus.send(input_msg)

        cost_tracker = CostTracker(agent_name=definition.name)
        lifecycle = AgentLifecycle()
        ctx = AgentContext(
            agent_name=definition.name,
            bus=bus,
            cost_tracker=cost_tracker,
            lifecycle=lifecycle,
            trace_id=record.trace_id,
        )

        try:
            with anyio.fail_after(timeout_seconds or 120.0):
                await definition.fn(ctx)
            record.status = "completed"
            sent = [
                m for m in bus.event_log()
                if m.from_agent == definition.name
            ]
            record.result = sent[-1].payload if sent else None
        except TimeoutError:
            record.status = "timed_out"
            record.error = f"Agent timed out after {timeout_seconds or 120}s"
        except Exception as exc:
            record.status = "failed"
            record.error = str(exc)
        finally:
            record.events = bus.event_log()
            record.completed_at = datetime.now(timezone.utc)

    # ── Workflow runs ─────────────────────────────────────────────────────────

    async def start_workflow_run(
        self,
        workflow_name: str,
        input: Any = None,
        *,
        timeout_seconds: float | None = None,
        wait: bool = False,
    ) -> RunRecord:
        run_id = uuid4()
        trace_id = uuid4()
        record = RunRecord(
            run_id=run_id,
            trace_id=trace_id,
            kind="workflow",
            name=workflow_name,
            status="running",
        )
        self._runs[run_id] = record

        if wait:
            await self._execute_workflow(record, input, timeout_seconds)
        elif self._background_tg is not None:
            self._background_tg.start_soon(
                self._execute_workflow, record, input, timeout_seconds
            )
        else:
            asyncio.ensure_future(
                self._execute_workflow(record, input, timeout_seconds)
            )

        return record

    async def _execute_workflow(
        self,
        record: RunRecord,
        input: Any,
        timeout_seconds: float | None,
    ) -> None:
        import asyncio
        from mosesaic.core.progress import _progress_queue

        # Attach a progress queue so the SSE stream can drain it
        queue: asyncio.Queue = asyncio.Queue(maxsize=1000)
        record.progress_queue = queue
        token = _progress_queue.set(queue)

        try:
            wf_result = await self._workflow_runtime.run(
                record.name,
                input=input,
                timeout_seconds=timeout_seconds,
            )
            record.status = wf_result.status  # type: ignore[assignment]
            record.result = wf_result.output
            record.error = wf_result.error
        except KeyError as exc:
            record.status = "failed"
            record.error = str(exc)
        finally:
            _progress_queue.reset(token)
            record.completed_at = datetime.now(timezone.utc)

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    def pause_agent(self, name: str) -> None:
        self._agent_runtime.pause(name)

    def resume_agent(self, name: str) -> None:
        self._agent_runtime.resume(name)

    def stop_agent(self, name: str) -> None:
        self._agent_runtime.stop(name)
