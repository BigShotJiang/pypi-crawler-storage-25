"""
CLI entrypoint: mosesaic-server

Usage:
    mosesaic-server agents.py --host 0.0.0.0 --port 8000
    mosesaic-server agents.py:my_setup_fn --reload
"""

from __future__ import annotations
import argparse
import importlib.util
import sys
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Mosesaic REST API server",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
The MODULE argument accepts:
  path/to/agents.py          Load all @agent definitions from the file
  path/to/agents.py:setup    Call setup() which returns (AgentRuntime, WorkflowRuntime)
        """,
    )
    parser.add_argument("module", help="Python file containing agent definitions")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--reload", action="store_true")
    args = parser.parse_args()

    import uvicorn
    from mosesaic.core.runtime import AgentRuntime
    from mosesaic.core.agent import AgentDefinition
    from mosesaic.workflow.runtime import WorkflowRuntime
    from mosesaic.workflow.definition import WorkflowDefinition
    from mosesaic.server.app import create_app

    # Parse module spec
    spec_str = args.module
    attr = None
    if ":" in spec_str:
        spec_str, attr = spec_str.rsplit(":", 1)

    path = Path(spec_str)
    if not path.exists():
        sys.exit(f"File not found: {path}")

    spec = importlib.util.spec_from_file_location("_mosesaic_user_module", path)
    mod = importlib.util.module_from_spec(spec)  # type: ignore[arg-type]
    spec.loader.exec_module(mod)  # type: ignore[union-attr]

    agent_rt = AgentRuntime()
    wf_rt = WorkflowRuntime()

    if attr:
        # Call the setup function to get configured runtimes
        setup_fn = getattr(mod, attr)
        result = setup_fn()
        if isinstance(result, tuple):
            agent_rt, wf_rt = result
        else:
            agent_rt = result
    else:
        # Auto-discover all AgentDefinition and WorkflowDefinition instances
        for name in dir(mod):
            obj = getattr(mod, name)
            if isinstance(obj, AgentDefinition):
                agent_rt.register(obj)
                wf_rt.register_agent(obj)
            elif isinstance(obj, WorkflowDefinition):
                wf_rt.register_workflow(obj)

    app = create_app(agent_rt, wf_rt)
    uvicorn.run(app, host=args.host, port=args.port, reload=args.reload)


if __name__ == "__main__":
    main()
