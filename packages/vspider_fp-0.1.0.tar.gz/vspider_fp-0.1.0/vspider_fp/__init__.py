import subprocess
import hashlib

def get():
    components = []
    try:
        fp = subprocess.check_output(['getprop', 'ro.build.fingerprint'], stderr=subprocess.DEVNULL).decode().strip()
        if fp: components.append(fp)
    except: pass
    try:
        model = subprocess.check_output(['getprop', 'ro.product.model'], stderr=subprocess.DEVNULL).decode().strip()
        device = subprocess.check_output(['getprop', 'ro.product.device'], stderr=subprocess.DEVNULL).decode().strip()
        if model and device: components.append(f"{model}|{device}")
    except: pass
    try:
        mfg = subprocess.check_output(['getprop', 'ro.product.manufacturer'], stderr=subprocess.DEVNULL).decode().strip()
        brand = subprocess.check_output(['getprop', 'ro.product.brand'], stderr=subprocess.DEVNULL).decode().strip()
        if mfg and brand: components.append(f"{mfg}|{brand}")
    except: pass
    try:
        build_id = subprocess.check_output(['getprop', 'ro.build.id'], stderr=subprocess.DEVNULL).decode().strip()
        release = subprocess.check_output(['getprop', 'ro.build.version.release'], stderr=subprocess.DEVNULL).decode().strip()
        if build_id and release: components.append(f"{build_id}|{release}")
    except: pass
    try:
        board = subprocess.check_output(['getprop', 'ro.product.board'], stderr=subprocess.DEVNULL).decode().strip()
        if board: components.append(board)
    except: pass
    combined = "|".join(components)
    return hashlib.sha512(combined.encode()).hexdigest()[:64]
