from __future__ import annotations

import logging

from mycel_cli.group.terminal import get_freeform_terminal


def send_terminal_hint(terminal_type: str, target_id: str, text: str) -> None:
    get_freeform_terminal(terminal_type).send_text(target_id, text)


def try_send_terminal_hint(
    terminal_type: str,
    target_id: str,
    text: str,
    *,
    logger: logging.Logger,
    log_label: str,
) -> bool:
    try:
        send_terminal_hint(terminal_type, target_id, text)
        return True
    except Exception:
        logger.exception(
            "%s terminal=%s target=%s failed (msg head=%r)",
            log_label,
            terminal_type,
            target_id,
            text[:80],
        )
        return False
