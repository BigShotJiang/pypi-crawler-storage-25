from typing import Any

import numpy as np
import pandas as pd


class Portfolio:
    def __init__(
        self,
        assets: int | list[str] | dict[str, float],
        name: str = "portfolio",
    ):
        self.name = name
        if isinstance(assets, int):
            self.assets = {f"Asset.{i + 1}": 0.0 for i in range(assets)}
        elif isinstance(assets, list):
            self.assets = {a: 0.0 for a in assets}
        else:
            self.assets = assets
        self.constraints = []
        self.objectives = []

    def add_constraint(self, type: str, enabled: bool = True, **kwargs):
        constraint = {"type": type, "enabled": enabled}
        nassets = len(self.assets)
        asset_names = list(self.assets.keys())

        if type in [
            "weight_sum",
            "leverage",
            "full_investment",
            "dollar_neutral",
            "active",
        ]:
            min_sum, max_sum = 0.99, 1.01
            if type == "full_investment":
                min_sum, max_sum = 1.0, 1.0
            elif type in ["dollar_neutral", "active"]:
                min_sum, max_sum = 0.0, 0.0
            else:
                min_sum = kwargs.get("min_sum", min_sum)
                max_sum = kwargs.get("max_sum", max_sum)
            constraint.update({"min_sum": min_sum, "max_sum": max_sum})
        elif type in ["box", "long_only"]:
            if type == "long_only":
                min_val, max_val = 0.0, 1.0
            else:
                min_val = kwargs.get("min", 0.0)
                max_val = kwargs.get("max", 1.0)

            if isinstance(min_val, (int, float)):
                min_vec = np.full(nassets, float(min_val))
            else:
                min_vec = np.array(min_val)

            if isinstance(max_val, (int, float)):
                max_vec = np.full(nassets, float(max_val))
            else:
                max_vec = np.array(max_val)

            constraint.update(
                {
                    "min": pd.Series(min_vec, index=asset_names),
                    "max": pd.Series(max_vec, index=asset_names),
                }
            )
        elif type == "group":
            constraint.update(
                {
                    "groups": kwargs.get("groups"),
                    "group_min": kwargs.get("group_min"),
                    "group_max": kwargs.get("group_max"),
                }
            )
        elif type in ["turnover", "transaction_cost"]:
            init_weights = kwargs.get("weight_initial")
            if init_weights is None:
                init_weights = np.array(list(self.assets.values()))
            elif isinstance(init_weights, dict):
                init_weights = np.array(
                    [init_weights.get(name, 0.0) for name in asset_names]
                )
            elif isinstance(init_weights, pd.Series):
                init_weights = init_weights.reindex(asset_names).values
            constraint.update({"weight_initial": init_weights})
            if type == "turnover":
                constraint.update({"turnover_target": kwargs.get("turnover_target")})
            else:
                ptc = kwargs.get("ptc", 0.0)
                if isinstance(ptc, (int, float)):
                    ptc = np.full(nassets, float(ptc))
                constraint.update({"ptc": ptc})
        elif type == "position_limit":
            constraint.update({"max_pos": kwargs.get("max_pos")})
        elif type == "tracking_error":
            if "benchmark" not in kwargs:
                raise ValueError("tracking_error constraint requires a 'benchmark' argument.")
            constraint.update(
                {
                    "target": kwargs.get("target", 0.05),
                    "benchmark": kwargs.get("benchmark"),
                    "p_norm": kwargs.get("p_norm", 2),
                }
            )
        elif type == "active_share":
            if "benchmark" not in kwargs:
                raise ValueError("active_share constraint requires a 'benchmark' argument.")
            constraint.update(
                {
                    "active_share_target": kwargs.get("target", 0.6),
                    "active_share_benchmark": kwargs.get("benchmark"),
                }
            )
        elif type == "factor_exposure":
            B = kwargs.get("B")
            lower = kwargs.get("lower")
            upper = kwargs.get("upper")

            if B is None or lower is None or upper is None:
                raise ValueError(
                    "Factor exposure constraint requires B, lower, and upper."
                )

            # Convert B to matrix if it's a list or vector
            if isinstance(B, (list, np.ndarray)) and not isinstance(B, pd.DataFrame):
                B = np.array(B)
                if B.ndim == 1:
                    B = B.reshape(-1, 1)

            # Validate dimensions
            if B.shape[0] != nassets:
                raise ValueError(f"B must have {nassets} rows (number of assets).")

            nfactors = B.shape[1]
            if len(lower) != nfactors or len(upper) != nfactors:
                raise ValueError(
                    f"lower and upper must have length {nfactors} (number of factors)."
                )

            constraint.update(
                {"B": B, "lower": np.array(lower), "upper": np.array(upper)}
            )
        elif type == "leverage_exposure":
            leverage = kwargs.get("leverage")
            if leverage is None:
                raise ValueError(
                    "leverage_exposure constraint requires 'leverage' parameter."
                )
            constraint.update({"leverage": float(leverage)})
        elif type in ["diversification", "HHI"]:
            div_target = kwargs.get("div_target")
            if div_target is None:
                # If HHI is passed, convert to div_target
                hhi_target = kwargs.get("hhi_target")
                if hhi_target is not None:
                    div_target = 1.0 - hhi_target
                else:
                    raise ValueError(
                        "diversification constraint requires 'div_target' or 'hhi_target'."
                    )
            constraint.update({"div_target": float(div_target)})
        elif type == "robust":
            delta_mu = kwargs.get("delta_mu", 0.0)
            if isinstance(delta_mu, (int, float)):
                delta_mu_vec = np.full(nassets, float(delta_mu))
            else:
                delta_mu_vec = np.array(delta_mu)
            constraint.update({"delta_mu": pd.Series(delta_mu_vec, index=asset_names)})
        elif type == "linear":
            A = kwargs.get("A")
            b = kwargs.get("b")
            A_eq = kwargs.get("A_eq")
            b_eq = kwargs.get("b_eq")
            if A is not None and b is not None:
                constraint.update({"A": np.array(A), "b": np.array(b)})
            if A_eq is not None and b_eq is not None:
                constraint.update({"A_eq": np.array(A_eq), "b_eq": np.array(b_eq)})

        self.constraints.append(constraint)
        return self

    def add_objective(
        self,
        type: str,
        name: str | None = None,
        enabled: bool = True,
        arguments: dict[str, Any] | None = None,
        multiplier: float | None = None,
        **kwargs,
    ):
        if name is None:
            name = type
        if multiplier is None:
            if type in ["return", "return_objective"]:
                multiplier = -1.0
            else:
                multiplier = 1.0
        obj = {
            "type": type,
            "name": name,
            "enabled": enabled,
            "arguments": arguments or {},
            "multiplier": multiplier,
            "target": kwargs.get("target"),
        }
        obj.update(kwargs)
        self.objectives.append(obj)
        return self

    def get_constraints(self) -> dict[str, Any]:
        asset_names = list(self.assets.keys())
        len(asset_names)
        res: dict[str, Any] = {
            "min_sum": -np.inf,
            "max_sum": np.inf,
            "min": pd.Series(-np.inf, index=asset_names),
            "max": pd.Series(np.inf, index=asset_names),
            "linear_A": [],
            "linear_b": [],
            "linear_A_eq": [],
            "linear_b_eq": [],
        }
        for constr in self.constraints:
            if not constr.get("enabled", True):
                continue
            ctype = constr["type"]
            if ctype in [
                "weight_sum",
                "leverage",
                "full_investment",
                "dollar_neutral",
                "active",
            ]:
                res["min_sum"] = max(res["min_sum"], constr["min_sum"])
                res["max_sum"] = min(res["max_sum"], constr["max_sum"])
            elif ctype in ["box", "long_only"]:
                res["min"] = np.maximum(res["min"], constr["min"])
                res["max"] = np.minimum(res["max"], constr["max"])
            elif ctype == "linear":
                if "A" in constr and "b" in constr:
                    if "linear_A" not in res:
                        res["linear_A"] = []
                        res["linear_b"] = []
                    res["linear_A"].append(constr["A"])
                    res["linear_b"].append(constr["b"])
                if "A_eq" in constr and "b_eq" in constr:
                    if "linear_A_eq" not in res:
                        res["linear_A_eq"] = []
                        res["linear_b_eq"] = []
                    res["linear_A_eq"].append(constr["A_eq"])
                    res["linear_b_eq"].append(constr["b_eq"])
            else:
                res.update(
                    {k: v for k, v in constr.items() if k not in ["type", "enabled"]}
                )

        # Final cleanup of box defaults if still -inf/inf
        res["min"] = res["min"].replace(-np.inf, -1.0)
        res["max"] = res["max"].replace(np.inf, 1.0)
        return res

    def clear_objectives(self):
        self.objectives = []
        return self

    def copy(self):
        import copy

        return copy.deepcopy(self)

    def __repr__(self):
        return f"Portfolio(name={self.name}, assets={list(self.assets.keys())})"


class RegimePortfolio:
    def __init__(self, portfolios: list[Portfolio], regime_labels: list[Any]):
        if len(portfolios) != len(regime_labels):
            raise ValueError("Number of portfolios must match number of regime labels.")
        self.portfolios = dict(zip(regime_labels, portfolios))
        self.regime_labels = regime_labels

    def get_portfolio(self, regime: Any) -> Portfolio:
        if regime not in self.portfolios:
            return next(iter(self.portfolios.values()))
        return self.portfolios[regime]

    def clear_objectives(self):
        self.objectives = []
        return self

    def copy(self):
        import copy

        return copy.deepcopy(self)

    def __repr__(self):
        return f"RegimePortfolio(regimes={self.regime_labels})"


class MultLayerPortfolio:
    def __init__(self, root_portfolio: Portfolio):
        self.root = root_portfolio
        self.sub_portfolios = {}

    def add_sub_portfolio(self, meta_asset_name: str, sub_portfolio: 'Portfolio | MultLayerPortfolio'):
        if meta_asset_name not in self.root.assets:
            raise ValueError(
                f"'{meta_asset_name}' must be defined as an asset in the root portfolio."
            )
        self.sub_portfolios[meta_asset_name] = sub_portfolio

    def clear_objectives(self):
        self.objectives = []
        return self

    def copy(self):
        import copy

        return copy.deepcopy(self)

    def __repr__(self):
        return f"MultLayerPortfolio(root={self.root.name}, sub={list(self.sub_portfolios.keys())})"
