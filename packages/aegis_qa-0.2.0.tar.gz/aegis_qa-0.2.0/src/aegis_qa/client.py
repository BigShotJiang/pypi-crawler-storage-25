"""Typed Python SDK client for the Aegis API."""

from __future__ import annotations

import httpx

from aegis_qa.api.schemas import (
    EventResponse,
    HealthCheckResponse,
    PortfolioResponse,
    ServiceHealthResponse,
    ServiceResponse,
    WorkflowHistoryEntry,
    WorkflowResponse,
    WorkflowRunResponse,
)


class AegisClient:
    """Synchronous client for the Aegis API.

    Args:
        base_url: Base URL of the Aegis server.
        api_key: Optional API key for authenticated endpoints.
        timeout: Request timeout in seconds.
    """

    def __init__(
        self,
        base_url: str = "http://localhost:8000",
        api_key: str | None = None,
        timeout: float = 30.0,
    ) -> None:
        headers: dict[str, str] = {}
        if api_key:
            headers["X-API-Key"] = api_key
        self._client = httpx.Client(base_url=base_url, headers=headers, timeout=timeout)

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> AegisClient:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    def health(self) -> HealthCheckResponse:
        """Get system health status."""
        resp = self._client.get("/health")
        resp.raise_for_status()
        return HealthCheckResponse.model_validate(resp.json())

    def list_services(self) -> list[ServiceResponse]:
        """List all registered services."""
        resp = self._client.get("/api/services")
        resp.raise_for_status()
        return [ServiceResponse.model_validate(item) for item in resp.json()]

    def service_health(self, name: str) -> ServiceHealthResponse:
        """Check health of a single service."""
        resp = self._client.get(f"/api/services/{name}/health")
        resp.raise_for_status()
        return ServiceHealthResponse.model_validate(resp.json())

    def list_workflows(self) -> list[WorkflowResponse]:
        """List all configured workflows."""
        resp = self._client.get("/api/workflows")
        resp.raise_for_status()
        return [WorkflowResponse.model_validate(item) for item in resp.json()]

    def get_workflow(self, name: str) -> WorkflowResponse:
        """Get a single workflow definition."""
        resp = self._client.get(f"/api/workflows/{name}")
        resp.raise_for_status()
        return WorkflowResponse.model_validate(resp.json())

    def run_workflow(self, name: str) -> WorkflowRunResponse:
        """Execute a workflow by name."""
        resp = self._client.post(f"/api/workflows/{name}/run")
        resp.raise_for_status()
        return WorkflowRunResponse.model_validate(resp.json())

    def workflow_history(self, name: str) -> list[WorkflowHistoryEntry]:
        """Get execution history for a specific workflow."""
        resp = self._client.get(f"/api/workflows/{name}/history")
        resp.raise_for_status()
        return [WorkflowHistoryEntry.model_validate(item) for item in resp.json()]

    def recent_history(self, limit: int = 20) -> list[WorkflowHistoryEntry]:
        """Get recent execution history across all workflows."""
        resp = self._client.get("/api/history", params={"limit": limit})
        resp.raise_for_status()
        return [WorkflowHistoryEntry.model_validate(item) for item in resp.json()]

    def events(
        self, limit: int = 50, event_type: str | None = None
    ) -> list[EventResponse]:
        """Get recent workflow events."""
        params: dict[str, str | int] = {"limit": limit}
        if event_type:
            params["event_type"] = event_type
        resp = self._client.get("/api/events", params=params)
        resp.raise_for_status()
        return [EventResponse.model_validate(item) for item in resp.json()]

    def portfolio(self) -> PortfolioResponse:
        """Get portfolio metadata."""
        resp = self._client.get("/api/portfolio")
        resp.raise_for_status()
        return PortfolioResponse.model_validate(resp.json())


class AsyncAegisClient:
    """Asynchronous client for the Aegis API.

    Args:
        base_url: Base URL of the Aegis server.
        api_key: Optional API key for authenticated endpoints.
        timeout: Request timeout in seconds.
    """

    def __init__(
        self,
        base_url: str = "http://localhost:8000",
        api_key: str | None = None,
        timeout: float = 30.0,
    ) -> None:
        headers: dict[str, str] = {}
        if api_key:
            headers["X-API-Key"] = api_key
        self._client = httpx.AsyncClient(
            base_url=base_url, headers=headers, timeout=timeout
        )

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        await self._client.aclose()

    async def __aenter__(self) -> AsyncAegisClient:
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.close()

    async def health(self) -> HealthCheckResponse:
        """Get system health status."""
        resp = await self._client.get("/health")
        resp.raise_for_status()
        return HealthCheckResponse.model_validate(resp.json())

    async def list_services(self) -> list[ServiceResponse]:
        """List all registered services."""
        resp = await self._client.get("/api/services")
        resp.raise_for_status()
        return [ServiceResponse.model_validate(item) for item in resp.json()]

    async def service_health(self, name: str) -> ServiceHealthResponse:
        """Check health of a single service."""
        resp = await self._client.get(f"/api/services/{name}/health")
        resp.raise_for_status()
        return ServiceHealthResponse.model_validate(resp.json())

    async def list_workflows(self) -> list[WorkflowResponse]:
        """List all configured workflows."""
        resp = await self._client.get("/api/workflows")
        resp.raise_for_status()
        return [WorkflowResponse.model_validate(item) for item in resp.json()]

    async def get_workflow(self, name: str) -> WorkflowResponse:
        """Get a single workflow definition."""
        resp = await self._client.get(f"/api/workflows/{name}")
        resp.raise_for_status()
        return WorkflowResponse.model_validate(resp.json())

    async def run_workflow(self, name: str) -> WorkflowRunResponse:
        """Execute a workflow by name."""
        resp = await self._client.post(f"/api/workflows/{name}/run")
        resp.raise_for_status()
        return WorkflowRunResponse.model_validate(resp.json())

    async def workflow_history(self, name: str) -> list[WorkflowHistoryEntry]:
        """Get execution history for a specific workflow."""
        resp = await self._client.get(f"/api/workflows/{name}/history")
        resp.raise_for_status()
        return [WorkflowHistoryEntry.model_validate(item) for item in resp.json()]

    async def recent_history(self, limit: int = 20) -> list[WorkflowHistoryEntry]:
        """Get recent execution history across all workflows."""
        resp = await self._client.get("/api/history", params={"limit": limit})
        resp.raise_for_status()
        return [WorkflowHistoryEntry.model_validate(item) for item in resp.json()]

    async def events(
        self, limit: int = 50, event_type: str | None = None
    ) -> list[EventResponse]:
        """Get recent workflow events."""
        params: dict[str, str | int] = {"limit": limit}
        if event_type:
            params["event_type"] = event_type
        resp = await self._client.get("/api/events", params=params)
        resp.raise_for_status()
        return [EventResponse.model_validate(item) for item in resp.json()]

    async def portfolio(self) -> PortfolioResponse:
        """Get portfolio metadata."""
        resp = await self._client.get("/api/portfolio")
        resp.raise_for_status()
        return PortfolioResponse.model_validate(resp.json())
