"""Aegis — The AI Quality Control Plane."""

import importlib.metadata

try:
    __version__ = importlib.metadata.version("aegis-qa")
except importlib.metadata.PackageNotFoundError:
    __version__ = "0.0.0-dev"
