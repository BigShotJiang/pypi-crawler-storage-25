"""Logging configuration for Aegis."""

from __future__ import annotations

import json
import logging
import logging.config
import os
from datetime import UTC, datetime


class JsonFormatter(logging.Formatter):
    """JSON log formatter for production deployments."""

    _BUILTIN_ATTRS = frozenset(logging.LogRecord("", 0, "", 0, "", (), None).__dict__)

    def format(self, record: logging.LogRecord) -> str:
        log_entry: dict[str, object] = {
            "timestamp": datetime.now(UTC).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        if record.exc_info and record.exc_info[0] is not None:
            log_entry["exception"] = self.formatException(record.exc_info)
        for key, value in record.__dict__.items():
            if key not in self._BUILTIN_ATTRS and key != "message":
                log_entry[key] = value
        return json.dumps(log_entry, default=str)


_configured = False


def configure_logging(
    level: str | None = None,
    json_format: bool | None = None,
) -> None:
    """Configure application-wide logging.

    Precedence: explicit argument > env var > default.
    """
    global _configured  # noqa: PLW0603
    resolved_level = (level or os.environ.get("AEGIS_LOG_LEVEL", "INFO")).upper()
    if json_format is None:
        json_format = os.environ.get("AEGIS_LOG_FORMAT", "text").lower() == "json"

    formatter = "json" if json_format else "text"

    logging.config.dictConfig(
        {
            "version": 1,
            "disable_existing_loggers": False,
            "formatters": {
                "text": {
                    "format": "%(asctime)s %(levelname)-8s %(name)s — %(message)s",
                    "datefmt": "%Y-%m-%d %H:%M:%S",
                },
                "json": {
                    "()": "aegis_qa.logging.JsonFormatter",
                },
            },
            "handlers": {
                "console": {
                    "class": "logging.StreamHandler",
                    "stream": "ext://sys.stderr",
                    "formatter": formatter,
                },
            },
            "root": {
                "level": resolved_level,
                "handlers": ["console"],
            },
        }
    )
    _configured = True
