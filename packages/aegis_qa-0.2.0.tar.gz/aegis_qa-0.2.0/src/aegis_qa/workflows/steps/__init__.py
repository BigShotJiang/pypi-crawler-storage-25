"""Workflow step type registry with entry-point plugin discovery."""

from __future__ import annotations

import importlib
import importlib.metadata
import logging

from aegis_qa.workflows.steps.base import BaseStep

logger = logging.getLogger(__name__)

_ENTRY_POINT_GROUP = "aegis_qa.steps"

# Hardcoded built-in mapping — loaded via direct import, NOT entry points.
# A third-party package cannot impersonate a built-in by registering the same name.
_BUILTINS: dict[str, str] = {
    "discover": "aegis_qa.workflows.steps.discover:DiscoverStep",
    "test": "aegis_qa.workflows.steps.test:RunTestsStep",
    "submit_bugs": "aegis_qa.workflows.steps.submit_bugs:SubmitBugsStep",
    "verify": "aegis_qa.workflows.steps.verify:VerifyStep",
    "report": "aegis_qa.workflows.steps.report:ReportStep",
}


def _import_class(dotted_path: str) -> type[BaseStep] | None:
    """Import a class from a 'module:ClassName' string. Returns None on failure."""
    module_path, _, class_name = dotted_path.rpartition(":")
    try:
        mod = importlib.import_module(module_path)
        cls = getattr(mod, class_name)
    except Exception:
        logger.warning("Failed to import step %r", dotted_path, exc_info=True)
        return None

    if not isinstance(cls, type) or not issubclass(cls, BaseStep):
        logger.warning("Step %r is not a BaseStep subclass, skipping", dotted_path)
        return None

    return cls


def load_step_registry() -> dict[str, type[BaseStep]]:
    """Discover and load all step types.

    Two-phase loading ensures built-ins always win:
    1. Seed registry from _BUILTINS via direct import (trusted source).
    2. Scan entry points for plugins (names NOT in _BUILTINS),
       sorted by (ep.name, ep.value). Duplicates logged and skipped.
    """
    registry: dict[str, type[BaseStep]] = {}

    # Phase 1: built-ins via direct import (trusted, deterministic)
    for name, dotted_path in _BUILTINS.items():
        cls = _import_class(dotted_path)
        if cls is not None:
            registry[name] = cls

    # Phase 2: plugins via entry points (sorted by name+value for determinism)
    all_eps = importlib.metadata.entry_points(group=_ENTRY_POINT_GROUP)
    plugin_eps = sorted(
        (ep for ep in all_eps if ep.name not in _BUILTINS),
        key=lambda ep: (ep.name, ep.value),
    )
    for ep in plugin_eps:
        if ep.name in registry:
            logger.warning(
                "Duplicate step type %r — keeping existing, skipping %s",
                ep.name,
                ep.value,
            )
            continue
        try:
            cls = ep.load()
        except Exception:
            logger.warning("Failed to load step plugin %r", ep.name, exc_info=True)
            continue
        if not isinstance(cls, type) or not issubclass(cls, BaseStep):
            logger.warning("Step plugin %r is not a BaseStep subclass, skipping", ep.name)
            continue
        registry[ep.name] = cls

    logger.info("Loaded %d step types: %s", len(registry), sorted(registry.keys()))
    return registry


# Module-level registry — populated at import time
STEP_REGISTRY: dict[str, type[BaseStep]] = load_step_registry()

__all__ = ["STEP_REGISTRY", "BaseStep", "load_step_registry"]
