"""Prometheus metrics definitions for Aegis."""

from __future__ import annotations

from prometheus_client import REGISTRY, CollectorRegistry, Counter, Gauge, Histogram


def _make_metrics(
    registry: CollectorRegistry = REGISTRY,
) -> tuple[Counter, Histogram, Gauge, Counter, Histogram, Histogram, Gauge, Gauge, Counter]:
    """Create all Aegis metrics in the given registry.

    Production code uses the default global REGISTRY.
    Tests call this with a fresh CollectorRegistry() and monkeypatch
    the module-level constants.
    """
    return (
        Counter(
            "aegis_http_requests_total",
            "Total HTTP requests",
            ["method", "path_template", "status_code"],
            registry=registry,
        ),
        Histogram(
            "aegis_http_request_duration_seconds",
            "HTTP request duration in seconds",
            ["method", "path_template"],
            registry=registry,
        ),
        Gauge(
            "aegis_http_requests_in_progress",
            "HTTP requests currently in progress",
            ["method"],
            registry=registry,
        ),
        Counter(
            "aegis_workflow_runs_total",
            "Total workflow executions",
            ["workflow", "status"],
            registry=registry,
        ),
        Histogram(
            "aegis_workflow_duration_seconds",
            "Workflow execution duration in seconds",
            ["workflow"],
            registry=registry,
        ),
        Histogram(
            "aegis_workflow_step_duration_seconds",
            "Individual workflow step duration in seconds",
            ["workflow", "step_type", "service"],
            registry=registry,
        ),
        Gauge(
            "aegis_service_health_up",
            "Service health status (1=healthy, 0=unhealthy)",
            ["service"],
            registry=registry,
        ),
        Gauge(
            "aegis_service_health_latency_seconds",
            "Service health check latency in seconds",
            ["service"],
            registry=registry,
        ),
        Counter(
            "aegis_service_health_checks_total",
            "Total service health checks",
            ["service", "status"],
            registry=registry,
        ),
    )


# Module-level constants — production uses global registry.
# Consumer modules MUST use ``import aegis_qa.metrics as metrics`` and
# reference ``metrics.HTTP_REQUESTS_TOTAL`` etc. so that monkeypatching
# in tests propagates through the module namespace.
(
    HTTP_REQUESTS_TOTAL,
    HTTP_REQUEST_DURATION,
    HTTP_REQUESTS_IN_PROGRESS,
    WORKFLOW_RUNS_TOTAL,
    WORKFLOW_DURATION,
    WORKFLOW_STEP_DURATION,
    SERVICE_HEALTH_UP,
    SERVICE_HEALTH_LATENCY,
    SERVICE_HEALTH_CHECKS_TOTAL,
) = _make_metrics()
