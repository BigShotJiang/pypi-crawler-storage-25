"""Service registry — loads services from config and checks health."""

from __future__ import annotations

import asyncio

import aegis_qa.metrics as metrics
from aegis_qa.config.models import AegisConfig, ServiceEntry
from aegis_qa.registry.health import check_all_services, check_health
from aegis_qa.registry.models import HealthResult, ServiceStatus


def _record_health_metrics(service_key: str, result: HealthResult) -> None:
    """Record Prometheus metrics for a health check result."""
    metrics.SERVICE_HEALTH_UP.labels(service=service_key).set(1 if result.healthy else 0)
    if result.latency_ms is not None:
        metrics.SERVICE_HEALTH_LATENCY.labels(service=service_key).set(result.latency_ms / 1000)
    metrics.SERVICE_HEALTH_CHECKS_TOTAL.labels(
        service=service_key,
        status="healthy" if result.healthy else "unhealthy",
    ).inc()


class ServiceRegistry:
    """Registry of downstream services with health-check support."""

    def __init__(self, config: AegisConfig) -> None:
        self._config = config
        self._services: dict[str, ServiceEntry] = dict(config.services)

    @property
    def service_keys(self) -> list[str]:
        return list(self._services.keys())

    def get_entry(self, key: str) -> ServiceEntry | None:
        return self._services.get(key)

    async def check_one(self, key: str, timeout: float = 5.0) -> HealthResult:
        entry = self._services.get(key)
        if entry is None:
            return HealthResult(healthy=False, error=f"Unknown service: {key}")
        result = await check_health(entry, timeout=timeout)
        _record_health_metrics(key, result)
        return result

    async def check_all(self, timeout: float = 5.0) -> dict[str, HealthResult]:
        return await check_all_services(self._services, timeout=timeout)

    async def get_all_statuses(self, timeout: float = 5.0) -> list[ServiceStatus]:
        health_map = await self.check_all(timeout=timeout)
        statuses: list[ServiceStatus] = []
        for key, entry in self._services.items():
            health_result = health_map.get(key)
            if health_result is not None:
                _record_health_metrics(key, health_result)
            statuses.append(
                ServiceStatus(
                    key=key,
                    name=entry.name,
                    description=entry.description,
                    url=entry.url,
                    features=list(entry.features),
                    health=health_result,
                )
            )
        return statuses

    def get_all_statuses_sync(self, timeout: float = 5.0) -> list[ServiceStatus]:
        return asyncio.run(self.get_all_statuses(timeout=timeout))
