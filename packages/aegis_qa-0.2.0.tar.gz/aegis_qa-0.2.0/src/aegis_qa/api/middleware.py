"""Request logging and metrics middleware for Aegis API."""

from __future__ import annotations

import logging
import re
import time
import uuid
from typing import Any

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response
from starlette.types import ASGIApp

import aegis_qa.metrics as metrics

logger = logging.getLogger(__name__)

# Ordered longest-first so /api/workflows/{name}/run matches before /api/workflows/{name}
_PATH_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    (re.compile(r"/api/services/[^/]+/health"), "/api/services/{name}/health"),
    (re.compile(r"/api/services/[^/]+"), "/api/services/{name}"),
    (re.compile(r"/api/workflows/[^/]+/run"), "/api/workflows/{name}/run"),
    (re.compile(r"/api/workflows/[^/]+/history"), "/api/workflows/{name}/history"),
    (re.compile(r"/api/workflows/[^/]+"), "/api/workflows/{name}"),
]


def _normalize_path(request: Request) -> str:
    """Replace path parameters with {name} templates for metric labels.

    Uses regex fullmatch against known parameterized patterns.
    Unmatched paths (e.g. /health, /api/services, /api/portfolio) are
    returned verbatim — these are already low-cardinality fixed paths.
    """
    path = request.url.path
    for pattern, template in _PATH_PATTERNS:
        if pattern.fullmatch(path):
            return template
    return path


class RequestLoggingMiddleware(BaseHTTPMiddleware):
    """Log every request with method, path, status, duration, and request ID."""

    def __init__(self, app: ASGIApp) -> None:
        super().__init__(app)

    async def dispatch(self, request: Request, call_next: Any) -> Response:
        request_id = request.headers.get("X-Request-ID", str(uuid.uuid4()))
        request.state.request_id = request_id
        start = time.monotonic()
        response: Response = await call_next(request)
        duration_ms = round((time.monotonic() - start) * 1000, 1)

        response.headers["X-Request-ID"] = request_id

        level = logging.INFO
        if request.url.path == "/health":
            level = logging.DEBUG
        elif response.status_code >= 500:
            level = logging.ERROR
        elif response.status_code >= 400:
            level = logging.WARNING

        logger.log(
            level,
            "%s %s %d %.1fms",
            request.method,
            request.url.path,
            response.status_code,
            duration_ms,
            extra={
                "request_id": request_id,
                "method": request.method,
                "path": request.url.path,
                "status_code": response.status_code,
                "duration_ms": duration_ms,
            },
        )
        return response


class MetricsMiddleware(BaseHTTPMiddleware):
    """Record Prometheus metrics for every HTTP request."""

    async def dispatch(self, request: Request, call_next: Any) -> Response:
        method = request.method
        metrics.HTTP_REQUESTS_IN_PROGRESS.labels(method=method).inc()
        start = time.monotonic()
        try:
            response: Response = await call_next(request)
            duration = time.monotonic() - start
            path_template = _normalize_path(request)
            metrics.HTTP_REQUESTS_TOTAL.labels(
                method=method,
                path_template=path_template,
                status_code=response.status_code,
            ).inc()
            metrics.HTTP_REQUEST_DURATION.labels(
                method=method,
                path_template=path_template,
            ).observe(duration)
            return response
        finally:
            metrics.HTTP_REQUESTS_IN_PROGRESS.labels(method=method).dec()
