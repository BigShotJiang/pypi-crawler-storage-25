"""Pydantic response models for all API endpoints."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field

# --- Meta ---


class HealthCheckResponse(BaseModel):
    """Health check response with system status summary."""

    status: str = Field(examples=["ok"])
    version: str = Field(examples=["0.1.0"])
    uptime_seconds: float = Field(examples=[123.4])
    services_configured: int = Field(examples=[2])
    workflows_configured: int = Field(examples=[1])


# --- Services ---


class ServiceHealthResponse(BaseModel):
    """Live health check result for a single service."""

    service: str
    healthy: bool
    status_code: int | None = None
    latency_ms: float | None = None
    error: str | None = None


class ServiceResponse(BaseModel):
    """Service entry with current health status."""

    key: str
    name: str
    description: str
    url: str
    features: list[str]
    status: str = Field(examples=["healthy"])
    latency_ms: float | None = None


# --- Workflows ---


class WorkflowStepSchema(BaseModel):
    """Definition of a single workflow step."""

    type: str
    service: str
    condition: str | None = None
    parallel: bool = False
    retries: int = 0
    retry_delay: float | None = None
    timeout: float | None = None


class WorkflowResponse(BaseModel):
    """Workflow definition with its steps."""

    key: str
    name: str
    steps: list[WorkflowStepSchema]


class StepResultResponse(BaseModel):
    """Result of a single executed workflow step."""

    step_type: str
    service: str
    success: bool
    skipped: bool = False
    data: dict[str, Any] = Field(default_factory=dict)
    error: str | None = None
    duration_ms: float | None = None
    attempts: list[dict[str, Any]] = Field(default_factory=list)


class WorkflowRunResponse(BaseModel):
    """Result of a full workflow execution."""

    workflow_name: str
    success: bool
    steps: list[StepResultResponse]


# --- History ---


class HistoryStepEntry(BaseModel):
    """Step record within a workflow execution history entry."""

    step_type: str
    service: str
    success: bool
    skipped: bool = False
    duration_ms: float | None = None
    error: str | None = None
    attempts: int = 1


class WorkflowHistoryEntry(BaseModel):
    """Workflow execution history record."""

    workflow_name: str
    started_at: str
    completed_at: str | None = None
    success: bool
    duration_ms: float | None = None
    step_count: int
    steps: list[HistoryStepEntry]


# --- Events ---


class EventResponse(BaseModel):
    """Workflow event from the in-memory event log."""

    event_type: str
    timestamp: str
    workflow_name: str
    data: dict[str, Any] = Field(default_factory=dict)


# --- Portfolio ---


class ToolSchema(BaseModel):
    """Tool entry in the portfolio response."""

    key: str
    name: str
    description: str
    features: list[str]
    repo_url: str
    docs_url: str


class PortfolioResponse(BaseModel):
    """Portfolio metadata for the landing page."""

    name: str
    tagline: str
    version: str
    tools: list[ToolSchema]
    workflows: list[str]
