"""Aegis FastAPI application."""
