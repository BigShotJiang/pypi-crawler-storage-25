"""FastAPI application factory for Aegis."""

from __future__ import annotations

import importlib.metadata
import logging
import os
import time
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from starlette.requests import Request
from starlette.responses import Response

import aegis_qa.logging as _aegis_logging
from aegis_qa.api.middleware import MetricsMiddleware, RequestLoggingMiddleware
from aegis_qa.api.routes import health, portfolio, workflow_list, workflows
from aegis_qa.api.schemas import HealthCheckResponse
from aegis_qa.config.loader import load_config
from aegis_qa.events.emitter import EventEmitter
from aegis_qa.events.log import EventLog
from aegis_qa.events.webhook import WebhookListener
from aegis_qa.logging import configure_logging
from aegis_qa.workflows.history import InMemoryHistory

logger = logging.getLogger(__name__)


def _get_version() -> str:
    """Return package version with a safe fallback."""
    try:
        return importlib.metadata.version("aegis-qa")
    except importlib.metadata.PackageNotFoundError:
        return "0.0.0-dev"


def create_app() -> FastAPI:
    if not _aegis_logging._configured:
        configure_logging()

    app = FastAPI(
        title="Aegis",
        version=_get_version(),
        description="The AI Quality Control Plane — unified orchestration for AI-powered QA tools.",
        openapi_tags=[
            {"name": "meta", "description": "Health and system information"},
            {"name": "services", "description": "Service registry and health checks"},
            {"name": "workflows", "description": "Workflow management and execution"},
            {"name": "portfolio", "description": "Portfolio and tool showcase"},
        ],
        license_info={"name": "MIT", "url": "https://opensource.org/licenses/MIT"},
        contact={"name": "Jack Blacketter", "url": "https://jblacketter.github.io/"},
    )

    app.state.start_time = time.monotonic()

    app.add_middleware(RequestLoggingMiddleware)
    app.add_middleware(MetricsMiddleware)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Load config and wire shared state
    try:
        config = load_config()
    except (FileNotFoundError, ValueError):
        logger.warning("Config file not found, using defaults")
        from aegis_qa.config.models import AegisConfig

        config = AegisConfig()

    app.state.config = config

    # History backend — AEGIS_DB_PATH env var overrides config value
    db_path_env = os.environ.get("AEGIS_DB_PATH", "")
    db_path = db_path_env if db_path_env else config.history_db_path
    history_backend = "sqlite"
    try:
        from aegis_qa.workflows.history_sqlite import SqliteHistory

        history = SqliteHistory(db_path, config.history_max_records)
    except Exception:
        logger.warning("SQLite history unavailable, using in-memory fallback", exc_info=True)
        history = InMemoryHistory()  # type: ignore[assignment]
        history_backend = "in-memory"
    app.state.history = history

    # Event system
    event_log = EventLog(config.event_log_size)
    emitter = EventEmitter()
    emitter.add_listener(event_log)
    if config.webhooks:
        emitter.add_listener(WebhookListener(config.webhooks))
    app.state.event_log = event_log
    app.state.emitter = emitter

    @app.exception_handler(Exception)
    async def unhandled_exception_handler(request: Request, exc: Exception) -> JSONResponse:
        request_id: str = getattr(request.state, "request_id", "unknown")
        logger.error(
            "Unhandled exception on %s %s",
            request.method,
            request.url.path,
            exc_info=exc,
            extra={"request_id": request_id},
        )
        return JSONResponse(
            status_code=500,
            content={"detail": "Internal server error"},
            headers={"X-Request-ID": request_id},
        )

    @app.get("/health", tags=["meta"], response_model=HealthCheckResponse)
    async def healthcheck() -> dict[str, object]:
        """System health check with uptime and configuration summary."""
        uptime = time.monotonic() - app.state.start_time
        return {
            "status": "ok",
            "version": _get_version(),
            "uptime_seconds": round(uptime, 1),
            "services_configured": len(config.services),
            "workflows_configured": len(config.workflows),
        }

    @app.get("/metrics", tags=["meta"], include_in_schema=False)
    async def prometheus_metrics() -> Response:
        from prometheus_client import CONTENT_TYPE_LATEST, generate_latest

        return Response(content=generate_latest(), media_type=CONTENT_TYPE_LATEST)

    app.include_router(health.router, prefix="/api")
    app.include_router(workflow_list.router, prefix="/api")
    app.include_router(workflows.router, prefix="/api")
    app.include_router(portfolio.router, prefix="/api")

    logger.info(
        "Aegis started",
        extra={
            "version": _get_version(),
            "services": len(config.services),
            "workflows": len(config.workflows),
            "history_backend": history_backend,
        },
    )

    # Serve landing page static files at root
    landing_dir = Path(__file__).parent.parent / "landing"
    if landing_dir.is_dir():
        app.mount("/", StaticFiles(directory=str(landing_dir), html=True), name="landing")

    return app


app = create_app()
