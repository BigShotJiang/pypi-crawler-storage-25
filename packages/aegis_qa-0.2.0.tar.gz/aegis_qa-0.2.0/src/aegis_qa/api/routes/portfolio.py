"""Portfolio metadata endpoint for the landing page."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter

from aegis_qa.api.schemas import PortfolioResponse
from aegis_qa.config.loader import load_config

router = APIRouter(tags=["portfolio"])


@router.get("/portfolio", response_model=PortfolioResponse)
async def portfolio() -> dict[str, Any]:
    """Return portfolio metadata for the landing page."""
    config = load_config()
    tools: list[dict[str, Any]] = []
    for key, entry in config.services.items():
        tools.append(
            {
                "key": key,
                "name": entry.name,
                "description": entry.description,
                "features": entry.features,
                "repo_url": entry.repo_url,
                "docs_url": entry.docs_url,
            }
        )
    return {
        "name": config.aegis.name,
        "tagline": "The AI Quality Control Plane",
        "version": config.aegis.version,
        "tools": tools,
        "workflows": list(config.workflows.keys()),
    }
