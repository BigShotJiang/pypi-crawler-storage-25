"""Service health and listing endpoints."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, HTTPException

from aegis_qa.api.schemas import ServiceHealthResponse, ServiceResponse
from aegis_qa.config.loader import load_config
from aegis_qa.registry.registry import ServiceRegistry

router = APIRouter(tags=["services"])


def _get_registry() -> ServiceRegistry:
    config = load_config()
    return ServiceRegistry(config)


@router.get("/services", response_model=list[ServiceResponse])
async def list_services() -> list[dict[str, Any]]:
    """List all registered services with their current health status."""
    registry = _get_registry()
    statuses = await registry.get_all_statuses(timeout=5.0)
    return [
        {
            "key": s.key,
            "name": s.name,
            "description": s.description,
            "url": s.url,
            "features": s.features,
            "status": s.status_label,
            "latency_ms": s.health.latency_ms if s.health else None,
        }
        for s in statuses
    ]


@router.get("/services/{name}/health", response_model=ServiceHealthResponse)
async def service_health(name: str) -> dict[str, Any]:
    """Check live health status for a single service."""
    registry = _get_registry()
    entry = registry.get_entry(name)
    if entry is None:
        raise HTTPException(status_code=404, detail=f"Unknown service: {name}")
    result = await registry.check_one(name, timeout=5.0)
    return {
        "service": name,
        "healthy": result.healthy,
        "status_code": result.status_code,
        "latency_ms": result.latency_ms,
        "error": result.error,
    }
