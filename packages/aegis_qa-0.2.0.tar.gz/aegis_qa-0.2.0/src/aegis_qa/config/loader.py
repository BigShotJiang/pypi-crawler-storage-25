"""YAML config loader with environment variable interpolation."""

from __future__ import annotations

import logging
import os
import re
from pathlib import Path
from typing import Any

import yaml
from pydantic import ValidationError

from aegis_qa.config.models import AegisConfig

logger = logging.getLogger(__name__)

CONFIG_FILENAME = ".aegis.yaml"

_ENV_VAR_PATTERN = re.compile(r"\$\{([^}]+)\}")


def _interpolate_env(value: str) -> str:
    """Replace ${VAR} and ${VAR:-default} patterns with environment values."""

    def _replace(match: re.Match[str]) -> str:
        expr = match.group(1)
        if ":-" in expr:
            var_name, default = expr.split(":-", 1)
            return os.environ.get(var_name.strip(), default)
        return os.environ.get(expr.strip(), match.group(0))

    return _ENV_VAR_PATTERN.sub(_replace, value)


def _interpolate_recursive(data: Any) -> Any:
    """Walk a nested data structure and interpolate env vars in strings."""
    if isinstance(data, str):
        return _interpolate_env(data)
    if isinstance(data, dict):
        return {k: _interpolate_recursive(v) for k, v in data.items()}
    if isinstance(data, list):
        return [_interpolate_recursive(item) for item in data]
    return data


def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    """Deep-merge override into base. Override always wins for conflicts.

    Rules:
    - Dict + Dict: recursively merge keys
    - List + List: override replaces base (lists are atomic)
    - Scalar + Scalar: override wins
    - Any + None: override wins (null in YAML -> None in Python)
    - Key in override not in base: added
    - Key in base not in override: preserved
    """
    result = dict(base)
    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def find_config_file(start: Path | None = None) -> Path | None:
    """Walk up from *start* (default cwd) looking for .aegis.yaml."""
    current = (start or Path.cwd()).resolve()
    for ancestor in [current, *current.parents]:
        candidate = ancestor / CONFIG_FILENAME
        if candidate.exists():
            return candidate
    return None


def load_config(path: Path | None = None, env: str | None = None) -> AegisConfig:
    """Load and validate .aegis.yaml with optional environment overlay.

    If *env* is not provided, reads from the ``AEGIS_ENV`` environment
    variable. When an environment is active, looks for
    ``.aegis.{env}.yaml`` alongside the base config and deep-merges it.
    """
    config_path = path or find_config_file()
    if not config_path or not config_path.exists():
        raise FileNotFoundError(
            f"Could not find {CONFIG_FILENAME}. Create one from .aegis.yaml.example or specify a path."
        )
    with config_path.open("r", encoding="utf-8") as fh:
        raw = yaml.safe_load(fh) or {}

    # Environment overlay
    active_env = env or os.environ.get("AEGIS_ENV")
    overlay_path: Path | None = None
    if active_env:
        overlay_path = config_path.parent / f".aegis.{active_env}.yaml"
        if overlay_path.exists():
            with overlay_path.open("r", encoding="utf-8") as fh:
                overlay = yaml.safe_load(fh) or {}
            raw = _deep_merge(raw, overlay)
            logger.info("Merged environment overlay: %s", overlay_path.name)
        else:
            logger.warning(
                "Environment %r set but overlay not found: %s",
                active_env,
                overlay_path,
            )
            overlay_path = None

    data = _interpolate_recursive(raw)
    try:
        return AegisConfig(**data)
    except ValidationError as exc:
        raise ValueError(f"Invalid configuration in {config_path}: {exc}") from exc
