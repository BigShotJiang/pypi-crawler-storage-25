"""Tests for Prometheus metrics module, middleware, and instrumentation."""

from __future__ import annotations

from unittest.mock import AsyncMock, patch

import pytest
from fastapi import FastAPI
from fastapi.responses import JSONResponse
from fastapi.testclient import TestClient
from prometheus_client import CollectorRegistry, Counter, Gauge, Histogram

import aegis_qa.metrics as metrics_mod
from aegis_qa.api.middleware import MetricsMiddleware, _normalize_path
from aegis_qa.metrics import _make_metrics
from aegis_qa.registry.models import HealthResult
from aegis_qa.registry.registry import _record_health_metrics


@pytest.fixture()
def fresh_metrics(monkeypatch: pytest.MonkeyPatch) -> CollectorRegistry:
    """Replace module-level metric constants with fresh-registry copies."""
    registry = CollectorRegistry()
    (
        http_requests_total,
        http_request_duration,
        http_requests_in_progress,
        workflow_runs_total,
        workflow_duration,
        workflow_step_duration,
        service_health_up,
        service_health_latency,
        service_health_checks_total,
    ) = _make_metrics(registry)
    monkeypatch.setattr(metrics_mod, "HTTP_REQUESTS_TOTAL", http_requests_total)
    monkeypatch.setattr(metrics_mod, "HTTP_REQUEST_DURATION", http_request_duration)
    monkeypatch.setattr(metrics_mod, "HTTP_REQUESTS_IN_PROGRESS", http_requests_in_progress)
    monkeypatch.setattr(metrics_mod, "WORKFLOW_RUNS_TOTAL", workflow_runs_total)
    monkeypatch.setattr(metrics_mod, "WORKFLOW_DURATION", workflow_duration)
    monkeypatch.setattr(metrics_mod, "WORKFLOW_STEP_DURATION", workflow_step_duration)
    monkeypatch.setattr(metrics_mod, "SERVICE_HEALTH_UP", service_health_up)
    monkeypatch.setattr(metrics_mod, "SERVICE_HEALTH_LATENCY", service_health_latency)
    monkeypatch.setattr(metrics_mod, "SERVICE_HEALTH_CHECKS_TOTAL", service_health_checks_total)
    return registry


# ---------------------------------------------------------------------------
# Metrics Module Tests
# ---------------------------------------------------------------------------


class TestMakeMetrics:
    def test_creates_all_nine_metrics(self):
        registry = CollectorRegistry()
        result = _make_metrics(registry)
        assert len(result) == 9

    def test_metric_types(self):
        registry = CollectorRegistry()
        result = _make_metrics(registry)
        assert isinstance(result[0], Counter)  # http_requests_total
        assert isinstance(result[1], Histogram)  # http_request_duration
        assert isinstance(result[2], Gauge)  # http_requests_in_progress
        assert isinstance(result[3], Counter)  # workflow_runs_total
        assert isinstance(result[4], Histogram)  # workflow_duration
        assert isinstance(result[5], Histogram)  # workflow_step_duration
        assert isinstance(result[6], Gauge)  # service_health_up
        assert isinstance(result[7], Gauge)  # service_health_latency
        assert isinstance(result[8], Counter)  # service_health_checks_total

    def test_two_registries_are_independent(self):
        reg1 = CollectorRegistry()
        reg2 = CollectorRegistry()
        metrics1 = _make_metrics(reg1)
        _make_metrics(reg2)
        # Increment on reg1, reg2 should be unaffected
        metrics1[0].labels(method="GET", path_template="/test", status_code=200).inc()
        sample = reg2.get_sample_value(
            "aegis_http_requests_total",
            {"method": "GET", "path_template": "/test", "status_code": "200"},
        )
        assert sample is None or sample == 0.0


# ---------------------------------------------------------------------------
# Path Normalization Tests
# ---------------------------------------------------------------------------


class TestNormalizePath:
    @pytest.fixture()
    def _make_request(self):
        """Return a factory to create minimal mock requests with a given path."""
        from unittest.mock import MagicMock

        def factory(path: str):
            req = MagicMock()
            req.url.path = path
            return req

        return factory

    def test_services_health(self, _make_request):
        req = _make_request("/api/services/qaagent/health")
        assert _normalize_path(req) == "/api/services/{name}/health"

    def test_services_single(self, _make_request):
        req = _make_request("/api/services/qaagent")
        assert _normalize_path(req) == "/api/services/{name}"

    def test_workflows_run(self, _make_request):
        req = _make_request("/api/workflows/full_pipeline/run")
        assert _normalize_path(req) == "/api/workflows/{name}/run"

    def test_workflows_history(self, _make_request):
        req = _make_request("/api/workflows/full_pipeline/history")
        assert _normalize_path(req) == "/api/workflows/{name}/history"

    def test_workflows_single(self, _make_request):
        req = _make_request("/api/workflows/full_pipeline")
        assert _normalize_path(req) == "/api/workflows/{name}"

    def test_unmatched_health(self, _make_request):
        req = _make_request("/health")
        assert _normalize_path(req) == "/health"

    def test_unmatched_metrics(self, _make_request):
        req = _make_request("/metrics")
        assert _normalize_path(req) == "/metrics"

    def test_unmatched_services_list(self, _make_request):
        req = _make_request("/api/services")
        assert _normalize_path(req) == "/api/services"

    def test_unmatched_portfolio(self, _make_request):
        req = _make_request("/api/portfolio")
        assert _normalize_path(req) == "/api/portfolio"


# ---------------------------------------------------------------------------
# MetricsMiddleware Tests
# ---------------------------------------------------------------------------


class TestMetricsMiddleware:
    @pytest.fixture()
    def metrics_app(self, fresh_metrics: CollectorRegistry) -> FastAPI:
        app = FastAPI()
        app.add_middleware(MetricsMiddleware)

        @app.get("/ok")
        async def ok():
            return {"status": "ok"}

        @app.get("/error")
        async def error():
            return JSONResponse(status_code=500, content={"detail": "error"})

        return app

    @pytest.fixture()
    def metrics_client(self, metrics_app: FastAPI) -> TestClient:
        return TestClient(metrics_app)

    def test_request_counter_incremented(self, metrics_client: TestClient, fresh_metrics: CollectorRegistry):
        metrics_client.get("/ok")
        value = fresh_metrics.get_sample_value(
            "aegis_http_requests_total",
            {"method": "GET", "path_template": "/ok", "status_code": "200"},
        )
        assert value == 1.0

    def test_request_counter_multiple(self, metrics_client: TestClient, fresh_metrics: CollectorRegistry):
        metrics_client.get("/ok")
        metrics_client.get("/ok")
        value = fresh_metrics.get_sample_value(
            "aegis_http_requests_total",
            {"method": "GET", "path_template": "/ok", "status_code": "200"},
        )
        assert value == 2.0

    def test_duration_histogram_observed(self, metrics_client: TestClient, fresh_metrics: CollectorRegistry):
        metrics_client.get("/ok")
        count = fresh_metrics.get_sample_value(
            "aegis_http_request_duration_seconds_count",
            {"method": "GET", "path_template": "/ok"},
        )
        assert count == 1.0

    def test_error_status_recorded(self, metrics_client: TestClient, fresh_metrics: CollectorRegistry):
        metrics_client.get("/error")
        value = fresh_metrics.get_sample_value(
            "aegis_http_requests_total",
            {"method": "GET", "path_template": "/error", "status_code": "500"},
        )
        assert value == 1.0

    def test_in_progress_returns_to_zero(self, metrics_client: TestClient, fresh_metrics: CollectorRegistry):
        metrics_client.get("/ok")
        value = fresh_metrics.get_sample_value(
            "aegis_http_requests_in_progress",
            {"method": "GET"},
        )
        assert value == 0.0


# ---------------------------------------------------------------------------
# Service Health Metrics Tests
# ---------------------------------------------------------------------------


class TestServiceHealthMetrics:
    def test_healthy_service(self, fresh_metrics: CollectorRegistry):
        result = HealthResult(healthy=True, latency_ms=42.5)
        _record_health_metrics("qaagent", result)

        up = fresh_metrics.get_sample_value("aegis_service_health_up", {"service": "qaagent"})
        assert up == 1.0

        latency = fresh_metrics.get_sample_value(
            "aegis_service_health_latency_seconds", {"service": "qaagent"}
        )
        assert latency == pytest.approx(0.0425)

        checks = fresh_metrics.get_sample_value(
            "aegis_service_health_checks_total",
            {"service": "qaagent", "status": "healthy"},
        )
        assert checks == 1.0

    def test_unhealthy_service(self, fresh_metrics: CollectorRegistry):
        result = HealthResult(healthy=False, error="connection refused")
        _record_health_metrics("bugalizer", result)

        up = fresh_metrics.get_sample_value("aegis_service_health_up", {"service": "bugalizer"})
        assert up == 0.0

        checks = fresh_metrics.get_sample_value(
            "aegis_service_health_checks_total",
            {"service": "bugalizer", "status": "unhealthy"},
        )
        assert checks == 1.0

    def test_latency_not_set_when_none(self, fresh_metrics: CollectorRegistry):
        result = HealthResult(healthy=False, error="timeout")
        # latency_ms defaults to 0.0 in HealthResult, but we want to test the None branch
        result.latency_ms = None  # type: ignore[assignment]
        _record_health_metrics("test-svc", result)

        latency = fresh_metrics.get_sample_value(
            "aegis_service_health_latency_seconds", {"service": "test-svc"}
        )
        assert latency is None

    async def test_registry_check_one_records_metrics(self, fresh_metrics: CollectorRegistry, sample_config):
        """check_one() should call _record_health_metrics after health check."""
        from aegis_qa.registry.registry import ServiceRegistry

        registry = ServiceRegistry(sample_config)
        mock_result = HealthResult(healthy=True, latency_ms=10.0)

        with patch("aegis_qa.registry.registry.check_health", new_callable=AsyncMock, return_value=mock_result):
            await registry.check_one("qaagent")

        up = fresh_metrics.get_sample_value("aegis_service_health_up", {"service": "qaagent"})
        assert up == 1.0

    async def test_registry_get_all_statuses_records_metrics(self, fresh_metrics: CollectorRegistry, sample_config):
        """get_all_statuses() should call _record_health_metrics for each service."""
        from aegis_qa.registry.registry import ServiceRegistry

        registry = ServiceRegistry(sample_config)
        mock_results = {
            "qaagent": HealthResult(healthy=True, latency_ms=10.0),
            "bugalizer": HealthResult(healthy=False, error="down"),
        }

        with patch(
            "aegis_qa.registry.registry.check_all_services",
            new_callable=AsyncMock,
            return_value=mock_results,
        ):
            await registry.get_all_statuses()

        qa_up = fresh_metrics.get_sample_value("aegis_service_health_up", {"service": "qaagent"})
        assert qa_up == 1.0

        bug_up = fresh_metrics.get_sample_value("aegis_service_health_up", {"service": "bugalizer"})
        assert bug_up == 0.0


# ---------------------------------------------------------------------------
# Workflow Metrics Tests
# ---------------------------------------------------------------------------


class TestWorkflowMetrics:
    async def test_successful_workflow_records_metrics(self, fresh_metrics: CollectorRegistry, sample_config):
        """PipelineRunner.run() should record workflow_runs_total and workflow_duration."""
        from aegis_qa.workflows.models import StepResult
        from aegis_qa.workflows.pipeline import PipelineRunner

        runner = PipelineRunner(sample_config)

        mock_step_result = StepResult(
            step_type="discover",
            service="qaagent",
            success=True,
            data={"routes": []},
            duration_ms=100.0,
        )

        with patch.object(runner, "_resolve_and_execute", new_callable=AsyncMock, return_value=mock_step_result):
            result = await runner.run("full_pipeline")

        assert result.success

        runs = fresh_metrics.get_sample_value(
            "aegis_workflow_runs_total",
            {"workflow": "full_pipeline", "status": "success"},
        )
        assert runs == 1.0

        duration_count = fresh_metrics.get_sample_value(
            "aegis_workflow_duration_seconds_count",
            {"workflow": "full_pipeline"},
        )
        assert duration_count == 1.0

    async def test_failed_workflow_records_failure_status(self, fresh_metrics: CollectorRegistry, sample_config):
        """Failed workflow should record status=failure."""
        from aegis_qa.workflows.models import StepResult
        from aegis_qa.workflows.pipeline import PipelineRunner

        runner = PipelineRunner(sample_config)

        mock_step_result = StepResult(
            step_type="discover",
            service="qaagent",
            success=False,
            error="service down",
            duration_ms=50.0,
        )

        with patch.object(runner, "_resolve_and_execute", new_callable=AsyncMock, return_value=mock_step_result):
            result = await runner.run("full_pipeline")

        assert not result.success

        runs = fresh_metrics.get_sample_value(
            "aegis_workflow_runs_total",
            {"workflow": "full_pipeline", "status": "failure"},
        )
        assert runs == 1.0

    async def test_step_duration_recorded(self, fresh_metrics: CollectorRegistry, sample_config):
        """_execute_with_retry should record step duration metrics."""
        from aegis_qa.workflows.models import StepResult
        from aegis_qa.workflows.pipeline import PipelineRunner

        runner = PipelineRunner(sample_config)

        mock_step_result = StepResult(
            step_type="discover",
            service="qaagent",
            success=True,
            data={},
            duration_ms=150.0,
        )

        mock_step = AsyncMock()
        mock_step.execute = AsyncMock(return_value=mock_step_result)

        from aegis_qa.config.models import WorkflowStepDef

        step_def = WorkflowStepDef(type="discover", service="qaagent")
        context = {"step_results": [], "workflow_name": "full_pipeline"}

        await runner._execute_with_retry(mock_step, step_def, context)

        count = fresh_metrics.get_sample_value(
            "aegis_workflow_step_duration_seconds_count",
            {"workflow": "full_pipeline", "step_type": "discover", "service": "qaagent"},
        )
        assert count == 1.0

    async def test_unknown_workflow_records_failure(self, fresh_metrics: CollectorRegistry, sample_config):
        """Unknown workflow should still record metrics as failure."""
        from aegis_qa.workflows.pipeline import PipelineRunner

        runner = PipelineRunner(sample_config)
        result = await runner.run("nonexistent")

        assert not result.success
        # Unknown workflows return early before metrics — verify no counter increment
        runs = fresh_metrics.get_sample_value(
            "aegis_workflow_runs_total",
            {"workflow": "nonexistent", "status": "failure"},
        )
        assert runs is None


# ---------------------------------------------------------------------------
# /metrics Endpoint Test
# ---------------------------------------------------------------------------


class TestMetricsEndpoint:
    def test_metrics_endpoint_returns_prometheus_format(self):
        """GET /metrics should return Prometheus text format."""
        with patch("aegis_qa.api.app.load_config", side_effect=FileNotFoundError):
            from aegis_qa.api.app import create_app

            app = create_app()
            client = TestClient(app)
            resp = client.get("/metrics")

        assert resp.status_code == 200
        assert "text/plain" in resp.headers.get("content-type", "")
        body = resp.text
        # Should contain at least the aegis metrics
        assert "aegis_http_requests_total" in body

    def test_metrics_not_in_openapi(self):
        """The /metrics endpoint should be excluded from the OpenAPI schema."""
        with patch("aegis_qa.api.app.load_config", side_effect=FileNotFoundError):
            from aegis_qa.api.app import create_app

            app = create_app()
            schema = app.openapi()

        assert "/metrics" not in schema.get("paths", {})
