"""Tests for multi-environment config: deep merge, overlay loading, CLI --env."""

from __future__ import annotations

from pathlib import Path
from typing import Any
from unittest.mock import patch

import pytest
import yaml
from typer.testing import CliRunner

from aegis_qa.config.loader import _deep_merge, load_config

runner = CliRunner()


# ── _deep_merge tests ───────────────────────────────────────────────

class TestDeepMerge:
    def test_dicts_merge_recursively(self):
        result = _deep_merge({"a": {"x": 1, "y": 2}}, {"a": {"y": 3}})
        assert result == {"a": {"x": 1, "y": 3}}

    def test_lists_replace_atomically(self):
        result = _deep_merge({"a": [1, 2]}, {"a": [3]})
        assert result == {"a": [3]}

    def test_scalars_override(self):
        result = _deep_merge({"a": "old"}, {"a": "new"})
        assert result == {"a": "new"}

    def test_null_overrides_to_none(self):
        result = _deep_merge({"a": "value"}, {"a": None})
        assert result == {"a": None}

    def test_missing_keys_preserved(self):
        result = _deep_merge({"a": 1, "b": 2}, {"b": 3})
        assert result == {"a": 1, "b": 3}

    def test_new_keys_added(self):
        result = _deep_merge({"a": 1}, {"b": 2})
        assert result == {"a": 1, "b": 2}

    def test_deeply_nested_merge(self):
        base = {"a": {"b": {"c": 1, "d": 2}, "e": 3}}
        override = {"a": {"b": {"d": 99}}}
        result = _deep_merge(base, override)
        assert result == {"a": {"b": {"c": 1, "d": 99}, "e": 3}}

    def test_empty_override(self):
        result = _deep_merge({"a": 1}, {})
        assert result == {"a": 1}

    def test_empty_base(self):
        result = _deep_merge({}, {"a": 1})
        assert result == {"a": 1}

    def test_both_empty(self):
        result = _deep_merge({}, {})
        assert result == {}

    def test_override_dict_with_scalar(self):
        result = _deep_merge({"a": {"x": 1}}, {"a": "replaced"})
        assert result == {"a": "replaced"}

    def test_override_scalar_with_dict(self):
        result = _deep_merge({"a": "old"}, {"a": {"x": 1}})
        assert result == {"a": {"x": 1}}

    def test_does_not_mutate_base(self):
        base = {"a": {"x": 1}}
        override = {"a": {"y": 2}}
        _deep_merge(base, override)
        assert base == {"a": {"x": 1}}


# ── Overlay loading tests ───────────────────────────────────────────

SAMPLE_BASE: dict[str, Any] = {
    "aegis": {"name": "Aegis", "version": "0.1.0"},
    "llm": {
        "ollama_base_url": "http://localhost:11434",
        "default_model": "qwen2.5-coder:7b",
        "timeout": 120,
    },
    "services": {
        "qaagent": {
            "name": "QA Agent",
            "description": "Route discovery",
            "url": "http://localhost:8080",
            "health_endpoint": "/health",
            "features": ["Discovery"],
        },
    },
    "workflows": {
        "pipeline": {
            "name": "Pipeline",
            "steps": [{"type": "discover", "service": "qaagent"}],
        },
    },
}

SAMPLE_PROD_OVERLAY: dict[str, Any] = {
    "services": {
        "qaagent": {
            "url": "https://qa.production.internal",
        },
    },
}


class TestOverlayLoading:
    def test_load_without_env_unchanged(self, tmp_path: Path):
        """No env set = base config only, current behavior unchanged."""
        config_path = tmp_path / ".aegis.yaml"
        config_path.write_text(yaml.dump(SAMPLE_BASE))

        config = load_config(path=config_path)
        assert config.services["qaagent"].url == "http://localhost:8080"

    def test_load_with_env_merges_overlay(self, tmp_path: Path):
        """AEGIS_ENV=prod merges .aegis.prod.yaml on top."""
        config_path = tmp_path / ".aegis.yaml"
        config_path.write_text(yaml.dump(SAMPLE_BASE))

        overlay_path = tmp_path / ".aegis.prod.yaml"
        overlay_path.write_text(yaml.dump(SAMPLE_PROD_OVERLAY))

        config = load_config(path=config_path, env="prod")
        assert config.services["qaagent"].url == "https://qa.production.internal"
        # Other fields preserved from base
        assert config.services["qaagent"].name == "QA Agent"

    def test_load_with_aegis_env_var(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
        """AEGIS_ENV environment variable selects overlay."""
        config_path = tmp_path / ".aegis.yaml"
        config_path.write_text(yaml.dump(SAMPLE_BASE))

        overlay_path = tmp_path / ".aegis.prod.yaml"
        overlay_path.write_text(yaml.dump(SAMPLE_PROD_OVERLAY))

        monkeypatch.setenv("AEGIS_ENV", "prod")
        config = load_config(path=config_path)
        assert config.services["qaagent"].url == "https://qa.production.internal"

    def test_env_param_overrides_aegis_env_var(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
        """Explicit env= parameter takes precedence over AEGIS_ENV."""
        config_path = tmp_path / ".aegis.yaml"
        config_path.write_text(yaml.dump(SAMPLE_BASE))

        dev_overlay: dict[str, Any] = {
            "services": {"qaagent": {"url": "http://dev.local:8080"}},
        }
        (tmp_path / ".aegis.dev.yaml").write_text(yaml.dump(dev_overlay))
        (tmp_path / ".aegis.prod.yaml").write_text(yaml.dump(SAMPLE_PROD_OVERLAY))

        monkeypatch.setenv("AEGIS_ENV", "prod")
        config = load_config(path=config_path, env="dev")
        assert config.services["qaagent"].url == "http://dev.local:8080"

    def test_missing_overlay_warns_and_continues(self, tmp_path: Path):
        """Missing overlay file logs warning but loads base config."""
        config_path = tmp_path / ".aegis.yaml"
        config_path.write_text(yaml.dump(SAMPLE_BASE))

        # No .aegis.staging.yaml exists
        config = load_config(path=config_path, env="staging")
        # Should fall back to base
        assert config.services["qaagent"].url == "http://localhost:8080"

    def test_overlay_adds_new_service(self, tmp_path: Path):
        """Overlay can add entirely new services."""
        config_path = tmp_path / ".aegis.yaml"
        config_path.write_text(yaml.dump(SAMPLE_BASE))

        overlay: dict[str, Any] = {
            "services": {
                "bugalizer": {
                    "name": "Bugalizer",
                    "description": "Bug triage",
                    "url": "http://bugs.prod:9090",
                    "health_endpoint": "/health",
                    "features": ["Triage"],
                },
            },
        }
        (tmp_path / ".aegis.prod.yaml").write_text(yaml.dump(overlay))

        config = load_config(path=config_path, env="prod")
        assert "qaagent" in config.services
        assert "bugalizer" in config.services
        assert config.services["bugalizer"].url == "http://bugs.prod:9090"


# ── CLI --env option tests ──────────────────────────────────────────

class TestCLIEnv:
    def test_config_validate_with_env(self, tmp_path: Path):
        from aegis_qa.cli import app

        config_path = tmp_path / ".aegis.yaml"
        config_path.write_text(yaml.dump(SAMPLE_BASE))
        (tmp_path / ".aegis.prod.yaml").write_text(yaml.dump(SAMPLE_PROD_OVERLAY))

        result = runner.invoke(app, ["config", "validate", "--path", str(config_path), "--env", "prod"])
        assert result.exit_code == 0
        assert "prod" in result.output

    def test_config_validate_missing_overlay_shows_warning(self, tmp_path: Path):
        from aegis_qa.cli import app

        config_path = tmp_path / ".aegis.yaml"
        config_path.write_text(yaml.dump(SAMPLE_BASE))

        result = runner.invoke(app, ["config", "validate", "--path", str(config_path), "--env", "staging"])
        assert result.exit_code == 0
        assert "not found" in result.output.lower() or "staging" in result.output

    def test_serve_env_sets_environ(self, monkeypatch: pytest.MonkeyPatch):
        """--env flag should set AEGIS_ENV before starting server."""
        import os

        from aegis_qa.cli import app

        # We can't actually start the server, so just test that env is set
        # by patching uvicorn.run
        with patch("uvicorn.run"):
            monkeypatch.delenv("AEGIS_ENV", raising=False)
            runner.invoke(app, ["serve", "--env", "prod"])
            assert os.environ.get("AEGIS_ENV") == "prod"
            # Clean up
            monkeypatch.delenv("AEGIS_ENV", raising=False)
