"""Tests for plugin architecture: step registry, entry-point discovery, CLI plugins."""

from __future__ import annotations

import importlib.metadata
from typing import Any
from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from aegis_qa.workflows.models import StepResult
from aegis_qa.workflows.steps.base import BaseStep

runner = CliRunner()


# ── Helpers ──────────────────────────────────────────────────────────

class FakeStep(BaseStep):
    """Valid plugin step for testing."""

    step_type = "fake"

    async def execute(self, context: dict[str, Any]) -> StepResult:
        return StepResult(step_type="fake", service="test", success=True)


class NotAStep:
    """Not a BaseStep subclass."""

    step_type = "bad"


def _make_entry_point(name: str, value: str, load_result: Any = None) -> MagicMock:
    """Create a mock entry point."""
    ep = MagicMock(spec=importlib.metadata.EntryPoint)
    ep.name = name
    ep.value = value
    ep.load.return_value = load_result
    return ep


# ── load_step_registry tests ────────────────────────────────────────

class TestLoadStepRegistry:
    def test_loads_all_builtins(self):
        from aegis_qa.workflows.steps import _BUILTINS, load_step_registry

        registry = load_step_registry()
        for name in _BUILTINS:
            assert name in registry, f"Built-in '{name}' missing from registry"
        assert len(registry) >= len(_BUILTINS)

    def test_builtins_are_basestep_subclasses(self):
        from aegis_qa.workflows.steps import load_step_registry

        registry = load_step_registry()
        for name, cls in registry.items():
            assert issubclass(cls, BaseStep), f"'{name}' is not a BaseStep subclass"

    def test_module_level_registry_populated(self):
        from aegis_qa.workflows.steps import STEP_REGISTRY

        assert len(STEP_REGISTRY) >= 5
        assert "discover" in STEP_REGISTRY
        assert "test" in STEP_REGISTRY
        assert "report" in STEP_REGISTRY

    def test_plugin_entry_point_discovered(self):
        """A valid plugin entry point is added to the registry."""
        fake_ep = _make_entry_point("custom_step", "fake_pkg.steps:FakeStep", FakeStep)

        from aegis_qa.workflows.steps import load_step_registry

        with patch("importlib.metadata.entry_points", return_value=[fake_ep]):
            registry = load_step_registry()

        assert "custom_step" in registry
        assert registry["custom_step"] is FakeStep

    def test_builtin_name_from_plugin_ignored(self):
        """A plugin registering a built-in name is silently filtered out."""
        fake_ep = _make_entry_point("discover", "evil_pkg:EvilStep", FakeStep)

        from aegis_qa.workflows.steps import load_step_registry

        with patch("importlib.metadata.entry_points", return_value=[fake_ep]):
            registry = load_step_registry()

        # The built-in discover should be the real DiscoverStep, not FakeStep
        from aegis_qa.workflows.steps.discover import DiscoverStep

        assert registry["discover"] is DiscoverStep

    def test_invalid_plugin_not_basestep_skipped(self):
        """A plugin that is not a BaseStep subclass is skipped."""
        fake_ep = _make_entry_point("bad_plugin", "fake_pkg:NotAStep", NotAStep)

        from aegis_qa.workflows.steps import load_step_registry

        with patch("importlib.metadata.entry_points", return_value=[fake_ep]):
            registry = load_step_registry()

        assert "bad_plugin" not in registry

    def test_plugin_import_error_skipped(self):
        """A plugin that fails to import is skipped."""
        fake_ep = _make_entry_point("broken", "broken_pkg:Step", None)
        fake_ep.load.side_effect = ImportError("no module named broken_pkg")

        from aegis_qa.workflows.steps import load_step_registry

        with patch("importlib.metadata.entry_points", return_value=[fake_ep]):
            registry = load_step_registry()

        assert "broken" not in registry

    def test_duplicate_plugin_names_first_wins(self):
        """When two plugins register the same name, first by (name, value) wins."""
        ep1 = _make_entry_point("custom", "alpha_pkg:StepA", FakeStep)

        class FakeStep2(BaseStep):
            step_type = "custom"

            async def execute(self, context: dict[str, Any]) -> StepResult:
                return StepResult(step_type="custom", service="test", success=True)

        ep2 = _make_entry_point("custom", "beta_pkg:StepB", FakeStep2)

        from aegis_qa.workflows.steps import load_step_registry

        with patch("importlib.metadata.entry_points", return_value=[ep2, ep1]):
            registry = load_step_registry()

        # alpha_pkg sorts before beta_pkg, so FakeStep wins
        assert registry["custom"] is FakeStep

    def test_plugins_sorted_by_name_value(self):
        """Plugins are sorted by (ep.name, ep.value) for deterministic loading."""

        class StepA(BaseStep):
            step_type = "a"

            async def execute(self, context: dict[str, Any]) -> StepResult:
                return StepResult(step_type="a", service="test", success=True)

        class StepB(BaseStep):
            step_type = "b"

            async def execute(self, context: dict[str, Any]) -> StepResult:
                return StepResult(step_type="b", service="test", success=True)

        ep_b = _make_entry_point("z_step", "beta:StepB", StepB)
        ep_a = _make_entry_point("a_step", "alpha:StepA", StepA)

        from aegis_qa.workflows.steps import load_step_registry

        # Pass in reverse order — should be sorted by (name, value)
        with patch("importlib.metadata.entry_points", return_value=[ep_b, ep_a]):
            registry = load_step_registry()

        # Both should be loaded
        assert "a_step" in registry
        assert "z_step" in registry


class TestImportClass:
    def test_valid_path(self):
        from aegis_qa.workflows.steps import _import_class

        cls = _import_class("aegis_qa.workflows.steps.discover:DiscoverStep")
        assert cls is not None

        from aegis_qa.workflows.steps.discover import DiscoverStep

        assert cls is DiscoverStep

    def test_invalid_module(self):
        from aegis_qa.workflows.steps import _import_class

        cls = _import_class("nonexistent.module:SomeClass")
        assert cls is None

    def test_not_basestep(self):
        from aegis_qa.workflows.steps import _import_class

        # str is not a BaseStep subclass
        cls = _import_class("builtins:str")
        assert cls is None


# ── CLI plugins command ─────────────────────────────────────────────

class TestPluginsCLI:
    def test_plugins_command_lists_builtins(self):
        from aegis_qa.cli import app

        result = runner.invoke(app, ["plugins"])
        assert result.exit_code == 0
        assert "discover" in result.output
        assert "test" in result.output
        assert "submit_bugs" in result.output
        assert "verify" in result.output
        assert "report" in result.output
        assert "built-in" in result.output

    def test_plugins_command_shows_source(self):
        from aegis_qa.cli import app

        result = runner.invoke(app, ["plugins"])
        assert result.exit_code == 0
        # All built-ins should show as built-in
        lines = [line for line in result.output.split("\n") if "built-in" in line]
        assert len(lines) >= 5
