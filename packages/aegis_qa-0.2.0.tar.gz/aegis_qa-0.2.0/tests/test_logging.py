"""Tests for logging configuration and JSON formatter."""

from __future__ import annotations

import json
import logging

import pytest

import aegis_qa.logging as aegis_logging
from aegis_qa.logging import JsonFormatter, configure_logging


class TestConfigureLogging:
    def test_default_level_is_info(self):
        configure_logging()
        assert logging.getLogger().level == logging.INFO

    def test_explicit_level(self):
        configure_logging(level="DEBUG")
        assert logging.getLogger().level == logging.DEBUG

    def test_level_case_insensitive(self):
        configure_logging(level="warning")
        assert logging.getLogger().level == logging.WARNING

    def test_env_var_level(self, monkeypatch: pytest.MonkeyPatch):
        monkeypatch.setenv("AEGIS_LOG_LEVEL", "ERROR")
        configure_logging()
        assert logging.getLogger().level == logging.ERROR

    def test_explicit_level_overrides_env(self, monkeypatch: pytest.MonkeyPatch):
        monkeypatch.setenv("AEGIS_LOG_LEVEL", "ERROR")
        configure_logging(level="DEBUG")
        assert logging.getLogger().level == logging.DEBUG

    def test_text_format_by_default(self):
        configure_logging()
        handler = logging.getLogger().handlers[0]
        assert not isinstance(handler.formatter, JsonFormatter)

    def test_json_format_explicit(self):
        configure_logging(json_format=True)
        handler = logging.getLogger().handlers[0]
        assert isinstance(handler.formatter, JsonFormatter)

    def test_json_format_env_var(self, monkeypatch: pytest.MonkeyPatch):
        monkeypatch.setenv("AEGIS_LOG_FORMAT", "json")
        configure_logging()
        handler = logging.getLogger().handlers[0]
        assert isinstance(handler.formatter, JsonFormatter)

    def test_text_format_env_var(self, monkeypatch: pytest.MonkeyPatch):
        monkeypatch.setenv("AEGIS_LOG_FORMAT", "text")
        configure_logging()
        handler = logging.getLogger().handlers[0]
        assert not isinstance(handler.formatter, JsonFormatter)

    def test_explicit_json_overrides_env(self, monkeypatch: pytest.MonkeyPatch):
        monkeypatch.setenv("AEGIS_LOG_FORMAT", "text")
        configure_logging(json_format=True)
        handler = logging.getLogger().handlers[0]
        assert isinstance(handler.formatter, JsonFormatter)

    def test_configured_flag_set(self):
        aegis_logging._configured = False
        configure_logging()
        assert aegis_logging._configured is True

    def test_create_app_skips_reconfigure(self):
        """create_app() must not override logging already configured by CLI."""
        from unittest.mock import patch

        configure_logging(level="DEBUG", json_format=True)
        assert logging.getLogger().level == logging.DEBUG
        assert isinstance(logging.getLogger().handlers[0].formatter, JsonFormatter)

        with patch("aegis_qa.api.app.load_config", side_effect=FileNotFoundError):
            from aegis_qa.api.app import create_app

            create_app()

        # CLI settings should be preserved — not reset to INFO/text
        assert logging.getLogger().level == logging.DEBUG
        assert isinstance(logging.getLogger().handlers[0].formatter, JsonFormatter)


class TestJsonFormatter:
    @pytest.fixture()
    def formatter(self) -> JsonFormatter:
        return JsonFormatter()

    def test_produces_valid_json(self, formatter: JsonFormatter):
        record = logging.LogRecord(
            name="test", level=logging.INFO, pathname="", lineno=0,
            msg="hello", args=(), exc_info=None,
        )
        output = formatter.format(record)
        parsed = json.loads(output)
        assert isinstance(parsed, dict)

    def test_standard_fields(self, formatter: JsonFormatter):
        record = logging.LogRecord(
            name="aegis_qa.api", level=logging.WARNING, pathname="", lineno=0,
            msg="something happened", args=(), exc_info=None,
        )
        parsed = json.loads(formatter.format(record))
        assert parsed["level"] == "WARNING"
        assert parsed["logger"] == "aegis_qa.api"
        assert parsed["message"] == "something happened"
        assert "timestamp" in parsed

    def test_message_formatting(self, formatter: JsonFormatter):
        record = logging.LogRecord(
            name="test", level=logging.INFO, pathname="", lineno=0,
            msg="value is %d", args=(42,), exc_info=None,
        )
        parsed = json.loads(formatter.format(record))
        assert parsed["message"] == "value is 42"

    def test_extra_fields_included(self, formatter: JsonFormatter):
        record = logging.LogRecord(
            name="test", level=logging.INFO, pathname="", lineno=0,
            msg="request", args=(), exc_info=None,
        )
        record.request_id = "abc-123"  # type: ignore[attr-defined]
        record.method = "GET"  # type: ignore[attr-defined]
        record.status_code = 200  # type: ignore[attr-defined]
        parsed = json.loads(formatter.format(record))
        assert parsed["request_id"] == "abc-123"
        assert parsed["method"] == "GET"
        assert parsed["status_code"] == 200

    def test_exception_info(self, formatter: JsonFormatter):
        try:
            raise ValueError("boom")
        except ValueError:
            import sys

            exc_info = sys.exc_info()
        record = logging.LogRecord(
            name="test", level=logging.ERROR, pathname="", lineno=0,
            msg="error", args=(), exc_info=exc_info,
        )
        parsed = json.loads(formatter.format(record))
        assert "exception" in parsed
        assert "ValueError: boom" in parsed["exception"]

    def test_no_exception_when_none(self, formatter: JsonFormatter):
        record = logging.LogRecord(
            name="test", level=logging.INFO, pathname="", lineno=0,
            msg="ok", args=(), exc_info=None,
        )
        parsed = json.loads(formatter.format(record))
        assert "exception" not in parsed

    def test_builtin_attrs_excluded(self, formatter: JsonFormatter):
        """Standard LogRecord attributes should NOT appear as extra keys."""
        record = logging.LogRecord(
            name="test", level=logging.INFO, pathname="/foo.py", lineno=42,
            msg="hello", args=(), exc_info=None,
        )
        parsed = json.loads(formatter.format(record))
        # These are standard fields — should not leak into JSON output
        assert "pathname" not in parsed
        assert "lineno" not in parsed
        assert "funcName" not in parsed
