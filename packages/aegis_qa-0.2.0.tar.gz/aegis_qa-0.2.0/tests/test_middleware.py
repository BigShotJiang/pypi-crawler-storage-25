"""Tests for request logging middleware."""

from __future__ import annotations

import logging
import uuid

import pytest
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from fastapi.testclient import TestClient

from aegis_qa.api.middleware import RequestLoggingMiddleware

# Shared state for capturing request_id from inside a handler
_captured_request_id: dict[str, str] = {}


@pytest.fixture()
def mw_app() -> FastAPI:
    """Create a minimal FastAPI app with the request logging middleware."""
    app = FastAPI()
    app.add_middleware(RequestLoggingMiddleware)

    @app.get("/health")
    async def health():
        return {"status": "ok"}

    @app.get("/ok")
    async def ok():
        return {"result": "ok"}

    @app.get("/not-found")
    async def not_found():
        return JSONResponse(status_code=404, content={"detail": "not found"})

    @app.get("/error")
    async def error():
        return JSONResponse(status_code=500, content={"detail": "error"})

    @app.get("/capture")
    async def capture(request: Request):
        _captured_request_id["value"] = request.state.request_id
        return {"ok": True}

    return app


@pytest.fixture()
def mw_client(mw_app: FastAPI) -> TestClient:
    return TestClient(mw_app)


class TestRequestIdPropagation:
    def test_generates_request_id(self, mw_client: TestClient):
        resp = mw_client.get("/ok")
        request_id = resp.headers.get("X-Request-ID")
        assert request_id is not None
        # Should be a valid UUID4
        uuid.UUID(request_id)

    def test_propagates_incoming_request_id(self, mw_client: TestClient):
        custom_id = "my-trace-id-123"
        resp = mw_client.get("/ok", headers={"X-Request-ID": custom_id})
        assert resp.headers["X-Request-ID"] == custom_id

    def test_request_state_has_request_id(self, mw_client: TestClient):
        """Middleware sets request.state.request_id for downstream handlers."""
        _captured_request_id.clear()
        resp = mw_client.get("/capture", headers={"X-Request-ID": "test-123"})
        assert resp.status_code == 200
        assert _captured_request_id["value"] == "test-123"


class TestLogLevelRouting:
    def test_health_logged_at_debug(self, mw_client: TestClient, caplog: pytest.LogCaptureFixture):
        with caplog.at_level(logging.DEBUG, logger="aegis_qa.api.middleware"):
            mw_client.get("/health")
        assert any("/health" in r.message and r.levelno == logging.DEBUG for r in caplog.records)

    def test_health_not_logged_at_info(self, mw_client: TestClient, caplog: pytest.LogCaptureFixture):
        with caplog.at_level(logging.INFO, logger="aegis_qa.api.middleware"):
            mw_client.get("/health")
        # At INFO level, DEBUG messages should not appear — filter to our middleware logger only
        mw_records = [r for r in caplog.records if r.name == "aegis_qa.api.middleware"]
        assert not any(r.levelno == logging.INFO for r in mw_records)

    def test_ok_logged_at_info(self, mw_client: TestClient, caplog: pytest.LogCaptureFixture):
        with caplog.at_level(logging.DEBUG, logger="aegis_qa.api.middleware"):
            mw_client.get("/ok")
        assert any("/ok" in r.message and r.levelno == logging.INFO for r in caplog.records)

    def test_404_logged_at_warning(self, mw_client: TestClient, caplog: pytest.LogCaptureFixture):
        with caplog.at_level(logging.DEBUG, logger="aegis_qa.api.middleware"):
            mw_client.get("/not-found")
        assert any("/not-found" in r.message and r.levelno == logging.WARNING for r in caplog.records)

    def test_500_logged_at_error(self, mw_client: TestClient, caplog: pytest.LogCaptureFixture):
        with caplog.at_level(logging.DEBUG, logger="aegis_qa.api.middleware"):
            mw_client.get("/error")
        assert any("/error" in r.message and r.levelno == logging.ERROR for r in caplog.records)


class TestStructuredFields:
    def test_extra_fields_present(self, mw_client: TestClient, caplog: pytest.LogCaptureFixture):
        with caplog.at_level(logging.DEBUG, logger="aegis_qa.api.middleware"):
            mw_client.get("/ok", headers={"X-Request-ID": "struct-test"})
        records = [r for r in caplog.records if r.name == "aegis_qa.api.middleware" and "/ok" in r.message]
        assert len(records) == 1
        record = records[0]
        assert record.request_id == "struct-test"  # type: ignore[attr-defined]
        assert record.method == "GET"  # type: ignore[attr-defined]
        assert record.path == "/ok"  # type: ignore[attr-defined]
        assert record.status_code == 200  # type: ignore[attr-defined]
        assert isinstance(record.duration_ms, float)  # type: ignore[attr-defined]
