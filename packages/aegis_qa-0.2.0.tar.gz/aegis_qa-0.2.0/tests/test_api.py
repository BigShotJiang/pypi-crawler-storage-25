"""Tests for FastAPI endpoints."""

from __future__ import annotations

import importlib.metadata
import logging
import time
from unittest.mock import AsyncMock, patch

import pytest
from fastapi.testclient import TestClient

from aegis_qa.config.models import AegisConfig
from aegis_qa.events.emitter import EventEmitter
from aegis_qa.events.log import EventLog
from aegis_qa.registry.models import HealthResult, ServiceStatus
from aegis_qa.workflows.history import InMemoryHistory
from aegis_qa.workflows.models import StepResult, WorkflowResult


@pytest.fixture()
def app(sample_config: AegisConfig):
    """Create a test app with mocked config loading."""
    with (
        patch("aegis_qa.api.routes.health.load_config", return_value=sample_config),
        patch("aegis_qa.api.routes.workflows.load_config", return_value=sample_config),
        patch("aegis_qa.api.routes.portfolio.load_config", return_value=sample_config),
        patch("aegis_qa.api.routes.workflow_list.load_config", return_value=sample_config),
    ):
        # Create app without static files mount (no landing dir in test)
        from fastapi import FastAPI
        from fastapi.middleware.cors import CORSMiddleware
        from fastapi.responses import JSONResponse
        from starlette.requests import Request

        from aegis_qa.api.middleware import RequestLoggingMiddleware
        from aegis_qa.api.routes import health, portfolio, workflow_list, workflows

        test_app = FastAPI(title="Aegis Test")
        test_app.add_middleware(RequestLoggingMiddleware)
        test_app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_methods=["*"],
            allow_headers=["*"],
        )

        test_app.state.start_time = time.monotonic()

        @test_app.get("/health")
        async def healthcheck():
            from aegis_qa.api.app import _get_version

            uptime = time.monotonic() - test_app.state.start_time
            return {
                "status": "ok",
                "version": _get_version(),
                "uptime_seconds": round(uptime, 1),
                "services_configured": len(sample_config.services),
                "workflows_configured": len(sample_config.workflows),
            }

        @test_app.get("/raise-error")
        async def raise_error():
            raise RuntimeError("test crash")

        _logger = logging.getLogger(__name__)

        @test_app.exception_handler(Exception)
        async def unhandled_exception_handler(request: Request, exc: Exception) -> JSONResponse:
            request_id: str = getattr(request.state, "request_id", "unknown")
            _logger.error(
                "Unhandled exception on %s %s",
                request.method,
                request.url.path,
                exc_info=exc,
                extra={"request_id": request_id},
            )
            return JSONResponse(
                status_code=500,
                content={"detail": "Internal server error"},
                headers={"X-Request-ID": request_id},
            )

        test_app.include_router(health.router, prefix="/api")
        test_app.include_router(workflow_list.router, prefix="/api")
        test_app.include_router(workflows.router, prefix="/api")
        test_app.include_router(portfolio.router, prefix="/api")

        # Wire app.state for the new DI pattern
        test_app.state.config = sample_config
        test_app.state.history = InMemoryHistory()
        test_app.state.event_log = EventLog()
        test_app.state.emitter = EventEmitter()

        yield test_app


@pytest.fixture()
def client(app) -> TestClient:
    return TestClient(app)


# ─── Health endpoint ───


class TestHealthEndpoint:
    def test_health(self, client: TestClient):
        resp = client.get("/health")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "ok"
        assert "version" in data
        assert isinstance(data["uptime_seconds"], (int, float))
        assert data["services_configured"] == 2
        assert data["workflows_configured"] == 1

    def test_health_version_fallback(self, client: TestClient):
        with patch(
            "aegis_qa.api.app.importlib.metadata.version",
            side_effect=importlib.metadata.PackageNotFoundError("aegis-qa"),
        ):
            resp = client.get("/health")
            assert resp.status_code == 200
            assert resp.json()["version"] == "0.0.0-dev"


# ─── Services endpoints ───


class TestServicesEndpoints:
    def test_list_services(self, client: TestClient, sample_config: AegisConfig):
        with patch("aegis_qa.api.routes.health._get_registry") as mock_reg:
            mock_instance = mock_reg.return_value
            mock_instance.get_all_statuses = AsyncMock(
                return_value=[
                    ServiceStatus(
                        key="qaagent",
                        name="QA Agent",
                        description="Test gen",
                        url="http://localhost:8080",
                        features=["Route Discovery"],
                        health=HealthResult(healthy=True, status_code=200, latency_ms=12.5),
                    ),
                    ServiceStatus(
                        key="bugalizer",
                        name="Bugalizer",
                        description="Bug triage",
                        url="http://localhost:8090",
                        features=["Bug Triage"],
                        health=HealthResult(healthy=False, error="Connection refused: connect"),
                    ),
                ]
            )
            resp = client.get("/api/services")
            assert resp.status_code == 200
            data = resp.json()
            assert len(data) == 2
            assert data[0]["key"] == "qaagent"
            assert data[0]["status"] == "healthy"
            assert data[1]["status"] == "unreachable"

    def test_service_health_found(self, client: TestClient):
        with patch("aegis_qa.api.routes.health._get_registry") as mock_reg:
            mock_instance = mock_reg.return_value
            mock_instance.get_entry.return_value = True  # entry exists
            mock_instance.check_one = AsyncMock(
                return_value=HealthResult(healthy=True, status_code=200, latency_ms=5.0)
            )
            resp = client.get("/api/services/qaagent/health")
            assert resp.status_code == 200
            data = resp.json()
            assert data["healthy"] is True

    def test_service_health_not_found(self, client: TestClient):
        with patch("aegis_qa.api.routes.health._get_registry") as mock_reg:
            mock_instance = mock_reg.return_value
            mock_instance.get_entry.return_value = None
            resp = client.get("/api/services/unknown/health")
            assert resp.status_code == 404


# ─── Workflow run endpoint ───


class TestWorkflowRunEndpoint:
    def test_run_known_workflow(self, client: TestClient, sample_config: AegisConfig):
        mock_result = WorkflowResult(
            workflow_name="full_pipeline",
            steps=[
                StepResult(step_type="discover", service="QA Agent", success=True, data={"route_count": 3}),
            ],
        )
        with patch("aegis_qa.api.routes.workflows.PipelineRunner") as mock_cls:
            mock_runner = mock_cls.return_value
            mock_runner.run = AsyncMock(return_value=mock_result)
            resp = client.post("/api/workflows/full_pipeline/run")
            assert resp.status_code == 200
            data = resp.json()
            assert data["workflow_name"] == "full_pipeline"
            assert data["success"] is True

    def test_run_unknown_workflow(self, client: TestClient):
        resp = client.post("/api/workflows/nonexistent/run")
        assert resp.status_code == 404


# ─── Workflow list endpoints ───


class TestWorkflowListEndpoints:
    def test_list_workflows(self, client: TestClient):
        resp = client.get("/api/workflows")
        assert resp.status_code == 200
        data = resp.json()
        assert len(data) == 1
        assert data[0]["key"] == "full_pipeline"
        assert data[0]["name"] == "Full QA Pipeline"
        assert len(data[0]["steps"]) == 3
        assert data[0]["steps"][0]["type"] == "discover"
        assert data[0]["steps"][2]["condition"] == "has_failures"

    def test_get_workflow(self, client: TestClient):
        resp = client.get("/api/workflows/full_pipeline")
        assert resp.status_code == 200
        data = resp.json()
        assert data["key"] == "full_pipeline"
        assert data["name"] == "Full QA Pipeline"
        assert len(data["steps"]) == 3
        # Check retry/parallel fields are present
        assert data["steps"][0]["parallel"] is False
        assert data["steps"][0]["retries"] == 0
        assert data["steps"][0]["timeout"] == 30.0

    def test_get_workflow_not_found(self, client: TestClient):
        resp = client.get("/api/workflows/nonexistent")
        assert resp.status_code == 404

    def test_workflow_history_empty(self, client: TestClient):
        resp = client.get("/api/workflows/full_pipeline/history")
        assert resp.status_code == 200
        assert resp.json() == []

    def test_workflow_history_not_found(self, client: TestClient):
        resp = client.get("/api/workflows/nonexistent/history")
        assert resp.status_code == 404


# ─── Recent history endpoint ───


class TestRecentHistoryEndpoint:
    def test_recent_history_empty(self, client: TestClient):
        resp = client.get("/api/history")
        assert resp.status_code == 200
        assert resp.json() == []

    def test_recent_history_with_limit(self, client: TestClient):
        resp = client.get("/api/history?limit=5")
        assert resp.status_code == 200
        assert resp.json() == []


# ─── Events endpoint ───


class TestEventsEndpoint:
    def test_events_empty(self, client: TestClient):
        resp = client.get("/api/events")
        assert resp.status_code == 200
        assert resp.json() == []

    def test_events_with_limit(self, client: TestClient):
        resp = client.get("/api/events?limit=5")
        assert resp.status_code == 200
        assert resp.json() == []

    def test_events_with_type_filter(self, client: TestClient):
        resp = client.get("/api/events?event_type=workflow.completed")
        assert resp.status_code == 200
        assert resp.json() == []


# ─── Portfolio endpoint ───


class TestPortfolioEndpoint:
    def test_portfolio(self, client: TestClient):
        resp = client.get("/api/portfolio")
        assert resp.status_code == 200
        data = resp.json()
        assert data["name"] == "Aegis"
        assert data["tagline"] == "The AI Quality Control Plane"
        assert len(data["tools"]) == 2
        assert "full_pipeline" in data["workflows"]

    def test_portfolio_includes_repo_urls(self, client: TestClient):
        resp = client.get("/api/portfolio")
        data = resp.json()
        tools_by_key = {t["key"]: t for t in data["tools"]}
        assert tools_by_key["qaagent"]["repo_url"] == "https://github.com/jblacketter/qaagent"
        assert tools_by_key["bugalizer"]["repo_url"] == "https://github.com/jblacketter/bugalizer"
        assert "docs_url" in tools_by_key["qaagent"]


# ─── AEGIS_DB_PATH env var override ───


class TestAegisDbPathOverride:
    def test_env_var_overrides_config(self, monkeypatch: pytest.MonkeyPatch):
        monkeypatch.setenv("AEGIS_DB_PATH", "/tmp/custom.db")
        with patch("aegis_qa.api.app.load_config", side_effect=FileNotFoundError):
            from aegis_qa.api.app import create_app

            test_app = create_app()
            assert test_app.state.history._db_path == "/tmp/custom.db"

    def test_no_env_var_uses_config_default(self, monkeypatch: pytest.MonkeyPatch):
        monkeypatch.delenv("AEGIS_DB_PATH", raising=False)
        with patch("aegis_qa.api.app.load_config", side_effect=FileNotFoundError):
            from aegis_qa.api.app import create_app

            test_app = create_app()
            assert test_app.state.history._db_path == "aegis_history.db"

    def test_empty_env_var_falls_back_to_config(self, monkeypatch: pytest.MonkeyPatch):
        monkeypatch.setenv("AEGIS_DB_PATH", "")
        with patch("aegis_qa.api.app.load_config", side_effect=FileNotFoundError):
            from aegis_qa.api.app import create_app

            test_app = create_app()
            assert test_app.state.history._db_path == "aegis_history.db"


# ─── Version consistency ───


class TestVersionConsistency:
    def test_get_version_fallback(self):
        """_get_version() returns '0.0.0-dev' when package metadata is unavailable."""
        with patch(
            "aegis_qa.api.app.importlib.metadata.version",
            side_effect=importlib.metadata.PackageNotFoundError("aegis-qa"),
        ):
            from aegis_qa.api.app import _get_version

            assert _get_version() == "0.0.0-dev"

    def test_init_version_fallback(self):
        """__version__ returns '0.0.0-dev' when package metadata is unavailable."""
        import importlib as il

        import aegis_qa

        with patch(
            "aegis_qa.importlib.metadata.version",
            side_effect=importlib.metadata.PackageNotFoundError("aegis-qa"),
        ):
            il.reload(aegis_qa)
            assert aegis_qa.__version__ == "0.0.0-dev"

    def test_fastapi_version_uses_get_version(self):
        """FastAPI app.version uses _get_version(), not a hardcoded string."""
        with patch("aegis_qa.api.app.load_config", side_effect=FileNotFoundError):
            from aegis_qa.api.app import _get_version, create_app

            test_app = create_app()
            assert test_app.version == _get_version()


# ─── Exception handler ───


class TestExceptionHandler:
    @pytest.fixture()
    def err_client(self, app) -> TestClient:
        """Client with raise_server_exceptions=False to test exception handler responses."""
        return TestClient(app, raise_server_exceptions=False)

    def test_unhandled_exception_returns_json_500(self, err_client: TestClient):
        resp = err_client.get("/raise-error")
        assert resp.status_code == 500
        assert resp.json() == {"detail": "Internal server error"}

    def test_exception_response_has_request_id(self, err_client: TestClient):
        resp = err_client.get("/raise-error", headers={"X-Request-ID": "err-trace-123"})
        assert resp.status_code == 500
        assert resp.headers["X-Request-ID"] == "err-trace-123"

    def test_exception_logged_with_request_id(
        self, err_client: TestClient, caplog: pytest.LogCaptureFixture
    ):
        with caplog.at_level(logging.DEBUG):
            err_client.get("/raise-error", headers={"X-Request-ID": "log-trace-456"})
        error_records = [r for r in caplog.records if r.levelno == logging.ERROR and "Unhandled" in r.message]
        assert len(error_records) >= 1
        assert error_records[0].request_id == "log-trace-456"  # type: ignore[attr-defined]


# ─── Middleware integration in app ───


class TestMiddlewareIntegration:
    def test_response_has_request_id_header(self, client: TestClient):
        resp = client.get("/health")
        assert "X-Request-ID" in resp.headers

    def test_propagates_request_id(self, client: TestClient):
        resp = client.get("/health", headers={"X-Request-ID": "custom-id"})
        assert resp.headers["X-Request-ID"] == "custom-id"


# ─── Response compatibility (key-set assertions) ───


class TestResponseCompatibility:
    """Assert every endpoint returns exactly the fields its schema declares."""

    def test_health_keys(self, client: TestClient):
        resp = client.get("/health")
        assert resp.status_code == 200
        assert set(resp.json().keys()) == {
            "status",
            "version",
            "uptime_seconds",
            "services_configured",
            "workflows_configured",
        }

    def test_list_services_keys(self, client: TestClient):
        with patch("aegis_qa.api.routes.health._get_registry") as mock_reg:
            mock_instance = mock_reg.return_value
            mock_instance.get_all_statuses = AsyncMock(
                return_value=[
                    ServiceStatus(
                        key="qaagent",
                        name="QA Agent",
                        description="Test gen",
                        url="http://localhost:8080",
                        features=["Route Discovery"],
                        health=HealthResult(healthy=True, status_code=200, latency_ms=12.5),
                    ),
                ]
            )
            resp = client.get("/api/services")
            assert resp.status_code == 200
            for item in resp.json():
                assert set(item.keys()) == {
                    "key",
                    "name",
                    "description",
                    "url",
                    "features",
                    "status",
                    "latency_ms",
                }

    def test_service_health_keys(self, client: TestClient):
        with patch("aegis_qa.api.routes.health._get_registry") as mock_reg:
            mock_instance = mock_reg.return_value
            mock_instance.get_entry.return_value = True
            mock_instance.check_one = AsyncMock(
                return_value=HealthResult(healthy=True, status_code=200, latency_ms=5.0)
            )
            resp = client.get("/api/services/qaagent/health")
            assert resp.status_code == 200
            assert set(resp.json().keys()) == {
                "service",
                "healthy",
                "status_code",
                "latency_ms",
                "error",
            }

    def test_list_workflows_keys(self, client: TestClient):
        resp = client.get("/api/workflows")
        assert resp.status_code == 200
        for wf in resp.json():
            assert set(wf.keys()) == {"key", "name", "steps"}
            for step in wf["steps"]:
                assert set(step.keys()) == {
                    "type",
                    "service",
                    "condition",
                    "parallel",
                    "retries",
                    "retry_delay",
                    "timeout",
                }

    def test_get_workflow_keys(self, client: TestClient):
        resp = client.get("/api/workflows/full_pipeline")
        assert resp.status_code == 200
        data = resp.json()
        assert set(data.keys()) == {"key", "name", "steps"}
        for step in data["steps"]:
            assert set(step.keys()) == {
                "type",
                "service",
                "condition",
                "parallel",
                "retries",
                "retry_delay",
                "timeout",
            }

    def test_run_workflow_keys(self, client: TestClient):
        mock_result = WorkflowResult(
            workflow_name="full_pipeline",
            steps=[
                StepResult(step_type="discover", service="QA Agent", success=True, data={"route_count": 3}),
            ],
        )
        with patch("aegis_qa.api.routes.workflows.PipelineRunner") as mock_cls:
            mock_runner = mock_cls.return_value
            mock_runner.run = AsyncMock(return_value=mock_result)
            resp = client.post("/api/workflows/full_pipeline/run")
            assert resp.status_code == 200
            data = resp.json()
            assert set(data.keys()) == {"workflow_name", "success", "steps"}
            for step in data["steps"]:
                assert set(step.keys()) == {
                    "step_type",
                    "service",
                    "success",
                    "skipped",
                    "data",
                    "error",
                    "duration_ms",
                    "attempts",
                }

    def test_portfolio_keys(self, client: TestClient):
        resp = client.get("/api/portfolio")
        assert resp.status_code == 200
        data = resp.json()
        assert set(data.keys()) == {"name", "tagline", "version", "tools", "workflows"}
        for tool in data["tools"]:
            assert set(tool.keys()) == {
                "key",
                "name",
                "description",
                "features",
                "repo_url",
                "docs_url",
            }

    def test_events_keys(self, client: TestClient):
        resp = client.get("/api/events")
        assert resp.status_code == 200
        # Empty list is fine — validates route works
        assert isinstance(resp.json(), list)

    def test_history_keys(self, client: TestClient):
        resp = client.get("/api/history")
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)
