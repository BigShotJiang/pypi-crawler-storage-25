"""Tests for Pydantic response models."""

from __future__ import annotations

from aegis_qa.api.schemas import (
    EventResponse,
    HealthCheckResponse,
    HistoryStepEntry,
    PortfolioResponse,
    ServiceHealthResponse,
    ServiceResponse,
    StepResultResponse,
    ToolSchema,
    WorkflowHistoryEntry,
    WorkflowResponse,
    WorkflowRunResponse,
    WorkflowStepSchema,
)


class TestHealthCheckResponse:
    def test_valid(self):
        model = HealthCheckResponse(
            status="ok",
            version="0.1.0",
            uptime_seconds=123.4,
            services_configured=2,
            workflows_configured=1,
        )
        assert model.status == "ok"
        assert model.uptime_seconds == 123.4

    def test_json_schema_has_examples(self):
        schema = HealthCheckResponse.model_json_schema()
        props = schema["properties"]
        assert "examples" in props["status"]


class TestServiceHealthResponse:
    def test_valid(self):
        model = ServiceHealthResponse(
            service="qaagent",
            healthy=True,
            status_code=200,
            latency_ms=5.0,
        )
        assert model.service == "qaagent"
        assert model.healthy is True
        assert model.error is None

    def test_optional_fields_default_none(self):
        model = ServiceHealthResponse(service="qa", healthy=False)
        assert model.status_code is None
        assert model.latency_ms is None
        assert model.error is None


class TestServiceResponse:
    def test_valid(self):
        model = ServiceResponse(
            key="qaagent",
            name="QA Agent",
            description="Test gen",
            url="http://localhost:8080",
            features=["Route Discovery"],
            status="healthy",
        )
        assert model.key == "qaagent"
        assert model.latency_ms is None


class TestWorkflowStepSchema:
    def test_defaults(self):
        model = WorkflowStepSchema(type="discover", service="qaagent")
        assert model.parallel is False
        assert model.retries == 0
        assert model.retry_delay is None
        assert model.timeout is None
        assert model.condition is None


class TestWorkflowResponse:
    def test_with_steps(self):
        model = WorkflowResponse(
            key="full_pipeline",
            name="Full QA Pipeline",
            steps=[
                WorkflowStepSchema(type="discover", service="qaagent"),
                WorkflowStepSchema(type="test", service="qaagent"),
            ],
        )
        assert len(model.steps) == 2
        assert model.steps[0].type == "discover"


class TestStepResultResponse:
    def test_defaults(self):
        model = StepResultResponse(
            step_type="discover", service="QA Agent", success=True
        )
        assert model.skipped is False
        assert model.data == {}
        assert model.error is None
        assert model.duration_ms is None
        assert model.attempts == []


class TestWorkflowRunResponse:
    def test_valid(self):
        model = WorkflowRunResponse(
            workflow_name="full_pipeline",
            success=True,
            steps=[
                StepResultResponse(
                    step_type="discover", service="QA Agent", success=True
                )
            ],
        )
        assert model.success is True
        assert len(model.steps) == 1


class TestHistoryStepEntry:
    def test_defaults(self):
        model = HistoryStepEntry(
            step_type="discover", service="QA Agent", success=True
        )
        assert model.skipped is False
        assert model.duration_ms is None
        assert model.error is None
        assert model.attempts == 1


class TestWorkflowHistoryEntry:
    def test_valid(self):
        model = WorkflowHistoryEntry(
            workflow_name="full_pipeline",
            started_at="2026-01-01T00:00:00",
            success=True,
            step_count=2,
            steps=[
                HistoryStepEntry(
                    step_type="discover", service="QA Agent", success=True
                )
            ],
        )
        assert model.completed_at is None
        assert model.duration_ms is None
        assert model.step_count == 2


class TestEventResponse:
    def test_valid(self):
        model = EventResponse(
            event_type="workflow.completed",
            timestamp="2026-01-01T00:00:00",
            workflow_name="full_pipeline",
        )
        assert model.data == {}


class TestToolSchema:
    def test_valid(self):
        model = ToolSchema(
            key="qaagent",
            name="QA Agent",
            description="Test gen",
            features=["Route Discovery"],
            repo_url="https://github.com/jblacketter/qaagent",
            docs_url="",
        )
        assert model.key == "qaagent"


class TestPortfolioResponse:
    def test_valid(self):
        model = PortfolioResponse(
            name="Aegis",
            tagline="The AI Quality Control Plane",
            version="0.1.0",
            tools=[],
            workflows=["full_pipeline"],
        )
        assert model.version == "0.1.0"
        assert model.tools == []
