"""Tests for the Aegis Python SDK client."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from aegis_qa.api.schemas import (
    EventResponse,
    HealthCheckResponse,
    PortfolioResponse,
    ServiceHealthResponse,
    ServiceResponse,
    WorkflowHistoryEntry,
    WorkflowResponse,
    WorkflowRunResponse,
)
from aegis_qa.client import AegisClient, AsyncAegisClient

# --- Fixtures ---


@pytest.fixture()
def mock_response() -> MagicMock:
    """Create a mock httpx.Response."""
    resp = MagicMock(spec=httpx.Response)
    resp.status_code = 200
    resp.raise_for_status = MagicMock()
    return resp


# --- Sync Client Tests ---


class TestAegisClient:
    def test_init_default(self):
        with patch("aegis_qa.client.httpx.Client") as mock_cls:
            client = AegisClient()
            mock_cls.assert_called_once_with(
                base_url="http://localhost:8000", headers={}, timeout=30.0
            )
            client.close()

    def test_init_with_api_key(self):
        with patch("aegis_qa.client.httpx.Client") as mock_cls:
            client = AegisClient(api_key="test-key")
            mock_cls.assert_called_once_with(
                base_url="http://localhost:8000",
                headers={"X-API-Key": "test-key"},
                timeout=30.0,
            )
            client.close()

    def test_context_manager(self):
        with patch("aegis_qa.client.httpx.Client"):
            with AegisClient() as client:
                assert client is not None

    def test_health(self, mock_response: MagicMock):
        mock_response.json.return_value = {
            "status": "ok",
            "version": "0.1.0",
            "uptime_seconds": 10.0,
            "services_configured": 2,
            "workflows_configured": 1,
        }
        with patch("aegis_qa.client.httpx.Client") as mock_cls:
            mock_cls.return_value.get.return_value = mock_response
            with AegisClient() as client:
                result = client.health()
                assert isinstance(result, HealthCheckResponse)
                assert result.status == "ok"

    def test_list_services(self, mock_response: MagicMock):
        mock_response.json.return_value = [
            {
                "key": "qa",
                "name": "QA Agent",
                "description": "Test gen",
                "url": "http://localhost:8080",
                "features": [],
                "status": "healthy",
                "latency_ms": 5.0,
            }
        ]
        with patch("aegis_qa.client.httpx.Client") as mock_cls:
            mock_cls.return_value.get.return_value = mock_response
            with AegisClient() as client:
                result = client.list_services()
                assert len(result) == 1
                assert isinstance(result[0], ServiceResponse)

    def test_service_health(self, mock_response: MagicMock):
        mock_response.json.return_value = {
            "service": "qa",
            "healthy": True,
            "status_code": 200,
            "latency_ms": 5.0,
            "error": None,
        }
        with patch("aegis_qa.client.httpx.Client") as mock_cls:
            mock_cls.return_value.get.return_value = mock_response
            with AegisClient() as client:
                result = client.service_health("qa")
                assert isinstance(result, ServiceHealthResponse)
                assert result.healthy is True

    def test_list_workflows(self, mock_response: MagicMock):
        mock_response.json.return_value = [
            {"key": "full_pipeline", "name": "Full QA Pipeline", "steps": []}
        ]
        with patch("aegis_qa.client.httpx.Client") as mock_cls:
            mock_cls.return_value.get.return_value = mock_response
            with AegisClient() as client:
                result = client.list_workflows()
                assert len(result) == 1
                assert isinstance(result[0], WorkflowResponse)

    def test_get_workflow(self, mock_response: MagicMock):
        mock_response.json.return_value = {
            "key": "full_pipeline",
            "name": "Full QA Pipeline",
            "steps": [],
        }
        with patch("aegis_qa.client.httpx.Client") as mock_cls:
            mock_cls.return_value.get.return_value = mock_response
            with AegisClient() as client:
                result = client.get_workflow("full_pipeline")
                assert isinstance(result, WorkflowResponse)

    def test_run_workflow(self, mock_response: MagicMock):
        mock_response.json.return_value = {
            "workflow_name": "full_pipeline",
            "success": True,
            "steps": [],
        }
        with patch("aegis_qa.client.httpx.Client") as mock_cls:
            mock_cls.return_value.post.return_value = mock_response
            with AegisClient() as client:
                result = client.run_workflow("full_pipeline")
                assert isinstance(result, WorkflowRunResponse)
                assert result.success is True

    def test_workflow_history(self, mock_response: MagicMock):
        mock_response.json.return_value = []
        with patch("aegis_qa.client.httpx.Client") as mock_cls:
            mock_cls.return_value.get.return_value = mock_response
            with AegisClient() as client:
                result = client.workflow_history("full_pipeline")
                assert result == []

    def test_recent_history(self, mock_response: MagicMock):
        mock_response.json.return_value = [
            {
                "workflow_name": "full_pipeline",
                "started_at": "2026-01-01T00:00:00",
                "completed_at": None,
                "success": True,
                "duration_ms": None,
                "step_count": 0,
                "steps": [],
            }
        ]
        with patch("aegis_qa.client.httpx.Client") as mock_cls:
            mock_cls.return_value.get.return_value = mock_response
            with AegisClient() as client:
                result = client.recent_history(limit=5)
                assert len(result) == 1
                assert isinstance(result[0], WorkflowHistoryEntry)

    def test_events(self, mock_response: MagicMock):
        mock_response.json.return_value = [
            {
                "event_type": "workflow.completed",
                "timestamp": "2026-01-01T00:00:00",
                "workflow_name": "full_pipeline",
                "data": {},
            }
        ]
        with patch("aegis_qa.client.httpx.Client") as mock_cls:
            mock_cls.return_value.get.return_value = mock_response
            with AegisClient() as client:
                result = client.events(limit=10, event_type="workflow.completed")
                assert len(result) == 1
                assert isinstance(result[0], EventResponse)

    def test_portfolio(self, mock_response: MagicMock):
        mock_response.json.return_value = {
            "name": "Aegis",
            "tagline": "The AI Quality Control Plane",
            "version": "0.1.0",
            "tools": [],
            "workflows": [],
        }
        with patch("aegis_qa.client.httpx.Client") as mock_cls:
            mock_cls.return_value.get.return_value = mock_response
            with AegisClient() as client:
                result = client.portfolio()
                assert isinstance(result, PortfolioResponse)

    def test_raises_on_http_error(self):
        with patch("aegis_qa.client.httpx.Client") as mock_cls:
            mock_resp = MagicMock(spec=httpx.Response)
            mock_resp.raise_for_status.side_effect = httpx.HTTPStatusError(
                "404", request=MagicMock(), response=mock_resp
            )
            mock_cls.return_value.get.return_value = mock_resp
            with AegisClient() as client:
                with pytest.raises(httpx.HTTPStatusError):
                    client.health()


# --- Async Client Tests ---


class TestAsyncAegisClient:
    def test_init_with_api_key(self):
        with patch("aegis_qa.client.httpx.AsyncClient") as mock_cls:
            _client = AsyncAegisClient(api_key="test-key")  # noqa: F841
            mock_cls.assert_called_once_with(
                base_url="http://localhost:8000",
                headers={"X-API-Key": "test-key"},
                timeout=30.0,
            )

    async def test_health(self, mock_response: MagicMock):
        mock_response.json.return_value = {
            "status": "ok",
            "version": "0.1.0",
            "uptime_seconds": 10.0,
            "services_configured": 2,
            "workflows_configured": 1,
        }
        with patch("aegis_qa.client.httpx.AsyncClient") as mock_cls:
            mock_cls.return_value.get = AsyncMock(return_value=mock_response)
            mock_cls.return_value.aclose = AsyncMock()
            async with AsyncAegisClient() as client:
                result = await client.health()
                assert isinstance(result, HealthCheckResponse)

    async def test_list_services(self, mock_response: MagicMock):
        mock_response.json.return_value = [
            {
                "key": "qa",
                "name": "QA Agent",
                "description": "Test gen",
                "url": "http://localhost:8080",
                "features": [],
                "status": "healthy",
                "latency_ms": None,
            }
        ]
        with patch("aegis_qa.client.httpx.AsyncClient") as mock_cls:
            mock_cls.return_value.get = AsyncMock(return_value=mock_response)
            mock_cls.return_value.aclose = AsyncMock()
            async with AsyncAegisClient() as client:
                result = await client.list_services()
                assert len(result) == 1
                assert isinstance(result[0], ServiceResponse)

    async def test_run_workflow(self, mock_response: MagicMock):
        mock_response.json.return_value = {
            "workflow_name": "full_pipeline",
            "success": True,
            "steps": [],
        }
        with patch("aegis_qa.client.httpx.AsyncClient") as mock_cls:
            mock_cls.return_value.post = AsyncMock(return_value=mock_response)
            mock_cls.return_value.aclose = AsyncMock()
            async with AsyncAegisClient() as client:
                result = await client.run_workflow("full_pipeline")
                assert isinstance(result, WorkflowRunResponse)

    async def test_events_with_filter(self, mock_response: MagicMock):
        mock_response.json.return_value = []
        with patch("aegis_qa.client.httpx.AsyncClient") as mock_cls:
            mock_cls.return_value.get = AsyncMock(return_value=mock_response)
            mock_cls.return_value.aclose = AsyncMock()
            async with AsyncAegisClient() as client:
                result = await client.events(event_type="workflow.started")
                assert result == []

    async def test_portfolio(self, mock_response: MagicMock):
        mock_response.json.return_value = {
            "name": "Aegis",
            "tagline": "The AI Quality Control Plane",
            "version": "0.1.0",
            "tools": [],
            "workflows": [],
        }
        with patch("aegis_qa.client.httpx.AsyncClient") as mock_cls:
            mock_cls.return_value.get = AsyncMock(return_value=mock_response)
            mock_cls.return_value.aclose = AsyncMock()
            async with AsyncAegisClient() as client:
                result = await client.portfolio()
                assert isinstance(result, PortfolioResponse)
