"""A directory to hold various one-off special project scripts.

There are many tasks that you can do with Beancount that are sophisticated
enough and that haven't been integrated and yet generalized in the reporting
infrastructure that you need to write some code to carry them out. This
directory is intended to contain those as usable scripts or examples.
"""

__copyright__ = "Copyright (C) 2008, 2014, 2016-2017, 2024-2025  Martin Blais"
__license__ = "GNU GPLv2"
