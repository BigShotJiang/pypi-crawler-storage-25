"""
Personal media tracking and ranking via active comparison.
"""
