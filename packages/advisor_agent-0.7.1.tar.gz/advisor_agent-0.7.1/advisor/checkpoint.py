"""Run checkpoints — save/resume the advisor's plan mid-pipeline.

A checkpoint captures the *pre-execution state*: the ranked files, the
chosen batches, the target config, the run id, and a UTC timestamp. It
lets a user resume an expensive review if the Claude Code session dies
between ``plan`` and the live dispatch, without paying for re-discovery.

Checkpoints live at ``<target>/.advisor/run-<run_id>.json`` alongside the
history file. They are human-readable JSON — diffable and auditable.
"""

from __future__ import annotations

import json
import re
import warnings
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path

from ._fs import atomic_write_text as _shared_atomic_write
from ._fs import read_text_capped as _read_text_capped
from .focus import FocusBatch, FocusTask
from .history import HISTORY_DIR_NAME

UTC = timezone.utc

CHECKPOINT_SCHEMA_VERSION = "1.0"
CHECKPOINT_PREFIX = "run-"
CHECKPOINT_SUFFIX = ".json"
_RUN_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]*$")
# Reject implausibly large checkpoints before ``read_text`` buffers
# them; a healthy checkpoint is a few KB. ``list_checkpoints`` already
# uses a 2 KB sniff cap; this is the stricter outer bound for full load.
_MAX_CHECKPOINT_BYTES = 10 * 1024 * 1024


@dataclass(frozen=True, slots=True)
class Checkpoint:
    """A persisted snapshot of a planned advisor run."""

    run_id: str
    created_at: str
    target: str
    team_name: str
    file_types: str
    min_priority: int
    max_runners: int
    advisor_model: str
    runner_model: str
    max_fixes_per_runner: int
    large_file_line_threshold: int
    large_file_max_fixes: int
    test_command: str
    context: str
    tasks: list[dict[str, object]]
    batches: list[dict[str, object]]
    schema_version: str = CHECKPOINT_SCHEMA_VERSION


def _dir(target: str | Path) -> Path:
    return Path(target) / HISTORY_DIR_NAME


def _validate_run_id(run_id: str) -> None:
    if not _RUN_ID_RE.fullmatch(run_id):
        raise ValueError("invalid run_id: use only letters, digits, underscore, dot, and hyphen")


def checkpoint_path(target: str | Path, run_id: str) -> Path:
    """Absolute path for a checkpoint file with the given run_id."""
    _validate_run_id(run_id)
    return _dir(target) / f"{CHECKPOINT_PREFIX}{run_id}{CHECKPOINT_SUFFIX}"


def save_checkpoint(
    target: str | Path,
    *,
    run_id: str,
    tasks: list[FocusTask],
    batches: list[FocusBatch] | None,
    team_name: str,
    file_types: str,
    min_priority: int,
    max_runners: int,
    advisor_model: str,
    runner_model: str,
    max_fixes_per_runner: int = 5,
    large_file_line_threshold: int = 800,
    large_file_max_fixes: int = 3,
    test_command: str = "",
    context: str = "",
) -> Path:
    """Write a checkpoint JSON file and return its path.

    Overwrites an existing checkpoint with the same ``run_id`` (idempotent
    — lets the advisor update a plan mid-flight).
    """
    task_dicts = [
        {"file_path": t.file_path, "priority": t.priority, "prompt": t.prompt} for t in tasks
    ]
    batch_dicts: list[dict[str, object]] = []
    if batches:
        for b in batches:
            batch_dicts.append(
                {
                    "batch_id": b.batch_id,
                    "complexity": b.complexity,
                    "top_priority": b.top_priority,
                    "tasks": [
                        {"file_path": t.file_path, "priority": t.priority, "prompt": t.prompt}
                        for t in b.tasks
                    ],
                }
            )
    checkpoint = Checkpoint(
        run_id=run_id,
        created_at=datetime.now(UTC).isoformat(timespec="seconds"),
        target=str(target),
        team_name=team_name,
        file_types=file_types,
        min_priority=min_priority,
        max_runners=max_runners,
        advisor_model=advisor_model,
        runner_model=runner_model,
        max_fixes_per_runner=max_fixes_per_runner,
        large_file_line_threshold=large_file_line_threshold,
        large_file_max_fixes=large_file_max_fixes,
        test_command=test_command,
        context=context,
        tasks=task_dicts,
        batches=batch_dicts,
    )
    path = checkpoint_path(target, run_id)
    serialized = json.dumps(asdict(checkpoint), indent=2)
    # Symmetric guard with ``load_checkpoint``: refuse to write a payload
    # the loader will refuse to read, otherwise ``--resume`` silently
    # breaks after a successful save.
    if len(serialized.encode("utf-8")) > _MAX_CHECKPOINT_BYTES:
        raise ValueError(
            f"could not save checkpoint {path}: serialized size exceeds "
            f"{_MAX_CHECKPOINT_BYTES} bytes — refusing to write"
        )
    _shared_atomic_write(path, serialized)
    return path


def load_checkpoint(target: str | Path, run_id: str) -> Checkpoint:
    """Load a checkpoint by run_id. Raises :class:`FileNotFoundError` or
    :class:`ValueError` on missing / malformed content.
    """
    path = checkpoint_path(target, run_id)
    # Single bounded read — _read_text_capped opens once, reads at most
    # _MAX_CHECKPOINT_BYTES + 1 raw bytes, and raises ValueError if the
    # file is larger. This replaces the prior ``stat().st_size`` →
    # ``read_text`` pair, which left a TOCTOU window where a concurrent
    # writer could grow the file past the guard before the read.
    try:
        text = _read_text_capped(path, _MAX_CHECKPOINT_BYTES)
    except FileNotFoundError:
        raise FileNotFoundError(f"no checkpoint at {path}") from None
    except (OSError, UnicodeDecodeError, ValueError) as exc:
        raise ValueError(f"could not read checkpoint {path}: {exc}") from exc
    try:
        obj = json.loads(text)
    except json.JSONDecodeError as exc:
        raise ValueError(f"could not read checkpoint {path}: {exc}") from exc

    version = str(obj.get("schema_version", ""))
    if version and version != CHECKPOINT_SCHEMA_VERSION:
        warnings.warn(
            f"{path}: schema_version {version!r} does not match "
            f"expected {CHECKPOINT_SCHEMA_VERSION!r}; parsing anyway",
            UserWarning,
            stacklevel=2,
        )

    try:
        return Checkpoint(
            run_id=str(obj["run_id"]),
            created_at=str(obj["created_at"]),
            target=str(obj["target"]),
            team_name=str(obj["team_name"]),
            file_types=str(obj["file_types"]),
            min_priority=int(obj["min_priority"]),
            max_runners=int(obj["max_runners"]),
            advisor_model=str(obj["advisor_model"]),
            runner_model=str(obj["runner_model"]),
            max_fixes_per_runner=int(obj.get("max_fixes_per_runner", 5)),
            large_file_line_threshold=int(obj.get("large_file_line_threshold", 800)),
            large_file_max_fixes=int(obj.get("large_file_max_fixes", 3)),
            test_command=str(obj.get("test_command", "")),
            context=str(obj.get("context", "")),
            tasks=list(obj.get("tasks", [])),
            batches=list(obj.get("batches", [])),
            # An older checkpoint that omitted ``schema_version`` would
            # otherwise load with ``""`` instead of the dataclass default,
            # quietly defeating any future code that keys off the sentinel.
            schema_version=version or CHECKPOINT_SCHEMA_VERSION,
        )
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError(f"checkpoint {path} is missing required fields: {exc}") from exc


def list_checkpoints(target: str | Path) -> list[str]:
    """Return all run_ids with saved checkpoints in ``target``, newest first.

    Ordering is lexical by filename — since run_ids are UTC ISO-like
    timestamps, lexical equals chronological.

    Filters out files whose contents are not parseable JSON (e.g.
    truncated mid-write after a crash, or a file that happens to
    match the prefix/suffix but isn't actually a checkpoint). A user
    selecting one of these IDs would otherwise get a confusing
    ``ValueError`` from :func:`load_checkpoint` instead of the file
    just being absent from the list.
    """
    d = _dir(target)
    if not d.is_dir():
        return []
    ids: list[str] = []
    for p in d.iterdir():
        name = p.name
        if not (name.startswith(CHECKPOINT_PREFIX) and name.endswith(CHECKPOINT_SUFFIX)):
            continue
        try:
            if not p.is_file():
                continue
        except OSError:
            continue
        # Cheap parseability check — reject anything that won't
        # roundtrip through ``load_checkpoint``. We only verify the
        # file contains a JSON object; the deeper schema checks
        # happen on actual load. This keeps ``list_checkpoints``
        # O(N file headers) rather than O(N full schema validations).
        try:
            with p.open("rb") as fh:
                first = fh.read(2048).lstrip()
        except OSError:
            continue
        if not first or not first.startswith(b"{"):
            continue
        ids.append(name[len(CHECKPOINT_PREFIX) : -len(CHECKPOINT_SUFFIX)])
    return sorted(ids, reverse=True)
