"""
Sharpe CLI — crypto derivatives and market data from the terminal.

Usage:
    sharpe market                          # market overview
    sharpe funding                         # current funding rates
    sharpe funding --type history --coin BTC --days 7
    sharpe futures oi-stacked --coin ETH --timeframe 1M
    sharpe options atm-iv --coin BTC
    sharpe arb spot-perp                   # spot-perp arbitrage
    sharpe arb cross-exchange              # cross-exchange arbitrage
    sharpe narratives                      # all narratives
    sharpe narratives --slug defi          # single narrative detail
    sharpe ecosystems --slug solana
    sharpe memecoins
    sharpe listings                        # exchange listings hub
    sharpe listings recent --days 30       # recent listings feed
    sharpe news --limit 10 --coin BTC
    sharpe search bitcoin
    sharpe gems --limit 20
    sharpe coverage                        # available data products
    sharpe watch market                    # live refresh every 30s
    sharpe briefing                        # daily composite briefing
    sharpe doctor                          # self-diagnosis
    sharpe login                           # authenticate
"""

from __future__ import annotations

import json
import os
import platform
import re
import shutil
import signal
import subprocess
import sys
import time
import webbrowser
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import httpx
import typer

# ── Version ─────────────────────────────────────────────────────────────

__version__ = "1.0.0"
_PYPI_PACKAGE = "sharpe-mcp"

# ── ANSI Codes ──────────────────────────────────────────────────────────
# We handle NO_COLOR and non-TTY via _is_color_enabled(). When color is
# disabled, all _C.* attributes return empty strings.


class _AnsiCodes:
    """ANSI escape sequences with NO_COLOR / non-TTY awareness."""

    RESET = "\033[0m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    UNDERLINE = "\033[4m"

    RED = "\033[31m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    BLUE = "\033[34m"
    MAGENTA = "\033[35m"
    CYAN = "\033[36m"
    WHITE = "\033[37m"

    BG_RED = "\033[41m"
    BG_GREEN = "\033[42m"

    # Box-drawing characters
    TL = "\u250c"  # top-left corner
    TR = "\u2510"  # top-right
    BL = "\u2514"  # bottom-left
    BR = "\u2518"  # bottom-right
    H = "\u2500"   # horizontal
    V = "\u2502"   # vertical
    TJ = "\u252c"  # top junction
    BJ = "\u2534"  # bottom junction
    LJ = "\u251c"  # left junction
    RJ = "\u2524"  # right junction
    CJ = "\u253c"  # cross junction

    def __getattr__(self, name: str) -> str:
        return ""


_C_ON = _AnsiCodes()
_C_OFF = _AnsiCodes.__new__(_AnsiCodes)
# Override all string attributes to "" on _C_OFF
for _attr in list(vars(_AnsiCodes)):
    if not _attr.startswith("_") and isinstance(getattr(_AnsiCodes, _attr), str):
        object.__setattr__(_C_OFF, _attr, "")


def _is_tty() -> bool:
    return hasattr(sys.stdout, "isatty") and sys.stdout.isatty()


def _is_color_enabled() -> bool:
    if os.environ.get("NO_COLOR"):
        return False
    return _is_tty()


def _C() -> _AnsiCodes:
    return _C_ON if _is_color_enabled() else _C_OFF


# ── Config File ─────────────────────────────────────────────────────────

_CONFIG_DIR = Path.home() / ".config" / "sharpe"
_CONFIG_PATH = _CONFIG_DIR / "config.yaml"
_UPDATE_CHECK_PATH = _CONFIG_DIR / ".last_update_check"


def _load_config() -> dict:
    """Load ~/.config/sharpe/config.yaml (simple flat key: value parsing)."""
    if not _CONFIG_PATH.exists():
        return {}
    cfg: dict = {}
    try:
        text = _CONFIG_PATH.read_text(encoding="utf-8")
        for line in text.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if ":" not in line:
                continue
            key, _, val = line.partition(":")
            key = key.strip()
            val = val.strip().strip("'\"")
            if val:
                cfg[key] = val
    except OSError:
        pass
    return cfg


def _save_config(cfg: dict) -> None:
    """Write config dict back to YAML."""
    _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    lines = []
    for k, v in cfg.items():
        if " " in str(v) or "#" in str(v):
            lines.append(f"{k}: \"{v}\"")
        else:
            lines.append(f"{k}: {v}")
    _CONFIG_PATH.write_text("\n".join(lines) + "\n", encoding="utf-8")


_CFG = _load_config()

# ── Resolved Settings ───────────────────────────────────────────────────
# Priority: env vars > CLI flags > config file > defaults

API_KEY = os.getenv("SHARPE_API_KEY", _CFG.get("api_key", ""))
API_BASE = os.getenv("SHARPE_API_URL", "https://api.sharpe.ai")
FREE_BASE = os.getenv("SHARPE_FREE_URL", "https://www.sharpe.ai")
DEFAULT_COIN = os.getenv("SHARPE_DEFAULT_COIN", _CFG.get("default_coin", "BTC"))
DEFAULT_TIMEFRAME = os.getenv("SHARPE_DEFAULT_TIMEFRAME", _CFG.get("default_timeframe", "3M"))
DEFAULT_OUTPUT = _CFG.get("output_format", "table")

# ── Typer App ───────────────────────────────────────────────────────────


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(f"sharpe {__version__}")
        raise typer.Exit()


app = typer.Typer(
    name="sharpe",
    help="Sharpe Terminal CLI — crypto derivatives and market data.",
    no_args_is_help=True,
    add_completion=False,
)


@app.callback()
def _main_callback(
    version: bool = typer.Option(
        False, "--version", "-V", callback=_version_callback,
        is_eager=True, help="Show version and exit.",
    ),
) -> None:
    """Sharpe Terminal CLI — crypto derivatives and market data."""
    _maybe_check_update()


# ── Web URL Mapping ─────────────────────────────────────────────────────

_WEB_URLS: dict[str, str] = {
    "futures": "https://sharpe.ai/futures",
    "options": "https://sharpe.ai/options",
    "narratives": "https://sharpe.ai/narratives",
    "ecosystems": "https://sharpe.ai/ecosystems",
    "memecoins": "https://sharpe.ai/memecoins",
    "market": "https://sharpe.ai",
    "funding": "https://sharpe.ai/funding-rate",
    "arb": "https://sharpe.ai/arbitrage",
    "news": "https://sharpe.ai/news",
    "gems": "https://sharpe.ai/gem-finder",
}


def _open_web(product: str) -> None:
    url = _WEB_URLS.get(product, "https://sharpe.ai")
    typer.echo(f"Opening {url}")
    webbrowser.open(url)
    raise typer.Exit()


# ── Suggestion Engine ───────────────────────────────────────────────────

_SUGGESTIONS: dict[str, str] = {
    "market": "sharpe futures oi-stacked | sharpe narratives | sharpe arb spot-perp",
    "funding": "sharpe arb spot-perp | sharpe futures funding-rate --coin BTC",
    "futures": "sharpe options atm-iv | sharpe arb spot-perp",
    "options": "sharpe futures oi-stacked | sharpe narratives",
    "arb": "sharpe funding | sharpe futures annualized-basis",
    "narratives": "sharpe ecosystems | sharpe memecoins",
    "ecosystems": "sharpe narratives | sharpe memecoins",
    "memecoins": "sharpe narratives | sharpe ecosystems",
    "news": "sharpe market | sharpe briefing",
    "search": "sharpe market | sharpe gems",
    "gems": "sharpe search <coin> | sharpe market",
    "predict": "sharpe market | sharpe futures oi-stacked",
    "coverage": "sharpe market | sharpe futures oi-stacked --coin BTC",
    "coins": "sharpe futures oi-stacked | sharpe funding",
    "briefing": "sharpe futures oi-stacked --coin BTC | sharpe options atm-iv",
}


def _suggest(command: str) -> None:
    if not _is_tty():
        return
    hint = _SUGGESTIONS.get(command)
    if hint:
        c = _C()
        typer.echo(f"\n{c.DIM}Next: {hint}{c.RESET}")


# ── Update Check ────────────────────────────────────────────────────────


def _maybe_check_update() -> None:
    """On first run of the day, check PyPI for a newer version."""
    if not _is_tty():
        return
    try:
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        if _UPDATE_CHECK_PATH.exists():
            last = _UPDATE_CHECK_PATH.read_text(encoding="utf-8").strip()
            if last == today:
                return
        _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        _UPDATE_CHECK_PATH.write_text(today, encoding="utf-8")
        with httpx.Client(timeout=3.0) as client:
            resp = client.get(f"https://pypi.org/pypi/{_PYPI_PACKAGE}/json")
            if resp.status_code == 200:
                latest = resp.json().get("info", {}).get("version", __version__)
                if latest != __version__:
                    c = _C()
                    typer.echo(
                        f"{c.YELLOW}Update available: {__version__} -> {latest}. "
                        f"Run: pip install --upgrade {_PYPI_PACKAGE}{c.RESET}\n"
                    )
    except Exception:
        pass


# ── Pager ───────────────────────────────────────────────────────────────


def _page_output(text: str) -> None:
    """If output exceeds terminal height and stdout is a TTY, pipe through $PAGER."""
    if not _is_tty():
        sys.stdout.write(text)
        if not text.endswith("\n"):
            sys.stdout.write("\n")
        return

    term_height = shutil.get_terminal_size((80, 24)).lines
    line_count = text.count("\n") + 1

    if line_count <= term_height - 2:
        sys.stdout.write(text)
        if not text.endswith("\n"):
            sys.stdout.write("\n")
        return

    pager_cmd = os.environ.get("PAGER", "less -FIRX")
    try:
        proc = subprocess.Popen(
            pager_cmd, shell=True, stdin=subprocess.PIPE, encoding="utf-8",
        )
        proc.communicate(input=text)
    except Exception:
        sys.stdout.write(text)
        if not text.endswith("\n"):
            sys.stdout.write("\n")


# ── API Client ──────────────────────────────────────────────────────────


def _call(v1_path: str, free_path: str, params: Optional[dict] = None) -> dict | list:
    """Synchronous API call. Uses v1 with auth when key is available."""
    clean = {k: v for k, v in (params or {}).items() if v is not None}

    if API_KEY:
        url = f"{API_BASE}{v1_path}"
        headers = {"Authorization": f"Bearer {API_KEY}"}
    else:
        url = f"{FREE_BASE}{free_path}"
        headers = {}

    with httpx.Client(timeout=30.0, follow_redirects=True) as client:
        resp = client.get(url, params=clean, headers=headers)

    if resp.status_code != 200:
        typer.echo(f"Error {resp.status_code}: {resp.text[:300]}", err=True)
        raise typer.Exit(1)

    data = resp.json()
    if isinstance(data, dict) and "data" in data and "meta" in data:
        return data["data"]
    if isinstance(data, dict) and "assets" in data and len(data) <= 2:
        return data["assets"]
    return data


# ── Formatting Helpers ──────────────────────────────────────────────────


def _fmt_number(val: object, decimals: int = 2) -> str:
    """Format a numeric value with commas, right-aligned."""
    if not isinstance(val, (int, float)):
        return str(val) if val is not None else "-"
    if abs(val) >= 1_000_000_000:
        return f"{val / 1_000_000_000:,.{decimals}f}B"
    if abs(val) >= 1_000_000:
        return f"{val / 1_000_000:,.{decimals}f}M"
    if abs(val) >= 1_000:
        return f"{val:,.{decimals}f}"
    if abs(val) < 0.0001 and val != 0:
        return f"{val:.6f}"
    if abs(val) < 1:
        return f"{val:.4f}"
    return f"{val:,.{decimals}f}"


def _fmt_pct(val: object) -> str:
    """Format a percentage with color coding (green positive, red negative)."""
    if not isinstance(val, (int, float)):
        return str(val) if val is not None else "-"
    c = _C()
    if val > 0:
        return f"{c.GREEN}+{val:.2f}%{c.RESET}"
    elif val < 0:
        return f"{c.RED}{val:.2f}%{c.RESET}"
    return f"{val:.2f}%"


def _fmt_signed(val: object) -> str:
    """Format a signed number with color (green positive, red negative)."""
    if not isinstance(val, (int, float)):
        return str(val) if val is not None else "-"
    c = _C()
    formatted = _fmt_number(val)
    if val > 0:
        return f"{c.GREEN}+{formatted}{c.RESET}"
    elif val < 0:
        return f"{c.RED}{formatted}{c.RESET}"
    return formatted


def _fmt_timestamp(ts: object) -> str:
    """Format a timestamp relative to now.

    TTY: "5m ago" for past, "in 1h" for future (e.g. next funding time).
    Non-TTY: truncated ISO for scripting.
    """
    if ts is None:
        return "-"
    s = str(ts)
    if not _is_tty():
        return s[:19]  # ISO truncated
    try:
        if "T" in s or "-" in s:
            dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
            now = datetime.now(timezone.utc)
            secs = int((dt - now).total_seconds())
            future = secs > 0
            secs = abs(secs)
            if secs < 60:
                rel = f"{secs}s"
            elif secs < 3600:
                rel = f"{secs // 60}m"
            elif secs < 86400:
                rel = f"{secs // 3600}h"
            else:
                rel = f"{secs // 86400}d"
            return f"in {rel}" if future else f"{rel} ago"
    except (ValueError, TypeError):
        pass
    return s[:19]


def _sort_rows(rows: list, spec: str) -> list:
    """Sort a list of dicts by one field. Prefix with '-' for descending.

    None values always go last, regardless of direction.
    """
    if not rows or not isinstance(rows[0], dict):
        return rows
    reverse = spec.startswith("-")
    key = spec.lstrip("-+")

    def sortable(v: object) -> object:
        if isinstance(v, bool):
            return int(v)
        if isinstance(v, (int, float)):
            return v
        return str(v).lower()

    with_val = [r for r in rows if r.get(key) is not None]
    without = [r for r in rows if r.get(key) is None]
    try:
        with_val.sort(key=lambda r: sortable(r.get(key)), reverse=reverse)
    except TypeError:
        with_val.sort(key=lambda r: str(r.get(key, "")).lower(), reverse=reverse)
    return with_val + without


def _truncate(s: str, width: int) -> str:
    """Truncate string with ellipsis if too long."""
    if len(s) <= width:
        return s
    if width <= 3:
        return s[:width]
    return s[: width - 1] + "\u2026"


def _visible_len(s: str) -> int:
    """Length of string excluding ANSI escape sequences."""
    return len(re.sub(r"\033\[[0-9;]*m", "", s))


def _pad(s: str, width: int, align: str = "left") -> str:
    """Pad string to width, accounting for ANSI codes."""
    vlen = _visible_len(s)
    pad_needed = max(0, width - vlen)
    if align == "right":
        return " " * pad_needed + s
    return s + " " * pad_needed


# ── Percentage / Numeric Column Detection ───────────────────────────────

_PCT_KEYS = {
    "change_24h", "change_7d", "change_30d", "change_1h",
    "price_change_percentage_24h", "price_change_percentage_7d",
    "pct_change", "pct", "percent", "return", "returns",
    "24h_change", "7d_change", "30d_change", "1h_change",
}

_NUMERIC_KEYS = {
    "price", "market_cap", "volume", "volume_24h", "total_volume",
    "open_interest", "oi", "tvl", "fdv", "rate", "funding_rate",
    "apr", "annualized", "spread", "strike", "iv", "delta",
    "gamma", "theta", "vega", "score", "rank", "dominance",
    "market_cap_usd", "volume_usd",
}

# Fields whose value is a decimal ratio that should display as a percentage
# in TTY mode (e.g. apr=2.74 means 274%). Matched case-insensitively against
# a normalized (lowercase, no underscores) key -- so "apr", "APR", "netApr",
# and "net_apr" all hit "apr"/"netapr".
_RATIO_KEYS = {
    "rate", "fundingrate", "longrate", "shortrate",
    "apr", "netapr",
    "basisrate", "spreadrate", "netfundingrate",
    "cumrate7d", "cumrate",
}


def _is_pct_key(key: str) -> bool:
    k = key.lower()
    return k in _PCT_KEYS or "pct" in k or "percent" in k or "change" in k


def _is_ratio_key(key: str) -> bool:
    return key.lower().replace("_", "") in _RATIO_KEYS


def _is_numeric_key(key: str) -> bool:
    k = key.lower()
    return k in _NUMERIC_KEYS or _is_pct_key(k)


def _fmt_ratio_as_pct(val: object) -> str:
    """Render a decimal ratio as a percentage (e.g. 2.74 -> '274.01%').

    Color-coded like _fmt_pct (green positive, red negative). Precision
    adapts to magnitude: tight values get more decimals to avoid
    collapsing small rates to '0.00%'.
    """
    if not isinstance(val, (int, float)):
        return str(val) if val is not None else "-"
    c = _C()
    pct = val * 100
    if abs(pct) >= 100:
        s = f"{pct:,.0f}%"
    elif abs(pct) >= 1:
        s = f"{pct:.2f}%"
    elif abs(pct) >= 0.01:
        s = f"{pct:.3f}%"
    elif pct == 0:
        s = "0%"
    else:
        s = f"{pct:.4f}%"
    if val > 0:
        return f"{c.GREEN}+{s}{c.RESET}"
    if val < 0:
        return f"{c.RED}{s}{c.RESET}"
    return s


# ── Table Rendering ─────────────────────────────────────────────────────


def _render_table(rows: list[dict], max_rows: int = 50) -> str:
    """Render a list of dicts as a box-drawn table.

    When piped (non-TTY): outputs clean TSV with no decorations.
    """
    if not rows or not isinstance(rows[0], dict):
        lines = [str(r) for r in rows[:max_rows]]
        if len(rows) > max_rows:
            lines.append(f"... {len(rows) - max_rows} more rows")
        return "\n".join(lines)

    display = rows[:max_rows]

    # Pick columns: skip very wide fields
    skip = {"sparkline", "sparkline_7d", "description", "content", "image", "thumb", "logo"}
    keys = [k for k in display[0].keys() if k not in skip]
    if len(keys) > 14:
        keys = keys[:14]

    # Non-TTY: clean TSV
    if not _is_tty():
        lines = ["\t".join(keys)]
        for row in display:
            vals = []
            for k in keys:
                v = row.get(k, "")
                if v is None:
                    v = ""
                vals.append(str(v))
            lines.append("\t".join(vals))
        return "\n".join(lines)

    c = _C()

    # Compute formatted cells
    formatted: list[list[str]] = []
    for row in display:
        frow: list[str] = []
        for k in keys:
            v = row.get(k)
            if v is None:
                frow.append("-")
            elif _is_pct_key(k) and isinstance(v, (int, float)):
                frow.append(_fmt_pct(v))
            elif _is_ratio_key(k) and isinstance(v, (int, float)):
                frow.append(_fmt_ratio_as_pct(v))
            elif _is_numeric_key(k) and isinstance(v, (int, float)):
                frow.append(_fmt_number(v))
            elif isinstance(v, str) and ("T" in v or "Z" in v) and len(v) > 16:
                frow.append(_fmt_timestamp(v))
            else:
                frow.append(_truncate(str(v), 28))
        formatted.append(frow)

    # Compute column widths
    widths: list[int] = []
    for i, k in enumerate(keys):
        header_w = len(k)
        cell_w = max((_visible_len(formatted[r][i]) for r in range(len(formatted))), default=0)
        widths.append(min(max(header_w, cell_w), 30))

    # Render with box-drawing
    lines: list[str] = []

    # Top border
    top = c.DIM + _C_ON.TL + _C_ON.TJ.join(_C_ON.H * (w + 2) for w in widths) + _C_ON.TR + c.RESET
    lines.append(top)

    # Header
    hdr_cells = []
    for i, k in enumerate(keys):
        hdr_cells.append(f" {c.BOLD}{_pad(k, widths[i])}{c.RESET} ")
    hdr = c.DIM + _C_ON.V + c.RESET + (c.DIM + _C_ON.V + c.RESET).join(hdr_cells) + c.DIM + _C_ON.V + c.RESET
    lines.append(hdr)

    # Header separator
    sep = c.DIM + _C_ON.LJ + _C_ON.CJ.join(_C_ON.H * (w + 2) for w in widths) + _C_ON.RJ + c.RESET
    lines.append(sep)

    # Data rows
    for frow in formatted:
        cells = []
        for i, k in enumerate(keys):
            align = "right" if _is_numeric_key(k) else "left"
            cells.append(f" {_pad(frow[i], widths[i], align)} ")
        row_line = c.DIM + _C_ON.V + c.RESET + (c.DIM + _C_ON.V + c.RESET).join(cells) + c.DIM + _C_ON.V + c.RESET
        lines.append(row_line)

    # Bottom border
    bot = c.DIM + _C_ON.BL + _C_ON.BJ.join(_C_ON.H * (w + 2) for w in widths) + _C_ON.BR + c.RESET
    lines.append(bot)

    if len(rows) > max_rows:
        lines.append(f"{c.DIM}... {len(rows) - max_rows} more rows (use --json for full output){c.RESET}")

    return "\n".join(lines)


def _render_dict(data: dict, indent: int = 0) -> str:
    """Render a dict as key: value lines."""
    c = _C()
    lines: list[str] = []
    prefix = "  " * indent
    for k, v in data.items():
        if isinstance(v, dict):
            lines.append(f"{prefix}{c.BOLD}{k}{c.RESET}:")
            lines.append(_render_dict(v, indent + 1))
        elif isinstance(v, list):
            lines.append(f"{prefix}{c.BOLD}{k}{c.RESET}: [{len(v)} items]")
        elif isinstance(v, (int, float)) and _is_pct_key(k):
            lines.append(f"{prefix}{c.BOLD}{k}{c.RESET}: {_fmt_pct(v)}")
        elif isinstance(v, (int, float)):
            lines.append(f"{prefix}{c.BOLD}{k}{c.RESET}: {_fmt_number(v)}")
        else:
            lines.append(f"{prefix}{c.BOLD}{k}{c.RESET}: {v}")
    return "\n".join(lines)


# ── Output Router ───────────────────────────────────────────────────────


def _output(
    data: object,
    *,
    as_json: bool = False,
    csv_out: bool = False,
    command: Optional[str] = None,
    use_pager: bool = True,
) -> None:
    """Central output dispatcher."""
    text: str

    # Warn on empty results
    if isinstance(data, list) and len(data) == 0:
        typer.echo("No data found.", err=True)
    elif isinstance(data, dict) and len(data) == 0:
        typer.echo("No data found.", err=True)

    if as_json:
        text = json.dumps(data, indent=2, default=str)

    elif csv_out:
        if isinstance(data, list) and data and isinstance(data[0], dict):
            headers = list(data[0].keys())
            lines = [",".join(headers)]
            for row in data:
                lines.append(",".join(str(row.get(h, "") or "") for h in headers))
            text = "\n".join(lines)
        else:
            text = json.dumps(data, indent=2, default=str)

    elif isinstance(data, list):
        text = _render_table(data)
    elif isinstance(data, dict):
        text = _render_dict(data)
    else:
        text = str(data)

    if use_pager:
        _page_output(text)
    else:
        sys.stdout.write(text)
        if not text.endswith("\n"):
            sys.stdout.write("\n")

    if command:
        _suggest(command)


# ── JSON Field Selection Parsing ────────────────────────────────────────
# --json with no value = full JSON; --json=fields = field selection.
# Typer doesn't support Optional[str] for options cleanly, so we use a
# sentinel approach: --json is a string that defaults to a sentinel.






# ── Commands ────────────────────────────────────────────────────────────


@app.command()
def market(
    json_out: bool = typer.Option(False, "--json", help="Output raw JSON"),
    csv_out: bool = typer.Option(False, "--csv", help="Output as CSV"),
) -> None:
    """Market overview — BTC price, dominance, Fear & Greed, gainers/losers."""
    json_mode = json_out
    data = _call("/v1/tracker/market-overview", "/api/tracker/market-overview")

    if json_mode is not None or csv_out:
        _output(data, as_json=json_out, csv_out=csv_out, command="market")
        return

    if not isinstance(data, dict):
        _output(data, command="market")
        return

    c = _C()
    btc = data.get("bitcoin", {})
    lines: list[str] = []

    lines.append(f"\n{c.BOLD}{c.CYAN}  Market Overview{c.RESET}")
    lines.append(f"  {c.DIM}{'=' * 44}{c.RESET}")
    lines.append(f"  BTC Price      {c.BOLD}${btc.get('price', 0):>14,.2f}{c.RESET}  {_fmt_pct(btc.get('change', btc.get('change_24h', 0)))}")
    lines.append(f"  BTC Dominance  {data.get('btc_dominance', 0):>14.1f}%")
    fgi = data.get("fgi", "?")
    fgi_class = data.get("fgi_classification", "?")
    fgi_color = c.GREEN if isinstance(fgi, (int, float)) and fgi > 50 else c.RED if isinstance(fgi, (int, float)) and fgi <= 25 else c.YELLOW
    lines.append(f"  Fear & Greed   {fgi_color}{fgi:>14}{c.RESET}   ({fgi_class})")
    eth = data.get("ethereum", {})
    btc_price = btc.get("price", 0)
    eth_price = eth.get("price", 0) if isinstance(eth, dict) else 0
    eth_btc_val = data.get("eth_btc", eth_price / btc_price if btc_price else 0)
    lines.append(f"  ETH/BTC        {eth_btc_val:>14.6f}")

    gainers = data.get("top_gainers", [])[:5]
    losers = data.get("top_losers", [])[:5]

    if gainers:
        lines.append(f"\n  {c.BOLD}{c.GREEN}Top Gainers{c.RESET}")
        for g in gainers:
            sym = g.get("symbol", "?")
            lines.append(f"    {sym:>8}  {_fmt_pct(g.get('change_24h', 0))}")
    if losers:
        lines.append(f"\n  {c.BOLD}{c.RED}Top Losers{c.RESET}")
        for l_item in losers:
            sym = l_item.get("symbol", "?")
            lines.append(f"    {sym:>8}  {_fmt_pct(l_item.get('change_24h', 0))}")

    lines.append("")
    _page_output("\n".join(lines))
    _suggest("market")


@app.command()
def funding(
    type: str = typer.Option("current", help="current, accumulated, or history"),
    coin: Optional[str] = typer.Option(None, help="Filter by coin ticker (e.g. BTC, ETH)"),
    days: int = typer.Option(30, help="Lookback days for history mode"),
    sort: Optional[str] = typer.Option(None, "--sort", help="Sort by field (rate, base_coin, exchange, open_interest, next_funding_time). Prefix with - for descending, e.g. -rate."),
    limit: Optional[int] = typer.Option(None, "--limit", help="Keep only the first N rows after filter/sort"),
    json_out: bool = typer.Option(False, "--json", help="Output raw JSON"),
    csv_out: bool = typer.Option(False, "--csv", help="Output as CSV"),
    web: bool = typer.Option(False, "--web", help="Open in browser"),
) -> None:
    """Funding rates across 13+ exchanges."""
    if web:
        _open_web("funding")
    params: dict = {"type": type}
    if coin:
        params["coin"] = coin.upper()
    if type == "history":
        params["days"] = str(days)
    data = _call("/v1/funding/rates", "/api/funding/rates", params)

    # Client-side coin filter: the current/accumulated endpoints ignore
    # the coin param, so filter here against base_coin.
    if coin and type != "history" and isinstance(data, list):
        needle = coin.upper()
        data = [r for r in data if isinstance(r, dict) and str(r.get("base_coin", "")).upper() == needle]
        if not data:
            typer.echo(f"No funding rows found for coin={needle}.", err=True)

    if sort and isinstance(data, list):
        data = _sort_rows(data, sort)

    if limit and isinstance(data, list):
        data = data[:limit]

    _output(data, as_json=json_out, csv_out=csv_out, command="funding")


@app.command()
def futures(
    chart: str = typer.Argument(help="Chart ID (e.g. oi-stacked, oi-total, liquidations, funding-rate, volume-total, annualized-basis)"),
    coin: str = typer.Option(DEFAULT_COIN, help="Coin ticker"),
    timeframe: str = typer.Option(DEFAULT_TIMEFRAME, help="1W, 2W, 1M, 3M, 6M, 1Y, 3Y"),
    exchanges: Optional[str] = typer.Option(None, help="Comma-separated exchanges"),
    json_out: bool = typer.Option(False, "--json", help="Output raw JSON"),
    csv_out: bool = typer.Option(False, "--csv", help="Output as CSV"),
    web: bool = typer.Option(False, "--web", help="Open in browser"),
) -> None:
    """Futures chart data — OI, volume, liquidations, basis, term structure."""
    if web:
        _open_web("futures")
    params = {"chart": chart, "coin": coin.upper(), "timeframe": timeframe}
    if exchanges:
        params["exchanges"] = exchanges
    data = _call("/v1/futures/data", "/api/futures/data", params)
    if isinstance(data, dict) and "data" in data:
        data = data["data"]
    _output(data, as_json=json_out, csv_out=csv_out, command="futures")


@app.command()
def options(
    chart: str = typer.Argument(help="Chart ID (e.g. atm-iv, vol-smile, gex, oi-by-strike, put-call-oi-ratio, put-call-volume-ratio)"),
    coin: str = typer.Option(DEFAULT_COIN, help="BTC, ETH, or SOL"),
    timeframe: str = typer.Option(DEFAULT_TIMEFRAME, help="1W, 1M, 3M, 6M, 1Y, 3Y, ALL"),
    exchanges: Optional[str] = typer.Option(None, help="Comma-separated exchanges"),
    json_out: bool = typer.Option(False, "--json", help="Output raw JSON"),
    csv_out: bool = typer.Option(False, "--csv", help="Output as CSV"),
    web: bool = typer.Option(False, "--web", help="Open in browser"),
) -> None:
    """Options analytics — IV, Greeks, GEX, vol surface, flow."""
    if web:
        _open_web("options")
    params = {"chart": chart, "coin": coin.upper(), "timeframe": timeframe}
    if exchanges:
        params["exchanges"] = exchanges
    data = _call("/v1/options/data", "/api/options/data", params)
    if isinstance(data, dict) and "data" in data:
        data = data["data"]
    _output(data, as_json=json_out, csv_out=csv_out, command="options")


@app.command()
def arb(
    type: str = typer.Argument("spot-perp", help="spot-perp or cross-exchange"),
    exchange: str = typer.Option("all", help="Exchange filter"),
    direction: str = typer.Option("all", help="all, long, or short"),
    sort: str = typer.Option("-apr", "--sort", help="Sort by field; prefix with - for descending. Defaults to -apr (highest APR first)."),
    limit: Optional[int] = typer.Option(None, "--limit", help="Keep only the first N rows after sort"),
    json_out: bool = typer.Option(False, "--json", help="Output raw JSON"),
    csv_out: bool = typer.Option(False, "--csv", help="Output as CSV"),
    web: bool = typer.Option(False, "--web", help="Open in browser"),
) -> None:
    """Arbitrage opportunities — spot-perp or cross-exchange."""
    if web:
        _open_web("arb")
    if type == "spot-perp":
        data = _call("/v1/arbitrage/spot-perp", "/api/arbitrage/spot-perp",
                      {"exchange": exchange, "direction": direction})
    else:
        data = _call("/v1/arbitrage/cross-exchange", "/api/arbitrage/cross-exchange",
                      {"exchanges": exchange if exchange != "all" else None})
    if sort and isinstance(data, list):
        data = _sort_rows(data, sort)
    if limit and isinstance(data, list):
        data = data[:limit]
    _output(data, as_json=json_out, csv_out=csv_out, command="arb")


@app.command()
def narratives(
    slug: Optional[str] = typer.Option(None, help="Narrative slug (e.g. defi, ai-agents)"),
    json_out: bool = typer.Option(False, "--json", help="Output raw JSON"),
    csv_out: bool = typer.Option(False, "--csv", help="Output as CSV"),
    web: bool = typer.Option(False, "--web", help="Open in browser"),
) -> None:
    """Crypto narrative analytics — L1, DeFi, AI, RWA, and more."""
    if web:
        _open_web("narratives")
    params: dict = {}
    if slug:
        params["narrative"] = slug
    data = _call("/v1/narratives/data", "/api/narratives/data", params)
    if isinstance(data, dict) and "narratives" in data:
        data = data["narratives"]
    _output(data, as_json=json_out, csv_out=csv_out, command="narratives")


@app.command()
def ecosystems(
    slug: Optional[str] = typer.Option(None, help="Ecosystem slug (e.g. ethereum, solana)"),
    exclude_native: bool = typer.Option(False, help="Exclude native token"),
    json_out: bool = typer.Option(False, "--json", help="Output raw JSON"),
    csv_out: bool = typer.Option(False, "--csv", help="Output as CSV"),
    web: bool = typer.Option(False, "--web", help="Open in browser"),
) -> None:
    """Blockchain ecosystem analytics — ETH, SOL, ARB, and more."""
    if web:
        _open_web("ecosystems")
    params: dict = {}
    if slug:
        params["ecosystem"] = slug
    if exclude_native:
        params["excludeNative"] = "true"
    data = _call("/v1/ecosystems/data", "/api/ecosystems/data", params)
    if isinstance(data, dict) and "ecosystems" in data:
        data = data["ecosystems"]
    _output(data, as_json=json_out, csv_out=csv_out, command="ecosystems")


@app.command()
def memecoins(
    slug: Optional[str] = typer.Option(None, help="Narrative slug (e.g. dog-coins, ai-meme)"),
    historical: Optional[str] = typer.Option(None, help="24h or 7d"),
    sort: Optional[str] = typer.Option(None, "--sort", help="Sort by field; prefix with - for descending"),
    limit: Optional[int] = typer.Option(None, "--limit", help="Keep only the first N rows after sort"),
    json_out: bool = typer.Option(False, "--json", help="Output raw JSON"),
    csv_out: bool = typer.Option(False, "--csv", help="Output as CSV"),
    web: bool = typer.Option(False, "--web", help="Open in browser"),
) -> None:
    """Memecoin narrative data — Dog, Cat, AI, Political, and more."""
    if web:
        _open_web("memecoins")
    params: dict = {}
    if slug:
        params["narrative"] = slug
    if historical:
        params["historical"] = historical
    data = _call("/v1/memecoins/data", "/api/memecoins/data", params)
    if isinstance(data, dict) and "narratives" in data:
        data = data["narratives"]
    if sort and isinstance(data, list):
        data = _sort_rows(data, sort)
    if limit and isinstance(data, list):
        data = data[:limit]
    _output(data, as_json=json_out, csv_out=csv_out, command="memecoins")


@app.command()
def listings(
    mode: str = typer.Argument("hub", help="hub (aggregated counts) or recent (flat feed)"),
    narrative: Optional[str] = typer.Option(None, help="Narrative slug (e.g. ai-agents, memes, defi)"),
    exchange: Optional[str] = typer.Option(None, help="Exchange: binance, okx, bybit, gateio, mexc"),
    days: int = typer.Option(90, help="Lookback days for recent mode (1-365)"),
    limit: int = typer.Option(200, help="Max rows for recent mode (1-1000, server-side)"),
    sort: Optional[str] = typer.Option(None, "--sort", help="Sort by field; prefix with - for descending (recent mode only)"),
    json_out: bool = typer.Option(False, "--json", help="Output raw JSON"),
    csv_out: bool = typer.Option(False, "--csv", help="Output as CSV"),
    web: bool = typer.Option(False, "--web", help="Open in browser"),
) -> None:
    """CEX exchange listings tagged by narrative — Binance, OKX, Bybit, Gate.io, MEXC."""
    if web:
        _open_web("listings")
    params: dict = {}
    if narrative:
        params["narrative"] = narrative
    if exchange:
        params["exchange"] = exchange
    if mode == "recent":
        params["days"] = str(days)
        params["limit"] = str(limit)
        data = _call("/v1/listings/recent", "/api/listings/recent", params)
        if isinstance(data, dict) and "rows" in data:
            data = data["rows"]
    else:
        data = _call("/v1/listings/data", "/api/listings/data", params)
    if sort and isinstance(data, list):
        data = _sort_rows(data, sort)
    _output(data, as_json=json_out, csv_out=csv_out, command="listings")


_TICKER_TO_SLUG: dict[str, str] = {
    "BTC": "bitcoin", "ETH": "ethereum", "SOL": "solana", "BNB": "binancecoin",
    "XRP": "ripple", "ADA": "cardano", "DOGE": "dogecoin", "DOT": "polkadot",
    "AVAX": "avalanche-2", "LINK": "chainlink", "MATIC": "matic-network",
    "UNI": "uniswap", "AAVE": "aave", "ATOM": "cosmos", "LTC": "litecoin",
    "ARB": "arbitrum", "OP": "optimism", "SUI": "sui", "APT": "aptos",
    "NEAR": "near", "FIL": "filecoin", "TRX": "tron", "TON": "the-open-network",
    "SHIB": "shiba-inu", "PEPE": "pepe", "WIF": "dogwifcoin",
}


@app.command()
def news(
    limit: int = typer.Option(20, help="Number of articles (server-side)"),
    coin: Optional[str] = typer.Option(None, help="Filter by coin (ticker like BTC or CoinGecko slug like bitcoin)"),
    category: Optional[str] = typer.Option(None, help="Filter by category"),
    sort: Optional[str] = typer.Option(None, "--sort", help="Sort by field; prefix with - for descending (e.g. -published)"),
    json_out: bool = typer.Option(False, "--json", help="Output raw JSON"),
    csv_out: bool = typer.Option(False, "--csv", help="Output as CSV"),
    web: bool = typer.Option(False, "--web", help="Open in browser"),
) -> None:
    """Aggregated crypto news feed."""
    if web:
        _open_web("news")
    json_mode = json_out
    params: dict = {"limit": str(limit)}
    if coin:
        # Map common tickers to CoinGecko slugs; pass through if already a slug
        slug = _TICKER_TO_SLUG.get(coin.upper(), coin)
        params["coin"] = slug
    if category:
        params["category"] = category
    data = _call("/v1/news/feed", "/api/news/feed", params)

    if sort:
        if isinstance(data, list):
            data = _sort_rows(data, sort)
        elif isinstance(data, dict):
            for k in ("items", "articles"):
                if isinstance(data.get(k), list):
                    data[k] = _sort_rows(data[k], sort)
                    break

    if json_mode is not None or csv_out:
        _output(data, as_json=json_out, csv_out=csv_out, command="news")
        return

    items = data if isinstance(data, list) else data.get("items", data.get("articles", []))  # type: ignore[union-attr]
    if isinstance(items, list):
        c = _C()
        lines: list[str] = []
        lines.append(f"\n{c.BOLD}{c.CYAN}  Latest News{c.RESET}")
        lines.append(f"  {c.DIM}{'=' * 60}{c.RESET}")
        for item in items[:limit]:
            title = item.get("title", "?")
            source = item.get("source", "?")
            published = item.get("published", item.get("published_at", ""))
            ts = _fmt_timestamp(published)
            lines.append(f"  {c.DIM}{ts:>8}{c.RESET}  {c.BOLD}{source:>12}{c.RESET}  {title}")
        lines.append("")
        _page_output("\n".join(lines))
        _suggest("news")
    else:
        _output(data, command="news")


@app.command()
def search(
    query: str = typer.Argument(help="Coin name or ticker to search"),
    json_out: bool = typer.Option(False, "--json", help="Output raw JSON"),
    csv_out: bool = typer.Option(False, "--csv", help="Output as CSV"),
) -> None:
    """Search coins by name or ticker."""
    data = _call("/v1/market-cap/search", "/api/market-cap/search", {"q": query})
    _output(data, as_json=json_out, csv_out=csv_out, command="search")


@app.command()
def gems(
    limit: int = typer.Option(20, help="Number of tokens (server-side fetch + client-side cap)"),
    sort: Optional[str] = typer.Option(None, "--sort", help="Sort by field; prefix with - for descending (e.g. -score)"),
    json_out: bool = typer.Option(False, "--json", help="Output raw JSON"),
    csv_out: bool = typer.Option(False, "--csv", help="Output as CSV"),
    web: bool = typer.Option(False, "--web", help="Open in browser"),
) -> None:
    """Low-cap high-potential token discovery."""
    if web:
        _open_web("gems")
    data = _call("/v1/gem-finder/data", "/api/gem-finder/data", {"limit": str(limit)})
    if isinstance(data, dict) and isinstance(data.get("coins"), list):
        data = data["coins"]
    if sort and isinstance(data, list):
        data = _sort_rows(data, sort)
    if isinstance(data, list) and len(data) > limit:
        data = data[:limit]
    _output(data, as_json=json_out, csv_out=csv_out, command="gems")


@app.command()
def predict(
    coin: Optional[str] = typer.Option(None, help="CoinGecko slug (e.g. bitcoin)"),
    json_out: bool = typer.Option(False, "--json", help="Output raw JSON"),
) -> None:
    """AI price prediction scores."""
    params: dict = {}
    if coin:
        params["coin"] = coin
    data = _call("/v1/price-prediction/data", "/api/price-prediction/data", params)
    _output(data, as_json=json_out, command="predict")


@app.command()
def coverage(
    json_out: bool = typer.Option(False, "--json", help="Output raw JSON"),
) -> None:
    """Show available data products, exchanges, and chart types."""
    json_mode = json_out
    data = _call("/v1/meta/coverage", "/api/v1/meta/coverage")

    if json_mode is not None:
        _output(data, as_json=json_out, command="coverage")
        return

    if isinstance(data, dict) and "products" in data:
        c = _C()
        lines: list[str] = []
        products = data["products"]
        for name, info in products.items():
            lines.append(f"\n{c.BOLD}{c.CYAN}  {name}{c.RESET}")
            if isinstance(info, dict):
                for k, v in info.items():
                    if isinstance(v, list) and len(v) > 8:
                        items_str = ", ".join(str(x) for x in v[:8])
                        lines.append(f"    {c.DIM}{k}:{c.RESET} {items_str}{c.DIM}... ({len(v)} total){c.RESET}")
                    elif isinstance(v, list):
                        lines.append(f"    {c.DIM}{k}:{c.RESET} {', '.join(str(x) for x in v)}")
                    else:
                        lines.append(f"    {c.DIM}{k}:{c.RESET} {v}")
        lines.append("")
        _page_output("\n".join(lines))
        _suggest("coverage")
    else:
        _output(data, command="coverage")


@app.command()
def coins(
    json_out: bool = typer.Option(False, "--json", help="Output raw JSON"),
    csv_out: bool = typer.Option(False, "--csv", help="Output as CSV"),
) -> None:
    """List available futures coins with capability flags."""
    data = _call("/v1/futures/coins", "/api/futures/coins")
    if isinstance(data, dict) and "coins" in data:
        data = data["coins"]
    _output(data, as_json=json_out, csv_out=csv_out, command="coins")


# ── New Commands ────────────────────────────────────────────────────────


@app.command()
def login() -> None:
    """Authenticate with Sharpe — opens browser to get API key, saves to config."""
    c = _C()
    dashboard_url = "https://sharpe.ai/dashboard/api-keys"

    typer.echo(f"\n{c.BOLD}  Sharpe Authentication{c.RESET}")
    typer.echo(f"  {c.DIM}{'=' * 40}{c.RESET}")
    typer.echo(f"\n  Opening {c.UNDERLINE}{dashboard_url}{c.RESET}")
    typer.echo(f"  {c.DIM}Copy your API key from the dashboard.{c.RESET}\n")

    webbrowser.open(dashboard_url)

    try:
        api_key = typer.prompt("  Paste your API key")
    except (KeyboardInterrupt, EOFError):
        typer.echo("\n  Cancelled.")
        raise typer.Exit(0)

    api_key = api_key.strip()
    if not api_key:
        typer.echo(f"  {c.RED}No key provided. Aborting.{c.RESET}")
        raise typer.Exit(1)

    # Validate the key
    typer.echo(f"  {c.DIM}Validating...{c.RESET}")
    try:
        with httpx.Client(timeout=10.0) as client:
            resp = client.get(
                f"{API_BASE}/v1/health",
                headers={"Authorization": f"Bearer {api_key}"},
            )
        if resp.status_code == 200:
            typer.echo(f"  {c.GREEN}Key validated successfully.{c.RESET}")
        else:
            typer.echo(f"  {c.YELLOW}Warning: API returned {resp.status_code}. Saving anyway.{c.RESET}")
    except Exception:
        typer.echo(f"  {c.YELLOW}Warning: Could not reach API. Saving key anyway.{c.RESET}")

    cfg = _load_config()
    cfg["api_key"] = api_key
    _save_config(cfg)
    typer.echo(f"  {c.GREEN}Saved to {_CONFIG_PATH}{c.RESET}\n")


@app.command()
def doctor() -> None:
    """Self-diagnosis — check API connectivity, config, and versions."""
    c = _C()

    typer.echo(f"\n{c.BOLD}{c.CYAN}  Sharpe Doctor{c.RESET}")
    typer.echo(f"  {c.DIM}{'=' * 40}{c.RESET}")

    # CLI version
    typer.echo(f"\n  {c.BOLD}CLI Version:{c.RESET}    {__version__}")

    # Python version
    typer.echo(f"  {c.BOLD}Python:{c.RESET}         {platform.python_version()}")

    # Platform
    typer.echo(f"  {c.BOLD}Platform:{c.RESET}       {platform.system()} {platform.machine()}")

    # Config file
    if _CONFIG_PATH.exists():
        typer.echo(f"  {c.BOLD}Config:{c.RESET}         {c.GREEN}{_CONFIG_PATH}{c.RESET}")
        cfg = _load_config()
        for k, v in cfg.items():
            display_v = v
            if k == "api_key" and len(v) > 8:
                display_v = v[:4] + "..." + v[-4:]
            typer.echo(f"    {c.DIM}{k}: {display_v}{c.RESET}")
    else:
        typer.echo(f"  {c.BOLD}Config:{c.RESET}         {c.YELLOW}Not found ({_CONFIG_PATH}){c.RESET}")

    # API key
    key_source = "env" if os.getenv("SHARPE_API_KEY") else "config" if _CFG.get("api_key") else "none"
    if API_KEY:
        masked = API_KEY[:4] + "..." + API_KEY[-4:] if len(API_KEY) > 8 else "***"
        typer.echo(f"  {c.BOLD}API Key:{c.RESET}        {c.GREEN}{masked} (from {key_source}){c.RESET}")
    else:
        typer.echo(f"  {c.BOLD}API Key:{c.RESET}        {c.YELLOW}Not set (using free endpoints){c.RESET}")

    # Network connectivity
    typer.echo(f"\n  {c.BOLD}Connectivity{c.RESET}")
    typer.echo(f"  {c.DIM}{'─' * 40}{c.RESET}")

    # Check free endpoint
    try:
        with httpx.Client(timeout=10.0) as client:
            t0 = time.monotonic()
            resp = client.get(f"{FREE_BASE}/api/health")
            latency = (time.monotonic() - t0) * 1000
            if resp.status_code == 200:
                typer.echo(f"  {c.GREEN}OK{c.RESET}  Free API ({FREE_BASE})  {c.DIM}{latency:.0f}ms{c.RESET}")
            else:
                typer.echo(f"  {c.YELLOW}!!{c.RESET}  Free API returned {resp.status_code}  {c.DIM}{latency:.0f}ms{c.RESET}")
    except Exception as e:
        typer.echo(f"  {c.RED}FAIL{c.RESET}  Free API ({FREE_BASE}): {e}")

    # Check authenticated endpoint
    if API_KEY:
        try:
            with httpx.Client(timeout=10.0) as client:
                t0 = time.monotonic()
                resp = client.get(
                    f"{API_BASE}/v1/health",
                    headers={"Authorization": f"Bearer {API_KEY}"},
                )
                latency = (time.monotonic() - t0) * 1000
                if resp.status_code == 200:
                    typer.echo(f"  {c.GREEN}OK{c.RESET}  Auth API ({API_BASE})  {c.DIM}{latency:.0f}ms{c.RESET}")
                elif resp.status_code == 401:
                    typer.echo(f"  {c.RED}FAIL{c.RESET}  Auth API: 401 Unauthorized (invalid key)  {c.DIM}{latency:.0f}ms{c.RESET}")
                else:
                    typer.echo(f"  {c.YELLOW}!!{c.RESET}  Auth API returned {resp.status_code}  {c.DIM}{latency:.0f}ms{c.RESET}")
        except Exception as e:
            typer.echo(f"  {c.RED}FAIL{c.RESET}  Auth API ({API_BASE}): {e}")
    else:
        typer.echo(f"  {c.DIM}SKIP{c.RESET}  Auth API (no key configured)")

    # Environment
    typer.echo(f"\n  {c.BOLD}Environment{c.RESET}")
    typer.echo(f"  {c.DIM}{'─' * 40}{c.RESET}")
    typer.echo(f"  TTY:          {'yes' if _is_tty() else 'no'}")
    typer.echo(f"  NO_COLOR:     {os.environ.get('NO_COLOR', 'not set')}")
    typer.echo(f"  PAGER:        {os.environ.get('PAGER', 'less -FIRX (default)')}")
    cols, rows = shutil.get_terminal_size((80, 24))
    typer.echo(f"  Terminal:     {cols}x{rows}")
    typer.echo("")


@app.command()
def watch(
    command: str = typer.Argument(help="Command to watch: market, funding, futures, options, arb"),
    chart: Optional[str] = typer.Option(None, help="Chart ID for futures/options"),
    coin: Optional[str] = typer.Option(None, help="Coin ticker"),
    type: Optional[str] = typer.Option(None, help="Type parameter (e.g. current, spot-perp)"),
    interval: int = typer.Option(30, help="Refresh interval in seconds"),
) -> None:
    """Live auto-refresh mode. Ctrl+C to exit.

    Examples:
        sharpe watch market
        sharpe watch funding --coin BTC
        sharpe watch futures --chart oi-stacked --coin ETH
    """
    c = _C()

    # Build a callable that fetches and formats data
    def _fetch() -> str:
        try:
            if command == "market":
                data = _call("/v1/tracker/market-overview", "/api/tracker/market-overview")
                return _render_market_compact(data)
            elif command == "funding":
                params: dict = {"type": type or "current"}
                if coin:
                    params["coin"] = coin.upper()
                data = _call("/v1/funding/rates", "/api/funding/rates", params)
                return _render_table(data) if isinstance(data, list) else _render_dict(data) if isinstance(data, dict) else str(data)
            elif command == "futures":
                params = {"chart": chart or "oi-stacked", "coin": (coin or DEFAULT_COIN).upper(), "timeframe": DEFAULT_TIMEFRAME}
                data = _call("/v1/futures/data", "/api/futures/data", params)
                if isinstance(data, dict) and "data" in data:
                    data = data["data"]
                return _render_table(data) if isinstance(data, list) else _render_dict(data) if isinstance(data, dict) else str(data)
            elif command == "options":
                params = {"chart": chart or "atm-iv", "coin": (coin or DEFAULT_COIN).upper(), "timeframe": DEFAULT_TIMEFRAME}
                data = _call("/v1/options/data", "/api/options/data", params)
                if isinstance(data, dict) and "data" in data:
                    data = data["data"]
                return _render_table(data) if isinstance(data, list) else _render_dict(data) if isinstance(data, dict) else str(data)
            elif command == "arb":
                arb_type = type or "spot-perp"
                if arb_type == "spot-perp":
                    data = _call("/v1/arbitrage/spot-perp", "/api/arbitrage/spot-perp", {"exchange": "all", "direction": "all"})
                else:
                    data = _call("/v1/arbitrage/cross-exchange", "/api/arbitrage/cross-exchange", {})
                return _render_table(data) if isinstance(data, list) else _render_dict(data) if isinstance(data, dict) else str(data)
            else:
                return f"Unknown watch target: {command}. Supported: market, funding, futures, options, arb"
        except SystemExit:
            return f"{c.RED}API error — retrying in {interval}s{c.RESET}"
        except Exception as e:
            return f"{c.RED}Error: {e}{c.RESET}"

    # Graceful exit on Ctrl+C
    _running = True

    def _handle_sigint(sig: int, frame: object) -> None:
        nonlocal _running
        _running = False

    prev_handler = signal.signal(signal.SIGINT, _handle_sigint)

    try:
        while _running:
            # Clear screen
            sys.stdout.write("\033[2J\033[H")
            sys.stdout.flush()

            now = datetime.now(timezone.utc).strftime("%H:%M:%S UTC")
            header = f"{c.BOLD}{c.CYAN}  sharpe watch {command}{c.RESET}  {c.DIM}refreshing every {interval}s  |  {now}  |  Ctrl+C to exit{c.RESET}\n"
            sys.stdout.write(header)

            output = _fetch()
            sys.stdout.write(output)
            if not output.endswith("\n"):
                sys.stdout.write("\n")
            sys.stdout.flush()

            # Sleep in small increments so Ctrl+C is responsive
            for _ in range(interval * 10):
                if not _running:
                    break
                time.sleep(0.1)
    finally:
        signal.signal(signal.SIGINT, prev_handler)

    typer.echo(f"\n{c.DIM}Watch stopped.{c.RESET}")


def _render_market_compact(data: object) -> str:
    """Compact market overview for watch mode."""
    if not isinstance(data, dict):
        return str(data)

    c = _C()
    btc = data.get("bitcoin", {})
    lines: list[str] = []

    lines.append(f"\n  {c.BOLD}BTC{c.RESET}           ${btc.get('price', 0):>14,.2f}  {_fmt_pct(btc.get('change', btc.get('change_24h', 0)))}")
    lines.append(f"  {c.BOLD}Dominance{c.RESET}     {data.get('btc_dominance', 0):>14.1f}%")

    fgi = data.get("fgi", "?")
    fgi_class = data.get("fgi_classification", "?")
    fgi_color = c.GREEN if isinstance(fgi, (int, float)) and fgi > 50 else c.RED if isinstance(fgi, (int, float)) and fgi <= 25 else c.YELLOW
    lines.append(f"  {c.BOLD}Fear/Greed{c.RESET}    {fgi_color}{fgi:>14}{c.RESET}   ({fgi_class})")
    eth = data.get("ethereum", {})
    btc_price = btc.get("price", 0)
    eth_price = eth.get("price", 0) if isinstance(eth, dict) else 0
    eth_btc_val = data.get("eth_btc", eth_price / btc_price if btc_price else 0)
    lines.append(f"  {c.BOLD}ETH/BTC{c.RESET}       {eth_btc_val:>14.6f}")

    gainers = data.get("top_gainers", [])[:3]
    losers = data.get("top_losers", [])[:3]

    if gainers:
        lines.append(f"\n  {c.GREEN}{c.BOLD}Gainers{c.RESET}")
        for g in gainers:
            lines.append(f"    {g.get('symbol', '?'):>8}  {_fmt_pct(g.get('change_24h', 0))}")
    if losers:
        lines.append(f"  {c.RED}{c.BOLD}Losers{c.RESET}")
        for l_item in losers:
            lines.append(f"    {l_item.get('symbol', '?'):>8}  {_fmt_pct(l_item.get('change_24h', 0))}")

    return "\n".join(lines)


@app.command()
def briefing(
    json_out: bool = typer.Option(False, "--json", help="Output raw JSON"),
) -> None:
    """Daily composite briefing — market + narratives + funding + arb in one view."""
    c = _C()

    if json_out:
        # Collect all data into a single JSON object
        sections: dict = {}
        try:
            sections["market"] = _call("/v1/tracker/market-overview", "/api/tracker/market-overview")
        except SystemExit:
            sections["market"] = {"error": "failed to fetch"}
        try:
            sections["funding"] = _call("/v1/funding/rates", "/api/funding/rates", {"type": "current"})
        except SystemExit:
            sections["funding"] = {"error": "failed to fetch"}
        try:
            sections["narratives"] = _call("/v1/narratives/data", "/api/narratives/data", {})
        except SystemExit:
            sections["narratives"] = {"error": "failed to fetch"}
        try:
            sections["arb_spot_perp"] = _call("/v1/arbitrage/spot-perp", "/api/arbitrage/spot-perp",
                                                {"exchange": "all", "direction": "all"})
        except SystemExit:
            sections["arb_spot_perp"] = {"error": "failed to fetch"}
        _output(sections, as_json=json_out, use_pager=False)
        return

    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    lines: list[str] = []

    lines.append(f"\n{c.BOLD}{c.CYAN}  ╔{'═' * 50}╗{c.RESET}")
    lines.append(f"{c.BOLD}{c.CYAN}  ║  SHARPE DAILY BRIEFING{' ' * 27}║{c.RESET}")
    lines.append(f"{c.BOLD}{c.CYAN}  ║  {c.DIM}{now}{' ' * (48 - len(now))}║{c.RESET}")
    lines.append(f"{c.BOLD}{c.CYAN}  ╚{'═' * 50}╝{c.RESET}")

    # 1. Market Overview
    lines.append(f"\n  {c.BOLD}{c.YELLOW}[1] MARKET OVERVIEW{c.RESET}")
    lines.append(f"  {c.DIM}{'─' * 48}{c.RESET}")
    try:
        mkt = _call("/v1/tracker/market-overview", "/api/tracker/market-overview")
        if isinstance(mkt, dict):
            btc = mkt.get("bitcoin", {})
            lines.append(f"  BTC Price      ${btc.get('price', 0):>14,.2f}  {_fmt_pct(btc.get('change', btc.get('change_24h', 0)))}")
            lines.append(f"  Dominance      {mkt.get('btc_dominance', 0):>14.1f}%")
            fgi = mkt.get("fgi", "?")
            fgi_cls = mkt.get("fgi_classification", "?")
            lines.append(f"  Fear & Greed   {fgi:>14}   ({fgi_cls})")
            eth = mkt.get("ethereum", {})
            btc_price = btc.get("price", 0)
            eth_price = eth.get("price", 0) if isinstance(eth, dict) else 0
            eth_btc_val = mkt.get("eth_btc", eth_price / btc_price if btc_price else 0)
            lines.append(f"  ETH/BTC        {eth_btc_val:>14.6f}")

            gainers = mkt.get("top_gainers", [])[:3]
            losers = mkt.get("top_losers", [])[:3]
            if gainers:
                g_str = "  ".join(f"{g.get('symbol', '?')} {_fmt_pct(g.get('change_24h', 0))}" for g in gainers)
                lines.append(f"  {c.GREEN}Gainers:{c.RESET} {g_str}")
            if losers:
                l_str = "  ".join(f"{l.get('symbol', '?')} {_fmt_pct(l.get('change_24h', 0))}" for l in losers)
                lines.append(f"  {c.RED}Losers:{c.RESET}  {l_str}")
    except (SystemExit, Exception) as e:
        lines.append(f"  {c.RED}Failed to fetch market data{c.RESET}")

    # 2. Top Narratives
    lines.append(f"\n  {c.BOLD}{c.YELLOW}[2] TOP NARRATIVES{c.RESET}")
    lines.append(f"  {c.DIM}{'─' * 48}{c.RESET}")
    try:
        narr_data = _call("/v1/narratives/data", "/api/narratives/data", {})
        narr_list = narr_data if isinstance(narr_data, list) else narr_data.get("narratives", []) if isinstance(narr_data, dict) else []
        if isinstance(narr_list, list):
            # Sort by 24h change if possible, show top 5
            sorted_narr = sorted(
                narr_list,
                key=lambda x: x.get("change24h", x.get("change_24h", x.get("price_change_percentage_24h", 0))) or 0,
                reverse=True,
            )
            for n in sorted_narr[:5]:
                name = n.get("name", n.get("narrative", "?"))
                ch = n.get("change24h", n.get("change_24h", n.get("price_change_percentage_24h", 0)))
                mcap = n.get("marketCap", n.get("market_cap", n.get("market_cap_usd", 0)))
                lines.append(f"    {_truncate(str(name), 20):<22} {_fmt_pct(ch):>16}  mcap {_fmt_number(mcap):>10}")
    except (SystemExit, Exception):
        lines.append(f"  {c.RED}Failed to fetch narrative data{c.RESET}")

    # 3. Funding Rate Summary
    lines.append(f"\n  {c.BOLD}{c.YELLOW}[3] FUNDING RATES (TOP POSITIVE & NEGATIVE){c.RESET}")
    lines.append(f"  {c.DIM}{'─' * 48}{c.RESET}")
    try:
        fund_data = _call("/v1/funding/rates", "/api/funding/rates", {"type": "current"})
        if isinstance(fund_data, list):
            sorted_fund = sorted(
                [f for f in fund_data if isinstance(f, dict) and isinstance(f.get("rate", f.get("funding_rate")), (int, float))],
                key=lambda x: x.get("rate", x.get("funding_rate", 0)),
                reverse=True,
            )
            # Top 3 positive
            positive = sorted_fund[:3]
            negative = sorted_fund[-3:][::-1]
            if positive:
                lines.append(f"  {c.GREEN}Highest (longs pay):{c.RESET}")
                for f_item in positive:
                    sym = f_item.get("symbol", f_item.get("coin", "?"))
                    exch = f_item.get("exchange", "?")
                    rate = f_item.get("rate", f_item.get("funding_rate", 0))
                    lines.append(f"    {sym:>10} {exch:<12} {_fmt_signed(rate)}")
            if negative:
                lines.append(f"  {c.RED}Lowest (shorts pay):{c.RESET}")
                for f_item in negative:
                    sym = f_item.get("symbol", f_item.get("coin", "?"))
                    exch = f_item.get("exchange", "?")
                    rate = f_item.get("rate", f_item.get("funding_rate", 0))
                    lines.append(f"    {sym:>10} {exch:<12} {_fmt_signed(rate)}")
    except (SystemExit, Exception):
        lines.append(f"  {c.RED}Failed to fetch funding data{c.RESET}")

    # 4. Arbitrage Opportunities
    lines.append(f"\n  {c.BOLD}{c.YELLOW}[4] ARBITRAGE OPPORTUNITIES{c.RESET}")
    lines.append(f"  {c.DIM}{'─' * 48}{c.RESET}")
    try:
        arb_data = _call("/v1/arbitrage/spot-perp", "/api/arbitrage/spot-perp",
                          {"exchange": "all", "direction": "all"})
        if isinstance(arb_data, list):
            sorted_arb = sorted(
                [a for a in arb_data if isinstance(a, dict) and isinstance(a.get("apr", a.get("annualized")), (int, float))],
                key=lambda x: abs(x.get("apr", x.get("annualized", 0))),
                reverse=True,
            )
            for a_item in sorted_arb[:5]:
                sym = a_item.get("symbol", a_item.get("coin", "?"))
                exch = a_item.get("exchange", "?")
                apr_val = a_item.get("apr", a_item.get("annualized", 0))
                direction = a_item.get("direction", "?")
                lines.append(f"    {sym:>10} {exch:<12} {direction:<6} APR: {_fmt_pct(apr_val)}")
            if not sorted_arb:
                lines.append(f"  {c.DIM}No opportunities found{c.RESET}")
    except (SystemExit, Exception):
        lines.append(f"  {c.RED}Failed to fetch arb data{c.RESET}")

    lines.append(f"\n  {c.DIM}{'─' * 48}{c.RESET}")
    lines.append(f"  {c.DIM}Generated by Sharpe CLI v{__version__}{c.RESET}\n")

    _page_output("\n".join(lines))
    _suggest("briefing")


# ── Entry Point ─────────────────────────────────────────────────────────


def main() -> None:
    app()


if __name__ == "__main__":
    main()
