"""Tests for the Sharpe MCP server."""

import json
import time
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from server import (
    ECOSYSTEM_SLUGS,
    EXCHANGES_DATA,
    FUTURES_CHARTS,
    MAX_ITEMS,
    NARRATIVE_SLUGS,
    OPTIONS_CHARTS,
    TTLCache,
    _cache,
    _fmt_pct,
    _fmt_rate,
    _fmt_usd,
    _safe_call,
    _safe_get,
    call_api,
)


# ── Fixtures ───────────────────────────────────────────────────────────────


@pytest.fixture(autouse=True)
def clear_cache():
    """Ensure the module-level cache is empty before every test."""
    _cache.clear()
    yield
    _cache.clear()


def _make_mock_ctx(mock_client: AsyncMock) -> MagicMock:
    """Build a mock MCP Context whose lifespan_context holds *mock_client*."""
    ctx = MagicMock()
    ctx.request_context.lifespan_context = {"http_client": mock_client}
    return ctx


def _make_response(
    status_code: int = 200,
    json_data: object = None,
    text: str = "",
) -> MagicMock:
    """Build a mock httpx.Response."""
    resp = MagicMock()
    resp.status_code = status_code
    resp.json.return_value = json_data
    resp.text = text
    return resp


# ── TTLCache ───────────────────────────────────────────────────────────────


class TestTTLCache:
    def test_get_set_roundtrip(self):
        cache = TTLCache(default_ttl=60)
        cache.set("k", {"price": 100})
        assert cache.get("k") == {"price": 100}

    def test_get_missing_key_returns_none(self):
        cache = TTLCache()
        assert cache.get("nonexistent") is None

    def test_expired_entry_returns_none(self):
        cache = TTLCache(default_ttl=60)
        # Manually insert an already-expired entry
        cache._store["old"] = (time.monotonic() - 1, "stale")
        assert cache.get("old") is None
        # The expired key should be removed from the store
        assert "old" not in cache._store

    def test_custom_ttl_per_entry(self):
        cache = TTLCache(default_ttl=600)
        cache.set("short", "val", ttl=0)
        # TTL=0 means it expires immediately (monotonic has advanced)
        # Give a tiny buffer — the entry should expire on next get
        time.sleep(0.01)
        assert cache.get("short") is None

    def test_evict_expired_removes_stale_entries(self):
        cache = TTLCache(default_ttl=60)
        cache._store["a"] = (time.monotonic() - 10, "dead")
        cache._store["b"] = (time.monotonic() - 5, "dead")
        cache._store["c"] = (time.monotonic() + 600, "alive")
        evicted = cache.evict_expired()
        assert evicted == 2
        assert "a" not in cache._store
        assert "b" not in cache._store
        assert cache.get("c") == "alive"

    def test_evict_expired_returns_zero_when_nothing_expired(self):
        cache = TTLCache(default_ttl=600)
        cache.set("fresh", 42)
        assert cache.evict_expired() == 0

    def test_clear_empties_store(self):
        cache = TTLCache()
        cache.set("x", 1)
        cache.set("y", 2)
        cache.clear()
        assert cache.get("x") is None
        assert cache.get("y") is None
        assert len(cache._store) == 0

    def test_overwrite_existing_key(self):
        cache = TTLCache()
        cache.set("k", "v1")
        cache.set("k", "v2")
        assert cache.get("k") == "v2"


# ── Formatting helpers ─────────────────────────────────────────────────────


class TestFmtUsd:
    def test_none_returns_na(self):
        assert _fmt_usd(None) == "N/A"

    def test_trillions(self):
        assert _fmt_usd(2_500_000_000_000) == "$2.50T"

    def test_billions(self):
        assert _fmt_usd(1_230_000_000) == "$1.23B"

    def test_millions(self):
        assert _fmt_usd(45_600_000) == "$45.60M"

    def test_thousands(self):
        assert _fmt_usd(7_890) == "$7.9K"

    def test_small_value(self):
        assert _fmt_usd(42.5) == "$42.50"

    def test_zero(self):
        assert _fmt_usd(0) == "$0.00"

    def test_negative_billions(self):
        assert _fmt_usd(-3_000_000_000) == "-$3.00B"

    def test_negative_thousands(self):
        assert _fmt_usd(-1_500) == "-$1.5K"

    def test_negative_small(self):
        assert _fmt_usd(-99.99) == "-$99.99"

    def test_exact_boundary_thousand(self):
        assert _fmt_usd(1_000) == "$1.0K"

    def test_exact_boundary_million(self):
        assert _fmt_usd(1_000_000) == "$1.00M"

    def test_exact_boundary_billion(self):
        assert _fmt_usd(1_000_000_000) == "$1.00B"

    def test_exact_boundary_trillion(self):
        assert _fmt_usd(1_000_000_000_000) == "$1.00T"


class TestFmtPct:
    def test_none_returns_na(self):
        assert _fmt_pct(None) == "N/A"

    def test_positive(self):
        assert _fmt_pct(5.123) == "+5.12%"

    def test_negative(self):
        assert _fmt_pct(-3.456) == "-3.46%"

    def test_zero(self):
        assert _fmt_pct(0) == "+0.00%"

    def test_large_value(self):
        assert _fmt_pct(100.0) == "+100.00%"


class TestFmtRate:
    def test_none_returns_na(self):
        assert _fmt_rate(None) == "N/A"

    def test_positive_rate(self):
        # 0.01 decimal = 1% funding rate
        assert _fmt_rate(0.01) == "1.0000%"

    def test_small_rate(self):
        # 0.0001 decimal = 0.01%
        assert _fmt_rate(0.0001) == "0.0100%"

    def test_negative_rate(self):
        assert _fmt_rate(-0.005) == "-0.5000%"

    def test_zero_rate(self):
        assert _fmt_rate(0) == "0.0000%"


class TestSafeGet:
    def test_single_level(self):
        assert _safe_get({"a": 1}, "a") == 1

    def test_nested(self):
        d = {"a": {"b": {"c": 42}}}
        assert _safe_get(d, "a", "b", "c") == 42

    def test_missing_key_returns_default(self):
        assert _safe_get({"a": 1}, "b") is None

    def test_missing_nested_key(self):
        assert _safe_get({"a": {"b": 1}}, "a", "x") is None

    def test_custom_default(self):
        assert _safe_get({}, "a", default="fallback") == "fallback"

    def test_non_dict_intermediate(self):
        d = {"a": "not_a_dict"}
        assert _safe_get(d, "a", "b") is None

    def test_none_input(self):
        assert _safe_get(None, "a") is None

    def test_empty_keys(self):
        d = {"a": 1}
        assert _safe_get(d) == d


# ── call_api ───────────────────────────────────────────────────────────────


class TestCallApi:
    async def test_successful_api_call(self):
        """Successful response returns parsed JSON data."""
        mock_client = AsyncMock()
        mock_client.get.return_value = _make_response(
            json_data={"price": 60_000}
        )
        ctx = _make_mock_ctx(mock_client)

        result = await call_api(ctx, "/v1/test", "/api/test")

        assert result == {"price": 60_000}
        mock_client.get.assert_awaited_once()

    async def test_envelope_unwrapping(self):
        """Responses with {data, meta} envelope are unwrapped."""
        payload = [{"coin": "BTC"}, {"coin": "ETH"}]
        mock_client = AsyncMock()
        mock_client.get.return_value = _make_response(
            json_data={"data": payload, "meta": {"page": 1}}
        )
        ctx = _make_mock_ctx(mock_client)

        result = await call_api(ctx, "/v1/test", "/api/test")

        assert result == payload

    async def test_caching_second_call_returns_cached(self):
        """Second call with the same path+params hits cache, not the network."""
        mock_client = AsyncMock()
        mock_client.get.return_value = _make_response(json_data={"ok": True})
        ctx = _make_mock_ctx(mock_client)

        first = await call_api(ctx, "/v1/cached", "/api/cached", {"a": "1"})
        second = await call_api(ctx, "/v1/cached", "/api/cached", {"a": "1"})

        assert first == second == {"ok": True}
        # Only one HTTP call should have been made
        assert mock_client.get.await_count == 1

    async def test_different_params_are_separate_cache_entries(self):
        """Different params produce different cache keys."""
        mock_client = AsyncMock()
        mock_client.get.return_value = _make_response(json_data={"v": 1})
        ctx = _make_mock_ctx(mock_client)

        await call_api(ctx, "/v1/x", "/api/x", {"coin": "BTC"})
        await call_api(ctx, "/v1/x", "/api/x", {"coin": "ETH"})

        assert mock_client.get.await_count == 2

    async def test_timeout_returns_error_string(self):
        """Timeout exceptions return a descriptive error string."""
        mock_client = AsyncMock()
        mock_client.get.side_effect = httpx.TimeoutException("timed out")
        ctx = _make_mock_ctx(mock_client)

        result = await call_api(ctx, "/v1/slow", "/api/slow")

        assert isinstance(result, str)
        assert "timed out" in result
        assert "/v1/slow" in result

    async def test_http_error_returns_error_string(self):
        """Generic HTTP errors return a descriptive error string."""
        mock_client = AsyncMock()
        mock_client.get.side_effect = httpx.HTTPError("connection reset")
        ctx = _make_mock_ctx(mock_client)

        result = await call_api(ctx, "/v1/fail", "/api/fail")

        assert isinstance(result, str)
        assert "HTTP error" in result

    async def test_non_200_status_returns_error_string(self):
        """Non-200 responses return status code and truncated body."""
        mock_client = AsyncMock()
        mock_client.get.return_value = _make_response(
            status_code=429, text="rate limited"
        )
        ctx = _make_mock_ctx(mock_client)

        result = await call_api(ctx, "/v1/limited", "/api/limited")

        assert isinstance(result, str)
        assert "429" in result
        assert "rate limited" in result

    async def test_data_truncation_at_max_items(self):
        """Arrays exceeding MAX_ITEMS are truncated with metadata."""
        big_list = [{"i": i} for i in range(MAX_ITEMS + 50)]
        mock_client = AsyncMock()
        mock_client.get.return_value = _make_response(json_data=big_list)
        ctx = _make_mock_ctx(mock_client)

        result = await call_api(ctx, "/v1/big", "/api/big")

        assert isinstance(result, dict)
        assert result["truncated"] is True
        assert result["total"] == MAX_ITEMS + 50
        assert result["showing"] == MAX_ITEMS
        assert len(result["items"]) == MAX_ITEMS

    async def test_list_under_max_items_not_truncated(self):
        """Arrays under MAX_ITEMS are returned as-is."""
        small_list = [{"i": i} for i in range(10)]
        mock_client = AsyncMock()
        mock_client.get.return_value = _make_response(json_data=small_list)
        ctx = _make_mock_ctx(mock_client)

        result = await call_api(ctx, "/v1/small", "/api/small")

        assert isinstance(result, list)
        assert len(result) == 10

    async def test_filter_fn_runs_before_truncation(self):
        """filter_fn must run before MAX_ITEMS cap so target rows beyond
        the first MAX_ITEMS positions aren't silently dropped."""
        # 210 rows -- under normal truncation BTC rows would never be seen
        # because they only appear at the tail.
        rows = [{"base_coin": f"C{i:03d}"} for i in range(MAX_ITEMS)] + [
            {"base_coin": "BTC"} for _ in range(10)
        ]
        mock_client = AsyncMock()
        mock_client.get.return_value = _make_response(json_data=rows)
        ctx = _make_mock_ctx(mock_client)

        result = await call_api(
            ctx, "/v1/funding", "/api/funding",
            filter_fn=lambda r: r.get("base_coin") == "BTC",
        )

        assert isinstance(result, list)
        assert len(result) == 10
        assert all(r["base_coin"] == "BTC" for r in result)

    async def test_filter_fn_ignored_for_dict_responses(self):
        """filter_fn only applies to list payloads; dicts pass through."""
        mock_client = AsyncMock()
        mock_client.get.return_value = _make_response(json_data={"price": 42})
        ctx = _make_mock_ctx(mock_client)

        result = await call_api(
            ctx, "/v1/x", "/api/x",
            filter_fn=lambda r: False,  # would reject everything if applied
        )

        assert result == {"price": 42}

    @patch("server.API_KEY", "test-key-123")
    @patch("server.API_BASE", "https://api.test.com")
    async def test_uses_v1_path_with_api_key(self):
        """When API_KEY is set, requests go to API_BASE/v1_path with Bearer auth."""
        mock_client = AsyncMock()
        mock_client.get.return_value = _make_response(json_data={})
        ctx = _make_mock_ctx(mock_client)

        await call_api(ctx, "/v1/test", "/api/test")

        call_args = mock_client.get.call_args
        assert call_args[0][0] == "https://api.test.com/v1/test"
        assert call_args[1]["headers"]["Authorization"] == "Bearer test-key-123"

    @patch("server.API_KEY", "")
    @patch("server.FREE_BASE", "https://free.test.com")
    async def test_uses_free_path_without_api_key(self):
        """When API_KEY is empty, requests go to FREE_BASE/free_path with no auth."""
        mock_client = AsyncMock()
        mock_client.get.return_value = _make_response(json_data={})
        ctx = _make_mock_ctx(mock_client)

        await call_api(ctx, "/v1/test", "/api/test")

        call_args = mock_client.get.call_args
        assert call_args[0][0] == "https://free.test.com/api/test"
        assert call_args[1]["headers"] == {}

    async def test_none_params_excluded_from_request(self):
        """Parameters with None values are filtered out before sending."""
        mock_client = AsyncMock()
        mock_client.get.return_value = _make_response(json_data={})
        ctx = _make_mock_ctx(mock_client)

        await call_api(ctx, "/v1/test", "/api/test", {"coin": "BTC", "extra": None})

        call_args = mock_client.get.call_args
        assert call_args[1]["params"] == {"coin": "BTC"}

    async def test_error_responses_are_not_cached(self):
        """Error strings from failed calls should not pollute the cache."""
        mock_client = AsyncMock()
        mock_client.get.side_effect = httpx.TimeoutException("timeout")
        ctx = _make_mock_ctx(mock_client)

        result1 = await call_api(ctx, "/v1/flaky", "/api/flaky")
        assert "timed out" in result1

        # Now make it succeed
        mock_client.get.side_effect = None
        mock_client.get.return_value = _make_response(json_data={"ok": True})

        result2 = await call_api(ctx, "/v1/flaky", "/api/flaky")
        assert result2 == {"ok": True}


# ── _safe_call ─────────────────────────────────────────────────────────────


class TestSafeCall:
    async def test_success_returns_data_and_no_error(self):
        """On success, returns (data, None)."""
        mock_client = AsyncMock()
        mock_client.get.return_value = _make_response(
            json_data={"funding": 0.01}
        )
        ctx = _make_mock_ctx(mock_client)

        data, err = await _safe_call(ctx, "/v1/ok", "/api/ok")

        assert data == {"funding": 0.01}
        assert err is None

    async def test_timeout_returns_none_and_error(self):
        """On timeout, returns (None, error_message)."""
        mock_client = AsyncMock()
        mock_client.get.side_effect = httpx.TimeoutException("timeout")
        ctx = _make_mock_ctx(mock_client)

        data, err = await _safe_call(ctx, "/v1/slow", "/api/slow")

        assert data is None
        assert err is not None
        assert "timed out" in err

    async def test_http_error_returns_none_and_error(self):
        """On HTTP error, returns (None, error_message)."""
        mock_client = AsyncMock()
        mock_client.get.side_effect = httpx.HTTPError("reset")
        ctx = _make_mock_ctx(mock_client)

        data, err = await _safe_call(ctx, "/v1/err", "/api/err")

        assert data is None
        assert "HTTP error" in err

    async def test_non_200_returns_none_and_error(self):
        """Non-200 status returns (None, error_message)."""
        mock_client = AsyncMock()
        mock_client.get.return_value = _make_response(
            status_code=500, text="internal error"
        )
        ctx = _make_mock_ctx(mock_client)

        data, err = await _safe_call(ctx, "/v1/500", "/api/500")

        assert data is None
        assert "500" in err

    async def test_label_appears_in_error(self):
        """The custom label is used in error messages instead of the path."""
        mock_client = AsyncMock()
        mock_client.get.side_effect = httpx.TimeoutException("timeout")
        ctx = _make_mock_ctx(mock_client)

        _, err = await _safe_call(
            ctx, "/v1/x", "/api/x", label="FundingRates"
        )

        assert "[FundingRates]" in err

    async def test_label_defaults_to_path(self):
        """Without a label, the v1 path is used in error messages."""
        mock_client = AsyncMock()
        mock_client.get.side_effect = httpx.TimeoutException("timeout")
        ctx = _make_mock_ctx(mock_client)

        _, err = await _safe_call(ctx, "/v1/my-endpoint", "/api/my-endpoint")

        assert "[/v1/my-endpoint]" in err


# ── Resources ──────────────────────────────────────────────────────────────


class TestResources:
    """Test the resource data constants. The @mcp.resource() decorator wraps
    these into FunctionResource objects, so we test the underlying data
    directly and verify it round-trips through JSON (what the resources return)."""

    def test_futures_charts_serializes_to_valid_json(self):
        result = json.loads(json.dumps(FUTURES_CHARTS))
        assert isinstance(result, list)
        assert len(result) == 19

    def test_futures_charts_entries_have_id_and_description(self):
        for entry in FUTURES_CHARTS:
            assert "id" in entry
            assert "description" in entry

    def test_futures_charts_known_ids_present(self):
        ids = {e["id"] for e in FUTURES_CHARTS}
        for expected in ["perpetual-price", "liquidations", "oi-stacked",
                         "funding-rate", "annualized-basis", "term-structure"]:
            assert expected in ids

    def test_options_charts_serializes_to_valid_json(self):
        result = json.loads(json.dumps(OPTIONS_CHARTS))
        assert isinstance(result, list)
        assert len(result) == 22

    def test_options_charts_entries_have_id_and_description(self):
        for entry in OPTIONS_CHARTS:
            assert "id" in entry
            assert "description" in entry

    def test_options_charts_known_ids_present(self):
        ids = {e["id"] for e in OPTIONS_CHARTS}
        for expected in ["atm-iv", "vol-smile", "gex", "vol-cones",
                         "put-call-oi-ratio", "max-pain"]:
            assert expected in ids

    def test_exchanges_serializes_to_valid_json(self):
        result = json.loads(json.dumps(EXCHANGES_DATA))
        assert isinstance(result, dict)
        assert "funding_rates" in result
        assert "futures" in result
        assert "options" in result

    def test_exchanges_funding_rates_is_list_of_13(self):
        assert isinstance(EXCHANGES_DATA["funding_rates"], list)
        assert len(EXCHANGES_DATA["funding_rates"]) == 13

    def test_exchanges_futures_has_default_and_extra(self):
        assert "default" in EXCHANGES_DATA["futures"]
        assert "extra" in EXCHANGES_DATA["futures"]

    def test_narratives_returns_22_entries(self):
        result = json.loads(json.dumps(NARRATIVE_SLUGS))
        assert isinstance(result, list)
        assert len(result) == 22

    def test_narratives_entries_have_slug_and_name(self):
        for entry in NARRATIVE_SLUGS:
            assert "slug" in entry
            assert "name" in entry

    def test_narratives_known_slugs_present(self):
        slugs = {e["slug"] for e in NARRATIVE_SLUGS}
        for expected in ["layer-1", "defi", "ai-agents", "memes", "rwa"]:
            assert expected in slugs

    def test_ecosystems_returns_23_entries(self):
        result = json.loads(json.dumps(ECOSYSTEM_SLUGS))
        assert isinstance(result, list)
        assert len(result) == 23

    def test_ecosystems_entries_have_slug_and_name(self):
        for entry in ECOSYSTEM_SLUGS:
            assert "slug" in entry
            assert "name" in entry

    def test_ecosystems_known_slugs_present(self):
        slugs = {e["slug"] for e in ECOSYSTEM_SLUGS}
        for expected in ["ethereum", "solana", "bitcoin", "arbitrum", "base"]:
            assert expected in slugs

    def test_ecosystems_some_have_native_token(self):
        tokens = [e.get("native_token") for e in ECOSYSTEM_SLUGS if "native_token" in e]
        assert "ETH" in tokens
        assert "SOL" in tokens
        assert "BTC" in tokens


# ── Data constants sanity checks ───────────────────────────────────────────


class TestDataConstants:
    def test_max_items_is_200(self):
        assert MAX_ITEMS == 200

    def test_futures_chart_ids_are_unique(self):
        ids = [c["id"] for c in FUTURES_CHARTS]
        assert len(ids) == len(set(ids))

    def test_options_chart_ids_are_unique(self):
        ids = [c["id"] for c in OPTIONS_CHARTS]
        assert len(ids) == len(set(ids))

    def test_narrative_slugs_are_unique(self):
        slugs = [n["slug"] for n in NARRATIVE_SLUGS]
        assert len(slugs) == len(set(slugs))

    def test_ecosystem_slugs_are_unique(self):
        slugs = [e["slug"] for e in ECOSYSTEM_SLUGS]
        assert len(slugs) == len(set(slugs))
