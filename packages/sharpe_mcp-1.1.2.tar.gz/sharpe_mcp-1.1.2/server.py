"""
Sharpe MCP Server — crypto derivatives and market data for AI agents.

Exposes 21 tools (18 data + 3 composite), 5 resources, and 2 prompts
covering funding rates, futures, options, arbitrage, narratives,
ecosystems, memecoins, and more. Works with Claude Desktop, Cursor,
and any MCP-compatible client.

Dual mode: uses authenticated /v1/ endpoints when SHARPE_API_KEY is set,
falls back to free /api/ endpoints without one.
"""

import os
import time
import json
from contextlib import asynccontextmanager
from typing import Annotated, Any, Callable, Dict, List, Literal, Optional, Tuple, Union

import httpx
from fastmcp import Context, FastMCP
from pydantic import Field

# ── Configuration ────────────────────────────────────────────────────────

API_KEY = os.getenv("SHARPE_API_KEY", "")
API_BASE = os.getenv("SHARPE_API_URL", "https://api.sharpe.ai")
FREE_BASE = os.getenv("SHARPE_FREE_URL", "https://www.sharpe.ai")
TIMEOUT = 30.0

# Max items to return to the LLM to avoid blowing up context
MAX_ITEMS = 200

# Cache TTL in seconds
CACHE_TTL = 300  # 5 minutes


# ── In-memory TTL Cache ─────────────────────────────────────────────────

class TTLCache:
    """Simple in-memory cache with per-entry TTL. No external dependencies."""

    def __init__(self, default_ttl: int = CACHE_TTL) -> None:
        self._store: Dict[str, Tuple[float, Any]] = {}
        self._default_ttl = default_ttl

    def get(self, key: str) -> Optional[Any]:
        entry = self._store.get(key)
        if entry is None:
            return None
        expires_at, value = entry
        if time.monotonic() > expires_at:
            del self._store[key]
            return None
        return value

    def set(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        expires_at = time.monotonic() + (ttl if ttl is not None else self._default_ttl)
        self._store[key] = (expires_at, value)

    def clear(self) -> None:
        self._store.clear()

    def evict_expired(self) -> int:
        """Remove all expired entries. Returns count of evicted items."""
        now = time.monotonic()
        expired = [k for k, (exp, _) in self._store.items() if now > exp]
        for k in expired:
            del self._store[k]
        return len(expired)


_cache = TTLCache()


# ── Lifespan (proper resource management) ────────────────────────────────


@asynccontextmanager
async def app_lifespan(server: FastMCP):
    """Initialize and clean up the shared HTTP client."""
    client = httpx.AsyncClient(timeout=TIMEOUT)
    try:
        yield {"http_client": client}
    finally:
        _cache.clear()
        await client.aclose()


# ── Server ──────────────────────────────────────────────────────────────

mcp = FastMCP(
    "Sharpe",
    instructions=(
        "Sharpe provides institutional-grade crypto derivatives and market data "
        "across 20+ exchanges with real-time and near-real-time updates.\n\n"
        "Workflow patterns:\n"
        "- Quick market check: get_market_overview\n"
        "- Coin analysis: analyze_coin (or get_funding_rates -> get_futures_data -> get_options_data)\n"
        "- Derivatives health: get_derivatives_overview -> get_futures_data\n"
        "- Sector rotation: get_narratives -> get_ecosystems\n"
        "- Arbitrage scan: find_opportunities (or get_arbitrage_spot_perp + get_arbitrage_cross_exchange)\n"
        "- Full briefing: market_briefing\n"
        "- Memecoin analysis: get_memecoins\n"
        "- Token discovery: get_gem_finder\n\n"
        "Always start with get_market_overview or market_briefing for general questions.\n"
        "Use analyze_coin for questions about a specific coin.\n"
        "Use get_api_coverage to discover available chart types before querying specific charts.\n"
        "Use resources (sharpe://charts/futures, sharpe://charts/options, etc.) for valid IDs.\n\n"
        "Data freshness: funding rates update every 1-8 hours per exchange, "
        "futures/options snapshots every 5-10 minutes, narratives/ecosystems every 30 minutes."
    ),
    lifespan=app_lifespan,
)


# ── API Client ───────────────────────────────────────────────────────────


def _cache_key(v1_path: str, params: Optional[dict]) -> str:
    """Build a deterministic cache key from path and sorted params."""
    sorted_params = sorted((params or {}).items())
    return f"{v1_path}|{sorted_params}"


async def call_api(
    ctx: Context,
    v1_path: str,
    free_path: str,
    params: Optional[dict] = None,
    filter_fn: Optional[Callable[[dict], bool]] = None,
) -> Union[dict, list, str]:
    """Call the Sharpe API with in-memory caching (5 min TTL).

    Uses v1 with auth if SHARPE_API_KEY is set, otherwise free endpoints.
    Returns the unwrapped data payload. On error, returns an error string.

    `filter_fn` runs after envelope-unwrap but before the MAX_ITEMS cap, so a
    tool that wants a subset (e.g. rows for one coin) can discard irrelevant
    rows before the truncation kicks in -- otherwise the target rows might
    already have been dropped.
    """
    clean_params = {k: v for k, v in (params or {}).items() if v is not None}
    key = _cache_key(v1_path, clean_params)

    # Check cache first
    cached = _cache.get(key)
    if cached is not None:
        return cached

    client: httpx.AsyncClient = ctx.request_context.lifespan_context["http_client"]

    if API_KEY:
        url = f"{API_BASE}{v1_path}"
        headers = {"Authorization": f"Bearer {API_KEY}"}
    else:
        url = f"{FREE_BASE}{free_path}"
        headers = {}

    try:
        resp = await client.get(
            url, params=clean_params, headers=headers, follow_redirects=True
        )
    except httpx.TimeoutException:
        return f"Request to {v1_path} timed out after {TIMEOUT}s. Try again or use a narrower query."
    except httpx.HTTPError as e:
        return f"HTTP error calling {v1_path}: {e}"

    if resp.status_code != 200:
        body = resp.text[:300]
        return f"Sharpe API returned {resp.status_code} for {v1_path}: {body}"

    data = resp.json()

    # Unwrap the { data, meta } envelope if present
    if isinstance(data, dict) and "data" in data and "meta" in data:
        data = data["data"]

    if filter_fn is not None and isinstance(data, list):
        data = [row for row in data if isinstance(row, dict) and filter_fn(row)]

    # Cap large arrays to avoid blowing up LLM context
    if isinstance(data, list) and len(data) > MAX_ITEMS:
        total = len(data)
        data = data[:MAX_ITEMS]
        result = {"items": data, "truncated": True, "total": total, "showing": MAX_ITEMS}
        _cache.set(key, result)
        return result

    _cache.set(key, data)
    return data


async def _safe_call(
    ctx: Context,
    v1_path: str,
    free_path: str,
    params: Optional[dict] = None,
    label: Optional[str] = None,
) -> Tuple[Optional[Any], Optional[str]]:
    """Call the API and return (data, None) on success or (None, error_msg) on failure.

    Used by composite tools for graceful degradation — failures are noted
    but do not prevent other data from being returned.
    """
    result = await call_api(ctx, v1_path, free_path, params)
    if isinstance(result, str) and (
        "timed out" in result
        or "HTTP error" in result
        or "returned" in result
    ):
        tag = label or v1_path
        return None, f"[{tag}] {result}"
    return result, None


# ── Constrained types ────────────────────────────────────────────────────

FuturesChart = Literal[
    "perpetual-price", "liquidations", "oi-stacked", "oi-change",
    "oi-daily-change", "oi-snapshot", "oi-volume", "volume-history",
    "volume-snapshot", "cvd", "long-short-ratio", "top-trader-ls",
    "returns-session", "returns-heatmap", "returns-hour", "returns-day",
    "funding-rate", "annualized-basis", "term-structure",
]

OptionsChart = Literal[
    "atm-iv", "iv-term-structure", "vol-smile", "vol-surface", "vol-skew",
    "term-structure-slope", "spot-vol-correlation", "oi-by-strike",
    "oi-by-expiry", "put-call-oi-ratio", "max-pain", "top-volume",
    "put-call-volume-ratio", "options-flow", "exchange-volume",
    "realized-vol", "iv-vs-rv", "zscore-iv", "zscore-rv", "zscore-iv-rv",
    "gex", "vol-cones",
]

FundingType = Literal["current", "accumulated", "history"]
FuturesTimeframe = Literal["1W", "2W", "1M", "3M", "6M", "1Y", "3Y"]
OptionsTimeframe = Literal["1W", "1M", "3M", "6M", "1Y", "3Y", "ALL"]
CorrelationPeriod = Literal["30d", "90d", "1y", "3y"]
HeatmapMode = Literal["coins", "narratives", "ecosystems"]
ArbitrageDirection = Literal["all", "long", "short"]
MemecoinHistorical = Literal["24h", "7d"]


# ── Formatting helpers ───────────────────────────────────────────────────


def _fmt_usd(value: Optional[float]) -> str:
    """Format a number as USD with appropriate suffix (K/M/B/T)."""
    if value is None:
        return "N/A"
    abs_v = abs(value)
    sign = "-" if value < 0 else ""
    if abs_v >= 1_000_000_000_000:
        return f"{sign}${abs_v / 1_000_000_000_000:.2f}T"
    if abs_v >= 1_000_000_000:
        return f"{sign}${abs_v / 1_000_000_000:.2f}B"
    if abs_v >= 1_000_000:
        return f"{sign}${abs_v / 1_000_000:.2f}M"
    if abs_v >= 1_000:
        return f"{sign}${abs_v / 1_000:.1f}K"
    return f"{sign}${abs_v:,.2f}"


def _fmt_pct(value: Optional[float]) -> str:
    """Format as percentage string."""
    if value is None:
        return "N/A"
    return f"{value:+.2f}%"


def _fmt_rate(value: Optional[float]) -> str:
    """Format a funding rate (decimal) as percentage."""
    if value is None:
        return "N/A"
    return f"{value * 100:.4f}%"


def _safe_get(d: Any, *keys: str, default: Any = None) -> Any:
    """Safely traverse nested dicts."""
    current = d
    for k in keys:
        if isinstance(current, dict):
            current = current.get(k, default)
        else:
            return default
    return current


# ── Tools: Data (18 existing) ────────────────────────────────────────────


@mcp.tool()
async def get_funding_rates(
    ctx: Context,
    type: Annotated[FundingType, Field(description="'current' = live snapshot across all coins and exchanges, 'accumulated' = cumulative rates over 7d/30d/90d/1y windows, 'history' = per-coin time-series (requires coin param)")] = "current",
    coin: Annotated[Optional[str], Field(description="Base coin ticker (e.g. BTC, ETH, SOL). Filters results to this base coin across all exchanges. Required for type='history'; optional for 'current' and 'accumulated'.")] = None,
    days: Annotated[int, Field(ge=1, le=1095, description="Lookback days for history mode only. Range 1-1095. Default 30.")] = 30,
) -> Union[dict, list, str]:
    """Get perpetual funding rates across 13 exchanges (Binance, Bybit, OKX, Deribit, Hyperliquid, etc.).

    Use this when you need to check current funding rates, compare rates across exchanges,
    or analyze funding rate history for a specific coin.
    Do NOT use this for futures open interest, volume, or liquidation data — use get_futures_data instead.

    Returns: exchange, symbol, rate (decimal, 0.01 = 1%), interval_hours, settlement time.
    Positive rate = longs pay shorts. Negative = shorts pay longs.
    """
    params: dict = {"type": type}
    if coin:
        params["coin"] = coin.upper()
    if type == "history":
        params["days"] = str(days)

    # The free /api/funding/rates endpoint ignores the `coin` param for
    # current/accumulated modes, returning all symbols. Filter client-side
    # so AI agents asking "BTC funding" actually get only BTC rows (and
    # so rows aren't lost to the MAX_ITEMS truncation in call_api).
    filter_fn: Optional[Callable[[dict], bool]] = None
    if coin and type != "history":
        needle = coin.upper()
        filter_fn = lambda row: str(row.get("base_coin", "")).upper() == needle

    return await call_api(
        ctx, "/v1/funding/rates", "/api/funding/rates", params, filter_fn=filter_fn
    )


@mcp.tool()
async def get_futures_data(
    ctx: Context,
    chart: Annotated[FuturesChart, Field(description="Chart type. See sharpe://charts/futures resource for all 19 valid IDs and descriptions.")],
    coin: Annotated[str, Field(description="Base coin ticker (e.g. BTC, ETH, SOL)")] = "BTC",
    timeframe: Annotated[FuturesTimeframe, Field(description="Lookback window: 1W, 2W, 1M, 3M, 6M, 1Y, or 3Y")] = "3M",
    exchanges: Annotated[Optional[str], Field(description="Comma-separated exchange filter (e.g. 'Binance,Bybit,OKX'). Omit for all default exchanges.")] = None,
) -> Union[dict, list, str]:
    """Get futures chart data: open interest, volume, liquidations, long/short ratios, funding, basis, and more.

    Use this when you need time-series or snapshot data for a specific futures chart type and coin.
    Do NOT use this for options data (use get_options_data) or for a quick derivatives overview
    (use get_derivatives_overview).

    Returns: time-series arrays or snapshot data depending on chart type. Each point has
    timestamp + value per exchange. Common charts: oi-stacked, liquidations, long-short-ratio,
    funding-rate, annualized-basis, term-structure.
    """
    params = {"chart": chart, "coin": coin.upper(), "timeframe": timeframe}
    if exchanges:
        params["exchanges"] = exchanges
    return await call_api(ctx, "/v1/futures/data", "/api/futures/data", params)


@mcp.tool()
async def get_futures_coins(ctx: Context) -> Union[dict, list, str]:
    """Get the list of coins with futures data available, including per-coin capability flags.

    Use this when you need to check which coins have futures data or which chart types
    are supported for a given coin before calling get_futures_data.
    Do NOT use this for options coins (only BTC/ETH/SOL) or for actual chart data.

    Returns: ticker, display name, and flags: hasOI, hasLiquidations, hasLongShort per coin.
    """
    return await call_api(ctx, "/v1/futures/coins", "/api/futures/coins")


@mcp.tool()
async def get_options_data(
    ctx: Context,
    chart: Annotated[OptionsChart, Field(description="Chart type. See sharpe://charts/options resource for all 22 valid IDs and descriptions.")],
    coin: Annotated[str, Field(description="One of BTC, ETH, SOL")] = "BTC",
    timeframe: Annotated[OptionsTimeframe, Field(description="Lookback window: 1W, 1M, 3M, 6M, 1Y, 3Y, or ALL")] = "3M",
    exchanges: Annotated[Optional[str], Field(description="Comma-separated exchange filter (e.g. 'Deribit,OKX'). Omit for all.")] = None,
) -> Union[dict, list, str]:
    """Get options analytics for BTC, ETH, and SOL: implied volatility, Greeks, OI, volume, and more.

    Use this when you need options-specific data like ATM IV, vol smile, GEX, put/call ratios,
    or volatility cones for a specific coin.
    Do NOT use this for futures data (use get_futures_data) or funding rates (use get_funding_rates).

    Returns: time-series or snapshot data depending on chart type. Key charts: atm-iv (ATM implied
    vol over time), vol-smile (IV by strike), oi-by-strike, put-call-oi-ratio, gex, vol-cones.
    Exchanges: Deribit (primary), OKX, Binance.
    """
    params = {"chart": chart, "coin": coin.upper(), "timeframe": timeframe}
    if exchanges:
        params["exchanges"] = exchanges
    return await call_api(ctx, "/v1/options/data", "/api/options/data", params)


@mcp.tool()
async def get_correlation_matrix(
    ctx: Context,
    period: Annotated[CorrelationPeriod, Field(description="Lookback period for correlation calculation: 30d, 90d, 1y, or 3y")] = "30d",
    ids: Annotated[Optional[str], Field(description="Comma-separated asset IDs. Crypto: CoinGecko IDs (bitcoin, ethereum). TradFi: short IDs (sp500, gold, nvda). Max 10.")] = None,
) -> Union[dict, list, str]:
    """Get a Pearson correlation matrix for crypto and TradFi assets over a given period.

    Use this when you need to analyze how assets move relative to each other for portfolio
    diversification, risk management, or cross-asset relationship analysis.
    Do NOT use this for price data or market performance — use get_market_overview instead.

    Returns: NxN correlation matrix with values between -1 and +1. Default set: bitcoin,
    ethereum, solana, sp500, gold. Max 10 assets per query.
    """
    params: dict = {"period": period}
    if ids:
        params["ids"] = ids
    return await call_api(ctx, "/v1/correlation/matrix", "/api/correlation/matrix", params)


@mcp.tool()
async def get_arbitrage_spot_perp(
    ctx: Context,
    exchange: Annotated[str, Field(description="Exchange name (e.g. 'Binance', 'Bybit') or 'all' for all exchanges")] = "all",
    direction: Annotated[ArbitrageDirection, Field(description="Trade direction: 'all', 'long' (positive funding), or 'short' (negative funding)")] = "all",
) -> Union[dict, list, str]:
    """Get spot-perp basis trade opportunities: long spot + short perp (or vice versa) to capture funding.

    Use this when looking for cash-and-carry or reverse cash-and-carry arbitrage trades
    based on funding rate differentials between spot and perpetual futures.
    Do NOT use this for cross-exchange arb (use get_arbitrage_cross_exchange) or for
    raw funding rates (use get_funding_rates).

    Returns: symbol, exchange, funding rate, annualized APR, direction, and estimated PnL.
    Sorted by APR descending.
    """
    params = {"exchange": exchange, "direction": direction}
    return await call_api(ctx, "/v1/arbitrage/spot-perp", "/api/arbitrage/spot-perp", params)


@mcp.tool()
async def get_arbitrage_cross_exchange(
    ctx: Context,
    exchanges: Annotated[Optional[str], Field(description="Comma-separated exchanges to compare (e.g. 'Binance,Bybit'). Omit for all.")] = None,
) -> Union[dict, list, str]:
    """Get cross-exchange funding rate arbitrage: long where funding is negative, short where positive.

    Use this when looking for exchange-to-exchange arbitrage opportunities where the same
    coin has significantly different funding rates on different exchanges.
    Do NOT use this for spot-perp basis trades (use get_arbitrage_spot_perp) or for
    single-exchange funding rates (use get_funding_rates).

    Returns: symbol, long_exchange, short_exchange, spread rate, annualized APR.
    Sorted by spread descending.
    """
    params: dict = {}
    if exchanges:
        params["exchanges"] = exchanges
    return await call_api(ctx, "/v1/arbitrage/cross-exchange", "/api/arbitrage/cross-exchange", params)


@mcp.tool()
async def get_heatmap(
    ctx: Context,
    mode: Annotated[HeatmapMode, Field(description="Grouping: 'coins' for individual tokens, 'narratives' for sector grouping, 'ecosystems' for chain grouping")] = "coins",
    category: Annotated[str, Field(description="Category slug (e.g. 'top-100', 'decentralized-finance-defi', 'layer-1', 'meme-token', 'ethereum-ecosystem')")] = "top-100",
) -> Union[dict, list, str]:
    """Get market heatmap data: tokens sized by market cap and colored by price performance.

    Use this when you need a visual overview of market performance across sectors, chains,
    or the top 100 coins by market cap.
    Do NOT use this for detailed time-series data — use get_futures_data or get_narratives instead.

    Returns: token name, symbol, market_cap, price, and performance (24h/7d/30d/1y) per entry.
    49 categories available including top-100, defi, layer-1, meme-token, ai, and chain ecosystems.
    """
    params = {"mode": mode, "category": category}
    return await call_api(ctx, "/v1/heatmap/data", "/api/heatmap/data", params)


@mcp.tool()
async def get_narratives(
    ctx: Context,
    narrative: Annotated[Optional[str], Field(description="Narrative slug for detail view (e.g. 'defi', 'ai-agents', 'rwa', 'layer-1'). See sharpe://narratives resource for all 22 slugs.")] = None,
    correlation: Annotated[Optional[str], Field(description="Set to 'true' to include correlation matrix for the narrative's tokens")] = None,
    timeframe: Annotated[Optional[str], Field(description="Timeframe for correlation data (e.g. '30d', '90d')")] = None,
) -> Union[dict, list, str]:
    """Get analytics for 22 crypto narratives: L1, L2, DeFi, AI Agents, DePIN, RWA, Gaming, and more.

    Use this when analyzing sector rotation, comparing narrative performance, or getting
    the top coins within a specific narrative/sector.
    Do NOT use this for ecosystem/chain-level data (use get_ecosystems) or memecoin
    narratives (use get_memecoins).

    Returns: market_cap, volume, 24h/7d/30d performance, social sentiment, derivatives
    positioning per narrative. Detail view includes top coins with individual metrics.
    """
    params: dict = {}
    if narrative:
        params["narrative"] = narrative
    if correlation:
        params["correlation"] = correlation
    if timeframe:
        params["timeframe"] = timeframe
    return await call_api(ctx, "/v1/narratives/data", "/api/narratives/data", params)


@mcp.tool()
async def get_ecosystems(
    ctx: Context,
    ecosystem: Annotated[Optional[str], Field(description="Ecosystem slug (e.g. 'ethereum', 'solana', 'arbitrum', 'base'). See sharpe://ecosystems resource for all 23 slugs.")] = None,
    exclude_native: Annotated[Optional[str], Field(description="Set to 'true' to exclude the chain's native token from aggregate metrics")] = None,
    correlation: Annotated[Optional[str], Field(description="Set to 'true' for token correlation matrix within the ecosystem")] = None,
    timeframe: Annotated[Optional[str], Field(description="Timeframe for correlation data (e.g. '30d', '90d')")] = None,
) -> Union[dict, list, str]:
    """Get analytics for 23 blockchain ecosystems: Ethereum, Solana, BNB, Arbitrum, Base, and more.

    Use this when comparing chain ecosystems by TVL, market cap, volume, or performance,
    or when drilling into the top tokens within a specific chain.
    Do NOT use this for narrative/sector analysis (use get_narratives) or for memecoin
    data (use get_memecoins).

    Returns: market_cap, volume, TVL, 24h/7d/30d performance per ecosystem. Detail view
    includes top coins. Use exclude_native='true' to see ecosystem health without the L1 token.
    """
    params: dict = {}
    if ecosystem:
        params["ecosystem"] = ecosystem
    if exclude_native:
        params["excludeNative"] = exclude_native
    if correlation:
        params["correlation"] = correlation
    if timeframe:
        params["timeframe"] = timeframe
    return await call_api(ctx, "/v1/ecosystems/data", "/api/ecosystems/data", params)


@mcp.tool()
async def get_memecoins(
    ctx: Context,
    narrative: Annotated[Optional[str], Field(description="Memecoin narrative slug (e.g. 'dog-coins', 'ai-meme', 'political', 'cat-coins')")] = None,
    historical: Annotated[Optional[MemecoinHistorical], Field(description="Include time-series snapshots: '24h' or '7d' for trend analysis")] = None,
) -> Union[dict, list, str]:
    """Get memecoin narrative data across 17 curated categories: Dog, Cat, Frog, AI, Political, and more.

    Use this when analyzing memecoin sectors, comparing memecoin narrative momentum,
    or identifying trending memecoin themes.
    Do NOT use this for non-meme crypto narratives (use get_narratives) or for
    individual token lookup (use search_market_cap).

    Returns: market_cap, volume, dominance, momentum score, and top coins per narrative.
    Set historical='24h' or '7d' to see time-series snapshots for momentum trend analysis.
    """
    params: dict = {}
    if narrative:
        params["narrative"] = narrative
    if historical:
        params["historical"] = historical
    return await call_api(ctx, "/v1/memecoins/data", "/api/memecoins/data", params)


@mcp.tool()
async def get_news(
    ctx: Context,
    limit: Annotated[int, Field(ge=1, le=500, description="Number of articles to return (1-500). Default 50.")] = 50,
    category: Annotated[Optional[str], Field(description="Filter by category (e.g. 'defi', 'regulation', 'nft', 'bitcoin')")] = None,
    coin: Annotated[Optional[str], Field(description="Filter by coin ticker (e.g. 'BTC', 'ETH')")] = None,
    since: Annotated[Optional[str], Field(description="ISO 8601 timestamp — only articles published after this time")] = None,
) -> Union[dict, list, str]:
    """Get aggregated crypto news articles from multiple sources, ranked by reliability.

    Use this when you need recent news, headlines, or sentiment context about the crypto
    market, a specific coin, or a category.
    Do NOT use this for price data, funding rates, or market metrics — use the dedicated tools.

    Returns: title, source, source_tier (1=most reliable), category, coin_tags, published timestamp.
    """
    params: dict = {"limit": str(limit)}
    if category:
        params["category"] = category
    if coin:
        params["coin"] = coin
    if since:
        params["since"] = since
    return await call_api(ctx, "/v1/news/feed", "/api/news/feed", params)


@mcp.tool()
async def get_curated_news(
    ctx: Context,
    limit: Annotated[int, Field(ge=1, le=100, description="Number of curated stories to return (1-100). Default 20.")] = 20,
    category: Annotated[Optional[str], Field(description="Filter by category: crypto, ai, markets, geopolitics")] = None,
) -> Union[dict, list, str]:
    """Get AI-curated top stories — the most important crypto, AI, markets, and geopolitics news.

    These are Claude-screened stories updated every 15 minutes. Use this when you need
    a quick overview of the most important breaking news, or when a user asks
    "what's happening?" or "what are the top stories?".

    Returns: headline, tweet (AI summary), url, category, source_name, posted_at.
    """
    params: dict = {"limit": str(limit)}
    if category:
        params["category"] = category
    return await call_api(ctx, "/v1/news/curated", "/api/news/curated", params)


@mcp.tool()
async def get_market_overview(ctx: Context) -> Union[dict, list, str]:
    """Get a broad crypto market overview: total market cap, 24h volume, BTC dominance,
    Fear & Greed Index, top gainers/losers, and trending coins.

    Use this as your FIRST call for any general market question ("how's the market?",
    "what's trending?", "is it bullish or bearish?").
    Do NOT use this for coin-specific analysis — use analyze_coin or dedicated tools instead.

    Returns: total_market_cap, total_volume_24h, btc_dominance, fear_greed_index,
    top_gainers (list), top_losers (list), trending (list).
    """
    return await call_api(ctx, "/v1/tracker/market-overview", "/api/tracker/market-overview")


@mcp.tool()
async def get_price_prediction(
    ctx: Context,
    coin: Annotated[Optional[str], Field(description="CoinGecko slug (e.g. 'bitcoin', 'ethereum', 'solana'). Omit for all coins.")] = None,
) -> Union[dict, list, str]:
    """Get AI-powered price prediction scores with sub-signal breakdowns for bias assessment.

    Use this when you need a model-based bullish/bearish signal or want to see how technical
    and derivatives indicators align for a coin.
    Do NOT use this for raw price data or market cap — use get_market_overview or search_market_cap.

    Returns: bias (bullish/bearish/neutral), score (0-10), technical signals (RSI, EMA trends),
    derivatives signals (funding sentiment, OI change, long/short ratio, liquidation sentiment).
    """
    params: dict = {}
    if coin:
        params["coin"] = coin
    return await call_api(ctx, "/v1/price-prediction/data", "/api/price-prediction/data", params)


@mcp.tool()
async def search_market_cap(
    ctx: Context,
    q: Annotated[str, Field(min_length=2, max_length=100, description="Search query: coin name or ticker (2-100 chars)")],
) -> Union[dict, list, str]:
    """Search for coins by name or ticker symbol to find their CoinGecko IDs and market data.

    Use this to discover CoinGecko IDs needed by get_price_prediction and get_correlation_matrix,
    or to look up basic market stats for any token.
    Do NOT use this for narrative/sector search — use get_narratives or get_ecosystems instead.

    Returns: id (CoinGecko slug), symbol, name, market_cap, price, price_change_24h, rank.
    """
    return await call_api(ctx, "/v1/market-cap/search", "/api/market-cap/search", {"q": q})


@mcp.tool()
async def get_gem_finder(
    ctx: Context,
    limit: Annotated[int, Field(ge=1, le=1000, description="Number of tokens to return (1-1000). Default 100.")] = 100,
) -> Union[dict, list, str]:
    """Get a curated list of low-cap, high-potential tokens identified by the gem finder algorithm.

    Use this when looking for early-stage alpha, undervalued tokens, or "hidden gems" that
    are showing unusual on-chain activity or smart money interest.
    Do NOT use this for established top-100 tokens — use get_market_overview or get_heatmap instead.

    Returns: token name, symbol, score, ATH distance (% below all-time high), FDV/MCap ratio,
    exchange listing count, and sparkline price data.
    """
    return await call_api(ctx, "/v1/gem-finder/data", "/api/gem-finder/data", {"limit": str(limit)})


@mcp.tool()
async def get_derivatives_overview(ctx: Context) -> Union[dict, list, str]:
    """Get a derivatives market-wide snapshot: total OI, average funding rate, OI-weighted funding,
    top 20 coins by OI, and exchange/coin counts.

    Use this for a quick derivatives health check before diving into specific coins with
    get_futures_data or get_options_data.
    Do NOT use this for per-coin time-series data — use get_futures_data with a specific chart type.
    Requires API key (SHARPE_API_KEY) — not available on the free tier.

    Returns: total_oi, avg_funding_rate, oi_weighted_funding, top_coins_by_oi (list),
    exchange_count, coin_count.
    """
    return await call_api(ctx, "/v1/market/derivatives-overview", "/v1/market/derivatives-overview")


@mcp.tool()
async def get_api_coverage(ctx: Context) -> Union[dict, list, str]:
    """Get metadata about all available data products: supported exchanges, coins, chart types,
    timeframes, and update frequencies for each product.

    Use this FIRST to understand what data is available before making specific queries.
    Lists all valid chart IDs for get_futures_data and get_options_data.
    Do NOT use this for actual data — it only describes what is available.
    Requires API key (SHARPE_API_KEY) — not available on the free tier.

    Returns: per-product breakdown of exchanges, coins, chart_types (with IDs and descriptions),
    timeframes, and update_frequency.
    """
    return await call_api(ctx, "/v1/meta/coverage", "/v1/meta/coverage")


ListingsExchange = Literal["binance", "okx", "bybit", "gateio", "mexc"]


@mcp.tool()
async def get_exchange_listings(
    ctx: Context,
    narrative: Annotated[
        Optional[str],
        Field(description="Filter to a single narrative slug (e.g. 'ai-agents', 'memes', 'layer-1', 'rwa', 'defi')."),
    ] = None,
    exchange: Annotated[
        Optional[ListingsExchange],
        Field(description="Filter to a single exchange."),
    ] = None,
) -> Union[dict, list, str]:
    """Get the Exchange Listings hub payload — aggregated listing counts across Binance, OKX,
    Bybit, Gate.io, and MEXC, plus recent listings, tagged by narrative.

    Use this to answer: which narratives are CEXs deploying listing slots toward? Which exchange
    is most active? What was the top token listed last week? Filter by narrative or exchange for
    scope-specific data.
    Do NOT use this for historical price data — use get_futures_data for that.

    Returns: weekly + monthly listing buckets, recent (last 90d) table, this-week/this-month
    totals with WoW/MoM deltas, top narratives and top exchanges of the month, freshness
    timestamps. Updated daily via exchange ingest crons.
    """
    params: Dict[str, str] = {}
    if narrative:
        params["narrative"] = narrative
    if exchange:
        params["exchange"] = exchange
    return await call_api(ctx, "/v1/listings/data", "/api/listings/data", params)


@mcp.tool()
async def get_recent_listings(
    ctx: Context,
    narrative: Annotated[
        Optional[str],
        Field(description="Filter to a single narrative slug."),
    ] = None,
    exchange: Annotated[
        Optional[ListingsExchange],
        Field(description="Filter to a single exchange."),
    ] = None,
    days: Annotated[
        int, Field(ge=1, le=365, description="Lookback window in days. Default 90.")
    ] = 90,
    limit: Annotated[
        int, Field(ge=1, le=1000, description="Max rows returned. Default 200.")
    ] = 200,
) -> Union[dict, list, str]:
    """Get a flat feed of recent token listings across top CEXs (Binance, OKX, Bybit, Gate.io, MEXC).

    Use this when you want a simple list of what got listed and when, not aggregate metrics.
    Good for trade-signal consumers scanning fresh listings, narrative watchers tracking new
    tokens, or agents building per-token context.
    Do NOT use this for aggregate counts or share distribution — use get_exchange_listings.

    Returns: {rows: [{token_symbol, token_name, token_coingecko_id, exchange, listing_date,
    narrative_slug, listing_date_source}], count, window_days}.
    """
    params: Dict[str, str] = {"days": str(days), "limit": str(limit)}
    if narrative:
        params["narrative"] = narrative
    if exchange:
        params["exchange"] = exchange
    return await call_api(ctx, "/v1/listings/recent", "/v1/listings/recent", params)


# ── Tools: Composite (3 new) ────────────────────────────────────────────


@mcp.tool()
async def analyze_coin(
    ctx: Context,
    coin: Annotated[str, Field(description="Coin ticker (e.g. 'BTC', 'ETH', 'SOL')")] = "BTC",
) -> str:
    """Comprehensive single-coin analysis combining funding rates, futures OI, options IV,
    and AI price prediction into one consolidated view.

    Use this when asked about a specific coin's outlook, positioning, or derivatives data.
    This is the best single tool for "what's happening with BTC/ETH/SOL?" questions.
    Do NOT use this for market-wide overview (use market_briefing) or for sector analysis
    (use get_narratives).

    Returns: formatted text with price prediction, funding rates by exchange, open interest
    summary, and ATM implied volatility (for BTC/ETH/SOL).
    """
    coin_upper = coin.upper()
    coin_lower = coin.lower()

    # CoinGecko slug mapping for common coins
    cg_slugs = {
        "BTC": "bitcoin", "ETH": "ethereum", "SOL": "solana",
        "DOGE": "dogecoin", "XRP": "ripple", "ADA": "cardano",
        "AVAX": "avalanche-2", "DOT": "polkadot", "LINK": "chainlink",
        "MATIC": "matic-network", "SUI": "sui", "APT": "aptos",
    }
    cg_slug = cg_slugs.get(coin_upper, coin_lower)

    # Options only available for BTC, ETH, SOL
    has_options = coin_upper in ("BTC", "ETH", "SOL")

    errors: List[str] = []

    # Fire all API calls concurrently
    import asyncio

    funding_task = _safe_call(
        ctx, "/v1/funding/rates", "/api/funding/rates",
        {"type": "accumulated"}, "funding"
    )
    oi_task = _safe_call(
        ctx, "/v1/futures/data", "/api/futures/data",
        {"chart": "oi-snapshot", "coin": coin_upper, "timeframe": "3M"}, "oi"
    )
    prediction_task = _safe_call(
        ctx, "/v1/price-prediction/data", "/api/price-prediction/data",
        {"coin": cg_slug}, "prediction"
    )

    tasks = [funding_task, oi_task, prediction_task]

    if has_options:
        iv_task = _safe_call(
            ctx, "/v1/options/data", "/api/options/data",
            {"chart": "atm-iv", "coin": coin_upper, "timeframe": "1M"}, "options-iv"
        )
        tasks.append(iv_task)

    results = await asyncio.gather(*tasks)

    funding_data, funding_err = results[0]
    oi_data, oi_err = results[1]
    prediction_data, prediction_err = results[2]
    iv_data, iv_err = (None, None)
    if has_options:
        iv_data, iv_err = results[3]

    for err in [funding_err, oi_err, prediction_err, iv_err]:
        if err:
            errors.append(err)

    # Build formatted output
    lines: List[str] = [f"## {coin_upper} Analysis"]

    # Price prediction section
    if prediction_data:
        pred = prediction_data
        if isinstance(pred, list) and len(pred) > 0:
            pred = pred[0]
        if isinstance(pred, dict):
            # API returns {coin: {direction, consensusScore, spotPrice, ...}, updatedAt}
            coin_obj = pred.get("coin", pred)
            if isinstance(coin_obj, dict):
                pred = coin_obj

            bias = _safe_get(pred, "direction", default=_safe_get(pred, "bias", default="unknown"))
            score = _safe_get(pred, "consensusScore", default=_safe_get(pred, "score", default=None))
            price = _safe_get(pred, "spotPrice", default=_safe_get(pred, "price", default=None))
            change_24h = _safe_get(pred, "priceChange24h", default=_safe_get(pred, "price_change_24h", default=None))

            price_str = _fmt_usd(price) if price else "N/A"
            change_str = _fmt_pct(change_24h) if change_24h is not None else ""
            score_str = f"{score}/100" if score is not None else "N/A"

            lines.append("")
            lines.append(f"**Price:** {price_str} | **24h:** {change_str}")
            lines.append(f"**Prediction:** {bias.capitalize()} (score: {score_str})")

            # Sub-signals if available
            signals = _safe_get(pred, "signals", default=_safe_get(pred, "technical", default=None))
            if isinstance(signals, list) and signals:
                parts = []
                for sig in signals:
                    if isinstance(sig, dict):
                        label = sig.get("label", sig.get("name", ""))
                        sig_bias = sig.get("bias", "")
                        if label and sig_bias:
                            parts.append(f"{label}: {sig_bias}")
                if parts:
                    lines.append(f"**Signals:** {', '.join(parts[:6])}")
            elif isinstance(signals, dict):
                rsi = _safe_get(signals, "rsi", default=None)
                ema_trend = _safe_get(signals, "ema_trend", default=None)
                parts = []
                if rsi is not None:
                    parts.append(f"RSI {rsi:.0f}")
                if ema_trend:
                    parts.append(f"EMA {ema_trend}")
                if parts:
                    lines.append(f"**Technicals:** {', '.join(parts)}")
    else:
        lines.append("\n*Price prediction data unavailable*")

    # Funding rates section
    if funding_data:
        rates_list = funding_data
        if isinstance(rates_list, dict) and "items" in rates_list:
            rates_list = rates_list["items"]
        if isinstance(rates_list, list):
            coin_rates = [
                r for r in rates_list
                if isinstance(r, dict) and (
                    r.get("base_coin", r.get("coin", "")).upper() == coin_upper
                    or r.get("symbol", "").upper().startswith(coin_upper)
                )
            ]
            if coin_rates:
                lines.append("")
                lines.append("**Funding Rates:**")
                rate_values = []
                for r in coin_rates[:10]:
                    exchange = r.get("exchange", "Unknown")
                    # Accumulated endpoint uses acc_7d/acc_1d; current uses rate
                    rate = r.get("rate", r.get("acc_1d", r.get("funding_rate", None)))
                    acc_7d = r.get("acc_7d", None)
                    if rate is not None:
                        rate_values.append(rate)
                        label = f"  {exchange}: {_fmt_rate(rate)}"
                        if acc_7d is not None:
                            label += f" (7d: {_fmt_rate(acc_7d)})"
                        lines.append(label)
                if rate_values:
                    avg_rate = sum(rate_values) / len(rate_values)
                    lines.append(f"  **Avg:** {_fmt_rate(avg_rate)} across {len(rate_values)} exchanges")
            else:
                lines.append("\n*No funding rates found for this coin*")
    else:
        lines.append("\n*Funding rate data unavailable*")

    # Open interest section
    if oi_data:
        # API returns {"chart": "oi-snapshot", "coin": ..., "data": [...], ...}
        if isinstance(oi_data, dict) and "data" in oi_data:
            oi_data = oi_data["data"]
        lines.append("")
        lines.append("**Open Interest:**")
        if isinstance(oi_data, list):
            # Aggregate: keep the latest OI value per exchange
            latest_by_exchange: Dict[str, float] = {}
            latest_ts_by_exchange: Dict[str, str] = {}
            for item in oi_data:
                if not isinstance(item, dict):
                    continue
                exchange = item.get("exchange", "Unknown")
                oi_val = item.get("open_interest_value", item.get("value", item.get("oi", item.get("open_interest", 0))))
                ts = item.get("timestamp", item.get("snapshot_at", ""))
                if isinstance(oi_val, (int, float)) and oi_val > 0:
                    prev_ts = latest_ts_by_exchange.get(exchange, "")
                    if ts >= prev_ts:
                        latest_by_exchange[exchange] = oi_val
                        latest_ts_by_exchange[exchange] = ts
            total_oi = 0.0
            for exchange, oi_val in sorted(latest_by_exchange.items(), key=lambda x: x[1], reverse=True)[:10]:
                total_oi += oi_val
                lines.append(f"  {exchange}: {_fmt_usd(oi_val)}")
            if latest_by_exchange:
                lines.append(f"  **Total:** {_fmt_usd(total_oi)} across {len(latest_by_exchange)} exchanges")
    else:
        lines.append("\n*Open interest data unavailable*")

    # Options IV section
    if has_options:
        if iv_data:
            # API returns {"chart": "atm-iv", "data": [...], ...}
            iv_list = iv_data
            if isinstance(iv_list, dict) and "data" in iv_list:
                iv_list = iv_list["data"]
            lines.append("")
            lines.append("**Options (ATM IV):**")
            if isinstance(iv_list, list) and len(iv_list) > 0:
                # Take the most recent data point
                latest = iv_list[-1] if iv_list else None
                if isinstance(latest, dict):
                    iv_val = latest.get("value", latest.get("iv", None))
                    if iv_val is not None:
                        lines.append(f"  ATM IV (latest): {iv_val:.1f}%")
                elif isinstance(latest, (list, tuple)) and len(latest) >= 2:
                    lines.append(f"  ATM IV (latest): {latest[1]:.1f}%")
            elif isinstance(iv_list, dict):
                for tenor, val in iv_list.items():
                    if isinstance(val, (int, float)):
                        lines.append(f"  {tenor}: {val:.1f}%")
        else:
            lines.append("\n*Options IV data unavailable*")

    # Errors section
    if errors:
        lines.append("")
        lines.append("**Data gaps:** " + "; ".join(errors))

    return "\n".join(lines)


@mcp.tool()
async def market_briefing(ctx: Context) -> str:
    """Get a comprehensive market briefing combining market overview, top narratives, and funding rate summary.

    Use this as the single best tool for a morning briefing, market recap, or when someone asks
    "what's going on in crypto?" without specifying a coin.
    Do NOT use this for coin-specific questions (use analyze_coin) or for detailed chart data
    (use get_futures_data/get_options_data).

    Returns: formatted text with market stats, Fear & Greed reading, top gainers/losers,
    narrative performance rankings, and funding rate highlights.
    """
    import asyncio

    errors: List[str] = []

    overview_task = _safe_call(
        ctx, "/v1/tracker/market-overview", "/api/tracker/market-overview",
        None, "market-overview"
    )
    narratives_task = _safe_call(
        ctx, "/v1/narratives/data", "/api/narratives/data",
        None, "narratives"
    )
    funding_task = _safe_call(
        ctx, "/v1/funding/rates", "/api/funding/rates",
        {"type": "current"}, "funding"
    )

    results = await asyncio.gather(overview_task, narratives_task, funding_task)

    overview_data, overview_err = results[0]
    narratives_data, narratives_err = results[1]
    funding_data, funding_err = results[2]

    for err in [overview_err, narratives_err, funding_err]:
        if err:
            errors.append(err)

    lines: List[str] = ["## Market Briefing"]

    # Market overview section
    if overview_data and isinstance(overview_data, dict):
        mcap = _safe_get(overview_data, "total_market_cap", default=None)
        vol = _safe_get(overview_data, "total_volume_24h", default=_safe_get(overview_data, "total_volume", default=None))
        btc_dom = _safe_get(overview_data, "btc_dominance", default=None)
        fg = _safe_get(overview_data, "fgi", default=_safe_get(overview_data, "fear_greed_index", default=_safe_get(overview_data, "fear_greed", default=None)))

        lines.append("")
        lines.append("### Market Stats")
        if mcap is not None:
            lines.append(f"**Total Market Cap:** {_fmt_usd(mcap)}")
        if vol is not None:
            lines.append(f"**24h Volume:** {_fmt_usd(vol)}")
        if btc_dom is not None:
            btc_dom_pct = btc_dom if btc_dom > 1 else btc_dom * 100
            lines.append(f"**BTC Dominance:** {btc_dom_pct:.1f}%")
        if fg is not None:
            fg_val = fg.get("value", fg) if isinstance(fg, dict) else fg
            fg_label = fg.get("label", "") if isinstance(fg, dict) else ""
            if not fg_label:
                fg_label = _safe_get(overview_data, "fgi_classification", default="")
            lines.append(f"**Fear & Greed:** {fg_val} {fg_label}")

        # Top gainers
        gainers = _safe_get(overview_data, "top_gainers", default=[])
        if isinstance(gainers, list) and gainers:
            lines.append("")
            lines.append("### Top Gainers (24h)")
            for g in gainers[:5]:
                if isinstance(g, dict):
                    sym = g.get("symbol", g.get("name", "?"))
                    chg = g.get("price_change_24h", g.get("change", None))
                    lines.append(f"  {sym}: {_fmt_pct(chg)}")

        # Top losers
        losers = _safe_get(overview_data, "top_losers", default=[])
        if isinstance(losers, list) and losers:
            lines.append("")
            lines.append("### Top Losers (24h)")
            for l_item in losers[:5]:
                if isinstance(l_item, dict):
                    sym = l_item.get("symbol", l_item.get("name", "?"))
                    chg = l_item.get("price_change_24h", l_item.get("change", None))
                    lines.append(f"  {sym}: {_fmt_pct(chg)}")
    else:
        lines.append("\n*Market overview data unavailable*")

    # Narratives section
    if narratives_data:
        narr_list = narratives_data
        # API returns {narratives: [...], totalNarrativeMcap, updatedAt}
        if isinstance(narr_list, dict) and "narratives" in narr_list:
            narr_list = narr_list["narratives"]
        elif isinstance(narr_list, dict) and "items" in narr_list:
            narr_list = narr_list["items"]
        if isinstance(narr_list, list) and narr_list:
            # Sort by 24h change (camelCase: change24h)
            sorted_narr = sorted(
                [n for n in narr_list if isinstance(n, dict)],
                key=lambda n: n.get("change24h", n.get("price_change_24h", n.get("change_24h", 0))) or 0,
                reverse=True,
            )
            lines.append("")
            lines.append("### Top Narratives (24h)")
            for n in sorted_narr[:5]:
                name = n.get("name", n.get("narrative", "?"))
                chg = n.get("change24h", n.get("price_change_24h", n.get("change_24h", None)))
                mcap_n = n.get("marketCap", n.get("market_cap", None))
                lines.append(f"  **{name}:** {_fmt_pct(chg)} (mcap: {_fmt_usd(mcap_n)})")

            lines.append("")
            lines.append("### Worst Narratives (24h)")
            for n in sorted_narr[-3:]:
                name = n.get("name", n.get("narrative", "?"))
                chg = n.get("change24h", n.get("price_change_24h", n.get("change_24h", None)))
                lines.append(f"  **{name}:** {_fmt_pct(chg)}")
    else:
        lines.append("\n*Narrative data unavailable*")

    # Funding rate highlights
    if funding_data:
        rates_list = funding_data
        if isinstance(rates_list, dict) and "items" in rates_list:
            rates_list = rates_list["items"]
        if isinstance(rates_list, list) and rates_list:
            # Find highest and lowest rates
            valid_rates = [
                r for r in rates_list
                if isinstance(r, dict)
                and r.get("rate", r.get("funding_rate")) is not None
            ]
            if valid_rates:
                def _rate_val(r: dict) -> float:
                    return float(r.get("rate", r.get("funding_rate", 0)) or 0)

                sorted_rates = sorted(valid_rates, key=_rate_val, reverse=True)

                lines.append("")
                lines.append("### Funding Rate Highlights")
                lines.append("**Highest (longs paying most):**")
                for r in sorted_rates[:3]:
                    coin_name = r.get("base_coin", r.get("coin", r.get("symbol", "?")))
                    exchange = r.get("exchange", "?")
                    rate = _rate_val(r)
                    lines.append(f"  {coin_name} on {exchange}: {_fmt_rate(rate)}")

                lines.append("**Lowest (shorts paying most):**")
                for r in sorted_rates[-3:]:
                    coin_name = r.get("base_coin", r.get("coin", r.get("symbol", "?")))
                    exchange = r.get("exchange", "?")
                    rate = _rate_val(r)
                    lines.append(f"  {coin_name} on {exchange}: {_fmt_rate(rate)}")
    else:
        lines.append("\n*Funding rate data unavailable*")

    if errors:
        lines.append("")
        lines.append("**Data gaps:** " + "; ".join(errors))

    return "\n".join(lines)


@mcp.tool()
async def find_opportunities(ctx: Context) -> str:
    """Scan for the best funding rate arbitrage opportunities across all exchanges, combining
    spot-perp basis trades and cross-exchange funding arb.

    Use this when looking for yield-generating or delta-neutral trades, or when asked
    "where's the alpha?" or "best arb opportunities right now?"
    Do NOT use this for directional trades or price predictions — use analyze_coin or
    get_price_prediction instead.

    Returns: formatted text with top spot-perp basis trades and cross-exchange arb
    opportunities sorted by annualized APR, plus a funding rate summary.
    """
    import asyncio

    errors: List[str] = []

    spot_perp_task = _safe_call(
        ctx, "/v1/arbitrage/spot-perp", "/api/arbitrage/spot-perp",
        {"exchange": "all", "direction": "all"}, "spot-perp-arb"
    )
    cross_ex_task = _safe_call(
        ctx, "/v1/arbitrage/cross-exchange", "/api/arbitrage/cross-exchange",
        None, "cross-exchange-arb"
    )
    funding_task = _safe_call(
        ctx, "/v1/funding/rates", "/api/funding/rates",
        {"type": "current"}, "funding"
    )

    results = await asyncio.gather(spot_perp_task, cross_ex_task, funding_task)

    spot_perp_data, spot_perp_err = results[0]
    cross_ex_data, cross_ex_err = results[1]
    funding_data, funding_err = results[2]

    for err in [spot_perp_err, cross_ex_err, funding_err]:
        if err:
            errors.append(err)

    lines: List[str] = ["## Arbitrage Opportunities"]

    # Spot-perp section
    if spot_perp_data:
        arb_list = spot_perp_data
        if isinstance(arb_list, dict) and "items" in arb_list:
            arb_list = arb_list["items"]
        if isinstance(arb_list, list) and arb_list:
            # Sort by APR descending
            sorted_arbs = sorted(
                [a for a in arb_list if isinstance(a, dict)],
                key=lambda a: abs(a.get("apr", a.get("annualized_apr", 0)) or 0),
                reverse=True,
            )
            lines.append("")
            lines.append("### Spot-Perp Basis Trades (Top 10 by APR)")
            lines.append("*Long spot + short perp (or vice versa) to capture funding*")
            lines.append("")
            for a in sorted_arbs[:10]:
                symbol = a.get("symbol", a.get("coin", "?"))
                exchange = a.get("exchange", "?")
                apr = a.get("apr", a.get("annualized_apr", 0))
                rate = a.get("fundingRate", a.get("rate", a.get("funding_rate", None)))
                direction = a.get("direction", "?")

                apr_str = f"{apr:.1f}%" if apr is not None else "N/A"
                rate_str = _fmt_rate(rate) if rate is not None else ""

                lines.append(
                    f"  **{symbol}** on {exchange} | APR: {apr_str} | "
                    f"Rate: {rate_str} | Dir: {direction}"
                )
        else:
            lines.append("\n*No spot-perp opportunities found*")
    else:
        lines.append("\n*Spot-perp arbitrage data unavailable*")

    # Cross-exchange section
    if cross_ex_data:
        cx_list = cross_ex_data
        if isinstance(cx_list, dict) and "items" in cx_list:
            cx_list = cx_list["items"]
        if isinstance(cx_list, list) and cx_list:
            sorted_cx = sorted(
                [a for a in cx_list if isinstance(a, dict)],
                key=lambda a: abs(a.get("apr", a.get("spread_apr", a.get("annualized_apr", 0))) or 0),
                reverse=True,
            )
            lines.append("")
            lines.append("### Cross-Exchange Funding Arb (Top 10 by APR)")
            lines.append("*Long on low-rate exchange, short on high-rate exchange*")
            lines.append("")
            for a in sorted_cx[:10]:
                symbol = a.get("symbol", a.get("coin", "?"))
                long_ex = a.get("longExchange", a.get("long_exchange", a.get("exchange_long", "?")))
                short_ex = a.get("shortExchange", a.get("short_exchange", a.get("exchange_short", "?")))
                apr = a.get("apr", a.get("spread_apr", a.get("annualized_apr", 0)))
                spread = a.get("spreadRate", a.get("spread", a.get("spread_rate", None)))

                apr_str = f"{apr:.1f}%" if apr is not None else "N/A"
                spread_str = _fmt_rate(spread) if spread is not None else ""

                lines.append(
                    f"  **{symbol}** | Long {long_ex} / Short {short_ex} | "
                    f"APR: {apr_str} | Spread: {spread_str}"
                )
        else:
            lines.append("\n*No cross-exchange opportunities found*")
    else:
        lines.append("\n*Cross-exchange arbitrage data unavailable*")

    # Funding rate summary
    if funding_data:
        rates_list = funding_data
        if isinstance(rates_list, dict) and "items" in rates_list:
            rates_list = rates_list["items"]
        if isinstance(rates_list, list) and rates_list:
            valid = [
                r for r in rates_list
                if isinstance(r, dict)
                and r.get("rate", r.get("funding_rate")) is not None
            ]
            if valid:
                all_rates = [float(r.get("rate", r.get("funding_rate", 0)) or 0) for r in valid]
                avg = sum(all_rates) / len(all_rates)
                positive = sum(1 for r in all_rates if r > 0)
                negative = sum(1 for r in all_rates if r < 0)

                lines.append("")
                lines.append("### Funding Rate Summary")
                lines.append(f"**Avg Rate:** {_fmt_rate(avg)}")
                lines.append(f"**Positive (longs pay):** {positive} | **Negative (shorts pay):** {negative}")
                sentiment = "bullish" if positive > negative * 1.5 else "bearish" if negative > positive * 1.5 else "neutral"
                lines.append(f"**Market Sentiment:** {sentiment} (based on funding rate skew)")

    if errors:
        lines.append("")
        lines.append("**Data gaps:** " + "; ".join(errors))

    return "\n".join(lines)


# ── Resources ────────────────────────────────────────────────────────────

FUTURES_CHARTS = [
    {"id": "perpetual-price", "description": "Perpetual futures price (OHLCV) over time"},
    {"id": "liquidations", "description": "Long and short liquidation volumes over time"},
    {"id": "oi-stacked", "description": "Open interest stacked by exchange over time"},
    {"id": "oi-change", "description": "Open interest change (delta) over time"},
    {"id": "oi-daily-change", "description": "Daily open interest change bars"},
    {"id": "oi-snapshot", "description": "Current open interest snapshot by exchange (bar chart)"},
    {"id": "oi-volume", "description": "Open interest vs volume overlay"},
    {"id": "volume-history", "description": "Trading volume over time by exchange"},
    {"id": "volume-snapshot", "description": "Current volume snapshot by exchange (bar chart)"},
    {"id": "cvd", "description": "Cumulative volume delta (buy vs sell pressure)"},
    {"id": "long-short-ratio", "description": "Long/short account ratio over time"},
    {"id": "top-trader-ls", "description": "Top trader long/short ratio (Binance only)"},
    {"id": "returns-session", "description": "Price returns broken down by trading session (US/EU/APAC)"},
    {"id": "returns-heatmap", "description": "Returns heatmap by hour and day of week"},
    {"id": "returns-hour", "description": "Average hourly returns"},
    {"id": "returns-day", "description": "Average daily returns by day of week"},
    {"id": "funding-rate", "description": "Funding rate time-series across exchanges"},
    {"id": "annualized-basis", "description": "Annualized futures basis (premium/discount) over time"},
    {"id": "term-structure", "description": "Futures term structure (price by expiry date)"},
]

OPTIONS_CHARTS = [
    {"id": "atm-iv", "description": "At-the-money implied volatility over time"},
    {"id": "iv-term-structure", "description": "IV term structure by tenor (1W, 1M, 3M, 6M, 1Y)"},
    {"id": "vol-smile", "description": "Volatility smile — IV by delta for a given expiry"},
    {"id": "vol-surface", "description": "3D volatility surface (strike x expiry x IV)"},
    {"id": "vol-skew", "description": "25-delta put-call skew over time"},
    {"id": "term-structure-slope", "description": "IV term structure slope (steepness) over time"},
    {"id": "spot-vol-correlation", "description": "Correlation between spot price and IV over time"},
    {"id": "oi-by-strike", "description": "Open interest distribution by strike price"},
    {"id": "oi-by-expiry", "description": "Open interest distribution by expiry date"},
    {"id": "put-call-oi-ratio", "description": "Put/call OI ratio over time"},
    {"id": "max-pain", "description": "Max pain strike price by expiry"},
    {"id": "top-volume", "description": "Top traded strikes/expiries by volume"},
    {"id": "put-call-volume-ratio", "description": "Put/call volume ratio over time"},
    {"id": "options-flow", "description": "Large options trades (block flow) feed"},
    {"id": "exchange-volume", "description": "Options volume by exchange over time"},
    {"id": "realized-vol", "description": "Realized (historical) volatility over time"},
    {"id": "iv-vs-rv", "description": "Implied volatility vs realized volatility comparison"},
    {"id": "zscore-iv", "description": "Z-score of implied volatility (mean reversion signal)"},
    {"id": "zscore-rv", "description": "Z-score of realized volatility"},
    {"id": "zscore-iv-rv", "description": "Z-score of IV/RV ratio (vol risk premium signal)"},
    {"id": "gex", "description": "Gamma exposure (GEX) by strike — dealer hedging pressure"},
    {"id": "vol-cones", "description": "Volatility cones — historical vol distribution by window"},
]

EXCHANGES_DATA = {
    "funding_rates": [
        "Binance", "OKX", "Bybit", "Gate.io", "Bitget", "KuCoin", "MEXC",
        "HTX", "BingX", "Hyperliquid", "Deribit", "CoinEx", "BitMEX",
    ],
    "futures": {
        "default": ["Binance", "Bybit", "OKX", "Deribit", "Hyperliquid"],
        "extra": ["Bitget", "Gate.io", "KuCoin", "MEXC", "HTX"],
    },
    "options": ["Deribit"],
}

NARRATIVE_SLUGS = [
    {"slug": "layer-1", "name": "Layer 1"},
    {"slug": "layer-2", "name": "Layer 2"},
    {"slug": "defi", "name": "DeFi"},
    {"slug": "ai-agents", "name": "AI Agents"},
    {"slug": "defai", "name": "DeFAI"},
    {"slug": "depin", "name": "DePIN"},
    {"slug": "desci", "name": "DeSci"},
    {"slug": "gaming", "name": "Gaming"},
    {"slug": "dex-tokens", "name": "DEX Tokens"},
    {"slug": "cex-tokens", "name": "CEX Tokens"},
    {"slug": "lending", "name": "Lending & Borrowing"},
    {"slug": "memes", "name": "Memes"},
    {"slug": "nfts", "name": "NFTs & Collectibles"},
    {"slug": "oracles", "name": "Oracles"},
    {"slug": "privacy", "name": "Privacy"},
    {"slug": "rwa", "name": "Real World Assets"},
    {"slug": "stablecoins", "name": "Stablecoins"},
    {"slug": "restaking", "name": "Restaking"},
    {"slug": "liquid-staking", "name": "Liquid Staking"},
    {"slug": "modular", "name": "Modular Blockchains"},
    {"slug": "socialfi", "name": "SocialFi"},
    {"slug": "intent", "name": "Intent-Based"},
]

ECOSYSTEM_SLUGS = [
    {"slug": "ethereum", "name": "Ethereum", "native_token": "ETH"},
    {"slug": "solana", "name": "Solana", "native_token": "SOL"},
    {"slug": "bnb-chain", "name": "BNB Chain", "native_token": "BNB"},
    {"slug": "arbitrum", "name": "Arbitrum", "native_token": "ARB"},
    {"slug": "base", "name": "Base"},
    {"slug": "bitcoin", "name": "Bitcoin", "native_token": "BTC"},
    {"slug": "avalanche", "name": "Avalanche", "native_token": "AVAX"},
    {"slug": "optimism", "name": "Optimism", "native_token": "OP"},
    {"slug": "cosmos", "name": "Cosmos", "native_token": "ATOM"},
    {"slug": "polkadot", "name": "Polkadot", "native_token": "DOT"},
    {"slug": "sui", "name": "Sui", "native_token": "SUI"},
    {"slug": "aptos", "name": "Aptos", "native_token": "APT"},
    {"slug": "toncoin", "name": "Toncoin", "native_token": "TON"},
    {"slug": "tron", "name": "Tron", "native_token": "TRX"},
    {"slug": "cardano", "name": "Cardano", "native_token": "ADA"},
    {"slug": "sonic", "name": "Sonic", "native_token": "S"},
    {"slug": "hyperliquid", "name": "Hyperliquid", "native_token": "HYPE"},
    {"slug": "berachain", "name": "Berachain", "native_token": "BERA"},
    {"slug": "sei", "name": "Sei", "native_token": "SEI"},
    {"slug": "zksync", "name": "zkSync", "native_token": "ZK"},
    {"slug": "starknet", "name": "Starknet", "native_token": "STRK"},
    {"slug": "scroll", "name": "Scroll", "native_token": "SCR"},
    {"slug": "movement", "name": "Movement", "native_token": "MOVE"},
]


@mcp.resource("sharpe://charts/futures")
def resource_futures_charts() -> str:
    """List of all 19 valid futures chart IDs with descriptions. Use these IDs with get_futures_data."""
    return json.dumps(FUTURES_CHARTS, indent=2)


@mcp.resource("sharpe://charts/options")
def resource_options_charts() -> str:
    """List of all 22 valid options chart IDs with descriptions. Use these IDs with get_options_data."""
    return json.dumps(OPTIONS_CHARTS, indent=2)


@mcp.resource("sharpe://exchanges")
def resource_exchanges() -> str:
    """Supported exchanges per product (funding rates, futures, options)."""
    return json.dumps(EXCHANGES_DATA, indent=2)


@mcp.resource("sharpe://narratives")
def resource_narratives() -> str:
    """All 22 narrative slugs for use with get_narratives. Pass slug as the 'narrative' parameter."""
    return json.dumps(NARRATIVE_SLUGS, indent=2)


@mcp.resource("sharpe://ecosystems")
def resource_ecosystems() -> str:
    """All 23 ecosystem slugs for use with get_ecosystems. Pass slug as the 'ecosystem' parameter."""
    return json.dumps(ECOSYSTEM_SLUGS, indent=2)


# ── Prompts ──────────────────────────────────────────────────────────────


@mcp.prompt()
def market_analysis() -> str:
    """A guided prompt template for performing a comprehensive crypto market analysis."""
    return (
        "Perform a comprehensive crypto market analysis using Sharpe data.\n\n"
        "Follow these steps:\n\n"
        "1. **Market Overview** — Call market_briefing to get the current state of the market.\n"
        "   Summarize: total market cap trend, BTC dominance, Fear & Greed, and top movers.\n\n"
        "2. **Derivatives Health** — Call get_derivatives_overview.\n"
        "   Analyze: total OI trend, funding rate skew, and leverage levels.\n\n"
        "3. **Sector Rotation** — Call get_narratives to see which sectors are leading/lagging.\n"
        "   Identify: top 3 outperforming and bottom 3 underperforming narratives.\n\n"
        "4. **Ecosystem Flows** — Call get_ecosystems to compare chain activity.\n"
        "   Highlight: which chains are gaining TVL and volume.\n\n"
        "5. **Opportunities** — Call find_opportunities for the best arb trades.\n"
        "   List: top 3 highest-APR opportunities with risk notes.\n\n"
        "6. **Synthesis** — Combine all signals into a coherent market thesis.\n"
        "   Deliver: 1-paragraph summary + bullish/bearish/neutral verdict + key risks.\n\n"
        "Format the output as a structured report with headers and bullet points."
    )


@mcp.prompt()
def coin_deep_dive(coin: str = "BTC") -> str:
    """A guided prompt template for analyzing a specific coin in depth across all data dimensions."""
    return (
        f"Perform a deep-dive analysis on {coin.upper()} using Sharpe data.\n\n"
        "Follow these steps:\n\n"
        f"1. **Quick Analysis** — Call analyze_coin with coin='{coin.upper()}' for a consolidated view.\n\n"
        f"2. **Futures Deep Dive** — Call get_futures_data for {coin.upper()} with these charts:\n"
        "   - oi-stacked (OI trend across exchanges)\n"
        "   - long-short-ratio (positioning)\n"
        "   - liquidations (if available)\n"
        "   - annualized-basis (futures premium)\n"
        "   Analyze: Is OI rising with price? Are traders net long or short? Is basis elevated?\n\n"
        f"3. **Options Analysis** (if BTC/ETH/SOL) — Call get_options_data for {coin.upper()}:\n"
        "   - atm-iv (volatility trend)\n"
        "   - vol-skew (put/call skew)\n"
        "   - put-call-oi-ratio (options positioning)\n"
        "   - gex (gamma exposure / dealer hedging)\n"
        "   Analyze: Is IV elevated vs historical? Are options traders hedging or speculating?\n\n"
        f"4. **Funding History** — Call get_funding_rates with type='history', coin='{coin.upper()}', days=30.\n"
        "   Analyze: Is funding persistently positive/negative? Any recent spikes?\n\n"
        f"5. **Correlation** — Call get_correlation_matrix to see how {coin.upper()} correlates with BTC, ETH, and TradFi.\n\n"
        f"6. **Price Prediction** — Call get_price_prediction for the AI model's take.\n\n"
        "7. **Synthesis** — Combine all signals:\n"
        f"   - Overall bias for {coin.upper()} (bullish/bearish/neutral)\n"
        "   - Key levels to watch (support/resistance implied by options strikes)\n"
        "   - Risk factors (high leverage, extreme funding, vol crush potential)\n"
        "   - Recommended trades (if any arb opportunities exist)\n\n"
        "Format as a structured research note with headers, key metrics in bold, and a summary box."
    )


# ── Entry point ──────────────────────────────────────────────────────────

if __name__ == "__main__":
    mcp.run()
