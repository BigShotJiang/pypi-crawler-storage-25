"""Tests for coding tools (ReadFileTool, WriteFileTool, ListDirectoryTool,
GrepSearchTool, BashExecuteTool, PythonREPLTool).

All file-system tests use the tmp_path pytest fixture — no real workspace required.

Run with: uv run pytest tests/tools/test_coding_tools.py -v
"""

from __future__ import annotations

import asyncio

import pytest

from agentbyte.component import ComponentLoader
from agentbyte.tools.coding_tools import (
    BashExecuteTool,
    CodingToolsConfig,
    GrepSearchTool,
    ListDirectoryTool,
    PythonREPLTool,
    ReadFileTool,
    WriteFileTool,
    create_coding_tools,
    _safe_resolve,
)


# ---------------------------------------------------------------------------
# _safe_resolve
# ---------------------------------------------------------------------------


def test_safe_resolve_valid(tmp_path):
    result = _safe_resolve(tmp_path, "sub/file.txt")
    assert result == (tmp_path / "sub" / "file.txt").resolve()


def test_safe_resolve_traversal_rejected(tmp_path):
    with pytest.raises(ValueError, match="outside workspace"):
        _safe_resolve(tmp_path, "../outside.txt")


def test_safe_resolve_deep_traversal_rejected(tmp_path):
    with pytest.raises(ValueError, match="outside workspace"):
        _safe_resolve(tmp_path, "a/b/../../../../../../etc/passwd")


# ---------------------------------------------------------------------------
# ReadFileTool
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_read_file_basic(tmp_path):
    (tmp_path / "hello.txt").write_text("hello world\n")
    tool = ReadFileTool(workspace=tmp_path)
    result = await tool.execute({"file_path": "hello.txt"})
    assert result.success
    assert result.result == "hello world\n"
    assert result.metadata["size"] == 12
    assert result.metadata["lines"] == 2


@pytest.mark.asyncio
async def test_read_file_not_found(tmp_path):
    tool = ReadFileTool(workspace=tmp_path)
    result = await tool.execute({"file_path": "missing.txt"})
    assert not result.success
    assert "not found" in result.error.lower()


@pytest.mark.asyncio
async def test_read_file_traversal_rejected(tmp_path):
    tool = ReadFileTool(workspace=tmp_path)
    result = await tool.execute({"file_path": "../outside.txt"})
    assert not result.success
    assert "outside workspace" in result.error


# ---------------------------------------------------------------------------
# WriteFileTool — full write
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_write_file_full_write(tmp_path):
    tool = WriteFileTool(workspace=tmp_path)
    result = await tool.execute({"file_path": "new.txt", "content": "line1\nline2\n"})
    assert result.success
    assert result.metadata["operation"] == "write"
    assert (tmp_path / "new.txt").read_text() == "line1\nline2\n"


@pytest.mark.asyncio
async def test_write_file_creates_parent_dirs(tmp_path):
    tool = WriteFileTool(workspace=tmp_path)
    result = await tool.execute({"file_path": "a/b/c.txt", "content": "deep"})
    assert result.success
    assert (tmp_path / "a" / "b" / "c.txt").read_text() == "deep"


@pytest.mark.asyncio
async def test_write_file_traversal_rejected(tmp_path):
    tool = WriteFileTool(workspace=tmp_path)
    result = await tool.execute({"file_path": "../escape.txt", "content": "bad"})
    assert not result.success
    assert "outside workspace" in result.error


# ---------------------------------------------------------------------------
# WriteFileTool — str_replace
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_write_file_str_replace(tmp_path):
    (tmp_path / "code.py").write_text("def foo():\n    pass\n")
    tool = WriteFileTool(workspace=tmp_path)
    result = await tool.execute({"file_path": "code.py", "old_str": "pass", "new_str": "return 42"})
    assert result.success
    assert result.metadata["operation"] == "str_replace"
    assert (tmp_path / "code.py").read_text() == "def foo():\n    return 42\n"


@pytest.mark.asyncio
async def test_write_file_str_replace_only_first_occurrence(tmp_path):
    (tmp_path / "f.txt").write_text("aaa aaa aaa")
    tool = WriteFileTool(workspace=tmp_path)
    result = await tool.execute({"file_path": "f.txt", "old_str": "aaa", "new_str": "bbb"})
    assert result.success
    assert (tmp_path / "f.txt").read_text() == "bbb aaa aaa"


@pytest.mark.asyncio
async def test_write_file_str_replace_not_found(tmp_path):
    (tmp_path / "f.txt").write_text("hello")
    tool = WriteFileTool(workspace=tmp_path)
    result = await tool.execute({"file_path": "f.txt", "old_str": "world", "new_str": "X"})
    assert not result.success
    assert "not found" in result.error.lower()


# ---------------------------------------------------------------------------
# WriteFileTool — insert_at_line
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_write_file_insert_at_line(tmp_path):
    (tmp_path / "f.txt").write_text("line1\nline3\n")
    tool = WriteFileTool(workspace=tmp_path)
    result = await tool.execute({"file_path": "f.txt", "insert_line": 1, "insert_content": "line2"})
    assert result.success
    assert result.metadata["operation"] == "insert_at_line"
    content = (tmp_path / "f.txt").read_text()
    assert content == "line1\nline2\nline3\n"


@pytest.mark.asyncio
async def test_write_file_insert_out_of_range(tmp_path):
    (tmp_path / "f.txt").write_text("line1\n")
    tool = WriteFileTool(workspace=tmp_path)
    result = await tool.execute({"file_path": "f.txt", "insert_line": 99, "insert_content": "extra"})
    assert not result.success
    assert "out of range" in result.error


@pytest.mark.asyncio
async def test_write_file_no_operation_specified(tmp_path):
    tool = WriteFileTool(workspace=tmp_path)
    result = await tool.execute({"file_path": "f.txt"})
    assert not result.success


# ---------------------------------------------------------------------------
# ListDirectoryTool
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_list_directory_basic(tmp_path):
    (tmp_path / "a.txt").write_text("a")
    (tmp_path / "b.txt").write_text("b")
    (tmp_path / "subdir").mkdir()
    tool = ListDirectoryTool(workspace=tmp_path)
    result = await tool.execute({})
    assert result.success
    types = [e["type"] for e in result.result]
    # directories listed before files
    assert types.index("directory") < types.index("file")
    assert result.metadata["count"] == 3


@pytest.mark.asyncio
async def test_list_directory_recursive(tmp_path):
    (tmp_path / "sub").mkdir()
    (tmp_path / "sub" / "nested.txt").write_text("x")
    (tmp_path / "top.txt").write_text("y")
    tool = ListDirectoryTool(workspace=tmp_path)
    result = await tool.execute({"recursive": True})
    assert result.success
    names = [e["name"] for e in result.result]
    assert any("nested.txt" in n for n in names)
    assert any("top.txt" in n for n in names)


@pytest.mark.asyncio
async def test_list_directory_not_a_dir(tmp_path):
    (tmp_path / "file.txt").write_text("x")
    tool = ListDirectoryTool(workspace=tmp_path)
    result = await tool.execute({"directory_path": "file.txt"})
    assert not result.success


@pytest.mark.asyncio
async def test_list_directory_traversal_rejected(tmp_path):
    tool = ListDirectoryTool(workspace=tmp_path)
    result = await tool.execute({"directory_path": "../"})
    assert not result.success
    assert "outside workspace" in result.error


# ---------------------------------------------------------------------------
# GrepSearchTool — rg → grep fallback
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_grep_rg_finds_match(tmp_path):
    (tmp_path / "source.py").write_text("def hello():\n    pass\n")
    tool = GrepSearchTool(workspace=tmp_path)
    result = await tool.execute({"pattern": "hello"})
    assert result.success
    assert len(result.result) >= 1
    assert any("hello" in m["text"] for m in result.result)


@pytest.mark.asyncio
async def test_grep_rg_not_found_fallback_to_grep(tmp_path, monkeypatch):
    (tmp_path / "file.txt").write_text("needle in haystack\n")
    tool = GrepSearchTool(workspace=tmp_path)

    original_exec = asyncio.create_subprocess_exec

    async def selective_exec(*args, **kwargs):
        if str(args[0]) == "rg":
            raise FileNotFoundError("rg not found")
        return await original_exec(*args, **kwargs)

    monkeypatch.setattr(asyncio, "create_subprocess_exec", selective_exec)
    result = await tool.execute({"pattern": "needle"})
    assert result.success
    assert any("needle" in m["text"] for m in result.result)


@pytest.mark.asyncio
async def test_grep_no_match_returns_empty(tmp_path):
    (tmp_path / "file.txt").write_text("no match here\n")
    tool = GrepSearchTool(workspace=tmp_path)
    result = await tool.execute({"pattern": "xyz_not_present"})
    assert result.success
    assert result.result == []


@pytest.mark.asyncio
async def test_grep_traversal_rejected(tmp_path):
    tool = GrepSearchTool(workspace=tmp_path)
    result = await tool.execute({"pattern": "x", "path": "../"})
    assert not result.success
    assert "outside workspace" in result.error


# ---------------------------------------------------------------------------
# BashExecuteTool
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_bash_execute_basic_command(tmp_path):
    tool = BashExecuteTool(workspace=tmp_path)
    result = await tool.execute({"command": "echo hello"})
    assert result.success
    assert "hello" in result.result["stdout"]
    assert result.metadata["returncode"] == 0


@pytest.mark.asyncio
async def test_bash_execute_captures_stderr(tmp_path):
    tool = BashExecuteTool(workspace=tmp_path)
    result = await tool.execute({"command": "echo err >&2; exit 1"})
    assert not result.success
    assert "err" in result.result["stderr"]
    assert result.metadata["returncode"] != 0


@pytest.mark.asyncio
async def test_bash_execute_timeout(tmp_path):
    tool = BashExecuteTool(workspace=tmp_path, timeout=1)
    result = await tool.execute({"command": "sleep 30"})
    assert not result.success
    assert "timed out" in result.error.lower()


@pytest.mark.asyncio
async def test_bash_execute_runs_in_workspace(tmp_path):
    tool = BashExecuteTool(workspace=tmp_path)
    result = await tool.execute({"command": "pwd"})
    assert result.success
    assert str(tmp_path) in result.result["stdout"].strip()


# ---------------------------------------------------------------------------
# PythonREPLTool
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_python_repl_stdout_capture(tmp_path):
    tool = PythonREPLTool(workspace=tmp_path)
    result = await tool.execute({"code": "print('hello repl')"})
    assert result.success
    assert "hello repl" in result.result


@pytest.mark.asyncio
async def test_python_repl_error_capture(tmp_path):
    tool = PythonREPLTool(workspace=tmp_path)
    result = await tool.execute({"code": "raise ValueError('bad input')"})
    assert not result.success
    assert "ValueError" in result.error
    assert "bad input" in result.error


@pytest.mark.asyncio
async def test_python_repl_no_output(tmp_path):
    tool = PythonREPLTool(workspace=tmp_path)
    result = await tool.execute({"code": "x = 1 + 1"})
    assert result.success
    assert result.result is None


@pytest.mark.asyncio
async def test_python_repl_isolated_namespace(tmp_path):
    tool = PythonREPLTool(workspace=tmp_path)
    await tool.execute({"code": "secret = 42"})
    result = await tool.execute({"code": "print(secret)"})
    # Second call should not see 'secret' from the first — fresh namespace
    assert not result.success
    assert "NameError" in result.error


@pytest.mark.asyncio
async def test_python_repl_timeout(tmp_path):
    tool = PythonREPLTool(workspace=tmp_path, timeout=1)
    result = await tool.execute({"code": "import time\ntime.sleep(30)"})
    assert not result.success
    assert "timed out" in result.error.lower()


@pytest.mark.asyncio
async def test_python_repl_runs_in_workspace(tmp_path):
    tool = PythonREPLTool(workspace=tmp_path)
    result = await tool.execute({"code": "from pathlib import Path\nprint(Path.cwd())"})
    assert result.success
    assert str(tmp_path) in result.result.strip()


# ---------------------------------------------------------------------------
# create_coding_tools factory
# ---------------------------------------------------------------------------


def test_create_coding_tools_returns_all_six(tmp_path):
    tools = create_coding_tools(workspace=tmp_path)
    names = {t.name for t in tools}
    assert names == {
        "read_file",
        "write_file",
        "list_directory",
        "grep_search",
        "bash_execute",
        "python_repl",
    }


def test_coding_tools_config_builds_expected_bundle(tmp_path):
    config = CodingToolsConfig(
        workspace=tmp_path,
        bash_timeout=12,
        repl_timeout=7,
    )
    tools = config.build_tools()
    assert isinstance(tools[0], ReadFileTool)
    assert isinstance(tools[1], WriteFileTool)
    assert isinstance(tools[2], ListDirectoryTool)
    assert isinstance(tools[3], GrepSearchTool)
    assert isinstance(tools[4], BashExecuteTool)
    assert isinstance(tools[5], PythonREPLTool)
    assert tools[4]._to_config().timeout == 12
    assert tools[5]._to_config().timeout == 7


def test_read_file_tool_component_round_trip(tmp_path):
    tool = ReadFileTool(workspace=tmp_path)
    dumped = tool.dump_component()
    restored = ComponentLoader.load_component(dumped)
    assert isinstance(restored, ReadFileTool)
    assert restored._to_config() == tool._to_config()


def test_write_file_tool_component_round_trip(tmp_path):
    tool = WriteFileTool(workspace=tmp_path)
    dumped = tool.dump_component()
    restored = ComponentLoader.load_component(dumped)
    assert isinstance(restored, WriteFileTool)
    assert restored._to_config() == tool._to_config()


def test_list_directory_tool_component_round_trip(tmp_path):
    tool = ListDirectoryTool(workspace=tmp_path)
    dumped = tool.dump_component()
    restored = ComponentLoader.load_component(dumped)
    assert isinstance(restored, ListDirectoryTool)
    assert restored._to_config() == tool._to_config()


def test_grep_search_tool_component_round_trip(tmp_path):
    tool = GrepSearchTool(workspace=tmp_path)
    dumped = tool.dump_component()
    restored = ComponentLoader.load_component(dumped)
    assert isinstance(restored, GrepSearchTool)
    assert restored._to_config() == tool._to_config()


def test_bash_execute_tool_component_round_trip(tmp_path):
    tool = BashExecuteTool(workspace=tmp_path, timeout=12)
    dumped = tool.dump_component()
    restored = ComponentLoader.load_component(dumped)
    assert isinstance(restored, BashExecuteTool)
    assert restored._to_config() == tool._to_config()


def test_python_repl_tool_component_round_trip(tmp_path):
    tool = PythonREPLTool(workspace=tmp_path, timeout=9)
    dumped = tool.dump_component()
    restored = ComponentLoader.load_component(dumped)
    assert isinstance(restored, PythonREPLTool)
    assert restored._to_config() == tool._to_config()


def test_component_loader_supports_short_coding_tool_provider(tmp_path):
    restored = ComponentLoader.load_component(
        {
            "provider": "PythonREPLTool",
            "component_type": "tool",
            "config": {
                "workspace": str(tmp_path),
                "timeout": 7,
                "approval_mode": "always_require",
            },
        }
    )
    assert isinstance(restored, PythonREPLTool)
    assert restored._to_config().timeout == 7
