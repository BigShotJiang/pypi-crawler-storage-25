"""Tests for research tools (WebSearchTool, WebFetchTool, ArxivSearchTool, YouTubeCaptionTool).

Requires the research extras to be installed:
    uv sync --group test

Run with: uv run pytest tests/tools/test_research_tools.py -v
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

pytest.importorskip("bs4")
pytest.importorskip("html2text")
pytest.importorskip("arxiv")
pytest.importorskip("youtube_transcript_api")

from agentbyte.component import ComponentLoader  # noqa: E402
from agentbyte.tools.research_tools import (  # noqa: E402
    ArxivSearchTool,
    ExtractTextTool,
    GoogleSearchTool,
    ResearchToolsConfig,
    WebFetchTool,
    WebSearchTool,
    YouTubeCaptionTool,
    create_research_tools,
    _extract_video_id,
    _is_domain_allowed,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _mock_client(json_data=None, text_data=None, status_code=200):
    """Return an AsyncMock that behaves like httpx.AsyncClient as context manager."""
    mock_response = MagicMock()
    mock_response.json.return_value = json_data or {}
    mock_response.text = text_data or ""
    mock_response.status_code = status_code
    mock_response.raise_for_status = MagicMock()

    mock_client = AsyncMock()
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=None)
    mock_client.get = AsyncMock(return_value=mock_response)
    return mock_client


_SAMPLE_DDG = {
    "Heading": "Python",
    "AbstractText": "Python is a programming language.",
    "AbstractURL": "https://python.org/",
    "Results": [],
    "RelatedTopics": [
        {"FirstURL": "https://docs.python.org/", "Text": "Python Docs"},
        {"FirstURL": "https://pypi.org/", "Text": "PyPI"},
    ],
}


# ---------------------------------------------------------------------------
# _is_domain_allowed
# ---------------------------------------------------------------------------


def test_domain_allowed_no_lists():
    assert _is_domain_allowed("https://example.com/page", None, None) is True


def test_domain_blocked():
    assert _is_domain_allowed("https://evil.com/page", None, ["evil.com"]) is False


def test_subdomain_blocked():
    assert _is_domain_allowed("https://sub.evil.com/page", None, ["evil.com"]) is False


def test_domain_allowed_with_allowlist():
    assert _is_domain_allowed("https://good.com/page", ["good.com"], None) is True
    assert _is_domain_allowed("https://other.com/page", ["good.com"], None) is False


def test_blocked_takes_precedence_over_allowed():
    assert (
        _is_domain_allowed("https://good.com/page", ["good.com"], ["good.com"]) is False
    )


# ---------------------------------------------------------------------------
# _extract_video_id
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "url,expected",
    [
        ("https://www.youtube.com/watch?v=dQw4w9WgXcQ", "dQw4w9WgXcQ"),
        ("https://youtu.be/dQw4w9WgXcQ", "dQw4w9WgXcQ"),
        ("https://www.youtube.com/shorts/dQw4w9WgXcQ", "dQw4w9WgXcQ"),
        ("https://www.youtube.com/embed/dQw4w9WgXcQ", "dQw4w9WgXcQ"),
        ("https://www.youtube.com/v/dQw4w9WgXcQ", "dQw4w9WgXcQ"),
        ("https://example.com/not-youtube", None),
        ("https://youtu.be/", None),
    ],
)
def test_extract_video_id(url, expected):
    assert _extract_video_id(url) == expected


# ---------------------------------------------------------------------------
# WebSearchTool
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_web_search_returns_results():
    tool = WebSearchTool()
    mock_client = _mock_client(json_data=_SAMPLE_DDG)
    with patch("agentbyte.tools.research_tools.httpx.AsyncClient", return_value=mock_client):
        result = await tool.execute({"query": "python"})
    assert result.success
    assert isinstance(result.result, list)
    assert len(result.result) > 0
    assert all("url" in r and "snippet" in r for r in result.result)


@pytest.mark.asyncio
async def test_web_search_block_list():
    tool = WebSearchTool(blocked_domains=["pypi.org"])
    mock_client = _mock_client(json_data=_SAMPLE_DDG)
    with patch("agentbyte.tools.research_tools.httpx.AsyncClient", return_value=mock_client):
        result = await tool.execute({"query": "python"})
    assert result.success
    urls = [r["url"] for r in result.result]
    assert not any("pypi.org" in u for u in urls)
    assert result.metadata["filtered"] >= 1


@pytest.mark.asyncio
async def test_web_search_allow_list():
    tool = WebSearchTool(allowed_domains=["python.org"])
    mock_client = _mock_client(json_data=_SAMPLE_DDG)
    with patch("agentbyte.tools.research_tools.httpx.AsyncClient", return_value=mock_client):
        result = await tool.execute({"query": "python"})
    assert result.success
    urls = [r["url"] for r in result.result]
    assert all("python.org" in u for u in urls)


@pytest.mark.asyncio
async def test_web_search_max_results():
    tool = WebSearchTool()
    # DDG data has 3 results (abstract + 2 related topics)
    mock_client = _mock_client(json_data=_SAMPLE_DDG)
    with patch("agentbyte.tools.research_tools.httpx.AsyncClient", return_value=mock_client):
        result = await tool.execute({"query": "python", "max_results": 1})
    assert result.success
    assert len(result.result) == 1


@pytest.mark.asyncio
async def test_web_search_http_error_returns_failure():
    tool = WebSearchTool()
    mock_client = AsyncMock()
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=None)
    mock_client.get = AsyncMock(side_effect=Exception("network error"))
    with patch("agentbyte.tools.research_tools.httpx.AsyncClient", return_value=mock_client):
        result = await tool.execute({"query": "python"})
    assert not result.success
    assert "network error" in result.error


@pytest.mark.asyncio
async def test_google_search_placeholder_returns_not_implemented():
    tool = GoogleSearchTool(api_key="test-key", cse_id="test-cse")
    result = await tool.execute({"query": "python"})
    assert not result.success
    assert "not implemented yet" in result.error.lower()
    assert result.metadata["backend"] == "google_cse"


def test_create_research_tools_keeps_ddg_default_even_with_google_credentials():
    tools = create_research_tools(google_api_key="test-key", google_cse_id="test-cse")
    assert isinstance(tools[0], WebSearchTool)
    assert not isinstance(tools[0], GoogleSearchTool)


# ---------------------------------------------------------------------------
# WebFetchTool
# ---------------------------------------------------------------------------


_SAMPLE_HTML = (
    "<html><head></head><body>"
    "<script>alert('x')</script>"
    "<h1>Title</h1><p>Hello world content here.</p>"
    "</body></html>"
)


@pytest.mark.asyncio
async def test_web_fetch_markdown_format():
    tool = WebFetchTool()
    mock_client = _mock_client(text_data=_SAMPLE_HTML)
    with patch("agentbyte.tools.research_tools.httpx.AsyncClient", return_value=mock_client):
        result = await tool.execute({"url": "https://example.com"})
    assert result.success
    assert result.metadata["output_format"] == "markdown"
    assert "alert" not in result.result  # script stripped
    assert "Hello world" in result.result


@pytest.mark.asyncio
async def test_web_fetch_text_format():
    tool = WebFetchTool()
    mock_client = _mock_client(text_data=_SAMPLE_HTML)
    with patch("agentbyte.tools.research_tools.httpx.AsyncClient", return_value=mock_client):
        result = await tool.execute({"url": "https://example.com", "output_format": "text"})
    assert result.success
    assert "Hello world" in result.result


@pytest.mark.asyncio
async def test_web_fetch_html_format():
    tool = WebFetchTool()
    mock_client = _mock_client(text_data=_SAMPLE_HTML)
    with patch("agentbyte.tools.research_tools.httpx.AsyncClient", return_value=mock_client):
        result = await tool.execute({"url": "https://example.com", "output_format": "html"})
    assert result.success
    assert "<h1>" in result.result or "Title" in result.result


@pytest.mark.asyncio
async def test_web_fetch_truncates_at_max_length():
    long_content = "<html><body>" + ("x" * 200) + "</body></html>"
    tool = WebFetchTool(max_content_length=50)
    mock_client = _mock_client(text_data=long_content)
    with patch("agentbyte.tools.research_tools.httpx.AsyncClient", return_value=mock_client):
        result = await tool.execute({"url": "https://example.com"})
    assert result.success
    assert result.metadata["truncated"] is True
    assert len(result.result) <= 50


@pytest.mark.asyncio
async def test_web_fetch_not_truncated_when_short():
    tool = WebFetchTool(max_content_length=50_000)
    mock_client = _mock_client(text_data=_SAMPLE_HTML)
    with patch("agentbyte.tools.research_tools.httpx.AsyncClient", return_value=mock_client):
        result = await tool.execute({"url": "https://example.com"})
    assert result.success
    assert result.metadata["truncated"] is False


# ---------------------------------------------------------------------------
# ExtractTextTool
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_extract_text_inline_html_markdown():
    tool = ExtractTextTool()
    result = await tool.execute({"html": _SAMPLE_HTML, "output_format": "markdown"})
    assert result.success
    assert "Hello world" in result.result
    assert "alert" not in result.result
    assert result.metadata["source"] == "inline_html"


@pytest.mark.asyncio
async def test_extract_text_file_html(tmp_path):
    html_file = tmp_path / "page.html"
    html_file.write_text(_SAMPLE_HTML)
    tool = ExtractTextTool(workspace=tmp_path)
    result = await tool.execute({"file_path": "page.html", "output_format": "text"})
    assert result.success
    assert "Hello world" in result.result
    assert result.metadata["source"] == "page.html"


@pytest.mark.asyncio
async def test_extract_text_requires_exactly_one_source(tmp_path):
    tool = ExtractTextTool(workspace=tmp_path)
    result = await tool.execute({"html": _SAMPLE_HTML, "file_path": "page.html"})
    assert not result.success
    assert "exactly one" in result.error.lower()


@pytest.mark.asyncio
async def test_extract_text_rejects_workspace_traversal(tmp_path):
    tool = ExtractTextTool(workspace=tmp_path)
    result = await tool.execute({"file_path": "../escape.html"})
    assert not result.success
    assert "outside workspace" in result.error


@pytest.mark.asyncio
async def test_extract_text_truncates_output():
    tool = ExtractTextTool(max_content_length=20)
    result = await tool.execute({"html": "<html><body>" + ("x" * 100) + "</body></html>"})
    assert result.success
    assert result.metadata["truncated"] is True
    assert len(result.result) <= 20


# ---------------------------------------------------------------------------
# ArxivSearchTool
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_arxiv_search_calls_client(monkeypatch):
    import arxiv as _arxiv

    fake_result = MagicMock()
    fake_result.title = "Test Paper"
    fake_result.authors = [MagicMock(__str__=lambda s: "Author A")]
    fake_result.published = None
    fake_result.summary = "Summary text."
    fake_result.pdf_url = "https://arxiv.org/pdf/1234.5678"
    fake_result.entry_id = "https://arxiv.org/abs/1234.5678"

    mock_client_instance = MagicMock()
    mock_client_instance.results.return_value = iter([fake_result])
    monkeypatch.setattr(_arxiv, "Client", lambda: mock_client_instance)

    tool = ArxivSearchTool()
    result = await tool.execute({"query": "agents"})
    assert result.success
    assert len(result.result) == 1
    assert result.result[0]["title"] == "Test Paper"
    assert result.metadata["count"] == 1


@pytest.mark.asyncio
async def test_arxiv_search_error_returns_failure(monkeypatch):
    import arxiv as _arxiv

    mock_client_instance = MagicMock()
    mock_client_instance.results.side_effect = RuntimeError("network error")
    monkeypatch.setattr(_arxiv, "Client", lambda: mock_client_instance)

    tool = ArxivSearchTool()
    result = await tool.execute({"query": "agents"})
    assert not result.success
    assert "network error" in result.error


# ---------------------------------------------------------------------------
# YouTubeCaptionTool
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_youtube_caption_basic(monkeypatch):
    from youtube_transcript_api._transcripts import FetchedTranscript, FetchedTranscriptSnippet

    fake_snippets = [
        FetchedTranscriptSnippet(text="Hello world", start=0.0, duration=1.0),
        FetchedTranscriptSnippet(text="Second line", start=1.0, duration=1.0),
    ]
    fake_transcript = FetchedTranscript(
        snippets=fake_snippets,
        video_id="dQw4w9WgXcQ",
        language="English",
        language_code="en",
        is_generated=False,
    )

    mock_api = MagicMock()
    mock_api.fetch.return_value = fake_transcript
    monkeypatch.setattr("agentbyte.tools.research_tools.YouTubeTranscriptApi", lambda: mock_api)

    tool = YouTubeCaptionTool()
    result = await tool.execute({"url": "https://youtu.be/dQw4w9WgXcQ"})
    assert result.success
    assert "Hello world" in result.result
    assert result.metadata["video_id"] == "dQw4w9WgXcQ"
    assert result.metadata["segment_count"] == 2


@pytest.mark.asyncio
async def test_youtube_caption_invalid_url():
    tool = YouTubeCaptionTool()
    result = await tool.execute({"url": "https://example.com/not-a-video"})
    assert not result.success
    assert "Could not extract video ID" in result.error


@pytest.mark.asyncio
async def test_youtube_caption_fallback_language(monkeypatch):
    from youtube_transcript_api._transcripts import FetchedTranscript, FetchedTranscriptSnippet

    call_log: list[dict] = []
    fallback_snippets = [FetchedTranscriptSnippet(text="Fallback text", start=0.0, duration=1.0)]
    fallback_transcript = FetchedTranscript(
        snippets=fallback_snippets,
        video_id="abc123",
        language="English",
        language_code="en",
        is_generated=False,
    )

    def fake_fetch(video_id, languages=("en",)):
        call_log.append({"languages": list(languages)})
        if list(languages) == ["de"]:
            raise Exception("Language not available")
        return fallback_transcript

    mock_api = MagicMock()
    mock_api.fetch.side_effect = fake_fetch
    monkeypatch.setattr("agentbyte.tools.research_tools.YouTubeTranscriptApi", lambda: mock_api)

    tool = YouTubeCaptionTool()
    result = await tool.execute({"url": "https://youtu.be/abc123", "language": "de"})
    assert result.success
    assert "Fallback text" in result.result
    # First call with 'de', second call with default ('en')
    assert call_log[0]["languages"] == ["de"]


@pytest.mark.asyncio
async def test_youtube_caption_both_calls_fail(monkeypatch):
    mock_api = MagicMock()
    mock_api.fetch.side_effect = Exception("no captions available")
    monkeypatch.setattr("agentbyte.tools.research_tools.YouTubeTranscriptApi", lambda: mock_api)

    tool = YouTubeCaptionTool()
    result = await tool.execute({"url": "https://youtu.be/abc123"})
    assert not result.success
    assert "no captions" in result.error


# ---------------------------------------------------------------------------
# Component config / factory validation
# ---------------------------------------------------------------------------


def test_research_tools_config_builds_expected_bundle():
    config = ResearchToolsConfig(
        google_api_key="test-key",
        google_cse_id="test-cse",
        allowed_domains=["python.org"],
        fetch_timeout=12,
        fetch_max_length=123,
    )
    tools = config.build_tools()
    assert isinstance(tools[0], WebSearchTool)
    assert isinstance(tools[1], WebFetchTool)
    assert isinstance(tools[2], ExtractTextTool)
    assert isinstance(tools[3], ArxivSearchTool)
    assert isinstance(tools[4], YouTubeCaptionTool)


def test_web_search_tool_component_round_trip():
    tool = WebSearchTool(allowed_domains=["python.org"], blocked_domains=["evil.com"], timeout=12)
    dumped = tool.dump_component()
    restored = ComponentLoader.load_component(dumped)
    assert isinstance(restored, WebSearchTool)
    assert restored._to_config() == tool._to_config()


def test_google_search_tool_component_round_trip():
    tool = GoogleSearchTool(
        api_key="test-key",
        cse_id="test-cse",
        allowed_domains=["python.org"],
        blocked_domains=["evil.com"],
        default_language="lang_en",
        default_country="countryUS",
        default_safe_search="active",
        timeout=12,
    )
    dumped = tool.dump_component()
    restored = ComponentLoader.load_component(dumped)
    assert isinstance(restored, GoogleSearchTool)
    assert restored._to_config() == tool._to_config()


def test_web_fetch_tool_component_round_trip():
    tool = WebFetchTool(timeout=12, max_content_length=123)
    dumped = tool.dump_component()
    restored = ComponentLoader.load_component(dumped)
    assert isinstance(restored, WebFetchTool)
    assert restored._to_config() == tool._to_config()


def test_extract_text_tool_component_round_trip(tmp_path):
    tool = ExtractTextTool(workspace=tmp_path, max_content_length=123)
    dumped = tool.dump_component()
    restored = ComponentLoader.load_component(dumped)
    assert isinstance(restored, ExtractTextTool)
    assert restored._to_config() == tool._to_config()


def test_component_loader_supports_short_research_tool_provider():
    restored = ComponentLoader.load_component(
        {
            "provider": "WebFetchTool",
            "component_type": "tool",
            "config": {"timeout": 12, "max_content_length": 123},
        }
    )
    assert isinstance(restored, WebFetchTool)
    assert restored._to_config().timeout == 12
