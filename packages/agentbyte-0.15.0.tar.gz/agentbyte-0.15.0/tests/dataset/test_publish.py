from __future__ import annotations

import io
import json
from pathlib import Path

import pytest

from agentbyte.dataset import publish_dataset
from agentbyte.dataset.config import LocalDatasetConfig
from agentbyte.dataset.publish_config import S3DatasetPublishConfig
from agentbyte.dataset.publishers import PublishedDatasetRef, S3DatasetPublisher


def _write_dataset(
    dataset_dir: Path,
    *,
    engine: str = "sqlite",
    table_name: str = "contracts_asmd",
    schema: list[dict[str, object]] | None = None,
    data: object | None = None,
) -> None:
    dataset_dir.mkdir(parents=True, exist_ok=True)
    (dataset_dir / "config.json").write_text(
        json.dumps(
            {
                "engine": engine,
                "table_name": table_name,
                "in_memory": True,
                "description": "Test dataset",
            }
        ),
        encoding="utf-8",
    )
    if schema is not None:
        (dataset_dir / "schema.json").write_text(json.dumps(schema), encoding="utf-8")
    if data is None:
        data = {"records": [{"id": "1", "name": "Acme"}]}
    (dataset_dir / "data.json").write_text(json.dumps(data), encoding="utf-8")


class _FakeClientError(Exception):
    def __init__(self, code: str) -> None:
        super().__init__(code)
        self.response = {"Error": {"Code": code}}


class FakeS3PublishClient:
    def __init__(self) -> None:
        self.objects: dict[str, bytes] = {}
        self.put_calls: list[tuple[str, str, bytes]] = []

    def put_object(self, *, Bucket: str, Key: str, Body: bytes | io.BytesIO | str) -> None:
        if isinstance(Body, io.BytesIO):
            payload = Body.read()
        elif isinstance(Body, str):
            payload = Body.encode("utf-8")
        else:
            payload = Body
        self.objects[f"{Bucket}/{Key}"] = payload
        self.put_calls.append((Bucket, Key, payload))

    def head_object(self, *, Bucket: str, Key: str) -> dict[str, object]:
        if f"{Bucket}/{Key}" not in self.objects:
            raise _FakeClientError("NoSuchKey")
        return {}


def test_publish_dataset_to_s3_with_sqlite_schema(tmp_path: Path) -> None:
    dataset_root = tmp_path / "samples"
    _write_dataset(
        dataset_root / "contracts10" / "asmd",
        engine="sqlite",
        schema=[{"name": "id", "type": "TEXT", "primary_key": True}],
    )
    fake_client = FakeS3PublishClient()
    publish_config = S3DatasetPublishConfig(
        s3_bucket="agentbyte-datasets",
        s3_prefix="shared",
    )
    publisher = S3DatasetPublisher(publish_config, client=fake_client)

    result = publisher.publish_dataset("contracts10/asmd", dataset_root / "contracts10" / "asmd")

    assert result == PublishedDatasetRef(
        dataset_id="contracts10/asmd",
        destination_uri="s3://agentbyte-datasets/shared/contracts10/asmd",
        uploaded_files=["config.json", "data.json", "schema.json"],
    )
    assert [key for _, key, _ in fake_client.put_calls] == [
        "shared/contracts10/asmd/config.json",
        "shared/contracts10/asmd/data.json",
        "shared/contracts10/asmd/schema.json",
    ]


def test_publish_dataset_to_s3_without_schema_for_json_dataset(tmp_path: Path) -> None:
    dataset_root = tmp_path / "samples"
    _write_dataset(
        dataset_root / "documents" / "wiki",
        engine="json",
        schema=None,
        data={"records": [{"title": "Doc"}]},
    )
    fake_client = FakeS3PublishClient()

    result = publish_dataset(
        "documents/wiki",
        local_config=LocalDatasetConfig(local_root=dataset_root),
        publish_config=_InlineS3PublishConfig(
            bucket="agentbyte-datasets",
            prefix="datasets",
            client=fake_client,
        ),
    )

    assert result.destination_uri == "s3://agentbyte-datasets/datasets/documents/wiki"
    assert result.uploaded_files == ["config.json", "data.json"]
    assert [key for _, key, _ in fake_client.put_calls] == [
        "datasets/documents/wiki/config.json",
        "datasets/documents/wiki/data.json",
    ]


def test_publish_dataset_raises_for_missing_local_dataset_dir(tmp_path: Path) -> None:
    with pytest.raises(FileNotFoundError, match="Dataset not found at"):
        publish_dataset(
            "contracts10/asmd",
            local_config=LocalDatasetConfig(local_root=tmp_path),
            publish_config=_InlineS3PublishConfig(
                bucket="agentbyte-datasets",
                prefix="datasets",
                client=FakeS3PublishClient(),
            ),
        )


def test_publish_dataset_raises_for_missing_required_file(tmp_path: Path) -> None:
    dataset_root = tmp_path / "samples"
    dataset_dir = dataset_root / "contracts10" / "asmd"
    dataset_dir.mkdir(parents=True)
    (dataset_dir / "config.json").write_text("{}", encoding="utf-8")

    with pytest.raises(FileNotFoundError, match="Required dataset file not found"):
        publish_dataset(
            "contracts10/asmd",
            local_config=LocalDatasetConfig(local_root=dataset_root),
            publish_config=_InlineS3PublishConfig(
                bucket="agentbyte-datasets",
                prefix="datasets",
                client=FakeS3PublishClient(),
            ),
        )


def test_publish_dataset_rejects_invalid_dataset_id(tmp_path: Path) -> None:
    with pytest.raises(ValueError, match="Dataset ID must be 'category/name'"):
        publish_dataset(
            "contracts10",
            local_config=LocalDatasetConfig(local_root=tmp_path),
            publish_config=_InlineS3PublishConfig(
                bucket="agentbyte-datasets",
                prefix="datasets",
                client=FakeS3PublishClient(),
            ),
        )


def test_publish_dataset_normalizes_prefix_with_trailing_slash(tmp_path: Path) -> None:
    dataset_root = tmp_path / "samples"
    _write_dataset(dataset_root / "contracts10" / "asmd")
    fake_client = FakeS3PublishClient()

    result = publish_dataset(
        "contracts10/asmd",
        local_config=LocalDatasetConfig(local_root=dataset_root),
        publish_config=_InlineS3PublishConfig(
            bucket="agentbyte-datasets",
            prefix="datasets/",
            client=fake_client,
        ),
    )

    assert result.destination_uri == "s3://agentbyte-datasets/datasets/contracts10/asmd"
    assert [key for _, key, _ in fake_client.put_calls] == [
        "datasets/contracts10/asmd/config.json",
        "datasets/contracts10/asmd/data.json",
    ]


def test_publish_dataset_uses_dataset_id_path_when_no_prefix(tmp_path: Path) -> None:
    dataset_root = tmp_path / "samples"
    _write_dataset(
        dataset_root / "contracts10" / "asmd",
        schema=[{"name": "id", "type": "TEXT", "primary_key": True}],
    )
    fake_client = FakeS3PublishClient()

    result = publish_dataset(
        "contracts10/asmd",
        local_config=LocalDatasetConfig(local_root=dataset_root),
        publish_config=_InlineS3PublishConfig(
            bucket="agentbyte-datasets",
            prefix="",
            client=fake_client,
        ),
    )

    assert result.destination_uri == "s3://agentbyte-datasets/contracts10/asmd"
    assert [key for _, key, _ in fake_client.put_calls] == [
        "contracts10/asmd/config.json",
        "contracts10/asmd/data.json",
        "contracts10/asmd/schema.json",
    ]


class _InlineS3PublishConfig(S3DatasetPublishConfig):
    client: object | None = None

    def __init__(self, *, bucket: str, prefix: str, client: object) -> None:
        super().__init__(s3_bucket=bucket, s3_prefix=prefix)
        object.__setattr__(self, "client", client)

    def build_publisher(self) -> S3DatasetPublisher:
        return S3DatasetPublisher(self, client=self.client)
