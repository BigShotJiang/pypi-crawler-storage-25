"""LLM-powered evaluation judge."""

from __future__ import annotations

import json
from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from agentbyte.cancellation_token import CancellationToken
from agentbyte.llm.base import BaseChatCompletionClient
from agentbyte.messages import SystemMessage, UserMessage

from agentbyte.eval.base import BaseEvalJudge
from agentbyte.eval.types import AnswerStrategy, EvalScore, EvalTrajectory


class _JudgeCriterionScore(BaseModel):
    criterion: str
    score: float = Field(ge=0.0, le=10.0)
    reasoning: str


class _JudgeStructuredResponse(BaseModel):
    # overall is nullable but must appear in the JSON response (OpenAI strict mode
    # requires every property to be in `required`; ge/le only validate non-None values).
    model_config = ConfigDict(json_schema_extra={"required": ["overall", "scores"]})

    overall: float | None = Field(default=None, ge=0.0, le=10.0)
    scores: list[_JudgeCriterionScore]


# Kept for the use_structured_output=False fallback path.
class _JudgeResponse(BaseModel):
    model_config = ConfigDict(extra="allow")

    overall: float | None = None
    dimensions: dict[str, float] = Field(default_factory=dict)
    reasoning: dict[str, str] = Field(default_factory=dict)


class LLMEvalJudge(BaseEvalJudge):
    """Use an LLM to judge a trajectory on one or more criteria."""

    def __init__(
        self,
        client: BaseChatCompletionClient,
        *,
        name: str | None = None,
        answer_strategy: AnswerStrategy = "last_non_empty",
        source_filter: str | None = None,
        default_criteria: list[str] | None = None,
        custom_instructions: str | None = None,
        use_structured_output: bool = True,
    ) -> None:
        super().__init__(
            name=name or f"LLM-{client.model}",
            answer_strategy=answer_strategy,
            source_filter=source_filter,
        )
        self.client = client
        self.default_criteria = default_criteria or [
            "accuracy",
            "completeness",
            "helpfulness",
        ]
        self.custom_instructions = custom_instructions
        self.use_structured_output = use_structured_output

    async def score(
        self,
        trajectory: EvalTrajectory,
        criteria: list[str] | None = None,
        cancellation_token: CancellationToken | None = None,
    ) -> EvalScore:
        # resolve: call-level arg > task metadata > judge default
        if criteria is None:
            raw = trajectory.task.metadata.get("_criteria")
            if isinstance(raw, list):
                criteria = raw
            elif isinstance(raw, str):
                criteria = [raw]
        eval_criteria = criteria or self.default_criteria
        if cancellation_token and cancellation_token.is_cancelled():
            return self._neutral_score(
                trajectory,
                eval_criteria,
                reason_prefix="Evaluation cancelled",
            )

        answer = self.extract_answer(trajectory)
        expected_output = trajectory.task.expected_output
        user_payload = {
            "task_name": trajectory.task.name,
            "task_input": trajectory.task.input,
            "expected_output": expected_output,
            "actual_output": answer,
            "success": trajectory.success,
            "error": trajectory.error,
            "criteria": eval_criteria,
            "usage": trajectory.usage.model_dump(mode="json")
            if trajectory.usage is not None
            else None,
            "metadata": trajectory.metadata,
        }

        try:
            if self.use_structured_output:
                result = await self.client.create(
                    messages=[
                        SystemMessage(
                            content=self._build_structured_prompt(eval_criteria),
                            source="system",
                        ),
                        UserMessage(
                            content=json.dumps(user_payload, ensure_ascii=True, indent=2),
                            source="user",
                        ),
                    ],
                    output_format=_JudgeStructuredResponse,
                )
                structured = result.structured_output
                if not isinstance(structured, _JudgeStructuredResponse):
                    raise ValueError(
                        f"Expected _JudgeStructuredResponse, got {type(structured)}"
                    )
                overall, dimensions, reasoning = self._normalize_structured_response(
                    structured, eval_criteria
                )
            else:
                result = await self.client.create(
                    messages=[
                        SystemMessage(
                            content=self._build_raw_prompt(),
                            source="system",
                        ),
                        UserMessage(
                            content=json.dumps(user_payload, ensure_ascii=True, indent=2),
                            source="user",
                        ),
                    ],
                )
                parsed = self._parse_response(None, result.message.content)
                dimensions = self._normalize_dimensions(parsed.dimensions, eval_criteria)
                reasoning = {
                    criterion: parsed.reasoning.get(criterion, "No reasoning provided")
                    for criterion in eval_criteria
                }
                overall = parsed.overall
                if overall is None:
                    overall = sum(dimensions.values()) / max(len(dimensions), 1)
                overall = self._clamp_score(overall)

            return EvalScore(
                overall=overall,
                dimensions=dimensions,
                reasoning=reasoning,
                trajectory=trajectory,
                metadata={
                    "judge": self.name,
                    "model": result.model,
                    "finish_reason": result.finish_reason,
                },
            )
        except Exception as exc:
            return self._neutral_score(
                trajectory,
                eval_criteria,
                reason_prefix=f"Judge fallback: {exc}",
            )

    def _build_structured_prompt(self, criteria: list[str]) -> str:
        criteria_list = ", ".join(f'"{c}"' for c in criteria)
        prompt = (
            "You are an evaluation judge. "
            f"Score the following criteria: [{criteria_list}]. "
            "Return one scores[] entry per criterion. "
            "Each criterion name must match exactly as given. "
            "Score each 0–10. "
            "Also provide an overall score 0–10."
        )
        if self.custom_instructions:
            prompt += f"\n\nAdditional instructions:\n{self.custom_instructions.strip()}"
        return prompt

    def _build_raw_prompt(self) -> str:
        prompt = (
            "You are an evaluation judge. "
            "Return ONLY a strict JSON object with exactly these keys:\n"
            '  "overall": <float 0-10>,\n'
            '  "dimensions": {"<criterion>": <float 0-10>, ...},\n'
            '  "reasoning": {"<criterion>": "<explanation string>", ...}\n'
            "The `reasoning` value MUST be an object (dict) — one key per criterion, "
            "never a plain string. No extra keys, no markdown, no prose outside the JSON."
        )
        if self.custom_instructions:
            prompt += f"\n\nAdditional instructions:\n{self.custom_instructions.strip()}"
        return prompt

    def _normalize_structured_response(
        self,
        response: _JudgeStructuredResponse,
        criteria: list[str],
    ) -> tuple[float, dict[str, float], dict[str, str]]:
        # last-wins for duplicate criterion entries
        score_lookup: dict[str, _JudgeCriterionScore] = {}
        for item in response.scores:
            score_lookup[item.criterion] = item

        dimensions = {
            c: self._clamp_score(score_lookup[c].score) if c in score_lookup else 5.0
            for c in criteria
        }
        reasoning = {
            c: score_lookup[c].reasoning if c in score_lookup else "No reasoning provided"
            for c in criteria
        }
        overall = response.overall
        if overall is None:
            overall = sum(dimensions.values()) / max(len(dimensions), 1)
        return self._clamp_score(overall), dimensions, reasoning

    # --- raw JSON fallback path (use_structured_output=False) ---

    def _parse_response(
        self,
        structured_output: Any,
        raw_content: str,
    ) -> _JudgeResponse:
        if isinstance(structured_output, _JudgeResponse):
            return structured_output
        if isinstance(structured_output, BaseModel):
            return _JudgeResponse.model_validate(self._coerce_raw(structured_output.model_dump()))
        if structured_output is not None:
            return _JudgeResponse.model_validate(self._coerce_raw(structured_output))
        raw = json.loads(raw_content)
        return _JudgeResponse.model_validate(self._coerce_raw(raw))

    @staticmethod
    def _coerce_raw(raw: Any) -> Any:
        """Coerce `reasoning` to dict if the LLM returned it as a plain string."""
        if not isinstance(raw, dict):
            return raw
        reasoning = raw.get("reasoning")
        if isinstance(reasoning, str):
            raw = {**raw, "reasoning": {"_default": reasoning}}
        return raw

    def _normalize_dimensions(
        self,
        dimensions: dict[str, float],
        criteria: list[str],
    ) -> dict[str, float]:
        return {
            criterion: self._clamp_score(dimensions.get(criterion, 5.0))
            for criterion in criteria
        }

    def _neutral_score(
        self,
        trajectory: EvalTrajectory,
        criteria: list[str],
        *,
        reason_prefix: str,
    ) -> EvalScore:
        return EvalScore(
            overall=5.0,
            dimensions={criterion: 5.0 for criterion in criteria},
            reasoning={criterion: reason_prefix for criterion in criteria},
            trajectory=trajectory,
            metadata={"judge": self.name, "fallback": True},
        )

    @staticmethod
    def _clamp_score(value: float) -> float:
        return min(max(float(value), 0.0), 10.0)


__all__ = ["LLMEvalJudge"]
