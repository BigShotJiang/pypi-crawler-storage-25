"""Dataset publishing configuration contracts.

Publishing configs mirror dataset source configs: each config object holds the
parameters for one publish target and constructs the matching publisher.
"""

from __future__ import annotations

from abc import ABC, abstractmethod

from pydantic_settings import BaseSettings, SettingsConfigDict

if False:  # pragma: no cover
    from agentbyte.dataset.publishers import DatasetPublisher


class DatasetPublishConfig(ABC):
    """Abstract base for all dataset publish target configurations."""

    @abstractmethod
    def build_publisher(self) -> "DatasetPublisher":
        """Build and return the dataset publisher for this configuration."""


class S3DatasetPublishConfig(DatasetPublishConfig, BaseSettings):
    """Configuration for publishing datasets into an S3 bucket."""

    model_config = SettingsConfigDict(env_prefix="AGENTBYTE_DATASET_", extra="ignore")

    s3_bucket: str
    s3_region: str = "eu-west-1"
    s3_prefix: str = ""
    overwrite_existing: bool = True

    def build_publisher(self) -> "DatasetPublisher":
        from agentbyte.dataset.publishers import S3DatasetPublisher

        return S3DatasetPublisher(self)


__all__ = ["DatasetPublishConfig", "S3DatasetPublishConfig"]
