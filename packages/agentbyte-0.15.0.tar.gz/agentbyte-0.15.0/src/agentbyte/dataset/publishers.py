"""Dataset publisher abstractions and concrete implementations."""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path

from pydantic import BaseModel, ConfigDict, Field

if False:  # pragma: no cover
    from agentbyte.dataset.publish_config import S3DatasetPublishConfig


class PublishedDatasetRef(BaseModel):
    """Reference to a published dataset artifact."""

    model_config = ConfigDict(frozen=True)

    dataset_id: str
    destination_uri: str
    uploaded_files: list[str] = Field(default_factory=list)


class DatasetPublisher(ABC):
    """Abstract base for dataset publishers."""

    @abstractmethod
    def publish_dataset(self, dataset_id: str, dataset_dir: Path) -> PublishedDatasetRef:
        """Publish a local dataset directory and return its published reference."""


class S3DatasetPublisher(DatasetPublisher):
    """Publish dataset files into an S3 bucket under the canonical dataset path."""

    def __init__(
        self,
        config: "S3DatasetPublishConfig",
        client: object | None = None,
    ) -> None:
        self.config = config
        self._client = client

    def publish_dataset(self, dataset_id: str, dataset_dir: Path) -> PublishedDatasetRef:
        uploaded_files: list[str] = []
        for filename in ("config.json", "data.json", "schema.json"):
            path = dataset_dir / filename
            if not path.exists():
                if filename == "schema.json":
                    continue
                raise FileNotFoundError(f"Required dataset file not found: {path}")
            key = self._build_key(dataset_id, filename)
            body = path.read_bytes()
            if not self.config.overwrite_existing:
                self._ensure_not_exists(key)
            self._get_client().put_object(Bucket=self.config.s3_bucket, Key=key, Body=body)
            uploaded_files.append(filename)

        return PublishedDatasetRef(
            dataset_id=dataset_id,
            destination_uri=f"s3://{self.config.s3_bucket}/{self._dataset_prefix(dataset_id)}",
            uploaded_files=uploaded_files,
        )

    def _dataset_prefix(self, dataset_id: str) -> str:
        prefix = self.config.s3_prefix.strip("/")
        return f"{prefix}/{dataset_id}" if prefix else dataset_id

    def _build_key(self, dataset_id: str, filename: str) -> str:
        return f"{self._dataset_prefix(dataset_id)}/{filename}"

    def _ensure_not_exists(self, key: str) -> None:
        client = self._get_client()
        try:
            if hasattr(client, "head_object"):
                client.head_object(Bucket=self.config.s3_bucket, Key=key)
            else:
                client.get_object(Bucket=self.config.s3_bucket, Key=key)
        except Exception as exc:
            if self._is_not_found_error(exc):
                return
            raise
        raise FileExistsError(f"Dataset object already exists: s3://{self.config.s3_bucket}/{key}")

    @staticmethod
    def _is_not_found_error(exc: Exception) -> bool:
        error_response = getattr(exc, "response", None)
        if not isinstance(error_response, dict):
            return False
        error = error_response.get("Error", {})
        code = str(error.get("Code", "")).lower()
        return code in {"nosuchkey", "notfound", "404"}

    def _get_client(self) -> object:
        if self._client is None:
            try:
                import boto3
            except ImportError as exc:
                raise ImportError(
                    "S3 dataset publishing requires boto3. Install the AWS dependency group first."
                ) from exc

            self._client = boto3.client("s3", region_name=self.config.s3_region)
        return self._client


__all__ = ["DatasetPublisher", "PublishedDatasetRef", "S3DatasetPublisher"]
