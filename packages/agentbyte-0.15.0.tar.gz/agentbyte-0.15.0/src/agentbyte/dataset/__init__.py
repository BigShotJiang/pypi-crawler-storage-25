"""Dataset loading and storage module for Agentbyte.

This module provides schema-driven dataset loading from JSON into engine-specific
backends. Currently supports:
    - SQLite: Structured data with strict schema and SQL queries
    - JSON: Semi-structured data with flexible JSON format

Architecture:
    Source Configs (config.py):
        - DatasetSourceConfig: Abstract base for all source configs
        - LocalDatasetConfig: Local filesystem datasets with explicit root path
        - S3DatasetConfig: S3-hosted datasets with bucket/region/prefix

    Publish Configs (publish_config.py):
        - DatasetPublishConfig: Abstract base for publish targets
        - S3DatasetPublishConfig: S3 publish target with bucket/region/prefix

    Generic Classes (base.py):
        - Column: Column definition (engine-agnostic)
        - Schema: Schema definition (engine-agnostic)
        - BaseDataset: Abstract interface for all dataset types
        - DatasetConfig: Configuration (engine, table name, etc.)
        - SchemaFormat: Display format enum

    SQLite-Specific Classes (sqlite.py):
        - SqliteColumn: Column with SQL constraints
        - SqliteSchema: Schema with SQL generation and formatted display
        - SQLiteDataset: SQLite implementation with JSON loading

    JSON-Specific Classes (json.py):
        - JSONDataset: JSON file-based dataset storage

    Loader:
        - load_dataset(): Factory function. Pass a config object to select
          source and parameters.
        - register_engine(): Register a custom engine class.
        - publish_dataset(): Publish an existing local dataset artifact.

Public API:
    Source configs:
        DatasetSourceConfig: Abstract base (extend for custom sources)
        LocalDatasetConfig: Load datasets from a local root directory
        S3DatasetConfig: Load datasets from an S3 bucket
        DatasetPublishConfig: Abstract base (extend for custom publish targets)
        S3DatasetPublishConfig: Publish datasets to an S3 bucket

    From base.py:
        Column, Schema, DatasetConfig, SchemaFormat, BaseDataset

    From sqlite.py:
        SqliteColumn, SqliteSchema, SQLiteDataset

    From json.py:
        JSONDataset

    Loader:
        load_dataset(): Routes to correct implementation based on config.engine
        register_engine(): Add a custom engine to the registry
        publish_dataset(): Publish a local dataset via a configured publisher

Engine-agnostic access:
    Use ``ds.fetch_all()`` to retrieve all rows as ``list[dict[str, Any]]``
    regardless of engine. Use ``ds.connect()`` only for engine-specific queries
    (e.g. SQL on SQLiteDataset).

Example:
    >>> from pathlib import Path
    >>> from agentbyte.dataset import load_dataset, register_engine
    >>> from agentbyte.dataset.config import LocalDatasetConfig

    >>> # Local dataset — engine-agnostic
    >>> ds = load_dataset("contracts/asmd", LocalDatasetConfig(local_root=Path("/data")))
    >>> rows = ds.fetch_all()

    >>> # SQLite-specific SQL query
    >>> from agentbyte.dataset import SQLiteDataset
    >>> assert isinstance(ds, SQLiteDataset)
    >>> conn = ds.connect()
    >>> rows = conn.execute("SELECT * FROM contracts_asmd").fetchall()
"""

from agentbyte.dataset.base import (
    BaseDataset,
    Column,
    DatasetConfig,
    Schema,
    SchemaFormat,
)
from agentbyte.dataset.config import DatasetSourceConfig, LocalDatasetConfig, S3DatasetConfig
from agentbyte.dataset.json import JSONDataset
from agentbyte.dataset.loader import load_dataset, register_engine
from agentbyte.dataset.publish import publish_dataset
from agentbyte.dataset.publish_config import DatasetPublishConfig, S3DatasetPublishConfig
from agentbyte.dataset.publishers import DatasetPublisher, PublishedDatasetRef, S3DatasetPublisher
from agentbyte.dataset.sqlite import (
    SQLiteDataset,
    SqliteColumn,
    SqliteSchema,
)

__all__ = [
    # Source configuration
    "DatasetSourceConfig",
    "LocalDatasetConfig",
    "S3DatasetConfig",
    "DatasetPublishConfig",
    "S3DatasetPublishConfig",
    # Schema definitions
    "Column",
    "SqliteColumn",
    "Schema",
    "SqliteSchema",
    "SchemaFormat",
    # Configuration
    "DatasetConfig",
    # Base interface
    "BaseDataset",
    # Implementations
    "SQLiteDataset",
    "JSONDataset",
    "DatasetPublisher",
    "S3DatasetPublisher",
    "PublishedDatasetRef",
    # Loader
    "load_dataset",
    "register_engine",
    "publish_dataset",
]
