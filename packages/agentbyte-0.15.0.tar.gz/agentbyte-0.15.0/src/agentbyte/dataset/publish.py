"""Dataset publishing helpers."""

from __future__ import annotations

from pathlib import Path

from agentbyte.dataset.config import LocalDatasetConfig
from agentbyte.dataset.publish_config import DatasetPublishConfig
from agentbyte.dataset.publishers import PublishedDatasetRef
from agentbyte.dataset.sources import validate_dataset_id


def publish_dataset(
    dataset_id: str,
    local_config: LocalDatasetConfig,
    publish_config: DatasetPublishConfig,
) -> PublishedDatasetRef:
    """Publish a local dataset directory through a configured publisher."""
    validate_dataset_id(dataset_id)

    dataset_dir = local_config.local_root / dataset_id
    if not dataset_dir.is_dir():
        raise FileNotFoundError(f"Dataset not found at: {dataset_dir}")

    _require_file(dataset_dir / "config.json")
    _require_file(dataset_dir / "data.json")

    publisher = publish_config.build_publisher()
    return publisher.publish_dataset(dataset_id, dataset_dir)


def _require_file(path: Path) -> None:
    if not path.exists():
        raise FileNotFoundError(f"Required dataset file not found: {path}")


__all__ = ["publish_dataset"]
