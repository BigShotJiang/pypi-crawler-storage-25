"""Compatibility wrapper for the WebUI execution service."""

from agentbyte.webui.service import ExecutionEngine, ExecutionService, _serialize_payload

__all__ = ["ExecutionEngine", "ExecutionService", "_serialize_payload"]
