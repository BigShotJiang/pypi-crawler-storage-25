"""Research tools for web and academic information retrieval.

Install the required extras before importing this module:

    pip install 'agentbyte[research]'
    # or
    uv sync --extra research
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Literal
from urllib.parse import parse_qs, urlparse

import httpx
from pydantic import BaseModel, ConfigDict

from ..component import Component
from ..types import ToolResult
from .base import BaseTool


def _missing_extra_import_error(package_name: str) -> ImportError:
    return ImportError(
        "agentbyte.tools.research_tools requires optional research dependencies. "
        f"Missing package: {package_name}. "
        "If you are developing in this repository, run: uv sync --extra research. "
        "If you are installing AgentByte in another project, run: "
        'uv add "agentbyte[research]" or pip install "agentbyte[research]".'
    )


try:
    from bs4 import BeautifulSoup
except ImportError as exc:
    raise _missing_extra_import_error("beautifulsoup4") from exc

try:
    from html2text import HTML2Text
except ImportError as exc:
    raise _missing_extra_import_error("html2text") from exc

try:
    import arxiv as _arxiv
except ImportError as exc:
    raise _missing_extra_import_error("arxiv") from exc

try:
    from youtube_transcript_api import YouTubeTranscriptApi
except ImportError as exc:
    raise _missing_extra_import_error("youtube-transcript-api") from exc

_DDGO_URL = "https://api.duckduckgo.com/"


class ResearchToolsConfig(BaseModel):
    """Factory configuration for research tool bundles."""

    model_config = ConfigDict(extra="forbid")

    google_api_key: str | None = None
    google_cse_id: str | None = None
    allowed_domains: list[str] | None = None
    blocked_domains: list[str] | None = None
    fetch_timeout: int = 30
    fetch_max_length: int = 50_000

    def build_tools(self) -> list[BaseTool]:
        return create_research_tools(
            google_api_key=self.google_api_key,
            google_cse_id=self.google_cse_id,
            allowed_domains=self.allowed_domains,
            blocked_domains=self.blocked_domains,
            fetch_timeout=self.fetch_timeout,
            fetch_max_length=self.fetch_max_length,
        )


class WebSearchToolConfig(BaseModel):
    """Serializable configuration for WebSearchTool."""

    model_config = ConfigDict(extra="forbid")

    allowed_domains: list[str] | None = None
    blocked_domains: list[str] | None = None
    timeout: int = 10


class GoogleSearchToolConfig(BaseModel):
    """Serializable configuration for GoogleSearchTool."""

    model_config = ConfigDict(extra="forbid")

    api_key: str
    cse_id: str
    allowed_domains: list[str] | None = None
    blocked_domains: list[str] | None = None
    default_language: str | None = None
    default_country: str | None = None
    default_safe_search: Literal["off", "active"] = "off"
    timeout: int = 10


class WebFetchToolConfig(BaseModel):
    """Serializable configuration for WebFetchTool."""

    model_config = ConfigDict(extra="forbid")

    timeout: int = 30
    max_content_length: int = 50_000


class ExtractTextToolConfig(BaseModel):
    """Serializable configuration for ExtractTextTool."""

    model_config = ConfigDict(extra="forbid")

    workspace: Path | None = None
    max_content_length: int = 50_000


class ArxivSearchToolConfig(BaseModel):
    """Serializable configuration for ArxivSearchTool."""

    model_config = ConfigDict(extra="forbid")

    max_results: int = 5


class YouTubeCaptionToolConfig(BaseModel):
    """Serializable configuration for YouTubeCaptionTool."""

    model_config = ConfigDict(extra="forbid")

    language: str = "en"


def _is_domain_allowed(
    url: str,
    allowed: list[str] | None,
    blocked: list[str] | None,
) -> bool:
    try:
        domain = urlparse(url).netloc.lower().removeprefix("www.")
    except Exception:
        return True
    if blocked and any(domain == blocked_domain or domain.endswith("." + blocked_domain) for blocked_domain in blocked):
        return False
    if allowed:
        return any(domain == allowed_domain or domain.endswith("." + allowed_domain) for allowed_domain in allowed)
    return True


def _strip_scripts(html: str) -> str:
    soup = BeautifulSoup(html, "html.parser")
    for tag in soup(["script", "style"]):
        tag.decompose()
    return str(soup)


def _html_to_markdown(html: str) -> str:
    parser = HTML2Text()
    parser.ignore_links = False
    parser.ignore_images = False
    parser.body_width = 0
    return parser.handle(html)


def _extract_text_content(
    html: str,
    *,
    output_format: Literal["html", "text", "markdown"] = "markdown",
    max_content_length: int = 50_000,
) -> tuple[str, dict[str, Any]]:
    cleaned_html = _strip_scripts(html)
    original_length = len(cleaned_html)

    if output_format == "html":
        content = cleaned_html
    elif output_format == "markdown":
        content = _html_to_markdown(cleaned_html)
    else:
        soup = BeautifulSoup(cleaned_html, "html.parser")
        content = soup.get_text(separator="\n", strip=True)

    truncated = len(content) > max_content_length
    if truncated:
        content = content[:max_content_length]

    metadata = {
        "output_format": output_format,
        "content_length": len(content),
        "original_length": original_length,
        "truncated": truncated,
        "max_length": max_content_length,
    }
    return content, metadata


def _extract_video_id(url: str) -> str | None:
    parsed = urlparse(url)
    netloc = parsed.netloc.lower()
    if "youtu.be" in netloc:
        return parsed.path.lstrip("/").split("/")[0] or None
    if "youtube.com" in netloc:
        path_parts = parsed.path.split("/")
        for prefix in ("shorts", "embed", "v"):
            try:
                idx = path_parts.index(prefix)
                return path_parts[idx + 1] or None
            except (ValueError, IndexError):
                pass
        query_params = parse_qs(parsed.query)
        if "v" in query_params:
            return query_params["v"][0]
    return None


def _safe_workspace_resolve(workspace: Path, path_str: str) -> Path:
    full_path = (workspace / path_str).resolve()
    try:
        full_path.relative_to(workspace.resolve())
    except ValueError as exc:
        raise ValueError("Access denied: path is outside workspace") from exc
    return full_path


class WebSearchTool(BaseTool, Component[WebSearchToolConfig]):
    """Search the web via the DuckDuckGo Instant Answer API."""

    component_type = "tool"
    component_config_schema = WebSearchToolConfig
    component_provider_override = "agentbyte.tools.research_tools.WebSearchTool"

    def __init__(
        self,
        allowed_domains: list[str] | None = None,
        blocked_domains: list[str] | None = None,
        timeout: int = 10,
    ) -> None:
        super().__init__(
            name="web_search",
            description=(
                "Search the web for current information using DuckDuckGo. "
                "Returns a list of results with title, URL, and snippet."
            ),
        )
        self._allowed = allowed_domains
        self._blocked = blocked_domains
        self._timeout = timeout

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search query string"},
                "max_results": {
                    "type": "integer",
                    "description": "Maximum number of results to return (default 5)",
                },
            },
            "required": ["query"],
        }

    async def execute(self, parameters: dict[str, Any]) -> ToolResult:
        query: str = parameters["query"]
        max_results: int = parameters.get("max_results", 5)

        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    _DDGO_URL,
                    params={
                        "q": query,
                        "format": "json",
                        "no_html": "1",
                        "skip_disambig": "1",
                    },
                    timeout=self._timeout,
                )
                response.raise_for_status()
                data = response.json()

            results: list[dict[str, str]] = []

            if data.get("AbstractText") and data.get("AbstractURL"):
                results.append(
                    {
                        "title": data.get("Heading", query),
                        "url": data["AbstractURL"],
                        "snippet": data["AbstractText"],
                    }
                )

            for item in data.get("Results", []):
                if item.get("FirstURL") and item.get("Text"):
                    results.append(
                        {
                            "title": item["Text"][:80],
                            "url": item["FirstURL"],
                            "snippet": item["Text"],
                        }
                    )

            for item in data.get("RelatedTopics", []):
                topics = item.get("Topics")
                if topics:
                    for sub_item in topics:
                        if sub_item.get("FirstURL") and sub_item.get("Text"):
                            results.append(
                                {
                                    "title": sub_item["Text"][:80],
                                    "url": sub_item["FirstURL"],
                                    "snippet": sub_item["Text"],
                                }
                            )
                elif item.get("FirstURL") and item.get("Text"):
                    results.append(
                        {
                            "title": item["Text"][:80],
                            "url": item["FirstURL"],
                            "snippet": item["Text"],
                        }
                    )

            before = len(results)
            results = [result for result in results if _is_domain_allowed(result["url"], self._allowed, self._blocked)]
            filtered_count = before - len(results)

            return ToolResult(
                success=True,
                result=results[:max_results],
                metadata={
                    "backend": "duckduckgo",
                    "query": query,
                    "count": min(len(results), max_results),
                    "filtered": filtered_count,
                },
            )
        except Exception as exc:
            return ToolResult(success=False, result=None, error=str(exc), metadata={"query": query})

    def _to_config(self) -> WebSearchToolConfig:
        return WebSearchToolConfig(
            allowed_domains=self._allowed,
            blocked_domains=self._blocked,
            timeout=self._timeout,
        )

    @classmethod
    def _from_config(cls, config: WebSearchToolConfig) -> "WebSearchTool":
        return cls(
            allowed_domains=config.allowed_domains,
            blocked_domains=config.blocked_domains,
            timeout=config.timeout,
        )


class GoogleSearchTool(BaseTool, Component[GoogleSearchToolConfig]):
    """Placeholder for future Google Custom Search integration."""

    component_type = "tool"
    component_config_schema = GoogleSearchToolConfig
    component_provider_override = "agentbyte.tools.research_tools.GoogleSearchTool"

    def __init__(
        self,
        api_key: str,
        cse_id: str,
        *,
        allowed_domains: list[str] | None = None,
        blocked_domains: list[str] | None = None,
        default_language: str | None = None,
        default_country: str | None = None,
        default_safe_search: Literal["off", "active"] = "off",
        timeout: int = 10,
    ) -> None:
        super().__init__(
            name="google_search",
            description=(
                "Search the web using Google Custom Search. "
                "Supports language, country, and safe-search controls."
            ),
        )
        self._api_key = api_key
        self._cse_id = cse_id
        self._allowed = allowed_domains
        self._blocked = blocked_domains
        self._default_language = default_language
        self._default_country = default_country
        self._default_safe_search = default_safe_search
        self._timeout = timeout

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search query string"},
                "max_results": {
                    "type": "integer",
                    "description": "Maximum number of results to return (default 5)",
                },
                "language": {
                    "type": "string",
                    "description": "Google language restriction (for example 'lang_en')",
                },
                "country": {
                    "type": "string",
                    "description": "Google country restriction (for example 'countryUS')",
                },
                "safe_search": {
                    "type": "string",
                    "enum": ["off", "active"],
                    "description": "Google safe search mode",
                },
            },
            "required": ["query"],
        }

    async def execute(self, parameters: dict[str, Any]) -> ToolResult:
        query: str = parameters["query"]
        return ToolResult(
            success=False,
            result=None,
            error=(
                "GoogleSearchTool is not implemented yet. "
                "Use WebSearchTool for DuckDuckGo-backed web search today."
            ),
            metadata={
                "backend": "google_cse",
                "query": query,
                "implemented": False,
            },
        )

    def _to_config(self) -> GoogleSearchToolConfig:
        return GoogleSearchToolConfig(
            api_key=self._api_key,
            cse_id=self._cse_id,
            allowed_domains=self._allowed,
            blocked_domains=self._blocked,
            default_language=self._default_language,
            default_country=self._default_country,
            default_safe_search=self._default_safe_search,
            timeout=self._timeout,
        )

    @classmethod
    def _from_config(cls, config: GoogleSearchToolConfig) -> "GoogleSearchTool":
        return cls(
            api_key=config.api_key,
            cse_id=config.cse_id,
            allowed_domains=config.allowed_domains,
            blocked_domains=config.blocked_domains,
            default_language=config.default_language,
            default_country=config.default_country,
            default_safe_search=config.default_safe_search,
            timeout=config.timeout,
        )


class WebFetchTool(BaseTool, Component[WebFetchToolConfig]):
    """Fetch a URL and return its content as text, markdown, or raw HTML."""

    component_type = "tool"
    component_config_schema = WebFetchToolConfig
    component_provider_override = "agentbyte.tools.research_tools.WebFetchTool"

    def __init__(self, timeout: int = 30, max_content_length: int = 50_000) -> None:
        super().__init__(
            name="web_fetch",
            description=(
                "Fetch the content of a URL and return it as clean markdown, text, or HTML. "
                "Content is truncated if it exceeds max_content_length."
            ),
        )
        self._timeout = timeout
        self._max_length = max_content_length

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "url": {"type": "string", "description": "URL to fetch"},
                "output_format": {
                    "type": "string",
                    "enum": ["html", "text", "markdown"],
                    "description": "Output format: 'markdown' (default), 'text', or 'html'",
                },
            },
            "required": ["url"],
        }

    async def execute(self, parameters: dict[str, Any]) -> ToolResult:
        url: str = parameters["url"]
        output_format: Literal["html", "text", "markdown"] = parameters.get("output_format", "markdown")

        try:
            async with httpx.AsyncClient(follow_redirects=True) as client:
                response = await client.get(
                    url,
                    timeout=self._timeout,
                    headers={"User-Agent": "Mozilla/5.0 (compatible; AgentByte/1.0)"},
                )
                response.raise_for_status()
                content, metadata = _extract_text_content(
                    response.text,
                    output_format=output_format,
                    max_content_length=self._max_length,
                )

            return ToolResult(
                success=True,
                result=content,
                metadata={
                    "url": url,
                    "status_code": response.status_code,
                    **metadata,
                },
            )
        except Exception as exc:
            return ToolResult(success=False, result=None, error=str(exc), metadata={"url": url})

    def _to_config(self) -> WebFetchToolConfig:
        return WebFetchToolConfig(timeout=self._timeout, max_content_length=self._max_length)

    @classmethod
    def _from_config(cls, config: WebFetchToolConfig) -> "WebFetchTool":
        return cls(timeout=config.timeout, max_content_length=config.max_content_length)


class ExtractTextTool(BaseTool, Component[ExtractTextToolConfig]):
    """Extract clean text or markdown from raw HTML or a local HTML file."""

    component_type = "tool"
    component_config_schema = ExtractTextToolConfig
    component_provider_override = "agentbyte.tools.research_tools.ExtractTextTool"

    def __init__(self, workspace: Path | None = None, max_content_length: int = 50_000) -> None:
        super().__init__(
            name="extract_text",
            description=(
                "Extract clean markdown, text, or HTML from raw HTML content or a local HTML file."
            ),
        )
        self._workspace = (workspace or Path.cwd()).resolve()
        self._max_length = max_content_length

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "html": {"type": "string", "description": "Raw HTML string to convert"},
                "file_path": {"type": "string", "description": "Workspace-relative path to a local HTML file"},
                "output_format": {
                    "type": "string",
                    "enum": ["html", "text", "markdown"],
                    "description": "Output format: 'markdown' (default), 'text', or 'html'",
                },
            },
            "required": [],
        }

    async def execute(self, parameters: dict[str, Any]) -> ToolResult:
        html: str | None = parameters.get("html")
        file_path: str | None = parameters.get("file_path")
        output_format: Literal["html", "text", "markdown"] = parameters.get("output_format", "markdown")

        if bool(html) == bool(file_path):
            return ToolResult(
                success=False,
                result=None,
                error="Provide exactly one of 'html' or 'file_path'.",
            )

        try:
            if file_path:
                resolved = _safe_workspace_resolve(self._workspace, file_path)
                html = resolved.read_text(encoding="utf-8")
                source = file_path
            else:
                source = "inline_html"

            content, metadata = _extract_text_content(
                html or "",
                output_format=output_format,
                max_content_length=self._max_length,
            )
            return ToolResult(
                success=True,
                result=content,
                metadata={"source": source, **metadata},
            )
        except Exception as exc:
            return ToolResult(success=False, result=None, error=str(exc), metadata={"source": file_path})

    def _to_config(self) -> ExtractTextToolConfig:
        return ExtractTextToolConfig(workspace=self._workspace, max_content_length=self._max_length)

    @classmethod
    def _from_config(cls, config: ExtractTextToolConfig) -> "ExtractTextTool":
        return cls(workspace=config.workspace, max_content_length=config.max_content_length)


class ArxivSearchTool(BaseTool):
    """Search academic papers on arXiv."""

    def __init__(self, max_results: int = 5) -> None:
        super().__init__(
            name="arxiv_search",
            description=(
                "Search academic papers on arXiv by keyword query. "
                "Returns paper titles, authors, abstracts, and PDF URLs."
            ),
        )
        self._max_results = max_results

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Search query (e.g., 'multi-agent reinforcement learning')",
                },
                "max_results": {
                    "type": "integer",
                    "description": f"Maximum number of results to return (default {self._max_results})",
                },
                "sort_by": {
                    "type": "string",
                    "enum": ["relevance", "lastUpdatedDate", "submittedDate"],
                    "description": "Sort order (default 'relevance')",
                },
            },
            "required": ["query"],
        }

    async def execute(self, parameters: dict[str, Any]) -> ToolResult:
        query: str = parameters["query"]
        max_results: int = parameters.get("max_results", self._max_results)
        sort_by_str: str = parameters.get("sort_by", "relevance")

        sort_map = {
            "relevance": _arxiv.SortCriterion.Relevance,
            "lastUpdatedDate": _arxiv.SortCriterion.LastUpdatedDate,
            "submittedDate": _arxiv.SortCriterion.SubmittedDate,
        }
        sort_criterion = sort_map.get(sort_by_str, _arxiv.SortCriterion.Relevance)

        try:
            client = _arxiv.Client()
            search = _arxiv.Search(query=query, max_results=max_results, sort_by=sort_criterion)
            results = [
                {
                    "title": result.title,
                    "authors": [str(author) for author in result.authors],
                    "published": result.published.isoformat() if result.published else None,
                    "summary": result.summary,
                    "pdf_url": result.pdf_url,
                    "entry_id": result.entry_id,
                }
                for result in client.results(search)
            ]
            return ToolResult(success=True, result=results, metadata={"query": query, "count": len(results)})
        except Exception as exc:
            return ToolResult(success=False, result=None, error=str(exc), metadata={"query": query})


class YouTubeCaptionTool(BaseTool):
    """Extract transcript/captions from a YouTube video."""

    def __init__(self, language: str = "en") -> None:
        super().__init__(
            name="youtube_caption",
            description=(
                "Extract the transcript/captions from a YouTube video URL. "
                "Returns the full transcript as a single text string."
            ),
        )
        self._language = language

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "url": {
                    "type": "string",
                    "description": "YouTube video URL (youtube.com/watch?v=..., youtu.be/..., etc.)",
                },
                "language": {
                    "type": "string",
                    "description": f"Language code for transcript (default '{self._language}')",
                },
            },
            "required": ["url"],
        }

    async def execute(self, parameters: dict[str, Any]) -> ToolResult:
        url: str = parameters["url"]
        language: str = parameters.get("language", self._language)

        video_id = _extract_video_id(url)
        if not video_id:
            return ToolResult(
                success=False,
                result=None,
                error=f"Could not extract video ID from URL: {url}",
                metadata={"url": url},
            )

        api = YouTubeTranscriptApi()
        try:
            transcript = api.fetch(video_id, languages=[language])
        except Exception:
            try:
                transcript = api.fetch(video_id)
            except Exception as exc:
                return ToolResult(
                    success=False,
                    result=None,
                    error=str(exc),
                    metadata={"url": url, "video_id": video_id},
                )

        snippets = list(transcript)
        text = re.sub(r"\s+", " ", " ".join(snippet.text for snippet in snippets)).strip()

        return ToolResult(
            success=True,
            result=text,
            metadata={
                "video_id": video_id,
                "url": url,
                "language": getattr(transcript, "language_code", language),
                "length": len(text),
                "segment_count": len(snippets),
            },
        )


def create_research_tools(
    *,
    google_api_key: str | None = None,
    google_cse_id: str | None = None,
    allowed_domains: list[str] | None = None,
    blocked_domains: list[str] | None = None,
    fetch_timeout: int = 30,
    fetch_max_length: int = 50_000,
) -> list[BaseTool]:
    """Return a standard suite of research tools."""

    return [
        WebSearchTool(
            allowed_domains=allowed_domains,
            blocked_domains=blocked_domains,
        ),
        WebFetchTool(timeout=fetch_timeout, max_content_length=fetch_max_length),
        ExtractTextTool(max_content_length=fetch_max_length),
        ArxivSearchTool(),
        YouTubeCaptionTool(),
    ]


__all__ = [
    "ResearchToolsConfig",
    "WebSearchToolConfig",
    "GoogleSearchToolConfig",
    "WebFetchToolConfig",
    "ExtractTextToolConfig",
    "ArxivSearchToolConfig",
    "YouTubeCaptionToolConfig",
    "WebSearchTool",
    "GoogleSearchTool",
    "WebFetchTool",
    "ExtractTextTool",
    "ArxivSearchTool",
    "YouTubeCaptionTool",
    "create_research_tools",
    "_extract_video_id",
    "_is_domain_allowed",
]
