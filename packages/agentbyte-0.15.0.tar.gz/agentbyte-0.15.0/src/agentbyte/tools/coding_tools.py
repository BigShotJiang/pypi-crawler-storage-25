"""Coding tools for file operations and code execution.

All tools enforce workspace isolation — paths that resolve outside the
configured workspace root are rejected with an error ToolResult.
"""

from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path
from typing import Any

from pydantic import BaseModel, ConfigDict

from ..component import Component
from ..types import ToolResult
from .base import ApprovalMode, BaseTool


def _safe_resolve(workspace: Path, path_str: str) -> Path:
    normalized = path_str.strip().lstrip("/")
    full = (workspace / normalized).resolve()
    try:
        full.relative_to(workspace.resolve())
    except ValueError as exc:
        raise ValueError("Access denied: path is outside workspace") from exc
    return full


class CodingToolsConfig(BaseModel):
    """Factory configuration for coding tool bundles."""

    model_config = ConfigDict(extra="forbid", use_enum_values=True)

    workspace: Path | None = None
    bash_timeout: int = 30
    bash_approval: ApprovalMode = ApprovalMode.ALWAYS
    repl_timeout: int = 30
    repl_approval: ApprovalMode = ApprovalMode.ALWAYS

    def build_tools(self) -> list[BaseTool]:
        return create_coding_tools(
            workspace=self.workspace,
            bash_timeout=self.bash_timeout,
            bash_approval=self.bash_approval,
            repl_timeout=self.repl_timeout,
            repl_approval=self.repl_approval,
        )


class ReadFileToolConfig(BaseModel):
    """Serializable configuration for ReadFileTool."""

    model_config = ConfigDict(extra="forbid")

    workspace: Path | None = None


class WriteFileToolConfig(BaseModel):
    """Serializable configuration for WriteFileTool."""

    model_config = ConfigDict(extra="forbid")

    workspace: Path | None = None


class ListDirectoryToolConfig(BaseModel):
    """Serializable configuration for ListDirectoryTool."""

    model_config = ConfigDict(extra="forbid")

    workspace: Path | None = None


class GrepSearchToolConfig(BaseModel):
    """Serializable configuration for GrepSearchTool."""

    model_config = ConfigDict(extra="forbid")

    workspace: Path | None = None


class BashExecuteToolConfig(BaseModel):
    """Serializable configuration for BashExecuteTool."""

    model_config = ConfigDict(extra="forbid", use_enum_values=True)

    workspace: Path | None = None
    timeout: int = 30
    approval_mode: ApprovalMode = ApprovalMode.ALWAYS


class PythonREPLToolConfig(BaseModel):
    """Serializable configuration for PythonREPLTool."""

    model_config = ConfigDict(extra="forbid", use_enum_values=True)

    workspace: Path | None = None
    timeout: int = 30
    approval_mode: ApprovalMode = ApprovalMode.ALWAYS


async def _communicate_with_timeout(
    process: asyncio.subprocess.Process,
    *,
    timeout: int,
    input_text: str | None = None,
) -> tuple[bytes, bytes] | None:
    input_bytes = input_text.encode() if input_text is not None else None
    try:
        return await asyncio.wait_for(process.communicate(input_bytes), timeout=timeout)
    except asyncio.TimeoutError:
        process.kill()
        await process.wait()
        return None


class ReadFileTool(BaseTool, Component[ReadFileToolConfig]):
    """Read a file from the workspace."""

    component_type = "tool"
    component_config_schema = ReadFileToolConfig
    component_provider_override = "agentbyte.tools.coding_tools.ReadFileTool"

    def __init__(self, workspace: Path | None = None) -> None:
        super().__init__(
            name="read_file",
            description="Read the contents of a file within the workspace.",
        )
        self._workspace = (workspace or Path.cwd()).resolve()

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "file_path": {
                    "type": "string",
                    "description": "Relative path to the file within the workspace",
                },
                "encoding": {
                    "type": "string",
                    "description": "File encoding (default 'utf-8')",
                },
            },
            "required": ["file_path"],
        }

    async def execute(self, parameters: dict[str, Any]) -> ToolResult:
        file_path: str = parameters["file_path"]
        encoding: str = parameters.get("encoding", "utf-8")

        try:
            full_path = _safe_resolve(self._workspace, file_path)
        except ValueError as exc:
            return ToolResult(success=False, result=None, error=str(exc))

        try:
            content = full_path.read_text(encoding=encoding)
            return ToolResult(
                success=True,
                result=content,
                metadata={
                    "file_path": file_path,
                    "size": len(content),
                    "lines": content.count("\n") + 1,
                },
            )
        except FileNotFoundError:
            return ToolResult(success=False, result=None, error=f"File not found: {file_path}")
        except Exception as exc:
            return ToolResult(success=False, result=None, error=str(exc))

    def _to_config(self) -> ReadFileToolConfig:
        return ReadFileToolConfig(workspace=self._workspace)

    @classmethod
    def _from_config(cls, config: ReadFileToolConfig) -> "ReadFileTool":
        return cls(workspace=config.workspace)


class WriteFileTool(BaseTool, Component[WriteFileToolConfig]):
    """Write, replace, or insert content in a file within the workspace."""

    component_type = "tool"
    component_config_schema = WriteFileToolConfig
    component_provider_override = "agentbyte.tools.coding_tools.WriteFileTool"

    def __init__(self, workspace: Path | None = None) -> None:
        super().__init__(
            name="write_file",
            description=(
                "Write to a file in the workspace. Three operations: "
                "(1) full write — provide 'content'; "
                "(2) str_replace — provide 'old_str' and 'new_str'; "
                "(3) insert_at_line — provide 'insert_line' and 'insert_content'."
            ),
        )
        self._workspace = (workspace or Path.cwd()).resolve()

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "file_path": {"type": "string", "description": "Relative path to the file within the workspace"},
                "content": {"type": "string", "description": "Full file content (for complete overwrite)"},
                "old_str": {"type": "string", "description": "String to replace (first occurrence) for str_replace"},
                "new_str": {"type": "string", "description": "Replacement string for str_replace"},
                "insert_line": {"type": "integer", "description": "1-based line number after which to insert content"},
                "insert_content": {"type": "string", "description": "Content to insert at the specified line"},
                "encoding": {"type": "string", "description": "File encoding (default 'utf-8')"},
            },
            "required": ["file_path"],
        }

    async def execute(self, parameters: dict[str, Any]) -> ToolResult:
        file_path: str = parameters["file_path"]
        encoding: str = parameters.get("encoding", "utf-8")

        try:
            full_path = _safe_resolve(self._workspace, file_path)
        except ValueError as exc:
            return ToolResult(success=False, result=None, error=str(exc))

        try:
            full_path.parent.mkdir(parents=True, exist_ok=True)

            if "content" in parameters:
                content: str = parameters["content"]
                full_path.write_text(content, encoding=encoding)
                return ToolResult(
                    success=True,
                    result=f"Written: {file_path}",
                    metadata={
                        "operation": "write",
                        "file_path": file_path,
                        "size": len(content),
                        "lines": content.count("\n") + 1,
                    },
                )

            if "old_str" in parameters and "new_str" in parameters:
                if not full_path.is_file():
                    return ToolResult(success=False, result=None, error=f"File not found: {file_path}")
                old_str: str = parameters["old_str"]
                new_str: str = parameters["new_str"]
                existing = full_path.read_text(encoding=encoding)
                if old_str not in existing:
                    return ToolResult(success=False, result=None, error=f"String not found in file: {old_str!r}")
                updated = existing.replace(old_str, new_str, 1)
                full_path.write_text(updated, encoding=encoding)
                return ToolResult(
                    success=True,
                    result=f"Replaced in: {file_path}",
                    metadata={
                        "operation": "str_replace",
                        "file_path": file_path,
                        "old_length": len(old_str),
                        "new_length": len(new_str),
                    },
                )

            if "insert_line" in parameters and "insert_content" in parameters:
                if not full_path.is_file():
                    return ToolResult(success=False, result=None, error=f"File not found: {file_path}")
                insert_line: int = parameters["insert_line"]
                insert_content: str = parameters["insert_content"]
                lines = full_path.read_text(encoding=encoding).splitlines(keepends=True)
                if insert_line < 0 or insert_line > len(lines):
                    return ToolResult(
                        success=False,
                        result=None,
                        error=f"insert_line {insert_line} out of range (file has {len(lines)} lines)",
                    )
                text = insert_content if insert_content.endswith("\n") else insert_content + "\n"
                lines.insert(insert_line, text)
                full_path.write_text("".join(lines), encoding=encoding)
                return ToolResult(
                    success=True,
                    result=f"Inserted after line {insert_line} in: {file_path}",
                    metadata={
                        "operation": "insert_at_line",
                        "file_path": file_path,
                        "line": insert_line,
                        "insert_length": len(insert_content),
                    },
                )

            return ToolResult(
                success=False,
                result=None,
                error=(
                    "Specify 'content' for full write, "
                    "'old_str'+'new_str' for str_replace, or "
                    "'insert_line'+'insert_content' for insert."
                ),
            )
        except Exception as exc:
            return ToolResult(success=False, result=None, error=str(exc))

    def _to_config(self) -> WriteFileToolConfig:
        return WriteFileToolConfig(workspace=self._workspace)

    @classmethod
    def _from_config(cls, config: WriteFileToolConfig) -> "WriteFileTool":
        return cls(workspace=config.workspace)


class ListDirectoryTool(BaseTool, Component[ListDirectoryToolConfig]):
    """List files and directories within the workspace."""

    component_type = "tool"
    component_config_schema = ListDirectoryToolConfig
    component_provider_override = "agentbyte.tools.coding_tools.ListDirectoryTool"

    def __init__(self, workspace: Path | None = None) -> None:
        super().__init__(
            name="list_directory",
            description="List files and directories within the workspace. Directories are listed first.",
        )
        self._workspace = (workspace or Path.cwd()).resolve()

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "directory_path": {
                    "type": "string",
                    "description": "Relative path to the directory to list (default '.')",
                },
                "recursive": {
                    "type": "boolean",
                    "description": "List all entries recursively (default false)",
                },
            },
            "required": [],
        }

    async def execute(self, parameters: dict[str, Any]) -> ToolResult:
        dir_path_str: str = parameters.get("directory_path", ".")
        recursive: bool = parameters.get("recursive", False)

        try:
            dir_path = _safe_resolve(self._workspace, dir_path_str)
        except ValueError as exc:
            return ToolResult(success=False, result=None, error=str(exc))

        try:
            if not dir_path.is_dir():
                return ToolResult(success=False, result=None, error=f"Not a directory: {dir_path_str}")

            raw = list(dir_path.rglob("*") if recursive else dir_path.iterdir())
            entries = sorted(raw, key=lambda path: (path.is_file(), path.name))
            items = [
                {
                    "name": str(entry.relative_to(self._workspace)),
                    "type": "file" if entry.is_file() else "directory",
                    "size": entry.stat().st_size if entry.is_file() else None,
                }
                for entry in entries
            ]
            return ToolResult(success=True, result=items, metadata={"directory": dir_path_str, "count": len(items)})
        except Exception as exc:
            return ToolResult(success=False, result=None, error=str(exc))

    def _to_config(self) -> ListDirectoryToolConfig:
        return ListDirectoryToolConfig(workspace=self._workspace)

    @classmethod
    def _from_config(cls, config: ListDirectoryToolConfig) -> "ListDirectoryTool":
        return cls(workspace=config.workspace)


class GrepSearchTool(BaseTool, Component[GrepSearchToolConfig]):
    """Pattern search across files in the workspace (ripgrep → grep fallback)."""

    component_type = "tool"
    component_config_schema = GrepSearchToolConfig
    component_provider_override = "agentbyte.tools.coding_tools.GrepSearchTool"

    def __init__(self, workspace: Path | None = None) -> None:
        super().__init__(
            name="grep_search",
            description=(
                "Search for a regex pattern across files in the workspace. "
                "Uses ripgrep (rg) when available, falls back to grep."
            ),
        )
        self._workspace = (workspace or Path.cwd()).resolve()

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "pattern": {"type": "string", "description": "Regular expression pattern to search for"},
                "path": {"type": "string", "description": "Relative path to search within (default '.')"},
                "file_pattern": {"type": "string", "description": "Glob filter for files to include (e.g., '*.py')"},
                "case_sensitive": {"type": "boolean", "description": "Case-sensitive search (default true)"},
            },
            "required": ["pattern"],
        }

    async def execute(self, parameters: dict[str, Any]) -> ToolResult:
        pattern: str = parameters["pattern"]
        search_path_str: str = parameters.get("path", ".")
        file_pattern: str | None = parameters.get("file_pattern")
        case_sensitive: bool = parameters.get("case_sensitive", True)

        try:
            search_path = _safe_resolve(self._workspace, search_path_str)
        except ValueError as exc:
            return ToolResult(success=False, result=None, error=str(exc))

        matches = await self._run_rg(pattern, search_path, file_pattern, case_sensitive)
        if matches is None:
            matches = await self._run_grep(pattern, search_path, file_pattern, case_sensitive)

        if matches is None:
            return ToolResult(success=False, result=None, error="Neither rg nor grep is available")

        return ToolResult(success=True, result=matches, metadata={"pattern": pattern, "matches": len(matches)})

    async def _run_rg(
        self,
        pattern: str,
        search_path: Path,
        file_pattern: str | None,
        case_sensitive: bool,
    ) -> list[dict[str, Any]] | None:
        command = ["rg", "--json", "-e", pattern]
        if not case_sensitive:
            command.append("-i")
        if file_pattern:
            command.extend(["--glob", file_pattern])
        command.append(str(search_path))

        try:
            process = await asyncio.create_subprocess_exec(
                *command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, _ = await process.communicate()
        except FileNotFoundError:
            return None

        if process.returncode not in (0, 1):
            return None

        matches: list[dict[str, Any]] = []
        for line in stdout.decode(errors="replace").splitlines():
            try:
                obj = json.loads(line)
                if obj.get("type") == "match":
                    data = obj["data"]
                    matches.append(
                        {
                            "file": data["path"]["text"],
                            "line": data["line_number"],
                            "text": data["lines"]["text"].rstrip("\n"),
                        }
                    )
            except (json.JSONDecodeError, KeyError):
                continue

        return matches

    async def _run_grep(
        self,
        pattern: str,
        search_path: Path,
        file_pattern: str | None,
        case_sensitive: bool,
    ) -> list[dict[str, Any]] | None:
        command = ["grep", "-rn"]
        if not case_sensitive:
            command.append("-i")
        if file_pattern:
            command.extend(["--include", file_pattern])
        command.extend([pattern, str(search_path)])

        try:
            process = await asyncio.create_subprocess_exec(
                *command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, _ = await process.communicate()
        except FileNotFoundError:
            return None

        if process.returncode not in (0, 1):
            return None

        matches: list[dict[str, Any]] = []
        for line in stdout.decode(errors="replace").splitlines():
            parts = line.split(":", 2)
            if len(parts) >= 3:
                matches.append(
                    {
                        "file": parts[0],
                        "line": int(parts[1]) if parts[1].isdigit() else parts[1],
                        "text": parts[2],
                    }
                )
        return matches

    def _to_config(self) -> GrepSearchToolConfig:
        return GrepSearchToolConfig(workspace=self._workspace)

    @classmethod
    def _from_config(cls, config: GrepSearchToolConfig) -> "GrepSearchTool":
        return cls(workspace=config.workspace)


class BashExecuteTool(BaseTool, Component[BashExecuteToolConfig]):
    """Execute a shell command within the workspace with a timeout."""

    component_type = "tool"
    component_config_schema = BashExecuteToolConfig
    component_provider_override = "agentbyte.tools.coding_tools.BashExecuteTool"

    def __init__(
        self,
        workspace: Path | None = None,
        timeout: int = 30,
        approval_mode: ApprovalMode = ApprovalMode.ALWAYS,
    ) -> None:
        super().__init__(
            name="bash_execute",
            description=(
                "Execute a shell command in the workspace directory. "
                "Returns stdout and stderr. Commands are killed on timeout."
            ),
            approval_mode=approval_mode,
        )
        self._workspace = (workspace or Path.cwd()).resolve()
        self._timeout = timeout

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "command": {"type": "string", "description": "Shell command to execute"},
                "timeout": {"type": "integer", "description": f"Timeout in seconds (default {self._timeout})"},
            },
            "required": ["command"],
        }

    async def execute(self, parameters: dict[str, Any]) -> ToolResult:
        command: str = parameters["command"]
        timeout: int = parameters.get("timeout", self._timeout)

        try:
            process = await asyncio.create_subprocess_shell(
                command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=str(self._workspace),
            )
            completed = await _communicate_with_timeout(process, timeout=timeout)
            if completed is None:
                return ToolResult(
                    success=False,
                    result=None,
                    error=f"Command timed out after {timeout}s",
                    metadata={"command": command, "returncode": None},
                )

            stdout, stderr = completed
            stdout_str = stdout.decode(errors="replace")
            stderr_str = stderr.decode(errors="replace")
            success = process.returncode == 0
            return ToolResult(
                success=success,
                result={"stdout": stdout_str, "stderr": stderr_str},
                error=stderr_str if not success else None,
                metadata={"command": command, "returncode": process.returncode},
            )
        except Exception as exc:
            return ToolResult(success=False, result=None, error=str(exc), metadata={"command": command})

    def _to_config(self) -> BashExecuteToolConfig:
        return BashExecuteToolConfig(
            workspace=self._workspace,
            timeout=self._timeout,
            approval_mode=self.approval_mode,
        )

    @classmethod
    def _from_config(cls, config: BashExecuteToolConfig) -> "BashExecuteTool":
        return cls(
            workspace=config.workspace,
            timeout=config.timeout,
            approval_mode=config.approval_mode,
        )


class PythonREPLTool(BaseTool, Component[PythonREPLToolConfig]):
    """Execute Python code in an isolated subprocess."""

    component_type = "tool"
    component_config_schema = PythonREPLToolConfig
    component_provider_override = "agentbyte.tools.coding_tools.PythonREPLTool"

    def __init__(
        self,
        workspace: Path | None = None,
        timeout: int = 30,
        approval_mode: ApprovalMode = ApprovalMode.ALWAYS,
    ) -> None:
        super().__init__(
            name="python_repl",
            description=(
                "Execute Python code in a fresh subprocess and capture stdout/stderr output."
            ),
            approval_mode=approval_mode,
        )
        self._workspace = (workspace or Path.cwd()).resolve()
        self._timeout = timeout

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "code": {"type": "string", "description": "Python code to execute"},
                "timeout": {"type": "integer", "description": f"Timeout in seconds (default {self._timeout})"},
            },
            "required": ["code"],
        }

    async def execute(self, parameters: dict[str, Any]) -> ToolResult:
        code: str = parameters["code"]
        timeout: int = parameters.get("timeout", self._timeout)

        wrapper = (
            "import sys\n"
            "namespace = {'__name__': '__main__'}\n"
            "source = sys.stdin.read()\n"
            "exec(compile(source, '<agentbyte-python-repl>', 'exec'), namespace, namespace)\n"
        )

        try:
            process = await asyncio.create_subprocess_exec(
                sys.executable,
                "-c",
                wrapper,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=str(self._workspace),
            )
            completed = await _communicate_with_timeout(process, timeout=timeout, input_text=code)
            if completed is None:
                return ToolResult(
                    success=False,
                    result=None,
                    error=f"Code execution timed out after {timeout}s",
                    metadata={"code_length": len(code), "returncode": None},
                )

            stdout, stderr = completed
            stdout_str = stdout.decode(errors="replace")
            stderr_str = stderr.decode(errors="replace")
            success = process.returncode == 0 and not stderr_str
            return ToolResult(
                success=success,
                result=stdout_str if stdout_str else None,
                error=stderr_str if not success else None,
                metadata={"code_length": len(code), "returncode": process.returncode},
            )
        except Exception as exc:
            return ToolResult(success=False, result=None, error=str(exc), metadata={"code_length": len(code)})

    def _to_config(self) -> PythonREPLToolConfig:
        return PythonREPLToolConfig(
            workspace=self._workspace,
            timeout=self._timeout,
            approval_mode=self.approval_mode,
        )

    @classmethod
    def _from_config(cls, config: PythonREPLToolConfig) -> "PythonREPLTool":
        return cls(
            workspace=config.workspace,
            timeout=config.timeout,
            approval_mode=config.approval_mode,
        )


def create_coding_tools(
    workspace: Path | None = None,
    *,
    bash_timeout: int = 30,
    bash_approval: ApprovalMode = ApprovalMode.ALWAYS,
    repl_timeout: int = 30,
    repl_approval: ApprovalMode = ApprovalMode.ALWAYS,
) -> list[BaseTool]:
    """Return a standard suite of coding tools."""

    return [
        ReadFileTool(workspace=workspace),
        WriteFileTool(workspace=workspace),
        ListDirectoryTool(workspace=workspace),
        GrepSearchTool(workspace=workspace),
        BashExecuteTool(workspace=workspace, timeout=bash_timeout, approval_mode=bash_approval),
        PythonREPLTool(workspace=workspace, timeout=repl_timeout, approval_mode=repl_approval),
    ]


__all__ = [
    "CodingToolsConfig",
    "ReadFileToolConfig",
    "WriteFileToolConfig",
    "ListDirectoryToolConfig",
    "GrepSearchToolConfig",
    "BashExecuteToolConfig",
    "PythonREPLToolConfig",
    "ReadFileTool",
    "WriteFileTool",
    "ListDirectoryTool",
    "GrepSearchTool",
    "BashExecuteTool",
    "PythonREPLTool",
    "create_coding_tools",
    "_safe_resolve",
]
