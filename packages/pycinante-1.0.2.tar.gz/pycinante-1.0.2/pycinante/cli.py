"""Pycinante command-line tools."""

import argparse
import json
import sys

from pycinante import read_json


def pjson_command():
    """Pretty print JSON files."""

    parser = argparse.ArgumentParser(
        description="Pretty print JSON files",
        prog="pjson",
    )
    parser.add_argument(
        "file",
        help="JSON file to pretty print",
    )
    parser.add_argument(
        "-i",
        "--indent",
        type=int,
        default=2,
        help="Indentation spaces (default: 2)",
    )
    parser.add_argument(
        "-e",
        "--encoding",
        type=str,
        default=None,
        help="File encoding (default: system default)",
    )

    args = parser.parse_args()

    try:
        data = read_json(args.file, encoding=args.encoding)
        output = json.dumps(data, indent=args.indent, ensure_ascii=False)
        print(output)
        return 0
    except FileNotFoundError:
        print(f"Error: File '{args.file}' not found", file=sys.stderr)
        return 1
    except json.JSONDecodeError as e:
        print(f"Error: Invalid JSON - {e}", file=sys.stderr)
        return 1
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
