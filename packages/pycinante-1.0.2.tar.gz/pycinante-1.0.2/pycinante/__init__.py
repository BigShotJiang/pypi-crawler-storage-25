"""Pycinante for easily programming in Python."""

import os.path as osp
import warnings

__version__ = "1.0.2"

osp = osp


def read_json(path, encoding=None, **kwargs):
    with open(path, "r", encoding=encoding) as fp:
        return __import__("json").load(fp, **kwargs)


def save_json(obj, path, encoding=None, **kwargs):
    with open(path, "w", encoding=encoding) as fp:
        __import__("json").dump(obj, fp, **kwargs)


def objprint(obj, **kwargs):
    try:
        __import__("objprint").op(obj, **kwargs)
    except ImportError:
        warnings.warn("objprint not installed, using pprint instead")
        __import__("pprint").pprint(obj, **kwargs)


def read_pickle(path, **kwargs):
    with open(path, "rb") as fp:
        return __import__("pickle").load(fp, **kwargs)


def save_pickle(obj, path, **kwargs):
    with open(path, "wb") as fp:
        __import__("pickle").dump(obj, fp, **kwargs)
