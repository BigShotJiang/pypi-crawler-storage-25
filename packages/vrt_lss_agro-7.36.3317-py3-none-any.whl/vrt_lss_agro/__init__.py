# coding: utf-8

# flake8: noqa

"""
    VRt.Agro [AG]

    Programming interface for Veeroute Agro.  # Description  The service is designed to compute the work plan of production facilities.  ## General schema  ![objects](../images/agro_objects.svg)  ### Field  - produces a specific agricultural crop with a specific moisture level - crop output from the field can be moved only to an Elevator or a Plant  ### Elevator (Threshing floor)  - consists of Gates, Dryers, short-term and long-term storage locations - dries the grain (if the crop moisture is above the allowed level) - stores dry grain in short-term storage locations (warehouses); unloading and loading of grain within a single day is allowed - stores dry grain in long-term storage locations (sleeves, trenches, mounds) - only one type of crop can be stored in a single storage at a time - sells surplus grain to the Market - production processes inside the facility: drying, loading/unloading to a storage location, storage  ### Plant  - consists of Gates, Dryers, Bunkers, Consumers - [if drying is present] dries the grain (if the crop moisture is above the allowed level) - stores dry grain in Bunkers (short-term storage tied to a specific crop) - maintains a minimum stock of grain in Bunkers for consumption - consumes grain from Bunkers - buys missing grain from the Market - production processes inside the facility: drying, loading/unloading to a storage location, storage, consumption  ### Market  - buys grain from Elevators - sells grain to Plants  ## Project  A project reflects the planned sequence of operations on agricultural crops; the operation types are described below.  ### HARVEST  Harvesting of an agricultural crop:  - between production facilities (a Field and an Elevator or a Plant) - the operation occurs within a single day - grain moisture is determined at the Field  |                          | Object (target_key)  | Sub-object (target_detail_key) | |--------------------------|----------------------|--------------------------------| | Source                   | Field                | -                              | | Destination              | Elevator or Plant    | Gates                          |  ### DRY  Drying of a crop:  - inside a production facility (Elevator or Plant) - duration of the operation — one day - during drying both the mass and the moisture type change (WET -> DRY) - the source specifies the mass of the wet crop - the destination specifies the resulting mass of the dry crop  |                          | Object (target_key)  | Sub-object (target_detail_key) | |--------------------------|----------------------|--------------------------------| | Source                   | Elevator or Plant    | Gates                          | | Destination              | Elevator or Plant    | Dryer                          |  ### LOAD  Loading of a crop from the Gates into a Storage location (long-term, short-term, bunker):  - between parts of the same production facility (Elevator or Plant) - the operation occurs within a single day  |                          | Object (target_key)  | Sub-object (target_detail_key)                            | |--------------------------|----------------------|-----------------------------------------------------------| | Source                   | Elevator or Plant    | Gates or Dryer                                            | | Destination              | Elevator or Plant    | Storage location (long-term, short-term, bunker)          |  ### UNLOAD  Unloading of a crop from a storage location to the Gates:  - between parts of the same production facility (Elevator) - the operation occurs within a single day  |                          | Object (target_key)  | Sub-object (target_detail_key)                                       | |--------------------------|----------------------|----------------------------------------------------------------------| | Source                   | Elevator             | Storage location (long-term, short-term, bunker) or Dryer            | | Destination              | Elevator             | Gates                                                                |  ### STORE  Crop storage:  - the storage location does not change - duration of the operation — one day - the operation occurs overnight  |                          | Object (target_key)  | Sub-object (target_detail_key)                            | |--------------------------|----------------------|-----------------------------------------------------------| | Source                   | Elevator or Plant    | Storage location (long-term, short-term, bunker)          | | Destination              | Elevator or Plant    | The same storage location                                 |  ### RELOCATE  Transport between production facilities:  - between production facilities (Elevator and Plant) - the operation occurs within a single day  |                          | Object (target_key)  | Sub-object (target_detail_key) | |--------------------------|----------------------|--------------------------------| | Source                   | Elevator             | Gates                          | | Destination              | Plant                | Gates                          |  ### CONSUMPTION  Consumption of a crop by the plant:  - between parts of the same production facility (Plant) - the operation occurs within a single day - consumption goes from a Bunker - additionally we can consume directly from the Gates or the Dryer without storing in a Bunker  |                          | Object (target_key)  | Sub-object (target_detail_key) | |--------------------------|----------------------|--------------------------------| | Source                   | Plant                | Bunker or Gates or Dryer       | | Destination              | Plant                | Consumer                       |  ### SELL  Sale of a crop:  - between production facilities (Elevator and Market) - the operation occurs within a single day  |                          | Object (target_key)  | Sub-object (target_detail_key) | |--------------------------|----------------------|--------------------------------| | Source                   | Elevator             | Gates                          | | Destination              | Market               | Contract                       |  ### BUY  Purchase of a crop:  - between production facilities (Market and Plant) - the operation occurs within a single day  |                          | Object (target_key)  | Sub-object (target_detail_key) | |--------------------------|----------------------|--------------------------------| | Source                   | Market               | Contract                       | | Destination              | Plant                | Gates                          |  ## Entity diagram  ![erd](../uml/agro.svg) 

    The version of the OpenAPI document: 7.36.3317
    Contact: support@veeroute.com
    Generated by OpenAPI Generator (https://openapi-generator.tech)

    Do not edit the class manually.
"""  # noqa: E501


__version__ = "7.36.3317"

# Define package exports
__all__ = [
    "PlanApi",
    "SystemApi",
    "ApiResponse",
    "ApiClient",
    "Configuration",
    "OpenApiException",
    "ApiTypeError",
    "ApiValueError",
    "ApiKeyError",
    "ApiAttributeError",
    "ApiException",
    "Agro400WithErrorsAndWarnings",
    "AgroEntityError",
    "AgroEntityErrorType",
    "AgroEntityPath",
    "AgroEntityType",
    "AgroEntityWarning",
    "AgroEntityWarningType",
    "AgroPlanResult",
    "AgroPlanSettings",
    "AgroPlanStatistics",
    "AgroPlanTask",
    "AgroUnplannedItems",
    "AgroValidateResult",
    "Attribute",
    "Bunker",
    "CalculationAsyncResult",
    "CalculationInfo",
    "CalculationSettings",
    "CalculationState",
    "CalculationStatus",
    "CapacityForecastElement",
    "Chamber",
    "CheckResult",
    "Consumer",
    "Contract",
    "ContractType",
    "CostForecastElement",
    "Crop",
    "CropType",
    "DateWindow",
    "Dryer",
    "Elevator",
    "Factory",
    "FlowType",
    "Gate",
    "General400",
    "General402",
    "General403",
    "General404",
    "General404Detail",
    "General429",
    "General500",
    "HumidityForecastElement",
    "Leftover",
    "ManufacturingOperation",
    "Market",
    "ModelField",
    "MovementMatrixElement",
    "ObjectType",
    "OperationMeasurements",
    "OperationTarget",
    "OperationType",
    "PriceForecastElement",
    "Pricelist",
    "ProductivityForecastElement",
    "ProjectConfiguration",
    "ProjectSettings",
    "SchemaError",
    "Service",
    "Silo",
    "StockForecastElement",
    "Storage",
    "Tracedata",
    "VersionResult",
]

# import apis into sdk package
from vrt_lss_agro.api.plan_api import PlanApi as PlanApi
from vrt_lss_agro.api.system_api import SystemApi as SystemApi

# import ApiClient
from vrt_lss_agro.api_response import ApiResponse as ApiResponse
from vrt_lss_agro.api_client import ApiClient as ApiClient
from vrt_lss_agro.configuration import Configuration as Configuration
from vrt_lss_agro.exceptions import OpenApiException as OpenApiException
from vrt_lss_agro.exceptions import ApiTypeError as ApiTypeError
from vrt_lss_agro.exceptions import ApiValueError as ApiValueError
from vrt_lss_agro.exceptions import ApiKeyError as ApiKeyError
from vrt_lss_agro.exceptions import ApiAttributeError as ApiAttributeError
from vrt_lss_agro.exceptions import ApiException as ApiException

# import models into sdk package
from vrt_lss_agro.models.agro400_with_errors_and_warnings import Agro400WithErrorsAndWarnings as Agro400WithErrorsAndWarnings
from vrt_lss_agro.models.agro_entity_error import AgroEntityError as AgroEntityError
from vrt_lss_agro.models.agro_entity_error_type import AgroEntityErrorType as AgroEntityErrorType
from vrt_lss_agro.models.agro_entity_path import AgroEntityPath as AgroEntityPath
from vrt_lss_agro.models.agro_entity_type import AgroEntityType as AgroEntityType
from vrt_lss_agro.models.agro_entity_warning import AgroEntityWarning as AgroEntityWarning
from vrt_lss_agro.models.agro_entity_warning_type import AgroEntityWarningType as AgroEntityWarningType
from vrt_lss_agro.models.agro_plan_result import AgroPlanResult as AgroPlanResult
from vrt_lss_agro.models.agro_plan_settings import AgroPlanSettings as AgroPlanSettings
from vrt_lss_agro.models.agro_plan_statistics import AgroPlanStatistics as AgroPlanStatistics
from vrt_lss_agro.models.agro_plan_task import AgroPlanTask as AgroPlanTask
from vrt_lss_agro.models.agro_unplanned_items import AgroUnplannedItems as AgroUnplannedItems
from vrt_lss_agro.models.agro_validate_result import AgroValidateResult as AgroValidateResult
from vrt_lss_agro.models.attribute import Attribute as Attribute
from vrt_lss_agro.models.bunker import Bunker as Bunker
from vrt_lss_agro.models.calculation_async_result import CalculationAsyncResult as CalculationAsyncResult
from vrt_lss_agro.models.calculation_info import CalculationInfo as CalculationInfo
from vrt_lss_agro.models.calculation_settings import CalculationSettings as CalculationSettings
from vrt_lss_agro.models.calculation_state import CalculationState as CalculationState
from vrt_lss_agro.models.calculation_status import CalculationStatus as CalculationStatus
from vrt_lss_agro.models.capacity_forecast_element import CapacityForecastElement as CapacityForecastElement
from vrt_lss_agro.models.chamber import Chamber as Chamber
from vrt_lss_agro.models.check_result import CheckResult as CheckResult
from vrt_lss_agro.models.consumer import Consumer as Consumer
from vrt_lss_agro.models.contract import Contract as Contract
from vrt_lss_agro.models.contract_type import ContractType as ContractType
from vrt_lss_agro.models.cost_forecast_element import CostForecastElement as CostForecastElement
from vrt_lss_agro.models.crop import Crop as Crop
from vrt_lss_agro.models.crop_type import CropType as CropType
from vrt_lss_agro.models.date_window import DateWindow as DateWindow
from vrt_lss_agro.models.dryer import Dryer as Dryer
from vrt_lss_agro.models.elevator import Elevator as Elevator
from vrt_lss_agro.models.factory import Factory as Factory
from vrt_lss_agro.models.flow_type import FlowType as FlowType
from vrt_lss_agro.models.gate import Gate as Gate
from vrt_lss_agro.models.general400 import General400 as General400
from vrt_lss_agro.models.general402 import General402 as General402
from vrt_lss_agro.models.general403 import General403 as General403
from vrt_lss_agro.models.general404 import General404 as General404
from vrt_lss_agro.models.general404_detail import General404Detail as General404Detail
from vrt_lss_agro.models.general429 import General429 as General429
from vrt_lss_agro.models.general500 import General500 as General500
from vrt_lss_agro.models.humidity_forecast_element import HumidityForecastElement as HumidityForecastElement
from vrt_lss_agro.models.leftover import Leftover as Leftover
from vrt_lss_agro.models.manufacturing_operation import ManufacturingOperation as ManufacturingOperation
from vrt_lss_agro.models.market import Market as Market
from vrt_lss_agro.models.model_field import ModelField as ModelField
from vrt_lss_agro.models.movement_matrix_element import MovementMatrixElement as MovementMatrixElement
from vrt_lss_agro.models.object_type import ObjectType as ObjectType
from vrt_lss_agro.models.operation_measurements import OperationMeasurements as OperationMeasurements
from vrt_lss_agro.models.operation_target import OperationTarget as OperationTarget
from vrt_lss_agro.models.operation_type import OperationType as OperationType
from vrt_lss_agro.models.price_forecast_element import PriceForecastElement as PriceForecastElement
from vrt_lss_agro.models.pricelist import Pricelist as Pricelist
from vrt_lss_agro.models.productivity_forecast_element import ProductivityForecastElement as ProductivityForecastElement
from vrt_lss_agro.models.project_configuration import ProjectConfiguration as ProjectConfiguration
from vrt_lss_agro.models.project_settings import ProjectSettings as ProjectSettings
from vrt_lss_agro.models.schema_error import SchemaError as SchemaError
from vrt_lss_agro.models.service import Service as Service
from vrt_lss_agro.models.silo import Silo as Silo
from vrt_lss_agro.models.stock_forecast_element import StockForecastElement as StockForecastElement
from vrt_lss_agro.models.storage import Storage as Storage
from vrt_lss_agro.models.tracedata import Tracedata as Tracedata
from vrt_lss_agro.models.version_result import VersionResult as VersionResult

