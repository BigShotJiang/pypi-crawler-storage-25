# coding: utf-8

# flake8: noqa
"""
    VRt.Agro [AG]

    Programming interface for Veeroute Agro.  # Description  The service is designed to compute the work plan of production facilities.  ## General schema  ![objects](../images/agro_objects.svg)  ### Field  - produces a specific agricultural crop with a specific moisture level - crop output from the field can be moved only to an Elevator or a Plant  ### Elevator (Threshing floor)  - consists of Gates, Dryers, short-term and long-term storage locations - dries the grain (if the crop moisture is above the allowed level) - stores dry grain in short-term storage locations (warehouses); unloading and loading of grain within a single day is allowed - stores dry grain in long-term storage locations (sleeves, trenches, mounds) - only one type of crop can be stored in a single storage at a time - sells surplus grain to the Market - production processes inside the facility: drying, loading/unloading to a storage location, storage  ### Plant  - consists of Gates, Dryers, Bunkers, Consumers - [if drying is present] dries the grain (if the crop moisture is above the allowed level) - stores dry grain in Bunkers (short-term storage tied to a specific crop) - maintains a minimum stock of grain in Bunkers for consumption - consumes grain from Bunkers - buys missing grain from the Market - production processes inside the facility: drying, loading/unloading to a storage location, storage, consumption  ### Market  - buys grain from Elevators - sells grain to Plants  ## Project  A project reflects the planned sequence of operations on agricultural crops; the operation types are described below.  ### HARVEST  Harvesting of an agricultural crop:  - between production facilities (a Field and an Elevator or a Plant) - the operation occurs within a single day - grain moisture is determined at the Field  |                          | Object (target_key)  | Sub-object (target_detail_key) | |--------------------------|----------------------|--------------------------------| | Source                   | Field                | -                              | | Destination              | Elevator or Plant    | Gates                          |  ### DRY  Drying of a crop:  - inside a production facility (Elevator or Plant) - duration of the operation — one day - during drying both the mass and the moisture type change (WET -> DRY) - the source specifies the mass of the wet crop - the destination specifies the resulting mass of the dry crop  |                          | Object (target_key)  | Sub-object (target_detail_key) | |--------------------------|----------------------|--------------------------------| | Source                   | Elevator or Plant    | Gates                          | | Destination              | Elevator or Plant    | Dryer                          |  ### LOAD  Loading of a crop from the Gates into a Storage location (long-term, short-term, bunker):  - between parts of the same production facility (Elevator or Plant) - the operation occurs within a single day  |                          | Object (target_key)  | Sub-object (target_detail_key)                            | |--------------------------|----------------------|-----------------------------------------------------------| | Source                   | Elevator or Plant    | Gates or Dryer                                            | | Destination              | Elevator or Plant    | Storage location (long-term, short-term, bunker)          |  ### UNLOAD  Unloading of a crop from a storage location to the Gates:  - between parts of the same production facility (Elevator) - the operation occurs within a single day  |                          | Object (target_key)  | Sub-object (target_detail_key)                                       | |--------------------------|----------------------|----------------------------------------------------------------------| | Source                   | Elevator             | Storage location (long-term, short-term, bunker) or Dryer            | | Destination              | Elevator             | Gates                                                                |  ### STORE  Crop storage:  - the storage location does not change - duration of the operation — one day - the operation occurs overnight  |                          | Object (target_key)  | Sub-object (target_detail_key)                            | |--------------------------|----------------------|-----------------------------------------------------------| | Source                   | Elevator or Plant    | Storage location (long-term, short-term, bunker)          | | Destination              | Elevator or Plant    | The same storage location                                 |  ### RELOCATE  Transport between production facilities:  - between production facilities (Elevator and Plant) - the operation occurs within a single day  |                          | Object (target_key)  | Sub-object (target_detail_key) | |--------------------------|----------------------|--------------------------------| | Source                   | Elevator             | Gates                          | | Destination              | Plant                | Gates                          |  ### CONSUMPTION  Consumption of a crop by the plant:  - between parts of the same production facility (Plant) - the operation occurs within a single day - consumption goes from a Bunker - additionally we can consume directly from the Gates or the Dryer without storing in a Bunker  |                          | Object (target_key)  | Sub-object (target_detail_key) | |--------------------------|----------------------|--------------------------------| | Source                   | Plant                | Bunker or Gates or Dryer       | | Destination              | Plant                | Consumer                       |  ### SELL  Sale of a crop:  - between production facilities (Elevator and Market) - the operation occurs within a single day  |                          | Object (target_key)  | Sub-object (target_detail_key) | |--------------------------|----------------------|--------------------------------| | Source                   | Elevator             | Gates                          | | Destination              | Market               | Contract                       |  ### BUY  Purchase of a crop:  - between production facilities (Market and Plant) - the operation occurs within a single day  |                          | Object (target_key)  | Sub-object (target_detail_key) | |--------------------------|----------------------|--------------------------------| | Source                   | Market               | Contract                       | | Destination              | Plant                | Gates                          |  ## Entity diagram  ![erd](../uml/agro.svg) 

    The version of the OpenAPI document: 7.36.3317
    Contact: support@veeroute.com
    Generated by OpenAPI Generator (https://openapi-generator.tech)

    Do not edit the class manually.
"""  # noqa: E501

# import models into model package
from vrt_lss_agro.models.agro400_with_errors_and_warnings import Agro400WithErrorsAndWarnings
from vrt_lss_agro.models.agro_entity_error import AgroEntityError
from vrt_lss_agro.models.agro_entity_error_type import AgroEntityErrorType
from vrt_lss_agro.models.agro_entity_path import AgroEntityPath
from vrt_lss_agro.models.agro_entity_type import AgroEntityType
from vrt_lss_agro.models.agro_entity_warning import AgroEntityWarning
from vrt_lss_agro.models.agro_entity_warning_type import AgroEntityWarningType
from vrt_lss_agro.models.agro_plan_result import AgroPlanResult
from vrt_lss_agro.models.agro_plan_settings import AgroPlanSettings
from vrt_lss_agro.models.agro_plan_statistics import AgroPlanStatistics
from vrt_lss_agro.models.agro_plan_task import AgroPlanTask
from vrt_lss_agro.models.agro_unplanned_items import AgroUnplannedItems
from vrt_lss_agro.models.agro_validate_result import AgroValidateResult
from vrt_lss_agro.models.attribute import Attribute
from vrt_lss_agro.models.bunker import Bunker
from vrt_lss_agro.models.calculation_async_result import CalculationAsyncResult
from vrt_lss_agro.models.calculation_info import CalculationInfo
from vrt_lss_agro.models.calculation_settings import CalculationSettings
from vrt_lss_agro.models.calculation_state import CalculationState
from vrt_lss_agro.models.calculation_status import CalculationStatus
from vrt_lss_agro.models.capacity_forecast_element import CapacityForecastElement
from vrt_lss_agro.models.chamber import Chamber
from vrt_lss_agro.models.check_result import CheckResult
from vrt_lss_agro.models.consumer import Consumer
from vrt_lss_agro.models.contract import Contract
from vrt_lss_agro.models.contract_type import ContractType
from vrt_lss_agro.models.cost_forecast_element import CostForecastElement
from vrt_lss_agro.models.crop import Crop
from vrt_lss_agro.models.crop_type import CropType
from vrt_lss_agro.models.date_window import DateWindow
from vrt_lss_agro.models.dryer import Dryer
from vrt_lss_agro.models.elevator import Elevator
from vrt_lss_agro.models.factory import Factory
from vrt_lss_agro.models.flow_type import FlowType
from vrt_lss_agro.models.gate import Gate
from vrt_lss_agro.models.general400 import General400
from vrt_lss_agro.models.general402 import General402
from vrt_lss_agro.models.general403 import General403
from vrt_lss_agro.models.general404 import General404
from vrt_lss_agro.models.general404_detail import General404Detail
from vrt_lss_agro.models.general429 import General429
from vrt_lss_agro.models.general500 import General500
from vrt_lss_agro.models.humidity_forecast_element import HumidityForecastElement
from vrt_lss_agro.models.leftover import Leftover
from vrt_lss_agro.models.manufacturing_operation import ManufacturingOperation
from vrt_lss_agro.models.market import Market
from vrt_lss_agro.models.model_field import ModelField
from vrt_lss_agro.models.movement_matrix_element import MovementMatrixElement
from vrt_lss_agro.models.object_type import ObjectType
from vrt_lss_agro.models.operation_measurements import OperationMeasurements
from vrt_lss_agro.models.operation_target import OperationTarget
from vrt_lss_agro.models.operation_type import OperationType
from vrt_lss_agro.models.price_forecast_element import PriceForecastElement
from vrt_lss_agro.models.pricelist import Pricelist
from vrt_lss_agro.models.productivity_forecast_element import ProductivityForecastElement
from vrt_lss_agro.models.project_configuration import ProjectConfiguration
from vrt_lss_agro.models.project_settings import ProjectSettings
from vrt_lss_agro.models.schema_error import SchemaError
from vrt_lss_agro.models.service import Service
from vrt_lss_agro.models.silo import Silo
from vrt_lss_agro.models.stock_forecast_element import StockForecastElement
from vrt_lss_agro.models.storage import Storage
from vrt_lss_agro.models.tracedata import Tracedata
from vrt_lss_agro.models.version_result import VersionResult

