# coding: utf-8

"""
    VRt.Agro [AG]

    Programming interface for Veeroute Agro.  # Description  The service is designed to compute the work plan of production facilities.  ## General schema  ![objects](../images/agro_objects.svg)  ### Field  - produces a specific agricultural crop with a specific moisture level - crop output from the field can be moved only to an Elevator or a Plant  ### Elevator (Threshing floor)  - consists of Gates, Dryers, short-term and long-term storage locations - dries the grain (if the crop moisture is above the allowed level) - stores dry grain in short-term storage locations (warehouses); unloading and loading of grain within a single day is allowed - stores dry grain in long-term storage locations (sleeves, trenches, mounds) - only one type of crop can be stored in a single storage at a time - sells surplus grain to the Market - production processes inside the facility: drying, loading/unloading to a storage location, storage  ### Plant  - consists of Gates, Dryers, Bunkers, Consumers - [if drying is present] dries the grain (if the crop moisture is above the allowed level) - stores dry grain in Bunkers (short-term storage tied to a specific crop) - maintains a minimum stock of grain in Bunkers for consumption - consumes grain from Bunkers - buys missing grain from the Market - production processes inside the facility: drying, loading/unloading to a storage location, storage, consumption  ### Market  - buys grain from Elevators - sells grain to Plants  ## Project  A project reflects the planned sequence of operations on agricultural crops; the operation types are described below.  ### HARVEST  Harvesting of an agricultural crop:  - between production facilities (a Field and an Elevator or a Plant) - the operation occurs within a single day - grain moisture is determined at the Field  |                          | Object (target_key)  | Sub-object (target_detail_key) | |--------------------------|----------------------|--------------------------------| | Source                   | Field                | -                              | | Destination              | Elevator or Plant    | Gates                          |  ### DRY  Drying of a crop:  - inside a production facility (Elevator or Plant) - duration of the operation — one day - during drying both the mass and the moisture type change (WET -> DRY) - the source specifies the mass of the wet crop - the destination specifies the resulting mass of the dry crop  |                          | Object (target_key)  | Sub-object (target_detail_key) | |--------------------------|----------------------|--------------------------------| | Source                   | Elevator or Plant    | Gates                          | | Destination              | Elevator or Plant    | Dryer                          |  ### LOAD  Loading of a crop from the Gates into a Storage location (long-term, short-term, bunker):  - between parts of the same production facility (Elevator or Plant) - the operation occurs within a single day  |                          | Object (target_key)  | Sub-object (target_detail_key)                            | |--------------------------|----------------------|-----------------------------------------------------------| | Source                   | Elevator or Plant    | Gates or Dryer                                            | | Destination              | Elevator or Plant    | Storage location (long-term, short-term, bunker)          |  ### UNLOAD  Unloading of a crop from a storage location to the Gates:  - between parts of the same production facility (Elevator) - the operation occurs within a single day  |                          | Object (target_key)  | Sub-object (target_detail_key)                                       | |--------------------------|----------------------|----------------------------------------------------------------------| | Source                   | Elevator             | Storage location (long-term, short-term, bunker) or Dryer            | | Destination              | Elevator             | Gates                                                                |  ### STORE  Crop storage:  - the storage location does not change - duration of the operation — one day - the operation occurs overnight  |                          | Object (target_key)  | Sub-object (target_detail_key)                            | |--------------------------|----------------------|-----------------------------------------------------------| | Source                   | Elevator or Plant    | Storage location (long-term, short-term, bunker)          | | Destination              | Elevator or Plant    | The same storage location                                 |  ### RELOCATE  Transport between production facilities:  - between production facilities (Elevator and Plant) - the operation occurs within a single day  |                          | Object (target_key)  | Sub-object (target_detail_key) | |--------------------------|----------------------|--------------------------------| | Source                   | Elevator             | Gates                          | | Destination              | Plant                | Gates                          |  ### CONSUMPTION  Consumption of a crop by the plant:  - between parts of the same production facility (Plant) - the operation occurs within a single day - consumption goes from a Bunker - additionally we can consume directly from the Gates or the Dryer without storing in a Bunker  |                          | Object (target_key)  | Sub-object (target_detail_key) | |--------------------------|----------------------|--------------------------------| | Source                   | Plant                | Bunker or Gates or Dryer       | | Destination              | Plant                | Consumer                       |  ### SELL  Sale of a crop:  - between production facilities (Elevator and Market) - the operation occurs within a single day  |                          | Object (target_key)  | Sub-object (target_detail_key) | |--------------------------|----------------------|--------------------------------| | Source                   | Elevator             | Gates                          | | Destination              | Market               | Contract                       |  ### BUY  Purchase of a crop:  - between production facilities (Market and Plant) - the operation occurs within a single day  |                          | Object (target_key)  | Sub-object (target_detail_key) | |--------------------------|----------------------|--------------------------------| | Source                   | Market               | Contract                       | | Destination              | Plant                | Gates                          |  ## Entity diagram  ![erd](../uml/agro.svg) 

    The version of the OpenAPI document: 7.36.3317
    Contact: support@veeroute.com
    Generated by OpenAPI Generator (https://openapi-generator.tech)

    Do not edit the class manually.
"""  # noqa: E501


from __future__ import annotations
import pprint
import re  # noqa: F401
import json

from pydantic import BaseModel, ConfigDict, Field, field_validator
from typing import Any, ClassVar, Dict, List, Optional
from typing_extensions import Annotated
from vrt_lss_agro.models.calculation_status import CalculationStatus
from typing import Optional, Set
from typing_extensions import Self

class CalculationInfo(BaseModel):
    """
    Calculation information.
    """ # noqa: E501
    status: CalculationStatus
    message: Optional[Annotated[str, Field(min_length=0, strict=True, max_length=10000)]] = Field(default=None, description="Message with additional information about the calculation status.")
    result_version: Annotated[int, Field(le=1000000, strict=True, ge=0)] = Field(description="Planning result version.")
    preparing_time: Annotated[str, Field(min_length=3, strict=True, max_length=16)] = Field(description="Time duration according to [ISO 8601 duration](https://en.wikipedia.org/wiki/ISO_8601#Durations).")
    business_validation_time: Annotated[str, Field(min_length=3, strict=True, max_length=16)] = Field(description="Time duration according to [ISO 8601 duration](https://en.wikipedia.org/wiki/ISO_8601#Durations).")
    math_validation_time: Annotated[str, Field(min_length=3, strict=True, max_length=16)] = Field(description="Time duration according to [ISO 8601 duration](https://en.wikipedia.org/wiki/ISO_8601#Durations).")
    waiting_time: Annotated[str, Field(min_length=3, strict=True, max_length=16)] = Field(description="Time duration according to [ISO 8601 duration](https://en.wikipedia.org/wiki/ISO_8601#Durations).")
    calculation_time: Annotated[str, Field(min_length=3, strict=True, max_length=16)] = Field(description="Time duration according to [ISO 8601 duration](https://en.wikipedia.org/wiki/ISO_8601#Durations).")
    postprocessing_time: Optional[Annotated[str, Field(min_length=3, strict=True, max_length=16)]] = Field(default='PT0S', description="Time duration according to [ISO 8601 duration](https://en.wikipedia.org/wiki/ISO_8601#Durations).")
    additional_properties: Dict[str, Any] = {}
    __properties: ClassVar[List[str]] = ["status", "message", "result_version", "preparing_time", "business_validation_time", "math_validation_time", "waiting_time", "calculation_time", "postprocessing_time"]

    @field_validator('preparing_time')
    def preparing_time_validate_regular_expression(cls, value):
        """Validates the regular expression"""
        if not re.match(r"^P(?!$)((\d+Y)|(\d+\.\d+Y$))?((\d+M)|(\d+\.\d+M$))?((\d+W)|(\d+\.\d+W$))?((\d+D)|(\d+\.\d+D$))?(T(?=\d)((\d+H)|(\d+\.\d+H$))?((\d+M)|(\d+\.\d+M$))?(\d+(\.\d+)?S)?)??$", value):
            raise ValueError(r"must validate the regular expression /^P(?!$)((\d+Y)|(\d+\.\d+Y$))?((\d+M)|(\d+\.\d+M$))?((\d+W)|(\d+\.\d+W$))?((\d+D)|(\d+\.\d+D$))?(T(?=\d)((\d+H)|(\d+\.\d+H$))?((\d+M)|(\d+\.\d+M$))?(\d+(\.\d+)?S)?)??$/")
        return value

    @field_validator('business_validation_time')
    def business_validation_time_validate_regular_expression(cls, value):
        """Validates the regular expression"""
        if not re.match(r"^P(?!$)((\d+Y)|(\d+\.\d+Y$))?((\d+M)|(\d+\.\d+M$))?((\d+W)|(\d+\.\d+W$))?((\d+D)|(\d+\.\d+D$))?(T(?=\d)((\d+H)|(\d+\.\d+H$))?((\d+M)|(\d+\.\d+M$))?(\d+(\.\d+)?S)?)??$", value):
            raise ValueError(r"must validate the regular expression /^P(?!$)((\d+Y)|(\d+\.\d+Y$))?((\d+M)|(\d+\.\d+M$))?((\d+W)|(\d+\.\d+W$))?((\d+D)|(\d+\.\d+D$))?(T(?=\d)((\d+H)|(\d+\.\d+H$))?((\d+M)|(\d+\.\d+M$))?(\d+(\.\d+)?S)?)??$/")
        return value

    @field_validator('math_validation_time')
    def math_validation_time_validate_regular_expression(cls, value):
        """Validates the regular expression"""
        if not re.match(r"^P(?!$)((\d+Y)|(\d+\.\d+Y$))?((\d+M)|(\d+\.\d+M$))?((\d+W)|(\d+\.\d+W$))?((\d+D)|(\d+\.\d+D$))?(T(?=\d)((\d+H)|(\d+\.\d+H$))?((\d+M)|(\d+\.\d+M$))?(\d+(\.\d+)?S)?)??$", value):
            raise ValueError(r"must validate the regular expression /^P(?!$)((\d+Y)|(\d+\.\d+Y$))?((\d+M)|(\d+\.\d+M$))?((\d+W)|(\d+\.\d+W$))?((\d+D)|(\d+\.\d+D$))?(T(?=\d)((\d+H)|(\d+\.\d+H$))?((\d+M)|(\d+\.\d+M$))?(\d+(\.\d+)?S)?)??$/")
        return value

    @field_validator('waiting_time')
    def waiting_time_validate_regular_expression(cls, value):
        """Validates the regular expression"""
        if not re.match(r"^P(?!$)((\d+Y)|(\d+\.\d+Y$))?((\d+M)|(\d+\.\d+M$))?((\d+W)|(\d+\.\d+W$))?((\d+D)|(\d+\.\d+D$))?(T(?=\d)((\d+H)|(\d+\.\d+H$))?((\d+M)|(\d+\.\d+M$))?(\d+(\.\d+)?S)?)??$", value):
            raise ValueError(r"must validate the regular expression /^P(?!$)((\d+Y)|(\d+\.\d+Y$))?((\d+M)|(\d+\.\d+M$))?((\d+W)|(\d+\.\d+W$))?((\d+D)|(\d+\.\d+D$))?(T(?=\d)((\d+H)|(\d+\.\d+H$))?((\d+M)|(\d+\.\d+M$))?(\d+(\.\d+)?S)?)??$/")
        return value

    @field_validator('calculation_time')
    def calculation_time_validate_regular_expression(cls, value):
        """Validates the regular expression"""
        if not re.match(r"^P(?!$)((\d+Y)|(\d+\.\d+Y$))?((\d+M)|(\d+\.\d+M$))?((\d+W)|(\d+\.\d+W$))?((\d+D)|(\d+\.\d+D$))?(T(?=\d)((\d+H)|(\d+\.\d+H$))?((\d+M)|(\d+\.\d+M$))?(\d+(\.\d+)?S)?)??$", value):
            raise ValueError(r"must validate the regular expression /^P(?!$)((\d+Y)|(\d+\.\d+Y$))?((\d+M)|(\d+\.\d+M$))?((\d+W)|(\d+\.\d+W$))?((\d+D)|(\d+\.\d+D$))?(T(?=\d)((\d+H)|(\d+\.\d+H$))?((\d+M)|(\d+\.\d+M$))?(\d+(\.\d+)?S)?)??$/")
        return value

    @field_validator('postprocessing_time')
    def postprocessing_time_validate_regular_expression(cls, value):
        """Validates the regular expression"""
        if value is None:
            return value

        if not re.match(r"^P(?!$)((\d+Y)|(\d+\.\d+Y$))?((\d+M)|(\d+\.\d+M$))?((\d+W)|(\d+\.\d+W$))?((\d+D)|(\d+\.\d+D$))?(T(?=\d)((\d+H)|(\d+\.\d+H$))?((\d+M)|(\d+\.\d+M$))?(\d+(\.\d+)?S)?)??$", value):
            raise ValueError(r"must validate the regular expression /^P(?!$)((\d+Y)|(\d+\.\d+Y$))?((\d+M)|(\d+\.\d+M$))?((\d+W)|(\d+\.\d+W$))?((\d+D)|(\d+\.\d+D$))?(T(?=\d)((\d+H)|(\d+\.\d+H$))?((\d+M)|(\d+\.\d+M$))?(\d+(\.\d+)?S)?)??$/")
        return value

    model_config = ConfigDict(
        populate_by_name=True,
        validate_assignment=True,
        protected_namespaces=(),
    )


    def to_str(self) -> str:
        """Returns the string representation of the model using alias"""
        return pprint.pformat(self.model_dump(by_alias=True))

    def to_json(self) -> str:
        """Returns the JSON representation of the model using alias"""
        # TODO: pydantic v2: use .model_dump_json(by_alias=True, exclude_unset=True) instead
        return json.dumps(self.to_dict())

    @classmethod
    def from_json(cls, json_str: str) -> Optional[Self]:
        """Create an instance of CalculationInfo from a JSON string"""
        return cls.from_dict(json.loads(json_str))

    def to_dict(self) -> Dict[str, Any]:
        """Return the dictionary representation of the model using alias.

        This has the following differences from calling pydantic's
        `self.model_dump(by_alias=True)`:

        * `None` is only added to the output dict for nullable fields that
          were set at model initialization. Other fields with value `None`
          are ignored.
        * Fields in `self.additional_properties` are added to the output dict.
        """
        excluded_fields: Set[str] = set([
            "additional_properties",
        ])

        _dict = self.model_dump(
            by_alias=True,
            exclude=excluded_fields,
            exclude_none=True,
        )
        # puts key-value pairs in additional_properties in the top level
        if self.additional_properties is not None:
            for _key, _value in self.additional_properties.items():
                _dict[_key] = _value

        # set to None if message (nullable) is None
        # and model_fields_set contains the field
        if self.message is None and "message" in self.model_fields_set:
            _dict['message'] = None

        return _dict

    @classmethod
    def from_dict(cls, obj: Optional[Dict[str, Any]]) -> Optional[Self]:
        """Create an instance of CalculationInfo from a dict"""
        if obj is None:
            return None

        if not isinstance(obj, dict):
            return cls.model_validate(obj)

        _obj = cls.model_validate({
            "status": obj.get("status"),
            "message": obj.get("message"),
            "result_version": obj.get("result_version"),
            "preparing_time": obj.get("preparing_time") if obj.get("preparing_time") is not None else 'PT0S',
            "business_validation_time": obj.get("business_validation_time") if obj.get("business_validation_time") is not None else 'PT0S',
            "math_validation_time": obj.get("math_validation_time") if obj.get("math_validation_time") is not None else 'PT0S',
            "waiting_time": obj.get("waiting_time") if obj.get("waiting_time") is not None else 'PT0S',
            "calculation_time": obj.get("calculation_time") if obj.get("calculation_time") is not None else 'PT0S',
            "postprocessing_time": obj.get("postprocessing_time") if obj.get("postprocessing_time") is not None else 'PT0S'
        })
        # store additional fields in additional_properties
        for _key in obj.keys():
            if _key not in cls.__properties:
                _obj.additional_properties[_key] = obj.get(_key)

        return _obj


