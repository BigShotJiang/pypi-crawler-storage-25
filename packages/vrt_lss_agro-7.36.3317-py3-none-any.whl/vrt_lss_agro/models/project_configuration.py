# coding: utf-8

"""
    VRt.Agro [AG]

    Programming interface for Veeroute Agro.  # Description  The service is designed to compute the work plan of production facilities.  ## General schema  ![objects](../images/agro_objects.svg)  ### Field  - produces a specific agricultural crop with a specific moisture level - crop output from the field can be moved only to an Elevator or a Plant  ### Elevator (Threshing floor)  - consists of Gates, Dryers, short-term and long-term storage locations - dries the grain (if the crop moisture is above the allowed level) - stores dry grain in short-term storage locations (warehouses); unloading and loading of grain within a single day is allowed - stores dry grain in long-term storage locations (sleeves, trenches, mounds) - only one type of crop can be stored in a single storage at a time - sells surplus grain to the Market - production processes inside the facility: drying, loading/unloading to a storage location, storage  ### Plant  - consists of Gates, Dryers, Bunkers, Consumers - [if drying is present] dries the grain (if the crop moisture is above the allowed level) - stores dry grain in Bunkers (short-term storage tied to a specific crop) - maintains a minimum stock of grain in Bunkers for consumption - consumes grain from Bunkers - buys missing grain from the Market - production processes inside the facility: drying, loading/unloading to a storage location, storage, consumption  ### Market  - buys grain from Elevators - sells grain to Plants  ## Project  A project reflects the planned sequence of operations on agricultural crops; the operation types are described below.  ### HARVEST  Harvesting of an agricultural crop:  - between production facilities (a Field and an Elevator or a Plant) - the operation occurs within a single day - grain moisture is determined at the Field  |                          | Object (target_key)  | Sub-object (target_detail_key) | |--------------------------|----------------------|--------------------------------| | Source                   | Field                | -                              | | Destination              | Elevator or Plant    | Gates                          |  ### DRY  Drying of a crop:  - inside a production facility (Elevator or Plant) - duration of the operation — one day - during drying both the mass and the moisture type change (WET -> DRY) - the source specifies the mass of the wet crop - the destination specifies the resulting mass of the dry crop  |                          | Object (target_key)  | Sub-object (target_detail_key) | |--------------------------|----------------------|--------------------------------| | Source                   | Elevator or Plant    | Gates                          | | Destination              | Elevator or Plant    | Dryer                          |  ### LOAD  Loading of a crop from the Gates into a Storage location (long-term, short-term, bunker):  - between parts of the same production facility (Elevator or Plant) - the operation occurs within a single day  |                          | Object (target_key)  | Sub-object (target_detail_key)                            | |--------------------------|----------------------|-----------------------------------------------------------| | Source                   | Elevator or Plant    | Gates or Dryer                                            | | Destination              | Elevator or Plant    | Storage location (long-term, short-term, bunker)          |  ### UNLOAD  Unloading of a crop from a storage location to the Gates:  - between parts of the same production facility (Elevator) - the operation occurs within a single day  |                          | Object (target_key)  | Sub-object (target_detail_key)                                       | |--------------------------|----------------------|----------------------------------------------------------------------| | Source                   | Elevator             | Storage location (long-term, short-term, bunker) or Dryer            | | Destination              | Elevator             | Gates                                                                |  ### STORE  Crop storage:  - the storage location does not change - duration of the operation — one day - the operation occurs overnight  |                          | Object (target_key)  | Sub-object (target_detail_key)                            | |--------------------------|----------------------|-----------------------------------------------------------| | Source                   | Elevator or Plant    | Storage location (long-term, short-term, bunker)          | | Destination              | Elevator or Plant    | The same storage location                                 |  ### RELOCATE  Transport between production facilities:  - between production facilities (Elevator and Plant) - the operation occurs within a single day  |                          | Object (target_key)  | Sub-object (target_detail_key) | |--------------------------|----------------------|--------------------------------| | Source                   | Elevator             | Gates                          | | Destination              | Plant                | Gates                          |  ### CONSUMPTION  Consumption of a crop by the plant:  - between parts of the same production facility (Plant) - the operation occurs within a single day - consumption goes from a Bunker - additionally we can consume directly from the Gates or the Dryer without storing in a Bunker  |                          | Object (target_key)  | Sub-object (target_detail_key) | |--------------------------|----------------------|--------------------------------| | Source                   | Plant                | Bunker or Gates or Dryer       | | Destination              | Plant                | Consumer                       |  ### SELL  Sale of a crop:  - between production facilities (Elevator and Market) - the operation occurs within a single day  |                          | Object (target_key)  | Sub-object (target_detail_key) | |--------------------------|----------------------|--------------------------------| | Source                   | Elevator             | Gates                          | | Destination              | Market               | Contract                       |  ### BUY  Purchase of a crop:  - between production facilities (Market and Plant) - the operation occurs within a single day  |                          | Object (target_key)  | Sub-object (target_detail_key) | |--------------------------|----------------------|--------------------------------| | Source                   | Market               | Contract                       | | Destination              | Plant                | Gates                          |  ## Entity diagram  ![erd](../uml/agro.svg) 

    The version of the OpenAPI document: 7.36.3317
    Contact: support@veeroute.com
    Generated by OpenAPI Generator (https://openapi-generator.tech)

    Do not edit the class manually.
"""  # noqa: E501


from __future__ import annotations
import json
from enum import Enum
from typing_extensions import Self


class ProjectConfiguration(str, Enum):
    """
    Target function type. 
    """

    """
    allowed enum values
    """
    OPTIMIZE_DISTANCE = 'OPTIMIZE_DISTANCE'
    OPTIMIZE_COST = 'OPTIMIZE_COST'

    @classmethod
    def from_json(cls, json_str: str) -> Self:
        """Create an instance of ProjectConfiguration from a JSON string"""
        return cls(json.loads(json_str))


