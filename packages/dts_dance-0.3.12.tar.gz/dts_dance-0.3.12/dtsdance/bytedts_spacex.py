from typing import Any, NamedTuple

from .bytecloud import ByteCloudClient
import requests
from loguru import logger

ACTION_NAME_MAPPING = {
    "getGatewayRules": "获取gateway rules",
    "setGatewayRules": "Set gateway rule",
    "operationGatewayCNames_list": "获取gateway cnames",
    "operationGatewayCNames_set": "Set gateway cname",
    "getGatewayRoute": "获取gateway routes",
    "setGatewayRoute": "set gateway route",
    "delGatewayRoute": "删除gateway_route",
}


class GatewayInfo(NamedTuple):
    mgr_name: str
    ctrl_name: str
    gateway_endpoint: str
    auth_user: str
    auth_password: str
    root_secret_key: str
    gw_meta_db: str


class BytedtsSpaceXClient:
    """
    ByteDTS SpaceX 运维平台 API 客户端
    """

    def __init__(self, bytecloud_client: ByteCloudClient):
        """
        初始化 SpaceX 通知客户端
        """
        self.bytecloud_client = bytecloud_client

    def list_mgr(self, site: str) -> list[Any]:
        site_info = self.bytecloud_client.get_site_config(site)
        print(f"site_info: {site_info}")
        url = f"{site_info.endpoint_spacex_bytedts}/bytedts/v1/queryServerMeta"

        try:
            response = requests.post(url, headers=self.bytecloud_client.build_request_headers(site))
            response.raise_for_status()

            result = response.json()
            return result.get("data", [])

        except Exception as e:
            logger.warning(f"do quest queryServerMeta exception: {e}")
            raise

    def register_resource(self, site: str, payload: dict[str, Any]) -> bool:
        site_info = self.bytecloud_client.get_site_config(site)
        url = f"{site_info.endpoint_spacex_bytedts}/resource/v1/registerResource"
        try:
            response = requests.post(url, json=payload, headers=self.bytecloud_client.build_request_headers(site))
            # print(f"response status code: {response.status_code}, response text: {response.text}")

            response.raise_for_status()

            result = response.json()
            return result.get("message", "") == "ok"

        except Exception as e:
            logger.warning(f"do quest registerResource exception: {e}")
            raise

    def list_resources(self, site: str, payload: dict[str, Any]) -> list[str]:
        site_info = self.bytecloud_client.get_site_config(site)
        url = f"{site_info.endpoint_spacex_bytedts}/resource/v1/listResource"
        try:
            response = requests.post(url, json=payload, headers=self.bytecloud_client.build_request_headers(site))
            # print(f"response status code: {response.status_code}, response text: {response.text}")

            response.raise_for_status()

            result = response.json()
            if not result.get("message", "") == "ok":
                return []

            items = result.get("data", {}).get("items", [])
            return [item["name"] for item in items]
        except Exception as e:
            logger.warning(f"do quest listResource exception: {e}")
            raise

    def register_gateway(self, site: str, gateway_info: GatewayInfo) -> bool:
        site_info = self.bytecloud_client.get_site_config(site)
        url = f"{site_info.endpoint_spacex_bytedts}/bytedts/v1/registryGateway"
        payload = {
            "region": gateway_info.mgr_name,
            "server_region": gateway_info.mgr_name,
            "cluster_region": gateway_info.ctrl_name,
            "cluster_name": gateway_info.ctrl_name,
            "server_domain": gateway_info.gateway_endpoint,
            "frontend_user": gateway_info.auth_user,
            "gateway_user": gateway_info.auth_user,
            "root_secret_key": gateway_info.root_secret_key,
            "gateway_password": gateway_info.auth_password,
            "frontend_password": gateway_info.auth_password,
            "gw_meta_db": gateway_info.gw_meta_db,
            "gateway_type": "psm",
        }
        try:
            response = requests.post(url, json=payload, headers=self.bytecloud_client.build_request_headers(site))
            # print(f"response status code: {response.status_code}, response text: {response.text}")

            response.raise_for_status()

            result = response.json()
            return result.get("message", "") == "ok"

        except Exception as e:
            logger.warning(f"do quest registryGateway exception: {e}")
            raise

    def _gateway_operation_directly(self, site: str, operation: str, payload: dict[str, Any]) -> dict[str, Any]:
        site_info = self.bytecloud_client.get_site_config(site)
        url = f"{site_info.endpoint_spacex_bytedts}/bytedts/v1/{operation}"
        try:
            response = requests.post(url, json=payload, headers=self.bytecloud_client.build_request_headers(site))
            # print(f"response status code: {response.status_code}, response text: {response.text}")

            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning(f"do quest gateway_operation exception: {e}")
            raise

    def _gateway_operation_from_bytecloud_frontend_gateway(
        self, site: str, operation: str, payload: dict[str, Any], operation_suffix : str | None
    ) -> dict[str, Any]:
        # TODO 走前端网关的方式，还要再验证多环境的适应性
        site_info = self.bytecloud_client.get_site_config(site)
        if not site_info.endpoint_spacex:
            raise ValueError(f"Site {site} does not supported to request spacex api through bytecloud frontend gateway")

        url_spacex = f"{site_info.endpoint_spacex}/nocode/action/run"
        url_spacex_bytedts = f"{site_info.endpoint_spacex_bytedts}/bytedts/v1/{operation}"
        action_name = ACTION_NAME_MAPPING.get(f"{operation}_{operation_suffix}", "") if operation_suffix else ACTION_NAME_MAPPING.get(operation, "")
        if not action_name:
            raise ValueError(f"Can't find action name from ACTION_NAME_MAPPING for operation {operation}")

        headers = self.bytecloud_client.build_request_headers(site)
        headers["x-biz-app"] = "null"
        outer_payload = {
            "actionType": "API",
            "elementId": "widget-2cf19e8f-8e00-4d94-ad89-1f1cc28a110b",
            "actionId": 99999,
            "actionMeta": {
                "method": "POST",
                "url": url_spacex_bytedts,
                "params": payload,
            },
            "actionName": action_name,
            "actionLabel": action_name,
            "node": "bytedts|app|T:runtimeResource.a3743f86-1fd1-44cf-d358-1c37f8eda7e8",
            "orderType": "changefree",
            "enableJwt": True,
            "isSyncSpacexTicketCenter": True,
            "spacexTicketType": "request",
            "product": "ByteDTS_i18n",
            "changeRiskControlApplyMeta": {"enabled": False},
        }

        # curl_cmd = ddutil.output_curl(url_spacex, headers, outer_payload)
        # print(f"Equivalent curl:\n{curl_cmd}")

        try:
            response = requests.post(url_spacex, json=outer_payload, headers=headers)
            print(f"response status code: {response.status_code}, response text: {response.text}")

            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning(f"do quest gateway_operation exception: {e}")
            raise

    def gateway_operation(self, site: str, operation: str, payload: dict[str, Any], operation_suffix: str | None = None) -> dict[str, Any]:
        if site in ["cn", "i18n-bd"]:
            return self._gateway_operation_directly(site, operation, payload)
        else:
            return self._gateway_operation_from_bytecloud_frontend_gateway(site, operation, payload, operation_suffix)
