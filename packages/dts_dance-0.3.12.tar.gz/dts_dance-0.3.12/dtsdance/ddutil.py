from typing import Any
from loguru import logger
import requests
import json
from urllib.parse import urlencode


def make_request(method: str, url: str, headers: dict[str, str], payload: dict | None = None, timeout: int | None = None) -> dict[str, Any]:
    """
    发送 HTTP 请求的通用方法

    Args:
        method: HTTP 方法 (GET/POST/DELETE)
        url: 请求 URL
        headers: 请求头
        payload: POST 请求的 JSON 数据
        timeout: 请求超时时间（秒）

    Returns:
        dict[str, Any]: 解析后的 JSON 响应
    """
    response = None
    try:
        if method.upper() == "GET":
            response = requests.get(url, headers=headers, params=payload, timeout=timeout)
        elif method.upper() == "DELETE":
            response = requests.delete(url, headers=headers, timeout=timeout)
        elif method.upper() == "PUT":
            response = requests.put(url, json=payload, headers=headers, timeout=timeout)
        elif method.upper() == "POST":
            response = requests.post(url, json=payload, headers=headers, timeout=timeout)
        else:
            raise ValueError(f"不支持的 HTTP 方法: {method}")

        # print(f"response.text: {response.text}")
        # 检查响应状态码
        # response.raise_for_status()

        # 解析 JSON 响应
        return response.json()

    except Exception as e:
        error_msg = f"make_request occur error, error: {e}"
        if response is not None:
            error_msg += f", response.text: {response.text}"
        logger.warning(error_msg)
        raise


def output_curl(url: str, headers: dict[str, str], payload: dict | None = None, method: str = "POST") -> str:
    """
    生成等效的 curl 命令字符串
    """
    method_upper = method.upper()
    curl_headers = " \\\n    ".join([f"-H '{k}: {v}'" for k, v in headers.items()])

    if method_upper == "GET":
        curl_url = url
        if payload:
            query_string = urlencode(payload)
            separator = "&" if "?" in url else "?"
            curl_url = f"{url}{separator}{query_string}"
        return f"""curl '{curl_url}' \\
    {curl_headers}"""

    if payload:
        curl_payload = json.dumps(payload, ensure_ascii=False)
        return f"""curl -X {method_upper} '{url}' \\
    {curl_headers} \\
    -d '{curl_payload}'"""
    else:
        return f"""curl -X {method_upper} '{url}' \\
    {curl_headers}"""
