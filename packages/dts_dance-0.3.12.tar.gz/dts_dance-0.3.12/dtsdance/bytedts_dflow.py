import collections
from enum import StrEnum
from typing import Any
from loguru import logger

from dtsdance.ddutil import make_request
from .bytecloud import ByteCloudClient
from . import ddutil


class OPERATE_TYPE(StrEnum):
    RESTART = "dflow.restart"
    REBALANCE = "dflow.balancing"


class TaskNotFound(Exception):
    pass


class DFlowNotFound(Exception):
    pass


class DFlowClient:
    """
    ByteDTS DFlow 新一代数据同步、数据订阅平台 API 客户端
    """

    def __init__(self, bytecloud_client: ByteCloudClient) -> None:
        self.bytecloud_client = bytecloud_client

    def _call_api(self, site: str, action: str, payload: dict, vregion: str | None = None) -> dict:
        """内部方法：调用 ByteDTS API"""
        site_info = self.bytecloud_client.get_site_config(site)
        url = f"{site_info.endpoint}/api/v1/bytedts/api/bytedts/v3/{action}"
        headers = self.bytecloud_client.build_request_headers(site, vregion)
        curl_cmd = ddutil.output_curl(url, headers, payload)
        logger.debug(f"Equivalent curl:\n{curl_cmd}")

        return make_request("POST", url, headers, payload)

    def get_task_info_raw(self, site: str, task_id: str, vregion: str | None = None) -> dict:
        """
        获取 DFlow 任务信息（原始完整数据）

        Args:
            site: 站点名称
            task_id: DFlow 任务 ID
            vregion: 虚拟区域（可选）

        Returns:
            dict: 原始任务数据
        """
        response_data = self._call_api(site, "DescribeTaskInfo", {"id": int(task_id)}, vregion)
        if response_data.get("code", 999) != 0:
            message = response_data.get("message")
            if message == "task not exists":
                raise TaskNotFound(f"获取 DFlow 任务信息失败，站点: {site}, 任务 ID: {task_id} 不存在")

            raise RuntimeError(f"DescribeTaskInfo {message}")

        return response_data.get("data", {}).get("task", {})

    def get_task_info(self, site: str, task_id: str, vregion: str | None = None) -> dict[str, Any]:
        """
        获取 DFlow 任务信息

        Args:
            site: 站点名称
            task_id: DFlow 任务 ID

        Returns:
            dict[str, Any]: DFlow 任务信息，包含 create_time 等字段
        """
        task = self.get_task_info_raw(site, task_id, vregion)
        try:
            # 提取核心信息
            return {
                "task_id": task.get("id", ""),
                "status": task.get("status", ""),
                "desc": task.get("desc", ""),
                "tree_id": task.get("tree_id", 0),
                "administrators": task.get("administrators", []),
                "create_time": task.get("create_time", 0),
                "dflow_count": task.get("dflow_count", 0),
            }
        except (KeyError, AttributeError) as e:
            raise Exception(f"无法从响应中提取 DFlow 任务信息数据: {str(e)}")

    def get_dflow_info(self, site: str, dflow_id: str, vregion: str | None = None) -> dict[str, Any]:
        """
        获取 DFlow 进程信息

        Args:
            site: 站点名称
            dflow_id: DFlow 进程 ID

        Returns:
            dict[str, Any]: DFlow 进程信息，包含 create_time 等字段
        """
        response_data = self._call_api(site, "DescribeDFlowDetail", {"dflow_id": int(dflow_id)}, vregion)

        message = response_data.get("message", "")
        logger.debug(f"get_dflow_info {site} {dflow_id}, message: {message}")

        if "dflow not found" in message:
            raise DFlowNotFound(f"获取 DFlow 进程信息失败，站点: {site}, 进程 ID: {dflow_id} 不存在")

        try:
            dflow = response_data.get("data", {}).get("dflow", {})
            # 提取核心信息
            return {
                "dflow_id": dflow.get("id", ""),
                "task_id": dflow.get("task_id", ""),
                "app": dflow.get("app", ""),
                "schedule_plan_name": dflow.get("schedule_plan_name", ""),
                "running_state.healthy_status": dflow.get("running_state", {}).get("healthy_status", ""),
            }
        except (KeyError, AttributeError) as e:
            raise Exception(f"无法从响应中提取 DFlow 进程信息数据: {str(e)}")

    def _describe_dflow_list(self, site: str, task_id: str, ctrl_env: str, offset: int, limit: int, vregion: str | None) -> dict:
        """内部方法：调用 DescribeDFlowList API 返回原始响应"""
        payload = {"task_id": [int(task_id)], "ctrl_env": ctrl_env, "offset": offset, "limit": limit}
        return self._call_api(site, "DescribeDFlowList", payload, vregion)

    def count_dflow_list(self, site: str, task_id: str, ctrl_env: str, vregion: str | None = None) -> int:
        """
        获取 DFlow 任务信息列表数量

        Args:
            site: 站点名称
            task_id: DFlow 任务 ID
            ctrl_env: 控制环境
            vregion: 虚拟区域（可选）

        Returns:
            int: DFlow 任务数量
        """
        try:
            response_data = self._describe_dflow_list(site, task_id, ctrl_env, offset=0, limit=10, vregion=vregion)
            return response_data.get("data", {}).get("total", 0)
        except Exception as e:
            raise Exception(f"count_dflow_list occur exception: {str(e)}")

    def list_dflows(self, site: str, task_id: str, ctrl_env: str, limit: int = 100, vregion: str | None = None) -> list[dict]:
        """
        获取 DFlow 列表（原始数据）

        Args:
            site: 站点名称
            task_id: DFlow 任务 ID
            ctrl_env: 控制环境
            limit: 返回数量限制，默认 100
            vregion: 虚拟区域（可选）

        Returns:
            list[dict]: DFlow 列表（原始数据）
        """
        response_data = self._describe_dflow_list(site, task_id, ctrl_env, offset=0, limit=limit, vregion=vregion)
        if response_data.get("code", 999) != 0:
            message = response_data.get("message")
            raise RuntimeError(f"DescribeDFlowList {message}")

        return (response_data.get("data") or {}).get("items") or []

    def generate_task_url(self, site: str, task_id: str, task_scene: int = 3) -> str | None:
        """
        获取 DFlow 任务详情页面的 URL

        Args:
            site: 站点名称
            task_id: DFlow 任务 ID
            task_scene: DFlow 任务场景。3 代表数据同步场景，1 为订阅。

        Returns:
            str | None: DFlow 任务详情页面的 URL 或 None 如果任务场景无效
        """
        if task_scene not in (1, 3):
            return None

        site_info = self.bytecloud_client.get_site_config(site)
        return f"{site_info.endpoint}/bytedts/datasync/detail/{task_id}" if task_scene == 3 else f"{site_info.endpoint}/bytedts/dbus/detail/{task_id}"

    def init_resources(self, site: str, vregion: str, ctrl_env: str) -> bool:
        """
        初始化 CTRL 环境资源

        Args:
            site: 站点名称
            vregion: 虚拟区域
            ctrl_env: 控制环境

        Returns:
            bool: CTRL 环境资源初始化结果
        """
        response_data = self._call_api(site, "InitSystemResource", {"ctrl_env": ctrl_env}, vregion)
        message = response_data.get("message")
        logger.info(f"init_resources {site} {ctrl_env}, message: {message}")
        return message == "ok"

    def list_resources(self, site: str, vregion: str, ctrl_env: str) -> list[str]:
        """
        列举 CTRL 环境资源列表，连同 agent 列表

        Args:
            site: 站点名称
            vregion: 虚拟区域
            ctrl_env: 控制环境
        Returns:
            list[str]: CTRL 环境资源列表
        """
        payload = {"offset": 0, "limit": 10, "ctrl_env": ctrl_env}
        response_data = self._call_api(site, "DescribeResources", payload, vregion)

        try:
            data = response_data.get("data", {})
            items = data.get("items", [])
            return [item["name"] for item in items]
        except (KeyError, AttributeError, Exception) as e:
            raise Exception(f"无法从响应中提取 CTRL 环境资源列表数据: {str(e)}")

    def get_all_ctrl_envs(self, site: str) -> dict[str, list[str]]:
        """获取所有可用的控制环境列表，返回以domain为键，ctrl_env列表为值的字典"""
        resp_json = self._call_api(site, "DescribeRegions", {})
        if resp_json["code"] != 0:
            raise Exception(resp_json["message"])

        # logger.debug(f"Fetched regions info: {json.dumps(resp_json['data'], ensure_ascii=False, indent=2)}")

        # 提取所有控制环境列表，格式为以domain为键，ctrl_env列表为值的字典
        all_ctrl_envs_by_domain = collections.defaultdict(list[str])

        # 从ops_platform_region中提取ctrl_env_list
        if "bytedts_env" in resp_json["data"]:
            for bytedts_env in resp_json["data"]["bytedts_env"]:
                if "ctrl_env_list" in bytedts_env and "domain" in bytedts_env:
                    env = bytedts_env["env"]
                    region = bytedts_env["include_region"][0] if bytedts_env["include_region"] else "Unknown"
                    env_region_key = env + "|" + region
                    for ctrl_env_item in bytedts_env["ctrl_env_list"]:
                        if "ctrl_env" in ctrl_env_item:
                            ctrl_env = ctrl_env_item["ctrl_env"]
                            # 将ctrl_env添加到domain对应的列表中
                            all_ctrl_envs_by_domain[env_region_key].append(ctrl_env)

        return dict(all_ctrl_envs_by_domain)

    def modify_task(self, site: str, task_id: int, payload: dict, vregion: str | None = None) -> bool:
        """
        修改 DFlow 任务

        Args:
            site: 站点名称
            task_id: DFlow 任务 ID
            payload: 修改任务的请求数据
        Returns:
            bool: 修改任务是否成功
        """
        payload["task_id"] = task_id
        response_data = self._call_api(site, "ModifyTask", payload, vregion)
        message = response_data.get("message")
        logger.debug(f"modify_task site: {site}, vregion: {vregion}, payload: {payload}, message: {message}")
        return message == "ok"

    def operate_task(self, site: str, task_id: int, payload: dict, vregion: str | None = None) -> bool:
        """
        操作 DFlow 任务

        Args:
            site: 站点名称
            task_id: DFlow 任务 ID
            payload: 操作任务的请求数据
        Returns:
            bool: 操作任务是否成功
        """
        payload["task_id"] = task_id
        response_data = self._call_api(site, "OperateTask", payload, vregion)
        message = response_data.get("message")
        logger.debug(f"operate_task site: {site}, vregion: {vregion}, payload: {payload}, message: {message}")
        return message == "ok"

    def operate_dflow(self, site: str, dflow_id: str, ctrl_env: str, operate_type: OPERATE_TYPE, vregion: str | None = None) -> bool:
        payload = {"dflow_id": dflow_id, "operate_type": operate_type, "ctrl_env": ctrl_env}
        try:
            response_data = self._call_api(site, "OperateDFlow", payload, vregion)
            if response_data.get("code") != 0:
                logger.warning(f"operate_dflow failed, site: {site}, dflow_id: {dflow_id}, error: {response_data.get('message', 'Unknown error')}")
                return False

            logger.info(f"operate_dflow success, site: {site}, dflow_id: {dflow_id}, operate_type: {operate_type}")
            return response_data.get("data", {}).get("success", False)
        except Exception as e:
            logger.error(f"operate_dflow occur error, site: {site}, dflow_id: {dflow_id}, error: {e}")
            raise
