import typer

from synapse_cli import __version__
from synapse_cli.commands import login, logout, service, status, sync


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(f"synapse {__version__}")
        raise typer.Exit()


app = typer.Typer(name="synapse", help="Synapse — Universal Memory Layer CLI")


@app.callback()
def _root(
    version: bool = typer.Option(
        False, "--version", "-V",
        callback=_version_callback,
        is_eager=True,
        help="Print version and exit.",
    ),
) -> None:
    """Synapse — Universal Memory Layer CLI."""
    return


app.command()(login.login)
app.command()(logout.logout)
app.command()(sync.sync)
app.command(name="status")(status.status_cmd)
app.command(name="install-service")(service.install_service)
app.command(name="uninstall-service")(service.uninstall_service)

if __name__ == "__main__":
    app()
