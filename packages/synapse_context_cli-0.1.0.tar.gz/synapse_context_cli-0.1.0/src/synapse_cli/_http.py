"""Shared HTTP defaults — version handshake, timeouts.

All Synapse-API calls flow through `default_headers()` so the server can
log which CLI version is talking to it. Useful when deciding whether a
breaking server-side change can be made (we can see the lowest CLI
version still in active use).
"""
from __future__ import annotations

from synapse_cli import __version__


def default_headers(*, token: str | None = None) -> dict[str, str]:
    """Headers attached to every CLI → Synapse API request."""
    headers: dict[str, str] = {
        "User-Agent": f"synapse-cli/{__version__}",
        "X-Synapse-CLI-Version": __version__,
    }
    if token is not None:
        headers["Authorization"] = f"Bearer {token}"
    return headers
