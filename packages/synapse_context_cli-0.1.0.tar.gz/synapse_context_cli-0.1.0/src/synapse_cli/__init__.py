"""Synapse CLI — Universal Memory Layer for AI coding tools."""
from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("synapse-context-cli")
except PackageNotFoundError:
    # Editable install before pyproject.toml metadata is registered.
    __version__ = "0.0.0+local"

__all__ = ["__version__"]
