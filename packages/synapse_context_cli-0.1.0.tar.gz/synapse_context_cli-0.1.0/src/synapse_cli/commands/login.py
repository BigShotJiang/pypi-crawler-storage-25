"""synapse login — GitHub device flow authentication.

Flow:
  1. POST github.com/login/device/code → get user_code + device_code
  2. Display user_code and verification URL to user
  3. Poll github.com/login/oauth/access_token until authorized or denied
  4. Exchange GitHub access token for Synapse JWT via POST /auth/github
  5. Save credentials to ~/.synapse/credentials.json
"""
from __future__ import annotations

import asyncio
from dataclasses import dataclass

import httpx
import typer
from rich.console import Console
from rich.panel import Panel

from synapse_cli._http import default_headers
from synapse_cli.config import DEFAULT_API_ENDPOINT, Credentials, save_credentials

console = Console()

# Synapse GitHub App client ID — public, OK to ship in the binary.
# Users can override via SYNAPSE_GITHUB_CLIENT_ID env var (e.g. to test
# against a fork's GitHub App).
_DEFAULT_CLIENT_ID = "Iv23livKlFAcLu6lgATh"
_GITHUB_DEVICE_URL = "https://github.com/login/device/code"
_GITHUB_TOKEN_URL = "https://github.com/login/oauth/access_token"
_DEFAULT_API_ENDPOINT = DEFAULT_API_ENDPOINT


@dataclass
class DeviceCodeResponse:
    device_code: str
    user_code: str
    verification_uri: str
    expires_in: int
    interval: int


@dataclass
class PollResult:
    access_token: str | None
    error: str | None


async def request_device_code(client_id: str) -> DeviceCodeResponse:
    """Request a device code from GitHub.

    GitHub returns 404 when the client_id is not registered or device flow
    is not enabled for that OAuth App — translate that into actionable text
    rather than letting the raw httpx error bubble up.
    """
    async with httpx.AsyncClient(timeout=15) as client:
        response = await client.post(
            _GITHUB_DEVICE_URL,
            data={"client_id": client_id, "scope": "read:org"},
            headers={"Accept": "application/json"},
        )

    if response.status_code == 404:
        raise RuntimeError(
            f"GitHub does not recognise client_id={client_id!r}. The Synapse "
            f"OAuth App is not yet registered for device flow.\n\n"
            f"Workarounds:\n"
            f"  • Set SYNAPSE_GITHUB_CLIENT_ID to a registered OAuth App's "
            f"client ID (must have 'Device flow' enabled in its settings).\n"
            f"  • Or use a token from the dashboard:\n"
            f"      export SYNAPSE_TOKEN=syn_live_..."
        )
    response.raise_for_status()

    data = response.json()
    return DeviceCodeResponse(
        device_code=data["device_code"],
        user_code=data["user_code"],
        verification_uri=data["verification_uri"],
        expires_in=data["expires_in"],
        interval=data.get("interval", 5),
    )


async def poll_for_token(
    client_id: str,
    device_code: str,
    interval: int,
    max_attempts: int = 60,
) -> PollResult:
    """Poll GitHub until the user authorizes or the flow expires/fails."""
    for _ in range(max_attempts):
        await asyncio.sleep(interval)

        async with httpx.AsyncClient(timeout=15) as client:
            response = await client.post(
                _GITHUB_TOKEN_URL,
                json={
                    "client_id": client_id,
                    "device_code": device_code,
                    "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
                },
                headers={"Accept": "application/json"},
            )
            response.raise_for_status()

        data = response.json()

        if "access_token" in data:
            return PollResult(access_token=data["access_token"], error=None)

        error = data.get("error")
        if error == "authorization_pending":
            continue
        if error == "slow_down":
            interval += 5
            continue
        # access_denied, expired_token, or unknown error
        return PollResult(access_token=None, error=error)

    return PollResult(access_token=None, error="timeout")


async def exchange_for_synapse_jwt(
    github_token: str,
    api_endpoint: str,
) -> tuple[str, str]:
    """Exchange a GitHub access token for a Synapse JWT + org_id."""
    async with httpx.AsyncClient(timeout=15) as client:
        response = await client.post(
            f"{api_endpoint}/auth/github",
            json={"github_token": github_token},
            headers=default_headers(),
        )
        response.raise_for_status()

    data = response.json()
    return data["token"], data["org_id"]


def login(
    api_endpoint: str = typer.Option(
        _DEFAULT_API_ENDPOINT, "--api", help="Synapse API endpoint"
    ),
    client_id: str = typer.Option(
        _DEFAULT_CLIENT_ID, "--client-id", hidden=True
    ),
) -> None:
    """Authenticate with Synapse via GitHub device flow.

    Walks GitHub's device-authorization flow and exchanges the resulting
    access token for a Synapse `syn_live_*` API token, saving it to
    `~/.synapse/credentials.json`.

    For headless / CI environments, set `SYNAPSE_TOKEN` directly instead.
    """
    import os
    client_id = os.environ.get("SYNAPSE_GITHUB_CLIENT_ID", client_id)
    asyncio.run(_login_flow(api_endpoint=api_endpoint, client_id=client_id))


async def _login_flow(api_endpoint: str, client_id: str) -> None:
    """Run the full device flow login sequence."""
    console.print("[bold]Synapse Login[/bold] — GitHub device flow\n")

    # Step 1: get device code
    try:
        device = await request_device_code(client_id=client_id)
    except RuntimeError as exc:
        # Friendly errors from request_device_code (e.g. unregistered client_id)
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=1) from exc
    except httpx.HTTPError as exc:
        console.print(f"[red]Failed to contact GitHub:[/red] {exc}")
        raise typer.Exit(code=1) from exc

    # Step 2: show user the code
    console.print(
        Panel(
            f"[bold yellow]{device.user_code}[/bold yellow]",
            title="Your activation code",
            subtitle=f"Visit: [link]{device.verification_uri}[/link]",
            expand=False,
        )
    )
    console.print(
        f"\nOpen [bold]{device.verification_uri}[/bold] and enter the code above.\n"
        f"Waiting for authorization",
        end="",
    )

    # Step 3: poll
    try:
        poll = await poll_for_token(
            client_id=client_id,
            device_code=device.device_code,
            interval=device.interval,
        )
    except httpx.HTTPError as exc:
        console.print(f"\n[red]Polling failed:[/red] {exc}")
        raise typer.Exit(code=1) from exc

    if poll.access_token is None:
        console.print(f"\n[red]Authorization failed:[/red] {poll.error}")
        raise typer.Exit(code=1)

    console.print(" [green]✓[/green]")

    # Step 4: exchange for Synapse JWT
    try:
        synapse_token, org_id = await exchange_for_synapse_jwt(
            github_token=poll.access_token,
            api_endpoint=api_endpoint,
        )
    except httpx.HTTPError as exc:
        console.print(f"[red]Failed to get Synapse token:[/red] {exc}")
        raise typer.Exit(code=1) from exc

    # Step 5: save
    save_credentials(Credentials(
        token=synapse_token,
        org_id=org_id,
        api_endpoint=api_endpoint,
    ))

    console.print(
        f"\n[bold green]✓ Logged in![/bold green] "
        f"Org: [bold]{org_id}[/bold]"
    )
