"""synapse sync --watch — auto-sync uncommitted changes on save.

Uses watchdog to monitor the repo, debounces rapid saves into a single
sync run after a quiet period, and re-runs the diff-driven sync from
sync.py whenever the dust settles.
"""
from __future__ import annotations

import subprocess
import threading
import time
from functools import lru_cache
from pathlib import Path
from typing import Callable

from watchdog.events import FileSystemEvent, FileSystemEventHandler
from watchdog.observers import Observer

# Directory names whose contents are never source code we want to sync.
# Matched against any path component, so nested copies are also skipped.
_IGNORED_DIRS: frozenset[str] = frozenset({
    ".git", ".hg", ".svn",
    "node_modules", "bower_components",
    "__pycache__", ".mypy_cache", ".pytest_cache", ".ruff_cache",
    ".venv", "venv", "env",
    ".next", "dist", "build", "target", "out",
    ".idea", ".vscode",
    ".tox", ".eggs",
})


def _should_ignore(path: str, repo_path: str) -> bool:
    """Return True if `path` lies inside any ignored directory under `repo_path`.

    Only directory components are checked — root-level dotfiles (.env.example,
    .pre-commit-config.yaml, etc.) are kept since they're real source.
    """
    try:
        rel = Path(path).resolve().relative_to(Path(repo_path).resolve())
    except ValueError:
        return True  # outside the repo
    # Check parent components only — the file name itself is not a directory
    for part in rel.parts[:-1]:
        if part in _IGNORED_DIRS:
            return True
    return False


class _GitignoreCache:
    """Cached `git check-ignore --quiet` lookups.

    `git check-ignore` exits 0 if the path IS ignored, 1 if not. We cache
    results so a watcher firing on the same `dist/out.js` 50 times doesn't
    shell out 50 times. Fails open (returns False) if git is unavailable.
    """

    def __init__(self, repo_path: str) -> None:
        self._repo_path = repo_path
        # Bounded LRU so a long-running watcher in a huge repo doesn't grow
        # the cache without bound.
        self._lookup = lru_cache(maxsize=1024)(self._uncached_is_ignored)

    def _uncached_is_ignored(self, path: str) -> bool:
        try:
            result = subprocess.run(
                ["git", "check-ignore", "--quiet", path],
                cwd=self._repo_path,
                capture_output=True,
                check=False,
            )
        except (FileNotFoundError, OSError):
            # git missing or path unreachable — fail open
            return False
        return result.returncode == 0

    def is_ignored(self, path: str) -> bool:
        return self._lookup(path)


class _DebouncedSync:
    """Coalesces rapid schedule() calls into a single fire after a quiet period.

    Uses a single rolling timer; each schedule() cancels the prior timer and
    starts a new one. Thread-safe under concurrent schedule() bursts.
    """

    def __init__(
        self,
        *,
        debounce_s: float,
        sync_callback: Callable[[], None],
    ) -> None:
        self._debounce_s = debounce_s
        self._sync_callback = sync_callback
        self._timer: threading.Timer | None = None
        self._lock = threading.Lock()

    def schedule(self) -> None:
        with self._lock:
            if self._timer is not None:
                self._timer.cancel()
            timer = threading.Timer(self._debounce_s, self._sync_callback)
            timer.daemon = True
            self._timer = timer
            timer.start()

    def cancel(self) -> None:
        with self._lock:
            if self._timer is not None:
                self._timer.cancel()
                self._timer = None


class _RepoEventHandler(FileSystemEventHandler):
    """Forwards meaningful filesystem events into the debouncer.

    Two-stage filter:
      1. Cheap `_should_ignore` check against `_IGNORED_DIRS` — handles
         `.git/`, `node_modules/`, build dirs without shelling out.
      2. `git check-ignore` lookup (cached) for everything else, so the
         user's actual `.gitignore` rules are honoured.
    """

    def __init__(
        self,
        debouncer: _DebouncedSync,
        repo_path: str,
        gitignore: _GitignoreCache | None = None,
    ) -> None:
        self._debouncer = debouncer
        self._repo_path = repo_path
        self._gitignore = gitignore

    def on_any_event(self, event: FileSystemEvent) -> None:
        if event.is_directory:
            return
        src = event.src_path
        if isinstance(src, bytes):
            src = src.decode("utf-8", errors="replace")
        # L1: cheap directory-name check
        if _should_ignore(src, self._repo_path):
            return
        # L2: respect the user's actual .gitignore
        if self._gitignore is not None and self._gitignore.is_ignored(src):
            return
        self._debouncer.schedule()


def run_watch(
    *,
    repo_path: str,
    debounce_s: float,
    sync_callback: Callable[[], None],
) -> None:
    """Run an initial sync, then watch the repo and debounce-fire on changes.

    Returns when the user sends SIGINT (Ctrl-C).
    """
    debouncer = _DebouncedSync(debounce_s=debounce_s, sync_callback=sync_callback)
    gitignore = _GitignoreCache(repo_path=repo_path)
    handler = _RepoEventHandler(
        debouncer=debouncer, repo_path=repo_path, gitignore=gitignore
    )
    observer = Observer()
    observer.schedule(handler, repo_path, recursive=True)

    # Initial sync — pick up the current diff before any new events arrive
    sync_callback()

    observer.start()
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        pass
    finally:
        debouncer.cancel()
        observer.stop()
        observer.join()
