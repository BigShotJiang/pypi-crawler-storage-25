"""synapse sync — push uncommitted diffs to WIP cache.

Detects changed files via GitPython, secret-scans each one,
then uploads clean files to the Synapse API's WIP endpoint.
"""
from __future__ import annotations

import asyncio
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

import httpx
import typer
from git import Repo
from rich.console import Console

from synapse_cli._http import default_headers
from synapse_cli.config import Credentials, load_credentials
from synapse_sdk.scanner import scan_for_secrets


@dataclass
class StagedScanResult:
    """One file's pre-commit scan verdict."""
    file_path: str
    is_rejected: bool
    secret_type: str | None = None


# Matches "owner/repo" embedded anywhere in a git remote URL. Strict enough
# that "https://example.com/x" won't match (no second slash before any
# trailing path), forgiving enough that ssh + https + bare paths all work.
_REMOTE_PATTERN = re.compile(r"[:/]([\w.-]+)/([\w.-]+?)(?:\.git)?/?$")


def _full_name_from_remote(remote: str) -> str:
    """Convert a git remote URL to GitHub `owner/repo` form.

    Handles:
      https://github.com/acme/api.git   → acme/api
      https://github.com/acme/api        → acme/api
      git@github.com:acme/api.git        → acme/api
      git@github.com:acme/api            → acme/api

    Falls back to the input unchanged if no `owner/repo` pattern matches.
    """
    match = _REMOTE_PATTERN.search(remote.rstrip("/"))
    if match is None:
        return remote
    return f"{match.group(1)}/{match.group(2)}"

console = Console()


# ---------------------------------------------------------------------------
# Pure logic helpers (testable without CLI)
# ---------------------------------------------------------------------------

def get_changed_files(repo_path: str) -> list[str]:
    """Return unique list of added/modified file paths in the working tree.

    Excludes deleted files — they don't need to be re-indexed.
    Combines staged, unstaged, and untracked files, deduplicating.
    Handles the first-commit case (no HEAD yet) by treating every staged
    entry as newly added.
    """
    repo = Repo(repo_path)
    seen: set[str] = set()
    result: list[str] = []

    # Staged changes (index vs HEAD) — skip the diff if there's no HEAD yet
    if repo.head.is_valid():
        for diff in repo.index.diff("HEAD"):
            if diff.a_path is None or diff.change_type == "D":
                continue
            if diff.a_path not in seen:
                seen.add(diff.a_path)
                result.append(diff.a_path)
    else:
        for entry in repo.index.entries:
            path = str(entry[0])
            if path not in seen:
                seen.add(path)
                result.append(path)

    # Unstaged changes (working tree vs index)
    for diff in repo.index.diff(None):
        if diff.a_path is None or diff.change_type == "D":
            continue
        if diff.a_path not in seen:
            seen.add(diff.a_path)
            result.append(diff.a_path)

    # Untracked files
    for path in repo.untracked_files:
        if path not in seen:
            seen.add(path)
            result.append(path)

    return result


def scan_staged_files(repo_path: str) -> list[StagedScanResult]:
    """Scan staged (index vs HEAD) files for secrets — used by `--pre-commit`.

    Skips deletes (no content to scan). Reads working-tree contents to match
    what will actually be committed. Handles the first-commit case (no HEAD
    yet) by treating every index entry as newly added.
    """
    repo = Repo(repo_path)
    results: list[StagedScanResult] = []

    if repo.head.is_valid():
        staged_paths = [
            d.a_path for d in repo.index.diff("HEAD")
            if d.a_path is not None and d.change_type != "D"
        ]
    else:
        # No commits yet — every index entry is "added"
        staged_paths = [str(entry[0]) for entry in repo.index.entries]

    for path in staged_paths:
        full_path = Path(repo_path) / path
        if not full_path.exists():
            continue
        content = full_path.read_text(errors="replace")
        scan = scan_for_secrets(content, file_path=path)
        results.append(StagedScanResult(
            file_path=path,
            is_rejected=bool(scan.is_rejected),
            secret_type=scan.secret_type,
        ))
    return results


def walk_working_tree(repo_path: str) -> list[str]:
    """Return every tracked + untracked-not-gitignored file in the working tree.

    Defers to git's own `ls-files --cached --others --exclude-standard`, which
    is git's authoritative answer to "what's in scope" — `.gitignore` rules
    are honoured for free.
    """
    repo = Repo(repo_path)
    raw = repo.git.ls_files("--cached", "--others", "--exclude-standard")
    return [line for line in raw.splitlines() if line.strip()]


async def upload_wip_file(
    file_path: str,
    content: str,
    creds: Credentials,
    repo: str,
    branch: str,
) -> bool:
    """Secret-scan then upload a single file to the WIP API endpoint.

    Returns True if uploaded, False if skipped (empty or secret found).
    """
    if not content.strip():
        return False

    scan_result = scan_for_secrets(content, file_path=file_path)
    if scan_result.is_rejected:
        console.print(
            f"[red]⚠ Secret detected[/red] in [bold]{file_path}[/bold] "
            f"({scan_result.secret_type}) — skipped"
        )
        return False

    async with httpx.AsyncClient(timeout=30) as client:
        response = await client.post(
            f"{creds.api_endpoint}/wip/sync",
            json={
                "file_path": file_path,
                "content": content,
                "repo": repo,
                "branch": branch,
                "org_id": creds.org_id,
            },
            headers=default_headers(token=creds.token),
        )
        response.raise_for_status()

    return True


# ---------------------------------------------------------------------------
# CLI command
# ---------------------------------------------------------------------------

SyncMode = Literal["diff", "full"]


async def _sync_once(
    *,
    creds: Credentials,
    repo_path: str,
    repo_remote: str,
    branch: str,
    mode: SyncMode = "diff",
    dry_run: bool = False,
    quiet: bool = False,
) -> tuple[int, int]:
    """Run a single WIP sync. Returns (synced, skipped).

    `mode="diff"` (default) syncs only uncommitted changes;
    `mode="full"` walks the entire working tree (respecting .gitignore).
    `dry_run=True` reports what would sync but doesn't upload.
    """
    try:
        if mode == "full":
            changed = walk_working_tree(repo_path)
        else:
            changed = get_changed_files(repo_path)
    except Exception as exc:
        console.print(f"[red]Git error:[/red] {exc}")
        return (0, 0)

    if not changed:
        if not quiet:
            msg = (
                "No files to sync."
                if mode == "full"
                else "No uncommitted changes to sync."
            )
            console.print(f"[green]✓[/green] {msg}")
        return (0, 0)

    if not quiet:
        scope = "(full tree)" if mode == "full" else ""
        console.print(f"[bold]Syncing {len(changed)} file(s) {scope}[/bold]")

    synced = 0
    skipped = 0
    for fp in changed:
        full_path = Path(repo_path) / fp
        if not full_path.exists():
            continue
        content = full_path.read_text(errors="replace")

        if dry_run:
            # Run the secret scan locally so the user sees the same skip
            # decisions a real sync would make, without the upload.
            if not content.strip():
                skipped += 1
                continue
            scan = scan_for_secrets(content, file_path=fp)
            if scan.is_rejected:
                skipped += 1
                console.print(
                    f"  [red]⚠[/red] {fp} [dim](would skip — secret: "
                    f"{scan.secret_type})[/dim]"
                )
            else:
                synced += 1
                console.print(f"  [yellow]→[/yellow] {fp} [dim](would sync)[/dim]")
            continue

        ok = await upload_wip_file(
            file_path=fp,
            content=content,
            creds=creds,
            repo=repo_remote,
            branch=branch,
        )
        if ok:
            synced += 1
            console.print(f"  [green]✓[/green] {fp}")
        else:
            skipped += 1
            if not quiet:
                console.print(f"  [dim]–[/dim] {fp} [dim](skipped)[/dim]")
    return (synced, skipped)


def sync(
    full: bool = typer.Option(
        False, "--full", help="Sync entire working tree, not just diff"
    ),
    watch: bool = typer.Option(
        False, "--watch", help="Watch mode: auto-sync on file save"
    ),
    debounce: float = typer.Option(
        1.5, "--debounce", help="Watch mode: seconds of quiet before sync fires"
    ),
    dry_run: bool = typer.Option(
        False, "--dry-run", help="Show what would sync without uploading"
    ),
    pre_commit: bool = typer.Option(
        False, "--pre-commit",
        help="Scan staged files for secrets; exit non-zero on findings (no upload)",
    ),
) -> None:
    """Push uncommitted diffs to WIP cache for AI context."""
    if pre_commit:
        results = scan_staged_files(".")
        rejected = [r for r in results if r.is_rejected]
        if rejected:
            for r in rejected:
                console.print(
                    f"[red]✗[/red] {r.file_path} [dim](secret: {r.secret_type})[/dim]"
                )
            console.print(
                f"\n[red bold]Pre-commit failed:[/red bold] "
                f"{len(rejected)} file(s) contain secrets."
            )
            raise typer.Exit(code=1)
        console.print(
            f"[green]✓[/green] Pre-commit clean — "
            f"{len(results)} staged file(s) scanned, no secrets."
        )
        return

    creds = load_credentials()
    if creds is None:
        console.print("[red]Not logged in.[/red] Run [bold]synapse login[/bold] first.")
        raise typer.Exit(code=1)

    repo_path = "."
    repo_obj = Repo(repo_path)
    repo_name = next(iter(repo_obj.remotes), None)
    repo_remote = (
        _full_name_from_remote(repo_name.url) if repo_name else "unknown/repo"
    )
    branch = repo_obj.active_branch.name

    mode: SyncMode = "full" if full else "diff"

    if watch:
        from synapse_cli.commands.watch import run_watch

        def _trigger_sync() -> None:
            # Watch mode always uses diff scope — full re-walks would be
            # absurdly expensive on every save. The initial full pass (if any)
            # should be done as a one-shot before starting --watch.
            synced, skipped = asyncio.run(_sync_once(
                creds=creds,
                repo_path=repo_path,
                repo_remote=repo_remote,
                branch=branch,
                mode="diff",
                quiet=True,
            ))
            if synced or skipped:
                console.print(
                    f"  [dim]→ {synced} synced, {skipped} skipped[/dim]"
                )

        console.print(
            f"[bold]Watching[/bold] {Path(repo_path).resolve()} "
            f"(debounce {debounce}s) — Ctrl-C to stop."
        )
        run_watch(
            repo_path=repo_path,
            debounce_s=debounce,
            sync_callback=_trigger_sync,
        )
        console.print("[bold green]Stopped.[/bold green]")
        return

    synced, skipped = asyncio.run(_sync_once(
        creds=creds,
        repo_path=repo_path,
        repo_remote=repo_remote,
        branch=branch,
        mode=mode,
        dry_run=dry_run,
    ))
    if synced == 0 and skipped == 0:
        return  # already printed "no changes"
    console.print(
        f"\n[bold green]Done.[/bold green] "
        f"{synced} synced, {skipped} skipped."
    )
