"""synapse install-service / uninstall-service / service-status — manage
the background watcher as a launchd / systemd user service.

macOS  → ~/Library/LaunchAgents/<label>.plist  + launchctl load/unload
Linux  → ~/.config/systemd/user/<label>.service + systemctl --user enable/disable
Windows → unsupported (errors out cleanly)
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path

import typer
from rich.console import Console

from synapse_cli.config import DEFAULT_API_ENDPOINT, load_credentials

console = Console()


class UnsupportedPlatform(RuntimeError):
    """Raised when install-service is invoked on Windows or unknown OS."""


_DEFAULT_LABEL = "dev.synapse.watch"


# ---------------------------------------------------------------------------
# Templates
# ---------------------------------------------------------------------------

def _render_launchd_plist(
    *,
    label: str,
    repo_path: str,
    synapse_token: str,
    api_endpoint: str,
    synapse_bin: str,
) -> str:
    """Render a macOS launchd plist that runs `synapse sync --watch` in repo_path."""
    return f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>{label}</string>
  <key>WorkingDirectory</key>
  <string>{repo_path}</string>
  <key>ProgramArguments</key>
  <array>
    <string>{synapse_bin}</string>
    <string>sync</string>
    <string>--watch</string>
  </array>
  <key>EnvironmentVariables</key>
  <dict>
    <key>SYNAPSE_TOKEN</key>
    <string>{synapse_token}</string>
    <key>SYNAPSE_API_ENDPOINT</key>
    <string>{api_endpoint}</string>
  </dict>
  <key>RunAtLoad</key>
  <true/>
  <key>KeepAlive</key>
  <true/>
  <key>StandardOutPath</key>
  <string>/tmp/{label}.log</string>
  <key>StandardErrorPath</key>
  <string>/tmp/{label}.err</string>
</dict>
</plist>
"""


def _render_systemd_unit(
    *,
    label: str,
    repo_path: str,
    synapse_token: str,
    api_endpoint: str,
    synapse_bin: str,
) -> str:
    """Render a systemd user unit that runs `synapse sync --watch` in repo_path."""
    return f"""[Unit]
Description=Synapse WIP watcher ({label})
After=network-online.target

[Service]
Type=simple
WorkingDirectory={repo_path}
ExecStart={synapse_bin} sync --watch
Environment=SYNAPSE_TOKEN={synapse_token}
Environment=SYNAPSE_API_ENDPOINT={api_endpoint}
Restart=always
RestartSec=5

[Install]
WantedBy=default.target
"""


# ---------------------------------------------------------------------------
# Install / uninstall implementations (testable, no real launchctl on tests)
# ---------------------------------------------------------------------------

def _default_target_dir() -> Path:
    if sys.platform == "darwin":
        return Path.home() / "Library" / "LaunchAgents"
    if sys.platform.startswith("linux"):
        return Path.home() / ".config" / "systemd" / "user"
    raise UnsupportedPlatform(
        f"synapse install-service does not support {sys.platform!r}"
    )


def _install_service_impl(
    *,
    label: str,
    repo_path: str,
    synapse_token: str,
    api_endpoint: str,
    synapse_bin: str,
    target_dir: Path,
) -> Path:
    """Render and write the unit file; load/enable it via launchctl/systemctl."""
    target_dir.mkdir(parents=True, exist_ok=True)

    if sys.platform == "darwin":
        plist = _render_launchd_plist(
            label=label,
            repo_path=repo_path,
            synapse_token=synapse_token,
            api_endpoint=api_endpoint,
            synapse_bin=synapse_bin,
        )
        unit_path = target_dir / f"{label}.plist"
        unit_path.write_text(plist)
        subprocess.run(
            ["launchctl", "load", "-w", str(unit_path)],
            check=False,
            capture_output=True,
        )
        return unit_path

    if sys.platform.startswith("linux"):
        unit = _render_systemd_unit(
            label=label,
            repo_path=repo_path,
            synapse_token=synapse_token,
            api_endpoint=api_endpoint,
            synapse_bin=synapse_bin,
        )
        unit_path = target_dir / f"{label}.service"
        unit_path.write_text(unit)
        subprocess.run(
            ["systemctl", "--user", "daemon-reload"], check=False, capture_output=True
        )
        subprocess.run(
            ["systemctl", "--user", "enable", "--now", f"{label}.service"],
            check=False,
            capture_output=True,
        )
        return unit_path

    raise UnsupportedPlatform(
        f"synapse install-service does not support {sys.platform!r}"
    )


def _uninstall_service_impl(*, label: str, target_dir: Path) -> None:
    """Stop the service and remove the unit file."""
    if sys.platform == "darwin":
        unit_path = target_dir / f"{label}.plist"
        subprocess.run(
            ["launchctl", "unload", str(unit_path)],
            check=False,
            capture_output=True,
        )
        if unit_path.exists():
            unit_path.unlink()
        return

    if sys.platform.startswith("linux"):
        unit_path = target_dir / f"{label}.service"
        subprocess.run(
            ["systemctl", "--user", "disable", "--now", f"{label}.service"],
            check=False,
            capture_output=True,
        )
        if unit_path.exists():
            unit_path.unlink()
        subprocess.run(
            ["systemctl", "--user", "daemon-reload"], check=False, capture_output=True
        )
        return

    raise UnsupportedPlatform(
        f"synapse uninstall-service does not support {sys.platform!r}"
    )


# ---------------------------------------------------------------------------
# CLI entrypoints
# ---------------------------------------------------------------------------

def _resolve_synapse_bin() -> str:
    """Find the absolute path to the `synapse` executable."""
    found = shutil.which("synapse")
    if found:
        return found
    # Fall back to current python's bin dir
    return str(Path(sys.executable).parent / "synapse")


def install_service(
    repo: str = typer.Option(
        ".", "--repo", help="Path to the repo to watch (default: current dir)"
    ),
    label: str = typer.Option(
        _DEFAULT_LABEL, "--label", help="Service identifier (plist Label / unit name)"
    ),
) -> None:
    """Install a background watcher as a launchd (macOS) or systemd (Linux) service."""
    creds = load_credentials()
    if creds is None or not creds.token:
        console.print(
            "[red]No credentials found.[/red] Set [bold]SYNAPSE_TOKEN[/bold] "
            "or run [bold]synapse login[/bold] before installing the service."
        )
        raise typer.Exit(code=1)

    api_endpoint = (
        os.environ.get("SYNAPSE_API_ENDPOINT")
        or creds.api_endpoint
        or DEFAULT_API_ENDPOINT
    )
    synapse_bin = _resolve_synapse_bin()
    repo_path = str(Path(repo).resolve())

    try:
        target = _default_target_dir()
    except UnsupportedPlatform as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=2) from exc

    try:
        unit_path = _install_service_impl(
            label=label,
            repo_path=repo_path,
            synapse_token=creds.token,
            api_endpoint=api_endpoint,
            synapse_bin=synapse_bin,
            target_dir=target,
        )
    except UnsupportedPlatform as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=2) from exc

    console.print(f"[green]✓[/green] Installed [bold]{label}[/bold]")
    console.print(f"  Unit file: [dim]{unit_path}[/dim]")
    console.print(f"  Watching:  [dim]{repo_path}[/dim]")


def uninstall_service(
    label: str = typer.Option(
        _DEFAULT_LABEL, "--label", help="Service identifier to remove"
    ),
) -> None:
    """Stop the watcher service and remove its unit file."""
    try:
        target = _default_target_dir()
    except UnsupportedPlatform as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=2) from exc

    try:
        _uninstall_service_impl(label=label, target_dir=target)
    except UnsupportedPlatform as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(code=2) from exc

    console.print(f"[green]✓[/green] Uninstalled [bold]{label}[/bold]")
