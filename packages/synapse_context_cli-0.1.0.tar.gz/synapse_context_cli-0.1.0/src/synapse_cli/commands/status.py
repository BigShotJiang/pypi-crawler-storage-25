"""synapse status — show current connection and credential state."""
from __future__ import annotations

import asyncio
from dataclasses import dataclass

import httpx
import typer
from rich.console import Console
from rich.table import Table

from synapse_cli._http import default_headers
from synapse_cli.config import load_credentials

console = Console()


@dataclass
class StatusResult:
    connected: bool
    version: str | None = None
    error: str | None = None


@dataclass
class WipEntry:
    file_path: str
    ttl_seconds: int
    repo: str
    branch: str


async def fetch_api_status(api_endpoint: str, token: str) -> StatusResult:
    """Ping the Synapse API health endpoint and return connection status."""
    try:
        async with httpx.AsyncClient(timeout=5) as client:
            response = await client.get(
                f"{api_endpoint}/health",
                headers=default_headers(token=token),
            )
            response.raise_for_status()
            data = response.json()
            return StatusResult(connected=True, version=data.get("version"))
    except Exception as exc:
        return StatusResult(connected=False, error=str(exc))


async def fetch_wip_entries(api_endpoint: str, token: str) -> list[WipEntry]:
    """Fetch current WIP entries for the auth'd user from /wip/list.

    Returns an empty list on any failure so the verbose status path still
    renders the rest of the table.
    """
    try:
        async with httpx.AsyncClient(timeout=5) as client:
            response = await client.get(
                f"{api_endpoint}/wip/list",
                headers=default_headers(token=token),
            )
            response.raise_for_status()
            data = response.json()
    except Exception:
        return []

    entries = data.get("entries", [])
    return [
        WipEntry(
            file_path=str(e.get("file_path", "")),
            ttl_seconds=int(e.get("ttl_seconds", 0)),
            repo=str(e.get("repo", "")),
            branch=str(e.get("branch", "")),
        )
        for e in entries
    ]


def _format_ttl(seconds: int) -> str:
    """Render a TTL in human-friendly form: 3h 42m, 27m, 45s."""
    if seconds <= 0:
        return "expired"
    hours, rem = divmod(seconds, 3600)
    minutes, secs = divmod(rem, 60)
    if hours:
        return f"{hours}h {minutes}m"
    if minutes:
        return f"{minutes}m"
    return f"{secs}s"


def status_cmd(
    verbose: bool = typer.Option(
        False, "--verbose", "-v", help="Show live WIP entries from the server"
    ),
) -> None:
    """Show current Synapse connection and credential status."""
    creds = load_credentials()

    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("Key", style="bold")
    table.add_column("Value")

    if creds is None:
        table.add_row("Auth", "[red]Not logged in[/red] — run [bold]synapse login[/bold]")
        console.print(table)
        raise typer.Exit(code=1)

    table.add_row("Org", creds.org_id or "[dim]unknown[/dim]")
    table.add_row("API", creds.api_endpoint)
    table.add_row("Token", f"{creds.token[:12]}…" if len(creds.token) > 12 else creds.token)

    api_status = asyncio.run(fetch_api_status(creds.api_endpoint, creds.token))
    if api_status.connected:
        label = "[green]Connected[/green]"
        if api_status.version:
            label += f" (v{api_status.version})"
    else:
        label = f"[red]Unreachable[/red] — {api_status.error}"

    table.add_row("API Status", label)

    console.print(table)

    if verbose and api_status.connected:
        entries = asyncio.run(fetch_wip_entries(creds.api_endpoint, creds.token))
        if not entries:
            console.print(
                "\n[dim]No WIP entries — run [bold]synapse sync[/bold] in a repo "
                "to populate.[/dim]"
            )
            return
        wip_table = Table(title=f"\nWIP entries ({len(entries)})", show_lines=False)
        wip_table.add_column("File")
        wip_table.add_column("TTL", justify="right")
        wip_table.add_column("Repo")
        wip_table.add_column("Branch")
        for entry in sorted(entries, key=lambda e: e.file_path):
            wip_table.add_row(
                entry.file_path,
                _format_ttl(entry.ttl_seconds),
                entry.repo or "[dim]–[/dim]",
                entry.branch or "[dim]–[/dim]",
            )
        console.print(wip_table)
