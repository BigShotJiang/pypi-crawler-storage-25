"""synapse logout — clear stored credentials."""
from __future__ import annotations

import os

from rich.console import Console

from synapse_cli.config import CREDENTIALS_PATH

console = Console()


def logout() -> None:
    """Remove ~/.synapse/credentials.json and remind about SYNAPSE_TOKEN env var."""
    if CREDENTIALS_PATH.exists():
        CREDENTIALS_PATH.unlink()
        console.print("[green]✓[/green] Logged out — credentials file removed.")
    else:
        console.print("[dim]Not logged in — no credentials file to remove.[/dim]")

    env_token = os.environ.get("SYNAPSE_TOKEN", "")
    # Only nag about the env var if it looks like a real Synapse token —
    # avoids confusing users who've set it to a test/placeholder value.
    if env_token.startswith("syn_live_"):
        console.print(
            "\n[yellow]Note:[/yellow] [bold]SYNAPSE_TOKEN[/bold] is still set "
            "in your environment.\n"
            "Run [bold]unset SYNAPSE_TOKEN[/bold] (and remove it from your "
            "shell rc) to fully log out."
        )
