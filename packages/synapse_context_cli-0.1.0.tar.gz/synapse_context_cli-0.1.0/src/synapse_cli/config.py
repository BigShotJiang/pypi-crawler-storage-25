"""Credentials management for the Synapse CLI.

Supports loading from SYNAPSE_TOKEN environment variable (takes precedence)
or from ~/.synapse/credentials.json file.
"""
import json
import os
from pathlib import Path

from pydantic import BaseModel

CREDENTIALS_PATH = Path.home() / ".synapse" / "credentials.json"

DEFAULT_API_ENDPOINT = "https://synapse.abhinavaditya.com"


class Credentials(BaseModel):
    token: str
    org_id: str
    api_endpoint: str = DEFAULT_API_ENDPOINT


def load_credentials() -> Credentials | None:
    """Load credentials from SYNAPSE_TOKEN env var or ~/.synapse/credentials.json.

    Environment variable takes precedence over file-based credentials.
    Returns None if no credentials are found.
    """
    token = os.environ.get("SYNAPSE_TOKEN")
    if token:
        return Credentials(
            token=token,
            org_id="",
            api_endpoint=os.environ.get(
                "SYNAPSE_API_ENDPOINT", DEFAULT_API_ENDPOINT
            ),
        )

    if CREDENTIALS_PATH.exists():
        data = json.loads(CREDENTIALS_PATH.read_text())
        return Credentials(**data)

    return None


def save_credentials(creds: Credentials) -> None:
    """Save credentials to ~/.synapse/credentials.json.

    Creates the ~/.synapse/ directory if it does not exist.
    """
    CREDENTIALS_PATH.parent.mkdir(parents=True, exist_ok=True)
    CREDENTIALS_PATH.write_text(creds.model_dump_json())
