# Changelog

All notable changes to `synapse-cli` will be documented here.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

## [0.1.0] — 2026-05-02

First public release.

### Added

- `synapse login` — GitHub device-flow auth against the Synapse GitHub App.
- `synapse logout` — clear stored credentials, hint about `SYNAPSE_TOKEN` env var.
- `synapse sync` — diff-driven WIP push (staged + unstaged + untracked).
  - `--full` — walk the entire working tree (respecting `.gitignore`).
  - `--watch` — debounced auto-sync on file save (default 1.5s, configurable
    via `--debounce`). Honours `.gitignore` via cached `git check-ignore`.
  - `--dry-run` — list what would sync without uploading.
  - `--pre-commit` — scan staged files only, exit non-zero on secrets.
- `synapse status` — auth + `/health` ping.
  - `--verbose` / `-v` — list live WIP entries with TTL countdown.
- `synapse install-service` / `uninstall-service` — generate launchd plist
  (macOS) or systemd user unit (Linux), load/start it.
- `--version` / `-V` — print version.
- `User-Agent` and `X-Synapse-CLI-Version` headers on all outbound requests.
- Repo identity normalisation: git remote URLs are converted to `owner/repo`
  before sending so the server-side `full_name` matches.

### Configuration

- Reads `SYNAPSE_TOKEN` (preferred) and `SYNAPSE_API_ENDPOINT` from env.
- Default API endpoint: `https://synapse.abhinavaditya.com`.
- Falls back to `~/.synapse/credentials.json` when no env token is set.
