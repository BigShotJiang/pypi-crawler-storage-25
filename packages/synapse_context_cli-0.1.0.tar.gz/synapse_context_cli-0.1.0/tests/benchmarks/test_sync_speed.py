"""KPI benchmark — `synapse sync` < 2s for a 10-file diff (CLAUDE.md § 13)."""
from __future__ import annotations

import asyncio
import os
import subprocess
import time
from pathlib import Path

import pytest

from synapse_cli.commands.sync import _sync_once
from synapse_cli.config import Credentials


def _enabled() -> bool:
    return os.environ.get("SYNAPSE_INTEGRATION") == "1"


pytestmark = pytest.mark.skipif(
    not _enabled(),
    reason="benchmark requires SYNAPSE_INTEGRATION=1 + live stack",
)


KPI_THRESHOLD_S = 2.0
FILE_COUNT = 10


def test_ten_file_diff_under_two_seconds(tmp_path: Path) -> None:
    """Generate a 10-file diff, run sync, assert wall clock < 2.0s."""
    api_endpoint = os.environ.get("SYNAPSE_API_ENDPOINT", "http://localhost:8000")
    token = os.environ.get("SYNAPSE_TOKEN")
    if not token:
        pytest.skip("SYNAPSE_TOKEN required for benchmark")

    # Build a fresh git repo with 10 uncommitted files
    repo = tmp_path / "bench"
    repo.mkdir()
    subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
    subprocess.run(["git", "config", "user.email", "b@b.com"], cwd=repo, check=True)
    subprocess.run(["git", "config", "user.name", "b"], cwd=repo, check=True)
    subprocess.run(
        ["git", "remote", "add", "origin", "https://github.com/x/bench.git"],
        cwd=repo, check=True,
    )
    for i in range(FILE_COUNT):
        body = "\n".join(f"def fn_{i}_{j}(): return {j}" for j in range(50))
        (repo / f"mod_{i}.py").write_text(body)

    creds = Credentials(token=token, org_id="", api_endpoint=api_endpoint)

    start = time.perf_counter()
    asyncio.run(_sync_once(
        creds=creds,
        repo_path=str(repo),
        repo_remote="https://github.com/x/bench.git",
        branch="main",
        mode="diff",
        quiet=True,
    ))
    elapsed = time.perf_counter() - start

    print(f"\n[bench] 10-file sync: {elapsed:.3f}s (target: < {KPI_THRESHOLD_S}s)")
    assert elapsed < KPI_THRESHOLD_S, (
        f"sync took {elapsed:.3f}s, violates KPI target {KPI_THRESHOLD_S}s"
    )
