"""Shared fixtures for synapse-cli tests."""
