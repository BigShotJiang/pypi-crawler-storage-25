"""TDD tests for `synapse install-service` — WRITTEN FIRST.

Tests render the right launchd plist (mac) / systemd unit (linux) and
that install/uninstall write/remove the unit file in the target dir.
"""
from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest


class TestRenderLaunchdPlist:
    """macOS launchd plist generator."""

    def test_includes_token_and_endpoint_env(self, tmp_path: Path) -> None:
        from synapse_cli.commands.service import _render_launchd_plist

        plist = _render_launchd_plist(
            label="dev.synapse.watch",
            repo_path=str(tmp_path),
            synapse_token="syn_live_X",
            api_endpoint="https://synapse.example",
            synapse_bin="/usr/local/bin/synapse",
        )

        assert "<key>Label</key>" in plist
        assert "<string>dev.synapse.watch</string>" in plist
        assert "syn_live_X" in plist
        assert "https://synapse.example" in plist
        assert "/usr/local/bin/synapse" in plist
        assert "<key>RunAtLoad</key>" in plist
        assert "<key>KeepAlive</key>" in plist
        assert "<string>sync</string>" in plist
        assert "<string>--watch</string>" in plist

    def test_repo_path_set_as_working_directory(self, tmp_path: Path) -> None:
        from synapse_cli.commands.service import _render_launchd_plist

        plist = _render_launchd_plist(
            label="dev.synapse.watch",
            repo_path=str(tmp_path),
            synapse_token="X",
            api_endpoint="Y",
            synapse_bin="/bin/synapse",
        )

        assert "<key>WorkingDirectory</key>" in plist
        assert f"<string>{tmp_path}</string>" in plist


class TestRenderSystemdUnit:
    """Linux systemd user unit generator."""

    def test_includes_exec_start_and_environment(self, tmp_path: Path) -> None:
        from synapse_cli.commands.service import _render_systemd_unit

        unit = _render_systemd_unit(
            label="synapse-watch",
            repo_path=str(tmp_path),
            synapse_token="syn_live_Y",
            api_endpoint="https://synapse.example",
            synapse_bin="/usr/local/bin/synapse",
        )

        assert "[Service]" in unit
        assert "ExecStart=/usr/local/bin/synapse sync --watch" in unit
        assert f"WorkingDirectory={tmp_path}" in unit
        assert "Environment=SYNAPSE_TOKEN=syn_live_Y" in unit
        assert "Environment=SYNAPSE_API_ENDPOINT=https://synapse.example" in unit
        assert "Restart=always" in unit
        assert "[Install]" in unit


class TestInstallService:
    """install_service writes the unit and reports success."""

    def test_macos_writes_plist_to_target_dir(self, tmp_path: Path) -> None:
        from synapse_cli.commands import service as service_mod

        target = tmp_path / "LaunchAgents"
        target.mkdir()

        with (
            patch.object(service_mod.sys, "platform", "darwin"),
            patch.object(service_mod.subprocess, "run") as mock_run,
        ):
            mock_run.return_value = MagicMock(returncode=0)
            service_mod._install_service_impl(
                label="dev.synapse.watch",
                repo_path=str(tmp_path),
                synapse_token="tok_X",
                api_endpoint="https://x",
                synapse_bin="/bin/synapse",
                target_dir=target,
            )

        plist_path = target / "dev.synapse.watch.plist"
        assert plist_path.exists()
        content = plist_path.read_text()
        assert "tok_X" in content
        # launchctl load was invoked
        assert mock_run.called

    def test_linux_writes_systemd_unit_to_target_dir(
        self, tmp_path: Path
    ) -> None:
        from synapse_cli.commands import service as service_mod

        target = tmp_path / "systemd-user"
        target.mkdir()

        with (
            patch.object(service_mod.sys, "platform", "linux"),
            patch.object(service_mod.subprocess, "run") as mock_run,
        ):
            mock_run.return_value = MagicMock(returncode=0)
            service_mod._install_service_impl(
                label="synapse-watch",
                repo_path=str(tmp_path),
                synapse_token="tok_Y",
                api_endpoint="https://y",
                synapse_bin="/bin/synapse",
                target_dir=target,
            )

        unit_path = target / "synapse-watch.service"
        assert unit_path.exists()
        content = unit_path.read_text()
        assert "tok_Y" in content
        assert "ExecStart=/bin/synapse sync --watch" in content

    def test_windows_raises_unsupported(self, tmp_path: Path) -> None:
        from synapse_cli.commands import service as service_mod

        with (
            patch.object(service_mod.sys, "platform", "win32"),
            pytest.raises(service_mod.UnsupportedPlatform),
        ):
            service_mod._install_service_impl(
                label="x",
                repo_path=str(tmp_path),
                synapse_token="z",
                api_endpoint="a",
                synapse_bin="b",
                target_dir=tmp_path,
            )


class TestUninstallService:

    def test_macos_removes_plist(self, tmp_path: Path) -> None:
        from synapse_cli.commands import service as service_mod

        target = tmp_path / "LaunchAgents"
        target.mkdir()
        plist = target / "dev.synapse.watch.plist"
        plist.write_text("<plist></plist>")

        with (
            patch.object(service_mod.sys, "platform", "darwin"),
            patch.object(service_mod.subprocess, "run") as mock_run,
        ):
            mock_run.return_value = MagicMock(returncode=0)
            service_mod._uninstall_service_impl(
                label="dev.synapse.watch", target_dir=target
            )

        assert not plist.exists()

    def test_linux_removes_unit(self, tmp_path: Path) -> None:
        from synapse_cli.commands import service as service_mod

        target = tmp_path / "systemd-user"
        target.mkdir()
        unit = target / "synapse-watch.service"
        unit.write_text("[Unit]")

        with (
            patch.object(service_mod.sys, "platform", "linux"),
            patch.object(service_mod.subprocess, "run") as mock_run,
        ):
            mock_run.return_value = MagicMock(returncode=0)
            service_mod._uninstall_service_impl(
                label="synapse-watch", target_dir=target
            )

        assert not unit.exists()
