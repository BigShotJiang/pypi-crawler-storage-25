"""TDD tests for synapse sync — WRITTEN FIRST.

Tests the git diff extraction, secret filtering, and API upload
logic without running the full CLI or live git repos.
"""
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from synapse_cli.config import Credentials


def _make_creds() -> Credentials:
    return Credentials(
        token="tok_test",
        org_id="org-1",
        api_endpoint="http://localhost:8000",
    )


class TestGetChangedFiles:
    """Detect uncommitted changed files from git."""

    def test_returns_modified_files(self, tmp_path: Path) -> None:
        from synapse_cli.commands.sync import get_changed_files

        mock_repo = MagicMock()
        mock_diff = MagicMock()
        mock_diff.a_path = "src/main.py"
        mock_diff.change_type = "M"
        mock_repo.index.diff.return_value = [mock_diff]
        mock_repo.untracked_files = []

        with patch("synapse_cli.commands.sync.Repo", return_value=mock_repo):
            files = get_changed_files(str(tmp_path))

        assert "src/main.py" in files

    def test_returns_new_untracked_files(self, tmp_path: Path) -> None:
        from synapse_cli.commands.sync import get_changed_files

        mock_repo = MagicMock()
        mock_repo.index.diff.return_value = []
        mock_repo.untracked_files = ["new_feature.py"]

        with patch("synapse_cli.commands.sync.Repo", return_value=mock_repo):
            files = get_changed_files(str(tmp_path))

        assert "new_feature.py" in files

    def test_excludes_deleted_files(self, tmp_path: Path) -> None:
        from synapse_cli.commands.sync import get_changed_files

        mock_repo = MagicMock()
        deleted_diff = MagicMock()
        deleted_diff.a_path = "deleted.py"
        deleted_diff.change_type = "D"
        mock_repo.index.diff.return_value = [deleted_diff]
        mock_repo.untracked_files = []

        with patch("synapse_cli.commands.sync.Repo", return_value=mock_repo):
            files = get_changed_files(str(tmp_path))

        assert "deleted.py" not in files

    def test_deduplicates_files_across_staged_and_unstaged(self, tmp_path: Path) -> None:
        from synapse_cli.commands.sync import get_changed_files

        mock_repo = MagicMock()
        diff_item = MagicMock()
        diff_item.a_path = "src/dup.py"
        diff_item.change_type = "M"
        # Both staged and unstaged return the same file
        mock_repo.index.diff.return_value = [diff_item]
        mock_repo.untracked_files = ["src/dup.py"]

        with patch("synapse_cli.commands.sync.Repo", return_value=mock_repo):
            files = get_changed_files(str(tmp_path))

        assert files.count("src/dup.py") == 1


class TestUploadWIPFiles:
    """Upload WIP file contents to Synapse API."""

    @pytest.mark.asyncio
    async def test_uploads_clean_file(self, tmp_path: Path) -> None:
        from synapse_cli.commands.sync import upload_wip_file

        file = tmp_path / "main.py"
        file.write_text("def hello(): pass\n")

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.raise_for_status = MagicMock()
        mock_response.json = MagicMock(return_value={"synced": True})

        mock_http = MagicMock()
        mock_http.__aenter__ = AsyncMock(return_value=mock_http)
        mock_http.__aexit__ = AsyncMock(return_value=False)
        mock_http.post = AsyncMock(return_value=mock_response)

        with patch("synapse_cli.commands.sync.httpx.AsyncClient", return_value=mock_http):
            result = await upload_wip_file(
                file_path=str(file),
                content="def hello(): pass\n",
                creds=_make_creds(),
                repo="acme/backend",
                branch="feature/auth",
            )

        assert result is True
        mock_http.post.assert_called_once()

    @pytest.mark.asyncio
    async def test_rejects_file_with_secret(self, tmp_path: Path) -> None:
        from synapse_cli.commands.sync import upload_wip_file

        secret_content = 'GITHUB_TOKEN = "ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefgh"'

        mock_http = MagicMock()
        mock_http.__aenter__ = AsyncMock(return_value=mock_http)
        mock_http.__aexit__ = AsyncMock(return_value=False)
        mock_http.post = AsyncMock()

        with patch("synapse_cli.commands.sync.httpx.AsyncClient", return_value=mock_http):
            result = await upload_wip_file(
                file_path="src/main.py",
                content=secret_content,
                creds=_make_creds(),
                repo="acme/backend",
                branch="feature/auth",
            )

        assert result is False
        mock_http.post.assert_not_called()

    @pytest.mark.asyncio
    async def test_upload_sends_bearer_token(self, tmp_path: Path) -> None:
        from synapse_cli.commands.sync import upload_wip_file

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.raise_for_status = MagicMock()
        mock_response.json = MagicMock(return_value={"synced": True})

        mock_http = MagicMock()
        mock_http.__aenter__ = AsyncMock(return_value=mock_http)
        mock_http.__aexit__ = AsyncMock(return_value=False)
        mock_http.post = AsyncMock(return_value=mock_response)

        with patch("synapse_cli.commands.sync.httpx.AsyncClient", return_value=mock_http):
            await upload_wip_file(
                file_path="clean.py",
                content="x = 1\n",
                creds=_make_creds(),
                repo="acme/backend",
                branch="main",
            )

        call_kwargs = mock_http.post.call_args.kwargs
        headers = call_kwargs.get("headers", {})
        assert "Authorization" in headers
        assert "tok_test" in headers["Authorization"]

    @pytest.mark.asyncio
    async def test_upload_empty_file_skipped(self, tmp_path: Path) -> None:
        from synapse_cli.commands.sync import upload_wip_file

        mock_http = MagicMock()
        mock_http.__aenter__ = AsyncMock(return_value=mock_http)
        mock_http.__aexit__ = AsyncMock(return_value=False)
        mock_http.post = AsyncMock()

        with patch("synapse_cli.commands.sync.httpx.AsyncClient", return_value=mock_http):
            result = await upload_wip_file(
                file_path="empty.py",
                content="",
                creds=_make_creds(),
                repo="acme/backend",
                branch="main",
            )

        assert result is False
        mock_http.post.assert_not_called()


class TestFullNameFromRemote:
    """Convert various git remote URL forms to GitHub `owner/repo` slugs.

    The server stores repos by `full_name` (`acme/api`) — the CLI must send
    the same form so WIP entries match what MCP search expects.
    """

    def test_https_remote_with_dot_git(self) -> None:
        from synapse_cli.commands.sync import _full_name_from_remote
        assert _full_name_from_remote(
            "https://github.com/acme/api.git"
        ) == "acme/api"

    def test_https_remote_without_dot_git(self) -> None:
        from synapse_cli.commands.sync import _full_name_from_remote
        assert _full_name_from_remote(
            "https://github.com/acme/api"
        ) == "acme/api"

    def test_ssh_remote(self) -> None:
        from synapse_cli.commands.sync import _full_name_from_remote
        assert _full_name_from_remote(
            "git@github.com:acme/api.git"
        ) == "acme/api"

    def test_ssh_remote_without_dot_git(self) -> None:
        from synapse_cli.commands.sync import _full_name_from_remote
        assert _full_name_from_remote(
            "git@github.com:acme/api"
        ) == "acme/api"

    def test_https_with_trailing_slash(self) -> None:
        from synapse_cli.commands.sync import _full_name_from_remote
        assert _full_name_from_remote(
            "https://github.com/acme/api/"
        ) == "acme/api"

    def test_unrecognised_url_falls_back_to_input(self) -> None:
        from synapse_cli.commands.sync import _full_name_from_remote
        # Self-hosted gitea or unknown — better to send the URL than to
        # silently mangle it
        assert _full_name_from_remote(
            "https://git.internal/team/repo.git"
        ) == "team/repo"
        # Truly unparseable falls through unchanged
        assert _full_name_from_remote("unknown/repo") == "unknown/repo"


class TestWalkWorkingTree:
    """Full-tree walk for `synapse sync --full` — defers to git's own
    `ls-files --cached --others --exclude-standard` so .gitignore is honoured."""

    def test_returns_tracked_and_untracked_excluding_gitignored(
        self, tmp_path: Path
    ) -> None:
        from synapse_cli.commands.sync import walk_working_tree

        mock_repo = MagicMock()
        # ls-files returns one file per line
        mock_repo.git.ls_files.return_value = (
            "src/main.py\nsrc/utils.py\nREADME.md\nnew_feature.py"
        )

        with patch("synapse_cli.commands.sync.Repo", return_value=mock_repo):
            files = walk_working_tree(str(tmp_path))

        # All four files returned, gitignored ones omitted by ls-files itself
        assert files == [
            "src/main.py",
            "src/utils.py",
            "README.md",
            "new_feature.py",
        ]
        # Confirm we used the right git incantation
        mock_repo.git.ls_files.assert_called_once_with(
            "--cached", "--others", "--exclude-standard"
        )

    def test_returns_empty_for_empty_repo(self, tmp_path: Path) -> None:
        from synapse_cli.commands.sync import walk_working_tree

        mock_repo = MagicMock()
        mock_repo.git.ls_files.return_value = ""

        with patch("synapse_cli.commands.sync.Repo", return_value=mock_repo):
            files = walk_working_tree(str(tmp_path))

        assert files == []

    def test_strips_blank_lines_from_ls_files_output(self, tmp_path: Path) -> None:
        from synapse_cli.commands.sync import walk_working_tree

        mock_repo = MagicMock()
        # Trailing newline / blank lines should not become empty path entries
        mock_repo.git.ls_files.return_value = "src/a.py\n\nsrc/b.py\n"

        with patch("synapse_cli.commands.sync.Repo", return_value=mock_repo):
            files = walk_working_tree(str(tmp_path))

        assert files == ["src/a.py", "src/b.py"]


class TestDryRun:
    """`--dry-run` lists what would sync without uploading."""

    @pytest.mark.asyncio
    async def test_dry_run_does_not_post(self, tmp_path: Path) -> None:
        from synapse_cli.commands import sync as sync_mod

        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "main.py").write_text("x = 1\n")

        mock_post = AsyncMock()
        with (
            patch.object(sync_mod, "get_changed_files", return_value=["src/main.py"]),
            patch.object(sync_mod.httpx, "AsyncClient") as mock_cls,
        ):
            mock_client = MagicMock()
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_client.post = mock_post
            mock_cls.return_value = mock_client

            synced, skipped = await sync_mod._sync_once(
                creds=_make_creds(),
                repo_path=str(tmp_path),
                repo_remote="acme/api",
                branch="main",
                mode="diff",
                dry_run=True,
                quiet=True,
            )

        mock_post.assert_not_called()
        # Files are reported as "would-sync" — counted as synced for summary
        assert synced == 1

    @pytest.mark.asyncio
    async def test_dry_run_still_reports_secret_rejections(
        self, tmp_path: Path
    ) -> None:
        from synapse_cli.commands import sync as sync_mod

        secret = 'GITHUB_TOKEN = "ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefgh"'
        (tmp_path / "leak.py").write_text(secret)

        with patch.object(sync_mod, "get_changed_files", return_value=["leak.py"]):
            synced, skipped = await sync_mod._sync_once(
                creds=_make_creds(),
                repo_path=str(tmp_path),
                repo_remote="acme/api",
                branch="main",
                mode="diff",
                dry_run=True,
                quiet=True,
            )

        # Secret-bearing file counted as skipped, not synced
        assert synced == 0
        assert skipped == 1


class TestPreCommit:
    """`--pre-commit` scans staged files and exits non-zero on secrets.

    Does not upload; intended as a git pre-commit hook.
    """

    def test_scan_staged_files_returns_secret_results(
        self, tmp_path: Path
    ) -> None:
        from synapse_cli.commands.sync import scan_staged_files

        mock_repo = MagicMock()
        secret = 'AWS_KEY = "AKIAIOSFODNN7EXAMPLE"'
        clean = "x = 1\n"
        (tmp_path / "leak.py").write_text(secret)
        (tmp_path / "ok.py").write_text(clean)

        diff_a = MagicMock()
        diff_a.a_path = "leak.py"
        diff_a.change_type = "M"
        diff_b = MagicMock()
        diff_b.a_path = "ok.py"
        diff_b.change_type = "A"
        mock_repo.index.diff.return_value = [diff_a, diff_b]

        with patch("synapse_cli.commands.sync.Repo", return_value=mock_repo):
            results = scan_staged_files(str(tmp_path))

        # Two staged files; one rejected
        rejected = [r for r in results if r.is_rejected]
        clean_results = [r for r in results if not r.is_rejected]
        assert len(rejected) == 1
        assert len(clean_results) == 1
        assert rejected[0].file_path == "leak.py"

    def test_scan_staged_files_handles_repo_without_head(
        self, tmp_path: Path
    ) -> None:
        """A fresh repo with no commits has no HEAD ref — scanner must not crash.

        In that case, all index entries count as 'added' (no HEAD to diff against).
        """
        from synapse_cli.commands.sync import scan_staged_files

        # Real fresh repo, no commits
        from git import Repo as RealRepo
        real_repo = RealRepo.init(str(tmp_path))
        # Stage one file
        (tmp_path / "x.py").write_text("x = 1\n")
        real_repo.index.add(["x.py"])

        # Should not raise — should return one result for x.py
        results = scan_staged_files(str(tmp_path))
        assert len(results) == 1
        assert results[0].file_path == "x.py"
        assert results[0].is_rejected is False

    def test_scan_staged_files_skips_deletes(self, tmp_path: Path) -> None:
        from synapse_cli.commands.sync import scan_staged_files

        mock_repo = MagicMock()
        diff_d = MagicMock()
        diff_d.a_path = "gone.py"
        diff_d.change_type = "D"
        mock_repo.index.diff.return_value = [diff_d]

        with patch("synapse_cli.commands.sync.Repo", return_value=mock_repo):
            results = scan_staged_files(str(tmp_path))

        assert results == []


class TestSyncMode:
    """`--full` must call walk_working_tree, not get_changed_files."""

    @pytest.mark.asyncio
    async def test_full_mode_walks_tree_not_diff(self, tmp_path: Path) -> None:
        from synapse_cli.commands import sync as sync_mod

        # Set up a tmp file so the upload path can read it
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "main.py").write_text("x = 1\n")

        with (
            patch.object(sync_mod, "walk_working_tree", return_value=["src/main.py"]) as mock_walk,
            patch.object(sync_mod, "get_changed_files") as mock_diff,
            patch.object(sync_mod, "upload_wip_file", new=AsyncMock(return_value=True)),
        ):
            await sync_mod._sync_once(
                creds=_make_creds(),
                repo_path=str(tmp_path),
                repo_remote="acme/backend",
                branch="main",
                mode="full",
                quiet=True,
            )

        mock_walk.assert_called_once_with(str(tmp_path))
        mock_diff.assert_not_called()

    @pytest.mark.asyncio
    async def test_diff_mode_uses_get_changed_files(self, tmp_path: Path) -> None:
        from synapse_cli.commands import sync as sync_mod

        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "main.py").write_text("x = 1\n")

        with (
            patch.object(sync_mod, "get_changed_files", return_value=["src/main.py"]) as mock_diff,
            patch.object(sync_mod, "walk_working_tree") as mock_walk,
            patch.object(sync_mod, "upload_wip_file", new=AsyncMock(return_value=True)),
        ):
            await sync_mod._sync_once(
                creds=_make_creds(),
                repo_path=str(tmp_path),
                repo_remote="acme/backend",
                branch="main",
                mode="diff",
                quiet=True,
            )

        mock_diff.assert_called_once_with(str(tmp_path))
        mock_walk.assert_not_called()
