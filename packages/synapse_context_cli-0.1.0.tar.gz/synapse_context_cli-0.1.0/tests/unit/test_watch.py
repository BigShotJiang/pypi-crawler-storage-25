"""TDD tests for synapse sync --watch — WRITTEN FIRST.

Watch mode debounces rapid filesystem events into a single sync run.
Tests cover the path filter, the debouncer, and the integration boundary
(callback wiring) without spinning up a real watchdog Observer.
"""
from __future__ import annotations

import threading
import time
from pathlib import Path
from unittest.mock import MagicMock, patch


class TestShouldIgnore:
    """Path filter — skip noisy directories that aren't tracked anyway."""

    def test_skips_dot_git_directory(self, tmp_path: Path) -> None:
        from synapse_cli.commands.watch import _should_ignore

        repo = tmp_path
        path = repo / ".git" / "HEAD"
        assert _should_ignore(str(path), str(repo)) is True

    def test_skips_node_modules(self, tmp_path: Path) -> None:
        from synapse_cli.commands.watch import _should_ignore

        repo = tmp_path
        path = repo / "node_modules" / "lodash" / "index.js"
        assert _should_ignore(str(path), str(repo)) is True

    def test_skips_python_caches(self, tmp_path: Path) -> None:
        from synapse_cli.commands.watch import _should_ignore

        repo = tmp_path
        for noisy in ("__pycache__", ".mypy_cache", ".pytest_cache", ".ruff_cache"):
            path = repo / "src" / noisy / "data"
            assert _should_ignore(str(path), str(repo)) is True, noisy

    def test_skips_build_artifacts(self, tmp_path: Path) -> None:
        from synapse_cli.commands.watch import _should_ignore

        repo = tmp_path
        for noisy in ("dist", "build", "target", ".next", ".venv"):
            path = repo / noisy / "out.js"
            assert _should_ignore(str(path), str(repo)) is True, noisy

    def test_does_not_skip_normal_source_file(self, tmp_path: Path) -> None:
        from synapse_cli.commands.watch import _should_ignore

        repo = tmp_path
        path = repo / "src" / "main.py"
        assert _should_ignore(str(path), str(repo)) is False

    def test_does_not_skip_root_dotfile(self, tmp_path: Path) -> None:
        """Root-level dotfiles like .env.example or .pre-commit-config.yaml
        are real source — only directory-level ignores are filtered."""
        from synapse_cli.commands.watch import _should_ignore

        repo = tmp_path
        path = repo / ".pre-commit-config.yaml"
        assert _should_ignore(str(path), str(repo)) is False


class TestDebouncer:
    """The debouncer must coalesce rapid schedule() calls into one fire."""

    def test_fires_once_after_quiet_period(self) -> None:
        from synapse_cli.commands.watch import _DebouncedSync

        callback = MagicMock()
        debouncer = _DebouncedSync(debounce_s=0.05, sync_callback=callback)

        for _ in range(10):
            debouncer.schedule()

        # Wait for the timer to fire; allow some slack on slow CI
        time.sleep(0.2)

        assert callback.call_count == 1

    def test_subsequent_burst_fires_again(self) -> None:
        from synapse_cli.commands.watch import _DebouncedSync

        callback = MagicMock()
        debouncer = _DebouncedSync(debounce_s=0.05, sync_callback=callback)

        debouncer.schedule()
        time.sleep(0.15)
        debouncer.schedule()
        time.sleep(0.15)

        assert callback.call_count == 2

    def test_cancel_prevents_pending_fire(self) -> None:
        from synapse_cli.commands.watch import _DebouncedSync

        callback = MagicMock()
        debouncer = _DebouncedSync(debounce_s=0.1, sync_callback=callback)

        debouncer.schedule()
        debouncer.cancel()
        time.sleep(0.2)

        assert callback.call_count == 0

    def test_thread_safe_under_concurrent_schedule(self) -> None:
        """Concurrent schedule() calls must not race the timer cancel/replace."""
        from synapse_cli.commands.watch import _DebouncedSync

        callback = MagicMock()
        debouncer = _DebouncedSync(debounce_s=0.05, sync_callback=callback)

        def hammer() -> None:
            for _ in range(50):
                debouncer.schedule()

        threads = [threading.Thread(target=hammer) for _ in range(4)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        time.sleep(0.2)
        # Exactly one fire after the burst settles
        assert callback.call_count == 1


class TestGitignoreCache:
    """`_GitignoreCache` shells out to `git check-ignore --quiet <path>`
    and caches results so repeated saves of the same file don't re-shell."""

    def test_returns_true_when_git_says_ignored(self, tmp_path: Path) -> None:
        from synapse_cli.commands.watch import _GitignoreCache

        # git check-ignore --quiet exits 0 if the path IS ignored
        with patch("synapse_cli.commands.watch.subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0)
            cache = _GitignoreCache(repo_path=str(tmp_path))
            assert cache.is_ignored(str(tmp_path / "dist" / "out.js")) is True
        mock_run.assert_called_once()

    def test_returns_false_when_git_says_not_ignored(self, tmp_path: Path) -> None:
        from synapse_cli.commands.watch import _GitignoreCache

        # exit 1 = not ignored
        with patch("synapse_cli.commands.watch.subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=1)
            cache = _GitignoreCache(repo_path=str(tmp_path))
            assert cache.is_ignored(str(tmp_path / "src" / "main.py")) is False

    def test_caches_repeated_lookups(self, tmp_path: Path) -> None:
        from synapse_cli.commands.watch import _GitignoreCache

        with patch("synapse_cli.commands.watch.subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0)
            cache = _GitignoreCache(repo_path=str(tmp_path))
            path = str(tmp_path / "dist" / "out.js")
            cache.is_ignored(path)
            cache.is_ignored(path)
            cache.is_ignored(path)

        # Only one shell-out despite three lookups
        assert mock_run.call_count == 1

    def test_returns_false_when_git_unavailable(self, tmp_path: Path) -> None:
        """If `git` is missing or the repo is detached, fail open — don't
        block syncs because gitignore lookup failed."""
        from synapse_cli.commands.watch import _GitignoreCache

        with patch("synapse_cli.commands.watch.subprocess.run") as mock_run:
            mock_run.side_effect = FileNotFoundError("git not found")
            cache = _GitignoreCache(repo_path=str(tmp_path))
            assert cache.is_ignored(str(tmp_path / "src" / "main.py")) is False


class TestRepoEventHandlerWithGitignore:
    """Event handler integrates the cheap _IGNORED_DIRS fast-path with the
    gitignore lookup so we never shell out for the obvious cases."""

    def test_fastpath_skip_does_not_invoke_gitignore(self, tmp_path: Path) -> None:
        from synapse_cli.commands import watch as watch_mod

        debouncer = MagicMock()
        gitignore = MagicMock()
        handler = watch_mod._RepoEventHandler(
            debouncer=debouncer, repo_path=str(tmp_path), gitignore=gitignore
        )

        event = MagicMock()
        event.is_directory = False
        event.src_path = str(tmp_path / ".git" / "HEAD")

        handler.on_any_event(event)

        gitignore.is_ignored.assert_not_called()
        debouncer.schedule.assert_not_called()

    def test_gitignore_consulted_for_non_fastpath(self, tmp_path: Path) -> None:
        from synapse_cli.commands import watch as watch_mod

        debouncer = MagicMock()
        gitignore = MagicMock()
        gitignore.is_ignored.return_value = True
        handler = watch_mod._RepoEventHandler(
            debouncer=debouncer, repo_path=str(tmp_path), gitignore=gitignore
        )

        event = MagicMock()
        event.is_directory = False
        # `dist/` is NOT in _IGNORED_DIRS by default? Actually it IS. Use
        # a path the fast-path wouldn't catch:
        event.src_path = str(tmp_path / "generated" / "schema.py")

        handler.on_any_event(event)

        gitignore.is_ignored.assert_called_once()
        debouncer.schedule.assert_not_called()

    def test_event_fires_when_not_ignored(self, tmp_path: Path) -> None:
        from synapse_cli.commands import watch as watch_mod

        debouncer = MagicMock()
        gitignore = MagicMock()
        gitignore.is_ignored.return_value = False
        handler = watch_mod._RepoEventHandler(
            debouncer=debouncer, repo_path=str(tmp_path), gitignore=gitignore
        )

        event = MagicMock()
        event.is_directory = False
        event.src_path = str(tmp_path / "src" / "main.py")

        handler.on_any_event(event)

        debouncer.schedule.assert_called_once()


class TestRunWatch:
    """The top-level run loop wires together initial sync + observer + debouncer."""

    def test_runs_initial_sync_before_starting_observer(self, tmp_path: Path) -> None:
        from synapse_cli.commands import watch as watch_mod

        sync_callback = MagicMock()

        # Stub out Observer so we don't actually watch the filesystem
        with patch.object(watch_mod, "Observer") as mock_observer_cls:
            mock_observer = MagicMock()
            mock_observer_cls.return_value = mock_observer

            # Have the post-start sleep raise immediately so run_watch returns
            with patch.object(watch_mod.time, "sleep", side_effect=KeyboardInterrupt):
                watch_mod.run_watch(
                    repo_path=str(tmp_path),
                    debounce_s=1.5,
                    sync_callback=sync_callback,
                )

        # Initial sync must run at least once before the loop exits
        assert sync_callback.call_count >= 1
        mock_observer.schedule.assert_called_once()
        mock_observer.start.assert_called_once()
        mock_observer.stop.assert_called_once()
        mock_observer.join.assert_called_once()
