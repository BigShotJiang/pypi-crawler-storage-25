"""TDD tests for top-level CLI behaviour — WRITTEN FIRST."""
from __future__ import annotations

from typer.testing import CliRunner


class TestVersionFlag:
    def test_synapse_version_prints_version(self) -> None:
        from synapse_cli import __version__
        from synapse_cli.main import app

        runner = CliRunner()
        result = runner.invoke(app, ["--version"])
        assert result.exit_code == 0
        assert __version__ in result.stdout

    def test_synapse_v_short_flag(self) -> None:
        from synapse_cli import __version__
        from synapse_cli.main import app

        runner = CliRunner()
        result = runner.invoke(app, ["-V"])
        assert result.exit_code == 0
        assert __version__ in result.stdout


class TestVersionHandshakeHeaders:
    def test_default_headers_include_version_and_user_agent(self) -> None:
        from synapse_cli import __version__
        from synapse_cli._http import default_headers

        h = default_headers()
        assert h["X-Synapse-CLI-Version"] == __version__
        assert h["User-Agent"] == f"synapse-cli/{__version__}"
        assert "Authorization" not in h

    def test_default_headers_with_token_includes_bearer(self) -> None:
        from synapse_cli._http import default_headers

        h = default_headers(token="syn_live_x")
        assert h["Authorization"] == "Bearer syn_live_x"
