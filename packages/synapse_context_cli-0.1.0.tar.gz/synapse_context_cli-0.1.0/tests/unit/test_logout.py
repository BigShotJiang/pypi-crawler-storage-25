"""TDD tests for `synapse logout` — WRITTEN FIRST."""
from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

import pytest


class TestLogout:
    """`synapse logout` clears stored credentials."""

    def test_removes_credentials_file_when_present(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        from synapse_cli.commands.logout import logout

        creds_file = tmp_path / ".synapse" / "credentials.json"
        creds_file.parent.mkdir(parents=True)
        creds_file.write_text('{"token": "tok_x", "org_id": "org-1"}')

        with patch("synapse_cli.commands.logout.CREDENTIALS_PATH", creds_file):
            logout()

        assert not creds_file.exists()
        out = capsys.readouterr().out
        assert "Logged out" in out or "logged out" in out

    def test_exits_cleanly_when_no_credentials_file(
        self, tmp_path: Path, capsys: pytest.CaptureFixture[str]
    ) -> None:
        from synapse_cli.commands.logout import logout

        nonexistent = tmp_path / ".synapse" / "credentials.json"

        with patch("synapse_cli.commands.logout.CREDENTIALS_PATH", nonexistent):
            logout()

        # Should not raise; should print something informative
        out = capsys.readouterr().out
        assert "Not logged in" in out or "No credentials" in out

    def test_hints_to_unset_env_var_when_token_set(
        self,
        tmp_path: Path,
        monkeypatch: pytest.MonkeyPatch,
        capsys: pytest.CaptureFixture[str],
    ) -> None:
        from synapse_cli.commands.logout import logout

        monkeypatch.setenv("SYNAPSE_TOKEN", "syn_live_x")
        nonexistent = tmp_path / ".synapse" / "credentials.json"

        with patch("synapse_cli.commands.logout.CREDENTIALS_PATH", nonexistent):
            logout()

        out = capsys.readouterr().out
        assert "SYNAPSE_TOKEN" in out
        assert "unset" in out.lower()

    def test_does_not_hint_when_env_var_is_not_a_synapse_token(
        self,
        tmp_path: Path,
        monkeypatch: pytest.MonkeyPatch,
        capsys: pytest.CaptureFixture[str],
    ) -> None:
        """Don't nag about a placeholder/test value that doesn't start with syn_live_."""
        from synapse_cli.commands.logout import logout

        monkeypatch.setenv("SYNAPSE_TOKEN", "test-placeholder")
        creds_file = tmp_path / ".synapse" / "credentials.json"
        creds_file.parent.mkdir(parents=True)
        creds_file.write_text('{"token": "tok_x", "org_id": "org-1"}')

        with patch("synapse_cli.commands.logout.CREDENTIALS_PATH", creds_file):
            logout()

        out = capsys.readouterr().out
        assert "unset SYNAPSE_TOKEN" not in out

    def test_does_not_hint_when_env_var_unset(
        self,
        tmp_path: Path,
        monkeypatch: pytest.MonkeyPatch,
        capsys: pytest.CaptureFixture[str],
    ) -> None:
        from synapse_cli.commands.logout import logout

        monkeypatch.delenv("SYNAPSE_TOKEN", raising=False)
        creds_file = tmp_path / ".synapse" / "credentials.json"
        creds_file.parent.mkdir(parents=True)
        creds_file.write_text('{"token": "tok_x", "org_id": "org-1"}')

        with patch("synapse_cli.commands.logout.CREDENTIALS_PATH", creds_file):
            logout()

        out = capsys.readouterr().out
        assert "unset SYNAPSE_TOKEN" not in out
