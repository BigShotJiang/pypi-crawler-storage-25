"""TDD tests for synapse login — GitHub device flow — WRITTEN FIRST."""
import pytest
from unittest.mock import AsyncMock, patch, MagicMock

from synapse_cli.commands.login import (
    request_device_code,
    poll_for_token,
    exchange_for_synapse_jwt,
)


class TestRequestDeviceCode:

    @pytest.mark.asyncio
    async def test_returns_device_code_response(self) -> None:
        mock_resp = MagicMock()
        mock_resp.json.return_value = {
            "device_code": "dev-abc",
            "user_code": "ABCD-1234",
            "verification_uri": "https://github.com/login/device",
            "expires_in": 900,
            "interval": 5,
        }
        mock_resp.raise_for_status = MagicMock()

        with patch("synapse_cli.commands.login.httpx.AsyncClient") as mock_cls:
            mock_client = AsyncMock()
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=None)
            mock_client.post = AsyncMock(return_value=mock_resp)
            mock_cls.return_value = mock_client

            result = await request_device_code(client_id="test-client-id")

        assert result.user_code == "ABCD-1234"
        assert result.device_code == "dev-abc"
        assert result.interval == 5

    @pytest.mark.asyncio
    async def test_posts_to_github_device_endpoint(self) -> None:
        mock_resp = MagicMock()
        mock_resp.json.return_value = {
            "device_code": "x", "user_code": "X", "verification_uri": "u",
            "expires_in": 900, "interval": 5,
        }
        mock_resp.raise_for_status = MagicMock()

        with patch("synapse_cli.commands.login.httpx.AsyncClient") as mock_cls:
            mock_client = AsyncMock()
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=None)
            mock_client.post = AsyncMock(return_value=mock_resp)
            mock_cls.return_value = mock_client

            await request_device_code(client_id="my-client")

            call_args = mock_client.post.call_args
            url = call_args.args[0] if call_args.args else call_args.kwargs.get("url")
            assert "github.com/login/device/code" in url


class TestPollForToken:

    @pytest.mark.asyncio
    async def test_returns_access_token_on_success(self) -> None:
        mock_resp = MagicMock()
        mock_resp.json.return_value = {"access_token": "gho_abc123", "token_type": "bearer"}
        mock_resp.raise_for_status = MagicMock()

        with patch("synapse_cli.commands.login.httpx.AsyncClient") as mock_cls:
            mock_client = AsyncMock()
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=None)
            mock_client.post = AsyncMock(return_value=mock_resp)
            mock_cls.return_value = mock_client

            with patch("synapse_cli.commands.login.asyncio.sleep", new=AsyncMock()):
                result = await poll_for_token(
                    client_id="cid",
                    device_code="dev-abc",
                    interval=1,
                )

        assert result.access_token == "gho_abc123"
        assert result.error is None

    @pytest.mark.asyncio
    async def test_retries_on_authorization_pending(self) -> None:
        """Polls again when GitHub returns authorization_pending."""
        pending = MagicMock()
        pending.json.return_value = {"error": "authorization_pending"}
        pending.raise_for_status = MagicMock()

        success = MagicMock()
        success.json.return_value = {"access_token": "gho_done"}
        success.raise_for_status = MagicMock()

        with patch("synapse_cli.commands.login.httpx.AsyncClient") as mock_cls:
            mock_client = AsyncMock()
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=None)
            mock_client.post = AsyncMock(side_effect=[pending, success])
            mock_cls.return_value = mock_client

            with patch("synapse_cli.commands.login.asyncio.sleep", new=AsyncMock()):
                result = await poll_for_token(
                    client_id="cid",
                    device_code="dev-abc",
                    interval=1,
                )

        assert result.access_token == "gho_done"

    @pytest.mark.asyncio
    async def test_returns_error_on_access_denied(self) -> None:
        denied = MagicMock()
        denied.json.return_value = {"error": "access_denied"}
        denied.raise_for_status = MagicMock()

        with patch("synapse_cli.commands.login.httpx.AsyncClient") as mock_cls:
            mock_client = AsyncMock()
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=None)
            mock_client.post = AsyncMock(return_value=denied)
            mock_cls.return_value = mock_client

            with patch("synapse_cli.commands.login.asyncio.sleep", new=AsyncMock()):
                result = await poll_for_token(
                    client_id="cid",
                    device_code="dev-abc",
                    interval=1,
                )

        assert result.access_token is None
        assert result.error == "access_denied"


class TestExchangeForSynapseJwt:

    @pytest.mark.asyncio
    async def test_returns_synapse_token_and_org(self) -> None:
        mock_resp = MagicMock()
        mock_resp.json.return_value = {
            "token": "synapse.jwt.here",
            "org_id": "org-abc",
        }
        mock_resp.raise_for_status = MagicMock()

        with patch("synapse_cli.commands.login.httpx.AsyncClient") as mock_cls:
            mock_client = AsyncMock()
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=None)
            mock_client.post = AsyncMock(return_value=mock_resp)
            mock_cls.return_value = mock_client

            token, org_id = await exchange_for_synapse_jwt(
                github_token="gho_abc",
                api_endpoint="https://api.synapse.dev",
            )

        assert token == "synapse.jwt.here"
        assert org_id == "org-abc"
