"""TDD tests for CLI credentials config — WRITTEN FIRST.

These validate loading/saving credentials from env vars and filesystem,
ensuring precedence rules and directory creation behave correctly.
"""
import json
from pathlib import Path
from unittest.mock import patch

import pytest

from synapse_cli.config import (
    DEFAULT_API_ENDPOINT,
    Credentials,
    load_credentials,
    save_credentials,
)


class TestLoadCredentialsFromEnv:
    """Environment variable credential loading."""

    def test_load_credentials_from_env(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("SYNAPSE_TOKEN", "tok_from_env")
        monkeypatch.delenv("SYNAPSE_API_ENDPOINT", raising=False)

        creds = load_credentials()

        assert creds is not None
        assert creds.token == "tok_from_env"
        assert creds.api_endpoint == DEFAULT_API_ENDPOINT

    def test_load_credentials_env_custom_endpoint(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("SYNAPSE_TOKEN", "tok_from_env")
        monkeypatch.setenv("SYNAPSE_API_ENDPOINT", "http://localhost:8000")

        creds = load_credentials()

        assert creds is not None
        assert creds.api_endpoint == "http://localhost:8000"


class TestLoadCredentialsFromFile:
    """File-based credential loading."""

    def test_load_credentials_from_file(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.delenv("SYNAPSE_TOKEN", raising=False)

        creds_file = tmp_path / ".synapse" / "credentials.json"
        creds_file.parent.mkdir(parents=True)
        creds_file.write_text(json.dumps({
            "token": "tok_from_file",
            "org_id": "org-42",
            "api_endpoint": "https://api.synapse.dev",
        }))

        with patch("synapse_cli.config.CREDENTIALS_PATH", creds_file):
            creds = load_credentials()

        assert creds is not None
        assert creds.token == "tok_from_file"
        assert creds.org_id == "org-42"


class TestLoadCredentialsMissing:
    """Behavior when no credentials are available."""

    def test_load_credentials_returns_none_when_missing(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.delenv("SYNAPSE_TOKEN", raising=False)
        nonexistent = tmp_path / ".synapse" / "credentials.json"

        with patch("synapse_cli.config.CREDENTIALS_PATH", nonexistent):
            creds = load_credentials()

        assert creds is None


class TestCredentialsPrecedence:
    """Environment variables take precedence over file."""

    def test_credentials_env_overrides_file(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("SYNAPSE_TOKEN", "tok_from_env")

        creds_file = tmp_path / ".synapse" / "credentials.json"
        creds_file.parent.mkdir(parents=True)
        creds_file.write_text(json.dumps({
            "token": "tok_from_file",
            "org_id": "org-42",
            "api_endpoint": "https://api.synapse.dev",
        }))

        with patch("synapse_cli.config.CREDENTIALS_PATH", creds_file):
            creds = load_credentials()

        assert creds is not None
        # Env var wins over file
        assert creds.token == "tok_from_env"


class TestSaveCredentials:
    """Credential persistence."""

    def test_save_credentials_creates_directory(self, tmp_path: Path) -> None:
        creds_file = tmp_path / ".synapse" / "credentials.json"

        with patch("synapse_cli.config.CREDENTIALS_PATH", creds_file):
            save_credentials(Credentials(
                token="tok_new",
                org_id="org-99",
                api_endpoint="https://api.synapse.dev",
            ))

        assert creds_file.exists()
        data = json.loads(creds_file.read_text())
        assert data["token"] == "tok_new"
        assert data["org_id"] == "org-99"

    def test_save_and_reload_round_trip(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("SYNAPSE_TOKEN", raising=False)
        creds_file = tmp_path / ".synapse" / "credentials.json"

        with patch("synapse_cli.config.CREDENTIALS_PATH", creds_file):
            save_credentials(Credentials(
                token="round_trip_tok",
                org_id="org-rt",
            ))
            loaded = load_credentials()

        assert loaded is not None
        assert loaded.token == "round_trip_tok"
        assert loaded.org_id == "org-rt"
