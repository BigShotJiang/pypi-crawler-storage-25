"""TDD tests for synapse status command — WRITTEN FIRST."""
import pytest
from unittest.mock import AsyncMock, patch, MagicMock

from synapse_cli.commands.status import fetch_api_status, fetch_wip_entries


class TestFetchApiStatus:

    @pytest.mark.asyncio
    async def test_returns_healthy_when_api_up(self) -> None:
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"status": "ok", "version": "0.1.0"}
        mock_resp.raise_for_status = MagicMock()

        with patch("synapse_cli.commands.status.httpx.AsyncClient") as mock_cls:
            mock_client = AsyncMock()
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=None)
            mock_client.get = AsyncMock(return_value=mock_resp)
            mock_cls.return_value = mock_client

            result = await fetch_api_status(api_endpoint="https://api.synapse.dev", token="tok")

        assert result.connected is True
        assert result.version == "0.1.0"
        assert result.error is None

    @pytest.mark.asyncio
    async def test_returns_disconnected_when_api_down(self) -> None:
        with patch("synapse_cli.commands.status.httpx.AsyncClient") as mock_cls:
            mock_client = AsyncMock()
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=None)
            mock_client.get = AsyncMock(
                side_effect=Exception("Connection refused")
            )
            mock_cls.return_value = mock_client

            result = await fetch_api_status(api_endpoint="https://api.synapse.dev", token="tok")

        assert result.connected is False
        assert "Connection refused" in (result.error or "")

    @pytest.mark.asyncio
    async def test_sends_auth_header(self) -> None:
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"status": "ok", "version": "0.1.0"}
        mock_resp.raise_for_status = MagicMock()

        with patch("synapse_cli.commands.status.httpx.AsyncClient") as mock_cls:
            mock_client = AsyncMock()
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=None)
            mock_client.get = AsyncMock(return_value=mock_resp)
            mock_cls.return_value = mock_client

            await fetch_api_status(api_endpoint="https://api.synapse.dev", token="my-token")

            call_kwargs = mock_client.get.call_args.kwargs
            headers = call_kwargs.get("headers", {})
            assert headers.get("Authorization") == "Bearer my-token"


class TestFetchWipEntries:
    """`status -v` calls /wip/list and renders the entries."""

    @pytest.mark.asyncio
    async def test_returns_entries_from_response(self) -> None:
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.raise_for_status = MagicMock()
        mock_resp.json.return_value = {
            "entries": [
                {"file_path": "src/a.py", "ttl_seconds": 14000, "repo": "acme/api", "branch": "main"},
                {"file_path": "src/b.py", "ttl_seconds": 7000, "repo": "acme/api", "branch": "feat/x"},
            ]
        }

        with patch("synapse_cli.commands.status.httpx.AsyncClient") as mock_cls:
            mock_client = AsyncMock()
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=None)
            mock_client.get = AsyncMock(return_value=mock_resp)
            mock_cls.return_value = mock_client

            entries = await fetch_wip_entries(
                api_endpoint="https://synapse.example", token="tok"
            )

        assert len(entries) == 2
        assert entries[0].file_path == "src/a.py"
        assert entries[0].ttl_seconds == 14000
        assert entries[1].branch == "feat/x"

    @pytest.mark.asyncio
    async def test_returns_empty_on_error(self) -> None:
        with patch("synapse_cli.commands.status.httpx.AsyncClient") as mock_cls:
            mock_client = AsyncMock()
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=None)
            mock_client.get = AsyncMock(side_effect=Exception("boom"))
            mock_cls.return_value = mock_client

            entries = await fetch_wip_entries(
                api_endpoint="https://synapse.example", token="tok"
            )

        assert entries == []
