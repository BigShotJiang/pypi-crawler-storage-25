"""Integration test fixtures — require a live Synapse stack.

Skipped unless the env var `SYNAPSE_INTEGRATION=1` is set. Reads connection
info from:
  - SYNAPSE_API_ENDPOINT (default: http://localhost:8000)
  - SYNAPSE_TOKEN (a syn_live_* token; required when env var is set)
"""
from __future__ import annotations

import os
import subprocess
from pathlib import Path
from typing import Generator

import httpx
import pytest

from synapse_cli.config import Credentials


def _integration_enabled() -> bool:
    return os.environ.get("SYNAPSE_INTEGRATION") == "1"


@pytest.fixture(scope="session", autouse=True)
def _gate_integration_tests() -> None:
    """Skip the entire integration suite unless explicitly enabled."""
    if not _integration_enabled():
        pytest.skip(
            "integration tests skipped — set SYNAPSE_INTEGRATION=1 to enable",
            allow_module_level=True,
        )


@pytest.fixture(scope="session")
def api_endpoint() -> str:
    return os.environ.get("SYNAPSE_API_ENDPOINT", "http://localhost:8000")


@pytest.fixture(scope="session")
def synapse_token() -> str:
    token = os.environ.get("SYNAPSE_TOKEN")
    if not token:
        pytest.skip("SYNAPSE_TOKEN must be set for integration tests")
    return token


@pytest.fixture
def integration_creds(api_endpoint: str, synapse_token: str) -> Credentials:
    return Credentials(token=synapse_token, org_id="", api_endpoint=api_endpoint)


@pytest.fixture
def tmp_git_repo(tmp_path: Path) -> Generator[Path, None, None]:
    """Create a tmp directory initialised as a git repo with one commit."""
    repo = tmp_path / "repo"
    repo.mkdir()
    subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
    subprocess.run(
        ["git", "config", "user.email", "test@example.com"], cwd=repo, check=True
    )
    subprocess.run(
        ["git", "config", "user.name", "Test User"], cwd=repo, check=True
    )
    subprocess.run(
        ["git", "remote", "add", "origin", "https://github.com/test/test.git"],
        cwd=repo,
        check=True,
    )
    (repo / "README.md").write_text("# test\n")
    subprocess.run(["git", "add", "."], cwd=repo, check=True)
    subprocess.run(
        ["git", "commit", "-q", "-m", "init"], cwd=repo, check=True
    )
    yield repo


@pytest.fixture
def cleanup_wip(api_endpoint: str, synapse_token: str):
    """After the test, request the server clears the user's WIP entries.

    Implemented as a best-effort: hit /wip/list and rely on the natural 4h
    TTL for cleanup. Server-side test-only flush would be cleaner but is
    out of scope.
    """
    yield
    # No-op cleanup: TTL handles it
    _ = api_endpoint, synapse_token


def wip_entries_for(api_endpoint: str, token: str) -> list[dict]:
    """Read /wip/list — used by tests to assert what landed in Redis."""
    response = httpx.get(
        f"{api_endpoint}/wip/list",
        headers={"Authorization": f"Bearer {token}"},
        timeout=5,
    )
    response.raise_for_status()
    return response.json().get("entries", [])
