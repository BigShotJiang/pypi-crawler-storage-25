"""End-to-end: `synapse sync --pre-commit` exits non-zero on staged secrets."""
from __future__ import annotations

import subprocess
from pathlib import Path

from typer.testing import CliRunner

from synapse_cli.main import app

runner = CliRunner()


def test_pre_commit_fails_on_staged_secret(tmp_git_repo: Path) -> None:
    # Stage a file that contains a credential
    leak = tmp_git_repo / "secrets.py"
    leak.write_text('AWS_KEY = "AKIAIOSFODNN7EXAMPLE"\n')
    subprocess.run(["git", "add", "secrets.py"], cwd=tmp_git_repo, check=True)

    result = runner.invoke(
        app, ["sync", "--pre-commit"], catch_exceptions=False, env={"PWD": str(tmp_git_repo)}
    )
    # The CLI runs in the test process cwd; switch with a context manager:
    import os
    cwd = os.getcwd()
    try:
        os.chdir(tmp_git_repo)
        result = runner.invoke(app, ["sync", "--pre-commit"], catch_exceptions=False)
    finally:
        os.chdir(cwd)

    assert result.exit_code == 1
    assert "secret" in result.stdout.lower()


def test_pre_commit_passes_on_clean_staged_files(tmp_git_repo: Path) -> None:
    clean = tmp_git_repo / "ok.py"
    clean.write_text("x = 1\n")
    subprocess.run(["git", "add", "ok.py"], cwd=tmp_git_repo, check=True)

    import os
    cwd = os.getcwd()
    try:
        os.chdir(tmp_git_repo)
        result = runner.invoke(app, ["sync", "--pre-commit"], catch_exceptions=False)
    finally:
        os.chdir(cwd)

    assert result.exit_code == 0
