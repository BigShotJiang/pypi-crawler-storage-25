"""End-to-end: `synapse sync` lands files in /wip/list."""
from __future__ import annotations

import asyncio
import time
from pathlib import Path

from synapse_cli.commands.sync import _sync_once
from synapse_cli.config import Credentials
from tests.integration.conftest import wip_entries_for


def test_sync_diff_lands_in_wip_list(
    tmp_git_repo: Path,
    integration_creds: Credentials,
    api_endpoint: str,
    synapse_token: str,
    cleanup_wip,
) -> None:
    # Add an uncommitted file
    target = tmp_git_repo / "src" / "feature.py"
    target.parent.mkdir()
    target.write_text("def feature():\n    return 'live edit'\n")

    asyncio.run(_sync_once(
        creds=integration_creds,
        repo_path=str(tmp_git_repo),
        repo_remote="https://github.com/test/test.git",
        branch="main",
        mode="diff",
        quiet=True,
    ))

    # Eventually-consistent: poll /wip/list
    deadline = time.time() + 5
    while time.time() < deadline:
        entries = wip_entries_for(api_endpoint, synapse_token)
        if any(e["file_path"] == "src/feature.py" for e in entries):
            return
        time.sleep(0.5)

    raise AssertionError(
        f"src/feature.py never appeared in /wip/list after sync (got {entries})"
    )


def test_sync_full_walks_tracked_files(
    tmp_git_repo: Path,
    integration_creds: Credentials,
    api_endpoint: str,
    synapse_token: str,
    cleanup_wip,
) -> None:
    # README.md is already committed in the fixture
    asyncio.run(_sync_once(
        creds=integration_creds,
        repo_path=str(tmp_git_repo),
        repo_remote="https://github.com/test/test.git",
        branch="main",
        mode="full",
        quiet=True,
    ))

    deadline = time.time() + 5
    while time.time() < deadline:
        entries = wip_entries_for(api_endpoint, synapse_token)
        if any(e["file_path"] == "README.md" for e in entries):
            return
        time.sleep(0.5)
    raise AssertionError(
        f"README.md never appeared in /wip/list after --full sync (got {entries})"
    )
