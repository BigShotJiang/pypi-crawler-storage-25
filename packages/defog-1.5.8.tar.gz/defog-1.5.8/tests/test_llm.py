import unittest
import pytest
import asyncio
import sys
from copy import deepcopy
from types import SimpleNamespace
import uuid
from defog.llm.utils import (
    map_model_to_provider,
    chat_async,
)
from defog.llm.llm_providers import LLMProvider
import re

from pydantic import BaseModel
from tests.conftest import skip_if_no_api_key, skip_if_no_models, AVAILABLE_MODELS

messages_sql = [
    {
        "role": "system",
        "content": "Your task is to generate SQL given a natural language question and schema of the user's database. Do not use aliases. Return only the SQL without ```.",
    },
    {
        "role": "user",
        "content": """Question: What is the total number of orders?
Schema:
```sql
CREATE TABLE orders (
    order_id int,
    customer_id int,
    employee_id int,
    order_date date
);
```
""",
    },
]

acceptable_sql = [
    "select count(*) from orders",
    "select count(order_id) from orders",
    "select count(*) as total_orders from orders",
    "select count(order_id) as total_orders from orders",
]


class ResponseFormat(BaseModel):
    reasoning: str
    sql: str


messages_sql_structured = [
    {
        "role": "system",
        "content": "Your task is to generate SQL given a natural language question and schema of the user's database. Do not use aliases.",
    },
    {
        "role": "user",
        "content": """Question: What is the total number of orders?
Schema:
```sql
CREATE TABLE orders (
    order_id int,
    customer_id int,
    employee_id int,
    order_date date
);
```
""",
    },
]


class TestChatClients(unittest.IsolatedAsyncioTestCase):
    def check_sql(self, sql: str):
        sql = sql.replace("```sql", "").replace("```", "").strip(";\n").lower()
        sql = re.sub(r"(\s+)", " ", sql)
        self.assertIn(sql, acceptable_sql)

    def test_map_model_to_provider(self):
        self.assertEqual(
            map_model_to_provider("claude-haiku-4-5"),
            LLMProvider.ANTHROPIC,
        )

        self.assertEqual(
            map_model_to_provider("gemini-1.5-flash-002"),
            LLMProvider.GEMINI,
        )

        self.assertEqual(map_model_to_provider("gpt-4o-mini"), LLMProvider.OPENAI)
        self.assertEqual(map_model_to_provider("gpt-5.5"), LLMProvider.OPENAI)

        with self.assertRaises(Exception):
            map_model_to_provider("unknown-model")

    @pytest.mark.asyncio(loop_scope="session")
    @skip_if_no_models()
    async def test_simple_chat_async(self):
        # Use a subset of available models for this test
        test_models = []
        if AVAILABLE_MODELS.get("anthropic"):
            test_models.append("claude-haiku-4-5")
        if AVAILABLE_MODELS.get("openai"):
            test_models.extend(["gpt-4.1-mini", "o4-mini", "o3"])
        if AVAILABLE_MODELS.get("gemini"):
            test_models.extend(
                [
                    "gemini-2.5-flash",
                    "gemini-2.5-pro",
                    "gemini-3-flash-preview",
                    "gemini-3-pro-preview",
                    "gemini-3.1-flash-lite-preview",
                    "gemini-3.1-pro-preview",
                ]
            )
        models = [m for m in test_models if m in sum(AVAILABLE_MODELS.values(), [])]
        messages = [
            {"role": "user", "content": "Return a greeting in not more than 2 words\n"}
        ]

        async def test_model(model):
            provider = map_model_to_provider(model)
            response = await chat_async(
                provider=provider,
                model=model,
                messages=messages,
                temperature=0.0,
                max_retries=1,
            )
            self.assertIsInstance(response.content, str)
            self.assertIsInstance(response.time, float)
            return model, response

        # Run all model tests in parallel
        results = await asyncio.gather(*[test_model(model) for model in models])

        # Verify all models completed successfully
        self.assertEqual(len(results), len(models))

    @pytest.mark.asyncio(loop_scope="session")
    @skip_if_no_models()
    async def test_sql_chat_async(self):
        # Use a subset of available models for SQL test
        test_models = []
        if AVAILABLE_MODELS.get("openai"):
            test_models.extend(
                ["gpt-4o-mini", "o3", "o4-mini", "gpt-4.1-mini", "gpt-4.1-nano"]
            )
        if AVAILABLE_MODELS.get("gemini"):
            test_models.extend(
                [
                    "gemini-2.5-flash",
                    "gemini-2.5-pro",
                    "gemini-3-flash-preview",
                    "gemini-3-pro-preview",
                    "gemini-3.1-flash-lite-preview",
                    "gemini-3.1-pro-preview",
                ]
            )

        models = [m for m in test_models if m in sum(AVAILABLE_MODELS.values(), [])]

        async def test_model(model):
            provider = map_model_to_provider(model)
            response = await chat_async(
                provider=provider,
                model=model,
                messages=messages_sql,
                temperature=0.0,
                max_retries=1,
            )
            self.check_sql(response.content)
            self.assertIsInstance(response.time, float)
            return model, response

        # Run all model tests in parallel
        results = await asyncio.gather(*[test_model(model) for model in models])

        # Verify all models completed successfully
        self.assertEqual(len(results), len(models))

    @pytest.mark.asyncio(loop_scope="session")
    @skip_if_no_models()
    async def test_sql_chat_structured_reasoning_effort_async(self):
        # Only test models that support reasoning effort
        test_models = []
        if AVAILABLE_MODELS.get("openai") and "o4-mini" in AVAILABLE_MODELS["openai"]:
            test_models.append("o4-mini")
        if AVAILABLE_MODELS.get("anthropic"):
            if "claude-haiku-4-5" in AVAILABLE_MODELS["anthropic"]:
                test_models.append("claude-haiku-4-5")
            if "claude-sonnet-4-6" in AVAILABLE_MODELS["anthropic"]:
                test_models.append("claude-sonnet-4-6")

        if not test_models:
            self.skipTest("No models with reasoning effort support available")

        reasoning_effort = ["low", "medium", "high", None]

        async def test_model_effort(model, effort):
            provider = map_model_to_provider(model)
            response = await chat_async(
                provider=provider,
                model=model,
                messages=messages_sql_structured,
                temperature=0.0,
                response_format=ResponseFormat,
                reasoning_effort=effort,
                max_retries=1,
            )
            self.check_sql(response.content.sql)
            self.assertIsInstance(response.content.reasoning, str)
            return (model, effort, response)

        # Create all test combinations
        test_tasks = []
        for effort in reasoning_effort:
            for model in test_models:
                test_tasks.append(test_model_effort(model, effort))

        # Run all tests in parallel
        results = await asyncio.gather(*test_tasks)

        # Verify all tests completed successfully
        self.assertEqual(len(results), len(reasoning_effort) * len(test_models))

    @pytest.mark.asyncio(loop_scope="session")
    @skip_if_no_models()
    async def test_sql_chat_structured_async(self):
        # Use a subset of available models for structured output test
        test_models = []
        if AVAILABLE_MODELS.get("openai"):
            test_models.extend(["gpt-4o", "o3", "o4-mini", "gpt-4.1", "gpt-4.1-nano"])
        if AVAILABLE_MODELS.get("gemini"):
            test_models.extend(
                [
                    "gemini-2.5-flash",
                    "gemini-2.5-pro",
                    "gemini-3-flash-preview",
                    "gemini-3-pro-preview",
                    "gemini-3.1-flash-lite-preview",
                    "gemini-3.1-pro-preview",
                ]
            )
        if AVAILABLE_MODELS.get("anthropic"):
            test_models.append("claude-haiku-4-5")

        models = [m for m in test_models if m in sum(AVAILABLE_MODELS.values(), [])]

        async def test_model(model):
            provider = map_model_to_provider(model)
            response = await chat_async(
                provider=provider,
                model=model,
                messages=messages_sql_structured,
                temperature=0.0,
                response_format=ResponseFormat,
                max_retries=1,
            )
            self.check_sql(response.content.sql)
            self.assertIsInstance(response.content.reasoning, str)
            return model, response

        # Run all model tests in parallel
        results = await asyncio.gather(*[test_model(model) for model in models])

        # Verify all models completed successfully
        self.assertEqual(len(results), len(models))

    @skip_if_no_api_key("anthropic")
    async def test_chat_async_conversation_follow_up_with_tools_real(self):
        from defog.llm.memory import conversation_cache

        await conversation_cache.clear_cache()

        async def multiply_numbers(x: float, y: float) -> float:
            """Multiply two numbers via tool call."""
            return x * y

        model = (
            AVAILABLE_MODELS["anthropic"][0]
            if AVAILABLE_MODELS.get("anthropic")
            else "claude-haiku-4-5"
        )

        system_prompt = (
            "You are an assistant that must use available tools when asked. "
            "You have a tool named multiply_numbers for multiplying two numbers."
        )
        initial_messages = [
            {"role": "system", "content": system_prompt},
            {
                "role": "user",
                "content": (
                    "Call the multiply_numbers tool exactly once to multiply 6234 and 42, "
                    "then respond with just the product and nothing else."
                ),
            },
        ]

        response1 = await chat_async(
            provider=LLMProvider.ANTHROPIC,
            model=model,
            messages=initial_messages,
            tools=[multiply_numbers],
            temperature=0.0,
            max_retries=1,
        )

        assert response1.tool_outputs, "expected multiply_numbers tool to be invoked"
        tool_output = response1.tool_outputs[0]
        assert tool_output["name"] == "multiply_numbers"
        assert tool_output["result"] in (261828, 261828.0)
        assert response1.response_id

        cached_first = await conversation_cache.load_messages(response1.response_id)
        assert cached_first is not None
        assert cached_first[-1]["role"] == "assistant"

        follow_up_messages = [
            {
                "role": "user",
                "content": (
                    "Using the product you just computed, multiply the answer by 84."
                    "Reply with the final number only."
                ),
            }
        ]

        response2 = await chat_async(
            provider=LLMProvider.ANTHROPIC,
            model=model,
            messages=follow_up_messages,
            temperature=0.0,
            max_retries=1,
            previous_response_id=response1.response_id,
            tools=[multiply_numbers],
        )

        numbers = re.findall(r"-?\d+", str(response2.content))
        assert numbers, "expected numeric answer in follow-up response"
        assert int(numbers[-1]) == 21993552
        assert response2.tool_outputs, "expected multiply_numbers tool to be invoked"
        tool_output = response2.tool_outputs[0]
        assert tool_output["name"] == "multiply_numbers"
        assert tool_output["result"] in (21993552, 21993552.0)

        cached_second = await conversation_cache.load_messages(response2.response_id)
        assert cached_second is not None
        assert cached_second[-1]["role"] == "assistant"
        assert cached_second[-1]["content"] == response2.content

        await conversation_cache.clear_cache()

    @skip_if_no_api_key("gemini")
    async def test_chat_async_gemini_follow_up_with_tools_real(self):
        from defog.llm.memory import conversation_cache

        await conversation_cache.clear_cache()

        async def multiply_numbers(x: float, y: float) -> float:
            """Multiply two numbers via tool call."""
            return x * y

        model = (
            "gemini-2.5-flash"
            if "gemini-2.5-flash" in AVAILABLE_MODELS.get("gemini", [])
            else AVAILABLE_MODELS["gemini"][0]
        )

        system_prompt = (
            "You are a helpful assistant. Use the multiply_numbers tool whenever a user asks "
            "you to multiply numbers."
        )
        initial_messages = [
            {"role": "system", "content": system_prompt},
            {
                "role": "user",
                "content": (
                    "Invoke multiply_numbers exactly once to multiply 6234 and 42. "
                    "After the tool responds, respond with just the product and nothing else."
                ),
            },
        ]

        response1 = await chat_async(
            provider=LLMProvider.GEMINI,
            model=model,
            messages=initial_messages,
            tools=[multiply_numbers],
            temperature=0.0,
            max_retries=1,
        )

        assert response1.tool_outputs, "expected multiply_numbers tool to be invoked"
        tool_output = response1.tool_outputs[0]
        assert tool_output["name"] == "multiply_numbers"
        assert tool_output["result"] in (261828, 261828.0)
        assert response1.response_id

        # cached_first = conversation_cache.load_messages(response1.response_id)
        # assert cached_first is not None
        # assert cached_first[-1]["role"] == "assistant"

        follow_up_messages = [
            {
                "role": "user",
                "content": (
                    "Using the product you computed, multiply the answer by 84."
                    "Reply with just the final number and nothing else."
                ),
            }
        ]

        response2 = await chat_async(
            provider=LLMProvider.GEMINI,
            model=model,
            messages=follow_up_messages,
            temperature=0.0,
            max_retries=1,
            previous_response_id=response1.response_id,
            tools=[multiply_numbers],
        )

        numbers = re.findall(r"-?\d+", str(response2.content))
        assert numbers, "expected numeric answer in follow-up response"
        assert int(numbers[-1]) == 21993552
        assert response2.tool_outputs, "expected multiply_numbers tool to be invoked"
        tool_output = response2.tool_outputs[0]
        assert tool_output["name"] == "multiply_numbers"
        assert tool_output["result"] in (21993552, 21993552.0)

        # cached_second = await conversation_cache.load_messages(response2.response_id)
        # assert cached_second is not None
        # assert cached_second[-1]["role"] == "assistant"
        # assert cached_second[-1]["content"] == response2.content

        await conversation_cache.clear_cache()

    async def test_chat_async_conversation_follow_up_with_tools_real_grandparent_cache(
        self,
    ):
        from defog.llm.memory import conversation_cache

        await conversation_cache.clear_cache()

        async def multiply_numbers(x: float, y: float) -> float:
            """Multiply two numbers via tool call."""
            return x * y

        model = (
            AVAILABLE_MODELS["anthropic"][0]
            if AVAILABLE_MODELS.get("anthropic")
            else "claude-haiku-4-5"
        )

        system_prompt = (
            "You are an assistant that must use available tools when asked. "
            "You have a tool named multiply_numbers for multiplying two numbers."
        )
        initial_messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": "What is 6234 * 42?"},
        ]

        response1 = await chat_async(
            provider=LLMProvider.ANTHROPIC,
            model=model,
            messages=initial_messages,
            tools=[multiply_numbers],
            temperature=0.0,
            max_retries=1,
        )
        assert response1.response_id is not None
        original_response_id = response1.response_id

        second_messages = [{"role": "user", "content": "Multiply this number by 84"}]
        response2 = await chat_async(
            provider=LLMProvider.ANTHROPIC,
            model=model,
            messages=second_messages,
            tools=[multiply_numbers],
            temperature=0.0,
            max_retries=1,
            previous_response_id=original_response_id,
        )
        second_response_id = response2.response_id
        assert response2.response_id is not None
        assert response2.response_id != original_response_id
        assert response2.tool_outputs is not None
        assert response2.tool_outputs[0]["name"] == "multiply_numbers"
        assert response2.tool_outputs[0]["result"] in (21993552, 21993552.0)

        third_messages = [
            {
                "role": "user",
                "content": "Multiply the result of the *original* question by 7",
            }
        ]
        response3 = await chat_async(
            provider=LLMProvider.ANTHROPIC,
            model=model,
            messages=third_messages,
            previous_response_id=second_response_id,
            tools=[multiply_numbers],
            temperature=0.0,
            max_retries=1,
        )
        print(response3)
        assert response3.response_id is not None
        assert response3.tool_outputs is not None
        assert response3.tool_outputs[0]["name"] == "multiply_numbers"
        assert response3.tool_outputs[0]["result"] in (1832796, 1832796.0)

        await conversation_cache.clear_cache()


@pytest.mark.asyncio
async def test_anthropic_previous_response_uses_conversation_cache(monkeypatch):
    from defog.llm.providers.anthropic_provider import AnthropicProvider
    from defog.llm.memory import conversation_cache

    await conversation_cache.clear_cache()
    provider = AnthropicProvider(api_key="api-key")

    captured_messages = []

    def fake_build_params(self, messages, model, **kwargs):
        captured_messages.append(deepcopy(messages))
        return ({"messages": messages, "model": model}, messages)

    monkeypatch.setattr(AnthropicProvider, "build_params", fake_build_params)

    call_index = {"value": 0}
    assistant_contents = ["First answer", "Second answer"]

    async def fake_process_response(
        self,
        client,
        response,
        request_params,
        tools,
        tool_dict,
        response_format=None,
        post_tool_function=None,
        post_response_hook=None,
        tool_handler=None,
        **kwargs,
    ):
        content = assistant_contents[call_index["value"]]
        call_index["value"] += 1
        return (content, [], 10, 5, 0, 0, None)

    monkeypatch.setattr(AnthropicProvider, "process_response", fake_process_response)

    class FakeAsyncAnthropic:
        def __init__(self, **kwargs):
            self.messages = self

        async def create(self, **kwargs):
            return SimpleNamespace(id=f"anth_{uuid.uuid4().hex}")

    monkeypatch.setitem(
        sys.modules,
        "anthropic",
        SimpleNamespace(AsyncAnthropic=FakeAsyncAnthropic),
    )

    base_messages = [
        {"role": "system", "content": "You are helpful."},
        {"role": "user", "content": "Hello"},
    ]

    try:
        response1 = await provider.execute_chat(
            messages=base_messages,
            model="claude-3-sonnet",
        )
        assert response1.response_id is not None

        cached_first = await conversation_cache.load_messages(response1.response_id)
        assert cached_first == base_messages + [
            {"role": "assistant", "content": "First answer"}
        ]
        assert captured_messages[0] == base_messages

        follow_up = [{"role": "user", "content": "Tell me more"}]

        response2 = await provider.execute_chat(
            messages=follow_up,
            model="claude-3-sonnet",
            previous_response_id=response1.response_id,
        )

        expected_request_messages = base_messages + [
            {"role": "assistant", "content": "First answer"},
            {"role": "user", "content": "Tell me more"},
        ]
        assert captured_messages[1] == expected_request_messages

        cached_second = await conversation_cache.load_messages(response2.response_id)
        assert cached_second == expected_request_messages + [
            {"role": "assistant", "content": "Second answer"}
        ]
    finally:
        await conversation_cache.clear_cache()


@pytest.mark.asyncio
async def test_gemini_previous_response_uses_conversation_cache(monkeypatch):
    from defog.llm.providers.gemini_provider import GeminiProvider
    from defog.llm.memory import conversation_cache

    await conversation_cache.clear_cache()
    provider = GeminiProvider(api_key="api-key")

    captured_messages = []

    def fake_build_params(self, messages, model, **kwargs):
        captured_messages.append(deepcopy(messages))
        return ({"temperature": 0.0}, [["placeholder"]])

    monkeypatch.setattr(GeminiProvider, "build_params", fake_build_params)

    call_index = {"value": 0}
    assistant_contents = ["Gemini first", "Gemini second"]

    async def fake_process_response(
        self,
        client,
        response,
        request_params,
        messages,
        tools,
        tool_dict,
        response_format=None,
        model: str = "",
        post_tool_function=None,
        post_response_hook=None,
        tool_handler=None,
        **kwargs,
    ):
        content = assistant_contents[call_index["value"]]
        call_index["value"] += 1
        return (content, [], 8, 4, None, None)

    monkeypatch.setattr(GeminiProvider, "process_response", fake_process_response)

    class FakeGeminiClient:
        def __init__(self, **kwargs):
            self.aio = SimpleNamespace(interactions=self)

        async def create(self, **kwargs):
            return SimpleNamespace(id=f"gem_{uuid.uuid4().hex}")

    monkeypatch.setattr(
        "defog.llm.providers.gemini_provider.genai.Client", FakeGeminiClient
    )
    monkeypatch.setattr(
        "defog.llm.providers.gemini_provider.types.GenerationConfig",
        lambda **kwargs: kwargs,
    )

    base_messages = [
        {"role": "system", "content": "You are Gemini."},
        {"role": "user", "content": "Hi"},
    ]

    try:
        response1 = await provider.execute_chat(
            messages=base_messages,
            model="gemini-1.5-flash",
        )
        assert response1.response_id is not None

        # cached_first = await conversation_cache.load_messages(response1.response_id)
        # assert cached_first == base_messages + [
        #     {"role": "assistant", "content": "Gemini first"}
        # ]
        assert captured_messages[0] == base_messages

        follow_up = [{"role": "user", "content": "Any other info?"}]

        response2 = await provider.execute_chat(
            messages=follow_up,
            model="gemini-1.5-flash",
            previous_response_id=response1.response_id,
        )

        # Gemini provider with Interactions API only sends new messages
        expected_request_messages = follow_up
        assert captured_messages[1] == expected_request_messages

        # cached_second = await conversation_cache.load_messages(response2.response_id)
        # assert cached_second == expected_request_messages + [
        #     {"role": "assistant", "content": "Gemini second"}
        # ]
    finally:
        await conversation_cache.clear_cache()


class TestGeminiSystemInstruction:
    """Test that system messages are extracted into system_instruction."""

    def test_system_message_extracted_from_interactions_input(self):
        """System messages should be returned as system_instruction, not as user turns."""
        from defog.llm.providers.gemini_provider import GeminiProvider

        provider = GeminiProvider(api_key="test-key")
        messages = [
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": "Hello"},
        ]

        system_instruction, input_contents = provider._messages_to_interactions_input(
            messages
        )

        assert system_instruction == "You are a helpful assistant."
        assert len(input_contents) == 1
        assert input_contents[0]["role"] == "user"

    def test_multiple_system_messages_concatenated(self):
        """Multiple system messages should be joined with double newlines."""
        from defog.llm.providers.gemini_provider import GeminiProvider

        provider = GeminiProvider(api_key="test-key")
        messages = [
            {"role": "system", "content": "Instruction 1."},
            {"role": "system", "content": "Instruction 2."},
            {"role": "user", "content": "Hello"},
        ]

        system_instruction, input_contents = provider._messages_to_interactions_input(
            messages
        )

        assert system_instruction == "Instruction 1.\n\nInstruction 2."
        assert len(input_contents) == 1

    def test_no_system_messages_returns_none(self):
        """When there are no system messages, system_instruction should be None."""
        from defog.llm.providers.gemini_provider import GeminiProvider

        provider = GeminiProvider(api_key="test-key")
        messages = [
            {"role": "user", "content": "Hello"},
            {"role": "assistant", "content": "Hi there"},
        ]

        system_instruction, input_contents = provider._messages_to_interactions_input(
            messages
        )

        assert system_instruction is None
        assert len(input_contents) == 2

    def test_system_instruction_in_build_params(self):
        """build_params should include system_instruction in request_params."""
        from defog.llm.providers.gemini_provider import GeminiProvider

        provider = GeminiProvider(api_key="test-key")
        messages = [
            {"role": "system", "content": "Be concise."},
            {"role": "user", "content": "What is 2+2?"},
        ]

        request_params, _ = provider.build_params(
            messages=messages,
            model="gemini-2.5-flash",
        )

        assert request_params["system_instruction"] == "Be concise."
        # Ensure no user turn was created for the system message
        assert len(request_params["input"]) == 1
        assert request_params["input"][0]["role"] == "user"

    def test_no_system_instruction_when_no_system_messages(self):
        """build_params should omit system_instruction when there are no system messages."""
        from defog.llm.providers.gemini_provider import GeminiProvider

        provider = GeminiProvider(api_key="test-key")
        messages = [
            {"role": "user", "content": "Hello"},
        ]

        request_params, _ = provider.build_params(
            messages=messages,
            model="gemini-2.5-flash",
        )

        assert "system_instruction" not in request_params

    def test_no_consecutive_user_turns_with_system_message(self):
        """System + user messages should not produce consecutive user turns."""
        from defog.llm.providers.gemini_provider import GeminiProvider

        provider = GeminiProvider(api_key="test-key")
        messages = [
            {"role": "system", "content": "System prompt"},
            {"role": "user", "content": "User message"},
        ]

        _, input_contents = provider._messages_to_interactions_input(messages)

        # Should have exactly 1 turn (the user message), not 2 consecutive user turns
        assert len(input_contents) == 1
        assert input_contents[0]["role"] == "user"

    def test_system_message_with_list_content(self):
        """System messages with list content should be handled correctly."""
        from defog.llm.providers.gemini_provider import GeminiProvider

        provider = GeminiProvider(api_key="test-key")
        messages = [
            {
                "role": "system",
                "content": [
                    {"type": "text", "text": "First instruction."},
                    {"type": "text", "text": "Second instruction."},
                ],
            },
            {"role": "user", "content": "Hello"},
        ]

        system_instruction, input_contents = provider._messages_to_interactions_input(
            messages
        )

        assert system_instruction == "First instruction.\n\nSecond instruction."
        assert len(input_contents) == 1
