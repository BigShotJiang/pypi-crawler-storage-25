# pyright: reportAssignmentType=false

from __future__ import annotations

from enum import StrEnum
from typing import Annotated, Any

from pydantic import AwareDatetime, BaseModel, ConfigDict, EmailStr, Field, RootModel


class AssetsOptions(BaseModel):
    model_config = ConfigDict(
        extra="forbid",
    )
    name: Annotated[str, Field(title="Name")] = "US Dollar Notes"
    asset_id: Annotated[str | None, Field(title="Asset Id")] = (
        "rgb:$i4cFKwt-2C5LZ3X-l$kOTGN-O6l1AOP-aP9COyn-7IeBkEM"
    )
    ticker: Annotated[str, Field(title="Ticker")] = "USDT"
    precision: Annotated[int, Field(title="Precision")] = 6
    issued_supply: Annotated[int, Field(title="Issued Supply")] = 0
    min_initial_client_amount: Annotated[int, Field(ge=0, title="Min Initial Client Amount")] = 0
    max_initial_client_amount: Annotated[int, Field(ge=0, title="Max Initial Client Amount")] = 0
    min_initial_lsp_amount: Annotated[int, Field(ge=0, title="Min Initial Lsp Amount")] = 0
    max_initial_lsp_amount: Annotated[int, Field(ge=0, title="Max Initial Lsp Amount")] = 10000
    min_channel_amount: Annotated[int, Field(ge=0, title="Min Channel Amount")] = 0
    max_channel_amount: Annotated[int, Field(ge=0, title="Max Channel Amount")] = 10000


class BitcoinNetwork(StrEnum):
    MAINNET = "Mainnet"
    TESTNET = "Testnet"
    TESTNET4 = "Testnet4"
    SIGNET = "Signet"
    REGTEST = "Regtest"


class ChannelDetails(BaseModel):
    channel_id: Annotated[str | None, Field(title="Channel Id")] = None
    temporary_channel_id: Annotated[str | None, Field(title="Temporary Channel Id")] = None
    funded_at: Annotated[AwareDatetime | None, Field(title="Funded At")] = None
    funding_outpoint: Annotated[str | None, Field(title="Funding Outpoint")] = None
    expires_at: Annotated[AwareDatetime | None, Field(title="Expires At")] = None


class ConfirmSwapRequest(BaseModel):
    swapstring: Annotated[
        str,
        Field(
            examples=[
                "30/rgb:2dkSTbr-jFhznbPmo-TQafzswCN-av4gTsJjX-ttx6CNou5-M98k8Zd/10/rgb:2eVw8uw-8G88LQ2tQ-kexM12SoD-nCX8DmQrw-yLMu6JDfK-xx1SCfc/1715896416/9d342c6ba006e24abee84a2e034a22d5e30c1f2599fb9c3574d46d3cde3d65a2"
            ],
            title="Swapstring",
        ),
    ]
    taker_pubkey: Annotated[
        str,
        Field(
            examples=["034eedc97802d7e2766704bd06d6bfded8aa2d35a1a007e277fd7278f3dc962706"],
            title="Taker Pubkey",
        ),
    ]
    payment_hash: Annotated[
        str,
        Field(
            examples=["9d342c6ba006e24abee84a2e034a22d5e30c1f2599fb9c3574d46d3cde3d65a2"],
            title="Payment Hash",
        ),
    ]


class ConfirmSwapResponse(BaseModel):
    status: Annotated[int, Field(examples=[200], title="Status")]
    message: Annotated[str, Field(examples=["Swap executed successfully."], title="Message")]


class CreateOrderRequest(BaseModel):
    client_pubkey: Annotated[str, Field(title="Client Pubkey")]
    lsp_balance_sat: Annotated[int, Field(ge=0, title="Lsp Balance Sat")]
    client_balance_sat: Annotated[int, Field(ge=0, title="Client Balance Sat")]
    required_channel_confirmations: Annotated[
        int, Field(ge=0, title="Required Channel Confirmations")
    ]
    funding_confirms_within_blocks: Annotated[
        int, Field(ge=1, title="Funding Confirms Within Blocks")
    ]
    channel_expiry_blocks: Annotated[int, Field(ge=1, title="Channel Expiry Blocks")]
    token: Annotated[str | None, Field(title="Token")] = None
    refund_onchain_address: Annotated[str | None, Field(title="Refund Onchain Address")] = None
    announce_channel: Annotated[bool, Field(title="Announce Channel")] = True
    asset_id: Annotated[str | None, Field(title="Asset Id")] = None
    lsp_asset_amount: Annotated[int | None, Field(title="Lsp Asset Amount")] = None
    client_asset_amount: Annotated[int | None, Field(title="Client Asset Amount")] = None
    rfq_id: Annotated[str | None, Field(title="Rfq Id")] = None
    email: Annotated[
        str | None, Field(description="Optional email for notifications", title="Email")
    ] = None


class DetailOnlyErrorResponse(BaseModel):
    detail: Annotated[
        str,
        Field(
            description="Human-readable error detail",
            examples=["pair_ticker must be in format 'BASE/QUOTE'"],
            title="Detail",
        ),
    ]


class EstimateFeesRequest(BaseModel):
    """
    Request model for estimating channel fees
    """

    lsp_balance_sat: Annotated[int, Field(ge=0, title="Lsp Balance Sat")]
    client_balance_sat: Annotated[int, Field(ge=0, title="Client Balance Sat")]
    channel_expiry_blocks: Annotated[int, Field(ge=1, title="Channel Expiry Blocks")]
    token: Annotated[str | None, Field(title="Token")] = None
    asset_id: Annotated[str | None, Field(title="Asset Id")] = None
    lsp_asset_amount: Annotated[int | None, Field(title="Lsp Asset Amount")] = None
    client_asset_amount: Annotated[int | None, Field(title="Client Asset Amount")] = None
    rfq_id: Annotated[str | None, Field(title="Rfq Id")] = None


class AppliedDiscount(RootModel[float]):
    root: Annotated[float, Field(ge=0.0, le=1.0, title="Applied Discount")]


class EstimateFeesResponse(BaseModel):
    """
    Response model for LSPS1 fee estimation
    """

    setup_fee: Annotated[int, Field(ge=0, title="Setup Fee")]
    capacity_fee: Annotated[int, Field(ge=0, title="Capacity Fee")]
    duration_fee: Annotated[int, Field(ge=0, title="Duration Fee")]
    total_fee: Annotated[int, Field(ge=0, title="Total Fee")]
    applied_discount: Annotated[AppliedDiscount | None, Field(title="Applied Discount")] = None
    discount_code: Annotated[str | None, Field(title="Discount Code")] = None


class Fee(BaseModel):
    base_fee: Annotated[int, Field(examples=[1000000], title="Base Fee")]
    variable_fee: Annotated[int, Field(examples=[1000000], title="Variable Fee")]
    fee_rate: Annotated[float, Field(examples=[0.0001], title="Fee Rate")]
    final_fee: Annotated[int, Field(examples=[2000000], title="Final Fee")]
    fee_asset: Annotated[
        str,
        Field(
            examples=["rgb:2dkSTbr-jFhznbPmo-TQafzswCN-av4gTsJjX-ttx6CNou5-M98k8Zd"],
            title="Fee Asset",
        ),
    ]
    fee_asset_precision: Annotated[int, Field(examples=[6], title="Fee Asset Precision")]


class KaleidoErrorResponse(BaseModel):
    error_code: Annotated[
        str,
        Field(
            description="Stable machine-readable application error code",
            examples=["PAIR_NOT_FOUND"],
            title="Error Code",
        ),
    ]
    message: Annotated[
        str,
        Field(
            description="Human-readable error message",
            examples=["Trading pair not found: BTC/USDT"],
            title="Message",
        ),
    ]
    details: Annotated[
        dict[str, Any] | None,
        Field(description="Optional structured error details", title="Details"),
    ] = None
    request_id: Annotated[
        str,
        Field(
            description="Request correlation identifier for support and debugging",
            examples=["req_01HV8Q9X7G0Q7Y3Z"],
            title="Request Id",
        ),
    ]


class Layer(StrEnum):
    """
    Settlement layer combining protocol and network as a single string.

    Format: PROTOCOL/NETWORK

    Each layer represents a valid combination where assets can exist and be transacted.
    The layer encodes both WHAT protocol the asset uses and WHERE it settles.
    """

    BTC_L1 = "BTC_L1"
    BTC_LN = "BTC_LN"
    BTC_SPARK = "BTC_SPARK"
    BTC_ARKADE = "BTC_ARKADE"
    BTC_LIQUID = "BTC_LIQUID"
    BTC_CASHU = "BTC_CASHU"
    RGB_L1 = "RGB_L1"
    RGB_LN = "RGB_LN"
    TAPASS_L1 = "TAPASS_L1"
    TAPASS_LN = "TAPASS_LN"
    LIQUID_LIQUID = "LIQUID_LIQUID"
    ARKADE_ARKADE = "ARKADE_ARKADE"
    SPARK_SPARK = "SPARK_SPARK"


class Media(BaseModel):
    file_path: Annotated[str, Field(examples=["/path/to/media"], title="File Path")]
    digest: Annotated[
        str,
        Field(
            examples=["5891b5b522d5df086d0ff0b110fbd9d21bb4fc7163af34d08286a2e846f6be03"],
            title="Digest",
        ),
    ]
    mime: Annotated[str, Field(examples=["text/plain"], title="Mime")]


class NetworkInfoResponse(BaseModel):
    network: BitcoinNetwork
    height: Annotated[int, Field(examples=[805434], title="Height")]


class MinOnchainPaymentConfirmations(RootModel[int]):
    root: Annotated[int, Field(ge=0, title="Min Onchain Payment Confirmations")]


class MinOnchainPaymentSizeSat(RootModel[int]):
    root: Annotated[int, Field(ge=0, title="Min Onchain Payment Size Sat")]


class OrderOptions(BaseModel):
    model_config = ConfigDict(
        extra="forbid",
    )
    min_required_channel_confirmations: Annotated[
        int, Field(ge=0, title="Min Required Channel Confirmations")
    ] = 0
    min_funding_confirms_within_blocks: Annotated[
        int, Field(ge=0, title="Min Funding Confirms Within Blocks")
    ] = 0
    min_onchain_payment_confirmations: Annotated[
        MinOnchainPaymentConfirmations | None, Field(title="Min Onchain Payment Confirmations")
    ] = None
    supports_zero_channel_reserve: Annotated[bool, Field(title="Supports Zero Channel Reserve")] = (
        True
    )
    min_onchain_payment_size_sat: Annotated[
        MinOnchainPaymentSizeSat | None, Field(title="Min Onchain Payment Size Sat")
    ] = None
    max_channel_expiry_blocks: Annotated[int, Field(ge=1, title="Max Channel Expiry Blocks")] = (
        20160
    )
    min_initial_client_balance_sat: Annotated[
        int, Field(ge=0, title="Min Initial Client Balance Sat")
    ] = 0
    max_initial_client_balance_sat: Annotated[
        int, Field(ge=0, title="Max Initial Client Balance Sat")
    ] = 1000000
    min_initial_lsp_balance_sat: Annotated[
        int, Field(ge=0, title="Min Initial Lsp Balance Sat")
    ] = 0
    max_initial_lsp_balance_sat: Annotated[
        int, Field(ge=0, title="Max Initial Lsp Balance Sat")
    ] = 16777215
    min_channel_balance_sat: Annotated[int, Field(ge=0, title="Min Channel Balance Sat")] = 50000
    max_channel_balance_sat: Annotated[int, Field(ge=0, title="Max Channel Balance Sat")] = 16777215


class OrderRequest(BaseModel):
    order_id: Annotated[str, Field(title="Order Id")]
    access_token: Annotated[str, Field(title="Access Token")] = ""


class OrderState(StrEnum):
    CREATED = "CREATED"
    CHANNEL_OPENING = "CHANNEL_OPENING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    PENDING_RATE_DECISION = "PENDING_RATE_DECISION"


class OrderStatsResponse(BaseModel):
    status_counts: Annotated[
        dict[str, int], Field(description="Count of orders by status", title="Status Counts")
    ]
    filled_orders_volume: Annotated[
        int, Field(description="Total volume of filled orders", title="Filled Orders Volume")
    ]
    filled_orders_count: Annotated[
        int, Field(description="Total count of filled orders", title="Filled Orders Count")
    ]


class PaginationMeta(BaseModel):
    """
    Pagination metadata
    """

    total: Annotated[
        int, Field(description="Total number of items matching the filter", title="Total")
    ]
    limit: Annotated[int, Field(description="Number of items per page", title="Limit")]
    skip: Annotated[int, Field(description="Number of items skipped", title="Skip")]
    current_page: Annotated[
        int, Field(description="Current page number (1-indexed)", title="Current Page")
    ]
    total_pages: Annotated[int, Field(description="Total number of pages", title="Total Pages")]
    has_next: Annotated[bool, Field(description="Whether there is a next page", title="Has Next")]
    has_previous: Annotated[
        bool, Field(description="Whether there is a previous page", title="Has Previous")
    ]


class PairRoutesRequest(BaseModel):
    pair_id: Annotated[str | None, Field(title="Pair Id")] = None
    from_asset_id: Annotated[str | None, Field(title="From Asset Id")] = None
    quote_asset_id: Annotated[str | None, Field(title="Quote Asset Id")] = None
    pair_ticker: Annotated[str | None, Field(title="Pair Ticker")] = None
    base_ticker: Annotated[str | None, Field(title="Base Ticker")] = None
    quote_ticker: Annotated[str | None, Field(title="Quote Ticker")] = None


class PaymentState(StrEnum):
    EXPECT_PAYMENT = "EXPECT_PAYMENT"
    HOLD = "HOLD"
    PAID = "PAID"
    REFUNDED = "REFUNDED"
    TO_REFUND = "TO_REFUND"


class PaymentStatus(StrEnum):
    """
    Payment status for onchain payments with support for partial payments.
    """

    NOT_PAID = "NOT_PAID"
    UNDERPAID = "UNDERPAID"
    PAID = "PAID"
    OVERPAID = "OVERPAID"


class RateDecisionRequest(BaseModel):
    """
    Request for user to accept new rate or request refund
    """

    order_id: Annotated[str, Field(title="Order Id")]
    access_token: Annotated[str, Field(title="Access Token")] = ""
    accept_new_rate: Annotated[bool, Field(title="Accept New Rate")]


class RateDecisionResponse(BaseModel):
    """
    Response after user makes rate decision
    """

    order_id: Annotated[str, Field(title="Order Id")]
    decision_accepted: Annotated[bool, Field(title="Decision Accepted")]
    message: Annotated[str, Field(title="Message")]
    refund_txid: Annotated[str | None, Field(title="Refund Txid")] = None


class ReachabilityCell(BaseModel):
    """
    Single cell in reachability matrix.
    """

    from_asset: Annotated[str, Field(description="Source asset ticker", title="From Asset")]
    to_asset: Annotated[str, Field(description="Destination asset ticker", title="To Asset")]
    layers: Annotated[
        list[str],
        Field(
            description="Available layer combinations (e.g., 'RGB_LN->BTC_SPARK')", title="Layers"
        ),
    ]
    min_hops: Annotated[int, Field(description="Minimum number of hops required", title="Min Hops")]


class ReachabilityMatrixResponse(BaseModel):
    """
    Full reachability matrix response.
    """

    matrix: Annotated[
        list[ReachabilityCell], Field(description="Reachability cells", title="Matrix")
    ]
    assets: Annotated[list[str], Field(description="All assets in the matrix", title="Assets")]
    timestamp: Annotated[int, Field(description="Response timestamp", title="Timestamp")]


class ReceiverAddressFormat(StrEnum):
    """
    Supported receiver address and invoice formats.

    Different networks and protocols use different address/invoice formats
    for receiving payments.
    """

    BTC_ADDRESS = "BTC_ADDRESS"
    BOLT11 = "BOLT11"
    BOLT12 = "BOLT12"
    LN_ADDRESS = "LN_ADDRESS"
    RGB_INVOICE = "RGB_INVOICE"
    LIQUID_ADDRESS = "LIQUID_ADDRESS"
    LIQUID_INVOICE = "LIQUID_INVOICE"
    SPARK_ADDRESS = "SPARK_ADDRESS"
    SPARK_INVOICE = "SPARK_INVOICE"
    ARKADE_ADDRESS = "ARKADE_ADDRESS"
    ARKADE_INVOICE = "ARKADE_INVOICE"
    CASHU_TOKEN = "CASHU_TOKEN"


class IndicativePrice(RootModel[str]):
    model_config = ConfigDict(
        regex_engine="python-re",
    )
    root: Annotated[
        str,
        Field(
            description="Indicative price from cached pair data",
            pattern="^(?!^[-+.]*$)[+-]?0*\\d*\\.?\\d*$",
            title="Indicative Price",
        ),
    ]


class RouteStep(BaseModel):
    """
    Single step in a route (one swap within a trading pair).
    """

    from_asset: Annotated[str, Field(description="Source asset ticker", title="From Asset")]
    from_layer: Annotated[Layer, Field(description="Source layer")]
    to_asset: Annotated[str, Field(description="Destination asset ticker", title="To Asset")]
    to_layer: Annotated[Layer, Field(description="Destination layer")]
    pair_ticker: Annotated[
        str, Field(description="Trading pair ticker (e.g., 'USDT/BTC')", title="Pair Ticker")
    ]
    indicative_price: Annotated[
        IndicativePrice | None,
        Field(description="Indicative price from cached pair data", title="Indicative Price"),
    ] = None


class RoutesRequest(BaseModel):
    """
    Request for route discovery.
    """

    from_asset: Annotated[str, Field(description="Source asset ticker or ID", title="From Asset")]
    from_layer: Annotated[Layer | None, Field(description="Filter by source layer (optional)")] = (
        None
    )
    to_asset: Annotated[
        str | None,
        Field(
            description="Destination asset (if None, returns all reachable assets)",
            title="To Asset",
        ),
    ] = None
    to_layer: Annotated[
        Layer | None, Field(description="Filter by destination layer (optional)")
    ] = None
    max_hops: Annotated[
        int, Field(description="Maximum number of hops (1-5)", ge=1, le=5, title="Max Hops")
    ] = 2


class SwapLeg(BaseModel):
    """
    Swap Leg: Complete asset specification for one side of a swap.

    Represents a specific asset on a specific settlement layer with an amount.
    This is the fundamental unit for swap orders - each side (leg) of a swap
    specifies an asset on a particular network with a specific amount.
    """

    asset_id: Annotated[
        str,
        Field(
            description="Unique identifier for the asset (e.g., 'BTC', RGB contract ID, etc.)",
            title="Asset Id",
        ),
    ]
    name: Annotated[
        str, Field(description="Full name of the asset", examples=["Bitcoin"], title="Name")
    ]
    ticker: Annotated[
        str,
        Field(
            description="Asset ticker symbol for display (e.g., 'BTC', 'USDT', 'EURX')",
            examples=["BTC"],
            title="Ticker",
        ),
    ]
    layer: Annotated[Layer, Field(description="Settlement layer (e.g., 'BTC_LN', 'RGB_L1')")]
    amount: Annotated[
        int,
        Field(
            description="Amount of the asset in smallest unit. Must be greater than or equal to zero.",
            examples=[100000],
            ge=0,
            title="Amount",
        ),
    ]
    precision: Annotated[
        int,
        Field(
            description="Number of decimal places for this asset (e.g., 8 for BTC, 6 or 8 for stablecoins)",
            examples=[8],
            ge=0,
            le=18,
            title="Precision",
        ),
    ]


class SwapLegInput(BaseModel):
    """
    Lightweight input model for specifying one leg of a swap request.

    Only contains the fields the client needs to provide. The service will
    look up additional details (name, ticker, precision) from the asset registry.
    """

    asset_id: Annotated[
        str,
        Field(
            description="Asset identifier (e.g., 'BTC', RGB contract ID)",
            examples=["BTC"],
            title="Asset Id",
        ),
    ]
    layer: Annotated[
        Layer, Field(description="Settlement layer (e.g., 'BTC_LN', 'RGB_L1')", examples=["BTC_LN"])
    ]
    amount: Annotated[
        int | None,
        Field(
            description="Amount in smallest unit (optional - one side must have amount)",
            examples=[1000000],
            title="Amount",
        ),
    ] = None


class SwapNodeInfoResponse(BaseModel):
    pubkey: Annotated[
        str | None,
        Field(
            examples=["034eedc97802d7e2766704bd06d6bfded8aa2d35a1a007e277fd7278f3dc962706"],
            title="Pubkey",
        ),
    ]
    network: Annotated[str | None, Field(examples=["Signet"], title="Network")]
    block_height: Annotated[int | None, Field(examples=[805434], title="Block Height")]


class SwapOrderRateDecisionRequest(BaseModel):
    """
    Request for user to accept new rate or request refund for a swap order
    """

    order_id: Annotated[str, Field(description="Swap order ID", title="Order Id")]
    access_token: Annotated[
        str, Field(description="Per-order access token", title="Access Token")
    ] = ""
    accept_new_rate: Annotated[
        bool,
        Field(
            description="True to accept new rate, False to request refund", title="Accept New Rate"
        ),
    ]


class SwapOrderRateDecisionResponse(BaseModel):
    """
    Response after user makes rate decision for a swap order
    """

    order_id: Annotated[str, Field(title="Order Id")]
    decision_accepted: Annotated[bool, Field(title="Decision Accepted")]
    message: Annotated[str, Field(title="Message")]
    refund_txid: Annotated[
        str | None,
        Field(description="Present if refund was requested and processed", title="Refund Txid"),
    ] = None


class SwapOrderStatus(StrEnum):
    OPEN = "OPEN"
    PENDING_PAYMENT = "PENDING_PAYMENT"
    PAID = "PAID"
    EXECUTING = "EXECUTING"
    FILLED = "FILLED"
    CANCELLED = "CANCELLED"
    EXPIRED = "EXPIRED"
    FAILED = "FAILED"
    PENDING_RATE_DECISION = "PENDING_RATE_DECISION"


class SwapOrderStatusRequest(BaseModel):
    order_id: Annotated[str, Field(title="Order Id")]
    access_token: Annotated[str, Field(title="Access Token")] = ""


class SwapRequest(BaseModel):
    rfq_id: Annotated[str, Field(examples=["1234567890"], title="Rfq Id")]
    from_asset: Annotated[str, Field(examples=["BTC"], title="From Asset")]
    from_amount: Annotated[int, Field(examples=[1000000], title="From Amount")]
    to_asset: Annotated[
        str,
        Field(
            examples=["rgb:2dkSTbr-jFhznbPmo-TQafzswCN-av4gTsJjX-ttx6CNou5-M98k8Zd"],
            title="To Asset",
        ),
    ]
    to_amount: Annotated[int, Field(examples=[1000000], title="To Amount")]


class SwapResponse(BaseModel):
    swapstring: Annotated[
        str,
        Field(
            examples=[
                "30/rgb:2dkSTbr-jFhznbPmo-TQafzswCN-av4gTsJjX-ttx6CNou5-M98k8Zd/10/rgb:2eVw8uw-8G88LQ2tQ-kexM12SoD-nCX8DmQrw-yLMu6JDfK-xx1SCfc/1715896416/9d342c6ba006e24abee84a2e034a22d5e30c1f2599fb9c3574d46d3cde3d65a2"
            ],
            title="Swapstring",
        ),
    ]
    payment_hash: Annotated[
        str,
        Field(
            examples=["9d342c6ba006e24abee84a2e034a22d5e30c1f2599fb9c3574d46d3cde3d65a2"],
            title="Payment Hash",
        ),
    ]


class SwapRoute(BaseModel):
    """
    Pre-computed valid swap route between two layers.

    Represents a specific path for swapping: from_layer -> to_layer.
    Frozen for immutability and hashability (enables use in sets, dict keys).
    """

    from_layer: str
    to_layer: str


class SwapStatus(StrEnum):
    WAITING = "Waiting"
    PENDING = "Pending"
    SUCCEEDED = "Succeeded"
    EXPIRED = "Expired"
    FAILED = "Failed"


class SwapStatusRequest(BaseModel):
    payment_hash: Annotated[
        str,
        Field(
            examples=["9d342c6ba006e24abee84a2e034a22d5e30c1f2599fb9c3574d46d3cde3d65a2"],
            title="Payment Hash",
        ),
    ]


class TradingLimits(BaseModel):
    """
    Trading limits for a layer.

    Combines a Layer (protocol/network) with min/max amount limits for trading.
    """

    layer: Annotated[str, Field(description="Settlement layer (e.g., 'BTC_LN', 'RGB_LN')")]
    min_amount: Annotated[
        int, Field(description="Minimum amount for trading (in smallest unit)", title="Min Amount")
    ]
    max_amount: Annotated[
        int, Field(description="Maximum amount for trading (in smallest unit)", title="Max Amount")
    ]
    is_active: Annotated[
        bool, Field(description="Whether this layer is active for trading", title="Is Active")
    ] = True


class Price(RootModel[str]):
    model_config = ConfigDict(
        regex_engine="python-re",
    )
    root: Annotated[str, Field(pattern="^(?!^[-+.]*$)[+-]?0*\\d*\\.?\\d*$", title="Price")]


class ValidationError(BaseModel):
    loc: Annotated[list[str | int], Field(title="Location")]
    msg: Annotated[str, Field(title="Message")]
    type: Annotated[str, Field(title="Error Type")]
    input: Annotated[Any | None, Field(title="Input")] = None
    ctx: Annotated[dict[str, Any] | None, Field(title="Context")] = None


class ValidationErrorDetail(BaseModel):
    loc: Annotated[
        list[str | int],
        Field(
            description="Location of the validation failure",
            examples=[["body", "rfq_id"]],
            title="Loc",
        ),
    ]
    msg: Annotated[
        str, Field(description="Validation error message", examples=["Field required"], title="Msg")
    ]
    type: Annotated[
        str,
        Field(
            description="FastAPI/Pydantic validation error type", examples=["missing"], title="Type"
        ),
    ]


class AssetResponseModel(BaseModel):
    """
    API response model for assets.
    """

    ticker: Annotated[str, Field(title="Ticker")]
    asset_id: Annotated[str, Field(title="Asset Id")]
    name: Annotated[str, Field(title="Name")]
    precision: Annotated[int, Field(title="Precision")]
    protocol_ids: Annotated[dict[str, str], Field(title="Protocol Ids")]
    media: Media | None = None
    issued_supply: Annotated[int | None, Field(title="Issued Supply")] = None
    timestamp: Annotated[int | None, Field(title="Timestamp")] = None
    endpoints: Annotated[list[TradingLimits] | None, Field(title="Endpoints")] = None
    is_active: Annotated[bool, Field(title="Is Active")] = True
    added_at: Annotated[int | None, Field(title="Added At")] = None
    supported_layers: Annotated[list[str] | None, Field(title="Supported Layers")] = None


class AssetsResponse(BaseModel):
    """
    Response model for asset listing endpoints with pagination support.
    """

    assets: Annotated[list[AssetResponseModel], Field(title="Assets")]
    network: Annotated[str, Field(title="Network")] = "regtest"
    total: Annotated[int, Field(title="Total")]
    limit: Annotated[int, Field(title="Limit")]
    offset: Annotated[int, Field(title="Offset")]
    timestamp: Annotated[int | None, Field(title="Timestamp")] = None


class FastAPIValidationErrorResponse(BaseModel):
    detail: Annotated[list[ValidationErrorDetail], Field(title="Detail")]


class HTTPValidationError(BaseModel):
    detail: Annotated[list[ValidationError] | None, Field(title="Detail")] = None


class LspInfoResponse(BaseModel):
    lsp_connection_url: Annotated[str, Field(title="Lsp Connection Url")]
    options: OrderOptions
    assets: Annotated[list[AssetsOptions], Field(title="Assets")]


class MultiHopRoute(BaseModel):
    """
    Complete route with one or more steps.
    """

    steps: Annotated[
        list[RouteStep], Field(description="Ordered list of route steps", title="Steps")
    ]
    total_hops: Annotated[int, Field(description="Number of hops in the route", title="Total Hops")]


class OrderHistorySummary(BaseModel):
    """
    Simplified order information for history listing
    """

    id: Annotated[str, Field(description="Order ID", title="Id")]
    status: Annotated[SwapOrderStatus, Field(description="Order status")]
    from_asset: Annotated[str, Field(description="Asset being swapped from", title="From Asset")]
    from_amount: Annotated[int, Field(description="Amount of from_asset", title="From Amount")]
    to_asset: Annotated[str, Field(description="Asset being swapped to", title="To Asset")]
    to_amount: Annotated[int, Field(description="Amount of to_asset", title="To Amount")]
    created_at: Annotated[int, Field(description="Order creation timestamp", title="Created At")]
    filled_at: Annotated[
        int | None, Field(description="Order completion timestamp", title="Filled At")
    ] = None


class PairQuoteRequest(BaseModel):
    """
    Request for a quote on a trading pair using SwapLegInput.
    """

    from_asset: Annotated[
        SwapLegInput, Field(description="Source leg specification (asset_id, layer, amount)")
    ]
    to_asset: Annotated[
        SwapLegInput, Field(description="Destination leg specification (asset_id, layer, amount)")
    ]


class PairQuoteResponse(BaseModel):
    """
    Response containing a quote for a trading pair.

    Uses full SwapLeg for both sides, providing complete asset details
    including ticker, name, precision, layer, and amount.
    """

    rfq_id: Annotated[str, Field(examples=["1234567890"], title="Rfq Id")]
    from_asset: Annotated[
        SwapLeg, Field(description="Complete source leg specification with amount and details")
    ]
    to_asset: Annotated[
        SwapLeg, Field(description="Complete destination leg specification with amount and details")
    ]
    price: Annotated[
        int,
        Field(
            description="Price of 1 whole unit of from_asset (e.g., 1 BTC) in terms of the smallest unit of to_asset (e.g., USDT with precision 6). Matches PriceData.price for the given rfq_id.",
            examples=[50000123456],
            title="Price",
        ),
    ]
    fee: Fee
    timestamp: Annotated[
        int, Field(description="Quote creation timestamp (seconds since epoch)", title="Timestamp")
    ]
    expires_at: Annotated[
        int, Field(description="Quote expiry timestamp (seconds since epoch)", title="Expires At")
    ]


class PairRoutesResponse(BaseModel):
    routes: Annotated[list[SwapRoute], Field(title="Routes")]


class PaymentBolt11(BaseModel):
    state: PaymentState
    expires_at: Annotated[AwareDatetime, Field(title="Expires At")]
    fee_total_sat: Annotated[int, Field(title="Fee Total Sat")]
    order_total_sat: Annotated[int, Field(title="Order Total Sat")]
    invoice: Annotated[str, Field(title="Invoice")]


class PaymentOnchain(BaseModel):
    state: PaymentState
    expires_at: Annotated[AwareDatetime, Field(title="Expires At")]
    fee_total_sat: Annotated[int, Field(title="Fee Total Sat")]
    order_total_sat: Annotated[int, Field(title="Order Total Sat")]
    address: Annotated[str, Field(title="Address")]
    min_fee_for_0conf: Annotated[int, Field(title="Min Fee For 0Conf")]
    min_onchain_payment_confirmations: Annotated[
        int, Field(title="Min Onchain Payment Confirmations")
    ]
    refund_onchain_address: Annotated[str | None, Field(title="Refund Onchain Address")] = None
    payment_status: Annotated[str | None, Field(title="Payment Status")] = None
    payment_difference: Annotated[
        int | None,
        Field(
            description="Payment difference in satoshis. Positive for overpayment, negative for underpayment, zero for exact payment",
            title="Payment Difference",
        ),
    ] = None
    last_payment_check: Annotated[int | None, Field(title="Last Payment Check")] = None


class ReceiverAddress(BaseModel):
    """
    Receiver address or invoice with its format.

    Encapsulates the destination for receiving funds along with
    metadata about what format it uses.
    """

    address: Annotated[
        str, Field(description="The actual address, invoice, or token string", title="Address")
    ]
    format: Annotated[ReceiverAddressFormat, Field(description="Format of the receiver address")]


class RoutesResponse(BaseModel):
    """
    Response with discovered routes.
    """

    routes: Annotated[
        list[MultiHopRoute], Field(description="List of discovered routes", title="Routes")
    ]
    timestamp: Annotated[int, Field(description="Response timestamp", title="Timestamp")]


class Swap(BaseModel):
    qty_from: Annotated[int, Field(examples=[30], title="Qty From")]
    qty_to: Annotated[int, Field(examples=[10], title="Qty To")]
    from_asset: Annotated[
        str | None,
        Field(
            examples=["rgb:CJkb4YZw-jRiz2sk-~PARPio-wtVYI1c-XAEYCqO-wTfvRZ8"], title="From Asset"
        ),
    ] = None
    to_asset: Annotated[
        str | None,
        Field(examples=["rgb:icfqnK9y-wObZKTu-XJcDL98-sKbE5Mh-OuDJhiI-brRJrzE"], title="To Asset"),
    ] = None
    payment_hash: Annotated[
        str,
        Field(
            examples=["7c2c95b9c2aa0a7d140495b664de7973b76561de833f0dd84def3efa08941664"],
            title="Payment Hash",
        ),
    ]
    status: SwapStatus
    requested_at: Annotated[int, Field(examples=[1691160765], title="Requested At")]
    initiated_at: Annotated[int | None, Field(examples=[1691168512], title="Initiated At")] = None
    expires_at: Annotated[int, Field(examples=[1691172703], title="Expires At")]
    completed_at: Annotated[int | None, Field(examples=[1691171075], title="Completed At")] = None


class SwapOrder(BaseModel):
    id: Annotated[str, Field(description="Order identifier", title="Id")]
    rfq_id: Annotated[
        str, Field(description="Quote identifier used to create the order", title="Rfq Id")
    ]
    maker_pubkey: Annotated[
        str | None, Field(description="Maker node public key", title="Maker Pubkey")
    ] = None
    from_asset: Annotated[
        SwapLeg,
        Field(
            description="Complete specification for input: asset, ticker, network, protocol, and amount"
        ),
    ]
    to_asset: Annotated[
        SwapLeg,
        Field(
            description="Complete specification for output: asset, ticker, network, protocol, and amount"
        ),
    ]
    price: Annotated[int, Field(title="Price")]
    deposit_address: Annotated[
        ReceiverAddress | None,
        Field(description="Address/Invoice for the user to deposit funds into"),
    ] = None
    payout_address: Annotated[
        ReceiverAddress | None,
        Field(description="Destination address/invoice for receiving the to_asset payout"),
    ] = None
    refund_address: Annotated[
        str | None, Field(description="Onchain refund address if provided", title="Refund Address")
    ] = None
    status: Annotated[SwapOrderStatus, Field(description="Current order status")] = "OPEN"
    created_at: Annotated[
        int | None,
        Field(
            description="Creation timestamp (seconds since epoch)",
            examples=[1715896356],
            title="Created At",
        ),
    ] = None
    expires_at: Annotated[
        int | None, Field(description="Expiry timestamp (seconds since epoch)", title="Expires At")
    ] = None
    filled_at: Annotated[
        int | None, Field(description="Timestamp when the order was filled", title="Filled At")
    ] = None
    refund_txid: Annotated[
        str | None, Field(description="Transaction ID of any refund sent", title="Refund Txid")
    ] = None
    deposit_txid: Annotated[
        str | None,
        Field(
            description="Matched incoming payment reference for deposit attribution",
            title="Deposit Txid",
        ),
    ] = None
    requires_manual_refund: Annotated[
        bool | None,
        Field(
            description="Whether the order requires manual refund handling",
            examples=[False],
            title="Requires Manual Refund",
        ),
    ] = False
    payment_status: Annotated[
        PaymentStatus | None, Field(description="Status of onchain payment verification")
    ] = None
    payment_difference: Annotated[
        int | None,
        Field(
            description="Payment difference in satoshis (positive for overpayment, negative for underpayment)",
            title="Payment Difference",
        ),
    ] = None
    last_payment_check: Annotated[
        int | None,
        Field(description="Timestamp of the last payment verification", title="Last Payment Check"),
    ] = None
    email: Annotated[
        str | None,
        Field(
            description="Notification email address", examples=["swap@example.com"], title="Email"
        ),
    ] = None
    failure_reason: Annotated[
        str | None,
        Field(description="Reason the order failed, if applicable", title="Failure Reason"),
    ] = None
    fee: Annotated[Fee, Field(description="Fee information from the quote")]


class SwapOrderStatusResponse(BaseModel):
    order_id: Annotated[str, Field(title="Order Id")]
    status: SwapOrderStatus
    order: SwapOrder


class SwapStatusResponse(BaseModel):
    swap: Swap | None = None


class TradableAssetResponseModel(BaseModel):
    """
    API response model for tradable assets.
    """

    ticker: Annotated[str, Field(title="Ticker")]
    asset_id: Annotated[str, Field(title="Asset Id")]
    name: Annotated[str, Field(title="Name")]
    precision: Annotated[int, Field(title="Precision")]
    protocol_ids: Annotated[dict[str, str], Field(title="Protocol Ids")]
    media: Media | None = None
    issued_supply: Annotated[int | None, Field(title="Issued Supply")] = None
    timestamp: Annotated[int | None, Field(title="Timestamp")] = None
    endpoints: Annotated[list[TradingLimits] | None, Field(title="Endpoints")] = None


class TradingPairResponseModel(BaseModel):
    """
    API response model for trading pairs.
    """

    id: Annotated[str, Field(title="Id")]
    base: TradableAssetResponseModel
    quote: TradableAssetResponseModel
    price: Annotated[Price | None, Field(title="Price")] = None
    routes: Annotated[list[SwapRoute] | None, Field(title="Routes")] = None
    is_active: Annotated[bool, Field(title="Is Active")] = True
    ticker: Annotated[str, Field(title="Ticker")]
    base_asset: Annotated[str, Field(title="Base Asset")]
    base_asset_id: Annotated[str, Field(title="Base Asset Id")]
    quote_asset: Annotated[str, Field(title="Quote Asset")]
    quote_asset_id: Annotated[str, Field(title="Quote Asset Id")]


class TradingPairsResponse(BaseModel):
    """
    Response containing list of trading pairs with pagination support.
    """

    pairs: Annotated[list[TradingPairResponseModel], Field(title="Pairs")]
    total: Annotated[int, Field(title="Total")]
    limit: Annotated[int, Field(title="Limit")]
    offset: Annotated[int, Field(title="Offset")]
    timestamp: Annotated[int, Field(title="Timestamp")]


class CreateSwapOrderRequest(BaseModel):
    rfq_id: Annotated[
        str, Field(description="RFQ ID cannot be empty", min_length=1, title="Rfq Id")
    ]
    from_asset: Annotated[
        SwapLeg,
        Field(
            description="Complete input specification: asset, ticker, network, protocol, and amount"
        ),
    ]
    to_asset: Annotated[
        SwapLeg,
        Field(
            description="Complete output specification: asset, ticker, network, protocol, and amount"
        ),
    ]
    receiver_address: Annotated[
        ReceiverAddress,
        Field(description="Destination address/invoice for receiving the to_asset payout"),
    ]
    min_onchain_conf: Annotated[int | None, Field(title="Min Onchain Conf")] = 1
    refund_address: Annotated[str | None, Field(title="Refund Address")] = None
    email: Annotated[
        EmailStr | None, Field(description="Optional email for notifications", title="Email")
    ] = None


class CreateSwapOrderResponse(BaseModel):
    id: Annotated[str, Field(title="Id")]
    rfq_id: Annotated[str, Field(title="Rfq Id")]
    deposit_address: ReceiverAddress | None = None
    status: SwapOrderStatus
    access_token: Annotated[str, Field(title="Access Token")]


class OrderHistoryResponse(BaseModel):
    data: Annotated[list[OrderHistorySummary], Field(description="List of orders", title="Data")]
    pagination: PaginationMeta


class PaymentDetails(BaseModel):
    bolt11: PaymentBolt11
    onchain: PaymentOnchain


class ChannelOrderResponse(BaseModel):
    order_id: Annotated[str, Field(title="Order Id")]
    client_pubkey: Annotated[str, Field(title="Client Pubkey")]
    lsp_balance_sat: Annotated[int, Field(title="Lsp Balance Sat")]
    client_balance_sat: Annotated[int, Field(title="Client Balance Sat")]
    required_channel_confirmations: Annotated[int, Field(title="Required Channel Confirmations")]
    funding_confirms_within_blocks: Annotated[int, Field(title="Funding Confirms Within Blocks")]
    channel_expiry_blocks: Annotated[int, Field(title="Channel Expiry Blocks")]
    token: Annotated[str | None, Field(title="Token")] = ""
    created_at: Annotated[AwareDatetime | None, Field(title="Created At")] = None
    announce_channel: Annotated[bool, Field(title="Announce Channel")]
    order_state: OrderState
    payment: PaymentDetails
    channel: ChannelDetails | None = None
    asset_id: Annotated[str | None, Field(title="Asset Id")] = None
    lsp_asset_amount: Annotated[int | None, Field(title="Lsp Asset Amount")] = None
    client_asset_amount: Annotated[int | None, Field(title="Client Asset Amount")] = None
    rfq_id: Annotated[str | None, Field(title="Rfq Id")] = None
    asset_price_sat: Annotated[int | None, Field(title="Asset Price Sat")] = None
    failure_reason: Annotated[str | None, Field(title="Failure Reason")] = None
    access_token: Annotated[str | None, Field(title="Access Token")] = None
