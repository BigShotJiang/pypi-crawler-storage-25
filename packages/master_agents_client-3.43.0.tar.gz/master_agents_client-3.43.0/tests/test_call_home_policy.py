"""Tests for K.1 CallHomePolicy (Wave K security primitive, 2026-05-18).

Covers default-safe configuration, allow/block decisions, tool-filter
behaviour, YAML round-trip, exception hierarchy, and the
foot-gun guard against `applies_to_tools: []` per architect critique
2026-05-18.
"""
from __future__ import annotations

import pytest

from master_agents_client.permissions import (
    CallHomePolicy,
    CallHomePolicyBlocked,
    PermissionDenied,
)


def test_default_policy_is_enabled():
    p = CallHomePolicy()
    assert p.enabled is True


def test_default_policy_allows_simos_ai_subdomain():
    p = CallHomePolicy()
    # No raise -> allowed
    p.check("http_get", {"url": "https://supplychain-api.sim-os.ai/v1/health"})


def test_default_policy_allows_localhost():
    p = CallHomePolicy()
    p.check("http_get", {"url": "http://localhost:8000/foo"})
    p.check("http_get", {"url": "http://127.0.0.1:8000/foo"})


def test_default_policy_allows_ipv6_localhost():
    """Code-reviewer WARNING 2026-05-18: IPv6 loopback `[::1]` is a
    standard localhost address and must be in defaults so legitimate
    `curl http://[::1]:8000` calls don't trip CallHomePolicy."""
    p = CallHomePolicy()
    p.check("http_get", {"url": "http://[::1]:8000/foo"})


def test_default_policy_blocks_external_url():
    p = CallHomePolicy()
    with pytest.raises(CallHomePolicyBlocked):
        p.check("http_get", {"url": "https://evil.example.com/exfil"})


def test_disabled_policy_allows_anything():
    p = CallHomePolicy(enabled=False)
    # No raise even on obviously-external URL
    p.check("http_get", {"url": "https://evil.example.com/exfil"})


def test_policy_ignores_tools_outside_applies_to():
    p = CallHomePolicy(applies_to_tools=["http_get"])
    # browser_fetch not in list -> no check
    p.check("browser_fetch", {"url": "https://evil.example.com/exfil"})


def test_callhome_blocked_inherits_permission_denied():
    assert issubclass(CallHomePolicyBlocked, PermissionDenied)


def test_blocked_error_message_lists_allowed_patterns():
    p = CallHomePolicy()
    with pytest.raises(CallHomePolicyBlocked) as exc_info:
        p.check("http_get", {"url": "https://evil.example.com"})
    msg = str(exc_info.value)
    assert "sim-os.ai" in msg
    assert "evil.example.com" in msg


def test_from_yaml_dict_with_none_returns_defaults():
    p = CallHomePolicy.from_yaml_dict(None)
    assert p.enabled is True
    assert any("sim-os.ai" in pat for pat in p.allowed_url_patterns)


def test_from_yaml_dict_rejects_empty_applies_to_tools():
    """Architect critique 2026-05-18: empty applies_to_tools is a
    foot-gun (user thinks policy is on but it does nothing). Raise at
    config-load time, point user at `enabled: false` instead."""
    with pytest.raises(ValueError, match="applies_to_tools is explicitly empty"):
        CallHomePolicy.from_yaml_dict({"applies_to_tools": []})


def test_from_yaml_dict_custom_patterns():
    p = CallHomePolicy.from_yaml_dict({
        "enabled": True,
        "allowed_url_patterns": ["https://api.openai.com/*"],
    })
    assert "https://api.openai.com/*" in p.allowed_url_patterns


def test_non_string_url_does_not_raise():
    """Defensive - non-string URL arg is a different bug (probably a
    tool-handler type mismatch). Policy should not raise
    CallHomePolicyBlocked; let downstream type checking surface the
    real bug."""
    p = CallHomePolicy()
    p.check("http_get", {"url": None})  # no raise
    p.check("http_get", {})  # no raise (missing url key)
