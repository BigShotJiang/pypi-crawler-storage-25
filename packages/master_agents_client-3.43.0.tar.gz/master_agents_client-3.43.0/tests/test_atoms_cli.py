"""K-G.1 Wave H S4 (2026-05-17) — tests for `mao-client atoms` subcommands.

Covers the propose → review → approve/reject lifecycle:
  - list-proposed (empty + populated)
  - approve (move + status flip + refuse-overwrite + unknown-id)
  - reject (delete + unknown-id)
  - clean-stale (days=0 deletes all + days=30 keeps recent + dry-run)

Operates on tmp_path-isolated corpus to keep tests deterministic.
"""

from __future__ import annotations

import argparse
import os
import time
from pathlib import Path

import pytest

from master_agents_client._cmd_atoms import (
    _DEFAULT_STALE_DAYS,
    _flip_status_to_active,
    add_atoms_subparser,
    cmd_atoms,
)


# ── helpers ───────────────────────────────────────────────────────────────────


_FRONTMATTER_PROPOSED = """---
id: {atom_id}
kind: {kind}
title: '{title}'
when: 2026-05-17
severity: P3
track: Knowledge
status: proposed
themes:
  - test
anchors: []
---
# {atom_id} — {title}

Test body content here.
"""


def _write_proposed_atom(
    proposed_dir: Path,
    atom_id: str,
    *,
    kind: str = "incident",
    title: str = "test atom",
    age_days: float = 0.0,
) -> Path:
    """Write a proposed atom file and optionally backdate its mtime."""
    proposed_dir.mkdir(parents=True, exist_ok=True)
    path = proposed_dir / f"{atom_id}.md"
    path.write_text(
        _FRONTMATTER_PROPOSED.format(atom_id=atom_id, kind=kind, title=title),
        encoding="utf-8",
    )
    if age_days > 0:
        # Backdate mtime
        old_time = time.time() - (age_days * 86400)
        os.utime(path, (old_time, old_time))
    return path


def _make_args(
    corpus_root: Path, subcmd: str, **kwargs,
) -> argparse.Namespace:
    """Build the argparse.Namespace cmd_atoms expects, mirroring CLI parsing."""
    return argparse.Namespace(
        command="atoms",
        atoms_command=subcmd,
        corpus_root=str(corpus_root),
        **kwargs,
    )


# ── add_atoms_subparser registers the parser correctly ────────────────────────


def test_add_atoms_subparser_registers_all_four_subcommands():
    """The CLI dispatch must expose exactly 4 subcommands."""
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    add_atoms_subparser(sub)
    # Parse `atoms list-proposed` to confirm the subparser tree is wired
    args = parser.parse_args(["atoms", "list-proposed"])
    assert args.command == "atoms"
    assert args.atoms_command == "list-proposed"
    # Parse `atoms approve I-001` to confirm positional arg works
    args = parser.parse_args(["atoms", "approve", "I-001"])
    assert args.atoms_command == "approve"
    assert args.atom_id == "I-001"
    # Parse `atoms reject` + `atoms clean-stale --days 7`
    args = parser.parse_args(["atoms", "reject", "P-001"])
    assert args.atoms_command == "reject"
    args = parser.parse_args(["atoms", "clean-stale", "--days", "7"])
    assert args.atoms_command == "clean-stale"
    assert args.days == 7


# ── list-proposed ─────────────────────────────────────────────────────────────


def test_list_proposed_empty_dir(tmp_path, capsys):
    """Empty (or missing) _proposed/ dir → exit 0, friendly message."""
    args = _make_args(tmp_path, "list-proposed", verbose=False)
    rc = cmd_atoms(args)
    captured = capsys.readouterr()
    assert rc == 0
    assert "No proposed atoms" in captured.out


def test_list_proposed_with_atoms(tmp_path, capsys):
    """Populated _proposed/ → lists each file with id + age."""
    proposed = tmp_path / "_proposed"
    _write_proposed_atom(proposed, "I-100", title="atom one")
    _write_proposed_atom(proposed, "P-100", kind="pattern", title="atom two")
    args = _make_args(tmp_path, "list-proposed", verbose=False)
    rc = cmd_atoms(args)
    captured = capsys.readouterr()
    assert rc == 0
    assert "2 proposed atom(s)" in captured.out
    assert "I-100" in captured.out
    assert "P-100" in captured.out


def test_list_proposed_verbose_shows_title_and_kind(tmp_path, capsys):
    """Verbose mode prints title + kind from frontmatter."""
    proposed = tmp_path / "_proposed"
    _write_proposed_atom(
        proposed, "I-200", title="verbose-mode marker title",
    )
    args = _make_args(tmp_path, "list-proposed", verbose=True)
    rc = cmd_atoms(args)
    captured = capsys.readouterr()
    assert rc == 0
    assert "verbose-mode marker title" in captured.out
    assert "incident" in captured.out  # kind label appears


# ── approve ───────────────────────────────────────────────────────────────────


def test_approve_moves_file_and_flips_status(tmp_path, capsys):
    """approve moves <id>.md from _proposed/ to atoms/, flips status."""
    proposed = tmp_path / "_proposed"
    proposed_path = _write_proposed_atom(proposed, "I-300", title="approve me")
    args = _make_args(tmp_path, "approve", atom_id="I-300")
    rc = cmd_atoms(args)
    captured = capsys.readouterr()
    assert rc == 0, f"approve failed: {captured.err}"
    # Proposed gone
    assert not proposed_path.exists()
    # Target exists with active status
    target_path = tmp_path / "I-300.md"
    assert target_path.exists()
    text = target_path.read_text(encoding="utf-8")
    assert "status: active" in text
    assert "status: proposed" not in text


def test_approve_refuses_to_overwrite_existing_atom(tmp_path, capsys):
    """If atoms/<id>.md already exists, approve refuses with non-zero exit."""
    proposed = tmp_path / "_proposed"
    _write_proposed_atom(proposed, "I-400", title="already exists")
    existing_path = tmp_path / "I-400.md"
    existing_path.write_text("existing content\n", encoding="utf-8")
    args = _make_args(tmp_path, "approve", atom_id="I-400")
    rc = cmd_atoms(args)
    captured = capsys.readouterr()
    assert rc == 1
    assert "already exists" in captured.err.lower()
    # Existing file unchanged
    assert existing_path.read_text(encoding="utf-8") == "existing content\n"


def test_approve_unknown_id_returns_error(tmp_path, capsys):
    """approve on missing proposed file → non-zero exit + clear error."""
    (tmp_path / "_proposed").mkdir()
    args = _make_args(tmp_path, "approve", atom_id="I-999")
    rc = cmd_atoms(args)
    captured = capsys.readouterr()
    assert rc == 1
    assert "no proposed atom" in captured.err.lower()


# ── reject ────────────────────────────────────────────────────────────────────


def test_reject_deletes_proposed_file(tmp_path, capsys):
    """reject deletes <id>.md from _proposed/."""
    proposed = tmp_path / "_proposed"
    proposed_path = _write_proposed_atom(proposed, "I-500", title="reject me")
    args = _make_args(tmp_path, "reject", atom_id="I-500")
    rc = cmd_atoms(args)
    captured = capsys.readouterr()
    assert rc == 0
    assert not proposed_path.exists()
    assert "Rejected I-500" in captured.out


def test_reject_unknown_id_returns_error(tmp_path, capsys):
    """reject on missing file → non-zero exit + clear error."""
    (tmp_path / "_proposed").mkdir()
    args = _make_args(tmp_path, "reject", atom_id="I-999")
    rc = cmd_atoms(args)
    captured = capsys.readouterr()
    assert rc == 1
    assert "no proposed atom" in captured.err.lower()


# ── clean-stale ───────────────────────────────────────────────────────────────


def test_clean_stale_days_0_deletes_all(tmp_path, capsys):
    """--days 0 → every proposal is stale; all deleted."""
    proposed = tmp_path / "_proposed"
    _write_proposed_atom(proposed, "I-600", title="recent atom")
    _write_proposed_atom(proposed, "I-601", title="also recent")
    args = _make_args(
        tmp_path, "clean-stale", days=0, dry_run=False,
    )
    rc = cmd_atoms(args)
    captured = capsys.readouterr()
    assert rc == 0
    assert not (proposed / "I-600.md").exists()
    assert not (proposed / "I-601.md").exists()
    assert "Deleted 2 stale proposal" in captured.out


def test_clean_stale_default_days_keeps_recent(tmp_path, capsys):
    """Default --days=30 keeps atoms with mtime < 30 days old."""
    proposed = tmp_path / "_proposed"
    _write_proposed_atom(proposed, "I-700", age_days=1.0)   # 1 day old — kept
    _write_proposed_atom(proposed, "I-701", age_days=60.0)  # 60 days — stale
    args = _make_args(
        tmp_path, "clean-stale", days=_DEFAULT_STALE_DAYS, dry_run=False,
    )
    rc = cmd_atoms(args)
    captured = capsys.readouterr()
    assert rc == 0
    assert (proposed / "I-700.md").exists()  # kept
    assert not (proposed / "I-701.md").exists()  # deleted
    assert "Deleted 1 stale proposal" in captured.out


def test_clean_stale_dry_run_does_not_delete(tmp_path, capsys):
    """--dry-run prints what WOULD be deleted but keeps files intact."""
    proposed = tmp_path / "_proposed"
    _write_proposed_atom(proposed, "I-800", age_days=60.0)
    args = _make_args(
        tmp_path, "clean-stale", days=30, dry_run=True,
    )
    rc = cmd_atoms(args)
    captured = capsys.readouterr()
    assert rc == 0
    assert (proposed / "I-800.md").exists()  # still there
    assert "Would delete" in captured.out
    assert "dry-run" in captured.out


def test_clean_stale_no_proposed_dir(tmp_path, capsys):
    """Missing _proposed/ → exit 0 with friendly message (not an error)."""
    args = _make_args(
        tmp_path, "clean-stale", days=30, dry_run=False,
    )
    rc = cmd_atoms(args)
    captured = capsys.readouterr()
    assert rc == 0
    assert "No _proposed/" in captured.out


def test_clean_stale_no_stale_files(tmp_path, capsys):
    """All files within window → exit 0 with count message."""
    proposed = tmp_path / "_proposed"
    _write_proposed_atom(proposed, "I-900", age_days=1.0)
    args = _make_args(
        tmp_path, "clean-stale", days=30, dry_run=False,
    )
    rc = cmd_atoms(args)
    captured = capsys.readouterr()
    assert rc == 0
    assert "No stale proposed atoms" in captured.out


# ── _flip_status_to_active helper unit tests ─────────────────────────────────


def test_flip_status_proposed_to_active():
    text = """---
id: I-001
status: proposed
title: x
---
body
"""
    flipped = _flip_status_to_active(text)
    assert "status: active" in flipped
    assert "status: proposed" not in flipped


def test_flip_status_idempotent_on_active():
    """If status is already 'active', _flip_status_to_active leaves it alone."""
    text = """---
id: I-001
status: active
title: x
---
body
"""
    assert _flip_status_to_active(text) == text


def test_flip_status_handles_missing_frontmatter():
    """Plain text without YAML frontmatter returns unchanged."""
    text = "just plain text"
    assert _flip_status_to_active(text) == text


def test_flip_status_handles_comment_after_value():
    """Z.1 (Wave I, 2026-05-18) — comment-line edge case from
    architect K-G.1 SHIPPABLE-WITH-FOLLOWUP. Status line with
    trailing comment must flip the value while preserving the
    comment verbatim."""
    text = """---
id: I-001
status: proposed  # this is the proposed comment
title: x
---
body
"""
    flipped = _flip_status_to_active(text)
    assert "status: active  # this is the proposed comment" in flipped
    assert "status: proposed" not in flipped


def test_flip_status_handles_quoted_value_with_comment():
    """Z.1 — quoted value AND trailing comment in same line."""
    text = """---
id: I-001
status: "proposed" # quoted plus comment
---
body
"""
    flipped = _flip_status_to_active(text)
    assert 'status: "active" # quoted plus comment' in flipped


def test_approve_atomic_uses_os_replace(tmp_path, capsys):
    """Z.3 (Wave I, 2026-05-18) — atomic approve. Even if the target
    parent dir doesn't exist initially, approve creates it + writes
    via tempfile + os.replace. No partial state if anything fails
    pre-rename."""
    proposed = tmp_path / "_proposed"
    _write_proposed_atom(proposed, "I-ATOMIC", title="atomic test")
    args = _make_args(tmp_path, "approve", atom_id="I-ATOMIC", force=False)
    rc = cmd_atoms(args)
    captured = capsys.readouterr()
    assert rc == 0, captured.err
    target = tmp_path / "I-ATOMIC.md"
    assert target.exists()
    # No stray tempfiles or backup files left around
    leftovers = list(tmp_path.glob("*.tmp")) + list(tmp_path.glob("*.bak"))
    assert not leftovers, f"stray files: {leftovers}"


def test_approve_force_backs_up_existing(tmp_path, capsys):
    """Z.2 (Wave I, 2026-05-18) — --force flag for update workflow.
    Existing atoms/<id>.md is backed up with timestamp before being
    overwritten by the new proposed version."""
    proposed = tmp_path / "_proposed"
    _write_proposed_atom(proposed, "I-FORCE", title="updated version")
    # Pre-existing active atom at target
    target = tmp_path / "I-FORCE.md"
    target.write_text("old committed content\n", encoding="utf-8")

    args = _make_args(tmp_path, "approve", atom_id="I-FORCE", force=True)
    rc = cmd_atoms(args)
    captured = capsys.readouterr()
    assert rc == 0, captured.err
    # Target now has the new content + status flipped
    new_content = target.read_text(encoding="utf-8")
    assert "updated version" in new_content
    assert "status: active" in new_content
    # Backup file exists with old content
    backups = list(tmp_path.glob("I-FORCE.md.*.bak"))
    assert len(backups) == 1, f"expected 1 backup, got {backups}"
    assert backups[0].read_text(encoding="utf-8") == "old committed content\n"
    # Backup message printed
    assert "Backed up existing atom" in captured.out


def test_approve_force_not_set_still_refuses(tmp_path, capsys):
    """Z.2 regression — without --force, approve still refuses to
    overwrite. Preserves the v1 (Phase 1) behaviour."""
    proposed = tmp_path / "_proposed"
    _write_proposed_atom(proposed, "I-NOFORCE", title="proposed version")
    target = tmp_path / "I-NOFORCE.md"
    target.write_text("committed content\n", encoding="utf-8")

    args = _make_args(
        tmp_path, "approve", atom_id="I-NOFORCE", force=False,
    )
    rc = cmd_atoms(args)
    captured = capsys.readouterr()
    assert rc == 1
    assert "already exists" in captured.err.lower()
    # Existing target unchanged
    assert target.read_text(encoding="utf-8") == "committed content\n"


def test_flip_status_handles_quoted_proposed():
    """Architect NIT (K-G.1 dual-review 2026-05-18): flip regex must
    handle quoted YAML values too — `status: "proposed"` and
    `status: 'proposed'` get flipped to the same quoting style."""
    # Double-quoted
    text_dq = """---
id: I-001
status: "proposed"
title: x
---
body
"""
    flipped_dq = _flip_status_to_active(text_dq)
    assert 'status: "active"' in flipped_dq
    assert "proposed" not in flipped_dq

    # Single-quoted
    text_sq = """---
id: I-001
status: 'proposed'
title: x
---
body
"""
    flipped_sq = _flip_status_to_active(text_sq)
    assert "status: 'active'" in flipped_sq
    assert "proposed" not in flipped_sq


def test_approve_frontmatter_less_file_still_moves(tmp_path, capsys):
    """code_reviewer NIT (K-G.1 dual-review 2026-05-18): approve on a
    file with NO YAML frontmatter still moves the file (no status to
    flip → passthrough). Phase 1 doesn't enforce frontmatter presence;
    Phase 2 may add a strict-frontmatter mode."""
    proposed = tmp_path / "_proposed"
    proposed.mkdir(parents=True, exist_ok=True)
    bare_path = proposed / "I-FRONTLESS.md"
    bare_path.write_text("Just a markdown body with no frontmatter.\n", encoding="utf-8")
    args = _make_args(tmp_path, "approve", atom_id="I-FRONTLESS")
    rc = cmd_atoms(args)
    captured = capsys.readouterr()
    assert rc == 0, f"approve failed: {captured.err}"
    # File moved to target unchanged
    target = tmp_path / "I-FRONTLESS.md"
    assert target.exists()
    assert not bare_path.exists()
    assert target.read_text(encoding="utf-8") == "Just a markdown body with no frontmatter.\n"


def test_clean_stale_negative_days_errors(tmp_path, capsys):
    """code_reviewer NIT (K-G.1 dual-review 2026-05-18): `--days -1`
    is nonsensical (negative threshold); exit non-zero with clear error."""
    (tmp_path / "_proposed").mkdir()
    args = _make_args(
        tmp_path, "clean-stale", days=-1, dry_run=False,
    )
    rc = cmd_atoms(args)
    captured = capsys.readouterr()
    assert rc == 2
    assert "--days must be >= 0" in captured.err


def test_flip_status_preserves_other_frontmatter_fields():
    """Only the status field changes; other frontmatter keys + body intact."""
    text = """---
id: I-001
kind: incident
title: keep me
status: proposed
themes:
  - alpha
  - beta
---
# Body heading

paragraph here
"""
    flipped = _flip_status_to_active(text)
    assert "status: active" in flipped
    assert "id: I-001" in flipped
    assert "title: keep me" in flipped
    assert "- alpha" in flipped
    assert "# Body heading" in flipped
    assert "paragraph here" in flipped


# K.4.B (Wave K, 2026-05-18) - promote-confident tests
# --------------------------------------------------------------------


_FRONTMATTER_PROPOSED_WITH_CONFIDENCE = """---
id: {atom_id}
kind: {kind}
title: '{title}'
when: 2026-05-17
severity: P3
track: Knowledge
status: proposed
confidence: {confidence}
themes:
  - test
anchors: []
---
# {atom_id} - {title}

Body content.
"""


def _write_proposed_with_confidence(
    proposed_dir: Path,
    atom_id: str,
    confidence: float,
    *,
    kind: str = "incident",
    title: str = "test atom",
) -> Path:
    proposed_dir.mkdir(parents=True, exist_ok=True)
    path = proposed_dir / f"{atom_id}.md"
    path.write_text(
        _FRONTMATTER_PROPOSED_WITH_CONFIDENCE.format(
            atom_id=atom_id, kind=kind, title=title,
            confidence=confidence,
        ),
        encoding="utf-8",
    )
    return path


def test_promote_confident_subparser_registers():
    """The CLI dispatch must expose the new promote-confident subcommand."""
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    add_atoms_subparser(sub)
    args = parser.parse_args(["atoms", "promote-confident", "--threshold", "0.9"])
    assert args.atoms_command == "promote-confident"
    assert args.threshold == 0.9
    assert args.apply is False


def test_promote_confident_dry_run_lists_eligible(tmp_path, capsys):
    """High-confidence atoms appear under 'Eligible to promote';
    no files are modified without --apply."""
    proposed = tmp_path / "_proposed"
    _write_proposed_with_confidence(proposed, "I-300", 0.95)
    _write_proposed_with_confidence(proposed, "I-301", 0.70)
    args = _make_args(tmp_path, "promote-confident", threshold=0.85, apply=False)
    rc = cmd_atoms(args)
    captured = capsys.readouterr()
    assert rc == 0
    assert "[DRY-RUN]" in captured.out
    assert "I-300" in captured.out
    # I-301 falls under "Skipped (confidence < threshold)"
    assert "I-301" in captured.out
    # File still in _proposed/ (dry run is non-destructive)
    assert (proposed / "I-300.md").exists()
    # Active corpus did NOT get the file
    assert not (tmp_path / "I-300.md").exists()


def test_promote_confident_apply_moves_eligible(tmp_path, capsys):
    """--apply actually flips status and moves to active corpus."""
    proposed = tmp_path / "_proposed"
    _write_proposed_with_confidence(proposed, "I-400", 0.95)
    args = _make_args(tmp_path, "promote-confident", threshold=0.85, apply=True)
    rc = cmd_atoms(args)
    captured = capsys.readouterr()
    assert rc == 0
    assert "[APPLY]" in captured.out
    assert "Promoted: I-400" in captured.out
    # Source removed, target created
    assert not (proposed / "I-400.md").exists()
    target = tmp_path / "I-400.md"
    assert target.exists()
    # Status flipped to active
    assert "status: active" in target.read_text(encoding="utf-8")


def test_promote_confident_skips_collision(tmp_path, capsys):
    """When <id>.md already exists in active corpus, promote skips it
    (user must resolve manually)."""
    proposed = tmp_path / "_proposed"
    _write_proposed_with_confidence(proposed, "I-500", 0.99)
    # Plant a colliding active atom
    (tmp_path / "I-500.md").write_text(
        "---\nid: I-500\nstatus: active\n---\nExisting\n",
        encoding="utf-8",
    )
    args = _make_args(tmp_path, "promote-confident", threshold=0.85, apply=True)
    rc = cmd_atoms(args)
    captured = capsys.readouterr()
    assert rc == 0
    assert "Skipped (collision" in captured.out
    assert "I-500" in captured.out
    # Source still in _proposed/ (not deleted)
    assert (proposed / "I-500.md").exists()


def test_promote_confident_skips_missing_confidence_field(tmp_path, capsys):
    """Atoms without a `confidence:` field are skipped (NOT auto-
    treated as 0; explicitly listed as 'missing/invalid')."""
    proposed = tmp_path / "_proposed"
    # _write_proposed_atom (the existing helper) emits NO confidence field.
    _write_proposed_atom(proposed, "I-600", title="no-confidence atom")
    args = _make_args(tmp_path, "promote-confident", threshold=0.0, apply=True)
    rc = cmd_atoms(args)
    captured = capsys.readouterr()
    assert rc == 0
    assert "Skipped (missing/invalid confidence field)" in captured.out
    assert "I-600" in captured.out
    # File preserved
    assert (proposed / "I-600.md").exists()


def test_promote_confident_rejects_out_of_range_threshold(tmp_path, capsys):
    """--threshold outside [0.0, 1.0] is a user error."""
    args = _make_args(tmp_path, "promote-confident", threshold=1.5, apply=False)
    rc = cmd_atoms(args)
    captured = capsys.readouterr()
    assert rc == 2
    assert "must be in [0.0, 1.0]" in captured.err
