"""Wave G.4 (2026-05-17) — ask-tier permission rule tests.

Pairs with test_permissions.py (pure config matching) +
test_permissions_executor.py (deny/allow integration). This file
covers the ask-tier specifically:

- ask rule matches → executor calls ask_callback with structured args.
- Callback returns "allow_once" → handler runs.
- Callback returns "deny_once" → handler does NOT run, clear error.
- Callback returns "allow_always" → handler runs + rule promoted to allow.
- Callback returns "deny_always" → handler does NOT run + rule
  promoted to deny so future identical calls block without re-prompting.
- No ask_callback wired in → fallback is deny-once (safe default).
- Precedence: deny wins over ask wins over allow.
- /auto-approve is OUT OF SCOPE for this engine layer — it's a
  session-level toggle that gates ``requires_approval``, NOT the
  ask tier. ask rules are deliberately sticky regardless of
  /auto-approve state.
- Round-trip: ask: rules survive from_yaml_dict / to_yaml_dict.
"""
from __future__ import annotations

from pathlib import Path

import pytest

from master_agents_client.permissions import (
    AskPermissionRequired,
    PermissionsConfig,
    PermissionVerdict,
)
from master_agents_client.remote_client import RemoteToolExecutor
from master_agents_client.tools.base import Tool


def _stub_tool(name: str = "bash") -> Tool:
    """Same pattern as test_permissions_executor.py — a do-nothing
    handler that records calls so we can assert it was / wasn't run.
    """
    calls: list[dict] = []

    async def handler(**kwargs):
        calls.append(kwargs)
        return f"{name} ran with {kwargs!r}"

    tool = Tool(
        name=name, description="stub", input_schema={}, handler=handler,
    )
    tool._test_calls = calls  # type: ignore[attr-defined]
    return tool


@pytest.fixture
def cwd(tmp_path: Path) -> Path:
    return tmp_path


# --- Config-level checks (PermissionsConfig) -------------------------------


def test_ask_rule_returns_ask_verdict_with_matched_rule() -> None:
    """The check() return surface carries the matched rule string —
    the REPL needs it to render the prompt context."""
    cfg = PermissionsConfig(ask=["Bash(rm:*)"])
    verdict = cfg.check("bash", {"command": "rm -rf /tmp/x"})
    assert verdict.action == "ask"
    assert verdict.matched_rule == "Bash(rm:*)"
    assert "Bash(rm:*)" in verdict.reason


def test_deny_beats_ask_for_overlapping_globs() -> None:
    """If both deny and ask match the same call, deny wins (always)."""
    cfg = PermissionsConfig(
        deny=["Bash(rm -rf:*)"],
        ask=["Bash(rm:*)"],
    )
    verdict = cfg.check("bash", {"command": "rm -rf /tmp/x"})
    assert verdict.action == "deny"


def test_ask_beats_allow_for_overlapping_globs() -> None:
    """ask is structurally more important than allow — if both match,
    ask wins so the user gets to confirm before a broader allow rule
    silently passes the call through."""
    cfg = PermissionsConfig(
        allow=["Bash"],  # broad allow
        ask=["Bash(rm:*)"],  # narrow ask
    )
    verdict = cfg.check("bash", {"command": "rm -rf /tmp/x"})
    assert verdict.action == "ask"


def test_ask_yaml_round_trip() -> None:
    """ask: tier serialises into and out of the YAML shape cleanly."""
    cfg = PermissionsConfig(
        allow=["Bash(git:*)"],
        deny=["Bash(sudo:*)"],
        ask=["Bash(rm:*)", "Bash(curl:*)"],
    )
    blob = cfg.to_yaml_dict()
    assert blob["ask"] == ["Bash(rm:*)", "Bash(curl:*)"]
    restored = PermissionsConfig.from_yaml_dict(blob)
    assert restored.ask == ["Bash(rm:*)", "Bash(curl:*)"]


def test_empty_ask_omitted_from_yaml_for_backcompat() -> None:
    """Pre-G.4 configs that only had allow/deny round-trip with NO
    spurious empty ``ask: []`` key in the YAML."""
    cfg = PermissionsConfig(allow=["Write(./**)"])
    blob = cfg.to_yaml_dict()
    assert "ask" not in blob


def test_add_rule_appends_to_target_tier_idempotently() -> None:
    cfg = PermissionsConfig()
    cfg.add_rule("allow", "Bash(git:*)")
    cfg.add_rule("allow", "Bash(git:*)")  # idempotent
    assert cfg.allow == ["Bash(git:*)"]


def test_add_rule_validates_at_insertion_time() -> None:
    """Malformed rule should raise — we don't want bad rules
    silently stored and only firing as 'never matches'."""
    cfg = PermissionsConfig()
    with pytest.raises(ValueError):
        cfg.add_rule("ask", "this is not a valid rule")


# --- Executor integration (RemoteToolExecutor) -----------------------------


async def test_ask_invokes_callback_with_structured_args(cwd: Path) -> None:
    tool = _stub_tool("bash")
    perms = PermissionsConfig(ask=["Bash(rm:*)"])
    captured: dict = {}

    def ask_cb(tool_name, input_args, verdict):
        captured["tool_name"] = tool_name
        captured["input_args"] = dict(input_args)
        captured["verdict"] = verdict
        return "allow_once"

    execu = RemoteToolExecutor(
        cwd=cwd, writable_paths=["."], tools={"bash": tool},
        permissions=perms, ask_callback=ask_cb,
    )
    out, is_error = await execu.execute("bash", {"command": "rm -rf /tmp/x"})
    assert is_error is False
    assert captured["tool_name"] == "bash"
    assert captured["input_args"] == {"command": "rm -rf /tmp/x"}
    assert captured["verdict"].matched_rule == "Bash(rm:*)"
    # Handler ran (allow_once).
    assert tool._test_calls == [{"command": "rm -rf /tmp/x"}]  # type: ignore[attr-defined]


async def test_ask_callback_deny_once_blocks_handler(cwd: Path) -> None:
    tool = _stub_tool("bash")
    perms = PermissionsConfig(ask=["Bash(rm:*)"])

    def ask_cb(tool_name, input_args, verdict):
        return "deny_once"

    execu = RemoteToolExecutor(
        cwd=cwd, writable_paths=["."], tools={"bash": tool},
        permissions=perms, ask_callback=ask_cb,
    )
    out, is_error = await execu.execute("bash", {"command": "rm -rf /tmp/x"})
    assert is_error is True
    assert "denied by user" in out.lower()
    assert tool._test_calls == []  # type: ignore[attr-defined]


async def test_ask_callback_allow_always_promotes_to_allow(cwd: Path) -> None:
    """allow_always: the rule moves into the allow tier in-memory so
    future identical calls pass through without re-prompting."""
    tool = _stub_tool("bash")
    perms = PermissionsConfig(ask=["Bash(rm:*)"])
    call_count = [0]

    def ask_cb(tool_name, input_args, verdict):
        call_count[0] += 1
        return "allow_always"

    execu = RemoteToolExecutor(
        cwd=cwd, writable_paths=["."], tools={"bash": tool},
        permissions=perms, ask_callback=ask_cb,
    )
    await execu.execute("bash", {"command": "rm -rf /tmp/x"})
    await execu.execute("bash", {"command": "rm -rf /tmp/y"})
    # Callback fired ONCE (first call); second call hit the promoted
    # allow rule and passed through silently.
    assert call_count[0] == 1
    assert "Bash(rm:*)" in perms.allow
    assert len(tool._test_calls) == 2  # type: ignore[attr-defined]


async def test_ask_callback_deny_always_promotes_to_deny(cwd: Path) -> None:
    """deny_always: the rule moves into the deny tier in-memory so
    future identical calls block without re-prompting."""
    tool = _stub_tool("bash")
    perms = PermissionsConfig(ask=["Bash(rm:*)"])
    call_count = [0]

    def ask_cb(tool_name, input_args, verdict):
        call_count[0] += 1
        return "deny_always"

    execu = RemoteToolExecutor(
        cwd=cwd, writable_paths=["."], tools={"bash": tool},
        permissions=perms, ask_callback=ask_cb,
    )
    out1, err1 = await execu.execute("bash", {"command": "rm -rf /tmp/x"})
    out2, err2 = await execu.execute("bash", {"command": "rm -rf /tmp/y"})
    assert err1 is True and err2 is True
    # Callback fired ONCE; second call hit the promoted deny rule.
    assert call_count[0] == 1
    assert "Bash(rm:*)" in perms.deny
    assert tool._test_calls == []  # type: ignore[attr-defined]


async def test_ask_without_callback_falls_back_to_deny(cwd: Path) -> None:
    """No prompt UI wired in → safe default is to block with an
    informative error pointing the user at the fix."""
    tool = _stub_tool("bash")
    perms = PermissionsConfig(ask=["Bash(rm:*)"])
    execu = RemoteToolExecutor(
        cwd=cwd, writable_paths=["."], tools={"bash": tool},
        permissions=perms, ask_callback=None,
    )
    out, is_error = await execu.execute("bash", {"command": "rm -rf /tmp/x"})
    assert is_error is True
    assert "no ask-callback" in out.lower()
    assert tool._test_calls == []  # type: ignore[attr-defined]


async def test_ask_callback_unknown_verdict_defaults_to_deny(
    cwd: Path,
) -> None:
    """Defensive: a buggy callback returning a string we don't
    recognise should NOT pass the call through — default to deny so
    a callback bug can never silently let destructive calls run."""
    tool = _stub_tool("bash")
    perms = PermissionsConfig(ask=["Bash(rm:*)"])

    def ask_cb(tool_name, input_args, verdict):
        return "wat"  # not allow_once / allow_always / deny_*

    execu = RemoteToolExecutor(
        cwd=cwd, writable_paths=["."], tools={"bash": tool},
        permissions=perms, ask_callback=ask_cb,
    )
    out, is_error = await execu.execute("bash", {"command": "rm -rf /tmp/x"})
    assert is_error is True
    assert "unknown verdict" in out.lower()
    assert tool._test_calls == []  # type: ignore[attr-defined]


async def test_ask_callback_async_form_is_awaited(cwd: Path) -> None:
    """Callback may be async (REPL uses async prompts under
    prompt_toolkit). Executor awaits the coroutine and uses its
    return value as the verdict."""
    tool = _stub_tool("bash")
    perms = PermissionsConfig(ask=["Bash(rm:*)"])

    async def ask_cb(tool_name, input_args, verdict):
        return "allow_once"

    execu = RemoteToolExecutor(
        cwd=cwd, writable_paths=["."], tools={"bash": tool},
        permissions=perms, ask_callback=ask_cb,
    )
    _, is_error = await execu.execute("bash", {"command": "rm -rf /tmp/x"})
    assert is_error is False
    assert tool._test_calls == [{"command": "rm -rf /tmp/x"}]  # type: ignore[attr-defined]


# --- Exception class (AskPermissionRequired) -------------------------------


def test_ask_permission_required_carries_structured_fields() -> None:
    """Non-REPL callers that don't wire a callback get a clean
    PermissionError subclass with all the fields they need to
    inspect / log."""
    exc = AskPermissionRequired(
        tool_name="bash",
        tool_args={"command": "rm -rf /tmp/x"},
        matched_rule="Bash(rm:*)",
        reason="dangerous pattern",
    )
    assert exc.tool_name == "bash"
    assert exc.matched_rule == "Bash(rm:*)"
    assert exc.tool_args == {"command": "rm -rf /tmp/x"}
    assert isinstance(exc, PermissionError)
    # str() carries the matched rule so logs / tracebacks are useful.
    assert "Bash(rm:*)" in str(exc)
