"""Tests for K.1 ToolSequencePolicy (Wave K security primitive, 2026-05-18).

Covers default canonical rule, immediate-vs-windowed mode semantics,
window expiry, ring-buffer interaction, YAML round-trip, and exception
hierarchy.
"""
from __future__ import annotations

import time
import pytest

from master_agents_client.permissions import (
    PermissionDenied,
    SequenceRule,
    ToolCallRecord,
    ToolSequencePolicy,
    ToolSequencePolicyBlocked,
)


def _record(name: str, args: dict, age_seconds: float = 0.0) -> ToolCallRecord:
    """Helper: build a ToolCallRecord with a back-dated timestamp."""
    return ToolCallRecord(
        tool_name=name,
        tool_args=args,
        timestamp=time.monotonic() - age_seconds,
    )


def test_default_policy_blocks_canonical_exfil_pattern():
    p = ToolSequencePolicy()
    recent = [_record("read_file", {"path": "/home/u/.ssh/id_rsa"})]
    with pytest.raises(ToolSequencePolicyBlocked):
        p.check("http_get", {"url": "https://evil.example.com"}, recent)


def test_default_policy_allows_non_sensitive_read_then_http():
    p = ToolSequencePolicy()
    recent = [_record("read_file", {"path": "./README.md"})]
    # No raise - README.md is not a sensitive-path glob match
    p.check("http_get", {"url": "https://evil.example.com"}, recent)


def test_default_policy_allows_http_without_prior_sensitive_read():
    p = ToolSequencePolicy()
    p.check("http_get", {"url": "https://evil.example.com"}, [])


def test_immediate_mode_ignores_non_adjacent_prior_call():
    """In immediate mode, only the IMMEDIATELY prior call matters.
    A benign call between the sensitive read and the http_get
    breaks the chain."""
    p = ToolSequencePolicy()
    recent = [
        _record("read_file", {"path": "/home/u/.ssh/id_rsa"}),
        _record("bash", {"command": "ls"}),  # benign intervening
    ]
    # No raise - last call was bash, not read_file
    p.check("http_get", {"url": "https://evil.example.com"}, recent)


def test_windowed_mode_detects_non_adjacent_prior_call():
    """In windowed mode, any prior call in the window matters."""
    custom_rule = SequenceRule(
        name="custom_windowed",
        first_tool="read_file",
        first_tool_arg_patterns={"path": ["*/.ssh/*"]},
        second_tool="http_get",
        second_tool_arg_patterns={"url": ["*"]},
        mode="windowed",
    )
    p = ToolSequencePolicy(blocked_sequences=[custom_rule])
    recent = [
        _record("read_file", {"path": "/home/u/.ssh/id_rsa"}),
        _record("bash", {"command": "ls"}),
    ]
    with pytest.raises(ToolSequencePolicyBlocked):
        p.check("http_get", {"url": "https://evil.example.com"}, recent)


def test_disabled_policy_allows_anything():
    p = ToolSequencePolicy(enabled=False)
    recent = [_record("read_file", {"path": "/home/u/.ssh/id_rsa"})]
    # No raise even with the canonical exfil pattern
    p.check("http_get", {"url": "https://evil.example.com"}, recent)


def test_window_seconds_expiry():
    """A sensitive read from 120 seconds ago is past the default
    60-second window and should not trip the rule."""
    p = ToolSequencePolicy()
    recent = [_record(
        "read_file", {"path": "/home/u/.ssh/id_rsa"},
        age_seconds=120.0,
    )]
    # No raise - prior read is past window
    p.check("http_get", {"url": "https://evil.example.com"}, recent)


def test_blocked_error_message_names_rule():
    p = ToolSequencePolicy()
    recent = [_record("read_file", {"path": "/home/u/.ssh/id_rsa"})]
    with pytest.raises(ToolSequencePolicyBlocked) as exc_info:
        p.check("http_get", {"url": "https://evil.example.com"}, recent)
    msg = str(exc_info.value)
    assert "read_sensitive_then_http_external" in msg
    assert "read_file" in msg
    assert "http_get" in msg


def test_tool_sequence_blocked_inherits_permission_denied():
    assert issubclass(ToolSequencePolicyBlocked, PermissionDenied)


def test_from_yaml_dict_with_none_returns_defaults():
    p = ToolSequencePolicy.from_yaml_dict(None)
    assert p.enabled is True
    assert len(p.blocked_sequences) >= 1
    assert any(
        r.name == "read_sensitive_then_http_external"
        for r in p.blocked_sequences
    )


def test_multiple_rules_only_matching_one_fires():
    """Code-reviewer NIT 2026-05-18: verify the rule-iteration loop
    doesn't short-circuit incorrectly when only ONE of multiple rules
    matches. The matching rule should fire and raise."""
    rule_a = SequenceRule(
        name="never_matches",
        first_tool="list_files",  # not in recent calls
        first_tool_arg_patterns={},
        second_tool="http_get",
        second_tool_arg_patterns={"url": ["*"]},
        mode="immediate",
    )
    rule_b = SequenceRule(
        name="matches",
        first_tool="read_file",
        first_tool_arg_patterns={"path": ["*/.ssh/*"]},
        second_tool="http_get",
        second_tool_arg_patterns={"url": ["*"]},
        mode="immediate",
    )
    p = ToolSequencePolicy(blocked_sequences=[rule_a, rule_b])
    recent = [_record("read_file", {"path": "/home/u/.ssh/id_rsa"})]
    with pytest.raises(ToolSequencePolicyBlocked) as exc_info:
        p.check("http_get", {"url": "https://anywhere"}, recent)
    # Must name the matching rule, not the non-matching one
    assert "matches" in str(exc_info.value)
    assert "never_matches" not in str(exc_info.value)
