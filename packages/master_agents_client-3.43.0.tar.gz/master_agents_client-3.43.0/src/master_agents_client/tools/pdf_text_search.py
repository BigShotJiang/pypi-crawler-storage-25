"""Built-in `pdf_text_search` tool — substring/regex search inside a PDF.

Wave A.4 (cite_checker enabler). Distinct from `pdf_read`:
  - `pdf_read` returns the whole extracted text (or a page-range slice)
    with page markers, suitable for "give me the content".
  - `pdf_text_search` returns ONLY the matches with page numbers +
    snippet context, suitable for "does this claim appear in this PDF?"

Designed for citation verification: an agent has a claim ("X grew 27%
after policy change") + a reference (a PDF). Run pdf_text_search with
a few keyword variants from the claim; if no matches turn up, flag the
citation as unverifiable. Verbatim grounding > paraphrase grounding,
per `[[feedback-fact-vs-advice]]`.

Sharing the pypdf reader path with pdf_read (same dependency set, same
encrypted-PDF handling, same disk-error envelope) keeps the surface
consistent — the only divergence is "what we do with the extracted
text" (search vs. return).
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from .base import Tool

# Hard cap on matches returned per call. Beyond this, the caller is
# searching for the wrong thing (too-broad query) — telling them to
# narrow scope is more useful than dumping 10,000 lines.
MAX_MATCHES = 100

# Per-match snippet window (characters on each side of the match).
# 80 chars per side ≈ one screen-wrapped line of context, enough to
# tell the caller WHICH sentence the match lives in without dumping
# the whole page.
SNIPPET_CONTEXT_CHARS = 80


def _make_snippet(text: str, start: int, end: int) -> str:
    """Extract a context window around the match. Replaces internal
    newlines with spaces so the snippet renders as a single line."""
    a = max(0, start - SNIPPET_CONTEXT_CHARS)
    b = min(len(text), end + SNIPPET_CONTEXT_CHARS)
    snippet = text[a:b].replace("\n", " ").strip()
    prefix = "…" if a > 0 else ""
    suffix = "…" if b < len(text) else ""
    return f"{prefix}{snippet}{suffix}"


async def _pdf_text_search_handler(
    path: str,
    query: str,
    case_sensitive: bool = False,
    regex: bool = False,
    max_matches: int = MAX_MATCHES,
) -> str:
    p = Path(path)
    if not p.exists():
        return f"Path does not exist: {path}"
    if not p.is_file():
        return f"Not a file: {path}"
    if p.suffix.lower() != ".pdf":
        return f"Not a PDF file: {path}"
    if not query:
        return "Query is empty — pass a non-empty substring or regex."
    if max_matches < 1:
        return f"max_matches must be >= 1 (got {max_matches})"

    try:
        from pypdf import PdfReader
        from pypdf.errors import PdfReadError
    except ImportError:  # pragma: no cover
        return (
            "pypdf is not installed. Install the master-agents package "
            "with pdf extras."
        )

    try:
        reader = PdfReader(str(p))
    except (PdfReadError, OSError, ValueError) as e:
        return f"Failed to read PDF: {type(e).__name__}: {e}"

    if reader.is_encrypted:
        try:
            ok = reader.decrypt("")
        except Exception as e:
            return f"Failed to read PDF (encrypted): {type(e).__name__}: {e}"
        if not ok:
            return f"Refusing to read encrypted PDF (password required): {path}"

    # Compile the matcher once. Regex mode passes the query through
    # `re.compile` directly so the agent can use anchors / character
    # classes / alternation. Substring mode escapes the query so
    # special characters in claim text (e.g., "$5.3M", "p < 0.05")
    # don't get interpreted.
    flags = 0 if case_sensitive else re.IGNORECASE
    try:
        if regex:
            pattern = re.compile(query, flags)
        else:
            pattern = re.compile(re.escape(query), flags)
    except re.error as exc:
        return f"Invalid regex query: {exc}"

    matches: list[dict[str, Any]] = []
    total_pages = len(reader.pages)
    if total_pages == 0:
        return f"PDF has no pages: {path}"

    for page_num in range(1, total_pages + 1):
        try:
            text = reader.pages[page_num - 1].extract_text() or ""
        except Exception as exc:
            # Page-level extraction failure shouldn't abort the whole
            # search — log a marker and move on, mirroring pdf_read.
            matches.append({
                "page": page_num,
                "match": None,
                "snippet": f"[extraction error: {type(exc).__name__}: {exc}]",
            })
            continue
        if not text:
            continue

        for m in pattern.finditer(text):
            matches.append({
                "page": page_num,
                "match": m.group(0),
                "snippet": _make_snippet(text, m.start(), m.end()),
            })
            if len(matches) >= max_matches:
                break
        if len(matches) >= max_matches:
            break

    if not matches:
        return (
            f"No matches for {query!r} in {path} (searched {total_pages} pages, "
            f"case_sensitive={case_sensitive}, regex={regex})."
        )

    header = (
        f"Found {len(matches)} match(es) for {query!r} in {path}"
        + (f" (capped at {max_matches})" if len(matches) >= max_matches else "")
        + ":"
    )
    lines = [header]
    for hit in matches:
        if hit["match"] is None:
            lines.append(f"  page {hit['page']}: {hit['snippet']}")
        else:
            lines.append(f"  page {hit['page']}: {hit['snippet']}")
    return "\n".join(lines)


pdf_text_search = Tool(
    name="pdf_text_search",
    description=(
        "Search a PDF for a substring or regex pattern and return the "
        "matches with page numbers + surrounding context. Use when you "
        "need to VERIFY whether a specific claim, citation, or term "
        "appears in a reference — `pdf_read` returns the whole document, "
        "this returns only the relevant hits. Set `regex=true` for "
        "pattern matching with anchors / alternation / character classes; "
        "default is literal substring (special regex chars in the query "
        "are escaped so claim text with $, ., or () works as-is). "
        "Returns up to `max_matches` (default 100); narrow the query if "
        "you hit the cap."
    ),
    input_schema={
        "type": "object",
        "required": ["path", "query"],
        "properties": {
            "path": {
                "type": "string",
                "description": "Path to a .pdf file.",
            },
            "query": {
                "type": "string",
                "description": (
                    "Substring (default) or regex pattern to search for. "
                    "In substring mode, special regex characters are "
                    "escaped automatically. In regex mode, the query is "
                    "compiled as-is — use Python `re` syntax."
                ),
            },
            "case_sensitive": {
                "type": "boolean",
                "default": False,
                "description": (
                    "Default false — citation verification rarely cares "
                    "about case. Set true when matching code symbols, "
                    "named entities, or anything case-meaningful."
                ),
            },
            "regex": {
                "type": "boolean",
                "default": False,
                "description": (
                    "When true, the query is compiled as a Python regex. "
                    "When false (default), the query is escaped and "
                    "treated as a literal substring."
                ),
            },
            "max_matches": {
                "type": "integer",
                "default": MAX_MATCHES,
                "description": (
                    f"Hard cap on returned matches (default {MAX_MATCHES}). "
                    "Hitting the cap usually means the query is too broad — "
                    "narrow it for better signal."
                ),
            },
        },
    },
    handler=_pdf_text_search_handler,
    untrusted_output=True,
    channels=["cli"],
)
