"""Tracer: emit JSONL events as a session runs.

Event types (v1):

- session_start    top-level session.run() invoked
- session_end      session finished (success or error)
- agent_start      a specific agent's Runner loop began
- agent_end        an agent's Runner loop finished
- chat_request     about to call provider.chat()
- chat_response    provider.chat() returned
- tool_call_start  about to execute a tool
- tool_call_end    tool execution finished

All events share: `type`, `timestamp`, `session_id`.
Event payloads stay small on purpose — previews and counts, not full
messages — so a long session's trace remains readable and cheap to store.
"""

from __future__ import annotations

import asyncio
import json
import logging
import sys
import time
import uuid
from abc import ABC, abstractmethod
from collections.abc import Awaitable, Callable
from pathlib import Path
from typing import Any, Literal, TextIO, Union

# Pydantic on Python <3.12 requires `typing_extensions.TypedDict` (and
# its companion `NotRequired`) — see the matching note in the service.
# `master_agents_client.agent.AgentSpec` is a Pydantic BaseModel that
# references TraceEvent (defined here) transitively, so the import
# source matters for schema generation. Verified 2026-05-13 by a
# failed v2.3.0 deploy on Python 3.11.
from typing_extensions import NotRequired, TypedDict

logger = logging.getLogger(__name__)


# ── Sprint 3 / Item 4 — typed shapes for the top-10 trace events ────
#
# Wire format: every emit() call passes a `dict[str, Any]` literal
# with a `"type"` discriminator. The 10 TypedDicts below pin the
# field schema for the most frequently-emitted event kinds; the
# remaining ~22 event types (text_delta / forced_route / router_*
# / pipeline_* / tool_call_blocked_by_* / etc.) stay loose-dict for
# now and migrate in a follow-up sprint.
#
# The shapes here are READ-ONLY documentation in v1 — emit sites
# continue to use dict literals, and the runtime tracer accepts
# either form via `Tracer.emit(event: TraceEvent | dict[str, Any])`.
# A future "all-event TypedDict" sweep will tighten emit sites to
# the typed shape and migrate consumers (ProgressTracer._format,
# ConsoleTracer.emit) to discriminated `match event["type"]:`
# narrowing.
#
# WHY DOCUMENT THE SHAPE EVEN WITHOUT ENFORCEMENT
# -----------------------------------------------
# `Tracer.emit(event: dict[str, Any])` is the LEAST informative
# possible signature for the wire format. Consumers had to grep
# emit sites to discover field names; trace-reader code accumulated
# `.get("...")` defensive scaffolding. The TypedDicts here are the
# authoritative reference — anyone writing a new tracer or a trace
# replay tool can import them and narrow at the call site.


class _BaseTraceEvent(TypedDict):
    """Common header on every trace event. Not exported — consumers
    work with the discriminated `TraceEvent` union below."""
    type: str
    timestamp: str
    session_id: str


class AgentStartEvent(TypedDict):
    """Emitted at the top of `Runner.run_turn()` for each agent."""
    type: Literal["agent_start"]
    timestamp: str
    session_id: str
    agent: str
    parent: str | None
    depth: int
    model: str
    spawn_index: int


class AgentEndEvent(TypedDict):
    """Emitted when `Runner.run_turn()` returns (success or error)."""
    type: Literal["agent_end"]
    timestamp: str
    session_id: str
    agent: str
    depth: int
    # Optional payload (PEP 655 NotRequired — `error` may be absent
    # on success, `result_preview` may be empty on error; the header
    # fields above are always present).
    steps_used: NotRequired[int]
    duration_ms: NotRequired[int]
    result_preview: NotRequired[str]
    error: NotRequired[str | None]


class ChatRequestEvent(TypedDict):
    """Emitted before `provider.chat()` is invoked."""
    type: Literal["chat_request"]
    timestamp: str
    session_id: str
    messages_count: int
    tools_count: int
    model: str


class ChatResponseEvent(TypedDict):
    """Emitted after `provider.chat()` returns."""
    type: Literal["chat_response"]
    timestamp: str
    session_id: str
    # `model` is emitted at every site but some legacy sites (pre-2026-04
    # consultant_cli graph_runner path) omit it — keep optional for
    # backwards-compat replay.
    model: NotRequired[str]
    input_tokens: NotRequired[int]
    output_tokens: NotRequired[int]
    cache_read_tokens: NotRequired[int]
    label: NotRequired[str]
    output_text: NotRequired[str]


class ToolCallStartEvent(TypedDict):
    """Emitted before a tool's `execute()` is invoked."""
    type: Literal["tool_call_start"]
    timestamp: str
    session_id: str
    agent: str
    depth: int
    tool_name: str
    input_preview: str
    input: dict[str, Any]


class ToolCallEndEvent(TypedDict):
    """Emitted after a tool's `execute()` returns (success or error)."""
    type: Literal["tool_call_end"]
    timestamp: str
    session_id: str
    agent: str
    depth: int
    tool_name: str
    duration_ms: int
    output_len: int
    is_error: bool
    # Opt-in payload — only present when `tool.emit_output_in_trace`
    # AND output is <= 65536 bytes (see the service).
    output: NotRequired[str]
    # D1 trace-replay payload — full result text (separate from
    # `output`), capped at 200KB.
    result_text: NotRequired[str]


class SessionStartEvent(TypedDict):
    """Emitted at the top of `Session.run()` for the root agent."""
    type: Literal["session_start"]
    timestamp: str
    session_id: str
    agent_name: str
    prompt_preview: str
    max_concurrent_agents: int
    max_spawn_depth: int
    max_total_steps: int | None


class SessionEndEvent(TypedDict):
    """Emitted when `Session.run()` returns (success or error)."""
    type: Literal["session_end"]
    timestamp: str
    session_id: str
    agent_name: str
    total_steps: int
    duration_ms: int
    # On success `error` is None; on error `result_preview` is "".
    # Both are always present in the emit-site dict (see the service
    # line 489-498), so they're required even though they vary in
    # truthiness.
    result_preview: str
    error: str | None


class StepStartEvent(TypedDict):
    """Emitted on each Runner-loop iteration (per LLM round-trip)."""
    type: Literal["step_start"]
    timestamp: str
    session_id: str
    agent: str
    depth: int
    step: int
    max_steps: int


class CostBandSummaryEvent(TypedDict):
    """Emitted at agent_end with the cumulative-estimate-tokens band."""
    type: Literal["cost_band_summary"]
    timestamp: str
    session_id: str
    agent: str
    depth: int
    total_estimated_tokens: int
    band: str  # "tier_1" | "tier_2" | "tier_3"
    threshold: int
    estimate_calls: int
    user_consulted: bool


# ── Sprint 5 / Item 1 — TypedDicts for the remaining 26 event ────
# types beyond the top-10. Sprint 4 documented these as deferred
# carryover; this sprint closes the gap. Each shape was derived
# from the canonical emit site (see comment on each class). All
# follow the same pattern as the top-10:
#
#   - Required: `type` (Literal discriminator), `timestamp`,
#     `session_id` header (where the emitter has one).
#   - Optional / per-event payload: marked `NotRequired[...]`.
#
# The wider `TraceEvent` union below now covers all 36 event types
# emitted from `master_agents` source. `Tracer.emit` keeps its
# `dict[str, Any]` parameter for v1 LSP compatibility with the 7
# subclass overrides; emit sites stay loose-dict for now (mypy
# doesn't auto-coerce dict literals to TypedDicts). A future sprint
# can tighten `emit` once the four large files (the service,
# remote_cli.py, the service, cli.py) decompose and per-site
# typed constructors become opportunistic.


class AgentSwitchEvent(TypedDict):
    """ — `interactive.set_master(...)` switched the active
    master mid-session. Carries the (previous, new) names."""
    type: Literal["agent_switch"]
    timestamp: str
    session_id: str
    previous_agent: str
    new_agent: str


class CostBudgetBreachEvent(TypedDict):
    """Emitted by the runner's cost-tracker when the spec's
    `cost_budget` is breached. `on_breach` records the configured
    remediation (`"abort"` | `"ask"` | `"warn"`)."""
    type: Literal["cost_budget_breach"]
    timestamp: str
    session_id: NotRequired[str | None]
    spec: str
    breach_reason: str
    cap_value: float
    observed_value: float
    on_breach: str


class CriticLoopIterationEvent(TypedDict):
    """Emitted at the end of each critic-loop iteration in
    `Session._run_critic_loop`. `converged=True` is the terminal
    iteration; `False` will be followed by another iteration up
    to `max_iterations`."""
    type: Literal["critic_loop_iteration"]
    timestamp: str
    session_id: str
    agent: str
    depth: int
    iteration: int
    converged: bool


class ForcedRouteEvent(TypedDict):
    """Emitted by the runner when a router/forced-routing rule
    matched and is about to spawn the target. `prompt_preview` is
    the first ~120 chars of the user prompt."""
    type: Literal["forced_route"]
    timestamp: str
    session_id: str
    agent: str
    depth: int
    target: str
    prompt_preview: str


class GraphNodeValidatorEvent(TypedDict):
    """Emitted by `graph_runner` after each node-validator pass.
    `verdict` is one of `"PASS"` | `"REVISE"` | `"FAIL"`;
    `revision` is the iteration counter (0 = first pass)."""
    type: Literal["graph_node_validator"]
    timestamp: str
    node_id: str
    verdict: str
    reason: str
    revision: int


class HistoryCompactionEvent(TypedDict):
    """Emitted by `InteractiveSession.compact_history` when the
    compaction threshold trips. The `*_tokens` fields are the
    estimator's pre/post counts; `summary_tokens` is the size of
    the LLM-generated summary."""
    type: Literal["history_compaction"]
    timestamp: str
    removed_messages: int
    before_tokens: int
    after_tokens: int
    summary_tokens: int


class MaxStepsSoftLandingEvent(TypedDict):
    """Emitted by the runner when the step loop hits
    `effective_max_steps` and the soft-landing system prompt is
    injected to force a final answer."""
    type: Literal["max_steps_soft_landing"]
    timestamp: str
    session_id: str
    agent: str
    depth: int
    steps_used: int
    max_steps: int


class PipelineCapBreachedEvent(TypedDict):
    """ — emitted when the session-wide token cap is exceeded
    and a tool call is halted. `used` / `cap` are cumulative
    session tokens at the breach."""
    type: Literal["pipeline_cap_breached"]
    timestamp: str
    session_id: str
    agent: str
    depth: int
    tool_name: str
    used: int
    cap: int


class PipelineStageCompleteEvent(TypedDict):
    """Emitted by `Session._run_pipeline` after each stage
    completes. `stage_index` is 0-based, `stage_agent` is the
    spec name that ran."""
    type: Literal["pipeline_stage_complete"]
    timestamp: str
    session_id: str
    agent: str
    depth: int
    stage_index: int
    stage_agent: str


class ProviderRetryEvent(TypedDict):
    """Emitted by the session's provider-call retry loop when a
    transient provider error (rate-limit, server, timeout) is
    being retried. `wait_seconds` is the backoff for THIS attempt."""
    type: Literal["provider_retry"]
    timestamp: str
    session_id: str
    model: str
    attempt: int
    max_attempts: int
    wait_seconds: float
    error_class: str
    error_message: str
    retry_after_supplied: NotRequired[float | None]


class RemoteToolDelegationEvent(TypedDict):
    """Emitted on the server side when a tool call is delegated
    to the client (RemoteToolWrapper). `input_preview` is the
    first ~200 chars of the kwargs."""
    type: Literal["remote_tool_delegation"]
    timestamp: str
    tool_name: str
    input_preview: str


class RetrievalEvent(TypedDict):
    """Emitted by RAG agents after a retrieval pass. `keywords`
    is the query expansion; `hits_per_path` is a per-corpus
    histogram; `total_chars` is the assembled context size;
    `truncated` indicates the budget cap was hit."""
    type: Literal["retrieval"]
    timestamp: str
    session_id: str
    keywords: list[str]
    hits_per_path: dict[str, int]
    total_chars: int
    truncated: bool


class RouterClassifyEvent(TypedDict):
    """Emitted by `Session._run_router` after the classifier LLM
    returns. `verdict_raw` is the first 200 chars of the model's
    response; `chosen` is the parsed target name; `matched`
    indicates whether `chosen` matched a routing rule (False ->
    fall through to default_target)."""
    type: Literal["router_classify"]
    timestamp: str
    session_id: str
    agent: str
    verdict_raw: str
    chosen: str
    matched: bool


class RouterDispatchEvent(TypedDict):
    """Emitted by `Session._run_router` immediately before
    spawning the chosen target."""
    type: Literal["router_dispatch"]
    timestamp: str
    session_id: str
    agent: str
    target: str


class SessionCancelRequestedEvent(TypedDict):
    """Emitted by `Session.cancel()` when an external cancellation
    flag is set. The runner's pre-LLM-step hook polls this and
    raises `SessionCancelled` to unwind cleanly."""
    type: Literal["session_cancel_requested"]
    timestamp: str
    session_id: str


class TextDeltaEvent(TypedDict):
    """Emitted from streaming-provider responses as text chunks
    arrive. `ConsoleTracer.emit` consumes these via the streaming
    markdown buffer (see `tracer.py:364`)."""
    type: Literal["text_delta"]
    timestamp: NotRequired[str]
    session_id: NotRequired[str]
    text: str


class ToolCallBlockedByCeilingEvent(TypedDict):
    """ — emitted when the per-turn input-token ceiling is
    exceeded and a tool call is blocked. The runner forces a
    finalize after this point."""
    type: Literal["tool_call_blocked_by_ceiling"]
    timestamp: str
    session_id: str
    agent: str
    depth: int
    tool_name: str


class ToolCallBlockedByCostGateEvent(TypedDict):
    """ — emitted when the cost-band tier_3 gate auto-rejects
    an expensive tool call. `tier` is always `"tier_3"` here
    (tier_1 is silent; tier_2 is `cost_band_summary`)."""
    type: Literal["tool_call_blocked_by_cost_gate"]
    timestamp: str
    session_id: str
    agent: str
    depth: int
    tool_name: str
    tier: str
    total_estimated_tokens: int
    threshold: int


class ToolCallBlockedByNonInteractiveEvent(TypedDict):
    """Emitted when `ask_user` is invoked on a non-interactive
    session (e.g., `mao-client remote run` HTTP one-shot). The
    agent backs off with stated assumptions."""
    type: Literal["tool_call_blocked_by_non_interactive"]
    timestamp: str
    session_id: str
    agent: str
    depth: int
    tool_name: str


class ToolCallBlockedByPlanModeEvent(TypedDict):
    """Emitted when a mutating tool is invoked while plan_mode
    is active. The agent should produce a plan as text instead
    of mutating state."""
    type: Literal["tool_call_blocked_by_plan_mode"]
    timestamp: str
    session_id: str
    agent: str
    depth: int
    tool_name: str


# Wave B Phase 1 (2026-05-17) — plan-mode state-machine events.
# Emitted by the plan_emit tool handler (plan_emitted) and the
# future Phase 2 server gate (plan_approved / plan_rejected). The
# Phase 1 ship leaves plan_approved + plan_rejected unused on
# emit but pinned in the union so Phase 2 can fire them without a
# union widening.

class PlanEmittedEvent(TypedDict):
    """Emitted when the agent calls plan_emit, transitioning the
    session's plan_state from PLANNING to AWAITING_APPROVAL.

    `manifest_bytes` is the byte size of the JSON-encoded manifest
    (useful for cost forensics + size-cap regression detection).
    The full manifest is NOT inlined in the event — it lives in
    Session.plan_manifest and surfaces via the /sessions/{id}/plan
    endpoint (Phase 2).
    """
    type: Literal["plan_emitted"]
    timestamp: str
    session_id: str
    agent: str
    tool_calls_count: int
    manifest_bytes: int


class PlanApprovedEvent(TypedDict):
    """Emitted when the user approves a pending plan, transitioning
    plan_state from AWAITING_APPROVAL to APPROVED. Phase 2 surface
    — pinned now so the union is stable when the server gate ships.

    `approved_by` is "user" for /approve from the CLI or web, "auto"
    for /auto-mode auto-approval (architect's recommendation:
    plan beats /auto in priority; /auto during plan mode skips
    /approve but doesn't bypass plan mode).
    """
    type: Literal["plan_approved"]
    timestamp: str
    session_id: str
    approved_by: Literal["user", "auto"]


class PlanRejectedEvent(TypedDict):
    """Emitted when the user rejects a pending plan, transitioning
    plan_state from AWAITING_APPROVAL back to PLANNING (re-plan).
    Phase 2 surface — pinned now for union stability.

    `reason` is the free-text rejection reason from the user (may be
    empty if the user pressed /reject without a message).
    """
    type: Literal["plan_rejected"]
    timestamp: str
    session_id: str
    reason: str


# Wave C Phase 1 (2026-05-17) — /loop autonomous-iteration events.
# Phase-1 server fires loop_start + loop_terminated; loop_iteration_*
# events are deferred to Phase 2 when the chat REPL drives iterations.

class LoopStartEvent(TypedDict):
    """Emitted when POST /sessions/{id}/loop/start fires, transitioning
    loop_state from INACTIVE/STOPPED to RUNNING."""
    type: Literal["loop_start"]
    timestamp: str
    session_id: str
    max_iterations: int
    condition_str: str


class LoopTerminatedEvent(TypedDict):
    """Emitted when /sessions/{id}/loop/stop fires OR when the client
    posts terminal /loop/stop after the break condition or
    max_iterations fired. `break_reason` is one of: break_condition_fired
    / max_iterations_reached / user_stop / cost_budget_exceeded."""
    type: Literal["loop_terminated"]
    timestamp: str
    session_id: str
    break_reason: str
    iteration_count: int


class ToolCallCappedEvent(TypedDict):
    """ — emitted when a tool's per-turn call count exceeds
    `cap`. `calls_this_turn` is the count INCLUDING the one being
    capped."""
    type: Literal["tool_call_capped"]
    timestamp: str
    session_id: str
    agent: str
    depth: int
    tool_name: str
    calls_this_turn: int
    cap: int


class ToolCallDedupedEvent(TypedDict):
    """ — emitted when a tool is called with input bytes
    identical to a prior call this turn. The cached result is
    returned instead of re-executing."""
    type: Literal["tool_call_deduped"]
    timestamp: str
    session_id: str
    agent: str
    depth: int
    tool_name: str
    input_preview: str


class ToolCallGatedEvent(TypedDict):
    """Emitted when a tier-gated tool (e.g., PPTX, PDF generators)
    is invoked by an agent under a tier that doesn't grant access.
    `reason` is short ("standard_tier")."""
    type: Literal["tool_call_gated"]
    timestamp: str
    session_id: str
    agent: str
    depth: int
    tool_name: str
    tier: str
    reason: str


class ToolCallRejectedEvent(TypedDict):
    """ — emitted when a tool call's input fails JSON-schema
    validation. `reason` is the validation-error message."""
    type: Literal["tool_call_rejected"]
    timestamp: str
    session_id: str
    agent: str
    depth: int
    tool_name: str
    reason: str


class TurnTokenCeilingBreachedEvent(TypedDict):
    """ — emitted when the per-turn cumulative-input-tokens
    counter exceeds the ceiling. The runner injects a halting
    UserMessage so the next LLM call is forced to consolidate."""
    type: Literal["turn_token_ceiling_breached"]
    timestamp: str
    session_id: str
    agent: str
    depth: int
    tokens_used: int
    ceiling: int


class UserInputEvent(TypedDict):
    """Emitted by `InteractiveSession.send_user` at the start of
    every turn. `prompt` is preview-truncated to 8000 chars;
    `prompt_chars` is the full original length."""
    type: Literal["user_input"]
    timestamp: str
    session_id: NotRequired[str | None]
    agent: str
    prompt: str
    prompt_chars: int


# Discriminated union over all 36 event types emitted from
# `master_agents` source. Static-type-checking consumers can
# `match event["type"]:` and get a narrowed shape per branch.
# `Tracer.emit` keeps its `dict[str, Any]` parameter for now
# (LSP compatibility with 7 subclass overrides + emit-site
# migration is Sprint 6+ scope per the architectural-decomposition
# track); this union exists today as authoritative documentation
# + a regression-pin surface for any new event type.
TraceEvent = Union[
    # Top-10 (Sprint 3 / Item 4)
    AgentStartEvent,
    AgentEndEvent,
    ChatRequestEvent,
    ChatResponseEvent,
    ToolCallStartEvent,
    ToolCallEndEvent,
    SessionStartEvent,
    SessionEndEvent,
    StepStartEvent,
    CostBandSummaryEvent,
    # Sprint 5 / Item 1 — remaining 26
    AgentSwitchEvent,
    CostBudgetBreachEvent,
    CriticLoopIterationEvent,
    ForcedRouteEvent,
    GraphNodeValidatorEvent,
    HistoryCompactionEvent,
    MaxStepsSoftLandingEvent,
    PipelineCapBreachedEvent,
    PipelineStageCompleteEvent,
    ProviderRetryEvent,
    RemoteToolDelegationEvent,
    RetrievalEvent,
    RouterClassifyEvent,
    RouterDispatchEvent,
    SessionCancelRequestedEvent,
    TextDeltaEvent,
    ToolCallBlockedByCeilingEvent,
    ToolCallBlockedByCostGateEvent,
    ToolCallBlockedByNonInteractiveEvent,
    ToolCallBlockedByPlanModeEvent,
    PlanEmittedEvent,
    PlanApprovedEvent,
    PlanRejectedEvent,
    LoopStartEvent,
    LoopTerminatedEvent,
    ToolCallCappedEvent,
    ToolCallDedupedEvent,
    ToolCallGatedEvent,
    ToolCallRejectedEvent,
    TurnTokenCeilingBreachedEvent,
    UserInputEvent,
]


# Public type-aliases for the discriminator literals — re-usable in
# `match` statements and `if event["type"] in (…,)` filters.
TraceEventType = Literal[
    # Top-10
    "agent_start",
    "agent_end",
    "chat_request",
    "chat_response",
    "tool_call_start",
    "tool_call_end",
    "session_start",
    "session_end",
    "step_start",
    "cost_band_summary",
    # Sprint 5 / Item 1 — remaining 26
    "agent_switch",
    "cost_budget_breach",
    "critic_loop_iteration",
    "forced_route",
    "graph_node_validator",
    "history_compaction",
    "max_steps_soft_landing",
    "pipeline_cap_breached",
    "pipeline_stage_complete",
    "provider_retry",
    "remote_tool_delegation",
    "retrieval",
    "router_classify",
    "router_dispatch",
    "session_cancel_requested",
    "text_delta",
    "tool_call_blocked_by_ceiling",
    "tool_call_blocked_by_cost_gate",
    "tool_call_blocked_by_non_interactive",
    "tool_call_blocked_by_plan_mode",
    # Wave B Phase 1 (2026-05-17) — plan-mode state-machine events.
    "plan_emitted",
    "plan_approved",
    "plan_rejected",
    # Wave C Phase 1 (2026-05-17) — autonomous-iteration events
    "loop_start",
    "loop_terminated",
    "tool_call_capped",
    "tool_call_deduped",
    "tool_call_gated",
    "tool_call_rejected",
    "turn_token_ceiling_breached",
    "user_input",
]


def now_iso() -> str:
    """Return current UTC time as ISO-8601 with Z suffix, millisecond precision."""
    t = time.time()
    base = time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(t))
    ms = int((t - int(t)) * 1000)
    return f"{base}.{ms:03d}Z"


def new_session_id() -> str:
    return uuid.uuid4().hex[:16]


def preview(text: str, limit: int = 120) -> str:
    """Trim long text for event payloads. Preserves first `limit` chars."""
    if text is None:
        return ""
    if len(text) <= limit:
        return text
    return text[:limit] + "...[truncated]"


class Tracer(ABC):
    """Abstract tracer. Implementations emit events to some sink."""

    @abstractmethod
    def emit(self, event: dict[str, Any]) -> None:
        """Emit one event. Implementations must be safe to call from multiple
        tasks/agents concurrently.

        `event` is a JSON-serialisable dict. Sprint 3 / Item 4 added
        TypedDicts (above — `AgentStartEvent`, `ToolCallEndEvent`, etc.)
        documenting the field schema for the top-10 most frequently-
        emitted event types. They are READ-ONLY documentation in v1 —
        emit sites continue to use dict literals, and the base signature
        stays loose to keep the LSP contract simple for the 7 Tracer
        subclasses (NoopTracer/StreamTracer/ConsoleTracer/MultiTracer/
        LiveTracer/ProgressTracer/QueueTracer). Migration of consumers
        to narrow on the discriminated union is a follow-up sprint.
        """

    def close(self) -> None:
        """Release any resources. Default no-op."""


class NoopTracer(Tracer):
    """Default tracer. Drops everything."""

    def emit(self, event: dict[str, Any]) -> None:
        pass


class ConsoleTracer(Tracer):
    """Human-friendly live tracer for interactive CLI use.

    Prints concise one-liners for subagent spawns / completions and tool
    calls that happen below the root agent. Silent for root-level chat
    events (those would be noise — the user just cares about delegation).

    Uses ANSI color codes by default; pass `color=False` for plain output.
    """

    def __init__(
        self,
        stream: TextIO | None = None,
        color: bool = True,
        *,
        min_depth: int = 1,
        markdown: bool = True,
    ) -> None:
        self._stream = stream or sys.stderr
        self._color = color
        # Local chat hides root-level noise (the user just issued the prompt).
        # Remote chat passes min_depth=0 so root-only agents (no subagents)
        # still show tool-call activity instead of running silently.
        self._min_depth = min_depth
        # streaming markdown buffer for `text_delta` events.
        # Lazy: only initialised on the first text_delta we see, so
        # the rich import doesn't cost anything for sessions without
        # streaming text deltas.
        self._markdown = markdown
        # Lazy-init buffer; concrete type imported lazily by
        # `_get_md_buffer()` below to keep `rich` cost out of the
        # cold-start path. The forward-reference dance is needed
        # because the concrete `StreamingMarkdownBuffer` class is
        # imported inside the lazy initializer.
        self._md_buffer: Any = None

    def emit(self, event: dict[str, Any]) -> None:
        typ = event.get("type")
        depth = event.get("depth", 0) if isinstance(event.get("depth"), int) else 0
        if depth < self._min_depth:
            return

        # streaming markdown rendering. Buffer text deltas and
        # flush at safe markdown boundaries so partial bold/code
        # spans don't render as raw `**` / backticks. The buffer is
        # auto-flushed on session_end / agent_end events below.
        if typ == "text_delta":
            text = event.get("text", "")
            if not text:
                return
            buf = self._get_md_buffer()
            if buf is None:
                # Markdown disabled — write raw.
                self._stream.write(text)
                self._stream.flush()
            else:
                buf.feed(text)
            return

        # Flush the streaming markdown buffer when an agent or
        # session boundary arrives — guarantees no buffered text
        # leaks into the next conceptual chunk.
        if typ in ("agent_end", "session_end") and self._md_buffer is not None:
            self._md_buffer.flush()

        if typ == "agent_start":
            agent = event.get("agent", "?")
            parent = event.get("parent")
            # Root agents have parent=None (the user is the conceptual
            # parent). Showing "(from ?)" was cryptic; "(root)" makes it
            # immediately clear this is the top-level agent vs. a spawned
            # subagent.
            label = f"(from {parent})" if parent else "(root)"
            self._write_line(
                f"  ▸ spawning {agent} {label}", dim=True
            )
        elif typ == "agent_end":
            agent = event.get("agent", "?")
            dur = (event.get("duration_ms", 0) or 0) / 1000
            err = event.get("error")
            if err:
                self._write_line(
                    f"  ✗ {agent} failed: {err}", color_code="31"
                )
            else:
                self._write_line(
                    f"  ✓ {agent} done ({dur:.1f}s)", color_code="32"
                )
        elif typ == "step_start":
            # User feedback: 'thinking… not available' for short turns
            # where only step 1 fires. Show the indicator on every
            # step now — agent_start says 'spawning' (the agent is
            # being constructed), step_start says 'thinking' (the LLM
            # is being invoked). They mean different things.
            step = event.get("step", 0)
            max_steps = event.get("max_steps", "?")
            self._write_line(
                f"    ⋯ thinking (step {step}/{max_steps})", dim=True
            )
        elif typ == "tool_call_start":
            tool = event.get("tool_name", "?")
            if tool == "spawn_agent":
                return  # the agent_start event covers this
            preview_text = event.get("input_preview", "")
            self._write_line(
                f"    • {tool}({preview_text})", dim=True
            )
        elif typ == "pipeline_cap_breached":
            # surface session-wide spend halt prominently. Red ⊘
            # because this is a hard halt (no recovery without /cap raise
            # or /clear).
            tool = event.get("tool_name", "?")
            used = event.get("used", 0)
            cap = event.get("cap", 0)
            self._write_line(
                f"    ⊘ {tool} HALTED — session cap exceeded "
                f"({used:,} / {cap:,} tokens). Use /cap <larger> "
                f"or /clear.",
                color_code="31",
            )
        elif typ == "tool_call_blocked_by_cost_gate":
            # surface tier_2/tier_3 cost-gate rejections so the
            # user sees the runner's structural cost discipline firing.
            tool = event.get("tool_name", "?")
            tier = event.get("tier", "?")
            total = event.get("total_estimated_tokens", 0)
            self._write_line(
                f"    ⊘ {tool} (cost gate: {tier} — "
                f"{total:,} tokens estimated)",
                color_code="33",
            )
        elif typ == "cost_band_summary":
            # only emit a visible line for tier_2/tier_3, since
            # tier_1 is the silent "all good" band; the indicator at the
            # token-line footer is enough for tier_1. Suppress for nested
            # specialists (depth > 0) to reduce noise.
            if event.get("depth", 0) != 0:
                return
            band = event.get("band", "tier_1")
            if band == "tier_1":
                return
            total = event.get("total_estimated_tokens", 0)
            threshold = event.get("threshold", 0)
            if band == "tier_2":
                self._write_line(
                    f"    ⊘ cost band tier_2 — {total:,} estimated tokens "
                    f"over {threshold:,} budget; user consultation required",
                    color_code="33",
                )
            else:  # tier_3
                self._write_line(
                    f"    ⊘ cost band tier_3 — {total:,} estimated tokens "
                    f"over {threshold * 2:,} hard cap; auto-rejected",
                    color_code="31",
                )
        elif typ in ("tool_call_capped", "tool_call_deduped", "tool_call_rejected"):
            #  visibility: render the runner's poka-yoke guards so
            # the user can see WHY a turn isn't progressing instead of
            # staring at silent "thinking" lines while the LLM hits
            # caps. Yellow ⊘ glyph distinguishes from successful tool
            # calls (• dim) and failures (✗ red).
            tool = event.get("tool_name", "?")
            if tool == "spawn_agent":
                return
            label = {
                "tool_call_capped": (
                    f"capped at {event.get('cap', '?')} per turn"
                ),
                "tool_call_deduped": "deduplicated — used cached result",
                "tool_call_rejected": (
                    "rejected: " + event.get("reason", "?")[:80]
                ),
            }.get(typ, typ)
            self._write_line(
                f"    ⊘ {tool} ({label})", color_code="33"
            )
        elif typ == "tool_call_end":
            # Render failures in red so the user can scan them at a
            # glance — common for write-path tools when the client's
            # writable_paths rejects an absolute target, or for read
            # tools when the path doesn't exist on the local fs (e.g.
            # user pasted a path from a different machine). Successes
            # stay silent to avoid noise; the agent's answer is the
            # natural success signal.
            if not event.get("is_error"):
                return
            tool = event.get("tool_name", "?")
            if tool == "spawn_agent":
                return  # agent_end covers spawn failures
            err = event.get("error", "(unknown error)")
            self._write_line(
                f"    ✗ {tool} failed: {err}", color_code="31"
            )

    def _write_line(
        self, text: str, *, color_code: str = "", dim: bool = False
    ) -> None:
        if self._color and (color_code or dim):
            prefix = "\x1b[2m" if dim else f"\x1b[{color_code}m"
            self._stream.write(f"{prefix}{text}\x1b[0m\n")
        else:
            self._stream.write(f"{text}\n")
        self._stream.flush()

    def _get_md_buffer(self) -> Any:
        """Lazily create the StreamingMarkdownBuffer on first
        text_delta. Returns None if markdown rendering is disabled
        (the caller writes raw). Return type is `Any` because the
        concrete `StreamingMarkdownBuffer` class is imported lazily
        inside this method to keep `rich` out of the cold-start
        import path."""
        if not self._markdown:
            return None
        if self._md_buffer is None:
            from ._streaming_markdown import StreamingMarkdownBuffer
            self._md_buffer = StreamingMarkdownBuffer(
                stream=self._stream, color=self._color,
            )
        return self._md_buffer

    def close(self) -> None:
        # make sure any buffered streaming text gets flushed
        # when the tracer is closed (e.g. session shutdown).
        if self._md_buffer is not None:
            try:
                self._md_buffer.flush()
            except Exception:
                pass


ProgressCallback = Callable[[str], Awaitable[None]]
