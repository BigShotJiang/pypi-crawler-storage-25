"""`mao-client remote run` (one-shot, non-interactive) command
handler -- extracted from `remote_cli.py` as Sprint 9e (fifth slice
of the Sprint 9 commands/repl/run decomposition).

Two names live here:
  - `_build_headless_approval_callback(policy)` -- maps
    `--approve-tool-calls {ask,allow,deny}` to the async callback
    `RemoteSessionClient` expects when the agent emits a
    `needs_approval` event mid-turn. None for "ask" (caller
    raises); auto-True for "allow"; auto-False for "deny".
  - `_cmd_remote_run(args)` -- the `remote run` subcommand entry
    point. Loads config, builds a one-shot `RemoteSessionClient`,
    dispatches the agent against the prompt (or --prompt-file
    content), and prints the final answer. Handles
    `SessionEndedError` gracefully with resume hints.

`RemoteSessionClient` + `SessionEndedError` are LAZILY imported
inside `_cmd_remote_run` to avoid a module-load-time circular dep
between this module and `_remote_cli/client.py` (same pattern as
`_remote_cli/progress.py` / `_remote_cli/routine.py`).

Re-exported from `master_agents_client.remote_cli` via the facade.

Extraction history: Sprint 9e (informal; fifth slice of Sprint 9),
2026-05-16, branched off `v3.24.1` main tip. VERBATIM from
`remote_cli.py:149-349`. Prerequisite cleanup also lands in this
commit: `DEFAULT_ACTIVE_SESSION_PATH` + the 3 active-session
helpers (`_save_active_session` / `_load_active_session` /
`_clear_active_session`) moved from `remote_cli.py:114-170` to
`_remote_cli/session_state.py` so this module can import them
as siblings.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Any

from .auth import _resolve_master
from .config import load_remote_config
from .mode_a import format_mode_a_warning, should_emit_mode_a_warning
from .session_state import (
    _config_path,
    _save_active_session,
    read_last_session_id,
    write_last_session_id,
)


def _build_headless_approval_callback(
    policy: str,
) -> Any | None:
    """Return an async on_needs_approval callback for headless dispatch.

    Maps `--approve-tool-calls` value to the callback `RemoteSessionClient`
    expects:
      - "ask"   -> None (caller raises RuntimeError on needs_approval --
                  the original, backward-compatible behaviour).
      - "allow" -> async fn returning True (auto-approve every event).
      - "deny"  -> async fn returning False (auto-reject every event).

    Any other value falls back to "ask" with a stderr warning so a
    typo'd flag never silently flips the policy to "allow."
    """
    if policy == "allow":
        async def _allow(tool_name: str, preview_text: str) -> bool:
            # Stderr breadcrumb so an operator scanning logs can see
            # which tool calls were auto-approved. Preview text is
            # often a multi-line YAML block -- truncate hard so a
            # screen of output doesn't drown the log.
            print(
                f"[remote run] auto-approving tool {tool_name!r} "
                f"(preview: {preview_text[:120]!r}...)",
                file=sys.stderr,
            )
            return True
        return _allow
    if policy == "deny":
        async def _deny(tool_name: str, preview_text: str) -> bool:
            print(
                f"[remote run] auto-denying tool {tool_name!r} "
                f"(preview: {preview_text[:120]!r}...)",
                file=sys.stderr,
            )
            return False
        return _deny
    if policy != "ask":
        # Defensive -- argparse `choices=[...]` should make this
        # unreachable, but a misconfigured caller (e.g. a wrapper
        # script forwarding stale strings) shouldn't silently get
        # "allow." Fall through to "ask" with a warning.
        print(
            f"[remote run] unknown --approve-tool-calls value "
            f"{policy!r}; falling back to 'ask'.",
            file=sys.stderr,
        )
    return None


async def _cmd_remote_run(args: Any) -> int:
    # Lazy import bounds the run.py <-> client.py cycle. Same pattern
    # as _run_bg_task in progress.py and _routine_run_all in routine.py.
    from .client import RemoteSessionClient, SessionEndedError

    cfg = load_remote_config(_config_path(args))

    # E86 (2026-05-16) -- `--prompt-file PATH` reads prompt content
    # from a file instead of the positional argv arg. Required for
    # prompts that exceed the OS command-line length limit (Windows
    # ~32 KB; the cap that surfaced in Sprint 1d dispatch where a
    # 23 KB planner output triggered `[WinError 206] The filename
    # or extension is too long`). When both --prompt-file and the
    # positional `prompt` are supplied, --prompt-file wins.
    prompt_file = getattr(args, "prompt_file", None)
    if prompt_file:
        try:
            args.prompt = Path(prompt_file).read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError) as exc:
            print(
                f"mao-client remote run: --prompt-file could not read "
                f"{prompt_file!r}: {type(exc).__name__}: {exc}",
                file=sys.stderr,
            )
            return 2

    # - headless approval policy. `mao-client remote run` is the
    # non-interactive entry point: when the agent emits a
    # `needs_approval` event mid-turn (tool-call requires explicit
    # approval per server policy), there is no human at a REPL to
    # answer. Pre- the dispatch crashed with
    # `RuntimeError: agent requested approval but no
    # on_needs_approval callback is registered`, taking the entire
    # answer down with it (UAT-B 2026-05-11 incident: 15 sim_builder
    # dispatches blocked at this gate).
    #
    # `--approve-tool-calls {ask,allow,deny}` lets the caller pick the
    # policy explicitly:
    #   - ask   (default, backward-compatible): no callback -> raise.
    #   - allow: auto-approve every needs_approval event.
    #   - deny:  auto-reject every needs_approval event.
    # The server's tier-key writable_paths + tool inventory are still
    # the security boundary -- this flag only decides what the *client*
    # answers when the server asks. Callers who pick `allow` should
    # have already reviewed the agent's tool surface.
    approval_policy = getattr(args, "approve_tool_calls", "ask")
    on_needs_approval = _build_headless_approval_callback(approval_policy)

    client = RemoteSessionClient(
        base_url=cfg.server,
        token=cfg.token,
        cwd=Path(os.getcwd()),
        writable_paths=cfg.writable_paths,
        on_needs_approval=on_needs_approval,
        # E48 (2026-05-14): default True; `--no-project-context` flips
        # it to False on the args namespace. Older client versions
        # without the flag still set the kwarg via getattr default.
        project_context=bool(getattr(args, "project_context", True)),
        # E47 (2026-05-14): forward the loaded permissions block.
        # None / empty in legacy configs -> no engine attached. Use
        # getattr for back-compat with test SimpleNamespace stubs
        # that predate the field.
        permissions=getattr(cfg, "permissions", None),
        # K.1 (Wave K, 2026-05-18): forward security policy blocks.
        # None / absent in config -> built-in safe defaults.
        call_home_policy=getattr(cfg, "call_home_policy", None),
        tool_sequence_policy=getattr(cfg, "tool_sequence_policy", None),
    )
    master = await _resolve_master(cfg, args, interactive=False)
    if not master:
        return 2

    # Resolve --resume / --resume-last -> concrete session_id (or None).
    resume_session_id = getattr(args, "resume", None)
    if not resume_session_id and getattr(args, "resume_last", False):
        resume_session_id = read_last_session_id(master)
        if resume_session_id is None:
            print(
                f"--resume-last: no detached session found for master "
                f"{master!r}. Run with --detach first.",
                file=sys.stderr,
            )
            return 2

    detach = getattr(args, "detach", False)

    try:
        result = await client.run(
            master,
            args.prompt,
            cap=getattr(args, "cap", None),
            threshold_ask_user=getattr(args, "threshold_ask_user", None),
            threshold_max_steps=getattr(args, "threshold_max_steps", None),
            max_output_tokens=getattr(args, "max_output_tokens", None),
            threshold_total_steps=getattr(args, "threshold_total_steps", None),
            threshold_turn_input=getattr(args, "threshold_turn_input", None),
            threshold_auto_compact=getattr(args, "threshold_auto_compact", None),
            model=getattr(args, "model", None),
            detach=detach,
            resume_session_id=resume_session_id,
        )
    except SessionEndedError as exc:
        # Server cancelled mid-flight (F1 timeout, container restart,
        # explicit cancel). NOT a client bug -- exit cleanly with a
        # one-line message instead of a Python traceback that confuses
        # operators. Exit code 1 still signals "this dispatch did not
        # complete" so scripts can detect it; just no stack noise.
        #
        # E39 (2026-05-13): surface the session_id + resume hints. The
        # session is fully recoverable from Postgres via the rehydrate
        # endpoint, but the user has to know its id. Auto-arm BOTH
        # storage paths so `--resume <id>` AND `--resume-last` work
        # after abnormal end (the explicit-detach branch only writes
        # both, so the recovery surfaces match).
        session_id = client.session_id
        nonce = client.nonce
        if session_id and nonce:
            _save_active_session(
                server=cfg.server,
                agent_name=master,
                session_id=session_id,
                nonce=nonce,
            )
            write_last_session_id(master, session_id)
            print(
                f"[Session ended] {exc}\n"
                f"  session_id={session_id}\n"
                f"  Resume with: agents remote chat --resume {session_id}\n"
                f"  Or:          agents remote chat --resume-last",
                file=sys.stderr,
            )
        else:
            # Session never reached server (auth fail, network 500
            # pre-create, etc.). No id to surface; no resume possible.
            print(f"[Session ended] {exc}", file=sys.stderr)
        return 1
    print(result)

    # Item 2 -- Mode-A post-processor (E5). Deterministic warning
    # on stderr when a plan-shaped agent received a Mode-A brief
    # AND failed to reach PHASE 5. Independent of agent prompt
    # behaviour; fires regardless of where the agent terminated.
    if should_emit_mode_a_warning(
        master=master, prompt=args.prompt, output=result,
    ):
        print(format_mode_a_warning(master=master), file=sys.stderr)

    # Lifecycle footer on stderr -- keeps stdout clean for piping.
    session_id = getattr(client, "_session_id", None)
    if detach and session_id:
        write_last_session_id(master, session_id)
        print(
            f"[Session detached] session_id={session_id} "
            f"-- resume with --resume {session_id} (or --resume-last)",
            file=sys.stderr,
        )
    else:
        print("[Session closed]", file=sys.stderr)
    return 0
