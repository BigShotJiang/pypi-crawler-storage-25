"""Interactive `mao-client remote chat` REPL implementation --
extracted from `remote_cli.py` as Sprint 9f (sixth and FINAL
slice of the Sprint 9 commands/repl/run decomposition).

Phase 1 backlog item #5 (2026-05-16, v3.32.0): the original
single-file 2603-LoC extraction is split into three sub-modules:
  - `chat_parsers.py` — pure parsers + `_REMOTE_CHAT_HELP`
  - `chat_resume.py`  — session-resume + agent-capabilities helpers
  - `chat.py`         — the REPL (this file)

Re-exported names (back-compat — Sprint 9f-era callers still
import these from `master_agents_client._remote_cli.chat`):

From `chat_parsers`:
  - `_REMOTE_CHAT_HELP` -- multi-line help string for `/help`.
  - `_parse_cap_arg(arg)` -- parse `--cap` values.
  - `_parse_budget_arg(arg)` -- parse `--threshold-ask-user` /
    `--budget` values.

From `chat_resume`:
  - `_fetch_agent_details(cfg, agent_name)` -- fetch master spec
    details from `GET /agents`.
  - `_print_capabilities(details, *, color)` -- render capabilities.
  - `_rehydrate_specific(client, session_id)` -- rehydrate by id.
  - `_try_resume_active_session(client, current_server)` -- offer
    to resume the cached active session.

Defined here:
  - `_cmd_remote_chat(args)` -- the main interactive REPL.

`RemoteSessionClient` is LAZILY imported inside `_cmd_remote_chat`
to avoid a module-load-time circular dep with
`_remote_cli/client.py` (same pattern as `progress.py` /
`routine.py` / `run.py`).

Re-exported from `master_agents_client.remote_cli` via the facade.

Extraction history: Sprint 9f (informal; sixth slice of Sprint 9
-- closes Sprint 9 sub-module ledger AND closes Phase 1 of the
god-module refactor), 2026-05-16, branched off `v3.24.2` main tip.
Backlog item #5 (2026-05-16, v3.32.0) split into 3 sub-modules.
"""

from __future__ import annotations

import asyncio
import getpass
import json
import os
import sys
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, cast

import httpx
import yaml

from .._paths import master_agents_home
from ..remote_client import DEFAULT_CLIENT_SIDE_TOOLS, RemoteToolExecutor
from ..tools import BUILTINS
from ..tracer import ConsoleTracer, Tracer

from .auth import _resolve_master
from .chat_parsers import (
    _REMOTE_CHAT_HELP,
    _parse_budget_arg,
    _parse_cap_arg,
)
from .chat_resume import (
    _fetch_agent_details,
    _print_capabilities,
    _rehydrate_specific,
    _try_resume_active_session,
)
from .config import RemoteConfig, load_remote_config, save_remote_config
from .mode_a import format_mode_a_warning, should_emit_mode_a_warning
from .picker import _format_age, _list_recent_sessions, _pick_session
from .progress import _BgTask, _execute_with_progress, _run_bg_task
from .prompts import (
    _defensive_kitty_disable,
    _draft_slot,
    _enable_kitty_keyboard_protocol,
    _has_draft,
    _make_prompt_reader,
    _pending_default_slot,
    _recall_draft,
    _save_draft,
    _set_pending_prompt_default,
    _take_pending_prompt_default,
)
from .render import (
    _format_cache_suffix,
    _format_cap_suffix,
    _format_cost_band_suffix,
    _format_ctx_suffix,
    _format_duration,
    _print_agent_separator,
    _print_answer,
    _print_remote_token_line,
    _print_separator,
    _print_user_separator,
    _surface_agent_question,
)
from .session_state import (
    DEFAULT_ACTIVE_SESSION_PATH,
    DEFAULT_REMOTE_CONFIG_PATH,
    _TOKEN_SUFFIXES,
    _clear_active_session,
    _config_path,
    _load_active_session,
    _save_active_session,
    last_session_file_path,
    parse_token_count,
    read_last_session_id,
    write_last_session_id,
)
from .sse import _parse_sse_chunk


async def _cmd_remote_chat(args) -> int:
    # Sprint 9f (2026-05-16): lazy import bounds the chat.py <->
    # client.py cycle to this function body. Same pattern as
    # progress.py / routine.py / run.py.
    from .client import RemoteSessionClient, SessionEndedError

    # defensive kitty pop. Belt-and-suspenders cleanup of any
    # leftover kitty keyboard mode pushed by a crashed pre-
    # process. No-op if the terminal isn't in kitty mode.
    _defensive_kitty_disable()
    # self-hosted refactor banner. When the agent is launched
    # from a master_agents_os repo checkout, surface the risk so the
    # user is reminded they're editing the agent's own source. No-op
    # for normal end-user installs.
    from .._self_host import is_self_hosted_repo
    if is_self_hosted_repo(Path(os.getcwd())):
        sys.stderr.write(
            "ℹ self-hosted refactor mode — cwd is a master_agents_os "
            "checkout. Edits to load-bearing modules (cli, runner, "
            "session, server, providers, agent, types) can break the "
            "running agent at next launch.  catches import-time "
            "errors automatically; behavioural bugs are still on you. "
            "Use docs/onramp/INSTALL_SELF_HOSTED.md's pattern for safer work.\n"
        )
        sys.stderr.flush()
    cfg = load_remote_config(_config_path(args))
    color = not getattr(args, "no_color", False)
    quiet = getattr(args, "quiet", False)
    markdown = not getattr(args, "no_markdown", False)
    show_diffs = not getattr(args, "no_diffs", False)
    # min_depth=0 so root-only agents (no subagents) still surface tool calls.
    # Local chat passes min_depth=1 because the user already issued the prompt
    # and root noise is redundant; here the user is staring at a blank prompt
    # waiting for the network round-trip, so any signal beats silence.
    tracer: Tracer | None = (
        None if quiet else ConsoleTracer(color=color, min_depth=0)
    )
    client = RemoteSessionClient(
        base_url=cfg.server,
        token=cfg.token,
        cwd=Path(os.getcwd()),
        writable_paths=cfg.writable_paths,
        tracer=tracer,
        heartbeat=not quiet and color,
        show_diffs=show_diffs and not quiet,
        diff_color=color,
        # E48 (2026-05-14): same passthrough as `remote run`.
        project_context=bool(getattr(args, "project_context", True)),
        # E47 (2026-05-14): same passthrough as `remote run`. getattr
        # for back-compat with test stubs predating the field.
        permissions=getattr(cfg, "permissions", None),
        # K.1 (Wave K, 2026-05-18): forward security policy blocks.
        # None / absent in config -> built-in safe defaults.
        call_home_policy=getattr(cfg, "call_home_policy", None),
        tool_sequence_policy=getattr(cfg, "tool_sequence_policy", None),
    )

    # Resume flow:
    #   1. If --new, skip resume entirely (Phase 1).
    #   2. If --resume <id>, rehydrate that specific id (Phase 2).
    #   3. If --resume-last, resolve master, read per-master last_session
    #      file, rehydrate (E39 — added 2026-05-13 hotfix; the
    #      original E39 added the flag to `remote run` only, leaving
    #      `remote chat` with a stale hint message that pointed at a
    #      flag the parser didn't have).
    #   4. If --pick, fetch /sessions list, show picker, rehydrate (Phase 2).
    #   5. Otherwise look at ~/.master_agents/active_session.json
    #      (Phase 1). If it points at THIS server, offer to resume.
    #      Try direct resume first; fall back to /rehydrate.
    #   6. Anything fails → silent fresh open.
    force_new = getattr(args, "new", False)
    resume_id = getattr(args, "resume_id", None)
    resume_last = getattr(args, "resume_last", False)
    pick = getattr(args, "pick", False)
    resumed_master: str | None = None

    if not force_new:
        if resume_id:
            resumed_master = await _rehydrate_specific(client, resume_id)
        elif resume_last:
            # --resume-last needs the master resolved first because the
            # last-session file is per-master (parity with --resume-last
            # in `remote run` at line ~1671).
            _rl_master = await _resolve_master(cfg, args, interactive=True)
            if not _rl_master:
                return 2
            _rl_last_id = read_last_session_id(_rl_master)
            if _rl_last_id is None:
                print(
                    f"--resume-last: no detached session found for master "
                    f"{_rl_master!r}. Run /detach in chat or pass --detach "
                    f"to `remote run` first; or pass --resume <id> if you "
                    f"have the id from a previous [Session ended] line.",
                    file=sys.stderr,
                )
                return 2
            resumed_master = await _rehydrate_specific(client, _rl_last_id)
            if resumed_master is None:
                # Server-side session gone (purged/expired). Fall through
                # to fresh open with the resolved master — printed warning
                # so the operator knows the recovery didn't fire.
                print(
                    f"--resume-last: stored session {_rl_last_id} no longer "
                    f"exists on the server. Starting a fresh session with "
                    f"master {_rl_master}.",
                    file=sys.stderr,
                )
        elif pick:
            picked = await _pick_session(cfg)
            if picked is not None:
                resumed_master = await _rehydrate_specific(
                    client, picked["session_id"],
                )
        else:
            resumed_master = await _try_resume_active_session(client, cfg.server)

    if resumed_master is not None:
        master = resumed_master
        print(
            f"remote chat with {master} @ {cfg.server} (resumed). "
            "/exit to quit, /detach to leave session alive, /help for commands."
        )
    else:
        master = await _resolve_master(cfg, args, interactive=True)
        if not master:
            return 2
        plan_mode = bool(getattr(args, "plan_mode", False))
        plan_hint = " [PLAN MODE — agent will emit plan + wait for /approve]" if plan_mode else ""
        print(
            f"remote chat with {master} @ {cfg.server}.{plan_hint} "
            "/exit to quit, /detach to leave session alive, /help for commands."
        )
        try:
            await client.open(master, plan_mode=plan_mode)
        except Exception as exc:
            print(
                f"Error opening session on {cfg.server}: {type(exc).__name__}: {exc}",
                file=sys.stderr,
            )
            return 1
    read_prompt = _make_prompt_reader()
    # `intent` controls what happens in the finally block:
    #   "destroy" — full teardown via client.close() (DELETE on the server)
    #   "detach"  — exit but keep the server session alive
    state = {"intent": "destroy", "should_exit": False}
    # E42 (2026-05-13): bg tasks spawned via /bg slash command. Each
    # entry is a _BgTask record. Lives for the chat session lifetime;
    # remaining tasks are cancelled on /exit + /detach. Recoverable
    # long-running work should use `mao-client remote run --detach`
    # in a separate terminal instead — this is operator-level
    # parallelism, not durable background work.
    bg_tasks: dict[str, _BgTask] = {}
    state["bg_tasks"] = bg_tasks  # type: ignore[assignment]
    # E44 (2026-05-13): autonomous-run mode — when on, the chat REPL
    # auto-approves every needs_approval event with a stderr
    # breadcrumb instead of prompting interactively. Toggled by
    # CLI flag `--auto-approve` (initial state) and slash command
    # `/auto-approve on|off|status` (mid-session toggle). Matches
    # Claude Code's `--dangerously-skip-permissions` ergonomic for
    # known-trusted agent specs. Default False — explicit opt-in
    # because the agent's tool surface IS the security boundary.
    state["auto_approve"] = bool(getattr(args, "auto_approve", False))
    # Wave C Phase 2.1 (2026-05-17) — auto-iteration driver state.
    # Set by /loop slash command; consumed by the consumer after each
    # turn completes to decide whether to re-enqueue the prompt.
    # Shape: {'active': bool, 'last_prompt': str, 'cond': str,
    #          'saved_auto_approve': bool}
    # Iteration count + max_iterations live server-side on
    # session.loop_config — client polls /loop/status when it needs
    # them (cache-friendly: avoid duplicating the source of truth).
    state["loop_driver"] = {
        "active": False,
        "last_prompt": "",
        "cond": "",
        "saved_auto_approve": False,
    }
    input_queue: asyncio.Queue[str] = asyncio.Queue()
    turn_busy = asyncio.Event()
    _EXIT_SENTINEL = "__EXIT__"

    # When the agent calls ask_user, the consumer sets pending_input["future"];
    # the producer's NEXT keystroke fulfils that future instead of queueing.
    # Single slot — the agent only blocks on one ask_user at a time.
    pending_input: dict[str, Any] = {"future": None}

    # numbered shortcut for /agent. /agents prints a numbered
    # list AND populates this map; /agent N looks up by number to
    # avoid typing long names. Refreshed on every /agents call so a
    # server-side spec change between calls is reflected. Empty
    # until the user runs /agents at least once.
    agent_index_map: dict[int, str] = {}

    async def _on_needs_input(question: str) -> str:
        loop = asyncio.get_running_loop()
        fut: asyncio.Future[str] = loop.create_future()
        pending_input["future"] = fut
        _surface_agent_question(
            question, markdown=markdown, color=color, client=client,
        )
        try:
            return await fut
        finally:
            pending_input["future"] = None

    async def _on_needs_approval(tool_name: str, preview_text: str) -> bool:
        # E44 (2026-05-13): autonomous-mode bypass. When state's
        # `auto_approve` flag is set (via --auto-approve CLI flag or
        # `/auto-approve on` slash command), every approval event
        # is granted with a stderr breadcrumb instead of an
        # interactive prompt. Same shape as the headless dispatch
        # callback at line ~1800 so operators see uniform logs
        # whether they're in run-headless or chat-autonomous mode.
        if state.get("auto_approve"):
            print(
                f"[auto-approve] {tool_name} "
                f"(preview: {preview_text[:120]!r}...)",
                file=sys.stderr,
            )
            return True
        # Approvals are a yes/no; route through the same input channel
        # but parse the answer as boolean-ish.
        answer = await _on_needs_input(
            f"Approve tool {tool_name!r} with input: {preview_text}? "
            "(yes/no)"
        )
        return answer.strip().lower() in ("y", "yes", "true", "1", "ok")

    # Re-build the client with these callbacks wired up. (The earlier
    # construction already happened; we mutate the existing client so
    # follow-up turns also use the callbacks.)
    client._on_needs_input = _on_needs_input
    client._on_needs_approval = _on_needs_approval

    # Optional: prompt_toolkit's patch_stdout wraps stdout/stderr so trace
    # events from the agent's run don't smudge the active prompt line
    # while the user is typing. Falls back to a no-op context manager if
    # prompt_toolkit isn't installed (chat still works, just messier
    # output during concurrent typing).
    try:
        from prompt_toolkit.patch_stdout import patch_stdout
        stdout_patch = patch_stdout(raw=True)
    except ImportError:
        import contextlib
        stdout_patch = contextlib.nullcontext()

    async def _producer() -> None:
        """Reads input forever. Slash commands that don't need server
        state (/exit, /detach, /cancel, /help) execute IMMEDIATELY.
        Everything else is enqueued for the consumer to dispatch
        sequentially. Status indicator shows queue depth when typing
        during a turn."""
        #  follow-up — `master` is set in the outer
        # `_cmd_remote_chat` scope at session creation. The /agent
        # slash handler MUST update it after a successful
        # set_master so the agent-separator label
        # (`_print_agent_separator(agent=master)`) reflects the
        # current master, not the one from session creation.
        nonlocal master
        first_prompt = True
        while not state["should_exit"]:
            try:
                if first_prompt:
                    _print_user_separator(color=color)
                    first_prompt = False
                line = await read_prompt("> ")
            except (EOFError, KeyboardInterrupt):
                state["intent"] = "destroy"
                state["should_exit"] = True
                await input_queue.put(_EXIT_SENTINEL)
                return
            stripped = line.strip()
            if not stripped:
                continue

            # If the agent is waiting on ask_user, the next message is
            # the answer — not a new prompt. Fulfil the pending future
            # and skip the queue. /cancel and /exit still bypass to
            # let the user escape a stuck question.
            pending_fut = pending_input.get("future")
            if (
                pending_fut is not None
                and not pending_fut.done()
                and stripped not in ("/cancel", "/stop", "/exit", "/quit", "/detach")
            ):
                pending_fut.set_result(line)
                continue

            # Immediate (don't queue):
            if stripped in ("/exit", "/quit"):
                state["intent"] = "destroy"
                state["should_exit"] = True
                if turn_busy.is_set():
                    try:
                        await client.cancel()
                    except Exception:
                        pass
                await input_queue.put(_EXIT_SENTINEL)
                return
            if stripped == "/detach":
                state["intent"] = "detach"
                state["should_exit"] = True
                if turn_busy.is_set():
                    try:
                        await client.cancel()
                    except Exception:
                        pass
                await input_queue.put(_EXIT_SENTINEL)
                return
            if stripped in ("/cancel", "/stop"):
                # if Esc-with-text triggered this /cancel, the
                # draft slot was populated. Surface the recovery
                # affordance so the user knows their text isn't lost.
                draft_was_saved = _has_draft()
                if turn_busy.is_set():
                    print("(cancelling current turn...)")
                    try:
                        await client.cancel()
                    except Exception as exc:
                        print(
                            f"(cancel failed: {type(exc).__name__}: {exc})"
                        )
                    # If a pending ask_user future exists, fail it so
                    # the consumer's await unblocks and the cancel
                    # propagates cleanly.
                    pf = pending_input.get("future")
                    if pf is not None and not pf.done():
                        pf.set_exception(
                            asyncio.CancelledError("user cancelled")
                        )
                else:
                    print("(no turn running to cancel)")
                if draft_was_saved:
                    print("(your typed buffer was saved — type /draft to recall it)")
                # Wave C Phase 2 (2026-05-17) — also stop any RUNNING
                # autonomous-iteration loop. Safe to call unconditionally:
                # the server endpoint is a no-op when loop_state is
                # already INACTIVE/STOPPED. /stop has always been "halt
                # whatever's running"; loops fit that semantic.
                try:
                    loop_result = await client.loop_stop(break_reason="user_stop")
                    if loop_result.get("status") == "stopped":
                        iters = loop_result.get("iteration_count", 0)
                        print(f"(loop stopped at iteration {iters})")
                except Exception as exc:
                    # Non-fatal — /stop's primary job is turn-cancel
                    # which already happened above. Loop-stop failure
                    # here is just a server-state inconsistency, not a
                    # user-visible block.
                    print(
                        f"(loop_stop best-effort failed: "
                        f"{type(exc).__name__}: {exc})",
                        file=sys.stderr,
                    )
                # Wave C Phase 2.1 (2026-05-17) — disarm the iteration
                # driver and restore the user's prior auto_approve
                # state. `/stop` always wins over /loop — single user-
                # facing command halts both surfaces.
                loop_driver = state.get("loop_driver", {})
                if loop_driver.get("active"):
                    loop_driver["active"] = False
                    state["auto_approve"] = bool(
                        loop_driver.get("saved_auto_approve", False)
                    )
                continue
            if stripped == "/draft":
                # recall the most-recent Esc-saved draft into
                # the next prompt. _recall_draft consumes the slot;
                # _set_pending_prompt_default makes _read use the
                # text as the prompt's `default` argument.
                saved = _recall_draft()
                if saved is None:
                    print(
                        "(no draft saved — drafts are saved automatically "
                        "when you press Esc with text in the buffer)"
                    )
                else:
                    _set_pending_prompt_default(saved)
                    print(
                        "(draft restored — next prompt is pre-populated; "
                        "edit and Enter to send)"
                    )
                continue
            if stripped == "/help":
                print(_REMOTE_CHAT_HELP)
                continue
            # Wave B Phase 3 (2026-05-17) — plan-mode approval slashes.
            # /approve — approve the pending plan (if any).
            # /reject [reason] — reject with optional reason (rest of
            #     the line after /reject is the reason, may be empty).
            if stripped == "/approve":
                try:
                    result = await client.approve_plan()
                    print(f"(plan approved — {result.get('plan_state', 'APPROVED')}; next message executes it)")
                except Exception as exc:
                    print(
                        f"(/approve failed: {type(exc).__name__}: {exc})",
                        file=sys.stderr,
                    )
                continue
            if stripped == "/reject" or stripped.startswith("/reject "):
                reason = stripped[len("/reject"):].strip()
                try:
                    result = await client.reject_plan(reason=reason)
                    note = f"(plan rejected — {result.get('plan_state', 'REJECTED')}; agent will re-plan"
                    if reason:
                        note += f"; reason: {reason!r}"
                    note += ")"
                    print(note)
                except Exception as exc:
                    print(
                        f"(/reject failed: {type(exc).__name__}: {exc})",
                        file=sys.stderr,
                    )
                continue
            # Wave C Phase 2 (2026-05-17) — autonomous-iteration slashes.
            # /loop status         — server-side loop_state + config.
            # /loop <N> [until "<cond>"]  — start a loop. Argument
            #     parsing keeps the surface simple: `/loop` alone uses
            #     defaults (max_iterations=20, no break condition);
            #     `/loop 10` caps iterations at 10; `/loop until
            #     "tests pass"` keeps default max + sets condition;
            #     `/loop 5 until "no errors"` combines both.
            # /stop is extended below to also call loop_stop so the
            #     user can interrupt a running loop with the same
            #     command they use to cancel a turn.
            if stripped == "/loop status":
                try:
                    s = await client.loop_status()
                    # Bug fix 2026-05-17: NEVER assign to `state` inside
                    # `_producer`. The producer closes over the outer
                    # `state` dict (line 262); any local assignment to
                    # `state` makes Python treat it as local for the
                    # ENTIRE function, causing `UnboundLocalError` at
                    # line 377 (`while not state["should_exit"]`) on
                    # the producer's first iteration. Use a distinct
                    # local name for the loop-state string read here.
                    loop_state_str = s.get("loop_state", "?")
                    # Same closure-shadow defence as `loop_state_str`
                    # above: rename to `loop_cfg` so we don't shadow
                    # the outer `_cmd_remote_chat`'s `cfg` (the
                    # RemoteConfig dataclass bound at line 147).
                    # `_producer` happens to only READ `cfg` AFTER
                    # this assignment so it doesn't crash today,
                    # but the regression test enforces the rule
                    # globally to prevent the next contributor
                    # introducing a pre-assignment read that does.
                    loop_cfg = s.get("loop_config") or {}
                    if loop_cfg:
                        max_iter = loop_cfg.get("max_iterations", "?")
                        iter_count = loop_cfg.get("iteration_count", 0)
                        cond = loop_cfg.get("condition_str", "") or "(none)"
                        reason = loop_cfg.get("break_reason", "") or "(running)"
                        print(
                            f"(loop_state={loop_state_str}; iteration "
                            f"{iter_count}/{max_iter}; condition={cond!r}; "
                            f"break_reason={reason!r})"
                        )
                    else:
                        print(f"(loop_state={state}; no active loop)")
                except Exception as exc:
                    print(
                        f"(/loop status failed: {type(exc).__name__}: {exc})",
                        file=sys.stderr,
                    )
                continue
            if stripped == "/loop" or stripped.startswith("/loop "):
                # Argument parsing — flexible surface per architect's
                # spec: `/loop`, `/loop N`, `/loop until "cond"`,
                # `/loop N until "cond"`.
                rest = stripped[len("/loop"):].strip()
                max_iter = 20
                cond_str = ""
                if rest:
                    # Split on `until` first; left side is iteration count
                    # (optional); right side is the quoted condition.
                    if " until " in rest:
                        left, _, right = rest.partition(" until ")
                        left = left.strip()
                        if left:
                            try:
                                max_iter = int(left)
                            except ValueError:
                                print(
                                    f"(/loop: max_iterations must be int, "
                                    f"got {left!r})",
                                    file=sys.stderr,
                                )
                                continue
                        # Strip surrounding quotes if present
                        cond_str = right.strip().strip('"').strip("'")
                    else:
                        # Just a number, e.g. /loop 10
                        try:
                            max_iter = int(rest)
                        except ValueError:
                            print(
                                f"(/loop: argument must be `N` or "
                                f"`[N] until \"<cond>\"`, got {rest!r})",
                                file=sys.stderr,
                            )
                            continue
                try:
                    s = await client.loop_start(
                        max_iterations=max_iter, condition_str=cond_str,
                    )
                    cond_disp = (
                        f" until {cond_str!r}" if cond_str else ""
                    )
                    # Wave C Phase 2.1 (2026-05-17) — arm the
                    # iteration driver. The consumer will re-enqueue
                    # the user's next prompt after each turn while
                    # state['loop_driver']['active'] is True. Save
                    # prior auto_approve state so /stop restores it
                    # (loop sessions imply auto-approve).
                    loop_driver = state["loop_driver"]  # type: ignore[index]
                    loop_driver["active"] = True
                    loop_driver["cond"] = cond_str
                    loop_driver["last_prompt"] = ""
                    loop_driver["saved_auto_approve"] = bool(
                        state.get("auto_approve", False)
                    )
                    state["auto_approve"] = True
                    print(
                        f"(loop started — max {max_iter} iterations"
                        f"{cond_disp}. /auto-approve auto-enabled for "
                        f"loop duration; your NEXT prompt becomes the "
                        f"loop body; consumer auto-re-enqueues it "
                        f"each iteration until break_condition fires, "
                        f"max_iterations is hit, or /stop. "
                        f"loop_state={s.get('loop_state', '?')})"
                    )
                except Exception as exc:
                    print(
                        f"(/loop failed: {type(exc).__name__}: {exc})",
                        file=sys.stderr,
                    )
                continue

            # Queued: dispatched in order by the consumer.
            await input_queue.put(stripped)
            if turn_busy.is_set():
                # Print the queue-depth indicator AFTER the current
                # turn's activity finishes; for now flag that this
                # message is queued.
                pending = input_queue.qsize()
                msg_word = "message" if pending == 1 else "messages"
                print(
                    f"(queued — {pending} {msg_word} waiting ✓)"
                )
            else:
                # Not busy yet: consumer will pick this up in a moment.
                # Skip the user separator print here — the consumer
                # will print the agent separator itself.
                pass

    async def _consumer() -> None:
        """Drains the queue and dispatches turns sequentially. Each
        turn sets turn_busy so the producer can show queue indicators
        when input arrives during execution."""
        # `master` is written below at the /agent <name> switch
        # ; without `nonlocal`, Python treats it as a
        # local-only and the read in _print_agent_separator(agent=master)
        # raises UnboundLocalError on the FIRST turn of every chat
        # (before any /agent switch). Pre-fix: every customer's first
        # non-/agent input crashed `mao-client remote chat`. v1.0.0
        # through v1.0.2 shipped with this defect.
        nonlocal master
        while True:
            # Poll with a short timeout so we can re-check should_exit
            # promptly without blocking forever on an empty queue.
            try:
                line = await asyncio.wait_for(input_queue.get(), timeout=0.25)
            except asyncio.TimeoutError:
                if state["should_exit"]:
                    break
                continue

            if line == _EXIT_SENTINEL or state["should_exit"]:
                # Discard any further queued items with a notice so the
                # user knows nothing got silently dropped.
                discarded: list[str] = []
                while not input_queue.empty():
                    try:
                        item = input_queue.get_nowait()
                        if item != _EXIT_SENTINEL:
                            discarded.append(item)
                    except asyncio.QueueEmpty:
                        break
                if discarded:
                    print(
                        f"({len(discarded)} queued message(s) discarded on exit)"
                    )
                return

            # Server-state slash commands (queued because they need
            # the session to be idle). Single-stream consumer means
            # they only run between turns, never during one.
            if line == "/capabilities":
                details = await _fetch_agent_details(cfg, master)
                if details is None:
                    print(
                        f"(could not fetch capabilities for {master!r} — "
                        "the server may not support this endpoint yet, "
                        "or the agent isn't visible to your token.)"
                    )
                else:
                    _print_capabilities(details, color=color)
                _print_user_separator(color=color)
                continue
            if line == "/model" or line.startswith("/model "):
                # Empty form: print CURRENT + available tiers; arg form:
                # switch to that model.
                parts = line.split(maxsplit=1)
                if len(parts) == 1:
                    # fetch the active tier so we can mark it in
                    # the listing. /thresholds returns model_alias in
                    # the context section.
                    try:
                        models = await client.list_models()
                    except Exception as exc:
                        print(
                            f"Error: {type(exc).__name__}: {exc}",
                            file=sys.stderr,
                        )
                        _print_user_separator(color=color)
                        continue
                    current_alias: str | None = None
                    try:
                        thresholds = await client.get_thresholds()
                        current_alias = (
                            thresholds.get("context", {}).get("model_alias")
                        )
                    except Exception:
                        # Older server without /thresholds endpoint or
                        # transient failure — show the list without a
                        # current marker.
                        current_alias = None
                    print("Switchable tiers:")
                    for m in models:
                        marker = (
                            "→ "
                            if current_alias == m["alias"]
                            else "  "
                        )
                        suffix = " (current)" if current_alias == m["alias"] else ""
                        print(
                            f"{marker}{m['alias']:10s}  ({m['tier']}) — "
                            f"{m['description']}{suffix}"
                        )
                    if current_alias:
                        print(
                            f"Usage: `/model standard` or `/model pro` "
                            f"to switch (current: {current_alias})."
                        )
                    else:
                        print(
                            "Usage: `/model standard` or `/model pro` "
                            "(applies to current session only)."
                        )
                else:
                    target = parts[1].strip()
                    try:
                        info = await client.set_model(target)
                    except Exception as exc:
                        print(
                            f"Error: {type(exc).__name__}: {exc}",
                            file=sys.stderr,
                        )
                        _print_user_separator(color=color)
                        continue
                    print(
                        f"(switched to {info['alias']} tier "
                        f"for this session)"
                    )
                _print_user_separator(color=color)
                continue
            if line == "/cap" or line.startswith("/cap "):
                # session-wide spend cap. Empty form → show usage;
                # arg form → set absolute / relative-add / reset.
                parts = line.split(maxsplit=1)
                if len(parts) == 1:
                    # query the live state, not just local cache.
                    try:
                        info = await client.get_thresholds()
                    except Exception as exc:
                        print(
                            f"Error fetching thresholds: {type(exc).__name__}: {exc}",
                            file=sys.stderr,
                        )
                        _print_user_separator(color=color)
                        continue
                    cap_state = info.get("cap", {})
                    cap_tokens = cap_state.get("tokens")
                    used = int(cap_state.get("used", 0))
                    if cap_tokens is None:
                        print(
                            "Cap: NOT SET (default = no limit on cumulative "
                            "session spend)\n"
                            f"Used so far this session: {used:,} tokens\n"
                            "Set with:\n"
                            "  /cap 1M       cap at 1,000,000 tokens total\n"
                            "  /cap 500k     tighten\n"
                            "  /cap +500k    add 500K to current usage\n"
                            "  /cap reset    remove cap"
                        )
                    else:
                        cap = int(cap_tokens)
                        remaining = cap_state.get("remaining")
                        pct = (100 * used / cap) if cap else 0
                        status = "HALTED" if cap_state.get("halted") else "active"
                        print(
                            f"Cap:       {cap:,} tokens\n"
                            f"Used:      {used:,} ({pct:.0f}%)"
                        )
                        if isinstance(remaining, int):
                            print(f"Remaining: {remaining:,}")
                        print(f"Status:    {status}")
                        print(
                            "Note: /clear and /compact preserve the "
                            "cumulative counter (financial truth)."
                        )
                else:
                    parsed = _parse_cap_arg(parts[1])
                    if parsed is None:
                        print(
                            f"Invalid cap: {parts[1]!r}. Examples: "
                            "`/cap 1M`, `/cap 500000`, `/cap +500k`, "
                            "`/cap reset`."
                        )
                        _print_user_separator(color=color)
                        continue
                    if parsed == "reset":
                        tokens_arg: int | None = None
                    else:
                        n, is_relative = parsed
                        if is_relative:
                            current_used = (
                                int(client.last_tokens.get("session_total", 0))
                                if client.last_tokens else 0
                            )
                            tokens_arg = current_used + n
                        else:
                            tokens_arg = n
                    try:
                        info = await client.set_cap(tokens_arg)
                    except Exception as exc:
                        print(
                            f"Error: {type(exc).__name__}: {exc}",
                            file=sys.stderr,
                        )
                        _print_user_separator(color=color)
                        continue
                    if info.get("cap") is None:
                        print(
                            "(cap removed — no limit on cumulative "
                            "session spend)"
                        )
                    else:
                        cap = int(info["cap"])
                        used = int(info["used"])
                        rem = info.get("remaining")
                        if isinstance(rem, int):
                            print(
                                f"(cap set to {cap:,} tokens; used "
                                f"{used:,}, remaining {rem:,})"
                            )
                        else:
                            print(f"(cap set to {cap:,} tokens; used {used:,})")
                _print_user_separator(color=color)
                continue
            if (
                line == "/allow-main-commits"
                or line.startswith("/allow-main-commits ")
            ):
                # feat-branch-only commit guard override.
                parts = line.split(maxsplit=1)
                arg = parts[1].strip().lower() if len(parts) == 2 else ""
                if arg in ("on", "true", "yes", "1"):
                    allowed = True
                elif arg in ("off", "false", "no", "0", "reset", "default"):
                    allowed = False
                elif arg == "":
                    print(
                        " feat-branch commit guard. Default: GUARD ACTIVE\n"
                        "  /allow-main-commits on    bypass for emergency hotfixes\n"
                        "  /allow-main-commits off   re-enable guard (default)\n"
                        "Project policy requires feat/<name> branches for all\n"
                        "code changes; override sparingly."
                    )
                    _print_user_separator(color=color)
                    continue
                else:
                    print(
                        f"Invalid argument {arg!r}. Use `on` or `off`."
                    )
                    _print_user_separator(color=color)
                    continue
                try:
                    info = await client.set_allow_main_commits(allowed)
                except Exception as exc:
                    print(
                        f"Error: {type(exc).__name__}: {exc}",
                        file=sys.stderr,
                    )
                    _print_user_separator(color=color)
                    continue
                if info.get("allow_main_commits"):
                    print(
                        "(WARNING — feat-branch commit guard DISABLED for "
                        "this session. Commits to main/master will proceed. "
                        "Re-enable with `/allow-main-commits off`.)"
                    )
                else:
                    print(
                        "(feat-branch commit guard ACTIVE — commits to "
                        "main/master refused; agent must `git_write "
                        "checkout -b feat/<name>` first.)"
                    )
                _print_user_separator(color=color)
                continue
            if (
                line == "/threshold-auto-compact"
                or line.startswith("/threshold-auto-compact ")
            ):
                # per-session auto-compact threshold override.
                # Soft trigger; the  mandatory 80% floor still applies.
                parts = line.split(maxsplit=1)
                if len(parts) == 1:
                    # show CURRENT effective threshold + source +
                    # current history fill. None → only mandatory floor.
                    try:
                        info = await client.get_thresholds()
                    except Exception as exc:
                        print(
                            f"Error fetching thresholds: {type(exc).__name__}: {exc}",
                            file=sys.stderr,
                        )
                        _print_user_separator(color=color)
                        continue
                    ct = info.get("compact_threshold", {})
                    ctx = info.get("context", {})
                    cur = ct.get("tokens")  # may be None
                    src = ct.get("source", "default")
                    history = int(ctx.get("history_tokens", 0))
                    floor = int(ctx.get("mandatory_floor", 0))
                    if cur is None:
                        #  revised: no soft trigger by default.
                        print(
                            "Auto-compact threshold\n"
                            "  Soft trigger:    NOT SET  (no soft compact "
                            "by default; users opt in)\n"
                            f"  History now:     {history:,} tokens\n"
                            f"  Mandatory floor: {floor:,} tokens  "
                            f"\n"
                            "Set a soft trigger with:\n"
                            "  /threshold-auto-compact 200k    compact at 200K\n"
                            "  /threshold-auto-compact 50k     compact at 50K\n"
                            "  /threshold-auto-compact 1M      loosen further"
                        )
                    else:
                        cur_int = int(cur)
                        src_label = {
                            "session": "set via /threshold-auto-compact this session",
                            "spec": "set in agent YAML (history_compact_threshold)",
                        }.get(src, src)
                        pct = (100 * history / cur_int) if cur_int else 0
                        print(
                            f"Auto-compact threshold\n"
                            f"  Soft trigger:    {cur_int:,} tokens  "
                            f"({src_label})\n"
                            f"  History now:     {history:,} tokens  "
                            f"({pct:.0f}% of soft trigger)\n"
                            f"  Mandatory floor: {floor:,} tokens  "
                            f"\n"
                            "Change with:\n"
                            "  /threshold-auto-compact 50k     tighten\n"
                            "  /threshold-auto-compact 1M      loosen\n"
                            "  /threshold-auto-compact reset   revert to spec / no default"
                        )
                else:
                    parsed = _parse_budget_arg(parts[1])
                    if parsed is None:
                        print(
                            f"Invalid threshold: {parts[1]!r}. Examples: "
                            "`/threshold-auto-compact 50k`, "
                            "`/threshold-auto-compact 200000`, "
                            "`/threshold-auto-compact reset`."
                        )
                        _print_user_separator(color=color)
                        continue
                    tokens_arg = None if parsed == "reset" else parsed
                    try:
                        info = await client.set_compact_threshold(tokens_arg)
                    except Exception as exc:
                        print(
                            f"Error: {type(exc).__name__}: {exc}",
                            file=sys.stderr,
                        )
                        _print_user_separator(color=color)
                        continue
                    val = info.get("compact_threshold")
                    if val is None:
                        print(
                            "(auto-compact threshold reset — falls back "
                            "to spec setting; mandatory 80% floor still "
                            "applies)"
                        )
                    else:
                        print(
                            f"(auto-compact threshold set to {val:,} tokens "
                            f"for this session; mandatory 80% floor still "
                            f"applies as safety net)"
                        )
                _print_user_separator(color=color)
                continue
            if (
                line == "/threshold-turn-input"
                or line.startswith("/threshold-turn-input ")
            ):
                # per-session per-turn input-token ceiling. Halts
                # the runner mid-turn once cumulative LLM input exceeds
                # the limit, forcing the agent to consolidate. Default
                # is unlimited — users opt in here when they want the
                # safety net. The override persists for every
                # remaining turn of THIS session.
                parts = line.split(maxsplit=1)
                if len(parts) == 1:
                    try:
                        info = await client.get_thresholds()
                    except Exception as exc:
                        print(
                            f"Error fetching thresholds: {type(exc).__name__}: {exc}",
                            file=sys.stderr,
                        )
                        _print_user_separator(color=color)
                        continue
                    ti = info.get("turn_input_ceiling", {})
                    cur = ti.get("tokens")  # may be None (unlimited)
                    src = ti.get("source", "default")
                    if cur is None:
                        print(
                            "Per-turn input-token ceiling\n"
                            "  Current:    UNLIMITED  (default — no "
                            "per-turn cap)\n"
                            "Set a ceiling for this session with:\n"
                            "  /threshold-turn-input 200k    halt at 200K "
                            "input tokens within a single turn\n"
                            "  /threshold-turn-input 50k     tighter — "
                            "use for short focused turns\n"
                            "  /threshold-turn-input 1M      loose safety "
                            "net for long research turns\n"
                            "Once set, the ceiling applies to every "
                            "subsequent turn of this session until you "
                            "reset it (`/threshold-turn-input reset`)."
                        )
                    else:
                        cur_int = int(cur)
                        src_label = {
                            "session": "set via /threshold-turn-input "
                            "this session",
                            "default": "global default",
                        }.get(src, src)
                        print(
                            f"Per-turn input-token ceiling\n"
                            f"  Current: {cur_int:,} tokens  "
                            f"({src_label})\n"
                            "  Halts the runner if cumulative LLM input "
                            "in a single turn exceeds this value;\n"
                            "  injects a STOP message forcing the agent "
                            "to consolidate or call ask_user.\n"
                            "Change with:\n"
                            "  /threshold-turn-input 50k     tighten\n"
                            "  /threshold-turn-input 1M      loosen\n"
                            "  /threshold-turn-input reset   revert to "
                            "default (UNLIMITED)"
                        )
                else:
                    parsed = _parse_budget_arg(parts[1])
                    if parsed is None:
                        print(
                            f"Invalid threshold: {parts[1]!r}. Examples: "
                            "`/threshold-turn-input 200k`, "
                            "`/threshold-turn-input 1000000`, "
                            "`/threshold-turn-input reset`."
                        )
                        _print_user_separator(color=color)
                        continue
                    tokens_arg = None if parsed == "reset" else parsed
                    try:
                        info = await client.set_turn_input_ceiling(tokens_arg)
                    except Exception as exc:
                        print(
                            f"Error: {type(exc).__name__}: {exc}",
                            file=sys.stderr,
                        )
                        _print_user_separator(color=color)
                        continue
                    val = info.get("turn_input_ceiling")
                    if val is None:
                        print(
                            "(per-turn input-token ceiling reset to "
                            "default UNLIMITED — no per-turn cap)"
                        )
                    else:
                        print(
                            f"(per-turn input-token ceiling set to "
                            f"{val:,} tokens for this session — applies "
                            f"to every remaining turn until reset)"
                        )
                _print_user_separator(color=color)
                continue
            if (
                line == "/max-output-tokens"
                or line.startswith("/max-output-tokens ")
            ):
                # .5 (2026-05-14): per-session max_output_tokens
                # override. Mirrors /threshold-max-steps pattern.
                # Closes the recurring truncation failure mode (K-F +
                #  reviews) — operators bump the cap per-session
                # without a spec edit + redeploy.
                parts = line.split(maxsplit=1)
                if len(parts) == 1:
                    print(
                        "Per-LLM-call max_output_tokens\n"
                        "  Override the agent spec's max_output_tokens\n"
                        "  for this session. Useful when a cross-cutting\n"
                        "  review / blueprint won't fit the spec's cap\n"
                        "  (e.g. code_reviewer's default 8000 may be\n"
                        "  tight for a 10-file diff verdict).\n"
                        "Change with:\n"
                        "  /max-output-tokens 16000   bump per-call cap\n"
                        "                             for big verdicts\n"
                        "  /max-output-tokens 4000    tighten to control\n"
                        "                             ramble cost\n"
                        "  /max-output-tokens reset   revert to spec\n"
                        "                             default"
                    )
                else:
                    arg = parts[1].strip()
                    if arg.lower() == "reset":
                        tokens_arg: int | None = None
                    else:
                        try:
                            tokens_arg = int(arg)
                            if tokens_arg <= 0:
                                raise ValueError
                        except ValueError:
                            print(
                                f"Invalid tokens: {arg!r}. Examples: "
                                "`/max-output-tokens 16000`, "
                                "`/max-output-tokens 4000`, "
                                "`/max-output-tokens reset`."
                            )
                            _print_user_separator(color=color)
                            continue
                    try:
                        info = await client.set_max_output_tokens(tokens_arg)
                    except Exception as exc:
                        print(
                            f"Error: {type(exc).__name__}: {exc}",
                            file=sys.stderr,
                        )
                        _print_user_separator(color=color)
                        continue
                    val = info.get("max_output_tokens")
                    if val is None:
                        print(
                            "(max_output_tokens reset — falls back to "
                            "spec default for the current agent)"
                        )
                    else:
                        print(
                            f"(max_output_tokens set to {val} for this "
                            "session — applies to every remaining LLM "
                            "call until reset)"
                        )
                _print_user_separator(color=color)
                continue
            if (
                line == "/threshold-max-steps"
                or line.startswith("/threshold-max-steps ")
            ):
                # per-session max_steps override. Mirrors the
                #  /threshold-turn-input pattern. Useful when an
                # autonomous run needs more (or fewer) loop
                # iterations per turn than the spec's default. The
                # override persists for every remaining turn of
                # THIS session.
                parts = line.split(maxsplit=1)
                if len(parts) == 1:
                    try:
                        info = await client.get_thresholds()
                    except Exception as exc:
                        print(
                            f"Error fetching thresholds: {type(exc).__name__}: {exc}",
                            file=sys.stderr,
                        )
                        _print_user_separator(color=color)
                        continue
                    ms = info.get("max_steps", {})
                    cur = ms.get("steps")
                    src = ms.get("source", "spec")
                    src_label = {
                        "session": "set via /threshold-max-steps "
                        "this session",
                        "spec": "agent's YAML default",
                    }.get(src, src)
                    print(
                        f"Per-turn max_steps\n"
                        f"  Current: {cur} steps  ({src_label})\n"
                        "  When the runner hits this number of\n"
                        "  iterations in a single turn it soft-lands\n"
                        "  with a final 'best answer from accumulated\n"
                        "  context' call. Higher = more exploration\n"
                        "  budget per turn (and more cost).\n"
                        "Change with:\n"
                        "  /threshold-max-steps 60     loosen for\n"
                        "                              long autonomous\n"
                        "                              runs (conductor\n"
                        "                              cycles often need\n"
                        "                              this)\n"
                        "  /threshold-max-steps 15     tighten for\n"
                        "                              focused turns\n"
                        "  /threshold-max-steps reset  revert to spec\n"
                        "                              default"
                    )
                else:
                    arg = parts[1].strip()
                    if arg.lower() == "reset":
                        steps_arg = None
                    else:
                        try:
                            steps_arg = int(arg)
                            if steps_arg <= 0:
                                raise ValueError
                        except ValueError:
                            print(
                                f"Invalid steps: {arg!r}. Examples: "
                                "`/threshold-max-steps 60`, "
                                "`/threshold-max-steps 15`, "
                                "`/threshold-max-steps reset`."
                            )
                            _print_user_separator(color=color)
                            continue
                    try:
                        info = await client.set_max_steps(steps_arg)
                    except Exception as exc:
                        print(
                            f"Error: {type(exc).__name__}: {exc}",
                            file=sys.stderr,
                        )
                        _print_user_separator(color=color)
                        continue
                    val = info.get("max_steps")
                    if val is None:
                        print(
                            "(max_steps reset — falls back to spec "
                            "default for the current agent)"
                        )
                    else:
                        print(
                            f"(max_steps set to {val} for this session — "
                            "applies to every remaining turn until reset)"
                        )
                _print_user_separator(color=color)
                continue
            if (
                line == "/threshold-total-steps"
                or line.startswith("/threshold-total-steps ")
            ):
                # per-session max_total_steps override.
                # Session-cumulative step counter (all turns + all
                # spawned subagents). When it crosses, the runner
                # hard-halts with MaxTotalStepsExceeded and the
                # only recovery was starting a new session
                # (re-paying the loaded codebase context). With
                # this slash command users can raise the ceiling
                # mid-session.
                parts = line.split(maxsplit=1)
                if len(parts) == 1:
                    try:
                        info = await client.get_thresholds()
                    except Exception as exc:
                        print(
                            f"Error fetching thresholds: {type(exc).__name__}: {exc}",
                            file=sys.stderr,
                        )
                        _print_user_separator(color=color)
                        continue
                    ts = info.get("total_steps", {})
                    cur = ts.get("steps")
                    used = int(ts.get("used", 0) or 0)
                    src = ts.get("source", "default")
                    src_label = {
                        "session": "set via /threshold-total-steps "
                        "this session",
                        "default": "construction-time default",
                    }.get(src, src)
                    pct = int(100 * used / cur) if cur else 0
                    print(
                        f"Session-cumulative max_total_steps\n"
                        f"  Current: {cur} steps  ({src_label})\n"
                        f"  Used:    {used} steps  ({pct}%)\n"
                        f"  Remaining: {max(cur - used, 0)} steps\n"
                        "  Counts every LLM round-trip across every\n"
                        "  turn and every spawned subagent. Halts the\n"
                        "  whole session with no recovery once exceeded.\n"
                        "Change with:\n"
                        "  /threshold-total-steps 500    raise for long\n"
                        "                                 autonomous runs\n"
                        "  /threshold-total-steps reset  revert to\n"
                        "                                 construction\n"
                        "                                 default"
                    )
                else:
                    arg = parts[1].strip()
                    if arg.lower() == "reset":
                        steps_arg = None
                    else:
                        try:
                            steps_arg = int(arg)
                            if steps_arg <= 0:
                                raise ValueError
                        except ValueError:
                            print(
                                f"Invalid steps: {arg!r}. Examples: "
                                "`/threshold-total-steps 500`, "
                                "`/threshold-total-steps 1000`, "
                                "`/threshold-total-steps reset`."
                            )
                            _print_user_separator(color=color)
                            continue
                    try:
                        info = await client.set_total_steps(steps_arg)
                    except Exception as exc:
                        print(
                            f"Error: {type(exc).__name__}: {exc}",
                            file=sys.stderr,
                        )
                        _print_user_separator(color=color)
                        continue
                    val = info.get("total_steps")
                    if val is None:
                        print(
                            "(max_total_steps reset — reverts to the "
                            "construction-time default)"
                        )
                    else:
                        print(
                            f"(max_total_steps set to {val} for this "
                            "session — applies to all remaining turns "
                            "and spawned subagents until reset)"
                        )
                _print_user_separator(color=color)
                continue
            if line == "/agents":
                #  UAT — list valid master agents the user can switch
                # to via /agent <name>. Filtered by this session's
                # channel ("cli" for remote chat) so the list shows only
                # agents that would actually accept the switch.
                # also populates agent_index_map so /agent N
                # accepts a numeric shortcut from the listing.
                try:
                    info = await client.list_agents(channel="cli")
                except Exception as exc:
                    print(
                        f"Error fetching agent list: "
                        f"{type(exc).__name__}: {exc}",
                        file=sys.stderr,
                    )
                    _print_user_separator(color=color)
                    continue
                # Pin types explicitly: `info` is `dict[str, Any]` so
                # `info.get(...)` returns `Any` and the `or []`
                # short-circuit doesn't narrow. The local name
                # `details` is also bound in this same function at
                # ~L3050 (`details = await _fetch_agent_details(...)`,
                # `dict[str, Any] | None`), so mypy unions both
                # bindings — `cast` to a different name (`agent_rows`)
                # avoids the rebinding-induced widening and gives the
                # listcomp + later iteration a clean type.
                agent_rows: list[dict[str, Any]] = cast(
                    list[dict[str, Any]], info.get("details") or [],
                )
                # `d.get("name") or "?"` (not `d.get("name", "?")`)
                # preserves exact behavioural parity with the pre-
                # narrowing code: when `d["name"]` is explicitly
                # None the listcomp must NOT yield the literal
                # string "None" — that would change observable
                # output for the rare server payload that emits
                # `{"name": null}` instead of omitting the key.
                names: list[str] = info.get("agents") or [
                    d.get("name") or "?" for d in agent_rows
                ]
                # refresh the index map every call. Reset first so
                # a stale entry from a prior /agents (with different
                # registry contents) doesn't leak.
                agent_index_map.clear()
                if not names:
                    print("(no agents available on this channel)")
                else:
                    # Compute the width needed so [001], [002], ...
                    # [025] all align cleanly when N >= 10.
                    width = len(str(len(names)))
                    print(f"Available masters ({len(names)}):")
                    # Print each on its own line with description
                    # snippet (one-line) so the user can see what each
                    # is for without going to /capabilities.  — each
                    # row gets a [N] prefix; that N can be passed to
                    # /agent as a shortcut for the long name.
                    for idx, d in enumerate(agent_rows, start=1):
                        name = d.get("name", "?")
                        agent_index_map[idx] = name
                        desc = (d.get("description") or "").strip()
                        first_line = desc.split("\n", 1)[0][:80]
                        prefix = f"  [{idx:>{width}}] {name}"
                        if first_line:
                            print(f"{prefix}  —  {first_line}")
                        else:
                            print(prefix)
                    print(
                        "Switch with `/agent <name>` or `/agent <number>` "
                        "(e.g. `/agent 3`). Conversation history carries "
                        "forward."
                    )
                _print_user_separator(color=color)
                continue
            if line == "/agent" or line.startswith("/agent "):
                # switch the active master agent mid-session.
                # `/agent` (no arg)  → usage hint.
                # `/agent <name>`    → switch to that master, carrying chat
                #                      history forward. The new master sees
                #                      a synthetic UserMessage marking the
                #                      handoff (so it doesn't conflate prior
                #                      tool calls — made under the previous
                #                      master's system prompt — with its
                #                      own).
                parts = line.split(maxsplit=1)
                if len(parts) == 1:
                    print(
                        "Usage: /agent <name|number>\n"
                        "  Switches the active master agent. Conversation "
                        "history carries forward; a synthetic handoff "
                        "message is inserted so the new agent treats prior "
                        "context as background.\n"
                        "  Run /agents first to see the list — then\n"
                        "  /agent <number> uses the [N] from that listing\n"
                        "  as a shortcut for the long name .\n"
                        "  Use /capabilities to see the current master."
                    )
                else:
                    target = parts[1].strip()
                    if not target:
                        print("Usage: /agent <name|number>")
                        _print_user_separator(color=color)
                        continue
                    # numeric shortcut: if the arg is a positive
                    # integer, look it up in the agent_index_map that
                    # /agents populated. Falls through to the
                    # name-as-given path on any miss so a user typing
                    # an agent literally named "3" (unlikely but legal)
                    # still works as a name match on the server side.
                    if target.isdigit():
                        idx = int(target)
                        if not agent_index_map:
                            print(
                                "Numeric shortcut requires running "
                                "`/agents` first to populate the listing. "
                                "Run /agents, then try /agent <number> "
                                "again.",
                                file=sys.stderr,
                            )
                            _print_user_separator(color=color)
                            continue
                        resolved = agent_index_map.get(idx)
                        if resolved is None:
                            print(
                                f"`{target}` is out of range (last "
                                f"/agents listed {len(agent_index_map)} "
                                f"agents). Re-run /agents to refresh "
                                f"the list, or use the agent name "
                                f"directly.",
                                file=sys.stderr,
                            )
                            _print_user_separator(color=color)
                            continue
                        # Tell the user what we resolved to so the
                        # subsequent confirmation message isn't a
                        # surprise.
                        print(f"(resolved /agent {target} → `{resolved}`)")
                        target = resolved
                    try:
                        result = await client.set_master(target)
                    except httpx.HTTPStatusError as exc:
                        # Server returned 4xx with a clear detail
                        try:
                            detail = exc.response.json().get("detail", "")
                        except Exception:
                            detail = exc.response.text
                        #  UAT finding: a 404 with detail "Not Found"
                        # means the server doesn't have the /set_master
                        # endpoint at all — i.e. the deployed
                        # master-agents-api container is older than the
                        # CLI. Surface a more helpful message so the user
                        # knows to redeploy rather than thinking the
                        # agent name was bad.
                        if (
                            exc.response.status_code == 404
                            and "Not Found" in str(detail)
                        ):
                            print(
                                f"Cannot switch to {target!r}: server has "
                                f"no /set_master endpoint. The deployed "
                                f"master-agents-api container is older "
                                f"than this CLI . Rebuild + restart the "
                                f"container, then retry.",
                                file=sys.stderr,
                            )
                        else:
                            print(
                                f"Cannot switch to {target!r}: {detail}",
                                file=sys.stderr,
                            )
                        _print_user_separator(color=color)
                        continue
                    except Exception as exc:
                        print(
                            f"Error switching agent: "
                            f"{type(exc).__name__}: {exc}",
                            file=sys.stderr,
                        )
                        _print_user_separator(color=color)
                        continue
                    prev = result.get("previous_master")
                    new = result.get("new_master")
                    #  follow-up — update the producer's `master`
                    # closure so the agent-separator label printed at
                    # the top of every subsequent turn shows the new
                    # master, not the stale one captured at session
                    # creation. Without this, /agent appeared to
                    # succeed but the chat label kept saying the old
                    # name AND the runtime correctly used the new
                    # master — confusing UX (UAT-found 2026-05-04).
                    if isinstance(new, str) and new:
                        master = new
                    print(
                        f"(switched from `{prev}` to `{new}` — chat history "
                        f"carries forward; handoff message inserted)"
                    )
                _print_user_separator(color=color)
                continue
            # /threshold-ask-user is a  descriptive alias for /budget.
            # The / cost-gate gates content reads BEFORE they happen,
            # forcing ask_user when the cumulative estimate_tokens accumulator
            # crosses the threshold (tier_2). The handler below handles both
            # forms identically.
            if (
                line == "/budget"
                or line.startswith("/budget ")
                or line == "/threshold-ask-user"
                or line.startswith("/threshold-ask-user ")
            ):
                # empty form → print usage + current state hint;
                # arg form → set or reset the cost-gate threshold.
                parts = line.split(maxsplit=1)
                if len(parts) == 1:
                    # show CURRENT effective threshold + source.
                    try:
                        info = await client.get_thresholds()
                    except Exception as exc:
                        print(
                            f"Error fetching thresholds: {type(exc).__name__}: {exc}",
                            file=sys.stderr,
                        )
                        _print_user_separator(color=color)
                        continue
                    b = info.get("budget", {})
                    cur = int(b.get("tokens", 0))
                    src = b.get("source", "default")
                    src_label = {
                        "session": "set via /threshold-ask-user this session",
                        "spec": "set in agent YAML",
                        "default": "global default",
                    }.get(src, src)
                    print(
                        f"Threshold (ask-user /  cost gate)\n"
                        f"  Current: {cur:,} tokens  ({src_label})\n"
                        f"  tier_1 ≤ {cur:,} (auto-run)\n"
                        f"  tier_2 {cur+1:,}..{cur*2:,} (gates → ask_user)\n"
                        f"  tier_3 > {cur*2:,} (auto-rejected)\n"
                        "Set with:\n"
                        "  /threshold-ask-user 50k    tighten to 50K\n"
                        "  /threshold-ask-user 200000 raw integer\n"
                        "  /threshold-ask-user 1.5M   loosen\n"
                        "  /threshold-ask-user reset  revert to default (100K)\n"
                        "Aliases: /budget = /threshold-ask-user (same command)"
                    )
                else:
                    parsed = _parse_budget_arg(parts[1])
                    if parsed is None:
                        print(
                            f"Invalid budget: {parts[1]!r}. Examples: "
                            "`/budget 50k`, `/budget 200000`, `/budget reset`."
                        )
                        _print_user_separator(color=color)
                        continue
                    tokens_arg = None if parsed == "reset" else parsed
                    try:
                        info = await client.set_budget(tokens_arg)
                    except Exception as exc:
                        print(
                            f"Error: {type(exc).__name__}: {exc}",
                            file=sys.stderr,
                        )
                        _print_user_separator(color=color)
                        continue
                    if info.get("budget") is None:
                        print(
                            "(budget reset — falls back to spec setting "
                            "or 100K default)"
                        )
                    else:
                        b = int(info["budget"])
                        t2 = int(info["tier_2_at"])
                        t3 = int(info["tier_3_at"])
                        print(
                            f"(budget set to {b:,} tokens for this "
                            f"session — tier_2 at {t2:,}, tier_3 at {t3:,})"
                        )
                _print_user_separator(color=color)
                continue
            if line == "/memory" or line.startswith("/memory "):
                # v3.3.0 — memory curation slash command.
                #   /memory                   list user-scope keys
                #                             (with updated_at + preview)
                #   /memory list [agent]      list user-scope OR this
                #                             agent's agent-scope
                #   /memory get <key> [agent] show full value
                #   /memory delete <key>      delete from user-scope (or
                #                             /memory delete agent <key>)
                # Discoverability surface for the /remember write path —
                # users need to see what they have before they can
                # forget anything.
                parts = line.split(maxsplit=2)
                if len(parts) == 1:
                    sub = "list"
                    sub_arg = ""
                else:
                    sub = parts[1].lower()
                    sub_arg = parts[2] if len(parts) > 2 else ""

                if sub == "help":
                    print(
                        "/memory — audit + curate persisted memory.\n"
                        "  /memory                       list user-scope keys\n"
                        "  /memory list                  list user-scope keys\n"
                        "  /memory list agent            list THIS agent's "
                        "agent-scope keys\n"
                        "  /memory get <key>             show full value "
                        "(user-scope)\n"
                        "  /memory get agent <key>       show full value "
                        "(this agent's agent-scope)\n"
                        "  /memory delete <key>          delete a user-scope "
                        "entry\n"
                        "  /memory delete agent <key>    delete this agent's "
                        "agent-scope entry"
                    )
                    _print_user_separator(color=color)
                    continue

                if sub == "list":
                    # v3.3.1 — parse sub_arg for scope + by-agent filter:
                    #   /memory list                      → user-scope, no filter
                    #   /memory list agent                → agent-scope (this agent)
                    #   /memory list by <agent_name>      → user-scope, filter by created_by_agent
                    #   /memory list agent by <agent_name>→ both (rare; allowed for completeness)
                    by_filter: str | None = None
                    tokens = sub_arg.strip().split()
                    if tokens and tokens[0].lower() == "agent":
                        scope = "agent"
                        qualifier = master
                        # consume 'agent', look for 'by <name>'
                        if len(tokens) >= 3 and tokens[1].lower() == "by":
                            by_filter = tokens[2]
                    elif len(tokens) >= 2 and tokens[0].lower() == "by":
                        scope = "user"
                        qualifier = ""
                        by_filter = tokens[1]
                    else:
                        scope = "user"
                        qualifier = ""
                    try:
                        # v3.3.1 — pass the by_filter via memory_list_curate
                        # (we extend the call below; for now the client
                        # method passes it through as a kwarg the endpoint
                        # accepts).
                        info = await client.memory_list_curate(
                            scope, qualifier,
                            created_by_agent=by_filter,
                        )
                    except Exception as exc:
                        print(
                            f"Error: {type(exc).__name__}: {exc}",
                            file=sys.stderr,
                        )
                        _print_user_separator(color=color)
                        continue
                    total = info.get("total", 0)
                    entries = info.get("keys", [])
                    qual_part = (
                        f" (this agent: {master})" if scope == "agent"
                        else " (cross-cutting)"
                    )
                    filter_part = (
                        f" — saved while chatting with {by_filter!r}"
                        if by_filter else ""
                    )
                    print(
                        f"{total} memory key(s) in {scope}-scope"
                        f"{qual_part}{filter_part}:"
                    )
                    if not entries:
                        print("  (none)")
                    else:
                        # Fetch values for short previews. N+1 round-
                        # trips but N is small (capped at 200) and this
                        # is interactive UI, not a hot path.
                        for entry in entries:
                            key = entry["key"]
                            ts = entry.get("updated_at", "?")
                            chars = entry["value_chars"]
                            # v3.3.1 — show provenance ("[via <agent>]")
                            # alongside each entry so user can see who
                            # was active when the fact was saved.
                            by = entry.get("created_by_agent") or "?"
                            try:
                                got = await client.memory_get_curate(
                                    scope, key, qualifier,
                                )
                                value = got.get("value", "")
                                preview = (
                                    value if len(value) <= 60
                                    else value[:60] + "..."
                                )
                            except Exception:
                                preview = "<value fetch failed>"
                            print(
                                f"  {ts}  [via {by:<22s}] "
                                f"{key:<30s} ({chars:>5,} chars)  {preview}"
                            )
                    _print_user_separator(color=color)
                    continue

                if sub == "get":
                    # /memory get <key>          → user-scope
                    # /memory get agent <key>    → agent-scope
                    arg_parts = sub_arg.split(maxsplit=1)
                    if not arg_parts:
                        print(
                            "/memory get: missing <key>. "
                            "Usage: /memory get <key> | /memory get agent <key>"
                        )
                        _print_user_separator(color=color)
                        continue
                    if arg_parts[0].lower() == "agent" and len(arg_parts) == 2:
                        scope = "agent"
                        qualifier = master
                        key = arg_parts[1].strip()
                    else:
                        scope = "user"
                        qualifier = ""
                        key = sub_arg.strip()
                    try:
                        got = await client.memory_get_curate(
                            scope, key, qualifier,
                        )
                    except Exception as exc:
                        msg = f"{type(exc).__name__}: {exc}"
                        if "404" in msg:
                            print(
                                f"Not found: {scope}:{qualifier}:{key}",
                                file=sys.stderr,
                            )
                        else:
                            print(f"Error: {msg}", file=sys.stderr)
                        _print_user_separator(color=color)
                        continue
                    print(
                        f"{scope}-scope key={key!r} "
                        f"(updated {got.get('updated_at', '?')}, "
                        f"{got.get('value_chars', 0):,} chars):"
                    )
                    print(got.get("value", ""))
                    _print_user_separator(color=color)
                    continue

                if sub == "delete":
                    # /memory delete <key>           → user-scope
                    # /memory delete agent <key>     → agent-scope
                    arg_parts = sub_arg.split(maxsplit=1)
                    if not arg_parts:
                        print(
                            "/memory delete: missing <key>. "
                            "Usage: /memory delete <key> | "
                            "/memory delete agent <key>"
                        )
                        _print_user_separator(color=color)
                        continue
                    if arg_parts[0].lower() == "agent" and len(arg_parts) == 2:
                        scope = "agent"
                        qualifier = master
                        key = arg_parts[1].strip()
                    else:
                        scope = "user"
                        qualifier = ""
                        key = sub_arg.strip()
                    # Confirmation prompt — bad delete is hard to undo
                    # unless you remember the value.
                    print(
                        f"Delete {scope}-scope key={key!r}?",
                        file=sys.stderr,
                    )
                    # Plain input() — blocks the event loop briefly but
                    # that's fine for a confirmation prompt in the
                    # interactive REPL (no concurrent work to interleave
                    # with). Matches the pattern used by other slash
                    # commands that need user confirmation.
                    try:
                        answer = input("  Confirm [y/N]: ")
                    except (KeyboardInterrupt, EOFError):
                        print("\n(aborted)")
                        _print_user_separator(color=color)
                        continue
                    if answer.strip().lower() not in ("y", "yes"):
                        print("(aborted)")
                        _print_user_separator(color=color)
                        continue
                    try:
                        result = await client.memory_delete_curate(
                            scope, key, qualifier,
                        )
                    except Exception as exc:
                        print(
                            f"Error: {type(exc).__name__}: {exc}",
                            file=sys.stderr,
                        )
                        _print_user_separator(color=color)
                        continue
                    if result.get("existed"):
                        print(f"(deleted {scope}-scope key={key!r})")
                    else:
                        print(
                            f"({scope}-scope key={key!r} was not "
                            f"present — no-op)"
                        )
                    _print_user_separator(color=color)
                    continue

                # Unknown subcommand.
                print(
                    f"/memory: unknown subcommand {sub!r}. "
                    "Use `/memory help` for the full list."
                )
                _print_user_separator(color=color)
                continue
            if line == "/remember" or line.startswith("/remember "):
                # v3.1.0 — user-driven fact save to user-scope memory.
                # `/remember <text>` saves to auto-keyed entry;
                # `/remember <key>=<text>` saves with explicit key.
                # On next session start, the fact appears in every
                # agent's <memory> block auto-load.
                parts = line.split(maxsplit=1)
                if len(parts) == 1:
                    print(
                        "/remember: save a fact to user-scope memory.\n"
                        "Usage:\n"
                        "  /remember <text>           "
                        "auto-keyed (note_<UTC-timestamp>)\n"
                        "  /remember <key>=<text>     "
                        "explicit key (1-64 chars [A-Za-z0-9_-])\n"
                        "User-scope facts auto-load into every agent's "
                        "<memory> block on the next session start."
                    )
                    _print_user_separator(color=color)
                    continue
                raw = parts[1]
                # Parse `key=text` if present; else auto-key.
                explicit_key: str | None = None
                fact_text = raw
                if "=" in raw:
                    candidate_key, _, rest = raw.partition("=")
                    candidate_key = candidate_key.strip()
                    # Only treat as key=text when the LHS looks like a
                    # valid slug AND there's content after `=`. Avoids
                    # mistaking `/remember a=1, b=2` (a freeform fact
                    # containing `=`) for an explicit key.
                    import re as _re
                    if (
                        rest.strip()
                        and _re.fullmatch(
                            r"[A-Za-z0-9_-]{1,64}", candidate_key,
                        )
                    ):
                        explicit_key = candidate_key
                        fact_text = rest.strip()
                try:
                    info = await client.remember(
                        fact_text, key=explicit_key,
                    )
                except Exception as exc:
                    print(
                        f"Error: {type(exc).__name__}: {exc}",
                        file=sys.stderr,
                    )
                    _print_user_separator(color=color)
                    continue
                saved_key = info.get("key", "?")
                chars = info.get("value_chars", len(fact_text))
                print(
                    f"(remembered — user-scope, key={saved_key}, "
                    f"{chars} chars. Visible in all agents' <memory> "
                    f"block from the NEXT session.)"
                )
                _print_user_separator(color=color)
                continue
            if line in ("/clear", "/reset"):
                try:
                    info = await client.reset()
                except Exception as exc:
                    print(
                        f"Error: {type(exc).__name__}: {exc}",
                        file=sys.stderr,
                    )
                    _print_user_separator(color=color)
                    continue
                cleared = info.get("messages_cleared", 0)
                print(f"(history cleared — {cleared} messages dropped)")
                _print_user_separator(color=color)
                continue
            # ── E44 (2026-05-13) — /auto-approve toggle ──────────
            if line == "/tasks" or line.startswith("/tasks "):
                # E42 (2026-05-14) — minimum-viable background-task
                # surface for . Three sub-commands:
                #   /tasks list                — show recent persisted
                #                                sessions (detached +
                #                                still-active).
                #   /tasks resume <id>         — re-attach to a
                #                                specific session by id
                #                                (alias for typing
                #                                `/exit` + relaunching
                #                                with `--resume <id>`,
                #                                but in-REPL).
                #   /tasks kill <id>           — terminate an arbitrary
                #                                session by id (calls
                #                                POST /sessions/{id}/kill
                #                                auth-only). For cleaning
                #                                up stale detached
                #                                sessions across crashes.
                # The full SSE-mid-tool-detach (`/bg next-tool`) is
                # deferred to .5 — requires a server-side SSE
                # protocol refactor. The detach mechanism that EXISTS
                # today (`--detach` flag on `remote run`, `/detach` slash
                # in chat) already covers the session-level use case;
                # /tasks is the surface for inspecting + managing those
                # detached sessions.
                parts = line.split(maxsplit=2)
                sub = parts[1].strip().lower() if len(parts) >= 2 else "list"
                if sub == "list":
                    try:
                        sessions = await _list_recent_sessions(cfg, limit=20)
                    except Exception as exc:
                        print(
                            f"Error: {type(exc).__name__}: {exc}",
                            file=sys.stderr,
                        )
                        _print_user_separator(color=color)
                        continue
                    if not sessions:
                        print("(no persisted sessions on this server)")
                    else:
                        print(f"Recent sessions on {cfg.server}:")
                        for s in sessions:
                            sid = s.get("session_id", "?")
                            agent = s.get("agent_name", "?")
                            age = _format_age(s.get("last_activity_ts"))
                            status = s.get("status", "?")
                            print(
                                f"  {sid[:24]}  {agent:24s}  {age:>10s} ago  "
                                f"{status}"
                            )
                        print()
                        print(
                            "Use `/tasks resume <id>` to re-attach, "
                            "`/tasks kill <id>` to terminate."
                        )
                elif sub == "resume":
                    if len(parts) < 3:
                        print("Usage: /tasks resume <session_id>")
                    else:
                        target = parts[2].strip()
                        print(
                            f"To resume {target}: type `/exit`, then "
                            f"relaunch with `mao-client remote chat "
                            f"--resume {target}`."
                        )
                elif sub == "kill":
                    if len(parts) < 3:
                        print("Usage: /tasks kill <session_id>")
                    else:
                        target = parts[2].strip()
                        try:
                            result = await client.kill_session_by_id(target)
                            print(
                                f"Killed session {target} "
                                f"({result.get('status', 'ok')})"
                            )
                        except Exception as exc:
                            print(
                                f"Error killing {target}: "
                                f"{type(exc).__name__}: {exc}",
                                file=sys.stderr,
                            )
                else:
                    print(
                        "/tasks <subcommand>\n"
                        "  list                   list recent persisted\n"
                        "                         sessions (detached +\n"
                        "                         still-active)\n"
                        "  resume <session_id>    re-attach to a specific\n"
                        "                         session by id\n"
                        "  kill <session_id>      terminate a session by id"
                    )
                _print_user_separator(color=color)
                continue
            if line == "/auto-approve" or line.startswith("/auto-approve "):
                parts = line.split(maxsplit=1)
                sub = parts[1].strip().lower() if len(parts) >= 2 else "status"
                if sub == "status":
                    cur = "on" if state.get("auto_approve") else "off"
                    print(f"/auto-approve: currently {cur}.")
                    print(
                        "Usage: /auto-approve on   — auto-grant every needs_approval\n"
                        "       /auto-approve off  — restore interactive prompts (default)\n"
                        "       /auto-approve      — show current setting"
                    )
                elif sub == "on":
                    if state.get("auto_approve"):
                        print("/auto-approve: already on (no change).")
                    else:
                        state["auto_approve"] = True
                        print(
                            "/auto-approve: ON. All subsequent tool-approval "
                            "events will auto-grant with a [auto-approve] stderr "
                            "breadcrumb. Type `/auto-approve off` to restore "
                            "interactive prompts."
                        )
                elif sub == "off":
                    if not state.get("auto_approve"):
                        print("/auto-approve: already off (no change).")
                    else:
                        state["auto_approve"] = False
                        print(
                            "/auto-approve: OFF. Interactive approval prompts "
                            "restored for subsequent tool calls."
                        )
                else:
                    print(
                        f"/auto-approve: unknown argument {sub!r}. "
                        "Use `on`, `off`, or leave blank for status."
                    )
                _print_user_separator(color=color)
                continue
            # ── E42 (2026-05-13) — /bg + /tasks ──────────────────
            if line == "/bg" or line.startswith("/bg "):
                parts = line.split(maxsplit=2)
                if len(parts) < 3:
                    print(
                        "/bg: spawn a parallel agent run in the background.\n"
                        "Usage: /bg <agent> <prompt>\n"
                        "Example: /bg simos_consultant \"summarise SimOS architecture\"\n"
                        "The foreground REPL stays responsive while the\n"
                        "background agent works. Inspect with /tasks list,\n"
                        "/tasks status <id>, /tasks kill <id>.\n"
                        "Note: bg tasks die with the chat session — for\n"
                        "durable long runs, use `mao-client remote run\n"
                        "--detach <agent> <prompt>` in a separate terminal."
                    )
                    _print_user_separator(color=color)
                    continue
                _bg_agent = parts[1]
                _bg_prompt = parts[2]
                _bg_task_id = uuid.uuid4().hex[:8]
                _bg_record = _BgTask(
                    task_id=_bg_task_id,
                    agent=_bg_agent,
                    prompt=_bg_prompt,
                    started_at=time.monotonic(),
                    started_wall=time.time(),
                )
                _bg_record.asyncio_task = asyncio.create_task(
                    _run_bg_task(cfg, _bg_agent, _bg_prompt, _bg_record),
                )
                bg_tasks[_bg_task_id] = _bg_record
                _bg_preview = (
                    _bg_prompt if len(_bg_prompt) <= 60
                    else _bg_prompt[:57] + "..."
                )
                print(
                    f"[bg:{_bg_task_id}] started — {_bg_agent}: {_bg_preview}"
                )
                _print_user_separator(color=color)
                continue
            if line == "/tasks" or line.startswith("/tasks "):
                parts = line.split(maxsplit=2)
                sub = parts[1].lower() if len(parts) >= 2 else "list"
                if sub == "list":
                    if not bg_tasks:
                        print("(no /bg tasks running in this session)")
                    else:
                        print(
                            f"{'id':<10}{'status':<11}{'agent':<24}"
                            f"{'elapsed':<10}prompt"
                        )
                        for _tid, _t in bg_tasks.items():
                            _el = _format_elapsed(
                                time.monotonic() - _t.started_at,
                            )
                            _pp = (
                                _t.prompt if len(_t.prompt) <= 40
                                else _t.prompt[:37] + "..."
                            )
                            print(
                                f"{_tid:<10}{_t.status:<11}"
                                f"{_t.agent:<24}{_el:<10}{_pp}"
                            )
                    _print_user_separator(color=color)
                    continue
                if sub == "status":
                    if len(parts) < 3:
                        print("/tasks status: usage: /tasks status <task_id>")
                        _print_user_separator(color=color)
                        continue
                    _tid = parts[2].strip()
                    _t = bg_tasks.get(_tid)
                    if _t is None:
                        print(f"/tasks status: no bg task with id {_tid!r}")
                        _print_user_separator(color=color)
                        continue
                    _el = _format_elapsed(time.monotonic() - _t.started_at)
                    print(f"task_id:     {_t.task_id}")
                    print(f"agent:       {_t.agent}")
                    print(f"status:      {_t.status}")
                    print(f"elapsed:     {_el}")
                    print(f"prompt:      {_t.prompt}")
                    if _t.session_id:
                        print(f"session_id:  {_t.session_id}")
                    if _t.status == "completed" and _t.result:
                        _ans = _t.result
                        if len(_ans) > 800:
                            print(f"answer:      {_ans[:800]}...")
                            print(
                                f"             ({len(_ans) - 800} more chars; "
                                "full answer in record)"
                            )
                        else:
                            print(f"answer:      {_ans}")
                    elif _t.error:
                        print(f"error:       {_t.error}")
                    _print_user_separator(color=color)
                    continue
                if sub == "kill":
                    if len(parts) < 3:
                        print("/tasks kill: usage: /tasks kill <task_id>")
                        _print_user_separator(color=color)
                        continue
                    _tid = parts[2].strip()
                    _t = bg_tasks.get(_tid)
                    if _t is None:
                        print(f"/tasks kill: no bg task with id {_tid!r}")
                        _print_user_separator(color=color)
                        continue
                    if _t.status not in ("starting", "running"):
                        print(
                            f"/tasks kill: bg task {_tid} already "
                            f"{_t.status} — nothing to cancel."
                        )
                        _print_user_separator(color=color)
                        continue
                    if _t.asyncio_task is not None:
                        _t.asyncio_task.cancel()
                    print(f"[bg:{_tid}] cancellation requested.")
                    _print_user_separator(color=color)
                    continue
                print(
                    f"/tasks: unknown subcommand {sub!r}. "
                    "Use `list`, `status <id>`, or `kill <id>`."
                )
                _print_user_separator(color=color)
                continue
            if line == "/compact":
                try:
                    info = await client.compact()
                except Exception as exc:
                    print(
                        f"Error: {type(exc).__name__}: {exc}",
                        file=sys.stderr,
                    )
                    _print_user_separator(color=color)
                    continue
                if info.get("status") == "no_op":
                    msg_count = info.get("message_count")
                    min_count = info.get("min_messages_to_compact")
                    history_tokens = info.get("history_tokens")
                    # history_tokens guarded separately — server may omit
                    # it on certain no_op shapes (e.g. the service),
                    # and `f"{None:,}"` crashes with the 2026-05-09 bug
                    # class. See master_agents_os/CLAUDE.md "Spec field
                    # defaults" for the canonical reference.
                    if msg_count is not None and min_count is not None:
                        if history_tokens is not None:
                            print(
                                f"(nothing to compact: {msg_count} messages "
                                f"in history, need ≥{min_count} before "
                                f"compaction kicks in. ~{history_tokens:,} "
                                "tokens of history right now.)"
                            )
                        else:
                            print(
                                f"(nothing to compact: {msg_count} messages "
                                f"in history, need ≥{min_count} before "
                                "compaction kicks in.)"
                            )
                    else:
                        print("(nothing to compact)")
                else:
                    print(
                        f"(compacted: {info.get('removed_messages', 0)} messages folded; "
                        f"{info.get('before_tokens', 0):,} → "
                        f"{info.get('after_tokens', 0):,} tokens)"
                    )
                _print_user_separator(color=color)
                continue

            # Normal turn dispatch.
            _print_agent_separator(color=color, agent=master)
            turn_busy.set()
            try:
                result = await client.turn(line)
            except SessionEndedError as exc:
                # Server-side cancellation (F1 timeout, container
                # restart, explicit cancel). The session is dead —
                # every subsequent turn would hit the same 410, so
                # we EXIT the chat loop instead of looping on errors.
                # Run-path exits 1 (script-callable signal). Chat
                # path exits 0 because the user is interactive and
                # already saw the message; "exit code" matters only
                # if the chat REPL itself was scripted, which is
                # rare. Error class is distinct from generic
                # `Exception` so this branch fires before the
                # catch-all below.
                #
                # E39 (2026-05-13): surface the session_id + resume
                # hints. The dead session is fully recoverable via
                # /sessions/{id}/rehydrate. Auto-arm both storage
                # paths so `--resume <id>` AND `--resume-last` work
                # after abnormal end (the prior message only said
                # "start a new session" — actively misled users away
                # from the recovery path that existed).
                session_id = client.session_id
                nonce = client.nonce
                if session_id and nonce:
                    _save_active_session(
                        server=cfg.server,
                        agent_name=master,
                        session_id=session_id,
                        nonce=nonce,
                    )
                    write_last_session_id(master, session_id)
                    print(
                        f"\n[Session ended] {exc}\n"
                        f"  session_id={session_id}\n"
                        f"  Resume with: agents remote chat --resume {session_id}\n"
                        f"  Or:          agents remote chat --resume-last\n",
                        file=sys.stderr,
                    )
                else:
                    # Session never reached server. No id to surface.
                    print(
                        f"\n[Session ended] {exc}\n"
                        f"Chat ended; reopen with `agents remote chat` "
                        f"to start a new session.",
                        file=sys.stderr,
                    )
                turn_busy.clear()
                state["intent"] = "destroy"
                state["should_exit"] = True
                # P3 follow-up: wake the producer immediately. Without
                # this, the producer is still awaiting `read_prompt`
                # and gather waits for the user's next keystroke. The
                # producer task is stashed on state by the gather
                # caller; cancelling it makes asyncio.gather return
                # right away with CancelledError, which the caller's
                # try/except absorbs cleanly.
                producer_task = state.get("_producer_task")
                if producer_task is not None and not producer_task.done():
                    producer_task.cancel()
                break
            except Exception as exc:
                print(
                    f"Error: {type(exc).__name__}: {exc}",
                    file=sys.stderr,
                )
                turn_busy.clear()
                _print_user_separator(color=color)
                continue
            finally:
                turn_busy.clear()
            _print_answer(result, markdown=markdown)
            if client.last_tokens:
                _print_remote_token_line(
                    client.last_tokens,
                    color=color,
                    duration_s=client.last_turn_seconds,
                    cost_summary=client.last_cost_summary,
                    cap_info=client.last_cap,
                )
            # Print user separator NOW so the next prompt has a clean
            # boundary above it (whether it comes from queued input or
            # fresh user typing).
            _print_user_separator(color=color)

            # Wave C Phase 2.1 (2026-05-17) — auto-iteration driver.
            # If the user started a loop with /loop and we just
            # completed a turn, decide whether to re-enqueue the same
            # prompt for the next iteration. Three termination
            # conditions (architect's three-layer safety):
            #   1. Server-side state changed away from RUNNING (e.g.
            #      another client called /loop/stop, or max_iterations
            #      hit on the previous iteration count bump).
            #   2. Break condition fires (cheap substring match for v1
            #      — checks if any token from cond_str appears in the
            #      result text. LLM-judge fallback for semantic
            #      conditions is deferred to a follow-up).
            #   3. Iteration count reaches max_iterations.
            loop_driver = state.get("loop_driver", {})
            if loop_driver.get("active"):
                # First turn after /loop: capture the user's prompt
                # so we can re-enqueue it. Subsequent turns reuse it.
                if not loop_driver.get("last_prompt"):
                    loop_driver["last_prompt"] = line
                # Poll server-side state — single source of truth for
                # iteration_count + max_iterations.
                try:
                    s = await client.loop_status()
                except Exception as exc:
                    print(
                        f"(loop_status poll failed: "
                        f"{type(exc).__name__}: {exc}; halting iteration)",
                        file=sys.stderr,
                    )
                    loop_driver["active"] = False
                    state["auto_approve"] = bool(
                        loop_driver.get("saved_auto_approve", False)
                    )
                    continue
                # Renamed `cfg` → `loop_cfg` (2026-05-17 fix): the
                # outer `_cmd_remote_chat` frame binds `cfg` (the
                # RemoteConfig dataclass at line 147). A bare
                # ``cfg = ...`` here would make Python treat `cfg`
                # as local for the WHOLE `_consumer` function,
                # raising UnboundLocalError on any earlier read.
                # _consumer doesn't currently read `cfg` before
                # this line, so the production crash was confined to
                # `_producer`'s `state` shadow; this rename is the
                # parallel hygiene fix so the regression test passes.
                loop_cfg = s.get("loop_config") or {}
                cur_state = s.get("loop_state", "")
                # Server-side state changed away from RUNNING -> stop.
                if "RUNNING" not in cur_state.upper():
                    loop_driver["active"] = False
                    state["auto_approve"] = bool(
                        loop_driver.get("saved_auto_approve", False)
                    )
                    print(
                        f"(loop driver halted — server state is "
                        f"{cur_state}; break_reason="
                        f"{loop_cfg.get('break_reason', 'unknown')!r})"
                    )
                    continue
                # Bump server-side iteration_count so /loop/status
                # reflects reality. (The server doesn't auto-increment
                # — Phase 2 endpoint stores config; iteration is
                # client-driven.)
                loop_cfg["iteration_count"] = (
                    int(loop_cfg.get("iteration_count", 0)) + 1
                )
                iter_count = loop_cfg["iteration_count"]
                max_iter = int(loop_cfg.get("max_iterations", 20))
                cond_str = (loop_driver.get("cond") or "").strip()
                # Check break_condition via cheap substring match.
                # LLM-judge fallback for semantic conditions is
                # deferred — for v1, the condition is a simple
                # phrase the agent's result must contain to halt
                # (mirrors architect's two-tier model: cheap path
                # first; LLM judge later).
                cond_fired = False
                if cond_str and isinstance(result, str):
                    cond_fired = cond_str.lower() in result.lower()
                if cond_fired:
                    print(
                        f"(loop break_condition fired at iteration "
                        f"{iter_count}: result contains {cond_str!r})"
                    )
                    try:
                        await client.loop_stop(
                            break_reason="break_condition_fired",
                        )
                    except Exception:
                        pass
                    loop_driver["active"] = False
                    state["auto_approve"] = bool(
                        loop_driver.get("saved_auto_approve", False)
                    )
                    continue
                if iter_count >= max_iter:
                    print(
                        f"(loop max_iterations reached: {iter_count}/"
                        f"{max_iter})"
                    )
                    try:
                        await client.loop_stop(
                            break_reason="max_iterations_reached",
                        )
                    except Exception:
                        pass
                    loop_driver["active"] = False
                    state["auto_approve"] = bool(
                        loop_driver.get("saved_auto_approve", False)
                    )
                    continue
                # All gates passed — re-enqueue the prompt for
                # another iteration.
                print(
                    f"(loop iteration {iter_count}/{max_iter} complete; "
                    f"re-dispatching same prompt for iteration "
                    f"{iter_count + 1})"
                )
                await input_queue.put(loop_driver["last_prompt"])

    # P3 follow-up (2026-05-07): wrap the producer as an explicit task
    # so the consumer can cancel it on consumer-initiated termination
    # (e.g. SessionEndedError — server-side cancel cancels every
    # subsequent prompt before it lands, so we exit the REPL instead
    # of looping). Without this wrapping, the producer awaits
    # `read_prompt("> ")` with no timeout; even after the consumer
    # sets `should_exit=True` and breaks, gather doesn't return until
    # the user presses any key. Cancelling the producer task surfaces
    # the exit immediately.
    producer_task = asyncio.create_task(_producer())
    state["_producer_task"] = producer_task  # consumer reads this to cancel
    try:
        with stdout_patch:
            await asyncio.gather(producer_task, _consumer())
    except asyncio.CancelledError:
        # Producer cancellation propagates here when the consumer
        # cancels it on SessionEndedError. Treat as clean exit (we
        # already printed `[Session ended]` from the consumer).
        pass
    finally:
        # Defensive: ensure the producer task is finished, even if
        # gather aborted before it returned naturally.
        if not producer_task.done():
            producer_task.cancel()
            try:
                await producer_task
            except (asyncio.CancelledError, Exception):
                pass
        # E42 (2026-05-13): cancel any /bg tasks still running. They
        # are tied to the chat session lifetime — operator-level
        # parallelism, NOT durable background work. Surface a count
        # if anything was cancelled so the operator knows what got
        # cut. For durable runs use `mao-client remote run --detach`.
        _live_bg = [
            t for t in bg_tasks.values()
            if t.status in ("starting", "running") and t.asyncio_task is not None
        ]
        if _live_bg:
            print(
                f"(cancelling {len(_live_bg)} /bg task"
                f"{'s' if len(_live_bg) != 1 else ''} on exit — "
                "their server sessions will be destroyed; for durable "
                "long runs use `mao-client remote run --detach`)",
                file=sys.stderr,
            )
            for _t in _live_bg:
                _t.asyncio_task.cancel()
            # Drain so the underlying clients close cleanly.
            try:
                await asyncio.gather(
                    *(t.asyncio_task for t in _live_bg),
                    return_exceptions=True,
                )
            except Exception:
                pass
        if state["intent"] == "detach" and client.session_id and client.nonce:
            _save_active_session(
                server=cfg.server,
                agent_name=master,
                session_id=client.session_id,
                nonce=client.nonce,
            )
            sid = client.session_id
            print(
                f"(detached — session {sid[:12]}… kept alive on the "
                "server. Next `agents remote chat` will offer to resume.)"
            )
            await client.detach()
        else:
            # Full destroy: clear the cache so a leftover detached
            # session from yesterday doesn't auto-offer alongside today's
            # explicit /exit.
            _clear_active_session()
            await client.close()
    return 0
