"""HTTP client + SSE driver for the remote-CLI REPL — extracted
from `remote_cli.py` as the fifth sub-module of the Phase 1
decomposition (per the addendum §3 Sprint 7 sub-module 5 of 6:
"client").

Two names live here after Sprint 1e-b:
  - `SessionEndedError` — exception raised by `_consume_stream`
    when the server returns 410 Gone on an SSE-streaming POST.
    Extracted Sprint 1e-a (2026-05-16, v3.19.1).
  - `RemoteSessionClient` — drives a single session on a remote
    master_agents_os server. Handles the SSE + POST dance for
    tool-inversion without surfacing it to the caller.
    Extracted Sprint 1e-b (2026-05-16, v3.20.0).

Re-exported from `master_agents_client.remote_cli` via the facade pattern.

Extraction history: Sprint 7 sub-module 5 (informal: Sprint 1e),
2026-05-16, branched off `v3.19.1` main tip + E91 architecture
fix. VERBATIM from `remote_cli.py:143-175` (SessionEndedError) and
`remote_cli.py:400-1616` (RemoteSessionClient) via E83 verbatim
passthrough at `apply_edit_step`. Sprint 1e-b uses E91 file-fed
verbatim (`expected_body_file`) since the 1217-LoC class body
exceeds the planner LLM's safe inline-emission size.
"""

from __future__ import annotations

import json
import sys
import time
from pathlib import Path
from typing import Any

import httpx

from ..remote_client import DEFAULT_CLIENT_SIDE_TOOLS, RemoteToolExecutor
from ..tools import BUILTINS
from ..tracer import Tracer
from .render import _print_remote_token_line
from .sse import _parse_sse_chunk


class SessionEndedError(Exception):
    """Server cancelled the session before our request could complete.

    Raised by `_consume_stream` when the server returns `410 Gone` on
    one of the SSE-streaming POST endpoints — `/turn`,
    `/local_tool_result`, or `/resume`. Server-side this response is
    correct (per `the service`: the pending request has been
    cancelled by F1 timeout, container restart, session_cancel, or
    ws-disconnect cleanup). Client-side, the legacy behaviour of
    propagating `httpx.HTTPStatusError` crashed the CLI with a Python
    traceback — operators saw "your client is broken" when actually
    the server was correctly reporting a session that had moved on.
    The CLI command handlers `_cmd_remote_run` (returns 1 + stderr
    `[Session ended]`) and `_cmd_remote_chat` (breaks the REPL loop
    with the same marker) catch this specifically.

    Distinct from `RuntimeError` (intentionally — see test
    `test_session_ended_error_is_not_runtime_error`) so the CLI
    handlers can catch this case ahead of generic `Exception` and
    exit cleanly instead of looping on the same error every turn.

    Scope note: `rehydrate()` does NOT route through this translation
    — it issues its own POST and surfaces 410 to the caller (which
    falls back to a fresh `open()`). Different recovery semantics:
    rehydrate's 410 means "the resume target is gone, start fresh,"
    not "your in-flight work is lost." If a future change unifies
    the two paths, lift the 410 translation up to a shared helper.

    Real incidents motivating this fix: tasks `bk2yynbp0` (F1 redeploy
    cancelled session `30f2c613`) and `bl9p2rii3` (routine container
    restart cancelled session `6babf136d286445ba6a6cd7b4a58f605`),
    both within one session 2026-05-07.
    """


class RemoteSessionClient:
    """Drives a single session on a remote master_agents_os server.

    Handles the SSE + POST dance for tool-inversion without surfacing it to
    the caller: `await client.run(agent_name, prompt)` returns the final text.
    """

    def __init__(
        self,
        *,
        base_url: str,
        token: str | None,
        cwd: Path | str,
        writable_paths: list[str],
        transport: httpx.BaseTransport | httpx.AsyncBaseTransport | None = None,
        tracer: Tracer | None = None,
        heartbeat: bool = False,
        show_diffs: bool = False,
        diff_color: bool = True,
        on_needs_input: Any = None,
        on_needs_approval: Any = None,
        # E48 (2026-05-14): if True (default), the client walks for
        # CLAUDE.md files from `cwd` to repo-root / $HOME at
        # `open()` and ships the rendered `<project_context>` block
        # to the server. Set to False via the `--no-project-context`
        # CLI flag or by callers that explicitly want a bare session
        # (e.g. tests, scripts that don't want their CLAUDE.md
        # rules to influence the agent).
        project_context: bool = True,
        # E47 (2026-05-14): structured permission rules. Schema:
        # {"allow": ["<Tool(pattern)>", ...], "deny": [...]}. None
        # (default) keeps legacy writable_paths-only enforcement.
        # Typically loaded from remote.yaml's permissions: block by
        # the CLI wrapper; tests / programmatic callers can pass
        # explicit rules.
        permissions: dict[str, list[str]] | None = None,
        # K.1 (Wave K, 2026-05-18): security policy gates. Both
        # default None -> built-in safe-defaults (sim-os.ai +
        # localhost URL allowlist; canonical read-sensitive-then-
        # http-external sequence rule). Pass raw dict (from
        # remote.yaml or programmatic) and the client converts via
        # `from_yaml_dict`.
        call_home_policy: dict | None = None,
        tool_sequence_policy: dict | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.token = token
        self.cwd = Path(cwd).resolve()
        self.writable_paths = list(writable_paths)
        self._transport = transport
        self._tracer = tracer
        # When True, _consume_stream prints a dim "▸ thinking…" line as soon
        # as the SSE POST is in flight, then ANSI-overwrites it the moment
        # the first real event arrives. Off by default so non-chat callers
        # (e.g. agents remote run, tests) don't get spurious stderr noise.
        self._heartbeat = heartbeat
        # Callbacks for the agent's `ask_user` and approval flows. When
        # the server emits a needs_input / needs_approval event mid-turn,
        # _drive_turn calls these to get the user's answer + posts back
        # via /sessions/{id}/resume. None means the client raises
        # RuntimeError on those events (the original behaviour, fine
        # for `agents remote run` which doesn't expect them).
        # Signatures:
        #   on_needs_input(question: str) -> str          # awaitable
        #   on_needs_approval(tool, preview) -> bool      # awaitable
        self._on_needs_input = on_needs_input
        self._on_needs_approval = on_needs_approval
        # Populated by `_consume_stream` from the server's `final` event so
        # callers (e.g. interactive chat) can print per-turn + cumulative
        # token totals after each turn.
        self.last_tokens: dict[str, Any] | None = None
        # Wallclock duration of the most recent turn() call, in seconds.
        # Set by turn() in a finally so it's populated even on error.
        # None until the first turn completes.
        self.last_turn_seconds: float | None = None
        # captured from the server's cost_band_summary trace event
        # (emitted at root agent turn-end when estimate_tokens fired).
        # Consumed by _print_remote_token_line to surface the tier
        # indicator under the answer. None when no estimate calls were
        # made in the turn.
        self.last_cost_summary: dict[str, Any] | None = None
        # last known cap snapshot from set_cap. Used by the chat
        # REPL's footer to render `cap: X / Y used` on every turn even
        # when the cap wasn't touched this turn. None when no cap has
        # been set in this session.
        self.last_cap: dict[str, Any] | None = None
        # Session lifecycle state for the long-lived chat mode (open/turn/
        # close). Stays None for one-shot run() callers, which manage their
        # own AsyncClient + session inside the call.
        self._http: httpx.AsyncClient | None = None
        self._session_id: str | None = None
        self._nonce: str | None = None
        # E47 (2026-05-14) — build a PermissionsConfig from the
        # caller-provided permissions dict. None / empty → no
        # permission engine attached (legacy writable_paths-only mode).
        # Construction validates rule syntax via parse_rule(); a typo
        # surfaces here at client init rather than silently failing
        # to match later.
        permissions_engine: Any = None
        if permissions:
            try:
                from ..permissions import (  # type: ignore[import-not-found]
                    PermissionsConfig,
                )
                permissions_engine = PermissionsConfig(
                    allow=list(permissions.get("allow") or []),
                    deny=list(permissions.get("deny") or []),
                )
            except ImportError:
                # permissions.py is wheel-only — server-source-only
                # dev installs silently skip the engine (legacy mode).
                permissions_engine = None

        # K.1 (Wave K, 2026-05-18): build CallHomePolicy +
        # ToolSequencePolicy from caller-provided dicts. None ->
        # safe defaults; dict -> from_yaml_dict (raises on misconfig
        # like applies_to_tools=[]). Lazy import for back-compat with
        # server-source-only dev installs lacking permissions.py
        # (wheel-only file).
        call_home_engine: Any = None
        tool_sequence_engine: Any = None
        try:
            from ..permissions import (  # type: ignore[import-not-found]
                CallHomePolicy,
                ToolSequencePolicy,
            )
            if call_home_policy is None:
                call_home_engine = CallHomePolicy()  # default-safe
            else:
                call_home_engine = CallHomePolicy.from_yaml_dict(
                    call_home_policy
                )
            if tool_sequence_policy is None:
                tool_sequence_engine = ToolSequencePolicy()  # default-safe
            else:
                tool_sequence_engine = ToolSequencePolicy.from_yaml_dict(
                    tool_sequence_policy
                )
        except ImportError:
            # Server-source-only dev installs skip policy engines.
            call_home_engine = None
            tool_sequence_engine = None

        self._executor = RemoteToolExecutor(
            cwd=self.cwd,
            writable_paths=self.writable_paths,
            tools={n: BUILTINS[n] for n in DEFAULT_CLIENT_SIDE_TOOLS if n in BUILTINS},
            show_diffs=show_diffs,
            diff_color=diff_color,
            permissions=permissions_engine,
            call_home_policy=call_home_engine,
            tool_sequence_policy=tool_sequence_engine,
        )
        # E48 (2026-05-14): stash the project-context toggle for use
        # at open() time. The actual walk fires lazily on session-
        # create so tests can toggle without re-instantiating the
        # client.
        self._project_context_enabled = bool(project_context)

    def _auth_headers(self, nonce: str | None = None) -> dict[str, str]:
        headers: dict[str, str] = {}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        if nonce:
            headers["X-Session-Nonce"] = nonce
        return headers

    async def run(
        self,
        agent_name: str,
        prompt: str,
        *,
        # Phase 1 will populate these from CLI flags. Defaults preserve
        # the original simple-positional contract — `client.run(agent,
        # prompt)` keeps working unchanged. Each kwarg maps 1:1 to the
        # equivalent chat slash command's POST endpoint:
        #   cap                       → POST /sessions/{id}/set_cap
        #   threshold_ask_user        → POST /sessions/{id}/set_budget
        #   threshold_max_steps       → POST /sessions/{id}/set_max_steps
        #   threshold_total_steps     → POST /sessions/{id}/set_total_steps
        #   threshold_turn_input      → POST /sessions/{id}/set_turn_input_ceiling
        #   threshold_auto_compact    → POST /sessions/{id}/set_compact_threshold
        #   model                     → POST /sessions/{id}/set_model
        # detach / resume_session_id control the open / close lifecycle
        # (mirror chat's `--resume`, `/detach`).
        cap: int | None = None,
        threshold_ask_user: int | None = None,
        threshold_max_steps: int | None = None,
        threshold_total_steps: int | None = None,
        threshold_turn_input: int | None = None,
        threshold_auto_compact: int | None = None,
        model: str | None = None,
        # .5 (2026-05-14): per-session max_output_tokens override.
        max_output_tokens: int | None = None,
        detach: bool = False,
        resume_session_id: str | None = None,
    ) -> str:
        """One-shot: open a session, run a single turn, tear down.

        Used by `agents remote run` and most tests. For the long-lived
        chat REPL, prefer `open()` → repeated `turn()` → `close()` so the
        server-side conversation history persists across prompts.

        Declares interactive=False because there is no REPL to answer
        ask_user — the runner gates that tool server-side and the
        agent must proceed with stated assumptions.

        All keyword-only args default to None / False / no-op so the
        simple positional call `client.run(agent, prompt)` keeps its
        original semantics. New flags arrive in Phase 1 of the
        consolidation branch.
        """
        if resume_session_id is not None:
            await self.open_resumed(resume_session_id)
        else:
            await self.open(agent_name, interactive=False)
        try:
            # Apply any session-control settings BEFORE the turn —
            # mirrors a chat operator typing slash commands before
            # their first prompt. Each helper is a no-op when its
            # arg is None.
            await self._apply_run_controls(
                cap=cap,
                threshold_ask_user=threshold_ask_user,
                threshold_max_steps=threshold_max_steps,
                threshold_total_steps=threshold_total_steps,
                threshold_turn_input=threshold_turn_input,
                threshold_auto_compact=threshold_auto_compact,
                model=model,
                max_output_tokens=max_output_tokens,
            )
            return await self.turn(prompt)
        finally:
            if not detach:
                await self.close()

    async def open_resumed(self, session_id: str) -> None:
        """Re-attach to an existing server-side session by id, instead
        of creating a new one. Mirror of chat's `--resume <id>` — the
        session's conversation history is preserved across the boundary.

        Thin wrapper over the existing `rehydrate()` method (which
        chat's --resume / --pick paths use) — keeps a single canonical
        re-attachment surface.
        """
        await self.rehydrate(session_id)

    async def _apply_run_controls(
        self,
        *,
        cap: int | None = None,
        threshold_ask_user: int | None = None,
        threshold_max_steps: int | None = None,
        threshold_total_steps: int | None = None,
        threshold_turn_input: int | None = None,
        threshold_auto_compact: int | None = None,
        model: str | None = None,
        # .5 (2026-05-14): per-session max_output_tokens override.
        max_output_tokens: int | None = None,
    ) -> None:
        """Apply the chat-slash-command-equivalent session controls.

        Each branch fires only when its kwarg is non-None — all-None
        invocation is a complete no-op (the simple-positional
        `client.run(agent, prompt)` path's default).

        Each call dispatches to an existing `POST /sessions/{id}/set_*`
        endpoint that chat operators already use via slash commands.
        No new server-side surface; pure leverage.
        """
        if cap is not None:
            await self.set_cap(cap)
        if threshold_ask_user is not None:
            await self.set_budget(threshold_ask_user)
        if threshold_max_steps is not None:
            await self.set_max_steps(threshold_max_steps)
        if threshold_total_steps is not None:
            await self.set_total_steps(threshold_total_steps)
        if threshold_turn_input is not None:
            await self.set_turn_input_ceiling(threshold_turn_input)
        if threshold_auto_compact is not None:
            await self.set_compact_threshold(threshold_auto_compact)
        if model is not None:
            await self.set_model(model)
        if max_output_tokens is not None:
            await self.set_max_output_tokens(max_output_tokens)

    async def open(
        self,
        agent_name: str,
        *,
        interactive: bool = True,
        plan_mode: bool = False,
    ) -> None:
        """Create a server-side session and keep it open across multiple
        turns. Persists `session_id` + `nonce` on the client so subsequent
        `turn()` calls reuse the same conversation history.

        `interactive` defaults True (chat REPL can answer ask_user).
        Set False from one-shot paths (run()) so the runner gates
        ask_user and the agent backs off with stated assumptions.

        `plan_mode` (Wave B Phase 3, 2026-05-17) defaults False. When
        True, the server starts the session in PLANNING state — the
        agent uses read-only tools to explore, then calls `plan_emit`
        to propose a plan. The session enters AWAITING_APPROVAL; the
        next /turn returns 409 until the client POSTs
        /sessions/{id}/plan/approve or /plan/reject.

        Raises RuntimeError if already open — callers must `close()` first.
        """
        if self._http is not None:
            raise RuntimeError("client already open; call close() first")
        http = httpx.AsyncClient(
            transport=self._transport, base_url=self.base_url, timeout=None,
        )
        try:
            from ..platform_info import detect_client_platform
            #  + 2026-05-07 cwd extension: machine-level platform
            # detection (os/shell/wsl_distro) PLUS session-level cwd.
            # Why cwd lives here, not in detect_client_platform(): the
            # detector's output is module-cached (machine doesn't
            # change mid-process); cwd is per-session (varies by where
            # the user invoked `agents remote run`). Keep the caches
            # separate. Real failure mode this fixes (P3 trace
            # `c641042702714d7fa5a2897a8ceb5104`): agent guessed
            # `/master_agents_os`, `/workspace`, `/home`; all failed;
            # tried ask_user (BLOCKED in non-interactive mode); gave
            # up with generic content. Surfacing cwd in the platform
            # block lets the agent grep with the right base on turn 1.
            platform_payload = dict(detect_client_platform())
            platform_payload["cwd"] = str(self.cwd)
            # E48 (2026-05-14): walk for CLAUDE.md files at session
            # open and pre-render the `<project_context>` block. Pure
            # client-side work (per E45 — container is filesystem-
            # blind for user content). Disabled via __init__'s
            # `project_context=False` (set by --no-project-context
            # CLI flag).
            project_context_str: str | None = None
            if self._project_context_enabled:
                try:
                    from ..project_context import (  # type: ignore[import-not-found]
                        collect_project_context_files,
                        render_project_context,
                        ProjectContextTooLarge,
                    )
                    files = collect_project_context_files(self.cwd)
                    block, disclosure = render_project_context(files)
                    if disclosure:
                        # Stderr disclosure lets the user see what
                        # loaded without polluting stdout (which
                        # downstream tools may pipe).
                        print(disclosure, file=sys.stderr)
                    project_context_str = block or None
                except ImportError:
                    # project_context.py is wheel-only — server-source
                    # dev installs without the public client wheel
                    # silently skip the walk.
                    pass
                except Exception as exc:
                    # >80k token abort or any other walk error.
                    # Surface the error and re-raise so callers see a
                    # clean failure.
                    print(f"E48: {type(exc).__name__}: {exc}", file=sys.stderr)
                    raise
            create = await http.post(
                "/sessions",
                json={
                    "agent_name": agent_name,
                    "remote_client_tools": sorted(DEFAULT_CLIENT_SIDE_TOOLS),
                    # tell the server which OS / shell / cwd the
                    # client is actually running in. Server injects this
                    # into the agent's system prompt so specialists pick
                    # the right command syntax + path base instead of
                    # guessing.
                    "client_platform": platform_payload,
                    # False = one-shot non-interactive (e.g.
                    # `agents remote run`); server's runner gates
                    # ask_user pre-dispatch.
                    "interactive": interactive,
                    # E48: pre-rendered project-rules block (may be
                    # None — server treats that as "no walk").
                    "project_context": project_context_str,
                    # Wave B Phase 3 (2026-05-17) — when True, the
                    # server starts the session in PLANNING state.
                    # Default False keeps all pre-Wave-B callers
                    # unchanged. Set via --plan on `mao-client remote
                    # chat` (Phase 3 CLI flag).
                    "plan_mode": plan_mode,
                },
                headers=self._auth_headers(),
            )
            create.raise_for_status()
            body = create.json()
            self._session_id = body["session_id"]
            self._nonce = body["session_nonce"]
            self._http = http
            # E53 (2026-05-15) — surface client/server tool-set mismatch
            # to the operator at chat start. Pre-E53 failure mode:
            # client v3.12.0 advertised `knowledge_search` / `slack_post`
            # / `webhook_post`; deployed server was v3.10.0 + lacked them
            # in BUILTINS; server logged "substitution will skip them
            # silently"; operator never saw it. Now the server returns
            # the diff in the session-create response; we print a single
            # yellow warning here so the operator can deploy before
            # re-trying. Best-effort: missing field on older servers
            # just no-ops.
            self._unknown_to_server = list(
                body.get("unknown_to_server_tools") or []
            )
            self._server_builtins_count = body.get("server_builtins_count")
            if self._unknown_to_server:
                # stderr, not stdout — keeps streaming consumers' output
                # clean while making the warning visible.
                print(
                    f"⚠️  E53 — server version drift detected.\n"
                    f"    Client advertised "
                    f"{len(self._unknown_to_server)} tool(s) "
                    f"NOT in the deployed server's BUILTINS dict: "
                    f"{', '.join(self._unknown_to_server)}.\n"
                    f"    These tools will be silently skipped during "
                    f"this session. To fix: ensure the deployed server "
                    f"version matches the client; for self-hosted, run "
                    f"`vps/start.sh` to rebuild master-agents-api.",
                    file=sys.stderr,
                )
        except Exception:
            await http.aclose()
            raise

    async def turn(self, prompt: str) -> str:
        """Drive one turn against the currently-open session.

        Records wallclock duration on `self.last_turn_seconds` so the
        chat REPL can show 'Time: 30s' alongside the token line.
        """
        import time

        if self._http is None or self._session_id is None or self._nonce is None:
            raise RuntimeError("client not open; call open() first")
        # Reset the per-turn cost summary so the previous turn's tier
        # indicator doesn't bleed into a turn that didn't call
        # estimate_tokens. last_tokens self-replaces from `final.tokens`.
        self.last_cost_summary = None
        start = time.perf_counter()
        try:
            return await self._drive_turn(
                self._http, self._session_id, self._nonce, prompt,
            )
        finally:
            self.last_turn_seconds = time.perf_counter() - start

    async def reset(self) -> dict[str, Any]:
        """Clear the master agent's conversation history server-side.

        Returns the server's response, e.g. `{"status": "reset",
        "messages_cleared": 4}`.
        """
        if self._http is None or self._session_id is None or self._nonce is None:
            raise RuntimeError("client not open; call open() first")
        resp = await self._http.post(
            f"/sessions/{self._session_id}/reset",
            headers=self._auth_headers(self._nonce),
        )
        resp.raise_for_status()
        return resp.json()

    async def memory_list_curate(
        self,
        scope: str,
        qualifier: str = "",
        *,
        prefix: str = "",
        max_results: int = 200,
        created_by_agent: str | None = None,
    ) -> dict[str, Any]:
        """v3.2.0 — list memory keys for a scope/qualifier WITHOUT a
        session. Powers `mao-client memory list`. Returns
        `{scope, qualifier, total, keys: [{key, value_chars,
        updated_at, created_by_agent}]}`.

        Uses the bearer-token-only `/memory/list` endpoint (no session
        nonce required) so users can audit memory before opening any
        agent session.

        v3.3.1: `created_by_agent` (optional) filters the result set
        to entries saved while the named agent was the master. Powers
        the `/memory list by <agent>` slash command. None means no
        filter — return all entries.
        """
        if self.token is None:
            raise RuntimeError(
                "memory curation requires a configured token"
            )
        # Use a short-lived httpx client since curation may be called
        # without prior open() — no session, no _http set up.
        import httpx
        body: dict[str, Any] = {
            "scope": scope,
            "qualifier": qualifier,
            "prefix": prefix,
            "max_results": max_results,
        }
        if created_by_agent is not None:
            body["created_by_agent"] = created_by_agent
        async with httpx.AsyncClient(
            base_url=self.base_url, timeout=15.0,
        ) as http:
            resp = await http.post(
                "/memory/list",
                headers={"Authorization": f"Bearer {self.token}"},
                json=body,
            )
            resp.raise_for_status()
            return resp.json()

    async def memory_get_curate(
        self, scope: str, key: str, qualifier: str = "",
    ) -> dict[str, Any]:
        """v3.2.0 — fetch one memory entry's full value via the
        non-session `/memory/get` endpoint. Raises HTTPStatusError on
        404 (not-found) so the CLI can render a friendly error.
        Returns `{scope, qualifier, key, value, value_chars}`.
        """
        if self.token is None:
            raise RuntimeError("memory curation requires a configured token")
        import httpx
        async with httpx.AsyncClient(
            base_url=self.base_url, timeout=15.0,
        ) as http:
            resp = await http.post(
                "/memory/get",
                headers={"Authorization": f"Bearer {self.token}"},
                json={"scope": scope, "qualifier": qualifier, "key": key},
            )
            resp.raise_for_status()
            return resp.json()

    async def memory_delete_curate(
        self, scope: str, key: str, qualifier: str = "",
    ) -> dict[str, Any]:
        """v3.2.0 — delete one memory entry. Idempotent (missing key
        returns existed=false, not 404). Returns
        `{scope, qualifier, key, existed: bool}`.
        """
        if self.token is None:
            raise RuntimeError("memory curation requires a configured token")
        import httpx
        async with httpx.AsyncClient(
            base_url=self.base_url, timeout=15.0,
        ) as http:
            resp = await http.post(
                "/memory/delete",
                headers={"Authorization": f"Bearer {self.token}"},
                json={"scope": scope, "qualifier": qualifier, "key": key},
            )
            resp.raise_for_status()
            return resp.json()

    async def remember(
        self, text: str, *, key: str | None = None,
    ) -> dict[str, Any]:
        """v3.1.0 — save a fact to user-scope memory via the server's
        `/memory/remember` endpoint. Powers the `/remember <text>`
        slash command in the chat REPL.

        On the NEXT session start, the new fact appears in every
        agent's `<memory>` block auto-load (user-scope is cross-cutting).

        `key` is optional — if omitted the server generates a
        timestamp-based key (`note_<UTC-timestamp>`). When provided,
        must be 1-64 chars [A-Za-z0-9_-] only.

        Returns the server's response, e.g. `{"status": "remembered",
        "scope": "user", "key": "note_20260513T133542Z",
        "value_chars": 42}`.
        """
        if self._http is None or self._session_id is None or self._nonce is None:
            raise RuntimeError("client not open; call open() first")
        body: dict[str, Any] = {"text": text}
        if key is not None:
            body["key"] = key
        resp = await self._http.post(
            f"/sessions/{self._session_id}/memory/remember",
            headers=self._auth_headers(self._nonce),
            json=body,
        )
        resp.raise_for_status()
        return resp.json()

    async def compact(self) -> dict[str, Any]:
        """Fold older messages into a summary server-side.

        Returns the server's response, e.g. `{"status": "compacted",
        "removed_messages": 6, "before_tokens": 12000, "after_tokens": 4500,
        "summary_tokens": 320}` or `{"status": "no_op", "removed_messages": 0}`
        if there was nothing to compact.
        """
        if self._http is None or self._session_id is None or self._nonce is None:
            raise RuntimeError("client not open; call open() first")
        resp = await self._http.post(
            f"/sessions/{self._session_id}/compact",
            headers=self._auth_headers(self._nonce),
        )
        resp.raise_for_status()
        return resp.json()

    async def resume(self, session_id: str, nonce: str) -> dict[str, Any]:
        """Adopt an existing server-side session without minting a new one.

        Used when a previous chat invocation called /detach and saved its
        session_id+nonce. We probe `GET /sessions/{id}/resume_state` to
        confirm the session is still alive (not idle-reaped); if it is,
        we re-use it and skip the POST /sessions cost. Returns the
        server's state snapshot on success.

        Raises RuntimeError if already open. Raises httpx.HTTPStatusError
        on 404 (session reaped — caller can fall back to rehydrate()).
        """
        if self._http is not None:
            raise RuntimeError("client already open; call close() first")
        http = httpx.AsyncClient(
            transport=self._transport, base_url=self.base_url, timeout=None,
        )
        try:
            check = await http.get(
                f"/sessions/{session_id}/resume_state",
                headers={**self._auth_headers(nonce)},
            )
            check.raise_for_status()
            self._session_id = session_id
            self._nonce = nonce
            self._http = http
            return check.json()
        except Exception:
            await http.aclose()
            raise

    async def rehydrate(self, old_session_id: str) -> dict[str, Any]:
        """Recreate a session from Postgres-persisted history when the
        original was idle-reaped. Returns a NEW session_id+nonce
        pre-loaded with the prior conversation buffer; the old id is
        retired.

        Server returns 503 if Postgres isn't configured, 404 if the row
        doesn't exist, 410 if the session was explicitly terminated.
        Client falls back to a fresh open() in those cases.
        """
        if self._http is not None:
            raise RuntimeError("client already open; call close() first")
        http = httpx.AsyncClient(
            transport=self._transport, base_url=self.base_url, timeout=None,
        )
        try:
            resp = await http.post(
                f"/sessions/{old_session_id}/rehydrate",
                headers=self._auth_headers(),
            )
            resp.raise_for_status()
            body = resp.json()
            self._session_id = body["session_id"]
            self._nonce = body["session_nonce"]
            self._http = http
            return body
        except Exception:
            await http.aclose()
            raise

    async def set_model(self, model: str) -> dict[str, Any]:
        """: override the master agent's model tier for this
        session. Accepts user-facing aliases: 'standard' / 'flash'
        for the standard tier, 'pro' for the pro tier. Backend
        provider is intentionally opaque on this API surface.
        Returns server's response: {status, alias, tier}."""
        if self._http is None or self._session_id is None or self._nonce is None:
            raise RuntimeError("client not open; call open() first")
        resp = await self._http.post(
            f"/sessions/{self._session_id}/set_model",
            headers=self._auth_headers(self._nonce),
            json={"name": model},  # server's body field is `name`
        )
        resp.raise_for_status()
        return resp.json()

    async def get_thresholds(self) -> dict[str, Any]:
        """: introspect all current session thresholds in one
        round-trip. Returns the effective values for cap, budget,
        compact_threshold, plus context state (history_tokens,
        model_max, mandatory_floor, model_alias) and the
        allow_main_commits flag.

        Each value carries a `source` label (session / spec / default)
        so the user knows which layer is winning.
        """
        if self._http is None or self._session_id is None or self._nonce is None:
            raise RuntimeError("client not open; call open() first")
        resp = await self._http.get(
            f"/sessions/{self._session_id}/thresholds",
            headers=self._auth_headers(self._nonce),
        )
        resp.raise_for_status()
        return resp.json()

    async def set_allow_main_commits(self, allowed: bool) -> dict[str, Any]:
        """: per-session override for the feat-branch-only commit
        guard. Default False (guard active). Returns
        {status, allow_main_commits}.
        """
        if self._http is None or self._session_id is None or self._nonce is None:
            raise RuntimeError("client not open; call open() first")
        resp = await self._http.post(
            f"/sessions/{self._session_id}/set_allow_main_commits",
            headers=self._auth_headers(self._nonce),
            json={"allowed": bool(allowed)},
        )
        resp.raise_for_status()
        return resp.json()

    async def set_compact_threshold(
        self, tokens: int | None,
    ) -> dict[str, Any]:
        """: per-session auto-compact threshold override. The
        mandatory 80% floor still applies as a safety net.
        Pass int (positive) to set; None to clear.
        Returns {status, compact_threshold}.
        """
        if self._http is None or self._session_id is None or self._nonce is None:
            raise RuntimeError("client not open; call open() first")
        resp = await self._http.post(
            f"/sessions/{self._session_id}/set_compact_threshold",
            headers=self._auth_headers(self._nonce),
            json={"tokens": tokens},
        )
        resp.raise_for_status()
        return resp.json()

    async def set_turn_input_ceiling(
        self, tokens: int | None,
    ) -> dict[str, Any]:
        """: per-session per-turn input-token ceiling override.
        Persists for every remaining turn of the session — set once,
        applies until reset. Default is unlimited; pass int (positive)
        to set a ceiling, None to clear.
        Returns {status, turn_input_ceiling}.
        """
        if self._http is None or self._session_id is None or self._nonce is None:
            raise RuntimeError("client not open; call open() first")
        resp = await self._http.post(
            f"/sessions/{self._session_id}/set_turn_input_ceiling",
            headers=self._auth_headers(self._nonce),
            json={"tokens": tokens},
        )
        resp.raise_for_status()
        return resp.json()

    async def list_agents(
        self, channel: str | None = None,
    ) -> dict[str, Any]:
        """ UAT — list available master agents on the server.

        Calls GET /agents (the existing endpoint that powers the
        --pick UI). When `channel` is provided, server filters the
        list to agents whose `channels` allowlist admits that
        channel. CLI sessions should pass channel='cli'.

        Returns {agents: [name], details: [{name, description,
        channels, model, ...}]}.
        """
        if self._http is None or self._nonce is None:
            raise RuntimeError("client not open; call open() first")
        params = {"channel": channel} if channel else {}
        # /agents uses auth_dep (token only), not nonce_dep, so the
        # session_nonce header is unnecessary — but `_auth_headers`
        # adds it harmlessly.
        resp = await self._http.get(
            "/agents",
            headers=self._auth_headers(self._nonce),
            params=params,
        )
        resp.raise_for_status()
        return resp.json()

    async def set_master(self, name: str) -> dict[str, Any]:
        """: switch the active master agent mid-session.

        The new master inherits the conversation history; a
        synthetic UserMessage marks the handoff so the LLM
        doesn't conflate prior tool calls (made under a
        different system prompt) with its own. Subsequent /turn
        calls run as the new master with the new spec's tools,
        system prompt, and per-turn caps.

        Returns {status, previous_master, new_master}. Raises
        httpx.HTTPStatusError(400) on validation failure (unknown
        agent, channel mismatch, attempting to switch to current).
        """
        if self._http is None or self._session_id is None or self._nonce is None:
            raise RuntimeError("client not open; call open() first")
        resp = await self._http.post(
            f"/sessions/{self._session_id}/set_master",
            headers=self._auth_headers(self._nonce),
            json={"name": name},
        )
        resp.raise_for_status()
        return resp.json()

    async def kill_session_by_id(self, session_id: str) -> dict[str, Any]:
        """E42 (2026-05-14) — terminate an ARBITRARY session by id
        using bearer-only auth.

        Companion to `close()` (which deletes the CURRENT session via
        DELETE /sessions/{id} + nonce). This method hits the new
        POST /sessions/{id}/kill auth-only endpoint, so it works
        against sessions the caller didn't open themselves — i.e. the
        `/tasks kill <id>` slash command use case.

        Returns the server response: `{"status": "killed"}` or raises
        on 404 / auth failure.
        """
        if self._http is None:
            raise RuntimeError("client not open; call open() first")
        resp = await self._http.post(
            f"/sessions/{session_id}/kill",
            headers=self._auth_headers(),
        )
        resp.raise_for_status()
        return resp.json()

    async def set_max_output_tokens(
        self, tokens: int | None,
    ) -> dict[str, Any]:
        """.5 (2026-05-14): per-session override for the
        per-LLM-call max_output_tokens cap. Persists for every
        remaining LLM call in the session. Pass int (positive) to
        set, None to revert to spec.max_output_tokens.

        Closes the recurring truncation failure mode by letting
        operators bump the cap per-session without a spec edit +
        redeploy.

        Returns {status, max_output_tokens}.
        """
        if self._http is None or self._session_id is None or self._nonce is None:
            raise RuntimeError("client not open; call open() first")
        resp = await self._http.post(
            f"/sessions/{self._session_id}/set_max_output_tokens",
            headers=self._auth_headers(self._nonce),
            json={"tokens": tokens},
        )
        resp.raise_for_status()
        return resp.json()

    async def set_max_steps(
        self, steps: int | None,
    ) -> dict[str, Any]:
        """: per-session max_steps override. Persists for every
        remaining turn of the session. Default falls back to the
        spec's max_steps. Pass int (positive) to set, None to
        clear.
        Returns {status, max_steps}.
        """
        if self._http is None or self._session_id is None or self._nonce is None:
            raise RuntimeError("client not open; call open() first")
        resp = await self._http.post(
            f"/sessions/{self._session_id}/set_max_steps",
            headers=self._auth_headers(self._nonce),
            json={"steps": steps},
        )
        resp.raise_for_status()
        return resp.json()

    async def set_total_steps(
        self, steps: int | None,
    ) -> dict[str, Any]:
        """: per-session max_total_steps override. The
        session-cumulative step counter (across all turns + spawned
        subagents) hard-halts when it crosses this value. Pre-
        the only recovery from MaxTotalStepsExceeded was starting
        a new session — which re-paid the loaded codebase context.
        Persists for the lifetime of the session. Pass int
        (positive) to set, None to revert to the construction-time
        default (typically 100).
        Returns {status, total_steps}.
        """
        if self._http is None or self._session_id is None or self._nonce is None:
            raise RuntimeError("client not open; call open() first")
        resp = await self._http.post(
            f"/sessions/{self._session_id}/set_total_steps",
            headers=self._auth_headers(self._nonce),
            json={"steps": steps},
        )
        resp.raise_for_status()
        return resp.json()

    async def set_cap(self, tokens: int | None) -> dict[str, Any]:
        """: session-wide spend cap (cumulative input+output tokens).
        Pass int (positive) to set; None to remove. Returns server's
        response: {status, cap, used, remaining, halted}.

        Updates `self.last_cap` so the chat REPL's footer can render
        the cap line on every turn without re-querying the server.
        """
        if self._http is None or self._session_id is None or self._nonce is None:
            raise RuntimeError("client not open; call open() first")
        resp = await self._http.post(
            f"/sessions/{self._session_id}/set_cap",
            headers=self._auth_headers(self._nonce),
            json={"tokens": tokens},
        )
        resp.raise_for_status()
        info = resp.json()
        self.last_cap = info if info.get("cap") is not None else None
        return info

    async def set_budget(self, tokens: int | None) -> dict[str, Any]:
        """: override the  cost-gate threshold for this session.
        Pass an int (positive) to set tier_1 at that token count;
        pass None to clear and revert to spec/global default.

        Returns server's response: {status, budget, tier_2_at, tier_3_at}.
        """
        if self._http is None or self._session_id is None or self._nonce is None:
            raise RuntimeError("client not open; call open() first")
        resp = await self._http.post(
            f"/sessions/{self._session_id}/set_budget",
            headers=self._auth_headers(self._nonce),
            json={"tokens": tokens},
        )
        resp.raise_for_status()
        return resp.json()

    async def list_models(self) -> list[dict[str, Any]]:
        """: enumerate switchable model tiers for the /model
        command picker. Returns tier-named entries; backend provider
        names are not exposed on the API surface."""
        if self._http is None:
            raise RuntimeError("client not open; call open() first")
        resp = await self._http.get(
            "/models", headers=self._auth_headers(),
        )
        resp.raise_for_status()
        return list(resp.json().get("models", []))

    async def cancel(self) -> dict[str, Any]:
        """Cancel the currently-running turn server-side. The runner's
        next _check_cancelled() raises SessionCancelled and the in-flight
        turn aborts cleanly. Mid-flight tool calls cancel via the
        existing watchdog. Tools that are non-abortable run to
        completion (their results are then discarded).

        Used by `/cancel` slash command in the chat REPL.
        Returns the server's response, e.g. `{"status": "cancelled"}`.
        """
        if self._http is None or self._session_id is None or self._nonce is None:
            raise RuntimeError("client not open; call open() first")
        resp = await self._http.post(
            f"/sessions/{self._session_id}/cancel",
            headers=self._auth_headers(self._nonce),
        )
        resp.raise_for_status()
        return resp.json()

    async def approve_plan(self) -> dict[str, Any]:
        """Wave B Phase 3 (2026-05-17) — approve the pending plan on
        this session. Transitions server-side plan_state
        AWAITING_APPROVAL -> APPROVED, after which the next /turn
        dispatches the LLM as normal (executing the approved plan).

        Returns the server's response, e.g.
        `{"status": "approved", "plan_state": "PlanState.APPROVED"}`.
        Raises httpx.HTTPStatusError on 409 (no pending plan) or 404
        (unknown session).
        """
        if self._http is None or self._session_id is None or self._nonce is None:
            raise RuntimeError("client not open; call open() first")
        resp = await self._http.post(
            f"/sessions/{self._session_id}/plan/approve",
            headers=self._auth_headers(self._nonce),
        )
        resp.raise_for_status()
        return resp.json()

    async def reject_plan(self, reason: str = "") -> dict[str, Any]:
        """Wave B Phase 3 (2026-05-17) — reject the pending plan with
        an optional reason. Transitions server-side plan_state
        AWAITING_APPROVAL -> REJECTED, clears the stored manifest, and
        records the reason in the trace so the agent can adjust its
        re-plan.

        Returns the server's response, e.g.
        `{"status": "rejected", "plan_state": "PlanState.REJECTED",
        "reason": "<echoed reason>"}`.
        Raises httpx.HTTPStatusError on 409 (no pending plan) or 404
        (unknown session).
        """
        if self._http is None or self._session_id is None or self._nonce is None:
            raise RuntimeError("client not open; call open() first")
        resp = await self._http.post(
            f"/sessions/{self._session_id}/plan/reject",
            headers=self._auth_headers(self._nonce),
            json={"reason": reason},
        )
        resp.raise_for_status()
        return resp.json()

    async def loop_start(
        self,
        max_iterations: int = 20,
        condition_str: str = "",
    ) -> dict[str, Any]:
        """Wave C Phase 2 (2026-05-17) — start an autonomous-iteration
        loop on this session. Server transitions loop_state INACTIVE/
        STOPPED -> RUNNING and stores the loop_config; the chat REPL's
        /loop slash command drives the actual /turn iteration.

        Per architect's hybrid model — server holds state for
        traceability + recovery; client drives turn dispatch + break-
        condition evaluation so the server's per-turn cancellation
        model stays unchanged.

        Returns the server's response:
        `{"status": "running", "loop_state": "...", "loop_config": {...}}`.
        Raises httpx.HTTPStatusError on 409 (loop already running) or
        422 (max_iterations out of 1..100 bounds).
        """
        if self._http is None or self._session_id is None or self._nonce is None:
            raise RuntimeError("client not open; call open() first")
        resp = await self._http.post(
            f"/sessions/{self._session_id}/loop/start",
            headers=self._auth_headers(self._nonce),
            json={
                "max_iterations": max_iterations,
                "condition_str": condition_str,
            },
        )
        resp.raise_for_status()
        return resp.json()

    async def loop_stop(self, break_reason: str = "user_stop") -> dict[str, Any]:
        """Wave C Phase 2 (2026-05-17) — halt an active loop. Server
        transitions loop_state RUNNING -> STOPPED and records the
        break_reason in the loop_config + trace event.

        Safe to call when no loop is active (returns 200 + status=noop)
        so the chat REPL's /stop handler can fire it unconditionally.

        `break_reason` is one of: 'user_stop' / 'break_condition_fired'
        / 'max_iterations_reached' / 'cost_budget_exceeded'.
        """
        if self._http is None or self._session_id is None or self._nonce is None:
            raise RuntimeError("client not open; call open() first")
        resp = await self._http.post(
            f"/sessions/{self._session_id}/loop/stop",
            headers=self._auth_headers(self._nonce),
            json={"break_reason": break_reason},
        )
        resp.raise_for_status()
        return resp.json()

    async def loop_status(self) -> dict[str, Any]:
        """Wave C Phase 2 (2026-05-17) — read the server's current
        loop_state + loop_config. Used by /loop status slash command +
        by the client-side loop-driver between iterations to confirm
        the loop hasn't been externally /stop'd (e.g. another client
        connected to the same session)."""
        if self._http is None or self._session_id is None or self._nonce is None:
            raise RuntimeError("client not open; call open() first")
        resp = await self._http.get(
            f"/sessions/{self._session_id}/loop/status",
            headers=self._auth_headers(self._nonce),
        )
        resp.raise_for_status()
        return resp.json()

    async def detach(self) -> None:
        """Like close() but does NOT issue DELETE /sessions/{id}. The
        server-side session lives on its idle-reap timer (default ~30
        min); the Postgres row persists indefinitely. Used by the chat
        REPL's /detach command so the user can resume on the next
        invocation."""
        if self._http is not None:
            try:
                await self._http.aclose()
            finally:
                self._http = None
                self._session_id = None
                self._nonce = None

    @property
    def session_id(self) -> str | None:
        """Current server-side session_id, or None if not open."""
        return self._session_id

    @property
    def nonce(self) -> str | None:
        """Current session nonce, or None if not open."""
        return self._nonce

    async def close(self) -> None:
        """DELETE the server session and close the underlying HTTP client.
        Idempotent — safe to call when already closed or partially open.
        DELETE failures are swallowed so a flaky tunnel can't prevent
        local cleanup."""
        if self._http is None:
            return
        if self._session_id is not None and self._nonce is not None:
            try:
                await self._http.delete(
                    f"/sessions/{self._session_id}",
                    headers=self._auth_headers(self._nonce),
                )
            except Exception:  # pragma: no cover - best-effort cleanup
                pass
        try:
            await self._http.aclose()
        finally:
            self._http = None
            self._session_id = None
            self._nonce = None

    async def _drive_turn(
        self,
        http: httpx.AsyncClient,
        session_id: str,
        nonce: str,
        prompt: str,
    ) -> str:
        # Per-client-turn token accumulator. The server emits a `tokens`
        # block on every needs_local_tool event AND on the terminal final
        # event, but each one only covers a single server-side cycle. A
        # client turn that uses three local tools has four cycles, so we
        # sum here to give the user a true per-turn cost. (UAT defect #4.)
        accumulated_input = 0
        accumulated_output = 0
        latest_session_total = 0
        latest_history_tokens = 0
        latest_compact_savings = 0
        # model max context window + soft compact threshold +
        # vendor-abstracted model alias from the server's `final`
        # event payload. Used to render the ctx footer: `ctx: 65K /
        # 1M (compact at 100K) · model: standard`.
        latest_model_max_tokens = 0
        latest_soft_compact_threshold: int | None = None
        latest_model_alias: str | None = None

        def _accumulate(event: dict[str, Any]) -> None:
            nonlocal accumulated_input, accumulated_output
            nonlocal latest_session_total, latest_history_tokens, latest_compact_savings
            nonlocal latest_model_max_tokens, latest_soft_compact_threshold
            nonlocal latest_model_alias
            tokens = event.get("tokens") or {}
            accumulated_input += int(tokens.get("input", 0) or 0)
            accumulated_output += int(tokens.get("output", 0) or 0)
            if "session_total" in tokens:
                latest_session_total = int(tokens["session_total"] or 0)
            if "history_tokens" in tokens:
                latest_history_tokens = int(tokens["history_tokens"] or 0)
            if "compact_savings" in tokens:
                latest_compact_savings = int(tokens["compact_savings"] or 0)
            if "model_max_tokens" in tokens:
                latest_model_max_tokens = int(tokens["model_max_tokens"] or 0)
            if "soft_compact_threshold" in tokens:
                v = tokens["soft_compact_threshold"]
                latest_soft_compact_threshold = (
                    int(v) if v is not None else None
                )
            if "model_alias" in tokens:
                a = tokens["model_alias"]
                latest_model_alias = str(a) if a else None

        # Open the initial /turn SSE stream.
        final = await self._consume_stream(
            http, session_id, nonce,
            method="POST",
            path=f"/sessions/{session_id}/turn",
            json_body={"prompt": prompt},
        )
        _accumulate(final)
        while final["kind"] in ("needs_local_tool", "needs_input", "needs_approval"):
            kind = final["kind"]
            if kind == "needs_local_tool":
                # E41 (2026-05-13): wrap executor in elapsed-time progress
                # display so long-running python_run/bash/powershell calls
                # show in-place updating status on stderr instead of dead
                # air. Threshold-gated (>=5s); disabled on non-TTY and via
                # MASTER_AGENTS_DISABLE_PROGRESS=1.
                # Sprint 1e-b: lazy import from the new sibling progress module
                # to avoid circular dep with the `remote_cli` facade module.
                from .progress import _execute_with_progress
                result, is_error = await _execute_with_progress(
                    self._executor, final["tool_name"], final["input"],
                )
                final = await self._consume_stream(
                    http, session_id, nonce,
                    method="POST",
                    path=f"/sessions/{session_id}/local_tool_result",
                    json_body={
                        "continuation_token": final["continuation_token"],
                        "result": result,
                        "is_error": is_error,
                    },
                )
            elif kind == "needs_input":
                # Agent called ask_user — surface the question to the
                # caller's input handler, post the answer back via
                # /resume. Without a callback, raise so the chat REPL
                # can recover instead of crashing the turn.
                if self._on_needs_input is None:
                    raise RuntimeError(
                        "agent called ask_user but no on_needs_input "
                        "callback is registered on the client"
                    )
                question = final.get("question", "")
                answer = await self._on_needs_input(question)
                final = await self._consume_stream(
                    http, session_id, nonce,
                    method="POST",
                    path=f"/sessions/{session_id}/resume",
                    json_body={
                        "continuation_token": final["continuation_token"],
                        "answer": answer,
                    },
                )
            elif kind == "needs_approval":
                if self._on_needs_approval is None:
                    raise RuntimeError(
                        "agent requested approval but no "
                        "on_needs_approval callback is registered"
                    )
                tool_name = final.get("tool_name", "?")
                preview_text = final.get("input_preview", "")
                approved = await self._on_needs_approval(
                    tool_name, preview_text,
                )
                final = await self._consume_stream(
                    http, session_id, nonce,
                    method="POST",
                    path=f"/sessions/{session_id}/resume",
                    json_body={
                        "continuation_token": final["continuation_token"],
                        "approved": bool(approved),
                    },
                )
            _accumulate(final)
        # Replace the per-stream snapshot in last_tokens (which only
        # reflects the LAST server-side cycle) with the accumulated
        # client-side turn totals. session_total / history_tokens /
        # compact_savings come from the last final event since they're
        # already cumulative on the server side.
        self.last_tokens = {
            "input": accumulated_input,
            "output": accumulated_output,
            "session_total": latest_session_total,
            "history_tokens": latest_history_tokens,
            "compact_savings": latest_compact_savings,
            # context-window meta + model alias for footer.
            "model_max_tokens": latest_model_max_tokens,
            "soft_compact_threshold": latest_soft_compact_threshold,
            "model_alias": latest_model_alias,
        }
        if final["kind"] == "final":
            return final["answer"]
        if final["kind"] == "error":
            raise RuntimeError(final.get("error", "remote session error"))
        raise RuntimeError(f"unexpected terminal event: {final}")

    async def _consume_stream(
        self,
        http: httpx.AsyncClient,
        session_id: str,
        nonce: str,
        *,
        method: str,
        path: str,
        json_body: dict[str, Any],
    ) -> dict[str, Any]:
        headers = self._auth_headers(nonce)
        # Heartbeat: print a dim "thinking…" the instant we open the stream,
        # then overwrite it the moment any real event (trace, final, error,
        # needs_*) arrives. Without this, on a no-tool prompt the user sees
        # nothing until `final` lands seconds later. CR + clear-line ANSI
        # makes the overwrite invisible on a working VT terminal.
        heartbeat_active = False
        if self._heartbeat:
            sys.stderr.write("\x1b[2m  ▸ thinking…\x1b[0m\r")
            sys.stderr.flush()
            heartbeat_active = True

        def _clear_heartbeat() -> None:
            nonlocal heartbeat_active
            if heartbeat_active:
                sys.stderr.write("\x1b[2K")
                sys.stderr.flush()
                heartbeat_active = False

        try:
            async with http.stream(method, path, json=json_body, headers=headers) as resp:
                # F2 follow-up (2026-05-07): translate 410 Gone on any
                # session endpoint into SessionEndedError so the CLI can
                # exit cleanly instead of crashing with an unhandled
                # HTTPStatusError. Server-side 410 means the pending
                # request was cancelled (F1 timeout, container restart,
                # explicit cancel) — that's ops-level, not a client bug,
                # so we surface it as a distinct exception class.
                if resp.status_code == 410:
                    _clear_heartbeat()
                    # Read the body for diagnostic detail without
                    # raising; aread() is safe on an already-streaming
                    # response and returns whatever the server sent.
                    try:
                        body = await resp.aread()
                        detail = body.decode("utf-8", errors="replace")[:200]
                    except Exception:
                        detail = ""
                    raise SessionEndedError(
                        f"session cancelled by server before request "
                        f"completed (410 Gone on {path}); "
                        f"server detail: {detail or '(none)'}"
                    )
                resp.raise_for_status()
                # SSE events are `\n\n`-delimited. A single TCP chunk can split a
                # frame, so buffer bytes across chunks and only parse completed
                # events. Without the buffer, any event that straddles a chunk
                # boundary is silently dropped.
                buffer = b""
                async for chunk in resp.aiter_raw():
                    if not chunk:
                        continue
                    buffer += chunk
                    while b"\n\n" in buffer:
                        block, buffer = buffer.split(b"\n\n", 1)
                        if not block.strip():
                            continue
                        parsed = _parse_sse_chunk(block + b"\n")
                        if not parsed:
                            continue
                        event_name, payload = parsed
                        if event_name == "trace":
                            _clear_heartbeat()
                            # / — capture cost summary so the chat
                            # REPL can render the tier indicator. Each
                            # Runner emits its own summary only when it
                            # called estimate_tokens; events fire in
                            # depth-DESCENDING order (deepest finishes
                            # first), so "last wins" naturally lands on
                            # the root's summary when the root estimated,
                            # and falls through to the deepest estimating
                            # agent otherwise. The common forced-routing
                            # case (assistant_cli → parallel_read_files,
                            # only the specialist estimates) is captured.
                            if (
                                isinstance(payload, dict)
                                and payload.get("type") == "cost_band_summary"
                            ):
                                self.last_cost_summary = dict(payload)
                            if self._tracer is not None:
                                try:
                                    self._tracer.emit(payload)
                                except Exception:  # pragma: no cover - defensive
                                    pass
                            continue
                        if event_name == "final":
                            _clear_heartbeat()
                            return {
                                "kind": "final",
                                "answer": payload.get("answer", ""),
                                "tokens": payload.get("tokens", {}),
                            }
                        if event_name == "error":
                            _clear_heartbeat()
                            return {"kind": "error", **payload}
                        if event_name == "needs_local_tool":
                            _clear_heartbeat()
                            return {
                                "kind": "needs_local_tool",
                                "tool_name": payload["tool_name"],
                                "input": payload.get("input", {}),
                                "continuation_token": payload["continuation_token"],
                                "tokens": payload.get("tokens", {}),
                            }
                        if event_name in ("needs_input", "needs_approval"):
                            _clear_heartbeat()
                            return {"kind": event_name, **payload}
        finally:
            _clear_heartbeat()
        raise RuntimeError("SSE stream closed without terminal event")
