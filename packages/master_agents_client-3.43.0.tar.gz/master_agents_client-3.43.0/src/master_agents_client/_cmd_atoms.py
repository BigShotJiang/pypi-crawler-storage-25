"""K-G.1 Wave H S4 (2026-05-17) — atom proposal/review CLI subcommands.

The agent-proposed side of the knowledge corpus lifecycle:

  distiller agent (incident_distiller / pattern_distiller)
    \\downarrow writes via write_file tool
  docs/knowledge/atoms/_proposed/<id>.md      (LOCAL, gitignored)
    \\downarrow human reviews via `mao-client atoms list-proposed`
    \\downarrow human approves via `mao-client atoms approve <id>`
  docs/knowledge/atoms/<id>.md                (COMMITTED)

Trust boundary per [[feedback-memory-user-authored-only]]: agents
PROPOSE, humans AUTHOR. The `approve` command IS the human action
that gates the transition; no auto-merge in Phase 1.

Phase 2 (auto-approve with confidence thresholds + mid-session
corpus reload) deferred to Wave I or later.

Operates on the CWD-anchored corpus by default; `--corpus-root`
optionally overrides for testing.

Wheel-only file per scripts/sync_client.py _WHEEL_ONLY_PRESERVE:
operates purely on client-side files (docs/knowledge/atoms/_proposed/
in the user's cwd); the server has nothing to do with the atom
proposal/review lifecycle.
"""

from __future__ import annotations

import argparse
import os
import re
import sys
import time
from pathlib import Path
from typing import Iterable


_FRONTMATTER_RE = re.compile(r"^---\n(.*?)\n---\n(.*)$", re.DOTALL)

_STATUS_PROPOSED = "proposed"
_STATUS_ACTIVE = "active"
_DEFAULT_STALE_DAYS = 30


def add_atoms_subparser(sub: argparse._SubParsersAction) -> None:
    """Register the `atoms` subparser on the top-level CLI parser."""
    p_atoms = sub.add_parser(
        "atoms",
        help=(
            "Manage agent-proposed atoms in docs/knowledge/atoms/_proposed/. "
            "Distillers write candidate atoms there; this command lets you "
            "review/approve/reject them."
        ),
    )
    p_atoms.add_argument(
        "--corpus-root",
        default="docs/knowledge/atoms",
        help=(
            "Path to the atom corpus root (the directory containing "
            "atoms/*.md and atoms/_proposed/*.md). Defaults to "
            "'docs/knowledge/atoms' relative to cwd."
        ),
    )
    atoms_sub = p_atoms.add_subparsers(dest="atoms_command", required=True)

    p_list = atoms_sub.add_parser(
        "list-proposed",
        help="List all atoms in _proposed/ awaiting review.",
    )
    p_list.add_argument(
        "--verbose", "-v", action="store_true",
        help="Print full title + age for each proposal (default: id only).",
    )

    p_approve = atoms_sub.add_parser(
        "approve",
        help=(
            "Move _proposed/<id>.md to atoms/<id>.md and flip status from "
            "'proposed' to 'active'. Refuses to overwrite an existing "
            "atoms/<id>.md."
        ),
    )
    p_approve.add_argument(
        "atom_id",
        help="Atom id to approve (e.g. 'I-016', 'P-024'). Must match the file stem in _proposed/.",
    )
    # Z.2 (Wave I, 2026-05-18) — --force flag for the update workflow.
    # When a proposed atom updates an existing active atom (same id),
    # by default approve refuses to overwrite (preserves human review).
    # --force overrides: the existing active atom is backed up to
    # `.bak` (timestamped) and replaced. Useful when the distiller
    # proposes an improved version of an already-committed atom.
    p_approve.add_argument(
        "--force", action="store_true",
        help=(
            "Overwrite an existing atoms/<id>.md. The existing file is "
            "backed up to atoms/<id>.md.<timestamp>.bak before replacement."
        ),
    )

    p_reject = atoms_sub.add_parser(
        "reject",
        help="Delete _proposed/<id>.md without copying to atoms/.",
    )
    p_reject.add_argument(
        "atom_id",
        help="Atom id to reject (e.g. 'I-016', 'P-024').",
    )

    p_clean = atoms_sub.add_parser(
        "clean-stale",
        help=(
            "Delete _proposed/*.md files older than N days (default 30). "
            "Use on cron / weekly to keep the proposal queue tidy."
        ),
    )
    p_clean.add_argument(
        "--days",
        type=int,
        default=_DEFAULT_STALE_DAYS,
        help=f"Stale threshold in days. Default {_DEFAULT_STALE_DAYS}.",
    )
    p_clean.add_argument(
        "--dry-run", action="store_true",
        help="Print what would be deleted without deleting.",
    )

    # K.4.B (Wave K, 2026-05-18) - confidence-thresholded auto-promote.
    # Scans _proposed/, reads each atom's `confidence:` frontmatter
    # field, auto-flips status->active for atoms at or above the
    # threshold. Trust-boundary tension acknowledged: this OPT-INTO
    # the auto-promote path; without --threshold, manual `approve`
    # remains canonical.
    p_promote = atoms_sub.add_parser(
        "promote-confident",
        help=(
            "Auto-promote _proposed/*.md atoms whose `confidence:` "
            "frontmatter is at or above THRESHOLD. Bypasses manual "
            "approve for high-confidence atoms; default DRY-RUN to "
            "preserve human-review safety margin."
        ),
    )
    p_promote.add_argument(
        "--threshold",
        type=float,
        default=0.85,
        help=(
            "Minimum confidence (in [0.0, 1.0]) to auto-promote. "
            "Default 0.85. Atoms with no `confidence:` field are "
            "always skipped (treated as 0.0)."
        ),
    )
    p_promote.add_argument(
        "--apply", action="store_true",
        help=(
            "Actually promote matching atoms. Without this flag the "
            "command runs in dry-run mode (lists what would be "
            "promoted, makes no changes)."
        ),
    )


def cmd_atoms(args: argparse.Namespace) -> int:
    """Entry point for `mao-client atoms <subcmd>`."""
    corpus_root = Path(args.corpus_root).resolve()
    proposed_dir = corpus_root / "_proposed"

    if args.atoms_command == "list-proposed":
        return _cmd_list_proposed(proposed_dir, verbose=args.verbose)
    if args.atoms_command == "approve":
        return _cmd_approve(
            corpus_root, proposed_dir, args.atom_id,
            force=getattr(args, "force", False),
        )
    if args.atoms_command == "reject":
        return _cmd_reject(proposed_dir, args.atom_id)
    if args.atoms_command == "clean-stale":
        return _cmd_clean_stale(
            proposed_dir, days=args.days, dry_run=args.dry_run,
        )
    if args.atoms_command == "promote-confident":
        return _cmd_promote_confident(
            corpus_root, proposed_dir,
            threshold=args.threshold,
            apply_changes=args.apply,
        )
    print(f"unknown atoms subcommand: {args.atoms_command!r}", file=sys.stderr)
    return 2


def _iter_proposed_files(proposed_dir: Path) -> Iterable[Path]:
    """Yield Path entries for each *.md in _proposed/ (sorted by id)."""
    if not proposed_dir.is_dir():
        return iter(())
    return iter(sorted(proposed_dir.glob("*.md")))


def _parse_atom_frontmatter(path: Path) -> dict[str, object]:
    """Read a YAML-frontmatter atom file and return its frontmatter dict."""
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return {}
    m = _FRONTMATTER_RE.match(text)
    if not m:
        return {}
    try:
        import yaml
        fm = yaml.safe_load(m.group(1))
        if isinstance(fm, dict):
            return fm
        return {}
    except Exception:
        return {}


def _format_age(seconds: float) -> str:
    if seconds < 60:
        return f"{int(seconds)}s ago"
    if seconds < 3600:
        return f"{int(seconds // 60)}m ago"
    if seconds < 86400:
        return f"{int(seconds // 3600)}h ago"
    return f"{int(seconds // 86400)}d ago"


def _cmd_list_proposed(proposed_dir: Path, *, verbose: bool) -> int:
    files = list(_iter_proposed_files(proposed_dir))
    if not files:
        print(f"No proposed atoms in {proposed_dir}.")
        return 0
    now = time.time()
    print(f"{len(files)} proposed atom(s) in {proposed_dir}:")
    for path in files:
        atom_id = path.stem
        age = _format_age(now - path.stat().st_mtime)
        if verbose:
            fm = _parse_atom_frontmatter(path)
            title = str(fm.get("title", "<no title>"))
            kind = str(fm.get("kind", "<no kind>"))
            print(f"  {atom_id}  [{kind}] {age}")
            print(f"      {title}")
        else:
            print(f"  {atom_id}  ({age})")
    return 0


def _flip_status_to_active(text: str) -> str:
    """Rewrite the `status: proposed` line in the frontmatter to
    `status: active`. Idempotent on already-active text.

    Z.1 (Wave I, 2026-05-18) — extended to handle comment-line edge
    case via line-by-line surgical edit. PyYAML round-trip rejected
    here because it would reorder keys + strip comments + normalise
    quoting, destroying the human-curated atom format. Instead the
    line edit handles all known variants:

      status: proposed
      status: "proposed"
      status: 'proposed'
      status: proposed   # comment
      status: "proposed" # comment
      status: 'proposed' # comment

    The single-quoted / double-quoted output preserves the quoting
    style; comments after the value are preserved verbatim.

    For atoms without YAML frontmatter, returns the text unchanged
    (no-op fallback — matches Phase 1 semantic).
    """
    m = _FRONTMATTER_RE.match(text)
    if not m:
        return text
    fm_text = m.group(1)
    body = m.group(2)
    # Line-by-line surgical edit. A status: line is matched by the
    # regex below; everything else (whitespace, other keys, comments
    # on non-status lines) is preserved verbatim.
    #
    # Capture groups:
    #   1. prefix  — leading whitespace + 'status:' + spacing
    #   2. quote   — optional opening quote (preserved)
    #   3. comment — optional trailing comment + whitespace (preserved
    #                including the comment delimiter # itself)
    _STATUS_LINE_RE = re.compile(
        r"""^
        (\s*status\s*:\s*)            # 1. prefix
        (["']?)                        # 2. opening quote (optional)
        proposed                       # the value being flipped
        \2                             # matching closing quote
        (\s*(?:\#[^\n]*)?)             # 3. trailing whitespace + optional comment
        $""",
        re.MULTILINE | re.VERBOSE,
    )
    new_fm = _STATUS_LINE_RE.sub(r"\1\2active\2\3", fm_text)
    return f"---\n{new_fm}\n---\n{body}"


def _cmd_approve(
    corpus_root: Path, proposed_dir: Path, atom_id: str,
    *, force: bool = False,
) -> int:
    """Approve a proposed atom: move from _proposed/ to atoms/ + flip
    status. Z.2 / Z.3 (Wave I): --force flag for update workflow +
    atomic write-then-rename to prevent partial-state crashes."""
    proposed_path = proposed_dir / f"{atom_id}.md"
    if not proposed_path.is_file():
        print(
            f"Error: no proposed atom at {proposed_path}. "
            f"Run `mao-client atoms list-proposed` to see available ids.",
            file=sys.stderr,
        )
        return 1
    target_path = corpus_root / f"{atom_id}.md"
    if target_path.exists():
        # Z.2 (Wave I, 2026-05-18) — --force flag for update workflow.
        # Without --force: refuse (preserves human-review gate).
        # With --force: back up existing file then replace (lets the
        # distiller propose an improved version of a committed atom).
        if not force:
            print(
                f"Error: atom already exists at {target_path}. "
                f"Refusing to overwrite. Either re-run with --force "
                f"to back up + replace the existing atom, OR inspect "
                f"the existing version + manually reconcile + reject "
                f"the proposal.",
                file=sys.stderr,
            )
            return 1
        # --force path: back up existing atom with timestamp.
        backup_path = target_path.with_suffix(
            f".md.{int(time.time())}.bak",
        )
        target_path.rename(backup_path)
        print(f"Backed up existing atom: {target_path} -> {backup_path}")

    # Z.3 (Wave I, 2026-05-18) — atomic write-then-rename. Previous
    # impl did `target_path.write_text(...); proposed_path.unlink()`
    # — a crash between the two left BOTH files (cosmetic but real).
    # New impl: write to a sibling tempfile, fsync, then os.rename
    # (atomic on POSIX + Windows ReplaceFile). If anything fails
    # before the rename, the tempfile is cleaned up + state is
    # unchanged. If rename succeeds, unlink the proposed file LAST.
    text = proposed_path.read_text(encoding="utf-8")
    flipped = _flip_status_to_active(text)
    target_path.parent.mkdir(parents=True, exist_ok=True)
    staging_path = target_path.with_suffix(
        f".md.{int(time.time() * 1000)}.tmp",
    )
    try:
        staging_path.write_text(flipped, encoding="utf-8")
        # On Windows, rename onto an existing target fails; we've
        # already moved any existing target to .bak above (under
        # --force), so target_path must NOT exist here. Use
        # os.replace (atomic on both POSIX + Windows) for safety.
        import os
        os.replace(staging_path, target_path)
    except BaseException:
        # Roll back staging path on any failure before unlinking
        # the proposed source.
        if staging_path.exists():
            try:
                staging_path.unlink()
            except OSError:
                pass
        raise
    # Only unlink the proposed file AFTER the target write succeeded
    # + the rename completed atomically. If we crash before this
    # unlink, the next approve invocation sees target exists +
    # refuses (correct behaviour — no double-state).
    proposed_path.unlink()
    print(f"Approved {atom_id}: moved {proposed_path} -> {target_path}")
    return 0


def _cmd_reject(proposed_dir: Path, atom_id: str) -> int:
    proposed_path = proposed_dir / f"{atom_id}.md"
    if not proposed_path.is_file():
        print(
            f"Error: no proposed atom at {proposed_path}. "
            f"Already rejected or never existed.",
            file=sys.stderr,
        )
        return 1
    proposed_path.unlink()
    print(f"Rejected {atom_id}: deleted {proposed_path}")
    return 0


def _cmd_clean_stale(
    proposed_dir: Path, *, days: int, dry_run: bool,
) -> int:
    if days < 0:
        print(f"Error: --days must be >= 0; got {days}", file=sys.stderr)
        return 2
    if not proposed_dir.is_dir():
        print(f"No _proposed/ directory at {proposed_dir} - nothing to clean.")
        return 0
    threshold = time.time() - (days * 86400)
    files = list(_iter_proposed_files(proposed_dir))
    stale = [p for p in files if p.stat().st_mtime < threshold]
    if not stale:
        print(
            f"No stale proposed atoms (threshold: {days} days; "
            f"{len(files)} proposal(s) all within window)."
        )
        return 0
    verb = "Would delete" if dry_run else "Deleted"
    for path in stale:
        if not dry_run:
            path.unlink()
        print(f"  {verb}: {path}")
    suffix = " (dry-run)" if dry_run else ""
    print(f"{verb} {len(stale)} stale proposal(s){suffix}.")
    return 0


def _cmd_promote_confident(
    corpus_root: Path,
    proposed_dir: Path,
    *,
    threshold: float,
    apply_changes: bool,
) -> int:
    """K.4.B (Wave K, 2026-05-18) - confidence-thresholded auto-promote.

    Scans _proposed/*.md, reads each atom's `confidence:` frontmatter
    field, and promotes atoms with `confidence >= threshold` to
    active status. Promotion = same mechanics as `mao-client atoms
    approve`: flip status proposed -> active, move file
    _proposed/<id>.md -> <id>.md.

    Trust boundary: dry-run by default (--apply required to actually
    promote). Skip atoms whose target <id>.md already exists in the
    active corpus (existing file = collision; user must resolve
    manually).
    """
    if not (0.0 <= threshold <= 1.0):
        print(
            f"Error: --threshold must be in [0.0, 1.0]; got {threshold}",
            file=sys.stderr,
        )
        return 2
    if not proposed_dir.is_dir():
        print(f"No _proposed/ directory at {proposed_dir} - nothing to promote.")
        return 0

    files = list(_iter_proposed_files(proposed_dir))
    if not files:
        print(f"No proposed atoms in {proposed_dir}.")
        return 0

    # Classify each proposed atom into one of:
    #   - eligible (confidence >= threshold AND no collision)
    #   - skipped_low_confidence
    #   - skipped_collision (target <id>.md already exists)
    #   - skipped_missing_confidence (no `confidence:` field)
    eligible: list[tuple[Path, float]] = []
    skipped_low: list[tuple[Path, float]] = []
    skipped_collision: list[Path] = []
    skipped_missing: list[Path] = []

    for path in files:
        fm = _parse_atom_frontmatter(path)
        confidence_raw = fm.get("confidence")
        if confidence_raw is None:
            skipped_missing.append(path)
            continue
        try:
            confidence = float(confidence_raw)
        except (TypeError, ValueError):
            skipped_missing.append(path)
            continue
        if confidence < threshold:
            skipped_low.append((path, confidence))
            continue
        target_path = corpus_root / f"{path.stem}.md"
        if target_path.exists():
            skipped_collision.append(path)
            continue
        eligible.append((path, confidence))

    # Report.
    mode = "APPLY" if apply_changes else "DRY-RUN"
    print(
        f"[{mode}] Scanned {len(files)} proposed atom(s); "
        f"threshold={threshold:.2f}"
    )
    print(f"  Eligible to promote: {len(eligible)}")
    for path, conf in eligible:
        print(f"    {path.stem}  (confidence={conf:.2f})")
    if skipped_low:
        print(f"  Skipped (confidence < threshold): {len(skipped_low)}")
        for path, conf in skipped_low:
            print(f"    {path.stem}  (confidence={conf:.2f})")
    if skipped_collision:
        print(f"  Skipped (collision with existing active atom): "
              f"{len(skipped_collision)}")
        for path in skipped_collision:
            print(f"    {path.stem}")
    if skipped_missing:
        print(f"  Skipped (missing/invalid confidence field): "
              f"{len(skipped_missing)}")
        for path in skipped_missing:
            print(f"    {path.stem}")

    if not eligible:
        return 0

    if not apply_changes:
        print("\nDry-run only. Re-run with --apply to promote the "
              "eligible atoms.")
        return 0

    # Actually promote: flip status + move.
    promoted = 0
    for path, _ in eligible:
        target = corpus_root / f"{path.stem}.md"
        try:
            text = path.read_text(encoding="utf-8")
            flipped = _flip_status_to_active(text)
            # Atomic write to target + delete proposed.
            tmp = target.with_suffix(".md.tmp")
            tmp.write_text(flipped, encoding="utf-8")
            os.replace(tmp, target)
            path.unlink()
            print(f"  Promoted: {path.stem} -> {target}")
            promoted += 1
        except Exception as exc:
            print(
                f"  ERROR promoting {path.stem}: {exc!r}",
                file=sys.stderr,
            )
    print(f"\nPromoted {promoted} atom(s) of {len(eligible)} eligible.")
    return 0 if promoted == len(eligible) else 1
