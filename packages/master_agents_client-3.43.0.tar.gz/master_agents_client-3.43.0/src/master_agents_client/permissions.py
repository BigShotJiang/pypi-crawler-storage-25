"""E47 — granular permission rules engine (2026-05-14).

Replaces the coarse ``writable_paths`` allowlist with structured
``permissions: {allow, deny, ask}`` rules carrying Claude-Code-parity
``<ToolName>(<arg-pattern>)`` syntax. Stays CLIENT-SIDE: enforcement
fires in :class:`RemoteToolExecutor.execute` before the tool's
handler runs, so a deny rule blocks the call without ever touching
the user's filesystem.

The v3.7.0 ship was **allow + deny** only. Wave G.4 (2026-05-17) adds
the **ask** tier: structural per-pattern prompts that fire BEFORE the
tool handler runs but AFTER the deny pass — independent of the
session-level ``/auto-approve`` toggle (deliberately sticky, see
architect diagnosis at docs/design/WAVE_G4_ASK_TIER_ARCHITECT_PROPOSAL_2026-05-17.md).

Precedence
==========

For a given tool call, rules are evaluated in tiers:

1. **deny** — first match short-circuits the call with an error.
2. **ask** — first match raises :class:`AskPermissionRequired`; the
   REPL catches it and renders a Y/N prompt. On user-approve, the
   call resumes; on user-deny, the call is blocked with a clear
   error.
3. **allow** — first match passes the call through silently.
4. **No match** — fallback default is allow (back-compat with pre-E47).

The ``ask`` tier is intentionally NOT bypassed by ``/auto-approve``.
Session-level approval (``requires_approval`` on the tool) is a class
gate; ``ask`` is a structural per-pattern gate written into
``remote.yaml`` as a considered decision. Bypassing it via a session
toggle would defeat the purpose.

Grammar
=======

A rule is a string of one of these shapes:

- ``ToolName`` — matches the named tool regardless of arguments
  (e.g. ``"WebFetch"`` denies every WebFetch call).
- ``ToolName(<glob>)`` — for tools with a ``path`` arg
  (Write/Edit/Read/Append/MultiEdit/FileGrep/ListFiles): match against
  the resolved path using ``Path.match()`` glob semantics.
- ``ToolName(<prefix>:*)`` — for shell tools (Bash/PowerShell): match
  when the ``command`` arg starts with ``<prefix>``. The ``:*`` suffix
  is mandatory for command-line patterns and is what disambiguates
  prefix-match from glob-match.
- ``ToolName(<exact>)`` — exact-string match. Rare in practice.

Tool-name aliases follow Claude Code's UpperCase → snake_case
mapping (``Write`` → ``write_file``, ``Edit`` → ``edit_file``,
``Read`` → ``read_file``, ``MultiEdit`` → ``multi_edit``, etc.).
Unknown aliases pass through lowercased — match-time gate the call
against the live registry separately if you need strictness.

Examples
========

Project-rules whitelist (typical setup)::

    permissions:
      allow:
        - Write(./**)
        - Edit(./**)
        - MultiEdit(./**)
        - Append(./**)
        - Bash(git:*)
        - Bash(pip:*)
      deny:
        - Bash(rm -rf:*)
        - Bash(sudo:*)
        - Write(/etc/**)
        - Write(/usr/**)

Match algorithm
===============

For a tool call ``(name, args)``:

1. **Deny pass first** — walk every deny rule; if any matches, return
   ``deny`` with the rule string in the reason. Deny ALWAYS wins.
2. **Allow pass** — walk every allow rule; if any matches, return
   ``allow``.
3. **Default fallback** — return ``allow`` for back-compat with
   pre-E47 sessions (where the only gate was ``writable_paths``).
   Callers wanting strict "deny by default" combine an explicit
   ``allow:`` list with a deny catch-all (e.g. ``deny: [Bash]``).
"""
from __future__ import annotations

import fnmatch
import logging
import re
import time
from dataclasses import dataclass, field
from pathlib import PurePath
from typing import Any, Literal


# Claude Code's UpperCase tool aliases → MAO's snake_case names in
# BUILTINS. This is the "common surface" — unknown UpperCase aliases
# pass through lowercased.
_TOOL_NAME_ALIASES: dict[str, str] = {
    "write": "write_file",
    "edit": "edit_file",
    "read": "read_file",
    "append": "append_file",
    "multiedit": "multi_edit",
    "multi_edit": "multi_edit",
    "filegrep": "file_grep",
    "file_grep": "file_grep",
    "listfiles": "list_files",
    "list_files": "list_files",
    "applypatch": "apply_patch",
    "apply_patch": "apply_patch",
    "bash": "bash",
    "powershell": "powershell",
    "pythonrun": "python_run",
    "python_run": "python_run",
    "pythoneval": "python_eval",
    "python_eval": "python_eval",
    "webfetch": "browser_fetch",
    "browser_fetch": "browser_fetch",
    "httpget": "http_get",
    "http_get": "http_get",
    "gitread": "git_read",
    "git_read": "git_read",
    "gitwrite": "git_write",
    "git_write": "git_write",
    "recallatom": "recall_atom",
    "recall_atom": "recall_atom",
}


# Rule string parser. Accepts ``ToolName`` or ``ToolName(<pattern>)``.
# The ``(`` group is greedy up to the final ``)`` so patterns
# containing parens (rare) survive — caller's responsibility to
# escape if it matters.
_RULE_RE = re.compile(r"^([A-Za-z][A-Za-z0-9_]*)(?:\((.*)\))?$")


def parse_rule(rule: str) -> tuple[str, str | None]:
    """Parse a rule string into ``(canonical_tool_name, pattern_or_None)``.

    Raises ``ValueError`` if the rule is malformed — empty, missing
    the close paren, or syntactically invalid otherwise. Strict-parse
    at config-load time catches typos before they become silent
    "rule never fires" mysteries.
    """
    if not isinstance(rule, str) or not rule.strip():
        raise ValueError(f"empty or non-string permission rule: {rule!r}")
    rule = rule.strip()
    # Reject obvious unclosed-paren forms before regex even sees them.
    if rule.count("(") != rule.count(")"):
        raise ValueError(
            f"unbalanced parentheses in permission rule: {rule!r}"
        )
    m = _RULE_RE.match(rule)
    if not m:
        raise ValueError(f"invalid permission rule syntax: {rule!r}")
    raw_name, pattern = m.group(1), m.group(2)
    canonical = _TOOL_NAME_ALIASES.get(raw_name.lower(), raw_name.lower())
    if pattern is not None and not pattern.strip():
        raise ValueError(
            f"permission rule {rule!r} has empty argument pattern"
        )
    return canonical, pattern


# --- match dispatch by tool name -----------------------------------------


def _match_path_pattern(pattern: str, path_value: Any) -> bool:
    """Glob-match a ``path`` argument against the rule's pattern.

    Uses ``PurePath.match`` for cross-platform glob semantics; falls
    back to substring match when the path arg isn't string-shaped
    (defensive — agents occasionally pass weird types).
    """
    if not isinstance(path_value, str):
        return False
    # PurePath.match expects the pattern AND the path to use the same
    # separator family. Normalize both to forward slashes — POSIX-style
    # globbing semantics regardless of host OS.
    p = PurePath(path_value.replace("\\", "/"))
    return p.match(pattern.replace("\\", "/"))


def _match_command_pattern(pattern: str, command_value: Any) -> bool:
    """Prefix-match a ``command`` argument against ``<prefix>:*`` form.

    Patterns without the ``:*`` suffix are treated as exact-match
    (rare but supported). The prefix is matched after stripping
    leading whitespace from the command — agents sometimes generate
    `"  git status"` with leading spaces.
    """
    if not isinstance(command_value, str):
        return False
    cmd = command_value.lstrip()
    if pattern.endswith(":*"):
        prefix = pattern[:-2].rstrip()
        return cmd.startswith(prefix)
    # Exact match (no `:*` suffix). Rare.
    return cmd == pattern


def _rule_matches(
    rule_name: str, rule_pattern: str | None,
    call_name: str, call_args: dict[str, Any],
) -> bool:
    """Return True iff a parsed rule matches a tool call.

    The match algorithm is tool-aware:
    - Bare ``ToolName`` (pattern is None) matches any call to that
      tool, regardless of args.
    - For path-bearing tools (Write/Edit/Read/Append/etc.), the
      pattern is treated as a glob and matched against
      ``call_args["path"]``.
    - For shell tools (Bash/PowerShell/python_run/etc.), the pattern
      is treated as prefix or exact and matched against
      ``call_args["command"]`` (or ``code`` for python_eval).
    - For any other tool, an explicit pattern requires
      ``call_args["arg"]`` exact match (rare).
    """
    if rule_name != call_name:
        return False
    if rule_pattern is None:
        return True  # bare tool name matches any args

    # Tool-name-aware arg selection.
    path_tools = {
        "write_file", "edit_file", "read_file", "append_file",
        "multi_edit", "file_grep", "list_files", "apply_patch",
        "create_md", "create_docx", "create_pptx", "create_xlsx",
        "create_pdf", "create_pptx_from_md", "render_chart",
        "pdf_read", "docx_read", "csv_read",
    }
    command_tools = {"bash", "powershell", "python_run", "python_eval",
                     "python_eval_sandboxed"}

    if call_name in path_tools:
        return _match_path_pattern(rule_pattern, call_args.get("path"))
    if call_name in command_tools:
        # python_eval uses `code` instead of `command`.
        cmd_key = "code" if call_name.startswith("python_eval") else "command"
        return _match_command_pattern(rule_pattern, call_args.get(cmd_key))
    # Unknown tool family: try a generic "first string arg" match.
    for value in call_args.values():
        if isinstance(value, str) and value == rule_pattern:
            return True
    return False


# --- PermissionsConfig + Verdict ----------------------------------------


PermissionAction = Literal["allow", "deny", "ask"]


@dataclass(frozen=True)
class PermissionVerdict:
    """Result of :meth:`PermissionsConfig.check`.

    ``reason`` is empty for allow verdicts (no message needed) and
    carries the matching rule string for deny / ask verdicts so the
    trace + the user-facing prompt / error message both see WHY the
    call was blocked or paused.

    ``matched_rule`` is the original rule-string that matched (only
    set for ask + deny verdicts). The REPL renders it in the prompt
    so the user sees exactly which structural rule triggered.
    """
    action: PermissionAction
    reason: str = ""
    matched_rule: str = ""


class AskPermissionRequired(PermissionError):
    """Wave G.4 (2026-05-17) — raised by :meth:`RemoteToolExecutor.execute`
    when an ``ask`` rule matches a tool call.

    The REPL catches this, renders a Y/N prompt with the matched rule
    + tool call context, then either retries the call (user-approve)
    or surfaces a permission-denied error (user-deny). Carries
    structured fields so the prompt UI can format cleanly.

    Inherits from :class:`PermissionError` so non-REPL callers (CI,
    automation) get a clean "permission required" failure if no
    ask-callback is wired in.
    """

    def __init__(
        self, tool_name: str, tool_args: dict[str, Any],
        matched_rule: str, reason: str,
    ) -> None:
        self.tool_name = tool_name
        self.tool_args = tool_args
        self.matched_rule = matched_rule
        self.reason = reason
        super().__init__(
            f"permission required (ask rule {matched_rule!r}): {reason}"
        )


@dataclass
class PermissionsConfig:
    """Permission rules loaded from ``remote.yaml``'s ``permissions:``
    block.

    Use :meth:`from_yaml_dict` to load + parse rules at config-read
    time; the constructor accepts raw rule strings without parsing
    (test fixtures use it).

    Three tiers: ``allow``, ``deny``, ``ask`` (Wave G.4). Evaluated in
    order deny → ask → allow; first match within each tier wins. See
    module docstring for full precedence rules.
    """
    allow: list[str] = field(default_factory=list)
    deny: list[str] = field(default_factory=list)
    # Wave G.4 (2026-05-17). Default empty for back-compat with
    # pre-G.4 configs — adding ask: rules is opt-in.
    ask: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        # Validate rules at construction so config-time typos surface
        # immediately. Parsing is cheap (one regex per rule), and we
        # only do it once per session.
        for r in (*self.allow, *self.deny, *self.ask):
            parse_rule(r)  # may raise ValueError

    def check(self, tool_name: str, tool_args: dict[str, Any]) -> PermissionVerdict:
        """Match a tool call against the rules; return a verdict.

        Evaluation order: deny → ask → allow. First match within each
        tier short-circuits to that verdict. Falls through to allow on
        no match (pre-E47 back-compat)."""
        canonical = _TOOL_NAME_ALIASES.get(tool_name.lower(), tool_name.lower())

        # Tier 1: Deny — ALWAYS wins, even over ask.
        for rule_str in self.deny:
            name, pattern = parse_rule(rule_str)
            if _rule_matches(name, pattern, canonical, tool_args):
                return PermissionVerdict(
                    action="deny",
                    reason=(
                        f"deny rule {rule_str!r} blocks {tool_name}("
                        + _summarize_args(tool_args) + ")"
                    ),
                    matched_rule=rule_str,
                )

        # Tier 2: Ask — structural per-pattern prompt (Wave G.4).
        # Fires BEFORE allow so an ``ask`` rule wins over a broader
        # ``allow`` rule that would otherwise pass the call through.
        # NOT bypassed by /auto-approve — see module docstring.
        for rule_str in self.ask:
            name, pattern = parse_rule(rule_str)
            if _rule_matches(name, pattern, canonical, tool_args):
                return PermissionVerdict(
                    action="ask",
                    reason=(
                        f"ask rule {rule_str!r} requires user approval for "
                        f"{tool_name}(" + _summarize_args(tool_args) + ")"
                    ),
                    matched_rule=rule_str,
                )

        # Tier 3: Allow — first explicit match wins.
        for rule_str in self.allow:
            name, pattern = parse_rule(rule_str)
            if _rule_matches(name, pattern, canonical, tool_args):
                return PermissionVerdict(action="allow")

        # Fallback default: allow. Back-compat with pre-E47 sessions
        # (where the only gate was ``writable_paths``). For strict
        # "deny by default" posture, callers add a catch-all deny
        # rule (e.g. ``deny: [Bash, Write]``) at the end of the list.
        return PermissionVerdict(action="allow")

    def add_rule(self, tier: PermissionAction, rule: str) -> None:
        """Wave G.4 (2026-05-17) — append a rule to a tier at runtime.

        Used by the ask-prompt's "Always allow" / "Always deny" paths
        so the user can promote an ask match into a permanent allow
        or deny without restarting the session. Validates the rule at
        insertion time (same path as ``__post_init__``).

        Idempotent — no-op if the exact rule already exists in the
        target tier.

        When promoting INTO allow or deny, the rule is ALSO removed
        from the ask tier (if present) so the user is not re-prompted
        for the same rule on subsequent calls. This is the natural
        promotion semantic — "always allow X" implicitly means
        "stop asking about X." Conversely, adding TO the ask tier
        does not remove from allow/deny — that path is rare and
        better handled explicitly.
        """
        parse_rule(rule)
        target = {"allow": self.allow, "deny": self.deny, "ask": self.ask}[tier]
        if rule not in target:
            target.append(rule)
        if tier in ("allow", "deny") and rule in self.ask:
            self.ask.remove(rule)

    def to_yaml_dict(self) -> dict[str, list[str]]:
        """Serialise to the dict shape ``remote.yaml`` stores.

        Omits the ``ask`` key when empty so pre-G.4 configs round-trip
        cleanly (no spurious empty ``ask: []`` block in the YAML on
        save)."""
        out: dict[str, list[str]] = {
            "allow": list(self.allow),
            "deny": list(self.deny),
        }
        if self.ask:
            out["ask"] = list(self.ask)
        return out

    @classmethod
    def from_yaml_dict(cls, data: Any) -> "PermissionsConfig":
        """Load from the dict shape ``remote.yaml`` stores. Tolerates
        ``None`` (block absent / null) and missing keys (allow-only or
        deny-only or ask-only configs)."""
        if not data or not isinstance(data, dict):
            return cls()
        allow = list(data.get("allow") or [])
        deny = list(data.get("deny") or [])
        ask = list(data.get("ask") or [])
        return cls(allow=allow, deny=deny, ask=ask)


def _summarize_args(args: dict[str, Any]) -> str:
    """Human-readable args summary for verdict reasons. Used only for
    the deny-reason string; intentionally lossy so the message stays
    short."""
    if not args:
        return ""
    # Common single-arg shapes get a clean form.
    if "command" in args:
        cmd = args["command"]
        return f"command={cmd!r}" if isinstance(cmd, str) else "command=…"
    if "path" in args:
        return f"path={args['path']!r}"
    if "code" in args and isinstance(args["code"], str):
        return f"code={args['code'][:40]!r}…"
    keys = ", ".join(args.keys())
    return f"args=[{keys}]"


# --- Migration from legacy `writable_paths` ------------------------------


def rules_from_legacy_writable_paths(paths: list[str]) -> list[str]:
    """Generate ``allow`` rules from a legacy ``writable_paths`` list.

    Each path expands to four rules — one each for the path-bearing
    write tools (Write/Edit/MultiEdit/Append). Paths get a ``/**``
    suffix so subdirectories are covered (matching the prior
    ``writable_paths`` semantics where ``./src`` allowed writes to
    everything under it).

    Used by :class:`RemoteConfig` loaders that see a legacy config:
    in-memory migration logs a deprecation warning + the user can
    persist the migrated permissions via the eventual
    ``/permissions save`` command (post-v3.8.0 follow-up).
    """
    if not paths:
        return []
    write_tools = ("Write", "Edit", "MultiEdit", "Append")
    rules: list[str] = []
    for p in paths:
        # Strip trailing slash so the glob is well-formed.
        clean = p.rstrip("/\\")
        if not clean:
            clean = "."
        for tool in write_tools:
            rules.append(f"{tool}({clean}/**)")
    return rules


# === K.1 (Wave K, 2026-05-18) - CallHomePolicy + ToolSequencePolicy ====
#
# Two client-side security primitives that gate network-fetching tools
# and multi-tool exfiltration sequences. Both fire at
# `RemoteToolExecutor.execute()` BEFORE the existing E47 PermissionsConfig
# engine. Together they defend against the canonical
# `read_file(sensitive) -> http_get(external)` prompt-injected
# exfiltration pattern flagged by 3 brainstormers (adversarial-redteam,
# regulatory, incumbent-competitor) in the 2026-05-17 brainstorm.
#
# Trust boundary: enforcement is CLIENT-SIDE only. The trust boundary
# IS the user's machine; server-side defence-in-depth is deferred to a
# later wave (a server enforcement layer would need a new protocol
# surface for per-session policy config).


class PermissionDenied(Exception):
    """Base for K.1+ policy-denial exceptions.

    Distinct from :class:`PermissionError` (Python builtin) and
    :class:`AskPermissionRequired` (E47 ask tier). Lets callers catch
    all client-side policy violations uniformly when raising is
    preferred (e.g. unit tests). Production callers in
    `RemoteToolExecutor.execute()` catch the specific subclasses and
    translate to the existing `(error_str, True)` tuple return shape
    so the broader executor contract is unchanged.
    """


class CallHomePolicyBlocked(PermissionDenied):
    """Raised by :meth:`CallHomePolicy.check` when a URL tool call
    targets a URL outside the configured allow-patterns."""

    def __init__(
        self, tool_name: str, url: str, allowed_patterns: list[str],
    ) -> None:
        self.tool_name = tool_name
        self.url = url
        self.allowed_patterns = list(allowed_patterns)
        super().__init__(
            f"CallHomePolicy blocked {tool_name}(url={url!r}) - URL "
            f"does not match any allowed pattern: {allowed_patterns!r}. "
            f"To allow this URL, add a pattern to "
            f"`call_home_policy.allowed_url_patterns` in remote.yaml, "
            f"or set `call_home_policy.enabled: false` to disable the "
            f"gate."
        )


class ToolSequencePolicyBlocked(PermissionDenied):
    """Raised by :meth:`ToolSequencePolicy.check` when the current
    tool call plus a prior call match a blocked sequence rule."""

    def __init__(
        self, rule_name: str, prior_tool: str, prior_args: dict,
        current_tool: str, current_args: dict,
    ) -> None:
        self.rule_name = rule_name
        self.prior_tool = prior_tool
        self.prior_args = dict(prior_args)
        self.current_tool = current_tool
        self.current_args = dict(current_args)
        super().__init__(
            f"ToolSequencePolicy blocked sequence {rule_name!r}: "
            f"{prior_tool}({_summarize_args(prior_args)}) -> "
            f"{current_tool}({_summarize_args(current_args)}). This "
            f"pattern is treated as a potential exfiltration sequence. "
            f"To allow this sequence, remove the rule from "
            f"`tool_sequence_policy.blocked_sequences` in remote.yaml, "
            f"or set `tool_sequence_policy.enabled: false`."
        )


@dataclass(frozen=True)
class ToolCallRecord:
    """Ring-buffer entry recording a single tool call.

    Used by :class:`ToolSequencePolicy` to detect immediate-precursor
    patterns. `timestamp` is :func:`time.monotonic`; used only by the
    `window_seconds` recency guard inside each rule.
    """
    tool_name: str
    tool_args: dict
    timestamp: float


@dataclass
class SequenceRule:
    """A single blocked tool-call sequence within
    :class:`ToolSequencePolicy`.

    Default `mode="immediate"` means only the IMMEDIATELY prior tool
    call matters - benign intervening calls (e.g. a `bash ls` between
    a `read_file` and an `http_get`) do NOT trip the rule. This
    eliminates false positives from legitimate workflows. The
    `windowed` mode scans the full window and is available when the
    user wants broader matching.
    """
    name: str
    first_tool: str
    second_tool: str
    first_tool_arg_patterns: dict[str, list[str]] = field(default_factory=dict)
    second_tool_arg_patterns: dict[str, list[str]] = field(default_factory=dict)
    description: str = ""
    window_seconds: int = 60
    mode: Literal["immediate", "windowed"] = "immediate"
    on_match: Literal["deny", "ask"] = "deny"


@dataclass
class CallHomePolicy:
    """Client-side URL allowlist gate for network-fetching tools.

    Default-safe: only sim-os.ai subdomains + localhost are allowed.
    Users can extend via remote.yaml::

        call_home_policy:
          enabled: true
          allowed_url_patterns:
            - "https://*.sim-os.ai/*"
            - "https://api.openai.com/*"
            - "http://localhost*"
          applies_to_tools:
            - http_get
            - browser_fetch
          on_block: deny    # `deny` | `ask` (ask reserved for future)

    Enforces at `RemoteToolExecutor.execute()` BEFORE the E47
    PermissionsConfig engine, so URL-pattern blocks short-circuit
    the entire tool pipeline.
    """
    enabled: bool = True
    allowed_url_patterns: list[str] = field(default_factory=lambda: [
        "https://*.sim-os.ai/*",
        "https://*.sim-os.ai",
        "http://localhost*",
        "http://127.0.0.1*",
        # IPv6 loopback (code-reviewer WARNING 2026-05-18). Standard
        # loopback address; legitimate `curl http://[::1]:8000` calls
        # would otherwise be blocked by the default policy.
        "http://[::1]*",
    ])
    applies_to_tools: list[str] = field(default_factory=lambda: [
        "http_get", "browser_fetch",
    ])
    on_block: Literal["deny", "ask"] = "deny"

    def check(self, tool_name: str, tool_args: dict) -> None:
        """Raise :class:`CallHomePolicyBlocked` if the tool call's
        URL is not in the allowlist. No-op when policy is disabled,
        when the tool is not in `applies_to_tools`, or when the URL
        matches a configured pattern."""
        if not self.enabled:
            return
        if tool_name not in self.applies_to_tools:
            return
        url = tool_args.get("url", "")
        if not isinstance(url, str) or not url:
            # Defensive: non-string URL arg or absent/empty URL is a
            # different bug (probably a tool-handler type mismatch
            # or missing required arg). Let the downstream handler
            # surface the real error rather than block on a spurious
            # CallHomePolicy violation against an empty URL.
            return
        for pattern in self.allowed_url_patterns:
            if _url_fnmatch(url, pattern):
                return
        raise CallHomePolicyBlocked(tool_name, url, self.allowed_url_patterns)

    @classmethod
    def from_yaml_dict(cls, data: Any) -> "CallHomePolicy":
        """Construct from remote.yaml's `call_home_policy:` block.

        Returns the default-safe policy if data is None or not a dict.
        Raises :class:`ValueError` if `applies_to_tools` is explicitly
        an empty list (architect-recommended foot-gun guard,
        2026-05-18: empty list would silently disable URL checking
        for all tools while leaving `enabled: true`).
        """
        if not isinstance(data, dict):
            return cls()
        applies_to = data.get("applies_to_tools")
        if applies_to == []:
            raise ValueError(
                "CallHomePolicy.applies_to_tools is explicitly empty - "
                "this would disable URL checking for all tools. If "
                "you intend to disable CallHomePolicy entirely, set "
                "`call_home_policy: {enabled: false}`. To check only "
                "specific tools, list them explicitly."
            )
        kwargs: dict = {}
        if "enabled" in data:
            kwargs["enabled"] = bool(data["enabled"])
        if "allowed_url_patterns" in data:
            kwargs["allowed_url_patterns"] = list(
                data["allowed_url_patterns"] or []
            )
        if applies_to is not None:
            kwargs["applies_to_tools"] = list(applies_to)
        if "on_block" in data:
            kwargs["on_block"] = data["on_block"]
        return cls(**kwargs)


@dataclass
class ToolSequencePolicy:
    """Client-side multi-tool-call sequence detector.

    Default-safe: ships with one canonical exfiltration rule blocking
    `read_file(sensitive) -> http_get(any)` adjacency. Configure via
    remote.yaml::

        tool_sequence_policy:
          enabled: true
          blocked_sequences:
            - name: custom_rule
              first_tool: read_file
              first_tool_arg_patterns:
                path: ["~/.ssh/*", "*.pem"]
              second_tool: http_get
              second_tool_arg_patterns:
                url: ["*"]
              mode: immediate
              window_seconds: 60
    """
    enabled: bool = True
    blocked_sequences: list[SequenceRule] = field(default_factory=lambda: [
        SequenceRule(
            name="read_sensitive_then_http_external",
            description=(
                "Blocks the canonical read-sensitive-file then "
                "external-http exfiltration pattern."
            ),
            first_tool="read_file",
            first_tool_arg_patterns={
                "path": [
                    "*/.ssh/*", ".env*", "*credentials*", "*secret*",
                    "*.pem", "*.key", "*/.aws/credentials",
                    "*/.gitconfig", "*/.netrc",
                ],
            },
            second_tool="http_get",
            second_tool_arg_patterns={"url": ["*"]},
            window_seconds=60,
            mode="immediate",
        ),
    ])

    def check(
        self, tool_name: str, tool_args: dict,
        recent_calls: list[ToolCallRecord],
    ) -> None:
        """Raise :class:`ToolSequencePolicyBlocked` if the current
        call + a prior call (immediate or windowed per rule) match a
        blocked sequence. No-op when policy is disabled or there are
        no recent calls."""
        if not self.enabled or not recent_calls:
            return
        now = time.monotonic()
        for rule in self.blocked_sequences:
            if rule.second_tool != tool_name:
                continue
            if not _match_arg_patterns(
                rule.second_tool_arg_patterns, tool_args,
            ):
                continue
            # Determine candidate prior calls per rule mode.
            if rule.mode == "immediate":
                candidates = [recent_calls[-1]] if recent_calls else []
            else:  # windowed
                candidates = list(recent_calls)
            for prior in candidates:
                if prior.tool_name != rule.first_tool:
                    continue
                if not _match_arg_patterns(
                    rule.first_tool_arg_patterns, prior.tool_args,
                ):
                    continue
                # Recency guard: skip prior calls older than the
                # window (regardless of mode).
                age = now - prior.timestamp
                if age > rule.window_seconds:
                    continue
                raise ToolSequencePolicyBlocked(
                    rule.name, prior.tool_name, prior.tool_args,
                    tool_name, tool_args,
                )

    @classmethod
    def from_yaml_dict(cls, data: Any) -> "ToolSequencePolicy":
        """Construct from remote.yaml's `tool_sequence_policy:` block.

        Returns default-safe policy (one canonical rule) if data is
        None or not a dict.
        """
        if not isinstance(data, dict):
            return cls()
        kwargs: dict = {}
        if "enabled" in data:
            kwargs["enabled"] = bool(data["enabled"])
        if "blocked_sequences" in data:
            seqs_raw = data["blocked_sequences"] or []
            kwargs["blocked_sequences"] = [
                SequenceRule(
                    name=s["name"],
                    first_tool=s["first_tool"],
                    second_tool=s["second_tool"],
                    first_tool_arg_patterns=dict(
                        s.get("first_tool_arg_patterns") or {}
                    ),
                    second_tool_arg_patterns=dict(
                        s.get("second_tool_arg_patterns") or {}
                    ),
                    description=s.get("description", ""),
                    window_seconds=int(s.get("window_seconds", 60)),
                    mode=s.get("mode", "immediate"),
                    on_match=s.get("on_match", "deny"),
                )
                for s in seqs_raw
            ]
        return cls(**kwargs)


def _url_fnmatch(url: str, pattern: str) -> bool:
    """fnmatch with bracket-literal awareness for IPv6 URL patterns.

    fnmatch's `[...]` syntax is a character class; that breaks literal
    bracket matching for IPv6 URLs like `http://[::1]:8000` where the
    brackets are required URL syntax (RFC 3986). This helper escapes
    `[` and `]` in the pattern by wrapping them in fnmatch's own
    "character class containing one character" syntax: `[[]` matches a
    literal `[`, and `[]]` matches a literal `]`. Wildcards (`*`, `?`)
    in the pattern still work as fnmatch globs.

    Code-reviewer surfaced this gap 2026-05-18 — without the helper,
    `fnmatch.fnmatch("http://[::1]:8000", "http://[::1]*")` returns
    False because `[::1]` is parsed as the char class `[:1]`.
    """
    # Single-pass escape — chained replace() is unsafe here because
    # the first pass inserts new `[` and `]` that the second pass
    # would touch again ("http://[::1]*" -> "http://[[]]::1[]]*").
    out_chars: list[str] = []
    for ch in pattern:
        if ch == "[":
            out_chars.append("[[]")
        elif ch == "]":
            out_chars.append("[]]")
        else:
            out_chars.append(ch)
    escaped_pattern = "".join(out_chars)
    return fnmatch.fnmatch(url, escaped_pattern)


def _match_arg_patterns(
    patterns: dict[str, list[str]], args: dict,
) -> bool:
    """Match every key in `patterns` against the corresponding value
    in `args`.

    Each pattern entry is a list of fnmatch globs; the arg value must
    match at least one of them. Empty `patterns` dict matches anything
    (used by `second_tool_arg_patterns: {"url": ["*"]}` which is
    semantically "any URL").
    """
    if not patterns:
        return True
    for key, glob_list in patterns.items():
        arg_value = args.get(key, "")
        if not isinstance(arg_value, str):
            return False
        if not any(fnmatch.fnmatch(arg_value, p) for p in glob_list):
            return False
    return True


def _log_policy_block(event_type: str, **fields: object) -> None:
    """Local audit log for policy-block events.

    Uses the stdlib logger; this is NOT a server-side trace event
    (client-side enforcement is by design; server-side audit
    deferred to a later wave). Per architect critique 2026-05-18,
    the helper is named `_log_policy_block` (not `emit_trace_event`)
    to avoid implying server-side durability.
    """
    logging.getLogger(__name__).info(
        "policy_block",
        extra={"event_type": event_type, **fields},
    )
