"""
Transform stage: Clean data (remove duplicates), extract add_dimension, and stage.
"""

import logging
import os
from typing import Optional, Sequence

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import coalesce, col, get_json_object, regexp_extract

from .config import BatchAnalyticsConfig

logger = logging.getLogger(__name__)


def extract_anchor_id(
    df: DataFrame,
    config: BatchAnalyticsConfig,
) -> DataFrame:
    """
    Extract anchor_id from add_dimension column.
    Supports JSON format {"anchor_id":"value"} or Python-dict {"anchor_id":"value"}.
    Creates a new column (anchor_id by default) with the extracted value.
    """
    col_name = config.transform.add_dimension_column
    out_col = config.transform.anchor_id_column

    if col_name not in df.columns:
        logger.debug("Column %s not found, skipping anchor_id extraction", col_name)
        return df

    # Valid JSON: {"anchor_id":"GP/GPH(D)/II(W)/250019"}
    json_extract = get_json_object(col(col_name), "$.anchor_id")
    # Python-dict style: {'anchor_id':'GP/GPH(D)/II(W)/250019'}
    regex_extract = regexp_extract(col(col_name), r"'anchor_id'\s*:\s*'([^']*)'", 1)

    extracted = coalesce(json_extract, regex_extract)
    return df.withColumn(out_col, extracted)


def remove_duplicates(
    df: DataFrame,
    key_columns: Optional[Sequence[str]] = None,
) -> DataFrame:
    """
    Remove duplicate rows.
    If key_columns is provided, keeps first occurrence per key.
    Otherwise, drops exact row duplicates.
    """
    before_count = df.count()
    if key_columns:
        df_cleaned = df.dropDuplicates(key_columns)
    else:
        df_cleaned = df.distinct()
    after_count = df_cleaned.count()
    removed = before_count - after_count
    logger.info(
        "Deduplication: %d -> %d rows (removed %d duplicates)",
        before_count,
        after_count,
        removed,
    )
    return df_cleaned


def transform(
    df: DataFrame,
    config: BatchAnalyticsConfig,
) -> DataFrame:
    """
    Apply transformation only: extract anchor_id, remove duplicates.
    Does not write anywhere. Use stage_to_clickhouse() separately to persist.
    """
    transformed = extract_anchor_id(df, config)
    dedup_cols = (
        [c.strip() for c in config.transform.dedup_columns.split(",") if c.strip()]
        if config.transform.dedup_columns
        else None
    )
    return remove_duplicates(transformed, key_columns=dedup_cols)


def stage_to_clickhouse(
    spark: SparkSession,
    df: DataFrame,
    config: BatchAnalyticsConfig,
) -> None:
    """
    Write transformed data to ClickHouse staging table.
    Separate job from transform; must complete before analytics can run.
    Uses native connector if available, else JDBC.
    """
    n = df.count()
    try:
        ch = config.clickhouse
        writer = (
            df.write.format("clickhouse")
            .option("host", ch.host)
            .option("protocol", ch.protocol)
            .option("http_port", str(ch.port))
            .option("database", ch.database)
            .option("table", config.transform.staging_table)
            .option("user", ch.user)
            .mode("overwrite")
        )
        if ch.password:
            writer = writer.option("password", ch.password)
        writer.save()
    except Exception as e:
        logger.warning("ClickHouse connector failed (%s), using JDBC", e)
        df.write.jdbc(
            config.clickhouse.jdbc_url,
            config.transform.staging_table,
            mode="overwrite",
            properties=config.clickhouse.jdbc_properties,
        )
    logger.info(
        "Staged data to ClickHouse %s.%s (%d rows)",
        config.clickhouse.database,
        config.transform.staging_table,
        n,
    )


def stage_to_path(
    spark: SparkSession,
    df: DataFrame,
    config: BatchAnalyticsConfig,
) -> None:
    """Write transformed data to parquet/delta (for local dev or intermediate storage)."""
    path = config.transform.staging_path
    fmt = config.transform.staging_format
    if fmt == "parquet":
        df.write.mode("overwrite").parquet(path)
        logger.info("Staged data to %s (parquet)", path)
    elif fmt == "delta":
        df.write.format("delta").mode("overwrite").save(path)
        logger.info("Staged data to %s (delta)", path)
    else:
        df.write.format(fmt).mode("overwrite").save(path)
        logger.info("Staged data to %s (%s)", path, fmt)


def transform_and_stage(
    spark: SparkSession,
    df: DataFrame,
    config: BatchAnalyticsConfig,
) -> DataFrame:
    """
    Transform and stage to ClickHouse. Kept for backward compatibility.
    Prefer calling transform() then stage_to_clickhouse() separately.
    """
    cleaned = transform(df, config)
    stage_to_clickhouse(spark, cleaned, config)
    return cleaned


def load_staged(
    spark: SparkSession,
    config: BatchAnalyticsConfig,
) -> DataFrame:
    """
    Load previously staged data (e.g. when running only analytics modules).
    """
    staging_path = config.transform.staging_path
    fmt = config.transform.staging_format

    if fmt == "parquet":
        return spark.read.parquet(staging_path)
    if fmt == "delta":
        return spark.read.format("delta").load(staging_path)
    if fmt == "clickhouse":
        ch = config.clickhouse
        tbl = config.transform.staging_table
        cat = os.environ.get("BATCH_CLICKHOUSE_CATALOG", "batch_ch").strip()
        if cat:
            try:
                return spark.table(f"{cat}.{ch.database}.{tbl}")
            except Exception as e:
                logger.warning(
                    "load_staged: catalog table %s.%s.%s failed (%s), using JDBC",
                    cat,
                    ch.database,
                    tbl,
                    e,
                )
        dbtable = f"(SELECT * FROM `{ch.database}`.`{tbl}`) AS _stg"
        return spark.read.jdbc(
            ch.jdbc_url,
            dbtable,
            properties=ch.jdbc_properties,
        )
    return spark.read.format(fmt).load(staging_path)
