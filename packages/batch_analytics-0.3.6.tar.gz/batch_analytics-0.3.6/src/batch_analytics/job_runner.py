"""
Batch analytics job runner: orchestrates Extract, Transform, Log stages and analytics modules.
"""

import argparse
import logging
import os
import socket
import sys
import uuid
from pathlib import Path
from typing import Dict, List, Optional
from urllib.parse import urlparse

from pyspark.sql import SparkSession

from .config import BatchAnalyticsConfig
from .extract import extract_unified
from .log import log_dataframe_summary, log_run
from .modules import DEFAULT_MODULES, MODULE_REGISTRY, VALID_MODULES
from .output import write_analytics_output
from .transform import load_staged, stage_to_clickhouse, transform

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)


def _local_jar_path_for_match(p: str) -> str:
    """Normalize file:/path or /path for prefix checks."""
    p = p.strip()
    if not p:
        return p
    if p.startswith("file:"):
        parsed = urlparse(p)
        return parsed.path if parsed.path else p[5:]
    return p


def _omit_spark_distrib_jars(jar_list: List[str]) -> List[str]:
    """
    Drop paths under $SPARK_HOME/jars from spark.jars.

    Those JARs are already on the driver and executor JVM classpath (Spark launch scripts add
    $SPARK_HOME/jars/*). Listing them again in spark.jars makes Spark distribute them to executors
    as ./basename.jar and breaks Kubernetes executors.

    SPARK_HOME may be unset or empty in some pods; always treat /opt/spark/jars/ as Spark distro
    (apache/spark images).
    """
    spark_home = (os.environ.get("SPARK_HOME") or "/opt/spark").rstrip("/")
    prefixes = (f"{spark_home}/jars/", "/opt/spark/jars/")
    out: List[str] = []
    skipped: List[str] = []
    for p in jar_list:
        p = p.strip()
        if not p:
            continue
        norm = _local_jar_path_for_match(p)
        if norm.endswith(".jar") and any(norm.startswith(pref) for pref in prefixes):
            skipped.append(p)
        else:
            out.append(p)
    if skipped:
        logger.info(
            "Omitting spark.jars for JARs already on Spark classpath (%s): %s",
            prefixes[0],
            ",".join(skipped),
        )
    return out


def create_spark_session(
    app_name: str = "BatchAnalytics",
    clickhouse_jars: Optional[str] = None,
    config: Optional[BatchAnalyticsConfig] = None,
) -> SparkSession:
    """
    Create SparkSession. Uses Kubernetes config when SPARK_MASTER starts with k8s://.
    """
    config = config or BatchAnalyticsConfig()
    cfg = config.spark_k8s

    builder = (
        SparkSession.builder.appName(app_name)
        .config("spark.sql.adaptive.enabled", "true")
        .config("spark.sql.adaptive.coalescePartitions.enabled", "true")
    )

    # JARs: spark.jars = local/https/file paths; spark.jars.packages = Maven coordinates
    # SPARK_JARS can be comma-separated URLs (e.g. Maven Central https://repo1.maven.org/...jar)
    jar_list: List[str] = []
    sp_jars = os.environ.get("SPARK_JARS", "").strip()
    if sp_jars:
        jar_list.extend(p.strip() for p in sp_jars.split(",") if p.strip())

    packages: List[str] = []
    if clickhouse_jars:
        for part in clickhouse_jars.split(","):
            part = part.strip()
            if not part:
                continue
            if part.startswith(("http://", "https://", "file:")):
                jar_list.append(part)
            elif part.endswith(".jar") and ":" not in part:
                jar_list.append(part)
            else:
                packages.append(part)

    jar_list = _omit_spark_distrib_jars(jar_list)

    if jar_list:
        builder = builder.config("spark.jars", ",".join(jar_list))
    elif os.environ.get("BATCH_ALLOW_INHERITED_SPARK_JARS", "").strip().lower() not in (
        "1",
        "true",
        "yes",
    ):
        # spark-submit / image ENV often set SPARK_JARS → --jars; Python never sees it in jar_list
        # above, but Spark still adds them ("Added JAR /opt/spark/jars/...") and K8s executors fail.
        # Empty spark.jars overrides inherited submit --jars; $SPARK_HOME/jars stay on JVM classpath.
        builder = builder.config("spark.jars", "")
        logger.info(
            "spark.jars cleared (override spark-submit --jars / SPARK_JARS); "
            "JARs under $SPARK_HOME/jars remain on the classpath. "
            "Set BATCH_ALLOW_INHERITED_SPARK_JARS=1 to keep submit-inherited spark.jars."
        )
    if packages:
        builder = builder.config("spark.jars.packages", ",".join(packages))

    # clickhouse-spark-runtime does not register legacy clickhouse.DefaultSource; the connector
    # expects a Spark catalog (see ClickHouse docs). Enables spark.table("catalog.db.table").
    ch_cat = os.environ.get("BATCH_CLICKHOUSE_CATALOG", "batch_ch").strip()
    if ch_cat:
        ch = config.clickhouse
        builder = (
            builder.config(
                f"spark.sql.catalog.{ch_cat}",
                "com.clickhouse.spark.ClickHouseCatalog",
            )
            .config(f"spark.sql.catalog.{ch_cat}.host", ch.host)
            .config(f"spark.sql.catalog.{ch_cat}.protocol", ch.protocol)
            .config(f"spark.sql.catalog.{ch_cat}.http_port", str(ch.port))
            .config(f"spark.sql.catalog.{ch_cat}.user", ch.user)
            .config(f"spark.sql.catalog.{ch_cat}.database", ch.database)
        )
        if ch.password:
            builder = builder.config(f"spark.sql.catalog.{ch_cat}.password", ch.password)
        if ch.protocol.lower() == "https":
            builder = builder.config(f"spark.sql.catalog.{ch_cat}.option.ssl", "true")
        # Avoid Lz4InputStream "Magic is not correct" when server HTTP compression != client expectation
        # (see clickhouse-java#1449 / server enable_http_compression user defaults).
        read_codec = os.environ.get(
            "SPARK_CLICKHOUSE_READ_COMPRESSION_CODEC", "none"
        ).strip()
        if read_codec:
            builder = builder.config(
                "spark.clickhouse.read.compression.codec",
                read_codec,
            )

    if cfg.master.startswith("k8s://"):
        driver_host = socket.gethostbyname(socket.gethostname())
        builder = (
            builder.master(cfg.master)
            .config("spark.kubernetes.container.image", cfg.container_image)
            .config("spark.kubernetes.namespace", cfg.namespace)
            .config("spark.kubernetes.authenticate.serviceAccountName", cfg.service_account)
            .config("spark.driver.host", driver_host)
            .config("spark.driver.bindAddress", "0.0.0.0")
            .config(
                "spark.kubernetes.driver.pod.name",
                os.environ.get("HOSTNAME", socket.gethostname()),
            )
            .config("spark.submit.deployMode", cfg.deploy_mode)
            .config(
                "spark.driver.extraJavaOptions",
                "-Djava.net.preferIPv4Stack=true -XX:+UseG1GC -XX:+HeapDumpOnOutOfMemoryError",
            )
            .config("spark.driver.memory", cfg.driver_memory)
            .config("spark.driver.memoryOverhead", cfg.driver_memory_overhead)
            .config("spark.executor.instances", str(cfg.executor_instances))
            .config("spark.executor.cores", str(cfg.executor_cores))
            .config("spark.executor.memory", cfg.executor_memory)
            .config("spark.executor.memoryOverhead", cfg.executor_memory_overhead)
            .config("spark.kubernetes.executor.serviceAccountName", cfg.service_account)
            .config("spark.kubernetes.container.image.pullPolicy", "IfNotPresent")
        )
        if cfg.s3_access_key and cfg.s3_secret_key:
            builder = (
                builder.config("spark.hadoop.fs.s3a.impl", "org.apache.hadoop.fs.s3a.S3AFileSystem")
                .config("spark.hadoop.fs.s3a.access.key", cfg.s3_access_key)
                .config("spark.hadoop.fs.s3a.secret.key", cfg.s3_secret_key)
                .config("spark.hadoop.fs.s3a.endpoint", cfg.s3_endpoint)
                .config("spark.hadoop.fs.s3a.endpoint.region", cfg.s3_region)
            )
        logger.info("Spark on Kubernetes: master=%s", cfg.master)

    return builder.getOrCreate()


def run_pipeline(
    config: Optional[BatchAnalyticsConfig] = None,
    spark: Optional[SparkSession] = None,
    run_extract: bool = True,
    run_transform: bool = True,
    run_stage: bool = True,
    run_analytics: bool = True,
    modules: Optional[List[str]] = None,
) -> Dict:
    """
    Run the full pipeline or selected stages.

    Args:
        config: Pipeline config (default: BatchAnalyticsConfig())
        spark: SparkSession (created if None)
        run_extract: Whether to extract from ClickHouse
        run_transform: Whether to transform (clean, dedupe, extract anchor_id)
        run_stage: Whether to stage transformed data to ClickHouse (separate job)
        run_analytics: Whether to run analytics (requires staged data in ClickHouse)
        modules: Which analytics to run: ["lr", "corr", "pca", "ttest"] or None for all

    Returns:
        Dict with run_id, stage results, analytics outputs
    """
    config = config or BatchAnalyticsConfig()
    run_id = str(uuid.uuid4())[:8]

    if spark is None:
        # Native format("clickhouse") needs clickhouse-spark-runtime; JDBC needs shaded clickhouse-jdbc (*-all),
        # not the thin Maven artifact: thin JAR lacks HttpClient 5 (ClassicHttpRequest).
        # Override: BATCH_SPARK_CLICKHOUSE_PACKAGES=maven coords / https jar URLs (comma-sep) or "" for SPARK_JARS only.
        # Empty/unset: rely on $SPARK_HOME/jars (analytics-runner image). Do not add spark.jars /
        # spark.jars.packages for ClickHouse here — that breaks K8s executors (./basename.jar).
        # For ad-hoc runs without the image, set e.g.
        # BATCH_SPARK_CLICKHOUSE_PACKAGES=com.clickhouse.spark:clickhouse-spark-runtime-3.5_2.12:0.8.0,https://repo1.maven.org/maven2/com/clickhouse/clickhouse-jdbc/0.9.8/clickhouse-jdbc-0.9.8-all.jar
        _raw_ch = os.environ.get("BATCH_SPARK_CLICKHOUSE_PACKAGES")
        if _raw_ch is None or not _raw_ch.strip():
            ch_pkgs = None
        else:
            ch_pkgs = _raw_ch.strip()
        spark = create_spark_session(
            app_name="BatchAnalytics",
            clickhouse_jars=ch_pkgs,
            config=config,
        )

    result = {"run_id": run_id, "stages": {}, "analytics": {}}

    # ----- Extract -----
    if run_extract:
        logger.info("Stage: Extract")
        df_raw = extract_unified(spark, config)
        result["stages"]["extract"] = {
            "row_count": df_raw.count(),
            "columns": [f.name for f in df_raw.schema.fields],
        }
    else:
        logger.info("Stage: Extract (skipped, loading from stage)")
        df_raw = load_staged(spark, config)
        result["stages"]["extract"] = {"skipped": True, "loaded_from_stage": True}

    # ----- Transform -----
    if run_transform:
        logger.info("Stage: Transform")
        df_transformed = transform(df_raw, config)
        result["stages"]["transform"] = {"row_count": df_transformed.count()}
    else:
        df_transformed = df_raw  # df_raw already loaded from staged when not run_extract
        if run_extract and run_analytics:
            from .transform import extract_anchor_id, remove_duplicates

            df_transformed = extract_anchor_id(df_raw, config)
            dedup_cols = (
                [c.strip() for c in config.transform.dedup_columns.split(",") if c.strip()]
                if config.transform.dedup_columns
                else None
            )
            df_transformed = remove_duplicates(df_transformed, key_columns=dedup_cols)
        result["stages"]["transform"] = {"skipped": True}

    # ----- Stage (to ClickHouse) - separate job before analytics -----
    if run_stage:
        logger.info("Stage: Stage to ClickHouse")
        stage_to_clickhouse(spark, df_transformed, config)
        result["stages"]["stage"] = {
            "destination": f"{config.clickhouse.database}.{config.transform.staging_table}",
            "row_count": df_transformed.count(),
        }
    else:
        result["stages"]["stage"] = {"skipped": True}

    # For analytics: use in-memory df (we always have df_transformed from transform/load)
    df_for_analytics = df_transformed

    # ----- Log stage metrics -----
    log_run(
        run_id,
        "pipeline",
        result["stages"],
        output_dir=config.log.log_path,
        extra={"config_summary": {"staging_format": config.transform.staging_format}},
    )

    # ----- Analytics (runs after stage; must run extract+transform+stage first, or use --from-stage) -----
    if run_analytics:
        modules = modules or DEFAULT_MODULES
        for mod in modules:
            if mod not in MODULE_REGISTRY:
                logger.warning("Unknown module %r, skipping. Valid: %s", mod, VALID_MODULES)
                continue
            run_fn, result_key = MODULE_REGISTRY[mod]
            try:
                mod_result = run_fn(spark, df_for_analytics, config)
                result["analytics"][result_key] = mod_result
            except Exception as e:
                logger.exception("%s failed: %s", result_key, e)
                result["analytics"][result_key] = {"error": str(e)}

        task_id = config.output.task_id or run_id
        write_analytics_output(
            run_id=run_id,
            task_id=task_id,
            artifacts=result["analytics"],
            output_type=config.output.type,
            path=config.log.log_path
            if config.output.type == "local"
            else config.output.s3_path,
            database=config.output.clickhouse_database,
            table=config.output.clickhouse_table,
            host=config.clickhouse.host,
            port=config.clickhouse.port,
            user=config.clickhouse.user,
            password=config.clickhouse.password,
        )

    return result


def main() -> int:
    parser = argparse.ArgumentParser(description="Batch analytics: Extract, Transform, Log + analytics")
    parser.add_argument(
        "--extract",
        action="store_true",
        default=True,
        help="Run extract stage (default: true)",
    )
    parser.add_argument(
        "--no-extract",
        action="store_false",
        dest="extract",
    )
    parser.add_argument(
        "--transform",
        action="store_true",
        default=True,
        help="Run transform stage (default: true)",
    )
    parser.add_argument(
        "--no-transform",
        action="store_false",
        dest="transform",
    )
    parser.add_argument(
        "--stage",
        action="store_true",
        default=True,
        help="Run stage step: write transformed data to ClickHouse (default: true)",
    )
    parser.add_argument(
        "--no-stage",
        action="store_false",
        dest="stage",
    )
    parser.add_argument(
        "--analytics",
        action="store_true",
        default=True,
        help="Run analytics modules (default: true)",
    )
    parser.add_argument(
        "--no-analytics",
        action="store_false",
        dest="analytics",
    )
    parser.add_argument(
        "--modules",
        nargs="+",
        choices=VALID_MODULES,
        default=None,
        help="Analytics modules to run (default: all). Must match catalog module_arg.",
    )
    parser.add_argument(
        "--from-stage",
        action="store_true",
        help="Load from staged ClickHouse table, run analytics only (implies --no-extract --no-transform --no-stage)",
    )
    args = parser.parse_args()

    if args.from_stage:
        args.extract = False
        args.transform = False
        args.stage = False

    result = run_pipeline(
        run_extract=args.extract,
        run_transform=args.transform,
        run_stage=args.stage,
        run_analytics=args.analytics,
        modules=args.modules,
    )

    logger.info("Run completed: %s", result["run_id"])
    return 0


if __name__ == "__main__":
    sys.exit(main())
