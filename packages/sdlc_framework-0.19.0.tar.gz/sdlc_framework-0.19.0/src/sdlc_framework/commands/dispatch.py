"""Autopilot dispatch handlers — auto-step, auto-mad-step, next.

Two distinct modes:

- ``auto`` (existing): emits one ``invoke`` / ``stop`` / ``done`` action per
  call. Stops on every gate, every drafted-but-unverified artifact, every
  open clarification, every high-risk path, and every PR-pending review.
  The user runs ``sdlc verify`` / writes signoffs / resolves clarifications
  manually between iterations.

- ``auto-mad`` (new in 0.13.0): MAD-A safety profile. Same as ``auto`` but
  also auto-resolves the *human-policy* stops:

    | Stop reason       | auto    | auto-mad         |
    | ----------------- | ------- | ---------------- |
    | verify_needed     | stop    | auto-write marker|
    | gate              | stop    | auto-sign yaml   |
    | clarification     | stop    | **stop (kept)**  |
    | high_risk         | stop    | **stop (kept)**  |
    | review_pending    | stop    | stop             |
    | tasks_empty       | stop    | stop             |

  Clarifications stay manual because they encode product *intent* the
  agent cannot infer. High-risk paths (auth, crypto, payment, secrets,
  iam, migration) stay manual because they encode security/financial
  policy. Every other "human-only" rule is bypassed.

  Auto-signoff yaml files are clearly marked ``approved_by: ai-mad-mode``
  with a timestamp and an unsign command so the user can revert.

Both handlers share the same ``compute_next_step`` core; ``auto-mad``
just runs an inner loop that applies auto-actions and re-scans until
the state quiesces, then prints the resulting (non-auto) action.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
from pathlib import Path

# Same high-risk policy used by auto and auto-mad. auto-mad still STOPS on
# these — only the human-only gate / verify checkpoints are bypassed.
HIGH_RISK_KEYWORDS = ["auth", "crypto", "payment", "secrets", "iam", "migration"]


# ---------------------------------------------------------------------------
# Pure helpers
# ---------------------------------------------------------------------------


def _is_high_risk(item: dict) -> bool:
    label = (item.get("label") or "").lower() + " " + (item.get("id") or "").lower()
    return any(h in label for h in HIGH_RISK_KEYWORDS)


def _latest_review_file(target: Path, task_id: str) -> Path | None:
    """Return the newest automation/reviews/<task-id>-*.md, or None."""
    review_dir = target / "automation" / "reviews"
    if not review_dir.exists():
        return None
    matches = sorted(review_dir.glob(f"{task_id}-*.md"))
    return matches[-1] if matches else None


def _branch_for_task(state: dict, task_id: str) -> str | None:
    """Lookup pr_branch (or pr_url) for a task in state.phases[3]."""
    for ph in state.get("phases", []):
        if ph.get("id") != 3:
            continue
        for it in ph.get("items", []):
            if it.get("id") == task_id:
                return it.get("pr_url") or it.get("pr_branch")
    return None


def _handle_auto_action(action: dict, state: dict, target: Path) -> dict:
    """Execute open_pr / squash_merge auto-actions emitted by mad-mode.

    Returns a dict that the outer loop appends to ``auto_actions_taken``
    on success, or surfaces as a stop on failure.
    """
    from sdlc_framework import gh_ops
    kind = action["auto_kind"]
    if kind == "open_pr":
        task_id = action["task_id"]
        branch = _branch_for_task(state, task_id) or f"feature/{task_id}"
        url = gh_ops.open_pr(branch=branch, base="main", target=target)
        if url is None:
            return {
                "stop_reason": "pr_open_failed",
                "user_action": (
                    f"`gh pr create --head {branch}` failed. Check "
                    f"`gh auth status`, branch state, then re-run."
                ),
            }
        return {"pr_url": url, "kind": "open_pr", "task_id": task_id}
    if kind == "squash_merge":
        task_id = action["task_id"]
        pr_ref = action.get("pr_url") or _branch_for_task(state, task_id)
        ok, err = gh_ops.squash_merge(
            pr_ref=pr_ref,
            subject=(
                f"chore: auto-merge {task_id} via /sdlc-auto-mad "
                f"[no human review]"
            ),
            target=target,
        )
        if not ok:
            return {
                "stop_reason": "merge_failed",
                "user_action": (
                    f"`gh pr merge {pr_ref}` failed: {err}. Resolve and re-run."
                ),
            }
        state.setdefault("phase3", {})["active_feature_id"] = None
        state["phase3"]["lock_acquired_at"] = None
        return {"merged": True, "kind": "squash_merge", "task_id": task_id}
    raise ValueError(f"unknown auto_kind: {kind}")


def _resolve_agent(item: dict, phase_id: int, engine_module) -> str:
    """Mirror of cli.py's agent resolution order."""
    return (
        item.get("next_subagent")          # Phase 3 task stage agent
        or item.get("agent")                # per-item override
        or engine_module.PHASE_AGENT_MAP.get(phase_id, "orchestrator")
    )


def _build_instruction(agent: str, item_id: str, stage: str | None) -> str:
    """Same instruction text used by both auto and auto-mad."""
    parts = [
        f"Use the {agent} subagent. Read agents/<role>.md for the role spec ",
        f"and automation/rules.json item `{item_id}` for evidence requirements. ",
        "Write the deliverable file (NOT into templates/). ",
    ]
    if not stage:
        parts.append(
            "After writing the artifact, append a "
            "`<!-- sdlc:verified-by: <name> <iso-date> -->` marker so the "
            "user can review and the engine can re-verify on their side. "
        )
    parts.append(
        "Stop and write a clarification file under "
        "automation/clarifications/ if you hit ambiguity, conflict, gate, "
        "or high-risk path. Do NOT modify code outside this item's scope."
    )
    return "".join(parts)


def _brief_context_for(state: dict, agent: str, target: Path) -> str:
    try:
        from sdlc_framework import context_bundle
        base = context_bundle.role_slice(state, agent, target)
    except Exception as e:  # noqa: BLE001
        import sys
        print(f"[sdlc dispatch] brief_context build failed: {e}", file=sys.stderr)
        base = ""
    # Append the addons "External assets available" advisory section.
    # Pure additive — if the project has no addons or no matching assets,
    # the brief is returned unchanged.
    try:
        from sdlc_framework.addons.brief import append_external_section
        return append_external_section(base, state, target)
    except Exception as e:  # noqa: BLE001
        import sys
        print(f"[sdlc dispatch] external-assets section skipped: {e}", file=sys.stderr)
        return base


# ---------------------------------------------------------------------------
# auto-mad auto-actions: write a verify marker / signoff yaml on the user's
# behalf so the next scan sees the item as done. Auditable: the resulting
# files clearly identify themselves as ai-mad-mode-generated.
# ---------------------------------------------------------------------------


def _now_iso() -> str:
    return dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _framework_version() -> str:
    try:
        from sdlc_framework import __version__
        return __version__
    except Exception:  # noqa: BLE001
        return "unknown"


def auto_verify_artifact(item_id: str, target: Path) -> bool:
    """Append a verify-by marker for ``item_id`` as ``ai-mad-mode``.

    Delegates to ``cli._cmd_verify`` with ``--name=ai-mad-mode`` so the
    same marker rules + .verifications.json audit log apply. The marker
    name distinguishes auto-mad signoffs from human signoffs at a glance.

    Returns True when a marker was actually written (False when the item
    was already verified or has no verify check).
    """
    from sdlc_framework.cli import _cmd_verify
    # _cmd_verify reads its own argv; redirect stdout to suppress the
    # "[sdlc verify] ..." prints — the outer auto-mad-step JSON will
    # report what got auto-verified.
    import contextlib
    import io
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        rc = _cmd_verify([item_id, "--name=ai-mad-mode"])
    return rc == 0


def auto_signoff_gate(gate_id: str, gate_label: str, target: Path) -> bool:
    """Write ``automation/signoffs/<gate_id>.yaml`` granting approval.

    The yaml clearly identifies itself as ai-generated so a human reading
    state.json or the dashboard can spot auto-signoffs at a glance.
    Includes an ``unsign_command`` for trivial revert.
    """
    signoffs_dir = target / "automation" / "signoffs"
    signoffs_dir.mkdir(parents=True, exist_ok=True)
    target_file = signoffs_dir / f"{gate_id}.yaml"
    if target_file.exists():
        try:
            text = target_file.read_text(encoding="utf-8")
            # Idempotent: already approved.
            if "approved: true" in text or "approved:true" in text:
                return False
        except OSError:
            pass
    body = (
        f"# AI-generated signoff — DO NOT trust without auditing the work.\n"
        f"# Generated by /sdlc-auto-mad. To revert: rm '{target_file.relative_to(target)}'\n"
        f"gate_id: {gate_id}\n"
        f"gate_label: {gate_label!r}\n"
        f"approved: true\n"
        f"approved_by: ai-mad-mode\n"
        f"approved_at: {_now_iso()}\n"
        f"sdlc_framework_version: \"{_framework_version()}\"\n"
        f"reason: \"auto-signed in /sdlc-auto-mad mode (no human review)\"\n"
        f"unsign_command: \"rm {target_file.relative_to(target)}\"\n"
    )
    target_file.write_text(body, encoding="utf-8")
    return True


# ---------------------------------------------------------------------------
# Core decision: given a state, pick the next action.
# ---------------------------------------------------------------------------


def compute_next_step(
    state: dict,
    target: Path,
    *,
    mode: str = "auto",
) -> dict:
    """Return the next action dict for ``sdlc auto-step`` / ``auto-mad-step``.

    Possible action values:
      - ``"invoke"`` — call the named agent
      - ``"stop"``  — block on user action
      - ``"done"``  — all phases complete
      - ``"auto_action"`` — only emitted in mode=='auto-mad'; tells the
        outer loop to apply the action (verify / signoff) and re-scan.
    """
    from sdlc_framework import engine

    pending = engine.find_next_pending(state)

    # Stop reason 1: open clarifications block all dispatch in BOTH modes.
    # Mad mode does NOT auto-resolve clarifications because they encode
    # product intent the agent cannot reliably infer.
    if pending["kind"] == "clarification":
        first = pending["first"]
        path = first.get("file") or first.get("title")
        return {
            "action": "stop",
            "stop_reason": "clarification",
            "phase": None,
            "item_id": None,
            "user_action": (
                f"Resolve the clarification at {path} (change `STATUS: open` "
                f"to `STATUS: resolved`), then re-run."
            ),
        }

    # Phase 3 special case: empty tasks. Same handling in both modes —
    # try inline bootstrap, fall back to tasks_empty stop.
    if pending["kind"] == "phase3_tasks_empty":
        story_file = target / "01-Planning" / "02-User-Stories.md"
        if not story_file.exists():
            return {
                "action": "stop",
                "stop_reason": "tasks_empty",
                "phase": 3,
                "item_id": None,
                "user_action": (
                    "Phase 3 has no tasks and we could not bootstrap "
                    "automatically (no 01-Planning/02-User-Stories.md). "
                    "Draft user stories then run `sdlc tasks bootstrap`."
                ),
            }
        from sdlc_framework.commands.tasks import cmd_tasks
        rc = cmd_tasks(["bootstrap"])
        if rc != 0:
            return {
                "action": "stop",
                "stop_reason": "tasks_empty",
                "phase": 3,
                "item_id": None,
                "user_action": (
                    "`sdlc tasks bootstrap` returned non-zero — likely no "
                    "`## Story:` headings parsed. Draft user stories then "
                    "re-run."
                ),
            }
        # Bootstrap succeeded — caller will re-scan and recurse.
        return {"action": "auto_action", "auto_kind": "rescan"}

    if pending["kind"] == "all_done":
        return {
            "action": "done",
            "stop_reason": None,
            "user_action": "All five phases complete. 🎉",
        }

    # pending["kind"] == "item": apply per-item stop conditions in
    # priority order (gate > high_risk > review_pending > drafted-not-
    # verified). The item is guaranteed to be the first undone item
    # walking phases in numeric order, so this preserves prior semantics.
    ph = pending["phase"]
    it = pending["item"]

    # Stop reason 2: gate.
    if it.get("gate"):
        gate_id = it["gate"]
        gate = next(
            (g for g in state.get("gates") or [] if g["id"] == gate_id),
            {},
        )
        if mode == "auto-mad":
            return {
                "action": "auto_action",
                "auto_kind": "signoff",
                "gate_id": gate_id,
                "gate_label": gate.get("label") or gate_id,
            }
        approvers = ", ".join(gate.get("approvers_required") or [])
        return {
            "action": "stop",
            "stop_reason": "gate",
            "phase": ph["id"],
            "item_id": it["id"],
            "item_label": it["label"],
            "user_action": (
                f"Approve gate `{gate_id}` by writing "
                f"`automation/signoffs/{gate_id}.yaml` with "
                f"`approved: true` (approvers: {approvers}). Then re-run."
            ),
        }

    # Stop reason 3: high-risk path. Kept in BOTH modes — auto-mad
    # is "human-only checkpoint bypass", not "policy-enforcement bypass".
    if _is_high_risk(it):
        return {
            "action": "stop",
            "stop_reason": "high_risk",
            "phase": ph["id"],
            "item_id": it["id"],
            "item_label": it["label"],
            "user_action": (
                f"`{it['id']}` touches a high-risk path "
                f"(auth/crypto/payment/secrets/migrations). Confirm "
                f"explicitly, then re-run."
            ),
        }

    # Stop reason 4: Phase 3 task at `await-merge` stage (PR open).
    # `auto`: hard-stop, waits for human merge.
    # `auto-mad`: parse code-reviewer verdict block; PASS+critical=0 → emit
    # squash_merge; otherwise stop with code_review_failed. Missing review
    # file → fall through to invoke code-reviewer agent (review can also
    # happen against an open PR when the local review step was skipped).
    if it.get("stage") == "await-merge":
        if mode == "auto-mad":
            from sdlc_framework.verdict import parse_verdict
            review_file = _latest_review_file(target, it["id"])
            if review_file is not None:
                v = parse_verdict(review_file.read_text())
                if v.is_pass and v.critical == 0:
                    return {
                        "action": "auto_action",
                        "auto_kind": "squash_merge",
                        "task_id": it["id"],
                        "pr_url": it.get("pr_url") or it.get("pr_branch"),
                    }
                return {
                    "action": "stop",
                    "stop_reason": "code_review_failed",
                    "phase": ph["id"],
                    "item_id": it["id"],
                    "item_label": it["label"],
                    "user_action": (
                        f"Review verdict={v.verdict} critical={v.critical}. "
                        f"Read {review_file.relative_to(target)}. Fix or "
                        f"force-merge with `sdlc tasks force-merge {it['id']} "
                        f"--i-accept-the-risk`."
                    ),
                }
            # No review file yet — fall through to invoke code-reviewer below.
        else:
            return {
                "action": "stop",
                "stop_reason": "review_pending",
                "phase": ph["id"],
                "item_id": it["id"],
                "item_label": it["label"],
                "stage": "await-merge",
                "user_action": (
                    f"Task `{it['id']}` has a PR open. Review and merge it, "
                    f"then re-run."
                ),
            }

    # Stop reason 5: Phase 1/2/4 artifact drafted but not verified.
    if it.get("drafted") and not it.get("verified") and not it.get("stage"):
        if mode == "auto-mad":
            return {
                "action": "auto_action",
                "auto_kind": "verify",
                "item_id": it["id"],
            }
        return {
            "action": "stop",
            "stop_reason": "verify_needed",
            "phase": ph["id"],
            "item_id": it["id"],
            "item_label": it["label"],
            "user_action": (
                f"Artifact `{it['id']}` is drafted but awaits your "
                f"verify. Review the file then run "
                f"`sdlc verify {it['id']}`. Then re-run."
            ),
        }

    # Mad-mode auto-action: code-reviewer's local review is in flight (or
    # done) and no PR is open yet → auto-open PR so the merge step can
    # follow on the next iteration. Stage `review` in the new scheme is
    # exactly the old `write-code` condition (both files exist, no PR).
    if mode == "auto-mad" and it.get("stage") == "review" \
            and not it.get("pr_url") and not it.get("pr_branch"):
        return {
            "action": "auto_action",
            "auto_kind": "open_pr",
            "task_id": it["id"],
        }

    # Otherwise: invoke the right subagent.
    agent = _resolve_agent(it, ph["id"], engine)
    stage = it.get("stage")
    item_id = it["id"]
    label = it.get("label") or item_id
    return {
        "action": "invoke",
        "agent": agent,
        "phase": ph["id"],
        "item_id": item_id,
        "item_label": label,
        "stage": stage,
        "stop_reason": None,
        "instruction": _build_instruction(agent, item_id, stage),
        "brief_context": _brief_context_for(state, agent, target),
    }


# ---------------------------------------------------------------------------
# Public CLI handlers
# ---------------------------------------------------------------------------


def _load_rules_or_stop(target: Path) -> tuple[dict | None, dict | None]:
    """Return (rules, error_action). On success, error_action is None."""
    rules_path = target / "automation" / "rules.json"
    if not rules_path.exists():
        return None, {
            "action": "stop",
            "stop_reason": "no_project",
            "user_action": "Run `sdlc setup` to scaffold the project first.",
        }
    return json.loads(rules_path.read_text()), None


def cmd_auto_step(argv: list[str]) -> int:
    """One step of the standard autopilot loop."""
    parser = argparse.ArgumentParser(prog="sdlc auto-step")
    parser.parse_args(argv)

    target = Path.cwd()
    rules, err = _load_rules_or_stop(target)
    if err is not None:
        print(json.dumps(err, indent=2, ensure_ascii=False))
        return 1
    from sdlc_framework import engine
    engine.set_root(target)
    state = engine.scan(rules)
    engine.write_state(state)
    out = compute_next_step(state, target, mode="auto")
    print(json.dumps(out, indent=2, ensure_ascii=False))
    return 0


# Defensive cap on auto-action iterations within a single auto-mad-step
# call. With this many, the user clearly forgot to advance work and is
# burning compute on signoffs / verifications alone.
MAD_AUTO_ACTION_CAP = 20


def cmd_auto_mad_step(argv: list[str]) -> int:
    """One step of the YOLO autopilot loop.

    Auto-resolves verify_needed and gate; everything else behaves like
    ``auto-step``. Each auto-resolution writes an ai-mad-mode-stamped
    file under ``automation/signoffs/`` or ``automation/.verifications.json``
    so the user can audit and revert.
    """
    parser = argparse.ArgumentParser(
        prog="sdlc auto-mad-step",
        description=(
            "MAD MODE — autopilot that auto-signs phase gates and "
            "auto-verifies drafted artifacts. Still stops on "
            "clarification, high_risk, review_pending. NOT for production."
        ),
    )
    parser.parse_args(argv)

    target = Path.cwd()
    rules, err = _load_rules_or_stop(target)
    if err is not None:
        print(json.dumps(err, indent=2, ensure_ascii=False))
        return 1

    from sdlc_framework import engine
    engine.set_root(target)

    auto_log: list[dict] = []
    iteration = 0
    while iteration < MAD_AUTO_ACTION_CAP:
        iteration += 1
        state = engine.scan(rules)
        engine.write_state(state)
        out = compute_next_step(state, target, mode="auto-mad")
        if out.get("action") != "auto_action":
            break
        kind = out.get("auto_kind")
        if kind == "verify":
            wrote = auto_verify_artifact(out["item_id"], target)
            if wrote:
                auto_log.append({
                    "kind": "verify",
                    "item_id": out["item_id"],
                    "at": _now_iso(),
                })
        elif kind == "signoff":
            wrote = auto_signoff_gate(
                out["gate_id"], out.get("gate_label", out["gate_id"]), target,
            )
            if wrote:
                auto_log.append({
                    "kind": "signoff",
                    "gate_id": out["gate_id"],
                    "at": _now_iso(),
                })
        elif kind in ("open_pr", "squash_merge"):
            result = _handle_auto_action(out, state, target)
            if result.get("stop_reason"):
                # Surface the failure as the outer stop and break.
                out = {
                    "action": "stop",
                    "stop_reason": result["stop_reason"],
                    "user_action": result["user_action"],
                    "phase": 3,
                    "item_id": out.get("task_id"),
                }
                break
            auto_log.append({
                "kind": kind,
                "task_id": out.get("task_id"),
                "pr_url": result.get("pr_url"),
                "at": _now_iso(),
            })
            # squash_merge cleared phase3.active_feature_id; persist.
            if kind == "squash_merge":
                engine.write_state(state)
        elif kind == "rescan":
            # Bootstrap or other side-effect already happened; just loop.
            pass
        else:  # pragma: no cover — defensive
            break
    else:
        # Hit the iteration cap — surface as an error stop.
        out = {
            "action": "stop",
            "stop_reason": "auto_mad_cap",
            "phase": None,
            "item_id": None,
            "user_action": (
                f"`auto-mad-step` hit its {MAD_AUTO_ACTION_CAP}-action "
                f"safety cap without producing real work. Inspect "
                f"`automation/signoffs/` and `automation/.verifications.json` "
                f"for ai-mad-mode entries, then re-run."
            ),
        }

    # Annotate the outgoing JSON with what was auto-handled this call so the
    # slash command can surface it to the user (audit trail).
    out["auto_actions_taken"] = auto_log
    print(json.dumps(out, indent=2, ensure_ascii=False))
    return 0


def cmd_next(argv: list[str]) -> int:
    """Print a paste-ready instruction for the next pending DoD item."""
    parser = argparse.ArgumentParser(prog="sdlc next")
    parser.add_argument("--json", action="store_true",
                        help="Machine-readable output.")
    args = parser.parse_args(argv)

    target = Path.cwd()
    rules_path = target / "automation" / "rules.json"
    if not rules_path.exists():
        print("[sdlc next] this directory doesn't look like an sdlc project. Run `sdlc init` first.")
        return 1

    # Refresh state.json + dashboard/state.json before reading. Without
    # this, callers stepping through with `sdlc next` between deliverables
    # leave the dashboard frozen at the last `sdlc scan` snapshot. Mirrors
    # what `sdlc auto-mad-step` already does.
    rules = json.loads(rules_path.read_text())
    from sdlc_framework import engine
    engine.set_root(target)
    state = engine.scan(rules)
    engine.write_state(state)

    # Re-use cli's _next_pending + role lookup helpers.
    from sdlc_framework.cli import _next_pending, _PHASE_AGENT, _PHASE_FILE
    pending = engine.find_next_pending(state)
    if pending["kind"] == "phase3_tasks_empty":
        print("⏸  Phase 3 has no tasks yet (setup is green but no task yamls exist).")
        print("    Draft 01-Planning/02-User-Stories.md then run `sdlc tasks bootstrap`,")
        print("    or `sdlc tasks new <id>` to create one manually.")
        return 0
    if pending["kind"] == "clarification":
        title = pending["first"].get("title") or pending["first"].get("file") or "?"
        print(f"✋ Blocked by open clarification: {title}")
        print("    Resolve it (set `STATUS: resolved`) then re-run.")
        return 0
    if pending["kind"] == "all_done":
        print("🎉  All DoD items are done. Nothing to dispatch.")
        return 0
    phase_id = pending["phase_id"]
    item = pending["item"]
    agent = (
        item.get("next_subagent")
        or item.get("agent")
        or _PHASE_AGENT.get(phase_id, "orchestrator")
    )
    role_file = f"agents/{_PHASE_FILE.get(phase_id, 'orchestrator.md')}"
    stage = item.get("stage")
    brief_context = _brief_context_for(state, agent, target)

    if args.json:
        out = {
            "phase": phase_id,
            "item_id": item["id"],
            "item_label": item["label"],
            "agent": agent,
            "role_file": role_file,
            "brief_context": brief_context,
        }
        if stage:
            out["stage"] = stage
        print(json.dumps(out, indent=2, ensure_ascii=False))
        return 0

    stage_suffix = f" (stage: {stage})" if stage else ""
    print(f"🎯 Next pending: phase {phase_id} · {item['id']} — {item['label']}{stage_suffix}")
    print()
    print("📋 Open this folder in your AI coding tool and paste:")
    print()
    print("─" * 64)
    print(f"Use the {agent} subagent. Read automation/rules.json item")
    print(f"`{item['id']}` and write the deliverable file that satisfies")
    print("its checks. Do not edit anything outside the deliverable for")
    print("this item. Stop and write a clarification file under")
    print("automation/clarifications/ if you hit ambiguity, conflict,")
    print("gate, or a high-risk path.")
    print("─" * 64)
    print()
    print(f"Role spec: {role_file}")
    print(f"Brief context preview: {brief_context[:120]!r}{'...' if len(brief_context) > 120 else ''}")
    return 0
