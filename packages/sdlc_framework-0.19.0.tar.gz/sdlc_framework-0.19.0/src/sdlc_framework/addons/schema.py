"""Recipe + Lockfile schemas, validation, and applies_to path enforcement.

Pure data layer — no I/O, no subprocess. Imported by every other addons
module so it must stay dependency-free (only stdlib).
"""
from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field
from pathlib import PurePosixPath
from typing import Any

PIN_TAG_RE = re.compile(r"^v?\d+\.\d+\.\d+(-[A-Za-z0-9.]+)?$")
PIN_SHA_RE = re.compile(r"^[0-9a-f]{40}$")
SLUG_RE = re.compile(r"^[a-z][a-z0-9-]{1,63}$")
SECTION_ID_RE = re.compile(r"^[a-z][a-z0-9-]{0,63}$")

VALID_INJECT_KINDS = {"doc-snippet", "agent-instruction", "remote-fetch"}

# Path prefixes per (phase, subtrack) slot. A target path is in-slot if it
# starts with any prefix. Cross-cutting addons declare {subtrack: cross}
# with no phase and bypass this table. See spec §4.2.
SLOT_PATH_PREFIXES: dict[tuple[int, str], tuple[str, ...]] = {
    (1, "planning"): ("01-Planning/",),
    # phase 2 architecture is "02-Design/ minus the UI-only carve-outs"; the
    # carve-out check happens below in `_path_in_slot` because pure prefix
    # matching cannot express "starts with X but not Y".
    (2, "architecture"): ("02-Design/",),
    (2, "ui-ux"): (
        "02-Design/templates/04-UI-UX-Spec.md",
        "02-Design/wireframes/",
        "02-Design/design-system/",
        "02-Design/assets/",
    ),
    (3, "setup"): (
        "03-Development/standards/",
        "03-Development/templates/",
        "agents/",
        ".mcp.json",
        # AI-tool surfaces at project root — each tool's settings live here
        ".claude/",
        ".cursor/",
        ".codex/",
        ".gemini/",
        ".aider/",
        ".cline/",
        ".continue/",
        ".windsurf/",
        # GitHub Copilot surfaces — explicit allowlist, NOT all of .github/.
        # We must NEVER let an addon write into .github/workflows/ since
        # CI configs are framework + project owner territory.
        ".github/copilot-instructions.md",
        ".github/instructions/",
        ".github/prompts/",
        ".github/agents/",
    ),
    (3, "tasks"): (
        "03-Development/skills/",
        "automation/tasks-templates/",
    ),
    (4, "e2e"): (
        "04-Testing-Deploy/test-plans/",
        "04-Testing-Deploy/e2e/",
    ),
    (5, "deploy"): (
        "04-Testing-Deploy/runbooks/",
        "04-Testing-Deploy/observability/",
        "workflows/",
        "infra/",
    ),
}


@dataclass(frozen=True)
class AppliesTo:
    """Phase + subtrack slot. ``phase=None`` only when ``subtrack='cross'``."""
    phase: int | None
    subtrack: str

    @classmethod
    def from_dict(cls, d: dict, *, where: str) -> "AppliesTo":
        if not isinstance(d, dict):
            raise SchemaError(f"{where}: must be a mapping {{phase, subtrack}}")
        sub = d.get("subtrack")
        if not isinstance(sub, str):
            raise SchemaError(f"{where}: subtrack must be a string")
        if sub == "cross":
            return cls(phase=None, subtrack="cross")
        ph = d.get("phase")
        if ph not in (1, 2, 3, 4, 5):
            raise SchemaError(f"{where}: phase must be 1..5 (got {ph!r})")
        valid = {
            1: {"planning"},
            2: {"architecture", "ui-ux"},
            3: {"setup", "tasks"},
            4: {"e2e"},
            5: {"deploy"},
        }[ph]
        if sub not in valid:
            raise SchemaError(
                f"{where}: subtrack {sub!r} not valid for phase {ph} "
                f"(valid: {sorted(valid)})"
            )
        return cls(phase=ph, subtrack=sub)


@dataclass(frozen=True)
class DocSnippet:
    target: str
    section_id: str
    content: str
    kind: str = "doc-snippet"


@dataclass(frozen=True)
class AgentInstruction:
    target: str
    section_id: str
    content: str
    kind: str = "agent-instruction"


@dataclass(frozen=True)
class SelectEntry:
    from_pat: str   # YAML "from"
    to: str


@dataclass(frozen=True)
class RemoteFetch:
    from_url: str           # YAML "from"
    pin: str
    select: tuple[SelectEntry, ...]
    confirm: bool = True
    kind: str = "remote-fetch"


Inject = DocSnippet | AgentInstruction | RemoteFetch


@dataclass(frozen=True)
class Recipe:
    id: str
    name: str
    description: str
    schema_version: int
    homepage: str
    license: str
    applies_to: tuple[AppliesTo, ...]
    injects: tuple[Inject, ...]
    # Optional tool gating: when non-empty, the recipe is only relevant to
    # users whose ``sdlc setup`` selected at least one of these tools.
    # ``()`` means "tool-agnostic — always offered".
    requires_ai_tool: tuple[str, ...] = ()


class SchemaError(ValueError):
    """Recipe or lockfile failed schema validation."""


# ---------------------------------------------------------------------------
# Recipe parsing
# ---------------------------------------------------------------------------

def parse_recipe(data: dict, *, source: str = "<recipe>") -> Recipe:
    """Validate a parsed YAML mapping and return a frozen Recipe.

    ``source`` is the file path or label used in error messages so users
    can locate the bad recipe quickly.
    """
    if not isinstance(data, dict):
        raise SchemaError(f"{source}: top-level must be a mapping")

    rid = data.get("id")
    if not isinstance(rid, str) or not SLUG_RE.match(rid):
        raise SchemaError(
            f"{source}: id must match {SLUG_RE.pattern} (got {rid!r})"
        )
    name = _required_str(data, "name", source)
    desc = _required_str(data, "description", source)
    sv = data.get("schema_version")
    if sv != 1:
        raise SchemaError(f"{source}: schema_version must be 1 (got {sv!r})")
    homepage = _required_str(data, "homepage", source)
    if not (homepage.startswith("https://") or homepage.startswith("http://")):
        raise SchemaError(f"{source}: homepage must be an http(s) URL")
    license_ = _required_str(data, "license", source)

    raw_applies = data.get("applies_to")
    if not isinstance(raw_applies, list) or not raw_applies:
        raise SchemaError(f"{source}: applies_to must be a non-empty list")
    applies = tuple(
        AppliesTo.from_dict(e, where=f"{source}.applies_to[{i}]")
        for i, e in enumerate(raw_applies)
    )

    raw_injects = data.get("injects")
    if not isinstance(raw_injects, list) or not raw_injects:
        raise SchemaError(f"{source}: injects must be a non-empty list")
    injects = tuple(
        _parse_inject(e, where=f"{source}.injects[{i}]")
        for i, e in enumerate(raw_injects)
    )

    raw_tools = data.get("requires_ai_tool", []) or []
    if not isinstance(raw_tools, list):
        raise SchemaError(f"{source}: requires_ai_tool must be a list of strings")
    for t in raw_tools:
        if not isinstance(t, str) or not SLUG_RE.match(t):
            raise SchemaError(
                f"{source}: requires_ai_tool entries must be slugs (got {t!r})"
            )

    recipe = Recipe(
        id=rid, name=name, description=desc, schema_version=sv,
        homepage=homepage, license=license_,
        applies_to=applies, injects=injects,
        requires_ai_tool=tuple(raw_tools),
    )
    _validate_inject_targets_in_slot(recipe, source=source)
    _validate_no_duplicate_dest(recipe, source=source)
    return recipe


def _required_str(data: dict, key: str, source: str) -> str:
    v = data.get(key)
    if not isinstance(v, str) or not v.strip():
        raise SchemaError(f"{source}: {key} must be a non-empty string")
    return v


def _parse_inject(d: Any, *, where: str) -> Inject:
    if not isinstance(d, dict):
        raise SchemaError(f"{where}: must be a mapping")
    kind = d.get("kind")
    if kind not in VALID_INJECT_KINDS:
        raise SchemaError(
            f"{where}: kind must be one of {sorted(VALID_INJECT_KINDS)} "
            f"(got {kind!r})"
        )
    if kind in ("doc-snippet", "agent-instruction"):
        target = _required_str(d, "target", where)
        sid = _required_str(d, "section_id", where)
        if not SECTION_ID_RE.match(sid):
            raise SchemaError(
                f"{where}: section_id must match {SECTION_ID_RE.pattern}"
            )
        content = _required_str(d, "content", where)
        _check_safe_relative(target, where=f"{where}.target")
        if kind == "agent-instruction" and not target.startswith("agents/"):
            raise SchemaError(
                f"{where}: agent-instruction target must be under agents/"
            )
        cls = DocSnippet if kind == "doc-snippet" else AgentInstruction
        return cls(target=target, section_id=sid, content=content)

    # remote-fetch
    from_url = _required_str(d, "from", where)
    if not (from_url.startswith("https://") or from_url.startswith("http://")):
        raise SchemaError(f"{where}.from: must be an http(s) URL")
    pin = _required_str(d, "pin", where)
    if not (PIN_TAG_RE.match(pin) or PIN_SHA_RE.match(pin)):
        raise SchemaError(
            f"{where}.pin: must be a semver tag (e.g. v1.2.0) or a 40-char SHA "
            f"(got {pin!r}); branches/HEAD/short-SHAs are forbidden"
        )
    raw_select = d.get("select")
    if not isinstance(raw_select, list) or not raw_select:
        raise SchemaError(f"{where}.select: must be a non-empty list")
    select_entries: list[SelectEntry] = []
    for i, e in enumerate(raw_select):
        if not isinstance(e, dict):
            raise SchemaError(f"{where}.select[{i}]: must be a mapping")
        f = _required_str(e, "from", f"{where}.select[{i}]")
        t = _required_str(e, "to", f"{where}.select[{i}]")
        _check_safe_relative(t, where=f"{where}.select[{i}].to")
        select_entries.append(SelectEntry(from_pat=f, to=t))
    confirm = d.get("confirm", True)
    if confirm is not True:
        raise SchemaError(
            f"{where}.confirm: must be true in MVP (silent fetch is post-MVP)"
        )
    return RemoteFetch(
        from_url=from_url, pin=pin, select=tuple(select_entries),
        confirm=True,
    )


def _check_safe_relative(p: str, *, where: str) -> None:
    """Ensure path is project-relative and does not escape via ``..``."""
    if not p:
        raise SchemaError(f"{where}: empty path")
    if p.startswith("/"):
        raise SchemaError(f"{where}: must be project-relative (no leading /)")
    parts = PurePosixPath(p).parts
    if any(part == ".." for part in parts):
        raise SchemaError(f"{where}: must not contain '..' segments")


def _validate_inject_targets_in_slot(recipe: Recipe, *, source: str) -> None:
    """Every inject's target/to MUST land inside one of recipe.applies_to."""
    has_cross = any(a.subtrack == "cross" for a in recipe.applies_to)
    for i, inj in enumerate(recipe.injects):
        paths = _inject_dest_paths(inj)
        for path in paths:
            if has_cross:
                continue
            if not _path_in_any_slot(path, recipe.applies_to):
                raise SchemaError(
                    f"{source}.injects[{i}]: target/to {path!r} is outside "
                    f"applies_to slots "
                    f"({[(a.phase, a.subtrack) for a in recipe.applies_to]})"
                )


def _validate_no_duplicate_dest(recipe: Recipe, *, source: str) -> None:
    """Two select entries within the same recipe cannot map to the same dest dir."""
    seen: dict[str, int] = {}
    for i, inj in enumerate(recipe.injects):
        if isinstance(inj, RemoteFetch):
            for j, e in enumerate(inj.select):
                key = e.to.rstrip("/") + "/"
                if key in seen:
                    raise SchemaError(
                        f"{source}.injects[{i}].select[{j}]: dest {e.to!r} "
                        f"duplicates injects[{seen[key]}]"
                    )
                seen[key] = i


def _inject_dest_paths(inj: Inject) -> list[str]:
    if isinstance(inj, (DocSnippet, AgentInstruction)):
        return [inj.target]
    if isinstance(inj, RemoteFetch):
        return [e.to for e in inj.select]
    return []


def _path_in_any_slot(path: str, applies: tuple[AppliesTo, ...]) -> bool:
    norm = path.rstrip("/")
    for a in applies:
        if a.phase is None:
            continue  # cross handled by caller
        # Phase 2 architecture is a carve-out: "starts with 02-Design/ but NOT
        # under any ui-ux slot path". Plain prefix match would let architecture
        # claim wireframes/, design-system/, assets/ which belong to ui-ux.
        if a.phase == 2 and a.subtrack == "architecture":
            if norm.startswith("02-Design/") and not _matches_phase2_uiux(norm):
                return True
            continue
        prefixes = SLOT_PATH_PREFIXES.get((a.phase, a.subtrack), ())
        for pref in prefixes:
            pref_norm = pref.rstrip("/")
            if norm == pref_norm:
                return True
            if pref.endswith("/") and (norm + "/").startswith(pref):
                return True
    return False


def _matches_phase2_uiux(norm_path: str) -> bool:
    for pref in SLOT_PATH_PREFIXES[(2, "ui-ux")]:
        pref_norm = pref.rstrip("/")
        if norm_path == pref_norm:
            return True
        if pref.endswith("/") and (norm_path + "/").startswith(pref):
            return True
    return False


# ---------------------------------------------------------------------------
# Marker helpers (used by injector + lockfile drift detection)
# ---------------------------------------------------------------------------

def short_hash(content: str) -> str:
    """4-hex truncated SHA-1 of content. Used in markers + lockfile."""
    return hashlib.sha1(content.encode("utf-8")).hexdigest()[:4]


def marker_start(addon_id: str, section_id: str, content_hash: str) -> str:
    return f"<!-- sdlc:addon:{addon_id}#{section_id}:start {content_hash} -->"


def marker_end(addon_id: str, section_id: str) -> str:
    return f"<!-- sdlc:addon:{addon_id}#{section_id}:end -->"


MARKER_START_RE = re.compile(
    r"<!--\s*sdlc:addon:(?P<id>[a-z][a-z0-9-]+)#(?P<sid>[a-z][a-z0-9-]*)"
    r":start\s+(?P<hash>[0-9a-f]{4})\s*-->"
)
MARKER_END_RE_TMPL = r"<!--\s*sdlc:addon:{id}#{sid}:end\s*-->"
