"""Detect collisions between an addon's planned writes and existing state.

Three collision categories (per spec §7.2):

  1. Framework-reserved — path is owned by the framework scaffold;
     installing would shadow a known framework command/agent/skill.
     Always reject (exit 5).
  2. Other-addon owned — path already in addons.lock under a different
     addon. Always reject (exit 5).
  3. User-file conflict — path exists on disk but isn't tracked by any
     addon. Warn + prompt (or skip in --yes, overwrite in --yes --force).

Reserved paths are auto-discovered by walking ``scaffold/`` once per
process — no hand-maintained list to drift out of sync. Snippet
collisions use ``(target, section_id)`` so two addons can target the
same file at different sections.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path

from .lockfile import Lockfile


# Top-level dirs / files where addon-installable surfaces live. Files
# under these (in scaffold/) are framework-owned and cannot be shadowed.
_RESERVED_TOP_DIRS = (".claude", ".cursor", "agents")
_RESERVED_GITHUB_PATHS = (
    ".github/copilot-instructions.md",
    ".github/prompts",
    ".github/instructions",
    ".github/agents",
)


@dataclass(frozen=True)
class CollisionReport:
    """Categorized collisions for one addon's planned writes."""
    addon_id: str
    framework_reserved: list[str] = field(default_factory=list)
    other_addon: list[tuple[str, str]] = field(default_factory=list)   # (path, owner_id)
    user_files: list[str] = field(default_factory=list)

    @property
    def has_blocking(self) -> bool:
        """Type 1 or Type 2 — must reject install."""
        return bool(self.framework_reserved) or bool(self.other_addon)

    @property
    def has_warnings(self) -> bool:
        """Type 3 — warn + prompt user."""
        return bool(self.user_files)


def framework_reserved_paths() -> set[str]:
    """Return the set of project-relative paths owned by the framework
    scaffold. Cached at module level — scaffold/ is read-only for the
    process lifetime."""
    return _scan_reserved()


@lru_cache(maxsize=1)
def _scan_reserved() -> frozenset[str]:
    scaffold = _scaffold_dir()
    if not scaffold.is_dir():
        return frozenset()
    out: set[str] = set()
    for path in scaffold.rglob("*"):
        if not path.is_file():
            continue
        rel = path.relative_to(scaffold)
        rel_str = str(rel).replace("\\", "/")
        if _is_reserved_path(rel_str):
            out.add(rel_str)
    return frozenset(out)


def _scaffold_dir() -> Path:
    here = Path(__file__).resolve().parent.parent
    return here / "scaffold"


def _is_reserved_path(rel: str) -> bool:
    if rel.startswith(("addons/",)):
        return False                              # recipes, not installable
    parts = rel.split("/", 1)
    if parts[0] in _RESERVED_TOP_DIRS:
        return True
    if rel == ".github/copilot-instructions.md":
        return True
    if any(rel.startswith(p + "/") for p in _RESERVED_GITHUB_PATHS):
        return True
    return False


def installed_path_owners(lock: Lockfile) -> dict[str, str]:
    """Return ``{path: addon_id}`` for every installed snippet target +
    fetched file across all addons. Used to detect Type 2 collisions in
    O(1) lookup."""
    owners: dict[str, str] = {}
    for aid, entry in lock.addons.items():
        for s in entry.snippets:
            # Snippets keyed by (target, section_id) for collision purposes
            # (different sections in same file don't collide). Encode the
            # composite key for the dict to keep lookup uniform.
            owners[_snippet_key(s.target, s.section_id)] = aid
        if entry.fetched:
            for f in entry.fetched.files:
                owners[f] = aid
    return owners


def _snippet_key(target: str, section_id: str) -> str:
    return f"{target}#{section_id}"


def check_collisions(
    addon_id: str,
    *,
    planned_files: list[str],                     # remote-fetch destinations
    planned_snippets: list[tuple[str, str]],      # (target, section_id) pairs
    reserved: set[str],
    owners: dict[str, str],
    project_root: Path,
) -> CollisionReport:
    """Categorize the addon's planned writes. Pure function — no I/O
    beyond ``Path.exists`` checks for Type 3."""
    framework_reserved: list[str] = []
    other_addon: list[tuple[str, str]] = []
    user_files: list[str] = []

    for f in planned_files:
        norm = f.replace("\\", "/")
        if norm in reserved:
            framework_reserved.append(norm)
            continue
        owner = owners.get(norm)
        if owner is not None and owner != addon_id:
            other_addon.append((norm, owner))
            continue
        if owner is None and (project_root / norm).exists():
            user_files.append(norm)

    for target, section_id in planned_snippets:
        key = _snippet_key(target, section_id)
        owner = owners.get(key)
        if owner is not None and owner != addon_id:
            other_addon.append((key, owner))

    return CollisionReport(
        addon_id=addon_id,
        framework_reserved=framework_reserved,
        other_addon=other_addon,
        user_files=user_files,
    )


def render_collision_report(report: CollisionReport) -> str:
    """Multi-line human-readable report for stderr printing."""
    lines = [f"[sdlc addons] BLOCKED: collision check failed for {report.addon_id}"]
    if report.framework_reserved:
        lines.append("\n  Framework-reserved (cannot install):")
        for p in report.framework_reserved:
            lines.append(f"    {p} → owned by framework scaffold")
    if report.other_addon:
        lines.append("\n  Owned by other addons:")
        for p, owner in report.other_addon:
            lines.append(f"    {p} → already installed by {owner}")
    lines.append("")
    lines.append("Suggested fixes:")
    lines.append("  - Recipe author: rename the conflicting paths to addon-prefixed")
    lines.append("    names (e.g. `.claude/commands/<addon-id>-<name>.md`).")
    lines.append("  - User: remove the conflicting addon first")
    lines.append("    (`sdlc addons remove <id>`) then try again.")
    lines.append("\nNothing was installed.")
    return "\n".join(lines)
