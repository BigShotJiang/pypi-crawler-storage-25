"""Single source of truth for the package version. Consumed by hatchling."""

__version__ = "1.2.0"
