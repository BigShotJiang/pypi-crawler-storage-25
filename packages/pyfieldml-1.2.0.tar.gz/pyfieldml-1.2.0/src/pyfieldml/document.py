"""Document — the user-facing FieldML document wrapper."""

from __future__ import annotations

from collections.abc import Mapping
from pathlib import Path
from typing import TYPE_CHECKING, Any

from lxml import etree

from pyfieldml.dom.parser import ParsedDocument, parse_file, parse_string
from pyfieldml.dom.validator import validate_tree
from pyfieldml.dom.writer import write_file
from pyfieldml.errors import FieldMLParseError
from pyfieldml.model._loader import load_document
from pyfieldml.model.evaluators import Evaluator
from pyfieldml.model.region import Region
from pyfieldml.model.types import (
    BooleanType,
    ContinuousType,
    EnsembleType,
    MeshType,
)

if TYPE_CHECKING:
    import meshio

    from pyfieldml.eval.field import Field

PathLike = str | Path


class Document:
    """An in-memory FieldML document.

    Holds a single primary ``Region`` (the first one in the document) plus
    the original DOM tree for round-trip writing.
    """

    def __init__(self, parsed: ParsedDocument, region: Region) -> None:
        self._parsed = parsed
        self._region = region

    @classmethod
    def from_file(cls, path: PathLike) -> Document:
        """Read a FieldML document from an on-disk file."""
        parsed = parse_file(path)
        region = load_document(Path(path))
        return cls(parsed, region)

    @classmethod
    def from_string(cls, content: str | bytes) -> Document:
        """Read a FieldML document from an in-memory string/bytes.

        External data-resource hrefs (HDF5, plain-text) are resolved relative
        to the current working directory since no source path is available.
        """
        # Local import to avoid a module-level cycle through pyfieldml.model._loader.
        from pyfieldml.model._loader import _load_region

        parsed = parse_string(content)
        regions = parsed.tree.getroot().findall("Region")
        if not regions:
            raise FieldMLParseError("No <Region> in document")
        region = _load_region(regions[0], base_dir=Path.cwd())
        return cls(parsed, region)

    @classmethod
    def from_region(cls, region: Region) -> Document:
        """Build a Document from a programmatically-constructed Region."""
        from pyfieldml.dom.parser import ParsedDocument
        from pyfieldml.model._writer import region_to_tree

        tree = region_to_tree(region)
        parsed = ParsedDocument(tree=tree, version="0.5.0", source_file=None)
        return cls(parsed, region)

    @property
    def source_version(self) -> str:
        """FieldML version declared on the root element (``@version``)."""
        return self._parsed.version

    @property
    def tree(self) -> etree._ElementTree:
        """Underlying lxml ElementTree. Escape hatch; prefer semantic APIs."""
        return self._parsed.tree

    @property
    def region(self) -> Region:
        """The document's primary (first) region."""
        return self._region

    @property
    def booleans(self) -> Mapping[str, BooleanType]:
        return self._region.booleans

    @property
    def ensembles(self) -> Mapping[str, EnsembleType]:
        return self._region.ensembles

    @property
    def continuous(self) -> Mapping[str, ContinuousType]:
        return self._region.continuous

    @property
    def meshes(self) -> Mapping[str, MeshType]:
        return self._region.meshes

    @property
    def evaluators(self) -> Mapping[str, Evaluator]:
        return self._region.evaluators

    def field(self, name: str) -> Field:
        """Return a Field wrapper for the evaluator named ``name``.

        Phase-2: requires the graph convention produced by ``add_lagrange_mesh``.
        """
        from pyfieldml.eval.field import resolve_field

        return resolve_field(self.region, name=name)

    def write(self, path: PathLike) -> None:
        """Phase-1 write path: re-serializes the DOM tree we parsed from."""
        write_file(self._parsed.tree, path)

    def validate(self) -> None:
        """Validate the document against the bundled FieldML 0.5 XSD."""
        validate_tree(self._parsed.tree)

    def to_meshio(self) -> meshio.Mesh:
        """Convert this Document to a meshio.Mesh. Requires pyfieldml[meshio]."""
        try:
            from pyfieldml.interop.meshio import to_meshio
        except ImportError as exc:
            raise ImportError(
                "to_meshio() requires the [meshio] extra: pip install pyfieldml[meshio]"
            ) from exc
        return to_meshio(self)

    @classmethod
    def from_meshio(cls, mesh: meshio.Mesh, *, name: str = "imported") -> Document:
        """Convert a meshio.Mesh to a Document. Requires pyfieldml[meshio]."""
        try:
            from pyfieldml.interop.meshio import from_meshio
        except ImportError as exc:
            raise ImportError(
                "from_meshio() requires the [meshio] extra: pip install pyfieldml[meshio]"
            ) from exc
        doc: Document = from_meshio(mesh, name=name)
        return doc

    def plot(self, **kwargs: Any) -> Any:
        """Render this Document via PyVista. Requires pyfieldml[viz]."""
        try:
            from pyfieldml.interop.pyvista import plot_doc
        except ImportError as exc:
            raise ImportError(
                "doc.plot() requires the [viz] extra: pip install pyfieldml[viz]"
            ) from exc
        return plot_doc(self, **kwargs)

    def explore(self) -> Any:
        """Open an interactive Jupyter widget to browse the evaluator graph.

        Requires the [viz] extra: ``pip install pyfieldml[viz]``.
        """
        try:
            from pyfieldml.viz.explorer import explore
        except ImportError as exc:
            raise ImportError(
                "doc.explore() requires the [viz] extra: pip install pyfieldml[viz]"
            ) from exc
        return explore(self)
