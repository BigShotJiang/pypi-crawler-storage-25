"""OpenSees CLI — run structural simulations in the cloud."""

__version__ = "0.1.0a8"
