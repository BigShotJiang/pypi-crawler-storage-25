"""Local credential storage.

Credentials are stored in ~/.opensees/credentials.json.
"""

import json
from pathlib import Path
from typing import Any, Dict, Optional

CONFIG_DIR = Path.home() / ".opensees"
CREDENTIALS_FILE = CONFIG_DIR / "credentials.json"

# Default API base URL — baked into the release.
# Override for development: set OPENSEES_API_URL env var.
DEFAULT_API_URL = "https://qjnct7etj7.execute-api.us-west-2.amazonaws.com/prod"


def _ensure_dir() -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    # Restrict permissions on the directory
    CONFIG_DIR.chmod(0o700)


# ---------------------------------------------------------------------------
# Credentials (tokens)
# ---------------------------------------------------------------------------

def save_credentials(
    access_token: str,
    refresh_token: str,
    id_token: Optional[str] = None,
    email: Optional[str] = None,
    is_admin: bool = False,
) -> None:
    _ensure_dir()
    data = {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "id_token": id_token,
        "email": email,
        "is_admin": is_admin,
    }
    CREDENTIALS_FILE.write_text(json.dumps(data, indent=2))
    CREDENTIALS_FILE.chmod(0o600)


def is_admin() -> bool:
    creds = load_credentials()
    return bool(creds and creds.get("is_admin"))


def load_credentials() -> Optional[Dict[str, Any]]:
    if not CREDENTIALS_FILE.exists():
        return None
    try:
        return json.loads(CREDENTIALS_FILE.read_text())
    except (json.JSONDecodeError, OSError):
        return None


def clear_credentials() -> None:
    if CREDENTIALS_FILE.exists():
        CREDENTIALS_FILE.unlink()


def get_access_token() -> Optional[str]:
    creds = load_credentials()
    return creds.get("access_token") if creds else None


def get_refresh_token() -> Optional[str]:
    creds = load_credentials()
    return creds.get("refresh_token") if creds else None


def get_api_url() -> str:
    import os
    return os.environ.get("OPENSEES_API_URL") or DEFAULT_API_URL
