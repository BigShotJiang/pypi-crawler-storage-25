"""First-run PATH check and auto-fix.

After ``pip install opensees_cli`` the ``ops`` / ``opensees`` console-scripts
are placed in a platform-specific *scripts* directory that may not be on the
user's PATH.  This module detects the situation on first run, prompts the
user, and—if they agree—appends the directory to the appropriate shell
profile so future terminal sessions find the commands automatically.

State is tracked via a marker file (``~/.opensees/path_fixed``) so the
prompt only appears once.
"""

from __future__ import annotations

import os
import platform
import sysconfig
import sys
from pathlib import Path

from rich.console import Console

from opensees_cli.config import CONFIG_DIR

_MARKER = CONFIG_DIR / "path_fixed"
_console = Console(stderr=True)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def ensure_path(*, force: bool = False) -> None:
    """Check whether the scripts directory is on PATH; offer to fix it.

    With ``force=True`` (e.g. ``python -m opensees_cli set_path``), ignore the
    one-time marker and always show the interactive prompt when possible.
    """
    if not force and _MARKER.exists():
        return

    scripts_dir = _scripts_dir()
    if scripts_dir is None:
        if force:
            _console.print(
                "[red]Could not find the directory containing the "
                "[bold]ops[/bold] launcher.[/red]"
            )
            raise SystemExit(1)
        return

    if not force and _is_on_path(scripts_dir):
        _write_marker()
        return

    if _prompt_and_fix(scripts_dir, force=force):
        _write_marker()


# ---------------------------------------------------------------------------
# Internals
# ---------------------------------------------------------------------------

def _scripts_dir() -> str | None:
    """Return the directory where pip installed console-scripts for *this* install.

    On Windows, ``pip install --user`` puts ``ops.exe`` under the *user* scripts
    directory, while the default ``sysconfig`` scheme often points at the
    global ``Scripts`` folder. We prefer the directory that actually contains
    ``ops`` / ``ops.exe``.
    """
    candidates: list[Path] = []
    scheme_names: list[str | None] = [None]
    if os.name == "nt":
        scheme_names.extend(["nt_user", "nt"])
    else:
        scheme_names.extend([f"{os.name}_user", "posix_user"])

    for scheme in scheme_names:
        try:
            d = (
                sysconfig.get_path("scripts")
                if scheme is None
                else sysconfig.get_path("scripts", scheme)
            )
        except KeyError:
            continue
        if d:
            p = Path(d).resolve()
            if p.is_dir() and p not in candidates:
                candidates.append(p)

    if sys.executable:
        py_parent = Path(sys.executable).resolve().parent
        if os.name == "nt":
            extra = py_parent / "Scripts"
            if extra.is_dir():
                er = extra.resolve()
                if er not in candidates:
                    candidates.append(er)
        elif py_parent.name == "bin" and py_parent.is_dir():
            # e.g. venv/bin/python — console scripts live in the same bin/
            er = py_parent.resolve()
            if er not in candidates:
                candidates.append(er)

    def _has_ops(p: Path) -> bool:
        return any(
            (p / name).exists()
            for name in ("ops.exe", "ops.cmd", "ops", "opensees.exe", "opensees.cmd")
        )

    for p in candidates:
        if _has_ops(p):
            return str(p)

    if candidates:
        return str(candidates[0])
    return None


def _paths_equal(a: Path, b: Path) -> bool:
    if os.name == "nt":
        return os.path.normcase(a.resolve()) == os.path.normcase(b.resolve())
    return a.resolve() == b.resolve()


def _is_on_path(directory: str) -> bool:
    dirs = os.environ.get("PATH", "").split(os.pathsep)
    target = Path(directory).resolve()
    return any(_paths_equal(Path(d).resolve(), target) for d in dirs if d)


def _write_marker() -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    _MARKER.touch()


def _prompt_and_fix(scripts_dir: str, *, force: bool = False) -> bool:
    """Offer to add *scripts_dir* to PATH. Return True if we should record completion.

    Returns False when stdin was unavailable (e.g. non-interactive) so the user
    can be prompted again on a later interactive run.
    """
    on_path = _is_on_path(scripts_dir)
    if force and on_path:
        _console.print(
            f"\n[yellow]The [bold]ops[/bold] launcher directory is "
            f"[bold]{scripts_dir}[/bold]. It is already on PATH in this "
            "session; you can still add it to your user PATH / shell profile "
            "below.[/yellow]"
        )
    elif not on_path:
        _console.print(
            f"\n[yellow]The [bold]ops[/bold] command was installed to "
            f"[bold]{scripts_dir}[/bold] which is not on your PATH.[/yellow]"
        )

    prompt = (
        "Add to your user PATH / shell profile now? [Y/n] "
        if force
        else "Add it now? [Y/n] "
    )
    try:
        answer = _console.input(f"[bold]{prompt}[/bold]").strip().lower()
    except (EOFError, KeyboardInterrupt):
        _console.print()
        _console.print(
            "[dim]No change. Run [bold]python -m opensees_cli set_path[/bold] in this "
            "window to try again, or add the folder above to your PATH manually.[/dim]"
        )
        return False

    if answer and answer not in ("y", "yes"):
        if force:
            _console.print(
                "[dim]Skipped. Run [bold]python -m opensees_cli set_path[/bold] "
                "anytime to see this prompt again, or add the folder to your PATH "
                "manually.[/dim]"
            )
        else:
            _console.print(
                "[dim]Skipped. Add [bold]"
                f"{scripts_dir}[/bold] to your PATH to run [bold]ops[/bold] from any "
                "terminal. To see this prompt again, delete "
                f"[bold]{_MARKER}[/bold] and run [bold]python -m opensees_cli[/bold].[/dim]"
            )
        return True

    system = platform.system()
    if system == "Windows":
        _fix_windows(scripts_dir)
    else:
        _fix_unix(scripts_dir)
    return True


# ---------------------------------------------------------------------------
# Unix (macOS / Linux)
# ---------------------------------------------------------------------------

_BANNER = "# Added by opensees_cli"


def _fix_unix(scripts_dir: str) -> None:
    profile = _choose_unix_profile()
    if profile is None:
        _console.print(
            "[red]Could not determine your shell profile. "
            f"Please add the following line manually:[/red]\n"
            f'  export PATH="{scripts_dir}:$PATH"'
        )
        return

    export_line = f'export PATH="{scripts_dir}:$PATH"'
    block = f"\n{_BANNER}\n{export_line}\n"

    # Don't duplicate if the line is already in the file.
    if profile.exists() and export_line in profile.read_text():
        _console.print(
            f"[dim]PATH entry already present in {profile} — skipping.[/dim]"
        )
        return

    shell_name = _current_shell_name()
    if shell_name == "fish":
        _fix_fish(scripts_dir)
        return

    with profile.open("a") as f:
        f.write(block)

    _console.print(
        f"\n[green]Done![/green] Added to [bold]{profile}[/bold].\n"
        f"Restart your terminal or run:  [bold]source {profile}[/bold]"
    )


def _current_shell_name() -> str:
    shell = os.environ.get("SHELL", "")
    return Path(shell).name if shell else ""


def _choose_unix_profile() -> Path | None:
    shell = _current_shell_name()
    home = Path.home()

    if shell == "fish":
        cfg = Path(os.environ.get("XDG_CONFIG_HOME", home / ".config"))
        return cfg / "fish" / "config.fish"

    if shell == "zsh":
        return home / ".zshrc"

    if platform.system() == "Darwin":
        # macOS default shell is zsh since Catalina.
        zshrc = home / ".zshrc"
        if zshrc.exists():
            return zshrc
        bash_profile = home / ".bash_profile"
        if bash_profile.exists():
            return bash_profile
        return zshrc  # create .zshrc if nothing exists yet

    # Linux with bash (or unknown shell)
    bashrc = home / ".bashrc"
    if bashrc.exists():
        return bashrc
    profile = home / ".profile"
    if profile.exists():
        return profile
    return bashrc


def _fix_fish(scripts_dir: str) -> None:
    cfg = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config"))
    config_fish = cfg / "fish" / "config.fish"
    line = f"fish_add_path {scripts_dir}"

    if config_fish.exists() and line in config_fish.read_text():
        _console.print(
            f"[dim]PATH entry already present in {config_fish} — skipping.[/dim]"
        )
        return

    config_fish.parent.mkdir(parents=True, exist_ok=True)
    with config_fish.open("a") as f:
        f.write(f"\n{_BANNER}\n{line}\n")

    _console.print(
        f"\n[green]Done![/green] Added to [bold]{config_fish}[/bold].\n"
        "Restart your terminal for the change to take effect."
    )


# ---------------------------------------------------------------------------
# Windows
# ---------------------------------------------------------------------------

def _fix_windows(scripts_dir: str) -> None:
    try:
        import winreg  # type: ignore[import-not-found]
    except ImportError:
        _console.print(
            "[red]Cannot modify the Windows registry on this platform.[/red]\n"
            f"Please add [bold]{scripts_dir}[/bold] to your PATH manually."
        )
        return

    key = winreg.OpenKey(
        winreg.HKEY_CURRENT_USER,
        r"Environment",
        0,
        winreg.KEY_READ | winreg.KEY_WRITE,
    )
    try:
        current, _ = winreg.QueryValueEx(key, "Path")
    except FileNotFoundError:
        current = ""

    entries = [e for e in current.split(";") if e]
    target = str(Path(scripts_dir).resolve())

    if any(_paths_equal(Path(e).resolve(), Path(target)) for e in entries if e):
        _console.print("[dim]PATH entry already present — skipping.[/dim]")
        winreg.CloseKey(key)
        return

    entries.append(target)
    winreg.SetValueEx(key, "Path", 0, winreg.REG_EXPAND_SZ, ";".join(entries))
    winreg.CloseKey(key)

    _broadcast_setting_change()

    _console.print(
        f"\n[green]Done![/green] Added [bold]{scripts_dir}[/bold] to your user PATH.\n"
        "Open a new terminal for the change to take effect."
    )


def _broadcast_setting_change() -> None:
    """Tell Windows to re-read environment variables without a reboot."""
    if sys.platform != "win32":
        return
    try:
        import ctypes
        HWND_BROADCAST = 0xFFFF
        WM_SETTINGCHANGE = 0x001A
        SMTO_ABORTIFHUNG = 0x0002
        ctypes.windll.user32.SendMessageTimeoutW(  # type: ignore[attr-defined]
            HWND_BROADCAST, WM_SETTINGCHANGE, 0,
            "Environment", SMTO_ABORTIFHUNG, 5000, ctypes.byref(ctypes.c_long()),
        )
    except Exception:
        pass
