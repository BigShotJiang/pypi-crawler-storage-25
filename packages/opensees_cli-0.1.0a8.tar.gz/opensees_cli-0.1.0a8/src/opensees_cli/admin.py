"""Admin CLI commands."""

import re
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from opensees_cli import api
from opensees_cli.auth import _to_local, print_quota

_RUNTIME_TOKEN_RE = re.compile(r"^((\d+(?:\.\d+)?)(h|m|s))+$")


def _parse_runtime_quota(raw: str) -> int:
    """Parse -r: plain digits = seconds; or duration tokens like 2h, 10m, 1h30m, 90s."""
    s = raw.strip().lower().replace(" ", "")
    if not s:
        raise ValueError("value is empty")
    if re.fullmatch(r"\d+", s):
        return int(s)
    if not _RUNTIME_TOKEN_RE.fullmatch(s):
        raise ValueError(
            "expected digits (seconds) or duration like 2h, 10m, 1h30m, 90s"
        )
    total = 0.0
    for m in re.finditer(r"(\d+(?:\.\d+)?)(h|m|s)", s):
        val = float(m.group(1))
        u = m.group(2)
        if u == "h":
            total += val * 3600
        elif u == "m":
            total += val * 60
        else:
            total += val
    return int(round(total))


def _parse_storage_quota(raw: str) -> int:
    """Parse -s: plain digits = bytes; or 500kb, 10mb, 2gb (base 1024)."""
    s = raw.strip().lower().replace(" ", "")
    if not s:
        raise ValueError("value is empty")
    if re.fullmatch(r"\d+", s):
        return int(s)
    m = re.fullmatch(r"(\d+(?:\.\d+)?)(kb|mb|gb)", s)
    if not m:
        raise ValueError("expected digits (bytes) or size like 500kb, 10mb, 2gb")
    val = float(m.group(1))
    unit = m.group(2)
    mult = {"kb": 1024, "mb": 1024**2, "gb": 1024**3}
    return int(round(val * mult[unit]))


console = Console()
app = typer.Typer(
    help="Admin operations (requires admin privileges).",
)


@app.callback(invoke_without_command=True)
def _admin_callback(ctx: typer.Context) -> None:
    api.require_login()
    if ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())
        raise typer.Exit(0)


@app.command("list-users")
def list_users():
    """List all registered users."""
    try:
        r = api.get("/admin/users")
    except api.ApiError as e:
        console.print(f"[red]{e.message}[/red]")
        raise typer.Exit(1)

    users = r.get("users", [])
    if not users:
        console.print("[dim]No users found.[/dim]")
        return

    table = Table(title=f"Users ({len(users)})")
    table.add_column("Email", style="cyan")
    table.add_column("Status")
    table.add_column("Enabled")
    table.add_column("Admin")
    table.add_column("Last Login")
    table.add_column("Last Activity")
    table.add_column("CLI Version")

    for u in users:
        enabled = "[green]yes[/green]" if u.get("enabled") else "[red]no[/red]"
        admin = "[yellow]yes[/yellow]" if u.get("is_admin") else "no"
        table.add_row(
            u.get("email", ""),
            u.get("status", ""),
            enabled,
            admin,
            u.get("last_login_at", "") or "-",
            u.get("last_activity_at", "") or "-",
            u.get("last_cli_version", "") or "-",
        )
    console.print(table)


@app.command("disable-user")
def disable_user(email: Optional[str] = typer.Option(None, "--email", "-e")):
    """Disable a user account (prevents login)."""
    if not email:
        email = typer.prompt("Email to disable")
    try:
        r = api.post("/admin/disable-user", {"email": email})
        console.print(f"[green]{r.get('message', 'User disabled.')}[/green]")
    except api.ApiError as e:
        console.print(f"[red]{e.message}[/red]")
        raise typer.Exit(1)


@app.command("enable-user")
def enable_user(email: Optional[str] = typer.Option(None, "--email", "-e")):
    """Re-enable a disabled user account."""
    if not email:
        email = typer.prompt("Email to enable")
    try:
        r = api.post("/admin/enable-user", {"email": email})
        console.print(f"[green]{r.get('message', 'User enabled.')}[/green]")
    except api.ApiError as e:
        console.print(f"[red]{e.message}[/red]")
        raise typer.Exit(1)


@app.command("delete-user")
def delete_user(email: Optional[str] = typer.Option(None, "--email", "-e")):
    """Permanently delete a user account."""
    if not email:
        email = typer.prompt("Email to delete")

    confirmed = typer.confirm(f"Permanently delete {email}? This cannot be undone")
    if not confirmed:
        console.print("[dim]Cancelled.[/dim]")
        raise typer.Exit(0)

    try:
        r = api.post("/admin/delete-user", {"email": email})
        console.print(f"[green]{r.get('message', 'User deleted.')}[/green]")
    except api.ApiError as e:
        console.print(f"[red]{e.message}[/red]")
        raise typer.Exit(1)


@app.command("user-info")
def user_info(email: Optional[str] = typer.Option(None, "--email", "-e")):
    """Show a user's account details and quota."""
    if not email:
        email = typer.prompt("Email")
    try:
        r = api.post("/admin/user-info", {"email": email})
    except api.ApiError as e:
        console.print(f"[red]{e.message}[/red]")
        raise typer.Exit(1)

    console.print(f"  Email:        [bold]{r.get('email', '')}[/bold]")
    console.print(f"  Admin:        {'[yellow]yes[/yellow]' if r.get('is_admin') else 'no'}")
    console.print(f"  Enabled:      {'[green]yes[/green]' if r.get('is_enabled') else '[red]no[/red]'}")
    if r.get("signup_at"):
        console.print(f"  Signed up:    {_to_local(r['signup_at'])}")
    if r.get("last_login_at"):
        console.print(f"  Last login:   {_to_local(r['last_login_at'])}")
    if r.get("last_activity_at"):
        console.print(f"  Last active:  {_to_local(r['last_activity_at'])}")
    if r.get("last_cli_version"):
        console.print(f"  CLI version:  {r['last_cli_version']}")
    if r.get("last_ip"):
        console.print(f"  Last IP:      {r['last_ip']}")

    q = r.get("quota")
    if q:
        console.print()
        print_quota(q)


@app.command("set-quota")
def set_quota(
    email: Optional[str] = typer.Option(None, "--email", "-e"),
    concurrent: Optional[int] = typer.Option(None, "--concurrent", "-c", help="Max concurrent tasks"),
    tasks: Optional[int] = typer.Option(None, "--tasks", help="Max tasks per analysis"),
    runtime: Optional[str] = typer.Option(None, "--runtime", "-r", help="Max monthly runtime: seconds (300) or duration (2h, 10m, 1h30m)"),
    storage: Optional[str] = typer.Option(None, "--storage", "-s", help="Max monthly storage: bytes (1048576) or size (500kb, 10mb, 2gb)"),
):
    """Update a user's quota limits."""
    if not email:
        email = typer.prompt("Email")
    if concurrent is None and tasks is None and runtime is None and storage is None:
        console.print("Provide at least one of --concurrent, --tasks, --runtime, or --storage.")
        raise typer.Exit(0)

    runtime_secs: Optional[int] = None
    if runtime is not None:
        try:
            runtime_secs = _parse_runtime_quota(runtime)
        except ValueError as exc:
            console.print(f"[red]Invalid --runtime value '{runtime}': {exc}[/red]")
            raise typer.Exit(1)

    storage_bytes: Optional[int] = None
    if storage is not None:
        try:
            storage_bytes = _parse_storage_quota(storage)
        except ValueError as exc:
            console.print(f"[red]Invalid --storage value '{storage}': {exc}[/red]")
            raise typer.Exit(1)

    body: dict = {"email": email}
    if concurrent is not None:
        body["max_concurrent_runs"] = concurrent
    if tasks is not None:
        body["max_tasks_per_analysis"] = tasks
    if runtime_secs is not None:
        body["max_monthly_runtime"] = runtime_secs
    if storage_bytes is not None:
        body["max_monthly_storage"] = storage_bytes

    try:
        r = api.post("/admin/set-quota", body)
        console.print(f"[green]{r.get('message', 'Quota updated.')}[/green]")
    except api.ApiError as e:
        console.print(f"[red]{e.message}[/red]")
        raise typer.Exit(1)
