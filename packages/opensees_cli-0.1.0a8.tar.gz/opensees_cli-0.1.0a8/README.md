# OpenSees CLI Documentation

Command-line interface for authentication and simulation runs.

## Install

```bash
pip install opensees_cli
```

The PyPI distribution name matches the import name: `import opensees_cli` and `python -m opensees_cli`.

Package page: [pypi.org/project/opensees_cli](https://pypi.org/project/opensees_cli/) (PyPI may still show **`opensees-cli`** in the page title; that is the same project—hyphens and underscores are equivalent there.)

## PATH and the `ops` command

After install, pip places the `ops` launcher in a **scripts** directory (e.g. `Scripts` on Windows, `bin` on macOS/Linux). That folder might not be on your `PATH`, so `ops` may be missing in a new terminal.

- On the **first** interactive run, the CLI can offer to add that folder to your `PATH` automatically.
- To **always** run that step (for example on Windows), use:

```bash
python -m opensees_cli set_path
```

Answer **Y** when prompted. Open a **new** terminal afterward, then try `ops version`.

If `ops` is still not found, you can run the same program with:

```bash
python -m opensees_cli
```

To see the PATH offer again after you skipped it, delete the marker file `~/.opensees/path_fixed` (on Windows: `%USERPROFILE%\.opensees\path_fixed`) and run `python -m opensees_cli` or `python -m opensees_cli set_path`.

## Quick Start

```bash
# 1) Create account
ops auth signup --email you@example.com

# 2) Confirm account
ops auth confirm --email you@example.com --code 123456

# 3) Log in
ops auth login --email you@example.com

# 4) Submit a simulation
ops run submit ./model.py --timeout 300 --wait
```

## Top-Level Commands

```bash
ops set_path
ops version
ops status
ops quota
ops help
```

- `set_path`: interactive prompt to add the `ops` launcher directory to your `PATH` (use `python -m opensees_cli set_path` if `ops` is not on `PATH` yet)
- `version`: print CLI version
- `status`: show account details, signup time, and quota (calls the API)
- `quota`: show your current run quota

## Auth Commands

```bash
ops auth signup --email you@example.com
ops auth confirm --email you@example.com --code 123456
ops auth resend-code --email you@example.com
ops auth login --email you@example.com
ops auth logout
ops auth status
ops auth forgot-password --email you@example.com
ops auth reset-password --email you@example.com --code 123456
ops auth change-password
ops auth help
```

## Run Commands

```bash
ops run submit ./model.py --timeout 120 --wait
ops run status <run_id>
ops run output <run_id>
ops run result <run_id>
ops run cancel <run_id>
ops run list --limit 20
ops run help
```

### `run submit` options

- `file` (required positional): path to a `.py` simulation script
- `--timeout`, `-t`: max wall time per task in seconds (default `120`). The API requires your **monthly runtime remaining** ≥ `timeout ×` number of tasks. Runs above **900s** use Fargate when configured; otherwise the **900s** Lambda limit applies.
- `--wait/--no-wait`: stream output until completion (default `--wait`)

Validation enforced by CLI:
- file must exist
- file extension must be `.py`
- file size must be <= 200 KB

## Common Workflows

### Check account + quota

```bash
ops status
ops quota
```

### Submit and monitor a run later

```bash
ops run submit ./model.py --no-wait
ops run status <run_id>
ops run output <run_id>
ops run result <run_id>
```

### Reset password

```bash
ops auth forgot-password --email you@example.com
ops auth reset-password --email you@example.com --code 123456
```
