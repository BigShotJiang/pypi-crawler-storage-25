"""Tests for root-level ops commands: version, status, quota."""

from opensees_cli.main import app
from opensees_cli import __version__


class TestVersion:
    def test_version_output(self, cli_runner):
        result = cli_runner.invoke(app, ["version"])
        assert result.exit_code == 0
        assert __version__ in result.output


class TestStatus:
    def test_status_logged_in(self, cli_runner, logged_in_creds, patch_httpx, mock_router):
        mock_router.add("GET", "/prod/auth/me", json={
            "email": "user@test.com",
            "is_admin": False,
            "is_enabled": True,
            "quota": {
                "max_concurrent_runs": 5,
                "max_tasks_per_analysis": 100,
                "max_monthly_runtime": 3600,
                "monthly_runtime_used": 100,
                "monthly_runtime_reserved": 0,
                "monthly_runtime_remaining": 3500,
                "max_monthly_storage": 1073741824,
                "storage_used": 0,
            },
        })
        result = cli_runner.invoke(app, ["status"])
        assert result.exit_code == 0
        assert "user@test.com" in result.output

    def test_status_not_logged_in(self, cli_runner):
        result = cli_runner.invoke(app, ["status"])
        assert result.exit_code == 0
        assert "Not logged in" in result.output


class TestQuota:
    def test_quota_happy(self, cli_runner, logged_in_creds, patch_httpx, mock_router):
        mock_router.add("GET", "/prod/auth/me", json={
            "email": "user@test.com",
            "quota": {
                "max_concurrent_runs": 5,
                "max_tasks_per_analysis": 100,
                "max_monthly_runtime": 3600,
                "monthly_runtime_used": 200,
                "monthly_runtime_reserved": 0,
                "monthly_runtime_remaining": 3400,
                "max_monthly_storage": 1073741824,
                "storage_used": 0,
            },
        })
        result = cli_runner.invoke(app, ["quota"])
        assert result.exit_code == 0
        assert "Concurrent tasks" in result.output

    def test_quota_not_logged_in(self, cli_runner):
        result = cli_runner.invoke(app, ["quota"])
        assert result.exit_code == 0
        assert "Not logged in" in result.output
