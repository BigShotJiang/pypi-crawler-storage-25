from __future__ import annotations

import asyncio
import logging
import shlex
import time
from typing import Any, Callable

from disquerd._http import HTTPClient
from disquerd._types import Coro, EventType
from disquerd.commands.core import CommandBase, CommandCheck
from disquerd.commands.slash import SlashCommand
from disquerd.commands.prefix import PrefixCommand
from disquerd.commands.context_menu import UserCommand, MessageCommand
from disquerd.commands.context import ApplicationContext, ComponentContext, ModalContext, Context
from disquerd.commands.cog import Cog
from disquerd.errors.command import CommandCheckFailure, CommandOnCooldown, CommandInvokeError
from disquerd.events.dispatch import EventDispatcher, EventHandler
from disquerd.gateway import Gateway
from disquerd.log import setup_logging, _banner, log_command, log_guild_join, log_guild_leave
from disquerd.models.interaction import Interaction, InteractionType, InteractionResponseType
from disquerd.rest import RESTClient
from disquerd.state import State
from disquerd.test_mode import TestMode
from disquerd.ui.modal import Modal

__all__ = ("Bot", "Intents")

_A = {"r": "\033[0m", "b": "\033[1m", "brrd": "\033[91m", "brgn": "\033[92m",
      "bryl": "\033[93m", "brmg": "\033[95m", "brcy": "\033[96m"}

_log = logging.getLogger("disquerd")


class Intents:
    __slots__ = ("value",)

    GUILDS = 1 << 0
    GUILD_MEMBERS = 1 << 1
    GUILD_BANS = 1 << 2
    GUILD_EMOJIS_AND_STICKERS = 1 << 3
    GUILD_INTEGRATIONS = 1 << 4
    GUILD_WEBHOOKS = 1 << 5
    GUILD_INVITES = 1 << 6
    GUILD_VOICE_STATES = 1 << 7
    GUILD_PRESENCES = 1 << 8
    GUILD_MESSAGES = 1 << 9
    GUILD_MESSAGE_REACTIONS = 1 << 10
    GUILD_MESSAGE_TYPING = 1 << 11
    DIRECT_MESSAGES = 1 << 12
    DIRECT_MESSAGE_REACTIONS = 1 << 13
    DIRECT_MESSAGE_TYPING = 1 << 14
    MESSAGE_CONTENT = 1 << 15
    GUILD_SCHEDULED_EVENTS = 1 << 16
    AUTO_MODERATION_CONFIGURATION = 1 << 20
    AUTO_MODERATION_EXECUTION = 1 << 21

    ALL_PRIVILEGED = GUILD_MEMBERS | GUILD_PRESENCES | MESSAGE_CONTENT

    ALL = (GUILDS | GUILD_MEMBERS | GUILD_BANS | GUILD_EMOJIS_AND_STICKERS |
           GUILD_INTEGRATIONS | GUILD_WEBHOOKS | GUILD_INVITES | GUILD_VOICE_STATES |
           GUILD_PRESENCES | GUILD_MESSAGES | GUILD_MESSAGE_REACTIONS |
           GUILD_MESSAGE_TYPING | DIRECT_MESSAGES | DIRECT_MESSAGE_REACTIONS |
           DIRECT_MESSAGE_TYPING | MESSAGE_CONTENT | GUILD_SCHEDULED_EVENTS |
           AUTO_MODERATION_CONFIGURATION | AUTO_MODERATION_EXECUTION)

    DEFAULT = (GUILDS | GUILD_BANS | GUILD_EMOJIS_AND_STICKERS | GUILD_INTEGRATIONS |
               GUILD_WEBHOOKS | GUILD_INVITES | GUILD_VOICE_STATES | GUILD_MESSAGES |
               GUILD_MESSAGE_REACTIONS | GUILD_MESSAGE_TYPING | DIRECT_MESSAGES |
               DIRECT_MESSAGE_REACTIONS | DIRECT_MESSAGE_TYPING | GUILD_SCHEDULED_EVENTS |
               AUTO_MODERATION_CONFIGURATION | AUTO_MODERATION_EXECUTION)

    def __init__(self, value: int = 0) -> None:
        self.value = value

    def has(self, flag: int) -> bool:
        return bool(self.value & flag)

    def add(self, flag: int) -> Intents:
        self.value |= flag
        return self

    def remove(self, flag: int) -> Intents:
        self.value &= ~flag
        return self

    @classmethod
    def all(cls) -> Intents:
        return cls(cls.ALL)

    @classmethod
    def default(cls) -> Intents:
        return cls(cls.DEFAULT)

    @classmethod
    def none(cls) -> Intents:
        return cls(0)

    def __repr__(self) -> str:
        return f"Intents({self.value})"


class Bot:
    __slots__ = (
        "_token", "_intents", "_http", "_rest", "_gateway", "_state",
        "_events", "_slash_commands", "_prefix_commands", "_user_commands", "_message_commands",
        "_views", "_cogs", "_autocomplete_handlers",
        "_modals", "_button_listeners",
        "_prefix", "_prefixes", "_debug", "_application_id", "_synced",
        "_ready_event", "_activity", "_status", "_test_mode",
        "_wait_futures",
        "_case_insensitive", "_strip_after_prefix",
        "_before_invoke", "_after_invoke",
        "_global_checks",
        "_last_heartbeat_ack",
    )

    def __init__(
        self,
        token: str,
        *,
        intents: Intents | None = None,
        prefix: str | list[str] = "!",
        debug: bool = False,
        activity: dict[str, Any] | None = None,
        status: str = "online",
        case_insensitive: bool = False,
        strip_after_prefix: bool = False,
    ) -> None:
        self._token = token
        self._intents = intents or Intents.default()
        self._http = HTTPClient(token)
        self._rest = RESTClient(self._http)
        self._gateway: Gateway | None = None
        self._state = State()
        self._state.bind_rest(self._rest)
        self._events = EventDispatcher()
        self._slash_commands: dict[str, SlashCommand] = {}
        self._prefix_commands: dict[str, PrefixCommand] = {}
        self._user_commands: dict[str, UserCommand] = {}
        self._message_commands: dict[str, MessageCommand] = {}
        self._views: dict[str, Any] = {}
        self._cogs: dict[str, Cog] = {}
        self._autocomplete_handlers: dict[str, Callable] = {}
        self._modals: dict[str, Modal] = {}
        self._button_listeners: dict[str, Callable] = {}
        if isinstance(prefix, str):
            self._prefix = prefix
            self._prefixes = [prefix]
        else:
            self._prefix = prefix[0] if prefix else "!"
            self._prefixes = prefix
        self._debug = debug
        self._application_id: int | None = None
        self._synced = False
        self._ready_event = asyncio.Event()
        self._activity = activity
        self._status = status
        self._test_mode: TestMode | None = None
        self._wait_futures: dict[EventType, list[asyncio.Future]] = {}
        self._case_insensitive = case_insensitive
        self._strip_after_prefix = strip_after_prefix
        self._before_invoke: Callable[..., Coro[None]] | None = None
        self._after_invoke: Callable[..., Coro[None]] | None = None
        self._global_checks: list[CommandCheck] = []
        self._last_heartbeat_ack: float | None = None

        setup_logging(level=logging.DEBUG if debug else logging.WARNING)

    @property
    def user(self) -> Any:
        return self._state.user

    @property
    def guilds(self) -> list[Any]:
        return self._state.guilds

    @property
    def application_id(self) -> int | None:
        return self._application_id

    @property
    def state(self) -> State:
        return self._state

    @property
    def rest(self) -> RESTClient:
        return self._rest

    @property
    def cogs(self) -> dict[str, Cog]:
        return self._cogs.copy()

    @property
    def modals(self) -> dict[str, Modal]:
        return self._modals.copy()

    @property
    def button_listeners(self) -> dict[str, Callable]:
        return self._button_listeners.copy()

    @property
    def username(self) -> str:
        u = self._state.user
        return u.display_name if u else "???"

    @property
    def avatar_url(self) -> str | None:
        u = self._state.user
        if u and getattr(u, "avatar", None):
            aid = u.avatar
            return f"https://cdn.discordapp.com/avatars/{u.id}/{aid}.png"
        return None

    @property
    def mention(self) -> str:
        u = self._state.user
        return f"<@{u.id}>" if u else ""

    @property
    def latency(self) -> float:
        if self._gateway and self._gateway._heartbeat_interval:
            return self._gateway._heartbeat_interval
        return float("nan")

    @property
    def latency_ms(self) -> float:
        v = self.latency
        return v * 1000 if v == v else float("nan")

    def get_channel(self, channel_id: int) -> Any | None:
        return self._state.get_channel(channel_id)

    def get_guild(self, guild_id: int) -> Any | None:
        return self._state.get_guild(guild_id)

    def get_user(self, user_id: int) -> Any | None:
        return self._state.get_user(user_id)

    def get_voice_state(self, guild_id: int, user_id: int) -> Any | None:
        return self._state.get_voice_state(guild_id, user_id)

    def get_cog(self, name: str) -> Cog | None:
        return self._cogs.get(name)

    def add_cog(self, cog: Cog) -> None:
        name = cog.__class__.__name__
        registered = cog._setup()
        self._cogs[name] = cog
        _log.info(f"Loaded cog {_A['brcy']}{name}{_A['r']} ({len(registered)} commands)")

    def remove_cog(self, name: str) -> Cog | None:
        cog = self._cogs.pop(name, None)
        if cog:
            cog._teardown()
            _log.info(f"Unloaded cog {_A['brcy']}{name}{_A['r']}")
        return cog

    def add_modal(self, modal: Modal) -> None:
        self._modals[modal.custom_id] = modal

    def get_modal(self, custom_id: str) -> Modal | None:
        return self._modals.get(custom_id)

    def remove_modal(self, custom_id: str) -> Modal | None:
        return self._modals.pop(custom_id, None)

    def add_button_listener(self, custom_id: str, callback: Callable) -> None:
        self._button_listeners[custom_id] = callback

    def get_button_listener(self, custom_id: str) -> Callable | None:
        return self._button_listeners.get(custom_id)

    def remove_button_listener(self, custom_id: str) -> Callable | None:
        return self._button_listeners.pop(custom_id, None)

    def slash_command(
        self,
        name: str | None = None,
        *,
        description: str = "",
        options: list[dict[str, Any]] | None = None,
        guild_ids: list[int] | None = None,
        checks: list[CommandCheck] | None = None,
        nsfw: bool = False,
        default_member_permissions: str | None = None,
        dm_permission: bool = True,
    ) -> Callable[[Callable[..., Coro[None]]], SlashCommand]:
        from disquerd.models.application import ApplicationCommandOption
        _opts: list[ApplicationCommandOption] | None = None
        if options:
            _opts = [ApplicationCommandOption(**o) if isinstance(o, dict) else o for o in options]

        def decorator(callback: Callable[..., Coro[None]]) -> SlashCommand:
            cmd = SlashCommand(callback, name=name, description=description,
                               options=_opts, guild_ids=guild_ids, checks=checks, nsfw=nsfw,
                               default_member_permissions=default_member_permissions,
                               dm_permission=dm_permission)
            self._slash_commands[cmd.name] = cmd
            return cmd
        return decorator

    def user_command(
        self,
        name: str | None = None,
        *,
        guild_ids: list[int] | None = None,
        checks: list[CommandCheck] | None = None,
    ) -> Callable[[Callable[..., Coro[None]]], UserCommand]:
        def decorator(callback: Callable[..., Coro[None]]) -> UserCommand:
            cmd = UserCommand(callback, name=name, guild_ids=guild_ids, checks=checks)
            self._user_commands[cmd.name] = cmd
            return cmd
        return decorator

    def message_command(
        self,
        name: str | None = None,
        *,
        guild_ids: list[int] | None = None,
        checks: list[CommandCheck] | None = None,
    ) -> Callable[[Callable[..., Coro[None]]], MessageCommand]:
        def decorator(callback: Callable[..., Coro[None]]) -> MessageCommand:
            cmd = MessageCommand(callback, name=name, guild_ids=guild_ids, checks=checks)
            self._message_commands[cmd.name] = cmd
            return cmd
        return decorator

    def command(
        self,
        name: str | None = None,
        *,
        description: str = "",
        aliases: list[str] | None = None,
        checks: list[CommandCheck] | None = None,
    ) -> Callable[[Callable[..., Coro[None]]], PrefixCommand]:
        def decorator(callback: Callable[..., Coro[None]]) -> PrefixCommand:
            cmd = PrefixCommand(callback, name=name, description=description,
                                aliases=aliases, checks=checks)
            self._prefix_commands[cmd.name] = cmd
            for alias in cmd.aliases:
                self._prefix_commands[alias] = cmd
            return cmd
        return decorator

    def event(self, event_type: EventType | None = None) -> Callable[[EventHandler], EventHandler]:
        return self._events.handler(event_type)

    def once(self, event_type: EventType | None = None) -> Callable[[EventHandler], EventHandler]:
        return self._events.once(event_type)

    def check(self, func: CommandCheck) -> CommandCheck:
        self._global_checks.append(func)
        return func

    def before_invoke(self, func: Callable[..., Coro[None]]) -> Callable[..., Coro[None]]:
        self._before_invoke = func
        return func

    def after_invoke(self, func: Callable[..., Coro[None]]) -> Callable[..., Coro[None]]:
        self._after_invoke = func
        return func

    def modal(
        self,
        custom_id: str | None = None,
        *,
        title: str = "",
        components: list | None = None,
    ) -> Callable[[Callable[..., Coro[None]]], Modal]:
        def decorator(callback: Callable[..., Coro[None]]) -> Modal:
            m = Modal(
                title=title or callback.__name__.replace("_", " ").title(),
                custom_id=custom_id or callback.__name__,
                components=components,
            )
            m.callback = callback
            self._modals[m.custom_id] = m
            return m
        return decorator

    def button(
        self,
        custom_id: str | None = None,
    ) -> Callable[[Callable[..., Coro[None]]], Callable[..., Coro[None]]]:
        def decorator(callback: Callable[..., Coro[None]]) -> Callable[..., Coro[None]]:
            cid = custom_id or callback.__name__
            self._button_listeners[cid] = callback
            return callback
        return decorator

    def add_view(self, view: Any, *, message_id: int | None = None) -> None:
        for item in getattr(view, "_children", []):
            custom_id = getattr(item, "custom_id", None)
            if custom_id:
                self._views[custom_id] = view

    def enable_test_mode(self, *, channel_id: int | None = None) -> None:
        self._test_mode = TestMode(self, channel_id=channel_id)

    async def wait_for(
        self,
        event: EventType,
        *,
        check: Callable[..., bool] | None = None,
        timeout: float | None = None,
    ) -> Any:
        future = asyncio.get_event_loop().create_future()
        if event not in self._wait_futures:
            self._wait_futures[event] = []
        self._wait_futures[event].append((future, check))
        return await asyncio.wait_for(future, timeout=timeout)

    async def change_presence(
        self,
        *,
        status: str = "online",
        activity: dict[str, Any] | None = None,
        afk: bool = False,
    ) -> None:
        self._status = status
        self._activity = activity
        if self._gateway:
            await self._gateway.update_presence(status=status, activity=activity, afk=afk)

    async def fetch_channel(self, channel_id: int) -> dict[str, Any]:
        return await self._rest.get_channel(channel_id)

    async def fetch_guild(self, guild_id: int) -> dict[str, Any]:
        return await self._rest.get_guild(guild_id)

    async def fetch_user(self, user_id: int) -> dict[str, Any]:
        return await self._rest.get_user(user_id)

    async def fetch_message(self, channel_id: int, message_id: int) -> dict[str, Any]:
        return await self._rest.get_message(channel_id, message_id)

    async def fetch_ban(self, guild_id: int, user_id: int) -> dict[str, Any]:
        return await self._rest.get_guild_ban(guild_id, user_id)

    async def fetch_bans(self, guild_id: int, **kwargs: Any) -> list[dict[str, Any]]:
        return await self._rest.get_guild_bans(guild_id, **kwargs)

    async def fetch_audit_log(self, guild_id: int, **kwargs: Any) -> dict[str, Any]:
        return await self._rest.get_guild_audit_log(guild_id, **kwargs)

    async def fetch_webhooks(self, guild_id: int) -> list[dict[str, Any]]:
        return await self._rest.get_guild_webhooks(guild_id)

    async def fetch_invites(self, guild_id: int) -> list[dict[str, Any]]:
        return await self._rest.get_guild_invites(guild_id)

    async def sync_commands(self) -> None:
        self._synced = False
        await self._sync_commands()

    async def mute(
        self, guild_id: int, user_id: int, *,
        until: str | None = None, reason: str | None = None,
    ) -> None:
        payload: dict[str, Any] = {}
        if until:
            payload["communication_disabled_until"] = until
        else:
            payload["communication_disabled_until"] = "2038-01-01T00:00:00.000000+00:00"
        if reason:
            payload["reason"] = reason
        await self._rest.modify_guild_member(guild_id, user_id, **payload)

    async def unmute(self, guild_id: int, user_id: int, *, reason: str | None = None) -> None:
        payload: dict[str, Any] = {"communication_disabled_until": None}
        if reason:
            payload["reason"] = reason
        await self._rest.modify_guild_member(guild_id, user_id, **payload)

    async def set_nickname(
        self, guild_id: int, user_id: int, nickname: str | None, *, reason: str | None = None,
    ) -> None:
        await self._rest.modify_guild_member(guild_id, user_id, nick=nickname, reason=reason)

    async def set_slowmode(
        self, channel_id: int, seconds: int, *, reason: str | None = None,
    ) -> None:
        await self._rest._http.patch(
            f"/channels/{channel_id}",
            json={"rate_limit_per_user": seconds},
            reason=reason,
            major_id=channel_id,
        )

    async def purge_messages(
        self, channel_id: int, limit: int = 100, *, reason: str | None = None,
    ) -> list[int]:
        messages = await self._rest.get_messages(channel_id, limit=min(limit, 100))
        ids = [int(m["id"]) for m in messages]
        if len(ids) >= 2:
            await self._rest.bulk_delete_messages(channel_id, ids, reason=reason)
        elif ids:
            await self._rest.delete_message(channel_id, ids[0], reason=reason)
        return ids

    def _dispatch_wait_for(self, event_type: EventType, *args: Any) -> None:
        futures = self._wait_futures.get(event_type, [])
        remaining = []
        for future, check in futures:
            if future.done():
                continue
            try:
                if check is None or check(*args):
                    future.set_result(args[0] if len(args) == 1 else args)
                    continue
            except Exception as e:
                future.set_exception(e)
                continue
            remaining.append((future, check))
        self._wait_futures[event_type] = remaining

    async def _sync_commands(self) -> None:
        if not self._application_id or self._synced:
            return
        if not self._slash_commands and not self._user_commands and not self._message_commands:
            return

        all_cmds: list[dict[str, Any]] = []
        for cmd in self._slash_commands.values():
            if not cmd.guild_ids:
                all_cmds.append(cmd.to_application_command().to_dict())
        for cmd in self._user_commands.values():
            if not cmd.guild_ids:
                all_cmds.append(cmd.to_application_command().to_dict())
        for cmd in self._message_commands.values():
            if not cmd.guild_ids:
                all_cmds.append(cmd.to_application_command().to_dict())

        if all_cmds:
            _log.info(f"Syncing {_A['brcy']}{len(all_cmds)}{_A['r']} commands...")
            try:
                await self._rest.bulk_overwrite_global_application_commands(
                    self._application_id, data=all_cmds)
            except Exception as e:
                _log.error(f"Command sync failed: {e}")

        guild_cmds: dict[int, list[dict[str, Any]]] = {}
        for cmd in list(self._slash_commands.values()) + list(self._user_commands.values()) + list(self._message_commands.values()):
            if hasattr(cmd, 'guild_ids') and cmd.guild_ids:
                for gid in cmd.guild_ids:
                    guild_cmds.setdefault(gid, []).append(cmd.to_application_command().to_dict())

        for gid, cmds in guild_cmds.items():
            try:
                await self._rest.bulk_overwrite_guild_application_commands(
                    self._application_id, gid, data=cmds)
            except Exception as e:
                _log.error(f"Guild {gid} sync failed: {e}")

        self._synced = True

    async def _on_gateway_dispatch(self, event_type: EventType, data: dict[str, Any]) -> None:
        match event_type:
            case EventType.READY:
                self._state.parse_ready(data)
                self._application_id = self._state.application_id
                await self._sync_commands()
                if self._activity or self._status != "online":
                    if self._gateway:
                        await self._gateway.update_presence(status=self._status, activity=self._activity)
                self._ready_event.set()
                user = self._state.user
                user_name = user.display_name if user else "???"
                total_cmds = len(self._slash_commands) + len(self._user_commands) + len(self._message_commands)
                latency = (self._gateway._heartbeat_interval * 1000) if self._gateway and self._gateway._heartbeat_interval else 0
                print(_banner(user_name, len(self._state.guilds), total_cmds, latency=latency))
                await self._events.dispatch(event_type)

            case EventType.GUILD_CREATE:
                guild = self._state.parse_guild_create(data)
                if not guild.unavailable:
                    log_guild_join(guild.name, guild.member_count)
                await self._events.dispatch(event_type, guild)
                self._dispatch_wait_for(event_type, guild)

            case EventType.GUILD_DELETE:
                gid = int(data.get("id", 0))
                guild = self._state.get_guild(gid)
                if guild:
                    log_guild_leave(guild.name)
                await self._events.dispatch(event_type, data)
                self._dispatch_wait_for(event_type, data)

            case EventType.MESSAGE_CREATE:
                message = self._state.parse_message_create(data)
                await self._events.dispatch(event_type, message)
                self._dispatch_wait_for(event_type, message)
                await self._process_prefix_command(message)

            case EventType.MESSAGE_UPDATE:
                message = self._state.parse_message_update(data)
                if message:
                    await self._events.dispatch(event_type, message)
                    self._dispatch_wait_for(event_type, message)

            case EventType.MESSAGE_DELETE:
                msg_id = self._state.parse_message_delete(data)
                if msg_id:
                    await self._events.dispatch(event_type, msg_id)
                    self._dispatch_wait_for(event_type, msg_id)

            case EventType.INTERACTION_CREATE:
                await self._process_interaction(data)

            case EventType.CHANNEL_CREATE:
                ch = self._state.parse_channel_create(data)
                await self._events.dispatch(event_type, ch)
                self._dispatch_wait_for(event_type, ch)

            case EventType.CHANNEL_UPDATE:
                ch = self._state.parse_channel_update(data)
                if ch:
                    await self._events.dispatch(event_type, ch)
                    self._dispatch_wait_for(event_type, ch)

            case EventType.CHANNEL_DELETE:
                ch = self._state.parse_channel_delete(data)
                if ch:
                    await self._events.dispatch(event_type, ch)

            case EventType.THREAD_CREATE:
                ch = self._state.parse_thread_create(data)
                await self._events.dispatch(event_type, ch)
                self._dispatch_wait_for(event_type, ch)

            case EventType.THREAD_UPDATE:
                ch = self._state.parse_thread_update(data)
                if ch:
                    await self._events.dispatch(event_type, ch)
                    self._dispatch_wait_for(event_type, ch)

            case EventType.THREAD_DELETE:
                ch = self._state.parse_thread_delete(data)
                if ch:
                    await self._events.dispatch(event_type, ch)

            case EventType.VOICE_STATE_UPDATE:
                vs = self._state.parse_voice_state_update(data)
                await self._events.dispatch(event_type, vs)
                self._dispatch_wait_for(event_type, vs)

            case EventType.GUILD_MEMBER_ADD:
                member = self._state.parse_member_add(data)
                await self._events.dispatch(event_type, member)
                self._dispatch_wait_for(event_type, member)

            case EventType.GUILD_MEMBER_REMOVE:
                result = self._state.parse_member_remove(data)
                if result:
                    await self._events.dispatch(event_type, result)

            case EventType.GUILD_MEMBER_UPDATE:
                member = self._state.parse_member_update(data)
                if member:
                    await self._events.dispatch(event_type, member)
                    self._dispatch_wait_for(event_type, member)

            case EventType.GUILD_UPDATE:
                guild = self._state.parse_guild_update(data)
                if guild:
                    await self._events.dispatch(event_type, guild)
                    self._dispatch_wait_for(event_type, guild)

            case EventType.GUILD_ROLE_CREATE:
                role = self._state.parse_role_create(data)
                await self._events.dispatch(event_type, role)

            case EventType.GUILD_ROLE_UPDATE:
                role = self._state.parse_role_update(data)
                if role:
                    await self._events.dispatch(event_type, role)

            case EventType.GUILD_ROLE_DELETE:
                role = self._state.parse_role_delete(data)
                if role:
                    await self._events.dispatch(event_type, role)

            case _:
                await self._events.dispatch(event_type, data)

    async def _process_interaction(self, data: dict[str, Any]) -> None:
        from disquerd.state import _decode
        try:
            interaction = _decode(Interaction, data)
        except Exception:
            interaction = Interaction(id=int(data.get("id", 0)), type=data.get("type", 0),
                                      token=data.get("token", ""))
        interaction.data = data

        match interaction.type:
            case InteractionType.APPLICATION_COMMAND:
                cmd_name = interaction.command_name
                cmd_type = interaction.command_type or 1
                match cmd_type:
                    case 2:
                        cmd = self._user_commands.get(cmd_name)
                    case 3:
                        cmd = self._message_commands.get(cmd_name)
                    case _:
                        cmd = self._slash_commands.get(cmd_name)
                if cmd:
                    ctx = ApplicationContext(interaction, self._rest, self._state)
                    ctx._bot = self
                    author = ctx.author
                    log_command(cmd_name, guild_name=ctx.guild.name if ctx.guild else "DM",
                                author=author.username if author else "unknown")
                    try:
                        if self._before_invoke:
                            await self._before_invoke(ctx)
                        await cmd.invoke(ctx)
                        if self._after_invoke:
                            await self._after_invoke(ctx)
                    except (CommandCheckFailure, CommandOnCooldown) as e:
                        await self._events.dispatch(EventType.SLASH_COMMAND_ERROR, ctx, e)
                        try:
                            if isinstance(e, CommandOnCooldown):
                                await ctx.respond(f"Cooldown: retry in {e.retry_after:.1f}s", ephemeral=True)
                            else:
                                await ctx.respond(f"Check failed: {e.message}", ephemeral=True)
                        except Exception:
                            pass
                    except Exception as e:
                        invoke_err = CommandInvokeError(original=e, command_name=cmd_name)
                        await self._events.dispatch(EventType.SLASH_COMMAND_ERROR, ctx, invoke_err)
                        _log.error(f"Error in /{cmd_name}: {e}")
                        try:
                            await ctx.respond(f"Error: {e}", ephemeral=True)
                        except Exception:
                            pass
                else:
                    await self._rest.create_interaction_response(
                        interaction.id, interaction.token,
                        data={"type": InteractionResponseType.CHANNEL_MESSAGE_WITH_SOURCE.value,
                              "data": {"content": "Unknown command.", "flags": 64}})

            case InteractionType.MESSAGE_COMPONENT:
                ctx = ComponentContext(interaction, self._rest, self._state)
                ctx._bot = self
                custom_id = interaction.custom_id

                if custom_id and custom_id in self._button_listeners:
                    try:
                        await self._button_listeners[custom_id](ctx)
                    except Exception as e:
                        await self._events.dispatch(EventType.COMPONENT_ERROR, ctx, e)
                        _log.error(f"Button listener error for {custom_id}: {e}")
                elif custom_id and custom_id in self._views:
                    try:
                        await self._views[custom_id].dispatch(data)
                    except Exception as e:
                        await self._events.dispatch(EventType.COMPONENT_ERROR, ctx, e)

                await self._events.dispatch(EventType.INTERACTION_CREATE, interaction)

            case InteractionType.MODAL_SUBMIT:
                ctx = ModalContext(interaction, self._rest, self._state)
                ctx._bot = self
                custom_id = interaction.custom_id

                if custom_id and custom_id in self._modals:
                    modal_obj = self._modals[custom_id]
                    if modal_obj.callback:
                        try:
                            await modal_obj.callback(ctx)
                        except Exception as e:
                            await self._events.dispatch(EventType.MODAL_ERROR, ctx, e)
                            _log.error(f"Modal callback error for {custom_id}: {e}")
                else:
                    _log.warning(f"Unregistered modal submit: {custom_id}")

                await self._events.dispatch(EventType.INTERACTION_CREATE, interaction)

            case InteractionType.PING:
                await self._rest.create_interaction_response(
                    interaction.id, interaction.token,
                    data={"type": InteractionResponseType.PONG.value})

            case InteractionType.APPLICATION_COMMAND_AUTOCOMPLETE:
                focused = None
                for opt in interaction.options:
                    if opt.get("focused"):
                        focused = opt.get("name")
                        break
                if focused and focused in self._autocomplete_handlers:
                    try:
                        choices = await self._autocomplete_handlers[focused](interaction)
                        await self._rest.create_interaction_response(
                            interaction.id, interaction.token,
                            data={"type": 8, "data": {"choices": choices}})
                    except Exception as e:
                        _log.error(f"Autocomplete error for {focused}: {e}")

            case _:
                await self._events.dispatch(EventType.INTERACTION_CREATE, interaction)

    async def _process_prefix_command(self, message: Any) -> None:
        if not self._prefix_commands:
            return
        content = getattr(message, "content", "")

        prefix_used = None
        for pfx in self._prefixes:
            if content.startswith(pfx):
                prefix_used = pfx
                break
        if prefix_used is None:
            return

        rest = content[len(prefix_used):]
        if self._strip_after_prefix:
            rest = rest.lstrip()
        if not rest:
            return

        try:
            parts = shlex.split(rest)
        except ValueError:
            parts = rest.split()

        invoked = parts[0].lower() if self._case_insensitive else parts[0]
        cmd = self._prefix_commands.get(invoked)
        if cmd is None:
            return

        ctx = Context(message, self._rest, self._state, prefix=prefix_used)
        ctx._bot = self
        ctx.invoked_with = invoked
        ctx.command = cmd
        ctx.view = " ".join(parts[1:])
        ctx.args = parts[1:]

        await self._events.dispatch(EventType.COMMAND, ctx)

        try:
            for check in self._global_checks:
                if not await check(ctx):
                    raise CommandCheckFailure(command_name=cmd.name)
            if self._before_invoke:
                await self._before_invoke(ctx)
            await cmd.invoke(ctx, *ctx.args)
            if self._after_invoke:
                await self._after_invoke(ctx)
            await self._events.dispatch(EventType.COMMAND_COMPLETION, ctx)
        except (CommandCheckFailure, CommandOnCooldown) as e:
            await self._events.dispatch(EventType.COMMAND_ERROR, ctx, e)
            _log.error(f"Check failed for {prefix_used}{invoked}: {e}")
        except Exception as e:
            invoke_err = CommandInvokeError(original=e, command_name=cmd.name)
            await self._events.dispatch(EventType.COMMAND_ERROR, ctx, invoke_err)
            _log.error(f"Error in {prefix_used}{invoked}: {e}")

    async def wait_until_ready(self) -> None:
        await self._ready_event.wait()

    async def start(self) -> None:
        self._gateway = Gateway(self._http, token=self._token,
                                 intents=self._intents.value, dispatch=self._on_gateway_dispatch)
        try:
            await self._gateway.connect()
        except Exception as e:
            _log.critical(f"Gateway error: {e}")
        finally:
            await self.close()

    def run(self) -> None:
        try:
            asyncio.run(self._run_inner())
        except KeyboardInterrupt:
            print(f"\n  {_A['bryl']}Bot stopped{_A['r']}")

    async def _run_inner(self) -> None:
        gw = asyncio.create_task(self.start())
        if self._test_mode:
            await self._ready_event.wait()
            tm = asyncio.create_task(self._test_mode.start())
            done, pending = await asyncio.wait([gw, tm], return_when=asyncio.FIRST_COMPLETED)
            for t in pending:
                t.cancel()
        else:
            await gw

    async def close(self) -> None:
        if self._test_mode:
            self._test_mode.stop()
        if self._gateway:
            await self._gateway.close()
        await self._rest.close()

    def __repr__(self) -> str:
        return f"Bot(user={self.user!r}, guilds={len(self.guilds)})"
