from __future__ import annotations

import asyncio
import logging
from typing import Any, Callable

import aiohttp

from disquerd._http import HTTPClient
from disquerd._websocket import WebSocketClient
from disquerd._types import EventType, MISSING
from disquerd.errors.gateway import GatewayError

__all__ = ("Gateway",)

_log = logging.getLogger(__name__)

_GATEWAY_OPCODES = {
    "DISPATCH": 0,
    "HEARTBEAT": 1,
    "IDENTIFY": 2,
    "STATUS_UPDATE": 3,
    "VOICE_STATE_UPDATE": 4,
    "RESUME": 6,
    "RECONNECT": 7,
    "REQUEST_GUILD_MEMBERS": 8,
    "INVALID_SESSION": 9,
    "HELLO": 10,
    "HEARTBEAT_ACK": 11,
}


class Gateway:
    __slots__ = (
        "_http",
        "_ws_client",
        "_session",
        "_token",
        "_intents",
        "_shard_id",
        "_shard_count",
        "_heartbeat_interval",
        "_heartbeat_task",
        "_seq",
        "_session_id",
        "_dispatch",
        "_resume_url",
        "_running",
    )

    def __init__(
        self,
        http: HTTPClient,
        *,
        token: str,
        intents: int = 0,
        shard_id: int = 0,
        shard_count: int = 1,
        dispatch: Callable[[EventType, dict[str, Any]], None] | None = None,
    ) -> None:
        self._http = http
        self._ws_client: WebSocketClient | None = None
        self._session: aiohttp.ClientSession | None = None
        self._token = token
        self._intents = intents
        self._shard_id = shard_id
        self._shard_count = shard_count
        self._heartbeat_interval: float = 0.0
        self._heartbeat_task: asyncio.Task[None] | None = None
        self._seq: int | None = None
        self._session_id: str | None = None
        self._dispatch = dispatch
        self._resume_url: str | None = None
        self._running = False

    async def connect(self) -> None:
        self._running = True
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession()

        url = await self._resolve_gateway_url()
        self._ws_client = WebSocketClient(self._session, f"{url}?v=10&encoding=json&compress=zlib-stream", use_compression=True)
        await self._ws_client.connect()
        _log.info("Gateway connected (shard %d/%d)", self._shard_id, self._shard_count)

        await self._listen()

    async def _resolve_gateway_url(self) -> str:
        if self._resume_url and self._session_id:
            return self._resume_url
        data = await self._http.get("/gateway/bot")
        return data["url"]

    async def _listen(self) -> None:
        while self._running and self._ws_client and not self._ws_client.is_closed:
            payload = await self._ws_client.receive()
            if payload is None:
                if self._running:
                    _log.warning("Connection lost, attempting to reconnect...")
                    await self._reconnect()
                break

            op = payload.get("op")
            data = payload.get("d", {})
            seq = payload.get("s")
            event_name = payload.get("t")

            if seq is not None:
                self._seq = seq
                if self._ws_client:
                    self._ws_client.sequence = seq

            match op:
                case 10:
                    self._heartbeat_interval = data["heartbeat_interval"] / 1000.0
                    _log.debug("Hello received, heartbeat interval: %.1fs", self._heartbeat_interval)
                    if self._session_id:
                        await self._resume()
                    else:
                        await self._identify()
                    self._heartbeat_task = asyncio.create_task(self._heartbeat_loop())
                case 11:
                    _log.debug("Heartbeat ACK")
                case 0:
                    await self._handle_dispatch(event_name, data)
                case 7:
                    _log.info("Reconnect requested by Discord")
                    await self._reconnect()
                case 9:
                    _log.warning("Invalid session, re-identifying...")
                    self._session_id = None
                    self._seq = None
                    await asyncio.sleep(2.0)
                    await self._identify()
                case _:
                    _log.debug("Unknown opcode %d", op)

    async def _identify(self) -> None:
        payload = {
            "op": _GATEWAY_OPCODES["IDENTIFY"],
            "d": {
                "token": self._token,
                "intents": self._intents,
                "shard": [self._shard_id, self._shard_count],
                "properties": {
                    "os": "linux",
                    "browser": "disquerd",
                    "device": "disquerd",
                },
            },
        }
        await self._send(payload)
        _log.info("Identified to gateway")

    async def _resume(self) -> None:
        payload = {
            "op": _GATEWAY_OPCODES["RESUME"],
            "d": {
                "token": self._token,
                "session_id": self._session_id,
                "seq": self._seq,
            },
        }
        await self._send(payload)
        _log.info("Resumed session %s", self._session_id)

    async def _heartbeat_loop(self) -> None:
        try:
            while self._running:
                await asyncio.sleep(self._heartbeat_interval)
                if not self._running:
                    break
                await self._send({
                    "op": _GATEWAY_OPCODES["HEARTBEAT"],
                    "d": self._seq,
                })
                _log.debug("Heartbeat sent (seq=%s)", self._seq)
        except asyncio.CancelledError:
            pass
        except Exception as e:
            _log.error("Heartbeat error: %s", e)

    async def _handle_dispatch(self, event_name: str | None, data: dict[str, Any]) -> None:
        if event_name is None:
            return

        event_map = {
            "READY": EventType.READY,
            "RESUMED": EventType.RESUMED,
            "MESSAGE_CREATE": EventType.MESSAGE_CREATE,
            "MESSAGE_UPDATE": EventType.MESSAGE_UPDATE,
            "MESSAGE_DELETE": EventType.MESSAGE_DELETE,
            "INTERACTION_CREATE": EventType.INTERACTION_CREATE,
            "GUILD_CREATE": EventType.GUILD_CREATE,
            "GUILD_UPDATE": EventType.GUILD_UPDATE,
            "GUILD_DELETE": EventType.GUILD_DELETE,
            "GUILD_MEMBER_ADD": EventType.GUILD_MEMBER_ADD,
            "GUILD_MEMBER_UPDATE": EventType.GUILD_MEMBER_UPDATE,
            "GUILD_MEMBER_REMOVE": EventType.GUILD_MEMBER_REMOVE,
            "GUILD_ROLE_CREATE": EventType.GUILD_ROLE_CREATE,
            "GUILD_ROLE_UPDATE": EventType.GUILD_ROLE_UPDATE,
            "GUILD_ROLE_DELETE": EventType.GUILD_ROLE_DELETE,
            "CHANNEL_CREATE": EventType.CHANNEL_CREATE,
            "CHANNEL_UPDATE": EventType.CHANNEL_UPDATE,
            "CHANNEL_DELETE": EventType.CHANNEL_DELETE,
            "THREAD_CREATE": EventType.THREAD_CREATE,
            "THREAD_UPDATE": EventType.THREAD_UPDATE,
            "THREAD_DELETE": EventType.THREAD_DELETE,
            "VOICE_STATE_UPDATE": EventType.VOICE_STATE_UPDATE,
        }

        event_type = event_map.get(event_name)
        if event_type is None:
            _log.debug("Unhandled event: %s", event_name)
            return

        if event_type == EventType.READY:
            self._session_id = data.get("session_id")
            self._resume_url = data.get("resume_gateway_url")
            if self._ws_client:
                self._ws_client.session_id = self._session_id

        if self._dispatch:
            await self._dispatch(event_type, data)

    async def _reconnect(self) -> None:
        self._running = False
        if self._heartbeat_task:
            self._heartbeat_task.cancel()
        if self._ws_client:
            await self._ws_client.close()
        await asyncio.sleep(2.0)
        self._running = True
        await self.connect()

    async def _send(self, data: dict[str, Any]) -> None:
        if self._ws_client and not self._ws_client.is_closed:
            await self._ws_client.send(data)

    async def update_presence(
        self,
        *,
        status: str = "online",
        activity: dict[str, Any] | None = None,
        afk: bool = False,
        since: float | None = None,
    ) -> None:
        payload = {
            "op": _GATEWAY_OPCODES["STATUS_UPDATE"],
            "d": {
                "status": status,
                "afk": afk,
                "since": since or 0,
                "activities": [activity] if activity else [],
            },
        }
        await self._send(payload)

    async def close(self) -> None:
        self._running = False
        if self._heartbeat_task:
            self._heartbeat_task.cancel()
        if self._ws_client:
            await self._ws_client.close()
        if self._session and not self._session.closed:
            await self._session.close()
