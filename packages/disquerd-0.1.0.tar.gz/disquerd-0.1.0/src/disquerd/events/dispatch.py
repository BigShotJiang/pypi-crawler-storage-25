from __future__ import annotations

import asyncio
import logging
from typing import Any, Callable, Awaitable

from disquerd._types import Coro, EventType

__all__ = ("EventDispatcher", "EventHandler")

_log = logging.getLogger(__name__)

type EventHandler = Callable[..., Coro[None]]


class EventDispatcher:
    __slots__ = ("_handlers", "_once_handlers")

    def __init__(self) -> None:
        self._handlers: dict[EventType, list[EventHandler]] = {}
        self._once_handlers: dict[EventType, list[EventHandler]] = {}

    def register(self, event_type: EventType, callback: EventHandler) -> None:
        if event_type not in self._handlers:
            self._handlers[event_type] = []
        self._handlers[event_type].append(callback)

    def register_once(self, event_type: EventType, callback: EventHandler) -> None:
        if event_type not in self._once_handlers:
            self._once_handlers[event_type] = []
        self._once_handlers[event_type].append(callback)

    def remove(self, event_type: EventType, callback: EventHandler) -> None:
        handlers = self._handlers.get(event_type, [])
        if callback in handlers:
            handlers.remove(callback)

    async def dispatch(self, event_type: EventType, *args: Any, **kwargs: Any) -> None:
        handlers = self._handlers.get(event_type, [])
        once_handlers = self._once_handlers.pop(event_type, [])

        for callback in handlers + once_handlers:
            try:
                await callback(*args, **kwargs)
            except Exception as e:
                _log.error("Error in event handler %s for %s: %s", callback, event_type, e)

    def handler(self, event_type: EventType | None = None) -> Callable[[EventHandler], EventHandler]:
        def decorator(callback: EventHandler) -> EventHandler:
            et = event_type or EventType(callback.__name__.upper())
            self.register(et, callback)
            return callback
        return decorator

    def once(self, event_type: EventType | None = None) -> Callable[[EventHandler], EventHandler]:
        def decorator(callback: EventHandler) -> EventHandler:
            et = event_type or EventType(callback.__name__.upper())
            self.register_once(et, callback)
            return callback
        return decorator

    @property
    def event_types(self) -> list[EventType]:
        return list(set(list(self._handlers.keys()) + list(self._once_handlers.keys())))
