from __future__ import annotations

from typing import Any

import msgspec

from disquerd.utils.snowflake import Snowflake

__all__ = ("User",)


class User(msgspec.Struct, kw_only=True, omit_defaults=True):
    id: int
    username: str = ""
    discriminator: str = "0"
    global_name: str | None = None
    avatar: str | None = None
    bot: bool = False
    system: bool = False
    mfa_enabled: bool | None = None
    banner: str | None = None
    accent_color: int | None = None
    locale: str | None = None
    verified: bool | None = None
    email: str | None = None
    flags: int = 0
    premium_type: int | None = None
    public_flags: int = 0

    @property
    def mention(self) -> str:
        return f"<@{self.id}>"

    @property
    def display_name(self) -> str:
        return self.global_name or self.username

    @property
    def mention(self) -> str:
        return f"<@{self.id}>"

    @property
    def avatar_url(self) -> str | None:
        if self.avatar is None:
            return None
        return f"https://cdn.discordapp.com/avatars/{self.id}/{self.avatar}.png"

    @property
    def default_avatar_url(self) -> str:
        index = (self.id >> 22) % 6
        return f"https://cdn.discordapp.com/embed/avatars/{index}.png"

    @property
    def display_avatar_url(self) -> str:
        return self.avatar_url or self.default_avatar_url

    @property
    def created_at(self) -> float:
        return Snowflake(self.id).timestamp

    def __repr__(self) -> str:
        return f"User(id={self.id}, username={self.username!r})"

    def __eq__(self, other: object) -> bool:
        return isinstance(other, User) and self.id == other.id

    def __hash__(self) -> int:
        return self.id
