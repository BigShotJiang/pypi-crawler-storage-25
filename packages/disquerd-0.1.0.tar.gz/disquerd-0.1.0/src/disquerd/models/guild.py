from __future__ import annotations

from typing import Any

import msgspec

from disquerd.utils.snowflake import Snowflake
from disquerd._registry import _rest

__all__ = ("Guild",)


class Guild(msgspec.Struct, kw_only=True, omit_defaults=True):
    id: int
    name: str = ""
    icon: str | None = None
    description: str | None = None
    owner_id: int = 0
    afk_channel_id: int | None = None
    afk_timeout: int = 0
    verification_level: int = 0
    mfa_level: int = 0
    application_id: int | None = None
    system_channel_id: int | None = None
    rules_channel_id: int | None = None
    vanity_url_code: str | None = None
    banner: str | None = None
    premium_tier: int = 0
    preferred_locale: str = "en-US"
    member_count: int = 0
    large: bool = False
    owner: bool = False
    unavailable: bool = False

    @property
    def icon_url(self) -> str | None:
        if self.icon is None:
            return None
        ext = "a" if self.icon.startswith("a_") else "png"
        return f"https://cdn.discordapp.com/icons/{self.id}/{self.icon}.{ext}"

    @property
    def created_at(self) -> float:
        return Snowflake(self.id).timestamp

    async def ban(self, user_id: int, *, reason: str | None = None, delete_message_days: int = 0) -> None:
        if _rest:
            await _rest.create_guild_ban(self.id, user_id, delete_message_days=delete_message_days, reason=reason)

    async def kick(self, user_id: int, *, reason: str | None = None) -> None:
        if _rest:
            await _rest.remove_guild_member(self.id, user_id, reason=reason)

    async def create_text_channel(self, name: str, **kwargs: Any) -> dict[str, Any]:
        if _rest:
            return await _rest.create_guild_channel(self.id, name=name, **kwargs)
        return {}

    async def create_role(self, *, name: str, **kwargs: Any) -> dict[str, Any]:
        if _rest:
            return await _rest.create_guild_role(self.id, name=name, **kwargs)
        return {}

    async def leave(self) -> None:
        if _rest:
            await _rest._http.delete(f"/users/@me/guilds/{self.id}")

    async def edit(self, *, reason: str | None = None, **kwargs: Any) -> dict[str, Any]:
        if _rest:
            return await _rest._http.patch(f"/guilds/{self.id}", json=kwargs, reason=reason, major_id=self.id)
        return {}

    def __repr__(self) -> str:
        return f"Guild(id={self.id}, name={self.name!r})"

    def __eq__(self, other: object) -> bool:
        return isinstance(other, Guild) and self.id == other.id

    def __hash__(self) -> int:
        return self.id
