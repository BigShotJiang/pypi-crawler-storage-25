from __future__ import annotations

import msgspec

from disquerd.utils.snowflake import Snowflake

__all__ = ("VoiceState",)


class VoiceState(msgspec.Struct, kw_only=True, omit_defaults=True):
    user_id: int
    guild_id: int = 0
    channel_id: int = 0
    session_id: str = ""
    deaf: bool = False
    mute: bool = False
    self_deaf: bool = False
    self_mute: bool = False
    self_stream: bool = False
    self_video: bool = False
    suppress: bool = False
    request_to_speak_timestamp: str | None = None

    @property
    def created_at(self) -> float:
        return Snowflake(self.user_id).timestamp

    def __repr__(self) -> str:
        return f"VoiceState(user_id={self.user_id}, channel_id={self.channel_id})"
