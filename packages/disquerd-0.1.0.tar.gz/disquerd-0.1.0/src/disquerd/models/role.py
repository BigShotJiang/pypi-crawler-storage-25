from __future__ import annotations

from typing import Any

import msgspec

from disquerd.utils.snowflake import Snowflake
from disquerd.utils.colour import Colour

__all__ = ("Role",)


class Role(msgspec.Struct, kw_only=True, omit_defaults=True):
    id: int
    guild_id: int = 0
    name: str = ""
    color: int = 0
    hoist: bool = False
    icon: str | None = None
    unicode_emoji: str | None = None
    position: int = 0
    permissions: int = 0
    managed: bool = False
    mentionable: bool = False

    @property
    def mention(self) -> str:
        return f"<@&{self.id}>"

    @property
    def is_default(self) -> bool:
        return self.id == self.guild_id

    @property
    def created_at(self) -> float:
        return Snowflake(self.id).timestamp

    def __repr__(self) -> str:
        return f"Role(id={self.id}, name={self.name!r})"

    def __eq__(self, other: object) -> bool:
        return isinstance(other, Role) and self.id == other.id

    def __hash__(self) -> int:
        return self.id
