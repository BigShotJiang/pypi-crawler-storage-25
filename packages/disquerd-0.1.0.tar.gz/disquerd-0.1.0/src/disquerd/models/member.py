from __future__ import annotations

from typing import Any

import msgspec

from disquerd.utils.snowflake import Snowflake
from disquerd.utils.permissions import Permissions
from disquerd.models.user import User
from disquerd._registry import _rest, _state

__all__ = ("Member",)


class Member(msgspec.Struct, kw_only=True, omit_defaults=True):
    id: int
    guild_id: int = 0
    nick: str | None = None
    avatar: str | None = None
    roles: list[int] = []
    joined_at: str | None = None
    premium_since: str | None = None
    deaf: bool = False
    mute: bool = False
    pending: bool = False
    communication_disabled_until: str | None = None
    user: User | None = None

    @property
    def display_name(self) -> str:
        if self.nick:
            return self.nick
        if self.user:
            return self.user.display_name
        return "Unknown"

    @property
    def avatar_url(self) -> str | None:
        if self.avatar:
            return f"https://cdn.discordapp.com/guilds/{self.guild_id}/users/{self.id}/avatars/{self.avatar}.png"
        if self.user and self.user.avatar:
            return self.user.avatar_url
        return None

    @property
    def display_avatar_url(self) -> str:
        return self.avatar_url or (self.user.display_avatar_url if self.user else f"https://cdn.discordapp.com/embed/avatars/{(self.id >> 22) % 6}.png")

    @property
    def mention(self) -> str:
        return f"<@{self.id}>"

    @property
    def created_at(self) -> float:
        return Snowflake(self.id).timestamp

    @property
    def guild_permissions(self) -> Permissions:
        if not _state:
            return Permissions(0)
        guild = _state.get_guild(self.guild_id)
        if guild and guild.owner_id == self.id:
            return Permissions.all()
        perm_value = 0
        for rid in self.roles:
            role = _state.get_role(rid)
            if role:
                if role.permissions & Permissions.ADMINISTRATOR:
                    return Permissions.all()
                perm_value |= role.permissions
        return Permissions(perm_value)

    async def kick(self, *, reason: str | None = None) -> None:
        if _rest:
            await _rest.remove_guild_member(self.guild_id, self.id, reason=reason)

    async def ban(self, *, reason: str | None = None, delete_message_days: int = 0) -> None:
        if _rest:
            await _rest.create_guild_ban(self.guild_id, self.id, delete_message_days=delete_message_days, reason=reason)

    async def timeout(self, until: str, *, reason: str | None = None) -> None:
        if _rest:
            await _rest.modify_guild_member(self.guild_id, self.id, communication_disabled_until=until, reason=reason)

    async def add_roles(self, *role_ids: int, reason: str | None = None) -> None:
        if _rest:
            for rid in role_ids:
                await _rest.add_guild_member_role(self.guild_id, self.id, rid, reason=reason)

    async def remove_roles(self, *role_ids: int, reason: str | None = None) -> None:
        if _rest:
            for rid in role_ids:
                await _rest.remove_guild_member_role(self.guild_id, self.id, rid, reason=reason)

    async def edit(self, *, reason: str | None = None, **kwargs: Any) -> None:
        if _rest:
            await _rest.modify_guild_member(self.guild_id, self.id, reason=reason, **kwargs)

    async def send(self, content: str = "", **kwargs: Any) -> dict[str, Any] | None:
        if not _rest:
            return None
        dm = await _rest._http.post("/users/@me/channels", json={"recipient_id": str(self.id)})
        if dm:
            return await _rest.create_message(int(dm.get("id", 0)), content=content, **kwargs)
        return None

    def __repr__(self) -> str:
        return f"Member(id={self.id}, guild_id={self.guild_id})"

    def __eq__(self, other: object) -> bool:
        return isinstance(other, Member) and self.id == other.id and self.guild_id == other.guild_id

    def __hash__(self) -> int:
        return hash((self.id, self.guild_id))
