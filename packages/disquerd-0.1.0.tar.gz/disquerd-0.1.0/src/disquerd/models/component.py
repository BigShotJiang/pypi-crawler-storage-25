from __future__ import annotations

from enum import IntEnum
from typing import Any

__all__ = ("Component", "ComponentType", "ActionRowData", "ButtonData", "SelectMenuData")


class ComponentType(IntEnum):
    ACTION_ROW = 1
    BUTTON = 2
    STRING_SELECT = 3
    TEXT_INPUT = 4
    USER_SELECT = 5
    ROLE_SELECT = 6
    MENTIONABLE_SELECT = 7
    CHANNEL_SELECT = 8


class ButtonStyle(IntEnum):
    PRIMARY = 1
    SECONDARY = 2
    SUCCESS = 3
    DANGER = 4
    LINK = 5


class Component:
    __slots__ = ("type", "custom_id", "disabled")

    def __init__(self, *, type: int = 1, custom_id: str | None = None, disabled: bool = False) -> None:
        self.type = ComponentType(type)
        self.custom_id = custom_id
        self.disabled = disabled

    def to_dict(self) -> dict[str, Any]:
        return {"type": self.type.value}


class ActionRowData(Component):
    __slots__ = ("components",)

    def __init__(self, *, components: list[Component] | None = None) -> None:
        super().__init__(type=ComponentType.ACTION_ROW)
        self.components = components or []

    def to_dict(self) -> dict[str, Any]:
        return {
            "type": self.type.value,
            "components": [c.to_dict() for c in self.components],
        }


class ButtonData(Component):
    __slots__ = ("style", "label", "emoji", "url")

    def __init__(
        self,
        *,
        style: int = 1,
        label: str | None = None,
        emoji: dict[str, Any] | None = None,
        url: str | None = None,
        custom_id: str | None = None,
        disabled: bool = False,
    ) -> None:
        super().__init__(type=ComponentType.BUTTON, custom_id=custom_id, disabled=disabled)
        self.style = ButtonStyle(style)
        self.label = label
        self.emoji = emoji
        self.url = url

    def to_dict(self) -> dict[str, Any]:
        data: dict[str, Any] = {
            "type": self.type.value,
            "style": self.style.value,
        }
        if self.label:
            data["label"] = self.label
        if self.emoji:
            data["emoji"] = self.emoji
        if self.url:
            data["url"] = self.url
        if self.custom_id:
            data["custom_id"] = self.custom_id
        if self.disabled:
            data["disabled"] = True
        return data


class SelectMenuData(Component):
    __slots__ = ("placeholder", "min_values", "max_values", "options", "channel_types")

    def __init__(
        self,
        *,
        custom_id: str | None = None,
        placeholder: str | None = None,
        min_values: int = 1,
        max_values: int = 1,
        options: list[dict[str, Any]] | None = None,
        channel_types: list[int] | None = None,
        disabled: bool = False,
    ) -> None:
        super().__init__(type=ComponentType.STRING_SELECT, custom_id=custom_id, disabled=disabled)
        self.placeholder = placeholder
        self.min_values = min_values
        self.max_values = max_values
        self.options = options or []
        self.channel_types = channel_types

    def to_dict(self) -> dict[str, Any]:
        data: dict[str, Any] = {
            "type": self.type.value,
        }
        if self.custom_id:
            data["custom_id"] = self.custom_id
        if self.placeholder:
            data["placeholder"] = self.placeholder
        if self.min_values != 1:
            data["min_values"] = self.min_values
        if self.max_values != 1:
            data["max_values"] = self.max_values
        if self.options:
            data["options"] = self.options
        if self.channel_types:
            data["channel_types"] = self.channel_types
        if self.disabled:
            data["disabled"] = True
        return data
