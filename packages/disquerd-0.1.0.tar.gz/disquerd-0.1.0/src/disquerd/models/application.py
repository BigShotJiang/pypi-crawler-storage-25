from __future__ import annotations

from enum import IntEnum
from typing import Any

__all__ = ("ApplicationCommand", "ApplicationCommandOption", "ApplicationCommandOptionType")


class ApplicationCommandOptionType(IntEnum):
    SUB_COMMAND = 1
    SUB_COMMAND_GROUP = 2
    STRING = 3
    INTEGER = 4
    BOOLEAN = 5
    USER = 6
    CHANNEL = 7
    ROLE = 8
    MENTIONABLE = 9
    NUMBER = 10
    ATTACHMENT = 11


class ApplicationCommandOption:
    __slots__ = ("type", "name", "description", "required", "choices", "options", "autocomplete", "min_value", "max_value", "channel_types")

    def __init__(
        self,
        *,
        type: int = 3,
        name: str = "",
        description: str = "",
        required: bool = False,
        choices: list[dict[str, Any]] | None = None,
        options: list[ApplicationCommandOption] | None = None,
        autocomplete: bool = False,
    ) -> None:
        self.type = ApplicationCommandOptionType(type)
        self.name = name
        self.description = description
        self.required = required
        self.choices = choices or []
        self.options = options or []
        self.autocomplete = autocomplete
        self.min_value: int | float | None = None
        self.max_value: int | float | None = None
        self.channel_types: list[int] | None = None

    def to_dict(self) -> dict[str, Any]:
        data: dict[str, Any] = {
            "type": self.type.value,
            "name": self.name,
            "description": self.description,
        }
        if self.required:
            data["required"] = True
        if self.choices:
            data["choices"] = self.choices
        if self.options:
            data["options"] = [o.to_dict() for o in self.options]
        if self.autocomplete:
            data["autocomplete"] = True
        if self.min_value is not None:
            data["min_value"] = self.min_value
        if self.max_value is not None:
            data["max_value"] = self.max_value
        if self.channel_types is not None:
            data["channel_types"] = self.channel_types
        return data


class ApplicationCommand:
    __slots__ = ("id", "type", "application_id", "name", "description", "options", "default_member_permissions", "dm_permission", "nsfw", "version")

    def __init__(
        self,
        *,
        id: int | None = None,
        name: str = "",
        description: str = "",
        options: list[ApplicationCommandOption] | None = None,
        type: int = 1,
    ) -> None:
        self.id = id
        self.type = type
        self.application_id: int | None = None
        self.name = name
        self.description = description
        self.options = options or []
        self.default_member_permissions: str | None = None
        self.dm_permission: bool | None = True
        self.nsfw = False
        self.version: str | None = None

    @classmethod
    def _from_raw(cls, data: dict[str, Any]) -> ApplicationCommand:
        cmd = cls(
            id=_maybe_int(data.get("id")),
            name=data.get("name", ""),
            description=data.get("description", ""),
            type=data.get("type", 1),
        )
        cmd.application_id = _maybe_int(data.get("application_id"))
        cmd.default_member_permissions = data.get("default_member_permissions")
        cmd.dm_permission = data.get("dm_permission", True)
        cmd.nsfw = data.get("nsfw", False)
        cmd.version = data.get("version")
        cmd.options = [ApplicationCommandOption(**o) for o in data.get("options", [])]
        return cmd

    def to_dict(self) -> dict[str, Any]:
        data: dict[str, Any] = {
            "name": self.name,
            "description": self.description,
            "type": self.type,
        }
        if self.options:
            data["options"] = [o.to_dict() for o in self.options]
        if self.default_member_permissions is not None:
            data["default_member_permissions"] = self.default_member_permissions
        if self.dm_permission is not None:
            data["dm_permission"] = self.dm_permission
        if self.nsfw:
            data["nsfw"] = True
        return data

    def __repr__(self) -> str:
        return f"ApplicationCommand(name={self.name!r})"


def _maybe_int(value: str | int | None) -> int | None:
    if value is None:
        return None
    return int(value)
