from __future__ import annotations

import logging
from enum import IntEnum
from typing import Any

import msgspec

from disquerd.utils.snowflake import Snowflake
from disquerd._registry import _rest

__all__ = ("Message", "MessageType", "MessageFlags", "Attachment")

_log = logging.getLogger("disquerd")


class MessageType(IntEnum):
    DEFAULT = 0
    RECIPIENT_ADD = 1
    RECIPIENT_REMOVE = 2
    CALL = 3
    CHANNEL_PINNED_MESSAGE = 6
    GUILD_MEMBER_JOIN = 7
    INTERACTION_CREATE = 20
    REPLY = 19
    CONTEXT_MENU_COMMAND = 23


class MessageFlags(IntEnum):
    NONE = 0
    CROSSPOSTED = 1 << 0
    SUPPRESS_EMBEDS = 1 << 2
    EPHEMERAL = 1 << 6
    LOADING = 1 << 7


class Attachment(msgspec.Struct, kw_only=True, omit_defaults=True):
    id: int
    filename: str = ""
    description: str | None = None
    content_type: str | None = None
    size: int = 0
    url: str = ""
    proxy_url: str = ""
    height: int | None = None
    width: int | None = None
    ephemeral: bool = False


class Message(msgspec.Struct, kw_only=True, omit_defaults=True):
    id: int
    channel_id: int
    guild_id: int | None = None
    content: str = ""
    timestamp: str | None = None
    edited_timestamp: str | None = None
    tts: bool = False
    mention_everyone: bool = False
    pinned: bool = False
    type: int = 0
    flags: int = 0
    webhook_id: int | None = None
    author_id: int | None = None

    @property
    def created_at(self) -> float:
        return Snowflake(self.id).timestamp

    @property
    def is_system(self) -> bool:
        return self.type != 0

    async def delete(self) -> None:
        if _rest:
            await _rest.delete_message(self.channel_id, self.id)

    async def edit(self, **kwargs: Any) -> dict[str, Any]:
        if _rest:
            return await _rest.edit_message(self.channel_id, self.id, **kwargs)
        return {}

    async def pin(self, *, reason: str | None = None) -> None:
        if _rest:
            await _rest._http.put(f"/channels/{self.channel_id}/pins/{self.id}", reason=reason, major_id=self.channel_id)

    async def unpin(self, *, reason: str | None = None) -> None:
        if _rest:
            await _rest._http.delete(f"/channels/{self.channel_id}/pins/{self.id}", reason=reason, major_id=self.channel_id)

    async def add_reaction(self, emoji: str) -> None:
        if _rest:
            await _rest._http.put(f"/channels/{self.channel_id}/messages/{self.id}/reactions/{emoji}/@me", major_id=self.channel_id)

    async def remove_reaction(self, emoji: str) -> None:
        if _rest:
            await _rest._http.delete(f"/channels/{self.channel_id}/messages/{self.id}/reactions/{emoji}/@me", major_id=self.channel_id)

    async def reply(self, content: str = "", **kwargs: Any) -> dict[str, Any]:
        kwargs.setdefault("message_reference", {"message_id": str(self.id), "channel_id": str(self.channel_id)})
        if self.guild_id:
            kwargs["message_reference"]["guild_id"] = str(self.guild_id)
        if _rest:
            return await _rest.create_message(self.channel_id, content=content, **kwargs)
        return {}

    def __repr__(self) -> str:
        return f"Message(id={self.id}, channel_id={self.channel_id})"

    def __eq__(self, other: object) -> bool:
        return isinstance(other, Message) and self.id == other.id

    def __hash__(self) -> int:
        return self.id
