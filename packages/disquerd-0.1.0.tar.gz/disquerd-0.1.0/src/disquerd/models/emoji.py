from __future__ import annotations

from typing import Any

import msgspec

from disquerd.utils.snowflake import Snowflake

__all__ = ("Emoji", "PartialEmoji")


class Emoji(msgspec.Struct, kw_only=True, omit_defaults=True):
    id: int
    guild_id: int = 0
    name: str = ""
    animated: bool = False
    managed: bool = False
    available: bool = True
    require_colons: bool = True

    @property
    def url(self) -> str:
        ext = "gif" if self.animated else "png"
        return f"https://cdn.discordapp.com/emojis/{self.id}.{ext}"

    @property
    def mention(self) -> str:
        if self.animated:
            return f"<a:{self.name}:{self.id}>"
        return f"<:{self.name}:{self.id}>"

    @property
    def created_at(self) -> float:
        return Snowflake(self.id).timestamp

    def __repr__(self) -> str:
        return f"Emoji(id={self.id}, name={self.name!r})"


class PartialEmoji(msgspec.Struct, kw_only=True, omit_defaults=True):
    id: int | None = None
    name: str | None = None
    animated: bool = False

    @property
    def is_custom(self) -> bool:
        return self.id is not None

    @property
    def mention(self) -> str:
        if self.id is None:
            return f":{self.name}:"
        if self.animated:
            return f"<a:{self.name}:{self.id}>"
        return f"<:{self.name}:{self.id}>"
