from __future__ import annotations

from typing import Any

import msgspec

from disquerd.utils.snowflake import Snowflake

__all__ = ("AllowedMentions", "Thread", "Invite", "Sticker", "ScheduledEvent", "AuditLogEntry")


class AllowedMentions(msgspec.Struct, kw_only=True, omit_defaults=True):
    parse: list[str] = []
    roles: list[int] = []
    users: list[int] = []
    replied_user: bool = False

    @classmethod
    def none(cls) -> AllowedMentions:
        return cls()

    @classmethod
    def all(cls) -> AllowedMentions:
        return cls(parse=["roles", "users", "everyone"], replied_user=True)

    @classmethod
    def only_users(cls) -> AllowedMentions:
        return cls(parse=["users"], replied_user=False)


class Thread(msgspec.Struct, kw_only=True, omit_defaults=True):
    id: int
    guild_id: int | None = None
    parent_id: int | None = None
    owner_id: int | None = None
    name: str = ""
    type: int = 11
    locked: bool = False
    slowmode_seconds: int = 0
    member_count: int = 0
    message_count: int = 0
    archived: bool = False
    auto_archive_duration: int = 60
    invitable: bool = True


class Invite(msgspec.Struct, kw_only=True, omit_defaults=True):
    code: str = ""
    guild_id: int | None = None
    channel_id: int | None = None
    inviter_id: int | None = None
    uses: int = 0
    max_uses: int = 0
    max_age: int = 0
    temporary: bool = False
    created_at: str | None = None

    @property
    def url(self) -> str:
        return f"https://discord.gg/{self.code}"

    def __repr__(self) -> str:
        return f"Invite(code={self.code!r})"


class Sticker(msgspec.Struct, kw_only=True, omit_defaults=True):
    id: int
    name: str = ""
    description: str | None = None
    pack_id: int | None = None
    format_type: int = 1
    tags: str = ""
    type: int = 1
    guild_id: int | None = None
    available: bool = True
    sort_value: int = 0

    @property
    def url(self) -> str:
        ext = {1: "png", 2: "apng", 3: "lottie"}.get(self.format_type, "png")
        return f"https://cdn.discordapp.com/stickers/{self.id}.{ext}"

    @property
    def created_at(self) -> float:
        return Snowflake(self.id).timestamp

    def __repr__(self) -> str:
        return f"Sticker(id={self.id}, name={self.name!r})"


class ScheduledEvent(msgspec.Struct, kw_only=True, omit_defaults=True):
    id: int
    guild_id: int | None = None
    name: str = ""
    description: str | None = None
    channel_id: int | None = None
    creator_id: int | None = None
    entity_type: int = 0
    status: int = 1
    entity_id: int | None = None
    scheduled_start_time: str | None = None
    scheduled_end_time: str | None = None
    user_count: int = 0
    privacy_level: int = 2

    @property
    def created_at(self) -> float:
        return Snowflake(self.id).timestamp

    def __repr__(self) -> str:
        return f"ScheduledEvent(id={self.id}, name={self.name!r})"


class AuditLogEntry(msgspec.Struct, kw_only=True, omit_defaults=True):
    id: int
    target_id: str | None = None
    user_id: int | None = None
    action_type: int = 0
    reason: str | None = None
    changes: list[dict[str, Any]] = []

    @property
    def created_at(self) -> float:
        return Snowflake(self.id).timestamp

    def __repr__(self) -> str:
        return f"AuditLogEntry(id={self.id}, action={self.action_type})"
