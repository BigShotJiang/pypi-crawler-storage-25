from __future__ import annotations

from enum import IntEnum
from typing import Any

import msgspec

from disquerd.utils.snowflake import Snowflake

__all__ = ("Interaction", "InteractionType", "InteractionResponseType")


class InteractionType(IntEnum):
    PING = 1
    APPLICATION_COMMAND = 2
    MESSAGE_COMPONENT = 3
    APPLICATION_COMMAND_AUTOCOMPLETE = 4
    MODAL_SUBMIT = 5


class InteractionResponseType(IntEnum):
    PONG = 1
    CHANNEL_MESSAGE_WITH_SOURCE = 4
    DEFERRED_CHANNEL_MESSAGE_WITH_SOURCE = 5
    DEFERRED_UPDATE_MESSAGE = 6
    UPDATE_MESSAGE = 7
    APPLICATION_COMMAND_AUTOCOMPLETE_RESULT = 8
    MODAL = 9


class _InteractionData:
    __slots__ = ("raw",)

    def __init__(self, raw: dict[str, Any]) -> None:
        self.raw = raw

    @property
    def _data(self) -> dict[str, Any]:
        return self.raw.get("data", {})

    @property
    def name(self) -> str | None:
        return self._data.get("name")

    @property
    def id(self) -> int | None:
        v = self._data.get("id")
        return int(v) if v else None

    @property
    def type(self) -> int | None:
        return self._data.get("type")

    @property
    def options(self) -> list[dict[str, Any]]:
        return self._data.get("options", [])

    @property
    def custom_id(self) -> str | None:
        return self._data.get("custom_id")

    @property
    def component_type(self) -> int | None:
        return self._data.get("component_type")

    @property
    def values(self) -> list[str]:
        return self._data.get("values", [])

    @property
    def resolved(self) -> dict[str, Any]:
        return self._data.get("resolved", {})

    @property
    def target_id(self) -> int | None:
        v = self._data.get("target_id")
        return int(v) if v else None

    @property
    def components(self) -> list[dict[str, Any]]:
        return self._data.get("components", [])

    @property
    def member(self) -> dict[str, Any]:
        return self.raw.get("member", {})

    @property
    def user(self) -> dict[str, Any]:
        return self.raw.get("user", self.member.get("user", {}))


_interaction_data_registry: dict[int, _InteractionData] = {}


def _set_interaction_data(interaction_id: int, raw: dict[str, Any]) -> None:
    _interaction_data_registry[interaction_id] = _InteractionData(raw)


def _get_interaction_data(interaction_id: int) -> _InteractionData:
    return _interaction_data_registry.get(interaction_id, _InteractionData({}))


class Interaction(msgspec.Struct, kw_only=True, omit_defaults=True):
    id: int
    application_id: int = 0
    type: int = 0
    token: str = ""
    version: int = 1
    guild_id: int | None = None
    channel_id: int | None = None
    locale: str | None = None
    guild_locale: str | None = None

    @property
    def data(self) -> _InteractionData:
        return _get_interaction_data(self.id)

    @data.setter
    def data(self, raw: dict[str, Any]) -> None:
        _set_interaction_data(self.id, raw)

    @property
    def command_name(self) -> str | None:
        return self.data.name

    @property
    def command_id(self) -> int | None:
        return self.data.id

    @property
    def command_type(self) -> int | None:
        return self.data.type

    @property
    def options(self) -> list[dict[str, Any]]:
        return self.data.options

    @property
    def custom_id(self) -> str | None:
        return self.data.custom_id

    @property
    def component_type(self) -> int | None:
        return self.data.component_type

    @property
    def values(self) -> list[str]:
        return self.data.values

    @property
    def resolved(self) -> dict[str, Any]:
        return self.data.resolved

    @property
    def target_id(self) -> int | None:
        return self.data.target_id

    @property
    def created_at(self) -> float:
        return Snowflake(self.id).timestamp

    @property
    def is_command(self) -> bool:
        return self.type == InteractionType.APPLICATION_COMMAND

    @property
    def is_component(self) -> bool:
        return self.type == InteractionType.MESSAGE_COMPONENT

    @property
    def is_modal_submit(self) -> bool:
        return self.type == InteractionType.MODAL_SUBMIT

    @property
    def is_autocomplete(self) -> bool:
        return self.type == InteractionType.APPLICATION_COMMAND_AUTOCOMPLETE

    def __repr__(self) -> str:
        return f"Interaction(id={self.id}, type={self.type})"
