from __future__ import annotations

import logging
from typing import Any

import msgspec

from disquerd.utils.snowflake import Snowflake
from disquerd._registry import _rest

__all__ = ("Channel", "TextChannel", "VoiceChannel", "DMChannel", "CategoryChannel", "PermissionOverwrite")

_log = logging.getLogger("disquerd")


class PermissionOverwrite(msgspec.Struct, kw_only=True, omit_defaults=True):
    id: int
    type: int = 0
    allow: str = "0"
    deny: str = "0"


class Channel(msgspec.Struct, kw_only=True, omit_defaults=True):
    id: int
    type: int = 0
    guild_id: int | None = None
    position: int = 0
    name: str = ""
    topic: str | None = None
    nsfw: bool = False
    last_message_id: int | None = None
    parent_id: int | None = None
    rate_limit_per_user: int = 0
    permission_overwrites: list[PermissionOverwrite] = []

    @property
    def type_name(self) -> str:
        _T = {0: "text", 1: "dm", 2: "voice", 3: "group_dm", 4: "category", 5: "announcement",
              10: "announcement_thread", 11: "public_thread", 12: "private_thread",
              13: "stage", 15: "forum", 16: "media"}
        return _T.get(self.type, "unknown")

    @property
    def mention(self) -> str:
        return f"<#{self.id}>"

    @property
    def created_at(self) -> float:
        return Snowflake(self.id).timestamp

    async def send(self, content: str = "", **kwargs: Any) -> dict[str, Any]:
        if _rest:
            return await _rest.create_message(self.id, content=content, **kwargs)
        return {}

    async def history(self, *, limit: int = 50, before: int | None = None) -> list[dict[str, Any]]:
        if _rest:
            return await _rest.get_messages(self.id, limit=limit, before=before)
        return []

    async def purge(self, *, limit: int = 100, before: int | None = None) -> list[int]:
        if not _rest:
            return []
        msgs = await _rest.get_messages(self.id, limit=limit, before=before)
        if not msgs:
            return []
        ids = [int(m.get("id", 0)) for m in msgs]
        await _rest.bulk_delete_messages(self.id, ids)
        return ids

    async def edit(self, **kwargs: Any) -> dict[str, Any]:
        if _rest:
            return await _rest._http.patch(f"/channels/{self.id}", json=kwargs, major_id=self.id)
        return {}

    async def delete(self) -> None:
        if _rest:
            await _rest._http.delete(f"/channels/{self.id}", major_id=self.id)

    async def create_invite(self, **kwargs: Any) -> dict[str, Any]:
        if _rest:
            return await _rest._http.post(f"/channels/{self.id}/invites", json=kwargs, major_id=self.id)
        return {}

    async def trigger_typing(self) -> None:
        if _rest:
            await _rest._http.post(f"/channels/{self.id}/typing", major_id=self.id)

    def __repr__(self) -> str:
        return f"Channel(id={self.id}, name={self.name!r}, type={self.type_name})"

    def __eq__(self, other: object) -> bool:
        return isinstance(other, Channel) and self.id == other.id

    def __hash__(self) -> int:
        return self.id


class TextChannel(Channel):
    pass


class VoiceChannel(Channel):
    bitrate: int = 64000
    user_limit: int = 0


class DMChannel(Channel):
    recipient_id: int | None = None


class CategoryChannel(Channel):
    pass
