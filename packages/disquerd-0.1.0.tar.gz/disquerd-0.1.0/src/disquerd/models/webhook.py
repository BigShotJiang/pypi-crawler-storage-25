from __future__ import annotations

from typing import Any

__all__ = ("Webhook",)


class Webhook:
    __slots__ = ("id", "type", "guild_id", "channel_id", "name", "avatar", "token", "application_id")

    def __init__(
        self,
        *,
        id: int,
        type: int = 1,
        channel_id: int = 0,
        name: str = "",
        token: str | None = None,
    ) -> None:
        self.id: int = id
        self.type = type
        self.guild_id: int | None = None
        self.channel_id = channel_id
        self.name = name
        self.avatar: str | None = None
        self.token = token
        self.application_id: int | None = None

    @classmethod
    def _from_raw(cls, data: dict[str, Any]) -> Webhook:
        wh = cls(
            id=int(data.get("id", 0)),
            type=data.get("type", 1),
            channel_id=int(data.get("channel_id", 0)),
            name=data.get("name", ""),
            token=data.get("token"),
        )
        wh.guild_id = _maybe_int(data.get("guild_id"))
        wh.avatar = data.get("avatar")
        wh.application_id = _maybe_int(data.get("application_id"))
        return wh

    def __repr__(self) -> str:
        return f"Webhook(id={self.id}, name={self.name!r})"


def _maybe_int(value: str | int | None) -> int | None:
    if value is None:
        return None
    return int(value)
