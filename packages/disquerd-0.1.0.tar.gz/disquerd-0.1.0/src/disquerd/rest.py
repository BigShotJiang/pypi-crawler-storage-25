from __future__ import annotations

from typing import Any

import aiohttp

from disquerd._http import HTTPClient

__all__ = ("RESTClient",)


class RESTClient:
    __slots__ = ("_http",)

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    async def get_gateway(self) -> str:
        data = await self._http.get("/gateway")
        return data["url"]

    async def get_gateway_bot(self) -> dict[str, Any]:
        return await self._http.get("/gateway/bot")

    async def get_user(self, user_id: int) -> dict[str, Any]:
        return await self._http.get(f"/users/{user_id}")

    async def get_current_user(self) -> dict[str, Any]:
        return await self._http.get("/users/@me")

    async def modify_current_user(self, *, username: str | None = None, avatar: str | None = None) -> dict[str, Any]:
        payload: dict[str, Any] = {}
        if username is not None:
            payload["username"] = username
        if avatar is not None:
            payload["avatar"] = avatar
        return await self._http.patch("/users/@me", json=payload)

    async def get_guild(self, guild_id: int) -> dict[str, Any]:
        return await self._http.get(f"/guilds/{guild_id}", major_id=guild_id)

    async def get_guild_channels(self, guild_id: int) -> list[dict[str, Any]]:
        data = await self._http.get(f"/guilds/{guild_id}/channels", major_id=guild_id)
        return data or []

    async def create_guild_channel(self, guild_id: int, *, name: str, **kwargs: Any) -> dict[str, Any]:
        payload: dict[str, Any] = {"name": name, **kwargs}
        return await self._http.post(f"/guilds/{guild_id}/channels", json=payload, major_id=guild_id)

    async def get_channel(self, channel_id: int) -> dict[str, Any]:
        return await self._http.get(f"/channels/{channel_id}", major_id=channel_id)

    async def get_message(self, channel_id: int, message_id: int) -> dict[str, Any]:
        return await self._http.get(f"/channels/{channel_id}/messages/{message_id}", major_id=channel_id)

    async def get_messages(
        self, channel_id: int, *, limit: int = 50, before: int | None = None, after: int | None = None
    ) -> list[dict[str, Any]]:
        params: dict[str, str] = {"limit": str(limit)}
        if before is not None:
            params["before"] = str(before)
        if after is not None:
            params["after"] = str(after)
        data = await self._http.get(f"/channels/{channel_id}/messages", params=params, major_id=channel_id)
        return data or []

    async def create_message(
        self,
        channel_id: int,
        *,
        content: str | None = None,
        embeds: list[dict[str, Any]] | None = None,
        tts: bool = False,
        **kwargs: Any,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {"tts": tts}
        if content is not None:
            payload["content"] = content
        if embeds is not None:
            payload["embeds"] = embeds
        payload.update(kwargs)
        return await self._http.post(f"/channels/{channel_id}/messages", json=payload, major_id=channel_id)

    async def edit_message(
        self, channel_id: int, message_id: int, *, content: str | None = None, **kwargs: Any
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {}
        if content is not None:
            payload["content"] = content
        payload.update(kwargs)
        return await self._http.patch(
            f"/channels/{channel_id}/messages/{message_id}", json=payload, major_id=channel_id
        )

    async def delete_message(self, channel_id: int, message_id: int, *, reason: str | None = None) -> None:
        await self._http.delete(
            f"/channels/{channel_id}/messages/{message_id}", reason=reason, major_id=channel_id
        )

    async def bulk_delete_messages(
        self, channel_id: int, message_ids: list[int], *, reason: str | None = None
    ) -> None:
        await self._http.post(
            f"/channels/{channel_id}/messages/bulk-delete",
            json={"messages": [str(mid) for mid in message_ids]},
            reason=reason,
            major_id=channel_id,
        )

    async def get_guild_member(self, guild_id: int, user_id: int) -> dict[str, Any]:
        return await self._http.get(f"/guilds/{guild_id}/members/{user_id}", major_id=guild_id)

    async def get_guild_members(
        self, guild_id: int, *, limit: int = 1, after: int | None = None
    ) -> list[dict[str, Any]]:
        params: dict[str, str] = {"limit": str(limit)}
        if after is not None:
            params["after"] = str(after)
        data = await self._http.get(f"/guilds/{guild_id}/members", params=params, major_id=guild_id)
        return data or []

    async def modify_guild_member(self, guild_id: int, user_id: int, **kwargs: Any) -> dict[str, Any]:
        return await self._http.patch(f"/guilds/{guild_id}/members/{user_id}", json=kwargs, major_id=guild_id)

    async def remove_guild_member(self, guild_id: int, user_id: int, *, reason: str | None = None) -> None:
        await self._http.delete(f"/guilds/{guild_id}/members/{user_id}", reason=reason, major_id=guild_id)

    async def add_guild_member_role(
        self, guild_id: int, user_id: int, role_id: int, *, reason: str | None = None
    ) -> None:
        await self._http.put(
            f"/guilds/{guild_id}/members/{user_id}/roles/{role_id}", reason=reason, major_id=guild_id
        )

    async def remove_guild_member_role(
        self, guild_id: int, user_id: int, role_id: int, *, reason: str | None = None
    ) -> None:
        await self._http.delete(
            f"/guilds/{guild_id}/members/{user_id}/roles/{role_id}", reason=reason, major_id=guild_id
        )

    async def create_interaction_response(
        self, interaction_id: int, interaction_token: str, *, data: dict[str, Any]
    ) -> None:
        await self._http.post(
            f"/interactions/{interaction_id}/{interaction_token}/callback",
            json=data,
        )

    async def create_followup_message(
        self, application_id: int, interaction_token: str, *, data: dict[str, Any]
    ) -> dict[str, Any]:
        return await self._http.post(
            f"/webhooks/{application_id}/{interaction_token}",
            json=data,
        )

    async def get_original_interaction_response(
        self, application_id: int, interaction_token: str
    ) -> dict[str, Any]:
        return await self._http.get(
            f"/webhooks/{application_id}/{interaction_token}/messages/@original",
        )

    async def edit_original_interaction_response(
        self, application_id: int, interaction_token: str, *, data: dict[str, Any]
    ) -> dict[str, Any]:
        return await self._http.patch(
            f"/webhooks/{application_id}/{interaction_token}/messages/@original",
            json=data,
        )

    async def delete_original_interaction_response(
        self, application_id: int, interaction_token: str
    ) -> None:
        await self._http.delete(
            f"/webhooks/{application_id}/{interaction_token}/messages/@original",
        )

    async def get_global_application_commands(self, application_id: int) -> list[dict[str, Any]]:
        data = await self._http.get(f"/applications/{application_id}/commands")
        return data or []

    async def create_global_application_command(
        self, application_id: int, *, data: dict[str, Any]
    ) -> dict[str, Any]:
        return await self._http.post(f"/applications/{application_id}/commands", json=data)

    async def get_global_application_command(self, application_id: int, command_id: int) -> dict[str, Any]:
        return await self._http.get(f"/applications/{application_id}/commands/{command_id}")

    async def edit_global_application_command(
        self, application_id: int, command_id: int, *, data: dict[str, Any]
    ) -> dict[str, Any]:
        return await self._http.patch(
            f"/applications/{application_id}/commands/{command_id}", json=data
        )

    async def delete_global_application_command(self, application_id: int, command_id: int) -> None:
        await self._http.delete(f"/applications/{application_id}/commands/{command_id}")

    async def bulk_overwrite_global_application_commands(
        self, application_id: int, *, data: list[dict[str, Any]]
    ) -> list[dict[str, Any]]:
        result = await self._http.put(f"/applications/{application_id}/commands", json=data)
        return result or []

    async def get_guild_application_commands(
        self, application_id: int, guild_id: int
    ) -> list[dict[str, Any]]:
        data = await self._http.get(
            f"/applications/{application_id}/guilds/{guild_id}/commands", major_id=guild_id
        )
        return data or []

    async def create_guild_application_command(
        self, application_id: int, guild_id: int, *, data: dict[str, Any]
    ) -> dict[str, Any]:
        return await self._http.post(
            f"/applications/{application_id}/guilds/{guild_id}/commands", json=data, major_id=guild_id
        )

    async def delete_guild_application_command(
        self, application_id: int, guild_id: int, command_id: int
    ) -> None:
        await self._http.delete(
            f"/applications/{application_id}/guilds/{guild_id}/commands/{command_id}", major_id=guild_id
        )

    async def bulk_overwrite_guild_application_commands(
        self, application_id: int, guild_id: int, *, data: list[dict[str, Any]]
    ) -> list[dict[str, Any]]:
        result = await self._http.put(
            f"/applications/{application_id}/guilds/{guild_id}/commands",
            json=data,
            major_id=guild_id,
        )
        return result or []

    async def create_guild_ban(
        self, guild_id: int, user_id: int, *, delete_message_days: int = 0, reason: str | None = None
    ) -> None:
        await self._http.put(
            f"/guilds/{guild_id}/bans/{user_id}",
            json={"delete_message_days": delete_message_days},
            reason=reason,
            major_id=guild_id,
        )

    async def remove_guild_ban(self, guild_id: int, user_id: int, *, reason: str | None = None) -> None:
        await self._http.delete(f"/guilds/{guild_id}/bans/{user_id}", reason=reason, major_id=guild_id)

    async def get_guild_bans(self, guild_id: int, *, limit: int | None = None, before: int | None = None, after: int | None = None) -> list[dict[str, Any]]:
        params: dict[str, str] = {}
        if limit is not None:
            params["limit"] = str(limit)
        if before is not None:
            params["before"] = str(before)
        if after is not None:
            params["after"] = str(after)
        data = await self._http.get(f"/guilds/{guild_id}/bans", params=params or None, major_id=guild_id)
        return data or []

    async def get_guild_ban(self, guild_id: int, user_id: int) -> dict[str, Any]:
        return await self._http.get(f"/guilds/{guild_id}/bans/{user_id}", major_id=guild_id)

    async def get_guild_prune_count(self, guild_id: int, *, days: int = 7, include_roles: list[int] | None = None) -> int:
        params: dict[str, str] = {"days": str(days)}
        if include_roles:
            params["include_roles"] = ",".join(str(r) for r in include_roles)
        data = await self._http.get(f"/guilds/{guild_id}/prune", params=params, major_id=guild_id)
        return data.get("pruned", 0)

    async def begin_guild_prune(self, guild_id: int, *, days: int = 7, reason: str | None = None, include_roles: list[int] | None = None) -> int | None:
        payload: dict[str, Any] = {"days": days}
        if include_roles:
            payload["include_roles"] = [str(r) for r in include_roles]
        data = await self._http.post(f"/guilds/{guild_id}/prune", json=payload, reason=reason, major_id=guild_id)
        return data.get("pruned")

    async def get_guild_emojis(self, guild_id: int) -> list[dict[str, Any]]:
        data = await self._http.get(f"/guilds/{guild_id}/emojis", major_id=guild_id)
        return data or []

    async def get_guild_emoji(self, guild_id: int, emoji_id: int) -> dict[str, Any]:
        return await self._http.get(f"/guilds/{guild_id}/emojis/{emoji_id}", major_id=guild_id)

    async def create_guild_emoji(self, guild_id: int, *, name: str, image: str, roles: list[int] | None = None, reason: str | None = None) -> dict[str, Any]:
        payload: dict[str, Any] = {"name": name, "image": image}
        if roles is not None:
            payload["roles"] = [str(r) for r in roles]
        return await self._http.post(f"/guilds/{guild_id}/emojis", json=payload, reason=reason, major_id=guild_id)

    async def modify_guild_emoji(self, guild_id: int, emoji_id: int, *, name: str | None = None, roles: list[int] | None = None, reason: str | None = None) -> dict[str, Any]:
        payload: dict[str, Any] = {}
        if name is not None:
            payload["name"] = name
        if roles is not None:
            payload["roles"] = [str(r) for r in roles]
        return await self._http.patch(f"/guilds/{guild_id}/emojis/{emoji_id}", json=payload, reason=reason, major_id=guild_id)

    async def delete_guild_emoji(self, guild_id: int, emoji_id: int, *, reason: str | None = None) -> None:
        await self._http.delete(f"/guilds/{guild_id}/emojis/{emoji_id}", reason=reason, major_id=guild_id)

    async def get_guild_stickers(self, guild_id: int) -> list[dict[str, Any]]:
        data = await self._http.get(f"/guilds/{guild_id}/stickers", major_id=guild_id)
        return data or []

    async def get_guild_sticker(self, guild_id: int, sticker_id: int) -> dict[str, Any]:
        return await self._http.get(f"/guilds/{guild_id}/stickers/{sticker_id}", major_id=guild_id)

    async def create_guild_sticker(self, guild_id: int, *, name: str, description: str, tags: str, file: bytes, reason: str | None = None) -> dict[str, Any]:
        form = aiohttp.FormData()
        form.add_field("name", name)
        form.add_field("description", description)
        form.add_field("tags", tags)
        form.add_field("file", file, filename="sticker.png", content_type="image/png")
        return await self._http.post_multipart(f"/guilds/{guild_id}/stickers", form=form, reason=reason, major_id=guild_id)

    async def modify_guild_sticker(self, guild_id: int, sticker_id: int, *, name: str | None = None, description: str | None = None, tags: str | None = None, reason: str | None = None) -> dict[str, Any]:
        payload: dict[str, Any] = {}
        if name is not None:
            payload["name"] = name
        if description is not None:
            payload["description"] = description
        if tags is not None:
            payload["tags"] = tags
        return await self._http.patch(f"/guilds/{guild_id}/stickers/{sticker_id}", json=payload, reason=reason, major_id=guild_id)

    async def delete_guild_sticker(self, guild_id: int, sticker_id: int, *, reason: str | None = None) -> None:
        await self._http.delete(f"/guilds/{guild_id}/stickers/{sticker_id}", reason=reason, major_id=guild_id)

    async def get_channel_webhooks(self, channel_id: int) -> list[dict[str, Any]]:
        data = await self._http.get(f"/channels/{channel_id}/webhooks", major_id=channel_id)
        return data or []

    async def get_guild_webhooks(self, guild_id: int) -> list[dict[str, Any]]:
        data = await self._http.get(f"/guilds/{guild_id}/webhooks", major_id=guild_id)
        return data or []

    async def create_webhook(self, channel_id: int, *, name: str, avatar: str | None = None, reason: str | None = None) -> dict[str, Any]:
        payload: dict[str, Any] = {"name": name}
        if avatar is not None:
            payload["avatar"] = avatar
        return await self._http.post(f"/channels/{channel_id}/webhooks", json=payload, reason=reason, major_id=channel_id)

    async def get_webhook(self, webhook_id: int) -> dict[str, Any]:
        return await self._http.get(f"/webhooks/{webhook_id}")

    async def modify_webhook(self, webhook_id: int, *, name: str | None = None, avatar: str | None = None, channel_id: int | None = None, reason: str | None = None) -> dict[str, Any]:
        payload: dict[str, Any] = {}
        if name is not None:
            payload["name"] = name
        if avatar is not None:
            payload["avatar"] = avatar
        if channel_id is not None:
            payload["channel_id"] = str(channel_id)
        return await self._http.patch(f"/webhooks/{webhook_id}", json=payload, reason=reason)

    async def delete_webhook(self, webhook_id: int, *, reason: str | None = None) -> None:
        await self._http.delete(f"/webhooks/{webhook_id}", reason=reason)

    async def execute_webhook(self, webhook_id: int, webhook_token: str, *, content: str | None = None, embeds: list[dict[str, Any]] | None = None, username: str | None = None, avatar_url: str | None = None, tts: bool = False, wait: bool = False) -> dict[str, Any] | None:
        payload: dict[str, Any] = {"tts": tts}
        if content is not None:
            payload["content"] = content
        if embeds is not None:
            payload["embeds"] = embeds
        if username is not None:
            payload["username"] = username
        if avatar_url is not None:
            payload["avatar_url"] = avatar_url
        params: dict[str, str] | None = {"wait": "true"} if wait else None
        return await self._http.post(f"/webhooks/{webhook_id}/{webhook_token}", json=payload, params=params)

    async def get_guild_invites(self, guild_id: int) -> list[dict[str, Any]]:
        data = await self._http.get(f"/guilds/{guild_id}/invites", major_id=guild_id)
        return data or []

    async def get_invite(self, invite_code: str, *, with_counts: bool = False) -> dict[str, Any]:
        params: dict[str, str] | None = {"with_counts": "true"} if with_counts else None
        return await self._http.get(f"/invites/{invite_code}", params=params)

    async def delete_invite(self, invite_code: str, *, reason: str | None = None) -> dict[str, Any]:
        return await self._http.delete(f"/invites/{invite_code}", reason=reason)

    async def create_channel_invite(self, channel_id: int, *, max_age: int = 86400, max_uses: int = 0, temporary: bool = False, unique: bool = False, reason: str | None = None) -> dict[str, Any]:
        payload: dict[str, Any] = {"max_age": max_age, "max_uses": max_uses, "temporary": temporary, "unique": unique}
        return await self._http.post(f"/channels/{channel_id}/invites", json=payload, reason=reason, major_id=channel_id)

    async def get_pinned_messages(self, channel_id: int) -> list[dict[str, Any]]:
        data = await self._http.get(f"/channels/{channel_id}/pins", major_id=channel_id)
        return data or []

    async def get_channel_message(self, channel_id: int, message_id: int) -> dict[str, Any]:
        return await self._http.get(f"/channels/{channel_id}/messages/{message_id}", major_id=channel_id)

    async def crosspost_message(self, channel_id: int, message_id: int) -> dict[str, Any]:
        return await self._http.post(f"/channels/{channel_id}/messages/{message_id}/crosspost", major_id=channel_id)

    async def get_reactions(self, channel_id: int, message_id: int, emoji: str, *, limit: int = 25, after: int | None = None) -> list[dict[str, Any]]:
        params: dict[str, str] = {"limit": str(limit)}
        if after is not None:
            params["after"] = str(after)
        data = await self._http.get(f"/channels/{channel_id}/messages/{message_id}/reactions/{emoji}", params=params, major_id=channel_id)
        return data or []

    async def delete_all_reactions(self, channel_id: int, message_id: int) -> None:
        await self._http.delete(f"/channels/{channel_id}/messages/{message_id}/reactions", major_id=channel_id)

    async def delete_all_reactions_for_emoji(self, channel_id: int, message_id: int, emoji: str) -> None:
        await self._http.delete(f"/channels/{channel_id}/messages/{message_id}/reactions/{emoji}", major_id=channel_id)

    async def modify_guild_channel_positions(self, guild_id: int, positions: list[dict[str, int]]) -> None:
        await self._http.patch(f"/guilds/{guild_id}/channels", json=positions, major_id=guild_id)

    async def modify_guild_role_positions(self, guild_id: int, positions: list[dict[str, int]]) -> list[dict[str, Any]]:
        data = await self._http.patch(f"/guilds/{guild_id}/roles", json=positions, major_id=guild_id)
        return data or []

    async def modify_guild_role(self, guild_id: int, role_id: int, *, name: str | None = None, permissions: int | None = None, color: int | None = None, hoist: bool | None = None, mentionable: bool | None = None, reason: str | None = None) -> dict[str, Any]:
        payload: dict[str, Any] = {}
        if name is not None:
            payload["name"] = name
        if permissions is not None:
            payload["permissions"] = str(permissions)
        if color is not None:
            payload["color"] = color
        if hoist is not None:
            payload["hoist"] = hoist
        if mentionable is not None:
            payload["mentionable"] = mentionable
        return await self._http.patch(f"/guilds/{guild_id}/roles/{role_id}", json=payload, reason=reason, major_id=guild_id)

    async def delete_guild_role(self, guild_id: int, role_id: int, *, reason: str | None = None) -> None:
        await self._http.delete(f"/guilds/{guild_id}/roles/{role_id}", reason=reason, major_id=guild_id)

    async def get_guild_voice_regions(self, guild_id: int) -> list[dict[str, Any]]:
        data = await self._http.get(f"/guilds/{guild_id}/regions", major_id=guild_id)
        return data or []

    async def list_voice_regions(self) -> list[dict[str, Any]]:
        data = await self._http.get("/voice/regions")
        return data or []

    async def modify_current_user_voice_state(self, guild_id: int, **kwargs: Any) -> None:
        await self._http.patch(f"/guilds/{guild_id}/voice-states/@me", json=kwargs, major_id=guild_id)

    async def modify_user_voice_state(self, guild_id: int, user_id: int, **kwargs: Any) -> None:
        await self._http.patch(f"/guilds/{guild_id}/voice-states/{user_id}", json=kwargs, major_id=guild_id)

    async def get_guild_audit_log(self, guild_id: int, *, user_id: int | None = None, action_type: int | None = None, before: int | None = None, limit: int = 50) -> dict[str, Any]:
        params: dict[str, str] = {"limit": str(limit)}
        if user_id is not None:
            params["user_id"] = str(user_id)
        if action_type is not None:
            params["action_type"] = str(action_type)
        if before is not None:
            params["before"] = str(before)
        return await self._http.get(f"/guilds/{guild_id}/audit-logs", params=params, major_id=guild_id)

    async def get_current_user_guilds(self, *, before: int | None = None, after: int | None = None, limit: int = 200) -> list[dict[str, Any]]:
        params: dict[str, str] = {"limit": str(limit)}
        if before is not None:
            params["before"] = str(before)
        if after is not None:
            params["after"] = str(after)
        data = await self._http.get("/users/@me/guilds", params=params)
        return data or []

    async def leave_guild(self, guild_id: int) -> None:
        await self._http.delete(f"/users/@me/guilds/{guild_id}")

    async def create_guild_role(self, guild_id: int, *, name: str, **kwargs: Any) -> dict[str, Any]:
        payload: dict[str, Any] = {"name": name, **kwargs}
        return await self._http.post(f"/guilds/{guild_id}/roles", json=payload, major_id=guild_id)

    async def edit_channel(self, channel_id: int, **kwargs: Any) -> dict[str, Any]:
        return await self._http.patch(f"/channels/{channel_id}", json=kwargs, major_id=channel_id)

    async def trigger_typing(self, channel_id: int) -> None:
        await self._http.post(f"/channels/{channel_id}/typing", major_id=channel_id)

    async def add_reaction(self, channel_id: int, message_id: int, emoji: str) -> None:
        await self._http.put(
            f"/channels/{channel_id}/messages/{message_id}/reactions/{emoji}/@me",
            major_id=channel_id,
        )

    async def remove_reaction(self, channel_id: int, message_id: int, emoji: str) -> None:
        await self._http.delete(
            f"/channels/{channel_id}/messages/{message_id}/reactions/{emoji}/@me",
            major_id=channel_id,
        )

    async def pin_message(self, channel_id: int, message_id: int) -> None:
        await self._http.put(
            f"/channels/{channel_id}/pins/{message_id}",
            major_id=channel_id,
        )

    async def unpin_message(self, channel_id: int, message_id: int) -> None:
        await self._http.delete(
            f"/channels/{channel_id}/pins/{message_id}",
            major_id=channel_id,
        )

    async def close(self) -> None:
        await self._http.close()
