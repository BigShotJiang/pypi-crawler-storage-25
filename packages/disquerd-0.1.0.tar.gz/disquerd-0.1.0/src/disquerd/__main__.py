from __future__ import annotations

import argparse
import os
import sys

__all__ = ("cli",)

_TEMPLATE_MAIN = '''"""A bot created with Disquerd."""
import disquerd

bot = disquerd.Bot("YOUR_TOKEN_HERE")


@bot.slash_command(name="ping", description="Check bot latency")
async def ping(ctx):
    await ctx.respond("Pong! 🏓")


@bot.event(disquerd.EventType.READY)
async def on_ready():
    print(f"Logged in as {bot.user}")


if __name__ == "__main__":
    bot.run()
'''

_TEMPLATE_ENV = '''# Disquerd Bot Configuration
DISCORD_TOKEN=YOUR_TOKEN_HERE
'''

_TEMPLATE_GITIGNORE = '''__pycache__/
*.pyc
.env
venv/
.venv/
*.egg-info/
dist/
build/
'''


def _init_project(name: str) -> None:
    base = os.path.join(os.getcwd(), name)
    src = os.path.join(base, "src")

    os.makedirs(src, exist_ok=True)

    main_path = os.path.join(src, "bot.py")
    if os.path.exists(main_path):
        print(f"Error: {main_path} already exists")
        sys.exit(1)

    with open(main_path, "w", encoding="utf-8") as f:
        f.write(_TEMPLATE_MAIN)

    env_path = os.path.join(base, ".env.example")
    with open(env_path, "w", encoding="utf-8") as f:
        f.write(_TEMPLATE_ENV)

    gitignore_path = os.path.join(base, ".gitignore")
    with open(gitignore_path, "w", encoding="utf-8") as f:
        f.write(_TEMPLATE_GITIGNORE)

    print(f"Created project: {name}/")
    print(f"  {name}/src/bot.py")
    print(f"  {name}/.env.example")
    print(f"  {name}/.gitignore")
    print()
    print("Next steps:")
    print(f"  1. cd {name}")
    print("  2. Edit .env.example -> .env with your token")
    print("  3. pip install disquerd")
    print("  4. python src/bot.py")


def cli() -> None:
    parser = argparse.ArgumentParser(
        prog="disquerd",
        description="Disquerd - Modern Discord bot framework",
    )
    subparsers = parser.add_subparsers(dest="command")

    init_parser = subparsers.add_parser("init", help="Create a new bot project")
    init_parser.add_argument("name", help="Project name")

    subparsers.add_parser("version", help="Show version")

    args = parser.parse_args()

    match args.command:
        case "init":
            _init_project(args.name)
        case "version":
            from disquerd import __version__
            print(f"Disquerd v{__version__}")
        case _:
            parser.print_help()


if __name__ == "__main__":
    cli()
