from __future__ import annotations

import logging
import os
import re
import sys
from datetime import datetime

__all__ = ("DisquerdFormatter", "setup_logging", "verbose_logging", "log_command", "log_guild_join", "log_guild_leave")

if sys.platform == "win32":
    os.environ.setdefault("PYTHONIOENCODING", "utf-8")
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

_A = {
    "r": "\033[0m", "b": "\033[1m", "d": "\033[2m",
    "rd": "\033[31m", "gn": "\033[32m", "yl": "\033[33m",
    "bl": "\033[34m", "mg": "\033[35m", "cy": "\033[36m", "wh": "\033[37m",
    "bg_rd": "\033[41m", "bg_gn": "\033[42m", "bg_yl": "\033[43m",
    "bg_bl": "\033[44m", "bg_mg": "\033[45m",
    "brbk": "\033[90m", "brrd": "\033[91m", "brgn": "\033[92m",
    "bryl": "\033[93m", "brbl": "\033[94m", "brmg": "\033[95m",
    "brcy": "\033[96m", "brwh": "\033[97m",
}

_ANSI_RE = re.compile(r"\033\[[0-9;]*m")


def _visible_len(s: str) -> int:
    return len(_ANSI_RE.sub("", s))


def _pad(s: str, width: int) -> str:
    vis = _visible_len(s)
    return s + " " * max(0, width - vis)


_LEVEL_STYLES = {
    logging.DEBUG: (" DBG ", "bg_bl", "wh", "brbk"),
    logging.INFO: (" INFO", "bg_gn", "wh", "brwh"),
    logging.WARNING: (" WARN", "bg_yl", "bk", "bryl"),
    logging.ERROR: (" ERR ", "bg_rd", "wh", "brrd"),
    logging.CRITICAL: (" CRIT", "bg_mg", "wh", "brrd"),
}


class DisquerdFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        badge_text, badge_bg, badge_fg, msg_color = _LEVEL_STYLES.get(
            record.levelno, _LEVEL_STYLES[logging.INFO]
        )
        now = datetime.now()
        ts = f"{now.strftime('%H:%M:%S')}.{now.microsecond // 1000:03d}"
        badge = f"{_A[badge_bg]}{_A[badge_fg]}{_A['b']}{badge_text}{_A['r']}"
        ts_str = f"{_A['d']}{ts}{_A['r']}"
        sep = f"{_A['d']}\u2502{_A['r']}"
        mod = record.name.replace("disquerd.", "").split(".")[-1]
        mod_str = f"{_A['brcy']}{mod}{_A['r']}"
        message = f"{_A[msg_color]}{record.getMessage()}{_A['r']}"
        line = f" {badge} {ts_str} {sep} {mod_str} {sep} {message}"
        if record.exc_info and record.exc_info[1] is not None:
            import traceback
            tb = "".join(traceback.format_exception(*record.exc_info))
            line += f"\n{_A['brrd']}{tb}{_A['r']}"
        return line


def _banner(user_name: str = "", guild_count: int = 0, cmd_count: int = 0, latency: float = 0) -> str:
    a = _A
    P = a["brmg"] + a["b"]
    R = a["r"]

    W = 40

    lines = [
        "",
        f"  {P}{_pad(f'  {a["b"]}{a["brmg"]}d{R}{a["b"]}{a["brwh"]}isquerd{R} {a["d"]}v0.1.0', W)}{P}{R}",
    ]
    if user_name:
        lines.append(f"  {P}{_pad(f'  {a["brwh"]}{a["b"]}{user_name}{R}', W)}{P}{R}")
    lines.append(f"  {P}{_pad(f'  {a["brcy"]}{guild_count}{R} guilds  {a["brmg"]}\u2022{R}  {a["brcy"]}{cmd_count}{R} commands', W)}{P}{R}")
    if latency:
        lines.append(f"  {P}{_pad(f'  {a["brgn"]}\u2713{R} {a["brwh"]}Connected{R} {a["d"]}~{latency:.0f}ms{R}', W)}{P}{R}")
    else:
        lines.append(f"  {P}{_pad(f'  {a["brgn"]}\u2713{R} {a["brwh"]}Connected{R}', W)}{P}{R}")
    lines.append("")
    return "\n".join(lines)


def _make_handler() -> logging.StreamHandler:
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(DisquerdFormatter())
    return handler


def setup_logging(level: int = logging.WARNING) -> None:
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    root = logging.getLogger("disquerd")
    root.handlers.clear()
    root.addHandler(_make_handler())
    root.setLevel(level)


def verbose_logging() -> None:
    setup_logging(level=logging.DEBUG)


_log = logging.getLogger("disquerd")


def log_command(command_name: str, *, guild_name: str | None = None, author: str | None = None) -> None:
    where = guild_name or "DM"
    who = author or "unknown"
    _log.info(f"{_A['brmg']}/{command_name}{_A['r']} by {_A['brcy']}{who}{_A['r']} in {_A['brgn']}{where}{_A['r']}")


def log_guild_join(name: str, member_count: int) -> None:
    _log.info(f"Joined {_A['brgn']}{_A['b']}{name}{_A['r']} ({_A['brcy']}{member_count}{_A['r']} members)")


def log_guild_leave(name: str) -> None:
    _log.info(f"Left {_A['brrd']}{name}{_A['r']}")
