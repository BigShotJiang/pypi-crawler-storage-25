from __future__ import annotations

__all__ = ("CommandError", "CommandCheckFailure", "CommandOnCooldown", "BadArgument", "MemberNotMuted", "CommandInvokeError")


class CommandError(Exception):
    __slots__ = ("command_name", "message")

    def __init__(self, command_name: str = "", message: str = "") -> None:
        self.command_name = command_name
        self.message = message
        super().__init__(message or f"Command error in '{command_name}'")


class CommandCheckFailure(CommandError):
    __slots__ = ()

    def __init__(self, command_name: str = "", message: str = "Check failed") -> None:
        super().__init__(command_name=command_name, message=message)


class CommandOnCooldown(CommandError):
    __slots__ = ("retry_after",)

    def __init__(self, retry_after: float, command_name: str = "") -> None:
        self.retry_after = retry_after
        super().__init__(command_name=command_name, message=f"Cooldown, retry after {retry_after:.1f}s")


class BadArgument(CommandError):
    __slots__ = ("argument",)

    def __init__(self, argument: str = "", command_name: str = "") -> None:
        self.argument = argument
        super().__init__(command_name=command_name, message=f"Bad argument: {argument!r}")


class MemberNotMuted(CommandError):
    __slots__ = ()

    def __init__(self, command_name: str = "") -> None:
        super().__init__(command_name=command_name, message="Member is not muted")


class CommandInvokeError(CommandError):
    __slots__ = ("original",)

    def __init__(self, original: Exception, command_name: str = "") -> None:
        self.original = original
        super().__init__(command_name=command_name, message=str(original))
