from disquerd.errors.gateway import GatewayError
from disquerd.errors.rest import RESTError, HTTPError, RateLimitError, UnauthorizedError, ForbiddenError, NotFoundError
from disquerd.errors.command import (
    CommandError, CommandCheckFailure, CommandOnCooldown, BadArgument,
    MemberNotMuted, CommandInvokeError,
)

__all__ = (
    "GatewayError",
    "RESTError",
    "HTTPError",
    "RateLimitError",
    "UnauthorizedError",
    "ForbiddenError",
    "NotFoundError",
    "CommandError",
    "CommandCheckFailure",
    "CommandOnCooldown",
    "BadArgument",
    "MemberNotMuted",
    "CommandInvokeError",
)
