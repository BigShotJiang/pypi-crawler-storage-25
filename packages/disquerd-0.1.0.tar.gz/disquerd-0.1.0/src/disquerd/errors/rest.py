from __future__ import annotations

import typing

__all__ = ("RESTError", "HTTPError", "RateLimitError", "UnauthorizedError", "ForbiddenError", "NotFoundError")


class RESTError(Exception):
    __slots__ = ("status", "code", "message")

    def __init__(self, status: int, code: int | None = None, message: str = "") -> None:
        self.status = status
        self.code = code
        self.message = message
        super().__init__(message or f"REST error (status={status})")

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(status={self.status}, code={self.code!r})"


class HTTPError(RESTError):
    __slots__ = ()


class RateLimitError(RESTError):
    __slots__ = ("retry_after",)

    def __init__(self, retry_after: float, status: int = 429, code: int | None = None) -> None:
        self.retry_after = retry_after
        super().__init__(status=status, code=code, message=f"Rate limited, retry after {retry_after}s")


class UnauthorizedError(RESTError):
    __slots__ = ()

    def __init__(self, code: int | None = None) -> None:
        super().__init__(status=401, code=code, message="Unauthorized")


class ForbiddenError(RESTError):
    __slots__ = ()

    def __init__(self, code: int | None = None) -> None:
        super().__init__(status=403, code=code, message="Forbidden")


class NotFoundError(RESTError):
    __slots__ = ()

    def __init__(self, code: int | None = None) -> None:
        super().__init__(status=404, code=code, message="Not Found")
