from __future__ import annotations

__all__ = ("GatewayError",)


class GatewayError(Exception):
    __slots__ = ("code", "message")

    def __init__(self, code: int | None = None, message: str = "") -> None:
        self.code = code
        self.message = message
        super().__init__(message or f"Gateway error (code={code})")

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(code={self.code!r}, message={self.message!r})"
