from __future__ import annotations

import asyncio
import sys
import logging
from typing import Any

__all__ = ("TestMode",)

_log = logging.getLogger("disquerd.test_mode")


class TestMode:
    __slots__ = ("_bot", "_rest", "_running", "_channel_id")

    def __init__(self, bot: Any, *, channel_id: int | None = None) -> None:
        self._bot = bot
        self._rest = bot._rest
        self._running = False
        self._channel_id = channel_id

    async def start(self) -> None:
        self._running = True
        await self._bot.wait_until_ready()

        from disquerd.log import _ANSI
        print()
        print(f'  {_ANSI["bold"]}{_ANSI["bright_yellow"]}Test Mode Active{_ANSI["reset"]}')
        print(f'  {_ANSI["dim"]}Type messages to send as the bot. Commands:{_ANSI["reset"]}')
        print(f'    {_ANSI["bright_cyan"]}/channel <id>{_ANSI["reset"]}  - Set target channel')
        print(f'    {_ANSI["bright_cyan"]}/guilds{_ANSI["reset"]}         - List guilds')
        print(f'    {_ANSI["bright_cyan"]}/channels <gid>{_ANSI["reset"]} - List channels in guild')
        print(f'    {_ANSI["bright_cyan"]}/exit{_ANSI["reset"]}           - Stop test mode')
        print()

        loop = asyncio.get_event_loop()
        while self._running:
            try:
                line = await loop.run_in_executor(None, self._read_input)
                if line is None:
                    continue
                await self._handle_input(line.strip())
            except (EOFError, KeyboardInterrupt):
                break
            except Exception as e:
                _log.error("Test mode error: %s", e)

    def _read_input(self) -> str | None:
        try:
            return input("> ")
        except (EOFError, KeyboardInterrupt):
            self._running = False
            return None

    async def _handle_input(self, line: str) -> None:
        from disquerd.log import _ANSI

        if not line:
            return

        if line == "/exit":
            print(f'  {_ANSI["bright_yellow"]}Exiting test mode...{_ANSI["reset"]}')
            self._running = False
            return

        if line.startswith("/channel "):
            try:
                self._channel_id = int(line.split()[1])
                ch = self._bot.get_channel(self._channel_id)
                ch_name = ch.name if ch else "unknown"
                print(f'  {_ANSI["bright_green"]}Target channel set to {_ANSI["bold"]}#{ch_name}{_ANSI["reset"]} ({self._channel_id})')
            except (ValueError, IndexError):
                print(f'  {_ANSI["bright_red"]}Invalid channel ID{_ANSI["reset"]}')
            return

        if line == "/guilds":
            guilds = self._bot.guilds
            for g in guilds[:20]:
                print(f'  {_ANSI["bright_cyan"]}{g.id}{_ANSI["reset"]} {_ANSI["dim"]}│{_ANSI["reset"]} {g.name}')
            if len(guilds) > 20:
                print(f'  {_ANSI["dim"]}... and {len(guilds) - 20} more{_ANSI["reset"]}')
            return

        if line.startswith("/channels "):
            try:
                guild_id = int(line.split()[1])
                channels = self._bot.state.get_guild_channels(guild_id)
                for ch in channels[:20]:
                    print(f'  {_ANSI["bright_cyan"]}{ch.id}{_ANSI["reset"]} {_ANSI["dim"]}│{_ANSI["reset"]} #{"ch.name"}')
            except (ValueError, IndexError):
                print(f'  {_ANSI["bright_red"]}Invalid guild ID{_ANSI["reset"]}')
            return

        if not self._channel_id:
            print(f'  {_ANSI["bright_red"]}Set a channel first: {_ANSI["bold"]}/channel <id>{_ANSI["reset"]}')
            return

        try:
            await self._rest.create_message(self._channel_id, content=line)
            print(f'  {_ANSI["dim"]}sent{_ANSI["reset"]}')
        except Exception as e:
            print(f'  {_ANSI["bright_red"]}Failed: {e}{_ANSI["reset"]}')

    def stop(self) -> None:
        self._running = False
