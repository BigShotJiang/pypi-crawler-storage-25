from __future__ import annotations

from typing import Any, Callable

from disquerd._types import Coro
from disquerd.commands.core import CommandBase, CommandCheck
from disquerd.commands.slash import SlashCommand
from disquerd.models.application import ApplicationCommand, ApplicationCommandOption, ApplicationCommandOptionType

__all__ = ("SubCommand", "SubCommandGroup")


class SubCommand(SlashCommand):
    __slots__ = ()

    def to_option(self) -> ApplicationCommandOption:
        return ApplicationCommandOption(
            type=ApplicationCommandOptionType.SUB_COMMAND,
            name=self.name,
            description=self.description,
            options=self.options,
        )

    def to_application_command(self) -> ApplicationCommand:
        raise TypeError("SubCommand cannot be converted to ApplicationCommand directly. Use the parent command.")


class SubCommandGroup(SlashCommand):
    __slots__ = ("_subcommands",)

    def __init__(self, callback: Callable[..., Coro[None]], **kwargs: Any) -> None:
        super().__init__(callback, **kwargs)
        self._subcommands: list[SubCommand] = []

    def sub_command(
        self,
        name: str | None = None,
        *,
        description: str = "",
    ) -> Callable[[Callable[..., Coro[None]]], SubCommand]:
        def decorator(callback: Callable[..., Coro[None]]) -> SubCommand:
            cmd = SubCommand(callback, name=name, description=description)
            self._subcommands.append(cmd)
            return cmd
        return decorator

    def to_option(self) -> ApplicationCommandOption:
        return ApplicationCommandOption(
            type=ApplicationCommandOptionType.SUB_COMMAND_GROUP,
            name=self.name,
            description=self.description,
            options=[sc.to_option() for sc in self._subcommands],
        )

    def to_application_command(self) -> ApplicationCommand:
        raise TypeError("SubCommandGroup cannot be converted to ApplicationCommand directly. Use the parent command.")
