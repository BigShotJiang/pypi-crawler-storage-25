from __future__ import annotations

import asyncio
import time
from typing import Any, Callable, Awaitable

from disquerd._types import Coro, MISSING
from disquerd.errors.command import CommandCheckFailure, CommandOnCooldown

__all__ = ("CommandBase", "CommandCheck", "CooldownMapping")


class CooldownMapping:
    __slots__ = ("rate", "per", "_bucket")

    def __init__(self, rate: int = 1, per: float = 3.0) -> None:
        self.rate = rate
        self.per = per
        self._bucket: dict[int, list[float]] = {}

    def _cleanup(self, key: int) -> None:
        now = time.monotonic()
        timestamps = self._bucket.get(key, [])
        self._bucket[key] = [t for t in timestamps if now - t < self.per]

    def is_on_cooldown(self, key: int) -> bool:
        self._cleanup(key)
        return len(self._bucket.get(key, [])) >= self.rate

    def get_cooldown(self, key: int) -> float:
        self._cleanup(key)
        timestamps = self._bucket.get(key, [])
        if len(timestamps) >= self.rate:
            return self.per - (time.monotonic() - timestamps[0])
        return 0.0

    def update(self, key: int) -> None:
        if key not in self._bucket:
            self._bucket[key] = []
        self._bucket[key].append(time.monotonic())


type CommandCheck = Callable[..., Awaitable[bool]]


class CommandBase:
    __slots__ = (
        "name", "description", "callback", "checks",
        "cooldown", "enabled", "hidden", "extras",
    )

    def __init__(
        self,
        callback: Callable[..., Coro[None]],
        *,
        name: str | None = None,
        description: str = "",
        checks: list[CommandCheck] | None = None,
        cooldown: CooldownMapping | None = None,
        enabled: bool = True,
        hidden: bool = False,
    ) -> None:
        self.callback = callback
        self.name: str = name or callback.__name__
        self.description = description or (callback.__doc__ or "").strip().split("\n")[0][:100]
        self.checks = checks or []
        self.cooldown = cooldown
        self.enabled = enabled
        self.hidden = hidden
        self.extras: dict[str, Any] = {}

    async def invoke(self, ctx: Any, *args: Any, **kwargs: Any) -> None:
        if not self.enabled:
            return

        for check in self.checks:
            result = await check(ctx)
            if not result:
                raise CommandCheckFailure(command_name=self.name)

        if self.cooldown:
            key = getattr(ctx, "author_id", 0) or getattr(ctx, "user_id", 0) or 0
            if self.cooldown.is_on_cooldown(key):
                retry = self.cooldown.get_cooldown(key)
                raise CommandOnCooldown(retry_after=retry, command_name=self.name)
            self.cooldown.update(key)

        await self.callback(ctx, *args, **kwargs)

    def add_check(self, check: CommandCheck) -> CommandBase:
        self.checks.append(check)
        return self

    def remove_check(self, check: CommandCheck) -> CommandBase:
        self.checks.remove(check)
        return self

    def set_cooldown(self, rate: int, per: float) -> CommandBase:
        self.cooldown = CooldownMapping(rate=rate, per=per)
        return self

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(name={self.name!r})"
