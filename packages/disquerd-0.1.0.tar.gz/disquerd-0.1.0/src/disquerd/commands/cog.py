from __future__ import annotations

from typing import Any, Callable

from disquerd._types import Coro, EventType
from disquerd.commands.slash import SlashCommand
from disquerd.commands.prefix import PrefixCommand
from disquerd.commands.core import CommandCheck

__all__ = ("Cog",)

_LISTENER_ALIASES: dict[str, EventType] = {
    "on_ready": EventType.READY,
    "on_resumed": EventType.RESUMED,
    "on_message": EventType.MESSAGE_CREATE,
    "on_message_edit": EventType.MESSAGE_UPDATE,
    "on_message_delete": EventType.MESSAGE_DELETE,
    "on_interaction": EventType.INTERACTION_CREATE,
    "on_guild_join": EventType.GUILD_CREATE,
    "on_guild_update": EventType.GUILD_UPDATE,
    "on_guild_remove": EventType.GUILD_DELETE,
    "on_member_join": EventType.GUILD_MEMBER_ADD,
    "on_member_update": EventType.GUILD_MEMBER_UPDATE,
    "on_member_remove": EventType.GUILD_MEMBER_REMOVE,
    "on_role_create": EventType.GUILD_ROLE_CREATE,
    "on_role_update": EventType.GUILD_ROLE_UPDATE,
    "on_role_delete": EventType.GUILD_ROLE_DELETE,
    "on_channel_create": EventType.CHANNEL_CREATE,
    "on_channel_update": EventType.CHANNEL_UPDATE,
    "on_channel_delete": EventType.CHANNEL_DELETE,
    "on_command": EventType.COMMAND,
    "on_command_completion": EventType.COMMAND_COMPLETION,
    "on_command_error": EventType.COMMAND_ERROR,
    "on_slash_command_error": EventType.SLASH_COMMAND_ERROR,
    "on_component_error": EventType.COMPONENT_ERROR,
    "on_modal_error": EventType.MODAL_ERROR,
}


class Cog:
    __slots__ = ("bot", "_listeners")

    def __init__(self, bot: Any) -> None:
        self.bot = bot
        self._listeners: list[tuple[EventType, Callable]] = []

    @staticmethod
    def listener(event_type: EventType | None = None) -> Callable[[Callable], Callable]:
        def decorator(func: Callable) -> Callable:
            et = event_type
            if et is None:
                et = _LISTENER_ALIASES.get(func.__name__)
                if et is None:
                    name = func.__name__
                    if name.startswith("on_"):
                        key = name[3:]
                        try:
                            et = EventType(key)
                        except ValueError:
                            pass
                if et is None:
                    raise ValueError(
                        f"Cannot infer EventType from {func.__name__!r}. "
                        f"Pass event_type explicitly: @Cog.listener(EventType.MESSAGE_CREATE)"
                    )
            func.__disquerd_listener__ = et
            return func
        return decorator

    def _setup(self) -> list[str]:
        registered = []
        for name in dir(self):
            attr = getattr(self, name, None)
            if attr is None:
                continue

            if isinstance(attr, SlashCommand):
                attr.callback = attr.callback.__get__(self)
                self.bot._slash_commands[attr.name] = attr
                registered.append(attr.name)
            elif isinstance(attr, PrefixCommand):
                attr.callback = attr.callback.__get__(self)
                self.bot._prefix_commands[attr.name] = attr
                for alias in attr.aliases:
                    self.bot._prefix_commands[alias] = attr
                registered.append(attr.name)

            listener_event = getattr(attr, "__disquerd_listener__", None)
            if listener_event is not None:
                bound = attr.__get__(self) if hasattr(attr, "__get__") else attr
                self.bot._events.register(listener_event, bound)
                self._listeners.append((listener_event, bound))

        if hasattr(self, "cog_load"):
            self.cog_load()

        return registered

    def _teardown(self) -> list[str]:
        removed = []
        for name in dir(self):
            attr = getattr(self, name, None)
            if isinstance(attr, (SlashCommand, PrefixCommand)):
                self.bot._slash_commands.pop(attr.name, None)
                self.bot._prefix_commands.pop(attr.name, None)
                for alias in getattr(attr, "aliases", []):
                    self.bot._prefix_commands.pop(alias, None)
                removed.append(attr.name)

        for event_type, bound in self._listeners:
            self.bot._events.remove(event_type, bound)
        self._listeners.clear()

        if hasattr(self, "cog_unload"):
            self.cog_unload()

        return removed

    def __repr__(self) -> str:
        return f"Cog({self.__class__.__name__})"
