from __future__ import annotations

from typing import Any, Callable

from disquerd._types import Coro
from disquerd.commands.core import CommandBase, CommandCheck, CooldownMapping
from disquerd.models.application import ApplicationCommand, ApplicationCommandOption, ApplicationCommandOptionType

__all__ = ("SlashCommand",)


class SlashCommand(CommandBase):
    __slots__ = ("options", "guild_ids", "nsfw", "default_member_permissions", "dm_permission", "guild_only")

    def __init__(
        self,
        callback: Callable[..., Coro[None]],
        *,
        name: str | None = None,
        description: str = "",
        options: list[ApplicationCommandOption] | None = None,
        guild_ids: list[int] | None = None,
        checks: list[CommandCheck] | None = None,
        cooldown: CooldownMapping | None = None,
        nsfw: bool = False,
        default_member_permissions: str | None = None,
        dm_permission: bool = True,
    ) -> None:
        super().__init__(
            callback,
            name=name,
            description=description,
            checks=checks,
            cooldown=cooldown,
        )
        self.options = options or []
        self.guild_ids = guild_ids
        self.nsfw = nsfw
        self.default_member_permissions = default_member_permissions
        self.dm_permission = dm_permission
        self.guild_only = not dm_permission

    def _build_options(self) -> list[dict[str, Any]]:
        return [opt.to_dict() for opt in self.options]

    def to_application_command(self) -> ApplicationCommand:
        return ApplicationCommand(
            name=self.name,
            description=self.description,
            options=self.options,
            type=1,
        )

    def add_option(
        self,
        name: str,
        *,
        type: int = 3,
        description: str = "",
        required: bool = False,
        choices: list[dict[str, Any]] | None = None,
        autocomplete: bool = False,
    ) -> SlashCommand:
        self.options.append(
            ApplicationCommandOption(
                type=type,
                name=name,
                description=description,
                required=required,
                choices=choices,
                autocomplete=autocomplete,
            )
        )
        return self

    def __repr__(self) -> str:
        return f"SlashCommand(name={self.name!r})"
