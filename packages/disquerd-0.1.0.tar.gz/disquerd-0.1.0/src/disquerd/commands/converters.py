from __future__ import annotations

from typing import Any, Callable, Awaitable

__all__ = ("Converter", "MemberConverter", "UserConverter", "ChannelConverter", "RoleConverter")


class Converter:
    __slots__ = ()

    async def convert(self, ctx: Any, argument: str) -> Any:
        raise NotImplementedError


class UserConverter(Converter):
    __slots__ = ()

    async def convert(self, ctx: Any, argument: str) -> Any:
        state = ctx._state
        if argument.startswith("<@") and argument.endswith(">"):
            uid = argument[2:-1].replace("!", "")
            return state.get_user(int(uid))
        if argument.isdigit():
            return state.get_user(int(argument))
        for user in state._users.values():
            if user.username.lower() == argument.lower():
                return user
        return None


class MemberConverter(Converter):
    __slots__ = ()

    async def convert(self, ctx: Any, argument: str) -> Any:
        state = ctx._state
        guild_id = ctx.guild_id
        if not guild_id:
            return None
        if argument.startswith("<@") and argument.endswith(">"):
            uid = argument[2:-1].replace("!", "")
            return state.get_member(guild_id, int(uid))
        if argument.isdigit():
            return state.get_member(guild_id, int(argument))
        for member in state.get_guild_members(guild_id):
            if member.display_name.lower() == argument.lower():
                return member
        return None


class ChannelConverter(Converter):
    __slots__ = ()

    async def convert(self, ctx: Any, argument: str) -> Any:
        state = ctx._state
        if argument.startswith("<#") and argument.endswith(">"):
            cid = argument[2:-1]
            return state.get_channel(int(cid))
        if argument.isdigit():
            return state.get_channel(int(argument))
        for channel in state._channels.values():
            if channel.name and channel.name.lower() == argument.lower():
                return channel
        return None


class RoleConverter(Converter):
    __slots__ = ()

    async def convert(self, ctx: Any, argument: str) -> Any:
        state = ctx._state
        if argument.startswith("<@&") and argument.endswith(">"):
            rid = argument[3:-1]
            return state.get_role(int(rid))
        if argument.isdigit():
            return state.get_role(int(argument))
        guild_id = ctx.guild_id
        if guild_id:
            for role in state.get_guild_roles(guild_id):
                if role.name.lower() == argument.lower():
                    return role
        return None
