from __future__ import annotations

import asyncio
import functools
from typing import Any, Callable, Awaitable

from disquerd._types import Coro, EventType
from disquerd.errors.command import CommandCheckFailure

__all__ = (
    "is_owner", "has_permissions", "has_role", "has_any_role",
    "guild_only", "dm_only", "nsfw", "cooldown",
)


def is_owner() -> Callable:
    def decorator(func: Callable) -> Callable:
        if not hasattr(func, "_checks"):
            func._checks = []
        func._checks.append(_check_is_owner)
        return func
    return decorator


async def _check_is_owner(ctx: Any) -> bool:
    app_id = ctx._bot.application_id if hasattr(ctx, "_bot") else None
    return ctx.author_id == app_id


def has_permissions(**perms: bool) -> Callable:
    def decorator(func: Callable) -> Callable:
        if not hasattr(func, "_checks"):
            func._checks = []
        async def check(ctx: Any) -> bool:
            member = ctx.member
            if member is None:
                return False
            from disquerd.utils.permissions import Permissions
            member_perms = Permissions(member.permissions if hasattr(member, "permissions") else 0)
            for perm, value in perms.items():
                flag = getattr(Permissions, perm.upper(), None)
                if flag is None:
                    continue
                if value and not member_perms.has(flag):
                    return False
            return True
        func._checks.append(check)
        return func
    return decorator


def has_role(role_id: int | str) -> Callable:
    def decorator(func: Callable) -> Callable:
        if not hasattr(func, "_checks"):
            func._checks = []
        async def check(ctx: Any) -> bool:
            member = ctx.member
            if member is None:
                return False
            rid = int(role_id)
            return rid in member.roles
        func._checks.append(check)
        return func
    return decorator


def has_any_role(*role_ids: int | str) -> Callable:
    def decorator(func: Callable) -> Callable:
        if not hasattr(func, "_checks"):
            func._checks = []
        async def check(ctx: Any) -> bool:
            member = ctx.member
            if member is None:
                return False
            rids = {int(r) for r in role_ids}
            return bool(set(member.roles) & rids)
        func._checks.append(check)
        return func
    return decorator


def guild_only() -> Callable:
    def decorator(func: Callable) -> Callable:
        if not hasattr(func, "_checks"):
            func._checks = []
        async def check(ctx: Any) -> bool:
            return ctx.guild_id is not None
        func._checks.append(check)
        return func
    return decorator


def dm_only() -> Callable:
    def decorator(func: Callable) -> Callable:
        if not hasattr(func, "_checks"):
            func._checks = []
        async def check(ctx: Any) -> bool:
            return ctx.guild_id is None
        func._checks.append(check)
        return func
    return decorator


def nsfw() -> Callable:
    def decorator(func: Callable) -> Callable:
        if not hasattr(func, "_checks"):
            func._checks = []
        async def check(ctx: Any) -> bool:
            channel = ctx.channel
            if channel is None:
                return False
            return getattr(channel, "nsfw", False)
        func._checks.append(check)
        return func
    return decorator


def cooldown(rate: int, per: float) -> Callable:
    from disquerd.commands.core import CooldownMapping
    def decorator(func: Callable) -> Callable:
        func._cooldown = CooldownMapping(rate=rate, per=per)
        return func
    return decorator
