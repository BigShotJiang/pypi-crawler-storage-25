from __future__ import annotations

from typing import Any, Callable

from disquerd._types import Coro
from disquerd.commands.core import CommandBase, CommandCheck, CooldownMapping

__all__ = ("PrefixCommand",)


class PrefixCommand(CommandBase):
    __slots__ = ("aliases", "brief", "usage", "rest_is_raw", "ignore_extra")

    def __init__(
        self,
        callback: Callable[..., Coro[None]],
        *,
        name: str | None = None,
        description: str = "",
        aliases: list[str] | None = None,
        checks: list[CommandCheck] | None = None,
        cooldown: CooldownMapping | None = None,
        brief: str = "",
        usage: str = "",
    ) -> None:
        super().__init__(
            callback,
            name=name,
            description=description,
            checks=checks,
            cooldown=cooldown,
        )
        self.aliases = aliases or []
        self.brief = brief
        self.usage = usage
        self.rest_is_raw = False
        self.ignore_extra = True

    def __repr__(self) -> str:
        return f"PrefixCommand(name={self.name!r}, aliases={self.aliases})"
