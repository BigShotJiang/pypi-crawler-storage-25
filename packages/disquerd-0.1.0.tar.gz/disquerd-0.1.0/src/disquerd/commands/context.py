from __future__ import annotations

from typing import Any

from disquerd.models.interaction import Interaction, InteractionResponseType
from disquerd.utils.embed import Embed

__all__ = ("ApplicationContext", "ComponentContext", "ModalContext", "Context")


class ApplicationContext:
    __slots__ = (
        "_interaction", "_rest", "_state", "_responded", "_deferred",
        "command_name", "options", "_bot",
    )

    def __init__(self, interaction: Interaction, rest: Any, state: Any) -> None:
        self._interaction = interaction
        self._rest = rest
        self._state = state
        self._responded = False
        self._deferred = False
        self.command_name = interaction.command_name or ""
        self.options = interaction.options
        self._bot: Any = None

    @property
    def interaction(self) -> Interaction:
        return self._interaction

    @property
    def author_id(self) -> int:
        raw = self._interaction.data.raw
        member = raw.get("member", {})
        if member and "user" in member:
            return int(member["user"]["id"])
        user = raw.get("user", {})
        if user:
            return int(user.get("id", 0))
        return 0

    @property
    def user_id(self) -> int:
        return self.author_id

    @property
    def guild_id(self) -> int | None:
        return self._interaction.guild_id

    @property
    def channel_id(self) -> int | None:
        return self._interaction.channel_id

    @property
    def author(self) -> Any:
        return self._state.get_user(self.author_id)

    @property
    def guild(self) -> Any:
        if self.guild_id:
            return self._state.get_guild(self.guild_id)
        return None

    @property
    def channel(self) -> Any:
        if self.channel_id:
            return self._state.get_channel(self.channel_id)
        return None

    @property
    def member(self) -> Any:
        if self.guild_id and self.author_id:
            return self._state.get_member(self.guild_id, self.author_id)
        return None

    def option(self, name: str, default: Any = None) -> Any:
        for opt in self.options:
            if opt.get("name") == name:
                return opt.get("value")
        return default

    def get_user(self, name: str = "user") -> Any:
        val = self.option(name)
        if val is not None:
            uid = int(val) if isinstance(val, str) else val
            return self.resolved_member(uid)
        return self.member

    def get_channel(self, name: str = "channel") -> Any:
        val = self.option(name)
        if val is not None:
            cid = int(val) if isinstance(val, str) else val
            return self.resolved_channel(cid)
        return self.channel

    def get_role(self, name: str = "role") -> Any:
        val = self.option(name)
        if val is not None:
            rid = int(val) if isinstance(val, str) else val
            return self.resolved_role(rid)
        return None

    def _option_value(self, name: str) -> Any:
        return self.option(name)

    def __getitem__(self, name: str) -> Any:
        return self._option_value(name)

    def get(self, name: str, default: Any = None) -> Any:
        val = self._option_value(name)
        return val if val is not None else default

    @property
    def resolved(self) -> dict[str, Any]:
        return self._interaction.resolved

    def resolved_user(self, user_id: int | None = None) -> Any:
        resolved = self.resolved
        users = resolved.get("users", {})
        uid = user_id or self.author_id
        data = users.get(str(uid))
        if data:
            from disquerd.state import _decode
            from disquerd.models.user import User
            try:
                return _decode(User, data)
            except Exception:
                pass
        return self.author

    def resolved_member(self, user_id: int | None = None) -> Any:
        resolved = self.resolved
        members = resolved.get("members", {})
        users = resolved.get("users", {})
        uid = user_id or self.author_id
        data = members.get(str(uid))
        if data:
            user_data = users.get(str(uid), {})
            if user_data:
                data["user"] = user_data
            data["id"] = uid
            if self.guild_id:
                data.setdefault("guild_id", self.guild_id)
            from disquerd.state import _decode
            from disquerd.models.member import Member
            try:
                return _decode(Member, data)
            except Exception:
                pass

        if str(uid) in users:
            from disquerd.state import _decode
            from disquerd.models.user import User
            try:
                return _decode(User, users[str(uid)])
            except Exception:
                pass

        return self.member

    def resolved_channel(self, channel_id: int) -> Any:
        resolved = self.resolved
        channels = resolved.get("channels", {})
        data = channels.get(str(channel_id))
        if data:
            from disquerd.state import _decode
            from disquerd.models.channel import Channel
            try:
                return _decode(Channel, data)
            except Exception:
                pass
        return None

    def resolved_role(self, role_id: int) -> Any:
        resolved = self.resolved
        roles = resolved.get("roles", {})
        data = roles.get(str(role_id))
        if data:
            if self.guild_id:
                data.setdefault("guild_id", self.guild_id)
            from disquerd.state import _decode
            from disquerd.models.role import Role
            try:
                return _decode(Role, data)
            except Exception:
                pass
        return None

    async def respond(
        self,
        content: str | None = None,
        *,
        embed: Embed | None = None,
        embeds: list[Embed] | None = None,
        ephemeral: bool = False,
        view: Any | None = None,
        **kwargs: Any,
    ) -> None:
        data: dict[str, Any] = {
            "type": InteractionResponseType.CHANNEL_MESSAGE_WITH_SOURCE.value,
        }

        message_data: dict[str, Any] = {}
        if content is not None:
            message_data["content"] = content
        if embed is not None:
            message_data["embeds"] = [embed.to_dict()]
        if embeds is not None:
            message_data["embeds"] = [e.to_dict() for e in embeds]
        if ephemeral:
            message_data["flags"] = 64
        if view is not None:
            message_data["components"] = view.to_dict()

        message_data.update(kwargs)
        data["data"] = message_data

        if not self._responded:
            await self._rest.create_interaction_response(
                self._interaction.id,
                self._interaction.token,
                data=data,
            )
            self._responded = True
        else:
            await self._rest.create_followup_message(
                self._interaction.application_id,
                self._interaction.token,
                data=message_data,
            )

    async def defer(self, *, ephemeral: bool = False) -> None:
        if self._responded:
            return
        data: dict[str, Any] = {
            "type": InteractionResponseType.DEFERRED_CHANNEL_MESSAGE_WITH_SOURCE.value,
        }
        if ephemeral:
            data["data"] = {"flags": 64}
        await self._rest.create_interaction_response(
            self._interaction.id,
            self._interaction.token,
            data=data,
        )
        self._responded = True
        self._deferred = True

    async def show_modal(self, modal: Any) -> None:
        data: dict[str, Any] = {
            "type": InteractionResponseType.MODAL.value,
            "data": modal.to_dict(),
        }
        await self._rest.create_interaction_response(
            self._interaction.id,
            self._interaction.token,
            data=data,
        )
        self._responded = True

    async def send_success(self, message: str, *, ephemeral: bool = False) -> None:
        e = Embed(title=message, colour=0x57F287)
        await self.respond(embed=e, ephemeral=ephemeral)

    async def send_error(self, message: str, *, ephemeral: bool = False) -> None:
        e = Embed(title=message, colour=0xED4245)
        await self.respond(embed=e, ephemeral=ephemeral)

    async def edit_response(
        self,
        content: str | None = None,
        *,
        embed: Embed | None = None,
        embeds: list[Embed] | None = None,
        view: Any | None = None,
        **kwargs: Any,
    ) -> None:
        message_data: dict[str, Any] = {}
        if content is not None:
            message_data["content"] = content
        if embed is not None:
            message_data["embeds"] = [embed.to_dict()]
        if embeds is not None:
            message_data["embeds"] = [e.to_dict() for e in embeds]
        if view is not None:
            message_data["components"] = view.to_dict()
        message_data.update(kwargs)

        await self._rest.edit_original_interaction_response(
            self._interaction.application_id,
            self._interaction.token,
            data=message_data,
        )

    async def delete_response(self) -> None:
        await self._rest.delete_original_interaction_response(
            self._interaction.application_id,
            self._interaction.token,
        )

    async def confirm(self, message: str = "Are you sure?") -> bool:
        from disquerd.utils.confirm import ConfirmView
        view = ConfirmView(author_id=self.author_id)
        await self.respond(content=message, view=view)
        if self._bot:
            self._bot.add_view(view)
        return await view.wait() or False

    def __repr__(self) -> str:
        return f"ApplicationContext(command={self.command_name!r})"


class ComponentContext(ApplicationContext):
    __slots__ = ("custom_id", "component_type", "values")

    def __init__(self, interaction: Interaction, rest: Any, state: Any) -> None:
        super().__init__(interaction, rest, state)
        self.custom_id = interaction.custom_id or ""
        self.component_type = interaction.component_type
        self.values = interaction.values

    async def defer_update(self) -> None:
        if self._responded:
            return
        await self._rest.create_interaction_response(
            self._interaction.id,
            self._interaction.token,
            data={"type": InteractionResponseType.DEFERRED_UPDATE_MESSAGE.value},
        )
        self._responded = True
        self._deferred = True

    async def update_message(
        self,
        content: str | None = None,
        *,
        embed: Embed | None = None,
        embeds: list[Embed] | None = None,
        view: Any | None = None,
        **kwargs: Any,
    ) -> None:
        message_data: dict[str, Any] = {}
        if content is not None:
            message_data["content"] = content
        if embed is not None:
            message_data["embeds"] = [embed.to_dict()]
        if embeds is not None:
            message_data["embeds"] = [e.to_dict() for e in embeds]
        if view is not None:
            message_data["components"] = view.to_dict()
        message_data.update(kwargs)

        if not self._responded:
            data: dict[str, Any] = {
                "type": InteractionResponseType.UPDATE_MESSAGE.value,
                "data": message_data,
            }
            await self._rest.create_interaction_response(
                self._interaction.id,
                self._interaction.token,
                data=data,
            )
            self._responded = True
        else:
            await self._rest.edit_original_interaction_response(
                self._interaction.application_id,
                self._interaction.token,
                data=message_data,
            )

    def __repr__(self) -> str:
        return f"ComponentContext(custom_id={self.custom_id!r})"


class ModalContext(ApplicationContext):
    __slots__ = ("custom_id",)

    def __init__(self, interaction: Interaction, rest: Any, state: Any) -> None:
        super().__init__(interaction, rest, state)
        self.custom_id = interaction.custom_id or ""

    def value(self, custom_id: str, default: str | None = None) -> str | None:
        for comp in self._interaction.data.components:
            for child in comp.get("components", []):
                if child.get("custom_id") == custom_id:
                    return child.get("value", default)
        return default

    @property
    def text_input_values(self) -> dict[str, str]:
        result: dict[str, str] = {}
        for comp in self._interaction.data.components:
            for child in comp.get("components", []):
                cid = child.get("custom_id")
                if cid:
                    result[cid] = child.get("value", "")
        return result

    def __repr__(self) -> str:
        return f"ModalContext(custom_id={self.custom_id!r})"


class Context:
    __slots__ = (
        "_message", "_rest", "_state", "prefix",
        "invoked_with", "command", "view", "args", "kwargs",
        "_bot",
    )

    def __init__(self, message: Any, rest: Any, state: Any, *, prefix: str = "") -> None:
        self._message = message
        self._rest = rest
        self._state = state
        self.prefix = prefix
        self.invoked_with: str | None = None
        self.command: Any | None = None
        self.view: str = ""
        self.args: list[str] = []
        self.kwargs: dict[str, str] = {}
        self._bot: Any = None

    @property
    def message(self) -> Any:
        return self._message

    @property
    def author_id(self) -> int:
        return self._message.author_id or 0

    @property
    def guild_id(self) -> int | None:
        return self._message.guild_id

    @property
    def channel_id(self) -> int:
        return self._message.channel_id

    @property
    def author(self) -> Any:
        return self._state.get_user(self.author_id)

    @property
    def guild(self) -> Any:
        if self.guild_id:
            return self._state.get_guild(self.guild_id)
        return None

    @property
    def channel(self) -> Any:
        return self._state.get_channel(self.channel_id)

    @property
    def member(self) -> Any:
        if self.guild_id and self.author_id:
            return self._state.get_member(self.guild_id, self.author_id)
        return None

    @property
    def content(self) -> str:
        return self._message.content

    async def send(self, content: str = "", **kwargs: Any) -> dict[str, Any]:
        return await self._rest.create_message(self.channel_id, content=content, **kwargs)

    async def reply(self, content: str = "", **kwargs: Any) -> dict[str, Any]:
        kwargs.setdefault("message_reference", {"message_id": str(self._message.id)})
        return await self._rest.create_message(self.channel_id, content=content, **kwargs)

    async def send_success(self, message: str) -> dict[str, Any]:
        e = Embed(title=message, colour=0x57F287)
        return await self._rest.create_message(
            self.channel_id, embeds=[e.to_dict()])

    async def send_error(self, message: str) -> dict[str, Any]:
        e = Embed(title=message, colour=0xED4245)
        return await self._rest.create_message(
            self.channel_id, embeds=[e.to_dict()])

    async def typing(self) -> None:
        await self._rest.trigger_typing(self.channel_id)

    async def react(self, emoji: str) -> None:
        await self._rest.add_reaction(self.channel_id, self._message.id, emoji)

    async def pin(self) -> None:
        await self._rest.pin_message(self.channel_id, self._message.id)

    async def unpin(self) -> None:
        await self._rest.unpin_message(self.channel_id, self._message.id)

    async def confirm(self, message: str = "Are you sure?") -> bool:
        from disquerd.utils.confirm import ConfirmView
        view = ConfirmView(author_id=self.author_id)
        await self.send(content=message, components=view.to_dict())
        if hasattr(self, '_bot') and self._bot:
            self._bot.add_view(view)
        return await view.wait() or False

    def __repr__(self) -> str:
        return f"Context(message_id={self._message.id})"
