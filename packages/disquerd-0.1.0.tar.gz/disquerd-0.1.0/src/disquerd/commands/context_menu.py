from __future__ import annotations

from typing import Any, Callable

from disquerd._types import Coro
from disquerd.commands.core import CommandBase, CommandCheck
from disquerd.models.application import ApplicationCommand

__all__ = ("UserCommand", "MessageCommand")


class UserCommand(CommandBase):
    __slots__ = ("guild_ids", "default_member_permissions", "dm_permission", "nsfw")

    def __init__(
        self,
        callback: Callable[..., Coro[None]],
        *,
        name: str | None = None,
        guild_ids: list[int] | None = None,
        checks: list[CommandCheck] | None = None,
        nsfw: bool = False,
        default_member_permissions: str | None = None,
        dm_permission: bool = True,
    ) -> None:
        super().__init__(callback, name=name, checks=checks)
        self.guild_ids = guild_ids
        self.nsfw = nsfw
        self.default_member_permissions = default_member_permissions
        self.dm_permission = dm_permission

    def to_application_command(self) -> ApplicationCommand:
        return ApplicationCommand(name=self.name, description="", type=2)

    def __repr__(self) -> str:
        return f"UserCommand(name={self.name!r})"


class MessageCommand(CommandBase):
    __slots__ = ("guild_ids", "default_member_permissions", "dm_permission", "nsfw")

    def __init__(
        self,
        callback: Callable[..., Coro[None]],
        *,
        name: str | None = None,
        guild_ids: list[int] | None = None,
        checks: list[CommandCheck] | None = None,
        nsfw: bool = False,
        default_member_permissions: str | None = None,
        dm_permission: bool = True,
    ) -> None:
        super().__init__(callback, name=name, checks=checks)
        self.guild_ids = guild_ids
        self.nsfw = nsfw
        self.default_member_permissions = default_member_permissions
        self.dm_permission = dm_permission

    def to_application_command(self) -> ApplicationCommand:
        return ApplicationCommand(name=self.name, description="", type=3)

    def __repr__(self) -> str:
        return f"MessageCommand(name={self.name!r})"
