from __future__ import annotations

from typing import Any, Callable

from disquerd._types import Coro
from disquerd.commands.slash import SlashCommand

__all__ = ("autocomplete",)


def autocomplete(option_name: str) -> Callable:
    def decorator(callback: Callable[..., Coro[list[dict[str, Any]]]]) -> Callable:
        callback._autocomplete_for = option_name
        return callback
    return decorator
