from __future__ import annotations

import logging
from typing import Any

import msgspec

from disquerd.models.user import User
from disquerd.models.guild import Guild
from disquerd.models.channel import Channel
from disquerd.models.message import Message
from disquerd.models.member import Member
from disquerd.models.role import Role
from disquerd.models.emoji import Emoji
from disquerd.models.voice import VoiceState
from disquerd.utils.cache import LRUCache
from disquerd._registry import _bind_rest, _bind_state

__all__ = ("State",)

_log = logging.getLogger("disquerd")

_decoders: dict[type, msgspec.json.Decoder] = {}

_SNOWFLAKE_KEYS = frozenset({
    "id", "user_id", "channel_id", "guild_id", "role_id", "webhook_id",
    "application_id", "owner_id", "parent_id", "message_id", "target_id",
    "last_message_id", "system_channel_id", "rules_channel_id",
    "public_updates_channel_id", "widget_channel_id",
})

_INT_KEYS = frozenset({
    "permissions", "color", "position", "type", "flags", "rate_limit_per_user",
    "bitrate", "nsfw", "max_age", "max_uses", "uses", "member_count",
    "approximate_member_count", "approximate_presence_count",
})

_SNOWFLAKE_LIST_KEYS = frozenset({
    "roles",
})


def _coerce_ids(data: dict[str, Any]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for k, v in data.items():
        if k in _SNOWFLAKE_KEYS and isinstance(v, str):
            try:
                out[k] = int(v)
            except ValueError:
                out[k] = v
        elif k in _INT_KEYS and isinstance(v, str):
            try:
                out[k] = int(v)
            except ValueError:
                out[k] = v
        elif k in _SNOWFLAKE_LIST_KEYS and isinstance(v, list):
            out[k] = [int(i) if isinstance(i, str) else i for i in v]
        elif isinstance(v, dict):
            out[k] = _coerce_ids(v)
        elif isinstance(v, list):
            out[k] = [_coerce_ids(i) if isinstance(i, dict) else i for i in v]
        else:
            out[k] = v
    return out


def _decode(cls: type, data: dict[str, Any] | bytes) -> Any:
    if cls not in _decoders:
        _decoders[cls] = msgspec.json.Decoder(type=cls)
    d = _decoders[cls]
    if isinstance(data, dict):
        data = _coerce_ids(data)
        data = msgspec.json.encode(data)
    return d.decode(data)


class State:
    __slots__ = (
        "_users", "_guilds", "_channels", "_messages",
        "_members", "_roles", "_emojis", "_voice_states", "_user", "_application_id",
    )

    def __init__(
        self,
        *,
        max_users: int = 5000, max_guilds: int = 500, max_channels: int = 2000,
        max_messages: int = 5000, max_members: int = 10000, max_roles: int = 2000,
        max_emojis: int = 5000, max_voice_states: int = 5000,
    ) -> None:
        self._users: LRUCache[int, User] = LRUCache(maxsize=max_users)
        self._guilds: LRUCache[int, Guild] = LRUCache(maxsize=max_guilds)
        self._channels: LRUCache[int, Channel] = LRUCache(maxsize=max_channels)
        self._messages: LRUCache[int, Message] = LRUCache(maxsize=max_messages)
        self._members: LRUCache[tuple[int, int], Member] = LRUCache(maxsize=max_members)
        self._roles: LRUCache[int, Role] = LRUCache(maxsize=max_roles)
        self._emojis: LRUCache[int, Emoji] = LRUCache(maxsize=max_emojis)
        self._voice_states: LRUCache[tuple[int, int], VoiceState] = LRUCache(maxsize=max_voice_states)
        self._user: User | None = None
        self._application_id: int | None = None

    @property
    def user(self) -> User | None:
        return self._user

    @property
    def application_id(self) -> int | None:
        return self._application_id

    def get_user(self, user_id: int) -> User | None:
        return self._users.get(user_id)

    def get_guild(self, guild_id: int) -> Guild | None:
        return self._guilds.get(guild_id)

    def get_channel(self, channel_id: int) -> Channel | None:
        return self._channels.get(channel_id)

    def get_message(self, message_id: int) -> Message | None:
        return self._messages.get(message_id)

    def get_member(self, guild_id: int, user_id: int) -> Member | None:
        return self._members.get((guild_id, user_id))

    def get_role(self, role_id: int) -> Role | None:
        return self._roles.get(role_id)

    def get_guild_channels(self, guild_id: int) -> list[Channel]:
        return [ch for ch in self._channels.values() if ch.guild_id == guild_id]

    def get_guild_members(self, guild_id: int) -> list[Member]:
        return [m for (gid, _), m in self._members.items() if gid == guild_id]

    def get_guild_roles(self, guild_id: int) -> list[Role]:
        return [r for r in self._roles.values() if r.guild_id == guild_id]

    def get_voice_state(self, guild_id: int, user_id: int) -> VoiceState | None:
        return self._voice_states.get((guild_id, user_id))

    def get_guild_voice_states(self, guild_id: int) -> list[VoiceState]:
        return [vs for (gid, _), vs in self._voice_states.items() if gid == guild_id]

    @property
    def guilds(self) -> list[Guild]:
        return list(self._guilds.values())

    def bind_rest(self, rest: Any) -> None:
        _bind_rest(rest)
        _bind_state(self)

    def _int_or_none(self, v: Any) -> int | None:
        if v is None:
            return None
        return int(v)

    def parse_ready(self, data: dict[str, Any]) -> None:
        try:
            self._user = _decode(User, data.get("user", {}))
        except Exception:
            self._user = User(id=int(data.get("user", {}).get("id", 0)))
        app = data.get("application", {})
        self._application_id = int(app["id"]) if app.get("id") else None

        for g in data.get("guilds", []):
            try:
                guild = _decode(Guild, g)
            except Exception:
                guild = Guild(id=int(g.get("id", 0)))
            self._guilds[guild.id] = guild

    def parse_guild_create(self, data: dict[str, Any]) -> Guild:
        try:
            guild = _decode(Guild, data)
        except Exception:
            guild = Guild(id=int(data.get("id", 0)), name=data.get("name", ""))
        self._guilds[guild.id] = guild

        for ch in data.get("channels", []):
            try:
                ch.setdefault("guild_id", guild.id)
                channel = _decode(Channel, ch)
            except Exception:
                channel = Channel(id=int(ch.get("id", 0)), guild_id=guild.id)
            self._channels[channel.id] = channel

        for m in data.get("members", []):
            uid = int(m.get("user", {}).get("id", 0))
            m.setdefault("id", uid)
            m.setdefault("guild_id", guild.id)
            try:
                member = _decode(Member, m)
            except Exception:
                member = Member(id=uid, guild_id=guild.id, roles=[int(r) for r in m.get("roles", [])])
            self._members[(guild.id, uid)] = member

        for r in data.get("roles", []):
            try:
                r.setdefault("guild_id", guild.id)
                role = _decode(Role, r)
            except Exception:
                role = Role(id=int(r.get("id", 0)), guild_id=guild.id)
            self._roles[role.id] = role

        return guild

    def parse_message_create(self, data: dict[str, Any]) -> Message:
        author_id = int(data["author"]["id"]) if data.get("author") else None
        guild_id = self._int_or_none(data.get("guild_id"))
        try:
            msg = _decode(Message, data)
        except Exception:
            msg = Message(id=int(data.get("id", 0)), channel_id=int(data.get("channel_id", 0)),
                          content=data.get("content", ""))
        msg.author_id = author_id
        msg.guild_id = guild_id
        self._messages[msg.id] = msg
        return msg

    def parse_message_update(self, data: dict[str, Any]) -> Message | None:
        mid = int(data.get("id", 0))
        existing = self._messages.get(mid)
        if existing:
            if "content" in data:
                existing.content = data["content"]
            if "edited_timestamp" in data:
                existing.edited_timestamp = data["edited_timestamp"]
            if "pinned" in data:
                existing.pinned = data["pinned"]
            return existing
        return None

    def parse_message_delete(self, data: dict[str, Any]) -> int | None:
        mid = int(data.get("id", 0))
        return self._messages.pop(mid, None) and mid

    def parse_channel_create(self, data: dict[str, Any]) -> Channel:
        try:
            ch = _decode(Channel, data)
        except Exception:
            ch = Channel(id=int(data.get("id", 0)))
        self._channels[ch.id] = ch
        return ch

    def parse_channel_update(self, data: dict[str, Any]) -> Channel | None:
        cid = int(data.get("id", 0))
        existing = self._channels.get(cid)
        if existing:
            for k in ("name", "topic", "nsfw", "position"):
                if k in data and hasattr(existing, k):
                    setattr(existing, k, data[k])
            return existing
        return None

    def parse_channel_delete(self, data: dict[str, Any]) -> Channel | None:
        cid = int(data.get("id", 0))
        return self._channels.pop(cid, None)

    def parse_member_add(self, data: dict[str, Any]) -> Member:
        gid = int(data.get("guild_id", 0))
        uid = int(data.get("user", {}).get("id", 0))
        data.setdefault("id", uid)
        data.setdefault("guild_id", gid)
        try:
            member = _decode(Member, data)
        except Exception:
            member = Member(id=uid, guild_id=gid, roles=[int(r) for r in data.get("roles", [])])
        self._members[(gid, uid)] = member
        return member

    def parse_member_remove(self, data: dict[str, Any]) -> tuple[int, int] | None:
        gid = int(data.get("guild_id", 0))
        uid = int(data.get("user", {}).get("id", 0))
        self._members.pop((gid, uid), None)
        return (gid, uid) if uid else None

    def parse_member_update(self, data: dict[str, Any]) -> Member | None:
        gid = int(data.get("guild_id", 0))
        uid = int(data.get("user", {}).get("id", 0))
        existing = self._members.get((gid, uid))
        if existing:
            for k in ("nick", "roles", "avatar", "deaf", "mute", "pending",
                      "communication_disabled_until", "premium_since"):
                if k in data and hasattr(existing, k):
                    v = data[k]
                    if k == "roles" and isinstance(v, list):
                        v = [int(r) if isinstance(r, str) else r for r in v]
                    setattr(existing, k, v)
            if "user" in data:
                ud = data["user"]
                if existing.user:
                    for uk in ("username", "discriminator", "avatar", "global_name"):
                        if uk in ud and hasattr(existing.user, uk):
                            setattr(existing.user, uk, ud[uk])
            return existing
        data.setdefault("id", uid)
        data.setdefault("guild_id", gid)
        try:
            member = _decode(Member, data)
        except Exception:
            member = Member(id=uid, guild_id=gid, roles=[int(r) for r in data.get("roles", [])])
        self._members[(gid, uid)] = member
        return member

    def parse_guild_update(self, data: dict[str, Any]) -> Guild | None:
        gid = int(data.get("id", 0))
        existing = self._guilds.get(gid)
        if existing:
            for k in ("name", "icon", "description", "owner_id", "afk_channel_id",
                      "afk_timeout", "verification_level", "mfa_level", "banner",
                      "premium_tier", "preferred_locale", "vanity_url_code",
                      "system_channel_id", "rules_channel_id", "unavailable"):
                if k in data and hasattr(existing, k):
                    setattr(existing, k, data[k])
            return existing
        return None

    def parse_thread_create(self, data: dict[str, Any]) -> Channel:
        try:
            ch = _decode(Channel, data)
        except Exception:
            ch = Channel(id=int(data.get("id", 0)))
        self._channels[ch.id] = ch
        return ch

    def parse_thread_update(self, data: dict[str, Any]) -> Channel | None:
        cid = int(data.get("id", 0))
        existing = self._channels.get(cid)
        if existing:
            for k in ("name", "topic", "nsfw", "position", "rate_limit_per_user",
                      "thread_metadata", "parent_id", "message_count", "member_count"):
                if k in data and hasattr(existing, k):
                    setattr(existing, k, data[k])
            return existing
        return None

    def parse_thread_delete(self, data: dict[str, Any]) -> Channel | None:
        cid = int(data.get("id", 0))
        return self._channels.pop(cid, None)

    def parse_voice_state_update(self, data: dict[str, Any]) -> VoiceState:
        gid = int(data.get("guild_id", 0))
        uid = int(data.get("user_id", 0))
        if data.get("channel_id") is None:
            self._voice_states.pop((gid, uid), None)
            return VoiceState(user_id=uid, guild_id=gid, channel_id=0)
        try:
            vs = _decode(VoiceState, data)
        except Exception:
            vs = VoiceState(user_id=uid, guild_id=gid, channel_id=int(data.get("channel_id", 0)))
        self._voice_states[(gid, uid)] = vs
        return vs

    def parse_role_create(self, data: dict[str, Any]) -> Role:
        gid = int(data.get("guild_id", 0))
        rd = data.get("role", data)
        rd.setdefault("guild_id", gid)
        try:
            role = _decode(Role, rd)
        except Exception:
            role = Role(id=int(rd.get("id", 0)), guild_id=gid)
        self._roles[role.id] = role
        return role

    def parse_role_update(self, data: dict[str, Any]) -> Role | None:
        rid = int(data.get("role", {}).get("id", 0))
        existing = self._roles.get(rid)
        if existing:
            rd = data.get("role", {})
            for k in ("name", "color", "hoist", "position", "permissions", "mentionable"):
                if k in rd and hasattr(existing, k):
                    setattr(existing, k, rd[k])
            return existing
        return None

    def parse_role_delete(self, data: dict[str, Any]) -> Role | None:
        rid = int(data.get("role_id", 0))
        return self._roles.pop(rid, None)

    def clear(self) -> None:
        self._users.clear()
        self._guilds.clear()
        self._channels.clear()
        self._messages.clear()
        self._members.clear()
        self._roles.clear()
        self._emojis.clear()
        self._voice_states.clear()
