from __future__ import annotations

from typing import Any

__all__ = ("MediaGallery", "MediaGalleryItem", "Section", "Separator", "TextDisplay", "Container", "UnfurledMediaItem")


class UnfurledMediaItem:
    __slots__ = ("url",)

    def __init__(self, url: str) -> None:
        self.url = url

    def to_dict(self) -> dict[str, Any]:
        return {"url": self.url}


class MediaGalleryItem:
    __slots__ = ("media", "description", "spoiler")

    def __init__(self, *, url: str, description: str | None = None, spoiler: bool = False) -> None:
        self.media = UnfurledMediaItem(url)
        self.description = description
        self.spoiler = spoiler

    def to_dict(self) -> dict[str, Any]:
        data: dict[str, Any] = {"media": self.media.to_dict()}
        if self.description:
            data["description"] = self.description
        if self.spoiler:
            data["spoiler"] = True
        return data


class MediaGallery:
    __slots__ = ("items",)

    def __init__(self, items: list[MediaGalleryItem] | None = None) -> None:
        self.items = items or []

    def add_item(self, item: MediaGalleryItem) -> MediaGallery:
        self.items.append(item)
        return self

    def to_dict(self) -> dict[str, Any]:
        return {
            "type": 13,
            "items": [i.to_dict() for i in self.items],
        }


class Section:
    __slots__ = ("components", "accessory")

    def __init__(self, components: list[Any] | None = None, accessory: Any | None = None) -> None:
        self.components = components or []
        self.accessory = accessory

    def add_component(self, component: Any) -> Section:
        self.components.append(component)
        return self

    def set_accessory(self, accessory: Any) -> Section:
        self.accessory = accessory
        return self

    def to_dict(self) -> dict[str, Any]:
        data: dict[str, Any] = {
            "type": 17,
            "components": [c.to_dict() if hasattr(c, "to_dict") else c for c in self.components],
        }
        if self.accessory:
            data["accessory"] = self.accessory.to_dict() if hasattr(self.accessory, "to_dict") else self.accessory
        return data


class Separator:
    __slots__ = ("divider", "spacing")

    def __init__(self, *, divider: bool = True, spacing: int = 1) -> None:
        self.divider = divider
        self.spacing = spacing

    def to_dict(self) -> dict[str, Any]:
        return {
            "type": 14,
            "divider": self.divider,
            "spacing": self.spacing,
        }


class TextDisplay:
    __slots__ = ("content",)

    def __init__(self, content: str) -> None:
        self.content = content

    def to_dict(self) -> dict[str, Any]:
        return {
            "type": 10,
            "content": self.content,
        }


class Container:
    __slots__ = ("components", "accent_color", "spoiler")

    def __init__(
        self,
        components: list[Any] | None = None,
        *,
        accent_color: int | None = None,
        spoiler: bool = False,
    ) -> None:
        self.components = components or []
        self.accent_color = accent_color
        self.spoiler = spoiler

    def add_component(self, component: Any) -> Container:
        self.components.append(component)
        return self

    def to_dict(self) -> dict[str, Any]:
        data: dict[str, Any] = {
            "type": 17,
            "components": [c.to_dict() if hasattr(c, "to_dict") else c for c in self.components],
        }
        if self.accent_color is not None:
            data["accent_color"] = self.accent_color
        if self.spoiler:
            data["spoiler"] = True
        return data
