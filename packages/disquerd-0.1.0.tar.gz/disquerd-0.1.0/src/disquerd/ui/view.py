from __future__ import annotations

import asyncio
from typing import Any, Callable, Awaitable

from disquerd.ui.action_row import ActionRow

__all__ = ("View",)


class View:
    __slots__ = ("_children", "timeout", "_event", "_task", "_message", "_stopped")

    def __init__(self, *, timeout: float = 180.0) -> None:
        self._children: list[Any] = []
        self.timeout = timeout
        self._event = asyncio.Event()
        self._task: asyncio.Task[None] | None = None
        self._message: dict[str, Any] | None = None
        self._stopped = False

    def add_item(self, item: Any) -> View:
        self._children.append(item)
        return self

    def remove_item(self, item: Any) -> View:
        self._children.remove(item)
        return self

    def get_item(self, custom_id: str) -> Any | None:
        for item in self._children:
            if getattr(item, "custom_id", None) == custom_id:
                return item
        return None

    @property
    def children(self) -> list[Any]:
        return list(self._children)

    def to_dict(self) -> list[dict[str, Any]]:
        rows: list[ActionRow] = []
        current_row = ActionRow()

        for item in self._children:
            if getattr(item, "type", None) == 1:
                if current_row.components:
                    rows.append(current_row)
                rows.append(item)
                current_row = ActionRow()
            elif len(current_row.components) >= 5:
                rows.append(current_row)
                current_row = ActionRow()
                current_row.add_component(item)
            else:
                current_row.add_component(item)

        if current_row.components:
            rows.append(current_row)

        return [row.to_dict() for row in rows]

    def stop(self) -> None:
        self._stopped = True
        self._event.set()
        if self._task:
            self._task.cancel()

    async def wait(self) -> None:
        await self._event.wait()

    async def on_timeout(self) -> None:
        for item in self._children:
            item.disabled = True
        self.stop()

    async def on_error(self, interaction: Any, error: Exception, item: Any) -> None:
        pass

    def _start(self) -> None:
        if self.timeout and self.timeout > 0:
            self._task = asyncio.create_task(self._timeout_task())

    async def _timeout_task(self) -> None:
        try:
            await asyncio.sleep(self.timeout)
            if not self._stopped:
                await self.on_timeout()
        except asyncio.CancelledError:
            pass

    async def dispatch(self, interaction: Any) -> None:
        custom_id = interaction.get("data", {}).get("custom_id")
        if not custom_id:
            return
        item = self.get_item(custom_id)
        if item and hasattr(item, "callback"):
            try:
                await item.callback(interaction)
            except Exception as e:
                await self.on_error(interaction, e, item)

    def __repr__(self) -> str:
        return f"View(children={len(self._children)}, timeout={self.timeout})"
