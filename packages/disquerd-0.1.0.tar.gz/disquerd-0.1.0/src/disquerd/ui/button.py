from __future__ import annotations

from enum import IntEnum
from typing import Any, Callable, Awaitable

__all__ = ("Button", "ButtonStyle")


class ButtonStyle(IntEnum):
    PRIMARY = 1
    SECONDARY = 2
    SUCCESS = 3
    DANGER = 4
    LINK = 5


class Button:
    __slots__ = ("style", "label", "emoji", "custom_id", "url", "disabled", "callback")

    def __init__(
        self,
        *,
        style: int = 1,
        label: str | None = None,
        emoji: str | dict[str, Any] | None = None,
        custom_id: str | None = None,
        url: str | None = None,
        disabled: bool = False,
    ) -> None:
        self.style = ButtonStyle(style)
        self.label = label
        self.emoji = emoji
        self.custom_id = custom_id
        self.url = url
        self.disabled = disabled
        self.callback: Callable[..., Awaitable[None]] | None = None

    def to_dict(self) -> dict[str, Any]:
        data: dict[str, Any] = {
            "type": 2,
            "style": self.style.value,
        }
        if self.label:
            data["label"] = self.label
        if self.emoji:
            if isinstance(self.emoji, str):
                data["emoji"] = {"name": self.emoji}
            else:
                data["emoji"] = self.emoji
        if self.url:
            data["url"] = self.url
        elif self.custom_id:
            data["custom_id"] = self.custom_id
        if self.disabled:
            data["disabled"] = True
        return data

    def __repr__(self) -> str:
        return f"Button(label={self.label!r}, style={self.style.name})"
