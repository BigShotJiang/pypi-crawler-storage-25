from __future__ import annotations

from typing import Any

__all__ = ("ActionRow",)


class ActionRow:
    __slots__ = ("components",)

    def __init__(self, *, components: list[Any] | None = None) -> None:
        self.components = components or []

    def add_component(self, component: Any) -> ActionRow:
        self.components.append(component)
        return self

    def to_dict(self) -> dict[str, Any]:
        return {
            "type": 1,
            "components": [c.to_dict() if hasattr(c, "to_dict") else c for c in self.components],
        }

    def __repr__(self) -> str:
        return f"ActionRow(components={len(self.components)})"
