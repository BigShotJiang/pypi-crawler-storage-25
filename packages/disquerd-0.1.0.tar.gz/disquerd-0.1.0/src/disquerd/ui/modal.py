from __future__ import annotations

from typing import Any, Callable, Awaitable

__all__ = ("Modal", "TextInput", "ModalBuilder", "combine_text_inputs")


class TextInput:
    __slots__ = ("custom_id", "label", "style", "min_length", "max_length", "required", "value", "placeholder")

    def __init__(
        self,
        *,
        custom_id: str,
        label: str,
        style: int = 1,
        min_length: int | None = None,
        max_length: int | None = None,
        required: bool = True,
        value: str | None = None,
        placeholder: str | None = None,
    ) -> None:
        self.custom_id = custom_id
        self.label = label
        self.style = style
        self.min_length = min_length
        self.max_length = max_length
        self.required = required
        self.value = value
        self.placeholder = placeholder

    def to_dict(self) -> dict[str, Any]:
        data: dict[str, Any] = {
            "type": 4,
            "custom_id": self.custom_id,
            "label": self.label,
            "style": self.style,
        }
        if self.min_length is not None:
            data["min_length"] = self.min_length
        if self.max_length is not None:
            data["max_length"] = self.max_length
        if not self.required:
            data["required"] = False
        if self.value is not None:
            data["value"] = self.value
        if self.placeholder is not None:
            data["placeholder"] = self.placeholder
        return data


class Modal:
    __slots__ = ("title", "custom_id", "components", "callback")

    def __init__(
        self,
        *,
        title: str,
        custom_id: str | None = None,
        components: list[TextInput] | None = None,
    ) -> None:
        self.title = title
        self.custom_id = custom_id or f"modal_{id(self)}"
        self.components = components or []
        self.callback: Callable[..., Awaitable[None]] | None = None

    def add_component(self, component: TextInput) -> Modal:
        self.components.append(component)
        return self

    def to_dict(self) -> dict[str, Any]:
        action_rows = []
        for comp in self.components:
            row = {"type": 1, "components": [comp.to_dict()]}
            action_rows.append(row)
        return {
            "title": self.title,
            "custom_id": self.custom_id,
            "components": action_rows,
        }

    def __repr__(self) -> str:
        return f"Modal(title={self.title!r})"


class ModalBuilder:
    __slots__ = ("_title", "_custom_id", "_rows")

    def __init__(self, *, title: str, custom_id: str | None = None) -> None:
        self._title = title
        self._custom_id = custom_id or f"modal_{id(self)}"
        self._rows: list[list[TextInput]] = []

    def add_row(self, *inputs: TextInput) -> ModalBuilder:
        self._rows.append(list(inputs))
        return self

    def add_text(
        self,
        custom_id: str,
        label: str,
        *,
        style: int = 1,
        placeholder: str | None = None,
        required: bool = True,
        min_length: int | None = None,
        max_length: int | None = None,
        value: str | None = None,
    ) -> ModalBuilder:
        inp = TextInput(
            custom_id=custom_id, label=label, style=style,
            placeholder=placeholder, required=required,
            min_length=min_length, max_length=max_length, value=value,
        )
        if not self._rows:
            self._rows.append([])
        self._rows[-1].append(inp)
        return self

    def build(self) -> Modal:
        components: list[TextInput] = []
        for row in self._rows:
            components.extend(row)
        return Modal(title=self._title, custom_id=self._custom_id, components=components)

    def __repr__(self) -> str:
        return f"ModalBuilder(title={self._title!r}, rows={len(self._rows)})"


def combine_text_inputs(*modals: Modal) -> dict[str, str]:
    result: dict[str, str] = {}
    for modal_obj in modals:
        for comp in modal_obj.components:
            if isinstance(comp, TextInput):
                result[comp.custom_id] = comp.value or ""
    return result
