from __future__ import annotations

from typing import Any, Callable, Awaitable

__all__ = ("SelectMenu", "SelectOption")


class SelectOption:
    __slots__ = ("label", "value", "description", "emoji", "default")

    def __init__(
        self,
        *,
        label: str,
        value: str,
        description: str | None = None,
        emoji: str | dict[str, Any] | None = None,
        default: bool = False,
    ) -> None:
        self.label = label
        self.value = value
        self.description = description
        self.emoji = emoji
        self.default = default

    def to_dict(self) -> dict[str, Any]:
        data: dict[str, Any] = {
            "label": self.label,
            "value": self.value,
        }
        if self.description:
            data["description"] = self.description
        if self.emoji:
            if isinstance(self.emoji, str):
                data["emoji"] = {"name": self.emoji}
            else:
                data["emoji"] = self.emoji
        if self.default:
            data["default"] = True
        return data


class SelectMenu:
    __slots__ = (
        "custom_id", "placeholder", "min_values", "max_values",
        "options", "disabled", "callback", "channel_types",
    )

    def __init__(
        self,
        *,
        custom_id: str | None = None,
        placeholder: str | None = None,
        min_values: int = 1,
        max_values: int = 1,
        options: list[SelectOption] | None = None,
        disabled: bool = False,
    ) -> None:
        self.custom_id = custom_id
        self.placeholder = placeholder
        self.min_values = min_values
        self.max_values = max_values
        self.options = options or []
        self.disabled = disabled
        self.callback: Callable[..., Awaitable[None]] | None = None
        self.channel_types: list[int] | None = None

    def add_option(self, option: SelectOption) -> SelectMenu:
        self.options.append(option)
        return self

    def to_dict(self) -> dict[str, Any]:
        data: dict[str, Any] = {
            "type": 3,
        }
        if self.custom_id:
            data["custom_id"] = self.custom_id
        if self.placeholder:
            data["placeholder"] = self.placeholder
        if self.min_values != 1:
            data["min_values"] = self.min_values
        if self.max_values != 1:
            data["max_values"] = self.max_values
        if self.options:
            data["options"] = [o.to_dict() for o in self.options]
        if self.disabled:
            data["disabled"] = True
        return data

    def __repr__(self) -> str:
        return f"SelectMenu(custom_id={self.custom_id!r})"
