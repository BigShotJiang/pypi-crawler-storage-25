from __future__ import annotations

from typing import TypedDict

__all__ = ("RawInteraction",)


class RawInteraction(TypedDict, total=False):
    id: str
    application_id: str
    type: int
    data: dict[str, typing.Any]
    token: str
    version: int
    guild_id: str
    channel_id: str
    member: dict[str, typing.Any]
    user: dict[str, typing.Any]
    message: dict[str, typing.Any]
    app_permissions: str
    locale: str
    guild_locale: str
