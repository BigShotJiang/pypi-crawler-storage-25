from __future__ import annotations

from typing import TypedDict

__all__ = ("RawChannel",)


class RawChannel(TypedDict, total=False):
    id: str
    type: int
    guild_id: str
    position: int
    name: str
    topic: str
    nsfw: bool
    last_message_id: str
    bitrate: int
    user_limit: int
    rate_limit_per_user: int
    parent_id: str
    last_pin_timestamp: str
