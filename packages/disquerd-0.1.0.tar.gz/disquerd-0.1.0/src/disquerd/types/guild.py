from __future__ import annotations

from typing import TypedDict

__all__ = ("RawGuild",)


class RawGuild(TypedDict, total=False):
    id: str
    name: str
    icon: str
    description: str
    owner: bool
    owner_id: str
    permissions: str
    region: str
    afk_channel_id: str
    afk_timeout: int
    verification_level: int
    default_message_notifications: int
    explicit_content_filter: int
    mfa_level: int
    application_id: str
    system_channel_id: str
    system_channel_flags: int
    rules_channel_id: str
    vanity_url_code: str
    banner: str
    premium_tier: int
    preferred_locale: str
    public_updates_channel_id: str
    member_count: int
    large: bool
