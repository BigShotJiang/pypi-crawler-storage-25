from __future__ import annotations

import typing

__all__ = ("SnowflakeType",)

type SnowflakeType = int | str
