from __future__ import annotations

from typing import TypedDict

__all__ = ("RawMessage",)


class RawMessage(TypedDict, total=False):
    id: str
    channel_id: str
    author: dict[str, typing.Any]
    content: str
    timestamp: str
    edited_timestamp: str
    tts: bool
    mention_everyone: bool
    mentions: list[dict[str, typing.Any]]
    mention_roles: list[str]
    attachments: list[dict[str, typing.Any]]
    embeds: list[dict[str, typing.Any]]
    pinned: bool
    type: int
    guild_id: str
    member: dict[str, typing.Any]
    reactions: list[dict[str, typing.Any]]
    nonce: int | str
    webhook_id: str
    flags: int
    message_reference: dict[str, typing.Any]
    referenced_message: dict[str, typing.Any]
    interaction: dict[str, typing.Any]
    components: list[dict[str, typing.Any]]
