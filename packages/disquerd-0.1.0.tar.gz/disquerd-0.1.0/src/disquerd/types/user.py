from __future__ import annotations

from typing import TypedDict

__all__ = ("RawUser",)


class RawUser(TypedDict, total=False):
    id: str
    username: str
    discriminator: str
    avatar: str
    bot: bool
    system: bool
    mfa_enabled: bool
    banner: str
    accent_color: int
    locale: str
    verified: bool
    email: str
    flags: int
    premium_type: int
    public_flags: int
