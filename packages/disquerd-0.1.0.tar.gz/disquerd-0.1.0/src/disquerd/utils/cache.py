from __future__ import annotations

import time
from collections import OrderedDict
from typing import Generic, Hashable, TypeVar

__all__ = ("Cache", "LRUCache", "TTLCache")

K = TypeVar("K", bound=Hashable)
V = TypeVar("V")


class Cache(Generic[K, V]):
    __slots__ = ("_data",)

    def __init__(self) -> None:
        self._data: dict[K, V] = {}

    def get(self, key: K) -> V | None:
        return self._data.get(key)

    def set(self, key: K, value: V) -> None:
        self._data[key] = value

    def pop(self, key: K, default: V | None = None) -> V | None:
        return self._data.pop(key, default)

    def clear(self) -> None:
        self._data.clear()

    def __getitem__(self, key: K) -> V:
        return self._data[key]

    def __setitem__(self, key: K, value: V) -> None:
        self._data[key] = value

    def __contains__(self, key: object) -> bool:
        return key in self._data

    def __len__(self) -> int:
        return len(self._data)

    def __iter__(self):
        return iter(self._data)

    def values(self):
        return self._data.values()

    def items(self):
        return self._data.items()

    def keys(self):
        return self._data.keys()


class LRUCache(Cache[K, V]):
    __slots__ = ("_maxsize",)

    def __init__(self, maxsize: int = 1024) -> None:
        super().__init__()
        self._maxsize = maxsize
        self._data: OrderedDict[K, V] = OrderedDict()

    def get(self, key: K) -> V | None:
        if key in self._data:
            self._data.move_to_end(key)
            return self._data[key]
        return None

    def set(self, key: K, value: V) -> None:
        if key in self._data:
            self._data.move_to_end(key)
        self._data[key] = value
        if len(self._data) > self._maxsize:
            self._data.popitem(last=False)

    def pop(self, key: K, default: V | None = None) -> V | None:
        return self._data.pop(key, default)

    @property
    def maxsize(self) -> int:
        return self._maxsize


class _TTLEntry(Generic[V]):
    __slots__ = ("value", "expires_at")

    def __init__(self, value: V, ttl: float) -> None:
        self.value = value
        self.expires_at = time.monotonic() + ttl

    @property
    def is_expired(self) -> bool:
        return time.monotonic() >= self.expires_at


class TTLCache(Cache[K, V]):
    __slots__ = ("_ttl", "_entries")

    def __init__(self, ttl: float = 3600.0, maxsize: int = 1024) -> None:
        self._ttl = ttl
        self._maxsize = maxsize
        self._entries: OrderedDict[K, _TTLEntry[V]] = OrderedDict()

    def get(self, key: K) -> V | None:
        entry = self._entries.get(key)
        if entry is None:
            return None
        if entry.is_expired:
            del self._entries[key]
            return None
        self._entries.move_to_end(key)
        return entry.value

    def set(self, key: K, value: V) -> None:
        if key in self._entries:
            self._entries.move_to_end(key)
        self._entries[key] = _TTLEntry(value, self._ttl)
        self._evict()

    def _evict(self) -> None:
        while len(self._entries) > self._maxsize:
            self._entries.popitem(last=False)
        now = time.monotonic()
        expired = [k for k, v in self._entries.items() if v.is_expired]
        for k in expired:
            del self._entries[k]

    def pop(self, key: K, default: V | None = None) -> V | None:
        entry = self._entries.pop(key, None)
        if entry is None:
            return default
        if entry.is_expired:
            return default
        return entry.value

    def clear(self) -> None:
        self._entries.clear()

    def __len__(self) -> int:
        self._evict()
        return len(self._entries)

    def __contains__(self, key: object) -> bool:
        entry = self._entries.get(key)
        if entry is None:
            return False
        if entry.is_expired:
            del self._entries[key]
            return False
        return True
