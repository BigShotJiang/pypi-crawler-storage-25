from __future__ import annotations

import asyncio
import logging
from typing import Any, Callable, Awaitable

from disquerd.ui.view import View
from disquerd.ui.button import Button

__all__ = ("ConfirmView",)

_log = logging.getLogger("disquerd")


class ConfirmView(View):
    __slots__ = ("_confirm_callback", "_deny_callback", "_result", "_author_id", "_confirm_btn", "_deny_btn", "_rest")

    def __init__(
        self,
        *,
        confirm_label: str = "Да",
        deny_label: str = "Нет",
        confirm_style: int = 3,
        deny_style: int = 4,
        author_id: int | None = None,
        timeout: float = 60.0,
        confirm_callback: Callable[[], Awaitable[None]] | None = None,
        deny_callback: Callable[[], Awaitable[None]] | None = None,
    ) -> None:
        super().__init__(timeout=timeout)
        self._result: bool | None = None
        self._author_id = author_id
        self._confirm_callback = confirm_callback
        self._deny_callback = deny_callback
        self._rest: Any = None

        self._confirm_btn = Button(label=confirm_label, style=confirm_style, custom_id="confirm_yes")
        self._deny_btn = Button(label=deny_label, style=deny_style, custom_id="confirm_no")

        self._confirm_btn.callback = self._on_confirm
        self._deny_btn.callback = self._on_deny

        self.add_item(self._confirm_btn)
        self.add_item(self._deny_btn)

    @property
    def result(self) -> bool | None:
        return self._result

    def _get_author_id(self, interaction: Any) -> str | None:
        uid = interaction.get("member", {}).get("user", {}).get("id")
        if uid is None:
            uid = interaction.get("user", {}).get("id")
        return uid

    async def _respond_defer(self, interaction: Any) -> None:
        if self._rest is None:
            from disquerd._registry import _rest as registry_rest
            self._rest = registry_rest
        if self._rest is None:
            return
        iid = int(interaction.get("id", 0))
        token = interaction.get("token", "")
        if iid and token:
            try:
                await self._rest.create_interaction_response(
                    iid, token,
                    data={"type": 6},
                )
            except Exception as e:
                _log.debug("ConfirmView defer response failed: %s", e)

    async def _on_confirm(self, interaction: Any) -> None:
        uid = self._get_author_id(interaction)
        if self._author_id and uid != str(self._author_id):
            return
        await self._respond_defer(interaction)
        self._result = True
        self.stop()
        if self._confirm_callback:
            await self._confirm_callback()

    async def _on_deny(self, interaction: Any) -> None:
        uid = self._get_author_id(interaction)
        if self._author_id and uid != str(self._author_id):
            return
        await self._respond_defer(interaction)
        self._result = False
        self.stop()
        if self._deny_callback:
            await self._deny_callback()

    async def wait(self) -> bool | None:
        await self._event.wait()
        return self._result
