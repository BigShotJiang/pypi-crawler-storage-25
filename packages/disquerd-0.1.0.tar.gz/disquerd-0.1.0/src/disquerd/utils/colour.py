from __future__ import annotations

__all__ = ("Colour", "Color")


class Colour(int):
    __slots__ = ()

    def __new__(cls, value: int = 0) -> Colour:
        return super().__new__(cls, value & 0xFFFFFF)

    @property
    def r(self) -> int:
        return (self >> 16) & 0xFF

    @property
    def g(self) -> int:
        return (self >> 8) & 0xFF

    @property
    def b(self) -> int:
        return self & 0xFF

    def to_rgb(self) -> tuple[int, int, int]:
        return (self.r, self.g, self.b)

    @classmethod
    def from_rgb(cls, r: int, g: int, b: int) -> Colour:
        return cls((r << 16) | (g << 8) | b)

    @classmethod
    def from_hex(cls, hex_str: str) -> Colour:
        hex_str = hex_str.lstrip("#")
        return cls(int(hex_str, 16))

    def to_hex(self) -> str:
        return f"#{self:06x}"

    @classmethod
    def default(cls) -> Colour:
        return cls(0)

    @classmethod
    def teal(cls) -> Colour:
        return cls(0x1ABC9C)

    @classmethod
    def dark_teal(cls) -> Colour:
        return cls(0x11806A)

    @classmethod
    def green(cls) -> Colour:
        return cls(0x2ECC71)

    @classmethod
    def dark_green(cls) -> Colour:
        return cls(0x1F8B4C)

    @classmethod
    def blue(cls) -> Colour:
        return cls(0x3498DB)

    @classmethod
    def dark_blue(cls) -> Colour:
        return cls(0x206694)

    @classmethod
    def purple(cls) -> Colour:
        return cls(0x9B59B6)

    @classmethod
    def dark_purple(cls) -> Colour:
        return cls(0x71368A)

    @classmethod
    def magenta(cls) -> Colour:
        return cls(0xE91E63)

    @classmethod
    def dark_magenta(cls) -> Colour:
        return cls(0xAD1457)

    @classmethod
    def gold(cls) -> Colour:
        return cls(0xF1C40F)

    @classmethod
    def dark_gold(cls) -> Colour:
        return cls(0xC27C0E)

    @classmethod
    def orange(cls) -> Colour:
        return cls(0xE67E22)

    @classmethod
    def dark_orange(cls) -> Colour:
        return cls(0xA84300)

    @classmethod
    def red(cls) -> Colour:
        return cls(0xE74C3C)

    @classmethod
    def dark_red(cls) -> Colour:
        return cls(0x992D22)

    @classmethod
    def lighter_grey(cls) -> Colour:
        return cls(0x95A5A6)

    @classmethod
    def dark_grey(cls) -> Colour:
        return cls(0x607D8B)

    @classmethod
    def light_grey(cls) -> Colour:
        return cls(0x979C9F)

    @classmethod
    def darker_grey(cls) -> Colour:
        return cls(0x546E7A)

    @classmethod
    def blurple(cls) -> Colour:
        return cls(0x5865F2)

    @classmethod
    def dark_embed(cls) -> Colour:
        return cls(0x2B2D31)

    @classmethod
    def fuchsia(cls) -> Colour:
        return cls(0xEB459E)

    @classmethod
    def yellow(cls) -> Colour:
        return cls(0xFEE75C)

    def __repr__(self) -> str:
        return f"Colour({self.to_hex()})"


Color = Colour
