from __future__ import annotations

import io
from typing import Any

__all__ = ("File",)


class File:
    __slots__ = ("filename", "description", "_fp", "_data", "spoiler")

    def __init__(
        self,
        fp: str | io.IOBase,
        filename: str | None = None,
        description: str | None = None,
        spoiler: bool = False,
    ) -> None:
        self._fp: str | None = None
        self._data: bytes | None = None
        self.filename = filename or (getattr(fp, "name", "unknown") if isinstance(fp, io.IOBase) else str(fp))
        self.description = description
        self.spoiler = spoiler

        if isinstance(fp, str):
            self._fp = fp
        elif isinstance(fp, (io.IOBase, io.RawIOBase)):
            self._data = fp.read()
            if isinstance(self._data, str):
                self._data = self._data.encode()
        elif isinstance(fp, bytes):
            self._data = fp
        else:
            self._fp = str(fp)

    def read(self) -> bytes:
        if self._data is not None:
            return self._data
        if self._fp is not None:
            with open(self._fp, "rb") as f:
                return f.read()
        return b""

    def to_payload(self) -> dict[str, Any]:
        payload: dict[str, Any] = {"filename": self.filename}
        if self.description:
            payload["description"] = self.description
        return payload
