from __future__ import annotations

from typing import Any

from disquerd.utils.colour import Colour

__all__ = ("Embed", "embed")


class EmbedField:
    __slots__ = ("name", "value", "inline")

    def __init__(self, name: str, value: str, inline: bool = False) -> None:
        self.name = name
        self.value = value
        self.inline = inline

    def to_dict(self) -> dict[str, Any]:
        return {"name": self.name, "value": self.value, "inline": self.inline}


class EmbedFooter:
    __slots__ = ("text", "icon_url")

    def __init__(self, text: str, icon_url: str | None = None) -> None:
        self.text = text
        self.icon_url = icon_url

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {"text": self.text}
        if self.icon_url:
            d["icon_url"] = self.icon_url
        return d


class EmbedAuthor:
    __slots__ = ("name", "url", "icon_url")

    def __init__(self, name: str, url: str | None = None, icon_url: str | None = None) -> None:
        self.name = name
        self.url = url
        self.icon_url = icon_url

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {"name": self.name}
        if self.url:
            d["url"] = self.url
        if self.icon_url:
            d["icon_url"] = self.icon_url
        return d


class EmbedImage:
    __slots__ = ("url",)

    def __init__(self, url: str) -> None:
        self.url = url

    def to_dict(self) -> dict[str, Any]:
        return {"url": self.url}


class Embed:
    __slots__ = ("title", "description", "url", "color", "fields", "footer", "author", "image", "thumbnail", "timestamp")

    def __init__(
        self,
        *,
        title: str | None = None,
        description: str | None = None,
        url: str | None = None,
        color: Colour | int | None = None,
        colour: Colour | int | None = None,
        timestamp: str | None = None,
    ) -> None:
        self.title = title
        self.description = description
        self.url = url
        self.color = color if color is not None else colour
        self.fields: list[EmbedField] = []
        self.footer: EmbedFooter | None = None
        self.author: EmbedAuthor | None = None
        self.image: EmbedImage | None = None
        self.thumbnail: EmbedImage | None = None
        self.timestamp = timestamp

    def set_title(self, title: str) -> Embed:
        self.title = title
        return self

    def set_description(self, description: str) -> Embed:
        self.description = description
        return self

    def set_url(self, url: str) -> Embed:
        self.url = url
        return self

    def set_color(self, color: Colour | int) -> Embed:
        self.color = color
        return self

    def set_timestamp(self, timestamp: str) -> Embed:
        self.timestamp = timestamp
        return self

    def set_footer(self, text: str, icon_url: str | None = None) -> Embed:
        self.footer = EmbedFooter(text, icon_url)
        return self

    def set_author(self, name: str, url: str | None = None, icon_url: str | None = None) -> Embed:
        self.author = EmbedAuthor(name, url, icon_url)
        return self

    def set_image(self, url: str) -> Embed:
        self.image = EmbedImage(url)
        return self

    def set_thumbnail(self, url: str) -> Embed:
        self.thumbnail = EmbedImage(url)
        return self

    def add_field(self, name: str, value: str, inline: bool = False) -> Embed:
        self.fields.append(EmbedField(name, value, inline))
        return self

    def insert_field_at(self, index: int, name: str, value: str, inline: bool = False) -> Embed:
        self.fields.insert(index, EmbedField(name, value, inline))
        return self

    def clear_fields(self) -> Embed:
        self.fields.clear()
        return self

    def to_dict(self) -> dict[str, Any]:
        data: dict[str, Any] = {}
        if self.title is not None:
            data["title"] = self.title
        if self.description is not None:
            data["description"] = self.description
        if self.url is not None:
            data["url"] = self.url
        if self.color is not None:
            data["color"] = int(self.color)
        if self.timestamp is not None:
            data["timestamp"] = self.timestamp
        if self.footer is not None:
            data["footer"] = self.footer.to_dict()
        if self.author is not None:
            data["author"] = self.author.to_dict()
        if self.image is not None:
            data["image"] = self.image.to_dict()
        if self.thumbnail is not None:
            data["thumbnail"] = self.thumbnail.to_dict()
        if self.fields:
            data["fields"] = [f.to_dict() for f in self.fields]
        return data


def embed(
    title: str | None = None,
    description: str | None = None,
    *,
    color: Colour | int | None = None,
    fields: list[tuple[str, str]] | None = None,
    footer: str | None = None,
    author: str | None = None,
    image: str | None = None,
    thumbnail: str | None = None,
    url: str | None = None,
) -> Embed:
    e = Embed(title=title, description=description, url=url, color=color)
    if fields:
        for name, value in fields:
            e.add_field(name, value)
    if footer:
        e.set_footer(footer)
    if author:
        e.set_author(author)
    if image:
        e.set_image(image)
    if thumbnail:
        e.set_thumbnail(thumbnail)
    return e
