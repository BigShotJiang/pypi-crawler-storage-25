from __future__ import annotations

import time

__all__ = ("Snowflake",)

_DISCORD_EPOCH = 1420070400000


class Snowflake(int):
    __slots__ = ()

    @property
    def timestamp(self) -> float:
        return ((self >> 22) + _DISCORD_EPOCH) / 1000.0

    @property
    def created_at(self) -> float:
        return self.timestamp

    @property
    def worker_id(self) -> int:
        return (self >> 17) & 0x1F

    @property
    def process_id(self) -> int:
        return (self >> 12) & 0x1F

    @property
    def increment(self) -> int:
        return self & 0xFFF

    @classmethod
    def from_timestamp(cls, ts: float) -> Snowflake:
        ms = int(ts * 1000 - _DISCORD_EPOCH)
        return cls(ms << 22)

    @classmethod
    def now(cls) -> Snowflake:
        return cls.from_timestamp(time.time())

    def __repr__(self) -> str:
        return f"Snowflake({int(self)})"

    def __str__(self) -> str:
        return str(int(self))
