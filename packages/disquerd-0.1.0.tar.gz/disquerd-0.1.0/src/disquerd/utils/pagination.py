from __future__ import annotations

import asyncio
from typing import Any

from disquerd.ui.view import View
from disquerd.ui.button import Button
from disquerd.utils.embed import Embed

__all__ = ("Paginator",)


class Paginator(View):
    __slots__ = ("_pages", "_current", "_message", "_author_id", "_timeout")

    def __init__(
        self,
        pages: list[str | Embed],
        *,
        author_id: int | None = None,
        timeout: float = 180.0,
    ) -> None:
        super().__init__(timeout=timeout)
        self._pages = pages
        self._current = 0
        self._message: dict[str, Any] | None = None
        self._author_id = author_id
        self._timeout = timeout

        self._prev_btn = Button(emoji="\u25c0", style=2, disabled=True, custom_id="pag_prev")
        self._next_btn = Button(emoji="\u25b6", style=2, custom_id="pag_next")
        self._stop_btn = Button(emoji="\u23f9", style=4, custom_id="pag_stop")

        self._prev_btn.callback = self._go_prev
        self._next_btn.callback = self._go_next
        self._stop_btn.callback = self._stop

        self.add_item(self._prev_btn)
        self.add_item(self._next_btn)
        self.add_item(self._stop_btn)

    def _update_buttons(self) -> None:
        self._prev_btn.disabled = self._current == 0
        self._next_btn.disabled = self._current >= len(self._pages) - 1

    @property
    def current_page(self) -> int:
        return self._current

    @property
    def total_pages(self) -> int:
        return len(self._pages)

    def _get_content(self) -> dict[str, Any]:
        page = self._pages[self._current]
        self._update_buttons()
        payload: dict[str, Any] = {"components": self.to_dict()}

        if isinstance(page, Embed):
            payload["embeds"] = [page.to_dict()]
        else:
            payload["content"] = f"{page}\n`Page {self._current + 1}/{self.total_pages}`"

        return payload

    async def _go_prev(self, interaction: Any) -> None:
        if self._author_id and interaction.get("member", {}).get("user", {}).get("id") != str(self._author_id):
            return
        if self._current > 0:
            self._current -= 1
            await self._respond(interaction, self._get_content())

    async def _go_next(self, interaction: Any) -> None:
        if self._author_id and interaction.get("member", {}).get("user", {}).get("id") != str(self._author_id):
            return
        if self._current < len(self._pages) - 1:
            self._current += 1
            await self._respond(interaction, self._get_content())

    async def _stop(self, interaction: Any) -> None:
        self.stop()
        for item in self._children:
            item.disabled = True
        payload: dict[str, Any] = {"components": self.to_dict()}
        if self._pages[self._current] and isinstance(self._pages[self._current], str):
            payload["content"] = self._pages[self._current]
        await self._respond(interaction, payload)

    async def _respond(self, interaction: Any, data: dict[str, Any]) -> None:
        pass

    def get_initial_payload(self) -> dict[str, Any]:
        self._update_buttons()
        return self._get_content()
