from __future__ import annotations

from typing import Any, Callable

from disquerd.client import Bot, Intents
from disquerd._types import Coro, EventType

__all__ = ("quick", "use_template")


_BUILTIN_TEMPLATES: dict[str, Callable[[Bot], None]] = {}


def _register_template(name: str) -> Callable[[Callable[[Bot], None]], Callable[[Bot], None]]:
    def decorator(func: Callable[[Bot], None]) -> Callable[[Bot], None]:
        _BUILTIN_TEMPLATES[name] = func
        return func
    return decorator


@_register_template("basic")
def _basic_template(bot: Bot) -> None:
    @bot.slash_command(name="ping", description="Check bot latency")
    async def _ping(ctx: Any) -> None:
        await ctx.respond("Pong!")

    @bot.slash_command(name="info", description="Show bot info")
    async def _info(ctx: Any) -> None:
        from disquerd.utils.embed import embed
        await ctx.respond(
            embed=embed(
                "Bot Info",
                f"Running on **Disquerd** v0.1.0\n"
                f"Serving **{len(bot.guilds)}** guilds",
                color=0x5865F2,
                fields=[
                    ("Guilds", str(len(bot.guilds))),
                    ("Latency", "Calculated..."),
                ],
            )
        )


@_register_template("moderation")
def _moderation_template(bot: Bot) -> None:
    _basic_template(bot)

    @bot.slash_command(name="kick", description="Kick a member")
    async def _kick(ctx: Any, member: str = "", reason: str = "") -> None:
        if not ctx.member or not ctx.member.permissions & (1 << 1):
            await ctx.respond("You don't have permission to kick members.", ephemeral=True)
            return
        await ctx.respond(f"Kicked {member}. Reason: {reason or 'No reason provided.'}")

    @bot.slash_command(name="ban", description="Ban a member")
    async def _ban(ctx: Any, member: str = "", reason: str = "") -> None:
        if not ctx.member or not ctx.member.permissions & (1 << 2):
            await ctx.respond("You don't have permission to ban members.", ephemeral=True)
            return
        if await ctx.confirm(f"Are you sure you want to ban {member}?"):
            await ctx.respond(f"Banned {member}. Reason: {reason or 'No reason provided.'}")
        else:
            await ctx.respond("Ban cancelled.", ephemeral=True)


@_register_template("music")
def _music_template(bot: Bot) -> None:
    _basic_template(bot)

    @bot.slash_command(name="play", description="Play a song (stub)")
    async def _play(ctx: Any, query: str = "") -> None:
        await ctx.respond(f"Now playing: **{query}** (voice not implemented yet)")

    @bot.slash_command(name="queue", description="Show the queue (stub)")
    async def _queue(ctx: Any) -> None:
        await ctx.respond("Queue is empty.")


def quick(token: str, **kwargs: Any) -> Bot:
    bot = Bot(token, **kwargs)
    use_template(bot, "basic")
    return bot


def use_template(bot: Bot, name: str) -> None:
    template = _BUILTIN_TEMPLATES.get(name)
    if template is None:
        available = ", ".join(_BUILTIN_TEMPLATES) or "none"
        raise ValueError(f"Template {name!r} not found. Available: {available}")
    template(bot)
