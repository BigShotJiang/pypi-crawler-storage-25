from __future__ import annotations

from typing import Any

__all__ = ("_rest", "_state", "_bind_rest", "_bind_state")

_rest: Any = None
_state: Any = None


def _bind_rest(rest: Any) -> None:
    global _rest
    _rest = rest


def _bind_state(state: Any) -> None:
    global _state
    _state = state
