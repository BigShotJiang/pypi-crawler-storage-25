from __future__ import annotations

import asyncio
import logging
import zlib
from typing import Any

import aiohttp

from disquerd.errors.gateway import GatewayError

__all__ = ("WebSocketClient",)

_log = logging.getLogger(__name__)

_ZLIB_SUFFIX = b"\x00\x00\xff\xff"


def _json_loads(data: bytes | str) -> dict[str, Any]:
    try:
        import orjson
        return orjson.loads(data)
    except ImportError:
        import json
        if isinstance(data, bytes):
            data = data.decode("utf-8")
        return json.loads(data)


class WebSocketClient:
    __slots__ = ("_ws", "_session", "_url", "_heartbeat_interval", "_seq", "_session_id", "_zlib", "_buffer", "_use_compression")

    def __init__(self, session: aiohttp.ClientSession, url: str, *, use_compression: bool = True) -> None:
        self._ws: aiohttp.ClientWebSocketResponse | None = None
        self._session = session
        self._url = url
        self._heartbeat_interval: float = 0.0
        self._seq: int | None = None
        self._session_id: str | None = None
        self._zlib: zlib.Decompress | None = None
        self._buffer: bytearray = bytearray()
        self._use_compression = use_compression

    async def connect(self) -> None:
        if self._use_compression:
            self._zlib = zlib.decompressobj()
            self._buffer = bytearray()
        self._ws = await self._session.ws_connect(self._url, max_msg_size=2**24)

    async def close(self, code: int = 1000) -> None:
        if self._ws and not self._ws.closed:
            await self._ws.close(code=code)

    async def send(self, data: dict[str, Any]) -> None:
        if self._ws and not self._ws.closed:
            try:
                import orjson
                payload = orjson.dumps(data)
                await self._ws.send_bytes(payload)
            except ImportError:
                import json
                await self._ws.send_str(json.dumps(data))

    def _decompress(self, data: bytes) -> str | None:
        self._buffer.extend(data)
        if len(data) < 4 or data[-4:] != _ZLIB_SUFFIX:
            return None
        try:
            decompressed = self._zlib.decompress(self._buffer)
            self._buffer.clear()
            return decompressed.decode("utf-8")
        except zlib.error as e:
            _log.error("Zlib decompression failed: %s", e)
            self._buffer.clear()
            self._zlib = zlib.decompressobj()
            return None

    async def receive(self) -> dict[str, Any] | None:
        if self._ws is None or self._ws.closed:
            return None

        msg = await self._ws.receive()

        if msg.type == aiohttp.WSMsgType.TEXT:
            return _json_loads(msg.data)

        if msg.type == aiohttp.WSMsgType.BINARY:
            if self._use_compression:
                decompressed = self._decompress(msg.data)
                if decompressed is None:
                    return await self.receive()
                return _json_loads(decompressed)
            return _json_loads(msg.data)

        if msg.type in (aiohttp.WSMsgType.CLOSE, aiohttp.WSMsgType.CLOSING, aiohttp.WSMsgType.CLOSED):
            _log.info("WebSocket closed: %s", msg.data)
            return None

        if msg.type == aiohttp.WSMsgType.ERROR:
            _log.error("WebSocket error: %s", self._ws.exception())
            raise GatewayError(message=f"WebSocket error: {self._ws.exception()}")

        return None

    @property
    def is_closed(self) -> bool:
        return self._ws is None or self._ws.closed

    @property
    def sequence(self) -> int | None:
        return self._seq

    @sequence.setter
    def sequence(self, value: int | None) -> None:
        self._seq = value

    @property
    def session_id(self) -> str | None:
        return self._session_id

    @session_id.setter
    def session_id(self, value: str | None) -> None:
        self._session_id = value
