from __future__ import annotations

import asyncio
import logging
import time
from typing import Any

import aiohttp

from disquerd._types import MISSING, _MissingSentinel
from disquerd.errors.rest import (
    ForbiddenError,
    HTTPError,
    NotFoundError,
    RateLimitError,
    RESTError,
    UnauthorizedError,
)

__all__ = ("HTTPClient",)

_log = logging.getLogger(__name__)

_API_BASE = "https://discord.com/api/v10"
_USER_AGENT = f"Disquerd (https://github.com/disquerd, 0.1.0)"


class _RateLimitBucket:
    __slots__ = ("key", "lock", "remaining", "reset_after", "last_update")

    def __init__(self, key: str) -> None:
        self.key = key
        self.lock = asyncio.Lock()
        self.remaining = 1
        self.reset_after = 0.0
        self.last_update = 0.0

    def update(self, headers: dict[str, str]) -> None:
        self.remaining = int(headers.get("X-RateLimit-Remaining", "1"))
        self.reset_after = float(headers.get("X-RateLimit-Reset-After", "0"))
        self.last_update = time.monotonic()

    @property
    def is_limited(self) -> bool:
        return self.remaining <= 0 and self.reset_after > time.monotonic() - self.last_update


class HTTPClient:
    __slots__ = ("_session", "_token", "_buckets", "_global_lock", "_retries")

    def __init__(
        self,
        token: str,
        *,
        session: aiohttp.ClientSession | None = None,
        retries: int = 3,
    ) -> None:
        self._session = session
        self._token = token
        self._buckets: dict[str, _RateLimitBucket] = {}
        self._global_lock = asyncio.Lock()
        self._retries = retries

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession()
        return self._session

    def _bucket_for(self, path: str, major_id: int | str | None = None) -> _RateLimitBucket:
        key = f"{path}:{major_id or ''}"
        if key not in self._buckets:
            self._buckets[key] = _RateLimitBucket(key)
        return self._buckets[key]

    @staticmethod
    def _raise_for_status(status: int, data: dict[str, Any]) -> None:
        code = data.get("code")
        message = data.get("message", "")

        match status:
            case 400:
                raise HTTPError(status=status, code=code, message=message)
            case 401:
                raise UnauthorizedError(code=code, message=message)
            case 403:
                raise ForbiddenError(code=code, message=message)
            case 404:
                raise NotFoundError(code=code, message=message)
            case 429:
                retry_after = float(data.get("retry_after", 1.0))
                raise RateLimitError(retry_after=retry_after, code=code, message=message)
            case s if s >= 500:
                raise HTTPError(status=status, code=code, message=message)

    async def request(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, str] | None = None,
        reason: str | None = None,
        major_id: int | str | None = None,
    ) -> dict[str, Any] | None:
        bucket = self._bucket_for(path, major_id)
        headers = {
            "Authorization": f"Bot {self._token}",
            "User-Agent": _USER_AGENT,
        }
        if json is not None:
            headers["Content-Type"] = "application/json"
        if reason is not None:
            headers["X-Audit-Log-Reason"] = reason[:512]

        for attempt in range(self._retries):
            await self._global_lock.acquire()
            self._global_lock.release()

            async with bucket.lock:
                if bucket.is_limited:
                    _log.warning("Rate limited on bucket %s, sleeping %.1fs", bucket.key, bucket.reset_after)
                    await asyncio.sleep(bucket.reset_after)

                session = await self._get_session()
                url = f"{_API_BASE}{path}"

                try:
                    async with session.request(
                        method,
                        url,
                        headers=headers,
                        json=json,
                        params=params,
                    ) as resp:
                        bucket.update(dict(resp.headers))

                        if resp.status == 204:
                            return None

                        data = await resp.json()

                        if resp.status == 429:
                            is_global = data.get("global", False)
                            retry = float(data.get("retry_after", 1.0))
                            if is_global:
                                _log.warning("Global rate limit hit, sleeping %.1fs", retry)
                                await self._global_lock.acquire()
                                await asyncio.sleep(retry)
                                self._global_lock.release()
                            else:
                                await asyncio.sleep(retry)
                            continue

                        if resp.status >= 400:
                            self._raise_for_status(resp.status, data)

                        return data

                except aiohttp.ClientError as e:
                    _log.error("HTTP error on attempt %d: %s", attempt + 1, e)
                    if attempt == self._retries - 1:
                        raise HTTPError(status=0, message=str(e)) from e
                    await asyncio.sleep(1.0 * (attempt + 1))

        return None

    async def get(self, path: str, **kwargs: Any) -> dict[str, Any] | None:
        return await self.request("GET", path, **kwargs)

    async def post(self, path: str, **kwargs: Any) -> dict[str, Any] | None:
        return await self.request("POST", path, **kwargs)

    async def patch(self, path: str, **kwargs: Any) -> dict[str, Any] | None:
        return await self.request("PATCH", path, **kwargs)

    async def put(self, path: str, **kwargs: Any) -> dict[str, Any] | None:
        return await self.request("PUT", path, **kwargs)

    async def delete(self, path: str, **kwargs: Any) -> dict[str, Any] | None:
        return await self.request("DELETE", path, **kwargs)

    async def post_multipart(
        self,
        path: str,
        *,
        form: aiohttp.FormData,
        reason: str | None = None,
        major_id: int | str | None = None,
    ) -> dict[str, Any] | None:
        bucket = self._bucket_for(path, major_id)
        headers = {
            "Authorization": f"Bot {self._token}",
            "User-Agent": _USER_AGENT,
        }
        if reason is not None:
            headers["X-Audit-Log-Reason"] = reason[:512]

        async with bucket.lock:
            if bucket.is_limited:
                await asyncio.sleep(bucket.reset_after)

            session = await self._get_session()
            url = f"{_API_BASE}{path}"

            async with session.post(url, headers=headers, data=form) as resp:
                bucket.update(dict(resp.headers))
                if resp.status == 204:
                    return None
                data = await resp.json()
                if resp.status >= 400:
                    self._raise_for_status(resp.status, data)
                return data

    async def close(self) -> None:
        if self._session and not self._session.closed:
            await self._session.close()
