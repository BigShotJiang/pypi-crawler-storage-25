from __future__ import annotations

import typing
from enum import Enum

__all__ = ("Status", "EventType", "MISSING")


class _MissingSentinel:
    __slots__ = ()

    def __eq__(self, other: object) -> bool:
        return isinstance(other, _MissingSentinel)

    def __bool__(self) -> bool:
        return False

    def __repr__(self) -> str:
        return "..."

    def __hash__(self) -> int:
        return id(self)


MISSING: typing.Any = _MissingSentinel()


class Status(Enum):
    ONLINE = "online"
    OFFLINE = "offline"
    IDLE = "idle"
    DND = "dnd"
    INVISIBLE = "invisible"


class EventType(Enum):
    READY = "ready"
    RESUMED = "resumed"
    MESSAGE_CREATE = "message_create"
    MESSAGE_UPDATE = "message_update"
    MESSAGE_DELETE = "message_delete"
    INTERACTION_CREATE = "interaction_create"
    GUILD_CREATE = "guild_create"
    GUILD_UPDATE = "guild_update"
    GUILD_DELETE = "guild_delete"
    GUILD_MEMBER_ADD = "guild_member_add"
    GUILD_MEMBER_UPDATE = "guild_member_update"
    GUILD_MEMBER_REMOVE = "guild_member_remove"
    GUILD_ROLE_CREATE = "guild_role_create"
    GUILD_ROLE_UPDATE = "guild_role_update"
    GUILD_ROLE_DELETE = "guild_role_delete"
    CHANNEL_CREATE = "channel_create"
    CHANNEL_UPDATE = "channel_update"
    CHANNEL_DELETE = "channel_delete"
    THREAD_CREATE = "thread_create"
    THREAD_UPDATE = "thread_update"
    THREAD_DELETE = "thread_delete"
    VOICE_STATE_UPDATE = "voice_state_update"
    COMMAND = "command"
    COMMAND_COMPLETION = "command_completion"
    COMMAND_ERROR = "command_error"
    SLASH_COMMAND_ERROR = "slash_command_error"
    COMPONENT_ERROR = "component_error"
    MODAL_ERROR = "modal_error"


type Coro[T] = typing.Coroutine[typing.Any, typing.Any, T]
type MaybeCoro[T] = T | typing.Coroutine[typing.Any, typing.Any, T]
