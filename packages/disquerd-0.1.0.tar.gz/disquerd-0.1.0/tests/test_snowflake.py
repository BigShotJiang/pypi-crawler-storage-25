from disquerd.utils.snowflake import Snowflake


def test_snowflake_timestamp(snowflake_id):
    sf = Snowflake(snowflake_id)
    assert sf.timestamp > 0


def test_snowflake_components(snowflake_id):
    sf = Snowflake(snowflake_id)
    assert sf.worker_id >= 0
    assert sf.process_id >= 0
    assert sf.increment >= 0


def test_snowflake_from_timestamp():
    sf = Snowflake.from_timestamp(1700000000.0)
    assert isinstance(sf, Snowflake)
    assert sf.timestamp > 0


def test_snowflake_str_repr(snowflake_id):
    sf = Snowflake(snowflake_id)
    assert str(sf) == str(snowflake_id)
    assert "Snowflake" in repr(sf)
