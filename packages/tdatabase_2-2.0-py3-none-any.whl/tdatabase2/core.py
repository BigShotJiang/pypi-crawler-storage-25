import os
import re

current_db_path = None

def connect(host=None, username=None, password=None, name=None):
    global base_path, current_db_path
    
    if not host:
        print("Error: 'host' parameter is required.")
        return False

    if host != "localhost:3309":
        print("Error: Host must be 'localhost:3309'.")
        return False

    if not name:
        print("Error: 'name' (database name) parameter is required.")
        return False

    try:
        pc = os.getlogin()
        base_path = rf'C:\Users\{pc}\AppData\Roaming\..Tdatabase'
    except Exception:
        print("Error: Could not determine user path.")
        return False
    
    root_data_dir = os.path.join(base_path, 'root-data')
    root_db_path = os.path.join(root_data_dir, 'root.tdb')

    user_data_dir = os.path.join(base_path, 'data')
    user_db_filename = f"{name}.tdb"
    user_db_path = os.path.join(user_data_dir, user_db_filename)

    if not os.path.exists(root_db_path):
        print("Error: Root database file 'root.tdb' not found in 'root-data'.")
        return False

    try:
        with open(root_db_path, 'r', encoding='utf-8') as f:
            root_content = f.read()

        user_match = re.search(r'username:\s*"?([^"\s,}]+)"?', root_content)
        pass_match = re.search(r'password:\s*"?([^"\s,}]+)"?', root_content)

        if not user_match or not pass_match:
            print("Error: Invalid root database file format.")
            return False

        root_username = user_match.group(1).strip()
        root_password = pass_match.group(1).strip()

        input_user = username if username else ""
        input_pass = password if password else ""

        if input_user != root_username or input_pass != root_password:
            print("Username or password is incorrect.")
            return False

        if not os.path.exists(user_db_path):
            print(f"Error: Database file '{user_db_filename}' not found in 'data'.")
            return False

        current_db_path = user_db_path
        print('Hi, Tdatabase is active.')
        return True

    except Exception as e:
        print(f"Error reading file: {e}")
        return False

def parse_tdb_file(file_path=None):
    global current_db_path
    
    if file_path is None:
        if current_db_path is None:
            print("Error: No database connected. Please run connect() first.")
            return None
        file_path = current_db_path

    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        match = re.search(r'\{(.*?)\}', content, re.DOTALL)
        if not match:
            return None
            
        data_content = match.group(1)
        result_data = {}
        
        lines = data_content.strip().split('\n')
        
        for line in lines:
            line = line.strip()
            if not line or line.startswith('//'):
                continue
                
            if ':' in line:
                parts = line.split(':', 1)
                field_name = parts[0].strip()
                values_str = parts[1].strip().rstrip(',')
                
                values = re.findall(r'"([^"]+)"', values_str)
                
                if values:
                    result_data[field_name] = values
        
        return result_data
        
    except Exception as e:
        print(f"Error parsing file: {e}")
        return None

def get_user_data(username, fields=None):
    all_data = parse_tdb_file()
    
    if not all_data:
        return None

    if 'username' not in all_data:
        print("Error: No 'username' field found in database.")
        return None

    try:
        user_index = all_data['username'].index(username)
    except ValueError:
        print(f"User '{username}' not found.")
        return None

    user_info = {}
    
    if fields is None:
        fields = list(all_data.keys())

    for field in fields:
        if field in all_data:
            if user_index < len(all_data[field]):
                user_info[field] = all_data[field][user_index]
            else:
                user_info[field] = None
        else:
            user_info[field] = None

    return user_info

def get_value(username, field):
    data = get_user_data(username, fields=[field])
    
    if data and field in data:
        return data[field]
    else:
        return None

def add_category(category_name):
    """
    اضافه کردن یک ستون (Category) جدید به دیتابیس
    """
    all_data = parse_tdb_file()
    
    if not all_data:
        all_data = {}

    if category_name in all_data:
        print(f"Category '{category_name}' already exists.")
        return False

    all_data[category_name] = []
    
    try:
        with open(current_db_path, 'w', encoding='utf-8') as f:
            f.write("DATABASE main {\n")
            for key, values in all_data.items():
                values_str = ', '.join([f'"{v}"' for v in values])
                f.write(f"    {key}: {values_str},\n")
            f.write("}\n")
        
        print(f"Category '{category_name}' added successfully.")
        return True
    except Exception as e:
        print(f"Error saving file: {e}")
        return False

def add_value(**kwargs):
    """
    اضافه کردن یک ردیف (Row) جدید از داده‌ها
    kwargs: نام ستون و مقدار آن (مثلا username="ali", money=100)
    """
    all_data = parse_tdb_file()
    
    if not all_data:
        all_data = {}

    # محاسبه ID جدید (anum) اگر وجود داشته باشد
    new_id = 1
    if 'anum' in all_data and all_data['anum']:
        try:
            ids = [int(x) for x in all_data['anum'] if x.isdigit()]
            if ids:
                new_id = max(ids) + 1
        except ValueError:
            new_id = 1

    # اضافه کردن ID خودکار به kwargs اگر وجود داشته باشد
    if 'anum' not in kwargs:
        kwargs['anum'] = str(new_id)

    # اضافه کردن مقادیر به ستون‌های مربوطه
    for key, value in kwargs.items():
        if key not in all_data:
            all_data[key] = []
        
        all_data[key].append(str(value) if value is not None else "")

    # نوشتن مجدد فایل
    try:
        with open(current_db_path, 'w', encoding='utf-8') as f:
            f.write("DATABASE main {\n")
            for key, values in all_data.items():
                formatted_values = [v if v is not None else "" for v in values]
                values_str = ', '.join([f'"{v}"' for v in formatted_values])
                f.write(f"    {key}: {values_str},\n")
            f.write("}\n")
        
        print(f"Value added successfully.")
        return True

    except Exception as e:
        print(f"Error saving file: {e}")
        return False
