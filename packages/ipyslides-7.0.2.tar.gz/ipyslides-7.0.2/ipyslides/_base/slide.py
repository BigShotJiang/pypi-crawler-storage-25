"""Slide Object, should not be instantiated directly"""

import base64
import textwrap
from contextlib import contextmanager, suppress
from functools import wraps
from IPython.display import display
from IPython.utils.capture import RichOutput
from ipywidgets import HTML as ipwHTML, VBox

from . import styles
from ._layout import background_css, get_unique_css_class, loading_skeleton
from .styles import collapse_node, hide_node
from ..utils import XTML, html, _resolve_img, _styled_css, _build_css
from ..xmd import capture_content
from ..formatters import _Output, widget_from_data, slidebound

class Vars:
    """Container for markdown slide variables, to see and update variables
    set on a slide or a group of slides.
    
    - `slides.s1.vars.update(name="New")` updates variable 'name' on slide 1 only
    - `slides.s2.vars.pop('age')` removes variable 'age' from slide 2 only, so it is picked from notebook scope
    - `slides.s3.vars.clear()` clears all variables set on slide 3 only, so they are picked from notebook scope
    - `slides[:].vars.update(theme='dark')` updates variable 'theme' on all slides
    - `slides[1:3].vars.pop('title')` removes variable 'title' from slide 1 and 2 only
    - `slides[0].vars.scope` see variables with scope set on slide 0
    
    ::: note-tip
        If variables are not set on slide, they are picked from notebook scope if `Auto Rebuild` is enabled in side panel.
    """
    def __init__(self, *slides):
        self._slides = slides
    
    def __repr__(self):
        scp = self.scope # could be tuple of dicts or single dict
        scps = (scp,) if isinstance(scp, dict) else scp
        head = "Scope       Vars\n=====       ====\n"
        return head + str.join(f"\n-----       ----\n", 
            ('\n'.join(f"{sc:<12}{value}" 
            for sc, value in scp.items()) for scp in scps)
        )
    
    @property
    def scope(self):
        "Returns variables info at different levels. 0: Slide, 1: Notebook scope, 2: Undefined."
        scopes = tuple({
            f'Slide{s.number}': tuple(s._md_vars), # only those set on slide
            'Notebook': tuple(v for v in s._req_vars if v in s._app._nb_vars), # only for this slide out of all
            'Undefined': tuple(v for v in s._req_vars if v not in s._app._nb_vars),
        } for s in self._slides if s._has_vars) # only markdown slides have variables, no need to make empty dict
        return scopes[0] if len(scopes) == 1 else scopes
    
    def update(self, **vars):
        """Update variables on a slide or group of slides. Unsed variables are ignored silently.
        
        - `slides.s1.vars.update(name="New Name", age=30)` updates variables 'name' and 'age' on slide 1 only.
        - `slides[:].vars.update(theme='dark')` updates variable 'theme' on all slides.
        - `slides[1:3].vars.update(title="New Title")` updates variable 'title' on slide 1 and 2 only.
        """
        for s in self._slides:
            s._md_vars.update({k:v for k,v in vars.items() if k in s._has_vars}) # only update required vars
            s._rebuild(True if len(self._slides) == 1 else False) # go there only if single slide
        
    __call__ = update # allow calling directly like slide.vars(...)
    
    def pop(self, *vars):
        "Remove variables from a slide or group of slides, so they are picked from higher scopes."
        for s in self._slides:
            for k in vars:
                s._md_vars.pop(k, None) # avoid key error if not present
            s._rebuild(True if len(self._slides) == 1 else False) # go there only if single slide
    
    def clear(self):
        "Clear all variables from a slide or group of slides, so they are picked from higher scopes."
        for s in self._slides:
            s._md_vars.clear()
            s._rebuild(True if len(self._slides) == 1 else False) # go there only if single slide


class Specs:
    """Slide configuration specs, can be set as content under slide or outside.
    Should not reset on slide build."""
    yoffset: int = None
    cssprops = None
    cssvars = None
    anim: str = None
    enim: str = None # page animation, will be removed
    
    def __getattr__(self, name):
        # Return None if not set on instance, but has in class
        if name in dir(type(self)):
            return None 
        raise AttributeError(f"{type(self).__name__!r} object has no attribute {name!r}")

    def __setattr__(self, name, value):
        # Only allow setting attributes that are defined in class, to avoid typos and unintended attributes
        if not name.startswith('_') and not hasattr(type(self), name):
            raise AttributeError(f"Can't set undefined attribute {name!r} on {type(self).__name__!r}")
        super().__setattr__(name, value)
    

class Slide:
    "Slide object, should not be instantiated directly by user."
    def __init__(self, app, number):
        self._widget = _Output(layout = dict(margin='auto',padding='8px', visibility='hidden')).add_class("SlideArea")
        self._app = app
        
        self._specs = Specs() # instance specs that are persistent accross builds 
        self._number = number
        self._index = number if number == 0 else None # First slide should have index ready
        self._sec_id = f"s-{id(self)}" # should there alway wether a section or not
        self._md_vars = {} # store variables set by build/rebuild on this slide
        self._esc_vars = {} # store escaped variables for rebuilds form build content
        self._source = {'text': '', 'language': ''} # Should be set at init once, since markdown needs to compare with previous
        self._set_defaults()
        self.vars = Vars(self) # to access variables info and update them
        self._bglayer = ipwHTML(layout={'margin': '0'}).add_class('print-only') # background layer for this slide, persistent
        self._ftrhtml = ipwHTML(layout={'margin':'0'}).add_class('print-only') # dynamyic footer with sections per slides
    
    def __setattr__(self, name: str, value):
        if not name.startswith('_') and hasattr(self, name):
            raise AttributeError(f"Can't reset attribute {name!r} on {self!r}")
        self.__dict__[name] = value
    
    def _set_defaults(self):
        for attr in ['_on_load', '_on_exit','_is_supp']:
            if hasattr(self, attr):
                delattr(self, attr) # reset these attributes if any
    
        self._notes = '' # Reset notes
        self._citations = {} # Reset citations
        self._section = None # Reset sec_key
        self._indexf = 0 # current frame index
        self._contents = [] # reset content to not be exportable 
        self._has_widgets = False # Update in _build_slide function
        self._has_vars = () # Update in _slide function for markdown slides only
        self._toc_args = () # empty by default
        self._widget.add_class(f"n{self.number}")
        self._fcss = ipwHTML(layout={"margin": "0","padding": "0","heigh": "0"}) # frame separator CSS
        self._lre_page = 0 # Leaset recently edited page number for quick jump while editing markdown
        self._bg_ikws = {} # rebuild always re-derives background mapping from content
  
    def _set_source(self, text, language):
        "Set source code for this slide. If"
        self._source = {'text': text, 'language': language}
    
    def _reset_source(self):
        "Reset old source but leave markdown source for observing chnages"
        if not self._markdown:
            self._set_source("","")
        
    def _on_load_private(self, func):
        with self._app._hold_running(): # slides will not be running during switch, so make it safe
            with capture_content() as cap: # check if code is correct
                out = func(self)
                if callable(out):
                    out(self) # test call to raise error if any
            
            if cap.outputs or cap.stdout:
                raise Exception('func in on_load(func) should not print or display anything!')
            elif cap.stderr:
                raise RuntimeError(f'func in on_load(func) raised an error. See above traceback!')
        
        # This should be itemside the try/except block even after finally, if successful, only then assign it.
        self._on_load = func # This will be called in main app
    
    def _run_on_load(self):
        "Called when a slide is loaded into view. Use it to register notifications, auto toggle laser pointer etc."
        # To ensure previous _on_exit and the new _on_load are called properly, try finally
        try:
            if callable(getattr(self,'_on_exit', None)):
                self._on_exit(self) # call exit function of previous slide if any
        finally: 
            if callable(getattr(self,'_on_load', None)):
                self._on_exit = self._on_load(self) # will be called when this slide is exited
        
    def __repr__(self):
        return f'Slide(number = {self.number}, index = {self.index}, nf = {self.nf})'
    
    @contextmanager
    def _capture(self):
        "Capture output to this slide."
        self._app._next_number = self.number + 1
        self._app._slides_per_cell.append(self) # will be flushed at end of cell by post_run_cell event
        self._set_defaults() 

        with suppress(Exception): # register only in slides building, not other cells
            self._app._register_postrun_cell()

        self._app._auto_rebuild(None) # avoid while building slides to trigger other updates, but keep auto_rebuild state by None
        
        with self._app._set_running(self):
            with capture_content() as captured:
                yield captured
            
            if (self.number == 0) and self._fidxs:
                self._frame_idxs = () # to be clear on next run
                raise ValueError(f"Title slide does not support frames!")

            if captured.stderr:
                if 'warning' in captured.stderr.lower():
                    print(captured.stderr) # Don't throw error on soft warnings
                else:
                    raise RuntimeError(f'Error in building {self}: {captured.stderr}')
            
            outputs = captured.outputs
            # Clean up delimiters: trailing, empty, adjacent, and around PAGE boundaries
            self._contents = self._cleanup_delimiters(outputs)
            self._contents.extend(self._handle_refs()) # add at end if any
            self._set_css_classes(remove = 'Out-Sync') # Now synced
            self.update_display()    

            if self._app.widgets.checks.focus.value: # User preference
                self._app._box.focus()
    
    def _cleanup_delimiters(self, outputs):
        """
        Clean up delimiters: remove outputs with only text/plain and no metadata,
        then remove trailing, empty, adjacent PARTs/PAGEs, PART after/before PAGE.
        """
        # First pass: skip outputs with only text/plain and no metadata
        filtered = []
        for out in outputs:
            metadata = getattr(out, 'metadata', None)
            if set(out.data.keys()) == {'text/plain'} and not metadata:
                continue
            filtered.append(out)

        # Build [None, "PAGE", ...] list
        delim_list = []
        for out in filtered:
            metadata = getattr(out, 'metadata', None)
            delim = metadata.get("DELIM", None) if metadata and isinstance(metadata, dict) else None
            delim_list.append(delim if delim in ("PAGE", "PART") else None)

        # Remove trailing delimiters
        while delim_list and delim_list[-1] is not None:
            delim_list.pop()
        filtered = filtered[:len(delim_list)]  # sync filtered outputs
    
        # Now, enumerate and apply rules
        indices = []
        prev_delim = None
        for i, delim in enumerate(delim_list):
            if delim is None:
                indices.append(i)
                prev_delim = None
                continue

            if delim == "PART":
                # PART right before PAGE or PART after PART
                next_delim = delim_list[i+1] if i+1 < len(delim_list) else None
                if next_delim == "PAGE" or prev_delim == "PART":
                    prev_delim = delim
                    continue
                indices.append(i)
                prev_delim = delim
                continue

            if delim == "PAGE":
                # Allow up PART before PAGE, skip multiple empty PAGEs
                if prev_delim == "PAGE":
                    prev_delim = delim
                    continue
                indices.append(i)
                prev_delim = delim
                continue

        return [filtered[i] for i in indices] 
     
    def update_display(self):
        "Update display of this slides including reloading citations, widgets etc."
        self._widget.clear_output(wait = True) # Clear, but don't go there
        # Need to know how many contents before user provide content
        with capture_content() as cap:
            display(VBox([
                    html('span', '', id = self._sec_id, css_class='Slide-UID').as_widget(), # span to not occupy space, need to remove from frames later.
                    self._bglayer, # background image layer
                    self._ftrhtml, # dynamic footer layer
                    self._fcss, # frame separator CSS
                ], layout = dict(margin='0',padding='0')).add_class('print-only').add_class('static-widget'), # static is must
                metadata={'skip-export':'export html assign itself'}
            )  # to register section id in DOM
            # show speaker notes at top (but after background stuff) if any to grab immediate attention of speaker, will be shown only in PDF.
            self._speaker_notes(returns=False) # displays directly if any
            
        self._offset = len(cap.outputs) # to offset frames later, store for export
                
        with self._widget:
            display(*cap.outputs) # speaker notes and metadata stuff as top
            for obj in self.contents:
                display(obj)
                if hasattr(obj, 'update_display'): 
                    obj.update_display() # Update metadata objects like columns
                elif (w := widget_from_data(obj.data)): # Output on top or in children
                    [c.update_display() for c in getattr(w, 'children',[w]) if isinstance(c, _Output)]
            
        # after others to take everything into account
        self._reset_frames(offset = self._offset)
        self._app._update_toc()
        self._app.settings.footer._update_footer() # this is live footer(not print), need to set section and number
        if self is self._app._current: # only on viewed slide, not in background rebuilds
            self._app.run_animation() # inform JS side of reload animation on update/build time without navigation
    
    def _rebuild(self, go_there=False):
        if not self._markdown and go_there: # this avoid printing logs during bacth rebuilds
            return print("Exception: Can only rebuild slides created purely from markdown!")
        
        with self._app.navigate_back(self.index if go_there else None):
            self._app._slide(f'{self.number} -m', self._markdown)
            self._app._unregister_postrun_cell() # Avoid showing slides in this rebuild
            self._app._auto_rebuild('ondemand') # set back to previous state as capture removes it
    
    @property
    def _req_vars(self):
        return tuple([v for v in self._has_vars if not v in self._md_vars]) # only those not set on slide

    def _reset_toc(self):
        items = []
        for s in self._app[:self.index]:
            if s._section:
                items.append({"c":"prev", "s":s})

        if self._section:
            items.append({"c":"this", "s":self})
        elif items:
            items[-1].update({"c":"this"})

        for s in self._app[self.index + 1:]:
            if s._section:
                items.append({"c":"next", "s":s})
        
        first_toc = True
        for s in self._app[:]:
            if s._toc_args and first_toc:
                s._widget.add_class('FirstTOC')
                first_toc = False
            else:
                s._widget.remove_class('FirstTOC')

        items = [XTML(textwrap.dedent('''
            <li class="toc-item {c}">
                <a href="#{s._sec_id}" class="slide-link citelink">{s._section}</a>
            </li>''').format(**sec))
            for sec in items]
        
        title, highlight = self._toc_args or ('## Contents {.align-left}', False)
        css_class = 'toc-list toc-extra' if highlight else 'toc-list'
        ol = self._app.html('ol', items, style='', css_class=css_class)
        
        return RichOutput(
            data = {'text/plain': title,'text/html': self._app.html('div', [title, ol]).value},
            metadata = {"DataTOC": self.number}) # to access later
    

    def _reset_frames(self, offset=0):
        self._widget.remove_class('HasFrames') # reset first
        frames, contents = [], self.contents  # get once
        pages = [
            i for i, c in enumerate(contents) 
            if isinstance(c.metadata, dict) and 
            c.metadata.get("DELIM","") == "PAGE"
        ]  # find page delimiters
        
        if pages:
            pages = [{"head": pages[0] - 1, "start": p, "end": (pages[i+1] if (i+1) < len(pages) else len(contents)) - 1} for i, p in enumerate(pages)]
        else:
            pages = [{"head": -1, "start": 0, "end": len(contents) - 1}] # One page by default
        
        for ip, page in enumerate(pages):
            if len(pages) > 1:
                page["page"] = ip + 1 # page number within slide to display only if more than one page
            # Parts inside head only take effect on first frame.
            # Also include index 0 when there is no PAGE delimiter at the start,
            # so a leading PART can trigger column incrementals.
            if ip == 0 and page["head"] > -1:
                start = 0
            elif page["start"] == 0 and contents and not (
                isinstance(contents[0].metadata, dict)
                and contents[0].metadata.get("DELIM", "") == "PAGE"
            ):
                start = 0
            else:
                start = page["start"] + 1
            if parts := self._resolve_parts(page, contents, range(start, page["end"] + 1)):
                parts[0]["anim"] = "next" # add animation flag to first part while navigative forward
                parts[-1]["anim"] = "prev" # add animation flag to last part while navigative backward
                frames.extend(parts)
            else:
                frames.append({**page, "anim": "both"}) # no parts, single frame, animate both ways
        
        # Add offeset to all indices to keep metadata available across all frames
        updated_persist = set()
        for i, frame in enumerate(frames):
            for key in ("head", "start", "part", "end"):
                if key in frame and isinstance(frame[key], int):
                    frames[i][key] += offset
            persist = frame.get("_snapshots_persist")
            if isinstance(persist, dict) and id(persist) not in updated_persist:
                if isinstance(persist.get("idx"), int):
                    persist["idx"] += offset
                updated_persist.add(id(persist))
        
        self._frame_idxs = tuple(frames) if len(frames) > 1 else ()
        if self._frame_idxs:
            self._widget.add_class('HasFrames') # make sure class is added
            self._reveal_frames() # shows a quick snaphots how frames (were built) will show up 
        elif hasattr(self, '_frame_idxs'): # from previous run may be
            del self._frame_idxs
        return frames
    
    def _resolve_parts(self, page, contents, indxs):
        ensure_dict = lambda meta: meta if isinstance(meta, dict) else {} # insure dict type
        frames = []
        _snapshots_persist = None  # Track snapshots persistence after exiting columns
        last_index = None
        
        for index in indxs:
            last_index = index
            meta = ensure_dict(contents[index].metadata)
            if isinstance(meta, dict) and meta.get("DELIM", "") == "PART":
                if index == indxs.stop - 1: 
                    continue  # skip if PART is last in range
                
                meta_prev = ensure_dict(contents[index - 1].metadata) if index - 1 > 0 else {} # can go to PAGE index
                meta_next = ensure_dict(contents[index + 1].metadata) if index + 1 in indxs else {}
                
                # Single column flattened after PART with its ROW delimiters
                if ("FLATCOL" in meta_next):
                    for i in range(index, index + meta_next["FLATCOL"]):
                        meta_row = ensure_dict(contents[i].metadata) if i in indxs else {}
                        if meta_row.get("DELIM", "") == "ROW":
                            meta_row["DELIM"] = "PART"  # change ROW to PART for frame handling
                   
                # --- PART before COLUMNS ---
                if "COLUMNS" in meta_next:
                    # PART before COLUMNS should not create a trigger-only frame.
                    # This keeps previous content visible and shows the first column part together.
                    if meta.get("ISOLATE", False) and index > indxs.start:
                        new_frame = {**page, "part": index}
                        if _snapshots_persist:
                            new_frame["_snapshots_persist"] = _snapshots_persist
                        frames.append(new_frame)
                    # Pre-compute row isolation columns from writer metadata
                    snapshots_last_rows = {}
                    snapshots_cols = getattr(contents[index + 1], '_snapshots_cols', {})
                    if isinstance(snapshots_cols, dict):
                        snapshots_last_rows = {int(k): v for k, v in snapshots_cols.items() if isinstance(v, int)}
                    # Add frames for each column part, tracking previous row per column
                    prev_row_per_col = {}
                    for part in contents[index + 1]._parts:
                        new_frame = {**page, "part": index + 1, **part}
                        col = part.get("col")
                        if "row" in part:
                            if col in prev_row_per_col:
                                new_frame["prev_row"] = prev_row_per_col[col]
                            prev_row_per_col[col] = part["row"]
                        if snapshots_last_rows:
                            new_frame["_snapshots_last_rows"] = snapshots_last_rows
                        if _snapshots_persist:
                            new_frame["_snapshots_persist"] = _snapshots_persist
                        frames.append(new_frame)
                    # Persist snapshots columns collapse after exiting this writer.
                    if snapshots_last_rows:
                        _snapshots_persist = {"idx": index + 1, "_snapshots_last_rows": snapshots_last_rows}

                # --- PART after COLUMNS ---
                elif "COLUMNS" in meta_prev:
                    # If last frame was built by previous columns, skip this PART
                    if index == indxs.start or (frames and "col" in frames[-1]):
                        continue  # skip adding extra frame after columns parts
                    new_frame = {**page, "part": index}
                    if _snapshots_persist:
                        new_frame["_snapshots_persist"] = _snapshots_persist
                    frames.append(new_frame)

                # --- Regular PART ---
                elif index > indxs.start:
                    new_frame = {**page, "part": index}
                    if _snapshots_persist:
                        new_frame["_snapshots_persist"] = _snapshots_persist
                    frames.append(new_frame)

        # Ensure at least one frame at the end when last item is real content.
        # If the range ends with a trailing delimiter (e.g. from pause.iter default trail),
        # appending a frame here creates a no-op extra click.
        last_meta = ensure_dict(contents[last_index].metadata) if isinstance(last_index, int) else {}
        if frames and isinstance(last_index, int) and frames[-1].get("part", last_index) != last_index and not last_meta.get("DELIM", ""):
            new_frame = {**page, "part": last_index}
            if _snapshots_persist:
                new_frame["_snapshots_persist"] = _snapshots_persist
            frames.append(new_frame)
        return frames 
    
    @property
    def _fidxs(self):
        idxs = getattr(self, '_frame_idxs', ())
        if self._app.widgets.checks.merge.value:
            # Merge PART frames into single PAGE frame for export, PAGE will be depricated later:
            merged_frames = []
            for frame in idxs:
                frame = {k:v for k,v in frame.items() if k in ('head','start','end', 'page')} # remove part, col, row info
                if not frame in merged_frames: # unique frames only
                    merged_frames.append(frame)
            return tuple(merged_frames) if len(merged_frames) > 1 else () # should not single frame
        return idxs    
    
    @property
    def nf(self):
        "Number of total frames."
        return len(self._fidxs) or 1 # each slide is single frame
    
    def _update_view(self, which):
        self._set_progress()
        getattr(self._app.widgets.slidebox, 
            'remove_class' if which == 'next' else 'add_class'
        )('AnimPrev') # set content animation direction always even between parts
        
        # Determine if we should animate based on frame position and type
        frame = self._fidxs[self.indexf] if self._fidxs else {}
        anim = frame.get('anim', None)  # 'next', 'prev', or 'both'

        # Only animate on appropriate edges
        should_animate = anim == 'both' or anim == which
        
        if should_animate:
            if which == 'prev':
                self._app.widgets.slidebox.add_class('Prev') # Backwards Animation
            else:
                self._app.widgets.slidebox.remove_class('Prev') # remove backwards animation safely
            self._update_transition_objs()
        else:
            self._update_transition_objs(animation=False) # avoid animations between frames

        if self.index == self._app.wprogress.max: # This is last slide
            if self.indexf + 1 == self.nf:
                self._app._box.add_class("InView-Last")
            else:
                self._app._box.remove_class("InView-Last")
        
        self._app._send_nav_msg(
            which == 'next',
            parts = "part" in frame
        ) # inform JS side
        if any([ # first and last frames are speacial cases, handled by navigation if swicthing from other slide
            self.indexf == 0 and which == 'prev',
            self.indexf + 1 == self.nf and which == 'next',
            0 < self.indexf < (self.nf - 1)
        ]) and hasattr(self,'_on_load') and callable(self._on_load):
            self._on_load(self)
        
    def _frame_css(self, index):
        if not self._fidxs:
            return ''
        
        if index < 0 or index >= self.nf:
            raise IndexError(f"Frame index {index} out of range for slide {self.number} with {self.nf} frames!")
        
        # Build CSS to show only current frame's content
        css_rules = {}
        frame = self._fidxs[index]
        # Use merged frames if printing PDF
        if hasattr(self._app.settings, '_printingPDF'):
            if not self._fidxs or index >= len(self._fidxs):
                return ''  # its all parts in single frame, no CSS needed
            frame = self._fidxs[index]  

        # head content visible everywhere
        head_end = frame.get("head", -1) + 1 # CSS nth-child is 1-indexed
        if head_end > 0:
            css_rules[f'^:nth-child(-n + {head_end})'] = hide_node(False)
        
        # Collapse nodes between head and start
        start = frame["start"] + 1
        if head_end > 0 and start > head_end + 1:
            css_rules[f'^:nth-child(n + {head_end + 1}):nth-child(-n + {start - 1})'] = collapse_node(True)
        
        # Collapse nodes after end
        end = frame["end"] + 1
        css_rules[f'^:nth-child(n + {end + 1})'] = collapse_node(True)

        # Handle PART incremental frames
        if "part" in frame:
            part_end = frame["part"] + 1
            css_rules[f'^:nth-child(n + {start}):nth-child(-n + {part_end})'] = hide_node(False)
            # Hide content after part
            if part_end < end:
                css_rules[f'^:nth-child(n + {part_end + 1}):nth-child(-n + {end})'] = hide_node(True)

            # Handle column incremental display
            if "col" in frame:
                col_idx = frame["col"]
                # Within the PART output (which contains COLUMNS), hide columns after current one
                col_sel = f'^:nth-child({part_end}) > .jp-OutputArea-output > .columns.writer:first-of-type > div'
                css_rules[f'{col_sel}:nth-child(n + {col_idx + 2})'] = hide_node(True)

                if "row" in frame:
                    # Hide rows after current one in the current column
                    rows_hide = frame["row"] + 2 # +2 to start hiding after this row
                    css_rules[f'{col_sel}:nth-child({col_idx + 1}) > .jp-OutputArea > .jp-OutputArea-child:nth-child(n + {rows_hide})'] = hide_node(True)

                    # snapshots: collapse non-current rows so only the active row is visible
                    if col_idx in frame.get("_snapshots_last_rows", {}):
                        focus_sel = f'^:nth-child({part_end}) > .jp-OutputArea-output > .columns.writer:first-of-type > div.snapshots-rows'
                        row_sel = f'{focus_sel}:nth-child({col_idx + 1}) > .jp-OutputArea > .jp-OutputArea-child'
                        if "prev_row" in frame:
                            css_rules[f'{row_sel}:nth-child(-n + {frame["prev_row"] + 1}):not(:has(.group-header-content))'] = collapse_node(True)
                        css_rules[f'{row_sel}:nth-child(n + {frame["row"] + 1}):not(:has(.group-header-content))'] = collapse_node(True)

                # snapshots: collapse non-last rows in previous columns and current col when fully visible
                snapshots_last_rows = frame.get("_snapshots_last_rows", {})
                if snapshots_last_rows:
                    focus_sel = f'^:nth-child({part_end}) > .jp-OutputArea-output > .columns.writer:first-of-type > div.snapshots-rows'
                    # Previous columns: show only last row, collapse the rest
                    for c in range(col_idx):
                        if c in snapshots_last_rows:
                            prev_row_sel = f'{focus_sel}:nth-child({c + 1}) > .jp-OutputArea > .jp-OutputArea-child'
                            css_rules[f'{prev_row_sel}:nth-child(-n + {snapshots_last_rows[c] + 1}):not(:has(.group-header-content))'] = collapse_node(True)
                    # Current column fully visible (no row): show only last row
                    if "row" not in frame and col_idx in snapshots_last_rows:
                        curr_row_sel = f'{focus_sel}:nth-child({col_idx + 1}) > .jp-OutputArea > .jp-OutputArea-child'
                        css_rules[f'{curr_row_sel}:nth-child(-n + {snapshots_last_rows[col_idx] + 1}):not(:has(.group-header-content))'] = collapse_node(True)

        # Persistent snapshots: collapse non-last rows in columns we already exited
        if "_snapshots_persist" in frame:
            persist = frame["_snapshots_persist"]
            cols_idx = persist["idx"] + 1  # 1-indexed for CSS
            focus_sel = f'^:nth-child({cols_idx}) > .jp-OutputArea-output > .columns.writer:first-of-type > div.snapshots-rows'
            for c, last_row in persist["_snapshots_last_rows"].items():
                row_sel = f'{focus_sel}:nth-child({c + 1}) > .jp-OutputArea > .jp-OutputArea-child'
                css_rules[f'{row_sel}:nth-child(-n + {last_row + 1}):not(:has(.group-header-content))'] = collapse_node(True)

        # Build final CSS with proper selector
        base_selector = f'^.n{self.number}.HasFrames > .jp-OutputArea > .jp-OutputArea-child'
        final_css = {base_selector: css_rules}
    
        return _styled_css(final_css).value
    
    def _show_frame(self, which):
        if self._fidxs:
            if (which == 'next') and ((self.indexf + 1) < self.nf):
                self._indexf += 1
            elif (which == 'prev') and ((self.indexf - 1) >= 0):
                self._indexf -= 1
            else:
                return False
            
            self._fcss.value = self._frame_css(self.indexf)
            self._update_view(which)
            return True # indicators required
        else:
            self._fcss.value = '' # clear frame css if any
            return False
    
    def next_frame(self):
        "Jump to next frame and return True. If no next frame, returns False"
        return self._show_frame('next')
        
    def prev_frame(self):
        "Jump to previous frame and return True. If no previous frame, returns False"
        return self._show_frame('prev')
    
    def _reset_indexf(self, new_index, func): 
        old = int(self.indexf) # avoid pointing to property
        self._indexf = new_index
        condition = False
        try:
            condition = func()
        except Exception as e:
            self._app.notify(f"Error while resetting frame index: {e}", 10)
        finally:
            if not condition:
                self._indexf = old
            return condition
    
    def first_frame(self):
        "Jump to first frame."
        return self._reset_indexf(-1, self.next_frame)  # go left and switch forward
    
    def last_frame(self):
        "Jump to last frame"
        return self._reset_indexf(self.nf, self.prev_frame) # go right and swicth back
    
    def _reveal_frames(self):
        "Reveal frames on current page incrementally if any, during update_display to have a quick snaphot how frames are built."
        self.first_frame() # go to first frame by default
        step_count = 0
        if self._lre_page > 0: # page being edited, legacy behavior to be dprecated later
            step_count = sum(1 for frame in self._fidxs[1:] if frame.get("page", 0) < self._lre_page)
            self._lre_page = 0 # reset at first jump
        else:
            # Get to all parts on edit incrementally: NOTE: This behavior would remain after page deprecation
            step_count = len(self._fidxs[1:])

        # Frontend-only staged reveal for current slide; avoids blocking kernel during batch rebuilds.
        if step_count > 0 and (self is self._app._current): # only for current slide, do not overload unseen slides in the update_display mode
            self._app.widgets.iw.msg_tojs = f"REVEAL:{step_count}"
    
    def _set_progress(self):
        if self is not self._app._current: return # avoid wrong indicators
        value = self._app._progress_value(self, self.indexf)
        if value is None:
            # Progress completes before supplemental section and stays navigable.
            self._app.widgets._progbar.children[0].layout.width = "0%"
            self._app.widgets._progbar.layout.display = 'none'
        else:
            self._app.widgets._progbar.layout.display = ''
            self._app.widgets._progbar.children[0].layout.width = f"{value}%"

    @property
    def _disp_num(self):
        prefix = f"<span class='snumber-hint jupyter-only'>{self.number} → </span>" if not self._contents else "" # if empty slide, give hint of given slide number 
        if self.index > self._app._lms_idx:
            return f"{prefix}S.{self.index - self._app._lms_idx}" # 1-based supplemental slide number
        return f"{prefix}{self.index or ''}" # empty for zero
    
    def _handle_refs(self):
        "Display unused citations at end of slide."
        unused_citations = [c for c in self._citations.values() if not getattr(c, '_used', False)]
        with capture_content() as cap:
            if ret := self._build_refs(unused_citations):
                display(ret)
        return cap.outputs
    
    def _build_refs(self, citations, ncol=None):
        "Used by `Slides.refs()` as well as internally to display unused citations at end of slide."
        ncol = ncol if isinstance(ncol, int) else self._app.settings.layout.ncol_refs
        return html('div',
            sorted(citations, key=lambda x: x._id), 
            css_class='Citations text-small', 
            style = f'column-count: {ncol} !important;'
        ) if citations else None 
        
    def _speaker_notes(self, returns=False):
        if self._notes:
            out = html('div', self._notes, 
                css_class='speaker-notes print-only'
            ) # hidden in slides always, shown in print/export if enabled
            return out.value if returns else display(out)
        return ''
    
    def show(self):
        "Show this slide in cell."
        out = _Output().add_class('SlideArea')
        with out:
            display(*self.contents)
        return display(out)
    
    @slidebound
    def yoffset(self, value):
        "Use Slides.yoffset inseatd, this will be deprecated soon."
        self._app.yoffset(value) # this slide will be picked automatically. NEED DEPRECATION
    
    def _yoffset_css(self, shared=False):
        yoffset = type(self._specs).yoffset if shared else self._specs.yoffset
        if not isinstance(yoffset, int): return '' # no yoffset CSS if not set or '' from markdown
        
        selector = '.SlideArea' + ('' if shared else f'.n{self.number}.n{self.number}') 
        return self._app.html('style', textwrap.dedent(f'''
            .{self._app.uid} {selector} {{
                align-items: start !important;
                padding-top: calc({yoffset}% + 8px) !important;
            }}''')) # yoffset by padding top, align-content:start is important to take effect
    
    def _style_css(self, shared=False):
        props = type(self._specs).cssprops if shared else self._specs.cssprops
        cvars = type(self._specs).cssvars if shared else self._specs.cssvars
        if not any([props, cvars]):
            return ''
        
        css = ''
        suffix = f".n{self.number}" if not shared else ''
        if cvars:
            # Set CSS variables for theme colors at top level to be used when this slide will be shown
            css += _build_css((f".{self._app.uid}.SlidesWrapper:has(.ShowSlide{suffix})",), cvars) 
        
        # Also, allow theme colors to be used directly per slide during print and export
        props = {**(cvars or {}), '.jp-OutputArea-output': props} # wrap below output area to avoid messing layout, but colors need to be at Slide Level
        if props:
            klass = f".{self._app.uid}.SlidesWrapper .SlideArea{suffix}" # strong selector base
            css += _build_css((klass,), props)
        return self._app.html('style', css)

        
    @property
    def notes(self): return self._notes
    
    @property
    def number(self): return self._number
    
    @property
    def css(self):
        "Returns CSS for this slide including overall CSS. Used while navigating to this slide."
        return XTML(textwrap.dedent(f"""
            {self._yoffset_css(shared=True)}
            {self._yoffset_css(shared=False)}
            {self._style_css(shared=True)}
            {self._style_css(shared=False)}
        """))

    def _update_transition_objs(self, animation=True):
        "Update objects that need to be re-displayed for transition to work properly, such as animation style changes at naviagtion time."
        objs = [] 
        if animation:
            objs.append(self.animation)
        
        # Only in jupyter
        if self._app.is_jupyter_session():
            self._app.widgets._tmp_out.clear_output(wait=True)
            with self._app.widgets._tmp_out:
                display(*objs)
    
    @property
    def index(self): return self._index

    @property
    def indexf(self):
        "Returns index of current displayed frame."
        return self._indexf if self._fidxs else 0
    
    @property
    def _markdown(self): 
        return self._source['text'] if self._source['language'] == 'markdown' else '' # Not All Slides have markdown
    
    @property
    def source(self):
        "Use get_source if you want to have a different name in top of block."
        return self.get_source(None)
    
    @property
    def animation(self):
        overall = type(self._specs).enim if self._fidxs else type(self._specs).anim
        return html('style', 
            styles.animations.get(self._specs.anim or overall, '').replace(
                '.SlideBox',f'.{self._app.uid} .SlideBox'
            )
        )
    
    @property
    def contents(self):
        outputs = []
        for out in self._contents:
            if "_MODEL_ID" in out.metadata: # need this for export
                outputs.append(widget_from_data(out.metadata["_MODEL_ID"]))
            elif 'DataTOC' in out.metadata:
                outputs.append(self._reset_toc())
            else:
                outputs.append(out)
                
        return tuple(outputs) 
    
    def get_source(self, name = None, height='400px', **kwargs):
        "Return source code of this slide, markdwon or python or None if no source exists. kwargs are passed to `Slides.code.from_string`."
        if self._source['text']:
            return self._app.code.from_string(**self._source, name = name, height=height, **kwargs)
        else:
            return self._app.code.cast('No source found!\n',language = 'markdown')

    def _mount_user_css(self):
        "Update persistent user CSS mount from slide-managed CSS state."
        css_text = lambda value: getattr(value, 'value', value) if value else ''
        overall_css = css_text(self._yoffset_css(shared=True)) + css_text(self._style_css(shared=True)) # overall CSS includes shared yoffset CSS if any
        slides_css = '\n'.join(
            css_text(s._yoffset_css()) + css_text(s._style_css())
            for s in self._app[:]
        )
        self._app.widgets.htmls.usercss.value = '\n'.join(x for x in (overall_css, slides_css) if x)
        if not self._app.this: # Otherwise it has side effects
            self._app.navigate_to(self.index)
    
    
    def set_css(self, this: dict=None, overall:dict=None, **theme_colors):
        """Use Slides.css instead. This will be deprecated soon."""
        if this is not None:
            self._app.css(this, self.number, **theme_colors)
        if overall is not None: # Avoid accidental re-write of overall CSS
            self._app.css(this, "all", **theme_colors) 

    def _set_css_classes(self, add=None, remove=None):
        "Set CSS classes on this slide separated by space. classes are remove first and add after it."
        if remove is not None: # remove first to enable toggle
            if not isinstance(remove, str):
                raise TypeError("CSS classes should be a string with each class separated by space")
            for c in remove.split():
                self._widget.remove_class(c)
        
        if add is not None:
            if not isinstance(add, str):
                raise TypeError("CSS classes should be a string with each class separated by space")
            for c in add.split():
                self._widget.add_class(c)

    @property
    def _css_class(self):
        "Readonly dom classes on this slide separated by space."
        return ' '.join(self._widget._dom_classes) # don't let things modify on orginal
    
    def set_bg_image(self, *args, **kwargs):
        """Removed legacy API.

        Use content-driven backgrounds with `Slides.bg(...)` in Python or `bg`...`` in markdown.
        """
        raise RuntimeError(
            "set_bg_image is removed. Use Slides.bg(...) while building a slide, "
            "or markdown bg`...` / bg[... ]`...` syntax."
        )

    def _set_bg_ikws(self, src=None, **kwargs):
        "Set per-slide background keywords directly; last call wins."
        self._bg_ikws = {} # reset state first to avoid stale values if src is None or invalid
        self._bglayer.value = '' # reset first to receive new content
        if src is None: return
        self._bg_ikws = {"src": src,"uclass": f"{self._sec_id}-bg", **kwargs}
        self._bglayer.value = self._get_bg_image(get_unique_css_class(), ikws=self._bg_ikws) 
    
    def _get_bg_image(self, selector, ikws=None):
        ikws = ikws if isinstance(ikws, dict) else {}
        if (image := _resolve_img(ikws.get('src',None), '100%')):
            if isinstance(image, str) and ("<svg" in image) and ("</svg>" in image):
                # Normalize svg to img so cover/contain behavior stays consistent across environments.
                svg_b64 = base64.b64encode(image.encode('utf-8')).decode('ascii')
                image = f'<img src="data:image/svg+xml;base64,{svg_b64}" alt="Background SVG"/>'

            return f'''<div class="BackLayer print-only {ikws['uclass']}">
            <style>
                {background_css(selector, **{k:v for k,v in ikws.items() if k != 'src'})}
            </style>
            {image}
            </div>'''
        return ''
    
     
    def set_animation(self, this=None, main = None, page = None):
        """Use Slides.transition instead. This will be deprecated soon."""
        for name in (this, main, page):
            if name and not name in styles.animations:
                raise KeyError(f'animation {name!r} not found. Use None to remove animation or one of {tuple(styles.animations.keys())}')
        
        type(self._specs).anim = main
        type(self._specs).enim = page
        self._specs.anim = this
        self._view_transition()# See effect of changes
    
    def _view_transition(self):
        if not self._app.this: # Otherwise it has side effects
            if self._app._current is self:
                self._update_transition_objs() # force refresh
            else:
                self._app.navigate_to(self.index) # Go there to see effects
    
    
    def _waiting_contents(self, info="Updating Slides ..."):
        """DO NOT TRY TO BE SMART HERE! Jupyter Handshake Delay is real!
        # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        # DO NOT REVERT TO WIDGET CLASS TOGGLING (.add_class / .remove_class)
        # Reason: The "Jupyter Handshake Delay."
        # Toggle state via Python kernel flushes instantly, but the Frontend (Browser) 
        # only acknowledges the "Task Finished" after DOM rendering is complete. 
        #
        # SOLUTION: Use clear_output(wait=True) with a hard-coded HTML/CSS skeleton.
        # This forces the browser to keep the shimmer visible until the next 
        # frame is fully ready to paint after update_display is called.
        # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        """
        self._widget.clear_output(wait=True)
        with self._widget:
            XTML(loading_skeleton(info)).display()
    
    def _pending(self): return hasattr(self, '_build_func') # built if no build_func

@contextmanager
def _build_slide(app, slide_number):
    "Use as contextmanager in Slides class to create slide."
    if not isinstance(slide_number, int):
        raise ValueError(f"slide_number should be int >= 0, got {slide_number}")

    if slide_number < 0:  # zero for title slide
        raise ValueError(f"slide_number should be int >= 0, got {slide_number}")
     
    if slide_number in app._slides_dict:
        this = app._slides_dict[slide_number] # Use existing slide is better as display is already there
        this._reset_source() # Reset old source but keep markdown for observing edits
    else:
        this = Slide(app, slide_number)
        app._slides_dict[slide_number] = this
        app.refresh() # rebuild slides to have index ready
       
    this._waiting_contents(f'Building Slide {this.number} ...') # show loading skeleton
    if not this._pending(): app.navigate_to(this.index) # avoid naviagting to lazy slides here
    with this._capture(): 
        yield this
        
    app.widgets.iw.msg_tojs = 'SwitchView' # enforce immediate view cleanup to avoid overlapping slides content
    for content in this._contents:
        if content.data.get('application/vnd.jupyter.widget-view+json',{}):
            this._has_widgets = True
            break # No need to check other widgets if one exists
    
    this._update_transition_objs() # any animation/CSS etc set during build should be applied immediately
    this._set_progress() # update progress bar after each build
    app.settings.footer._update_footer() # update footer after each build
    
class SlideGroup:
    """Proxy calls/attributes to multiple Slide instances.

    - Broadcasts Slide methods to all slides in group; returns None if all methods return None, else a tuple of results
    - Non-callable attributes return a tuple of values
    - Special attribute 'vars' returns a Vars proxy over the group
    - Behaves like a tuple for indexing/iteration; use .values to get underlying slides
    """
    def __init__(self, slides):
        self._slides = tuple(slides)

    def __repr__(self):
        ids = ','.join(str(s.number) for s in self._slides)
        return f"SlideGroup([{ids}])"

    def __len__(self): return len(self._slides)
    def __iter__(self): return iter(self._slides)
    def __contains__(self, item): return item in self._slides
    
    @property
    def values(self): 
        "Returns underlying Slide instances as a tuple."
        return self._slides

    def __getitem__(self, key):
        if isinstance(key, slice):
            return SlideGroup(self._slides[key])
        return self._slides[key]

    def __dir__(self):
        # expose public Slide attributes for completion
        slide_attrs = [n for n in dir(Slide) if not n.startswith('_')]
        return sorted(set(slide_attrs + ['vars', 'values'] + list(self.__dict__.keys())))

    def __getattr__(self, name: str):
        # Broadcast method or collect attribute across slides
        attr = getattr(Slide, name, None)
        if callable(attr):
            @wraps(attr)
            def _call(*args, **kwargs):
                results = tuple(getattr(s, name)(*args, **kwargs) for s in self._slides)
                return None if all(r is None for r in results) else results
            
            _call.__doc__ = f"Broadcast Slide.{name} to all slides in this group.\n" + (attr.__doc__ or '')
            return _call
        elif name == 'vars':
            return Vars(*self._slides)
        return tuple(getattr(s, name) for s in self._slides)
