"""
Author Notes: Classes in this module should only be instantiated in Slides class or it's parent class
and then provided to other classes via composition, not inheritance.
"""
import json
import traitlets
from contextlib import suppress

from traitlets import HasTraits, Int, Unicode, Bool, Float, TraitError
from pathlib import Path
from inspect import Signature, Parameter
from IPython.display import Image, SVG
from ipywidgets.widgets.trait_types import InstanceDict

from ..formatters import code_css, htmlize
from ..utils import html, today, _clipbox_children, _resolve_img, get_clips_dir, set_dir
from . import styles, _layout
from ..dashlab import disabled


class ConfigTraits(HasTraits):
    def _apply_change(self, change=None): raise NotImplementedError
        
    @traitlets.observe(traitlets.All)
    def _observe(self, change):
        self._apply_change(change)

    @property
    def props(self):  
        return {
            k : v.props if isinstance(v, ConfigTraits) else v # clean up
            for k,v in self.trait_values().items()
        }

    @property
    def main(self): return Settings._instance

    def __repr__(self): 
        r = ", ".join(f"{k}={repr(v) if isinstance(v,str) else v.__class__.__name__ if isinstance(v, ConfigTraits) else  v}" for k,v in self.props.items())
        return f'{self.__class__.__name__}({r})'

    def _set_props(self, **kwargs):
        self.unobserve_all()
        try:
            for key, value in kwargs.items():
                if not self.has_trait(key):
                    raise TraitError(f"trait {key!r} does not exits!")
                self.set_trait(key, value)
            self._apply_change(None)
        finally:
            self.observe(self._observe, names=traitlets.All)
        return self.main # For method chaining
    
def fix_sig(cls):
    parameters=[Parameter('self', Parameter.POSITIONAL_ONLY), 
        *[Parameter(key, Parameter.POSITIONAL_OR_KEYWORD, default=value.default_value) for key,value in cls.class_traits().items()]]
    def set_props(self, **kwargs): return cls._set_props(self, **kwargs) 
    cls.__call__ = set_props # need new function each time
    cls.__call__.__signature__ = Signature(parameters) # can only be set over class level
    return cls

@fix_sig
class StylePerTheme(ConfigTraits):
    "Pygment code block style for each theme. You mostly need to change for custom and inherit theme."
    jupyter = Unicode('default')
    custom  = Unicode('default')
    light   = Unicode('friendly')
    dark    = Unicode('stata-dark')
    material_light = Unicode('manni')
    material_dark = Unicode('github-dark')

    def _apply_change(self, change): 
        self.main.code._apply_change(None) # works as validator too, run anyway
    
    def reset(self):
        "Reset all user set code block styles."
        with self.hold_trait_notifications():
            for key, value in zip(
                'inherit custom light dark material_light material_dark'.split(),
                'default default friendly native perldoc one-dark'.split()
                ):
                self.set_trait(key, value)
            self._apply_change(None)

@fix_sig
class Code(ConfigTraits):
    "Set code block styles. background and color may be needed for some styles."
    style_per_theme = InstanceDict(StylePerTheme, help="A pygment style for each theme.")
    color       = Unicode(allow_none=True)
    background  = Unicode(allow_none=True) 
    hover_color = Unicode("var(--bg3-color)")
    lineno      = Bool(True)

    def _apply_change(self, change): # need to set somewhere
        kwargs = {k:v for k,v in self.props.items() if k != 'style_per_theme'}
        kwargs['style'] = getattr(self.style_per_theme, self.main._widgets.theme.value.lower().replace(' ','_'))
        self.main._widgets.htmls.hilite.value = code_css(**kwargs)

@fix_sig
class Fonts(ConfigTraits):
    "Set fonts of text and code and size."
    heading = Unicode("Arial", allow_none=True, help="Heading font")
    text = Unicode("Roboto", allow_none=True)
    code = Unicode("Cascadia Code", allow_none=True)
    size = Int(16, help="Can use any large/small value that CSS supports!")

    def _apply_change(self, change):
        self.main._update_theme()

    @traitlets.validate('text','code', 'heading')
    def _fix_font(self, proposal):
        return ", ".join(repr(t.strip().strip('\"').strip("\'")) for t in proposal["value"].split(','))
    
    @traitlets.validate('size')
    def _change_slider_values(self, proposal):
        value, slider = proposal["value"], self.main._widgets.sliders.fontsize
        slider.max = max(value, min(64, slider.max))
        slider.min = min(value, max(8,slider.min))
        slider.value = value # Keep values in default [8,64] range when possible
        return value 

@fix_sig    
class Footer(ConfigTraits):
    "Set footer attributes of slides."
    text = Unicode('IPySlides', help="Set footer text. Can use Markdown")
    section = Bool(True, help="Show currently running section in footer when available.")
    numbering = Bool(True, help="Show/hide slide numbering in footer.")
    date = Unicode("today", allow_none=True, help="Set date string or use 'today' for current date.")
    controls = Bool(True, help="Show/hide controls like next/prev buttons and clickers in PDF/export mode.")
    progress = Bool(True, help="Show/hide progress bar at bottom of slides.")

    def _apply_change(self,change):
        # change is None when called as footer(...), so we update all things together
        self._update_footer() # html content updated
        wgts = self.main._widgets
        wgts._progbar.layout.display = "" if self.progress else "none" # show/hide progress bar
        wgts.iw._fpad = 23 if any([self.text, self.date, self.section, self.numbering]) else 16 # 16 is same around all sides unless footer needs more
        wgts.controls.layout.visibility = "visible" if self.controls else "hidden"
        wgts.iw.msg_tojs = 'RESCALE' # sets padding etc

        if not self.controls:
            self.main._slides.notify("Navigation controls hidden. But keyboard and edge click is still working!")
        
        for slide in self.main._slides:
            self._set_on(slide) # update footer per slide for print/export

    def _running_section_text(self, slide):
        "Get running section title via Slides._sectionindex and return stripped text." 
        for s in self.main._slides[:slide.index+1][::-1]: # revese from here
            if s._section:
                return s._section
        
        return ''

    def _update_footer(self):
        "Refresh footer html for runtime changes like running section updates."
        self.main._widgets.htmls.footer.value = self._to_html()
    
    def _set_on(self, slide):
        "Set footer for a slide when a section changes or footer is updated"
        slide._ftrhtml.value = self._to_html(slide)

    
    def _to_html(self, slide=None,fidx=0):
        if slide is None:
            slide = self.main._slides._current
        style = 'white-space:nowrap;margin-block:0;position:absolute;left:0;bottom:0;width:100%'
        inner = self.text
        if self.section and (running := self._running_section_text(slide)):
            inner += ("<span style='white-space:pre;opacity:0.4;'> \u2502 </span>" if inner else "") + f"<span class='section'>{running}</span>"
        if self.date:
            inner += (
                "<span style='white-space:pre;opacity:0.4;'> \u2502 </span>" if inner else ""
            ) + f'{today(fg = "var(--fg2-color)") if self.date == "today" else self.date}'
        
        inner = f'<div class="footer-text"><div>{inner}</div>'
        if self.controls:
            inner += self.main._get_clickers(slide) # clickers in footer when controls on, otherwise in separate div for better print layout
        if self.numbering:
            inner += f'<div class="slide-number">{slide._disp_num}</div>' # avoid 0 on title page
        inner += '</div>' # complete here
        
        if self.progress:
            pv = self.main._slides._progress_value(slide, fidx)
            if pv is not None: # supplemental otherwise
                unit = 100/(self.main._slides._lms_idx or 1) # unit progress value per slide
                pbar = f'<div class="sprogress-view" style="width:{pv}%;height:100%;background:var(--accent-color,blue);" data-cw="{pv}" data-uw="{unit}"></div>' # attributes for JS
                inner += f'<div class="slide-progress print-only" style="background:var(--bg2-color,#aaa4);width:100%;height:2px;">{pbar}</div>'
        return htmlize(f'<div markdown="1" class="slide-footer" style="{style}">{inner}</div>') 

@fix_sig
class Layout(ConfigTraits):
    "Set overall layout of slides."
    centered = Bool(True)
    scroll   = Bool(True)
    width    = Int(100)
    aspect   = Float(16/9.001, help="Aspect ratio of slides, width/height. Add a small value to avoid exact 16/9, 16/10 etc. which causes bottom border gap in some browsers.")
    ncol_refs = Int(2)
    theme    = Unicode('Jupyter')

    _reflow = False # internal use only
    _inotes = False # internal use only
    
    @traitlets.validate('width')
    def _limit_width(self, proposal):
        if not proposal["value"] in range(101):
            raise ValueError("width should in range [0,100]")
        return proposal["value"]
  
    def _apply_change(self, change):
        if change and change['owner'] == "theme":
            return self.main._update_theme({'owner':'layout'}) # otherwise colors don't apply to icons
        self.main._update_size(change = None) # will reset theme and send RESCALE message
    
    @traitlets.validate('theme')
    def _validate_theme(self, proposal):
        themes = self.main._widgets.theme.options
        if proposal["value"] not in themes:
            raise ValueError(f"Theme value expect on the followings: {themes!r}")
        self.main._widgets.theme.value = proposal["value"] # needs a robust update
        return proposal["value"] 

@fix_sig
class Toggle(ConfigTraits):
    "Toggle ON/OFF checks in settings panel."
    reflow = Bool(False)
    notes  = Bool(False)
    toast  = Bool(True)
    focus  = Bool(True, help="Focus on slide area when a slide is built or rebuilt.")
    rebuild= Bool(True, help="Auto rebuild markdown slides when an included notebook-scoped variable is updated.")

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for trait in self.class_own_traits():
            if widget := getattr(self.main._widgets.checks, trait, None):
                traitlets.link((self,trait),(widget, "value"))

    def _apply_change(self, change): pass

class AutoUnicode(Unicode):
    def validate(self, obj, value):
        if isinstance(value,(int, float)) and not isinstance(value, bool):
            value = f"{value}px"
        elif not isinstance(value, str):
            raise TraitError(f"The '{self.name}' trait of AutoUnicode instance expected str, int or float, not {type(value)}.")
        return super().validate(obj, value)

@fix_sig
class Logo(ConfigTraits):
    "Set logo for all slides. left and bottom take precedence over right and top respectively."
    src    = Unicode(allow_none=True)
    width  = AutoUnicode('60px')
    top    = AutoUnicode('4px')
    right  = AutoUnicode('4px')
    left   = AutoUnicode('', help='take precedence over right')
    bottom = AutoUnicode('', help='take precedence over top')

    @traitlets.validate('src')
    def _fix_path(self, proposal):
        if isinstance(proposal["value"], Path):
            return str(Path)
        return proposal["value"]

    def _set_props(self, **kwargs):
        self.bottom, self.left = '', '' # allow using top, right, otherwise these will take precedence
        return super()._set_props(**kwargs) # returns settings for chaining
    
    def _apply_change(self,change):
        if not self.src: # give as None, '' etc
            self.main._widgets.htmls.logo.value = ''
        elif (image := _resolve_img(self.src, self.width)):
            self.main._widgets.htmls.logo.value = image 
            kwargs = {k:v for k,v in self.props.items() if k !='src'}

            if self.bottom: kwargs.pop('top',None)
            if self.left: kwargs.pop('right', None)
            kwargs.update(dict(height='max-content', margin='0',padding='0',overflow='hidden'))
            self.main._widgets.htmls.logo.layout = kwargs # absolute position set in CSS, does not work here
        

class Settings:
    """
    Apply settings to slides programatically. Fewer settings are available as widgets.

    Settings can be nested or individual attributes as set as well. For example:
    ```python
    Slides.settings(layout = {"aspect": 16/10}) # Top 
    Slides.settings.layout(aspect = 16/10) # Individual
    Slides.settings.layout.aspect = 16/10  # Attribute
    ```
    All settings calls including top level returns settings instance to apply method chaining.
    e.g. code`Slides.settings.layout(aspect = 16/10).footer(text="ABC").logo(...)`.
    """
    _instance = None
    def __init__(self, _instanceSlides, _instanceWidgets):
        self._slides = _instanceSlides
        self._widgets = _instanceWidgets
        self.__class__._instance = self # After _widgets, _slides to enable access
        self.code   = Code()
        self.fonts  = Fonts()
        self.footer = Footer()
        self.layout = Layout()
        self.toggle = Toggle()
        self.logo   = Logo()
        
        self._wslider = self._widgets.sliders.width # Used in multiple places

        self._widgets.sliders.fontsize.observe(lambda c: self.fonts(size=c.new), names=["value"])
        self._widgets.theme.observe(self._update_theme, names=["value"])
        self._widgets.checks.reflow.observe(self._update_theme, names=["value"]) # set reflow through layout._reflow
        self._widgets.checks.inotes.observe(self._update_theme, names=["value"]) # set inline notes through layout._inotes
        self._widgets.checks.merge.observe(self._set_merge_class, names=["value"])
        self._widgets.buttons.print.on_click(self._print_pdf)
        self._wslider.observe(self._update_size, names=["value"])
        self._update_theme({'owner':'layout'})  # Trigger Theme with aspect changed as well
        self._update_size(change=None)  # Trigger this as well
        self._widgets.panelbox._clipsTab.children = _clipbox_children() # Set clipbox children

        self._traits = [key for key, value in self.__dict__.items() if isinstance(value, ConfigTraits)]
        parameters=[Parameter('self', Parameter.POSITIONAL_ONLY), 
        *[Parameter(key, Parameter.POSITIONAL_OR_KEYWORD, default=None) for key in self._traits]]
        type(self).__call__.__signature__ = Signature(parameters) # can only be set over class level
                                         
    def __call__(self, **kwargs):
        "Apply many settings at once! Can apply individual traits in a setting with assignment as well."
        for key, value in kwargs.items():
            if not key in self._traits:
                raise AttributeError(f"Settings has not trait attribute {key!r}")
            if value and not isinstance(value, dict):
                raise TypeError(f"{key} expects a dict, got {type(value)}")
            getattr(self, key)(**value)
        return self # For chaining

    def __setattr__(self, name: str, value):
        if not name.startswith('_') and hasattr(self, name):
            raise AttributeError(f"Can't reset attribute {name!r} on {self!r}")
        self.__dict__[name] = value

    def _set_merge_class(self, change=None):
        if self._widgets.checks.merge.value:
            self._widgets.mainbox.add_class('SlidesMerged')
        else:
            self._widgets.mainbox.remove_class('SlidesMerged')

    def _print_pdf(self, btn):
        if self._slides._next_pending:
            return self._slides.notify(
                self._slides.error("Print Error", "Please build pending slides by naviagting/clicking on 'Pending Slides' button before you can print to PDF.").value
            )
            
        with disabled(self._widgets.buttons.print): # disable button to avoid multiple clicks
            self._slides.notify("Loading PDF window… <br>Use <code class='info'>Save as PDF</code> to preserve links.", timeout=5)
            self._printingPDF = True # set before setting frame to pick correct content
                
            # Update frames indices for print
            parts = {}
            for slide in self._slides:
                frames = slide._fidxs
                # JS print flow handles per-frame visibility; clear runtime frame CSS to avoid over-hiding.
                slide._fcss.value = ''
                if frames: # merged parts automatically handled
                    parts[slide.number] = frames
                    
            self._widgets.iw._parts = parts
            # Send message to JS to start print
            self._widgets.iw.msg_tojs = 'PRINT'
            del self._printingPDF  # remove flag after use
    
    def _get_clickers(self, slide): # in PDF/export mode
        if len(self._slides) < 5 or slide.number == 0:
            return '' # no clicks for few slides or title page
        
        items = [getattr(item,'_sec_id','') for item in self._slides if item.index <= self._slides._lms_idx] # only before supplemnetal
        imax = len(items) - 1
        items = [items[int(round(i,0))] for i in [0, imax/4,imax/2, 3*imax/4, imax]]
        labels = '●●●●●'
        links = "".join(f'<a href="#{key}" class="clicker">{label}</a>' for (label,key) in zip(labels,items))
        return f'<div class="click-wrapper print-only"> {links} </div>' 

    def _update_size(self, change):
        self._widgets.mainbox.layout.height = "{:.2f}vw".format(self._wslider.value / self.layout.aspect)
        self._widgets.mainbox.layout.width = "{}vw".format(self._wslider.value)
        self._update_theme({'owner':'layout'})  # change aspect for Linked Output view too
        self._widgets.iw.msg_tojs = 'RESCALE'

    @property
    def _colors(self):
        return styles.theme_colors[self._widgets.theme.value]

    @property
    def _theme_kws(self):
        return dict(
            colors = self._colors,
            fonts  = self.fonts,
            layout = self.layout,
        )

    def _update_theme(self, change=None):
        # Only update layout CSS if theme changes, not on each call
        if change and change['owner'] in ('layout',self._widgets.theme): # function called with owner without widget works too much
            self._widgets.htmls.main.value = html('style',
                _layout.layout_css(self._colors['accent'],self.layout.aspect)
            ).value + _layout.loading_style # loading style should be always there
            
        # before applying style_css theme, set reflow and inotes
        self.layout._reflow = self._widgets.checks.reflow.value
        self.layout._inotes = self._widgets.checks.inotes.value
        
        theme_css = styles.style_css(**self._theme_kws)
        self._widgets.htmls.theme.value = html("style", theme_css).value
        if self._widgets.checks.notes.value:
            self._slides.notes.display() # Update notes window if open
        
        if self._widgets.theme.value == "Jupyter":
            msg = "THEME:jupyterlab"
        else:
            msg = 'THEME:dark' if "Dark" in self._widgets.theme.value else 'THEME:light'
        self._widgets.iw.msg_tojs = msg # changes theme of board
        self.code._apply_change(None) # Update code theme

    def load(self, path):
        "Load settings from a json file. You may need to dump settings and then edit for correct usage."
        file = Path(path)
        if file.exists():
            try:
                self(**json.loads(file.read_text()))
            except Exception as e:
                self._slides.notify(self._slides.error("Exception", str(e)))
        else:
            raise FileNotFoundError(f"File {path!r} does not exist!")

    def dump(self, path):
        "Dump the settings state to a json file. Use it once you have finalized a settings setup of slides."
        file = Path(path)
        _req_configs = { 
            key: getattr(self, key).props 
            for key in getattr(self,'_traits',[])
        }
        with file.open("w") as f: 
            json.dump(_req_configs, f, indent=4)
