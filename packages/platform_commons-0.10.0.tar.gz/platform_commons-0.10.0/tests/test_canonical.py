"""Tests for canonical entity registry (PSYNC-01)."""

import pytest

from platform_commons.canonical import (
    CANONICAL_AGENT_ROLES,
    CANONICAL_SCOPES,
    DEFAULT_BUDGET_TIERS,
    SCOPE_HIERARCHY,
    SERVICE_SCOPES,
    WORKER_SCOPES,
    is_valid_role,
    is_valid_scope,
    resolve_effective_budget,
)


class TestRoles:
    def test_contains_all_eight_roles(self) -> None:
        expected = {
            "analyst",
            "architect",
            "documentation",
            "validation",
            "execution",
            "review",
            "conversation",
            "human",
        }
        assert expected == CANONICAL_AGENT_ROLES

    def test_human_is_valid(self) -> None:
        assert is_valid_role("human") is True

    def test_unknown_role_invalid(self) -> None:
        assert is_valid_role("superadmin") is False

    def test_frozenset_immutable(self) -> None:
        with pytest.raises(AttributeError):
            CANONICAL_AGENT_ROLES.add("hacker")  # type: ignore[attr-defined]


class TestScopes:
    def test_service_scopes_subset(self) -> None:
        assert SERVICE_SCOPES <= CANONICAL_SCOPES

    def test_worker_scopes_subset(self) -> None:
        assert WORKER_SCOPES <= CANONICAL_SCOPES

    def test_no_overlap(self) -> None:
        assert frozenset() == SERVICE_SCOPES & WORKER_SCOPES

    def test_repo_read_is_valid(self) -> None:
        assert is_valid_scope("repo.read") is True

    def test_rag_decisions_read_is_valid(self) -> None:
        assert is_valid_scope("rag.decisions.read") is True

    def test_unknown_scope_invalid(self) -> None:
        assert is_valid_scope("nuclear.launch") is False

    def test_hierarchy_keys_are_valid_scopes(self) -> None:
        for parent in SCOPE_HIERARCHY:
            assert parent in CANONICAL_SCOPES, f"hierarchy parent {parent} not in CANONICAL_SCOPES"

    def test_hierarchy_values_are_valid_scopes(self) -> None:
        for parent, children in SCOPE_HIERARCHY.items():
            for child in children:
                assert child in CANONICAL_SCOPES, (
                    f"hierarchy child {child} of {parent} not in CANONICAL_SCOPES"
                )


class TestBudget:
    def test_default_tiers_cover_all_roles(self) -> None:
        for role in CANONICAL_AGENT_ROLES:
            assert role in DEFAULT_BUDGET_TIERS, f"no default budget tier for role {role}"

    def test_human_tier_is_zero(self) -> None:
        t = DEFAULT_BUDGET_TIERS["human"]
        assert t.max_tokens == 0
        assert t.max_cost_usd == 0.0

    def test_resolve_no_overrides(self) -> None:
        result = resolve_effective_budget("analyst")
        assert result == DEFAULT_BUDGET_TIERS["analyst"]

    def test_resolve_pl_tighter(self) -> None:
        result = resolve_effective_budget(
            "analyst",
            pl_limits={"max_token": 100_000, "max_rag": 30},
        )
        assert result.max_tokens == 100_000  # PL stricter than default 150k
        assert result.max_rag_calls == 30  # PL stricter than default 50

    def test_resolve_adm_tighter(self) -> None:
        result = resolve_effective_budget(
            "architect",
            adm_limits={"max_cost_usd": 3.0},
        )
        assert result.max_cost_usd == 3.0  # ADM stricter than default 8.0

    def test_resolve_both_takes_min(self) -> None:
        result = resolve_effective_budget(
            "execution",
            pl_limits={"max_token": 180_000},
            adm_limits={"max_tokens": 150_000},
        )
        assert result.max_tokens == 150_000  # min(180k, 150k)

    def test_resolve_unknown_role_uses_defaults(self) -> None:
        result = resolve_effective_budget("unknown_role")
        assert result.role == "unknown_role"
        assert result.max_tokens == 200_000  # BudgetTier defaults
