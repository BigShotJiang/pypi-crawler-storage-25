"""Tests for PolicyClient SDK."""

from __future__ import annotations

import asyncio
import threading
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from platform_commons.policy_cache import AsyncCache, SyncCache, make_cache_key
from platform_commons.policy_client import PolicyClient
from platform_commons.policy_di import PolicySettings, get_policy_client
from platform_commons.policy_models import (
    BudgetConfig,
    PolicyDecisionOutcome,
    WorkerContract,
)


def _mock_response(json_data: dict) -> MagicMock:  # type: ignore[type-arg]
    """Create a mock httpx.Response with sync json() and raise_for_status()."""
    resp = MagicMock(spec=httpx.Response)
    resp.json.return_value = json_data
    resp.raise_for_status.return_value = None
    return resp


# ============================================================================
# CACHE TESTS
# ============================================================================


async def test_async_cache_set_get() -> None:
    """Test AsyncCache set and get."""
    cache = AsyncCache(default_ttl_seconds=60)
    await cache.set("key1", "value1")
    value = await cache.get("key1")
    assert value == "value1"


async def test_async_cache_expiry() -> None:
    """Test AsyncCache TTL expiry."""
    cache = AsyncCache(default_ttl_seconds=1)
    await cache.set("key1", "value1")

    # Should exist immediately
    value = await cache.get("key1")
    assert value == "value1"

    # Should expire after TTL
    await asyncio.sleep(1.1)
    value = await cache.get("key1")
    assert value is None


async def test_async_cache_invalidate_pattern() -> None:
    """Test AsyncCache pattern-based invalidation."""
    cache = AsyncCache(default_ttl_seconds=60)
    await cache.set("get_contract:org-123:executor:research:3", "contract1")
    await cache.set("get_contract:org-123:reviewer:analysis:2", "contract2")
    await cache.set("evaluate:domain1", "decision1")

    # Invalidate contracts for org-123
    deleted = await cache.invalidate("get_contract:org-123:*")
    assert deleted == 2

    # evaluate should still exist
    value = await cache.get("evaluate:domain1")
    assert value == "decision1"


async def test_async_cache_invalidate_all() -> None:
    """Test AsyncCache clear all."""
    cache = AsyncCache(default_ttl_seconds=60)
    await cache.set("key1", "val1")
    await cache.set("key2", "val2")

    deleted = await cache.invalidate()
    assert deleted == 2

    assert await cache.get("key1") is None
    assert await cache.get("key2") is None


async def test_async_cache_delete() -> None:
    """Test AsyncCache delete specific key."""
    cache = AsyncCache(default_ttl_seconds=60)
    await cache.set("key1", "val1")
    await cache.set("key2", "val2")

    await cache.delete("key1")
    assert await cache.get("key1") is None
    assert await cache.get("key2") == "val2"


async def test_async_cache_size() -> None:
    """Test AsyncCache size."""
    cache = AsyncCache(default_ttl_seconds=60)
    assert await cache.size() == 0
    await cache.set("key1", "val1")
    assert await cache.size() == 1
    await cache.set("key2", "val2")
    assert await cache.size() == 2


def test_sync_cache_set_get() -> None:
    """Test SyncCache set and get."""
    cache = SyncCache(default_ttl_seconds=60)
    cache.set("key1", "value1")
    value = cache.get("key1")
    assert value == "value1"


def test_sync_cache_thread_safety() -> None:
    """Test SyncCache is thread-safe."""
    cache = SyncCache(default_ttl_seconds=60)
    results: list[str | None] = []

    def writer(key: str, val: str) -> None:
        cache.set(key, val)

    def reader(key: str) -> None:
        val = cache.get(key)
        results.append(val)

    threads = [threading.Thread(target=writer, args=(f"key{i}", f"val{i}")) for i in range(5)]
    threads.extend([threading.Thread(target=reader, args=(f"key{i}",)) for i in range(5)])

    for t in threads:
        t.start()
    for t in threads:
        t.join()

    # Just verify no crashes (concurrent access is thread-safe)
    assert len(results) >= 0


def test_sync_cache_invalidate_pattern() -> None:
    """Test SyncCache pattern-based invalidation."""
    cache = SyncCache(default_ttl_seconds=60)
    cache.set("get_contract:org-123:executor", "c1")
    cache.set("get_contract:org-123:reviewer", "c2")
    cache.set("evaluate:domain1", "d1")

    deleted = cache.invalidate("get_contract:org-123:*")
    assert deleted == 2
    assert cache.get("evaluate:domain1") == "d1"


def test_make_cache_key() -> None:
    """Test make_cache_key produces deterministic keys."""
    key1 = make_cache_key("org-123", "executor", method="get_contract")
    key2 = make_cache_key("org-123", "executor", method="get_contract")
    assert key1 == key2
    assert key1.startswith("get_contract:")


def test_make_cache_key_different_args() -> None:
    """Test make_cache_key produces different keys for different args."""
    key1 = make_cache_key("org-123", "executor", method="get_contract")
    key2 = make_cache_key("org-456", "reviewer", method="get_contract")
    assert key1 != key2


# ============================================================================
# POLICY CLIENT TESTS
# ============================================================================


async def test_evaluate_cache_miss_and_store() -> None:
    """Test evaluate with cache miss, fetch, and store."""
    client = PolicyClient(base_url="http://test:8001", cache_ttl=60, use_async=True)

    mock_resp = _mock_response(
        {
            "outcome": "allow",
            "rule_id": "rule1",
            "reason": "Action permitted",
            "metadata": {},
            "ttl_seconds": 60,
        }
    )

    with patch.object(client, "_http_post", new_callable=AsyncMock, return_value=mock_resp):
        result = await client.evaluate(
            domain="action_permission",
            rule="rule1",
            context={"action": "execute"},
        )
        assert result.outcome == PolicyDecisionOutcome.ALLOW
        assert result.rule_id == "rule1"

    await client.close()


async def test_evaluate_cache_hit() -> None:
    """Test evaluate uses cache when available."""
    client = PolicyClient(base_url="http://test:8001", cache_ttl=60, use_async=True)

    mock_resp = _mock_response(
        {
            "outcome": "allow",
            "rule_id": "rule1",
            "reason": "OK",
            "metadata": {},
            "ttl_seconds": 60,
        }
    )

    mock_post = AsyncMock(return_value=mock_resp)
    with patch.object(client, "_http_post", mock_post):
        await client.evaluate(
            domain="action_permission",
            rule="rule1",
            context={"action": "execute"},
        )
        assert mock_post.call_count == 1

        # Second call: should use cache
        result = await client.evaluate(
            domain="action_permission",
            rule="rule1",
            context={"action": "execute"},
        )
        assert result.outcome == PolicyDecisionOutcome.ALLOW
        # No additional HTTP call
        assert mock_post.call_count == 1

    await client.close()


async def test_evaluate_batch() -> None:
    """Test evaluate_batch with mixed cache hits and misses."""
    client = PolicyClient(base_url="http://test:8001", cache_ttl=60, use_async=True)

    mock_resp = _mock_response(
        {
            "decisions": [
                {"outcome": "allow", "rule_id": "rule1", "domain": "action", "reason": "OK"},
                {
                    "outcome": "deny",
                    "rule_id": "rule2",
                    "domain": "action",
                    "reason": "Not allowed",
                },
            ]
        }
    )

    with patch.object(client, "_http_post", new_callable=AsyncMock, return_value=mock_resp):
        results = await client.evaluate_batch(
            evaluations=[
                {"domain": "action", "rule": "rule1", "context": {}},
                {"domain": "action", "rule": "rule2", "context": {}},
            ]
        )
        assert len(results) == 2
        assert results[0].outcome == PolicyDecisionOutcome.ALLOW
        assert results[1].outcome == PolicyDecisionOutcome.DENY

    await client.close()


_CONTRACT_RESPONSE_FULL = {
    "org_id": "org-123",
    "member_id": "worker-456",
    "role": "executor",
    "task_type": "research",
    "trust_level": "3",
    "allowed_actions": ["search", "read", "execute"],
    "gated_actions": ["delete"],
    "denied_actions": ["send_external"],
    "budget": {"max_tokens": 100000, "max_cost_usd": 10.0, "period_minutes": 60},
    "review_requirements": {"human_review_threshold": 500, "escalation_tasks": ["delete"]},
    "escalation_triggers": [{"type": "cost_exceeded", "threshold": 8.0}],
    "help_protocol": "escalate_to_supervisor",
    "responsibility": "task_executor",
    "credential_map": [
        {
            "ref": "github_token",
            "source": "member_shared",
            "scope": "public_repos_only",
            "audit_required": True,
        }
    ],
    "version_hash": "v1:abc123",
}


async def test_get_contract_cache_miss_fetch_and_store() -> None:
    """Test get_contract with cache miss, fetch, and store."""
    client = PolicyClient(base_url="http://test:8001", cache_ttl=60, use_async=True)
    mock_resp = _mock_response(_CONTRACT_RESPONSE_FULL)

    with patch.object(client, "_http_get", new_callable=AsyncMock, return_value=mock_resp):
        contract = await client.get_contract(
            org_id="org-123",
            member_id="worker-456",
            role="executor",
            task_type="research",
            trust_level="3",
        )
        assert contract.org_id == "org-123"
        assert contract.member_id == "worker-456"
        assert "search" in contract.allowed_actions
        assert "delete" in contract.gated_actions
        assert contract.can_perform("search") is True
        assert contract.can_perform("send_external") is False
        assert contract.requires_review("delete") is True

    await client.close()


async def test_get_contract_budget_and_triggers() -> None:
    """Test get_contract returns budget and escalation triggers."""
    client = PolicyClient(base_url="http://test:8001", cache_ttl=60, use_async=True)

    mock_resp = _mock_response(
        {
            "org_id": "org-123",
            "member_id": "worker-456",
            "role": "executor",
            "task_type": "research",
            "trust_level": "3",
            "allowed_actions": [],
            "gated_actions": [],
            "denied_actions": [],
            "budget": {"max_tokens": 50000, "max_cost_usd": 5.0, "period_minutes": 30},
            "escalation_triggers": [
                {"type": "cost_exceeded", "threshold": 4.0},
                {"type": "token_limit_exceeded", "threshold": 45000},
            ],
            "version_hash": "v1:xyz",
        }
    )

    with patch.object(client, "_http_get", new_callable=AsyncMock, return_value=mock_resp):
        contract = await client.get_contract(
            org_id="org-123",
            member_id="worker-456",
            role="executor",
            task_type="research",
            trust_level="3",
        )
        assert contract.budget is not None
        assert contract.budget.max_tokens == 50000
        assert contract.budget.max_cost_usd == 5.0
        assert len(contract.escalation_triggers) == 2
        assert contract.escalation_triggers[0].type == "cost_exceeded"

    await client.close()


async def test_get_effective() -> None:
    """Test get_effective returns merged policy chain."""
    client = PolicyClient(base_url="http://test:8001", cache_ttl=60, use_async=True)

    mock_resp = _mock_response(
        {
            "policies": [
                {
                    "id": "policy1",
                    "domain": "action_permission",
                    "name": "Org Default",
                    "version": "1.0",
                    "org_id": "org-123",
                    "rules": {},
                },
                {
                    "id": "policy2",
                    "domain": "action_permission",
                    "name": "Member Specific",
                    "version": "1.0",
                    "member_id": "worker-456",
                    "rules": {},
                },
            ]
        }
    )

    with patch.object(client, "_http_get", new_callable=AsyncMock, return_value=mock_resp):
        policies = await client.get_effective(
            domain="action_permission",
            org_id="org-123",
            member_id="worker-456",
        )
        assert len(policies) == 2
        assert policies[0].name == "Org Default"
        assert policies[1].name == "Member Specific"

    await client.close()


async def test_invalidate_cache_pattern() -> None:
    """Test cache invalidation by pattern."""
    client = PolicyClient(base_url="http://test:8001", cache_ttl=60, use_async=True)
    assert client._async_cache is not None

    await client._async_cache.set("get_contract:org-123:executor:research:3", "c1")
    await client._async_cache.set("get_contract:org-123:reviewer:analysis:2", "c2")
    await client._async_cache.set("evaluate:domain1", "decision1")

    deleted = await client.invalidate_cache("get_contract:org-123:*")
    assert deleted == 2

    value = await client._async_cache.get("evaluate:domain1")
    assert value == "decision1"

    await client.close()


async def test_invalidate_cache_all() -> None:
    """Test cache invalidation (clear all)."""
    client = PolicyClient(base_url="http://test:8001", cache_ttl=60, use_async=True)
    assert client._async_cache is not None

    await client._async_cache.set("key1", "val1")
    await client._async_cache.set("key2", "val2")

    deleted = await client.invalidate_cache()
    assert deleted == 2

    assert await client._async_cache.get("key1") is None
    assert await client._async_cache.get("key2") is None

    await client.close()


async def test_http_error_handling() -> None:
    """Test PolicyClient handles HTTP errors gracefully."""
    client = PolicyClient(base_url="http://test:8001", cache_ttl=60, use_async=True)

    with (
        patch.object(
            client,
            "_http_post",
            new_callable=AsyncMock,
            side_effect=httpx.ConnectError("Connection refused"),
        ),
        pytest.raises(httpx.ConnectError),
    ):
        await client.evaluate(domain="action", rule="rule1", context={})

    await client.close()


def test_worker_contract_helpers() -> None:
    """Test WorkerContract helper methods."""
    contract = WorkerContract(
        org_id="org-123",
        member_id="worker-456",
        role="executor",
        task_type="research",
        trust_level="3",
        allowed_actions=["search", "read", "execute"],
        gated_actions=["delete", "modify"],
        denied_actions=["send_external", "modify_user"],
    )

    assert contract.can_perform("search") is True
    assert contract.can_perform("send_external") is False
    assert contract.requires_review("delete") is True
    assert contract.requires_review("search") is False

    denied = contract.all_denied_actions
    assert "delete" in denied
    assert "send_external" in denied
    assert "search" not in denied


def test_worker_contract_budget() -> None:
    """Test WorkerContract with budget config."""
    contract = WorkerContract(
        org_id="org-123",
        member_id="worker-456",
        role="executor",
        task_type="research",
        trust_level="3",
        budget=BudgetConfig(max_tokens=100000, max_cost_usd=10.0, period_minutes=60),
    )
    assert contract.budget is not None
    assert contract.budget.max_tokens == 100000
    assert contract.budget.max_cost_usd == 10.0


def test_policy_decision_outcome_values() -> None:
    """Test PolicyDecisionOutcome enum values."""
    assert PolicyDecisionOutcome.ALLOW.value == "allow"
    assert PolicyDecisionOutcome.DENY.value == "deny"
    assert PolicyDecisionOutcome.REQUIRE_REVIEW.value == "require_review"
    assert PolicyDecisionOutcome.ESCALATE.value == "escalate"


async def test_policy_client_context_manager() -> None:
    """Test PolicyClient as async context manager."""
    async with PolicyClient(
        base_url="http://test:8001",
        cache_ttl=60,
        use_async=True,
    ) as client:
        assert client is not None
        assert client.base_url == "http://test:8001"


def test_policy_di_factory() -> None:
    """Test DI factory creates PolicyClient."""
    client = get_policy_client()
    assert isinstance(client, PolicyClient)
    assert client.base_url == "http://localhost:8001"

    settings = PolicySettings.from_env()
    assert settings.policy_registry_url == "http://localhost:8001"
    assert settings.policy_client_cache_ttl == 60
