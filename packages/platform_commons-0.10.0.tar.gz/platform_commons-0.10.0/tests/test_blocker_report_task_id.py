"""Tests for BlockerReport.task_id field (ROAD-M17-02 F1 B-prime-2).

Verifies that:
1. BlockerReport construction succeeds with task_id.
2. Constructing without task_id raises TypeError (field is required).
3. BlockerReport satisfies the BlockerReportLike Protocol structurally.
"""

from __future__ import annotations

from uuid import UUID

import pytest

from platform_commons.blocker.protocols import BlockerReportLike
from platform_commons.blocker.types import (
    BlockerOption,
    BlockerReport,
    BlockerType,
)


def _sample_report(*, task_id: str = "task_001") -> BlockerReport:
    return BlockerReport(
        type=BlockerType.CLARIFICATION_REQUIRED,
        summary="summary",
        details_prose="details",
        typed_fields={"question_code": "Q1", "unknown_fact": "fact"},
        options=[BlockerOption(id="A", title="A", impact="low", risk="low")],
        recommended_option="A",
        confidence=0.8,
        required_actor="oa",
        workflow_id=UUID("00000000-0000-0000-0000-000000000001"),
        step_id="step_1",
        task_id=task_id,
        worker_id="worker_1",
    )


def test_blocker_report_construction_with_task_id() -> None:
    """BlockerReport accepts task_id as a required field."""
    report = _sample_report(task_id="task_abc_123")
    assert report.task_id == "task_abc_123"
    assert report.step_id == "step_1"
    assert report.worker_id == "worker_1"


def test_blocker_report_without_task_id_raises_type_error() -> None:
    """task_id is non-optional; omitting it must raise TypeError."""
    with pytest.raises(TypeError, match="task_id"):
        BlockerReport(  # type: ignore[call-arg]
            type=BlockerType.CLARIFICATION_REQUIRED,
            summary="s",
            details_prose="d",
            typed_fields={"question_code": "Q1", "unknown_fact": "f"},
            options=[BlockerOption(id="A", title="A", impact="l", risk="l")],
            recommended_option="A",
            confidence=0.5,
            required_actor="oa",
            workflow_id=UUID("00000000-0000-0000-0000-000000000001"),
            step_id="step_1",
            worker_id="worker_1",
        )


def test_blocker_report_satisfies_blocker_report_like_protocol() -> None:
    """BlockerReport structurally satisfies BlockerReportLike."""
    report = _sample_report()
    # Structural typing: assigning to a Protocol-typed variable.
    # If BlockerReport does not have all Protocol fields, mypy catches it.
    like: BlockerReportLike = report  # type: ignore[assignment]
    assert like.summary == "summary"
    assert like.task_id == "task_001"
