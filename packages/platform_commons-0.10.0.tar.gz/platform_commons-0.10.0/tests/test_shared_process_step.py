"""Tests for SharedProcessStep (PSYNC-03A)."""

import pytest

from platform_commons.canonical.process_step import SharedProcessStep, StepAnnotationDTO


def test_minimal_step():
    step = SharedProcessStep(step_id="s1")
    assert step.step_id == "s1"
    assert step.annotation is None
    assert step.activation == "auto"


def test_full_step_with_annotation():
    step = SharedProcessStep(
        step_id="s1",
        name="Analysis",
        step_type="analysis",
        annotation=StepAnnotationDTO(
            agent_role="analyst",
            capability="analyze.v1",
            timeout_seconds=600,
        ),
        worker_profile="claude",
    )
    assert step.annotation is not None
    assert step.annotation.agent_role == "analyst"
    assert step.annotation.timeout_seconds == 600


def test_invalid_role_rejected():
    with pytest.raises(ValueError, match="not in CANONICAL_AGENT_ROLES"):
        StepAnnotationDTO(agent_role="superadmin")


def test_none_role_accepted():
    dto = StepAnnotationDTO(agent_role=None)
    assert dto.agent_role is None


def test_annotation_defaults():
    dto = StepAnnotationDTO()
    assert dto.agent_role is None
    assert dto.capability is None
    assert dto.timeout_seconds is None
    assert dto.human_review_required is False
    assert dto.escalation_channel is None


def test_step_config_defaults():
    step = SharedProcessStep(step_id="s1")
    assert step.config == {}
    assert step.depends_on == []
    assert step.required_inputs == []
    assert step.output_artifacts == []
    assert step.on_failure is None
    assert step.on_complete is None


def test_step_from_dict():
    """SharedProcessStep can parse a dict (simulating PL API response)."""
    data = {
        "step_id": "analysis",
        "name": "Requirements Analysis",
        "step_type": "analysis",
        "depends_on": ["intake"],
        "config": {"phase": "analysis"},
        "annotation": {
            "agent_role": "analyst",
            "capability": "analyze.v1",
        },
    }
    step = SharedProcessStep.model_validate(data)
    assert step.step_id == "analysis"
    assert step.annotation is not None
    assert step.annotation.agent_role == "analyst"


def test_canonical_import():
    """SharedProcessStep is importable from canonical package."""
    from platform_commons import canonical  # noqa: PLC0415

    assert canonical.SharedProcessStep is SharedProcessStep
    assert canonical.StepAnnotationDTO is StepAnnotationDTO
