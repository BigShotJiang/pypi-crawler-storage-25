# Changelog

All notable changes to `platform_commons` are documented in this file.

The project uses hatch-vcs for versioning: the authoritative version
string is read from the most recent ``v*`` git tag on the main branch.
CHANGELOG entries are grouped by the tag that carries them.

## 0.9.0 (unreleased, tagged post-merge)

### Added

- `BlockerReport.task_id: str` field (ROAD-M17-02 F1 B-prime-2): the
  ADM-side `tasks.task_id` of the task instance a blocker applies to.
  Non-optional, globally unique. Required by ADM `BlockerService` to
  key `workflow_steps` rows on `task_id` (migration 014). Mirrored on
  `BlockerReportLike` Protocol.

## 0.8.0 -- 2026-04-11

### Added

- `platform_commons.blocker` subpackage (ROAD-M17-03 phase 2): shared
  types for the M17-01 blocker contract. Consolidates the type
  definitions that were previously duplicated across the ADM, Operator
  Agent, and WORKERS consumer repos into a single sink that all three
  can import from.
  - `platform_commons.blocker.types` — `BlockerReport`, `BlockerOption`,
    `BlockerOutcome`, `BlockerResolution`, `RoutingDecision`,
    `DecisionCard`, `DecisionCardOption`, `DecisionCardLike`,
    `BlockerType`, `BLOCKER_TYPED_FIELDS_SCHEMA`.
  - `platform_commons.blocker.errors` — `BlockerError` base class plus
    11 subclasses (`BlockerValidationError`, `MissingRequiredTypedField`,
    `UnexpectedTypedField`, `BlockerOptionsEmpty`,
    `RecommendedOptionInvalid`, `BlockerSummaryTooLong`,
    `BlockerConfidenceOutOfRange`, `BlockerAlreadyResolved`,
    `CheckpointSerializationError`, `CheckpointTooLargeError`,
    `WorkerTerminatedError`). `WorkerTerminatedError` is the unified
    definition replacing the two historical variants (ADM-side
    inherited from `BlockerError`; WORKERS-side inherited from
    `RuntimeError`). The unified version inherits from `BlockerError`
    alone.
  - `platform_commons.blocker.protocols` — `BlockerReportLike`,
    `BlockerOptionLike`, `BlockerResolutionLike`, `CheckpointLike`.
  - `platform_commons.blocker.common` — `JSONValue` recursive type
    alias for free-form JSON-like payload surfaces.
- `platform_commons/py.typed` marker (PEP 561) so downstream mypy
  strict mode can follow cross-package type imports.
- CI lint-stage job `blocker-type-sink-assertion` that fails the
  build if any consumer-repo import
  (`from adm` / `import adm` / `from operator_agent` / `import
  operator_agent` / `from workers` / `import workers`) leaks into
  `platform_commons/blocker/`. Hard Rule 2 enforcement per the phase 2
  prompt.

### Migration notes

- Consumer repos (ADM, OA, WORKERS) bump their `platform-commons` pin
  to `>=0.8.0` in subsequent ROAD-M17-03 phase 2 commits (F2 and F3).
  Until those commits land, consumers should treat v0.8.0 as a new
  availability point — no existing consumer is broken by the additive
  subpackage.
- Python compatibility is unchanged: `platform_commons` still targets
  `>=3.11`. The `JSONValue` alias uses `TypeAlias` (PEP 613) with a
  string forward reference for its recursive self-mention so that it
  imports cleanly on 3.11 as well as 3.12+.
