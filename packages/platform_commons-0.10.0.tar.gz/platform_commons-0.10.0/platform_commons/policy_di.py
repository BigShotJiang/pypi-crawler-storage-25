"""Dependency injection factories for PolicyClient."""

from __future__ import annotations

import os
from functools import lru_cache

from .policy_client import PolicyClient


class PolicySettings:
    """PolicyClient application settings."""

    def __init__(self) -> None:
        self.policy_registry_url: str = "http://localhost:8001"
        self.policy_client_cache_ttl: int = 60
        self.policy_client_timeout: float = 10.0

    @classmethod
    def from_env(cls) -> PolicySettings:
        """Load from environment variables."""
        settings = cls()
        settings.policy_registry_url = os.getenv(
            "POLICY_REGISTRY_URL",
            "http://localhost:8001",
        )
        settings.policy_client_cache_ttl = int(os.getenv("POLICY_CLIENT_CACHE_TTL", "60"))
        settings.policy_client_timeout = float(os.getenv("POLICY_CLIENT_TIMEOUT", "10.0"))
        return settings


@lru_cache(maxsize=1)
def get_policy_settings() -> PolicySettings:
    """Get application settings (cached singleton)."""
    return PolicySettings.from_env()


def get_policy_client() -> PolicyClient:
    """Factory function for FastAPI Depends.

    Usage in FastAPI app:
        @app.get("/some-endpoint")
        async def my_endpoint(client: PolicyClient = Depends(get_policy_client)):
            contract = await client.get_contract(...)
            ...

    Returns:
        PolicyClient configured with service URL and cache TTL
    """
    settings = get_policy_settings()
    return PolicyClient(
        base_url=settings.policy_registry_url,
        cache_ttl=settings.policy_client_cache_ttl,
        timeout=settings.policy_client_timeout,
        use_async=True,
    )


__all__ = ["PolicySettings", "get_policy_client", "get_policy_settings"]
