"""Platform Commons — shared libraries for AI Development Platform."""

from .auth_middleware import AuthContext, DualAuthMiddleware
from .jwt_middleware import JWKSClient, JWTValidator, require_scopes
from .jwt_models import JWTClaims
from .metrics_middleware import add_metrics
from .policy_client import PolicyClient
from .policy_di import PolicySettings, get_policy_client, get_policy_settings
from .policy_models import (
    BudgetConfig,
    CredentialMapEntry,
    EscalationTrigger,
    Policy,
    PolicyDecision,
    PolicyDecisionOutcome,
    ReviewRequirement,
    WorkerContract,
)
from .scope_hierarchy import SCOPE_HIERARCHY, expand_scopes
from .scope_middleware import CapabilityScopeMiddleware, ScopeRegistry

__all__ = [
    "SCOPE_HIERARCHY",
    "AuthContext",
    "BudgetConfig",
    "CapabilityScopeMiddleware",
    "CredentialMapEntry",
    "DualAuthMiddleware",
    "EscalationTrigger",
    "JWKSClient",
    "JWTClaims",
    "JWTValidator",
    "Policy",
    "PolicyClient",
    "PolicyDecision",
    "PolicyDecisionOutcome",
    "PolicySettings",
    "ReviewRequirement",
    "ScopeRegistry",
    "WorkerContract",
    "add_metrics",
    "expand_scopes",
    "get_policy_client",
    "get_policy_settings",
    "require_scopes",
]
