"""Budget tier definitions and monotonic tightening resolver.

Rule: when PL CapabilityProfile and ADM CostGovernance policy both
define a limit, the STRICTER (lower) value wins.

  effective = min(pl_limit, adm_limit) when both defined
  effective = whichever is defined when only one exists
  effective = default when neither is defined
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class BudgetTier:
    """Budget limits for a single role."""

    role: str
    max_tokens: int = 200_000
    max_cost_usd: float = 10.0
    max_rag_calls: int = 50
    max_pl_calls: int = 20


# Default tiers aligned with PL seed profiles (capability_profiles.py)
DEFAULT_BUDGET_TIERS: dict[str, BudgetTier] = {
    "analyst": BudgetTier(
        role="analyst", max_tokens=150_000, max_cost_usd=5.0, max_rag_calls=50, max_pl_calls=20
    ),
    "architect": BudgetTier(
        role="architect", max_tokens=200_000, max_cost_usd=8.0, max_rag_calls=30, max_pl_calls=50
    ),
    "documentation": BudgetTier(
        role="documentation",
        max_tokens=100_000,
        max_cost_usd=3.0,
        max_rag_calls=30,
        max_pl_calls=10,
    ),
    "validation": BudgetTier(
        role="validation", max_tokens=120_000, max_cost_usd=4.0, max_rag_calls=40, max_pl_calls=15
    ),
    "execution": BudgetTier(
        role="execution", max_tokens=200_000, max_cost_usd=10.0, max_rag_calls=0, max_pl_calls=0
    ),
    "review": BudgetTier(
        role="review", max_tokens=100_000, max_cost_usd=4.0, max_rag_calls=40, max_pl_calls=0
    ),
    "conversation": BudgetTier(
        role="conversation", max_tokens=50_000, max_cost_usd=2.0, max_rag_calls=20, max_pl_calls=0
    ),
    "human": BudgetTier(
        role="human", max_tokens=0, max_cost_usd=0.0, max_rag_calls=0, max_pl_calls=0
    ),
}


def resolve_effective_budget(
    role: str,
    *,
    pl_limits: dict[str, int | float] | None = None,
    adm_limits: dict[str, int | float] | None = None,
) -> BudgetTier:
    """Resolve effective budget via monotonic tightening.

    Args:
        role: Agent role name (must be in CANONICAL_AGENT_ROLES).
        pl_limits: PL CapabilityProfile.budget_limits dict (optional).
                   Keys: "max_rag", "max_pl", "max_token".
        adm_limits: ADM CostGovernance policy limits (optional).
                    Keys: "max_tokens", "max_cost_usd", "max_rag_calls", "max_pl_calls".

    Returns:
        BudgetTier with the STRICTER value for each field.
    """
    default = DEFAULT_BUDGET_TIERS.get(role, BudgetTier(role=role))
    pl = pl_limits or {}
    adm = adm_limits or {}

    def _min_defined(default_val: int | float, *candidates: int | float | None) -> int | float:
        """Return minimum of default and all non-None candidates."""
        values = [default_val] + [c for c in candidates if c is not None]
        return min(values)

    return BudgetTier(
        role=role,
        max_tokens=int(
            _min_defined(default.max_tokens, pl.get("max_token"), adm.get("max_tokens"))
        ),
        max_cost_usd=float(_min_defined(default.max_cost_usd, adm.get("max_cost_usd"))),
        max_rag_calls=int(
            _min_defined(default.max_rag_calls, pl.get("max_rag"), adm.get("max_rag_calls"))
        ),
        max_pl_calls=int(
            _min_defined(default.max_pl_calls, pl.get("max_pl"), adm.get("max_pl_calls"))
        ),
    )
