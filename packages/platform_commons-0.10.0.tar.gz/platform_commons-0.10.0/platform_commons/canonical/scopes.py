"""Canonical scope definitions.

Unified namespace covering BOTH service-level scopes (SDK-style)
and worker-level scopes (ADM-style). All scopes use dot-notation.

Two categories:
  SERVICE_SCOPES — inter-service API access (rag.*, pl.*, sg.*, adm.*)
  WORKER_SCOPES — worker execution capabilities (repo.*, git.*, kb.*)

CANONICAL_SCOPES = SERVICE_SCOPES | WORKER_SCOPES
"""

from __future__ import annotations

# --- Service-level scopes (existing SDK format: {service}.{resource}.{action}) ---
SERVICE_SCOPES: frozenset[str] = frozenset(
    {
        # RAG Knowledge
        "rag.decisions.read",
        "rag.decisions.write",
        "rag.artifacts.read",
        "rag.artifacts.write",
        # Process Library
        "pl.processes.read",
        "pl.versions.read",
        "pl.versions.write",
        "pl.versions.promote",
        # Secrets Gateway
        "sg.access.check",
        "sg.policies.validate",
        # ADM
        "adm.workflows.read",
        "adm.tasks.read",
    }
)

# --- Worker-level scopes (ADM format, now first-class) ---
WORKER_SCOPES: frozenset[str] = frozenset(
    {
        # Repository access
        "repo.read",
        "repo.write",
        # Git operations
        "git.branch",
        "git.commit",
        "git.push",
        # Knowledge base
        "kb.read",
        "kb.write",
        # Internal APIs
        "internal_api.read",
        "internal_api.write",
    }
)

# --- Combined canonical set ---
CANONICAL_SCOPES: frozenset[str] = SERVICE_SCOPES | WORKER_SCOPES

# --- Scope hierarchy (parent implies children) ---
SCOPE_HIERARCHY: dict[str, list[str]] = {
    # Service scopes
    "rag.decisions.write": ["rag.decisions.read"],
    "rag.artifacts.write": ["rag.artifacts.read"],
    "pl.versions.write": ["pl.versions.read"],
    "pl.versions.promote": ["pl.versions.write", "pl.versions.read"],
    # Worker scopes
    "repo.write": ["repo.read"],
    "kb.write": ["kb.read"],
    "git.push": ["git.commit", "git.branch"],
    "git.commit": ["git.branch"],
    "internal_api.write": ["internal_api.read"],
}


def is_valid_scope(scope: str) -> bool:
    """Check if a scope is in the canonical set."""
    return scope in CANONICAL_SCOPES
