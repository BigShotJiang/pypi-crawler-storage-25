"""Canonical entity registry — single source of truth for roles, scopes, and budget tiers.

Every consumer (SDK, PL, ADM) MUST import from this package.
DO NOT define roles, scopes, or budget tiers elsewhere.

Created: PSYNC-01 (GAP-06, GAP-12, GAP-13)
"""

from platform_commons.canonical.budget import (
    DEFAULT_BUDGET_TIERS,
    BudgetTier,
    resolve_effective_budget,
)
from platform_commons.canonical.process_step import SharedProcessStep, StepAnnotationDTO
from platform_commons.canonical.roles import CANONICAL_AGENT_ROLES, is_valid_role
from platform_commons.canonical.scopes import (
    CANONICAL_SCOPES,
    SCOPE_HIERARCHY,
    SERVICE_SCOPES,
    WORKER_SCOPES,
    is_valid_scope,
)

__all__ = [
    "CANONICAL_AGENT_ROLES",
    "CANONICAL_SCOPES",
    "DEFAULT_BUDGET_TIERS",
    "SCOPE_HIERARCHY",
    "SERVICE_SCOPES",
    "WORKER_SCOPES",
    "BudgetTier",
    "SharedProcessStep",
    "StepAnnotationDTO",
    "is_valid_role",
    "is_valid_scope",
    "resolve_effective_budget",
]
