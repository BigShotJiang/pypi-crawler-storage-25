"""Shared ProcessStep contract between Process Library and ADM.

PL serializes process steps into this format.
ADM deserializes and validates against this format.
This eliminates the untyped JSON bridge (GAP-01).

Created: PSYNC-03A
"""

from __future__ import annotations

from pydantic import BaseModel, Field, field_validator

from platform_commons.canonical.roles import CANONICAL_AGENT_ROLES


class StepAnnotationDTO(BaseModel):
    """Flat extract of PL StepAnnotation — the fields ADM actually needs.

    PL StepAnnotation has complex validators (capability_invariant, approval_gate_requirements).
    ADM needs only the data, not the PL-specific validation.
    """

    agent_role: str | None = None
    capability: str | None = None
    timeout_seconds: int | None = None
    human_review_required: bool = False
    escalation_channel: str | None = None

    @field_validator("agent_role")
    @classmethod
    def _validate_role(cls, v: str | None) -> str | None:
        if v is not None and v not in CANONICAL_AGENT_ROLES:
            raise ValueError(f"agent_role '{v}' not in CANONICAL_AGENT_ROLES")
        return v


class SharedProcessStep(BaseModel):
    """Cross-component ProcessStep contract.

    PL publishes this via API. ADM consumes and validates against it.
    All fields have defaults — partial data is valid (bootstrap compatibility).
    """

    step_id: str
    name: str = ""
    step_type: str = "automated"
    depends_on: list[str] = Field(default_factory=list)
    config: dict = Field(default_factory=dict)  # type: ignore[type-arg]
    worker_profile: str | None = None
    output_schema: dict | None = None  # type: ignore[type-arg]

    # Extracted annotation (GAP-03)
    annotation: StepAnnotationDTO | None = None

    # Config convenience extractions
    required_inputs: list[str] = Field(default_factory=list)
    output_artifacts: list[str] = Field(default_factory=list)
    on_failure: str | None = None
    on_complete: str | None = None
    activation: str = "auto"
