"""Canonical agent roles.

Source of truth for ALL agent role identifiers across the platform.
SDK, PL, and ADM MUST import from here. No local definitions.

Roles:
  - analyst:       Requirements analysis, research, information gathering
  - architect:     System design, technical decisions, architecture
  - documentation: Technical writing, documentation generation
  - validation:    Testing, QA, verification
  - execution:     Code implementation, task execution
  - review:        Code review, peer review, approval
  - conversation:  User interaction, chat, clarification
  - human:         Human-in-the-loop governance gates (approval, escalation)
"""

from __future__ import annotations

CANONICAL_AGENT_ROLES: frozenset[str] = frozenset(
    {
        "analyst",
        "architect",
        "documentation",
        "validation",
        "execution",
        "review",
        "conversation",
        "human",
    }
)


def is_valid_role(role: str) -> bool:
    """Check if a role is in the canonical set."""
    return role in CANONICAL_AGENT_ROLES
