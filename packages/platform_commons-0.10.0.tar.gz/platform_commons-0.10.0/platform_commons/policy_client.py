"""PolicyClient SDK for interacting with Policy Registry service."""

from __future__ import annotations

import logging
from typing import Any, cast
from urllib.parse import urljoin

import httpx

from .policy_cache import AsyncCache, SyncCache, make_cache_key
from .policy_models import (
    BudgetConfig,
    CredentialMapEntry,
    EscalationTrigger,
    Policy,
    PolicyDecision,
    PolicyDecisionOutcome,
    ReviewRequirement,
    WorkerContract,
)

logger = logging.getLogger(__name__)


class PolicyClient:
    """SDK for Policy Registry service interactions.

    Provides caching, batching, and type-safe access to policy data.
    Use dependency injection (via FastAPI Depends) in applications.

    Example:
        client = PolicyClient(base_url="http://localhost:8001", cache_ttl=60)
        contract = await client.get_contract(
            org_id="org-123",
            member_id="worker-456",
            role="executor",
            task_type="research",
            trust_level="3"
        )
        if contract.can_perform("execute"):
            # safe to proceed
            pass
    """

    def __init__(
        self,
        base_url: str,
        cache_ttl: int = 60,
        timeout: float = 10.0,
        use_async: bool = True,
    ) -> None:
        """Initialize PolicyClient.

        Args:
            base_url: Policy Registry service base URL (e.g., "http://localhost:8001")
            cache_ttl: Cache TTL in seconds (default 60)
            timeout: HTTP request timeout in seconds (default 10)
            use_async: Use AsyncCache if True, SyncCache if False (default True)
        """
        self.base_url = base_url.rstrip("/")
        self.cache_ttl = cache_ttl
        self.timeout = timeout
        self._is_async = use_async

        # Store typed references for mypy
        self._async_cache: AsyncCache | None = None
        self._sync_cache: SyncCache | None = None
        self._async_client: httpx.AsyncClient | None = None
        self._sync_client: httpx.Client | None = None

        if use_async:
            self._async_cache = AsyncCache(default_ttl_seconds=cache_ttl)
            self._async_client = httpx.AsyncClient()
        else:
            self._sync_cache = SyncCache(default_ttl_seconds=cache_ttl)
            self._sync_client = httpx.Client()

    # Expose cache for direct access in tests
    @property
    def cache(self) -> AsyncCache | SyncCache:
        """Return the active cache instance."""
        if self._async_cache is not None:
            return self._async_cache
        assert self._sync_cache is not None
        return self._sync_cache

    @property
    def client(self) -> httpx.AsyncClient | httpx.Client:
        """Return the active HTTP client."""
        if self._async_client is not None:
            return self._async_client
        assert self._sync_client is not None
        return self._sync_client

    async def _cache_get(self, key: str) -> Any:
        """Get value from cache (async or sync)."""
        if self._async_cache is not None:
            return await self._async_cache.get(key)
        return cast(SyncCache, self._sync_cache).get(key)

    async def _cache_set(self, key: str, value: Any) -> None:
        """Set value in cache (async or sync)."""
        if self._async_cache is not None:
            await self._async_cache.set(key, value)
        else:
            cast(SyncCache, self._sync_cache).set(key, value)

    async def _cache_invalidate(self, pattern: str | None = None) -> int:
        """Invalidate cache entries (async or sync)."""
        if self._async_cache is not None:
            return await self._async_cache.invalidate(pattern)
        return cast(SyncCache, self._sync_cache).invalidate(pattern)

    async def _http_post(self, url: str, json: Any) -> httpx.Response:
        """Send HTTP POST (async or sync)."""
        if self._async_client is not None:
            return await self._async_client.post(url, json=json, timeout=self.timeout)
        return cast(httpx.Client, self._sync_client).post(url, json=json, timeout=self.timeout)

    async def _http_get(self, url: str, params: dict[str, str]) -> httpx.Response:
        """Send HTTP GET (async or sync)."""
        if self._async_client is not None:
            return await self._async_client.get(url, params=params, timeout=self.timeout)
        return cast(httpx.Client, self._sync_client).get(url, params=params, timeout=self.timeout)

    async def evaluate(
        self,
        domain: str,
        rule: str,
        context: dict[str, Any],
    ) -> PolicyDecision:
        """Evaluate a single policy.

        Args:
            domain: Policy domain (e.g., "action_permission")
            rule: Rule identifier (e.g., "allow_execute")
            context: Evaluation context (e.g., {"action": "execute", "role": "executor"})

        Returns:
            PolicyDecision with outcome and metadata

        Raises:
            httpx.RequestError: If Policy Registry service is unavailable
        """
        cache_key = make_cache_key(domain, rule, context, method="evaluate")
        cached = await self._cache_get(cache_key)
        if cached is not None:
            logger.debug("Cache hit: evaluate(%s, %s)", domain, rule)
            return cached  # type: ignore[no-any-return]

        try:
            url = urljoin(self.base_url + "/", "policies/evaluate")
            payload = {"domain": domain, "rule": rule, "context": context}
            response = await self._http_post(url, payload)
            response.raise_for_status()
            data: dict[str, Any] = response.json()
        except httpx.RequestError as e:
            logger.error("PolicyClient.evaluate failed: %s", e)
            raise

        decision = PolicyDecision(
            outcome=PolicyDecisionOutcome(data["outcome"]),
            rule_id=data.get("rule_id", rule),
            domain=domain,
            reason=data.get("reason", ""),
            metadata=data.get("metadata", {}),
            ttl_seconds=data.get("ttl_seconds", self.cache_ttl),
        )

        await self._cache_set(cache_key, decision)
        logger.info("Evaluated policy: %s/%s -> %s", domain, rule, decision.outcome.value)
        return decision

    async def evaluate_batch(
        self,
        evaluations: list[dict[str, Any]],
    ) -> list[PolicyDecision]:
        """Evaluate multiple policies in one request.

        Args:
            evaluations: List of dicts with keys: domain, rule, context

        Returns:
            List of PolicyDecision objects in same order

        Raises:
            httpx.RequestError: If Policy Registry service is unavailable
        """
        cached_results, uncached_evals, uncached_indices = await self._partition_cached_batch(
            evaluations
        )

        if not uncached_evals:
            return self._merge_batch_results(len(evaluations), cached_results, [], [])

        data = await self._fetch_batch(uncached_evals)
        decisions_from_service = await self._parse_and_cache_batch(data, uncached_evals)

        logger.info("Evaluated batch: %d policies", len(evaluations))
        return self._merge_batch_results(
            len(evaluations), cached_results, uncached_indices, decisions_from_service
        )

    async def _partition_cached_batch(
        self,
        evaluations: list[dict[str, Any]],
    ) -> tuple[list[tuple[int, PolicyDecision]], list[dict[str, Any]], list[int]]:
        """Partition evaluations into cached hits and uncached misses."""
        cached_results: list[tuple[int, PolicyDecision]] = []
        uncached_evals: list[dict[str, Any]] = []
        uncached_indices: list[int] = []

        for i, eval_item in enumerate(evaluations):
            cache_key = make_cache_key(
                eval_item["domain"],
                eval_item["rule"],
                eval_item.get("context", {}),
                method="evaluate",
            )
            cached = await self._cache_get(cache_key)
            if cached:
                cached_results.append((i, cached))
            else:
                uncached_evals.append(eval_item)
                uncached_indices.append(i)

        return cached_results, uncached_evals, uncached_indices

    async def _fetch_batch(self, uncached_evals: list[dict[str, Any]]) -> dict[str, Any]:
        """Fetch batch evaluations from service."""
        try:
            url = urljoin(self.base_url + "/", "policies/evaluate/batch")
            response = await self._http_post(url, {"evaluations": uncached_evals})
            response.raise_for_status()
            return response.json()  # type: ignore[no-any-return]
        except httpx.RequestError as e:
            logger.error("PolicyClient.evaluate_batch failed: %s", e)
            raise

    async def _parse_and_cache_batch(
        self,
        data: dict[str, Any],
        uncached_evals: list[dict[str, Any]],
    ) -> list[PolicyDecision]:
        """Parse batch response and cache decisions."""
        decisions: list[PolicyDecision] = []
        for idx, item in enumerate(data.get("decisions", [])):
            decision = PolicyDecision(
                outcome=PolicyDecisionOutcome(item["outcome"]),
                rule_id=item.get("rule_id", ""),
                domain=item.get("domain", ""),
                reason=item.get("reason", ""),
                metadata=item.get("metadata", {}),
                ttl_seconds=item.get("ttl_seconds", self.cache_ttl),
            )
            decisions.append(decision)

            eval_item = uncached_evals[idx]
            cache_key = make_cache_key(
                eval_item["domain"],
                eval_item["rule"],
                eval_item.get("context", {}),
                method="evaluate",
            )
            await self._cache_set(cache_key, decision)

        return decisions

    @staticmethod
    def _merge_batch_results(
        total: int,
        cached_results: list[tuple[int, PolicyDecision]],
        uncached_indices: list[int],
        decisions_from_service: list[PolicyDecision],
    ) -> list[PolicyDecision]:
        """Merge cached and freshly-fetched batch results."""
        result_list: list[PolicyDecision | None] = [None] * total
        for i, decision in cached_results:
            result_list[i] = decision
        for i, decision in zip(uncached_indices, decisions_from_service, strict=True):
            result_list[i] = decision
        return [r for r in result_list if r is not None]

    async def get_contract(
        self,
        org_id: str,
        member_id: str,
        role: str,
        task_type: str,
        trust_level: str,
    ) -> WorkerContract:
        """Get compiled policy contract for a worker (O(1) cached lookup).

        **This is the PRIMARY method used by ADM for contract lookup.**

        Returns the effective policy contract that describes:
        - Allowed actions
        - Gated actions (require review)
        - Denied actions
        - Budget constraints
        - Escalation triggers

        Cache key: contract:{org_id}:{role}:{task_type}:{trust_level}

        Args:
            org_id: Organization ID
            member_id: Worker member ID
            role: Role (e.g., "executor", "reviewer")
            task_type: Task type (e.g., "research", "development")
            trust_level: Trust level (e.g., "1", "2", "3")

        Returns:
            WorkerContract with all applicable restrictions

        Raises:
            httpx.RequestError: If Policy Registry service is unavailable
            httpx.HTTPStatusError: If contract not found (404)
        """
        cache_key = make_cache_key(org_id, role, task_type, trust_level, method="get_contract")
        cached = await self._cache_get(cache_key)
        if cached is not None:
            logger.debug(
                "Cache hit: get_contract(%s, %s, %s, %s)",
                org_id,
                role,
                task_type,
                trust_level,
            )
            return cached  # type: ignore[no-any-return]

        try:
            url = urljoin(self.base_url + "/", "policies/worker-contract")
            params = {
                "org_id": org_id,
                "member_id": member_id,
                "role": role,
                "task_type": task_type,
                "trust_level": trust_level,
            }
            response = await self._http_get(url, params)
            response.raise_for_status()
            data: dict[str, Any] = response.json()
        except httpx.RequestError as e:
            logger.error(
                "PolicyClient.get_contract failed (%s, %s, %s): %s",
                org_id,
                role,
                task_type,
                e,
            )
            raise

        contract = self._parse_contract(data, member_id)
        await self._cache_set(cache_key, contract)
        logger.info("Retrieved contract: %s/%s/%s/%s", org_id, role, task_type, trust_level)
        return contract

    async def get_effective(
        self,
        domain: str,
        org_id: str,
        member_id: str | None = None,
    ) -> list[Policy]:
        """Get merged policy chain (org + member + defaults).

        Returns policies in order of precedence (member > org > domain defaults).

        Args:
            domain: Policy domain
            org_id: Organization ID
            member_id: Optional member ID for member-specific policies

        Returns:
            List of Policy objects (merged chain)

        Raises:
            httpx.RequestError: If Policy Registry service is unavailable
        """
        cache_key = make_cache_key(domain, org_id, member_id or "", method="get_effective")
        cached = await self._cache_get(cache_key)
        if cached is not None:
            logger.debug("Cache hit: get_effective(%s, %s)", domain, org_id)
            return cached  # type: ignore[no-any-return]

        try:
            url = urljoin(self.base_url + "/", "policies/effective")
            params: dict[str, str] = {"domain": domain, "org_id": org_id}
            if member_id:
                params["member_id"] = member_id
            response = await self._http_get(url, params)
            response.raise_for_status()
            data: dict[str, Any] = response.json()
        except httpx.RequestError as e:
            logger.error("PolicyClient.get_effective failed: %s", e)
            raise

        policies = [
            Policy(
                id=p["id"],
                domain=p["domain"],
                name=p["name"],
                version=p["version"],
                org_id=p.get("org_id"),
                member_id=p.get("member_id"),
                rules=p.get("rules", {}),
                metadata=p.get("metadata", {}),
            )
            for p in data.get("policies", [])
        ]

        await self._cache_set(cache_key, policies)
        logger.info(
            "Retrieved effective policies: %s/%s -> %d policies",
            domain,
            org_id,
            len(policies),
        )
        return policies

    async def invalidate_cache(self, pattern: str | None = None) -> int:
        """Invalidate cache entries by pattern.

        Called when policies change (via Policy Registry event system).

        Args:
            pattern: Glob pattern (e.g., "get_contract:org-123:*") or None to clear all

        Returns:
            Number of entries invalidated

        Example:
            # Invalidate all contracts for org-123
            await client.invalidate_cache("get_contract:org-123:*")

            # Invalidate all cache
            await client.invalidate_cache()
        """
        count = await self._cache_invalidate(pattern)
        logger.info("Invalidated cache: pattern=%s, entries_deleted=%d", pattern, count)
        return count

    async def close(self) -> None:
        """Close HTTP client connections."""
        if self._async_client is not None:
            await self._async_client.aclose()
        elif self._sync_client is not None:
            self._sync_client.close()

    async def __aenter__(self) -> PolicyClient:
        """Async context manager entry."""
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: Any,
    ) -> None:
        """Async context manager exit."""
        await self.close()

    @staticmethod
    def _parse_contract(data: dict[str, Any], member_id: str) -> WorkerContract:
        """Parse API response into WorkerContract."""
        budget = None
        if data.get("budget"):
            budget = BudgetConfig(
                max_tokens=data["budget"].get("max_tokens"),
                max_cost_usd=data["budget"].get("max_cost_usd"),
                period_minutes=data["budget"].get("period_minutes", 60),
            )

        review_req = None
        if data.get("review_requirements"):
            review_req = ReviewRequirement(
                human_review_threshold=data["review_requirements"].get("human_review_threshold"),
                escalation_tasks=data["review_requirements"].get("escalation_tasks", []),
            )

        return WorkerContract(
            org_id=data["org_id"],
            member_id=data.get("member_id", member_id),
            role=data["role"],
            task_type=data["task_type"],
            trust_level=data["trust_level"],
            allowed_actions=data.get("allowed_actions", []),
            gated_actions=data.get("gated_actions", []),
            denied_actions=data.get("denied_actions", []),
            budget=budget,
            review_requirements=review_req,
            escalation_triggers=[
                EscalationTrigger(type=t["type"], threshold=t["threshold"])
                for t in data.get("escalation_triggers", [])
            ],
            help_protocol=data.get("help_protocol", "escalate_to_supervisor"),
            responsibility=data.get("responsibility", "task_executor"),
            credential_map=[
                CredentialMapEntry(
                    ref=c["ref"],
                    source=c["source"],
                    scope=c["scope"],
                    audit_required=c.get("audit_required", False),
                )
                for c in data.get("credential_map", [])
            ],
            version_hash=data.get("version_hash", ""),
        )


__all__ = ["PolicyClient"]
