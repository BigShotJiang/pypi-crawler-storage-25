"""Shared Prometheus metrics middleware for all platform services.

Usage in service main.py:
    from platform_commons.metrics_middleware import add_metrics
    add_metrics(app, service_name="adm")

Adds:
  1. ASGI middleware collecting golden signals (latency, traffic, errors, saturation)
  2. GET /metrics endpoint returning Prometheus exposition format
"""

from __future__ import annotations

import re
import time
from typing import Any

try:
    from prometheus_client import (
        CONTENT_TYPE_LATEST,
        Counter,
        Gauge,
        Histogram,
        generate_latest,
    )

    HAS_PROMETHEUS = True
except ImportError:
    HAS_PROMETHEUS = False


def _safe_metric(cls: type, name: str, desc: str, labels: list[str] | None = None) -> Any:
    """Create metric, reuse existing on duplicate (test safety)."""
    try:
        return cls(name, desc, labels) if labels else cls(name, desc)
    except ValueError:
        from prometheus_client import REGISTRY  # noqa: PLC0415

        return REGISTRY._names_to_collectors.get(name)


def add_metrics(app: Any, service_name: str) -> None:
    """One-liner to add Prometheus metrics to a FastAPI/Starlette app.

    If prometheus_client is not installed, this is a no-op.
    """
    if not HAS_PROMETHEUS:
        return

    request_duration = _safe_metric(
        Histogram,
        f"{service_name}_request_duration_seconds",
        f"HTTP request duration for {service_name}",
        ["method", "path", "status"],
    )
    requests_total = _safe_metric(
        Counter,
        f"{service_name}_requests_total",
        f"Total HTTP requests for {service_name}",
        ["method", "path", "status"],
    )
    errors_total = _safe_metric(
        Counter,
        f"{service_name}_errors_total",
        f"Total HTTP errors for {service_name}",
        ["status"],
    )
    inflight = _safe_metric(
        Gauge,
        f"{service_name}_inflight_requests",
        f"In-flight requests for {service_name}",
    )

    class _MetricsMiddleware:
        """Pure ASGI middleware — no BaseHTTPMiddleware stacking issues."""

        def __init__(self, inner_app: Any) -> None:
            self.app = inner_app

        async def __call__(self, scope: dict[str, Any], receive: Any, send: Any) -> None:
            if scope["type"] != "http":
                await self.app(scope, receive, send)
                return

            path = scope.get("path", "")
            if path == "/metrics":
                await self.app(scope, receive, send)
                return

            method = scope.get("method", "GET")
            status_code = 500

            async def send_wrapper(message: dict[str, Any]) -> None:
                nonlocal status_code
                if message["type"] == "http.response.start":
                    status_code = message.get("status", 500)
                await send(message)

            inflight.inc()
            start = time.monotonic()
            try:
                await self.app(scope, receive, send_wrapper)
            finally:
                duration = time.monotonic() - start
                inflight.dec()
                norm_path = _normalize_path(path)
                status_str = str(status_code)
                request_duration.labels(method, norm_path, status_str).observe(duration)
                requests_total.labels(method, norm_path, status_str).inc()
                if status_code >= 400:
                    errors_total.labels(status_str).inc()

    app.add_middleware(_MetricsMiddleware)

    from starlette.responses import Response  # noqa: PLC0415

    @app.get("/metrics", include_in_schema=False)  # type: ignore[untyped-decorator]
    async def metrics_endpoint() -> Response:
        return Response(content=generate_latest(), media_type=CONTENT_TYPE_LATEST)


_ID_PATTERNS = [
    re.compile(r"/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"),
    re.compile(r"/[0-9a-f]{8,}"),
    re.compile(r"/\d+"),
    re.compile(r"/(task|wf|exec|mbr|org|dec|art|wrk|pool|sw)_[a-zA-Z0-9_]+"),
]


def _normalize_path(path: str) -> str:
    """Collapse UUID/ID segments to {id} for label cardinality control."""
    for pattern in _ID_PATTERNS:
        path = pattern.sub("/{id}", path)
    return path
