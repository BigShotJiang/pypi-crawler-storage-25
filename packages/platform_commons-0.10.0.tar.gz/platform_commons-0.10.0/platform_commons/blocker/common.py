"""Common shared type aliases for the blocker subpackage (ROAD-M17-03).

Hosts the recursive :data:`JSONValue` alias used by every free-form
payload surface in the blocker contract (``typed_fields``, checkpoint
``blob``, etc.) per R1 (recon report §Objective 4 — "free-form payload
surfaces MUST NOT be annotated as dict[str, object] or bare object").

This module is a strict type sink: zero runtime imports from ``adm``,
``operator_agent``, or ``workers`` (Hard Rule 2).
"""

from __future__ import annotations

from collections.abc import Mapping
from typing import TypeAlias

__all__ = ["JSONValue"]

# Recursive JSON value alias (R1). Originally declared in the OA
# blocker_protocols module; moved here by ROAD-M17-03 phase 2
# commit PC-1 to become the single canonical definition reachable
# from every consumer repo.
#
# Uses ``TypeAlias`` (PEP 613) with a string forward reference for
# the recursive self-mention because platform_commons targets
# Python >= 3.11 and the ``type`` statement (PEP 695) is 3.12+.
# Consumer repos on Python >= 3.12 may re-export this alias freely.
JSONValue: TypeAlias = (
    str | int | float | bool | None | Mapping[str, "JSONValue"] | list["JSONValue"]
)
