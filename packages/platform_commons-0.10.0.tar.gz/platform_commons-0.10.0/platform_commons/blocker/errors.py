"""Blocker subsystem error taxonomy (ROAD-M17-03 phase 2, commit PC-1).

Port of the canonical hierarchy from ``adm/core/blocker_errors.py``
locked by ROAD-M17-01 phase 2 §H6. All exceptions descend from
:class:`BlockerError` so callers can use ``except BlockerError``
for a catch-all. Validator-level errors descend further from
:class:`BlockerValidationError`.

``WorkerTerminatedError`` is defined ONLY here (ROAD-M17-03 phase 2
unification per recon Objective 6). The ADM-side and WORKERS-side
local definitions are replaced by re-export shims in later commits
(ADM-2 and WORKERS-1 respectively). The pre-F1 risk grep on the
WORKERS repo confirmed zero ``except RuntimeError`` / ``except
WorkerTerminatedError`` / ``isinstance(*, RuntimeError)`` catch sites
in either production or test code, so the unified class inherits
ONLY from :class:`BlockerError`; no multiple-inheritance fallback
was needed.

This module is a strict type sink: zero runtime imports from ``adm``,
``operator_agent``, or ``workers`` (Hard Rule 2).
"""

from __future__ import annotations

from uuid import UUID

__all__ = [
    "BlockerAlreadyResolved",
    "BlockerConfidenceOutOfRange",
    "BlockerError",
    "BlockerOptionsEmpty",
    "BlockerSummaryTooLong",
    "BlockerValidationError",
    "CheckpointSerializationError",
    "CheckpointTooLargeError",
    "MissingRequiredTypedField",
    "RecommendedOptionInvalid",
    "UnexpectedTypedField",
    "WorkerTerminatedError",
]


class BlockerError(Exception):
    """Base for all blocker subsystem errors."""


class BlockerValidationError(BlockerError):
    """Raised by ``validate_blocker_report`` on any rule violation.

    Intermediate base — specific rules raise a subclass below so callers
    can distinguish "missing required field" from "summary too long" etc.
    """


class MissingRequiredTypedField(BlockerValidationError):
    """A required key for the blocker's type is missing from ``typed_fields``."""


class UnexpectedTypedField(BlockerValidationError):
    """A key not in ``required+optional`` for the blocker's type is present."""


class BlockerOptionsEmpty(BlockerValidationError):
    """A blocker report was submitted with zero options."""


class RecommendedOptionInvalid(BlockerValidationError):
    """``recommended_option`` does not match any option id in ``options``."""


class BlockerSummaryTooLong(BlockerValidationError):
    """``summary`` exceeds the 200-character limit."""


class BlockerConfidenceOutOfRange(BlockerValidationError):
    """``confidence`` is not inside ``[0.0, 1.0]``."""


class BlockerAlreadyResolved(BlockerError):
    """Raised by ``resolve_blocker`` on CAS rowcount==0.

    Carries both the target blocker_id and the existing resolution_id
    so callers can log / surface the losing resolution attempt without
    a second DB lookup.
    """

    def __init__(self, blocker_id: UUID, existing_resolution_id: UUID) -> None:
        super().__init__(
            f"blocker {blocker_id} is already resolved "
            f"(existing_resolution_id={existing_resolution_id})"
        )
        self.blocker_id = blocker_id
        self.existing_resolution_id = existing_resolution_id


class CheckpointSerializationError(BlockerError):
    """The checkpoint blob is not JSON-serializable (envelope hardening, §H4)."""


class CheckpointTooLargeError(BlockerError):
    """The checkpoint blob exceeds ``MAX_CHECKPOINT_BYTES`` (§H4)."""


class WorkerTerminatedError(BlockerError):
    """Raised when a public SDK client method is called after ``report_blocker``.

    Enforces the H1 hard-terminal contract: a worker that has reported
    a blocker MUST NOT mutate workflow state further via the same SDK
    client instance. Any concrete public method on the adapter
    (``execute``, ``health_check``, ``report_blocker`` again, or
    ``resume_step_with_resolution``) raises this exception after
    ``report_blocker`` has been called once. Metadata accessors
    (``family_name``, ``capabilities``) are intentionally NOT guarded
    — they are safe to read post-termination because adapter
    registries may introspect them at any time.

    Unified here by ROAD-M17-03 phase 2 (commit PC-1): previously the
    ADM side inherited from :class:`BlockerError` and the WORKERS
    side from :class:`RuntimeError`. The pre-F1 WORKERS grep (zero
    ``except RuntimeError`` / ``except WorkerTerminatedError`` /
    ``isinstance`` catch sites in production or tests) confirmed the
    unified base class can be :class:`BlockerError` alone with no
    behavior regression in WORKERS.
    """
