"""Structural Protocols for the blocker contract (ROAD-M17-03 phase 2).

PEP 544 Protocol classes that mirror the public attribute surface of
the concrete :mod:`platform_commons.blocker.types` dataclasses. These
exist so consumers that prefer structural typing (OA renderer,
WORKERS adapter SDK) can type their parameters without depending on
the concrete frozen dataclass identity.

Sources consolidated here (ROAD-M17-03 phase 2 commit PC-1):

* :class:`BlockerOptionLike`, :class:`BlockerReportLike` — ported
  from ``operator_agent/blocker_protocols.py`` (the broader
  OA-side version, which includes the ``options`` field). The
  WORKERS-local narrower version at ``workers/adapters/base.py:71``
  is superseded by this shared definition in commit WORKERS-1
  (reinforcement R-F1-B: concrete BlockerReport passes both
  historical shapes, so the broader Protocol is a strict superset).
* :class:`BlockerResolutionLike`, :class:`CheckpointLike` — ported
  from ``workers/adapters/base.py`` (read-only port, F1 does not
  modify WORKERS files).

``BlockerReportLike.typed_fields`` uses the :data:`JSONValue`
recursive alias from :mod:`platform_commons.blocker.common` (R1:
free-form payload surfaces MUST NOT be ``dict[str, object]`` or
bare ``object``).

This module is a strict type sink: zero runtime imports from
``adm``, ``operator_agent``, or ``workers`` (Hard Rule 2).
"""

from __future__ import annotations

from collections.abc import Mapping
from typing import Protocol

from platform_commons.blocker.common import JSONValue

__all__ = [
    "BlockerOptionLike",
    "BlockerReportLike",
    "BlockerResolutionLike",
    "CheckpointLike",
]


class BlockerOptionLike(Protocol):
    """Structural mirror of :class:`platform_commons.blocker.types.BlockerOption`.

    The four public attributes match the concrete dataclass field
    names exactly. ``impact`` and ``risk`` are free-form strings;
    no further structure is assumed in phase 2.
    """

    id: str
    title: str
    impact: str
    risk: str


class BlockerReportLike(Protocol):
    """Structural mirror of :class:`platform_commons.blocker.types.BlockerReport`.

    The narrower form hosted previously in
    ``workers/adapters/base.py:71`` omitted the ``options`` field;
    this consolidated version declares it because the OA renderer
    requires it for the decision card. Concrete
    :class:`BlockerReport` satisfies both shapes, so the merger is
    a pure superset move (ROAD-M17-03 phase 2 commit PC-1,
    reinforcement R-F1-B).

    ``typed_fields`` is R1-tight (:data:`JSONValue` recursive alias,
    wrapped in :class:`collections.abc.Mapping`). It MUST NOT be
    annotated as ``dict[str, object]`` or bare ``object``.
    """

    summary: str
    details_prose: str
    typed_fields: Mapping[str, JSONValue]
    options: list[BlockerOptionLike]
    recommended_option: str
    confidence: float
    task_id: str  # ADM-side tasks.task_id -- globally unique (ROAD-M17-02 F1 B-prime-2).


class CheckpointLike(Protocol):
    """Structural mirror of the ADM/WORKERS ``Checkpoint`` envelope.

    Only WORKERS uses this Protocol today (SDK method parameter on
    ``BaseCliAdapter.report_blocker``). Consolidated here so a
    future non-WORKERS consumer can reference the same shape
    without a duplicate local declaration.
    """

    step_id: str
    worker_id: str
    blob: Mapping[str, JSONValue]


class BlockerResolutionLike(Protocol):
    """Structural mirror of :class:`platform_commons.blocker.types.BlockerResolution`.

    Narrower than the concrete dataclass (omits
    ``scope_amendment_note``, ``resolver_id``, ``resolved_at``)
    because the WORKERS SDK only reads the two core fields.
    Concrete :class:`BlockerResolution` satisfies this Protocol via
    structural subtyping.
    """

    selected_option: str
    rationale: str
