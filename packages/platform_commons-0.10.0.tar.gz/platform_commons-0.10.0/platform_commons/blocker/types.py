"""Blocker contract types (ROAD-M17-03 phase 2, commit PC-1).

Port of the canonical blocker contract types originally hosted in
``adm/core/blocker_types.py`` (ROAD-M17-01 phase 2 §S3). This module
is the single source of truth for every consumer repo (ADM, OA,
WORKERS) after ROAD-M17-03 phase 2 lands.

Locked contracts:

* :class:`BlockerType` — 8-value StrEnum.
* :data:`BLOCKER_TYPED_FIELDS_SCHEMA` — per-type strict schema.
* :class:`BlockerReport` — the full report shape written by a worker.
* :class:`BlockerOption` — one candidate resolution option.
* :class:`BlockerOutcome` — frozen tagged return value from
  ``BlockerService.create_blocker`` per §H3.
* :class:`BlockerResolution` — the resolution payload chosen by an actor.
* :class:`RoutingDecision` — policy engine routing decision per §H2.
* :class:`DecisionCard` — user-facing governance card dataclass
  (originally hosted in OA ``blocker_decision_card.py``).
* :class:`DecisionCardOption` — inner dataclass referenced by
  :class:`DecisionCard.options` (implicit transitive dependency of
  DecisionCard; pre-flight reinforcement R-F1-A during commit PC-1).
* :class:`DecisionCardLike` — marker Protocol satisfied by
  :class:`DecisionCard` (retained for RoutingDecision.payload
  structural narrowing and backwards-compat with the ADM phase-2
  marker Protocol).

Dependency-light by design: only stdlib. This module is a strict
type sink — zero runtime imports from ``adm``, ``operator_agent``,
or ``workers`` (Hard Rule 2).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum
from typing import Any, Literal, Protocol
from uuid import UUID

__all__ = [
    "BLOCKER_TYPED_FIELDS_SCHEMA",
    "BlockerOption",
    "BlockerOutcome",
    "BlockerReport",
    "BlockerResolution",
    "BlockerType",
    "DecisionCard",
    "DecisionCardLike",
    "DecisionCardOption",
    "RoutingDecision",
]


class BlockerType(StrEnum):
    """Typed categorization of worker-emitted blockers (§S3)."""

    CLARIFICATION_REQUIRED = "clarification_required"
    DECISION_REQUIRED = "decision_required"
    CONTRADICTION_DETECTED = "contradiction_detected"
    ACCESS_REQUIRED = "access_required"
    APPROVAL_REQUIRED = "approval_required"
    DEPENDENCY_UNAVAILABLE = "dependency_unavailable"
    POLICY_BLOCKED = "policy_blocked"
    RESOURCE_MISSING = "resource_missing"


# Per-type strict schema: for each BlockerType, which keys are required
# and which are optional inside ``BlockerReport.typed_fields``. Any key
# outside ``required + optional`` is rejected by the validator (strict
# mode — prevents silent schema drift).
BLOCKER_TYPED_FIELDS_SCHEMA: dict[BlockerType, dict[str, list[str]]] = {
    BlockerType.CONTRADICTION_DETECTED: {
        "required": ["spec_ref", "baseline_ref"],
        "optional": ["contradicting_tests"],
    },
    BlockerType.DECISION_REQUIRED: {
        "required": ["decision_topic"],
        "optional": ["constraints"],
    },
    BlockerType.CLARIFICATION_REQUIRED: {
        "required": ["question_code", "unknown_fact"],
        "optional": [],
    },
    BlockerType.ACCESS_REQUIRED: {
        "required": ["resource", "required_permission"],
        "optional": [],
    },
    BlockerType.APPROVAL_REQUIRED: {
        "required": ["action_requiring_approval", "approval_scope"],
        "optional": [],
    },
    BlockerType.DEPENDENCY_UNAVAILABLE: {
        "required": ["dependency_name", "failure_mode"],
        "optional": ["retry_count"],
    },
    BlockerType.POLICY_BLOCKED: {
        "required": ["violated_policy_id"],
        "optional": ["policy_version"],
    },
    BlockerType.RESOURCE_MISSING: {
        "required": ["resource_type", "resource_id"],
        "optional": [],
    },
}


@dataclass(frozen=True)
class BlockerOption:
    """One candidate resolution option presented by the worker."""

    id: str
    title: str
    impact: str
    risk: str


@dataclass(frozen=True)
class BlockerReport:
    """Full blocker report written by a worker via ``report_blocker``."""

    type: BlockerType
    summary: str
    details_prose: str
    typed_fields: dict[str, Any]
    options: list[BlockerOption]
    recommended_option: str
    confidence: float
    required_actor: str
    workflow_id: UUID
    step_id: str
    task_id: str  # ADM-side tasks.task_id — globally unique task instance identifier.
    # Used by ADM BlockerService.create_blocker as identity arg for the
    # workflow_steps row (ROAD-M17-02 F1 B-prime-2; see spike findings S5).
    worker_id: str


@dataclass(frozen=True)
class BlockerResolution:
    """Resolution payload chosen by an actor (OA, policy engine, etc.)."""

    selected_option: str
    rationale: str
    scope_amendment_note: str | None = None
    resolver_id: str | None = None
    resolved_at: datetime | None = None


@dataclass(frozen=True)
class BlockerOutcome:
    """Tagged frozen return value from ``BlockerService.create_blocker`` (§H3)."""

    status: Literal["pending", "auto_resolved", "duplicate"]
    blocker_id: UUID | None
    superseded_by: UUID | None = None
    auto_resolution: BlockerResolution | None = None


@dataclass(frozen=True)
class RoutingDecision:
    """Routing decision returned by ``BlockerPolicyEngine.route`` (§H2).

    This shape is LOCKED. Phase 3 may add new allowed values to the
    ``action`` / ``target_actor`` literals and may narrow ``payload``
    to ``DecisionCard | None``, but MUST NOT add, remove, or rename
    fields.
    """

    blocker_id: UUID
    action: Literal["escalate_to_oa", "auto_resolve", "deny", "route_to_role"]
    target_actor: str  # Phase 2: "oa"|"policy_engine"|"none"; Phase 3: any canonical role
    payload: DecisionCardLike | None
    rationale: str
    routed_at: datetime


@dataclass(frozen=True)
class DecisionCardOption:
    """One rendered option inside a :class:`DecisionCard`.

    Mirrors :class:`BlockerOption` with identical field names; exists
    as a separate type so the OA renderer can transform ADM's
    BlockerOption into the card-specific shape without leaking the
    ADM frozen dataclass identity into governance output.
    """

    id: str
    title: str
    impact: str
    risk: str


@dataclass(frozen=True)
class DecisionCard:
    """User-facing decision card for a blocker escalation (§S8).

    ``details_url`` is the relative path of the ADM-owned blocker
    details endpoint (ROAD-M17-04). It is rendered as a literal text
    line by the OA renderer.
    """

    blocker_id: UUID
    title: str
    summary: str
    options: list[DecisionCardOption]
    recommended_option_id: str
    risk_summary: str
    details_url: str
    details_prose: str = ""
    typed_fields_preview: list[str] = field(default_factory=list)


class DecisionCardLike(Protocol):
    """Marker Protocol for :class:`DecisionCard` structural narrowing.

    Originally declared as a cross-repo boundary Protocol so ADM's
    :class:`RoutingDecision.payload` could be typed without a runtime
    import from OA. Retained here even though the real
    :class:`DecisionCard` now lives in the same module, because:

    * :class:`RoutingDecision.payload` annotation prefers the
      structural form to decouple the policy engine from the full
      dataclass shape.
    * Backwards compat: the ADM-side marker Protocol was the original
      boundary and re-exporting it preserves the import signature
      for any consumer that referenced it.

    Any object exposing a ``blocker_id`` attribute typed as
    :class:`uuid.UUID` satisfies the protocol.
    """

    blocker_id: UUID
