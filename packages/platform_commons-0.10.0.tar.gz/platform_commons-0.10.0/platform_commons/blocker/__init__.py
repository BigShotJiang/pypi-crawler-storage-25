"""Shared blocker contract types (ROAD-M17-03 phase 2, commit PC-1).

The :mod:`platform_commons.blocker` subpackage is the single source
of truth for the M17-01 blocker contract across the ADM, Operator
Agent, and WORKERS repositories. Before ROAD-M17-03 these types were
duplicated in all three consumer repos; this subpackage consolidates
them into a strict type sink (zero runtime imports from ``adm``,
``operator_agent``, or ``workers`` — enforced by the CI assertion
added in commit PC-2).

Public surface — re-exported from sibling modules:

* :mod:`~platform_commons.blocker.types` — BlockerReport,
  BlockerOption, BlockerOutcome, BlockerResolution, RoutingDecision,
  DecisionCard, DecisionCardOption, DecisionCardLike, BlockerType,
  BLOCKER_TYPED_FIELDS_SCHEMA.
* :mod:`~platform_commons.blocker.errors` — BlockerError + 11
  subclasses including the unified WorkerTerminatedError(BlockerError).
* :mod:`~platform_commons.blocker.protocols` — BlockerReportLike,
  BlockerOptionLike, BlockerResolutionLike, CheckpointLike.
* :mod:`~platform_commons.blocker.common` — JSONValue recursive
  alias.

Consumer repos import from this package directly
(``platform_commons.blocker.types.BlockerReport``) or via the
re-export shims in the consumer repos themselves (the
``adm.core.blocker_types`` module path, added in commits
ADM-1/ADM-2 in F2).
"""

from __future__ import annotations

from platform_commons.blocker.common import JSONValue
from platform_commons.blocker.errors import (
    BlockerAlreadyResolved,
    BlockerConfidenceOutOfRange,
    BlockerError,
    BlockerOptionsEmpty,
    BlockerSummaryTooLong,
    BlockerValidationError,
    CheckpointSerializationError,
    CheckpointTooLargeError,
    MissingRequiredTypedField,
    RecommendedOptionInvalid,
    UnexpectedTypedField,
    WorkerTerminatedError,
)
from platform_commons.blocker.protocols import (
    BlockerOptionLike,
    BlockerReportLike,
    BlockerResolutionLike,
    CheckpointLike,
)
from platform_commons.blocker.types import (
    BLOCKER_TYPED_FIELDS_SCHEMA,
    BlockerOption,
    BlockerOutcome,
    BlockerReport,
    BlockerResolution,
    BlockerType,
    DecisionCard,
    DecisionCardLike,
    DecisionCardOption,
    RoutingDecision,
)

__all__ = [
    "BLOCKER_TYPED_FIELDS_SCHEMA",
    "BlockerAlreadyResolved",
    "BlockerConfidenceOutOfRange",
    "BlockerError",
    "BlockerOption",
    "BlockerOptionLike",
    "BlockerOptionsEmpty",
    "BlockerOutcome",
    "BlockerReport",
    "BlockerReportLike",
    "BlockerResolution",
    "BlockerResolutionLike",
    "BlockerSummaryTooLong",
    "BlockerType",
    "BlockerValidationError",
    "CheckpointLike",
    "CheckpointSerializationError",
    "CheckpointTooLargeError",
    "DecisionCard",
    "DecisionCardLike",
    "DecisionCardOption",
    "JSONValue",
    "MissingRequiredTypedField",
    "RecommendedOptionInvalid",
    "RoutingDecision",
    "UnexpectedTypedField",
    "WorkerTerminatedError",
]
