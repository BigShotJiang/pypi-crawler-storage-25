"""Policy data models (shared between registry and consumers)."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum
from typing import Any


class PolicyDecisionOutcome(StrEnum):
    """Policy evaluation outcome."""

    ALLOW = "allow"
    DENY = "deny"
    REQUIRE_REVIEW = "require_review"
    ESCALATE = "escalate"


@dataclass
class PolicyDecision:
    """Result of a policy evaluation."""

    outcome: PolicyDecisionOutcome
    rule_id: str
    domain: str
    reason: str
    metadata: dict[str, Any] = field(default_factory=dict)
    evaluated_at: datetime = field(default_factory=datetime.utcnow)
    ttl_seconds: int | None = None


@dataclass
class BudgetConfig:
    """Token and cost budget constraints."""

    max_tokens: int | None = None
    max_cost_usd: float | None = None
    period_minutes: int = 60


@dataclass
class ReviewRequirement:
    """Human review thresholds and triggers."""

    human_review_threshold: int | None = None
    escalation_tasks: list[str] = field(default_factory=list)


@dataclass
class EscalationTrigger:
    """Automatic escalation condition."""

    type: str  # "cost_exceeded", "token_limit_exceeded", "policy_violation"
    threshold: float


@dataclass
class CredentialMapEntry:
    """Credential reference in a contract."""

    ref: str  # e.g., "github_token", "api_key"
    source: str  # "member_shared", "org_shared", "denied"
    scope: str  # e.g., "public_repos_only", "all_actions", "read_only"
    audit_required: bool = False


@dataclass
class WorkerContract:
    """Compiled policy contract for a worker in a specific context.

    Returned by PolicyClient.get_contract(). Contains all applicable
    restrictions, capabilities, and audit requirements.
    """

    org_id: str
    member_id: str
    role: str  # "executor", "reviewer", "supervisor", etc.
    task_type: str  # "research", "development", "analysis", etc.
    trust_level: str  # "1", "2", "3", "4", "5"

    # Capabilities
    allowed_actions: list[str] = field(default_factory=list)
    gated_actions: list[str] = field(default_factory=list)  # Require review
    denied_actions: list[str] = field(default_factory=list)

    # Constraints
    budget: BudgetConfig | None = None
    review_requirements: ReviewRequirement | None = None
    escalation_triggers: list[EscalationTrigger] = field(default_factory=list)

    # Metadata
    help_protocol: str = "escalate_to_supervisor"  # How to handle exceptions
    responsibility: str = "task_executor"  # Who is accountable
    credential_map: list[CredentialMapEntry] = field(default_factory=list)
    version_hash: str = ""  # Trace contract version
    compiled_at: datetime = field(default_factory=datetime.utcnow)

    @property
    def all_denied_actions(self) -> set[str]:
        """Return union of denied_actions and gated_actions."""
        return set(self.denied_actions) | set(self.gated_actions)

    def can_perform(self, action: str) -> bool:
        """Quick check: can this action be performed without review?"""
        if action in self.denied_actions:
            return False
        return action in self.allowed_actions

    def requires_review(self, action: str) -> bool:
        """Quick check: does this action require human review?"""
        return action in self.gated_actions


@dataclass
class Policy:
    """A policy object (read from registry)."""

    id: str
    domain: str
    name: str
    version: str
    org_id: str | None = None
    member_id: str | None = None
    rules: dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    metadata: dict[str, Any] = field(default_factory=dict)


__all__ = [
    "BudgetConfig",
    "CredentialMapEntry",
    "EscalationTrigger",
    "Policy",
    "PolicyDecision",
    "PolicyDecisionOutcome",
    "ReviewRequirement",
    "WorkerContract",
]
