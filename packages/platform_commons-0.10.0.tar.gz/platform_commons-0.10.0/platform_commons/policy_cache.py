"""In-memory cache layer for PolicyClient."""

from __future__ import annotations

import asyncio
import hashlib
import json
import threading
from datetime import datetime
from fnmatch import fnmatch
from typing import Any, Generic, TypeVar

T = TypeVar("T")


class CacheEntry(Generic[T]):
    """Single cache entry with timestamp."""

    def __init__(self, value: T, ttl_seconds: int) -> None:
        self.value = value
        self.created_at = datetime.utcnow()
        self.ttl_seconds = ttl_seconds

    def is_expired(self) -> bool:
        """Check if entry has exceeded TTL."""
        age = (datetime.utcnow() - self.created_at).total_seconds()
        return age > self.ttl_seconds

    def __repr__(self) -> str:
        return (
            f"CacheEntry(age_s={self._age_seconds():.1f}, "
            f"ttl={self.ttl_seconds}, expired={self.is_expired()})"
        )

    def _age_seconds(self) -> float:
        return (datetime.utcnow() - self.created_at).total_seconds()


class AsyncCache:
    """Async-safe TTL cache using asyncio.Lock."""

    def __init__(self, default_ttl_seconds: int = 60) -> None:
        self.store: dict[str, CacheEntry[Any]] = {}
        self.default_ttl = default_ttl_seconds
        self.lock = asyncio.Lock()

    async def get(self, key: str) -> Any | None:
        """Retrieve from cache (non-blocking within async context)."""
        async with self.lock:
            if key not in self.store:
                return None
            entry = self.store[key]
            if entry.is_expired():
                del self.store[key]
                return None
            return entry.value

    async def set(self, key: str, value: Any, ttl_seconds: int | None = None) -> None:
        """Store in cache."""
        ttl = ttl_seconds or self.default_ttl
        async with self.lock:
            self.store[key] = CacheEntry(value, ttl)

    async def delete(self, key: str) -> None:
        """Remove specific key."""
        async with self.lock:
            self.store.pop(key, None)

    async def invalidate(self, pattern: str | None = None) -> int:
        """Invalidate by pattern (glob-style) or all if pattern is None.

        Returns count of deleted entries.
        """
        async with self.lock:
            if pattern is None:
                count = len(self.store)
                self.store.clear()
                return count

            keys_to_delete = [k for k in self.store if fnmatch(k, pattern)]
            for key in keys_to_delete:
                del self.store[key]
            return len(keys_to_delete)

    async def clear(self) -> None:
        """Clear all cache entries."""
        async with self.lock:
            self.store.clear()

    async def size(self) -> int:
        """Return count of entries (not considering expiry)."""
        async with self.lock:
            return len(self.store)


class SyncCache:
    """Sync-safe TTL cache using threading.Lock."""

    def __init__(self, default_ttl_seconds: int = 60) -> None:
        self.store: dict[str, CacheEntry[Any]] = {}
        self.default_ttl = default_ttl_seconds
        self.lock = threading.Lock()

    def get(self, key: str) -> Any | None:
        """Retrieve from cache (blocking, thread-safe)."""
        with self.lock:
            if key not in self.store:
                return None
            entry = self.store[key]
            if entry.is_expired():
                del self.store[key]
                return None
            return entry.value

    def set(self, key: str, value: Any, ttl_seconds: int | None = None) -> None:
        """Store in cache."""
        ttl = ttl_seconds or self.default_ttl
        with self.lock:
            self.store[key] = CacheEntry(value, ttl)

    def delete(self, key: str) -> None:
        """Remove specific key."""
        with self.lock:
            self.store.pop(key, None)

    def invalidate(self, pattern: str | None = None) -> int:
        """Invalidate by pattern (glob-style) or all if pattern is None.

        Returns count of deleted entries.
        """
        with self.lock:
            if pattern is None:
                count = len(self.store)
                self.store.clear()
                return count

            keys_to_delete = [k for k in self.store if fnmatch(k, pattern)]
            for key in keys_to_delete:
                del self.store[key]
            return len(keys_to_delete)

    def clear(self) -> None:
        """Clear all cache entries."""
        with self.lock:
            self.store.clear()

    def size(self) -> int:
        """Return count of entries (not considering expiry)."""
        with self.lock:
            return len(self.store)


def make_cache_key(*args: Any, method: str = "") -> str:
    """Generate cache key from method name and arguments.

    Format: {method}:{hash}
    """
    # Hash the arguments to avoid long keys
    args_str = json.dumps(args, sort_keys=True, default=str)
    args_hash = hashlib.md5(args_str.encode()).hexdigest()[:8]  # noqa: S324
    return f"{method}:{args_hash}"


__all__ = ["AsyncCache", "CacheEntry", "SyncCache", "make_cache_key"]
