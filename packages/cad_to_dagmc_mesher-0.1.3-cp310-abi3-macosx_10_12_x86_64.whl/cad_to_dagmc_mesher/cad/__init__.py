"""
Optional CAD helpers for cad-to-dagmc-mesher.

Extracts UV edge polylines from OCC shapes and evaluates UV
results back to 3D.  Requires ``cadquery-ocp`` — install with::

    pip install cad-to-dagmc-mesher[cad]

Single-shape functions
    :func:`extract_face_inputs` — extract faces from one shape
    :func:`evaluate_3d` — UV results → 3D vertices and triangles
    :func:`mesh_shape` — full pipeline → ``vertices_to_h5m``-compatible output

Multi-volume (imprinted assembly) functions
    :func:`extract_assembly` — imprint + extract with shared-face tracking
    :func:`mesh_assembly` — full pipeline → ``vertices_to_h5m``-compatible output
"""

try:
    from OCP.BRep import BRep_Tool as _  # noqa: F401
except ImportError as e:
    raise ImportError(
        "cad_to_dagmc_mesher.cad requires cadquery-ocp.  Install with:  pip install cad-to-dagmc-mesher[cad]"
    ) from e

from ._assembly import SolidConfig, extract_assembly, mesh_assembly
from ._evaluate import evaluate_3d
from ._extract import extract_face_inputs
from ._shape import mesh_shape
from ._size_field import compute_size_field

__all__ = [
    "SolidConfig",
    "compute_size_field",
    "evaluate_3d",
    "extract_assembly",
    "extract_face_inputs",
    "mesh_assembly",
    "mesh_shape",
]
