"""Curvature-adaptive size field computation from OCC surfaces."""

import math

from OCP.BRepAdaptor import BRepAdaptor_Surface


def compute_size_field(occ_face, nu=20, nv=20, elements_per_2pi=15,
                       min_h=0.01, max_h=None, chordal_tolerance=None):
    """Compute a curvature-adaptive size field for a face.

    Uses the first fundamental form (metric tensor) and principal curvatures
    from OCC to determine local target edge lengths.

    Parameters
    ----------
    occ_face : TopoDS_Face
    nu, nv : int
        Grid resolution in U and V.
    elements_per_2pi : float
        Elements per full circle of curvature (higher = denser at curves).
    min_h, max_h : float
        Bounds on target edge length in 3D.
    chordal_tolerance : float or None
        If set, also limits target_h via ``h <= sqrt(8 * tol / kappa)``.
    """
    from OCP.BRepLProp import BRepLProp_SLProps
    from OCP.gp import gp_Pnt, gp_Vec

    surface = BRepAdaptor_Surface(occ_face)
    u0 = surface.FirstUParameter()
    u1 = surface.LastUParameter()
    v0 = surface.FirstVParameter()
    v1 = surface.LastVParameter()

    target_h = []
    metric_e = []
    metric_f = []
    metric_g = []
    target_h1 = []
    target_h2 = []
    curvature_angle = []

    for iv in range(nv):
        vp = v0 + iv * (v1 - v0) / max(nv - 1, 1)
        for iu in range(nu):
            up = u0 + iu * (u1 - u0) / max(nu - 1, 1)

            p = gp_Pnt()
            du = gp_Vec()
            dv = gp_Vec()
            surface.D1(up, vp, p, du, dv)

            E = du.Dot(du)
            F = du.Dot(dv)
            G = dv.Dot(dv)

            metric_e.append(E)
            metric_f.append(F)
            metric_g.append(G)

            props = BRepLProp_SLProps(surface, up, vp, 2, 1e-7)
            if props.IsCurvatureDefined():
                kappa = max(abs(props.MaxCurvature()), abs(props.MinCurvature()))
            else:
                kappa = 0.0

            if kappa > 1e-12:
                h = 2.0 * math.pi / (kappa * elements_per_2pi)
            else:
                h = max_h if max_h is not None else 1e6

            if chordal_tolerance is not None and kappa > 1e-12:
                h_chordal = math.sqrt(8.0 * chordal_tolerance / kappa)
                h = min(h, h_chordal)

            h = max(h, min_h)
            if max_h is not None:
                h = min(h, max_h)

            target_h.append(h)

            # Anisotropic sizing: compute per-direction target sizes
            # from the two principal curvatures.
            if props.IsCurvatureDefined():
                k_max = abs(props.MaxCurvature())
                k_min = abs(props.MinCurvature())

                # Target size in each principal direction
                if k_max > 1e-12:
                    h1 = 2.0 * math.pi / (k_max * elements_per_2pi)
                    if chordal_tolerance is not None:
                        h1 = min(h1, math.sqrt(8.0 * chordal_tolerance / k_max))
                else:
                    h1 = max_h if max_h is not None else 1e6
                if k_min > 1e-12:
                    h2 = 2.0 * math.pi / (k_min * elements_per_2pi)
                    if chordal_tolerance is not None:
                        h2 = min(h2, math.sqrt(8.0 * chordal_tolerance / k_min))
                else:
                    h2 = max_h if max_h is not None else 1e6

                h1 = max(min_h, min(h1, max_h) if max_h else h1)
                h2 = max(min_h, min(h2, max_h) if max_h else h2)

                # Principal curvature direction angle relative to du
                try:
                    d1 = props.CurvatureDirection1()
                    # Project d1 onto the (du, dv) tangent basis
                    du_mag = du.Magnitude()
                    dv_mag = dv.Magnitude()
                    if du_mag > 1e-12 and dv_mag > 1e-12:
                        cos_a = d1.Dot(du) / du_mag
                        sin_a = d1.Dot(dv) / dv_mag
                        angle = math.atan2(sin_a, cos_a)
                    else:
                        angle = 0.0
                except Exception:
                    angle = 0.0
            else:
                h1 = h
                h2 = h
                angle = 0.0

            target_h1.append(h1)
            target_h2.append(h2)
            curvature_angle.append(angle)

    return {
        "nu": nu, "nv": nv,
        "u_min": u0, "u_max": u1,
        "v_min": v0, "v_max": v1,
        "target_h": target_h,
        "metric_e": metric_e,
        "metric_f": metric_f,
        "metric_g": metric_g,
        "target_h1": target_h1,
        "target_h2": target_h2,
        "curvature_angle": curvature_angle,
    }
