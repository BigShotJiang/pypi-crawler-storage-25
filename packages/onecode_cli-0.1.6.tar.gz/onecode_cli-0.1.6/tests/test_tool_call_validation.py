#!/usr/bin/env python3
"""Test tool call validation in RAGAS evaluator."""

import sys
from eval.ragas_metrics import RAGASMetricsEvaluator


def test_valid_tool_calls():
    """Test conversion of valid tool call dicts."""
    evaluator = RAGASMetricsEvaluator()
    tools = [
        {"name": "search", "args": {"query": "test"}},
        {"name": "analyze", "args": {}},
        {"name": "fetch", "args": {"url": "http://example.com"}},
    ]

    result = evaluator._convert_to_tool_calls(tools)
    assert len(result) == 3
    assert result[0].name == "search"
    assert result[1].name == "analyze"
    assert result[2].name == "fetch"
    print("✓ test_valid_tool_calls passed")


def test_empty_tool_list():
    """Test handling of empty tool list."""
    evaluator = RAGASMetricsEvaluator()
    result = evaluator._convert_to_tool_calls([])
    assert result == []
    print("✓ test_empty_tool_list passed")


def test_missing_name_field():
    """Test error on missing 'name' field."""
    evaluator = RAGASMetricsEvaluator()
    tools = [
        {"args": {"query": "test"}}  # Missing name
    ]

    try:
        evaluator._convert_to_tool_calls(tools)
        assert False, "Should raise ValueError"
    except ValueError as e:
        assert "missing required 'name' field" in str(e)
        print("✓ test_missing_name_field passed")


def test_empty_name_field():
    """Test error on empty 'name' field."""
    evaluator = RAGASMetricsEvaluator()
    tools = [
        {"name": "", "args": {"query": "test"}}  # Empty name
    ]

    try:
        evaluator._convert_to_tool_calls(tools)
        assert False, "Should raise ValueError"
    except ValueError as e:
        assert "missing required 'name' field" in str(e)
        print("✓ test_empty_name_field passed")


def test_invalid_name_type():
    """Test error on non-string name."""
    evaluator = RAGASMetricsEvaluator()
    tools = [
        {"name": 123, "args": {}}  # Name is int, not str
    ]

    try:
        evaluator._convert_to_tool_calls(tools)
        assert False, "Should raise ValueError"
    except ValueError as e:
        assert "invalid 'name' type" in str(e)
        assert "int" in str(e)
        print("✓ test_invalid_name_type passed")


def test_invalid_args_type():
    """Test error on non-dict args."""
    evaluator = RAGASMetricsEvaluator()
    tools = [
        {"name": "search", "args": "invalid"}  # Args is string, not dict
    ]

    try:
        evaluator._convert_to_tool_calls(tools)
        assert False, "Should raise ValueError"
    except ValueError as e:
        assert "invalid 'args' type" in str(e)
        assert "str" in str(e)
        print("✓ test_invalid_args_type passed")


def test_invalid_tool_type():
    """Test error on non-dict, non-ToolCall object."""
    evaluator = RAGASMetricsEvaluator()
    tools = [
        "not a dict"  # Invalid type
    ]

    try:
        evaluator._convert_to_tool_calls(tools)
        assert False, "Should raise ValueError"
    except ValueError as e:
        assert "must be dict or ToolCall object" in str(e)
        assert "str" in str(e)
        print("✓ test_invalid_tool_type passed")


def test_none_args_converts_to_empty_dict():
    """Test that None args is converted to empty dict."""
    evaluator = RAGASMetricsEvaluator()
    tools = [
        {"name": "search", "args": None}  # None args
    ]

    result = evaluator._convert_to_tool_calls(tools)
    assert len(result) == 1
    assert result[0].name == "search"
    assert result[0].args == {}
    print("✓ test_none_args_converts_to_empty_dict passed")


def test_missing_args_field():
    """Test that missing args field defaults to empty dict."""
    evaluator = RAGASMetricsEvaluator()
    tools = [
        {"name": "search"}  # Missing args
    ]

    result = evaluator._convert_to_tool_calls(tools)
    assert len(result) == 1
    assert result[0].name == "search"
    assert result[0].args == {}
    print("✓ test_missing_args_field passed")


def test_multiple_tools_with_one_invalid():
    """Test that one invalid tool fails entire conversion."""
    evaluator = RAGASMetricsEvaluator()
    tools = [
        {"name": "search", "args": {"query": "test"}},
        {"name": "", "args": {}},  # Invalid: empty name
        {"name": "fetch", "args": {}},
    ]

    try:
        evaluator._convert_to_tool_calls(tools)
        assert False, "Should raise ValueError"
    except ValueError as e:
        assert "index 1" in str(e)  # Error on second tool
        print("✓ test_multiple_tools_with_one_invalid passed")


def test_clear_error_messages():
    """Test that error messages are clear and helpful."""
    evaluator = RAGASMetricsEvaluator()
    tools = [
        {"name": "search"}  # This is actually valid (args defaults to {})
    ]

    result = evaluator._convert_to_tool_calls(tools)
    assert len(result) == 1

    # Now test invalid case
    tools = [
        {"args": {"x": 1}}  # Missing name
    ]

    try:
        evaluator._convert_to_tool_calls(tools)
        assert False, "Should raise ValueError"
    except ValueError as e:
        error_msg = str(e)
        assert "index 0" in error_msg  # Which tool failed
        assert "missing required 'name'" in error_msg  # What's wrong
        assert "Tool call" in error_msg  # Context
        print("✓ test_clear_error_messages passed")


if __name__ == "__main__":
    try:
        test_valid_tool_calls()
        test_empty_tool_list()
        test_missing_name_field()
        test_empty_name_field()
        test_invalid_name_type()
        test_invalid_args_type()
        test_invalid_tool_type()
        test_none_args_converts_to_empty_dict()
        test_missing_args_field()
        test_multiple_tools_with_one_invalid()
        test_clear_error_messages()
        print("\n✅ All tool call validation tests passed!")
    except AssertionError as e:
        print(f"\n❌ Test failed: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
