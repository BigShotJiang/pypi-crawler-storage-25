#!/usr/bin/env python3
"""Test LLM-based target matching for evaluator."""

import sys
from agents.evaluator import _match_target_modules_with_llm


def test_exact_substring_match():
    """Test exact substring matching fallback."""
    modules = [
        {"name": "agents/reader.py", "module_kind": "agentic", "structure_type": "module"},
        {"name": "agents/coder.py", "module_kind": "genai", "structure_type": "module"},
        {"name": "agents/executor.py", "module_kind": "agentic", "structure_type": "module"},
    ]

    result = _match_target_modules_with_llm("reader", modules)
    assert len(result) == 1
    assert result[0]["name"] == "agents/reader.py"
    print("✓ test_exact_substring_match passed")


def test_no_matches():
    """Test when target doesn't match any modules."""
    modules = [
        {"name": "agents/reader.py", "module_kind": "agentic", "structure_type": "module"},
        {"name": "agents/coder.py", "module_kind": "genai", "structure_type": "module"},
    ]

    result = _match_target_modules_with_llm("nonexistent_agent", modules)
    # Should return empty on LLM mismatch, or use fallback
    assert isinstance(result, list)
    print("✓ test_no_matches passed")


def test_empty_modules_list():
    """Test with empty modules list."""
    result = _match_target_modules_with_llm("reader", [])
    assert len(result) == 0
    print("✓ test_empty_modules_list passed")


def test_case_insensitive_match():
    """Test case-insensitive matching."""
    modules = [
        {"name": "agents/Reader.py", "module_kind": "agentic", "structure_type": "module"},
        {"name": "agents/Coder.py", "module_kind": "genai", "structure_type": "module"},
    ]

    result = _match_target_modules_with_llm("READER", modules)
    assert len(result) >= 1
    assert any("Reader" in m["name"] for m in result)
    print("✓ test_case_insensitive_match passed")


def test_multiple_matches():
    """Test returning multiple matching modules."""
    modules = [
        {"name": "agents/reader.py", "module_kind": "agentic", "structure_type": "module"},
        {"name": "search_agent.py", "module_kind": "agentic", "structure_type": "module"},
        {"name": "agents/coder.py", "module_kind": "genai", "structure_type": "module"},
    ]

    # This would test LLM's ability to match multiple modules for "search"
    # But we'll test with simple substring to avoid LLM API call in test
    result = _match_target_modules_with_llm("agent", modules)
    # Should match reader and search_agent through fallback
    assert len(result) >= 1
    print("✓ test_multiple_matches passed")


if __name__ == "__main__":
    try:
        test_exact_substring_match()
        test_no_matches()
        test_empty_modules_list()
        test_case_insensitive_match()
        test_multiple_matches()
        print("\n✅ All target matching tests passed!")
    except AssertionError as e:
        print(f"\n❌ Test failed: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
