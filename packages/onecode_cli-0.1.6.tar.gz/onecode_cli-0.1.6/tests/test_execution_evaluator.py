#!/usr/bin/env python3
"""Test execution-based evaluator."""

import sys
import asyncio
from eval.execution_evaluator import (
    ExecutionBasedEvaluator,
    ExecutionResult,
    create_execution_evaluator,
)
from eval.golden_dataset_generator import GoldenDataset


def test_execution_result_creation():
    """Test creating ExecutionResult objects."""
    result = ExecutionResult(
        question="What is the answer?",
        actual_output="The answer is 42",
        execution_time=0.5,
        error=None,
        success=True,
    )

    assert result.question == "What is the answer?"
    assert result.actual_output == "The answer is 42"
    assert result.execution_time == 0.5
    assert result.error is None
    assert result.success is True

    # Test to_dict
    result_dict = result.to_dict()
    assert result_dict["question"] == "What is the answer?"
    assert result_dict["success"] is True
    print("✓ test_execution_result_creation passed")


def test_execution_result_with_error():
    """Test ExecutionResult with error."""
    result = ExecutionResult(
        question="Test question",
        actual_output=None,
        execution_time=0.1,
        error="Module not found",
        success=False,
    )

    assert result.success is False
    assert result.error == "Module not found"
    assert result.actual_output is None
    print("✓ test_execution_result_with_error passed")


def test_evaluator_creation():
    """Test creating execution evaluator."""
    evaluator = create_execution_evaluator()
    assert evaluator is not None
    assert evaluator.executor is None  # No executor configured
    print("✓ test_evaluator_creation passed")


def test_similarity_calculation():
    """Test output similarity metric."""
    evaluator = ExecutionBasedEvaluator()

    # Identical strings
    similarity = evaluator._calculate_similarity("hello world", "hello world")
    assert similarity == 1.0

    # No overlap
    similarity = evaluator._calculate_similarity("foo bar", "baz qux")
    assert similarity == 0.0

    # Partial overlap
    similarity = evaluator._calculate_similarity("hello world test", "hello world")
    assert 0 < similarity < 1

    # None actual output
    similarity = evaluator._calculate_similarity(None, "expected")
    assert similarity == 0.0

    # Empty expected
    similarity = evaluator._calculate_similarity("actual", "")
    assert similarity == 0.0

    print("✓ test_similarity_calculation passed")


def test_tool_call_accuracy():
    """Test tool call accuracy metric."""
    evaluator = ExecutionBasedEvaluator()

    # Perfect match
    expected = [{"name": "search"}, {"name": "analyze"}]
    actual = [{"name": "search"}, {"name": "analyze"}]
    accuracy = evaluator._tool_call_accuracy(expected, actual)
    assert accuracy == 1.0

    # Partial match
    expected = [{"name": "search"}, {"name": "analyze"}]
    actual = [{"name": "search"}]
    accuracy = evaluator._tool_call_accuracy(expected, actual)
    assert accuracy == 0.5

    # No match
    expected = [{"name": "search"}]
    actual = [{"name": "fetch"}]
    accuracy = evaluator._tool_call_accuracy(expected, actual)
    assert accuracy == 0.0

    # Empty expected
    accuracy = evaluator._tool_call_accuracy([], [])
    assert accuracy == 1.0

    # Empty actual
    accuracy = evaluator._tool_call_accuracy([{"name": "search"}], [])
    assert accuracy == 0.0

    print("✓ test_tool_call_accuracy passed")


def test_extract_tool_calls():
    """Test extracting tool calls from output."""
    evaluator = ExecutionBasedEvaluator()

    # JSON format
    import json
    output = json.dumps({"tool_calls": [{"name": "search", "args": {}}]})
    tools = evaluator._extract_tool_calls(output)
    assert len(tools) == 1
    assert tools[0]["name"] == "search"

    # No tool calls in output
    output = "Just a regular response"
    tools = evaluator._extract_tool_calls(output)
    assert tools == []

    # Invalid JSON
    output = "{ invalid json }"
    tools = evaluator._extract_tool_calls(output)
    assert tools == []

    print("✓ test_extract_tool_calls passed")


async def test_evaluate_with_no_executor():
    """Test evaluation when executor is not configured."""
    evaluator = ExecutionBasedEvaluator(executor_agent=None)
    module_info = {
        "name": "test_module",
        "module_kind": "genai",
        "description": "Test module",
    }
    dataset = GoldenDataset(
        module_name="test_module",
        module_kind="genai",
        questions=["Q1", "Q2"],
        contexts=[["C1"], ["C2"]],
        answers=["A1", "A2"],
        ground_truth=["GT1", "GT2"],
    )

    result = await evaluator.evaluate_with_execution(module_info, dataset)
    assert result.module_name == "test_module"
    assert result.module_kind == "genai"
    assert len(result.execution_results) == 0
    assert result.execution_metrics["total_questions"] == 2

    print("✓ test_evaluate_with_no_executor passed")


async def test_evaluation_result_structure():
    """Test structure of evaluation results."""
    evaluator = ExecutionBasedEvaluator()
    module_info = {
        "name": "test_module",
        "module_kind": "agentic",
        "description": "Test module",
        "uses_tools": True,
    }
    dataset = GoldenDataset(
        module_name="test_module",
        module_kind="agentic",
        questions=["Q1"],
        contexts=[["C1"]],
        answers=["A1"],
        ground_truth=["GT1"],
        expected_tool_calls=[[{"name": "search"}]],
        selected_tool_calls=[[{"name": "search"}]],
    )

    result = await evaluator.evaluate_with_execution(module_info, dataset)
    result_dict = result.to_dict()

    assert "module_name" in result_dict
    assert "module_kind" in result_dict
    assert "execution_results" in result_dict
    assert "execution_metrics" in result_dict

    metrics = result_dict["execution_metrics"]
    assert "total_questions" in metrics
    assert "successful_executions" in metrics
    assert "failed_executions" in metrics
    assert "success_rate" in metrics
    assert "average_execution_time" in metrics

    print("✓ test_evaluation_result_structure passed")


def test_execution_result_to_dict():
    """Test ExecutionResult.to_dict() method."""
    result = ExecutionResult(
        question="Test?",
        actual_output="Answer",
        execution_time=1.5,
        error=None,
        actual_tool_calls=[{"name": "tool1"}],
        success=True,
    )

    result_dict = result.to_dict()
    assert isinstance(result_dict, dict)
    assert result_dict["question"] == "Test?"
    assert result_dict["actual_output"] == "Answer"
    assert result_dict["execution_time"] == 1.5
    assert result_dict["error"] is None
    assert result_dict["success"] is True
    assert len(result_dict["actual_tool_calls"]) == 1

    print("✓ test_execution_result_to_dict passed")


if __name__ == "__main__":
    try:
        test_execution_result_creation()
        test_execution_result_with_error()
        test_evaluator_creation()
        test_similarity_calculation()
        test_tool_call_accuracy()
        test_extract_tool_calls()
        test_execution_result_to_dict()

        # Run async tests
        loop = asyncio.run(test_evaluate_with_no_executor())
        asyncio.run(test_evaluation_result_structure())

        print("\n✅ All execution evaluator tests passed!")
    except AssertionError as e:
        print(f"\n❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
