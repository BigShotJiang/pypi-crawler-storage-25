"""Tests for evaluation query parsing logic."""

import pytest
from agents.evaluator import _parse_evaluation_query


class TestQueryParsing:
    """Test query parsing with natural language inputs."""

    def test_answer_accuracy_query(self):
        """Parse query requesting specific metric for specific agent."""
        query = "what is the answer accuracy of summarizer agent?"
        result = _parse_evaluation_query(query)

        assert result["target"].lower() in ("summarizer", "summarizer_agent")
        assert result["metrics"] == ["answer_accuracy"]
        assert result["num_samples"] == 5

    def test_quick_evaluation_query(self):
        """Parse query with 'quick' keyword for few samples."""
        query = "quick evaluation of coder"
        result = _parse_evaluation_query(query)

        assert result["target"].lower() in ("coder", "coder_agent")
        assert result["metrics"] is None  # None = all metrics
        assert result["num_samples"] == 2

    def test_faithfulness_query(self):
        """Parse query requesting faithfulness metric."""
        query = "how faithful is reader?"
        result = _parse_evaluation_query(query)

        assert result["target"].lower() in ("reader", "reader_agent")
        assert result["metrics"] == ["faithfulness"]
        assert result["num_samples"] == 5

    def test_codebase_evaluation_query(self):
        """Parse query for full codebase evaluation."""
        query = "evaluate the codebase"
        result = _parse_evaluation_query(query)

        assert result["target"].lower() == "codebase"
        assert result["metrics"] is None  # None = all metrics
        assert result["num_samples"] == 5

    def test_comprehensive_groundedness_query(self):
        """Parse comprehensive query with specific metric."""
        query = "comprehensive evaluation of supervisor focusing on groundedness"
        result = _parse_evaluation_query(query)

        assert result["target"].lower() in ("supervisor", "supervisor_agent")
        assert result["metrics"] == ["response_groundedness"]
        assert result["num_samples"] == 10

    def test_tool_call_f1_query(self):
        """Parse query requesting tool call F1 metric."""
        query = "what is the tool call f1 of executor?"
        result = _parse_evaluation_query(query)

        assert result["target"].lower() in ("executor", "executor_agent")
        assert result["metrics"] == ["tool_call_f1"]
        assert result["num_samples"] == 5

    def test_intent_based_agent_selection(self):
        """Parse query that describes what an agent does (intent-based)."""
        query = "evaluate the code writing agent"
        result = _parse_evaluation_query(query)

        # "code writing agent" should map to "coder"
        assert "coder" in result["target"].lower()
        assert result["metrics"] is None  # None = all metrics
        assert result["num_samples"] == 5

    def test_agent_function_description(self):
        """Parse query describing agent functionality."""
        query = "which agent is best at finding code patterns?"
        result = _parse_evaluation_query(query)

        # "finding code patterns" should map to "search" or "reader"
        target = result["target"].lower()
        assert target in ["search", "reader", "search_agent", "reader_agent"]
