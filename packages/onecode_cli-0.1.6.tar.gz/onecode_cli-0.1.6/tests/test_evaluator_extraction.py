#!/usr/bin/env python3
"""Test module extraction robustness."""

import sys
from agents.evaluator import _extract_modules_from_analysis


def test_extraction_basic():
    """Test extraction with normal output format."""
    output = """
================================================================================
MODULE/AGENT ANALYSIS REPORT
================================================================================

Total Modules/Agents: 2

By Module Kind:
  - agentic: 1
  - genai: 1

--------------------------------------------------------------------------------
DETAILED LISTING
--------------------------------------------------------------------------------

1. agents/reader.py
   Structure: module
   Module Kind: agentic
   Level: top-level
   Description: Semantic code search

2. agents/summarizer.py
   Structure: module
   Module Kind: genai
   Level: top-level
   Description: Content summarization

================================================================================
"""
    modules = _extract_modules_from_analysis(output)
    assert len(modules) == 2
    assert modules[0]["name"] == "agents/reader.py"
    assert modules[0]["module_kind"] == "agentic"
    assert modules[1]["name"] == "agents/summarizer.py"
    assert modules[1]["module_kind"] == "genai"
    print("✓ test_extraction_basic passed")


def test_extraction_with_extra_whitespace():
    """Test extraction tolerates extra whitespace."""
    output = """
================================================================================
DETAILED LISTING
================================================================================

1.   agents/coder.py
   Structure:   module
   Module Kind:   agentic
   Level:   top-level

2. agents/executor.py
   Structure: module
   Module Kind: agentic

================================================================================
"""
    modules = _extract_modules_from_analysis(output)
    assert len(modules) == 2
    assert modules[0]["name"] == "agents/coder.py"
    assert modules[0]["module_kind"] == "agentic"
    assert modules[1]["name"] == "agents/executor.py"
    print("✓ test_extraction_with_extra_whitespace passed")


def test_extraction_missing_kind():
    """Test extraction skips modules without Module Kind."""
    output = """
================================================================================
DETAILED LISTING
================================================================================

1. agents/reader.py
   Structure: module
   Module Kind: agentic
   Level: top-level

2. agents/incomplete.py
   Structure: module
   Level: top-level

3. agents/coder.py
   Structure: module
   Module Kind: genai
   Level: top-level

================================================================================
"""
    modules = _extract_modules_from_analysis(output)
    assert len(modules) == 2
    assert modules[0]["name"] == "agents/reader.py"
    assert modules[1]["name"] == "agents/coder.py"
    print("✓ test_extraction_missing_kind passed")


def test_extraction_empty_output():
    """Test extraction handles empty output gracefully."""
    output = ""
    modules = _extract_modules_from_analysis(output)
    assert len(modules) == 0
    print("✓ test_extraction_empty_output passed")


def test_extraction_no_listing_section():
    """Test extraction handles missing DETAILED LISTING section."""
    output = """
================================================================================
MODULE/AGENT ANALYSIS REPORT
================================================================================

Total Modules/Agents: 2

By Module Kind:
  - agentic: 1
  - genai: 1
"""
    modules = _extract_modules_from_analysis(output)
    assert len(modules) == 0
    print("✓ test_extraction_no_listing_section passed")


def test_extraction_class_based_modules():
    """Test extraction of class-based modules."""
    output = """
================================================================================
DETAILED LISTING
================================================================================

1. ReaderAgent
   Structure: class
   Module Kind: agentic
   Level: component
   Methods: 5

2. SummarizerAgent
   Structure: class
   Module Kind: genai
   Level: component
   Methods: 3

================================================================================
"""
    modules = _extract_modules_from_analysis(output)
    assert len(modules) == 2
    assert modules[0]["name"] == "ReaderAgent"
    assert modules[0]["structure_type"] == "class"
    assert modules[1]["name"] == "SummarizerAgent"
    print("✓ test_extraction_class_based_modules passed")


def test_extraction_field_case_insensitivity():
    """Test extraction handles field name case variations."""
    output = """
================================================================================
DETAILED LISTING
================================================================================

1. agents/reader.py
   Structure: module
   MODULE KIND: agentic
   LEVEL: top-level

================================================================================
"""
    modules = _extract_modules_from_analysis(output)
    assert len(modules) == 1
    assert modules[0]["module_kind"] == "agentic"
    print("✓ test_extraction_field_case_insensitivity passed")


if __name__ == "__main__":
    try:
        test_extraction_basic()
        test_extraction_with_extra_whitespace()
        test_extraction_missing_kind()
        test_extraction_empty_output()
        test_extraction_no_listing_section()
        test_extraction_class_based_modules()
        test_extraction_field_case_insensitivity()
        print("\n✅ All tests passed!")
    except AssertionError as e:
        print(f"\n❌ Test failed: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
