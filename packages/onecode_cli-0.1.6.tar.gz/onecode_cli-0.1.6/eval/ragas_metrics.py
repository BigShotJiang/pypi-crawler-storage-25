"""RAGAS metrics evaluator — computes evaluation metrics using RAGAS framework."""

import asyncio
import os
from typing import Optional
import config
from openai import AsyncOpenAI
from anthropic import AsyncAnthropic

from ragas.metrics.collections import (
    ContextRelevance,
    Faithfulness,
    AnswerRelevancy,
    ContextPrecision,
    ContextRecall,
    AgentGoalAccuracyWithoutReference,
    ToolCallF1,
    AnswerAccuracy,
    ResponseGroundedness,
)
from ragas.llms import llm_factory
from ragas.embeddings.base import embedding_factory
from ragas.messages import HumanMessage, AIMessage, ToolCall


class RAGASMetricsEvaluator:
    """
    Evaluates modules using RAGAS framework metrics.

    Metrics computed:
    - GenAI modules: context_relevance, faithfulness, hallucination, answer_relevancy,
                     context_precision, context_recall, answer_accuracy, response_groundedness
    - Agentic modules: above + agent_goal_accuracy, tool_call_f1
    """

    def __init__(
        self,
        llm_model: str = None,
        embeddings_model: str = "text-embedding-3-small",
    ):
        """
        Initialize RAGAS evaluator.

        Args:
            llm_model: LLM model name (defaults to gpt-4o-mini for evaluation)
            embeddings_model: Embeddings model name
        """
        # Use gpt-4o-mini for all evaluation (independent of user's configured model)
        self.llm_model = llm_model or "gpt-4o-mini"
        self.embeddings_model = embeddings_model
        self.llm = None
        self.embeddings = None
        self.llm_http_client = None
        self.embeddings_http_client = None
        self._initialize_clients()

    def _initialize_clients(self):
        """Initialize async LLM and embeddings clients with connection pooling."""
        try:
            # Initialize async LLM with proper client instance and connection pooling
            client = None
            if "gpt" in self.llm_model.lower():
                api_key = os.getenv("OPENAI_API_KEY")
                if api_key:
                    from httpx import AsyncClient
                    self.llm_http_client = AsyncClient(
                        limits=__import__('httpx').Limits(
                            max_connections=100,
                            max_keepalive_connections=20
                        ),
                        timeout=60.0
                    )
                    client = AsyncOpenAI(api_key=api_key, http_client=self.llm_http_client)
            elif "claude" in self.llm_model.lower():
                api_key = os.getenv("ANTHROPIC_API_KEY")
                if api_key:
                    from httpx import AsyncClient
                    self.llm_http_client = AsyncClient(
                        limits=__import__('httpx').Limits(
                            max_connections=100,
                            max_keepalive_connections=20
                        ),
                        timeout=60.0
                    )
                    client = AsyncAnthropic(api_key=api_key, http_client=self.llm_http_client)

            if client:
                self.llm = llm_factory(self.llm_model, client=client)
            else:
                self.llm = None

            # Initialize async embeddings (always OpenAI) with connection pooling
            embeddings_api_key = os.getenv("OPENAI_API_KEY")
            if embeddings_api_key:
                from httpx import AsyncClient
                self.embeddings_http_client = AsyncClient(
                    limits=__import__('httpx').Limits(
                        max_connections=100,
                        max_keepalive_connections=20
                    ),
                    timeout=60.0
                )
                embeddings_client = AsyncOpenAI(api_key=embeddings_api_key, http_client=self.embeddings_http_client)
                # Add provider prefix for RAGAS
                model_name = (
                    f"openai/{self.embeddings_model}"
                    if not self.embeddings_model.startswith("openai/")
                    else self.embeddings_model
                )
                self.embeddings = embedding_factory(
                    model_name,
                    client=embeddings_client,
                )
            else:
                self.embeddings = None
        except Exception as e:
            print(f"[Warning] Failed to initialize RAGAS clients: {e}")
            self.llm = None
            self.embeddings = None

    async def close(self):
        """Close async HTTP clients to clean up resources."""
        try:
            if self.llm_http_client:
                await self.llm_http_client.aclose()
                self.llm_http_client = None
            if self.embeddings_http_client:
                await self.embeddings_http_client.aclose()
                self.embeddings_http_client = None
        except Exception as e:
            print(f"[Warning] Failed to close RAGAS http clients: {e}")

    def _batch_samples(self, samples: list, batch_size: int = 3) -> list[list]:
        """Split samples into batches for concurrent processing."""
        return [samples[i:i + batch_size] for i in range(0, len(samples), batch_size)]

    async def _evaluate_sample_genai(self, metrics_map: dict, question: str, context_list: list, answer: str, reference: str) -> dict:
        """Evaluate a single sample with all requested metrics concurrently."""
        sample_results = {k: None for k in ["context_relevance", "faithfulness", "answer_relevancy", "context_precision", "context_recall", "answer_accuracy", "response_groundedness"]}

        # Build list of concurrent metric tasks
        tasks = []
        task_names = []

        if "context_relevance" in metrics_map:
            tasks.append(metrics_map["context_relevance"].ascore(user_input=question, retrieved_contexts=context_list))
            task_names.append("context_relevance")
        if "faithfulness" in metrics_map:
            tasks.append(metrics_map["faithfulness"].ascore(user_input=question, response=answer, retrieved_contexts=context_list))
            task_names.append("faithfulness")
        if "answer_relevancy" in metrics_map:
            tasks.append(metrics_map["answer_relevancy"].ascore(user_input=question, response=answer))
            task_names.append("answer_relevancy")
        if "context_precision" in metrics_map:
            tasks.append(metrics_map["context_precision"].ascore(user_input=question, reference=reference, retrieved_contexts=context_list))
            task_names.append("context_precision")
        if "context_recall" in metrics_map:
            tasks.append(metrics_map["context_recall"].ascore(user_input=question, reference=reference, retrieved_contexts=context_list))
            task_names.append("context_recall")
        if "answer_accuracy" in metrics_map:
            tasks.append(metrics_map["answer_accuracy"].ascore(user_input=question, response=answer, reference=reference))
            task_names.append("answer_accuracy")
        if "response_groundedness" in metrics_map:
            tasks.append(metrics_map["response_groundedness"].ascore(response=answer, retrieved_contexts=context_list))
            task_names.append("response_groundedness")

        # Run all metric computations concurrently
        scores = await asyncio.gather(*tasks, return_exceptions=True) if tasks else []

        # Process results
        for task_name, score in zip(task_names, scores):
            if isinstance(score, Exception):
                sample_results[task_name] = None
            else:
                sample_results[task_name] = score.value if hasattr(score, "value") else score

        return sample_results

    async def evaluate_genai_module(
        self,
        questions: list[str],
        contexts: list[list[str]],
        answers: list[str],
        ground_truth: list[str],
        requested_metrics: Optional[list[str]] = None,
    ) -> dict:
        """
        Evaluate GenAI module using RAGAS metrics.

        Args:
            questions: List of input questions
            contexts: List of retrieved contexts (one list per question)
            answers: List of generated answers
            ground_truth: List of ground truth references

        Returns:
            Dictionary with metric scores:
            - context_relevance: How relevant is the context to the question
            - faithfulness: How faithful is answer to context
            - answer_relevancy: How relevant answer is to question
            - context_precision: How much context is relevant
            - context_recall: How much of relevant context is retrieved
        """
        if not self.llm or not self.embeddings:
            print("[Warning] RAGAS clients not initialized")
            return self._empty_genai_metrics()

        try:
            # Determine which metrics to compute (None = all metrics)
            metrics_to_compute = set(requested_metrics) if requested_metrics else None

            # Initialize only requested metrics (or all if none specified)
            metrics_map = {}
            if metrics_to_compute is None or "context_relevance" in metrics_to_compute:
                metrics_map["context_relevance"] = ContextRelevance(llm=self.llm)
            if metrics_to_compute is None or "faithfulness" in metrics_to_compute or "hallucination" in metrics_to_compute:
                metrics_map["faithfulness"] = Faithfulness(llm=self.llm)
            if metrics_to_compute is None or "answer_relevancy" in metrics_to_compute:
                metrics_map["answer_relevancy"] = AnswerRelevancy(llm=self.llm, embeddings=self.embeddings)
            if metrics_to_compute is None or "context_precision" in metrics_to_compute:
                metrics_map["context_precision"] = ContextPrecision(llm=self.llm)
            if metrics_to_compute is None or "context_recall" in metrics_to_compute:
                metrics_map["context_recall"] = ContextRecall(llm=self.llm)
            if metrics_to_compute is None or "answer_accuracy" in metrics_to_compute:
                metrics_map["answer_accuracy"] = AnswerAccuracy(llm=self.llm)
            if metrics_to_compute is None or "response_groundedness" in metrics_to_compute:
                metrics_map["response_groundedness"] = ResponseGroundedness(llm=self.llm)

            results = {k: [] for k in ["context_relevance", "faithfulness", "hallucination", "answer_relevancy", "context_precision", "context_recall", "answer_accuracy", "response_groundedness"]}

            # Prepare sample batches for concurrent processing
            samples = list(zip(questions, contexts, answers, ground_truth))
            sample_batches = self._batch_samples(samples, batch_size=3)

            # Process samples in batches concurrently
            for batch in sample_batches:
                # Create tasks for all samples in this batch
                batch_tasks = [
                    self._evaluate_sample_genai(metrics_map, q, ctx, ans, ref)
                    for q, ctx, ans, ref in batch
                ]

                # Wait for all samples in this batch to complete
                try:
                    batch_results = await asyncio.gather(*batch_tasks, return_exceptions=True)

                    # Aggregate results from batch
                    for sample_result in batch_results:
                        if isinstance(sample_result, Exception):
                            for key in results:
                                results[key].append(None)
                        else:
                            for key in results:
                                if key == "hallucination":
                                    faith_val = sample_result.get("faithfulness")
                                    results[key].append(1 - faith_val if faith_val is not None else None)
                                else:
                                    results[key].append(sample_result.get(key))
                except Exception as e:
                    print(f"[Warning] Failed to process batch: {e}")
                    for _ in batch:
                        for key in results:
                            results[key].append(None)

            # Build return dict with computed metrics
            ret = {}
            for metric_key in results.keys():
                ret[f"{metric_key}_avg"] = self._safe_mean(results[metric_key])
                ret[f"{metric_key}_scores"] = results[metric_key]
            return ret

        except Exception as e:
            print(f"[Warning] Failed to evaluate GenAI module: {e}")
            return self._empty_genai_metrics()

    async def _evaluate_sample_agentic(self, metrics_map: dict, question: str, context_list: list, answer: str, reference: str, expected_tools: list, selected_tools: list) -> dict:
        """Evaluate a single agentic sample with all requested metrics concurrently."""
        sample_results = {k: None for k in ["context_relevance", "faithfulness", "answer_relevancy", "context_precision", "context_recall", "agent_goal_accuracy", "tool_call_f1", "answer_accuracy", "response_groundedness"]}

        # Validate and convert tool calls
        try:
            selected_tool_calls = self._convert_to_tool_calls(selected_tools)
        except ValueError as e:
            print(f"[evaluator] Warning: Invalid selected tool calls: {e}")
            return sample_results  # Return all None on tool call validation failure

        # Build agent conversation trace
        user_input = [
            HumanMessage(content=question),
            AIMessage(
                content=answer,
                tool_calls=selected_tool_calls,
            ),
        ]

        # Build list of concurrent metric tasks
        tasks = []
        task_names = []

        if "context_relevance" in metrics_map:
            tasks.append(metrics_map["context_relevance"].ascore(user_input=question, retrieved_contexts=context_list))
            task_names.append("context_relevance")
        if "faithfulness" in metrics_map:
            tasks.append(metrics_map["faithfulness"].ascore(user_input=question, response=answer, retrieved_contexts=context_list))
            task_names.append("faithfulness")
        if "answer_relevancy" in metrics_map:
            tasks.append(metrics_map["answer_relevancy"].ascore(user_input=question, response=answer))
            task_names.append("answer_relevancy")
        if "context_precision" in metrics_map:
            tasks.append(metrics_map["context_precision"].ascore(user_input=question, reference=reference, retrieved_contexts=context_list))
            task_names.append("context_precision")
        if "context_recall" in metrics_map:
            tasks.append(metrics_map["context_recall"].ascore(user_input=question, reference=reference, retrieved_contexts=context_list))
            task_names.append("context_recall")
        if "agent_goal_accuracy" in metrics_map:
            tasks.append(metrics_map["agent_goal_accuracy"].ascore(user_input=user_input))
            task_names.append("agent_goal_accuracy")
        if "tool_call_f1" in metrics_map:
            try:
                expected_tool_calls = self._convert_to_tool_calls(expected_tools)
                tasks.append(metrics_map["tool_call_f1"].ascore(user_input=user_input, reference_tool_calls=expected_tool_calls))
                task_names.append("tool_call_f1")
            except ValueError as e:
                print(f"[evaluator] Warning: Invalid expected tool calls for tool_call_f1 metric: {e}")
                # Skip tool_call_f1 metric on validation error
        if "answer_accuracy" in metrics_map:
            tasks.append(metrics_map["answer_accuracy"].ascore(user_input=question, response=answer, reference=reference))
            task_names.append("answer_accuracy")
        if "response_groundedness" in metrics_map:
            tasks.append(metrics_map["response_groundedness"].ascore(response=answer, retrieved_contexts=context_list))
            task_names.append("response_groundedness")

        # Run all metric computations concurrently
        scores = await asyncio.gather(*tasks, return_exceptions=True) if tasks else []

        # Process results
        for task_name, score in zip(task_names, scores):
            if isinstance(score, Exception):
                sample_results[task_name] = None
            else:
                sample_results[task_name] = score.value if hasattr(score, "value") else score

        return sample_results

    async def evaluate_agentic_module(
        self,
        questions: list[str],
        contexts: list[list[str]],
        answers: list[str],
        ground_truth: list[str],
        expected_tool_calls: list[list],
        selected_tool_calls: list[list],
        requested_metrics: Optional[list[str]] = None,
    ) -> dict:
        """
        Evaluate Agentic module using RAGAS metrics + agent-specific metrics.

        Args:
            questions: List of input questions
            contexts: List of retrieved contexts
            answers: List of generated answers
            ground_truth: List of ground truth references
            expected_tool_calls: List of expected tool call sequences
            selected_tool_calls: List of selected tool call sequences

        Returns:
            Dictionary with metric scores including:
            - GenAI metrics (context_relevance, faithfulness, etc.)
            - agent_goal_accuracy: How accurately agent achieved goal
            - tool_call_f1: F1 score of tool calls used
        """
        if not self.llm or not self.embeddings:
            print("[Warning] RAGAS clients not initialized")
            return self._empty_agentic_metrics()

        try:
            # Determine which metrics to compute (None = all metrics)
            metrics_to_compute = set(requested_metrics) if requested_metrics else None

            # Initialize only requested metrics (or all if none specified)
            metrics_map = {}
            if metrics_to_compute is None or "context_relevance" in metrics_to_compute:
                metrics_map["context_relevance"] = ContextRelevance(llm=self.llm)
            if metrics_to_compute is None or "faithfulness" in metrics_to_compute or "hallucination" in metrics_to_compute:
                metrics_map["faithfulness"] = Faithfulness(llm=self.llm)
            if metrics_to_compute is None or "answer_relevancy" in metrics_to_compute:
                metrics_map["answer_relevancy"] = AnswerRelevancy(llm=self.llm, embeddings=self.embeddings)
            if metrics_to_compute is None or "context_precision" in metrics_to_compute:
                metrics_map["context_precision"] = ContextPrecision(llm=self.llm)
            if metrics_to_compute is None or "context_recall" in metrics_to_compute:
                metrics_map["context_recall"] = ContextRecall(llm=self.llm)
            if metrics_to_compute is None or "agent_goal_accuracy" in metrics_to_compute:
                metrics_map["agent_goal_accuracy"] = AgentGoalAccuracyWithoutReference(llm=self.llm)
            if metrics_to_compute is None or "tool_call_f1" in metrics_to_compute:
                metrics_map["tool_call_f1"] = ToolCallF1()
            if metrics_to_compute is None or "answer_accuracy" in metrics_to_compute:
                metrics_map["answer_accuracy"] = AnswerAccuracy(llm=self.llm)
            if metrics_to_compute is None or "response_groundedness" in metrics_to_compute:
                metrics_map["response_groundedness"] = ResponseGroundedness(llm=self.llm)

            results = {k: [] for k in ["context_relevance", "faithfulness", "hallucination", "answer_relevancy", "context_precision", "context_recall", "agent_goal_accuracy", "tool_call_f1", "answer_accuracy", "response_groundedness"]}

            # Prepare sample batches for concurrent processing
            samples = list(zip(questions, contexts, answers, ground_truth, expected_tool_calls, selected_tool_calls))
            sample_batches = self._batch_samples(samples, batch_size=3)

            # Process samples in batches concurrently
            for batch in sample_batches:
                # Create tasks for all samples in this batch
                batch_tasks = [
                    self._evaluate_sample_agentic(metrics_map, q, ctx, ans, ref, exp_tools, sel_tools)
                    for q, ctx, ans, ref, exp_tools, sel_tools in batch
                ]

                # Wait for all samples in this batch to complete
                try:
                    batch_results = await asyncio.gather(*batch_tasks, return_exceptions=True)

                    # Aggregate results from batch
                    for sample_result in batch_results:
                        if isinstance(sample_result, Exception):
                            for key in results:
                                results[key].append(None)
                        else:
                            for key in results:
                                if key == "hallucination":
                                    faith_val = sample_result.get("faithfulness")
                                    results[key].append(1 - faith_val if faith_val is not None else None)
                                else:
                                    results[key].append(sample_result.get(key))
                except Exception as e:
                    print(f"[Warning] Failed to process batch: {e}")
                    for _ in batch:
                        for key in results:
                            results[key].append(None)

            # Build return dict with computed metrics
            ret = {}
            for metric_key in results.keys():
                ret[f"{metric_key}_avg"] = self._safe_mean(results[metric_key])
                ret[f"{metric_key}_scores"] = results[metric_key]
            return ret

        except Exception as e:
            print(f"[Warning] Failed to evaluate agentic module: {e}")
            return self._empty_agentic_metrics()

    def _convert_to_tool_calls(self, tool_list: list) -> list:
        """
        Convert tool call dicts to RAGAS ToolCall objects with validation.

        Validates each tool has required fields (name, args) and proper types.
        Raises ValueError on invalid structure rather than silently creating bad objects.
        """
        if not tool_list:
            return []

        tool_calls = []
        for idx, tool_dict in enumerate(tool_list):
            # If already a ToolCall object, use as-is
            if isinstance(tool_dict, ToolCall):
                tool_calls.append(tool_dict)
                continue

            # If not a dict, raise clear error
            if not isinstance(tool_dict, dict):
                raise ValueError(
                    f"Tool call at index {idx} must be dict or ToolCall object, "
                    f"got {type(tool_dict).__name__}: {tool_dict}"
                )

            # Validate required fields
            name = tool_dict.get("name")
            if not name:
                raise ValueError(
                    f"Tool call at index {idx} missing required 'name' field. "
                    f"Got: {tool_dict}"
                )

            if not isinstance(name, str):
                raise ValueError(
                    f"Tool call at index {idx} has invalid 'name' type. "
                    f"Expected str, got {type(name).__name__}: {name}"
                )

            # Validate args field
            args = tool_dict.get("args", {})
            if args is None:
                args = {}
            elif not isinstance(args, dict):
                raise ValueError(
                    f"Tool call at index {idx} '{name}' has invalid 'args' type. "
                    f"Expected dict or None, got {type(args).__name__}: {args}"
                )

            # Create ToolCall with validated data
            try:
                tool_call = ToolCall(name=name, args=args)
                tool_calls.append(tool_call)
            except Exception as e:
                raise ValueError(
                    f"Failed to create ToolCall at index {idx} for tool '{name}': {e}"
                )

        return tool_calls

    @staticmethod
    def _safe_mean(values: list) -> Optional[float]:
        """Safely compute mean of values, handling None entries."""
        valid_values = [v for v in values if v is not None]
        if not valid_values:
            return None
        return sum(valid_values) / len(valid_values)

    @staticmethod
    def _empty_genai_metrics() -> dict:
        """Return empty GenAI metrics dict."""
        return {
            "context_relevance_avg": None,
            "context_relevance_scores": [],
            "faithfulness_avg": None,
            "faithfulness_scores": [],
            "hallucination_avg": None,
            "hallucination_scores": [],
            "answer_relevancy_avg": None,
            "answer_relevancy_scores": [],
            "context_precision_avg": None,
            "context_precision_scores": [],
            "context_recall_avg": None,
            "context_recall_scores": [],
            "answer_accuracy_avg": None,
            "answer_accuracy_scores": [],
            "response_groundedness_avg": None,
            "response_groundedness_scores": [],
        }

    @staticmethod
    def _empty_agentic_metrics() -> dict:
        """Return empty agentic metrics dict."""
        metrics = RAGASMetricsEvaluator._empty_genai_metrics()
        metrics.update(
            {
                "agent_goal_accuracy_avg": None,
                "agent_goal_accuracy_scores": [],
                "tool_call_f1_avg": None,
                "tool_call_f1_scores": [],
            }
        )
        return metrics


def create_ragas_evaluator(
    llm_model: str = None,
    embeddings_model: str = "text-embedding-3-small",
) -> RAGASMetricsEvaluator:
    """
    Factory function to create RAGAS metrics evaluator.

    Args:
        llm_model: LLM model for metric computation (defaults to gpt-4o-mini for evaluation)
        embeddings_model: Embeddings model

    Returns:
        RAGASMetricsEvaluator instance
    """
    return RAGASMetricsEvaluator(llm_model or "gpt-4o-mini", embeddings_model)
