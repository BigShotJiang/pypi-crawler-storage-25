"""Evaluation module — analyzes and evaluates modules in a codebase."""

from eval.module_analyzer import (
    make_module_analyzer,
    get_modules_structured,
    get_modules_structured_async,
    ModuleInfo,
)
from eval.golden_dataset_generator import (
    generate_golden_dataset,
    generate_datasets_batch,
    generate_golden_dataset_async,
)
from eval.ragas_metrics import create_ragas_evaluator
from eval.execution_evaluator import (
    create_execution_evaluator,
    ExecutionBasedEvaluator,
    ExecutionResult,
    ExecutionEvaluationResult,
)
from eval.actionability import (
    ModuleActionReport,
    build_action_report,
    format_action_report,
)
from eval.results_store import (
    EvalRun,
    save_eval_run,
    load_eval_runs,
    compare_runs,
    rank_modules,
    format_comparison_table,
    format_trend_table,
)

__all__ = [
    "make_module_analyzer",
    "get_modules_structured",
    "get_modules_structured_async",
    "ModuleInfo",
    "generate_golden_dataset",
    "generate_golden_dataset_async",
    "generate_datasets_batch",
    "create_ragas_evaluator",
    "create_execution_evaluator",
    "ExecutionBasedEvaluator",
    "ExecutionResult",
    "ExecutionEvaluationResult",
    "ModuleActionReport",
    "build_action_report",
    "format_action_report",
    "EvalRun",
    "save_eval_run",
    "load_eval_runs",
    "compare_runs",
    "rank_modules",
    "format_comparison_table",
    "format_trend_table",
]
