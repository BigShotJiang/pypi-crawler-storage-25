"""Execution-based evaluator — runs modules with test inputs and captures real outputs."""

import asyncio
import time
import json
from dataclasses import dataclass
from typing import Optional
from eval.golden_dataset_generator import GoldenDataset


@dataclass
class ExecutionResult:
    """Result from executing a module with one test input."""

    question: str
    actual_output: Optional[str]
    execution_time: float
    error: Optional[str]
    actual_tool_calls: list = None
    success: bool = False

    def to_dict(self) -> dict:
        return {
            "question": self.question,
            "actual_output": self.actual_output,
            "execution_time": self.execution_time,
            "error": self.error,
            "actual_tool_calls": self.actual_tool_calls or [],
            "success": self.success,
        }


@dataclass
class ExecutionEvaluationResult:
    """Complete execution-based evaluation results."""

    module_name: str
    module_kind: str
    execution_results: list[ExecutionResult]
    execution_metrics: dict

    def to_dict(self) -> dict:
        return {
            "module_name": self.module_name,
            "module_kind": self.module_kind,
            "execution_results": [r.to_dict() for r in self.execution_results],
            "execution_metrics": self.execution_metrics,
        }


class ExecutionBasedEvaluator:
    """
    Evaluates modules by actually executing them with test inputs.

    Captures real outputs, tool calls, execution times, and errors.
    Compares actual vs expected to assess module quality.
    """

    def __init__(self, executor_agent=None):
        """
        Initialize execution-based evaluator.

        Args:
            executor_agent: OneCode executor agent for running commands/code
        """
        self.executor = executor_agent

    async def evaluate_with_execution(
        self,
        module_info: dict,
        golden_dataset: GoldenDataset,
        module_content: str = "",
    ) -> ExecutionEvaluationResult:
        """
        Execute module with golden dataset questions and capture real outputs.

        Args:
            module_info: Module metadata (name, kind, description)
            golden_dataset: Golden dataset with questions, contexts, answers, ground truth
            module_content: Optional module source code

        Returns:
            ExecutionEvaluationResult with actual outputs and metrics
        """
        execution_results = []
        metrics = {
            "total_questions": len(golden_dataset.questions),
            "successful_executions": 0,
            "failed_executions": 0,
            "average_execution_time": 0,
            "output_similarity_avg": None,
            "tool_call_accuracy": None,
        }

        if not self.executor:
            print("[execution-evaluator] Warning: No executor provided, skipping execution")
            metrics["success_rate"] = 0
            return ExecutionEvaluationResult(
                module_name=module_info["name"],
                module_kind=module_info["module_kind"],
                execution_results=[],
                execution_metrics=metrics,
            )

        # Execute each test case
        execution_times = []
        output_similarities = []
        tool_call_matches = []

        for idx, question in enumerate(golden_dataset.questions):
            result = await self._execute_single(
                module_info, question, idx, golden_dataset.expected_tool_calls
            )
            execution_results.append(result)

            if result.success:
                metrics["successful_executions"] += 1
                execution_times.append(result.execution_time)

                # Calculate output similarity to expected answer
                expected_answer = (
                    golden_dataset.answers[idx]
                    if idx < len(golden_dataset.answers)
                    else ""
                )
                similarity = self._calculate_similarity(
                    result.actual_output, expected_answer
                )
                output_similarities.append(similarity)

                # Check tool call accuracy (agentic modules only)
                if module_info["module_kind"] == "agentic" and golden_dataset.expected_tool_calls:
                    expected_tools = golden_dataset.expected_tool_calls[idx]
                    actual_tools = result.actual_tool_calls or []
                    accuracy = self._tool_call_accuracy(expected_tools, actual_tools)
                    tool_call_matches.append(accuracy)
            else:
                metrics["failed_executions"] += 1

        # Calculate aggregate metrics
        if execution_times:
            metrics["average_execution_time"] = sum(execution_times) / len(execution_times)
        if output_similarities:
            metrics["output_similarity_avg"] = sum(output_similarities) / len(output_similarities)
        if tool_call_matches:
            metrics["tool_call_accuracy"] = sum(tool_call_matches) / len(tool_call_matches)

        # Always calculate success rate
        metrics["success_rate"] = (
            metrics["successful_executions"] / metrics["total_questions"]
            if metrics["total_questions"] > 0
            else 0
        )

        return ExecutionEvaluationResult(
            module_name=module_info["name"],
            module_kind=module_info["module_kind"],
            execution_results=execution_results,
            execution_metrics=metrics,
        )

    async def _execute_single(
        self,
        module_info: dict,
        question: str,
        idx: int,
        expected_tool_calls: Optional[list] = None,
    ) -> ExecutionResult:
        """Execute module with a single question and capture output."""
        start_time = time.time()

        try:
            # Call executor to run the module with the question
            # This is a simplified interface - actual implementation depends on executor
            output = await self._run_module_with_input(
                module_info["name"], question
            )

            elapsed = time.time() - start_time

            return ExecutionResult(
                question=question,
                actual_output=output,
                execution_time=elapsed,
                error=None,
                actual_tool_calls=self._extract_tool_calls(output),
                success=True,
            )

        except Exception as e:
            elapsed = time.time() - start_time
            return ExecutionResult(
                question=question,
                actual_output=None,
                execution_time=elapsed,
                error=str(e),
                success=False,
            )

    async def _run_module_with_input(self, module_name: str, question: str) -> str:
        """
        Execute a module with input and capture output.

        This is a placeholder that would integrate with OneCode's executor.
        Real implementation would:
        1. Locate the module in the codebase
        2. Call its main entry point with the question
        3. Capture stdout/stderr and return value
        """
        if not self.executor:
            raise ValueError("Executor not configured")

        # For now, return mock output
        # TODO: Integrate with actual executor agent
        return f"Executed {module_name} with input: {question}"

    @staticmethod
    def _extract_tool_calls(output: str) -> list:
        """
        Extract tool calls from module output.

        Looks for structured tool call data in output (JSON or special format).
        """
        try:
            # Try to parse as JSON
            if output.startswith("{") and output.endswith("}"):
                data = json.loads(output)
                if "tool_calls" in data:
                    return data["tool_calls"]
        except (json.JSONDecodeError, ValueError):
            pass

        return []

    @staticmethod
    def _calculate_similarity(actual: Optional[str], expected: str) -> float:
        """
        Calculate similarity between actual and expected output.

        Simple implementation using string overlap.
        Range: [0, 1] where 1 is identical.
        """
        if actual is None:
            return 0.0

        if not expected:
            return 1.0 if not actual else 0.0

        # Simple word overlap metric
        actual_words = set(actual.lower().split())
        expected_words = set(expected.lower().split())

        if not expected_words:
            return 0.0

        intersection = len(actual_words & expected_words)
        union = len(actual_words | expected_words)

        return intersection / union if union > 0 else 0.0

    @staticmethod
    def _tool_call_accuracy(expected: list, actual: list) -> float:
        """
        Calculate accuracy of actual tool calls vs expected.

        Considers:
        - Tool name matches
        - Tool call order
        - Arguments match

        Range: [0, 1]
        """
        if not expected:
            return 1.0 if not actual else 0.0

        if not actual:
            return 0.0

        # Simple matching: count how many expected tools were called
        expected_names = [t.get("name") if isinstance(t, dict) else str(t) for t in expected]
        actual_names = [t.get("name") if isinstance(t, dict) else str(t) for t in actual]

        # Check if expected tools are in actual (order-aware)
        matches = 0
        for exp_name in expected_names:
            if exp_name in actual_names:
                matches += 1

        return matches / len(expected_names) if expected_names else 0.0


def create_execution_evaluator(executor_agent=None) -> ExecutionBasedEvaluator:
    """Factory function to create execution-based evaluator."""
    return ExecutionBasedEvaluator(executor_agent=executor_agent)
