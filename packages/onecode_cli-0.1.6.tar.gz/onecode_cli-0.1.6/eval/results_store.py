"""Results storage and comparison — persist evaluation runs and track trends."""

from dataclasses import dataclass, asdict
from pathlib import Path
from datetime import datetime, timezone
import json
from typing import Optional


@dataclass
class EvalRun:
    """Single evaluation run with timestamp and results."""

    run_id: str  # "20260426_093022_summarizer"
    timestamp: str  # ISO 8601
    target: str  # "codebase" | agent name
    results: list[dict]  # from _evaluate_modules
    codebase_root: str = ""


def _get_results_dir(codebase_root: str) -> Path:
    """Get or create eval results directory."""
    results_dir = Path(codebase_root) / ".onecode" / "eval_results"
    results_dir.mkdir(parents=True, exist_ok=True)
    return results_dir


def save_eval_run(codebase_root: str, run: EvalRun) -> Path:
    """
    Save evaluation run to .onecode/eval_results/{run_id}.json.

    Returns path to saved file.
    """
    results_dir = _get_results_dir(codebase_root)
    run_path = results_dir / f"{run.run_id}.json"

    with open(run_path, "w") as f:
        json.dump(asdict(run), f, indent=2)

    return run_path


def load_eval_runs(
    codebase_root: str, target: str = "", limit: int = 10
) -> list[EvalRun]:
    """
    Load evaluation runs from .onecode/eval_results/.

    Args:
        codebase_root: Root of codebase
        target: Filter by target (e.g., "summarizer") — empty = all targets
        limit: Max number of runs to return (most recent first)

    Returns:
        List of EvalRun objects, sorted by timestamp descending
    """
    results_dir = _get_results_dir(codebase_root)

    if not results_dir.exists():
        return []

    runs = []
    for run_file in sorted(results_dir.glob("*.json"), reverse=True):
        try:
            with open(run_file) as f:
                data = json.load(f)
                run = EvalRun(
                    run_id=data["run_id"],
                    timestamp=data["timestamp"],
                    target=data["target"],
                    results=data["results"],
                    codebase_root=data.get("codebase_root", ""),
                )

                # Filter by target if specified
                if target and run.target != target:
                    continue

                runs.append(run)

                if len(runs) >= limit:
                    break
        except (json.JSONDecodeError, KeyError):
            continue

    return runs


def compare_runs(current: EvalRun, prior: EvalRun) -> dict:
    """
    Compare two evaluation runs and compute deltas.

    Returns: {module_name: {metric: {current, prior, delta, regression}}}
    where regression = True if delta < -0.1
    """
    comparison = {}

    # Build map of module results for quick lookup
    prior_results = {r["name"]: r for r in prior.results if r["status"] == "success"}
    current_results = {
        r["name"]: r for r in current.results if r["status"] == "success"
    }

    # Compare each module in current results
    for module_name, current_result in current_results.items():
        if module_name not in prior_results:
            continue  # Skip modules not in prior run

        prior_result = prior_results[module_name]
        current_metrics = current_result.get("metrics", {})
        prior_metrics = prior_result.get("metrics", {})

        module_comparison = {}

        # Compare each _avg metric
        for key in current_metrics.keys():
            if not key.endswith("_avg"):
                continue

            metric_name = key[:-4]
            current_score = current_metrics.get(key)
            prior_score = prior_metrics.get(key)

            if current_score is None or prior_score is None:
                continue

            delta = current_score - prior_score
            regression = delta < -0.1

            module_comparison[metric_name] = {
                "current": current_score,
                "prior": prior_score,
                "delta": delta,
                "regression": regression,
            }

        if module_comparison:
            comparison[module_name] = module_comparison

    return comparison


def rank_modules(run: EvalRun, metric: str) -> list[tuple[str, float]]:
    """
    Rank modules by a specific metric in descending order.

    Returns: [(module_name, score), ...]
    """
    rankings = []

    for result in run.results:
        if result["status"] != "success":
            continue

        metrics = result.get("metrics", {})
        score = metrics.get(f"{metric}_avg")

        if score is not None:
            rankings.append((result["name"], score))

    # Sort by score descending
    rankings.sort(key=lambda x: x[1], reverse=True)
    return rankings


def format_comparison_table(comparison: dict) -> str:
    """Format comparison dict as a readable table."""
    if not comparison:
        return ""

    lines = ["\n" + "-" * 80, "COMPARISON WITH PRIOR RUN", "-" * 80]

    for module_name in sorted(comparison.keys()):
        module_comp = comparison[module_name]
        lines.append(f"\n{module_name}:")

        for metric in sorted(module_comp.keys()):
            info = module_comp[metric]
            current = info["current"]
            prior = info["prior"]
            delta = info["delta"]
            regression = info["regression"]

            delta_str = f"{delta:+.3f}"
            if regression:
                marker = "⚠ REGRESSION"
                delta_str += " ↓"
            else:
                marker = "  "

            lines.append(
                f"   {marker} {metric:25} {prior:.3f} → {current:.3f}  ({delta_str})"
            )

    lines.append("-" * 80)
    return "\n".join(lines)


def format_trend_table(
    runs: list[EvalRun], module_name: str, metric: str
) -> str:
    """Format trend of a metric across multiple runs."""
    if len(runs) < 2:
        return ""

    lines = [
        "\n" + "-" * 80,
        f"TREND: {module_name} — {metric}",
        "-" * 80,
    ]

    for run in reversed(runs):  # oldest first
        results = [r for r in run.results if r["name"] == module_name]
        if not results:
            continue

        result = results[0]
        if result["status"] != "success":
            continue

        score = result.get("metrics", {}).get(f"{metric}_avg")
        if score is None:
            continue

        timestamp = run.timestamp[:10]  # YYYY-MM-DD
        lines.append(f"   {timestamp}  {score:.3f}")

    lines.append("-" * 80)
    return "\n".join(lines)
