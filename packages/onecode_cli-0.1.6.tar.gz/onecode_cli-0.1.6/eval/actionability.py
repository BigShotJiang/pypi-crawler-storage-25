"""Actionability Engine — converts raw metrics into actionable insights."""

from dataclasses import dataclass
from typing import Optional
import config
from utils.retry import call_api


# Score bands: (min, max, label)
SCORE_BANDS = [
    (0.85, 1.00, "Good"),
    (0.70, 0.85, "Acceptable"),
    (0.40, 0.70, "Needs Improvement"),
    (0.00, 0.40, "Critical"),
]

# Baseline thresholds per metric — below these means "failing"
BASELINE_THRESHOLDS = {
    "faithfulness": 0.70,
    "answer_relevancy": 0.70,
    "context_precision": 0.65,
    "context_recall": 0.65,
    "answer_accuracy": 0.70,
    "response_groundedness": 0.65,
    "agent_goal_accuracy": 0.65,
    "tool_call_f1": 0.60,
}

# Static guidance: what low/high scores mean and what to do
METRIC_GUIDANCE = {
    "faithfulness": {
        "label": "Faithfulness",
        "low": "Module fabricates information not present in context. Improve context injection in the system prompt and add explicit grounding instructions.",
        "high": "Module stays grounded in retrieved context.",
    },
    "hallucination": {
        "label": "Hallucination",
        "low": "Low hallucination rate — module is generating well-grounded responses.",
        "high": "Module is hallucinating frequently. Same fix as faithfulness: improve context injection.",
    },
    "answer_relevancy": {
        "label": "Answer Relevancy",
        "low": "Answers drift off-topic. Review system prompt output constraints and add examples of on-target responses.",
        "high": "Answers are relevant to the questions asked.",
    },
    "context_precision": {
        "label": "Context Precision",
        "low": "Too many irrelevant chunks retrieved. Tune similarity threshold or add post-retrieval filtering.",
        "high": "Retrieved context is precise and relevant.",
    },
    "context_recall": {
        "label": "Context Recall",
        "low": "Relevant information is being missed. Increase top_k or widen search scope.",
        "high": "Retrieval captures the relevant information.",
    },
    "answer_accuracy": {
        "label": "Answer Accuracy",
        "low": "Answers diverge from ground truth. Review retrieval quality and grounding.",
        "high": "Answers match expected ground truth.",
    },
    "response_groundedness": {
        "label": "Response Groundedness",
        "low": "Responses contain unsupported claims. Add explicit grounding constraints to the system prompt.",
        "high": "Responses are well-grounded in retrieved context.",
    },
    "agent_goal_accuracy": {
        "label": "Agent Goal Accuracy",
        "low": "Agent fails to accomplish stated goals. Review task decomposition logic and tool descriptions.",
        "high": "Agent reliably accomplishes its goals.",
    },
    "tool_call_f1": {
        "label": "Tool Call F1",
        "low": "Wrong tools being selected or called in wrong order. Review tool descriptions and supervisor routing logic.",
        "high": "Agent selects appropriate tools for each task.",
    },
}


@dataclass
class ModuleActionReport:
    """Structured actionability report for a single module."""

    module_name: str
    module_kind: str
    metrics: dict  # raw metrics dict with _avg and _scores keys
    metric_bands: dict[str, str]  # metric -> "Good" | "Acceptable" | ...
    below_threshold: list[str]  # metrics failing baseline
    recommendations: list[str]  # one per failing metric
    llm_analysis: str  # 3-5 sentence synthesis
    worst_samples: list[dict]  # [{"question": q, "metric": m, "score": s}]


def score_band(score: Optional[float]) -> str:
    """Map a score to its band label."""
    if score is None:
        return "No data"
    for lo, hi, label in SCORE_BANDS:
        if lo <= score <= hi:
            return label
    return "Critical"


def below_baseline(metric: str, score: Optional[float]) -> bool:
    """Check if a score is below the baseline threshold for its metric."""
    if score is None:
        return False
    threshold = BASELINE_THRESHOLDS.get(metric, 0.70)
    return score < threshold


def failing_samples(
    metric: str,
    scores: list[Optional[float]],
    questions: list[str],
    threshold: float = 0.5,
) -> list[dict]:
    """
    Identify questions where a metric scored below threshold.

    Returns up to 3 worst samples, sorted by score ascending.
    """
    if not scores or not questions:
        return []

    # Collect samples with scores below threshold
    bad_samples = []
    for idx, score in enumerate(scores):
        if score is not None and score < threshold and idx < len(questions):
            bad_samples.append(
                {
                    "question": questions[idx],
                    "metric": metric,
                    "score": score,
                }
            )

    # Sort by score (worst first) and cap at 3
    bad_samples.sort(key=lambda x: x["score"])
    return bad_samples[:3]


def build_action_report(
    module_name: str,
    module_kind: str,
    module_purpose: str,
    metrics: dict,
    questions: list[str],
) -> ModuleActionReport:
    """
    Build a comprehensive actionability report for a module.

    Args:
        module_name: Name of the module
        module_kind: "agentic" | "genai" | "non-agentic"
        module_purpose: Module description (for LLM analysis)
        metrics: Full metrics dict from RAGASMetricsEvaluator
                 (with _avg and _scores keys)
        questions: List of test questions (parallel to _scores lists)

    Returns:
        ModuleActionReport with bands, failures, recommendations, analysis, worst samples
    """
    # Build metric_bands: metric -> band label
    metric_bands = {}
    metric_keys = set()

    for key in metrics.keys():
        if key.endswith("_avg"):
            metric_name = key[:-4]  # strip "_avg"
            metric_keys.add(metric_name)
            score = metrics.get(key)
            metric_bands[metric_name] = score_band(score)

    # Find metrics below baseline
    below_threshold = []
    for metric in metric_keys:
        score = metrics.get(f"{metric}_avg")
        if below_baseline(metric, score):
            below_threshold.append(metric)

    # Build recommendations from METRIC_GUIDANCE
    recommendations = []
    for metric in below_threshold:
        if metric in METRIC_GUIDANCE:
            recommendations.append(METRIC_GUIDANCE[metric]["low"])

    # Collect worst samples from failing metrics
    worst_samples_set = {}  # question -> worst sample dict (dedup by question)
    for metric in below_threshold:
        scores = metrics.get(f"{metric}_scores", [])
        samples = failing_samples(metric, scores, questions, threshold=0.5)
        for sample in samples:
            q = sample["question"]
            if q not in worst_samples_set or sample["score"] < worst_samples_set[q]["score"]:
                worst_samples_set[q] = sample

    worst_samples = sorted(
        list(worst_samples_set.values()), key=lambda x: x["score"]
    )[:3]

    # Generate LLM analysis
    llm_analysis = generate_llm_analysis(
        module_name, module_kind, module_purpose, metrics, worst_samples
    )

    return ModuleActionReport(
        module_name=module_name,
        module_kind=module_kind,
        metrics=metrics,
        metric_bands=metric_bands,
        below_threshold=below_threshold,
        recommendations=recommendations,
        llm_analysis=llm_analysis,
        worst_samples=worst_samples,
    )


def generate_llm_analysis(
    module_name: str,
    module_kind: str,
    module_purpose: str,
    metrics: dict,
    worst_samples: list[dict],
) -> str:
    """
    Generate a 3-5 sentence LLM analysis of the module's evaluation results.

    Falls back gracefully on error.
    """
    # Format metric scores for prompt
    metric_scores = []
    for key in sorted(metrics.keys()):
        if key.endswith("_avg") and metrics[key] is not None:
            metric_name = key[:-4]
            metric_scores.append(f"{metric_name}: {metrics[key]:.2f}")

    scores_text = ", ".join(metric_scores) if metric_scores else "No metrics"

    # Format worst samples
    worst_text = ""
    if worst_samples:
        worst_text = "\n\nWorst-performing samples:\n"
        for sample in worst_samples[:3]:
            worst_text += f"  • Q: \"{sample['question'][:60]}...\" — {sample['metric']}: {sample['score']:.2f}\n"

    prompt = f"""Analyze the evaluation results for: {module_name}
Purpose: {module_purpose}
Module type: {module_kind}

Scores: {scores_text}
{worst_text}

In 3-5 sentences, explain what these evaluation scores mean and what should be the primary focus for improvement."""

    def call_llm():
        client = config.get_client()
        response = client.chat.completions.create(
            model=config.MODEL,
            max_tokens=300,
            temperature=0,
            messages=[{"role": "user", "content": prompt}],
        )
        return response.choices[0].message.content.strip()

    try:
        return call_api(call_llm)
    except Exception as e:
        print(f"[Warning] LLM analysis failed: {str(e)[:50]}")
        return ""


def format_action_report(report: ModuleActionReport) -> str:
    """Format a ModuleActionReport as human-readable text."""
    lines = [f"\n📊 {report.module_name} ({report.module_kind})"]

    # Show all metrics with scores and bands
    for metric in sorted(report.metric_bands.keys()):
        band = report.metric_bands[metric]
        avg_key = f"{metric}_avg"
        score = report.metrics.get(avg_key)

        if score is None:
            score_str = "N/A"
        else:
            score_str = f"{score:.2f}"

        # Mark below-threshold metrics with ⚠
        marker = "⚠ " if metric in report.below_threshold else "  "
        metric_label = metric.replace("_", " ").title()
        lines.append(f"   {marker}{metric_label:25} {score_str:6} [{band}]")

    # Below-threshold warning
    if report.below_threshold:
        lines.append(
            f"\n   ⚠ Below baseline: {', '.join(report.below_threshold)}"
        )

    # Recommendations
    if report.recommendations:
        lines.append("\n   Recommendations:")
        for rec in report.recommendations:
            lines.append(f"     • {rec}")

    # LLM analysis
    if report.llm_analysis:
        lines.append(f"\n   Analysis:\n     {report.llm_analysis}")

    # Worst samples
    if report.worst_samples:
        lines.append("\n   Worst samples:")
        for sample in report.worst_samples:
            q_preview = sample["question"][:60]
            if len(sample["question"]) > 60:
                q_preview += "..."
            lines.append(
                f"     • \"{q_preview}\" — {sample['metric']}: {sample['score']:.2f}"
            )

    return "\n".join(lines)
