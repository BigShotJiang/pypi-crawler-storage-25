"""Module analyzer — identifies and categorizes modules/agents in a codebase."""

import asyncio
import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import config
from kg.graph import KnowledgeGraph
from utils.retry import call_api


@dataclass
class ModuleInfo:
    """Structured module information."""
    name: str
    structure_type: str  # "module" | "class"
    level: str  # "top-level" | "component"
    module_kind: str  # "agentic" | "genai" | "non-agentic"
    description: str
    uses_llm: bool
    uses_tools: bool
    file_content: str = ""
    methods: int = 0


def make_module_analyzer(kg: KnowledgeGraph):
    """Factory function that returns a module analyzer function."""

    def analyze(query: str) -> str:
        """Analyze and report on modules/agents in the codebase."""
        modules = _analyze_modules(kg)
        return _format_module_report(modules)

    return analyze


async def _llm_classify_module_async(
    file_path: str,
    file_content: str,
    class_docstrings: list[str],
    function_signatures: list[str],
) -> tuple[str, str, bool, bool]:
    """Async version of _llm_classify_module using thread pool."""
    return await asyncio.to_thread(
        _llm_classify_module,
        file_path,
        file_content,
        class_docstrings,
        function_signatures,
    )


async def _analyze_modules_async(kg: KnowledgeGraph, codebase_root: str = "", target: str = "") -> dict:
    """
    Async version of _analyze_modules with parallel LLM classification.

    Runs all uncached file classifications concurrently using asyncio.gather.
    """
    modules = {
        "total_count": 0,
        "by_structure_type": {},
        "by_module_kind": {},
        "by_level": {},
        "modules_list": [],
    }

    # Load classification cache once
    cache = _load_classification_cache(codebase_root)

    class_nodes = [v for v in kg.vertices.values() if v.label == "class"]
    file_nodes = [v for v in kg.vertices.values() if v.label == "file"]

    # Identify agent-like classes
    agent_classes = [
        v
        for v in class_nodes
        if "agent" in v.properties.get("name", "").lower()
    ]

    # Identify all Python files with "agent" in name
    agent_files = [
        v
        for v in file_nodes
        if "agent" in v.properties.get("path", "").lower()
        and v.properties.get("path", "").endswith(".py")
    ]

    # If target is specified, filter to only that target
    if target and target != "codebase":
        target_lower = target.lower()
        agent_files = [
            v for v in agent_files
            if target_lower in v.properties.get("path", "").lower()
        ]

    modules["total_count"] = len(agent_classes) + len(agent_files)

    # Process class-based modules (sync, no LLM)
    for cls in agent_classes:
        name = cls.properties.get("name", "unknown")
        docstring = cls.properties.get("docstring", "")
        description = docstring.split("\n")[0] if docstring else "No description"
        methods = cls.properties.get("methods", [])

        module_kind, details = _classify_module_kind_detailed(name, description, "")

        modules["modules_list"].append({
            "name": name,
            "structure_type": "class",
            "level": "component",
            "module_kind": module_kind,
            "description": description,
            "uses_llm": details.get("uses_llm", False),
            "uses_tools": details.get("uses_tools", False),
            "methods": len(methods),
        })

        modules["by_structure_type"]["class"] = modules["by_structure_type"].get("class", 0) + 1
        modules["by_level"]["component"] = modules["by_level"].get("component", 0) + 1
        modules["by_module_kind"][module_kind] = modules["by_module_kind"].get(module_kind, 0) + 1

    # Process file nodes: collect uncached files and classify in parallel
    uncached_files = []
    cached_results = {}

    for file_node in agent_files:
        path = file_node.properties.get("path", "unknown")
        content = file_node.properties.get("content", "")
        cache_key = _get_cache_key(content)

        if cache_key in cache:
            cached_results[path] = cache[cache_key]
        else:
            # Collect KG context for this file
            class_docstrings = []
            function_signatures = []
            file_key = f"file:{path}"
            if file_key in kg.vertices:
                neighbors = kg.neighbors(file_key)
                for neighbor_id in neighbors:
                    if neighbor_id in kg.vertices:
                        v = kg.vertices[neighbor_id]
                        if v.label == "class" and v.properties.get("docstring"):
                            class_docstrings.append(v.properties["docstring"])
                        elif v.label == "function" and v.properties.get("signature"):
                            function_signatures.append(v.properties["signature"])

            uncached_files.append((path, content, cache_key, class_docstrings, function_signatures))

    # Opt 3: Classify all uncached files in parallel
    if uncached_files and codebase_root:
        print(f"[module_analyzer] Classifying {len(uncached_files)} uncached files in parallel...")

    classifications = []
    if uncached_files:
        tasks = [
            _llm_classify_module_async(path, content, class_docstrings, function_signatures)
            for path, content, _, class_docstrings, function_signatures in uncached_files
        ]
        classifications = await asyncio.gather(*tasks, return_exceptions=True)

    # Process uncached results and update cache
    for idx, (path, content, cache_key, _, _) in enumerate(uncached_files):
        if idx < len(classifications):
            result = classifications[idx]
            if isinstance(result, Exception):
                # Fallback on error
                module_kind, purpose, uses_llm, uses_tools = "non-agentic", "Utility module (classification failed)", False, False
                if codebase_root:
                    print(f"  [error] {path}")
            else:
                module_kind, purpose, uses_llm, uses_tools = result
                if codebase_root:
                    print(f"  [llm] {path} → {module_kind}")
        else:
            module_kind, purpose, uses_llm, uses_tools = "non-agentic", "Unknown", False, False

        # Store in cache
        cache[cache_key] = {
            "module_kind": module_kind,
            "description": purpose,
            "uses_llm": uses_llm,
            "uses_tools": uses_tools,
        }
        cached_results[path] = cache[cache_key]

    # Build modules list from all results (cached + newly classified)
    for file_node in agent_files:
        path = file_node.properties.get("path", "unknown")
        if path not in cached_results:
            continue

        cached = cached_results[path]
        module_kind = cached["module_kind"]
        description = cached["description"]
        uses_llm = cached["uses_llm"]
        uses_tools = cached["uses_tools"]

        modules["modules_list"].append({
            "name": path,
            "structure_type": "module",
            "level": "top-level",
            "module_kind": module_kind,
            "description": description,
            "uses_llm": uses_llm,
            "uses_tools": uses_tools,
        })

        modules["by_structure_type"]["module"] = modules["by_structure_type"].get("module", 0) + 1
        modules["by_level"]["top-level"] = modules["by_level"].get("top-level", 0) + 1
        modules["by_module_kind"][module_kind] = modules["by_module_kind"].get(module_kind, 0) + 1

    # Save cache
    _save_classification_cache(codebase_root, cache)

    return modules


async def get_modules_structured_async(kg: KnowledgeGraph, codebase_root: str = "", target: str = "") -> list[ModuleInfo]:
    """
    Async version of get_modules_structured with parallel classification.
    """
    modules_dict = await _analyze_modules_async(kg, codebase_root, target)
    modules_list = []

    for module_dict in modules_dict["modules_list"]:
        file_content = ""

        # Populate file_content from KG for file-based modules
        if module_dict["structure_type"] == "module":
            file_key = f"file:{module_dict['name']}"
            if file_key in kg.vertices:
                file_content = kg.vertices[file_key].properties.get("content", "")

        module_info = ModuleInfo(
            name=module_dict["name"],
            structure_type=module_dict["structure_type"],
            level=module_dict["level"],
            module_kind=module_dict["module_kind"],
            description=module_dict["description"],
            uses_llm=module_dict["uses_llm"],
            uses_tools=module_dict["uses_tools"],
            file_content=file_content,
            methods=module_dict.get("methods", 0),
        )
        modules_list.append(module_info)

    return modules_list


def get_modules_structured(kg: KnowledgeGraph, codebase_root: str = "", target: str = "") -> list[ModuleInfo]:
    """
    Get structured module information without text-based formatting.

    Args:
        kg: Knowledge graph of the codebase
        codebase_root: Optional root path for caching and context
        target: Optional target module name to focus on (optimization to skip classifying all)

    Returns:
        List of ModuleInfo objects with full file content populated from KG
    """
    modules_dict = _analyze_modules(kg, codebase_root, target)
    modules_list = []

    for module_dict in modules_dict["modules_list"]:
        file_content = ""

        # Populate file_content from KG for file-based modules
        if module_dict["structure_type"] == "module":
            file_key = f"file:{module_dict['name']}"
            if file_key in kg.vertices:
                file_content = kg.vertices[file_key].properties.get("content", "")

        module_info = ModuleInfo(
            name=module_dict["name"],
            structure_type=module_dict["structure_type"],
            level=module_dict["level"],
            module_kind=module_dict["module_kind"],
            description=module_dict["description"],
            uses_llm=module_dict["uses_llm"],
            uses_tools=module_dict["uses_tools"],
            file_content=file_content,
            methods=module_dict.get("methods", 0),
        )
        modules_list.append(module_info)

    return modules_list


def _analyze_modules(kg: KnowledgeGraph, codebase_root: str = "", target: str = "") -> dict:
    """
    Analyze the knowledge graph to identify modules/agents.
    Uses LLM-based classification with caching for file-based modules.

    Args:
        kg: Knowledge graph
        codebase_root: Root path for caching
        target: Optional target module to focus on (optimization)

    Returns a dict with counts, categorized lists, and detailed information.
    """
    modules = {
        "total_count": 0,
        "by_structure_type": {},
        "by_module_kind": {},
        "by_level": {},
        "modules_list": [],
    }

    # Load classification cache once
    cache = _load_classification_cache(codebase_root)
    if cache and codebase_root:
        print(f"[module_analyzer] Cache loaded: {len(cache)} entries")

    class_nodes = [v for v in kg.vertices.values() if v.label == "class"]
    file_nodes = [v for v in kg.vertices.values() if v.label == "file"]

    # Identify agent-like classes
    agent_classes = [
        v
        for v in class_nodes
        if "agent" in v.properties.get("name", "").lower()
    ]

    # Identify all Python files with "agent" in name
    agent_files = [
        v
        for v in file_nodes
        if "agent" in v.properties.get("path", "").lower()
        and v.properties.get("path", "").endswith(".py")
    ]

    # If target is specified, filter to only that target (optimization)
    if target and target != "codebase":
        target_lower = target.lower()
        agent_files = [
            v for v in agent_files
            if target_lower in v.properties.get("path", "").lower()
        ]

    modules["total_count"] = len(agent_classes) + len(agent_files)

    # Process class-based modules
    for cls in agent_classes:
        name = cls.properties.get("name", "unknown")
        docstring = cls.properties.get("docstring", "")
        description = docstring.split("\n")[0] if docstring else "No description"
        methods = cls.properties.get("methods", [])

        # Analyze class for LLM and tool usage
        module_kind, details = _classify_module_kind_detailed(
            name, description, ""
        )

        modules["modules_list"].append(
            {
                "name": name,
                "structure_type": "class",
                "level": "component",
                "module_kind": module_kind,
                "description": description,
                "uses_llm": details.get("uses_llm", False),
                "uses_tools": details.get("uses_tools", False),
                "methods": len(methods),
            }
        )

        modules["by_structure_type"]["class"] = (
            modules["by_structure_type"].get("class", 0) + 1
        )
        modules["by_level"]["component"] = modules["by_level"].get("component", 0) + 1
        modules["by_module_kind"][module_kind] = (
            modules["by_module_kind"].get(module_kind, 0) + 1
        )

    # Process module-level files with LLM classification + caching
    for file_node in agent_files:
        path = file_node.properties.get("path", "unknown")
        content = file_node.properties.get("content", "")

        # Check cache first
        cache_key = _get_cache_key(content)
        if cache_key in cache:
            cached = cache[cache_key]
            module_kind = cached["module_kind"]
            description = cached["description"]
            uses_llm = cached["uses_llm"]
            uses_tools = cached["uses_tools"]
            if codebase_root:
                print(f"  [cache hit] {path}: {module_kind}")
        else:
            # Use LLM classification (with fallback to keyword matching)
            if codebase_root:
                print(f"  [llm call] {path}...", end=" ", flush=True)
            description = _infer_module_description(path, content)

            # Collect related class docstrings and function signatures from KG
            class_docstrings = []
            function_signatures = []
            file_key = f"file:{path}"
            if file_key in kg.vertices:
                neighbors = kg.neighbors(file_key)
                for neighbor_id in neighbors:
                    if neighbor_id in kg.vertices:
                        v = kg.vertices[neighbor_id]
                        if v.label == "class" and v.properties.get("docstring"):
                            class_docstrings.append(v.properties["docstring"])
                        elif v.label == "function" and v.properties.get("signature"):
                            function_signatures.append(v.properties["signature"])

            # Call LLM classification
            module_kind, purpose, uses_llm, uses_tools = _llm_classify_module(
                path, content, class_docstrings, function_signatures
            )

            # Use LLM's purpose if we got a good one
            if purpose and purpose.strip():
                description = purpose

            # Store in cache
            cache[cache_key] = {
                "module_kind": module_kind,
                "description": description,
                "uses_llm": uses_llm,
                "uses_tools": uses_tools,
            }
            if codebase_root:
                print(f"→ {module_kind}")

        modules["modules_list"].append(
            {
                "name": path,
                "structure_type": "module",
                "level": "top-level",
                "module_kind": module_kind,
                "description": description,
                "uses_llm": uses_llm,
                "uses_tools": uses_tools,
            }
        )

        modules["by_structure_type"]["module"] = (
            modules["by_structure_type"].get("module", 0) + 1
        )
        modules["by_level"]["top-level"] = (
            modules["by_level"].get("top-level", 0) + 1
        )
        modules["by_module_kind"][module_kind] = (
            modules["by_module_kind"].get(module_kind, 0) + 1
        )

    # Save cache after processing all files
    _save_classification_cache(codebase_root, cache)
    if cache and codebase_root:
        print(f"[module_analyzer] Cache saved: {len(cache)} entries")

    return modules


def _load_classification_cache(codebase_root: str) -> dict:
    """Load classification cache from disk."""
    if not codebase_root:
        return {}

    cache_path = Path(codebase_root) / ".onecode" / "eval_datasets" / "classifications.json"
    if cache_path.exists():
        try:
            with open(cache_path, "r") as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            return {}
    return {}


def _save_classification_cache(codebase_root: str, cache: dict) -> None:
    """Save classification cache to disk."""
    if not codebase_root:
        return

    cache_dir = Path(codebase_root) / ".onecode" / "eval_datasets"
    cache_dir.mkdir(parents=True, exist_ok=True)

    cache_path = cache_dir / "classifications.json"
    try:
        with open(cache_path, "w") as f:
            json.dump(cache, f, indent=2)
    except IOError:
        pass


def _get_cache_key(content: str) -> str:
    """Generate cache key from file content hash (first 16 chars of SHA256)."""
    return hashlib.sha256(content.encode()).hexdigest()[:16]


def _llm_classify_module(
    file_path: str,
    file_content: str,
    class_docstrings: list[str],
    function_signatures: list[str],
) -> tuple[str, str, bool, bool]:
    """
    Classify module using LLM.

    Returns: (module_kind, purpose_description, uses_llm, uses_tools)
    Falls back to keyword matching on LLM failure.
    """
    # Prepare context for LLM
    file_snippet = file_content[:1500] if file_content else ""

    class_context = "\n".join(class_docstrings[:3]) if class_docstrings else ""
    func_context = "\n".join(function_signatures[:5]) if function_signatures else ""

    prompt = f"""Analyze this Python module's PRIMARY PURPOSE and classify it.

FILE: {file_path}

CONTENT (first 1500 chars):
{file_snippet}

CLASS DOCSTRINGS:
{class_context or "(none)"}

FUNCTION SIGNATURES:
{func_context or "(none)"}

Classification rules (focus on PRIMARY PURPOSE, not implementation details):
- "agentic": PRIMARY purpose is orchestrating/coordinating LLM calls with tool/agent routing (supervisor, dispatcher)
- "genai": PRIMARY purpose is content generation using LLM (summarizer, writer, explainer)
- "non-agentic": PRIMARY purpose is NOT about LLM/generation (analyzer, parser, utility, infrastructure)

NOTE: If a module uses LLM/tools INTERNALLY for its implementation but its PRIMARY purpose is analysis/utility, classify as "non-agentic".

Return ONLY valid JSON with no extra text:
{{"kind": "agentic|genai|non-agentic", "purpose": "one-line description of primary purpose", "uses_llm": true/false, "uses_tools": true/false}}"""

    try:
        def _call_llm():
            client = config.get_client()
            response = client.chat.completions.create(
                model=config.MODEL,
                max_tokens=200,
                messages=[{"role": "user", "content": prompt}],
            )
            return response.choices[0].message.content

        result_text = call_api(_call_llm)

        # Parse JSON response (handle markdown code blocks)
        try:
            # Extract JSON from markdown code blocks if present
            json_text = result_text.strip()
            if json_text.startswith("```"):
                # Remove markdown code blocks
                lines = json_text.split("\n")
                json_lines = []
                in_block = False
                for line in lines:
                    if line.startswith("```"):
                        in_block = not in_block
                    elif in_block:
                        json_lines.append(line)
                json_text = "\n".join(json_lines)

            result = json.loads(json_text)
            kind = result.get("kind", "non-agentic").lower()
            purpose = result.get("purpose", "")
            uses_llm = result.get("uses_llm", False)
            uses_tools = result.get("uses_tools", False)

            # Validate kind
            if kind not in ("agentic", "genai", "non-agentic"):
                kind = "non-agentic"

            return kind, purpose, uses_llm, uses_tools
        except (json.JSONDecodeError, KeyError, TypeError):
            # Fall back to keyword matching
            combined = (file_path + " " + file_content).lower()
            uses_llm = _uses_llm(combined)
            uses_tools = _uses_tools(file_content, combined)

            if uses_llm and uses_tools:
                return "agentic", "LLM-based agent (fallback classification)", True, True
            elif uses_llm:
                return "genai", "LLM-powered module (fallback classification)", True, False
            else:
                return "non-agentic", "Utility module (fallback classification)", False, False
    except Exception:
        # Fallback to keyword matching on any error
        combined = (file_path + " " + file_content).lower()
        uses_llm = _uses_llm(combined)
        uses_tools = _uses_tools(file_content, combined)

        if uses_llm and uses_tools:
            return "agentic", "LLM-based agent (keyword fallback)", True, True
        elif uses_llm:
            return "genai", "LLM-powered module (keyword fallback)", True, False
        else:
            return "non-agentic", "Utility module (keyword fallback)", False, False


def _classify_module_kind_detailed(
    name: str, description: str, content: str
) -> tuple[str, dict]:
    """
    Classify module kind based on LLM + tool usage.

    Classification rules:
    - LLM + tools/function calls → agentic
    - LLM (no tools) → genai
    - No LLM → non-agentic

    Returns: (module_kind, details_dict)
    """
    combined = (name + " " + description + " " + content).lower()

    # Analyze LLM and tool usage
    uses_llm = _uses_llm(combined)
    uses_tools = _uses_tools(content, combined)

    # Classify based on LLM + tool usage
    if uses_llm and uses_tools:
        return "agentic", {"uses_llm": True, "uses_tools": True}
    elif uses_llm:
        return "genai", {"uses_llm": True, "uses_tools": False}
    else:
        return "non-agentic", {"uses_llm": False, "uses_tools": False}


def _uses_llm(combined: str) -> bool:
    """
    Detect if module uses LLM by checking:
    - Imports from OpenAI, Anthropic
    - Function calls to LLM APIs
    - Keywords indicating LLM usage
    """
    llm_indicators = [
        "from openai",
        "from anthropic",
        "import openai",
        "import anthropic",
        "completion",
        "message(",
        "claude",
        "gpt",
    ]

    return any(indicator in combined for indicator in llm_indicators)


def _uses_tools(content: str, combined: str) -> bool:
    """
    Detect if module uses tools/function calling by checking:
    - Tool registration/schema definitions
    - Function calls to other agents
    - Tool execution patterns
    - Generator/factory functions that create callable tools
    """
    tool_indicators = [
        "make_",  # OneCode factory pattern
        "register(",
        "tool",
        "function_definitions",
        "schema",
        "callbacks",
        "fn=",  # OneCode pattern for function registration
        ".fn(",  # Calling registered functions
        "agent_spec",
    ]

    has_tool_patterns = any(indicator in combined for indicator in tool_indicators)

    # Check if module calls other agents (in OneCode context)
    has_agent_calls = "agent" in combined and ("(" in content or "fn" in content)

    return has_tool_patterns or has_agent_calls


def _infer_module_description(path: str, content: str) -> str:
    """
    Infer module description from docstring or factory function.
    """
    # Try to extract module docstring first
    docstring = _extract_module_docstring(content)
    if docstring and docstring.strip():
        return docstring.split("\n")[0]

    # Try to find make_* factory function and its docstring
    lines = content.split("\n")
    for i, line in enumerate(lines):
        if line.strip().startswith("def make_"):
            for j in range(i + 1, min(i + 10, len(lines))):
                next_line = lines[j].strip()
                if next_line.startswith('"""') or next_line.startswith("'''"):
                    quote = '"""' if next_line.startswith('"""') else "'''"
                    rest = next_line[3:]
                    if rest.endswith(quote):
                        desc = rest[: -len(quote)]
                    else:
                        desc = rest
                    return desc if desc else "Module factory function"

    # Fallback: infer from filename
    name = path.split("/")[-1].replace("_", " ").replace(".py", "")
    return f"{name.title()}"


def _extract_module_docstring(content: str) -> str:
    """Extract the first docstring from a Python module."""
    lines = content.split("\n")
    in_docstring = False
    docstring_lines = []

    for line in lines:
        stripped = line.strip()
        if not in_docstring and (stripped.startswith('"""') or stripped.startswith("'''")):
            in_docstring = True
            quote = '"""' if stripped.startswith('"""') else "'''"
            rest = stripped[3:]
            if rest.endswith(quote):
                return rest[: -len(quote)]
            docstring_lines.append(rest)
        elif in_docstring:
            if '"""' in stripped or "'''" in stripped:
                quote = '"""' if '"""' in stripped else "'''"
                idx = stripped.find(quote)
                docstring_lines.append(stripped[:idx])
                break
            else:
                docstring_lines.append(stripped)

    return "\n".join(docstring_lines)


def _format_module_report(modules: dict) -> str:
    """Format module analysis into a readable report."""
    lines = [
        "=" * 80,
        "MODULE/AGENT ANALYSIS REPORT",
        "=" * 80,
        f"\nTotal Modules/Agents: {modules['total_count']}",
    ]

    if modules["by_structure_type"]:
        lines.append("\nBy Structure Type:")
        for stype, count in sorted(modules["by_structure_type"].items()):
            lines.append(f"  - {stype}: {count}")

    if modules["by_module_kind"]:
        lines.append("\nBy Module Kind:")
        kind_order = ["agentic", "genai", "non-agentic"]
        for kind in kind_order:
            if kind in modules["by_module_kind"]:
                count = modules["by_module_kind"][kind]
                lines.append(f"  - {kind}: {count}")

    if modules["by_level"]:
        lines.append("\nBy Level:")
        for level, count in sorted(modules["by_level"].items()):
            lines.append(f"  - {level}: {count}")

    if modules["modules_list"]:
        lines.append("\n" + "-" * 80)
        lines.append("DETAILED LISTING")
        lines.append("-" * 80)
        for i, module in enumerate(modules["modules_list"], 1):
            lines.append(f"\n{i}. {module['name']}")
            lines.append(f"   Structure: {module['structure_type']}")
            lines.append(f"   Module Kind: {module['module_kind']}")
            lines.append(f"   Level: {module['level']}")

            # Show LLM and tool usage
            usage = []
            if module.get("uses_llm"):
                usage.append("uses LLM")
            if module.get("uses_tools"):
                usage.append("uses tools/calls")
            if usage:
                lines.append(f"   Capabilities: {', '.join(usage)}")

            lines.append(f"   Description: {module['description']}")
            if "methods" in module:
                lines.append(f"   Methods: {module['methods']}")

    lines.append("\n" + "=" * 80)
    return "\n".join(lines)
