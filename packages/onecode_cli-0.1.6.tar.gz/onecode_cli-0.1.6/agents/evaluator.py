"""Evaluation agent — evaluates modules using natural language queries."""

import asyncio
import json
from typing import Optional
import config
from kg.graph import KnowledgeGraph
from eval import (
    make_module_analyzer,
    generate_golden_dataset,
    create_ragas_evaluator,
    get_modules_structured,
)
from eval.module_analyzer import get_modules_structured_async
from eval.golden_dataset_generator import (
    _extract_codebase_context,
    generate_golden_dataset_async,
)
from eval.actionability import build_action_report, format_action_report
from eval.results_store import save_eval_run, load_eval_runs, compare_runs, format_comparison_table
from utils.retry import call_api
from datetime import datetime, timezone


def make_evaluation_agent(kg: KnowledgeGraph, codebase_root: str = ""):
    """
    Factory function that returns an evaluation agent.

    Args:
        kg: Knowledge graph of the codebase
        codebase_root: Root path of codebase for dataset caching

    Returns:
        Evaluation agent function
    """

    def evaluate(query: str, execution_mode: bool = False) -> str:
        """
        Evaluate modules based on natural language query.

        Args:
            query: Natural language query (e.g., "evaluate the codebase",
                   "evaluate summarizer agent",
                   "what is the faithfulness of coder agent")
            execution_mode: If True, use execution-based evaluation; if False, use RAGAS metrics

        Returns:
            Formatted evaluation results
        """
        try:
            # Step 1: Analyze what the user is asking for
            evaluation_request = _parse_evaluation_query(query)

            if not evaluation_request:
                return "Unable to parse evaluation query. Try: 'evaluate the codebase', 'evaluate [agent_name]', or 'what metrics for [agent_name]'"

            print(f"\n[evaluator] Target: {evaluation_request['target']}")
            print(f"[evaluator] Metrics: {evaluation_request['metrics'] or 'all'}")
            print(f"[evaluator] Samples: {evaluation_request['num_samples']}")

            # Step 2-4: Run all async work together (classification + dataset gen + eval)
            runner = asyncio.Runner()
            try:
                results, comparison = runner.run(
                    _evaluate_pipeline(
                        kg=kg,
                        codebase_root=codebase_root,
                        evaluation_request=evaluation_request,
                    )
                )
            finally:
                runner.close()
                print("[evaluator] Evaluation complete")

            # Step 5: Format results with comparison
            return _format_evaluation_results(results, evaluation_request, comparison=comparison)

        except Exception as e:
            return f"Evaluation error: {e}"

    return evaluate


def _parse_evaluation_query(query: str) -> Optional[dict]:
    """
    Parse natural language evaluation query using LLM to extract intent.

    Returns dict with:
    - target: "codebase" or agent name (reader, coder, executor, etc.)
    - metrics: list of metrics to compute (empty = all)
    - num_samples: number of test samples
    """

    # Agent descriptions for intelligent selection
    agent_descriptions = """
AVAILABLE AGENTS:
- reader_agent: Semantic search over codebase. Understands code structure, logic, classes, functions.
- search_agent: Exact/regex text search. Finds specific strings, symbols, patterns across files.
- coder_agent: Writes and modifies code. Creates new code or updates existing code.
- renamer_agent: Renames and moves files/directories within the codebase.
- deleter_agent: Deletes files and directories from the codebase.
- executor_agent: Runs shell commands. Executes code and returns output/errors.
- git_agent: Performs git operations (status, commit, diff, etc.).
- summarizer_agent: Condenses long content into summaries.
- module_analyzer: Identifies and categorizes modules/agents in the codebase.
- evaluator_agent: Evaluates modules using RAGAS metrics (faithfulness, accuracy, etc.).
- supervisor: Orchestrates all agents using natural language understanding.
"""

    prompt = f"""Extract the evaluation request from this query. Return ONLY valid JSON.

{agent_descriptions}

Query: "{query}"

INSTRUCTIONS:
1. Extract target agent based on user intent:
   - If user mentions a specific agent name → use that agent (remove "_agent" suffix if present)
   - If user says "evaluate [name] agent" → target is "[name]" (e.g., "supervisor agent" → "supervisor")
   - If user describes what an agent does → match to appropriate agent(s)
   - If asking about "the codebase" or "all modules" → target is "codebase"
   - Examples: "supervisor agent" → "supervisor", "code writer" → "coder", "code searcher" → "reader"

2. Extract requested metrics (empty array = all metrics wanted):
   Metric names: faithfulness, hallucination, answer_relevancy, context_precision, context_recall, answer_accuracy, response_groundedness, agent_goal_accuracy, tool_call_f1
   Aliases:
   - "faithful", "truthfulness" → faithfulness
   - "hallucination", "hallucinate" → hallucination
   - "relevant", "relevance", "answer relevancy" → answer_relevancy
   - "precision", "context precision" → context_precision
   - "recall", "context recall" → context_recall
   - "accuracy", "answer accuracy" → answer_accuracy
   - "groundedness", "grounded", "response groundedness" → response_groundedness
   - "goal", "agent goal" → agent_goal_accuracy
   - "tool", "tool call" → tool_call_f1

3. Extract sample count:
   - "quick" or "few" → 2 samples
   - "comprehensive" or "detailed" → 10 samples
   - default → 5 samples

EXAMPLES:
- "evaluate supervisor agent" → {{"target": "supervisor", "metrics": [], "num_samples": 5}}
- "evaluate the summarizer" → {{"target": "summarizer", "metrics": [], "num_samples": 5}}
- "quick evaluation" → {{"target": "codebase", "metrics": [], "num_samples": 2}}
- "which agent is best at code understanding?" → {{"target": "reader", "metrics": [], "num_samples": 5}}
- "evaluate the code modifier focusing on accuracy" → {{"target": "coder", "metrics": ["answer_accuracy"], "num_samples": 5}}
- "how faithful is the searcher?" → {{"target": "search", "metrics": ["faithfulness"], "num_samples": 5}}
- "comprehensive evaluation of all agents" → {{"target": "codebase", "metrics": [], "num_samples": 10}}

START WITH {{ CHARACTER. ONLY JSON."""

    try:
        # Use project's configured LLM (Claude or OpenAI depending on config)
        response = config.get_client().chat.completions.create(
            model=config.MODEL,
            max_tokens=200,
            temperature=0,
            messages=[{"role": "user", "content": prompt}],
        )
        response_text = response.choices[0].message.content.strip()

        # Clean up response if it has markdown code blocks
        if "```" in response_text:
            parts = response_text.split("```")
            if len(parts) >= 2:
                response_text = parts[1]
                if response_text.startswith("json"):
                    response_text = response_text[4:]
        response_text = response_text.strip()

        # Parse JSON
        result = json.loads(response_text)

        return {
            "target": result.get("target", "codebase"),
            "metrics": result.get("metrics", []) or None,  # None means all metrics
            "num_samples": result.get("num_samples", 5),
        }
    except Exception as e:
        # Fallback: try pattern-based parsing
        print(f"[evaluator] Note: Using pattern-based parsing (LLM failed: {str(e)[:50]}...)")

        target = "codebase"
        metrics = None
        num_samples = 5

        # Try to extract agent name from query
        query_lower = query.lower()
        agent_names = [
            "supervisor", "reader", "coder", "executor", "git_agent", "git",
            "search", "searcher", "summarizer", "deleter", "renamer"
        ]

        for agent in agent_names:
            if agent in query_lower:
                target = agent
                break

        # Try to extract metrics
        if "faithful" in query_lower:
            metrics = ["faithfulness"]
        elif "accuracy" in query_lower:
            metrics = ["answer_accuracy"]
        elif "relevancy" in query_lower or "relevant" in query_lower:
            metrics = ["answer_relevancy"]

        # Try to extract sample count
        if "quick" in query_lower or "few" in query_lower:
            num_samples = 2
        elif "comprehensive" in query_lower or "detailed" in query_lower:
            num_samples = 10

        print(f"[evaluator] Pattern match: target='{target}', metrics={metrics}, samples={num_samples}")

        return {
            "target": target,
            "metrics": metrics,
            "num_samples": num_samples,
        }


async def _evaluate_pipeline(
    kg,
    codebase_root: str,
    evaluation_request: dict,
) -> list[dict]:
    """
    Optimized evaluation pipeline with parallel operations:
    - Opt 3: Async module classification (parallel file classification)
    - Opt 1&2: Async dataset generation with parallel LLM calls per module + across modules
    - RAGAS evaluation: Sequential per module (but async and concurrent internally)
    """
    target = evaluation_request["target"]
    metrics = evaluation_request["metrics"]
    num_samples = evaluation_request["num_samples"]

    # Step A: Classify modules in parallel (Opt 3)
    print("[evaluator] Analyzing modules with parallel classification...")
    modules_info = await get_modules_structured_async(kg, codebase_root, target=target)

    print(f"[evaluator] Found {len(modules_info)} evaluable modules")
    if modules_info:
        all_module_names = [m.name for m in modules_info]
        print(f"[evaluator] All modules: {all_module_names}")

    if not modules_info:
        return []

    # Filter modules if specific agent requested
    if target != "codebase":
        target_lower = evaluation_request["target"].lower()
        filtered = []

        for m in modules_info:
            module_name_raw = m.name.lower()
            module_name = module_name_raw.split("/")[-1].replace(".py", "")
            module_name_no_agent = module_name[:-5] if module_name.endswith("agent") else module_name
            target_without_agent = target_lower[:-6] if target_lower.endswith("_agent") else target_lower
            target_with_agent = target_lower if target_lower.endswith("_agent") else target_lower + "_agent"

            matches = (
                target_lower == module_name or
                target_without_agent == module_name or
                target_with_agent == module_name or
                target_lower in module_name or
                target_without_agent in module_name or
                target_lower in module_name_no_agent or
                target_lower in module_name_raw
            )

            if matches:
                filtered.append(m)

        modules_info = filtered
        print(f"[evaluator] Filtered to {len(modules_info)} module(s) for target '{evaluation_request['target']}'")

        if not modules_info:
            return []

    # Extract codebase context for dataset generation
    codebase_context = _extract_codebase_context(kg)
    if codebase_context:
        print("[evaluator] Using codebase context for dataset generation")

    # Step B: Separate evaluable and non-evaluable modules
    evaluable = [m for m in modules_info if m.module_kind != "non-agentic"]
    non_evaluable = [m for m in modules_info if m.module_kind == "non-agentic"]

    if not evaluable:
        return []

    # Step C: Generate datasets for ALL modules in parallel (Opt 1&2)
    print(f"[evaluator] Generating datasets for {len(evaluable)} modules in parallel...\n")

    async def _gen_dataset(module):
        """Generate dataset for a single module with async LLM calls."""
        try:
            module_info = {
                "name": module.name,
                "module_kind": module.module_kind,
                "description": module.description,
                "uses_llm": module.uses_llm,
                "uses_tools": module.uses_tools,
            }
            dataset = await generate_golden_dataset_async(
                module_info,
                num_samples=num_samples,
                module_content=module.file_content,
                codebase_root=codebase_root,
                codebase_context=codebase_context,
            )
            return module, dataset
        except Exception as e:
            print(f"[evaluator] Dataset generation failed for {module.name}: {str(e)[:50]}")
            return module, None

    dataset_results = await asyncio.gather(*[_gen_dataset(m) for m in evaluable], return_exceptions=True)

    # Step D: Evaluate modules with RAGAS (sequential per module, async concurrent internally)
    evaluator = create_ragas_evaluator()
    results = []

    print(f"[evaluator] Starting RAGAS evaluation of {len(evaluable)} modules...\n")

    for idx, result in enumerate(dataset_results, 1):
        if isinstance(result, Exception):
            print(f"[{idx}/{len(evaluable)}] Error generating dataset")
            continue

        module, dataset = result

        try:
            print(f"[{idx}/{len(evaluable)}] {module.name} ({module.module_kind})...", end=" ")

            if dataset is None or not dataset.questions:
                print("❌ failed (dataset generation)")
                results.append({
                    "name": module.name,
                    "kind": module.module_kind,
                    "status": "failed",
                    "reason": "Failed to generate golden dataset",
                })
                continue

            # Evaluate with RAGAS
            print("computing metrics...", end=" ")

            if module.module_kind == "genai":
                eval_metrics = await evaluator.evaluate_genai_module(
                    questions=dataset.questions,
                    contexts=dataset.contexts,
                    answers=dataset.answers,
                    ground_truth=dataset.ground_truth,
                    requested_metrics=metrics,
                )
            elif module.module_kind == "agentic":
                eval_metrics = await evaluator.evaluate_agentic_module(
                    questions=dataset.questions,
                    contexts=dataset.contexts,
                    answers=dataset.answers,
                    ground_truth=dataset.ground_truth,
                    expected_tool_calls=dataset.expected_tool_calls or [],
                    selected_tool_calls=dataset.selected_tool_calls or [],
                    requested_metrics=metrics,
                )
            else:
                continue

            print("✓")
            results.append({
                "name": module.name,
                "kind": module.module_kind,
                "status": "success",
                "metrics": eval_metrics,
                "num_samples": num_samples,
                "questions": dataset.questions,
                "description": module.description,
            })

        except Exception as e:
            print(f"❌ error: {str(e)[:60]}")
            results.append({
                "name": module.name,
                "kind": module.module_kind,
                "status": "failed",
                "error": str(e),
            })

    # Add non-evaluable modules to results
    for module in non_evaluable:
        results.append({
            "name": module.name,
            "kind": "non-agentic",
            "status": "skipped",
            "reason": "Non-agentic modules cannot be evaluated",
        })

    # Close evaluator to clean up HTTP clients
    try:
        await evaluator.close()
    except Exception as e:
        print(f"[evaluator] Warning: Failed to close evaluator: {e}")

    print(f"\n[evaluator] Results: {len([r for r in results if r['status'] == 'success'])} passed, {len([r for r in results if r['status'] == 'failed'])} failed\n")

    # Phase 5: Save eval run and load prior for comparison
    from eval.results_store import EvalRun, save_eval_run, load_eval_runs, compare_runs
    run_id = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S_%s") + f"_{target}"
    run = EvalRun(
        run_id=run_id,
        timestamp=datetime.now(timezone.utc).isoformat(),
        target=target,
        results=results,
        codebase_root=codebase_root,
    )
    save_eval_run(codebase_root, run)

    # Load prior run for comparison
    prior_runs = load_eval_runs(codebase_root, target=target, limit=2)
    comparison = None
    if len(prior_runs) >= 2:
        # prior_runs[0] is the current run we just saved, prior_runs[1] is the previous one
        comparison = compare_runs(prior_runs[0], prior_runs[1])

    return results, comparison


def _format_evaluation_results(
    results: list[dict], request: dict, comparison: dict = None
) -> str:
    """Format evaluation results for display."""
    lines = ["\n" + "=" * 80, "EVALUATION RESULTS", "=" * 80]

    successful = [r for r in results if r["status"] == "success"]
    failed = [r for r in results if r["status"] == "failed"]
    skipped = [r for r in results if r["status"] == "skipped"]

    # Summary
    lines.append(
        f"\nSummary: {len(successful)} evaluated, {len(failed)} failed, {len(skipped)} skipped"
    )

    # Comparison with prior run
    if comparison:
        lines.append(format_comparison_table(comparison))

    # Detailed results
    if successful:
        lines.append("\n" + "-" * 80)
        lines.append("SUCCESSFUL EVALUATIONS")
        lines.append("-" * 80)

        for result in successful:
            # Build actionability report
            report = build_action_report(
                module_name=result["name"],
                module_kind=result["kind"],
                module_purpose=result.get("description", ""),
                metrics=result["metrics"],
                questions=result.get("questions", []),
            )
            # Format and display the report
            lines.append(format_action_report(report))

    if skipped:
        lines.append("\n" + "-" * 80)
        lines.append("SKIPPED")
        lines.append("-" * 80)
        for result in skipped:
            lines.append(f"\n⏭️  {result['name']}: {result['reason']}")

    if failed:
        lines.append("\n" + "-" * 80)
        lines.append("FAILED")
        lines.append("-" * 80)
        for result in failed:
            reason = result.get("error") or result.get("reason", "Unknown error")
            lines.append(f"\n❌ {result['name']}: {reason}")

    lines.append("\n" + "=" * 80 + "\n")

    return "\n".join(lines)
