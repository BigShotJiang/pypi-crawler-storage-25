from typing import Any

from tqdm import tqdm

from grabber.core.bot.infrastructure import TelegramSenderAdapter
from grabber.core.bot.usecases.contracts import SendMessageRequest
from grabber.core.bot.usecases.message_sender import MessageSenderUseCase

_DEFAULT_SENDER: MessageSenderUseCase | None = None


def get_message_sender() -> MessageSenderUseCase:
    global _DEFAULT_SENDER
    if _DEFAULT_SENDER is None:
        _DEFAULT_SENDER = MessageSenderUseCase(sender=TelegramSenderAdapter())
    return _DEFAULT_SENDER


async def send_video(
    videos: list[Any],
    channel: str | None = "@fans_posting",
    caption: str = "",
    headers: dict[str, str] | None = None,
) -> bool:
    if not channel:
        return False
    adapter = TelegramSenderAdapter()
    return await adapter.send_video_group(
        channels=[channel],
        videos=videos,
        caption=caption,
        headers=headers,
    )


async def send_message(
    post_text: str,
    image_urls: set[tuple[str, str]] | None = None,
    channel: str | None = "@fans_posting",
    thread_id: int | None = None,
    retry: bool | None = False,
    posts_counter: int = 0,
    retry_counter: int = 0,
    sleep_time: int | None = 0,
    tqdm_iterable: tqdm | None = None,
    send_images: bool | None = False,
    entity: str | None = "",
) -> tuple[bool, list[str]]:
    request = SendMessageRequest(
        post_text=post_text,
        image_urls=image_urls,
        channel=channel,
        thread_id=thread_id,
        retry=bool(retry),
        posts_counter=posts_counter,
        retry_counter=retry_counter,
        sleep_time=int(sleep_time or 0),
        tqdm_iterable=tqdm_iterable,
        send_images=bool(send_images),
        entity=entity or "",
    )
    result = await get_message_sender().run(request)
    return result.was_successful, result.channels
