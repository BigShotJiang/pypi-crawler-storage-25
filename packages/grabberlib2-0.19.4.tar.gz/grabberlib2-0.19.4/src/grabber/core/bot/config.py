from dataclasses import dataclass, field

from environs import Env
from telegraph import Telegraph

from grabber.core.settings import APP_ROOT, CHANNELS


@dataclass
class BotSettings:
    bot_token: str
    channels: dict[str, str]
    telegraph_author_name: str | None = None
    telegraph_author_url: str | None = None
    telegraph_short_name: str | None = None
    telegraph_token: str | None = None
    telethon_api_id: int | None = None
    telethon_api_hash: str | None = None
    telethon_session_path: str = field(default_factory=lambda: str(APP_ROOT / "grabber_user"))
    __telegraph_client: Telegraph | None = None

    @property
    def telegraph_client(self) -> Telegraph | None:
        if not self.__telegraph_client and self.telegraph_token:
            self.__telegraph_client = Telegraph(access_token=self.telegraph_token)

        return self.__telegraph_client


class BotSettingsFactory:
    def __init__(self, env: Env | None = None) -> None:
        self.env = env or Env()
        self.env.read_env()

    def build(self) -> BotSettings:
        token = self.env.str("BOT_TOKEN", "")
        telegraph_token = self.env.str("TELEGRAPH_TOKEN", "")
        short_name = self.env.str("SHORT_NAME", "")
        author_name = self.env.str("AUTHOR_NAME", "")
        author_url = self.env.str("AUTHOR_URL", "")
        telethon_api_id = self.env.int("TELETHON_API_ID", None)
        telethon_api_hash = self.env.str("TELETHON_API_HASH", "") or None
        telethon_session_path = self.env.str("TELETHON_SESSION_PATH", str(APP_ROOT / "grabber_user"))

        if not token:
            raise RuntimeError("BOT_TOKEN not set")

        return BotSettings(
            bot_token=token,
            channels=CHANNELS,
            telegraph_author_name=author_name,
            telegraph_author_url=author_url,
            telegraph_short_name=short_name,
            telegraph_token=telegraph_token,
            telethon_api_id=telethon_api_id,
            telethon_api_hash=telethon_api_hash,
            telethon_session_path=telethon_session_path,
        )


def get_settings() -> BotSettings:
    return BotSettingsFactory().build()
