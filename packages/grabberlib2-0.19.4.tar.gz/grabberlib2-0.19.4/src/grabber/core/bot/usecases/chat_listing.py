import asyncio

from telethon import TelegramClient

from grabber.core.settings import APP_ROOT

CHATS_TXT_PATH = APP_ROOT / "assets" / "txt" / "chats.txt"
DEFAULT_SESSION_PATH = str(APP_ROOT / "grabber_user")


def load_cached_chats() -> list[str]:
    if not CHATS_TXT_PATH.exists():
        return []
    return [line.strip() for line in CHATS_TXT_PATH.read_text(encoding="utf-8").splitlines() if line.strip()]


def save_chats(usernames: list[str]) -> None:
    CHATS_TXT_PATH.parent.mkdir(parents=True, exist_ok=True)
    CHATS_TXT_PATH.write_text("\n".join(usernames), encoding="utf-8")


async def fetch_public_usernames(api_id: int, api_hash: str, session_path: str) -> list[str]:
    client = TelegramClient(session_path, api_id, api_hash)
    await client.connect()
    try:
        if not await client.is_user_authorized():
            raise RuntimeError(
                "Telethon session not authorized. "
                "Run: python -m grabber.core.bot.usecases.chat_listing"
            )
        seen: set[str] = set()
        usernames: list[str] = []
        for folder in (0, 1):  # 0 = main, 1 = archived
            async for dialog in client.iter_dialogs(folder=folder):
                if not (dialog.is_group or dialog.is_channel):
                    continue
                username = getattr(dialog.entity, "username", None)
                if username and username not in seen:
                    seen.add(username)
                    usernames.append(f"@{username}")
        return usernames
    finally:
        await client.disconnect()


async def fetch_and_save(api_id: int, api_hash: str, session_path: str) -> list[str]:
    usernames = await fetch_public_usernames(api_id, api_hash, session_path)
    save_chats(usernames)
    return usernames


if __name__ == "__main__":
    from environs import Env

    env = Env()
    env.read_env()
    api_id = env.int("TELETHON_API_ID", 0) or int(input("TELETHON_API_ID: "))
    api_hash = env.str("TELETHON_API_HASH", "") or input("TELETHON_API_HASH: ")
    session_path = env.str("TELETHON_SESSION_PATH", DEFAULT_SESSION_PATH)

    async def _auth() -> None:
        client = TelegramClient(session_path, api_id, api_hash)
        await client.start()
        print(f"Authenticated. Session: {session_path}.session")
        await client.disconnect()

    asyncio.run(_auth())
