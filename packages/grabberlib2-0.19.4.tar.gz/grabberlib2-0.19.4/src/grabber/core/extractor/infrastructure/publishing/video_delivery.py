from __future__ import annotations

import asyncio
import json
import logging
import pathlib
import tempfile
from dataclasses import dataclass
from typing import Any
from urllib.parse import unquote, urlparse

import aiofiles
import aiohttp
from aiogram import Bot
from aiogram.exceptions import TelegramEntityTooLarge, TelegramRetryAfter
from aiogram.types import FSInputFile, URLInputFile
from boltons.setutils import IndexedSet
from tqdm import tqdm

from grabber.core.extractor.infrastructure.checkpoints import build_checkpoint_service
from grabber.core.settings import BOT_TOKEN

logger = logging.getLogger(__name__)
CHUNK_SIZE = 1024 * 1024
URL_INPUT_MAX_BYTES = 50 * 1024 * 1024
BOT_UPLOAD_MAX_BYTES = 50 * 1024 * 1024
FFMPEG_AUDIO_BITRATE_KBPS = 128
FFMPEG_TARGET_SIZE_BYTES = BOT_UPLOAD_MAX_BYTES - 1 * 1024 * 1024  # 49 MB safety margin
COMPRESS_MAX_BYTES = 80 * 1024 * 1024  # above this, split directly — compression would wreck quality


@dataclass(slots=True)
class VideoDeliveryStats:
    total_found: int
    total_after_checkpoint: int
    sent_count: int
    skipped_count: int
    fallback_download_count: int
    fallback_document_count: int
    failed_count: int
    link_only_count: int = 0


def _set_progress(tqdm_iterable: tqdm | None, message: str) -> None:
    if tqdm_iterable is not None:
        tqdm_iterable.set_description(message)
        return
    logger.info(message)


async def _run_with_retry_after(operation) -> Any:
    while True:
        try:
            return await operation()
        except TelegramRetryAfter as exc:
            sleep_seconds = max(1, int(getattr(exc, "retry_after", 1)))
            logger.warning("Telegram asked retry-after=%s seconds", sleep_seconds)
            await asyncio.sleep(sleep_seconds)


def _extract_video_src(media_record: object) -> str:
    if isinstance(media_record, tuple | list) and media_record:
        return str(media_record[-1]).strip()
    return str(media_record).strip()


def _extract_video_filename(media_record: object, index: int, source_url: str) -> str:
    if isinstance(media_record, tuple | list) and media_record:
        candidate = str(media_record[0]).strip()
        if candidate:
            filename = pathlib.Path(candidate).name
            if "." in filename:
                return filename
            return f"{filename}.mp4"

    parsed_name = pathlib.Path(unquote(urlparse(source_url).path)).name.strip()
    if parsed_name:
        return parsed_name
    return f"video-{index:03d}.mp4"


def _should_fallback_to_document(exc: Exception) -> bool:
    if isinstance(exc, TelegramEntityTooLarge):
        return True

    message = str(exc).lower()
    media_error_tokens = (
        "too large",
        "request entity too large",
        "video content type",
        "wrong file identifier",
        "failed to get http url content",
        "type of file mismatch",
    )
    return any(token in message for token in media_error_tokens)


def _parse_content_range_total(content_range: str | None) -> int | None:
    if not content_range or "/" not in content_range:
        return None

    maybe_total = content_range.rsplit("/", 1)[-1].strip()
    if not maybe_total.isdigit():
        return None
    return int(maybe_total)


async def _probe_remote_file_size(
    video_url: str,
    headers: dict[str, str] | None = None,
) -> int | None:
    timeout = aiohttp.ClientTimeout(total=None, sock_connect=15, sock_read=30)
    base_headers = headers or {}
    async with aiohttp.ClientSession(timeout=timeout, headers=base_headers) as session:
        try:
            async with session.head(video_url, allow_redirects=True) as response:
                content_length = response.headers.get("Content-Length", "").strip()
                if content_length.isdigit():
                    return int(content_length)
        except Exception:
            logger.debug("HEAD size probe failed for %s", video_url)

        try:
            range_headers = dict(base_headers)
            range_headers["Range"] = "bytes=0-0"
            async with session.get(video_url, headers=range_headers, allow_redirects=True) as response:
                content_length = response.headers.get("Content-Length", "").strip()
                if response.status == 200 and content_length.isdigit():
                    return int(content_length)

                total_from_range = _parse_content_range_total(response.headers.get("Content-Range"))
                if total_from_range is not None:
                    return total_from_range
        except Exception:
            logger.debug("Range size probe failed for %s", video_url)

    return None


def _format_size_bytes(size_bytes: int | None) -> str:
    if size_bytes is None:
        return "unknown"
    size_mb = size_bytes / (1024 * 1024)
    return f"{size_mb:.1f}MB"


async def _send_link_only_message(
    bot: Bot,
    channel: str,
    page_title: str,
    video_url: str,
    size_bytes: int | None,
) -> None:
    size_text = _format_size_bytes(size_bytes)
    text = f"{page_title}\nVideo too large for Telegram Bot API upload ({size_text}).\n{video_url}"
    await _run_with_retry_after(lambda: bot.send_message(chat_id=channel, text=text, disable_web_page_preview=True))


async def send_link_message_to_channel(
    channel: str,
    page_title: str,
    video_url: str,
    size_bytes: int | None = None,
) -> bool:
    if not channel.strip():
        logger.warning("Skipping link message send because channel is empty for %s", video_url)
        return False

    bot = Bot(token=BOT_TOKEN)
    async with bot.context():
        try:
            await _send_link_only_message(
                bot=bot,
                channel=channel,
                page_title=page_title,
                video_url=video_url,
                size_bytes=size_bytes,
            )
            return True
        except Exception as exc:
            logger.warning("Failed to send link message for %s: %s", video_url, exc)
            return False


async def send_local_video_to_channel(
    channel: str,
    page_title: str,
    source_url: str,
    local_file_path: pathlib.Path,
    video_filename: str | None = None,
    tqdm_iterable: tqdm | None = None,
) -> bool:
    if not channel.strip():
        logger.warning("Skipping local video send: missing channel for source=%s", source_url)
        return False
    if not local_file_path.exists():
        logger.warning("Skipping local video send: file not found=%s source=%s", local_file_path, source_url)
        return False

    filename = video_filename or local_file_path.name
    _set_progress(tqdm_iterable, f"Sending local video to Telegram channel {channel}")
    bot = Bot(token=BOT_TOKEN)
    async with bot.context():
        try:
            await _run_with_retry_after(
                lambda: bot.send_video(
                    chat_id=channel,
                    video=FSInputFile(path=local_file_path.as_posix(), filename=filename),
                    caption=page_title,
                    supports_streaming=True,
                )
            )
            return True
        except Exception as exc:
            if not _should_fallback_to_document(exc):
                logger.warning("Local send_video failed for source=%s path=%s err=%s", source_url, local_file_path, exc)
                return False
            logger.warning("Local send_video failed; using send_document fallback: %s", exc)
            try:
                await _run_with_retry_after(
                    lambda: bot.send_document(
                        chat_id=channel,
                        document=FSInputFile(path=local_file_path.as_posix(), filename=filename),
                        caption=page_title,
                    )
                )
                return True
            except Exception as fallback_exc:
                logger.warning(
                    "Local send_document fallback failed for source=%s path=%s err=%s",
                    source_url,
                    local_file_path,
                    fallback_exc,
                )
                return False


async def _download_video_to_path(
    video_url: str,
    destination_path: pathlib.Path,
    headers: dict[str, str] | None = None,
    total_size: int | None = None,
) -> pathlib.Path:
    timeout = aiohttp.ClientTimeout(total=None, sock_connect=30, sock_read=120)
    downloaded = 0
    async with aiohttp.ClientSession(timeout=timeout, headers=headers or {}) as session:
        async with session.get(video_url) as response:
            response.raise_for_status()
            content_length = int(response.headers.get("Content-Length") or 0) or total_size
            async with aiofiles.open(destination_path, "wb") as f:
                async for chunk in response.content.iter_chunked(CHUNK_SIZE):
                    if chunk:
                        await f.write(chunk)
                        downloaded += len(chunk)
                        if content_length:
                            pct = min(100, int(downloaded / content_length * 100))
                            print(f"\r[grabber] downloading {pct}% ({_format_size_bytes(downloaded)} / {_format_size_bytes(content_length)})", end="", flush=True)
                        else:
                            print(f"\r[grabber] downloading {_format_size_bytes(downloaded)}", end="", flush=True)
    print(flush=True)
    return destination_path


_ROTATION_TO_TRANSPOSE: dict[int, str] = {
    90: "transpose=1",
    180: "transpose=1,transpose=1",
    270: "transpose=2",
}


async def _get_video_rotation(path: pathlib.Path) -> int:
    """Return clockwise rotation in degrees (0, 90, 180, 270) from stream metadata."""
    try:
        proc = await asyncio.create_subprocess_exec(
            "ffprobe", "-v", "quiet",
            "-select_streams", "v:0",
            "-print_format", "json",
            "-show_streams",
            str(path),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.DEVNULL,
        )
        stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=30)
        data = json.loads(stdout.decode())
        stream = (data.get("streams") or [{}])[0]
        for sd in stream.get("side_data_list", []):
            if "rotation" in sd:
                return (-int(sd["rotation"])) % 360
        rotate_tag = stream.get("tags", {}).get("rotate")
        if rotate_tag:
            return int(rotate_tag) % 360
    except Exception:
        logger.debug("Failed to detect video rotation for %s", path)
    return 0


async def _get_video_duration_seconds(path: pathlib.Path) -> float | None:
    try:
        proc = await asyncio.create_subprocess_exec(
            "ffprobe", "-v", "error",
            "-show_entries", "format=duration",
            "-of", "default=noprint_wrappers=1:nokey=1",
            str(path),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.DEVNULL,
        )
        stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=30)
    except Exception:
        return None
    else:
        return float(stdout.decode().strip())


async def _compress_video(src: pathlib.Path, dst: pathlib.Path, duration: float) -> pathlib.Path | None:
    total_kbps = int((FFMPEG_TARGET_SIZE_BYTES * 8) / (duration * 1000))
    video_kbps = max(100, total_kbps - FFMPEG_AUDIO_BITRATE_KBPS)
    src_size = _format_size_bytes(src.stat().st_size)
    print(f"[grabber] compressing video ({src_size} → target {_format_size_bytes(FFMPEG_TARGET_SIZE_BYTES)}) ...", flush=True)

    rotation = await _get_video_rotation(src)
    transpose = _ROTATION_TO_TRANSPOSE.get(rotation, "")
    scale = "scale=trunc(iw/2)*2:trunc(ih/2)*2,setsar=1"
    vf = f"{transpose},{scale}" if transpose else scale
    if rotation:
        print(f"[grabber] detected rotation={rotation}°, applying transpose", flush=True)

    try:
        proc = await asyncio.create_subprocess_exec(
            "ffmpeg", "-y",
            "-noautorotate",       # disable auto-rotate; we apply transpose explicitly
            "-i", str(src),
            "-b:v", f"{video_kbps}k",
            "-b:a", f"{FFMPEG_AUDIO_BITRATE_KBPS}k",
            "-vcodec", "libx264",
            "-acodec", "aac",
            "-vf", vf,
            "-metadata:s:v:0", "rotate=0",
            "-movflags", "+faststart",
            "-progress", "pipe:1",
            "-nostats",
            str(dst),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.DEVNULL,
        )
        if proc.stdout:
            async for raw in proc.stdout:
                line = raw.decode().strip()
                if line.startswith("out_time_ms="):
                    val = line.split("=", 1)[1]
                    if val.lstrip("-").isdigit():
                        pct = min(100, int(int(val) / 1000 / duration * 100))
                        print(f"\r[grabber] compress {pct}%  ", end="", flush=True)
        await asyncio.wait_for(proc.wait(), timeout=600)
        print(flush=True)
    except Exception as exc:
        logger.warning("ffmpeg compress failed: %s", exc)
        return None
    else:
        if proc.returncode != 0:
            logger.warning("ffmpeg compress exited with code %d", proc.returncode)
            return None
        result_size = _format_size_bytes(dst.stat().st_size)
        print(f"[grabber] compressed → {result_size}", flush=True)
        return dst


async def _normalize_rotation(src: pathlib.Path, out_dir: pathlib.Path, rotation: int) -> pathlib.Path:
    """Re-encode src applying transpose for rotation, output to out_dir. Returns output path."""
    dst = out_dir / f"normalized_{src.name}"
    transpose = _ROTATION_TO_TRANSPOSE.get(rotation, "")
    scale = "scale=trunc(iw/2)*2:trunc(ih/2)*2,setsar=1"
    vf = f"{transpose},{scale}" if transpose else scale
    proc = await asyncio.create_subprocess_exec(
        "ffmpeg", "-y", "-noautorotate", "-i", str(src),
        "-c:v", "libx264", "-c:a", "copy",
        "-vf", vf,
        "-metadata:s:v:0", "rotate=0",
        "-movflags", "+faststart",
        str(dst),
        stdout=asyncio.subprocess.DEVNULL,
        stderr=asyncio.subprocess.DEVNULL,
    )
    await asyncio.wait_for(proc.wait(), timeout=600)
    return dst if proc.returncode == 0 else src


async def _split_video(src: pathlib.Path, out_dir: pathlib.Path) -> list[pathlib.Path]:
    rotation = await _get_video_rotation(src)
    duration = await _get_video_duration_seconds(src)
    if not duration:
        return []

    split_src = src
    if rotation:
        print(f"[grabber] detected rotation={rotation}°, normalizing before split ...", flush=True)
        split_src = await _normalize_rotation(src, out_dir, rotation)

    n_segments = max(2, int(src.stat().st_size / FFMPEG_TARGET_SIZE_BYTES) + 1)
    segment_duration = duration / n_segments
    pattern = str(out_dir / "segment_%03d.mp4")
    print(f"[grabber] splitting into {n_segments} segments ({segment_duration:.1f}s each) ...", flush=True)
    try:
        proc = await asyncio.create_subprocess_exec(
            "ffmpeg", "-y", "-i", str(split_src),
            "-c", "copy",
            "-f", "segment",
            "-segment_time", str(segment_duration),
            "-reset_timestamps", "1",
            "-progress", "pipe:1",
            "-nostats",
            pattern,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.DEVNULL,
        )
        if proc.stdout:
            async for raw in proc.stdout:
                line = raw.decode().strip()
                if line.startswith("out_time_ms="):
                    val = line.split("=", 1)[1]
                    if val.lstrip("-").isdigit():
                        pct = min(100, int(int(val) / 1000 / duration * 100))
                        print(f"\r[grabber] split {pct}%  ", end="", flush=True)
        await asyncio.wait_for(proc.wait(), timeout=600)
        print(flush=True)
    except Exception as exc:
        logger.warning("ffmpeg split failed: %s", exc)
        return []
    else:
        if proc.returncode != 0:
            logger.warning("ffmpeg split exited with code %d", proc.returncode)
            return []
        segments = sorted(out_dir.glob("segment_*.mp4"))
        print(f"[grabber] split → {len(segments)} segments", flush=True)
        return segments


async def send_videos_to_channel(
    channel: str,
    page_title: str,
    source_url: str,
    ordered_unique_video_urls: IndexedSet,
    headers: dict[str, str] | None = None,
    tqdm_iterable: tqdm | None = None,
) -> VideoDeliveryStats:
    stats = VideoDeliveryStats(
        total_found=len(ordered_unique_video_urls),
        total_after_checkpoint=0,
        sent_count=0,
        skipped_count=0,
        fallback_download_count=0,
        fallback_document_count=0,
        failed_count=0,
    )
    if not channel.strip():
        stats.skipped_count = stats.total_found
        logger.warning("Skipping telegra.ph video send: missing --channel for source=%s", source_url)
        return stats

    checkpoint_service = build_checkpoint_service()
    decision = checkpoint_service.filter_media(
        source_url=source_url,
        ordered_unique_img_urls=IndexedSet(),
        ordered_unique_video_urls=ordered_unique_video_urls,
    )
    videos_to_send = decision.new_videos or IndexedSet()
    stats.total_after_checkpoint = len(videos_to_send)
    stats.skipped_count = decision.skipped_videos_count
    if not videos_to_send:
        _set_progress(tqdm_iterable, f"No new videos for {page_title}; checkpoint skipped send")
        return stats

    _set_progress(
        tqdm_iterable,
        f"Sending {len(videos_to_send)} telegra.ph videos to Telegram channel {channel}",
    )
    sent_records = IndexedSet()
    bot = Bot(token=BOT_TOKEN)
    async with bot.context():
        with tempfile.TemporaryDirectory(prefix="grabber-video-") as temp_dir:
            temp_root = pathlib.Path(temp_dir)
            for index, media_record in enumerate(videos_to_send, start=1):
                video_src = _extract_video_src(media_record)
                if not video_src:
                    logger.warning("Skipping empty video source for page=%s source=%s", page_title, source_url)
                    stats.failed_count += 1
                    continue

                video_filename = _extract_video_filename(media_record, index=index, source_url=video_src)
                caption = f"{page_title}\n{source_url}"
                print("[grabber] probing remote size ...", flush=True)
                remote_size_bytes = await _probe_remote_file_size(video_src, headers=headers)
                print(f"[grabber] remote size: {_format_size_bytes(remote_size_bytes)}", flush=True)

                if remote_size_bytes is not None and remote_size_bytes > BOT_UPLOAD_MAX_BYTES:
                    print("[grabber] video exceeds 50MB — will download then compress/split", flush=True)

                can_try_url_input = remote_size_bytes is None or remote_size_bytes <= URL_INPUT_MAX_BYTES

                if can_try_url_input:
                    print("[grabber] trying direct Telegram upload (URLInputFile) ...", flush=True)
                    try:
                        await _run_with_retry_after(
                            lambda: bot.send_video(
                                chat_id=channel,
                                video=URLInputFile(url=video_src, headers=headers or {}, filename=video_filename),
                                caption=caption,
                                supports_streaming=True,
                            )
                        )
                        stats.sent_count += 1
                        sent_records.add(media_record)
                        continue
                    except Exception as exc:
                        print(f"[grabber] URLInputFile failed ({exc}); falling back to download", flush=True)
                else:
                    print(f"[grabber] size >{_format_size_bytes(URL_INPUT_MAX_BYTES)}, skipping URLInputFile", flush=True)

                downloaded_file: pathlib.Path | None = None
                try:
                    print("[grabber] downloading to temp file ...", flush=True)
                    downloaded_file = await _download_video_to_path(
                        video_url=video_src,
                        destination_path=temp_root / video_filename,
                        headers=headers,
                        total_size=remote_size_bytes,
                    )
                    stats.fallback_download_count += 1

                    downloaded_size_bytes = downloaded_file.stat().st_size
                    if downloaded_size_bytes <= BOT_UPLOAD_MAX_BYTES:
                        print(f"[grabber] downloaded {_format_size_bytes(downloaded_size_bytes)} — under 50MB, uploading as-is", flush=True)
                    if downloaded_size_bytes > BOT_UPLOAD_MAX_BYTES:
                        print(f"[grabber] downloaded {_format_size_bytes(downloaded_size_bytes)} — exceeds 50MB", flush=True)
                        duration = await _get_video_duration_seconds(downloaded_file)
                        segments: list[pathlib.Path] = []

                        if duration:
                            if downloaded_size_bytes <= COMPRESS_MAX_BYTES:
                                compressed = temp_root / f"compressed_{video_filename}"
                                result = await _compress_video(downloaded_file, compressed, duration)
                                if result and result.stat().st_size <= BOT_UPLOAD_MAX_BYTES:
                                    segments = [result]
                                else:
                                    split_src = result if (result and result.exists()) else downloaded_file
                                    segments = await _split_video(split_src, temp_root)
                            else:
                                print(f"[grabber] {_format_size_bytes(downloaded_size_bytes)} > 80MB — splitting directly", flush=True)
                                segments = await _split_video(downloaded_file, temp_root)

                        if not segments:
                            logger.warning("compress/split failed; falling back to link-only for %s", video_src)
                            try:
                                await _send_link_only_message(
                                    bot=bot,
                                    channel=channel,
                                    page_title=page_title,
                                    video_url=video_src,
                                    size_bytes=downloaded_size_bytes,
                                )
                            except Exception as exc:
                                logger.warning("link-only fallback also failed for %s: %s", video_src, exc)
                                stats.failed_count += 1
                                continue
                            stats.sent_count += 1
                            stats.link_only_count += 1
                            sent_records.add(media_record)
                            continue

                        total_segs = len(segments)
                        for seg_idx, seg_path in enumerate(segments, start=1):
                            seg_caption = (
                                f"{caption} ({seg_idx}/{total_segs})" if total_segs > 1 else caption
                            )
                            try:
                                await _run_with_retry_after(
                                    lambda p=seg_path, c=seg_caption: bot.send_video(
                                        chat_id=channel,
                                        video=FSInputFile(path=p.as_posix(), filename=p.name),
                                        caption=c,
                                        supports_streaming=True,
                                    )
                                )
                            except Exception as exc:
                                logger.warning("Failed sending segment %s: %s", seg_path.name, exc)
                                stats.failed_count += 1

                        stats.sent_count += 1
                        sent_records.add(media_record)
                        continue

                    try:
                        await _run_with_retry_after(
                            lambda: bot.send_video(
                                chat_id=channel,
                                video=FSInputFile(path=downloaded_file.as_posix(), filename=video_filename),
                                caption=caption,
                                supports_streaming=True,
                            )
                        )
                        stats.sent_count += 1
                        sent_records.add(media_record)
                        continue
                    except Exception as send_file_exc:
                        if not _should_fallback_to_document(send_file_exc):
                            raise
                        logger.warning("send_video from file failed; using send_document fallback: %s", send_file_exc)
                        stats.fallback_document_count += 1
                        await _run_with_retry_after(
                            lambda: bot.send_document(
                                chat_id=channel,
                                document=FSInputFile(path=downloaded_file.as_posix(), filename=video_filename),
                                caption=caption,
                            )
                        )
                        stats.sent_count += 1
                        sent_records.add(media_record)
                        continue
                except Exception as exc:
                    stats.failed_count += 1
                    logger.warning(
                        "Failed sending video for page=%s source=%s file=%s err=%s",
                        page_title,
                        source_url,
                        downloaded_file or video_filename,
                        exc,
                    )

    if sent_records:
        checkpoint_service.commit_media(source_url=source_url, media_records=sent_records)

    _set_progress(
        tqdm_iterable,
        (
            f"Finished telegra.ph video send for {page_title}: "
            f"sent={stats.sent_count} skipped={stats.skipped_count} "
            f"link_only={stats.link_only_count} failed={stats.failed_count}"
        ),
    )
    return stats


__all__ = [
    "VideoDeliveryStats",
    "send_link_message_to_channel",
    "send_local_video_to_channel",
    "send_videos_to_channel",
]
