from __future__ import annotations

import httpx

from grabber.core.settings import GRABBER_HTTP_CONNECT_TIMEOUT_SECONDS, GRABBER_HTTP_READ_TIMEOUT_SECONDS


def build_httpx_timeout() -> httpx.Timeout:
    return httpx.Timeout(
        connect=GRABBER_HTTP_CONNECT_TIMEOUT_SECONDS,
        read=GRABBER_HTTP_READ_TIMEOUT_SECONDS,
        write=GRABBER_HTTP_READ_TIMEOUT_SECONDS,
        pool=GRABBER_HTTP_CONNECT_TIMEOUT_SECONDS,
    )


def build_requests_timeout() -> tuple[int, int]:
    return (GRABBER_HTTP_CONNECT_TIMEOUT_SECONDS, GRABBER_HTTP_READ_TIMEOUT_SECONDS)


__all__ = ["build_httpx_timeout", "build_requests_timeout"]
