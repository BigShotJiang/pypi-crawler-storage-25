from typing import Any

from .parser import get_sources_for_erome_fan


class EromefanAdapter:
    async def run(self, **kwargs: Any) -> None:
        await get_sources_for_erome_fan(**kwargs)


__all__ = ["EromefanAdapter"]
