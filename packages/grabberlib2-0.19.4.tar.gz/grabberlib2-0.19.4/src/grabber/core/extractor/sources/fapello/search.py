from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from difflib import SequenceMatcher
from typing import Any
from urllib.parse import urlparse

import httpx

from grabber.core.settings import FAPELLO_HASH, FAPELLO_USER_ID

BASE_URL = "https://fapello.com"
SEARCH_ENDPOINT = f"{BASE_URL}/search_v2/"
DEFAULT_LIMIT = 30
DEFAULT_OFFSET = 0
DEFAULT_TIMEOUT = 30.0

FAPELLO_SEARCH_ACCEPT_HEADER = "*/*"
FAPELLO_SEARCH_USER_AGENT = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/123.0.0.0 Safari/537.36"
)


class FapelloSearchAuthError(RuntimeError):
    pass


@dataclass(slots=True)
class FapelloSearchResult:
    id: str
    name: str
    url: str
    content_count: int
    views: int


FetchSearchPayload = Callable[[str, dict[str, str], float], dict[str, Any]]


def search_models(
    query: str,
    *,
    timeout: float = DEFAULT_TIMEOUT,
    fetch_payload: FetchSearchPayload | None = None,
) -> list[FapelloSearchResult]:
    clean_query = query.strip()
    if not clean_query:
        return []

    headers = build_headers()
    payload_fetcher = fetch_payload or fetch_search_payload
    payload = payload_fetcher(clean_query, headers, timeout)
    results = parse_model_results(payload)
    return rank_model_results(results, clean_query)


def build_headers() -> dict[str, str]:
    missing = []
    if not FAPELLO_USER_ID:
        missing.append("FAPELLO_USER_ID")
    if not FAPELLO_HASH:
        missing.append("FAPELLO_HASH")
    if missing:
        raise FapelloSearchAuthError(f"Missing Fapello search auth: {', '.join(missing)}")

    return {
        "Accept": FAPELLO_SEARCH_ACCEPT_HEADER,
        "User-Agent": FAPELLO_SEARCH_USER_AGENT,
        "Cookie": f"user_id={FAPELLO_USER_ID}; hash={FAPELLO_HASH};",
    }


def fetch_search_payload(query: str, headers: dict[str, str], timeout: float) -> dict[str, Any]:
    response = httpx.get(
        SEARCH_ENDPOINT,
        headers=headers,
        params={
            "ajax": "1",
            "q": query,
            "type": "models",
            "limit": str(DEFAULT_LIMIT),
            "offset": str(DEFAULT_OFFSET),
        },
        timeout=timeout,
    )
    response.raise_for_status()
    payload = response.json()
    if not isinstance(payload, dict):
        raise TypeError(f"Expected object payload from Fapello search, got {type(payload).__name__}")
    return payload


def parse_model_results(payload: dict[str, Any]) -> list[FapelloSearchResult]:
    results = payload.get("results")
    if not isinstance(results, dict):
        return []

    models = results.get("models")
    if not isinstance(models, list):
        return []

    parsed: list[FapelloSearchResult] = []
    for model in models:
        if not isinstance(model, dict):
            continue
        url = str(model.get("url", "")).strip()
        name = str(model.get("name", "")).strip()
        if not url or not name:
            continue

        parsed.append(
            FapelloSearchResult(
                id=str(model.get("id", "")).strip(),
                name=name,
                url=url,
                content_count=_safe_int(model.get("content_count")),
                views=_safe_int(model.get("views")),
            )
        )

    return parsed


def rank_model_results(results: list[FapelloSearchResult], query: str) -> list[FapelloSearchResult]:
    normalized_query = _normalize(query)

    def sort_key(indexed_result: tuple[int, FapelloSearchResult]) -> tuple[int, float, int, int]:
        index, result = indexed_result
        bucket, similarity = _match_rank(result, normalized_query)
        return (bucket, -similarity, -result.views, index)

    return [result for _, result in sorted(enumerate(results), key=sort_key)]


def format_search_results(results: list[FapelloSearchResult]) -> str:
    blocks = []
    for result in results:
        blocks.append(
            "\n".join(
                [
                    f"Model: {result.name}",
                    f"Number of posts: {result.content_count}",
                    f"Profile page: {result.url}",
                    f"Views: {result.views}",
                    f"ID: {result.id}",
                ]
            )
        )
    return "\n\n".join(blocks)


def _match_rank(result: FapelloSearchResult, normalized_query: str) -> tuple[int, float]:
    normalized_name = _normalize(result.name)
    normalized_slug = _normalize(_slug_from_url(result.url))
    similarity = max(
        SequenceMatcher(None, normalized_query, normalized_name).ratio(),
        SequenceMatcher(None, normalized_query, normalized_slug).ratio(),
    )

    if normalized_name == normalized_query:
        return (0, similarity)
    if normalized_slug == normalized_query:
        return (1, similarity)
    if normalized_name.startswith(normalized_query) or normalized_slug.startswith(normalized_query):
        return (2, similarity)
    if normalized_query in normalized_name or normalized_query in normalized_slug:
        return (3, similarity)
    return (4, similarity)


def _normalize(value: str) -> str:
    return "".join(char for char in value.lower() if char.isalnum())


def _slug_from_url(url: str) -> str:
    parsed = urlparse(url)
    return parsed.path.strip("/").split("/", 1)[0]


def _safe_int(value: Any) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return 0


__all__ = [
    "FapelloSearchAuthError",
    "FapelloSearchResult",
    "build_headers",
    "fetch_search_payload",
    "format_search_results",
    "parse_model_results",
    "rank_model_results",
    "search_models",
]
