import pathlib
from urllib.parse import unquote, urljoin, urlparse

from boltons.setutils import IndexedSet
from bs4 import BeautifulSoup, Tag
from telegraph import Telegraph

from grabber.core.extractor import ExtractorConfig, ExtractorResult
from grabber.core.extractor.infrastructure.fetching.scraper import get_soup
from grabber.core.extractor.usecases import run_default_source

IMAGE_QUERY = "div.media-group div.img div.img-box img"
VIDEO_QUERY = "div.media-group div.video source"


def _clean_title(soup: BeautifulSoup) -> str:
    title_tag = soup.find("title")
    if title_tag is None:
        return "post-erome.fan"

    page_title = title_tag.get_text(strip=True).strip().rstrip()
    for splitter in (" - erome.fan", " | erome.fan", " - Erome.Fan", " | Erome.Fan"):
        page_title = page_title.split(splitter)[0]

    page_title = page_title.replace("https:", "").strip().rstrip()
    return page_title or "post-erome.fan"


def _normalize_media_url(source_url: str, media_url: str) -> str:
    media_url = media_url.strip().rstrip().replace("\r", "").replace("\n", "")
    if not media_url:
        return ""
    return urljoin(source_url, media_url)


def _filename_from_url(media_url: str, prefix: str, fallback_extension: str) -> str:
    parsed_url = urlparse(media_url)
    filename = unquote(pathlib.PurePosixPath(parsed_url.path).name)
    if not filename:
        filename = f"media-{prefix}{fallback_extension}"
    return f"{prefix}-{filename}"


def _extract_image_records(soup: BeautifulSoup, source_url: str) -> IndexedSet:
    records = IndexedSet()
    seen_urls = set()

    for image_tag in soup.select(IMAGE_QUERY):
        raw_src = str(image_tag.attrs.get("src") or image_tag.attrs.get("data-src") or "").strip()
        image_url = _normalize_media_url(source_url, raw_src)
        if not image_url or image_url in seen_urls:
            continue

        seen_urls.add(image_url)
        image_prefix = f"{len(records) + 1}".zfill(3)
        filename = _filename_from_url(image_url, image_prefix, ".jpg")
        records.add((filename, image_url))

    return records


def _extract_video_records(soup: BeautifulSoup, source_url: str) -> IndexedSet:
    records = IndexedSet()
    seen_urls = set()

    for source_tag in soup.select(VIDEO_QUERY):
        raw_src = str(source_tag.attrs.get("src") or "").strip()
        video_url = _normalize_media_url(source_url, raw_src)
        if not video_url or video_url in seen_urls:
            continue

        seen_urls.add(video_url)
        video_prefix = f"{len(records) + 1}".zfill(3)
        filename = _filename_from_url(video_url, video_prefix, ".mp4")
        video_tag = source_tag.find_parent("video")
        poster_url = ""
        if isinstance(video_tag, Tag):
            raw_poster = str(video_tag.attrs.get("poster") or "").strip()
            poster_url = _normalize_media_url(source_url, raw_poster)
        records.add((filename, poster_url, video_url))

    return records


async def collect_erome_fan_result(
    source_url: str,
    headers: dict[str, str] | None = None,
) -> ExtractorResult | None:
    soup = await get_soup(target_url=source_url, headers=headers)
    ordered_unique_img_urls = _extract_image_records(soup, source_url)
    ordered_unique_video_urls = _extract_video_records(soup, source_url)

    if not ordered_unique_img_urls and not ordered_unique_video_urls:
        return None

    return ExtractorResult(
        page_title=_clean_title(soup),
        ordered_unique_img_urls=ordered_unique_img_urls,
        ordered_unique_video_urls=ordered_unique_video_urls if ordered_unique_video_urls else None,
    )


async def get_sources_for_erome_fan(
    sources: list[str],
    entity: str,
    telegraph_client: Telegraph | None = None,
    final_dest: str | pathlib.Path = "",
    save_to_telegraph: bool | None = False,
    **kwargs,
) -> None:
    config = ExtractorConfig(
        query=IMAGE_QUERY,
        src_attr="src",
        result_collector=collect_erome_fan_result,
    )
    await run_default_source(
        sources=sources,
        entity=entity,
        telegraph_client=telegraph_client,
        config=config,
        final_dest=final_dest,
        save_to_telegraph=bool(save_to_telegraph or kwargs.get("channel", "")),
        channel=kwargs.get("channel", ""),
        max_pages=kwargs.get("max_pages", 50),
    )
