from urllib.parse import urljoin

from boltons.setutils import IndexedSet
from bs4 import BeautifulSoup, Tag

from grabber.core.extractor import ExtractorResult
from grabber.core.extractor.infrastructure.parsing.media import build_unique_img_urls, build_unique_video_urls
from grabber.core.extractor.infrastructure.parsing.title import get_page_title


class IbradomeParser:
    BASE_URL = "https://ibradome.com"
    VIDEO_EXTENSIONS = (".mp4", ".m4v", ".mov", ".webm")

    @staticmethod
    def build_page_title(soup: BeautifulSoup) -> str:
        return get_page_title(soup=soup, strings_to_remove=["Nude", "OnlyFans", "PhotosIbradome"])

    def extract_detail_links(self, soup: BeautifulSoup, page_url: str) -> list[str]:
        links: list[str] = []
        seen: set[str] = set()

        for tag in soup.select('a[href*="/photo/"], a[href*="/video/"]'):
            href = tag.attrs.get("href", "")
            if not isinstance(href, str) or not href:
                continue

            normalized = urljoin(page_url, href)
            if not normalized.startswith(self.BASE_URL):
                continue
            if "/creator/" not in normalized:
                continue
            if normalized in seen:
                continue

            seen.add(normalized)
            links.append(normalized)

        return links

    def extract_next_page_url(self, soup: BeautifulSoup, page_url: str) -> str | None:
        next_link = soup.select_one('a[rel="next"][href], a[href*="page="][aria-label*="Next" i]')
        if next_link is None:
            return None

        href = next_link.attrs.get("href")
        if not isinstance(href, str) or not href:
            return None

        return urljoin(page_url, href)

    def extract_main_image_tags(self, soup: BeautifulSoup) -> list[Tag]:
        tags = [tag for tag in soup.select("img.single-stage-media[src]") if not self._is_video_tag(tag)]
        if tags:
            return tags

        return [
            tag
            for tag in soup.select(
                'article.post div.img-wrapper div.item img[src], img[src*="/Media/"]:not([src*="/m_"])'
            )
            if not self._is_video_tag(tag)
        ]

    def extract_video_tags(self, soup: BeautifulSoup) -> list[Tag]:
        tags = list(soup.select("video[src], video source[src]"))
        tags.extend(tag for tag in soup.select("img[src]") if self._is_video_tag(tag))
        return tags

    def _is_video_tag(self, tag: Tag) -> bool:
        src = tag.attrs.get("src")
        if not isinstance(src, str):
            return False

        normalized = src.split("?", 1)[0].lower()
        return normalized.endswith(self.VIDEO_EXTENSIONS)

    async def parse_result(
        self,
        soup: BeautifulSoup,
        image_tags: list[Tag],
        src_attr: str,
        video_tags: list[Tag] | None = None,
    ) -> ExtractorResult | None:
        # Preserve website/DOM order so Telegraph chunks match source chronology.
        ordered_unique_video_urls = IndexedSet()

        ordered_unique_img_urls = await build_unique_img_urls(image_tags, src_attr)

        if video_tags is not None:
            ordered_unique_video_urls = await build_unique_video_urls(video_tags, src_attr)

        if not ordered_unique_img_urls and not ordered_unique_video_urls:
            return None

        return ExtractorResult(
            page_title=self.build_page_title(soup),
            ordered_unique_img_urls=ordered_unique_img_urls,
            ordered_unique_video_urls=ordered_unique_video_urls or None,
        )
