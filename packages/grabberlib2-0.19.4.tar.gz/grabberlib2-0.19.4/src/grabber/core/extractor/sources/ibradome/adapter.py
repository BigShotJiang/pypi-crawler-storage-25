from urllib.parse import urlencode, urlparse, urlunparse

import httpx
from bs4 import BeautifulSoup, Tag

from grabber.core.extractor.infrastructure.checkpoints import SourceCheckpointHint
from grabber.core.extractor.infrastructure.fetching.timeouts import build_httpx_timeout

from .parser import IbradomeParser


class IbradomeAdapter:
    base_url = "https://ibradome.com"

    def __init__(self) -> None:
        self._checkpoint_hint: SourceCheckpointHint | None = None

    def configure_checkpoint_hint(self, checkpoint_hint: SourceCheckpointHint | None) -> None:
        self._checkpoint_hint = checkpoint_hint

    def fetch_soup(self, url: str, headers: dict[str, str] | None = None) -> BeautifulSoup:
        response = httpx.get(url=url, headers=headers, follow_redirects=True, timeout=build_httpx_timeout())
        response.raise_for_status()
        return BeautifulSoup(response.text, features="lxml")

    async def collect_result(
        self,
        source_url: str,
        headers: dict[str, str] | None,
        max_pages: int,
        parser: IbradomeParser,
    ):
        source_soup = self.fetch_soup(source_url, headers=headers)
        detail_links = self._collect_detail_links(
            source_url=source_url,
            source_soup=source_soup,
            headers=headers,
            max_pages=max_pages,
            parser=parser,
        )

        if not detail_links:
            image_tags = parser.extract_main_image_tags(source_soup)
            video_tags = parser.extract_video_tags(source_soup)
            self._normalize_media_tags(image_tags + video_tags, source_url=source_url)
            return await parser.parse_result(
                soup=source_soup,
                image_tags=image_tags,
                video_tags=video_tags,
                src_attr="src",
            )

        image_tags: list[Tag] = []
        video_tags: list[Tag] = []
        for detail_url in detail_links:
            detail_soup = self.fetch_soup(detail_url, headers=headers)
            detail_image_tags = parser.extract_main_image_tags(detail_soup)
            detail_video_tags = parser.extract_video_tags(detail_soup)
            self._normalize_media_tags(detail_image_tags + detail_video_tags, source_url=detail_url)
            image_tags.extend(detail_image_tags)
            video_tags.extend(detail_video_tags)

        return await parser.parse_result(
            soup=source_soup,
            image_tags=image_tags,
            video_tags=video_tags,
            src_attr="src",
        )

    async def get_media_from_page(
        self,
        url: str,
        headers: dict[str, str] | None = None,
        query: str = "",
        src_attr: str = "src",
    ) -> tuple[list[Tag], list[Tag]]:
        images_tags: list[Tag] = []
        videos_tags: list[Tag] = []

        soup = self.fetch_soup(url, headers=headers)
        current_image_tags = soup.select(query)

        for tag in current_image_tags:
            src = tag.attrs.get(src_attr, "")

            if not src.startswith("http") and ".svg" not in src:
                src = f"{self.base_url}/{src.lstrip('/')}"
                tag.attrs[src_attr] = src  # Update tag with absolute URL for downstream processing
                images_tags.append(tag)  # Add tag to images_tags since it has a valid src now

        return images_tags, videos_tags

    def _collect_detail_links(
        self,
        source_url: str,
        source_soup: BeautifulSoup,
        headers: dict[str, str] | None,
        max_pages: int,
        parser: IbradomeParser,
    ) -> list[str]:
        links: list[str] = []
        seen: set[str] = set()
        page_url: str | None = source_url
        page_soup = source_soup

        for page_number in range(1, max_pages + 1):
            for detail_url in parser.extract_detail_links(page_soup, page_url or source_url):
                if detail_url in seen:
                    continue
                seen.add(detail_url)
                links.append(detail_url)

            next_url = parser.extract_next_page_url(page_soup, page_url or source_url)
            if next_url is None:
                next_url = self._build_next_creator_page_url(source_url, page_number + 1) if page_number == 1 else None
                if next_url is None:
                    break

            if next_url in seen:
                break
            page_url = next_url
            page_soup = self.fetch_soup(page_url, headers=headers)
            if not parser.extract_detail_links(page_soup, page_url):
                break

        return links

    def _build_next_creator_page_url(self, source_url: str, next_page_number: int) -> str | None:
        parsed = urlparse(source_url)
        path_parts = [part for part in parsed.path.split("/") if part]
        if len(path_parts) != 2 or path_parts[0] != "creator" or next_page_number <= 1:
            return None

        return urlunparse(parsed._replace(query=urlencode({"page": str(next_page_number)})))

    def _normalize_media_tags(self, tags: list[Tag], source_url: str) -> None:
        for tag in tags:
            src = tag.attrs.get("src")
            if isinstance(src, str) and src.startswith("/"):
                tag.attrs["src"] = f"{self.base_url}/{src.lstrip('/')}"

            poster = tag.attrs.get("poster")
            if isinstance(poster, str) and poster.startswith("/"):
                tag.attrs["poster"] = f"{self.base_url}/{poster.lstrip('/')}"
