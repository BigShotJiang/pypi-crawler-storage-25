from __future__ import annotations

from dataclasses import dataclass
from typing import Any
from urllib.parse import urlencode, urlparse

from boltons.setutils import IndexedSet
from bs4 import BeautifulSoup

from grabber.core.extractor import ExtractorResult


@dataclass(frozen=True, slots=True)
class LadysoneTargetRef:
    section: str
    slug: str


class LadysoneParser:
    TITLE_SUFFIX = ", new Nude photos and Porn videos"

    def parse_target_reference(self, source_url: str) -> LadysoneTargetRef:
        parsed = urlparse(source_url)
        path_parts = [part for part in parsed.path.split("/") if part]
        if len(path_parts) != 2 or not path_parts[0] or not path_parts[1].startswith("u-"):
            raise ValueError(f"Unsupported ladys.one source URL: {source_url}")

        slug = path_parts[1][2:].strip()
        if not slug:
            raise ValueError(f"Unsupported ladys.one source URL: {source_url}")

        return LadysoneTargetRef(section=path_parts[0], slug=slug)

    def build_profile_page_url(self, target_ref: LadysoneTargetRef) -> str:
        return f"https://ladys.one/{target_ref.section}/u-{target_ref.slug}"

    def build_api_endpoint(self, target_ref: LadysoneTargetRef, page: int) -> str:
        query = urlencode({"slug": target_ref.slug, "page": page})
        return f"https://ladys.one/{target_ref.section}/api/v1/user/profile-public/load-adverts?{query}"

    def extract_profile_title(self, html: str, fallback_slug: str, fallback_author: str | None = None) -> str:
        soup = BeautifulSoup(html, features="lxml")
        title_tag = soup.select_one("title")
        title = title_tag.get_text(strip=True) if title_tag is not None else ""
        creator_name = self._extract_creator_name(title)
        if not creator_name:
            creator_name = self._clean_creator_name(fallback_author or "")
        if not creator_name:
            creator_name = self._clean_creator_name(fallback_slug.replace("-", " "))
        return self._format_hashtag_title(creator_name or fallback_slug)

    def extract_media_from_adverts(self, adverts: list[dict[str, Any]]) -> tuple[list[str], list[str], str | None]:
        image_urls: list[str] = []
        video_urls: list[str] = []
        seen_urls: set[str] = set()
        author_name: str | None = None

        for advert in adverts:
            if author_name is None:
                raw_author = advert.get("author")
                if isinstance(raw_author, dict):
                    candidate_author = str(raw_author.get("name", "")).strip()
                    if candidate_author:
                        author_name = candidate_author

            for photo in advert.get("photos", []) or []:
                if not isinstance(photo, dict):
                    continue
                candidate_url = str(photo.get("url", "")).strip()
                if candidate_url and candidate_url not in seen_urls:
                    seen_urls.add(candidate_url)
                    image_urls.append(candidate_url)

            video = advert.get("video")
            if isinstance(video, dict):
                candidate_url = str(video.get("url", "")).strip()
                if candidate_url and candidate_url not in seen_urls:
                    seen_urls.add(candidate_url)
                    video_urls.append(candidate_url)

        return image_urls, video_urls, author_name

    def build_extractor_result(
        self, title: str, image_urls: list[str], video_urls: list[str]
    ) -> ExtractorResult | None:
        if not image_urls and not video_urls:
            return None

        image_records = IndexedSet(
            (self._build_filename(index, image_url), image_url) for index, image_url in enumerate(image_urls, start=1)
        )
        video_records = IndexedSet(
            (self._build_filename(index, video_url), "", video_url)
            for index, video_url in enumerate(video_urls, start=1)
        )

        return ExtractorResult(
            page_title=title,
            ordered_unique_img_urls=image_records,
            ordered_unique_video_urls=video_records if video_records else None,
        )

    def extract_advert_list(self, payload: dict[str, Any]) -> list[dict[str, Any]]:
        try:
            raw_list = payload["data"]["advertData"]["list"]
        except Exception as exc:
            raise RuntimeError("ladys.one payload is missing data.advertData.list") from exc

        if not isinstance(raw_list, list):
            raise TypeError("ladys.one payload contains non-list data.advertData.list")

        return [advert for advert in raw_list if isinstance(advert, dict)]

    def _extract_creator_name(self, title: str) -> str:
        cleaned = title.strip()
        if not cleaned:
            return ""
        if self.TITLE_SUFFIX in cleaned:
            cleaned = cleaned.split(self.TITLE_SUFFIX, 1)[0]
        elif "," in cleaned:
            cleaned = cleaned.split(",", 1)[0]
        return self._clean_creator_name(cleaned)

    def _clean_creator_name(self, value: str) -> str:
        return " ".join(part for part in str(value).strip().split() if part)

    def _format_hashtag_title(self, creator_name: str) -> str:
        hashtags = []
        for token in creator_name.split("/"):
            normalized = "".join(ch for ch in token if ch.isalnum())
            if normalized:
                hashtags.append(f"#{normalized}")
        if not hashtags:
            compact = "".join(ch for ch in creator_name if ch.isalnum()) or "ladysone"
            hashtags.append(f"#{compact}")
        return " ".join(hashtags)

    def _build_filename(self, index: int, media_url: str) -> str:
        filename = media_url.split("/")[-1].split("?", 1)[0]
        if not filename:
            filename = f"media-{index}"
        return f"{index:04d}-{filename}"
