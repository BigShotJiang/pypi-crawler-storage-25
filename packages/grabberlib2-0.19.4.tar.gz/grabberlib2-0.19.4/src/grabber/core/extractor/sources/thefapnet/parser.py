import base64
import binascii
import pathlib
import re
from typing import cast
from urllib.parse import parse_qs, unquote, urljoin, urlparse

import httpx
from boltons.setutils import IndexedSet
from bs4 import BeautifulSoup, Tag
from telegraph import Telegraph
from unidecode import unidecode
from url_parser import parse_url

from grabber.core.extractor import ExtractorConfig, ExtractorResult
from grabber.core.extractor.constants import query_mapping
from grabber.core.extractor.infrastructure.fetching.scraper import get_soup
from grabber.core.extractor.infrastructure.fetching.timeouts import build_httpx_timeout
from grabber.core.extractor.infrastructure.parsing.media import build_unique_img_urls
from grabber.core.extractor.usecases import run_default_source

NUMBERS_PATTERN = r"\d+(?:,\d+)*"
THEFAPNET_VIDEO_URL_PATTERN = re.compile(r"https?://[^\s\"'<>]+?\.mp4(?:\?[^\s\"'<>]+)?", flags=re.IGNORECASE)
THEFAPNET_IMAGE_CHECK_TIMEOUT_SECONDS = 12
THEFAPNET_IMAGE_CHECK_HEADERS = {
    "Accept": "image/avif,image/webp,image/apng,image/*,*/*;q=0.8",
    "Referer": "https://thefap.net/",
    "User-Agent": (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36"
    ),
}


def _extract_media_url(record: tuple[str, ...]) -> str | None:
    if not record:
        return None
    media_url = record[-1].strip()
    return media_url if media_url else None


def _classify_content_type(content_type: str) -> bool | None:
    normalized = content_type.split(";")[0].strip().lower()
    if not normalized:
        return None
    if normalized.startswith("image/"):
        return True
    if normalized in {"text/html", "text/plain", "application/json", "application/javascript"}:
        return False
    return None


def _resolve_url_and_check(client: httpx.Client, media_url: str) -> tuple[str, bool | None]:
    """Returns (final_url_after_redirects, is_image).

    Follows redirects so that thefap.net permalink URLs are resolved to their
    actual CDN targets.  The caller should embed final_url in the record so
    Telegraph receives the direct CDN URL instead of a redirect chain.
    """
    try:
        response = client.head(media_url, headers=THEFAPNET_IMAGE_CHECK_HEADERS)
        final_url = str(response.url)
        if response.status_code >= 400:
            return final_url, False
        classified = _classify_content_type(response.headers.get("Content-Type", ""))
        if classified is not None:
            return final_url, classified
    except Exception:
        final_url = media_url

    try:
        probe_headers = {**THEFAPNET_IMAGE_CHECK_HEADERS, "Range": "bytes=0-1024"}
        with client.stream("GET", media_url, headers=probe_headers) as response:
            final_url = str(response.url)
            if response.status_code >= 400:
                return final_url, False
            return final_url, _classify_content_type(response.headers.get("Content-Type", ""))
    except Exception:
        return media_url, None


def filter_unreachable_image_urls(ordered_unique_img_urls: IndexedSet) -> IndexedSet:
    if not ordered_unique_img_urls:
        return ordered_unique_img_urls

    filtered_urls = IndexedSet()
    with httpx.Client(timeout=THEFAPNET_IMAGE_CHECK_TIMEOUT_SECONDS, follow_redirects=True) as client:
        for media_record in ordered_unique_img_urls:
            media_url = _extract_media_url(media_record)
            if not media_url or "http" not in media_url:
                continue

            final_url, is_usable = _resolve_url_and_check(client, media_url)
            if is_usable is not True:
                continue

            if final_url and final_url != media_url:
                filtered_urls.add((*media_record[:-1], final_url))
            else:
                filtered_urls.add(media_record)

    return filtered_urls


def _normalize_video_candidate(candidate: str, base_url: str) -> str:
    normalized = candidate.strip().replace("&amp;", "&")
    if not normalized:
        return ""
    if normalized.startswith("//"):
        return f"https:{normalized}"
    if normalized.startswith("play.php"):
        return urljoin("https://thefap.net/", normalized)
    return urljoin(base_url, normalized)


def _decode_base64_url(value: str) -> str | None:
    encoded = unquote(value).strip()
    if not encoded:
        return None
    padded = encoded + "=" * (-len(encoded) % 4)

    for decoder in (base64.b64decode, base64.urlsafe_b64decode):
        try:
            decoded = decoder(padded).decode("utf-8").strip()
        except (binascii.Error, UnicodeDecodeError, ValueError):
            continue
        if decoded.startswith(("http://", "https://")):
            return decoded
    return None


def _decode_url_from_candidate(candidate_url: str) -> str | None:
    decoded_url = _decode_base64_url(candidate_url)
    if decoded_url:
        return decoded_url

    parsed = urlparse(candidate_url)
    query = parse_qs(parsed.query)
    file_values = query.get("file", [])
    if not file_values and "file=" in candidate_url:
        file_values = [candidate_url.split("file=", 1)[-1].split("&", 1)[0]]

    for value in file_values:
        decoded = _decode_base64_url(value)
        if decoded:
            return decoded
    return None


def _decode_video_url_from_file_param(candidate_url: str) -> str | None:
    decoded_url = _decode_url_from_candidate(candidate_url)
    if decoded_url and ".mp4" in decoded_url.lower():
        return decoded_url
    return None


def _extract_filename_from_video_url(video_url: str, index: int) -> str:
    filename = pathlib.Path(unquote(urlparse(video_url).path)).name.strip()
    if not filename:
        filename = f"video-{index:03d}.mp4"
    if "." not in filename:
        filename = f"{filename}.mp4"
    return f"{index:03d}-{filename}"


def _extract_direct_video_urls_from_soup(soup: BeautifulSoup, base_url: str) -> list[str]:
    video_urls = IndexedSet()

    for tag in soup.select("video.jw-video[src], video[src], source[src]"):
        src = str(tag.attrs.get("src", "")).strip()
        if src:
            video_urls.add(_normalize_video_candidate(src, base_url))

    for match in THEFAPNET_VIDEO_URL_PATTERN.findall(str(soup)):
        video_urls.add(_normalize_video_candidate(match, base_url))

    return [url for url in video_urls if url.startswith(("http://", "https://"))]


def _extract_video_candidate_urls_from_soup(soup: BeautifulSoup, base_url: str) -> list[str]:
    candidate_urls = IndexedSet()
    candidate_attrs = ("src", "href", "value", "data-src", "data-url", "data-file", "data-video", "onclick")

    for tag in soup.select(
        "iframe[src], a[href], button[value], [data-src], [data-url], [data-file], [data-video], [onclick]"
    ):
        for attr in candidate_attrs:
            raw_value = tag.attrs.get(attr)
            if raw_value is None:
                continue
            value = " ".join(raw_value) if isinstance(raw_value, list) else str(raw_value)
            if not value:
                continue

            for url_match in re.findall(r"https?://[^\s\"'<>]+", value):
                if "play.php" in url_match or "file=" in url_match or ".mp4" in url_match.lower():
                    candidate_urls.add(_normalize_video_candidate(url_match, base_url))

            if attr == "data-file" and "http" not in value and "file=" not in value:
                candidate_urls.add(_normalize_video_candidate(f"play.php?file={value}", base_url))
                continue

            if attr == "value":
                decoded_url = _decode_base64_url(value)
                if decoded_url:
                    candidate_urls.add(_normalize_video_candidate(decoded_url, base_url))
                    continue

            if attr != "onclick" and ("play.php" in value or "file=" in value or ".mp4" in value.lower()):
                candidate_urls.add(_normalize_video_candidate(value, base_url))

    for direct_video_url in _extract_direct_video_urls_from_soup(soup, base_url):
        candidate_urls.add(direct_video_url)

    return [url for url in candidate_urls if url]


def _extract_video_page_urls_from_soup(soup: BeautifulSoup, base_url: str) -> list[str]:
    video_page_urls = IndexedSet()

    for anchor in soup.select("a[href]"):
        href = str(anchor.attrs.get("href", "")).strip()
        if not href:
            continue
        has_play_icon = any("icon-play" in str(img.attrs.get("src", "")) for img in anchor.select("img[src]"))
        normalized_url = urljoin(base_url, href)
        path = urlparse(normalized_url).path
        looks_like_media_page = re.search(r"/[^/]+-\d+/[^/]+/i\d+/?$", path) is not None
        if has_play_icon or looks_like_media_page:
            video_page_urls.add(normalized_url)

    return list(video_page_urls)


def _fetch_player_soup(candidate_url: str, headers: dict[str, str] | None = None) -> BeautifulSoup | None:
    try:
        response = httpx.get(
            candidate_url,
            headers=headers,
            follow_redirects=True,
            timeout=build_httpx_timeout(),
        )
        if response.status_code >= 400:
            return None
    except Exception:
        return None
    return BeautifulSoup(response.content, features="html.parser")


def _resolve_video_candidate(
    candidate_url: str,
    headers: dict[str, str] | None = None,
    depth: int = 0,
) -> str | None:
    if depth > 4:
        return None

    if ".mp4" in candidate_url.lower() and "play.php" not in candidate_url:
        return candidate_url

    decoded_url = _decode_url_from_candidate(candidate_url)
    if decoded_url:
        if ".mp4" in decoded_url.lower():
            return decoded_url
        if decoded_url != candidate_url:
            return _resolve_video_candidate(decoded_url, headers=headers, depth=depth + 1)

    if "play.php" not in candidate_url:
        return None

    player_soup = _fetch_player_soup(candidate_url, headers=headers)
    if player_soup is None:
        return None

    direct_video_urls = _extract_direct_video_urls_from_soup(player_soup, candidate_url)
    for direct_video_url in direct_video_urls:
        resolved_url = _resolve_video_candidate(direct_video_url, headers=headers, depth=depth + 1)
        if resolved_url:
            return resolved_url
    return None


def _build_video_records_from_candidates(
    candidate_urls: list[str],
    headers: dict[str, str] | None = None,
) -> IndexedSet:
    video_records = IndexedSet()
    seen_video_urls = set()

    for candidate_url in candidate_urls:
        video_url = _resolve_video_candidate(candidate_url, headers=headers)
        if not video_url or video_url in seen_video_urls:
            continue
        seen_video_urls.add(video_url)
        filename = _extract_filename_from_video_url(video_url, len(video_records) + 1)
        video_records.add((filename, video_url))

    return video_records


async def get_pages_from_pagination(
    url: str,
    headers: dict[str, str] | None = None,
    max_pages: int = 50,
) -> list[str]:
    query, _ = query_mapping["thefap.net"]
    parsed_url = parse_url(url)
    model_id = parsed_url["path"].replace("/", "").split("-")[-1]
    source_urls = []
    page_number = 1

    while page_number <= max_pages:
        target_url = f"https://thefap.net/ajax/model/{model_id}/page-{page_number}"
        page_response = httpx.get(url=target_url, headers=headers, timeout=build_httpx_timeout())
        page_content = page_response.content.decode("utf-8")
        if not page_content.strip():
            break
        soup = BeautifulSoup(page_content, features="html.parser")
        image_tags = [tag for tag in soup.select(query) if "icon" not in tag.attrs.get("src", "")]
        video_candidates = _extract_video_candidate_urls_from_soup(soup, target_url)
        if not image_tags and not video_candidates:
            break
        source_urls.append(target_url)
        page_number += 1

    return source_urls


def get_page_title(soup: BeautifulSoup) -> str:
    page_title = cast(Tag, soup.find("title")).get_text(strip=True).strip().rstrip()
    page_title = (
        page_title.split("Nude")[0].split("Leaks")[0].split("OnlyFans")[0].replace("https:", "").strip().rstrip()
    )
    page_title = re.sub(NUMBERS_PATTERN, "", page_title).strip()
    return unidecode(
        " ".join(
            f"#{part.strip().replace(' ', '').replace('.', '_').replace('-', '_')}" for part in page_title.split("/")
        )
    )


async def collect_thefapnet_result(
    source_url: str,
    headers: dict[str, str] | None,
    max_pages: int = 50,
) -> ExtractorResult | None:
    query, src_attr = query_mapping["thefap.net"]
    source_urls = [source_url, *(await get_pages_from_pagination(source_url, headers=headers, max_pages=max_pages))]
    image_tags: list[Tag] = []
    video_candidates: list[str] = []
    video_page_urls = IndexedSet()
    first_soup: BeautifulSoup | None = None

    for target_url in source_urls:
        soup = await get_soup(target_url, headers=headers)
        if first_soup is None:
            first_soup = soup
        image_tags.extend(tag for tag in soup.select(query) if "icon" not in tag.attrs.get("src", ""))
        video_candidates.extend(_extract_video_candidate_urls_from_soup(soup, target_url))
        video_page_urls.update(_extract_video_page_urls_from_soup(soup, target_url))

    for video_page_url in video_page_urls:
        try:
            video_soup = await get_soup(video_page_url, headers=headers)
        except Exception:
            continue
        video_candidates.extend(_extract_video_candidate_urls_from_soup(video_soup, video_page_url))

    if first_soup is None:
        return None

    ordered_unique_img_urls = await build_unique_img_urls(
        image_tags=image_tags,
        src_attr=src_attr,
        entity="thefap.net",
    )
    ordered_unique_img_urls = filter_unreachable_image_urls(ordered_unique_img_urls)
    ordered_unique_video_urls = _build_video_records_from_candidates(video_candidates, headers=headers)

    if not ordered_unique_img_urls and not ordered_unique_video_urls:
        return None

    return ExtractorResult(
        page_title=get_page_title(first_soup),
        ordered_unique_img_urls=ordered_unique_img_urls,
        ordered_unique_video_urls=ordered_unique_video_urls,
    )


async def get_sources_for_the_fap_net(
    sources: list[str],
    entity: str,
    telegraph_client: Telegraph | None = None,
    final_dest: str | pathlib.Path = "",
    save_to_telegraph: bool | None = False,
    **kwargs,
) -> None:
    query, src_attr = query_mapping[entity]
    max_pages = int(kwargs.get("max_pages", 500))
    config = ExtractorConfig(
        query=query,
        src_attr=src_attr,
        pagination_fetcher=get_pages_from_pagination,
        title_factory=get_page_title,
        image_urls_post_processor=filter_unreachable_image_urls,
        result_collector=lambda source_url, headers: collect_thefapnet_result(
            source_url=source_url,
            headers=headers,
            max_pages=max_pages,
        ),
    )
    await run_default_source(
        sources=sources,
        entity=entity,
        telegraph_client=telegraph_client,
        config=config,
        final_dest=final_dest,
        save_to_telegraph=save_to_telegraph,
        channel=kwargs.get("channel", ""),
        max_pages=max_pages,
    )
