from __future__ import annotations

from collections.abc import Callable
from typing import Any

import cloudscraper

from grabber.core.settings import (
    PICAZOR_CF_CLEARANCE,
    PICAZOR_CSRF_TOKEN,
    PICAZOR_LOCALE,
    PICAZOR_SESSION_TOKEN,
)

BASE_URL = "https://picazor.com"
ALERTS_ENDPOINT = "/api/alerts"
DEFAULT_LIMIT = 10
DEFAULT_TIMEOUT = 30.0


class PicazorNotificationAuthError(RuntimeError):
    pass


FetchNotificationsPage = Callable[[int, int, dict[str, str], float], dict[str, Any]]


def build_album_url(notification: dict[str, Any], locale: str = PICAZOR_LOCALE) -> str | None:
    album = notification.get("album") or {}
    subject = album.get("subject") or {}
    subject_uri = subject.get("uri")
    album_order = album.get("order")

    if not subject_uri or album_order is None:
        return None

    return f"{BASE_URL}/{locale}/{subject_uri}/albums/{album_order}"


def build_profile_url(notification: dict[str, Any], locale: str = PICAZOR_LOCALE) -> str | None:
    album = notification.get("album") or {}
    subject = album.get("subject") or {}
    subject_uri = subject.get("uri")

    if not subject_uri:
        return None

    return f"{BASE_URL}/{locale}/{subject_uri}"


def retrieve_album_urls(
    number: int,
    *,
    include_read: bool = False,
    timeout: float = DEFAULT_TIMEOUT,
    fetch_page: FetchNotificationsPage | None = None,
) -> list[str]:
    urls: list[str] = []
    seen: set[str] = set()

    for notification in iter_album_notifications(
        number=number,
        include_read=include_read,
        timeout=timeout,
        fetch_page=fetch_page,
    ):
        url = build_album_url(notification, locale=PICAZOR_LOCALE)
        if not url or url in seen:
            continue
        seen.add(url)
        urls.append(url)
        if len(urls) >= number:
            break

    return urls


def retrieve_profile_urls(
    number: int,
    *,
    include_read: bool = False,
    timeout: float = DEFAULT_TIMEOUT,
    fetch_page: FetchNotificationsPage | None = None,
) -> list[str]:
    urls: list[str] = []
    seen: set[str] = set()

    for notification in iter_album_notifications(
        number=number,
        include_read=include_read,
        timeout=timeout,
        fetch_page=fetch_page,
    ):
        url = build_profile_url(notification, locale=PICAZOR_LOCALE)
        if not url or url in seen:
            continue
        seen.add(url)
        urls.append(url)

    return urls


def iter_album_notifications(
    number: int,
    *,
    include_read: bool = False,
    timeout: float = DEFAULT_TIMEOUT,
    fetch_page: FetchNotificationsPage | None = None,
) -> list[dict[str, Any]]:
    if number <= 0:
        return []

    headers = build_headers()
    page_fetcher = fetch_page or fetch_notifications_page
    notifications: list[dict[str, Any]] = []
    page = 1

    while len(notifications) < number:
        payload = page_fetcher(page, DEFAULT_LIMIT, headers, timeout)
        page_notifications = payload.get("notifications", [])
        has_more = bool(payload.get("hasMore", False))

        if not isinstance(page_notifications, list) or not page_notifications:
            break

        for notification in page_notifications:
            if not isinstance(notification, dict):
                continue
            if notification.get("type") != "NEW_ALBUM":
                continue
            if not include_read and notification.get("read", False):
                continue

            notifications.append(notification)
            if len(notifications) >= number:
                break

        if len(notifications) >= number or not has_more:
            break
        page += 1

    return notifications


def fetch_notifications_page(page: int, limit: int, headers: dict[str, str], timeout: float) -> dict[str, Any]:
    scraper = cloudscraper.create_scraper(interpreter="nodejs")
    response = scraper.get(
        f"{BASE_URL}{ALERTS_ENDPOINT}",
        headers=headers,
        params={"page": page, "limit": limit},
        timeout=timeout,
    )
    response.raise_for_status()
    payload = response.json()
    if not isinstance(payload, dict):
        raise TypeError(f"Expected object payload from Picazor alerts, got {type(payload).__name__}")
    return payload


def build_headers() -> dict[str, str]:
    if not PICAZOR_SESSION_TOKEN:
        raise PicazorNotificationAuthError("Missing Picazor notification auth: PICAZOR_SESSION_TOKEN")

    cookie_parts = [
        f"__Secure-next-auth.session-token={PICAZOR_SESSION_TOKEN}",
        f"NEXT_LOCALE={PICAZOR_LOCALE}",
    ]
    if PICAZOR_CF_CLEARANCE:
        cookie_parts.append(f"cf_clearance={PICAZOR_CF_CLEARANCE}")
    if PICAZOR_CSRF_TOKEN:
        cookie_parts.append(f"__Host-next-auth.csrf-token={PICAZOR_CSRF_TOKEN}")

    return {
        "Accept": "*/*",
        "User-Agent": (
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
            "AppleWebKit/605.1.15 (KHTML, like Gecko) "
            "Version/26.3 Safari/605.1.15"
        ),
        "Referer": f"{BASE_URL}/",
        "Origin": BASE_URL,
        "Content-Type": "application/json",
        "Cookie": "; ".join(cookie_parts),
    }


__all__ = [
    "PicazorNotificationAuthError",
    "build_album_url",
    "build_headers",
    "build_profile_url",
    "fetch_notifications_page",
    "iter_album_notifications",
    "retrieve_album_urls",
    "retrieve_profile_urls",
]
