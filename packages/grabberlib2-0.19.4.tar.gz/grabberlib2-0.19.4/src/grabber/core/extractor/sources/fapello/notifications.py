from __future__ import annotations

import re
from collections.abc import Callable

import httpx
from bs4 import BeautifulSoup

from grabber.core.settings import FAPELLO_HASH, FAPELLO_USER_ID

BASE_URL = "https://fapello.com"
FEED_ENDPOINT = f"{BASE_URL}/ajax/my/page-{{page_number}}/"
FEED_POST_SELECTOR = "div.bg-white.shadow div div.grid.grid-cols-2 a"
PROFILE_LINK_SELECTOR = "div.bg-white.shadow div.flex.justify-between div.flex.flex-1 a"
DEFAULT_TIMEOUT = 30.0
DEFAULT_MAX_PAGES = 50

FAPELLO_ACCEPT_HEADER = (
    "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,"
    "application/signed-exchange;v=b3;q=0.7"
)
FAPELLO_USER_AGENT = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/123.0.0.0 Safari/537.36"
)


class FapelloNotificationAuthError(RuntimeError):
    pass


FetchFeedPage = Callable[[int, dict[str, str], float], str]


def retrieve_image_urls(
    number: int,
    *,
    timeout: float = DEFAULT_TIMEOUT,
    max_pages: int = DEFAULT_MAX_PAGES,
    fetch_page: FetchFeedPage | None = None,
) -> list[str]:
    return _retrieve_urls(
        number=number,
        selector=FEED_POST_SELECTOR,
        url_extractor=_extract_feed_image_url,
        timeout=timeout,
        max_pages=max_pages,
        fetch_page=fetch_page,
    )


def retrieve_profile_urls(
    number: int,
    *,
    timeout: float = DEFAULT_TIMEOUT,
    max_pages: int = DEFAULT_MAX_PAGES,
    fetch_page: FetchFeedPage | None = None,
) -> list[str]:
    return _retrieve_urls(
        number=number,
        selector=PROFILE_LINK_SELECTOR,
        url_extractor=lambda anchor: anchor.get("href", ""),
        timeout=timeout,
        max_pages=max_pages,
        fetch_page=fetch_page,
    )


def build_headers() -> dict[str, str]:
    missing = []
    if not FAPELLO_USER_ID:
        missing.append("FAPELLO_USER_ID")
    if not FAPELLO_HASH:
        missing.append("FAPELLO_HASH")
    if missing:
        raise FapelloNotificationAuthError(f"Missing Fapello feed auth: {', '.join(missing)}")

    return {
        "Accept": FAPELLO_ACCEPT_HEADER,
        "User-Agent": FAPELLO_USER_AGENT,
        "Cookie": f"user_id={FAPELLO_USER_ID}; hash={FAPELLO_HASH};",
    }


def fetch_feed_page(page_number: int, headers: dict[str, str], timeout: float) -> str:
    response = httpx.get(
        FEED_ENDPOINT.format(page_number=page_number),
        headers=headers,
        timeout=timeout,
    )
    response.raise_for_status()
    return response.text


def normalize_feed_image_url(image_url: str) -> str:
    return re.sub(r"_300px(?=\.[^./?]+(?:\?|$))", "", image_url.strip())


def _retrieve_urls(
    number: int,
    selector: str,
    url_extractor: Callable,
    timeout: float,
    max_pages: int,
    fetch_page: FetchFeedPage | None,
) -> list[str]:
    if number <= 0:
        return []

    headers = build_headers()
    page_fetcher = fetch_page or fetch_feed_page
    urls: list[str] = []
    seen: set[str] = set()

    for page_number in range(1, max_pages + 1):
        page_html = page_fetcher(page_number, headers, timeout)
        if not page_html.strip():
            break

        soup = BeautifulSoup(page_html, features="lxml")
        anchors = soup.select(selector)
        if not anchors:
            break

        for anchor in anchors:
            url = str(url_extractor(anchor)).strip()
            if not url or url in seen:
                continue

            seen.add(url)
            urls.append(url)
            if len(urls) >= number:
                return urls

    return urls


def _extract_feed_image_url(anchor) -> str:
    image = anchor.select_one("img[src]")
    if image is None:
        return ""
    return normalize_feed_image_url(str(image.get("src", "")))


__all__ = [
    "FapelloNotificationAuthError",
    "build_headers",
    "fetch_feed_page",
    "normalize_feed_image_url",
    "retrieve_image_urls",
    "retrieve_profile_urls",
]
