module github.com/example/myapp

go 1.22

require (
	github.com/lib/pq v1.10.9
	github.com/gorilla/mux v1.8.1
)
