# Referencia CLI

Referencia de comandos de AI Code Reviewer.

---

## Comando Principal

```bash
ai-review [OPTIONS]
```

**Comportamiento:**

- En CI (GitHub Actions / GitLab CI) — detecta automáticamente el contexto
- Manualmente — necesitas especificar `--provider`, `--repo`, `--pr`

!!! info "Subcomandos"
    `ai-review` (sin subcommand) ejecuta una revisión — compatible hacia atrás. Usa `ai-review discover` para ejecutar discovery de forma independiente.

---

## Opciones

| Opción | Corto | Descripción | Por defecto |
|--------|-------|-------------|---------|
| `--provider` | `-p` | Proveedor CI | Auto-detectar |
| `--repo` | `-r` | Repositorio (owner/repo) | Auto-detectar |
| `--pr` | | Número de PR/MR | Auto-detectar |
| `--help` | | Mostrar ayuda | |
| `--version` | | Mostrar versión | |

---

## Proveedores

| Valor | Descripción |
|-------|-------------|
| `github` | GitHub (GitHub Actions) |
| `gitlab` | GitLab (GitLab CI) |

---

## Ejemplos de Uso

### En CI (automático)

```bash
# GitHub Actions — todo automático
ai-review

# GitLab CI — todo automático
ai-review
```

### Manual para GitHub

```bash
export AI_REVIEWER_GOOGLE_API_KEY=your_key
export AI_REVIEWER_GITHUB_TOKEN=your_token

ai-review --provider github --repo owner/repo --pr 123
```

<small>
**Dónde obtener los valores:**

- `--repo` — de la URL del repositorio: `github.com/owner/repo` → `owner/repo`
- `--pr` — número de la URL: `github.com/owner/repo/pull/123` → `123`
</small>

### Manual para GitLab

```bash
export AI_REVIEWER_GOOGLE_API_KEY=your_key
export AI_REVIEWER_GITLAB_TOKEN=your_token

ai-review --provider gitlab --repo owner/repo --pr 456
```

<small>
**Dónde obtener los valores:**

- `--repo` — ruta del proyecto de la URL: `gitlab.com/group/project` → `group/project`
- `--pr` — número del MR de la URL: `gitlab.com/group/project/-/merge_requests/456` → `456`
</small>

### Sintaxis Corta

```bash
ai-review -p github -r owner/repo --pr 123
```

---

## Variables de Entorno

CLI lee la configuración de las variables de entorno:

### Requeridas

| Variable | Descripción |
|----------|-------------|
| `AI_REVIEWER_GOOGLE_API_KEY` | Clave API de Gemini |
| `AI_REVIEWER_GITHUB_TOKEN` | Token de GitHub (para GitHub) |
| `AI_REVIEWER_GITLAB_TOKEN` | Token de GitLab (para GitLab) |

!!! tip "Fallback"
    Los nombres antiguos sin prefijo (p. ej., `GOOGLE_API_KEY`) siguen funcionando como fallback.

### Opcionales

| Variable | Descripción | Por defecto |
|----------|-------------|---------|
| `AI_REVIEWER_LANGUAGE` | Idioma de respuesta | `en` |
| `AI_REVIEWER_LANGUAGE_MODE` | Modo de idioma | `adaptive` |
| `AI_REVIEWER_GEMINI_MODEL` | Modelo Gemini | `gemini-2.5-flash` |
| `AI_REVIEWER_LOG_LEVEL` | Nivel de log | `INFO` |
| `AI_REVIEWER_GITLAB_URL` | URL de GitLab | `https://gitlab.com` |

:point_right: [Lista completa →](configuration.md)

---

## Auto-detección

### GitHub Actions

CLI usa automáticamente:

| Variable | Descripción |
|----------|-------------|
| `GITHUB_ACTIONS` | Detección de entorno |
| `GITHUB_REPOSITORY` | owner/repo |
| `GITHUB_EVENT_PATH` | JSON con detalles del PR |
| `GITHUB_REF` | Fallback para número de PR |

### GitLab CI

CLI usa automáticamente:

| Variable | Descripción |
|----------|-------------|
| `GITLAB_CI` | Detección de entorno |
| `CI_PROJECT_PATH` | owner/repo |
| `CI_MERGE_REQUEST_IID` | Número del MR |
| `CI_SERVER_URL` | URL de GitLab |

---

## Códigos de Salida

| Código | Descripción |
|------|-------------|
| `0` | Éxito |
| `1` | Error (configuración, API, etc.) |

---

## Logging

### Niveles

| Nivel | Descripción |
|-------|-------------|
| `DEBUG` | Información detallada para depuración |
| `INFO` | Información general (por defecto) |
| `WARNING` | Advertencias |
| `ERROR` | Errores |
| `CRITICAL` | Errores críticos |

### Configuración

```bash
export AI_REVIEWER_LOG_LEVEL=DEBUG
ai-review
```

### Salida

CLI usa [Rich](https://rich.readthedocs.io/) para salida formateada:

```
[12:34:56] INFO     Detected CI Provider: github
[12:34:56] INFO     Context extracted: owner/repo PR #123
[12:34:57] INFO     Fetching PR diff...
[12:34:58] INFO     Analyzing code with Gemini...
[12:35:02] INFO     Review completed successfully
```

---

## Errores

### Error de Configuración

```
Configuration Error: AI_REVIEWER_GOOGLE_API_KEY is too short (minimum 10 characters)
```

**Causa:** Configuración inválida.

**Solución:** Verifica las variables de entorno.

### Error de Contexto

```
Context Error: Could not determine PR number from GitHub Actions context.
```

**Causa:** El workflow no se está ejecutando para un PR.

**Solución:** Asegúrate de que el workflow tenga `on: pull_request`.

### Proveedor No Detectado

```
Error: Could not detect CI environment.
Please specify --provider, --repo, and --pr manually.
```

**Causa:** Ejecutando fuera de CI.

**Solución:** Especifica todos los parámetros manualmente.

---

## Comando Discover

Ejecutar project discovery de forma independiente (sin crear una revisión):

```bash
ai-review discover <REPO> [OPTIONS]
```

### Argumentos

| Argumento | Descripción |
|-----------|-------------|
| `REPO` | Repositorio (owner/repo) |

### Opciones

| Opción | Corto | Descripción | Por defecto |
|--------|-------|-------------|-------------|
| `--provider` | `-p` | Proveedor Git | `github` |
| `--json` | | Salida en formato JSON | `false` |
| `--verbose` | `-v` | Mostrar todos los detalles (convenciones, herramientas CI, watch-files) | `false` |

### Ejemplos

```bash
# Repositorio GitHub
ai-review discover owner/repo

# Salida JSON
ai-review discover owner/repo --json

# Modo verbose
ai-review discover owner/repo -v

# Proyecto GitLab
ai-review discover group/project -p gitlab
```

### Ejemplo de salida

```
🔍 Discovering project context...

Stack: Python (FastAPI) 3.13, uv
CI: ✅ .github/workflows/tests.yml — ruff, mypy, pytest

Attention Zones:
  ✅ Formatting — ruff format in CI
  ✅ Type checking — mypy --strict in CI
  ❌ Security scanning — No security scanner detected
  ⚠️ Test coverage — no coverage threshold
```

---

## Docker

Ejecutar via Docker:

```bash
docker run --rm \
  -e AI_REVIEWER_GOOGLE_API_KEY=your_key \
  -e AI_REVIEWER_GITHUB_TOKEN=your_token \
  ghcr.io/konstziv/ai-code-reviewer:1 \
  --provider github \
  --repo owner/repo \
  --pr 123
```

---

## Versión

```bash
ai-review --version
```

```
AI Code Reviewer 0.1.0
```

---

## Ayuda

```bash
ai-review --help
```

```
Usage: ai-review [OPTIONS]

  Run AI Code Reviewer.

  Automatically detects CI environment and reviews the current Pull Request.
  Can also be run manually by providing arguments.

Options:
  -p, --provider [github|gitlab]  CI provider (auto-detected if not provided)
  -r, --repo TEXT                 Repository name (e.g. owner/repo). Auto-detected in CI.
  --pr INTEGER                    Pull Request number. Auto-detected in CI.
  --help                          Show this message and exit.
```

---

## Siguiente Paso

- [Solución de Problemas →](troubleshooting.md)
- [Ejemplos →](examples/index.md)
