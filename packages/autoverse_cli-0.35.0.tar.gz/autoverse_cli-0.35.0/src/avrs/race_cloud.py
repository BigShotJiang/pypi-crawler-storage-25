import subprocess
import base64
import logging
import time
import ipaddress
from avrs.cfg import *
from avrs.race_cloud_util import *
from avrs.race_cloud_cfg_util import *
from avrs.race_cloud_fwd_api import *
from avrs.race_cloud_bridge_can import *
from avrs.race_cloud_heartbeat import heartbeat_loop
from avrs.util import *
from avrs.requests.request import AvrsApiRequest
from argparse import RawTextHelpFormatter


def is_valid_public_ip(value):
    """Check if a string is a valid public IP address (not private, not loopback, not reserved)."""
    try:
        ip = ipaddress.ip_address(value)
        return not (ip.is_private or ip.is_loopback or ip.is_reserved or
                    ip.is_multicast or ip.is_link_local)
    except ValueError:
        return False


def is_valid_private_ip(value):
    """Check if a string is a valid private (RFC 1918) IP address."""
    try:
        ip = ipaddress.ip_address(value)
        return ip.is_private and not (ip.is_loopback or ip.is_reserved or
                                      ip.is_multicast or ip.is_link_local)
    except ValueError:
        return False


def parse_sim_target(value):
    """
    Parse sim_target argument: must be a valid public or private IP address.
    Returns (is_valid, parsed_value).
    """
    if is_valid_public_ip(value) or is_valid_private_ip(value):
        return (True, value)
    else:
        return (False, "Must be a valid IP address (not loopback, reserved, or multicast)")

class AvrsRaceCloud(AvrsApiRequest):
    def __init__(self, parser, cfg):
        self.cfg = cfg
        race_cloud_parser = parser.add_parser(
            'race-cloud', 
            help='cloud racing\n\n')

        sps = race_cloud_parser.add_subparsers(required=True, help='race-cloud options')

        connect_parser = sps.add_parser(
            'connect',
            help='connect to an instance for cloud racing')
        connect_parser.add_argument(
            'sim_target',
            type=str,
            help='IP address of the server instance (public or private)')
        connect_parser.add_argument(
            'team_name',
            help='the name of the team to race under')
        connect_parser.add_argument(
            'vehicle_config',
            help='the path the vehicle configuration file to use when racing')
        connect_parser.add_argument(
            '--instance-id',
            default = '',
            help='can be used directly instead of instance name if needed')
        connect_parser.add_argument(
            '--no-restart-sim',
            action='store_true',
            help='if set, the sim instance will not be restarted after connection')
        connect_parser.add_argument(
            '--no-check-cans',
            action='store_true',
            help='if set, vcan interfaces will not be checked for validity')
        connect_parser.add_argument(
            '--print-debug',
            action='store_true',
            help='if set, debug information will be printed')
        connect_parser.set_defaults(func=self.race_connect)

        rx_connect_parser = sps.add_parser(
            'rx-connection',
            help='execute steps to receive a connection (only relevant to sim-side)')
        rx_connect_parser.add_argument(
            'team_name',
            help='the name of the connecting team')
        rx_connect_parser.add_argument(
            'ip',
            help='the ip address of the incoming connection')
        rx_connect_parser.add_argument(
            '--restart',
            action='store_true',
            help='should the sim program be restarted after this connection')
        rx_connect_parser.add_argument(
            'cfg_data',
            help='the incoming vehicle configuration data')
        rx_connect_parser.add_argument(
            '--disable-perception',
            action='store_true',
            help='disable perception sensors (lidar, camera, radar) for this connection')
        rx_connect_parser.add_argument(
            '--requester-ip',
            type=str,
            default=None,
            help="Lambda's view of the requester's IP (e.g. API Gateway sourceIp). "
                 "Stored as the slot's auth_ip and used to authorize subsequent disconnects.")
        rx_connect_parser.set_defaults(func=self.rx_connect)

        sim_ctrl_parser = sps.add_parser(
            'sim-ctrl',
            help='control the sim program (start, stop, restart, reset)')
        sim_ctrl_parser.add_argument(
            'sim_target',
            type=str,
            help='IP address of the server instance (public or private)')
        sim_ctrl_parser.add_argument(
            'action',
            choices=['start', 'stop', 'restart', 'reset-connection', 'get-log'],
            help='what action to apply to the simulator program')
        sim_ctrl_parser.add_argument(
            '--local',
            action='store_true',
            help='if set, this command will run on this system locally (not for use from dev instances)')
        sim_ctrl_parser.add_argument(
            '--instance-id',
            default = '',
            help='can be used directly instead of sim index if needed')
        sim_ctrl_parser.add_argument(
            '--clear-autospawns',
            action='store_true',
            help='can be used with the reset-connection action to clear sim autospawn config')
        sim_ctrl_parser.add_argument(
            '--requester-ip',
            default=None,
            help='(for --local reset-connection) IP of the original requester. Used to '
                 'authorize: trusted requesters (loopback, sim host itself, or unset for '
                 'interactive use) get a global reset; any other IP is scoped to that '
                 "team's slot only. Forwarded by the cloud API; do not set manually.")
        sim_ctrl_parser.set_defaults(func=self.sim_ctrl)

        reset_qos_parser = sps.add_parser(
            'reset-qos',
            help='reset the qos file on this system')
        reset_qos_parser.set_defaults(func=self.reset_qos)

        enable_peer_qos_parser = sps.add_parser(
            'enable-peer-qos',
            help='enable a peer in this systems qos file')
        enable_peer_qos_parser.add_argument(
            'peer_id',
            type=int,
            choices=[0, 1, 2, 3, 4, 5],
            help='the id of the peer to enable')
        enable_peer_qos_parser.add_argument(
            'ip',
            help='the ip address to add to the qos file')
        enable_peer_qos_parser.set_defaults(func=self.enable_peer_qos)

        disable_peer_qos_parser = sps.add_parser(
            'disable-peer-qos',
            help='disable a peer in this systems qos file')
        disable_peer_qos_parser.add_argument(
            'peer_id',
            type=int,
            choices=[0, 1, 2, 3, 4, 5],
            help='the id of the peer to enable')
        disable_peer_qos_parser.set_defaults(func=self.disable_peer_qos)

        fwd_server_parser = sps.add_parser(
            'fwd-api',
            help='forwards incoming external api requests to the simulator api')
        fwd_server_parser.add_argument(
            'mode',
            choices=['bg', 'fg'],
            help='whether to run in forground or background')
        fwd_server_parser.add_argument(
            'source_port',
            type=int,
            help='the external port to listen to external api requests on')
        fwd_server_parser.add_argument(
            'target_port',
            type=int,
            help='the local port to forward api requests too')
        fwd_server_parser.set_defaults(func=self.fwd_api)

        bridge_can_parser = sps.add_parser(
            'bridge-can',
            help='bridges a local vcan with a remote vcan over udp')

        bridge_can_parser.add_argument(
            'mode',
            choices=['bg', 'fg'],
            help='whether to run in forground or background')

        bridge_can_parser.add_argument(
            'vcan_name')

        bridge_can_parser.add_argument(
            'peer_ip')

        bridge_can_parser.add_argument(
            'peer_port',
            type=int)

        bridge_can_parser.add_argument(
            'local_port',
            type=int)

        bridge_can_parser.set_defaults(func=self.bridge_can)

        heartbeat_parser = sps.add_parser(
            'heartbeat',
            help='send periodic heartbeat to the sim instance to maintain connection')
        heartbeat_parser.add_argument(
            'mode',
            choices=['bg', 'fg'],
            help='whether to run in foreground or background')
        heartbeat_parser.add_argument(
            'sim_ip',
            help='the ip address of the sim instance')
        heartbeat_parser.add_argument(
            'sim_port',
            type=int,
            help='the port of the sim forwarder (typically 30333)')
        heartbeat_parser.add_argument(
            'team_name',
            help='the team name for this connection')
        heartbeat_parser.add_argument(
            'slot',
            type=int,
            help='the slot id assigned to this team')
        heartbeat_parser.set_defaults(func=self.heartbeat)

        disconnect_parser = sps.add_parser(
            'disconnect',
            help='disconnect a team from the server, remove their locks, and despawn their car')
        disconnect_parser.add_argument(
            'sim_target',
            nargs='?',
            type=str,
            default=None,
            help='IP address of the server instance, public or private (required for remote disconnect)')
        disconnect_parser.add_argument(
            'team_name',
            help='the name of the team to disconnect')
        disconnect_parser.add_argument(
            '--slot',
            type=int,
            choices=[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11],
            default=None,
            help='the slot id the team is using (optional, will be looked up by team name if not provided)')
        disconnect_parser.add_argument(
            '--local',
            action='store_true',
            help='if set, this command will run on this system locally (for use on sim instances)')
        disconnect_parser.set_defaults(func=self.disconnect_team)

        # rx-disconnect parser (runs on sim instance when receiving disconnect request)
        rx_disconnect_parser = sps.add_parser(
            'rx-disconnect',
            help='execute steps to receive a disconnect request (only relevant to sim-side)')
        rx_disconnect_parser.add_argument(
            'team_name',
            help='the name of the team to disconnect')
        rx_disconnect_parser.add_argument(
            'requester_ip',
            help='the ip address of the requester')
        rx_disconnect_parser.add_argument(
            '--slot',
            type=int,
            default=None,
            help='the slot id (optional, will be looked up by team name)')
        rx_disconnect_parser.set_defaults(func=self.rx_disconnect_team)

    def race_connect(self, args):
        logger = logging.getLogger('avrs')

        # Validate sim_target (must be a valid public or private IP)
        is_valid, parsed_value = parse_sim_target(args.sim_target)
        if not is_valid:
            print('invalid sim_target: {}'.format(parsed_value))
            return

        # make api call to begin connection
        our_ip = get_local_instance_ip()

        if our_ip == '127.0.0.1':
            print('this machines IP was returned as localhost. was this run on the cloud instance?')
            return

        logger.info('starting race-cloud connect for team {} to {}'.format(
            args.team_name, parsed_value))
        print('connecting to race with team name: {}'.format(args.team_name))

        # reset local connection first
        logger.info('resetting local connection state prior to connection')
        reset_race_cloud_connection()

        # validate / load vehicle config
        vcfg_ok, vcfg_data, bsu_vcan, kistler_vcan, badenia_vcan = prepare_vehicle_cfg(args.vehicle_config)

        if not vcfg_ok:
            print('error reading config file: {}'.format(vcfg_data))
            return

        print('creating vcan interfaces found in config locally: {}, {}, {} (if they do not exist)'.format(
            bsu_vcan, kistler_vcan, badenia_vcan))

        setup_vcans(bsu_vcan, kistler_vcan, badenia_vcan)

        vcan_ok = True
        if not check_vcan_exists(bsu_vcan) and not args.no_check_cans:
            print('bsu vcan {} does not appear to exist'.format(bsu_vcan))
            vcan_ok = False
        if not check_vcan_exists(kistler_vcan) and not args.no_check_cans:
            print('kistler vcan {} does not appear to exist'.format(kistler_vcan))
            vcan_ok = False
        if not check_vcan_exists(badenia_vcan) and not args.no_check_cans:
            print('badenia vcan {} does not appear to exist'.format(badenia_vcan))
            vcan_ok = False

        if not vcan_ok:
            return

        connection_request = {
            'action': 'connect',
            'sim_id': parsed_value,
            'ip_to_reserve': our_ip,
            'team_name': args.team_name,
            'sim_id_override': args.instance_id,
            'ensure_instance_is_running': False,
            'should_restart_sim_program': not args.no_restart_sim,
            'config_data': vcfg_data
        }

        ok, response = call_race_cloud_api(connection_request)
        if not ok:
            print('connect api error: {}'.format(response))
            return

        ok, rbody, sim_ip = get_api_script_response(response)
        if not ok:
            print(rbody)
            return

        if args.print_debug:
            print(rbody)
        #print(sim_ip)

        slot_info = {}
        for k, v in rbody.items():
            logger.info('Processing response for key: {}'.format(k))
            logger.info('stdout: {}'.format(v.get('stdout', '')))
            logger.info('stderr: {}'.format(v.get('stderr', '')))

            stdout = v.get('stdout', '').strip()
            stderr = v.get('stderr', '').strip()

            if not stdout:
                print('Error: No stdout from remote command')
                if stderr:
                    print('stderr: {}'.format(stderr))
                return

            try:
                slot_info = json.loads(stdout)
            except json.JSONDecodeError as e:
                print('Error parsing JSON from stdout: {}'.format(e))
                print('stdout content: {}'.format(stdout[:500]))  # Print first 500 chars
                if stderr:
                    print('stderr: {}'.format(stderr))
                return

        if not slot_info['ok']:
            print('issue reserving slot: {}'.format(slot_info['msg']))
            return

        extra_msg = slot_info.get('extra_msg', '')
        print(extra_msg)

        sim_slot = slot_info['slot']

        # enable first peer since this is on a client (only will ever have 1, the sim)
        enable_peer_qos(sim_slot, sim_ip)

        # will need to get port from received slot id to connect peer vcans
        connect_peer_vcan(sim_slot, sim_ip, 0, bsu_vcan)
        connect_peer_vcan(sim_slot, sim_ip, 1, kistler_vcan)
        connect_peer_vcan(sim_slot, sim_ip, 2, badenia_vcan)

        # configure the CLI to communicate with the cloud sim instance
        self.cfg['sim_address'] = sim_ip
        self.cfg['sim_api_port'] = 30333 # set this to the forwarding server running on sim instance
        logger.info('setting sim addr to {} and port to {} for future api requests'.format(sim_ip, 30333))
        save_cfg('avrs', self.cfg)

        # start heartbeat to sim instance
        logger.info('starting heartbeat to sim instance {}:{}'.format(sim_ip, 30333))
        stop_heartbeat()
        start_heartbeat(sim_ip, 30333, args.team_name, sim_slot)

        # Slot N maps to ROS_DOMAIN_ID N+1 (domain 0 is reserved for SimTimeManager).
        domain_id = sim_slot + 1
        print('connection success with team name {} on slot {} (ROS_DOMAIN_ID {})'.format(
            args.team_name, sim_slot, domain_id))
        print('your ROS2 interfaces will be available on ROS_DOMAIN_ID {}'.format(domain_id))
        print('you will need to set the ROS_DOMAIN_ID environment variable prior to echoing or running software')
        print('(eg \"export ROS_DOMAIN_ID={}\")'.format(domain_id))

    # this should only run on sim instances (not dev instances)
    def rx_connect(self, args):
        logger = logging.getLogger('avrs')

        extra_msg = ''

        # check time-since last connection here. if > 10mins auto reset connection state
        time_since_last_connection = self.get_and_update_time_since_last_connection()
        reset_connection_timeout = 3600.0
        if time_since_last_connection > 3600.0:
            if any_slot_reserved():
                logger.info(
                    'time since last connection rx {} > {} but slots still reserved. '
                    'skipping reset to preserve active teams'.format(
                        time_since_last_connection, reset_connection_timeout))
                extra_msg += 'skipping idle reset: other teams still connected'
            else:
                logger.info('time since last connection rx {} > {}. resetting connection'.format(
                    time_since_last_connection, reset_connection_timeout))
                clear_autospawns()
                reset_race_cloud_connection()
                extra_msg += 'automatically resetting simulation instance connection state'
                extra_msg += ' (last connection was > {} seconds ago)'.format(reset_connection_timeout)
        else:
            extra_msg += 'NOT resetting connection state. last connection was only {} seconds ago'.format(
                time_since_last_connection)

        requester_ip = getattr(args, 'requester_ip', None)
        logger.info(
            'rx race cloud connection for team {} with ip {} (requester_ip={})'.format(
                args.team_name, args.ip, requester_ip))
        ok, msg, slot = try_get_open_slot(args.team_name, args.ip, auth_ip=requester_ip)

        bsu_vcan = get_auto_vcan_name(slot, 0)
        kistler_vcan = get_auto_vcan_name(slot, 1)
        badenia_vcan = get_auto_vcan_name(slot, 2)

        # Stop CAN bridges before despawn so UDP traffic stops feeding the
        # vehicle's sensors while UE is tearing the actor down. Sensor data
        # arriving mid-destroy has caused main-thread hangs.
        for vcan_id in range(3):
            stop_vcan_bridge(get_auto_vcan_name(slot, vcan_id))

        despawn_pres = despawn_vehicle(slot, args.team_name)
        if not despawn_pres.ok:
            logger.warning(
                'despawn-object failed (rc={}); sim may be unresponsive. aborting reconnect for slot {}'.format(
                    despawn_pres.returncode, slot))
            reset_race_cloud_connection_for_slot(slot, expected_ip=args.ip)
            print(json.dumps({
                'ok': False,
                'msg': 'sim despawn failed; slot released',
                'slot': -1
            }))
            return

        time.sleep(1)

        # get CAN names from this
        disable_perception = getattr(args, 'disable_perception', False)
        object_spec_name = register_received_vehicle(
            args.team_name, slot, args.cfg_data, bsu_vcan, kistler_vcan, badenia_vcan,
            disable_perception)

        vcan_ok = True
        vcan_msg = ''
        if not check_vcan_exists(bsu_vcan):
            vcan_msg = 'bsu vcan {} does not appear to exist'.format(bsu_vcan)
            vcan_ok = False
        if not check_vcan_exists(kistler_vcan):
            vcan_msg = 'kistler vcan {} does not appear to exist'.format(kistler_vcan)
            vcan_ok = False
        if not check_vcan_exists(badenia_vcan):
            vcan_msg = 'badenia vcan {} does not appear to exist'.format(badenia_vcan)
            vcan_ok = False

        if not vcan_ok:
            print(json.dumps({
                'ok': vcan_ok,
                'msg': vcan_msg,
                'slot': -1
                }))
            return

        spawn_pres = spawn_vehicle('PitsSlot{}'.format(slot + 1), object_spec_name)
        if not spawn_pres.ok:
            logger.warning(
                'spawn-object failed (rc={}); not starting bridges. releasing slot {}'.format(
                    spawn_pres.returncode, slot))
            reset_race_cloud_connection_for_slot(slot, expected_ip=args.ip)
            print(json.dumps({
                'ok': False,
                'msg': 'sim spawn failed; slot released',
                'slot': -1
            }))
            return

        if ok:
            logger.info('enabling qos for slot {} with ip {}'.format(slot, args.ip))
            enable_peer_qos(slot, args.ip)
            logger.info('connecting vcans for incoming connection')
            out = connect_peer_vcan(slot, args.ip, 0)
            logger.info('connected first vcan result: {} {}'.format(out.out, out.err))
            out = connect_peer_vcan(slot, args.ip, 1)
            logger.info('connected second vcan result: {} {}'.format(out.out, out.err))
            out = connect_peer_vcan(slot, args.ip, 2)
            logger.info('connected third vcan result: {} {}'.format(out.out, out.err))

        # go ahead and restart forwarding script here
        # stop it if its already running
        stop_result = stop_fwd_api()
        logger.info('stopped fwd-api: {}'.format(stop_result))
        start_result = start_fwd_api(30333, 30313)
        logger.info('started fwd-api: {}'.format(start_result))

        # if args.restart:
        #     logger.info('restarting sim program for new connection')
        #     logger.info('stopping sim program on sim instance')
        #     bash_kill_process('Autoverse')
        #     logger.info('starting sim program on sim instance')
        #     exe_path = os.path.join(get_sim_exe_path())
        #     start_exe(exe_path)
        #     extra_msg += '\n' if len(extra_msg) > 0 else ''
        #     extra_msg += 'automatically restarting sim program on sim instance'
        # else:
        #     logger.info('--restart not specified, not restarting sim program for this connection')

        response = {
            'ok': ok,
            'msg': msg,
            'slot': slot,
            'extra_msg': extra_msg
        }
        

        print(json.dumps(response)) # print this so that when called from the ssh lambda we can get the result

    def sim_ctrl(self, args):
        if args.local:
            self.local_sim_ctrl(args)
        else:
            self.remote_sim_ctrl(args)

    def local_sim_ctrl(self, args):
        # This handler is reachable via the cloud Lambda (untrusted callers).
        # Trust only `args.requester_ip` via `is_trusted_requester` — every
        # other field on `args` is caller-controllable.
        logger = logging.getLogger('avrs')
        if args.action == 'reset-connection':
            requester_ip = getattr(args, 'requester_ip', None)
            trusted = is_trusted_requester(requester_ip)
            requester_label = requester_ip if requester_ip else '<local>'

            if trusted:
                affected = []
                for i in range(12):
                    team, _ = get_slot_info(i)
                    if team is not None:
                        affected.append((i, team))
                logger.info(
                    'AUDIT reset-connection (global): requester={} trusted=True '
                    'clear_autospawns={} affecting slots {}'.format(
                        requester_label, args.clear_autospawns, affected))
                print('resetting race cloud connection')
                print('resetting qos file, removing CAN lock files, stopping all cannelloni instances')
                reset_race_cloud_connection()
                if args.clear_autospawns:
                    clear_autospawns()
            else:
                slot = find_slot_by_ip(requester_ip)
                matched_team, _ = get_slot_info(slot) if slot >= 0 else (None, None)
                logger.info(
                    'AUDIT reset-connection (scoped): requester={} trusted=False '
                    'matched_slot={} matched_team={} clear_autospawns_suppressed={}'.format(
                        requester_label, slot, matched_team, bool(args.clear_autospawns)))
                if slot < 0:
                    msg = 'no slot reserved for requester {} — nothing to reset'.format(requester_ip)
                    logger.warning(msg)
                    print(msg)
                else:
                    print('resetting slot {} for requester {}'.format(slot, requester_ip))
                    reset_race_cloud_connection_for_slot(slot, expected_ip=requester_ip)
                if args.clear_autospawns:
                    logger.warning(
                        'ignoring --clear-autospawns on scoped reset (requester {} not trusted)'.format(
                            requester_ip))
        if args.action == 'stop' or args.action == 'restart':
            logger.info('stopping race-cloud simulator program')
            print('stopping sim program on sim instance')
            bash_kill_process('Autoverse')
        if args.action == 'start' or args.action == 'restart':
            logger.info('starting race-cloud simulator program')
            #print('starting sim program on sim instance')
            exe_path = os.path.join(get_sim_exe_path())
            start_exe(exe_path)
        if args.action == 'get-log':
            logger.info('getting connection log')
            log_path = os.path.join(get_cfg_dir('avrs'), 'avrs.log')
            if os.path.isfile(log_path):
                print('the get-log command has been deprecated')
                #with open(log_path, 'r', encoding='utf-8') as f:
                    #print('the get-log command has been deprecated')
                    #print(f.read())
            else:
                print('no log file found')


    def remote_sim_ctrl(self, args):
        logger = logging.getLogger('avrs')

        # Validate sim_target (must be a valid public or private IP)
        is_valid, parsed_value = parse_sim_target(args.sim_target)
        if not is_valid:
            print('invalid sim_target: {}'.format(parsed_value))
            return

        # go ahead and reset local connection as well
        if args.action == 'reset-connection':
            reset_race_cloud_connection()

        our_ip = get_local_instance_ip()

        reset_request = {
            'action': args.action,
            'sim_id': parsed_value,
            'ip_to_reserve': our_ip,
            'requester_ip': our_ip,
            'sim_id_override': args.instance_id,
            'ensure_instance_is_running': False
        }

        logger.info('sending race-cloud sim-ctrl request: {}'.format(reset_request))

        ok, response = call_race_cloud_api(reset_request)
        #print(response)
        if not ok:
            print(response)
            return

        ok, rbody, sim_ip = get_api_script_response(response)
        if not ok:
            print(rbody)
            return

        for k, v in rbody.items():
            print(v['stdout'])

    def reset_qos(self, args):
        print('resetting qos files')
        reset_rmw_qos()
        reset_rmw_cyclone_qos()

    def enable_peer_qos(self, args):
        print('enabling peer qos for id {} using ip address {}'.format(
            args.peer_id, args.ip))
        out = enable_peer_qos(args.peer_id, args.ip)
        print('{} {}'.format(out.out, out.err))

    def disable_peer_qos(self, args):
        print('disabling peer qos for id {}'.format(args.peer_id))
        out = disable_peer_qos(args.peer_id)
        print('{} {}'.format(out.out, out.err))

    def fwd_api(self, args):
        # start a server that listens for http on some port and forwards
        # to the simulator on 30313
        logger = logging.getLogger('avrs')

        if args.mode == 'bg':
            # call the cli so that it starts the forwarding server in the background
            # stop it if its already running
            try:
                stop_result = stop_fwd_api()
                logger.info('stopped fwd-api: {}'.format(stop_result))
                start_result = start_fwd_api(args.source_port, args.target_port)
                logger.info('started fwd-api: {}'.format(start_result))
            except Exception as e:
                logger.error('failed to restart fwd-api: {}'.format(e))

        else:
            logger.info('starting fwd-api in forground')
            handler = ApiForwardHandler(args.target_port)
            reaper = HeartbeatReaper(handler)
            reaper.start()
            logger.info('heartbeat reaper thread started')
            server = ThreadingHTTPServer(('0.0.0.0', args.source_port), handler)
            server.serve_forever()

    def test_reset_timeout(self, args):
        print('testing reset timeout')

        elapsed = self.get_and_update_time_since_last_connection()
        print('elasped: {}'.format(elapsed))

    def get_and_update_time_since_last_connection(self):
        t = time.time()
        # default to zero if not exist to force timeout
        last_time = self.cfg.get('race-cloud-last-connect-time', 0)
        elapsed = t - last_time
        self.cfg['race-cloud-last-connect-time'] = t
        save_cfg('avrs', self.cfg)
        return elapsed

    def bridge_can(self, args):
        logger = logging.getLogger('avrs')

        if args.mode == 'bg':
            # call the cli so that it starts the forwarding server in the background
            # stop it if its already running
            try:
                stop_result = stop_can_brdige()
                logger.info('stopped can bridge: {}'.format(stop_result))
                start_result = start_can_bridge(args)
                logger.info('started can bridge: {}'.format(start_result))
            except Exception as e:
                logger.error('failed to restart can bridge: {}'.format(e))

        else:
            logger.info('starting can bridge in forground')
            can_bridge_loop(args)

    def heartbeat(self, args):
        logger = logging.getLogger('avrs')

        if args.mode == 'bg':
            try:
                stop_heartbeat()
                start_result = start_heartbeat(args.sim_ip, args.sim_port, args.team_name, args.slot)
                logger.info('started heartbeat: {}'.format(start_result))
            except Exception as e:
                logger.error('failed to restart heartbeat: {}'.format(e))
        else:
            logger.info('starting heartbeat in foreground')
            heartbeat_loop(args.sim_ip, args.sim_port, args.team_name, args.slot)

    def disconnect_team(self, args):
        if args.local:
            self.local_disconnect_team(args)
        else:
            if not args.sim_target:
                print('error: sim_target (server IP) is required for remote disconnect')
                return
            self.remote_disconnect_team(args)

    def local_disconnect_team(self, args, requester_ip=None):
        """Disconnect a team locally on the sim instance.

        Args:
            args: Command arguments
            requester_ip: IP of the requester (None for local/server requests)
        """
        logger = logging.getLogger('avrs')

        # Resolve slot from team name if not provided
        slot = args.slot
        if slot is None:
            slot = find_slot_by_team_name(args.team_name)
            if slot == -1:
                print('error: team {} not found in any slot'.format(args.team_name))
                return {'ok': False, 'msg': 'team not found'}
            logger.info('resolved team {} to slot {}'.format(args.team_name, slot))

        # Verify authorization (server-side requests pass None for requester_ip)
        authorized, auth_msg = verify_disconnect_authorization(slot, requester_ip)
        if not authorized:
            print('error: {}'.format(auth_msg))
            return {'ok': False, 'msg': auth_msg}

        logger.info('disconnecting team {} from slot {} ({})'.format(args.team_name, slot, auth_msg))
        print('disconnecting team {} from slot {}'.format(args.team_name, slot))

        # 1. Despawn the team's vehicle
        print('despawning vehicle for team {}'.format(args.team_name))
        despawn_vehicle(slot, args.team_name)

        # 2. Remove vehicle config files
        print('removing vehicle config for team {}'.format(args.team_name))
        unregister_vehicle(args.team_name)

        # 3. Disable QoS for this slot
        print('disabling QoS for slot {}'.format(slot))
        disable_peer_qos(slot)

        # 4. Stop CAN bridges for this slot's vcans
        print('stopping CAN bridges for slot {}'.format(slot))
        for vcan_id in range(3):
            vcan_name = get_auto_vcan_name(slot, vcan_id)
            stop_vcan_bridge(vcan_name)

        # 5. Remove the slot reservation file
        print('removing slot reservation for slot {}'.format(slot))
        remove_slot_reservation(slot)

        print('team {} has been disconnected from slot {}'.format(args.team_name, slot))
        return {'ok': True, 'msg': 'team disconnected', 'slot': slot}

    def remote_disconnect_team(self, args):
        """Send disconnect request to a remote sim instance."""
        logger = logging.getLogger('avrs')
        our_ip = get_local_instance_ip()

        disconnect_request = {
            'action': 'disconnect',
            'sim_id': args.sim_target,
            'ip_to_reserve': our_ip,
            'team_name': args.team_name,
            'slot': args.slot,  # Can be None, will be resolved on server side
        }

        logger.info('sending race-cloud disconnect request: {}'.format(disconnect_request))

        ok, response = call_race_cloud_api(disconnect_request)
        if not ok:
            print(response)
            return

        ok, rbody, sim_ip = get_api_script_response(response)
        if not ok:
            print(rbody)
            return

        for k, v in rbody.items():
            stdout = v.get('stdout', '')
            if stdout:
                print(stdout)
            try:
                result = json.loads(stdout)
                if not result.get('ok', True):
                    print('disconnect failed: {}'.format(result.get('msg', 'unknown error')))
            except (json.JSONDecodeError, TypeError):
                pass

        # Also reset local connection state after successful disconnect
        print('resetting local connection state')
        reset_race_cloud_connection()

    def rx_disconnect_team(self, args):
        """Execute disconnect on the sim instance (called via Lambda SSH).

        This runs on the sim side when receiving a remote disconnect request.
        Outputs JSON result for the Lambda to return to the requester.
        """
        logger = logging.getLogger('avrs')
        logger.info('rx disconnect for team {} from requester {}'.format(
            args.team_name, args.requester_ip))

        class DisconnectArgs:
            pass

        disconnect_args = DisconnectArgs()
        disconnect_args.team_name = args.team_name
        disconnect_args.slot = args.slot

        result = self.local_disconnect_team(disconnect_args, requester_ip=args.requester_ip)

        # Output JSON for Lambda to parse
        print(json.dumps(result))