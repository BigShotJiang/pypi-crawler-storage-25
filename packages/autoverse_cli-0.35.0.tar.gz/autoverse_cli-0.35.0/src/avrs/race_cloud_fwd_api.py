import argparse
import json
import logging
import os
import re
import time
import subprocess
import threading
import http
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

# https://gist.github.com/dfrankow/f91aefd683ece8e696c26e183d696c29

REAPER_CHECK_INTERVAL_SEC = 15
REAPER_STALE_THRESHOLD_SEC = 60

# Request types that must never be proxied to the sim from remote callers.
# These are host-only admin operations and must be invoked directly against
# the sim loopback port (30313) from the sim host itself.
ADMIN_REQUEST_TYPES = {
    'ToggleGroundTruth',
}

class ApiForwardHandler(BaseHTTPRequestHandler):
    def __init__(self, target_port):
        self.target_port = target_port
        self.heartbeat_timestamps = {}
        self.heartbeat_lock = threading.Lock()
        self._seed_heartbeats_from_slot_files()

    def _seed_heartbeats_from_slot_files(self):
        """Seed heartbeat tracking from existing .simslot_* files so the reaper
        can evict stale slots whose client died while fwd-api was down."""
        now = time.time()
        home = os.environ.get('HOME', '')
        if not home:
            return
        for i in range(12):
            slot_path = os.path.join(home, '.simslot_{}'.format(i))
            if not os.path.isfile(slot_path):
                continue
            team_name = 'unknown'
            try:
                with open(slot_path, 'r', encoding='utf-8') as f:
                    data = json.loads(f.read())
                    team_name = data.get('team_name', 'unknown')
            except Exception:
                pass
            self.heartbeat_timestamps[i] = (now, team_name)

    # allows to be passed to the HTTPServer ctor
    def __call__(self, *args, **kwargs):
        """Handle a request."""
        super().__init__(*args, **kwargs)

    def do_POST(self):
        length = int(self.headers.get('content-length'))
        rfile_str = self.rfile.read(length).decode('utf8')

        if self.path == '/heartbeat':
            self.handle_heartbeat(rfile_str)
            return

        if self.is_admin_request(rfile_str):
            try:
                print('rejecting admin request from {}'.format(self.client_address))
            except:
                pass
            self.send_response(HTTPStatus.FORBIDDEN)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps({
                "ok": False,
                "error": "admin request type is not allowed via the forwarder"
            }).encode('utf-8'))
            return

        # Strip any caller-supplied requester_ip and re-inject the HTTP source
        # address. Downstream auth (e.g. is_trusted_requester) relies on this
        # field; trusting the client-supplied value would let any team escalate
        # to host-trusted operations by sending requester_ip="127.0.0.1".
        rfile_str = self._rewrite_requester_ip(rfile_str)

        sim_response = self.get_fwd_response(rfile_str)
        try:
            print("{} : {}".format(self.client_address, rfile_str))
        except:
            pass
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(sim_response.encode('utf-8'))
        self.end_headers()

    def is_admin_request(self, body):
        try:
            parsed = json.loads(body)
        except Exception:
            return False
        return parsed.get('RequestType') in ADMIN_REQUEST_TYPES

    def _rewrite_requester_ip(self, body):
        try:
            parsed = json.loads(body)
        except Exception:
            return body
        if not isinstance(parsed, dict):
            return body
        parsed['requester_ip'] = self.client_address[0]
        return json.dumps(parsed)

    def handle_heartbeat(self, body):
        try:
            data = json.loads(body)
            slot = int(data['slot'])
            team_name = data.get('team_name', 'unknown')
            with self.heartbeat_lock:
                self.heartbeat_timestamps[slot] = (time.time(), team_name)
            self.send_response(HTTPStatus.OK)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(b'{"ok": true}')
        except Exception as e:
            self.send_response(HTTPStatus.BAD_REQUEST)
            self.end_headers()
            self.wfile.write(json.dumps({"ok": False, "error": str(e)}).encode('utf-8'))

    def get_fwd_response(self, body):
        connection = http.client.HTTPConnection('localhost', self.target_port, timeout=3)
        headers = {
            'Content-type': 'application/json',
        }
        #body = json.dumps(body).encode('utf-8') # already a string here
        connection.request('POST', '/post', body, headers)
        response = connection.getresponse()
        response_string = ''
        if response.status != 200:
            pass
        else:
            response_string = response.read().decode('utf-8')
        return response_string


class HeartbeatReaper(threading.Thread):
    def __init__(self, handler):
        super().__init__(daemon=True)
        self.handler = handler

    def run(self):
        while True:
            time.sleep(REAPER_CHECK_INTERVAL_SEC)
            self.check_stale_slots()

    def check_stale_slots(self):
        now = time.time()
        stale_slots = []
        with self.handler.heartbeat_lock:
            for slot, (last_time, team_name) in self.handler.heartbeat_timestamps.items():
                if now - last_time > REAPER_STALE_THRESHOLD_SEC:
                    stale_slots.append((slot, team_name))
            for slot, _ in stale_slots:
                del self.handler.heartbeat_timestamps[slot]

        for slot, team_name in stale_slots:
            self.disconnect_team(slot, team_name)

    def disconnect_team(self, slot, team_name):
        logger = logging.getLogger('avrs')
        try:
            logger.info('reaper: disconnecting stale team {} from slot {}'.format(team_name, slot))
            subprocess.run(
                ['avrs', 'race-cloud', 'disconnect', team_name, '--local', '--slot', str(slot)],
                timeout=30)
        except Exception as e:
            logger.warning('reaper: failed to disconnect team {} from slot {}: {}'.format(team_name, slot, e))
