import can
import argparse
import errno
import socket
import struct
import time
import logging

BUFFER_SIZE = 512

# OSError errnos that mean the network is temporarily unusable (e.g. during a
# systemd-networkd restart, DHCP reacquire, ENI flap). Survive these so the
# python-can Notifier thread does not die on the first failed sendto.
TRANSIENT_NET_ERRNOS = {
    errno.ENETUNREACH,
    errno.EHOSTUNREACH,
    errno.ENETDOWN,
    errno.ENETRESET,
    errno.ENONET,
    errno.EADDRNOTAVAIL,
}

# Throttle error logging during sustained outages.
_LOG_THROTTLE_SEC = 5.0

CAN_FRAME_FORMATS = [
    '=H', # 0 bytes should never happen
    '=HB',
    '=HBB',
    '=HBBB',
    '=HBBBB',
    '=HBBBBB',
    '=HBBBBBB',
    '=HBBBBBBB',
    '=HBBBBBBBB'
]

class UdpTxCanListener(can.Listener):
    def __init__(self, target_port, target_ip):
        self.target_port = target_port
        self.target_ip = target_ip
        self.s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self._last_warn_ts = 0.0
        self._dropped_since_warn = 0
        self._logger = logging.getLogger('avrs')

    def on_message_received(self, msg):
        try:
            data = struct.pack(CAN_FRAME_FORMATS[len(msg.data)], msg.arbitration_id, *msg.data)
            self.s.sendto(data, (self.target_ip, self.target_port))
        except OSError as e:
            if e.errno in TRANSIENT_NET_ERRNOS:
                self._dropped_since_warn += 1
                now = time.monotonic()
                if now - self._last_warn_ts > _LOG_THROTTLE_SEC:
                    self._logger.warning(
                        'can bridge tx to {}:{} transient net error ({}): {} (dropped {} frames since last warn)'.format(
                            self.target_ip, self.target_port,
                            errno.errorcode.get(e.errno, e.errno), e,
                            self._dropped_since_warn))
                    self._last_warn_ts = now
                    self._dropped_since_warn = 0
                return
            self._logger.exception('can bridge tx fatal: {}'.format(e))
        except Exception as e:
            self._logger.exception('can bridge tx unexpected: {}'.format(e))

def can_bridge_loop(args):
    logger = logging.getLogger('avrs')
    logger.info('starting can bridge tx on {} to {}:{} (listen on {})'.format(
        args.vcan_name, args.peer_ip, args.peer_port, args.local_port))
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        #s.settimeout(0.1)
        s.bind(('', args.local_port))
        with can.interface.Bus(args.vcan_name, interface='socketcan') as bus:
            l = UdpTxCanListener(args.peer_port, args.peer_ip)
            can.Notifier(bus, [l])
            last_warn_ts = 0.0
            dropped_since_warn = 0
            while True:
                try:
                    data, server = s.recvfrom(BUFFER_SIZE)

                    l = len(data)

                    # ensure data is expected size
                    if l > 10 or l < 2:
                        continue

                    up = struct.unpack(CAN_FRAME_FORMATS[l - 2], data)

                    tx_msg = can.Message(
                        arbitration_id=up[0],
                        data=up[1:],
                        is_extended_id=False,
                        dlc=l - 2) # len is rx size - 1 bc we add id to front

                    bus.send(tx_msg)
                except OSError as e:
                    if e.errno in TRANSIENT_NET_ERRNOS or e.errno == errno.EINTR:
                        dropped_since_warn += 1
                        now = time.monotonic()
                        if now - last_warn_ts > _LOG_THROTTLE_SEC:
                            logger.warning(
                                'can bridge rx transient ({}): {} (dropped {} frames since last warn)'.format(
                                    errno.errorcode.get(e.errno, e.errno), e, dropped_since_warn))
                            last_warn_ts = now
                            dropped_since_warn = 0
                        continue
                    logger.error('can bridge fatal OSError: {}'.format(e))
                    break
                except can.CanError as e:
                    # vcan or bus.send hiccup; keep loop alive.
                    now = time.monotonic()
                    if now - last_warn_ts > _LOG_THROTTLE_SEC:
                        logger.warning('can bridge bus.send error: {}'.format(e))
                        last_warn_ts = now
                    continue
                except Exception as e:
                    logger.exception('can bridge unexpected: {}'.format(e))
                    break
    except Exception as e:
        logger.error('can bridge setup error: {}'.format(e))
        return

if __name__ == '__main__':

    parser = argparse.ArgumentParser(
        prog='canbridge',
        description='can bridge')

    vcan_name_psr = parser.add_argument(
        'vcan_name')

    peer_ip_psr = parser.add_argument(
        'peer_ip')

    peer_port_psr = parser.add_argument(
        'peer_port',
        type=int)

    peer_port_psr = parser.add_argument(
        'local_port',
        type=int)

    version_psr = parser.add_argument(
        '--peer_ip', 
        help='')

    parser.set_defaults(func=bridge_loop)

    args = parser.parse_args()
    args.func(args)