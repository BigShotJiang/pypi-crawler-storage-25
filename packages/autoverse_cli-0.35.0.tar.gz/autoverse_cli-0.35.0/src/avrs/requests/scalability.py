from avrs.requests.request import AvrsApiRequest


class AvrsSetScalabilityRequest(AvrsApiRequest):
    def __init__(self, parser, cfg):
        AvrsApiRequest.__init__(self, parser, cfg, 'SetScalability', '')
        psr = parser.add_parser(
            'set-scalability',
            help='set the global UE graphics scalability preset on the fly '
                 '(0=Low, 1=Medium, 2=High, 3=Epic). Not persisted across sim restarts.')
        psr.add_argument(
            'quality_level',
            type=int,
            choices=[0, 1, 2, 3],
            help='quality preset to apply globally (0=Low, 1=Medium, 2=High, 3=Epic)')
        psr.set_defaults(func=self.send_request)

    def get_request_body(self, args):
        return {
            'qualityLevel': args.quality_level
        }
