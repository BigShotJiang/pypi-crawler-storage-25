import os
import json
import http.client

from avrs.requests.request import AvrsApiRequest

# Loopback sim API endpoint — this admin command must only ever be issued
# from the sim host itself. Bypassing cfg (which typically points clients
# at the forwarder on 30333) ensures we always hit the sim directly, and
# the forwarder's admin denylist rejects this RequestType if a client
# somehow routes it through the public port.
HOST_ONLY_SIM_HOST = '127.0.0.1'
HOST_ONLY_SIM_PORT = 30313


def _on_off(value):
    v = value.lower()
    if v in ('on', 'true', '1', 'enable', 'enabled'):
        return True
    if v in ('off', 'false', '0', 'disable', 'disabled'):
        return False
    raise ValueError('expected on/off, got: {}'.format(value))


class AvrsToggleGroundTruthRequest(AvrsApiRequest):
    """
    Host-only runtime toggle for GroundTruthSensor on a specific vehicle.
    Pinned to 127.0.0.1:30313 so it cannot be invoked from remote clients.
    """

    def __init__(self, parser, cfg):
        AvrsApiRequest.__init__(self, parser, cfg, 'ToggleGroundTruth', '')
        psr = parser.add_parser(
            'toggle-ground-truth',
            help='[host-only] enable or disable ground truth messages for a specific vehicle at runtime')
        psr.add_argument(
            'target',
            help='target vehicle spec name or object id (e.g. eav24_teamA)')
        psr.add_argument(
            '--self',
            dest='self_state',
            type=_on_off,
            default=None,
            help='set self ground truth channel on or off')
        psr.add_argument(
            '--opponent',
            dest='opponent_state',
            type=_on_off,
            default=None,
            help='set opponent (v2v) ground truth channel on or off')
        psr.set_defaults(func=self.send_request)

    def get_request_body(self, args):
        self.target_object_id = args.target
        body = {
            'bOverrideSelf': args.self_state is not None,
            'bSelfEnabled': bool(args.self_state) if args.self_state is not None else False,
            'bOverrideOpponent': args.opponent_state is not None,
            'bOpponentEnabled': bool(args.opponent_state) if args.opponent_state is not None else False,
        }
        return body

    def send_http_request(self, args):
        if args.self_state is None and args.opponent_state is None:
            print('nothing to do — pass --self on|off and/or --opponent on|off')
            return

        if args.verbose:
            print('sending host-only request to: {}:{}'.format(
                HOST_ONLY_SIM_HOST, HOST_ONLY_SIM_PORT))

        connection = http.client.HTTPConnection(
            HOST_ONLY_SIM_HOST, HOST_ONLY_SIM_PORT, timeout=10)
        headers = {'Content-type': 'application/json'}
        body = json.dumps(self.get_request(args)).encode('utf-8')
        try:
            connection.request('POST', '/post', body, headers)
            response = connection.getresponse()
        except ConnectionRefusedError:
            print('error: could not reach sim api at {}:{} — this command must be run on the sim host'.format(
                HOST_ONLY_SIM_HOST, HOST_ONLY_SIM_PORT))
            return
        if response.status != 200:
            print('response had status code {}'.format(response.status))
        print('{}'.format(response.read().decode('utf-8')))
