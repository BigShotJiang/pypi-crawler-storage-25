from avrs.requests.rest_request import AvrsRestApiRequest


def _on_off(value):
    v = value.lower()
    if v in ('on', 'true', '1', 'enable', 'enabled'):
        return True
    if v in ('off', 'false', '0', 'disable', 'disabled'):
        return False
    raise ValueError('expected on/off, got: {}'.format(value))


class AvrsSetTrackLimitsRequest(AvrsRestApiRequest):
    """
    Host-side track-limit enforcement toggle. POSTs to the sim's modern
    item-bus REST API. Auto-gated on the sim side to qualifying and race
    sessions — flipping this on during free practice has no effect until
    a Q or R session starts.
    """

    def __init__(self, parser, cfg):
        AvrsRestApiRequest.__init__(
            self, parser, cfg, '/api/v1.0/set-track-limits', 'POST')
        psr = parser.add_parser(
            'set-track-limits',
            help='enable or disable host-side track-limit monitoring (Q/R only)')
        psr.add_argument(
            'state',
            type=_on_off,
            help='on/off (also accepts true/false, 1/0, enable/disable)')
        psr.set_defaults(func=self.send_request)

    def get_request_body(self, args):
        return {'enabled': bool(args.state)}
