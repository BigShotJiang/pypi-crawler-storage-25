from avrs.requests.request import AvrsApiRequest
from avrs.requests.rest_request import AvrsRestApiRequest
from datetime import datetime
from zoneinfo import ZoneInfo
import http.client
import json

ENVIRONMENT_TIMEZONES = {
    'yasmarina': 'Asia/Dubai',
    'yasmarinanorth': 'Asia/Dubai',
    'autonodrome': 'America/Chicago',
    'suzuka': 'Asia/Tokyo',
}

class AvrsEnvironmentRequests():
    def __init__(self, parser, cfg):
            psr = parser.add_parser('environment', help='Edits the environment')
            sps = psr.add_subparsers(required= True, help='')
            AvrsSetTimeOfDayRequest(sps, cfg)
            AvrsSetLocalTimeRequest(sps, cfg)
            AvrsSetTimeSpeedRequest(sps, cfg)
            AvrsGetEnvironmentMetaRequest(sps, cfg)


class AvrsSetTimeOfDayRequest(AvrsRestApiRequest):
    def __init__(self, parser, cfg):
        AvrsRestApiRequest.__init__(self, parser, cfg, '/api/v1.0/set-time-of-day', 'POST')
        psr = parser.add_parser('set-time-of-day', help='sets the current time of day')
        psr.add_argument('tod', type=float, help='The time of day (0-24) to set')
        psr.set_defaults(func=self.send_request)

    def get_request_body(self, args):
        return {
            'timeOfDay': args.tod
        }

class AvrsSetLocalTimeRequest(AvrsRestApiRequest):
    def __init__(self, parser, cfg):
        AvrsRestApiRequest.__init__(self, parser, cfg, '/api/v1.0/set-time-of-day', 'POST')
        psr = parser.add_parser('set-local-time',
            help='sets time of day to the real-world local time of the loaded circuit')
        psr.set_defaults(func=self.handle)

    def handle(self, args):
        sim_address = '0.0.0.0'
        sim_port = 51111
        try:
            connection = http.client.HTTPConnection(sim_address, sim_port, timeout=10)
            connection.request('GET', '/api/v1.0/get-web-viz-meta', '', {'Content-type': 'application/json'})
            response = connection.getresponse()
            if response.status != 200:
                print('Failed to get environment meta (status {})'.format(response.status))
                return
            meta = json.loads(response.read().decode('utf-8'))
        except Exception as e:
            print('Failed to connect to simulator: {}'.format(e))
            return

        current_env = meta.get('currentEnv', '').lower()
        tz_name = ENVIRONMENT_TIMEZONES.get(current_env)
        if not tz_name:
            print('Environment "{}" does not have a mapped timezone.'.format(current_env))
            print('Supported environments: {}'.format(', '.join(ENVIRONMENT_TIMEZONES.keys())))
            return

        now = datetime.now(ZoneInfo(tz_name))
        tod = now.hour + now.minute / 60.0 + now.second / 3600.0
        print('Environment: {} | Timezone: {} | Local time: {}'.format(
            current_env, tz_name, now.strftime('%H:%M:%S')))

        args.tod = tod
        self.send_request(args)

    def get_request_body(self, args):
        return {'timeOfDay': args.tod}

class AvrsSetTimeSpeedRequest(AvrsRestApiRequest):
    def __init__(self, parser, cfg):
        AvrsRestApiRequest.__init__(self, parser, cfg, '/api/v1.0/set-time-speed', 'POST')
        psr = parser.add_parser('set-time-speed',
            help='sets the time progression speed (0=paused, 1=realtime, 2/4/8/16=accelerated)')
        psr.add_argument('speed', type=int, choices=[0, 1, 2, 4, 8, 16],
            help='time speed multiplier')
        psr.set_defaults(func=self.send_request)

    def get_request_body(self, args):
        return {'timeSpeed': float(args.speed)}

class AvrsGetEnvironmentMetaRequest(AvrsApiRequest):
    def __init__(self, parser, cfg):
        AvrsApiRequest.__init__(self, parser, cfg, 'GetEnvironmentMeta', '')
        psr = parser.add_parser('get-meta', help='get metadata about the currently loaded environment')
        psr.set_defaults(func=self.send_request)

    def get_request_body(self, args):
            self.target_object_id = ''
            return {
            }

class AvrsSetEnvironmentRequest(AvrsApiRequest):
    def __init__(self, parser, cfg):
        AvrsApiRequest.__init__(self, parser, cfg, 'SetEnvironment', '')
        psr = parser.add_parser('set-environment', help='changes to a new environment')
        psr.add_argument('new_environment_name', help='name of desired environment')
        psr.set_defaults(func=self.send_request)

    def get_request_body(self, args):
        self.target_object_id = ''
        return {
            'newEnvironmentName': args.new_environment_name
        }