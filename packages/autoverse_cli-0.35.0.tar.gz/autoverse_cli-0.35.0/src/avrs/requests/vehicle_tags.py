from avrs.requests.request import AvrsApiRequest


class AvrsVehicleTagsRequests():
    def __init__(self, parser, cfg):
        psr = parser.add_parser('vehicle-tags', help='control vehicle name tag visibility')
        sps = psr.add_subparsers(required=True, help='sub-command for vehicle-tags')
        EnableVehicleTags(sps, cfg)
        DisableVehicleTags(sps, cfg)


class EnableVehicleTags(AvrsApiRequest):
    def __init__(self, parser, cfg):
        AvrsApiRequest.__init__(self, parser, cfg, 'SetVehicleTagVisibility', '')
        psr = parser.add_parser('enable', help='show vehicle name tags')
        psr.add_argument(
            'vehicle_name',
            nargs='?',
            default='Ego',
            help='the name of the vehicle (default: Ego)')
        psr.set_defaults(func=self.send_request)

    def get_request_body(self, args):
        self.target_object_id = args.vehicle_name
        return {
            'bVisible': True
        }


class DisableVehicleTags(AvrsApiRequest):
    def __init__(self, parser, cfg):
        AvrsApiRequest.__init__(self, parser, cfg, 'SetVehicleTagVisibility', '')
        psr = parser.add_parser('disable', help='hide vehicle name tags')
        psr.add_argument(
            'vehicle_name',
            nargs='?',
            default='Ego',
            help='the name of the vehicle (default: Ego)')
        psr.set_defaults(func=self.send_request)

    def get_request_body(self, args):
        self.target_object_id = args.vehicle_name
        return {
            'bVisible': False
        }
