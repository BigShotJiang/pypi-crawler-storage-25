import os
import json
import logging
import boto3
from botocore.auth import SigV4Auth
from botocore.awsrequest import AWSRequest
import urllib.request
from avrs.util import *

BASH_KILL_PROCESS_SCRIPT = '''
    PROC_NAME={pname}
    I=0
    TRIES=20
    while [ $I -le $TRIES ]; do

        pkill $PROC_NAME
        PROC_RUNNING=$(ps -A | grep $PROC_NAME)
        if [[ ! -z $PROC_RUNNING ]]; then
            echo process $PROC_NAME is still running
            if [ $I == $(( TRIES - 1 )) ]; then
                echo process is resisting. crushing its dreams with sigkill
                pkill -SIGKILL $PROC_NAME
            fi
        else
            echo process $PROC_NAME is not running
            break
        fi
        I=$(( I + 1 ))
        sleep 1
    done
'''

BASH_KILL_BY_LAUNCH_SCRIPT = '''
    ps -x | grep "{launch_phrase}" | awk '{{ print $1 }}' | xargs -L1 kill
'''

DEFAULT_RMW_QOS = '''
<?xml version="1.0" encoding="UTF-8" ?>
<profiles xmlns="http://www.eprosima.com/XMLSchemas/fastRTPS_Profiles">
    <library_settings>
        <intraprocess_delivery>OFF</intraprocess_delivery>
    </library_settings>
    <transport_descriptors>
        <transport_descriptor>
            <transport_id>morepeers</transport_id> <!-- string -->
            <type>UDPv4</type> <!-- string -->
            <maxInitialPeersRange>100</maxInitialPeersRange> <!-- uint32 -->
            <maxMessageSize>1400</maxMessageSize>
            <sendBufferSize>16777216</sendBufferSize>
            <receiveBufferSize>16777216</receiveBufferSize>
        </transport_descriptor>
    </transport_descriptors>
    <participant profile_name="participant_profile_ros2" is_default_profile="true">
        <rtps>
            <builtin>
                <metatrafficUnicastLocatorList>
                    <locator/>
                </metatrafficUnicastLocatorList>
                <initialPeersList>
                    <locator> <udpv4> <address>127.0.0.1</address> </udpv4> </locator>
                    <!--<locator> <udpv4> <address>PEER_0</address> </udpv4> </locator>PEER0-->
                    <!--<locator> <udpv4> <address>PEER_1</address> </udpv4> </locator>PEER1-->
                    <!--<locator> <udpv4> <address>PEER_2</address> </udpv4> </locator>PEER2-->
                    <!--<locator> <udpv4> <address>PEER_3</address> </udpv4> </locator>PEER3-->
                    <!--<locator> <udpv4> <address>PEER_4</address> </udpv4> </locator>PEER4-->
                    <!--<locator> <udpv4> <address>PEER_5</address> </udpv4> </locator>PEER5-->
                    <!--<locator> <udpv4> <address>PEER_6</address> </udpv4> </locator>PEER6-->
                    <!--<locator> <udpv4> <address>PEER_7</address> </udpv4> </locator>PEER7-->
                    <!--<locator> <udpv4> <address>PEER_8</address> </udpv4> </locator>PEER8-->
                    <!--<locator> <udpv4> <address>PEER_9</address> </udpv4> </locator>PEER9-->
                    <!--<locator> <udpv4> <address>PEER_10</address> </udpv4> </locator>PEER10-->
                    <!--<locator> <udpv4> <address>PEER_11</address> </udpv4> </locator>PEER11-->
                    <!--<locator> <udpv4> <address>PEER_12</address> </udpv4> </locator>PEER12-->
                </initialPeersList>
            </builtin>
            <userTransports>
            <transport_id>morepeers</transport_id>
            </userTransports>
            <useBuiltinTransports>false</useBuiltinTransports>
        </rtps>
    </participant>
</profiles>
'''

DEFAULT_RMW_CYCLONE = '''
    <?xml version="1.0" encoding="UTF-8" ?>
      <CycloneDDS>
        <Domain id="any">
            <General>
                <!-- autodetermine picks the interface on the default route (ens5 on EC2)
                     so Cyclone does not bind to docker0 / lo. -->
                <Interfaces>
                    <NetworkInterface autodetermine="true" multicast="default" />
                </Interfaces>
                <AllowMulticast>false</AllowMulticast>
                <!-- 1400 B caps fragment size below the 1500 MTU seen on
                     cross-region / peered / NAT'd paths. Intra-VPC jumbo
                     hosts reassemble fine; clients do not publish large
                     samples back, so the ~6x packet overhead stays
                     server-side. -->
                <MaxMessageSize>1400 B</MaxMessageSize>
                <FragmentSize>1344 B</FragmentSize>
            </General>
            <Discovery>
                <ParticipantIndex>auto</ParticipantIndex>
                <!-- Default is 9 (= 10 participants per domain). A2RL client
                     stacks (foxglove_bridge, planner, controller, eav24_bsu,
                     ...) routinely create >10 participants on a single domain
                     and silently fail with "Failed to find a free participant
                     index". Bump well above realistic team usage. -->
                <MaxAutoParticipantIndex>100</MaxAutoParticipantIndex>
                <Peers>
                        <Peer address='127.0.0.1'/>
                        <!--<Peer address='PEER_0'/>PEER0-->
                        <!--<Peer address='PEER_1'/>PEER1-->
                        <!--<Peer address='PEER_2'/>PEER2-->
                        <!--<Peer address='PEER_3'/>PEER3-->
                        <!--<Peer address='PEER_4'/>PEER4-->
                        <!--<Peer address='PEER_5'/>PEER5-->
                        <!--<Peer address='PEER_6'/>PEER6-->
                        <!--<Peer address='PEER_7'/>PEER7-->
                        <!--<Peer address='PEER_8'/>PEER8-->
                        <!--<Peer address='PEER_9'/>PEER9-->
                        <!--<Peer address='PEER_10'/>PEER10-->
                        <!--<Peer address='PEER_11'/>PEER11-->
                        <!--<Peer address='PEER_12'/>PEER12-->
                </Peers>
            </Discovery>
            <Internal>
                <SocketReceiveBufferSize min="16 MiB" max="16 MiB"/>
                <SocketSendBufferSize min="16 MiB" max="16 MiB"/>
            </Internal>
        </Domain>
    </CycloneDDS>
'''

DISABLE_PEER_QOS_SCRIPT = '''
    QOS_FILE_PATH={qos_path}
    CYCLONE_PATH={cyclone_path}
    PEER_ID={peer_id}

    # for the origin rmw qos file
    sed -i -E "s,(<locator> <udpv4> <address>)(.+)(</address> </udpv4> </locator>)<!--(PEER$PEER_ID-->),<!--\\1PEER$PEER_ID\\3\\4,g" $QOS_FILE_PATH

    # for the cyclone file
    sed -i -E "s,(<Peer address=')(.+)('/>)<!--(PEER$PEER_ID-->),<!--\\1PEER$PEER_ID\\3\\4,g" $CYCLONE_PATH

    VCAN_NAME=vcan$PEER_ID
    if [[ -e $VCAN_NAME.vcanlock ]]; then
        echo "stopping existing cannelloni connection with pid $(cat $VCAN_NAME.vcanlock)"
        kill $(cat $VCAN_NAME.vcanlock)
        rm $VCAN_NAME.vcanlock
    fi
'''

ENABLE_PEER_QOS_SCRIPT = '''
    QOS_FILE_PATH={qos_path}
    CYCLONE_PATH={cyclone_path}
    PEER_ID={peer_id}
    PEER_ADDRESS={peer_ip}

    # for the origin rmw qos file
    sed -i -E "s,(<!--?)(<locator> <udpv4> <address>)(.+)(</address> </udpv4> </locator>)(PEER$PEER_ID-->),\\2$PEER_ADDRESS\\4<!--\\5,g" $QOS_FILE_PATH

    # for the cyclone file
    sed -i -E "s,(<!--?)(<Peer address=')(.+)('/>)(PEER$PEER_ID-->),\\2$PEER_ADDRESS\\4<!--\\5,g" $CYCLONE_PATH
'''

CONNECT_PEER_VCAN_SCRIPT = '''
    PEER_ID={peer_id}
    PEER_ADDRESS={peer_ip}
    REMOTE_PORT={remote_port}
    LOCAL_PORT={local_port}
    VCAN_NAME={vcan_name}
    LOCK_FILE="$HOME/.$VCAN_NAME.vcanlock"
    LOG_FILE="$HOME/.$VCAN_NAME.vcanlog"
    if [[ -z $VCAN_NAME ]]; then
        VCAN_NAME=vcan$PEER_ID
    fi
    echo "connecting peer id $PEER_ID using local port $LOCAL_PORT and remote port $REMOTE_PORT and vcan name $VCAN_NAME" > "$LOG_FILE" 2>&1

    if [[ -e $LOCK_FILE ]]; then
        echo "stopping existing can_bridge connection with pid $(cat $LOCK_FILE)"
        kill $(cat $LOCK_FILE)
    fi

    # https://stackoverflow.com/questions/29142/getting-ssh-to-execute-a-command-in-the-background-on-target-machine
    # nohup to avoid SSH issues, send stdout to loni.log, send stderr to stdout, dont expect input, and background with "&"
    nohup avrs race-cloud bridge-can fg $VCAN_NAME $PEER_ADDRESS $REMOTE_PORT $LOCAL_PORT >>"$LOG_FILE" 2>&1 < /dev/null &
    echo "$!" > $LOCK_FILE
'''

CHECK_VCAN_EXISTS_SCRIPT = '''
    if [[ -z $(ip addr show | grep {vcan_name}) ]]; then
        echo -n "no"
    else
        echo -n "yes"
    fi
'''

CREATE_VCANS_SCRIPT = '''
    sudo modprobe vcan
    sudo ip link add name "{a}" type vcan
    sudo ip link set dev "{a}" up
    sudo ip link add name "{b}" type vcan
    sudo ip link set dev "{b}" up
    sudo ip link add name "{c}" type vcan
    sudo ip link set dev "{c}" up
'''

START_FWD_API_SCRIPT = '''
    nohup avrs race-cloud fwd-api fg {source_port} {target_port} >> ~/fwd_api.log 2>&1 < /dev/null &
    echo "$!" > ~/fwd_api_pid
'''

STOP_FWD_API_SCRIPT = '''
    if [[ -e ~/fwd_api_pid ]]; then
        kill $(cat ~/fwd_api_pid)
    fi
    rm ~/fwd_api_pid
'''

START_HEARTBEAT_SCRIPT = '''
    nohup avrs race-cloud heartbeat fg {sim_ip} {sim_port} {team_name} {slot} >> ~/.heartbeat.log 2>&1 < /dev/null &
    echo "$!" > ~/.heartbeat.lock
'''

STOP_HEARTBEAT_SCRIPT = '''
    if [[ -e ~/.heartbeat.lock ]]; then
        kill $(cat ~/.heartbeat.lock) 2>/dev/null || true
        rm -f ~/.heartbeat.lock
    fi
'''

GET_EC2_LOCAL_IP_SCRIPT = '''
    echo -n $(ec2metadata --local-ipv4)
'''

# kill a process with a given name
def bash_kill_process(pname):
    return run_process(['bash', '-c', 
        BASH_KILL_PROCESS_SCRIPT.format(**{'pname': pname})])

def bash_kill_process_by_launch_command(launch_command):
    return run_process(['bash', '-c',
        BASH_KILL_BY_LAUNCH_SCRIPT.format(**{'launch_phrase': launch_command})])

# start an exectuable in the background, sending output to a file
# stored at root with its name
def start_exe(exe_path):
    logger = logging.getLogger('avrs')
    logger.info('running {} and saving under {}'.format(exe_path, os.path.basename(exe_path).replace(' ', '')))
    return run_process(['bash', '-c',
        'nohup {} > ~/{}_output.log 2>&1 < /dev/null &'.format(exe_path, os.path.basename(exe_path).replace(' ', ''))])

def get_sim_install_path():
    sim_path = os.environ.get('AVRS_INSTALL_PATH', 
        os.path.join(os.environ['HOME'], 'autoverse-linux'))
    return sim_path

def get_sim_exe_path():
    exe_path = os.environ.get('AVRS_EXE_PATH',
        os.path.join(os.environ['HOME'], 'autoverse-linux', 'Linux', 'utils', 'run_autoverse.sh'))
    return exe_path

def get_rmw_qos_path():
    return os.path.join(os.environ['HOME'], '.rmw_qos.xml')

def get_rmw_cyclone_qos_path():
    return os.path.join(os.environ['HOME'], '.cyclone.xml')

def reset_rmw_qos():
    with open(get_rmw_qos_path(), 'w', encoding='utf-8') as f:
        f.write(DEFAULT_RMW_QOS)

def reset_rmw_cyclone_qos():
    with open(get_rmw_cyclone_qos_path(), 'w', encoding='utf-8') as f:
        f.write(DEFAULT_RMW_CYCLONE)

def disable_peer_qos(peer_id):
    if not os.path.isfile(get_rmw_qos_path()):
        reset_rmw_qos()
    if not os.path.isfile(get_rmw_cyclone_qos_path()):
        reset_rmw_cyclone_qos()
    pargs = {
        'qos_path': get_rmw_qos_path(),
        'cyclone_path': get_rmw_cyclone_qos_path(),
        'peer_id': peer_id
    }
    return run_process(['bash', '-c',
        DISABLE_PEER_QOS_SCRIPT.format(**pargs)])

def enable_peer_qos(peer_id, peer_ip):
    disable_peer_qos(peer_id) # disable first
    pargs = {
        'qos_path': get_rmw_qos_path(),
        'cyclone_path': get_rmw_cyclone_qos_path(),
        'peer_id': peer_id,
        'peer_ip': peer_ip
    }
    return run_process(['bash', '-c',
        ENABLE_PEER_QOS_SCRIPT.format(**pargs)])

def check_vcan_exists(vcan_name):
    pargs = {
        'vcan_name': vcan_name
    }
    pres = run_process(['bash', '-c',
        CHECK_VCAN_EXISTS_SCRIPT.format(**pargs)])
    return pres.out == 'yes'

def setup_vcans(vcan0, vcan1, vcan2):
    pargs = {
        'a': vcan0,
        'b': vcan1,
        'c': vcan2
    }
    pres = run_process(['bash', '-c',
        CREATE_VCANS_SCRIPT.format(**pargs)])
    return pres.out + ' ' + pres.err

def start_fwd_api(source_port, target_port):
    pargs = {
        'source_port': source_port,
        'target_port': target_port
    }
    pres = run_process(['bash', '-c', START_FWD_API_SCRIPT.format(**pargs)])
    return pres.out

def stop_fwd_api():
    pres = run_process(['bash', '-c', STOP_FWD_API_SCRIPT])
    return pres.out

def start_heartbeat(sim_ip, sim_port, team_name, slot):
    pargs = {
        'sim_ip': sim_ip,
        'sim_port': sim_port,
        'team_name': team_name,
        'slot': slot
    }
    pres = run_process(['bash', '-c', START_HEARTBEAT_SCRIPT.format(**pargs)])
    return pres.out

def stop_heartbeat():
    pres = run_process(['bash', '-c', STOP_HEARTBEAT_SCRIPT])
    return pres.out

def start_can_bridge(args):
    pargs = {
        'peer_ip': args.peer_ip,
        'peer_port': args.peer_port,
        'local_port': args.local_port
    }
    pres = run_process(['bash', 'c', START_CAN_BRIDGE_SCRIPT.format(**pargs)])
    return pres.out

def stop_can_brdige():
    pres = run_process(['bash'], '-c', STOP_CAN_BRIDGE_SCRIPT)
    return pres.out

def get_auto_vcan_name(peer_id, vcan_id):
    return 'vcan{}_{}'.format(peer_id, vcan_id)

def connect_peer_vcan(peer_id, peer_ip, vcan_id, vcan_name=''):
    logger = logging.getLogger('avrs')
    pargs = {
        'peer_id': peer_id,
        'peer_ip': peer_ip,
        'remote_port': 20000 + peer_id * 3 + vcan_id, # three ports per peer_id
        'local_port': 20000 + peer_id * 3 + vcan_id,
        'vcan_name': vcan_name if vcan_name != '' else get_auto_vcan_name(peer_id, vcan_id)
    }
    logger.info('connecting vcan with args: {}'.format(pargs))
    return run_process(['bash', '-c',
        CONNECT_PEER_VCAN_SCRIPT.format(**pargs)])

def get_local_instance_ip():
    try:
        pres = run_process(['bash', '-c', GET_EC2_LOCAL_IP_SCRIPT])
        if pres.out == '':
            return '127.0.0.1'
        return pres.out
    except:
        return '127.0.0.1'

def _cleanup_slot(slot, team_name, logger):
    """Tear down per-slot state. Order matters:
       1. Stop CAN bridges so UDP stops feeding the vehicle's sensors.
       2. Disable peer QoS.
       3. Despawn the vehicle (now safe — no live traffic into destroyed actor).
       4. Unregister config.
    """
    # local import avoids circular dependency with race_cloud_cfg_util
    from avrs.race_cloud_cfg_util import unregister_vehicle
    logger.info('cleaning up slot {} (team {})'.format(slot, team_name))
    try:
        for vcan_id in range(3):
            stop_vcan_bridge(get_auto_vcan_name(slot, vcan_id))
        disable_peer_qos(slot)
        despawn_vehicle(slot, team_name)
        unregister_vehicle(team_name)
    except Exception as e:
        logger.warning('cleanup error for slot {}: {}'.format(slot, e))

def reset_race_cloud_connection_for_slot(slot, expected_ip=None):
    """Reset state for a single slot only.

    If expected_ip is given, abort if the slot's reserved IP no longer matches —
    closes a TOCTOU between caller's slot lookup and this teardown.

    Intentionally does NOT touch global state (RMW QoS, cannelloni, heartbeat) —
    those are shared across all slots; only the global reset wipes them.

    Returns the team name that was cleaned up, or None.
    """
    logger = logging.getLogger('avrs')
    stored_team, stored_ip = get_slot_info(slot)
    if stored_team is None:
        logger.info('reset_race_cloud_connection_for_slot: slot {} is not reserved, nothing to clean'.format(slot))
        return None
    if expected_ip is not None and stored_ip != expected_ip:
        logger.warning(
            'slot {} ownership changed since lookup (stored_ip={}, expected={}); aborting cleanup'.format(
                slot, stored_ip, expected_ip))
        return None
    logger.info('resetting connection for slot {} (team {})'.format(slot, stored_team))
    _cleanup_slot(slot, stored_team, logger)
    # remove only this slot's reservation file
    slot_file_path = os.path.join(os.environ['HOME'], '.simslot_{}'.format(slot))
    try:
        if os.path.isfile(slot_file_path):
            os.remove(slot_file_path)
            logger.info('removed slot reservation file: {}'.format(slot_file_path))
    except Exception as e:
        logger.warning('failed to remove slot file {}: {}'.format(slot_file_path, e))
    return stored_team

def reset_race_cloud_connection():
    """Global reset: tear down every reserved slot, wipe all reservation files,
    and reset shared state (RMW QoS, cannelloni bridges, heartbeat). Used only
    on the trusted (sysadmin / host-local) path; untrusted callers go through
    reset_race_cloud_connection_for_slot for their own slot only."""
    logger = logging.getLogger('avrs')
    logger.info('resetting connection')

    # despawn vehicles and tear down per-slot state before wiping reservation files
    for i in range(12):
        stored_team, _ = get_slot_info(i)
        if stored_team is None:
            continue
        _cleanup_slot(i, stored_team, logger)

    reset_rmw_qos()
    reset_rmw_cyclone_qos()
    logger.info('removing vcanlog and vcanlock files')
    run_process(['bash', '-c', 'rm ~/.simslot*']) # remove slot reservations
    run_process(['bash', '-c', 'rm ~/.*.vcanlog*']) # remove slot reservations
    run_process(['bash', '-c', 'rm ~/.*.vcanlock']) # remove lock files
    logger.info('stopping race-cloud bridge-can')
    bash_kill_process_by_launch_command('avrs race-cloud bridge-can')
    logger.info('stopping heartbeat')
    bash_kill_process_by_launch_command('avrs race-cloud heartbeat')
    stop_heartbeat()
    run_process(['bash', '-c', 'rm -f ~/.heartbeat.lock'])
    run_process(['bash', '-c', 'rm -f ~/.heartbeat.log'])

def _log_proc(logger, tag, pres):
    """Log subprocess stdout/stderr if non-empty."""
    out = (pres.out or '').strip()
    err = (pres.err or '').strip()
    if out:
        logger.info('{} stdout: {}'.format(tag, out))
    if err:
        logger.warning('{} stderr: {}'.format(tag, err))

def despawn_team_vehicle(team_name):
    logger = logging.getLogger('avrs')
    logger.info('despawning team {} vehicle'.format(team_name))
    pres = run_process(['bash', '-c', 'avrs despawn-object {}'.format(team_name)])
    _log_proc(logger, 'despawn-object {}'.format(team_name), pres)

def despawn_vehicle(slot, name):
    # get the vcan name for this slot
    logger = logging.getLogger('avrs')
    logger.info('despawning vehicle {} for slot {}'.format(name, slot))
    pres = run_process(['bash', '-c', 'avrs despawn-object {}'.format(name)])
    _log_proc(logger, 'despawn-object {}'.format(name), pres)
    return pres

def spawn_vehicle(landmark, name):
    logger = logging.getLogger('avrs')
    logger.info('spawning vehicle {} for landmark {}'.format(name, landmark))
    pres = run_process(['bash', '-c', 'avrs spawn-object {} {}'.format(name, landmark)])
    _log_proc(logger, 'spawn-object {} {}'.format(name, landmark), pres)
    return pres

def get_slot_info(slot):
    """Read slot reservation info from file. Returns (team_name, ip) or (None, None) if not found."""
    slot_file_path = os.path.join(os.environ['HOME'], '.simslot_{}'.format(slot))
    if not os.path.isfile(slot_file_path):
        return (None, None)
    
    with open(slot_file_path, 'r', encoding='utf-8') as f:
        content = f.read()
        # Support both old format (just IP) and new format (JSON with team_name and ip)
        try:
            data = json.loads(content)
            return (data.get('team_name'), data.get('ip'))
        except json.JSONDecodeError:
            # Old format: content is just the IP
            return (None, content)

def any_slot_reserved():
    """Return True if any slot currently has a reservation file."""
    for i in range(12):
        stored_team, stored_ip = get_slot_info(i)
        if stored_team is not None or stored_ip is not None:
            return True
    return False

def find_slot_by_team_name(team_name):
    """Find a slot reserved by a specific team. Returns slot number or -1 if not found."""
    logger = logging.getLogger('avrs')
    slot_file_dir = os.environ['HOME']
    for i in range(12):
        stored_team, stored_ip = get_slot_info(i)
        if stored_team == team_name:
            logger.info('found team {} in slot {}'.format(team_name, i))
            return i
    logger.info('team {} not found in any slot'.format(team_name))
    return -1

def find_slot_by_ip(ip):
    """Find a slot reserved by a given IP. Returns slot number or -1 if not found."""
    # Guard against None/empty matching unreserved slots (get_slot_info returns
    # (None, None) for empty slots, so without this any falsy ip would match slot 0).
    if not ip:
        return -1
    for i in range(12):
        _, stored_ip = get_slot_info(i)
        if stored_ip == ip:
            return i
    return -1

def is_trusted_requester(requester_ip):
    """Return True if the requester IP is trusted to perform global operations.

    Trusted = no requester (interactive sysadmin), loopback, or the sim host's own IP.
    """
    if requester_ip is None or requester_ip == '' or requester_ip == '127.0.0.1':
        return True
    return requester_ip == get_local_instance_ip()

def verify_disconnect_authorization(slot, requester_ip):
    """Verify that the requester is authorized to disconnect a team from a slot.

    Returns (authorized, message) tuple.
    Authorization is granted if:
    - This is a local (server-side) request (requester_ip is None or '127.0.0.1')
    - The requester IP matches the team's stored connection IP (private VPC view)
    - The requester IP matches the team's stored auth_ip (Lambda's API Gateway
      sourceIp view, captured at connect time when supported by the caller)
    """
    logger = logging.getLogger('avrs')
    stored_team, stored_ip = get_slot_info(slot)
    stored_auth_ip = get_slot_auth_ip(slot)

    if stored_team is None and stored_ip is None:
        return (False, 'slot {} is not reserved'.format(slot))

    # Server-side requests are always authorized
    if requester_ip is None or requester_ip == '127.0.0.1':
        logger.info('disconnect authorized: server-side request')
        return (True, 'authorized (server)')

    # Team can disconnect themselves (private VPC IP)
    if stored_ip == requester_ip:
        logger.info('disconnect authorized: team {} disconnecting themselves (ip match)'.format(stored_team))
        return (True, 'authorized (own team ip)')

    # Team can disconnect themselves (Lambda's view, e.g. public NAT IP)
    if stored_auth_ip is not None and stored_auth_ip == requester_ip:
        logger.info('disconnect authorized: team {} disconnecting themselves (auth_ip match)'.format(stored_team))
        return (True, 'authorized (own team auth_ip)')

    logger.warning(
        'disconnect denied: requester {} is not authorized for slot {} '
        '(owned by {}, ip={}, auth_ip={})'.format(
            requester_ip, slot, stored_team, stored_ip, stored_auth_ip))
    return (False, 'not authorized: only the server or the team itself can disconnect')

def try_get_open_slot(team_name, ip, auth_ip=None):
    logger = logging.getLogger('avrs')
    slot_file_dir = os.environ['HOME']
    logger.info('finding a slot for team {}'.format(team_name))

    # Pass 1: find existing reservation matching both team name and ip (reconnect)
    for i in range(12):
        stored_team, stored_ip = get_slot_info(i)
        if stored_team == team_name and stored_ip == ip:
            logger.info('slot {} already reserved by team {}'.format(i, team_name))
            return (True, 'slot {} is already reserved by you'.format(i), i)

    # Pass 2: allocate first empty slot atomically
    for i in range(12):
        slot_file_path = os.path.join(slot_file_dir, '.simslot_{}'.format(i))
        try:
            fd = os.open(slot_file_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            slot_payload = {'team_name': team_name, 'ip': ip}
            if auth_ip:
                slot_payload['auth_ip'] = auth_ip
            os.write(fd, json.dumps(slot_payload).encode('utf-8'))
            os.close(fd)
            logger.info('slot {} successfully reserved by team {}'.format(i, team_name))
            return (True, 'reserved slot {}'.format(i), i)
        except FileExistsError:
            continue

    logger.info('no open slot found for team {}'.format(team_name))
    return (False, 'no open slots', -1)

def get_slot_auth_ip(slot):
    """Return the auth_ip recorded for a slot, or None if the slot is unreserved
    or was reserved by an older CLI without auth_ip."""
    slot_file_path = os.path.join(os.environ['HOME'], '.simslot_{}'.format(slot))
    if not os.path.isfile(slot_file_path):
        return None
    try:
        with open(slot_file_path, 'r', encoding='utf-8') as f:
            data = json.loads(f.read())
        return data.get('auth_ip')
    except (json.JSONDecodeError, OSError):
        return None

def call_race_cloud_api(body):
    logger = logging.getLogger('avrs')
    logger.info('calling race-cloud api with body: {}'.format(body))

    url = 'https://5sgtxlpk3d.execute-api.us-east-1.amazonaws.com/prodaspire/race-connect'
    region = 'us-east-1'

    # Get credentials from boto3 session (uses IAM role on EC2)
    session = boto3.Session()
    credentials = session.get_credentials()
    
    if credentials is None:
        return (False, 'No AWS credentials available')

    # Prepare the request body
    body_json = json.dumps(body)

    # Create AWS request for signing
    request = AWSRequest(
        method='POST',
        url=url,
        data=body_json,
        headers={'Content-Type': 'application/json'}
    )

    # Sign the request with SigV4
    SigV4Auth(credentials, 'execute-api', region).add_auth(request)

    # Make the request using urllib
    try:
        req = urllib.request.Request(
            url,
            data=body_json.encode('utf-8'),
            headers=dict(request.headers),
            method='POST'
        )
        with urllib.request.urlopen(req) as response:
            response_body = response.read().decode('utf-8')
            return (True, response_body)
    except urllib.error.HTTPError as e:
        error_body = e.read().decode('utf-8')
        logger.error('API error - status: {}, body: {}'.format(e.code, error_body))
        return (False, 'response had status code {} - {}'.format(e.code, error_body))
    except Exception as e:
        logger.error('API request failed: {}'.format(str(e)))
        return (False, 'request failed: {}'.format(str(e)))

def get_api_script_response(raw):
    logger = logging.getLogger('avrs')
    
    # Parse the raw JSON response
    api_response = json.loads(raw)
    
    # Handle different response formats from API Gateway
    # Format 1: {"body": "{...}"} - Lambda Proxy integration with string body
    # Format 2: {"script_response": {...}, "sim_private_ip": ...} - Direct response
    if 'body' in api_response:
        body_str = api_response['body']
        # Body is a JSON string from Lambda Proxy integration
        decoded = json.loads(body_str) if isinstance(body_str, str) else body_str
    else:
        # Response came directly without body wrapper
        decoded = api_response
    
    logger.info('race cloud api response: {}'.format(decoded))
    
    if decoded['script_response']['statusCode'] != 200:
        return (False, 'inner response had bad status code {}'.format(decoded))

    # Parse the script_response body
    script_body = decoded['script_response']['body']
    if isinstance(script_body, str):
        script_body = json.loads(script_body)

    return (True, script_body, decoded['sim_private_ip'])


STOP_VCAN_BRIDGE_SCRIPT = '''
    VCAN_NAME={vcan_name}
    LOCK_FILE="$HOME/.$VCAN_NAME.vcanlock"
    if [[ -e $LOCK_FILE ]]; then
        echo "stopping CAN bridge for $VCAN_NAME with pid $(cat $LOCK_FILE)"
        kill $(cat $LOCK_FILE) 2>/dev/null || true
        rm -f $LOCK_FILE
    else
        echo "no lock file found for $VCAN_NAME"
    fi
'''

def stop_vcan_bridge(vcan_name):
    """Stop a specific vcan bridge by name."""
    logger = logging.getLogger('avrs')
    logger.info('stopping vcan bridge for {}'.format(vcan_name))
    pargs = {'vcan_name': vcan_name}
    pres = run_process(['bash', '-c', STOP_VCAN_BRIDGE_SCRIPT.format(**pargs)])
    _log_proc(logger, 'stop_vcan_bridge {}'.format(vcan_name), pres)
    return pres

def remove_slot_reservation(slot):
    """Remove the slot reservation file for a given slot."""
    logger = logging.getLogger('avrs')
    slot_file_path = os.path.join(os.environ['HOME'], '.simslot_{}'.format(slot))
    if os.path.isfile(slot_file_path):
        logger.info('removing slot reservation file: {}'.format(slot_file_path))
        os.remove(slot_file_path)
    else:
        logger.info('no slot reservation file found for slot {}'.format(slot))
    