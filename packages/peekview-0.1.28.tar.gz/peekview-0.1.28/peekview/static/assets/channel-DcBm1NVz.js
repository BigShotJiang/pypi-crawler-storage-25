import{aH as o,aI as n}from"./EntryDetailView-BAKYV0xv.js";const t=(a,r)=>o.lang.round(n.parse(a)[r]);export{t as c};
