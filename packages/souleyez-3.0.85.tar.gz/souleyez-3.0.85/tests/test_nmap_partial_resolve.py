#!/usr/bin/env python3
"""
Tests for nmap handler status when one or more multi-target hostnames
fail to resolve.

Background: scanning a list of 10 hostnames where 9 resolve cleanly
and 1 doesn't ('Failed to resolve' line in nmap output) used to mark
the entire job as ERROR. That suppressed every downstream chain
(http_fingerprint, gobuster, nuclei, etc.) for the 9 hosts that were
scanned successfully — same anti-pattern as the v3.0.66 nuclei and
v3.0.67 katana false-error regressions.

Findings-first: if any host came up, the scan was successful for
those hosts; partial-resolve is a warning, not a fatal error.
WARNING status is chainable, so chains fire as expected.
"""

from souleyez.engine.job_status import (CHAINABLE_STATUSES, STATUS_DONE,
                                        STATUS_ERROR, STATUS_NO_RESULTS,
                                        STATUS_WARNING, is_chainable)


def test_warning_status_is_chainable():
    """
    Locks in the design contract: WARNING must trigger auto-chain so
    that nmap partial-resolve scans still fan out to http_fingerprint
    et al.
    """
    assert STATUS_WARNING in CHAINABLE_STATUSES
    assert is_chainable(STATUS_WARNING) is True


def test_error_status_is_not_chainable():
    """ERROR remains the hard kill-switch for chaining."""
    assert STATUS_ERROR not in CHAINABLE_STATUSES
    assert is_chainable(STATUS_ERROR) is False


def test_done_and_no_results_chainable():
    """Sanity: existing status semantics unchanged."""
    assert is_chainable(STATUS_DONE) is True
    assert is_chainable(STATUS_NO_RESULTS) is True


# ---------------------------------------------------------------------------
# nmap handler status decision (the fix)
# ---------------------------------------------------------------------------


def _decide_status(hosts_up: int, nmap_error):
    """
    Mirrors the v3.0.85 logic in NmapHandler.parse_job. Soft errors
    (DNS resolution failures — operator-induced, not a scan problem)
    don't downgrade the job; only hard errors (permission, host down,
    real tool failures) do.
    """
    soft_error = nmap_error and nmap_error.lower() == "failed to resolve"
    hard_error = nmap_error and not soft_error
    if hosts_up > 0:
        return STATUS_WARNING if hard_error else STATUS_DONE
    if hard_error or soft_error:
        return STATUS_ERROR
    return STATUS_NO_RESULTS


def test_partial_resolve_with_findings_is_done():
    """
    v3.0.85 contract: the exact engagement #11 scenario — 9 of 10
    multi-target hostnames resolved and got scanned, 1 didn't exist
    in DNS — should be DONE, not WARNING. The skipped target is
    surfaced in the summary, not the status. Operator-induced typos
    in the target list shouldn't poison the audit-evidence narrative.
    """
    assert _decide_status(hosts_up=9, nmap_error="failed to resolve") == STATUS_DONE
    assert is_chainable(_decide_status(9, "failed to resolve")) is True


def test_hard_error_with_findings_is_warning():
    """
    A real tool error (permission denied, host seems down, etc.) WITH
    findings should still be WARNING — the scan completed but
    something unusual happened. Chains still fire.
    """
    assert (
        _decide_status(hosts_up=5, nmap_error="permission denied")
        == STATUS_WARNING
    )
    assert is_chainable(_decide_status(5, "host seems down")) is True


def test_total_resolve_failure_is_error():
    """
    Inverse case: zero hosts came up AND error pattern detected ->
    real failure, no chains. Both soft and hard errors fail this way.
    """
    assert _decide_status(hosts_up=0, nmap_error="failed to resolve") == STATUS_ERROR
    assert _decide_status(hosts_up=0, nmap_error="permission denied") == STATUS_ERROR
    assert is_chainable(_decide_status(0, "failed to resolve")) is False


def test_clean_scan_is_done():
    """No errors and hosts up — vanilla success."""
    assert _decide_status(hosts_up=5, nmap_error=None) == STATUS_DONE


def test_no_hosts_no_error_is_no_results():
    """All hosts down or filtered, no error pattern — no_results."""
    assert _decide_status(hosts_up=0, nmap_error=None) == STATUS_NO_RESULTS
