#!/usr/bin/env python3
"""
Tests for v3.0.84 audit-evidence report sections:
- audit_evidence_host_summary  (per-host findings table)
- audit_evidence_tool_coverage (host x tool grid)
- audit_evidence_severity_histogram (per-tool severity bars)

Each section is a pure HTML-string builder, so the tests assert on
the rendered output: presence of expected table cells, severity
counts, tool names, and CSS class hooks the WeasyPrint stylesheet
keys off.
"""

from souleyez.reporting.formatters import HTMLFormatter


def _formatter():
    return HTMLFormatter()


def _findings(scenario="mixed"):
    """
    Helper to build a findings_by_severity dict matching what
    list_findings() returns. affected_target is the COALESCE'd
    hostname-or-IP introduced in v3.0.77.
    """
    if scenario == "empty":
        return {"critical": [], "high": [], "medium": [], "low": [], "info": []}
    if scenario == "mixed":
        return {
            "critical": [
                {"tool": "nmap", "affected_target": "api.freshpaint-staging.com",
                 "title": "Slowloris CVE-2007-6750"},
            ],
            "high": [
                {"tool": "nmap", "affected_target": "api.freshpaint-staging.com",
                 "title": "Backup file"},
                {"tool": "nikto", "affected_target": "app.freshpaint-staging.com",
                 "title": "Misconfig"},
            ],
            "medium": [
                {"tool": "http_fingerprint",
                 "affected_target": "app.freshpaint-staging.com",
                 "title": "CSP unsafe-inline"},
                {"tool": "tls_check",
                 "affected_target": "freshpaint-cdn-staging.com",
                 "title": "HSTS missing"},
            ],
            "low": [
                {"tool": "dmarc_check",
                 "affected_target": "freshpaint-staging.com",
                 "title": "DMARC p=none"},
            ],
            "info": [],
        }


# ---------------------------------------------------------------------------
# Per-host findings summary
# ---------------------------------------------------------------------------


def test_host_summary_renders_table_with_severity_counts():
    f = _formatter()
    findings = _findings("mixed")
    html = f.audit_evidence_host_summary(findings, hosts=[])
    assert "<section" in html
    assert "host-summary-table" in html
    assert "api.freshpaint-staging.com" in html
    assert "app.freshpaint-staging.com" in html
    # api host has 1 critical + 1 high = 2 total
    assert ">2<" in html  # total cell


def test_host_summary_includes_zero_finding_hosts_from_scope():
    """
    Hosts that were tested but produced no findings should appear with
    zero counts — coverage evidence, not absence of testing.
    """
    f = _formatter()
    findings = _findings("mixed")
    scope_hosts = [
        {"hostname": "perfalytics-staging.com", "ip_address": "1.1.1.1"},
        # Already in findings — should not duplicate
        {"hostname": "api.freshpaint-staging.com", "ip_address": "2.2.2.2"},
    ]
    html = f.audit_evidence_host_summary(findings, hosts=scope_hosts)
    assert "perfalytics-staging.com" in html
    assert "row-clean" in html  # zero-row class applied


def test_host_summary_empty_returns_empty_string():
    f = _formatter()
    html = f.audit_evidence_host_summary(_findings("empty"), hosts=[])
    assert html == ""


def test_host_summary_handles_missing_target_field():
    """Defensive: a finding with no affected_target shouldn't crash."""
    f = _formatter()
    findings = {
        "critical": [],
        "high": [{"tool": "x", "title": "y"}],  # no host fields
        "medium": [], "low": [], "info": [],
    }
    html = f.audit_evidence_host_summary(findings, hosts=[])
    assert "(unknown host)" in html


# ---------------------------------------------------------------------------
# Tool coverage matrix
# ---------------------------------------------------------------------------


def test_tool_coverage_renders_host_x_tool_matrix():
    f = _formatter()
    findings = _findings("mixed")
    html = f.audit_evidence_tool_coverage(
        findings,
        hosts=[],
        tools_used={"nmap", "nikto", "http_fingerprint", "tls_check",
                    "dmarc_check"},
    )
    assert "tool-coverage-table" in html
    # Tool headers
    assert ">nmap<" in html
    assert ">nikto<" in html
    assert ">tls_check<" in html
    # Hosts
    assert "api.freshpaint-staging.com" in html
    # Hit cells (CSS class)
    assert "cov-cell hit" in html
    # Clean cells (CSS class)
    assert "cov-cell clean" in html


def test_tool_coverage_clean_cell_for_untested_host_tool_pair():
    """
    When a host wasn't hit by a tool but the tool was used in the
    engagement, the cell should be clean (empty), not omitted.
    """
    f = _formatter()
    findings = {
        "critical": [],
        "high": [{"tool": "nmap", "affected_target": "api.example.com"}],
        "medium": [], "low": [], "info": [],
    }
    html = f.audit_evidence_tool_coverage(
        findings,
        hosts=[],
        tools_used={"nmap", "nikto", "tls_check"},
    )
    # api.example.com has nmap hit, so 1 hit cell + 2 clean cells
    assert html.count("cov-cell hit") == 1
    assert html.count("cov-cell clean") == 2


def test_tool_coverage_empty_returns_empty_string():
    f = _formatter()
    html = f.audit_evidence_tool_coverage(
        _findings("empty"), hosts=[], tools_used=set()
    )
    assert html == ""


def test_tool_coverage_filters_unknown_none_tools():
    """tools_used may contain noise like 'unknown' / 'none' — drop them."""
    f = _formatter()
    findings = {
        "critical": [],
        "high": [{"tool": "nmap", "affected_target": "x"}],
        "medium": [], "low": [], "info": [],
    }
    html = f.audit_evidence_tool_coverage(
        findings, hosts=[], tools_used={"nmap", "unknown", "none", "n/a"}
    )
    assert ">nmap<" in html
    assert ">unknown<" not in html
    assert ">n/a<" not in html


# ---------------------------------------------------------------------------
# Severity histogram per tool
# ---------------------------------------------------------------------------


def test_histogram_renders_bars_per_tool():
    f = _formatter()
    findings = _findings("mixed")
    html = f.audit_evidence_severity_histogram(findings)
    assert "audit-severity-histogram" in html
    assert "histogram-row" in html
    # Each tool that produced findings should have a label
    assert "nmap" in html
    assert "nikto" in html
    assert "http_fingerprint" in html
    # Severity bar segments
    assert "hist-critical" in html
    assert "hist-high" in html
    assert "hist-medium" in html


def test_histogram_segments_have_width():
    """Width is computed as % of global max — sanity check it's emitted."""
    f = _formatter()
    findings = _findings("mixed")
    html = f.audit_evidence_severity_histogram(findings)
    assert "width:" in html


def test_histogram_empty_returns_empty_string():
    f = _formatter()
    assert f.audit_evidence_severity_histogram(_findings("empty")) == ""


def test_histogram_includes_total_count_per_tool():
    """Each tool row should show a count in parens."""
    f = _formatter()
    findings = _findings("mixed")
    html = f.audit_evidence_severity_histogram(findings)
    assert "histogram-total" in html
    assert "(2)" in html  # nmap has 2 findings


# ---------------------------------------------------------------------------
# Integration: all three together don't crash on real-shaped input
# ---------------------------------------------------------------------------


def test_full_audit_evidence_section_renders_for_engagement_11_shape():
    f = _formatter()
    findings = _findings("mixed")
    hosts = [
        {"hostname": "api.freshpaint-staging.com", "ip_address": "10.0.0.1"},
        {"hostname": "app.freshpaint-staging.com", "ip_address": "10.0.0.2"},
        {"hostname": "perfalytics-staging.com", "ip_address": "10.0.0.3"},
        {"hostname": "freshpaint-cdn-staging.com", "ip_address": "10.0.0.4"},
        {"hostname": "freshpaint-staging.com", "ip_address": "10.0.0.5"},
    ]
    tools = {"nmap", "http_fingerprint", "nikto", "tls_check",
             "dmarc_check", "origin_check"}

    h = f.audit_evidence_host_summary(findings, hosts=hosts)
    t = f.audit_evidence_tool_coverage(findings, hosts=hosts, tools_used=tools)
    s = f.audit_evidence_severity_histogram(findings)

    # All three render and together produce substantive HTML
    combined = h + t + s
    assert len(combined) > 1000
    # Each scoped host appears in the host summary
    for host in hosts:
        assert host["hostname"] in combined
    # Each tool appears in the coverage matrix
    for tool in tools:
        assert tool in combined
