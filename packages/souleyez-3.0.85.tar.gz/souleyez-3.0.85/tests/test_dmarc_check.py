#!/usr/bin/env python3
"""
Tests for v3.0.83 dmarc_check plugin and handler.

Covers:
- Apex extraction from URLs / hostnames
- Args parsing
- Plugin loader convention (mod.plugin instance)
- SPF classification (qualifier, lookup count)
- DMARC classification (policy, rua presence)
- Handler severity mapping for each finding category
"""

from souleyez.handlers.dmarc_check_handler import DmarcCheckHandler
from souleyez.plugins.dmarc_check import (DmarcCheckPlugin, _extract_apex,
                                          _parse_args)

# ---------------------------------------------------------------------------
# Apex extraction
# ---------------------------------------------------------------------------


def test_apex_from_subdomain():
    assert _extract_apex("app.freshpaint.io") == "freshpaint.io"
    assert _extract_apex("api.v2.freshpaint-staging.com") == "freshpaint-staging.com"


def test_apex_from_url():
    assert _extract_apex("https://app.freshpaint.io/path") == "freshpaint.io"
    assert _extract_apex("http://api.example.com:8080") == "example.com"


def test_apex_from_apex():
    assert _extract_apex("freshpaint.io") == "freshpaint.io"


def test_apex_from_empty():
    assert _extract_apex("") is None
    assert _extract_apex(None) is None


def test_apex_lowercases():
    assert _extract_apex("APP.Freshpaint.IO") == "freshpaint.io"


# ---------------------------------------------------------------------------
# Args parsing
# ---------------------------------------------------------------------------


def test_parse_args_defaults():
    out = _parse_args([])
    assert out["timeout"] == 5
    assert "default" in out["selectors"]


def test_parse_args_timeout():
    out = _parse_args(["--timeout", "10"])
    assert out["timeout"] == 10


def test_parse_args_custom_selectors():
    out = _parse_args(["--selectors", "google,k1,sendgrid"])
    assert out["selectors"] == ["google", "k1", "sendgrid"]


# ---------------------------------------------------------------------------
# Plugin loader convention
# ---------------------------------------------------------------------------


def test_plugin_module_handle_is_lowercase_instance():
    from souleyez.plugins import dmarc_check as mod

    assert hasattr(mod, "plugin")
    assert isinstance(mod.plugin, DmarcCheckPlugin)


def test_plugin_metadata():
    from souleyez.plugins import dmarc_check as mod

    assert mod.plugin.tool == "dmarc_check"
    assert mod.plugin.category == "reconnaissance"


# ---------------------------------------------------------------------------
# Handler — severity mapping for typical inputs
# ---------------------------------------------------------------------------


class _RecordingFM:
    def __init__(self):
        self.added = []

    def add_finding(self, **kwargs):
        self.added.append(kwargs)


def test_spf_missing_is_medium():
    handler = DmarcCheckHandler()
    fm = _RecordingFM()
    parsed = {
        "apex": "example.com",
        "spf": {"present": False},
    }
    n = handler._check_spf(99, 1, "example.com", parsed, fm)
    assert n == 1
    assert fm.added[0]["severity"] == "medium"
    assert "SPF" in fm.added[0]["title"]


def test_spf_plus_all_is_high():
    handler = DmarcCheckHandler()
    fm = _RecordingFM()
    parsed = {
        "apex": "example.com",
        "spf": {
            "present": True,
            "ends_with_all": "+all",
            "lookup_count": 3,
            "raw": "v=spf1 include:_spf.google.com +all",
        },
    }
    n = handler._check_spf(99, 1, "example.com", parsed, fm)
    assert any(f["severity"] == "high" for f in fm.added)
    assert any("+all" in f["title"] for f in fm.added)


def test_spf_lookup_limit_is_low():
    handler = DmarcCheckHandler()
    fm = _RecordingFM()
    parsed = {
        "apex": "example.com",
        "spf": {
            "present": True,
            "ends_with_all": "-all",
            "lookup_count": 12,  # over 10
            "raw": "v=spf1 ... -all",
        },
    }
    handler._check_spf(99, 1, "example.com", parsed, fm)
    assert any(f["severity"] == "low" for f in fm.added)


def test_spf_strong_no_findings():
    handler = DmarcCheckHandler()
    fm = _RecordingFM()
    parsed = {
        "apex": "example.com",
        "spf": {
            "present": True,
            "ends_with_all": "-all",
            "lookup_count": 5,
            "raw": "v=spf1 include:_spf.google.com -all",
        },
    }
    handler._check_spf(99, 1, "example.com", parsed, fm)
    assert fm.added == []


def test_dmarc_missing_is_medium():
    handler = DmarcCheckHandler()
    fm = _RecordingFM()
    parsed = {"apex": "example.com", "dmarc": {"present": False}}
    n = handler._check_dmarc(99, 1, "example.com", parsed, fm)
    assert n == 1
    assert fm.added[0]["severity"] == "medium"


def test_dmarc_p_none_is_low():
    handler = DmarcCheckHandler()
    fm = _RecordingFM()
    parsed = {
        "apex": "example.com",
        "dmarc": {
            "present": True,
            "policy": "none",
            "rua": "mailto:dmarc@example.com",
            "raw": "v=DMARC1; p=none; rua=mailto:dmarc@example.com",
        },
    }
    handler._check_dmarc(99, 1, "example.com", parsed, fm)
    assert any(f["severity"] == "low" for f in fm.added)


def test_dmarc_no_rua_is_low():
    handler = DmarcCheckHandler()
    fm = _RecordingFM()
    parsed = {
        "apex": "example.com",
        "dmarc": {
            "present": True,
            "policy": "reject",
            "rua": None,
            "raw": "v=DMARC1; p=reject",
        },
    }
    handler._check_dmarc(99, 1, "example.com", parsed, fm)
    assert any(f["severity"] == "low" for f in fm.added)


def test_dmarc_strong_no_findings():
    handler = DmarcCheckHandler()
    fm = _RecordingFM()
    parsed = {
        "apex": "example.com",
        "dmarc": {
            "present": True,
            "policy": "reject",
            "rua": "mailto:dmarc@example.com",
            "raw": "v=DMARC1; p=reject; rua=mailto:dmarc@example.com",
        },
    }
    handler._check_dmarc(99, 1, "example.com", parsed, fm)
    assert fm.added == []


def test_dnssec_missing_is_low():
    handler = DmarcCheckHandler()
    fm = _RecordingFM()
    parsed = {
        "apex": "example.com",
        "dnssec": {"dnskey_present": False, "ad_flag": False},
    }
    n = handler._check_dnssec(99, 1, "example.com", parsed, fm)
    assert n == 1
    assert fm.added[0]["severity"] == "low"


def test_dnssec_present_no_finding():
    handler = DmarcCheckHandler()
    fm = _RecordingFM()
    parsed = {
        "apex": "example.com",
        "dnssec": {"dnskey_present": True, "ad_flag": True},
    }
    n = handler._check_dnssec(99, 1, "example.com", parsed, fm)
    assert n == 0
    assert fm.added == []


def test_full_clean_posture_no_findings():
    """Healthy domain — strong SPF, strict DMARC, DNSSEC on."""
    handler = DmarcCheckHandler()
    fm = _RecordingFM()
    parsed = {
        "apex": "example.com",
        "spf": {
            "present": True,
            "ends_with_all": "-all",
            "lookup_count": 5,
            "raw": "v=spf1 include:_spf.google.com -all",
        },
        "dmarc": {
            "present": True,
            "policy": "reject",
            "rua": "mailto:dmarc@example.com",
            "raw": "v=DMARC1; p=reject; rua=mailto:dmarc@example.com",
        },
        "dnssec": {"dnskey_present": True, "ad_flag": True},
    }
    handler._check_spf(99, 1, "example.com", parsed, fm)
    handler._check_dmarc(99, 1, "example.com", parsed, fm)
    handler._check_dnssec(99, 1, "example.com", parsed, fm)
    assert fm.added == []
