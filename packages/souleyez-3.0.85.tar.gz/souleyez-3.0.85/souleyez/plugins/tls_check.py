#!/usr/bin/env python3
"""
souleyez.plugins.tls_check - TLS/SSL configuration audit.

Probes a target hostname's TLS configuration for findings that
matter to compliance frameworks (SOC 2, HITRUST, PCI-DSS) and to
attackers:
- Deprecated protocol versions (TLS 1.0 / 1.1) accepted
- Weak signature algorithm on certificate (SHA-1)
- Expired or near-expiry certificate
- Self-signed certificate
- Missing or weak HSTS header

Pure-Python: uses the stdlib ssl module + cryptography library
(already in souleyez deps). No external testssl.sh required —
covers the high-value findings without the extra dependency.
For comprehensive cipher-by-cipher / Heartbleed / ROBOT-class
testing, run testssl.sh manually as a follow-up.

Plugin runs in two modes:
- Manual: operator passes a hostname or URL.
- Auto-chain: tool_chaining fires it when http_fingerprint detects
  HTTPS, scope-gated to engagement-scoped hostnames.
"""

import json
import socket
import ssl
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import urlparse

try:
    import requests
except ImportError:  # pragma: no cover - hard dep
    requests = None  # type: ignore

try:
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes
except ImportError:  # pragma: no cover - hard dep
    x509 = None  # type: ignore
    hashes = None  # type: ignore

from .plugin_base import PluginBase

HELP = {
    "name": "TLS/SSL Configuration Audit",
    "description": (
        "Audits a target hostname's TLS configuration for compliance "
        "and security findings.\n\n"
        "Findings:\n"
        "- TLS 1.0/1.1 accepted     -> high\n"
        "- Cert expired             -> critical\n"
        "- Cert expires < 14 days   -> high\n"
        "- Cert expires < 30 days   -> medium\n"
        "- SHA-1 signature on cert  -> high\n"
        "- Self-signed cert         -> medium\n"
        "- HSTS missing             -> medium\n"
        "- HSTS max-age < 1 year    -> low\n\n"
        "Auto-triggered when http_fingerprint detects HTTPS on a "
        "scoped hostname. Can also be run manually against any "
        "hostname or URL."
    ),
    "usage": "souleyez jobs enqueue tls_check <hostname-or-url>",
    "examples": [
        "souleyez jobs enqueue tls_check api.freshpaint.io",
        "souleyez jobs enqueue tls_check https://app.example.com",
    ],
    "flags": [
        ["--port <int>", "Port to test (default: 443)"],
        ["--timeout <sec>", "Connection timeout (default: 10)"],
    ],
    "presets": [
        {
            "name": "TLS Audit",
            "args": [],
            "desc": "Protocol + cert + HSTS check",
        },
    ],
}


# Deprecated protocol versions worth flagging when accepted by the
# server. TLS 1.2 and 1.3 are the only versions a 2026 deployment
# should accept.
_DEPRECATED_PROTOCOLS: List[Tuple[str, "ssl.TLSVersion", str]] = []


def _build_protocol_list() -> List[Tuple[str, Any, str]]:
    """Build the deprecated-protocol probe list lazily."""
    out = []
    for name, attr, severity in [
        ("TLS 1.0", "TLSv1", "high"),
        ("TLS 1.1", "TLSv1_1", "high"),
    ]:
        version = getattr(ssl.TLSVersion, attr, None)
        if version is not None:
            out.append((name, version, severity))
    return out


def _hostname_from_target(target: str, default_port: int = 443) -> Tuple[Optional[str], int]:
    if not target:
        return None, default_port
    s = target.strip()
    parsed = urlparse(s if "://" in s else f"https://{s}")
    host = parsed.hostname
    port = parsed.port or default_port
    return (host.lower() if host else None), port


def _parse_args(args: List[str]) -> Dict[str, Any]:
    out: Dict[str, Any] = {"port": 443, "timeout": 10}
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--port" and i + 1 < len(args):
            try:
                out["port"] = int(args[i + 1])
            except ValueError:
                pass
            i += 2
        elif a == "--timeout" and i + 1 < len(args):
            try:
                out["timeout"] = max(1, int(args[i + 1]))
            except ValueError:
                pass
            i += 2
        else:
            i += 1
    return out


def _probe_protocol_accepted(
    hostname: str, port: int, version: Any, timeout: int
) -> bool:
    """
    Return True if the server completes a handshake at the given
    TLS protocol version. Best-effort — connection refused / timeout
    / handshake failure all return False.
    """
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    try:
        ctx.minimum_version = version
        ctx.maximum_version = version
    except (ValueError, AttributeError):
        return False
    try:
        with socket.create_connection(
            (hostname, port), timeout=timeout
        ) as sock:
            with ctx.wrap_socket(sock, server_hostname=hostname) as ssock:
                ssock.do_handshake()
                return True
    except Exception:
        return False


def _fetch_certificate(
    hostname: str, port: int, timeout: int
) -> Tuple[Optional[bytes], Optional[Any], Optional[str]]:
    """
    Connect with cert-validation off and pull the leaf cert as DER
    bytes. Returns (der_bytes, x509_obj, error_message). Validation
    intentionally disabled so we can audit even self-signed or
    expired certs without bailing out.
    """
    if x509 is None:
        return None, None, "cryptography library not available"
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    try:
        with socket.create_connection(
            (hostname, port), timeout=timeout
        ) as sock:
            with ctx.wrap_socket(sock, server_hostname=hostname) as ssock:
                der = ssock.getpeercert(binary_form=True)
                cert = x509.load_der_x509_certificate(der)
                return der, cert, None
    except Exception as e:
        return None, None, str(e)


def _fetch_hsts(hostname: str, port: int, timeout: int) -> Tuple[Optional[str], Optional[str]]:
    """
    Return (hsts_header_value, error_message). Performs a HEAD
    request to the root URL and inspects the Strict-Transport-Security
    response header.
    """
    if requests is None:
        return None, "requests library not available"
    url = (
        f"https://{hostname}/"
        if port == 443
        else f"https://{hostname}:{port}/"
    )
    try:
        r = requests.head(
            url,
            timeout=timeout,
            allow_redirects=False,
            verify=False,
            headers={"User-Agent": "souleyez/tls-check"},
        )
        return r.headers.get("Strict-Transport-Security"), None
    except Exception as e:
        return None, str(e)


def _classify_cert(cert: Any) -> Dict[str, Any]:
    """Pull audit-relevant fields off an x509 leaf certificate."""
    info: Dict[str, Any] = {
        "subject": "",
        "issuer": "",
        "self_signed": False,
        "not_after_iso": "",
        "days_until_expiry": None,
        "signature_algorithm": "",
        "signature_is_weak": False,
    }
    try:
        info["subject"] = cert.subject.rfc4514_string()
        info["issuer"] = cert.issuer.rfc4514_string()
        info["self_signed"] = cert.subject == cert.issuer
        info["not_after_iso"] = cert.not_valid_after_utc.isoformat()
        delta = cert.not_valid_after_utc - datetime.now(timezone.utc)
        info["days_until_expiry"] = int(delta.total_seconds() // 86400)
        sig_oid = cert.signature_algorithm_oid
        sig_name = sig_oid._name if hasattr(sig_oid, "_name") else str(sig_oid)
        info["signature_algorithm"] = sig_name
        # SHA-1 is deprecated since 2017
        info["signature_is_weak"] = "sha1" in sig_name.lower() or "md5" in sig_name.lower()
    except Exception as e:
        info["parse_error"] = str(e)
    return info


def _classify_hsts(hsts_header: Optional[str]) -> Dict[str, Any]:
    """Inspect HSTS header string for max-age / includeSubDomains / preload."""
    info: Dict[str, Any] = {
        "present": bool(hsts_header),
        "raw": hsts_header,
        "max_age_seconds": None,
        "include_subdomains": False,
        "preload": False,
    }
    if not hsts_header:
        return info
    parts = [p.strip().lower() for p in hsts_header.split(";")]
    for p in parts:
        if p.startswith("max-age="):
            try:
                info["max_age_seconds"] = int(p.split("=", 1)[1])
            except (ValueError, IndexError):
                pass
        elif p == "includesubdomains":
            info["include_subdomains"] = True
        elif p == "preload":
            info["preload"] = True
    return info


class TlsCheckPlugin(PluginBase):
    name = "TLS Check"
    tool = "tls_check"
    category = "scanning"
    HELP = HELP

    def check_tool_available(self) -> tuple:
        if x509 is None:
            return False, "cryptography library not available"
        if requests is None:
            return False, "requests library not available"
        return True, None

    def build_command(
        self,
        target: str,
        args: List[str] = None,
        label: str = "",
        log_path: str = None,
    ):
        return None  # pure-Python plugin

    def run(
        self,
        target: str,
        args: List[str] = None,
        label: str = "",
        log_path: str = None,
    ) -> int:
        args = args or []
        opts = _parse_args(args)

        result: Dict[str, Any] = {
            "target": target,
            "hostname": None,
            "port": opts["port"],
            "deprecated_protocols": [],
            "certificate": None,
            "hsts": None,
            "error": None,
            "elapsed": 0.0,
        }

        hostname, port = _hostname_from_target(target, opts["port"])
        if not hostname:
            result["error"] = f"Could not parse hostname from target: {target}"
            self._write_log(log_path, result)
            return 0
        result["hostname"] = hostname
        result["port"] = port

        if x509 is None or requests is None:
            result["error"] = "Required libraries not installed (ssl/cryptography/requests)"
            self._write_log(log_path, result)
            return 0

        # Suppress urllib3 InsecureRequestWarning for our HSTS probe;
        # we intentionally disable cert verification because we're
        # auditing the cert itself and want results even for
        # self-signed or expired certs.
        try:
            import urllib3

            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        except Exception:
            pass

        start = time.time()

        # Deprecated protocol probes
        deprecated = _build_protocol_list()
        for proto_name, version, severity in deprecated:
            accepted = _probe_protocol_accepted(
                hostname, port, version, opts["timeout"]
            )
            if accepted:
                result["deprecated_protocols"].append(
                    {
                        "name": proto_name,
                        "accepted": True,
                        "severity": severity,
                    }
                )

        # Certificate inspection
        der, cert, cert_err = _fetch_certificate(
            hostname, port, opts["timeout"]
        )
        if cert is not None:
            result["certificate"] = _classify_cert(cert)
        elif cert_err:
            result["certificate"] = {"error": cert_err}

        # HSTS header
        hsts_value, hsts_err = _fetch_hsts(hostname, port, opts["timeout"])
        if hsts_err and hsts_value is None:
            result["hsts"] = {"error": hsts_err, "present": False}
        else:
            result["hsts"] = _classify_hsts(hsts_value)

        result["elapsed"] = round(time.time() - start, 2)
        self._write_log(log_path, result)
        return 0

    def _write_log(self, log_path: Optional[str], result: Dict[str, Any]) -> None:
        if not log_path:
            return
        lines = [
            "=== Plugin: TLS Check ===",
            f"Target: {result.get('target')}",
            f"Hostname: {result.get('hostname') or '(unparsed)'}",
            f"Port: {result.get('port')}",
        ]
        deprecated = result.get("deprecated_protocols") or []
        if deprecated:
            lines.append("Deprecated protocols accepted:")
            for d in deprecated:
                lines.append(f"  - {d['name']} ({d['severity']})")
        else:
            lines.append("Deprecated protocols accepted: none")
        cert = result.get("certificate")
        if cert and "error" not in cert:
            lines.append("Certificate:")
            lines.append(f"  Subject: {cert.get('subject', '')}")
            lines.append(f"  Issuer: {cert.get('issuer', '')}")
            lines.append(f"  Not after: {cert.get('not_after_iso', '')}")
            lines.append(f"  Days until expiry: {cert.get('days_until_expiry')}")
            lines.append(
                f"  Signature: {cert.get('signature_algorithm', '')} "
                f"(weak={cert.get('signature_is_weak')})"
            )
            lines.append(f"  Self-signed: {cert.get('self_signed')}")
        elif cert:
            lines.append(f"Certificate: ERROR {cert.get('error')}")
        hsts = result.get("hsts")
        if hsts and "error" not in hsts:
            lines.append(
                f"HSTS: present={hsts.get('present')} "
                f"max-age={hsts.get('max_age_seconds')} "
                f"includeSubDomains={hsts.get('include_subdomains')} "
                f"preload={hsts.get('preload')}"
            )
        elif hsts:
            lines.append(f"HSTS: ERROR {hsts.get('error')}")
        if result.get("error"):
            lines.append(f"ERROR: {result['error']}")
        lines.append(f"Elapsed: {result.get('elapsed')}s")
        lines.append("")
        lines.append("=== JSON_RESULT ===")
        lines.append(json.dumps(result, indent=2, default=str))
        lines.append("=== END_JSON_RESULT ===")
        lines.append("")
        try:
            with open(log_path, "a", encoding="utf-8", errors="replace") as fh:
                fh.write("\n".join(lines))
        except Exception:
            pass


plugin = TlsCheckPlugin()
