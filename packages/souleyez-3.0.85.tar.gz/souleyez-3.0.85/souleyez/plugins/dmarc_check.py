#!/usr/bin/env python3
"""
souleyez.plugins.dmarc_check - email-security DNS audit.

Audits an apex domain's email-security posture by querying the
relevant DNS records:
- SPF (TXT record on the apex)
- DMARC (TXT record on _dmarc.<apex>)
- DKIM (TXT records on a list of common selectors)
- DNSSEC (DNSKEY presence + AD bit on resolver responses)

Pure-Python via dnspython. Mirrors the tls_check / s3_check /
origin_check pure-Python plugin pattern. No external `dig` or
`checkdmarc` binary required.

Plugin runs in two modes:
- Manual: operator passes a domain (apex preferred — `freshpaint.io`,
  not `app.freshpaint.io` — though the plugin extracts the registrable
  domain from a hostname automatically).
- Auto-chain: tool_chaining fires it once per unique apex domain
  observed across http_fingerprint outputs (so a multi-host scan only
  audits the apex once, not per-subdomain).
"""

import json
import re
import time
from typing import Any, Dict, List, Optional, Tuple

try:
    import dns.resolver
    import dns.flags
    import dns.exception
except ImportError:  # pragma: no cover - dnspython is a hard dep
    dns = None  # type: ignore

from .plugin_base import PluginBase

HELP = {
    "name": "DMARC / Email Security DNS Audit",
    "description": (
        "Audits apex domain DNS records for email-security posture: "
        "SPF, DMARC, DKIM (common selectors), DNSSEC.\n\n"
        "Findings:\n"
        "- SPF missing                     -> medium\n"
        "- SPF ends with +all (open)       -> high\n"
        "- SPF >10 lookups (RFC 7208)      -> low\n"
        "- DMARC missing                   -> medium\n"
        "- DMARC p=none (monitor only)     -> low\n"
        "- DMARC missing rua= reporting    -> low\n"
        "- DKIM record on common selectors -> info (presence only)\n"
        "- DNSSEC not enabled              -> low\n\n"
        "Auto-triggered once per unique apex domain. Can also be run "
        "manually."
    ),
    "usage": "souleyez jobs enqueue dmarc_check <domain>",
    "examples": [
        "souleyez jobs enqueue dmarc_check freshpaint.io",
        "souleyez jobs enqueue dmarc_check app.example.com",
    ],
    "flags": [
        ["--timeout <sec>", "DNS query timeout (default: 5)"],
        ["--selectors <csv>", "DKIM selectors to probe (default: common)"],
    ],
    "presets": [
        {
            "name": "DMARC Audit",
            "args": [],
            "desc": "SPF + DMARC + DKIM + DNSSEC",
        },
    ],
}


# Common DKIM selectors used by major mail providers and CRMs.
# Probing each is a single TXT lookup so the cost is bounded.
_DEFAULT_DKIM_SELECTORS = [
    "default",
    "google",
    "selector1",
    "selector2",
    "k1",
    "k2",
    "mail",
    "dkim",
    "smtp",
    "mandrill",
    "mailgun",
    "sendgrid",
    "amazonses",
    "zendesk1",
    "zendesk2",
]

# Public-suffix list is overkill for our purposes; this regex covers
# the apex extraction we need for any common hostname we'll see.
# `app.freshpaint.io` -> `freshpaint.io`. For multi-part TLDs (.co.uk
# etc.) we'd need a real PSL lookup, but those are rare in this fleet.
_APEX_RE = re.compile(r"([a-z0-9-]+\.[a-z]{2,})$", re.IGNORECASE)


def _extract_apex(target: str) -> Optional[str]:
    if not target:
        return None
    s = target.strip().lower()
    # Strip scheme + path if present
    if "://" in s:
        s = s.split("://", 1)[1]
    s = s.split("/", 1)[0]
    s = s.split(":", 1)[0]
    m = _APEX_RE.search(s)
    return m.group(1) if m else None


def _parse_args(args: List[str]) -> Dict[str, Any]:
    out: Dict[str, Any] = {
        "timeout": 5,
        "selectors": list(_DEFAULT_DKIM_SELECTORS),
    }
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--timeout" and i + 1 < len(args):
            try:
                out["timeout"] = max(1, int(args[i + 1]))
            except ValueError:
                pass
            i += 2
        elif a == "--selectors" and i + 1 < len(args):
            sels = [s.strip() for s in args[i + 1].split(",") if s.strip()]
            if sels:
                out["selectors"] = sels
            i += 2
        else:
            i += 1
    return out


def _make_resolver(timeout: int):
    if dns is None:
        return None
    r = dns.resolver.Resolver()
    r.timeout = timeout
    r.lifetime = timeout * 2
    return r


def _query_txt(resolver, name: str) -> List[str]:
    """Return list of TXT record values for `name`, empty on no record."""
    try:
        ans = resolver.resolve(name, "TXT", raise_on_no_answer=False)
    except dns.exception.DNSException:
        return []
    out = []
    if ans.rrset is None:
        return []
    for rdata in ans:
        try:
            # TXT records are byte-string sequences; join into one string
            joined = b"".join(rdata.strings).decode("utf-8", errors="replace")
            out.append(joined)
        except Exception:
            try:
                out.append(rdata.to_text())
            except Exception:
                continue
    return out


def _check_spf(resolver, apex: str) -> Dict[str, Any]:
    """Pull SPF record from apex TXT and classify."""
    info: Dict[str, Any] = {
        "present": False,
        "raw": None,
        "ends_with_all": None,
        "lookup_count": 0,
        "warnings": [],
    }
    txts = _query_txt(resolver, apex)
    spf_records = [t for t in txts if t.lower().startswith("v=spf1")]
    if not spf_records:
        return info
    if len(spf_records) > 1:
        info["warnings"].append("Multiple SPF records found (RFC 7208 violation)")
    raw = spf_records[0]
    info["present"] = True
    info["raw"] = raw

    # Classify final qualifier on `all`
    if re.search(r"\+all\b", raw, re.IGNORECASE):
        info["ends_with_all"] = "+all"
    elif re.search(r"~all\b", raw, re.IGNORECASE):
        info["ends_with_all"] = "~all"
    elif re.search(r"-all\b", raw, re.IGNORECASE):
        info["ends_with_all"] = "-all"
    elif re.search(r"\?all\b", raw, re.IGNORECASE):
        info["ends_with_all"] = "?all"

    # RFC 7208 §4.6.4 — SPF lookup limit is 10. Count include/redirect/a/mx/exists.
    lookup_terms = re.findall(
        r"\b(?:include|redirect|a|mx|exists|ptr)(?::\S+)?",
        raw,
        re.IGNORECASE,
    )
    info["lookup_count"] = len(lookup_terms)
    return info


def _check_dmarc(resolver, apex: str) -> Dict[str, Any]:
    info: Dict[str, Any] = {
        "present": False,
        "raw": None,
        "policy": None,
        "subdomain_policy": None,
        "rua": None,
        "ruf": None,
        "pct": None,
        "warnings": [],
    }
    txts = _query_txt(resolver, f"_dmarc.{apex}")
    dmarc_records = [t for t in txts if t.lower().startswith("v=dmarc1")]
    if not dmarc_records:
        return info
    if len(dmarc_records) > 1:
        info["warnings"].append("Multiple DMARC records found (invalid)")
    raw = dmarc_records[0]
    info["present"] = True
    info["raw"] = raw

    for tag in raw.split(";"):
        tag = tag.strip()
        if "=" not in tag:
            continue
        k, v = tag.split("=", 1)
        k = k.strip().lower()
        v = v.strip()
        if k == "p":
            info["policy"] = v.lower()
        elif k == "sp":
            info["subdomain_policy"] = v.lower()
        elif k == "rua":
            info["rua"] = v
        elif k == "ruf":
            info["ruf"] = v
        elif k == "pct":
            try:
                info["pct"] = int(v)
            except ValueError:
                info["pct"] = v
    return info


def _check_dkim(resolver, apex: str, selectors: List[str]) -> Dict[str, Any]:
    info: Dict[str, Any] = {"selectors_found": [], "selectors_probed": list(selectors)}
    for sel in selectors:
        txts = _query_txt(resolver, f"{sel}._domainkey.{apex}")
        for t in txts:
            if t.lower().startswith("v=dkim1") or "p=" in t.lower():
                info["selectors_found"].append({"selector": sel, "raw": t})
                break
    return info


def _check_dnssec(resolver, apex: str) -> Dict[str, Any]:
    """
    Detect DNSSEC by querying DNSKEY at the apex. Presence of DNSKEY
    plus AD flag on a SOA query indicates the resolver validated the
    signature. False negatives possible if the configured resolver
    doesn't validate; we report what we observe.
    """
    info: Dict[str, Any] = {"dnskey_present": False, "ad_flag": False}
    try:
        ans = resolver.resolve(apex, "DNSKEY", raise_on_no_answer=False)
        info["dnskey_present"] = ans.rrset is not None
    except dns.exception.DNSException:
        pass
    try:
        ans = resolver.resolve(apex, "SOA", raise_on_no_answer=False)
        flags = getattr(ans.response, "flags", 0)
        info["ad_flag"] = bool(flags & dns.flags.AD)
    except dns.exception.DNSException:
        pass
    return info


class DmarcCheckPlugin(PluginBase):
    name = "DMARC Check"
    tool = "dmarc_check"
    category = "reconnaissance"
    HELP = HELP

    def check_tool_available(self) -> tuple:
        if dns is None:
            return False, "dnspython library not available"
        return True, None

    def build_command(
        self,
        target: str,
        args: List[str] = None,
        label: str = "",
        log_path: str = None,
    ):
        return None  # pure-Python plugin

    def run(
        self,
        target: str,
        args: List[str] = None,
        label: str = "",
        log_path: str = None,
    ) -> int:
        args = args or []
        opts = _parse_args(args)

        result: Dict[str, Any] = {
            "target": target,
            "apex": None,
            "spf": None,
            "dmarc": None,
            "dkim": None,
            "dnssec": None,
            "error": None,
            "elapsed": 0.0,
        }

        apex = _extract_apex(target)
        if not apex:
            result["error"] = f"Could not extract apex domain from: {target}"
            self._write_log(log_path, result)
            return 0
        result["apex"] = apex

        if dns is None:
            result["error"] = "dnspython library not installed"
            self._write_log(log_path, result)
            return 0

        resolver = _make_resolver(opts["timeout"])
        if resolver is None:
            result["error"] = "Could not initialize DNS resolver"
            self._write_log(log_path, result)
            return 0

        start = time.time()
        result["spf"] = _check_spf(resolver, apex)
        result["dmarc"] = _check_dmarc(resolver, apex)
        result["dkim"] = _check_dkim(resolver, apex, opts["selectors"])
        result["dnssec"] = _check_dnssec(resolver, apex)
        result["elapsed"] = round(time.time() - start, 2)

        self._write_log(log_path, result)
        return 0

    def _write_log(self, log_path: Optional[str], result: Dict[str, Any]) -> None:
        if not log_path:
            return
        lines = [
            "=== Plugin: DMARC Check ===",
            f"Target: {result.get('target')}",
            f"Apex: {result.get('apex') or '(unparsed)'}",
        ]
        spf = result.get("spf") or {}
        if spf.get("present"):
            lines.append(
                f"SPF: present | qualifier={spf.get('ends_with_all')} | "
                f"lookups={spf.get('lookup_count')}"
            )
            if spf.get("raw"):
                lines.append(f"  raw: {spf['raw']}")
        else:
            lines.append("SPF: MISSING")
        dmarc = result.get("dmarc") or {}
        if dmarc.get("present"):
            lines.append(
                f"DMARC: present | p={dmarc.get('policy')} | "
                f"sp={dmarc.get('subdomain_policy')} | "
                f"pct={dmarc.get('pct')} | "
                f"rua={'yes' if dmarc.get('rua') else 'no'}"
            )
            if dmarc.get("raw"):
                lines.append(f"  raw: {dmarc['raw']}")
        else:
            lines.append("DMARC: MISSING")
        dkim = result.get("dkim") or {}
        found = dkim.get("selectors_found") or []
        lines.append(
            f"DKIM: {len(found)} selector(s) found "
            f"(probed {len(dkim.get('selectors_probed') or [])})"
        )
        for entry in found:
            lines.append(f"  - {entry.get('selector')}")
        dnssec = result.get("dnssec") or {}
        lines.append(
            f"DNSSEC: dnskey_present={dnssec.get('dnskey_present')} "
            f"ad_flag={dnssec.get('ad_flag')}"
        )
        if result.get("error"):
            lines.append(f"ERROR: {result['error']}")
        lines.append(f"Elapsed: {result.get('elapsed')}s")
        lines.append("")
        lines.append("=== JSON_RESULT ===")
        lines.append(json.dumps(result, indent=2, default=str))
        lines.append("=== END_JSON_RESULT ===")
        lines.append("")
        try:
            with open(log_path, "a", encoding="utf-8", errors="replace") as fh:
                fh.write("\n".join(lines))
        except Exception:
            pass


plugin = DmarcCheckPlugin()
