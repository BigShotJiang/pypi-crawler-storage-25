import os
import pandas as pd
import clr
from pathlib import Path

DEFAULT_ADOMD_PATH = (
    r"c:\Program Files\Microsoft Power BI Desktop\bin\Microsoft.PowerBI.AdomdClient.dll"
)


class AdomdClientNotFoundError(FileNotFoundError):
    """Raised when Microsoft.PowerBI.AdomdClient.dll cannot be located."""


def _find_adomd_dll(path: Path, verbose:bool) -> Path:
    """Resolve the path to the AdomdClient DLL, searching C:\\ if needed."""
    if path.is_file():
        return path

    if verbose:
        print("Microsoft.PowerBI.AdomdClient.dll not at expected path, searching C:\\...")
    for root, _, files in os.walk("c:\\"):
        for name in files:
            if name == "Microsoft.PowerBI.AdomdClient.dll":
                found = Path(os.path.abspath(os.path.join(root, name)))
                if "Power BI" in str(found):
                    if verbose:
                        print(
                            f"AdomdClient found. Pass this path to avoid future searches:\n  {found}"
                        )
                    return found

    raise AdomdClientNotFoundError(
        "Microsoft.PowerBI.AdomdClient.dll not found. Please install Power BI Desktop."
    )


def _load_adomd(dll_path: Path) -> tuple:
    """Load CLR references and return AdomdConnection and AdomdDataAdapter classes."""
    clr.AddReference(str(dll_path))
    clr.AddReference("System.Data")
    clr.AddReference("System.Net")

    from System.Net import ServicePointManager, SecurityProtocolType

    ServicePointManager.SecurityProtocol = (
        SecurityProtocolType.Ssl3
        | SecurityProtocolType.Tls
        | SecurityProtocolType.Tls11
        | SecurityProtocolType.Tls12
    )

    from Microsoft.AnalysisServices.AdomdClient import AdomdConnection, AdomdDataAdapter
    import System.Data
    return AdomdConnection, AdomdDataAdapter, System.Data.DataTable


def _is_mdx(query: str) -> bool:
    return "select" in query.lower()


def _parse_column_names(
    raw_names: list[str], query: str, space_replacer: str
) -> list[str]:
    """Derive clean column names from raw ADOMD field names."""
    measures_count = sum(1 for n in raw_names if "[Measures]" in n)
    dim_raw = raw_names[: len(raw_names) - measures_count]
    measure_raw = raw_names[len(raw_names) - measures_count :]

    if _is_mdx(query):
        dimensions = [
            n[n.find("].[", n.find("].[") + 1) + 3:]
            .replace("].[MEMBER_CAPTION]", "")
            .replace(" ", space_replacer)
            for n in dim_raw
        ]
        measures = [
            n.replace("[Measures].[", "").replace("]", "").replace(" ", space_replacer)
            for n in measure_raw
        ]
    else:
        # DAX query — all columns treated as dimensions
        dimensions = [
            n.split("[")[-1].rstrip("]").replace(" ", space_replacer)
            for n in raw_names
        ]
        measures = []

    return dimensions + measures


def mdx_retriever(
    query: str,
    olap_connection_string: str,
    space_replacer: str = "_",
    adomd_dll: str = DEFAULT_ADOMD_PATH,
    verbose:bool = False
) -> pd.DataFrame:
    """
    Execute an MDX or DAX query against an OLAP cube and return results as a DataFrame.

    Args:
        query:                  MDX or DAX query string.
        olap_connection_string: OLAP connection string, e.g.
                                    "Data Source=https://biserver.domain.com/version/;
                                     Catalog=version;"
        space_replacer:         Character used to replace spaces in column names.
                                Defaults to '_'. Use ' ' to preserve original names.
        adomd_dll:              Path to Microsoft.PowerBI.AdomdClient.dll.
                                Defaults to the standard Power BI Desktop install path.

    Returns:
        A pandas DataFrame containing the query results, or an empty DataFrame on error.
    """
    if not query.strip():
        raise ValueError("No query provided. Please supply a valid MDX or DAX query.")

    try:
        dll_path = _find_adomd_dll(Path(adomd_dll), verbose=verbose)
    except AdomdClientNotFoundError as e:
        print(e)
        return pd.DataFrame()

    AdomdConnection, AdomdDataAdapter, DataTable = _load_adomd(dll_path)

    query_type = "MDX" if _is_mdx(query) else "DAX"
    if verbose:
        print(f"{query_type} query detected.")
        print("Fetching data from OLAP cube, this may take a while...")

    conn = AdomdConnection(olap_connection_string)
    conn.Open()
    try:
        cmd = conn.CreateCommand()
        cmd.CommandText = query

        adapter = AdomdDataAdapter(cmd)
        table = DataTable()
        adapter.Fill(table)

        raw_names = [table.Columns[i].ColumnName for i in range(table.Columns.Count)]
        column_names = _parse_column_names(raw_names, query, space_replacer)

        # ItemArray fetches an entire row as a .NET object[] in one boundary
        # crossing, rather than one crossing per cell — significantly faster
        # for wide or large result sets.
        rows = [list(row.ItemArray) for row in table.Rows]
    finally:
        conn.Close()

    return pd.DataFrame(rows, columns=column_names)


if __name__ == "__main__":
    print(__name__)