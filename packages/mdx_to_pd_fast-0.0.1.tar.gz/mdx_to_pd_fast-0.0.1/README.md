# mdx_to_pd_fast

Requirements
- pandas
- pythonnet

