"""Install OpenRunner slash commands for AI coding tools.

Supports:
- Claude Code: ~/.claude/commands/openrunner/
- Codex (OpenAI): ~/.codex/commands/ or AGENTS.md instructions
- Qwen Code: ~/.qwen-code/commands/
- OpenCode: ~/.opencode/commands/

Usage:
    openrunner install          # auto-detect and install all
    openrunner install claude   # Claude Code only
    openrunner install codex    # Codex only
    openrunner install qwen     # Qwen Code only
    openrunner install opencode # OpenCode only
"""

from __future__ import annotations

import os
from pathlib import Path

# ---------------------------------------------------------------------------
# Command templates
# ---------------------------------------------------------------------------

SYNC_SESSION_CMD = """---
name: {prefix}sync-session
description: Sync current coding session to OpenRunner as a research log
argument-hint: "[org/project]"
allowed-tools:
  - Bash
  - Read
  - AskUserQuestion
---

Sync the current Claude Code session to OpenRunner.

## Process

### Step 1: Check configuration

Run this to check if session config exists:

```bash
python3 -c "
import json
from pathlib import Path
config_file = Path.home() / '.openrunner' / 'session_config.json'
if config_file.exists():
    config = json.loads(config_file.read_text())
    if config.get('api_key') and config.get('project'):
        print('CONFIGURED')
        print(f'project={{config[\"project\"]}}')
    else:
        print('INCOMPLETE')
else:
    print('NOT_CONFIGURED')
"
```

### Step 2a: If NOT_CONFIGURED or INCOMPLETE

Ask the user for their OpenRunner API key and base URL. Then list projects and ask them to pick one. Save to ~/.openrunner/session_config.json.

### Step 2b: If CONFIGURED (or after setup)

Sync the current session. Use $ARGUMENTS as project override if provided:

```bash
python3 -c "
import sys, os
from pathlib import Path
for p in ([os.path.join(d, 'site-packages') for d in __import__('glob').glob(os.path.expanduser('~/.local/lib/python3.*/')) + __import__('glob').glob(os.path.expanduser('~/Library/Python/3.*/lib/python/'))]):
    if os.path.isdir(p): sys.path.insert(0, p)
from openrunner.session import parse_claude_session, sync_session_to_openrunner, get_session_config

cwd = Path.cwd()
cwd_key = '-' + str(cwd).replace('/', '-').lstrip('-')
project_dir = Path.home() / '.claude' / 'projects' / cwd_key
if not project_dir.exists():
    for d in (Path.home() / '.claude' / 'projects').iterdir():
        if d.is_dir() and cwd_key in d.name:
            project_dir = d
            break

sessions = sorted(
    [f for f in project_dir.rglob('*.jsonl') if f.stat().st_size > 100 and '.meta.' not in f.name],
    key=lambda f: f.stat().st_mtime, reverse=True,
) if project_dir.exists() else []

if not sessions:
    print('No session files found.')
    sys.exit(1)

latest = sessions[0]
print(f'Syncing: {{latest.name}} ({{latest.stat().st_size // 1024}} KB)')
parsed = parse_claude_session(latest)
print(f'  Messages: {{parsed[\"message_count\"]}} ({{parsed[\"user_message_count\"]}} user)')
print(f'  Tokens: {{parsed.get(\"total_tokens\", 0):,}}')

project_override = '$ARGUMENTS'.strip() or None
run_id = sync_session_to_openrunner(parsed, project=project_override)
if run_id:
    config = get_session_config()
    base = config.get('base_url', '')
    project = project_override or config.get('project', '')
    print(f'Synced -> {{base}}/{{project}}/ai-sessions/{{run_id}}')
else:
    print('Sync failed. Run: openrunner session setup')
"
```

### Step 3: Report the run URL and stats to the user.
"""

LOG_NOTE_CMD = """---
name: {prefix}log-note
description: Log a research note to OpenRunner
---

Log the user's note text to OpenRunner as a quick research entry. Run:

```bash
python3 -c "
import os, sys, json
from pathlib import Path

for p in ([os.path.join(d, 'site-packages') for d in __import__('glob').glob(os.path.expanduser('~/.local/lib/python3.*/')) + __import__('glob').glob(os.path.expanduser('~/Library/Python/3.*/lib/python/'))]):
    if os.path.isdir(p):
        sys.path.insert(0, p)

from openrunner.api_client import APIClient

settings_file = Path.home() / '.openrunner' / 'settings.json'
settings = json.loads(settings_file.read_text()) if settings_file.exists() else {{}}
api_key = os.environ.get('OPENRUNNER_API_KEY') or settings.get('api_key')
base_url = os.environ.get('OPENRUNNER_BASE_URL') or settings.get('base_url', config.get('base_url', ''))
project = os.environ.get('OPENRUNNER_SESSION_PROJECT', 'research-sessions')

note = '''$ARGUMENTS'''

client = APIClient(base_url=base_url, api_key=api_key)
result = client.create_run({{
    'project': project,
    'display_name': f'note: {{note[:50]}}',
    'notes': note,
    'tags': ['note', 'quick'],
    'state': 'finished',
}})
if result:
    print(f'Note logged: run {{result[\"id\"]}}')
else:
    print('Failed. Run: openrunner login')
client.close()
"
```
"""

# ---------------------------------------------------------------------------
# Installers per tool
# ---------------------------------------------------------------------------


SETUP_CMD = """---
name: {prefix}setup
description: Configure OpenRunner API key and project for this workspace
allowed-tools:
  - Bash
  - AskUserQuestion
---

Interactive setup for OpenRunner session sync in this workspace.

## Process

1. Check if global config exists (`~/.openrunner/session_config.json`). If no API key, ask user for it. Save globally.

2. If no local project config, list available projects:

```bash
python3 -c "
import sys, os, json
from pathlib import Path
for p in ([os.path.join(d, 'site-packages') for d in __import__('glob').glob(os.path.expanduser('~/.local/lib/python3.*/')) + __import__('glob').glob(os.path.expanduser('~/Library/Python/3.*/lib/python/'))]):
    if os.path.isdir(p): sys.path.insert(0, p)
from openrunner.api_client import APIClient
config = json.loads((Path.home() / '.openrunner' / 'session_config.json').read_text())
client = APIClient(base_url=config['base_url'], api_key=config['api_key'])
for i, p in enumerate(client.list_projects(), 1):
    print(f'  [{{i}}] {{p.get(\"org_name\",\"?\") }}/{{p.get(\"name\",\"?\")}}')
client.close()
"
```

3. Ask user to pick a project number. Save to `.openrunner/session.json` in CWD.
"""

LIST_SESSIONS_CMD = """---
name: {prefix}list-sessions
description: List AI sessions logged to the current project in OpenRunner
allowed-tools:
  - Bash
---

List recent AI sessions. Run:

```bash
python3 -c "
import sys, os, json
from pathlib import Path
for p in ([os.path.join(d, 'site-packages') for d in __import__('glob').glob(os.path.expanduser('~/.local/lib/python3.*/')) + __import__('glob').glob(os.path.expanduser('~/Library/Python/3.*/lib/python/'))]):
    if os.path.isdir(p): sys.path.insert(0, p)
from openrunner.session import get_session_config
from openrunner.api_client import APIClient
config = get_session_config()
if not config.get('api_key'): print('Not configured. Run /openrunner:setup'); sys.exit(1)
client = APIClient(base_url=config['base_url'], api_key=config['api_key'])
project_name = config.get('project', '')
project_id = None
for p in client.list_projects():
    if f'{{p.get(\"org_name\",\"\")}}/{{p.get(\"name\",\"\")}}' == project_name or p.get('name') == project_name:
        project_id = p.get('id'); break
if not project_id: print(f'Project not found'); sys.exit(1)
resp = client._request('get', f'/projects/{{project_id}}/ai-sessions?limit=20')
data = resp.json()
for s in data.get('sessions', []):
    src = s.get('source','?')[:12]
    title = (s.get('title') or 'untitled')[:40]
    msgs = s.get('message_count',0)
    tokens = s.get('total_tokens',0)
    tok = f'{{tokens//1000}}K' if tokens>1000 else str(tokens)
    print(f'  {{src:<12}} {{title:<40}} {{msgs:>4}} msgs  {{tok:>6}} tok')
client.close()
"
```

Show results to user.
"""

CHAT_CMD = """---
name: {prefix}chat
description: Chat with the most recent AI session logged to OpenRunner
argument-hint: "<question>"
allowed-tools:
  - Bash
---

Ask about the latest AI session:

```bash
python3 -c "
import sys, os, json
from pathlib import Path
for p in ([os.path.join(d, 'site-packages') for d in __import__('glob').glob(os.path.expanduser('~/.local/lib/python3.*/')) + __import__('glob').glob(os.path.expanduser('~/Library/Python/3.*/lib/python/'))]):
    if os.path.isdir(p): sys.path.insert(0, p)
from openrunner.session import get_session_config
from openrunner.api_client import APIClient
config = get_session_config()
if not config.get('api_key'): print('Not configured.'); sys.exit(1)
client = APIClient(base_url=config['base_url'], api_key=config['api_key'])
project_name = config.get('project', '')
project_id = None
for p in client.list_projects():
    if f'{{p.get(\"org_name\",\"\")}}/{{p.get(\"name\",\"\")}}' == project_name or p.get('name') == project_name:
        project_id = p.get('id'); break
if not project_id: print('Project not found'); sys.exit(1)
resp = client._request('get', f'/projects/{{project_id}}/ai-sessions?limit=1')
sessions = resp.json().get('sessions', [])
if not sessions: print('No sessions. Sync first.'); sys.exit(1)
session_id = sessions[0]['id']
question = '''$ARGUMENTS'''
if not question.strip(): print(f'Latest: {{sessions[0].get(\"title\")}}'); sys.exit(0)
resp = client._request('post', f'/projects/{{project_id}}/ai-sessions/{{session_id}}/chat', json={{'message': question, 'history': []}})
if resp.status_code == 200: print(resp.json().get('message',''))
else: print(f'Error: {{resp.status_code}}')
client.close()
"
```

Show the response to the user.
"""


LOGIN_CMD = """---
name: {prefix}login
description: Authenticate OpenRunner CLI via browser
allowed-tools:
  - Bash
  - AskUserQuestion
---
<objective>
Authenticate the user with their OpenRunner instance. Get their server URL and API key configured in ~/.openrunner/settings.json.
</objective>

<process>
1. Check current auth state by reading ~/.openrunner/settings.json
2. If no base_url configured, ask the user: "What is your OpenRunner server URL? (e.g. https://openrun.example.com)"
3. Once you have the base_url, initiate the browser login flow by running the script below (replace BASE_URL with actual URL)
4. If browser flow succeeds (prints SUCCESS), confirm to user they're logged in
5. If it times out or fails, ask user to paste their API key manually (from their OpenRunner Settings page)
6. Save the final config to ~/.openrunner/settings.json

IMPORTANT: You MUST ask the user for their server URL before proceeding. Do NOT assume or hardcode any URL.
</process>

Check auth state:
```bash
python3 -c "
import json; from pathlib import Path
f = Path.home() / '.openrunner' / 'settings.json'
if f.exists():
    s = json.loads(f.read_text())
    print(f'base_url={{s.get(\"base_url\",\"\")}} api_key={{\"set\" if s.get(\"api_key\") else \"missing\"}}')
else:
    print('base_url= api_key=missing')
"
```

After getting BASE_URL from user, run browser login:
```bash
python3 -c "
import sys, os, json, time; from pathlib import Path
for p in ([os.path.join(d, 'site-packages') for d in __import__('glob').glob(os.path.expanduser('~/.local/lib/python3.*/')) + __import__('glob').glob(os.path.expanduser('~/Library/Python/3.*/lib/python/'))]):
    if os.path.isdir(p): sys.path.insert(0, p)
import httpx
base_url = 'BASE_URL'
resp = httpx.post(f'{{base_url}}/api/v1/auth/cli/initiate', json={{'expiry_days': 90}}, timeout=10)
data = resp.json(); code = data['code']; auth_url = data['url']
print(f'APPROVE_URL={{auth_url}}')
import webbrowser; webbrowser.open(auth_url)
for i in range(60):
    time.sleep(2)
    pd = httpx.get(f'{{base_url}}/api/v1/auth/cli/poll/{{code}}', timeout=10).json()
    if pd['status'] == 'approved':
        sf = Path.home() / '.openrunner' / 'settings.json'; sf.parent.mkdir(parents=True, exist_ok=True)
        sf.write_text(json.dumps({{'api_key': pd['api_key'], 'base_url': base_url}}, indent=2))
        print(f'SUCCESS email={{pd.get(\"email\",\"\")}}'); sys.exit(0)
    elif pd['status'] == 'expired': print('EXPIRED'); sys.exit(1)
print('TIMEOUT'); sys.exit(1)
"
```

If browser flow fails, save manual key:
```bash
python3 -c "
import json; from pathlib import Path
sf = Path.home() / '.openrunner' / 'settings.json'; sf.parent.mkdir(parents=True, exist_ok=True)
sf.write_text(json.dumps({{'api_key': 'USER_API_KEY', 'base_url': 'BASE_URL'}}, indent=2))
print('Saved.')
"
```
"""

CODE_UPLOAD_CMD = """---
name: {prefix}code-upload
description: Upload current directory code to OpenRunner as artifact (redacted)
allowed-tools:
  - Bash
  - AskUserQuestion
---

Upload redacted source code from CWD to OpenRunner as artifact:

```bash
python3 -c "
import sys, os
from pathlib import Path
for p in ([os.path.join(d, 'site-packages') for d in __import__('glob').glob(os.path.expanduser('~/.local/lib/python3.*/')) + __import__('glob').glob(os.path.expanduser('~/Library/Python/3.*/lib/python/'))]):
    if os.path.isdir(p): sys.path.insert(0, p)

from openrunner.session import get_session_config
from openrunner.api_client import APIClient
from openrunner.redact import redact_text
import tempfile, shutil

config = get_session_config()
if not config.get('api_key'):
    print('Not configured. Run /openrunner:setup first.')
    sys.exit(1)

project_name = config.get('project', '')
CODE_EXTENSIONS = ('.py', '.yaml', '.yml', '.toml', '.cfg', '.sh', '.json', 'Dockerfile', 'Makefile', 'requirements.txt', 'pyproject.toml')
SKIP_DIRS = {{'.git', '__pycache__', 'node_modules', 'venv', '.venv', 'dist', 'build', '.openrunner'}}

cwd = Path.cwd()
files_collected = []
for fpath in sorted(cwd.rglob('*')):
    if not fpath.is_file(): continue
    rel = str(fpath.relative_to(cwd))
    parts = Path(rel).parts
    if any(p.startswith('.') or p in SKIP_DIRS for p in parts): continue
    if not any(rel.endswith(ext) or rel == ext for ext in CODE_EXTENSIONS): continue
    if fpath.stat().st_size > 1_000_000: continue
    files_collected.append((rel, fpath))

print(f'Found {{len(files_collected)}} source files')
if not files_collected:
    print('No source files found.')
    sys.exit(1)

tmp_dir = Path(tempfile.mkdtemp(prefix='or-code-'))
redacted_count = 0
for rel, fpath in files_collected:
    content = fpath.read_text(errors='replace')
    result = redact_text(content, mode='regex')
    redacted_count += result.redacted_count
    dest = tmp_dir / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(result.text)

if redacted_count > 0:
    print(f'Redacted {{redacted_count}} secrets')

import openrunner
os.environ['OPENRUNNER_API_KEY'] = config['api_key']
os.environ['OPENRUNNER_BASE_URL'] = config.get('base_url', '')
run = openrunner.init(project=project_name, name='code-upload', save_code=False)
artifact = openrunner.Artifact('source-code', type='code')
artifact.add_dir(str(tmp_dir))
result = run.log_artifact(artifact)
run.finish()
shutil.rmtree(tmp_dir, ignore_errors=True)

if result:
    print(f'Uploaded source-code artifact (v{{result.get(\"version\", \"?\")}}) — {{len(files_collected)}} files, {{redacted_count}} secrets redacted')
else:
    print('Upload failed.')
"
```

Report result to user.
"""


UPDATE_CMD = """---
name: {prefix}update
description: Update OpenRunner SDK and reinstall all commands
allowed-tools:
  - Bash
---

Upgrade openrunner-sdk and reinstall slash commands:

```bash
pip install --upgrade openrunner-sdk 2>&1 | tail -3 && python3 -c "
import sys, os
from pathlib import Path
for p in ([os.path.join(d, 'site-packages') for d in __import__('glob').glob(os.path.expanduser('~/.local/lib/python3.*/')) + __import__('glob').glob(os.path.expanduser('~/Library/Python/3.*/lib/python/'))]):
    if os.path.isdir(p): sys.path.insert(0, p)
marker = Path.home() / '.openrunner' / '.commands_version'
if marker.exists(): marker.unlink()
import importlib, openrunner, openrunner.install_commands
importlib.reload(openrunner.install_commands)
importlib.reload(openrunner)
print(f'OpenRunner SDK {{openrunner.__version__}}')
cmd_dir = Path.home() / '.claude' / 'commands' / 'openrunner'
if cmd_dir.exists():
    print('Commands installed:')
    for f in sorted(cmd_dir.glob('*.md')):
        print(f'  /openrunner:{{f.stem}}')
print()
print('MCP Plugin: enable in Claude Code with /plugins -> openrunner')
print('(restart session after enabling for tool access)')
"
```

Report version and installed commands to user. Remind them to enable the MCP plugin.
"""


PLOT_SESSION_RUN_CMD = """---
name: {prefix}plot-session-run
description: Plot training metrics from runs in current project (ASCII chart + table, PNG on desktop)
argument-hint: "[run_id] [--metric key] [--all] [--watch [secs]]"
allowed-tools:
  - Bash
  - Read
---

Plot training run metrics from the current OpenRunner project as ASCII sparklines and summary table.
If on a desktop with display, also generates a PNG chart.

Use `--watch` (or `-w`) for live refresh every 2 minutes (override: `--watch 30` for 30s).
Auto-stops when no runs are in progress.

## Process

### Step 1: Fetch runs and metrics

```bash
python3 -c "
import sys, os, json
from pathlib import Path
for p in ([os.path.join(d, 'site-packages') for d in __import__('glob').glob(os.path.expanduser('~/.local/lib/python3.*/')) + __import__('glob').glob(os.path.expanduser('~/Library/Python/3.*/lib/python/'))]):
    if os.path.isdir(p): sys.path.insert(0, p)

from openrunner.session import get_session_config
from openrunner.api_client import APIClient

config = get_session_config()
if not config.get('api_key'):
    print('NOT_CONFIGURED')
    sys.exit(1)

client = APIClient(base_url=config['base_url'], api_key=config['api_key'])

# Resolve project (case-insensitive)
project_name = config.get('project', '')
project_id = None
for p in client.list_projects():
    full = f'{{p.get(\"org_name\",\"\")}}/{{p.get(\"name\",\"\")}}'
    if full.lower() == project_name.lower() or (p.get('name') or '').lower() == project_name.lower():
        project_id = p.get('id')
        break

if not project_id:
    print(f'PROJECT_NOT_FOUND={{project_name}}')
    client.close()
    sys.exit(1)

args = '$ARGUMENTS'.strip()
run_id = None
metric_keys = ['train/loss', 'learning_rate']
show_all = False
watch_mode = False
watch_interval = 120

# Parse args
parts = args.split() if args else []
i = 0
while i < len(parts):
    if parts[i] == '--metric' and i+1 < len(parts):
        metric_keys = [parts[i+1]]; i += 2
    elif parts[i] == '--all':
        show_all = True; i += 1
    elif parts[i] == '--watch' or parts[i] == '-w':
        watch_mode = True
        if i+1 < len(parts) and parts[i+1].isdigit():
            watch_interval = int(parts[i+1]); i += 2
        else:
            i += 1
    elif not parts[i].startswith('--'):
        run_id = parts[i]; i += 1
    else:
        i += 1

import time as _time

iteration = 0
while True:
    iteration += 1

    # Clear screen on refresh (not first run)
    if iteration > 1:
        print('\\033[2J\\033[H', end='')

    # Get runs
    if run_id:
        runs = [{{'id': run_id}}]
    else:
        resp = client._request('get', f'/projects/{{project_id}}/runs', params={{'limit': 10, 'order': 'desc'}})
        runs_data = resp.json()
        if isinstance(runs_data, dict) and 'detail' in runs_data:
            print('API_ERROR=%s' % runs_data['detail'])
            break
        if isinstance(runs_data, dict):
            runs = runs_data.get('runs', [])
        elif isinstance(runs_data, list):
            runs = runs_data
        else:
            runs = []
        if not runs:
            print('NO_RUNS')
            break

    # Collect metrics
    bars = '▁▂▃▄▅▆▇█'
    results = []

    for run in runs[:10]:
        rid = run.get('id', run) if isinstance(run, dict) else run
        try:
            resp = client._request('get', f'/runs/{{rid}}/metrics', params={{'max_points': 10000}})
            data = resp.json()
            # Response is either {{metrics: ...}} or directly {{key: [points]}}
            metrics = data.get('metrics', data) if isinstance(data, dict) else {{}}
            if not metrics and not show_all:
                continue

            # If none of the requested metrics found, use whatever is available
            found_any = any(k in metrics for k in metric_keys)
            if not found_any and metrics and not show_all:
                metric_keys = list(metrics.keys())[:2]

            for key, points in metrics.items():
                if not show_all and key not in metric_keys:
                    continue
                if not points:
                    continue

                values = [pt.get('value', pt) if isinstance(pt, dict) else pt for pt in points]
                steps = [pt.get('step', i) if isinstance(pt, dict) else i for i, pt in enumerate(points)]
                values = [v for v in values if isinstance(v, (int, float))]
                if not values:
                    continue

                min_v = min(values)
                max_v = max(values)
                range_v = max_v - min_v or 1
                w = 60

                # Sample if too many
                if len(values) > w:
                    step_size = len(values) / w
                    sampled = [values[int(j * step_size)] for j in range(w)]
                else:
                    sampled = values

                sparkline = ''
                for v in sampled:
                    idx = int((v - min_v) / range_v * (len(bars) - 1))
                    sparkline += bars[idx]

                run_name = run.get('display_name') or run.get('name') or rid[:8] if isinstance(run, dict) else rid[:8]
                run_state = run.get('state', 'unknown') if isinstance(run, dict) else 'unknown'
                direction = 'rising' if values[-1] > values[0] else 'falling'
                pct = ((values[-1] - values[0]) / (values[0] or 1)) * 100

                results.append({{
                    'run_id': rid,
                    'run_name': run_name,
                    'metric': key,
                    'sparkline': sparkline,
                    'min': min_v,
                    'max': max_v,
                    'latest': values[-1],
                    'steps': len(values),
                    'step_range': f'{{steps[0]}}->{{steps[-1]}}',
                    'direction': direction,
                    'pct': pct,
                    'state': run_state,
                }})
        except Exception as e:
            results.append({{'run_id': rid, 'error': str(e)}})

    if not results:
        print('NO_METRICS')
        break

    # ASCII output
    print('=' * 72)
    print(f' OPENRUNNER METRICS — {{project_name}}')
    print('=' * 72)

    for r in results:
        if 'error' in r:
            print(f'  {{r[\"run_id\"][:8]}} — error: {{r[\"error\"]}}')
            continue
        print()
        print(f'  Run: {{r[\"run_name\"]}} ({{r[\"run_id\"][:8]}})')
        print(f'  Metric: {{r[\"metric\"]}} | Steps: {{r[\"step_range\"]}} ({{r[\"steps\"]}} pts)')
        print('  Range: %.6f -> %.6f | Latest: %.6f' % (r['min'], r['max'], r['latest']))
        print('  ' + r['sparkline'])
        arrow = '↗' if r['pct'] > 0 else '↘'
        print('  %s %s (%+.1f%%)' % (arrow, r['direction'], r['pct']))

    # Summary table
    print()
    print('-' * 72)
    print(' %-20s %-15s %10s %10s %10s %8s' % ('Run', 'Metric', 'Latest', 'Min', 'Max', 'Trend'))
    print('-' * 72)
    for r in results:
        if 'error' in r:
            continue
        name = (r['run_name'] or '')[:20]
        met = r['metric'][:15]
        arrow = '↗' if r['pct'] > 0 else '↘'
        trend = '%s%+.0f%%' % (arrow, r['pct'])
        print(' %-20s %-15s %10.4f %10.4f %10.4f %8s' % (name, met, r['latest'], r['min'], r['max'], trend))
    print('-' * 72)

    # Live runs footer — show link + loss indicator for in-progress runs
    base_url = config.get('base_url', '').rstrip('/')
    live_runs = [r for r in results if r.get('state') in ('running', 'in_progress') and 'error' not in r]
    if live_runs:
        print()
        print('=' * 72)
        print(' LIVE RUNS')
        print('=' * 72)
        seen_ids = set()
        for r in live_runs:
            if r['run_id'] in seen_ids:
                continue
            seen_ids.add(r['run_id'])
            loss_metrics = [x for x in live_runs if x['run_id'] == r['run_id'] and 'loss' in x['metric'].lower()]
            lr_metrics = [x for x in live_runs if x['run_id'] == r['run_id'] and ('lr' in x['metric'].lower() or 'learning' in x['metric'].lower())]
            indicator = ''
            if loss_metrics:
                lm = loss_metrics[0]
                arrow = '↘' if lm['pct'] < 0 else '↗'
                indicator += ' loss: %.4f %s' % (lm['latest'], arrow)
            if lr_metrics:
                lrm = lr_metrics[0]
                indicator += ' | lr: %.2e' % lrm['latest']
            run_url = '%s/%s/runs/%s' % (base_url, project_name, r['run_id'])
            print()
            print('  %s %s' % (r['run_name'], indicator))
            if loss_metrics:
                print('  %s' % loss_metrics[0]['sparkline'])
            print('  -> %s' % run_url)
        print()
        print('=' * 72)

    # Watch mode: loop or exit
    if not watch_mode:
        break
    if not live_runs:
        print('\\nAll runs finished. Exiting watch mode.')
        break
    print('\\n  Refreshing in %ds... (Ctrl+C to stop)' % watch_interval)
    try:
        _time.sleep(watch_interval)
    except KeyboardInterrupt:
        print('\\nWatch stopped.')
        break

# PNG generation if display available
has_display = os.environ.get('DISPLAY') or os.environ.get('WAYLAND_DISPLAY') or sys.platform == 'darwin'
if has_display:
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        import tempfile

        fig, axes = plt.subplots(len([r for r in results if 'error' not in r]), 1,
                                  figsize=(12, 3 * len([r for r in results if 'error' not in r])),
                                  squeeze=False)
        fig.suptitle(f'OpenRunner Metrics — {{project_name}}', fontsize=14, fontweight='bold')

        plot_idx = 0
        for r in results:
            if 'error' in r:
                continue
            # Re-fetch values for plot
            resp2 = client._request('get', f'/runs/{{r[\"run_id\"]}}/metrics', params={{'keys': r[\"metric\"]}})
            pts = resp2.json().get('metrics', {{}}).get(r['metric'], [])
            vals = [pt.get('value', pt) if isinstance(pt, dict) else pt for pt in pts]
            stp = [pt.get('step', i) if isinstance(pt, dict) else i for i, pt in enumerate(pts)]
            vals = [v for v in vals if isinstance(v, (int, float))]
            stp = stp[:len(vals)]

            ax = axes[plot_idx][0]
            ax.plot(stp, vals, linewidth=1.5, color='#2196F3')
            ax.fill_between(stp, vals, alpha=0.1, color='#2196F3')
            ax.set_title(f'{{r[\"run_name\"]}} — {{r[\"metric\"]}}', fontsize=11)
            ax.set_xlabel('Step')
            ax.set_ylabel(r['metric'])
            ax.grid(True, alpha=0.3)
            plot_idx += 1

        plt.tight_layout()
        png_path = Path(tempfile.gettempdir()) / 'openrunner_metrics.png'
        fig.savefig(png_path, dpi=150, bbox_inches='tight')
        plt.close(fig)
        print(f'\\nPNG_SAVED={{png_path}}')
    except ImportError:
        print('\\nPNG_SKIP=matplotlib not installed (pip install matplotlib)')
    except Exception as e:
        print(f'\\nPNG_ERROR={{e}}')

client.close()
print('\\nDONE')
"
```

### Step 2: Present results

Show the ASCII chart and table to the user. If a PNG was generated, mention its path so they can open it.

If NOT_CONFIGURED: tell user to run `/openrunner:setup` first.
If NO_RUNS: tell user no training runs found in project.
If NO_METRICS: tell user runs exist but no metrics logged yet.
"""

STATUSLINE_CMD = """---
name: {prefix}statusline
description: Configure which metrics appear in the Claude Code footer
allowed-tools:
  - Bash
  - AskUserQuestion
---
<objective>
Configure which project, run, and metrics appear in the Claude Code statusline footer.
Interactive setup: project → run → metrics.
</objective>

<process>
1. Run the bash script to list projects.
2. Use AskUserQuestion tool with the projects as options. Default = current project.
3. Run the bash script to list runs for that project.
4. Use AskUserQuestion tool with the runs as options. Include "latest (auto-follow)" as recommended.
5. Run the bash script to list metrics for the chosen run.
6. Use AskUserQuestion tool (multiSelect) for metrics. First question: sparkline metric. Second: additional metrics.
7. Save to ~/.openrunner/statusline.json.
8. Confirm with preview.

IMPORTANT: You MUST use the AskUserQuestion tool for steps 2, 4, and 6. Do NOT just propose and ask "go" — present proper interactive options derived from the bash output.
</process>

### Step 1: List projects and runs

```bash
python3 -c "
import sys, os, json
from pathlib import Path
for p in ([os.path.join(d, 'site-packages') for d in __import__('glob').glob(os.path.expanduser('~/.local/lib/python3.*/')) + __import__('glob').glob(os.path.expanduser('~/Library/Python/3.*/lib/python/'))]):
    if os.path.isdir(p): sys.path.insert(0, p)
from openrunner.session import get_session_config
from openrunner.api_client import APIClient

config = get_session_config()
if not config.get('api_key'):
    print('NOT_CONFIGURED'); sys.exit(1)

client = APIClient(base_url=config['base_url'], api_key=config['api_key'])

# List projects
projects = client.list_projects()
print('PROJECTS:')
current = config.get('project', '')
for i, p in enumerate(projects, 1):
    full = '%s/%s' % (p.get('org_name',''), p.get('name',''))
    marker = ' (current)' if full.lower() == current.lower() else ''
    print('  [%d] %s%s' % (i, full, marker))

# Show current statusline config
cfg_path = Path.home() / '.openrunner' / 'statusline.json'
if cfg_path.exists():
    cfg = json.loads(cfg_path.read_text())
    print('\\nCURRENT_CONFIG: project=%s run=%s sparkline=%s metrics=%s' % (
        cfg.get('project','auto'), cfg.get('run','latest'),
        cfg.get('sparkline','auto'), cfg.get('metrics',[])))
else:
    print('\\nCURRENT_CONFIG: not configured')

client.close()
"
```

### Step 2: Ask project (MUST use AskUserQuestion tool)

Use AskUserQuestion with options built from the project list above. Mark current project as "(Recommended)". Do NOT skip this step or propose defaults without asking.

### Step 3: List runs for chosen project

```bash
python3 -c "
import sys, os, json
from pathlib import Path
for p in ([os.path.join(d, 'site-packages') for d in __import__('glob').glob(os.path.expanduser('~/.local/lib/python3.*/')) + __import__('glob').glob(os.path.expanduser('~/Library/Python/3.*/lib/python/'))]):
    if os.path.isdir(p): sys.path.insert(0, p)
from openrunner.session import get_session_config
from openrunner.api_client import APIClient

config = get_session_config()
client = APIClient(base_url=config['base_url'], api_key=config['api_key'])

# PROJECT_NAME will be replaced by the chosen project
pname = 'PROJECT_NAME'
pid = None
for p in client.list_projects():
    full = '%s/%s' % (p.get('org_name',''), p.get('name',''))
    if full.lower() == pname.lower() or (p.get('name') or '').lower() == pname.lower():
        pid = p.get('id'); break

if not pid:
    print('PROJECT_NOT_FOUND'); client.close(); sys.exit(1)

resp = client._request('get', '/projects/%s/runs' % pid, params={{'limit': 10, 'order': 'desc'}})
runs_data = resp.json()
runs = runs_data.get('runs', []) if isinstance(runs_data, dict) else runs_data

print('RUNS in %s:' % pname)
for i, r in enumerate(runs, 1):
    name = r.get('display_name') or r.get('id','?')
    state = r.get('state', '?')
    icon = ' [running]' if state == 'running' else ''
    print('  [%d] %s (%s)%s' % (i, name, r.get('id','?')[:8], icon))

if not runs:
    print('  (no runs)')

print('\\n  [0] latest (auto-follow newest run)')
client.close()
"
```

### Step 4: Ask run (MUST use AskUserQuestion tool)

Use AskUserQuestion with options built from the runs list. Include "latest (auto-follow)" as first option with "(Recommended)". Show run names and states.

### Step 5: List metrics for chosen run

```bash
python3 -c "
import sys, os, json
from pathlib import Path
for p in ([os.path.join(d, 'site-packages') for d in __import__('glob').glob(os.path.expanduser('~/.local/lib/python3.*/')) + __import__('glob').glob(os.path.expanduser('~/Library/Python/3.*/lib/python/'))]):
    if os.path.isdir(p): sys.path.insert(0, p)
from openrunner.session import get_session_config
from openrunner.api_client import APIClient

config = get_session_config()
client = APIClient(base_url=config['base_url'], api_key=config['api_key'])

# RUN_ID will be replaced
rid = 'RUN_ID'
resp = client._request('get', '/runs/%s/metrics' % rid, params={{'max_points': 10000}})
data = resp.json()
metrics = data.get('metrics', data) if isinstance(data, dict) else {{}}
if 'detail' in metrics: metrics = {{}}

keys = sorted(metrics.keys())
print('METRICS (%d available):' % len(keys))
for i, k in enumerate(keys, 1):
    pts = metrics.get(k, [])
    n = len(pts) if isinstance(pts, list) else 0
    last_str = ''
    if n > 0:
        lp = pts[-1]
        v = lp.get('value', lp) if isinstance(lp, dict) else lp
        if isinstance(v, float):
            last_str = ' (%.4f, %d pts)' % (v, n)
        else:
            last_str = ' (%s, %d pts)' % (v, n)
    print('  [%d] %s%s' % (i, k, last_str))

client.close()
"
```

### Step 6: Ask metrics (MUST use AskUserQuestion tool)

Use AskUserQuestion with TWO questions:
1. "Which metric for the sparkline?" — single select from metrics list (recommend first loss-like metric)
2. "Which additional metrics to show?" — multiSelect: true, from remaining metrics (exclude system.* by default)

### Step 7: Save config

```bash
python3 -c "
import json
from pathlib import Path
cfg_path = Path.home() / '.openrunner' / 'statusline.json'
cfg_path.parent.mkdir(parents=True, exist_ok=True)
cfg = {{'project': 'PROJECT_NAME', 'run': 'RUN_VALUE', 'sparkline': 'SPARKLINE_KEY', 'metrics': METRICS_LIST}}
cfg_path.write_text(json.dumps(cfg, indent=2))
print('Saved: %s' % cfg_path)
print('  Project: %s' % cfg['project'])
print('  Run: %s' % cfg['run'])
print('  Sparkline: %s' % cfg['sparkline'])
print('  Metrics: %s' % cfg['metrics'])
print()
print('Footer will update on next statusline refresh (30s).')
"
```

Replace PROJECT_NAME, RUN_VALUE (run_id or 'latest'), SPARKLINE_KEY, and METRICS_LIST with user's choices.
"""

MCP_CMD = """---
name: {prefix}mcp
description: Register OpenRunner MCP server for native tool access
allowed-tools:
  - Bash
  - AskUserQuestion
---
<objective>
Register the OpenRunner MCP server with `claude mcp add` so Claude Code has native tool access.
</objective>

<process>
1. Find the openrunner binary path
2. Tell user to run `claude mcp add` with the correct path
3. Explain available tools
4. Tell user to QUIT and restart session (MCP loads at startup only)
</process>

Find openrunner binary:
```bash
python3 -c "
import shutil, os, glob
bin_path = shutil.which('openrunner')
if not bin_path:
    candidates = glob.glob(os.path.expanduser('~/.local/bin/openrunner')) + \
                 sorted(glob.glob(os.path.expanduser('~/Library/Python/3.*/bin/openrunner')), reverse=True)
    for c in candidates:
        if os.path.isfile(c):
            bin_path = c
            break
if bin_path:
    print(f'FOUND={{bin_path}}')
else:
    print('NOT_FOUND')
"
```

Tell the user to run (replace path with FOUND value):
```
! claude mcp add openrunner /path/to/openrunner mcp serve
```

**10 tools after restart:**
- openrunner_search_sessions, openrunner_search_papers, openrunner_search_research
- openrunner_search_runs, openrunner_search_code
- openrunner_get_session, openrunner_list_runs, openrunner_get_run_metrics
- openrunner_list_artifacts, openrunner_log_note

**IMPORTANT:** `/reload-plugins` does NOT work for MCP. User MUST `/quit` and start a new session.
"""


_STATUSLINE_SCRIPT = '''#!/bin/bash
# OpenRunner statusline provider.
# Writes one-liner to $TMPDIR/claude-statusline-openrunner.txt
# (matches Node's os.tmpdir() — macOS uses /var/folders/.../T/ not /tmp/)
CACHE_DIR="${TMPDIR:-/tmp}"
CACHE="${CACHE_DIR%/}/claude-statusline-openrunner.txt"
TTL=30

# Refresh cache in background if stale
if [ ! -f "$CACHE" ] || [ $(($(date +%s) - $(stat -c%Y "$CACHE" 2>/dev/null || stat -f%m "$CACHE" 2>/dev/null || echo 0))) -gt $TTL ]; then
  (python3 - <<'PY' > "$CACHE.tmp" 2>/dev/null && mv "$CACHE.tmp" "$CACHE" &
import sys, os
for p in __import__('glob').glob(os.path.expanduser('~/.local/lib/python3.*/site-packages')) + __import__('glob').glob(os.path.expanduser('~/Library/Python/3.*/lib/python/site-packages')):
    if os.path.isdir(p): sys.path.insert(0, p)
try:
    from openrunner.session import get_session_config
    from openrunner.api_client import APIClient
except ImportError:
    print("openrunner not installed"); sys.exit(0)
cfg = get_session_config()
if not cfg.get('api_key'): print("not configured"); sys.exit(0)
client = APIClient(base_url=cfg['base_url'], api_key=cfg['api_key'])
# Read statusline config for project/run override
import json as _json
sl_cfg = {}
sl_path = os.path.expanduser('~/.openrunner/statusline.json')
if os.path.isfile(sl_path):
    try: sl_cfg = _json.loads(open(sl_path).read())
    except: pass
pname = sl_cfg.get('project') or cfg.get('project', '')
pid = None
for p in client.list_projects():
    full = f"{p.get('org_name','')}/{p.get('name','')}"
    if full.lower() == pname.lower() or (p.get('name') or '').lower() == pname.lower():
        pid = p.get('id'); break
if not pid: print("?"); client.close(); sys.exit(0)
# If specific run configured, only show that one
configured_run = sl_cfg.get('run', 'latest')
if configured_run and configured_run != 'latest':
    runs = [{'id': configured_run, 'state': 'unknown'}]
else:
    runs = client._request('get', f'/projects/{pid}/runs', params={'limit': 5, 'order': 'desc', 'state': 'running'}).json()
    if isinstance(runs, dict): runs = runs.get('runs', [])
    # Fallback to latest if no running runs
    if not runs:
        runs = client._request('get', f'/projects/{pid}/runs', params={'limit': 1, 'order': 'desc'}).json()
        if isinstance(runs, dict): runs = runs.get('runs', [])
parts = []
for run in runs[:3]:
    rid = run.get('id', '?'); state = run.get('state', '?')
    name = (run.get('display_name') or rid)[:12]
    # Status circle: green=running, yellow=stopping, red=crashed/stopped
    if state == 'running':
        circle = '\\033[32m\\u25cf\\033[0m'  # green
    elif state in ('stopping', 'preempting'):
        circle = '\\033[33m\\u25cf\\033[0m'  # yellow
    elif state in ('crashed', 'failed'):
        circle = '\\033[31m\\u25cf\\033[0m'  # red
    elif state == 'finished':
        circle = '\\033[32m\\u2713\\033[0m'  # green check
    else:
        circle = '\\033[90m\\u25cf\\033[0m'  # gray
    icon = ' ' + circle
    m = client._request('get', f'/runs/{rid}/metrics', params={'max_points': 10000}).json()
    if not isinstance(m, dict) or 'detail' in m:
        m = {}
    elif 'metrics' in m:
        m = m['metrics']
    # Read user-configured metrics from ~/.openrunner/statusline.json
    # Format: {"metrics": ["train/loss", "wer"], "sparkline": "train/loss"}
    # If not configured, auto-detect: sparkline first loss-like key, show first 2 metrics
    import json as _j
    sl_cfg_path = os.path.expanduser('~/.openrunner/statusline.json')
    sl_cfg = {}
    if os.path.isfile(sl_cfg_path):
        try: sl_cfg = _j.loads(open(sl_cfg_path).read())
        except: pass
    show_metrics = sl_cfg.get('metrics', [])
    spark_key = sl_cfg.get('sparkline', '')
    # Auto-detect if not configured
    if not show_metrics:
        all_keys = list(m.keys())
        # Pick loss-like for sparkline, then next interesting metric
        for k in all_keys:
            if 'loss' in k.lower() and not spark_key:
                spark_key = k
            elif k not in ('epoch', 'lr', 'learning_rate') and len(show_metrics) < 2:
                if 'system' not in k.lower():
                    show_metrics.append(k)
        if spark_key and spark_key not in show_metrics:
            show_metrics.insert(0, spark_key)
    if not spark_key and show_metrics:
        spark_key = show_metrics[0]
    # OSC 8 hyperlink: clickable run name in terminal
    run_url = f"{cfg['base_url'].rstrip('/')}/{pname.lower()}/runs/{rid}"
    linked_name = f"\\033]8;;{run_url}\\033\\\\{name}{icon}\\033]8;;\\033\\\\"
    bits = [linked_name]
    # Sparkline for primary metric
    spark_data = m.get(spark_key, [])
    if spark_data:
        last = spark_data[-1]
        v = last.get('value', last) if isinstance(last, dict) else last
        s = last.get('step', '?') if isinstance(last, dict) else '?'
        bars = '\\u2581\\u2582\\u2583\\u2584\\u2585\\u2586\\u2587\\u2588'
        vals = [pt.get('value', pt) if isinstance(pt, dict) else pt for pt in spark_data[-10:]]
        vals = [x for x in vals if isinstance(x, (int, float))]
        spark = ''
        if len(vals) > 1:
            mn, mx = min(vals), max(vals)
            rng = mx - mn or 1
            spark = ''.join(bars[int((x - mn) / rng * 7)] for x in vals)
        bits.append(f"s{s} {spark} {v:.2f}")
    # Additional configured metrics
    for mk in show_metrics:
        if mk == spark_key: continue
        pts = m.get(mk, [])
        if not pts: continue
        last = pts[-1]
        v = last.get('value', last) if isinstance(last, dict) else last
        label = mk.split('/')[-1][:6]
        if isinstance(v, float):
            bits.append(f"{label}={v:.3f}" if v < 1 else f"{label}={v:.1f}")
        else:
            bits.append(f"{label}={v}")
    parts.append(' '.join(bits))
print(' | '.join(parts) if parts else 'no runs')
client.close()
PY
) 2>/dev/null
fi
cat "$CACHE" 2>/dev/null
'''


def install_claude_code() -> list[str]:
    """Install commands in ~/.claude/commands/openrunner/."""
    cmd_dir = Path.home() / ".claude" / "commands" / "openrunner"
    cmd_dir.mkdir(parents=True, exist_ok=True)

    commands = {
        "sync-session.md": SYNC_SESSION_CMD,
        "log-note.md": LOG_NOTE_CMD,
        "setup.md": SETUP_CMD,
        "list-sessions.md": LIST_SESSIONS_CMD,
        "chat.md": CHAT_CMD,
        "login.md": LOGIN_CMD,
        "code-upload.md": CODE_UPLOAD_CMD,
        "update.md": UPDATE_CMD,
        "mcp.md": MCP_CMD,
        "plot-session-run.md": PLOT_SESSION_RUN_CMD,
        "statusline.md": STATUSLINE_CMD,
    }

    files = []
    for filename, template in commands.items():
        path = cmd_dir / filename
        path.write_text(template.format(prefix="openrunner:"))
        files.append(str(path))

    # Install CLAUDE.md with MCP usage instructions
    claude_md = Path.home() / ".claude" / "CLAUDE.md"
    mcp_instructions = """# OpenRunner MCP Integration

When the user asks about training metrics, loss charts, run data, or experiment results:
- Use `mcp__openrunner__openrunner_watch_run` to show ASCII sparkline charts
- Use `mcp__openrunner__openrunner_get_run_metrics` for raw metrics
- Use `mcp__openrunner__openrunner_list_runs` to find runs
- Use `mcp__openrunner__openrunner_search_sessions` to search AI session history

Do NOT parse log files or grep for metrics when OpenRunner MCP tools are available.

When the user asks to plot or visualize run metrics in this session:
- Use `/openrunner:plot-session-run` for full ASCII charts + table + PNG
- Supports: `/openrunner:plot-session-run [run_id] [--metric key] [--all]`

When the user asks about papers, research, or sessions:
- Use `mcp__openrunner__openrunner_search_papers` for paper content
- Use `mcp__openrunner__openrunner_search_research` for research plans
- Use `mcp__openrunner__openrunner_search_sessions` for AI session history
- Use `mcp__openrunner__openrunner_update_paper` to modify paper sections
"""
    import re
    if claude_md.exists():
        content = claude_md.read_text()
        if "OpenRunner MCP Integration" in content:
            # Replace existing section with updated version
            content = re.sub(
                r"# OpenRunner MCP Integration.*?(?=\n# |\Z)",
                mcp_instructions.strip(),
                content,
                flags=re.DOTALL,
            )
            claude_md.write_text(content)
        else:
            claude_md.write_text(content + "\n" + mcp_instructions)
        files.append(str(claude_md))
    else:
        claude_md.write_text(mcp_instructions)
        files.append(str(claude_md))

    # Install statusline script for Claude Code footer
    scripts_dir = Path.home() / ".claude" / "scripts"
    scripts_dir.mkdir(parents=True, exist_ok=True)
    statusline_script = scripts_dir / "openrun-status.sh"
    statusline_script.write_text(_STATUSLINE_SCRIPT)
    statusline_script.chmod(0o755)
    files.append(str(statusline_script))

    # Auto-patch any JS statusline to read /tmp/claude-statusline-*.txt plugin files.
    # Generic: finds the statusline command from settings.json, patches if it's a node script.
    import json as _json
    settings_file = Path.home() / ".claude" / "settings.json"
    if settings_file.exists():
        try:
            settings = _json.loads(settings_file.read_text())
            sl_cmd = settings.get("statusLine", {}).get("command", "")
            # Extract JS file path from command like 'node "/path/to/script.js"'
            import shlex
            parts = shlex.split(sl_cmd) if sl_cmd else []
            js_file = None
            for p in parts:
                if p.endswith(".js") and Path(p).exists():
                    js_file = Path(p)
                    break
            if js_file:
                content = js_file.read_text()
                needs_patch = False
                # Add spawn logic if missing (triggers refresh scripts)
                if "scripts/*-status.sh" not in content and "// Output" in content:
                    needs_patch = True
                    spawn_patch = """    // Spawn plugin refresh scripts if cache stale
    try {
      const scriptsDir = path.join(os.homedir(), '.claude', 'scripts');
      if (fs.existsSync(scriptsDir)) {
        const scripts = fs.readdirSync(scriptsDir).filter(f => f.endsWith('-status.sh'));
        for (const s of scripts) {
          const name = s.replace('-status.sh', '').replace('openrun', 'openrunner');
          const cachePath = path.join(os.tmpdir(), 'claude-statusline-' + name + '.txt');
          let stale = !fs.existsSync(cachePath);
          if (!stale) { try { stale = (Date.now() - fs.statSync(cachePath).mtimeMs) / 1000 > 30; } catch(e) { stale = true; } }
          if (stale) { try { require('child_process').spawn('bash', [path.join(scriptsDir, s)], {detached:true,stdio:'ignore'}).unref(); } catch(e) {} }
        }
      }
    } catch (e) {}

"""
                    content = content.replace("// Output", spawn_patch + "    // Output")
                # Add reader if missing
                if "claude-statusline-" not in content and "// Output" in content:
                    reader_patch = """    // Read plugin statusline segments from /tmp/claude-statusline-*.txt
    let plugins = '';
    try {
      const pfiles = fs.readdirSync(os.tmpdir())
        .filter(f => f.startsWith('claude-statusline-') && f.endsWith('.txt'));
      for (const f of pfiles) {
        try {
          const fp = path.join(os.tmpdir(), f);
          const st = fs.statSync(fp);
          if ((Date.now() - st.mtimeMs) / 1000 > 120) continue;
          const c = fs.readFileSync(fp, 'utf8').trim();
          if (c && c.length < 200) plugins += ' \\u2502 ' + c;
        } catch (e) {}
      }
    } catch (e) {}

"""
                    needs_patch = True
                    content = content.replace("// Output", reader_patch + "    // Output")
                    content = content.replace("${ctx}`)", "${ctx}${plugins}`)")
                if needs_patch:
                    js_file.write_text(content)
                    files.append(str(js_file))
        except Exception:
            pass

    return files


def _install_all_commands_to_dir(cmd_dir: Path, prefix: str = "openrunner:") -> list[str]:
    """Install all commands to a given directory."""
    cmd_dir.mkdir(parents=True, exist_ok=True)

    commands = {
        "sync-session.md": SYNC_SESSION_CMD,
        "log-note.md": LOG_NOTE_CMD,
        "setup.md": SETUP_CMD,
        "list-sessions.md": LIST_SESSIONS_CMD,
        "chat.md": CHAT_CMD,
        "login.md": LOGIN_CMD,
        "code-upload.md": CODE_UPLOAD_CMD,
        "update.md": UPDATE_CMD,
        "mcp.md": MCP_CMD,
        "plot-session-run.md": PLOT_SESSION_RUN_CMD,
        "statusline.md": STATUSLINE_CMD,
    }

    files = []
    for filename, template in commands.items():
        path = cmd_dir / filename
        path.write_text(template.format(prefix=prefix))
        files.append(str(path))

    return files


def install_codex() -> list[str]:
    """Install commands for Codex CLI.

    Codex uses ~/.codex/prompts/ for custom slash commands (Markdown).
    Also adds instructions to AGENTS.md for implicit context.
    Ref: https://developers.openai.com/codex/custom-prompts
    """
    # Codex custom prompts directory
    files = _install_all_commands_to_dir(Path.home() / ".codex" / "prompts")

    # Also add to AGENTS.md for implicit context
    agents_file = Path.home() / ".codex" / "AGENTS.md"
    instruction = "\n\n## OpenRunner Integration\nUse `/prompts:openrunner:sync-session` to log this session.\nUse `/prompts:openrunner:setup` to configure.\nUse `/prompts:openrunner:chat <question>` to ask about sessions.\nUse `/prompts:openrunner:login` to authenticate.\n"
    if agents_file.exists():
        content = agents_file.read_text()
        if "openrunner" not in content.lower():
            agents_file.write_text(content + instruction)
            files.append(str(agents_file))
    else:
        agents_file.write_text("# Codex Agent Instructions" + instruction)
        files.append(str(agents_file))

    return files


def install_qwen_code() -> list[str]:
    """Install commands for Qwen Code.

    Qwen Code uses .qwen-code/commands/ in project root or ~/.qwen-code/commands/ globally.
    Supports Markdown format with YAML frontmatter.
    Ref: https://github.com/QwenLM/qwen-code/blob/main/docs/users/features/commands.md
    """
    return _install_all_commands_to_dir(Path.home() / ".qwen-code" / "commands")


def install_opencode() -> list[str]:
    """Install commands for OpenCode.

    OpenCode uses ~/.config/opencode/commands/ for global user commands.
    Each .md file becomes a user:filename command.
    Ref: https://opencode.ai/docs/commands/
    """
    return _install_all_commands_to_dir(Path.home() / ".config" / "opencode" / "commands")


# ---------------------------------------------------------------------------
# Main installer
# ---------------------------------------------------------------------------

TOOLS = {
    "claude": ("Claude Code", install_claude_code),
    "codex": ("Codex", install_codex),
    "qwen": ("Qwen Code", install_qwen_code),
    "opencode": ("OpenCode", install_opencode),
}


def install_all(targets: list[str] | None = None) -> dict[str, list[str]]:
    """Install commands for specified tools (or all if None).

    Returns dict of tool_name -> list of installed file paths.
    """
    results = {}

    if targets:
        to_install = [(k, v) for k, v in TOOLS.items() if k in targets]
    else:
        # Auto-detect: install for all tools
        to_install = list(TOOLS.items())

    for key, (name, installer) in to_install:
        files = installer()
        results[name] = files

    return results
