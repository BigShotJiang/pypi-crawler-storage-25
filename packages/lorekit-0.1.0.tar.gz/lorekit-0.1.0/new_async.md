# Async NPC Combat — Parallel Decision Phase

Parallelize NPC decision-making in multi-NPC encounters. Each NPC turn
takes ~10-15s (Claude subprocess). With 4+ NPCs that's 40-60s sequential.
Parallel decisions cut it to ~15s total.

Only implement when encounters routinely have 3+ NPCs and the wait becomes
a gameplay problem. The current sequential flow is correct and simpler.

---

## Design

Parallelize only the LLM decision calls. Resolution stays sequential.
No changes to intent schema, NPC prompt, or parser.

### Phase 1: Freeze

Snapshot the encounter state: positions, conditions, modifiers, initiative
order. This is the shared context all NPCs decide from.

### Phase 2: Decide (parallel)

Launch all pending NPC decision calls simultaneously. Each NPC receives
the same frozen snapshot as combat context. No database writes during
this phase — pure LLM calls.

Each NPC returns a single intent (same format as today).

### Phase 3: Resolve (sequential, in initiative order)

For each NPC in initiative order:

1. Validate the intent against current (live) state
2. If valid → execute normally (move + resolve_action + advance_turn)
3. If invalid → re-call that single NPC with updated state and execute
   the new intent

Common invalidation cases:
- Target moved to a different zone (most frequent — NPC planned to
  move + attack but target is no longer there)
- Target already dead/incapacitated
- Zone blocked or occupied differently than expected
- NPC's own conditions changed (stunned by an earlier resolution)

Only the NPC whose intent was invalidated gets re-called. The others
resolve normally. Example: 4 NPCs decide in parallel, 1 has a stale
target → 1 extra LLM call, not 4.

### Phase 4: Present

Return all NPC narrations and mechanical results in initiative order.
GM narrates the round to the player.

---

## Why this works

- All NPCs decide from the same snapshot — no NPC "sees the future"
- No changes to intent format, prompt, or parser
- Invalid intents are re-decided with real state, not generic fallbacks
- The NPC's personality drives the re-decision (same LLM, fresh context)
- Parallel phase is pure LLM calls (no DB writes) — safe to run concurrently
- Sequential phase is pure DB writes (no LLM calls) — fast
- Re-calls only happen on conflict, which is rare in practice

---

## When to implement

- Encounters routinely have 3+ NPCs acting per round
- Sequential wait (30s+) is a noticeable gameplay problem
- The current sequential `npc_combat_turn` has been stable for 10+ encounters
