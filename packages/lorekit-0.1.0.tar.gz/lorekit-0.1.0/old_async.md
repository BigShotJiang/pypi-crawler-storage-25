# Async NPC Combat

Parallelize NPC turns in multi-NPC encounters. Currently each NPC turn takes
~10-15s (Claude subprocess). With 4 NPCs that's ~50s sequential. Parallel
decision-making cuts it to ~15s total.

**Prerequisite:** NPC structured intent must be reliable in practice first.
Play 5+ combat encounters with `npc_combat_turn`, track how often the JSON
intent parses correctly vs falls back to narrative-only. Check `data/npc.log`.
Do not build this until intent parsing is consistently reliable.

---

## Priority list intent

Before parallelizing, evolve the NPC intent from a single action to a
ranked list of contingencies. Instead of "attack Fighter", the NPC says
"attack Fighter, but if he's down attack Rogue instead, and if nobody's
reachable then retreat."

This is how real tactical thinking works — a smart NPC considers what-ifs,
a dumb one doesn't. That's more personality, not less. The engine tries
each intent in order and executes the first one that's still valid. No
re-asking the LLM, no deterministic fallbacks that might violate personality.

This works for the current sequential `npc_combat_turn` too. If the NPC's
first choice becomes invalid (target died earlier in the round), the engine
falls through to the next intent. The async version just runs the decision
phase in parallel — same intent format, same resolution logic.

---

## Flow

### 1. Freeze state

Take a snapshot of the encounter: who is where, who is alive, what modifiers
are active, whose turn it is. This snapshot is the shared truth all NPCs
decide from.

### 2. All NPCs decide simultaneously

Every NPC whose turn is pending gets the same frozen snapshot as combat
context. They all think at the same time, in parallel. Each returns a
ranked list of intents plus optional narration. No database writes happen
during this step.

### 3. Resolve one at a time, in initiative order

Go through each NPC in initiative order. For each intent in their priority
list, check if it's still valid — the target might be dead, out of range,
or the zone might be blocked by earlier resolutions. Execute the first
valid intent. If no intent is valid, it becomes a narrative-only turn
(modifiers still tick, initiative still advances).

### 4. Advance initiative

After all NPCs have resolved, advance initiative past all of them to the
next PC turn. Modifier durations tick for each NPC as their turn passes.

### 5. Present to the GM

Return all NPC narrations and mechanical results in initiative order. The GM
narrates the round to the player.

---

## Why this works

- All NPCs decide from the same snapshot, so no NPC "sees the future"
- Invalid intents fall through to the NPC's own contingency, not a generic fallback
- The NPC's personality drives every option in the list — no behavior it wouldn't choose
- The parallel step is pure LLM calls with no DB writes — safe to run concurrently
- The sequential step is pure DB writes with no LLM calls — fast
