# Future Release Plan

## v0.1.0 — First Public Release

Ship lorekit as a proper PyPI package — an open-source TTRPG game engine that
anyone can embed in their own application. Two entry points: MCP server (for AI
tool users) and GameSession Python API (for app developers building Discord
bots, web apps, or custom UIs).

### Packaging Work

The current package only includes Python source (`src/lorekit/`). For `uvx` to
work, the wheel must be self-contained.

**Bundle package data:**

- Include `systems/` (pf2e, mm3e, basic) as package data in the wheel
- Include `guidelines/` (GM_GUIDE, NPC_GUIDE, SHARED_GUIDE, REWRITING_GUIDE) as package data
- Configure this in `pyproject.toml` via `[tool.hatch.build]` or package-data directives

**Rewrite path resolution:**

- `project_root()` in `rules.py` currently walks the filesystem looking for a
  `systems/` directory. This breaks when installed as a package (resolves to
  nonsense inside site-packages).
- Replace with `importlib.resources` to locate bundled data when installed as a
  package, keeping the filesystem fallback for development (`pip install -e .`).
- Same applies to `_load_npc_guides()` in `tools/npc.py` — resolve guidelines
  from package data, fall back to filesystem.

**Publish cruncher to PyPI first:**

- lorekit depends on cruncher. It must be on PyPI before lorekit can be.
- cruncher is zero-dependency and ready to publish as-is.

**Consider separate system pack packages:**

- `resolve_system_path()` already tries `import cruncher_<system_name>` before
  falling back to the filesystem. This means system packs can ship as separate
  PyPI packages (`cruncher-pf2e`, `cruncher-mm3e`).
- For v0.1.0, bundling them in the main package is simpler. Separate packages
  make sense later if packs grow large or have different release cadences.

**Make sentence-transformers optional:**

- It pulls in torch (~2GB). That's a rough first install.
- Move to an optional dependency: `pip install lorekit[semantic]`
- Fall back to keyword-only search when not installed (the code already handles
  this gracefully via ImportError).
- Default `uvx lorekit` stays light; users opt in to semantic search.

**Provider is internal, not a separate package:**

- The Claude CLI provider ships inside lorekit (`lorekit.providers.claude`).
- The provider protocol (`AgentProvider`) is agent-agnostic — new providers
  (Codex, Gemini CLI) can be added as modules under `providers/`.
- No entry-point discovery; `load_provider()` uses simple conditional imports.
- Extract to separate packages only if/when third-party providers appear.

### End User Install Experience (after packaging work)

**As an MCP server (primary use case):**

```bash
# With uv
uvx lorekit
claude mcp add lorekit uvx lorekit

# Without uv
pip install lorekit
lorekit
claude mcp add lorekit -- lorekit
```

Any MCP-compatible AI tool (Claude Code, Codex, Gemini CLI) can connect.

**As an HTTP server (for custom clients like Discord bots):**

```bash
# With uv
uv pip install lorekit[server]
lorekit serve

# Without uv
pip install lorekit[server]
lorekit serve
```

**As a Python library:**

```python
import lorekit
session = lorekit.GameSession(campaign_dir=Path("~/my-campaign"))
await session.start()
async for event in session.send("I attack the goblin"):
    print(event.content)
```

---

## GitHub Repository Polish

### High Priority

**Fill GitHub repo metadata** (Settings > About gear icon):

- Description: "MCP-based TTRPG game engine — deterministic rules, NPC agents, branching saves"
- Topics: `mcp`, `ttrpg`, `pathfinder`, `game-engine`, `tabletop-rpg`, `ai-agents`, `python`

**Create first GitHub Release:**

```bash
# bump version in pyproject.toml and cruncher/pyproject.toml
git add pyproject.toml cruncher/pyproject.toml
git commit -m "chore: bump version to 0.1.0"
git tag v0.1.0
git push && git push --tags
gh release create v0.1.0 --title "v0.1.0" --notes "$(cat <<'EOF'
First public release.

- bullet points of what's included
EOF
)"
```

**Flesh out pyproject.toml metadata:**

```toml
[project]
name = "lorekit"
version = "0.1.0"
description = "MCP-based TTRPG game engine"
authors = [{ name = "matluz1" }]
readme = "README.md"
requires-python = ">=3.13"
license = "Apache-2.0"
keywords = ["mcp", "ttrpg", "pathfinder", "game-engine", "ai"]
classifiers = [
    "Development Status :: 3 - Alpha",
    "License :: OSI Approved :: Apache Software License",
    "Programming Language :: Python :: 3.13",
    "Topic :: Games/Entertainment :: Role-Playing",
]
dependencies = [
    "cruncher",
    "mcp[cli]",
    "sqlite-vec",
    "platformdirs",
    # sentence-transformers is optional — see [semantic] extra
]

[project.optional-dependencies]
semantic = ["sentence-transformers"]
server = ["starlette", "uvicorn"]

[project.scripts]
lorekit = "lorekit.http_server:main"

[project.urls]
Repository = "https://github.com/matluz1/lorekit"
```

**Add CI** (`.github/workflows/ci.yml`):

```yaml
name: CI
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        python-version: ["3.13"]
    steps:
      - uses: actions/checkout@v4
      - uses: astral-sh/setup-uv@v6
      - run: uv sync --dev
      - run: uv run ruff check .
      - run: uv run pytest
```

**Add CONTRIBUTING.md:**

Short and honest. Something like:

> LoreKit is early-stage. Issues and discussions welcome. If you want to
> contribute code, open an issue first so we can align on approach. Run `pytest`
> before submitting. Pre-commit hooks handle formatting.

**Add `.env` to `.gitignore`:**

Safety net for contributors.

### Low Priority

- Add IDE directories to `.gitignore` (`.vscode/`, `.idea/`, `.DS_Store`)
- Add `py.typed` marker to cruncher for type checker support
- Improve type hints gradually across modules
- Hide Deployments and Packages from GitHub sidebar (keep Releases)

### Not Needed Yet

- CHANGELOG.md — GitHub Releases page is the changelog
- CODE_OF_CONDUCT — noise until there's a community
- Branch protection / required reviews — overhead for a solo dev
- Coverage badges / dependency bots / security scanning
- Issue templates — let people just open issues

---

## Versioning

Using semver. Pre-1.0, the rules are loose:

- **0.1.0 -> 0.1.1** (patch): bug fixes, small corrections
- **0.1.0 -> 0.2.0** (minor): new features, significant changes
- **0.x.y -> 1.0.0**: stable API, committing to not breaking things

Versions are bumped on release, not on every commit. Between releases, commits
just accumulate on main. Tag and create a GitHub Release when the project is in
a meaningfully better state than the last tag.

---

## Branching

No branch strategy needed for solo development. Keep committing to main.
Use branches only for risky experiments or big refactors. If/when contributors
show up, protect main and require PRs.

---

## Release Process (once on PyPI)

```bash
# 1. bump version in pyproject.toml
# 2. commit and tag
git commit -m "chore: bump version to 0.x.0"
git tag v0.x.0
git push && git push --tags

# 3. create GitHub Release
gh release create v0.x.0 --title "v0.x.0" --notes "- what changed"

# 4. publish to PyPI (manual for now, automate later)
uv build
uv publish
```

Later, add a GitHub Actions workflow that publishes to PyPI on tag push.
