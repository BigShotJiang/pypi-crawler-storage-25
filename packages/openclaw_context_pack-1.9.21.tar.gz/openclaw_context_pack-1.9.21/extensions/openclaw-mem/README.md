# OpenClaw Mem plugin

`openclaw-mem` is the **OpenClaw observation-capture plugin** that feeds the wider `openclaw-mem` workflow.

What it does:
- captures tool results into JSONL for later ingest
- can optionally spool bounded episodic events (including conversations)
- can annotate memory-tool activity for backend-aware receipts

This package is the **sidecar capture plugin**, not the optional memory-slot backend.
Inside the `openclaw-mem` family, it is the low-risk / sidecar role.
If you want the slot-owner lane, that is `openclaw-mem-engine` — same family, different install and rollback boundary.

## Install

### Local checkout

```bash
openclaw plugins install -l ./extensions/openclaw-mem
```

### ClawHub bundle package

```bash
openclaw bundles install clawhub:openclaw-mem-lyria
```

This marketplace path installs the sidecar capture plugin. Install the optional `openclaw-mem-engine` from the GitHub repo only after reading the engine docs and choosing the memory-slot migration boundary deliberately.

## Minimal config

Add under `plugins.entries.openclaw-mem.config` in `openclaw.json`:

```jsonc
{
  "plugins": {
    "entries": {
      "openclaw-mem": {
        "enabled": true,
        "config": {
          "outputPath": "memory/openclaw-mem-observations.jsonl",
          "captureMessage": false,
          "redactSensitive": true,
          "backendMode": "auto",
          "annotateMemoryTools": true,
          "excludeAgents": ["cron-watchdog", "healthcheck"]
        }
      }
    }
  }
}
```

## Rollback

Disable the entry or uninstall the package. The native memory slot stays untouched because this plugin is sidecar-only.

## Verification (focused)

```bash
node --test extensions/openclaw-mem/toolResultSummary.test.mjs
node --experimental-strip-types --test extensions/openclaw-mem/toolResultPersistE2E.test.mjs
python3 -m pytest tests/test_plugin_episodic_summary_runtime.py tests/test_plugin_episodic_spool.py tests/test_episodic_secret_detection.py -q
```

## More context

See the repo root docs for:
- install modes
- trust model / ownership boundary
- `openclaw-mem-engine` slot-backend posture
