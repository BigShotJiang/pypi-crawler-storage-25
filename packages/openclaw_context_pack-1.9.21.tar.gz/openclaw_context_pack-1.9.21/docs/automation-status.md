# Automation status (main-only) — what is automatic vs cron vs not yet wired

This page summarizes which `openclaw-mem` capabilities are automatic, scheduled, or manual. It intentionally avoids host-specific job IDs and private paths.

The system is intentionally split into layers:
- **Plugin (sidecar)** captures observations.
- **Cron (operator automation)** runs ingest/triage and related loops.
- Some features exist as CLI tools but are **not yet auto-wired** into the default agent loop.

## 1) Automatic (plugin / sidecar) — already running
These happen automatically once the OpenClaw plugin is enabled.

- Capture: writes JSONL observations
  - output: OpenClaw state memory directory (operator-configured)
- Backend annotations (observability): tags memory backend + memory tool actions
- Redaction/denoise:
  - `captureMessage=false`
  - exclude noisy/sensitive tools (exec/read/browser/message/gateway/nodes/canvas)

What this layer does *not* do:
- it does not run harvest/ingest into SQLite
- it does not run context packing
- it does not run AI compression

## 2) Automatic (cron) — scheduled operator loops
These are automated via OpenClaw cron jobs (so the system works without manual CLI calls).

### Harvest + triage (main)
- Main baseline: scheduled by the operator
  - code root: repository checkout
  - DB: OpenClaw memory state directory
  - receipts: OpenClaw memory state directory

### Feature lanes (A-fast / A-deep, main-governed)
- A-fast / A-deep: optional operator-managed lanes
- governance: lane packets converge to `main`; no long-lived `dev` integration branch contract
- lock: `openclaw-mem-dev-feature` + global heavy-python guard (legacy lock name retained)

### AI compression (derived artifact)
- Schedule: operator-defined
- Output (derived): workspace memory/compressed directory
- Receipt: workspace memory/compressed receipts directory
- Governance: derived-by-default, no durable promotion (see `docs/ai-compression.md`)

### Graphic Memory — auto-capture (git commits)
- Schedule: operator-defined
- Spec: maintainer/operator archive
- DB: OpenClaw memory state directory
- State cursor (default): `OPENCLAW_STATE_DIR/memory/openclaw-mem/graph-capture-state.json`

### Graphic Memory — auto-capture (markdown index-only)
- Schedule: operator-defined
- Spec: maintainer/operator archive
- DB: OpenClaw memory state directory
- State cursor (default): `OPENCLAW_STATE_DIR/memory/openclaw-mem/graph-capture-md-state.json`

## 3) Exists (CLI) but NOT yet auto-wired (waiting for further decisions)

### Context Packer (`pack`)
- `pack` exists and supports `--trace` receipts.
- Not yet wired as the default per-request context feeder for OpenClaw.

Why not wired yet:
- We want a clear promotion gate and a burn-in window.
- We need confidence on determinism, privacy/redaction, and operator debuggability.

Current pilot sequencing (2026-02):
- **Pillar A (build now):** contract hardening + citation/rationale coverage + benchmark receipts.
- **Pillar B (spec now):** learning-record lifecycle/bench specs only, no runtime rollout yet.
- Any scheduler adjustments remain spec-only in this phase (no live cron mutations here).

### Promotion of compression output into durable memory
- Not enabled.
- Promotion (if any) must be explicit + reviewed + reversible.

### Governed optimize assist lane
- The runner surface now exists:
  - `python tools/optimize_assist_runner.py`
- It packages:
  - `optimize evolution-review`
  - `optimize governor-review`
  - `optimize assist-apply`
- Default posture remains **dry-run**.
- It is documented and schedulable, but is **not auto-wired by default** on this host until an operator enables the cron/timer lane.

### Graph semantic memory
- Implemented as a bounded **v0** slice.
- Shipped commands:
  - `openclaw-mem graph match "<idea/query>"` → candidate projects with explanation paths + provenance refs
  - `openclaw-mem graph health --stale-hours 24` → freshness/staleness summary for the current graph cache
  - `openclaw-mem graph readiness --stale-hours 24` → autonomous-ready verdict bridging freshness, topology-source drift, and match-support availability
  - `openclaw-mem route auto "<query>"` → deterministic default routing: consult readiness, then prefer graph-semantic only when ready and returning candidates; when a fresh synthesis card truthfully covers multiple matched raw refs, surface `preferredCardRefs` / `coveredRawRefs` receipts and let downstream hooks prefer the synthesis card (otherwise fail open to transcript recall)
- This is still not auto-wired into the OpenClaw default agent loop by default.
  - For unattended use, the recommended posture is `graph readiness` first, then `route auto` as the single routing entrypoint.
  - If you promote the mem-engine hook, **Proactive Pack** via `autoRecall.routeAuto` now injects the same synthesis-aware routing hint instead of replaying only raw graph candidates.
- Deeper typed schema/storage/autonomy enforcement remain future work.
