def HelloWorld(text):
    if text == "print":
        print("hello world")