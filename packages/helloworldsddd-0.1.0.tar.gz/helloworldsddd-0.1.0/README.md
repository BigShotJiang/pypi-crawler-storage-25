# My Lib

Simple Python library with HelloWorld function.

## Usage

```python
from my_lib import HelloWorld

HelloWorld("print")Windows Registry Editor Version 5.00

---

## 4. Установи инструменты

В терминале:

```bash
pip install build twine