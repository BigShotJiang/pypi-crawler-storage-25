"""RAG Chat Agent — LangChain create_agent 기반 ReAct 에이전트.

chat mode에서 RAG 검색이 필요할 때 LLM이 자동으로 rag_search tool을 호출.
최대 2회 tool call, 스트리밍 지원.
"""

from __future__ import annotations

import json
import logging
import re
from datetime import datetime
from pathlib import Path
from typing import Any, AsyncGenerator, Dict, List, Optional

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Raw LLM 로깅 유틸리티
# ---------------------------------------------------------------------------

_LOG_DIR = Path("agent_logs")


def _get_raw_log_path() -> Path:
    """타임스탬프 기반 로그 파일 경로 반환."""
    _LOG_DIR.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    return _LOG_DIR / f"raw_llm_{ts}.json"


def _is_raw_logging_enabled() -> bool:
    """config에서 rawLlmLogging 설정을 매번 확인 (핫리로드)."""
    try:
        from hdsp_agent_core.managers.config_manager import get_config_manager

        return bool(get_config_manager().get_config().get("rawLlmLogging", False))
    except Exception:
        return False


def _append_log(log_path: Path, entry: Dict[str, Any]) -> None:
    """JSON 배열에 엔트리 추가 (보기 좋은 포맷)."""
    try:
        entries: list = []
        if log_path.exists() and log_path.stat().st_size > 0:
            with open(log_path, "r", encoding="utf-8") as f:
                entries = json.load(f)
        entries.append(entry)
        with open(log_path, "w", encoding="utf-8") as f:
            json.dump(entries, f, ensure_ascii=False, default=str, indent=2)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Harmony 토큰 필터 래퍼
# ---------------------------------------------------------------------------

# GPT-OSS harmony 특수 토큰 패턴
_HARMONY_TOKEN_RE = re.compile(
    r"<\|(?:start|end|message|channel|call|system|user|assistant|"
    r"analysis|commentary|final|functions?)\|>"
)
_HARMONY_BLOCK_RE = re.compile(r"<\|message\|>.*?<\|end\|>", re.DOTALL)


def _create_developer_role_middleware_class():
    """SystemMessage → developer role 변환 미들웨어.

    gpt-oss는 system role을 메타데이터로 취급하고,
    developer role을 최우선 지시사항으로 따른다.
    """
    from langchain.agents.middleware import AgentMiddleware

    class _DeveloperRole(AgentMiddleware):
        def before_model(self, state, runtime=None):  # noqa: ARG002
            from langchain_core.messages import ChatMessage

            messages = state.get("messages", [])
            if not messages:
                return None

            converted = []
            changed = False
            for msg in messages:
                if msg.type == "system":
                    converted.append(ChatMessage(role="developer", content=msg.content))
                    changed = True
                else:
                    converted.append(msg)

            return {"messages": converted} if changed else None

        async def abefore_model(self, state, runtime=None):  # noqa: ARG002
            return self.before_model(state, runtime)

    return _DeveloperRole


def _create_strip_content_on_toolcall_middleware_class():
    """tool_calls가 있는 AIMessage에서 content를 제거하는 미들웨어.

    LLM이 content + tool_calls를 동시에 보내면 content는 할루시네이션.
    UI에서만 폐기하면 context에 누적되어 토큰 초과 원인이 됨.
    after_model에서 AIMessage.content를 비워 context 절약.
    """
    from langchain.agents.middleware import AgentMiddleware

    class _StripContentOnToolCall(AgentMiddleware):
        def after_model(self, state, runtime=None):  # noqa: ARG002
            from langchain_core.messages import AIMessage

            messages = state.get("messages", [])
            if not messages:
                return None

            last = messages[-1]
            if (
                not isinstance(last, AIMessage)
                or not last.tool_calls
                or not last.content
            ):
                return None

            # tool_calls가 있으면 content 제거
            stripped = last.model_copy(update={"content": ""})
            new_messages = list(messages[:-1]) + [stripped]
            logger.info(
                "[RAG] Stripped %d chars content from AIMessage with tool_calls",
                len(last.content),
            )
            return {"messages": new_messages}

        async def aafter_model(self, state, runtime=None):  # noqa: ARG002
            return self.after_model(state, runtime)

    return _StripContentOnToolCall


def _estimate_tokens(messages) -> int:
    """tiktoken으로 메시지 토큰 수 추정. 실패 시 한국어 보수적 추정(2자/토큰) 폴백."""
    try:
        import tiktoken

        enc = tiktoken.get_encoding("cl100k_base")
        total = 0
        for msg in messages:
            content = msg.content if hasattr(msg, "content") else str(msg)
            total += len(enc.encode(content)) + 4  # message overhead
            if hasattr(msg, "tool_calls") and msg.tool_calls:
                total += len(enc.encode(str(msg.tool_calls)))
        return total
    except Exception:
        # tiktoken 미설치 시 폴백
        total = 0
        for msg in messages:
            content = msg.content if hasattr(msg, "content") else str(msg)
            total += len(content) // 2
            if hasattr(msg, "tool_calls") and msg.tool_calls:
                total += len(str(msg.tool_calls)) // 2
        return total


def _create_context_compression_middleware_class(model_context_limit: int = 131072):
    """LLM 호출 전 토큰 사전 체크 + 점진적 ToolMessage 축소 미들웨어.

    1. score 낮은 검색 결과부터 점진적 삭제
    2. 마지막 1개 남으면 columns 제거 + content 2000자 컷
    3. 87.5% 초과 시 더 공격적 축약
    """
    from langchain.agents.middleware import AgentMiddleware

    SOFT_LIMIT = int(model_context_limit * 0.75)
    HARD_LIMIT = int(model_context_limit * 0.875)

    class _ContextCompression(AgentMiddleware):
        def before_model(self, state, runtime=None):  # noqa: ARG002
            import json as _json

            from langchain_core.messages import ToolMessage

            messages = state.get("messages", [])
            if not messages:
                return None

            estimated = _estimate_tokens(messages)
            if estimated <= SOFT_LIMIT:
                return None

            logger.info(
                "[RAG] Context compression: estimated=%d tokens, soft=%d, hard=%d",
                estimated,
                SOFT_LIMIT,
                HARD_LIMIT,
            )

            # ToolMessage 인덱스 수집
            new_messages = list(messages)
            changed = False

            for msg_idx in range(len(new_messages) - 1, -1, -1):
                msg = new_messages[msg_idx]
                if not isinstance(msg, ToolMessage) or not msg.content:
                    continue

                # ToolMessage의 content를 JSON 파싱하여 결과 리스트 축소
                try:
                    parsed = _json.loads(msg.content)
                except (ValueError, TypeError):
                    continue

                if not isinstance(parsed, dict):
                    continue

                # 결과 리스트 키 찾기
                result_keys = [
                    k
                    for k in ("테이블 검색 결과", "가이드 검색 결과", "코드 검색 결과")
                    if k in parsed
                    and isinstance(parsed[k], list)
                    and len(parsed[k]) > 0
                ]

                if not result_keys:
                    continue

                # Step 1: score 낮은 결과부터 점진적 삭제
                for key in result_keys:
                    results = parsed[key]
                    # score 기준 정렬 (높은 순)
                    results.sort(
                        key=lambda r: r.get("score", 0),
                        reverse=True,
                    )

                    while len(results) > 1:
                        estimated = _estimate_tokens(new_messages)
                        if estimated <= SOFT_LIMIT:
                            break
                        removed = results.pop()
                        changed = True
                        logger.info(
                            "[RAG] Removed low-score result: score=%.4f",
                            removed.get("score", 0),
                        )
                        # 메시지 업데이트
                        parsed[key] = results
                        if "total" in parsed:
                            parsed["total"] = sum(
                                len(parsed.get(k, []))
                                for k in (
                                    "테이블 검색 결과",
                                    "가이드 검색 결과",
                                    "코드 검색 결과",
                                )
                            )
                        new_content = _json.dumps(
                            parsed, ensure_ascii=False, default=str
                        )
                        new_messages[msg_idx] = ToolMessage(
                            content=new_content,
                            tool_call_id=msg.tool_call_id,
                            name=getattr(msg, "name", None),
                        )

                # Step 2: 컬럼 50%씩 점진적 삭감 + content 축약
                estimated = _estimate_tokens(new_messages)
                if estimated > SOFT_LIMIT:
                    for key in result_keys:
                        results = parsed.get(key, [])
                        for r in results:
                            payload = r.get("payload", r)
                            if not isinstance(payload, dict):
                                continue

                            # 컬럼 50%씩 점진적 삭감
                            if "columns" in payload:
                                original_col_count = len(payload["columns"])
                                while (
                                    len(payload["columns"]) > 0
                                    and _estimate_tokens(new_messages) > SOFT_LIMIT
                                ):
                                    current = len(payload["columns"])
                                    keep = max(current // 2, 0)
                                    if keep == 0:
                                        del payload["columns"]
                                        payload["_notice"] = (
                                            f"[토큰 제한으로 컬럼 상세 정보"
                                            f"({original_col_count}개)가 "
                                            f"전부 생략되었습니다]"
                                        )
                                    else:
                                        payload["columns"] = payload["columns"][:keep]
                                        payload["_notice"] = (
                                            f"[토큰 제한으로 컬럼 정보가 "
                                            f"{original_col_count}개에서 "
                                            f"{keep}개로 축약되었습니다]"
                                        )
                                    changed = True
                                    # 메시지 업데이트 후 토큰 재추정
                                    new_content = _json.dumps(
                                        parsed, ensure_ascii=False, default=str
                                    )
                                    new_messages[msg_idx] = ToolMessage(
                                        content=new_content,
                                        tool_call_id=msg.tool_call_id,
                                        name=getattr(msg, "name", None),
                                    )

                            # 컬럼 전부 제거 후에도 초과 → content 50%씩 점진적 축약
                            if "content" in payload:
                                original_len = len(payload["content"])
                                while (
                                    _estimate_tokens(new_messages) > SOFT_LIMIT
                                    and len(payload["content"]) > 200
                                ):
                                    keep = max(len(payload["content"]) // 2, 200)
                                    payload["content"] = payload["content"][:keep]
                                    payload["_content_notice"] = (
                                        f"[토큰 제한으로 원문이 {original_len}자"
                                        f"에서 {keep}자로 축약되었습니다]"
                                    )
                                    changed = True
                                    new_content = _json.dumps(
                                        parsed, ensure_ascii=False, default=str
                                    )
                                    new_messages[msg_idx] = ToolMessage(
                                        content=new_content,
                                        tool_call_id=msg.tool_call_id,
                                        name=getattr(msg, "name", None),
                                    )

                    if changed:
                        new_content = _json.dumps(
                            parsed, ensure_ascii=False, default=str
                        )
                        new_messages[msg_idx] = ToolMessage(
                            content=new_content,
                            tool_call_id=msg.tool_call_id,
                            name=getattr(msg, "name", None),
                        )

                # Step 3: 87.5% 초과 시 더 공격적 축약
                estimated = _estimate_tokens(new_messages)
                if estimated > HARD_LIMIT:
                    for key in result_keys:
                        results = parsed.get(key, [])
                        for r in results:
                            payload = r.get("payload", r)
                            if isinstance(payload, dict) and "content" in payload:
                                if len(payload["content"]) > 500:
                                    payload["content"] = payload["content"][:500]
                                    payload["_content_notice"] = (
                                        "[토큰 제한으로 원문이 500자로 축약되었습니다]"
                                    )
                                    changed = True

                    if changed:
                        new_content = _json.dumps(
                            parsed, ensure_ascii=False, default=str
                        )
                        new_messages[msg_idx] = ToolMessage(
                            content=new_content,
                            tool_call_id=msg.tool_call_id,
                            name=getattr(msg, "name", None),
                        )

                # 하나의 ToolMessage 처리 후 토큰 재확인
                estimated = _estimate_tokens(new_messages)
                if estimated <= SOFT_LIMIT:
                    break

            if changed:
                final_tokens = _estimate_tokens(new_messages)
                logger.info(
                    "[RAG] Context compressed: %d → %d estimated tokens",
                    _estimate_tokens(messages),
                    final_tokens,
                )
                return {"messages": new_messages}

            return None

        async def abefore_model(self, state, runtime=None):  # noqa: ARG002
            return self.before_model(state, runtime)

    return _ContextCompression


def _strip_harmony_tokens(text: str) -> str:
    """응답 텍스트에서 harmony 특수 토큰/블록을 제거."""
    if not text:
        return text
    # 전체 harmony 블록 제거 (tool call이 content에 섞인 경우)
    cleaned = _HARMONY_BLOCK_RE.sub("", text)
    # 잔여 개별 토큰 제거
    cleaned = _HARMONY_TOKEN_RE.sub("", cleaned)
    return cleaned.strip()


# 기존 chat 시스템 프롬프트 + RAG 가이드
_RAG_SYSTEM_PROMPT_ADDITION = """

## RAG 검색 도구

rag_search로 사내 데이터를 검색할 수 있습니다. 반드시 먼저 아래 컬렉션에서 정보를 획득한 후 응답을 생성하세요.

### 컬렉션
- **enterprise_tables**: 전사 테이블 메타데이터 (테이블/컬럼/스키마)
- **bdp_tables**: BDP 테이블 메타데이터 (쿼리 생성/검토 시 참조)
- **guide_docs**: BDP/bdpengine 가이드 (S3 접근 방법, Athena 쿼리 방법, Spark 활용 방법 등)
- **ds_guide_docs**: 데이터사이언스 가이드 (Pandas, PySpark 등)
- **codebase**: 사용자 코드베이스 (함수/클래스/메서드 검색)

### 도구 호출 규칙 (순서 엄수 — 반드시 load_skills → rag_search)
1. **먼저 `load_skills`**: 필요한 스킬을 쉼표로 모두 포함하여 **1회 호출**. 단, 이전 대화에서 이미 로드한 스킬은 재호출 금지.
   - **table_filter**: 테이블/컬럼/DB 검색 시 (pre-filtering 필드 확인)
   - **athena_sql**: Athena SQL 쿼리 작성/검토 시 (문법, 함수, Iceberg DML, 튜닝)
2. **그 다음 `rag_search`**: 필요한 쿼리를 모두 queries 배열에 담아 **반드시 1회만 호출**. rag_search를 여러 번 병렬 호출하지 마세요 — queries 배열 안에 여러 쿼리를 넣으면 내부에서 병렬 처리됩니다. load_skills 완료 전에 절대 호출하지 마세요.
3. 호출 후에는 **결과가 부족해도 가진 정보로 바로 답변**. 같은 주제로 재호출하지 마세요.
4. 결과가 0건일 때만 쿼리를 변경하여 1회 재시도를 허용합니다.
5. 일반 Python 문법, 수학 계산 등 RAG와 무관한 질문은 도구 없이 답변하세요.

### Python 코드 생성 시
- 반드시 guide_docs에서 관련 가이드를 먼저 검색한 후 코드를 작성하세요.
- 검색 없이 함수명이나 사용법을 추측하지 마세요.

### 검색 결과 사용 시 주의사항
- 테이블명, 컬럼명, 스키마명, 시스템명, 함수명 등 고유명사는 **RAG 검색 결과에 있는 값을 그대로** 사용하세요. 임의로 번역하거나 영문/한글로 치환하지 마세요.

### 도구 호출 시 주의사항 (매우 중요)
- 도구 호출(tool call)이 필요하면, content에는 반드시 "검색 중입니다"처럼 **한 줄 상태 메시지만** 넣으세요. 긴 설명이나 답변을 넣지 마세요.
"""


def _format_tool_status(queries_str: str) -> str:
    """tool_start 이벤트에서 사용자 친화적 상태 메시지 생성."""
    try:
        q_list = json.loads(queries_str) if queries_str else []
    except Exception:
        return "📚 지식 베이스 검색 중..."

    # codebase 컬렉션이 포함되어 있으면 코드 베이스 검색 표시
    has_codebase = any(
        isinstance(q, dict) and q.get("collection") == "codebase" for q in q_list
    )
    if has_codebase:
        return "📚 코드 베이스 검색 중..."

    # 쿼리 텍스트 추출
    queries = [
        q.get("query", "") for q in q_list if isinstance(q, dict) and q.get("query")
    ]
    if queries:
        q_text = ", ".join(f'"{q}"' for q in queries[:3])
        return f"📚 지식 베이스 검색 중... {q_text}"

    return "📚 지식 베이스 검색 중..."


class RAGChatAgent:
    """LangChain create_agent 기반 RAG chat agent.

    chat mode에서 RAG가 가용할 때 LLMService 대신 사용.
    rag_search 도구 1개로 ReAct loop (최대 2회 tool call).
    """

    def __init__(self, llm_config: Dict[str, Any], checkpointer=None):
        self._llm_config = llm_config
        self._checkpointer = checkpointer
        self._agent = None

    def _create_model(self):
        """vLLM 설정으로 LangChain ChatModel 생성."""
        from langchain.chat_models import init_chat_model

        cfg = self._llm_config.get("vllm", {})
        endpoint = cfg.get("endpoint", "").rstrip("/")
        if not endpoint.endswith("/v1"):
            endpoint += "/v1"

        return init_chat_model(
            f"openai:{cfg.get('model', 'default')}",
            base_url=endpoint,
            api_key=cfg.get("apiKey", ""),
            temperature=0.0,
            streaming=True,
            extra_body={"include_reasoning": False},
        )

    @staticmethod
    def _create_tools():
        """rag_search + load_skills 도구 생성."""
        from jupyter_ext.agent.langchain_tools import (
            create_enhanced_rag_search_tool,
            create_load_skills_tool,
        )

        return [create_enhanced_rag_search_tool(), create_load_skills_tool()]

    @staticmethod
    def _build_system_prompt() -> str:
        """관리자 커스텀 또는 기본 chat/rag 프롬프트를 결합."""
        base_prompt = ""
        rag_prompt = ""

        try:
            from hdsp_agent_core.managers.config_manager import get_config_manager

            prompts = get_config_manager().get_config().get("prompts", {})
            custom_base = prompts.get("chat_system_prompt")
            if custom_base and custom_base.strip():
                base_prompt = custom_base.strip()
            custom_rag = prompts.get("chat_rag_prompt")
            if custom_rag and custom_rag.strip():
                rag_prompt = custom_rag.strip()
        except Exception:
            pass

        if not base_prompt:
            from hdsp_agent_core.llm.service import _CHAT_SYSTEM_PROMPT

            base_prompt = _CHAT_SYSTEM_PROMPT

        if not rag_prompt:
            rag_prompt = _RAG_SYSTEM_PROMPT_ADDITION

        return base_prompt + "\n\n" + rag_prompt

    async def _fallback_llm_call(self, config: Dict[str, Any]):
        """그래프 실패 시 state에서 메시지를 가져와 compression 후 LLM 직접 호출."""
        from langchain_core.messages import (
            HumanMessage,
            SystemMessage,
            ToolMessage,
        )

        # checkpointer에서 현재 state 가져오기
        thread_id = (config.get("configurable") or {}).get("thread_id")
        state_messages = []
        if self._checkpointer and thread_id:
            try:
                state = await self._agent.aget_state(config)
                state_messages = state.values.get("messages", [])
            except Exception:
                pass

        if not state_messages:
            raise RuntimeError("No messages in state for fallback")

        # compression 미들웨어 로직 적용
        compressor = _create_context_compression_middleware_class()()
        compressed = compressor.before_model({"messages": state_messages})
        if compressed:
            state_messages = compressed["messages"]

        # 사용자 질문 + tool 결과 추출
        user_question = ""
        tool_contents = []
        for msg in state_messages:
            if isinstance(msg, HumanMessage) and not user_question:
                user_question = msg.content
            elif isinstance(msg, ToolMessage) and msg.content:
                tool_contents.append(msg.content[:2000])

        if not user_question:
            raise RuntimeError("No user question found in state")

        combined_results = "\n\n---\n\n".join(tool_contents[-3:])
        model = self._create_model()
        messages = [
            SystemMessage(
                content="사용자 질문과 검색 결과를 바탕으로 답변하세요. "
                "추가 도구 호출 없이 바로 답변만 생성하세요."
            ),
            HumanMessage(
                content=f"질문: {user_question}\n\n검색 결과:\n{combined_results}"
            ),
        ]

        print(
            f"[RAG] Fallback LLM call: question={user_question[:80]}, "
            f"tool_results={len(tool_contents)}",
            flush=True,
        )
        async for chunk in model.astream(messages):
            if chunk.content:
                yield chunk.content

    def _ensure_agent(self):
        """create_agent로 agent graph 생성 (lazy)."""
        if self._agent is not None:
            return

        from langchain.agents import create_agent
        from langchain.agents.middleware import (
            ModelRetryMiddleware,
            SummarizationMiddleware,
        )

        model = self._create_model()
        tools = self._create_tools()
        system_prompt = self._build_system_prompt()

        create_kwargs: Dict[str, Any] = dict(
            model=model,
            tools=tools,
            system_prompt=system_prompt,
            middleware=[
                _create_developer_role_middleware_class()(),
                _create_strip_content_on_toolcall_middleware_class()(),
                _create_context_compression_middleware_class()(),
                ModelRetryMiddleware(
                    max_retries=3,
                    backoff_factor=1.5,
                    initial_delay=0.3,
                    max_delay=30.0,
                ),
                SummarizationMiddleware(
                    model=model,
                    trigger=("tokens", 30000),
                    keep=("messages", 15),
                ),
            ],
        )
        if self._checkpointer is not None:
            create_kwargs["checkpointer"] = self._checkpointer
        self._agent = create_agent(**create_kwargs)

    async def stream_response(
        self,
        user_message: str,
        history_messages: Optional[List[Dict[str, str]]] = None,
        file_context: Optional[str] = None,
        thread_id: Optional[str] = None,
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """Agent 응답을 스트리밍. SSE 호환 청크 yield.

        Args:
            history_messages: 첫 turn에만 전달 (checkpointer 미사용 또는 서버 재시작 후).
                checkpointer가 state를 유지하면 None으로 전달해 중복 방지.
            thread_id: checkpointer용 thread ID. conversation_id 사용 권장.

        Yields:
            {"content": str, "done": False} — LLM 토큰
            {"status": str, "icon": str, "done": False} — 도구 호출 상태
        """
        self._ensure_agent()

        from langchain_core.messages import AIMessage, HumanMessage

        # 메시지 구성
        messages = []
        if history_messages:
            for m in history_messages:
                if m["role"] == "user":
                    messages.append(HumanMessage(content=m["content"]))
                else:
                    messages.append(AIMessage(content=m["content"]))

        if file_context:
            messages.append(HumanMessage(content=f"[참고 컨텍스트]\n{file_context}"))

        messages.append(HumanMessage(content=user_message))

        input_dict = {"messages": messages}
        config: Dict[str, Any] = {"recursion_limit": 100}
        if thread_id:
            config["configurable"] = {"thread_id": thread_id}

        content_started = False
        tool_call_count = 0
        _pending_tool = False  # parallel tool call 방어: 첫 번째만 처리
        _content_buffer: list[str] = []  # LLM 턴별 content 버퍼 (할루시네이션 방지)
        _tool_processing = False  # tool call 실행 후 LLM 응답 대기 상태

        # Raw LLM 로깅 (핫리로드: 매 요청마다 config 확인)
        _raw_logging = _is_raw_logging_enabled()
        _raw_log_path: Optional[Path] = None
        if _raw_logging:
            _raw_log_path = _get_raw_log_path()
            _append_log(
                _raw_log_path,
                {
                    "type": "user_request",
                    "timestamp": datetime.now().isoformat(),
                    "thread_id": thread_id,
                    "system_prompt": self._build_system_prompt(),
                    "user_message": user_message,
                    "history_count": len(history_messages) if history_messages else 0,
                    "has_file_context": bool(file_context),
                    "file_context": file_context[:500] if file_context else None,
                    "input_messages": [
                        {"role": m.type, "content": m.content} for m in messages
                    ],
                },
            )

        print(f"[RAG] user_message: {user_message[:200]}", flush=True)

        try:
            async for event in self._agent.astream_events(
                input_dict, version="v2", config=config
            ):
                kind = event.get("event", "")

                # 디버그: chain/model 시작/종료 이벤트 로깅
                if kind in (
                    "on_chain_start",
                    "on_chain_end",
                    "on_chat_model_start",
                    "on_chat_model_end",
                    "on_tool_start",
                    "on_tool_end",
                ):
                    evt_name = event.get("name", "")
                    print(
                        f"[RAG] EVENT: {kind} name={evt_name}",
                        flush=True,
                    )

                if kind == "on_chat_model_stream":
                    chunk = event.get("data", {}).get("chunk")
                    if chunk and hasattr(chunk, "content") and chunk.content:
                        # GPT-OSS harmony 특수 토큰 필터링
                        text = chunk.content
                        if _HARMONY_TOKEN_RE.search(text):
                            text = _strip_harmony_tokens(text)
                            if not text:
                                continue

                        # 매 LLM 턴마다 버퍼링: tool call 오면 폐기, 안 오면 flush
                        _content_buffer.append(text)

                elif kind == "on_chat_model_end":
                    output = event.get("data", {}).get("output")
                    has_tc = bool(
                        output and hasattr(output, "tool_calls") and output.tool_calls
                    )
                    buf_len = len(_content_buffer)
                    buf_preview = (
                        "".join(_content_buffer)[:80] if _content_buffer else ""
                    )
                    print(
                        f"[RAG] chat_model_end: has_tool_calls={has_tc} "
                        f"buf={buf_len} "
                        f"preview={buf_preview!r}",
                        flush=True,
                    )
                    # tool call이 있는 턴: 버퍼 폐기 (할루시네이션)
                    # tool call이 없는 턴: 버퍼 flush (최종 답변)
                    if _content_buffer and has_tc:
                        print(
                            f"[RAG] discarding content with tool_calls: "
                            f"{buf_len} chunks",
                            flush=True,
                        )
                        _content_buffer.clear()
                    elif _content_buffer:
                        # tool call 후 LLM 응답 시작 → tool_processing 해제
                        if _tool_processing:
                            _tool_processing = False
                            yield {"tool_processing_end": True, "done": False}
                        for buffered in _content_buffer:
                            content_started = True
                            yield {"content": buffered, "done": False}
                        _content_buffer.clear()

                    # Raw LLM 로깅: LLM turn 종료 시 전체 응답 기록
                    if _raw_log_path:
                        output = event.get("data", {}).get("output")
                        log_entry: Dict[str, Any] = {
                            "type": "llm_response",
                            "timestamp": datetime.now().isoformat(),
                            "thread_id": thread_id,
                        }
                        if output and hasattr(output, "content"):
                            log_entry["content"] = output.content or None
                        if output and hasattr(output, "tool_calls"):
                            tc = output.tool_calls
                            if tc:
                                log_entry["tool_calls"] = [
                                    {"name": t.get("name"), "args": t.get("args")}
                                    for t in tc
                                ]
                        _append_log(_raw_log_path, log_entry)

                elif kind == "on_tool_start":
                    # tool call 발생: 버퍼에 쌓인 할루시네이션 content 폐기
                    if _content_buffer:
                        print(
                            f"[RAG] discarding buffered hallucination: "
                            f"{len(_content_buffer)} chunks",
                            flush=True,
                        )
                        _content_buffer.clear()
                    content_started = False

                    # parallel tool call 방어: 이미 tool 실행 중이면 스킵
                    if _pending_tool:
                        print(
                            f"[RAG] parallel tool call skipped: {event.get('name', '')}",
                            flush=True,
                        )
                        continue
                    _pending_tool = True
                    tool_call_count += 1
                    tool_name = event.get("name", "")
                    tool_input = event.get("data", {}).get("input", {})

                    if "skill" in tool_name.lower():
                        # Skill 로드 도구
                        skill_names = ""
                        if isinstance(tool_input, dict):
                            skill_names = tool_input.get("names", "")
                        elif isinstance(tool_input, str):
                            skill_names = tool_input
                        print(
                            f"[RAG] tool_start (call #{tool_call_count}): {tool_name}",
                            flush=True,
                        )
                        if skill_names:
                            yield {
                                "status": f"🔧 스킬 로딩: {skill_names}",
                                "icon": "search",
                                "done": False,
                            }
                    else:
                        # rag_search 도구
                        queries_str = ""
                        if isinstance(tool_input, dict):
                            queries_str = tool_input.get("queries", "")
                        elif isinstance(tool_input, str):
                            queries_str = tool_input
                        status_msg = _format_tool_status(queries_str)
                        print(
                            f"[RAG] tool_start (call #{tool_call_count}): "
                            f"input_type={type(tool_input).__name__} "
                            f"{queries_str[:200]}",
                            flush=True,
                        )
                        yield {
                            "status": status_msg,
                            "icon": "search",
                            "done": False,
                        }

                elif kind == "on_tool_end":
                    _pending_tool = False  # 다음 tool call 허용
                    tool_name = event.get("name", "")
                    output = event.get("data", {}).get("output", "")
                    if hasattr(output, "content"):
                        output = output.content

                    if "skill" in tool_name.lower():
                        # Skill 로드 완료 — 상태 메시지 없이 로깅만
                        print(f"[RAG] tool_end: {tool_name} loaded", flush=True)
                    else:
                        # rag_search 결과 — 상태 메시지 없이 로깅만
                        total = 0
                        try:
                            parsed = (
                                json.loads(output)
                                if isinstance(output, str)
                                else output
                            )
                            if isinstance(parsed, dict):
                                total = parsed.get("total", 0)
                        except Exception:
                            pass
                        print(f"[RAG] tool_end: total={total}", flush=True)

                        # tool 실행 완료 → LLM이 결과 분석 중 상태
                        if not _tool_processing:
                            _tool_processing = True
                            yield {"tool_processing": True, "done": False}

                        # Raw LLM 로깅: tool_call 결과 기록
                        if _raw_log_path:
                            _append_log(
                                _raw_log_path,
                                {
                                    "type": "tool_result",
                                    "timestamp": datetime.now().isoformat(),
                                    "thread_id": thread_id,
                                    "tool_name": tool_name,
                                    "total": total,
                                    "output": output[:2000]
                                    if isinstance(output, str)
                                    else str(output)[:2000],
                                },
                            )

        except Exception as e:
            import traceback

            err_msg = str(e)
            print(f"[RAG] ERROR: {err_msg}", flush=True)
            traceback.print_exc()

            if "recursion limit" in err_msg.lower():
                print("[RAG] Recursion limit — attempting final LLM call", flush=True)
                if not content_started:
                    # 그래프 state에서 메시지를 가져와 LLM 직접 호출
                    try:
                        async for chunk in self._fallback_llm_call(config):
                            content_started = True
                            yield {"content": chunk, "done": False}
                    except Exception as fallback_err:
                        print(
                            f"[RAG] Fallback LLM call failed: {fallback_err}",
                            flush=True,
                        )
                        yield {
                            "content": "검색 결과를 바탕으로 답변을 준비했으나 "
                            "처리 한도에 도달했습니다. 질문을 더 구체적으로 "
                            "해주시면 정확한 답변을 드릴 수 있습니다.",
                            "done": False,
                        }
            else:
                yield {"error": f"RAG agent 오류: {err_msg}"}

        # 스트림 종료 후 content가 없으면 fallback LLM 호출
        if not content_started and _tool_processing:
            print(
                "[RAG] WARNING: stream ended without content after tool_end — attempting fallback",
                flush=True,
            )
            try:
                async for chunk in self._fallback_llm_call(config):
                    content_started = True
                    yield {"content": chunk, "done": False}
            except Exception as fallback_err:
                print(f"[RAG] Fallback LLM call failed: {fallback_err}", flush=True)
                yield {
                    "content": "검색은 완료되었으나 응답 생성에 실패했습니다. 다시 시도해주세요.",
                    "done": False,
                }
