## Typing stubs for ibm-db

This is a [type stub package](https://typing.python.org/en/latest/tutorials/external_libraries.html)
for the [`ibm-db`](https://github.com/ibmdb/python-ibmdb) package. It can be used by type checkers
to check code that uses `ibm-db`. This version of
`types-ibm-db` aims to provide accurate annotations for
`ibm-db==3.2.9`.

This package is part of the [typeshed project](https://github.com/python/typeshed).
All fixes for types and metadata should be contributed there.
See [the README](https://github.com/python/typeshed/blob/main/README.md)
for more details. The source for this package can be found in the
[`stubs/ibm-db`](https://github.com/python/typeshed/tree/main/stubs/ibm-db)
directory.

This package was tested with the following type checkers:
* [mypy](https://github.com/python/mypy/) 2.1.0
* [pyright](https://github.com/microsoft/pyright) 1.1.409

It was generated from typeshed commit
[`526a7ddb7869b9dca22cde37c5775f734cfbfe44`](https://github.com/python/typeshed/commit/526a7ddb7869b9dca22cde37c5775f734cfbfe44).