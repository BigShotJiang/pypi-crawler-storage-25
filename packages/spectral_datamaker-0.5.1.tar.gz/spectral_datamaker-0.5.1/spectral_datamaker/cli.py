"""Console entry points for SpectralDatamaker."""

import json
import os
import sys

import click
import yaml

from .config import ConfigLoader
from .config import ComposeConfigLoader
from .dataset import DatasetStructure, DatasetValidator
from .processors import (
    MetadataProcessor,
    PixelMasking,
    ROIMasking,
    SegmentationCrop,
    StructureProcessor,
    ComposeProcessor,
)

from ._version import __version__


@click.group()
@click.version_option(version=__version__, prog_name="spectral-datamaker")
def cli():
    """SpectralDatamaker - Create datasets from hyperspectral images."""


@cli.command()
@click.argument("config_file", type=click.Path(exists=True))
@click.argument("output_dir", type=click.Path())
@click.option("--dry-run", is_flag=True, help="Validate configuration without executing")
@click.option("--skip-validation", is_flag=True, help="Skip final dataset validation")
@click.option("--no-interactive", is_flag=True, help="Skip interactive mask adjustment (napari)")
def create(config_file, output_dir, dry_run, skip_validation, no_interactive):
    """Create a complete dataset from a configuration file.

    CONFIG_FILE: Path to the YAML configuration file
    OUTPUT_DIR: Directory where the dataset will be created
    """
    try:
        click.echo(f"Loading configuration from: {config_file}")
        config = ConfigLoader.get_config(config_file)

        click.echo(f"Dataset: {config.name}")
        click.echo(f"Description: {config.description}")
        click.echo(f"Source images: {len(config.source_images)}")

        if dry_run:
            click.echo("\nConfiguration is valid (dry-run mode)")
            return

        if no_interactive:
            click.echo("\nWarning: --no-interactive mode not yet supported")
            click.echo("Interactive mask adjustment will be required")

        dataset_structure = DatasetStructure(output_dir)

        click.echo(f"\nCreating dataset structure at: {output_dir}")
        StructureProcessor(config, dataset_structure).process()
        click.echo("Structure created")

        click.echo("\nGenerating ROI masks...")
        ROIMasking(config, dataset_structure).process()
        click.echo("ROI masks generated")

        click.echo("\nGenerating pixel masks...")
        PixelMasking(config, dataset_structure).process()
        click.echo("Pixel masks generated")

        click.echo("\nCropping images...")
        SegmentationCrop(config, dataset_structure).process()
        click.echo("Images cropped")

        click.echo("\nGenerating metadata...")
        MetadataProcessor(config, dataset_structure).process()
        click.echo("Metadata generated")

        if not skip_validation:
            click.echo("\nValidating dataset...")
            validator = DatasetValidator(dataset_structure)
            validator.validate_dataset_from_config(config_file)
            click.echo("Dataset validated successfully")

        click.echo(f"\nDataset created successfully at: {output_dir}")

    except FileNotFoundError as exc:
        click.echo(f"\nError: {exc}", err=True)
        sys.exit(1)
    except ValueError as exc:
        click.echo(f"\nConfiguration error: {exc}", err=True)
        sys.exit(1)
    except Exception as exc:
        click.echo(f"\nUnexpected error: {exc}", err=True)
        sys.exit(1)


@cli.command()
@click.argument("dataset_dir", type=click.Path(exists=True))
@click.option("--config", "config_file", type=click.Path(exists=True), help="Validate against specific config file")
@click.option("--strict", is_flag=True, help="Strict validation mode")
def validate(dataset_dir, config_file, strict):
    """Validate an existing dataset structure and contents.

    DATASET_DIR: Path to the dataset directory to validate
    """
    try:
        click.echo(f"Validating dataset: {dataset_dir}")

        dataset_structure = DatasetStructure(dataset_dir)
        validator = DatasetValidator(dataset_structure)

        if config_file:
            click.echo(f"Using configuration: {config_file}")
            validator.validate_dataset_from_config(config_file)
        else:
            click.echo("Using metadata file")
            validator.validate_dataset_from_metadata()

        click.echo("\nDataset validation passed!")
        click.echo(f"   Dataset location: {dataset_dir}")

    except FileNotFoundError as exc:
        click.echo(f"\nValidation failed: {exc}", err=True)
        sys.exit(1)
    except Exception as exc:
        click.echo(f"\nValidation error: {exc}", err=True)
        sys.exit(1)


@cli.command()
@click.argument("dataset_dir", type=click.Path(exists=True))
@click.option("--format", "output_format", type=click.Choice(["json", "yaml", "table"]), default="table", help="Output format")
@click.option("--show-images", is_flag=True, help="List processed images")
def inspect(dataset_dir, output_format, show_images):
    """Inspect dataset metadata and statistics.

    DATASET_DIR: Path to the dataset directory to inspect
    """
    try:
        dataset_structure = DatasetStructure(dataset_dir)
        metadata_path = dataset_structure.metadata_file

        if not os.path.exists(metadata_path):
            click.echo(f"Metadata file not found: {metadata_path}", err=True)
            sys.exit(1)

        with open(metadata_path, "r", encoding="utf-8") as file_handle:
            metadata = json.load(file_handle)

        if output_format == "json":
            click.echo(json.dumps(metadata, indent=2))
        elif output_format == "yaml":
            click.echo(yaml.dump(metadata, default_flow_style=False))
        else:
            click.echo("\n" + "=" * 60)
            click.echo(f"Dataset: {metadata.get('name', 'N/A')}")
            click.echo("=" * 60)
            click.echo(f"Description: {metadata.get('description', 'N/A')}")
            click.echo(f"Last update: {metadata.get('last_update', 'N/A')}")
            click.echo(f"  Types: {', '.join(metadata.get('types', []))}")
            click.echo(f"  Source images: {len(metadata.get('source_images', []))}")

            if "segmentation_masking" in metadata:
                click.echo("\nSegmentation Data:")
                seg_data = metadata["segmentation_masking"]
                for img_key, img_data in seg_data.items():
                    click.echo(f"\n  Image: {img_data.get('source_image', img_key)}")
                    click.echo(f"    Classes: {len(img_data.get('classes', []))}")
                    click.echo(f"    Class names: {', '.join(img_data.get('classes', []))}")
                    if "assignments" in img_data:
                        for class_name, roi_indices in img_data["assignments"].items():
                            click.echo(f"      {class_name}: {len(roi_indices)} ROIs")

            if show_images:
                click.echo("\nProcessed Images:")
                images_dir = dataset_structure.images_dir
                if os.path.exists(images_dir):
                    images = sorted([file_name for file_name in os.listdir(images_dir) if not file_name.startswith(".")])
                    for image_name in images:
                        click.echo(f"  - {image_name}")
                    click.echo(f"\n  Total: {len(images)} images")

            click.echo("\n" + "=" * 60)

    except json.JSONDecodeError as exc:
        click.echo(f"Invalid metadata JSON: {exc}", err=True)
        sys.exit(1)
    except Exception as exc:
        click.echo(f"Error inspecting dataset: {exc}", err=True)
        sys.exit(1)


@cli.command()
@click.argument("step_name", type=click.Choice(["structure", "roi-mask", "pixel-mask", "crop", "metadata"]))
@click.argument("config_file", type=click.Path(exists=True))
@click.argument("dataset_dir", type=click.Path())
@click.option("--force", is_flag=True, help="Overwrite existing files")
def step(step_name, config_file, dataset_dir, force):
    """Execute a single step of the dataset creation pipeline.

    STEP_NAME: Name of the step to execute
    CONFIG_FILE: Path to the configuration file
    DATASET_DIR: Dataset directory
    """
    del force

    try:
        click.echo(f"Loading configuration from: {config_file}")
        config = ConfigLoader.get_config(config_file)
        dataset_structure = DatasetStructure(dataset_dir)

        if step_name == "structure":
            click.echo("Creating dataset structure...")
            StructureProcessor(config, dataset_structure).process()
            click.echo("Structure created")

        elif step_name == "roi-mask":
            click.echo("Generating ROI masks...")
            ROIMasking(config, dataset_structure).process()
            click.echo("ROI masks generated")

        elif step_name == "pixel-mask":
            click.echo("Generating pixel masks...")
            PixelMasking(config, dataset_structure).process()
            click.echo("Pixel masks generated")

        elif step_name == "crop":
            click.echo("Cropping images...")
            SegmentationCrop(config, dataset_structure).process()
            click.echo("Images cropped")

        elif step_name == "metadata":
            click.echo("Generating metadata...")
            MetadataProcessor(config, dataset_structure).process()
            click.echo("Metadata generated")

        click.echo(f"\nStep '{step_name}' completed successfully")

    except FileNotFoundError as exc:
        click.echo(f"\nError: {exc}", err=True)
        sys.exit(1)
    except Exception as exc:
        click.echo(f"\nError executing step: {exc}", err=True)
        sys.exit(1)


@cli.command()
@click.argument("config_file", type=click.Path(exists=True))
@click.argument("output_dir", type=click.Path())
@click.option("--dry-run", is_flag=True, help="Validate configuration without copying files")
def compose(config_file, output_dir, dry_run):
    """Compose a new dataset by selecting ROIs from existing datasets.

    CONFIG_FILE: Path to the compose YAML configuration file
    OUTPUT_DIR: Directory where the new dataset will be created
    """
    try:
        click.echo(f"Loading configuration from: {config_file}")
        config = ComposeConfigLoader.get_config(config_file)

        click.echo(f"Dataset: {config.name}")
        click.echo(f"Description: {config.description}")
        click.echo(f"Classes: {', '.join(config.classes)}")
        click.echo(f"Sources: {len(config.sources)}")

        if dry_run:
            click.echo("\nConfiguration is valid (dry-run mode)")
            return

        dataset_structure = DatasetStructure(output_dir)

        click.echo(f"\nComposing dataset at: {output_dir}")
        ComposeProcessor(dataset_structure).process(config)

        click.echo(f"\nDataset composed successfully at: {output_dir}")

    except FileNotFoundError as exc:
        click.echo(f"\nError: {exc}", err=True)
        sys.exit(1)
    except ValueError as exc:
        click.echo(f"\nConfiguration error: {exc}", err=True)
        sys.exit(1)
    except Exception as exc:
        click.echo(f"\nUnexpected error: {exc}", err=True)
        sys.exit(1)