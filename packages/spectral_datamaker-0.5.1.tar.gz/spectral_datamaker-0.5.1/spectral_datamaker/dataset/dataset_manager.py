from ..processors.processor import DatasetConnection
from .dataset_structure import DatasetStructure
from .metadata_structure import DatasetMetadata, SegmentationMetadata
from .metadata_manager import MetadataManager
from .dataset_validator import DatasetValidator

class DatasetManager(DatasetConnection):
    """Manages dataset information, including retrieval of image paths, 
    metadata details and validation.
    """

    def __init__(self, dataset_structure: DatasetStructure):
        super().__init__(dataset_structure)
        self.metadata = MetadataManager(dataset_structure)
        self.validator = DatasetValidator(dataset_structure)

    def get_name(self) -> str:
        """Returns the name of the dataset."""
        return self.metadata.get_name()
    
    def get_description(self) -> str:
        """Returns the description of the dataset."""
        return self.metadata.get_description()
    
    def get_source_image_paths(self, abs=True) -> list:
        """Returns a list of the source images of the dataset."""
        return self.metadata.get_source_images(abs)
    
    def get_last_update(self) -> str:
        """Returns the last update date of the dataset."""
        return self.metadata.get_last_update()
    
    def get_types(self) -> list:
        """Returns a list of the types of the dataset."""
        return self.metadata.get_types()
    
    def get_nmasks_for_image(self, image_name: str) -> int:
        """Returns the number of masks associated with a given source image."""
        return self.metadata.get_nmasks_for_image(image_name)
    
    def get_image_paths(self, abs: bool = True) -> list:
        """Returns a list of the dataset images"""
        images = []
        for image in self.get_source_image_paths(abs=False):
            cropped_images = self.filenames.get_cropped_images(
                source_image=image,
                dataset_name=self.get_name(),
                nmasks = self.get_nmasks_for_image(image),
                abs = abs
            )
            images.extend(cropped_images)
        return images
    
    def get_pixel_mask_paths(self, abs: bool = True) -> list:
        """Returns a list of the dataset pixel masks"""
        masks = []
        for image in self.get_source_image_paths(abs=False):
            cropped_masks = self.filenames.get_cropped_masks(
                source_image=image,
                dataset_name=self.get_name(),
                nmasks = self.get_nmasks_for_image(image),
                abs = abs
            )
            masks.extend(cropped_masks)
        return masks
    
    def get_metadata_path(self, abs=True) -> str:
        """Returns the path to the dataset metadata file."""
        return self.filenames.get_dataset_metadata(abs)
    
    def validate(self) -> bool:
        """Validates the dataset structure and contents."""
        self.validator.validate_dataset_from_metadata()
        return True
    
    def validate_from_config(self, config_file: str) -> bool:
        """Validates the dataset structure and contents based on a configuration file."""
        self.validator.validate_dataset_from_config(config_file)
        return True