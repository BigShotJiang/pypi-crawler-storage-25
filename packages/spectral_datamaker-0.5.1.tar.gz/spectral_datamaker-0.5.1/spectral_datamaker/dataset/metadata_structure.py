from dataclasses import dataclass, field
from typing import List, Dict

# Metadata structure definitions for SpectralDatamaker datasets
    
@dataclass
class SegmentationMetadata:
    label_map: Dict[str, str]
    num_classes: int
    classes: List[str]
    assignments: Dict[str, List[int]]
    source_image: str
    rois_file: str
    mask_file: str
    created: str
    format: str
    source_dataset: str = None
    source_class: str = None
    nmasks: int = field(init=False)

    def __post_init__(self) -> None:
        self.nmasks = sum(len(values) for values in self.assignments.values())

@dataclass
class DatasetMetadata:
    name: str
    description: str
    last_update: str
    source_images: List[str]
    types: List[str]
    segmentation_masking: Dict[str, SegmentationMetadata]
