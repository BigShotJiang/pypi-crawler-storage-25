from ..processors.processor import DatasetConnection
from .dataset_structure import DatasetStructure
from .metadata_structure import DatasetMetadata, SegmentationMetadata
import json
import os

class MetadataManager(DatasetConnection):
    """Class for handling the dataset metadata."""

    def __init__(self, dataset_structure: DatasetStructure):
        super().__init__(dataset_structure)
        self.metadata: DatasetMetadata = self._import_metadata()

    def get_name(self) -> str:
        """Returns the name of the dataset."""
        return self.metadata.name
    
    def get_description(self) -> str:
        """Returns the description of the dataset."""
        return self.metadata.description

    def get_source_images(self, abs=False) -> list:
        """Returns a list of the source images of the dataset."""
        return self._get_source_images(abs)
    
    def get_last_update(self) -> str:
        """Returns the last update date of the dataset."""
        return self.metadata.last_update
    
    def get_types(self) -> list:
        """Returns a list of the types of the dataset."""
        return self.metadata.types
    
    def get_rois_files(self) -> list:
        """Returns a list of the ROIs files of the dataset."""
        return self._get_rois_files()
    
    def get_masks_files(self) -> list:
        """Returns a list of the pixel masks files of the dataset."""
        return self._get_masks_files()
    
    def get_segmentation_metadata(self) -> dict:
        """Returns the segmentation metadata of the dataset as a dictionary."""
        return self.metadata.segmentation_masking
    
    def get_nmasks_for_image(self, image_name: str) -> int:
        """Returns the number of masks associated with a given source image."""
        return self._get_nmasks_for_image(image_name)
    
    def to_json(self) -> str:
        """Returns the metadata of the dataset as a JSON string."""
        return self._to_json()
    
    def _import_metadata(self) -> DatasetMetadata:
        """Imports the metadata from the metadata file and returns it as a DatasetMetadata object."""
        metadata_path = self.dataset_structure.metadata_file

        with open(metadata_path, "r") as f:
            raw_metadata = json.load(f)

        raw_metadata["segmentation_masking"] = {
            image_name: SegmentationMetadata(**segmentation_data)
            for image_name, segmentation_data in raw_metadata.get("segmentation_masking", {}).items()
        }

        return DatasetMetadata(**raw_metadata)

    def _get_source_images(self, abs=False) -> list:
        """Returns a list of the source images of the dataset from the metadata."""
        if abs == False:
            return [os.path.basename(image) for image in self.metadata.source_images]
        return self.metadata.source_images

    def _get_rois_files(self) -> list:
        """Returns a list of the ROIs files of the dataset from the metadata."""
        return [sdata.rois_file for sdata in self.metadata.segmentation_masking.values()]
    
    def _get_masks_files(self) -> list:
        """Returns a list of the pixel masks files of the dataset from the metadata."""
        return [segmentation_data.mask_file for segmentation_data in self.metadata.segmentation_masking.values()]
    
    def _to_json(self) -> str:
        """Returns the metadata as a JSON string."""
        return json.dumps(self.metadata.__dict__, indent=2, default=lambda o: o.__dict__)
    
    def _get_nmasks_for_image(self, image_name: str) -> int:
        """Returns the number of masks associated with a given source image."""
        # removes extension if present
        if image_name.endswith((".hdr", ".img", ".npy")): #FIXME: this is a bit hacky, should be improved
            image_name = os.path.splitext(image_name)[0]
            segmentation_data = self.metadata.segmentation_masking.get(image_name)
        else:
            segmentation_data = self.metadata.segmentation_masking.get(image_name)
        if segmentation_data:
            return segmentation_data.nmasks
        return 0