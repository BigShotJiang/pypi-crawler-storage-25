import os


class DatasetStructure:
    def __init__(self, root_dir: str):
        self.root_dir = root_dir
        self.images_dir = os.path.join(root_dir, "images")
        self.masks_dir = os.path.join(root_dir, "masks")
        self.source_dir = os.path.join(root_dir, "source")
        self.metadata_file = os.path.join(root_dir, "metadata.json")