import os

from .dataset_structure import DatasetStructure


class Filenames:
    def __init__(self, dataset_structure: DatasetStructure):
        self.dataset_structure = dataset_structure
        self.dataset_metadata = "metadata.json"
        self.roi_mask_prefix = "RoiMASK_"
        self.px_mask_prefix = "PxMASK_"
        self.labels_prefix = "LABELS_"
        self.file_locations = {
            "dataset_metadata": self.dataset_structure.root_dir,
            "roi_masks": self.dataset_structure.masks_dir,
            "px_masks": self.dataset_structure.masks_dir,
            "roi_mask_metadata": self.dataset_structure.masks_dir,
            "px_mask_metadata": self.dataset_structure.masks_dir,
            "labels": self.dataset_structure.masks_dir,
            "cropped_images": self.dataset_structure.images_dir,
            "cropped_masks": self.dataset_structure.masks_dir,
        }

    def _abs_or_file(self, filename: str, directory_key: str, abs=False) -> str:
        """Returns the absolute path to a file if `abs` is True, otherwise returns the filename."""
        if abs:
            return os.path.join(self.file_locations[directory_key], filename)
        return filename

    def _get_img_basename(self, source_image: str) -> str:
        """Returns the base name for the source image (without extension)."""
        return os.path.splitext(os.path.basename(source_image))[0]

    def _get_roi_basename(self, source_image: str) -> str:
        """Returns the base name for the ROI mask files (without extension) based on the source image name."""
        return f"RoiMASK_{self._get_img_basename(source_image)}"

    def _get_px_basename(self, source_image: str) -> str:
        """Returns the base name for the pixel mask files (without extension) based on the source image name."""
        return f"PxMASK_{self._get_img_basename(source_image)}"

    def get_roi_mask(self, source_image: str, abs=False) -> str:
        """Returns the filename for the ROI mask (in .csv format) based on the source image name."""
        filename = f"{self._get_roi_basename(source_image)}.csv"
        return self._abs_or_file(filename, "roi_masks", abs)

    def get_roi_mask_metadata(self, source_image: str, abs=False) -> str:
        """Returns the filename for the ROI mask metadata (in .json format) based on the source image name."""
        filename = f"{self._get_roi_basename(source_image)}.json"
        return self._abs_or_file(filename, "roi_mask_metadata", abs)

    def get_labels(self, source_image: str, abs=False) -> str:
        """Returns the filename for the classification labels (in .csv format) based on the source image name."""
        filename = f"{self.labels_prefix}{self._get_img_basename(source_image)}.csv"
        return self._abs_or_file(filename, "labels", abs)

    def get_px_mask(self, source_image: str, abs=False) -> str:
        """Returns the filename for the pixel mask (in .npy format) based on the source image name."""
        filename = f"{self._get_px_basename(source_image)}.npy"
        return self._abs_or_file(filename, "px_masks", abs)

    def get_px_mask_metadata(self, source_image: str, abs=False) -> str:
        """Returns the filename for the pixel mask metadata (in .json format) based on the source image name."""
        filename = f"{self._get_px_basename(source_image)}.json"
        return self._abs_or_file(filename, "px_mask_metadata", abs)

    def get_dataset_metadata(self, abs=False) -> str:
        """Returns the filename for the dataset metadata file (in .json format)."""
        filename = self.dataset_metadata
        return self._abs_or_file(filename, "dataset_metadata", abs)

    def get_cropped_basename(self, source_image: str, dataset_name: str, abs=False) -> str:
        """Returns the basename for the cropped results (used for cropped images and masks)."""
        img_basename = self._get_img_basename(source_image)
        return self._abs_or_file(f"{dataset_name.upper()}_{img_basename}", "images", abs)

    def get_cropped_images(self, source_image: str, dataset_name: str, nmasks: int, abs=False) -> list:
        """Returns all the resulting cropped image filenames from a source image."""
        basename = self.get_cropped_basename(source_image, dataset_name, abs=False)
        filenames = [f"{basename}_{i}.npy" for i in range(nmasks)]
        return [self._abs_or_file(filename, "cropped_images", abs) for filename in filenames]

    def get_cropped_masks(self, source_image: str, dataset_name: str, nmasks: int, abs=False) -> str:
        """Returns the filename for a cropped mask."""
        basename = self.get_cropped_basename(source_image, dataset_name, abs=False)
        filenames = [f"{basename}_{i}.npy" for i in range(nmasks)]
        return [self._abs_or_file(filename, "cropped_masks", abs) for filename in filenames]