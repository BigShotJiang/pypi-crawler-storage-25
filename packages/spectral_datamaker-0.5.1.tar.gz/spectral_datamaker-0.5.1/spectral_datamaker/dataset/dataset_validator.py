from ..processors import DatasetConnection
import os
import json
from ..config import ConfigLoader

class DatasetValidator(DatasetConnection):
    """Class for validating the dataset structure and contents."""
    def __init__(self, dataset_structure):
        super().__init__(dataset_structure)

    def _validate_directories(self):
        """Validates the dataset structure."""
        if not os.path.exists(self.dataset_structure.images_dir):
            raise FileNotFoundError(f"Images directory not found: {self.dataset_structure.images_dir}")
        if not os.path.exists(self.dataset_structure.masks_dir):
            raise FileNotFoundError(f"Masks directory not found: {self.dataset_structure.masks_dir}")
        if not os.path.exists(self.dataset_structure.source_dir):
            raise FileNotFoundError(f"Source directory not found: {self.dataset_structure.source_dir}")

    def _validate_source_images(self, source_images: list):
        """Validates the presence of source images defined in the configuration."""
        for source_image in source_images:
            if not os.path.exists(source_image):
                raise FileNotFoundError(f"Source image not found: {source_image}")

    def _validate_metadata_file(self):
        """Validates the presence of the dataset metadata file."""
        metadata_file_path = self.filenames.get_dataset_metadata(abs=True)
        if not os.path.exists(metadata_file_path):
            raise FileNotFoundError(f"Dataset metadata file not found: {metadata_file_path}")

    def _validate_roi_masks(self, source_images: list):
        """Validates the presence of the necessary files for ROI masks."""
        for source_image in source_images:
            if not os.path.exists(self.filenames.get_roi_mask(source_image, abs=True)):
                raise FileNotFoundError(f"ROI mask file not found for image: {source_image.path}")

    def _validate_pixel_masks(self, source_images: list):
        """Validates the presence of the necessary files for pixel masks."""
        for source_image in source_images:
            if not os.path.exists(self.filenames.get_px_mask(source_image, abs=True)):
                raise FileNotFoundError(f"Pixel mask file not found for image: {source_image.path}")

    def _validate_labels(self, source_images: list):
        """Validates the presence of the necessary files for classification labels."""
        for source_image in source_images:
            if not os.path.exists(self.filenames.get_labels(source_image.path, abs=True)):
                raise FileNotFoundError(f"Classification labels file not found for image: {source_image.path}")

    def _validate_cropped_images(self, source_images: list, dataset_name: str, num_masks_dict: dict):
        """Validates the presence of the cropped images (segmentation / classification)."""
        for source_image in source_images:
            source_image_name = os.path.basename(source_image)
            nmasks = num_masks_dict[source_image_name]
            for cropped_image in self.filenames.get_cropped_images(source_image, dataset_name, nmasks=nmasks, abs=True):
                if not os.path.exists(cropped_image):
                    raise FileNotFoundError(f"Segmentation cropped image not found for image: {cropped_image}")

    def _validate_cropped_masks(self, source_images: list, dataset_name: str, num_masks_dict: dict):
        """Validates the presence of the cropped masks (segmentation)."""
        for source_image in source_images:
            source_image_name = os.path.basename(source_image)
            nmasks = num_masks_dict[source_image_name]
            for cropped_mask in self.filenames.get_cropped_masks(source_image, dataset_name, nmasks=nmasks, abs=True):
                if not os.path.exists(cropped_mask):
                    raise FileNotFoundError(f"Segmentation cropped mask not found for image: {cropped_mask}")

    def _validate_segmentation_crop_data(self, source_images: list, dataset_name: str, num_masks_dict: dict):
        """Validates the presence of the cropped images and masks for segmentation."""
        self._validate_cropped_images(source_images, dataset_name, num_masks_dict)
        self._validate_cropped_masks(source_images, dataset_name, num_masks_dict)

    def _validate_classification_crop_data(self, source_images: list, dataset_name: str, num_masks_dict: dict): #FIXME: To implement
        """Validates the presence of the cropped images for classifications."""
        print("Classification crop data validation not implemented yet.")

    def _validate_segmentation_metadata(self, source_images: list):
        for source_image in source_images:
            if not os.path.exists(self.filenames.get_px_mask_metadata(source_image, abs=True)):
                raise FileNotFoundError(f"Pixel mask metadata file not found for image: {source_image.path}")

    def _validate_classification_metadata(self, source_images: list):
        for source_image in source_images:
            if not os.path.exists(self.filenames.get_roi_mask_metadata(source_image, abs=True)):
                raise FileNotFoundError(f"ROI mask metadata file not found for image: {source_image.path}")

    def _validate_segmentation_files(self, source_images: list, dataset_name: str, num_masks_dict: dict):
        """Validates the presence of the necessary files for segmentation."""
        self._validate_roi_masks(source_images)
        self._validate_pixel_masks(source_images)
        self._validate_segmentation_crop_data(source_images, dataset_name, num_masks_dict)
        self._validate_segmentation_metadata(source_images)

    def _validate_classification_files(self, source_images: list, dataset_name: str, num_masks_dict: dict):
        """Validates the presence of the necessary files for classification."""
        self._validate_roi_masks(source_images)
        self._validate_labels(source_images)
        self._validate_classification_crop_data(source_images, dataset_name, num_masks_dict)
        self._validate_classification_metadata(source_images)

    def _validate_common_files(self, source_images: list):
        """Validates the presence of the necessary files common to both segmentation and classification."""
        self._validate_directories()
        self._validate_source_images(source_images)

    def _validate_segmentation_and_classification_files(self, source_images: list, dataset_name: str, num_masks_dict: dict):
        """Validates the presence of the necessary files for both segmentation and classification."""
        self._validate_segmentation_files(source_images, dataset_name, num_masks_dict)
        self._validate_classification_files(source_images, dataset_name, num_masks_dict)

    def _validate_dataset(self, source_images: list, dataset_has_segmentation: bool, dataset_has_classification: bool, dataset_name: str, num_masks_dict: dict):
        """Validates the dataset structure and contents based on the dataset type."""
        self._validate_common_files(source_images)
        if dataset_has_segmentation and dataset_has_classification:
            self._validate_segmentation_and_classification_files(source_images, dataset_name, num_masks_dict)
        elif dataset_has_segmentation:
            self._validate_segmentation_files(source_images, dataset_name, num_masks_dict)
        elif dataset_has_classification:
            self._validate_classification_files(source_images, dataset_name, num_masks_dict)

    def validate_dataset_from_config(self, config_file: str):
        """Validates the dataset structure and contents based on the provided configuration file."""
        config = ConfigLoader.get_config(config_file)
        num_masks_dict = config.get_mask_number_per_source_image()
        self._validate_dataset(
            source_images = [source_image.path for source_image in config.source_images],
            dataset_has_segmentation = config.segmentation_config.enabled,
            dataset_has_classification = config.classification_config.enabled,
            dataset_name = config.name,
            num_masks_dict = num_masks_dict
            )

    def _get_num_masks_dict_from_metadata(self, metadata: dict)-> dict: #FIXME: This will be implemented in a future DatasetMetadata class
        """Extracts the number of masks per source image from the existing metadata file."""
        num_masks_dict = {}
        for key, value in metadata["segmentation_masking"].items():
            image_name = value["source_image"]
            num_masks = sum([len(i[1]) for i in value["assignments"].items()])
            num_masks_dict[image_name] = num_masks
        return num_masks_dict

    def validate_dataset_from_metadata(self):
        """Validates the dataset structure and contents based on the existing metadata file."""
        self._validate_metadata_file()
        metadata = json.load(open(self.filenames.get_dataset_metadata(abs=True), 'r'))
        num_mask_dict = self._get_num_masks_dict_from_metadata(metadata)
        dataset_has_segmentation = "segmentation" in metadata.get("types", [])
        dataset_has_classification = "classification" in metadata.get("types", [])
        source_images = metadata.get("source_images", [])
        dataset_name = metadata["name"]
        self._validate_dataset(source_images, dataset_has_segmentation, dataset_has_classification, dataset_name, num_mask_dict)