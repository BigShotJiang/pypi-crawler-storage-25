import os
import subprocess

from ..config import DatasetConfig
from ..dataset import DatasetStructure
from .processor import Processor

class PixelMasking(Processor):
    def __init__(self, config: DatasetConfig, dataset_structure: DatasetStructure):
        super().__init__(config, dataset_structure)
        self._format = "npy"
        self._save_metadata = True

    def _create_single_pixel_mask(self, image: str, rois_csv: str, output: str) -> None:
        """
        Converts ROI masks defined in a CSV file to pixel masks that align with the original image dimensions.

        Args:
            image: The input ENVI (.hdr) image for which the pixel mask will be generated.
            rois_csv: The CSV file containing the coordinates of the ROI masks.
            output: The path where the generated pixel mask will be saved.

        Returns:
            None: generates a pixel mask file in `output` corresponding to the input image and ROI definitions.
        """
        subprocess.run([
            "hypertool", "roi-to-pixel-mask", image, rois_csv,
            "--classes", ",".join(self.config.segmentation_config.classes),
            "--output", output,
            "--format", self._format,
            "--save-metadata"], check=True)
        return None

    def process(self):
        """
        Processes each source image defined in the configuration by converting the corresponding ROI masks to pixel masks.

        Returns:
            None: The method generates pixel mask files for each processed image but does not return any value.
        """
        for source_image in self.config.source_images:
            image_path = source_image.path
            image_name = os.path.splitext(os.path.basename(image_path))[0]
            rois_csv = f"{self.dataset_structure.masks_dir}/RoiMASK_{image_name}.csv"
            output_path = f"{self.dataset_structure.masks_dir}/PxMASK_{image_name}"
            self._create_single_pixel_mask(image_path, rois_csv, output_path)