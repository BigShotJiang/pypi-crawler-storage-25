from abc import ABC, abstractmethod

from ..dataset import DatasetStructure, Filenames

class DatasetConnection:
    """Base class for connecting to a dataset."""
    def __init__(self, dataset_structure: DatasetStructure):
        self.dataset_structure = dataset_structure
        self.filenames = Filenames(self.dataset_structure)

class ConfigConnection:
    """Base class for connecting to a dataset."""
    def __init__(self, config, dataset_structure: DatasetStructure):
        self.config = config
        self.dataset_structure = dataset_structure

class Processor(ConfigConnection, ABC):
    """Abstract base class for all processors in the SpectralDatamaker library."""
    def __init__(self, config, dataset_structure):
        super().__init__(config, dataset_structure)

    @abstractmethod
    def process(self):
        raise NotImplementedError("Subclasses must implement the process method.")