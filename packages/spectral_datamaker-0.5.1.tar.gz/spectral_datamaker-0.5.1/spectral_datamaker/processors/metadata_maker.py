from abc import ABC, abstractmethod
from datetime import datetime
import json
import os

from ..config import DatasetConfig
from ..dataset import DatasetStructure
from .processor import ConfigConnection, Processor

class MetadataMaker(ConfigConnection, ABC):
    def __init__(self, config: DatasetConfig, dataset_structure: DatasetStructure):
        super().__init__(config, dataset_structure)

    @abstractmethod
    def get_metadata(self)-> dict:
        """Abstract method to be implemented by subclasses to return the specific metadata for the dataset."""
        raise NotImplementedError("Subclasses must implement the _get_metadata method.")

class CommonMetadataMaker(MetadataMaker):
    def __init__(self, config: DatasetConfig, dataset_structure: DatasetStructure):
        super().__init__(config, dataset_structure)

    def _get_dataset_name(self)-> str:
        return self.config.name

    def _get_dataset_description(self)-> str:
        return self.config.description

    def _get_source_images(self)-> list:
        return self.config.source_images

    def _get_current_date(self)-> str:
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def get_metadata(self)-> dict:
        """Returns the common metadata as dictionary."""
        return {
            "name": self._get_dataset_name(),
            "description": self._get_dataset_description(),
            "last_update": self._get_current_date(),
            "source_images": [image.path for image in self._get_source_images()],
        }

class SegmentationMetadataMaker(MetadataMaker):
    def __init__(self, config: DatasetConfig, dataset_structure: DatasetStructure):
        super().__init__(config, dataset_structure)

    def _get_source_image_names(self)-> list:
        """Returns a list of names (without extension) to the source images defined in the configuration."""
        return [os.path.splitext(os.path.basename(image.path))[0] for image in self.config.source_images]

    def _get_masking_metadata(self)-> dict:
        """Returns the metadata for the masking process as a dictionary."""
        metadata_paths = [(image, f"PxMASK_{image}.json") for image in self._get_source_image_names()]
        metadata = {}
        for image, path in metadata_paths:
            with open(os.path.join(self.dataset_structure.masks_dir, path), 'r') as f:
                metadata[image] = json.load(f)
        return metadata

    def _get_dataset_types(self)-> list:
        return ["segmentation"]

    def get_metadata(self)-> dict:
        """Returns the segmentation metadata of a dataset as a dictionary."""
        return {
            "types": self._get_dataset_types(),
            "segmentation_masking": self._get_masking_metadata()
            }

class ClassificationMetadataMaker(MetadataMaker):
    def __init__(self, config: DatasetConfig, dataset_structure: DatasetStructure):
        super().__init__(config, dataset_structure)

    def _get_labels_metadata(self)-> dict:
        """Returns the metadata for the labeling process as a dictionary."""
        metadata_paths = [(image, f"RoiMASK_{image}.json") for image in self.config.source_images.path]
        metadata = {}
        for image, path in metadata_paths:
            with open(os.path.join(self.dataset_structure.labels_dir, path), 'r') as f:
                metadata[image] = json.load(f)
        return metadata

    def _get_dataset_types(self)-> list:
        return ["classification"]

    def get_metadata(self)-> dict:
        """Returns the classification metadata of a dataset as a dictionary."""
        return {
            "types": self._get_dataset_types(),
            "classification_labels": self._get_labels_metadata()
            }

class MetadataFileHandler:
    def __init__(self, dataset_structure: DatasetStructure):
        self.dataset_structure = dataset_structure

    def _get_metadata_file_path(self)-> str:
        """Returns the file path to the metadata file."""
        return self.dataset_structure.metadata_file

    def _metadata_file_exists(self)-> bool:
        """Checks if the metadata file already exists in the dataset structure."""
        return os.path.exists(self._get_metadata_file_path())

    def _metadata_file_type_is_classification(self)-> bool:
        """Checks if the existing metadata file corresponds to a classification dataset."""
        if not self._metadata_file_exists():
            return False
        with open(self.dataset_structure.metadata_file, 'r') as f:
            existing_metadata = json.load(f)
        return "classification" in existing_metadata.get("types", [])

    def _metadata_file_type_is_segmentation(self)-> bool:
        """Checks if the existing metadata file corresponds to a segmentation dataset."""
        if not self._metadata_file_exists():
            return False
        with open(self.dataset_structure.metadata_file, 'r') as f:
            existing_metadata = json.load(f)
        return "segmentation" in existing_metadata.get("types", [])

    def _metadata_file_is_segmentation_and_classification(self)-> bool:
        """Checks if the existing metadata file corresponds to a dataset that is both segmentation and classification."""
        if not self._metadata_file_exists():
            return False
        with open(self.dataset_structure.metadata_file, 'r') as f:
            existing_metadata = json.load(f)
        types = existing_metadata.get("types", [])
        return "segmentation" in types and "classification" in types

class MetadataProcessor(Processor):
    def __init__(self, config: DatasetConfig, dataset_structure: DatasetStructure):
        super().__init__(config, dataset_structure)
        self.metadata_handler = MetadataFileHandler(dataset_structure)
        self._metadata = CommonMetadataMaker(self.config, self.dataset_structure).get_metadata()

    def _load_base_metadata(self):
        common = CommonMetadataMaker(self.config, self.dataset_structure).get_metadata()

        if self.metadata_handler._metadata_file_exists():
            with open(self.dataset_structure.metadata_file, "r") as f:
                existing = json.load(f)

            # Base en memoria: conservar lo que ya existía y completar con comunes faltantes
            self._metadata = {**common, **existing}
        else:
            self._metadata = common


    def _merge_metadata(self, new_metadata: dict):
        # Asegura base cargada (soluciona caso inicial sin metadata.json)
        if not self._metadata:
            self._load_base_metadata()

        # Merge robusto de types
        existing_types = set(self._metadata.get("types", []))
        incoming_types = set(new_metadata.get("types", []))
        if existing_types or incoming_types:
            self._metadata["types"] = list(existing_types.union(incoming_types))

        # Merge del resto de bloques
        for key, value in new_metadata.items():
            if key == "types":
                continue

            if isinstance(value, dict):
                self._metadata[key] = {
                    **self._metadata.get(key, {}),
                    **value
                }
            else:
                self._metadata[key] = value


    def process(self):
        # Carga una única vez desde disco/común al inicio
        self._load_base_metadata()

        if self.config.segmentation_config.enabled:
            segmentation_metadata = SegmentationMetadataMaker(
                self.config, self.dataset_structure
            ).get_metadata()
            self._merge_metadata(segmentation_metadata)

        if self.config.classification_config.enabled:
            classification_metadata = ClassificationMetadataMaker(
                self.config, self.dataset_structure
            ).get_metadata()
            self._merge_metadata(classification_metadata)

        with open(self.metadata_handler._get_metadata_file_path(), "w") as f:
            json.dump(self._metadata, f, indent=4)