import os
import subprocess

from ..config import DatasetConfig
from ..dataset import DatasetStructure
from .processor import Processor

class SegmentationCrop(Processor):
    def __init__(self, config: DatasetConfig, dataset_structure: DatasetStructure):
        super().__init__(config, dataset_structure)

    def _crop_single_image(self, image: str, mask_npy: str, prefix: str):
        """
        Crops the input image and its corresponding pixel mask into smaller segments based on the defined crop size in the configuration.

        Args:
            image: The input ENVI (.hdr) image to be cropped.
            mask_npy: The corresponding pixel mask file (in .npy format) for the input image.
            images_dir: The directory where the cropped image segments will be saved.
            masks_dir: The directory where the cropped mask segments will be saved.
            prefix: A prefix to be added to the filenames of the cropped segments for identification.

        Returns:
            None: generates cropped image and mask files in `images_dir` and `masks_dir` respectively, but does not return any value.
        """

        # def crop(image, mask_input, output_dir, prefix, format, apply_mask, min_area, images_dir, masks_dir)
        subprocess.run(["hypertool", "crop", image, mask_npy,
                        "--prefix", prefix,
                        "--format", "numpy",
                        "--images-dir", self.dataset_structure.images_dir,
                        "--masks-dir", self.dataset_structure.masks_dir], check=True)
        return

    def process(self):
        """
        Processes each source image defined in the configuration by cropping the image and its corresponding pixel mask into smaller segments.

        Returns:
            None: The method generates cropped image and mask files for each processed image but does not return any value.
        """
        dataset_name = self.config.name.upper()
        for source_image in self.config.source_images:
            image_path = source_image.path
            image_name = os.path.splitext(os.path.basename(image_path))[0]
            mask_npy = f"{self.dataset_structure.masks_dir}/PxMASK_{image_name}.npy"
            prefix = f"{dataset_name}_{image_name}"
            self._crop_single_image(image_path, mask_npy, prefix)