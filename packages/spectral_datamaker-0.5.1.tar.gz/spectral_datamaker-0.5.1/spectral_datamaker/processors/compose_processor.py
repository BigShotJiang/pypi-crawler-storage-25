import json
import os
import shutil
from datetime import datetime

import numpy as np

from ..config.compose_config_schema import ComposeConfig
from ..dataset.dataset_structure import DatasetStructure
from ..dataset.filenames import Filenames
from .processor import DatasetConnection


class ComposeProcessor(DatasetConnection):
    """Processor that builds a new dataset by selecting ROI crops from existing datasets."""

    def __init__(self, dataset_structure: DatasetStructure):
        super().__init__(dataset_structure)

    def _create_output_dirs(self):
        os.makedirs(self.dataset_structure.images_dir, exist_ok=True)
        os.makedirs(self.dataset_structure.masks_dir, exist_ok=True)
        os.makedirs(self.dataset_structure.source_dir, exist_ok=True)

    def _build_inverted_label_map(self, label_map: dict) -> dict:
        """Returns {class_name: int_label} from {"0": "background", "1": "class1", ...}."""
        return {name: int(key) for key, name in label_map.items()}

    def _get_file_indices(self, assignments: dict, inverted_label_map: dict, variety: str):
        """
        Returns the range of file indices that hypertool crop generated for `variety`.

        hypertool crop iterates np.unique(mask) in ascending label order and enumerates
        regions sequentially. So all crops of label N come before all crops of label N+1.
        """
        src_label = inverted_label_map[variety]
        start_idx = sum(
            len(roi_list)
            for cls_name, roi_list in assignments.items()
            if 0 < inverted_label_map.get(cls_name, 0) < src_label
        )
        count = len(assignments[variety])
        return range(start_idx, start_idx + count)

    def _remap_mask(self, mask: np.ndarray, src_label: int, dst_label: int) -> np.ndarray:
        """Replace src_label pixels with dst_label; everything else becomes background (0)."""
        return np.where(mask == src_label, dst_label, 0).astype(mask.dtype)

    def process(self, config: ComposeConfig):
        # Lazy import to break the circular dependency:
        # processors/__init__ → compose_processor → dataset_manager → metadata_manager
        #                                          → processors/__init__ (partially initialized)
        from ..dataset.dataset_manager import DatasetManager

        self._create_output_dirs()

        virtual_source_images = []
        segmentation_masking = {}

        for source in config.sources:
            src_structure = DatasetStructure(source.dataset)
            src_manager = DatasetManager(src_structure)
            src_filenames = Filenames(src_structure)

            dataset_name = src_manager.get_name()
            seg_metadata = src_manager.metadata.get_segmentation_metadata()

            remaining = source.num  # None means unlimited

            for source_image_key, entry in seg_metadata.items():
                if remaining is not None and remaining <= 0:
                    break
                if source.class_name not in entry.assignments:
                    continue
                if len(entry.assignments[source.class_name]) == 0:
                    continue

                inverted = self._build_inverted_label_map(entry.label_map)
                src_label = inverted[source.class_name]
                file_indices = self._get_file_indices(entry.assignments, inverted, source.class_name)

                if remaining is not None:
                    file_indices = file_indices[:remaining]

                src_img_paths = src_filenames.get_cropped_images(
                    source_image_key, dataset_name, entry.nmasks, abs=True
                )
                src_msk_paths = src_filenames.get_cropped_masks(
                    source_image_key, dataset_name, entry.nmasks, abs=True
                )

                dst_label = config.classes.index(source.class_name) + 1
                group_key = f"{source_image_key}_{source.class_name}"
                group_count = len(file_indices)

                for output_idx, file_idx in enumerate(file_indices):
                    dst_img_name = f"{config.name.upper()}_{group_key}_{output_idx}.npy"
                    dst_msk_name = f"{config.name.upper()}_{group_key}_{output_idx}.npy"

                    shutil.copy(
                        src_img_paths[file_idx],
                        os.path.join(self.dataset_structure.images_dir, dst_img_name),
                    )

                    mask = np.load(src_msk_paths[file_idx])
                    remapped = self._remap_mask(mask, src_label, dst_label)
                    np.save(
                        os.path.join(self.dataset_structure.masks_dir, dst_msk_name),
                        remapped,
                    )

                if remaining is not None:
                    remaining -= group_count

                dst_label_map = {"0": "background"}
                for i, cls in enumerate(config.classes):
                    dst_label_map[str(i + 1)] = cls

                group_assignments = {cls: [] for cls in config.classes}
                group_assignments[source.class_name] = list(range(group_count))

                segmentation_masking[group_key] = {
                    "label_map": dst_label_map,
                    "num_classes": len(config.classes) + 1,
                    "classes": config.classes,
                    "assignments": group_assignments,
                    "source_image": group_key,
                    "source_dataset": source.dataset,
                    "source_class": source.class_name,
                    "rois_file": "",
                    "mask_file": "",
                    "created": datetime.now().isoformat(),
                    "format": "npy",
                }

                virtual_source_images.append(group_key)

        metadata = {
            "name": config.name,
            "description": config.description,
            "last_update": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "source_images": virtual_source_images,
            "types": ["segmentation"],
            "segmentation_masking": segmentation_masking,
        }

        with open(self.dataset_structure.metadata_file, "w") as f:
            json.dump(metadata, f, indent=4)
