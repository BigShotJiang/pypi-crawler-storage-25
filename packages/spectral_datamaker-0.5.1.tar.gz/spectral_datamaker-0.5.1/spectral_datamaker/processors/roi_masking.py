import os
import subprocess

from ..config import DatasetConfig
from ..dataset import DatasetStructure
from .processor import Processor

class ROIMasking(Processor):
    def __init__(self, config: DatasetConfig, dataset_structure: DatasetStructure):
        super().__init__(config, dataset_structure)

    def _create_single_roi_mask(self, image: str, shape: str, size: int, num: int, output: str)-> None:
        """
        Opens the image with napari using default bands and adds a shapes
        layer with pre-configured masks. Users can then adjust mask
        positions while maintaining consistent size across different images.

        Args:
            image: The input ENVI (.hdr) image to which the ROI mask will be applied.
            shape: The shape of the ROI mask ('circle', 'square' or 'triangle').
            size: The size of the ROI mask.
            num: The number of ROI masks to apply.

        Returns:
            None: generates a CSV file in `output` with the coordinates of the applied
                ROI masks for the given image.
        """
        subprocess.run(["hypertool", "roi-mask", image, "--shape", shape, "--size", str(size), "--num", str(num), "--output", output], check=True)
        return None

    def process(self):
        """
        Processes each source image defined in the configuration by applying the ROI masking.

        Returns:
            None: The method generates CSV files for each processed image but does not return any value.
        """
        for source_image in self.config.source_images:
            image_path = source_image.path
            image_name = os.path.splitext(os.path.basename(image_path))[0]
            shape = source_image.masking.shape
            size = source_image.masking.size
            num = source_image.masking.num
            output_path = f"{self.dataset_structure.masks_dir}/RoiMASK_{image_name}.csv"
            self._create_single_roi_mask(image_path, shape, size, num, output_path)