import os
from .processor import Processor

class StructureProcessor(Processor):
    """Processor for handling dataset structure related tasks, like creating directories,
    symlinks, and validating the structure. This is typically one of the first processors
    to run in a processing pipeline.
    """
    def __init__(self, config, dataset_structure):
        super().__init__(config, dataset_structure)

    def _create_directories(self):
        os.makedirs(self.dataset_structure.images_dir, exist_ok=True)
        os.makedirs(self.dataset_structure.masks_dir, exist_ok=True)
        os.makedirs(self.dataset_structure.source_dir, exist_ok=True)

    def process(self):
        """Process the dataset structure."""
        self._create_directories()