from dataclasses import dataclass
from typing import List, Optional


@dataclass
class SourceSelection:
    dataset: str
    class_name: str
    num: Optional[int] = None


@dataclass
class ComposeConfig:
    name: str
    description: str
    classes: List[str]
    sources: List[SourceSelection]
