from .config_schema import DatasetConfig, SourceImage, MaskingConfig, SegmentationConfig, ClassificationConfig
import yaml

class ConfigLoader:
    """
    A class responsible for loading and validating the dataset configuration from a YAML file.
    """

    @staticmethod
    def get_config(config_path: str) -> DatasetConfig:
        """
        Load the dataset configuration from a YAML file.

        Args:
            config_path (str): The path to the YAML configuration file.
        Returns:
            DatasetConfig: An instance of DatasetConfig containing the loaded configuration.
        """
        with open(config_path, 'r') as file:
            config_dict = yaml.safe_load(file)["dataset"]

        # Validate and create DatasetConfig instance
        try:
            source_images = [
                SourceImage(
                    path=img['path'],
                    masking=MaskingConfig(
                        shape=img['masking']['shape'],
                        size=img['masking']['size'],
                        num=img['masking']['num']
                    )
                ) for img in config_dict['source-images']
            ]

            segmentation_config = SegmentationConfig(
                enabled=config_dict['segmentation']['enabled'],
                classes=config_dict['segmentation']['classes']
            )

            classification_config = ClassificationConfig(
                enabled=config_dict['classification']['enabled']
            )

            dataset_config = DatasetConfig(
                name=config_dict['name'],
                description=config_dict['description'],
                source_images=source_images,
                segmentation_config=segmentation_config,
                classification_config=classification_config
            )

            return dataset_config

        except KeyError as e:
            raise ValueError(f"Missing required configuration key: {e}")