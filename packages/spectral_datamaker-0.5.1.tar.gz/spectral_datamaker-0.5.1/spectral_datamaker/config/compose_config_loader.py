import yaml

from .compose_config_schema import ComposeConfig, SourceSelection


class ComposeConfigLoader:

    @staticmethod
    def get_config(config_path: str) -> ComposeConfig:
        with open(config_path, "r") as f:
            config_dict = yaml.safe_load(f)["compose"]

        try:
            sources = [
                SourceSelection(
                    dataset=src["dataset"],
                    class_name=src["class"],
                    num=src.get("num", None),
                )
                for src in config_dict["sources"]
            ]

            return ComposeConfig(
                name=config_dict["name"],
                description=config_dict["description"],
                classes=config_dict["classes"],
                sources=sources,
            )

        except KeyError as e:
            raise ValueError(f"Missing required configuration key: {e}")
