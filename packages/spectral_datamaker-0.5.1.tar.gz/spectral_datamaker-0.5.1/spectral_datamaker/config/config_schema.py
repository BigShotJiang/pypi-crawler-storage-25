from dataclasses import dataclass
from typing import List, Dict, Any
import os

@dataclass
class MaskingConfig:
    """
    Configuration class for masking parameters.
    """
    shape: str
    size: int
    num: int

@dataclass
class SourceImage:
    """
    Configuration class for source images.
    """
    path: str
    masking: MaskingConfig


@dataclass
class SegmentationConfig:
    """
    Configuration class for segmentation parameters.
    """
    enabled: bool
    classes: List[str]

@dataclass
class ClassificationConfig: #FIXME: This is a placeholder for future classification parameters. It can be expanded as needed.
    """
    Configuration class for classification parameters.
    """
    enabled: bool

@dataclass
class DatasetConfig:
    """
    Configuration class for SpectralDatamaker.
    """
    name: str
    description: str
    source_images: List[SourceImage]
    segmentation_config: SegmentationConfig
    classification_config: ClassificationConfig

    def get_mask_number_per_source_image(self)-> Dict[str, int]:
        """Returns a dictionary mapping each source image path to its corresponding number of masks."""
        return {os.path.basename(source_image.path): source_image.masking.num for source_image in self.source_images}