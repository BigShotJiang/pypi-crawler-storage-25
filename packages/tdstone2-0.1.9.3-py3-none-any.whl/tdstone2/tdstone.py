from tdstone2.utils import (
    execute_query,
    retry_on_upstream_timeout,
    _raw_query_apply_df,
    set_apply_compute_group,
    set_apply_connect_kwargs,
)
import teradataml as tdml
from tqdm import tqdm
import os
import logging
import os
import logging
from datetime import datetime
from tqdm import tqdm

# Setting up the logger to include timestamps
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

file_list = ['tds_feature_engineering',
             'tds_feature_engineering_reducer',
             'tds_training',
             'tds_scoring',
             'tds_training_old',
             'tds_scoring_old',
             'tds_feature_engineering_jsonoutput',
             'tds_vector_embedding',
             'tds_vector_embedding_lake',
             'tds_seq2seq'
             ]

# Apply (VCL/OpenAF) script files. Installed into the Apply user-env when
# TDStone is configured with use_apply=True.
APPLY_FILES = ['tds_training_apply',
               'tds_scoring_apply',
               'tds_feature_engineering_apply',
               'tds_feature_engineering_reducer_apply',
               ]

DEFAULT_APPLY_LIBS = ['numpy', 'pandas', 'scikit-learn', 'skl2onnx', 'onnxruntime']

this_dir, this_filename = os.path.split(__file__)

class TDStone():
    """
    Class to manage the TDStone system.
    """
    def __init__(self, schema_name, **kwargs):
        """
        Initialize the TDStone object.
        ...
        """        
        self.schema_name      = schema_name
        self.SEARCHUIFDBPATH  = kwargs.get('SEARCHUIFDBPATH', schema_name)
        self.oaf_env          = kwargs.get('oaf_env', None)
        self.code_repository  = kwargs.get('code_repository', 'TDS_CODE_REPOSITORY')
        self.model_repository = kwargs.get('model_repository', 'TDS_MODEL_REPOSITORY')
        self.trained_model_repository = kwargs.get('trained_model_repository', 'TDS_TRAINED_MODEL_REPOSITORY')
        self.mapper_repository = kwargs.get('mapper_repository', 'TDS_MAPPER_REPOSITORY')
        self.hyper_model_repository = kwargs.get('hyper_model_repository', 'TDS_HYPER_MODEL_REPOSITORY')
        self.feature_engineering_process_repository = kwargs.get('feature_engineering_process_repository', 'TDS_FEATURE_ENGINEERING_PROCESS_REPOSITORY')

        # Apply (VCL/OpenAF) configuration. use_apply=True opts into the Apply
        # backend on Vantage Cloud Lake. Defaults preserve Script-on-Lake behaviour.
        # oaf_env is independent: it's the legacy Script-on-Lake env (also used by
        # tdsgenai_lake). When use_apply=True and oaf_env is None, setup() runs in
        # Apply-only mode and skips the legacy STO file push.
        self.use_apply        = kwargs.get('use_apply', False)
        self.apply_env_name   = kwargs.get('apply_env_name', 'tdstone2_sklearn')
        self.apply_libs       = list(kwargs.get('apply_libs', DEFAULT_APPLY_LIBS))
        self.apply_python     = kwargs.get('apply_python', 'python3')
        self.apply_delimiter  = kwargs.get('apply_delimiter', ',')
        # Pin the compute group used by every Apply call. Required on VCLs
        # where the user has no default compute-group association — without
        # it, Apply returns Error 4100 "Incompatible DBS". When set, the
        # ``compute=<group>`` queryband is applied to the fresh teradatasql
        # connection that ``utils._get_apply_conn`` opens for OFS-routed DML.
        # Falls back to the VCL_COMPUTE_GROUP / TD_COMPUTE_GROUP env vars if
        # the kwarg is not provided (matches the host/user/password lookup
        # pattern). None preserves the pre-fix behaviour for systems where
        # the user *does* have a default association.
        self.compute_group    = kwargs.get(
            'compute_group',
            os.getenv('VCL_COMPUTE_GROUP') or os.getenv('TD_COMPUTE_GROUP'),
        )
        # Pin the teradatasql.connect kwargs the Apply helper uses for
        # OFS-routed DML. Required when multiple VCL env-blocks are loaded
        # (e.g. VCL_* and VCL2_*) — otherwise the helper's hardcoded
        # ``os.getenv('VCL_*')`` lookup would silently land on whichever
        # one is set, possibly the wrong cluster. Pass at least
        # host/user/password; database/logmech optional. None preserves
        # the env-var fallback behaviour for single-VCL setups.
        self.connect_kwargs   = kwargs.get('connect_kwargs', None)
        if self.use_apply and self.compute_group:
            set_apply_compute_group(self.compute_group)
        if self.use_apply and self.connect_kwargs:
            set_apply_connect_kwargs(**self.connect_kwargs)
        # Mini-batch size used inside tds_scoring_apply.py to slice the per-
        # partition data_buffer before each ``model.predict``. Passed as the
        # script's first CLI arg.
        #
        # Why 1000 (not 100): the scoring loop is fully sequential on a single
        # CPU thread (df-build → cast → predict → format → write). Unlike the
        # GPU vector-embedding path in tds_vector_embedding_lake.py — where
        # ``sentence_transformer.encode(...)`` runs on CUDA in parallel with
        # stdin/stdout I/O on the CPU and small batches give a real pipeline
        # win — on the sklearn CPU path there's no second compute resource to
        # overlap with, so small batches just multiply per-batch overhead
        # (DataFrame ctor, type-cast loop, csv-format setup). Apply also
        # doesn't stream results back to the caller incrementally, so smaller
        # batches don't help first-row latency either. Default 1000 keeps
        # per-batch overhead amortised; raise further on tiny rows / large
        # partitions, lower only if the worker container is memory-constrained.
        self.apply_scoring_batch_size = int(kwargs.get('apply_scoring_batch_size', 1000))
        # Number of hash buckets used by the scoring on-clause view. Apply's
        # HASH BY <col> opens one script per distinct hash value, so to
        # consolidate to "one script per AMP" we hash on (Partition_ID MOD N)
        # where N matches the cluster's AMP count. Default 8 matches the
        # current Lake compute profile; tune via this kwarg.
        self.apply_scoring_hash_buckets = int(kwargs.get('apply_scoring_hash_buckets', 8))
        # base_env passed to tdml.create_env. When None, teradataml calls
        # list_base_envs() to auto-pick a default — that endpoint is the most
        # flaky on VCL, so we set an explicit default to bypass it.
        self.base_env         = kwargs.get('base_env', 'python_3.10')
        # PTI (Primary Time Index / GENERATED SYSTEM TIMECOLUMN) is an
        # Enterprise-only feature; VCL parser rejects the syntax. Default to
        # PTI only on Enterprise (use_apply=False).
        self.use_pti          = kwargs.get('use_pti', not self.use_apply)

    def _vt(self):
        """CURRENT VALIDTIME prefix for SELECT/INSERT/UPDATE.

        Empty on the Apply path and on VCL (oaf_env set): OFS tables can't
        carry a TEMPORAL period column, and VCL rejects temporal DDL/DML with
        Error 9352 / 9330 even for non-OFS storage.
        """
        return "" if (self.use_apply or self.oaf_env) else "CURRENT VALIDTIME "

    def _temporal_columns(self):
        """Return the ValidStart/ValidEnd/PERIOD column block for temporal repos.

        OFS rejects ``PERIOD FOR ValidPeriod ... AS VALIDTIME`` (Error 3706:
        "TEMPORAL option is not allowed"), so the Apply path emits a
        non-temporal table with a regular CREATION_DATE column instead. VCL
        (oaf_env set) also rejects temporal DDL (Error 9352), so the same
        non-temporal column block is used there.
        """
        if self.use_apply or self.oaf_env:
            return "\n                CREATION_DATE TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP(6)"
        return """\n                ValidStart TIMESTAMP(0) WITH TIME ZONE NOT NULL,
                ValidEnd TIMESTAMP(0) WITH TIME ZONE NOT NULL,
                PERIOD FOR ValidPeriod  (ValidStart, ValidEnd) AS VALIDTIME"""

    def _query_df(self, query):
        """Return a pandas DataFrame for a SELECT statement.

        Routes through the fresh teradatasql connection for both Apply and
        Script paths. ``tdml.DataFrame.from_query`` internally creates a
        temporary VIEW, which fails with Error 9330 when the query contains
        a ``CURRENT VALIDTIME`` qualifier — even on Script-on-Lake where the
        underlying tables *are* temporal. The raw connection executes the
        query directly without view creation.
        """
        return _raw_query_apply_df(query)

    def _table_options(self):
        """Return the CREATE TABLE options block.

        On the Apply path, every tdstone2 table is pinned to OFS via
        ``STORAGE = TD_OFSSTORAGE`` so the Analytical Compute Cluster can read
        and write it without crossing storage tiers (Error 6881). The user's
        home schema (e.g. data_scientist) typically lacks CREATE TABLE rights
        in OFS-native databases like demo_ofs, so we keep the table addressed
        as <home_schema>.<name> but flip its physical storage to OFS — same
        trick as ``tdstone2.utils.move2OFS``.
        """
        if self.use_apply:
            return ",\n            NO FALLBACK,\n            MAP = TD_MAP2,\n            STORAGE = TD_OFSSTORAGE"
        return ",\n            FALLBACK,\n            NO BEFORE JOURNAL,\n            NO AFTER JOURNAL,\n            CHECKSUM = DEFAULT,\n            DEFAULT MERGEBLOCKRATIO,\n            MAP = TD_MAP1"

    @execute_query
    def PushFile(self):
        """
        This method is used to create a list of database queries that will update 
        the search path, remove the current file, and then install a new file based 
        on the operating system type. It is specifically designed for handling file 
        management on different systems.

        Returns:
            list: A list of SQL queries to be executed.
        """

        # Creating an empty list to hold the queries
        queries = []

        # Appending the SET SESSION and DATABASE queries to the list
        queries.append('SET SESSION SEARCHUIFDBPATH = "{}"'.format(self.SEARCHUIFDBPATH))
        queries.append('DATABASE {}'.format(self.SEARCHUIFDBPATH))

        # Looping through each filename in the file list
        for filename in (pbar := tqdm(file_list)):
            pbar.set_description(f"Installing {filename}")
            # Adding a command to remove the existing file
            queries.append("CALL SYSUIF.REMOVE_FILE('{}',1);".format(filename))

            # Checking the OS name to determine the file path format
            if os.name == 'nt':
                # If it's Windows, we need to format the path a little differently
                queries.append("CALL SYSUIF.INSTALL_FILE('{}','{}','cz!{}')".format(filename,
                     filename+'.py',
                     os.path.join(this_dir, "data", filename+".py").replace("\\", "/").split(':')[1]))

            else:
                # If it's Linux or another OS, we can use the standard path format
                queries.append("CALL SYSUIF.INSTALL_FILE('{}','{}','cz!{}')".format(filename,
                     filename+'.py',
                     os.path.join(this_dir, "data", filename+".py")))

        # Return the complete list of queries
        return queries

    def PushFile_Lake(self, target_env=None, files=None):
        """Install Python script files into a Lake user environment.

        Args:
            target_env: name of the Lake env (defaults to ``self.oaf_env``).
            files:      iterable of file basenames to install (no ``.py``); defaults
                        to the legacy Script-on-Lake ``file_list``.

        Logging:
            Logs each file installation attempt with a timestamp.
        """
        from time import sleep
        if target_env is None:
            target_env = self.oaf_env
        if files is None:
            files = file_list

        # Retrieve the environment configuration
        oaf = retry_on_upstream_timeout(logger=None)(tdml.get_env)(target_env)
        sql_queries = []

        # Loop through each filename in the file list and log progress
        logger.info(f"Installing {','.join(files)} in the {target_env} environment")
        for filename in files:
            # Determine file path format based on OS
            if os.name == 'nt':
                # Windows path adjustment
                file_path = os.path.join(this_dir, "data", filename + ".py").replace("\\", "/").split(':')[1]
            else:
                # Standard path for Linux or Unix
                file_path = os.path.join(this_dir, "data", filename + ".py")
            # Execute installation with environment configuration
            try:

                claim_id = ''
                nb_tentatives = 0
                while nb_tentatives < 10:
                    try:
                        if nb_tentatives == 0:
                            logger.info(
                                f"Starting installation of {filename}.py to environment: {target_env}")
                        else:
                            logger.info(
                                f"Starting installation of {filename}.py to environment: {target_env} tentative #{nb_tentatives}")
                        claim_id = oaf.install_file(
                            file_path       = file_path,
                            replace         = True,
                            suppress_output = True,
                            asynchronous    = True
                        )
                        logger.info(
                            f"Successful install_file execution (e.g. no timeout issue)")
                        break
                    except Exception as e:
                        # Check if this is an upstream timeout error
                        logger.error(f"An unexpected error occurred: {str(e)}")
                        if 'TDML_2412' in str(e):
                            logger.warning("TeradataMlException: Upstream request timeout occurred. New tentative.")
                        else:
                            logger.error(f"An unexpected error occurred: {str(e)}")
                            raise
                    nb_tentatives += 1
                    sleep(nb_tentatives)
                    if nb_tentatives >= 10:
                        raise
                if isinstance(claim_id, str):
                    logger.info(
                        f"Claimid for {filename}.py installation '{claim_id}'")
                    try:
                        stage = oaf.status(claim_id)['Stage'].iloc[-1]
                        while stage != 'File Installed':
                            stage = oaf.status(claim_id)['Stage'].iloc[-1]
                            logger.info(
                                f"Claimid {claim_id} status '{stage}'")
                            sleep(1)
                    except Exception as e:
                        logger.info(
                            f"Claimid {claim_id} status '{stage}'")
                        logger.info(f"error {str(e)}")
                        raise

                logger.info(
                    f"{filename}.py successfully installed in environment '{target_env}'.")
            except Exception as e:
                # Log the error with relevant details
                logger.error(
                    f"Installation failed for {filename}.py in environment: {target_env}. Error: {str(e)}")
                raise


        logger.info(f"All files installed")

        return

    def _get_or_create_env(self, env_name, desc='tdstone2 user environment', base_env=None):
        """Get an env by name, creating it if missing.

        Tries ``tdml.create_env`` first (per the pattern in
        ``demos/notebooks td_sklearn/03 - Basic Anomaly Detection with Apply (VCL).ipynb``):
        ``create_env`` is cheap and fails fast with a clear "same name already exists"
        error, whereas ``tdml.get_env`` internally lists *all* user envs and is the
        first thing to flake out under VCL load (intermittent 500s).

        ``base_env`` is passed through to ``tdml.create_env``. When omitted,
        teradataml calls ``list_base_envs()`` to auto-pick a default — that
        endpoint is the second most flaky on VCL, so we default to
        ``self.base_env`` (typically ``'python_3.10'``) to skip the lookup.

        Returns the teradataml Environment object for ``env_name``.
        """
        if base_env is None:
            base_env = self.base_env

        kwargs = dict(env_name=env_name, desc=desc, conda_env=False)
        if base_env:
            kwargs['base_env'] = base_env

        try:
            env = retry_on_upstream_timeout(logger=logger)(tdml.create_env)(**kwargs)
            logger.info(f"Env '{env_name}' created (base_env={base_env!r}).")
            return env
        except Exception as e:
            if 'same name already exists' in str(e).lower():
                logger.info(
                    f"Env '{env_name}' already exists; obtaining a reference."
                )
                return retry_on_upstream_timeout(logger=logger)(tdml.get_env)(env_name)
            logger.error(f"Failed to create env '{env_name}': {e}")
            raise

    def ensure_apply_env(self):
        """Idempotently get-or-create the Apply user env and install required libs.

        Returns:
            The teradataml Environment object for ``self.apply_env_name``.
        """
        from time import sleep

        env = self._get_or_create_env(
            self.apply_env_name, desc='tdstone2 Apply user environment',
        )

        if self.apply_libs:
            # Skip already-installed libs. env.libs returns a DataFrame with a
            # 'name' (or 'package') column listing installed packages. Match
            # case-insensitively on the bare package name (drop version pins).
            try:
                installed_df = env.libs
                installed_names = set()
                if installed_df is not None and not installed_df.empty:
                    name_col = 'name' if 'name' in installed_df.columns else (
                        'package' if 'package' in installed_df.columns else installed_df.columns[0]
                    )
                    installed_names = {str(n).strip().lower() for n in installed_df[name_col].tolist()}
            except Exception as e:
                logger.warning(f"Could not list installed libs for '{self.apply_env_name}': {e}. Will attempt full install.")
                installed_names = set()

            def _bare_name(spec):
                # Strip version pins like 'numpy==1.26', 'pandas>=2.0', 'scikit-learn~=1.4'.
                for sep in ('==', '>=', '<=', '~=', '!=', '>', '<', '='):
                    if sep in spec:
                        return spec.split(sep, 1)[0].strip().lower()
                return spec.strip().lower()

            missing = [lib for lib in self.apply_libs if _bare_name(lib) not in installed_names]

            if not missing:
                logger.info(
                    f"All required libraries already installed in '{self.apply_env_name}': "
                    f"{self.apply_libs}. Skipping install_lib."
                )
            else:
                already = [lib for lib in self.apply_libs if _bare_name(lib) in installed_names]
                if already:
                    logger.info(f"Already installed in '{self.apply_env_name}': {already}")
                logger.info(
                    f"Installing missing libraries {missing} into Apply env '{self.apply_env_name}' (async)."
                )
                try:
                    claim_id = env.install_lib(missing, asynchronous=True)
                    if isinstance(claim_id, str):
                        stage = env.status(claim_id)['Stage'].iloc[-1]
                        while stage not in ('Finished', 'Errored', 'File Installed'):
                            stage = env.status(claim_id)['Stage'].iloc[-1]
                            logger.info(f"install_lib stage '{stage}' (claim {claim_id})")
                            sleep(2)
                        if stage == 'Errored':
                            raise RuntimeError(
                                f"install_lib reported 'Errored' for claim {claim_id} in env '{self.apply_env_name}'"
                            )
                except Exception as e:
                    logger.error(f"install_lib failed for env '{self.apply_env_name}': {str(e)}")
                    raise

        return env

    def install_scripts(self):
        """Re-push every STO Python script (training, scoring, feature engineering,
        embeddings, seq2seq, ...) to Vantage without touching any repository tables.

        Use this after upgrading tdstone2, or after editing the bundled scripts under
        tdstone2/data/, so AMP-side execution picks up the new code on the next
        train()/score() call. Routes to PushFile() on Vantage Enterprise (no oaf_env)
        or PushFile_Lake() on Vantage Cloud Lake.
        """
        from tdstone2 import __version__
        if self.oaf_env is not None:
            backend = "PushFile_Lake"
        elif not self.use_apply:
            backend = "PushFile"
        else:
            backend = "skip-legacy (Apply-only)"
        logger.info(
            "Re-installing %d STO scripts via %s (tdstone2==%s, source=%s)",
            len(file_list), backend, __version__, os.path.join(this_dir, "data"),
        )
        if self.oaf_env is not None:
            self.PushFile_Lake()
            logger.info("STO scripts re-installed: %s", ', '.join(file_list))
        elif not self.use_apply:
            self.PushFile()
            logger.info("STO scripts re-installed: %s", ', '.join(file_list))
        else:
            logger.info("Apply-only mode: skipping legacy STO scripts re-install.")

        if self.use_apply:
            self.ensure_apply_env()
            logger.info(
                "Re-installing %d Apply scripts into env '%s'",
                len(APPLY_FILES), self.apply_env_name,
            )
            self.PushFile_Lake(target_env=self.apply_env_name, files=APPLY_FILES)
            logger.info("Apply scripts re-installed: %s", ', '.join(APPLY_FILES))

    def setup(self, install_files=True, create_env=False, oaf_env_name='tdstone2_lake', base_env=None):
        """Set up repository tables and (optionally) install STO/Apply scripts.

        Parameters:
            install_files (bool):
                If True, install the STO/Apply Python scripts after creating
                repositories. Defaults to True.
            create_env (bool):
                If True and the legacy Lake env (``self.oaf_env``) doesn't yet
                exist, create it. When ``self.oaf_env`` is None, falls back to
                ``oaf_env_name`` and assigns it to ``self.oaf_env``. Defaults
                to False — missing envs raise instead of being auto-created.
            oaf_env_name (str):
                Name to use when ``create_env=True`` and ``self.oaf_env`` is
                None. Defaults to ``'tdstone2_lake'``.
            base_env (str):
                Lake base env (Python runtime) to pass to ``tdml.create_env``.
                When None, falls back to ``self.base_env`` (default
                ``'python_3.10'``). Set this if your cluster doesn't have
                ``python_3.10`` available — the demo notebook's pattern of
                listing base envs first is unreliable when VCL's
                ``list_base_envs`` endpoint is flaky.

        Repository tables created:
            Code, Model, Mapper, HyperModel, Feature Engineering Process.
        """
        if base_env is not None:
            self.base_env = base_env

        logger.info("Starting setup: Creating repositories.")

        self._create_code_repository()
        logger.info("Code repository created.")

        self._create_model_repository()
        logger.info("Model repository created.")

        self._create_mapper_repository()
        logger.info("Mapper repository created.")

        self._create_hypermodel_repository()
        logger.info("Hypermodel repository created.")

        self._create_feature_engineering_process_repository()
        logger.info("Feature engineering process repository created.")

        # Optionally provision the legacy Lake env. When create_env=True the
        # missing-env case is handled here so PushFile_Lake doesn't crash.
        if create_env:
            if self.oaf_env is None:
                self.oaf_env = oaf_env_name
                logger.info(
                    "create_env=True and oaf_env was unset; using default '%s'.",
                    self.oaf_env,
                )
            self._get_or_create_env(
                self.oaf_env, desc='tdstone2 legacy Script-on-Lake environment',
            )

        # Conditional file installation based on environment and install_files flag
        if install_files:
            if self.oaf_env is not None:
                logger.info(
                    "Installing legacy STO scripts into Lake env '%s' with PushFile_Lake.",
                    self.oaf_env,
                )
                self.PushFile_Lake()
            elif not self.use_apply:
                # Vantage Enterprise (no oaf_env, no use_apply) → SYSUIF install.
                logger.info("Environment detected as Vantage Enterprise. Starting file installation with PushFile.")
                self.PushFile()
            else:
                # Apply-only mode on Lake: no oaf_env set, only the Apply env is needed.
                logger.info(
                    "Apply-only mode (no oaf_env): skipping legacy STO file install."
                )

            if self.use_apply:
                logger.info(
                    "use_apply=True: provisioning Apply env '%s' and installing Apply scripts.",
                    self.apply_env_name,
                )
                self.ensure_apply_env()
                self.PushFile_Lake(target_env=self.apply_env_name, files=APPLY_FILES)

        logger.info("Setup complete.")
####################################################################################################
#
#               CCCCC   OOOOO  DDDDD   EEEEEEE 
#              CC    C OO   OO DD  DD  EE      
#              CC      OO   OO DD   DD EEEEE   
#              CC    C OO   OO DD   DD EE      
#               CCCCC   OOOO0  DDDDDD  EEEEEEE 
#
####################################################################################################  

    @execute_query
    def _create_code_repository(self):
        """
        Create a code repository in the TDStone system.

        Returns:
            query: SQL query to create the code repository.
        """        
        query = f"""
            CREATE MULTISET TABLE {self.schema_name}.{self.code_repository}{self._table_options()}
            (
                ID VARCHAR(36) NOT NULL,
                CODE_TYPE VARCHAR(255) CHARACTER SET UNICODE NOT CASESPECIFIC NOT NULL,
                CODE BLOB,
                METADATA JSON(32000),{self._temporal_columns()}
            )
            PRIMARY INDEX (ID);
        """
        return query
    
    def list_codes(self, with_full_script = False, current_only = True):
        """
        List the code in the TDStone system.

        Args:
            with_full_script (bool, optional): If True, the full script is listed. Defaults to False.
            current_only (bool, optional): If True, only the current version is listed. Defaults to True.

        Returns:
            DataFrame: A DataFrame with the code details.
        """        
        if current_only:
            query = self._vt() + "\n"
        else:
            query = ''
            
        query = query + 'SELECT \n'
        
        if with_full_script:
            query = query + '* \n'
        else:
            if current_only:
                query = query + ',\n'.join(['ID','CODE_TYPE','METADATA'])
            else:
                query = query + ',\n'.join(['ID','CODE_TYPE','METADATA','ValidStart','ValidEnd'])
                
        query = query + f'\n FROM {self.schema_name}.{self.code_repository}'

        return self._query_df(query)
    
    @execute_query
    def remove_codes(self, code_id):
        """
        Remove a code from the TDStone system.

        Args:
            code_id (str or list): The ID or list of IDs of the code to be removed.

        Returns:
            query: SQL query to remove the code.
        """        
        if type(code_id) == list:
            code_list = ",".join(["'"+x+"'" for x in code_id])
            query = f"""
                DELETE {self.schema_name}.{self.code_repository} WHERE ID IN ({code_list});
                """
        else:
            query = f"""
                DELETE {self.schema_name}.{self.code_repository} WHERE ID = '{code_id}';
                """
        
        return query

####################################################################################################
#
#              MM    MM  OOOOO  DDDDD   EEEEEEE LL      
#              MMM  MMM OO   OO DD  DD  EE      LL      
#              MM MM MM OO   OO DD   DD EEEEE   LL      
#              MM    MM OO   OO DD   DD EE      LL      
#              MM    MM  OOOO0  DDDDDD  EEEEEEE LLLLLLL 
#
####################################################################################################    
    @execute_query
    def _create_model_repository(self):
        """
        Create a model repository in the TDStone system.

        Returns:
            query: SQL query to create the model repository.
        """        
        query = f"""
        CREATE MULTISET TABLE {self.schema_name}.{self.model_repository}{self._table_options()}
        (
            ID VARCHAR(36) NOT NULL,
            ID_CODE VARCHAR(36),
            ARGUMENTS VARCHAR(32000) CHARACTER SET UNICODE NOT CASESPECIFIC NOT NULL, --JSON(32000),
            METADATA JSON(32000),{self._temporal_columns()}
        )
        PRIMARY INDEX (ID_CODE);
        """
        return query
    
    def list_models(self, current_only = True):
        """
        List the models in the TDStone system.

        Args:
            with_full_script (bool, optional): If True, the full script is listed. Defaults to False.
            current_only (bool, optional): If True, only the current version is listed. Defaults to True.

        Returns:
            DataFrame: A DataFrame with the model details.
        """        
        if current_only:
            query = self._vt() + "\n"
        else:
            query = ''
            
        query = query + 'SELECT \n'
        
        if current_only:
            query = query + ',\n'.join(['ID','ID_CODE','ARGUMENTS','METADATA'])
        else:
            query = query + ',\n'.join(['ID','ID_CODE','ARGUMENTS','METADATA','ValidStart','ValidEnd'])
                
        query = query + f'\n FROM {self.schema_name}.{self.model_repository}'

        return self._query_df(query)
    
    @execute_query
    def remove_models(self, model_id):
        """
        Remove a model from the TDStone system.

        Args:
            model_id (str or list): The ID or list of IDs of the model to be removed.

        Returns:
            query: SQL query to remove the model.
        """        
        if type(model_id) == list:
            model_list = ",".join(["'"+x+"'" for x in model_id])
            query = f"""
                DELETE {self.schema_name}.{self.model_repository} WHERE ID IN ({model_list});
                """
        else:
            query = f"""
                DELETE {self.schema_name}.{self.model_repository} WHERE ID = '{model_id}';
                """
        
        return query  
    
####################################################################################################
#
#              MM    MM   AAA   PPPPPP  PPPPPP  EEEEEEE RRRRRR  
#              MMM  MMM  AAAAA  PP   PP PP   PP EE      RR   RR 
#              MM MM MM AA   AA PPPPPP  PPPPPP  EEEEE   RRRRRR  
#              MM    MM AAAAAAA PP      PP      EE      RR  RR  
#              MM    MM AA   AA PP      PP      EEEEEEE RR   RR 
#
####################################################################################################

                                                   
    @execute_query
    def _create_mapper_repository(self):
        """
        Create a mapper repository in the TDStone system.

        Returns:
            query: SQL query to create the mapper repository.
        """        
        query = f"""
            CREATE MULTISET TABLE {self.schema_name}.{self.mapper_repository}{self._table_options()}
            (
                ID VARCHAR(36) NOT NULL,
                MAPPER_TYPE VARCHAR(255) CHARACTER SET UNICODE,
                TABLE_NAME VARCHAR(255) CHARACTER SET UNICODE,
                CODE_REPOSITORY VARCHAR(255) CHARACTER SET UNICODE,
                MODEL_REPOSITORY VARCHAR(255) CHARACTER SET UNICODE,
                TRAINED_MODEL_REPOSITORY VARCHAR(255) CHARACTER SET UNICODE,
                FEATURE_REPOSITORY VARCHAR(255) CHARACTER SET UNICODE,
                SCORES_REPOSITORY VARCHAR(255) CHARACTER SET UNICODE,
                DATASET_OBJECT VARCHAR(2000) CHARACTER SET UNICODE NOT CASESPECIFIC,
                COL_ID_ROW VARCHAR(2000) CHARACTER SET UNICODE NOT CASESPECIFIC,
                COL_ID_PARTITION VARCHAR(2000) CHARACTER SET UNICODE NOT CASESPECIFIC,
                COL_FOLD VARCHAR(2000) CHARACTER SET UNICODE NOT CASESPECIFIC,
                ON_CLAUSE_VIEW VARCHAR(2000) CHARACTER SET UNICODE NOT CASESPECIFIC,
                STO_VIEW VARCHAR(2000) CHARACTER SET UNICODE NOT CASESPECIFIC,
                METADATA JSON(32000),{self._temporal_columns()}
            )
            PRIMARY INDEX (ID);
            """
        return query
    
    def list_mappers(self, current_only = True, mapper_type = None):
        """
        List the mappers in the TDStone system.

        Args:
            with_full_script (bool, optional): If True, the full script is listed. Defaults to False.
            current_only (bool, optional): If True, only the current version is listed. Defaults to True.

        Returns:
            DataFrame: A DataFrame with the model details.
        """        
        if current_only:
            query = self._vt() + "\n"
        else:
            query = ''
            
        query = query + 'SELECT * \n'
        
               
        query = query + f'\n FROM {self.schema_name}.{self.mapper_repository}'
        
        if mapper_type is not None:
            query = query + f"\n WHERE MAPPER_TYPE = '{mapper_type}'"

        return self._query_df(query)
    
    @execute_query
    def remove_mappers(self, mapper_id):
        """
        Remove a model from the TDStone system.

        Args:
            model_id (str or list): The ID or list of IDs of the mapper to be removed.

        Returns:
            query: SQL query to remove the model.
        """        
        if type(mapper_id) == list and len(mapper_id)>0:
            mapper_list = ",".join(["'"+x+"'" for x in mapper_id])
            query = f"""
                DELETE {self.schema_name}.{self.mapper_repository} WHERE ID IN ({mapper_list});
                """
        else:
            query = f"""
                DELETE {self.schema_name}.{self.mapper_repository} WHERE ID = '{mapper_id}';
                """
        
        return query  
    
####################################################################################################
#
# ooooo   ooooo oooooo   oooo ooooooooo.   oooooooooooo ooooooooo.   ooo        ooooo   .oooooo.   oooooooooo.   oooooooooooo ooooo        
# `888'   `888'  `888.   .8'  `888   `Y88. `888'     `8 `888   `Y88. `88.       .888'  d8P'  `Y8b  `888'   `Y8b  `888'     `8 `888'        
#  888     888    `888. .8'    888   .d88'  888          888   .d88'  888b     d'888  888      888  888      888  888          888         
#  888ooooo888     `888.8'     888ooo88P'   888oooo8     888ooo88P'   8 Y88. .P  888  888      888  888      888  888oooo8     888         
#  888     888      `888'      888          888    "     888`88b.     8  `888'   888  888      888  888      888  888    "     888         
#  888     888       888       888          888       o  888  `88b.   8    Y     888  `88b    d88'  888     d88'  888       o  888       o 
# o888o   o888o     o888o     o888o        o888ooooood8 o888o  o888o o8o        o888o  `Y8bood8P'  o888bood8P'   o888ooooood8 o888ooooood8 
#
####################################################################################################

                                                   
    @execute_query
    def _create_hypermodel_repository(self):
        """
        Create a mapper repository in the TDStone system.

        Returns:
            query: SQL query to create the mapper repository.
        """        
        query = f"""
            CREATE MULTISET TABLE {self.schema_name}.{self.hyper_model_repository}{self._table_options()}
            (
                CREATION_DATE TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
                ID VARCHAR(36) NOT NULL,
                ID_MODEL VARCHAR(36) NOT NULL,
                ID_MAPPER_TRAINING VARCHAR(36) NOT NULL,
                ID_MAPPER_SCORING VARCHAR(36) NOT NULL,
                METADATA JSON(32000)
            )
            PRIMARY INDEX (ID);
            """
        return query
    
    def list_hyper_models(self):
        """
        List the hyper models in the TDStone system.

        Returns:
            DataFrame: A DataFrame with the hyper model details.
        """        
            
        query = 'SELECT * \n'
        
               
        query = query + f'\n FROM {self.schema_name}.{self.hyper_model_repository}'

        return self._query_df(query)
    
    @execute_query
    def remove_hyper_models(self, hyper_model_id):
        """
        Remove a hyper model from the TDStone system.

        Args:
            model_id (str or list): The ID or list of IDs of the mapper to be removed.

        Returns:
            query: SQL query to remove the model.
        """        
        if type(hyper_model_id) == list and len(hyper_model_id)>0:
            hyper_model_list = ",".join(["'"+x+"'" for x in hyper_model_id])
            query = f"""
                DELETE {self.schema_name}.{self.hyper_model_repository} WHERE ID IN ({hyper_model_list});
                """
        else:
            query = f"""
                DELETE {self.schema_name}.{self.hyper_model_repository} WHERE ID = '{hyper_model_id}';
                """
        
        return query

    ####################################################################################################
    #
    #    oooooooooooo oooooooooooo       .o.       ooooooooooooo ooooo     ooo ooooooooo.   oooooooooooo      oooooooooooo ooooo      ooo   .oooooo.    ooooo ooooo      ooo oooooooooooo oooooooooooo ooooooooo.   ooooo ooooo      ooo   .oooooo.    
    # `888'     `8 `888'     `8      .888.      8'   888   `8 `888'     `8' `888   `Y88. `888'     `8      `888'     `8 `888b.     `8'  d8P'  `Y8b   `888' `888b.     `8' `888'     `8 `888'     `8 `888   `Y88. `888' `888b.     `8'  d8P'  `Y8b   
    #  888          888             .8"888.          888       888       8   888   .d88'  888               888          8 `88b.    8  888            888   8 `88b.    8   888          888          888   .d88'  888   8 `88b.    8  888           
    #  888oooo8     888oooo8       .8' `888.         888       888       8   888ooo88P'   888oooo8          888oooo8     8   `88b.  8  888            888   8   `88b.  8   888oooo8     888oooo8     888ooo88P'   888   8   `88b.  8  888           
    #  888    "     888    "      .88ooo8888.        888       888       8   888`88b.     888    "          888    "     8     `88b.8  888     ooooo  888   8     `88b.8   888    "     888    "     888`88b.     888   8     `88b.8  888     ooooo 
    #  888          888       o  .8'     `888.       888       `88.    .8'   888  `88b.   888       o       888       o  8       `888  `88.    .88'   888   8       `888   888       o  888       o  888  `88b.   888   8       `888  `88.    .88'  
    # o888o        o888ooooood8 o88o     o8888o     o888o        `YbodP'    o888o  o888o o888ooooood8      o888ooooood8 o8o        `8   `Y8bood8P'   o888o o8o        `8  o888ooooood8 o888ooooood8 o888o  o888o o888o o8o        `8   `Y8bood8P'   

    #
    ####################################################################################################

    @execute_query
    def _create_feature_engineering_process_repository(self):
        """
        Create a mapper repository in the TDStone system.

        Returns:
            query: SQL query to create the mapper repository.
        """
        query = f"""
            CREATE MULTISET TABLE {self.schema_name}.{self.feature_engineering_process_repository}{self._table_options()}
            (
                CREATION_DATE TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
                ID VARCHAR(36) NOT NULL,
                ID_MODEL VARCHAR(36) NOT NULL,
                ID_MAPPER VARCHAR(36) NOT NULL,
                FEATURE_ENGINEERING_TYPE VARCHAR(255) NOT NULL,
                METADATA JSON(32000)
            )
            PRIMARY INDEX (ID);
            """
        return query

    def list_feature_engineering_models(self):
        """
        List the hyper models in the TDStone system.

        Returns:
            DataFrame: A DataFrame with the hyper model details.
        """

        query = 'SELECT * \n'

        query = query + f'\n FROM {self.schema_name}.{self.feature_engineering_process_repository}'

        return self._query_df(query)

    @execute_query
    def remove_feature_engineering_models(self, feature_engineering_process_id):
        """
        Remove a hyper model from the TDStone system.

        Args:
            model_id (str or list): The ID or list of IDs of the mapper to be removed.

        Returns:
            query: SQL query to remove the model.
        """
        if type(feature_engineering_process_id) == list and len(feature_engineering_process_id) > 0:
            feature_engineering_process_list = ",".join(["'" + x + "'" for x in feature_engineering_process_id])
            query = f"""
                DELETE {self.schema_name}.{self.feature_engineering_process_repository} WHERE ID IN ({feature_engineering_process_list});
                """
        else:
            query = f"""
                DELETE {self.schema_name}.{self.feature_engineering_process_repository} WHERE ID = '{feature_engineering_process_id}';
                """

        return query