from tdstone2.tdstone import TDStone
from tdstone2.tdscode import Code
from tdstone2.tdsmodel import Model
from tdstone2.tdsmapper import Mapper
from tdstone2.utils import execute_query,get_partition_datatype, get_sto_parameters, _raw_execute, _raw_query_apply_df
import os
import time
import uuid
import json
import logging
import teradataml as tdml

logger = logging.getLogger(__name__)


class HyperModel():
    """
    Initializes the HyperModel instance.

    Args:
        tdstone (TDStone): Instance of the TDStone class for database operations.
        id (str, optional): Unique identifier for the hypermodel process. Defaults to None.
        metadata (dict, optional): Metadata associated with the hypermodel process. Defaults to an empty dictionary.
        script_path (str, optional): Path to the script for model code. Defaults to None.
        model_parameters (dict, optional): Dictionary of model parameters. Defaults to None.
        dataset (str, optional): Name of the dataset being used. Defaults to None.
        id_row (str, optional): Identifier for the row. Defaults to None.
        id_partition (str, optional): Identifier for the partition. Defaults to None.
        id_fold (str, optional): Identifier for the fold. Defaults to None.
        fold_training (Any, optional): Specifies the fold for training. Defaults to None.
        skl_pipeline_steps (list, optional): Steps for the scikit-learn pipeline. Defaults to None.
        convert_to_onnx (bool, optional): Whether to convert the model to ONNX format. Defaults to False.
        store_pickle (bool, optional): Whether to store the model as a pickle file. Defaults to True.
    """
    def __init__(self, tdstone, id = None, metadata ={},
                 script_path = None,
                 model_parameters = None,
                 dataset = None,
                 id_row = None,
                 id_partition = None,
                 id_fold = None,
                 fold_training = None,
                 skl_pipeline_steps = None,
                 convert_to_onnx = False,
                 store_pickle = True
                ):
        
        self.id               = str(uuid.uuid4()) if id is None else id
        self.tdstone          = tdstone
        self.mapper_training  = None
        self.mapper_scoring   = None
        self.id_model         = None
        self.fold_training    = fold_training
        try:
            self.metadata = {'user': os.getlogin()}
        except Exception as e:
            self.metadata = {}
        self.metadata.update(metadata)
        self.dataset          = dataset

        if model_parameters is not None and 'target' not in model_parameters.keys():
            model_parameters['target'] = ''

        has_script   = script_path is not None and model_parameters is not None and dataset is not None and id_row is not None and id_partition is not None and fold_training is not None
        has_pipeline = skl_pipeline_steps is not None and model_parameters is not None and dataset is not None and id_row is not None and id_partition is not None and fold_training is not None

        if has_script or has_pipeline:
            source = 'script_path' if has_script else 'skl_pipeline_steps'
            logger.info(
                "Building HyperModel id=%s source=%s dataset=%s id_partition=%s id_row=%s id_fold=%s fold_training=%s",
                self.id, source, dataset, id_partition, id_row, id_fold, fold_training,
            )
            t0 = time.perf_counter()

            if has_script:
                logger.info("Registering Code from script_path=%s", script_path)
                mycode = Code(tdstone=self.tdstone)
                mycode.update_metadata(metadata)
                mycode.update_script(script_path)
                mycode.upload()

                arguments = {}
                arguments["sto_parameters"] = get_sto_parameters(tdml.DataFrame(self.dataset))
                arguments["model_parameters"] = model_parameters
            else:
                from tdstone2.model_maker.scikit_learn import extract_explicit_hyperparameters, generate_code_skl_pipeline
                step_names = [name for name, _ in skl_pipeline_steps]
                logger.info("Generating sklearn pipeline code from steps=%s", step_names)
                model_parameters["arguments"] = extract_explicit_hyperparameters(skl_pipeline_steps)
                script = generate_code_skl_pipeline(skl_pipeline_steps)

                logger.info("Registering Code (auto-generated, %d chars)", len(script))
                mycode = Code(tdstone=self.tdstone)
                mycode.update_metadata(metadata)
                mycode.update_script_code(script)
                mycode.upload()

                arguments = {}
                arguments["sto_parameters"] = get_sto_parameters(tdml.DataFrame(self.dataset))
                output_format = []
                if convert_to_onnx:
                    output_format.append('onnx')
                if store_pickle:
                    output_format.append('pickle')
                arguments["sto_parameters"]['output_format'] = output_format
                arguments["model_parameters"] = model_parameters
                logger.info("Output formats: %s", output_format or ['<none>'])

            logger.debug("Code uploaded id=%s", mycode.id)

            model = Model(tdstone=self.tdstone)
            model.attach_code(mycode.id)
            model.update_arguments(arguments)
            model.update_metadata(metadata)
            model.upload()
            self.id_model = model.id
            logger.info("Model registered id_model=%s id_code=%s", self.id_model, mycode.id)

            logger.info("Creating training mapper")
            self.mapper_training = Mapper(tdstone=self.tdstone,
                                          mapper_type  = 'training',
                                          id_row       = id_row,
                                          id_partition = id_partition,
                                          id_fold      = id_fold,
                                          dataset      = dataset
                                         )
            self.mapper_training.upload()
            self.mapper_training.fill_mapping_full(model_id=self.id_model)
            self.mapper_training.create_on_clause(fold=self.fold_training)
            self.mapper_training.create_sto_view()
            logger.info("Training mapper ready id=%s", self.mapper_training.id)

            logger.info("Creating scoring mapper")
            # Reuse types/columns from the training mapper to avoid a second
            # SELECT against the dataset (flaky on VCL OFS schemas after DDL).
            self.mapper_scoring = Mapper(tdstone=self.tdstone,
                                         mapper_type  = 'scoring',
                                         id_row       = self.mapper_training.id_row,
                                         id_partition = self.mapper_training.id_partition,
                                         id_fold      = self.mapper_training.id_fold,
                                         dataset      = self.mapper_training.dataset,
                                         dataset_columns = self.mapper_training.dataset_columns,
                                         types        = self.mapper_training.types,
                                         trained_model_repository = self.mapper_training.trained_model_repository
                                        )
            self.mapper_scoring.upload()
            self.mapper_scoring.create_on_clause()
            # The volatile-table workaround is needed only on the Script path.
            # Apply reads the on-clause view directly; VCL also rejects CREATE
            # VOLATILE with CLOB columns (Error 3732), so skip on Apply.
            if not getattr(self.mapper_scoring, '_use_apply', lambda: False)():
                self.mapper_scoring.create_volatile_table_on_clause()
            self.mapper_scoring.create_sto_view()
            self.mapper_scoring.fill_mapping_full(model_id=self.id_model)
            logger.info("Scoring mapper ready id=%s", self.mapper_scoring.id)

            self._register_hyper_model()
            logger.info(
                "HyperModel ready id=%s id_model=%s mapper_training=%s mapper_scoring=%s elapsed=%.2fs",
                self.id, self.id_model, self.mapper_training.id, self.mapper_scoring.id,
                time.perf_counter() - t0,
            )
        else:
            logger.debug("HyperModel id=%s instantiated without arguments (use download() to load existing)", self.id)
            
    @execute_query
    def _register_hyper_model(self):
        """
        Registers the hypermodel in the database by inserting relevant details into a designated repository table.

        Returns:
            str: SQL query for registering the hypermodel in the database.
        """

        query = f"""
        INSERT INTO {self.tdstone.schema_name}.{self.tdstone.hyper_model_repository}
            (ID, ID_MODEL, ID_MAPPER_TRAINING, ID_MAPPER_SCORING, METADATA)
             VALUES
            ('{self.id}',
             '{self.id_model}',
             '{self.mapper_training.id}',
             '{self.mapper_scoring.id}',
             '{json.dumps(self.metadata).replace("'", '"')}');
        """
        logger.info(
            "Registering HyperModel in %s.%s id=%s",
            self.tdstone.schema_name, self.tdstone.hyper_model_repository, self.id,
        )
        return query
        
        
        
    def train(self, full_mapping_update = True, report = True):
        """
        Executes the training process for the hypermodel by updating mappings and executing the mapper for training.

        Parameters:
            full_mapping_update (bool, optional): Determines whether a full mapping update is required. Defaults to True.
            report (bool, optional): Display an inline HTML insight report
                with partition / chunk / worker-error breakdown after the run.
                Defaults to True. Set to False to skip (e.g. headless runs).
        """
        logger.info(
            "train start hyper_model=%s id_model=%s mapper=%s repository=%s.%s full_mapping_update=%s",
            self.id, self.id_model, self.mapper_training.id,
            self.tdstone.schema_name, self.mapper_training.trained_model_repository,
            full_mapping_update,
        )
        t0 = time.perf_counter()
        # Capture the Teradata-side wall clock before execute_mapper so we can isolate
        # this call's rows in the (non-idempotent) trained-model repository. Using the
        # server clock — not Python's — avoids client/server skew.
        try:
            t_start = _raw_execute("SELECT CURRENT_TIMESTAMP(6)")[0][0]
        except Exception:
            t_start = None
            logger.debug("Could not capture Teradata CURRENT_TIMESTAMP — success/failure counts will be skipped")
        try:
            if full_mapping_update:
                logger.info("Refreshing training mapper partitions")
                self.mapper_training.fill_mapping_full(model_id=self.id_model)
            logger.info("Executing training mapper (STO)")
            self.mapper_training.execute_mapper()
        except Exception:
            logger.exception("train failed hyper_model=%s id_model=%s", self.id, self.id_model)
            raise
        tally = self._count_trained_models_since(t_start) if t_start is not None else None
        elapsed = time.perf_counter() - t0
        if tally is None:
            logger.info("train done hyper_model=%s elapsed=%.2fs", self.id, elapsed)
        else:
            n_real_fail   = tally['fail_partitions']
            n_worker_err  = tally['worker_errors']
            level = logger.info if n_real_fail == 0 else logger.warning
            level(
                "train done hyper_model=%s elapsed=%.2fs "
                "successful=%d partitions (%d chunks) "
                "failed=%d partitions (%d chunks) "
                "worker_errors=%d",
                self.id, elapsed,
                tally['ok_partitions'], tally['ok_chunks'],
                tally['fail_partitions'], tally['fail_chunks'],
                n_worker_err,
            )
            if n_real_fail > 0:
                # Sample real-partition failures (excluding worker-error sentinels)
                # so the user sees WHICH partition failed and WHY.
                for part_repr, status in self._sample_failed_partitions(
                    t_start, limit=3, exclude_sentinel=True,
                ):
                    logger.warning("  failed partition %s — %s", part_repr, status)
            if n_worker_err > 0:
                # Worker-error rows have Partition_ID = -1 — they came from worker
                # spawns that never received real partition data (empty input, JSON
                # parse failure, etc.). They are NOT associated with a real
                # partition and should be triaged as worker plumbing issues.
                for part_repr, status in self._sample_failed_partitions(
                    t_start, limit=3, only_sentinel=True,
                ):
                    logger.info("  worker error (no partition data) %s — %s", part_repr, status)
            if tally['ok_partitions'] == 0 and n_real_fail == 0 and n_worker_err == 0:
                logger.warning(
                    "No rows were inserted into %s.%s for this run. The STO likely "
                    "crashed (e.g. SIGSEGV in a native extension) — check the AMP "
                    "error logs. Re-running model.train() will create new rows.",
                    self.tdstone.schema_name, self.mapper_training.trained_model_repository,
                )
        if report:
            self._maybe_display_html(self._build_train_report(t_start, elapsed, tally))
        return

    def _count_trained_models_since(self, t_start):
        """Tally trained-model rows inserted at or after ``t_start`` for this
        hyper-model's id_model. Returns a dict::

            {'ok_partitions':   <distinct successful partitions>,
             'ok_chunks':       <total successful rows>,
             'fail_partitions': <distinct failed partitions, excluding sentinel>,
             'fail_chunks':     <failed rows for those partitions>,
             'worker_errors':   <failed rows where the first partition col = -1>}

        ``worker_errors`` are sentinel rows from Apply workers that fired without
        receiving real partition data (empty stdin, malformed JSON args, etc.).
        They carry ``Partition_ID = -1`` (cast to VARCHAR for type-safety) and
        are *not* associated with a real partition — keeping them separate from
        ``fail_partitions`` keeps the success / failure tally meaningful when
        the cluster spawns more workers than there are partitions.

        Counting distinct partitions (rather than row counts) matters because
        the trained-model repo stores ONE ROW PER CHUNK of the pickled model:
        a partition with a 600 KB pickle becomes ~10 rows of VARCHAR(64000).
        Chunk count varies per partition, so dividing total rows by a constant
        gives the wrong partition count.

        Best-effort — returns ``None`` if the query fails (e.g. permission,
        table absent).
        """
        partition_cols = [c.strip() for c in self.mapper_training.id_partition.split(',') if c.strip()]
        first_part = partition_cols[0] if partition_cols else 'Partition_ID'
        sentinel_pred = f"CAST({first_part} AS VARCHAR(64)) = '-1'"
        sql = f"""
        SELECT
            COUNT(DISTINCT CASE
                WHEN STATUS LIKE '%successful%' AND NOT ({sentinel_pred})
                THEN {first_part} END) AS ok_partitions,
            COALESCE(SUM(CASE WHEN STATUS LIKE '%successful%' THEN 1 ELSE 0 END), 0) AS ok_chunks,
            COUNT(DISTINCT CASE
                WHEN STATUS NOT LIKE '%successful%' AND NOT ({sentinel_pred})
                THEN {first_part} END) AS fail_partitions,
            COALESCE(SUM(CASE
                WHEN STATUS NOT LIKE '%successful%' AND NOT ({sentinel_pred}) THEN 1
                ELSE 0 END), 0) AS fail_chunks,
            COALESCE(SUM(CASE
                WHEN STATUS NOT LIKE '%successful%' AND ({sentinel_pred}) THEN 1
                ELSE 0 END), 0) AS worker_errors
        FROM {self.tdstone.schema_name}.{self.mapper_training.trained_model_repository}
        WHERE TD_TIMECODE >= CAST('{t_start}' AS TIMESTAMP(6) WITH TIME ZONE)
          AND ID_MODEL = '{self.id_model}'
        """
        try:
            rows = _raw_execute(sql)
            row = rows[0] if rows else None
            if row is None:
                return None
            return {
                'ok_partitions':   int(row[0]),
                'ok_chunks':       int(row[1]),
                'fail_partitions': int(row[2]),
                'fail_chunks':     int(row[3]),
                'worker_errors':   int(row[4]),
            }
        except Exception:
            logger.debug("Failed to tally trained-model counts since %s", t_start, exc_info=True)
            return None

    def _sample_failed_partitions(self, t_start, limit=3, status_chars=300,
                                  exclude_sentinel=False, only_sentinel=False):
        """Yield up to ``limit`` (partition_repr, status_excerpt) tuples for rows
        that failed during this run. Best-effort — yields nothing on query error.

        ``exclude_sentinel=True`` skips rows with first-partition-col = -1
        (worker-error sentinels). ``only_sentinel=True`` does the opposite.
        Mutually exclusive; pass one or neither.
        """
        partition_cols = [c.strip() for c in self.mapper_training.id_partition.split(',') if c.strip()]
        first_part = partition_cols[0] if partition_cols else 'Partition_ID'
        sentinel_pred = f"CAST({first_part} AS VARCHAR(64)) = '-1'"
        extra = ""
        if exclude_sentinel:
            extra = f"\n          AND NOT ({sentinel_pred})"
        elif only_sentinel:
            extra = f"\n          AND ({sentinel_pred})"
        sql = f"""
        SELECT TOP {int(limit)}
            {', '.join(partition_cols)},
            SUBSTR(STATUS, 1, {int(status_chars)}) AS STATUS_EXCERPT
        FROM {self.tdstone.schema_name}.{self.mapper_training.trained_model_repository}
        WHERE TD_TIMECODE >= CAST('{t_start}' AS TIMESTAMP(6) WITH TIME ZONE)
          AND ID_MODEL = '{self.id_model}'
          AND STATUS NOT LIKE '%successful%'{extra}
        """
        try:
            rows = _raw_execute(sql)
        except Exception:
            logger.debug("Failed to sample failing partitions since %s", t_start, exc_info=True)
            return
        for row in rows:
            part_vals = row[:len(partition_cols)]
            status = row[-1]
            part_repr = ', '.join(f"{c}={v}" for c, v in zip(partition_cols, part_vals))
            yield part_repr, status

    # --------------------------------------------------------------------- #
    # HTML insight reports (rendered after train() / score() unless          #
    # ``report=False`` is passed). Plain HTML — no external CSS/JS, fits    #
    # in a notebook cell output without any deps.                           #
    # --------------------------------------------------------------------- #
    def _maybe_display_html(self, html):
        """Display ``html`` via IPython if available; otherwise no-op.

        Calling code never has to check whether it's running in a notebook —
        ``train()`` / ``score()`` always invoke this; outside Jupyter it
        silently does nothing.
        """
        if not html:
            return
        try:
            from IPython.display import display, HTML
            display(HTML(html))
        except Exception:
            logger.debug("IPython HTML display unavailable; skipping report.")

    def _fmt_secs(self, s):
        """Compact human-readable elapsed-seconds formatter."""
        if s is None:
            return '–'
        if s < 1.0:
            return f'{s*1000:.0f} ms'
        if s < 60:
            return f'{s:.2f} s'
        m = int(s // 60); rem = s - m*60
        return f'{m} min {rem:.1f} s'

    def _svg_hbar(self, items, bar_width=200, color='#4a90e2', fmt=str):
        """Build an HTML table with one horizontal SVG bar per ``items`` row.

        ``items`` is a sequence of ``(label, value)`` tuples — value can be int
        or float. Bar widths are scaled to the largest ``abs(value)`` in the
        list. ``fmt`` formats the right-hand value column. Self-contained
        inline SVG: no external CSS / JS, renders in any notebook viewer."""
        if not items:
            return '<div style="font-size:11px;color:#888">no data</div>'
        max_v = max(abs(float(v)) for _, v in items) or 1.0
        rows = []
        for label, val in items:
            bar_w = int((abs(float(val)) / max_v) * bar_width) if val else 0
            rows.append(
                f'<tr>'
                f'<td style="text-align:right;font-size:11px;font-family:monospace;'
                f'padding:1px 6px 1px 0;white-space:nowrap">{label}</td>'
                f'<td style="font-size:11px;width:{bar_width+8}px;padding:1px 0">'
                f'<svg width="{bar_width}" height="12">'
                f'<rect x="0" y="2" width="{bar_w}" height="8" fill="{color}"/>'
                f'</svg></td>'
                f'<td style="text-align:right;font-size:11px;font-family:monospace;'
                f'padding:1px 0 1px 6px">{fmt(val)}</td>'
                f'</tr>'
            )
        return f'<table style="border-collapse:collapse">{"".join(rows)}</table>'

    def _svg_histogram(self, values, bins=10, bar_width=200, color='#4a90e2', unit=''):
        """Bin ``values`` into ``bins`` buckets and render a horizontal-bar
        histogram via _svg_hbar. Useful for distribution-shape views (per-
        partition duration, per-batch timings, model size, …)."""
        vals = [float(v) for v in values if v is not None]
        if not vals:
            return '<div style="font-size:11px;color:#888">no data</div>'
        lo, hi = min(vals), max(vals)
        if lo == hi:
            return f'<div style="font-size:11px;color:#888">all values = {lo:.4g}{unit}</div>'
        span = hi - lo
        bin_size = span / bins
        counts = [0] * bins
        for v in vals:
            idx = min(int((v - lo) / bin_size), bins - 1)
            counts[idx] += 1
        def _r(x):
            return f'{x:.2g}{unit}'
        items = [
            (f'{_r(lo + i*bin_size)}–{_r(lo + (i+1)*bin_size)}', counts[i])
            for i in range(bins)
        ]
        return self._svg_hbar(items, bar_width=bar_width, color=color, fmt=str)

    def _build_train_report(self, t_start, elapsed, tally):
        """Build an HTML insight report summarising the just-completed train()."""
        if t_start is None or tally is None:
            return ""
        partition_cols = [c.strip() for c in self.mapper_training.id_partition.split(',') if c.strip()]
        first_part = partition_cols[0] if partition_cols else 'Partition_ID'
        repo = f"{self.tdstone.schema_name}.{self.mapper_training.trained_model_repository}"

        # Per-partition chunk count + model-size proxy (sum of CLOB lengths
        # across that partition's chunks). Training repos don't carry per-
        # partition wall-clock, so model size is the closest "complexity"
        # signal we can show.
        per_part_sql = f"""
        SELECT TOP 200
            {first_part} AS partition_id,
            COUNT(*)     AS n_chunks,
            MAX(MODEL_CHUNK_TOTAL) AS chunk_total,
            SUM(CHARACTER_LENGTH(SUBSTRING(TRAINED_MODEL FROM 1 FOR 100000))) AS model_chars
        FROM {repo}
        WHERE TD_TIMECODE >= CAST('{t_start}' AS TIMESTAMP(6) WITH TIME ZONE)
          AND ID_MODEL = '{self.id_model}'
          AND STATUS LIKE '%successful%'
          AND CAST({first_part} AS VARCHAR(64)) <> '-1'
        GROUP BY {first_part}
        ORDER BY n_chunks DESC, partition_id
        """
        try:
            per_part = _raw_execute(per_part_sql) or []
        except Exception:
            per_part = []

        # Per-partition input-row count from the underlying dataset, filtered
        # by the training fold (rows the script actually saw at train time).
        # Best-effort: skipped silently if the dataset reference can't be
        # resolved or fold_training is None.
        input_rows_per_part = []
        try:
            ds = self.mapper_training.dataset
            id_fold = self.mapper_training.id_fold
            fold_val = getattr(self, 'fold_training', None)
            if ds and fold_val is not None:
                # self.mapper_training.dataset is an inlinable SQL fragment
                # (table name or "schema"."table"); wrap in DataFrame just to
                # get the column-quoting style without imposing fold at SQL
                # level when not present.
                input_sql = (
                    f"SELECT {first_part} AS partition_id, COUNT(*) AS n_input "
                    f"FROM {ds} "
                    f"WHERE {id_fold} = '{fold_val}' "
                    f"GROUP BY {first_part}"
                )
                input_rows_per_part = _raw_execute(input_sql) or []
        except Exception as e:
            logger.debug("train-report input-rows query failed: %s", e)
            input_rows_per_part = []

        # Worker-error sample (Partition_ID = -1 sentinels) — pull a few
        # status excerpts so the user can see WHY they fired.
        worker_err_sample = list(self._sample_failed_partitions(t_start, limit=5, only_sentinel=True))

        ok_p   = tally['ok_partitions']
        ok_c   = tally['ok_chunks']
        fail_p = tally['fail_partitions']
        fail_c = tally['fail_chunks']
        werr   = tally['worker_errors']
        avg_chunks = (ok_c / ok_p) if ok_p else 0
        rows_per_min = (ok_p / (elapsed / 60)) if elapsed > 0 else 0

        head_color = '#d63b3b' if fail_p > 0 else ('#d49b00' if werr > 0 else '#2a8a2a')
        title = "training report"

        # Per-partition diagnostics — chunk distribution + model-size top/bottom.
        # Build them only if we got rows back from per_part_sql.
        size_rows = sorted(per_part, key=lambda r: int(r[3] or 0))  # by model_chars
        top_largest = list(reversed(size_rows[-10:]))                 # top 10 largest
        top_smallest = size_rows[:10]                                 # top 10 smallest

        def _kib(n):
            return f'{n/1024:.1f} KB' if n else '0'

        chunk_rows = '\n'.join(
            f'<tr><td style="text-align:right">{r[0]}</td>'
            f'<td style="text-align:right">{r[1]}</td>'
            f'<td style="text-align:right">{r[2]}</td>'
            f'<td style="text-align:right">{_kib(int(r[3] or 0))}</td></tr>'
            for r in per_part[:25]
        )
        if len(per_part) > 25:
            chunk_rows += f'<tr><td colspan="4" style="text-align:center;color:#888">…{len(per_part)-25} more partitions hidden…</td></tr>'

        # Histograms + top-N for distributions.
        chunk_hist_html = self._svg_histogram(
            [int(r[1] or 0) for r in per_part], bins=8, color='#4a90e2', unit=' ch')
        size_hist_html = self._svg_histogram(
            [int(r[3] or 0) for r in per_part], bins=8, color='#9c52d4', unit='B')
        top_largest_html = self._svg_hbar(
            [(f'partition {r[0]}', int(r[3] or 0)) for r in top_largest],
            color='#9c52d4', fmt=lambda v: _kib(v))
        top_smallest_html = self._svg_hbar(
            [(f'partition {r[0]}', int(r[3] or 0)) for r in top_smallest],
            color='#74b072', fmt=lambda v: _kib(v))

        # Input-row count distributions (only if the query succeeded).
        if input_rows_per_part:
            input_sorted = sorted(input_rows_per_part, key=lambda r: int(r[1] or 0))
            top_input_largest  = list(reversed(input_sorted[-10:]))
            top_input_smallest = input_sorted[:10]
            input_hist_html = self._svg_histogram(
                [int(r[1] or 0) for r in input_rows_per_part], bins=8, color='#4a90e2', unit=' rows')
            top_input_largest_html  = self._svg_hbar(
                [(f'partition {r[0]}', int(r[1] or 0)) for r in top_input_largest],
                color='#4a90e2', fmt=lambda v: f'{v:,}')
            top_input_smallest_html = self._svg_hbar(
                [(f'partition {r[0]}', int(r[1] or 0)) for r in top_input_smallest],
                color='#74b072', fmt=lambda v: f'{v:,}')
            input_block_html = (
                '<details style="margin-top:6px" open>'
                '<summary style="cursor:pointer;font-size:13px;color:#444">'
                'training input-row distribution + top 10 / tail 10'
                '</summary>'
                '<table style="margin-top:4px"><tr style="vertical-align:top">'
                '<td style="padding:0 16px 0 0">'
                '<div style="font-size:11px;color:#666;margin-bottom:2px"><b>input rows per partition</b></div>'
                f'{input_hist_html}</td>'
                '<td style="padding:0 16px 0 0">'
                '<div style="font-size:11px;color:#666;margin-bottom:2px"><b>top 10 largest input</b></div>'
                f'{top_input_largest_html}</td>'
                '<td>'
                '<div style="font-size:11px;color:#666;margin-bottom:2px"><b>top 10 smallest input (tail)</b></div>'
                f'{top_input_smallest_html}</td>'
                '</tr></table></details>'
            )
        else:
            input_block_html = ''

        worker_err_rows = ''.join(
            f'<tr><td style="white-space:nowrap">{p}</td>'
            f'<td style="font-family:monospace;font-size:11px">{(s or "")[:240]}</td></tr>'
            for p, s in worker_err_sample
        ) or '<tr><td colspan="2" style="color:#888;text-align:center">— none —</td></tr>'

        return f"""
        <div style="font-family:-apple-system,Segoe UI,sans-serif;border:1px solid #ddd;border-radius:6px;padding:10px 14px;margin:8px 0;max-width:920px;background:#fafafa">
          <div style="display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid #e2e2e2;padding-bottom:6px;margin-bottom:8px">
            <h3 style="margin:0;font-size:15px;color:{head_color}">tdstone2 / {title}</h3>
            <span style="font-size:11px;color:#777;font-family:monospace">hyper_model={self.id} id_model={self.id_model}</span>
          </div>
          <table style="border-collapse:collapse;width:100%;font-size:13px;margin-bottom:8px">
            <tr>
              <td style="padding:2px 8px"><b>elapsed</b></td><td style="padding:2px 8px">{self._fmt_secs(elapsed)}</td>
              <td style="padding:2px 8px"><b>partitions / min</b></td><td style="padding:2px 8px">{rows_per_min:.1f}</td>
              <td style="padding:2px 8px"><b>repo</b></td><td style="padding:2px 8px;font-family:monospace;font-size:11px">{repo}</td>
            </tr>
          </table>
          <table style="border-collapse:collapse;width:100%;font-size:13px;margin-bottom:8px">
            <thead><tr style="background:#eef">
              <th style="padding:4px 8px">successful partitions</th>
              <th style="padding:4px 8px">successful chunks</th>
              <th style="padding:4px 8px">avg chunks / partition</th>
              <th style="padding:4px 8px">failed partitions</th>
              <th style="padding:4px 8px">failed chunks</th>
              <th style="padding:4px 8px">worker errors</th>
            </tr></thead>
            <tbody><tr style="text-align:center">
              <td style="padding:6px;color:#2a8a2a;font-weight:600">{ok_p}</td>
              <td style="padding:6px">{ok_c}</td>
              <td style="padding:6px">{avg_chunks:.1f}</td>
              <td style="padding:6px;color:{'#d63b3b' if fail_p else '#888'}">{fail_p}</td>
              <td style="padding:6px;color:{'#d63b3b' if fail_c else '#888'}">{fail_c}</td>
              <td style="padding:6px;color:{'#d49b00' if werr else '#888'}">{werr}</td>
            </tr></tbody>
          </table>
          {input_block_html}
          <details style="margin-top:6px" open>
            <summary style="cursor:pointer;font-size:13px;color:#444">model-output distribution + top 10 largest / smallest</summary>
            <table style="margin-top:4px"><tr style="vertical-align:top">
              <td style="padding:0 16px 0 0">
                <div style="font-size:11px;color:#666;margin-bottom:2px"><b>chunk-count buckets</b></div>
                {chunk_hist_html}
                <div style="font-size:11px;color:#666;margin:6px 0 2px"><b>model-size buckets (chars)</b></div>
                {size_hist_html}
              </td>
              <td style="padding:0 16px 0 0">
                <div style="font-size:11px;color:#666;margin-bottom:2px"><b>top 10 largest models</b></div>
                {top_largest_html}
              </td>
              <td>
                <div style="font-size:11px;color:#666;margin-bottom:2px"><b>top 10 smallest models</b></div>
                {top_smallest_html}
              </td>
            </tr></table>
          </details>
          <details style="margin-top:6px">
            <summary style="cursor:pointer;font-size:13px;color:#444">chunk count + model size per partition (top 25 by chunk count)</summary>
            <table style="border-collapse:collapse;font-size:12px;margin-top:4px">
              <thead><tr style="background:#eee">
                <th style="padding:3px 8px">partition_id</th>
                <th style="padding:3px 8px">chunks emitted</th>
                <th style="padding:3px 8px">MODEL_CHUNK_TOTAL</th>
                <th style="padding:3px 8px">model size</th>
              </tr></thead>
              <tbody>{chunk_rows}</tbody>
            </table>
          </details>
          {'<details style="margin-top:6px"><summary style="cursor:pointer;font-size:13px;color:#444">worker-error sample (Partition_ID = -1 — workers without real data)</summary>'
            f'<table style="border-collapse:collapse;font-size:12px;margin-top:4px"><thead><tr style="background:#eee"><th style="padding:3px 8px">partition</th><th style="padding:3px 8px">status</th></tr></thead><tbody>{worker_err_rows}</tbody></table></details>' if werr > 0 else ''}
        </div>
        """

    def _build_score_report(self, t_start, elapsed):
        """Build an HTML insight report summarising the just-completed score()."""
        scores_repo = f"{self.tdstone.schema_name}.{self.mapper_scoring.scores_repository}"
        partition_cols = [c.strip() for c in self.mapper_scoring.id_partition.split(',') if c.strip()]
        first_part = partition_cols[0] if partition_cols else 'Partition_ID'

        # Filter to rows from this run if t_start is available — TD_TIMECODE
        # is the script's EXECUTION_TIME so any row inserted by this run is
        # >= t_start. If the column doesn't exist (older repos), fall back to
        # ALL rows (caller can still read insight from the totals).
        where = f"TD_TIMECODE >= CAST('{t_start}' AS TIMESTAMP(6) WITH TIME ZONE)" if t_start else "1=1"

        # Aggregate per-batch + per-partition timing. Each row shares the
        # partition's per-batch values (PROCESS_TIME = predict for THIS batch,
        # PRINT_TIME = previous batch's stdout). MAX(BATCH_NO) per partition
        # = total batches. Partition duration ≈ SUM(per-batch TOTAL_TIME)
        # divided by row count per batch (since each row in a batch carries
        # the same per-batch values, naive SUM(TOTAL_TIME) over-counts by
        # row_count). We compute it as MAX(TOTAL_TIME) × MAX(BATCH_NO) — a
        # rough upper bound — or via the AVG × batches relation.
        # COUNT(DISTINCT {id_row}) gives input rows per partition (each input
        # row produces N feature rows in the scores repo).
        id_row_first = self.mapper_scoring.id_row.split(',')[0].strip()
        per_part_sql = f"""
        SELECT TOP 200
            {first_part} AS partition_id,
            COUNT(*)                       AS rows_emitted,
            COUNT(DISTINCT {id_row_first}) AS n_input_rows,
            MAX(BATCH_NO)                  AS n_batches,
            AVG(PROCESS_TIME)              AS avg_process,
            AVG(PRINT_TIME)                AS avg_print,
            AVG(TOTAL_TIME)                AS avg_total,
            MAX(LOAD_TIME)                 AS load_time
        FROM {scores_repo}
        WHERE {where}
        GROUP BY {first_part}
        ORDER BY n_batches DESC, partition_id
        """
        try:
            per_part = _raw_execute(per_part_sql) or []
        except Exception as e:
            logger.debug("score-report per-part query failed: %s", e)
            per_part = []

        # Per-partition wall-clock approximation: avg_total × n_batches +
        # one-time load_time. avg_total is per-batch (predict + previous
        # print), so multiplying by n_batches reconstructs the worker's
        # processing time. Column indices for the per-partition tuple:
        #   0 partition_id, 1 rows_emitted, 2 n_input_rows, 3 n_batches,
        #   4 avg_process, 5 avg_print, 6 avg_total, 7 load_time
        def _part_dur(row):
            n_batches = float(row[3] or 0)
            avg_total = float(row[6] or 0)
            load_time = float(row[7] or 0)
            return load_time + (avg_total * n_batches)

        durations = [(row[0], _part_dur(row)) for row in per_part]
        sorted_dur = sorted(durations, key=lambda x: x[1])
        top_longest = list(reversed(sorted_dur[-10:]))
        top_fastest = sorted_dur[:10]
        all_durations = [d for _, d in durations]

        # Row-count distributions — input rows / output rows per partition.
        in_rows  = [(row[0], int(row[2] or 0)) for row in per_part]
        out_rows = [(row[0], int(row[1] or 0)) for row in per_part]
        in_sorted  = sorted(in_rows,  key=lambda x: x[1])
        out_sorted = sorted(out_rows, key=lambda x: x[1])
        top_in_largest  = list(reversed(in_sorted[-10:]))
        top_in_smallest = in_sorted[:10]
        top_out_largest  = list(reversed(out_sorted[-10:]))
        top_out_smallest = out_sorted[:10]

        totals_sql = f"""
        SELECT
            COUNT(*)                 AS n_rows,
            COUNT(DISTINCT {first_part}) AS n_partitions,
            COUNT(DISTINCT SCRIPT_UUID)  AS n_workers,
            MAX(BATCH_NO)            AS max_batch_no,
            MIN(LOAD_TIME)           AS load_min,
            MAX(LOAD_TIME)           AS load_max,
            AVG(PROCESS_TIME)        AS proc_avg,
            AVG(PRINT_TIME)          AS print_avg
        FROM {scores_repo}
        WHERE {where}
        """
        try:
            totals = _raw_execute(totals_sql)
            tot = totals[0] if totals else None
        except Exception:
            tot = None

        n_rows = int(tot[0]) if tot else 0
        n_part = int(tot[1]) if tot else 0
        n_work = int(tot[2]) if tot else 0
        rows_per_s = (n_rows / elapsed) if elapsed > 0 else 0
        bs = getattr(self.mapper_scoring, 'apply_scoring_batch_size', None)

        part_rows = '\n'.join(
            f'<tr>'
            f'<td style="text-align:right">{r[0]}</td>'
            f'<td style="text-align:right">{r[2]}</td>'
            f'<td style="text-align:right">{r[1]}</td>'
            f'<td style="text-align:right">{r[3]}</td>'
            f'<td style="text-align:right">{(r[4] or 0)*1000:.1f} ms</td>'
            f'<td style="text-align:right">{(r[5] or 0)*1000:.1f} ms</td>'
            f'<td style="text-align:right">{(r[6] or 0)*1000:.1f} ms</td>'
            f'<td style="text-align:right">{r[7] or 0:.2f} s</td>'
            f'</tr>'
            for r in per_part[:25]
        )
        if len(per_part) > 25:
            part_rows += f'<tr><td colspan="8" style="text-align:center;color:#888">…{len(per_part)-25} more partitions hidden…</td></tr>'

        # Insight callout: which phase dominates?
        proc_avg = (tot[6] or 0) if tot else 0
        print_avg = (tot[7] or 0) if tot else 0
        load_avg = ((tot[4] or 0) + (tot[5] or 0))/2 if tot else 0
        per_batch_total = proc_avg + print_avg
        if per_batch_total <= 0:
            insight = '<div style="color:#888;font-size:12px">Per-batch timings unavailable — script may be older than the per-batch instrumentation.</div>'
        else:
            proc_pct = 100 * proc_avg / per_batch_total
            print_pct = 100 * print_avg / per_batch_total
            insight = (
                f'<div style="font-size:12px;color:#444;margin-top:4px">'
                f'<b>where the time goes (per-batch averages):</b> '
                f'<span style="color:#0066cc">predict {proc_pct:.0f}%</span> · '
                f'<span style="color:#cc6600">stdout {print_pct:.0f}%</span> · '
                f'load (one-time) ≈ {load_avg*1000:.0f} ms. '
                + (
                    f'Predict-bound: try a smaller / cheaper model, more workers (raise <code>apply_scoring_hash_buckets</code>).'
                    if proc_pct > 65 else
                    f'Stdout-bound: raise <code>apply_scoring_batch_size</code> to amortise per-batch overhead, or output-PACK to emit fewer rows.'
                    if print_pct > 50 else
                    f'Balanced — consider raising <code>apply_scoring_batch_size</code> first; small wins on both sides.'
                )
                + '</div>'
            )

        return f"""
        <div style="font-family:-apple-system,Segoe UI,sans-serif;border:1px solid #ddd;border-radius:6px;padding:10px 14px;margin:8px 0;max-width:980px;background:#fafafa">
          <div style="display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid #e2e2e2;padding-bottom:6px;margin-bottom:8px">
            <h3 style="margin:0;font-size:15px;color:#2a8a2a">tdstone2 / scoring report</h3>
            <span style="font-size:11px;color:#777;font-family:monospace">hyper_model={self.id} batch_size={bs}</span>
          </div>
          <table style="border-collapse:collapse;width:100%;font-size:13px;margin-bottom:8px">
            <tr>
              <td style="padding:2px 8px"><b>elapsed</b></td><td style="padding:2px 8px">{self._fmt_secs(elapsed)}</td>
              <td style="padding:2px 8px"><b>predictions</b></td><td style="padding:2px 8px">{n_rows:,}</td>
              <td style="padding:2px 8px"><b>partitions</b></td><td style="padding:2px 8px">{n_part}</td>
              <td style="padding:2px 8px"><b>workers</b></td><td style="padding:2px 8px">{n_work}</td>
              <td style="padding:2px 8px"><b>rows / s</b></td><td style="padding:2px 8px">{rows_per_s:,.0f}</td>
            </tr>
          </table>
          {insight}
          <details style="margin-top:6px" open>
            <summary style="cursor:pointer;font-size:13px;color:#444">per-partition duration distribution + top 10 longest / fastest</summary>
            <table style="margin-top:4px"><tr style="vertical-align:top">
              <td style="padding:0 16px 0 0">
                <div style="font-size:11px;color:#666;margin-bottom:2px"><b>per-partition duration buckets</b></div>
                {self._svg_histogram(all_durations, bins=8, color='#4a90e2', unit='s')}
              </td>
              <td style="padding:0 16px 0 0">
                <div style="font-size:11px;color:#666;margin-bottom:2px"><b>top 10 longest partitions</b></div>
                {self._svg_hbar([(f'partition {pid}', dur) for pid, dur in top_longest],
                                color='#d49b00', fmt=lambda v: f'{v:.2f}s')}
              </td>
              <td>
                <div style="font-size:11px;color:#666;margin-bottom:2px"><b>top 10 fastest partitions</b></div>
                {self._svg_hbar([(f'partition {pid}', dur) for pid, dur in top_fastest],
                                color='#74b072', fmt=lambda v: f'{v:.2f}s')}
              </td>
            </tr></table>
          </details>
          <details style="margin-top:6px">
            <summary style="cursor:pointer;font-size:13px;color:#444">per-partition row-count distribution + top 10 / tail 10</summary>
            <table style="margin-top:4px"><tr style="vertical-align:top">
              <td style="padding:0 16px 0 0">
                <div style="font-size:11px;color:#666;margin-bottom:2px"><b>input rows per partition</b></div>
                {self._svg_histogram([n for _, n in in_rows], bins=8, color='#4a90e2', unit=' rows')}
                <div style="font-size:11px;color:#666;margin:6px 0 2px"><b>output rows per partition</b></div>
                {self._svg_histogram([n for _, n in out_rows], bins=8, color='#9c52d4', unit=' rows')}
              </td>
              <td style="padding:0 16px 0 0">
                <div style="font-size:11px;color:#666;margin-bottom:2px"><b>top 10 largest input</b></div>
                {self._svg_hbar([(f'partition {pid}', n) for pid, n in top_in_largest],
                                color='#4a90e2', fmt=lambda v: f'{v:,}')}
                <div style="font-size:11px;color:#666;margin:6px 0 2px"><b>top 10 largest output</b></div>
                {self._svg_hbar([(f'partition {pid}', n) for pid, n in top_out_largest],
                                color='#9c52d4', fmt=lambda v: f'{v:,}')}
              </td>
              <td>
                <div style="font-size:11px;color:#666;margin-bottom:2px"><b>top 10 smallest input (tail)</b></div>
                {self._svg_hbar([(f'partition {pid}', n) for pid, n in top_in_smallest],
                                color='#74b072', fmt=lambda v: f'{v:,}')}
                <div style="font-size:11px;color:#666;margin:6px 0 2px"><b>top 10 smallest output (tail)</b></div>
                {self._svg_hbar([(f'partition {pid}', n) for pid, n in top_out_smallest],
                                color='#74b072', fmt=lambda v: f'{v:,}')}
              </td>
            </tr></table>
          </details>
          <details style="margin-top:6px">
            <summary style="cursor:pointer;font-size:13px;color:#444">per-partition timing (top 25 by batch count)</summary>
            <table style="border-collapse:collapse;font-size:12px;margin-top:4px">
              <thead><tr style="background:#eee">
                <th style="padding:3px 8px">partition_id</th>
                <th style="padding:3px 8px">input rows</th>
                <th style="padding:3px 8px">output rows</th>
                <th style="padding:3px 8px">n_batches</th>
                <th style="padding:3px 8px">avg predict</th>
                <th style="padding:3px 8px">avg print</th>
                <th style="padding:3px 8px">avg total</th>
                <th style="padding:3px 8px">load time</th>
              </tr></thead>
              <tbody>{part_rows}</tbody>
            </table>
          </details>
        </div>
        """

    def score(self, full_mapping_update = True, report = True):
        """
        Executes the scoring process for the hypermodel by updating mappings and executing the mapper for scoring.

        Parameters:
            full_mapping_update (bool, optional): Determines whether a full mapping update is required. Defaults to True.
            report (bool, optional): Display an inline HTML insight report
                with per-partition + per-batch timing breakdown after the run.
                Defaults to True. Set to False to skip (e.g. headless runs).
        """
        logger.info(
            "score start hyper_model=%s id_model=%s mapper=%s repository=%s.%s full_mapping_update=%s",
            self.id, self.id_model, self.mapper_scoring.id,
            self.tdstone.schema_name, self.mapper_scoring.scores_repository,
            full_mapping_update,
        )
        t0 = time.perf_counter()
        try:
            t_start = _raw_execute("SELECT CURRENT_TIMESTAMP(6)")[0][0]
        except Exception:
            t_start = None
        try:
            if full_mapping_update:
                logger.info("Refreshing scoring mapper partitions")
                self.mapper_scoring.fill_mapping_full(model_id=self.id_model)
            logger.debug("Rebuilding scoring ON clause")
            self.mapper_scoring.create_on_clause()
            logger.info("Executing scoring mapper (STO)")
            self.mapper_scoring.execute_mapper()
        except Exception:
            logger.exception("score failed hyper_model=%s id_model=%s", self.id, self.id_model)
            raise
        elapsed = time.perf_counter() - t0
        logger.info(
            "score done hyper_model=%s elapsed=%.2fs",
            self.id, elapsed,
        )
        if report:
            self._maybe_display_html(self._build_score_report(t_start, elapsed))
        return
    
    def get_trained_models(self, with_binary_model = False, only_successful = True):
        """
        Retrieves details of trained models, optionally including the binary model itself
        and/or rows where training failed.

        Parameters:
            with_binary_model (bool, optional): Whether to include the TRAINED_MODEL binary column. Defaults to False.
            only_successful (bool, optional): When True (default), returns only rows where training succeeded.
                Set to False to also include rows where training failed (STATUS does not contain 'successful').

        Returns:
            DataFrame: tdml.DataFrame on Script path, pandas.DataFrame on Apply path
            (the OFS-resident repo tables are read through the fresh teradatasql connection).
        """
        print(self.tdstone.schema_name, self.mapper_training.model_repository)
        schema = self.tdstone.schema_name
        table = self.mapper_training.trained_model_repository
        if getattr(self.tdstone, 'use_apply', False):
            where = " WHERE STATUS LIKE '%successful%'" if only_successful else ""
            df = _raw_query_apply_df(f"SELECT * FROM {schema}.{table}{where}")
            if not with_binary_model:
                df = df[[c for c in df.columns if c.lower() != 'trained_model']]
            return df
        df = tdml.DataFrame(tdml.in_schema(schema, table))
        if only_successful:
            df = df[df['STATUS'].like('%successful%')]
        if not with_binary_model:
            df = df[[x for x in df.columns if x.lower() != 'trained_model']]
        return df

    def get_byom_catalog(self):
        """
        Retrieves details of trained models, optionally including the binary model itself.

        Parameters:
            with_binary_model (bool, optional): Determines whether to include the binary model in the results. Defaults to False.

        Returns:
            DataFrame: DataFrame containing details of trained models.
        """
        print(self.tdstone.schema_name, 'V_'+self.mapper_training.trained_model_repository+'_BYOM_CATALOG')
        return tdml.DataFrame(tdml.in_schema(self.tdstone.schema_name, 'V_'+self.mapper_training.trained_model_repository+'_BYOM_CATALOG'))

    def get_model_predictions(self, denormalized_view = True, include_timing = False):
        """
        Retrieves model predictions, optionally generating a denormalized view for easier analysis.

        Parameters:
            denormalized_view (bool, optional): Determines whether to generate a denormalized view of the predictions. Defaults to True.
            include_timing (bool, optional): When True (and ``denormalized_view``
                is True), the per-batch timing columns
                (``SCRIPT_UUID``, ``BATCH_NO``, ``PROCESS_TIME``, ``PRINT_TIME``,
                ``TOTAL_TIME``, ``LOAD_TIME``) are joined into the denormalized
                view alongside the prediction features so the user can correlate
                a row with the batch that produced it. Defaults to False (the
                view stays narrow and analysis-friendly). Only meaningful for
                scoring repos that have the per-batch instrumentation columns
                (added in the harmonised tds_scoring*.py).

        Returns:
            DataFrame: DataFrame containing model predictions.
        """
        logger.debug(
            "get_model_predictions hyper_model=%s scores=%s.%s denormalized_view=%s",
            self.id, self.tdstone.schema_name, self.mapper_scoring.scores_repository, denormalized_view,
        )

        use_apply = getattr(self.tdstone, 'use_apply', False)

        def generate_denormalized_view(schema_name, table_name, col_join = None):
            if use_apply:
                from tdstone2.utils import _raw_execute_apply
                feature_names = _raw_execute_apply(
                    f"SELECT DISTINCT FEATURE_NAME, FEATURE_TYPE FROM {schema_name}.{table_name}"
                )
            else:
                feature_names = _raw_execute(
                    f"SELECT DISTINCT FEATURE_NAME, FEATURE_TYPE FROM {schema_name}.{table_name}"
                )
            feature_names = {x[0]: x[1] for x in feature_names}

            if col_join is None:
                if use_apply:
                    cols_rows = _raw_query_apply_df(
                        f"SELECT * FROM {schema_name}.{table_name} WHERE 1=0"
                    )
                    columns = list(cols_rows.columns)
                else:
                    columns = tdml.DataFrame(tdml.in_schema(schema_name, table_name)).columns
                col_join = columns[0:-5] + [columns[-1]]

            if not feature_names:
                return None

            query_select = f"""SELECT
            {','.join(['A1.' + x for x in col_join])}
            """
            query_from = ''
            for index, (k, v) in enumerate(feature_names.items(), start=1):

                if 'float' in v:
                    query_select += f"""\n,CAST(A{index}.FEATURE_VALUE AS FLOAT) AS {k}"""
                elif 'int' in v:
                    query_select += f"""\n,CAST(A{index}.FEATURE_VALUE AS BIGINT) AS {k}"""
                else:
                    query_select += f"""\n,A{index}.FEATURE_VALUE AS {k}"""

                if index == 1:
                    query_from = f"""\nFROM (
                    SELECT {','.join(col_join)} , FEATURE_VALUE FROM {schema_name}.{table_name}
                    WHERE FEATURE_NAME = '{k}'
                    ) A{index}
                    """
                else:
                    query_from += f"""\nFULL OUTER JOIN (
                    SELECT {','.join(col_join)} , FEATURE_VALUE FROM {schema_name}.{table_name}
                    WHERE FEATURE_NAME = '{k}'
                    ) A{index}
                    ON {' AND '.join(['A1.' + x + '=A' + str(index) + '.' + x for x in col_join])}
                    """

            return query_select + '\n' + query_from

        schema = self.tdstone.schema_name
        scores_table = self.mapper_scoring.scores_repository

        if denormalized_view:
            col_join = ['TD_TIMECODE', 'ID_PROCESS', 'ID_TRAINED_MODEL']+self.mapper_training.id_partition.split(',')+self.mapper_training.id_row.split(',')
            if include_timing:
                # Per-batch values are constant for all (row × feature) rows
                # within a single batch, so they can safely participate in the
                # FULL OUTER JOIN as part of col_join — the JOIN keys still
                # match across features. Skipped silently if the columns
                # aren't present (older repos).
                col_join += ['SCRIPT_UUID', 'BATCH_NO', 'PROCESS_TIME', 'PRINT_TIME', 'TOTAL_TIME', 'LOAD_TIME']
            query = generate_denormalized_view(schema, scores_table, col_join)
            if query is None:
                logger.warning(
                    "No FEATURE_NAME rows found in %s.%s — returning the raw scores view. "
                    "Run model.score() first, or check the STATUS column for failures.",
                    schema, scores_table,
                )
                if use_apply:
                    return _raw_query_apply_df(f"SELECT * FROM {schema}.{scores_table}")
                return tdml.DataFrame(tdml.in_schema(schema, scores_table))
            if use_apply:
                return _raw_query_apply_df(query)
            return tdml.DataFrame.from_query(query)
        else:
            if use_apply:
                return _raw_query_apply_df(f"SELECT * FROM {schema}.{scores_table}")
            return tdml.DataFrame(tdml.in_schema(schema, scores_table))

    def download(self, id, tdstone=None):
        """
        Downloads the details of a hypermodel process based on the provided ID, allowing for inspection or modification.

        Parameters:
            id (str): The unique identifier of the hypermodel process to download.
            tdstone (TDStone, optional): Instance of the TDStone class for database operations, if different from the initially provided one.
        """
        if tdstone is not None:
            self.tdstone = tdstone

        query = f"""
        SELECT 
           ID
        ,  ID_MODEL
        ,  ID_MAPPER_TRAINING
        ,  ID_MAPPER_SCORING
        ,  METADATA
        FROM {self.tdstone.schema_name}.{self.tdstone.hyper_model_repository}
        WHERE ID = '{id}'
        """

        df = tdml.DataFrame.from_query(query).to_pandas().reset_index()
        #print(df)
        if df.shape[0] > 0:
            self.id              = df.ID.values[0]
            self.id_model        = df.ID_MODEL.values[0]
            id_mapper_training   = df.ID_MAPPER_TRAINING.values[0]
            self.mapper_training = Mapper(tdstone=self.tdstone, mapper_type = 'training')
            self.mapper_training.download(id=id_mapper_training, mapper_type = 'training')
            id_mapper_scoring   = df.ID_MAPPER_SCORING.values[0]
            self.mapper_scoring = Mapper(tdstone=self.tdstone, mapper_type = 'training')
            self.mapper_scoring.download(id=id_mapper_scoring, mapper_type = 'scoring')
            self.metadata = json.loads(df.METADATA.values[0])
        else:
            print('there is no hyper model with this id')

    def retrieve_code_and_data(self, Partition=None, with_data=False):
        """
        Retrieves the code and optionally the data associated with the hypermodel process.

        Parameters:
            Partition (dict, optional): Partition details to filter the data, if specific subsets are required.
            with_data (bool, optional): Flag indicating whether to include the data in the retrieval. Defaults to False.

        Returns:
            dict: A dictionary containing 'code', 'arguments', and optionally 'data'.
        """

        # Get the model_id from list_mapping:
        if Partition is None:
            df = self.mapper_training.list_mapping().to_pandas(num_rows=1)
            Partition = df.iloc[:, 1:-2]
            Partition = {c: v[0] for c, v in zip(Partition.columns, Partition.values.tolist())}
        else:
            df = self.mapper_training.list_mapping()
            df._DataFrame__execute_node_and_set_table_name(df._nodeid, df._metaexpr)
            where = " and ".join(
                [k + "='" + v + "'" if type(v) == str else k + "=" + str(v) for k, v in Partition.items()])
            df = tdml.DataFrame.from_query(f"""
                SEL *
                FROM {df._table_name}
                WHERE {where}
            """).to_pandas(num_rows=1)

        id_model = df.ID_MODEL.values[0]

        # Get the Code and the Arguments
        df = self.tdstone.list_models()
        df = df[df.ID == id_model].to_pandas(num_rows=1)
        arguments = json.loads(df.ARGUMENTS.values[0])
        id_code = df.ID_CODE.values[0]

        # Get the Code
        df = self.tdstone.list_codes(with_full_script=True)
        df = df[df.ID == id_code].to_pandas(num_rows=1)
        code = df.CODE.values[0].decode()

        results = {}
        results['code'] = code
        results['arguments'] = arguments['model_parameters']

        if with_data:
            df = tdml.DataFrame(self.mapper_training.dataset)
            df._DataFrame__execute_node_and_set_table_name(df._nodeid, df._metaexpr)
            where = " and ".join(
                [k + "='" + v + "'" if type(v) == str else k + "=" + str(v) for k, v in Partition.items()])
            df = tdml.DataFrame.from_query(f"""
                SEL *
                FROM {df._table_name}
                WHERE {where}
            """).to_pandas().reset_index()
            results['data'] = df

        return results
