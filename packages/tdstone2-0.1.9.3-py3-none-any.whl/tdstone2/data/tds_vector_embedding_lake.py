import warnings

# Suppress warnings for cleaner output
warnings.filterwarnings('ignore')

import os
# Apply runs as a UID that may not exist in /etc/passwd; transformers >=5 calls
# getpass.getuser() during cache init, which raises KeyError on getpwuid lookup.
# Set HOME so getuser() falls back to the env var instead of the passwd lookup.
os.environ.setdefault("HOME", "/tmp")
os.environ.setdefault("USER", "tduser")

import time
import warnings
import sys
import csv
import torch
from torch.utils.data import Dataset, DataLoader

# OAF mirror provides huggingface-hub==1.2.3 but sentence-transformers 5.x
# requires >=1.5.0. ST checks via importlib.metadata.version, so patch that
# too — the actual API used (model loading, cache) is compatible with 1.2.3.
import importlib.metadata as _imeta
_orig_imeta_version = _imeta.version
def _patched_imeta_version(pkg):
    if pkg in ("huggingface-hub", "huggingface_hub"):
        return "1.9.0"
    return _orig_imeta_version(pkg)
_imeta.version = _patched_imeta_version
import huggingface_hub as _hfhub
_hfhub.__version__ = "1.9.0"

# Hub 1.2.3's type_validator handles typing.Union but not Python 3.10+ types.UnionType
# (the X | Y syntax used in transformers 5.x field annotations like 'str | None').
# Add UnionType to the validator dispatch table before the model config dataclasses
# are instantiated so the validation falls through to the existing _validate_union handler.
import types as _builtins_types
import huggingface_hub.dataclasses as _hf_dc
if hasattr(_builtins_types, "UnionType") and _builtins_types.UnionType not in _hf_dc._BASIC_TYPE_VALIDATORS:
    _hf_dc._BASIC_TYPE_VALIDATORS[_builtins_types.UnionType] = _hf_dc._validate_union

from sentence_transformers import SentenceTransformer
import uuid
import ast
from collections import OrderedDict

warnings.warn("Beginning of the script.", UserWarning)

# Define the path to your preloaded models directory
models_directory = os.path.abspath("./models")
os.environ["TRANSFORMERS_CACHE"] = models_directory
os.environ["HF_HOME"] = models_directory
os.environ["TF_ENABLE_ONEDNN_OPTS"] = '0'

# Start measuring process and elapsed time
start_process_time = time.process_time()
start_time = time.time()


# Define the delimiter for splitting input lines
DELIMITER = ','

# Get parameters from sys.argv
model_name  = sys.argv[1] if len(sys.argv) > 1 else sys.exit("Please provide the model name")
batch_size  = int(sys.argv[2])  # the batch size
text_column = int(sys.argv[3])  # Convert the second argument to an integer (text_column)
try:
    accumulate    = ast.literal_eval(sys.argv[4].replace('-',',')) # Convert the third argument (accumulate) from string to list
except Exception as e:
    sys.exit()
DELIMITER   = sys.argv[5] if len(sys.argv[5])==1 else ast.literal_eval(sys.argv[5])
device      = sys.argv[6] # will take 'cuda' of 'cpu'
half        = int(sys.argv[7]) # if 1 then the model will run half precision


colNames = ['text_column'] + [f'accumulate_{idx}' for idx in range(len(accumulate))]
# Generate a unique identifier for this script instance
script_uuid = uuid.uuid4()

def restore_model_name(model_fname: str) -> str:
    if model_fname.startswith("models--"):
        model_name = model_fname[len("models--"):].replace("--", "/")
        return model_name
    else:
        return model_name

# Load SentenceTransformer model and move to CUDA if available
if device == 'cuda':
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
else:
    device = 'cpu'

# Disable optimised attention kernels (flash SDP, flex_attention) that require
# SM >= 8.0 (Ampere+). Tesla T4 is SM 7.5 and flex_attention fails at JIT
# compile time on that capability. Eager attention is slightly slower but runs
# on any CUDA device.
if device == 'cuda':
    torch.backends.cuda.enable_flash_sdp(False)
    torch.backends.cuda.enable_mem_efficient_sdp(False)
    torch.backends.cuda.enable_math_sdp(True)

# Update the model loading to handle local paths
model_path = os.path.join(models_directory, model_name, model_name)
sentence_transformer = SentenceTransformer(
    model_path,
    model_kwargs={"attn_implementation": "eager"},
).to(device)

if half == 1 and device == 'cuda':
    sentence_transformer = sentence_transformer.half()
else:
    half = 0

sentence_transformer.eval()

class StdinDataset(Dataset):
    def __init__(self, transform=None):
        self.transform = transform
        self.csv_reader = csv.DictReader(
            sys.stdin,
            fieldnames= colNames,
            delimiter = DELIMITER
        )
        self.eof_reached = False  # Initialize EOF flag

    def __len__(self):
        return 10**9  # Large number simulating indefinite streaming

    def parse_row(self, row):
        try:
            warnings.warn(f"row : {list(row.keys())}", UserWarning)
            text_data = row['text_column']
            additional_data = [row[f'accumulate_{idx}'] for idx in range(len(accumulate))]
            return text_data, additional_data
        except IndexError:
            sys.exit()

    def __getitem__(self, idx):
        if self.eof_reached:
            return [], [], True  # Return empty lists and EOF flag

        while not self.eof_reached:
            try:
                row = next(self.csv_reader)
                sample = self.parse_row(row)
                if sample is not None:
                    text_data, additional_data = sample
                    return additional_data, text_data, False
            except StopIteration:
                self.eof_reached = True
                return [], [], True

# Custom collate function to handle empty (EOF) items
def collate_fn(batch):
    # Filter out empty entries (EOF signals)
    batch = [item for item in batch if item[1] != []]
    if len(batch) == 0:
        return [], [], True  # Return EOF-only batch if nothing valid remains

    additional_data, text_data, eof_status = zip(*batch)
    return additional_data, text_data, any(eof_status)

def create_stdin_dataloader(batch_size=1):
    dataset = StdinDataset()
    return DataLoader(dataset, batch_size=batch_size, shuffle=False, collate_fn=collate_fn)

def vect2dict(embedding_vector):
    #return str(OrderedDict((f"V{i}", value) for i, value in enumerate(embedding_vector))).replace("'", '"')
    return f"{len(embedding_vector)}{DELIMITER}{' '.join([str(v) for v in embedding_vector])}"


batch_no = 1
def optimized_output_flattened():
    # Prepare the base output data (constant part for all embeddings)
    base_output_data = (
        f"{script_uuid}{DELIMITER}"
        f"{process_time_used / len(embeddings)}{DELIMITER}"
        f"{elapsed_time / len(embeddings)}{DELIMITER}"
        f"{model_name}{DELIMITER}"
        f"{device}{DELIMITER}"
        f"{half}{DELIMITER}"
        f"{batch_size}{DELIMITER}"
        f"{batch_no}"
    )

    output_buffer = [
        f"{DELIMITER.join(map(str, additional_data[i]))}{DELIMITER}{base_output_data}{DELIMITER}{vect2dict(embedding_vector)}"
        for i, embedding_vector in enumerate(embeddings)
    ]
    # Write all output at once to stdout and flush so Apply sees it immediately.
    # Without flush, block-buffered stdout on a pipe can silently hold data
    # for several seconds between batches, causing Apply to time out.
    sys.stdout.write("\n".join(output_buffer) + "\n")
    sys.stdout.flush()

warnings.warn("Before create_stdin_dataloader.", UserWarning)
dataloader = create_stdin_dataloader(batch_size=batch_size)
warnings.warn("create_stdin_dataloader successful.", UserWarning)

# On CUDA, force kernel compilation and VRAM allocation on a dummy batch before
# stdin data starts flowing.  Without this the first real batch absorbs the full
# CUDA JIT cost and Apply may time out waiting for the first stdout line.
if device == 'cuda':
    with torch.no_grad():
        _ = sentence_transformer.encode(["warmup"], convert_to_tensor=True, device=device)
    warnings.warn("CUDA warmup done.", UserWarning)

try:
    warnings.warn("before the for loop.", UserWarning)

    for additional_data, text_data, eof_status in dataloader:
        if len(text_data) == 0 or len(text_data[0]) == 0:
            sys.exit()

        # Perform batch encoding
        with torch.no_grad():
            embeddings = sentence_transformer.encode(text_data, convert_to_tensor=True, device=device).cpu().numpy()

        # Calculate process and elapsed time
        process_time_used = time.process_time() - start_process_time
        elapsed_time      = time.time() - start_time

        optimized_output_flattened()
        batch_no = batch_no + 1
        start_process_time = time.process_time()
        start_time = time.time()

        if eof_status:
            sys.exit()  # Exit if EOF reached

except SystemExit:
    pass
except Exception as e:
    print("Script Failure :", sys.exc_info()[0], file=sys.stderr)
    raise
    sys.exit()