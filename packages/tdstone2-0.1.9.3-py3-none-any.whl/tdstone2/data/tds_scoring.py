import time as _time
_T_SCRIPT_START = _time.time()
_T_IMPORT_START = _T_SCRIPT_START

import sys
import numpy as np
import pandas as pd
import json
import base64
import pickle
import uuid as _uuid

import warnings
warnings.filterwarnings('ignore')

# Per-batch instrumentation — harmonised with tds_scoring_apply.py so the
# Script-on-Enterprise and Apply-on-Lake paths produce identical metric
# columns. PROCESS_TIME / PRINT_TIME / TOTAL_TIME are PER-BATCH (not
# cumulative); LOAD_TIME / IMPORT_TIME are one-time. PRINT_TIME of the
# previous batch is embedded in the current batch's rows (one-step lag —
# the kernel write cost is only known *after* the writes complete).
IMPORT_TIME           = _time.time() - _T_IMPORT_START
LOAD_TIME             = 0.0
SCRIPT_UUID           = str(_uuid.uuid4())
BATCH_NO_GLOBAL       = 0
PROCESS_TIME_BATCH    = 0.0   # this batch's predict time
PRINT_TIME_BATCH      = 0.0   # previous batch's stdout cost (one-step lag)
TOTAL_TIME_BATCH      = 0.0   # = PROCESS_TIME_BATCH + PRINT_TIME_BATCH

# RETURNS('IDstr VARCHAR(255) CHARACTER SET UNICODE, ID_Model INTEGER, ID_Partition VARCHAR(2000) CHARACTER SET UNICODE, Model_Type VARCHAR(255) CHARACTER SET UNICODE, JSON_RESULTS VARCHAR(2000), Part_no INTEGER, BINARY_RESULTS BLOB')

batch_size  = int(sys.argv[1]) if len(sys.argv) > 1 else 100000


STO_OUTPUT_DEFAULT_STO_PARTITION_ID = -1
STO_OUTPUT_DEFAULT_STO_ROW_ID = -1
STO_OUTPUT_DEFAULT_STO_MODEL_ID = -1
STO_OUTPUT_DEFAULT_FEATURE_NAME = 'STO error'
STO_OUTPUT_DEFAULT_FEATURE_VALUE = 'STO error'
STO_OUTPUT_DEFAULT_FEATURE_TYPE = 'None'
STO_OUTPUT_DEFAULT_STATUS = '{"error": "failed"}'
STO_OUTPUT_DEFAULT_MODEL_TYPE = 'STO error'
STO_OUTPUT_DEFAULT_TRAINED_MODEL_ID = 'STO error'
STO_OUTPUT_DEFAULT_EXECUTION_TIME = '9999-01-01 00:00:00.000000-04:00'
DELIMITER = '\t'


_SAFE_MAX = 4000  # cap individual values to keep rows under VARCHAR LATIN limits

# Drop control bytes (< 0x20 or > 0x7E) — including the awk-pipe row separator
# (\n) and field separator (\t). Script's downstream awk filter splits on \t
# with no quoting; an embedded \t in any value would shift the NF count and
# get the row dropped. Built lazily so module-load doesn't pay for the table.
_SAFE_DROP = bytes(range(0, 32)) + bytes(range(127, 256))
def _safe(v):
    """Return a Latin-safe, single-line, no-tab version of ``v`` capped at
    ``_SAFE_MAX`` bytes. Mirrors tds_scoring_apply._safe but tuned for the
    Script tab-delimited / awk-piped IO contract (no comma/quote stripping
    needed; only control bytes including \\t and \\n)."""
    if v is None:
        return ''
    if not isinstance(v, str):
        v = str(v)
    b = v.encode('utf-8', errors='replace').translate(None, _SAFE_DROP)
    if len(b) > _SAFE_MAX:
        b = b[:_SAFE_MAX]
    return b.decode('latin-1', errors='replace')


def _timing_suffix():
    """7-field suffix appended to every output row, in the order matching the
    SQL RETURNS clause: SCRIPT_UUID, TOTAL_TIME, IMPORT_TIME, LOAD_TIME,
    PROCESS_TIME, PRINT_TIME, BATCH_NO. Reads module-level globals updated by
    the per-batch loop."""
    return (
        SCRIPT_UUID + DELIMITER +
        f"{TOTAL_TIME_BATCH:.6f}" + DELIMITER +
        f"{IMPORT_TIME:.6f}" + DELIMITER +
        f"{LOAD_TIME:.6f}" + DELIMITER +
        f"{PROCESS_TIME_BATCH:.6f}" + DELIMITER +
        f"{PRINT_TIME_BATCH:.6f}" + DELIMITER +
        str(BATCH_NO_GLOBAL)
    )


def print_outputs2():
    print(
        str(STO_OUTPUT_DEFAULT_STO_PARTITION_ID) + DELIMITER +
        str(STO_OUTPUT_DEFAULT_STO_ROW_ID) + DELIMITER +
        str(STO_OUTPUT_DEFAULT_FEATURE_NAME) + DELIMITER +
        str(STO_OUTPUT_DEFAULT_FEATURE_VALUE) + DELIMITER +
        str(STO_OUTPUT_DEFAULT_FEATURE_TYPE) + DELIMITER +
        str(STO_OUTPUT_DEFAULT_STATUS) + DELIMITER +
        str(STO_OUTPUT_DEFAULT_STO_MODEL_ID) + DELIMITER +
        str(STO_OUTPUT_DEFAULT_MODEL_TYPE) + DELIMITER +
        str(STO_OUTPUT_DEFAULT_TRAINED_MODEL_ID) + DELIMITER +
        _timing_suffix() + DELIMITER +
        str(STO_OUTPUT_DEFAULT_EXECUTION_TIME)

    )

nb_partitions = None
nb_rows       = None

def print_outputs():
    suffix = _timing_suffix()
    if nb_partitions is None:
        for i in range(10):
            list_2_print = [str(STO_OUTPUT_DEFAULT_STO_PARTITION_ID)]*(i+1)
            list_2_print.append(str(STO_OUTPUT_DEFAULT_FEATURE_NAME))
            list_2_print.append(str(STO_OUTPUT_DEFAULT_FEATURE_VALUE))
            list_2_print.append(str(STO_OUTPUT_DEFAULT_FEATURE_TYPE))
            list_2_print.append(str(STO_OUTPUT_DEFAULT_STATUS))
            list_2_print.append(str(STO_OUTPUT_DEFAULT_STO_MODEL_ID))
            list_2_print.append(str(STO_OUTPUT_DEFAULT_MODEL_TYPE))
            list_2_print.append(str(STO_OUTPUT_DEFAULT_TRAINED_MODEL_ID))
            list_2_print.append(suffix)
            list_2_print.append(str(STO_OUTPUT_DEFAULT_EXECUTION_TIME))
            print(DELIMITER.join(list_2_print))
    elif type(STO_OUTPUT_DEFAULT_STO_PARTITION_ID) == list and len(STO_OUTPUT_DEFAULT_STO_PARTITION_ID) == nb_partitions and type(STO_OUTPUT_DEFAULT_STO_ROW_ID) == list and len(STO_OUTPUT_DEFAULT_STO_ROW_ID) == nb_rows:
        list_2_print = [str(x) for x in STO_OUTPUT_DEFAULT_STO_PARTITION_ID]
        list_2_print = list_2_print + [str(x) for x in STO_OUTPUT_DEFAULT_STO_ROW_ID]
        list_2_print.append(str(STO_OUTPUT_DEFAULT_FEATURE_NAME))
        list_2_print.append(str(STO_OUTPUT_DEFAULT_FEATURE_VALUE))
        list_2_print.append(str(STO_OUTPUT_DEFAULT_FEATURE_TYPE))
        list_2_print.append(str(STO_OUTPUT_DEFAULT_STATUS))
        list_2_print.append(str(STO_OUTPUT_DEFAULT_STO_MODEL_ID))
        list_2_print.append(str(STO_OUTPUT_DEFAULT_MODEL_TYPE))
        list_2_print.append(str(STO_OUTPUT_DEFAULT_TRAINED_MODEL_ID))
        list_2_print.append(suffix)
        list_2_print.append(str(STO_OUTPUT_DEFAULT_EXECUTION_TIME))
        print(DELIMITER.join(list_2_print))
    else:
        list_2_print = [str(STO_OUTPUT_DEFAULT_STO_PARTITION_ID)]*nb_partitions
        list_2_print = list_2_print + [str(STO_OUTPUT_DEFAULT_STO_ROW_ID)]*nb_rows
        list_2_print.append(str(STO_OUTPUT_DEFAULT_FEATURE_NAME))
        list_2_print.append(str(STO_OUTPUT_DEFAULT_FEATURE_VALUE))
        list_2_print.append(str(STO_OUTPUT_DEFAULT_FEATURE_TYPE))
        list_2_print.append(str(STO_OUTPUT_DEFAULT_STATUS))
        list_2_print.append(str(STO_OUTPUT_DEFAULT_STO_MODEL_ID))
        list_2_print.append(str(STO_OUTPUT_DEFAULT_MODEL_TYPE))
        list_2_print.append(str(STO_OUTPUT_DEFAULT_TRAINED_MODEL_ID))
        list_2_print.append(suffix)
        list_2_print.append(str(STO_OUTPUT_DEFAULT_EXECUTION_TIME))
        print(DELIMITER.join(list_2_print))

def print_when_exception():
    print_outputs()
    sys.exit()


#print_when_exception()

# Here we read the input data
# Know your data: You must know in advance the number and data types of the
# incoming columns from the Teradata database!
# For this script, the input expected format is:
beg_cols = []

end_cols = [
    'sto_fake_row',
    'sto_model_id',
    'sto_row_id',
    'sto_partition_id',
    'sto_fold_id',
    'sto_code_type',
    'sto_code',
    'arguments',
    'id_trained_model',
    'model_type',
    'sto_trained_model',
    'sto_model_chunk_index',  # added when chunked-CLOB pattern was rolled out for Apply
    'sto_model_chunk_total',  # ditto — present in the SCORING on-clause view
    'execution_time',
    'hash_bucket',            # ditto — Partition_ID MOD apply_scoring_hash_buckets
]

import uuid

unique_id = str(uuid.uuid4())

def reconstruct_pandas_dataframe(beg_cols, end_cols, batch_size=1):
    """
    Reads standard input line by line to construct a pandas DataFrame with
    appropriate data types specified for each column.

    Returns:
        df (DataFrame): A DataFrame with data read from standard input,
                        with columns typed as float, int, and category as appropriate.
    """
    data_Tbl = []

    for _ in range(batch_size):
        try:
            line = sys.stdin.readline()
            if line == '':  # Stop if the line is empty or EOF
                break
            data_Tbl.append([x for x in line.split(DELIMITER)])
        except EOFError:
            break

    if not data_Tbl:
        # End-of-stream — exit cleanly. sys.exit("msg") returns exit code 1
        # which causes the SCRIPT operator (and Apply on Lake) to discard
        # the partition's entire stdout, including any successful rows
        # already emitted. sys.exit(0) preserves them.
        sys.exit(0)

    num_columns = len(data_Tbl[0])

    # Generate column names
    dummy_cols = [f"dummy_col_{i}" for i in range(num_columns - len(beg_cols) - len(end_cols))]
    column_names = beg_cols + dummy_cols + end_cols

    # Ensure no duplicate column names
    if len(set(column_names)) != len(column_names):
        sys.exit("Error: Duplicate column names generated. Check beg_cols and end_cols.")

    df = pd.DataFrame(data_Tbl, columns=column_names)

    return df, dummy_cols

# Helper functions
def update_status(message):
    global STO_OUTPUT_DEFAULT_STATUS
    STO_OUTPUT_DEFAULT_STATUS = message
    print_when_exception()



def parse_execution_time(df):
    try:
        return df['execution_time'].values[0]
    except:
        update_status('{"error": "failed", "info":"fails to read execution_time"}')
        return None

def parse_arguments(df):
    try:
        return json.loads(df['arguments'].values[0])
    except:
        update_status('{"error": "failed", "info":"arguments JSON may not be well formed"}')
        return None

def extract_param(params, key, error_message):
    try:
        return params[key]
    except:
        update_status(f'{{"error": "failed", "info":"{error_message}"}}')
        return None

def split_column_values(value, column_name):
    try:
        return value.split(',')
    except Exception as e:
        update_status(f'{{"error": "failed", "info": "problem to split {column_name}. {e}"}}')
        return None

def process_partition_id(df, partition_id):
    try:
        partition_list = partition_id.split(',')
        return partition_list, df[partition_list].values[0].tolist()
    except Exception as e:
        update_status(f'{{"error": "failed", "info": "problem to split sto_partition_id. {e}"}}')
        
    
def construct_dataframe(df, Params_STO, dummy_cols):
    global STO_OUTPUT_DEFAULT_STATUS

    # Construct DataFrame with specified column names
    try:
        df = df[dummy_cols]
        df.columns = Params_STO["columnnames"]
    except Exception as e:
        STO_OUTPUT_DEFAULT_STATUS = f'{{"error": "failed", "info": "problem constructing the dataframe with columnnames. {e}"}}'
        print_when_exception()
        return None

    # Cast columns to specified types
    column_type_mapping = {
        "float_columnames": pd.to_numeric,
        "integer_columnames": lambda col: col.astype("int"),
        "category_columns": lambda col: col.astype("category"),
        "datetime_columns": pd.to_datetime
    }

    for col_type, cast_func in column_type_mapping.items():
        if col_type in Params_STO:
            for c in Params_STO[col_type]:
                if len(c) > 0:
                    try:
                        # Replace spaces with empty strings before applying the type conversion
                        df[c] = df[c].str.replace(" ", "").astype(str)  # Ensure string type for replace
                        df[c] = cast_func(df[c])
                    except:
                        STO_OUTPUT_DEFAULT_STATUS = f'{{"error": "failed", "info": "column {c} cannot be converted to {col_type.split("_")[0]} Python"}}'
                        print_when_exception()

    # Drop rows with all NaN values
    df = df.dropna(how="all")

    # Check if enough data remains
    if df.shape[0] < 1:
        STO_OUTPUT_DEFAULT_STATUS = f'{{"error": "failed", "info": "not enough data left after the dropna. Only {df.shape[0]} rows."}}'
        print_when_exception()


    return df


df, dummy_cols = reconstruct_pandas_dataframe(beg_cols, end_cols)

if df.shape[0] < 1:
    sys.exit()



# Extract values
try:
    sto_fake_row      = df['sto_fake_row'].values[0]
    sto_model_id      = df['sto_model_id'].values[0]
    sto_row_id        = df['sto_row_id'].values[0]
    sto_partition_id  = df['sto_partition_id'].values[0]
    sto_fold_id       = df['sto_fold_id'].values[0]
    sto_code_type     = df['sto_code_type'].values[0]
    sto_code          = df['sto_code'].values[0]
    arguments         = df['arguments'].values[0]
    id_trained_model  = df['id_trained_model'].values[0]
    model_type        = df['model_type'].values[0]
    sto_trained_model = df['sto_trained_model'].values[0]
except Exception as e:
    STO_OUTPUT_DEFAULT_STATUS = f'{{"error": "failed", "info": "Extract values failed. {e}"}}'
    print_when_exception()



execution_time    = parse_execution_time(df)


# Update status and model ID
STO_OUTPUT_DEFAULT_STATUS = f"{sto_partition_id} {sto_row_id} {sto_fold_id}"
STO_OUTPUT_DEFAULT_STO_MODEL_ID = sto_model_id

# Rebuild parameters
Params = parse_arguments(df)
if Params is None:
    print_when_exception()
    sys.exit()

Params_STO       = extract_param(Params, 'sto_parameters', 'there is no field sto_parameters in arguments')
Params_Model     = extract_param(Params, 'model_parameters', 'there is no field model_parameters in arguments')

# Split column values
sto_row_id       = split_column_values(sto_row_id, 'sto_row_id')
sto_fold_id      = split_column_values(sto_fold_id, 'sto_fold_id')
sto_partition_id = split_column_values(sto_partition_id, 'sto_partition_id')

# Set the proper data types:
try:
    df = construct_dataframe(df, Params_STO, dummy_cols)
except Exception as e:
    STO_OUTPUT_DEFAULT_STATUS = f'{{"error": "failed", "info": "Set the proper data types failed. {e}"}}'
    print_when_exception()



nb_partitions    = len(sto_partition_id)
nb_rows          = len(sto_row_id)

# rebuild the code
Code = base64.b64decode(sto_code).decode()
STO_OUTPUT_DEFAULT_MODEL_TYPE = model_type
STO_OUTPUT_DEFAULT_TRAINED_MODEL_ID = id_trained_model

try:
    exec(Code)
except Exception as e:
    STO_OUTPUT_DEFAULT_STATUS = f'{{"error": "failed", "info": "the code cannot be executed. Please test it locally first. {e}"}}'
    print_when_exception()



if sto_code_type == 'python class':
    # Instantiate the model
    try:
        _t_load_start = _time.time()
        # tds_training.py emits a clean base64 string (no b'...' wrapper) — see
        # the comment in tds_training.py at the modelSerB64 = base64.b64encode...
        # block. Older trained-model rows may still carry the legacy b'...'
        # wrapper, so strip [2:-1] only when it's actually there. Mirrors the
        # defensive logic in tds_scoring_apply.py to avoid corrupting the
        # base64 (which would lead to pickle.loads failing and the script
        # emitting a 'failed' STATUS that gets filtered out by the INSERT).
        _payload = sto_trained_model
        if isinstance(_payload, str) and _payload.startswith("b'") and _payload.endswith("'"):
            _payload = _payload[2:-1]
        model = pickle.loads(base64.b64decode(_payload))
        LOAD_TIME = _time.time() - _t_load_start
    except Exception as e:
        STO_OUTPUT_DEFAULT_STATUS = f'{{"error": "failed", "info": "the model cannot be deserialized. Check trained model object.{sto_trained_model}"}}'
        print_when_exception()
else:
    STO_OUTPUT_DEFAULT_STATUS = f'{{"error": "failed", "info": "unkown code type: {sto_code_type}"}}'
    print_when_exception()


try:
    model_type = model.get_model_type()
except Exception as e:
    model_type = 'unknown model type'

try:
    model_metadata = model.get_description()
except Exception as e:
    model_metadata = '{}'

batch = 1
_prev_print_time = 0.0   # PRINT_TIME of the previous batch (one-step lag)
while True:

    # Run the score method on the data — measure predict cost for THIS batch.
    _t_predict_start = _time.time()
    try:
        columns_in = df.columns
        df = model.score(df)
        columns_out = df.columns
    except Exception as e:
        STO_OUTPUT_DEFAULT_STATUS = f'{{"error": "failed", "info": "the model run failed. {e}"}}'
        print_when_exception()

    try:
        new_columns = set(columns_out) - set(columns_in)
        new_columns = list(new_columns)
        df = df[new_columns + sto_partition_id + sto_row_id]
        df.drop_duplicates(inplace=True)
    except Exception as e:
        STO_OUTPUT_DEFAULT_STATUS = f'{{"error": "failed", "info": "df = df[["sto_partition_id", "sto_row_id"] + list(new_columns)] failed. columns_in : {",".join(columns_in)} columns_out : {",".join(columns_out)} sto_partition_id : {",".join(sto_partition_id)} sto_row_id : {",".join(sto_row_id)} {e}"}}'
        print_when_exception()
    PROCESS_TIME_BATCH = _time.time() - _t_predict_start

    # Update module-level globals consumed by _timing_suffix() below.
    BATCH_NO_GLOBAL    = batch
    PRINT_TIME_BATCH   = _prev_print_time
    TOTAL_TIME_BATCH   = PROCESS_TIME_BATCH + PRINT_TIME_BATCH

    # Emit the batch — buffered single-write pattern mirroring
    # tds_scoring_apply.py / tds_vector_embedding_lake.optimized_output_flattened.
    # Build all (row × feature) output lines as a list comprehension, then ONE
    # sys.stdout.write per batch. Reduces ~N×M individual write() syscalls
    # to one. Note Script's IO contract differs from Apply's: tab-delimited
    # with no quoting + downstream awk -F"\t" filter, so every emitted value
    # is run through _safe() to strip embedded \t/\n that would otherwise
    # shift the NF count and get the row dropped.
    _t_write_start = _time.time()
    try:
        metadata = {
            "error": "successful",
            "batch": batch,
            "job":   unique_id,
            "batch_size": df.shape[0],
        }
        status_safe = _safe(str(metadata).replace("'", '"'))
        sm_safe   = _safe(sto_model_id)
        mt_safe   = _safe(model_type)
        itm_safe  = _safe(id_trained_model)
        et_safe   = _safe(execution_time)

        # Pre-built constant suffix shared by every row of this batch (status
        # + IDs + timing + execution time). All per-batch numerics are read
        # from the module globals set just above.
        suffix = (
            status_safe + DELIMITER +
            sm_safe + DELIMITER +
            mt_safe + DELIMITER +
            itm_safe + DELIMITER +
            SCRIPT_UUID + DELIMITER +
            f"{TOTAL_TIME_BATCH:.6f}" + DELIMITER +
            f"{IMPORT_TIME:.6f}" + DELIMITER +
            f"{LOAD_TIME:.6f}" + DELIMITER +
            f"{PROCESS_TIME_BATCH:.6f}" + DELIMITER +
            f"{PRINT_TIME_BATCH:.6f}" + DELIMITER +
            str(BATCH_NO_GLOBAL) + DELIMITER +
            et_safe
        )

        # Project to the columns we actually emit, in output order:
        # partition_id cols, row_id cols, then feature cols. itertuples
        # avoids the per-iteration Series construction iterrows() does.
        feature_cols = list(new_columns)
        ordered_cols = sto_partition_id + sto_row_id + feature_cols
        df_ordered   = df[ordered_cols]
        n_part       = len(sto_partition_id)
        n_row        = len(sto_row_id)
        n_feat       = len(feature_cols)

        output_buffer = [
            DELIMITER.join(
                [_safe(tup[i]) for i in range(n_part + n_row)] +
                [_safe(feature_cols[k]),
                 _safe(tup[n_part + n_row + k]),
                 _safe(type(tup[n_part + n_row + k]).__name__),
                 suffix]
            )
            for tup in df_ordered.itertuples(index=False, name=None)
            for k in range(n_feat)
        ]
        sys.stdout.write("\n".join(output_buffer) + "\n")

    except Exception as e:
        STO_OUTPUT_DEFAULT_STATUS = f'{{"error": "failed", "info": "writing the outputs failed. {e}"}}'
        print_when_exception()
    _prev_print_time = _time.time() - _t_write_start

    batch += 1
    # load next batch
    df,dummy_cols = reconstruct_pandas_dataframe(beg_cols, end_cols, batch_size=batch_size+1)
    if df.shape[0]<1:
        # No more rows — clean exit so the SCRIPT operator keeps the rows
        # emitted by the buffered-write block above. sys.exit('...') returns
        # 1 and Teradata discards the whole partition's output.
        sys.exit(0)
    
    # Set the proper data types:
    try:
        df = construct_dataframe(df, Params_STO, dummy_cols)
    except Exception as e:
        STO_OUTPUT_DEFAULT_STATUS = f'{{"error": "failed", "info": "Set the proper data types failed. {e}"}}'
        print_when_exception()