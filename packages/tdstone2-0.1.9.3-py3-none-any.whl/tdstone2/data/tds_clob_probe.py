"""Diagnostic STO probe: read the chunk-anchor row's sto_trained_model field
and emit its length so we can tell whether SCRIPT stdin truncates the CLOB.

Reads ONE line from stdin, splits on tab, prints a single-line tab-delimited
status row. Designed to be run via SCRIPT_COMMAND on the same on-clause view
the scoring script uses, with the same RETURNS shape (single output row per
partition with 'len=NNN' encoded into FEATURE_VALUE).
"""
import sys

# Match tds_scoring.py end_cols layout: stdin per-row =
#   [dummy cols ...] + sto_fake_row, sto_model_id, sto_row_id,
#                       sto_partition_id, sto_fold_id, sto_code_type,
#                       sto_code, arguments, id_trained_model, model_type,
#                       sto_trained_model, execution_time
# We don't know the dummy-col count up front; sto_trained_model is the 11th
# from the END. So index = -2 (counting from -1 = execution_time). Simpler:
# split, count, sto_trained_model is at fields[-2].
DELIMITER = '\t'
line = sys.stdin.readline()
if not line:
    sys.exit(0)
fields = line.rstrip('\n').split(DELIMITER)
sto_trained_model = fields[-2] if len(fields) >= 2 else ''
sto_partition_id  = fields[-9] if len(fields) >= 9 else '?'

# Emit one minimal-shape row so we can see the CLOB length received.
# Output shape: partition_id, row_id, FEATURE_NAME, FEATURE_VALUE, FEATURE_TYPE,
#               STATUS, ID_MODEL, MODEL_TYPE, ID_TRAINED_MODEL,
#               SCRIPT_UUID, TOTAL_TIME, IMPORT_TIME, LOAD_TIME,
#               PROCESS_TIME, PRINT_TIME, BATCH_NO, EXECUTION_TIME
# 17 fields total — matches the awk NF==17 filter.
print(DELIMITER.join([
    str(sto_partition_id),  # Partition_ID
    '0',                    # ID
    'CLOB_LEN',             # FEATURE_NAME
    str(len(sto_trained_model)),  # FEATURE_VALUE
    'int',                  # FEATURE_TYPE
    '{"error":"successful","probe":"clob_len"}',  # STATUS
    'probe',                # ID_MODEL
    'probe',                # MODEL_TYPE
    'probe',                # ID_TRAINED_MODEL
    'probe-uuid',           # SCRIPT_UUID
    '0.0', '0.0', '0.0', '0.0', '0.0',  # TOTAL/IMPORT/LOAD/PROCESS/PRINT
    '0',                    # BATCH_NO
    '9999-01-01 00:00:00.000000-04:00',  # EXECUTION_TIME
]))
sys.exit(0)
