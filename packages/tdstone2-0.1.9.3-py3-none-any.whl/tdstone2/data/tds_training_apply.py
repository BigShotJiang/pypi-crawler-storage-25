"""Apply (VCL/OpenAF) variant of tds_training.py.

Differences from tds_training.py:
  - stdin is parsed with csv.reader (Apply ships data as csv, not tab-delimited).
  - stdout is written with csv.writer (QUOTE_MINIMAL) so that base64 CLOB columns
    containing the configured DELIMITER survive the round trip.
  - DELIMITER is ',' to match Mapper._generate_apply_query (DELIMITER(',')).
  - No awk filter pipe — every emitted row has the same shape, so the Apply
    consumer's RETURNS column count matches the script's writer output exactly.

Everything else (model fit, ONNX export, pickle path, status JSON) mirrors the
Script-flavoured tds_training.py byte-for-byte.
"""
import sys
import csv
import faulthandler
import numpy as np
import pandas as pd
import json
import base64
import pickle

faulthandler.enable()

import warnings
warnings.filterwarnings('ignore')

from skl2onnx.common.data_types import FloatTensorType, StringTensorType, Int64TensorType
from skl2onnx import convert_sklearn, to_onnx


def convert_dataframe_schema(df, drop=None):
    inputs = []
    for k, v in zip(df.columns, df.dtypes):
        if drop is not None and k in drop:
            continue
        if v == 'int64':
            t = Int64TensorType([None, 1])
        elif v == 'float64':
            t = FloatTensorType([None, 1])
        else:
            t = StringTensorType([None, 1])
        inputs.append((k, t))
    return inputs


def encode_base64M(data: bytes):
    base64_encoded = base64.b16encode(data)
    base64M_encoded = base64_encoded.decode('utf-8')
    return base64M_encoded


def convert2onnx_mymodel_object(model, dataset, arguments):
    initial_type = []
    for feature in arguments['model_parameters']['column_names_X']:
        if feature in arguments['model_parameters']['column_categorical']:
            try:
                dataset[feature].astype(int)
                initial_type.append((feature, Int64TensorType([None, 1])))
            except ValueError:
                initial_type.append((feature, StringTensorType([None, 1])))
        else:
            if pd.api.types.is_integer_dtype(dataset[feature]):
                initial_type.append((feature, Int64TensorType([None, 1])))
            elif pd.api.types.is_float_dtype(dataset[feature]):
                initial_type.append((feature, FloatTensorType([None, 1])))
            else:
                initial_type.append((feature, StringTensorType([None, 1])))

    onnx_model = convert_sklearn(
        model.model,
        initial_types=initial_type,
        target_opset={'': 12, 'ai.onnx.ml': 3},
    )
    return encode_base64M(onnx_model.SerializeToString())


def list_module_version():
    res = []
    for module in list(sys.modules.keys()):
        try:
            if not 'built-in' in str(module):
                res.append(module + '==' + sys.modules[module].__version__)
        except:
            pass
    return res


STO_OUTPUT_DEFAULT_STO_PARTITION_ID = -1
STR_OUTPUT_DEFAULT_STO_MODEL_ID = -1
STO_OUTPUT_DEFAULT_TRAINED_MODEL_ID = 'STO error'
STO_OUTPUT_DEFAULT_TRAINED_MODEL = 'STO error'
STO_OUTPUT_DEFAULT_MODEL_TYPE = 'None'
STO_OUTPUT_DEFAULT_STATUS = '{"error": "failed"}'
STO_OUTPUT_DEFAULT_MODEL_CHUNK_INDEX = 0
STO_OUTPUT_DEFAULT_MODEL_CHUNK_TOTAL = 1
STO_OUTPUT_DEFAULT_EXECUTION_TIME = '9999-01-01 00:00:00.000000-04:00'

# Maximum size of a single TRAINED_MODEL chunk in characters. Apply RETURNS
# declares VARCHAR(64000) CHARACTER SET LATIN; we leave a small margin to be
# safe against accidental high-bit chars rewritten to ASCII spaces by _safe.
CHUNK_MAX = 60000

nb_partitions = None

DELIMITER = ','
OUTPUT_DELIMITER = DELIMITER

# Apply's stdout reader expects raw delimited rows (no CSV quoting). The
# reference notebook (demos/notebooks td_sklearn/03 - Basic Anomaly Detection
# with Apply (VCL).ipynb) prints each row as a bare delimiter-joined string,
# and using csv.writer with QUOTE_MINIMAL causes Apply to wait indefinitely
# (the parser doesn't unquote, so the row's column count doesn't match the
# RETURNS shape). The base64 CLOB alphabet (A-Za-z0-9+/=) is safe under a
# comma delimiter; STATUS messages get their commas stripped to keep the
# fixed-shape contract.
_SAFE_MAX = 4000  # keep individual columns well under VARCHAR LATIN caps;
                  # TRAINED_MODEL is exempt — see _print_row below.

def _safe(v, max_len=_SAFE_MAX):
    # Apply's stdout reader uses csv with quotechar=" — any literal " in an
    # un-quoted value (e.g. STATUS contains JSON like {"error": "..."}) trips
    # the parser with "bare quotechar in non-quoted-field". Replace " with '
    # so the field stays parseable. Also strip the delimiter and newlines so
    # the fixed-shape contract holds. Drop any byte > 0x7E so non-ASCII content
    # never reaches Apply's RETURNS-typed VARCHAR(LATIN) parser.
    s = str(v)
    s = (s.replace(OUTPUT_DELIMITER, ';')
          .replace('\n', ' ')
          .replace('\r', ' ')
          .replace('"', "'"))
    s = ''.join(c if 0x20 <= ord(c) <= 0x7E else ' ' for c in s)
    if max_len is not None and len(s) > max_len:
        s = s[:max_len - 12] + '...truncated'
    return s


def _print_row(values):
    # Per-column max lengths. With chunking the tail order is
    #   ID_MODEL, ID_TRAINED_MODEL, MODEL_TYPE, STATUS, TRAINED_MODEL,
    #   MODEL_CHUNK_INDEX, MODEL_CHUNK_TOTAL, EXECUTION_TIME
    # so TRAINED_MODEL is the 4th from the end. Cap STATUS at 4000 (RETURNS is
    # VARCHAR(20000) LATIN); let TRAINED_MODEL through up to ~64 KB.
    maxes = [None] * len(values)
    if len(values) >= 4:
        maxes[-4] = 64000  # TRAINED_MODEL
    print(OUTPUT_DELIMITER.join(
        _safe(v, max_len=m if m is not None else _SAFE_MAX)
        for v, m in zip(values, maxes)
    ))


def _resolve_lob(value):
    """Apply ships large fields (CLOB / VARBYTE) as file-path references on
    stdin — e.g. ``/lob/<query-id>/<col>/<token>``. The actual content lives
    in that file. Detect the path and read its content; otherwise return
    the value unchanged.
    """
    if isinstance(value, str) and value.startswith('/lob/'):
        try:
            with open(value, 'rb') as fh:
                return fh.read().decode('latin-1')
        except Exception:
            pass
    return value


def print_outputs():
    tail = [
        STR_OUTPUT_DEFAULT_STO_MODEL_ID,
        STO_OUTPUT_DEFAULT_TRAINED_MODEL_ID,
        STO_OUTPUT_DEFAULT_MODEL_TYPE,
        STO_OUTPUT_DEFAULT_STATUS,
        STO_OUTPUT_DEFAULT_TRAINED_MODEL,
        STO_OUTPUT_DEFAULT_MODEL_CHUNK_INDEX,
        STO_OUTPUT_DEFAULT_MODEL_CHUNK_TOTAL,
        STO_OUTPUT_DEFAULT_EXECUTION_TIME,
    ]
    if nb_partitions is None:
        # Apply rejects the entire result on the first row whose field count
        # doesn't match RETURNS. The legacy STO behaviour was to brute-force
        # 10 candidate row shapes (1..10 partition columns) — that breaks
        # Apply hard. Emit a single best-guess row with one partition column
        # instead; downstream code can refine if needed.
        head = [STO_OUTPUT_DEFAULT_STO_PARTITION_ID]
        _print_row(head + tail)
    elif type(STO_OUTPUT_DEFAULT_STO_PARTITION_ID) == list and len(
            STO_OUTPUT_DEFAULT_STO_PARTITION_ID) == nb_partitions:
        head = [x for x in STO_OUTPUT_DEFAULT_STO_PARTITION_ID]
        _print_row(head + tail)
    else:
        head = [STO_OUTPUT_DEFAULT_STO_PARTITION_ID] * nb_partitions
        _print_row(head + tail)


def print_when_exception():
    print_outputs()
    sys.exit()


def print_trained_model_chunked(payload):
    """Emit one row per chunk of ``payload``.

    Models small enough to fit in a single VARCHAR(64000) row produce a
    single row with MODEL_CHUNK_INDEX=0 / MODEL_CHUNK_TOTAL=1. Models larger
    than that produce N rows sharing the same ID_TRAINED_MODEL but with
    distinct chunk indexes — the scoring on-clause re-orders chunks ahead
    of data rows so the scoring script can reassemble the payload before it
    hits any data row.
    """
    global STO_OUTPUT_DEFAULT_TRAINED_MODEL
    global STO_OUTPUT_DEFAULT_MODEL_CHUNK_INDEX
    global STO_OUTPUT_DEFAULT_MODEL_CHUNK_TOTAL
    if not isinstance(payload, str):
        payload = str(payload)
    if len(payload) <= CHUNK_MAX:
        STO_OUTPUT_DEFAULT_TRAINED_MODEL = payload
        STO_OUTPUT_DEFAULT_MODEL_CHUNK_INDEX = 0
        STO_OUTPUT_DEFAULT_MODEL_CHUNK_TOTAL = 1
        print_outputs()
        return
    chunks = [payload[i:i + CHUNK_MAX] for i in range(0, len(payload), CHUNK_MAX)]
    n = len(chunks)
    for idx, ch in enumerate(chunks):
        STO_OUTPUT_DEFAULT_TRAINED_MODEL = ch
        STO_OUTPUT_DEFAULT_MODEL_CHUNK_INDEX = idx
        STO_OUTPUT_DEFAULT_MODEL_CHUNK_TOTAL = n
        print_outputs()


beg_cols = []

end_cols = [
    'sto_fake_row',
    'sto_model_id',
    'sto_row_id',
    'sto_partition_id',
    'sto_fold_id',
    'sto_code_type',
    'sto_code',
    'arguments',
    'execution_time'
]


def reconstruct_pandas_dataframe(beg_cols, end_cols):
    """Read csv from stdin and return (DataFrame, dummy_cols).

    Apply streams data as delimited rows (no header) — the script knows the
    schema from beg_cols / end_cols and infers dummy_cols from the row width.
    Read stdin eagerly via readlines() (the reference notebook
    demos/notebooks td_sklearn/03 - Basic Anomaly Detection with Apply
    (VCL).ipynb does the same) — lazy csv.reader(sys.stdin) has been
    observed to return zero rows under Apply, with the script reporting
    "The input DataFrame is empty" while the table operator clearly has
    rows in its on-clause view.
    """
    raw = sys.stdin.readlines()
    # AMPs / Apply workers that don't own any rows for the current partition
    # still launch the script. Apply pipes them an empty stdin and expects a
    # clean exit; raising sys.exit(<message>) exits with status 1 and surfaces
    # as Error 9134, killing the whole Apply. Return cleanly instead.
    if not raw:
        sys.exit(0)
    reader = csv.reader(raw, delimiter=DELIMITER, quoting=csv.QUOTE_MINIMAL)
    data_Tbl = [row for row in reader if row]

    if not data_Tbl:
        sys.exit(0)

    num_columns = len(data_Tbl[0])
    dummy_cols = [f"dummy_col_{i}" for i in range(num_columns - len(beg_cols) - len(end_cols))]
    column_names = beg_cols + dummy_cols + end_cols

    if len(set(column_names)) != len(column_names):
        sys.exit("Error: Duplicate column names generated. Check beg_cols and end_cols.")

    df = pd.DataFrame(data_Tbl, columns=column_names)
    return df, dummy_cols


def update_status(message):
    global STO_OUTPUT_DEFAULT_STATUS
    STO_OUTPUT_DEFAULT_STATUS = message
    print_when_exception()


def parse_execution_time(df):
    try:
        return df['execution_time'].values[0]
    except:
        update_status('{"error": "failed", "info":"fails to read execution_time"}')
        return None


def parse_arguments(df):
    try:
        return json.loads(df['arguments'].values[0])
    except:
        update_status('{"error": "failed", "info":"arguments JSON may not be well formed"}')
        return None


def extract_param(params, key, error_message):
    try:
        return params[key]
    except:
        update_status(f'{{"error": "failed", "info":"{error_message}"}}')
        return None


def split_column_values(value, column_name):
    try:
        return value.split(',')
    except Exception as e:
        update_status(f'{{"error": "failed", "info": "problem to split {column_name}. {e}"}}')
        return None


def process_partition_id(df, partition_id):
    try:
        partition_list = partition_id.split(',')
        return partition_list, df[partition_list].values[0].tolist()
    except Exception as e:
        update_status(f'{{"error": "failed", "info": "problem to split sto_partition_id. {e}"}}')
        return None, None


def construct_dataframe(df, Params_STO, dummy_cols):
    global STO_OUTPUT_DEFAULT_STATUS

    try:
        df = df[dummy_cols]
        df.columns = Params_STO["columnnames"]
    except Exception as e:
        STO_OUTPUT_DEFAULT_STATUS = f'{{"error": "failed", "info": "problem constructing the dataframe with columnnames. {e}"}}'
        print_when_exception()
        return None

    column_type_mapping = {
        "float_columnames": pd.to_numeric,
        "integer_columnames": lambda col: col.astype("int"),
        "category_columns": lambda col: col.astype("category"),
        "datetime_columns": pd.to_datetime
    }

    for col_type, cast_func in column_type_mapping.items():
        if col_type in Params_STO:
            for c in Params_STO[col_type]:
                if len(c) > 0:
                    try:
                        df[c] = df[c].str.replace(" ", "").astype(str)
                        df[c] = cast_func(df[c])
                    except:
                        STO_OUTPUT_DEFAULT_STATUS = f'{{"error": "failed", "info": "column {c} cannot be converted to {col_type.split("_")[0]} Python"}}'
                        print_when_exception()

    df = df.dropna(how="all")

    if df.shape[0] < 30:
        STO_OUTPUT_DEFAULT_STATUS = f'{{"error": "failed", "info": "not enough data left after the dropna. Only {df.shape[0]} rows."}}'
        print_when_exception()
        return None

    return df


df, dummy_cols = reconstruct_pandas_dataframe(beg_cols, end_cols)

# Apply spawns workers on every AMP. Workers that don't co-locate with real
# partition data still receive the chunk-anchor "fake rows" (sto_partition_id
# = '-1') from the on-clause view. Without this guard the worker would fall
# through to construct_dataframe() and emit "failed" sentinel rows (e.g.
# 'not enough data left after dropna' / 'arguments JSON may not be well
# formed') that pollute the trained-model repo even though no real partition
# was supposed to be trained here. Exit cleanly instead so the repo only
# carries rows for partitions that actually had data.
if (df['sto_partition_id'].astype(str) == '-1').all():
    sys.exit(0)

sto_fake_row     = df['sto_fake_row'].values[0]
sto_model_id     = df['sto_model_id'].values[0]
sto_row_id       = df['sto_row_id'].values[0]
sto_partition_id = df['sto_partition_id'].values[0]
sto_fold_id      = df['sto_fold_id'].values[0]
sto_code_type    = df['sto_code_type'].values[0]
sto_code         = _resolve_lob(df['sto_code'].values[0])
arguments        = _resolve_lob(df['arguments'].values[0])
df['arguments']  = arguments  # parse_arguments reads from df
execution_time   = parse_execution_time(df)

STO_OUTPUT_DEFAULT_STATUS = f"{sto_partition_id} {sto_row_id} {sto_fold_id}"
STR_OUTPUT_DEFAULT_STO_MODEL_ID = sto_model_id

Params = parse_arguments(df)
if Params is None:
    print_outputs()
    sys.exit()

Params_STO       = extract_param(Params, 'sto_parameters', 'there is no field sto_parameters in arguments')
Params_Model     = extract_param(Params, 'model_parameters', 'there is no field model_parameters in arguments')

sto_row_id       = split_column_values(sto_row_id, 'sto_row_id')
sto_fold_id      = split_column_values(sto_fold_id, 'sto_fold_id')

df = construct_dataframe(df, Params_STO, dummy_cols)
sto_partition_id, STO_OUTPUT_DEFAULT_STO_PARTITION_ID = process_partition_id(df, sto_partition_id)
nb_partitions = len(sto_partition_id)

try:
    sto_code = _resolve_lob(sto_code)
    _padded = sto_code + '=' * ((4 - len(sto_code) % 4) % 4)
    try:
        Code = base64.b64decode(_padded).decode()
    except Exception:
        Code = base64.urlsafe_b64decode(_padded).decode()
except Exception as e:
    _len = len(sto_code) if sto_code is not None else -1
    _head = (sto_code[:60] + '...') if sto_code and len(sto_code) > 60 else str(sto_code)
    STO_OUTPUT_DEFAULT_STATUS = f"err=base64;len={_len};head={_head};orig={e}"
    print_when_exception()

try:
    list1 = list_module_version()
    exec(Code)
    list2 = list_module_version()
    imported_packages = list(set(list2).difference(set(list1)))
except Exception as e:
    STO_OUTPUT_DEFAULT_STATUS = f'{{"error": "failed", "info": "the code cannot be executed. Please test it locally first. {e} {Code[0:100]}"}}'
    print_when_exception()

STO_OUTPUT_DEFAULT_STATUS = sto_code_type

if sto_code_type == 'python class':
    try:
        model = MyModel(**Params_Model)
    except:
        STO_OUTPUT_DEFAULT_STATUS = f'{{"error": "failed", "info": "the model cannot be instanciated. Check whether the model parameters are correct and consistent."}}'
        print_when_exception()

    try:
        model.fit(df)
    except Exception as e:
        STO_OUTPUT_DEFAULT_STATUS = f'{{"error": "failed", "info": "the model run failed. {e}"}}'
        print_when_exception()
else:
    STO_OUTPUT_DEFAULT_STATUS = f'{{"error": "failed", "info": "unknown model type: {sto_code_type}."}}'
    print_when_exception()

try:
    model_type = model.get_model_type()
except Exception as e:
    STO_OUTPUT_DEFAULT_STATUS = f'{{"error": "failed", "info": "issue with get_model_type. {e}"}}'
    print_when_exception()

try:
    model_metadata = model.get_description()
except Exception as e:
    model_metadata = '{}'
    STO_OUTPUT_DEFAULT_STATUS = f'{{"error": "failed", "info": "issue with get_description. {e}"}}'
    print_when_exception()

import uuid

unique_id = str(uuid.uuid4())
STO_OUTPUT_DEFAULT_STATUS = 'after python class'

if 'pickle' in Params_STO['output_format']:
    STO_OUTPUT_DEFAULT_MODEL_TYPE = 'pickle'
    try:
        metadata = {}
        metadata["error"] = "successful"
        metadata["model_type"] = model_type
        metadata.update(json.loads(model_metadata))
        metadata['packages'] = imported_packages
        metadata['python_version'] = str(sys.version)

        modelSer = pickle.dumps(model)
        modelSerB64 = base64.b64encode(modelSer).decode('ascii')

        STO_OUTPUT_DEFAULT_STO_PARTITION_ID = df[sto_partition_id].values[0].tolist()
        STR_OUTPUT_DEFAULT_STO_MODEL_ID = sto_model_id
        STO_OUTPUT_DEFAULT_TRAINED_MODEL_ID = unique_id
        STO_OUTPUT_DEFAULT_MODEL_TYPE = 'pickle'
        STO_OUTPUT_DEFAULT_STATUS = str(json.dumps(metadata)).replace("'", '"')
        print_trained_model_chunked(modelSerB64)
    except Exception as e:
        STO_OUTPUT_DEFAULT_MODEL_TYPE = 'pickle'
        STO_OUTPUT_DEFAULT_STATUS = f'{{"error": "failed", "info": "writing the pickle outputs failed {e}"}}'
        print_when_exception()

if 'onnx' in Params_STO['output_format']:
    STO_OUTPUT_DEFAULT_MODEL_TYPE = 'onnx'
    try:
        onx = convert2onnx_mymodel_object(model, df, Params)
    except Exception as e:
        STO_OUTPUT_DEFAULT_STATUS = f'{{"error": "failed", "info": "model conversion to ONNX failed {e}"}}'
        print_when_exception()

    try:
        metadata = {}
        metadata["error"] = "successful"
        metadata["model_type"] = model_type
        metadata.update(json.loads(model_metadata))
        metadata['packages'] = imported_packages
        metadata['python_version'] = str(sys.version)
        metadata['features'] = Params_Model['column_names_X']
        metadata['target'] = Params_Model['target']

        STO_OUTPUT_DEFAULT_STO_PARTITION_ID = df[sto_partition_id].values[0].tolist()
        STR_OUTPUT_DEFAULT_STO_MODEL_ID = sto_model_id
        STO_OUTPUT_DEFAULT_TRAINED_MODEL_ID = unique_id
        STO_OUTPUT_DEFAULT_MODEL_TYPE = 'onnx'
        STO_OUTPUT_DEFAULT_STATUS = str(json.dumps(metadata)).replace("'", '"')
        print_trained_model_chunked(onx)
    except Exception as e:
        STO_OUTPUT_DEFAULT_STATUS = f'{{"error": "failed", "info": "writing the onnx outputs failed {e}"}}'
        print_when_exception()
