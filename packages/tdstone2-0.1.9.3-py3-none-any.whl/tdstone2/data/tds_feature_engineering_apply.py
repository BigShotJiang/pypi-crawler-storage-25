"""Apply (VCL/OpenAF) variant of tds_feature_engineering.py.

Differences vs tds_feature_engineering.py:
  - csv-based stdin/stdout (DELIMITER ',', csv.reader / csv.writer with QUOTE_MINIMAL).
  - Single-pass read of the partition stream into pandas.
  - Reuses inputs_ schema (beg_cols / end_cols) but resolves header via dummy_cols
    instead of slicing by exec-assigned indices.

ML logic (model.transform, output emission) mirrors tds_feature_engineering.py.
"""
import statsmodels  # noqa: F401  (preserve import-time side effects parity with Script variant)
import sys
import csv
import numpy as np
import pandas as pd
import json
import base64
import pickle

import warnings
warnings.filterwarnings('ignore')


STO_OUPTUT_DEFAULT_STO_PARTITION_ID = [-1]
STO_OUPTUT_DEFAULT_STO_ROW_ID       = [-1]
STO_OUPTUT_DEFAULT_FEATURE_NAME     = 'STO error'
STO_OUPTUT_DEFAULT_FEATURE_VALUE    = 'STO error'
STO_OUTPUT_DEFAULT_FEATURE_TYPE     = 'None'
STO_OUPTUT_DEFAULT_STATUS           = '{"error": "failed"}'
STO_OUTPUT_DEFAULT_STO_MODEL_ID     = 'STO error'
STO_OUPTUT_DEFAULT_EXECUTION_TIME   = '9999-01-01 00:00:00.000000-04:00'

DELIMITER = ','

# Apply expects raw delimited stdout — no CSV quoting.
_SAFE_MAX = 4000  # keep individual columns well under VARCHAR LATIN caps

def _safe(v):
    # Strip Apply's csv quotechar (") along with delimiter / newlines, drop
    # any byte > 0x7E so non-ASCII content never reaches Apply's RETURNS-typed
    # VARCHAR(LATIN) parser.
    s = str(v)
    s = (s.replace(DELIMITER, ';')
          .replace('\n', ' ')
          .replace('\r', ' ')
          .replace('"', "'"))
    s = ''.join(c if 0x20 <= ord(c) <= 0x7E else ' ' for c in s)
    if len(s) > _SAFE_MAX:
        s = s[:_SAFE_MAX - 12] + '...truncated'
    return s


def _print_row(values):
    print(DELIMITER.join(_safe(v) for v in values))


def _resolve_lob(value):
    """Apply ships large input fields as /lob/<query>/<col>/<token> paths."""
    if isinstance(value, str) and value.startswith('/lob/'):
        try:
            with open(value, 'rb') as fh:
                return fh.read().decode('latin-1')
        except Exception:
            pass
    return value


nb_partitions = None
nb_rows = 1


def print_outputs():
    tail = [
        STO_OUPTUT_DEFAULT_FEATURE_NAME,
        STO_OUPTUT_DEFAULT_FEATURE_VALUE,
        STO_OUTPUT_DEFAULT_FEATURE_TYPE,
        STO_OUPTUT_DEFAULT_STATUS,
        STO_OUTPUT_DEFAULT_STO_MODEL_ID,
        STO_OUPTUT_DEFAULT_EXECUTION_TIME,
    ]
    if nb_partitions is None:
        # Single best-guess error row, not 10 candidate shapes — Apply
        # rejects the full result on first row-count mismatch.
        head = [STO_OUPTUT_DEFAULT_STO_PARTITION_ID[0], STO_OUTPUT_DEFAULT_STO_ROW_ID]
        _print_row(head + tail)
    elif (type(STO_OUPTUT_DEFAULT_STO_PARTITION_ID) == list
          and len(STO_OUPTUT_DEFAULT_STO_PARTITION_ID) == nb_partitions
          and type(STO_OUPTUT_DEFAULT_STO_ROW_ID) == list
          and len(STO_OUPTUT_DEFAULT_STO_ROW_ID) == nb_rows):
        head = [x for x in STO_OUPTUT_DEFAULT_STO_PARTITION_ID]
        head += [x for x in STO_OUPTUT_DEFAULT_STO_ROW_ID]
        _print_row(head + tail)
    else:
        head = [STO_OUPTUT_DEFAULT_STO_PARTITION_ID] * nb_partitions
        head += [STO_OUPTUT_DEFAULT_STO_ROW_ID] * nb_rows
        _print_row(head + tail)


def print_when_exception():
    print_outputs()
    sys.exit()


def list_module_version():
    res = []
    for module in list(sys.modules.keys()):
        try:
            if not 'built-in' in str(module):
                res.append(module + '==' + sys.modules[module].__version__)
        except:
            pass
    return res


beg_cols = []

end_cols = [
    'sto_fake_row',
    'sto_model_id',
    'sto_row_id',
    'sto_partition_id',
    'sto_code_type',
    'sto_code',
    'arguments',
    'execution_time'
]


# Read the entire csv stream once. Use readlines() + QUOTE_NONE to mirror the
# reference Apply notebook (lazy csv.reader(sys.stdin) has been observed to
# yield zero rows under Apply even when the on-clause view has data).
raw = sys.stdin.readlines()
reader = csv.reader(raw, delimiter=DELIMITER, quoting=csv.QUOTE_MINIMAL)
rows = [r for r in reader if r]

if not rows:
    sys.exit()

num_columns = len(rows[0])
dummy_cols = [f"dummy_col_{i}" for i in range(num_columns - len(beg_cols) - len(end_cols))]
column_names = beg_cols + dummy_cols + end_cols

if len(set(column_names)) != len(column_names):
    sys.exit("Error: Duplicate column names generated. Check beg_cols and end_cols.")

raw_df = pd.DataFrame(rows, columns=column_names)

# Apply spawns workers on every AMP. Workers that don't co-locate with real
# partition data still receive the chunk-anchor "fake rows" (sto_partition_id
# = '-1'). Without this guard the worker would fall through to extracting
# fixed columns / running the FE callable and emit spurious "failed" sentinel
# rows even though no real partition was supposed to be processed here. Exit
# cleanly so the FE results table only carries rows for partitions with data.
if (raw_df['sto_partition_id'].astype(str) == '-1').all():
    sys.exit(0)

# Pull the per-partition fixed columns from the first row.
try:
    sto_fake_row     = raw_df['sto_fake_row'].values[0]
    sto_model_id     = raw_df['sto_model_id'].values[0]
    sto_row_id       = raw_df['sto_row_id'].values[0]
    sto_partition_id = raw_df['sto_partition_id'].values[0]
    sto_code_type    = raw_df['sto_code_type'].values[0]
    sto_code         = _resolve_lob(raw_df['sto_code'].values[0])
    arguments        = _resolve_lob(raw_df['arguments'].values[0])
    execution_time   = raw_df['execution_time'].values[0]
except Exception as e:
    STO_OUPTUT_DEFAULT_STATUS = f'{{"error": "failed", "info": "extracting fixed columns failed. {e}"}}'
    print_when_exception()

STO_OUPTUT_DEFAULT_EXECUTION_TIME = execution_time

try:
    from io import StringIO
    from contextlib import redirect_stdout
except:
    STO_OUPTUT_DEFAULT_STATUS = '{"error": "failed", "info":"unexpected error in importing io and contextlib packages"}'
    print_when_exception()

try:
    Params = json.loads(arguments)
except:
    STO_OUPTUT_DEFAULT_STATUS = arguments
    print_when_exception()

try:
    Params_STO = Params['sto_parameters']
except:
    STO_OUPTUT_DEFAULT_STATUS = '{"error": "failed", "info":"there is no field sto_parameters in arguments"}'
    print_when_exception()

try:
    Params_Model = Params['model_parameters']
except:
    STO_OUPTUT_DEFAULT_STATUS = '{"error": "failed", "info":"there is no field model_parameters in arguments"}'
    print_when_exception()

# Build the working dataframe from the dummy (real-payload) columns + named schema.
try:
    df = raw_df[dummy_cols].copy()
    df.columns = Params_STO["columnnames"]
    # Strip surrounding spaces in every cell, mirroring the legacy script.
    df = df.applymap(lambda x: x.replace(" ", "") if isinstance(x, str) else x)
except Exception as e:
    STO_OUPTUT_DEFAULT_STATUS = f'{{"error": "failed", "info": "problem constructing the dataframe with columnnames. {e}"}}'
    print_when_exception()

try:
    sto_row_id = sto_row_id.split(',')
    nb_rows = len(sto_row_id)
except Exception as e:
    STO_OUPTUT_DEFAULT_STATUS = f'{{"error": "failed", "info": "problem to split sto_row_id. {e}"}}'
    print_when_exception()

try:
    sto_partition_id = sto_partition_id.split(',')
    nb_partitions = len(sto_partition_id)
    # Carry the partition-id columns onto df so they can be re-emitted (the legacy
    # script slices df[sto_partition_id], so the columns must exist on df).
    for col in sto_partition_id:
        if col not in df.columns:
            df[col] = raw_df[col].values
    STO_OUPTUT_DEFAULT_STO_PARTITION_ID = df[sto_partition_id].values[0].tolist()
except Exception as e:
    STO_OUPTUT_DEFAULT_STATUS = f'{{"error": "failed", "info": "problem to split sto_partition_id. {e}"}}'
    print_when_exception()


if "float_columnames" in Params_STO:
    for c in Params_STO["float_columnames"]:
        if len(c) > 0:
            try:
                df[c] = pd.to_numeric(df[c])
            except:
                STO_OUPTUT_DEFAULT_STATUS = f'{{"error": "failed", "info": "column {c} cannot be converted to float Python"}}'
                print_when_exception()

if "integer_columnames" in Params_STO:
    for c in Params_STO["integer_columnames"]:
        if len(c) > 0:
            try:
                df[c] = df[c].astype('int')
            except:
                STO_OUPTUT_DEFAULT_STATUS = f'{{"error": "failed", "info": "column {c} cannot be converted to int Python"}}'
                print_when_exception()

if "category_columns" in Params_STO:
    for c in Params_STO["category_columns"]:
        if len(c) > 0:
            try:
                df[c] = df[c].astype('category')
            except:
                STO_OUPTUT_DEFAULT_STATUS = f'{{"error": "failed", "info": "column {c} cannot be converted to category Python"}}'
                print_when_exception()

if "datetime_columns" in Params_STO:
    for c in Params_STO["datetime_columns"]:
        if len(c) > 0:
            try:
                df[c] = pd.to_datetime(df[c])
            except:
                STO_OUPTUT_DEFAULT_STATUS = f'{{"error": "failed", "info": "column {c} cannot be converted to category Python"}}'
                print_when_exception()


df = df.dropna(how='all')

if df.shape[0] < 1:
    STO_OUPTUT_DEFAULT_STATUS = f'{{"error": "failed", "info": "not enough data left after the dropna. Only {df.shape[0]} rows."}}'

try:
    Code = base64.b64decode(sto_code).decode()
except Exception as e:
    STO_OUPTUT_DEFAULT_STATUS = f'{{"error": "failed", "info": "the code rebuild the code. Please test it locally first. {e}"}}'
    print_when_exception()

try:
    list1 = list_module_version()
    exec(Code)
    list2 = list_module_version()
    imported_packages = list(set(list2).difference(set(list1)))
except Exception as e:
    STO_OUPTUT_DEFAULT_STATUS = f'{{"error": "failed", "info": "the code cannot be executed. Please test it locally first. {e}"}}'
    print_when_exception()

STO_OUPTUT_DEFAULT_STATUS = sto_code_type


if sto_code_type == 'python class':
    try:
        model = MyModel(**Params_Model)
    except:
        STO_OUPTUT_DEFAULT_STATUS = f'{{"error": "failed", "info": "the model cannot be instanciated. Check whether the model parameters are correct and consistent."}}'
        print_when_exception()

    try:
        columns_in = df.columns
        df = model.transform(df)
    except Exception as e:
        STO_OUPTUT_DEFAULT_STATUS = f'{{"error": "failed", "info": "the model run failed. {e}"}}'
        print_when_exception()

    try:
        columns_out = df.columns
        new_columns = list(set(columns_out) - set(columns_in))
        new_columns = [c for c in new_columns if c not in sto_row_id]
        new_columns = [c for c in new_columns if c not in sto_partition_id]
        columns = [c for c in df.columns]
        df = df[sto_partition_id + sto_row_id + new_columns]
    except Exception as e:
        STO_OUPTUT_DEFAULT_STATUS = f'{{"error": "failed", "info": "problem managing the model outputs. Are you sure you use the script? check you feature engineering mapper attached to your process id. {e} sto_partition_id : {sto_partition_id}, sto_row_id : {sto_row_id}, new_columns : {new_columns}, all columns: {columns}"}}'
        print_when_exception()


try:
    model_type = model.get_model_type()
except Exception as e:
    model_type = 'unknown model type'

try:
    model_metadata = model.get_description()
except Exception as e:
    model_metadata = '{}'

try:
    metadata = {}
    metadata["error"] = "successful"
    metadata["model_type"] = model_type
    metadata.update(eval(model_metadata))
    metadata['packages'] = imported_packages
    metadata['python_version'] = str(sys.version)

    # Per-batch ``optimized_output_flattened`` pattern from
    # tds_vector_embedding_lake.py — pre-compute the constant suffix, build
    # each batch as a list comprehension, single sys.stdout.write per batch,
    # no explicit flush.
    status_safe = _safe(str(metadata).replace("'", '"'))
    sm_safe     = _safe(sto_model_id)
    et_safe     = _safe(STO_OUPTUT_DEFAULT_EXECUTION_TIME)

    n_part = len(sto_partition_id)
    n_row  = len(sto_row_id)
    BATCH_SIZE = 1000

    df_subset = df[sto_partition_id + sto_row_id + new_columns]

    base_suffix = (
        f"{status_safe}{DELIMITER}"
        f"{sm_safe}{DELIMITER}"
        f"{et_safe}"
    )

    def optimized_output_flattened(batch_rows):
        # Single f-string per row, list comprehension, single
        # sys.stdout.write per batch — matches the reference shape in
        # tds_vector_embedding_lake.py verbatim.
        output_buffer = [
            f"{head}{DELIMITER}{_safe(col)}{DELIMITER}{_safe(val)}{DELIMITER}{_safe(type(val).__name__)}{DELIMITER}{base_suffix}"
            for head, feature_vals in batch_rows
            for col_idx, col in enumerate(new_columns)
            for val in (feature_vals[col_idx],)
        ]
        sys.stdout.write("\n".join(output_buffer) + "\n")

    batch_rows = []
    for tup in df_subset.itertuples(index=False, name=None):
        head = DELIMITER.join(_safe(v) for v in tup[:n_part + n_row])
        feature_vals = tup[n_part + n_row:]
        batch_rows.append((head, feature_vals))
        if len(batch_rows) >= BATCH_SIZE:
            optimized_output_flattened(batch_rows)
            batch_rows = []

    if batch_rows:
        optimized_output_flattened(batch_rows)

    sys.exit(0)
except Exception as e:
    STO_OUPTUT_DEFAULT_STATUS = f'{{"error": "failed", "info": "writing the outputs failed {e}"}}'
    print_when_exception()
