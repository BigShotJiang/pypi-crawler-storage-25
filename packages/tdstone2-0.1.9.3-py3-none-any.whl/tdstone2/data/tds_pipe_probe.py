"""Minimal probe: emit ONE hardcoded row, ignore stdin entirely.

Goal: prove the Apply round-trip plumbing works at all.
"""
import sys
print("1,1,probe,0.5,float,ok,m1,probe,t1,uuid1,0.0,0.0,0.0,0.0,0.0,2026-05-03 00:00:00.000000+00:00")
sys.exit(0)
