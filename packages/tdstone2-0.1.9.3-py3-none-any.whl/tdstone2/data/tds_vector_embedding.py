import time
# Start measuring process time and elapsed time
start_process_time = time.process_time()
start_time = time.time()

import warnings
import sys
import numpy as np
import os
import ast
import json


import onnxruntime as ort
from tokenizers import Tokenizer  # Replace AutoTokenizer with Tokenizer from the tokenizers package

import uuid
from collections import OrderedDict

# Generate a UUID
script_uuid = uuid.uuid4()

# Suppress warnings for cleaner output
warnings.filterwarnings('ignore')

# Ensure single-threaded execution
os.environ["OMP_NUM_THREADS"] = "1"

# Define the delimiter for splitting input lines
DELIMITER = '\t'

import sentencepiece as spm       # For spiece.model

def load_tokenizer_from_folder(folder_name: str):
    """
    Load the tokenizer from the specified folder.
    If 'sentencepiece.bpe.model' is present, use it.
    Otherwise, fall back to 'spiece.model' or 'tokenizer.json'.

    Args:
        folder_name (str): The folder where the tokenizer is saved.

    Returns:
        tokenizer: The loaded tokenizer instance (SentencePieceProcessor or Tokenizer).
    """
    sp_bpe_path = os.path.join(folder_name, "sentencepiece.bpe.model")
    sp_path = os.path.join(folder_name, "spiece.model")
    tokenizer_json_path = os.path.join(folder_name, "tokenizer.json")

    if os.path.exists(sp_bpe_path):
        from sentencepiece import SentencePieceProcessor
        sp = SentencePieceProcessor()
        sp.load(sp_bpe_path)
        #print("Loaded tokenizer from sentencepiece.bpe.model")
        return sp, False
    elif os.path.exists(sp_path):
        from sentencepiece import SentencePieceProcessor
        sp = SentencePieceProcessor()
        sp.load(sp_path)
        #print("Loaded tokenizer from spiece.model")
        return sp, False
    elif os.path.exists(tokenizer_json_path):
        from tokenizers import Tokenizer
        tokenizer = Tokenizer.from_file(tokenizer_json_path)
        #print("Loaded tokenizer from tokenizer.json")
        return tokenizer, True
    else:
        raise FileNotFoundError("No suitable tokenizer model found in the folder.")

def mean_pooling(token_embeddings, attention_mask):
    """
    Perform mean pooling on token embeddings, taking the attention mask into account.
    Args:
        token_embeddings: The embeddings for each token in the sentence.
        attention_mask: The attention mask (to exclude padding tokens from pooling).
    Returns:
        sentence_embeddings: The pooled sentence embeddings.
    """
    # Expand attention mask dimensions for proper broadcasting (similar to unsqueeze in PyTorch)
    attention_mask = np.expand_dims(attention_mask, axis=-1).astype(np.float32)

    # Perform mean pooling (sum of token embeddings divided by the sum of attention mask)
    pooled_embeddings = np.sum(token_embeddings * attention_mask, axis=1) / np.clip(np.sum(attention_mask, axis=1),
                                                                                    a_min=1e-9, a_max=None)
    return pooled_embeddings

def vect2dict(embedding_vector):
    return json.dumps(OrderedDict((f"V{i}", float(value)) for i, value in enumerate(embedding_vector)))
    #return f"{len(embedding_vector)}{DELIMITER}{' '.join([str(v) for v in embedding_vector])}"

def inspect_onnx_model_inputs(onnx_session):
    """
    Inspect the ONNX model to check if 'token_type_ids' are required and determine the input sequence length.
    Args:
        onnx_session: The ONNX Runtime session.
    Returns:
        bool: Whether 'token_type_ids' are required.
        int: The max sequence length (or None if not specified).
        int: The rank (number of dimensions) of the model output.
    """
    # Get model input details
    input_names = [input_tensor.name for input_tensor in onnx_session.get_inputs()]

    # Check if 'token_type_ids' is one of the required inputs
    requires_token_type_ids = "token_type_ids" in input_names

    # Inspect the input shape of 'input_ids' to get the max sequence length
    input_ids_info = onnx_session.get_inputs()[input_names.index('input_ids')]
    input_shape = input_ids_info.shape  # e.g. [1, 256] (fixed) or ['batch_size', 'sequence_length'] (dynamic)

    # The sequence-length dim is the second dimension of 'input_ids'. It may be:
    #   - an int (model exported at fixed sequence length)
    #   - a str symbolic name (model exported with dynamic sequence dim)
    #   - None (unspecified)
    # When it is symbolic or unspecified, fall back to BERT's standard max (512) for the
    # probe inference below; the actual tokenizer padding length is governed by the caller.
    raw_seq = input_shape[1] if len(input_shape) > 1 else None
    max_sequence_length = raw_seq if isinstance(raw_seq, int) and raw_seq > 0 else 512
    probe_len = max_sequence_length

    # Run the model with dummy inputs to check the output shape
    dummy_input_ids = np.random.randint(0, 1000, (1, probe_len)).astype('int64')
    dummy_attention_mask = np.ones((1, probe_len)).astype('int64')

    # Prepare dummy input for model inference
    onnx_inputs = {
        'input_ids': dummy_input_ids,
        'attention_mask': dummy_attention_mask
    }

    if requires_token_type_ids:
        onnx_inputs['token_type_ids'] = np.zeros((1, probe_len)).astype('int64')  # Dummy token_type_ids if needed

    # If the model exposes a named 'sentence_embedding' output (Teradata BYOM canonical schema),
    # request just that — it is already mean-pooled and L2-normalized, so the script's downstream
    # pooling step must be skipped. Otherwise fall back to outputs[0] and let rank-3 detection
    # drive the mean_pooling fallback.
    output_names_in_model = [o.name for o in onnx_session.get_outputs()]
    requested_outputs = ['sentence_embedding'] if 'sentence_embedding' in output_names_in_model else None

    # Run the model to inspect the output shape
    outputs = onnx_session.run(requested_outputs, onnx_inputs)
    output_shape = outputs[0].shape  # Check the shape of the output

    # Return: token_type_ids requirement, max sequence length, output shape rank,
    # and the explicit output-name list to use at inference time (None = all outputs).
    return requires_token_type_ids, max_sequence_length, len(output_shape), requested_outputs



# Get the zip file path from sys.argv
zip_file_path = sys.argv[1] if len(sys.argv) > 1 else sys.exit(0)
text_column   = int(sys.argv[2])
try:
    accumulate = ast.literal_eval(sys.argv[3].replace('-', ','))
except Exception:
    sys.exit()
# argv[4] = delimiter (passed by caller, kept for compat but DELIMITER already set above)
batch_size = int(sys.argv[5]) if len(sys.argv) > 5 else 10

os.environ['TRANSFORMERS_CACHE'] = zip_file_path

model_name = os.path.basename(zip_file_path.rstrip('/\\'))
tokenizer, is_Tokenizer = load_tokenizer_from_folder(zip_file_path)
onnx_session = None

requires_token_type_ids = False
requires_mean_pooling   = False
max_sequence_length     = 512
requested_outputs       = None

while True:
    # ── Read up to batch_size lines from stdin ────────────────────────
    batch = []
    for _ in range(batch_size):
        try:
            line = input()
        except EOFError:
            break
        if line.strip() == '':
            break
        batch.append(line)

    if not batch:
        break

    # ── Lazy ONNX session init on first batch ─────────────────────────
    if onnx_session is None:
        options = ort.SessionOptions()
        options.intra_op_num_threads = 1
        with open(os.path.join(zip_file_path, "full_model.onnx"), "rb") as f:
            model_bytes = f.read()
        onnx_session = ort.InferenceSession(model_bytes, sess_options=options,
                                            providers=['CPUExecutionProvider'])
        requires_token_type_ids, max_sequence_length, output_rank, requested_outputs = \
            inspect_onnx_model_inputs(onnx_session)
        # rank-3 output = token-level → mean pooling needed;
        # rank-2 (sentence_embedding) = already pooled+normalized.
        requires_mean_pooling = output_rank == 3

    # ── Process each row individually (ONNX batch=1) ──────────────────
    output_buffer = []
    for line in batch:
        t0_proc = time.process_time()
        t0_wall = time.time()

        input_data = line.split(DELIMITER)

        if is_Tokenizer:
            encoded = tokenizer.encode(input_data[text_column])
        else:
            encoded = tokenizer.Encode(input_data[text_column])

        ids = encoded if isinstance(encoded, list) else encoded.ids
        nb_tokens = len(ids)

        ids_arr  = np.array([ids], dtype=np.int64)
        attn_arr = np.ones_like(ids_arr)
        type_arr = np.zeros_like(ids_arr)

        if ids_arr.shape[1] > max_sequence_length:
            ids_arr  = ids_arr[:,  :max_sequence_length]
            attn_arr = attn_arr[:, :max_sequence_length]
            type_arr = type_arr[:, :max_sequence_length]

        pad = max_sequence_length - ids_arr.shape[1]
        ids_arr  = np.pad(ids_arr,  ((0, 0), (0, pad)), constant_values=0)
        attn_arr = np.pad(attn_arr, ((0, 0), (0, pad)), constant_values=0)
        type_arr = np.pad(type_arr, ((0, 0), (0, pad)), constant_values=0)

        onnx_inputs = {"input_ids": ids_arr, "attention_mask": attn_arr}
        if requires_token_type_ids:
            onnx_inputs["token_type_ids"] = type_arr

        outputs    = onnx_session.run(requested_outputs, onnx_inputs)
        embeddings = mean_pooling(outputs[0], attn_arr) if requires_mean_pooling else outputs[0]

        process_time_used = time.process_time() - t0_proc
        elapsed_time      = time.time() - t0_wall

        output_buffer.append(DELIMITER.join(
            [str(input_data[c]) for c in accumulate] +
            [str(script_uuid), str(process_time_used), str(elapsed_time),
             str(len(embeddings[0])), model_name, str(nb_tokens), vect2dict(embeddings[0])]
        ))

    # ── Emit the whole mini-batch in one write ────────────────────────
    sys.stdout.write("\n".join(output_buffer) + "\n")

    if len(batch) < batch_size:
        break  # partial batch → EOF reached

sys.exit(0)