"""Apply (VCL/OpenAF) variant of tds_scoring.py — HASH BY multi-partition.

The on-clause view ships rows ``HASH BY id_partition LOCAL ORDER BY
(id_partition, id_row)`` so one script process per AMP handles ALL
partitions hashed to it (vs PARTITION BY where Apply spawns one script
per partition). Within the stream:

  * ``STO_FAKE_ROW == 1`` marks the first row of a (new) partition.
  * Per-partition state — chunked-model assembly, current-batch buffer,
    per-partition timing — resets at every transition.
  * The script generates ONE SCRIPT_UUID at startup so it identifies the
    AMP, not the partition. SCRIPT_UUID + Partition_ID together identify
    the unit of work.

ML logic identical to tds_scoring.py — only the IO loop is restructured.
"""
import time as _time
_T_SCRIPT_START = _time.time()
_T_IMPORT_START = _T_SCRIPT_START

import sys
import csv
import numpy as np
import pandas as pd
import json
import base64
import pickle
import uuid

import warnings
warnings.filterwarnings('ignore')

# ---------------------------------------------------------------------------
# Per-AMP constants
# ---------------------------------------------------------------------------
IMPORT_TIME = _time.time() - _T_IMPORT_START

# One UUID per script invocation = one per AMP under HASH BY.
unique_id = str(uuid.uuid4())

# Streaming mini-batch size — passed via APPLY_COMMAND sys.argv[1].
try:
    BATCH_SIZE = int(sys.argv[1]) if len(sys.argv) > 1 else 1000
    if BATCH_SIZE < 1:
        BATCH_SIZE = 1000
except Exception:
    BATCH_SIZE = 1000

DELIMITER = ','

STO_OUTPUT_DEFAULT_STO_PARTITION_ID = -1
STO_OUTPUT_DEFAULT_STO_ROW_ID = -1
STO_OUTPUT_DEFAULT_STO_MODEL_ID = -1
STO_OUTPUT_DEFAULT_FEATURE_NAME = 'STO error'
STO_OUTPUT_DEFAULT_FEATURE_VALUE = 'STO error'
STO_OUTPUT_DEFAULT_FEATURE_TYPE = 'None'
STO_OUTPUT_DEFAULT_STATUS = '{"error": "failed"}'
STO_OUTPUT_DEFAULT_MODEL_TYPE = 'STO error'
STO_OUTPUT_DEFAULT_TRAINED_MODEL_ID = 'STO error'
STO_OUTPUT_DEFAULT_EXECUTION_TIME = '9999-01-01 00:00:00.000000-04:00'

_SAFE_MAX = 4000

# Pre-built bytes translation table for _safe() — applied via the
# C-implemented bytes.translate() which is ~50-100x faster than the old
# per-char generator. Mappings:
#   - ASCII control chars 0x00-0x1F -> space (\n and \r included)
#   - DELIMITER (',') -> ';'
#   - '"' -> "'"
#   - 0x7F-0xFF (non-printable / extended) -> space
#   - All other 0x20-0x7E codepoints kept as-is.
_SAFE_BYTE_TRANS = bytearray(range(256))
for _i in range(0x20):           # control chars 0x00-0x1F (incl \n, \r, \t)
    _SAFE_BYTE_TRANS[_i] = 0x20  # space
_SAFE_BYTE_TRANS[ord(',')] = ord(';')
_SAFE_BYTE_TRANS[ord('"')] = ord("'")
for _i in range(0x7F, 0x100):    # non-printable / high bit
    _SAFE_BYTE_TRANS[_i] = 0x20  # space
_SAFE_BYTE_TRANS = bytes(_SAFE_BYTE_TRANS)
del _i


def _safe(v):
    """Sanitize a value for emission as a CSV field on Apply's stdout.

    Hot path uses C-level bytes.translate() instead of a Python char-by-char
    generator. ASCII inputs (the vast majority of scoring values) are handled
    in a single pass; non-ASCII inputs go through encode(errors='replace')
    first which substitutes them with '?' that the translate then leaves
    alone (no special handling needed)."""
    s = str(v)
    try:
        b = s.encode('ascii')
    except UnicodeEncodeError:
        b = s.encode('ascii', errors='replace')
    s = b.translate(_SAFE_BYTE_TRANS).decode('ascii')
    if len(s) > _SAFE_MAX:
        s = s[:_SAFE_MAX - 12] + '...truncated'
    return s


def _print_row(values):
    print(DELIMITER.join(_safe(v) for v in values))


def _resolve_lob(value):
    """Apply ships large input fields as ``/lob/<query>/<col>/<token>`` file
    paths on stdin — open the file to get the actual content."""
    if isinstance(value, str) and value.startswith('/lob/'):
        try:
            with open(value, 'rb') as fh:
                return fh.read().decode('latin-1')
        except Exception:
            pass
    return value


def _to_int(v):
    try:
        return int(v)
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Per-AMP cumulative timing
# ---------------------------------------------------------------------------
PROCESS_TIME_TOTAL = 0.0
PRINT_TIME_TOTAL   = 0.0
_T_FIRST_EMIT = None  # set on first emit so PRINT_TIME = wall-clock since first emit


def _now():
    return _time.time() - _T_SCRIPT_START


# ---------------------------------------------------------------------------
# Per-partition state — created fresh at every STO_FAKE_ROW == 1 transition
# ---------------------------------------------------------------------------
def make_partition_state():
    return {
        'chunks_collected': {},
        'chunk_total_expected': None,
        'data_buffer': [],
        'model': None,
        'metadata_loaded': False,
        'sto_partition_id_list': None,
        'sto_row_id_list': None,
        'sto_fold_id_list': None,
        'sto_code_type': None,
        'sto_model_id': None,
        'id_trained_model': None,
        'model_type': None,
        'execution_time': None,
        'Params_STO': None,
        'new_columns': None,
        '_T_LOAD_START': _time.time(),
        'LOAD_TIME': 0.0,
        'PROCESS_TIME': 0.0,    # cumulative, kept for skip/error rows
        'failed_status': None,  # if non-None, partition is poisoned — emit one error row at flush
        # Per-batch instrumentation. Each call to _process_and_emit emits one
        # batch; we tag every output row of that batch with the batch's own
        # PROCESS_TIME (predict cost) and the previous batch's PRINT_TIME (one-
        # step lag — last batch's stdout cost gets attributed to next batch's
        # rows; the very first batch records 0.0). TOTAL_TIME becomes the
        # batch's predict + previous-print sum, NOT cumulative since script
        # start. LOAD_TIME / IMPORT_TIME stay one-time.
        'batch_no': 0,
        '_t_last_emit_end': None,
        '_prev_print_time': 0.0,
        '_batch_predict_time': 0.0,
    }


st = None
column_names = None
data_col_names = None


# ---------------------------------------------------------------------------
# Output paths
# ---------------------------------------------------------------------------
nb_partitions = None
nb_rows = None


def _print_error_row():
    """Emit one fixed-shape error row using STO_OUTPUT_DEFAULT_* + cumulative
    timing. Used for hard failures where we can't continue."""
    tail = [
        STO_OUTPUT_DEFAULT_FEATURE_NAME,
        STO_OUTPUT_DEFAULT_FEATURE_VALUE,
        STO_OUTPUT_DEFAULT_FEATURE_TYPE,
        STO_OUTPUT_DEFAULT_STATUS,
        STO_OUTPUT_DEFAULT_STO_MODEL_ID,
        STO_OUTPUT_DEFAULT_MODEL_TYPE,
        STO_OUTPUT_DEFAULT_TRAINED_MODEL_ID,
        unique_id,
        f"{_now():.6f}",
        f"{IMPORT_TIME:.6f}",
        f"{(st['LOAD_TIME'] if st else 0.0):.6f}",
        f"{(st['PROCESS_TIME'] if st else 0.0):.6f}",
        f"{PRINT_TIME_TOTAL:.6f}",
        '0',  # BATCH_NO — error row, not associated with a batch
        STO_OUTPUT_DEFAULT_EXECUTION_TIME,
    ]
    if nb_partitions is None:
        head = [STO_OUTPUT_DEFAULT_STO_PARTITION_ID, STO_OUTPUT_DEFAULT_STO_ROW_ID]
    else:
        head = [STO_OUTPUT_DEFAULT_STO_PARTITION_ID] * nb_partitions
        head += [STO_OUTPUT_DEFAULT_STO_ROW_ID] * nb_rows
    _print_row(head + tail)


def _emit_skip_for_partition(state, info):
    """Emit one error row for a partition we're skipping (e.g. couldn't
    assemble its model). Doesn't terminate the script — the next
    partition's stream continues.

    head values are -1 so they can be cast to INTEGER in the RETURNS clause
    (pclass/passenger are declared INTEGER). The actual error info is in STATUS;
    ID_TRAINED_MODEL identifies which partition failed."""
    head_n = (len(state['sto_partition_id_list'] or []) or 1) + (len(state['sto_row_id_list'] or []) or 1)
    head = ['-1'] * head_n
    tail = [
        'STO error', 'STO error', 'None',
        f'{{"error": "failed", "info": "{info}"}}',
        _safe(state.get('sto_model_id') or 'unknown'),
        _safe(state.get('model_type') or 'unknown'),
        _safe(state.get('id_trained_model') or 'unknown'),
        unique_id,
        f"{_now():.6f}",
        f"{IMPORT_TIME:.6f}",
        f"{state['LOAD_TIME']:.6f}",
        f"{state['PROCESS_TIME']:.6f}",
        f"{PRINT_TIME_TOTAL:.6f}",
        '0',  # BATCH_NO — skip/error row, not associated with a batch
        _safe(state.get('execution_time') or '9999-01-01 00:00:00.000000-04:00'),
    ]
    _print_row(head + tail)


def _cast_columns(df, params_sto):
    """Replicate tds_scoring.construct_dataframe's type-casting on the
    dummy_cols subset of the buffered DataFrame. Renames to user columns,
    then casts per Params_STO."""
    df = df[data_col_names].copy()
    df.columns = params_sto["columnnames"]
    column_type_mapping = {
        "float_columnames": pd.to_numeric,
        "integer_columnames": lambda c: c.astype("int"),
        "category_columns": lambda c: c.astype("category"),
        "datetime_columns": pd.to_datetime,
    }
    for col_type, cast_func in column_type_mapping.items():
        if col_type in params_sto:
            for c in params_sto[col_type]:
                if len(c) > 0:
                    try:
                        df[c] = df[c].str.replace(" ", "").astype(str)
                        df[c] = cast_func(df[c])
                    except Exception:
                        pass
    df = df.dropna(how="all")
    return df


def _emit_batch(df_subset, state):
    """Emit one scored mini-batch in the RETURNS shape — single
    sys.stdout.write per batch, list comprehension verbatim from
    tds_vector_embedding_lake.py.

    Per-batch timing semantics (re-interpreted from the original cumulative
    fields, see make_partition_state docstring):
      PROCESS_TIME = predict time of THIS batch (set by caller in
                     state['_batch_predict_time'])
      PRINT_TIME   = stdout-write time of the PREVIOUS batch (one-step lag;
                     0.0 for the first batch). The current batch's print time
                     is captured at the end of this function and embedded in
                     the next batch's rows.
      TOTAL_TIME   = PROCESS_TIME + PRINT_TIME for this batch.
      BATCH_NO     = monotone batch counter within this partition.
    """
    global PRINT_TIME_TOTAL, _T_FIRST_EMIT
    if df_subset is None or df_subset.shape[0] == 0:
        return
    n_part = len(state['sto_partition_id_list'])
    n_row  = len(state['sto_row_id_list'])

    if _T_FIRST_EMIT is None:
        _T_FIRST_EMIT = _time.time()

    state['batch_no'] += 1

    metadata = {
        "error": "successful",
        "batch": state['batch_no'],
        "job":   unique_id,
        "batch_size": df_subset.shape[0],
    }
    status_safe = _safe(str(metadata).replace("'", '"'))
    sm_safe   = _safe(state['sto_model_id'])
    mt_safe   = _safe(state['model_type'])
    itm_safe  = _safe(state['id_trained_model'])
    et_safe   = _safe(state['execution_time'])

    batch_process_time = float(state.get('_batch_predict_time', 0.0))
    prev_print_time    = float(state.get('_prev_print_time', 0.0))
    batch_total_time   = batch_process_time + prev_print_time
    batch_no           = state['batch_no']

    base_suffix = (
        f"{status_safe}{DELIMITER}"
        f"{sm_safe}{DELIMITER}"
        f"{mt_safe}{DELIMITER}"
        f"{itm_safe}{DELIMITER}"
        f"{unique_id}{DELIMITER}"
        f"{batch_total_time:.6f}{DELIMITER}"
        f"{IMPORT_TIME:.6f}{DELIMITER}"
        f"{state['LOAD_TIME']:.6f}{DELIMITER}"
        f"{batch_process_time:.6f}{DELIMITER}"
        f"{prev_print_time:.6f}{DELIMITER}"
        f"{batch_no:d}{DELIMITER}"
        f"{et_safe}"
    )
    new_cols = state['new_columns']
    output_buffer = [
        f"{head}{DELIMITER}{_safe(col)}{DELIMITER}{_safe(val)}{DELIMITER}{_safe(type(val).__name__)}{DELIMITER}{base_suffix}"
        for head, feature_vals in (
            (DELIMITER.join(_safe(v) for v in tup[:n_part + n_row]),
             tup[n_part + n_row:])
            for tup in df_subset.itertuples(index=False, name=None)
        )
        for col_idx, col in enumerate(new_cols)
        for val in (feature_vals[col_idx],)
    ]
    _t_write_start = _time.time()
    sys.stdout.write("\n".join(output_buffer) + "\n")
    _t_write_end = _time.time()
    # Capture this batch's stdout-write cost so the NEXT batch's rows can
    # report it as PRINT_TIME (one-step lag). Catches the actual kernel write
    # cost — not "elapsed since first emit" like the cumulative version.
    state['_prev_print_time'] = _t_write_end - _t_write_start
    state['_t_last_emit_end'] = _t_write_end
    PRINT_TIME_TOTAL = _t_write_end - _T_FIRST_EMIT


def _process_and_emit(rows, state):
    """Build a DataFrame from a list of data-field lists, cast, score, emit."""
    if not rows or state['model'] is None:
        return
    _t = _time.time()
    df = pd.DataFrame(rows, columns=data_col_names)
    df = _cast_columns(df, state['Params_STO'])
    if df.shape[0] < 1:
        return
    columns_in = list(df.columns)
    df = state['model'].score(df)
    columns_out = list(df.columns)
    if state['new_columns'] is None:
        state['new_columns'] = list(set(columns_out) - set(columns_in))
    df_subset = df[state['sto_partition_id_list'] + state['sto_row_id_list'] + state['new_columns']]
    df_subset = df_subset.drop_duplicates()
    # Per-batch predict time: includes df construction + cast + score + subset
    # extraction. Stored on state so _emit_batch picks it up for the suffix.
    batch_predict = _time.time() - _t
    state['PROCESS_TIME'] += batch_predict             # cumulative — used by skip/error rows
    state['_batch_predict_time'] = batch_predict       # per-batch — used by _emit_batch
    _emit_batch(df_subset, state)


def _flush_partition(state):
    """End-of-partition: drain the data_buffer in BATCH_SIZE-sized slices
    or emit a skip-error row if the model never assembled."""
    if state is None or not state['metadata_loaded']:
        return
    if state['failed_status']:
        _emit_skip_for_partition(state, state['failed_status'])
        state['data_buffer'] = []
        return
    if state['model'] is None:
        # Stream ended (or partition ended) before chunks complete — skip.
        info = (
            f"partition delivered only {len(state['chunks_collected'])} "
            f"chunk row(s) but the trained model needs {state['chunk_total_expected']} chunks. "
            f"Skipping this partition."
        )
        _emit_skip_for_partition(state, info)
        state['data_buffer'] = []
        return
    while len(state['data_buffer']) >= BATCH_SIZE:
        _process_and_emit(state['data_buffer'][:BATCH_SIZE], state)
        del state['data_buffer'][:BATCH_SIZE]
    if state['data_buffer']:
        _process_and_emit(state['data_buffer'], state)
        state['data_buffer'] = []


def _maybe_load_model(state):
    if state['model'] is not None or state['chunk_total_expected'] is None:
        return
    if len(state['chunks_collected']) < state['chunk_total_expected']:
        return
    payload = ''.join(state['chunks_collected'][i] for i in sorted(state['chunks_collected'].keys()))
    if isinstance(payload, str) and payload.startswith("b'") and payload.endswith("'"):
        payload = payload[2:-1]
    try:
        state['model'] = pickle.loads(base64.b64decode(payload))
        state['LOAD_TIME'] = _time.time() - state['_T_LOAD_START']
    except Exception as e:
        state['failed_status'] = f"the model cannot be deserialized: {e}"


def _begin_partition_from_row(row):
    """STO_FAKE_ROW == 1 row. Initialise per-partition state, parse metadata."""
    global st, nb_partitions, nb_rows
    global STO_OUTPUT_DEFAULT_MODEL_TYPE, STO_OUTPUT_DEFAULT_TRAINED_MODEL_ID
    global STO_OUTPUT_DEFAULT_STO_MODEL_ID

    state = make_partition_state()
    try:
        state['sto_model_id']     = row['sto_model_id']
        _spi                      = row['sto_partition_id']
        _sri                      = row['sto_row_id']
        _sfi                      = row['sto_fold_id']
        state['sto_code_type']    = row['sto_code_type']
        sto_code                  = _resolve_lob(row['sto_code'])
        arguments_str             = _resolve_lob(row['arguments'])
        state['id_trained_model'] = row['id_trained_model']
        state['model_type']       = row['model_type']
        state['execution_time']   = row['execution_time']

        ct = _to_int(row.get('sto_model_chunk_total', ''))
        state['chunk_total_expected'] = ct if (ct is not None and ct > 0) else 1

        Params = json.loads(arguments_str)
        Params_STO = Params.get('sto_parameters')
        if Params_STO is None:
            raise ValueError('there is no field sto_parameters in arguments')
        state['Params_STO'] = Params_STO

        state['sto_partition_id_list'] = _spi.split(',')
        state['sto_row_id_list']       = _sri.split(',')
        state['sto_fold_id_list']      = _sfi.split(',')
        # Per-AMP shape constants — same across all partitions handled by
        # this script, set on the first partition.
        nb_partitions = len(state['sto_partition_id_list'])
        nb_rows       = len(state['sto_row_id_list'])

        Code = base64.b64decode(sto_code).decode()
        # exec into globals so pickle.loads can find class definitions later.
        exec(Code, globals())

        STO_OUTPUT_DEFAULT_MODEL_TYPE       = state['model_type']
        STO_OUTPUT_DEFAULT_TRAINED_MODEL_ID = state['id_trained_model']
        STO_OUTPUT_DEFAULT_STO_MODEL_ID     = state['sto_model_id']

        if state['sto_code_type'] != 'python class':
            state['failed_status'] = f"unknown code type: {state['sto_code_type']}"

        state['metadata_loaded'] = True
    except Exception as e:
        state['failed_status'] = f"Extract metadata failed. {e}"
    st = state


# ---------------------------------------------------------------------------
# Streaming main loop — HASH BY: one stream of multiple partitions per AMP
# ---------------------------------------------------------------------------
reader = csv.reader(sys.stdin, delimiter=DELIMITER, quoting=csv.QUOTE_MINIMAL)

beg_cols = []
end_cols = [
    'sto_fake_row',
    'sto_model_id',
    'sto_row_id',
    'sto_partition_id',
    'sto_fold_id',
    'sto_code_type',
    'sto_code',
    'arguments',
    'id_trained_model',
    'model_type',
    'sto_trained_model',
    'sto_model_chunk_index',
    'sto_model_chunk_total',
    'execution_time',
    'hash_bucket',  # appended last; the script doesn't read it, but it's in
                    # the on-clause view so the dummy_col count must include it.
]

try:
    for raw_row in reader:
        if not raw_row:
            continue
        if column_names is None:
            num_columns = len(raw_row)
            data_col_names = [f"dummy_col_{i}" for i in range(num_columns - len(beg_cols) - len(end_cols))]
            column_names = beg_cols + data_col_names + end_cols

        row = dict(zip(column_names, raw_row))
        sfr = _to_int(row.get('sto_fake_row', ''))

        # ---- Partition transition signal: STO_FAKE_ROW == 1 ----
        if sfr == 1:
            if st is not None:
                _flush_partition(st)
            _begin_partition_from_row(row)

        if st is None:
            # Defensive: should always be set by now (first row has sfr==1)
            continue

        # If partition is poisoned, skip work for it (we'll emit one error
        # row at flush time for shape compliance).
        if st['failed_status']:
            continue

        # ---- Harvest chunk content if model not yet ready ----
        is_chunk_row = False
        if st['model'] is None:
            cidx = _to_int(row.get('sto_model_chunk_index', ''))
            stm  = row.get('sto_trained_model', '')
            if cidx is not None and stm:
                st['chunks_collected'][cidx] = _resolve_lob(stm)
                is_chunk_row = True
            _maybe_load_model(st)

        # ---- Buffer data fields for scoring ----
        data_fields = [row[c] for c in data_col_names]
        st['data_buffer'].append(data_fields)

        # ---- If model ready and buffer hits BATCH_SIZE, drain ----
        if st['model'] is not None:
            while len(st['data_buffer']) >= BATCH_SIZE:
                _process_and_emit(st['data_buffer'][:BATCH_SIZE], st)
                del st['data_buffer'][:BATCH_SIZE]

    # ---- End of stdin: flush whatever's pending in the last partition ----
    if st is not None:
        _flush_partition(st)
    sys.exit(0)

except SystemExit:
    pass
except Exception as e:
    STO_OUTPUT_DEFAULT_STATUS = f'{{"error": "failed", "info": "streaming scoring failed {e}"}}'
    _print_error_row()
    sys.exit()
