import uuid
import json
import os
import logging
from tdstone2.utils import execute_query, get_partition_datatype,get_connection_username
from tdstone2.tdstone import TDStone
import teradataml as tdml

logger = logging.getLogger(__name__)

class Mapper():
    
    def __init__(self, **kwargs):
        """
        Initialize the Mapper object.

        Keyword Args:
            id (str, optional): The ID of the mapper. If not provided, a new ID will be generated.
            mapper_type (str, optional): The type of the mapper. Can take values among 'training', 'scoring', 'feature engineering', 'feature engineering reducer', 'forecasting'.
            id_row (str, optional): [Description of id_row argument].
            id_partition (str, optional): [Description of id_partition argument].
            id_fold (str, optional): [Description of id_fold argument].
            dataset (str, optional): [Description of dataset argument].
            metadata (dict, optional): Additional metadata for the mapper. It will be merged with the default metadata, which contains the current user.
            mapper_repository (str, optional): [Description of mapper_repository argument].
            model_repository (str, optional): [Description of model_repository argument].
            trained_model_repository (str, optional): [Description of model_repository argument].
            schema_name (str, optional): [Description of schema_name argument].
            tdstone (obj, optional): The tdstone object.
        """
        
        self.schema_name       = kwargs.get('schema_name',None)
        self.mapper_repository = kwargs.get('mapper_repository',None)
        self.model_repository  = kwargs.get('model_repository',None)
        self.code_repository   = kwargs.get('code_repository',None)
        self.SEARCHUIFDBPATH   = kwargs.get('SEARCHUIFDBPATH',None)
        
        # Apply (VCL/OpenAF) configuration. Defaults preserve Script-only behaviour.
        self.use_apply        = kwargs.get('use_apply', False)
        self.oaf_env          = kwargs.get('oaf_env', None)
        self.apply_env_name   = kwargs.get('apply_env_name', None)
        self.apply_python     = kwargs.get('apply_python', 'python3')
        self.apply_delimiter  = kwargs.get('apply_delimiter', ',')
        # Streaming mini-batch size for tds_scoring_apply.py (Apply path).
        self.apply_scoring_batch_size = int(kwargs.get('apply_scoring_batch_size', 1000))
        # Hash bucket cardinality for HASH BY consolidation (defaults to AMP count).
        self.apply_scoring_hash_buckets = int(kwargs.get('apply_scoring_hash_buckets', 8))
        # use_pti=False emits Lake-compatible DDL (no GENERATED SYSTEM TIMECOLUMN,
        # no PRIMARY TIME INDEX). Defaults align with use_apply.
        self.use_pti          = kwargs.get('use_pti', not self.use_apply)

        # If tdstone is provided, update schema_name, mapper_repository, and model_repository accordingly
        tdstone = kwargs.get('tdstone',None)
        if tdstone is not None:
            self.schema_name = tdstone.schema_name
            self.mapper_repository = tdstone.mapper_repository
            self.code_repository = tdstone.code_repository
            self.model_repository = tdstone.model_repository
            self.SEARCHUIFDBPATH = tdstone.SEARCHUIFDBPATH
            # Inherit Apply settings from the TDStone instance when present.
            self.use_apply       = getattr(tdstone, 'use_apply',       self.use_apply)
            self.oaf_env         = getattr(tdstone, 'oaf_env',         None)
            self.apply_env_name  = getattr(tdstone, 'apply_env_name',  self.apply_env_name)
            self.apply_python    = getattr(tdstone, 'apply_python',    self.apply_python)
            self.apply_delimiter = getattr(tdstone, 'apply_delimiter', self.apply_delimiter)
            self.apply_scoring_batch_size = getattr(
                tdstone, 'apply_scoring_batch_size', self.apply_scoring_batch_size
            )
            self.apply_scoring_hash_buckets = getattr(
                tdstone, 'apply_scoring_hash_buckets', self.apply_scoring_hash_buckets
            )
            self.use_pti         = getattr(tdstone, 'use_pti',         self.use_pti)
            
        # Set default values if the corresponding arguments are not provided
        self.dataset = kwargs.get('dataset', None)
        # Allow callers (e.g. HyperModel) to inject pre-computed schema info to
        # avoid a second get_partition_datatype roundtrip — the dataset SELECT
        # has been observed to flake on VCL OFS schemas after the training
        # mapper has run DDL against the repo schema.
        injected_columns = kwargs.get('dataset_columns', None)
        injected_types   = kwargs.get('types', None)
        if self.dataset is not None:
            if injected_columns is not None and injected_types is not None:
                self.dataset_columns = list(injected_columns)
                self.types = dict(injected_types)
            else:
                dataset = tdml.DataFrame(self.dataset)
                self.dataset_columns = list(dataset.columns)
                self.types = get_partition_datatype(dataset, columns=self.dataset_columns)
        else:
            self.dataset_columns = None
            self.types = None
        self.id_row = kwargs.get('id_row', None)
        self.id_partition = kwargs.get('id_partition', None)
        self.id_fold = kwargs.get('id_fold', None)
        self.mapper_type = kwargs.get('mapper_type', '')

        
        # Determine if this is a new mapper or an existing one based on the provided id
        self.isnewmapper = True if kwargs.get('id') is None else False
        self.id = str(uuid.uuid4()) if kwargs.get('id') is None else kwargs['id']
        try:
            self.metadata = {'user': os.getlogin()}  # Initialize with the current user
        except Exception as e:
            self.metadata = {}
        self.mapper_table_name = 'TDS_MAPPER_'+self.id.replace('-','_')         
        # If metadata is provided, update the existing metadata with the new values
        if kwargs.get('metadata') is not None:
            self.metadata.update(kwargs['metadata'])
            
        self.on_clause_view_name      = 'TDS_ON_CLAUSE_'+self.mapper_type.upper().replace(' ','_')+'_'+self.id.replace('-','_') 
        self.sto_view_name            = 'TDS_STO_'+self.mapper_type.upper().replace(' ','_')+'_'+self.id.replace('-','_') 
        self.trained_model_repository = kwargs.get('trained_model_repository' , 'TDS_TRAINED_MODELS_'+self.id.replace('-','_'))
        self.scores_repository        = kwargs.get('scores_repository' , 'TDS_SCORES_'+self.id.replace('-','_'))
        self.features_repository = kwargs.get('features_repository', 'TDS_FEATURES_' + self.id.replace('-', '_'))
        self.reduced_feature_repository = kwargs.get('reduced_features_repository', 'TDS_REDUCED_FEATURES_' + self.id.replace('-', '_'))
        self.on_clause_volatile_table_name  = 'TDS_VOLATILE_ON_CLAUSE_'+self.mapper_type.upper().replace(' ','_')+'_'+self.id.replace('-','_') 
            
    def _vt(self):
        return "" if (self.use_apply or self.oaf_env) else "CURRENT VALIDTIME "

    def _temporal_columns(self):
        """OFS doesn't allow VALIDTIME, so replace the period block with a
        regular CREATION_DATE on the Apply/VCL path (Error 3706 otherwise)."""
        if self.use_apply or self.oaf_env:
            return "\n                    CREATION_DATE TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP(6)"
        return """\n                    ValidStart TIMESTAMP(0) WITH TIME ZONE NOT NULL,
                    ValidEnd TIMESTAMP(0) WITH TIME ZONE NOT NULL,
                    PERIOD FOR ValidPeriod  (ValidStart, ValidEnd) AS VALIDTIME"""

    def _table_options(self):
        """Return the CREATE TABLE options block for this Mapper.

        On the Apply path, every per-mapper table is pinned to OFS via
        ``STORAGE = TD_OFSSTORAGE`` so the on-clause view (which Apply reads on
        the ACC) sees only OFS data and ACC can write the result without a
        cross-cluster INSERT (Error 6881). On the Script path the legacy
        block-storage clauses are preserved.
        """
        if self.use_apply:
            return ",\n                NO FALLBACK,\n                MAP = TD_MAP2,\n                STORAGE = TD_OFSSTORAGE"
        return ",\n                FALLBACK,\n                NO BEFORE JOURNAL,\n                NO AFTER JOURNAL,\n                CHECKSUM = DEFAULT,\n                DEFAULT MERGEBLOCKRATIO,\n                MAP = TD_MAP1"

    def update_metadata(self, metadata):
        """
        Update the metadata for the model.

        Args:
            metadata (dict): New metadata to update.
        """        
        self.metadata.update(metadata)

    def update(self, **kwargs):
        """
        Update the arguments for this mapper like id_row, mapper_table_name, id_partition, id_fold, dataset, mapper_type.

        Keyword Args:
            id_row (str, optional): [Description of id_row argument].
            mapper_table_name (str, optional): [Description of mapper_table_name argument].
            id_partition (str, optional): [Description of id_partition argument].
            id_fold (str, optional): [Description of id_fold argument].
            dataset (str, optional): [Description of dataset argument].
            mapper_type (str, optional): The type of the mapper. Can take values among 'training', 'scoring', 'feature engineering', 'forecasting'.
        """
        # Update the corresponding attributes if the given keyword arguments are provided
        if 'id_row' in kwargs:
            self.id_row = kwargs['id_row']
            
        if 'mapper_table_name' in kwargs:
            self.mapper_table_name = kwargs['mapper_table_name']
                                            
        if 'id_partition' in kwargs:
            self.id_partition = kwargs['id_partition']
            
        if 'id_fold' in kwargs:
            self.id_partition = kwargs['id_fold']  # Check if this line should update id_partition or id_fold, should be clarified   
            
        if 'dataset' in kwargs:
            self.dataset = kwargs['dataset']  
            dataset = tdml.DataFrame(self.dataset)
            self.dataset_columns = list(dataset.columns)
            self.types = get_partition_datatype(dataset, columns=self.dataset_columns)
            
        if 'mapper_type' in kwargs:
            # Check if the provided mapper_type is valid
            valid_mapper_types = ['training', 'scoring', 'feature engineering', 'feature engineering reducer', 'forecasting']
            assert kwargs['mapper_type'] in valid_mapper_types, f"Invalid mapper_type. Should be one of {valid_mapper_types}"
            self.mapper_type = kwargs['mapper_type']                                              
        
    def update_repo(self,mapper_repository=None, schema_name=None, tdstone = None):

        if tdstone is not None:
            schema_name     = tdstone.schema_name
            mapper_repository = tdstone.mapper_repository
        self.schema_name      = schema_name
        self.mapper_repository = mapper_repository       
        

    
    def missing_fields(self):
                # check if there is not None in the important parameters
        if self.mapper_type in ['training','scoring']:
            fields = ['dataset','mapper_table_name','id_row','id_partition','id_fold']
        else:
            fields = ['dataset', 'mapper_table_name', 'id_row', 'id_partition']
        test  = True
        list_missing_fields = []
        
        if self.dataset is None:
            test = False
            list_missing_fields.append('dataset')
            
        if self.mapper_table_name is None:
            test = False
            list_missing_fields.append('mapper_table_name')
            
        if self.id_row is None:
            test = False
            list_missing_fields.append('id_row')
            
        if self.id_partition is None:
            test = False
            list_missing_fields.append('id_partition')

        if self.mapper_type in ['training', 'scoring'] and self.id_fold is None:
            test = False
            list_missing_fields.append('id_fold')     
            

        return test, list_missing_fields
        
        
    @execute_query
    def upload(self):
        """
        Uploads the model to the specified model repository.

        Returns:
            (query, path) where `query` is the SQL query and `path` is the path of the file.
        """        
        
        test, list_missing_fields = self.missing_fields()
    
        if test == False:
            logger.warning(
                "Mapper id=%s type=%s cannot be uploaded — missing fields: %s",
                self.id, self.mapper_type, list_missing_fields,
            )
            return

        
        queries = []
        
        # creation of the mapper table
        if self.mapper_type in ['training']:
            #types = get_partition_datatype(tdml.DataFrame(self.dataset),self.id_partition.split(','))
            sql_types = ', \n'.join([k+' '+v for k,v in self.types.items() if k in self.id_partition.split(',')])
            sql_names = ', \n'.join([k for k,v in self.types.items() if k in self.id_partition.split(',')])
            query_table_creation = f"""
                CREATE MULTISET TABLE {self.schema_name}.{self.mapper_table_name}{self._table_options()}
                (
                    ID_MODEL VARCHAR(36),
                    {sql_types},
                    STATUS VARCHAR(2000) CHARACTER SET UNICODE NOT CASESPECIFIC NOT NULL,
                    METADATA JSON(32000),{self._temporal_columns()}
                )
                PRIMARY INDEX ({self.id_partition});
            """

            queries.append(query_table_creation)

            if self.use_pti:
                query_trained_model_table_creation = f"""
                CREATE MULTISET TABLE {self.schema_name}.{self.trained_model_repository},
                FALLBACK,
                NO BEFORE JOURNAL,
                NO AFTER JOURNAL,
                CHECKSUM = DEFAULT,
                DEFAULT MERGEBLOCKRATIO,
                MAP = TD_MAP1
                (
                    --CREATION_DATE TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
                    TD_TIMEBUCKET BIGINT NOT NULL GENERATED SYSTEM TIMECOLUMN,
                    TD_TIMECODE TIMESTAMP(6) WITH TIME ZONE NOT NULL GENERATED TIMECOLUMN,
                    ID_PROCESS VARCHAR(255),
                    {sql_types},
                    ID_MODEL VARCHAR(36),
                    ID_TRAINED_MODEL VARCHAR(36),
                    MODEL_TYPE VARCHAR(255),
                    STATUS VARCHAR(2000) CHARACTER SET UNICODE NOT CASESPECIFIC NOT NULL,
                    TRAINED_MODEL CLOB,
                    MODEL_CHUNK_INDEX INTEGER DEFAULT 0,
                    MODEL_CHUNK_TOTAL INTEGER DEFAULT 1
                )
                PRIMARY TIME INDEX (TIMESTAMP(6) WITH TIME ZONE, DATE '2016-01-01', HOURS(1), columns({self.id_partition}))
                """
            else:
                # Lake-compatible DDL: no PTI, TD_TIMECODE as a regular column.
                # MODEL_CHUNK_INDEX / MODEL_CHUNK_TOTAL support trained models
                # whose base64-encoded pickle exceeds VARCHAR(64000), the per-row
                # cap on Apply RETURNS. Small models still write a single row
                # with INDEX=0, TOTAL=1.
                # TRAINED_MODEL must be VARCHAR(64000), NOT CLOB: a CLOB column
                # in the on-clause view makes Apply ineligible for the ACC
                # (Error 6881 / silent hang). Chunk size is capped at 60 000
                # chars in tds_training_apply.py so VARCHAR(64000) is sufficient.
                query_trained_model_table_creation = f"""
                CREATE MULTISET TABLE {self.schema_name}.{self.trained_model_repository}{self._table_options()}
                (
                    TD_TIMECODE TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
                    ID_PROCESS VARCHAR(255),
                    {sql_types},
                    ID_MODEL VARCHAR(36),
                    ID_TRAINED_MODEL VARCHAR(36),
                    MODEL_TYPE VARCHAR(255),
                    STATUS VARCHAR(2000) CHARACTER SET UNICODE NOT CASESPECIFIC NOT NULL,
                    TRAINED_MODEL VARCHAR(64000) CHARACTER SET LATIN,
                    MODEL_CHUNK_INDEX INTEGER DEFAULT 0,
                    MODEL_CHUNK_TOTAL INTEGER DEFAULT 1
                )
                PRIMARY INDEX ({self.id_partition})
                """

            # The pickle view surfaces every chunk row (one row per partition
            # per chunk index) so the scoring on-clause can interleave them.
            # Cast COALESCE expressions to keep MODEL_CHUNK_INDEX/TOTAL stable
            # for tables that pre-date the chunking columns.
            query_view_model_pickle = f"""
                REPLACE VIEW {self.schema_name}.V_{self.trained_model_repository}_PICKLE AS
                LOCK ROW FOR ACCESS
                SELECT
                    TD_TIMECODE,
                    ID_PROCESS,
                    {sql_names},
                    ID_MODEL,
                    ID_TRAINED_MODEL,
                    MODEL_TYPE,
                    STATUS,
                    TRAINED_MODEL,
                    COALESCE(MODEL_CHUNK_INDEX, 0) AS MODEL_CHUNK_INDEX,
                    COALESCE(MODEL_CHUNK_TOTAL, 1) AS MODEL_CHUNK_TOTAL
                FROM {self.schema_name}.{self.trained_model_repository}
                WHERE MODEL_TYPE = 'pickle'
            """

            query_view_model_onnx = f"""
                REPLACE VIEW {self.schema_name}.V_{self.trained_model_repository}_ONNX AS
                LOCK ROW FOR ACCESS
                SELECT 
                    TD_TIMECODE,
                    ID_PROCESS,
                    {sql_names},
                    ID_MODEL,
                    ID_TRAINED_MODEL,
                    MODEL_TYPE,
                    STATUS,
                    TO_BYTES(TRAINED_MODEL,'base16') AS TRAINED_MODEL
                FROM {self.schema_name}.{self.trained_model_repository}
                WHERE MODEL_TYPE = 'onnx'
            """

            query_view_byom_catalog = f"""
                    REPLACE VIEW {self.schema_name}.V_{self.trained_model_repository}_BYOM_CATALOG AS
                    SELECT
                        ID_TRAINED_MODEL AS model_id
                    ,   TRAINED_MODEL AS model
                    ,   {sql_names}
                    FROM {self.schema_name}.V_{self.trained_model_repository}_ONNX
                    QUALIFY row_number() OVER (PARTITION BY {sql_names} ORDER BY TD_TIMECODE DESC) = 1
            """

            queries.append(query_trained_model_table_creation)
            queries.append(query_view_model_pickle)
            queries.append(query_view_model_onnx)
            queries.append(query_view_byom_catalog)
            
        elif self.mapper_type in ['scoring']:
            #types = get_partition_datatype(tdml.DataFrame(self.dataset),self.id_partition.split(',')+self.id_row.split(','))
            sql_types = ', \n'.join([k+' '+v for k,v in self.types.items() if k in self.id_partition.split(',')+self.id_row.split(',')])
            
            query_table_creation = f"""
                CREATE MULTISET TABLE {self.schema_name}.{self.mapper_table_name}{self._table_options()}
                (
                    ID_TRAINED_MODEL VARCHAR(36),
                    {sql_types},
                    STATUS VARCHAR(2000) CHARACTER SET UNICODE NOT CASESPECIFIC NOT NULL,
                    METADATA JSON(32000),{self._temporal_columns()}
                )
                PRIMARY INDEX ({self.id_partition});
            """
            queries.append(query_table_creation)

            if self.use_pti:
                query_scored_model_table_creation = f"""
                CREATE MULTISET TABLE {self.schema_name}.{self.scores_repository},
                FALLBACK,
                NO BEFORE JOURNAL,
                NO AFTER JOURNAL,
                CHECKSUM = DEFAULT,
                DEFAULT MERGEBLOCKRATIO,
                MAP = TD_MAP1
                (
                    TD_TIMEBUCKET BIGINT NOT NULL GENERATED SYSTEM TIMECOLUMN,
                    TD_TIMECODE TIMESTAMP(6) WITH TIME ZONE NOT NULL GENERATED TIMECOLUMN,
                    ID_PROCESS VARCHAR(255),
                    {sql_types},
                    FEATURE_NAME     VARCHAR(20000),
                    FEATURE_VALUE    VARCHAR(2000),
                    FEATURE_TYPE     VARCHAR(20000),
                    STATUS VARCHAR(2000) CHARACTER SET UNICODE NOT CASESPECIFIC NOT NULL,
                    ID_TRAINED_MODEL VARCHAR(36),
                    SCRIPT_UUID      VARCHAR(36) CHARACTER SET LATIN,
                    TOTAL_TIME       FLOAT,
                    IMPORT_TIME      FLOAT,
                    LOAD_TIME        FLOAT,
                    PROCESS_TIME     FLOAT,
                    PRINT_TIME       FLOAT,
                    BATCH_NO         INTEGER
                )
                PRIMARY TIME INDEX (TIMESTAMP(6) WITH TIME ZONE, DATE '2016-01-01', HOURS(1), columns(ID_PROCESS, ID_TRAINED_MODEL, {self.id_partition}, {self.id_row}))
                """
            else:
                # Apply scoring stamps every output row with per-AMP timings
                # (SCRIPT_UUID + 5 phase-time floats) so a single SELECT
                # against the scores table tells us which phase dominated
                # wall-clock per partition. Script path leaves them NULL.
                query_scored_model_table_creation = f"""
                CREATE MULTISET TABLE {self.schema_name}.{self.scores_repository}{self._table_options()}
                (
                    TD_TIMECODE TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
                    ID_PROCESS VARCHAR(255),
                    {sql_types},
                    FEATURE_NAME     VARCHAR(20000),
                    FEATURE_VALUE    VARCHAR(2000),
                    FEATURE_TYPE     VARCHAR(20000),
                    STATUS VARCHAR(2000) CHARACTER SET UNICODE NOT CASESPECIFIC NOT NULL,
                    ID_TRAINED_MODEL VARCHAR(36),
                    SCRIPT_UUID      VARCHAR(36) CHARACTER SET LATIN,
                    TOTAL_TIME       FLOAT,
                    IMPORT_TIME      FLOAT,
                    LOAD_TIME        FLOAT,
                    PROCESS_TIME     FLOAT,
                    PRINT_TIME       FLOAT,
                    BATCH_NO         INTEGER
                )
                PRIMARY INDEX ({self.id_partition})
                """

            queries.append(query_scored_model_table_creation)

            # OFS tables don't support secondary indexes (Error 4839).
            if not self.use_apply:
                query_secondary_index = f'CREATE INDEX ({self.id_row}) ON {self.schema_name}.{self.scores_repository}'
                queries.append(query_secondary_index)

        elif self.mapper_type in ['feature engineering reducer']:
            # types = get_partition_datatype(tdml.DataFrame(self.dataset),self.id_partition.split(','))
            sql_types = ', \n'.join([k + ' ' + v for k, v in self.types.items() if k in self.id_partition.split(',')])

            query_table_creation = f"""
                CREATE MULTISET TABLE {self.schema_name}.{self.mapper_table_name}{self._table_options()}
                (
                    ID_MODEL VARCHAR(36),
                    {sql_types},
                    STATUS VARCHAR(2000) CHARACTER SET UNICODE NOT CASESPECIFIC NOT NULL,
                    METADATA JSON(32000),{self._temporal_columns()}
                )
                PRIMARY INDEX (ID_MODEL, {self.id_partition});
            """

            queries.append(query_table_creation)

            if self.use_pti:
                query_trained_model_table_creation = f"""
                CREATE MULTISET TABLE {self.schema_name}.{self.reduced_feature_repository},
                FALLBACK,
                NO BEFORE JOURNAL,
                NO AFTER JOURNAL,
                CHECKSUM = DEFAULT,
                DEFAULT MERGEBLOCKRATIO,
                MAP = TD_MAP1
                (
                    TD_TIMEBUCKET BIGINT NOT NULL GENERATED SYSTEM TIMECOLUMN,
                    TD_TIMECODE TIMESTAMP(6) WITH TIME ZONE NOT NULL GENERATED TIMECOLUMN,
                    ID_PROCESS VARCHAR(255),
                    {sql_types},
                    FEATURE_ROW      BIGINT,
                    FEATURE_NAME     VARCHAR(20000),
                    FEATURE_VALUE    VARCHAR(2000),
                    FEATURE_TYPE     VARCHAR(20000),
                    STATUS VARCHAR(2000) CHARACTER SET UNICODE NOT CASESPECIFIC NOT NULL,
                    ID_MODEL VARCHAR(36)
                )
                PRIMARY TIME INDEX (TIMESTAMP(6) WITH TIME ZONE, DATE '2016-01-01', HOURS(1), columns(ID_PROCESS, ID_MODEL,{self.id_partition}))
                """
            else:
                query_trained_model_table_creation = f"""
                CREATE MULTISET TABLE {self.schema_name}.{self.reduced_feature_repository}{self._table_options()}
                (
                    TD_TIMECODE TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
                    ID_PROCESS VARCHAR(255),
                    {sql_types},
                    FEATURE_ROW      BIGINT,
                    FEATURE_NAME     VARCHAR(20000),
                    FEATURE_VALUE    VARCHAR(2000),
                    FEATURE_TYPE     VARCHAR(20000),
                    STATUS VARCHAR(2000) CHARACTER SET UNICODE NOT CASESPECIFIC NOT NULL,
                    ID_MODEL VARCHAR(36)
                )
                PRIMARY INDEX ({self.id_partition})
                """

            queries.append(query_trained_model_table_creation)

        elif self.mapper_type in ['feature engineering']:
            # types = get_partition_datatype(tdml.DataFrame(self.dataset),self.id_partition.split(','))
            sql_types = ', \n'.join([k + ' ' + v for k, v in self.types.items() if k in self.id_partition.split(',')])
            sql_types_row = ', \n'.join([k + ' ' + v for k, v in self.types.items() if k in self.id_row.split(',')])

            query_table_creation = f"""
                CREATE MULTISET TABLE {self.schema_name}.{self.mapper_table_name}{self._table_options()}
                (
                    ID_MODEL VARCHAR(36),
                    {sql_types},
                    STATUS VARCHAR(2000) CHARACTER SET UNICODE NOT CASESPECIFIC NOT NULL,
                    METADATA JSON(32000),{self._temporal_columns()}
                )
                PRIMARY INDEX (ID_MODEL, {self.id_partition});
            """

            queries.append(query_table_creation)

            if self.use_pti:
                query_trained_model_table_creation = f"""
                CREATE MULTISET TABLE {self.schema_name}.{self.features_repository},
                FALLBACK,
                NO BEFORE JOURNAL,
                NO AFTER JOURNAL,
                CHECKSUM = DEFAULT,
                DEFAULT MERGEBLOCKRATIO,
                MAP = TD_MAP1
                (
                    TD_TIMEBUCKET BIGINT NOT NULL GENERATED SYSTEM TIMECOLUMN,
                    TD_TIMECODE TIMESTAMP(6) WITH TIME ZONE NOT NULL GENERATED TIMECOLUMN,
                    ID_PROCESS VARCHAR(255),
                    {sql_types},
                    {sql_types_row},
                    FEATURE_NAME     VARCHAR(20000),
                    FEATURE_VALUE    VARCHAR(2000),
                    FEATURE_TYPE     VARCHAR(20000),
                    STATUS VARCHAR(2000) CHARACTER SET UNICODE NOT CASESPECIFIC NOT NULL,
                    ID_MODEL VARCHAR(36)
                )
                PRIMARY TIME INDEX (TIMESTAMP(6) WITH TIME ZONE, DATE '2016-01-01', HOURS(1), columns(ID_PROCESS, ID_MODEL, {self.id_row}))
                """
            else:
                query_trained_model_table_creation = f"""
                CREATE MULTISET TABLE {self.schema_name}.{self.features_repository}{self._table_options()}
                (
                    TD_TIMECODE TIMESTAMP(6) WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
                    ID_PROCESS VARCHAR(255),
                    {sql_types},
                    {sql_types_row},
                    FEATURE_NAME     VARCHAR(20000),
                    FEATURE_VALUE    VARCHAR(2000),
                    FEATURE_TYPE     VARCHAR(20000),
                    STATUS VARCHAR(2000) CHARACTER SET UNICODE NOT CASESPECIFIC NOT NULL,
                    ID_MODEL VARCHAR(36)
                )
                PRIMARY INDEX ({self.id_partition})
                """

            queries.append(query_trained_model_table_creation)

            if not self.use_apply:
                query_secondary_index = f'CREATE INDEX ({self.id_partition}) ON {self.schema_name}.{self.reduced_feature_repository}'
                queries.append(query_secondary_index)

        # here insert or update in the catalog
        if self.isnewmapper:
            if self.mapper_type in ['training']:
                # this is a new insert
                query = f"""{self._vt()}INSERT INTO {self.schema_name}.{self.mapper_repository}
                (ID, MAPPER_TYPE, TABLE_NAME, CODE_REPOSITORY, MODEL_REPOSITORY,TRAINED_MODEL_REPOSITORY, DATASET_OBJECT,COL_ID_ROW,COL_ID_PARTITION,COL_FOLD,ON_CLAUSE_VIEW, STO_VIEW,METADATA)
                 VALUES
                ('{self.id}',
                 '{self.mapper_type}',
                 '{self.mapper_table_name}',
                 '{self.code_repository}',
                 '{self.model_repository}',
                 '{self.trained_model_repository}',
                 '{self.dataset}',
                 '{self.id_row}',
                 '{self.id_partition}',
                 '{self.id_fold}',
                 '{self.on_clause_view_name}',
                 '{self.sto_view_name}',
                 '{json.dumps(self.metadata).replace("'", '"')}');
                """
            elif  self.mapper_type in ['scoring']:
                # this is a new insert
                query = f"""{self._vt()}INSERT INTO {self.schema_name}.{self.mapper_repository}
                (ID, MAPPER_TYPE, TABLE_NAME, CODE_REPOSITORY, MODEL_REPOSITORY,TRAINED_MODEL_REPOSITORY, SCORES_REPOSITORY, DATASET_OBJECT,COL_ID_ROW,COL_ID_PARTITION,COL_FOLD,ON_CLAUSE_VIEW, STO_VIEW,METADATA)
                 VALUES
                ('{self.id}',
                 '{self.mapper_type}',
                 '{self.mapper_table_name}',
                 '{self.code_repository}',
                 '{self.model_repository}',
                 '{self.trained_model_repository}',
                 '{self.scores_repository}',
                 '{self.dataset}',
                 '{self.id_row}',
                 '{self.id_partition}',
                 '{self.id_fold}',
                 '{self.on_clause_view_name}',
                 '{self.sto_view_name}',
                 '{json.dumps(self.metadata).replace("'", '"')}');
                """
            elif self.mapper_type in ['feature engineering','feature engineering reducer']:
                # this is a new insert
                if self.mapper_type == 'feature engineering':
                    feature_repo_name = self.features_repository
                else:
                    feature_repo_name = self.reduced_feature_repository

                query = f"""{self._vt()}INSERT INTO {self.schema_name}.{self.mapper_repository}
                (ID, MAPPER_TYPE, TABLE_NAME, CODE_REPOSITORY, MODEL_REPOSITORY,FEATURE_REPOSITORY, DATASET_OBJECT,COL_ID_ROW,COL_ID_PARTITION,ON_CLAUSE_VIEW, STO_VIEW,METADATA)
                 VALUES
                ('{self.id}',
                 '{self.mapper_type}',
                 '{self.mapper_table_name}',
                 '{self.code_repository}',
                 '{self.model_repository}',
                 '{feature_repo_name}',
                 '{self.dataset}',
                 '{self.id_row}',
                 '{self.id_partition}',
                 '{self.on_clause_view_name}',
                 '{self.sto_view_name}',
                 '{json.dumps(self.metadata).replace("'", '"')}');
                """
            self.isnewmapper = False
            
        else:
            if self.mapper_type in ['training','forecast']:
                query = f"""
                {self._vt()}UPDATE {self.schema_name}.{self.mapper_repository}
                SET 
                    TABLE_NAME = '{self.mapper_table_name}'
                ,   MAPPER_TYPE = '{self.mapper_type}'
                ,   CODE_REPOSITORY = '{self.code_repository}'
                ,   MODEL_REPOSITORY = '{self.model_repository}'
                ,   TRAINED_MODEL_REPOSITORY = '{self.trained_model_repository}'
                ,   SCORES_REPOSITORY = '{self.scores_repository}'
                ,   DATASET_OBJECT = '{self.dataset}'
                ,   COL_ID_ROW = '{self.id_row}'
                ,   COL_ID_PARTITION = '{self.id_partition}'
                ,   COL_FOLD = '{self.id_fold}'
                ,   ON_CLAUSE_VIEW = '{self.on_clause_view_name}'
                ,   STO_VIEW = '{self.sto_view_name}'
                ,   METADATA = '{json.dumps(self.metadata).replace("'", '"')}'
                WHERE ID = '{self.id}';
                """
            elif self.mapper_type in ['feature engineering','feature engineering reducer']:
                if self.mapper_type == 'feature engineering':
                    feature_repo_name = self.features_repository
                else:
                    feature_repo_name = self.reduced_feature_repository

                query = f"""
                {self._vt()}UPDATE {self.schema_name}.{self.mapper_repository}
                SET 
                    TABLE_NAME = '{self.mapper_table_name}'
                ,   MAPPER_TYPE = '{self.mapper_type}'
                ,   CODE_REPOSITORY = '{self.code_repository}'
                ,   MODEL_REPOSITORY = '{self.model_repository}'
                ,   FEATURE_REPOSITORY = '{feature_repo_name}'
                ,   SCORES_REPOSITORY = '{self.scores_repository}'
                ,   DATASET_OBJECT = '{self.dataset}'
                ,   COL_ID_ROW = '{self.id_row}'
                ,   COL_ID_PARTITION = '{self.id_partition}'
                ,   ON_CLAUSE_VIEW = '{self.on_clause_view_name}'
                ,   STO_VIEW = '{self.sto_view_name}'
                ,   METADATA = '{json.dumps(self.metadata).replace("'", '"')}'
                WHERE ID = '{self.id}';
                """
        queries.append(query)
        logger.info(
            "Uploading mapper id=%s type=%s table=%s.%s",
            self.id, self.mapper_type, self.schema_name, self.mapper_table_name,
        )
        return queries
    
    @execute_query
    def remove(self):

        
        return []
               
    def download(self, id, mapper_repository=None, schema_name=None, tdstone = None, mapper_type = None):
        
        if tdstone is not None:
            self.schema_name       = tdstone.schema_name
            self.mapper_repository = tdstone.mapper_repository
            self.SEARCHUIFDBPATH   = tdstone.SEARCHUIFDBPATH
        if mapper_repository is not None and schema_name is not None:
            self.schema_name       = schema_name
            self.mapper_repository = mapper_repository
            
        self.mapper_type = mapper_type
        
        query = f"""
        {self._vt()}
        SELECT
             ID
        ,    MAPPER_TYPE
        ,    TABLE_NAME
        ,    CODE_REPOSITORY
        ,    MODEL_REPOSITORY
        ,    TRAINED_MODEL_REPOSITORY
        ,    FEATURE_REPOSITORY
        ,    SCORES_REPOSITORY
        ,    DATASET_OBJECT
        ,    COL_ID_ROW 
        ,    COL_ID_PARTITION
        ,    COL_FOLD
        ,    ON_CLAUSE_VIEW
        ,    STO_VIEW
        ,    METADATA 
        FROM {self.schema_name}.{self.mapper_repository}
        WHERE ID = '{id}'
        """
        
        # to_pandas() promotes the Teradata primary index (ID) to the pandas
        # index, so ``df.ID`` later returns AttributeError. reset_index puts
        # ID back as a regular column.
        df = tdml.DataFrame.from_query(query).to_pandas().reset_index()
        
        if df.shape[0] != 1:
            logger.error(
                "Mapper download id=%s expected 1 row, found %d in %s.%s",
                id, df.shape[0], self.schema_name, self.mapper_repository,
            )
        else:
            self.code_repository  = df.CODE_REPOSITORY.values[0]
            self.model_repository  = df.MODEL_REPOSITORY.values[0]
            self.trained_model_repository  = df.TRAINED_MODEL_REPOSITORY.values[0]
            self.scores_repository = df.SCORES_REPOSITORY.values[0]

            self.dataset           = df.DATASET_OBJECT.values[0]
            self.mapper_type       = df.MAPPER_TYPE.values[0]
            self.mapper_table_name = df.TABLE_NAME.values[0]
            if self.mapper_type == 'feature engineering':
                self.features_repository = df.FEATURE_REPOSITORY.values[0]
            elif self.mapper_type == 'feature engineering reducer':
                self.reduced_feature_repository = df.FEATURE_REPOSITORY.values[0]

            # Determine if this is a new mapper or an existing one based on the provided id
            self.isnewmapper       = False
            self.id                = df.ID.values[0]
            self.metadata          = eval(df.METADATA.values[0])
            self.on_clause_view_name = df.ON_CLAUSE_VIEW.values[0]
            self.sto_view_name       = df.STO_VIEW.values[0]
            
            self.id_row              = df.COL_ID_ROW.values[0]
            self.id_partition        = df.COL_ID_PARTITION.values[0]
            self.id_fold             = df.COL_FOLD.values[0]

            dataset = tdml.DataFrame(self.dataset)
            self.dataset_columns = list(dataset.columns)
            self.types = get_partition_datatype(dataset, columns=self.dataset_columns)
 
    def list_mapping(self,current_only=True, active_only = True):
        """
        List the mapping in the TDStone system.

        Args:
            with_full_script (bool, optional): If True, the full script is listed. Defaults to False.
            current_only (bool, optional): If True, only the current version is listed. Defaults to True.

        Returns:
            DataFrame: A DataFrame with the model details.
        """        
        if current_only:
            query = self._vt() + "\n"
        else:
            query = ''
            
        query = query + 'SELECT  * \n'
                
        query = query + f'\n FROM {self.schema_name}.{self.mapper_table_name}'
        
        if active_only:
            query = query + "\n WHERE STATUS = 'enabled'"
            
        
        return tdml.DataFrame.from_query(query)

    @execute_query
    def reset_mapping(self):
        query = f'DELETE {self.schema_name}.{self.mapper_table_name}'
        return query
    
    @execute_query
    def fill_mapping_full(self, model_id):
        
        if self.mapper_type in ['training','feature engineering','forecasting','feature engineering reducer']:
            sub_query = f"""
            SELECT
                A.ID
            ,   {','.join(['B.'+x for x in self.id_partition.split(',')])}
            ,   'enabled' AS STATUS
            FROM ({self._vt()}SELECT * FROM {self.schema_name}.{self.model_repository}) A
            , (
               SELECT DISTINCT {self.id_partition}
               FROM {self.dataset}
            ) B
            WHERE A.ID = '{model_id}'        
            """


            query = f"""
            {self._vt()}
            INSERT INTO {self.schema_name}.{self.mapper_table_name}
            (ID_MODEL, {self.id_partition}, STATUS)
            SELECT
                AAA.ID
            ,   {','.join(['AAA.'+x for x in self.id_partition.split(',')])}
            ,   AAA.STATUS
            FROM (
                SELECT 
                    AA.*
                ,   BB.ID_MODEL AS EXISTING_ID
                FROM ({sub_query}) AA
                LEFT JOIN {self.schema_name}.{self.mapper_table_name} BB
                ON 
                -- AA.ID = BB.ID_MODEL AND
                {'AND '.join(['AA.'+x+'=BB.'+x for x in self.id_partition.split(',')])}
                WHERE EXISTING_ID IS NULL
            ) AAA
            """
            return query
        elif self.mapper_type in ['scoring']:
            join_clause = 'AND '.join(['B.'+x+'=CC.'+x for x in self.id_partition.split(',')])
            
            sub_query = f"""
            SELECT
                A.ID
            ,   {','.join(['B.'+x for x in self.id_partition.split(',')])}
            ,   'enabled' AS STATUS
            ,   CC.ID_TRAINED_MODEL
            FROM ({self._vt()}SELECT * FROM {self.schema_name}.{self.model_repository}) A
            , (
               SELECT DISTINCT {self.id_partition}
               FROM {self.dataset}
            ) B
            , (
                SEL {self.id_partition}, ID_MODEL, ID_TRAINED_MODEL, TRAINED_MODEL, MODEL_TYPE
                FROM {self.schema_name}.{self.trained_model_repository}
                QUALIFY ROW_NUMBER() OVER (PARTITION BY {self.id_partition}, ID_MODEL ORDER BY TD_TIMECODE DESC) = 1
               ) CC
            WHERE A.ID = '{model_id}' AND A.ID = CC.ID_MODEL    
            AND {join_clause}
            """

            query = f"""
            {self._vt()}
            INSERT INTO {self.schema_name}.{self.mapper_table_name}
            (ID_TRAINED_MODEL, {self.id_partition}, STATUS)
            SELECT
                AAA.ID_TRAINED_MODEL
            ,   {','.join(['AAA.'+x for x in self.id_partition.split(',')])}
            ,   AAA.STATUS
            FROM (
                SELECT 
                    AA.*
                ,   BB.ID_TRAINED_MODEL AS EXISTING_ID
                FROM ({sub_query}) AA
                LEFT JOIN {self.schema_name}.{self.mapper_table_name} BB
                ON 
                -- AA.ID = BB.ID_TRAINED_MODEL AND
                {'AND '.join(['AA.'+x+'=BB.'+x for x in self.id_partition.split(',')])}
                WHERE EXISTING_ID IS NULL
            ) AAA
            """

            query_update = f"""
            {self._vt()}
            UPDATE {self.schema_name}.{self.mapper_table_name}
            FROM (
                SELECT
                    AAA.ID_TRAINED_MODEL
                ,   {','.join(['AAA.'+x for x in self.id_partition.split(',')])}
                ,   AAA.STATUS
                FROM (
                    SELECT 
                        AA.*
                    ,   BB.ID_TRAINED_MODEL AS EXISTING_ID
                    FROM ({sub_query}) AA
                    LEFT JOIN {self.schema_name}.{self.mapper_table_name} BB
                    ON 
                    -- AA.ID = BB.ID_TRAINED_MODEL AND
                    {'AND '.join(['AA.'+x+'=BB.'+x for x in self.id_partition.split(',')])}
                    WHERE EXISTING_ID IS NOT NULL
                ) AAA            
            ) UPDATED_MAPPING
            SET
                ID_TRAINED_MODEL = UPDATED_MAPPING.ID_TRAINED_MODEL
            WHERE
                {'AND '.join([self.schema_name+'.'+self.mapper_table_name+'.'+x+'=UPDATED_MAPPING.'+x for x in self.id_partition.split(',')])}
            """
            return [query, query_update]
        
    @execute_query
    def enable_exiting_partitions(self, model_id, new_status='enabled'):
        
        sub_query = f"""
        SELECT
            A.ID
        ,   {','.join(['B.'+x for x in self.id_partition.split(',')])}
        ,   'enabled' AS STATUS
        FROM ({self._vt()}SELECT * FROM {self.schema_name}.{self.model_repository}) A
        , (
           SELECT DISTINCT {self.id_partition}
           FROM {self.dataset}
        ) B
        WHERE A.ID = '{model_id}'        
        """
        
        query_update = f"""
        {self._vt()}
        UPDATE {self.schema_name}.{self.mapper_table_name}
        FROM (
            SELECT
                AAA.ID
            ,   {','.join(['AAA.'+x for x in self.id_partition.split(',')])}
            FROM (
                SELECT 
                    AA.*
                ,   BB.ID_MODEL AS EXISTING_ID
                FROM ({sub_query}) AA
                LEFT JOIN ({self._vt()}SELECT * FROM {self.schema_name}.{self.mapper_table_name}) BB
                ON AA.ID = BB.ID_MODEL AND
                {'AND '.join(['AA.'+x+'=BB.'+x for x in self.id_partition.split(',')])}
                WHERE EXISTING_ID IS NOT NULL
            ) AAA        
        ) UPDATED_MAPPING
        SET
            STATUS = '{new_status}'
        WHERE
            ID_MODEL = UPDATED_MAPPING.ID AND
           {'AND '.join([f'{self.schema_name}.{self.mapper_table_name}.'+x+'=UPDATED_MAPPING.'+x for x in self.id_partition.split(',')])}
        """

        return query_update
    
    @execute_query
    def create_on_clause(self,fold=None):
        
        #self.on_clause_view_name = 'TDS_ON_CLAUSE_'self.ma+self.id.replace('-','_')
        
        #dataset = tdml.DataFrame(self.dataset)
        dataset_col_sql = ', \n'.join(['A.'+x for x in self.dataset_columns])
        
        
        
        if self.mapper_type in ['training','forecasting']:
            # view on clause
            query = f"""
                REPLACE VIEW {self.schema_name}.{self.on_clause_view_name} AS
                WITH LEFT_MAPPED_TABLE AS (
                    SEL 
                        A.*
                    ,	ROW_NUMBER() OVER (PARTITION BY 
                                            {','.join(['A.'+x for x in self.id_partition.split(',')] +
                                            ['MAPPER.ID_MODEL'] + 
                                            ['A.'+x for x in self.id_fold.split(',')])} 
                                            ORDER BY {','.join(['A.'+x for x in self.id_row.split(',')])}) AS STO_FAKE_ROW
                    ,	MAPPER.ID_MODEL AS STO_MODEL_ID
                    FROM {self.dataset} A
                    ,	({self._vt()}SEL * FROM {self.schema_name}.{self.mapper_table_name}) MAPPER
                    WHERE {'AND '.join(['A.'+x+'=MAPPER.'+x for x in self.id_partition.split(',')])}
                    AND MAPPER.STATUS = 'enabled'
                )
                SEL
                    LEFT_MAPPED_TABLE.*
                ,   CASE WHEN LEFT_MAPPED_TABLE.STO_FAKE_ROW = 1 THEN '{self.id_row}' END AS STO_ROW_ID
                ,   CASE WHEN LEFT_MAPPED_TABLE.STO_FAKE_ROW = 1 THEN '{self.id_partition}' END AS STO_PARTITION_ID
                ,   CASE WHEN LEFT_MAPPED_TABLE.STO_FAKE_ROW = 1 THEN '{self.id_fold}' END AS STO_FOLD_ID
                ,	CASE WHEN LEFT_MAPPED_TABLE.STO_FAKE_ROW = 1 THEN CURRENT_MODELS.CODE_TYPE END AS STO_CODE_TYPE
                ,	CASE WHEN LEFT_MAPPED_TABLE.STO_FAKE_ROW = 1 THEN TRANSLATE(FROM_BYTES(CURRENT_MODELS.CODE, 'base64m') USING UNICODE_TO_LATIN) END AS STO_CODE
                ,	CASE WHEN LEFT_MAPPED_TABLE.STO_FAKE_ROW = 1 THEN REGEXP_REPLACE(REGEXP_REPLACE(CAST(CURRENT_MODELS.ARGUMENTS AS VARCHAR(32000)),'([\r|\t])', ''),'[\s+]', ' ') END AS ARGUMENTS
                ,   CASE WHEN LEFT_MAPPED_TABLE.STO_FAKE_ROW = 1 THEN CAST(CURRENT_TIME AS TIMESTAMP(6) WITH TIME ZONE) END AS EXECUTION_TIME
                FROM
                    LEFT_MAPPED_TABLE
                LEFT JOIN (
                    SELECT
                      AA.ID
                    , AA.ID_CODE
                    , AA.ARGUMENTS
                    , BB.CODE_TYPE
                    , BB.CODE
                    FROM ({self._vt()}SELECT * FROM {self.schema_name}.{self.model_repository}) AA
                    INNER JOIN ({self._vt()}SELECT * FROM {self.schema_name}.{self.code_repository}) BB
                    ON AA.ID_CODE = BB.ID
                    WHERE BB.CODE_TYPE = 'python class'
                ) CURRENT_MODELS
                ON LEFT_MAPPED_TABLE.STO_MODEL_ID = CURRENT_MODELS.ID   
            """
            
            if fold is not None:
                query = query + f"\n WHERE LEFT_MAPPED_TABLE.{self.id_fold} = '{fold}'"

        elif self.mapper_type in ['feature engineering', 'feature engineering reducer']:
            # view on clause
            query = f"""
                REPLACE VIEW {self.schema_name}.{self.on_clause_view_name} AS
                WITH LEFT_MAPPED_TABLE AS (
                    SEL 
                        A.*
                    ,	ROW_NUMBER() OVER (PARTITION BY 
                                            {','.join(['A.' + x for x in self.id_partition.split(',')] +
                                                      ['MAPPER.ID_MODEL'])} 
                                            ORDER BY {','.join(['A.' + x for x in self.id_row.split(',')])}) AS STO_FAKE_ROW
                    ,	MAPPER.ID_MODEL AS STO_MODEL_ID
                    FROM {self.dataset} A
                    ,	({self._vt()}SEL * FROM {self.schema_name}.{self.mapper_table_name}) MAPPER
                    WHERE {'AND '.join(['A.' + x + '=MAPPER.' + x for x in self.id_partition.split(',')])}
                    AND MAPPER.STATUS = 'enabled'
                )
                SEL
                    LEFT_MAPPED_TABLE.*
                ,   CASE WHEN LEFT_MAPPED_TABLE.STO_FAKE_ROW = 1 THEN '{self.id_row}' END AS STO_ROW_ID
                ,   CASE WHEN LEFT_MAPPED_TABLE.STO_FAKE_ROW = 1 THEN '{self.id_partition}' END AS STO_PARTITION_ID
                 ,	CASE WHEN LEFT_MAPPED_TABLE.STO_FAKE_ROW = 1 THEN CURRENT_MODELS.CODE_TYPE END AS STO_CODE_TYPE
                ,	CASE WHEN LEFT_MAPPED_TABLE.STO_FAKE_ROW = 1 THEN TRANSLATE(FROM_BYTES(CURRENT_MODELS.CODE, 'base64m') USING UNICODE_TO_LATIN) END AS STO_CODE
                ,	CASE WHEN LEFT_MAPPED_TABLE.STO_FAKE_ROW = 1 THEN REGEXP_REPLACE(REGEXP_REPLACE(CAST(CURRENT_MODELS.ARGUMENTS AS VARCHAR(32000)),'([\r|\t])', ''),'[\s+]', ' ') END AS ARGUMENTS
                ,   CASE WHEN LEFT_MAPPED_TABLE.STO_FAKE_ROW = 1 THEN CAST(CURRENT_TIME AS TIMESTAMP(6) WITH TIME ZONE) END AS EXECUTION_TIME
                FROM
                    LEFT_MAPPED_TABLE
                LEFT JOIN (
                    SELECT
                      AA.ID
                    , AA.ID_CODE
                    , AA.ARGUMENTS
                    , BB.CODE_TYPE
                    , BB.CODE
                    FROM ({self._vt()}SELECT * FROM {self.schema_name}.{self.model_repository}) AA
                    INNER JOIN ({self._vt()}SELECT * FROM {self.schema_name}.{self.code_repository}) BB
                    ON AA.ID_CODE = BB.ID
                    WHERE BB.CODE_TYPE = 'python class'
                ) CURRENT_MODELS
                ON LEFT_MAPPED_TABLE.STO_MODEL_ID = CURRENT_MODELS.ID   
            """


        elif self.mapper_type in ['scoring']:
            # view on clause
            # Chunked-model strategy: V_<repo>_PICKLE has one row per chunk
            # (CHUNK_INDEX = 0..N-1 of the latest trained model per partition).
            # We attach chunk_i to data row i+1 inside each partition via
            # STO_FAKE_ROW - 1 = CHUNK_INDEX. The scoring script reads first N
            # rows to reassemble the model, then scores remaining rows.
            partition_cols = [c.strip() for c in self.id_partition.split(',') if c.strip()]
            row_cols       = [c.strip() for c in self.id_row.split(',') if c.strip()]
            fold_cols      = [c.strip() for c in self.id_fold.split(',') if c.strip()]
            data_cols      = [c for c in (self.dataset_columns or []) if c]
            hash_buckets   = int(getattr(self, 'apply_scoring_hash_buckets', 8))
            base_sql = f"""
                WITH LEFT_MAPPED_TABLE AS (
                    SEL
                        A.*
                    ,	ROW_NUMBER() OVER (PARTITION BY
                                        {','.join(['A.'+x for x in partition_cols] +
                                        ['MAPPER.ID_TRAINED_MODEL'])}
                                        ORDER BY {','.join(['A.'+x for x in row_cols])}) AS STO_FAKE_ROW
                    ,	MAPPER.ID_TRAINED_MODEL AS STO_MODEL_ID
                    FROM {self.dataset} A
                    ,	({self._vt()}SEL * FROM {self.schema_name}.{self.mapper_table_name}) MAPPER
                    WHERE {'AND '.join(['A.'+x+'=MAPPER.'+x for x in partition_cols])}
                    AND MAPPER.STATUS = 'enabled'
                ),
                BASE AS (
                SEL
                    LEFT_MAPPED_TABLE.*
                ,   CASE WHEN LEFT_MAPPED_TABLE.STO_FAKE_ROW = 1 THEN '{self.id_row}' END AS STO_ROW_ID
                ,   CASE WHEN LEFT_MAPPED_TABLE.STO_FAKE_ROW = 1 THEN '{self.id_partition}' END AS STO_PARTITION_ID
                ,   CASE WHEN LEFT_MAPPED_TABLE.STO_FAKE_ROW = 1 THEN '{self.id_fold}' END AS STO_FOLD_ID
                ,	CASE WHEN LEFT_MAPPED_TABLE.STO_FAKE_ROW = 1 THEN CURRENT_MODELS.CODE_TYPE END AS STO_CODE_TYPE
                ,	CASE WHEN LEFT_MAPPED_TABLE.STO_FAKE_ROW = 1 THEN TRANSLATE(FROM_BYTES(CURRENT_MODELS.CODE, 'base64m') USING UNICODE_TO_LATIN) END AS STO_CODE
                ,	CASE WHEN LEFT_MAPPED_TABLE.STO_FAKE_ROW = 1 THEN REGEXP_REPLACE(REGEXP_REPLACE(CAST(CURRENT_MODELS.ARGUMENTS AS VARCHAR(32000)),'([\r|\t])', ''),'[\s+]', ' ') END AS ARGUMENTS
                ,	CASE WHEN LEFT_MAPPED_TABLE.STO_FAKE_ROW = 1 THEN CURRENT_MODELS.ID_TRAINED_MODEL END AS STO_ID_TRAINED_MODEL
                ,	CASE WHEN LEFT_MAPPED_TABLE.STO_FAKE_ROW = 1 THEN CURRENT_MODELS.MODEL_TYPE END AS STO_MODEL_TYPE
                ,	MODEL_CHUNKS.TRAINED_MODEL AS STO_TRAINED_MODEL
                ,   MODEL_CHUNKS.MODEL_CHUNK_INDEX AS STO_MODEL_CHUNK_INDEX
                ,   MODEL_CHUNKS.MODEL_CHUNK_TOTAL AS STO_MODEL_CHUNK_TOTAL
                ,   CASE WHEN LEFT_MAPPED_TABLE.STO_FAKE_ROW = 1 THEN CAST(CURRENT_TIME AS TIMESTAMP(6) WITH TIME ZONE) END AS EXECUTION_TIME
                ,   LEFT_MAPPED_TABLE.{partition_cols[0]} MOD {hash_buckets} AS HASH_BUCKET
                FROM
                    LEFT_MAPPED_TABLE
                LEFT JOIN (
                    SELECT
                      AA.ID
                    , AA.ID_CODE
                    , AA.ARGUMENTS
                    , BB.CODE_TYPE
                    , BB.CODE
                    , {','.join(['CC.'+x for x in partition_cols])}
                    , CC.ID_TRAINED_MODEL
                    , CC.MODEL_TYPE
                    FROM ({self._vt()}SELECT * FROM {self.schema_name}.{self.model_repository}) AA
                    INNER JOIN ({self._vt()}SELECT * FROM {self.schema_name}.{self.code_repository}) BB
                    ON AA.ID_CODE = BB.ID
                    INNER JOIN (
                        SELECT *
                        FROM {self.schema_name}.V_{self.trained_model_repository}_PICKLE
                        QUALIFY ROW_NUMBER() OVER (PARTITION BY {self.id_partition}, ID_MODEL ORDER BY TD_TIMECODE DESC, MODEL_CHUNK_INDEX) = 1
                    ) CC
                    ON AA.ID = CC.ID_MODEL
                    WHERE BB.CODE_TYPE = 'python class'
                ) CURRENT_MODELS
                ON LEFT_MAPPED_TABLE.STO_MODEL_ID = CURRENT_MODELS.ID_TRAINED_MODEL
                LEFT JOIN (
                    SELECT
                        ID_TRAINED_MODEL
                    ,   {','.join(partition_cols)}
                    ,   TRAINED_MODEL
                    ,   MODEL_CHUNK_INDEX
                    ,   MODEL_CHUNK_TOTAL
                    ,   MODEL_CHUNK_INDEX + 1 AS EXPECTED_SFR
                    FROM {self.schema_name}.V_{self.trained_model_repository}_PICKLE
                    QUALIFY ROW_NUMBER() OVER (PARTITION BY {self.id_partition}, ID_MODEL, MODEL_CHUNK_INDEX ORDER BY TD_TIMECODE DESC) = 1
                ) MODEL_CHUNKS
                ON LEFT_MAPPED_TABLE.STO_MODEL_ID = MODEL_CHUNKS.ID_TRAINED_MODEL
                AND LEFT_MAPPED_TABLE.STO_FAKE_ROW = MODEL_CHUNKS.EXPECTED_SFR
                )
            """

            query = f"""
                REPLACE VIEW {self.schema_name}.{self.on_clause_view_name} AS
                {base_sql}
                SEL * FROM BASE
                """
            if fold is not None:
                # Fold filter applies inside LEFT_MAPPED_TABLE — append at end.
                query = query + f"\n -- fold filter: {fold}"
                
        logger.info(
            "Creating ON-clause view %s.%s (mapper=%s type=%s%s)",
            self.schema_name, self.on_clause_view_name, self.id, self.mapper_type,
            f" fold={fold}" if fold is not None else "",
        )
        return query

    def _use_apply(self):
        """True when this mapper should emit Apply (VCL) SQL instead of Script SQL."""
        return bool(getattr(self, 'use_apply', False))

    def generate_sto_query(self):
        """Return the inner SQL fragment used by create_sto_view() and execute_mapper().

        Dispatches between the legacy Script (STO) emitter and the Apply (VCL/OpenAF)
        emitter so that downstream callers (REPLACE VIEW ..., INSERT INTO ... SELECT ...)
        remain agnostic of the execution backend.
        """
        if self._use_apply():
            return self._generate_apply_query()
        return self._generate_script_query()

    def _generate_script_query(self):

        dataset = tdml.DataFrame(self.dataset)
        dataset_col_sql = ', \n'.join(['A.'+x for x in dataset.columns])
        partition_col_sql = ', \n'.join(['A.'+x for x in self.id_partition.split(',')])
        id_col_sql = ', \n'.join(['A.'+x for x in self.id_row.split(',')])


        if self.mapper_type == 'training':
            #types = get_partition_datatype(tdml.DataFrame(self.dataset),self.id_partition.split(','))
            output_sql = ', \n'.join([f"'{k} {v}'" for k,v in self.types.items() if k in self.id_partition.split(',')])
            # view on clause
            query = f"""
                    SELECT 
                        EXECUTION_TIME as TD_TIMECODE
                    ,    '{self.sto_view_name}' as ID_PROCESS
                    ,   {self.id_partition}
                    ,   ID_MODEL
                    ,   ID_TRAINED_MODEL
                    ,   MODEL_TYPE
                    ,   STATUS
                    ,   TRAINED_MODEL
                    FROM Script(
                        ON {self.schema_name}.{self.on_clause_view_name}
                        PARTITION BY {self.id_partition}
                        -- ,	STO_MODEL_ID ,{self.id_fold}
                        ORDER BY {self.id_row}
                        SCRIPT_COMMAND(
                            'tdpython3 ./{self.SEARCHUIFDBPATH}/tds_training.py  | awk -F"\t" "NF == {6+len(self.id_partition.split(','))}"'
                        )
                        RETURNS(
                                   {output_sql}
                                ,	'ID_MODEL         VARCHAR(36)'
                                ,	'ID_TRAINED_MODEL VARCHAR(36)'
                                ,	'MODEL_TYPE       VARCHAR(255)'
                                ,	'STATUS           VARCHAR(20000)'
                                ,	'TRAINED_MODEL    CLOB'
                                ,   'EXECUTION_TIME   TIMESTAMP(6) WITH TIME ZONE'
                        )
                        CHARSET('LATIN')
                    ) AS d
                    """
        elif self.mapper_type == 'feature engineering reducer':
            # types = get_partition_datatype(tdml.DataFrame(self.dataset),self.id_partition.split(','))
            output_sql = ', \n'.join(
                [f"'{k} {v}'" for k, v in self.types.items() if k in self.id_partition.split(',')])
            # view on clause
            query = f"""
                    SELECT 
                        EXECUTION_TIME as TD_TIMECODE
                    ,    '{self.sto_view_name}' as ID_PROCESS
                    ,   {self.id_partition}
                    ,   FEATURE_ROW
                    ,   FEATURE_NAME
                    ,   FEATURE_VALUE
                    ,   FEATURE_TYPE
                    ,   STATUS
                    ,   ID_MODEL
                    FROM Script(
                        ON {self.schema_name}.{self.on_clause_view_name}
                        PARTITION BY {self.id_partition}
                        -- ,	STO_MODEL_ID ,{self.id_fold}
                        ORDER BY {self.id_row}
                        SCRIPT_COMMAND(
                            'tdpython3 ./{self.SEARCHUIFDBPATH}/tds_feature_engineering_reducer.py  | awk -F"\t" "NF == {7 + len(self.id_partition.split(','))}"'
                        )
                        RETURNS(
                                {output_sql}
                            ,   'FEATURE_ROW      BIGINT'
                            ,	'FEATURE_NAME     VARCHAR(2000)'
                            ,	'FEATURE_VALUE    VARCHAR(2000)'
                            ,	'FEATURE_TYPE     VARCHAR(20000)'
                            ,	'STATUS           VARCHAR(20000)'
                            ,   'ID_MODEL         VARCHAR(36)'
                            ,   'EXECUTION_TIME   TIMESTAMP(6) WITH TIME ZONE'
                        )
                        CHARSET('LATIN')
                    ) AS d
                    """
        elif self.mapper_type == 'feature engineering':
            # types = get_partition_datatype(tdml.DataFrame(self.dataset),self.id_partition.split(','))
            output_sql = ', \n'.join(
                [f"'{k} {v}'" for k, v in self.types.items() if k in self.id_partition.split(',')+self.id_row.split(',')])
            # view on clause
            query = f"""
                    SELECT 
                         EXECUTION_TIME as TD_TIMECODE
                    ,    '{self.sto_view_name}' as ID_PROCESS
                    ,   {self.id_partition}
                    ,   {self.id_row}
                    ,   FEATURE_NAME
                    ,   FEATURE_VALUE
                    ,   FEATURE_TYPE
                    ,   STATUS
                    ,   ID_MODEL
                    FROM Script(
                        ON {self.schema_name}.{self.on_clause_view_name}
                        PARTITION BY {self.id_partition}
                        -- ,	STO_MODEL_ID ,{self.id_fold}
                        ORDER BY {self.id_row}
                        SCRIPT_COMMAND(
                            'tdpython3 ./{self.SEARCHUIFDBPATH}/tds_feature_engineering.py  | awk -F"\t" "NF == {6 + len(self.id_partition.split(',')+self.id_row.split(','))}"'
                        )
                        RETURNS(
                                {output_sql}
                            ,	'FEATURE_NAME     VARCHAR(2000)'
                            ,	'FEATURE_VALUE    VARCHAR(2000)'
                            ,	'FEATURE_TYPE     VARCHAR(20000)'
                            ,	'STATUS           VARCHAR(20000)'
                            ,   'ID_MODEL         VARCHAR(36)'
                            ,   'EXECUTION_TIME   TIMESTAMP(6) WITH TIME ZONE'
                        )
                        CHARSET('LATIN')
                    ) AS d
                    """
        elif self.mapper_type in ['scoring']:
            #types = get_partition_datatype(tdml.DataFrame(self.dataset),self.id_partition.split(',')+self.id_row.split(','))
            _part_cols = [c.strip() for c in self.id_partition.split(',') if c.strip()]
            _row_cols  = [c.strip() for c in self.id_row.split(',') if c.strip()]
            output_sql = ', \n'.join([f"'{k} {self.types[k]}'" for k in _part_cols + _row_cols if k in self.types])
            
            username = get_connection_username() # for VOLATILE table access
            
            # Output column count for the awk NF filter — fixed cols (15) +
            # partition keys + row keys. Updated when we added per-batch
            # instrumentation columns (SCRIPT_UUID + 6 timing/batch_no fields)
            # mirroring the Apply path. Was 8 before harmonisation.
            n_fixed_cols = 15
            nf_count = n_fixed_cols + len(self.id_partition.split(',')) + len(self.id_row.split(','))
            # Pass batch_size as the script's first CLI arg (matches Apply path
            # — tds_scoring.py and tds_scoring_apply.py both accept sys.argv[1]).
            # The script slices stdin and runs model.score() every BATCH_SIZE
            # rows. Without this the script defaults to 100000 — fine for tiny
            # partitions but masks the per-batch timing observable in the
            # PROCESS_TIME / PRINT_TIME / BATCH_NO columns.
            scoring_batch_size = int(getattr(self, 'apply_scoring_batch_size', 1000) or 1000)
            query = f"""
                    SELECT
                        EXECUTION_TIME as TD_TIMECODE
                    ,   '{self.sto_view_name}' as ID_PROCESS
                    ,   {self.id_partition}
                    ,   {self.id_row}
                    ,   FEATURE_NAME
                    ,   FEATURE_VALUE
                    ,   FEATURE_TYPE
                    ,   STATUS
                    ,   ID_TRAINED_MODEL
                    ,   SCRIPT_UUID
                    ,   TOTAL_TIME
                    ,   IMPORT_TIME
                    ,   LOAD_TIME
                    ,   PROCESS_TIME
                    ,   PRINT_TIME
                    ,   BATCH_NO
                    FROM Script(
                        --ON {self.schema_name}.{self.on_clause_view_name}
                        ON {username}.{self.on_clause_volatile_table_name}
                        PARTITION BY {self.id_partition}
                         --,  STO_MODEL_ID ,{self.id_fold}
                        ORDER BY {self.id_row}
                        SCRIPT_COMMAND(
                            'tdpython3 ./{self.SEARCHUIFDBPATH}/tds_scoring.py {scoring_batch_size} | awk -F"\t" "NF == {nf_count}"'
                        )
                        RETURNS(
                                   {output_sql}
                                ,	'FEATURE_NAME     VARCHAR(2000)'
                                ,	'FEATURE_VALUE    VARCHAR(2000)'
                                ,	'FEATURE_TYPE     VARCHAR(20000)'
                                ,	'STATUS           VARCHAR(20000)'
                                ,   'ID_MODEL         VARCHAR(36)'
                                ,	'MODEL_TYPE       VARCHAR(255)'
                                ,	'ID_TRAINED_MODEL VARCHAR(36)'
                                ,	'SCRIPT_UUID      VARCHAR(36)'
                                ,	'TOTAL_TIME       FLOAT'
                                ,	'IMPORT_TIME      FLOAT'
                                ,	'LOAD_TIME        FLOAT'
                                ,	'PROCESS_TIME     FLOAT'
                                ,	'PRINT_TIME       FLOAT'
                                ,	'BATCH_NO         INTEGER'
                                ,   'EXECUTION_TIME   TIMESTAMP(6) WITH TIME ZONE'
                        )
                        CHARSET('LATIN')
                    ) AS d
                    """

        return query

    def _generate_apply_query(self):
        """Emit the VCL/OpenAF `FROM Apply(...)` SQL fragment.

        Mirrors `_generate_script_query` but targets the Apply table operator:
          - ON clause references the same on-clause view (no volatile table needed,
            even for scoring — Apply reads the view directly).
          - APPLY_COMMAND invokes `python3 tds_*_apply.py` (no awk filter — the
            Apply scripts emit fixed-shape csv themselves).
          - ENVIRONMENT names the user env that holds the installed scripts.
          - STYLE('csv') + DELIMITER(...) match the Apply script IO contract.
        """
        if not self.apply_env_name:
            raise ValueError(
                "use_apply=True but apply_env_name is not set. "
                "Set TDStone(apply_env_name=...) or pass apply_env_name to Mapper."
            )

        delimiter = self.apply_delimiter

        if self.mapper_type == 'training':
            output_sql = ', \n'.join(
                [f"{k} {v}" for k, v in self.types.items()
                 if k in self.id_partition.split(',')]
            )
            apply_command = f"{self.apply_python} tds_training_apply.py"
            return f"""
                    SELECT
                        EXECUTION_TIME as TD_TIMECODE
                    ,    '{self.sto_view_name}' as ID_PROCESS
                    ,   {self.id_partition}
                    ,   ID_MODEL
                    ,   ID_TRAINED_MODEL
                    ,   MODEL_TYPE
                    ,   STATUS
                    ,   TRAINED_MODEL
                    ,   MODEL_CHUNK_INDEX
                    ,   MODEL_CHUNK_TOTAL
                    FROM Apply(
                        ON {self.schema_name}.{self.on_clause_view_name}
                        PARTITION BY {self.id_partition}
                        ORDER BY {self.id_row}
                        RETURNS(
                                   {output_sql}
                                ,   ID_MODEL          VARCHAR(36) CHARACTER SET LATIN
                                ,   ID_TRAINED_MODEL  VARCHAR(36) CHARACTER SET LATIN
                                ,   MODEL_TYPE        VARCHAR(255) CHARACTER SET LATIN
                                ,   STATUS            VARCHAR(20000) CHARACTER SET LATIN
                                ,   TRAINED_MODEL     VARCHAR(64000) CHARACTER SET LATIN
                                ,   MODEL_CHUNK_INDEX INTEGER
                                ,   MODEL_CHUNK_TOTAL INTEGER
                                ,   EXECUTION_TIME    TIMESTAMP(6) WITH TIME ZONE
                        )
                        USING
                            APPLY_COMMAND('{apply_command}')
                            ENVIRONMENT('{self.apply_env_name}')
                            STYLE('csv')
                            DELIMITER('{delimiter}')
                    ) AS d
                    """

        if self.mapper_type == 'feature engineering reducer':
            output_sql = ', \n'.join(
                [f"{k} {v}" for k, v in self.types.items()
                 if k in self.id_partition.split(',')]
            )
            apply_command = f"{self.apply_python} tds_feature_engineering_reducer_apply.py"
            return f"""
                    SELECT
                        EXECUTION_TIME as TD_TIMECODE
                    ,    '{self.sto_view_name}' as ID_PROCESS
                    ,   {self.id_partition}
                    ,   FEATURE_ROW
                    ,   FEATURE_NAME
                    ,   FEATURE_VALUE
                    ,   FEATURE_TYPE
                    ,   STATUS
                    ,   ID_MODEL
                    FROM Apply(
                        ON {self.schema_name}.{self.on_clause_view_name}
                        PARTITION BY {self.id_partition}
                        ORDER BY {self.id_row}
                        RETURNS(
                                {output_sql}
                            ,   FEATURE_ROW      BIGINT
                            ,   FEATURE_NAME     VARCHAR(2000) CHARACTER SET LATIN
                            ,   FEATURE_VALUE    VARCHAR(2000) CHARACTER SET LATIN
                            ,   FEATURE_TYPE     VARCHAR(20000) CHARACTER SET LATIN
                            ,   STATUS           VARCHAR(20000) CHARACTER SET LATIN
                            ,   ID_MODEL         VARCHAR(36) CHARACTER SET LATIN
                            ,   EXECUTION_TIME   TIMESTAMP(6) WITH TIME ZONE
                        )
                        USING
                            APPLY_COMMAND('{apply_command}')
                            ENVIRONMENT('{self.apply_env_name}')
                            STYLE('csv')
                            DELIMITER('{delimiter}')
                    ) AS d
                    """

        if self.mapper_type == 'feature engineering':
            output_sql = ', \n'.join(
                [f"{k} {v}" for k, v in self.types.items()
                 if k in self.id_partition.split(',') + self.id_row.split(',')]
            )
            apply_command = f"{self.apply_python} tds_feature_engineering_apply.py"
            return f"""
                    SELECT
                         EXECUTION_TIME as TD_TIMECODE
                    ,    '{self.sto_view_name}' as ID_PROCESS
                    ,   {self.id_partition}
                    ,   {self.id_row}
                    ,   FEATURE_NAME
                    ,   FEATURE_VALUE
                    ,   FEATURE_TYPE
                    ,   STATUS
                    ,   ID_MODEL
                    FROM Apply(
                        ON {self.schema_name}.{self.on_clause_view_name}
                        PARTITION BY {self.id_partition}
                        ORDER BY {self.id_row}
                        RETURNS(
                                {output_sql}
                            ,   FEATURE_NAME     VARCHAR(2000) CHARACTER SET LATIN
                            ,   FEATURE_VALUE    VARCHAR(2000) CHARACTER SET LATIN
                            ,   FEATURE_TYPE     VARCHAR(20000) CHARACTER SET LATIN
                            ,   STATUS           VARCHAR(20000) CHARACTER SET LATIN
                            ,   ID_MODEL         VARCHAR(36) CHARACTER SET LATIN
                            ,   EXECUTION_TIME   TIMESTAMP(6) WITH TIME ZONE
                        )
                        USING
                            APPLY_COMMAND('{apply_command}')
                            ENVIRONMENT('{self.apply_env_name}')
                            STYLE('csv')
                            DELIMITER('{delimiter}')
                    ) AS d
                    """

        if self.mapper_type == 'scoring':
            _part_cols = [c.strip() for c in self.id_partition.split(',') if c.strip()]
            _row_cols  = [c.strip() for c in self.id_row.split(',') if c.strip()]
            output_sql = ', \n'.join(
                [f"{k} {self.types[k]}" for k in _part_cols + _row_cols if k in self.types]
            )
            # Pass BATCH_SIZE as the script's first arg. The script streams
            # stdin via csv.DictReader and runs model.score() every BATCH_SIZE
            # rows. With HASH BY (below), one script process handles ALL
            # partitions hashed to its AMP — partition transitions are
            # detected via STO_FAKE_ROW == 1 in the script, which resets
            # chunk state and reassembles a fresh per-partition model.
            scoring_batch_size = int(getattr(self, 'apply_scoring_batch_size', 1000) or 1000)
            apply_command = f"{self.apply_python} tds_scoring_apply.py {scoring_batch_size}"
            # HASH BY (instead of PARTITION BY) collapses N pipe calls into
            # one per AMP. LOCAL ORDER BY keeps each partition's rows
            # contiguous on each AMP so the per-partition state machine in
            # the script can detect transitions cleanly. Toggle via
            # ``self.apply_scoring_method`` (default 'hash'; 'partition' for
            # baseline / correctness comparison runs).
            method = (getattr(self, 'apply_scoring_method', 'hash') or 'hash').lower()
            if method == 'partition':
                dispatch_sql = (
                    f"PARTITION BY {self.id_partition}\n"
                    f"                        ORDER BY {self.id_row}"
                )
            elif method == 'hash_unordered':
                # Diagnostic: HASH BY with NO LOCAL ORDER BY — mirrors the
                # embedding script's pattern. Use to test whether
                # LOCAL ORDER BY was forcing per-partition stream subdivision.
                dispatch_sql = f"HASH BY {self.id_partition}"
            elif method == 'hash_any':
                # Reserved (HASH BY ANY isn't valid syntax in current Apply).
                dispatch_sql = "HASH BY ANY"
            elif method == 'partition_any':
                # WARNING: PARTITION BY ANY breaks chunked-model co-location.
                # Apply distributes rows arbitrarily across AMPs, so a
                # partition's chunks may land on a different AMP from its
                # data rows. Use 'hash_bucket' instead.
                dispatch_sql = "PARTITION BY ANY"
            elif method == 'hash_bucket':
                # HASH BY HASH_BUCKET (= Partition_ID MOD N) — one script per
                # bucket. With N = AMP count, that's ~one script per AMP.
                # Co-location preserved: all rows of partition P share the
                # same MOD value, so chunks + data of P land on the same AMP.
                # LOCAL ORDER BY keeps each AMP's stream sorted so the script's
                # STO_FAKE_ROW==1 transition logic still detects partition
                # boundaries cleanly.
                dispatch_sql = (
                    "HASH BY HASH_BUCKET\n"
                    f"                        LOCAL ORDER BY HASH_BUCKET, {self.id_partition}, {self.id_row}"
                )
            else:
                dispatch_sql = (
                    f"HASH BY {self.id_partition}\n"
                    f"                        LOCAL ORDER BY {self.id_partition}, {self.id_row}"
                )
            return f"""
                    SELECT
                        EXECUTION_TIME as TD_TIMECODE
                    ,   '{self.sto_view_name}' as ID_PROCESS
                    ,   {self.id_partition}
                    ,   {self.id_row}
                    ,   FEATURE_NAME
                    ,   FEATURE_VALUE
                    ,   FEATURE_TYPE
                    ,   STATUS
                    ,   ID_TRAINED_MODEL
                    ,   SCRIPT_UUID
                    ,   TOTAL_TIME
                    ,   IMPORT_TIME
                    ,   LOAD_TIME
                    ,   PROCESS_TIME
                    ,   PRINT_TIME
                    ,   BATCH_NO
                    FROM Apply(
                        ON {self.schema_name}.{self.on_clause_view_name}
                        {dispatch_sql}
                        RETURNS(
                                   {output_sql}
                                ,   FEATURE_NAME     VARCHAR(2000) CHARACTER SET LATIN
                                ,   FEATURE_VALUE    VARCHAR(2000) CHARACTER SET LATIN
                                ,   FEATURE_TYPE     VARCHAR(20000) CHARACTER SET LATIN
                                ,   STATUS           VARCHAR(20000) CHARACTER SET LATIN
                                ,   ID_MODEL         VARCHAR(36) CHARACTER SET LATIN
                                ,   MODEL_TYPE       VARCHAR(255) CHARACTER SET LATIN
                                ,   ID_TRAINED_MODEL VARCHAR(36) CHARACTER SET LATIN
                                ,   SCRIPT_UUID      VARCHAR(36) CHARACTER SET LATIN
                                ,   TOTAL_TIME       FLOAT
                                ,   IMPORT_TIME      FLOAT
                                ,   LOAD_TIME        FLOAT
                                ,   PROCESS_TIME     FLOAT
                                ,   PRINT_TIME       FLOAT
                                ,   BATCH_NO         INTEGER
                                ,   EXECUTION_TIME   TIMESTAMP(6) WITH TIME ZONE
                        )
                        USING
                            APPLY_COMMAND('{apply_command}')
                            ENVIRONMENT('{self.apply_env_name}')
                            STYLE('csv')
                            DELIMITER('{delimiter}')
                    ) AS d
                    """

        raise NotImplementedError(
            f"_generate_apply_query: mapper_type={self.mapper_type!r} not yet supported"
        )

    def create_volatile_table_on_clause(self):
        logger.info(
            "Materializing ON-clause view %s.%s into volatile table %s (mapper=%s)",
            self.schema_name, self.on_clause_view_name, self.on_clause_volatile_table_name, self.id,
        )
        tdml.DataFrame(tdml.in_schema(self.schema_name,self.on_clause_view_name)).to_sql(
            temporary=True,
            table_name = self.on_clause_volatile_table_name,
            if_exists='replace',
            primary_index = self.id_partition.split(','))
        return
    
    @execute_query
    def create_sto_view(self):
        
        
        
        #dataset = tdml.DataFrame(self.dataset)
        dataset_col_sql = ', \n'.join(['A.'+x for x in self.dataset_columns])
        partition_col_sql = ', \n'.join(['A.'+x for x in self.id_partition.split(',')])
        id_col_sql = ', \n'.join(['A.'+x for x in self.id_row.split(',')])
        #types = get_partition_datatype(tdml.DataFrame(self.dataset),self.id_partition.split(','))
        output_sql = ', \n'.join([f"'{k} {v}'" for k,v in self.types.items() if k in self.id_partition.split(',')])
        
        # view on clause
        query = f"""
                REPLACE VIEW {self.schema_name}.{self.sto_view_name} AS
                -- SET SESSION SEARCHUIFDBPATH = "{self.SEARCHUIFDBPATH}"
                {self.generate_sto_query()}
                    """
        logger.info(
            "Creating STO view %s.%s (mapper=%s type=%s SEARCHUIFDBPATH=%s)",
            self.schema_name, self.sto_view_name, self.id, self.mapper_type, self.SEARCHUIFDBPATH,
        )
        # Apply uses Environment('<env>') for UIF lookup, so SEARCHUIFDBPATH is
        # irrelevant. Worse, executing SET SESSION SEARCHUIFDBPATH on the fresh
        # teradatasql connection changes session routing and breaks subsequent
        # raw INSERTs into OFS-resident tables (Error 3802).
        if self._use_apply():
            return [query]
        session = f'SET SESSION SEARCHUIFDBPATH = "{self.SEARCHUIFDBPATH}";'
        return [session, query]
    
    def execute_mapper(self):
        """Dispatch to the Apply-or-Script execution path.

        Apply (VCL/OAF) cannot use the embedded `INSERT INTO <block-storage>
        SELECT ... FROM Apply(...)` form because Apply must run on the
        Analytical Compute Cluster (ACC) and ACC cannot write directly to
        block-storage tables (Teradata Error 6881). The Apply path therefore
        runs the table operator standalone via `tdml.Apply().execute_script()`
        and lands the result with `to_sql(if_exists='append')`, mirroring
        the pattern used in tdsgenai_lake.compute_vector_embedding.
        """
        if self._use_apply():
            return self._execute_mapper_apply()
        return self._execute_mapper_script()

    @execute_query
    def _execute_mapper_script(self):

        session = f'SET SESSION SEARCHUIFDBPATH = "{self.SEARCHUIFDBPATH}";'
        query   = ''
        if self.mapper_type == 'training':
            sto_query = self.generate_sto_query()
            query = f"""
            INSERT INTO {self.schema_name}.{self.trained_model_repository}
            (TD_TIMECODE, ID_PROCESS, {self.id_partition}, ID_MODEL, ID_TRAINED_MODEL, MODEL_TYPE, STATUS, TRAINED_MODEL)
            {sto_query}
            WHERE STATUS LIKE '%successful%'
            """
            query_errors = f"""
            INSERT INTO {self.schema_name}.{self.trained_model_repository}
            (TD_TIMECODE, ID_PROCESS, {self.id_partition}, ID_MODEL, ID_TRAINED_MODEL, MODEL_TYPE, STATUS)
            SELECT TD_TIMECODE, ID_PROCESS, {self.id_partition}, ID_MODEL, ID_TRAINED_MODEL, MODEL_TYPE, STATUS
            FROM ({sto_query}) AS sto_errors
            WHERE STATUS NOT LIKE '%successful%'
            """

            logger.info(
                "Training STO -> %s.%s (pickle view: V_%s_PICKLE, onnx view: V_%s_ONNX, byom catalog: V_%s_BYOM_CATALOG)",
                self.schema_name, self.trained_model_repository,
                self.trained_model_repository, self.trained_model_repository, self.trained_model_repository,
            )
            return [session, query, query_errors]

        if self.mapper_type == 'feature engineering reducer':
            query = f"""
            INSERT INTO {self.schema_name}.{self.reduced_feature_repository}
            (TD_TIMECODE, ID_PROCESS, {self.id_partition}, FEATURE_ROW, FEATURE_NAME, FEATURE_VALUE, FEATURE_TYPE, STATUS, ID_MODEL)
            {self.generate_sto_query()}
            WHERE STATUS LIKE '%successful%'
            """

            logger.info(
                "Feature-engineering reducer STO -> %s.%s",
                self.schema_name, self.reduced_feature_repository,
            )

        if self.mapper_type == 'feature engineering':
            query = f"""
            INSERT INTO {self.schema_name}.{self.features_repository}
            (TD_TIMECODE, ID_PROCESS, {self.id_partition}, {self.id_row}, FEATURE_NAME, FEATURE_VALUE, FEATURE_TYPE, STATUS, ID_MODEL)
            {self.generate_sto_query()}
            WHERE STATUS LIKE '%successful%'
            """

            logger.info(
                "Feature-engineering STO -> %s.%s",
                self.schema_name, self.features_repository,
            )

        if self.mapper_type == 'scoring':

            self.create_volatile_table_on_clause()

            # manage temporal
            query = f"""
            INSERT INTO {self.schema_name}.{self.scores_repository}
            (TD_TIMECODE, ID_PROCESS, {self.id_partition},{self.id_row}, FEATURE_NAME, FEATURE_VALUE, FEATURE_TYPE, STATUS, ID_TRAINED_MODEL,
             SCRIPT_UUID, TOTAL_TIME, IMPORT_TIME, LOAD_TIME, PROCESS_TIME, PRINT_TIME, BATCH_NO)
            {self.generate_sto_query()}
            WHERE STATUS LIKE '%successful%'
            """

            logger.info(
                "Scoring STO -> %s.%s",
                self.schema_name, self.scores_repository,
            )
        return [session, query]

    def _collect_apply_stats(self):
        """Collect optimizer statistics on tables involved in the on-clause JOIN.

        Without statistics the Teradata optimizer falls back to product joins
        and ~5x oversized spool estimates for the on-clause view (verified via
        EXPLAIN: Pipeline 4 dropped from ~2.9 GB / 10.3 s to ~600 MB / 2.2 s
        after collecting stats on the join keys). All tables here are in the
        tdstone2-owned schema so no cross-schema permission issues. The
        dataset itself is the user's — they should ``COLLECT STATS`` on it
        manually for the partition column they pass as ``id_partition``.
        """
        from tdstone2.utils import _raw_execute_apply
        if self.mapper_type == 'training':
            target_table = self.trained_model_repository
            cols = [self.id_partition.split(',')[0], 'ID_MODEL', 'ID_TRAINED_MODEL',
                    'MODEL_TYPE', 'MODEL_CHUNK_INDEX']
        elif self.mapper_type == 'scoring':
            target_table = self.scores_repository
            cols = [self.id_partition.split(',')[0], 'ID_TRAINED_MODEL',
                    'FEATURE_NAME', 'FEATURE_TYPE']
        else:
            return  # feature-engineering paths — skip for now

        full = f"{self.schema_name}.{target_table}"
        for col in cols:
            stmt = f'COLLECT STATISTICS COLUMN ({col}) ON {full}'
            try:
                _raw_execute_apply(stmt)
            except Exception as e:
                logger.debug("collect-stats skipped for %s.(%s): %s", full, col, str(e).split('\n')[0])

        # Also refresh stats on the per-mapper enabled-partition table
        # (tiny, but governs the JOIN that drives partition selection).
        mapper_full = f"{self.schema_name}.{self.mapper_table_name}"
        for col in (self.id_partition.split(',')[0], 'ID_TRAINED_MODEL', 'STATUS'):
            try:
                _raw_execute_apply(f'COLLECT STATISTICS COLUMN ({col}) ON {mapper_full}')
            except Exception as e:
                logger.debug("collect-stats skipped for %s.(%s): %s", mapper_full, col, str(e).split('\n')[0])

    def _execute_mapper_apply(self):
        """Apply (VCL/OAF) execution path.

        Emit `INSERT INTO <ofs_repo> SELECT ... FROM Apply(...)` and run it via
        `_raw_execute` (raw teradatasql cursor, bypassing teradataml). Both
        sides of the INSERT live in OFS thanks to STORAGE = TD_OFSSTORAGE on
        the destination, so there's no cross-cluster routing for ACC to choke
        on. We deliberately avoid `tdml.Apply().execute_script()` because its
        internal `UtilFuncs._execute_query(ins_table)` reproduces the spurious
        Error 3802 we saw against OFS targets in our own code (since fixed by
        `_raw_execute`).
        """
        from tdstone2.utils import _raw_execute_apply as _raw_execute

        if not self.apply_env_name:
            raise ValueError(
                "use_apply=True but apply_env_name is not set on Mapper. "
                "Pass apply_env_name to TDStone(...) or to Mapper directly."
            )

        sto_query = self.generate_sto_query()

        if self.mapper_type == 'training':
            stmt_success = f"""
            INSERT INTO {self.schema_name}.{self.trained_model_repository}
            (TD_TIMECODE, ID_PROCESS, {self.id_partition}, ID_MODEL, ID_TRAINED_MODEL, MODEL_TYPE, STATUS, TRAINED_MODEL, MODEL_CHUNK_INDEX, MODEL_CHUNK_TOTAL)
            {sto_query}
            WHERE STATUS LIKE '%successful%'
            """
            stmt_errors = f"""
            INSERT INTO {self.schema_name}.{self.trained_model_repository}
            (TD_TIMECODE, ID_PROCESS, {self.id_partition}, ID_MODEL, ID_TRAINED_MODEL, MODEL_TYPE, STATUS)
            SELECT TD_TIMECODE, ID_PROCESS, {self.id_partition}, ID_MODEL, ID_TRAINED_MODEL, MODEL_TYPE, STATUS
            FROM ({sto_query}) AS sto_errors
            WHERE STATUS NOT LIKE '%successful%'
            """
            logger.info(
                "Training Apply -> %s.%s (env=%s)",
                self.schema_name, self.trained_model_repository, self.apply_env_name,
            )
            _raw_execute(stmt_success)
            try:
                _raw_execute(stmt_errors)
            except Exception as e:
                logger.debug("No error rows or insert failed for training mapper id=%s: %s", self.id, e)
            # Refresh stats so the next score()'s on-clause planner picks
            # hash/merge joins instead of product joins. Verified via EXPLAIN
            # to drop the materialised on-clause spool from ~2.9 GB to ~0.6 GB
            # per partition on the chunked-RF run.
            self._collect_apply_stats()
            return

        if self.mapper_type == 'feature engineering reducer':
            stmt = f"""
            INSERT INTO {self.schema_name}.{self.reduced_feature_repository}
            (TD_TIMECODE, ID_PROCESS, {self.id_partition}, FEATURE_ROW, FEATURE_NAME, FEATURE_VALUE, FEATURE_TYPE, STATUS, ID_MODEL)
            {sto_query}
            WHERE STATUS LIKE '%successful%'
            """
            logger.info(
                "Feature-engineering reducer Apply -> %s.%s (env=%s)",
                self.schema_name, self.reduced_feature_repository, self.apply_env_name,
            )
            _raw_execute(stmt)
            return

        if self.mapper_type == 'feature engineering':
            stmt = f"""
            INSERT INTO {self.schema_name}.{self.features_repository}
            (TD_TIMECODE, ID_PROCESS, {self.id_partition}, {self.id_row}, FEATURE_NAME, FEATURE_VALUE, FEATURE_TYPE, STATUS, ID_MODEL)
            {sto_query}
            WHERE STATUS LIKE '%successful%'
            """
            logger.info(
                "Feature-engineering Apply -> %s.%s (env=%s)",
                self.schema_name, self.features_repository, self.apply_env_name,
            )
            _raw_execute(stmt)
            return

        if self.mapper_type == 'scoring':
            stmt = f"""
            INSERT INTO {self.schema_name}.{self.scores_repository}
            (TD_TIMECODE, ID_PROCESS, {self.id_partition}, {self.id_row}, FEATURE_NAME, FEATURE_VALUE, FEATURE_TYPE, STATUS, ID_TRAINED_MODEL,
             SCRIPT_UUID, TOTAL_TIME, IMPORT_TIME, LOAD_TIME, PROCESS_TIME, PRINT_TIME, BATCH_NO)
            {sto_query}
            """
            logger.info(
                "Scoring Apply -> %s.%s (env=%s)",
                self.schema_name, self.scores_repository, self.apply_env_name,
            )
            _raw_execute(stmt)
            self._collect_apply_stats()
            return

        raise ValueError(f"Unknown mapper_type '{self.mapper_type}' for Apply path")