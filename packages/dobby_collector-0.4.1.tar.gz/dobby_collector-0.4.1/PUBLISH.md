# Publishing `dobby-collector` to PyPI

> Last updated 2026-05-16. Phase 6 of the Dobby Collector SDK roadmap —
> see `.claude/skills/native-agent-telemetry/SKILL.md` for context.

## 🚨 Known blocker — SM credentials are basic-auth, not API token

**As of 2026-05-16**: SM secrets `pypi-username` + `pypi-password` (in
project `gcp-dobby-p`) hold Gil's PERSONAL PyPI username + account
password. PyPI rejects basic auth for uploads since 2024 — returns
`403 Forbidden` regardless of whether the project already exists.

**The fix (Gil-direct, ~3 min):**

1. Visit https://pypi.org/manage/account/token/
2. Create a new token:
   - **Token name**: `dobby-collector-publish-2026-05-16`
   - **Scope**: `dobby-collector` (project-scoped, narrower blast radius)
3. Copy the value (starts with `pypi-AgEI...`). Shown ONCE.
4. Store in SM (replaces the basic-auth password):
   ```bash
   printf '%s' '__token__' | \
     gcloud secrets versions add pypi-username \
       --data-file=- --project=gcp-dobby-p
   printf '%s' 'pypi-AgEIcHlwaS5vcmcCJ...' | \
     gcloud secrets versions add pypi-password \
       --data-file=- --project=gcp-dobby-p
   ```
   (printf is mandatory — `echo` adds a trailing newline that breaks
   auth, per `feedback_sm_secret_trailing_newline_trap`.)
5. Verify:
   ```bash
   gcloud secrets versions access latest --secret=pypi-username --project=gcp-dobby-p
   # Should output: __token__
   gcloud secrets versions access latest --secret=pypi-password --project=gcp-dobby-p
   # Should output: pypi-AgEI...
   ```

Once stored, any subsequent `python3 -m twine upload` run (Section B
below) will succeed using `TWINE_USERNAME=__token__` + the SM password.

This is the operator runbook for cutting a new public release of the
`dobby-collector` Python SDK to **pypi.org**. The first publish (v0.1.0)
is also the moment when the name `dobby-collector` is permanently
registered to Dobby AI's PyPI account.

## One-time setup (Gil-direct)

These steps happen ONCE per publishing operator. Skip if you already
have a PyPI account + API token saved.

### 1. Register a PyPI account

Go to https://pypi.org/account/register/

- **Username**: `dobby-ai` (recommended — owns the namespace) OR your
  personal handle if `dobby-ai` is already taken
- **Email**: `gil@dobby-ai.com` (verified mailbox so password reset works)
- **Display name**: Dobby AI, Inc.

Confirm via the email link PyPI sends.

### 2. Enable 2FA (REQUIRED)

PyPI enforces 2FA for all uploads since 2024.

https://pypi.org/manage/account/

- Add a TOTP authenticator (Authy / 1Password / Bitwarden / Google Authenticator)
- Save the recovery codes somewhere durable

### 3. Create an API token

https://pypi.org/manage/account/token/

- **Token name**: `dobby-collector-publish-2026-05-14`
- **Scope**: "Entire account" for the FIRST upload (the project doesn't
  exist yet, so we can't scope to it). After v0.1.0 lands, create a new
  token scoped to `dobby-collector` only and revoke this broad one.

Copy the token value. It starts with `pypi-` and you'll see it ONLY ONCE.

Save it as a local env var for this session:
```bash
export TWINE_PASSWORD='pypi-AgEI...the-long-token...'
export TWINE_USERNAME='__token__'    # literally the string `__token__`
```

## v0.4.0 release notes (pending publish 2026-05-16)

**Already on `main` at commit `4ee9f7d7`** — awaits the PyPI token fix
in the §🚨 Known blocker section above. When Gil unblocks, run sections
B → H to publish.

**What changed since v0.3.0:**

- **W3C Trace Context auto-emission.** Every batch the SDK ships to Dobby
  now carries a fresh `traceparent: 00-{32hex}-{16hex}-01` header
  generated via `secrets.token_hex`. Per-batch (not per-process, not
  per-event) so each upload is a unique transaction. No customer code
  changes — `init(...)` picks up the new behavior automatically.
- **Governance unlock.** Once a customer's batches land traceparent on
  Dobby's side, the Surrounding-mode `Tracing Enabled` governance
  control (weight = 4) flips from `not_applicable` → `configured` for
  the entire org within one hourly governance-rescore cron tick. See the
  public docs page at `/docs/sdk/python-collector/tracing` for the
  customer-facing explanation.
- **Server-side validation.** Inbound `traceparent` headers go through
  strict W3C format check + all-zero sentinel rejection before they're
  stamped onto `workload_runs.metadata_json.traceparent`. Malformed
  headers are silently dropped — never rejects the batch.

**Suggested release-notes blurb for the PyPI long description:**

```
v0.4.0 (2026-05-16)
-------------------
- Auto-emit W3C Trace Context headers on every outbound batch.
- No code changes required — upgrade with `pip install -U dobby-collector`.
- Unlocks the Surrounding-mode "Tracing Enabled" governance control in
  Dobby AI's Control Plane (https://dobby-ai.com/docs/sdk/python-collector/tracing).
```

**Verification after publish:**

```bash
# 1. Confirm wheel includes the new symbol
python3 -c "from dobby_collector._sender import _make_traceparent; print(_make_traceparent())"
# Expected output: 00-{32hex}-{16hex}-01

# 2. Smoke against a real connector (Gil-direct, requires dsdk_*/wc_*)
DOBBY_API_KEY=dsdk_xxx DOBBY_CONNECTOR_ID=wc_xxx \
  python3 sdk/python-collector/examples/quickstart.py
# Then check the BQ row got traceparent:
bq query --use_legacy_sql=false \
  "SELECT JSON_VALUE(metadata_json, '\$.traceparent') AS tp
   FROM \`gcp-dobby-p.ds_platform.workload_runs\`
   WHERE connector_id = 'wc_xxx'
   ORDER BY created_at DESC LIMIT 1"
# Expected: tp is a non-null W3C-formatted string
```

## Each release (you do this every time you bump version)

### A. Bump the version

Two files, kept in lockstep — line numbers drift, so grep for the constant:
1. `sdk/python-collector/pyproject.toml` — the `version = "..."` line:
   ```toml
   version = "0.1.1"   # was 0.1.0
   ```
2. `sdk/python-collector/src/dobby_collector/_config.py` — the `SDK_VERSION`
   constant. `__init__.py` derives `__version__` from it, so this single
   bump cascades to both `dobby_collector.__version__` AND the
   `sdk_meta.version` the SDK reports to the server.

Bump rules (semver):
- `0.x.y` → `0.x.(y+1)` for bug fixes that don't change the wire protocol
  or the public API surface
- `0.x.y` → `0.(x+1).0` for new features (Phase 4 framework adapters,
  new SdkEvent types the server understands)
- `0.x.y` → `1.0.0` when we promise API stability — NOT yet

### B. Build the artifacts

```bash
cd sdk/python-collector
rm -rf dist/ build/
python3 -m build
```

Output: `dist/dobby_collector-X.Y.Z-py3-none-any.whl` + `dist/dobby_collector-X.Y.Z.tar.gz`

### C. Validate before uploading

```bash
python3 -m twine check dist/*
# Both must report PASSED.
```

Optional but recommended — install into a clean venv + verify imports:
```bash
python3 -m venv /tmp/pypi-test
source /tmp/pypi-test/bin/activate
pip install dist/dobby_collector-X.Y.Z-py3-none-any.whl
python3 -c "from dobby_collector import init, __version__; print(__version__)"
pip install "dist/dobby_collector-X.Y.Z-py3-none-any.whl[langchain]"
python3 -c "from dobby_collector.integrations.langchain import DobbyCallbackHandler"
deactivate
rm -rf /tmp/pypi-test
```

### D. Test upload to TestPyPI (FIRST RELEASE ONLY — optional after)

Before the FIRST production upload, do a dry-run on TestPyPI so a typo
in package metadata doesn't burn the `dobby-collector` name on real PyPI:

```bash
# Get a TestPyPI account + token from https://test.pypi.org first
TWINE_USERNAME=__token__ \
  TWINE_PASSWORD='pypi-test-...' \
  python3 -m twine upload --repository testpypi dist/*
```

Verify install:
```bash
pip install --index-url https://test.pypi.org/simple/ dobby-collector
```

If anything looks wrong, fix it BEFORE step E. TestPyPI is wiped
periodically so name conflicts don't carry over.

### E. Upload to production PyPI

**This step permanently registers the package version. No takebacks.**

```bash
cd sdk/python-collector
TWINE_USERNAME=__token__ \
  TWINE_PASSWORD="$TWINE_PASSWORD" \
  python3 -m twine upload dist/*
```

Expected output:
```
Uploading distributions to https://upload.pypi.org/legacy/
Uploading dobby_collector-X.Y.Z-py3-none-any.whl
100% ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 29.4/29.4 kB
Uploading dobby_collector-X.Y.Z.tar.gz
100% ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 38.0/38.0 kB

View at: https://pypi.org/project/dobby-collector/X.Y.Z/
```

### F. Verify the public install

```bash
python3 -m venv /tmp/pypi-prod-test
source /tmp/pypi-prod-test/bin/activate
pip install dobby-collector
python3 -c "from dobby_collector import __version__; print(__version__)"
# Must print the version you just uploaded.
pip install "dobby-collector[langchain]"
python3 -c "from dobby_collector.integrations.langchain import DobbyCallbackHandler; DobbyCallbackHandler()"
deactivate
rm -rf /tmp/pypi-prod-test
```

### G. Lock the namespace + scope the token

After v0.1.0 is up:

1. Go to https://pypi.org/manage/account/token/
2. Create a NEW token scoped to project `dobby-collector` (replaces the
   broad "entire account" token from step 3)
3. Revoke the old broad token
4. Update wherever the token is stored (1Password, Vault, etc.)

### H. Tag the release in git

```bash
cd /Users/gilkal/projects/repo-dobby
git tag -a "dobby-collector-vX.Y.Z" -m "dobby-collector vX.Y.Z published to PyPI"
git push origin "dobby-collector-vX.Y.Z"
```

The tag is for archeology — anyone debugging a customer issue can
`git checkout dobby-collector-v0.1.0` to see the exact source that
shipped.

## Yanking a bad release

If a version ships with a critical bug:

```
https://pypi.org/manage/project/dobby-collector/release/X.Y.Z/
→ "Yank release" button
```

Yank does NOT delete the file (PyPI never lets you delete after upload
for ~24h, and never lets you re-upload the same version number) — it
just hides it from default `pip install` resolution. Customers explicitly
asking for the yanked version still get it.

Fix forward: bump version + upload a new release. Add `yanked = true`
reasoning in the release notes.

## Trusted Publishing (future — when we have a build pipeline)

Manual `twine upload` is fine for the first few releases. Once we cut
v0.x or v1.0 we should switch to PyPI Trusted Publishing via GitHub
Actions / Cloud Build OIDC:

https://docs.pypi.org/trusted-publishers/

Trusted publishing eliminates the long-lived API token — every release
is signed by the CI run that built it. Filed for Phase 6+ follow-up.
