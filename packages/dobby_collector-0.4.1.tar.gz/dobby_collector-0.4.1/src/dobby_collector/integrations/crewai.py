"""
CrewAI auto-instrumentation
============================

Customer instantiates `DobbyCrewAIHandler` once at agent startup and every
crew kickoff / agent execution / task execution / LLM call / tool call
fires a Dobby SdkEvent automatically — no `@track` decorators needed.

Usage::

    from dobby_collector import init
    from dobby_collector.integrations.crewai import DobbyCrewAIHandler

    init(api_key="dsdk_...", connector_id="wc_...")
    handler = DobbyCrewAIHandler()   # registers globally on crewai_event_bus

    # Your existing CrewAI code runs unchanged — handler captures everything.
    crew = Crew(agents=[...], tasks=[...])
    result = crew.kickoff()

Each `crew.kickoff()` becomes one Dobby workload_run. The handler maps
CrewAI's `event_id` (UUID per event) to Dobby's `event_id`, and uses
`parent_event_id` to thread nested spans (task → agent → LLM/tool).

If no Dobby SDK run is active when CrewKickoffStartedEvent fires, the
handler auto-`start_run()`s and `end_run()`s on the corresponding
CrewKickoffCompletedEvent / Failed — the customer doesn't have to manage
run boundaries.

Install::

    pip install dobby-collector[crewai]

Lazy import: this module imports `crewai.events.*` at module load. If
`crewai>=1.0` isn't installed, `from dobby_collector.integrations.crewai
import DobbyCrewAIHandler` raises ImportError with a remediation message.
The base SDK `pip install dobby-collector` does NOT pull crewai transitively.

CrewAI version compatibility:
    Verified against crewai==1.14.4. The CrewAIEventsBus + BaseEventListener
    pattern stabilized in crewai>=1.0; earlier versions used different APIs
    (CrewAI Tools callback pattern, ad-hoc step_callback). Customers on
    older versions: pin a newer crewai or use the manual @track/span API.

CrewAI Cloud customers:
    DON'T need this handler. CrewAI Cloud delivers webhooks directly to
    Dobby's connector endpoint — instrumentation is server-side. Use this
    handler ONLY for local CrewAI Python lib (`pip install crewai`).
"""

from __future__ import annotations

import logging
import threading
from collections import OrderedDict
from time import time
from typing import Any, Optional

from .._api import _emit, end_run, start_run
from .._config import get_collector
from .._events import SdkEvent, iso_now, new_event_id

logger = logging.getLogger(__name__)

try:
    from crewai.events.base_event_listener import BaseEventListener
    from crewai.events.event_bus import CrewAIEventsBus, crewai_event_bus
    from crewai.events.types.agent_events import (
        AgentExecutionCompletedEvent,
        AgentExecutionStartedEvent,
    )
    from crewai.events.types.crew_events import (
        CrewKickoffCompletedEvent,
        CrewKickoffFailedEvent,
        CrewKickoffStartedEvent,
    )
    from crewai.events.types.llm_events import (
        LLMCallCompletedEvent,
        LLMCallFailedEvent,
        LLMCallStartedEvent,
    )
    from crewai.events.types.task_events import (
        TaskCompletedEvent,
        TaskFailedEvent,
        TaskStartedEvent,
    )
    from crewai.events.types.tool_usage_events import (
        ToolUsageErrorEvent,
        ToolUsageFinishedEvent,
        ToolUsageStartedEvent,
    )
except ImportError as e:  # pragma: no cover — only fires when crewai missing
    raise ImportError(
        "DobbyCrewAIHandler requires crewai>=1.0. Install with: "
        "pip install dobby-collector[crewai]  "
        "(or: pip install crewai)"
    ) from e


# Dobby SdkEvent types (mirror what the LangChain handler emits — server
# normalizer treats these identically regardless of source framework).
# IMPORTANT: keep these in lockstep with `_events.LLM_COMPLETION` / `TOOL_END`
# constants — the server normalizer pairs `llm.start` ↔ `llm.completion` (not
# `llm.end`) and `tool.start` ↔ `tool.end` by parent_event_id.
RUN_STARTED = "run.started"
RUN_COMPLETED = "run.completed"
RUN_FAILED = "run.failed"
SPAN_STARTED = "span.started"
SPAN_COMPLETED = "span.completed"
SPAN_FAILED = "span.failed"
TOOL_START = "tool.start"
TOOL_END = "tool.end"
TOOL_ERROR = "tool.error"
LLM_START = "llm.start"
LLM_END = "llm.completion"  # MUST match _events.LLM_COMPLETION for server pairing
LLM_ERROR = "llm.error"

_DEFAULT_RUN_MAP_SIZE = 4096
_DEFAULT_MAX_PAYLOAD_CHARS = 4000


def _truncate(value: Any, max_chars: int = _DEFAULT_MAX_PAYLOAD_CHARS) -> Any:
    """
    Coerce value to a JSON-serializable shape and truncate long strings.

    CrewAI events surface non-str payload types like `TaskOutput` (a Pydantic
    model). The sender's JSON encoder rejects them and the batch is dropped
    silently — so any path that returns a non-(None/str/list/dict) value MUST
    coerce it first. Falls back to `str(value)` for unknown types.
    """
    if value is None:
        return None
    if isinstance(value, str):
        return value if len(value) <= max_chars else value[:max_chars] + "...[truncated]"
    if isinstance(value, list):
        return [_truncate(v, max_chars) for v in value[:50]]
    if isinstance(value, dict):
        return {k: _truncate(v, max_chars) for k, v in list(value.items())[:50]}
    # Pydantic v2 model (TaskOutput, etc.) — serialise via .model_dump() then truncate.
    model_dump = getattr(value, "model_dump", None)
    if callable(model_dump):
        try:
            return _truncate(model_dump(), max_chars)
        except Exception:  # noqa: BLE001 — fall through to repr below
            pass
    # Any other type — coerce to string (last-resort JSON safety net).
    s = str(value)
    return s if len(s) <= max_chars else s[:max_chars] + "...[truncated]"


class _BoundedLRU(OrderedDict):
    """Drop-in bounded LRU cache. Identical to the LangChain handler's helper."""

    def __init__(self, max_size: int) -> None:
        super().__init__()
        self._max_size = max_size

    def __setitem__(self, key: str, value: Any) -> None:
        if key in self:
            self.move_to_end(key)
        super().__setitem__(key, value)
        if len(self) > self._max_size:
            self.popitem(last=False)

    def get_or_none(self, key: str) -> Any:
        if key in self:
            self.move_to_end(key)
            return OrderedDict.__getitem__(self, key)
        return None


class DobbyCrewAIHandler(BaseEventListener):
    """
    CrewAI event listener that emits Dobby SdkEvents for every callback the
    CrewAIEventsBus fires.

    Thread-safe: CrewAI may execute multiple agents in parallel; the handler
    guards its run-id mapping with an internal lock. Emission itself goes
    through the SDK's _emit which uses the buffer's internal lock.

    The handler registers itself on the GLOBAL `crewai_event_bus` singleton
    in __init__ — instantiate ONCE per process and reuse. Subclassing
    BaseEventListener triggers automatic registration via setup_listeners().

    Args:
        framework: Tag emitted on every event. Defaults to "crewai".
        auto_run: When True (default), auto-`start_run()` on CrewKickoffStartedEvent
            and `end_run()` on the corresponding Completed/Failed event.
            Customers who manage runs themselves can set this to False.
        max_payload_chars: Per-field truncation cap. Default 4000.
        run_map_size: Bounded LRU size for the CrewAI-event-id → Dobby-event-id
            mapping. Default 4096.

    Example:
        from dobby_collector import init
        from dobby_collector.integrations.crewai import DobbyCrewAIHandler

        init(api_key="dsdk_...", connector_id="wc_...")
        handler = DobbyCrewAIHandler()
        # Then any subsequent crew.kickoff() is captured automatically.
    """

    def __init__(
        self,
        *,
        framework: str = "crewai",
        auto_run: bool = True,
        max_payload_chars: int = _DEFAULT_MAX_PAYLOAD_CHARS,
        run_map_size: int = _DEFAULT_RUN_MAP_SIZE,
        event_bus: Optional["CrewAIEventsBus"] = None,
    ) -> None:
        self._framework = framework
        self._auto_run = auto_run
        self._max_payload_chars = max_payload_chars
        self._lock = threading.Lock()
        # CrewAI event_id (UUID str) → Dobby event_id mapping (start → end pairing)
        self._event_id_map: _BoundedLRU = _BoundedLRU(run_map_size)
        # CrewAI top-level event_id → Dobby RunHandle (when auto_run=True)
        self._auto_run_handles: _BoundedLRU = _BoundedLRU(run_map_size)
        # Per-event-id start time (monotonic) for duration_ms on end events
        self._start_times: _BoundedLRU = _BoundedLRU(run_map_size)
        # Allow injection of a test event bus; default to the global singleton
        self._event_bus_override = event_bus
        # BaseEventListener.__init__ calls setup_listeners — must run LAST
        super().__init__()

    # ------------------------------------------------------------------
    # BaseEventListener contract
    # ------------------------------------------------------------------

    def setup_listeners(self, crewai_event_bus: "CrewAIEventsBus") -> None:
        """Register handlers for every CrewAI event type Dobby cares about."""
        bus = self._event_bus_override or crewai_event_bus

        # Crew lifecycle (one workload_run per kickoff)
        bus.register_handler(CrewKickoffStartedEvent, self._on_crew_started)
        bus.register_handler(CrewKickoffCompletedEvent, self._on_crew_completed)
        bus.register_handler(CrewKickoffFailedEvent, self._on_crew_failed)

        # Task spans
        bus.register_handler(TaskStartedEvent, self._on_task_started)
        bus.register_handler(TaskCompletedEvent, self._on_task_completed)
        bus.register_handler(TaskFailedEvent, self._on_task_failed)

        # Agent execution spans
        bus.register_handler(AgentExecutionStartedEvent, self._on_agent_started)
        bus.register_handler(AgentExecutionCompletedEvent, self._on_agent_completed)

        # LLM call spans
        bus.register_handler(LLMCallStartedEvent, self._on_llm_started)
        bus.register_handler(LLMCallCompletedEvent, self._on_llm_completed)
        bus.register_handler(LLMCallFailedEvent, self._on_llm_failed)

        # Tool usage spans
        bus.register_handler(ToolUsageStartedEvent, self._on_tool_started)
        bus.register_handler(ToolUsageFinishedEvent, self._on_tool_finished)
        bus.register_handler(ToolUsageErrorEvent, self._on_tool_error)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _register_event(self, crewai_event_id: str, dobby_event_id: str) -> None:
        with self._lock:
            self._event_id_map[crewai_event_id] = dobby_event_id
            self._start_times[crewai_event_id] = time()

    def _lookup_parent_event_id(self, parent_id: Optional[str]) -> Optional[str]:
        if parent_id is None:
            return None
        with self._lock:
            return self._event_id_map.get_or_none(parent_id)

    def _resolve_run_id(self) -> str:
        """Active SDK run_id, or mint one if none active (graceful fallback)."""
        c = get_collector()
        if c is not None:
            rid = c.get_current_run()
            if rid is not None:
                return rid
        from .._events import new_run_id

        return new_run_id()

    def _duration_ms(self, crewai_event_id: str) -> Optional[float]:
        with self._lock:
            started = self._start_times.get_or_none(crewai_event_id)
        if started is None:
            return None
        return (time() - started) * 1000.0

    def _emit(
        self,
        *,
        event_type: str,
        crewai_event_id: str,
        crewai_parent_id: Optional[str] = None,
        name: Optional[str] = None,
        status: Optional[str] = None,
        data: Optional[dict[str, Any]] = None,
        is_end: bool = False,
    ) -> None:
        """Build + emit one Dobby SdkEvent. Maps CrewAI ids to Dobby ids."""
        try:
            if is_end:
                # End reuses the START's Dobby event_id as parent_event_id so
                # the server normalizer pairs (start, end) → ToolCallSummary etc.
                parent_event_id = self._lookup_parent_event_id(crewai_event_id)
                dobby_event_id = new_event_id()
                duration_ms = self._duration_ms(crewai_event_id)
            else:
                dobby_event_id = new_event_id()
                self._register_event(crewai_event_id, dobby_event_id)
                parent_event_id = self._lookup_parent_event_id(crewai_parent_id)
                duration_ms = None

            event = SdkEvent(
                event_id=dobby_event_id,
                run_id=self._resolve_run_id(),
                timestamp=iso_now(),
                type=event_type,
                name=name,
                parent_event_id=parent_event_id,
                duration_ms=duration_ms,
                status=status,
                data=data,
                framework=self._framework,
            )
            _emit(event)
        except Exception:  # noqa: BLE001 — handler must NEVER raise into customer
            logger.exception("DobbyCrewAIHandler: _emit swallowed")

    def _maybe_auto_start_run(self, event: "CrewKickoffStartedEvent") -> None:
        """Auto-start a Dobby run on the top-level CrewKickoff."""
        if not self._auto_run:
            return
        c = get_collector()
        if c is None:
            return
        # Only auto-start if no run is currently active.
        if c.get_current_run() is not None:
            return
        try:
            run = start_run(
                name=event.crew_name or "crewai_kickoff",
                inputs=_truncate(event.inputs, self._max_payload_chars),
            )
            with self._lock:
                self._auto_run_handles[event.event_id] = run
        except Exception:  # noqa: BLE001
            logger.exception("DobbyCrewAIHandler: auto start_run swallowed")

    def _maybe_auto_end_run(
        self, crewai_event_id: str, *, status: str, error: Optional[str] = None
    ) -> None:
        """End the auto-started run if one was created."""
        if not self._auto_run:
            return
        with self._lock:
            run = self._auto_run_handles.get_or_none(crewai_event_id)
        if run is None:
            return
        try:
            end_run(run, status=status, error=error)
        except Exception:  # noqa: BLE001
            logger.exception("DobbyCrewAIHandler: auto end_run swallowed")

    # ------------------------------------------------------------------
    # Crew kickoff lifecycle (= one workload_run)
    # ------------------------------------------------------------------

    def _on_crew_started(self, source: Any, event: "CrewKickoffStartedEvent") -> None:
        self._maybe_auto_start_run(event)
        self._emit(
            event_type=RUN_STARTED,
            crewai_event_id=event.event_id,
            crewai_parent_id=event.parent_event_id,
            name=event.crew_name or "crewai_kickoff",
            data={"inputs": _truncate(event.inputs, self._max_payload_chars)},
        )

    def _on_crew_completed(self, source: Any, event: "CrewKickoffCompletedEvent") -> None:
        # CrewAI's Completed event has different fields per version — use
        # getattr defensively. `output` is most common.
        outputs = getattr(event, "output", None)
        self._emit(
            event_type=RUN_COMPLETED,
            crewai_event_id=event.event_id,
            status="success",
            data={"outputs": _truncate(outputs, self._max_payload_chars)} if outputs else None,
            is_end=True,
        )
        self._maybe_auto_end_run(event.event_id, status="success")

    def _on_crew_failed(self, source: Any, event: "CrewKickoffFailedEvent") -> None:
        error = getattr(event, "error", None) or str(getattr(event, "exception", "unknown"))
        self._emit(
            event_type=RUN_FAILED,
            crewai_event_id=event.event_id,
            status="error",
            data={"error": str(error)[:1000]},
            is_end=True,
        )
        self._maybe_auto_end_run(event.event_id, status="error", error=str(error))

    # ------------------------------------------------------------------
    # Task spans
    # ------------------------------------------------------------------

    def _on_task_started(self, source: Any, event: "TaskStartedEvent") -> None:
        self._emit(
            event_type=SPAN_STARTED,
            crewai_event_id=event.event_id,
            crewai_parent_id=event.parent_event_id,
            name=event.task_name or f"task:{event.task_id}",
            data={"task_id": event.task_id, "agent_role": event.agent_role},
        )

    def _on_task_completed(self, source: Any, event: "TaskCompletedEvent") -> None:
        output = getattr(event, "output", None)
        self._emit(
            event_type=SPAN_COMPLETED,
            crewai_event_id=event.event_id,
            status="success",
            data={"output": _truncate(output, self._max_payload_chars)} if output else None,
            is_end=True,
        )

    def _on_task_failed(self, source: Any, event: "TaskFailedEvent") -> None:
        error = getattr(event, "error", None)
        self._emit(
            event_type=SPAN_FAILED,
            crewai_event_id=event.event_id,
            status="error",
            data={"error": str(error)[:1000]} if error else None,
            is_end=True,
        )

    # ------------------------------------------------------------------
    # Agent execution spans
    # ------------------------------------------------------------------

    def _on_agent_started(self, source: Any, event: "AgentExecutionStartedEvent") -> None:
        self._emit(
            event_type=SPAN_STARTED,
            crewai_event_id=event.event_id,
            crewai_parent_id=event.parent_event_id,
            name=f"agent:{event.agent_role or event.agent_id}",
            data={"agent_id": event.agent_id, "agent_role": event.agent_role},
        )

    def _on_agent_completed(self, source: Any, event: "AgentExecutionCompletedEvent") -> None:
        self._emit(
            event_type=SPAN_COMPLETED,
            crewai_event_id=event.event_id,
            status="success",
            is_end=True,
        )

    # ------------------------------------------------------------------
    # LLM call spans
    # ------------------------------------------------------------------

    def _on_llm_started(self, source: Any, event: "LLMCallStartedEvent") -> None:
        self._emit(
            event_type=LLM_START,
            crewai_event_id=event.event_id,
            crewai_parent_id=event.parent_event_id,
            name=f"llm:{event.model}",
            data={
                "model": event.model,
                "call_id": event.call_id,
                "messages": _truncate(event.messages, self._max_payload_chars),
            },
        )

    def _on_llm_completed(self, source: Any, event: "LLMCallCompletedEvent") -> None:
        response = getattr(event, "response", None)
        usage = getattr(event, "usage", None) or getattr(event, "token_usage", None)
        data: dict[str, Any] = {}
        if response is not None:
            data["response"] = _truncate(response, self._max_payload_chars)
        if usage is not None:
            data["usage"] = _truncate(usage, self._max_payload_chars)
        self._emit(
            event_type=LLM_END,
            crewai_event_id=event.event_id,
            status="success",
            data=data or None,
            is_end=True,
        )

    def _on_llm_failed(self, source: Any, event: "LLMCallFailedEvent") -> None:
        error = getattr(event, "error", None) or str(getattr(event, "exception", "unknown"))
        self._emit(
            event_type=LLM_ERROR,
            crewai_event_id=event.event_id,
            status="error",
            data={"error": str(error)[:1000]},
            is_end=True,
        )

    # ------------------------------------------------------------------
    # Tool usage spans
    # ------------------------------------------------------------------

    def _on_tool_started(self, source: Any, event: "ToolUsageStartedEvent") -> None:
        self._emit(
            event_type=TOOL_START,
            crewai_event_id=event.event_id,
            crewai_parent_id=event.parent_event_id,
            name=event.tool_name,
            data={
                "tool_name": event.tool_name,
                "tool_args": _truncate(event.tool_args, self._max_payload_chars),
                "tool_class": event.tool_class,
                "agent_role": event.agent_role,
            },
        )

    def _on_tool_finished(self, source: Any, event: "ToolUsageFinishedEvent") -> None:
        output = getattr(event, "output", None)
        self._emit(
            event_type=TOOL_END,
            crewai_event_id=event.event_id,
            status="success",
            data={"output": _truncate(output, self._max_payload_chars)} if output else None,
            is_end=True,
        )

    def _on_tool_error(self, source: Any, event: "ToolUsageErrorEvent") -> None:
        error = getattr(event, "error", None) or str(getattr(event, "exception", "unknown"))
        self._emit(
            event_type=TOOL_ERROR,
            crewai_event_id=event.event_id,
            status="error",
            data={"error": str(error)[:1000], "tool_name": getattr(event, "tool_name", None)},
            is_end=True,
        )
