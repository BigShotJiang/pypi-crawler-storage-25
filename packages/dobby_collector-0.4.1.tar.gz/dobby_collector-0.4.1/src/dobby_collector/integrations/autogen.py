"""
AutoGen auto-instrumentation
=============================

Customer attaches `DobbyAutoGenLogHandler` to AutoGen's event logger once
at startup and every LLM call / tool invocation / message dispatch fires
a Dobby SdkEvent automatically — no `@track` decorators needed.

Usage::

    import logging
    from autogen_core import EVENT_LOGGER_NAME
    from dobby_collector import init
    from dobby_collector.integrations.autogen import DobbyAutoGenLogHandler

    init(api_key="dsdk_...", connector_id="wc_...")
    logging.getLogger(EVENT_LOGGER_NAME).addHandler(DobbyAutoGenLogHandler())

    # Your existing AutoGen code runs unchanged — handler captures everything.

Why a logging.Handler instead of an event-bus subscriber:
    AutoGen ≥0.4 routes ALL telemetry through Python's stdlib logging —
    every LLMCallEvent / ToolCallEvent / MessageEvent is logged as a record
    where `record.msg` is the raw event instance. Subclassing
    `logging.Handler` is the canonical AutoGen integration pattern (see
    autogen_core docs § "Event Logging"). We don't need to import the
    runtime / register subscriptions / monkey-patch agents — just attach
    to the logger.

Each unique customer workload (a chat completion, an agent loop, an
agent team run) produces N events depending on what the customer code
does. AutoGen doesn't have a single "kickoff" event like CrewAI, so the
handler does NOT auto-start_run() by default — customer must call
`start_run()` / `end_run()` themselves around each logical unit of work
they want grouped into one workload_run.

If you want auto-run-grouping, pass `auto_run_on_first_event=True` to the
constructor — the handler then auto-`start_run()`s on the FIRST event it
sees (until the customer calls `end_run()` or the run is auto-terminated).
This is convenient for simple scripts; risky for long-running daemons
where you want explicit run boundaries.

Install::

    pip install dobby-collector[autogen]

Lazy import: this module imports `autogen_core.logging.*` at module
load. If `autogen-core>=0.4` isn't installed, `from
dobby_collector.integrations.autogen import DobbyAutoGenLogHandler`
raises ImportError with a remediation message.

AutoGen version compatibility:
    Verified against autogen-core==0.7.5. The Python-logging-based event
    pattern stabilized in autogen-core>=0.4 (Microsoft rewrote the
    callback API in the v0.4 release). Customers on autogen<0.4: pin a
    newer autogen or use the manual @track/span API.
"""

from __future__ import annotations

import logging
import threading
from collections import OrderedDict
from time import time
from typing import Any, Optional

from .._api import _emit, end_run, start_run
from .._config import get_collector
from .._events import SdkEvent, iso_now, new_event_id

logger = logging.getLogger(__name__)

try:
    from autogen_core import EVENT_LOGGER_NAME
    from autogen_core.logging import (
        AgentConstructionExceptionEvent,
        LLMCallEvent,
        LLMStreamEndEvent,
        LLMStreamStartEvent,
        MessageDroppedEvent,
        MessageEvent,
        MessageHandlerExceptionEvent,
        ToolCallEvent,
    )
except ImportError as e:  # pragma: no cover
    raise ImportError(
        "DobbyAutoGenLogHandler requires autogen-core>=0.4. Install with: "
        "pip install dobby-collector[autogen]  (or: pip install autogen-core)"
    ) from e


# Dobby SdkEvent types (mirror LangChain + CrewAI handler vocab)
RUN_STARTED = "run.started"
SPAN_STARTED = "span.started"
SPAN_COMPLETED = "span.completed"
SPAN_FAILED = "span.failed"
LLM_START = "llm.start"
LLM_END = "llm.end"
LLM_STREAM_START = "llm.stream_start"
LLM_STREAM_END = "llm.stream_end"
TOOL_END = "tool.end"   # AutoGen ToolCallEvent fires AFTER tool runs — only end events
TOOL_ERROR = "tool.error"
MESSAGE = "agent.message"

_DEFAULT_MAX_PAYLOAD_CHARS = 4000
_DEFAULT_RUN_MAP_SIZE = 4096


def _truncate(value: Any, max_chars: int = _DEFAULT_MAX_PAYLOAD_CHARS) -> Any:
    if value is None:
        return None
    if isinstance(value, str):
        return value if len(value) <= max_chars else value[:max_chars] + "...[truncated]"
    if isinstance(value, list):
        return [_truncate(v, max_chars) for v in value[:50]]
    if isinstance(value, dict):
        return {k: _truncate(v, max_chars) for k, v in list(value.items())[:50]}
    return value


def _agent_id_str(agent_id: Any) -> Optional[str]:
    """AutoGen AgentId is a dataclass — coerce to a stable string for SdkEvent."""
    if agent_id is None:
        return None
    try:
        return str(agent_id)
    except Exception:  # noqa: BLE001
        return None


def _field(event: Any, name: str, default: Any = None) -> Any:
    """Read an AutoGen event field. AutoGen routes most fields through
    `event.kwargs` dict (e.g. messages, response, tool_name, arguments,
    payload, sender, receiver, reason). A few (prompt_tokens,
    completion_tokens) are also direct attrs on some event classes.
    Try direct attr first, then kwargs, then default.
    """
    # Direct attr — fastest path
    val = getattr(event, name, _MISSING)
    if val is not _MISSING and val is not None:
        return val
    # Kwargs dict — AutoGen's standard storage
    kwargs = getattr(event, "kwargs", None)
    if isinstance(kwargs, dict) and name in kwargs:
        return kwargs[name]
    return default


_MISSING = object()


class _BoundedLRU(OrderedDict):
    def __init__(self, max_size: int) -> None:
        super().__init__()
        self._max_size = max_size

    def __setitem__(self, key: str, value: Any) -> None:
        if key in self:
            self.move_to_end(key)
        super().__setitem__(key, value)
        if len(self) > self._max_size:
            self.popitem(last=False)

    def get_or_none(self, key: str) -> Any:
        if key in self:
            self.move_to_end(key)
            return OrderedDict.__getitem__(self, key)
        return None


class DobbyAutoGenLogHandler(logging.Handler):
    """
    AutoGen event subscriber implemented as a Python logging.Handler.

    Subscribes to AutoGen's EVENT_LOGGER_NAME (default
    `autogen_core.events`) and translates each LogRecord whose `msg` is
    a recognized AutoGen event type into a Dobby SdkEvent.

    Thread-safe: stdlib logging is already thread-safe; the handler's
    internal LRU map is guarded by an internal lock.

    Args:
        framework: Tag emitted on every event. Defaults to "autogen".
        auto_run_on_first_event: When True, auto-start_run() on the FIRST
            event seen (until customer ends it). Useful for simple scripts.
            Default False — safer for long-running processes.
        max_payload_chars: Per-field truncation cap. Default 4000.
        run_map_size: Bounded LRU size for stream-start/end pairing.
            Default 4096.
        level: stdlib Handler log level. Defaults to logging.DEBUG so the
            handler sees every event AutoGen emits.

    Example:
        import logging
        from autogen_core import EVENT_LOGGER_NAME
        from dobby_collector import init
        from dobby_collector.integrations.autogen import DobbyAutoGenLogHandler

        init(api_key="dsdk_...", connector_id="wc_...")
        logging.getLogger(EVENT_LOGGER_NAME).addHandler(DobbyAutoGenLogHandler())
        # ... your AutoGen code ...
    """

    def __init__(
        self,
        *,
        framework: str = "autogen",
        auto_run_on_first_event: bool = False,
        max_payload_chars: int = _DEFAULT_MAX_PAYLOAD_CHARS,
        run_map_size: int = _DEFAULT_RUN_MAP_SIZE,
        level: int = logging.DEBUG,
    ) -> None:
        super().__init__(level=level)
        self._framework = framework
        self._auto_run_on_first_event = auto_run_on_first_event
        self._max_payload_chars = max_payload_chars
        self._lock = threading.Lock()
        # AutoGen stream events lack an event_id — we synthesize one keyed
        # on (agent_id, prompt_tokens|completion_tokens timestamp) to pair
        # start/end. Bounded for memory safety.
        self._stream_event_map: _BoundedLRU = _BoundedLRU(run_map_size)
        self._auto_run_handle: Any = None  # Set on first event if auto_run_on_first_event

    def emit(self, record: logging.LogRecord) -> None:
        """Called by stdlib logging for every record on EVENT_LOGGER_NAME."""
        try:
            event = record.msg
            if event is None:
                return

            self._maybe_auto_start_run()

            # Dispatch based on type — isinstance check, not name-based, so
            # subclasses of these events route correctly.
            if isinstance(event, LLMCallEvent):
                self._on_llm_call(event)
            elif isinstance(event, LLMStreamStartEvent):
                self._on_llm_stream_start(event)
            elif isinstance(event, LLMStreamEndEvent):
                self._on_llm_stream_end(event)
            elif isinstance(event, ToolCallEvent):
                self._on_tool_call(event)
            elif isinstance(event, MessageEvent):
                self._on_message(event)
            elif isinstance(event, MessageDroppedEvent):
                self._on_message_dropped(event)
            elif isinstance(
                event, (AgentConstructionExceptionEvent, MessageHandlerExceptionEvent)
            ):
                self._on_exception(event)
            # else: unknown event type — silently skip (forward-compat)
        except Exception:  # noqa: BLE001 — handler must NEVER raise into customer
            logger.exception("DobbyAutoGenLogHandler: emit swallowed")

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _maybe_auto_start_run(self) -> None:
        """If auto_run_on_first_event AND no run is active, start one."""
        if not self._auto_run_on_first_event:
            return
        with self._lock:
            if self._auto_run_handle is not None:
                return
            c = get_collector()
            if c is None:
                return
            if c.get_current_run() is not None:
                return
            try:
                self._auto_run_handle = start_run(name="autogen_session", inputs=None)
            except Exception:  # noqa: BLE001
                logger.exception("DobbyAutoGenLogHandler: auto start_run swallowed")

    def _resolve_run_id(self) -> str:
        """Active SDK run_id, or mint one if none active."""
        c = get_collector()
        if c is not None:
            rid = c.get_current_run()
            if rid is not None:
                return rid
        from .._events import new_run_id

        return new_run_id()

    def _emit_event(
        self,
        *,
        event_type: str,
        name: Optional[str] = None,
        status: Optional[str] = None,
        data: Optional[dict[str, Any]] = None,
        parent_event_id: Optional[str] = None,
        duration_ms: Optional[float] = None,
    ) -> str:
        """Build + emit one SdkEvent. Returns the new Dobby event_id."""
        dobby_event_id = new_event_id()
        sdk_event = SdkEvent(
            event_id=dobby_event_id,
            run_id=self._resolve_run_id(),
            timestamp=iso_now(),
            type=event_type,
            name=name,
            parent_event_id=parent_event_id,
            duration_ms=duration_ms,
            status=status,
            data=data,
            framework=self._framework,
        )
        try:
            _emit(sdk_event)
        except Exception:  # noqa: BLE001
            logger.exception("DobbyAutoGenLogHandler: _emit swallowed")
        return dobby_event_id

    # ------------------------------------------------------------------
    # Event handlers
    # ------------------------------------------------------------------

    def _on_llm_call(self, event: "LLMCallEvent") -> None:
        """LLMCallEvent fires AFTER the call completes — single .end-style event."""
        agent_id_str = _agent_id_str(_field(event, "agent_id"))
        self._emit_event(
            event_type=LLM_END,
            name=f"llm:{agent_id_str or 'unknown'}",
            status="success",
            data={
                "agent_id": agent_id_str,
                "messages": _truncate(_field(event, "messages"), self._max_payload_chars),
                "response": _truncate(_field(event, "response"), self._max_payload_chars),
                "prompt_tokens": _field(event, "prompt_tokens"),
                "completion_tokens": _field(event, "completion_tokens"),
            },
        )

    def _on_llm_stream_start(self, event: "LLMStreamStartEvent") -> None:
        agent_id = _agent_id_str(_field(event, "agent_id"))
        stream_key = f"{agent_id}:{id(event)}"
        dobby_id = self._emit_event(
            event_type=LLM_STREAM_START,
            name=f"llm-stream:{agent_id or 'unknown'}",
            data={
                "agent_id": agent_id,
                "messages": _truncate(_field(event, "messages"), self._max_payload_chars),
            },
        )
        with self._lock:
            self._stream_event_map[stream_key] = (dobby_id, time())

    def _on_llm_stream_end(self, event: "LLMStreamEndEvent") -> None:
        agent_id = _agent_id_str(_field(event, "agent_id"))
        with self._lock:
            matching_key = None
            for k in reversed(self._stream_event_map):
                if k.startswith(f"{agent_id}:"):
                    matching_key = k
                    break
            if matching_key:
                start_dobby_id, start_time = self._stream_event_map.pop(matching_key)
                duration_ms = (time() - start_time) * 1000.0
            else:
                start_dobby_id = None
                duration_ms = None

        self._emit_event(
            event_type=LLM_STREAM_END,
            name=f"llm-stream:{agent_id or 'unknown'}",
            status="success",
            data={
                "agent_id": agent_id,
                "response": _truncate(_field(event, "response"), self._max_payload_chars),
                "prompt_tokens": _field(event, "prompt_tokens"),
                "completion_tokens": _field(event, "completion_tokens"),
            },
            parent_event_id=start_dobby_id,
            duration_ms=duration_ms,
        )

    def _on_tool_call(self, event: "ToolCallEvent") -> None:
        """ToolCallEvent fires AFTER the tool runs — single .end-style event."""
        result = _field(event, "result")
        is_error = isinstance(result, dict) and result.get("is_error") is True
        tool_name = _field(event, "tool_name", "unknown_tool")
        self._emit_event(
            event_type=TOOL_ERROR if is_error else TOOL_END,
            name=tool_name,
            status="error" if is_error else "success",
            data={
                "tool_name": _field(event, "tool_name"),
                "arguments": _truncate(_field(event, "arguments"), self._max_payload_chars),
                "result": _truncate(result, self._max_payload_chars),
                "agent_id": _agent_id_str(_field(event, "agent_id")),
            },
        )

    def _on_message(self, event: "MessageEvent") -> None:
        self._emit_event(
            event_type=MESSAGE,
            name="agent_message",
            data={
                "sender": _agent_id_str(_field(event, "sender")),
                "receiver": _agent_id_str(_field(event, "receiver")),
                "kind": str(_field(event, "kind", "")) or None,
                "delivery_stage": str(_field(event, "delivery_stage", "")) or None,
                "payload": _truncate(_field(event, "payload"), self._max_payload_chars),
            },
        )

    def _on_message_dropped(self, event: "MessageDroppedEvent") -> None:
        self._emit_event(
            event_type=MESSAGE,
            name="agent_message_dropped",
            status="error",
            data={
                "sender": _agent_id_str(_field(event, "sender")),
                "receiver": _agent_id_str(_field(event, "receiver")),
                "reason": str(_field(event, "reason", "unknown")),
            },
        )

    def _on_exception(self, event: Any) -> None:
        """AgentConstructionException / MessageHandlerException — log as span.failed."""
        exc = _field(event, "exception") or _field(event, "error")
        self._emit_event(
            event_type=SPAN_FAILED,
            name=type(event).__name__,
            status="error",
            data={
                "error": str(exc)[:1000] if exc else "unknown",
                "agent_id": _agent_id_str(_field(event, "agent_id")),
            },
        )
