"""
Global SDK state + lifecycle
=============================

One `Collector` instance per process. Lifecycle:

    init(api_key=..., connector_id=...)   # creates the singleton, starts sender thread
    # ... agent runs, events flow ...
    shutdown(timeout_seconds=5)           # drains + stops thread

Why a module-level singleton: customers call `track`/`span`/`start_run` from
anywhere in their codebase without threading a reference around. Mirrors how
OpenAI's Python SDK, Sentry, etc. work.

Thread-safety: init/shutdown are guarded by `_lifecycle_lock`. Concurrent
init() calls return the same instance (idempotent). Post-shutdown calls
to event-emitting APIs no-op silently (never raise — telemetry can't crash
the app).
"""

from __future__ import annotations

import atexit
import contextlib
import logging
import os
import threading
from pathlib import Path
from typing import Optional, Union

from ._buffer import EventBuffer
from ._dlq import Dlq, _default_dlq_path
from ._sender import Sender

logger = logging.getLogger("dobby_collector")

SDK_VERSION = "0.4.1"


class Collector:
    """Singleton holding the buffer + sender + config."""

    def __init__(
        self,
        *,
        api_key: str,
        connector_id: str,
        base_url: str,
        flush_interval_seconds: float,
        max_buffer_events: int,
        framework: Optional[str],
        host_fingerprint: Optional[str],
        pii_redact: bool,
        exclude_fields: list[str],
        dlq: Optional[Dlq] = None,
    ) -> None:
        self.api_key = api_key
        self.connector_id = connector_id
        self.base_url = base_url
        self.framework = framework
        self.pii_redact = pii_redact
        self.exclude_fields = list(exclude_fields)
        self.buffer = EventBuffer(max_events=max_buffer_events)
        self.dlq = dlq
        self.sender = Sender(
            buffer=self.buffer,
            api_key=api_key,
            connector_id=connector_id,
            base_url=base_url,
            sdk_version=SDK_VERSION,
            flush_interval_seconds=flush_interval_seconds,
            framework=framework,
            host_fingerprint=host_fingerprint,
            dlq=dlq,
        )
        # Track current run_id for ambient context lookups (used by @track + span()).
        self._current_run_id: Optional[str] = None
        self._current_run_lock = threading.Lock()

    def start(self) -> None:
        self.sender.start()

    def stop(self, *, timeout_seconds: float = 5.0) -> None:
        self.sender.stop(timeout=timeout_seconds)

    def set_current_run(self, run_id: Optional[str]) -> None:
        with self._current_run_lock:
            self._current_run_id = run_id

    def get_current_run(self) -> Optional[str]:
        with self._current_run_lock:
            return self._current_run_id


# ---------------------------------------------------------------------------
# Module-level singleton + lifecycle
# ---------------------------------------------------------------------------

_collector: Optional[Collector] = None
_lifecycle_lock = threading.Lock()


def init(
    *,
    api_key: Optional[str] = None,
    connector_id: Optional[str] = None,
    base_url: str = "https://dobby-ai.com",
    flush_interval_seconds: float = 10.0,
    max_buffer_events: int = 10_000,
    framework: Optional[str] = None,
    host_fingerprint: Optional[str] = None,
    pii_redact: bool = False,
    exclude_fields: Optional[list[str]] = None,
    dlq_path: Optional[Union[str, Path]] = None,
    dlq_enabled: bool = True,
    dlq_max_rows: int = 1000,
) -> Collector:
    """
    Initialize the SDK. Call once at agent startup.

    Falls back to env vars if args are omitted:
      DOBBY_API_KEY        → api_key
      DOBBY_CONNECTOR_ID   → connector_id
      DOBBY_BASE_URL       → base_url
      DOBBY_DLQ_PATH       → dlq_path
      DOBBY_DLQ_DISABLED=1 → dlq_enabled=False

    DLQ defaults to ON — pending batches survive crashes / network outages
    via a SQLite file at `~/.dobby-collector/dlq.sqlite`. Pass
    `dlq_enabled=False` (or set `DOBBY_DLQ_DISABLED=1`) to disable for
    short-lived processes or tests.

    Idempotent: subsequent calls return the existing instance without
    restarting the sender thread. Call `shutdown()` first if you need to
    re-init with different credentials.
    """
    global _collector

    with _lifecycle_lock:
        if _collector is not None:
            logger.debug("dobby_collector: init() called twice — returning existing instance")
            return _collector

        api_key = api_key or os.environ.get("DOBBY_API_KEY")
        connector_id = connector_id or os.environ.get("DOBBY_CONNECTOR_ID")
        base_url = os.environ.get("DOBBY_BASE_URL", base_url)

        if not api_key:
            raise ValueError(
                "dobby_collector.init: api_key is required "
                "(pass api_key=... or set DOBBY_API_KEY env var)"
            )
        if not connector_id:
            raise ValueError(
                "dobby_collector.init: connector_id is required "
                "(pass connector_id=... or set DOBBY_CONNECTOR_ID env var)"
            )

        # Resolve DLQ — env override wins over arg.
        if os.environ.get("DOBBY_DLQ_DISABLED") in ("1", "true", "TRUE", "yes"):
            dlq_enabled = False
        resolved_dlq_path: Optional[Path] = None
        if dlq_enabled:
            # Coerce a string arg to Path here too (Dlq.__init__ also coerces
            # defensively — belt + suspenders, keeps the type honest).
            resolved_dlq_path = (
                Path(dlq_path) if dlq_path else _default_dlq_path()
            )
        dlq = Dlq(path=resolved_dlq_path, max_rows=dlq_max_rows)

        _collector = Collector(
            api_key=api_key,
            connector_id=connector_id,
            base_url=base_url,
            flush_interval_seconds=flush_interval_seconds,
            max_buffer_events=max_buffer_events,
            framework=framework,
            host_fingerprint=host_fingerprint,
            pii_redact=pii_redact,
            exclude_fields=exclude_fields or [],
            dlq=dlq,
        )
        _collector.start()

        # Best-effort flush on Python interpreter exit.
        atexit.register(_atexit_flush)

        logger.info(
            "dobby_collector: initialized — connector=%s framework=%s flush=%.1fs",
            connector_id,
            framework,
            flush_interval_seconds,
        )
        return _collector


def shutdown(*, timeout_seconds: float = 5.0) -> None:
    """
    Drain buffer + stop sender thread. Call before process exit for clean shutdown.
    Idempotent — calling after a prior shutdown is a no-op.
    """
    global _collector

    with _lifecycle_lock:
        if _collector is None:
            return
        try:
            _collector.stop(timeout_seconds=timeout_seconds)
        finally:
            _collector = None


def get_collector() -> Optional[Collector]:
    """Return the active singleton, or None if not yet initialized."""
    return _collector


def _atexit_flush() -> None:
    """Auto-flush on interpreter exit — only fires if user didn't call shutdown()."""
    if _collector is not None:
        with contextlib.suppress(Exception):
            # atexit hooks must never raise — interpreter is already shutting down.
            shutdown(timeout_seconds=2.0)
