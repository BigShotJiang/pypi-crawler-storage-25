"""
Tests for DobbyAutoGenLogHandler — AutoGen auto-instrumentation.

AutoGen uses Python's stdlib logging for events (not callback-style),
so tests construct real AutoGen event classes + push them through the
handler via a LogRecord (the same path AutoGen uses internally).

Skipped automatically if autogen-core isn't installed.
"""
from __future__ import annotations

import logging

import pytest

# Skip whole module if autogen-core not installed
autogen_installed = True
try:
    from autogen_core.logging import (  # noqa: F401
        LLMCallEvent,
        LLMStreamEndEvent,
        LLMStreamStartEvent,
        MessageDroppedEvent,
        MessageEvent,
        ToolCallEvent,
    )
except ImportError:
    autogen_installed = False

pytestmark = pytest.mark.skipif(
    not autogen_installed, reason="autogen-core not installed (optional integration dep)"
)


@pytest.fixture
def captured_events(monkeypatch):
    """Patch SDK's _emit to capture SdkEvents into a list instead of sending."""
    captured = []

    def fake_emit(event):
        captured.append(event)

    import dobby_collector.integrations.autogen as autogen_mod

    monkeypatch.setattr(autogen_mod, "_emit", fake_emit)
    return captured


@pytest.fixture
def handler(captured_events):
    """Handler instance (depends on captured_events so monkeypatch is wired)."""
    from dobby_collector.integrations.autogen import DobbyAutoGenLogHandler

    return DobbyAutoGenLogHandler()


def _push(handler, event):
    """Push an AutoGen event through the handler the same way logging would."""
    record = logging.LogRecord(
        name="autogen_core.events",
        level=logging.INFO,
        pathname=__file__,
        lineno=0,
        msg=event,
        args=None,
        exc_info=None,
    )
    handler.emit(record)


# ---------------------------------------------------------------------------
# LLM call (after-the-fact event — single .end emission)
# ---------------------------------------------------------------------------


class TestLLMCallEvent:
    def test_emits_llm_end_with_messages_and_response(
        self, handler, captured_events
    ):
        event = LLMCallEvent(
            messages=[{"role": "user", "content": "hi"}],
            response={"content": "hello back"},
            prompt_tokens=5,
            completion_tokens=3,
        )
        _push(handler, event)

        assert len(captured_events) == 1
        e = captured_events[0]
        assert e.type == "llm.end"
        assert e.status == "success"
        assert e.framework == "autogen"
        assert e.data["messages"] == [{"role": "user", "content": "hi"}]
        assert e.data["response"] == {"content": "hello back"}
        assert e.data["prompt_tokens"] == 5
        assert e.data["completion_tokens"] == 3


# ---------------------------------------------------------------------------
# LLM streaming (start/end pairing)
# ---------------------------------------------------------------------------


class TestLLMStreamPairing:
    def test_stream_start_then_end_pairs_via_parent_event_id(
        self, handler, captured_events
    ):
        start = LLMStreamStartEvent(
            messages=[{"role": "user", "content": "x"}],
        )
        _push(handler, start)

        end = LLMStreamEndEvent(
            response={"content": "streamed answer"},
            prompt_tokens=10,
            completion_tokens=7,
        )
        _push(handler, end)

        assert len(captured_events) == 2
        start_emitted, end_emitted = captured_events
        assert start_emitted.type == "llm.stream_start"
        assert end_emitted.type == "llm.stream_end"
        # End event references start via parent_event_id
        assert end_emitted.parent_event_id == start_emitted.event_id
        assert end_emitted.duration_ms is not None
        assert end_emitted.data["completion_tokens"] == 7


# ---------------------------------------------------------------------------
# Tool call (after-the-fact event)
# ---------------------------------------------------------------------------


class TestToolCallEvent:
    def test_success_emits_tool_end(self, handler, captured_events):
        event = ToolCallEvent(
            tool_name="search_db",
            arguments={"q": "AI safety"},
            result={"rows": 5},
        )
        _push(handler, event)

        assert len(captured_events) == 1
        e = captured_events[0]
        assert e.type == "tool.end"
        assert e.status == "success"
        assert e.name == "search_db"
        assert e.data["tool_name"] == "search_db"
        assert e.data["arguments"] == {"q": "AI safety"}
        assert e.data["result"] == {"rows": 5}

    def test_is_error_flag_routes_to_tool_error(self, handler, captured_events):
        event = ToolCallEvent(
            tool_name="search_db",
            arguments={"q": "x"},
            result={"is_error": True, "message": "timeout"},
        )
        _push(handler, event)

        e = captured_events[0]
        assert e.type == "tool.error"
        assert e.status == "error"


# ---------------------------------------------------------------------------
# Message dispatch
# ---------------------------------------------------------------------------


class TestMessageEvent:
    def test_message_emits_agent_message(self, handler, captured_events):
        from autogen_core import AgentId

        event = MessageEvent(
            payload={"text": "hello"},
            sender=AgentId(type="a", key="1"),
            receiver=AgentId(type="b", key="2"),
            kind="DIRECT",
            delivery_stage="SEND",
        )
        _push(handler, event)

        e = captured_events[0]
        assert e.type == "agent.message"
        assert e.name == "agent_message"
        assert e.data["payload"] == {"text": "hello"}
        # AgentId stringified
        assert e.data["sender"] is not None
        assert e.data["receiver"] is not None

    def test_dropped_emits_with_status_error(self, handler, captured_events):
        from autogen_core import AgentId

        event = MessageDroppedEvent(
            payload={"text": "x"},
            sender=AgentId(type="a", key="1"),
            receiver=AgentId(type="b", key="2"),
            kind="DIRECT",
            delivery_stage="DROPPED",
            reason="receiver_unreachable",
        )
        _push(handler, event)

        e = captured_events[0]
        assert e.type == "agent.message"
        assert e.name == "agent_message_dropped"
        assert e.status == "error"
        assert e.data["reason"] == "receiver_unreachable"


# ---------------------------------------------------------------------------
# Payload truncation
# ---------------------------------------------------------------------------


class TestTruncation:
    def test_long_messages_get_truncated(self, captured_events):
        from dobby_collector.integrations.autogen import DobbyAutoGenLogHandler

        handler = DobbyAutoGenLogHandler(max_payload_chars=50)
        long_content = "x" * 500
        event = LLMCallEvent(
            messages=[{"role": "user", "content": long_content}],
            response={"content": "ok"},
            prompt_tokens=0,
            completion_tokens=0,
        )
        _push(handler, event)

        e = captured_events[0]
        truncated = e.data["messages"][0]["content"]
        assert truncated.endswith("...[truncated]")
        assert len(truncated) <= 50 + len("...[truncated]")


# ---------------------------------------------------------------------------
# Error swallowing — handler MUST never raise into customer code
# ---------------------------------------------------------------------------


class TestErrorSwallowing:
    def test_handler_swallows_emit_errors(self, handler, monkeypatch):
        import dobby_collector.integrations.autogen as autogen_mod

        def raising_emit(event):
            raise RuntimeError("buffer full")

        monkeypatch.setattr(autogen_mod, "_emit", raising_emit)

        event = LLMCallEvent(
            messages=[],
            response={"content": ""},
            prompt_tokens=0,
            completion_tokens=0,
        )
        # Must NOT raise — handler must catch ALL emit errors
        _push(handler, event)

    def test_handler_ignores_unknown_event_types(self, handler, captured_events):
        """Forward-compat: future AutoGen event types we don't recognize are skipped."""

        class UnknownEvent:
            pass

        _push(handler, UnknownEvent())

        # No emission, no exception
        assert len(captured_events) == 0

    def test_handler_handles_none_msg(self, handler, captured_events):
        record = logging.LogRecord(
            name="autogen_core.events",
            level=logging.INFO,
            pathname=__file__,
            lineno=0,
            msg=None,
            args=None,
            exc_info=None,
        )
        # Must NOT raise
        handler.emit(record)
        assert len(captured_events) == 0


# ---------------------------------------------------------------------------
# logging.Handler wiring
# ---------------------------------------------------------------------------


class TestLoggingIntegration:
    def test_attaches_to_event_logger_and_receives_events(
        self, captured_events
    ):
        """End-to-end: attach handler to EVENT_LOGGER_NAME + log an event."""
        from autogen_core import EVENT_LOGGER_NAME

        from dobby_collector.integrations.autogen import DobbyAutoGenLogHandler

        autogen_logger = logging.getLogger(EVENT_LOGGER_NAME)
        handler = DobbyAutoGenLogHandler()
        autogen_logger.addHandler(handler)
        autogen_logger.setLevel(logging.DEBUG)

        try:
            event = LLMCallEvent(
                messages=[{"role": "user", "content": "hi"}],
                response={"content": "ok"},
                prompt_tokens=1,
                completion_tokens=1,
            )
            autogen_logger.info(event)

            assert len(captured_events) == 1
            assert captured_events[0].type == "llm.end"
        finally:
            autogen_logger.removeHandler(handler)

    def test_default_handler_level_is_debug(self, handler):
        """Sees every event, even debug-level ones."""
        assert handler.level == logging.DEBUG

    def test_custom_framework_tag_propagates(self, captured_events):
        from dobby_collector.integrations.autogen import DobbyAutoGenLogHandler

        handler = DobbyAutoGenLogHandler(framework="autogen-microsoft")
        event = LLMCallEvent(
            messages=[],
            response={"content": ""},
            prompt_tokens=0,
            completion_tokens=0,
        )
        _push(handler, event)

        assert captured_events[0].framework == "autogen-microsoft"
