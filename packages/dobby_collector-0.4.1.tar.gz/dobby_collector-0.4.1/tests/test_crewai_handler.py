"""
Tests for DobbyCrewAIHandler — CrewAI auto-instrumentation.

Mirrors test_langchain_handler.py shape: tests call handler methods DIRECTLY
with stub event objects (SimpleNamespace), avoiding CrewAI's pydantic
schema headaches. Patches _emit to capture SdkEvents into a list.

Skipped automatically if crewai isn't installed (sentry-style optional dep).
Registration test (which DOES need real event classes) is gated separately.
"""
from __future__ import annotations

from types import SimpleNamespace
from typing import Any
from uuid import uuid4

import pytest

# Skip whole module if crewai not installed (avoids forcing crewai on every dev)
crewai_installed = True
try:
    import crewai  # noqa: F401
except ImportError:
    crewai_installed = False

pytestmark = pytest.mark.skipif(
    not crewai_installed, reason="crewai not installed (optional integration dep)"
)


@pytest.fixture
def captured_events(monkeypatch):
    """Patch the SDK's _emit to capture events into a list instead of sending."""
    captured = []

    def fake_emit(event):
        captured.append(event)

    import dobby_collector.integrations.crewai as crewai_mod

    monkeypatch.setattr(crewai_mod, "_emit", fake_emit)
    return captured


@pytest.fixture
def isolated_bus():
    """Fresh CrewAIEventsBus per test — avoids cross-test handler leak."""
    from crewai.events.event_bus import CrewAIEventsBus

    return CrewAIEventsBus()


@pytest.fixture
def handler(isolated_bus, captured_events):
    """Handler wired to isolated bus; depends on captured_events so the
    monkeypatch is installed BEFORE the handler is constructed."""
    from dobby_collector.integrations.crewai import DobbyCrewAIHandler

    return DobbyCrewAIHandler(auto_run=False, event_bus=isolated_bus)


def _stub_event(**fields: Any) -> Any:
    """Build a stub event with `event_id` auto-generated + any custom fields."""
    fields.setdefault("event_id", str(uuid4()))
    fields.setdefault("parent_event_id", None)
    return SimpleNamespace(**fields)


# ---------------------------------------------------------------------------
# Registration (uses real CrewAI event classes — only test that needs them)
# ---------------------------------------------------------------------------


class TestRegistration:
    def test_handler_registers_for_all_event_types(self, handler, isolated_bus):
        """All 14 events we wire up should have ≥1 handler after init."""
        from crewai.events.types.agent_events import (
            AgentExecutionCompletedEvent,
            AgentExecutionStartedEvent,
        )
        from crewai.events.types.crew_events import (
            CrewKickoffCompletedEvent,
            CrewKickoffFailedEvent,
            CrewKickoffStartedEvent,
        )
        from crewai.events.types.llm_events import (
            LLMCallCompletedEvent,
            LLMCallFailedEvent,
            LLMCallStartedEvent,
        )
        from crewai.events.types.task_events import (
            TaskCompletedEvent,
            TaskFailedEvent,
            TaskStartedEvent,
        )
        from crewai.events.types.tool_usage_events import (
            ToolUsageErrorEvent,
            ToolUsageFinishedEvent,
            ToolUsageStartedEvent,
        )

        expected = [
            CrewKickoffStartedEvent, CrewKickoffCompletedEvent, CrewKickoffFailedEvent,
            TaskStartedEvent, TaskCompletedEvent, TaskFailedEvent,
            AgentExecutionStartedEvent, AgentExecutionCompletedEvent,
            LLMCallStartedEvent, LLMCallCompletedEvent, LLMCallFailedEvent,
            ToolUsageStartedEvent, ToolUsageFinishedEvent, ToolUsageErrorEvent,
        ]
        for cls in expected:
            handlers = isolated_bus._sync_handlers.get(cls, [])
            assert len(handlers) >= 1, f"No handler registered for {cls.__name__}"


# ---------------------------------------------------------------------------
# Crew kickoff → workload_run
# ---------------------------------------------------------------------------


class TestCrewKickoff:
    def test_started_emits_run_started(self, handler, captured_events):
        event = _stub_event(
            crew_name="test_crew",
            inputs={"topic": "AI safety"},
        )
        handler._on_crew_started(source=None, event=event)

        assert len(captured_events) == 1
        emitted = captured_events[0]
        assert emitted.type == "run.started"
        assert emitted.name == "test_crew"
        assert emitted.framework == "crewai"
        assert emitted.data == {"inputs": {"topic": "AI safety"}}

    def test_started_falls_back_to_default_name_when_crew_name_missing(
        self, handler, captured_events
    ):
        event = _stub_event(crew_name=None, inputs=None)
        handler._on_crew_started(source=None, event=event)

        assert captured_events[0].name == "crewai_kickoff"

    def test_completed_emits_run_completed_with_status_success(
        self, handler, captured_events
    ):
        started = _stub_event(crew_name="t", inputs={})
        handler._on_crew_started(source=None, event=started)
        completed = _stub_event(event_id=started.event_id, output="final answer")
        handler._on_crew_completed(source=None, event=completed)

        assert len(captured_events) == 2
        assert captured_events[1].type == "run.completed"
        assert captured_events[1].status == "success"
        assert captured_events[1].data == {"outputs": "final answer"}
        # Paired with start time → duration computed
        assert captured_events[1].duration_ms is not None

    def test_failed_emits_run_failed_with_error_str(self, handler, captured_events):
        started = _stub_event(crew_name="t", inputs={})
        handler._on_crew_started(source=None, event=started)
        failed = _stub_event(event_id=started.event_id, error="upstream timeout")
        handler._on_crew_failed(source=None, event=failed)

        assert captured_events[1].type == "run.failed"
        assert captured_events[1].status == "error"
        assert captured_events[1].data["error"] == "upstream timeout"


# ---------------------------------------------------------------------------
# Task spans
# ---------------------------------------------------------------------------


class TestTaskSpans:
    def test_started_emits_span_started_with_task_name(
        self, handler, captured_events
    ):
        event = _stub_event(
            task_id="task_xyz",
            task_name="research_phase",
            agent_role="researcher",
        )
        handler._on_task_started(source=None, event=event)

        emitted = captured_events[0]
        assert emitted.type == "span.started"
        assert emitted.name == "research_phase"
        assert emitted.data["task_id"] == "task_xyz"
        assert emitted.data["agent_role"] == "researcher"

    def test_completed_pairs_via_event_id_with_duration(
        self, handler, captured_events
    ):
        started = _stub_event(task_id="task_xyz", task_name="t", agent_role="r")
        handler._on_task_started(source=None, event=started)
        completed = _stub_event(event_id=started.event_id, output="done")
        handler._on_task_completed(source=None, event=completed)

        assert captured_events[1].type == "span.completed"
        assert captured_events[1].status == "success"
        assert captured_events[1].duration_ms is not None


# ---------------------------------------------------------------------------
# Tool usage spans
# ---------------------------------------------------------------------------


class TestToolUsage:
    def test_started_emits_tool_start_with_name_and_args(
        self, handler, captured_events
    ):
        event = _stub_event(
            tool_name="search_web",
            tool_args={"query": "AI safety"},
            tool_class="SearchTool",
            agent_role="researcher",
        )
        handler._on_tool_started(source=None, event=event)

        emitted = captured_events[0]
        assert emitted.type == "tool.start"
        assert emitted.name == "search_web"
        assert emitted.data["tool_name"] == "search_web"
        assert emitted.data["tool_args"] == {"query": "AI safety"}
        assert emitted.data["tool_class"] == "SearchTool"

    def test_finished_emits_tool_end_with_output_and_status_success(
        self, handler, captured_events
    ):
        started = _stub_event(
            tool_name="search_web",
            tool_args={"q": "x"},
            tool_class="ST",
            agent_role="r",
        )
        handler._on_tool_started(source=None, event=started)
        finished = _stub_event(event_id=started.event_id, output="result snippet")
        handler._on_tool_finished(source=None, event=finished)

        end_event = captured_events[1]
        assert end_event.type == "tool.end"
        assert end_event.status == "success"
        assert end_event.data == {"output": "result snippet"}

    def test_error_emits_tool_error(self, handler, captured_events):
        started = _stub_event(
            tool_name="search_web",
            tool_args={},
            tool_class="ST",
            agent_role="r",
        )
        handler._on_tool_started(source=None, event=started)
        errored = _stub_event(
            event_id=started.event_id, error="timeout", tool_name="search_web"
        )
        handler._on_tool_error(source=None, event=errored)

        err_event = captured_events[1]
        assert err_event.type == "tool.error"
        assert err_event.status == "error"
        assert err_event.data["error"] == "timeout"


# ---------------------------------------------------------------------------
# LLM call spans
# ---------------------------------------------------------------------------


class TestLLMCall:
    def test_started_emits_llm_start_with_model_messages(
        self, handler, captured_events
    ):
        event = _stub_event(
            model="gpt-4o-mini",
            call_id="call_abc",
            messages=[{"role": "user", "content": "hello"}],
        )
        handler._on_llm_started(source=None, event=event)

        emitted = captured_events[0]
        assert emitted.type == "llm.start"
        assert emitted.name == "llm:gpt-4o-mini"
        assert emitted.data["model"] == "gpt-4o-mini"
        assert emitted.data["call_id"] == "call_abc"
        assert emitted.data["messages"] == [{"role": "user", "content": "hello"}]

    def test_completed_extracts_response_and_usage(self, handler, captured_events):
        started = _stub_event(model="gpt-4o-mini", call_id="c1", messages=[])
        handler._on_llm_started(source=None, event=started)
        completed = _stub_event(
            event_id=started.event_id,
            response="hi there",
            usage={"prompt_tokens": 10, "completion_tokens": 5},
        )
        handler._on_llm_completed(source=None, event=completed)

        end = captured_events[1]
        assert end.type == "llm.end"
        assert end.data["response"] == "hi there"
        assert end.data["usage"] == {"prompt_tokens": 10, "completion_tokens": 5}

    def test_failed_marks_status_error(self, handler, captured_events):
        started = _stub_event(model="gpt-4o-mini", call_id="c2", messages=[])
        handler._on_llm_started(source=None, event=started)
        failed = _stub_event(event_id=started.event_id, error="rate_limit")
        handler._on_llm_failed(source=None, event=failed)

        assert captured_events[1].type == "llm.error"
        assert captured_events[1].status == "error"


# ---------------------------------------------------------------------------
# Payload truncation
# ---------------------------------------------------------------------------


class TestPayloadTruncation:
    def test_long_string_input_gets_truncated(
        self, isolated_bus, captured_events
    ):
        from dobby_collector.integrations.crewai import DobbyCrewAIHandler

        handler = DobbyCrewAIHandler(
            auto_run=False, event_bus=isolated_bus, max_payload_chars=50
        )
        event = _stub_event(
            crew_name="t", inputs={"prompt": "x" * 500}
        )
        handler._on_crew_started(source=None, event=event)

        truncated = captured_events[0].data["inputs"]["prompt"]
        assert truncated.endswith("...[truncated]")
        # 50 chars + "...[truncated]" suffix
        assert len(truncated) <= 50 + len("...[truncated]")


# ---------------------------------------------------------------------------
# Error swallowing — handler MUST never raise into customer code
# ---------------------------------------------------------------------------


class TestErrorSwallowing:
    def test_handler_swallows_emit_errors(
        self, handler, monkeypatch
    ):
        import dobby_collector.integrations.crewai as crewai_mod

        def raising_emit(event):
            raise RuntimeError("buffer full")

        monkeypatch.setattr(crewai_mod, "_emit", raising_emit)
        event = _stub_event(crew_name="t", inputs={})

        # Must NOT raise — customer code should never see SDK errors
        handler._on_crew_started(source=None, event=event)


# ---------------------------------------------------------------------------
# Parent/child event id threading (start → tool → end pairing)
# ---------------------------------------------------------------------------


class TestEventIdThreading:
    def test_child_tool_uses_parent_crew_dobby_id(self, handler, captured_events):
        # Crew kickoff = parent
        crew_event = _stub_event(crew_name="t", inputs={})
        handler._on_crew_started(source=None, event=crew_event)
        crew_emitted = captured_events[0]

        # Tool call as child (parent_event_id points to crew event)
        tool_event = _stub_event(
            tool_name="t1", tool_args={}, tool_class="X", agent_role="r",
            parent_event_id=crew_event.event_id,
        )
        handler._on_tool_started(source=None, event=tool_event)
        tool_emitted = captured_events[1]

        # tool's parent_event_id should be the crew's Dobby event_id
        assert tool_emitted.parent_event_id == crew_emitted.event_id

    def test_end_event_uses_start_dobby_id_for_pairing(
        self, handler, captured_events
    ):
        """End events get parent_event_id = start's Dobby event_id (server pairing)."""
        started = _stub_event(tool_name="t", tool_args={}, tool_class="X", agent_role="r")
        handler._on_tool_started(source=None, event=started)
        start_dobby_id = captured_events[0].event_id

        finished = _stub_event(event_id=started.event_id, output="ok")
        handler._on_tool_finished(source=None, event=finished)

        # The end event's parent_event_id should equal the start event's Dobby id
        assert captured_events[1].parent_event_id == start_dobby_id


# ---------------------------------------------------------------------------
# Constructor defaults
# ---------------------------------------------------------------------------


class TestConstructorDefaults:
    def test_default_framework_is_crewai(self, handler, captured_events):
        event = _stub_event(crew_name="t", inputs={})
        handler._on_crew_started(source=None, event=event)
        assert captured_events[0].framework == "crewai"

    def test_custom_framework_tag_propagates(
        self, isolated_bus, captured_events
    ):
        from dobby_collector.integrations.crewai import DobbyCrewAIHandler

        handler = DobbyCrewAIHandler(
            auto_run=False, event_bus=isolated_bus, framework="crewai-custom"
        )
        event = _stub_event(crew_name="t", inputs={})
        handler._on_crew_started(source=None, event=event)

        assert captured_events[0].framework == "crewai-custom"
