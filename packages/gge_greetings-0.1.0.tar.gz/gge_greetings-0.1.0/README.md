# README

### Git repository 
https://gitlab.com/all51/greetings.git

### Workflow to modify package
Windows cmd (not powershell): 
```bash
git clone https://gitlab.com/all51/greetings.git
cd greetings 
python -m venv venv 
call win_activate.bat
pip install -e .
echo reeeaaaadyyy 
```

### Workflow just for testing
```bash
pip install -e .
python test/test_greetings.py
```


### Workflow to install via pip 
```bash
pip install git+https://gitlab.com/all51/greetings.git 
```