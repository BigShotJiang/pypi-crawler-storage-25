from setuptools import setup

setup(
    # Needed to silence warnings (and to be a worthwhile package)
    name='greetings',
    author='Gregor',
    packages=['greetings'],
    version='0.1',
    url='https://gitlab.com/all51/greetings.git',
    description='Gives you a nice greeting',
    install_requires=[]
    # We will also need a readme eventually (there will be a warning)
    # long_description=open('README.txt').read(),
)