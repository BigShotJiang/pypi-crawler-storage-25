adjectives = """abenteuerlustig
achtsam
achtungswert
adrett
agil
akkurat
akribisch
aktiv
aktuell
allerbest
allerliebst
ambitioniert
amüsant
andächtig
andersartig
anerkannt
angenehm
animierend
anmutig
ansprechend
anspruchsvoll
anständig
anziehend
apart
aphrodisierend
arbeitsam
arbeitswütig
arkadisch
atemberaubend
athletisch
attraktiv
aufbauend
auffallend
auffällig
aufmerksam
aufmunternd
aufrecht
aufreizend
aufrichtig
aufsehenerregend
ausdrucksstark
auserlesen
auserwählt
ausgefallen
ausgeflippt
ausgeglichen
ausgelassen
ausgereift
ausgesucht
ausgewählt
ausgezeichnet
ausnahmslos
ausschlaggebend
außergewöhnlich
außerordentlich
auszeichnungswürdig
autark
authentisch
autonom
avantgardistisch
bahnbrechend
barmherzig
beachtenswert
beachtlich
beachtsam
bedacht
bedenkenlos
bedeutend
bedeutsam
beeindruckend
beeinflussend
beflügelnd
befreiend
begabt
begehrenswert
begehrt
begeisternd
begeistert
begeisterungsfähig
begierig
beglückend
begnügsam
behänd
beharrlich
beherrscht
beherzt
behutsam
beispielgebend
beispielhaft
beispiellos
bekannt
bekräftigend
belastbar
belebend
belebt
beliebt
bemerkenswert
bemüht
bequem
berauschend
berechenbar
berückend
berufen
beruhigt
berühmt
bescheiden
beschwingt
beseelt
besonders
besonnen
beständig
bestechend
bestimmt
bestmöglich
betriebsam
bevorzugt
bewährt
beweglich
bewundernswert
bewunderungswürdig
bewusst
bezaubernd
bildhübsch
bildlich
bildschön
bodenständig
bombig
brandaktuell
brandneu
brillant
brüderlich
bunt
charakterstark
charismatisch
charmant
cool
couragiert
dankbar
delikat
deliziös
detailliert
deutlich
dezent
dezidiert
diplomatisch
direkt
diszipliniert
divenhaft
dogmatisch
dominant
duftend
durchblickend
durchdacht
durchschlagend
durchsetzungsstark
durchtrieben
dynamisch
echt
edel
edelmütig
effektiv
effektvoll
effizient
ehrenhaft
ehrfürchtig
ehrgeizig
ehrlich
ehrwürdig
eifrig
eigen
eigenartig
eigenbestimmt
eigensinnig
eigenständig
eigenwillig
eindeutig
eindrucksvoll
einfach
einfallsreich
einfühlsam
einladend
einmalig
einnehmend
einsatzbereit
einsichtig
einträglich
einwandfrei
einzigartig
eitel
eklatant
ekstatisch
elanvoll
elegant
elementar
elitär
eloquent
elysisch
emotional
empathisch
empfehlenswert
empfindlich
empfindsam
empfindungsvoll
emsig
energiegeladen
energievoll
energisch
engagiert
engelsgleich
enigmatisch
enorm
entdeckungsfreudig
entgegenkommend
enthusiastisch
entscheidungsfreudig
entschlossen
entschlussfreudig
entspannt
entzückend
epochemachend
erbaulich
erfahren
erfinderisch
erfolgreich
erfolgsorientiert
erfolgssicher
erfreulich
erfrischend
ergebnisorientiert
ergebnisreich
ergiebig
erhaben
erhebend
erhellend
erlebnisreich
erlesen
ernst
ernsthaft
erotisch
erprobt
erregend
erstaunlich
erstklassig
erstmalig
erstrangig
erstrebenswert
erträglich
erwünscht
etabliert
euphorisch
exakt
exemplarisch
exklusiv
experimentierfreudig
explosiv
exquisit
extravagant
extravertiert
exzellent
exzentrisch
exzessiv
fabelhaft
facettenreich
fachgerecht
fachkundig
fair
faktenreich
familiär
famosfacettenreich
fantasiereich
fantasievoll
fantastisch
farbenfroh
faszinierend
fehlerfrei
feierlich
fein
feinfühlig
feinsinnig
fesch
fesselnd
festlich
festlich
feurig
fidel
fit
fleißig
flexibel
flink
flott
fokussiert
formidabel
forsch
fortschrittlich
frech
frei
freidenkend
freigiebig
freiheitsliebend
freimütig
freizügig
fresh
freudig
freudvoll
freundlich
friedfertig
friedlich
friedselig
friedvoll
frisch
froh
fröhlich
frohsinnig
fruchtbar
fruchtsam
führend
fulminant
fundamental
fundiert
funkelnd
furchtlos
furios
fürsorglich
galant
garantiert
gastfreundlich
geachtet
gebildet
geborgen
gediegen
geduldig
geehrt
geerdet
gefeiert
gefühlsbetont
gefühlvoll
geheimnisvoll
gehoben
geistreich
gelassen
gelungen
gemütlich
gemütvoll
genau
generös
genial
genießbar
genießerisch
genügsam
genüsslich
gepflegt
geradlinig
gerecht
geschäftig
geschätzt
geschickt
geschmeidig
gesellig
gesetzt
gesichert
gespannt
gesprächig
gestanden
getrost
geübt
gewaltig
gewichtig
gewieft
gewinnend
gewissenhaft
gewitzt
gewünscht
gigantisch
glamourös
glänzend
glaubensstark
glaubwürdig
glorreich
glücklich
gnädig
gönnerhaft
grandios
gravierend
grazil
grenzenlos
groß
großartig
großherzig
großmütig
großzügig
grundlegend
gründlich
grundsätzlich
grundsolide
günstig
gut
gutherzig
gütig
gutmütig
harmonisch
hartnäckig
heilsam
heiß
heißblütig
heiter
heldenhaft
heldenmütig
hell
hellhörig
hemmungslos
herausfordernd
herausragend
heroisch
herrlich
hervorhebend
hervorragend
hervorstechend
herzensgut
herzerfrischend
herzlich
hilfreich
hilfsbereit
himmlisch
hingebungsvoll
hinreißend
hintergründig
hochanständig
hochehrenhaft
hochgeschätzt
hochgradig
hochinteressant
hochkarätig
hochmodern
hochmotiviert
hochmütig
hochrangig
hochwertig
hochwirksam
hoffnungsvoll
höflich
hübsch
hüllenlos
humorvoll
ideal
idealistisch
ideenreich
idyllisch
imagefördernd
imponierend
imposant
individuell
influent
informativ
inhaltsreich
initial
initiativ
innovativ
inspirierend
instinktiv
integer
intellektuell
intelligent
intensiv
interessiert
intuitiv
irre
jovial
jugendlich
kämpferisch
keck
kennerisch
kenntnisreich
klar
klasse
klug
knallig
knuffig
kokett
kollegial
kolossal
komfortabel
kommunikationsfähig
kommunikativ
kompetent
kompetitiv
kompromissbereit
königlich
konkret
konkurrenzlos
konsequent
konsistent
konstant
konstitutiv
konstruktiv
kontrolliert
konventionell
konzentriert
konziliant
kooperativ
kordial
korrekt
kostbar
köstlich
kräftig
kraftvoll
kreativ
krisenfest
kühn
kulant
kultiviert
kundig
künstlerisch
kunstvoll
kurios
lässig
laut
lebendig
lebensbejahend
lebensfroh
lebenslustig
lebensnah
lebhaft
leger
lehrreich
leicht
leichtfüssig
leidenschaftlich
leistungsbereit
leistungsfähig
leistungsorientiert
leistungsstark
lernbereit
leuchtend
leutselig
liberal
lieb
liebenswert
liebenswürdig
liebevoll
liebreizend
lobenswert
locker
logisch
lohnenswert
lösungsorientiert
loyal
lukrativ
lüstern
lustig
lustvoll
luxuriös
mächtig
magisch
majestätisch
makellos
malerisch
märchenhaft
markant
marktgerecht
maßgeblich
maßgeschneidert
massiv
maximal
meinungsstark
meisterhaft
meisterlich
menschlich
methodisch
mild
mitfühlend
mitreißend
mobil
modebewusst
modern
modisch
mondän
monströs
monumental
motiviert
mühelos
munter
mustergültig
musterhaft
mutig
mysteriös
mystisch
nachdrücklich
nachhaltig
nachweislich
narrensicher
natürlich
nett
neu
neugierig
niedlich
niveauvoll
nobel
notorisch
nuanciert
nüchtern
nutzbringend
nützlich
objektiv
obligatorisch
offen
offenherzig
offensiv
olympisch
optimal
optimistisch
ordentlich
organisiert
originell
packend
paradiesisch
partnerschaftlich
passioniert
penibel
perfekt
persönlich
pfiffig
pflichtbewusst
phänomenal
phantasievoll
phantastisch
pietätvoll
pikant
pittoresk
plausibel
poetisch
pompös
populär
positiv
potent
prächtig
prachtvoll
pragmatisch
prägnant
praktikabel
praktisch
prall
präzise
prestigefördernd
prestigeträchtig
prestigevoll
prinzipientreu
proaktiv
probat
problemlos
produktiv
professionell
profiliert
profitabel
progressiv
prominent
prophetisch
protektiv
prunkvoll
pünktlich
putzig
qualifiziert
qualitativ
qualitätsvoll
querdenkend
quicklebendig
quirlig
raffiniert
rasant
rational
raumfüllend
real
realistisch
rechtschaffend
redselig
reell
reflektiert
rege
regsam
reich
reif
rein
reizend
reizvoll
rekordverdächtig
relevant
renommiert
renommiert
rentabel
resilient
resistent
resolut
respektabel
respektiert
respektvoll
revolutionär
richtungsgebend
richtungsweisend
riesig
rigoros
risikobereit
riskant
ritterlich
robust
romantisch
rotzig
routiniert
rücksichtsvoll
ruhevoll
ruhig
sachgemäß
sachgerecht
sachkundig
sachlich
sachverständig
sagenhaft
sanft
sanftmütig
sanguinisch
sauber
scharf
schillernd
schlagfertig
schlau
schnell
schön
schöpferisch
schwungvoll
selbständig
selbstbestimmt
selbstbewusst
selbstlos
selbstsicher
selbstständig
selten
sensationell
sensibel
sensitiv
seriös
sexuell
sexy
sicher
sicherheitsorientiert
siegreich
signifikant
simpel
sinnlich
skandalös
smart
solidarisch
solide
sonnig
sorgenfrei
sorgfältig
sorgsam
souverän
sozial
sozialverträglich
spannend
sparsam
spaßig
spektakulär
speziell
spielerisch
spitze
spontan
sportlich
sprachlos
spritzig
spürbar
stabil
standhaft
stark
stattlich
stichfest
stilbewusst
stilsicher
stilvoll
stimmig
stimmungsvoll
stoisch
stolz
strahlend
strategisch
strebsam
streng
strikt
strukturiert
stürmisch
substanziell
substanzreich
sündig
süß
sympathisch
tadellos
taff
taktvoll
talentiert
tapfer
tatkräftig
tauglich
temperamentvoll
teuer
tief
tiefgründig
tolerant
tonangebend
tough
traditionell
transparent
transzendent
träumerisch
traumhaft
treffend
treffsicher
treu
treuherzig
tüchtig
tugendhaft
tugendhaft
überdurchschnittlich
übergenau
überlegen
überlegt
überragend
überraschend
übersichtlich
übersinnlich
überwältigend
überzeugend
ultimativ
umfassend
umgänglich
umjubelt
umschwärmt
umsichtig
umtriebig
umwerfend
unabhängig
unangreifbar
unantastbar
unaufhaltsam
unbändig
unbeeinflussbar
unbefangen
unbeirrbar
unbekümmert
unbeschreiblich
unbeschwert
unbesehen
unbesorgt
unbestechlich
unbestritten
unbezahlbar
uneigennützig
unerbittlich
unerreichbar
unerschöpflich
unersetzlich
unfassbar
ungewöhnlich
ungezwungen
unglaublich
unkompliziert
unkonventionell
unnachahmlich
unnachgiebig
unproblematisch
unschlagbar
unsterblich
unterhaltsam
unternehmungsfreudig
unternehmungslustig
unterstützend
unübersehbar
unübertroffen
unverfälscht
unvergesslich
unvergleichbar
unverkennbar
unverletzbar
unverwechselbar
unverwundbar
unverzichtbar
unvoreingenommen
unvorstellbar
unwiderstehlich
verantwortungsbewusst
verantwortungsvoll
verbindend
verbindlich
verblüffend
verbreitet
verbrieft
verbürgt
verdient
verehrt
verführerisch
vergebend
verklärt
verlässlich
verlockend
vermittelnd
vernetzend
vernünftig
versiert
versöhnlich
verspielt
verständnisvoll
verträglich
vertrauensvoll
vertrauenswürdig
verträumt
verwegen
verwöhnt
verwundert
vielfältig
vielschichtig
vielseitig
visionär
vital
vollkommen
vorausschauend
vorbehaltlos
vorbildhaft
vorbildlich
vornehm
vorsorglich
vorteilhaft
vortrefflich
vorurteilsfrei
vorwitzig
vorzeigenswert
vorzüglich
wachsam
wagemutig
wählerisch
wahrhaftig
wahrheitsliebend
wandelbar
warm
warmherzig
weich
weise
weitblickend
weitsichtig
weltbekannt
weltgewandt
weltoffen
wendig
wertschätzend
wertvoll
wesentlich
wichtig
wichtig
widerstandsfähig
wieselflink
wild
willensstark
willkommen
wirksam
wissbegierig
wissenschaftlich
wissenshungrig
witzig
wohlerzogen
wohlgesinnt
wohlklingend
wohlriechend
wohlschmeckend
wohltuend
wohlüberlegt
wohlverdient
wohlwollend
wortgewandt
wunderbar
wunderhübsch
wunderlich
wunderschön
wundervoll
wünschenswert
würdevoll
xenophil
zäh
zart
zartbesaitet
zartfühlend
zärtlich
zauberhaft
zeitlos
zielbewusst
zielführend
zielgerichtet
zielorientiert
zielsicher
zielstrebig
zugeneigt
zukunftsorientiert
zündend
zupackend
zurechnungsfähig
zurückhaltend
zuständig
zuverlässig
zuversichtlich
zuvorkommend"""

animals = """
Aal
Aalmutter
Aalrutte
Aaskäfer
Aberdeenrind
Abraxas
Abtrittsfliege
Abtrittsmücke
Achatschnecke
Ackerhummel
Ackermaus
Ackerschnecke
Addax
Addax
Adeliepinguin
Adiak
Adjutant
Adler
Adlerbussard
Adlerechse
Adlerfisch
Adlerfrerattvogel
Adlerrochen
Admiral
Adria-Eidechse
Aeneasratte
Ährenfisch
Ährenmaus
Ährenträgerpfau
Äsche
Äskulapnatter
Affe
Affendler
Affenpinscher
Afterrüssler
Afterskorpion
Agassiz’ Zwergbuntbarsch
Agrion
Aguarachay
Agujaadler
Aguti
Ai
Ailanthusspinner
Aitel
Akalima
Akialoa
Aktäonkäfer
Akumba
Aland
Alandbleke
Alaskabär
Albatros
Alectis
Alektoweber
Alet
Alfonsino
Alligator
Alligatorhai
Alligatorsalamander
Almiqui
Almizilero
Alpaka
Alpenbär
Alpenbock
Alpenbraunelle
Alpendohle
Alpenfledermaus
Alpenkrähe
Alpenmauerläufer
Alpenmurmeltier
Alpenpfeifhase
Alpensalamander
Alpenschneehase
Alpenschneehuhn
Alpensegler
Alpenspitzmaus
Alpensteinbock
Alpenstrandläufer
Alpenwolf
Alpenwühlmaus
Amadine
Amazonenameise
Ameise
Ameisenbär
Ameisenbeutler
Ameisenigel
Ameisenjungfern
Ameisenlöwe
Ameisenvogel
Ameisewespe
Amerikanischer Cocker Spaniel
Amethiystschlange
Amherstfasan
Amöbe
Amsel
Anakonda
Anconschaf
Anchovis
Ancylus
Andenbär
Andenhirsch
Anemonenfisch
Angler
Angolahase
Angorakaninchen
Angoraziege
Ani
Anoa
Anopheles
Ansauger
Anthus
Antilope
Anubis-Pavian
Apatura
Apella
Apfelblattlaus
Apfelblattsauger
Apfelwickler
Apollofalter
Ara
Arakanga
Arapaima
Arawana
Archaeopteryx
Argali
Argentinischer Stummelfuß
Argonauta
Argusfasan
Arizonasaurus
Arpiranga-Salmler
Aristoteles-Hai
Aristoteles-Hirsch
Arkal
Ammolch
Arni
Aronstab-Frosch
Aruliusbarbe
Aschenhund
Aschkoko
Asinus
Aspis
Aspisviper
Assala
Assapan
Assel
Asselspinne
Asselspinner
Astacus
Atlasfink
Atlaslaubenvogel
Atun
Auerhuhn
Auerochse
Augenfalter
Augenfleckbuntbarsch
Augenfleckbuntbutte
Augengrubennatter
Augenpfeiffer
Augenringwaldsänger
Augenspinner
Aurorafalter
Auster
Austerfisch
Austernfischer
Australienkrokodil
Axishirsch
Axolotl
Aye-Aye
Ayu
Azarafuchs
Babakoto
Babirussa
Bache
Bachforelle
Bachläufer
Bachneunauge
Bachröhrenwurm
Bachsaibling
Bachsalamander
Bachstelze
Badger
Badul
Bänderkänguru
Bändersandnatter
Bäumchenröhrenwurm
Baikalrobbe
Baira
Balirind
Balkannatter
Balkenschröter
Ballschlange
Baltimoretrupial
Bambusbär
Bambusfingerratte
Bambusgeist
Bananenfrosch
Bananenlaubfrosch
Bandfink
Bandiltis
Bandmaus
Bandmolch
Bandnatter
Bandro
Bandrobbe
Bandwurm
Bankivahuhn
Banteng
Bär
Barasingha
Barbastella
Bärbling
Barch
Bärenbeutler
Bärenkänguru
Bärenmakak
Bärenmaki
Bärenpavian
Bärenspinner
Baribal
Barrakuda
Barramuda
Barrenringelnatter
Barrigudo
Barsch
Bartaffe
Bart-Agame
Bartfledermaus
Bartkauz
Bartmeise
Bartrobbe
Bartsaki
Bartschwein
Basset
Baßtölpel
Bastardmakrele
Bastardschildkröte
Batagurschildkröte
Batakpony
Bauin
Baumameisenfresser
Baumfalke
Baumfrosch
Baumkänguru
Baumläuferwaldsänger
Baumleguane
Baummarder
Baumpieper
Baumsalamander
Baumschläfer
Baumschlange
Baumschneke
Baumschnüffler
Baumsegler
Baumstachelschwein
Baumtiger
Baumweißling
Baumwollratte
Baumwollschwanzkaninchen
Bechsteins Fledermaus
Beerenwnaze
Behra
Beilbauchfisch
Beilbauchsalmler
Beilfisch
Beisa
Belchen
Bellfrosch
Bellhirsch
Beluga
Bembix
Bengalfuchs
Bengalisches Stachelschwein
Bengalkatze
Bengaltiger
Bennets Baumkänguruh
Bennetkänguruh
Beo
Berberaffe
Berberkröte
Berberlöwe
Berbermaus
Berberskink
Bergamaskerschaf
Berg-Coati
Bergeidechse
Bergente
Bergfink
Berggorilla
Berhänfling
Bergilt
Bergkänguruh
Bergkatze
Berglandunke
Berglöwe
Bergmolch
Bergnasenbär
Bergnyala
Bergpaka
Bergpieper
Bergriedbock
Bergstachler
Bergtapir
Bergzebra
Bergziege
Bernhardiner
Bernsteinmakrele
Bettwanze
Beulenkrokodil
Beutelbär
Beutelbilch
Beuteldachs
Beutelflughörnchen
Beutelfrosch
Beutelfuchs
Beutelgilbmaus
Beutelhund
Beuteliltis
Beutelmarder
Beutelmaulwurf
Beutelmull
Beutelratte
Beuteteufel
Beutewolf
Bezoarziege
Bharal
Biber
Blauracke
Buberkäfer
Biberratte
Biberspitzmaus
Biene
Bienenelfe
Bienenfresser
Bienenkäfer
Bienenlaus
Bienenmilbe
Bienenwolf
Bighornschaf
Bilch
Bilchmaki
Bilharzia
Bindebeuteldachs
Bindenschwein
Bindenwaran
Binturong
Birgus
Birkenknopfhornwespe
Birkenmaus
Birkenspanner
Birkenspinner
Birkenstecher
Birkenzeisig
Birkfuchs
Birkhuhn
Birma-Hase
Birnensauger
Birngallmücke
Bisam
Bisamente
Bisamratte
Bisamschwein
Bischoffsaffe
Biskaya-Wal
Bison
Bitterling
Bitterlingsbarbe
Black-Molly
Bläßgans
Bläßhuhn
Bläuel
Blaumeise
Blainvilles Delphin
Blankaal
Blasenfrosch
Blasenkäfer
Blasenwurm
Blasser Kärpfling
Blaßfuchs
Blattfinger
Blattfisch
Blatthühnchen
Blattkäfer
Blattlaus
Blattlauslöwe
Blattnasenatter
Blattrippenstecher
Blattschmetterling
Blattschneiderameise
Blattschneiderbiene
Blattschwanzgecko
Blattsteigerfrosch
Blattwespe
Blaubandgrundel
Blaubandkärpling
Blaubandsalmler
Blaubarsch
Blaubock
Blauböckchen
Blaubull
Blaudrossel
Blauer Fadenfisch
Blaufelchen
Blaufisch
Blauflügelwaldsänger
Blaufuchs
Blauglanzhechtling
Blauhai
Blaukehlagame
Blaukehlchen
Blaukopf
Blaumaul-Meerkatze
Blaumeise
Blaumerle
Blaupunktbuntbarsch
Blaurake
Blaurücken
Blaurückenducker
Blaurückenwaldsänger
Blauschaf
Blauschwanz-Schlankskink
Blaustirnamazone
Blaustreifengrunzer
Blauwal
Blauwange
Blauzungenskink
Bleiböckchen
Bleirückensalamander
Bleßbock
Bleßgans
Bleßmull
Blikke
Blinddarmbilch
Blinde-Höhlenbarbe
Blinde Höhlengrundel
Blinder Höhlensalamander
Blinder Höhlenwels
Blinder Trugkärpfling
Blindmaulwurf
Blindmaus
Blindmolch
Blindschleiche
Blödauge
Blöker
Blumennase
Blumentopfschlange
Blutbock
Blutbrustpavian
Blutegel
Blutfasan
Bluthänfling
Bluthals
Blthund
Blutlaus
Blutpython
Blutsalmler
Blutsauger
Blutschnabelweber
Blutströpchen
Boa
Boaedon
Boa-Trugnatter
Bobak
Bobtail
Bock
Bockkäfer
Bodenkröte
Böhm-Zebra
Bogenfinger
Bohnenkäfer
Bohnenmuschel
Bohrschnecken
Bohrschwamm
Bohrwurm
Boleophthalmus
Bologneser-Hundchen
Bombardierkäfer
Bombay-Ente
Bombina
Bobus
Bonellia
Bongo
Bonito
Bonobo
Boomslang
Bordeaux-Dogge
Borkenkäfer
Borkenratte
Borkentier
Borneokatze
Borstenbaumstachler
Borstenferkel
Borstengürteltier
Borstenhörnchen
Borstenigel
Borstenkaninchen
Borstenmaul
Bothrops
Boxer
Brabantbuntbarsch
Brachkäfer
Brachschwalbe
Brachsen
Brachsensalmler
Brachschnepfe
Brachvogel
Brandgans
Brandmaus
Brandseeschwalbe
Brasse, Brassen
Bratpfannenwels
Brauen-Glattstirnkaiman
Braula
Braunbär
Braunbrustwaldsänger
Braune-Hyäne
Braunfisch
Braunkelchen
Braunkehlfrosch
Braunkopffaultier
Braunkopf-Kuhstärling
Braunrückentukan
Braunskink
Brautente
Brazza-Meerkatze
Breitflossenkärpfling
Breitmaulnashorn
Breitrandschildkröte
Breitschnauzen-Halbmaki
Breitschnauzenkaiman
Bremse
Brenner
Brieftaube
Brillantsalmler
Brillenbär
Brillenkänguruh
Brillenkaiman
Brillenpinguin
Brillenschlange
Brokatbarbe
Brolgakranich
Brombeerfalter
Brotkäfer
Bruchfisch
Bruchwasserläufer
Brückenechse
Brüllaffe
Brunnenmolch
Brydewal
Buansu
Bubo bubo
Buchdrucker
Buchengallmücke
Buchenspinner
Buchfink
Buchstabenfrosch
Buckelochse
Buckelwal
Budeng
Bücherlaus
Bücherskorpion
Bücherwurm
Büffel
Bülbül
Bündelnister
Bürstenschwanz-Rattenkänguruh
Büschelbraunenviper
Büschelkäfer
Büschelohr-Beisa
Bulldogameise
Bulldogge
Bullterrier
Bungerschlange
Buntbarsch
Buntbock
Buntkäfer
Buntmaus
Buntspecht
Buntwaran
Buntwühle
Burchell-Zebra
Burunduk
Buschbaby
Buschbock
Buschducker
Buschhuhn
Buschkatze
Buschmeister
Buschschliefer
Buschwaldgalago
Bussard
Butt
Butterfisch
Butterkrebs
Cacajao
Calandra
Cambarus
Campbell-Meerkatze
Cana-Fuchs
Cañon-Laubfrosch
Capparo
Capybara
Carassius
Carcinus
Cayenne-Ratte
Celebes-Schwein
Celebes-Segelfisch
Cerastes
Ceylonbarbe
Ceylon-Wühle
Chamäleon
Chanchito
Chapman-Zebra
Charsa
Cheetah
Cheiraxanthium
Chelifer
Chihuahua
Chilenischer Pudu
Chin
China-Alligator
Chinchillakaninchen
Chinchillaratte
Chinchilla
Chinesische Nachtigall
Chinesischer Hase
Chipmunk
Chitala
Chitala-Frosch
Chow-Chow
Chuckwalla
Cistensänger
Clownbarbe
Clownfisch
Coatimundi
Cobia
Cocker-Spaniel
Collie
Colobus
Colocolò
Coloradokäfer
Colpeo
Coluber
Connemara-Pony
Cornwallschwein
Coscoroba
Coyote
Cyclops
Daboia
Dachratte
Dachschildkröte
Dachs
Dachshund
Dackel
Dalmatiner
Dama-Gazelle
Damara-Dik-Dik
Damara-Zebra
Damhirsch
Dampfschiffente
Darwins Nandu
Dattelmuschel
Davidshirsch
Deerhound
Defassa-Wasserbock
Degenfisch
Degu
Delfin
Demidoff-Galago
Dendrolagus
Derby-Arassari
Derbywallaby
Desmognathus
Deutsch-Drahthaar
Deutsche-Dogge
Deutsch-Kurzhaar
Deutsch-Langhaar
Diadem-Meerkatze
Diadem-Natter
Diadem-Schildkröte
Diadem-Seeigel
Diadem-Sifaka
Diamantbarsche
Diamantfasan
Diamantklapperschlange
Diamantpiton
Diamantschildkröte
Diana-Meerkatze
Dickfinger
Dickhornschaf
Dickkopfkapuziner
Dickschnabelpinguin
Dickschwanzbeutelratte
Dickschwanz-Scorpion
Diebskäfer
Dingo
Dinosaurier
Dione-Natter
Diskusbuntbarsch
Diskussalmler
Distelfalter
Distelfink
dodo
Dosenschildkröte
Döbel
Dögling
Dogge
Doggenhai
Dohle
Doktorfisch
Dolchfrosch
Dolchstichtaube
Dompfaff
Donaulachs
Doppelbindenarassari
Doppelhornvogel
Doppelschnepfe
Dorkasgazelle
Dorneidechse
Dornfingerspinne
Dorngrasmücke
Dornhai
Dornroche
Dornschwanzbilch
Dornschwanzkink
Dornteufel
Dornzirpe
Dorsch
Dottertukan
Drachenfisch
Drachenflosser
Drahthaarterrier
Drehwurm
Dreibandsalmler
Dreibinden-Ziersalmler
Dreieckmuschel
Dreifingerfaultier
Dreihornchamäleon
Dreihornkäfer
Dreikantwurm
Dreikielschilkröte
Dreiklauer
Dreilinienbärbling
Dreipunkt-Korallenbarsch
Dreischwanzbarsch
Dreistreifenpalmenroller
Dreistreifensalmler
Dreizehefaultier
Dreizehespecht
Drill
Drohne
Dromedar
Drongos
Dronte
Drosophila
Drossel
Drosselrohrsänger
Drückerfisch
Drusenkopf
Dryas
Dschelada
Dschiggetai
Dschungelrind
Duckaffe
Dünengazelle
Dünnfingergeko
Dünnleib
Düsterbiene
Dukatenfalter
Dummkopfwal
Dungkäfer
Durukulis
Dybowskihirsch
Dytiscus
Eber
Echse
Edelfasan
Egel
Eichelhäher
Eichenspinner
Eichhörnchen
Eidechse
Eiderente
Einsiedlerkrebs
Eintagsfliege
Eisbär
Eisvogel
Elch
Elen
Elefant
Elritze
Elster
Emu
Engelhai
Engerling
Ente
Erdferkel
Erdmännchen
Erpel
Esel
Eselspinguin
Eule
Falkennachtschwalbe
Falter
Färberfrosch
Fasan
Faultier
Fechterschnecke
Feenseeschwalbe
Feldgrille
Feldhase
Feldmaus
Felsenpinguin
Feuersalamander
Fichtenwaldsänger
Fingertier
Fischadler
Fischbandwurm
Fischotter
Fischreiher
Flachlandgorilla
Flamingo
Fledermaus
Fliege
Floh
Florida-Waldkaninchen
Flugdrache
Flunder
Flussdelfin
Flusskrebs
Flusspferd
Forelle
Fossa
Frettchen
Frosch
Fruchtvampir
Fuchs
Fuchsbandwurm
Galagos
Geburtshelferkröte
Gämse
Gans
Gänsegeier
Gaur
Gazelle
Gecko
Gefleckter Kohltriebrüssler
Gefurchter Dickmaulrüssler
Geier
Gelbbrustwaldsänger
Gelbscheitelwaldsänger
Gelbstirnwaldsänger
Gemeine Feuerwanze
Gemeine Florfliege
Gemeine Wiesenwanze
Gemeiner Graurüssler
Gemeiner Holzbock
Gemeiner Nagekäfer
Gemse
Gepard
Gerfalke
Geringelte Mordwanze
Gibbon
Gimpel
Giraffe
Glanzvogel
Glasbarsch
Glattwal
Glockenvogel
Gnu
Goldfisch
Goldflügelwaldsänger
Goldlachs
Goldleiste
Goldmulle
Goldschnepfe
Goldschopfpinguin
Goldwaldsänger
Goldwangenwaldsänger
Goldzeisig
Gorilla
Gottesanbeterin
Grasfrosch
Grasmücke
Graubär
Graufuchs
Grauliest
Grauwal
Grevyzebra
Grizzlybär
Grille
Groppe
Großer Rapsstängelrüssler
Großnilhecht
Grottenolm
Grundel
Grüne Mamba
Grüne Stinkwanze
Grünfink
Grünrüssler
Grünwaldsänger
Guanako
Guppy
Gürtelmull
Gürteltier
Haarnasenwombat
Haarschopftaucher
Halsbanddrossel
Häherkuckuck
Hahn
Hai
Haldenwaldsänger
Halsbandsittich
Hammerhai
Hamster
Hängebauchschwein
Hase
Haselmaus
Haubentaucher
Hausmaus
Hausratte
Hausschwein
Hawaiigans
Heidelerche
Heilbutt
Helmturako
Henne
Herbstgrasmilbe
Hering
Heringshai
Hermelin
Heuschrecke
Hirsch
Hirschkäfer
Hoatzin
Hochlandrind
Höckerschwan
Holzbrüter
Holzwurm
Honigbiene
Hornfrosch
Hornisse
Hübschgesichtwallaby
Hufeisennase
Huhn
Hummelelfe
Hummer
Hund
Hundsfisch
Hyäne
Hyazinth-Ara
Igel
Igelfisch
Iltis
Imme
Impala
Inger
Insekt
Iris
Isabellabär
Ibis
Jaguar
Jak
Jack Russell Terrier
Jaguarundi
Japanmakake
Kabeljau
Katta
Kleinstein
Käfer
Kakerlake
Kamel
Kanadawaldsänger
Känguru
Kaninchen
Kapuzenwaldsänger
Karnickel
Karpfen
Kaschmirhirsch
Kaschmirziege
Kater
Katze
Kaulbarsch
Kaulquappe
Kegelrobbe
Kellerassel
Kentuckywaldsänger
Klapperschlange
Kliesche
Knoblauchkröte
Knochenhecht
Koala
Kodiakbär
Kolibri
Kommafalter
Komoren-Quastenflosser
Königspython
Kormoran
Kranich
Krähe
Kreuzkröte
Kreuzotter
Krokodil
Kronenadler
Kronwaldsänger
Kröte
Kugelfisch
Küchenschabe
Kuh
Lachmöwe
Lachsforelle
Lama
Lamm
Landschildkröte
Langschwanzchinchilla
Lar
Laubfrosch
Laubsänger
Laus
Lärmlederkopf
Lederschildkröte
Leguan
Lemming
Lemur
Leopard
Leopardgecko
Libelle
Liger
Lippenbär
Löwe
Luchs
Lurch
Farbmaus
Made
Madenhacker
Marder
Marderhund
Maus
Mädesüß-Perlmutterfalter
Mähnenwolf
Maikäfer
Magnolienwaldsänger
Makake
Maki
Makrele
Malaienbär
Malvenfalter
Manado-Quastenflosser
Mandarinente
Mandrill
Manta
Manteltier
Marabu
Marder
Marienkäfer
Marmelente
Marmorkatze
Märzente
Mastodon
Mauerläufer
Mauersegler
Maulesel
Maultier
Maulwurf
Mauritiusfalke
Maus
Mäusebussard
Meeresfisch
Meeresschildkröte
Meerestier
Meerkatze
Meerneunauge
Meerschwein
Meerschweinchen
Megalodon
Meise
Menschenfloh
Messingkäfer
Miesmuschel
Mistkäfer
Mieze
Miezekatze
Milan
Milbe
Minischwein
Misteldrossel
Mittelspecht
Moa
Molluske
Monarchfalter
Mönchswaldsänger
Mondfisch
Mondvogel
Moorente
Moorhuhn
Mops
Mosaikfadenfisch
Moschusochse
Motte
Möwe
Mungo
Mücke
Muli
Mull
Muräne
Murmeltier
Muschel
Mustang
Nachtigall
Nachtigall-Grashüpfer
Nackthund
Nacktkatze
Nachtfalter
Nacktmull
Nacktnasenwombat
Nacktschnecke
Nandu
Nasenaffe
Nasenbär
Nashorn
Natter
Nautilus
Nebelparder
Neunauge
Nilpferd
Nördlicher Pfeifhase
Nutria
Nymphensittich
Ochse
Ochsenauge (großes, kleines, rostbraunes; Schmetterling)
Ochsenfrosch
Octopus
Ohrenkneifer
Ohrenqualle
Okapi
Olm
Onager
Opossum
Orca
Orang-Utan
Orangefleckwaldsänger
Otter
Ozelot
Ölkäfer
Pampashase
Panda
Pangasius
Panther
Pantoffeltierchen
Papagei
Papageitaucher
Paradiesvogel
Pelikan
Pelikanaal
Perlsteißhuhn
Perserkatze
Peterfisch
Pfau
Pfauenauge
Pfauenaugenbutt
Pfeilgiftfrosch
Pferd
Pieperwaldsänger
Pillendreher
Pinguin
Polarbär
Polarfuchs
Polyp
Pottwal
Primat
Puma
Purpurbär
Purpurbock
Purpurkopfbarbe
Pute
Puter
Quagga
Qualle
Quastenflosser
Quokka
Rabe
Rabenkrähe
Ratte
Ratten-Lungenwurm
Raubfisch
Raubfuß-Bussard
Raubtier
Raubvogel
Raufußkauz
Rauhaardackel
Raupe
Rebhuhn
Reblaus
Regenbogenforelle
Regenpfeifer
Regenwurm
Reh
Rehbock
Rehböckchen
Rehkitz
Reiher
Reinwardt-Arassari
Ren
Rennmaus
Rennschwein
Rennvogel
Rentier
Reptil
Rhesusaffe
Rhinozeros
Riesenbastkäfer
Riesenhai
Riesenkrake
Riesenschildkröte
Riesentukan
Rind
Rinderbandwurm
Ringdrossel
Ringelgans
Ringelnatter
Ringeltaube
Robbe
Rochen
Rohrdommel
Rohrratte
Rohrweihe
Rosenköpfchen
Rosenwaldsänger
Rostscheitelwaldsänger
Rotbarsch
Rotbrasse
Rote Mordwanze
Roter Brüllaffe
Rotfuchs
Rothalsgans
Rothalstaucher
Rotkehlchen
Rotkropfarassari
Rotluchs
Rotmilan
Rotnackenarassari
Rotschwanz
Rotsteißarassari
Rotwangenschildkröte
Rotwild
Rotwolf
Rotzunge
Rubinfleckwaldsänger
Rubinkehlkolibri
Ruderfrosch
Sardelle
Säbelschnäbler
Säbelzahntiger
Sägefisch
Säger
Saibing
Salamander
Salangane
Salm
Salmler
Sandaal
Sanderling
Sandfloh
Sandlaufkäfer
Sandregenpfeifer
Sandwespe
Sardine
Sattelrobbe
Sau
Säuger
Säugetier
Schabe
Schabrackenschakal
Schachbrett
Schaf
Schakal
Scharbe
Scheidenschnabel
Schellfisch
Scheltopusik
Scherenschnabel
Scherflein
Schermaus
Schildkröte
Schildlaus
Schill
Schimmel
Schimpanse
Schäfer
Schlammläufer
Schlammpeitzger
Schlammteufel
Schlange
Schlangenweihe
Schlangernstern
Schlankschnabelbülbül
Schleiche
Schleie
Schleiereule
Schleimaal
Schleimfisch
Schliefer
Schlüsselschnecke
Schmerle
Schmetterling
Schmutzgeier
Schnabeligel
Schnabeltier
Schnake
Schnapper
Schnäpperwaldsänger
Schnecke
Schneeammer
Schnee-Eule
Schneefink
Schneefloh
Schneegans
Schneehöschen
Schneehuhn
Schneesperling
Schnegel
Schneider
Schnepfe
Schnirkelschnecke
Scholle
Schopfwachtel
Schriftarassari
Schuhschnabel
Schupp
Schuppentier
Schuster
Schützenfisch
Schwalbe
Schwalbenschwanz
Schwalm
Schwamm
Schwan
Schwanzmeise
Schwarzkehlarassari
Schwarzkopftukan
Schwarzschnabeltukan
Schwarzspecht
Schwarzstorch
Schwein
Schweinsaffe
Schweinsfisch
Schweinshai
Schweinswal
Schwertfisch
Schwertwal
Schwimmwühle
Seeaal
Seeadler
Seeanemone
Seeapfel
Seebär
Seebarbe
Seebarsch
Seebinkel
Seebrassen
Seebull
Seedattel
Seeelefant
Seefächer
Seefeder
Seegurke
Seehase
Seehecht
Seehund
Seeigel
Seekatze
Seekuh
Seelachs
Seelilie
Seelöwe
Seemannshand
Seemaus
Seenadel
Seenelke
Seeohr
Seeotter
Seepferdchen
Seerabe
Seeratte
Seeringelwurm
Seescheide
Seeschlange
Seeschmetterling
Seeschwalbe
Seeskorpion
Seespinne
Seestachelbeere
Seestern
Seetaucher
Seeteufel
Seevogel
Seewalze
Seewolf
Seezunge
Segelfalter
Segler
Seidenfadenfisch
Seidenschwanz
Seidenspinner
Sekretär
Sepia
Seychellenfalke
Shrimp
Sichelreiher
Siebenschläfer
Siamang
Sichler
Sichling
Sikahirsch
Silberfisch
Singvogel
Skalar
Skarabäus
Skink
Skorpion
Skunk
Sonnenbarsch
Sonnenstern
Spanner
Spatz
Specht
Sperber
Sperbereule
Sperling
Sperlingskauz
Spießer
Spinne
Spinnenläufer
Spinner
Spint
Spitzhörnchen
Spitzmaus
Spötter
Spottdrossel
Springaffe
Springbock
Spulwurm
Stachelmakrele
Stachelrochen
Stachelschwein
Star
Starfrosch
Stechfliege
Stechmücke
Stechrochen
Steinadler
Steinbeißer
Steinbock
Steinbutt
Steindohle
Steinfisch
Steinfliege
Steinforelle
Steingreßling
Steinhuhn
Steinkauz
Steinkoralle
Steinkrebs
Steinkriecher
Steinlachs
Steinläufer
Steinmarder
Steinpicker
Steinrötel
Steinschmätzer
Steinspatz
Steinsperling
Steinwälzer
Stelze
Stelzenläufer
Sterntaucher
Stichling
Stieglitz
Stier
Stinktier
Stint
Stockente
Stöcker
Stör
Storch
Strandelster
Strandfliege
Strandfloh
Strandläufer
Strandpieper
Strandschnecke
Strandwolf
Streber
Streifengrasmaus
Streifenhörnchen
Streifenschnabelarassari
Strömer
Stubenfliege
Sturmschwalbe
Sturmtaucher
Sturmvogel
Stute
Sumpfbiber
Sumpfdeckelschnecke
Sumpfhase
Sumpfhuhn
Sumpfläufer
Sumpfmaus
Sumpfmeise
Sumpfohreule
Sumpfschildkröte
Swainson-Tukan
Schwein
Tabakkäfer
Tagfalter
Tagpfauenauge
Tannenhäher
Tanrek
Tanuki
Tarantel
Taube
Tausendfüßer
Tausendfüßler
Tentakel-Schluckspecht
Thunfisch
Tieraffe
Tiger
Tigerwaldsänger
Timberwolf
Tintenfisch
Todis
Töle
Tölpel
Totengräber
Totenkopf
Totenkopfäffchen
Totenuhr
Trampeltier
Triel
Truthahn
Truthuhn
Tsetse-Fliege
Tsetsefliege
Tukan
Tundrawolf
Tüpfelhyäne
Turmfalke
Turteltaube
Tyrann
Uakari
Uferschnepfe
Uferschwalbe
Uhu
Unglückshäher
Unke
Ur
Urangutan
Urpferd
Urson
Vampirfisch
Veilchenente
Veilchenohrkolibri
Veilchenperlmutterfalter
Venusgürtel
Vielfraß
Vierfleck
Vierfleckkreuzspinne
Vierflecklibelle
Vierkantwurm
Vierstreifige Dickkopffliege
Vierzehnpunkt-Marienkäfer
Vikunja
Viper
Vogel
Vogelspinne
Wachtel
Wal
Waldgärtner
Waldgrille
Waldkatze
Waldkauz
Waldrapp
Walhai
Walross
Wanderfalke
Wanze
Waran
Warzenschlange
Warzenschwein
Waschbär
Wasseramsel
Wasserbüffel
Wasserfloh
Wasserpieper
Wasserschildkröte
Wasserschnecke
Wasserschwein
Wasserspinne
Wasserzwerg
Watussirind
Weberknecht
Weichschildkröte
Weidengelbkehlchen
Weihnachtsbaumwurm
Weinbergschnecke
Weißfisch
Wellensittich
Wellhornschnecke
Wels
Wespe
Wespenbussard
Wiener Nachtpfauenauge
Wiesel
Wiesenralle
Wildkaninchen
Wildschwein
Windhund
Wisent
Wolf
Wolfsspinne
Wombat
Würgeschlange
Wurm
Wüstenheuschrecke
Wüstenmaus
Yak
Yeti-Krabbe
Yuccamotte
Zackenbarsch
Zander
Zauneidechse
Zaunkönig
Zebra
Zebraspringspinne
Zebu
zebu
Zecke
Ziege
Ziesel
Zikade
Zitronenfalter
Zitronenwaldsänger
Zobel
Zorilla
Zweifingerfaultier
Zwergadler
Zwergalk
Zwergameisenbär
Zwergammer
Zwergantilope
Zwergbandwurm
Zwergbartagame
Zwergbeutelmarder
Zwerg-Bläuling
Zwergbreitrandschildkröte
Zwergbuschbiene
Zwergdommel
Zwergesel
Zwergfledermaus
Zwergflusspferd
Zwerghamster
Zwergkaninchen
Zwergkolibri
Zwerg-Kugelfisch
Zwerg-Langzungenflughund
Zwergmaus
Zwergpinguin
Zwerg-Seepferdchen
Zwerg-Pinscher
"""

animals = animals.split("\n")
adjectives = adjectives.split("\n")

tiere_mit_artikel = """der Aal
die Aalmutter
die Aalrutte
der Aaskäfer
das Aberdeenrind
der Abraxas
die Abtrittsfliege
die Abtrittsmücke
die Achatschnecke
die Ackerhummel
die Ackermaus
die Ackerschnecke
der Addax
der Addax
der Adeliepinguin
der Adiak
der Adjutant
der Adler
der Adlerbussard
die Adlerechse
der Adlerfisch
der Adlerfrerattvogel
der Adlerrochen
der Admiral
die Adria-Eidechse
die Aeneasratte
der Ährenfisch
die Ährenmaus
der Ährenträgerpfau
die Äsche
die Äskulapnatter
der Affe
der Affendler
der Affenpinscher
der Afterrüssler
der Afterskorpion
der Agassiz’ Zwergbuntbarsch
das Agrion
der Aguarachay
der Agujaadler
das Aguti
das Ai
der Ailanthusspinner
der Aitel
die Akalima
der Akialoa
der Aktäonkäfer
der Akumba
der Aland
die Alandbleke
der Alaskabär
der Albatros
die Alectis
der Alektoweber
der Alet
der Alfonsino
der Alligator
der Alligatorhai
der Alligatorsalamander
der Almiqui
der Almizilero
das Alpaka
der Alpenbär
der Alpenbock
die Alpenbraunelle
die Alpendohle
die Alpenfledermaus
die Alpenkrähe
der Alpenmauerläufer
das Alpenmurmeltier
der Alpenpfeifhase
der Alpensalamander
der Alpenschneehase
das Alpenschneehuhn
der Alpensegler
die Alpenspitzmaus
der Alpensteinbock
der Alpenstrandläufer
der Alpenwolf
die Alpenwühlmaus
die Amadine
die Amazonenameise
die Ameise
der Ameisenbär
der Ameisenbeutler
der Ameisenigel
die Ameisenjungfern
der Ameisenlöwe
der Ameisenvogel
die Ameisewespe
der Amerikanische Cocker Spaniel
die Amethiystschlange
der Amherstfasan
die Amöbe
die Amsel
die Anakonda
das Anconschaf
die Anchovis
der Ancylus
der Andenbär
der Andenhirsch
der Anemonenfisch
der Angler
der Angolahase
das Angorakaninchen
die Angoraziege
der Ani
der Anoa
die Anopheles
der Ansauger
der Anthus
die Antilope
der Anubis-Pavian
die Apatura
der Apella
die Apfelblattlaus
der Apfelblattsauger
der Apfelwickler
der Apollofalter
der Ara
der Arakanga
der Arapaima
der Arawana
der Archaeopteryx
der Argali
der Argentinische Stummelfuß
die Argonauta
der Argusfasan
der Arizonasaurus
der Arpiranga-Salmler
der Aristoteles-Hai
der Aristoteles-Hirsch
der Arkal
der Ammolch
der Arni
der Aronstab-Frosch
die Aruliusbarbe
der Aschenhund
der Aschkoko
der Asinus
der Aspis
die Aspisviper
der Assala
der Assapan
die Assel
die Asselspinne
der Asselspinner
der Astacus
der Atlasfink
der Atlaslaubenvogel
der Atun
das Auerhuhn
der Auerochse
der Augenfalter
der Augenfleckbuntbarsch
die Augenfleckbuntbutte
die Augengrubennatter
der Augenpfeiffer
der Augenringwaldsänger
der Augenspinner
der Aurorafalter
die Auster
der Austerfisch
der Austernfischer
das Australienkrokodil
der Axishirsch
der Axolotl
das Aye-Aye
der Ayu
der Azarafuchs
der Babakoto
das Babirussa
die Bache
die Bachforelle
der Bachläufer
das Bachneunauge
der Bachröhrenwurm
der Bachsaibling
der Bachsalamander
die Bachstelze
der Badger
der Badul
das Bänderkänguru
die Bändersandnatter
der Bäumchenröhrenwurm
die Baikalrobbe
der Baira
das Balirind
die Balkannatter
der Balkenschröter
die Ballschlange
der Baltimoretrupial
der Bambusbär
die Bambusfingerratte
der Bambusgeist
der Bananenfrosch
der Bananenlaubfrosch
der Bandfink
der Bandiltis
die Bandmaus
der Bandmolch
die Bandnatter
der Bandro
die Bandrobbe
der Bandwurm
das Bankivahuhn
der Banteng
der Bär
der Barasingha
die Barbastella
der Bärbling
der Barch
der Bärenbeutler
das Bärenkänguru
der Bärenmakak
der Bärenmaki
der Bärenpavian
der Bärenspinner
der Baribal
der Barrakuda
der Barramuda
die Barrenringelnatter
der Barrigudo
der Barsch
der Bartaffe
die Bart-Agame
die Bartfledermaus
der Bartkauz
die Bartmeise
die Bartrobbe
der Bartsaki
das Bartschwein
der Basset
der Baßtölpel
die Bastardmakrele
die Bastardschildkröte
die Batagurschildkröte
das Batakpony
die Bauin
der Baumameisenfresser
der Baumfalke
der Baumfrosch
das Baumkänguru
der Baumläuferwaldsänger
die Baumleguane
der Baummarder
der Baumpieper
der Baumsalamander
der Baumschläfer
die Baumschlange
die Baumschneke
der Baumschnüffler
der Baumsegler
das Baumstachelschwein
der Baumtiger
der Baumweißling
die Baumwollratte
das Baumwollschwanzkaninchen
die Bechsteins Fledermaus
die Beerenwanze
der Behra
der Beilbauchfisch
der Beilbauchsalmler
der Beilfisch
die Beisa
der Belchen
der Bellfrosch
der Bellhirsch
der Beluga
die Bembix
der Bengalfuchs
das Bengalische Stachelschwein
die Bengalkatze
der Bengaltiger
das Bennets Baumkänguruh
das Bennetkänguruh
der Beo
der Berberaffe
die Berberkröte
der Berberlöwe
die Berbermaus
der Berberskink
das Bergamaskerschaf
der Berg-Coati
die Bergeidechse
die Bergente
der Bergfink
der Berggorilla
der Berghänfling
der Bergilt
das Bergkänguruh
die Bergkatze
die Berglandunke
der Berglöwe
der Bergmolch
der Bergnasenbär
die Bergnyala
der Bergpaka
der Bergpieper
der Bergriedbock
der Bergstachler
der Bergtapir
das Bergzebra
die Bergziege
der Bernhardiner
die Bernsteinmakrele
die Bettwanze
das Beulenkrokodil
der Beutelbär
der Beutelbilch
der Beuteldachs
das Beutelflughörnchen
der Beutelfrosch
der Beutelfuchs
die Beutelgilbmaus
der Beutelhund
der Beuteliltis
der Beutelmarder
der Beutelmaulwurf
der Beutelmull
die Beutelratte
der Beuteteufel
der Beutewolf
die Bezoarziege
der Bharal
der Biber
der Buberkäfer
die Biberratte
die Biberspitzmaus
die Biene
die Bienenelfe
der Bienenfresser
der Bienenkäfer
die Bienenlaus
die Bienenmilbe
der Bienenwolf
das Bighornschaf
der Bilch
der Bilchmaki
die Bilharzia
der Bindebeuteldachs
das Bindenschwein
der Bindenwaran
der Binturong
der Birgus
die Birkenknopfhornwespe
die Birkenmaus
der Birkenspanner
der Birkenspinner
der Birkenstecher
der Birkenzeisig
der Birkfuchs
das Birkhuhn
der Birma-Hase
der Birnensauger
die Birngallmücke
der Bisam
die Bisamente
die Bisamratte
das Bisamschwein
der Bischoffsaffe
der Biskaya-Wal
der Bison
der Bitterling
die Bitterlingsbarbe
der Black-Molly
die Bläßgans
das Bläßhuhn
der Bläuel
die Blaumeise
der Blainvilles Delphin
der Blankaal
der Blasenfrosch
der Blasenkäfer
der Blasenwurm
der Blasse Kärpfling
der Blaßfuchs
der Blattfinger
der Blattfisch
das Blatthühnchen
der Blattkäfer
die Blattlaus
der Blattlauslöwe
die Blattnasenatter
der Blattrippenstecher
der Blattschmetterling
die Blattschneiderameise
die Blattschneiderbiene
der Blattschwanzgecko
der Blattsteigerfrosch
die Blattwespe
die Blaubandgrundel
der Blaubandkärpling
der Blaubandsalmler
der Blaubarsch
der Blaubock
das Blauböckchen
der Blaubull
die Blaudrossel
der Blaue Fadenfisch
das Blaufelchen
der Blaufisch
der Blauflügelwaldsänger
der Blaufuchs
der Blauglanzhechtling
der Blauhai
die Blaukehlagame
das Blaukehlchen
der Blaukopf
die Blaumaul-Meerkatze
die Blaumeise
die Blaumerle
der Blaupunktbuntbarsch
die Blaurake
der Blaurücken
der Blaurückenducker
der Blaurückenwaldsänger
das Blauschaf
der Blauschwanz-Schlankskink
die Blaustirnamazone
der Blaustreifengrunzer
der Blauwal
die Blauwange
der Blauzungenskink
das Bleiböckchen
der Bleirückensalamander
der Bleßbock
die Bleßgans
der Bleßmull
der Blikke
der Blinddarmbilch
die Blinde-Höhlenbarbe
die Blinde Höhlengrundel
der Blinder Höhlensalamander
der Blinder Höhlenwels
der Blinder Trugkärpfling
der Blindmaulwurf
die Blindmaus
der Blindmolch
die Blindschleiche
das Blödauge
der Blöker
die Blumennase
die Blumentopfschlange
der Blutbock
der Blutbrustpavian
der Blutegel
der Blutfasan
der Bluthänfling
der Bluthals
der Blthund
die Blutlaus
die Blutpython
der Blutsalmler
der Blutsauger
der Blutschnabelweber
das Blutströpchen
die Boa
der Boaedon
die Boa-Trugnatter
der Bobak
der Bobtail
der Bock
der Bockkäfer
die Bodenkröte
das Böhm-Zebra
der Bogenfinger
der Bohnenkäfer
die Bohnenmuschel
die Bohrschnecken
der Bohrschwamm
der Bohrwurm
der Boleophthalmus
das Bologneser-Hundchen
der Bombardierkäfer
die Bombay-Ente
die Bombina
der Bobus
die Bonellia
der Bongo
der Bonito
der Bonobo
der Boomslang
die Bordeaux-Dogge
der Borkenkäfer
die Borkenratte
das Borkentier
die Borneokatze
der Borstenbaumstachler
das Borstenferkel
das Borstengürteltier
das Borstenhörnchen
der Borstenigel
das Borstenkaninchen
das Borstenmaul
die Bothrops
der Boxer
der Brabantbuntbarsch
der Brachkäfer
die Brachschwalbe
der Brachsen
der Brachsensalmler
die Brachschnepfe
der Brachvogel
die Brandgans
die Brandmaus
die Brandseeschwalbe
die Brasse
der Bratpfannenwels
der Brauen-Glattstirnkaiman
die Braula
der Braunbär
der Braunbrustwaldsänger
die Braune-Hyäne
der Braunfisch
das Braunkelchen
der Braunkehlfrosch
das Braunkopffaultier
der Braunkopf-Kuhstärling
der Braunrückentukan
der Braunskink
die Brautente
die Brazza-Meerkatze
der Breitflossenkärpfling
das Breitmaulnashorn
die Breitrandschildkröte
der Breitschnauzen-Halbmaki
der Breitschnauzenkaiman
die Bremse
der Brenner
die Brieftaube
der Brillantsalmler
der Brillenbär
das Brillenkänguruh
der Brillenkaiman
der Brillenpinguin
die Brillenschlange
die Brokatbarbe
der Brolgakranich
der Brombeerfalter
der Brotkäfer
der Bruchfisch
der Bruchwasserläufer
die Brückenechse
der Brüllaffe
der Brunnenmolch
der Brydewal
der Buansu
der Bubo bubo
der Buchdrucker
die Buchengallmücke
der Buchenspinner
der Buchfink
der Buchstabenfrosch
der Buckelochse
der Buckelwal
der Budeng
die Bücherlaus
der Bücherskorpion
der Bücherwurm
der Büffel
der Bülbül
der Bündelnister
das Bürstenschwanz-Rattenkänguruh
die Büschelbraunenviper
der Büschelkäfer
die Büschelohr-Beisa
die Bulldogameise
die Bulldogge
der Bullterrier
die Bungerschlange
der Buntbarsch
der Buntbock
der Buntkäfer
die Buntmaus
der Buntspecht
der Buntwaran
die Buntwühle
das Burchell-Zebra
der Burunduk
das Buschbaby
der Buschbock
der Buschducker
das Buschhuhn
die Buschkatze
der Buschmeister
der Buschschliefer
der Buschwaldgalago
der Bussard
der Butt
der Butterfisch
der Butterkrebs
der Cacajao
die Calandra
der Cambarus
die Campbell-Meerkatze
der Cana-Fuchs
der Cañon-Laubfrosch
der Capparo
das Capybara
der Carassius
der Carcinus
die Cayenne-Ratte
das Celebes-Schwein
der Celebes-Segelfisch
die Cerastes
die Ceylonbarbe
die Ceylon-Wühle
das Chamäleon
der Chanchito
das Chapman-Zebra
der Charsa
der Cheetah
das Cheiraxanthium
der Chelifer
der Chihuahua
der Chilenischer Pudu
der Chin
der China-Alligator
das Chinchillakaninchen
die Chinchillaratte
das Chinchilla
die Chinesische Nachtigall
der Chinesischer Hase
der Chipmunk
der Chitala
der Chitala-Frosch
der Chow-Chow
die Chuckwalla
der Cistensänger
die Clownbarbe
der Clownfisch
der Coatimundi
der Cobia
der Cocker-Spaniel
der Collie
der Colobus
der Colocolò
der Coloradokäfer
der Colpeo
der Coluber
das Connemara-Pony
das Cornwallschwein
die Coscoroba
der Coyote
der Cyclops
die Daboia
die Dachratte
die Dachschildkröte
der Dachs
der Dachshund
der Dackel
die Dama-Gazelle
die Damara-Dik-Dik
das Damara-Zebra
der Damhirsch
die Dampfschiffente
der Darwins Nandu
die Dattelmuschel
der Davidshirsch
der Deerhound
der Defassa-Wasserbock
der Degenfisch
der Degu
der Delfin
der Demidoff-Galago
der Dendrolagus
der Derby-Arassari
das Derbywallaby
der Desmognathus
der Deutsch-Drahthaar
die Deutsche-Dogge
der Deutsch-Kurzhaar
der Deutsch-Langhaar
die Diadem-Meerkatze
die Diadem-Natter
die Diadem-Schildkröte
der Diadem-Seeigel
der Diadem-Sifaka
die Diamantbarsche
der Diamantfasan
die Diamantklapperschlange
der Diamantpiton
die Diamantschildkröte
die Diana-Meerkatze
der Dickfinger
das Dickhornschaf
der Dickkopfkapuziner
der Dickschnabelpinguin
die Dickschwanzbeutelratte
der Dickschwanz-Scorpion
der Diebskäfer
der Dingo
der Dinosaurier
die Dione-Natter
der Diskusbuntbarsch
der Diskussalmler
der Distelfalter
der Distelfink
der dodo
die Dosenschildkröte
der Döbel
der Dögling
die Dogge
der Doggenhai
die Dohle
der Doktorfisch
der Dolchfrosch
die Dolchstichtaube
der Dompfaff
der Donaulachs
der Doppelbindenarassari
der Doppelhornvogel
die Doppelschnepfe
die Dorkasgazelle
die Dorneidechse
die Dornfingerspinne
die Dorngrasmücke
der Dornhai
die Dornroche
der Dornschwanzbilch
der Dornschwanzkink
der Dornteufel
die Dornzirpe
der Dorsch
der Dottertukan
der Drachenfisch
der Drachenflosser
der Drahthaarterrier
der Drehwurm
der Dreibandsalmler
der Dreibinden-Ziersalmler
die Dreieckmuschel
das Dreifingerfaultier
das Dreihornchamäleon
der Dreihornkäfer
der Dreikantwurm
die Dreikielschilkröte
der Dreiklauer
der Dreilinienbärbling
der Dreipunkt-Korallenbarsch
der Dreischwanzbarsch
der Dreistreifenpalmenroller
der Dreistreifensalmler
das Dreizehefaultier
der Dreizehespecht
der Drill
die Drohne
das Dromedar
die Drongos
die Dronte
die Drosophila
die Drossel
der Drosselrohrsänger
der Drückerfisch
der Drusenkopf
der Dryas
die Dschelada
der Dschiggetai
das Dschungelrind
der Duckaffe
die Dünengazelle
der Dünnfingergeko
der Dünnleib
die Düsterbiene
der Dukatenfalter
der Dummkopfwal
der Dungkäfer
die Durukulis
der Dybowskihirsch
der Dytiscus
der Eber
die Echse
der Edelfasan
der Egel
der Eichelhäher
der Eichenspinner
das Eichhörnchen
die Eidechse
die Eiderente
der Einsiedlerkrebs
die Eintagsfliege
der Eisbär
der Eisvogel
der Elch
das Elen
der Elefant
die Elritze
die Elster
der Emu
der Engelhai
der Engerling
die Ente
das Erdferkel
das Erdmännchen
der Erpel
der Esel
der Eselspinguin
die Eule
die Falkennachtschwalbe
der Falter
der Färberfrosch
der Fasan
das Faultier
die Fechterschnecke
die Feenseeschwalbe
die Feldgrille
der Feldhase
die Feldmaus
der Felsenpinguin
der Feuersalamander
der Fichtenwaldsänger
das Fingertier
der Fischadler
der Fischbandwurm
der Fischotter
der Fischreiher
der Flachlandgorilla
der Flamingo
die Fledermaus
die Fliege
der Floh
das Florida-Waldkaninchen
der Flugdrache
die Flunder
der Flussdelfin
der Flusskrebs
das Flusspferd
die Forelle
die Fossa
das Frettchen
der Frosch
der Fruchtvampir
der Fuchs
der Fuchsbandwurm
die Galagos
die Geburtshelferkröte
die Gämse
die Gans
der Gänsegeier
der Gaur
die Gazelle
der Gecko
der Gefleckter Kohltriebrüssler
der Gefurchter Dickmaulrüssler
der Geier
der Gelbbrustwaldsänger
der Gelbscheitelwaldsänger
der Gelbstirnwaldsänger
die Gemeine Feuerwanze
die Gemeine Florfliege
die Gemeine Wiesenwanze
der Gemeiner Graurüssler
der Gemeiner Holzbock
der Gemeiner Nagekäfer
die Gemse
der Gepard
der Gerfalke
die Geringelte Mordwanze
der Gibbon
der Gimpel
die Giraffe
der Glanzvogel
der Glasbarsch
der Glattwal
der Glockenvogel
das Gnu
der Goldfisch
der Goldflügelwaldsänger
der Goldlachs
die Goldleiste
die Goldmulle
die Goldschnepfe
der Goldschopfpinguin
der Goldwaldsänger
der Goldwangenwaldsänger
der Goldzeisig
der Gorilla
die Gottesanbeterin
der Grasfrosch
die Grasmücke
der Graubär
der Graufuchs
der Grauliest
der Grauwal
das Grevyzebra
der Grizzlybär
die Grille
die Groppe
der Große Rapsstängelrüssler
der Großnilhecht
der Grottenolm
die Grundel
die Grüne Mamba
die Grüne Stinkwanze
der Grünfink
der Grünrüssler
der Grünwaldsänger
das Guanako
der Guppy
der Gürtelmull
das Gürteltier
der Haarnasenwombat
der Haarschopftaucher
die Halsbanddrossel
der Häherkuckuck
der Hahn
der Hai
der Haldenwaldsänger
der Halsbandsittich
der Hammerhai
der Hamster
das Hängebauchschwein
der Hase
die Haselmaus
der Haubentaucher
die Hausmaus
die Hausratte
das Hausschwein
die Hawaiigans
die Heidelerche
der Heilbutt
der Helmturako
die Henne
die Herbstgrasmilbe
der Hering
der Heringshai
das Hermelin
die Heuschrecke
der Hirsch
der Hirschkäfer
der Hoatzin
das Hochlandrind
der Höckerschwan
der Holzbrüter
der Holzwurm
die Honigbiene
der Hornfrosch
die Hornisse
das Hübschgesichtwallaby
die Hufeisennase
das Huhn
die Hummelelfe
der Hummer
der Hund
der Hundsfisch
die Hyäne
der Hyazinth-Ara
der Igel
der Igelfisch
der Iltis
die Imme
die Impala
der Inger
das Insekt
die Iris
der Isabellabär
der Ibis
der Jaguar
der Jak
der Jack Russell Terrier
der Jaguarundi
der Japanmakake
der Kabeljau
der Katta
der Kleinstein
der Käfer
die Kakerlake
das Kamel
der Kanadawaldsänger
das Känguru
das Kaninchen
der Kapuzenwaldsänger
das Karnickel
der Karpfen
der Kaschmirhirsch
die Kaschmirziege
der Kater
die Katze
der Kaulbarsch
die Kaulquappe
die Kegelrobbe
die Kellerassel
der Kentuckywaldsänger
die Klapperschlange
die Kliesche
die Knoblauchkröte
der Knochenhecht
der Koala
der Kodiakbär
der Kolibri
der Kommafalter
der Komoren-Quastenflosser
die Königspython
der Kormoran
der Kranich
die Krähe
die Kreuzkröte
die Kreuzotter
das Krokodil
der Kronenadler
der Kronwaldsänger
die Kröte
der Kugelfisch
die Küchenschabe
die Kuh
die Lachmöwe
die Lachsforelle
das Lama
das Lamm
die Landschildkröte
die Langschwanzchinchilla
der Lar
der Laubfrosch
der Laubsänger
die Laus
der Lärmlederkopf
die Lederschildkröte
der Leguan
der Lemming
der Lemur
der Leopard
der Leopardgecko
die Libelle
der Liger
der Lippenbär
der Löwe
der Luchs
der Lurch
die Farbmaus
die Made
der Madenhacker
der Marder
der Marderhund
die Maus
der Mädesüß-Perlmutterfalter
der Mähnenwolf
der Maikäfer
der Magnolienwaldsänger
der Makake
der Maki
die Makrele
der Malaienbär
der Malvenfalter
der Manado-Quastenflosser
die Mandarinente
der Mandrill
der Manta
das Manteltier
der Marabu
der Marder
der Marienkäfer
die Marmelente
die Marmorkatze
die Märzente
die Mauerläufer
der Mauersegler
der Maulesel
das Maultier
der Maulwurf
der Mauritiusfalke
die Maus
der Mäusebussard
der Meeresfisch
die Meeresschildkröte
das Meerestier
die Meerkatze
das Meerneunauge
das Meerschwein
das Meerschweinchen
der Megalodon
die Meise
der Menschenfloh
der Messingkäfer
die Miesmuschel
der Mistkäfer
die Mieze
die Miezekatze
der Milan
die Milbe
das Minischwein
die Misteldrossel
der Mittelspecht
der Moa
die Molluske
der Monarchfalter
der Mönchswaldsänger
der Mondfisch
der Mondvogel
die Moorente
das Moorhuhn
der Mops
der Mosaikfadenfisch
der Moschusochse
die Motte
die Möwe
der Mungo
die Mücke
der Muli
der Mull
die Muräne
das Murmeltier
die Muschel
der Mustang
die Nachtigall
der Nachtigall-Grashüpfer
der Nackthund
die Nacktkatze
der Nachtfalter
der Nacktmull
der Nacktnasenwombat
die Nacktschnecke
der Nandu
der Nasenaffe
der Nasenbär
das Nashorn
die Natter
der Nautilus
der Nebelparder
das Neunauge
das Nilpferd
der Nördlicher Pfeifhase
die Nutria
der Nymphensittich
der Ochse
das Ochsenauge
der Ochsenfrosch
der Octopus
der Ohrenkneifer
die Ohrenqualle
das Okapi
der Olm
der Onager
das Opossum
der Orca
der Orang-Utan
der Orangefleckwaldsänger
der Otter
der Ozelot
der Ölkäfer
der Pampashase
der Panda
der Pangasius
der Panther
das Pantoffeltierchen
der Papagei
der Papageitaucher
der Paradiesvogel
der Pelikan
der Pelikanaal
das Perlsteißhuhn
die Perserkatze
der Peterfisch
der Pfau
das Pfauenauge
der Pfauenaugenbutt
der Pfeilgiftfrosch
das Pferd
der Pieperwaldsänger
der Pillendreher
der Pinguin
der Polarbär
der Polarfuchs
der Polyp
der Pottwal
der Primat
der Puma
der Purpurbär
der Purpurbock
die Purpurkopfbarbe
die Pute
der Puter
das Quagga
die Qualle
der Quastenflosser
das Quokka
der Rabe
die Rabenkrähe
die Ratte
der Ratten-Lungenwurm
der Raubfisch
der Raubfuß-Bussard
das Raubtier
der Raubvogel
der Raufußkauz
der Rauhaardackel
die Raupe
das Rebhuhn
die Reblaus
die Regenbogenforelle
der Regenpfeifer
der Regenwurm
das Reh
der Rehbock
das Rehböckchen
das Rehkitz
der Reiher
der Reinwardt-Arassari
das Ren
die Rennmaus
das Rennschwein
der Rennvogel
das Rentier
das Reptil
der Rhesusaffe
das Rhinozeros
der Riesenbastkäfer
der Riesenhai
die Riesenkrake
die Riesenschildkröte
der Riesentukan
das Rind
der Rinderbandwurm
die Ringdrossel
die Ringelgans
die Ringelnatter
die Ringeltaube
die Robbe
der Rochen
die Rohrdommel
die Rohrratte
die Rohrweihe
das Rosenköpfchen
der Rosenwaldsänger
der Rostscheitelwaldsänger
der Rotbarsch
die Rotbrasse
die Rote Mordwanze
der Roter Brüllaffe
der Rotfuchs
die Rothalsgans
der Rothalstaucher
das Rotkehlchen
der Rotkropfarassari
der Rotluchs
der Rotmilan
der Rotnackenarassari
der Rotschwanz
der Rotsteißarassari
die Rotwangenschildkröte
das Rotwild
der Rotwolf
die Rotzunge
der Rubinfleckwaldsänger
der Rubinkehlkolibri
der Ruderfrosch
die Sardelle
der Säbelschnäbler
der Säbelzahntiger
der Sägefisch
der Säger
der Saibing
der Salamander
die Salangane
der Salm
der Salmler
der Sandaal
der Sanderling
der Sandfloh
der Sandlaufkäfer
der Sandregenpfeifer
die Sandwespe
die Sardine
die Sattelrobbe
die Sau
der Säuger
das Säugetier
die Schabe
der Schabrackenschakal
das Schachbrett
das Schaf
der Schakal
die Scharbe
der Scheidenschnabel
der Schellfisch
der Scheltopusik
der Scherenschnabel
das Scherflein
die Schermaus
die Schildkröte
die Schildlaus
der Schill
der Schimmel
der Schimpanse
der Schäfer
der Schlammläufer
der Schlammpeitzger
der Schlammteufel
die Schlange
die Schlangenweihe
der Schlangernstern
der Schlankschnabelbülbül
die Schleiche
die Schleie
die Schleiereule
der Schleimaal
der Schleimfisch
der Schliefer
die Schlüsselschnecke
die Schmerle
der Schmetterling
der Schmutzgeier
der Schnabeligel
das Schnabeltier
die Schnake
der Schnapper
der Schnäpperwaldsänger
die Schnecke
die Schneeammer
die Schnee-Eule
der Schneefink
der Schneefloh
die Schneegans
das Schneehöschen
das Schneehuhn
der Schneesperling
der Schnegel
der Schneider
die Schnepfe
die Schnirkelschnecke
die Scholle
die Schopfwachtel
der Schriftarassari
der Schuhschnabel
der Schupp
das Schuppentier
der Schuster
der Schützenfisch
die Schwalbe
der Schwalbenschwanz
der Schwalm
der Schwamm
der Schwan
die Schwanzmeise
der Schwarzkehlarassari
der Schwarzkopftukan
der Schwarzschnabeltukan
der Schwarzspecht
der Schwarzstorch
das Schwein
der Schweinsaffe
der Schweinsfisch
der Schweinshai
der Schweinswal
der Schwertfisch
der Schwertwal
die Schwimmwühle
der Seeaal
der Seeadler
die Seeanemone
der Seeapfel
der Seebär
die Seebarbe
der Seebarsch
die Seebinkel
die Seebrassen
der Seebull
die Seedattel
der Seeelefant
der Seefächer
die Seefeder
die Seegurke
der Seehase
der Seehecht
der Seehund
der Seeigel
die Seekatze
die Seekuh
der Seelachs
die Seelilie
der Seelöwe
die Seemannshand
die Seemaus
die Seenadel
die Seenelke
das Seeohr
der Seeotter
der Seerabe
die Seeratte
der Seeringelwurm
die Seescheide
die Seeschlange
der Seeschmetterling
die Seeschwalbe
der Seeskorpion
die Seespinne
die Seestachelbeere
der Seestern
der Seetaucher
der Seeteufel
der Seevogel
die Seewalze
der Seewolf
die Seezunge
der Segelfalter
der Segler
der Seidenfadenfisch
der Seidenschwanz
der Seidenspinner
der Sekretär
die Sepia
der Seychellenfalke
der Shrimp
der Sichelreiher
der Siebenschläfer
der Siamang
der Sichler
der Sichling
der Sikahirsch
der Silberfisch
der Singvogel
der Skalar
der Skarabäus
der Skink
der Skorpion
das Skunk
der Sonnenbarsch
der Sonnenstern
der Spanner
der Spatz
der Specht
der Sperber
die Sperbereule
der Sperling
der Sperlingskauz
der Spießer
die Spinne
der Spinnenläufer
der Spinner
der Spint
das Spitzhörnchen
die Spitzmaus
der Spötter
die Spottdrossel
der Springaffe
der Springbock
der Spulwurm
die Stachelmakrele
der Stachelrochen
das Stachelschwein
der Star
der Starfrosch
die Stechfliege
die Stechmücke
der Stechrochen
der Steinadler
der Steinbeißer
der Steinbock
der Steinbutt
die Steindohle
der Steinfisch
die Steinfliege
die Steinforelle
der Steingreßling
das Steinhuhn
der Steinkauz
die Steinkoralle
der Steinkrebs
der Steinkriecher
der Steinlachs
der Steinläufer
der Steinmarder
der Steinpicker
der Steinrötel
der Steinschmätzer
der Steinspatz
der Steinsperling
der Steinwälzer
die Stelze
der Stelzenläufer
der Sterntaucher
der Stichling
der Stieglitz
der Stier
das Stinktier
der Stint
die Stockente
der Stöcker
der Stör
der Storch
die Strandelster
die Strandfliege
der Strandfloh
der Strandläufer
der Strandpieper
die Strandschnecke
der Strandwolf
der Streber
die Streifengrasmaus
das Streifenhörnchen
der Streifenschnabelarassari
der Strömer
die Stubenfliege
die Sturmschwalbe
der Sturmtaucher
der Sturmvogel
die Stute
der Sumpfbiber
die Sumpfdeckelschnecke
der Sumpfhase
das Sumpfhuhn
der Sumpfläufer
die Sumpfmaus
die Sumpfmeise
die Sumpfohreule
die Sumpfschildkröte
der Swainson-Tukan
das Schwein
der Tabakkäfer
der Tagfalter
das Tagpfauenauge
der Tannenhäher
der Tanrek
der Tanuki
die Tarantel
die Taube
der Tausendfüßer
der Tausendfüßler
der Tentakel-Schluckspecht
der Thunfisch
der Tieraffe
der Tiger
der Tigerwaldsänger
der Timberwolf
der Tintenfisch
die Todis
die Töle
der Tölpel
der Totengräber
der Totenkopf
das Totenkopfäffchen
die Totenuhr
das Trampeltier
der Triel
der Truthahn
das Truthuhn
die Tsetse-Fliege
die Tsetsefliege
der Tukan
der Tundrawolf
die Tüpfelhyäne
der Turmfalke
die Turteltaube
der Tyrann
der Uakari
die Uferschnepfe
die Uferschwalbe
der Uhu
der Unglückshäher
die Unke
der Ur
der Urangutan
das Urpferd
der Urson
der Vampirfisch
die Veilchenente
der Veilchenohrkolibri
der Veilchenperlmutterfalter
der Venusgürtel
der Vielfraß
der Vierfleck
die Vierfleckkreuzspinne
die Vierflecklibelle
der Vierkantwurm
die Vierstreifige Dickkopffliege
der Vierzehnpunkt-Marienkäfer
das Vikunja
die Viper
der Vogel
die Vogelspinne
die Wachtel
der Wal
der Waldgärtner
die Waldgrille
die Waldkatze
der Waldkauz
der Waldrapp
der Walhai
das Walross
der Wanderfalke
die Wanze
der Waran
die Warzenschlange
das Warzenschwein
der Waschbär
die Wasseramsel
der Wasserbüffel
der Wasserfloh
der Wasserpieper
die Wasserschildkröte
die Wasserschnecke
das Wasserschwein
die Wasserspinne
der Wasserzwerg
das Watussirind
der Weberknecht
die Weichschildkröte
das Weidengelbkehlchen
der Weihnachtsbaumwurm
die Weinbergschnecke
der Weißfisch
der Wellensittich
die Wellhornschnecke
der Wels
die Wespe
der Wespenbussard
das Wiener Nachtpfauenauge
das Wiesel
die Wiesenralle
das Wildkaninchen
das Wildschwein
der Windhund
der Wisent
der Wolf
die Wolfsspinne
der Wombat
die Würgeschlange
der Wurm
die Wüstenheuschrecke
die Wüstenmaus
das Yak
die Yeti-Krabbe
die Yuccamotte
der Zackenbarsch
der Zander
die Zauneidechse
der Zaunkönig
das Zebra
die Zebraspringspinne
das Zebu
das zebu
die Zecke
die Ziege
der Ziesel
die Zikade
der Zitronenfalter
der Zitronenwaldsänger
der Zobel
die Zorilla
das Zweifingerfaultier
der Zwergadler
der Zwergalk
der Zwergameisenbär
die Zwergammer
die Zwergantilope
der Zwergbandwurm
die Zwergbartagame
der Zwergbeutelmarder
der Zwerg-Bläuling
die Zwergbreitrandschildkröte
die Zwergbuschbiene
die Zwergdommel
der Zwergesel
die Zwergfledermaus
das Zwergflusspferd
der Zwerghamster
das Zwergkaninchen
der Zwergkolibri
der Zwerg-Kugelfisch
der Zwerg-Langzungenflughund
die Zwergmaus
der Zwergpinguin
das Zwerg-Seepferdchen
der Zwerg-Pinscher"""
