from greetings.consts import adjectives, animals
from random import randint
import re


def greeting(data: bool = False) -> list[str] | str:
    """Gives you a nice greeting
    if data is True the output is just adjective and animal."""
    index1 = randint(0, len(adjectives) - 1)
    adj = adjectives[index1]
    first_letter = f"{adj[0]}.*"
    filter_animals = [x for x in animals if re.match(first_letter.upper(), x)]

    index2 = randint(0, len(filter_animals) - 1)
    animal = filter_animals[index2]

    pronomen1 = "mein"
    pronomen2 = ["junge", "kleine"]
    pronomen2 = pronomen2[randint(0, 1)]

    if animal[-1] == "e":
        adj = adj + "e"
        pronomen1 = pronomen1 + "e"
    else:
        adj = adj + "er"
        pronomen2 = pronomen2 + "r"

    if data:
        return [adj, animal]
    else:
        return f"{pronomen1} {pronomen2} {adj} {animal}"


if __name__ == "__main__":
    print(greeting())
