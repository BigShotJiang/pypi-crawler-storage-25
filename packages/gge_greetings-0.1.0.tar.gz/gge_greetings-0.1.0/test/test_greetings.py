from greetings import greeting

print("Just greeting():")
print(greeting())
print("\ngreeting(data=True):")
print(greeting(data=True))