## Typing stubs for Deprecated

This is a [type stub package](https://typing.python.org/en/latest/tutorials/external_libraries.html)
for the [`Deprecated`](https://github.com/laurent-laporte-pro/deprecated) package. It can be used by type checkers
to check code that uses `Deprecated`. This version of
`types-Deprecated` aims to provide accurate annotations for
`Deprecated~=1.3.1`.

This package is part of the [typeshed project](https://github.com/python/typeshed).
All fixes for types and metadata should be contributed there.
See [the README](https://github.com/python/typeshed/blob/main/README.md)
for more details. The source for this package can be found in the
[`stubs/Deprecated`](https://github.com/python/typeshed/tree/main/stubs/Deprecated)
directory.

This package was tested with the following type checkers:
* [mypy](https://github.com/python/mypy/) 2.1.0
* [pyright](https://github.com/microsoft/pyright) 1.1.409

It was generated from typeshed commit
[`60a6695e77b81d0e1b5a088c316af78c7510941f`](https://github.com/python/typeshed/commit/60a6695e77b81d0e1b5a088c316af78c7510941f).