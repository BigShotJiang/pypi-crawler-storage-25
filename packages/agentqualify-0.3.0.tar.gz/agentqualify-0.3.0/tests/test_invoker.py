"""Tests for AgentInvoker — all three model switching strategies."""
import json
from unittest.mock import MagicMock, patch

from agentqualify.config import AgentQualifyConfig, TestCase, Turn
from agentqualify.invoker import AgentInvoker

BASE_CONFIG = {
    "agent": {
        "runtime_arn": "arn:aws:bedrock-agentcore:us-east-1:123:agent-runtime/agent1",
        "span_wait_seconds": 0,
    },
}

TESTS = [TestCase(name="t1", prompt="Hello")]


def _make_config(models_cfg: dict) -> AgentQualifyConfig:
    return AgentQualifyConfig.model_validate({**BASE_CONFIG, "models": models_cfg})


@patch("agentqualify.invoker.boto3.client")
def test_qualifier_strategy(mock_boto):
    mock_client = MagicMock()
    mock_boto.return_value = mock_client
    mock_client.invoke_agent_runtime.return_value = {}

    cfg = _make_config({
        "strategy": "qualifier",
        "variants": [{"name": "sonnet", "qualifier": "sonnet-ep"}],
    })
    result = AgentInvoker(cfg).invoke_all(TESTS)

    assert "sonnet" in result
    assert "t1" in result["sonnet"]
    call_kwargs = mock_client.invoke_agent_runtime.call_args[1]
    assert call_kwargs["qualifier"] == "sonnet-ep"
    assert call_kwargs["agentRuntimeArn"] == cfg.agent.runtime_arn


@patch("agentqualify.invoker.boto3.client")
def test_payload_strategy(mock_boto):
    mock_client = MagicMock()
    mock_boto.return_value = mock_client
    mock_client.invoke_agent_runtime.return_value = {}

    cfg = _make_config({
        "strategy": "payload",
        "variants": [{"name": "haiku", "payload_override": {"model": "anthropic.claude-haiku"}}],
    })
    AgentInvoker(cfg).invoke_all(TESTS)

    call_kwargs = mock_client.invoke_agent_runtime.call_args[1]
    payload = json.loads(call_kwargs["payload"])
    assert payload["model"] == "anthropic.claude-haiku"


@patch("agentqualify.invoker.boto3.client")
def test_separate_runtimes_strategy(mock_boto):
    mock_client = MagicMock()
    mock_boto.return_value = mock_client
    mock_client.invoke_agent_runtime.return_value = {}

    alt_arn = "arn:aws:bedrock-agentcore:us-east-1:123:agent-runtime/agent2"
    cfg = _make_config({
        "strategy": "separate_runtimes",
        "variants": [{"name": "v2", "runtime_arn": alt_arn}],
    })
    AgentInvoker(cfg).invoke_all(TESTS)

    call_kwargs = mock_client.invoke_agent_runtime.call_args[1]
    assert call_kwargs["agentRuntimeArn"] == alt_arn


@patch("agentqualify.invoker.boto3.client")
def test_multi_turn(mock_boto):
    mock_client = MagicMock()
    mock_boto.return_value = mock_client
    mock_client.invoke_agent_runtime.return_value = {}

    cfg = _make_config({
        "strategy": "qualifier",
        "variants": [{"name": "m", "qualifier": "ep"}],
    })
    multi = [TestCase(name="mt", prompts=["Turn 1", "Turn 2"])]
    AgentInvoker(cfg).invoke_all(multi)

    # Should be called twice (once per turn), same session_id
    assert mock_client.invoke_agent_runtime.call_count == 2
    sid1 = mock_client.invoke_agent_runtime.call_args_list[0][1]["runtimeSessionId"]
    sid2 = mock_client.invoke_agent_runtime.call_args_list[1][1]["runtimeSessionId"]
    assert sid1 == sid2


@patch("agentqualify.invoker.boto3.client")
def test_multi_turn_with_turns_format(mock_boto):
    mock_client = MagicMock()
    mock_boto.return_value = mock_client
    mock_client.invoke_agent_runtime.return_value = {}

    cfg = _make_config({
        "strategy": "qualifier",
        "variants": [{"name": "m", "qualifier": "ep"}],
    })
    multi = [TestCase(name="mt", turns=[
        Turn(prompt="Turn 1", expected_response="A1"),
        Turn(prompt="Turn 2", expected_response="A2"),
    ])]
    AgentInvoker(cfg).invoke_all(multi)

    assert mock_client.invoke_agent_runtime.call_count == 2
    # Verify prompts were sent correctly
    p1 = json.loads(mock_client.invoke_agent_runtime.call_args_list[0][1]["payload"])
    p2 = json.loads(mock_client.invoke_agent_runtime.call_args_list[1][1]["payload"])
    assert p1["prompt"] == "Turn 1"
    assert p2["prompt"] == "Turn 2"
