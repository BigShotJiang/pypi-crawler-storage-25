"""Tests for CICDGate — threshold and regression checks."""

from agentqualify.config import AgentQualifyConfig
from agentqualify.gate import CICDGate

BASE_CONFIG = {
    "agent": {"runtime_arn": "arn:aws:bedrock-agentcore:us-east-1:123:agent-runtime/a1"},
    "evaluators": ["Builtin.Helpfulness", "Builtin.Correctness"],
    "thresholds": {"Builtin.Helpfulness": 0.7, "Builtin.Correctness": 0.8},
    "baseline": {"enabled": True, "s3_uri": "s3://b/k.json", "max_regression": 0.05},
}


def _results(helpfulness: float, correctness: float) -> dict:
    return {
        "model-a": {
            "test1": {
                "Builtin.Helpfulness": {"score": helpfulness, "label": "Good"},
                "Builtin.Correctness": {"score": correctness, "label": "Good"},
            }
        }
    }


def test_all_pass():
    cfg = AgentQualifyConfig.model_validate(BASE_CONFIG)
    gate = CICDGate(cfg, _results(0.8, 0.9))
    result = gate.check()
    assert result.passed
    assert result.failures == []


def test_threshold_breach():
    cfg = AgentQualifyConfig.model_validate(BASE_CONFIG)
    gate = CICDGate(cfg, _results(0.65, 0.9))  # helpfulness below 0.7
    result = gate.check()
    assert not result.passed
    assert any(f["evaluator"] == "Builtin.Helpfulness" and f["type"] == "threshold" for f in result.failures)


def test_regression_breach():
    cfg = AgentQualifyConfig.model_validate(BASE_CONFIG)
    gate = CICDGate(cfg, _results(0.75, 0.85))
    baseline = {"scores": {"Builtin.Helpfulness": 0.85, "Builtin.Correctness": 0.86}}
    result = gate.check(baseline)
    # Helpfulness dropped 0.10 > max_regression 0.05
    assert not result.passed
    assert any(f["type"] == "regression" and f["evaluator"] == "Builtin.Helpfulness" for f in result.failures)


def test_regression_within_tolerance():
    cfg = AgentQualifyConfig.model_validate(BASE_CONFIG)
    gate = CICDGate(cfg, _results(0.82, 0.85))
    baseline = {"scores": {"Builtin.Helpfulness": 0.85, "Builtin.Correctness": 0.86}}
    result = gate.check(baseline)
    # Helpfulness dropped 0.03 < 0.05 — should pass
    assert result.passed


def test_build_baseline_data():
    cfg = AgentQualifyConfig.model_validate(BASE_CONFIG)
    gate = CICDGate(cfg, _results(0.8, 0.9))
    data = gate.build_baseline_data()
    assert abs(data["scores"]["Builtin.Helpfulness"] - 0.8) < 0.001
    assert abs(data["scores"]["Builtin.Correctness"] - 0.9) < 0.001
