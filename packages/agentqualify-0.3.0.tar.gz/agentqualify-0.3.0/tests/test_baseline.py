"""Tests for BaselineManager — S3 upload/download."""
import json
from unittest.mock import MagicMock, patch

import pytest

from agentqualify.baseline import BaselineManager


@patch("agentqualify.baseline.boto3.client")
def test_save_and_load(mock_boto):
    mock_s3 = MagicMock()
    mock_boto.return_value = mock_s3

    data = {"scores": {"Builtin.Helpfulness": 0.8}}
    mock_s3.get_object.return_value = {
        "Body": MagicMock(read=lambda: json.dumps(data).encode())
    }

    bm = BaselineManager("s3://my-bucket/baseline.json")
    bm.save(data)
    loaded = bm.load()

    assert mock_s3.put_object.called
    put_args = mock_s3.put_object.call_args[1]
    assert put_args["Bucket"] == "my-bucket"
    assert put_args["Key"] == "baseline.json"

    assert loaded == data


@patch("agentqualify.baseline.boto3.client")
def test_load_missing(mock_boto):
    mock_s3 = MagicMock()
    mock_boto.return_value = mock_s3
    mock_s3.exceptions.NoSuchKey = Exception
    mock_s3.get_object.side_effect = Exception("NoSuchKey")

    bm = BaselineManager("s3://bucket/missing.json")
    assert bm.load() is None


def test_invalid_s3_uri():
    with pytest.raises(ValueError):
        BaselineManager("not-an-s3-uri")
