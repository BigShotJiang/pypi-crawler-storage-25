"""Tests for config loading and validation."""
import pytest
from pydantic import ValidationError

from agentqualify.config import AgentQualifyConfig, load_test_suite

MINIMAL_CONFIG = {
    "agent": {
        "runtime_arn": "arn:aws:bedrock-agentcore:us-east-1:123456789012:agent-runtime/test",
    }
}


def test_minimal_config():
    cfg = AgentQualifyConfig.model_validate(MINIMAL_CONFIG)
    assert cfg.agent.agent_id == "test"  # derived from runtime_arn
    assert cfg.agent.region == "us-east-1"
    assert cfg.agent.span_wait_seconds == 180
    assert "Builtin.Helpfulness" in cfg.evaluators


def test_full_config():
    data = {
        **MINIMAL_CONFIG,
        "models": {
            "strategy": "qualifier",
            "variants": [
                {"name": "sonnet", "qualifier": "sonnet-ep"},
                {"name": "haiku", "qualifier": "haiku-ep"},
            ],
        },
        "thresholds": {"Builtin.Helpfulness": 0.7},
        "baseline": {"enabled": True, "s3_uri": "s3://bucket/baseline.json", "max_regression": 0.05},
        "reporting": {"cloudwatch": {"enabled": True, "namespace": "AgentQualify", "dashboard_name": "Test"}},
    }
    cfg = AgentQualifyConfig.model_validate(data)
    assert len(cfg.models.variants) == 2
    assert cfg.thresholds["Builtin.Helpfulness"] == 0.7
    assert cfg.baseline.s3_uri == "s3://bucket/baseline.json"


def test_qualifier_strategy_requires_qualifier():
    data = {
        **MINIMAL_CONFIG,
        "models": {
            "strategy": "qualifier",
            "variants": [{"name": "sonnet"}],  # missing qualifier
        },
    }
    with pytest.raises(ValidationError):
        AgentQualifyConfig.model_validate(data)


def test_load_test_suite(tmp_path):
    suite = tmp_path / "tests.yaml"
    suite.write_text("""
tests:
  - name: single
    prompt: "Hello"
  - name: multi
    prompts:
      - "Step 1"
      - "Step 2"
""")
    tests = load_test_suite(str(suite))
    assert len(tests) == 2
    assert tests[0].prompt == "Hello"
    assert tests[0].get_prompts() == ["Hello"]
    assert tests[1].prompts == ["Step 1", "Step 2"]
    assert tests[1].get_prompts() == ["Step 1", "Step 2"]


def test_test_case_requires_prompt():
    from agentqualify.config import TestCase
    with pytest.raises(ValidationError):
        TestCase.model_validate({"name": "bad"})


def test_test_case_with_ground_truth():
    from agentqualify.config import TestCase
    tc = TestCase.model_validate({
        "name": "gt_test",
        "prompt": "What is 2+2?",
        "expected_response": "4",
        "assertions": ["Response is a number"],
        "expected_trajectory": ["calculator"],
    })
    assert tc.expected_response == "4"
    assert tc.assertions == ["Response is a number"]
    assert tc.expected_trajectory == ["calculator"]
    assert tc.has_ground_truth()


def test_test_case_without_ground_truth():
    from agentqualify.config import TestCase
    tc = TestCase.model_validate({"name": "no_gt", "prompt": "Hello"})
    assert not tc.has_ground_truth()
    assert tc.expected_response is None
    assert tc.assertions is None
    assert tc.expected_trajectory is None


def test_test_case_turns_format():
    from agentqualify.config import TestCase
    tc = TestCase.model_validate({
        "name": "turns_test",
        "turns": [
            {"prompt": "What is 15+27?", "expected_response": "42"},
            {"prompt": "What's the weather?", "expected_response": "Sunny"},
        ],
        "expected_trajectory": ["calculator", "weather"],
    })
    assert tc.get_prompts() == ["What is 15+27?", "What's the weather?"]
    assert tc.get_per_turn_expected_responses() == ["42", "Sunny"]
    assert tc.has_ground_truth()


def test_test_case_turns_partial_expected_response():
    from agentqualify.config import TestCase
    tc = TestCase.model_validate({
        "name": "partial",
        "turns": [
            {"prompt": "Step 1"},
            {"prompt": "Step 2", "expected_response": "Done"},
        ],
    })
    assert tc.get_per_turn_expected_responses() == [None, "Done"]
    assert tc.has_ground_truth()


def test_test_case_prompts_with_top_level_expected_response():
    """Top-level expected_response maps to the last turn for legacy format."""
    from agentqualify.config import TestCase
    tc = TestCase.model_validate({
        "name": "legacy_multi",
        "prompts": ["Turn 1", "Turn 2"],
        "expected_response": "Final answer",
    })
    assert tc.get_per_turn_expected_responses() == [None, "Final answer"]


def test_extract_ground_truth():
    from agentqualify.config import TestCase, extract_ground_truth
    tests = [
        TestCase(name="with_gt", prompt="Q?", expected_response="A"),
        TestCase(name="no_gt", prompt="Hi"),
        TestCase(name="traj", prompt="Do it", expected_trajectory=["tool_a", "tool_b"]),
    ]
    gt_map = extract_ground_truth(tests)
    assert "with_gt" in gt_map
    assert gt_map["with_gt"].expected_responses == [None, "A"] or gt_map["with_gt"].expected_responses == ["A"]
    assert "no_gt" not in gt_map
    assert "traj" in gt_map
    assert gt_map["traj"].expected_trajectory == ["tool_a", "tool_b"]


def test_extract_ground_truth_turns():
    from agentqualify.config import TestCase, Turn, extract_ground_truth
    tests = [
        TestCase(
            name="multi",
            turns=[
                Turn(prompt="Q1", expected_response="A1"),
                Turn(prompt="Q2", expected_response="A2"),
            ],
            assertions=["Agent was helpful"],
        ),
    ]
    gt_map = extract_ground_truth(tests)
    assert "multi" in gt_map
    assert gt_map["multi"].expected_responses == ["A1", "A2"]
    assert gt_map["multi"].assertions == ["Agent was helpful"]


def test_load_test_suite_with_ground_truth(tmp_path):
    suite = tmp_path / "tests.yaml"
    suite.write_text("""
tests:
  - name: gt_test
    prompt: "What is the capital of France?"
    expected_response: "Paris"
    assertions:
      - "Response mentions Paris"
    expected_trajectory: ["lookup_capital"]
  - name: turns_test
    turns:
      - prompt: "What is 2+2?"
        expected_response: "4"
      - prompt: "What is 3+3?"
        expected_response: "6"
  - name: plain
    prompt: "Hello"
""")
    tests = load_test_suite(str(suite))
    assert len(tests) == 3
    assert tests[0].expected_response == "Paris"
    assert tests[0].has_ground_truth()
    assert tests[1].get_per_turn_expected_responses() == ["4", "6"]
    assert tests[1].has_ground_truth()
    assert not tests[2].has_ground_truth()
