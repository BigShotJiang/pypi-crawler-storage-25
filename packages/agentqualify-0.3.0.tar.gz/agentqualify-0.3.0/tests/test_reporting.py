"""Tests for CloudWatchReporter — metrics and dashboard."""
import json
from unittest.mock import MagicMock, patch

from agentqualify.config import AgentQualifyConfig
from agentqualify.reporting import CloudWatchReporter

CONFIG = {
    "agent": {"runtime_arn": "arn:aws:bedrock-agentcore:us-east-1:123:agent-runtime/a1", "region": "us-east-1"},
    "evaluators": ["Builtin.Helpfulness"],
    "reporting": {"cloudwatch": {"enabled": True, "namespace": "AgentQualify", "dashboard_name": "TestDash"}},
}

RESULTS = {
    "sonnet": {
        "test1": {
            "Builtin.Helpfulness": {
                "score": 0.85,
                "label": "Good",
                "token_usage": {"totalTokens": 500},
            }
        }
    }
}


@patch("agentqualify.reporting.boto3.client")
def test_publish_metrics(mock_boto):
    mock_cw = MagicMock()
    mock_boto.return_value = mock_cw

    cfg = AgentQualifyConfig.model_validate(CONFIG)
    reporter = CloudWatchReporter(cfg)
    reporter.publish_metrics(RESULTS)

    assert mock_cw.put_metric_data.called
    call_args = mock_cw.put_metric_data.call_args[1]
    assert call_args["Namespace"] == "AgentQualify"
    metrics = call_args["MetricData"]
    score_metric = next(m for m in metrics if m["MetricName"] == "EvaluatorScore")
    assert score_metric["Value"] == 0.85
    dims = {d["Name"]: d["Value"] for d in score_metric["Dimensions"]}
    assert dims["Model"] == "sonnet"
    assert dims["Evaluator"] == "Builtin.Helpfulness"


@patch("agentqualify.reporting.boto3.client")
def test_create_dashboard(mock_boto):
    mock_cw = MagicMock()
    mock_boto.return_value = mock_cw

    cfg = AgentQualifyConfig.model_validate(CONFIG)
    reporter = CloudWatchReporter(cfg)
    url = reporter.create_dashboard(RESULTS)

    assert mock_cw.put_dashboard.called
    call_args = mock_cw.put_dashboard.call_args[1]
    assert call_args["DashboardName"] == "TestDash"
    body = json.loads(call_args["DashboardBody"])
    assert "widgets" in body
    assert len(body["widgets"]) > 0
    assert "us-east-1" in url


@patch("agentqualify.reporting.boto3.client")
def test_disabled_reporting(mock_boto):
    mock_cw = MagicMock()
    mock_boto.return_value = mock_cw

    cfg_data = {**CONFIG, "reporting": {"cloudwatch": {"enabled": False}}}
    cfg = AgentQualifyConfig.model_validate(cfg_data)
    reporter = CloudWatchReporter(cfg)
    reporter.publish_metrics(RESULTS)
    reporter.create_dashboard(RESULTS)

    mock_cw.put_metric_data.assert_not_called()
    mock_cw.put_dashboard.assert_not_called()
