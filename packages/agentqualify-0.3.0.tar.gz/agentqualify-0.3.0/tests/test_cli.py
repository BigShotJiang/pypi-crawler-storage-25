"""Tests for CLI commands."""
from unittest.mock import MagicMock, patch

from click.testing import CliRunner

from agentqualify.cli import main


def _make_config_file(tmp_path):
    cfg = tmp_path / "agentqualify.yaml"
    cfg.write_text("""
agent:
  runtime_arn: "arn:aws:bedrock-agentcore:us-east-1:123:agent-runtime/a1"
  span_wait_seconds: 0
models:
  strategy: qualifier
  variants:
    - name: sonnet
      qualifier: DEFAULT
evaluators:
  - Builtin.Helpfulness
input:
  mode: sessions
  sessions:
    - session_id: "sess-123"
      name: "test1"
thresholds:
  Builtin.Helpfulness: 0.5
reporting:
  cloudwatch:
    enabled: false
""")
    return str(cfg)


MOCK_RESULTS = {
    "existing": {
        "test1": {
            "Builtin.Helpfulness": {"score": 0.8, "label": "Good", "error": None}
        }
    }
}


@patch("agentqualify.core.EvaluationRunner")
@patch("agentqualify.core.CloudWatchReporter")
def test_run_passes(mock_reporter_cls, mock_runner_cls, tmp_path):
    mock_runner = MagicMock()
    mock_runner.run.return_value = MOCK_RESULTS
    mock_runner_cls.return_value = mock_runner

    mock_reporter = MagicMock()
    mock_reporter.publish_metrics.return_value = None
    mock_reporter.create_dashboard.return_value = ""
    mock_reporter_cls.return_value = mock_reporter

    runner = CliRunner()
    result = runner.invoke(main, ["run", "--config", _make_config_file(tmp_path)])
    assert result.exit_code == 0
    assert "PASSED" in result.output


@patch("agentqualify.core.EvaluationRunner")
@patch("agentqualify.core.CloudWatchReporter")
def test_run_fails_threshold(mock_reporter_cls, mock_runner_cls, tmp_path):
    low_results = {
        "existing": {
            "test1": {
                "Builtin.Helpfulness": {"score": 0.3, "label": "Poor", "error": None}
            }
        }
    }
    mock_runner = MagicMock()
    mock_runner.run.return_value = low_results
    mock_runner_cls.return_value = mock_runner

    mock_reporter = MagicMock()
    mock_reporter.create_dashboard.return_value = ""
    mock_reporter_cls.return_value = mock_reporter

    runner = CliRunner()
    result = runner.invoke(main, ["run", "--config", _make_config_file(tmp_path)])
    assert result.exit_code == 1
    assert "FAILED" in result.output


def test_list_evaluators():
    runner = CliRunner()
    result = runner.invoke(main, ["list-evaluators"])
    assert result.exit_code == 0
    assert "Builtin.Helpfulness" in result.output
    assert "Builtin.GoalSuccessRate" in result.output
    # Trajectory evaluators (rich may truncate long names, so check partial)
    assert "TrajectoryExactOrder" in result.output
    assert "TrajectoryInOrderMatch" in result.output
    assert "TrajectoryAnyOrderMatch" in result.output
