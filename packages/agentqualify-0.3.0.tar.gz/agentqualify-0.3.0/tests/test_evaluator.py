"""Tests for EvaluationRunner — ground truth support and backward compatibility."""
from unittest.mock import MagicMock, patch

from agentqualify.config import AgentQualifyConfig, GroundTruth
from agentqualify.evaluator import BUILTIN_EVALUATORS, EvaluationRunner

CONFIG = {
    "agent": {"runtime_arn": "arn:aws:bedrock-agentcore:us-east-1:123:agent-runtime/a1", "region": "us-east-1"},
    "evaluators": ["Builtin.Helpfulness", "Builtin.Correctness"],
}

SESSION_MAP = {"model-a": {"test1": "sess-001"}}


def test_builtin_evaluators_include_trajectory():
    ids = {e["id"] for e in BUILTIN_EVALUATORS}
    assert "Builtin.TrajectoryExactOrderMatch" in ids
    assert "Builtin.TrajectoryInOrderMatch" in ids
    assert "Builtin.TrajectoryAnyOrderMatch" in ids


def test_builtin_evaluators_count():
    assert len(BUILTIN_EVALUATORS) == 16


def test_build_reference_inputs_empty_when_no_gt():
    refs = EvaluationRunner._build_reference_inputs("sess-001", None)
    assert refs == []

    refs = EvaluationRunner._build_reference_inputs("sess-001", GroundTruth())
    assert refs == []


def test_build_reference_inputs_with_expected_response():
    """expectedResponse is sent when trace_ids are available."""
    gt = GroundTruth(expected_responses=["Paris"])
    # Without trace_ids — no expectedResponse
    refs = EvaluationRunner._build_reference_inputs("sess-001", gt)
    assert refs == []

    # With trace_ids — expectedResponse scoped to last trace
    refs = EvaluationRunner._build_reference_inputs(
        "sess-001", gt, trace_ids=["trace-abc"],
    )
    assert len(refs) == 1
    assert refs[0]["expectedResponse"] == {"text": "Paris"}
    assert refs[0]["context"]["spanContext"]["traceId"] == "trace-abc"
    assert refs[0]["context"]["spanContext"]["sessionId"] == "sess-001"


def test_build_reference_inputs_with_per_turn_responses():
    gt = GroundTruth(expected_responses=[None, "42", "Sunny"])
    refs = EvaluationRunner._build_reference_inputs(
        "sess-001", gt, trace_ids=["t1", "t2", "t3"],
    )
    # Last non-null response mapped to last trace
    resp_refs = [r for r in refs if "expectedResponse" in r]
    assert len(resp_refs) == 1
    assert resp_refs[0]["expectedResponse"] == {"text": "Sunny"}
    assert resp_refs[0]["context"]["spanContext"]["traceId"] == "t3"


def test_build_reference_inputs_with_assertions():
    gt = GroundTruth(assertions=["Agent was polite", "Agent used tool X"])
    refs = EvaluationRunner._build_reference_inputs("sess-001", gt)
    assert len(refs) == 1
    assert refs[0]["assertions"] == [
        {"text": "Agent was polite"},
        {"text": "Agent used tool X"},
    ]
    assert refs[0]["context"]["spanContext"]["sessionId"] == "sess-001"


def test_build_reference_inputs_with_trajectory():
    gt = GroundTruth(expected_trajectory=["search", "book"])
    refs = EvaluationRunner._build_reference_inputs("sess-001", gt)
    assert len(refs) == 1
    assert refs[0]["expectedTrajectory"] == {"toolNames": ["search", "book"]}
    assert refs[0]["context"]["spanContext"]["sessionId"] == "sess-001"


def test_build_reference_inputs_all_fields():
    """All ground truth fields sent when trace_ids are available."""
    gt = GroundTruth(
        expected_responses=["Booked flight"],
        assertions=["Confirmed before booking"],
        expected_trajectory=["search_flights", "book_flight"],
    )
    refs = EvaluationRunner._build_reference_inputs(
        "sess-001", gt, trace_ids=["t1"],
    )
    assert len(refs) == 2

    # Session-level: assertions + trajectory
    session_ref = refs[0]
    assert "expectedResponse" not in session_ref
    assert len(session_ref["assertions"]) == 1
    assert session_ref["expectedTrajectory"]["toolNames"] == [
        "search_flights", "book_flight",
    ]

    # Trace-level: expectedResponse
    trace_ref = refs[1]
    assert trace_ref["expectedResponse"] == {"text": "Booked flight"}
    assert trace_ref["context"]["spanContext"]["traceId"] == "t1"


def test_build_reference_inputs_ignores_all_none_responses():
    gt = GroundTruth(expected_responses=[None, None])
    refs = EvaluationRunner._build_reference_inputs("sess-001", gt)
    assert refs == []


@patch("agentqualify.evaluator.boto3.client")
def test_run_without_ground_truth(mock_boto):
    """Backward compatibility: run() works fine with no ground truth."""
    mock_client = MagicMock()
    mock_boto.return_value = mock_client
    mock_client.evaluate.return_value = {
        "evaluationResults": [{
            "evaluatorId": "Builtin.Helpfulness",
            "evaluatorName": "Builtin.Helpfulness",
            "value": 0.85,
            "label": "Good",
            "explanation": "Helpful response",
        }]
    }

    cfg = AgentQualifyConfig.model_validate(CONFIG)
    runner = EvaluationRunner(cfg)
    runner._fetch_spans = MagicMock(return_value=[{"mock": "span"}])
    # No ground_truth_map — should work exactly as before
    results = runner.run(SESSION_MAP)

    assert "model-a" in results
    assert "test1" in results["model-a"]
    assert results["model-a"]["test1"]["Builtin.Helpfulness"]["score"] == 0.85

    # Verify evaluate was called WITHOUT evaluationReferenceInputs
    call_kwargs = mock_client.evaluate.call_args_list[0][1]
    assert "evaluationReferenceInputs" not in call_kwargs


@patch("agentqualify.evaluator.boto3.client")
def test_run_with_ground_truth(mock_boto):
    """Ground truth including expectedResponse is passed with trace-level scoping."""
    mock_client = MagicMock()
    mock_boto.return_value = mock_client
    mock_client.evaluate.return_value = {
        "evaluationResults": [{
            "evaluatorId": "Builtin.Correctness",
            "evaluatorName": "Builtin.Correctness",
            "value": 0.95,
            "label": "Correct",
            "explanation": "Matches expected response",
        }]
    }

    cfg = AgentQualifyConfig.model_validate({
        **CONFIG,
        "evaluators": ["Builtin.Correctness"],
    })
    runner = EvaluationRunner(cfg)
    # Provide a root span + its matching event so it passes the incomplete filter
    runner._fetch_spans = MagicMock(return_value=[
        {"traceId": "trace-123", "spanId": "span-1", "name": "InvokeAgent",
         "scope": {"name": "strands.telemetry.tracer"}},
        {"traceId": "trace-123", "spanId": "span-1",
         "scope": {"name": "strands.telemetry.tracer"},
         "attributes": {"event.name": "input", "session.id": "sess-001"},
         "body": {"input": {"messages": []}}},
    ])
    gt_map = {"test1": GroundTruth(
        expected_responses=["Paris"],
        assertions=["Agent answered correctly"],
    )}
    results = runner.run(SESSION_MAP, ground_truth_map=gt_map)

    assert results["model-a"]["test1"]["Builtin.Correctness"]["score"] == 0.95

    call_kwargs = mock_client.evaluate.call_args_list[0][1]
    assert "evaluationReferenceInputs" in call_kwargs
    refs = call_kwargs["evaluationReferenceInputs"]
    # Session-level ref (assertions) + trace-level ref (expectedResponse)
    assert len(refs) == 2
    session_ref = refs[0]
    assert "assertions" in session_ref
    assert "expectedResponse" not in session_ref
    trace_ref = refs[1]
    assert trace_ref["expectedResponse"] == {"text": "Paris"}
    assert trace_ref["context"]["spanContext"]["traceId"] == "trace-123"


@patch("agentqualify.evaluator.boto3.client")
def test_run_gt_only_sent_to_supported_evaluators(mock_boto):
    """Ground truth fields are only sent to evaluators that support them."""
    mock_client = MagicMock()
    mock_boto.return_value = mock_client
    mock_client.evaluate.return_value = {
        "evaluationResults": [{
            "evaluatorId": "test",
            "evaluatorName": "test",
            "value": 0.8,
            "label": "Good",
        }]
    }

    cfg = AgentQualifyConfig.model_validate({
        **CONFIG,
        "evaluators": ["Builtin.Helpfulness", "Builtin.Correctness"],
    })
    runner = EvaluationRunner(cfg)
    runner._fetch_spans = MagicMock(return_value=[
        {"traceId": "t1", "spanId": "s1", "name": "InvokeAgent",
         "scope": {"name": "strands.telemetry.tracer"}},
        {"traceId": "t1", "spanId": "s1",
         "scope": {"name": "strands.telemetry.tracer"},
         "attributes": {"event.name": "input", "session.id": "sess-001"},
         "body": {"input": {"messages": []}}},
    ])
    gt_map = {"test1": GroundTruth(assertions=["Agent answered correctly"])}
    runner.run(SESSION_MAP, ground_truth_map=gt_map)

    # Helpfulness call should NOT have reference inputs
    helpfulness_call = mock_client.evaluate.call_args_list[0][1]
    assert helpfulness_call["evaluatorId"] == "Builtin.Helpfulness"
    assert "evaluationReferenceInputs" not in helpfulness_call

    # Correctness call SHOULD have reference inputs (assertions)
    correctness_call = mock_client.evaluate.call_args_list[1][1]
    assert correctness_call["evaluatorId"] == "Builtin.Correctness"
    assert "evaluationReferenceInputs" in correctness_call


@patch("agentqualify.evaluator.boto3.client")
def test_run_captures_ignored_fields(mock_boto):
    """ignoredReferenceInputFields from the API is captured in results."""
    mock_client = MagicMock()
    mock_boto.return_value = mock_client
    mock_client.evaluate.return_value = {
        "evaluationResults": [{
            "evaluatorId": "Builtin.Helpfulness",
            "evaluatorName": "Builtin.Helpfulness",
            "value": 0.83,
            "label": "Very Helpful",
            "ignoredReferenceInputFields": ["expectedResponse"],
        }]
    }

    cfg = AgentQualifyConfig.model_validate({
        **CONFIG,
        "evaluators": ["Builtin.Helpfulness"],
    })
    runner = EvaluationRunner(cfg)
    runner._fetch_spans = MagicMock(return_value=[{"mock": "span"}])
    results = runner.run(SESSION_MAP)

    r = results["model-a"]["test1"]["Builtin.Helpfulness"]
    assert r["ignored_fields"] == ["expectedResponse"]
