"""CloudWatch metrics publisher and dashboard generator."""
from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any

import boto3

from agentqualify.config import AgentQualifyConfig
from agentqualify.evaluator import EvalResults


class CloudWatchReporter:
    def __init__(self, config: AgentQualifyConfig):
        self.config = config
        self.cw_cfg = config.reporting.cloudwatch
        self._cw = boto3.client("cloudwatch", region_name=config.agent.region)

    def publish_metrics(self, results: EvalResults) -> None:
        """Publish evaluation scores as CloudWatch custom metrics."""
        if not self.cw_cfg.enabled:
            return

        namespace = self.cw_cfg.namespace
        now = datetime.now(timezone.utc)
        metric_data: list[dict[str, Any]] = []

        for model_name, test_results in results.items():
            for test_name, evaluator_results in test_results.items():
                for evaluator_id, result in evaluator_results.items():
                    score = result.get("score")
                    if score is None:
                        continue
                    # Per-test metric (3 dimensions)
                    metric_data.append({
                        "MetricName": "EvaluatorScore",
                        "Timestamp": now,
                        "Value": score,
                        "Unit": "None",
                        "Dimensions": [
                            {"Name": "Model", "Value": model_name},
                            {"Name": "Evaluator", "Value": evaluator_id},
                            {"Name": "TestCase", "Value": test_name},
                        ],
                    })
                    # Aggregate metric (2 dimensions, no TestCase)
                    # for summary dashboard widgets
                    metric_data.append({
                        "MetricName": "EvaluatorScore",
                        "Timestamp": now,
                        "Value": score,
                        "Unit": "None",
                        "Dimensions": [
                            {"Name": "Model", "Value": model_name},
                            {"Name": "Evaluator", "Value": evaluator_id},
                        ],
                    })
                    # Token usage
                    token_usage = result.get("token_usage")
                    if token_usage and isinstance(token_usage, dict):
                        total = (
                            token_usage.get("totalTokens")
                            or token_usage.get("total_tokens")
                        )
                        if total:
                            metric_data.append({
                                "MetricName": "TokenUsage",
                                "Timestamp": now,
                                "Value": total,
                                "Unit": "Count",
                                "Dimensions": [
                                    {"Name": "Model", "Value": model_name},
                                    {"Name": "Evaluator", "Value": evaluator_id},
                                ],
                            })

        # CloudWatch accepts max 1000 metrics per call; batch in 20s
        for i in range(0, len(metric_data), 20):
            self._cw.put_metric_data(
                Namespace=namespace,
                MetricData=metric_data[i:i + 20],
            )

    def create_dashboard(self, results: EvalResults) -> str:
        """Create/update a CloudWatch dashboard. Returns the dashboard URL."""
        if not self.cw_cfg.enabled:
            return ""

        namespace = self.cw_cfg.namespace
        dashboard_name = self.cw_cfg.dashboard_name
        region = self.config.agent.region
        models = list(results.keys())
        evaluators = self.config.evaluators

        widgets = []
        x, y = 0, 0

        # ── Widget 1: Score comparison (metric widget per evaluator) ──
        for evaluator_id in evaluators:
            metrics = []
            for model_name in models:
                metrics.append([
                    namespace,
                    "EvaluatorScore",
                    "Model", model_name,
                    "Evaluator", evaluator_id,
                    {"label": model_name, "stat": "Average"},
                ])
            widgets.append({
                "type": "metric",
                "x": x, "y": y, "width": 12, "height": 6,
                "properties": {
                    "title": f"Score: {evaluator_id}",
                    "metrics": metrics,
                    "view": "timeSeries",
                    "stat": "Average",
                    "period": 300,
                    "region": region,
                    "yAxis": {"left": {"min": 0, "max": 1}},
                },
            })
            x = (x + 12) % 24
            if x == 0:
                y += 6

        # ── Widget 2: Per-model average score bar chart ──
        all_model_metrics = []
        for model_name in models:
            for evaluator_id in evaluators:
                all_model_metrics.append([
                    namespace,
                    "EvaluatorScore",
                    "Model", model_name,
                    "Evaluator", evaluator_id,
                    {"label": f"{model_name}/{evaluator_id}", "stat": "Average"},
                ])
        if all_model_metrics:
            widgets.append({
                "type": "metric",
                "x": 0, "y": y, "width": 24, "height": 6,
                "properties": {
                    "title": "All Models — Evaluator Scores",
                    "metrics": all_model_metrics,
                    "view": "bar",
                    "stat": "Average",
                    "period": 86400,
                    "region": region,
                    "yAxis": {"left": {"min": 0, "max": 1}},
                },
            })
            y += 6

        # ── Widget 3: Token usage per model ──
        token_metrics = []
        for model_name in models:
            for evaluator_id in evaluators:
                token_metrics.append([
                    namespace,
                    "TokenUsage",
                    "Model", model_name,
                    "Evaluator", evaluator_id,
                    {"label": f"{model_name}/{evaluator_id}", "stat": "Sum"},
                ])
        if token_metrics:
            widgets.append({
                "type": "metric",
                "x": 0, "y": y, "width": 12, "height": 6,
                "properties": {
                    "title": "Token Usage by Model",
                    "metrics": token_metrics,
                    "view": "bar",
                    "stat": "Sum",
                    "period": 86400,
                    "region": region,
                },
            })

        # ── Widget 4: Per-test-case score breakdown ──
        test_names = list({
            test_name
            for model_results in results.values()
            for test_name in model_results
        })
        for test_name in test_names[:4]:  # limit to 4 test cases to avoid dashboard overflow
            test_metrics = []
            for model_name in models:
                for evaluator_id in evaluators:
                    test_metrics.append([
                        namespace,
                        "EvaluatorScore",
                        "Model", model_name,
                        "Evaluator", evaluator_id,
                        "TestCase", test_name,
                        {"label": f"{model_name}/{evaluator_id}", "stat": "Average"},
                    ])
            if test_metrics:
                widgets.append({
                    "type": "metric",
                    "x": 12, "y": y, "width": 12, "height": 6,
                    "properties": {
                        "title": f"Test: {test_name}",
                        "metrics": test_metrics,
                        "view": "bar",
                        "stat": "Average",
                        "period": 86400,
                        "region": region,
                        "yAxis": {"left": {"min": 0, "max": 1}},
                    },
                })
                y += 6

        dashboard_body = json.dumps({"widgets": widgets})
        self._cw.put_dashboard(DashboardName=dashboard_name, DashboardBody=dashboard_body)

        return (
            f"https://{region}.console.aws.amazon.com/cloudwatch/home"
            f"?region={region}#dashboards:name={dashboard_name}"
        )
