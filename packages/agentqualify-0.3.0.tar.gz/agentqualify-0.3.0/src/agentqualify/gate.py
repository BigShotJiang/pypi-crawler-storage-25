"""CI/CD gate — threshold and regression checks on evaluation results."""
from __future__ import annotations

from typing import Any

from agentqualify.config import AgentQualifyConfig
from agentqualify.evaluator import EvalResults


class GateResult:
    def __init__(self, passed: bool, failures: list[dict[str, Any]]):
        self.passed = passed
        self.failures = failures

    def __repr__(self):
        return f"GateResult(passed={self.passed}, failures={len(self.failures)})"


def _avg_score(results: EvalResults, evaluator_id: str) -> float | None:
    """Compute average score for an evaluator across all models and tests."""
    scores = []
    for model_results in results.values():
        for test_results in model_results.values():
            r = test_results.get(evaluator_id)
            if r and r.get("score") is not None:
                scores.append(r["score"])
    return sum(scores) / len(scores) if scores else None


def _collect_errors(results: EvalResults, evaluator_id: str) -> list[str]:
    """Collect distinct error messages for an evaluator across all results."""
    errors: list[str] = []
    seen: set = set()
    for model_results in results.values():
        for test_results in model_results.values():
            r = test_results.get(evaluator_id)
            if r and r.get("error") and r["error"] not in seen:
                seen.add(r["error"])
                errors.append(r["error"])
    return errors


class CICDGate:
    def __init__(self, config: AgentQualifyConfig, results: EvalResults):
        self.config = config
        self.results = results

    def check(self, baseline: dict | None = None) -> GateResult:
        failures: list[dict[str, Any]] = []

        # 1. Threshold checks
        for evaluator_id, threshold in self.config.thresholds.items():
            score = _avg_score(self.results, evaluator_id)
            if score is None:
                errors = _collect_errors(self.results, evaluator_id)
                reason = "No score available"
                if errors:
                    reason += " — " + "; ".join(errors)
                failures.append({
                    "type": "threshold",
                    "evaluator": evaluator_id,
                    "reason": reason,
                    "score": None,
                    "threshold": threshold,
                })
            elif score < threshold:
                failures.append({
                    "type": "threshold",
                    "evaluator": evaluator_id,
                    "reason": f"Score {score:.3f} below threshold {threshold}",
                    "score": score,
                    "threshold": threshold,
                })

        # 2. Regression checks against baseline
        if baseline and self.config.baseline.enabled:
            max_drop = self.config.baseline.max_regression
            for evaluator_id in self.config.evaluators:
                current = _avg_score(self.results, evaluator_id)
                base_score = baseline.get("scores", {}).get(evaluator_id)
                if current is not None and base_score is not None:
                    drop = base_score - current
                    if drop > max_drop:
                        failures.append({
                            "type": "regression",
                            "evaluator": evaluator_id,
                            "reason": f"Score dropped {drop:.3f} (max allowed: {max_drop})",
                            "score": current,
                            "baseline_score": base_score,
                            "drop": drop,
                        })

        return GateResult(passed=len(failures) == 0, failures=failures)

    def build_baseline_data(self) -> dict:
        """Build baseline dict from current results for saving to S3."""
        scores = {}
        for evaluator_id in self.config.evaluators:
            score = _avg_score(self.results, evaluator_id)
            if score is not None:
                scores[evaluator_id] = score
        return {"scores": scores}
