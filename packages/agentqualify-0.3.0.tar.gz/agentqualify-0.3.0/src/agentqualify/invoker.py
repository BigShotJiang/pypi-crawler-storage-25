"""Invoke AgentCore agent runtime per model variant and collect session IDs."""
from __future__ import annotations

import json
import logging
import time
import uuid
from urllib.parse import quote, urlencode
from urllib.request import Request, urlopen

import boto3

from agentqualify.config import AgentQualifyConfig, OAuthConfig, TestCase

logger = logging.getLogger(__name__)

# SessionMap: {model_name: {test_name: session_id}}
SessionMap = dict[str, dict[str, str]]

# Refresh the token 60 seconds before it actually expires so we never
# hit the API with a stale token mid-request.
_TOKEN_EXPIRY_BUFFER_SECS = 60


class TokenProvider:
    """Fetches and caches an OAuth access token using the client credentials grant.

    The token is automatically refreshed when it is within
    ``_TOKEN_EXPIRY_BUFFER_SECS`` of expiry.
    """

    def __init__(self, oauth_config: OAuthConfig):
        self._oauth = oauth_config
        self._access_token: str | None = None
        self._expires_at: float = 0.0  # epoch seconds

    def get_token(self) -> str:
        """Return a valid access token, refreshing if necessary."""
        if self._access_token and time.time() < self._expires_at:
            return self._access_token

        logger.debug("Fetching new OAuth token from %s", self._oauth.token_url)
        self._access_token, expires_in = self._fetch_token()
        self._expires_at = time.time() + expires_in - _TOKEN_EXPIRY_BUFFER_SECS
        logger.info("OAuth token acquired (expires in %ds)", expires_in)
        return self._access_token

    def _fetch_token(self) -> tuple[str, int]:
        """Execute the OAuth2 client_credentials grant and return (token, expires_in)."""
        form: dict[str, str] = {
            "grant_type": "client_credentials",
            "client_id": self._oauth.resolve_client_id(),
            "client_secret": self._oauth.resolve_client_secret(),
        }
        if self._oauth.scopes:
            form["scope"] = " ".join(self._oauth.scopes)

        body = urlencode(form).encode("utf-8")
        req = Request(  # noqa: S310
            self._oauth.token_url,
            data=body,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            method="POST",
        )
        try:
            with urlopen(req) as resp:  # noqa: S310
                data = json.loads(resp.read())
        except Exception as e:
            raise RuntimeError(f"Failed to fetch OAuth token from {self._oauth.token_url}: {e}") from e

        access_token = data.get("access_token")
        if not access_token:
            raise RuntimeError(f"OAuth token response missing 'access_token': {data}")

        expires_in = int(data.get("expires_in", 3600))
        return access_token, expires_in


class AgentInvoker:
    def __init__(self, config: AgentQualifyConfig):
        self.config = config
        self._client_cache: dict[str, object] = {}
        self._token_provider: TokenProvider | None = None

        if config.agent.auth.type == "oauth" and config.agent.auth.oauth:
            self._token_provider = TokenProvider(config.agent.auth.oauth)

    def _client(self, runtime_arn: str) -> object:
        if runtime_arn not in self._client_cache:
            self._client_cache[runtime_arn] = boto3.client(
                "bedrock-agentcore", region_name=self.config.agent.region
            )
        return self._client_cache[runtime_arn]

    def _build_arn(self, variant_runtime_arn: str | None) -> str:
        return variant_runtime_arn or self.config.agent.runtime_arn

    def _build_qualifier(self, qualifier: str | None) -> str:
        return qualifier or "DEFAULT"

    def _invoke_single(
        self,
        runtime_arn: str,
        qualifier: str,
        session_id: str,
        payload: dict,
    ) -> None:
        if self.config.agent.auth.type == "oauth":
            self._invoke_single_oauth(runtime_arn, qualifier, session_id, payload)
        else:
            self._invoke_single_sigv4(runtime_arn, qualifier, session_id, payload)

    def _invoke_single_sigv4(
        self,
        runtime_arn: str,
        qualifier: str,
        session_id: str,
        payload: dict,
    ) -> None:
        """Invoke via boto3 SDK using IAM SigV4 authentication."""
        client = self._client(runtime_arn)
        client.invoke_agent_runtime(
            agentRuntimeArn=runtime_arn,
            qualifier=qualifier,
            runtimeSessionId=session_id,
            payload=json.dumps(payload).encode(),
            contentType="application/json",
            accept="application/json",
        )

    def _invoke_single_oauth(
        self,
        runtime_arn: str,
        qualifier: str,
        session_id: str,
        payload: dict,
    ) -> None:
        """Invoke via HTTPS with an auto-managed OAuth Bearer token.

        When an agent runtime is configured with JWT inbound auth, the
        boto3 SDK (SigV4) cannot be used. Instead we make a direct HTTPS
        POST to the InvokeAgentRuntime endpoint with an Authorization
        header carrying the Bearer token. The token is automatically
        fetched and refreshed by the TokenProvider.
        """
        assert self._token_provider is not None
        region = self.config.agent.region
        bearer_token = self._token_provider.get_token()
        encoded_arn = quote(runtime_arn, safe="")

        url = (
            f"https://bedrock-agentcore.{region}.amazonaws.com"
            f"/runtimes/{encoded_arn}/invocations"
        )
        if qualifier:
            url += f"?qualifier={quote(qualifier, safe='')}"

        body = json.dumps(payload).encode("utf-8")

        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Authorization": f"Bearer {bearer_token}",
            "X-Amzn-Bedrock-AgentCore-Runtime-Session-Id": session_id,
        }

        req = Request(url, data=body, headers=headers, method="POST")  # noqa: S310
        try:
            with urlopen(req) as resp:  # noqa: S310
                # Read and discard the response body (we only need the session to be created)
                resp.read()
        except Exception as e:
            raise RuntimeError(
                f"OAuth invocation failed for {runtime_arn}: {e}"
            ) from e

    def _invoke_test(self, test: TestCase, runtime_arn: str, qualifier: str, extra_payload: dict) -> str:
        """Invoke a test case (single or multi-turn) and return the session ID."""
        session_id = f"agentqualify-{uuid.uuid4().hex}"
        prompts = test.get_prompts()
        for prompt in prompts:
            payload = {"prompt": prompt, **extra_payload}
            self._invoke_single(runtime_arn, qualifier, session_id, payload)
        return session_id

    def invoke_all(self, tests: list[TestCase]) -> SessionMap:
        """
        Invoke all test cases for each model variant.
        Returns {model_name: {test_name: session_id}}.
        """
        cfg = self.config
        results: SessionMap = {}

        if cfg.agent.auth.type == "oauth":
            logger.info("Using OAuth (client credentials) for agent invocation")
            # Acquire token eagerly so the log appears before test invocations
            assert self._token_provider is not None
            self._token_provider.get_token()
        else:
            logger.info("Using IAM SigV4 for agent invocation")

        for variant in cfg.models.variants:
            model_sessions: dict[str, str] = {}

            # Resolve ARN, qualifier, and extra payload per strategy
            if cfg.models.strategy == "qualifier":
                runtime_arn = self._build_arn(None)
                qualifier = self._build_qualifier(variant.qualifier)
                extra_payload: dict = {}
            elif cfg.models.strategy == "payload":
                runtime_arn = self._build_arn(None)
                qualifier = "DEFAULT"
                extra_payload = variant.payload_override or {}
            else:  # separate_runtimes
                runtime_arn = self._build_arn(variant.runtime_arn)
                qualifier = "DEFAULT"
                extra_payload = {}

            for i, test in enumerate(tests, 1):
                logger.info("[%s] Invoking test %d/%d: %s", variant.name, i, len(tests), test.name)
                session_id = self._invoke_test(test, runtime_arn, qualifier, extra_payload)
                model_sessions[test.name] = session_id

            results[variant.name] = model_sessions

        total_sessions = sum(len(s) for s in results.values())
        logger.info("All invocations complete: %d session(s) across %d model variant(s)",
                     total_sessions, len(results))

        # Wait for spans to propagate to CloudWatch
        wait = cfg.agent.span_wait_seconds
        if wait > 0:
            logger.info("Waiting %ds for spans to propagate to CloudWatch...", wait)
            interval = 10
            remaining = wait
            while remaining > 0:
                step = min(interval, remaining)
                time.sleep(step)
                remaining -= step
                if remaining > 0:
                    logger.info("  %ds remaining...", remaining)
            logger.info("Span wait complete")

        return results
