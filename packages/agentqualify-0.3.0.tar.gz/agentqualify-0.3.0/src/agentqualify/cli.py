"""AgentQualify CLI — agentqualify run / baseline update / baseline show."""
from __future__ import annotations

import json
import logging
import sys

import click
from rich.console import Console
from rich.table import Table

console = Console()


def _setup_logging(verbose: bool):
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        level=level,
    )


@click.group()
@click.version_option(package_name="agentqualify")
def main():
    """AgentQualify — evaluate AI agents with AWS AgentCore Evaluations."""


@main.command()
@click.option("--config", "-c", default="agentqualify.yaml", show_default=True, help="Path to config YAML")
@click.option("--output-json", "-o", default=None, help="Write full results to a JSON file")
@click.option("--update-baseline", is_flag=True, help="Save results as the new S3 baseline after a passing run")
@click.option("--verbose", "-v", is_flag=True)
def run(config: str, output_json: str | None, update_baseline: bool, verbose: bool):
    """Run evaluations and check CI/CD gate."""
    _setup_logging(verbose)
    from agentqualify.core import AgentQualify

    try:
        scorer = AgentQualify(config_path=config)
        result = scorer.run()
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(2)

    # Write JSON output if requested
    if output_json:
        from pathlib import Path

        Path(output_json).write_text(
            json.dumps(result.to_dict(), indent=2, default=str)
        )
        console.print(f"\nResults written to [bold]{output_json}[/bold]")

    # Print results table
    table = Table(title="AgentQualify Results", show_lines=True)
    table.add_column("Model", style="cyan")
    table.add_column("Test Case", style="magenta")
    table.add_column("Evaluator", style="yellow")
    table.add_column("Score", justify="right")
    table.add_column("Label")
    table.add_column("Status")

    for model_name, test_results in result.results.items():
        for test_name, evaluator_results in test_results.items():
            for eid, r in evaluator_results.items():
                score = r.get("score")
                label = r.get("label") or ""
                err = r.get("error")
                if err:
                    status = f"[red]ERROR: {err}[/red]"
                    score_str = "—"
                else:
                    score_str = f"{score:.3f}" if score is not None else "—"
                    # Check threshold
                    threshold = scorer.config.thresholds.get(eid)
                    if threshold and score is not None and score < threshold:
                        status = f"[red]FAIL (< {threshold})[/red]"
                    else:
                        status = "[green]PASS[/green]"
                table.add_row(model_name, test_name, eid, score_str, label, status)

    console.print(table)

    if result.dashboard_url:
        console.print(f"\n[bold]Dashboard:[/bold] {result.dashboard_url}")

    if result.failures:
        console.print("\n[bold red]Gate Failures:[/bold red]")
        for f in result.failures:
            console.print(f"  • [{f['type']}] {f['evaluator']}: {f['reason']}")

    if result.passed:
        console.print("\n[bold green]✅ PASSED[/bold green]")
        if update_baseline:
            try:
                from agentqualify.gate import CICDGate
                from agentqualify.baseline import BaselineManager
                cfg = scorer.config
                if not cfg.baseline.s3_uri:
                    console.print("[yellow]Warning: baseline.s3_uri not set — skipping baseline update.[/yellow]")
                else:
                    gate = CICDGate(cfg, result.results)
                    bm = BaselineManager(cfg.baseline.s3_uri, cfg.agent.region)
                    bm.save(gate.build_baseline_data())
                    console.print(f"[green]Baseline saved to {cfg.baseline.s3_uri}[/green]")
            except Exception as e:
                console.print(f"[yellow]Warning: baseline update failed:[/yellow] {e}")
        sys.exit(0)
    else:
        console.print("\n[bold red]❌ FAILED[/bold red]")
        sys.exit(1)


@main.group()
def baseline():
    """Manage evaluation baselines stored in S3."""


@baseline.command("update")
@click.option("--config", "-c", default="agentqualify.yaml", show_default=True)
@click.option("--verbose", "-v", is_flag=True)
def baseline_update(config: str, verbose: bool):
    """Run evaluation and save results as the new S3 baseline."""
    _setup_logging(verbose)
    from agentqualify.core import AgentQualify

    try:
        AgentQualify(config_path=config).update_baseline()
        console.print("[green]Baseline updated successfully.[/green]")
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        sys.exit(2)


@baseline.command("show")
@click.option("--config", "-c", default="agentqualify.yaml", show_default=True)
def baseline_show(config: str):
    """Download and display the current S3 baseline."""
    from agentqualify.baseline import BaselineManager
    from agentqualify.config import load_config

    cfg = load_config(config)
    if not cfg.baseline.s3_uri:
        console.print("[red]baseline.s3_uri not configured.[/red]")
        sys.exit(2)

    bm = BaselineManager(cfg.baseline.s3_uri, cfg.agent.region)
    data = bm.load()
    if data is None:
        console.print("[yellow]No baseline found at:[/yellow]", cfg.baseline.s3_uri)
        sys.exit(0)

    console.print(json.dumps(data, indent=2))


@main.command("list-evaluators")
def list_evaluators():
    """List all available built-in evaluators."""
    from agentqualify.evaluator import BUILTIN_EVALUATORS
    table = Table(title="Built-in Evaluators", show_lines=True)
    table.add_column("ID", style="cyan")
    table.add_column("Level", style="yellow")
    table.add_column("Description")
    for e in BUILTIN_EVALUATORS:
        table.add_row(e["id"], e["level"], e["description"])
    console.print(table)
