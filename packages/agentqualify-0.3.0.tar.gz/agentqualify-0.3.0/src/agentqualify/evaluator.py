"""Run AgentCore evaluations on collected sessions."""
from __future__ import annotations

import logging
from typing import Any

import boto3

from agentqualify.config import AgentQualifyConfig, GroundTruth, GroundTruthMap
from agentqualify.invoker import SessionMap

BUILTIN_EVALUATORS = [
    {
        "id": "Builtin.GoalSuccessRate",
        "level": "session",
        "description": "Assesses whether all user goals were successfully completed",
    },
    {
        "id": "Builtin.Helpfulness",
        "level": "trace",
        "description": "Assesses how effectively the response helps users progress toward their goals",
    },
    {
        "id": "Builtin.Correctness",
        "level": "trace",
        "description": "Assesses factual accuracy and correctness of the response",
    },
    {
        "id": "Builtin.Coherence",
        "level": "trace",
        "description": "Assesses logical consistency and cohesion of the response",
    },
    {
        "id": "Builtin.Conciseness",
        "level": "trace",
        "description": "Measures how efficiently information is communicated",
    },
    {
        "id": "Builtin.Faithfulness",
        "level": "trace",
        "description": "Assesses consistency with conversation history",
    },
    {
        "id": "Builtin.Harmfulness",
        "level": "trace",
        "description": "Detects potentially harmful content",
    },
    {
        "id": "Builtin.InstructionFollowing",
        "level": "trace",
        "description": "Assesses adherence to explicit instructions",
    },
    {
        "id": "Builtin.Refusal",
        "level": "trace",
        "description": "Detects when the assistant declines requests",
    },
    {
        "id": "Builtin.ResponseRelevance",
        "level": "trace",
        "description": "Assesses how well the response addresses the request",
    },
    {
        "id": "Builtin.Stereotyping",
        "level": "trace",
        "description": "Detects bias and stereotypical content",
    },
    {
        "id": "Builtin.ToolSelectionAccuracy",
        "level": "tool",
        "description": "Assesses whether the appropriate tool was chosen",
    },
    {
        "id": "Builtin.ToolParameterAccuracy",
        "level": "tool",
        "description": "Assesses whether tool parameters are correctly used",
    },
    {
        "id": "Builtin.TrajectoryExactOrderMatch",
        "level": "session",
        "description": "Actual trajectory must match expected exactly",
    },
    {
        "id": "Builtin.TrajectoryInOrderMatch",
        "level": "session",
        "description": "Expected tools must appear in order, extras allowed",
    },
    {
        "id": "Builtin.TrajectoryAnyOrderMatch",
        "level": "session",
        "description": "All expected tools must be present, order doesn't matter",
    },
]

# Evaluators that accept ground truth reference inputs
_GT_EVALUATORS = {
    "Builtin.Correctness",
    "Builtin.GoalSuccessRate",
    "Builtin.TrajectoryExactOrderMatch",
    "Builtin.TrajectoryInOrderMatch",
    "Builtin.TrajectoryAnyOrderMatch",
}

logger = logging.getLogger(__name__)

# EvalResults: {model: {test_name: {evaluator_id: result_dict}}}
EvalResults = dict[str, dict[str, dict[str, Any]]]


class EvaluationRunner:
    def __init__(self, config: AgentQualifyConfig):
        self.config = config
        self._dp_client = None

    def _get_dp_client(self):
        if not self._dp_client:
            self._dp_client = boto3.client(
                "bedrock-agentcore", region_name=self.config.agent.region
            )
        return self._dp_client

    @staticmethod
    def _agent_id_from_arn(arn: str) -> str:
        """Extract the agent/runtime name from an ARN.

        e.g. arn:aws:bedrock-agentcore:us-east-1:123:agent-runtime/my-agent
             → my-agent
        """
        return arn.rstrip("/").rsplit("/", 1)[-1]

    def _build_model_agent_id_map(self) -> dict[str, str]:
        """Return {model_name: agent_id} for each variant.

        For ``separate_runtimes`` each variant has its own runtime ARN and
        therefore its own agent ID (and CloudWatch log group).  For other
        strategies all variants share the top-level agent_id.
        """
        cfg = self.config
        result: dict[str, str] = {}
        for variant in cfg.models.variants:
            if cfg.models.strategy == "separate_runtimes" and variant.runtime_arn:
                result[variant.name] = self._agent_id_from_arn(variant.runtime_arn)
            else:
                result[variant.name] = cfg.agent.agent_id
        return result

    def _run_via_agentcore_sdk(self, agent_id: str, session_id: str, evaluators: list[str],
                               ground_truth: GroundTruth | None = None) -> list[dict]:
        """Primary path: use the bedrock-agentcore SDK EvaluationClient.

        Retries up to ``_SDK_MAX_RETRIES`` times when the API reports
        incomplete span data, giving CloudWatch more time to ingest the
        missing log events.
        """
        import time as _time

        from bedrock_agentcore.evaluation import EvaluationClient
        from bedrock_agentcore.evaluation.client import ReferenceInputs

        eval_client = EvaluationClient(region_name=self.config.agent.region)

        # Build kwargs
        kwargs: dict[str, Any] = dict(
            evaluator_ids=evaluators,
            session_id=session_id,
            agent_id=agent_id,
        )
        # Add ground truth via ReferenceInputs when available
        if ground_truth and not ground_truth.is_empty():
            ref_kwargs: dict[str, Any] = {}
            per_turn = [r for r in ground_truth.expected_responses if r is not None]
            if per_turn:
                ref_kwargs["expected_response"] = per_turn[-1] if len(per_turn) == 1 else per_turn[-1]
            if ground_truth.assertions:
                ref_kwargs["assertions"] = ground_truth.assertions
            if ground_truth.expected_trajectory:
                ref_kwargs["expected_trajectory"] = ground_truth.expected_trajectory
            if ref_kwargs:
                kwargs["reference_inputs"] = ReferenceInputs(**ref_kwargs)

        max_retries = 3
        retry_delay = 30  # seconds

        for attempt in range(1, max_retries + 1):
            raw_results = eval_client.run(**kwargs)

            # Check if all results have the "incomplete span data" error
            incomplete = [r for r in raw_results
                          if r.get("errorMessage") and "span data is incomplete" in r["errorMessage"].lower()]
            if incomplete and attempt < max_retries:
                logger.warning(
                    "Attempt %d/%d: %d evaluator(s) reported incomplete span data, "
                    "retrying in %ds...",
                    attempt, max_retries, len(incomplete), retry_delay,
                )
                _time.sleep(retry_delay)
                continue
            break

        out = []
        for r in raw_results:
            out.append({
                "evaluator_id": r.get("evaluatorId", "unknown"),
                "evaluator_name": r.get("evaluatorName", "unknown"),
                "score": r.get("value"),
                "label": r.get("label"),
                "explanation": r.get("explanation"),
                "token_usage": r.get("tokenUsage"),
                "error": r.get("errorMessage"),
                "ignored_fields": r.get("ignoredReferenceInputFields"),
            })
        return out

    def _run_evaluations(self, session_spans: list, evaluators: list[str],
                         session_id: str = "",
                         ground_truth: GroundTruth | None = None,
                         trace_ids: list[str] | None = None) -> list[dict]:
        """Run evaluators against session spans via direct boto3 calls."""
        client = self._get_dp_client()
        ref_inputs = self._build_reference_inputs(
            session_id, ground_truth, trace_ids=trace_ids,
        )
        out = []
        for evaluator_id in evaluators:
            try:
                call_kwargs: dict[str, Any] = dict(
                    evaluatorId=evaluator_id,
                    evaluationInput={"sessionSpans": session_spans},
                )
                # Only attach reference inputs for evaluators that use them
                if ref_inputs and evaluator_id in _GT_EVALUATORS:
                    call_kwargs["evaluationReferenceInputs"] = ref_inputs

                resp = client.evaluate(**call_kwargs)
                for r in resp.get("evaluationResults", []):
                    out.append({
                        "evaluator_id": r.get("evaluatorId", evaluator_id),
                        "evaluator_name": r.get("evaluatorName", evaluator_id),
                        "score": r.get("value"),
                        "label": r.get("label"),
                        "explanation": r.get("explanation"),
                        "token_usage": r.get("tokenUsage"),
                        "error": r.get("errorMessage"),
                        "ignored_fields": r.get("ignoredReferenceInputFields"),
                    })
            except Exception as e:
                logger.warning("Evaluator %s failed: %s", evaluator_id, e)
                out.append({
                    "evaluator_id": evaluator_id,
                    "evaluator_name": evaluator_id,
                    "score": None,
                    "label": None,
                    "explanation": None,
                    "token_usage": None,
                    "error": str(e),
                    "ignored_fields": None,
                })
        return out

    @staticmethod
    def _extract_trace_ids(session_spans: list) -> list[str]:
        """Extract ordered trace IDs for top-level agent invocation spans.

        Each turn in a session produces a root span (no parentSpanId)
        with a unique traceId.  We return them in chronological order
        so they can be positionally aligned with per-turn expected
        responses.
        """
        seen: set[str] = set()
        trace_ids: list[str] = []
        for item in session_spans:
            # Only look at span records (not events)
            if item.get("body") is not None:
                continue
            attrs = item.get("attributes")
            if isinstance(attrs, dict) and "event.name" in attrs:
                continue

            trace_id = item.get("traceId", "")
            if not trace_id or trace_id in seen:
                continue

            # Root spans have no parentSpanId (or it's empty)
            parent = item.get("parentSpanId", "")
            if not parent:
                seen.add(trace_id)
                trace_ids.append(trace_id)

        return trace_ids

    @staticmethod
    def _build_reference_inputs(
        session_id: str,
        ground_truth: GroundTruth | None = None,
        trace_ids: list[str] | None = None,
    ) -> list:
        """Build evaluationReferenceInputs from ground truth data.

        Scoping rules enforced by the Evaluate API:
        - SESSION-level context (sessionId): assertions, expectedTrajectory
        - TRACE-level context (traceId required): expectedResponse

        When ``trace_ids`` are available, expectedResponse is scoped to
        the last trace (matching the convention that a single expected
        response applies to the final agent reply).
        """
        if not ground_truth or ground_truth.is_empty():
            return []

        ref_inputs: list = []

        # ── Session-level: assertions + trajectory ──
        session_ref: dict[str, Any] = {
            "context": {"spanContext": {"sessionId": session_id}},
        }
        has_session_fields = False

        if ground_truth.assertions:
            session_ref["assertions"] = [
                {"text": a} for a in ground_truth.assertions
            ]
            has_session_fields = True
        if ground_truth.expected_trajectory:
            session_ref["expectedTrajectory"] = {
                "toolNames": ground_truth.expected_trajectory,
            }
            has_session_fields = True

        if has_session_fields:
            ref_inputs.append(session_ref)

        # ── Trace-level: expectedResponse ──
        per_turn = ground_truth.expected_responses
        non_null = [r for r in per_turn if r is not None]
        if non_null and trace_ids:
            # Map the last expected response to the last trace
            trace_id = trace_ids[-1]
            ref_inputs.append({
                "context": {
                    "spanContext": {
                        "sessionId": session_id,
                        "traceId": trace_id,
                    },
                },
                "expectedResponse": {"text": non_null[-1]},
            })

        return ref_inputs

    def _fetch_spans(self, agent_id: str, session_id: str) -> list:
        """Fetch session spans and events from CloudWatch for direct boto3 path.

        Spans (metadata) live in the ``aws/spans`` log group while events
        (payloads) live in ``/aws/bedrock-agentcore/runtimes/{agent_id}-{qualifier}``
        log groups.  The qualifier suffix depends on the model strategy:
        - ``qualifier`` strategy: each variant has its own qualifier
        - ``payload`` / ``separate_runtimes``: uses ``DEFAULT``

        We query all relevant runtime log groups plus ``aws/spans``, then
        merge, deduplicate, and return.
        """
        import time as _time
        from datetime import datetime, timedelta

        logs = boto3.client("logs", region_name=self.config.agent.region)
        query = (
            f'fields @timestamp, @message'
            f' | filter ispresent(scope.name)'
            f' | filter attributes.session.id = "{session_id}"'
            f'    or attributes.`session.id` = "{session_id}"'
            f' | sort @timestamp asc'
        )

        # Build the set of runtime log groups to query.
        # Always include DEFAULT; also include per-qualifier log groups.
        qualifiers: set[str] = {"DEFAULT"}
        cfg = self.config
        if cfg.models.strategy == "qualifier":
            for v in cfg.models.variants:
                if v.qualifier:
                    qualifiers.add(v.qualifier)

        log_groups: list[str] = [
            f"/aws/bedrock-agentcore/runtimes/{agent_id}-{q}"
            for q in sorted(qualifiers)
        ]
        log_groups.append("aws/spans")

        raw_items: list = []
        for log_group in log_groups:
            try:
                start = datetime.now() - timedelta(minutes=90)
                qid = logs.start_query(
                    logGroupName=log_group,
                    startTime=int(start.timestamp()),
                    endTime=int(datetime.now().timestamp()),
                    queryString=query,
                )["queryId"]
                while True:
                    res = logs.get_query_results(queryId=qid)
                    if res["status"] in ("Complete", "Failed"):
                        break
                    _time.sleep(1)
                import json as _json
                for row in res.get("results", []):
                    for f in row:
                        if f["field"] == "@message" and f["value"].strip().startswith("{"):
                            try:
                                raw_items.append(_json.loads(f["value"]))
                            except Exception:  # noqa: S110
                                pass  # skip malformed JSON log entries
            except Exception as e:
                logger.debug("Could not query log group %s: %s", log_group, e)

        # Deduplicate by (traceId, spanId, record type).
        # A span record has 'name' at top level; an event record has
        # 'attributes.event.name'.  We keep both but never the same
        # (traceId, spanId, kind) twice.
        seen: set = set()
        deduped: list = []
        for item in raw_items:
            trace_id = item.get("traceId", "")
            span_id = item.get("spanId", "")
            # Distinguish span records from event records
            kind = "event" if item.get("body") is not None or (
                isinstance(item.get("attributes"), dict) and "event.name" in item["attributes"]
            ) else "span"
            key = (trace_id, span_id, kind)
            if key in seen:
                continue
            seen.add(key)
            deduped.append(item)

        if len(deduped) != len(raw_items):
            logger.info("Deduplicated spans: %d → %d", len(raw_items), len(deduped))

        return deduped

    @staticmethod
    def _filter_incomplete_spans(session_spans: list) -> list:
        """Remove spans with supported scopes that are missing their event.

        The Evaluate API requires that every span with a supported scope
        (``strands.telemetry.tracer``, etc.) has a corresponding event
        record (matched by spanId + traceId).  If even one is missing,
        the entire evaluation is rejected with a ValidationException.

        This method drops orphaned spans so the remaining complete data
        can still be evaluated.
        """
        supported_scopes = {
            "strands.telemetry.tracer",
            "opentelemetry.instrumentation.langchain",
            "openinference.instrumentation.langchain",
        }

        # Build a set of (traceId, spanId) for all event records
        event_keys: set[tuple[str, str]] = set()
        for item in session_spans:
            is_event = item.get("body") is not None or (
                isinstance(item.get("attributes"), dict)
                and "event.name" in item["attributes"]
            )
            if is_event:
                event_keys.add((
                    item.get("traceId", ""),
                    item.get("spanId", ""),
                ))

        # Keep everything except supported-scope spans missing events
        filtered: list = []
        dropped = 0
        for item in session_spans:
            is_event = item.get("body") is not None or (
                isinstance(item.get("attributes"), dict)
                and "event.name" in item["attributes"]
            )
            if is_event:
                filtered.append(item)
                continue

            # It's a span record — check scope
            scope_name = ""
            scope = item.get("scope")
            if isinstance(scope, dict):
                scope_name = scope.get("name", "")

            if scope_name in supported_scopes:
                key = (item.get("traceId", ""), item.get("spanId", ""))
                if key not in event_keys:
                    dropped += 1
                    logger.debug(
                        "Dropping incomplete span %s (name=%s) "
                        "— no matching event",
                        item.get("spanId"), item.get("name"),
                    )
                    continue

            filtered.append(item)

        if dropped:
            logger.warning(
                "Filtered %d incomplete span(s) missing log events "
                "(%d → %d)",
                dropped, len(session_spans), len(filtered),
            )

        return filtered

    def run(self, session_map: SessionMap, ground_truth_map: GroundTruthMap | None = None) -> EvalResults:
        """
        Run all evaluators for every session in session_map.

        Fetches spans from CloudWatch, filters incomplete ones, and
        calls the Evaluate API via boto3.

        Args:
            session_map: {model: {test_name: session_id}}
            ground_truth_map: Optional {test_name: GroundTruth}.

        Returns:
            {model: {test_name: {evaluator_id: result_dict}}}
        """
        evaluators = self.config.evaluators
        agent_id = self.config.agent.agent_id
        gt_map = ground_truth_map or {}
        results: EvalResults = {}

        # Build per-model agent ID map (differs for separate_runtimes strategy)
        model_agent_ids = self._build_model_agent_id_map()

        for model_name, test_sessions in session_map.items():
            model_results: dict[str, dict[str, Any]] = {}
            test_items = list(test_sessions.items())
            # Use the correct agent_id for this model variant's log group
            variant_agent_id = model_agent_ids.get(model_name, agent_id)
            test_items = list(test_sessions.items())
            for i, (test_name, session_id) in enumerate(test_items, 1):
                logger.info(
                    "[%s] Evaluating test %d/%d: %s",
                    model_name, i, len(test_items), test_name,
                )
                gt = gt_map.get(test_name)
                spans = self._fetch_spans(variant_agent_id, session_id)
                spans = self._filter_incomplete_spans(spans)

                if not spans:
                    logger.warning(
                        "[%s] No spans found for session %s — "
                        "CloudWatch may not have ingested them yet",
                        model_name, session_id,
                    )
                    # Return error results for all evaluators
                    raw = [
                        {
                            "evaluator_id": eid,
                            "evaluator_name": eid,
                            "score": None,
                            "label": None,
                            "explanation": None,
                            "token_usage": None,
                            "error": (
                                f"No spans found for session {session_id}. "
                                "Try increasing span_wait_seconds."
                            ),
                            "ignored_fields": None,
                        }
                        for eid in evaluators
                    ]
                else:
                    trace_ids = self._extract_trace_ids(spans)
                    if trace_ids:
                        logger.debug(
                            "Extracted %d trace ID(s) for session %s",
                            len(trace_ids), session_id,
                        )
                    raw = self._run_evaluations(
                        spans, evaluators,
                        session_id=session_id, ground_truth=gt,
                        trace_ids=trace_ids,
                    )

                # Aggregate: keep best score per evaluator_id
                by_evaluator: dict[str, Any] = {}
                for r in raw:
                    eid = r["evaluator_id"]
                    if eid not in by_evaluator or (
                        r["score"] is not None
                        and (by_evaluator[eid]["score"] is None or r["score"] > by_evaluator[eid]["score"])
                    ):
                        by_evaluator[eid] = r

                model_results[test_name] = by_evaluator
            results[model_name] = model_results

        return results
