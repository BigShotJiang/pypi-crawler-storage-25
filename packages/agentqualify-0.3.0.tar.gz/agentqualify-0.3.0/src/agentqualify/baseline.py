"""Baseline management — store and retrieve evaluation baselines from S3."""
from __future__ import annotations

import json
import logging
import re

import boto3

logger = logging.getLogger(__name__)


def _parse_s3_uri(uri: str):
    m = re.match(r"s3://([^/]+)/(.+)", uri)
    if not m:
        raise ValueError(f"Invalid S3 URI: {uri}")
    return m.group(1), m.group(2)


class BaselineManager:
    def __init__(self, s3_uri: str, region: str = "us-east-1"):
        self.s3_uri = s3_uri
        self.bucket, self.key = _parse_s3_uri(s3_uri)
        self._s3 = boto3.client("s3", region_name=region)

    def load(self) -> dict | None:
        """Download baseline from S3. Returns None if not found."""
        try:
            obj = self._s3.get_object(Bucket=self.bucket, Key=self.key)
            return json.loads(obj["Body"].read())
        except self._s3.exceptions.NoSuchKey:
            return None
        except Exception as e:
            logger.warning("Could not load baseline from %s: %s", self.s3_uri, e)
            return None

    def save(self, data: dict) -> None:
        """Upload baseline to S3."""
        self._s3.put_object(
            Bucket=self.bucket,
            Key=self.key,
            Body=json.dumps(data, indent=2).encode(),
            ContentType="application/json",
        )
        logger.info("Baseline saved to s3://%s/%s", self.bucket, self.key)
