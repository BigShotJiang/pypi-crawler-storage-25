"""AgentQualify core orchestrator — Python SDK entry point."""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

from agentqualify.baseline import BaselineManager
from agentqualify.config import (
    AgentQualifyConfig,
    GroundTruthMap,
    SessionInput,
    extract_ground_truth,
    load_config,
    load_test_suite,
)
from agentqualify.evaluator import EvalResults, EvaluationRunner
from agentqualify.gate import CICDGate, GateResult
from agentqualify.invoker import AgentInvoker
from agentqualify.reporting import CloudWatchReporter

logger = logging.getLogger(__name__)


@dataclass
class AgentQualifyResult:
    passed: bool
    results: EvalResults
    failures: list[dict[str, Any]]
    dashboard_url: str = ""
    gate_result: GateResult | None = None

    def summary(self) -> str:
        lines = ["AgentQualify Summary", "=" * 40]
        for model, test_results in self.results.items():
            lines.append(f"\nModel: {model}")
            for test_name, evaluator_results in test_results.items():
                lines.append(f"  Test: {test_name}")
                for eid, r in evaluator_results.items():
                    score = r.get("score")
                    label = r.get("label", "")
                    err = r.get("error")
                    if err:
                        lines.append(f"    {eid}: ERROR — {err}")
                    else:
                        lines.append(
                            f"    {eid}: {score:.3f} ({label})"
                            if score is not None
                            else f"    {eid}: N/A"
                        )
        lines.append("\n" + ("✅ PASSED" if self.passed else "❌ FAILED"))
        if self.failures:
            for f in self.failures:
                lines.append(f"  • [{f['type']}] {f['evaluator']}: {f['reason']}")
        if self.dashboard_url:
            lines.append(f"\nDashboard: {self.dashboard_url}")
        return "\n".join(lines)

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-serializable dict of the full result."""
        return {
            "passed": self.passed,
            "results": self.results,
            "failures": self.failures,
            "dashboard_url": self.dashboard_url,
        }


class AgentQualify:
    """
    Python SDK for AgentQualify.

    Usage:
        result = AgentQualify("agentqualify.yaml").run()
        print(result.summary())
        sys.exit(0 if result.passed else 1)
    """

    def __init__(self, config_path: str = "agentqualify.yaml", config: AgentQualifyConfig | None = None):
        self.config = config or load_config(config_path)

    def run(self) -> AgentQualifyResult:
        """Run the full evaluation pipeline and return results."""
        cfg = self.config
        session_map: dict[str, dict[str, str]] = {}
        ground_truth_map: GroundTruthMap = {}

        # ── Step 1: Collect sessions ──
        if cfg.input.mode in ("test_suite", "both"):
            if not cfg.input.test_suite:
                raise ValueError("input.test_suite path required when mode is 'test_suite' or 'both'")
            tests = load_test_suite(cfg.input.test_suite)
            ground_truth_map = extract_ground_truth(tests)
            if ground_truth_map:
                logger.info("Ground truth loaded for %d test cases", len(ground_truth_map))
            logger.info(
                "Invoking agent for %d test cases across %d model variants",
                len(tests), len(cfg.models.variants),
            )
            invoker = AgentInvoker(cfg)
            session_map = invoker.invoke_all(tests)

        if cfg.input.mode in ("sessions", "both"):
            sessions: list[SessionInput] = cfg.input.sessions or []
            # For existing sessions, use a single pseudo-model "existing"
            existing: dict[str, str] = {}
            for s in sessions:
                name = s.name or s.session_id
                existing[name] = s.session_id
            if existing:
                session_map.setdefault("existing", {}).update(existing)

        if not session_map:
            raise ValueError("No sessions to evaluate. Check input config.")

        # ── Step 2: Run evaluations ──
        logger.info("Running evaluations...")
        runner = EvaluationRunner(cfg)
        results = runner.run(session_map, ground_truth_map=ground_truth_map or None)

        # ── Step 3: Publish metrics + create dashboard ──
        dashboard_url = ""
        if cfg.reporting.cloudwatch.enabled:
            reporter = CloudWatchReporter(cfg)
            reporter.publish_metrics(results)
            dashboard_url = reporter.create_dashboard(results)
            logger.info("Dashboard: %s", dashboard_url)

        # ── Step 4: Load baseline and check gate ──
        baseline_data = None
        if cfg.baseline.enabled and cfg.baseline.s3_uri:
            bm = BaselineManager(cfg.baseline.s3_uri, cfg.agent.region)
            baseline_data = bm.load()
            if baseline_data is None:
                logger.info(
                    "No existing baseline found at %s — "
                    "run 'agentqualify baseline update' to create one",
                    cfg.baseline.s3_uri,
                )

        gate = CICDGate(cfg, results)
        gate_result = gate.check(baseline_data)

        return AgentQualifyResult(
            passed=gate_result.passed,
            results=results,
            failures=gate_result.failures,
            dashboard_url=dashboard_url,
            gate_result=gate_result,
        )

    def update_baseline(self) -> None:
        """Run evaluation and save results as the new S3 baseline."""
        cfg = self.config
        if not cfg.baseline.s3_uri:
            raise ValueError("baseline.s3_uri must be set to update baseline")

        result = self.run()
        gate = CICDGate(cfg, result.results)
        baseline_data = gate.build_baseline_data()

        bm = BaselineManager(cfg.baseline.s3_uri, cfg.agent.region)
        bm.save(baseline_data)
        logger.info("Baseline saved to %s", cfg.baseline.s3_uri)
