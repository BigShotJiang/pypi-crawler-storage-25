"""Config models and YAML loader for AgentQualify."""
from __future__ import annotations

from pathlib import Path
from typing import Any, Literal

import yaml
from pydantic import BaseModel, Field, model_validator


class OAuthConfig(BaseModel):
    """OAuth client credentials configuration for automatic token generation."""
    token_url: str                          # e.g. https://cognito-idp.us-east-1.amazonaws.com/us-east-1_xxx/oauth2/token
    client_id: str                          # OAuth client ID (or ${ENV_VAR})
    client_secret: str                      # OAuth client secret (or ${ENV_VAR})
    scopes: list[str] | None = None      # e.g. ["agentcore/invoke"]

    @staticmethod
    def _resolve_env(value: str) -> str:
        """Expand ${ENV_VAR} references to environment variable values."""
        import os
        if value.startswith("${") and value.endswith("}"):
            env_var = value[2:-1]
            resolved = os.environ.get(env_var)
            if not resolved:
                raise ValueError(f"Environment variable '{env_var}' is not set")
            return resolved
        return value

    def resolve_client_id(self) -> str:
        return self._resolve_env(self.client_id)

    def resolve_client_secret(self) -> str:
        return self._resolve_env(self.client_secret)


class AuthConfig(BaseModel):
    """Inbound authorization config for agent runtime invocation."""
    type: Literal["sigv4", "oauth"] = "sigv4"
    oauth: OAuthConfig | None = None

    @model_validator(mode="after")
    def validate_oauth(self) -> AuthConfig:
        if self.type == "oauth" and not self.oauth:
            raise ValueError("auth.oauth config is required when auth.type is 'oauth'")
        return self


class AgentConfig(BaseModel):
    runtime_arn: str
    agent_id: str | None = None  # derived from runtime_arn if not provided
    region: str = "us-east-1"
    span_wait_seconds: int = 180  # wait after invocation for spans (CloudWatch ingestion)
    auth: AuthConfig = Field(default_factory=AuthConfig)

    @model_validator(mode="before")
    @classmethod
    def normalize_auth(cls, data: Any) -> Any:
        """Allow shorthand ``auth: "sigv4"`` / ``auth: "oauth"`` in YAML."""
        if isinstance(data, dict) and isinstance(data.get("auth"), str):
            data["auth"] = {"type": data["auth"]}
        return data

    @model_validator(mode="after")
    def derive_agent_id(self) -> AgentConfig:
        """Derive agent_id from runtime_arn if not explicitly provided."""
        if not self.agent_id:
            # arn:aws:bedrock-agentcore:{region}:{account}:agent-runtime/{agent-id}
            self.agent_id = self.runtime_arn.rstrip("/").rsplit("/", 1)[-1]
        return self


class ModelVariant(BaseModel):
    name: str
    # qualifier strategy
    qualifier: str | None = None
    # payload strategy
    payload_override: dict[str, Any] | None = None
    # separate_runtimes strategy
    runtime_arn: str | None = None


class ModelsConfig(BaseModel):
    strategy: Literal["qualifier", "payload", "separate_runtimes"] = "qualifier"
    variants: list[ModelVariant] = Field(default_factory=list)

    @model_validator(mode="after")
    def validate_variants(self) -> ModelsConfig:
        for v in self.variants:
            if self.strategy == "qualifier" and not v.qualifier:
                raise ValueError(f"Model variant '{v.name}' missing 'qualifier'")
            if self.strategy == "payload" and not v.payload_override:
                raise ValueError(f"Model variant '{v.name}' missing 'payload_override'")
            if self.strategy == "separate_runtimes" and not v.runtime_arn:
                raise ValueError(f"Model variant '{v.name}' missing 'runtime_arn'")
        return self


class Turn(BaseModel):
    """A single turn in a multi-turn test case."""
    prompt: str
    expected_response: str | None = None


class TestCase(BaseModel):
    name: str
    # Single-turn: use prompt (string)
    prompt: str | None = None
    # Multi-turn: use prompts (list of strings) or turns (list of Turn objects)
    prompts: list[str] | None = None
    turns: list[Turn] | None = None
    # Ground truth fields (all optional for backward compatibility)
    # Top-level expected_response applies to single-turn or as a session-level fallback
    expected_response: str | None = None
    assertions: list[str] | None = None
    expected_trajectory: list[str] | None = None

    @model_validator(mode="after")
    def validate_prompts(self) -> TestCase:
        if not self.prompt and not self.prompts and not self.turns:
            raise ValueError(f"Test '{self.name}' must have 'prompt', 'prompts', or 'turns'")
        return self

    def get_prompts(self) -> list[str]:
        """Return the flat list of prompt strings for invocation."""
        if self.turns:
            return [t.prompt for t in self.turns]
        if self.prompts:
            return self.prompts
        return [self.prompt] if self.prompt else []

    def get_per_turn_expected_responses(self) -> list[str | None]:
        """Return per-turn expected responses, positionally aligned with prompts.

        For the ``turns`` format each Turn can carry its own expected_response.
        For the legacy ``prompt``/``prompts`` format the top-level
        ``expected_response`` is mapped to the last turn (matching the
        AgentCore convention where a single expected_response applies to the
        final agent reply).
        """
        if self.turns:
            return [t.expected_response for t in self.turns]
        prompts = self.get_prompts()
        if self.expected_response and prompts:
            # Map top-level expected_response to the last turn
            return [None] * (len(prompts) - 1) + [self.expected_response]
        return [None] * len(prompts)

    def has_ground_truth(self) -> bool:
        """Return True if any ground truth field is set."""
        if self.assertions or self.expected_trajectory:
            return True
        if self.expected_response:
            return True
        if self.turns and any(t.expected_response for t in self.turns):
            return True
        return False


class GroundTruth(BaseModel):
    """Ground truth data for a single test case."""
    # Per-turn expected responses, positionally aligned with turns
    expected_responses: list[str | None] = Field(default_factory=list)
    assertions: list[str] | None = None
    expected_trajectory: list[str] | None = None

    def is_empty(self) -> bool:
        has_responses = any(r is not None for r in self.expected_responses)
        return not (has_responses or self.assertions or self.expected_trajectory)


# GroundTruthMap: {test_name: GroundTruth}
GroundTruthMap = dict[str, GroundTruth]


class SessionInput(BaseModel):
    session_id: str
    name: str | None = None


class InputConfig(BaseModel):
    mode: Literal["test_suite", "sessions", "both"] = "test_suite"
    test_suite: str | None = None   # path to test suite YAML
    sessions: list[SessionInput] | None = None


class BaselineConfig(BaseModel):
    enabled: bool = False
    s3_uri: str | None = None       # s3://bucket/path/baseline.json
    max_regression: float = 0.05       # fail if score drops more than this


class CloudWatchConfig(BaseModel):
    enabled: bool = True
    namespace: str = "AgentQualify"
    dashboard_name: str = "AgentQualify-Dashboard"


class ReportingConfig(BaseModel):
    cloudwatch: CloudWatchConfig = Field(default_factory=CloudWatchConfig)


class AgentQualifyConfig(BaseModel):
    agent: AgentConfig
    models: ModelsConfig = Field(default_factory=ModelsConfig)
    evaluators: list[str] = Field(default_factory=lambda: [
        "Builtin.Helpfulness",
        "Builtin.Correctness",
        "Builtin.GoalSuccessRate",
    ])
    input: InputConfig = Field(default_factory=InputConfig)
    thresholds: dict[str, float] = Field(default_factory=dict)
    baseline: BaselineConfig = Field(default_factory=BaselineConfig)
    reporting: ReportingConfig = Field(default_factory=ReportingConfig)


def load_config(path: str) -> AgentQualifyConfig:
    """Load and validate AgentQualify config from a YAML file."""
    data = yaml.safe_load(Path(path).read_text())
    if not isinstance(data, dict):
        raise ValueError(f"Config file '{path}' is empty or not a valid YAML mapping")
    return AgentQualifyConfig.model_validate(data)


def load_test_suite(path: str) -> list[TestCase]:
    """Load test cases from a YAML test suite file."""
    data = yaml.safe_load(Path(path).read_text())
    if not isinstance(data, dict):
        raise ValueError(f"Test suite file '{path}' is empty or not a valid YAML mapping")
    return [TestCase.model_validate(t) for t in data.get("tests", [])]


def extract_ground_truth(tests: list[TestCase]) -> GroundTruthMap:
    """Extract ground truth data from test cases into a GroundTruthMap."""
    gt_map: GroundTruthMap = {}
    for t in tests:
        gt = GroundTruth(
            expected_responses=t.get_per_turn_expected_responses(),
            assertions=t.assertions,
            expected_trajectory=t.expected_trajectory,
        )
        if not gt.is_empty():
            gt_map[t.name] = gt
    return gt_map
