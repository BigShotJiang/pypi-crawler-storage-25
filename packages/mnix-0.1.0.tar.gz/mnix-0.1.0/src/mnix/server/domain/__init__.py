"""Server domain layer."""
