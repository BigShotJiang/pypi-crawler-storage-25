"""Server package for mnix."""
