"""Tests for the custom widget system."""

from __future__ import annotations

from typing import Any, ClassVar

import pytest

from plushie.events import (
    Click,
    Enter,
    Press,
    RawEvent,
    Select,
)
from plushie.subscriptions import Subscription
from plushie.tree import normalize
from plushie.widget import (
    EventAction,
    EventActionResult,
    EventSpec,
    RegistryEntry,
    WidgetDef,
    collect_subscriptions,
    derive_registry,
    dispatch_through_widgets,
    maybe_handle_timer,
)

# ---------------------------------------------------------------------------
# Test widget definitions
# ---------------------------------------------------------------------------


class StarRating(WidgetDef):
    """Simple star rating widget for testing."""

    def init(self, props: dict[str, Any]) -> dict[str, Any]:
        return {"hovered": None, "max": props.get("max", 5)}

    def view(
        self, widget_id: str, props: dict[str, Any], state: dict[str, Any]
    ) -> dict[str, Any]:
        return {"id": widget_id, "type": "canvas", "props": {}, "children": []}

    def handle_event(self, event: Any, state: dict[str, Any]) -> EventActionResult:
        if isinstance(event, Enter):
            return EventAction.update_state({**state, "hovered": event.id})
        if isinstance(event, Click):
            return EventAction.emit("select", {"value": event.id})
        return EventAction.ignored()


class IgnoreAll(WidgetDef):
    """Widget that ignores all events."""

    def init(self, props: dict[str, Any]) -> dict[str, Any]:
        return {}

    def view(
        self, widget_id: str, props: dict[str, Any], state: dict[str, Any]
    ) -> dict[str, Any]:
        return {"id": widget_id, "type": "canvas", "props": {}, "children": []}

    def handle_event(self, event: Any, state: dict[str, Any]) -> EventActionResult:
        return EventAction.ignored()


class ConsumeAll(WidgetDef):
    """Widget that consumes all events."""

    def init(self, props: dict[str, Any]) -> dict[str, Any]:
        return {}

    def view(
        self, widget_id: str, props: dict[str, Any], state: dict[str, Any]
    ) -> dict[str, Any]:
        return {"id": widget_id, "type": "canvas", "props": {}, "children": []}

    def handle_event(self, event: Any, state: dict[str, Any]) -> EventActionResult:
        return EventAction.consumed()


class CustomEmitter(WidgetDef):
    """Widget that emits a custom (non-built-in) event name."""

    def init(self, props: dict[str, Any]) -> dict[str, Any]:
        return {}

    def view(
        self, widget_id: str, props: dict[str, Any], state: dict[str, Any]
    ) -> dict[str, Any]:
        return {"id": widget_id, "type": "canvas", "props": {}, "children": []}

    def handle_event(self, event: Any, state: dict[str, Any]) -> EventActionResult:
        if isinstance(event, Click):
            return EventAction.emit("change", {"hue": 180.0, "sat": 0.5})
        return EventAction.ignored()


class ToggleEmitter(WidgetDef):
    """Widget that emits a built-in toggle event."""

    def init(self, props: dict[str, Any]) -> dict[str, Any]:
        return {"on": False}

    def view(
        self, widget_id: str, props: dict[str, Any], state: dict[str, Any]
    ) -> dict[str, Any]:
        return {"id": widget_id, "type": "canvas", "props": {}, "children": []}

    def handle_event(self, event: Any, state: dict[str, Any]) -> EventActionResult:
        if isinstance(event, Click):
            new_on = not state["on"]
            return EventAction.emit("toggle", new_on, state={"on": new_on})
        return EventAction.ignored()


class WithSubscriptions(WidgetDef):
    """Widget with timer subscription."""

    def init(self, props: dict[str, Any]) -> dict[str, Any]:
        return {}

    def view(
        self, widget_id: str, props: dict[str, Any], state: dict[str, Any]
    ) -> dict[str, Any]:
        return {"id": widget_id, "type": "canvas", "props": {}, "children": []}

    def handle_event(self, event: Any, state: dict[str, Any]) -> EventActionResult:
        return EventAction.ignored()

    def subscribe(
        self, props: dict[str, Any], state: dict[str, Any]
    ) -> list[Subscription]:
        return [Subscription.every(100, "tick")]


class ValidatedWidget(WidgetDef):
    """Widget with event_specs for validation testing."""

    event_specs: ClassVar[dict[str, EventSpec]] = {
        "change": EventSpec(fields={"hue": float, "saturation": float}),
        "select": EventSpec(value_type=int),
        "cleared": EventSpec(),
    }

    def init(self, props: dict[str, Any]) -> dict[str, Any]:
        return {}

    def view(
        self, widget_id: str, props: dict[str, Any], state: dict[str, Any]
    ) -> dict[str, Any]:
        return {"id": widget_id, "type": "canvas", "props": {}, "children": []}

    def handle_event(self, event: Any, state: dict[str, Any]) -> EventActionResult:
        if isinstance(event, Click):
            eid = event.id
            if eid == "ring":
                return EventAction.emit("change", {"hue": 180.0, "saturation": 0.5})
            if eid == "star":
                return EventAction.emit("select", 3)
            if eid == "clear":
                return EventAction.emit("cleared")
        return EventAction.ignored()


# ---------------------------------------------------------------------------
# EventAction tests
# ---------------------------------------------------------------------------


class TestEventAction:
    def test_ignored(self) -> None:
        result = EventAction.ignored()
        assert result == EventAction.ignored()

    def test_consumed(self) -> None:
        result = EventAction.consumed()
        assert result == EventAction.consumed()

    def test_update_state(self) -> None:
        result = EventAction.update_state({"x": 1})
        assert result.state == {"x": 1}

    def test_emit_with_dict(self) -> None:
        result = EventAction.emit("select", {"value": "star3"})
        assert result.kind == "select"
        assert result.data == {"value": "star3"}

    def test_emit_with_scalar(self) -> None:
        result = EventAction.emit("change", 42)
        assert result.data == {"value": 42}

    def test_emit_with_state(self) -> None:
        result = EventAction.emit("select", {"v": 1}, state={"count": 3})
        assert result.state == {"count": 3}

    def test_emit_with_none_data(self) -> None:
        result = EventAction.emit("ping")
        assert result.data == {}


# ---------------------------------------------------------------------------
# Build tests
# ---------------------------------------------------------------------------


class TestBuild:
    def test_builds_placeholder(self) -> None:
        node = StarRating.build("stars", props={"max": 5})
        assert node["id"] == "stars"
        assert node["type"] == "canvas"
        meta = node["meta"]
        assert meta["__widget__"] is StarRating
        assert meta["__widget_props__"] == {"max": 5}

    def test_build_sets_event_rate_on_placeholder(self) -> None:
        props = {"max": 5, "event_rate": 15}
        node = StarRating.build("stars", props=props, event_rate=60)

        assert node["props"] == {"event_rate": 60}
        assert node["meta"]["__widget_props__"] == {"max": 5, "event_rate": 15}
        assert node["meta"]["__widget_props__"] is not props

        props["max"] = 10
        assert node["meta"]["__widget_props__"]["max"] == 5

    def test_meta_preserved_through_normalize(self) -> None:
        node = StarRating.build("stars", props={"max": 5})
        tree = {
            "id": "main",
            "type": "window",
            "props": {},
            "children": [node],
        }
        result = normalize(tree)
        child = result["children"][0]
        assert "meta" in child
        assert child["meta"]["__widget__"] is StarRating

    def test_view_returning_none_raises_clear_error(self) -> None:
        class NoneView(WidgetDef):
            def init(self, props: dict[str, Any]) -> dict[str, Any]:
                return {}

            def view(
                self, widget_id: str, props: dict[str, Any], state: dict[str, Any]
            ) -> Any:
                return None

        tree = {
            "id": "main",
            "type": "window",
            "props": {},
            "children": [NoneView.build("empty")],
        }

        with pytest.raises(
            ValueError,
            match=(
                r"NoneView\.view\(\) returned None for widget 'main#empty' "
                r"\(local id 'empty'\)"
            ),
        ):
            normalize(tree, registry={})

    def test_view_returning_non_dict_raises_clear_error(self) -> None:
        class ListView(WidgetDef):
            def init(self, props: dict[str, Any]) -> dict[str, Any]:
                return {}

            def view(
                self, widget_id: str, props: dict[str, Any], state: dict[str, Any]
            ) -> Any:
                return []

        tree = {
            "id": "main",
            "type": "window",
            "props": {},
            "children": [ListView.build("items")],
        }

        with pytest.raises(
            ValueError,
            match=(
                r"ListView\.view\(\) must return a dict for widget 'main#items' "
                r"\(local id 'items'\); got list"
            ),
        ):
            normalize(tree, registry={})


# ---------------------------------------------------------------------------
# Registry tests
# ---------------------------------------------------------------------------


class TestDeriveRegistry:
    def test_empty_tree(self) -> None:
        assert derive_registry(None) == {}

    def test_extracts_widget_entries(self) -> None:
        tree = normalize(
            {
                "id": "main",
                "type": "window",
                "props": {},
                "children": [StarRating.build("stars", props={"max": 5})],
            },
            registry={},
        )
        reg = derive_registry(tree)
        assert ("main", "main#stars") in reg
        entry = reg[("main", "main#stars")]
        assert isinstance(entry.definition, StarRating)
        assert entry.state == {"hovered": None, "max": 5}
        assert entry.props == {"max": 5}

    def test_new_widget_init_runs_once_and_dispatch_uses_view_instance(self) -> None:
        calls: list[str] = []
        instances: list[WidgetDef] = []

        class ProbeWidget(WidgetDef):
            def __init__(self) -> None:
                calls.append("construct")
                instances.append(self)

            def init(self, props: dict[str, Any]) -> dict[str, Any]:
                calls.append("init")
                return {"token": id(self)}

            def view(
                self, widget_id: str, props: dict[str, Any], state: dict[str, Any]
            ) -> dict[str, Any]:
                calls.append("view")
                assert state["token"] == id(self)
                return {
                    "id": widget_id,
                    "type": "container",
                    "props": {},
                    "children": [
                        {
                            "id": "target",
                            "type": "button",
                            "props": {"label": "hit"},
                            "children": [],
                        }
                    ],
                }

            def handle_event(
                self, event: Any, state: dict[str, Any]
            ) -> EventActionResult:
                calls.append(f"handle:{state['token'] == id(self)}")
                return EventAction.emit("select", "ok")

        tree = normalize(
            {
                "id": "main",
                "type": "window",
                "props": {},
                "children": [ProbeWidget.build("probe")],
            },
            registry={},
        )
        reg = derive_registry(tree)

        assert calls == ["construct", "init", "view"]
        assert len(instances) == 1

        result, _new_reg, _changed = dispatch_through_widgets(
            reg,
            Click(id="target", window_id="main", scope=("probe", "main")),
        )

        assert isinstance(result, Select)
        assert calls == ["construct", "init", "view", "handle:True"]
        assert reg[("main", "main#probe")].definition is instances[0]

    def test_derive_registry_uses_rendered_metadata_only(self) -> None:
        calls: list[str] = []

        class MetadataWidget(WidgetDef):
            def __init__(self) -> None:
                calls.append("construct")

            def init(self, props: dict[str, Any]) -> dict[str, Any]:
                calls.append("init")
                return {"ready": True}

            def view(
                self, widget_id: str, props: dict[str, Any], state: dict[str, Any]
            ) -> dict[str, Any]:
                calls.append("view")
                return {"id": widget_id, "type": "canvas", "props": {}, "children": []}

            def handle_event(
                self, event: Any, state: dict[str, Any]
            ) -> EventActionResult:
                return EventAction.ignored()

        rendered = normalize(
            {
                "id": "main",
                "type": "window",
                "props": {},
                "children": [MetadataWidget.build("probe")],
            },
            registry={},
        )

        reg1 = derive_registry(rendered)
        reg2 = derive_registry(rendered)

        assert calls == ["construct", "init", "view"]
        assert (
            reg1[("main", "main#probe")].definition
            is reg2[("main", "main#probe")].definition
        )

    def test_view_only_widget_is_transparent_registry_entry(self) -> None:
        class ViewOnly(WidgetDef):
            def init(self, props: dict[str, Any]) -> dict[str, Any]:
                return {"ready": True}

            def view(
                self, widget_id: str, props: dict[str, Any], state: dict[str, Any]
            ) -> dict[str, Any]:
                return {
                    "id": widget_id,
                    "type": "container",
                    "props": {},
                    "children": [
                        {
                            "id": "target",
                            "type": "button",
                            "props": {"label": "hit"},
                            "children": [],
                        }
                    ],
                }

        tree = normalize(
            {
                "id": "main",
                "type": "window",
                "props": {},
                "children": [ViewOnly.build("view_only")],
            },
            registry={},
        )
        reg = derive_registry(tree)

        assert ("main", "main#view_only") in reg
        assert collect_subscriptions(reg) == []

        event = Click(id="target", window_id="main", scope=("view_only", "main"))
        result, _new_reg, changed = dispatch_through_widgets(reg, event)

        assert result is event
        assert changed is False

    @pytest.mark.parametrize("second_kind", ["sibling", "base"])
    def test_same_id_with_new_widget_class_gets_new_instance(
        self, second_kind: str
    ) -> None:
        calls: list[str] = []

        class BaseWidget(WidgetDef):
            def init(self, props: dict[str, Any]) -> dict[str, Any]:
                calls.append("base:init")
                return {"name": "base"}

            def view(
                self, widget_id: str, props: dict[str, Any], state: dict[str, Any]
            ) -> dict[str, Any]:
                calls.append("base:view")
                return {
                    "id": widget_id,
                    "type": "text",
                    "props": {"content": state["name"]},
                    "children": [],
                }

        class ChildWidget(BaseWidget):
            def init(self, props: dict[str, Any]) -> dict[str, Any]:
                calls.append("child:init")
                return {"name": "child"}

            def view(
                self, widget_id: str, props: dict[str, Any], state: dict[str, Any]
            ) -> dict[str, Any]:
                calls.append("child:view")
                return {
                    "id": widget_id,
                    "type": "text",
                    "props": {"content": state["name"]},
                    "children": [],
                }

        class SiblingWidget(WidgetDef):
            def init(self, props: dict[str, Any]) -> dict[str, Any]:
                calls.append("sibling:init")
                return {"name": "sibling"}

            def view(
                self, widget_id: str, props: dict[str, Any], state: dict[str, Any]
            ) -> dict[str, Any]:
                calls.append("sibling:view")
                return {
                    "id": widget_id,
                    "type": "text",
                    "props": {"content": state["name"]},
                    "children": [],
                }

        first_tree = normalize(
            {
                "id": "main",
                "type": "window",
                "props": {},
                "children": [ChildWidget.build("slot")],
            },
            registry={},
        )
        first_registry = derive_registry(first_tree)
        second_widget = BaseWidget if second_kind == "base" else SiblingWidget

        second_tree = normalize(
            {
                "id": "main",
                "type": "window",
                "props": {},
                "children": [second_widget.build("slot")],
            },
            registry=first_registry,
        )
        second_registry = derive_registry(second_tree)

        assert calls == [
            "child:init",
            "child:view",
            f"{second_kind}:init",
            f"{second_kind}:view",
        ]
        assert type(second_registry[("main", "main#slot")].definition) is second_widget
        assert second_tree["children"][0]["props"]["content"] == second_kind


# ---------------------------------------------------------------------------
# Dispatch tests
# ---------------------------------------------------------------------------


class TestDispatchThroughWidgets:
    def test_ignored_passes_through(self) -> None:
        reg = {
            ("main", "main#form/widget"): RegistryEntry(
                definition=IgnoreAll(), state={}, props={}
            )
        }
        event = Click(id="btn", window_id="main", scope=("widget", "form"))
        result, _new_reg, _changed = dispatch_through_widgets(reg, event)
        assert result is event

    def test_consumed_returns_none(self) -> None:
        reg = {
            ("main", "main#form/widget"): RegistryEntry(
                definition=ConsumeAll(), state={}, props={}
            )
        }
        event = Click(id="btn", window_id="main", scope=("widget", "form"))
        result, _new_reg, _changed = dispatch_through_widgets(reg, event)
        assert result is None

    def test_emit_replaces_event(self) -> None:
        reg = {
            ("main", "main#stars"): RegistryEntry(
                definition=StarRating(),
                state={"hovered": None, "max": 5},
                props={"max": 5},
            )
        }
        event = Click(
            id="star3",
            window_id="main",
            scope=("stars",),
        )
        result, _new_reg, _changed = dispatch_through_widgets(reg, event)
        assert isinstance(result, Select)
        assert result.value == "star3"
        assert result.window_id == "main"
        assert result.id == "stars"

    def test_emit_custom_event_produces_widget_event(self) -> None:
        """Custom event names produce RawEvent (no typed class)."""
        reg = {
            ("main", "main#picker"): RegistryEntry(
                definition=CustomEmitter(),
                state={},
                props={},
            )
        }
        event = Click(
            id="ring",
            window_id="main",
            scope=("picker",),
        )
        result, _, _changed = dispatch_through_widgets(reg, event)
        assert isinstance(result, RawEvent)
        assert result.kind == "change"
        assert result.data == {"hue": 180.0, "sat": 0.5}

    def test_emit_toggle_produces_typed_event(self) -> None:
        """Built-in 'toggle' emission produces a Toggle dataclass."""
        from plushie.events import Toggle

        reg = {
            ("main", "main#sw"): RegistryEntry(
                definition=ToggleEmitter(),
                state={"on": False},
                props={},
            )
        }
        event = Click(
            id="switch",
            window_id="main",
            scope=("sw",),
        )
        result, new_reg, _changed = dispatch_through_widgets(reg, event)
        assert isinstance(result, Toggle)
        assert result.value is True
        assert result.id == "sw"
        assert result.window_id == "main"
        # State was also updated
        assert new_reg[("main", "main#sw")].state == {"on": True}

    def test_update_state_modifies_registry(self) -> None:
        reg = {
            ("main", "main#stars"): RegistryEntry(
                definition=StarRating(),
                state={"hovered": None, "max": 5},
                props={"max": 5},
            )
        }
        event = Enter(
            id="star2",
            window_id="main",
            scope=("stars",),
        )
        result, new_reg, _changed = dispatch_through_widgets(reg, event)
        assert result is None  # consumed by update_state
        assert new_reg[("main", "main#stars")].state["hovered"] == "star2"

    def test_empty_registry_passes_through(self) -> None:
        event = Click(id="btn", window_id="main", scope=())
        result, _, _changed = dispatch_through_widgets({}, event)
        assert result is event

    def test_no_scope_passes_through(self) -> None:
        reg = {
            ("main", "main#stars"): RegistryEntry(
                definition=IgnoreAll(), state={}, props={}
            )
        }
        event = Click(id="other", window_id="main")
        result, _, _changed = dispatch_through_widgets(reg, event)
        assert result is event

    def test_unhandled_press_passes_through(self) -> None:
        """Pointer events from unmatched scope pass through to update()."""
        reg = {
            ("main", "main#other_widget"): RegistryEntry(
                definition=IgnoreAll(), state={}, props={}
            )
        }
        event = Press(
            id="raw_canvas",
            x=0.0,
            y=0.0,
            button="left",
            window_id="main",
            scope=(),
        )
        result, _, _changed = dispatch_through_widgets(reg, event)
        assert result is event


# ---------------------------------------------------------------------------
# Event spec validation tests
# ---------------------------------------------------------------------------


class TestEventSpecs:
    def _make_reg(self) -> dict[tuple[str, str], RegistryEntry]:
        return {
            ("main", "main#picker"): RegistryEntry(
                definition=ValidatedWidget(),
                state={},
                props={},
            )
        }

    def _click(self, element_id: str) -> Click:
        return Click(
            id=element_id,
            window_id="main",
            scope=("picker",),
        )

    def test_valid_data_event_passes(self) -> None:
        reg = self._make_reg()
        result, _, _changed = dispatch_through_widgets(reg, self._click("ring"))
        assert isinstance(result, RawEvent)
        assert result.kind == "change"
        assert result.data == {"hue": 180.0, "saturation": 0.5}

    def test_valid_value_event_produces_typed(self) -> None:
        reg = self._make_reg()
        result, _, _changed = dispatch_through_widgets(reg, self._click("star"))
        assert isinstance(result, Select)
        assert result.value == 3

    def test_valid_no_payload_event(self) -> None:
        reg = self._make_reg()
        # "cleared" has EventSpec(), no payload expected
        # The widget emits with None data -> normalized to {}
        # Need a widget that emits "cleared":

        class ClearWidget(WidgetDef):
            event_specs: ClassVar[dict[str, EventSpec]] = {
                "cleared": EventSpec(),
            }

            def init(self, props: dict[str, Any]) -> dict[str, Any]:
                return {}

            def view(
                self, widget_id: str, props: dict[str, Any], state: dict[str, Any]
            ) -> dict[str, Any]:
                return {"id": widget_id, "type": "canvas", "props": {}, "children": []}

            def handle_event(
                self, event: Any, state: dict[str, Any]
            ) -> EventActionResult:
                return EventAction.emit("cleared")

        reg = {
            ("main", "main#w"): RegistryEntry(
                definition=ClearWidget(), state={}, props={}
            )
        }
        event = Click(
            id="x",
            window_id="main",
            scope=("w",),
        )
        result, _, _changed = dispatch_through_widgets(reg, event)
        assert isinstance(result, RawEvent)
        assert result.kind == "cleared"

    def test_undeclared_event_name_raises(self) -> None:
        class BadWidget(WidgetDef):
            event_specs: ClassVar[dict[str, EventSpec]] = {
                "change": EventSpec(fields={"x": float}),
            }

            def init(self, props: dict[str, Any]) -> dict[str, Any]:
                return {}

            def view(
                self, widget_id: str, props: dict[str, Any], state: dict[str, Any]
            ) -> dict[str, Any]:
                return {"id": widget_id, "type": "canvas", "props": {}, "children": []}

            def handle_event(
                self, event: Any, state: dict[str, Any]
            ) -> EventActionResult:
                return EventAction.emit("chaneg", {"x": 1.0})  # typo!

        reg = {
            ("main", "main#w"): RegistryEntry(
                definition=BadWidget(), state={}, props={}
            )
        }
        event = Click(
            id="x",
            window_id="main",
            scope=("w",),
        )

        with pytest.raises(ValueError, match="undeclared event"):
            dispatch_through_widgets(reg, event)

    def test_missing_field_raises(self) -> None:
        class IncompleteWidget(WidgetDef):
            event_specs: ClassVar[dict[str, EventSpec]] = {
                "change": EventSpec(fields={"hue": float, "saturation": float}),
            }

            def init(self, props: dict[str, Any]) -> dict[str, Any]:
                return {}

            def view(
                self, widget_id: str, props: dict[str, Any], state: dict[str, Any]
            ) -> dict[str, Any]:
                return {"id": widget_id, "type": "canvas", "props": {}, "children": []}

            def handle_event(
                self, event: Any, state: dict[str, Any]
            ) -> EventActionResult:
                return EventAction.emit("change", {"hue": 180.0})  # missing saturation

        reg = {
            ("main", "main#w"): RegistryEntry(
                definition=IncompleteWidget(), state={}, props={}
            )
        }
        event = Click(
            id="x",
            window_id="main",
            scope=("w",),
        )

        with pytest.raises(ValueError, match="missing declared fields"):
            dispatch_through_widgets(reg, event)

    def test_wrong_value_type_raises(self) -> None:
        class WrongTypeWidget(WidgetDef):
            event_specs: ClassVar[dict[str, EventSpec]] = {
                "select": EventSpec(value_type=int),
            }

            def init(self, props: dict[str, Any]) -> dict[str, Any]:
                return {}

            def view(
                self, widget_id: str, props: dict[str, Any], state: dict[str, Any]
            ) -> dict[str, Any]:
                return {"id": widget_id, "type": "canvas", "props": {}, "children": []}

            def handle_event(
                self, event: Any, state: dict[str, Any]
            ) -> EventActionResult:
                return EventAction.emit("select", "not_an_int")

        reg = {
            ("main", "main#w"): RegistryEntry(
                definition=WrongTypeWidget(), state={}, props={}
            )
        }
        event = Click(
            id="x",
            window_id="main",
            scope=("w",),
        )

        with pytest.raises(TypeError, match="expected int"):
            dispatch_through_widgets(reg, event)

    def test_builtin_event_allowed_without_declaration(self) -> None:
        """A widget with event_specs can still emit built-in events."""

        class ClickEmitter(WidgetDef):
            event_specs: ClassVar[dict[str, EventSpec]] = {
                "custom": EventSpec(),
            }

            def init(self, props: dict[str, Any]) -> dict[str, Any]:
                return {}

            def view(
                self, widget_id: str, props: dict[str, Any], state: dict[str, Any]
            ) -> dict[str, Any]:
                return {"id": widget_id, "type": "canvas", "props": {}, "children": []}

            def handle_event(
                self, event: Any, state: dict[str, Any]
            ) -> EventActionResult:
                return EventAction.emit("click")

        reg = {
            ("main", "main#w"): RegistryEntry(
                definition=ClickEmitter(), state={}, props={}
            )
        }
        event = Click(
            id="x",
            window_id="main",
            scope=("w",),
        )
        result, _, _changed = dispatch_through_widgets(reg, event)
        assert isinstance(result, Click)

    def test_no_event_specs_skips_validation(self) -> None:
        """Widgets without event_specs can emit anything."""
        reg = {
            ("main", "main#picker"): RegistryEntry(
                definition=CustomEmitter(),  # no event_specs
                state={},
                props={},
            )
        }
        result, _, _changed = dispatch_through_widgets(reg, self._click("ring"))
        assert isinstance(result, RawEvent)
        assert result.kind == "change"

    def test_optional_field_omitted_passes(self) -> None:
        class OptWidget(WidgetDef):
            event_specs: ClassVar[dict[str, EventSpec]] = {
                "change": EventSpec(
                    fields={"hue": float, "saturation": float, "modifier": str},
                    optional=("modifier",),
                ),
            }

            def init(self, props: dict[str, Any]) -> dict[str, Any]:
                return {}

            def view(
                self, widget_id: str, props: dict[str, Any], state: dict[str, Any]
            ) -> dict[str, Any]:
                return {"id": widget_id, "type": "canvas", "props": {}, "children": []}

            def handle_event(
                self, event: Any, state: dict[str, Any]
            ) -> EventActionResult:
                return EventAction.emit("change", {"hue": 180.0, "saturation": 0.5})

        reg = {
            ("main", "main#w"): RegistryEntry(
                definition=OptWidget(), state={}, props={}
            )
        }
        event = Click(id="x", window_id="main", scope=("w",))
        result, _, _changed = dispatch_through_widgets(reg, event)
        assert isinstance(result, RawEvent)
        assert result.kind == "change"
        assert result.data == {"hue": 180.0, "saturation": 0.5}
        assert "modifier" not in result.data

    def test_optional_field_present_passes(self) -> None:
        class OptWidget(WidgetDef):
            event_specs: ClassVar[dict[str, EventSpec]] = {
                "change": EventSpec(
                    fields={"hue": float, "modifier": str},
                    optional=("modifier",),
                ),
            }

            def init(self, props: dict[str, Any]) -> dict[str, Any]:
                return {}

            def view(
                self, widget_id: str, props: dict[str, Any], state: dict[str, Any]
            ) -> dict[str, Any]:
                return {"id": widget_id, "type": "canvas", "props": {}, "children": []}

            def handle_event(
                self, event: Any, state: dict[str, Any]
            ) -> EventActionResult:
                return EventAction.emit("change", {"hue": 180.0, "modifier": "shift"})

        reg = {
            ("main", "main#w"): RegistryEntry(
                definition=OptWidget(), state={}, props={}
            )
        }
        event = Click(id="x", window_id="main", scope=("w",))
        result, _, _changed = dispatch_through_widgets(reg, event)
        assert isinstance(result, RawEvent)
        assert result.data["modifier"] == "shift"

    def test_optional_field_wrong_type_raises(self) -> None:
        class OptWidget(WidgetDef):
            event_specs: ClassVar[dict[str, EventSpec]] = {
                "change": EventSpec(
                    fields={"hue": float, "modifier": str},
                    optional=("modifier",),
                ),
            }

            def init(self, props: dict[str, Any]) -> dict[str, Any]:
                return {}

            def view(
                self, widget_id: str, props: dict[str, Any], state: dict[str, Any]
            ) -> dict[str, Any]:
                return {"id": widget_id, "type": "canvas", "props": {}, "children": []}

            def handle_event(
                self, event: Any, state: dict[str, Any]
            ) -> EventActionResult:
                return EventAction.emit("change", {"hue": 180.0, "modifier": 42})

        reg = {
            ("main", "main#w"): RegistryEntry(
                definition=OptWidget(), state={}, props={}
            )
        }
        event = Click(id="x", window_id="main", scope=("w",))
        with pytest.raises(TypeError, match="modifier"):
            dispatch_through_widgets(reg, event)

    def test_required_field_still_required_with_optional(self) -> None:
        class OptWidget(WidgetDef):
            event_specs: ClassVar[dict[str, EventSpec]] = {
                "change": EventSpec(
                    fields={"hue": float, "modifier": str},
                    optional=("modifier",),
                ),
            }

            def init(self, props: dict[str, Any]) -> dict[str, Any]:
                return {}

            def view(
                self, widget_id: str, props: dict[str, Any], state: dict[str, Any]
            ) -> dict[str, Any]:
                return {"id": widget_id, "type": "canvas", "props": {}, "children": []}

            def handle_event(
                self, event: Any, state: dict[str, Any]
            ) -> EventActionResult:
                return EventAction.emit("change", {"modifier": "shift"})

        reg = {
            ("main", "main#w"): RegistryEntry(
                definition=OptWidget(), state={}, props={}
            )
        }
        event = Click(id="x", window_id="main", scope=("w",))
        with pytest.raises(ValueError, match=r"missing declared fields.*hue"):
            dispatch_through_widgets(reg, event)

    def test_spec_rejects_unknown_optional_field(self) -> None:
        with pytest.raises(ValueError, match="optional fields not in fields"):
            EventSpec(fields={"x": float}, optional=("y",))

    def test_spec_rejects_optional_without_fields(self) -> None:
        with pytest.raises(ValueError, match="optional fields require"):
            EventSpec(optional=("x",))


# ---------------------------------------------------------------------------
# Subscription collection tests
# ---------------------------------------------------------------------------


class TestCollectSubscriptions:
    def test_namespaced_tags(self) -> None:
        reg = {
            ("main", "widget1"): RegistryEntry(
                definition=WithSubscriptions(), state={}, props={}
            )
        }
        subs = collect_subscriptions(reg)
        assert len(subs) == 1
        assert subs[0].tag == ("__widget__", "main", "widget1", "tick")


# ---------------------------------------------------------------------------
# Timer routing tests
# ---------------------------------------------------------------------------


class TestMaybeHandleTimer:
    def test_non_widget_tag_not_routed(self) -> None:
        handled, _, _ = maybe_handle_timer({}, "regular_tag")
        assert handled is False

    def test_widget_tag_routed(self) -> None:
        reg = {
            ("main", "main#stars"): RegistryEntry(
                definition=IgnoreAll(), state={}, props={}
            )
        }
        handled, event, _ = maybe_handle_timer(
            reg, ("__widget__", "main", "main#stars", "tick")
        )
        assert handled is True
        assert event is None  # IgnoreAll ignores everything
