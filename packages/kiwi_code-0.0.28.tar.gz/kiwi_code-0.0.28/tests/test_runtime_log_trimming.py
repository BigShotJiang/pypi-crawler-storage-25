from __future__ import annotations

from pathlib import Path

import pytest

from kiwi_tui.runtime_agent import MAX_RUNTIME_LOG_BYTES, _trim_file_to_tail_bytes
from kiwi_tui.screens.runtime_logs import _tail_lines


def _make_log_bytes(num_lines: int) -> bytes:
    # Fixed-width lines make expected tails deterministic.
    return b"".join([f"line-{i:06d} hello world\n".encode("utf-8") for i in range(num_lines)])


def test_trim_file_to_tail_bytes_keeps_last_bytes(tmp_path: Path) -> None:
    p = tmp_path / "log"
    payload = _make_log_bytes(20000)  # plenty bigger than 30KB
    p.write_bytes(payload)

    _trim_file_to_tail_bytes(p, max_bytes=MAX_RUNTIME_LOG_BYTES)

    data = p.read_bytes()
    assert len(data) <= MAX_RUNTIME_LOG_BYTES

    # We should keep the most recent line.
    assert b"line-019999" in data

    # We should *not* keep the earliest line.
    assert b"line-000000" not in data


def test_tail_lines_reads_tail_window(tmp_path: Path) -> None:
    p = tmp_path / "log"
    payload = _make_log_bytes(5000)
    p.write_bytes(payload)

    # Read a small tail window and last few lines from it.
    lines = _tail_lines(p, max_lines=5, max_bytes=512)
    assert len(lines) == 5

    # Must include the final log line.
    assert lines[-1].startswith("line-004999")
