"""Slash command picker modal screen."""

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Vertical
from textual.screen import ModalScreen
from textual.widgets import OptionList, Static
from textual.widgets.option_list import Option

from kiwi_tui.slash_commands import SLASH_COMMANDS


# Commands and their descriptions (single source of truth).
# We show the template in the picker, and return insert_text on selection.
_COMMANDS = [(c.insert_text, c.template, c.description) for c in SLASH_COMMANDS]


class SlashPickerScreen(ModalScreen[str]):
    """Modal that lets the user pick a slash command.

    Returns the command string (insert_text), or empty string if cancelled.
    Commands that don't need arguments are returned as-is for immediate execution.
    Commands that expect args end with a trailing space ("/use ").
    """

    BINDINGS = [
        Binding("escape", "cancel", "Cancel", show=True),
    ]

    CSS = """
    SlashPickerScreen {
        align: center middle;
    }

    #slash-container {
        width: 70;
        height: 80%;
        background: $surface;
        border: solid $accent;
        padding: 1 2;
    }

    #slash-title {
        width: 100%;
        text-align: center;
        text-style: bold;
        color: $primary;
        height: 1;
        margin-bottom: 1;
    }

    #slash-list {
        height: 1fr;
        width: 100%;
        border: solid $panel;
    }
    """

    def compose(self) -> ComposeResult:
        with Vertical(id="slash-container"):
            yield Static("Select a command", id="slash-title")
            option_list = OptionList(id="slash-list")
            for insert_text, template, desc in _COMMANDS:
                option_list.add_option(Option(f"{template:<32} {desc}", id=insert_text))
            yield option_list

    def on_option_list_option_selected(self, event: OptionList.OptionSelected) -> None:
        cmd = event.option.id or ""
        self.dismiss(cmd)

    def action_cancel(self) -> None:
        self.dismiss("")
