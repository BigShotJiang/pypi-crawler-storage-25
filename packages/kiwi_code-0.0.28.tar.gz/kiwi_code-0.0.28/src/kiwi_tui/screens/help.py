import subprocess
import sys
import time

from rich.text import Text
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Vertical
from textual.screen import ModalScreen
from textual.widgets import OptionList, Static
from textual.widgets.option_list import Option

from kiwi_tui.slash_commands import SLASH_COMMANDS


class HelpScreen(ModalScreen[None]):
    """Modal that lists available slash commands and allows copying."""

    BINDINGS = [
        Binding("escape", "close", "Close", show=True),
        Binding("c", "copy", "Copy", show=True),
    ]

    CSS = """
    HelpScreen {
        align: center middle;
    }

    #help-container {
        width: 96;
        height: 80%;
        background: $surface;
        border: solid $accent;
        /* Reduce top padding so the title/hint sit closer to the border. */
        padding: 0 3 1 3;
    }

    #help-title {
        width: 100%;
        text-align: center;
        text-style: bold;
        color: $primary;
        height: 1;
        /* Tighten vertical spacing at the top of the modal. */
        margin-bottom: 0;
    }

    #help-hint {
        width: 100%;
        height: 1;
        padding: 0 1;
        color: $text-muted;
        text-style: italic;
        margin-bottom: 0;
    }

    #help-list {
        height: 1fr;
        width: 100%;
        border: solid $panel;
        background: $surface;
        scrollbar-size: 1 1;
        /* Keep the list away from the container border for consistent margins. */
        margin: 0 1;
    }

    #help-list > .option-list--option-highlighted {
        background: $primary-background;
        color: $primary;
        text-style: bold;
    }
    """

    def __init__(self) -> None:
        super().__init__()
        self._last_copy_notify_at: float = 0.0
        self._last_highlight_index: int | None = None
        self._highlight_skip_guard: bool = False

    def on_mount(self) -> None:
        # Match the UX of the inline @ picker: focus the list and highlight the first command.
        option_list = self.query_one("#help-list", OptionList)
        try:
            for idx, opt in enumerate(option_list.options):
                if not getattr(opt, "disabled", False) and opt.id:
                    option_list.highlighted = idx
                    break
        except Exception:
            pass
        option_list.focus()

    def compose(self) -> ComposeResult:
        # Column widths tuned for a typical terminal width; the OptionList will clip if narrower.
        cmd_col_width = 38
        with Vertical(id="help-container"):
            yield Static("Slash Commands", id="help-title")
            yield Static("Enter/click: copy   C: copy highlighted   Esc: close", id="help-hint")

            option_list = OptionList(id="help-list")

            last_category: str | None = None
            for cmd in SLASH_COMMANDS:
                if cmd.category != last_category:
                    # Add a blank spacer row between sections for readability.
                    if last_category is not None:
                        option_list.add_option(Option(Text(""), id=None, disabled=True))

                    last_category = cmd.category
                    option_list.add_option(
                        Option(Text(f" {cmd.category.upper()}", style="bold cyan"), id=None, disabled=True)
                    )

                # Option id is the command template so we can copy exactly what is shown.
                label = f"  {cmd.template:<{cmd_col_width}} {cmd.description}"
                option_list.add_option(Option(Text(label), id=cmd.template))

            yield option_list

    def on_option_list_option_highlighted(self, event: OptionList.OptionHighlighted) -> None:
        """Skip spacer/category rows while navigating with arrow keys."""
        if self._highlight_skip_guard:
            return

        # Track previous position so we can infer direction.
        prev = self._last_highlight_index

        # Textual versions differ slightly in attribute names.
        idx = getattr(event, "index", None)
        if idx is None:
            idx = getattr(event, "option_index", None)
        if idx is None:
            return

        self._last_highlight_index = idx

        option = event.option
        if option.id and not getattr(option, "disabled", False):
            return

        option_list = event.option_list
        try:
            direction = -1 if (prev is not None and idx < prev) else 1
            n = len(option_list.options)
            self._highlight_skip_guard = True
            cur = idx
            while 0 <= cur < n:
                cur += direction
                if not (0 <= cur < n):
                    break
                opt = option_list.options[cur]
                if opt.id and not getattr(opt, "disabled", False):
                    option_list.highlighted = cur
                    self._last_highlight_index = cur
                    break
        finally:
            self._highlight_skip_guard = False



    def _notify_once(self, msg: str, *, severity: str) -> None:
        now = time.monotonic()
        if now - self._last_copy_notify_at < 1.0:
            return
        self._last_copy_notify_at = now
        self.app.notify(msg, severity=severity)

    def _copy_to_clipboard(self, text: str) -> bool:
        """Copy text to the system clipboard. Returns True if it likely worked."""
        copied = False

        # Prefer native OS clipboard tools (more reliable in terminal apps).
        try:
            if sys.platform == "darwin":
                subprocess.run(["pbcopy"], input=text.encode("utf-8"), check=True)
                copied = True
            elif sys.platform.startswith("linux"):
                subprocess.run(
                    ["xclip", "-selection", "clipboard"],
                    input=text.encode("utf-8"),
                    check=True,
                )
                copied = True
            elif sys.platform.startswith("win"):
                subprocess.run(["clip"], input=text.encode("utf-8"), check=True)
                copied = True
        except Exception:
            copied = False

        # Fallback to Textual's clipboard integration.
        if not copied:
            try:
                self.app.copy_to_clipboard(text)
                copied = True
            except Exception:
                copied = False

        return copied

    def _copy_selected(self, template: str) -> None:
        if not template.strip():
            return
        if self._copy_to_clipboard(template):
            self._notify_once(f"Copied: {template}", severity="information")
        else:
            self._notify_once("Failed to copy to clipboard", severity="error")

    def on_option_list_option_selected(self, event: OptionList.OptionSelected) -> None:
        template = event.option.id
        if template:
            self._copy_selected(str(template))

    def action_copy(self) -> None:
        option_list = self.query_one("#help-list", OptionList)
        opt = option_list.highlighted_option
        if opt and opt.id:
            self._copy_selected(str(opt.id))

    def action_close(self) -> None:
        self.dismiss(None)
