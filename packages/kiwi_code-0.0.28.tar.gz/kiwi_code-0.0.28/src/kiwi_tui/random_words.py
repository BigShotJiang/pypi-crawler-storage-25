from functools import lru_cache


@lru_cache(maxsize=1)
def _ww() -> object | None:
    try:
        from wonderwords import RandomWord  # type: ignore

        return RandomWord()
    except Exception:
        return None


def _to_present_participle(verb: str) -> str:
    v = (verb or "").strip()
    if not v:
        return ""
    w = v.lower()

    # Common irregulars / spelling rules that a simple suffix approach misses.
    irregular = {
        "be": "being",
        "see": "seeing",
        "flee": "fleeing",
        "knee": "kneeing",
        "die": "dying",
        "tie": "tying",
        "lie": "lying",
    }
    if w in irregular:
        return irregular[w].capitalize()

    # ie -> ying (die -> dying).
    if w.endswith("ie") and len(w) > 2:
        return (w[:-2] + "ying").capitalize()

    # Drop trailing e (make -> making), but keep ee/ye/oe (see -> seeing).
    if w.endswith("e") and not w.endswith(("ee", "ye", "oe")) and len(w) > 1:
        return (w[:-1] + "ing").capitalize()

    # Verbs ending in 'ic' often add 'k' (panic -> panicking).
    if w.endswith("ic") and len(w) > 2:
        return (w + "king").capitalize()

    vowels = set("aeiou")
    # Double final consonant for short CVC words with a/i/o/u vowel (run -> running).
    if (
        3 <= len(w) <= 4
        and w[-1] not in vowels
        and w[-1] not in "wxy"
        and w[-2] in vowels
        and w[-2] != "e"
        and w[-3] not in vowels
    ):
        return (w + w[-1] + "ing").capitalize()

    return (w + "ing").capitalize()


def random_verb(*, default: str = "Thinking") -> str:
    """Return a random present-participle verb for display (e.g. "Searching")."""
    rw = _ww()
    if rw is None:
        return default

    try:
        # wonderwords supports parts_of_speech filtering.
        word = rw.word(include_parts_of_speech=["verbs"])  # type: ignore[attr-defined]
        word = str(word or "").strip()
        if not word:
            return default
        ing = _to_present_participle(word)
        return ing if ing else default
    except Exception:
        return default


# Backward-compat alias (older code used adjectives).
def random_adjective(*, default: str = "Curious") -> str:  # pragma: no cover
    return default