"""Error reports module."""
