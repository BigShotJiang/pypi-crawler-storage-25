"""The base backend implementation."""
