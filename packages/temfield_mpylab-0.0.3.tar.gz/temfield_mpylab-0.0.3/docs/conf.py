import os
import sys
from pathlib import Path
try:
    from importlib.metadata import version as pkg_version
    release = pkg_version("temfield_mpylab")
except Exception:
    release = "dev"

src_dir = Path(__file__).resolve().parent.parent / 'src'
sys.path.insert(0, str(src_dir))

project = 'temfield_mpylab'
copyright = '2026, Hans Georg Krauthäuser'
author = 'Hans Georg Krauthäuser'

version = ".".join(release.split(".")[:2])

extensions = [
    'sphinx.ext.autodoc',       # Automatische API-Dokumentation aus Docstrings
    'sphinx.ext.viewcode',      # Fügt "View Source"-Links hinzu
    'sphinx.ext.intersphinx',   # Links zu externer Doku (numpy, scipy, python)
    'sphinx.ext.todo',          # TODO-Kommentare
    'matplotlib.sphinxext.roles',
]

templates_path = ['_templates']
exclude_patterns = ['_build', 'Thumbs.db', '.DS_Store']
html_theme = 'default'

# Name der Hauptdatei
master_doc = 'index'
html_static_path = ['_static']

autodoc_default_options = {
    'members': True,           # Alle Mitglieder dokumentieren
    'member-order': 'bysource', # Reihenfolge wie im Code, nicht alphabetisch
    'special-members': '__init__', # __init__ Methoden einschließen
    'undoc-members': True,     # Auch undocumented members zeigen (optional)
    'exclude-members': (
        '__weakref__,'
        'Figure,FigureCanvas,NavigationToolbar,'
        'QApplication,QFileDialog,QMainWindow,QMessageBox,QTableWidgetItem,'
        'QVBoxLayout,QWidget,QObject,QMutex,QMutexLocker,QSettings,QThread,'
        'QWaitCondition,QLocale,Qt,Signal,Slot'
    ),
    'show-inheritance': True,  # Vererbung anzeigen
    'imported-members': False, # Nur lokale Mitglieder (optional)
}


def skip_external_members(app, what, name, obj, skip, options):
    """Hide imported Qt and Matplotlib objects from project API pages."""
    module = getattr(obj, '__module__', '')
    if module.startswith(('PySide6.', 'matplotlib.')):
        return True
    return skip


def setup(app):
    app.connect('autodoc-skip-member', skip_external_members)

# -----------------------------------------------------------------------------
# 7. INTERSPHINX MAPPING (Externe Links)
# -----------------------------------------------------------------------------
intersphinx_mapping = {
    'python': ('https://docs.python.org/3', None),
    'numpy': ('https://numpy.org/doc/stable/', None),
    'scipy': ('https://docs.scipy.org/doc/scipy/', None),
    'matplotlib': ('https://matplotlib.org/stable/', None),
    'mpylab': ('https://mpylab-75fcff.gp.hrz.tu-chemnitz.de/', None),
    'scuq': ('https://scuq-b5d96a.gp.hrz.tu-chemnitz.de/', None),
}

# -----------------------------------------------------------------------------
# 8. SONSTIGE OPTIONEN
# -----------------------------------------------------------------------------
mathjax_path = 'https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js'
todo_include_todos = True

# -----------------------------------------------------------------------------
# 9. AUTOMATISCHE INDEX GENERIERUNG (Optional)
# -----------------------------------------------------------------------------
# Wenn du 'sphinx.ext.autosummary' nutzen willst, um automatisch RST-Dateien zu generieren:
# extensions.append('sphinx.ext.autosummary')
# autosummary_generate = True
