temfield_mpylab.TestSusceptibility
==================================

.. automodule:: temfield_mpylab.TestSusceptibility
   :members:
   :undoc-members:
