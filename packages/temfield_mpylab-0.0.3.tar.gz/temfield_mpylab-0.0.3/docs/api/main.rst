temfield_mpylab.main
====================

This module contains the PySide6 GUI entry point for TEMField.

It is intentionally not imported by the API documentation build, because
importing it loads the Qt Matplotlib backend and PySide6 widget stack. On
headless CI runners this can require system OpenGL/EGL/XCB libraries that are
not needed for documenting the non-GUI measurement API.

The public command line entry point is:

.. code-block:: text

   temfield

The application entry function is:

.. code-block:: python

   temfield_mpylab.main.main()
