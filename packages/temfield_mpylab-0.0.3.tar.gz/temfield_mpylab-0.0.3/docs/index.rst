temfield-mpylab documentation
=============================

TEMField performs radiated susceptibility measurements in (G)TEM cells using
MpyLab. The PySide6 user interface starts the measurement sequence in a
dedicated worker thread, keeping the GUI responsive while instrument commands
are executed by the measurement worker.

Installation
------------

Install the package from PyPI:

.. code-block:: bash

   pip install temfield-mpylab

For an isolated application-style installation, ``pipx`` is also useful:

.. code-block:: bash

   pipx install temfield-mpylab

This installs the package in its own environment and exposes the command line
tools ``temfield`` and ``temfield-info`` on your ``PATH``.

Run ``main.py`` from the package or use the installed ``temfield`` entry point.
Use ``temfield-info`` to show installation and dependency information, or
``temfield-info --json`` for machine-readable output.

API
---

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   api/index
