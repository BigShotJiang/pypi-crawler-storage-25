# TemField

Radiated EMC susceptibility measurements in (G)TEM waveguides using **mpylab**

This software is distributed unter GPL-3 or higher. See LICENSE for details.

## Installation

```bash
pip install temfield-mpylab
```

For an isolated application-style installation, `pipx` is also useful:

```bash
pipx install temfield-mpylab
```

This installs the package in its own environment and exposes the command line
tools `temfield` and `temfield-info` on your `PATH`.

## Command line

Start the GUI with:

```bash
temfield
```

Show installation and dependency information with:

```bash
temfield-info
```

Use `temfield-info --json` for machine-readable output.

## License

GPL-3 or higher

## Repository

[https://gitlab.hrz.tu-chemnitz.de/chair-of-electromagnetic-theory-and-compatibility-at-tu-dresden/mpylab/TEMField.git](https://gitlab.hrz.tu-chemnitz.de/chair-of-electromagnetic-theory-and-compatibility-at-tu-dresden/mpylab/TEMField.git)

## Documentation

[https://temfield-1012e2.gp.hrz.tu-chemnitz.de/](https://temfield-1012e2.gp.hrz.tu-chemnitz.de/)


## Contact

Prof. Dr. Hans Georg Krauthäuser (hgk@ieee.org)  
Chair for Electromagnetic Theory and Compatibility  
Technische Universität Dresden, Dresden, Germany
