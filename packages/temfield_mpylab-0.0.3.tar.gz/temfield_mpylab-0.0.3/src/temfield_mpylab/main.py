# This Python file uses the following encoding: utf-8
import os.path
import sys
import csv
import datetime
import time
import ast

import numpy as np

from matplotlib.backends.backend_qtagg import (FigureCanvasQTAgg as FigureCanvas,
                                               NavigationToolbar2QT as NavigationToolbar)
from matplotlib.figure import Figure

from PySide6.QtCore import Qt, QLocale, QSettings, QThread
from PySide6.QtWidgets import (QApplication, QMainWindow, QMessageBox,
                               QFileDialog, QTableWidgetItem, QVBoxLayout, QWidget)

from mpylab.tools.spacing import logspace, linspace
from mpylab.tools.util import tstamp
from mpylab.tools.sin_fit import fit_sin

try:
    from .measurement_worker import TEMFieldWorker
except ImportError:
    from measurement_worker import TEMFieldWorker

# Important:
# You need to run the following command to generate the mainwindow.py file
#     pyside6-uic mainwindow.ui -o mainwindow.py
try:
    from .mainwindow import Ui_MainWindow
except ImportError:
    from mainwindow import Ui_MainWindow


class MainWindow(QMainWindow):
    def __init__(self, settings, parent=None):
        super().__init__(parent)
        self.eut_status = "Unknown"
        self.eut_finished = False
        self.settings = settings
        self.ready_for_next_freq = True
        self.measurement_thread = None
        self.worker = None
        self.latest_waveform = None
        self.main_e_component = None
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)

        self.table_is_unsaved = False
        self.disable_update = True
        self._read_setup()
        self.disable_update = False

        def _adjust(x):
            self.adjust_to_setting = x
        # register adjust radio buttons
        self.ui.radioButton_Ex.clicked.connect(lambda: _adjust('x'))
        self.ui.radioButton_Ey.clicked.connect(lambda: _adjust('y'))
        self.ui.radioButton_Ez.clicked.connect(lambda: _adjust('z'))
        self.ui.radioButton_absE.clicked.connect(lambda: _adjust('mag'))
        self.ui.radioButton_Largest_E.clicked.connect(lambda: _adjust('largest'))
        self.ui.radioButton_Auto.clicked.connect(lambda: _adjust('auto'))

        # register message box for quit action
        self.ui.actionQuit.triggered.connect(MainWindow.close)
        # File Dialog
        self.ui.actionLoad_Graph.triggered.connect(self.load_graph)

        # cw field strength
        self.ui.cw_doubleSpinBox.valueChanged.connect(self.cw_doubleSpinBox_changed)
        # am percentage
        self.ui.am_spinBox.valueChanged.connect(self.am_spinBox_changed)
        # about
        self.ui.actionAbout.triggered.connect(self.about_triggered)
        # node names
        self.ui.node_names_tableWidget.cellChanged.connect(self.node_names_table_cellChanged)
        # update the other fields
        self.update()
        self.ui.start_pause_pushButton.setDisabled(True)
        self.node_names_table_cellChanged()
        self.ui.start_pause_pushButton.clicked.connect(self.start_pause_pushButton_clicked)
        self.ui.EUT_plainTextEdit.textChanged.connect(self.EUT_plainTextEdit_changed)
        self.ui.save_table_pushButton.clicked.connect(self.save_Table)
        self.ui.clear_table_pushButton.clicked.connect(self.clear_Table)
        # waveform
        self.efield_canvas = FigureCanvas(Figure(figsize=(5, 4)))
        self.efield_toolbar = NavigationToolbar(self.efield_canvas, self)

        layout = QVBoxLayout()
        layout.addWidget(self.efield_toolbar)
        layout.addWidget(self.efield_canvas)
        widget = QWidget()
        widget.setLayout(layout)
        self.ui.waveform_scrollArea.setWidget(widget)
        self._efield_ax = self.efield_canvas.figure.subplots()
        t = np.linspace(0, 10, 101)
        self.lineEx, = self._efield_ax.plot(t, np.sin(t + time.time()), marker=',', label='Ex')
        self.lineEy, = self._efield_ax.plot(t, np.sin(t + time.time()*2), marker=',', label='Ey')
        self.lineEz, = self._efield_ax.plot(t, np.sin(t + time.time()*3), marker=',', label='Ez')
        self.lineSin, = self._efield_ax.plot(t, np.sin(t + time.time()), ls='-', label='sin-fit (Ex)')
        self._efield_ax.set_xlabel("Time in ms")
        self._efield_ax.set_ylabel("E-Field in V/m")
        self._efield_ax.set_title("Dummy Plot")
        self._efield_ax.legend(loc='upper right')
        self._efield_ax.grid(True)
        # Set up a Line2D.
        self._timer = self.efield_canvas.new_timer(50)
        self._timer.add_callback(self._update_efield)
        self._timer.start()

        self.ui.start_pause_pushButton.setDisabled(False)
        self.ui.rf_pushButton.clicked.connect(self.toggle_rf)
        self.rf_isON = False
        self.ui.modulation_pushButton.clicked.connect(self.toggle_am)
        self.am_isON = False

    def _update_efield(self):
        data = self.latest_waveform or {}
        err = data.get("err", -1)
        t = data.get("t")
        ex = data.get("ex")
        ey = data.get("ey")
        ez = data.get("ez")
        if err < 0:
            t = np.linspace(0, 10, 101)
            # Shift the sinusoid as a function of time.
            self.lineEx.set_data(t, np.sin(t + time.time()))
            self.lineEy.set_data(t, np.sin(t + time.time() * 2))
            self.lineEz.set_data(t, np.sin(t + time.time() * 3))
            self.lineSin.set_data(t, np.sin(t + time.time()))
        else:
            self.lineEx.set_data(t, ex)
            self.lineEy.set_data(t, ey)
            self.lineEz.set_data(t, ez)
            if self.adjust_to_setting == 'x' or self.main_e_component == 0:
                _e = ex
            elif self.adjust_to_setting == 'y' or self.main_e_component == 1:
                _e = ey
            elif self.adjust_to_setting == 'z' or self.main_e_component == 2:
                _e = ez
            elif self.adjust_to_setting == 'mag':
                _e = np.sqrt(np.square(ex) + np.square(ey) + np.square(ez))
            elif self.adjust_to_setting == 'largest':
                max_vals = (max(ex), max(ey), max(ez))
                _i = max_vals.index(max(max_vals))
                _e = (ex, ey, ez)[_i]
            else:
                _e = ex

            fitdata = fit_sin(t, _e)
            freqAM = fitdata['freq']
            meanAM = fitdata['offset']
            modAM = abs(fitdata['amp']) / meanAM * 100
            self.lineSin.set_data(t, fitdata['fitfunc'](t))
            self._efield_ax.set_title(f"E-Field: {meanAM:.2f} V/m, AM-Freq: {freqAM:.2f} kHz, AM-Depth: {modAM:.2f} %")
            self._efield_ax.relim()
            self._efield_ax.autoscale_view(True, True, True)
        self.lineEx.figure.canvas.draw()

    def EUT_plainTextEdit_changed(self):
        self.eut_description = self.ui.EUT_plainTextEdit.toPlainText()

    def log(self, text, short = None):
        if short is None:
            short = text
        longtext = f"{self.get_time_as_string(format='')}: {text}"
        self.ui.logtab_log_plainTextEdit.appendPlainText(longtext)
        self.ui.permanent_log_plainTextEdit.appendPlainText(short)

    def do_fill_table(self, freq=None, cw=(None,None,None), status=None):
        self.table_is_unsaved = True
        table = self.ui.table_tableWidget
        rowposition = table.rowCount()
        table.insertRow(rowposition)
        val = QTableWidgetItem(self.get_time_as_string(format=''))
        val.setFlags(val.flags() & ~Qt.ItemFlag.ItemIsEditable)
        table.setItem(rowposition, 0, val)
        val = QTableWidgetItem(str(freq*1e-6))
        val.setFlags(val.flags() & ~Qt.ItemFlag.ItemIsEditable)
        table.setItem(rowposition, 1, val)
        magnitude = 0.0
        for _r,_cw in enumerate(cw):
            val = QTableWidgetItem(str(round(_cw,2)))
            val.setFlags(val.flags() & ~Qt.ItemFlag.ItemIsEditable)
            table.setItem(rowposition, 2+_r, val)
            magnitude += _cw*_cw
        magnitude = np.sqrt(magnitude)
        val = QTableWidgetItem(str(round(magnitude, 2)))
        val.setFlags(val.flags() & ~Qt.ItemFlag.ItemIsEditable)
        table.setItem(rowposition, 5, val)
        table.setItem(rowposition, 6, QTableWidgetItem(str(status)))
        table.verticalScrollBar().setSliderPosition(table.verticalScrollBar().maximum())

    def clear_Table(self):
        table = self.ui.table_tableWidget
        table.clearContents()
        table.setRowCount(0)
        self.table_is_unsaved = False

    def _measurement_is_running(self):
        return self.measurement_thread is not None and self.measurement_thread.isRunning()

    def _searchpath_list(self):
        try:
            return ast.literal_eval(self.searchpath)
        except (SyntaxError, ValueError):
            return [self.searchpath]

    def _set_measurement_state(self, *, running, paused=False):
        self.ui.start_pause_pushButton.setText("Cont. Test" if paused else ("Pause Test" if running else "Start Test"))
        self.ui.clear_table_pushButton.setEnabled(not running)

    def _start_measurement(self):
        if self._measurement_is_running():
            return

        self.clear_Table()
        self.latest_waveform = None
        self.main_e_component = None
        self.ui.test_progressBar.setValue(0)
        self.ui.EUT_progressBar.setValue(0)
        self.log("Start Test")
        self.log(f"EUT description: {self.eut_description}")

        self.measurement_thread = QThread()
        self.measurement_thread.setObjectName("TEMField_Measurement_Thread")
        self.worker = TEMFieldWorker(dwell_time=self.dwell_time,
                                     e_target=self.cw,
                                     names=self.names.copy(),
                                     dotfile=self.dotfile,
                                     searchpath=self._searchpath_list(),
                                     adjust_to_setting=self.adjust_to_setting,
                                     am=self.am,
                                     freqs=self.freqs.copy())
        self.worker.moveToThread(self.measurement_thread)

        self.worker.log.connect(self.log)
        self.worker.test_progress.connect(self.ui.test_progressBar.setValue)
        self.worker.eut_progress.connect(self.ui.EUT_progressBar.setValue)
        self.worker.frequency_done.connect(self._frequency_done)
        self.worker.waveform.connect(self._waveform_received)
        self.worker.rf_state_changed.connect(self._rf_state_changed)
        self.worker.am_state_changed.connect(self._am_state_changed)
        self.worker.error.connect(self._worker_error)

        self.measurement_thread.started.connect(self.worker.run)
        self.worker.finished.connect(self.measurement_thread.quit)
        self.worker.finished.connect(self.worker.deleteLater)
        self.measurement_thread.finished.connect(self._on_measurement_thread_finished)

        self.measurement_thread.start()
        self._set_measurement_state(running=True, paused=False)

    def _frequency_done(self, data):
        self.do_fill_table(freq=data["freq"],
                           cw=(_e.get_expectation_value_as_float() for _e in data["e_field"]),
                           status=data["status"])

    def _waveform_received(self, data):
        self.latest_waveform = data
        self.main_e_component = data.get("main_e_component")

    def _rf_state_changed(self, state):
        self.rf_isON = state
        self.ui.rf_pushButton.setChecked(state)

    def _am_state_changed(self, state):
        self.am_isON = state
        self.ui.modulation_pushButton.setChecked(state)

    def _worker_error(self, text):
        self.log(text)

    def _on_measurement_thread_finished(self):
        if self.measurement_thread is not None:
            self.measurement_thread.deleteLater()
        self.worker = None
        self.measurement_thread = None
        self.rf_isON = False
        self.am_isON = False
        self.ui.rf_pushButton.setChecked(False)
        self.ui.modulation_pushButton.setChecked(False)
        self._set_measurement_state(running=False, paused=False)

    def toggle_rf(self):
        if self.rf_isON is False:
            self.rf_on()
        else:
            self.rf_off()

    def rf_on(self):
        if self.worker is not None:
            self.worker.rf_on()
        self.ui.rf_pushButton.setChecked(self.rf_isON)

    def rf_off(self):
        if self.worker is not None:
            self.worker.rf_off()
        self.ui.rf_pushButton.setChecked(self.rf_isON)

    def toggle_am(self):
        if self.am_isON is False:
            self.am_on()
        else:
            self.am_off()

    def am_on(self):
        if self.worker is not None:
            self.worker.am_on()
        self.ui.modulation_pushButton.setChecked(self.am_isON)

    def am_off(self):
        if self.worker is not None:
            self.worker.am_off()
        self.ui.modulation_pushButton.setChecked(self.am_isON)

    def start_pause_pushButton_clicked(self):
        if self.ui.start_pause_pushButton.text() == "Start Test":
            if self.table_is_unsaved:
                ret = QMessageBox.question(self, "Unsaved Table detected",
                                              "Do you want to save the table?", QMessageBox.StandardButton.No,
                                           QMessageBox.StandardButton.Yes)
                if ret == QMessageBox.StandardButton.Yes:
                    self.save_Table()

            self.clear_Table()
            self.ui.test_progressBar.setValue(0)
            self._start_measurement()
        elif self.ui.start_pause_pushButton.text() == "Pause Test":
            if self.worker is not None:
                paused = self.worker.toggle_pause()
                self.log("Pause Test" if paused else "Continue Test")
                self._set_measurement_state(running=True, paused=paused)
        else:
            if self.worker is not None:
                paused = self.worker.toggle_pause()
                self.log("Pause Test" if paused else "Continue Test")
                self._set_measurement_state(running=True, paused=paused)


    def node_names_table_cellChanged(self):
        names = {'sg': None, 'a1': None, 'a2': None, 'tem': None, 'fp': None}
        for row,key in enumerate(['sg', 'a1', 'a2', 'tem', 'fp']):
            names[key] = self.ui.node_names_tableWidget.item(row, 1).text()
        self.names = names

    def load_graph(self):
        fullfile, _ = QFileDialog.getOpenFileName(self,
                                                   "Open Graph File",
                                                   ".",
                                                   "dot files (*.dot)")
        dotpath, self.dotfile = os.path.split(fullfile)
        self.searchpath = str(['.', dotpath])
        self.ui.graph_file_lineEdit.setText(self.dotfile)
        self.ui.search_path_lineEdit.setText(str(self.searchpath))
        # print(self.dotfile, self.searchpath)


    def about_triggered(self):
        QMessageBox.about(self, "TEMField",
                          "Susceptibility measurements in (G)TEM-cell.\n\n(c) 2024: Prof. H. G. Krauthäuser")

    def cw_doubleSpinBox_changed(self):
        self.cw = self.ui.cw_doubleSpinBox.value()

    def am_spinBox_changed(self):
        self.am = self.ui.am_spinBox.value()

    def closeEvent(self, event):
        # fire confirmation box
        self.log("close event")
        ret = QMessageBox.question(self, "TEMField",
                                       "Do you want to exit the application?",
                                           QMessageBox.StandardButton.Yes, QMessageBox.StandardButton.No)
        if ret == QMessageBox.StandardButton.Yes:
            if self.table_is_unsaved:
                ret = QMessageBox.question(self, "Table is unsaved",
                                              "Do you want to save the table?", QMessageBox.StandardButton.No,
                                           QMessageBox.StandardButton.Yes)
                if ret == QMessageBox.StandardButton.Yes:
                    self.save_Table()
            self._save_setup()
            self._shutdown_measurement_thread()
            self.log("Exit Application")
            event.accept()
        else:
            self.log("Continue Application")
            event.ignore()

    def _shutdown_measurement_thread(self):
        if not self._measurement_is_running():
            return
        self.log("Stopping measurement thread...")
        if self.worker is not None:
            self.worker.stop()
        self.measurement_thread.quit()
        self.measurement_thread.wait(3000)

    def _read_setup(self):
        self.log("read setup")
        self.start_freq = float(self.settings.value("frequencies/start_freq", 30.))
        self.stop_freq = float(self.settings.value("frequencies/stop_freq", 1000.))
        self.step_freq = float(self.settings.value("frequencies/step_freq", 1.))
        self.log_sweep = (True if self.settings.value("frequencies/log_sweep", True) in (True, 'true', 'True') else False)
        self.cw = float(self.settings.value("fieldstrength/cw", 1.))
        self.am = float(self.settings.value("fieldstrength/am", 80.))
        self.dwell_time = float(self.settings.value("settings/dwell_time", 1.))
        self.dotfile = self.settings.value("settings/dotfile", os.path.abspath('./conf/gtem.dot'))
        self.searchpath = self.settings.value("settings/searchpath", str(['.', os.path.abspath('./conf')]))
        self.names = self.settings.value("settings/names", {'sg': 'sg', 'a1': 'amp1', 'a2': 'amp2',
                                                            'tem': 'gtem', 'fp': 'prb'})
        self.eut_description = self.settings.value("settings/eut-description", '')
        self.table_save_dir = self.settings.value("settings/table-save-dir", '.')
        self.table_save_dir = os.path.abspath(self.table_save_dir)
        self.adjust_to_setting = self.settings.value("settings/adjust_to_setting", 'auto')   # 'x', 'y', 'z', 'mag', 'largest', 'auto'
        # print("Init: ", self.log_sweep)
        # print(type(self.log_sweep), self.log_sweep)
        self.ui.log_sweep_checkBox.setChecked(self.log_sweep)
        self.ui.freq_start_doubleSpinBox.setValue(self.start_freq)
        self.ui.freq_stop_doubleSpinBox.setValue(self.stop_freq)
        self.ui.freq_step_doubleSpinBox.setValue(self.step_freq)
        self.ui.cw_doubleSpinBox.setValue(self.cw)
        self.ui.am_spinBox.setValue(self.am)
        self.ui.dwell_time_doubleSpinBox.setValue(self.dwell_time)
        self.ui.graph_file_lineEdit.setText(self.dotfile)
        self.ui.search_path_lineEdit.setText(str(self.searchpath))
        for row,key in enumerate(['sg', 'a1', 'a2', 'tem', 'fp']):
            self.ui.node_names_tableWidget.setItem(row, 1, QTableWidgetItem(self.names[key]))
        self.ui.EUT_plainTextEdit.setPlainText(self.eut_description)
        if self.adjust_to_setting == 'auto':
                self.ui.radioButton_Auto.setChecked(True)
        elif self.adjust_to_setting == 'x':
                self.ui.radioButton_Ex.setChecked(True)
        elif self.adjust_to_setting == 'y':
                self.ui.radioButton_Ey.setChecked(True)
        elif self.adjust_to_setting == 'z':
                self.ui.radioButton_Ez.setChecked(True)
        elif self.adjust_to_setting == 'mag':
                self.ui.radioButton_absE.setChecked(True)
        elif self.adjust_to_setting == 'largest':
                self.ui.radioButton_Largest_E.setChecked(True)



    def _save_setup(self):
        self.log("save setup")
        self.settings.setValue("frequencies/start_freq", self.start_freq)
        self.settings.setValue("frequencies/stop_freq", self.stop_freq)
        self.settings.setValue("frequencies/step_freq", self.step_freq)
        self.settings.setValue("frequencies/log_sweep", self.log_sweep)
        self.settings.setValue("fieldstrength/cw", self.cw)
        self.settings.setValue("fieldstrength/am", self.am)
        self.settings.setValue("settings/dwell_time", self.dwell_time)
        self.settings.setValue("settings/searchpath", self.searchpath)
        self.settings.setValue("settings/dotfile", self.dotfile)
        self.settings.setValue("settings/names", self.names)
        self.settings.setValue("settings/eut-description", self.eut_description)
        self.settings.setValue("settings/table-save-dir", self.table_save_dir)
        self.settings.setValue("settings/adjust_to_setting", self.adjust_to_setting)
        # print("Exit: ", self.log_sweep)
        self.settings.sync()

    def update(self):
        if self.disable_update:
            return
        # print("update")
        self.log_sweep = True if self.ui.log_sweep_checkBox.checkState() == Qt.CheckState.Checked else False
        # print("update", self.log_sweep)
        if not self.log_sweep:
            self.ui.freq_step_doubleSpinBox.setSuffix(' MHz')
            self.ui.freq_step_doubleSpinBox.setDecimals(4)
            self.ui.freq_step_doubleSpinBox.setRange(0, 99999.9999)
        else:
            self.ui.freq_step_doubleSpinBox.setSuffix('%')
            self.ui.freq_step_doubleSpinBox.setDecimals(2)
            self.ui.freq_step_doubleSpinBox.setRange(0, 99.99)

        self.start_freq = self.ui.freq_start_doubleSpinBox.value()
        self.stop_freq = self.ui.freq_stop_doubleSpinBox.value()
        self.step_freq = self.ui.freq_step_doubleSpinBox.value()
        if not self.log_sweep:
            self.freqs = linspace(self.start_freq, self.stop_freq, self.step_freq, endpoint=True)
        else:
            self.freqs = logspace(self.start_freq, self.stop_freq, 1+self.step_freq*0.01, endpoint=True)
        self.freqs = [f*1e6 for f in self.freqs]  # convert to Hz
        self.ui.nr_freqs_lineEdit.setText(str(len(self.freqs)))
        self.ui.freqs_plainTextEdit.setPlainText('\n'.join(map(str, self.freqs)))

        self.dwell_time = self.ui.dwell_time_doubleSpinBox.value()
        time_s = (self.dwell_time + 0.9) * len(self.freqs)  # 0.9 s offset per freq
        self.ui.est_time_lineEdit.setText(' '+str(datetime.timedelta(seconds=round(time_s,0)))+' (hh:mm:ss)')

    def get_time_as_string(self, format=None):
        if format is None:
            tstr = tstamp()   # default format from Mpy
        elif format == '':
            format = "%Y-%m-%dT%H:%M:%S.%f%z"
            tz = datetime.datetime.now(datetime.timezone.utc).astimezone().tzinfo
            tstr = datetime.datetime.now(tz=tz).strftime(format)
        return tstr

    def save_Table(self):
        path, _ = QFileDialog.getSaveFileName(self, caption='Save as CSV',
                                              dir=self.table_save_dir, filter='(*.csv)',
                                              options=QFileDialog.Option.DontUseNativeDialog)
        self.table_save_dir = os.path.dirname(path)
        if path:
            columns = range(self.ui.table_tableWidget.columnCount())
            header = [self.ui.table_tableWidget.horizontalHeaderItem(column).text()
                      for column in columns]
            with open(path, 'w') as csvfile:
                t = self.get_time_as_string(format='')
                csvfile.write(f"# File saved: {t}\n#\n")
                csvfile.write('# EUT Description\n')
                plaintext_EUT = self.eut_description
                for eut_line in plaintext_EUT.splitlines():
                    csvfile.write(f"# {eut_line}\n")

                writer = csv.writer(
                    csvfile, dialect='excel', lineterminator='\n')
                writer.writerow(header)
                for row in range(self.ui.table_tableWidget.rowCount()):
                    writer.writerow(
                        self.ui.table_tableWidget.item(row, column).text()
                        for column in columns)
                self.table_is_unsaved = False

def main():
    if not QApplication.instance():
        app = QApplication(sys.argv)
    else:
        app = QApplication.instance()
    app.setOrganizationName("TUD-TETEMV")
    app.setOrganizationDomain("tu-dresden.de/et/tet")
    app.setApplicationName("TEMField")
    settings = QSettings()

    QLocale.setDefault(QLocale.Language.English)

    widget = MainWindow(settings)
    widget.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
