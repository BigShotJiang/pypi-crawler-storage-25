"""Command line helpers for TEMField."""

import argparse
import json
import platform
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path

import temfield_mpylab


def _package_version(package_name):
    try:
        return version(package_name)
    except PackageNotFoundError:
        return "not installed"


def _info():
    package_path = Path(temfield_mpylab.__file__).resolve().parent
    project_root = package_path.parent.parent
    virtual_config = project_root / "test" / "conf-virtual" / "gtem-virtual.dot"

    return {
        "temfield_version": temfield_mpylab.__version__,
        "python_version": platform.python_version(),
        "package_path": str(package_path),
        "dependencies": {
            "matplotlib": _package_version("matplotlib"),
            "mpylab": _package_version("mpylab"),
            "numpy": _package_version("numpy"),
            "pyside6": _package_version("PySide6"),
            "scuq": _package_version("scuq"),
        },
        "entry_points": {
            "gui": "temfield",
            "info": "temfield-info",
        },
        "virtual_config": {
            "path": str(virtual_config),
            "exists": virtual_config.exists(),
        },
    }


def _print_text(info):
    print("TEMField information")
    print("====================")
    print(f"TEMField version : {info['temfield_version']}")
    print(f"Python           : {info['python_version']}")
    print(f"Package path     : {info['package_path']}")
    print()
    print("Dependencies")
    print("------------")
    for name, package_version in info["dependencies"].items():
        print(f"{name:10}: {package_version}")
    print()
    print("Entry points")
    print("------------")
    print(f"GUI  : {info['entry_points']['gui']}")
    print(f"Info : {info['entry_points']['info']}")
    print()
    print("Virtual test configuration")
    print("--------------------------")
    print(f"Path   : {info['virtual_config']['path']}")
    print(f"Exists : {info['virtual_config']['exists']}")


def info_main(argv=None):
    """Entry point for the ``temfield-info`` command."""
    parser = argparse.ArgumentParser(
        prog="temfield-info",
        description="Show TEMField installation and dependency information.",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="print machine-readable JSON instead of text",
    )
    args = parser.parse_args(argv)

    info = _info()
    if args.json:
        print(json.dumps(info, indent=2, sort_keys=True))
    else:
        _print_text(info)
    return 0


if __name__ == "__main__":
    raise SystemExit(info_main())
