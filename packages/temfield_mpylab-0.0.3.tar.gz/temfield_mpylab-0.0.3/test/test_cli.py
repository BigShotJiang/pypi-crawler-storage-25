import json

from temfield_mpylab.cli import info_main


def test_info_main_prints_installation_summary(capsys):
    assert info_main([]) == 0

    output = capsys.readouterr().out

    assert "TEMField information" in output
    assert "TEMField version" in output
    assert "Dependencies" in output
    assert "Entry points" in output
    assert "temfield" in output


def test_info_main_can_print_json(capsys):
    assert info_main(["--json"]) == 0

    info = json.loads(capsys.readouterr().out)

    assert info["temfield_version"]
    assert info["python_version"]
    assert info["package_path"]
    assert info["entry_points"]["gui"] == "temfield"
    assert info["entry_points"]["info"] == "temfield-info"
    assert isinstance(info["virtual_config"]["exists"], bool)
