"""Check that the chap-core 'Modeling' app is installed on DHIS2."""

from __future__ import annotations

import time
from typing import Any, ClassVar

from dhis2w_client import Dhis2Client
from pydantic import BaseModel, ConfigDict, Field

from chap_checker.checks.base import CheckResult, Status, format_request_error, register_check

MODELING_APP_HUB_ID = "a29851f9-82a7-4ecd-8b2c-58e0f220bc75"
APPS_PATH = "/api/apps"


class Dhis2App(BaseModel):
    """Minimal projection of one entry in ``/api/apps``."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    key: str | None = None
    name: str | None = None
    version: str | None = None
    # DHIS2 returns snake_case `app_hub_id` on some versions and camelCase
    # `appHubId` on others. Accept both via the alias + populate_by_name.
    app_hub_id: str | None = Field(default=None, alias="appHubId")
    app_type: str | None = Field(default=None, alias="appType")
    launch_url: str | None = Field(default=None, alias="launchUrl")


@register_check
class Dhis2ChapModelingAppCheck:
    """Look for an installed DHIS2 app whose App Hub UUID matches the modeling app."""

    name: ClassVar[str] = "dhis2_chap_modeling_app"
    description: ClassVar[str] = "DHIS2 app with app_hub_id of the modeling app is installed and reports a version."
    order: ClassVar[int] = 60
    # Depends on the chap route, not just dhis2_ping: on a plain DHIS2 instance
    # without chap-core integration the modeling app is never installed, so
    # skipping is more honest than reporting FAIL on every poll. The route's
    # own prereq chain still pulls in dhis2_ping transitively.
    requires: ClassVar[list[str]] = ["dhis2_chap_route"]

    async def run(self, client: Dhis2Client) -> CheckResult:
        start = time.perf_counter()
        try:
            response = await client.get_response(APPS_PATH)
        except Exception as exc:  # noqa: BLE001
            return CheckResult(
                name=self.name,
                status=Status.ERROR,
                message=format_request_error(exc, path=APPS_PATH),
                duration_ms=(time.perf_counter() - start) * 1000,
            )

        duration_ms = (time.perf_counter() - start) * 1000
        if response.status_code >= 400:
            return CheckResult(
                name=self.name,
                status=Status.FAIL,
                message=f"Could not list apps (status {response.status_code}).",
                duration_ms=duration_ms,
            )

        try:
            body = response.json()
        except ValueError:
            return CheckResult(
                name=self.name,
                status=Status.FAIL,
                message="DHIS2 returned malformed JSON when listing apps.",
                duration_ms=duration_ms,
            )
        if isinstance(body, list):
            entries = body
        elif isinstance(body, dict):
            entries = body.get("apps", [])
        else:
            return CheckResult(
                name=self.name,
                status=Status.FAIL,
                message="Unexpected /api/apps response shape (expected a list or object).",
                duration_ms=duration_ms,
            )
        if not all(isinstance(e, dict) for e in entries):
            return CheckResult(
                name=self.name,
                status=Status.FAIL,
                message="Unexpected /api/apps entry shape (entries must be objects).",
                duration_ms=duration_ms,
            )
        apps = [Dhis2App.model_validate(entry) for entry in entries]
        match = next((a for a in apps if a.app_hub_id == MODELING_APP_HUB_ID), None)
        if match is None:
            return CheckResult(
                name=self.name,
                status=Status.FAIL,
                message=f"No app with app_hub_id '{MODELING_APP_HUB_ID}' installed.",
                details={"app_count": len(apps)},
                duration_ms=duration_ms,
            )
        label = match.name or match.key or "modeling-app"
        if not match.version:
            return CheckResult(
                name=self.name,
                status=Status.WARN,
                message=f"{label} installed but no 'version' field.",
                details=_dump(match),
                duration_ms=duration_ms,
            )
        return CheckResult(
            name=self.name,
            status=Status.OK,
            message=f"{label} {match.version}.",
            details=_dump(match),
            duration_ms=duration_ms,
        )


def _dump(app: Dhis2App) -> dict[str, Any]:
    return app.model_dump(exclude_none=True, by_alias=True)
