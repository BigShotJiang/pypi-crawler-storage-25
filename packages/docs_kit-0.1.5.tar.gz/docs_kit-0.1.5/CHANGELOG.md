# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/), and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.5] - 2026-03-28

### Added

- `docs-kit query --full` to print full chunk text; default preview truncation increased to 1500 characters (from 300).
- Markdown chunking that keeps tables and fenced code blocks intact when possible: large tables split on row boundaries with header repeated; large code blocks split on lines with opening/closing fences preserved in each part.
- Tests covering table/code chunking, list-heavy sections, and headers inside fences.

### Changed

- `docs-kit install codex` (and `codex-app` / `codex-desktop`) writes the skill to `~/.codex/skills/docs-kit/SKILL.md` and mirrors the same content to `~/.agents/skills/docs-kit/SKILL.md` for compatibility with shared agent layouts.
- `docs-kit doctor` lists installed skills with install-target labels (`claude-code`, `cursor`, `codex`, `codex-shared`, `opencode`, `claude-desktop`) and suggests the matching `docs-kit install <target>` command when missing.

### Fixed

- Chunking no longer merges or normalizes markdown tables and code fences in ways that broke pipe layout or list structure.

## [0.1.4] - 2026-03-28

### Changed (breaking)

- Removed the MCP server and MCP dependencies; agents use installed skill files that invoke the `docs-kit` CLI directly (`query`, `list`, `ingest`, `remove`, `inspect`, `doctor`, etc.).
- CLI: added `list` and `remove`; removed `serve` and `stop`.
- `docs-kit install` writes skills for Claude Code, Cursor, Codex, OpenCode, Claude Desktop, and related targets under `docs_kit/templates/`.
- `doctor` checks PATH, config, Qdrant, and installed skill paths.
- Local Qdrant access is serialized with `filelock` for concurrent CLI use.
- Python support remains `>=3.11,<3.14`.

## [0.1.3] - 2026-03-28

### Added

- `docs-kit serve` as a background daemon (PID + logs) and `docs-kit stop`.
- Default MCP transport: SSE on `localhost:45139` to reduce Qdrant lock contention.
- Install flows write URL entries pointing at `/sse` for Claude, Cursor, and Codex.
- `doctor` checks MCP process and port reachability.

### Changed

- Project install without a local `docs-kit.yaml` uses in-memory defaults (no user bootstrap in that path).

### Fixed

- Serve daemon test log path mock (`MagicMock` parent breaking `mkdir`).

## [0.1.2] - 2026-03-27

### Added

- Bootstrap `~/.docs-kit/docs-kit.yaml` and default Qdrant path when running a global `install` with no project config.
- `DocsKitConfig.from_yaml` loading from the user config after `./docs-kit.yaml`.

### Changed

- Documented pipx-first install, config precedence, and Python 3.11–3.13 cap; `requires-python` set to `<3.14` (onnxruntime wheels).

## [0.1.1] - 2026-03-27

### Added

- Mintlify fetcher (`llms-full.txt`, `llms.txt`, sitemap fallback) and shared `llms_txt` helpers.
- `docs-kit ingest --provider auto|gitbook|mintlify`.
- Formatted CLI help and banner (`DocsKitGroup` / `DocsKitCommand`, examples in epilogs).

### Changed

- GitBook fetcher refactor; HTML stripped before chunking via `html_utils`.
- `install` resolves absolute `docs-kit` command and config paths; warns if YAML is missing.

### Chore

- Ignore local `docs/` and add release helper script to `.gitignore`.

## [0.1.0] - 2026-03-27

### Added

- `DocsKitAgent` API: `ingest()`, `query()`.
- CLI: `docs-kit init`, `fetch`, `ingest`, `serve`, `install`, `query`, `inspect`, `doctor`.
- GitBook fetch via `/llms-full.txt` / `/llms.txt` and linked pages.
- Local embeddings with FastEmbed (dense + sparse/BM25).
- Vector store: Qdrant (local path or remote URL).
- Document parsers for `.txt` and `.md`.
- `DocsKitConfig` with YAML and environment variable support.
- MCP server tools: `search_docs`, `list_sources`, `get_collection_info`, `get_full_document`.
- Annotated `docs-kit.yaml` example, npx wrapper, sample data, CI and publish workflows.
