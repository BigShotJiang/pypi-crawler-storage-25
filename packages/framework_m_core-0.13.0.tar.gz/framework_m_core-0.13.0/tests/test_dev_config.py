"""Tests for Development Configuration Utilities.

Tests for Procfile parser, m.toml [dev] section loader, and configuration merging.
"""

from __future__ import annotations

import sys
from pathlib import Path
from textwrap import dedent

from framework_m_core.dev_config import (
    get_default_processes,
    load_dev_config_from_toml,
    load_procfile,
    merge_process_configs,
)


class TestLoadProcfile:
    """Tests for Procfile parsing."""

    def test_load_procfile_returns_dict(self, tmp_path: Path) -> None:
        """load_procfile should return a dictionary."""
        procfile = tmp_path / "Procfile"
        procfile.write_text("backend: uvicorn app:app\n")

        result = load_procfile(procfile)
        assert isinstance(result, dict)

    def test_load_procfile_parses_simple_format(self, tmp_path: Path) -> None:
        """load_procfile should parse 'name: command' format."""
        procfile = tmp_path / "Procfile"
        procfile.write_text("backend: uvicorn app:app --reload\n")

        result = load_procfile(procfile)
        assert result["backend"] == "uvicorn app:app --reload"

    def test_load_procfile_parses_multiple_processes(self, tmp_path: Path) -> None:
        """load_procfile should parse multiple processes."""
        content = dedent(
            """
            backend: uvicorn app:app --reload
            frontend: cd frontend && pnpm dev
            worker: m worker --concurrency 4
        """
        ).strip()

        procfile = tmp_path / "Procfile"
        procfile.write_text(content)

        result = load_procfile(procfile)
        assert len(result) == 3
        assert result["backend"] == "uvicorn app:app --reload"
        assert result["frontend"] == "cd frontend && pnpm dev"
        assert result["worker"] == "m worker --concurrency 4"

    def test_load_procfile_skips_comments(self, tmp_path: Path) -> None:
        """load_procfile should skip comment lines."""
        content = dedent(
            """
            # This is a comment
            backend: uvicorn app:app
            # Another comment
            frontend: pnpm dev
        """
        ).strip()

        procfile = tmp_path / "Procfile"
        procfile.write_text(content)

        result = load_procfile(procfile)
        assert len(result) == 2

    def test_load_procfile_skips_empty_lines(self, tmp_path: Path) -> None:
        """load_procfile should skip empty lines."""
        content = dedent(
            """
            backend: uvicorn app:app

            frontend: pnpm dev

        """
        ).strip()

        procfile = tmp_path / "Procfile"
        procfile.write_text(content)

        result = load_procfile(procfile)
        assert len(result) == 2

    def test_load_procfile_handles_colons_in_command(self, tmp_path: Path) -> None:
        """load_procfile should handle colons in commands."""
        procfile = tmp_path / "Procfile"
        procfile.write_text("backend: uvicorn app:create_app --host 0.0.0.0:8888\n")

        result = load_procfile(procfile)
        assert result["backend"] == "uvicorn app:create_app --host 0.0.0.0:8888"

    def test_load_procfile_handles_hyphens_in_name(self, tmp_path: Path) -> None:
        """load_procfile should handle hyphens in process names."""
        procfile = tmp_path / "Procfile"
        procfile.write_text("my-worker: m worker\n")

        result = load_procfile(procfile)
        assert result["my-worker"] == "m worker"

    def test_load_procfile_returns_empty_if_not_exists(self, tmp_path: Path) -> None:
        """load_procfile should return empty dict if file doesn't exist."""
        procfile = tmp_path / "nonexistent.procfile"

        result = load_procfile(procfile)
        assert result == {}


class TestLoadDevConfigFromToml:
    """Tests for m.toml [dev] section parsing."""

    def test_load_dev_config_returns_dict(self, tmp_path: Path) -> None:
        """load_dev_config_from_toml should return a dictionary."""
        config_file = tmp_path / "m.toml"
        config_file.write_text("[dev]\nbackend_port = 8888\n")

        result = load_dev_config_from_toml(config_file)
        assert isinstance(result, dict)

    def test_load_dev_config_parses_ports(self, tmp_path: Path) -> None:
        """load_dev_config_from_toml should parse port settings."""
        content = dedent(
            """
            [dev]
            backend_port = 9000
            frontend_port = 3000
        """
        ).strip()

        config_file = tmp_path / "m.toml"
        config_file.write_text(content)

        result = load_dev_config_from_toml(config_file)
        assert result["backend_port"] == 9000
        assert result["frontend_port"] == 3000

    def test_load_dev_config_parses_enable_flags(self, tmp_path: Path) -> None:
        """load_dev_config_from_toml should parse enable flags."""
        content = dedent(
            """
            [dev]
            enable_worker = true
            enable_scheduler = false
        """
        ).strip()

        config_file = tmp_path / "m.toml"
        config_file.write_text(content)

        result = load_dev_config_from_toml(config_file)
        assert result["enable_worker"] is True
        assert result["enable_scheduler"] is False

    def test_load_dev_config_parses_command_overrides(self, tmp_path: Path) -> None:
        """load_dev_config_from_toml should parse command overrides."""
        content = dedent(
            """
            [dev]
            backend_command = "uvicorn app:app --reload --log-level debug"
            frontend_command = "pnpm dev --host 0.0.0.0"
        """
        ).strip()

        config_file = tmp_path / "m.toml"
        config_file.write_text(content)

        result = load_dev_config_from_toml(config_file)
        assert result["backend_command"] == "uvicorn app:app --reload --log-level debug"
        assert result["frontend_command"] == "pnpm dev --host 0.0.0.0"

    def test_load_dev_config_parses_procfile_path(self, tmp_path: Path) -> None:
        """load_dev_config_from_toml should parse procfile path."""
        content = dedent(
            """
            [dev]
            procfile = "Procfile.dev"
        """
        ).strip()

        config_file = tmp_path / "m.toml"
        config_file.write_text(content)

        result = load_dev_config_from_toml(config_file)
        assert result["procfile"] == "Procfile.dev"

    def test_load_dev_config_parses_custom_processes(self, tmp_path: Path) -> None:
        """load_dev_config_from_toml should parse custom processes."""
        content = dedent(
            """
            [dev]

            [dev.processes.mailhog]
            command = "mailhog -smtp-bind-addr 127.0.0.1:1025"
            enabled = true

            [dev.processes.redis]
            command = "redis-server --port 6379"
            enabled = false
            cwd = "/opt/redis"

            [dev.processes.custom]
            command = "python scripts/watch.py"
            cwd = "."

            [dev.processes.custom.env]
            PYTHONPATH = "src"
            DEBUG = "true"
        """
        ).strip()

        config_file = tmp_path / "m.toml"
        config_file.write_text(content)

        result = load_dev_config_from_toml(config_file)
        assert "processes" in result

        processes = result["processes"]
        assert "mailhog" in processes
        assert (
            processes["mailhog"]["command"] == "mailhog -smtp-bind-addr 127.0.0.1:1025"
        )
        assert processes["mailhog"]["enabled"] is True

        assert "redis" in processes
        assert processes["redis"]["enabled"] is False
        assert processes["redis"]["cwd"] == "/opt/redis"

        assert "custom" in processes
        assert "env" in processes["custom"]
        assert processes["custom"]["env"]["PYTHONPATH"] == "src"

    def test_load_dev_config_returns_empty_if_no_dev_section(
        self, tmp_path: Path
    ) -> None:
        """load_dev_config_from_toml should return empty if no [dev] section."""
        content = dedent(
            """
            [database]
            url = "postgresql://localhost/db"
        """
        ).strip()

        config_file = tmp_path / "m.toml"
        config_file.write_text(content)

        result = load_dev_config_from_toml(config_file)
        assert result == {}

    def test_load_dev_config_returns_empty_if_not_exists(self, tmp_path: Path) -> None:
        """load_dev_config_from_toml should return empty if file doesn't exist."""
        config_file = tmp_path / "nonexistent.toml"

        result = load_dev_config_from_toml(config_file)
        assert result == {}


class TestGetDefaultProcesses:
    """Tests for default process generation."""

    def test_get_default_processes_includes_backend(self, tmp_path: Path) -> None:
        """get_default_processes should include backend process."""
        result = get_default_processes(
            app="app:app",
            host="127.0.0.1",
            port=8888,
            frontend_dir=tmp_path / "frontend",
            frontend_port=5173,
        )

        assert "backend" in result
        assert "uvicorn" in result["backend"]
        assert "app:app" in result["backend"]
        assert "8888" in result["backend"]

    def test_get_default_processes_includes_frontend_if_exists(
        self, tmp_path: Path
    ) -> None:
        """get_default_processes should include frontend if directory exists."""
        frontend_dir = tmp_path / "frontend"
        frontend_dir.mkdir()
        (frontend_dir / "package.json").write_text("{}")

        result = get_default_processes(
            app="app:app",
            host="127.0.0.1",
            port=8888,
            frontend_dir=frontend_dir,
            frontend_port=5173,
        )

        assert "frontend" in result
        assert "pnpm dev" in result["frontend"]
        assert "5173" in result["frontend"]

    def test_get_default_processes_skips_frontend_if_no_frontend_flag(
        self, tmp_path: Path
    ) -> None:
        """get_default_processes should skip frontend if no_frontend=True."""
        frontend_dir = tmp_path / "frontend"
        frontend_dir.mkdir()
        (frontend_dir / "package.json").write_text("{}")

        result = get_default_processes(
            app="app:app",
            host="127.0.0.1",
            port=8888,
            frontend_dir=frontend_dir,
            frontend_port=5173,
            no_frontend=True,
        )

        assert "frontend" not in result

    def test_get_default_processes_uses_python_executable(self, tmp_path: Path) -> None:
        """get_default_processes should use sys.executable."""
        result = get_default_processes(
            app="app:app",
            host="127.0.0.1",
            port=8888,
            frontend_dir=tmp_path / "frontend",
            frontend_port=5173,
        )

        assert sys.executable in result["backend"]


class TestMergeProcessConfigs:
    """Tests for configuration merging."""

    def test_merge_process_configs_uses_defaults(self) -> None:
        """merge_process_configs should use defaults when no overrides."""
        defaults = {"backend": "uvicorn app:app"}
        procfile = {}
        toml_config = {}

        result = merge_process_configs(defaults, procfile, toml_config)
        assert result == defaults

    def test_merge_process_configs_overrides_with_toml_commands(self) -> None:
        """merge_process_configs should override with m.toml commands."""
        defaults = {"backend": "uvicorn app:app"}
        procfile = {}
        toml_config = {"backend_command": "uvicorn app:app --log-level debug"}

        result = merge_process_configs(defaults, procfile, toml_config)
        assert result["backend"] == "uvicorn app:app --log-level debug"

    def test_merge_process_configs_adds_toml_custom_processes(self) -> None:
        """merge_process_configs should add custom processes from m.toml."""
        defaults = {"backend": "uvicorn app:app"}
        procfile = {}
        toml_config = {
            "processes": {
                "redis": {"command": "redis-server", "enabled": True},
                "mailhog": {"command": "mailhog", "enabled": False},
            }
        }

        result = merge_process_configs(defaults, procfile, toml_config)
        assert "redis" in result
        assert result["redis"] == "redis-server"
        assert "mailhog" not in result  # disabled

    def test_merge_process_configs_prepends_cwd(self) -> None:
        """merge_process_configs should prepend cwd to command if specified."""
        defaults = {"backend": "uvicorn app:app"}
        procfile = {}
        toml_config = {
            "processes": {
                "worker": {"command": "m worker", "cwd": "/opt/app", "enabled": True}
            }
        }

        result = merge_process_configs(defaults, procfile, toml_config)
        assert result["worker"] == "cd /opt/app && m worker"

    def test_merge_process_configs_procfile_has_highest_precedence(self) -> None:
        """merge_process_configs should prioritize Procfile over everything."""
        defaults = {"backend": "uvicorn app:app"}
        procfile = {"backend": "uvicorn custom:custom_app"}
        toml_config = {"backend_command": "uvicorn toml:toml_app"}

        result = merge_process_configs(defaults, procfile, toml_config)
        assert result["backend"] == "uvicorn custom:custom_app"

    def test_merge_process_configs_full_precedence_chain(self) -> None:
        """merge_process_configs should apply full precedence chain correctly."""
        defaults = {
            "backend": "uvicorn app:app",
            "frontend": "pnpm dev",
        }

        procfile = {
            "backend": "uvicorn procfile:app",  # Overrides everything
        }

        toml_config = {
            "frontend_command": "pnpm dev --host 0.0.0.0",  # Overrides frontend
            "processes": {
                "worker": {"command": "m worker", "enabled": True},  # Adds worker
            },
        }

        result = merge_process_configs(defaults, procfile, toml_config)

        # Procfile wins for backend
        assert result["backend"] == "uvicorn procfile:app"

        # TOML overrides default frontend
        assert result["frontend"] == "pnpm dev --host 0.0.0.0"

        # TOML adds worker
        assert result["worker"] == "m worker"


__all__ = [
    "TestLoadProcfile",
    "TestLoadDevConfigFromToml",
    "TestGetDefaultProcesses",
    "TestMergeProcessConfigs",
]
