"""Tests for MetaRegistry discovery mechanisms."""

from typing import Any
from unittest.mock import MagicMock, patch

import pytest
from framework_m_core.registry import MetaRegistry


@pytest.fixture
def registry():
    """Clear registry before each test."""
    reg = MetaRegistry.get_instance()
    reg.clear()
    return reg


class TestRegistryDiscovery:
    """Tests for MetaRegistry.load_installed_apps and related methods."""

    def test_load_installed_apps_calls_discoveries(self, registry):
        """load_installed_apps should call core discovery and entry points."""
        with (
            patch.object(
                registry, "discover_doctypes", return_value=1
            ) as mock_discover,
            patch("importlib.metadata.entry_points") as mock_eps,
        ):
            # Mock entry points
            mock_ep = MagicMock()
            mock_ep.name = "test_app"
            mock_ep.module = "test_app:app"
            mock_ep.load.return_value = {}
            mock_eps.return_value = [mock_ep]

            count = registry.load_installed_apps()

            assert count > 0
            # Should discover core + test_app
            assert mock_discover.called
            assert any(
                "framework_m_core.doctypes" in str(args)
                for args, _ in mock_discover.call_args_list
            )

    @patch("importlib.metadata.entry_points")
    def test_load_installed_apps_handles_failure(self, mock_eps, registry):
        """load_installed_apps should not fail if an app fails to load."""
        mock_ep = MagicMock()
        mock_ep.name = "broken_app"
        mock_ep.load.side_effect = Exception("Import error")
        mock_eps.return_value = [mock_ep]

        # Should not raise exception
        count = registry.load_installed_apps()
        assert isinstance(count, int)

    def test_discover_local_project_doctypes(self, registry, tmp_path):
        """discover_local_project_doctypes should find doctypes in CWD."""
        with patch("pathlib.Path.cwd", return_value=tmp_path):
            # Create a dummy pyproject.toml
            (tmp_path / "pyproject.toml").write_text(
                '[project]\nname = "my_local_app"', encoding="utf-8"
            )
            (tmp_path / "my_local_app").mkdir()
            (tmp_path / "my_local_app" / "doctypes").mkdir()

            with patch.object(
                registry, "discover_doctypes", return_value=5
            ) as mock_discover:
                count = registry.discover_local_project_doctypes()

                assert count == 5
                mock_discover.assert_any_call("my_local_app.doctypes")

    def test_parse_local_project_package_name(self, registry, tmp_path):
        """_parse_local_project_package_name should extract package name from pyproject.toml."""
        (tmp_path / "pyproject.toml").write_text(
            '[project]\nname = "test-framework-m"', encoding="utf-8"
        )

        name = registry._parse_local_project_package_name(tmp_path)
        assert name == "test_framework_m"

    def test_parse_local_project_package_name_invalid(self, registry, tmp_path):
        """_parse_local_project_package_name should return None for invalid pyproject.toml."""
        (tmp_path / "pyproject.toml").write_text("not toml", encoding="utf-8")
        assert registry._parse_local_project_package_name(tmp_path) is None

    def test_collect_local_doctype_candidates(self, registry, tmp_path):
        """_collect_local_doctype_candidates should find candidates in src/ and root."""
        (tmp_path / "pyproject.toml").write_text(
            '[project]\nname = "app"', encoding="utf-8"
        )

        # Scenario: App with src layout
        src = tmp_path / "src"
        src.mkdir()

        pkg1 = src / "pkg1"
        pkg1.mkdir()
        (pkg1 / "__init__.py").touch()
        (pkg1 / "doctypes").mkdir()

        candidates = registry._collect_local_doctype_candidates(tmp_path)

        assert "app.doctypes" in candidates
        assert "pkg1.doctypes" in candidates

    def test_unique_preserve_order(self, registry):
        """_unique_preserve_order should keep first occurrence and maintain order."""
        items = ["a", "b", "a", "c", "b"]
        result = registry._unique_preserve_order(items)
        assert result == ["a", "b", "c"]

    def test_load_apps_fallback(self, registry):
        """load_apps should fallback to flat structure if .doctypes is empty."""
        with patch.object(registry, "discover_doctypes") as mock_discover:
            # Return 0 for namespaced, 5 for flat
            mock_discover.side_effect = [0, 5]

            count = registry.load_apps(["my_app"])

            assert count == 5
            mock_discover.assert_any_call("my_app.doctypes")
            mock_discover.assert_any_call("my_app")

    def test_load_installed_apps_core_only(self, registry):
        """load_installed_apps should work when no entry points exist."""
        with (
            patch.object(
                registry, "discover_doctypes", return_value=3
            ) as mock_discover,
            patch("importlib.metadata.entry_points", return_value=[]),
        ):
            count = registry.load_installed_apps()

            assert count == 3
            mock_discover.assert_called_with("framework_m_core.doctypes")

    def test_discover_doctypes_import_error_root(self, registry) -> None:
        """Should return 0 when the root package cannot be imported."""
        assert registry.discover_doctypes("nonexistent_package_12345") == 0

    def test_discover_doctypes_import_error_submodule(self, registry) -> None:
        """Should catch ImportError when walking submodules and continue."""
        with patch(
            "pkgutil.walk_packages", return_value=[(None, "fake.submodule", False)]
        ):

            def mock_import(name: str, *args: Any, **kwargs: Any) -> Any:
                if name == "fake":
                    dummy = MagicMock()
                    dummy.__path__ = ["/fake/path"]
                    return dummy
                if name == "fake.submodule":
                    raise ImportError("Cannot import submodule")
                return MagicMock()

            with patch("importlib.import_module", side_effect=mock_import):
                # Should not raise exception
                assert registry.discover_doctypes("fake") == 0

    def test_parse_local_project_package_name_no_file(self, registry) -> None:
        """Should return None if pyproject.toml does not exist."""
        cwd = MagicMock()
        cwd.__truediv__.return_value.exists.return_value = False
        assert registry._parse_local_project_package_name(cwd) is None

    def test_parse_local_project_package_name_no_tomllib(self, registry) -> None:
        """Should return None if tomllib is missing."""
        cwd = MagicMock()
        pyproject = MagicMock()
        pyproject.exists.return_value = True
        cwd.__truediv__.return_value = pyproject

        with patch.dict("sys.modules", {"tomllib": None}):
            assert registry._parse_local_project_package_name(cwd) is None

    def test_collect_local_doctype_candidates_no_src(self, registry) -> None:
        """Should return early if src directory does not exist."""
        cwd = MagicMock()
        src_dir = MagicMock()
        src_dir.exists.return_value = False

        def truediv_side_effect(key: str) -> MagicMock:
            if key == "pyproject.toml":
                return MagicMock(exists=MagicMock(return_value=False))
            if key == "src":
                return src_dir
            return MagicMock()

        cwd.__truediv__.side_effect = truediv_side_effect

        assert registry._collect_local_doctype_candidates(cwd) == []
