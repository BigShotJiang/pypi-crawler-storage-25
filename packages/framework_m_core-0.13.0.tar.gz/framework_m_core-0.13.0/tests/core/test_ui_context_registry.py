"""Tests for UI context and aggregate root registries."""

from __future__ import annotations

from framework_m_core.registry import AggregateRootRegistry, UIContextRegistry


class TestUIContextRegistry:
    """Context-aware UI metadata registry behavior."""

    def setup_method(self) -> None:
        UIContextRegistry.get_instance().clear()

    def test_register_and_resolve_context_override(self) -> None:
        registry = UIContextRegistry.get_instance()
        registry.register_context_override(
            "Invoice",
            "POS",
            {
                "form": {
                    "sections": [
                        {"label": "POS", "fields": ["customer", "total"]},
                    ]
                }
            },
        )

        resolved = registry.resolve_ui_meta(
            "Invoice",
            base_ui_meta={
                "doctype": "Invoice",
                "form": {
                    "sections": [
                        {"label": "Default", "fields": ["customer"]},
                    ]
                },
            },
            context="pos",
        )

        assert resolved["doctype"] == "Invoice"
        assert resolved["form"]["sections"][0]["label"] == "POS"

    def test_resolve_without_context_returns_base(self) -> None:
        registry = UIContextRegistry.get_instance()

        base = {"doctype": "Invoice", "list": {"columns": [{"field": "name"}]}}
        resolved = registry.resolve_ui_meta("Invoice", base_ui_meta=base)

        assert resolved == base

    def test_unknown_context_falls_back_to_base(self) -> None:
        registry = UIContextRegistry.get_instance()

        base = {"doctype": "Invoice", "form": {"sections": [{"label": "A"}]}}
        resolved = registry.resolve_ui_meta(
            "Invoice", base_ui_meta=base, context="mobile"
        )

        assert resolved["form"]["sections"][0]["label"] == "A"


class TestAggregateRootRegistry:
    """Aggregate root metadata registry behavior."""

    def setup_method(self) -> None:
        AggregateRootRegistry.get_instance().clear()

    def test_register_and_get_aggregate_root_config(self) -> None:
        registry = AggregateRootRegistry.get_instance()
        config = {
            "rootField": "name",
            "children": [
                {
                    "resource": "InvoiceItem",
                    "linkField": "parent_invoice",
                }
            ],
        }

        registry.register("Invoice", config)
        resolved = registry.get("Invoice")

        assert resolved is not None
        assert resolved["children"][0]["resource"] == "InvoiceItem"

    def test_get_unknown_aggregate_root_returns_none(self) -> None:
        registry = AggregateRootRegistry.get_instance()

        assert registry.get("Unknown") is None
