"""Meta Registry - Central registry for DocTypes and Controllers.

This module provides the MetaRegistry singleton that tracks all registered
DocTypes and their associated controllers. It supports automatic discovery
of DocTypes from packages and enforces globally unique DocType names.
"""

from __future__ import annotations

import copy
import importlib
import inspect
import pkgutil
from typing import TYPE_CHECKING, Any, cast

from framework_m_core.exceptions import DuplicateDocTypeError

if TYPE_CHECKING:
    from framework_m_core.domain.base_controller import BaseController
    from framework_m_core.domain.base_doctype import BaseDocType


class MetaRegistry:
    """
    Singleton registry for DocTypes and Controllers.

    The MetaRegistry is the central store for all DocType metadata.
    It maps DocType names to their classes and optional controllers.

    DocType Uniqueness:
        Framework M enforces globally unique DocType names across all
        installed apps. Attempting to register a duplicate name will
        raise DuplicateDocTypeError.

    Example:
        registry = MetaRegistry()

        # Register a DocType
        registry.register_doctype(Todo, TodoController)

        # Get DocType class
        TodoClass = registry.get_doctype("Todo")

        # Get controller
        ControllerClass = registry.get_controller("Todo")

        # Load DocTypes from installed apps in order
        registry.load_apps(["app1", "app2", "app3"])
    """

    _instance: MetaRegistry | None = None
    _initialized: bool = False

    # Instance attributes - declared here for mypy
    _doctypes: dict[str, type[BaseDocType]]
    _controllers: dict[str, type[BaseController[Any]]]
    _doctype_sources: dict[str, str]  # Maps doctype name to source module
    _overrides: dict[str, type[BaseDocType]]  # Maps doctype name to override class
    _whitelisted_meta_keys: set[str]  # Whitelisted keys for metadata discovery

    def __new__(cls) -> MetaRegistry:
        """Ensure only one instance exists (singleton pattern)."""
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self) -> None:
        """Initialize the registry (only once)."""
        if not MetaRegistry._initialized:
            self._doctypes = {}
            self._controllers = {}
            self._doctype_sources = {}
            self._overrides = {}
            self._whitelisted_meta_keys = {
                "show_in_desk",
                "api_resource",
                "is_child_table",
                "is_submittable",
                "label",
                "module",
                "ui_meta",
            }
            MetaRegistry._initialized = True

    @classmethod
    def get_instance(cls) -> MetaRegistry:
        """Get the singleton instance."""
        return cls()

    def register_doctype(
        self,
        doctype_class: type[BaseDocType],
        controller_class: type[BaseController[Any]] | None = None,
    ) -> None:
        """
        Register a DocType with optional controller.

        Args:
            doctype_class: The DocType class to register
            controller_class: Optional controller class for this DocType

        Raises:
            DuplicateDocTypeError: If a DocType with the same name is already
                registered. Framework M requires globally unique DocType names.
        """
        name = doctype_class.get_doctype_name()
        new_module = doctype_class.__module__

        # Check for duplicate registration
        if name in self._doctypes:
            existing_module = self._doctype_sources.get(name)
            raise DuplicateDocTypeError(
                doctype_name=name,
                existing_module=existing_module,
                new_module=new_module,
            )

        self._doctypes[name] = doctype_class
        self._doctype_sources[name] = new_module
        if controller_class is not None:
            self._controllers[name] = controller_class

    def get_doctype(self, name: str) -> type[BaseDocType]:
        """
        Get a registered DocType class by name.

        If an override is registered for this DocType, returns the override
        class instead of the base class.

        Args:
            name: The DocType name

        Returns:
            The DocType class (or override if registered)

        Raises:
            KeyError: If DocType is not registered
        """
        if name not in self._doctypes:
            raise KeyError(f"DocType '{name}' not registered")

        # Return override if registered, otherwise return base
        if name in self._overrides:
            return self._overrides[name]

        return self._doctypes[name]

    def get_controller(self, name: str) -> type[BaseController[Any]] | None:
        """
        Get a registered controller class by DocType name.

        Args:
            name: The DocType name

        Returns:
            The controller class, or None if not registered
        """
        return self._controllers.get(name)

    def list_doctypes(self) -> list[str]:
        """
        List all registered DocType names.

        Returns:
            List of DocType names
        """
        return list(self._doctypes.keys())

    def register_override(
        self,
        base_doctype: str,
        override_class: type[BaseDocType],
    ) -> None:
        """
        Register an override for a DocType.

        The override class must inherit from the base DocType. When get_doctype()
        is called for the base DocType, the override class will be returned instead.

        Only one override per base DocType is allowed. This enforces a clear
        override hierarchy and prevents ambiguity.

        Args:
            base_doctype: Name of the base DocType to override
            override_class: The override class (must inherit from base)

        Raises:
            KeyError: If base DocType is not registered
            ValueError: If override doesn't inherit from base or if an override
                already exists for this base DocType
        """
        # Check that base DocType is registered
        if base_doctype not in self._doctypes:
            raise KeyError(f"Base DocType '{base_doctype}' not registered")

        base_class = self._doctypes[base_doctype]

        # Validate that override inherits from base
        if not issubclass(override_class, base_class):
            raise ValueError(
                f"Override class must inherit from base DocType '{base_doctype}'"
            )

        # Check if an override already exists
        if base_doctype in self._overrides:
            existing_override = self._overrides[base_doctype]
            raise ValueError(
                f"DocType '{base_doctype}' already has an override registered: "
                f"{existing_override.__name__}"
            )

        # Register the override
        self._overrides[base_doctype] = override_class

    def has_override(self, doctype_name: str) -> bool:
        """
        Check if a DocType has an override registered.

        Args:
            doctype_name: The DocType name

        Returns:
            True if an override is registered, False otherwise
        """
        return doctype_name in self._overrides

    def get_override_class(self, doctype_name: str) -> type[BaseDocType] | None:
        """
        Get the override class for a DocType.

        Args:
            doctype_name: The DocType name

        Returns:
            The override class, or None if no override registered
        """
        return self._overrides.get(doctype_name)

    def register_meta_key(self, key: str) -> None:
        """
        Add a metadata key to the discovery whitelist.

        Allows custom apps and plugins to publish their own Meta
        attributes to the discovery API.

        Args:
            key: The flag name to whitelist (e.g., 'wms_meta')
        """
        self._whitelisted_meta_keys.add(key)

    def get_whitelisted_meta_keys(self) -> set[str]:
        """
        Get all metadata keys safe for public discovery.

        Returns:
            Set of whitelisted flag names.
        """
        return self._whitelisted_meta_keys

    def load_apps(self, installed_apps: list[str]) -> int:
        """
        Load DocTypes from installed apps in order.

        Scans each app package in the order specified and registers
        any discovered DocTypes. This respects the load order, so
        earlier apps in the list are registered first.

        Args:
            installed_apps: List of app package names to load, in order

        Returns:
            Total number of DocTypes discovered across all apps
        """
        total = 0
        for app_name in installed_apps:
            # Try namespaced structure first: <app_name>.doctypes
            count = self.discover_doctypes(f"{app_name}.doctypes")
            if count == 0:
                # Fallback: scan the entire module (legacy flat structure)
                count = self.discover_doctypes(app_name)
            total += count
        return total

    def load_installed_apps(self) -> int:
        """
        Discover and load DocTypes from all installed apps via entry points.

        This is the primary discovery mechanism for Framework M. It scans
        for 'framework_m.apps' entry points and loads their DocTypes.

        Returns:
            Total number of DocTypes discovered across all apps
        """
        from importlib.metadata import entry_points

        total = 0

        # 1. First, discover framework's core DocTypes
        total += self.discover_doctypes("framework_m_core.doctypes")

        # 2. Then discover DocTypes from all installed apps registered via entry points
        eps = entry_points(group="framework_m.apps")
        for ep in eps:
            try:
                # Load the app module to ensure it's in sys.modules
                ep.load()

                # Get the module path (e.g., "my_app" from "my_app:app")
                module_path = ep.module.split(":")[0]

                # Use load_apps logic for individual app
                total += self.load_apps([module_path])

            except Exception as e:
                # Log but don't fail if an app fails to load
                import sys

                print(f"Warning: Failed to load app '{ep.name}': {e}", file=sys.stderr)

        return total

    def discover_doctypes(self, package_name: str) -> int:
        """
        Discover and register DocTypes from a package.

        Scans all modules in the package for BaseDocType subclasses
        and registers them automatically. Raises DuplicateDocTypeError
        if a DocType name conflicts with an already registered one.

        Args:
            package_name: The package to scan (e.g., "myapp.doctypes")

        Returns:
            Number of DocTypes discovered and registered
        """
        # Import here to avoid circular imports
        from framework_m_core.domain.base_doctype import BaseDocType

        count = 0
        try:
            package = importlib.import_module(package_name)
        except ImportError:
            return 0

        # Get package path for iteration
        package_path = getattr(package, "__path__", None)
        if package_path is None:
            # It's a module, not a package - scan it directly
            for _, obj in inspect.getmembers(package, inspect.isclass):
                if issubclass(obj, BaseDocType) and obj is not BaseDocType:
                    name = obj.get_doctype_name()
                    if name not in self._doctypes:
                        self.register_doctype(obj)
                        count += 1
            return count

        # Iterate through submodules
        for _, module_name, _ in pkgutil.walk_packages(
            package_path, prefix=f"{package_name}."
        ):
            try:
                module = importlib.import_module(module_name)
                for _, obj in inspect.getmembers(module, inspect.isclass):
                    if issubclass(obj, BaseDocType) and obj is not BaseDocType:
                        name = obj.get_doctype_name()
                        if name not in self._doctypes:
                            self.register_doctype(obj)
                            count += 1
            except ImportError:
                continue

        return count

    def clear(self) -> None:
        """
        Clear all registered DocTypes, controllers, and overrides.

        Primarily used for testing.
        """
        self._doctypes.clear()
        self._controllers.clear()
        self._doctype_sources.clear()
        self._overrides.clear()

    def discover_local_project_doctypes(self) -> int:
        """Discover DocTypes from the current project source tree.

        This supports local app development where the project itself might not be
        installed as a package entry point yet.
        """
        from pathlib import Path

        unique_candidates = self._unique_preserve_order(
            self._collect_local_doctype_candidates(Path.cwd())
        )

        total = 0
        for package_name in unique_candidates:
            count = self.discover_doctypes(package_name)
            if count > 0:
                total += count

        return total

    def _parse_local_project_package_name(self, cwd: Any) -> str | None:
        pyproject = cwd / "pyproject.toml"
        if not pyproject.exists():
            return None

        try:
            import tomllib

            toml_loads = tomllib.loads
        except ImportError:
            return None

        try:
            data = toml_loads(pyproject.read_text(encoding="utf-8"))
            name = data.get("project", {}).get("name")
        except Exception:
            return None

        if isinstance(name, str) and name.strip():
            return name.strip().replace("-", "_")
        return None

    def _collect_local_doctype_candidates(self, cwd: Any) -> list[str]:
        candidates: list[str] = []

        project_package = self._parse_local_project_package_name(cwd)
        if project_package:
            candidates.append(f"{project_package}.doctypes")

        src_dir = cwd / "src"
        if not src_dir.exists():
            return candidates

        for package_dir in src_dir.iterdir():
            if (
                package_dir.is_dir()
                and (package_dir / "__init__.py").exists()
                and (package_dir / "doctypes").is_dir()
            ):
                candidates.append(f"{package_dir.name}.doctypes")

        if (src_dir / "doctypes").is_dir():
            candidates.append("doctypes")

        return candidates

    def _unique_preserve_order(self, items: list[str]) -> list[str]:
        seen: set[str] = set()
        unique_items: list[str] = []
        for item in items:
            if item in seen:
                continue
            seen.add(item)
            unique_items.append(item)
        return unique_items


class UIContextRegistry:
    """Registry for context-aware UI metadata overrides.

    Stores per-DocType UI metadata overrides for contexts such as
    ``office``, ``pos``, and ``mobile``. Consumers can resolve a base
    ``ui_meta`` structure with the matching context override merged in.
    """

    _instance: UIContextRegistry | None = None
    _context_overrides: dict[str, dict[str, dict[str, Any]]]

    def __new__(cls) -> UIContextRegistry:
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._context_overrides = {}
        return cls._instance

    @classmethod
    def get_instance(cls) -> UIContextRegistry:
        """Get the singleton instance."""
        return cls()

    def register_context_override(
        self,
        doctype_name: str,
        context: str,
        ui_meta: dict[str, Any],
    ) -> None:
        """Register UI metadata overrides for a DocType context."""
        normalized_context = context.strip().lower()
        if not normalized_context:
            raise ValueError("context must be a non-empty string")

        overrides = self._context_overrides.setdefault(doctype_name, {})
        overrides[normalized_context] = copy.deepcopy(ui_meta)

    def get_context_override(
        self,
        doctype_name: str,
        context: str,
    ) -> dict[str, Any] | None:
        """Return registered override for a DocType/context pair."""
        normalized_context = context.strip().lower()
        overrides = self._context_overrides.get(doctype_name, {})
        override = overrides.get(normalized_context)
        if override is None:
            return None
        return copy.deepcopy(override)

    def resolve_ui_meta(
        self,
        doctype_name: str,
        base_ui_meta: dict[str, Any] | None,
        context: str | None = None,
    ) -> dict[str, Any]:
        """Resolve base UI metadata with optional context overrides."""
        resolved: dict[str, Any] = copy.deepcopy(base_ui_meta or {})
        resolved.setdefault("doctype", doctype_name)

        if context is None:
            return resolved

        override = self.get_context_override(doctype_name, context)
        if override is None:
            return resolved

        return self._deep_merge(resolved, override)

    def list_contexts(self, doctype_name: str) -> list[str]:
        """List available contexts for a DocType."""
        return list(self._context_overrides.get(doctype_name, {}).keys())

    def clear(self) -> None:
        """Clear all context overrides (primarily for tests)."""
        self._context_overrides.clear()

    def _deep_merge(
        self,
        base: dict[str, Any],
        override: dict[str, Any],
    ) -> dict[str, Any]:
        merged: dict[str, Any] = copy.deepcopy(base)
        for key, value in override.items():
            base_value = merged.get(key)
            if (
                key in merged
                and isinstance(base_value, dict)
                and isinstance(value, dict)
            ):
                merged[key] = self._deep_merge(
                    cast(dict[str, Any], base_value),
                    value,
                )
            else:
                merged[key] = copy.deepcopy(value)
        return merged


class AggregateRootRegistry:
    """Registry for aggregate root view metadata.

    Tracks root DocTypes and their related child resources so frontend
    adapters can render master-detail aggregate views.
    """

    _instance: AggregateRootRegistry | None = None
    _aggregate_roots: dict[str, dict[str, Any]]

    def __new__(cls) -> AggregateRootRegistry:
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._aggregate_roots = {}
        return cls._instance

    @classmethod
    def get_instance(cls) -> AggregateRootRegistry:
        """Get singleton instance."""
        return cls()

    def register(
        self,
        doctype_name: str,
        config: dict[str, Any],
    ) -> None:
        """Register aggregate root configuration for a DocType."""
        self._aggregate_roots[doctype_name] = copy.deepcopy(config)

    def get(self, doctype_name: str) -> dict[str, Any] | None:
        """Get aggregate root configuration for a DocType."""
        config = self._aggregate_roots.get(doctype_name)
        if config is None:
            return None
        return copy.deepcopy(config)

    def clear(self) -> None:
        """Clear all aggregate root registrations (primarily for tests)."""
        self._aggregate_roots.clear()


__all__ = ["AggregateRootRegistry", "MetaRegistry", "UIContextRegistry"]
