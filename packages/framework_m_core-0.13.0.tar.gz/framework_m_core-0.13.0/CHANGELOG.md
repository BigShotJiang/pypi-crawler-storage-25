## framework-m-core v0.13.0

### Features

- add AuditMixin, VersionedMixin, diff util, and controller audit hooks (70f65f1)
- implement AuditMixin and auto-audit hooks (f5a3c3f)

## framework-m-core v0.12.0

### Features

- implement automated meta extraction and ui_meta support (4f3a65b)

## framework-m-core v0.11.4

### Bug Fixes

- implement bulk dependency upgrades and fix typecheck stubs (bf01d94)
- install pnpm and coreutils in release phase (ed335f8)
- enforce tool availability and install pnpm in CI (b8f9465)
- enforce lockfile sync, stage templates, and fix types (a41aad0)
- enhance local dry-run and silence check-ignore spam (29f9ef6)
- modernize gitops auth and api integration (7f15453)
- secure staging logic and resolve test regressions (e31d701)
- implement pnpm/uv lockfile sync and config cleanup (8302956)
- lint cleanup for cli.py (40b3a78)
- support GITLAB_TOKEN and harden auth check (c08b25c)
- implement atomic direct push for CI/CD stability (2947270)
- modularize release package and resolve test regressions (fe8c676)

## framework-m-core v0.11.3

### Bug Fixes

- install pnpm and coreutils in release phase (ed335f8)
- enforce tool availability and install pnpm in CI (b8f9465)
- enforce lockfile sync, stage templates, and fix types (a41aad0)
- enhance local dry-run and silence check-ignore spam (29f9ef6)
- modernize gitops auth and api integration (7f15453)
- secure staging logic and resolve test regressions (e31d701)
- implement pnpm/uv lockfile sync and config cleanup (8302956)
- lint cleanup for cli.py (40b3a78)
- support GITLAB_TOKEN and harden auth check (c08b25c)
- implement atomic direct push for CI/CD stability (2947270)
- modularize release package and resolve test regressions (fe8c676)

# Changelog

## framework-m-core v0.11.2

### Bug Fixes

- fix uv-build output and sync python packages (d9c994a)


## framework-m-core v0.11.1

### Bug Fixes

- refine dependency sync to respect explicit targets (187938c)
- support commit body tags for synchronized releases (b83d42a)
- switch to native uv build and bypass currently un-fixable pygments CVE (37cb5ef)


## framework-m-core v0.11.0

### Features

- fix basename and process.env polyfill (d5f1edd)

### Bug Fixes

- add license and clarify MX pattern (eafbb1a)
- clarify foundation and add license (59675a6)


## framework-m-core v0.10.0

### Features

- implement phase 13 (a6e9280)

### Bug Fixes

- remove unused import (40ea58f)


## framework-m-core v0.9.0

### Features

- implement OAuth2, webhook, CQRS and phase 15 (4209aa0)
- implement dynamic package detection and plugin loader for info command (3dcbf52)
- update todo and translation doctypes for LLM documentation (af54ad4)
- implement secrets management protocol and service (f89a3b6)

### Bug Fixes

- Removed the brittle developer/generated/index doc entry from the Reference (fcd004e)
- mismatch trigger (18920bc)
- ruff lint and format (ae16867)
- update and sync pnpm lockfile (2e85bc2)
- resolve gitleaks generic-api-key false positives (9ceec1e)


## framework-m-core v0.8.0

### Features

- implement runtime MFE loader and shell integration (f412561)


## framework-m-core v0.7.1

### Bug Fixes

- restore frontend build for metapackage and fix static sync (7a634ab)


## framework-m-core v0.7.0

### Features

- implement sidebar plugin architecture (28641af)
- persist LocalUser roles for RBAC (94fb348)
- persist LocalUser roles for RBAC (8ca17c9)
- implement entry-point-driven app and doctype discovery (848cb9c)

### Bug Fixes

- remove stale cp step in build-frontend job (97ca23d)
- bundle static assets in standard and studio wheels (dee74cc)
- ignore rule T3 and delete prod.md (0c9f243)
- frontend build cleanup (ff91c90)
- enforce workspace linking for internal packages and refresh lockfile (e4b8c8a)
- repo links (026645e)
- remove redundant tomli fallback for mypy compliance (bb235ba)


## framework-m-core v0.6.0

### Features

- Add  hook to  for new document inserts (f05f080)
- Implement field-level mutability for submitted documents (9495630)
- m dev and m prod command implementation (23f75cc)

### Bug Fixes

- safe empty fallback directory at .m/empty-assets and still registers StaticFilesConfig for /desk/assets (0ca7fd4)
- ruff errors (ac56951)
- lint errors and TestServeStaticMode in test_app.py (a6ac18c)


## framework-m-core v0.5.6

### Bug Fixes

- use last tag version as base for release bump (bfefd3f)
- support version bumping for package.json in release script (2b6a7c3)
- fix build crash and ensure static assets are packaged (bdc18b7)
- force include gitignored static assets in packages (4fd49a5)

## framework-m-core v0.5.5

### Bug Fixes

- trigger doc builds on studio changes (d1a2a7b)
- synchronize pages rules with build-docs (3b2d9b7)
- aggressive filtering and dependency decoupling (6b8dbf0)
- global dummy assets and artifact integrity (f6d39f2)
- dual-track artifacts and tag optimization (6b9cdfb)
- optimize tag pipeline and kill duplication (d9154ae)
- use hatch artifacts to resolve duplicate filenames (e499457)

## framework-m-core v0.5.4

### Bug Fixes

- robustly detect existing tags in auto_tag_release (8aeef39)

## framework-m-core v0.5.3

### Bug Fixes

- bulletproof tagging and gitlab pypi upload idempotency (530466b)
- make auto_tag_release script idempotent (c211ab5)

## framework-m-core v0.5.2

### Bug Fixes

- remove unsupported --skip-existing from gitlab twine upload (a1b6a96)

## framework-m-core v0.5.1

### Bug Fixes

- make test-workspace needs optional (96450fc)
- restore gitlint general section header (7131edc)
- adjust gitlint limits and script for long release titles (1a1371e)
- resolve duplicate filenames in wheel and improve CI robustness (e24c0ef)
- add project id in package.json and update readme (b36a65d)

## framework-m-core v0.5.0

### Features

- implement m prod and m dev commands (4c80fc1)
- implement bundled Desk distribution with npm package (20b3be4)

### Bug Fixes

- lint errors (9b6ab60)
- lint-import (8738781)
- switch tabs, doctype name spacing and foreign key field for doctypes (036f34c)
- Fix GitLab CI test failures (589d783)
- add framework-m-desk to pnpm-workspace.yaml (43deefa)
- lint format and import (9116aec)
- lint errors and rename publish-npm-package job to publish-npm-package-gitlab (77e2dce)

## framework-m-core v0.4.2

### Bug Fixes

- add TestPyPI badge to README (8e62bea)

## framework-m-core v0.4.1

### Bug Fixes

- add both OIDC tokens to all publish jobs (206d05d)

## framework-m-core v0.4.0

### Features

- add comprehensive README with installation and usage docs (9ce1589)
- add comprehensive README with installation and usage docs (8a01633)

### Bug Fixes

- add pipeline status badge to README (c413751)
- update package description in README (56a047c)
- use correct pyproject-build executable from build package (45d68b6)

## framework-m-core v0.3.1

### Bug Fixes

- add time import in release_utils (d4e3f8f)
- use uv tool run instead of uv run for both build and twine (801aa3f)

## framework-m-core v0.3.0

### Features

- Add new protocol-based interfaces, framework-mx-mongo and documentation generation (51f92ee)
- add gitlint for conventional commit enforcement (5ec959f)
- switch to scoped tags and fix release automation (e975051)
- add unique constraint support and refine docs (5f9af98)
- add Python-based release automation with update-existing-branch logic (6fcd9cb)
- add automated release workflow with duplicate prevention (ca5a508)
- add PyPI publishing for framework-m-studio and update docs (d6ed80a)
- comprehensive documentation covering fundamentals, migration guides, i18n, multi-tenancy usage, and API references (6a2c1df)
- implement Frontend Build & Serving (9f9aa79)
- implement desk ui (13ebcc8)
- implement workflows and advanced features (22a7745)
- implement system doctypes and features (05e7f3d)
- implement built-in doctypes and system adapters (23195d1)
- cli tools implementation (18a1d83)
- implement events, webhooks, monitoring and websockets (9381d3f)
- add NATS event bus, cron scheduler, and document lifecycle events (1b6525a)
- phase-03 complete (00123da)
- prepare for package split after completion (e8abae2)
- permission system implemented (632afb7)
- litestar application setup and authentication middleware (7854664)
- Complete DocType Engine & Database Layer (523f211)
- refactor phase-01 and implemented doctype-engine with CRUD, migrations and cli (3c36234)
- complete Phase 01 - Core Kernel & Interfaces (1dcbfab)
- automated pipeline for gitlab registry (c1a9e2b)

### Bug Fixes

- release script and broken anchors in features.md (3830267)
- broken links (dc03f4b)
- footer links and broken markdown links (82d0595)
- node version mismatch (7fc3067)
- docs command to use colon instead of space (eddf12d)
- lint and mypy errors (0e65b7d)
- lint and mypy errors (0738180)
- Resolve import errors and test failures after package split (6153884)
- add pypi and pipeline badges to readme (62590fc)
- robust package detection and safe MR title truncation (36385b6)
- improve changelog extraction for GitLab release pages (bb636b0)
- use show-ref for robust tag check and clear local ghost tags (79563c5)
- finalize air-tight release automation with GitLab releases, professional logging, and zero-spam logic (0dc7b19)
- simplify release rules and regex to stop recursive loops (790b318)
- fix auto-tagging trigger and regex for merge commits (5e69fb9)
- improve commit filtering and fix linting (6e4082d)
- prevent duplicate changelog entries by ensuring tags are fetched and handled correctly (a498f85)
- make release tag parsing more robust for large monorepos (8e1b5d8)
- update project URLs to GitLab and refactor versioning source of truth (84e0bd3)
- prevent recursive release loops and cleanup dead code (6ff3776)
- remove create-studio-release-mr and detached HEAD (d814206)
- lint issues (0c1dc94)
- studio issues and ci pipeline (e17e9c2)
- ruff issue (24fb2ef)
- ruff issue (2b3dfb0)
- mypy issues (23c539b)
- Fix ruff linting errors (ad8997c)
- lint format (8fc33e8)
- add framework-m-studio in dev dependencies (3d3825a)
- correct mypy type ignore for aioboto3 imports (aa04e86)
- format with ruff (c9d5f39)
- mypy issues (5ab1715)
- format all files with ruff (90e3808)
- remove skip ci from release commit message (2db2b6f)
- correct directory navigation in release-package job (5b67a98)
- lint error in base_doctype (47e8c37)
- lint error in test_base_doctype (354f66f)
- use twine for GitLab registry publishing (6472dc7)
- specify dist path for uv publish (86df5c7)
- exclude cache directories from source (695d2fb)
- lint errors in tests (8b4120d)
- rename workspace to avoid package name conflict (20e46bb)
