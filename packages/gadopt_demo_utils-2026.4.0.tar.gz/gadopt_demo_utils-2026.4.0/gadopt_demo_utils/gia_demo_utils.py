"""This module provides helper functions for plotting, associated with the
glacial isostatic adjustment demos, via Pyvista. This includes plotting
'ice rings' showing ice thickness offset from the surface of
the domain. This module also has default options for plotting viscosity
fields and animations with artificially warped meshes based on the
displacement field.

"""
from firedrake import atan2, conditional, exp, pi, tanh, Function
from gadopt.utility import vertical_component
import matplotlib.pyplot as plt
import numpy as np
import pyvista as pv
from pyvista.core.pointset import PolyData
from pyvista.core.utilities.reader import PVDReader
from pyvista.plotting.plotter import Plotter
import ufl

# camera settings
radius = 2.2
zoom = 4.25
lw = 5


def ice_sheet_disc(
        X: ufl.geometry.SpatialCoordinate,
        disc_centre: float,
        disc_halfwidth: float,
        radius: float = 6371e3,
        surface_dx_smooth: float = 200e3
) -> ufl.core.expr.Expr:
    '''Initialises ice sheet disc with a smooth transition given
    by a tanh profile

    Args:
      X:
        Spatial coordinate associated with the mesh
      disc_centre:
        centre of disc in radians (assumed to be between -pi to pi)
      disc_halfwidth:
        Half width of disc in radians
      radius:
        Radius of domain in m
      surface_dx_smooth:
        characteristic length scale for tanh smoothing in m

    Returns:
      Expression for ice sheet disc with tanh smoothing
    '''

    # Setup lengthscales for tanh smoothing
    surface_resolution_radians_smooth = surface_dx_smooth / radius

    # angle phi defined between -pi -> pi radians with zero at 'north pole'
    # (x,y) = (0,R) and -pi / pi transition at 'south pole' (x,y) = (0, -R)
    # where R is the radius of the domain
    phi = atan2(X[0], X[1])

    angular_distance_raw = abs(phi - disc_centre)
    # Angular distance accounting for discontinuity at 'south pole'
    angular_distance = conditional(
        angular_distance_raw < pi, angular_distance_raw, 2 * pi - angular_distance_raw
    )

    arg = angular_distance - disc_halfwidth
    disc = 0.5*(1-tanh(arg / (2*surface_resolution_radians_smooth)))
    return disc


def make_ice_ring(
        reader: PVDReader,
        thickness_scale: float = 2891e3,
        scalar='Ice thickness',
) -> PolyData:
    """Create a ring of ice thickness outside an annulus domain

    Args:
      reader:
        Pyvista reader that contains ice thickness data
      thickness_scale:
        Thickness in m used to re-dimensionalise ice thickness

    Returns:
      Ice thickness transformed to surface mesh
    """

    data = reader.read()[0]
    data[scalar] *= thickness_scale  # Convert ice thickness to m

    # Isolate data on surface of sphere
    surf = data.extract_feature_edges(boundary_edges=True, non_manifold_edges=False,
                                      feature_edges=False, manifold_edges=False)
    sphere = pv.Sphere(radius=0.8*radius)
    clipped_surf = surf.clip_surface(sphere, invert=False)

    # Stretch line by 15%
    stretch = 1.15
    transform_matrix = np.array(
        [
            [stretch, 0, 0, 0],
            [0, stretch, 0, 0],
            [0, 0, stretch, 0],
            [0, 0, 0, 1],
        ])
    transformed_surf = clipped_surf.transform(transform_matrix, inplace=True)
    return transformed_surf


def plot_ice_ring(
        plotter: Plotter,
        fname: str = 'ice.pvd',
        scalar: str = "Ice thickness",
        scalar_bar_x: float = 0.05,
        scalar_bar_y: float = 0.3,
        scalar_bar_vertical: bool = True,
        show_scalar_bar: bool = True,
        thickness_scale: float = 2891e3,
        timestep: int = 0):
    """Add an ice ring to Pyvista plot

    Args:
      plotter:
        Pyvista plotter
      fname:
        Name of VTK pvd file to read input data from
      scalar:
        Name of scalar field to plot
    """
    ice_reader = pv.get_reader(fname)
    ice_reader.set_active_time_point(timestep)
    ice_ring = make_ice_ring(ice_reader, scalar=scalar, thickness_scale=thickness_scale)
    ice_cmap = plt.get_cmap("Blues", 25)
    ice_lw = 20

    # add outline of ice ring
    plotter.add_mesh(ice_ring, color='black', line_width=ice_lw+2, lighting=False,
                     show_scalar_bar=False)

    # plot ice ring
    plotter.add_mesh(
        ice_ring,
        scalars=scalar,
        line_width=ice_lw,
        cmap=ice_cmap,
        clim=[0, 2000],
        scalar_bar_args={
            "title": 'Ice thickness (m)',
            "position_x": scalar_bar_x,
            "position_y": scalar_bar_y,
            "vertical": scalar_bar_vertical,
            "title_font_size": 20,
            "label_font_size": 16,
            "fmt": "%.0f",
            "font_family": "arial",
        },
        show_scalar_bar=show_scalar_bar,
    )


def plot_adj_viscosity(
        plotter: Plotter,
        fname: str = 'adj_visc.pvd',
        scalar_bar_x: float = 0.8,
        scalar_bar_y: float = 0.3,
        scalar_bar_vertical: bool = True,
        show_scalar_bar=True):
    """Add viscosity field to Pyvista plot

    Args:
      plotter:
        Pyvista plotter
      fname:
        Name of VTK pvd file to read input data from
      viscosity_scale:
        Characteristic viscosity scale used to re-dimensionalise the viscosity field
    """
    reader = pv.get_reader(fname)
    data = reader.read()[0]

    # add outline of domain
    surf = data.extract_feature_edges(boundary_edges=True, non_manifold_edges=False,
                                      feature_edges=False, manifold_edges=False)
    plotter.add_mesh(surf, color='black', line_width=lw,
                     lighting=False, show_scalar_bar=False)

    adj_cmap = plt.get_cmap("coolwarm", 25)

    plotter.add_mesh(
        data,
        component=None,
        lighting=False,
        show_edges=False,
        cmap=adj_cmap,
        clim=[-0.1, 0.1],
        scalar_bar_args={
            "title": 'Adjoint sensitivity',
            "position_x": scalar_bar_x,
            "position_y": scalar_bar_y,
            "vertical": scalar_bar_vertical,
            "title_font_size": 20,
            "label_font_size": 16,
            "fmt": "%.0e",
            "font_family": "arial",
            "n_labels": 6,
        },
        show_scalar_bar=show_scalar_bar,
    )


def plot_viscosity(
        plotter: Plotter,
        fname: str = 'viscosity.pvd',
        scalar: str = 'viscosity',
        viscosity_scale: float = 1e21,
        scalar_bar_x: float = 0.8,
        scalar_bar_y: float = 0.3,
        scalar_bar_vertical: bool = True,
        show_scalar_bar=True,
        timestep: int = 0):
    """Add viscosity field to Pyvista plot

    Args:
      plotter:
        Pyvista plotter
      fname:
        Name of VTK pvd file to read input data from
      viscosity_scale:
        Characteristic viscosity scale used to re-dimensionalise the viscosity field
    """
    reader = pv.get_reader(fname)
    reader.set_active_time_point(timestep)
    data = reader.read()[0]
    data[scalar] *= viscosity_scale  # Convert viscosity to Pa s

    # add outline of domain
    surf = data.extract_feature_edges(boundary_edges=True, non_manifold_edges=False,
                                      feature_edges=False, manifold_edges=False)
    plotter.add_mesh(surf, color='black', line_width=lw,
                     lighting=False, show_scalar_bar=False)

    inferno_cmap = plt.get_cmap("inferno_r", 25)

    plotter.add_mesh(
        data,
        scalars=scalar,
        component=None,
        lighting=False,
        show_edges=False,
        cmap=inferno_cmap,
        clim=[1e20, 1e25],
        log_scale=True,
        scalar_bar_args={
            "title": 'Viscosity (Pa s)',
            "position_x": scalar_bar_x,
            "position_y": scalar_bar_y,
            "vertical": scalar_bar_vertical,
            "title_font_size": 20,
            "label_font_size": 16,
            "fmt": "%.0e",
            "font_family": "arial",
            "n_labels": 6,
        },
        show_scalar_bar=show_scalar_bar,
    )


def plot_animation(
        plotter: Plotter,
        fname: str = 'output.pvd',
        domain_depth: float = 2891e3,
        dt_out_years: float = 1e3):
    """Artifically warp mesh based on displacement and create a gif

    Args:
      plotter:
        Pyvista plotter
      fname:
        Name of VTK pvd file to read input data from
      domain_depth:
        Depth of domain in m used to re-dimensionalise displacement
      dt_out_years:
        Time step duration in years of simulation outputs
    """

    reader = pv.get_reader(fname)
    data = reader.read()[0]

    plotter.open_gif("displacement_warp.gif")

    inferno_cmap = plt.get_cmap("inferno_r", 25)

    # Make a list of output times (non-uniform because also
    # outputing first (quasi-elastic) solve
    times = [0]
    for i in range(len(reader.time_values)):
        times.append((i+1)*dt_out_years)

    for i in range(len(reader.time_values)):
        print("Step: ", i)
        reader.set_active_time_point(i)
        data = reader.read()[0]

        # Artificially warp the output data by the displacement
        # Note the mesh is not really moving!
        warped = data.warp_by_vector(vectors="displacement", factor=1500)
        arrows = warped.glyph(orient="velocity", scale="velocity", factor=5e4, tolerance=0.01)
        plotter.add_mesh(arrows, color="grey", lighting=False)

        data['displacement'] *= domain_depth  # Convert displacement to m
        # Add the warped displacement field to the frame
        plotter.add_mesh(
            warped,
            scalars="displacement",
            component=None,
            lighting=False,
            clim=[0, 600],
            cmap=inferno_cmap,
            scalar_bar_args={
                "title": 'Displacement (m)',
                "position_x": 0.85,
                "position_y": 0.3,
                "vertical": True,
                "title_font_size": 20,
                "label_font_size": 16,
                "fmt": "%.0f",
                "font_family": "arial",
            }
        )

        plotter.camera_position = [(0, 0, radius*5),
                                   (0.0, 0.0, 0.0),
                                   (0.0, 1.0, 0.0)]

        plotter.add_text(f"Time: {times[i]:6} years", name='time-label')

        if i == 0:
            plot_ice_ring(plotter, scalar="zero")
            for j in range(10):
                plotter.write_frame()

        plot_ice_ring(plotter)

        # Write end frame multiple times to give a pause before gif starts again!
        for j in range(10):
            plotter.write_frame()

        if i == len(reader.time_values)-1:
            # Write end frame multiple times to give a pause before gif starts again!
            for j in range(20):
                plotter.write_frame()

        plotter.clear()


def plot_displacement(
        plotter: Plotter,
        fname: str = 'output.pvd',
        disp='displacement',
        vel='velocity',
        domain_depth: float = 2891e3,
        timestep: int = 0,
        scalar_bar_x: float = 0.85,
        show_scalar_bar=True):
    """Add viscosity field to Pyvista plot

    Args:
      plotter:
        Pyvista plotter
      fname:
        Name of VTK pvd file to read input data from
      viscosity_scale:
        Characteristic viscosity scale used to re-dimensionalise the viscosity field
    """
    reader = pv.get_reader(fname)
    reader.set_active_time_point(timestep)
    data = reader.read()[0]
    # Artificially warp the output data by the displacement
    # Note the mesh is not really moving!
    warped = data.warp_by_vector(vectors=disp, factor=1500)
    arrows = warped.glyph(orient=vel, scale=vel, factor=5e4, tolerance=0.01)
    plotter.add_mesh(arrows, color="grey", lighting=False)
    data[disp] *= domain_depth  # Convert displacement to m
    inferno_cmap = plt.get_cmap("inferno_r", 25)
    # Add the warped displacement field to the frame
    plotter.add_mesh(
        warped,
        scalars=disp,
        component=None,
        lighting=False,
        clim=[0, 600],
        cmap=inferno_cmap,
        scalar_bar_args={
            "title": 'Displacement (m)',
            "position_x": scalar_bar_x,
            "position_y": 0.3,
            "vertical": True,
            "title_font_size": 20,
            "label_font_size": 16,
            "fmt": "%.0f",
            "font_family": "arial",
        },
        show_scalar_bar=True,
    )


def plot_adj_ring(
        plotter: Plotter,
        fname: str = 'adj_ice.pvd',
        scalar: str = "Ice thickness",
        stretch: float = 1.15,
        scalar_bar_x: float = 0.8,
        scalar_bar_y: float = 0.3,
        scalar_bar_vertical: bool = True,
        show_scalar_bar=True):
    """Add an ice ring to Pyvista plot

    Args:
      plotter:
        Pyvista plotter
      fname:
        Name of VTK pvd file to read input data from
      scalar:
        Name of scalar field to plot
    """
    reader = pv.get_reader(fname)
    data = reader.read()[0]
    # Stretch so that ring appears outside computational domain
    transform_matrix = np.array(
        [
            [stretch, 0, 0, 0],
            [0, stretch, 0, 0],
            [0, 0, stretch, 0],
            [0, 0, 0, 1],
        ])
    transformed_surf = data.transform(transform_matrix, inplace=True)
    ice_lw = 20

    # add outline of ice ring
    plotter.add_mesh(transformed_surf, color='black', line_width=ice_lw+2, lighting=False,
                     show_scalar_bar=False)
    adj_cmap = plt.get_cmap("coolwarm", 25)
    # plot ice ring
    plotter.add_mesh(
        transformed_surf,
        line_width=ice_lw,
        cmap=adj_cmap,
        clim=[-0.5, 0.5],
        scalar_bar_args={
            "title": 'Adjoint sensitivity',
            "position_x": scalar_bar_x,
            "position_y": scalar_bar_y,
            "vertical": scalar_bar_vertical,
            "title_font_size": 20,
            "label_font_size": 16,
            "fmt": "%.2f",
            "font_family": "arial",
        }
    )


def setup_heterogenous_viscosity(
        X: ufl.geometry.SpatialCoordinate,
        background_viscosity: Function,
        viscosity_scale: float = 1e21,
        r_lith: float = 6301e3,
        domain_depth: float = 2891e3,
) -> Function:
    '''Adds lateral variations to a background viscosity field in a 2D annulus

    The synthetic lateral viscosity variations consist of 5 'blobs'
    constructed from bivariate gaussian functions to represent interesting features
    in the mantle. We assume the background viscosity only varies in the
    radial direction and do not make modifications to the viscosity structure
    in the lithosphere i.e. for r > `r_lith' where r is the radial distance.

    Args:
      X:
        Spatial coordinate associated with the mesh
      background_viscosity:
        Background radial viscosity field (N.b. this is not modified)
      viscosity_scale:
        Characteristc viscosity used for nondimensionalisation
      r_lith:
        Radius of the lithosphere-mantle boundary in m
      domain_depth:
        Domain depth in m used for nondimensionalisation

    Returns:
      heterogenous_viscosity_field
        A new field containing the updated lateral viscosity variations
    '''
    heterogenous_viscosity_field = Function(background_viscosity.function_space(),
                                            name='viscosity')

    # Set up magnitudes of low and high viscosity regions
    low_visc = 1e20/viscosity_scale
    high_visc = 1e22/viscosity_scale

    # Add a low viscosity region in the bottom left corner
    # of the domain, aiming to mimic the low viscosity zone under the West
    # Antarctic ice sheet
    southpole_x, southpole_y = -2e6/domain_depth, -5.5e6/domain_depth
    low_viscosity_southpole = bivariate_gaussian(X[0], X[1],
                                                 southpole_x, southpole_y,
                                                 1.5e6/domain_depth,
                                                 0.5e6/domain_depth,
                                                 -0.4)

    heterogenous_viscosity_field.interpolate(
        low_visc*low_viscosity_southpole + background_viscosity * (1-low_viscosity_southpole))

    # Add two symmetrical low viscosity zones near the core-mantle boundary, inspired by
    # Large Low-Shear-Velocity Provinces (referred to as `llsvp`) so that
    # we can investigate sensitivity in the lower mantle.
    llsvp1_x, llsvp1_y = 3.5e6/domain_depth, 0
    llsvp1 = bivariate_gaussian(X[0], X[1], llsvp1_x, llsvp1_y, 0.75e6/domain_depth,
                                1e6/domain_depth, 0)

    heterogenous_viscosity_field.interpolate(low_visc*llsvp1 +
                                             heterogenous_viscosity_field * (1-llsvp1))

    llsvp2_x, llsvp2_y = -3.5e6/domain_depth, 0
    llsvp2 = bivariate_gaussian(X[0], X[1], llsvp2_x, llsvp2_y, 0.75e6/domain_depth,
                                1e6/domain_depth, 0)

    heterogenous_viscosity_field.interpolate(low_visc*llsvp2 +
                                             heterogenous_viscosity_field * (1-llsvp2))

    # Add an elongated high viscosity region in the top right corner of the domain
    # to represent a slab geometry
    slab_x, slab_y = 3e6/domain_depth, 4.5e6/domain_depth
    slab = bivariate_gaussian(X[0], X[1], slab_x, slab_y, 0.7e6/domain_depth,
                              0.35e6/domain_depth, 0.7)

    heterogenous_viscosity_field.interpolate(high_visc*slab +
                                             heterogenous_viscosity_field * (1-slab))

    # Add a high viscosity feature at the top of the domain representing a craton
    high_viscosity_craton_x, high_viscosity_craton_y = 0, 6.2e6/domain_depth
    high_viscosity_craton = bivariate_gaussian(X[0], X[1], high_viscosity_craton_x,
                                               high_viscosity_craton_y,
                                               1.5e6/domain_depth,
                                               0.5e6/domain_depth, 0.2)

    heterogenous_viscosity_field.interpolate(
        high_visc*high_viscosity_craton +
        heterogenous_viscosity_field * (1-high_viscosity_craton)
    )

    # We usually assume the lithosphere is purely elastic for GIA simulations,
    # so we reset viscosity in the lithosphere to the original background viscosity
    # value, which is assumed to be an arbitarily high constant so that the Maxwell
    # time in this layer is much larger than the timestep and simulation duration.
    heterogenous_viscosity_field.interpolate(
        conditional(vertical_component(X) > r_lith/domain_depth,
                    background_viscosity,
                    heterogenous_viscosity_field))

    return heterogenous_viscosity_field


def bivariate_gaussian(x, y, mu_x, mu_y, sigma_x, sigma_y, rho, normalised_area=False):
    arg = ((x-mu_x)/sigma_x)**2 - 2*rho*((x-mu_x)/sigma_x)*((y-mu_y)/sigma_y) + ((y-mu_y)/sigma_y)**2
    numerator = exp(-1/(2*(1-rho**2))*arg)
    if normalised_area:
        denominator = 2*pi*sigma_x*sigma_y*(1-rho**2)**0.5
    else:
        denominator = 1
    return numerator / denominator
