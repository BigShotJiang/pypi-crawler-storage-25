#   python manage.py generate_brd --discover
#   python manage.py generate_brd --flow "Carga de Subestaciones" --subdir "Extracción"
#   python manage.py generate_brd --flow "Carga de Subestaciones" --force
#   python manage.py generate_brd --reindex
#   python manage.py generate_brd --reindex --subdir "Extracción"

import os
import re

from pathlib import Path

from django.conf import settings
from django.core.management.base import BaseCommand
from django.core.management.base import CommandError

import anthropic

from magnet_dpt_doc_generator.management.commands._generate_docs.collector import collect_srs_docs
from magnet_dpt_doc_generator.management.commands._generate_docs.collector import collect_srs_index
from magnet_dpt_doc_generator.management.commands._generate_docs.collector import collect_url_patterns
from magnet_dpt_doc_generator.management.commands._generate_docs.config import BRD_OUTPUT_DIR
from magnet_dpt_doc_generator.management.commands._generate_docs.config import DOCS_OUTPUT_DIR
from magnet_dpt_doc_generator.management.commands._generate_docs.config import GLOSSARY_PATH
from magnet_dpt_doc_generator.management.commands._generate_docs.config import REQUEST_DELAY_SECONDS
from magnet_dpt_doc_generator.management.commands._generate_docs.prompts import BRD_DISCOVER_PROMPT
from magnet_dpt_doc_generator.management.commands._generate_docs.prompts import BRD_FLOW_PROMPT
from magnet_dpt_doc_generator.management.commands._generate_docs.prompts import BRD_INDEX_PROMPT
from magnet_dpt_doc_generator.management.commands._generate_docs.prompts import BRD_SYSTEM_PROMPT
from magnet_dpt_doc_generator.management.commands._generate_docs.prompts import DESCRIPTION_HINT
from magnet_dpt_doc_generator.management.commands._generate_docs.prompts import GLOSSARY_SECTION
from magnet_dpt_doc_generator.management.commands._generate_docs.prompts import SRS_INDEX_SECTION
from magnet_dpt_doc_generator.management.commands._generate_docs.prompts import URL_SECTION


def _slugify(name: str) -> str:
    """Convert a name to a safe filename or directory name."""
    slug = name.lower().strip()
    slug = re.sub(r"[^\w\s-]", "", slug)
    slug = re.sub(r"[\s_-]+", "_", slug)
    return slug[:80]


def _call_api(client: anthropic.Anthropic, prompt: str, stdout=None) -> str:
    """Call the API with retries on rate limit errors."""
    import time

    import magnet_dpt_doc_generator.management.commands._generate_docs.api_client as api_mod

    from magnet_dpt_doc_generator.management.commands._generate_docs.config import MAX_RETRIES
    from magnet_dpt_doc_generator.management.commands._generate_docs.config import MAX_TOKENS
    from magnet_dpt_doc_generator.management.commands._generate_docs.config import MODEL
    from magnet_dpt_doc_generator.management.commands._generate_docs.config import RETRY_BACKOFF

    delay = api_mod.REQUEST_DELAY_SECONDS
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            msg = client.messages.create(
                model=MODEL,
                max_tokens=MAX_TOKENS,
                system=BRD_SYSTEM_PROMPT,
                messages=[{"role": "user", "content": prompt}],
            )
            time.sleep(delay)
            return msg.content[0].text
        except anthropic.RateLimitError:
            if attempt == MAX_RETRIES:
                raise
            wait = RETRY_BACKOFF * attempt
            text = (
                f"Rate limit reached (attempt {attempt}/{MAX_RETRIES})."
                f" Waiting {wait}s..."
            )
            (stdout.write if stdout else print)(text)
            time.sleep(wait)
    return ""  # unreachable, but satisfies the explicit-return requirement


def _load_glossary(repo_path: Path, override: str | None) -> str:
    path = repo_path / (override or GLOSSARY_PATH)
    return path.read_text(encoding="utf-8") if path.exists() else ""


def _existing_flows(brd_dir: Path) -> list[str]:
    """Return stems of already-documented flow files in a directory."""
    return [p.stem for p in sorted(brd_dir.glob("*.md")) if p.stem != "README"]


def _rebuild_index(
    client: anthropic.Anthropic,
    target_dir: Path,
    glossary: str,
    stdout=None,
):
    """
    Regenerate README.md for target_dir.
    Includes both .md flow files and subdirectory READMEs found in that directory.
    """
    entries = []

    # Direct flow files
    for p in sorted(target_dir.glob("*.md")):
        if p.stem != "README":
            label = p.stem.replace("_", " ").title()
            entries.append(f"- [{label}]({p.name})")

    # Subdirectories that have a README
    for sub in sorted(d for d in target_dir.iterdir() if d.is_dir()):
        if (sub / "README.md").exists():
            label = sub.name.replace("_", " ").title()
            entries.append(f"- [{label}]({sub.name}/README.md)")

    if not entries:
        return

    flow_list = "\n".join(entries)
    glossary_section = GLOSSARY_SECTION.format(glossary=glossary) if glossary else ""
    prompt = BRD_INDEX_PROMPT.format(
        flow_list=flow_list,
        glossary_section=glossary_section,
    )

    if stdout:
        stdout.write(f"Regenerating index: {target_dir / 'README.md'}")
    content = _call_api(client, prompt, stdout)
    (target_dir / "README.md").write_text(content, encoding="utf-8")


def _rebuild_root_index(
    client: anthropic.Anthropic,
    brd_root: Path,
    glossary: str,
    stdout=None,
):
    """Always regenerate the root BRD README after any change."""
    _rebuild_index(client, brd_root, glossary, stdout)


class Command(BaseCommand):
    help = "Generate a BRD from existing SRS documentation"

    def add_arguments(self, parser):
        mode = parser.add_mutually_exclusive_group(required=True)
        mode.add_argument(
            "--discover",
            action="store_true",
            help="Read the SRS and propose a list of business flows to document.",
        )
        mode.add_argument(
            "--flow",
            metavar="NAME",
            help="Name of the business flow to document.",
        )
        mode.add_argument(
            "--reindex",
            action="store_true",
            help="Regenerate README indexes (root + subdir if --subdir is given).",
        )
        parser.add_argument(
            "--subdir",
            default=None,
            metavar="NAME",
            help=(
                "Optional subdirectory name inside the BRD output dir "
                "(e.g. --subdir Extracción). "
                "The flow file and its README go there; "
                "the root README is also updated."
            ),
        )
        parser.add_argument(
            "--srs-dir",
            default=None,
            metavar="DIR",
            help=f"SRS docs directory (default: {DOCS_OUTPUT_DIR}, set in config.py)",
        )
        parser.add_argument(
            "--output",
            default=None,
            metavar="DIR",
            help=f"BRD root output directory (default: {BRD_OUTPUT_DIR})",
        )
        parser.add_argument(
            "--glossary",
            default=None,
            metavar="FILE",
            help=f"Path to GLOSSARY.md (default: {GLOSSARY_PATH}, set in config.py)",
        )
        parser.add_argument(
            "--root-urls",
            default="project/urls.py",
            metavar="FILE",
            help="Root urls.py relative to BASE_DIR (default: project/urls.py)",
        )
        parser.add_argument(
            "--force",
            action="store_true",
            help="Overwrite an existing flow file.",
        )
        parser.add_argument(
            "--description",
            default=None,
            metavar="TEXT",
            help="Optional one-line description of the flow from --discover output.",
        )
        parser.add_argument(
            "--srs-files",
            nargs="+",
            metavar="FILE",
            help=(
                "One or more additional .md files to include in the SRS context "
                "(relative to BASE_DIR). Appended after the main SRS content."
            ),
        )
        parser.add_argument(
            "--delay",
            type=int,
            default=None,
            metavar="SECONDS",
            help=(
                f"Pause between API calls in seconds"
                f" (default: {REQUEST_DELAY_SECONDS}s)."
            ),
        )

    def handle(self, *args, **options):
        import magnet_dpt_doc_generator.management.commands._generate_docs.api_client as api_mod

        if options["delay"] is not None:
            api_mod.REQUEST_DELAY_SECONDS = options["delay"]

        self._repo_path = Path(settings.BASE_DIR).resolve()
        self._brd_root = self._repo_path / (options["output"] or BRD_OUTPUT_DIR)
        self._srs_dir = self._repo_path / (options["srs_dir"] or DOCS_OUTPUT_DIR)
        self._target_dir = (
            self._brd_root / options["subdir"] if options["subdir"] else self._brd_root
        )
        self._target_dir.mkdir(parents=True, exist_ok=True)

        if not self._srs_dir.exists():
            msg = (
                f"SRS directory not found: {self._srs_dir}\n"
                "Run generate_docs first, or pass --srs-dir."
            )
            raise CommandError(msg)

        api_key = getattr(settings, "ANTHROPIC_API_KEY", None) or os.environ.get(
            "ANTHROPIC_API_KEY"
        )
        if not api_key:
            msg = "ANTHROPIC_API_KEY not found."
            raise CommandError(msg)
        self._client = anthropic.Anthropic(api_key=api_key)

        self._glossary = _load_glossary(self._repo_path, options["glossary"])
        if self._glossary:
            glossary_path = self._repo_path / (options["glossary"] or GLOSSARY_PATH)
            self.stdout.write(f"Glossary loaded: {glossary_path}\n")

        self._url_patterns = collect_url_patterns(self._repo_path, options["root_urls"])
        if self._url_patterns:
            self.stdout.write(f"URL patterns loaded from: {options['root_urls']}\n")
        else:
            self.stderr.write(
                self.style.WARNING(
                    f"No URL patterns found at: {options['root_urls']}\n"
                )
            )

        if options["discover"]:
            self._run_discover()
        elif options["reindex"]:
            self._run_reindex(options["subdir"])
        else:
            self._run_flow(options)

    def _run_discover(self):
        self.stdout.write(f"Reading SRS from: {self._srs_dir}")
        srs_content = collect_srs_docs(self._srs_dir)
        if not srs_content.strip():
            msg = "No SRS documents found. Run generate_docs first."
            raise CommandError(msg)

        glossary_section = (
            GLOSSARY_SECTION.format(glossary=self._glossary) if self._glossary else ""
        )
        prompt = BRD_DISCOVER_PROMPT.format(
            srs_content=srs_content,
            glossary_section=glossary_section,
        )
        self.stdout.write("Analyzing SRS to identify business flows...\n")
        result = _call_api(self._client, prompt, self.stdout)

        already = _existing_flows(self._target_dir)
        self.stdout.write("\n" + "─" * 60)
        self.stdout.write("Proposed business flows:\n")
        self.stdout.write(result)
        self.stdout.write("─" * 60)
        if already:
            self.stdout.write(
                self.style.WARNING(f"\nAlready documented: {', '.join(already)}")
            )
        self.stdout.write(
            '\nRun: python manage.py generate_brd --flow "<flow name>" to document one.'
        )

    def _run_reindex(self, subdir: str | None):
        if subdir:
            _rebuild_index(self._client, self._target_dir, self._glossary, self.stdout)
        _rebuild_root_index(self._client, self._brd_root, self._glossary, self.stdout)

    def _run_flow(self, options: dict):
        flow_name = options["flow"]
        slug = _slugify(flow_name)
        out_path = self._target_dir / f"{slug}.md"

        if out_path.exists() and not options["force"]:
            msg = f"Flow already exists: {out_path}\nUse --force to overwrite."
            raise CommandError(msg)

        self.stdout.write(f"Reading SRS from: {self._srs_dir}")
        srs_content = collect_srs_docs(self._srs_dir)
        if not srs_content.strip():
            msg = "No SRS documents found. Run generate_docs first."
            raise CommandError(msg)

        if options["srs_files"]:
            srs_content = self._append_extra_srs_files(
                srs_content, options["srs_files"]
            )

        glossary_section = (
            GLOSSARY_SECTION.format(glossary=self._glossary) if self._glossary else ""
        )
        url_section = (
            URL_SECTION.format(url_patterns=self._url_patterns)
            if self._url_patterns
            else ""
        )
        description_hint = (
            DESCRIPTION_HINT.format(description=options["description"])
            if options["description"]
            else ""
        )
        srs_index = collect_srs_index(self._srs_dir)
        srs_index_section = (
            SRS_INDEX_SECTION.format(srs_index=srs_index) if srs_index else ""
        )

        prompt = BRD_FLOW_PROMPT.format(
            flow_name=flow_name,
            srs_content=srs_content,
            url_section=url_section,
            glossary_section=glossary_section,
            srs_index_section=srs_index_section,
            description_hint=description_hint,
        )

        self.stdout.write(f'Documenting flow: "{flow_name}"...')
        content = _call_api(self._client, prompt, self.stdout)
        out_path.write_text(content, encoding="utf-8")
        self.stdout.write(self.style.SUCCESS(f"Saved: {out_path}"))

        if options["subdir"]:
            _rebuild_index(self._client, self._target_dir, self._glossary, self.stdout)
        _rebuild_root_index(self._client, self._brd_root, self._glossary, self.stdout)

        self.stdout.write(
            self.style.SUCCESS(f"Done. BRD directory: {self._target_dir}")
        )

    def _append_extra_srs_files(self, srs_content: str, srs_files: list[str]) -> str:
        extras = []
        for raw_path in srs_files:
            p = Path(raw_path)
            if not p.is_absolute():
                p = self._repo_path / p
            if not p.exists():
                self.stderr.write(
                    self.style.WARNING(f"  SRS file not found, skipping: {p}")
                )
                continue
            try:
                extra_content = p.read_text(encoding="utf-8", errors="ignore")
                extras.append(f"### {p.name}\n\n{extra_content}")
                self.stdout.write(f"  Extra SRS file loaded: {p}")
            except OSError as e:
                self.stderr.write(self.style.WARNING(f"  Could not read {p}: {e}"))
        if extras:
            srs_content += "\n\n---\n\n" + "\n\n---\n\n".join(extras)
        return srs_content
