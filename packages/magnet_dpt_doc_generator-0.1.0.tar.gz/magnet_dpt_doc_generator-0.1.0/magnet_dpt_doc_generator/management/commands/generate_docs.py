from magnet_dpt_doc_generator.management.commands._generate_docs.command import Command

__all__ = ["Command"]
