# Usage:
#   # Generate glossary from scratch by scanning apps
#   python manage.py generate_glossary --apps generation projects
#
#   # Update existing glossary (adds new terms, keeps existing ones)
#   python manage.py generate_glossary --apps generation projects --update

import os

from pathlib import Path

from django.conf import settings
from django.core.management.base import BaseCommand
from django.core.management.base import CommandError

import anthropic

from magnet_dpt_doc_generator.management.commands._generate_docs.api_client import define_terms_from_code
from magnet_dpt_doc_generator.management.commands._generate_docs.api_client import extract_term_names
from magnet_dpt_doc_generator.management.commands._generate_docs.api_client import infer_definitions
from magnet_dpt_doc_generator.management.commands._generate_docs.collector import collect_po_files
from magnet_dpt_doc_generator.management.commands._generate_docs.collector import collect_python_files
from magnet_dpt_doc_generator.management.commands._generate_docs.collector import read_file_for_doc
from magnet_dpt_doc_generator.management.commands._generate_docs.collector import read_po_strings
from magnet_dpt_doc_generator.management.commands._generate_docs.config import GLOSSARY_PATH
from magnet_dpt_doc_generator.management.commands._generate_docs.config import REQUEST_DELAY_SECONDS

GLOSSARY_HEADER = """\
# Project Glossary

Domain terms, acronyms and abbreviations used throughout the codebase.
**Edit this table freely** — future runs will preserve your changes.

| Term | Meaning | Notes |
|---|---|---|
"""

# Seed rows always present in a new glossary — included in the alphabetical sort.
GLOSSARY_SEED_ROWS = [
    "| BRD  | Documento de requerimientos del negocio | "
    "BRD de sus siglas en Inglés: Business Requirements Document. "
    "Documentación orientada al cliente que describe qué hace el sistema y por qué, "
    "escrita en lenguaje no técnico |",
    "| SRS  | Especificación de Requerimientos de Software | "
    " SRS de sus siglas en inglés: Software Requirements Specification. "
    "Documentación técnica que describe cómo se implementa el sistema, "
    "dirigida a desarrolladores |",
]

TermRegistry = dict[str, dict[str, str]]


def _load_existing_glossary(
    output_path: Path,
) -> tuple[set[str], list[str]]:
    existing_terms: set[str] = set()
    existing_rows: list[str] = []
    for line in output_path.read_text(encoding="utf-8").splitlines():
        if (
            line.startswith("| ")
            and not line.startswith("| Term")
            and not line.startswith("|---")
        ):
            term = line.split("|")[1].strip()
            existing_terms.add(term.lower())
            existing_rows.append(_normalize_row(line))
    return existing_terms, existing_rows


def _normalize_row(line: str) -> str:
    """Strip excess whitespace from each cell of a Markdown table row."""
    cells = [c.strip() for c in line.split("|")][1:-1]
    return "| " + " | ".join(cells) + " |"


def _build_row(entry: dict[str, str]) -> str:
    meaning = entry["meaning"] or "—"
    return f"| {entry['display']} | {meaning} | {entry['notes']} |"


class Command(BaseCommand):
    help = "Generate or update a domain glossary using Claude (3-phase)"

    def add_arguments(self, parser):
        parser.add_argument(
            "--apps",
            nargs="+",
            metavar="APP",
            required=True,
            help="Django apps to scan for domain terms.",
        )
        parser.add_argument(
            "--output",
            default=None,
            metavar="FILE",
            help=f"Glossary output file (default: {GLOSSARY_PATH}, set in config.py)",
        )
        parser.add_argument(
            "--update",
            action="store_true",
            help=(
                "Add new terms to an existing glossary without overwriting current "
                "entries."
            ),
        )
        parser.add_argument(
            "--delay",
            type=int,
            default=None,
            metavar="SECONDS",
            help=(
                "Pause between API calls in seconds "
                f"(default: {REQUEST_DELAY_SECONDS}s)."
            ),
        )

    # ── Phase helpers ──────────────────────────────────────────────────────────

    def _collect_terms(
        self,
        content: str,
        client: anthropic.Anthropic,
        existing_terms: set[str],
        term_registry: TermRegistry,
    ) -> int:
        """Add new term names (no definitions) to term_registry. Returns count added."""
        names = extract_term_names(client, content, self.stdout)
        count = 0
        for name in names:
            lower = name.lower()
            if lower not in existing_terms and lower not in term_registry:
                term_registry[lower] = {"display": name, "meaning": "", "notes": ""}
                count += 1
        return count

    def _define_terms(
        self,
        content: str,
        client: anthropic.Anthropic,
        term_registry: TermRegistry,
    ) -> int:
        """Fill in meanings for undefined terms using code evidence. Returns count."""
        undefined = [v["display"] for v in term_registry.values() if not v["meaning"]]
        if not undefined:
            return 0
        defined = define_terms_from_code(client, content, undefined, self.stdout)
        count = 0
        for lower, (meaning, notes) in defined.items():
            if lower in term_registry and not term_registry[lower]["meaning"]:
                term_registry[lower]["meaning"] = meaning
                term_registry[lower]["notes"] = notes
                count += 1
        return count

    def _phase1(
        self,
        py_files: list[Path],
        po_files: list[Path],
        repo_path: Path,
        client: anthropic.Anthropic,
        existing_terms: set[str],
    ) -> TermRegistry:
        """Scan all files to collect term names only."""
        term_registry: TermRegistry = {}
        total = len(py_files) + len(po_files)
        n = 0
        for file_path in py_files:
            n += 1
            rel = file_path.relative_to(repo_path)
            self.stdout.write(f"  [{n}/{total}] {rel} ... ", ending="")
            try:
                count = self._collect_terms(
                    read_file_for_doc(file_path), client, existing_terms, term_registry
                )
                self.stdout.write(self.style.SUCCESS(f"+{count}"))
            except Exception as e:  # noqa: BLE001
                self.stderr.write(self.style.ERROR(f"error: {e}"))
        for po_path in po_files:
            n += 1
            rel = po_path.relative_to(repo_path)
            self.stdout.write(f"  [{n}/{total}] {rel} ... ", ending="")
            try:
                po_text = read_po_strings(po_path)
                if not po_text.strip():
                    self.stdout.write(self.style.WARNING("empty, skipped"))
                    continue
                count = self._collect_terms(
                    po_text, client, existing_terms, term_registry
                )
                self.stdout.write(self.style.SUCCESS(f"+{count}"))
            except Exception as e:  # noqa: BLE001
                self.stderr.write(self.style.ERROR(f"error: {e}"))
        return term_registry

    def _phase2(
        self,
        py_files: list[Path],
        po_files: list[Path],
        repo_path: Path,
        client: anthropic.Anthropic,
        term_registry: TermRegistry,
    ) -> None:
        """Scan all files to find definitions from explicit code evidence."""
        total = len(py_files) + len(po_files)
        n = 0
        for file_path in py_files:
            n += 1
            if not any(not v["meaning"] for v in term_registry.values()):
                break
            rel = file_path.relative_to(repo_path)
            self.stdout.write(f"  [{n}/{total}] {rel} ... ", ending="")
            try:
                count = self._define_terms(
                    read_file_for_doc(file_path), client, term_registry
                )
                self.stdout.write(self.style.SUCCESS(f"+{count} defined"))
            except Exception as e:  # noqa: BLE001
                self.stderr.write(self.style.ERROR(f"error: {e}"))
        for po_path in po_files:
            n += 1
            if not any(not v["meaning"] for v in term_registry.values()):
                break
            rel = po_path.relative_to(repo_path)
            self.stdout.write(f"  [{n}/{total}] {rel} ... ", ending="")
            try:
                po_text = read_po_strings(po_path)
                if not po_text.strip():
                    self.stdout.write(self.style.WARNING("empty, skipped"))
                    continue
                count = self._define_terms(po_text, client, term_registry)
                self.stdout.write(self.style.SUCCESS(f"+{count} defined"))
            except Exception as e:  # noqa: BLE001
                self.stderr.write(self.style.ERROR(f"error: {e}"))

    # ── Main entry point ───────────────────────────────────────────────────────

    def handle(self, *args, **options):
        import magnet_dpt_doc_generator.management.commands._generate_docs.api_client as api_client_module

        if options["delay"] is not None:
            api_client_module.REQUEST_DELAY_SECONDS = options["delay"]

        repo_path = Path(settings.BASE_DIR).resolve()
        output_path = repo_path / (options["output"] or GLOSSARY_PATH)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        api_key = getattr(settings, "ANTHROPIC_API_KEY", None) or os.environ.get(
            "ANTHROPIC_API_KEY"
        )
        if not api_key:
            msg = "ANTHROPIC_API_KEY not found."
            raise CommandError(msg)
        client = anthropic.Anthropic(api_key=api_key)

        # ── Load existing terms if --update ───────────────────────────────────
        existing_terms: set[str] = set()
        existing_rows: list[str] = []
        if options["update"] and output_path.exists():
            self.stdout.write(f"Reading existing glossary: {output_path}")
            existing_terms, existing_rows = _load_existing_glossary(output_path)
            self.stdout.write(f"  {len(existing_terms)} existing terms\n")

        py_files = collect_python_files(repo_path, apps=options["apps"])
        po_files = collect_po_files(repo_path, apps=options["apps"])
        self.stdout.write(
            f"Apps: {', '.join(options['apps'])} "
            f"({len(py_files)} .py, {len(po_files)} .po files)\n"
        )

        # ── Phase 1: collect term names ───────────────────────────────────────
        self.stdout.write("\nPhase 1: collecting term names...\n")
        term_registry = self._phase1(
            py_files, po_files, repo_path, client, existing_terms
        )
        self.stdout.write(
            self.style.SUCCESS(f"  → {len(term_registry)} new terms found\n")
        )

        # ── Phase 2: define from code evidence ────────────────────────────────
        if term_registry:
            self.stdout.write("Phase 2: finding definitions in code...\n")
            self._phase2(py_files, po_files, repo_path, client, term_registry)
            defined = sum(1 for v in term_registry.values() if v["meaning"])
            self.stdout.write(
                self.style.SUCCESS(f"  → {defined}/{len(term_registry)} defined\n")
            )

        # ── Phase 3: infer remaining ──────────────────────────────────────────
        undefined = [v["display"] for v in term_registry.values() if not v["meaning"]]
        if undefined:
            self.stdout.write(
                f"Phase 3: inferring {len(undefined)} undefined terms...\n"
            )
            existing_glossary = "\n".join(existing_rows) or "(none yet)"
            inferred = infer_definitions(
                client, undefined, existing_glossary, self.stdout
            )
            for lower, (meaning, notes) in inferred.items():
                if lower in term_registry:
                    term_registry[lower]["meaning"] = meaning
                    term_registry[lower]["notes"] = notes
            self.stdout.write(
                self.style.SUCCESS(f"  → {len(inferred)} terms inferred\n")
            )

        # ── Write glossary ────────────────────────────────────────────────────
        seed = (
            []
            if options["update"]
            else [
                row
                for row in GLOSSARY_SEED_ROWS
                if row.split("|")[1].strip().lower() not in existing_terms
            ]
        )
        all_new_rows = [_build_row(v) for v in term_registry.values()]
        rows = sorted(
            existing_rows + seed + all_new_rows,
            key=lambda line: line.split("|")[1].strip().lower(),
        )
        if not rows:
            self.stdout.write(self.style.WARNING("\nNo terms found."))
            return

        content = GLOSSARY_HEADER + "\n".join(rows) + "\n"
        output_path.write_text(content, encoding="utf-8")
        self.stdout.write(
            self.style.SUCCESS(
                f"Glossary saved: {output_path} ({len(rows)} terms total)"
            )
        )
