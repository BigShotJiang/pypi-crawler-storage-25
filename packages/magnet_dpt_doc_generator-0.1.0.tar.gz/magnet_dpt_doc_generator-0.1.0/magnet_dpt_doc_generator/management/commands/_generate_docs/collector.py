import ast
import re

from pathlib import Path

from .config import IGNORE_DIRS
from .config import IGNORE_PATHS
from .config import INCLUDE_PATHS
from .config import MAX_CONTEXT_CHARS
from .config import SKIP_METHODS

# Minimum thresholds — avoids sending near-empty files to the model
_MIN_SOURCE_LINES = 5  # lines: skip trivially short Python files
_MIN_CONTENT_CHARS = 50  # chars: skip trivially short SRS / context docs

# Compiled regexes used by the URL-collection helpers (module-level for reuse)
_INCLUDE_RE = re.compile(r"include\(['\"]([^'\"]+)['\"]")
_PATH_RE = re.compile(
    r"""(?:re_)?path\s*\(\s*['"r]([^'"]+)['"]\s*,\s*([^\s,)]+)"""
    r"""(?:.*?name\s*=\s*['"]([^'"]+)['"])?"""
)
_METHODS_RE = re.compile(
    r"http_method_names\s*=\s*\[([^\]]+)\]"
    r"|def\s+(get|post|put|patch|delete|head)\s*\(self"
)


def _should_ignore(path: Path, repo_path: Path) -> bool:
    """
    Return True if a file should be excluded from scanning.
    INCLUDE_PATHS (relative) takes precedence over IGNORE_PATHS (bare filename or
    relative).
    """
    relative = str(path.relative_to(repo_path)).replace("\\", "/")

    # An explicit relative path in INCLUDE_PATHS always wins
    if relative in INCLUDE_PATHS:
        return False

    # Match against IGNORE_PATHS: bare filename or relative path
    for rule in IGNORE_PATHS:
        if "/" in rule:
            if relative == rule:
                return True
        elif path.name == rule:
            return True

    return False


def strip_skip_methods(source: str) -> str:
    """Remove methods listed in SKIP_METHODS from source before sending to Claude."""
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return source

    lines = source.splitlines(keepends=True)
    ranges_to_remove: list[tuple[int, int]] = []

    for node in ast.walk(tree):
        if (
            isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef)
            and node.name in SKIP_METHODS
        ):
            ranges_to_remove.append((node.lineno, node.end_lineno))

    if not ranges_to_remove:
        return source

    skip_lines: set[int] = set()
    for start, end in ranges_to_remove:
        skip_lines.update(range(start, end + 1))

    return "".join(line for i, line in enumerate(lines, start=1) if i not in skip_lines)


def collect_python_files(repo_path: Path, apps: list[str] | None = None) -> list[Path]:
    """
    Collect relevant Python files. If apps are given, restrict search to those
    directories.
    """
    search_roots = [repo_path / app for app in apps] if apps else [repo_path]
    files = []
    for root in search_roots:
        if not root.exists():
            continue
        for path in sorted(root.rglob("*.py")):
            if any(part in IGNORE_DIRS for part in path.parts):
                continue
            if _should_ignore(path, repo_path):
                continue

            relative = str(path.relative_to(repo_path)).replace("\\", "/")
            force_include = relative in INCLUDE_PATHS

            try:
                content = path.read_text(encoding="utf-8", errors="ignore")
                if (
                    not force_include
                    and len(content.strip().splitlines()) < _MIN_SOURCE_LINES
                ):
                    continue
                if force_include:
                    files.append(path)
                    continue
                tree = ast.parse(content)
                has_defs = any(
                    isinstance(
                        node,
                        ast.FunctionDef | ast.AsyncFunctionDef | ast.ClassDef,
                    )
                    for node in ast.walk(tree)
                )
                if has_defs:
                    files.append(path)
            except SyntaxError:
                pass
    return files


def collect_po_files(repo_path: Path, apps: list[str] | None = None) -> list[Path]:
    """Collect .po localization files within the given apps (or the whole repo)."""
    search_roots = [repo_path / app for app in apps] if apps else [repo_path]
    files = []
    for root in search_roots:
        if not root.exists():
            continue
        for path in sorted(root.rglob("*.po")):
            if any(part in IGNORE_DIRS for part in path.parts):
                continue
            if path.stat().st_size > 0:
                files.append(path)
    return files


def read_po_strings(path: Path) -> str:
    """
    Extract msgid/msgstr pairs from a .po file and return them as plain text.
    Only includes entries with a non-empty msgstr, since those carry real domain
    translations most likely to contain business-specific terms.
    """
    content = path.read_text(encoding="utf-8", errors="ignore")
    pattern = re.compile(r'msgid\s+"([^"]+)"\s+msgstr\s+"([^"]+)"', re.MULTILINE)
    pairs = pattern.findall(content)
    if not pairs:
        return ""
    return "\n".join(
        f'msgid: "{msgid}" → msgstr: "{msgstr}"'
        for msgid, msgstr in pairs
        if msgstr.strip()
    )


def read_file_for_doc(path: Path) -> str:
    """Read a .py file and strip SKIP_METHODS before passing it to Claude."""
    content = path.read_text(encoding="utf-8", errors="ignore")
    return strip_skip_methods(content)


def collect_srs_docs(srs_dir: Path) -> str:
    """
    Read all .md files from the SRS directory (excluding README.md) and
    concatenate them as a single reference text for BRD generation.
    Applies the same MAX_CONTEXT_CHARS limit to avoid exceeding model context.
    """
    snippets, total_chars = [], 0
    for path in sorted(srs_dir.rglob("*.md")):
        if path.name == "README.md":
            continue
        try:
            content = path.read_text(encoding="utf-8", errors="ignore")
            if len(content.strip()) < _MIN_CONTENT_CHARS:
                continue
            snippet = f"### {path.relative_to(srs_dir)}\n\n{content}"
            if total_chars + len(snippet) > MAX_CONTEXT_CHARS:
                snippets.append("_(SRS context truncated due to size limit)_")
                break
            snippets.append(snippet)
            total_chars += len(snippet)
        except OSError:
            pass
    return "\n\n---\n\n".join(snippets)


def collect_srs_index(srs_dir: Path) -> str:
    """
    Return a flat list of SRS .md files (relative to srs_dir) for use in BRD prompts.
    Claude uses this list to produce accurate cross-reference links.
    """
    paths = sorted(
        p
        for p in srs_dir.rglob("*.md")
        if p.name != "README.md" and p.stat().st_size > _MIN_CONTENT_CHARS
    )
    return "\n".join(str(p.relative_to(srs_dir)) for p in paths)


def collect_context_files(repo_path: Path, context_dirs: list[str]) -> str:
    """
    Read Python files from the given directories and concatenate them as reference
    text for the prompt. They are not documented — only used as context.
    """
    snippets, total_chars = [], 0
    for dir_name in context_dirs:
        dir_path = repo_path / dir_name
        if not dir_path.exists():
            continue
        for path in sorted(dir_path.rglob("*.py")):
            if any(part in IGNORE_DIRS for part in path.parts):
                continue
            if _should_ignore(path, repo_path):
                continue
            try:
                content = path.read_text(encoding="utf-8", errors="ignore")
                if len(content.strip()) < _MIN_CONTENT_CHARS:
                    continue
                snippet = (
                    f"### {path.relative_to(repo_path)}\n```python\n{content}\n```"
                )
                if total_chars + len(snippet) > MAX_CONTEXT_CHARS:
                    snippets.append(
                        "_(additional context truncated due to size limit)_"
                    )
                    break
                snippets.append(snippet)
                total_chars += len(snippet)
            except OSError:
                pass
    return "\n\n".join(snippets)


def _find_view_file(repo_path: Path, view_ref: str) -> Path | None:
    """
    Resolve a dotted view reference like 'generation.views.MyView' to a file path.
    Tries from longest to shortest path segment.
    """
    parts = view_ref.strip().split(".")
    for i in range(len(parts), 0, -1):
        candidate = repo_path / Path(*parts[:i]).with_suffix(".py")
        if candidate.exists():
            return candidate
        # Also try as a package: generation/views/ directory
        candidate_dir = repo_path / Path(*parts[:i])
        if candidate_dir.is_dir():
            # Look for views/__init__.py or views/something.py matching next part
            if i < len(parts):
                sub = candidate_dir / f"{parts[i]}.py"
                if sub.exists():
                    return sub
            init = candidate_dir / "__init__.py"
            if init.exists():
                return init
    return None


def _infer_methods(repo_path: Path, view_ref: str) -> set[str]:
    """Infer HTTP methods for a view reference by reading its source file."""
    view_file = _find_view_file(repo_path, view_ref)
    if not view_file:
        return set()
    try:
        source = view_file.read_text(encoding="utf-8", errors="ignore")
        found: set[str] = set()
        for m in _METHODS_RE.finditer(source):
            if m.group(1):
                for method in re.findall(r"'(\w+)'", m.group(1)):
                    found.add(method.upper())
            elif m.group(2):
                found.add(m.group(2).upper())
    except OSError:
        return set()
    else:
        return found


def _read_urls(
    repo_path: Path,
    file_path: Path,
    prefix: str = "",
    app_dir: Path | None = None,
) -> list[dict]:
    """Recursively parse a urls.py file and return a flat list of URL entries."""
    if not file_path.exists():
        return []
    try:
        source = file_path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return []

    current_app_dir = file_path.parent if app_dir is None else app_dir
    results = []

    for module_path in _INCLUDE_RE.findall(source):
        candidate = repo_path / module_path.replace(".", "/").rstrip("/")
        if not candidate.suffix:
            candidate = candidate.with_suffix(".py")
        if candidate.exists():
            inc_prefix_match = re.search(
                rf"""path\s*\(\s*['"](.*?)['"]\s*,\s*include\s*\(\s*['"]"""
                f"""{re.escape(module_path)}""",
                source,
            )
            inc_prefix = inc_prefix_match.group(1) if inc_prefix_match else ""
            results.extend(
                _read_urls(repo_path, candidate, prefix + inc_prefix, candidate.parent)
            )

    for m in _PATH_RE.finditer(source):
        url_pattern = m.group(1)
        view_ref = m.group(2)
        url_name = m.group(3) or ""
        full_pattern = "/" + (prefix + url_pattern).lstrip("/")
        methods = _infer_methods(repo_path, view_ref)
        results.append(
            {
                "pattern": full_pattern,
                "view_ref": view_ref,
                "url_name": url_name,
                "methods": methods,
                "app_dir": current_app_dir,
            }
        )

    return results


def _find_matching_templates(templates_dir: Path, url_name: str) -> list[str]:
    """Find HTML template filenames in templates_dir that reference url_name."""
    url_tag_re = re.compile(
        r"""{%[-\s]*url\s+['"]""" + re.escape(url_name) + r"""['"]"""
    )
    matching: list[str] = []
    for html_path in templates_dir.rglob("*.html"):
        try:
            if url_tag_re.search(
                html_path.read_text(encoding="utf-8", errors="ignore")
            ):
                matching.append(html_path.name)
        except OSError:
            pass
    return matching


def _find_view_classes(
    views_locations: list[Path], matching_templates: list[str]
) -> list[str]:
    """Find view class names whose template_name matches one of matching_templates."""
    template_name_re = re.compile(
        r"""template_name\s*=\s*['"][^'"]*?([^/'"]+\.html)['"]"""
    )
    view_classes: list[str] = []
    for loc in views_locations:
        candidates = (
            [loc]
            if loc.suffix == ".py" and loc.exists()
            else (list(loc.rglob("*.py")) if loc.is_dir() else [])
        )
        for vpath in candidates:
            try:
                source = vpath.read_text(encoding="utf-8", errors="ignore")
                for m in template_name_re.finditer(source):
                    if m.group(1) in matching_templates:
                        prefix_source = source[: m.start()]
                        class_match = re.findall(r"class\s+(\w+)", prefix_source)
                        if class_match:
                            view_classes.append(class_match[-1])
            except OSError:
                pass
    return view_classes


def _resolve_form_url(
    repo_path: Path,
    app_dir: Path,
    url_name: str,
    all_urls: list[dict],
) -> str | None:
    """
    Given a POST url name, walk the chain:
      url_name → templates/*.html with {% url 'url_name' %} →
      view with template_name matching that html → GET url for that view

    Returns the GET url pattern string if found, otherwise None.
    """
    templates_dir = app_dir / "templates"
    if not templates_dir.exists():
        return None

    matching_templates = _find_matching_templates(templates_dir, url_name)
    if not matching_templates:
        return None

    views_locations = [app_dir / "views.py", app_dir / "views"]
    view_classes = _find_view_classes(views_locations, matching_templates)
    if not view_classes:
        return None

    for entry in all_urls:
        if "GET" in entry["methods"] and "POST" not in entry["methods"]:
            for vc in view_classes:
                if vc in entry["view_ref"]:
                    return entry["pattern"]

    return None


def collect_url_patterns(repo_path: Path, root_urls: str = "project/urls.py") -> str:
    """
    Read the root urls.py and follow include() references recursively to build
    a flat list of URL patterns across the project.

    For POST-only urls, attempts to resolve the GET url of the form page that
    submits to them, following the chain:
      url name → template {% url %} tag → view template_name → GET url

    Returns a plain-text summary suitable for injection into a prompt.
    Only reads files — does not import or execute any Django code.
    """
    root_path = repo_path / root_urls
    if not root_path.exists():
        return ""

    all_urls = _read_urls(repo_path, root_path)
    if not all_urls:
        return ""

    lines = []
    for entry in all_urls:
        methods = entry["methods"]
        pattern = entry["pattern"]
        view_ref = entry["view_ref"]
        methods_str = f"[{', '.join(sorted(methods))}]" if methods else ""

        form_url = None
        if methods == {"POST"} and entry["url_name"]:
            form_url = _resolve_form_url(
                repo_path, entry["app_dir"], entry["url_name"], all_urls
            )

        if form_url:
            lines.append(
                f"{pattern:<50}  {view_ref:<45}  {methods_str}  (form at: {form_url})"
            )
        else:
            lines.append(f"{pattern:<50}  {view_ref:<45}  {methods_str}")

    header = f"{'URL Pattern':<50}  {'View':<45}  Methods\n" + "-" * 110
    return header + "\n" + "\n".join(lines)
