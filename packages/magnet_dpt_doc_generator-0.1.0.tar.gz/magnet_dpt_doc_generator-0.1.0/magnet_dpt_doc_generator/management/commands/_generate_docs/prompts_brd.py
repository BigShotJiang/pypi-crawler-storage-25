# Prompts are intentionally written in Spanish — they are sent directly to Claude.

BRD_SYSTEM_PROMPT = """Eres un analista de negocios experto en documentar
requerimientos de software.
Tu audiencia es el cliente del proyecto, no desarrolladores técnicos.
Escribes en español, en lenguaje claro y sin jerga técnica.
Describes QUÉ hace el sistema y POR QUÉ, nunca CÓMO está implementado.
Nunca menciones clases, métodos, modelos, queries, APIs ni código.
Usas diagramas Mermaid (flowchart) cuando ayudan a ilustrar un flujo de negocio."""

BRD_DISCOVER_PROMPT = """A continuación encontrarás la documentación técnica (SRS) de
un sistema de software.

Tu tarea es identificar los flujos de negocio relevantes que debería documentar un BRD
(Business Requirements Document) orientado al cliente.

Un flujo de negocio es una secuencia de pasos que el sistema realiza para cumplir
un objetivo de negocio concreto. No es una función ni una clase — es algo que
el cliente reconocería como una capacidad del sistema.

Ejemplos de buenos flujos:
- "Extracción de datos desde Acceso Abierto"
- "Asignación automática de comuna a una subestación"
- "Generación de reporte de generación mensual"

Documentación SRS:
{srs_content}

{glossary_section}

Responde SOLO con una lista Markdown numerada de flujos de negocio propuestos.
Para cada flujo incluye: nombre (negrita) y una oración describiendo su propósito.
Sin texto adicional antes ni después de la lista."""

# Shared section template used in BRD_FLOW_PROMPT and RFC prompts
_BRD_FLOW_SECTIONS = """
## Descripción del flujo
Explica en 2-4 párrafos qué hace este flujo y cuál es su valor para el negocio.
Incluye un diagrama Mermaid flowchart que muestre los pasos principales.

## Actores involucrados
Lista quién o qué participa en este flujo (usuarios, sistemas externos, el propio
sistema).

## Precondiciones
Qué debe ser verdad antes de que este flujo pueda ejecutarse.

## Postcondiciones
Qué garantiza el sistema una vez que el flujo se completa exitosamente.

## Reglas de negocio
Lista numerada de las reglas que el sistema aplica durante este flujo.
Escríbelas como afirmaciones concretas ("El sistema asigna X cuando Y").

## Fuentes de datos externas
Si este flujo obtiene datos desde portales, APIs o servicios externos al sistema,
lista cada fuente con: nombre, URL o dominio, y qué información se obtiene de ella.
Si el flujo no usa fuentes externas, omite esta sección.

## Flujos alternativos y excepciones
Qué sucede cuando algo no va según lo esperado."""

BRD_FLOW_PROMPT = """A continuación encontrarás la documentación técnica (SRS) de un
sistema de software.

Genera la documentación BRD para el siguiente flujo de negocio:
**{{flow_name}}**
{description_hint}
El documento debe estar escrito para el cliente del proyecto (no para desarrolladores)
y debe incluir exactamente estas secciones:
{sections}

## Endpoints relacionados
Usando la lista de URLs del proyecto, incluye solo los endpoints relevantes para este
flujo.
Para cada uno indica: método HTTP, URL y una descripción breve de para qué sirve.
Si no hay URLs claramente relacionadas con este flujo, omite la sección.

## Referencias técnicas (SRS)
Lista los archivos del SRS que documentan los módulos involucrados en este flujo.
Usa el índice de archivos SRS disponibles para construir los links con esta sintaxis
exacta, uno por línea como lista de bullets:
- [nombre descriptivo](../SRS/ruta/al/archivo.md)
- [otro nombre](../SRS/otra/ruta.md)
Solo incluye archivos que sean directamente relevantes para este flujo.

Documentación SRS de referencia:
{{srs_content}}

{{url_section}}{{glossary_section}}{{srs_index_section}}
Responde SOLO con el contenido Markdown, comenzando directamente con el título del
flujo.""".format(
    sections=_BRD_FLOW_SECTIONS,
    description_hint="{description_hint}",
)

SRS_INDEX_SECTION = """
---
Índice de archivos SRS disponibles para referencias (usa estas rutas en los links):

{srs_index}
---
"""

DESCRIPTION_HINT = (
    "\nDescripción del flujo (proporcionada por el usuario): {description}\n"
)

URL_SECTION = """
---
URLs del proyecto (para la sección "Endpoints relacionados"):

{url_patterns}

Instrucciones para usar esta lista:
- Muestra solo las URLs que el usuario final navegaría directamente en su navegador.
- Si un flujo implica enviar un formulario (POST), muestra la URL GET de la página
  que contiene ese formulario, no la URL POST que lo procesa.
- Si solo existe la URL POST sin una URL GET relacionada, omítela — no es navegable.
- Describe cada URL en lenguaje de negocio: qué ve o puede hacer el usuario ahí,
  no qué hace técnicamente el servidor.
---
"""

BRD_INDEX_PROMPT = """Genera un README de índice para el BRD (Business Requirements
Document) de este proyecto.

Incluye:
1. Título y descripción general del sistema en lenguaje de negocio (2-3 párrafos)
2. Lista de flujos documentados con una oración descriptiva de cada uno
3. Instrucciones breves sobre cómo leer este documento

Flujos documentados:
{flow_list}

{glossary_section}

Responde SOLO con el contenido Markdown."""

RFC_TRIAGE_PROMPT = """Eres un analista de negocios revisando un cambio solicitado por
el cliente.

A continuación tienes:
1. Un RFC (Request for Change) del cliente
2. La lista de documentos BRD existentes con su contenido

Tu tarea es determinar:
- Qué documentos BRD existentes deben actualizarse para reflejar el cambio
- Si el RFC introduce funcionalidades completamente nuevas que requieren crear un BRD
nuevo

RFC:
{rfc_content}

Documentos BRD existentes:
{brd_summaries}

Responde SOLO con un objeto JSON con este formato exacto, sin texto adicional:
{{
  "update": ["nombre_archivo_1.md", "nombre_archivo_2.md"],
  "create": ["Nombre del flujo nuevo 1", "Nombre del flujo nuevo 2"],
  "reason": "Explicación breve de cada decisión"
}}

Usa "update" para BRDs existentes que deben modificarse.
Usa "create" con el nombre del flujo (no un filename) para funcionalidades nuevas sin
BRD.
Si no hay cambios en ninguna categoría, deja la lista vacía."""

RFC_UPDATE_PROMPT = """Eres un analista de negocios actualizando documentación BRD.

El cliente ha solicitado el siguiente cambio (RFC):
{rfc_content}

El documento BRD actual que debes actualizar es:
{brd_content}

Actualiza el documento para reflejar el cambio solicitado. Mantén:
- El mismo formato y estructura de secciones
- El tono y nivel de detalle existente
- Todas las secciones no afectadas por el RFC intactas

Solo modifica lo que el RFC indica que cambió.

{glossary_section}

Responde SOLO con el contenido Markdown completo del documento actualizado."""

RFC_CREATE_PROMPT = f"""Eres un analista de negocios creando documentación BRD para una
funcionalidad nueva.

El cliente ha solicitado la siguiente funcionalidad mediante este RFC:
{{rfc_content}}

Crea la documentación BRD para el siguiente flujo de negocio nuevo:
**{{flow_name}}**

El documento debe estar escrito para el cliente del proyecto (no para desarrolladores)
y debe incluir exactamente estas secciones:
{_BRD_FLOW_SECTIONS}

{{glossary_section}}

Responde SOLO con el contenido Markdown, comenzando directamente con el título del
flujo."""
