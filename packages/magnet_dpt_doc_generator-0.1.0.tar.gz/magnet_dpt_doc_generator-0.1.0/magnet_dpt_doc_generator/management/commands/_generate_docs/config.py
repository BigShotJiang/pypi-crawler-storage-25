# All settings can be overridden in your Django settings.py using the
# MAGNET_DPT_ prefix. For example:
#
#   MAGNET_DPT_DOCS_OUTPUT_DIR = "my_project/docs/SRS"
#   MAGNET_DPT_MODEL = "claude-opus-4-20250514"
#   MAGNET_DPT_IGNORE_DIRS = ["__pycache__", ".git", "migrations"]
#
# List values (IGNORE_DIRS, IGNORE_PATHS, INCLUDE_PATHS, SKIP_METHODS) must be
# provided as lists or sets in settings.py — they are converted to sets
# internally.

from django.conf import settings

# ── Output paths ──────────────────────────────────────────────────────────────
# Relative to BASE_DIR (project root, where manage.py lives)

DOCS_OUTPUT_DIR: str = getattr(settings, "MAGNET_DPT_DOCS_OUTPUT_DIR", "docs/SRS")
GLOSSARY_PATH: str = getattr(settings, "MAGNET_DPT_GLOSSARY_PATH", "docs/GLOSSARY.md")
BRD_OUTPUT_DIR: str = getattr(settings, "MAGNET_DPT_BRD_OUTPUT_DIR", "docs/BRD")

# ── Directories and files to ignore when scanning the repo ───────────────────
# IGNORE_DIRS: directory names (matched against any part of the path)
# IGNORE_PATHS: either a bare filename (e.g. "urls.py" — ignored everywhere)
#               or a relative path (e.g. "myapp/urls.py" — ignored only there).
#               To keep a specific file that would otherwise be ignored by a
#               bare filename rule, add it to INCLUDE_PATHS — it takes
#               precedence over IGNORE_PATHS.

IGNORE_DIRS: set[str] = set(
    getattr(
        settings,
        "MAGNET_DPT_IGNORE_DIRS",
        {"__pycache__", ".git", ".venv", "venv", "node_modules", "migrations", "tests"},
    )
)

IGNORE_PATHS: set[str] = set(
    getattr(
        settings,
        "MAGNET_DPT_IGNORE_PATHS",
        {
            "manage.py",
            "wsgi.py",
            "asgi.py",
            "settings.py",
            "admin.py",
            "apps.py",
            "tests.py",
            "urls.py",
            "fixtures.py",
            "forms.py",
            "managers.py",
        },
    )
)

INCLUDE_PATHS: set[str] = set(
    getattr(settings, "MAGNET_DPT_INCLUDE_PATHS", set())
)

# Methods not worth documenting because they are well-known Python or Django
# conventions. Add or remove entries to match your preferences.
SKIP_METHODS: set[str] = set(
    getattr(
        settings,
        "MAGNET_DPT_SKIP_METHODS",
        {
            # Python standard
            "__str__",
            "__repr__",
            "__eq__",
            "__hash__",
            "__len__",
            "__init__",
            "__new__",
            "__del__",
            "__enter__",
            "__exit__",
            # Django standard
            "get_absolute_url",
            "save",
            "delete",
            "clean",
            "full_clean",
            "get_queryset",
            "get_context_data",
            "get_form_kwargs",
            "get_success_url",
            "get_object",
        },
    )
)

# ── Model and API limits ──────────────────────────────────────────────────────

MODEL: str = getattr(settings, "MAGNET_DPT_MODEL", "claude-sonnet-4-20250514")
MAX_TOKENS: int = getattr(settings, "MAGNET_DPT_MAX_TOKENS", 4096)
MAX_CONTEXT_CHARS: int = getattr(settings, "MAGNET_DPT_MAX_CONTEXT_CHARS", 40_000)

# ── Rate limiting ─────────────────────────────────────────────────────────────
# Free tier:     ~15-20s  (10k tokens/min limit)
# Build tier:    ~2-3s
# Higher tiers:  0

REQUEST_DELAY_SECONDS: int = getattr(settings, "MAGNET_DPT_REQUEST_DELAY_SECONDS", 15)
MAX_RETRIES: int = getattr(settings, "MAGNET_DPT_MAX_RETRIES", 3)
RETRY_BACKOFF: int = getattr(
    settings,
    "MAGNET_DPT_RETRY_BACKOFF",
    60,  # base wait in seconds per retry attempt (multiplied by attempt number)
)
