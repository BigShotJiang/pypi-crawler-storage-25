# Re-exports all prompts from their respective modules.
# Import from here to avoid changing existing code.

from .prompts_brd import BRD_DISCOVER_PROMPT
from .prompts_brd import BRD_FLOW_PROMPT
from .prompts_brd import BRD_INDEX_PROMPT
from .prompts_brd import BRD_SYSTEM_PROMPT
from .prompts_brd import DESCRIPTION_HINT
from .prompts_brd import RFC_CREATE_PROMPT
from .prompts_brd import RFC_TRIAGE_PROMPT
from .prompts_brd import RFC_UPDATE_PROMPT
from .prompts_brd import SRS_INDEX_SECTION
from .prompts_brd import URL_SECTION
from .prompts_glossary import GLOSSARY_GENERATE_PROMPT
from .prompts_srs import CONTEXT_SECTION
from .prompts_srs import FUNCTION_DOC_PROMPT
from .prompts_srs import GLOSSARY_SECTION
from .prompts_srs import INDEX_PROMPT
from .prompts_srs import SYSTEM_PROMPT

__all__ = [
    "BRD_DISCOVER_PROMPT",
    "BRD_FLOW_PROMPT",
    "BRD_INDEX_PROMPT",
    "BRD_SYSTEM_PROMPT",
    "CONTEXT_SECTION",
    "DESCRIPTION_HINT",
    "FUNCTION_DOC_PROMPT",
    "GLOSSARY_GENERATE_PROMPT",
    "GLOSSARY_SECTION",
    "INDEX_PROMPT",
    "RFC_CREATE_PROMPT",
    "RFC_TRIAGE_PROMPT",
    "RFC_UPDATE_PROMPT",
    "SRS_INDEX_SECTION",
    "SYSTEM_PROMPT",
    "URL_SECTION",
]
