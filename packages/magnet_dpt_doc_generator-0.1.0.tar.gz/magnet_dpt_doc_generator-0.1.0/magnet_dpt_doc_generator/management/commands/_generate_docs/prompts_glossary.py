# generate_docs/prompts_glossary.py
# Prompts are intentionally written in Spanish — they are sent directly to Claude.

# Legacy prompt kept for backwards compatibility (used by generate_module_doc flow).
GLOSSARY_GENERATE_PROMPT = """Analiza el siguiente código de un proyecto Django
y extrae un glosario de términos del dominio de negocio.

El glosario está dirigido a personas no técnicas que necesitan entender las reglas de \
negocio del proyecto. NO está dirigido a desarrolladores.

INCLUYE únicamente:
- Siglas y acrónimos del dominio (ej: AA, SEIA, TA, BRD, SRS)
- Nombres de entidades del negocio (ej: Subestación, Proyecto, Expediente)
- Términos específicos del sector o industria que un externo no conocería
- Conceptos de negocio que aparecen en el código pero que tienen significado fuera de él

EXCLUYE todo lo siguiente, sin excepciones:
- Variables, atributos y campos del modelo (ej: _raw_parsed_content, external_id)
- Nombres de clases, funciones y métodos Python
- Términos técnicos de Django, Python o programación en general
- Nombres de archivos, módulos o paquetes
- Cualquier identificador que solo tenga sentido dentro del código

Formato de salida: SOLO una tabla Markdown así:

| Término | Significado | Notas |
|---------|-------------|-------|
| SEIA    | Sistema de Evaluación de Impacto Ambiental | Portal gubernamental chileno |

Si no encuentras términos de negocio válidos en el código analizado, responde con una \
tabla vacía (solo el encabezado, sin filas).

Código a analizar:
{code}

Responde SOLO con la tabla Markdown, sin texto adicional."""

GLOSSARY_EXTRACT_TERMS_PROMPT = """Analiza el siguiente código Django e identifica
términos del dominio de negocio: siglas, acrónimos, entidades y conceptos sectoriales.

NO incluyas definiciones. Lista SOLO los nombres o siglas de los términos.

INCLUYE: siglas y acrónimos del dominio, entidades de negocio, términos del sector \
que un externo no conocería.
EXCLUYE: variables, clases, funciones, módulos, términos técnicos de Django o Python.

Código:
{code}

Responde SOLO con los términos, uno por línea, sin explicaciones ni tabla. \
Si no encuentras ninguno, responde con una línea vacía."""

GLOSSARY_DEFINE_TERMS_PROMPT = """Analiza el siguiente código Django. \
Tienes una lista de términos cuya definición aún se desconoce.

Define SOLO los términos para los que encuentres evidencia explícita en el código \
(comentarios, docstrings, strings literales, nombres descriptivos). \
NO inventes ni supongas definiciones. Si no hay evidencia para un término, omítelo.

Términos a definir:
{terms}

Código:
{code}

Formato de salida: SOLO una tabla Markdown con los términos que pudiste definir:
| Término | Significado | Notas |
|---------|-------------|-------|
Si no puedes definir ninguno con evidencia, responde solo con el encabezado."""

GLOSSARY_INFER_DEFINITIONS_PROMPT = """Los siguientes términos aparecen en un proyecto \
Django de gestión eléctrica pero no se encontró su definición explícita en el código.

Usando el glosario existente como contexto del dominio, infiere la definición más \
plausible para cada uno. Añade "(inferido)" en la columna Notas.

Glosario existente:
{existing_glossary}

Términos sin definición:
{terms}

Formato: SOLO una tabla Markdown:
| Término | Significado | Notas |
|---------|-------------|-------|"""
