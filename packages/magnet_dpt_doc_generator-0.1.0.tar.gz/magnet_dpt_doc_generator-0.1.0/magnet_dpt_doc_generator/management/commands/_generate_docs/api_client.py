import sys
import time

from pathlib import Path

import anthropic

from .config import MAX_RETRIES
from .config import MAX_TOKENS
from .config import MODEL
from .config import REQUEST_DELAY_SECONDS
from .config import RETRY_BACKOFF
from .prompts import CONTEXT_SECTION
from .prompts import FUNCTION_DOC_PROMPT
from .prompts import GLOSSARY_GENERATE_PROMPT
from .prompts import GLOSSARY_SECTION
from .prompts import INDEX_PROMPT
from .prompts import SYSTEM_PROMPT
from .prompts_glossary import GLOSSARY_DEFINE_TERMS_PROMPT
from .prompts_glossary import GLOSSARY_EXTRACT_TERMS_PROMPT
from .prompts_glossary import GLOSSARY_INFER_DEFINITIONS_PROMPT


def _warn(text: str) -> None:
    sys.stderr.write(text + "\n")


def _call_api(client: anthropic.Anthropic, prompt: str, stdout=None) -> str:
    """Call the API with automatic retries on rate limit errors (429)."""
    delay = REQUEST_DELAY_SECONDS
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            msg = client.messages.create(
                model=MODEL,
                max_tokens=MAX_TOKENS,
                system=SYSTEM_PROMPT,
                messages=[{"role": "user", "content": prompt}],
            )
            time.sleep(delay)
            return msg.content[0].text
        except anthropic.RateLimitError:
            if attempt == MAX_RETRIES:
                raise
            wait = RETRY_BACKOFF * attempt
            text = (
                f"Rate limit reached (attempt {attempt}/{MAX_RETRIES})."
                f" Waiting {wait}s..."
            )
            (stdout.write if stdout else _warn)(text)
            time.sleep(wait)
    return ""  # unreachable; satisfies explicit-return requirement


def generate_module_doc(
    client: anthropic.Anthropic,
    code: str,
    filename: str,
    context: str = "",
    glossary: str = "",
    stdout=None,
) -> str:
    context_section = CONTEXT_SECTION.format(context_files=context) if context else ""
    glossary_section = GLOSSARY_SECTION.format(glossary=glossary) if glossary else ""
    prompt = FUNCTION_DOC_PROMPT.format(
        filename=filename,
        code=code,
        context_section=context_section,
        glossary_section=glossary_section,
    )
    return _call_api(client, prompt, stdout)


def generate_index_doc(
    client: anthropic.Anthropic,
    documented_files: list[str],
    glossary: str = "",
    stdout=None,
) -> str:
    file_list = "\n".join(f"- {f}" for f in documented_files)
    glossary_section = GLOSSARY_SECTION.format(glossary=glossary) if glossary else ""
    return _call_api(
        client,
        INDEX_PROMPT.format(
            file_list=file_list,
            glossary_section=glossary_section,
        ),
        stdout,
    )


def generate_glossary_terms(
    client: anthropic.Anthropic,
    code: str,
    stdout=None,
) -> str:
    """Extract domain terms from a code snippet and return them as a Markdown table."""
    prompt = GLOSSARY_GENERATE_PROMPT.format(code=code)
    return _call_api(client, prompt, stdout)


def _parse_table_rows(raw: str) -> dict[str, tuple[str, str]]:
    """Parse a Markdown table into {term_lower: (meaning, notes)}."""
    result = {}
    for line in raw.splitlines():
        if (
            line.startswith("| ")
            and not line.startswith("| Término")
            and not line.startswith("|---")
        ):
            parts = [p.strip() for p in line.split("|")]
            if len(parts) >= 4 and parts[1]:  # noqa: PLR2004
                result[parts[1].lower()] = (parts[2], parts[3])
    return result


def extract_term_names(
    client: anthropic.Anthropic,
    code: str,
    stdout=None,
) -> list[str]:
    """Phase 1: extract only term names from code, without definitions."""
    raw = _call_api(client, GLOSSARY_EXTRACT_TERMS_PROMPT.format(code=code), stdout)
    return [line.strip() for line in raw.splitlines() if line.strip()]


def define_terms_from_code(
    client: anthropic.Anthropic,
    code: str,
    terms: list[str],
    stdout=None,
) -> dict[str, tuple[str, str]]:
    """Phase 2: define specific terms using only evidence found in code."""
    terms_list = "\n".join(f"- {t}" for t in terms)
    prompt = GLOSSARY_DEFINE_TERMS_PROMPT.format(terms=terms_list, code=code)
    return _parse_table_rows(_call_api(client, prompt, stdout))


def infer_definitions(
    client: anthropic.Anthropic,
    terms: list[str],
    existing_glossary: str,
    stdout=None,
) -> dict[str, tuple[str, str]]:
    """Phase 3: infer plausible definitions for terms not found in code."""
    terms_list = "\n".join(f"- {t}" for t in terms)
    prompt = GLOSSARY_INFER_DEFINITIONS_PROMPT.format(
        terms=terms_list,
        existing_glossary=existing_glossary,
    )
    return _parse_table_rows(_call_api(client, prompt, stdout))


def save_doc(output_dir: Path, relative_path: Path, content: str) -> Path:
    doc_path = output_dir / relative_path.with_suffix(".md")
    doc_path.parent.mkdir(parents=True, exist_ok=True)
    doc_path.write_text(content, encoding="utf-8")
    return doc_path
