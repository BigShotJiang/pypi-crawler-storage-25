# Prompts are intentionally written in Spanish — they are sent directly to Claude.

SYSTEM_PROMPT = """Eres un experto en documentación técnica de software para proyectos
Python/Django. Generas documentación clara, concisa y profesional en español, en formato
Markdown. Cuando sea útil, incluyes diagramas Mermaid (flowchart o sequenceDiagram) para
ilustrar flujos.
Nunca inventas comportamientos que no estén en el código."""

FUNCTION_DOC_PROMPT = """Analiza el siguiente código Python y genera documentación
técnica en Markdown.

Incluye:
1. **Propósito general** del módulo (1-2 oraciones)
2. Por cada clase pública:
   - Descripción y responsabilidad
   - Atributos/campos importantes
   - Métodos públicos con sus parámetros y lo que retornan
   - Si un método tiene un flujo no trivial que el diagrama aclararía mejor que el
     texto, incluye un diagrama Mermaid (flowchart o sequenceDiagram) **inmediatamente
     debajo de la descripción de ese método**, no al final del documento.
     Omite el diagrama si el docstring o la descripción ya explican el flujo con
     claridad.
3. Por cada función pública (fuera de clases):
   - Descripción, parámetros y valor de retorno
   - Diagrama Mermaid inline si el flujo es complejo y no queda claro con texto
4. **Fuentes y servicios externos**: si el código hace llamadas a URLs externas, APIs de
   terceros, portales gubernamentales u otros servicios fuera del sistema, documéntalos
   explícitamente: URL o dominio, propósito, y qué datos se obtienen o envían.

Criterio para incluir un diagrama: ¿Le ahorra al lector tener que imaginarse el flujo?
Si la respuesta es no, omítelo.

Archivo a documentar: `{filename}`

```python
{code}
```
{glossary_section}{context_section}
Responde SOLO con el contenido Markdown, sin explicaciones adicionales."""

GLOSSARY_SECTION = """
---
Glosario del proyecto (úsalo para interpretar siglas y términos del dominio
correctamente):

{glossary}
---
"""

CONTEXT_SECTION = """
---
Código de referencia de otros módulos del proyecto (NO los documentes,
úsalos solo para entender dependencias y enriquecer la documentación del archivo
principal):

{context_files}
---
"""

INDEX_PROMPT = """Dado el siguiente índice de archivos documentados de un proyecto
Django, genera un archivo README de índice en Markdown que:
1. Tenga un título y descripción general del proyecto
2. Liste los módulos organizados por app Django
3. Incluya un diagrama Mermaid de arquitectura general con las apps y sus relaciones
4. Sea útil como punto de entrada para desarrolladores nuevos

Archivos documentados:
{file_list}

{glossary_section}
Responde SOLO con el contenido Markdown."""
