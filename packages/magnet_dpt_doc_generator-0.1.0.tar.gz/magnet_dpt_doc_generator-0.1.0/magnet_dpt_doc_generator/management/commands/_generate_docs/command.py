# Usage:
#   python manage.py generate_docs --output ./docs
#   python manage.py generate_docs --apps orders inventory --output ./docs
#   python manage.py generate_docs --apps orders --context-dirs users core \
#       --output ./docs
#   python manage.py generate_docs --only orders/views.py --output ./docs

import os

from pathlib import Path

from django.conf import settings
from django.core.management.base import BaseCommand
from django.core.management.base import CommandError

import anthropic

from .api_client import generate_index_doc
from .api_client import generate_module_doc
from .api_client import save_doc
from .collector import collect_context_files
from .collector import collect_python_files
from .collector import read_file_for_doc
from .config import DOCS_OUTPUT_DIR
from .config import GLOSSARY_PATH
from .config import REQUEST_DELAY_SECONDS


class Command(BaseCommand):
    help = (
        "Generate Markdown documentation for the project using Claude (Anthropic API)"
    )

    def add_arguments(self, parser):
        parser.add_argument(
            "--output",
            default=None,
            metavar="DIR",
            help=(
                f"Output directory for .md files"
                f" (default: {DOCS_OUTPUT_DIR}, set in config.py)"
            ),
        )
        parser.add_argument(
            "--apps",
            nargs="+",
            metavar="APP",
            help=(
                "Django apps to document."
                " Without this flag, the whole project is scanned."
            ),
        )
        parser.add_argument(
            "--context-dirs",
            nargs="+",
            metavar="DIR",
            help=(
                "Directories Claude will read as reference context"
                " without documenting them."
            ),
        )
        parser.add_argument(
            "--only",
            metavar="FILE",
            help="Document a single file (path relative to the project root).",
        )
        parser.add_argument(
            "--glossary",
            default=None,
            metavar="FILE",
            help=f"Path to GLOSSARY.md (default: {GLOSSARY_PATH}, set in config.py)",
        )
        parser.add_argument(
            "--dry-run",
            action="store_true",
            help="List files that would be documented without calling the API.",
        )
        parser.add_argument(
            "--force",
            action="store_true",
            help="Regenerate and overwrite existing .md files (skipped by default).",
        )
        parser.add_argument(
            "--delay",
            type=int,
            default=None,
            metavar="SECONDS",
            help=(
                f"Pause between API calls in seconds "
                f"(default: {REQUEST_DELAY_SECONDS}s, set in config.py). "
                "Use 0 for higher-tier plans."
            ),
        )

    def handle(self, *args, **options):
        import magnet_dpt_doc_generator.management.commands._generate_docs.api_client as api_client_module

        if options["delay"] is not None:
            api_client_module.REQUEST_DELAY_SECONDS = options["delay"]
            delay = options["delay"]
        else:
            delay = REQUEST_DELAY_SECONDS
        self.stdout.write(f"Delay between calls: {delay}s\n")

        self._repo_path = Path(settings.BASE_DIR).resolve()
        self._output_dir = self._repo_path / (options["output"] or DOCS_OUTPUT_DIR)
        self._output_dir.mkdir(parents=True, exist_ok=True)

        api_key = getattr(settings, "ANTHROPIC_API_KEY", None) or os.environ.get(
            "ANTHROPIC_API_KEY"
        )
        if not api_key:
            msg = (
                "ANTHROPIC_API_KEY not found. "
                "Define it in settings.py or as an environment variable."
            )
            raise CommandError(msg)
        self._client = anthropic.Anthropic(api_key=api_key)

        self._glossary = self._load_glossary(options)
        self._context = self._load_context(options)

        if options["only"]:
            self._handle_only(options)
            return

        self._handle_batch(options)

    def _load_glossary(self, options: dict) -> str:
        glossary_path = self._repo_path / (options["glossary"] or GLOSSARY_PATH)
        if not glossary_path.exists():
            self.stderr.write(
                self.style.WARNING(f"Glossary not found: {glossary_path}")
            )
            return ""
        glossary = glossary_path.read_text(encoding="utf-8")
        self.stdout.write(f"Glossary loaded: {glossary_path}\n")
        return glossary

    def _load_context(self, options: dict) -> str:
        if not options["context_dirs"]:
            return ""
        self.stdout.write(f"Loading context from: {', '.join(options['context_dirs'])}")
        context = collect_context_files(self._repo_path, options["context_dirs"])
        self.stdout.write(f"  {len(context):,} chars loaded\n")
        return context

    def _handle_only(self, options: dict) -> None:
        target = self._repo_path / options["only"]
        if not target.exists():
            msg = f"File not found: {target}"
            raise CommandError(msg)
        self.stdout.write(f"Documenting: {options['only']}")
        code = read_file_for_doc(target)
        doc = generate_module_doc(
            self._client,
            code,
            options["only"],
            self._context,
            self._glossary,
            self.stdout,
        )
        out = save_doc(self._output_dir, Path(options["only"]), doc)
        self.stdout.write(self.style.SUCCESS(f"Saved: {out}"))

    def _handle_batch(self, options: dict) -> None:
        if options["apps"]:
            self.stdout.write(f"Apps to document: {', '.join(options['apps'])}")
            for app in options["apps"]:
                if not (self._repo_path / app).exists():
                    self.stderr.write(self.style.WARNING(f"  App not found: {app}"))

        self.stdout.write(f"Scanning: {self._repo_path}")
        files = collect_python_files(self._repo_path, apps=options["apps"])
        self.stdout.write(f"{len(files)} files to document\n")

        if options["dry_run"]:
            self._dry_run(files, options)
            return

        skipped, documented = self._document_files(files, options)

        if skipped:
            self.stdout.write(
                self.style.WARNING(
                    f"\n{len(skipped)} file(s) skipped (already exist)."
                    " Use --force to regenerate."
                )
            )

        self.stdout.write("\nGenerating index...")
        index_content = generate_index_doc(
            self._client, documented, self._glossary, self.stdout
        )
        index_path = self._output_dir / "README.md"
        index_path.write_text(index_content, encoding="utf-8")
        self.stdout.write(self.style.SUCCESS(f"Index saved: {index_path}"))
        self.stdout.write(self.style.SUCCESS(f"Done. Output: {self._output_dir}"))

    def _dry_run(self, files: list[Path], options: dict) -> None:
        for file_path in files:
            relative = file_path.relative_to(self._repo_path)
            doc_path = self._output_dir / relative.with_suffix(".md")
            if doc_path.exists() and not options["force"]:
                self.stdout.write(
                    f"  {relative}  "
                    + self.style.WARNING("(already exists, would skip)")
                )
            else:
                self.stdout.write(f"  {relative}")
        self.stdout.write(f"\nTotal: {len(files)} files. (dry-run, API not called)")

    def _document_files(
        self, files: list[Path], options: dict
    ) -> tuple[list[str], list[str]]:
        skipped: list[str] = []
        documented: list[str] = []
        for i, file_path in enumerate(files, 1):
            relative = file_path.relative_to(self._repo_path)
            doc_path = self._output_dir / relative.with_suffix(".md")

            if doc_path.exists() and not options["force"]:
                skipped.append(str(relative))
                self.stdout.write(
                    f"[{i}/{len(files)}] {relative} ... "
                    + self.style.WARNING("skipped")
                )
                continue

            self.stdout.write(f"[{i}/{len(files)}] {relative} ... ", ending="")
            try:
                code = read_file_for_doc(file_path)
                doc = generate_module_doc(
                    self._client,
                    code,
                    str(relative),
                    self._context,
                    self._glossary,
                    self.stdout,
                )
                save_doc(self._output_dir, relative, doc)
                documented.append(str(relative))
                self.stdout.write(self.style.SUCCESS("done"))
            except (OSError, anthropic.APIError) as e:
                self.stderr.write(self.style.ERROR(f"error: {e}"))
        return skipped, documented
