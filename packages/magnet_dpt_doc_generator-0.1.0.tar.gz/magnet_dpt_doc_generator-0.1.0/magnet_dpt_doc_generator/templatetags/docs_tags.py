from django import template

register = template.Library()


@register.filter
def startswith(value: str, prefix: str) -> bool:
    return str(value).startswith(prefix)


@register.filter
def removesuffix(value: str, suffix: str) -> str:
    return str(value).removesuffix(suffix)


@register.filter
def removeprefix(value: str, prefix: str) -> str:
    return str(value).removeprefix(prefix)
