from __future__ import annotations

import re

from pathlib import Path

from django.conf import settings
from django.http import Http404

import markdown

from base.views.generic import BaseTemplateView
from base.views.mixins import StaffRestrictedMixin

# ── Configuration ─────────────────────────────────────────────────────────────

DOCS_ROOT = Path(settings.BASE_DIR) / "docs"

# Sections shown in the sidebar, in order.
# Each entry maps a display label to a path relative to DOCS_ROOT.
SECTIONS: list[tuple[str, str]] = [
    ("Glosario", "GLOSSARY.md"),
    ("BRD", "BRD"),
    ("RFC", "rfc"),
    ("SRS", "SRS"),
]

MARKDOWN_EXTENSIONS = [
    "extra",  # tables, fenced code blocks, footnotes
    "toc",  # generates [TOC] and heading anchors
    "codehilite",  # syntax highlighting
    "sane_lists",
]

# ── Helpers ───────────────────────────────────────────────────────────────────


def _render_md(text: str) -> str:
    """Convert Markdown text to HTML."""
    # Convert ```mermaid fenced blocks to <div class="mermaid"> before the
    # Markdown renderer (codehilite) strips the language hint and wraps them
    # in <pre><code>, which Mermaid.js cannot pick up.
    text = re.sub(
        r"```mermaid\n(.*?)```",
        lambda m: f'<div class="mermaid">\n{m.group(1)}</div>',
        text,
        flags=re.DOTALL,
    )
    return markdown.markdown(text, extensions=MARKDOWN_EXTENSIONS)


def _rewrite_md_links(html: str, current_path: str) -> str:
    """
    Rewrite relative .md links in rendered HTML so they point to the
    docs_viewer URL instead of raw files.
    e.g. href="../SRS/foo.md"  →  href="/docs/SRS/foo/"
    """

    def _replace(m: re.Match) -> str:
        href = m.group(1)
        if href.startswith("http") or not href.endswith(".md"):
            return m.group(0)
        base = (Path("docs") / current_path).parent
        resolved = (base / href).resolve().relative_to(Path("docs").resolve())
        clean = str(resolved).removesuffix(".md")
        return f'href="/docs/{clean}/"'

    return re.sub(r'href="([^"]+)"', _replace, html)


def _build_tree(directory: Path, base: Path) -> list[dict]:
    """Recursively build a navigation tree for a directory."""
    items = []
    try:
        entries = sorted(
            directory.iterdir(),
            key=lambda p: (p.is_file(), p.name.lower()),
        )
    except PermissionError:
        return items

    for entry in entries:
        if entry.name.startswith("."):
            continue
        rel = entry.relative_to(base)
        if entry.is_dir():
            has_readme = (entry / "README.md").is_file() or (
                entry / "index.md"
            ).is_file()
            items.append(
                {
                    "label": entry.name,
                    "url": f"/docs/{rel}/" if has_readme else None,
                    "children": _build_tree(entry, base),
                    "is_dir": True,
                }
            )
        elif entry.suffix == ".md" and entry.name != "README.md":
            items.append(
                {
                    "label": entry.stem.replace("_", " ").title(),
                    "url": f"/docs/{str(rel).removesuffix('.md')}/",
                    "children": [],
                    "is_dir": False,
                }
            )
    return items


def _sidebar(active_path: str) -> list[dict]:
    """Build the full sidebar structure."""
    sections = []
    for label, rel_path in SECTIONS:
        full_path = DOCS_ROOT / rel_path
        if not full_path.exists():
            continue
        if full_path.is_file():
            url = f"/docs/{rel_path.removesuffix('.md')}/"
            sections.append(
                {
                    "label": label,
                    "url": url,
                    "children": [],
                    "is_dir": False,
                    "active": active_path == rel_path.removesuffix(".md"),
                }
            )
        else:
            sections.append(
                {
                    "label": label,
                    "url": f"/docs/{rel_path}/",
                    "children": _build_tree(full_path, DOCS_ROOT),
                    "is_dir": True,
                    "active": active_path.startswith(rel_path),
                }
            )
    return sections


# ── Views ─────────────────────────────────────────────────────────────────────


class DocsIndexView(StaffRestrictedMixin, BaseTemplateView):
    template_name = "docs_viewer/page.html"
    title = "Documentation"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context.update(
            {
                "sidebar": _sidebar(""),
                "content": "<p>Select a document from the sidebar.</p>",
                "title": self.title,
                "breadcrumbs": [],
                "doc_path": "",
            }
        )
        return context


class DocsPageView(StaffRestrictedMixin, BaseTemplateView):
    template_name = "docs_viewer/page.html"

    def get_context_data(self, **kwargs):
        doc_path = self.kwargs.get("doc_path", "").strip("/")
        self.title = doc_path
        context = super().get_context_data(**kwargs)

        # Prevent path traversal
        rel = Path(doc_path)
        if ".." in rel.parts:
            raise Http404

        full_path = DOCS_ROOT / rel
        candidates = [
            full_path.with_suffix(".md"),
            full_path / "README.md",
            full_path / "index.md",
        ]
        md_file = next((p for p in candidates if p.is_file()), None)
        if md_file is None:
            raise Http404

        raw = md_file.read_text(encoding="utf-8")
        html = _render_md(raw)
        md_rel = str(md_file.relative_to(DOCS_ROOT))
        html = _rewrite_md_links(html, md_rel)

        # Breadcrumbs
        parts = rel.parts
        breadcrumbs = [
            {
                "label": part.replace("_", " ").title(),
                "url": f"/docs/{'/'.join(parts[: i + 1])}/",
            }
            for i, part in enumerate(parts)
        ]

        title = parts[-1].replace("_", " ").title() if parts else "Documentation"

        context.update(
            {
                "sidebar": _sidebar(doc_path),
                "content": html,
                "title": title,
                "breadcrumbs": breadcrumbs,
                "doc_path": doc_path,
            }
        )
        return context
