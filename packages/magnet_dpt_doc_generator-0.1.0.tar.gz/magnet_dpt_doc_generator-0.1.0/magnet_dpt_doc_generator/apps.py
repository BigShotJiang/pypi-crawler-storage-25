from django.apps import AppConfig
from django.utils.translation import gettext_lazy as _


class DocsViewerConfig(AppConfig):
    name = "magnet_dpt_doc_generator"
    label = "docs_viewer"
    verbose_name = _("docs_viewer")
