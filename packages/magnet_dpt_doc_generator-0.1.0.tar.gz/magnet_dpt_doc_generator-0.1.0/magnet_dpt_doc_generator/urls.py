from django.urls import path
from django.urls import re_path

from .views import DocsIndexView
from .views import DocsPageView

app_name = "docs_viewer"

urlpatterns = [
    path("", DocsIndexView.as_view(), name="docs_index"),
    re_path(r"^(?P<doc_path>.+)/$", DocsPageView.as_view(), name="document_page"),
]
