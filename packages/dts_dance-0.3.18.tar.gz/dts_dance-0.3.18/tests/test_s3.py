import os
from dtsdance.s3 import S3Client
from config import ConfigLoader

# 从配置文件加载 S3 配置
config_loader = ConfigLoader.get_instance()
config_loader.load_from_file()
s3_config = config_loader.get_s3_config()

s3_client = S3Client(
    access_key=s3_config.access_key,
    secret_key=s3_config.secret_key,
    endpoint=s3_config.endpoint,
    region=s3_config.region,
    bucket=s3_config.bucket,
    base_url=s3_config.base_url,
)


# pytest tests/test_s3.py::test_list_objects -s
def test_list_objects():
    result = s3_client.list_objects()
    print(f"Objects: {result}")


# pytest tests/test_s3.py::test_upload_and_download -s
def test_upload_and_download():
    # 创建测试文件
    test_file = "/tmp/test_s3_upload.txt"
    with open(test_file, "w") as f:
        f.write("test content")

    # 上传
    url = s3_client.upload_file(test_file, "test_upload.txt")
    print(f"Uploaded: {url}")

    # 下载
    download_path = "/tmp/test_s3_download.txt"
    success = s3_client.download_file("test_upload.txt", download_path)
    print(f"Download success: {success}")

    # 验证
    if success:
        with open(download_path) as f:
            content = f.read()
        print(f"Downloaded content: {content}")

    # 清理
    os.remove(test_file)
    if os.path.exists(download_path):
        os.remove(download_path)
