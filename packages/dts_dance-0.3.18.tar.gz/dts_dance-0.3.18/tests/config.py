import os
import yaml
from dataclasses import dataclass
from dtsdance.bytecloud import SiteConfig


@dataclass
class MetricsFEEnvConfig:
    """Metrics FE 环境配置"""

    name: str
    endpoint: str
    ak: str
    sk: str


@dataclass
class S3Config:
    """S3 配置"""

    access_key: str
    secret_key: str
    endpoint: str
    base_url: str
    bucket: str
    region: str


@dataclass
class DSyncerConfig:
    """DSyncer 配置"""

    secret_api_token: str


class ConfigLoader:

    _instance: "ConfigLoader | None" = None

    def __init__(self):
        self._site_configs: dict[str, SiteConfig] = {}
        self._s3_config: S3Config | None = None
        self._metrics_fe_configs: list[MetricsFEEnvConfig] = []
        self._dsyncer_config: DSyncerConfig | None = None

    @classmethod
    def get_instance(cls) -> "ConfigLoader":
        """获取单例实例"""
        if cls._instance is None:
            cls._instance = cls()

        return cls._instance

    def load_from_file(self, sites: list[str] | None = None) -> None:
        """从配置文件加载配置"""
        config_path = os.environ.get("CONFIG_PATH", "config.yaml")

        try:
            with open(config_path, encoding="utf-8") as f:
                configs = yaml.safe_load(f)
        except Exception as e:
            raise ValueError(f"加载配置失败: {e}")

        self._site_configs.update(
            {
                k: SiteConfig(
                    name=k,
                    endpoint=v["endpoint"],
                    svc_account=v["svc_account"],
                    svc_secret=v["svc_secret"],
                    endpoint_spacex=v.get("endpoint_spacex", None),
                    endpoint_spacex_gw=v.get("endpoint_spacex_gw", None),
                    endpoint_spacex_bytedts=v.get("endpoint_spacex_bytedts", None),
                )
                for k, v in configs["sites"].items()
                if sites is None or k in sites
            }
        )

        # 加载 S3 配置
        if "s3" in configs:
            s3_conf = configs["s3"]
            self._s3_config = S3Config(
                access_key=s3_conf["access_key"],
                secret_key=s3_conf["secret_key"],
                endpoint=s3_conf["endpoint"],
                base_url=s3_conf["base_url"],
                bucket=s3_conf["bucket"],
                region=s3_conf.get("region", ""),
            )

        # 加载 Metrics FE 配置
        if "metrics_fe" in configs:
            metrics_fe_conf = configs["metrics_fe"]
            self._metrics_fe_configs = [
                MetricsFEEnvConfig(
                    name=env["name"],
                    endpoint=env["endpoint"],
                    ak=env["ak"],
                    sk=env["sk"],
                )
                for env in metrics_fe_conf.get("envs", [])
            ]

        # 加载 DSyncer 配置
        if "dsyncer" in configs:
            dsyncer_conf = configs["dsyncer"]
            self._dsyncer_config = DSyncerConfig(secret_api_token=dsyncer_conf["secret_api_token"])

    def get(self, site: str) -> SiteConfig:
        """获取指定站点的配置"""
        if not self._site_configs:
            raise RuntimeError("配置未加载，请先调用 load_from_file()")

        if site not in self._site_configs:
            raise KeyError(f"站点 {site} 不存在")

        return self._site_configs[site]

    def get_site_configs(self) -> dict[str, SiteConfig]:
        """获取所有配置"""
        return self._site_configs

    def get_s3_config(self) -> S3Config:
        """获取 S3 配置"""
        if not self._s3_config:
            raise RuntimeError("配置未加载，请先调用 load_from_file()")

        return self._s3_config

    def get_metrics_fe_configs(self) -> list[MetricsFEEnvConfig]:
        """获取 Metrics FE 环境配置列表"""
        return self._metrics_fe_configs

    def get_dsyncer_config(self) -> DSyncerConfig:
        """获取 DSyncer 配置"""
        if not self._dsyncer_config:
            raise RuntimeError("配置未加载，请先调用 load_from_file()")

        return self._dsyncer_config
