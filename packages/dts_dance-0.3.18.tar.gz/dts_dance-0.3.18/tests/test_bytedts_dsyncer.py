from dtsdance.bytecloud import ByteCloudClient
from config import ConfigLoader
from dtsdance.bytedts_dsyncer import DSyncerClient

loader = ConfigLoader.get_instance()
loader.load_from_file(["boe", "cn", "i18n-tt", "i18n-bd", "us-ttp"])
site_configs = loader.get_site_configs()
dsyncer_config = loader.get_dsyncer_config()
bytecloud_client = ByteCloudClient(site_configs)
dsyncer_client = DSyncerClient(dsyncer_config.secret_api_token, bytecloud_client)


# pytest tests/test_bytedts_dsyncer.py::test_get_task_info -s
def test_get_task_info():
    info = dsyncer_client.get_task_info("cn", "China-North", "1759140831119555029")
    print(f"DSyncer Info: {info}")


# pytest tests/test_bytedts_dsyncer.py::test_get_migrated_dflow_task_id -s
def test_get_migrated_dflow_task_id():
    # dflow_task_id = dsyncer_client.get_migrated_dflow_task_id("cn", "China-North", "1754290766694088737")
    # dflow_task_id = dsyncer_client.get_migrated_dflow_task_id("i18n-tt", "Singapore-Central", "1775219310168037143")
    dflow_task_id = dsyncer_client.get_migrated_dflow_task_id("i18n-tt", "Singapore-Central", "1769416705211173802")
    print(f"DFlow Task ID: {dflow_task_id}")

# pytest tests/test_bytedts_dsyncer.py::test_get_dflow_task_info -s
def test_get_dflow_task_info():
    info = dsyncer_client.get_dflow_task_info("i18n-tt", "US-East", "1659066164440013423")
    print(f"DFlow Task Info: {info}")

