"""
异步版本的 Metrics Client
需要 dts-dance[async] 额外依赖: httpx, tenacity, cachetools
"""

import asyncio
import time
from datetime import datetime
from typing import TYPE_CHECKING, Any, cast
from loguru import logger
from cachetools import TTLCache
from . import ddutil
from .metrics_fe import (
    METRICS_FE_VREGION_ENV_MAPPING,
    MetricEnvInfo,
    MetricType,
    _build_query_payload,
    _parse_token_response,
    _process_query_response,
    _build_mq_filters,
    _build_task_filters,
)

if TYPE_CHECKING:
    import httpx


class AsyncMetricsClient:
    """
    异步 Metrics Client
    需要 dts-dance[async] 额外依赖: httpx, tenacity, cachetools
    """

    # 2小时有效，过期前15分钟可刷新。所以，刷新间隔为15分钟
    _REFRESH_INTERVAL = 15 * 60

    def __init__(self, envs: dict[str, MetricEnvInfo], http_client: "httpx.AsyncClient"):
        """
        初始化异步 Metrics Client

        Args:
            envs: 环境配置列表
            http_client: 共享的 httpx.AsyncClient 实例
        """
        self.envs = envs
        self.tokens: dict[str, str] = {}
        self.token_lock = asyncio.Lock()
        self._refresh_task: asyncio.Task | None = None

        self.client: httpx.AsyncClient = http_client
        self.cache: TTLCache = TTLCache(maxsize=1000, ttl=60)

    async def initialize(self):
        """初始化服务"""
        await self._refresh_tokens()
        self._start_refresh_task()

    async def shutdown(self):
        """关闭服务"""
        if self._refresh_task and not self._refresh_task.done():
            self._refresh_task.cancel()
            try:
                await self._refresh_task
            except asyncio.CancelledError:
                pass

    def get_configured_vregions(self) -> list[str]:
        """获取已配置的 vRegion 列表"""
        return [vregion for vregion, env in METRICS_FE_VREGION_ENV_MAPPING.items() if env in self.envs.keys()]

    def _start_refresh_task(self):
        self._refresh_task = asyncio.create_task(self._refresh_token_periodically())

    async def _refresh_token_periodically(self):
        try:
            while True:
                await asyncio.sleep(self._REFRESH_INTERVAL)
                await self._refresh_tokens()
        except asyncio.CancelledError:
            logger.info("Metrics token refresh task cancelled")
            raise

    async def _refresh_tokens(self):
        logger.debug("开始刷新所有环境的访问令牌...")

        tasks: list[asyncio.Task] = []
        env_names: list[str] = []
        for env_name, env_config in self.envs.items():
            task = asyncio.create_task(
                self._refresh_single_token(env_name, env_config.ak, env_config.sk, env_config.endpoint),
                name=f"refresh_metrics_{env_name}",
            )
            tasks.append(task)
            env_names.append(env_name)

        results = await asyncio.gather(*tasks, return_exceptions=True)

        for env_name, result in zip(env_names, results):
            if isinstance(result, Exception):
                logger.error(f"环境 {env_name} 的访问令牌刷新失败: {result}")
            else:
                logger.debug(f"环境 {env_name} 的访问令牌成功刷新")

        logger.debug(f"所有环境的访问令牌刷新完成。当前环境数量: {len(self.tokens)}")

    async def _refresh_single_token(self, env: str, ak: str, sk: str, endpoint: str):
        try:
            new_token = await self._acquire_token(env, ak, sk, endpoint)
            logger.debug(f"acquire token success, endpoint: {endpoint}, token: {new_token}")
            async with self.token_lock:
                self.tokens[env] = new_token
        except Exception as e:
            logger.error(f"环境 {env} 的访问令牌刷新失败: {e}")
            raise

    async def _acquire_token(self, env: str, ak: str, sk: str, endpoint: str) -> str:
        """获取访问令牌（带重试）"""
        import httpx
        from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type

        @retry(
            stop=stop_after_attempt(3),
            wait=wait_exponential(multiplier=1, min=4, max=10),
            retry=retry_if_exception_type((httpx.RequestError, httpx.HTTPStatusError)),
        )
        async def _do_acquire():
            url = endpoint + "/api/access_token?force_new&_region=" + env
            data = {"app_name": ak, "app_secret": sk}
            try:
                response = await self.client.post(url, json=data)
                response.raise_for_status()
                response_json = response.json()
                return _parse_token_response(response_json)
            except Exception as e:
                logger.error(f"获取令牌时出错: {e}")
                raise

        return await _do_acquire()

    async def _get_token(self, env: str) -> str:
        async with self.token_lock:
            if env not in self.tokens:
                raise KeyError(f"环境 {env} 的访问令牌不存在")
            return self.tokens[env]

    def _get_endpoint(self, env: str) -> str:
        try:
            return self.envs[env].endpoint
        except KeyError:
            raise KeyError(f"未找到环境 {env} 的endpoint配置")

    async def _execute_metrics_query(
        self, vregion: str, metric_name: str, aggregator: str, start_time: str, end_time: str, filters: list[dict[str, Any]], rate: bool, **kwargs
    ) -> list[dict[str, Any]]:
        """执行通用的指标查询，返回所有指标结果"""
        query_start = time.time()
        env = METRICS_FE_VREGION_ENV_MAPPING.get(vregion, None)
        if not env:
            raise ValueError(f"未知的虚拟区域: {vregion}")

        try:
            token = await self._get_token(env)
            endpoint = self._get_endpoint(env)

            url = f"{endpoint}/api/query?_region={vregion}"
            start_time_ms = int(datetime.fromisoformat(start_time).timestamp() * 1000)
            end_time_ms = int(datetime.fromisoformat(end_time).timestamp() * 1000)

            payload = _build_query_payload(metric_name, aggregator, start_time_ms, end_time_ms, filters, rate, **kwargs)
            headers = {"Content-Type": "text/plain", "Authorization": token}

            curl_cmd = ddutil.output_curl(url, headers, payload)
            logger.debug(f"Equivalent curl:\n{curl_cmd}")

            response = await self.client.post(url, json=payload, headers=headers)
            response.raise_for_status()

            result = response.json()
            return _process_query_response(result, end_time)

        except Exception as e:
            logger.error(
                f"execute_metrics_query error: vregion={vregion}, metric={metric_name}, error={e}, cost={(time.time() - query_start) * 1000:.2f}ms"
            )
            raise Exception(f"获取指标失败: {e}")

    async def get_mq_group_metrics(
        self, vregion: str, cluster: str, topic: str, group: str, start_time: str, end_time: str, metric_type: MetricType, **kwargs
    ) -> list[dict[str, Any]]:
        cache_key = f"{vregion}:{metric_type.name}:{cluster}:{topic}:{group}:{start_time[:16]}:{end_time[:16]}"
        if cache_key in self.cache:
            logger.info(f"从缓存获取指标数据: {cache_key}")
            return cast(list[dict[str, Any]], self.cache[cache_key])

        try:
            filters = _build_mq_filters(cluster, topic, group)
            result = await self._execute_metrics_query(
                vregion, metric_type.metric_name, metric_type.aggregator, start_time, end_time, filters, rate=False, **kwargs
            )

            self.cache[cache_key] = result
            return result

        except Exception as e:
            logger.error(f"get_mq_group_metrics vregion={vregion}, cluster={cluster}, topic={topic}, group={group}, error: {e}")
            raise Exception(f"获取消费分组指标失败: {e}")

    async def get_dsyncer_task_metrics(
        self, vregion: str, dsyncer_increment_task_id: str, metric_type: MetricType, start_time: str, end_time: str
    ) -> list[dict[str, Any]]:
        # 校验 increment_task_id
        if not dsyncer_increment_task_id or not dsyncer_increment_task_id.strip():
            raise ValueError("dsyncer_increment_task_id 参数无效：不能为空")

        cache_key = f"{vregion}:{metric_type.name}:{dsyncer_increment_task_id}:{start_time[:16]}:{end_time[:16]}"
        if cache_key in self.cache:
            logger.info(f"从缓存获取指标数据: {cache_key}")
            return cast(list[dict[str, Any]], self.cache[cache_key])

        logger.debug(
            f"get_dsyncer_task_metrics vregion: {vregion}, metric_type: {metric_type.name}, dsyncer_task_id: {dsyncer_increment_task_id}, start_time: {start_time}, end_time: {end_time}"
        )

        try:
            filters = _build_task_filters(dsyncer_increment_task_id)

            result = await self._execute_metrics_query(
                vregion, metric_type.metric_name, metric_type.aggregator, start_time, end_time, filters, rate=metric_type.rate
            )

            self.cache[cache_key] = result
            return result

        except Exception as e:
            logger.error(
                f"get_dsyncer_task_metrics vregion={vregion}, metric_type={metric_type}, dsyncer_task_id={dsyncer_increment_task_id}, error: {e}"
            )
            raise Exception(f"获取 dsyncer 指标失败: {e}")

    async def get_dflow_task_metrics(
        self, vregion: str, dflow_task_id: str, metric_type: MetricType, start_time: str, end_time: str, show_detail: bool = False, **kwargs
    ) -> list[dict[str, Any]]:
        cache_key = f"{vregion}:{metric_type.name}:{dflow_task_id}:{show_detail}:{start_time[:16]}:{end_time[:16]}"
        if cache_key in self.cache:
            logger.info(f"从缓存获取指标数据: {cache_key}")
            return cast(list[dict[str, Any]], self.cache[cache_key])

        try:
            filters = _build_task_filters(dflow_task_id, show_detail)

            result = await self._execute_metrics_query(
                vregion, metric_type.metric_name, metric_type.aggregator, start_time, end_time, filters, rate=metric_type.rate, **kwargs
            )

            self.cache[cache_key] = result
            return result

        except Exception as e:
            logger.error(f"get_dflow_task_metrics vregion={vregion}, metric_type={metric_type}, dflow_task_id={dflow_task_id}, error: {e}")
            raise Exception(f"获取 dflow 指标失败: {e}")
