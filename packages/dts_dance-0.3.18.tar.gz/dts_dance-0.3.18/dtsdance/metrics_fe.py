import time
from datetime import datetime
from typing import Any, NamedTuple

import requests
import threading
from loguru import logger

METRICS_FE_VREGION_ENV_MAPPING = {
    "China-North": "CN",
    "China-East": "CN",
    "Singapore-Central": "SG",
    "Singapore-Compliance": "SG",
    "Asia-CIS": "I18N-BD",
    "US-EE": "I18N-BD",
    "US-East": "VA",
}


class MetricEnvInfo(NamedTuple):
    """Metric 环境配置"""

    name: str
    ak: str
    sk: str
    endpoint: str


class MetricType:
    def __init__(self, name: str, desc: str, metric_name: str, aggregator: str, rate: bool = False):
        self.name = name
        self.desc = desc
        self.metric_name = metric_name
        self.aggregator = aggregator
        self.rate = rate


class MetricTypeEnum(MetricType):
    DSYNCER_LATENCY = MetricType("dsyncer_latency", "DSyncer 延迟", "middleware.dsyncer.server.total.delay.latency.avg", "avg")
    DSYNCER_RT = MetricType("dsyncer_rt", "DSyncer RT", "middleware.dsyncer.server.total.time_consume.latency.pct99", "avg")
    DSYNCER_TPS = MetricType("dsyncer_tps", "DSyncer TPS", "middleware.dsyncer.server.success.row.count.total.rate", "sum")
    DSYNCER_MQ_BACKLOG = MetricType("dsyncer_mq_backlog", "DSyncer MQ 堆积", "rocketmq.consumer_group.depth", "sum")
    DSYNCER_MQ_CONSUME = MetricType("dsyncer_mq_consume", "DSyncer MQ 消费速率", "rocketmq.consumer_group.message.rate", "sum", True)
    DSYNCER_DFLOW_NODE_ERROR = MetricType("dsyncer_dflow_node_error", "DSyncer 对应的 DFlow 节点错误数", "dflow.error", "max")
    DFLOW_NODE_ERROR = MetricType("dflow_node_error", "DFlow 节点错误数", "dflow.error", "max")
    DFLOW_RATE_LIMIT = MetricType("dflow_rate_limit", "DFlow 限流数", "dflow.ratelimit", "max")
    DFLOW_RPS = MetricType("dflow_rps", "DFlow RPS", "dflow.rows", "sum", True)
    DFLOW_BPS = MetricType("dflow_bps", "DFlow BPS", "dflow.bytes", "sum", True)
    DFLOW_FETCH_DELAY = MetricType("dflow_fetch_delay", "DFlow Fetch Delay", "dflow.delay", "max")
    DFLOW_CONSUME_DELAY = MetricType("dflow_consume_delay", "DFlow Consume Delay", "dflow.consumer_delay.avg", "max")
    DFLOW_LAST_COMMIT_DELAY = MetricType("dflow_last_commit_delay", "DFlow Last Commit Delay", "dflow.last_commit_delay.avg", "max")
    DFLOW_DATA_DELAY = MetricType("dflow_data_delay", "DFlow Data Delay", "dflow.trx_delay.avg", "avg")


def get_metric_type_by_name(metric_name: str) -> MetricType | None:
    """
    根据指标名称获取 MetricType 实例

    Args:
        metric_name: 指标名称

    Returns:
        MetricType | None: MetricType 实例，如果不存在则返回 None
    """
    # 遍历 MetricTypeEnum 的所有属性
    for attr_name in dir(MetricTypeEnum):
        # 跳过私有属性和方法
        if attr_name.startswith("_"):
            continue

        attr_value = getattr(MetricTypeEnum, attr_name)

        # 检查是否是 MetricType 实例且名称匹配
        if isinstance(attr_value, MetricType) and attr_value.name == metric_name:
            return attr_value

    return None


def _build_query_payload(
    metric_name: str, aggregator: str, start_time_ms: int, end_time_ms: int, filters: list[dict[str, Any]], rate: bool, **kwargs
) -> dict:
    query = {
        "metric": metric_name,
        "tenant": "default",
        "aggregator": aggregator,
        "rightAxis": 0,
        "rate": rate,
        "rateOptions": {"counter": True, "diff": False, "order": "before_downsample"},
        "isMultiField": False,
        "downsample": "30s-avg",
        "filters": filters,
    }

    if "topK" in kwargs:
        query["topK"] = kwargs["topK"]
    if "downsample" in kwargs:
        query["downsample"] = kwargs["downsample"]

    return {
        "allowCoprocessor": False,
        "start": start_time_ms,
        "end": end_time_ms,
        "queries": [query],
    }


def _remove_last_datapoint(end_time: str, dps: dict[str, float]) -> dict[str, float]:
    """移除监控数据中最后一个数据点，只有当最后一个点的时间戳与 end_time 相差在 30 秒内时才移除"""
    if not dps:
        return dps

    timestamps = sorted(dps.keys())
    if not timestamps:
        return dps

    last_timestamp = timestamps[-1]

    try:
        end_time_sec = int(datetime.fromisoformat(end_time).timestamp())
        last_timestamp_sec = int(last_timestamp)
        time_diff_sec = abs(end_time_sec - last_timestamp_sec)

        if time_diff_sec <= 30:
            return {k: v for k, v in dps.items() if k != last_timestamp}

        return dps

    except Exception as e:
        logger.warning(f"解析时间戳时出错，保留所有数据点: {e}")
        return dps


def _parse_token_response(response_json: dict) -> str:
    if response_json.get("code") != 0:
        error_msg = response_json.get("message", "未知错误")
        raise Exception(f"获取令牌失败: {error_msg}")
    token = response_json.get("access_token")
    if not token:
        raise Exception("响应中没有找到 access_token")
    return token


def _process_query_response(result: list[dict], end_time: str) -> list[dict[str, Any]]:
    if not result:
        return []
    processed_results = []
    for metric_data in result:
        dps = metric_data.get("dps", {})
        tags = metric_data.get("tags", {})
        dps = _remove_last_datapoint(end_time, dps)
        processed_results.append({"metric": metric_data.get("metric"), "dps": dps, "tags": tags})
    return processed_results


def _build_mq_filters(cluster: str, topic: str, group: str) -> list[dict[str, Any]]:
    return [
        {"tagk": "cluster", "filter": cluster, "type": "literal_or", "groupBy": False},
        {"tagk": "consumer_group", "filter": group, "type": "literal_or", "groupBy": False},
        {"tagk": "topic", "filter": topic, "type": "literal_or", "groupBy": False},
    ]


def _build_task_filters(task_id: str, show_detail: bool = False) -> list[dict[str, Any]]:
    filters = [
        {"tagk": "task_id", "filter": task_id, "type": "literal_or", "groupBy": False},
    ]
    if show_detail:
        filters.append({"tagk": "dflow_id", "filter": "*", "type": "literal_or", "groupBy": True})
    return filters


class MetricsClient:
    """
    字节云 Metric 平台 API Client
    """

    # https://cloud.bytedance.net/docs/metrics/docs/63bbbb1ec6b537022a6000c7/63bbd4e8777a300220d4ac3a?x-resource-account=public&x-bc-region-id=bytedance
    # 2小时有效，过期前15分钟可刷新。所以，刷新间隔为15分钟
    _REFRESH_INTERVAL = 15 * 60

    def __init__(self, envs: dict[str, MetricEnvInfo]):
        """
        初始化 Metrics Client
        从配置文件加载所有环境的信息，并为每个环境初始化访问令牌
        """
        self.envs = envs

        # 初始化线程锁，用于保护 tokens 的并发访问
        self.token_lock = threading.Lock()

        # 初始化访问令牌缓存，按环境名称索引
        self.tokens: dict[str, str] = {}

        # 更新所有环境的配置信息
        self._refresh_tokens()

        # 启动 token 刷新线程
        self._start_refresh_thread()

    def _start_refresh_thread(self):
        """
        启动一个后台线程，定期刷新指定环境的访问令牌
        """
        refresh_thread = threading.Thread(
            target=self._refresh_token_periodically,
            daemon=True,
            name="metric-token-refresh",
        )
        refresh_thread.start()

    def _refresh_token_periodically(self):
        """
        定期刷新指定环境的访问令牌的线程函数
        """

        while True:
            # 等待指定时间
            time.sleep(self._REFRESH_INTERVAL)
            self._refresh_tokens()

    def _refresh_tokens(self):
        """
        刷新所有环境的访问令牌
        """
        logger.debug("开始刷新所有环境的访问令牌...")

        for env in self.envs.values():
            try:
                # 刷新令牌
                new_token = self._acquire_token(env.name, env.ak, env.sk, env.endpoint)
                # 使用线程锁更新缓存中的访问令牌
                with self.token_lock:
                    self.tokens[env.name] = new_token
                    logger.debug(f"环境 {env} 的访问令牌成功刷新，新令牌: {new_token}")

            except Exception as e:
                logger.error(f"环境 {env} 的访问令牌刷新失败: {e}")

        logger.debug(f"所有环境的访问令牌已成功刷新。tokens: {self.tokens}")

    def _acquire_token(self, env: str, ak: str, sk: str, endpoint: str) -> str:
        """
        获取访问令牌

        Args:
            env: 环境名称，如 'China-North', 'China-East' 等
            ak: 应用名称 (app_name)
            sk: 应用密钥 (app_secret)
            endpoint: API 端点

        Returns:
            str: 访问令牌
        """
        url = endpoint + "/api/access_token?force_new&_region=" + env

        # 准备请求体
        data = {"app_name": ak, "app_secret": sk}

        try:
            # 发送 POST 请求
            response = requests.post(url, json=data, timeout=30)

            # 检查响应状态码
            response.raise_for_status()

            response_json = response.json()
            return _parse_token_response(response_json)

        except Exception as e:
            logger.error(f"获取令牌时出错: {e}")
            raise

    def _get_token(self, env: str) -> str:
        """
        获取指定环境的访问令牌

        Args:
            env: 环境名称，如 'China-North', 'China-East' 等

        Returns:
            str: 当前有效的访问令牌

        Raises:
            KeyError: 如果指定的环境不存在
        """
        # 使用线程锁保护并发访问
        with self.token_lock:
            if env not in self.tokens:
                raise KeyError(f"环境 {env} 的访问令牌不存在")
            return self.tokens[env]

    def _get_endpoint(self, env: str) -> str:
        """
        获取指定环境的API端点

        Args:
            env: 环境名称，如 'China-North', 'China-East' 等

        Returns:
            str: API端点

        Raises:
            KeyError: 如果指定的环境不存在
        """
        if env not in self.envs:
            raise KeyError(f"未找到环境 {env} 的endpoint配置")

        return self.envs[env].endpoint

    def _execute_metrics_query(
        self, vregion: str, metric_name: str, aggregator: str, start_time: str, end_time: str, filters: list[dict], rate: bool, **kwargs
    ) -> list[dict[str, Any]]:
        """
        执行通用的指标查询

        Args:
            vregion: 虚拟区域名称
            metric_name: 指标名称
            aggregator: 聚合方式
            start_time: 开始时间
            end_time: 结束时间
            filters: 过滤条件列表
            rate: 是否使用速率计算
            **kwargs: 其他可选参数

        Returns:
            list[dict]: 指标结果列表，每个元素包含 metric, dps, tags

        Raises:
            Exception: 如果API请求失败
        """
        env = METRICS_FE_VREGION_ENV_MAPPING.get(vregion, None)
        if not env:
            raise ValueError(f"未知的虚拟区域: {vregion}")

        try:
            # 获取访问令牌和端点
            token = self._get_token(env)
            endpoint = self._get_endpoint(env)

            # 构建API请求URL
            url = f"{endpoint}/api/query?_region={vregion}"
            start_time_ms = int(datetime.fromisoformat(start_time).timestamp() * 1000)
            end_time_ms = int(datetime.fromisoformat(end_time).timestamp() * 1000)

            # 构建请求体
            payload = _build_query_payload(metric_name, aggregator, start_time_ms, end_time_ms, filters, rate, **kwargs)

            # 设置请求头
            headers = {"Content-Type": "text/plain", "Authorization": token}

            # 发送POST请求
            response = requests.post(url, json=payload, headers=headers, timeout=30)
            response.raise_for_status()

            result = response.json()
            return _process_query_response(result, end_time)

        except Exception as e:
            logger.error(f"execute_metrics_query error: vregion={vregion}, metric={metric_name}, error={e}")
            raise Exception(f"获取指标失败: {e}")

    def get_mq_group_metrics(
        self, vregion: str, cluster: str, topic: str, group: str, start_time: str, end_time: str, metric_type: MetricType, **kwargs
    ) -> list[dict[str, Any]]:
        """
        获取指定时间段的堆积指标

        Args:
            vregion: 虚拟区域名称，如 'China-North', 'China-East' 等
            cluster: RocketMQ 集群名称
            topic: RocketMQ 主题名称
            group: RocketMQ 消费组名称
            start_time: 开始时间
            end_time: 结束时间
            metric_name: 指标名称

        Returns:
            Dict: 包含堆积指标的字典，包括metric和dps（数据点）

        Raises:
            KeyError: 如果指定的虚拟区域不存在
            Exception: 如果API请求失败
        """
        logger.debug(
            f"get_mq_backlog_metrics vregion: {vregion}, cluster: {cluster}, topic: {topic}, group: {group}, start_time: {start_time}, end_time: {end_time}"
        )

        filters = _build_mq_filters(cluster, topic, group)

        try:
            result = self._execute_metrics_query(
                vregion, metric_type.metric_name, metric_type.aggregator, start_time, end_time, filters, rate=False, **kwargs
            )
            # logger.debug(f"get_mq_backlog_metrics filtered_dps: {str(result['dps'])[:400]}...")
            return result
        except Exception as e:
            logger.error(f"get_backlog_metrics vregion: {vregion}, cluster: {cluster}, topic: {topic}, group: {group}, error: {e}")
            raise Exception(f"获取堆积指标失败: {e}")

    def get_dsyncer_task_metrics(
        self, vregion: str, dsyncer_increment_task_id: str, metric_type: MetricType, start_time: str, end_time: str
    ) -> list[dict[str, Any]]:
        """
        获取 DSyncer 任务指定时间段的指标

        Args:
            vregion: 虚拟区域名称，如 'China-North', 'China-East' 等
            dsyncer_increment_task_id: 增量任务 ID
            metric_type: 指标类型
            start_time: 开始时间
            end_time: 结束时间

        Returns:
            Dict: 包含指标的字典，包括metric和dps（数据点）

        Raises:
            KeyError: 如果指定的虚拟区域不存在
            Exception: 如果API请求失败
        """
        # 校验 increment_task_id
        if not dsyncer_increment_task_id or not dsyncer_increment_task_id.strip():
            raise ValueError("dsyncer_increment_task_id 参数无效：不能为空")

        logger.debug(
            f"get_dsyncer_task_metrics vregion: {vregion}, metric_type: {metric_type}, dsyncer_increment_task_id: {dsyncer_increment_task_id}, start_time: {start_time}, end_time: {end_time}"
        )

        filters = _build_task_filters(dsyncer_increment_task_id)

        try:
            return self._execute_metrics_query(
                vregion, metric_type.metric_name, metric_type.aggregator, start_time, end_time, filters, rate=metric_type.rate
            )
        except Exception as e:
            logger.error(f"get_dsyncer_task_metrics vregion: {vregion}, dsyncer_increment_task_id: {dsyncer_increment_task_id}, error: {e}")
            raise Exception(f"获取指标失败: {e}")

    def get_dflow_task_metrics(
        self, vregion: str, dflow_task_id: str, metric_type: MetricType, start_time: str, end_time: str, show_detail: bool = False, **kwargs
    ) -> list[dict[str, Any]]:
        """
        获取指定时间段的 DFlow 指标

        Args:
            vregion: 虚拟区域名称，如 'China-North', 'China-East' 等
            dflow_task_id: DFlow 任务 ID
            metric_type: 指标类型
            start_time: 开始时间
            end_time: 结束时间

        Returns:
            Dict: 包含指标的字典，包括metric和dps（数据点）

        Raises:
            KeyError: 如果指定的虚拟区域不存在
            Exception: 如果API请求失败
        """
        logger.debug(
            f"get_dflow_task_metrics vregion: {vregion}, dflow_task_id: {dflow_task_id}, metric_type: {metric_type}, start_time: {start_time}, end_time: {end_time}"
        )

        filters = _build_task_filters(dflow_task_id, show_detail)

        try:
            result = self._execute_metrics_query(
                vregion, metric_type.metric_name, metric_type.aggregator, start_time, end_time, filters, rate=metric_type.rate, **kwargs
            )
            return result
        except Exception as e:
            logger.error(f"get_dflow_task_metrics vregion: {vregion}, dflow_task_id: {dflow_task_id}, error: {e}")
            raise Exception(f"获取指标失败: {e}")
