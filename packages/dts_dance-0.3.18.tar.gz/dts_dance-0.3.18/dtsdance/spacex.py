from datetime import datetime, UTC, timedelta, timezone

from dtsdance import ddutil
from .bytecloud import ByteCloudClient
import requests
from loguru import logger

SITE_SPACEX_ENV_MAP = {
    "cn": "cn",
    # "boe": "boe",
    # "i18n-tt": "i18n",
    # "i18n-bd": "i18nbd",
}


class SpaceXClient:
    """
    SpaceX API 客户端。包含：工单创建等功能
    """

    def __init__(self, bytecloud_client: ByteCloudClient):
        """
        SpaceX API 客户端
        """
        self.bytecloud_client = bytecloud_client

    def _build_request_headers(self, site: str) -> dict[str, str]:
        """
        构建请求头

        Args:
            env: 环境名称
            include_auth: 是否包含 Authorization 头

        Returns:
            dict[str, str]: 请求头字典
        """
        jwt_token = self.bytecloud_client.get_jwt_token(site)
        spacex_env = SITE_SPACEX_ENV_MAP.get(site, site)
        return {
            "X-Jwt-Token": jwt_token,
            "x-spacex-env": spacex_env,
            "x-biz-app": "null",
            "x-spacex-tenant": "bytedts",
        }

    def _compute_change_time_window(self) -> list[str]:
        """
        根据当前时间返回合法的变更时间窗口。
        变更窗口：10:00 ~ 18:00
        返回时间格式为 UTC ISO 8601 格式

        Returns:
            List[str]: 包含开始时间和结束时间的列表 [start_time, end_time]
        """
        # 获取当前UTC时间
        now_utc = datetime.now(UTC)

        # 转换为北京时间 (UTC+8) 来判断时间窗口
        beijing_tz = timezone(timedelta(hours=8))
        now_beijing = now_utc.astimezone(beijing_tz)

        # 获取今天的日期
        today = now_beijing.date()

        # 定义变更窗口 (北京时间) - 连续窗口 10:00 ~ 18:00
        window_start = datetime.combine(today, datetime.min.time().replace(hour=10, minute=0), beijing_tz)
        window_end = datetime.combine(today, datetime.min.time().replace(hour=18, minute=0), beijing_tz)

        # 判断当前时间在哪个窗口
        if window_start <= now_beijing < window_end:
            # 当前在窗口内：开始使用当前UTC时间，结束为当天窗口结束
            start_time = now_utc
            end_time = window_end.astimezone(UTC)
        elif now_beijing < window_start:
            # 当前时间早于窗口，使用今天的窗口
            start_time = window_start.astimezone(UTC)
            end_time = window_end.astimezone(UTC)
        else:
            # 当前时间晚于窗口，使用明天的同一窗口
            tomorrow = today + timedelta(days=1)
            tomorrow_start = datetime.combine(tomorrow, datetime.min.time().replace(hour=10, minute=0), beijing_tz)
            tomorrow_end = datetime.combine(tomorrow, datetime.min.time().replace(hour=18, minute=0), beijing_tz)
            start_time = tomorrow_start.astimezone(UTC)
            end_time = tomorrow_end.astimezone(UTC)

        # 转换为ISO 8601格式的字符串
        start_time_str = start_time.isoformat().replace("+00:00", "Z")
        end_time_str = end_time.isoformat().replace("+00:00", "Z")

        logger.info(f"Generated valid change time window, input : {beijing_tz}, output : {start_time_str} to {end_time_str}")
        return [start_time_str, end_time_str]

    def create_migration_order(self, vregion: str, username: str, task_ids: list[str], site: str = "cn") -> str:
        site_info = self.bytecloud_client.get_site_config(site)
        url = f"{site_info.endpoint_spacex}/nocode/action/run"

        # 获取合法的变更时间窗口
        change_plan_time = self._compute_change_time_window()
        payload = {
            "actionType": "API",
            "ticketTags": [],
            "elementId": "widget-7c589761-e223-48f9-9792-cd688219480a",
            "entityType": "unknown",
            "entityValue": "unknown",
            "actionId": 99999,
            "actionMeta": {
                "method": "POST",
                "url": f"{site_info.endpoint_spacex_gw}/scene_ops/api/v1/ticket/sample",
                "params": {
                    "change_plan_time": change_plan_time,
                    "trigger_type": "manual_trigger",
                    "tags": [],
                    "name": "DSyncer批量迁往DFlow",
                    "args": {"vregion": vregion, "username": username, "task_ids": task_ids},
                    "tod_change_control_param": {
                        "strategyScenes": "DEFAULT",
                        "changeLevel": "L3",
                        "isUrgent": False,
                        "changeDesc": "DSyncer 任务迁移至 DFlow",
                        "effectScope": "针对迁移的任务，数据正确性、迁移效率等有影响",
                        "rollbackPlan": "人工确认后，可再流程中执行回滚操作",
                    },
                    "task_unique_name": "dsync_batch_migrate_dflow",
                    "in_frame": False,
                    "context_args": {"standardObjects": {"cmdbSelfLink": ""}},
                    "product": "ByteDTS",
                },
                "__detailFormKv": "{}",
                "customHeaders": {},
                "referer": "",
            },
            "actionName": "submit_change",
            "actionLabel": "submit_change",
            "node": "module@@scenario-operation|app|T:createSampleScene.195bbb19-ffe7-41b3-c142-3a457029a0ad",
            "orderType": "changefree",
            "processorInfo": {},
            "notifyDataJson": None,
            "enableJwt": True,
            "isSyncSpacexTicketCenter": False,
            "spacexTicketType": "change",
            "product": "ByteDTS",
            "changeRiskControlApplyMeta": {"enabled": False},
        }

        headers = self._build_request_headers(site)

        # curl_cmd = ddutil.output_curl(url, headers, payload)
        # logger.debug(f"Equivalent curl:\n{curl_cmd}")

        try:
            response = requests.post(url, json=payload, headers=headers)
            logger.debug(f"create_migration_order response: {response.text}")

            # 检查响应状态码
            response.raise_for_status()
            result = response.json()
            if result.get("code") != 0:
                logger.warning(
                    f"create_migration_order failed, vregion: {vregion}, task_ids: {task_ids}, error: {result.get('message', 'Unknown error')}"
                )
                return ""

            logger.info(f"create_migration_order success, vregion: {vregion}, task_ids: {task_ids}")
            ticket_id = result.get("data", {}).get("id", "")
            return f"{site_info.endpoint_spacex_bytedts}/settings/sops/scenario-operation-and-maintenance/ticket-detail-old?id={ticket_id}"

        except Exception as e:
            logger.error(f"create_migration_order occur error, vregion: {vregion}, task_ids: {task_ids}, error: {e}")
            raise
