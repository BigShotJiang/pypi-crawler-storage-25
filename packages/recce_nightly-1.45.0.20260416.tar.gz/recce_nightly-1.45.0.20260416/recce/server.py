import asyncio
import json
import logging
import os
import signal
import sys
import uuid
from contextlib import asynccontextmanager
from dataclasses import dataclass
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Annotated, Any, Literal, Optional, Set

from fastapi import (
    BackgroundTasks,
    FastAPI,
    Form,
    HTTPException,
    Request,
    Response,
    UploadFile,
    WebSocket,
)
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, ValidationError
from pytz import utc
from starlette.middleware.gzip import GZipMiddleware
from starlette.middleware.sessions import SessionMiddleware
from starlette.websockets import WebSocketDisconnect

from . import __latest_version__, __version__, event, is_recce_cloud_instance
from .apis.check_api import check_router
from .apis.check_events_api import check_events_router
from .apis.run_api import run_router
from .config import RecceConfig
from .connect_to_cloud import (
    connect_to_cloud_background_task,
    generate_key_pair,
    get_connection_url,
    is_callback_server_running,
    prepare_connection_url,
)
from .core import RecceContext, default_context, load_context
from .event import get_recce_api_token, log_api_event, log_single_env_event
from .exceptions import RecceException
from .github import is_github_codespace
from .models.types import CllData
from .models.websocket import CloudUserContextMessage
from .run import load_preset_checks
from .state import RecceShareStateManager, RecceStateLoader
from .util.startup_perf import track_timing
from .websocket import (
    extract_cloud_user_from_headers,
    get_connection_manager,
    set_current_cloud_user,
)

logger = logging.getLogger("uvicorn")

# Idle timeout check interval bounds (in seconds)
MAX_CHECK_INTERVAL = 30
MIN_CHECK_INTERVAL = 1


class RecceServerMode(str, Enum):
    server = "server"
    preview = "preview"
    read_only = "read-only"

    def __str__(self):
        return self.value

    @staticmethod
    def available_members() -> Set[str]:
        return ["server", "preview", "read-only"]


@dataclass
class AppState:
    command: Optional[str] = None
    state_loader: Optional[RecceStateLoader] = None
    kwargs: Optional[dict] = None
    flag: Optional[dict] = None
    auth_options: Optional[dict] = None
    lifetime: Optional[int] = None
    lifetime_expired_at: Optional[datetime] = None
    idle_timeout: Optional[int] = None
    last_activity: Optional[dict] = None
    share_url: Optional[str] = None
    organization_name: Optional[str] = None
    web_url: Optional[str] = None
    host: Optional[str] = None
    port: Optional[int] = None


def schedule_lifetime_termination(app_state):
    def terminating_server():
        pid = os.getpid()
        logger.info(f"Terminating server process [{pid}] manually due to lifetime expiration")
        os.kill(pid, signal.SIGINT)

    # Terminate the server process after the specified lifetime
    logger.info(f"[Configuration] The lifetime of the server is {app_state.lifetime} seconds")
    app.state.lifetime_expired_at = datetime.now(utc) + timedelta(seconds=app_state.lifetime)
    asyncio.get_running_loop().call_later(app_state.lifetime, terminating_server)


def schedule_idle_timeout_check(app_state):
    """
    Schedule periodic checks for idle timeout.
    If the server has been idle for longer than idle_timeout, terminate it.
    """
    # Track last activity time in app_state
    app_state.last_activity = {"time": datetime.now(utc)}

    def terminating_server_idle():
        pid = os.getpid()
        logger.info(f"Terminating server process [{pid}] manually due to idle timeout")
        os.kill(pid, signal.SIGINT)

    async def check_idle_timeout():
        """Periodically check if the server has been idle for too long"""
        # Use smaller check interval if idle_timeout is very short
        # Check at least every MAX_CHECK_INTERVAL seconds, but also check when idle_timeout is approaching
        check_interval = min(MAX_CHECK_INTERVAL, max(MIN_CHECK_INTERVAL, app_state.idle_timeout // 3))

        logger.debug(f"[Idle Timeout] Starting idle timeout checker with {check_interval}s check interval")

        while True:
            await asyncio.sleep(check_interval)

            idle_seconds = (datetime.now(utc) - app_state.last_activity["time"]).total_seconds()
            remaining_seconds = app_state.idle_timeout - idle_seconds

            # Always log the countdown for debugging
            if remaining_seconds > 0:
                logger.debug(
                    f"[Idle Timeout] Server idle for {idle_seconds:.1f}s / {app_state.idle_timeout}s "
                    f"(remaining: {remaining_seconds:.1f}s)"
                )

            if idle_seconds >= app_state.idle_timeout:
                logger.info(
                    f"[Idle Timeout] Threshold reached! Server has been idle for {idle_seconds:.0f} seconds "
                    f"(threshold: {app_state.idle_timeout} seconds)"
                )
                terminating_server_idle()
                break

    # Start the idle timeout check task
    logger.info(f"[Configuration] The idle timeout of the server is {app_state.idle_timeout} seconds")

    # Create task using asyncio.create_task which works in async context
    task = asyncio.create_task(check_idle_timeout())
    logger.debug(f"[Idle Timeout] Background task created: {task}")


def setup_server(app_state: AppState) -> RecceContext:
    from rich.console import Console

    from .core import load_context

    console = Console()
    state_loader = app_state.state_loader
    kwargs = app_state.kwargs
    ctx = load_context(**kwargs, state_loader=state_loader)
    ctx.start_monitor_artifacts(callback=dbt_artifacts_updated_callback)
    single_env = False
    if app_state.flag.get("single_env_onboarding", False) is True:
        # [Experiment 2] Start with Single Environment
        single_env = True
        ctx.start_monitor_base_env(callback=dbt_env_updated_callback)
        log_single_env_event()

    # Initialize Recce Config
    config = RecceConfig(config_file=kwargs.get("config"))
    if state_loader.state is None:
        preset_checks = config.get("checks", [])
        if preset_checks and len(preset_checks) > 0:
            console.rule("Loading Preset Checks")
            load_preset_checks(preset_checks)

    from recce.event import log_load_state

    log_load_state(command="server", single_env=single_env)

    return ctx


def teardown_server(app_state: AppState, ctx: RecceContext):
    # pull latest state, merge runs/checks and pick the newer artifacts
    state_loader = ctx.state_loader
    state_loader.refresh()
    if state_loader.state:
        ctx.import_state(state_loader.state, merge=True)
    state_loader.export(ctx.export_state())
    ctx.stop_monitor_artifacts()
    if app_state.flag.get("single_env_onboarding", False):
        ctx.stop_monitor_base_env()


def setup_ready_only(app_state: AppState) -> RecceContext:
    from .core import load_context

    kwargs = app_state.kwargs
    state_loader = app_state.state_loader
    ctx = load_context(**kwargs, state_loader=state_loader)
    return ctx


def teardown_ready_only(app_state: AppState, ctx: RecceContext):
    pass


def setup_preview(app_state: AppState):
    state_loader = app_state.state_loader
    kwargs = app_state.kwargs
    ctx = load_context(**kwargs, state_loader=state_loader)
    return ctx


def teardown_preview(app_state: AppState, ctx: RecceContext):
    state_loader = app_state.state_loader
    state_loader.export(ctx.export_state())
    pass


@track_timing("server_setup")
def _do_lifespan_setup(app_state: AppState):
    """Run server setup and return context for teardown.

    Note: This function runs in a background thread. Do NOT call asyncio APIs
    (create_task, get_running_loop, etc.) here — schedule them in the async
    caller after this returns.
    """
    if app_state.command == "server":
        ctx = setup_server(app_state)
    elif app_state.command == "read-only":
        ctx = setup_ready_only(app_state)
    elif app_state.command == "preview":
        ctx = setup_preview(app_state)
    else:
        ctx = None

    return ctx


@asynccontextmanager
async def lifespan(fastapi: FastAPI):
    from recce.core import default_context
    from recce.event import log_performance
    from recce.util.startup_perf import clear_startup_tracker, get_startup_tracker

    app_state: AppState = app.state

    # Ensure logger is at DEBUG level if debug mode is enabled
    if app_state.kwargs and app_state.kwargs.get("debug"):
        logger.setLevel(logging.DEBUG)
        logger.debug("Debug mode enabled - logger set to DEBUG level")

    # Set up readiness signaling for background loading
    ready_event = asyncio.Event()
    app_state.ready_event = ready_event
    app_state.startup_error = None
    app_state.startup_ctx = None

    async def background_load():
        try:
            ctx = await asyncio.to_thread(_do_lifespan_setup, app_state)
            app_state.startup_ctx = ctx

            # Schedule async timers on the event loop (must be in async context)
            if app_state.lifetime is not None and app_state.lifetime > 0:
                schedule_lifetime_termination(app_state)
            if app_state.idle_timeout is not None and app_state.idle_timeout > 0:
                logger.debug(f"[Idle Timeout] Scheduling idle timeout check with {app_state.idle_timeout} seconds")
                schedule_idle_timeout_check(app_state)

            # Log startup performance metrics
            if tracker := get_startup_tracker():
                tracker.command = app_state.command
                recce_ctx = default_context()
                if recce_ctx and recce_ctx.adapter:
                    tracker.adapter_type = type(recce_ctx.adapter).__name__
                    if hasattr(recce_ctx.adapter, "curr_manifest") and recce_ctx.adapter.curr_manifest:
                        tracker.node_count = len(recce_ctx.adapter.curr_manifest.nodes)
                log_performance("server_startup", tracker.to_dict())
        except Exception as e:
            logger.exception("Failed to load server context during startup")
            app_state.startup_error = e
        finally:
            clear_startup_tracker()
            ready_event.set()

    task = asyncio.create_task(background_load())

    yield  # Server starts accepting connections immediately

    # Wait for background loading to complete before teardown
    await task

    if not app_state.startup_error:
        ctx = app_state.startup_ctx
        if app_state.command == "server" and ctx:
            teardown_server(app_state, ctx)
        elif app_state.command == "read-only" and ctx:
            teardown_ready_only(app_state, ctx)
        elif app_state.command == "preview" and ctx:
            teardown_preview(app_state, ctx)


app = FastAPI(lifespan=lifespan)


def verify_json_file(file_path: str) -> bool:
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            json.load(f)
    except Exception:
        return False
    return True


def dbt_artifacts_updated_callback(file_changed_event: Any):
    src_path = Path(file_changed_event.src_path)
    target_type = src_path.parent.name
    file_name = src_path.name

    if not verify_json_file(file_changed_event.src_path):
        logger.debug("Skip to refresh the artifacts because the file is not updated completely.")
        return

    logger.info(f"Detect {target_type} file {file_changed_event.event_type}: {file_name}")
    ctx = load_context()
    ctx.refresh_manifest(file_changed_event.src_path)
    broadcast_command = {
        "command": "refresh",
        "event": {"eventType": file_changed_event.event_type, "srcPath": file_changed_event.src_path},
    }
    payload = json.dumps(broadcast_command)
    asyncio.run(broadcast(payload))


def dbt_env_updated_callback():
    logger.info("Detect 'manifest.json' and 'catalog.json' are generated under 'target-base' directory")
    broadcast_command = {
        "command": "relaunch",
    }
    payload = json.dumps(broadcast_command)
    asyncio.run(broadcast(payload))


origins = [
    "http://localhost:3000",
    "http://localhost:3001",
]

app.add_middleware(GZipMiddleware, minimum_size=1000)
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.add_middleware(
    SessionMiddleware,
    secret_key=uuid.uuid4(),
)


@app.middleware("http")
async def track_activity_for_idle_timeout(request: Request, call_next):
    """Track activity time for idle timeout check"""
    # Exclude paths that should not reset idle timer
    # Health checks and monitoring endpoints don't count as user activity
    excluded_paths = ["/api/health", "/api/ws"]

    # Update last activity time BEFORE processing request if idle timeout is enabled
    # This ensures long-running requests don't get terminated mid-execution
    app_state: AppState = app.state
    if app_state.last_activity is not None:
        if request.url.path not in excluded_paths:
            app_state.last_activity["time"] = datetime.now(utc)
            logger.debug(f"[Idle Timeout] ✓ Activity detected: {request.method} {request.url.path} - Timer reset")
        else:
            logger.debug(f"[Idle Timeout] Excluded path (no timer reset): {request.method} {request.url.path}")

    response = await call_next(request)
    return response


@app.middleware("http")
async def extract_cloud_user_context(request: Request, call_next):
    """
    Extract cloud user context from HTTP headers sent by Recce Cloud proxy.

    When Recce Cloud proxies HTTP requests to a shared instance, it can include
    headers identifying the authenticated user. This middleware extracts those
    headers and sets the user context for the duration of the request.

    Headers:
        X-Recce-User-Id: The user's UUID
        X-Recce-User-Login: The user's login/username
        X-Recce-User-Email: The user's email (optional)
    """
    # Extract user context from headers
    cloud_user = extract_cloud_user_from_headers(dict(request.headers))

    if cloud_user:
        # Set the context for this request
        set_current_cloud_user(cloud_user)

    try:
        response = await call_next(request)
        return response
    finally:
        # Clear the context after the request completes
        if cloud_user:
            set_current_cloud_user(None)


@app.middleware("http")
async def set_context_by_cookie(request: Request, call_next):
    response = await call_next(request)

    user_id_in_cookie = request.cookies.get("recce_user_id")
    user_id = event.get_user_id()

    if event.is_anonymous_tracking() is False:
        # Disable anonymous tracking
        user_id = None

    if user_id_in_cookie is None or user_id_in_cookie != user_id:
        response.set_cookie(key="recce_user_id", value=user_id)
    return response


@app.middleware("http")
async def readiness_gate(request: Request, call_next):
    """Block API requests until server startup is complete.

    /api/health and non-API routes (SPA, static assets) pass through
    immediately so container orchestrators can detect the process is alive
    and the frontend can load while the backend initializes.
    All other /api/* endpoints wait for the background loading to finish.
    If loading failed, return 503.
    """
    path = request.url.path
    if path == "/api/health" or not path.startswith("/api/"):
        return await call_next(request)

    ready_event = getattr(request.app.state, "ready_event", None)
    if isinstance(ready_event, asyncio.Event):
        startup_timeout = float(os.environ.get("RECCE_STARTUP_TIMEOUT", "300"))
        try:
            await asyncio.wait_for(ready_event.wait(), timeout=startup_timeout)
        except asyncio.TimeoutError:
            return JSONResponse(
                {"error": f"Server startup did not complete within {startup_timeout:.0f}s."},
                status_code=503,
            )

        if getattr(request.app.state, "startup_error", None):
            return JSONResponse(
                {"error": "Server startup failed. Check server logs for details."},
                status_code=503,
            )

    return await call_next(request)


@app.middleware("http")
async def disable_cache(request: Request, call_next):
    response = await call_next(request)

    # disable cache for '/' and '/index.html'
    if request.url.path in ["/", "/index.html"]:
        response.headers["Cache-Control"] = "no-store"

    return response


@app.get("/api/health")
async def health_check(request: Request):
    ready_event = getattr(request.app.state, "ready_event", None)
    is_ready = ready_event.is_set() if isinstance(ready_event, asyncio.Event) else True
    startup_error = getattr(request.app.state, "startup_error", None)
    # Only expose the exception type to avoid leaking internal details
    # (file paths, config values). Full details are in the server logs.
    error = type(startup_error).__name__ if startup_error else None

    return {
        "status": "ok",
        "ready": is_ready and not startup_error,
        "error": error,
    }


@app.post("/api/keep-alive")
async def keep_alive():
    """Endpoint to keep the session alive and reset idle timeout"""
    app_state: AppState = app.state
    if app_state.last_activity is not None:
        app_state.last_activity["time"] = datetime.now(utc)
        logger.debug("[Idle Timeout] Keep-alive request received - Timer reset")
        return {"status": "ok", "idle_timeout_enabled": True}
    return {"status": "ok", "idle_timeout_enabled": False}


class RecceInstanceInfoOut(BaseModel):
    server_mode: RecceServerMode
    read_only: bool
    preview: bool
    single_env: bool
    authed: bool
    cloud_instance: bool
    python_version: str
    lifetime_expired_at: Optional[datetime] = None
    idle_timeout: Optional[int] = None
    share_url: Optional[str] = None
    session_id: Optional[str] = None
    organization_name: Optional[str] = None
    web_url: Optional[str] = None
    user_role: Optional[str] = None


@app.get("/api/instance-info", response_model=RecceInstanceInfoOut, response_model_exclude_none=True)
async def recce_instance_info():
    app_state: AppState = app.state
    flag = app_state.flag
    read_only = flag.get("read_only", False)
    single_env = flag.get("single_env_onboarding", False)

    api_token = get_recce_api_token()

    return {
        "server_mode": app_state.command,
        "read_only": read_only,
        "preview": flag.get("preview", False),
        "single_env": single_env,
        "authed": True if api_token else False,
        "cloud_instance": is_recce_cloud_instance(),
        "python_version": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
        "lifetime_expired_at": app_state.lifetime_expired_at,  # UTC timezone
        "idle_timeout": app_state.idle_timeout,
        "share_url": app_state.share_url,
        "session_id": app_state.state_loader.session_id if app_state.state_loader else None,
        "organization_name": app_state.organization_name,
        "web_url": app_state.web_url,
        # TODO: Add more instance info which won't change during the instance lifecycle
        # review_mode
        # cloud_mode
        # demo
        # single env
    }


@app.get("/api/flag")
async def config_flag():
    app_state: AppState = app.state
    flag = app_state.flag
    return flag


@app.post("/api/relaunch-hint/completed", status_code=204)
async def mark_relaunch_hint_completed():
    app.state.flag["show_relaunch_hint"] = False


@app.get("/api/info")
async def get_info():
    """
    Get the information of the current context.
    """
    context = default_context()
    demo = os.environ.get("DEMO", False)
    is_codespace = is_github_codespace()

    if demo:
        state = context.export_demo_state()
    else:
        state = context.export_state()

    support_tasks = context.support_tasks()
    if context.state_loader and context.state_loader.state_file:
        filename = os.path.basename(context.state_loader.state_file)
    else:
        filename = None

    state_metadata = context.state_loader.state.metadata if context.state_loader.state else None
    lineage_diff = context.get_lineage_diff()

    try:
        info = {
            "state_metadata": state_metadata,
            "adapter_type": context.adapter_type,
            "review_mode": context.review_mode,
            "git": state.git.to_dict() if state.git else None,
            "pull_request": state.pull_request.to_dict() if state.pull_request else None,
            "lineage": lineage_diff,
            "demo": bool(demo),
            "codespace": bool(is_codespace),
            "cloud_mode": context.state_loader.cloud_mode,
            "file_mode": context.state_loader.state_file is not None,
            "filename": filename,
            "support_tasks": support_tasks,
        }

        if context.adapter_type == "sqlmesh":
            from recce.adapter.sqlmesh_adapter import SqlmeshAdapter

            sqlmesh_adapter: SqlmeshAdapter = context.adapter
            info["sqlmesh"] = {
                "base_env": sqlmesh_adapter.base_env.name,
                "current_env": sqlmesh_adapter.curr_env.name,
            }

        return info
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


class CllIn(BaseModel):
    node_id: Optional[str] = None
    column: Optional[str] = None
    change_analysis: Optional[bool] = False
    no_cll: Optional[bool] = False
    no_upstream: Optional[bool] = False
    no_downstream: Optional[bool] = False
    full_map: Optional[bool] = False


class CllOutput(BaseModel):
    current: CllData


@app.post("/api/cll", response_model=CllOutput)
async def column_level_lineage_by_node(cll_input: CllIn):
    from recce.adapter.dbt_adapter import DbtAdapter

    app_state: AppState = app.state
    disable_cll_cache = app_state.flag.get("disable_cll_cache", False) if app_state.flag else False

    dbt_adapter: DbtAdapter = default_context().adapter
    cll = dbt_adapter.get_cll(
        node_id=cll_input.node_id,
        column=cll_input.column,
        change_analysis=cll_input.change_analysis,
        no_upstream=cll_input.no_upstream,
        no_downstream=cll_input.no_downstream,
        no_cll=cll_input.no_cll,
        full_map=cll_input.full_map,
        disable_cll_cache=disable_cll_cache,
    )

    return CllOutput(current=cll)


class SelectNodesInput(BaseModel):
    select: Optional[str] = None
    exclude: Optional[str] = None
    packages: Optional[list[str]] = None
    view_mode: Optional[Literal["all", "changed_models"]] = None


class SelectNodesOutput(BaseModel):
    nodes: Set[str] = []


@app.post("/api/select", response_model=SelectNodesOutput)
async def select_nodes(input: SelectNodesInput):
    context = default_context()

    if context.adapter_type != "dbt":
        raise HTTPException(status_code=400, detail="Only dbt adapter is supported")

    try:
        nodes = context.adapter.select_nodes(
            select=input.select,
            exclude=input.exclude,
            packages=input.packages,
            view_mode=input.view_mode,
        )
        nodes = [node for node in nodes if not node.startswith("test.")]
        return SelectNodesOutput(nodes=nodes)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.get("/api/model/{model_id}")
async def get_columns(model_id: str):
    context = default_context()
    try:
        return {
            "model": {
                "base": context.get_model(model_id, base=True),
                "current": context.get_model(model_id, base=False),
            }
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/api/save", response_class=PlainTextResponse, status_code=200)
async def save_handler():
    """
    Save the in-memory state to the state file
    """
    try:
        # Sync the state file
        context = default_context()
        log_api_event("save", dict(state_loader_mode=context.state_loader_mode()))
        state_loader = context.state_loader
        if not state_loader.cloud_mode and state_loader.state_file is None:
            raise RecceException("Not file mode or cloud mode")

        context.sync_state("overwrite")
    except RecceException as e:
        raise HTTPException(status_code=400, detail=e.message)


class SaveAsOrRenameInput(BaseModel):
    # The filename. The filename should not contain directory.
    filename: Optional[str] = None
    # Overwrite the file if it exists
    overwrite: Optional[bool] = False


def saveas_or_rename(input: SaveAsOrRenameInput, rename: bool = False):
    context = default_context()
    state_loader = context.state_loader
    if state_loader.cloud_mode:
        raise RecceException("Cloud mode does not support rename")

    new_filename = input.filename
    if os.path.dirname(new_filename):
        raise RecceException("The new filename should not contain directory")
    if not new_filename.endswith(".json"):
        raise RecceException("The new filename should end with .json")

    old_path = state_loader.state_file
    if old_path:
        old_dir = os.path.dirname(state_loader.state_file)
        old_filename = os.path.basename(state_loader.state_file)
        if old_filename == new_filename:
            raise RecceException("The new filename is the same as the current filename")
        new_path = os.path.join(old_dir, new_filename)
    else:
        new_path = new_filename

    if os.path.exists(new_path):
        if os.path.isdir(new_path):
            raise HTTPException(status_code=400, detail=f"The file {new_path} exists and is a directory")

        if not input.overwrite:
            raise HTTPException(status_code=409, detail=f"The file {new_filename} already exists")

    state_loader.state_file = new_path
    context.sync_state("overwrite")
    if rename and os.path.exists(old_path):
        os.remove(old_path)


@app.post("/api/save-as", response_class=PlainTextResponse, status_code=200)
async def save_as_handler(input: SaveAsOrRenameInput):
    """
    Save the state to a new file
    """
    context = default_context()
    try:
        log_api_event("saveas", dict(state_loader_mode=context.state_loader_mode()))
        saveas_or_rename(input, rename=False)
    except RecceException as e:
        raise HTTPException(status_code=400, detail=e.message)


@app.post("/api/rename", response_class=PlainTextResponse, status_code=200)
async def rename_handler(input: SaveAsOrRenameInput):
    """
    Rename the state to a new file
    """
    context = default_context()
    try:
        log_api_event("rename", dict(state_loader_mode=context.state_loader_mode()))
        saveas_or_rename(input, rename=True)
    except RecceException as e:
        raise HTTPException(status_code=400, detail=e.message)


@app.post("/api/export", response_class=PlainTextResponse, status_code=200)
async def export_handler():
    """
    Export the recce state to the client.
    """
    context = default_context()
    try:
        log_api_event("export", dict(state_loader_mode=context.state_loader_mode()))
        return context.export_state().to_json()
    except RecceException as e:
        raise HTTPException(status_code=400, detail=e.message)


@app.post("/api/import", status_code=200)
async def import_handler(
    file: Annotated[UploadFile, Form()], checks_only: Annotated[bool, Form()], background_tasks: BackgroundTasks
):
    """
    Import the recce state from the client.
    """
    from recce.state import RecceState

    context = default_context()
    try:
        log_api_event("import", dict(state_loader_mode=context.state_loader_mode()))
        content = await file.read()
        state = RecceState.from_json(content)

        if checks_only:
            import_checks = context.import_checks(state)
            background_tasks.add_task(context.sync_state, "overwrite")
            return {"runs": 0, "checks": import_checks}

        import_runs, import_checks = context.import_state(state)
        return {"runs": import_runs, "checks": import_checks}
    except ValidationError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except RecceException as e:
        raise HTTPException(status_code=400, detail=e.message)


class SyncStateInput(BaseModel):
    method: Optional[str] = None


@app.post("/api/sync", status_code=202)
async def sync_handler(input: SyncStateInput, response: Response, background_tasks: BackgroundTasks):
    """
    Sync the state with the external storage. (two-way sync)

    This is used to sync the state with the external (local or cloud) storage. There are three methods:
    - overwrite: Overwrite the external storage with the in-memory state.
    - revert: Revert the in-memory state with the external storage.
    - merge: Merge the state between the in-memory and external storage.
    """
    context = default_context()
    state_loader = context.state_loader
    method = input.method
    log_api_event(
        "sync",
        dict(
            state_loader_mode=context.state_loader_mode(),
            method=method,
        ),
    )

    if not method:
        is_conflict = state_loader.check_conflict()
        if is_conflict:
            raise HTTPException(status_code=409, detail="Conflict detected")
        method = "overwrite"

    is_syncing = state_loader.state_lock.locked()
    if is_syncing:
        response.status_code = 208
        return {"status": "syncing"}

    def reload_state():
        ctx = default_context()
        ctx.sync_state(method)

    background_tasks.add_task(reload_state)
    response.status_code = 202
    return {"status": "request accepted"}


@app.get("/api/sync", status_code=200)
async def sync_status(response: Response):
    """
    Get the sync status.
    """
    context = default_context()
    if context.state_loader.state_lock.locked():
        response.status_code = 208
        return {"status": "syncing"}

    response.status_code = 200
    return {"status": "idle"}


class ShareStateOutput(BaseModel):
    status: str
    message: str
    share_url: Optional[str] = None


@app.post("/api/share", response_model=ShareStateOutput)
async def share_state():
    """
    Share the recce state to the external storage. (one-way sync)
    """
    app_state: AppState = app.state
    state_manager = RecceShareStateManager(app_state.auth_options)
    if not state_manager.verify():
        error, hint = state_manager.error_and_hint
        raise HTTPException(status_code=400, detail=f"Failed to share state: {error}. {hint}")

    context = default_context()
    state_loader = context.state_loader

    file_name = "recce_state.json"
    if state_loader.state_file:
        file_name = os.path.basename(state_loader.state_file)

    state = state_loader.state
    if state_loader.state is None:
        state = context.export_state()

    response = state_manager.share_state(file_name, state)

    return ShareStateOutput(**response)


class VersionOut(BaseModel):
    version: str
    latestVersion: str


@app.get("/api/version", response_model=VersionOut)
async def version():
    try:
        return dict(
            version=__version__,
            latestVersion=__latest_version__,
        )
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.websocket("/api/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    manager = get_connection_manager()
    manager.connect(websocket)
    try:
        while True:
            data = await websocket.receive_text()
            await _handle_websocket_message(websocket, data, manager)
    except WebSocketDisconnect:
        manager.disconnect(websocket)


async def _handle_websocket_message(websocket: WebSocket, data: str, manager) -> None:
    """
    Handle incoming WebSocket messages.

    Supports:
    - Plain text "ping" messages (backward compatibility)
    - JSON messages with "type" field for routing
    """
    # Handle plain text ping for backward compatibility
    if data == "ping":
        await websocket.send_text("pong")
        return

    # Try to parse as JSON
    try:
        message = json.loads(data)
    except json.JSONDecodeError:
        logger.warning(f"Received non-JSON WebSocket message: {data[:100]}")
        return

    # Route based on message type
    message_type = message.get("type")

    if message_type == "cloud_user_context":
        await _handle_cloud_user_context(websocket, message, manager)
    elif message_type == "ping":
        # JSON ping format
        await websocket.send_text(json.dumps({"type": "pong"}))
    else:
        logger.debug(f"Unhandled WebSocket message type: {message_type}")


async def _handle_cloud_user_context(websocket: WebSocket, message: dict, manager) -> None:
    """
    Handle cloud_user_context message from Recce Cloud.

    This message is sent when Recce Cloud proxies a WebSocket connection
    to identify the authenticated user.
    """
    try:
        # Validate and parse the message
        context_message = CloudUserContextMessage(**message)

        # Check version compatibility
        if context_message.version > 1:
            logger.warning(
                f"Received cloud_user_context with unsupported version: "
                f"{context_message.version}. Some fields may be ignored."
            )

        # Store the user context
        user_context = context_message.to_context()
        manager.set_user_context(websocket, user_context)

        # Send acknowledgment
        await websocket.send_text(
            json.dumps(
                {
                    "type": "cloud_user_context_ack",
                    "status": "ok",
                    "user_login": user_context.user_login,
                }
            )
        )

    except Exception as e:
        logger.error(f"Failed to process cloud_user_context message: {e}")
        await websocket.send_text(
            json.dumps(
                {
                    "type": "cloud_user_context_ack",
                    "status": "error",
                    "error": str(e),
                }
            )
        )


async def broadcast(data: str):
    """Broadcast a message to all connected WebSocket clients."""
    manager = get_connection_manager()
    for client in manager.clients:
        try:
            await client.send_text(data)
        except Exception as e:
            logger.debug(f"Failed to send to client: {e}")


@app.post("/api/connect")
async def generate_connect_to_cloud_url(background_tasks: BackgroundTasks):
    if is_callback_server_running():
        return {"connection_url": get_connection_url()}

    private_key, public_key = generate_key_pair()
    connection_url, callback_port = prepare_connection_url(public_key)

    background_tasks.add_task(connect_to_cloud_background_task, private_key, callback_port, connection_url)
    return {
        "connection_url": connection_url,
    }


@app.get("/api/users")
async def get_user_info():
    from recce.connect_to_cloud import RecceCloud

    context = default_context()
    user_token = get_recce_api_token() or context.state_loader.token
    cloud = RecceCloud(user_token)
    try:
        user_info = cloud.get_user_info()
        return user_info
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.get("/api/connection-info")
async def get_connection_info():
    """Return non-sensitive connection parameters from the loaded dbt profile."""
    context = default_context()
    user_token = get_recce_api_token() or context.state_loader.token
    if not user_token:
        raise HTTPException(status_code=401, detail="Not authenticated with Recce Cloud")

    adapter = context.adapter
    runtime_config = getattr(adapter, "runtime_config", None)
    if runtime_config is None:
        return {"connection_info": None}

    creds = runtime_config.credentials
    info = dict(creds.connection_info())
    info["type"] = creds.type
    return {"connection_info": info}


@app.get("/api/cloud/organizations")
def list_cloud_organizations():
    """List all organizations the authenticated user has access to."""
    from recce.util.recce_cloud import RecceCloud

    context = default_context()
    user_token = get_recce_api_token() or context.state_loader.token
    if not user_token:
        raise HTTPException(status_code=401, detail="Not authenticated with Recce Cloud")

    cloud = RecceCloud(user_token)
    try:
        return {"organizations": cloud.list_organizations()}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.get("/api/cloud/organizations/{org_id}/projects")
def list_cloud_projects(org_id: str):
    """List all projects in an organization."""
    from recce.util.recce_cloud import RecceCloud

    context = default_context()
    user_token = get_recce_api_token() or context.state_loader.token
    if not user_token:
        raise HTTPException(status_code=401, detail="Not authenticated with Recce Cloud")

    cloud = RecceCloud(user_token)
    try:
        return {"projects": cloud.list_projects(org_id)}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.get("/api/cloud/organizations/{org_id}/projects/{project_id}/base-status")
def get_cloud_project_base_status(org_id: str, project_id: str):
    """Check if the project's base session needs artifact upload."""
    from recce.util.recce_cloud import RecceCloud

    context = default_context()
    user_token = get_recce_api_token() or context.state_loader.token
    if not user_token:
        raise HTTPException(status_code=401, detail="Not authenticated with Recce Cloud")

    cloud = RecceCloud(user_token)
    try:
        return {"base_needs_upload": _check_base_needs_upload(cloud, org_id, project_id)}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


def _check_base_needs_upload(cloud, org_id: str, project_id: str) -> bool:
    """Check if the project's base session exists but has no artifacts."""
    try:
        sessions = cloud.list_sessions(org_id, project_id)
        base_session = next((s for s in sessions if s.get("is_base")), None)
        if not base_session:
            return False
        return not base_session.get("adapter_type")
    except Exception as e:
        logger.warning(f"Failed to check base upload status: {e}")
        return False


class CloudUploadInput(BaseModel):
    org_id: str
    project_id: str
    session_name: str


class CloudUploadOutput(BaseModel):
    status: str
    session_id: Optional[str] = None
    session_url: Optional[str] = None
    message: Optional[str] = None


def _upload_artifacts_to_session(
    cloud,
    org_id,
    project_id,
    session_id,
    manifest_path,
    catalog_path,
    adapter_type,
    notify_completed=True,
):
    """Upload manifest + catalog to a session via presigned URLs.

    Args:
        notify_completed: Whether to call upload_completed after uploading.
            Set to False for base sessions — they don't need completion notification
            because no post-upload processing (summary, PR comment) is needed.
    """
    import requests as http_requests

    presigned_urls = cloud.get_upload_urls_by_session_id(org_id, project_id, session_id)

    with open(manifest_path, "rb") as f:
        resp = http_requests.put(presigned_urls["manifest_url"], data=f)
        if resp.status_code not in [200, 204]:
            raise Exception(f"Failed to upload manifest: {resp.text}")

    if os.path.exists(catalog_path):
        with open(catalog_path, "rb") as f:
            resp = http_requests.put(presigned_urls["catalog_url"], data=f)
            if resp.status_code not in [200, 204]:
                raise Exception(f"Failed to upload catalog: {resp.text}")

    cloud.update_session(org_id, project_id, session_id, adapter_type)
    if notify_completed:
        cloud.upload_completed(session_id)


def _maybe_upload_base_session(cloud, org_id, project_id, base_target, adapter_type) -> bool:
    """Upload base artifacts to the project's base session if it has no metadata yet.

    The base session is created when the project is created, but may not have
    artifacts uploaded. We find it via list_sessions (is_base=True) and check
    adapter_type to determine if artifacts exist.

    Returns True if base artifacts were uploaded, False otherwise.
    """
    if not base_target:
        return False

    base_manifest = os.path.join(base_target, "manifest.json")
    base_catalog = os.path.join(base_target, "catalog.json")
    if not os.path.exists(base_manifest):
        return False

    sessions = cloud.list_sessions(org_id, project_id)
    base_session = next((s for s in sessions if s.get("is_base")), None)
    if not base_session:
        return False

    if base_session.get("adapter_type"):
        return False  # Base session already has artifacts

    # Base session has no artifacts — upload them.
    # notify_completed=False: base sessions don't need post-upload processing.
    base_session_id_raw = base_session.get("id")
    if base_session_id_raw is None:
        logger.warning("Base session has no 'id' field, skipping base upload")
        return False
    base_session_id = str(base_session_id_raw).strip()
    if not base_session_id:
        logger.warning("Base session has empty 'id' field, skipping base upload")
        return False
    _upload_artifacts_to_session(
        cloud,
        org_id,
        project_id,
        base_session_id,
        base_manifest,
        base_catalog,
        adapter_type,
        notify_completed=False,
    )
    return True


@app.post("/api/cloud/upload", response_model=CloudUploadOutput)
def upload_to_cloud(input: CloudUploadInput):
    """Create Cloud sessions and upload local artifacts (base + current)."""
    from recce.util.recce_cloud import RECCE_CLOUD_BASE_URL, RecceCloud

    context = default_context()
    user_token = get_recce_api_token() or context.state_loader.token
    if not user_token:
        raise HTTPException(status_code=401, detail="Not authenticated with Recce Cloud")

    adapter = context.adapter
    if adapter is None:
        raise HTTPException(status_code=400, detail="No adapter available")

    # Get artifact paths from the adapter
    curr_target = getattr(adapter, "target_path", None)
    if not curr_target:
        raise HTTPException(status_code=400, detail="Current target path not available")

    curr_manifest = os.path.join(curr_target, "manifest.json")
    curr_catalog = os.path.join(curr_target, "catalog.json")
    if not os.path.exists(curr_manifest):
        raise HTTPException(status_code=400, detail="manifest.json not found in current target")

    base_target = getattr(adapter, "base_path", None)

    # Read the warehouse adapter type (e.g., "postgres", "snowflake") from manifest metadata.
    # context.adapter_type is the framework type ("dbt"/"sqlmesh"), not what Cloud expects.
    with open(curr_manifest, "r", encoding="utf-8") as f:
        manifest_data = json.load(f)
    adapter_type = manifest_data.get("metadata", {}).get("adapter_type")
    if not isinstance(adapter_type, str) or not adapter_type.strip():
        raise HTTPException(
            status_code=400,
            detail="manifest.json is missing required metadata.adapter_type",
        )

    cloud = RecceCloud(user_token)

    try:
        # Upload base artifacts if the project's base session lacks metadata.
        _maybe_upload_base_session(
            cloud,
            input.org_id,
            input.project_id,
            base_target,
            adapter_type,
        )

        # Create current session and upload artifacts
        session = cloud.create_session(
            org_id=input.org_id,
            project_id=input.project_id,
            name=input.session_name,
            adapter_type=adapter_type,
        )
        session_id_raw = session.get("id") or session.get("session_id")
        session_id = str(session_id_raw).strip() if session_id_raw is not None else ""
        if not session_id:
            raise HTTPException(status_code=400, detail="Cloud returned a session with no ID")
        _upload_artifacts_to_session(
            cloud,
            input.org_id,
            input.project_id,
            session_id,
            curr_manifest,
            curr_catalog,
            adapter_type,
        )

        session_url = f"{RECCE_CLOUD_BASE_URL}/launch/{session_id}"

        return CloudUploadOutput(
            status="success",
            session_id=session_id,
            session_url=session_url,
        )
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


class WarehouseSetupInput(BaseModel):
    org_id: str
    project_id: str
    connection_name: str
    config: dict


class WarehouseSetupOutput(BaseModel):
    status: str
    warehouse_connection_id: Optional[str] = None
    message: Optional[str] = None


@app.post("/api/cloud/warehouse-setup", response_model=WarehouseSetupOutput)
async def setup_warehouse(input: WarehouseSetupInput):
    """Create a warehouse connection in Cloud and bind it to the project."""
    from recce.util.recce_cloud import RecceCloud

    context = default_context()
    user_token = get_recce_api_token() or context.state_loader.token
    if not user_token:
        raise HTTPException(status_code=401, detail="Not authenticated with Recce Cloud")

    cloud = RecceCloud(user_token)
    try:
        connection = cloud.create_warehouse_connection(
            org_id=input.org_id,
            name=input.connection_name,
            config=input.config,
        )
        connection_id_raw = connection.get("id")
        if connection_id_raw is None:
            raise HTTPException(
                status_code=400,
                detail="Cloud returned a warehouse connection with no ID",
            )
        connection_id = str(connection_id_raw).strip()
        if not connection_id:
            raise HTTPException(
                status_code=400,
                detail="Cloud returned a warehouse connection with no ID",
            )

        try:
            cloud.bind_warehouse_connection_to_project(
                org_id=input.org_id,
                project_id=input.project_id,
                warehouse_connection_id=connection_id,
            )
        except Exception as bind_err:
            logger.error(
                f"Failed to bind warehouse connection {connection_id} to project "
                f"{input.project_id}: {bind_err}. Orphaned connection may need manual cleanup."
            )
            raise

        return WarehouseSetupOutput(
            status="success",
            warehouse_connection_id=connection_id,
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


api_prefix = "/api"
app.include_router(check_router, prefix=api_prefix)
app.include_router(check_events_router, prefix=api_prefix)
app.include_router(run_router, prefix=api_prefix)

static_folder_path = Path(__file__).parent / "data"

app.mount("/", StaticFiles(directory=static_folder_path, html=True), name="static")
