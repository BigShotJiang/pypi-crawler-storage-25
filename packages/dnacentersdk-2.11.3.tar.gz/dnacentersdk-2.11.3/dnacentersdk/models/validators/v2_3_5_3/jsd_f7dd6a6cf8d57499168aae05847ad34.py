# -*- coding: utf-8 -*-
"""Cisco DNA Center CreateSensorTestTemplate data model.

Copyright (c) 2019-2021 Cisco Systems.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""


import json
from builtins import *

import fastjsonschema

from dnacentersdk.exceptions import MalformedRequest


class JSONSchemaValidatorF7Dd6A6Cf8D57499168Aae05847Ad34(object):
    """CreateSensorTestTemplate request schema definition."""

    def __init__(self):
        super(JSONSchemaValidatorF7Dd6A6Cf8D57499168Aae05847Ad34, self).__init__()
        self._validator = fastjsonschema.compile(
            json.loads(
                """{
                "$schema": "http://json-schema.org/draft-04/schema#",
                "properties": {
                "apCoverage": {
                "items": {
                "properties": {
                "bands": {
                "type": "string"
                },
                "numberOfApsToTest": {
                "type": "string"
                },
                "rssiThreshold": {
                "type": "string"
                }
                },
                "type": "object"
                },
                "type": "array"
                },
                "connection": {
                "type": "string"
                },
                "modelVersion": {
                "type": "integer"
                },
                "name": {
                "type": "string"
                },
                "ssids": {
                "items": {
                "properties": {
                "authType": {
                "type": "string"
                },
                "categories": {
                "items": {
                "type": "string"
                },
                "type": "array"
                },
                "profileName": {
                "type": "string"
                },
                "psk": {
                "type": "string"
                },
                "qosPolicy": {
                "type": "string"
                },
                "ssid": {
                "type": "string"
                },
                "tests": {
                "items": {
                "properties": {
                "config": {
                "items": {
                "type": "object"
                },
                "type": "array"
                },
                "name": {
                "type": "string"
                }
                },
                "type": "object"
                },
                "type": "array"
                },
                "thirdParty": {
                "properties": {
                "selected": {
                "type": "boolean"
                }
                },
                "type": "object"
                }
                },
                "type": "object"
                },
                "type": "array"
                }
                },
                "type": "object"
                }""".replace(
                    "\n" + " " * 16, ""
                )
            )
        )

    def validate(self, request):
        try:
            self._validator(request)
        except fastjsonschema.exceptions.JsonSchemaException as e:
            raise MalformedRequest(
                "{} is invalid. Reason: {}".format(request, e.message)
            )
