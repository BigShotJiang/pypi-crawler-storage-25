from torch_tk.test import add


def test_add():
    assert add(2, 2) == 4
