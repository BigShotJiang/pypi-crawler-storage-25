"""Quick smoke test for the MCP streamable-http transport.

Usage:
    1. Start the server:  kagimcp --http --port 8000
    2. Run this script:   python test_http.py
"""

import httpx
import json
import sys

BASE_URL = "http://localhost:8000/mcp"
HEADERS = {
    "Content-Type": "application/json",
    "Accept": "application/json, text/event-stream",
}


def jsonrpc(method: str, params: dict | None = None, id: int = 1) -> dict:
    msg = {"jsonrpc": "2.0", "id": id, "method": method}
    if params:
        msg["params"] = params
    return msg


def parse_sse_response(text: str) -> dict | None:
    """Extract the JSON-RPC message from an SSE stream."""
    for line in text.splitlines():
        if line.startswith("data: "):
            return json.loads(line[len("data: "):])
    return None


def parse_response(response: httpx.Response) -> dict | None:
    ct = response.headers.get("content-type", "")
    if "text/event-stream" in ct:
        return parse_sse_response(response.text)
    elif "application/json" in ct:
        return response.json()
    return None


def main():
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8000
    base = f"http://localhost:{port}/mcp"

    with httpx.Client(timeout=10) as client:
        # 1. Initialize
        print("→ initialize")
        r = client.post(
            base,
            json=jsonrpc("initialize", {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": "test-client", "version": "0.1"},
            }),
            headers=HEADERS,
        )
        print(f"  status: {r.status_code}")
        result = parse_response(r)
        print(f"  response: {json.dumps(result, indent=2)}")

        session_id = r.headers.get("mcp-session-id")
        if not session_id:
            print("  ✗ no session id returned")
            sys.exit(1)
        print(f"  session: {session_id}")

        session_headers = {**HEADERS, "mcp-session-id": session_id}

        # 2. Initialized notification
        print("→ notifications/initialized")
        r = client.post(
            base,
            json={"jsonrpc": "2.0", "method": "notifications/initialized"},
            headers=session_headers,
        )
        print(f"  status: {r.status_code}")

        # 3. List tools
        print("→ tools/list")
        r = client.post(
            base,
            json=jsonrpc("tools/list", id=2),
            headers=session_headers,
        )
        print(f"  status: {r.status_code}")
        result = parse_response(r)
        if result and "result" in result:
            tools = result["result"].get("tools", [])
            print(f"  tools: {[t['name'] for t in tools]}")
        else:
            print(f"  response: {json.dumps(result, indent=2)}")

        print("\n✓ server is responding over HTTP")


if __name__ == "__main__":
    main()
