"""Packaged SNAPpy resources."""
