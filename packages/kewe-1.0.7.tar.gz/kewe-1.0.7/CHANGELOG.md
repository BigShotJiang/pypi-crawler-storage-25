# Changelog

All notable changes to KeWe will be documented in this file.

## [1.0.0] — 2025-05-10

### Production-Ready Release (v1.0.0)

- 994 passing tests across both CPython 3.12 and 3.14
- Full framework coverage: routing, middleware, security, WebSocket, DI, caching, monitoring, OpenAPI, telemetry, background tasks
- RPS benchmark comparison (17 test scenarios) against reference framework
- Comprehensive framework documentation (35 chapters)
- 98/100 production readiness score
- 90+ modules with full coverage

### Features

- **Routing**: Regex-based router with type converters, blueprints, class-based views, blueprint groups, URL building
- **HTTP**: HTTP/1.1, HTTP/2 (h2), HTTP/3 (aioquic), keep-alive, range requests, SSE, streaming uploads
- **Middleware**: Onion-style pipeline with priority control; CORS, compression, security headers, trusted hosts, forwarded headers, HTTPS redirect, request ID, error tracking
- **Security**: JWT (HS256/RS256), OAuth2, API Key, Basic Auth, CSRF, rate limiting, RBAC, password hashing, signed cookies, token encryption, circuit breaker
- **Dependency Injection**: `Depends()`, `Query()`, `Header()`, `Body()`, `Form()`, `File()`, `Path()`, `Security()` with scoped service lifetimes
- **WebSockets**: Built-in WS support with connection manager, broadcasting, group messaging
- **Background Tasks**: Fire-and-forget, scheduled jobs, async task processor, cleanup manager
- **Caching**: Memory/Redis backends with decorator API
- **Monitoring**: Health checks, metrics, anomaly detection, audit logging
- **OpenAPI**: Auto-generated OpenAPI 3.0 schemas with Swagger UI and ReDoc
- **Testing**: Sync/async test clients, test case classes, WebSocket testing, dependency overriding
- **Telemetry**: OpenTelemetry tracing support
- **Worker**: Multi-process worker manager with shared context and multiplexing
- **CLI**: Interactive REPL, shell commands, startup manager, file watching reloader
- **Plugins**: Extensible plugin system with database, Redis, OpenAPI, Pydantic, CORS, compression, rate limiting
- **Internationalization**: i18n support with configurable locales

## [0.9.0] — 2025-04-29

- 90 modules with full coverage
- E-Commerce real-world project validation
- 927 passing tests

## [0.8.0] — 2025-04-25

- Blog API real-world project validation
- 49 modules with full coverage
- 840 passing tests

## [0.7.0] — 2025-04-22

- Real-world project validation
- Complete documentation rebuild
- Automatic git commit integration

## [0.6.0] — 2025-04-20

- Full RFC 7807 error format coverage
- Benchmark comparison suite
- Documentation rebuild

## [0.5.x] — 2025-04-15

- P0 defect fixes
- PM-Skills layered testing
- Server hardening
- Performance optimization
- 661 test cases

## [0.4.x] — 2025-04-10

- Production benchmarks (40 test scenarios)
- Sandbox full coverage testing (144 cases)
- Chinese documentation (4 volumes)
- OpenAPI alignment with FastAPI standards
- Performance optimizations (handler param pre-compilation, ASGI body pre-allocation)
- Critical/High/Medium issue fixes
- Phantom alias cleanup

## [0.3.x] — 2025-04-05

- OpenAPI Form/File schema fixes
- Request API enhancements
- JSON fallback chain completion
- Race condition fixes in locking
- Critical production issue fixes

## [0.1.0 - 0.3.5] — 2025-03

- Initial framework skeleton
- Core routing and middleware
- Basic HTTP server
- Request/Response models
- Early plugin system
