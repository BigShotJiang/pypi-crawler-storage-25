#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.monitoring.inspector - Runtime inspector for application state and diagnostics
"""

import asyncio
from kewe.utils.compat import json
import logging
import time
import os
import signal
from typing import Dict, Any, Optional, List, Callable, Union
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
import threading
from kewe import __version__

logger = logging.getLogger(__name__)


class InspectorCommand(Enum):
    """Inspector 命令"""
    STATE = "state"
    SCALE = "scale"
    RELOAD = "reload"
    SHUTDOWN = "shutdown"
    WORKERS = "workers"
    HEALTH = "health"
    METRICS = "metrics"


@dataclass
class WorkerInfo:
    """Worker 状态"""
    pid: int
    index: int
    state: str = "running"
    requests_handled: int = 0
    start_time: Optional[datetime] = None
    last_heartbeat: Optional[datetime] = None
    memory_usage: int = 0
    cpu_percent: float = 0.0


@dataclass
class InspectorAppState:
    """Inspector 应用状态快照"""
    name: str
    version: str = field(default_factory=lambda: __version__)
    start_time: Optional[datetime] = None
    total_requests: int = 0
    active_connections: int = 0
    workers: List[WorkerInfo] = field(default_factory=list)


class InspectorServer:
    """
    Inspector 服务器
    
    提供运行时监控和管理接口
    
    使用示例:
        inspector = InspectorServer(app, host="127.0.0.1", port=6455)
        await inspector.start()
        
        # 客户端请求
        # GET http://127.0.0.1:6455/state
        # POST http://127.0.0.1:6455/scale {"replicas": 4}
    """
    
    def __init__(
        self,
        app,
        host: str = "127.0.0.1",
        port: int = 6455,
        api_key: Optional[str] = None,
        tls_cert: Optional[str] = None,
        tls_key: Optional[str] = None
    ):
        self.app = app
        self.host = host
        self.port = port
        self.api_key = api_key
        self.tls_cert = tls_cert
        self.tls_key = tls_key
        
        self._server: Optional[asyncio.Server] = None
        self._running = False
        self._custom_handlers: Dict[str, Callable] = {}
        self._start_time: Optional[datetime] = None
        
        self._register_default_handlers()
    
    def _register_default_handlers(self):
        """注册默认处理器"""
        self._custom_handlers["state"] = self._handle_state
        self._custom_handlers["scale"] = self._handle_scale
        self._custom_handlers["reload"] = self._handle_reload
        self._custom_handlers["shutdown"] = self._handle_shutdown
        self._custom_handlers["workers"] = self._handle_workers
        self._custom_handlers["health"] = self._handle_health
        self._custom_handlers["metrics"] = self._handle_metrics
    
    def command(self, name: str) -> Callable:
        """
        注册自定义命令装饰器
        
        使用示例:
            @inspector.command("custom")
            async def handle_custom(data: dict) -> dict:
                return {"result": "ok"}
        """
        def decorator(func: Callable) -> Callable:
            self._custom_handlers[name] = func
            return func
        return decorator
    
    async def start(self):
        """启动 Inspector 服务器"""
        self._running = True
        self._start_time = datetime.now()
        
        try:
            self._server = await asyncio.start_server(
                self._handle_connection,
                self.host,
                self.port
            )
            
            logger.info(f"Inspector started on {self.host}:{self.port}")
            
            async with self._server:
                await self._server.serve_forever()
        except Exception as e:
            logger.error(f"Inspector error: {e}")
    
    async def stop(self):
        """停止 Inspector 服务器"""
        self._running = False
        if self._server:
            self._server.close()
            await self._server.wait_closed()
        logger.info("Inspector stopped")
    
    async def _handle_connection(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter
    ):
        """处理连接"""
        try:
            data = await reader.read(4096)
            if not data:
                return
            
            request = json.loads(data.decode('utf-8'))
            response = await self._process_request(request)
            
            writer.write(json.dumps(response).encode('utf-8'))
            await writer.drain()
        except json.JSONDecodeError:
            writer.write(json.dumps({"error": "Invalid JSON"}).encode('utf-8'))
            await writer.drain()
        except Exception as e:
            logger.error(f"Inspector connection error: {e}")
            writer.write(json.dumps({"error": str(e)}).encode('utf-8'))
            await writer.drain()
        finally:
            writer.close()
            await writer.wait_closed()
    
    async def _process_request(self, request: Dict[str, Any]) -> Dict[str, Any]:
        """处理请求"""
        if self.api_key:
            if request.get("api_key") != self.api_key:
                return {"error": "Unauthorized", "status": 401}
        
        command = request.get("command", "state")
        data = request.get("data", {})
        
        handler = self._custom_handlers.get(command)
        if handler:
            try:
                result = handler(data)
                if asyncio.iscoroutine(result):
                    result = await result
                return {"success": True, "data": result}
            except Exception as e:
                return {"success": False, "error": str(e)}
        
        return {"error": f"Unknown command: {command}"}
    
    async def _handle_state(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """获取应用状态"""
        state = InspectorAppState(
            name=getattr(self.app, 'name', 'KeweApp'),
            start_time=self._start_time,
            total_requests=getattr(self.app, '_request_count', 0),
            active_connections=getattr(self.app, '_active_connections', 0),
        )
        
        if hasattr(self.app, 'worker_manager'):
            for idx, info in self.app.worker_manager.get_all_worker_infos().items():
                state.workers.append(WorkerInfo(
                    pid=info.pid or 0,
                    index=idx,
                    state=info.state.value if hasattr(info.state, 'value') else str(info.state),
                    requests_handled=info.requests_handled,
                    start_time=info.start_time
                ))
        
        return {
            "name": state.name,
            "start_time": state.start_time.isoformat() if state.start_time else None,
            "uptime": (datetime.now() - self._start_time).total_seconds() if self._start_time else 0,
            "total_requests": state.total_requests,
            "active_connections": state.active_connections,
            "workers": [
                {
                    "pid": w.pid,
                    "index": w.index,
                    "state": w.state,
                    "requests_handled": w.requests_handled
                }
                for w in state.workers
            ]
        }
    
    async def _handle_scale(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """动态调整 worker 数量"""
        replicas = data.get("replicas")
        if not isinstance(replicas, int) or replicas < 1:
            return {"error": "Invalid replicas value"}
        
        if hasattr(self.app, 'worker_manager'):
            await self.app.worker_manager.scale(replicas)
            return {"replicas": replicas, "status": "scaled"}
        
        return {"error": "Worker manager not available"}
    
    async def _handle_reload(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """触发重载"""
        if hasattr(self.app, 'worker_manager'):
            await self.app.worker_manager.reload_all()
            return {"status": "reloading"}
        
        return {"error": "Worker manager not available"}
    
    async def _handle_shutdown(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """触发关闭"""
        asyncio.create_task(self._delayed_shutdown())
        return {"status": "shutting_down"}
    
    async def _delayed_shutdown(self):
        """延迟关闭"""
        await asyncio.sleep(0.5)
        if hasattr(self.app, 'worker_manager'):
            await self.app.worker_manager.stop()
    
    async def _handle_workers(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """获取 worker 详情"""
        workers = []
        
        if hasattr(self.app, 'worker_manager'):
            for idx, info in self.app.worker_manager.get_all_worker_infos().items():
                workers.append({
                    "index": idx,
                    "pid": info.pid,
                    "state": info.state.value if hasattr(info.state, 'value') else str(info.state),
                    "requests_handled": info.requests_handled,
                    "start_time": info.start_time.isoformat() if info.start_time else None,
                    "last_error": info.last_error
                })
        
        return {"workers": workers, "count": len(workers)}
    
    async def _handle_health(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """健康检查"""
        return {
            "status": "healthy",
            "uptime": (datetime.now() - self._start_time).total_seconds() if self._start_time else 0
        }
    
    async def _handle_metrics(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """获取指标"""
        metrics = {
            "requests_total": getattr(self.app, '_request_count', 0),
            "active_connections": getattr(self.app, '_active_connections', 0),
            "uptime_seconds": (datetime.now() - self._start_time).total_seconds() if self._start_time else 0,
        }
        
        if hasattr(self.app, 'router'):
            metrics["routes_count"] = len(self.app.router.get_routes())
        
        if hasattr(self.app, 'middleware_manager'):
            metrics["middlewares_count"] = len(self.app.middleware_manager.middlewares)
        
        return metrics


class InspectorClient:
    """
    Inspector 客户端
    
    用于远程管理 Kewe 应用
    
    使用示例:
        client = InspectorClient("127.0.0.1", 6455, api_key="secret")
        state = await client.get_state()
        await client.scale(4)
        await client.reload()
    """
    
    def __init__(
        self,
        host: str = "127.0.0.1",
        port: int = 6455,
        api_key: Optional[str] = None
    ):
        self.host = host
        self.port = port
        self.api_key = api_key
    
    async def _send_request(
        self,
        command: str,
        data: Dict[str, Any] = None
    ) -> Dict[str, Any]:
        """发送请求"""
        request = {
            "command": command,
            "data": data or {}
        }
        
        if self.api_key:
            request["api_key"] = self.api_key
        
        try:
            reader, writer = await asyncio.open_connection(self.host, self.port)
            
            writer.write(json.dumps(request).encode('utf-8'))
            await writer.drain()
            
            response_data = await reader.read(4096)
            writer.close()
            await writer.wait_closed()
            
            return json.loads(response_data.decode('utf-8'))
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    async def get_state(self) -> Dict[str, Any]:
        """获取应用状态"""
        return await self._send_request("state")
    
    async def scale(self, replicas: int) -> Dict[str, Any]:
        """调整 worker 数量"""
        return await self._send_request("scale", {"replicas": replicas})
    
    async def reload(self) -> Dict[str, Any]:
        """触发重载"""
        return await self._send_request("reload")
    
    async def shutdown(self) -> Dict[str, Any]:
        """触发关闭"""
        return await self._send_request("shutdown")
    
    async def get_workers(self) -> Dict[str, Any]:
        """获取 worker 详情"""
        return await self._send_request("workers")
    
    async def health_check(self) -> Dict[str, Any]:
        """健康检查"""
        return await self._send_request("health")
    
    async def get_metrics(self) -> Dict[str, Any]:
        """获取指标"""
        return await self._send_request("metrics")
    
    async def execute(self, command: str, data: Dict[str, Any] = None) -> Dict[str, Any]:
        """执行自定义命令"""
        return await self._send_request(command, data)


class Inspector:
    """
    Inspector 主类 - 整合服务器和客户端功能
    
    使用示例:
        # 服务器端
        inspector = Inspector(app)
        app.inspector = inspector
        await inspector.start()
        
        # 客户端
        from kewe.monitoring.inspector import InspectorClient
        client = InspectorClient()
        state = await client.get_state()
    """
    
    def __init__(
        self,
        app = None,
        host: str = "127.0.0.1",
        port: int = 6455,
        api_key: Optional[str] = None,
        enabled: bool = True
    ):
        self.app = app
        self.host = host
        self.port = port
        self.api_key = api_key
        self.enabled = enabled
        
        self._server: Optional[InspectorServer] = None
        self._client: Optional[InspectorClient] = None
    
    @property
    def client(self) -> InspectorClient:
        """获取客户端"""
        if self._client is None:
            self._client = InspectorClient(self.host, self.port, self.api_key)
        return self._client
    
    async def start(self):
        """启动 Inspector"""
        if not self.enabled:
            return
        
        if self.app is None:
            raise ValueError("App not set")
        
        self._server = InspectorServer(
            self.app,
            self.host,
            self.port,
            self.api_key
        )
        
        asyncio.create_task(self._server.start())
    
    async def stop(self):
        """停止 Inspector"""
        if self._server:
            await self._server.stop()
    
    def command(self, name: str) -> Callable:
        """注册自定义命令"""
        if self._server:
            return self._server.command(name)
        
        def decorator(func: Callable) -> Callable:
            return func
        return decorator


def create_inspector(
    app = None,
    host: str = "127.0.0.1",
    port: int = 6455,
    api_key: Optional[str] = None,
    enabled: bool = True
) -> Inspector:
    """创建 Inspector 实例"""
    return Inspector(app, host, port, api_key, enabled)


__all__ = [
    'Inspector',
    'InspectorServer',
    'InspectorClient',
    'InspectorCommand',
    'InspectorAppState',
    'WorkerInfo',
    'create_inspector',
]
