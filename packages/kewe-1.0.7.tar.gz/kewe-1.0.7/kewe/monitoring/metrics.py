#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.monitoring.metrics - Metrics manager for Prometheus-style application metrics
"""

import time
import logging
import threading
from typing import Dict, Any, Optional, List
from dataclasses import dataclass, field
from collections import defaultdict, Counter

logger = logging.getLogger(__name__)


@dataclass
class RequestMetrics:
    """请求指标"""
    total_requests: int = 0
    total_response_time: float = 0.0
    status_codes: Counter = field(default_factory=Counter)
    method_counts: Counter = field(default_factory=Counter)
    path_counts: Counter = field(default_factory=Counter)
    errors: int = 0
    start_time: float = field(default_factory=time.time)
    
    def reset(self):
        """重置指标"""
        self.total_requests = 0
        self.total_response_time = 0.0
        self.status_codes.clear()
        self.method_counts.clear()
        self.path_counts.clear()
        self.errors = 0
    
    def add_request(self, method: str, path: str, status: int, response_time: float, is_error: bool = False):
        """添加请求指标"""
        self.total_requests += 1
        self.total_response_time += response_time
        self.status_codes[status] += 1
        self.method_counts[method] += 1
        self.path_counts[path] += 1
        if is_error:
            self.errors += 1
    
    @property
    def average_response_time(self) -> float:
        """平均响应时间"""
        if self.total_requests == 0:
            return 0.0
        return self.total_response_time / self.total_requests
    
    @property
    def error_rate(self) -> float:
        """错误率"""
        if self.total_requests == 0:
            return 0.0
        return self.errors / self.total_requests
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            'total_requests': self.total_requests,
            'total_response_time': self.total_response_time,
            'average_response_time': self.average_response_time,
            'status_codes': dict(self.status_codes),
            'method_counts': dict(self.method_counts),
            'path_counts': dict(self.path_counts),
            'errors': self.errors,
            'error_rate': self.error_rate,
            'uptime': time.time() - self.start_time
        }


class MetricsManager:
    """指标管理器 — 统一入口，委托给MetricsCollector"""

    def __init__(self):
        from kewe.monitoring.core import MetricsCollector
        self._collector = MetricsCollector()
        self._metrics = RequestMetrics()
        self._lock = threading.Lock()
        self._custom_metrics: Dict[str, float] = {}
        self.running = False

    def start(self):
        self.running = True

    def stop(self):
        self.running = False

    def add_request(self, method: str, path: str, status: int, response_time: float, is_error: bool = False):
        with self._lock:
            self._metrics.add_request(method, path, status, response_time, is_error)
        self._collector.counter('requests_total', labels={'method': method, 'path': path, 'status': str(status)})
        self._collector.histogram('request_duration_seconds', response_time, {'method': method, 'path': path, 'status': str(status)})
        if is_error:
            self._collector.counter('errors_total', labels={'method': method, 'path': path, 'status': str(status)})

    def record_token_generated(self, token_type: str, duration: float):
        self._collector.counter("token_generated", labels={"type": token_type})
        self._collector.histogram("token_generation_duration", duration, labels={"type": token_type})

    def record_token_validated(self, validation_type: str, duration: float):
        self._collector.counter("token_validated", labels={"type": validation_type})
        self._collector.histogram("token_validation_duration", duration, labels={"type": validation_type})

    def record_token_refresh(self, duration: float = 0.0):
        self._collector.counter("token_refresh")
        if duration > 0:
            self._collector.histogram("token_refresh_duration", duration)

    def record_token_revoked(self):
        self._collector.counter("token_revoked")

    def record_anomaly(self, anomaly_type: str = "unknown"):
        self._collector.counter("anomalies_detected", labels={"type": anomaly_type})

    def get_metrics(self) -> Dict[str, Any]:
        with self._lock:
            metrics = self._metrics.to_dict()
            metrics.update(self._custom_metrics)
            return metrics

    def reset_metrics(self):
        with self._lock:
            self._metrics.reset()
        self._collector.counters.clear()
        self._collector.gauges.clear()
        self._collector.histograms.clear()

    def set_custom_metric(self, name: str, value: float):
        with self._lock:
            self._custom_metrics[name] = value
        self._collector.gauge(name, value)

    def increment_custom_metric(self, name: str, value: float = 1.0):
        with self._lock:
            if name not in self._custom_metrics:
                self._custom_metrics[name] = 0.0
            self._custom_metrics[name] += value
        self._collector.counter(name, value)

    def get_prometheus_metrics(self) -> str:
        return self._collector.get_prometheus_metrics()


# 全局指标管理器
_global_metrics_manager: Optional[MetricsManager] = None


def get_metrics_manager() -> MetricsManager:
    """获取全局指标管理器"""
    global _global_metrics_manager
    if _global_metrics_manager is None:
        _global_metrics_manager = MetricsManager()
    return _global_metrics_manager


def metrics_middleware(app):
    """
    指标收集中间件
    
    Args:
        app: Kewe应用实例
    """
    metrics_manager = get_metrics_manager()
    
    @app.middleware('request')
    async def start_request(request):
        """请求开始时记录时间"""
        request.start_time = time.time()
    
    @app.middleware('response')
    async def end_request(request, response):
        """请求结束时收集指标"""
        response_time = time.time() - request.start_time
        is_error = response.status >= 400
        
        # 收集指标
        metrics_manager.add_request(
            method=request.method,
            path=request.path,
            status=response.status,
            response_time=response_time,
            is_error=is_error
        )
        
        # 添加响应时间头
        response.headers['X-Response-Time'] = f"{response_time:.3f}s"
        
        return response


def add_health_check(app, path: str = "/health"):
    metrics_manager = get_metrics_manager()

    @app.route(path)
    async def health_check(request):
        metrics = metrics_manager.get_metrics()
        health_status = "healthy"
        if metrics.get('error_rate', 0) > 0.5:
            health_status = "unhealthy"
        from kewe.response import json as json_resp
        return json_resp({
            "status": health_status,
            "metrics": metrics
        })


def add_metrics_endpoint(app, path: str = "/metrics"):
    metrics_manager = get_metrics_manager()

    @app.route(path)
    async def metrics_endpoint(request):
        metrics = metrics_manager.get_metrics()
        from kewe.response import json as json_resp
        return json_resp(metrics)


def setup_metrics(app, health_check_path: str = "/health", metrics_path: str = "/metrics"):
    """
    设置监控和指标收集
    
    Args:
        app: Kewe应用实例
        health_check_path: 健康检查路径
        metrics_path: 指标路径
    """
    # 添加指标中间件
    metrics_middleware(app)
    
    # 添加健康检查端点
    add_health_check(app, health_check_path)
    
    # 添加指标端点
    add_metrics_endpoint(app, metrics_path)
    
    logger.info(f"Metrics setup complete: health={health_check_path}, metrics={metrics_path}")


MetricsCollector = MetricsManager

__all__ = [
    'MetricsManager',
    'MetricsCollector',
    'RequestMetrics',
    'get_metrics_manager',
    'metrics_middleware',
    'add_health_check',
    'add_metrics_endpoint',
    'setup_metrics',
]