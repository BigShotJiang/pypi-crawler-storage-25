#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.monitoring.monitoring - Unified monitoring manager combining health, metrics, and auditing
"""

from kewe.monitoring.metrics import MetricsManager
from kewe.logging.logger import get_logger


class MonitoringManager:

    def __init__(self):
        self._delegate = MetricsManager()
        self.logger = get_logger(__name__)

    def start(self):
        self._delegate.start()
        self.logger.info("监控管理器已启动")

    def stop(self):
        self._delegate.stop()
        self.logger.info("监控管理器已停止")

    def record_token_generated(self, token_type: str, duration: float):
        self._delegate.record_token_generated(token_type, duration)

    def record_token_validated(self, validation_type: str, duration: float):
        self._delegate.record_token_validated(validation_type, duration)

    def record_token_refresh(self, duration: float = 0.0):
        self._delegate.record_token_refresh(duration)

    def record_token_revoked(self):
        self._delegate.record_token_revoked()

    def record_anomaly(self, anomaly_type: str = "unknown"):
        self._delegate.record_anomaly(anomaly_type)

    def get_metrics(self) -> dict:
        return self._delegate.get_metrics()

    def reset_metrics(self):
        self._delegate.reset_metrics()

    def get_prometheus_metrics(self) -> str:
        return self._delegate.get_prometheus_metrics()
