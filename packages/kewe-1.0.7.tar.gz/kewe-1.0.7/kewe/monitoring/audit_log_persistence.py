#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.monitoring.audit_log_persistence - Audit log persistence with pluggable storage backends
"""

import time
from abc import ABC, abstractmethod
from collections import deque
from typing import Optional, Dict, Any, List
from dataclasses import dataclass
import logging


from kewe.utils.compat import json
from kewe.logging.logger import get_logger



logger = logging.getLogger(__name__)

@dataclass
class AuditLogEntry:
    """审计日志条目"""
    timestamp: int
    event_type: str
    user_id: str
    jti: Optional[str] = None
    ip_address: Optional[str] = None
    device_fingerprint: Optional[str] = None
    details: Dict[str, Any] = None

    def __post_init__(self):
        if self.details is None:
            self.details = {}


class AuditLogStorage(ABC):
    """审计日志存储基类"""

    @abstractmethod
    def save_log(self, entry: AuditLogEntry) -> bool:
        ...

    @abstractmethod
    def get_logs(self, user_id: Optional[str] = None, event_type: Optional[str] = None, limit: int = 100) -> List[AuditLogEntry]:
        ...

    @abstractmethod
    def cleanup_old_logs(self, retention_days: int = 30) -> int:
        ...

    def close(self):
        return None


class InMemoryAuditLogStorage(AuditLogStorage):

    def __init__(self, max_logs: int = 10000):
        self.logs: deque[AuditLogEntry] = deque(maxlen=max_logs)
        self.logger = get_logger(__name__)

    def save_log(self, entry: AuditLogEntry) -> bool:
        try:
            self.logs.append(entry)
            return True
        except Exception as e:
            self.logger.error(f"保存审计日志失败: {e}")
            return False

    def get_logs(self, user_id: Optional[str] = None, event_type: Optional[str] = None, limit: int = 100) -> List[AuditLogEntry]:
        """
        获取审计日志

        Args:
            user_id: 用户ID
            event_type: 事件类型
            limit: 限制数量

        Returns:
            审计日志列表
        """
        try:
            filtered_logs = list(self.logs)
            if user_id:
                filtered_logs = [log for log in filtered_logs if log.user_id == user_id]
            if event_type:
                filtered_logs = [log for log in filtered_logs if log.event_type == event_type]
            filtered_logs.sort(key=lambda x: x.timestamp, reverse=True)
            return filtered_logs[:limit]
        except Exception as e:
            self.logger.error(f"获取审计日志失败: {e}")
            return []

    def cleanup_old_logs(self, retention_days: int = 30) -> int:
        """
        清理旧日志

        Args:
            retention_days: 保留天数

        Returns:
            清理的日志数量
        """
        try:
            cutoff_time = int(time.time()) - (retention_days * 24 * 3600)
            old_count = len(self.logs)
            remaining = deque(maxlen=self.logs.maxlen)
            for log in self.logs:
                if log.timestamp > cutoff_time:
                    remaining.append(log)
            self.logs = remaining
            return old_count - len(self.logs)
        except Exception as e:
            self.logger.error(f"清理旧日志失败: {e}")
            return 0


class DatabaseAuditLogStorage(AuditLogStorage):

    def __init__(self, connection_string: str = None, table_name: str = "audit_logs", **kwargs):
        self._connection_string = connection_string
        self._table_name = table_name
        self._engine = None
        self._session_factory = None
        self._initialized = False
        self.logger = get_logger(__name__)

    def _ensure_initialized(self):
        if self._initialized:
            return
        try:
            from sqlalchemy import create_engine
            from sqlalchemy.orm import sessionmaker
            self._engine = create_engine(self._connection_string)
            self._session_factory = sessionmaker(bind=self._engine)
            self._initialized = True
        except ImportError:
            raise RuntimeError(
                "DatabaseAuditLogStorage requires SQLAlchemy. "
                "Install it with: pip install sqlalchemy"
            )

    def save_log(self, entry: AuditLogEntry) -> bool:
        self._ensure_initialized()
        try:
            from sqlalchemy import text as sql_text
            with self._session_factory() as session:
                session.execute(
                    sql_text(f"""
                        INSERT INTO {self._table_name}
                        (timestamp, event_type, user_id, jti, ip_address, device_fingerprint, details)
                        VALUES (:timestamp, :event_type, :user_id, :jti, :ip_address, :device_fingerprint, :details)
                    """),
                    {
                        "timestamp": entry.timestamp,
                        "event_type": entry.event_type,
                        "user_id": entry.user_id,
                        "jti": entry.jti,
                        "ip_address": entry.ip_address,
                        "device_fingerprint": entry.device_fingerprint,
                        "details": json.dumps(entry.details) if entry.details else None,
                    }
                )
                session.commit()
                return True
        except Exception as e:
            self.logger.error(f"保存审计日志到数据库失败: {e}")
            return False

    def get_logs(self, user_id: Optional[str] = None, event_type: Optional[str] = None, limit: int = 100) -> List[AuditLogEntry]:
        self._ensure_initialized()
        try:
            from sqlalchemy import text as sql_text
            query = f"SELECT * FROM {self._table_name} WHERE 1=1"
            params = {}
            if user_id:
                query += " AND user_id = :user_id"
                params["user_id"] = user_id
            if event_type:
                query += " AND event_type = :event_type"
                params["event_type"] = event_type
            query += " ORDER BY timestamp DESC LIMIT :limit"
            params["limit"] = limit
            with self._session_factory() as session:
                result = session.execute(sql_text(query), params)
                entries = []
                for row in result:
                    details_data = row.details
                    if isinstance(details_data, str):
                        try:
                            details_data = json.loads(details_data)
                        except Exception:
                            details_data = {}
                    elif not isinstance(details_data, dict):
                        details_data = {}
                    entries.append(AuditLogEntry(
                        timestamp=row.timestamp,
                        event_type=row.event_type,
                        user_id=row.user_id,
                        jti=row.jti if hasattr(row, 'jti') else None,
                        ip_address=row.ip_address if hasattr(row, 'ip_address') else None,
                        device_fingerprint=row.device_fingerprint if hasattr(row, 'device_fingerprint') else None,
                        details=details_data,
                    ))
                return entries
        except Exception as e:
            self.logger.error(f"从数据库获取审计日志失败: {e}")
            return []

    def cleanup_old_logs(self, max_age_days: int = 90) -> int:
        self._ensure_initialized()
        try:
            from sqlalchemy import text as sql_text
            with self._session_factory() as session:
                result = session.execute(
                    sql_text(f"""
                        DELETE FROM {self._table_name}
                        WHERE timestamp < :cutoff_timestamp
                    """),
                    {"cutoff_timestamp": int(time.time()) - (max_age_days * 24 * 3600)}
                )
                session.commit()
                return result.rowcount
        except Exception as e:
            self.logger.error(f"清理旧审计日志失败: {e}")
            return 0


class AuditLogManager:
    """审计日志管理器"""

    def __init__(self, storage: AuditLogStorage):
        self.storage = storage
        self.logger = get_logger(__name__)

    @staticmethod
    def _extract_jti(token: str) -> str:
        try:
            import base64
            parts = token.split('.')
            if len(parts) >= 2:
                payload_b64 = parts[1]
                padding = 4 - len(payload_b64) % 4
                if padding != 4:
                    payload_b64 += '=' * padding
                payload = json.loads(base64.urlsafe_b64decode(payload_b64))
                return payload.get('jti', 'unknown')
        except Exception:
            logger.warning("JWT token ID extraction failed", exc_info=True)
        return 'redacted'

    def log_token_issued(self, user_id: str, jti: str, token_type: str, ip_address: str, device_fingerprint: Optional[str]):
        """
        记录令牌发行日志

        Args:
            user_id: 用户ID
            jti: 令牌ID
            token_type: 令牌类型
            ip_address: IP地址
            device_fingerprint: 设备指纹
        """
        entry = AuditLogEntry(
            timestamp=int(time.time()),
            event_type=f"TOKEN_ISSUED_{token_type.upper()}",
            user_id=user_id,
            jti=jti,
            ip_address=ip_address,
            device_fingerprint=device_fingerprint,
            details={"token_type": token_type}
        )
        self.storage.save_log(entry)

    def log_token_refreshed(self, user_id: str, old_jti: str, new_token: str, ip_address: str, device_fingerprint: Optional[str]):
        entry = AuditLogEntry(
            timestamp=int(time.time()),
            event_type="TOKEN_REFRESHED",
            user_id=user_id,
            jti=old_jti,
            ip_address=ip_address,
            device_fingerprint=device_fingerprint,
            details={"new_jti": self._extract_jti(new_token)}
        )
        self.storage.save_log(entry)

    def log_token_revoked(self, user_id: str, jti: str, reason: str, ip_address: str):
        """
        记录令牌撤销日志

        Args:
            user_id: 用户ID
            jti: 令牌ID
            reason: 撤销原因
            ip_address: IP地址
        """
        entry = AuditLogEntry(
            timestamp=int(time.time()),
            event_type="TOKEN_REVOKED",
            user_id=user_id,
            jti=jti,
            ip_address=ip_address,
            details={"reason": reason}
        )
        self.storage.save_log(entry)

    def log_security_event(self, event_type: str, user_id: str, ip_address: str, details: Dict[str, Any]):
        """
        记录安全事件

        Args:
            event_type: 事件类型
            user_id: 用户ID
            ip_address: IP地址
            details: 详细信息
        """
        entry = AuditLogEntry(
            timestamp=int(time.time()),
            event_type=event_type,
            user_id=user_id,
            ip_address=ip_address,
            details=details
        )
        self.storage.save_log(entry)

    def get_logs(self, user_id: Optional[str] = None, event_type: Optional[str] = None, limit: int = 100) -> List[AuditLogEntry]:
        """
        获取审计日志

        Args:
            user_id: 用户ID
            event_type: 事件类型
            limit: 限制数量

        Returns:
            审计日志列表
        """
        return self.storage.get_logs(user_id, event_type, limit)

    def cleanup_old_logs(self, retention_days: int = 30) -> int:
        """
        清理旧日志

        Args:
            retention_days: 保留天数

        Returns:
            清理的日志数量
        """
        return self.storage.cleanup_old_logs(retention_days)

    def close(self):
        """关闭存储"""
        self.storage.close()




