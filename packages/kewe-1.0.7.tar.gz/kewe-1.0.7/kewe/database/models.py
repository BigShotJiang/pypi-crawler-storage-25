#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.database.models - Base model classes and declarative base for ORM
"""

import asyncio
import logging
from kewe.utils.compat import json as _json
import contextvars
from datetime import datetime, date, time, timezone
from decimal import Decimal
from enum import Enum
from typing import Any, Dict, List, Optional, Type, ClassVar
import uuid

logger = logging.getLogger(__name__)

try:
    from sqlalchemy import inspect as _sa_inspect
except ImportError:
    _sa_inspect = None

def _convert_value(value: Any) -> Any:
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, time):
        return value.isoformat()
    if isinstance(value, uuid.UUID):
        return str(value)
    if isinstance(value, Decimal):
        return float(value)
    if isinstance(value, bytes):
        return value.decode('utf-8', errors='surrogateescape')
    if isinstance(value, Enum):
        return value.value
    return value

_SQLALCHEMY_AVAILABLE = False
_DeclarativeBase = None
_mapped_column = None
_sa_inspect_available = _sa_inspect is not None

try:
    from sqlalchemy.orm import DeclarativeBase, mapped_column
    from sqlalchemy import Integer, DateTime, func
    _SQLALCHEMY_AVAILABLE = True
    _DeclarativeBase = DeclarativeBase
    _mapped_column = mapped_column
except ImportError:
    logger.debug("SQLAlchemy not available. Model base class will not be functional.")


_global_base: Optional[Type] = None
_base_registry: Dict[str, Type] = {}


def get_declarative_base(name: str = "KeweBase") -> Type:
    """
    获取或创建声明式基类

    每个数据库URL对应一个基类实例，确保多数据库支持。

    Args:
        name: 基类名称

    Returns:
        SQLAlchemy DeclarativeBase子类
    """
    global _global_base

    if not _SQLALCHEMY_AVAILABLE:
        raise ImportError(
            "SQLAlchemy is required for Model base class. "
            "Install with: pip install sqlalchemy[asyncio]"
        )

    if name in _base_registry:
        return _base_registry[name]

    class _Base(_DeclarativeBase):
        pass

    _Base.__name__ = name
    _Base.__qualname__ = name
    _base_registry[name] = _Base

    if _global_base is None:
        _global_base = _Base

    return _Base


Base = None
if _SQLALCHEMY_AVAILABLE:
    Base = get_declarative_base("KeweBase")


def _build_model_base(base_name: str = "KeweBase") -> Type:
    """
    构建Model基类 - 动态继承DeclarativeBase和混入方法

    这是核心设计：Model必须同时继承DeclarativeBase（SQLAlchemy要求）
    和提供便利方法（to_dict/to_json等）。通过动态创建中间基类实现。
    """
    if not _SQLALCHEMY_AVAILABLE:
        class _FallbackBase:
            _skip_auto_fields: ClassVar[bool] = False

            def to_dict(self, **kwargs):
                return {}

            def to_json(self, **kwargs):
                return "{}"

            @classmethod
            def from_dict(cls, data):
                raise ImportError("SQLAlchemy is required")

            def update(self, **kwargs):
                for k, v in kwargs.items():
                    if hasattr(self, k):
                        setattr(self, k, v)
                return self

        return _FallbackBase

    decl_base = _global_base or get_declarative_base(base_name)

    class _ModelBase(decl_base):
        __abstract__ = True

        _skip_auto_fields: ClassVar[bool] = False

        def to_dict(
            self,
            *,
            exclude: Optional[List[str]] = None,
            include: Optional[List[str]] = None,
            exclude_none: bool = False,
        ) -> Dict[str, Any]:
            result = {}
            try:
                mapper = _sa_inspect(type(self))
                for column in mapper.columns:
                    key = column.key
                    if exclude and key in exclude:
                        continue
                    if include and key not in include:
                        continue
                    value = getattr(self, key, None)
                    if exclude_none and value is None:
                        continue
                    result[key] = _convert_value(value)
            except Exception:
                for key in self.__dict__:
                    if key.startswith("_") or key == "sa_instance_state":
                        continue
                    if exclude and key in exclude:
                        continue
                    if include and key not in include:
                        continue
                    value = getattr(self, key)
                    if exclude_none and value is None:
                        continue
                    result[key] = _convert_value(value)

            if not exclude or '_relationships' not in exclude:
                try:
                    state = _sa_inspect(self)
                    for rel in state.mapper.relationships:
                        if exclude and rel.key in exclude:
                            continue
                        if include and rel.key not in include:
                            continue
                        try:
                            rel_value = getattr(self, rel.key, None)
                            if rel_value is None:
                                if not exclude_none:
                                    result[rel.key] = None
                                continue
                            if isinstance(rel_value, list):
                                result[rel.key] = [
                                    r.to_dict(exclude=exclude, include=include, exclude_none=exclude_none)
                                    if hasattr(r, 'to_dict') else _convert_value(r)
                                    for r in rel_value
                                ]
                            elif hasattr(rel_value, 'to_dict'):
                                result[rel.key] = rel_value.to_dict(
                                    exclude=exclude, include=include, exclude_none=exclude_none
                                )
                            else:
                                result[rel.key] = _convert_value(rel_value)
                        except Exception:
                            continue
                except Exception:
                    logger.debug("Non-critical operation failed", exc_info=True)

            return result

        def to_json(
            self,
            *,
            exclude: Optional[List[str]] = None,
            include: Optional[List[str]] = None,
            exclude_none: bool = False,
        ) -> str:
            return _json.dumps(
                self.to_dict(
                    exclude=exclude,
                    include=include,
                    exclude_none=exclude_none,
                ),
                default=str,
                ensure_ascii=False,
            )

        @classmethod
        def from_dict(cls, data: Dict[str, Any]) -> "_ModelBase":
            mapper = _sa_inspect(cls)
            valid_keys = {column.key for column in mapper.columns}
            filtered = {k: v for k, v in data.items() if k in valid_keys}
            return cls(**filtered)

        def update(self, **kwargs: Any) -> "_ModelBase":
            for key, value in kwargs.items():
                if hasattr(self, key):
                    setattr(self, key, value)
            return self

        def __repr__(self) -> str:
            try:
                mapper = _sa_inspect(type(self))
                pk_cols = [c.name for c in mapper.primary_key]
                pk_vals = {c: getattr(self, c, None) for c in pk_cols}
                pk_str = ", ".join(f"{k}={v}" for k, v in pk_vals.items())
                return f"<{self.__class__.__name__}({pk_str})>"
            except Exception:
                return f"<{self.__class__.__name__}>"

    _ModelBase.__name__ = "Model"
    _ModelBase.__qualname__ = "Model"

    return _ModelBase


Model = _build_model_base()


def _add_auto_fields(cls: Type):
    """
    为模型类自动添加通用字段

    使用__init_subclass__机制替代元类，避免与SQLAlchemy元类冲突。
    """
    if not _SQLALCHEMY_AVAILABLE:
        return

    if getattr(cls, '_skip_auto_fields', False):
        return

    if getattr(cls, '__abstract__', False):
        return

    if not hasattr(cls, '__tablename__'):
        return

    if cls.__tablename__ is None:
        return

    has_id = False
    has_created_at = False
    has_updated_at = False

    for parent in cls.__mro__[1:]:
        if parent is object:
            continue
        parent_dict = getattr(parent, '__dict__', {})
        if 'id' in parent_dict and not isinstance(parent_dict.get('id'), property):
            has_id = True
        if 'created_at' in parent_dict and not isinstance(parent_dict.get('created_at'), property):
            has_created_at = True
        if 'updated_at' in parent_dict and not isinstance(parent_dict.get('updated_at'), property):
            has_updated_at = True

    if 'id' in cls.__dict__:
        has_id = True
    if 'created_at' in cls.__dict__:
        has_created_at = True
    if 'updated_at' in cls.__dict__:
        has_updated_at = True

    if not has_id:
        cls.id = _mapped_column(
            Integer, primary_key=True, autoincrement=True
        )

    if not has_created_at:
        cls.created_at = _mapped_column(
            DateTime(timezone=True),
            server_default=func.now(),
            default=lambda: datetime.now(timezone.utc),
        )

    if not has_updated_at:
        cls.updated_at = _mapped_column(
            DateTime(timezone=True),
            server_default=func.now(),
            onupdate=lambda: datetime.now(timezone.utc),
            default=lambda: datetime.now(timezone.utc),
        )


_original_init_subclass_fn = None
if _SQLALCHEMY_AVAILABLE and hasattr(Model, '__init_subclass__'):
    raw = Model.__init_subclass__
    if hasattr(raw, '__func__'):
        _original_init_subclass_fn = raw.__func__
    else:
        _original_init_subclass_fn = raw


def _model_init_subclass(cls, **kwargs):
    _add_auto_fields(cls)
    if _original_init_subclass_fn is not None:
        _original_init_subclass_fn(cls, **kwargs)


if _SQLALCHEMY_AVAILABLE:
    Model.__init_subclass__ = classmethod(lambda cls, **kw: _model_init_subclass(cls, **kw))


def get_global_base() -> Optional[Type]:
    return _global_base


def model_to_pydantic(model_instance, pydantic_class, *, by_alias: bool = True, exclude_none: bool = False):
    """将SQLAlchemy模型实例转换为Pydantic模型实例

    使用示例:
        class UserResponse(BaseModel):
            name: str
            email: str

        user = await session.get(User, 1)
        response = model_to_pydantic(user, UserResponse)
    """
    try:
        from pydantic import BaseModel
    except ImportError:
        raise ImportError("pydantic is required for model_to_pydantic. Install with: pip install pydantic")

    if _SQLALCHEMY_AVAILABLE and hasattr(model_instance, 'to_dict'):
        data = model_instance.to_dict()
    elif isinstance(model_instance, dict):
        data = model_instance
    else:
        data = model_instance

    if isinstance(data, dict):
        return pydantic_class.model_validate(data)
    return pydantic_class.model_validate(data)


def pydantic_to_model(pydantic_instance, model_class):
    """将Pydantic模型实例转换为SQLAlchemy模型实例

    使用示例:
        class CreateUser(BaseModel):
            name: str
            email: str

        user_data = CreateUser(name="test", email="test@example.com")
        user = pydantic_to_model(user_data, User)
        session.add(user)
    """
    if hasattr(pydantic_instance, 'model_dump'):
        data = pydantic_instance.model_dump(mode='python')
    elif hasattr(pydantic_instance, 'dict'):
        data = pydantic_instance.dict()
    else:
        data = dict(pydantic_instance)

    return model_class.from_dict(data)


class NPlusOneDetector:
    """N+1查询检测器

    使用示例:
        detector = NPlusOneDetector(threshold=5, warning=True)

        async with detector.track():
            users = await session.execute(select(User))
            for user in users.scalars():
                detector.increment()
                posts = await session.execute(select(Post).where(Post.user_id == user.id))
                detector.increment()

        if detector.detected:
            logger.warning(f"N+1 detected: {detector.report}")
    """

    def __init__(self, threshold: int = 5, warning: bool = True):
        self.threshold = threshold
        self.warning = warning
        self._query_count = 0
        self._loop_count = 0
        self._detected = False
        self._reports: List[Dict[str, Any]] = []
        self._tracking = False
        self._last_query_time: Optional[float] = None

    @property
    def detected(self) -> bool:
        return self._detected

    @property
    def report(self) -> Dict[str, Any]:
        return {
            'detected': self._detected,
            'query_count': self._query_count,
            'loop_count': self._loop_count,
            'threshold': self.threshold,
            'reports': self._reports,
        }

    def increment(self, label: str = ""):
        self._query_count += 1
        if self._tracking and self._query_count > self.threshold:
            self._detected = True
            report = {
                'query_count': self._query_count,
                'label': label,
            }
            self._reports.append(report)
            if self.warning:
                import logging
                logging.getLogger(__name__).warning(
                    f"Potential N+1 query detected: {self._query_count} queries "
                    f"(threshold: {self.threshold}) {label}"
                )

    def reset(self):
        self._query_count = 0
        self._loop_count = 0
        self._detected = False
        self._reports.clear()
        self._tracking = False

    def __enter__(self):
        self._tracking = True
        return self

    def __exit__(self, *args):
        self._tracking = False

    async def __aenter__(self):
        self._tracking = True
        return self

    async def __aexit__(self, *args):
        self._tracking = False


class ConnectionPoolMonitor:
    """连接池监控器

    使用示例:
        monitor = ConnectionPoolMonitor(engine)
        stats = monitor.get_stats()
    """

    def __init__(self, engine=None):
        self._engine = engine

    def get_stats(self) -> Dict[str, Any]:
        if self._engine is None:
            return {'status': 'no_engine'}

        try:
            pool = self._engine.pool
            return {
                'status': 'active',
                'size': pool.size() if hasattr(pool, 'size') else 0,
                'checked_in': pool.checkedin() if hasattr(pool, 'checkedin') else 0,
                'checked_out': pool.checkedout() if hasattr(pool, 'checkedout') else 0,
                'overflow': pool.overflow() if hasattr(pool, 'overflow') else 0,
                'invalidated': pool.invalidated if hasattr(pool, 'invalidated') else 0,
            }
        except Exception as e:
            return {'status': 'error', 'error': str(e)}

    def health_check(self) -> Dict[str, Any]:
        stats = self.get_stats()
        if stats.get('status') != 'active':
            return {'healthy': False, 'reason': 'no_pool'}

        checked_out = stats.get('checked_out', 0)
        size = stats.get('size', 1)
        utilization = checked_out / size if size > 0 else 0

        return {
            'healthy': utilization < 0.9,
            'utilization': utilization,
            'checked_out': checked_out,
            'pool_size': size,
        }


def initialize_database(app, database_url: str, **engine_kwargs) -> "SQLAlchemyPlugin":
    from kewe.plugins.database import SQLAlchemyPlugin

    plugin = SQLAlchemyPlugin(database_url, **engine_kwargs)

    base = _global_base or get_declarative_base("KeweBase")
    plugin.set_base(base)

    plugin.setup(app)

    return plugin


_tx_depth_var: contextvars.ContextVar[int] = contextvars.ContextVar('_tx_depth', default=0)
_tx_session_var: contextvars.ContextVar[Any] = contextvars.ContextVar('_tx_session', default=None)


class transaction:

    def __init__(self, engine_or_session_factory):
        self._source = engine_or_session_factory
        self._session = None
        self._owns_session = False
        self._is_nested = False
        self._savepoint = None

    async def __aenter__(self):
        current_depth = _tx_depth_var.get()
        if hasattr(self._source, 'begin'):
            self._session = self._source
            if not self._session.in_transaction():
                await self._session.begin()
                self._owns_session = False
                _tx_depth_var.set(1)
                _tx_session_var.set(self._session)
            else:
                self._is_nested = True
                self._savepoint = await self._session.begin_nested()
                _tx_depth_var.set(current_depth + 1)
        elif hasattr(self._source, 'async_session_factory'):
            factory = self._source.async_session_factory
            self._session = factory()
            await self._session.__aenter__()
            self._owns_session = True
            _tx_depth_var.set(1)
            _tx_session_var.set(self._session)
        elif callable(self._source):
            self._session = self._source()
            if hasattr(self._session, '__aenter__'):
                await self._session.__aenter__()
            self._owns_session = True
            _tx_depth_var.set(1)
            _tx_session_var.set(self._session)
        else:
            self._session = self._source
        return self._session

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self._session is None:
            return False
        try:
            current_depth = _tx_depth_var.get()
            if self._is_nested and self._savepoint is not None:
                if exc_type is not None:
                    await self._savepoint.rollback()
                else:
                    await self._savepoint.commit()
                _tx_depth_var.set(current_depth - 1)
                return False

            if exc_type is not None:
                if hasattr(self._session, 'rollback'):
                    result = self._session.rollback()
                    if asyncio.iscoroutine(result):
                        await result
            else:
                if hasattr(self._session, 'commit'):
                    result = self._session.commit()
                    if asyncio.iscoroutine(result):
                        await result
        finally:
            if self._owns_session and hasattr(self._session, 'close'):
                result = self._session.close()
                if asyncio.iscoroutine(result):
                    await result
            new_depth = _tx_depth_var.get() - 1
            _tx_depth_var.set(max(0, new_depth))
            if new_depth <= 0:
                _tx_session_var.set(None)
        return False

