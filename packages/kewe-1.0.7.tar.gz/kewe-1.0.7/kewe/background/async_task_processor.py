#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.background.async_task_processor - Async task processor with thread pool executor
"""

import asyncio
import threading
from typing import Optional, Callable, Any, List
from concurrent.futures import ThreadPoolExecutor

from kewe.logging.logger import get_logger
import logging

logger = logging.getLogger(__name__)


class AsyncTaskProcessor:

    def __init__(self, max_workers: int = 4, max_queue_size: int = 1000):
        self.max_workers = max_workers
        self.max_queue_size = max_queue_size
        self.executor = ThreadPoolExecutor(max_workers=max_workers)
        self.loop: Optional[asyncio.AbstractEventLoop] = None
        self.thread: Optional[threading.Thread] = None
        self.running = False
        self.logger = get_logger(__name__)
        self._pending_count = 0
        self._max_queue_size = max_queue_size

    def start(self):
        if not self.running:
            self.running = True
            self.loop = asyncio.new_event_loop()
            self.thread = threading.Thread(target=self._run_loop, daemon=True)
            self.thread.start()
            self.logger.info(f"AsyncTaskProcessor started, max_workers: {self.max_workers}")

    def stop(self):
        if self.running:
            self.running = False
            if self.loop and self.loop.is_running():
                self.loop.call_soon_threadsafe(self.loop.stop)
            if self.thread:
                self.thread.join(timeout=5)
            self.executor.shutdown(wait=True)
            self.logger.info("AsyncTaskProcessor stopped")

    def _run_loop(self):
        asyncio.set_event_loop(self.loop)
        try:
            self.loop.run_forever()
        finally:
            try:
                pending = asyncio.all_tasks(self.loop)
            except RuntimeError:
                pending = set()
            for task in pending:
                task.cancel()
            if pending:
                try:
                    self.loop.run_until_complete(
                        asyncio.wait_for(
                            asyncio.gather(*pending, return_exceptions=True),
                            timeout=10.0
                        )
                    )
                except asyncio.TimeoutError:
                    self.logger.warning("Some tasks did not complete within timeout during shutdown")
            self.loop.close()

    def submit_task(self, func: Callable[..., Any], *args, **kwargs):
        if not self.running:
            self.logger.warning("AsyncTaskProcessor not running, task ignored")
            return None

        if self._pending_count >= self._max_queue_size:
            self.logger.warning(f"Task queue full (max: {self._max_queue_size}), task rejected")
            return None

        self._pending_count += 1

        if asyncio.iscoroutinefunction(func):
            future = asyncio.run_coroutine_threadsafe(func(*args, **kwargs), self.loop)
            future.add_done_callback(self._task_done_callback)
            return future
        else:
            future = self.executor.submit(func, *args, **kwargs)
            future.add_done_callback(lambda f: self._task_done_callback(f))
            return future

    def _task_done_callback(self, future):
        self._pending_count = max(0, self._pending_count - 1)
        try:
            exc = future.exception()
            if exc:
                self.logger.error(f"Async task failed: {exc}")
        except (asyncio.CancelledError, Exception):
            logger.debug("Non-critical operation failed", exc_info=True)

    @property
    def pending_count(self) -> int:
        return self._pending_count
