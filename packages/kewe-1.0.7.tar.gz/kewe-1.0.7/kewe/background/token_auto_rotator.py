#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.background.token_auto_rotator - Automatic token rotation for security credentials
"""

import time
from typing import Optional, Dict, Any, Callable, Tuple
from dataclasses import dataclass

from kewe.logging.logger import get_logger


@dataclass
class TokenRotationConfig:
    """令牌轮换配置"""
    enabled: bool = True
    strategy: str = "hybrid"
    rotation_threshold: float = 0.7
    min_rotation_interval: int = 300
    max_rotation_count: int = 10
    force_rotation_on_risk: bool = True
    max_usage_count: int = 1000


class TokenAutoRotator:

    def __init__(self, config: TokenRotationConfig, refresh_callback: Callable[[str, Dict[str, Any]], Tuple[str, str]]):
        self.config = config
        self.refresh_callback = refresh_callback
        self.tokens: Dict[str, Dict[str, Any]] = {}
        self.last_rotation_time: Dict[str, float] = {}
        self.rotation_count: Dict[str, int] = {}
        self.usage_count: Dict[str, int] = {}
        self.logger = get_logger(__name__)

    def register_token(self, token: str, token_type: str, user_id: str, issued_at: int, expires_at: int):
        """
        注册令牌到轮换器

        Args:
            token: 令牌
            token_type: 令牌类型
            user_id: 用户ID
            issued_at: 发行时间
            expires_at: 过期时间
        """
        self.tokens[token] = {
            "token_type": token_type,
            "user_id": user_id,
            "issued_at": issued_at,
            "expires_at": expires_at,
            "last_used": time.time()
        }

    def record_token_usage(self, token: str):
        if token in self.tokens:
            self.tokens[token]["last_used"] = time.time()
            self.usage_count[token] = self.usage_count.get(token, 0) + 1

    def should_rotate(self, token: str, context: Dict[str, Any]) -> bool:
        if not self.config.enabled:
            return False

        if token not in self.tokens:
            return False

        token_info = self.tokens[token]
        current_time = time.time()

        if self.config.force_rotation_on_risk and context.get("has_risk", False):
            return True

        strategy = self.config.strategy

        time_based = False
        if strategy in ("time-based", "hybrid"):
            total_lifetime = token_info["expires_at"] - token_info["issued_at"]
            remaining_lifetime = token_info["expires_at"] - current_time
            if remaining_lifetime <= 0:
                return True
            if total_lifetime > 0 and remaining_lifetime / total_lifetime < self.config.rotation_threshold:
                time_based = True

        usage_based = False
        if strategy in ("usage-based", "hybrid"):
            usage = self.usage_count.get(token, 0)
            if usage >= self.config.max_usage_count:
                usage_based = True

        should = time_based or usage_based
        if should:
            last_rotation = self.last_rotation_time.get(token, 0)
            if current_time - last_rotation < self.config.min_rotation_interval:
                return False
            rotation_count = self.rotation_count.get(token, 0)
            if rotation_count >= self.config.max_rotation_count:
                return False

        return should

    def rotate_token(self, token: str, context: Dict[str, Any]) -> Tuple[Optional[str], Optional[str]]:
        """
        轮换令牌

        Args:
            token: 旧令牌
            context: 上下文信息

        Returns:
            (新令牌, 新刷新令牌)
        """
        if not self.should_rotate(token, context):
            return None, None

        try:
            new_token, new_refresh_token = self.refresh_callback(token, context)
            if new_token:
                self.last_rotation_time[token] = time.time()
                self.rotation_count[token] = self.rotation_count.get(token, 0) + 1
                self.logger.info(f"令牌已自动轮换: user={self.tokens[token]['user_id']}")
                return new_token, new_refresh_token
        except Exception as e:
            self.logger.error(f"轮换令牌失败: {e}")

        return None, None
