#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.background.cleanup_task_manager - Background cleanup task manager
"""

import time
import threading
from typing import Optional, Callable, Dict, Any

from kewe.logging.logger import get_logger


class CleanupTaskManager:
    """后台清理任务管理器"""

    def __init__(self):
        self.tasks: Dict[str, Dict[str, Any]] = {}
        self.threads: Dict[str, threading.Thread] = {}
        self.running = False
        self.logger = get_logger(__name__)

    def start(self):
        """启动清理任务管理器"""
        if not self.running:
            self.running = True
            for task_name, task_info in self.tasks.items():
                self._start_task(task_name, task_info)
            self.logger.info("清理任务管理器已启动")

    def stop(self):
        """停止清理任务管理器"""
        if self.running:
            self.running = False
            for thread in self.threads.values():
                thread.join(timeout=5)
            self.threads.clear()
            self.logger.info("清理任务管理器已停止")

    def register_task(self, name: str, func: Callable[[], None], interval: float):
        """
        注册清理任务

        Args:
            name: 任务名称
            func: 任务函数
            interval: 执行间隔（秒）
        """
        self.tasks[name] = {
            "func": func,
            "interval": interval
        }
        if self.running:
            self._start_task(name, self.tasks[name])
        self.logger.info(f"已注册清理任务: {name}, 间隔: {interval}秒")

    def _start_task(self, name: str, task_info: Dict[str, Any]):
        """启动单个清理任务"""
        def _task_loop():
            while self.running:
                try:
                    task_info["func"]()
                except Exception as e:
                    self.logger.error(f"执行清理任务 {name} 失败: {e}")
                time.sleep(task_info["interval"])

        thread = threading.Thread(target=_task_loop, daemon=True, name=f"cleanup-{name}")
        thread.start()
        self.threads[name] = thread
