#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.background.tasks - Task scheduling and Celery integration
"""

import asyncio
import functools
import logging
import threading
from typing import Any, Callable, Optional, Dict, List
from dataclasses import dataclass
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)


# 尝试导入Celery
try:
    from celery import Celery, Task as CeleryTask
    from celery.schedules import crontab
    CELERY_AVAILABLE = True
except ImportError:
    CELERY_AVAILABLE = False
    Celery = None
    CeleryTask = object
    crontab = None


@dataclass
class TaskConfig:
    """任务配置"""
    broker_url: str = "redis://localhost:6379/0"
    result_backend: str = "redis://localhost:6379/0"
    task_serializer: str = "json"
    accept_content: List[str] = None
    result_serializer: str = "json"
    timezone: str = "UTC"
    enable_utc: bool = True
    
    def __post_init__(self):
        if self.accept_content is None:
            self.accept_content = ["json"]


class TaskManager:
    """
    任务管理器 - 管理Celery任务
    """
    
    def __init__(self, config: TaskConfig = None):
        self.config = config or TaskConfig()
        self.celery: Optional[Celery] = None
        self._background_tasks: set = set()
        
        if CELERY_AVAILABLE:
            self._init_celery()
    
    def _init_celery(self):
        """初始化Celery"""
        self.celery = Celery(
            "kewe_tasks",
            broker=self.config.broker_url,
            backend=self.config.result_backend
        )
        
        self.celery.conf.update(
            task_serializer=self.config.task_serializer,
            accept_content=self.config.accept_content,
            result_serializer=self.config.result_serializer,
            timezone=self.config.timezone,
            enable_utc=self.config.enable_utc,
        )
    
    def task(self, *args, **kwargs):
        if not CELERY_AVAILABLE:
            def fallback_decorator(func: Callable) -> Callable:
                @functools.wraps(func)
                def wrapper(*a, **kw):
                    return func(*a, **kw)
                wrapper.delay = wrapper
                wrapper.apply_async = wrapper
                return wrapper
            if args and callable(args[0]):
                return fallback_decorator(args[0])
            return fallback_decorator
        
        def decorator(func: Callable) -> Callable:
            celery_task = self.celery.task(func, **kwargs)
            return celery_task
        
        if args and callable(args[0]):
            return decorator(args[0])
        
        return decorator
    
    def schedule(self, schedule: Any, **kwargs):
        if not CELERY_AVAILABLE:
            logger.warning("Celery not available; schedule decorator will run task immediately on call")
            def fallback_decorator(func: Callable) -> Callable:
                func.delay = lambda *a, **kw: func(*a, **kw)
                return func
            return fallback_decorator
        
        def decorator(func: Callable) -> Callable:
            # 注册为周期性任务
            task = self.celery.task(func)
            
            # 添加到beat schedule
            task_name = f"{func.__module__}.{func.__name__}"
            self.celery.conf.beat_schedule = self.celery.conf.beat_schedule or {}
            self.celery.conf.beat_schedule[task_name] = {
                "task": task_name,
                "schedule": schedule,
            }
            
            return task
        
        return decorator
    
    async def run_in_background(self, coro) -> asyncio.Task:
        task = asyncio.create_task(coro)
        self._background_tasks.add(task)
        
        def _on_task_done(t: asyncio.Task):
            self._background_tasks.discard(t)
            if t.cancelled():
                return
            if exc := t.exception():
                logger.error(f"Background task failed: {exc}", exc_info=exc)
        
        task.add_done_callback(_on_task_done)
        return task
    
    async def run_with_retry(
        self,
        coro_factory: Callable,
        max_retries: int = 3,
        retry_delay: float = 1.0,
        backoff_factor: float = 2.0,
        retry_on: tuple = (Exception,),
    ) -> Any:
        last_exception = None
        for attempt in range(max_retries + 1):
            try:
                if asyncio.iscoroutinefunction(coro_factory):
                    coro = coro_factory()
                elif callable(coro_factory):
                    coro = coro_factory()
                    if asyncio.iscoroutine(coro):
                        pass
                elif asyncio.iscoroutine(coro_factory):
                    if attempt > 0:
                        raise RuntimeError(
                            "Cannot retry a coroutine object. Pass a factory function "
                            "(e.g., lambda: some_async_func()) instead of the coroutine itself."
                        )
                    coro = coro_factory
                else:
                    coro = coro_factory
                result = await coro
                return result
            except retry_on as e:
                last_exception = e
                if attempt < max_retries:
                    delay = retry_delay * (backoff_factor ** attempt)
                    logger.warning(f"Task attempt {attempt + 1}/{max_retries + 1} failed: {e}, retrying in {delay:.1f}s")
                    await asyncio.sleep(delay)
                else:
                    logger.error(f"Task failed after {max_retries + 1} attempts: {e}")
        raise last_exception
    
    def send_task(self, name: str, args: tuple = None, kwargs: dict = None, **options) -> Any:
        if not CELERY_AVAILABLE:
            raise RuntimeError(
                f"Cannot send_task('{name}'): Celery is not installed. "
                f"Install celery or use run_in_background() for local async tasks."
            )
        
        return self.celery.send_task(name, args=args, kwargs=kwargs, **options)
    
    def get_task_result(self, task_id: str) -> Any:
        if not CELERY_AVAILABLE:
            logger.warning("Celery not available; get_task_result is a no-op")
            return None
        
        result = self.celery.AsyncResult(task_id)
        return result

    async def shutdown(self):
        """优雅关闭所有后台任务"""
        for task in list(self._background_tasks):
            task.cancel()
        if self._background_tasks:
            await asyncio.gather(*self._background_tasks, return_exceptions=True)
        self._background_tasks.clear()


# 全局任务管理器
_task_manager: Optional[TaskManager] = None
_task_manager_lock = threading.Lock()


def get_task_manager() -> TaskManager:
    """获取全局任务管理器"""
    global _task_manager
    if _task_manager is None:
        with _task_manager_lock:
            if _task_manager is None:
                _task_manager = TaskManager()
    return _task_manager


def setup_tasks(app, config: TaskConfig = None):
    """
    设置任务队列
    
    使用示例:
        from kewe import Kewe
        from kewe.background.tasks import setup_tasks, TaskConfig
        
        app = Kewe("MyApp")
        setup_tasks(app, TaskConfig(broker_url="redis://localhost:6379/0"))
    """
    global _task_manager
    _task_manager = TaskManager(config)
    app.task_manager = _task_manager
    
    if hasattr(app, 'startup'):
        @app.startup
        async def on_startup():
            if CELERY_AVAILABLE and _task_manager.celery:
                print(f"Celery tasks initialized with broker: {getattr(config, 'broker_url', 'default') if config else 'default'}")
    
    if hasattr(app, 'shutdown'):
        @app.shutdown
        async def on_shutdown():
            await _task_manager.shutdown()


# 便捷装饰器
def task(*args, **kwargs):
    """
    任务装饰器快捷方式
    
    使用示例:
        from kewe.background.tasks import task
        
        @task(bind=True)
        def process_data(self, data_id: int):
            # 处理数据
            return {"processed": data_id}
    """
    manager = get_task_manager()
    return manager.task(*args, **kwargs)


def schedule(schedule: Any, **kwargs):
    """
    定时任务装饰器快捷方式
    
    使用示例:
        from kewe.background.tasks import schedule, crontab
        
        @schedule(crontab(hour=0, minute=0))
        def daily_cleanup():
            # 每日清理任务
            pass
    """
    manager = get_task_manager()
    return manager.schedule(schedule, **kwargs)


def background_task(func: Callable) -> Callable:
    """后台任务装饰器 — 标记函数为后台任务并自动注册到 BackgroundTasks

    被装饰的函数可在 handler 中通过 response.background 执行，
    也可直接作为普通异步函数调用。

    使用示例:
        @background_task
        async def send_notification(user_id: int, message: str):
            await email_service.send(user_id, message)

        @app.post("/users")
        async def create_user(request):
            from kewe.response.response import BackgroundTasks
            tasks = BackgroundTasks()
            tasks.add_task(send_notification, 123, "Hello!")
            resp = json({"ok": True})
            resp.background = tasks
            return resp
    """
    func._is_background_task = True

    @functools.wraps(func)
    async def wrapper(*args, **kwargs):
        return await func(*args, **kwargs)

    wrapper._is_background_task = True
    wrapper._original_func = func
    return wrapper


__all__ = [
    "TaskManager",
    "TaskConfig",
    "get_task_manager",
    "setup_tasks",
    "task",
    "schedule",
    "background_task",
]


def _import_background_task():
    from kewe.response.response import BackgroundTask as _BT
    return _BT


BackgroundTask = _import_background_task()

if CELERY_AVAILABLE:
    __all__.append("crontab")
