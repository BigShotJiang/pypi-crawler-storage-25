#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.cookies.signed - Signed cookie management with cryptographic verification
"""

import hmac
import hashlib
import base64
from kewe.utils.compat import json
import time
from typing import Optional, Any


class SignedCookieManager:
    """签名Cookie管理器"""
    
    def __init__(self, secret_key: str, salt: str = "kewe.cookie"):
        self.secret_key = secret_key.encode('utf-8')
        self.salt = salt.encode('utf-8')
    
    def sign(self, value: str) -> str:
        signature = hmac.new(
            self.secret_key,
            self.salt + value.encode('utf-8'),
            hashlib.sha256
        ).hexdigest()
        return f"{value}.{signature}"
    
    def unsign(self, signed_value: str, max_age: int = None) -> Optional[str]:
        """验证并解签名
        
        Args:
            signed_value: 签名后的值
            max_age: 最大有效期(秒), 仅对TimestampSigner有效
        """
        try:
            value, signature = signed_value.rsplit('.', 1)
            expected = self.sign(value)
            if hmac.compare_digest(signed_value, expected):
                return value
        except ValueError:
            pass
        return None
    
    def encode(self, data: Any) -> str:
        """编码数据为签名字符串"""
        json_str = json.dumps(data, separators=(',', ':'))
        encoded = base64.urlsafe_b64encode(json_str.encode()).decode().rstrip('=')
        return self.sign(encoded)
    
    def decode(self, signed_data: str) -> Optional[Any]:
        """解码签名数据"""
        encoded = self.unsign(signed_data)
        if encoded is None:
            return None
        
        # 添加填充
        padding = 4 - len(encoded) % 4
        if padding != 4:
            encoded += '=' * padding
        
        try:
            json_str = base64.urlsafe_b64decode(encoded).decode('utf-8')
            return json.loads(json_str)
        except Exception:
            import logging
            logging.getLogger(__name__).debug("Signed cookie decode failed", exc_info=True)
            return None


class TimestampSigner(SignedCookieManager):
    """带时间戳的签名器"""
    
    def __init__(self, secret_key: str, salt: str = "kewe.cookie", max_age: int = None):
        super().__init__(secret_key, salt)
        self.max_age = max_age
    
    def sign(self, value: str) -> str:
        """签名并添加时间戳"""
        timestamp = base64.urlsafe_b64encode(
            str(int(time.time())).encode()
        ).decode().rstrip('=')
        value = f"{value}.{timestamp}"
        return super().sign(value)
    
    def unsign(self, signed_value: str, max_age: int = None) -> Optional[str]:
        """验证签名和时间戳"""
        try:
            value, signature = signed_value.rsplit('.', 1)
        except ValueError:
            return None

        expected = SignedCookieManager.sign(self, value)
        if not hmac.compare_digest(signed_value, expected):
            return None

        try:
            value, timestamp = value.rsplit('.', 1)
            padding = 4 - len(timestamp) % 4
            if padding != 4:
                timestamp += '=' * padding

            timestamp = int(base64.urlsafe_b64decode(timestamp).decode())
            age = time.time() - timestamp

            max_age = max_age if max_age is not None else self.max_age
            if max_age and age > max_age:
                return None

            return value
        except Exception:
            import logging
            logging.getLogger(__name__).debug("TimestampSigner unsign failed", exc_info=True)
            return None


SignedCookie = SignedCookieManager


__all__ = [
    'SignedCookieManager',
    'SignedCookie',
    'TimestampSigner',
]
