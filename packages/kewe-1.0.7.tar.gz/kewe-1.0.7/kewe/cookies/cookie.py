#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.cookies.cookie - HTTP cookie handling with SameSite and security attributes
"""

import logging
from typing import Optional, Dict, Any, Union
from datetime import datetime
from enum import Enum

logger = logging.getLogger(__name__)


class SameSite(Enum):
    """
    Cookie SameSite 属性
    
    参考: https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Set-Cookie/SameSite
    
    - Strict: 完全禁止第三方 Cookie，跨站点时任何情况下都不发送
    - Lax: 大多数情况下禁止第三方 Cookie，除非导航到目标网址的 GET 请求
    - None: 允许第三方 Cookie，必须同时设置 Secure 属性
    """
    STRICT = "Strict"
    LAX = "Lax"
    NONE = "None"
    
    @classmethod
    def from_string(cls, value: str) -> 'SameSite':
        """
        从字符串创建 SameSite
        
        Args:
            value: 字符串值（不区分大小写）
            
        Returns:
            SameSite 枚举值
        """
        if value is None:
            return cls.LAX
        
        value_lower = value.lower()
        if value_lower == 'strict':
            return cls.STRICT
        elif value_lower == 'none':
            return cls.NONE
        else:
            return cls.LAX


class Cookie:
    """
    HTTP Cookie 表示
    
    Cookie实现，提供安全的默认值
    """
    __slots__ = (
        '_key', '_value', '_path', '_domain', '_secure',
        '_max_age', '_expires', '_httponly', '_samesite',
        '_partitioned', '_comment',
    )
    
    def __init__(
        self,
        key: str = None,
        value: str = "",
        *,
        name: str = None,
        path: str = "/",
        domain: Optional[str] = None,
        secure: bool = True,
        max_age: Optional[int] = None,
        expires: Optional[datetime] = None,
        httponly: bool = True,
        samesite: Optional[Union[SameSite, str]] = SameSite.LAX,
        partitioned: bool = False,
        comment: Optional[str] = None,
        host_prefix: bool = False,
        secure_prefix: bool = False
    ):
        if name is not None and key is None:
            key = name
        if key is None:
            raise TypeError("Cookie() missing required argument: 'key' or 'name'")
        """
        初始化 Cookie
        
        Args:
            key: Cookie 名称
            value: Cookie 值
            path: 路径（默认 "/"）
            domain: 域名
            secure: 是否仅 HTTPS（默认 True）
            max_age: 最大存活时间（秒）
            expires: 过期时间
            httponly: 是否禁止 JavaScript 访问
            samesite: SameSite 策略（默认 Lax）
            partitioned: 是否分区
            comment: 注释
            host_prefix: 是否添加 __Host- 前缀
            secure_prefix: 是否添加 __Secure- 前缀
        """
        if host_prefix and secure_prefix:
            raise ValueError("Cannot use both host_prefix and secure_prefix")
        
        if host_prefix:
            if path != "/":
                raise ValueError("host_prefix requires path='/'")
            if domain is not None:
                raise ValueError("host_prefix requires domain=None")
            if not secure:
                raise ValueError("host_prefix requires secure=True")
        
        if secure_prefix and not secure:
            raise ValueError("secure_prefix requires secure=True")
        
        self._key = self._make_key(key, host_prefix, secure_prefix)
        self._value = value
        self._path = path
        self._domain = domain
        self._secure = secure
        self._max_age = max_age
        self._expires = expires
        self._httponly = httponly
        self._samesite = self._normalize_samesite(samesite)
        self._partitioned = partitioned
        self._comment = comment
    
    @staticmethod
    def _make_key(key: str, host_prefix: bool, secure_prefix: bool) -> str:
        """生成带前缀的 key"""
        if host_prefix:
            return f"__Host-{key}"
        if secure_prefix:
            return f"__Secure-{key}"
        return key
    
    @staticmethod
    def _normalize_samesite(samesite: Optional[Union[SameSite, str]]) -> Optional[SameSite]:
        """规范化 SameSite 值"""
        if samesite is None:
            return SameSite.LAX
        if isinstance(samesite, SameSite):
            return samesite
        return SameSite.from_string(samesite)
    
    @property
    def key(self) -> str:
        return self._key

    @property
    def name(self) -> str:
        return self._key
    
    @property
    def value(self) -> str:
        """Cookie 值"""
        return self._value
    
    @value.setter
    def value(self, v: str):
        self._value = v
    
    @property
    def path(self) -> str:
        """路径"""
        return self._path
    
    @property
    def domain(self) -> Optional[str]:
        """域名"""
        return self._domain
    
    @property
    def secure(self) -> bool:
        """是否仅 HTTPS"""
        return self._secure
    
    @property
    def max_age(self) -> Optional[int]:
        """最大存活时间"""
        return self._max_age
    
    @property
    def expires(self) -> Optional[datetime]:
        """过期时间"""
        return self._expires
    
    @property
    def httponly(self) -> bool:
        """是否禁止 JavaScript 访问"""
        return self._httponly
    
    @property
    def samesite(self) -> Optional[SameSite]:
        """SameSite 策略"""
        return self._samesite
    
    @property
    def partitioned(self) -> bool:
        """是否分区"""
        return self._partitioned
    
    @property
    def comment(self) -> Optional[str]:
        """注释"""
        return self._comment
    
    def encode(self, encoding: str = 'utf-8') -> bytes:
        from urllib.parse import quote
        safe_value = quote(str(self._value), safe='')
        parts = [f"{self._key}={safe_value}"]
        
        if self._path:
            parts.append(f"Path={self._path}")
        
        if self._domain:
            parts.append(f"Domain={self._domain}")
        
        if self._secure:
            parts.append("Secure")
        
        if self._httponly:
            parts.append("HttpOnly")
        
        if self._max_age is not None:
            parts.append(f"Max-Age={self._max_age}")
        
        if self._expires is not None:
            if isinstance(self._expires, datetime):
                expires_str = self._expires.strftime("%a, %d %b %Y %H:%M:%S GMT")
            else:
                expires_str = str(self._expires)
            parts.append(f"Expires={expires_str}")
        
        if self._samesite:
            parts.append(f"SameSite={self._samesite.value}")
        
        if self._partitioned:
            parts.append("Partitioned")
        
        if self._comment:
            parts.append(f"Comment={self._comment}")
        
        return "; ".join(parts).encode(encoding)
    
    def __str__(self) -> str:
        return self.encode().decode('utf-8')
    
    def __repr__(self) -> str:
        return f"Cookie(key={self._key!r}, value={self._value!r})"


class CookieJar(dict):
    """
    Cookie 容器
    
    自动写入 Set-Cookie 头
    
    使用示例:
        response.cookies["session"] = Cookie("session", "abc123")
        
        response.add_cookie("test", "value", max_age=3600)
        response.delete_cookie("old_cookie")
    """
    
    def __init__(self, headers: Optional[Dict[str, str]] = None):
        """
        初始化 CookieJar
        
        Args:
            headers: 响应头字典
        """
        super().__init__()
        self._headers = headers or {}
    
    def add_cookie(
        self,
        key: str,
        value: str,
        *,
        path: str = "/",
        domain: Optional[str] = None,
        secure: bool = True,
        max_age: Optional[int] = None,
        expires: Optional[datetime] = None,
        httponly: bool = True,
        samesite: Optional[Union[SameSite, str]] = SameSite.LAX,
        partitioned: bool = False,
        comment: Optional[str] = None,
        host_prefix: bool = False,
        secure_prefix: bool = False
    ) -> Cookie:
        """
        添加 Cookie
        
        Args:
            key: Cookie 名称
            value: Cookie 值
            path: 路径
            domain: 域名
            secure: 是否仅 HTTPS
            max_age: 最大存活时间（秒）
            expires: 过期时间
            httponly: 是否禁止 JavaScript 访问
            samesite: SameSite 策略
            partitioned: 是否分区
            comment: 注释
            host_prefix: 是否添加 __Host- 前缀
            secure_prefix: 是否添加 __Secure- 前缀
            
        Returns:
            创建的 Cookie 实例
        """
        cookie = Cookie(
            key=key,
            value=value,
            path=path,
            domain=domain,
            secure=secure,
            max_age=max_age,
            expires=expires,
            httponly=httponly,
            samesite=samesite,
            partitioned=partitioned,
            comment=comment,
            host_prefix=host_prefix,
            secure_prefix=secure_prefix
        )
        
        self[key] = cookie
        self._update_headers()
        
        return cookie
    
    def delete_cookie(
        self,
        key: str,
        *,
        path: str = "/",
        domain: Optional[str] = None,
        secure: bool = True,
        httponly: bool = True,
        host_prefix: bool = False,
        secure_prefix: bool = False
    ):
        self.add_cookie(
            key=key,
            value="",
            path=path,
            domain=domain,
            secure=secure,
            max_age=0,
            httponly=httponly,
            host_prefix=host_prefix,
            secure_prefix=secure_prefix
        )

    def set(self, key: str, value: str, **kwargs) -> Cookie:
        return self.add_cookie(key, value, **kwargs)

    def add(self, cookie: Cookie) -> Cookie:
        if not isinstance(cookie, Cookie):
            raise TypeError(f"Expected Cookie, got {type(cookie).__name__}")
        self[cookie.key] = cookie
        return cookie

    def get(self, key: str, default: Any = None) -> Optional[Cookie]:
        return super().get(key, default)
    
    def _update_headers(self):
        set_cookie_headers = [str(cookie) for cookie in self.values()]
        if set_cookie_headers:
            self._headers["set-cookie"] = set_cookie_headers
        else:
            self._headers.pop("set-cookie", None)
    
    def __setitem__(self, key: str, value: Cookie):
        if not isinstance(value, Cookie):
            raise TypeError("Value must be a Cookie instance")
        super().__setitem__(key, value)
        self._update_headers()
    
    def __delitem__(self, key: str):
        super().__delitem__(key)
        self._update_headers()


__all__ = [
    'SameSite',
    'Cookie',
    'CookieJar',
]
