#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.cookies - Cookies package initialization
"""

import os
import warnings
from .signed import SignedCookieManager, TimestampSigner
from .cookie import SameSite, Cookie, CookieJar
from .session import (
    SessionConfig, Session, NullSession, SessionInterface,
    SecureCookieSessionInterface, RedisSessionInterface,
    SessionMiddleware, setup_session,
)

_default_signer = None

def _get_default_signer():
    global _default_signer
    if _default_signer is None:
        import os
        _default_signer = SignedCookieManager(secret_key=os.urandom(32).hex())
    return _default_signer

def create_signed_cookie(value: str, secret_key: str = None) -> str:
    if secret_key is None:
        warnings.warn(
            "Using default signer with random key. Cookies will not validate "
            "across restarts. Pass secret_key explicitly.",
            RuntimeWarning,
            stacklevel=2,
        )
    mgr = SignedCookieManager(secret_key=secret_key) if secret_key else _get_default_signer()
    return mgr.sign(value)

def verify_signed_cookie(signed_value: str, secret_key: str = None, max_age: int = None) -> str:
    if secret_key is None:
        warnings.warn(
            "Using default signer with random key. Cookies will not validate "
            "across restarts. Pass secret_key explicitly.",
            RuntimeWarning,
            stacklevel=2,
        )
    mgr = SignedCookieManager(secret_key=secret_key) if secret_key else _get_default_signer()
    return mgr.unsign(signed_value, max_age=max_age)

__all__ = [
    "SignedCookieManager",
    "TimestampSigner",
    "create_signed_cookie",
    "verify_signed_cookie",
    "SameSite",
    "Cookie",
    "CookieJar",
    "SessionConfig",
    "Session",
    "NullSession",
    "SessionInterface",
    "SecureCookieSessionInterface",
    "RedisSessionInterface",
    "SessionMiddleware",
    "setup_session",
]
