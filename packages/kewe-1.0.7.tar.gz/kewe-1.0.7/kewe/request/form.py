#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.request.form - Form data parsing and file upload handling
"""

from typing import Dict, List, Tuple, Optional
from urllib.parse import parse_qs


def parse_form_data(body: bytes, content_type: str = "application/x-www-form-urlencoded") -> Dict[str, List[str]]:
    """Parse form data from request body"""
    if not body:
        return {}
    
    try:
        text = body.decode('utf-8')
        return parse_qs(text, keep_blank_values=True)
    except UnicodeDecodeError:
        return {}


parse_form = parse_form_data

