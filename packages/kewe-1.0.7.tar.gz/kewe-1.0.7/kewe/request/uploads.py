#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.request.uploads - Uploaded file handling with streaming support
"""

import os
import secrets
import functools
from typing import Optional, List, Dict, Any, Callable, Union
from dataclasses import dataclass, field
from pathlib import Path
import asyncio


@dataclass
class FileStorage:
    """
    文件存储对象 - File对象
    """
    
    stream: Any  # 文件流
    filename: str
    name: str  # 表单字段名
    content_type: str = "application/octet-stream"
    headers: Dict[str, str] = field(default_factory=dict)
    _file_path: Optional[str] = None
    
    @property
    def content_length(self) -> int:
        """获取文件大小"""
        if hasattr(self.stream, 'seek') and hasattr(self.stream, 'tell'):
            current = self.stream.tell()
            self.stream.seek(0, 2)
            size = self.stream.tell()
            self.stream.seek(current)
            return size
        return 0
    
    async def save(self, destination: Union[str, Path], buffer_size: int = 16384):
        """
        保存文件到目标位置
        
        Args:
            destination: 目标路径
            buffer_size: 缓冲区大小
        """
        dest_path = Path(destination)
        dest_path.parent.mkdir(parents=True, exist_ok=True)
        
        # 如果是目录，使用原始文件名
        if dest_path.is_dir():
            safe_name = UploadManager()._secure_filename(self.filename)
            dest_path = dest_path / safe_name
        
        # 异步保存文件
        loop = asyncio.get_running_loop()
        await loop.run_in_executor(
            None, self._sync_save, dest_path, buffer_size
        )
        
        self._file_path = str(dest_path)
        return dest_path
    
    def _sync_save(self, dest_path: Path, buffer_size: int):
        """同步保存文件"""
        with open(dest_path, 'wb') as dest:
            if hasattr(self.stream, 'seek'):
                self.stream.seek(0)
            
            while True:
                chunk = self.stream.read(buffer_size)
                if not chunk:
                    break
                dest.write(chunk)
    
    async def close(self):
        if hasattr(self.stream, 'close'):
            if asyncio.iscoroutinefunction(self.stream.close):
                await self.stream.close()
            else:
                loop = asyncio.get_running_loop()
                await loop.run_in_executor(None, self.stream.close)
    
    async def __aenter__(self):
        return self
    
    async def __aexit__(self, *args):
        await self.close()
    
    async def read(self, size: int = -1) -> bytes:
        """读取文件内容"""
        if hasattr(self.stream, 'seek'):
            self.stream.seek(0)
        
        if size == -1:
            return self.stream.read()
        else:
            return self.stream.read(size)
    
    def __iter__(self):
        """迭代读取文件块"""
        if hasattr(self.stream, 'seek'):
            self.stream.seek(0)
        
        while True:
            chunk = self.stream.read(8192)
            if not chunk:
                break
            yield chunk
    
    def __aiter__(self):
        """异步迭代器"""
        return self._async_iter()
    
    async def _async_iter(self):
        """异步迭代读取"""
        if hasattr(self.stream, 'seek'):
            self.stream.seek(0)
        
        while True:
            chunk = await asyncio.get_running_loop().run_in_executor(
                None, self.stream.read, 8192
            )
            if not chunk:
                break
            yield chunk


@dataclass
class UploadConfig:
    """上传配置"""
    
    max_content_length: int = 16 * 1024 * 1024  # 16MB
    upload_folder: str = "./uploads"
    allowed_extensions: Optional[set] = None
    allowed_content_types: Optional[set] = None
    use_filename: bool = True  # 使用原始文件名还是生成随机名
    filename_generator: Optional[Callable] = None


class FileValidator:
    """
    文件验证器 - 验证上传文件
    """
    
    def __init__(
        self,
        allowed_extensions: Optional[List[str]] = None,
        allowed_content_types: Optional[List[str]] = None,
        max_size: Optional[int] = None,
        min_size: Optional[int] = None
    ):
        self.allowed_extensions = set(allowed_extensions) if allowed_extensions else None
        self.allowed_content_types = set(allowed_content_types) if allowed_content_types else None
        self.max_size = max_size
        self.min_size = min_size
    
    def validate(self, file_storage: FileStorage) -> List[str]:
        """
        验证文件
        
        Returns:
            错误列表，空列表表示验证通过
        """
        errors = []
        
        # 验证扩展名
        if self.allowed_extensions:
            ext = Path(file_storage.filename).suffix.lower()
            if ext not in self.allowed_extensions:
                errors.append(f"File extension '{ext}' is not allowed. Allowed: {self.allowed_extensions}")
        
        # 验证Content-Type
        if self.allowed_content_types:
            if file_storage.content_type not in self.allowed_content_types:
                errors.append(f"Content type '{file_storage.content_type}' is not allowed")
        
        # 验证文件大小
        size = file_storage.content_length
        
        if self.max_size and size > self.max_size:
            errors.append(f"File size {size} exceeds maximum {self.max_size}")
        
        if self.min_size and size < self.min_size:
            errors.append(f"File size {size} is less than minimum {self.min_size}")
        
        return errors


class UploadManager:
    """
    上传管理器 - 管理文件上传
    """
    
    def __init__(self, config: UploadConfig = None):
        self.config = config or UploadConfig()
        self.validators: List[FileValidator] = []
    
    def add_validator(self, validator: FileValidator):
        """添加验证器"""
        self.validators.append(validator)
    
    def generate_filename(self, original_filename: str) -> str:
        """生成文件名"""
        if self.config.filename_generator:
            return self.config.filename_generator(original_filename)
        
        if self.config.use_filename:
            # 安全化文件名
            safe_name = self._secure_filename(original_filename)
            # 添加时间戳避免冲突
            name, ext = os.path.splitext(safe_name)
            timestamp = secrets.token_hex(4)
            return f"{name}_{timestamp}{ext}"
        else:
            # 生成随机文件名
            ext = Path(original_filename).suffix
            random_name = secrets.token_hex(16)
            return f"{random_name}{ext}"
    
    def _secure_filename(self, filename: str) -> str:
        """安全化文件名"""
        # 移除路径分隔符
        filename = os.path.basename(filename)
        
        # 移除危险字符
        keep_chars = (' ', '.', '_', '-')
        filename = "".join(c for c in filename if c.isalnum() or c in keep_chars)
        
        return filename.strip(' .')
    
    async def save_file(
        self,
        file_storage: FileStorage,
        folder: str = None,
        filename: str = None
    ) -> Path:
        """
        保存上传的文件
        
        Args:
            file_storage: 文件存储对象
            folder: 子文件夹
            filename: 自定义文件名
            
        Returns:
            保存的文件路径
        """
        # 验证文件
        for validator in self.validators:
            errors = validator.validate(file_storage)
            if errors:
                raise ValueError(f"File validation failed: {', '.join(errors)}")
        
        # 确定目标路径
        upload_folder = Path(self.config.upload_folder)
        if folder:
            upload_folder = upload_folder / folder
        
        upload_folder.mkdir(parents=True, exist_ok=True)
        
        # 确定文件名
        if not filename:
            filename = self.generate_filename(file_storage.filename)
        
        dest_path = upload_folder / filename
        
        # 保存文件
        await file_storage.save(dest_path)
        
        return dest_path
    
    async def save_files(
        self,
        file_storages: List[FileStorage],
        folder: str = None
    ) -> List[Path]:
        """保存多个文件"""
        paths = []
        for file_storage in file_storages:
            path = await self.save_file(file_storage, folder)
            paths.append(path)
        return paths


def upload_required(
    field_name: str = "file",
    max_size: int = None,
    allowed_extensions: List[str] = None
):
    """
    文件上传必需装饰器
    
    使用示例:
        @app.route("/upload", methods=["POST"])
        @upload_required(field_name="avatar", max_size=5*1024*1024, allowed_extensions=[".jpg", ".png"])
        async def upload_avatar(request):
            file = request.files.get("avatar")
            # 处理文件...
    """
    def decorator(func: Callable):
        @functools.wraps(func)
        async def wrapper(request, *args, **kwargs):
            if not hasattr(request, 'files') or field_name not in request.files:
                from kewe.response import json
                return json({"error": f"Missing file field: {field_name}"}, status=400)
            
            file_storage = request.files[field_name]
            
            # 验证
            validator = FileValidator(
                allowed_extensions=allowed_extensions,
                max_size=max_size
            )
            errors = validator.validate(file_storage)
            
            if errors:
                from kewe.response import json
                return json({"error": errors[0]}, status=400)
            
            return await func(request, *args, **kwargs)
        return wrapper
    return decorator


__all__ = [
    "FileStorage",
    "UploadConfig",
    "FileValidator",
    "UploadManager",
    "upload_required",
]

