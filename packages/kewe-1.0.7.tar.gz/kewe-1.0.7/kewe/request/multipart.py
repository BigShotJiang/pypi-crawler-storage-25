#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.request.multipart - Multipart form data parser
"""

import re
from typing import Dict, List
from dataclasses import dataclass

from kewe.request.multipart_stream import (
    MultipartField,
    MultipartParser,
    MultipartParserConfig,
    extract_boundary,
)


@dataclass
class FileUpload:
    filename: str
    content_type: str
    data: bytes


def parse_multipart(body: bytes, boundary: str) -> Dict[str, List]:
    """Parse multipart form data (同步模式，委托给 MultipartParser)

    对于大文件上传场景，建议直接使用 MultipartParser 的流式解析。
    """
    if not body or not boundary:
        return {}

    result = {}
    config = MultipartParserConfig()
    parser = MultipartParser(config)

    try:
        fields = parser.parse(body, boundary)
        for field in fields:
            if field.is_file:
                upload = FileUpload(
                    filename=field.filename or 'upload',
                    content_type=field.content_type or 'application/octet-stream',
                    data=field.data or b'',
                )
                result.setdefault(field.name, []).append(upload)
            else:
                value = field.data.decode('utf-8', errors='surrogateescape') if isinstance(field.data, bytes) else str(field.data)
                result.setdefault(field.name, []).append(value)
    except Exception:
        boundary_bytes = f"--{boundary}".encode()
        parts = body.split(boundary_bytes)
        for part in parts:
            part = part.strip()
            if not part or part == b'--':
                continue
            if b'\r\n\r\n' in part:
                headers_bytes, content = part.split(b'\r\n\r\n', 1)
                content = content.rstrip(b'\r\n')
                headers = headers_bytes.decode('utf-8', errors='surrogateescape')
                disposition_match = re.search(
                    r'Content-Disposition: form-data; name="([^"]+)"(?:; filename="([^"]*)")?',
                    headers
                )
                if disposition_match:
                    field_name = disposition_match.group(1)
                    filename = disposition_match.group(2)
                    if filename:
                        import os
                        filename = os.path.basename(filename)
                        filename = re.sub(r'[^\w.\-]', '_', filename).lstrip('.') or 'upload'
                        content_type_match = re.search(r'Content-Type: (.+)', headers)
                        content_type = content_type_match.group(1).strip() if content_type_match else 'application/octet-stream'
                        upload = FileUpload(filename=filename, content_type=content_type, data=content)
                        result.setdefault(field_name, []).append(upload)
                    else:
                        result.setdefault(field_name, []).append(content.decode('utf-8', errors='surrogateescape'))

    return result
