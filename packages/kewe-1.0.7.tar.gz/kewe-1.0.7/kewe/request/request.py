#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.request.request - HTTP request object with body, form, and file accessors
"""

import logging
import os
from typing import Dict, Any, List, Optional, Union, AsyncGenerator, Callable
from dataclasses import dataclass, field
from urllib.parse import parse_qs
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from collections import namedtuple
import asyncio

from kewe.base.context import RequestContextManager, g
from kewe.utils.compat import json as _json
from kewe.http.headers import Headers

_SocketInfo = namedtuple('SocketInfo', ['ip', 'port'])


class _ConnInfo:
    """连接信息 — 连接信息

    封装 client, server, ssl 等连接信息。
    """

    __slots__ = ('_request',)

    def __init__(self, request):
        self._request = request

    @property
    def client(self):
        return self._request.client

    @property
    def server(self):
        return self._request.server

    @property
    def ssl(self):
        return self._request.is_secure

    @property
    def ip(self):
        return self._request.client_ip or self._request.remote_addr

    @property
    def port(self):
        return self._request.port

logger = logging.getLogger(__name__)


class UserAgent:
    """User-Agent 解析对象

    提供轻量级的 User-Agent 解析，支持 .string/.browser/.platform/.version 属性。
    """

    __slots__ = ('_string', '_browser', '_platform', '_version')

    _BROWSER_PATTERNS = [
        ('Edg', 'Edge'), ('OPR', 'Opera'), ('Chrome', 'Chrome'),
        ('Firefox', 'Firefox'), ('Safari', 'Safari'), ('MSIE', 'IE'),
        ('Trident', 'IE'),
    ]
    _PLATFORM_PATTERNS = [
        ('Windows', 'Windows'), ('Mac OS', 'macOS'), ('Linux', 'Linux'),
        ('Android', 'Android'), ('iPhone', 'iOS'), ('iPad', 'iOS'),
    ]

    def __init__(self, ua_string: str = ''):
        self._string = ua_string
        self._browser = None
        self._platform = None
        self._version = None

    @property
    def string(self) -> str:
        return self._string

    @property
    def browser(self) -> Optional[str]:
        if self._browser is None:
            self._browser = ''
            for pattern, name in self._BROWSER_PATTERNS:
                idx = self._string.find(pattern)
                if idx != -1:
                    self._browser = name
                    ver_start = idx + len(pattern)
                    if ver_start < len(self._string) and self._string[ver_start] == '/':
                        ver_end = ver_start + 1
                        while ver_end < len(self._string) and self._string[ver_end] not in (' ', ';', ')'):
                            ver_end += 1
                        self._version = self._string[ver_start + 1:ver_end] or None
                    break
        return self._browser or None

    @property
    def platform(self) -> Optional[str]:
        if self._platform is None:
            self._platform = ''
            for pattern, name in self._PLATFORM_PATTERNS:
                if pattern in self._string:
                    self._platform = name
                    break
        return self._platform or None

    @property
    def version(self) -> Optional[str]:
        if self._version is None:
            self.browser
        return self._version

    def __str__(self) -> str:
        return self._string

    def __repr__(self) -> str:
        return f"UserAgent({self._string!r})"

    def __bool__(self) -> bool:
        return bool(self._string)


class _AwaitableProperty:
    """使属性同时支持同步和异步访问的包装器

    当 request._full_body 尚未设置时（如流式请求），
    request.json 返回此对象，用户可以 await 它获取数据。

    使用示例:
        data = request.json       # 同步访问（body 已预解析时）
        data = await request.json # 异步访问（body 未预解析时）
    """

    def __init__(self, request, prop_name):
        self._request = request
        self._prop_name = prop_name

    def __await__(self):
        async def _resolve():
            if self._prop_name == 'json':
                return await self._request.json_async
            elif self._prop_name == 'form':
                return await self._request.form_async
            elif self._prop_name == 'files':
                return await self._request.files_async
            return None
        return _resolve().__await__()

    def __bool__(self):
        import warnings
        warnings.warn(
            f"request.{self._prop_name} returned an _AwaitableProperty because "
            f"the request body has not been parsed yet. "
            f"Use 'await request.{self._prop_name}' or read the body first. "
            f"This will raise an error in a future version.",
            RuntimeWarning,
            stacklevel=3,
        )
        return False

    def __repr__(self):
        return f'<AwaitableProperty {self._prop_name} - use await or ensure body is pre-parsed>'

    def __getitem__(self, key):
        raise TypeError(
            f"Cannot access {self._prop_name}['{key}'] synchronously. "
            f"Body not yet parsed. Use 'await request.{self._prop_name}' instead, "
            f"or ensure the request body has been read first."
        )

    def __iter__(self):
        raise TypeError(
            f"Cannot iterate request.{self._prop_name} synchronously. "
            f"Body not yet parsed. Use 'await request.{self._prop_name}' instead."
        )

    def __str__(self):
        return self.__repr__()


class _MIMEAccept:
    def __init__(self, items: List[tuple]):
        self._items = items
        self._mimetypes = [m for m, _ in items]

    def __getitem__(self, index):
        return self._mimetypes[index]

    def __iter__(self):
        return iter(self._mimetypes)

    def __len__(self):
        return len(self._mimetypes)

    def __bool__(self):
        return bool(self._mimetypes)

    def __contains__(self, mimetype):
        return any(self._match(m, mimetype) for m in self._mimetypes)

    def __repr__(self):
        return f"MIMEAccept({self._items})"

    @staticmethod
    def _match(pattern, mimetype):
        if pattern == '*/*':
            return True
        if pattern.endswith('/*'):
            return mimetype.startswith(pattern[:-1])
        return pattern.lower() == mimetype.lower()

    def quality(self, mimetype: str) -> float:
        for m, q in self._items:
            if self._match(m, mimetype):
                return q
        return 0.0

    def best_match(self, offers: List[str]) -> Optional[str]:
        best = None
        best_q = -1.0
        for offer in offers:
            q = self.quality(offer)
            if q > best_q:
                best_q = q
                best = offer
        return best if best_q > 0 else None


class RequestCacheControl:
    """Cache-Control 头解析

    提供语义化属性访问 Cache-Control 指令。
    """
    def __init__(self, header: str = ''):
        self._header = header
        self._directives: Dict[str, Optional[str]] = {}
        for part in header.split(','):
            part = part.strip().lower()
            if '=' in part:
                key, value = part.split('=', 1)
                self._directives[key.strip()] = value.strip()
            elif part:
                self._directives[part] = None

    @property
    def no_cache(self) -> bool:
        return 'no-cache' in self._directives

    @property
    def no_store(self) -> bool:
        return 'no-store' in self._directives

    @property
    def max_age(self) -> Optional[int]:
        val = self._directives.get('max-age')
        if val is not None:
            try:
                return int(val)
            except (ValueError, TypeError):
                return None
        return None

    @property
    def no_transform(self) -> bool:
        return 'no-transform' in self._directives

    @property
    def must_revalidate(self) -> bool:
        return 'must-revalidate' in self._directives

    @property
    def proxy_revalidate(self) -> bool:
        return 'proxy-revalidate' in self._directives

    @property
    def s_maxage(self) -> Optional[int]:
        val = self._directives.get('s-maxage')
        if val is not None:
            try:
                return int(val)
            except (ValueError, TypeError):
                return None
        return None

    @property
    def public(self) -> bool:
        return 'public' in self._directives

    @property
    def private(self) -> bool:
        return 'private' in self._directives

    @property
    def immutable(self) -> bool:
        return 'immutable' in self._directives

    @property
    def stale_while_revalidate(self) -> Optional[int]:
        val = self._directives.get('stale-while-revalidate')
        if val is not None:
            try:
                return int(val)
            except (ValueError, TypeError):
                return None
        return None

    def to_header(self) -> str:
        return self._header

    def __repr__(self) -> str:
        return f"RequestCacheControl({self._header!r})"


class _QueryArgs:
    """
    查询参数 - 完整的 dict-like 接口
    QueryParams 实现
    
    支持多值参数（如 ?a=1&a=2），默认取第一个值，
    使用 getlist() 获取所有值。
    """
    def __init__(self, data: Dict[str, List[str]]):
        self._data = data

    def get(self, key: str, default: Any = None) -> Any:
        values = self._data.get(key)
        if values is None:
            return default
        if isinstance(values, list):
            return values[0] if values else default
        return values

    def getlist(self, key: str) -> List[Any]:
        values = self._data.get(key, [])
        if isinstance(values, list):
            return list(values)
        if values is None:
            return []
        return [values]

    def items(self):
        for key in self._data:
            yield key, self.get(key)

    def items_raw(self):
        for key, values in self._data.items():
            yield key, values

    def multi_items(self):
        for key, values in self._data.items():
            for value in values:
                yield key, value

    def keys(self):
        return self._data.keys()

    def values(self):
        for key in self._data:
            yield self.get(key)

    def to_dict(self, *, flat: bool = True) -> Dict[str, Any]:
        if flat:
            return {key: self.get(key) for key in self._data}
        return {key: self.getlist(key) for key in self._data}

    def __contains__(self, key: str) -> bool:
        return key in self._data

    def __getitem__(self, key: str) -> Any:
        if key not in self._data:
            raise KeyError(key)
        return self.get(key)

    def __iter__(self):
        return iter(self._data)

    def __len__(self) -> int:
        return len(self._data)

    def __eq__(self, other):
        if isinstance(other, _QueryArgs):
            return self._data == other._data
        if isinstance(other, dict):
            return self.to_dict() == other
        return NotImplemented

    def __repr__(self) -> str:
        return f"QueryArgs({self.to_dict()})"

    def __bool__(self) -> bool:
        return bool(self._data)

    def pop(self, key: str, *args):
        if key in self._data:
            values = self._data.pop(key)
            if isinstance(values, list):
                return values[0] if values else None
            return values
        if args:
            return args[0]
        raise KeyError(key)

    def update(self, data: Dict[str, Any]):
        for key, value in data.items():
            if isinstance(value, list):
                self._data[key] = value
            else:
                self._data[key] = [str(value)]

    def setdefault(self, key: str, default: Any = None):
        if key not in self._data:
            if isinstance(default, list):
                self._data[key] = default
            else:
                self._data[key] = [str(default)] if default is not None else []
        return self.get(key)


@dataclass
class UploadedFile:
    name: str
    filename: str
    content_type: str
    body: bytes = b''
    _temp_file: Optional[str] = field(default=None, repr=False)
    _stream_parser: Any = field(default=None, repr=False)

    @property
    def size(self) -> int:
        if self._temp_file:
            try:
                return os.path.getsize(self._temp_file)
            except OSError:
                pass
        return len(self.body)

    @property
    def stream(self):
        import io
        if self._temp_file:
            return open(self._temp_file, 'rb')
        return io.BytesIO(self.body)

    async def read(self, chunk_size: int = -1) -> bytes:
        """流式读取文件内容"""
        if self._temp_file:
            loop = asyncio.get_running_loop()
            if chunk_size == -1:
                return await loop.run_in_executor(None, self._read_temp_file)
            else:
                return await loop.run_in_executor(None, self._read_temp_file_chunked, chunk_size)
        if chunk_size == -1:
            return self.body
        return self.body[:chunk_size]

    def _read_temp_file(self) -> bytes:
        with open(self._temp_file, 'rb') as f:
            return f.read()

    def _read_temp_file_chunked(self, chunk_size: int) -> bytes:
        if not hasattr(self, '_chunk_handle') or self._chunk_handle is None:
            self._chunk_handle = open(self._temp_file, 'rb')
        else:
            # Close and reopen if handle exists but is stale
            try:
                self._chunk_handle.close()
            except Exception:
                pass
            self._chunk_handle = open(self._temp_file, 'rb')
        data = self._chunk_handle.read(chunk_size)
        if not data:
            self._chunk_handle.close()
            self._chunk_handle = None
        return data

    def save(self, path: str, allowed_dir: Optional[str] = None, chunk_size: int = 65536):
        import os
        abs_path = os.path.normpath(os.path.realpath(path))
        if allowed_dir:
            abs_allowed = os.path.normpath(os.path.realpath(allowed_dir))
            if not (abs_path.startswith(abs_allowed + os.sep) or abs_path.startswith(abs_allowed + '/') or abs_path == abs_allowed):
                raise ValueError(f"Path traversal detected: {path} is outside {allowed_dir}")
        os.makedirs(os.path.dirname(abs_path), exist_ok=True)
        if self._temp_file:
            import shutil
            shutil.copy2(self._temp_file, abs_path)
        else:
            with open(abs_path, 'wb') as f:
                offset = 0
                while offset < len(self.body):
                    chunk = self.body[offset:offset + chunk_size]
                    f.write(chunk)
                    offset += chunk_size

    async def asave(self, path: str, allowed_dir: Optional[str] = None):
        import os
        abs_path = os.path.normpath(os.path.realpath(path))
        if allowed_dir:
            abs_allowed = os.path.normpath(os.path.realpath(allowed_dir))
            if not (abs_path.startswith(abs_allowed + os.sep) or abs_path.startswith(abs_allowed + '/') or abs_path == abs_allowed):
                raise ValueError(f"Path traversal detected: {path} is outside {allowed_dir}")
        os.makedirs(os.path.dirname(abs_path), exist_ok=True)
        if self._temp_file:
            import shutil
            loop = asyncio.get_running_loop()
            await loop.run_in_executor(None, shutil.copy2, self._temp_file, abs_path)
        else:
            loop = asyncio.get_running_loop()
            await loop.run_in_executor(None, self._write_file, abs_path)

    def _write_file(self, path: str):
        with open(path, 'wb') as f:
            f.write(self.body)

    async def close(self):
        """关闭临时文件句柄"""
        if hasattr(self, '_chunk_handle') and self._chunk_handle:
            self._chunk_handle.close()
            self._chunk_handle = None


class FormData:

    def __init__(self, body: bytes, content_type: str):
        self.body = body
        self.content_type = content_type
        self._fields: Dict[str, List[str]] = {}
        self._files: Dict[str, List[UploadedFile]] = {}
        self._parsed = False

    def _parse(self):
        if self._parsed:
            return

        if not self.body:
            return

        if 'multipart/form-data' in self.content_type:
            self._parse_multipart()
        elif 'application/x-www-form-urlencoded' in self.content_type:
            self._parse_urlencoded()

        self._parsed = True

    def _parse_multipart(self):
        boundary = None
        for part in self.content_type.split(';'):
            if 'boundary=' in part:
                boundary = part.split('boundary=')[1].strip().strip('"')
                break

        if not boundary:
            return

        boundary_bytes = f'--{boundary}'.encode()
        end_marker = f'--{boundary}--'.encode()

        if end_marker in self.body:
            body_to_parse = self.body[:self.body.index(end_marker)]
        else:
            body_to_parse = self.body

        parts = body_to_parse.split(boundary_bytes)

        for part in parts[1:]:
            if part.startswith(b'\r\n'):
                part = part[2:]
            if part.endswith(b'\r\n'):
                part = part[:-2]
            if not part:
                continue

            header_end = part.find(b'\r\n\r\n')
            if header_end == -1:
                continue

            headers = part[:header_end].decode('utf-8', errors='surrogateescape')
            body = part[header_end + 4:]

            name = None
            filename = None
            content_type = 'application/octet-stream'

            for line in headers.split('\r\n'):
                if line.lower().startswith('content-disposition:'):
                    if 'name="' in line:
                        name_start = line.find('name="')
                        if name_start == -1:
                            continue
                        name_start += 6
                        name_end = line.find('"', name_start)
                        if name_end == -1:
                            continue
                        name = line[name_start:name_end]

                    if 'filename="' in line:
                        filename_start = line.find('filename="')
                        if filename_start == -1:
                            continue
                        filename_start += 10
                        filename_end = line.find('"', filename_start)
                        if filename_end == -1:
                            continue
                        filename = line[filename_start:filename_end]
                        filename = filename.replace('\\', '/').split('/')[-1]
                        import re
                        filename = re.sub(r'[^\w.\-]', '_', filename)
                        filename = filename.lstrip('.')
                        if not filename:
                            filename = None

                elif line.lower().startswith('content-type:'):
                    content_type = line.split(':', 1)[1].strip()

            if name:
                if filename:
                    max_file_size = getattr(self, '_max_file_size', 100 * 1024 * 1024)
                    if len(body) > max_file_size:
                        from kewe.errors.exceptions import PayloadTooLarge
                        raise PayloadTooLarge(f"File '{filename}' exceeds maximum size of {max_file_size} bytes")
                    file_obj = UploadedFile(
                        name=name,
                        filename=filename,
                        content_type=content_type,
                        body=body
                    )
                    if name not in self._files:
                        self._files[name] = []
                    self._files[name].append(file_obj)
                else:
                    value = body.decode('utf-8', errors='surrogateescape')
                    if name not in self._fields:
                        self._fields[name] = []
                    self._fields[name].append(value)

    def _parse_urlencoded(self):
        try:
            data = self.body.decode('utf-8')
            parsed = parse_qs(data, keep_blank_values=True)
            self._fields = parsed
        except Exception as e:
            logger.error(f"Error parsing urlencoded form: {e}")

    def get(self, name: str, default: Any = None) -> Any:
        self._parse()
        values = self._fields.get(name)
        if values:
            return values[0]
        return default

    def getlist(self, name: str) -> List[str]:
        self._parse()
        return self._fields.get(name, [])

    def get_file(self, name: str) -> Optional[UploadedFile]:
        self._parse()
        files = self._files.get(name)
        if files:
            return files[0]
        return None

    def getfiles(self, name: str) -> List[UploadedFile]:
        self._parse()
        return self._files.get(name, [])

    @property
    def files(self) -> Dict[str, List[UploadedFile]]:
        self._parse()
        return self._files

    @property
    def fields(self) -> Dict[str, List[str]]:
        self._parse()
        return self._fields

    def __contains__(self, key: str) -> bool:
        self._parse()
        return key in self._fields or key in self._files

    def __getitem__(self, key: str) -> Union[str, 'UploadedFile']:
        self._parse()
        if key in self._fields:
            return self._fields[key][0]
        if key in self._files:
            return self._files[key][0]
        raise KeyError(key)

    def __len__(self) -> int:
        self._parse()
        return len(self._fields) + len(self._files)

    def __iter__(self):
        self._parse()
        for key in self._fields:
            yield key
        for key in self._files:
            yield key

    def items(self):
        self._parse()
        for key, values in self._fields.items():
            yield key, values[0] if len(values) == 1 else values
        for key, files in self._files.items():
            yield key, files[0] if len(files) == 1 else files

    def keys(self):
        self._parse()
        return list(self._fields.keys()) + list(self._files.keys())

    def values(self):
        self._parse()
        for values in self._fields.values():
            yield values[0] if len(values) == 1 else values
        for files in self._files.values():
            yield files[0] if len(files) == 1 else files

    def to_dict(self, *, flat: bool = True, include_files: bool = True) -> Dict[str, Any]:
        """转换为字典

        Args:
            flat: True 时每个键取第一个值，False 时保留所有值为列表
            include_files: True 时包含文件字段，False 时仅包含文本字段
        """
        self._parse()
        if flat:
            result = {}
            for key, values in self._fields.items():
                result[key] = values[0] if values else ""
            if include_files:
                for key, files in self._files.items():
                    result[key] = files[0] if files else ""
            return result
        result = {key: list(values) for key, values in self._fields.items()}
        if include_files:
            for key, files in self._files.items():
                result[key] = list(files)
        return result


class _CookieMultiDict(dict):
    """Cookie 多值字典

    MultiDict 接口：
    - dict-like 访问取第一个值
    - getlist() 获取所有值
    - 支持 .get(key, default, type) 类型转换
    """

    def __init__(self, mapping: Optional[Dict[str, List[str]]] = None):
        super().__init__()
        self._multi: Dict[str, List[str]] = mapping or {}
        for key, values in self._multi.items():
            super().__setitem__(key, values[0] if values else '')

    def getlist(self, key: str) -> List[str]:
        return list(self._multi.get(key, []))

    def get(self, key: str, default: Any = None, type: Optional[Callable] = None) -> Any:
        values = self._multi.get(key)
        if not values:
            return default
        value = values[0]
        if type is not None:
            try:
                return type(value)
            except (ValueError, TypeError):
                return default
        return value

    def __contains__(self, key: object) -> bool:
        return key in self._multi

    def __iter__(self):
        return iter(self._multi)

    def __len__(self) -> int:
        return len(self._multi)

    def keys(self):
        return self._multi.keys()

    def values(self):
        for values in self._multi.values():
            yield values[0] if values else ''

    def items(self):
        for key, values in self._multi.items():
            yield key, values[0] if values else ''

    def to_dict(self, *, flat: bool = True) -> Dict[str, Any]:
        if flat:
            return {k: v[0] if v else '' for k, v in self._multi.items() if v}
        return {k: list(v) for k, v in self._multi.items()}

    def __repr__(self) -> str:
        return f"CookieMultiDict({dict(self.items())})"


class Request:

    __slots__ = (
        'method', 'path', 'headers', 'query_params_raw', 'query_params',
        'args', '_query_string', '_body', 'client_ip', 'protocol',
        '_scheme', 'request_id', '_app', 'ctx', '_scope', '_receive',
        '_is_disconnected', '_json', '_json_parsed', '_json_error',
        '_form', '_cookies', '_full_body', '_body_consumed',
        '_body_lock', '_content_length', '_session',
    )

    def __init__(
        self,
        method: str = "GET",
        path: str = "/",
        headers: Dict[str, str] = None,
        query_params: Dict[str, List[str]] = None,
        query_string: Union[str, bytes] = None,
        body: Union[bytes, AsyncGenerator[bytes, None]] = None,
        client_ip: str = "127.0.0.1",
        protocol: str = "HTTP/1.1",
        version: str = None,
        request_id: str = None,
        app=None,
        *,
        _scope: Optional[Dict] = None,
        _receive: Optional[Callable] = None,
        scope: Optional[Dict] = None,
        receive: Optional[Callable] = None,
    ):
        if version is not None and protocol == "HTTP/1.1":
            protocol = version
        if query_string is not None and not query_params:
            if isinstance(query_string, bytes):
                query_string = query_string.decode("utf-8", errors="surrogateescape")
            from urllib.parse import parse_qs
            query_params = parse_qs(query_string, keep_blank_values=True)
        headers = headers or {}
        query_params = query_params or {}
        body = body or b""
        actual_scope = _scope or scope
        actual_receive = _receive or receive
        self.method = method.upper()
        self.path = path
        if isinstance(headers, Headers):
            self.headers = headers
        elif isinstance(headers, dict):
            self.headers = Headers(headers)
        else:
            self.headers = Headers(headers) if headers else Headers()
        self.query_params_raw = query_params
        self.query_params = _QueryArgs(query_params)
        self.args = self.query_params
        self._query_string: Optional[str] = None
        self._body = body
        self.client_ip = client_ip
        self.protocol = protocol
        self._scheme = self._resolve_scheme(protocol, _scope)
        self.request_id = request_id
        self._app = app
        from kewe.application.state_store import StateRequestContext
        self.ctx = StateRequestContext()
        self.ctx.user_id = None
        self.ctx.token_payload = None
        self.ctx.route = None
        self.ctx.path_params = {}

        self._scope = actual_scope
        self._receive = actual_receive
        self._is_disconnected = False

        self._json: Optional[Any] = None
        self._json_parsed: bool = False
        self._json_error: Optional[Exception] = None
        self._form = None
        self._cookies = None
        self._full_body: Optional[bytes] = None
        self._body_consumed: bool = False
        self._body_lock: Optional[asyncio.Lock] = None
        self._content_length: Optional[int] = None
        self._session = None

    def _get_body_lock(self) -> asyncio.Lock:
        if self._body_lock is None:
            self._body_lock = asyncio.Lock()
        return self._body_lock

    @property
    def app(self):
        return self._app

    @app.setter
    def app(self, value):
        self._app = value

    @property
    def state(self):
        return self.ctx

    @state.setter
    def state(self, value):
        self.ctx = value

    @property
    async def body(self) -> bytes:
        async with self._get_body_lock():
            if self._full_body is None and self._body_consumed:
                raise RuntimeError("Request body has already been consumed by stream()")
            if self._full_body is None:
                if isinstance(self._body, bytes):
                    self._full_body = self._body
                else:
                    body_parts = []
                    total_size = 0
                    max_body_size = getattr(self, '_max_body_size', 100 * 1024 * 1024)
                    async for chunk in self._body:
                        total_size += len(chunk)
                        if total_size > max_body_size:
                            from kewe.errors.exceptions import PayloadTooLarge
                            raise PayloadTooLarge(f"Request body exceeds {max_body_size} bytes")
                        body_parts.append(chunk)
                    self._full_body = b''.join(body_parts)
                self._body_consumed = True
            return self._full_body

    async def get_body(self) -> bytes:
        async with self._get_body_lock():
            if self._full_body is None and self._body_consumed:
                raise RuntimeError("Request body has already been consumed by stream()")
            if self._full_body is None:
                if isinstance(self._body, bytes):
                    self._full_body = self._body
                else:
                    body_parts = []
                    total_size = 0
                    max_body_size = getattr(self, '_max_body_size', 100 * 1024 * 1024)
                    async for chunk in self._body:
                        total_size += len(chunk)
                        if total_size > max_body_size:
                            from kewe.errors.exceptions import PayloadTooLarge
                            raise PayloadTooLarge(f"Request body exceeds {max_body_size} bytes")
                        body_parts.append(chunk)
                    self._full_body = b''.join(body_parts)
                self._body_consumed = True
            return self._full_body

    def _handle_json_error(self, error: Exception) -> Optional[Any]:
        content_type = self.headers.get('content-type', '')
        if 'application/json' in content_type.lower():
            from kewe.errors.exceptions import BadRequest
            raise BadRequest(f"Invalid JSON in request body: {error}")
        return None

    @property
    def json(self) -> Optional[Any]:
        if self._json_parsed:
            return self._json
        if self._full_body is not None:
            if not self._json_parsed:
                self._json_parsed = True
                if not self._full_body:
                    self._json = None
                    return None
                if not self.is_json:
                    self._json = None
                    return None
                try:
                    body_data = self._full_body
                    if isinstance(body_data, bytes):
                        self._json = _json.loads(body_data)
                    else:
                        self._json = _json.loads(body_data)
                except (UnicodeDecodeError, ValueError) as e:
                    self._json_error = e
                    return self._handle_json_error(e)
            return self._json
        return self._await_json()

    def _await_json(self):
        return _AwaitableProperty(self, 'json')

    @property
    async def json_async(self) -> Optional[Any]:
        if not self._json_parsed:
            self._json_parsed = True
            body = await self.body
            if not body:
                self._json = None
                return None
            try:
                self._json = _json.loads(body)
            except (UnicodeDecodeError, ValueError) as e:
                self._json_error = e
                result = self._handle_json_error(e)
                self._json = result
        return self._json

    async def get_json(self) -> Optional[Any]:
        if not self._json_parsed:
            self._json_parsed = True
            body = await self.body
            if not body:
                self._json = None
                return None
            try:
                self._json = _json.loads(body)
            except (UnicodeDecodeError, ValueError) as e:
                self._json_error = e
                result = self._handle_json_error(e)
                self._json = result
        return self._json

    @property
    def form(self) -> FormData:
        """Form data - 同步访问（）

        当 body 已被预解析时直接返回数据，
        否则返回 _AwaitableProperty，需要使用 await request.form 或 await request.get_form()。

        在 ASGI 适配器中 body 已预读取，因此大多数情况下可直接使用。
        """
        if self._form is not None:
            return self._form
        if self._full_body is not None:
            content_type = self.headers.get('content-type', '')
            self._form = FormData(self._full_body, content_type)
            return self._form
        return self._await_form()

    def _await_form(self):
        return _AwaitableProperty(self, 'form')

    @property
    async def form_async(self) -> FormData:
        if self._form is None:
            content_type = self.headers.get('content-type', '')
            if 'multipart/form-data' in content_type and self._full_body is None:
                self._form = await self._parse_multipart_streaming(content_type)
            else:
                body = await self.body
                self._form = FormData(body, content_type)
        return self._form

    async def get_form(self) -> "FormData":
        if self._form is None:
            content_type = self.headers.get('content-type', '')
            if 'multipart/form-data' in content_type and self._full_body is None:
                self._form = await self._parse_multipart_streaming(content_type)
            else:
                body = await self.body
                self._form = FormData(body, content_type)
        return self._form

    async def _parse_multipart_streaming(self, content_type: str) -> FormData:
        """使用流式 MultipartParser 解析 multipart 请求

        大文件通过临时文件存储，避免全量内存占用。
        解析完成后将结果转换为 FormData 对象，保持 API 兼容。
        """
        from kewe.request.multipart_stream import (
            MultipartParser, MultipartParserConfig, extract_boundary
        )

        boundary = extract_boundary(content_type)
        if not boundary:
            body = await self.body
            return FormData(body, content_type)

        config = MultipartParserConfig()
        max_body_size = getattr(self, '_max_body_size', 100 * 1024 * 1024)
        config.max_file_size = max_body_size

        parser = MultipartParser(boundary, config)

        async def body_stream():
            if isinstance(self._body, bytes):
                yield self._body
            else:
                async for chunk in self._body:
                    yield chunk

        form = FormData(b'', content_type)
        form._parsed = True

        try:
            async for field in parser.parse(body_stream()):
                if field.is_file:
                    uploaded = UploadedFile(
                        name=field.name,
                        filename=field.filename or '',
                        content_type=field.content_type,
                        body=field.value or b''
                    )
                    uploaded._temp_file = field.temp_file
                    uploaded._stream_parser = parser
                    if field.name not in form._files:
                        form._files[field.name] = []
                    form._files[field.name].append(uploaded)
                else:
                    if field.name not in form._fields:
                        form._fields[field.name] = []
                    form._fields[field.name].append(field.get_value())
        except Exception:
            parser.cleanup()
            raise
        else:
            parser._close_current_file_handle()

        self._body_consumed = True
        return form

    @property
    def files(self) -> Dict[str, List[UploadedFile]]:
        """上传文件 - 同步访问（）

        当 body 已被预解析时直接返回数据，
        否则返回 _AwaitableProperty，需要使用 await request.files 或 await request.files_async。

        在 ASGI 适配器中 body 已预读取，因此大多数情况下可直接使用。
        """
        if self._form is not None:
            return self._form.files
        if self._full_body is not None:
            content_type = self.headers.get('content-type', '')
            self._form = FormData(self._full_body, content_type)
            return self._form.files
        return self._await_files()

    def _await_files(self):
        return _AwaitableProperty(self, 'files')

    @property
    async def files_async(self) -> Dict[str, List[UploadedFile]]:
        """异步文件解析 - 显式异步版本"""
        form_data = await self.form_async
        return form_data.files

    @property
    def cookies(self) -> _CookieMultiDict:
        if self._cookies is None:
            cookie_data: Dict[str, List[str]] = {}
            cookie_header = self.headers.get('cookie', '')
            if cookie_header:
                for cookie in cookie_header.split(';'):
                    if '=' in cookie:
                        name, value = cookie.strip().split('=', 1)
                        if name not in cookie_data:
                            cookie_data[name] = []
                        cookie_data[name].append(value)
            self._cookies = _CookieMultiDict(cookie_data)
        return self._cookies

    def get_cookie(self, key: str, default: str = None) -> Optional[str]:
        return self.cookies.get(key, default)

    def get_header(self, name: str, default: Any = None) -> Any:
        if not name:
            return default
        lower_name = name.lower()
        if hasattr(self.headers, '_get_lowered'):
            return self.headers._get_lowered(lower_name, default)
        return self.headers.get(lower_name, default)

    def get(self, key: str, default: Any = None) -> Any:
        """获取查询参数 — 等同于 request.query_params.get(key, default)"""
        return self.query_params.get(key, default)

    def getlist(self, key: str) -> List[str]:
        """获取查询参数列表 — 等同于 request.query_params.getlist(key)"""
        return self.query_params.getlist(key)

    @property
    def content_type(self) -> str:
        return self.headers.get('content-type', '')

    @property
    def data(self) -> bytes:
        if self._full_body is not None:
            return self._full_body
        if isinstance(self._body, bytes):
            return self._body
        raise RuntimeError(
            "request.data cannot be used with streaming request bodies. "
            "Use 'await request.body' to read the body first."
        )

    @property
    def mimetype(self) -> str:
        """MIME 类型部分（不含参数）— 

        例如 Content-Type: text/html; charset=utf-8 -> text/html
        """
        ct = self.content_type
        if ';' in ct:
            return ct.split(';', 1)[0].strip()
        return ct.strip()

    @property
    def mimetype_params(self) -> Dict[str, str]:
        """MIME 类型参数

        例如 Content-Type: text/html; charset=utf-8 -> {'charset': 'utf-8'}
        """
        ct = self.content_type
        if ';' not in ct:
            return {}
        params = {}
        for part in ct.split(';')[1:]:
            part = part.strip()
            if '=' in part:
                key, value = part.split('=', 1)
                params[key.strip().lower()] = value.strip().strip('"')
        return params

    @property
    def encoding(self) -> Optional[str]:
        """请求体编码

        从 Content-Type 头提取 charset 参数。
        """
        return self.mimetype_params.get('charset')

    @property
    def if_match(self) -> List[str]:
        """If-Match 头解析

        返回 ETag 值列表。'*' 表示匹配任意。
        """
        header = self.headers.get('if-match', '')
        if not header:
            return []
        if header.strip() == '*':
            return ['*']
        result = []
        for tag in header.split(','):
            tag = tag.strip().strip('"').strip("W/").strip('"')
            if tag:
                result.append(tag)
        return result

    @property
    def if_none_match(self) -> List[str]:
        """If-None-Match 头解析

        返回 ETag 值列表。'*' 表示匹配任意。
        """
        header = self.headers.get('if-none-match', '')
        if not header:
            return []
        if header.strip() == '*':
            return ['*']
        result = []
        for tag in header.split(','):
            tag = tag.strip().strip('"').strip("W/").strip('"')
            if tag:
                result.append(tag)
        return result

    @property
    def cache_control(self) -> 'RequestCacheControl':
        """Cache-Control 头解析

        返回 RequestCacheControl 对象，提供语义化属性访问。
        """
        header = self.headers.get('cache-control', '')
        return RequestCacheControl(header)

    @property
    def if_modified_since(self) -> Optional[datetime]:
        """If-Modified-Since 头解析

        返回 datetime 对象（UTC），解析失败返回 None。
        """
        header = self.headers.get('if-modified-since', '')
        if not header:
            return None
        try:
            return parsedate_to_datetime(header)
        except (ValueError, TypeError):
            return None

    @property
    def if_unmodified_since(self) -> Optional[datetime]:
        """If-Unmodified-Since 头解析

        返回 datetime 对象（UTC），解析失败返回 None。
        """
        header = self.headers.get('if-unmodified-since', '')
        if not header:
            return None
        try:
            return parsedate_to_datetime(header)
        except (ValueError, TypeError):
            return None

    @property
    def is_cacheable(self) -> bool:
        if self.method not in ('GET', 'HEAD'):
            return False
        if 'authorization' in self.headers:
            return False
        cache_control = self.headers.get('cache-control', '').lower()
        if 'no-store' in cache_control or 'no-cache' in cache_control:
            return False
        return True

    @property
    def is_safe(self) -> bool:
        return self.method in ('GET', 'HEAD', 'OPTIONS', 'TRACE')

    @property
    def is_idempotent(self) -> bool:
        return self.method in ('GET', 'HEAD', 'OPTIONS', 'TRACE', 'PUT', 'DELETE')

    @property
    def is_ajax(self) -> bool:
        return self.headers.get('x-requested-with', '').lower() == 'xmlhttprequest'

    @property
    def is_json(self) -> bool:
        content_type = self.content_type.lower()
        return 'application/json' in content_type

    @property
    def is_multipart(self) -> bool:
        content_type = self.content_type.lower()
        return 'multipart/form-data' in content_type

    @property
    def is_urlencoded(self) -> bool:
        content_type = self.content_type.lower()
        return 'application/x-www-form-urlencoded' in content_type

    @staticmethod
    def _resolve_scheme(protocol: Optional[str], scope: Optional[Dict]) -> str:
        if scope and 'scheme' in scope:
            return scope['scheme'].lower()
        if protocol:
            proto_lower = protocol.lower()
            if proto_lower in ('https', 'http/2', 'http/3'):
                return proto_lower
            if proto_lower.startswith('https'):
                return 'https'
        return 'http'

    @property
    def is_secure(self) -> bool:
        return self._scheme in ('https', 'http/2', 'http/3')

    @property
    def scheme(self) -> str:
        if self.is_secure:
            return 'https'
        return 'http'

    @scheme.setter
    def scheme(self, value: str):
        self._scheme = value.lower()

    @property
    def content_length(self) -> Optional[int]:
        if self._content_length is None:
            if 'content-length' in self.headers:
                try:
                    self._content_length = int(self.headers['content-length'])
                except ValueError:
                    self._content_length = None
            elif self._full_body is not None:
                self._content_length = len(self._full_body)
        return self._content_length

    @property
    def max_content_length(self) -> Optional[int]:
        """最大请求体长度

        从应用配置中读取 request_max_size，若无配置返回 None。
        """
        app = getattr(self, '_app', None)
        if app is None:
            from kewe.base.context import get_app_ctx
            try:
                app_ctx = get_app_ctx()
                if app_ctx and hasattr(app_ctx, 'app'):
                    app = app_ctx.app
            except Exception:
                logger.debug("Non-critical operation failed", exc_info=True)
        if app is not None:
            return getattr(app.config, 'request_max_size', None)
        return None

    @property
    def max_forwards(self) -> Optional[int]:
        """Max-Forwards 头解析

        用于 TRACE 和 OPTIONS 方法，限制代理/网关转发次数。
        返回整数值，解析失败或不存在时返回 None。
        """
        header = self.headers.get('max-forwards', '')
        if not header:
            return None
        try:
            return int(header.strip())
        except (ValueError, TypeError):
            return None

    @property
    def pragma(self) -> List[str]:
        """Pragma 头解析

        返回 Pragma 指令列表，如 ['no-cache']。
        """
        header = self.headers.get('pragma', '')
        if not header:
            return []
        return [p.strip() for p in header.split(',') if p.strip()]

    @property
    def date(self) -> Optional[datetime]:
        """Date 头解析

        返回 datetime 对象（UTC），解析失败返回 None。
        """
        header = self.headers.get('date', '')
        if not header:
            return None
        try:
            return parsedate_to_datetime(header)
        except (ValueError, TypeError):
            return None

    @property
    def if_range(self) -> Optional[str]:
        """If-Range 头解析

        返回 If-Range 头的值（ETag 或 HTTP-date），不存在返回 None。
        """
        return self.headers.get('if-range', '') or None

    @property
    def range(self) -> Optional[List[tuple]]:
        """Range 头解析

        解析 Range 头返回 (start, end) 元组列表。
        例如 Range: bytes=0-499 -> [(0, 499)]
        不存在或格式错误返回 None。
        """
        header = self.headers.get('range', '')
        if not header:
            return None
        if not header.startswith('bytes='):
            return None
        range_spec = header[6:].strip()
        ranges = []
        for part in range_spec.split(','):
            part = part.strip()
            if '-' not in part:
                return None
            start_str, end_str = part.split('-', 1)
            try:
                if start_str == '':
                    suffix_length = int(end_str)
                    ranges.append((-suffix_length, None))
                elif end_str == '':
                    start = int(start_str)
                    ranges.append((start, None))
                else:
                    start = int(start_str)
                    end = int(end_str)
                    ranges.append((start, end))
            except ValueError:
                return None
        return ranges if ranges else None

    @property
    def content_range(self) -> Optional[Dict[str, Any]]:
        """Content-Range 头解析

        解析 Content-Range 头返回字典。
        例如 Content-Range: bytes 0-499/1000 -> {'unit': 'bytes', 'start': 0, 'stop': 499, 'length': 1000}
        """
        header = self.headers.get('content-range', '')
        if not header:
            return None
        parts = header.split()
        if len(parts) < 2:
            return None
        unit = parts[0]
        range_spec = parts[1]
        if '/' in range_spec:
            range_part, length_str = range_spec.split('/', 1)
            if '-' in range_part:
                start_str, stop_str = range_part.split('-', 1)
                try:
                    result = {
                        'unit': unit,
                        'start': int(start_str),
                        'stop': int(stop_str),
                        'length': int(length_str) if length_str != '*' else None,
                    }
                    return result
                except ValueError:
                    pass
        return None

    @property
    def user_agent(self) -> 'UserAgent':
        """User-Agent 解析对象

        返回 UserAgent 对象，支持 .string/.browser/.platform/.version 属性。
        """
        ua_str = self.headers.get('user-agent', '')
        return UserAgent(ua_str)

    @property
    def host(self) -> str:
        return self.headers.get('host', '')

    @property
    def hostname(self) -> str:
        """主机名（不含端口）- """
        host_header = self.host
        if ':' in host_header:
            return host_header.rsplit(':', 1)[0]
        return host_header

    @property
    def port(self) -> Optional[int]:
        """请求端口号 - """
        host_header = self.host
        if ':' in host_header:
            try:
                return int(host_header.rsplit(':', 1)[1])
            except (ValueError, IndexError):
                pass
        if self._scope and self._scope.get('server'):
            return self._scope['server'][1]
        if self.scheme == 'https':
            return 443
        return 80

    @property
    def ip(self) -> str:
        """客户端 IP 短名 - """
        return self.client_ip or self.remote_addr

    @property
    def token(self) -> Optional[str]:
        """从 Authorization 头提取 Bearer token - """
        auth = self.headers.get('authorization', '')
        if auth.lower().startswith('bearer '):
            return auth[7:].strip()
        return None

    @property
    def authorization(self) -> Optional[Dict[str, str]]:
        """解析 Authorization 头

        返回字典:
        - Bearer: {"type": "Bearer", "token": "..."}
        - Basic: {"type": "Basic", "username": "...", "password": "...", "token": "..."}
        """
        auth = self.headers.get('authorization', '')
        if not auth:
            return None
        parts = auth.split(' ', 1)
        if len(parts) == 2:
            auth_type = parts[0]
            token = parts[1].strip()
            result = {"type": auth_type, "token": token}
            if auth_type.lower() == 'basic':
                import base64
                try:
                    decoded = base64.b64decode(token).decode('utf-8')
                    username, password = decoded.split(':', 1)
                    result["username"] = username
                    result["password"] = password
                except Exception:
                    logger.debug("Non-critical operation failed", exc_info=True)
            return result
        return {"type": auth, "token": ""}

    @property
    def endpoint(self) -> Optional[str]:
        """当前路由端点名 - """
        if hasattr(self, 'ctx') and hasattr(self.ctx, 'route') and self.ctx.route:
            route = self.ctx.route
            if isinstance(route, dict):
                return route.get("name")
            if hasattr(route, 'name'):
                return route.name
        return None

    @property
    def blueprint(self) -> Optional[str]:
        """当前匹配的蓝图名

        从 endpoint 中提取蓝图名（endpoint 格式为 blueprint.route_name）。
        如果路由不在蓝图中，返回 None。
        """
        ep = self.endpoint
        if ep and '.' in ep:
            return ep.split('.', 1)[0]
        return None

    @property
    def matched_route(self) -> Optional[str]:
        """匹配的路由模式"""
        if hasattr(self, 'ctx') and hasattr(self.ctx, 'route') and self.ctx.route:
            route = self.ctx.route
            if isinstance(route, dict):
                return route.get("path")
            if hasattr(route, 'path'):
                return route.path
        return None

    @property
    def route(self):
        """匹配的路由对象 — 匹配路由"""
        if hasattr(self, 'ctx') and hasattr(self.ctx, 'route') and self.ctx.route is not None:
            return self.ctx.route
        return None

    @property
    def id(self) -> Optional[str]:
        """请求 ID — 请求ID

        别名 for request.request_id
        """
        return getattr(self, 'request_id', None) or self.headers.get('x-request-id')

    @property
    def socket(self):
        ip = self.client_ip or self.remote_addr or '127.0.0.1'
        port_val = getattr(self, '_client_port', 0)
        return _SocketInfo(ip=ip, port=port_val)

    @property
    def conn_info(self):
        """连接信息 — 连接信息

        封装 client, server, ssl 等连接信息。
        """
        return _ConnInfo(self)

    @property
    def accept(self) -> str:
        return self.headers.get('accept', '')

    @property
    def accept_encodings(self) -> List[str]:
        header = self.headers.get('accept-encoding', '')
        if not header:
            return []
        return self._parse_accept_header(header)

    def url_for(self, name: str, **kwargs) -> Optional[str]:
        if hasattr(self, '_app') and self._app and hasattr(self._app, 'router'):
            return self._app.router.url_for(name, **kwargs)
        return None

    @property
    def accept_languages(self) -> List[str]:
        header = self.headers.get('accept-language', '')
        if not header:
            return []
        return self._parse_accept_header(header)

    @staticmethod
    def _parse_accept_header(header: str) -> List[str]:
        result = []
        for item in header.split(','):
            item = item.strip()
            if not item:
                continue
            if ';q=' in item:
                parts = item.split(';q=')
                value = parts[0].strip()
                try:
                    quality = float(parts[1].split(';')[0].strip())
                except (ValueError, IndexError):
                    quality = 1.0
            else:
                value = item.split(';')[0].strip()
                quality = 1.0
            result.append((quality, value))
        result.sort(key=lambda x: x[0], reverse=True)
        return [v for _, v in result]

    @property
    def session(self) -> Any:
        sess = getattr(self, '_session', None)
        if sess is None:
            from kewe.cookies.session import NullSession
            sess = NullSession()
            self._session = sess
        return sess

    @session.setter
    def session(self, value: Any):
        self._session = value

    @property
    def query_string(self) -> str:
        if self._query_string is None:
            if self.query_params_raw:
                import urllib.parse
                parts = []
                for key, values in self.query_params_raw.items():
                    if isinstance(values, list):
                        for v in values:
                            parts.append(f"{urllib.parse.quote(str(key))}={urllib.parse.quote(str(v))}")
                    else:
                        parts.append(f"{urllib.parse.quote(str(key))}={urllib.parse.quote(str(values))}")
                self._query_string = '&'.join(parts)
            else:
                self._query_string = ''
        return self._query_string

    @property
    def url(self) -> 'URL':
        from kewe.http.url import HttpURL as URL
        scheme = self.scheme
        host = self.headers.get('host', 'localhost')
        root = self.root_path or ''
        qs = ''
        if self.query_params_raw:
            import urllib.parse
            parts = []
            for key, values in self.query_params_raw.items():
                if isinstance(values, (list, tuple)):
                    for v in values:
                        parts.append(f"{urllib.parse.quote(key)}={urllib.parse.quote(str(v))}")
                else:
                    parts.append(f"{urllib.parse.quote(key)}={urllib.parse.quote(str(values))}")
            qs = '&'.join(parts)
        url_str = f"{scheme}://{host}{root}{self.path}"
        if qs:
            url_str += f"?{qs}"
        return URL(url_str)

    @property
    def base_url(self) -> 'URL':
        from kewe.http.url import HttpURL as URL
        scheme = self.scheme
        host = self.headers.get('host', 'localhost')
        root = self.root_path or ''
        return URL(f"{scheme}://{host}{root}")

    @property
    def url_root(self) -> str:
        """URL 根路径（带尾部斜杠）

        返回 scheme://host/root_path/ 格式。
        """
        scheme = self.scheme
        host = self.headers.get('host', 'localhost')
        root = self.root_path or ''
        if root and not root.endswith('/'):
            root += '/'
        elif not root:
            root = '/'
        return f"{scheme}://{host}{root}"

    @property
    def scope(self) -> Optional[Dict]:
        return self._scope

    @scope.setter
    def scope(self, value: Optional[Dict]):
        self._scope = value

    @property
    def path_params(self) -> Dict[str, Any]:
        return self.ctx.path_params if hasattr(self, 'ctx') else {}

    @path_params.setter
    def path_params(self, value: Dict[str, Any]):
        if hasattr(self, 'ctx'):
            self.ctx.path_params = value

    @property
    def root_path(self) -> str:
        if self._scope:
            return self._scope.get('root_path', '')
        return ''

    @property
    def client(self) -> Optional[tuple]:
        if self._scope:
            return self._scope.get('client')
        if self.client_ip:
            return (self.client_ip, 0)
        return None

    @property
    def remote_addr(self) -> str:
        """客户端IP地址 - 便捷别名"""
        if self._scope and self._scope.get('client'):
            return self._scope['client'][0]
        return self.client_ip or '127.0.0.1'

    @property
    def server(self) -> Optional[tuple]:
        if self._scope:
            return self._scope.get('server')
        return None

    @property
    def referer(self) -> str:
        return self.headers.get('referer', '') or self.headers.get('referrer', '')

    @property
    def origin(self) -> str:
        return self.headers.get('origin', '')

    @property
    def full_path(self) -> str:
        qs = self.query_string
        if qs:
            return f"{self.path}?{qs}"
        return self.path

    @property
    def full_url(self) -> str:
        return str(self.url)

    @property
    def accept_mimetypes(self):
        accept = self.headers.get('accept', '')
        if not accept:
            return _MIMEAccept([('*/*', 1.0)])
        items = []
        for item in accept.split(','):
            item = item.strip()
            if not item:
                continue
            if ';q=' in item:
                parts = item.split(';q=')
                value = parts[0].strip()
                try:
                    quality = float(parts[1].split(';')[0].strip())
                except (ValueError, IndexError):
                    quality = 1.0
            else:
                value = item.split(';')[0].strip()
                quality = 1.0
            items.append((value, quality))
        items.sort(key=lambda x: x[1], reverse=True)
        return _MIMEAccept(items)

    @property
    def raw_path(self) -> bytes:
        if self._scope:
            return self._scope.get('raw_path', self.path.encode('utf-8'))
        return self.path.encode('utf-8')

    @property
    def user(self) -> Any:
        return getattr(self.ctx, 'user', None) if hasattr(self, 'ctx') else None

    @property
    def receive(self) -> Optional[Callable]:
        return self._receive

    @receive.setter
    def receive(self, value: Optional[Callable]):
        self._receive = value

    async def is_disconnected(self) -> bool:
        if self._is_disconnected:
            return True
        if self._receive is not None:
            try:
                message = await asyncio.wait_for(self._receive(), timeout=0.001)
                if message.get('type') == 'http.disconnect':
                    self._is_disconnected = True
                    return True
            except asyncio.TimeoutError:
                return False
            except Exception:
                return False
        return False

    async def stream(self, chunk_size: int = 8192) -> AsyncGenerator[bytes, None]:
        """流式读取请求体

        当 body 已预读取时，分块 yield 已有的 bytes。
        当 body 未预读取时，从 ASGI receive 逐块读取。
        """
        if self._full_body is not None:
            for i in range(0, len(self._full_body), chunk_size):
                yield self._full_body[i:i + chunk_size]
            return

        if self._body_consumed:
            raise RuntimeError("Request body has already been consumed")

        self._body_consumed = True

        if self._receive is not None:
            while True:
                message = await self._receive()
                if message.get('type') == 'http.request':
                    body_chunk = message.get('body', b'')
                    if body_chunk:
                        yield body_chunk
                    if not message.get('more_body', False):
                        break
                elif message.get('type') == 'http.disconnect':
                    break
                else:
                    break
            return

        if isinstance(self._body, bytes):
            for i in range(0, len(self._body), chunk_size):
                yield self._body[i:i + chunk_size]
        else:
            async for chunk in self._body:
                yield chunk

    async def text(self, encoding: str = 'utf-8') -> str:
        body = await self.body
        return body.decode(encoding)

    async def read(self, max_size: int = None) -> bytes:
        body = await self.body
        if max_size and len(body) > max_size:
            raise ValueError(f"Request body too large: {len(body)} > {max_size}")
        return body

    async def json_items(self, chunk_size: int = 8192) -> AsyncGenerator[Any, None]:
        """逐项迭代 JSON 数据

        注意：此方法先完整解析 JSON 再逐项 yield，
        不适用于超大 JSON 的流式解析场景。
        对于大 JSON 数据，建议直接使用 request.stream() 读取原始字节流。

        Args:
            chunk_size: 保留参数，当前未使用

        Yields:
            JSON 数组中的每个元素，或整个 JSON 对象
        """
        json_data = await self.json
        if isinstance(json_data, list):
            for item in json_data:
                yield item
        elif isinstance(json_data, dict):
            yield json_data


class RequestPool:
    """Request对象池 - 减少内存分配，降低GC压力

    使用示例:
        pool = RequestPool(max_size=1000)
        req = pool.acquire(method="GET", path="/api/test", ...)
        try:
            process(req)
        finally:
            pool.release(req)
    """

    __slots__ = ('_pool', '_max_size', '_created', '_reused', '_hits', '_misses')

    def __init__(self, max_size: int = 1000):
        self._max_size = max_size
        self._pool: list = []
        self._created: int = 0
        self._reused: int = 0
        self._hits: int = 0
        self._misses: int = 0

    def acquire(self, **kwargs) -> "Request":
        if self._pool:
            req = self._pool.pop()
            self._reset_request(req, **kwargs)
            self._reused += 1
            self._hits += 1
            return req
        self._misses += 1
        self._created += 1
        return Request(**kwargs)

    def release(self, req: "Request"):
        if len(self._pool) < self._max_size:
            self._pool.append(req)
        # 超出池容量则不回收，让GC处理

    @staticmethod
    def _reset_request(req: "Request", **kwargs):
        req.method = kwargs.get("method", "GET").upper()
        req.path = kwargs.get("path", "/")
        headers = kwargs.get("headers", {})
        if isinstance(headers, dict):
            from kewe.http.headers import Headers
            req.headers = Headers(headers)
        else:
            req.headers = headers
        req.query_params_raw = kwargs.get("query_params", {})
        req.query_params = _QueryArgs(req.query_params_raw)
        req.args = req.query_params
        req.client_ip = kwargs.get("client_ip", "127.0.0.1")
        req.protocol = kwargs.get("protocol", "HTTP/1.1")
        req._body = kwargs.get("body", b"")
        req._app = kwargs.get("app")
        req.request_id = kwargs.get("request_id")
        req._scope = kwargs.get("_scope") or kwargs.get("scope")
        req._receive = kwargs.get("_receive") or kwargs.get("receive")
        req._json = None
        req._json_parsed = False
        req._json_error = None
        req._form = None
        req._cookies = None
        req._full_body = None
        req._body_consumed = False
        req._body_lock = None
        req._content_length = None
        req._session = None
        req._is_disconnected = False
        req._query_string = None
        req.ctx.user_id = None
        req.ctx.token_payload = None
        req.ctx.route = None
        req.ctx.path_params = {}

    @property
    def stats(self) -> dict:
        total = self._hits + self._misses
        return {
            "pool_size": len(self._pool),
            "max_size": self._max_size,
            "created": self._created,
            "reused": self._reused,
            "hits": self._hits,
            "misses": self._misses,
            "hit_rate": self._hits / total if total > 0 else 0,
        }

    def clear(self):
        self._pool.clear()
        self._hits = 0
        self._misses = 0
