#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.cache.backends - Cache backends including memory, Redis, and file-based
"""

import time
import pickle
import logging
import asyncio
from abc import ABC, abstractmethod
from typing import Any, Dict, Optional, List
from dataclasses import dataclass
from enum import Enum
from collections import OrderedDict
import threading

from kewe.utils.compat import JsonWrapper

logger = logging.getLogger(__name__)


class CacheStrategy(Enum):
    MEMORY = "memory"
    REDIS = "redis"
    MEMCACHED = "memcached"


@dataclass(slots=True)
class CacheEntry:
    value: Any
    expire_at: Optional[float]
    created_at: float
    _access_count: int = 0


class CacheBackend(ABC):

    def __init__(self):
        self._async_lock: Optional[asyncio.Lock] = None

    def _get_async_lock(self) -> asyncio.Lock:
        if self._async_lock is None:
            self._async_lock = asyncio.Lock()
        return self._async_lock

    @abstractmethod
    def get(self, key: str) -> Any:
        ...

    @abstractmethod
    def set(self, key: str, value: Any, ttl: int = None):
        ...

    @abstractmethod
    def delete(self, key: str):
        ...

    @abstractmethod
    def clear(self):
        ...

    @abstractmethod
    def exists(self, key: str) -> bool:
        ...

    @abstractmethod
    def keys(self, pattern: str = "*") -> List[str]:
        ...

    async def aget(self, key: str) -> Optional[Any]:
        async with self._get_async_lock():
            return self.get(key)

    async def aset(self, key: str, value: Any, ttl: int = None):
        async with self._get_async_lock():
            self.set(key, value, ttl)

    async def adelete(self, key: str):
        async with self._get_async_lock():
            self.delete(key)

    async def aclear(self):
        async with self._get_async_lock():
            self.clear()

    async def aexists(self, key: str) -> bool:
        async with self._get_async_lock():
            return self.exists(key)

    async def akeys(self, pattern: str = "*") -> List[str]:
        return await asyncio.to_thread(self.keys, pattern)

    def close(self):
        return None

    async def aclose(self):
        self.close()


class MemoryCache(CacheBackend):

    DEFAULT_MAX_SIZE = 10000
    _CLEANUP_INTERVAL = 60

    def __init__(self, max_size: int = None, default_ttl: int = None):
        self._cache: OrderedDict[str, CacheEntry] = OrderedDict()
        self._lock = threading.RLock()
        self._async_lock: Optional[asyncio.Lock] = None
        self._max_size = max_size or self.DEFAULT_MAX_SIZE
        self._default_ttl = default_ttl
        self._last_cleanup = time.time()

    def _maybe_cleanup(self):
        now = time.time()
        if now - self._last_cleanup < self._CLEANUP_INTERVAL:
            return
        self._last_cleanup = now
        expired_keys = [
            key for key, entry in self._cache.items()
            if entry.expire_at is not None and now > entry.expire_at
        ]
        for key in expired_keys:
            del self._cache[key]

    def get(self, key: str) -> Any:
        with self._lock:
            self._maybe_cleanup()
            entry = self._cache.get(key)
            if entry is None:
                return None

            if entry.expire_at is not None and time.time() > entry.expire_at:
                del self._cache[key]
                return None

            self._cache.move_to_end(key)
            return entry.value

    def set(self, key: str, value: Any, ttl: int = None):
        with self._lock:
            self._maybe_cleanup()
            effective_ttl = ttl if ttl is not None else self._default_ttl
            expire_at = None
            if effective_ttl is not None:
                expire_at = time.time() + effective_ttl

            self._cache[key] = CacheEntry(
                value=value,
                expire_at=expire_at,
                created_at=time.time()
            )
            self._cache.move_to_end(key)

            while len(self._cache) > self._max_size:
                self._cache.popitem(last=False)

    def delete(self, key: str):
        with self._lock:
            self._cache.pop(key, None)

    def clear(self):
        with self._lock:
            self._cache.clear()

    def exists(self, key: str) -> bool:
        with self._lock:
            entry = self._cache.get(key)
            if entry is None:
                return False

            if entry.expire_at is not None and time.time() > entry.expire_at:
                del self._cache[key]
                return False

            return True

    def keys(self, pattern: str = "*") -> List[str]:
        import fnmatch
        with self._lock:
            if pattern == "*":
                return list(self._cache.keys())

            current_time = time.time()
            keys = []
            for key, entry in list(self._cache.items()):
                if entry.expire_at is not None and current_time > entry.expire_at:
                    del self._cache[key]
                elif fnmatch.fnmatch(key, pattern):
                    keys.append(key)

            return keys

    def cleanup_expired(self):
        with self._lock:
            current_time = time.time()
            expired_keys = [
                key for key, entry in self._cache.items()
                if entry.expire_at is not None and current_time > entry.expire_at
            ]
            for key in expired_keys:
                del self._cache[key]

    def close(self):
        with self._lock:
            self._cache.clear()


class RedisCache(CacheBackend):

    def __init__(self, host: str = "localhost", port: int = 6379, db: int = 0, password: str = None, serializer: str = "json", key_prefix: str = "kewe:"):
        self._host = host
        self._port = port
        self._db = db
        self._password = password
        try:
            import redis
            self._redis = redis.Redis(
                host=host,
                port=port,
                db=db,
                password=password,
                decode_responses=False
            )
            self._available = True
        except ImportError:
            logger.warning("redis package not installed, Redis cache unavailable")
            self._available = False
            self._redis = None
        self._serializer = serializer
        self._key_prefix = key_prefix
        self._aredis = None

    def _serialize(self, value: Any) -> bytes:
        if self._serializer == "pickle":
            import warnings
            warnings.warn(
                "Pickle serialization is insecure and may allow remote code execution. "
                "Use JSON serialization instead.",
                UserWarning, stacklevel=3
            )
            return pickle.dumps(value)
        return JsonWrapper.dumpsb(value)

    def _deserialize(self, data: bytes) -> Any:
        if self._serializer == "pickle":
            import warnings
            warnings.warn(
                "Pickle deserialization is insecure and may allow remote code execution. "
                "Use JSON serialization instead.",
                UserWarning, stacklevel=3
            )
            return pickle.loads(data)
        return JsonWrapper.loads(data)

    def _prefixed(self, key: str) -> str:
        return f"{self._key_prefix}{key}"

    def get(self, key: str) -> Optional[Any]:
        if not self._available:
            return None

        try:
            data = self._redis.get(self._prefixed(key))
            if data is None:
                return None
            return self._deserialize(data)
        except Exception as e:
            logger.error(f"Redis get error: {e}")
            return None

    def set(self, key: str, value: Any, ttl: int = None):
        if not self._available:
            return

        try:
            data = self._serialize(value)
            redis_key = self._prefixed(key)
            if ttl:
                self._redis.setex(redis_key, ttl, data)
            else:
                self._redis.set(redis_key, data)
        except Exception as e:
            logger.error(f"Redis set error: {e}")

    def delete(self, key: str):
        if not self._available:
            return

        try:
            self._redis.delete(self._prefixed(key))
        except Exception as e:
            logger.error(f"Redis delete error: {e}")

    def clear(self):
        if not self._available:
            return

        try:
            cursor = 0
            while True:
                cursor, keys = self._redis.scan(cursor, match=f"{self._key_prefix}*", count=100)
                if keys:
                    self._redis.delete(*keys)
                if cursor == 0:
                    break
        except Exception as e:
            logger.error(f"Redis clear error: {e}")

    def exists(self, key: str) -> bool:
        if not self._available:
            return False

        try:
            return self._redis.exists(self._prefixed(key)) > 0
        except Exception as e:
            logger.error(f"Redis exists error: {e}")
            return False

    def keys(self, pattern: str = "*") -> List[str]:
        if not self._available:
            return []

        try:
            full_pattern = f"{self._key_prefix}{pattern}"
            result = []
            cursor = 0
            while True:
                cursor, keys = self._redis.scan(cursor, match=full_pattern, count=100)
                result.extend([k.decode('utf-8') if isinstance(k, bytes) else k for k in keys])
                if cursor == 0:
                    break
            prefix_len = len(self._key_prefix)
            return [k[prefix_len:] if k.startswith(self._key_prefix) else k for k in result]
        except Exception as e:
            logger.error(f"Redis keys error: {e}")
            return []

    def close(self):
        if not self._available:
            return
        try:
            if hasattr(self._redis, 'close'):
                self._redis.close()
            elif hasattr(self._redis, 'connection_pool'):
                self._redis.connection_pool.disconnect()
        except Exception as e:
            logger.error(f"Redis close error: {e}")

    async def aclose(self):
        if not self._available:
            return
        try:
            if hasattr(self._redis, 'aclose'):
                await self._redis.aclose()
            elif hasattr(self._redis, 'close'):
                self._redis.close()
        except Exception as e:
            logger.error(f"Redis aclose error: {e}")

    def _ensure_async_redis(self):
        if not hasattr(self, '_aredis') or self._aredis is None:
            try:
                import redis.asyncio as aioredis
                self._aredis = aioredis.Redis(
                    host=getattr(self, '_host', 'localhost'),
                    port=getattr(self, '_port', 6379),
                    db=getattr(self, '_db', 0),
                    password=getattr(self, '_password', None),
                    decode_responses=False,
                )
            except ImportError:
                self._aredis = None
        return self._aredis

    async def aget(self, key: str) -> Optional[Any]:
        if not self._available:
            return None
        aredis = self._ensure_async_redis()
        if aredis is None:
            return await asyncio.to_thread(self.get, key)
        try:
            data = await aredis.get(self._prefixed(key))
            if data is None:
                return None
            return self._deserialize(data)
        except Exception as e:
            logger.error(f"Redis async get error: {e}")
            return None

    async def aset(self, key: str, value: Any, ttl: int = None):
        if not self._available:
            return
        aredis = self._ensure_async_redis()
        if aredis is None:
            return await asyncio.to_thread(self.set, key, value, ttl)
        try:
            data = self._serialize(value)
            redis_key = self._prefixed(key)
            if ttl:
                await aredis.setex(redis_key, ttl, data)
            else:
                await aredis.set(redis_key, data)
        except Exception as e:
            logger.error(f"Redis async set error: {e}")

    async def adelete(self, key: str):
        if not self._available:
            return
        aredis = self._ensure_async_redis()
        if aredis is None:
            return await asyncio.to_thread(self.delete, key)
        try:
            await aredis.delete(self._prefixed(key))
        except Exception as e:
            logger.error(f"Redis async delete error: {e}")

    async def aclear(self):
        if not self._available:
            return
        aredis = self._ensure_async_redis()
        if aredis is None:
            return await asyncio.to_thread(self.clear)
        try:
            cursor = 0
            while True:
                cursor, keys = await aredis.scan(cursor, match=f"{self._key_prefix}*", count=100)
                if keys:
                    await aredis.delete(*keys)
                if cursor == 0:
                    break
        except Exception as e:
            logger.error(f"Redis async clear error: {e}")

    async def aexists(self, key: str) -> bool:
        if not self._available:
            return False
        aredis = self._ensure_async_redis()
        if aredis is None:
            return await asyncio.to_thread(self.exists, key)
        try:
            return await aredis.exists(self._prefixed(key)) > 0
        except Exception as e:
            logger.error(f"Redis async exists error: {e}")
            return False

    async def akeys(self, pattern: str = "*") -> List[str]:
        if not self._available:
            return []
        aredis = self._ensure_async_redis()
        if aredis is None:
            return await asyncio.to_thread(self.keys, pattern)
        try:
            full_pattern = f"{self._key_prefix}{pattern}"
            result = []
            cursor = 0
            while True:
                cursor, keys = await aredis.scan(cursor, match=full_pattern, count=100)
                result.extend([k.decode('utf-8') if isinstance(k, bytes) else k for k in keys])
                if cursor == 0:
                    break
            prefix_len = len(self._key_prefix)
            return [k[prefix_len:] if k.startswith(self._key_prefix) else k for k in result]
        except Exception as e:
            logger.error(f"Redis async keys error: {e}")
            return []


__all__ = [
    'CacheStrategy',
    'CacheEntry',
    'CacheBackend',
    'MemoryCache',
    'RedisCache',
]
