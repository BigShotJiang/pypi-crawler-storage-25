#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.cache.lru_cache - Thread-safe LRU cache implementation
"""

import asyncio
import threading
import time
from typing import Any, Optional, Dict, List, Tuple
from collections import OrderedDict


class LRUCache:

    __slots__ = ('_max_size', '_ttl', '_cache', '_lock', '_async_lock', '_hits', '_misses')

    def __init__(self, max_size: int = 128, ttl: Optional[int] = None, default_ttl: Optional[int] = None, *, maxsize: int = None):
        self._max_size = maxsize if maxsize is not None else max_size
        self._ttl = default_ttl or ttl
        self._cache: OrderedDict[str, Tuple[Any, float, Optional[int]]] = OrderedDict()
        self._lock = threading.RLock()
        self._async_lock = asyncio.Lock()
        self._hits = 0
        self._misses = 0

    def _is_expired(self, key: str) -> bool:
        if key not in self._cache:
            return True
        _, created_at, item_ttl = self._cache[key]
        effective_ttl = item_ttl if item_ttl is not None else self._ttl
        if effective_ttl is not None and time.time() - created_at > effective_ttl:
            return True
        return False

    def _evict_expired(self, key: str):
        if key in self._cache and self._is_expired(key):
            del self._cache[key]

    async def aget(self, key: str) -> Optional[Any]:
        async with self._async_lock:
            if key not in self._cache:
                self._misses += 1
                return None
            if self._is_expired(key):
                self._evict_expired(key)
                self._misses += 1
                return None
            self._cache.move_to_end(key)
            self._hits += 1
            return self._cache[key][0]

    def get(self, key: str) -> Optional[Any]:
        with self._lock:
            if key not in self._cache:
                self._misses += 1
                return None
            if self._is_expired(key):
                self._evict_expired(key)
                self._misses += 1
                return None
            self._cache.move_to_end(key)
            self._hits += 1
            return self._cache[key][0]

    async def aset(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        async with self._async_lock:
            self._set_internal(key, value, ttl)

    def set(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        with self._lock:
            self._set_internal(key, value, ttl)

    put = set

    def _set_internal(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        if key in self._cache:
            self._cache.move_to_end(key)
        elif len(self._cache) >= self._max_size:
            self._cache.popitem(last=False)
        self._cache[key] = (value, time.time(), ttl)

    async def adelete(self, key: str) -> bool:
        async with self._async_lock:
            return self._delete_internal(key)

    def delete(self, key: str) -> bool:
        with self._lock:
            return self._delete_internal(key)

    def _delete_internal(self, key: str) -> bool:
        if key in self._cache:
            del self._cache[key]
            return True
        return False

    def clear(self) -> None:
        with self._lock:
            self._cache.clear()

    def has(self, key: str) -> bool:
        with self._lock:
            if key not in self._cache:
                return False
            if self._is_expired(key):
                self._evict_expired(key)
                return False
            return True

    def size(self) -> int:
        with self._lock:
            return len(self._cache)

    def keys(self) -> List[str]:
        with self._lock:
            return list(self._cache.keys())

    def cleanup_expired(self) -> int:
        cleaned = 0
        with self._lock:
            expired_keys = []
            for key, (_, created_at, item_ttl) in list(self._cache.items()):
                effective_ttl = item_ttl if item_ttl is not None else self._ttl
                if effective_ttl is not None and time.time() - created_at > effective_ttl:
                    expired_keys.append(key)
            for key in expired_keys:
                del self._cache[key]
                cleaned += 1
        return cleaned

    def get_stats(self) -> Dict[str, Any]:
        with self._lock:
            expired_count = 0
            now = time.time()
            for key, (_, created_at, item_ttl) in self._cache.items():
                effective_ttl = item_ttl if item_ttl is not None else self._ttl
                if effective_ttl is not None and now - created_at > effective_ttl:
                    expired_count += 1
            total = self._hits + self._misses
            hit_rate = self._hits / total if total > 0 else 0.0
            return {
                "size": len(self._cache),
                "max_size": self._max_size,
                "ttl": self._ttl,
                "expired_count": expired_count,
                "active_count": len(self._cache) - expired_count,
                "hit_rate": hit_rate,
                "hits": self._hits,
                "misses": self._misses,
            }


__all__ = [
    'LRUCache',
]
