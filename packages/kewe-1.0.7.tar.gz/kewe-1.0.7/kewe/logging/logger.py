#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.logging.logger - Logger setup with structured and contextual logging
"""

import logging
import logging.config
import sys
from kewe.utils.compat import json
from typing import Dict, Any, Optional, Union
from datetime import datetime


class KeweLogger(logging.Logger):

    def __init__(
        self,
        name: str = "kewe",
        level: int = logging.INFO,
        access_log: bool = True,
        error_log: bool = True,
        json_format: bool = False
    ):
        super().__init__(name, level)
        self.access_log_enabled = access_log
        self.error_log_enabled = error_log
        self.json_format = json_format
        
        self._access_logger = logging.getLogger(f"{name}.access")
        self._access_logger.setLevel(logging.INFO)
        
        self._error_logger = logging.getLogger(f"{name}.error")
        self._error_logger.setLevel(logging.ERROR)
        
        self._setup_handlers()
    
    def _setup_handlers(self):
        self.handlers.clear()
        self._access_logger.handlers.clear()
        self._error_logger.handlers.clear()
        
        # 控制台处理器
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(self.level)
        
        if self.json_format:
            from .formatters import JSONFormatter
            formatter = JSONFormatter()
        else:
            from .formatters import ColoredFormatter
            formatter = ColoredFormatter()
        
        console_handler.setFormatter(formatter)
        self.addHandler(console_handler)
        
        # 访问日志处理器
        if self.access_log_enabled:
            access_handler = logging.StreamHandler(sys.stdout)
            access_handler.setLevel(logging.INFO)
            from .filters import AccessLogFilter
            access_handler.addFilter(AccessLogFilter())
            
            if self.json_format:
                from .formatters import JSONFormatter
                access_formatter = JSONFormatter()
            else:
                access_formatter = logging.Formatter(
                    '%(client_ip)s - - [%(asctime)s] "%(method)s %(path)s %(protocol)s" %(status)s %(length)s'
                )
            
            access_handler.setFormatter(access_formatter)
            self._access_logger.addHandler(access_handler)
        
        # 错误日志处理器
        if self.error_log_enabled:
            error_handler = logging.StreamHandler(sys.stderr)
            error_handler.setLevel(logging.ERROR)
            
            if self.json_format:
                from .formatters import JSONFormatter
                error_formatter = JSONFormatter()
            else:
                error_formatter = logging.Formatter(
                    '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
                )
            
            error_handler.setFormatter(error_formatter)
            self._error_logger.addHandler(error_handler)
    
    def debug(self, message: str, **extra):
        super().debug(message, extra=extra)
    
    def info(self, message: str, **extra):
        super().info(message, extra=extra)
    
    def warning(self, message: str, **extra):
        super().warning(message, extra=extra)
    
    def error(self, message: str, **extra):
        super().error(message, extra=extra)
        if self.error_log_enabled:
            self._error_logger.error(message, extra=extra)
    
    def critical(self, message: str, **extra):
        super().critical(message, extra=extra)
        if self.error_log_enabled:
            self._error_logger.critical(message, extra=extra)

    def set_level(self, level: Union[int, str]):
        """动态设置日志级别

        Args:
            level: 日志级别，可以是字符串('DEBUG','INFO','WARNING','ERROR','CRITICAL')或整数
        """
        if isinstance(level, str):
            level = getattr(logging, level.upper(), logging.INFO)
        self.setLevel(level)
        for handler in self.handlers:
            handler.setLevel(level)
        self._access_logger.setLevel(level)
        self._error_logger.setLevel(level)
    
    def log_request(
        self,
        request: Any,
        response: Any,
        duration: float = None
    ):
        """
        记录访问日志
        
        Args:
            request: 请求对象
            response: 响应对象
            duration: 处理耗时（秒）
        """
        if not self.access_log_enabled:
            return
        
        # 提取请求信息
        client_ip = getattr(request, 'client_ip', '-')
        method = getattr(request, 'method', '-')
        path = getattr(request, 'path', '-')
        protocol = getattr(request, 'protocol', 'HTTP/1.1')
        user_agent = getattr(request, 'headers', {}).get('user-agent', '-')
        
        # 提取响应信息
        status = getattr(response, 'status', 200)
        length = len(getattr(response, 'body', b''))
        content_type = getattr(response, 'content_type', '-')
        
        extra = {
            'client_ip': client_ip,
            'method': method,
            'path': path,
            'protocol': protocol,
            'user_agent': user_agent,
            'status': status,
            'length': length,
            'content_type': content_type,
        }
        
        if duration is not None:
            extra['duration'] = f"{duration:.3f}s"
            extra['duration_ms'] = int(duration * 1000)
        
        # 构建日志消息
        message = f"{client_ip} - {method} {path} {protocol} {status} {length} {duration:.3f}s" if duration is not None else f"{client_ip} - {method} {path} {protocol} {status} {length}"
        
        self._access_logger.info(message, extra=extra)
    
    def log_exception(
        self,
        exception: Exception,
        request: Any = None
    ):
        """
        记录异常日志
        
        Args:
            exception: 异常对象
            request: 请求对象（可选）
        """
        extra = {
            'exception_type': type(exception).__name__,
            'exception_message': str(exception),
        }
        
        if request:
            extra['client_ip'] = getattr(request, 'client_ip', '-')
            extra['method'] = getattr(request, 'method', '-')
            extra['path'] = getattr(request, 'path', '-')
        
        self._error_logger.exception(exception, extra=extra)


# 全局日志器实例
_global_logger: Optional[KeweLogger] = None


def get_logger(name: str = "kewe") -> KeweLogger:
    """
    获取日志器实例
    
    Args:
        name: 日志器名称
        
    Returns:
        KeweLogger实例
    """
    global _global_logger
    if _global_logger is None:
        _global_logger = KeweLogger(name)
    return _global_logger


def setup_logging(
    level: int = logging.INFO,
    json_format: bool = False,
    access_log: bool = True,
    error_log: bool = True,
    log_config: Optional[dict] = None
) -> 'KeweLogger':
    from kewe.logging.setup import setup_logging as _setup
    _setup(level=level, json_format=json_format, access_log=access_log,
           error_log=error_log, log_config=log_config)
    global _global_logger
    _global_logger = KeweLogger(
        level=level,
        json_format=json_format,
        access_log=access_log,
        error_log=error_log
    )
    return _global_logger


# 便捷函数
def debug(message: str, **extra):
    """记录调试日志"""
    get_logger().debug(message, **extra)


def info(message: str, **extra):
    """记录信息日志"""
    get_logger().info(message, **extra)


def warning(message: str, **extra):
    """记录警告日志"""
    get_logger().warning(message, **extra)


def error(message: str, **extra):
    """记录错误日志"""
    get_logger().error(message, **extra)


def critical(message: str, **extra):
    """记录严重错误日志"""
    get_logger().critical(message, **extra)
