#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.logging.formatters - Log formatters including JSON and colorized output
"""

import logging
from .access import AccessLogFormatter
from kewe.utils.compat import json
import os
import sys
from datetime import datetime, timezone
from typing import Dict, Any, Optional


class ColoredFormatter(logging.Formatter):
    """
    彩色日志格式化器 - ColoredFormatter
    
    根据日志级别使用不同的颜色输出
    """
    
    # ANSI颜色代码
    COLORS = {
        'DEBUG': '\033[36m',      # 青色
        'INFO': '\033[32m',       # 绿色
        'WARNING': '\033[33m',    # 黄色
        'ERROR': '\033[31m',      # 红色
        'CRITICAL': '\033[35m',   # 紫色
        'BOLD': '\033[1m',        # 粗体
        'RESET': '\033[0m',       # 重置
    }
    
    # HTTP状态码颜色
    STATUS_COLORS = {
        '2': '\033[32m',  # 2xx - 绿色
        '3': '\033[33m',  # 3xx - 黄色
        '4': '\033[31m',  # 4xx - 红色
        '5': '\033[35m',  # 5xx - 紫色
    }
    
    def __init__(
        self,
        fmt: str = None,
        datefmt: str = None,
        use_colors: bool = True,
        style: str = '%'
    ):
        super().__init__(fmt, datefmt, style)
        if os.environ.get('NO_COLOR') is not None:
            self.use_colors = False
        elif os.environ.get('FORCE_COLOR') is not None or os.environ.get('KEWE_FORCE_COLOR') is not None:
            self.use_colors = use_colors
        else:
            self.use_colors = use_colors and sys.stdout.isatty()
    
    def format(self, record: logging.LogRecord) -> str:
        """格式化日志记录"""
        original_levelname = record.levelname
        original_status = getattr(record, 'status', None)
        
        if self.use_colors:
            color = self.COLORS.get(record.levelname, self.COLORS['RESET'])
            reset = self.COLORS['RESET']
            bold = self.COLORS['BOLD']
            
            if record.levelname in ('ERROR', 'CRITICAL'):
                record.levelname = f"{bold}{color}{record.levelname}{reset}"
            else:
                record.levelname = f"{color}{record.levelname}{reset}"
            
            if hasattr(record, 'status'):
                status_str = str(record.status)
                status_color = self.STATUS_COLORS.get(status_str[0], self.COLORS['RESET'])
                record.status = f"{status_color}{record.status}{reset}"
        
        result = super().format(record)
        
        record.levelname = original_levelname
        if original_status is not None:
            record.status = original_status
        elif hasattr(record, 'status'):
            delattr(record, 'status')
        
        return result


class JSONFormatter(logging.Formatter):
    """
    JSON格式日志格式化器 - JSONFormatter
    
    将日志输出为JSON格式，便于日志收集和分析
    """
    
    def __init__(
        self,
        indent: Optional[int] = None,
        fields: Optional[list] = None
    ):
        super().__init__()
        self.indent = indent
        self.fields = fields or [
            'timestamp', 'level', 'logger', 'message', 'module',
            'function', 'line', 'thread', 'process'
        ]
    
    def format(self, record: logging.LogRecord) -> str:
        """格式化为JSON"""
        log_data: Dict[str, Any] = {
            'timestamp': datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z'),
            'level': record.levelname,
            'logger': record.name,
            'message': record.getMessage(),
        }
        
        # 添加标准字段
        if 'module' in self.fields:
            log_data['module'] = record.module
        if 'function' in self.fields:
            log_data['function'] = record.funcName
        if 'line' in self.fields:
            log_data['line'] = record.lineno
        if 'thread' in self.fields:
            log_data['thread'] = record.thread
        if 'process' in self.fields:
            log_data['process'] = record.process
        
        # 添加HTTP相关字段
        http_fields = ['method', 'path', 'status', 'client_ip', 'duration', 'user_agent']
        for field in http_fields:
            if hasattr(record, field):
                log_data[field] = getattr(record, field)
        
        # 添加异常信息
        if record.exc_info:
            log_data['exception'] = {
                'type': record.exc_info[0].__name__ if record.exc_info[0] else None,
                'message': str(record.exc_info[1]) if record.exc_info[1] else None,
                'traceback': self.formatException(record.exc_info)
            }
        
        # 添加其他额外属性
        standard_attrs = {
            'args', 'asctime', 'created', 'exc_info', 'exc_text',
            'filename', 'funcName', 'levelname', 'levelno', 'lineno',
            'module', 'msecs', 'msg', 'name', 'pathname', 'process',
            'processName', 'relativeCreated', 'stack_info', 'thread',
            'threadName', 'message'
        }
        
        for key, value in record.__dict__.items():
            if key not in log_data and key not in standard_attrs and not key.startswith('_'):
                log_data[key] = value
        
        return json.dumps(log_data, indent=self.indent, default=str, ensure_ascii=False)


class DetailedFormatter(logging.Formatter):
    """
    详细日志格式化器
    
    提供包含更多上下文的详细日志格式
    """
    
    def __init__(
        self,
        fmt: str = None,
        datefmt: str = None,
        use_colors: bool = True
    ):
        if fmt is None:
            fmt = '%(asctime)s [%(process)d:%(thread)d] %(name)s - %(levelname)s - [%(filename)s:%(lineno)d in %(funcName)s] - %(message)s'
        
        super().__init__(fmt, datefmt)
        self.use_colors = use_colors and sys.stdout.isatty()
    
    def format(self, record: logging.LogRecord) -> str:
        """格式化详细日志"""
        # 添加颜色
        if self.use_colors:
            colors = {
                'DEBUG': '\033[36m',
                'INFO': '\033[32m',
                'WARNING': '\033[33m',
                'ERROR': '\033[31m',
                'CRITICAL': '\033[35m',
                'RESET': '\033[0m',
            }
            
            original_levelname = record.levelname
            color = colors.get(record.levelname, colors['RESET'])
            record.levelname = f"{color}{record.levelname}{colors['RESET']}"
            
            result = super().format(record)
            record.levelname = original_levelname
            return result
        
        return super().format(record)


# 便捷函数
def create_formatter(
    format_type: str = 'colored',
    use_colors: bool = True,
    **kwargs
) -> logging.Formatter:
    """
    创建格式化器的便捷函数
    
    Args:
        format_type: 格式类型 ('colored', 'access', 'json', 'detailed')
        use_colors: 是否使用颜色
        **kwargs: 其他参数
    
    Returns:
        Formatter实例
    """
    formatters = {
        'colored': ColoredFormatter,
        'access': AccessLogFormatter,
        'json': JSONFormatter,
        'detailed': DetailedFormatter,
    }
    
    formatter_class = formatters.get(format_type, ColoredFormatter)
    
    if format_type == 'json':
        return formatter_class(**kwargs)
    elif format_type == 'access':
        return formatter_class(**kwargs)
    else:
        return formatter_class(use_colors=use_colors, **kwargs)


__all__ = [
    'ColoredFormatter',
    'AccessLogFormatter',
    'JSONFormatter',
    'DetailedFormatter',
    'create_formatter',
]
