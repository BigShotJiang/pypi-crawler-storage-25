#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.logging.filters - Log filtering utilities for level and context
"""

import logging
import random
from typing import Optional


class AccessLogFilter(logging.Filter):
    """
    访问日志过滤器
    
    支持采样率和状态码过滤
    """

    def __init__(
        self,
        name: str = '',
        sample_rate: float = 1.0,
        skip_success: bool = False,
    ):
        super().__init__(name)
        self.sample_rate = max(0.0, min(1.0, sample_rate))
        self.skip_success = skip_success

    def filter(self, record: logging.LogRecord) -> bool:
        if not hasattr(record, 'method'):
            record.method = '-'
        if not hasattr(record, 'path'):
            record.path = '-'
        if not hasattr(record, 'status'):
            record.status = '-'
        if not hasattr(record, 'client_ip'):
            record.client_ip = '-'

        if self.sample_rate < 1.0:
            if random.random() > self.sample_rate:
                return False

        if self.skip_success:
            status = getattr(record, 'status', '-')
            if isinstance(status, int) and 200 <= status < 400:
                return False

        return True






class ErrorLogFilter(logging.Filter):
    """
    错误日志过滤器
    
    只记录ERROR级别及以上的日志
    """
    
    def filter(self, record: logging.LogRecord) -> bool:
        """只保留ERROR及以上级别的日志"""
        return record.levelno >= logging.ERROR


class ExcludePatternFilter(logging.Filter):
    """
    模式排除日志过滤器
    
    过滤掉匹配排除模式的日志记录
    """
    
    def __init__(self, name: str = '', exclude_patterns: Optional[list] = None):
        super().__init__(name)
        self.exclude_patterns = exclude_patterns or []
    
    def filter(self, record: logging.LogRecord) -> bool:
        """过滤日志记录"""
        # 检查排除模式
        message = record.getMessage()
        for pattern in self.exclude_patterns:
            if pattern in message:
                return False
        
        return True
