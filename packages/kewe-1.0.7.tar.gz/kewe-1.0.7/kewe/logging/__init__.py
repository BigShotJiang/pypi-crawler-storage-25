#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.logging - Logging package initialization
"""

from .setup import setup_logging, reset_logging
from .formatters import ColoredFormatter, JSONFormatter
from .filters import AccessLogFilter
from .access import (
    SENSITIVE_FIELDS, SENSITIVE_HEADERS, SENSITIVE_PATTERNS,
    AccessLogRecord, AccessLogFormatter, AccessLogger, AccessLogMiddleware,
)
from .logger import KeweLogger, get_logger, debug, info, warning, error, critical

__all__ = [
    'setup_logging',
    'reset_logging',
    'ColoredFormatter',
    'JSONFormatter',
    'AccessLogFilter',
    'SENSITIVE_FIELDS',
    'SENSITIVE_HEADERS',
    'SENSITIVE_PATTERNS',
    'AccessLogRecord',
    'AccessLogFormatter',
    'AccessLogger',
    'AccessLogMiddleware',
    'KeweLogger',
    'get_logger',
    'debug',
    'info',
    'warning',
    'error',
    'critical',
]
