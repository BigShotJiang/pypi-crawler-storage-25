#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.logging.access - HTTP access logging with Apache-style format
"""

import logging
import time
from kewe.utils.compat import json as _json
import re
from typing import Optional, Dict, Any, Callable, Set
from datetime import datetime
from dataclasses import dataclass


SENSITIVE_FIELDS: Set[str] = {
    "password", "passwd", "pwd",
    "token", "access_token", "refresh_token", "auth_token",
    "secret", "api_key", "apikey", "api_secret",
    "authorization", "credential", "credentials",
    "private_key", "privatekey", "private-key",
    "session_id", "sessionid", "session-id",
    "credit_card", "creditcard", "card_number",
    "ssn", "social_security",
    "pin", "otp", "code"
}

SENSITIVE_HEADERS: Set[str] = {
    "authorization", "cookie", "set-cookie",
    "x-api-key", "x-auth-token", "x-access-token",
    "proxy-authorization", "www-authenticate"
}

SENSITIVE_PATTERNS = [
    re.compile(r"(bearer\s+)[^\s]+", re.IGNORECASE),
    re.compile(r"(basic\s+)[^\s]+", re.IGNORECASE),
    re.compile(r"(token[=:\s]+)[^\s]+", re.IGNORECASE),
    re.compile(r"(password[=:\s]+)[^\s]+", re.IGNORECASE),
    re.compile(r"(api[_-]?key[=:\s]+)[^\s]+", re.IGNORECASE),
]


@dataclass(slots=True)
class AccessLogRecord:
    """访问日志记录"""
    client_ip: str = "-"
    method: str = "-"
    path: str = "-"
    query_string: str = ""
    protocol: str = "HTTP/1.1"
    status: int = 0
    content_length: int = 0
    referer: str = "-"
    user_agent: str = "-"
    duration: float = 0.0
    request_id: str = "-"
    timestamp: datetime = None
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.now()


class AccessLogFormatter:
    """
    访问日志格式化器
    
    支持的格式字段:
        %t - 时间戳
        %T - 时间戳 (ISO格式)
        %m - HTTP方法
        %p - 请求路径
        %q - 查询字符串
        %H - 协议版本
        %s - 状态码
        %b - 响应大小
        %B - 响应大小 (字节)
        %h - 客户端IP
        %r - 引用页
        %u - 用户代理
        %D - 处理时间 (毫秒)
        %d - 处理时间 (秒)
        %i - 请求ID
        %l - 请求行 (方法 路径 协议)
        %L - 请求行带查询字符串
        
    使用示例:
        # 默认格式
        formatter = AccessLogFormatter()
        
        # 自定义格式
        formatter = AccessLogFormatter(
            format="%h - %l %s %b %Dms"
        )
        
        # Combined格式
        formatter = AccessLogFormatter.combined()
        
        # Common格式
        formatter = AccessLogFormatter.common()
    """
    
    DEFAULT_FORMAT = '%h - %l %s %b %Dms'
    COMBINED_FORMAT = '%h - %l %s %b "%r" "%u"'
    COMMON_FORMAT = '%h - %l %s %b'
    JSON_FORMAT = 'json'
    
    def __init__(
        self,
        format: str = None,
        time_format: str = "%Y-%m-%d %H:%M:%S",
        json_format: bool = False
    ):
        self.format = format or self.DEFAULT_FORMAT
        self.time_format = time_format
        self.json_format = json_format or self.format == self.JSON_FORMAT
    
    @classmethod
    def combined(cls) -> "AccessLogFormatter":
        """创建 Combined 格式格式化器"""
        return cls(format=cls.COMBINED_FORMAT)
    
    @classmethod
    def common(cls) -> "AccessLogFormatter":
        """创建 Common 格式格式化器"""
        return cls(format=cls.COMMON_FORMAT)
    
    @classmethod
    def json(cls) -> "AccessLogFormatter":
        """创建 JSON 格式格式化器"""
        return cls(format=cls.JSON_FORMAT, json_format=True)
    
    def format_record(self, record: AccessLogRecord) -> str:
        """格式化日志记录"""
        if self.json_format:
            return self._format_json(record)
        
        result = self.format
        
        replacements = {
            '%t': record.timestamp.strftime(self.time_format) if record.timestamp else '-',
            '%T': record.timestamp.isoformat() if record.timestamp else '-',
            '%m': record.method,
            '%p': record.path,
            '%q': record.query_string if record.query_string else '',
            '%H': record.protocol,
            '%s': str(record.status),
            '%b': self._format_size(record.content_length),
            '%B': str(record.content_length),
            '%h': record.client_ip,
            '%r': record.referer,
            '%u': record.user_agent,
            '%D': f"{record.duration * 1000:.0f}",
            '%d': f"{record.duration:.3f}",
            '%i': record.request_id,
            '%l': f"{record.method} {record.path} {record.protocol}",
            '%L': self._build_request_line(record),
        }
        
        for key, value in replacements.items():
            result = result.replace(key, value)
        
        return result
    
    def _format_json(self, record: AccessLogRecord) -> str:
        data = {
            "timestamp": record.timestamp.isoformat() if record.timestamp else None,
            "client_ip": record.client_ip,
            "method": record.method,
            "path": record.path,
            "query_string": record.query_string,
            "protocol": record.protocol,
            "status": record.status,
            "content_length": record.content_length,
            "referer": record.referer,
            "user_agent": record.user_agent,
            "duration_ms": round(record.duration * 1000, 2),
            "request_id": record.request_id,
        }
        
        return _json.dumps(data)
    
    def _format_size(self, size: int) -> str:
        """格式化大小"""
        if size < 1024:
            return f"{size}B"
        elif size < 1024 * 1024:
            return f"{size / 1024:.1f}KB"
        elif size < 1024 * 1024 * 1024:
            return f"{size / (1024 * 1024):.1f}MB"
        else:
            return f"{size / (1024 * 1024 * 1024):.1f}GB"
    
    def _build_request_line(self, record: AccessLogRecord) -> str:
        """构建请求行"""
        path = record.path
        if record.query_string:
            path = f"{path}?{record.query_string}"
        return f"{record.method} {path} {record.protocol}"


class AccessLogger:
    """
    访问日志记录器
    
    使用示例:
        logger = AccessLogger(
            format="%h - %l %s %b %Dms",
            enabled=True
        )
        
        # 记录请求
        logger.log(AccessLogRecord(
            client_ip="127.0.0.1",
            method="GET",
            path="/api/users",
            status=200,
            content_length=1024,
            duration=0.05
        ))
    """
    
    def __init__(
        self,
        format: str = None,
        enabled: bool = True,
        logger: logging.Logger = None,
        json_format: bool = False,
        mask_sensitive: bool = True,
        mask_char: str = "*"
    ):
        self.enabled = enabled
        self.formatter = AccessLogFormatter(format=format, json_format=json_format)
        self._logger = logger or logging.getLogger("kewe.access")
        self.mask_sensitive = mask_sensitive
        self.mask_char = mask_char
    
    @staticmethod
    def mask_value(value: str, mask_char: str = "*", visible_chars: int = 4) -> str:
        """脱敏值"""
        if not value or len(value) <= visible_chars:
            return mask_char * len(value) if value else ""
        return value[:visible_chars // 2] + mask_char * (len(value) - visible_chars // 2)
    
    @staticmethod
    def mask_sensitive_data(data: str, mask_char: str = "*") -> str:
        """脱敏敏感数据"""
        if not data:
            return data
        
        result = data
        for pattern in SENSITIVE_PATTERNS:
            result = pattern.sub(
                lambda m: m.group(1) + mask_char * 8,
                result
            )
        
        return result
    
    @staticmethod
    def mask_query_string(query_string: str, mask_char: str = "*") -> str:
        """脱敏查询字符串中的敏感参数"""
        if not query_string:
            return query_string
        
        from urllib.parse import parse_qs, urlencode
        
        try:
            params = parse_qs(query_string, keep_blank_values=True)
            masked_params = {}
            
            for key, values in params.items():
                if key.lower() in SENSITIVE_FIELDS:
                    masked_params[key] = [AccessLogger.mask_value(v, mask_char) for v in values]
                else:
                    masked_params[key] = values
            
            return urlencode(masked_params, doseq=True)
        except Exception:
            return query_string
    
    @staticmethod
    def mask_headers(headers: Dict[str, str], mask_char: str = "*") -> Dict[str, str]:
        """脱敏请求头中的敏感信息"""
        if not headers:
            return headers
        
        masked = {}
        for key, value in headers.items():
            if key.lower() in SENSITIVE_HEADERS:
                masked[key] = AccessLogger.mask_value(value, mask_char)
            else:
                masked[key] = value
        
        return masked
    
    def log(self, record: AccessLogRecord) -> None:
        """记录访问日志"""
        if not self.enabled:
            return
        
        if self.mask_sensitive:
            record.query_string = self.mask_query_string(record.query_string, self.mask_char)
            record.path = self.mask_sensitive_data(record.path, self.mask_char)
        
        message = self.formatter.format_record(record)
        self._logger.info(message)
    
    def log_request(
        self,
        request,
        response,
        duration: float = 0.0,
        request_id: str = None
    ) -> None:
        """
        从请求和响应对象记录日志
        
        Args:
            request: 请求对象
            response: 响应对象
            duration: 处理时间（秒）
            request_id: 请求ID
        """
        if not self.enabled:
            return
        
        query_string = ""
        if hasattr(request, 'query_params') and request.query_params:
            from urllib.parse import urlencode
            query_string = urlencode(request.query_params, doseq=True)
        
        record = AccessLogRecord(
            client_ip=getattr(request, 'client_ip', '-'),
            method=getattr(request, 'method', '-'),
            path=getattr(request, 'path', '-'),
            query_string=query_string,
            protocol=getattr(request, 'protocol', 'HTTP/1.1'),
            status=getattr(response, 'status', 0),
            content_length=len(getattr(response, 'body', b'') or b''),
            referer=dict(getattr(request, 'headers', {})).get('referer', '-'),
            user_agent=dict(getattr(request, 'headers', {})).get('user-agent', '-'),
            duration=duration,
            request_id=request_id or '-',
        )
        
        self.log(record)


class AccessLogMiddleware:
    """
    访问日志中间件
    
    使用示例:
        from kewe import Kewe
        from kewe.logging.access import AccessLogMiddleware
        
        app = Kewe("MyApp")
        
        # 使用默认格式
        app.middleware_manager.register(AccessLogMiddleware())
        
        # 使用自定义格式
        app.middleware_manager.register(AccessLogMiddleware(
            format="%h - %l %s %b %Dms"
        ))
    """
    
    def __init__(
        self,
        format: str = None,
        enabled: bool = True,
        json_format: bool = False
    ):
        self.logger = AccessLogger(
            format=format,
            enabled=enabled,
            json_format=json_format
        )
    
    async def __call__(self, request):
        """请求处理前"""
        request._start_time = time.time()
        return True
    
    async def on_response(self, request, response):
        """响应处理后"""
        duration = 0.0
        if hasattr(request, '_start_time'):
            duration = time.time() - request._start_time
        
        request_id = getattr(request, 'request_id', None) or getattr(request.ctx, 'request_id', None)
        
        self.logger.log_request(request, response, duration, request_id)


__all__ = [
    'AccessLogRecord',
    'AccessLogFormatter',
    'AccessLogger',
    'AccessLogMiddleware',
]
