#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.__main__ - CLI entry point for running the framework via python -m
"""

from kewe.cli.app import main

if __name__ == "__main__":
    main()
