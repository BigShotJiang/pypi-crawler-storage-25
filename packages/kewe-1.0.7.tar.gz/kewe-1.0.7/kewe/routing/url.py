#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.routing.url - URL building with reverse lookup support
"""

from typing import Dict, Optional, Any, List
from urllib.parse import urlencode, quote
from collections import OrderedDict
import re
import logging




logger = logging.getLogger(__name__)

class URL:
    """
    URL类 - 用于构建和解析URL
    """
    
    def __init__(self, path: str):
        self.path = path
    
    def build(self, params: Dict[str, Any]) -> str:
        """构建URL路径"""
        from urllib.parse import quote
        result = self.path
        for key, value in params.items():
            str_value = str(value)
            encoded = quote(str_value, safe='')
            path_encoded = quote(str_value, safe='/')
            result = result.replace(f'<{key}>', encoded)
            result = result.replace(f'<{key}:int>', str_value)
            result = result.replace(f'<{key}:str>', encoded)
            result = result.replace(f'<{key}:path>', path_encoded)
        return result


class URLBuilder:
    """
    URL构建器 - URL构建
    """
    
    def __init__(self, host: str = "", scheme: str = "http", port: int = None):
        self.host = host
        self.scheme = scheme
        self.port = port
    
    def build(
        self,
        path: str,
        query: Dict[str, Any] = None,
        fragment: str = None,
        params: Dict[str, Any] = None
    ) -> str:
        """构建完整URL"""
        # 构建基础URL
        url = f"{self.scheme}://{self.host}"
        
        if self.port and self.port not in (80, 443):
            url += f":{self.port}"
        
        # 添加路径
        if not path.startswith('/'):
            path = '/' + path
        url += path
        
        # 添加查询参数
        query_params = query or params
        if query_params:
            url += '?' + urlencode(query_params, doseq=True)
        
        # 添加片段
        if fragment:
            url += '#' + quote(fragment)
        
        return url


class RouteCache:
    """
    路由缓存 - 缓存路由匹配结果
    """

    def __init__(self, max_size: int = 1000):
        self.max_size = max_size
        self._cache: OrderedDict[str, Any] = OrderedDict()

    def get(self, key: str) -> Optional[Any]:
        """获取缓存值"""
        if key in self._cache:
            self._cache.move_to_end(key)
            return self._cache[key]
        return None

    def set(self, key: str, value: Any):
        """设置缓存值"""
        if key in self._cache:
            self._cache.move_to_end(key)
            self._cache[key] = value
        else:
            if len(self._cache) >= self.max_size:
                self._cache.popitem(last=False)
            self._cache[key] = value

    def clear(self):
        """清空缓存"""
        self._cache.clear()


class HostRouter:
    """
    主机路由 - 基于Host头的路由
    """
    
    def __init__(self):
        self._routes: Dict[str, Any] = {}
        self._patterns: List[tuple] = []
    
    def add_route(self, host: str, app_or_handler: Any):
        """添加主机路由"""
        # 检查是否是正则表达式
        if '*' in host or '?' in host or '[' in host:
            pattern = host.replace('.', r'\.').replace('*', '.*').replace('?', '.')
            self._patterns.append((re.compile(pattern), app_or_handler))
        else:
            self._routes[host.lower()] = app_or_handler
    
    def get_handler(self, host: str) -> Optional[Any]:
        """获取主机对应的处理器"""
        host = host.lower()
        
        # 精确匹配
        if host in self._routes:
            return self._routes[host]
        
        # 模式匹配
        for pattern, handler in self._patterns:
            if pattern.match(host):
                return handler
        
        return None


def url_for(
    endpoint: str,
    _external: bool = False,
    _scheme: str = None,
    _anchor: str = None,
    **values
) -> str:
    """
    URL生成函数 - url_for

    通过请求上下文自动获取当前应用实例，委托给 app.url_for() 查询路由注册表。
    若无请求上下文，则回退到简单路径拼接。

    使用示例:
        url_for('user_profile', user_id=123)
        url_for('user_profile', user_id=123, _external=True)
    """
    try:
        from kewe.base.context import get_app
        app = get_app()
        if app is not None and hasattr(app, 'url_for'):
            url = app.url_for(endpoint, **values)
            if _external:
                from kewe.base.context import get_request
                req = get_request()
                if req is not None and hasattr(req, 'url'):
                    scheme = _scheme or str(req.url.scheme)
                    host = req.headers.get('host', 'localhost')
                    if not url.startswith(('http://', 'https://')):
                        url = f"{scheme}://{host}{url}"
                elif not url.startswith(('http://', 'https://')):
                    scheme = _scheme or 'http'
                    url = f"{scheme}://localhost{url}"
            if _anchor:
                url = f"{url}#{_anchor}"
            return url
    except Exception:
        logger.warning("URL building failed", exc_info=True)

    raise RuntimeError(
        f"Cannot generate URL for '{endpoint}' outside of request context. "
        f"Use app.url_for() instead."
    )


def safe_url(url: str) -> str:
    """安全的URL编码"""
    return quote(url, safe='/:?#[]@!$&\'()*+,;=')


def url_decode(query_string: str) -> Dict[str, List[str]]:
    """URL解码查询字符串"""
    from urllib.parse import parse_qs
    return parse_qs(query_string, keep_blank_values=True)


__all__ = [
    'URL',
    'URLBuilder',
    'RouteCache',
    'HostRouter',
    'url_for',
    'safe_url',
    'url_decode',
]
