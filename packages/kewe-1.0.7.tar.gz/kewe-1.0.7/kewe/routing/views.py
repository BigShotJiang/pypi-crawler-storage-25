#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.routing.views - Class-based views with HTTP method dispatching
"""

import asyncio
import inspect
import logging
from typing import Callable, Dict, List, Optional, Any, Union
from functools import wraps

logger = logging.getLogger(__name__)


class HTTPMethodView:
    """
    HTTP方法视图基类
    
    使用示例:
        class UserView(HTTPMethodView):
            async def get(self, request):
                return {"users": []}
            
            async def post(self, request):
                return {"created": True}
        
        app.add_route("/users", UserView.as_view())
    """
    
    # 装饰器存储 — initialized per-instance in __init_subclass__
    decorators: List[Callable]

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        cls.decorators = []  # Fresh list per subclass, avoids shared mutable class variable
    
    def __init__(self):
        self.request = None
        self.args = None
        self.kwargs = None
    
    @classmethod
    def as_view(cls, *class_args, **class_kwargs):
        async def view(request, *args, **kwargs):
            instance = cls(*class_args, **class_kwargs)
            instance.request = request
            instance.args = args
            instance.kwargs = kwargs

            result = instance.dispatch_request(request, *args, **kwargs)
            if asyncio.iscoroutine(result):
                result = await result
            return result

        if cls.decorators:
            for decorator in reversed(cls.decorators):
                view = decorator(view)

        view._is_view = True
        view._view_class = cls
        view.__doc__ = cls.__doc__
        view.__module__ = cls.__module__
        view.__name__ = cls.__name__

        return view
    
    @classmethod
    def _get_allowed_methods(cls) -> List[str]:
        """获取允许的HTTP方法列表"""
        methods = []
        for method in ['get', 'post', 'put', 'delete', 'patch', 'head', 'options']:
            if hasattr(cls, method) and callable(getattr(cls, method)):
                methods.append(method.upper())
        return methods
    
    def dispatch_request(self, request, *args, **kwargs):
        method = request.method.lower()
        handler = getattr(self, method, None)

        if handler is None:
            from kewe.errors.exceptions import MethodNotAllowed
            raise MethodNotAllowed(
                f"Method {request.method} not allowed",
                allowed_methods=self._get_allowed_methods()
            )

        return handler(request, *args, **kwargs)
    
    # 默认的HTTP方法实现（可选重写）
    async def get(self, request, *args, **kwargs):
        """GET请求处理"""
        raise NotImplementedError("GET method not implemented")
    
    async def post(self, request, *args, **kwargs):
        """POST请求处理"""
        raise NotImplementedError("POST method not implemented")
    
    async def put(self, request, *args, **kwargs):
        """PUT请求处理"""
        raise NotImplementedError("PUT method not implemented")
    
    async def delete(self, request, *args, **kwargs):
        """DELETE请求处理"""
        raise NotImplementedError("DELETE method not implemented")
    
    async def patch(self, request, *args, **kwargs):
        """PATCH请求处理"""
        raise NotImplementedError("PATCH method not implemented")
    
    async def head(self, request, *args, **kwargs):
        """HEAD请求处理"""
        # 默认使用GET方法，但只返回头部
        response = await self.get(request, *args, **kwargs)
        if hasattr(response, 'body'):
            response.body = b""
        return response
    
    async def options(self, request, *args, **kwargs):
        """OPTIONS请求处理"""
        from kewe.response import Response
        response = Response()
        response.status = 200
        response.headers['allow'] = ', '.join(self._get_allowed_methods())
        return response


class View:
    """
    通用视图基类
    提供基本的请求处理流程
    """
    
    methods: List[str] = ['GET']
    
    def __init__(self):
        self.request = None
    
    @classmethod
    def as_view(cls, name: str = None, **init_kwargs):
        """
        创建视图函数
        
        Args:
            name: 视图名称
            **init_kwargs: 初始化参数
            
        Returns:
            视图函数
        """
        name = name or cls.__name__
        
        async def view(request, *args, **kwargs):
            instance = cls(**init_kwargs)
            instance.request = request
            return await instance.dispatch(request, *args, **kwargs)
        
        view._is_view = True
        view._view_class = cls
        view.__name__ = name
        view.__doc__ = cls.__doc__
        view.__module__ = cls.__module__
        
        return view
    
    async def dispatch(self, request, *args, **kwargs):
        """
        请求分发
        子类应该重写此方法
        """
        raise NotImplementedError("Subclasses must implement dispatch()")


class ListView(View):
    """
    列表视图
    用于展示对象列表
    """
    
    model = None
    paginate_by: int = 50
    
    async def dispatch(self, request, *args, **kwargs):
        """处理列表请求"""
        object_list = await self.get_queryset()
        context = {
            'object_list': object_list,
            'view': self
        }
        return await self.render_to_response(context)
    
    async def get_queryset(self):
        """获取查询集"""
        raise NotImplementedError("Subclasses must implement get_queryset()")
    
    async def render_to_response(self, context: Dict[str, Any]):
        """渲染响应"""
        from kewe.response import json
        return json(context)


class DetailView(View):
    """
    详情视图
    用于展示单个对象
    """
    
    model = None
    pk_url_kwarg: str = 'pk'
    
    async def dispatch(self, request, *args, **kwargs):
        """处理详情请求"""
        obj = await self.get_object(**kwargs)
        context = {
            'object': obj,
            'view': self
        }
        return await self.render_to_response(context)
    
    async def get_object(self, **kwargs):
        """获取对象"""
        raise NotImplementedError("Subclasses must implement get_object()")
    
    async def render_to_response(self, context: Dict[str, Any]):
        """渲染响应"""
        from kewe.response import json
        return json(context)


class CreateView(View):
    """
    创建视图
    用于创建新对象
    """
    
    methods = ['GET', 'POST']
    model = None
    
    async def dispatch(self, request, *args, **kwargs):
        """处理创建请求"""
        if request.method == 'GET':
            return await self.get(request, *args, **kwargs)
        elif request.method == 'POST':
            return await self.post(request, *args, **kwargs)
    
    async def get(self, request, *args, **kwargs):
        """显示创建表单"""
        form = await self.get_form()
        return await self.render_to_response({'form': form})
    
    async def post(self, request, *args, **kwargs):
        """处理创建提交"""
        form = await self.get_form()
        if await self.form_valid(form):
            return await self.form_valid_response(form)
        return await self.form_invalid_response(form)
    
    async def get_form(self):
        """获取表单"""
        return {}
    
    async def form_valid(self, form) -> bool:
        """验证表单"""
        return True
    
    async def form_valid_response(self, form):
        """表单验证成功的响应"""
        from kewe.response import json
        return json({'success': True})
    
    async def form_invalid_response(self, form):
        """表单验证失败的响应"""
        from kewe.response import json
        return json({'success': False, 'errors': {}}, status=400)
    
    async def render_to_response(self, context: Dict[str, Any]):
        """渲染响应"""
        from kewe.response import json
        return json(context)


class UpdateView(View):
    """
    更新视图
    用于更新对象
    """
    
    methods = ['GET', 'PUT', 'PATCH']
    model = None
    pk_url_kwarg: str = 'pk'
    
    async def dispatch(self, request, *args, **kwargs):
        """处理更新请求"""
        self.object = await self.get_object(**kwargs)
        
        if request.method == 'GET':
            return await self.get(request, *args, **kwargs)
        elif request.method in ['PUT', 'PATCH']:
            return await self.put(request, *args, **kwargs)
    
    async def get(self, request, *args, **kwargs):
        """显示更新表单"""
        form = await self.get_form(instance=self.object)
        return await self.render_to_response({'form': form, 'object': self.object})
    
    async def put(self, request, *args, **kwargs):
        """处理更新提交"""
        form = await self.get_form(instance=self.object)
        if await self.form_valid(form):
            return await self.form_valid_response(form)
        return await self.form_invalid_response(form)
    
    async def get_object(self, **kwargs):
        """获取对象"""
        raise NotImplementedError("Subclasses must implement get_object()")
    
    async def get_form(self, instance=None):
        """获取表单"""
        return {}
    
    async def form_valid(self, form) -> bool:
        """验证表单"""
        return True
    
    async def form_valid_response(self, form):
        """表单验证成功的响应"""
        from kewe.response import json
        return json({'success': True})
    
    async def form_invalid_response(self, form):
        """表单验证失败的响应"""
        from kewe.response import json
        return json({'success': False, 'errors': {}}, status=400)
    
    async def render_to_response(self, context: Dict[str, Any]):
        """渲染响应"""
        from kewe.response import json
        return json(context)


class DeleteView(View):
    """
    删除视图
    用于删除对象
    """
    
    methods = ['GET', 'DELETE']
    model = None
    pk_url_kwarg: str = 'pk'
    
    async def dispatch(self, request, *args, **kwargs):
        """处理删除请求"""
        self.object = await self.get_object(**kwargs)
        
        if request.method == 'GET':
            return await self.get(request, *args, **kwargs)
        elif request.method == 'DELETE':
            return await self.delete(request, *args, **kwargs)
    
    async def get(self, request, *args, **kwargs):
        """显示确认删除页面"""
        return await self.render_to_response({'object': self.object})
    
    async def delete(self, request, *args, **kwargs):
        """处理删除"""
        await self.perform_delete()
        return await self.delete_success_response()
    
    async def get_object(self, **kwargs):
        """获取对象"""
        raise NotImplementedError("Subclasses must implement get_object()")
    
    async def perform_delete(self):
        """执行删除操作"""
        raise NotImplementedError("Subclasses must implement perform_delete()")
    
    async def delete_success_response(self):
        """删除成功的响应"""
        from kewe.response import json
        return json({'deleted': True})
    
    async def render_to_response(self, context: Dict[str, Any]):
        """渲染响应"""
        from kewe.response import json
        return json(context)


def method_decorator(decorator: Callable, name: str = None):
    """
    方法装饰器
    用于将装饰器应用到类视图的特定方法
    
    使用示例:
        @method_decorator(login_required, name='get')
        class MyView(HTTPMethodView):
            pass
    """
    def _decorator(cls):
        if name is None:
            # 应用到所有方法
            for method_name in ['get', 'post', 'put', 'delete', 'patch', 'head', 'options']:
                if hasattr(cls, method_name):
                    method = getattr(cls, method_name)
                    setattr(cls, method_name, decorator(method))
        else:
            # 应用到指定方法
            if hasattr(cls, name):
                method = getattr(cls, name)
                setattr(cls, name, decorator(method))
        return cls
    return _decorator
