#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.routing.converter - Route parameter type conversion with registry
"""

import re
import uuid as _uuid
from typing import Any, Callable, Dict, Optional, Type, Union, List, Tuple
from datetime import datetime

from kewe.errors.exceptions import KeweException


class ValidationError(KeweException, ValueError):
    """参数验证错误"""
    def __init__(self, message: str = "Validation error"):
        KeweException.__init__(self, message=message, status_code=422, error_code="VALIDATION_ERROR")
        ValueError.__init__(self, message)


class ParameterValidator:
    """参数验证器"""
    
    def __init__(
        self,
        min_value: Optional[Union[int, float]] = None,
        max_value: Optional[Union[int, float]] = None,
        min_length: Optional[int] = None,
        max_length: Optional[int] = None,
        pattern: Optional[str] = None,
        choices: Optional[List[Any]] = None,
        custom_validator: Optional[Callable[[Any], bool]] = None
    ):
        """
        初始化参数验证器
        
        Args:
            min_value: 最小值（用于数值类型）
            max_value: 最大值（用于数值类型）
            min_length: 最小长度（用于字符串类型）
            max_length: 最大长度（用于字符串类型）
            pattern: 正则表达式模式（用于字符串类型）
            choices: 允许的值列表
            custom_validator: 自定义验证函数
        """
        self.min_value = min_value
        self.max_value = max_value
        self.min_length = min_length
        self.max_length = max_length
        self.pattern = re.compile(pattern) if pattern else None
        self.choices = choices
        self.custom_validator = custom_validator
    
    def validate(self, value: Any, param_name: str) -> Any:
        """
        验证参数值
        
        Args:
            value: 参数值
            param_name: 参数名称
            
        Returns:
            验证后的值
            
        Raises:
            ValidationError: 验证失败
        """
        if isinstance(value, (int, float)):
            if self.min_value is not None and value < self.min_value:
                raise ValidationError(
                    f"Parameter '{param_name}' value {value} is less than minimum {self.min_value}"
                )
            if self.max_value is not None and value > self.max_value:
                raise ValidationError(
                    f"Parameter '{param_name}' value {value} is greater than maximum {self.max_value}"
                )
        
        if isinstance(value, str):
            if self.min_length is not None and len(value) < self.min_length:
                raise ValidationError(
                    f"Parameter '{param_name}' length {len(value)} is less than minimum {self.min_length}"
                )
            if self.max_length is not None and len(value) > self.max_length:
                raise ValidationError(
                    f"Parameter '{param_name}' length {len(value)} is greater than maximum {self.max_length}"
                )
            
            if self.pattern and not self.pattern.match(value):
                raise ValidationError(
                    f"Parameter '{param_name}' value '{value}' does not match pattern {self.pattern.pattern}"
                )
        
        if self.choices is not None and value not in self.choices:
            raise ValidationError(
                f"Parameter '{param_name}' value '{value}' is not in allowed choices {self.choices}"
            )
        
        if self.custom_validator is not None:
            if not self.custom_validator(value):
                raise ValidationError(
                    f"Parameter '{param_name}' value '{value}' failed custom validation"
                )
        
        return value


class ParameterConverter:
    """参数转换器基类"""
    
    def __init__(
        self,
        name: str,
        regex: str,
        converter: Callable[[str], Any],
        validator: Optional[ParameterValidator] = None
    ):
        self.name = name
        self.regex = regex
        self.converter = converter
        self.validator = validator
    
    def convert(self, value: str, param_name: str = None) -> Any:
        """
        转换参数值
        
        Args:
            value: 参数值
            param_name: 参数名称（用于错误消息）
            
        Returns:
            转换后的值
            
        Raises:
            ValueError: 转换失败
            ValidationError: 验证失败
        """
        try:
            if self.regex and not re.fullmatch(self.regex, value):
                raise ValueError(
                    f"Value '{value}' does not match pattern '{self.regex}' for {self.name}"
                )
            converted_value = self.converter(value)
        except (ValueError, ValidationError):
            raise
        except Exception as e:
            raise ValueError(f"Cannot convert '{value}' to {self.name}: {e}") from e
        
        if self.validator:
            self.validator.validate(converted_value, param_name or "parameter")
        
        return converted_value


class InlineRegexConverter(ParameterConverter):
    """内联正则转换器 - 支持自定义正则表达式"""
    
    def __init__(self, name: str, regex: str, converter: Callable[[str], Any] = None):
        super().__init__(name, regex, converter or (lambda x: x))
        self._original_regex = regex


class EnumConverter(ParameterConverter):
    """枚举转换器 - 支持值枚举约束"""
    
    def __init__(self, name: str, choices: List[str], case_sensitive: bool = False):
        self.choices = choices
        self.case_sensitive = case_sensitive
        if case_sensitive:
            regex = "|".join(re.escape(c) for c in choices)
        else:
            regex = "(?i:" + "|".join(re.escape(c) for c in choices) + ")"
        super().__init__(name, regex, self._convert)
    
    def _convert(self, value: str) -> str:
        if not self.case_sensitive:
            for choice in self.choices:
                if value.lower() == choice.lower():
                    return choice
            raise ValueError(f"Value '{value}' not in choices {self.choices}")
        if value not in self.choices:
            raise ValueError(f"Value '{value}' not in choices {self.choices}")
        return value


class ConverterRegistry:
    """转换器注册表"""
    
    def __init__(self):
        self._converters: Dict[str, ParameterConverter] = {}
        self._register_default_converters()
    
    def _register_default_converters(self):
        """注册默认转换器"""
        self.register("str", ParameterConverter(
            "str",
            r"[^/]+",
            lambda x: x
        ))
        
        self.register("int", ParameterConverter(
            "int",
            r"-?\d+",
            int
        ))
        
        self.register("float", ParameterConverter(
            "float",
            r"-?\d+(\.\d+)?",
            float
        ))
        
        self.register("path", ParameterConverter(
            "path",
            r".+",
            lambda x: x
        ))
        
        self.register("uuid", ParameterConverter(
            "uuid",
            r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}",
            _uuid.UUID
        ))
        
        self.register("date", ParameterConverter(
            "date",
            r"\d{4}-\d{2}-\d{2}",
            lambda x: datetime.strptime(x, "%Y-%m-%d").date()
        ))
        
        self.register("datetime", ParameterConverter(
            "datetime",
            r"\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}",
            lambda x: datetime.fromisoformat(x.replace(" ", "T"))
        ))
        
        self.register("bool", ParameterConverter(
            "bool",
            r"(?:true|false|1|0|yes|no)",
            lambda x: x.lower() in ("true", "1", "yes")
        ))
        
        self.register("email", ParameterConverter(
            "email",
            r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}",
            lambda x: x
        ))
        
        self.register("slug", ParameterConverter(
            "slug",
            r"[a-z0-9-]+",
            lambda x: x
        ))
        
        self.register("alpha", ParameterConverter(
            "alpha",
            r"[a-zA-Z]+",
            lambda x: x
        ))
        
        self.register("alphanum", ParameterConverter(
            "alphanum",
            r"[a-zA-Z0-9]+",
            lambda x: x
        ))
        
        self.register("hex", ParameterConverter(
            "hex",
            r"[0-9a-fA-F]+",
            lambda x: int(x, 16)
        ))
        
        self.register("oct", ParameterConverter(
            "oct",
            r"[0-7]+",
            lambda x: int(x, 8)
        ))
        
        self.register("binary", ParameterConverter(
            "binary",
            r"[01]+",
            lambda x: int(x, 2)
        ))
        
        self.register("year", ParameterConverter(
            "year",
            r"\d{4}",
            int
        ))
        
        self.register("month", ParameterConverter(
            "month",
            r"(?:0?[1-9]|1[0-2])",
            int
        ))
        
        self.register("day", ParameterConverter(
            "day",
            r"(?:0?[1-9]|[12]\d|3[01])",
            int
        ))
        
        self.register("word", ParameterConverter(
            "word",
            r"\w+",
            lambda x: x
        ))
        
        self.register("ext", ParameterConverter(
            "ext",
            r"[a-zA-Z0-9]+",
            lambda x: x.lower()
        ))
    
    def register(self, name: str, converter: ParameterConverter):
        """注册转换器"""
        self._converters[name] = converter
    
    def get(self, name: str) -> Optional[ParameterConverter]:
        """获取转换器"""
        return self._converters.get(name)
    
    def has(self, name: str) -> bool:
        """检查转换器是否存在"""
        return name in self._converters


_converter_registry = ConverterRegistry()


class TypeConverter:
    """路径参数类型转换器 — 便捷封装

    用法:
        tc = TypeConverter()
        tc.convert('123', 'int')   -> 123
        tc.convert('hello', 'str') -> 'hello'
        tc.convert('true', 'bool') -> True
    """

    def __init__(self, registry: Optional[ConverterRegistry] = None):
        self._registry = registry or _converter_registry

    def convert(self, value: str, type_name: str, param_name: str = None) -> Any:
        converter = self._registry.get(type_name)
        if converter:
            return converter.convert(value, param_name)
        return value

    def register(self, name: str, regex: str, converter: Callable[[str], Any]):
        self._registry.register(name, ParameterConverter(name, regex, converter))

    def has(self, name: str) -> bool:
        return self._registry.has(name)


def get_converter_registry() -> ConverterRegistry:
    """获取转换器注册表"""
    return _converter_registry


def register_converter(name: str, regex: str, converter: Callable[[str], Any]):
    """
    注册自定义转换器
    
    使用示例:
        register_converter("hex", r"[0-9a-fA-F]+", lambda x: int(x, 16))
        
        @app.get("/color/<code:hex>")
        async def get_color(request, code: int):
            return {"color": code}
    """
    _converter_registry.register(name, ParameterConverter(name, regex, converter))


def convert_parameter(value: str, converter_name: str, param_name: str = None) -> Any:
    """
    转换参数值
    
    Args:
        value: 参数值
        converter_name: 转换器名称
        param_name: 参数名称（用于错误消息）
        
    Returns:
        转换后的值
        
    Raises:
        ValueError: 转换失败
        ValidationError: 验证失败
    """
    converter = _converter_registry.get(converter_name)
    if converter:
        return converter.convert(value, param_name)
    return value


_BRACE_PARAM_RE = re.compile(r'\{(\w+)(?::([^}]+))?\}')


def _normalize_path_params(path: str) -> str:
    """将  {param} 路径参数转换为 Kewe 的 <param> 格式"""
    def _replace_brace_param(match):
        name = match.group(1)
        converter = match.group(2)
        if converter:
            return f'<{name}:{converter}>'
        return f'<{name}>'
    return _BRACE_PARAM_RE.sub(_replace_brace_param, path)


def parse_path_pattern(path: str) -> Tuple[str, List[str], Dict[str, str]]:
    """
    解析路径模式，提取参数和转换器
    
    返回: (regex_pattern, param_names, param_converters)
    
    支持的格式:
        - <id:int>          - 内置转换器
        - <version:v1|v2>   - 枚举值约束（匹配 v1 或 v2）
        - <id:[0-9a-f]{8}>  - 自定义正则表达式
        - <name>            - 默认字符串类型
        - {name}            - 花括号风格（自动转换为 <name>）
        - {name:type}       - 花括号风格带类型（自动转换为 <name:type>）
    
    示例:
        "/users/<id:int>" -> ("^/users/(?P<id>\\d+)$", ["id"], {"id": "int"})
        "/api/<version:v1|v2>" -> ("^/api/(?P<version>v1|v2)$", ["version"], {"version": "enum:v1,v2"})
        "/items/{item_id}" -> 同 "/items/<item_id>"
    """
    path = _normalize_path_params(path)
    
    param_names = []
    param_converters: Dict[str, str] = {}
    param_inline_converters: Dict[str, ParameterConverter] = {}
    
    parts = []
    i = 0
    original_path = path
    
    while i < len(path):
        if path[i] == '<':
            end = path.find('>', i)
            if end != -1:
                if i > 0:
                    parts.append(re.escape(path[:i]))
                
                param_def = path[i+1:end]
                param_name, converter_def = _parse_param_definition(param_def)
                
                param_names.append(param_name)
                
                regex, converter_name = _resolve_converter(param_name, converter_def)
                param_converters[param_name] = converter_name
                
                parts.append(f"(?P<{param_name}>{regex})")
                path = path[end+1:]
                i = 0
            else:
                i += 1
        else:
            i += 1
    
    if path:
        parts.append(re.escape(path))
    
    regex_pattern = "".join(parts)
    
    if not regex_pattern.startswith("^"):
        regex_pattern = "^" + regex_pattern
    if not regex_pattern.endswith("$"):
        regex_pattern = regex_pattern + "$"
    
    return regex_pattern, param_names, param_converters


def _parse_param_definition(param_def: str) -> Tuple[str, str]:
    """
    解析参数定义
    
    Args:
        param_def: 参数定义字符串，如 "id:int" 或 "version:v1|v2"
    
    Returns:
        (param_name, converter_def)
    """
    if ":" in param_def:
        param_name, converter_def = param_def.split(":", 1)
        return param_name.strip(), converter_def.strip()
    return param_def.strip(), "str"


def _resolve_converter(param_name: str, converter_def: str) -> Tuple[str, str]:
    """
    解析转换器定义，返回正则表达式和转换器名称
    
    Args:
        param_name: 参数名称
        converter_def: 转换器定义，可以是:
            - 内置转换器名称: "int", "str", "uuid" 等
            - 枚举值: "v1|v2|v3"
            - 自定义正则: "[0-9a-f]{8}" 或 "(foo|bar)"
    
    Returns:
        (regex_pattern, converter_name)
    """
    if converter_def == "str":
        return r"[^/]+", "str"
    
    converter = _converter_registry.get(converter_def)
    if converter:
        return converter.regex, converter_def
    
    if "|" in converter_def and not converter_def.startswith("(") and not converter_def.startswith("["):
        choices = [c.strip() for c in converter_def.split("|")]
        if all(_is_simple_identifier(c) for c in choices):
            regex = "|".join(re.escape(c) for c in choices)
            enum_converter = EnumConverter(f"_enum_{param_name}", choices)
            _converter_registry.register(f"_enum_{param_name}", enum_converter)
            return f"(?:{regex})", f"_enum_{param_name}"
    
    if converter_def.startswith("[") or converter_def.startswith("("):
        try:
            re.compile(converter_def)
            if _check_redos_risk(converter_def):
                raise ValueError(f"Regex pattern '{converter_def}' may cause ReDoS, use simpler patterns or built-in converters")
            inline_converter = InlineRegexConverter(f"_inline_{param_name}", converter_def)
            _converter_registry.register(f"_inline_{param_name}", inline_converter)
            return converter_def, f"_inline_{param_name}"
        except (re.error, ValueError):
            pass
    
    if _looks_like_regex(converter_def):
        try:
            re.compile(converter_def)
            if _check_redos_risk(converter_def):
                raise ValueError(f"Regex pattern '{converter_def}' may cause ReDoS, use simpler patterns or built-in converters")
            inline_converter = InlineRegexConverter(f"_inline_{param_name}", converter_def)
            _converter_registry.register(f"_inline_{param_name}", inline_converter)
            return converter_def, f"_inline_{param_name}"
        except (re.error, ValueError):
            pass
    
    return r"[^/]+", "str"


_DANGEROUS_REDOS_PATTERNS = [
    re.compile(r'\([^)]*[+*][+*]'),
    re.compile(r'\([^)]*\)[+*]\s*\{'),
    re.compile(r'(?:\+|\*)\s*\{.*,\s*\d{2,}'),
    re.compile(r'\([^)]*[+*]\)[+*]'),
    re.compile(r'\([^)]*\|[^)]*\)[+*]'),
    re.compile(r'\([^)]*\)[+*]\([^)]*[+*]\)'),
]


def _check_redos_risk(regex_str: str) -> bool:
    for pattern in _DANGEROUS_REDOS_PATTERNS:
        if pattern.search(regex_str):
            return True
    return False


def _is_simple_identifier(s: str) -> bool:
    """检查字符串是否是简单标识符（用于枚举值检测）"""
    if not s:
        return False
    first_char = s[0]
    if not (first_char.isalpha() or first_char == '_'):
        return False
    return all(c.isalnum() or c in '_-' for c in s)


def _looks_like_regex(s: str) -> bool:
    """检查字符串是否看起来像正则表达式"""
    regex_chars = {'[', ']', '(', ')', '{', '}', '*', '+', '?', '|', '^', '$', '\\', '.'}
    return any(c in regex_chars for c in s)




