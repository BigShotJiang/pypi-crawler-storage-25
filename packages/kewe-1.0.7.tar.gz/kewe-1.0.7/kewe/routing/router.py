#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.routing.router - HTTP route matching and registration
"""

import re
import time
import logging
import threading
from typing import Dict, List, Callable, Optional, Any, Tuple, Union
from dataclasses import dataclass, field
from collections import OrderedDict

from kewe.routing.converter import parse_path_pattern, convert_parameter, ValidationError, ConverterRegistry

logger = logging.getLogger(__name__)


def join_path(prefix: str, path: str) -> str:
    """连接路径前缀和路径"""
    if not prefix:
        return path
    if not path:
        return prefix
    return f"{prefix}/{path.lstrip('/')}"


@dataclass(slots=True)
class Route:
    """路由定义"""
    path: str
    methods: List[str]
    handler: Callable
    params: Dict[str, str] = None
    regex_pattern: re.Pattern = None
    strict_slashes: bool = False
    middlewares: List[Callable] = None
    name: Optional[str] = None
    namespace: Optional[str] = None
    host: Optional[str] = None
    schemes: Optional[List[str]] = None
    tags: Optional[List[str]] = None
    summary: Optional[str] = None
    description: Optional[str] = None
    deprecated: bool = False
    response_model: Optional[Any] = None
    status_code: Optional[int] = None
    _url_template: Optional[str] = field(default=None, init=False, repr=False)
    
    def __post_init__(self):
        if self.middlewares is None:
            self.middlewares = []
        if self.name is None:
            self.name = self.handler.__name__
        if self.schemes is None:
            self.schemes = []
        if self.tags is None:
            self.tags = []
        if self.summary is None and self.handler.__doc__:
            self.summary = self.handler.__doc__.strip().split('\n')[0]


from kewe.routing.blueprints import Blueprint
from kewe.routing.blueprint_group import BlueprintGroup


class TrieNode:
    """字典树节点"""
    def __init__(self):
        self.children: Dict[str, "TrieNode"] = {}
        self.routes: List[Route] = []
        self.param_node: Optional["TrieNode"] = None  # 路径参数节点
        self.param_name: Optional[str] = None
        self.param_type: Optional[str] = None
        self.wildcard_node: Optional["TrieNode"] = None
        self.wildcard_name: Optional[str] = None
        self.wildcard_type: Optional[str] = None


class Router:
    """URL路由器 - 支持参数类型转换和高效匹配
    路由实现，优化路由匹配性能
    支持智能缓存策略和命中率统计
    """
    
    def __init__(self, strict_slashes: bool = False, cache_size: int = 10000, cache_ttl: float = 300.0):
        self._strict_slashes = strict_slashes
        self._root = TrieNode()
        self._route_map: Dict[str, Route] = {}
        self._name_map: Dict[str, Route] = {}
        self._cache: OrderedDict[str, tuple] = OrderedDict()
        self._cache_size = cache_size
        self._cache_ttl = cache_ttl
        self._host_map: Dict[str, List[Route]] = {}
        self._route_lock = threading.Lock()
        self._converter_registry = ConverterRegistry()
        
        self._cache_hits = 0
        self._cache_misses = 0
        self._cache_evictions = 0
        self._access_counts: Dict[str, int] = {}
    
    @property
    def cache_stats(self) -> Dict[str, Any]:
        """获取缓存统计信息"""
        total = self._cache_hits + self._cache_misses
        hit_rate = self._cache_hits / total if total > 0 else 0
        return {
            "hits": self._cache_hits,
            "misses": self._cache_misses,
            "evictions": self._cache_evictions,
            "hit_rate": hit_rate,
            "size": len(self._cache),
            "max_size": self._cache_size
        }
    
    def clear_cache(self):
        """清除缓存"""
        self._cache.clear()
        self._access_counts.clear()
        self._cache_hits = 0
        self._cache_misses = 0
        self._cache_evictions = 0

    def _unique_route_name(self, base_name: str, path: str) -> str:
        """为路由生成唯一名称，防止循环中handler名称冲突"""
        if base_name not in self._name_map:
            return base_name
        suffix = 2
        while f"{base_name}_{suffix}" in self._name_map:
            suffix += 1
        return f"{base_name}_{suffix}"

    def optimize_cache(self):
        """优化缓存 - 移除低频访问的条目"""
        if len(self._cache) < self._cache_size // 2:
            return
        
        avg_access = sum(self._access_counts.values()) / len(self._access_counts) if self._access_counts else 0
        
        keys_to_remove = [
            key for key, count in self._access_counts.items()
            if count < avg_access / 2
        ]
        
        for key in keys_to_remove:
            if key in self._cache:
                del self._cache[key]
                del self._access_counts[key]
                self._cache_evictions += 1
    
    def route(self, path: str, methods: Optional[List[str]] = None, **kwargs):
        def decorator(handler: Callable):
            self.add_route(path, methods or ["GET"], handler, **kwargs)
            return handler
        return decorator

    def get(self, path: str, **kwargs):
        return self.route(path, methods=["GET"], **kwargs)

    def post(self, path: str, **kwargs):
        return self.route(path, methods=["POST"], **kwargs)

    def put(self, path: str, **kwargs):
        return self.route(path, methods=["PUT"], **kwargs)

    def delete(self, path: str, **kwargs):
        return self.route(path, methods=["DELETE"], **kwargs)

    def patch(self, path: str, **kwargs):
        return self.route(path, methods=["PATCH"], **kwargs)

    def head(self, path: str, **kwargs):
        return self.route(path, methods=["HEAD"], **kwargs)

    def options(self, path: str, **kwargs):
        return self.route(path, methods=["OPTIONS"], **kwargs)

    def websocket(self, path: str, **kwargs):
        def decorator(handler: Callable):
            self.add_websocket_route(path, handler, **kwargs)
            return handler
        return decorator
    
    def add_route(
        self,
        path: str,
        methods: List[str],
        handler: Callable,
        strict_slashes: bool = None,
        middlewares: List[Callable] = None,
        name: Optional[str] = None,
        host: Optional[str] = None,
        schemes: Optional[List[str]] = None,
        tags: Optional[List[str]] = None,
        summary: Optional[str] = None,
        description: Optional[str] = None,
        deprecated: bool = False,
        response_model: Optional[Any] = None,
        status_code: Optional[int] = None,
        **kwargs
    ):
        """
        添加路由
        
        Args:
            path: 路由路径
            methods: HTTP方法列表
            handler: 处理函数
            strict_slashes: 是否严格匹配斜杠
            middlewares: 路由特定中间件列表
            name: 路由名称
            host: 主机匹配
            schemes: 协议匹配
            **kwargs: 其他参数
        """
        # 解析路径模式
        regex_str, param_names, param_converters = parse_path_pattern(path)
        
        try:
            regex_pattern = re.compile(regex_str)
        except re.error as e:
            logger.error(f"Invalid regex pattern for path '{path}': {e}")
            raise
        
        route = Route(
            path=path,
            methods=[m.upper() for m in methods],
            handler=handler,
            params=param_converters,
            regex_pattern=regex_pattern,
            strict_slashes=strict_slashes if strict_slashes is not None else self._strict_slashes,
            middlewares=middlewares or [],
            name=name or self._unique_route_name(handler.__name__, path),
            host=host,
            schemes=schemes,
            tags=tags,
            summary=summary,
            description=description,
            deprecated=deprecated,
            response_model=response_model,
            status_code=status_code,
        )

        with self._route_lock:
            self._check_route_conflict(route)

            self._add_to_trie(path, route)
        
            route_key = f"{route.name}:{path}"
            self._route_map[route_key] = route
        
            if route.name:
                if route.name in self._name_map:
                    existing = self._name_map[route.name]
                    if existing.path != route.path:
                        existing_methods = set(existing.methods)
                        new_methods = set(route.methods)
                        if existing_methods == new_methods:
                            import warnings
                            warnings.warn(
                                f"Route name '{route.name}' is already registered for "
                                f"{list(existing_methods)} {existing.path}, overriding with "
                                f"{list(new_methods)} {route.path}",
                                UserWarning, stacklevel=4,
                            )
                self._name_map[route.name] = route
        
            if host:
                if host not in self._host_map:
                    self._host_map[host] = []
                self._host_map[host].append(route)
        
            logger.debug(f"Registered route: {methods} {path} -> {handler.__name__}")
        
            if 'GET' in route.methods and 'HEAD' not in route.methods:
                head_name = f"{route.name}_head" if route.name else None
                head_route = Route(
                    path=path,
                    methods=['HEAD'],
                    handler=handler,
                    params=param_converters,
                    regex_pattern=regex_pattern,
                    strict_slashes=strict_slashes if strict_slashes is not None else self._strict_slashes,
                    middlewares=middlewares or [],
                    name=head_name,
                    host=host,
                    schemes=schemes,
                    tags=tags,
                    summary=summary,
                    description=description,
                    deprecated=deprecated,
                )
                self._add_to_trie(path, head_route)
                if head_route.name:
                    head_key = f"{head_route.name}:{path}"
                    self._route_map[head_key] = head_route
                    self._name_map[head_route.name] = head_route
                if host:
                    if host not in self._host_map:
                        self._host_map[host] = []
                    self._host_map[host].append(head_route)
                logger.debug(f"Auto-registered HEAD route for GET: HEAD {path}")
        
        if hasattr(self, '_method_route_index'):
            del self._method_route_index
        
        self.clear_cache()
        
        if hasattr(self, '_route_hooks'):
            openapi_kwargs = dict(kwargs)
            if tags:
                openapi_kwargs['tags'] = tags
            if summary:
                openapi_kwargs['summary'] = summary
            if description:
                openapi_kwargs['description'] = description
            if deprecated:
                openapi_kwargs['deprecated'] = deprecated
            if response_model is not None:
                openapi_kwargs['response_model'] = response_model
            if status_code is not None:
                openapi_kwargs['status_code'] = status_code
            for hook in self._route_hooks:
                try:
                    hook(path, methods, handler, **openapi_kwargs)
                except Exception as e:
                    logger.warning(f"Route hook error: {e}")
        return self

    def add(self, path: str, methods: Optional[List[str]] = None, handler: Optional[Callable] = None, **kwargs):
        """添加路由（便捷方法，参数顺序与 add_route 一致：path, methods, handler）

        Note:
            为保持向后兼容，如果第二个位置参数是 Callable，
            将自动识别为 handler（旧调用方式: add(path, handler, methods)）
        """
        if handler is None and methods is not None and callable(methods):
            handler = methods
            methods = None
        if handler is None:
            raise TypeError("add() missing required argument: 'handler'")
        return self.add_route(path=path, methods=methods or ["GET"], handler=handler, **kwargs)

    def add_route_hook(self, hook: Callable):
        """添加路由注册钩子 - 用于 OpenAPI 等插件收集路由信息"""
        if not hasattr(self, '_route_hooks'):
            self._route_hooks = []
        self._route_hooks.append(hook)
    
    def add_api_route(
        self,
        path: str,
        endpoint: Callable,
        *,
        methods: Optional[List[str]] = None,
        name: Optional[str] = None,
        tags: Optional[List[str]] = None,
        summary: Optional[str] = None,
        description: Optional[str] = None,
        deprecated: bool = False,
        response_model: Optional[Any] = None,
        status_code: Optional[int] = None,
        **kwargs
    ) -> None:
        """程序化路由注册（非装饰器风格）"""
        self.add_route(
            path=path,
            methods=methods or ["GET"],
            handler=endpoint,
            name=name or endpoint.__name__,
            tags=tags,
            summary=summary,
            description=description,
            deprecated=deprecated,
            response_model=response_model,
            status_code=status_code,
            **kwargs
        )
    
    def include_router(self, router, *, prefix: str = "", tags: Optional[List[str]] = None, dependencies: Optional[List[Callable]] = None) -> None:
        """嵌套路由器/蓝图"""
        from kewe.routing.blueprints import Blueprint
        if isinstance(router, Blueprint):
            if tags:
                if not hasattr(router, '_route_tags'):
                    router._route_tags = tags
            if dependencies:
                if not hasattr(router, '_route_dependencies'):
                    router._route_dependencies = []
                router._route_dependencies.extend(dependencies)
            router.register(self, url_prefix=prefix or None)
        elif hasattr(router, '_routes'):
            for route in router._routes:
                handler = route.handler
                route_path = prefix + route.path
                self.add_route(
                    path=route_path,
                    methods=route.methods,
                    handler=handler,
                    name=route.name,
                )
        else:
            raise TypeError(f"Cannot include router of type {type(router)}")
    
    def add_websocket_route(self, path: str, handler: Callable, name: Optional[str] = None, **kwargs):
        if not hasattr(self, '_websocket_routes'):
            self._websocket_routes = {}
        
        regex_str, param_names, param_converters = parse_path_pattern(path)
        try:
            regex_pattern = re.compile(regex_str)
        except re.error as e:
            logger.error(f"Invalid regex pattern for websocket path '{path}': {e}")
            raise
        
        route_name = name or handler.__name__
        ws_route = {
            'handler': handler,
            'path': path,
            'regex_pattern': regex_pattern,
            'params': param_converters,
            'name': route_name,
            'is_websocket': True,
        }
        
        self._websocket_routes[path] = ws_route
        self._name_map[route_name] = ws_route
        
        logger.debug(f"Registered WebSocket route: {path} -> {handler.__name__}")
    
    def _check_route_conflict(self, new_route: 'Route'):
        to_remove = []
        for key, existing in self._route_map.items():
            if existing.path == new_route.path:
                overlap = set(existing.methods) & set(new_route.methods)
                if overlap:
                    if existing.handler == new_route.handler:
                        continue
                    if existing.name and existing.name.startswith('gateway_'):
                        existing.methods = [m for m in existing.methods if m not in overlap]
                        if not existing.methods:
                            to_remove.append(key)
                    elif new_route.name and new_route.name.startswith('gateway_'):
                        existing.methods = [m for m in existing.methods if m not in overlap]
                        if not existing.methods:
                            to_remove.append(key)
                    else:
                        raise ValueError(
                            f"Route conflict: {list(overlap)} {new_route.path} "
                            f"is already registered by '{existing.name or existing.handler.__name__}'"
                        )
        for key in to_remove:
            del self._route_map[key]

    def _add_to_trie(self, path: str, route: Route):
        """添加路由到字典树"""
        parts = path.strip("/").split("/") if path != "/" else []
        node = self._root
        
        for part in parts:
            if part == "*":
                # 处理通配符
                if not node.wildcard_node:
                    node.wildcard_node = TrieNode()
                node.wildcard_node.wildcard_name = '*'
                node = node.wildcard_node
            elif part.startswith("<") and part.endswith(">"):
                param_info = part[1:-1]
                if param_info.startswith("*"):
                    wildcard_info = param_info[1:]
                    if wildcard_info.startswith(":"):
                        wildcard_name = wildcard_info[1:]
                    else:
                        wildcard_name = wildcard_info if wildcard_info else '*'
                    if not node.wildcard_node:
                        node.wildcard_node = TrieNode()
                    node.wildcard_node.wildcard_name = wildcard_name
                    node = node.wildcard_node
                else:
                    param_info = part[1:-1]
                    if ":" in param_info:
                        param_name, param_type = param_info.split(":", 1)
                    else:
                        param_name, param_type = param_info, "str"
                    
                    if param_type == "path":
                        if not node.wildcard_node:
                            node.wildcard_node = TrieNode()
                        node.wildcard_node.wildcard_name = param_name
                        node.wildcard_node.wildcard_type = param_type
                        node = node.wildcard_node
                    else:
                        if not node.param_node:
                            node.param_node = TrieNode()
                            node.param_name = param_name
                            node.param_type = param_type
                        else:
                            if node.param_type != param_type:
                                raise ValueError(
                                    f"Route conflict: parameter type mismatch at same level. "
                                    f"Existing: <{node.param_name}:{node.param_type}>, "
                                    f"New: <{param_name}:{param_type}>"
                                )
                        node = node.param_node
            else:
                # 普通路径部分
                if part not in node.children:
                    node.children[part] = TrieNode()
                node = node.children[part]
        
        # 在叶子节点添加路由
        existing_idx = None
        for i, r in enumerate(node.routes):
            if r.path == route.path and set(r.methods) & set(route.methods):
                existing_idx = i
                break
        if existing_idx is not None:
            existing = node.routes[existing_idx]
            if existing.handler == route.handler:
                merged_methods = list(set(existing.methods) | set(route.methods))
                existing.methods = merged_methods
            else:
                node.routes[existing_idx] = route
        else:
            node.routes.append(route)
    
    def find_route(self, path: str, method: str, host: str = None, scheme: str = None) -> Optional[Dict[str, Any]]:
        method = method.upper()
        original_path = path
        
        if not self._strict_slashes:
            if path != "/" and path.endswith("/"):
                path = path[:-1]
        
        cache_key = f"{method}:{host or ''}:{scheme or ''}:{path}"
        
        cached = self._cache.get(cache_key)
        if cached is not None:
            entry, ts = cached
            if self._cache_ttl and (time.monotonic() - ts) > self._cache_ttl:
                del self._cache[cache_key]
                self._access_counts.pop(cache_key, None)
                self._cache_misses += 1
            else:
                self._cache.move_to_end(cache_key)
                self._cache_hits += 1
                self._access_counts[cache_key] = self._access_counts.get(cache_key, 0) + 1
                return entry
        
        self._cache_misses += 1
        
        if host and host in self._host_map:
            for route in self._host_map[host]:
                if method in route.methods:
                    match = route.regex_pattern.match(path)
                    if match:
                        raw_params = match.groupdict()
                        converted_params = {}
                        conversion_failed = False
                        for param_name, raw_value in raw_params.items():
                            converter_name = route.params.get(param_name, "str")
                            try:
                                converted_params[param_name] = convert_parameter(raw_value, converter_name, param_name)
                            except (ValueError, ValidationError) as e:
                                logger.warning(f"Parameter conversion failed for '{param_name}': {e}")
                                conversion_failed = True
                                break
                        
                        if conversion_failed:
                            continue
                        
                        result = {
                            "path": route.path,
                            "methods": list(route.methods),
                            "handler": route.handler,
                            "name": route.name,
                            "params": converted_params,
                            "middlewares": list(route.middlewares) if route.middlewares else []
                        }
                        
                        self._update_cache(cache_key, result)
                        return result
        
        parts = path.strip("/").split("/") if path != "/" else []
        node = self._root
        params = {}
        
        for i, part in enumerate(parts):
            if part in node.children:
                node = node.children[part]
            elif node.param_node:
                params[node.param_name] = part
                node = node.param_node
            elif node.wildcard_node:
                wildcard_name = getattr(node.wildcard_node, 'wildcard_name', '*')
                params[wildcard_name] = '/'.join(parts[i:])
                node = node.wildcard_node
                break
            else:
                result = self._find_route_regex(path, method, host, scheme)
                if result:
                    self._update_cache(cache_key, result)
                else:
                    self._update_cache(cache_key, None)
                return result
        
        allowed_methods = set()
        for route in node.routes:
            if method in route.methods:
                if route.host and route.host != host:
                    continue
                if route.schemes and scheme not in route.schemes:
                    continue
                
                if self._strict_slashes and route.strict_slashes:
                    request_has_slash = original_path.endswith('/') and original_path != '/'
                    route_has_slash = route.path.endswith('/') and route.path != '/'
                    if request_has_slash != route_has_slash:
                        alt_path = route.path
                        redirect_result = {
                            "path": route.path,
                            "methods": list(route.methods),
                            "handler": route.handler,
                            "name": route.name,
                            "params": {},
                            "middlewares": list(route.middlewares) if route.middlewares else [],
                            "redirect_to": alt_path,
                        }
                        self._update_cache(cache_key, redirect_result)
                        return redirect_result

                converted_params = {}
                conversion_failed = False
                for param_name, raw_value in params.items():
                    converter_name = route.params.get(param_name, "str")
                    try:
                        converted_params[param_name] = convert_parameter(raw_value, converter_name, param_name)
                    except (ValueError, ValidationError) as e:
                        logger.warning(f"Parameter conversion failed for '{param_name}': {e}")
                        conversion_failed = True
                        break

                if conversion_failed:
                    continue

                allowed_methods.update(route.methods)

                result = {
                    "path": route.path,
                    "methods": list(route.methods),
                    "handler": route.handler,
                    "name": route.name,
                    "params": converted_params,
                    "middlewares": list(route.middlewares) if route.middlewares else []
                }

                self._update_cache(cache_key, result)
                return result

        if allowed_methods:
            result = {
                "path": path,
                "methods": list(allowed_methods),
                "handler": None,
                "params": {},
                "middlewares": [],
                "method_not_allowed": True
            }
            self._update_cache(cache_key, result)
            return result
        
        result = self._find_route_regex(path, method, host, scheme)
        if result:
            self._update_cache(cache_key, result)
            return result
        
        if self._strict_slashes:
            alt_path = path.rstrip("/") if path.endswith("/") and path != "/" else (path + "/")
            alt_result = self._find_route_regex(alt_path, method, host, scheme)
            if alt_result:
                redirect_result = {
                    "path": alt_result["path"],
                    "methods": alt_result.get("methods", []),
                    "handler": alt_result.get("handler"),
                    "params": alt_result.get("params", {}),
                    "middlewares": alt_result.get("middlewares", []),
                    "redirect_to": alt_path,
                }
                self._update_cache(cache_key, redirect_result)
                return redirect_result
        
        self._update_cache(cache_key, None)
        return None
    
    def _update_cache(self, key: str, value: Dict[str, Any]):
        if len(self._cache) >= self._cache_size:
            oldest_key = next(iter(self._cache))
            del self._cache[oldest_key]
            if oldest_key in self._access_counts:
                del self._access_counts[oldest_key]
            self._cache_evictions += 1
        self._cache[key] = (value, time.monotonic())
        self._access_counts[key] = 1
    
    def _find_route_regex(self, path: str, method: str, host: str = None, scheme: str = None) -> Optional[Dict[str, Any]]:
        """使用正则表达式匹配路由（后备方案，使用方法索引优化）"""
        if not hasattr(self, '_method_route_index'):
            self._method_route_index: Dict[str, List] = {}
            for route in self._route_map.values():
                for m in route.methods:
                    self._method_route_index.setdefault(m, []).append(route)
        
        if host and host in self._host_map:
            for route in self._host_map[host]:
                if method not in route.methods:
                    continue
                
                match = route.regex_pattern.match(path)
                if match:
                    if route.schemes and scheme not in route.schemes:
                        continue
                    
                    raw_params = match.groupdict()
                    
                    converted_params = {}
                    conversion_failed = False
                    for param_name, raw_value in raw_params.items():
                        converter_name = route.params.get(param_name, "str")
                        try:
                            converted_params[param_name] = convert_parameter(raw_value, converter_name, param_name)
                        except (ValueError, TypeError) as e:
                            logger.warning(f"Parameter conversion failed: {e}")
                            conversion_failed = True
                            break

                    if conversion_failed:
                        continue

                    return {
                        "path": route.path,
                        "methods": list(route.methods),
                        "handler": route.handler,
                        "name": route.name,
                        "params": converted_params,
                        "middlewares": list(route.middlewares) if route.middlewares else []
                    }
        
        for route in self._method_route_index.get(method, []):
            if route.host and route.host != host:
                continue
            if route.schemes and scheme not in route.schemes:
                continue
            
            match = route.regex_pattern.match(path)
            if match:
                raw_params = match.groupdict()
                
                converted_params = {}
                conversion_failed = False
                for param_name, raw_value in raw_params.items():
                    converter_name = route.params.get(param_name, "str")
                    try:
                        converted_params[param_name] = convert_parameter(raw_value, converter_name, param_name)
                    except (ValueError, TypeError) as e:
                        logger.warning(f"Parameter conversion failed: {e}")
                        conversion_failed = True
                        break

                if conversion_failed:
                    continue

                return {
                    "path": route.path,
                    "methods": list(route.methods),
                    "handler": route.handler,
                    "name": route.name,
                    "params": converted_params,
                    "middlewares": list(route.middlewares) if route.middlewares else []
                }
        
        allowed_methods = set()
        for route in self._route_map.values():
            if route.host and route.host != host:
                continue
            if route.schemes and scheme not in route.schemes:
                continue
            match = route.regex_pattern.match(path)
            if match:
                raw_params = match.groupdict()
                conversion_ok = True
                for param_name, raw_value in raw_params.items():
                    converter_name = route.params.get(param_name, "str")
                    try:
                        convert_parameter(raw_value, converter_name, param_name)
                    except (ValueError, TypeError, ValidationError):
                        conversion_ok = False
                        break
                if conversion_ok:
                    allowed_methods.update(route.methods)
        
        if allowed_methods:
            return {
                "path": path,
                "methods": list(allowed_methods),
                "handler": None,
                "params": {},
                "middlewares": [],
                "method_not_allowed": True
            }
        
        return None
    
    def get_routes(self) -> List[Route]:
        """获取所有路由"""
        return list(self._route_map.values())

    @property
    def routes(self) -> List[Route]:
        """路由列表 - 属性"""
        return list(self._route_map.values())
    
    def get_allowed_methods(self, path: str, host: str = None) -> List[str]:
        """获取指定路径支持的所有HTTP方法"""
        if not self._strict_slashes:
            if path != "/" and path.endswith("/"):
                path = path[:-1]
        
        allowed = set()
        
        for route in self._route_map.values():
            if route.host and route.host != host:
                continue
            match = route.regex_pattern.match(path)
            if match:
                allowed.update(route.methods)
        
        return sorted(allowed)
    
    def url_for(
        self,
        handler_name: str,
        _external: bool = False,
        _scheme: str = None,
        _anchor: str = None,
        **kwargs
    ) -> Optional[str]:
        """
        反向解析URL - 使用预编译模板替代字符串替换

        使用示例:
            @app.get("/users/<id:int>")
            async def get_user(request):
                pass

            url = router.url_for("get_user", id=123)  # "/users/123"
            url = router.url_for("get_user", id=123, _external=True)  # "http://localhost:8000/users/123"

        支持命名空间:
            api = Blueprint("api", "/api", "api")
            api.get("/users/<id:int>", get_user, name="get_user")
            url = router.url_for("api.get_user", id=123)  # "/api/users/123"
        """
        route = self._name_map.get(handler_name)
        if not route:
            for r in self._route_map.values():
                if r.name == handler_name:
                    route = r
                    break
            if not route:
                candidates = []
                for r in self._route_map.values():
                    if r.name and r.name.endswith('.' + handler_name):
                        candidates.append(r)
                if len(candidates) == 1:
                    route = candidates[0]
                elif len(candidates) > 1:
                    names = [r.name for r in candidates]
                    raise ValueError(
                        f"Ambiguous endpoint '{handler_name}' matches multiple routes: {names}. "
                        f"Use the full qualified name (e.g. '{names[0]}') to disambiguate."
                    )
            if not route:
                return None

        if isinstance(route, dict):
            path = route.get('path', '/')
        else:
            path = route.path

        url_template = None
        if isinstance(route, dict):
            url_template = route.get('_url_template')
        else:
            url_template = getattr(route, '_url_template', None)
        if url_template is None:
            url_template = re.sub(r'<(\w+)(?::[^>]+)?>', r'{\1}', path)
            if isinstance(route, dict):
                route['_url_template'] = url_template
            else:
                route._url_template = url_template

        route_param_names = set(re.findall(r'<(\w+)(?::[^>]+)?>', path))
        if not route_param_names:
            route_param_names = set(re.findall(r'\{(\w+)(?::[^}]+)?\}', path))
        format_kwargs = {}
        for name in route_param_names:
            if name in kwargs:
                format_kwargs[name] = str(kwargs[name])

        try:
            path = url_template.format_map(format_kwargs)
        except KeyError as e:
            raise ValueError(
                f"Missing required path parameter for '{handler_name}': {e}. "
                f"Got kwargs: {list(kwargs.keys())}"
            )

        unresolved = re.findall(r'\{(\w+)\}', path)
        if unresolved:
            raise ValueError(
                f"Missing required path parameters for '{handler_name}': {', '.join(unresolved)}. "
                f"Got kwargs: {list(kwargs.keys())}"
            )

        query_params = {k: v for k, v in kwargs.items() if k not in route_param_names and not k.startswith('_')}
        if query_params:
            from urllib.parse import urlencode
            path += "?" + urlencode(query_params)

        if _external:
            scheme = _scheme or 'http'
            host = getattr(self, '_server_name', None)
            if not host and hasattr(self, '_app') and self._app is not None:
                server_name = getattr(self._app.config, 'server_name', None)
                if server_name:
                    host = server_name
                preferred_scheme = getattr(self._app.config, 'preferred_url_scheme', None)
                if preferred_scheme and not _scheme:
                    scheme = preferred_scheme
            if not host:
                try:
                    from kewe.base.context import g
                    req = getattr(g, 'request', None)
                    if req is not None:
                        host = req.headers.get('host', 'localhost')
                        scheme = req.scheme or scheme
                except Exception:
                    logger.warning("Request context lookup for url_for failed", exc_info=True)
            if not host:
                host = 'localhost'
            port = getattr(self, '_server_port', None)
            url = f"{scheme}://{host}"
            if port and int(port) not in (80, 443):
                url += f":{port}"
            url += path
            path = url

        if _anchor:
            from urllib.parse import quote
            path += "#" + quote(_anchor)

        return path
    
    def get_route_by_name(self, name: str) -> Optional[Route]:
        """
        通过名称获取路由
        
        Args:
            name: 路由名称
        
        Returns:
            路由对象
        """
        return self._name_map.get(name)
    
    def add_blueprint(self, blueprint: Blueprint, url_prefix: str = None, host: str = None):
        """
        添加蓝图
        
        Args:
            blueprint: 蓝图
            url_prefix: 路由前缀
            host: 主机匹配
        """
        blueprint.register(self, url_prefix, host)
