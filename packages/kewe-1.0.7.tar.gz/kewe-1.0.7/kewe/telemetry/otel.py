#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.telemetry.otel - OpenTelemetry integration for distributed tracing
"""

import logging
from typing import Optional, Dict, Any

logger = logging.getLogger(__name__)

OTEL_AVAILABLE = False
try:
    from opentelemetry import trace, metrics
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import BatchSpanProcessor
    from opentelemetry.sdk.metrics import MeterProvider
    from opentelemetry.sdk.resources import Resource
    OTEL_AVAILABLE = True
except ImportError:
    pass


class OpenTelemetryConfig:
    """OpenTelemetry 配置"""

    def __init__(
        self,
        service_name: str = "kewe-app",
        service_version: str = None,
        endpoint: Optional[str] = None,
        export_interval_ms: int = 5000,
        resource_attributes: Optional[Dict[str, Any]] = None,
    ):
        self.service_name = service_name
        if service_version is None:
            from kewe import __version__
            service_version = __version__
        self.service_version = service_version
        self.endpoint = endpoint
        self.export_interval_ms = export_interval_ms
        self.resource_attributes = resource_attributes or {}


class OpenTelemetryIntegration:
    """OpenTelemetry 集成"""

    def __init__(self, config: Optional[OpenTelemetryConfig] = None):
        self.config = config or OpenTelemetryConfig()
        self._tracer = None
        self._meter = None
        self._initialized = False
        self._request_counter = None
        self._request_duration = None
        self._error_counter = None
        self._active_requests = None

    def initialize(self) -> bool:
        """初始化 OpenTelemetry SDK"""
        if not OTEL_AVAILABLE:
            logger.warning("OpenTelemetry SDK not installed. "
                         "Install with: pip install opentelemetry-api opentelemetry-sdk")
            return False

        try:
            resource = Resource.create({
                "service.name": self.config.service_name,
                "service.version": self.config.service_version,
                **self.config.resource_attributes,
            })

            tracer_provider = TracerProvider(resource=resource)

            if self.config.endpoint:
                try:
                    from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
                    exporter = OTLPSpanExporter(endpoint=self.config.endpoint)
                    tracer_provider.add_span_processor(
                        BatchSpanProcessor(exporter, schedule_delay_millis=self.config.export_interval_ms)
                    )
                except ImportError:
                    try:
                        from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
                        exporter = OTLPSpanExporter(endpoint=self.config.endpoint)
                        tracer_provider.add_span_processor(
                            BatchSpanProcessor(exporter, schedule_delay_millis=self.config.export_interval_ms)
                        )
                    except ImportError:
                        logger.warning("No OTLP exporter available. Install opentelemetry-exporter-otlp")

            trace.set_tracer_provider(tracer_provider)
            self._tracer = trace.get_tracer(self.config.service_name, self.config.service_version)

            meter_provider = MeterProvider(resource=resource)
            metrics.set_meter_provider(meter_provider)
            self._meter = metrics.get_meter(self.config.service_name, self.config.service_version)

            self._init_instruments()

            self._initialized = True
            logger.info(f"OpenTelemetry initialized: service={self.config.service_name}")
            return True

        except Exception as e:
            logger.error(f"Failed to initialize OpenTelemetry: {e}")
            return False

    def _init_instruments(self):
        if self._meter is None:
            return
        try:
            self._request_counter = self._meter.create_counter(
                name="kewe.http.requests",
                description="Total HTTP requests",
                unit="1",
            )
            self._error_counter = self._meter.create_counter(
                name="kewe.http.errors",
                description="Total HTTP errors",
                unit="1",
            )
            self._request_duration = self._meter.create_histogram(
                name="kewe.http.duration",
                description="HTTP request duration",
                unit="ms",
            )
            self._active_requests = self._meter.create_up_down_counter(
                name="kewe.http.active_requests",
                description="Active HTTP requests",
                unit="1",
            )
            self._request_size = self._meter.create_histogram(
                name="kewe.http.request.size",
                description="HTTP request body size",
                unit="By",
            )
            self._response_size = self._meter.create_histogram(
                name="kewe.http.response.size",
                description="HTTP response body size",
                unit="By",
            )
            self._db_query_duration = self._meter.create_histogram(
                name="kewe.db.query.duration",
                description="Database query duration",
                unit="ms",
            )
            self._db_query_counter = self._meter.create_counter(
                name="kewe.db.queries",
                description="Total database queries",
                unit="1",
            )
        except Exception as e:
            logger.warning(f"Failed to create instruments: {e}")

    def record_request(self, method: str, path: str, status: int, duration_ms: float):
        if not self._initialized:
            return
        try:
            attrs = {"http.method": method, "http.status_code": status, "http.route": path}
            if self._request_counter:
                self._request_counter.add(1, attrs)
            if self._request_duration:
                self._request_duration.record(duration_ms, attrs)
            if status >= 400 and self._error_counter:
                self._error_counter.add(1, attrs)
        except Exception:
            logger.warning("OpenTelemetry start_active_request failed", exc_info=True)

    def start_active_request(self, method: str, path: str):
        if not self._initialized or not self._active_requests:
            return
        try:
            self._active_requests.add(1, {"http.method": method, "http.route": path})
        except Exception:
            logger.warning("OpenTelemetry end_active_request failed", exc_info=True)

    def end_active_request(self, method: str, path: str):
        if not self._initialized or not self._active_requests:
            return
        try:
            self._active_requests.add(-1, {"http.method": method, "http.route": path})
        except Exception:
            logger.warning("OpenTelemetry record_request failed", exc_info=True)

    def record_request_size(self, method: str, path: str, size: int):
        if not self._initialized or not self._request_size:
            return
        try:
            self._request_size.record(size, {"http.method": method, "http.route": path})
        except Exception:
            logger.warning("OpenTelemetry record_response_size failed", exc_info=True)

    def record_response_size(self, method: str, path: str, size: int):
        if not self._initialized or not self._response_size:
            return
        try:
            self._response_size.record(size, {"http.method": method, "http.route": path})
        except Exception:
            logger.warning("OpenTelemetry record_db_query failed", exc_info=True)

    def record_db_query(self, operation: str, table: str, duration_ms: float):
        if not self._initialized:
            return
        try:
            attrs = {"db.operation": operation, "db.table": table}
            if self._db_query_counter:
                self._db_query_counter.add(1, attrs)
            if self._db_query_duration:
                self._db_query_duration.record(duration_ms, attrs)
        except Exception:
            logger.debug("Non-critical operation failed", exc_info=True)

    @property
    def tracer(self):
        if not self._initialized:
            self.initialize()
        return self._tracer

    @property
    def meter(self):
        if not self._initialized:
            self.initialize()
        return self._meter

    def create_middleware(self):
        """创建 OpenTelemetry 中间件"""
        if not OTEL_AVAILABLE:
            return None

        class OTelMiddleware:
            def __init__(self, integration: OpenTelemetryIntegration):
                self.integration = integration

            async def __call__(self, request, call_next):
                tracer = self.integration.tracer
                if not tracer:
                    return await call_next(request)

                method = getattr(request, 'method', 'UNKNOWN')
                path = getattr(request, 'path', '/')
                span_name = f"{method} {path}"

                self.integration.start_active_request(method, path)

                with tracer.start_as_current_span(span_name) as span:
                    span.set_attribute("http.method", method)
                    span.set_attribute("http.url", str(getattr(request, 'url', '')))
                    span.set_attribute("http.scheme", getattr(request, 'scheme', 'http'))
                    span.set_attribute("http.host", getattr(request, 'host', ''))
                    span.set_attribute("http.target", path)
                    span.set_attribute("http.flavor", getattr(request, 'protocol_version', '1.1'))
                    span.set_attribute("http.user_agent", getattr(request, 'user_agent', ''))
                    span.set_attribute("net.peer.ip", getattr(request, 'client_ip', ''))

                    content_length = getattr(request, 'content_length', 0)
                    if content_length:
                        self.integration.record_request_size(method, path, content_length)

                    try:
                        response = await call_next(request)
                    except Exception as exc:
                        span.set_attribute("error", True)
                        span.record_exception(exc)
                        self.integration.end_active_request(method, path)
                        raise

                    status = getattr(response, 'status', 0)
                    span.set_attribute("http.status_code", status)
                    if status >= 400:
                        span.set_attribute("error", True)
                        span.add_event("http.error", {"http.status_code": status})

                    response_body = getattr(response, 'body', b'')
                    if response_body:
                        self.integration.record_response_size(method, path, len(response_body))

                    self.integration.end_active_request(method, path)

                    return response

        return OTelMiddleware(self)


def setup_opentelemetry(app, config: Optional[OpenTelemetryConfig] = None):
    """在 Kewe 应用中设置 OpenTelemetry"""
    integration = OpenTelemetryIntegration(config)

    if integration.initialize():
        middleware = integration.create_middleware()
        if middleware:
            app._onion_chain.add_from_middleware(middleware)
            logger.info("OpenTelemetry middleware added to application")

    return integration


__all__ = [
    'OpenTelemetryConfig',
    'OpenTelemetryIntegration',
    'setup_opentelemetry',
    'OTEL_AVAILABLE',
    'is_otel_available',
]

is_otel_available = lambda: OTEL_AVAILABLE

