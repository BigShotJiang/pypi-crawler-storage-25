#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.worker.worker - Individual worker process implementation
"""

import asyncio
import logging
import os
import signal
import sys
from typing import Optional

logger = logging.getLogger(__name__)


class GunicornWorker:
    """
    Gunicorn工作进程
    兼容Gunicorn的worker接口
    """

    def __init__(self, app, host: str = "0.0.0.0", port: int = 8000):
        self.app = app
        self.host = host
        self.port = port
        self.loop: Optional[asyncio.AbstractEventLoop] = None
        self.server = None
        self._shutdown_event = asyncio.Event()

    async def run(self):
        from kewe.server import KeweServer

        self.loop = asyncio.get_running_loop()
        self._setup_signals()
        self.server = KeweServer(self.app, self.host, self.port)
        logger.info(f"Gunicorn worker starting on {self.host}:{self.port}")
        await self.server.start()
        await self._shutdown_event.wait()
        await self.server.stop()

    def _setup_signals(self):
        for sig in (signal.SIGTERM, signal.SIGINT):
            self.loop.add_signal_handler(sig, self._signal_handler)

    def _signal_handler(self):
        logger.info("Received shutdown signal")
        self._shutdown_event.set()

    def init_process(self):
        self.loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.loop)
        try:
            self.loop.run_until_complete(self.run())
        finally:
            self.loop.close()


def kewe_worker(app, host: str = "0.0.0.0", port: int = 8000):
    worker = GunicornWorker(app, host, port)
    return worker


class ProcessManager:

    def __init__(self, app, num_workers: int = 4, host: str = "0.0.0.0", port: int = 8000):
        self.app = app
        self.num_workers = num_workers
        self.host = host
        self.port = port
        self.processes = []
        self._shutdown = False

    def start(self):
        import multiprocessing

        logger.info(f"Starting {self.num_workers} workers on {self.host}:{self.port}")

        for i in range(self.num_workers):
            process = multiprocessing.Process(
                target=self._worker_process,
                args=(i,)
            )
            process.start()
            self.processes.append(process)

        try:
            for process in self.processes:
                process.join()
        except KeyboardInterrupt:
            logger.info("Shutting down workers...")
            self.stop()

    def _worker_process(self, worker_id: int):
        try:
            import setproctitle
            setproctitle.setproctitle(f"kewe-worker-{worker_id}")
        except ImportError:
            pass
        asyncio.run(self._run_server(worker_id))

    async def _run_server(self, worker_id: int):
        from kewe.server import KeweServer
        port = self.port + worker_id if self.num_workers > 1 else self.port
        server = KeweServer(self.app, self.host, port)
        logger.info(f"Worker {worker_id} starting on {self.host}:{port}")
        await server.start()

    def stop(self):
        self._shutdown = True
        for process in self.processes:
            if process.is_alive():
                process.terminate()
                process.join(timeout=5)
                if process.is_alive():
                    process.kill()
                    process.join()


__all__ = ['GunicornWorker', 'ProcessManager', 'kewe_worker']
