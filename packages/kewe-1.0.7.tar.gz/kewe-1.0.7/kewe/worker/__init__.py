#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.worker - Worker package initialization
"""

from enum import Enum, auto


class WorkerState(Enum):
    IDLE = auto()
    INIT = auto()
    STARTING = auto()
    RUNNING = auto()
    RESTARTING = auto()
    STOPPING = auto()
    STOPPED = auto()
    FAILED = auto()


from .worker import GunicornWorker, ProcessManager
from .custom import (
    WorkerInfo,
    WorkerProcess,
    SocketManager,
    WorkerManager,
    MultiWorkerServer,
)
from .multiplexer import Multiplexer, WorkerSharedState
from .shared_ctx import SharedContextError, SharedObjectProxy, SharedContext, SimpleContext, create_shared_context
from .manager import (
    WorkerConfig,
    WorkerMessage,
    Worker,
    ProcessWorkerManager,
    run_with_workers,
    get_worker_manager,
    set_worker_manager,
)

__all__ = [
    'WorkerState',
    'GunicornWorker',
    'ProcessManager',
    'WorkerInfo',
    'WorkerProcess',
    'SocketManager',
    'WorkerManager',
    'MultiWorkerServer',
    'Multiplexer',
    'WorkerSharedState',
    'SharedContextError',
    'SharedObjectProxy',
    'SharedContext',
    'SimpleContext',
    'create_shared_context',
    'WorkerConfig',
    'WorkerMessage',
    'Worker',
    'ProcessWorkerManager',
    'run_with_workers',
    'get_worker_manager',
    'set_worker_manager',
]
