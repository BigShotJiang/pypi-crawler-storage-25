#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.worker.shared_ctx - Shared context for cross-worker data exchange
"""

import logging
import multiprocessing as mp
from multiprocessing.managers import SyncManager, BaseManager
from typing import Any, Dict, List, Optional, Type, Callable, Set, Union
from dataclasses import dataclass
from threading import RLock
import pickle

from kewe.errors.exceptions import KeweException

logger = logging.getLogger(__name__)


class SharedContextError(KeweException):
    """共享上下文错误"""
    error_code = "SHARED_CONTEXT_ERROR"

    def __init__(self, message: str = "Shared context error"):
        super().__init__(message=message, status_code=500, error_code=self.error_code)


class SharedObjectProxy:
    """
    共享对象代理
    
    用于代理 multiprocessing.Manager 创建的共享对象
    """
    
    def __init__(self, obj):
        self._obj = obj
    
    def __getattr__(self, name):
        return getattr(self._obj, name)
    
    def __setattr__(self, name, value):
        if name.startswith('_'):
            super().__setattr__(name, value)
        else:
            setattr(self._obj, name, value)
    
    def __getitem__(self, key):
        return self._obj[key]
    
    def __setitem__(self, key, value):
        self._obj[key] = value
    
    def __delitem__(self, key):
        del self._obj[key]
    
    def __contains__(self, key):
        return key in self._obj
    
    def __len__(self):
        return len(self._obj)
    
    def __iter__(self):
        return iter(self._obj)


class SharedContext:
    """
    跨 Worker 共享上下文
    
    基于 multiprocessing.Manager 实现多进程间共享数据
    
    使用示例:
        @app.before_server_start
        async def setup(app):
            app.shared_ctx.db = Database()
            app.shared_ctx.cache = {}
        
        @app.get("/")
        async def handler(request):
            db = request.app.shared_ctx.db
            cache = request.app.shared_ctx.cache
    
    注意:
        - 只能共享可 pickle 序列化的对象
        - 使用 multiprocessing.Manager 创建的共享数据结构
        - 不适用于跨机器的水平扩展
    """
    
    _SUPPORTED_TYPES: Set[Type] = {
        dict, list, set, tuple,
        int, float, str, bool, bytes,
        type(None)
    }
    
    def __init__(self, manager: SyncManager = None, auto_start: bool = True):
        """
        初始化共享上下文
        
        Args:
            manager: SyncManager 实例（如果为 None 则自动创建）
            auto_start: 是否自动启动 manager
        """
        self._manager: Optional[SyncManager] = manager
        self._auto_start = auto_start
        self._objects: Dict[str, Any] = {}
        self._lock = RLock()
        self._started = False
    
    def _ensure_manager(self):
        """确保 manager 已启动"""
        if self._manager is None:
            self._manager = mp.Manager()
        if self._auto_start and not self._started:
            try:
                self._manager.start()
                self._started = True
            except Exception as e:
                logger.warning(f"Failed to start manager: {e}")
    
    def __getattr__(self, name: str) -> Any:
        if name.startswith('_'):
            return super().__getattribute__(name)
        
        with self._lock:
            if name in self._objects:
                return self._objects[name]
            raise AttributeError(
                f"SharedContext has no attribute '{name}'. "
                f"Did you forget to set it in a before_server_start listener?"
            )
    
    def __setattr__(self, name: str, value: Any) -> None:
        if name.startswith('_'):
            super().__setattr__(name, value)
            return
        
        self._ensure_manager()
        
        with self._lock:
            shared_value = self._make_shared(value)
            self._objects[name] = shared_value
            logger.debug(f"Set shared context attribute: {name}")
    
    def __delattr__(self, name: str) -> None:
        if name.startswith('_'):
            super().__delattr__(name)
            return
        
        with self._lock:
            if name in self._objects:
                del self._objects[name]
            else:
                raise AttributeError(f"SharedContext has no attribute '{name}'")
    
    def __contains__(self, name: str) -> bool:
        with self._lock:
            return name in self._objects
    
    def __iter__(self):
        with self._lock:
            return iter(list(self._objects.items()))
    
    def __len__(self) -> int:
        with self._lock:
            return len(self._objects)
    
    def __repr__(self) -> str:
        with self._lock:
            attrs = ', '.join(self._objects.keys())
            return f"SharedContext({attrs})"
    
    def _make_shared(self, value: Any) -> Any:
        """
        将值转换为共享对象
        
        Args:
            value: 原始值
            
        Returns:
            共享对象
        """
        if value is None:
            return None
        
        value_type = type(value)
        
        if value_type in (int, float, str, bool, bytes):
            return value
        
        if isinstance(value, dict):
            shared_dict = self._manager.dict()
            for k, v in value.items():
                shared_dict[k] = self._make_shared(v)
            return shared_dict
        
        if isinstance(value, list):
            shared_list = self._manager.list()
            for item in value:
                shared_list.append(self._make_shared(item))
            return shared_list
        
        if isinstance(value, set):
            shared_set = self._manager.list()
            for item in value:
                shared_set.append(item)
            return shared_set
        
        try:
            pickle.dumps(value)
            return value
        except (pickle.PicklingError, TypeError) as e:
            logger.warning(
                f"Object of type {value_type.__name__} is not pickle-serializable: {e}. "
                f"It may not be properly shared across processes."
            )
            return value
    
    def get(self, name: str, default: Any = None) -> Any:
        """
        获取共享值
        
        Args:
            name: 属性名
            default: 默认值
            
        Returns:
            共享值或默认值
        """
        with self._lock:
            return self._objects.get(name, default)
    
    def set(self, name: str, value: Any) -> None:
        """
        设置共享值
        
        Args:
            name: 属性名
            value: 值
        """
        self.__setattr__(name, value)
    
    def delete(self, name: str) -> bool:
        """
        删除共享值
        
        Args:
            name: 属性名
            
        Returns:
            是否成功删除
        """
        with self._lock:
            if name in self._objects:
                del self._objects[name]
                return True
            return False
    
    def keys(self) -> List[str]:
        """获取所有属性名"""
        with self._lock:
            return list(self._objects.keys())
    
    def values(self) -> List[Any]:
        """获取所有值"""
        with self._lock:
            return list(self._objects.values())
    
    def items(self) -> List[tuple]:
        """获取所有键值对"""
        with self._lock:
            return list(self._objects.items())
    
    def update(self, data: Dict[str, Any]) -> None:
        """
        批量更新
        
        Args:
            data: 字典数据
        """
        for key, value in data.items():
            self.set(key, value)
    
    def clear(self) -> None:
        """清除所有共享值"""
        with self._lock:
            self._objects.clear()
    
    def create_dict(self, name: str, initial: Dict = None) -> Dict:
        """
        创建共享字典
        
        Args:
            name: 属性名
            initial: 初始值
            
        Returns:
            共享字典
        """
        self._ensure_manager()
        shared_dict = self._manager.dict(initial or {})
        with self._lock:
            self._objects[name] = shared_dict
        return shared_dict
    
    def create_list(self, name: str, initial: List = None) -> List:
        """
        创建共享列表
        
        Args:
            name: 属性名
            initial: 初始值
            
        Returns:
            共享列表
        """
        self._ensure_manager()
        shared_list = self._manager.list(initial or [])
        with self._lock:
            self._objects[name] = shared_list
        return shared_list
    
    def create_queue(self, name: str, maxsize: int = 0) -> mp.Queue:
        """
        创建共享队列
        
        Args:
            name: 属性名
            maxsize: 最大大小（0 表示无限制）
            
        Returns:
            共享队列
        """
        self._ensure_manager()
        shared_queue = self._manager.Queue(maxsize=maxsize)
        with self._lock:
            self._objects[name] = shared_queue
        return shared_queue
    
    def create_lock(self, name: str) -> mp.Lock:
        """
        创建共享锁
        
        Args:
            name: 属性名
            
        Returns:
            共享锁
        """
        self._ensure_manager()
        shared_lock = self._manager.Lock()
        with self._lock:
            self._objects[name] = shared_lock
        return shared_lock
    
    def create_event(self, name: str) -> mp.Event:
        """
        创建共享事件
        
        Args:
            name: 属性名
            
        Returns:
            共享事件
        """
        self._ensure_manager()
        shared_event = self._manager.Event()
        with self._lock:
            self._objects[name] = shared_event
        return shared_event
    
    def shutdown(self) -> None:
        """关闭共享上下文"""
        if self._manager and self._started:
            try:
                self._manager.shutdown()
                self._started = False
                logger.debug("SharedContext manager shutdown")
            except Exception as e:
                logger.warning(f"Error shutting down manager: {e}")


class SimpleContext:
    """
    简单上下文（单进程模式）
    
    用于单 Worker 模式或测试环境
    """
    
    def __init__(self):
        self._data: Dict[str, Any] = {}
        self._lock = RLock()
    
    def __getattr__(self, name: str) -> Any:
        if name.startswith('_'):
            return super().__getattribute__(name)
        
        with self._lock:
            if name in self._data:
                return self._data[name]
            raise AttributeError(f"Context has no attribute '{name}'")
    
    def __setattr__(self, name: str, value: Any) -> None:
        if name.startswith('_'):
            super().__setattr__(name, value)
            return
        
        with self._lock:
            self._data[name] = value
    
    def __delattr__(self, name: str) -> None:
        if name.startswith('_'):
            super().__delattr__(name)
            return
        
        with self._lock:
            if name in self._data:
                del self._data[name]
            else:
                raise AttributeError(f"Context has no attribute '{name}'")
    
    def __contains__(self, name: str) -> bool:
        with self._lock:
            return name in self._data
    
    def get(self, name: str, default: Any = None) -> Any:
        with self._lock:
            return self._data.get(name, default)
    
    def set(self, name: str, value: Any) -> None:
        with self._lock:
            self._data[name] = value
    
    def delete(self, name: str) -> bool:
        with self._lock:
            if name in self._data:
                del self._data[name]
                return True
            return False
    
    def keys(self) -> List[str]:
        with self._lock:
            return list(self._data.keys())
    
    def clear(self) -> None:
        with self._lock:
            self._data.clear()


def create_shared_context(
    workers: int = 1,
    manager: SyncManager = None
) -> Union[SharedContext, SimpleContext]:
    """
    创建共享上下文
    
    Args:
        workers: Worker 数量（如果为 1 则使用简单上下文）
        manager: SyncManager 实例
        
    Returns:
        SharedContext 或 SimpleContext
    """
    if workers <= 1:
        logger.debug("Using SimpleContext for single worker mode")
        return SimpleContext()
    
    return SharedContext(manager=manager)


__all__ = [
    'SharedContext',
    'SimpleContext',
    'SharedContextError',
    'SharedObjectProxy',
    'create_shared_context',
]
