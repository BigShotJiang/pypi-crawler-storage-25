#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.worker.manager - Worker process manager with configuration
"""

import os
import sys
import signal
import multiprocessing
import logging
from kewe.utils.compat import json
import struct
import socket
from typing import Optional, Callable, List, Dict, Any, Union
from dataclasses import dataclass, field
from enum import Enum, auto
from time import time, sleep

from kewe.worker import WorkerState

logger = logging.getLogger(__name__)


@dataclass
class WorkerConfig:
    """Worker配置 - Worker配置"""
    num_workers: int = 1
    host: str = "0.0.0.0"
    port: int = 8000
    debug: bool = False
    access_log: bool = True
    
    # 进程管理
    max_requests_per_worker: int = 0  # 0表示无限制
    worker_timeout: int = 30
    graceful_timeout: int = 10
    keep_alive_timeout: int = 5
    
    # 自动重启
    auto_restart: bool = True
    restart_delay: float = 1.0
    
    # 性能
    request_timeout: float = 60.0
    request_max_size: int = 100 * 1024 * 1024
    
    # IPC
    ipc_socket_path: Optional[str] = None


class WorkerMessage:
    """Worker间通信消息"""
    
    def __init__(self, msg_type: str, data: Any = None):
        self.type = msg_type
        self.data = data
        self.timestamp = time()
    
    def to_bytes(self) -> bytes:
        payload = json.dumps({
            'type': self.type,
            'data': self.data,
            'timestamp': self.timestamp
        }, default=str).encode('utf-8')
        return struct.pack('!I', len(payload)) + payload
    
    @classmethod
    def from_bytes(cls, data: bytes) -> 'WorkerMessage':
        payload = json.loads(data[4:].decode('utf-8'))
        msg = cls(payload['type'], payload['data'])
        msg.timestamp = payload['timestamp']
        return msg


class Worker:
    """
    工作进程 - Worker实现
    
    封装单个工作进程的生命周期管理
    """
    
    def __init__(
        self,
        worker_id: int,
        target: Callable,
        args: tuple = (),
        kwargs: dict = None,
        config: WorkerConfig = None
    ):
        self.worker_id = worker_id
        self.target = target
        self.args = args
        self.kwargs = kwargs or {}
        self.config = config or WorkerConfig()
        
        self.process: Optional[multiprocessing.Process] = None
        self.state = WorkerState.IDLE
        self.start_time: Optional[float] = None
        self.request_count = 0
        self.last_request_time: Optional[float] = None
        
        # IPC
        self._ipc_socket: Optional[socket.socket] = None
        self._ipc_path: Optional[str] = None
    
    def start(self):
        """启动工作进程"""
        self.state = WorkerState.STARTING
        
        # 创建进程
        self.process = multiprocessing.Process(
            target=self._run,
            name=f"kewe-worker-{self.worker_id}",
            daemon=False
        )
        self.process.start()
        self.start_time = time()
        self.state = WorkerState.RUNNING
        
        logger.info(f"Worker {self.worker_id} started (PID: {self.process.pid})")
    
    def _run(self):
        """工作进程运行入口"""
        # 设置进程标题
        self._set_process_title()
        
        # 设置信号处理
        self._setup_signals()
        
        # 设置IPC
        self._setup_ipc()
        
        try:
            # 运行目标函数
            self.target(*self.args, **self.kwargs)
        except Exception as e:
            logger.error(f"Worker {self.worker_id} error: {e}")
            raise
    
    def _set_process_title(self):
        """设置进程标题"""
        try:
            import setproctitle
            setproctitle.setproctitle(f"kewe-worker-{self.worker_id}")
        except ImportError:
            pass
    
    def _setup_signals(self):
        """设置信号处理"""
        def signal_handler(signum, frame):
            logger.info(f"Worker {self.worker_id} received signal {signum}")
            self.state = WorkerState.STOPPING
            sys.exit(0)
        
        signal.signal(signal.SIGTERM, signal_handler)
        signal.signal(signal.SIGINT, signal_handler)
        
        # 忽略SIGCHLD
        signal.signal(signal.SIGCHLD, signal.SIG_IGN)
    
    def _setup_ipc(self):
        """设置IPC通信"""
        if self.config.ipc_socket_path:
            self._ipc_path = f"{self.config.ipc_socket_path}.{self.worker_id}"
    
    def stop(self, graceful: bool = True):
        """停止工作进程"""
        if not self.process or not self.process.is_alive():
            return
        
        self.state = WorkerState.STOPPING
        
        if graceful:
            # 优雅停止：发送SIGTERM
            self.process.terminate()
            self.process.join(timeout=self.config.graceful_timeout)
            
            if self.process.is_alive():
                # 强制停止
                logger.warning(f"Worker {self.worker_id} force kill")
                self.process.kill()
                self.process.join()
        else:
            # 强制停止
            self.process.kill()
            self.process.join()
        
        self.state = WorkerState.STOPPED
        logger.info(f"Worker {self.worker_id} stopped")
    
    def restart(self):
        """重启工作进程"""
        self.state = WorkerState.RESTARTING
        self.stop(graceful=True)
        sleep(self.config.restart_delay)
        self.start()
    
    def is_alive(self) -> bool:
        """检查进程是否存活"""
        return self.process is not None and self.process.is_alive()
    
    def increment_request_count(self):
        """增加请求计数"""
        self.request_count += 1
        self.last_request_time = time()
    
    def get_uptime(self) -> float:
        """获取运行时间"""
        if self.start_time is None:
            return 0.0
        return time() - self.start_time


class ProcessWorkerManager:
    """
    Worker进程管理器 - WorkerManager实现
    
    管理多个工作进程的生命周期，支持：
    - 进程监控和自动重启
    - 优雅关闭
    - 进程间通信
    - 负载均衡
    """
    
    def __init__(self, config: WorkerConfig = None):
        self.config = config or WorkerConfig()
        self.workers: Dict[int, Worker] = {}
        self._shutdown = False
        self._monitor_task: Optional[Any] = None
        self._master_pid: Optional[int] = None
        self._target: Optional[Callable] = None
        self._target_args: tuple = ()
        self._target_kwargs: dict = {}
        
        # 统计
        self._total_requests = 0
        self._start_time: Optional[float] = None
        
        # IPC
        self._ipc_socket: Optional[socket.socket] = None
        self._ipc_path: Optional[str] = None
    
    def start_workers(self, target: Callable, *args, **kwargs):
        """
        启动所有工作进程
        
        Args:
            target: 工作进程执行的函数
            *args, **kwargs: 传递给target的参数
        """
        self._master_pid = os.getpid()
        self._start_time = time()
        self._target = target
        self._target_args = args
        self._target_kwargs = kwargs
        
        logger.info(f"Starting {self.config.num_workers} workers")
        logger.info(f"Master PID: {self._master_pid}")
        
        # 设置主进程信号处理
        self._setup_master_signals()
        
        # 创建Worker
        for i in range(self.config.num_workers):
            worker = Worker(
                worker_id=i,
                target=target,
                args=args,
                kwargs=kwargs,
                config=self.config
            )
            worker.start()
            self.workers[i] = worker
        
        # 启动监控
        self._start_monitor()
    
    def _setup_master_signals(self):
        """设置主进程信号处理"""
        def signal_handler(signum, frame):
            logger.info(f"Master received signal {signum}")
            self._shutdown = True
        
        signal.signal(signal.SIGTERM, signal_handler)
        signal.signal(signal.SIGINT, signal_handler)
        
        # 设置进程标题
        try:
            import setproctitle
            setproctitle.setproctitle("kewe-master")
        except ImportError:
            pass
    
    def _start_monitor(self):
        """启动进程监控"""
        import threading
        
        def monitor():
            while not self._shutdown:
                self._check_workers()
                sleep(1)
        
        self._monitor_task = threading.Thread(target=monitor, daemon=True)
        self._monitor_task.start()
    
    def _check_workers(self):
        """检查Worker状态"""
        for worker_id, worker in list(self.workers.items()):
            if not worker.is_alive():
                if not self._shutdown and self.config.auto_restart:
                    logger.warning(f"Worker {worker_id} died, restarting...")
                    worker.start()
                else:
                    logger.info(f"Worker {worker_id} stopped")
                    del self.workers[worker_id]
            
            # 检查最大请求数
            elif (self.config.max_requests_per_worker > 0 and 
                  worker.request_count >= self.config.max_requests_per_worker):
                logger.info(f"Worker {worker_id} max requests reached, restarting...")
                worker.restart()
    
    def stop_workers(self, graceful: bool = True):
        """停止所有工作进程"""
        logger.info("Stopping all workers...")
        self._shutdown = True
        
        # 停止监控
        if self._monitor_task and self._monitor_task.is_alive():
            self._monitor_task.join(timeout=1)
        
        # 停止所有Worker
        for worker in self.workers.values():
            worker.stop(graceful=graceful)
        
        self.workers.clear()
        logger.info("All workers stopped")
    
    def restart_workers(self):
        """重启所有工作进程"""
        logger.info("Restarting all workers...")
        for worker in self.workers.values():
            worker.restart()
    
    def scale_workers(self, num_workers: int):
        current = len(self.workers)
        
        if num_workers > current:
            if not self._target:
                logger.warning("Cannot scale up: no target function stored")
            else:
                for i in range(current, num_workers):
                    worker = Worker(
                        worker_id=i,
                        target=self._target,
                        args=self._target_args,
                        kwargs=self._target_kwargs,
                        config=self.config,
                    )
                    worker.start()
                    self.workers[i] = worker
                    logger.info(f"Scaled up: added worker {i}")
                
        elif num_workers < current:
            # 减少Worker
            for i in range(num_workers, current):
                if i in self.workers:
                    self.workers[i].stop()
                    del self.workers[i]
        
        self.config.num_workers = num_workers
        logger.info(f"Scaled workers to {num_workers}")
    
    def get_worker_status(self) -> List[Dict[str, Any]]:
        """获取所有Worker状态"""
        status = []
        for worker_id, worker in list(self.workers.items()):
            status.append({
                'worker_id': worker_id,
                'pid': worker.process.pid if worker.process else None,
                'state': worker.state.name,
                'is_alive': worker.is_alive(),
                'request_count': worker.request_count,
                'uptime': worker.get_uptime(),
                'start_time': worker.start_time
            })
        return status
    
    def get_stats(self) -> Dict[str, Any]:
        """获取管理器统计"""
        return {
            'master_pid': self._master_pid,
            'num_workers': len(self.workers),
            'total_requests': self._total_requests,
            'uptime': time() - self._start_time if self._start_time else 0,
            'workers': self.get_worker_status()
        }


def run_with_workers(
    app,
    num_workers: int = 1,
    host: str = "0.0.0.0",
    port: int = 8000,
    **kwargs
):
    """
    使用多进程运行应用 - 多进程模式
    
    示例:
        run_with_workers(app, num_workers=4, host="0.0.0.0", port=8000)
    """
    config = WorkerConfig(
        num_workers=num_workers,
        host=host,
        port=port,
        **kwargs
    )
    
    manager = ProcessWorkerManager(config)
    
    def worker_target():
        """Worker进程目标函数"""
        import asyncio
        from kewe.server import serve
        from kewe.utils.compat import auto_select_event_loop
        
        # 选择最佳事件循环
        auto_select_event_loop()
        
        # 运行服务器
        asyncio.run(serve(
            app,
            host=host,
            port=port,
            **kwargs
        ))
    
    try:
        manager.start_workers(worker_target)
        
        # 等待所有Worker
        while True:
            sleep(1)
            
    except KeyboardInterrupt:
        logger.info("Received keyboard interrupt")
    finally:
        manager.stop_workers()


# 全局Worker管理器实例
_global_worker_manager: Optional[ProcessWorkerManager] = None


def get_worker_manager() -> Optional[ProcessWorkerManager]:
    """获取全局Worker管理器"""
    return _global_worker_manager


def set_worker_manager(manager: ProcessWorkerManager):
    """设置全局Worker管理器"""
    global _global_worker_manager
    _global_worker_manager = manager




