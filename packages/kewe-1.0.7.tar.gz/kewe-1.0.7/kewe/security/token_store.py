#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.security.token_store - Token storage with persistence and expiry management
"""

import time
import threading
from kewe.utils.compat import json as _json
from typing import Optional, Dict, Any, List, Tuple
from dataclasses import dataclass, asdict

from kewe.logging.logger import get_logger
from kewe.application.config import Config


@dataclass
class RefreshTokenData:
    """刷新令牌数据"""
    jti: str
    created_at: int
    expires_at: int
    usage_count: int = 0
    max_usage: int = 10
    device_fingerprint: Optional[str] = None
    ip_address: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "RefreshTokenData":
        return cls(**data)


class TokenStore:
    """令牌存储"""

    DEFAULT_REDIS_PREFIX_BLACKLIST = "kewe:blacklist:"
    DEFAULT_REDIS_PREFIX_REFRESH_TOKEN = "kewe:refresh:"

    def __init__(self, redis_client: Optional[Any] = None, config: Optional[Any] = None):
        self.redis = redis_client
        self.blacklist: Dict[str, int] = {}
        self.refresh_tokens: Dict[str, Dict[str, RefreshTokenData]] = {}
        self._user_revocation_ts: Dict[str, float] = {}
        self.lock = threading.RLock()
        self.logger = get_logger(__name__)
        self.config = config or Config()
        self.cleaner_thread = None
        self.running = False

    def start_cleaner(self):
        """启动清理线程"""
        self.running = True
        self.cleaner_thread = threading.Thread(target=self._cleanup_loop, daemon=True)
        self.cleaner_thread.start()
        self.logger.info("令牌存储清理线程已启动")

    def stop_cleaner(self):
        """停止清理线程"""
        self.running = False
        if self.cleaner_thread:
            self.cleaner_thread.join(timeout=5)
        self.logger.info("Token store cleanup thread stopped")

    def _cleanup_loop(self):
        """清理循环"""
        while self.running:
            try:
                self.cleanup_expired_blacklist()
                self.cleanup_expired_refresh_tokens()
            except Exception as e:
                self.logger.error(f"清理令牌失败: {e}")
            time.sleep(3600)  # 每小时清理一次

    def add_to_blacklist(self, jti: str, exp: int) -> bool:
        """将令牌加入黑名单"""
        try:
            if self.redis:
                redis_key = f"{self.config.redis_prefix_blacklist}{jti}"
                ttl = max(1, exp - int(time.time()))
                self.redis.setex(redis_key, ttl, "1")
            else:
                with self.lock:
                    self.blacklist[jti] = exp
            return True
        except Exception as e:
            self.logger.error(f"加入黑名单失败: {e}")
            return False

    def is_blacklisted(self, jti: Optional[str]) -> bool:
        if not jti:
            return False
        try:
            if self.redis:
                redis_key = f"{self.config.redis_prefix_blacklist}{jti}"
                return bool(self.redis.exists(redis_key))
            else:
                with self.lock:
                    if jti in self.blacklist:
                        if self.blacklist[jti] > time.time():
                            return True
                        else:
                            del self.blacklist[jti]
                            return False
                    return False
        except Exception as e:
            self.logger.error(f"Failed to check blacklist: {e}")
            return False

    def store_refresh_token(
        self,
        user_id: str,
        jti: str,
        expires_at: int,
        context: Any,
        max_usage: int = 10
    ) -> bool:
        """存储刷新令牌"""
        try:
            token_data = RefreshTokenData(
                jti=jti,
                created_at=int(time.time()),
                expires_at=expires_at,
                max_usage=max_usage,
                device_fingerprint=getattr(context, "device_fingerprint", None),
                ip_address=getattr(context, "ip_address", None)
            )

            if self.redis:
                redis_key = f"{self.config.redis_prefix_refresh_token}{user_id}:{jti}"
                ttl = max(1, expires_at - int(time.time()))
                self.redis.setex(redis_key, ttl, _json.dumps(token_data.to_dict()))
            else:
                with self.lock:
                    if user_id not in self.refresh_tokens:
                        self.refresh_tokens[user_id] = {}
                    self.refresh_tokens[user_id][jti] = token_data
            return True
        except Exception as e:
            self.logger.error(f"Failed to store refresh token: {e}")
            return False

    def get_refresh_token(self, user_id: str, jti: str) -> Optional[RefreshTokenData]:
        """获取刷新令牌"""
        try:
            if self.redis:
                redis_key = f"{self.config.redis_prefix_refresh_token}{user_id}:{jti}"
                data = self.redis.get(redis_key)
                if data:
                    return RefreshTokenData.from_dict(_json.loads(data))
            else:
                with self.lock:
                    if user_id in self.refresh_tokens and jti in self.refresh_tokens[user_id]:
                        token_data = self.refresh_tokens[user_id][jti]
                        if token_data.expires_at > time.time():
                            return token_data
                        else:
                            # 清理过期的刷新令牌
                            del self.refresh_tokens[user_id][jti]
            return None
        except Exception as e:
            self.logger.error(f"获取刷新令牌失败: {e}")
            return None

    def increment_refresh_usage(self, user_id: str, jti: str) -> bool:
        """增加刷新令牌使用次数"""
        try:
            if self.redis:
                redis_key = f"{self.config.redis_prefix_refresh_token}{user_id}:{jti}"
                data = self.redis.get(redis_key)
                if data:
                    token_data = RefreshTokenData.from_dict(_json.loads(data))
                    token_data.usage_count += 1
                    if token_data.usage_count <= token_data.max_usage:
                        ttl = max(1, token_data.expires_at - int(time.time()))
                        self.redis.setex(redis_key, ttl, _json.dumps(token_data.to_dict()))
                        return True
                    return False
            else:
                with self.lock:
                    if user_id in self.refresh_tokens and jti in self.refresh_tokens[user_id]:
                        token_data = self.refresh_tokens[user_id][jti]
                        if token_data.expires_at > time.time() and token_data.usage_count < token_data.max_usage:
                            token_data.usage_count += 1
                            return True
            return False
        except Exception as e:
            self.logger.error(f"增加刷新令牌使用次数失败: {e}")
            return False

    def revoke_refresh_token(self, user_id: str, jti: str) -> bool:
        """撤销刷新令牌"""
        try:
            if self.redis:
                redis_key = f"{self.config.redis_prefix_refresh_token}{user_id}:{jti}"
                self.redis.delete(redis_key)
            else:
                with self.lock:
                    if user_id in self.refresh_tokens and jti in self.refresh_tokens[user_id]:
                        del self.refresh_tokens[user_id][jti]
            return True
        except Exception as e:
            self.logger.error(f"Failed to revoke refresh token: {e}")
            return False

    def revoke_all_user_refresh_tokens(self, user_id: str) -> bool:
        try:
            if self.redis:
                pattern = f"{self.config.redis_prefix_refresh_token}{user_id}:*"
                keys = self.redis.keys(pattern)
                if keys:
                    self.redis.delete(*keys)
            else:
                with self.lock:
                    if user_id in self.refresh_tokens:
                        del self.refresh_tokens[user_id]
            return True
        except Exception as e:
            self.logger.error(f"撤销用户所有刷新令牌失败: {e}")
            return False

    def set_user_revocation_timestamp(self, user_id: str) -> None:
        import time as _time
        with self.lock:
            self._user_revocation_ts[user_id] = _time.time()

    def get_user_revocation_timestamp(self, user_id: str) -> Optional[float]:
        with self.lock:
            return self._user_revocation_ts.get(user_id)

    def is_user_token_revoked(self, user_id: str, token_iat: float) -> bool:
        rev_ts = self.get_user_revocation_timestamp(user_id)
        if rev_ts is None:
            return False
        return token_iat < rev_ts

    def cleanup_expired_blacklist(self) -> int:
        """清理过期的黑名单"""
        count = 0
        if not self.redis:
            with self.lock:
                expired = [jti for jti, exp in self.blacklist.items() if exp <= time.time()]
                for jti in expired:
                    del self.blacklist[jti]
                    count += 1
        return count

    def cleanup_expired_refresh_tokens(self) -> int:
        """清理过期的刷新令牌"""
        count = 0
        if not self.redis:
            with self.lock:
                for user_id in list(self.refresh_tokens.keys()):
                    expired = [jti for jti, data in self.refresh_tokens[user_id].items() if data.expires_at <= time.time()]
                    for jti in expired:
                        del self.refresh_tokens[user_id][jti]
                        count += 1
                    if not self.refresh_tokens[user_id]:
                        del self.refresh_tokens[user_id]
        return count

    def track_session(self, user_id: str, session_id: str, context: Any, max_sessions: int, reject_ip_change: bool) -> Tuple[bool, Optional[str]]:
        """跟踪会话 - 实现并发会话限制"""
        if max_sessions <= 0:
            return True, None

        try:
            if self.redis:
                redis_key = f"{self.config.redis_prefix_refresh_token}sessions:{user_id}"
                sessions = {}
                data = self.redis.get(redis_key)
                if data:
                    sessions = _json.loads(data)

                now = time.time()
                active = {sid: info for sid, info in sessions.items()
                          if info.get("expires_at", 0) > now}

                if session_id not in active:
                    if len(active) >= max_sessions:
                        oldest_sid = min(active, key=lambda s: active[s].get("created_at", 0))
                        evicted = active.pop(oldest_sid)
                        ttl = max(1, int(evicted.get("expires_at", now + 3600) - now))
                        self.redis.setex(redis_key, ttl, _json.dumps(active))
                        return True, oldest_sid

                    active[session_id] = {
                        "created_at": now,
                        "expires_at": now + 86400,
                        "ip": getattr(context, "ip_address", None) if context else None,
                    }
                    ttl = 86400
                    self.redis.setex(redis_key, ttl, _json.dumps(active))
                return True, None
            else:
                with self.lock:
                    if not hasattr(self, '_user_sessions'):
                        self._user_sessions: Dict[str, Dict[str, Dict]] = {}

                    if user_id not in self._user_sessions:
                        self._user_sessions[user_id] = {}

                    now = time.time()
                    active = {sid: info for sid, info in self._user_sessions[user_id].items()
                              if info.get("expires_at", 0) > now}
                    self._user_sessions[user_id] = active

                    if session_id not in active:
                        if len(active) >= max_sessions:
                            oldest_sid = min(active, key=lambda s: active[s].get("created_at", 0))
                            evicted = active.pop(oldest_sid)
                            return True, oldest_sid

                        active[session_id] = {
                            "created_at": now,
                            "expires_at": now + 86400,
                            "ip": getattr(context, "ip_address", None) if context else None,
                        }
                    return True, None
        except Exception as e:
            self.logger.error(f"Failed to track session: {e}")
            return True, None

    async def aadd_to_blacklist(self, jti: str, exp: int) -> bool:
        """异步将令牌加入黑名单"""
        if self.redis:
            try:
                redis_key = f"{self.config.redis_prefix_blacklist}{jti}"
                ttl = max(1, exp - int(time.time()))
                await self.redis.set(redis_key, "1", ex=ttl)
                return True
            except Exception as e:
                self.logger.error(f"异步加入黑名单失败: {e}")
                return False
        import asyncio
        return await asyncio.get_running_loop().run_in_executor(
            None, self.add_to_blacklist, jti, exp
        )

    async def ais_blacklisted(self, jti: Optional[str]) -> bool:
        if not jti:
            return False
        if self.redis:
            try:
                redis_key = f"{self.config.redis_prefix_blacklist}{jti}"
                return bool(await self.redis.exists(redis_key))
            except Exception as e:
                self.logger.error(f"异步检查黑名单失败: {e}")
                return True
        import asyncio
        return await asyncio.get_running_loop().run_in_executor(
            None, self.is_blacklisted, jti
        )

    async def astore_refresh_token(self, user_id: str, jti: str, expires_at: int, context: Any, max_usage: int = 10) -> bool:
        """异步存储刷新令牌"""
        if self.redis:
            try:
                token_data = RefreshTokenData(
                    jti=jti, created_at=int(time.time()), expires_at=expires_at,
                    max_usage=max_usage,
                    device_fingerprint=getattr(context, "device_fingerprint", None),
                    ip_address=getattr(context, "ip_address", None)
                )
                redis_key = f"{self.config.redis_prefix_refresh_token}{user_id}:{jti}"
                ttl = max(1, expires_at - int(time.time()))
                await self.redis.set(redis_key, _json.dumps(token_data.to_dict()), ex=ttl)
                return True
            except Exception as e:
                self.logger.error(f"异步存储刷新令牌失败: {e}")
                return False
        import asyncio
        return await asyncio.get_running_loop().run_in_executor(
            None, self.store_refresh_token, user_id, jti, expires_at, context, max_usage
        )

    async def arevoke_refresh_token(self, user_id: str, jti: str) -> bool:
        """异步撤销刷新令牌"""
        if self.redis:
            try:
                redis_key = f"{self.config.redis_prefix_refresh_token}{user_id}:{jti}"
                await self.redis.delete(redis_key)
                return True
            except Exception as e:
                self.logger.error(f"Async refresh token revoke failed: {e}")
                return False
        import asyncio
        return await asyncio.get_running_loop().run_in_executor(
            None, self.revoke_refresh_token, user_id, jti
        )


__all__ = [
    'RefreshTokenData',
    'TokenStore',
]
