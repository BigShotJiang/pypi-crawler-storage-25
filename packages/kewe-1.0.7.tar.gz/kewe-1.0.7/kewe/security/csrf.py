#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.security.csrf - CSRF protection middleware and token management
"""

import hmac
import secrets
import hashlib
import asyncio
from typing import Optional, Dict, Any
from datetime import datetime, timedelta, timezone

from kewe.request import Request
from kewe.response import Response
import logging

logger = logging.getLogger(__name__)


class CSRFProtection:
    """
    CSRF保护类
    
    生成和验证CSRF令牌，防止跨站请求伪造攻击
    """
    
    def __init__(
        self,
        secret_key: str,
        token_name: str = "csrf_token",
        header_name: str = "X-CSRFToken",
        cookie_name: str = "_csrf_token",
        max_age: int = 3600,
        samesite: str = "lax"
    ):
        self.secret_key = secret_key
        self.token_name = token_name
        self.header_name = header_name
        self.cookie_name = cookie_name
        self.max_age = max_age
        self.samesite = samesite.lower()
        if self.samesite not in ("strict", "lax", "none"):
            raise ValueError(f"Invalid samesite value: {self.samesite!r}. Must be 'strict', 'lax', or 'none'")
        if self.samesite == "none":
            import warnings
            warnings.warn("CSRF cookie samesite='none' requires secure=True for browser compatibility")
    
    def generate_token(self, request: Request = None, session_id: str = None) -> str:
        if session_id is not None and request is None:
            sid = session_id
        elif request is not None:
            sid = self._get_session_id(request)
        else:
            sid = "anonymous"
        timestamp = int(datetime.now(timezone.utc).timestamp())
        
        random_value = secrets.token_hex(16)
        
        data = f"{sid}:{timestamp}:{random_value}"
        
        signature = self._sign(data)
        
        token = f"{timestamp}:{random_value}:{signature}"
        
        return token
    
    def validate_token(self, request: Any = None, token: Optional[str] = None) -> bool:
        """验证CSRF令牌

        Args:
            request: 请求对象（用于从header/cookie中提取token并验证origin）
            token: 直接传入的token字符串（与request互斥，优先使用token参数）

        Returns:
            是否验证通过
        """
        if isinstance(request, str):
            token = request
            request = None

        if token is not None:
            return self._verify_token_standalone(token)

        if request is not None:
            if not self._validate_origin(request):
                return False
            submitted_token = self._get_token_sync(request)
            if not submitted_token:
                return False
            return self._verify_token(submitted_token, request)

        return False

    async def validate_token_async(self, request: Request) -> bool:
        if not self._validate_origin(request):
            return False
        submitted_token = await self._get_token(request)
        if not submitted_token:
            return False
        return self._verify_token(submitted_token, request)

    def _verify_token(self, submitted_token: str, request: Request) -> bool:
        try:
            parts = submitted_token.split(":", 2)
            if len(parts) != 3:
                return False
            timestamp_str, random_value, signature = parts
            timestamp = int(timestamp_str)

            if datetime.now(timezone.utc).timestamp() - timestamp > self.max_age:
                return False

            session_id = self._get_session_id(request)
            data = f"{session_id}:{timestamp}:{random_value}"
            expected_signature = self._sign(data)

            if not secrets.compare_digest(signature, expected_signature):
                return False
        except (ValueError, IndexError):
            return False

        cookie_token = request.get_cookie(self.cookie_name)
        if not cookie_token:
            return False
        if not secrets.compare_digest(submitted_token, cookie_token):
            return False

        return True

    def _verify_token_standalone(self, submitted_token: str) -> bool:
        """验证token（无需request对象，仅验证签名和时效性）"""
        try:
            parts = submitted_token.split(":", 2)
            if len(parts) != 3:
                return False
            timestamp_str, random_value, signature = parts
            timestamp = int(timestamp_str)

            if datetime.now(timezone.utc).timestamp() - timestamp > self.max_age:
                return False

            data = f"anonymous:{timestamp}:{random_value}"
            expected_signature = self._sign(data)

            if not secrets.compare_digest(signature, expected_signature):
                return False
        except (ValueError, IndexError):
            return False

        return True
    
    def _sign(self, data: str) -> str:
        return hmac.new(
            self.secret_key.encode('utf-8'),
            data.encode('utf-8'),
            hashlib.sha256
        ).hexdigest()
    
    def _validate_origin(self, request: Request) -> bool:
        origin = request.headers.get('origin')
        referer = request.headers.get('referer')
        host = request.headers.get('host')

        if not host:
            return False

        if origin:
            from urllib.parse import urlparse
            try:
                parsed = urlparse(origin)
                if parsed.netloc != host:
                    return False
            except Exception:
                return False
            return True

        if referer:
            from urllib.parse import urlparse
            try:
                parsed = urlparse(referer)
                if parsed.netloc != host:
                    return False
            except Exception:
                return False
            return True

        return False
    
    def _get_session_id(self, request: Request) -> str:
        if hasattr(request, 'session') and request.session is not None and 'id' in request.session:
            return request.session['id']
        
        if hasattr(request, 'cookies'):
            session_cookie = request.cookies.get('session_id') or request.cookies.get('sid')
            if session_cookie:
                return session_cookie
            csrf_secret = request.cookies.get('_csrf_secret')
            if csrf_secret:
                return csrf_secret

        fallback_parts = []
        if hasattr(request, 'client_ip') and request.client_ip:
            fallback_parts.append(request.client_ip)
        user_agent = request.headers.get('user-agent', '')
        if user_agent:
            fallback_parts.append(user_agent)
        if fallback_parts:
            return hashlib.sha256(":".join(fallback_parts).encode('utf-8')).hexdigest()[:32]

        return secrets.token_hex(16)
    
    def _get_token_sync(self, request: Request) -> Optional[str]:
        if self.header_name.lower() in request.headers:
            return request.headers[self.header_name.lower()]
        
        token = request.get(self.token_name)
        if token:
            return token
        
        token = request.get_cookie(self.cookie_name)
        if token:
            return token
        
        if hasattr(request, '_form') and request._form is not None:
            if hasattr(request._form, 'get'):
                token = request._form.get(self.token_name)
                if token:
                    return token
        
        return None

    async def _get_token(self, request: Request) -> Optional[str]:
        if self.header_name.lower() in request.headers:
            return request.headers[self.header_name.lower()]
        
        if hasattr(request, 'form'):
            try:
                form_data = request.form
                if asyncio.iscoroutine(form_data):
                    form_data = await form_data
                if form_data and hasattr(form_data, 'get'):
                    token = form_data.get(self.token_name)
                    if token:
                        return token
            except Exception:
                logger.debug("Non-critical operation failed", exc_info=True)
        
        token = request.get(self.token_name)
        if token:
            return token
        
        token = request.get_cookie(self.cookie_name)
        if token:
            return token
        
        return None
    
    def set_token_cookie(self, response: Response, request: Request) -> Response:
        session_id = self._get_session_id(request)
        if not session_id:
            csrf_secret = secrets.token_hex(16)
            response.set_cookie(
                '_csrf_secret',
                csrf_secret,
                max_age=self.max_age,
                httponly=True,
                samesite=self.samesite,
                secure=True
            )
        
        token = self.generate_token(request)
        response.set_cookie(
            self.cookie_name,
            token,
            max_age=self.max_age,
            httponly=False,
            samesite=self.samesite,
            secure=True
        )
        response.headers["X-CSRF-Token"] = token
        return response
    
    def get_token(self, request: Request) -> str:
        """
        获取CSRF令牌，如果不存在则生成新的
        
        Args:
            request: 请求对象
            
        Returns:
            CSRF令牌
        """
        # 尝试从Cookie获取
        token = request.get_cookie(self.cookie_name)
        if token and self.validate_token(request):
            return token
        
        # 生成新令牌
        return self.generate_token(request)


class CSRFMiddleware:
    """
    CSRF中间件
    
    自动为请求验证CSRF令牌
    """
    
    def __init__(
        self,
        secret_key: str,
        excluded_methods: list = None,
        excluded_paths: list = None,
        **csrf_kwargs
    ):
        """
        初始化CSRF中间件
        
        Args:
            secret_key: 用于签名CSRF令牌的密钥
            excluded_methods: 不需要CSRF验证的HTTP方法
            excluded_paths: 不需要CSRF验证的路径
            **csrf_kwargs: 传递给CSRFProtection的其他参数
        """
        self.csrf = CSRFProtection(secret_key, **csrf_kwargs)
        self.excluded_methods = excluded_methods or ["GET", "HEAD", "OPTIONS", "TRACE"]
        self.excluded_paths = excluded_paths or []
    
    async def __call__(self, request: Request, call_next=None):
        if request.method in self.excluded_methods:
            if call_next:
                return await call_next(request)
            return True
        
        for path in self.excluded_paths:
            if request.path.startswith(path):
                if call_next:
                    return await call_next(request)
                return True
        
        handler = getattr(request, '_route_handler', None)
        if handler and getattr(handler, '_csrf_exempt', False):
            if call_next:
                return await call_next(request)
            return True
        
        if not await self.csrf.validate_token_async(request):
            from kewe.errors.exceptions import Forbidden
            raise Forbidden("CSRF token validation failed")
        
        if call_next:
            response = await call_next(request)
            await self.response(request, response)
            return response
        return True
    
    async def response(self, request: Request, response: Response):
        """
        响应中间件，设置CSRF令牌到Cookie
        
        Args:
            request: 请求对象
            response: 响应对象
        """
        self.csrf.set_token_cookie(response, request)
        return response


# 便捷函数
def csrf_protect(secret_key: str, **kwargs):
    """
    创建CSRF中间件
    
    Args:
        secret_key: 用于签名CSRF令牌的密钥
        **kwargs: 传递给CSRFProtection的其他参数
        
    Returns:
        CSRFMiddleware实例
    """
    return CSRFMiddleware(secret_key, **kwargs)


def get_csrf_token(request: Request, secret_key: str, **kwargs) -> str:
    """
    获取CSRF令牌
    
    Args:
        request: 请求对象
        secret_key: 用于签名CSRF令牌的密钥
        **kwargs: 传递给CSRFProtection的其他参数
        
    Returns:
        CSRF令牌
    """
    csrf = CSRFProtection(secret_key, **kwargs)
    return csrf.get_token(request)


def set_csrf_cookie(response: Response, request: Request, secret_key: str, **kwargs) -> Response:
    """
    设置CSRF令牌到Cookie
    
    Args:
        response: 响应对象
        request: 请求对象
        secret_key: 用于签名CSRF令牌的密钥
        **kwargs: 传递给CSRFProtection的其他参数
        
    Returns:
        更新后的响应对象
    """
    csrf = CSRFProtection(secret_key, **kwargs)
    return csrf.set_token_cookie(response, request)


def csrf_exempt(func):
    """标记视图函数免除CSRF验证
    
    使用示例:
        @app.post("/webhook")
        @csrf_exempt
        async def webhook(request):
            return json({"ok": True})
    """
    func._csrf_exempt = True
    return func


__all__ = [
    'CSRFProtection',
    'CSRFMiddleware',
    'csrf_protect',
    'get_csrf_token',
    'set_csrf_cookie',
    'csrf_exempt',
]
