#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.security.auth - Authentication manager with JWT, session, OAuth2, and API key strategies
"""

from __future__ import annotations

import asyncio
import base64
import contextvars
import hashlib
import hmac
from kewe.utils.compat import json
import logging
import secrets
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from enum import Enum, auto
from functools import wraps
from typing import (
    Any,
    Awaitable,
    Callable,
    Coroutine,
    Dict,
    List,
    Optional,
    Protocol,
    Set,
    Tuple,
    TypeVar,
    Union,
    runtime_checkable,
)

try:
    from kewe.security.jwt import JWTAuthManager, TokenPayload, SecurityContext
    from kewe.security.rbac_manager import RBACManager, Permission, Role
    HAS_ROUTINE = True
except ImportError:
    HAS_ROUTINE = False

logger = logging.getLogger(__name__)

from kewe.errors.exceptions import HTTPException
from kewe.request import Request
from kewe.response import Response
from kewe.base.context import g
from kewe.cookies.session import SessionMiddleware

if not HAS_ROUTINE:
    try:
        from kewe.security.rbac_manager import RBACManager, Permission, Role
        HAS_ROUTINE = True
    except ImportError:
        RBACManager = None
        Permission = None
        Role = None

# ============================================================================
# Constants
# ============================================================================

DEFAULT_TOKEN_EXPIRY = 3600  # 1 hour
DEFAULT_REFRESH_EXPIRY = 86400 * 7  # 7 days
DEFAULT_SESSION_EXPIRY = 86400  # 24 hours
DEFAULT_API_KEY_HEADER = "X-API-Key"
DEFAULT_AUTH_HEADER = "Authorization"
DEFAULT_AUTH_SCHEME = "Bearer"


# ============================================================================
# Enums
# ============================================================================

class AuthStrategy(Enum):
    """Authentication strategies supported by the framework."""
    JWT = auto()
    SESSION = auto()
    API_KEY = auto()
    OAUTH2 = auto()


class AuthError(Enum):
    """Authentication error types."""
    INVALID_CREDENTIALS = "invalid_credentials"
    TOKEN_EXPIRED = "token_expired"
    TOKEN_INVALID = "token_invalid"
    TOKEN_REVOKED = "token_revoked"
    INSUFFICIENT_PERMISSIONS = "insufficient_permissions"
    RATE_LIMITED = "rate_limited"
    SESSION_INVALID = "session_invalid"
    API_KEY_INVALID = "api_key_invalid"
    OAUTH2_ERROR = "oauth2_error"


# ============================================================================
# Exceptions
# ============================================================================

class AuthenticationError(HTTPException):
    """Base authentication exception."""

    def __init__(
        self,
        message: str,
        error_type: AuthError = AuthError.INVALID_CREDENTIALS,
        status_code: int = 401,
        headers: Optional[Dict[str, str]] = None,
    ):
        super().__init__(status_code=status_code, detail=message, headers=headers)
        self.error_type = error_type


class AuthorizationError(HTTPException):
    """Authorization (permission) exception."""

    def __init__(
        self,
        message: str = "Insufficient permissions",
        required_permissions: Optional[List[str]] = None,
        status_code: int = 403,
    ):
        super().__init__(status_code=status_code, detail=message)
        self.required_permissions = required_permissions or []


# ============================================================================
# Data Classes
# ============================================================================

@dataclass
class User:
    """User model for authentication."""
    id: str
    username: str
    email: Optional[str] = None
    roles: List[str] = field(default_factory=list)
    permissions: List[str] = field(default_factory=list)
    is_active: bool = True
    is_verified: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: Optional[datetime] = None
    last_login: Optional[datetime] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert user to dictionary."""
        return {
            "id": self.id,
            "username": self.username,
            "email": self.email,
            "roles": self.roles,
            "permissions": self.permissions,
            "is_active": self.is_active,
            "is_verified": self.is_verified,
            "metadata": self.metadata,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "last_login": self.last_login.isoformat() if self.last_login else None,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "User":
        """Create user from dictionary."""
        return cls(
            id=data["id"],
            username=data["username"],
            email=data.get("email"),
            roles=data.get("roles", []),
            permissions=data.get("permissions", []),
            is_active=data.get("is_active", True),
            is_verified=data.get("is_verified", False),
            metadata=data.get("metadata", {}),
            created_at=datetime.fromisoformat(data["created_at"]) if data.get("created_at") else None,
            last_login=datetime.fromisoformat(data["last_login"]) if data.get("last_login") else None,
        )


@dataclass
class AuthToken:
    """Authentication token model."""
    access_token: str
    refresh_token: Optional[str] = None
    token_type: str = "bearer"
    expires_in: int = DEFAULT_TOKEN_EXPIRY
    scope: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert token to dictionary."""
        result = {
            "access_token": self.access_token,
            "token_type": self.token_type,
            "expires_in": self.expires_in,
        }
        if self.refresh_token:
            result["refresh_token"] = self.refresh_token
        if self.scope:
            result["scope"] = self.scope
        return result


@dataclass
class APIKey:
    """API Key model."""
    key: str
    name: str
    user_id: str
    permissions: List[str] = field(default_factory=list)
    is_active: bool = True
    expires_at: Optional[datetime] = None
    last_used_at: Optional[datetime] = None
    rate_limit: Optional[int] = None  # requests per minute
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: Optional[datetime] = None


@dataclass
class OAuth2Config:
    """OAuth2 provider configuration."""
    provider: str
    client_id: str
    client_secret: str
    authorize_url: str
    token_url: str
    user_info_url: str
    scope: str = "openid email profile"
    redirect_uri: Optional[str] = None


# ============================================================================
# Protocols
# ============================================================================

@runtime_checkable
class UserStore(Protocol):
    """Protocol for user storage backends."""

    async def get_user_by_id(self, user_id: str) -> Optional[User]:
        """Get user by ID."""
        ...

    async def get_user_by_username(self, username: str) -> Optional[User]:
        """Get user by username."""
        ...

    async def get_user_by_email(self, email: str) -> Optional[User]:
        """Get user by email."""
        ...

    async def create_user(self, user: User) -> User:
        """Create a new user."""
        ...

    async def update_user(self, user: User) -> User:
        """Update an existing user."""
        ...

    async def verify_password(self, username: str, password: str) -> bool:
        """Verify user password."""
        ...


@runtime_checkable
class TokenStoreProtocol(Protocol):
    """Protocol for token storage backends."""

    async def store_token(self, token_id: str, user_id: str, expires_at: datetime) -> None:
        ...

    async def revoke_token(self, token_id: str) -> None:
        ...

    async def is_token_revoked(self, token_id: str) -> bool:
        ...

    async def cleanup_expired_tokens(self) -> None:
        ...


# ============================================================================
# In-Memory Stores (Default implementations)
# ============================================================================

class InMemoryUserStore:
    """In-memory user store for development/testing."""

    def __init__(self):
        self._users: Dict[str, User] = {}
        self._username_index: Dict[str, str] = {}
        self._email_index: Dict[str, str] = {}
        self._passwords: Dict[str, str] = {}  # username -> hashed_password

    async def get_user_by_id(self, user_id: str) -> Optional[User]:
        return self._users.get(user_id)

    async def get_user_by_username(self, username: str) -> Optional[User]:
        user_id = self._username_index.get(username)
        return self._users.get(user_id) if user_id else None

    async def get_user_by_email(self, email: str) -> Optional[User]:
        user_id = self._email_index.get(email)
        return self._users.get(user_id) if user_id else None

    async def create_user(self, user: User) -> User:
        if user.id in self._users:
            raise ValueError(f"User with ID {user.id} already exists")
        if user.username in self._username_index:
            raise ValueError(f"Username {user.username} already exists")
        if user.email and user.email in self._email_index:
            raise ValueError(f"Email {user.email} already exists")

        self._users[user.id] = user
        self._username_index[user.username] = user.id
        if user.email:
            self._email_index[user.email] = user.id
        return user

    async def update_user(self, user: User) -> User:
        if user.id not in self._users:
            raise ValueError(f"User with ID {user.id} not found")
        old_user = self._users[user.id]
        if old_user.username != user.username:
            self._username_index.pop(old_user.username, None)
            self._username_index[user.username] = user.id
        if old_user.email != user.email:
            if old_user.email:
                self._email_index.pop(old_user.email, None)
            if user.email:
                self._email_index[user.email] = user.id
        self._users[user.id] = user
        return user

    async def verify_password(self, username: str, password: str) -> bool:
        stored_hash = self._passwords.get(username)
        if not stored_hash:
            return False
        return self._verify_hash(password, stored_hash)

    def set_password(self, username: str, password: str) -> None:
        """Set password for a user (for testing/development)."""
        self._passwords[username] = self._hash_password(password)

    def _hash_password(self, password: str) -> str:
        try:
            from kewe.security.password import generate_password_hash
            return generate_password_hash(password, scheme="pbkdf2")
        except ImportError:
            salt = secrets.token_hex(16)
            pwdhash = hashlib.pbkdf2_hmac('sha256', password.encode(), salt.encode(), 300000)
            return salt + pwdhash.hex()

    def _verify_hash(self, password: str, stored_hash: str) -> bool:
        try:
            from kewe.security.password import check_password_hash
            return check_password_hash(password, stored_hash)
        except ImportError:
            salt = stored_hash[:32]
            pwdhash = hashlib.pbkdf2_hmac('sha256', password.encode(), salt.encode(), 300000)
            return secrets.compare_digest(pwdhash.hex(), stored_hash[32:])


class InMemoryTokenStore:

    def __init__(self):
        self._tokens: Dict[str, Dict[str, Any]] = {}
        self._lock: asyncio.Lock = asyncio.Lock()

    def _get_lock(self) -> asyncio.Lock:
        return self._lock

    async def store_token(self, token_id: str, user_id: str, expires_at: datetime) -> None:
        async with self._get_lock():
            self._tokens[token_id] = {
                "user_id": user_id,
                "expires_at": expires_at,
                "revoked": False,
            }

    async def revoke_token(self, token_id: str) -> None:
        async with self._get_lock():
            if token_id in self._tokens:
                self._tokens[token_id]["revoked"] = True

    async def is_token_revoked(self, token_id: str) -> bool:
        async with self._get_lock():
            token = self._tokens.get(token_id)
            if not token:
                return False
            if token["revoked"]:
                return True
            if datetime.now(timezone.utc) > token["expires_at"]:
                return True
            return False

    async def cleanup_expired_tokens(self) -> None:
        async with self._get_lock():
            now = datetime.now(timezone.utc)
            expired = [
                tid for tid, t in self._tokens.items()
                if t["revoked"] or now > t["expires_at"]
            ]
            for tid in expired:
                del self._tokens[tid]


# ============================================================================
# JWT Authentication
# ============================================================================

class JWTAuthenticator:
    """JWT authentication handler."""

    def __init__(
        self,
        secret_key: str,
        algorithm: str = "HS256",
        access_token_expire: int = DEFAULT_TOKEN_EXPIRY,
        refresh_token_expire: int = DEFAULT_REFRESH_EXPIRY,
        token_store: Optional[TokenStoreProtocol] = None,
        user_store: Any = None,
    ):
        self.secret_key = secret_key
        self.algorithm = algorithm
        self.access_token_expire = access_token_expire
        self.refresh_token_expire = refresh_token_expire
        self.token_store = token_store or InMemoryTokenStore()
        self.user_store = user_store

        # Try to use existing JWT manager from routine
        if HAS_ROUTINE:
            try:
                self._jwt_manager = JWTAuthManager(redis_client=None)
            except Exception:
                self._jwt_manager = None
        else:
            self._jwt_manager = None

    def _base64url_encode(self, data: bytes) -> str:
        """Base64 URL-safe encode."""
        return base64.urlsafe_b64encode(data).rstrip(b'=').decode('ascii')

    def _base64url_decode(self, data: str) -> bytes:
        """Base64 URL-safe decode."""
        padding = 4 - len(data) % 4
        if padding != 4:
            data += '=' * padding
        return base64.urlsafe_b64decode(data)

    def _create_token(
        self,
        user_id: str,
        token_type: str = "access",
        expires_delta: Optional[int] = None,
        token_data: Optional[Dict[str, Any]] = None,
        extra_claims: Optional[Dict[str, Any]] = None,
    ) -> str:
        """Create a JWT token - delegates to JWTAuthManager when available."""
        claims = extra_claims or token_data or {}
        if self._jwt_manager is not None:
            try:
                return self._jwt_manager.create_token(
                    user_id=user_id,
                    token_type=token_type,
                    expires_delta=expires_delta or self.access_token_expire,
                    extra_claims=claims,
                )
            except Exception as e:
                logger.warning(f"JWT manager create_token failed, falling back to local: {e}")

        try:
            from kewe.security.jwt import JWTEncoder
            now = datetime.now(timezone.utc)
            expires = now + timedelta(seconds=expires_delta or self.access_token_expire)
            payload = {
                "sub": user_id,
                "iat": int(now.timestamp()),
                "exp": int(expires.timestamp()),
                "type": token_type,
                "jti": str(uuid.uuid4()),
            }
            payload.update(claims)
            return JWTEncoder.encode(payload, self.secret_key, algorithm=self.algorithm)
        except ImportError:
            now = datetime.now(timezone.utc)
            expires = now + timedelta(seconds=expires_delta or self.access_token_expire)
            header = {"alg": self.algorithm, "typ": "JWT"}
            payload = {
                "sub": user_id,
                "iat": int(now.timestamp()),
                "exp": int(expires.timestamp()),
                "type": token_type,
                "jti": str(uuid.uuid4()),
            }
            payload.update(claims)
            header_b64 = self._base64url_encode(json.dumps(header, separators=(',', ':')).encode())
            payload_b64 = self._base64url_encode(json.dumps(payload, separators=(',', ':')).encode())
            signature_input = f"{header_b64}.{payload_b64}"
            alg_map = {
                'HS256': hashlib.sha256,
                'HS384': hashlib.sha384,
                'HS512': hashlib.sha512,
            }
            hash_func = alg_map.get(self.algorithm.upper(), hashlib.sha256)
            signature = hmac.new(
                self.secret_key.encode(),
                signature_input.encode(),
                hash_func,
            ).digest()
            signature_b64 = self._base64url_encode(signature)
            return f"{signature_input}.{signature_b64}"

    def _decode_token(self, token: str) -> Dict[str, Any]:
        """Decode and verify a JWT token - delegates to JWTAuthManager when available."""
        if self._jwt_manager is not None:
            try:
                return self._jwt_manager.decode_token(token)
            except Exception as e:
                logger.warning(f"JWT manager decode_token failed, falling back to local: {e}")

        try:
            from kewe.security.jwt import JWTEncoder
            return JWTEncoder.decode(token, self.secret_key, algorithm=self.algorithm)
        except ImportError:
            pass

        try:
            parts = token.split('.')
            if len(parts) != 3:
                raise AuthenticationError("Invalid token format", AuthError.TOKEN_INVALID)

            payload_json = self._base64url_decode(parts[1])
            payload = json.loads(payload_json)

            exp = payload.get("exp")
            leeway = getattr(self, '_token_leeway', 10)
            if exp and datetime.now(timezone.utc).timestamp() > exp + leeway:
                raise AuthenticationError("Token has expired", AuthError.TOKEN_EXPIRED)

            signature_input = f"{parts[0]}.{parts[1]}"
            alg_map = {
                'HS256': hashlib.sha256,
                'HS384': hashlib.sha384,
                'HS512': hashlib.sha512,
            }
            hash_func = alg_map.get(self.algorithm.upper(), hashlib.sha256)
            expected_signature = hmac.new(
                self.secret_key.encode(),
                signature_input.encode(),
                hash_func,
            ).digest()

            try:
                provided_sig = self._base64url_decode(parts[2])
                if not hmac.compare_digest(provided_sig, expected_signature):
                    raise AuthenticationError("Invalid token signature", AuthError.TOKEN_INVALID)
            except AuthenticationError:
                raise
            except Exception:
                raise AuthenticationError("Invalid token signature", AuthError.TOKEN_INVALID)

            return payload

        except json.JSONDecodeError:
            raise AuthenticationError("Invalid token payload", AuthError.TOKEN_INVALID)
        except AuthenticationError:
            raise
        except Exception:
            raise AuthenticationError("Token validation failed", AuthError.TOKEN_INVALID)

    async def create_tokens(
        self,
        user: User,
        extra_claims: Optional[Dict[str, Any]] = None,
    ) -> AuthToken:
        """Create access and refresh tokens for a user."""
        claims = {
            "username": user.username,
            "roles": user.roles,
            "permissions": user.permissions,
        }
        if extra_claims:
            claims.update(extra_claims)

        access_token = self._create_token(
            user.id,
            token_type="access",
            expires_delta=self.access_token_expire,
            extra_claims=claims,
        )

        refresh_token = self._create_token(
            user.id,
            token_type="refresh",
            expires_delta=self.refresh_token_expire,
        )

        # Store tokens
        access_payload = self._decode_token(access_token)
        refresh_payload = self._decode_token(refresh_token)

        await self.token_store.store_token(
            access_payload["jti"],
            user.id,
            datetime.fromtimestamp(access_payload["exp"], tz=timezone.utc),
        )
        await self.token_store.store_token(
            refresh_payload["jti"],
            user.id,
            datetime.fromtimestamp(refresh_payload["exp"], tz=timezone.utc),
        )

        return AuthToken(
            access_token=access_token,
            refresh_token=refresh_token,
            token_type="bearer",
            expires_in=self.access_token_expire,
        )

    async def refresh_access_token(self, refresh_token: str) -> AuthToken:
        payload = self._decode_token(refresh_token)

        if payload.get("type") != "refresh":
            raise AuthenticationError("Invalid token type", AuthError.TOKEN_INVALID)

        if await self.token_store.is_token_revoked(payload["jti"]):
            raise AuthenticationError("Token has been revoked", AuthError.TOKEN_REVOKED)

        old_jti = payload["jti"]
        user_id = payload["sub"]

        user = await self.user_store.get_user_by_id(user_id) if self.user_store else None
        if user is None:
            user = User(
                id=user_id,
                username=payload.get("username", "unknown"),
                roles=payload.get("roles", []),
                permissions=payload.get("permissions", []),
            )

        new_tokens = await self.create_tokens(user)

        await self.token_store.revoke_token(old_jti)

        return new_tokens

    async def revoke_token(self, token: str) -> None:
        """Revoke a token."""
        payload = self._decode_token(token)
        await self.token_store.revoke_token(payload["jti"])

    async def authenticate(self, token: str) -> Dict[str, Any]:
        """Authenticate using JWT token."""
        payload = self._decode_token(token)

        if await self.token_store.is_token_revoked(payload["jti"]):
            raise AuthenticationError("Token has been revoked", AuthError.TOKEN_REVOKED)

        return payload


# ============================================================================
# Session Authentication
# ============================================================================

class SessionAuthenticator:
    """Session-based authentication handler."""

    def __init__(
        self,
        session_manager: "SessionManager",
        user_store: UserStore,
        session_key: str = "user_id",
    ):
        self.session_manager = session_manager
        self.user_store = user_store
        self.session_key = session_key

    async def login(self, request: Request, user: User) -> None:
        """Log in a user by storing user ID in session."""
        session = await self.session_manager.get_session(request)
        if hasattr(session, 'regenerate_id'):
            session.regenerate_id()
        session[self.session_key] = user.id
        session["authenticated_at"] = datetime.now(timezone.utc).isoformat()
        await self.session_manager.save_session(request, session)

    async def logout(self, request: Request) -> None:
        """Log out a user by clearing session."""
        session = await self.session_manager.get_session(request)
        if self.session_key in session:
            del session[self.session_key]
        await self.session_manager.save_session(request, session)

    async def authenticate(self, request: Request) -> Optional[User]:
        """Authenticate using session."""
        session = await self.session_manager.get_session(request)
        user_id = session.get(self.session_key)

        if not user_id:
            return None

        user = await self.user_store.get_user_by_id(user_id)
        if user and user.is_active:
            return user

        return None


# ============================================================================
# API Key Authentication
# ============================================================================

class APIKeyAuthenticator:
    """API Key authentication handler."""

    def __init__(
        self,
        user_store: UserStore,
        header_name: str = DEFAULT_API_KEY_HEADER,
        key_prefix: str = "kw_",
    ):
        self.user_store = user_store
        self.header_name = header_name
        self.key_prefix = key_prefix
        self._keys: Dict[str, APIKey] = {}
        self._user_keys: Dict[str, Set[str]] = {}
        self._lock: asyncio.Lock = asyncio.Lock()

    def _get_lock(self) -> asyncio.Lock:
        return self._lock

    def generate_key(self, name: str, user_id: str, permissions: Optional[List[str]] = None) -> APIKey:
        """Generate a new API key."""
        key_value = f"{self.key_prefix}{secrets.token_urlsafe(32)}"
        api_key = APIKey(
            key=key_value,
            name=name,
            user_id=user_id,
            permissions=permissions or [],
            created_at=datetime.now(timezone.utc),
        )
        return api_key

    async def store_key(self, api_key: APIKey) -> None:
        async with self._get_lock():
            key_hash = hashlib.sha256(api_key.key.encode()).hexdigest()
            api_key._key_hash = key_hash
            self._keys[key_hash] = api_key
            if api_key.user_id not in self._user_keys:
                self._user_keys[api_key.user_id] = set()
            self._user_keys[api_key.user_id].add(key_hash)

    async def revoke_key(self, key: str) -> None:
        async with self._get_lock():
            key_hash = hashlib.sha256(key.encode()).hexdigest()
            if key_hash in self._keys:
                api_key = self._keys[key_hash]
                api_key.is_active = False
                self._user_keys[api_key.user_id].discard(key_hash)

    async def get_user_keys(self, user_id: str) -> List[APIKey]:
        """Get all API keys for a user."""
        async with self._get_lock():
            key_ids = self._user_keys.get(user_id, set())
            return [self._keys[k] for k in key_ids if k in self._keys]

    async def authenticate(self, request: Request) -> Optional[User]:
        api_key_value = request.headers.get(self.header_name)
        if not api_key_value:
            return None

        key_hash = hashlib.sha256(api_key_value.encode()).hexdigest()
        async with self._get_lock():
            api_key = self._keys.get(key_hash)

        if not api_key:
            raise AuthenticationError("Invalid API key", AuthError.API_KEY_INVALID)

        if not api_key.is_active:
            raise AuthenticationError("API key has been revoked", AuthError.API_KEY_INVALID)

        if api_key.expires_at and datetime.now(timezone.utc) > api_key.expires_at:
            raise AuthenticationError("API key has expired", AuthError.API_KEY_INVALID)

        # Update last used
        api_key.last_used_at = datetime.now(timezone.utc)

        # Get user
        user = await self.user_store.get_user_by_id(api_key.user_id)
        if not user or not user.is_active:
            raise AuthenticationError("User not found or inactive", AuthError.API_KEY_INVALID)

        return user


# ============================================================================
# OAuth2 Authentication
# ============================================================================

class OAuth2Authenticator:
    """OAuth2 authentication handler with PKCE support."""

    def __init__(self, config: OAuth2Config, enable_pkce: bool = True):
        self.config = config
        self.enable_pkce = enable_pkce
        self._states: Dict[str, Dict[str, Any]] = {}
        self._state_ttl = 600

    @staticmethod
    def generate_pkce_pair() -> tuple[str, str]:
        """Generate PKCE code_verifier and code_challenge pair.

        Returns:
            (code_verifier, code_challenge) tuple
        """
        code_verifier = secrets.token_urlsafe(64)
        digest = hashlib.sha256(code_verifier.encode('ascii')).digest()
        code_challenge = base64.urlsafe_b64encode(digest).rstrip(b'=').decode('ascii')
        return code_verifier, code_challenge

    def _cleanup_expired_states(self):
        now = datetime.now(timezone.utc) if hasattr(datetime, 'now') else datetime.now()
        expired = [k for k, v in list(self._states.items())
                   if (now - v.get("created_at", now)).total_seconds() > self._state_ttl]
        for k in expired:
            self._states.pop(k, None)

    def get_authorization_url(
        self,
        redirect_uri: Optional[str] = None,
        state: Optional[str] = None,
        code_challenge: Optional[str] = None,
    ) -> tuple[str, Optional[str]]:
        """Get OAuth2 authorization URL.

        Args:
            redirect_uri: Redirect URI after authorization
            state: CSRF state parameter (auto-generated if None)
            code_challenge: PKCE code_challenge (auto-generated if enable_pkce=True and None)

        Returns:
            (authorization_url, code_verifier) tuple. code_verifier is None when PKCE is disabled.
        """
        import urllib.parse
        self._cleanup_expired_states()

        state = state or secrets.token_urlsafe(32)
        redirect = redirect_uri or self.config.redirect_uri

        code_verifier = None
        if self.enable_pkce and code_challenge is None:
            code_verifier, code_challenge = self.generate_pkce_pair()

        state_data: Dict[str, Any] = {
            "created_at": datetime.now(timezone.utc),
            "redirect_uri": redirect,
        }
        if code_verifier is not None:
            state_data["code_verifier"] = code_verifier

        self._states[state] = state_data

        params = {
            "client_id": self.config.client_id,
            "response_type": "code",
            "scope": self.config.scope,
            "redirect_uri": redirect,
            "state": state,
        }
        if code_challenge is not None:
            params["code_challenge"] = code_challenge
            params["code_challenge_method"] = "S256"

        query = urllib.parse.urlencode(params)
        return f"{self.config.authorize_url}?{query}", code_verifier

    async def exchange_code(self, code: str, state: str) -> Dict[str, Any]:
        """Exchange authorization code for tokens."""
        try:
            import httpx
        except ImportError:
            raise ImportError(
                "httpx is required for OAuth2 token exchange. "
                "Install it with: pip install httpx"
            )

        if state not in self._states:
            raise AuthenticationError("Invalid state parameter", AuthError.OAUTH2_ERROR)

        state_data = self._states.pop(state)

        async with httpx.AsyncClient() as client:
            token_data = {
                "grant_type": "authorization_code",
                "code": code,
                "redirect_uri": state_data["redirect_uri"],
                "client_id": self.config.client_id,
                "client_secret": self.config.client_secret,
            }

            code_verifier = state_data.get("code_verifier")
            if code_verifier is not None:
                token_data["code_verifier"] = code_verifier

            response = await client.post(
                self.config.token_url,
                data=token_data,
                headers={"Accept": "application/json"},
            )
            if response.status_code != 200:
                raise AuthenticationError(
                    f"Token exchange failed: {response.status_code}",
                    AuthError.OAUTH2_ERROR,
                )
            tokens = response.json()

            access_token = tokens.get("access_token")
            if not access_token:
                raise AuthenticationError("No access token received", AuthError.OAUTH2_ERROR)

            response = await client.get(
                self.config.user_info_url,
                headers={
                    "Authorization": f"Bearer {access_token}",
                    "Accept": "application/json",
                },
            )
            if response.status_code != 200:
                raise AuthenticationError(
                    f"Failed to get user info: {response.status_code}",
                    AuthError.OAUTH2_ERROR,
                )
            user_info = response.json()

        return {
            "tokens": tokens,
            "user_info": user_info,
        }

    async def refresh_access_token(self, refresh_token: str) -> Dict[str, Any]:
        """使用refresh_token刷新access_token

        Args:
            refresh_token: OAuth2 refresh token

        Returns:
            包含新tokens的字典

        Raises:
            AuthenticationError: 刷新失败
        """
        try:
            import httpx
        except ImportError:
            raise ImportError(
                "httpx is required for OAuth2 token refresh. "
                "Install it with: pip install httpx"
            )

        async with httpx.AsyncClient() as client:
            token_data = {
                "grant_type": "refresh_token",
                "refresh_token": refresh_token,
                "client_id": self.config.client_id,
                "client_secret": self.config.client_secret,
            }

            response = await client.post(
                self.config.token_url,
                data=token_data,
                headers={"Accept": "application/json"},
            )

            if response.status_code != 200:
                raise AuthenticationError(
                    f"Token refresh failed: {response.status_code}",
                    AuthError.OAUTH2_ERROR,
                )

            new_tokens = response.json()

            if "access_token" not in new_tokens:
                raise AuthenticationError(
                    "No access token in refresh response",
                    AuthError.OAUTH2_ERROR,
                )

            return new_tokens

    async def revoke_token(self, token: str, token_type_hint: str = "access_token") -> bool:
        """撤销OAuth2令牌

        Args:
            token: 要撤销的令牌
            token_type_hint: 令牌类型提示 (access_token/refresh_token)

        Returns:
            是否撤销成功
        """
        revoke_url = getattr(self.config, 'revoke_url', None)
        if not revoke_url:
            return False

        try:
            import httpx
        except ImportError:
            return False

        try:
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    revoke_url,
                    data={
                        "token": token,
                        "token_type_hint": token_type_hint,
                        "client_id": self.config.client_id,
                        "client_secret": self.config.client_secret,
                    },
                    headers={"Accept": "application/json"},
                )
                return response.status_code in (200, 204)
        except Exception:
            return False

    async def refresh_with_rotation(self, refresh_token: str) -> Dict[str, Any]:
        """刷新令牌并旋转 refresh_token（安全最佳实践）

        每次使用 refresh_token 获取新 access_token 时，
        同时返回新的 refresh_token 并使旧的失效。

        Args:
            refresh_token: 当前 refresh_token

        Returns:
            包含新 access_token 和 refresh_token 的字典

        Raises:
            AuthenticationError: 刷新失败
        """
        new_tokens = await self.refresh_access_token(refresh_token)

        try:
            await self.revoke_token(refresh_token, token_type_hint="refresh_token")
        except Exception:
            logger.debug("Non-critical operation failed", exc_info=True)

        return new_tokens

    def validate_token_expiry(self, token_data: Dict[str, Any]) -> bool:
        """验证令牌是否过期

        Args:
            token_data: 令牌数据（包含 expires_in 或 expires_at）

        Returns:
            令牌是否仍然有效
        """
        if "expires_at" in token_data:
            return time.time() < token_data["expires_at"]
        if "expires_in" in token_data:
            return token_data["expires_in"] > 0
        return True


# ============================================================================
# Enhanced RBAC Manager
# ============================================================================

class EnhancedRBACManager(RBACManager):
    """Enhanced Role-Based Access Control manager - extends RBACManager with descriptions."""

    def __init__(self):
        super().__init__()
        self._role_descriptions: Dict[str, str] = {}
        self._permission_descriptions: Dict[str, str] = {}
        self._initialize_enhanced_defaults()

    def _initialize_enhanced_defaults(self) -> None:
        self._permission_descriptions = {
            "user:read": "Read user information",
            "user:write": "Create and update users",
            "user:delete": "Delete users",
            "content:read": "Read content",
            "content:write": "Create and update content",
            "content:delete": "Delete content",
            "content:publish": "Publish content",
            "system:read": "Read system information",
            "system:write": "Modify system settings",
            "system:admin": "Full system administration",
            "api:read": "Read API data",
            "api:write": "Write API data",
            "api:admin": "Administer API",
        }
        self._role_descriptions = {
            "guest": "Unauthenticated visitor",
            "user": "Standard authenticated user",
            "moderator": "Content moderator",
            "admin": "System administrator",
            "super_admin": "Super administrator with all permissions",
        }
        self.add_role("super_admin", set(self._permission_descriptions.keys()))

    def create_role(
        self,
        role_id: str,
        description: str,
        permissions: Set[str],
        inherits: Optional[Set[str]] = None,
    ) -> None:
        if role_id in self.role_permissions:
            raise ValueError(f"Role {role_id} already exists")
        self._role_descriptions[role_id] = description
        self.add_role(role_id, permissions)
        if inherits:
            self.role_hierarchy[role_id] = inherits

    def create_permission(self, permission_id: str, description: str) -> None:
        if permission_id in self._permission_descriptions:
            raise ValueError(f"Permission {permission_id} already exists")
        self._permission_descriptions[permission_id] = description

    def get_role_description(self, role_id: str) -> Optional[str]:
        return self._role_descriptions.get(role_id)

    def get_permission_description(self, permission_id: str) -> Optional[str]:
        return self._permission_descriptions.get(permission_id)


# ============================================================================
# Main Auth Manager
# ============================================================================

F = TypeVar("F", bound=Callable[..., Awaitable[Any]])


class AuthManager:
    """
    Main authentication manager for Kewe framework.

    Supports multiple authentication strategies:
    - JWT: Token-based authentication
    - Session: Cookie-based session authentication
    - API Key: Header-based API key authentication
    - OAuth2: Third-party OAuth2 provider authentication

    Usage:
        from kewe import Kewe
        from kewe.security.auth import AuthManager, login_required

        app = Kewe()
        auth = AuthManager(app, secret_key="your-secret")

        @app.route("/login", methods=["POST"])
        async def login(request):
            # Validate credentials...
            user = User(id="1", username="john", roles=["user"])
            tokens = await auth.create_tokens(user)
            return tokens.to_dict()

        @app.route("/protected")
        @auth.login_required
        async def protected(request):
            user = auth.current_user
            return {"message": f"Hello, {user.username}!"}
    """

    def __init__(
        self,
        app: Optional[Any] = None,
        secret_key: Optional[str] = None,
        user_store: Optional[UserStore] = None,
        token_store: Optional[TokenStoreProtocol] = None,
        session_manager: Optional["SessionManager"] = None,
        jwt_config: Optional[Dict[str, Any]] = None,
        enable_jwt: bool = True,
        enable_session: bool = True,
        enable_api_key: bool = True,
    ):
        if secret_key is None and enable_jwt:
            secret_key = secrets.token_urlsafe(48)
            import warnings
            warnings.warn(
                "No secret_key provided to AuthManager. A random key has been generated, "
                "but tokens will not persist across restarts. "
                "Please provide a stable secret_key in production.",
                RuntimeWarning,
                stacklevel=2,
            )
        self.secret_key = secret_key or ""
        self.user_store = user_store or InMemoryUserStore()
        self.token_store = token_store or InMemoryTokenStore()
        self.session_manager = session_manager

        # Initialize authenticators
        self.jwt_auth: Optional[JWTAuthenticator] = None
        self.session_auth: Optional[SessionAuthenticator] = None
        self.api_key_auth: Optional[APIKeyAuthenticator] = None
        self.oauth2_auths: Dict[str, OAuth2Authenticator] = {}

        self.rbac = EnhancedRBACManager()

        self._current_user_var: contextvars.ContextVar[Optional[User]] = contextvars.ContextVar('current_user', default=None)
        self._current_auth_strategy_var: contextvars.ContextVar[Optional[AuthStrategy]] = contextvars.ContextVar('current_auth_strategy', default=None)

        # Configuration
        self._enable_jwt = enable_jwt
        self._enable_session = enable_session
        self._enable_api_key = enable_api_key
        self._jwt_config = jwt_config or {}

        if app:
            self.init_app(app)

    def init_app(self, app: Any) -> None:
        """Initialize authentication with an app instance."""
        # Initialize JWT authenticator
        if self._enable_jwt:
            self.jwt_auth = JWTAuthenticator(
                secret_key=self.secret_key,
                token_store=self.token_store,
                **self._jwt_config,
            )

        # Initialize session authenticator
        if self._enable_session and self.session_manager:
            self.session_auth = SessionAuthenticator(
                session_manager=self.session_manager,
                user_store=self.user_store,
            )

        # Initialize API key authenticator
        if self._enable_api_key:
            self.api_key_auth = APIKeyAuthenticator(
                user_store=self.user_store,
            )

        # Register middleware
        app.middleware('onion')(self._auth_middleware)

        # Register security schemes with OpenAPI
        self._register_openapi_security_schemes(app)

    def _register_openapi_security_schemes(self, app: Any) -> None:
        """Register security schemes with the OpenAPI plugin."""
        try:
            openapi_plugin = None
            if hasattr(app, 'plugins') and hasattr(app.plugins, 'get'):
                openapi_plugin = app.plugins.get('openapi')
            if openapi_plugin is None and hasattr(app, '_plugins'):
                for p in app._plugins:
                    if hasattr(p, 'name') and p.name == 'openapi':
                        openapi_plugin = p
                        break

            if openapi_plugin is None or not hasattr(openapi_plugin, 'add_security_scheme'):
                return

            if self._enable_jwt:
                openapi_plugin.add_security_scheme('bearerAuth', {
                    'type': 'http',
                    'scheme': 'bearer',
                    'bearerFormat': 'JWT',
                })

            if self._enable_api_key:
                openapi_plugin.add_security_scheme('apiKey', {
                    'type': 'apiKey',
                    'in': 'header',
                    'name': 'X-API-Key',
                })

            if self._enable_session:
                openapi_plugin.add_security_scheme('cookieAuth', {
                    'type': 'apiKey',
                    'in': 'cookie',
                    'name': 'session_id',
                })
        except Exception:
            logger.debug("Non-critical operation failed", exc_info=True)

    async def _auth_middleware(self, request: Request, call_next) -> Any:
        """Middleware to authenticate requests."""
        # Try to authenticate with available strategies
        user = None
        strategy = None

        # Try JWT first
        if self.jwt_auth:
            auth_header = request.headers.get(DEFAULT_AUTH_HEADER, "")
            if auth_header.startswith(f"{DEFAULT_AUTH_SCHEME} "):
                token = auth_header[len(f"{DEFAULT_AUTH_SCHEME} "):].strip()
                if not token:
                    raise AuthenticationError("Missing Bearer token", AuthError.TOKEN_INVALID)
                try:
                    payload = await self.jwt_auth.authenticate(token)
                    user_id = payload.get("sub")
                    if user_id:
                        user = await self.user_store.get_user_by_id(user_id)
                        strategy = AuthStrategy.JWT
                except AuthenticationError:
                    pass

        # Try API Key
        if not user and self.api_key_auth:
            try:
                user = await self.api_key_auth.authenticate(request)
                if user:
                    strategy = AuthStrategy.API_KEY
            except AuthenticationError:
                pass

        # Try Session
        if not user and self.session_auth:
            user = await self.session_auth.authenticate(request)
            if user:
                strategy = AuthStrategy.SESSION

        # Store in request context
        if user:
            request.ctx.user = user
            request.ctx.auth_strategy = strategy
            self._current_user_var.set(user)
            self._current_auth_strategy_var.set(strategy)

        return await call_next(request)

    @property
    def current_user(self) -> Optional[User]:
        return self._current_user_var.get()

    @property
    def current_auth_strategy(self) -> Optional[AuthStrategy]:
        return self._current_auth_strategy_var.get()

    # ========================================================================
    # Token Management
    # ========================================================================

    async def create_tokens(self, user: User, extra_claims: Optional[Dict[str, Any]] = None) -> AuthToken:
        """Create authentication tokens for a user."""
        if not self.jwt_auth:
            raise RuntimeError("JWT authentication is not enabled")
        return await self.jwt_auth.create_tokens(user, extra_claims)

    async def refresh_tokens(self, refresh_token: str) -> AuthToken:
        """Refresh access token using refresh token."""
        if not self.jwt_auth:
            raise RuntimeError("JWT authentication is not enabled")
        return await self.jwt_auth.refresh_access_token(refresh_token)

    async def revoke_token(self, token: str) -> None:
        """Revoke a token."""
        if not self.jwt_auth:
            raise RuntimeError("JWT authentication is not enabled")
        await self.jwt_auth.revoke_token(token)

    # ========================================================================
    # Session Management
    # ========================================================================

    async def login_session(self, request: Request, user: User) -> None:
        """Log in a user using session."""
        if not self.session_auth:
            raise RuntimeError("Session authentication is not enabled")
        await self.session_auth.login(request, user)

    async def logout_session(self, request: Request) -> None:
        """Log out a user from session."""
        if not self.session_auth:
            raise RuntimeError("Session authentication is not enabled")
        await self.session_auth.logout(request)

    # ========================================================================
    # API Key Management
    # ========================================================================

    def generate_api_key(
        self,
        name: str,
        user_id: str,
        permissions: Optional[List[str]] = None,
    ) -> APIKey:
        """Generate a new API key."""
        if not self.api_key_auth:
            raise RuntimeError("API key authentication is not enabled")
        return self.api_key_auth.generate_key(name, user_id, permissions)

    async def store_api_key(self, api_key: APIKey) -> None:
        """Store an API key."""
        if not self.api_key_auth:
            raise RuntimeError("API key authentication is not enabled")
        await self.api_key_auth.store_key(api_key)

    async def revoke_api_key(self, key: str) -> None:
        """Revoke an API key."""
        if not self.api_key_auth:
            raise RuntimeError("API key authentication is not enabled")
        await self.api_key_auth.revoke_key(key)

    # ========================================================================
    # OAuth2 Management
    # ========================================================================

    def register_oauth2_provider(self, name: str, config: OAuth2Config) -> None:
        """Register an OAuth2 provider."""
        self.oauth2_auths[name] = OAuth2Authenticator(config)

    def get_oauth2_authorization_url(
        self,
        provider: str,
        redirect_uri: Optional[str] = None,
        state: Optional[str] = None,
    ) -> Union[str, Tuple[str, Optional[str]]]:
        """Get OAuth2 authorization URL for a provider."""
        if provider not in self.oauth2_auths:
            raise ValueError(f"OAuth2 provider '{provider}' not registered")
        return self.oauth2_auths[provider].get_authorization_url(redirect_uri, state)

    async def exchange_oauth2_code(self, provider: str, code: str, state: str) -> Dict[str, Any]:
        """Exchange OAuth2 authorization code for tokens."""
        if provider not in self.oauth2_auths:
            raise ValueError(f"OAuth2 provider '{provider}' not registered")
        return await self.oauth2_auths[provider].exchange_code(code, state)

    # ========================================================================
    # RBAC Methods
    # ========================================================================

    def create_role(
        self,
        role_id: str,
        description: str,
        permissions: Set[str],
        inherits: Optional[Set[str]] = None,
    ) -> None:
        self.rbac.create_role(role_id, description, permissions, inherits)

    def add_role(self, role, permissions: Optional[Set[str]] = None) -> bool:
        return self.rbac.add_role(role, permissions)

    def create_permission(self, permission_id: str, description: str) -> None:
        """Create a new permission."""
        self.rbac.create_permission(permission_id, description)

    def check_permission(self, user_or_role, permission: str) -> bool:
        if isinstance(user_or_role, User):
            return self.rbac.check_any_permission(user_or_role.roles, [permission])
        if isinstance(user_or_role, str):
            return self.rbac.check_permission(user_or_role, permission)
        if isinstance(user_or_role, list):
            return self.rbac.check_any_permission(user_or_role, [permission])
        return False

    def check_any_permission(self, user: User, permissions: List[str]) -> bool:
        """Check if user has any of the permissions."""
        return self.rbac.check_any_permission(user.roles, permissions)

    def check_all_permissions(self, user: User, permissions: List[str]) -> bool:
        return self.rbac.check_all_permissions(user.roles, permissions)

    def _get_all_inherited_roles(self, user_roles) -> set:
        all_roles = set(user_roles)
        queue = list(user_roles)
        while queue:
            role = queue.pop()
            inherited = self.rbac.role_hierarchy.get(role, set())
            for r in inherited:
                if r not in all_roles:
                    all_roles.add(r)
                    queue.append(r)
        return all_roles

    # ========================================================================
    # Decorators
    # ========================================================================

    def login_required(self, handler: F) -> F:
        """Decorator to require authentication."""
        @wraps(handler)
        async def wrapper(request: Request, *args: Any, **kwargs: Any) -> Any:
            user = getattr(request.ctx, "user", None)
            if not user:
                raise AuthenticationError("Authentication required")
            return await handler(request, *args, **kwargs)
        return wrapper  # type: ignore

    def roles_required(self, *roles: str) -> Callable[[F], F]:
        def decorator(handler: F) -> F:
            @wraps(handler)
            async def wrapper(request: Request, *args: Any, **kwargs: Any) -> Any:
                user = getattr(request.ctx, "user", None)
                if not user:
                    raise AuthenticationError("Authentication required")

                all_user_roles = self._get_all_inherited_roles(user.roles)
                if not all(role in all_user_roles for role in roles):
                    raise AuthorizationError(
                        f"Required roles: {', '.join(roles)}",
                        required_permissions=[f"role:{r}" for r in roles],
                    )

                return await handler(request, *args, **kwargs)
            return wrapper  # type: ignore
        return decorator

    def require_role(self, *roles: str) -> Callable[[F], F]:
        return self.roles_required(*roles)

    def permissions_required(self, *permissions: str, require_all: bool = True) -> Callable[[F], F]:
        """Decorator to require specific permissions."""
        def decorator(handler: F) -> F:
            @wraps(handler)
            async def wrapper(request: Request, *args: Any, **kwargs: Any) -> Any:
                user = getattr(request.ctx, "user", None)
                if not user:
                    raise AuthenticationError("Authentication required")

                if require_all:
                    has_permissions = self.check_all_permissions(user, list(permissions))
                else:
                    has_permissions = self.check_any_permission(user, list(permissions))

                if not has_permissions:
                    raise AuthorizationError(
                        f"Required permissions: {', '.join(permissions)}",
                        required_permissions=list(permissions),
                    )

                return await handler(request, *args, **kwargs)
            return wrapper  # type: ignore
        return decorator

    def api_key_required(self, handler: F) -> F:
        """Decorator to require API key authentication."""
        @wraps(handler)
        async def wrapper(request: Request, *args: Any, **kwargs: Any) -> Any:
            strategy = getattr(request.ctx, "auth_strategy", None)
            if strategy != AuthStrategy.API_KEY:
                raise AuthenticationError("API key authentication required")
            return await handler(request, *args, **kwargs)
        return wrapper  # type: ignore


# ============================================================================
# Convenience Functions (for use without AuthManager instance)
# ============================================================================

async def get_current_user(request: Request) -> Optional[User]:
    """Get current authenticated user from request."""
    return getattr(request.ctx, "user", None)


def login_required(handler: F) -> F:
    """Decorator to require authentication (standalone version)."""
    @wraps(handler)
    async def wrapper(request: Request, *args: Any, **kwargs: Any) -> Any:
        user = getattr(request.ctx, "user", None)
        if not user:
            raise AuthenticationError("Authentication required")
        return await handler(request, *args, **kwargs)
    return wrapper  # type: ignore


def roles_required(*roles: str) -> Callable[[F], F]:
    ROLE_HIERARCHY = {
        "admin": {"moderator", "user", "guest"},
        "moderator": {"user", "guest"},
        "user": {"guest"},
    }
    def _get_inherited(user_roles):
        all_roles = set(user_roles)
        queue = list(user_roles)
        while queue:
            role = queue.pop()
            for r in ROLE_HIERARCHY.get(role, set()):
                if r not in all_roles:
                    all_roles.add(r)
                    queue.append(r)
        return all_roles

    def decorator(handler: F) -> F:
        @wraps(handler)
        async def wrapper(request: Request, *args: Any, **kwargs: Any) -> Any:
            user = getattr(request.ctx, "user", None)
            if not user:
                raise AuthenticationError("Authentication required")

            all_user_roles = _get_inherited(user.roles if hasattr(user, 'roles') else [])
            if not all(role in all_user_roles for role in roles):
                raise AuthorizationError(
                    f"Required roles: {', '.join(roles)}",
                    required_permissions=[f"role:{r}" for r in roles],
                )

            return await handler(request, *args, **kwargs)
        return wrapper  # type: ignore
    return decorator


def permissions_required(*permissions: str, require_all: bool = True) -> Callable[[F], F]:
    def decorator(handler: F) -> F:
        @wraps(handler)
        async def wrapper(request: Request, *args: Any, **kwargs: Any) -> Any:
            user = getattr(request.ctx, "user", None)
            if not user:
                raise AuthenticationError("Authentication required")

            user_roles = user.roles if hasattr(user, 'roles') else []
            
            if hasattr(request, 'app') and hasattr(request.app, 'auth_manager'):
                auth_mgr = request.app.auth_manager
                rbac = getattr(auth_mgr, 'rbac', None) or getattr(auth_mgr, 'rbac_manager', None)
                if rbac and hasattr(rbac, 'check_all_permissions'):
                    if require_all:
                        has_permissions = rbac.check_all_permissions(user_roles, list(permissions))
                    else:
                        has_permissions = rbac.check_any_permission(user_roles, list(permissions))
                else:
                    has_permissions = False
            else:
                has_permissions = False

            if not has_permissions:
                raise AuthorizationError(
                    f"Required permissions: {', '.join(permissions)}",
                    required_permissions=list(permissions),
                )

            return await handler(request, *args, **kwargs)
        return wrapper  # type: ignore
    return decorator


# ============================================================================
# Bearer Token Extractor
# ============================================================================

class BearerTokenExtractor:

    def __init__(
        self,
        token_url: str = "",
        scheme_name: Optional[str] = None,
        scopes: Optional[Dict[str, str]] = None,
        auto_error: bool = True,
    ):
        self.token_url = token_url
        self.scheme_name = scheme_name or "BearerTokenExtractor"
        self.scopes = scopes or {}
        self.auto_error = auto_error

    async def __call__(self, request: Any = None) -> Optional[str]:
        authorization = request.headers.get('authorization', '') if request else ''
        if authorization.startswith('Bearer '):
            return authorization[7:]
        if self.auto_error:
            from kewe.errors.exceptions import Unauthorized
            raise Unauthorized("Not authenticated")
        return None


class PasswordRequestForm:

    def __init__(
        self,
        *,
        grant_type: Optional[str] = None,
        username: Optional[str] = None,
        password: Optional[str] = None,
        scope: str = "",
        client_id: Optional[str] = None,
        client_secret: Optional[str] = None,
    ):
        self.grant_type = grant_type
        self.username = username
        self.password = password
        self.scopes = scope.split() if scope else []
        self.client_id = client_id
        self.client_secret = client_secret

    @classmethod
    async def from_request(cls, request: Any) -> 'PasswordRequestForm':
        form_data = request.form_async
        if asyncio.iscoroutine(form_data):
            form_data = await form_data
        elif asyncio.iscoroutinefunction(getattr(request, 'form_async', None)):
            form_data = await request.form_async()
        if form_data is None:
            form_data = {}
        elif hasattr(form_data, 'get'):
            pass
        elif isinstance(form_data, dict):
            pass
        else:
            form_data = {}
        return cls(
            grant_type=form_data.get('grant_type') if hasattr(form_data, 'get') else None,
            username=form_data.get('username') if hasattr(form_data, 'get') else None,
            password=form_data.get('password') if hasattr(form_data, 'get') else None,
            scope=form_data.get('scope', '') if hasattr(form_data, 'get') else '',
            client_id=form_data.get('client_id') if hasattr(form_data, 'get') else None,
            client_secret=form_data.get('client_secret') if hasattr(form_data, 'get') else None,
        )


# ============================================================================
# HTTP Basic Authentication
# ============================================================================

@dataclass
class BasicCredentials:
    username: str
    password: str


class BasicAuth:

    def __init__(
        self,
        realm: str = "Access",
        auto_error: bool = True,
    ):
        self.realm = realm
        self.auto_error = auto_error

    async def __call__(self, request: Any) -> Optional[BasicCredentials]:
        """
        从请求中提取Basic认证凭据
        
        Args:
            request: 请求对象
            
        Returns:
            BasicAuthCredentials 或 None
            
        Raises:
            Unauthorized: 当auto_error=True且凭据无效时
        """
        authorization = request.headers.get('authorization')
        if not authorization:
            if self.auto_error:
                from kewe.errors.exceptions import Unauthorized
                raise Unauthorized(
                    "Not authenticated",
                    headers={"WWW-Authenticate": f'Basic realm="{self.realm}"'},
                )
            return None

        try:
            scheme, credentials = authorization.split(None, 1)
        except ValueError:
            if self.auto_error:
                from kewe.errors.exceptions import Unauthorized
                raise Unauthorized(
                    "Invalid authentication credentials",
                    headers={"WWW-Authenticate": f'Basic realm="{self.realm}"'},
                )
            return None

        if scheme.lower() != "basic":
            if self.auto_error:
                from kewe.errors.exceptions import Unauthorized
                raise Unauthorized(
                    "Invalid authentication scheme",
                    headers={"WWW-Authenticate": f'Basic realm="{self.realm}"'},
                )
            return None

        try:
            decoded = base64.b64decode(credentials).decode("ascii")
        except (ValueError, UnicodeDecodeError):
            if self.auto_error:
                from kewe.errors.exceptions import Unauthorized
                raise Unauthorized(
                    "Invalid base64 encoding",
                    headers={"WWW-Authenticate": f'Basic realm="{self.realm}"'},
                )
            return None

        if ":" not in decoded:
            if self.auto_error:
                from kewe.errors.exceptions import Unauthorized
                raise Unauthorized(
                    "Invalid authentication credentials",
                    headers={"WWW-Authenticate": f'Basic realm="{self.realm}"'},
                )
            return None

        username, password = decoded.split(":", 1)
        return BasicCredentials(username=username, password=password)


class APIKeyCredentials:
    """API Key credentials"""

    def __init__(self, api_key: str, header_name: str = "X-API-Key"):
        self.api_key = api_key
        self.header_name = header_name

    def __repr__(self):
        return f"APIKeyCredentials(header_name={self.header_name!r})"


class APIKeyHeader:
    """API Key Header Authentication

    Usage:
        from kewe.security.auth import APIKeyHeader

        api_key_header = APIKeyHeader(name="X-API-Key")

        @app.route("/protected")
        async def protected(request, key: str = Depends(api_key_header)):
            return {"key": key}
    """

    def __init__(
        self,
        name: str = "X-API-Key",
        auto_error: bool = True,
    ):
        self.name = name
        self.auto_error = auto_error

    async def __call__(self, request: Any) -> Optional[str]:
        api_key = request.headers.get(self.name.lower())
        if api_key:
            return api_key
        if self.auto_error:
            from kewe.errors.exceptions import Unauthorized
            raise Unauthorized(f"API Key header '{self.name}' is missing")
        return None


class APIKeyQuery:
    """API Key Query Parameter Authentication

    Usage:
        api_key_query = APIKeyQuery(name="api_key")

        @app.route("/protected")
        async def protected(request, key: str = Depends(api_key_query)):
            return {"key": key}
    """

    def __init__(
        self,
        name: str = "api_key",
        auto_error: bool = True,
    ):
        self.name = name
        self.auto_error = auto_error

    async def __call__(self, request: Any) -> Optional[str]:
        api_key = request.query_params.get(self.name) if hasattr(request, 'query_params') else None
        if api_key:
            return api_key
        if self.auto_error:
            from kewe.errors.exceptions import Unauthorized
            raise Unauthorized(f"API Key query parameter '{self.name}' is missing")
        return None

