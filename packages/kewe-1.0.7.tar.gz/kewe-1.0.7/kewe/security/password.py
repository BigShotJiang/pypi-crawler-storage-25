#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.security.password - Password hashing and verification utilities
"""

import hashlib
import secrets
import re
import string

_DEFAULT_ITERATIONS = 300000
_DEFAULT_METHOD = 'pbkdf2:sha256'

_BCRYPT_AVAILABLE = False
_ARGON2_AVAILABLE = False

try:
    import bcrypt as _bcrypt
    _BCRYPT_AVAILABLE = True
except ImportError:
    pass

try:
    import argon2 as _argon2_module
    _argon2_hasher = _argon2_module.PasswordHasher()
    _ARGON2_AVAILABLE = True
except ImportError:
    pass


def generate_password_hash(
    password: str,
    method: str = None,
    algo: str = None,
    salt_length: int = 16,
    iterations: int = None,
) -> str:
    if algo is not None and method is None:
        method = algo
    if method is None:
        if _ARGON2_AVAILABLE:
            method = 'argon2'
        elif _BCRYPT_AVAILABLE:
            method = 'bcrypt'
        else:
            method = _DEFAULT_METHOD

    if method == 'argon2':
        if not _ARGON2_AVAILABLE:
            raise ValueError("argon2-cffi is not installed. Run: pip install argon2-cffi")
        return _argon2_hasher.hash(password)

    if method == 'bcrypt':
        if not _BCRYPT_AVAILABLE:
            raise ValueError("bcrypt is not installed. Run: pip install bcrypt")
        return _bcrypt.hashpw(password.encode(), _bcrypt.gensalt()).decode()

    parts = method.split(':')
    algo = parts[0]
    digest = parts[1] if len(parts) > 1 else 'sha256'

    if algo == 'pbkdf2':
        iters = iterations or _DEFAULT_ITERATIONS
        salt = secrets.token_hex(salt_length)
        pwdhash = hashlib.pbkdf2_hmac(digest, password.encode(), salt.encode(), iters)
        return f"pbkdf2:{digest}:{iters}${salt}${pwdhash.hex()}"

    raise ValueError(f"Unsupported hash method: {algo}. Use 'pbkdf2', 'bcrypt', or 'argon2'.")


def check_password_hash(password: str, pwhash: str) -> bool:
    try:
        if not pwhash:
            return False

        if pwhash.startswith('$argon2'):
            if not _ARGON2_AVAILABLE:
                return False
            try:
                _argon2_hasher.verify(pwhash, password)
                return True
            except Exception:
                return False

        if pwhash.startswith('$2b$') or pwhash.startswith('$2a$') or pwhash.startswith('$2y$'):
            if not _BCRYPT_AVAILABLE:
                return False
            try:
                return _bcrypt.checkpw(password.encode(), pwhash.encode())
            except Exception:
                return False

        if pwhash.startswith('pbkdf2:'):
            if '$' not in pwhash:
                return False
            parts = pwhash.split('$', 2)
            if len(parts) != 3:
                return False
            method_part, salt, stored_hash = parts
            method_parts = method_part.split(':')
            if len(method_parts) < 3:
                return False
            digest = method_parts[1]
            iterations = int(method_parts[2])
            pwdhash = hashlib.pbkdf2_hmac(digest, password.encode(), salt.encode(), iterations)
            return secrets.compare_digest(pwdhash.hex(), stored_hash)

        return False
    except (ValueError, IndexError, TypeError):
        return False


def needs_rehash(pwhash: str, preferred_method: str = None) -> bool:
    if preferred_method is None:
        if _ARGON2_AVAILABLE:
            preferred_method = 'argon2'
        elif _BCRYPT_AVAILABLE:
            preferred_method = 'bcrypt'
        else:
            preferred_method = 'pbkdf2'

    if preferred_method == 'argon2' and not pwhash.startswith('$argon2'):
        return True
    if preferred_method == 'bcrypt' and not (pwhash.startswith('$2b$') or pwhash.startswith('$2a$')):
        return True
    if preferred_method == 'pbkdf2' and not pwhash.startswith('pbkdf2:'):
        return True

    if pwhash.startswith('$argon2') and _ARGON2_AVAILABLE:
        try:
            return _argon2_hasher.check_needs_rehash(pwhash)
        except Exception:
            return False

    return False


def validate_password_strength(
    password: str,
    min_length: int = 8,
    max_length: int = 128,
    require_upper: bool = True,
    require_lower: bool = True,
    require_digit: bool = True,
    require_special: bool = False,
    special_chars: str = string.punctuation,
    disallow_common: bool = True,
) -> tuple:
    errors = []

    if len(password) < min_length:
        errors.append(f"Password must be at least {min_length} characters long")
    if len(password) > max_length:
        errors.append(f"Password must be at most {max_length} characters long")
    if require_upper and not re.search(r'[A-Z]', password):
        errors.append("Password must contain at least one uppercase letter")
    if require_lower and not re.search(r'[a-z]', password):
        errors.append("Password must contain at least one lowercase letter")
    if require_digit and not re.search(r'\d', password):
        errors.append("Password must contain at least one digit")
    if require_special and not any(c in special_chars for c in password):
        errors.append("Password must contain at least one special character")

    if disallow_common:
        _common = {
            'password', '123456', '12345678', 'qwerty', 'abc123',
            'monkey', 'master', 'dragon', 'login', 'princess',
            'football', 'shadow', 'sunshine', 'trustno1', 'iloveyou',
        }
        if password.lower() in _common:
            errors.append("Password is too common")

    score = 0
    if len(password) >= min_length:
        score += 1
    if len(password) >= min_length * 2:
        score += 1
    if re.search(r'[A-Z]', password):
        score += 1
    if re.search(r'[a-z]', password):
        score += 1
    if re.search(r'\d', password):
        score += 1
    if any(c in special_chars for c in password):
        score += 1
    if len(set(password)) >= len(password) * 0.7:
        score += 1

    strength = 'weak' if score <= 3 else ('medium' if score <= 5 else 'strong')

    return (len(errors) == 0, errors, strength)


hash_password = generate_password_hash
verify_password = check_password_hash


__all__ = [
    'generate_password_hash',
    'check_password_hash',
    'hash_password',
    'verify_password',
    'needs_rehash',
    'validate_password_strength',
]
