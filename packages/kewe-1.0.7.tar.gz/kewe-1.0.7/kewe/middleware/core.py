#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.middleware.core - Core middleware chain with onion pattern execution
"""

import asyncio
import logging
import re
import uuid
from typing import Callable, List, Optional, Dict, Any, Union, Awaitable
from dataclasses import dataclass, field
from collections import OrderedDict
from enum import Enum
from functools import wraps

from kewe.request import Request
from kewe.response import Response, StreamingResponse
from kewe.utils.compat import json as _json

logger = logging.getLogger(__name__)


class MiddlewarePriority(Enum):
    """
    中间件优先级 - 数值越小优先级越高
    
    执行顺序：
    HIGHEST (0) -> HIGH (25) -> NORMAL (50) -> LOW (75) -> LOWEST (100)
    """
    HIGHEST = 0
    HIGH = 25
    NORMAL = 50
    LOW = 75
    LOWEST = 100


class MiddlewareAttachPoint(Enum):
    """
    中间件挂载点
    
    REQUEST: 请求处理前执行
    RESPONSE: 响应发送前执行
    EXCEPTION: 异常发生时执行
    BEFORE_SERVER_START: 服务器启动前执行
    AFTER_SERVER_START: 服务器启动后执行
    BEFORE_SERVER_STOP: 服务器停止前执行
    AFTER_SERVER_STOP: 服务器停止后执行
    """
    REQUEST = "request"
    RESPONSE = "response"
    EXCEPTION = "exception"
    BEFORE_SERVER_START = "before_server_start"
    AFTER_SERVER_START = "after_server_start"
    BEFORE_SERVER_STOP = "before_server_stop"
    AFTER_SERVER_STOP = "after_server_stop"


@dataclass
class MiddlewareContext:
    """中间件上下文"""
    request: Request
    response: Optional[Response] = None
    exception: Optional[Exception] = None
    cancelled: bool = False
    skip_remaining: bool = False
    extra: Dict[str, Any] = field(default_factory=dict)


class MiddlewareResult:
    """中间件执行结果"""
    
    def __init__(
        self,
        continue_processing: bool = True,
        response: Optional[Response] = None,
        exception: Optional[Exception] = None
    ):
        self.continue_processing = continue_processing
        self.response = response
        self.exception = exception
    
    @classmethod
    def continue_(cls):
        """继续处理"""
        return cls(continue_processing=True)
    
    @classmethod
    def stop(cls, response: Response):
        """停止处理并返回响应"""
        return cls(continue_processing=False, response=response)
    
    @classmethod
    def error(cls, exception: Exception):
        """返回错误"""
        return cls(continue_processing=False, exception=exception)


class Middleware:
    """
    中间件包装器
    Middleware实现
    
    支持条件中间件 - 通过 methods/path_pattern 参数限定中间件的作用范围
    """
    
    def __init__(
        self,
        middleware: Callable,
        priority: "Union[int, MiddlewarePriority]" = MiddlewarePriority.NORMAL,
        attach_to: "Union[str, MiddlewareAttachPoint]" = MiddlewareAttachPoint.REQUEST,
        name: Optional[str] = None,
        methods: Optional[List[str]] = None,
        path_pattern: Optional[str] = None,
    ):
        self.middleware = middleware
        if isinstance(attach_to, str):
            attach_to = MiddlewareAttachPoint(attach_to)
        self.attach_to = attach_to
        self.priority = priority if isinstance(priority, int) else priority.value
        self.name = name or getattr(middleware, '__name__', None) or getattr(middleware, 'name', None) or middleware.__class__.__name__
        self.methods = [m.upper() for m in methods] if methods else None
        self._path_regex = re.compile(path_pattern) if path_pattern else None
        self._path_pattern = path_pattern
        
        if asyncio.iscoroutinefunction(middleware):
            self.is_async = True
        elif hasattr(middleware, '__call__') and asyncio.iscoroutinefunction(middleware.__call__):
            self.is_async = True
        else:
            self.is_async = False

        self._param_count = None
        if attach_to not in (MiddlewareAttachPoint.REQUEST, MiddlewareAttachPoint.RESPONSE, MiddlewareAttachPoint.EXCEPTION):
            import inspect as _inspect
            try:
                sig = _inspect.signature(middleware)
                self._param_count = len([p for p in sig.parameters.values()
                                         if p.default is _inspect.Parameter.empty
                                         and p.kind not in (_inspect.Parameter.VAR_POSITIONAL, _inspect.Parameter.VAR_KEYWORD)])
            except (ValueError, TypeError):
                self._param_count = 0
    
    def should_run(self, context: MiddlewareContext) -> bool:
        """检查中间件是否应该执行"""
        if self.methods and context.request.method not in self.methods:
            return False
        if self._path_regex and not self._path_regex.match(context.request.path):
            return False
        return True
    
    async def execute(
        self,
        context: MiddlewareContext
    ) -> MiddlewareResult:
        """执行中间件"""
        try:
            if self.attach_to == MiddlewareAttachPoint.REQUEST:
                # 请求中间件：只接收request参数
                if self.is_async:
                    result = await self.middleware(context.request)
                else:
                    result = self.middleware(context.request)
            elif self.attach_to == MiddlewareAttachPoint.RESPONSE:
                # 响应中间件：接收request和response参数
                if self.is_async:
                    result = await self.middleware(context.request, context.response)
                else:
                    result = self.middleware(context.request, context.response)
            elif self.attach_to == MiddlewareAttachPoint.EXCEPTION:
                # 异常中间件：接收request和exception参数
                if self.is_async:
                    result = await self.middleware(context.request, context.exception)
                else:
                    result = self.middleware(context.request, context.exception)
            else:
                app_arg = context.extra.get('app')
                loop_arg = context.extra.get('loop')
                param_count = self._param_count if self._param_count is not None else 0
                if self.is_async:
                    if param_count >= 2:
                        result = await self.middleware(app_arg, loop_arg)
                    elif param_count == 1:
                        result = await self.middleware(app_arg)
                    else:
                        result = await self.middleware()
                else:
                    if param_count >= 2:
                        result = self.middleware(app_arg, loop_arg)
                    elif param_count == 1:
                        result = self.middleware(app_arg)
                    else:
                        result = self.middleware()
            
            # 处理返回值
            if result is None:
                return MiddlewareResult.continue_()
            elif isinstance(result, Response):
                return MiddlewareResult.stop(result)
            elif isinstance(result, bool):
                if result:
                    return MiddlewareResult.continue_()
                else:
                    return MiddlewareResult.stop(Response(status=403, body=b"Forbidden"))
            elif isinstance(result, MiddlewareResult):
                return result
            else:
                return MiddlewareResult.continue_()
                
        except asyncio.CancelledError:
            raise
        except Exception as e:
            from kewe.errors.exceptions import KeweException
            if isinstance(e, KeweException):
                raise
            logger.error(f"Middleware {self.name} error: {e}")
            return MiddlewareResult.error(e)


class MiddlewareManager:
    """
    中间件管理器
    MiddlewareManager实现
    支持预编译中间件链以优化执行效率
    """
    
    def __init__(self):
        self._middlewares: List[Middleware] = []
        self._request_middlewares: List[Middleware] = []
        self._response_middlewares: List[Middleware] = []
        self._exception_middlewares: List[Middleware] = []
        self._before_server_start_middlewares: List[Middleware] = []
        self._after_server_start_middlewares: List[Middleware] = []
        self._before_server_stop_middlewares: List[Middleware] = []
        self._after_server_stop_middlewares: List[Middleware] = []
        self._error_handlers: Dict[type, List[tuple]] = {}
        self._status_code_handlers: Dict[int, Callable] = {}
        self._global_error_handler: Optional[Callable] = None
        self._route_middlewares: Dict[str, List[Middleware]] = {}
        
        self._compiled_request_chain: Optional[Callable] = None
        self._compiled_response_chain: Optional[Callable] = None
        self._compiled_exception_chain: Optional[Callable] = None
        self._needs_recompile: bool = True
    
    def register(
        self,
        middleware: Callable,
        priority: Union[int, MiddlewarePriority] = MiddlewarePriority.NORMAL,
        attach_to: Union[str, MiddlewareAttachPoint] = MiddlewareAttachPoint.REQUEST,
        name: Optional[str] = None
    ) -> 'MiddlewareManager':
        """
        注册中间件
        
        Args:
            middleware: 中间件函数
            priority: 优先级（数值越小优先级越高，支持int或MiddlewarePriority枚举）
            attach_to: 挂载点 ('request', 'response', 'exception', 'before_server_start', 'after_server_start', 'before_server_stop', 'after_server_stop')
            name: 中间件名称
            
        Returns:
            self 用于链式调用
            
        使用示例:
            # 使用枚举优先级
            @app.middleware(priority=MiddlewarePriority.HIGH)
            async def high_priority_middleware(request):
                pass
            
            # 使用数字优先级
            @app.middleware(priority=10)
            async def custom_priority_middleware(request):
                pass
        """
        if isinstance(attach_to, str):
            attach_to = MiddlewareAttachPoint(attach_to)
        
        # 统一转换为int类型
        priority_value = priority if isinstance(priority, int) else priority.value
        
        mw = Middleware(middleware, priority_value, attach_to, name)
        self._middlewares.append(mw)
        
        if attach_to == MiddlewareAttachPoint.REQUEST:
            self._request_middlewares.append(mw)
            self._request_middlewares.sort(key=lambda x: x.priority)
        elif attach_to == MiddlewareAttachPoint.RESPONSE:
            self._response_middlewares.append(mw)
            self._response_middlewares.sort(key=lambda x: x.priority)
        elif attach_to == MiddlewareAttachPoint.EXCEPTION:
            self._exception_middlewares.append(mw)
            self._exception_middlewares.sort(key=lambda x: x.priority)
        elif attach_to == MiddlewareAttachPoint.BEFORE_SERVER_START:
            self._before_server_start_middlewares.append(mw)
            self._before_server_start_middlewares.sort(key=lambda x: x.priority)
        elif attach_to == MiddlewareAttachPoint.AFTER_SERVER_START:
            self._after_server_start_middlewares.append(mw)
            self._after_server_start_middlewares.sort(key=lambda x: x.priority)
        elif attach_to == MiddlewareAttachPoint.BEFORE_SERVER_STOP:
            self._before_server_stop_middlewares.append(mw)
            self._before_server_stop_middlewares.sort(key=lambda x: x.priority)
        elif attach_to == MiddlewareAttachPoint.AFTER_SERVER_STOP:
            self._after_server_stop_middlewares.append(mw)
            self._after_server_stop_middlewares.sort(key=lambda x: x.priority)
        
        logger.debug(f"Registered middleware: {mw.name} (priority: {priority_value}, attach_to: {attach_to.value})")
        self._needs_recompile = True
        return self
    
    def unregister(self, middleware: Callable) -> bool:
        """注销中间件"""
        for mw in self._middlewares:
            if mw.middleware == middleware:
                self._middlewares.remove(mw)
                if mw in self._request_middlewares:
                    self._request_middlewares.remove(mw)
                if mw in self._response_middlewares:
                    self._response_middlewares.remove(mw)
                if mw in self._exception_middlewares:
                    self._exception_middlewares.remove(mw)
                if mw in self._before_server_start_middlewares:
                    self._before_server_start_middlewares.remove(mw)
                if mw in self._after_server_start_middlewares:
                    self._after_server_start_middlewares.remove(mw)
                if mw in self._before_server_stop_middlewares:
                    self._before_server_stop_middlewares.remove(mw)
                if mw in self._after_server_stop_middlewares:
                    self._after_server_stop_middlewares.remove(mw)
                logger.debug(f"Unregistered middleware: {mw.name}")
                return True
        return False
    
    def register_before_server_start(
        self,
        handler: Callable,
        priority: int = 0,
        name: Optional[str] = None
    ) -> 'MiddlewareManager':
        """
        注册服务器启动前监听器
        
        Args:
            handler: 处理函数
            priority: 优先级（数值越小越先执行）
            name: 监听器名称
        """
        return self.register(
            handler,
            priority=priority,
            attach_to=MiddlewareAttachPoint.BEFORE_SERVER_START,
            name=name
        )
    
    def register_after_server_start(
        self,
        handler: Callable,
        priority: int = 0,
        name: Optional[str] = None
    ) -> 'MiddlewareManager':
        """
        注册服务器启动后监听器
        
        Args:
            handler: 处理函数
            priority: 优先级（数值越大越先执行）
            name: 监听器名称
        """
        return self.register(
            handler,
            priority=priority,
            attach_to=MiddlewareAttachPoint.AFTER_SERVER_START,
            name=name
        )
    
    def register_before_server_stop(
        self,
        handler: Callable,
        priority: int = 0,
        name: Optional[str] = None
    ) -> 'MiddlewareManager':
        """
        注册服务器停止前监听器
        
        Args:
            handler: 处理函数
            priority: 优先级（数值越大越先执行）
            name: 监听器名称
        """
        return self.register(
            handler,
            priority=priority,
            attach_to=MiddlewareAttachPoint.BEFORE_SERVER_STOP,
            name=name
        )
    
    def register_after_server_stop(
        self,
        handler: Callable,
        priority: int = 0,
        name: Optional[str] = None
    ) -> 'MiddlewareManager':
        """
        注册服务器停止后监听器
        
        Args:
            handler: 处理函数
            priority: 优先级（数值越大越先执行）
            name: 监听器名称
        """
        return self.register(
            handler,
            priority=priority,
            attach_to=MiddlewareAttachPoint.AFTER_SERVER_STOP,
            name=name
        )
    
    def register_error_handler(
        self,
        exception_type: type,
        handler: Callable,
        url_prefix: Optional[str] = None
    ) -> 'MiddlewareManager':
        """注册异常处理器

        Args:
            exception_type: 异常类型
            handler: 处理函数，签名为 async def handler(request, exception)
            url_prefix: 可选的URL前缀，用于蓝图作用域隔离。
                        为None时表示全局处理器，为具体路径时仅处理匹配该前缀的请求。
        """
        if exception_type not in self._error_handlers:
            self._error_handlers[exception_type] = []

        if url_prefix is None:
            self._error_handlers[exception_type] = [
                (up, h) for up, h in self._error_handlers[exception_type]
                if up is not None
            ]
            self._error_handlers[exception_type].append((url_prefix, handler))
        else:
            self._error_handlers[exception_type].append((url_prefix, handler))

        logger.debug(f"Registered error handler for {exception_type.__name__}" +
                     (f" (scope: {url_prefix})" if url_prefix else " (global)"))
        return self

    def unregister_error_handler(self, exception_type: type) -> 'MiddlewareManager':
        self._error_handlers.pop(exception_type, None)
        logger.debug(f"Unregistered error handler for {exception_type.__name__}")
        return self

    def register_status_code_handler(self, status_code: int, handler: Callable) -> 'MiddlewareManager':
        self._status_code_handlers[status_code] = handler
        logger.debug(f"Registered status code handler for {status_code}")
        return self

    def unregister_status_code_handler(self, status_code: int) -> 'MiddlewareManager':
        self._status_code_handlers.pop(status_code, None)
        logger.debug(f"Unregistered status code handler for {status_code}")
        return self

    def get_status_code_handler(self, status_code: int) -> Optional[Callable]:
        return self._status_code_handlers.get(status_code)

    def set_global_error_handler(self, handler: Callable) -> 'MiddlewareManager':
        """设置全局异常处理器"""
        self._global_error_handler = handler
        logger.debug("Set global error handler")
        return self
    
    def register_route_middleware(
        self,
        route_name: str,
        middleware: Callable,
        priority: MiddlewarePriority = MiddlewarePriority.NORMAL,
        attach_to: Union[str, MiddlewareAttachPoint] = MiddlewareAttachPoint.REQUEST,
        name: Optional[str] = None
    ) -> 'MiddlewareManager':
        """
        为特定路由注册中间件
        
        Args:
            route_name: 路由名称
            middleware: 中间件函数
            priority: 优先级
            attach_to: 挂载点
            name: 中间件名称
            
        Returns:
            self 用于链式调用
        """
        if isinstance(attach_to, str):
            attach_to = MiddlewareAttachPoint(attach_to)
        
        priority_value = priority if isinstance(priority, int) else priority.value
        mw = Middleware(middleware, priority_value, attach_to, name)
        
        if route_name not in self._route_middlewares:
            self._route_middlewares[route_name] = []
        
        self._route_middlewares[route_name].append(mw)
        # 按优先级排序
        self._route_middlewares[route_name].sort(key=lambda x: x.priority if isinstance(x.priority, int) else x.priority.value)
        
        logger.debug(f"Registered route middleware: {mw.name} for route {route_name}")
        return self
    
    async def execute_request_middleware(
        self,
        request: Request
    ) -> MiddlewareResult:
        if self._needs_recompile:
            self.compile_middleware_chains()
        
        if self._compiled_request_chain:
            result = await self._compiled_request_chain(request)
            if not result.continue_processing:
                return result
        else:
            result = MiddlewareResult.continue_()
        
        if hasattr(request.ctx, 'route') and hasattr(request.ctx.route, 'name'):
            route_name = request.ctx.route.name
            if route_name in self._route_middlewares:
                context = MiddlewareContext(request=request)
                for mw in self._route_middlewares[route_name]:
                    if mw.attach_to == MiddlewareAttachPoint.REQUEST:
                        if context.skip_remaining:
                            break
                        mw_result = await mw.execute(context)
                        if not mw_result.continue_processing:
                            return mw_result
                        if mw_result.exception:
                            handled = await self._handle_exception(request, mw_result.exception)
                            if handled:
                                return MiddlewareResult.stop(handled)
                            return mw_result
        
        return result
    
    async def execute_response_middleware(
        self,
        request: Request,
        response: Response
    ) -> Response:
        if self._needs_recompile:
            self.compile_middleware_chains()
        
        if self._compiled_response_chain:
            response = await self._compiled_response_chain(request, response)
        
        if hasattr(request.ctx, 'route') and hasattr(request.ctx.route, 'name'):
            route_name = request.ctx.route.name
            if route_name in self._route_middlewares:
                context = MiddlewareContext(request=request, response=response)
                for mw in self._route_middlewares[route_name]:
                    if mw.attach_to == MiddlewareAttachPoint.RESPONSE:
                        try:
                            mw_result = await mw.execute(context)
                            if mw_result.response:
                                context.response = mw_result.response
                                response = mw_result.response
                        except Exception as e:
                            logger.error(f"Route response middleware {mw.name} error: {e}")
        
        return response
    
    async def execute_exception_middleware(
        self,
        request: Request,
        exception: Exception
    ) -> Optional[Response]:
        if self._needs_recompile:
            self.compile_middleware_chains()
        
        if self._compiled_exception_chain:
            result = await self._compiled_exception_chain(request, exception)
            if result is not None:
                return result
        
        if hasattr(request.ctx, 'route') and hasattr(request.ctx.route, 'name'):
            route_name = request.ctx.route.name
            if route_name in self._route_middlewares:
                context = MiddlewareContext(request=request, exception=exception)
                for mw in self._route_middlewares[route_name]:
                    if mw.attach_to == MiddlewareAttachPoint.EXCEPTION:
                        try:
                            result = await mw.execute(context)
                            if result.response:
                                return result.response
                            elif result.exception:
                                exception = result.exception
                        except Exception as e:
                            logger.error(f"Route exception middleware {mw.name} error: {e}")
        
        return await self._handle_exception(request, exception)
    
    async def execute_before_server_start(
        self,
        app,
        loop
    ) -> None:
        """执行服务器启动前中间件（按优先级排序）"""
        context = MiddlewareContext(
            request=None,
            extra={'app': app, 'loop': loop}
        )
        
        sorted_middlewares = sorted(
            self._before_server_start_middlewares,
            key=lambda mw: getattr(mw, 'priority', 0)
        )
        
        for mw in sorted_middlewares:
            result = await mw.execute(context)
            if result.exception is not None:
                raise result.exception
    
    async def execute_after_server_start(
        self,
        app,
        loop
    ) -> None:
        """执行服务器启动后中间件（按优先级排序）"""
        context = MiddlewareContext(
            request=None,
            extra={'app': app, 'loop': loop}
        )
        
        sorted_middlewares = sorted(
            self._after_server_start_middlewares,
            key=lambda mw: getattr(mw, 'priority', 0)
        )
        
        for mw in sorted_middlewares:
            await mw.execute(context)
    
    async def execute_before_server_stop(
        self,
        app,
        loop
    ) -> None:
        """执行服务器停止前中间件（按优先级排序）"""
        context = MiddlewareContext(
            request=None,
            extra={'app': app, 'loop': loop}
        )
        
        sorted_middlewares = sorted(
            self._before_server_stop_middlewares,
            key=lambda mw: getattr(mw, 'priority', 0)
        )
        
        for mw in sorted_middlewares:
            await mw.execute(context)
    
    async def execute_after_server_stop(
        self,
        app,
        loop
    ) -> None:
        """执行服务器停止后中间件（按优先级排序）"""
        context = MiddlewareContext(
            request=None,
            extra={'app': app, 'loop': loop}
        )
        
        sorted_middlewares = sorted(
            self._after_server_stop_middlewares,
            key=lambda mw: getattr(mw, 'priority', 0)
        )
        
        for mw in sorted_middlewares:
            await mw.execute(context)
    
    async def _invoke_error_handler(self, handler, request, exception):
        import inspect
        sig = inspect.signature(handler)
        param_count = len([p for p in sig.parameters.values()
                          if p.kind not in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD)])
        if param_count <= 1:
            return await handler(exception)
        return await handler(request, exception)

    def _invoke_error_handler_sync(self, handler, request, exception):
        import inspect
        sig = inspect.signature(handler)
        param_count = len([p for p in sig.parameters.values()
                          if p.kind not in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD)])
        if param_count <= 1:
            return handler(exception)
        return handler(request, exception)

    async def _handle_exception(
        self,
        request: Request,
        exception: Exception
    ) -> Optional[Response]:
        status_code = getattr(exception, 'status_code', None) or getattr(exception, 'status', None)
        if status_code and isinstance(status_code, int):
            handler = self._status_code_handlers.get(status_code)
            if handler:
                try:
                    if asyncio.iscoroutinefunction(handler):
                        return await self._invoke_error_handler(handler, request, exception)
                    else:
                        return self._invoke_error_handler_sync(handler, request, exception)
                except Exception as e:
                    logger.error(f"Status code handler failed: {e}")

        request_path = getattr(request, 'path', '')
        for cls in type(exception).__mro__:
            handlers = self._error_handlers.get(cls)
            if not handlers:
                continue
            scoped_match = None
            global_match = None
            for url_prefix, handler in handlers:
                if url_prefix is None:
                    if global_match is None:
                        global_match = handler
                else:
                    if request_path == url_prefix or request_path.startswith(url_prefix + '/'):
                        if scoped_match is None or (url_prefix is not None and
                           (scoped_match[0] is None or len(url_prefix) > len(scoped_match[0] or ''))):
                            scoped_match = (url_prefix, handler)
            chosen = scoped_match[1] if scoped_match else global_match
            if chosen:
                try:
                    if asyncio.iscoroutinefunction(chosen):
                        return await self._invoke_error_handler(chosen, request, exception)
                    else:
                        return self._invoke_error_handler_sync(chosen, request, exception)
                except Exception as e:
                    logger.error(f"Error handler failed: {e}")
        
        if self._global_error_handler:
            try:
                if asyncio.iscoroutinefunction(self._global_error_handler):
                    return await self._invoke_error_handler(self._global_error_handler, request, exception)
                else:
                    return self._invoke_error_handler_sync(self._global_error_handler, request, exception)
            except Exception as e:
                logger.error(f"Global error handler failed: {e}")
        
        return None
    
    def clear(self):
        """清除所有中间件"""
        self._middlewares.clear()
        self._request_middlewares.clear()
        self._response_middlewares.clear()
        self._exception_middlewares.clear()
        self._before_server_start_middlewares.clear()
        self._after_server_start_middlewares.clear()
        self._before_server_stop_middlewares.clear()
        self._after_server_stop_middlewares.clear()
        self._error_handlers.clear()
        self._global_error_handler = None
        self._compiled_request_chain = None
        self._compiled_response_chain = None
        self._compiled_exception_chain = None
        self._needs_recompile = True
    
    def compile_middleware_chains(self):
        """
        预编译中间件链 - 优化策略
        在服务器启动时调用，将中间件链编译为单一可调用对象
        避免每次请求都遍历中间件列表
        """
        self._compiled_request_chain = self._compile_request_chain()
        self._compiled_response_chain = self._compile_response_chain()
        self._compiled_exception_chain = self._compile_exception_chain()
        self._needs_recompile = False
        logger.debug("Middleware chains compiled")
    
    def _compile_request_chain(self) -> Callable:
        """编译请求中间件链"""
        middlewares = self._request_middlewares.copy()
        
        if not middlewares:
            return None
        
        async def compiled_chain(request: Request) -> MiddlewareResult:
            context = MiddlewareContext(request=request)
            
            for mw in middlewares:
                if context.skip_remaining:
                    break
                
                if not mw.should_run(context):
                    continue
                
                result = await mw.execute(context)
                
                if not result.continue_processing:
                    return result
                
                if result.exception:
                    handled = await self._handle_exception(request, result.exception)
                    if handled:
                        return MiddlewareResult.stop(handled)
                    return result
            
            return MiddlewareResult.continue_()
        
        return compiled_chain
    
    def _compile_response_chain(self) -> Callable:
        """编译响应中间件链"""
        middlewares = list(reversed(self._response_middlewares))
        
        if not middlewares:
            return None
        
        async def compiled_chain(request: Request, response: Response) -> Response:
            context = MiddlewareContext(request=request, response=response)
            
            for mw in middlewares:
                if not mw.should_run(context):
                    continue
                try:
                    result = await mw.execute(context)
                    
                    if result.response:
                        context.response = result.response
                    
                    if result.exception:
                        logger.error(f"Response middleware error: {result.exception}")
                        
                except Exception as e:
                    logger.error(f"Response middleware {mw.name} error: {e}")
            
            return context.response
        
        return compiled_chain
    
    def _compile_exception_chain(self) -> Callable:
        """编译异常中间件链"""
        middlewares = self._exception_middlewares.copy()
        
        if not middlewares:
            return None
        
        async def compiled_chain(request: Request, exception: Exception) -> Optional[Response]:
            context = MiddlewareContext(request=request, exception=exception)
            
            for mw in middlewares:
                result = await mw.execute(context)
                
                if result.response:
                    return result.response
                elif result.exception:
                    exception = result.exception
            
            return await self._handle_exception(request, exception)
        
        return compiled_chain
    
    @property
    def middlewares(self) -> List[Middleware]:
        """获取所有中间件"""
        return self._middlewares.copy()
    
    @property
    def request_middlewares(self) -> List[Middleware]:
        """获取请求中间件"""
        return self._request_middlewares.copy()
    
    @property
    def response_middlewares(self) -> List[Middleware]:
        """获取响应中间件"""
        return self._response_middlewares.copy()
    
    @property
    def exception_middlewares(self) -> List[Middleware]:
        """获取异常中间件"""
        return self._exception_middlewares.copy()
    
    @property
    def before_server_start_middlewares(self) -> List[Middleware]:
        """获取服务器启动前中间件"""
        return self._before_server_start_middlewares.copy()
    
    @property
    def after_server_start_middlewares(self) -> List[Middleware]:
        """获取服务器启动后中间件"""
        return self._after_server_start_middlewares.copy()
    
    @property
    def before_server_stop_middlewares(self) -> List[Middleware]:
        """获取服务器停止前中间件"""
        return self._before_server_stop_middlewares.copy()
    
    @property
    def after_server_stop_middlewares(self) -> List[Middleware]:
        """获取服务器停止后中间件"""
        return self._after_server_stop_middlewares.copy()


# ========== 内置中间件 ==========

class RequestIDMiddleware:
    """请求ID中间件 - 为每个请求生成唯一ID
    
    支持:
    - 从请求头读取已有的请求ID
    - 自动生成唯一请求ID (UUID, ULID, NanoID等格式)
    - 在响应头中返回请求ID
    - 可配置前缀和格式
    """
    
    def __init__(
        self,
        header_name: str = "X-Request-ID",
        response_header: str = "X-Request-ID",
        format: str = "uuid",
        length: int = 21,
        prefix: str = "",
        enforce: bool = False
    ):
        from kewe.middleware.request_id import (
            RequestIDConfig, RequestIDManager, RequestIDFormat
        )
        
        format_map = {
            "uuid": RequestIDFormat.UUID,
            "uuid_hex": RequestIDFormat.UUID_HEX,
            "ulid": RequestIDFormat.ULID,
            "nanoid": RequestIDFormat.NANO_ID,
        }
        
        self.config = RequestIDConfig(
            header_name=header_name,
            response_header_name=response_header,
            format=format_map.get(format, RequestIDFormat.UUID),
            length=length,
            prefix=prefix,
            enforce=enforce
        )
        self.manager = RequestIDManager(self.config)
    
    async def __call__(self, request: Request):
        request_id = self.manager.get_or_create(request.headers)
        request.request_id = request_id
        request.ctx.request_id = request_id
        return True
    
    async def response(self, request: Request, response: Response):
        request_id = getattr(request, 'request_id', None) or getattr(request.ctx, 'request_id', None)
        if request_id:
            response.headers[self.config.response_header_name] = request_id


class CompressionMiddleware:
    """压缩中间件 - 支持gzip/brotli压缩，包括流式响应"""

    def __init__(
        self,
        min_size: int = 1024,
        level: int = 6,
        compressible_types: List[str] = None
    ):
        self.min_size = min_size
        self.level = level
        self.compressible_types = compressible_types or [
            'text/', 'application/json', 'application/javascript',
            'application/xml', 'application/rss+xml'
        ]
        self._brotli_available = False
        try:
            import brotli
            self._brotli_available = True
        except ImportError:
            pass

    def _append_vary(self, response: Response, value: str):
        existing = response.headers.get('vary', '')
        if existing:
            if value.lower() not in existing.lower():
                response.headers['vary'] = f"{existing}, {value}"
        else:
            response.headers['vary'] = value

    async def response(self, request: Request, response: Response):
        """压缩响应"""
        if 'content-encoding' in response.headers:
            return

        accept_encoding = request.headers.get('accept-encoding', '').lower()

        use_brotli = self._brotli_available and 'br' in accept_encoding
        use_gzip = 'gzip' in accept_encoding

        if not use_brotli and not use_gzip:
            return

        content_type = response.content_type.lower()
        is_compressible = any(
            content_type == t.rstrip('/') or content_type.startswith(t)
            for t in self.compressible_types
        )

        if not is_compressible:
            return

        if response._streaming and response._stream_generator:
            await self._compress_streaming(response, use_brotli)
        elif len(response.body) >= self.min_size:
            await self._compress_body(response, use_brotli)

    async def _compress_body(self, response: Response, use_brotli: bool = False):
        """压缩非流式响应体"""
        try:
            if use_brotli:
                import brotli
                compressed = brotli.compress(response.body, quality=self.level)
                encoding = 'br'
            else:
                import gzip
                compressed = gzip.compress(response.body, compresslevel=self.level)
                encoding = 'gzip'

            if len(compressed) < len(response.body):
                response.body = compressed
                response.headers['content-encoding'] = encoding
                response.headers['content-length'] = str(len(compressed))
                self._append_vary(response, 'accept-encoding')
        except Exception as e:
            logger.error(f"Compression error: {e}")

    async def _compress_streaming(self, response: Response, use_brotli: bool = False):
        import zlib

        original_generator = response._stream_generator

        if use_brotli:
            async def br_stream():
                import brotli
                compressor = brotli.Compressor(quality=self.level)
                try:
                    async for chunk in original_generator:
                        if isinstance(chunk, str):
                            chunk = chunk.encode('utf-8')
                        compressed = compressor.process(chunk)
                        if compressed:
                            yield compressed
                finally:
                    remaining = compressor.finish()
                    if remaining:
                        yield remaining

            response._stream_generator = br_stream()
            response.headers['content-encoding'] = 'br'
        else:
            async def gzip_stream():
                gzip_compress = zlib.compressobj(level=self.level, wbits=31)
                try:
                    async for chunk in original_generator:
                        if isinstance(chunk, str):
                            chunk = chunk.encode('utf-8')
                        compressed = gzip_compress.compress(chunk)
                        if compressed:
                            yield compressed
                finally:
                    remaining = gzip_compress.flush()
                    if remaining:
                        yield remaining

            response._stream_generator = gzip_stream()
            response.headers['content-encoding'] = 'gzip'

        self._append_vary(response, 'accept-encoding')
        response.headers.pop('content-length', None)


class GZipMiddleware(CompressionMiddleware):
    """GZip中间件 - 便捷别名

    GZipMiddleware，提供gzip压缩功能。
    继承自CompressionMiddleware，仅启用gzip（不使用brotli）。

    使用示例:
        app.add_middleware(GZipMiddleware, min_size=1000, level=6)
    """

    def __init__(
        self,
        min_size: int = 1024,
        level: int = 6,
        compressible_types: List[str] = None
    ):
        super().__init__(min_size=min_size, level=level, compressible_types=compressible_types)
        self._brotli_available = False


class SecurityHeadersMiddleware:
    """安全头部中间件"""
    
    def __init__(
        self,
        x_content_type_options: str = "nosniff",
        x_frame_options: str = "DENY",
        x_xss_protection: str = "0",
        strict_transport_security: Optional[str] = None,
        hsts_max_age: int = 31536000,
        hsts_include_subdomains: bool = True,
        hsts_preload: bool = False,
        content_security_policy: Optional[str] = None,
        referrer_policy: str = "strict-origin-when-cross-origin",
        permissions_policy: Optional[str] = None,
        cross_origin_opener_policy: str = "same-origin",
        cross_origin_resource_policy: str = "same-origin",
        cross_origin_embedder_policy: Optional[str] = None
    ):
        self.x_content_type_options = x_content_type_options
        self.x_frame_options = x_frame_options
        self.x_xss_protection = x_xss_protection
        self.hsts_max_age = hsts_max_age
        self.hsts_include_subdomains = hsts_include_subdomains
        self.hsts_preload = hsts_preload
        self.content_security_policy = content_security_policy
        self.referrer_policy = referrer_policy
        self.permissions_policy = permissions_policy
        self.cross_origin_opener_policy = cross_origin_opener_policy
        self.cross_origin_resource_policy = cross_origin_resource_policy
        self.cross_origin_embedder_policy = cross_origin_embedder_policy
        
        if strict_transport_security:
            self._hsts_value = strict_transport_security
        else:
            self._hsts_value = self._build_hsts_value()
    
    def _build_hsts_value(self) -> str:
        """构建 HSTS 值"""
        value = f"max-age={self.hsts_max_age}"
        if self.hsts_include_subdomains:
            value += "; includeSubDomains"
        if self.hsts_preload:
            value += "; preload"
        return value
    
    async def response(self, request: Request, response: Response):
        """添加安全头部"""
        if self.x_content_type_options:
            response.headers['x-content-type-options'] = self.x_content_type_options
        
        if self.x_frame_options:
            response.headers['x-frame-options'] = self.x_frame_options
        
        if self.x_xss_protection:
            response.headers['x-xss-protection'] = self.x_xss_protection
        
        if getattr(request, 'is_secure', False) or request.scheme == 'https':
            response.headers['strict-transport-security'] = self._hsts_value
        
        if self.content_security_policy:
            response.headers['content-security-policy'] = self.content_security_policy
        
        if self.referrer_policy:
            response.headers['referrer-policy'] = self.referrer_policy
        
        if self.permissions_policy:
            response.headers['permissions-policy'] = self.permissions_policy
        
        if self.cross_origin_opener_policy:
            response.headers['cross-origin-opener-policy'] = self.cross_origin_opener_policy
        
        if self.cross_origin_resource_policy:
            response.headers['cross-origin-resource-policy'] = self.cross_origin_resource_policy
        
        if self.cross_origin_embedder_policy:
            response.headers['cross-origin-embedder-policy'] = self.cross_origin_embedder_policy


class TimingMiddleware:
    """计时中间件 - 记录请求处理时间"""
    
    def __init__(self, header_name: str = "X-Response-Time"):
        self.header_name = header_name
    
    async def __call__(self, request: Request):
        """记录开始时间"""
        import time
        request.ctx._start_time = time.time()
        return True
    
    async def response(self, request: Request, response: Response):
        """添加处理时间到响应头"""
        import time
        
        if hasattr(request.ctx, '_start_time'):
            elapsed = (time.time() - request.ctx._start_time) * 1000
            response.headers[self.header_name] = f"{elapsed:.2f}ms"


# ========== 便捷装饰器 ==========

def middleware(
    priority: MiddlewarePriority = MiddlewarePriority.NORMAL,
    attach_to: str = "request"
):
    """
    中间件装饰器
    
    使用示例:
        @middleware(priority=MiddlewarePriority.HIGH)
        async def auth_middleware(request):
            if not request.ctx.user:
                return Response(status=401)
            return True
        
        @middleware(attach_to="response")
        async def add_headers(request, response):
            response.headers['X-Custom'] = 'value'
    """
    def decorator(func: Callable):
        func._is_middleware = True
        func._middleware_priority = priority
        func._middleware_attach_to = attach_to
        return func
    return decorator


class HTTPSRedirectMiddleware:
    
    def __init__(self, status_code: int = 307):
        self.status_code = status_code
    
    async def __call__(self, request: Request):
        if request.headers.get('x-forwarded-proto', '').lower() == 'http':
            url = f"https://{request.headers.get('host', '')}{request.path}"
            from kewe.response import redirect as _redirect
            return _redirect(url, status=self.status_code)
        return True


class TrustedHostMiddleware:
    
    def __init__(
        self,
        allowed_hosts: List[str] = None,
        except_paths: List[str] = None
    ):
        self.allowed_hosts = [h.lower() for h in (allowed_hosts or ["*"])]
        self.except_paths = except_paths or []
        self._allow_any = "*" in self.allowed_hosts
    
    async def __call__(self, request: Request, call_next=None):
        if self._allow_any:
            if call_next:
                return await call_next(request)
            return True

        path = request.path
        for except_path in self.except_paths:
            if path.startswith(except_path):
                if call_next:
                    return await call_next(request)
                return True

        host = request.headers.get('host', '').split(':')[0].lower()

        if not host:
            if call_next:
                return await call_next(request)
            return True

        for pattern in self.allowed_hosts:
            if pattern == host:
                if call_next:
                    return await call_next(request)
                return True
            if pattern.startswith('.') and (host == pattern[1:] or host.endswith(pattern)):
                if call_next:
                    return await call_next(request)
                return True
            if pattern.startswith('*.') and host.endswith(pattern[1:]):
                if call_next:
                    return await call_next(request)
                return True

        from kewe.errors.exceptions import Forbidden
        raise Forbidden(f"Host '{host}' is not trusted")


class ForwardedHeadersMiddleware:
    
    def __init__(
        self,
        x_forwarded_for: bool = True,
        x_forwarded_proto: bool = True,
        x_forwarded_host: bool = True,
        x_forwarded_port: bool = True,
        x_real_ip: bool = True,
        trusted_proxies: Optional[List[str]] = None
    ):
        self.x_forwarded_for = x_forwarded_for
        self.x_forwarded_proto = x_forwarded_proto
        self.x_forwarded_host = x_forwarded_host
        self.x_forwarded_port = x_forwarded_port
        self.x_real_ip = x_real_ip
        self.trusted_proxies = trusted_proxies
    
    async def __call__(self, request: Request):
        if self.trusted_proxies is None:
            return True
        
        client_ip = request.client_ip or ''
        if client_ip not in self.trusted_proxies:
            return True
        
        if self.x_real_ip:
            real_ip = request.headers.get('x-real-ip')
            if real_ip:
                request.client_ip = real_ip
        
        if self.x_forwarded_for:
            forwarded_for = request.headers.get('x-forwarded-for')
            if forwarded_for:
                ips = [ip.strip() for ip in forwarded_for.split(',')]
                trusted_ip = None
                for ip in reversed(ips):
                    if ip in self.trusted_proxies:
                        continue
                    trusted_ip = ip
                    break
                if trusted_ip is None and ips:
                    trusted_ip = ips[-1]
                if trusted_ip:
                    request.client_ip = trusted_ip
        
        if self.x_forwarded_proto:
            proto = request.headers.get('x-forwarded-proto', '').lower().strip()
            if proto in ('http', 'https'):
                request.scheme = proto
        
        if self.x_forwarded_host:
            host = request.headers.get('x-forwarded-host')
            if host:
                request.headers['host'] = host
        
        if self.x_forwarded_port:
            port = request.headers.get('x-forwarded-port')
            if port:
                try:
                    request.server_port = int(port)
                except (ValueError, TypeError):
                    pass
        
        return True


__all__ = [
    'MiddlewareManager',
    'Middleware',
    'MiddlewareContext',
    'MiddlewareResult',
    'MiddlewarePriority',
    'MiddlewareAttachPoint',
    'RequestIDMiddleware',
    'CompressionMiddleware',
    'GZipMiddleware',
    'SecurityHeadersMiddleware',
    'TimingMiddleware',
    'HTTPSRedirectMiddleware',
    'TrustedHostMiddleware',
    'ForwardedHeadersMiddleware',
    'OnionMiddleware',
    'OnionMiddlewareChain',
    'BaseHTTPMiddleware',
    'ASGIMiddlewareAdapter',
    'ServerErrorMiddleware',
    'ASGIMiddlewareStack',
    'PureASGIMiddleware',
    'ASGIOnionMiddleware',
    'middleware',
]


class OnionMiddleware:
    """
    洋葱中间件 - call_next模式
    
    允许在同一个中间件函数中同时处理请求前和响应后逻辑。
    这解决了线性管道模型中请求/响应中间件分离的问题。
    
    使用示例:
        @app.onion_middleware
        async def timing(request, call_next):
            start = time.time()
            response = await call_next(request)
            elapsed = time.time() - start
            response.headers["X-Process-Time"] = f"{elapsed:.4f}s"
            return response
        
        @app.onion_middleware
        async def db_transaction(request, call_next):
            async with request.app.db.transaction():
                response = await call_next(request)
            return response
    """
    
    def __init__(self, middleware_func: Callable, priority: int = 50):
        self.func = middleware_func
        self.priority = priority
        self.is_async = asyncio.iscoroutinefunction(middleware_func) or (
            hasattr(middleware_func, '__call__') and asyncio.iscoroutinefunction(middleware_func.__call__)
        )
    
    async def __call__(
        self,
        request: Request,
        call_next: Callable[[Request], Awaitable[Response]]
    ) -> Response:
        if self.is_async:
            return await self.func(request, call_next)
        else:
            return self.func(request, call_next)


class BaseHTTPMiddleware:
    """基于类的HTTP中间件 - BaseHTTPMiddleware
    
    提供clean的dispatch模式，子类只需实现dispatch方法。
    
    使用示例:
        class AuthMiddleware(BaseHTTPMiddleware):
            async def dispatch(self, request, call_next):
                if not request.headers.get('authorization'):
                    return Response(status=401, body=b'Unauthorized')
                response = await call_next(request)
                return response
        
        app.add_middleware(AuthMiddleware)
    """

    def __init__(self, app=None):
        self.app = app

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """子类应重写此方法实现中间件逻辑"""
        return await call_next(request)

    async def __call__(self, request: Request, call_next: Callable) -> Response:
        return await self.dispatch(request, call_next)


class ASGIMiddlewareAdapter:
    """纯 ASGI 中间件适配器 - 将 ASGI 中间件包装为洋葱中间件
    
    中间件栈设计，允许 KeWe 使用
    纯 ASGI 中间件（如 SessionMiddleware、AuthenticationMiddleware 等）。
    
    使用示例:
        # SessionMiddleware参考
        app.add_middleware(SessionMiddleware, secret_key="...")
    """
    
    def __init__(self, asgi_middleware, app):
        self.asgi_middleware = asgi_middleware
        self.app = app
    
    async def __call__(self, request: Request, call_next: Callable) -> Response:
        scope = {
            'type': 'http',
            'method': request.method,
            'path': request.path,
            'query_string': request.query_string.encode('utf-8') if hasattr(request, 'query_string') and isinstance(request.query_string, str) else b'',
            'headers': [],
            'server': None,
            'client': None,
            'asgi': {'version': '3.0'},
        }
        
        for key, value in request.headers.items():
            scope['headers'].append((key.lower().encode('utf-8'), value.encode('utf-8') if isinstance(value, str) else value))
        
        response_started = False
        response_body = bytearray()
        response_headers = []
        response_status = 200
        
        async def receive():
            body = await request.body
            body = body if isinstance(body, bytes) else b''
            return {
                'type': 'http.request',
                'body': body,
                'more_body': False,
            }
        
        async def send(message):
            nonlocal response_started, response_body, response_headers, response_status
            
            if message['type'] == 'http.response.start':
                response_started = True
                response_status = message.get('status', 200)
                response_headers = message.get('headers', [])
            elif message['type'] == 'http.response.body':
                body = message.get('body', b'')
                if body:
                    response_body.extend(body if isinstance(body, bytes) else body.encode('utf-8'))
        
        inner_response = None
        
        async def inner_asgi_app(scope, receive, send):
            nonlocal inner_response
            inner_response = await call_next(request)
            
            await send({
                'type': 'http.response.start',
                'status': inner_response.status,
                'headers': [
                    (k.lower().encode('utf-8'), v.encode('utf-8') if isinstance(v, str) else v)
                    for k, v in inner_response.headers.items()
                ],
            })
            await send({
                'type': 'http.response.body',
                'body': inner_response.body,
            })
        
        await self.asgi_middleware(scope, receive, inner_asgi_app)
        
        if inner_response is not None and response_started:
            if response_body:
                inner_response.body = bytes(response_body)
            inner_response.status = response_status
            for header_name, header_value in response_headers:
                inner_response.headers[header_name.decode('utf-8')] = header_value.decode('utf-8')
            return inner_response
        
        if response_started:
            resp = Response(body=bytes(response_body), status=response_status)
            for header_name, header_value in response_headers:
                resp.headers[header_name.decode('utf-8')] = header_value.decode('utf-8')
            return resp
        
        return await call_next(request)


class ServerErrorMiddleware:
    """服务器错误中间件 - 
    
    作为最外层中间件，确保即使应用崩溃也能返回500响应。
    """

    def __init__(self, app=None, debug: bool = False):
        self.app = app
        self.debug = debug

    async def __call__(self, request: Request, call_next: Callable) -> Response:
        try:
            return await call_next(request)
        except Exception as exc:
            logger.error(f"Unhandled server error: {exc}", exc_info=True)
            from kewe.errors.exceptions import InternalServerError
            err = InternalServerError(str(exc) if self.debug else "Internal Server Error")
            return Response(
                body=_json.dumps(err.to_problem_details(request.path)).encode('utf-8'),
                status=500,
                content_type="application/json"
            )


class OnionMiddlewareChain:
    """
    洋葱中间件链 - 将多个洋葱中间件组合为嵌套调用
    
    执行顺序（假设有3个中间件 A, B, C）：
        A 请求前 -> B 请求前 -> C 请求前 -> handler -> C 响应后 -> B 响应后 -> A 响应后
    """
    
    def __init__(self):
        self._middlewares: List[OnionMiddleware] = []
        self._cached_chain = None
        self._cache_key = None
    
    def add(self, middleware: OnionMiddleware) -> None:
        self._middlewares.append(middleware)
        self._middlewares.sort(key=lambda m: m.priority)
        self._invalidate_cache()
    
    def add_from_middleware(self, middleware_instance: Any) -> None:
        self._middlewares.append(OnionMiddleware(middleware_instance.__call__))
        self._middlewares.sort(key=lambda m: m.priority)
        self._invalidate_cache()
    
    def _invalidate_cache(self):
        self._cached_chain = None
        self._cache_key = None
    
    def _get_cache_key(self):
        return tuple(id(m) for m in self._middlewares)
    
    async def execute(
        self,
        request: Request,
        handler: Callable[[Request], Awaitable[Response]]
    ) -> Response:
        cache_key = self._get_cache_key()
        
        if self._cached_chain is not None and self._cache_key == cache_key:
            chain = self._cached_chain
        else:
            chain = self._build_chain(handler)
            self._cached_chain = chain
            self._cache_key = cache_key
        
        return await chain(request)
    
    def _build_chain(self, final_handler: Callable[[Request], Awaitable[Response]]) -> Callable[[Request], Awaitable[Response]]:
        def build_chain(
            middlewares: List[OnionMiddleware],
            handler: Callable[[Request], Awaitable[Response]]
        ) -> Callable[[Request], Awaitable[Response]]:
            if not middlewares:
                return handler
            
            current = middlewares[0]
            rest = middlewares[1:]
            
            inner = build_chain(rest, handler) if rest else handler
            
            async def chain_call(req: Request) -> Response:
                call_next_called = False
                
                async def guarded_call_next(request: Request) -> Response:
                    nonlocal call_next_called
                    if call_next_called:
                        raise RuntimeError("call_next was called multiple times in middleware. Each call_next should only be invoked once.")
                    call_next_called = True
                    return await inner(request)
                
                return await current(req, guarded_call_next)
            
            return chain_call
        
        return build_chain(self._middlewares, final_handler)
    
    @property
    def middlewares(self) -> List[OnionMiddleware]:
        return self._middlewares.copy()


class ASGIMiddlewareStack:
    """纯ASGI中间件栈 - 中间件栈设计

    所有中间件通过ASGI协议嵌套，确保中间件栈完全兼容。
    中间件按照添加顺序嵌套：最后添加的中间件在最外层。

    核心设计：
        app = ASGIMiddlewareStack(inner_app)
        app.add_middleware(CORSMiddleware, ...)
        app.add_middleware(GZipMiddleware, ...)
        # 最终调用链: GZipMiddleware → CORSMiddleware → inner_app

    使用示例:
        stack = ASGIMiddlewareStack(app)
        stack.add_middleware(SomeASGIMiddleware, param1="value1")
        asgi_app = stack.build()
        # 用 uvicorn 运行 asgi_app
    """

    def __init__(self, app):
        self.app = app
        self._middleware_stack: List[tuple] = []

    def add_middleware(self, middleware_class, **kwargs):
        """添加ASGI中间件

        Args:
            middleware_class: ASGI中间件类，必须接受app作为第一个参数
            **kwargs: 传递给中间件构造函数的额外参数
        """
        self._middleware_stack.append((middleware_class, kwargs))

    def build(self) -> Callable:
        """构建ASGI中间件栈

        返回一个完整的ASGI应用，所有中间件按顺序嵌套。
        最后添加的中间件在最外层（最先执行）。
        """
        current = self.app

        for middleware_class, kwargs in reversed(self._middleware_stack):
            current = middleware_class(app=current, **kwargs)

        return current

    async def __call__(self, scope, receive, send):
        """直接作为ASGI应用调用"""
        app = self.build()
        await app(scope, receive, send)


class PureASGIMiddleware:
    """纯ASGI中间件基类 - 

    所有ASGI中间件都应继承此类，只需实现process_request和/或process_response方法。

    使用示例:
        class TimingASGIMiddleware(PureASGIMiddleware):
            async def process_request(self, scope, receive):
                scope['start_time'] = time.time()

            async def process_response(self, scope, receive, send, response_start, response_body):
                elapsed = time.time() - scope.get('start_time', 0)
                # 修改响应头
                response_start['headers'].append(
                    (b'x-process-time', f'{elapsed:.4f}s'.encode())
                )
    """

    def __init__(self, app):
        self.app = app

    async def process_request(self, scope, receive):
        return None

    async def process_response(self, scope, receive, send, response_start, response_body):
        return None

    async def process_websocket(self, scope, receive, send):
        return None

    async def __call__(self, scope, receive, send):
        if scope['type'] not in ('http', 'websocket'):
            await self.app(scope, receive, send)
            return

        if scope['type'] == 'websocket':
            await self.process_websocket(scope, receive, send)
            await self.app(scope, receive, send)
            return

        await self.process_request(scope, receive)

        response_start = None
        response_body = None

        async def send_wrapper(message):
            nonlocal response_start, response_body

            if message['type'] == 'http.response.start':
                response_start = message
            elif message['type'] == 'http.response.body':
                response_body = message

                await self.process_response(scope, receive, send, response_start, response_body)

                await send(response_start)
                await send(response_body)
            else:
                await send(message)

        await self.app(scope, receive, send_wrapper)


class ASGIOnionMiddleware:
    """ASGI洋葱中间件 - 将洋葱风格中间件转换为纯ASGI中间件

    将 call_next(request) 风格的中间件转换为 ASGI(scope, receive, send) 风格，
    使其可以在纯ASGI中间件栈中使用。

    使用示例:
        async def timing_middleware(request, call_next):
            start = time.time()
            response = await call_next(request)
            response.headers["X-Process-Time"] = f"{time.time()-start:.4f}s"
            return response

        stack.add_middleware(ASGIOnionMiddleware, middleware_func=timing_middleware)
    """

    def __init__(self, app, middleware_func=None):
        self.app = app
        self.middleware_func = middleware_func

    async def __call__(self, scope, receive, send):
        if scope['type'] not in ('http', 'websocket'):
            await self.app(scope, receive, send)
            return

        if scope['type'] == 'websocket':
            if self.middleware_func is not None:
                logger.debug(f"ASGIOnionMiddleware: WebSocket scope passed through (middleware {self.middleware_func.__name__} skipped for websocket)")
            await self.app(scope, receive, send)
            return

        if self.middleware_func is None:
            await self.app(scope, receive, send)
            return

        from kewe.server.asgi import ASGIAdapter

        request = self._build_request_from_scope(scope, receive)
        if request is None:
            await self.app(scope, receive, send)
            return

        response_started = False
        response_status = 200
        response_headers = []
        response_body = bytearray()
        more_body_expected = False

        async def inner_send(message):
            nonlocal response_started, response_status, response_headers, response_body, more_body_expected
            if message['type'] == 'http.response.start':
                response_started = True
                response_status = message.get('status', 200)
                response_headers = message.get('headers', [])
            elif message['type'] == 'http.response.body':
                body = message.get('body', b'')
                if body:
                    response_body.extend(body if isinstance(body, bytes) else body.encode('utf-8'))
                more_body_expected = message.get('more_body', False)

        async def call_next(req):
            await self.app(scope, receive, inner_send)

            if more_body_expected:
                resp = StreamingResponse(
                    content=self._stream_from_app(receive),
                    status=response_status,
                )
            else:
                resp = Response(
                    body=bytes(response_body),
                    status=response_status,
                )
            for h_name, h_value in response_headers:
                resp.headers[h_name.decode('utf-8')] = h_value.decode('utf-8')
            return resp

        try:
            result = self.middleware_func(request, call_next)
            if asyncio.iscoroutine(result):
                response = await result
            else:
                response = result

            if isinstance(response, Response):
                headers = []
                for k, v in response.headers.items():
                    headers.append((k.lower().encode('utf-8'), v.encode('utf-8') if isinstance(v, str) else v))
                await send({
                    'type': 'http.response.start',
                    'status': response.status,
                    'headers': headers,
                })
                body = response.body if isinstance(response.body, bytes) else response.body.encode('utf-8')
                await send({
                    'type': 'http.response.body',
                    'body': body,
                })
            else:
                if not response_started:
                    await self.app(scope, receive, send)
        except Exception as e:
            logger.error(f"ASGI onion middleware error: {e}", exc_info=True)
            if not response_started:
                try:
                    error_body = _json.dumps({"detail": "Internal Server Error"}).encode('utf-8')
                    await send({
                        'type': 'http.response.start',
                        'status': 500,
                        'headers': [(b'content-type', b'application/json')],
                    })
                    await send({
                        'type': 'http.response.body',
                        'body': error_body,
                    })
                except Exception:
                    logger.error("Failed to send error response after ASGI middleware exception", exc_info=True)
            else:
                try:
                    await send({
                        'type': 'http.response.body',
                        'body': b'',
                        'more_body': False,
                    })
                except Exception:
                    logger.debug("Non-critical operation failed", exc_info=True)

    async def _stream_from_app(self, receive):
        while True:
            msg = await receive()
            if msg['type'] == 'http.response.body':
                yield msg.get('body', b'')
                if not msg.get('more_body', False):
                    break

    def _build_request_from_scope(self, scope, receive):
        try:
            import urllib.parse
            path = scope['path']
            query_string = scope.get('query_string', b'').decode('utf-8')
            query_params = urllib.parse.parse_qs(query_string, keep_blank_values=True)

            headers = {}
            for key, value in scope.get('headers', []):
                headers[key.decode('utf-8').lower()] = value.decode('utf-8')

            client = scope.get('client')
            client_ip = client[0] if client else ''

            request = Request(
                method=scope['method'],
                path=path,
                headers=headers,
                query_params=query_params,
                body=b'',
                client_ip=client_ip,
                protocol=f"HTTP/{scope.get('http_version', '1.1')}",
            )
            request._scope = scope
            if hasattr(self, '_app'):
                request.app = self._app
            return request
        except Exception:
            return None
