#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.middleware.cors - CORS middleware for cross-origin resource sharing
"""

import logging
import re
import time
from collections import OrderedDict
from typing import List, Optional, Dict, Any, Union, Pattern

from kewe.middleware.core import MiddlewarePriority

logger = logging.getLogger(__name__)


class CORSConfig:
    """CORS配置
    
    支持 参数 (origins, methods) 和 别名参数 (allow_origins, allow_methods)
    """
    
    def __init__(
        self,
        origins: List[Union[str, Pattern]] = None,
        methods: List[str] = None,
        allow_headers: List[str] = None,
        expose_headers: List[str] = None,
        supports_credentials: bool = False,
        max_age: int = 86400,
        automatic_options: bool = True,
        allow_origins: List[Union[str, Pattern]] = None,
        allow_methods: List[str] = None,
        allow_credentials: bool = None,
        preflight_cache: bool = True,
        preflight_cache_max_age: int = 3600,
    ):
        self.origins = allow_origins or origins or ["*"]
        self.methods = allow_methods or methods or ["GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"]
        self.allow_headers = allow_headers or ["*"]
        self.expose_headers = expose_headers or []
        self.supports_credentials = allow_credentials if allow_credentials is not None else supports_credentials
        self.max_age = max_age
        self.automatic_options = automatic_options
        self.preflight_cache = preflight_cache
        self.preflight_cache_max_age = preflight_cache_max_age
        
        if self.supports_credentials and "*" in self.origins:
            raise ValueError(
                "CORS: supports_credentials=True with allow_origins=['*'] is not allowed "
                "by the CORS spec. Please specify explicit origins."
            )
        
        self._compiled_patterns: List[Pattern] = []
        for origin in self.origins:
            if isinstance(origin, Pattern):
                self._compiled_patterns.append(origin)
            elif "*" in origin and origin != "*":
                parts = origin.split("*")
                regex_parts = [re.escape(part) for part in parts]
                regex_str = r".*".join(regex_parts)
                self._compiled_patterns.append(re.compile("^" + regex_str + "$"))


class CORSMiddleware:
    """CORS中间件"""
    
    MAX_PREFLIGHT_CACHE_SIZE = 1024

    def __init__(self, config: CORSConfig = None, **kwargs):
        if config is not None:
            self.config = config
        elif kwargs:
            self.config = CORSConfig(**kwargs)
        else:
            self.config = CORSConfig()
        self._preflight_cache_store: OrderedDict[str, tuple] = OrderedDict()

    @property
    def preflight_cache(self) -> bool:
        return self.config.preflight_cache

    @property
    def preflight_cache_max_age(self) -> int:
        return self.config.preflight_cache_max_age
    
    async def __call__(self, request, response=None):
        """处理CORS请求"""
        if response is None:
            return await self._handle_request(request)
        else:
            return await self._handle_response(request, response)
    
    async def response(self, request, response):
        """响应中间件接口 — 就地修改 response 对象"""
        origin = request.headers.get("origin")
        if not origin:
            return
        
        allow_origin = self._get_allow_origin(origin)
        if not allow_origin:
            return
        
        response.headers["Access-Control-Allow-Origin"] = allow_origin
        existing_vary = response.headers.get("Vary", "")
        if existing_vary:
            if "origin" not in existing_vary.lower():
                response.headers["Vary"] = f"{existing_vary}, Origin"
        else:
            response.headers["Vary"] = "Origin"
        
        if self.config.supports_credentials:
            response.headers["Access-Control-Allow-Credentials"] = "true"
        
        if self.config.expose_headers:
            response.headers["Access-Control-Expose-Headers"] = ", ".join(self.config.expose_headers)
    
    async def _handle_request(self, request):
        """处理请求"""
        if request.method == "OPTIONS" and self.config.automatic_options:
            if self.config.preflight_cache:
                origin = request.headers.get("origin", "")
                request_method = request.headers.get("access-control-request-method", "")
                request_headers = request.headers.get("access-control-request-headers", "")
                cached = self._get_cached_preflight(origin, request_method, request_headers)
                if cached is not None:
                    return self._clone_response(cached)
            response = await self._create_options_response(request)
            if self.config.preflight_cache and response.status == 204:
                origin = request.headers.get("origin", "")
                request_method = request.headers.get("access-control-request-method", "")
                request_headers = request.headers.get("access-control-request-headers", "")
                self._cache_preflight(origin, request_method, request_headers, response)
            return response
        return True

    @staticmethod
    def _clone_response(response):
        from kewe.response import Response
        from kewe.http.headers import Headers
        cloned = Response(status=response.status)
        if isinstance(response.headers, Headers):
            cloned.headers = Headers(response.headers)
        else:
            cloned.headers = Headers(response.headers)
        return cloned

    def _get_cached_preflight(self, origin: str, request_method: str, request_headers: str = "") -> Optional[Any]:
        cache_key = f"{origin}:{request_method}:{request_headers}"
        entry = self._preflight_cache_store.get(cache_key)
        if entry is None:
            return None
        cached_response, cached_at = entry
        if time.monotonic() - cached_at > self.config.preflight_cache_max_age:
            del self._preflight_cache_store[cache_key]
            return None
        return cached_response

    def _cache_preflight(self, origin: str, request_method: str, request_headers: str, response) -> None:
        if len(self._preflight_cache_store) >= self.MAX_PREFLIGHT_CACHE_SIZE:
            self._preflight_cache_store.popitem(last=False)
        cache_key = f"{origin}:{request_method}:{request_headers}"
        self._preflight_cache_store[cache_key] = (response, time.monotonic())
        self._preflight_cache_store.move_to_end(cache_key)
    
    def _get_allow_origin(self, origin: str) -> Optional[str]:
        """获取允许的origin值 - 遵循CORS规范"""
        if not self._is_allowed_origin(origin):
            return None
        
        if self.config.supports_credentials:
            return origin
        
        if "*" in self.config.origins and not self.config._compiled_patterns:
            return "*"
        
        return origin
    
    async def _handle_response(self, request, response):
        """处理响应"""
        origin = request.headers.get("origin")
        if not origin:
            return response
        
        allow_origin = self._get_allow_origin(origin)
        if not allow_origin:
            return response
        
        response.headers["Access-Control-Allow-Origin"] = allow_origin
        existing_vary = response.headers.get("Vary", "")
        if existing_vary:
            if "origin" not in existing_vary.lower():
                response.headers["Vary"] = f"{existing_vary}, Origin"
        else:
            response.headers["Vary"] = "Origin"
        
        if self.config.supports_credentials:
            response.headers["Access-Control-Allow-Credentials"] = "true"
        
        if self.config.expose_headers:
            response.headers["Access-Control-Expose-Headers"] = ", ".join(self.config.expose_headers)
        
        return response
    
    async def _create_options_response(self, request):
        """创建OPTIONS预检响应"""
        from kewe.response import Response
        
        origin = request.headers.get("origin")
        if not origin:
            return Response(status=204)
        
        allow_origin = self._get_allow_origin(origin)
        if not allow_origin:
            return Response(status=204)
        
        response = Response(status=204)
        
        response.headers["Access-Control-Allow-Origin"] = allow_origin
        response.headers["Access-Control-Allow-Methods"] = ", ".join(self.config.methods)

        allow_headers_value = ", ".join(self.config.allow_headers)
        if "*" in self.config.allow_headers:
            request_headers = request.headers.get("access-control-request-headers", "")
            if request_headers:
                allow_headers_value = request_headers
        response.headers["Access-Control-Allow-Headers"] = allow_headers_value
        response.headers["Access-Control-Max-Age"] = str(self.config.max_age)
        vary_parts = ["Origin"]
        if "*" in self.config.allow_headers:
            vary_parts.append("Access-Control-Request-Headers")
        response.headers["Vary"] = ", ".join(vary_parts)
        
        if self.config.supports_credentials:
            response.headers["Access-Control-Allow-Credentials"] = "true"
        
        return response
    
    def _is_allowed_origin(self, origin: str) -> bool:
        """检查是否是允许的源 - 支持正则匹配"""
        if "*" in self.config.origins:
            return True
        
        if origin in self.config.origins:
            return True
        
        for pattern in self.config._compiled_patterns:
            if pattern.match(origin):
                return True
        
        return False


def add_cors(app, config: CORSConfig = None, **kwargs):
    """
    添加CORS中间件
    
    使用示例:
        add_cors(app)
        add_cors(app, origins=["https://example.com"], supports_credentials=True)
        add_cors(app, CORSConfig(origins=["https://example.com"]))
        add_cors(app, allow_origins=["*"], allow_methods=["GET", "POST"])
    """
    if config is None:
        config = CORSConfig(**kwargs)
    cors_middleware = CORSMiddleware(config)
    
    @app.middleware("onion")
    async def cors_onion_middleware(request, call_next):
        if request.method == "OPTIONS" and config.automatic_options:
            origin = request.headers.get("origin")
            if origin:
                if cors_middleware._is_allowed_origin(origin):
                    return await cors_middleware._create_options_response(request)
                else:
                    from kewe.response import Response
                    return Response(status=403)
        response = await call_next(request)
        if request.method == "OPTIONS" and config.automatic_options and response.status == 405:
            response = await cors_middleware._create_options_response(request)
        else:
            await cors_middleware._handle_response(request, response)
        return response
    
    logger.info(f"CORS middleware added with origins: {config.origins}")
    return cors_middleware


__all__ = [
    'CORSConfig',
    'CORSMiddleware',
    'add_cors',
]
