#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.response.streaming - Streaming responses including SSE and file streaming
"""

import asyncio
import logging
import mimetypes
import os
import time
import warnings
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import AsyncGenerator, Callable, Optional, Union, Any, Dict

from kewe.http.headers import Headers

logger = logging.getLogger(__name__)


@dataclass
class StreamConfig:
    chunk_size: int = 8192
    max_buffer_size: int = 1024 * 1024
    backpressure_high: int = 100
    backpressure_low: int = 10


class StreamBuffer:

    def __init__(self, config: StreamConfig = None):
        self.config = config or StreamConfig()
        self._queue: asyncio.Queue = asyncio.Queue(maxsize=self.config.backpressure_high)
        self._paused = False
        self._closed = False

    async def put(self, data: bytes) -> bool:
        if self._closed:
            return False
        if self._queue.qsize() >= self.config.backpressure_high:
            self._paused = True
        await self._queue.put(data)
        return True

    async def get(self) -> Optional[bytes]:
        if self._closed and self._queue.empty():
            return None
        return await self._queue.get()

    def close(self):
        self._closed = True

    @property
    def is_paused(self) -> bool:
        return self._paused

    @property
    def is_closed(self) -> bool:
        return self._closed

    @property
    def size(self) -> int:
        return self._queue.qsize()


class StreamingResponse:
    """
    流式HTTP响应 — 继承 StreamingResponse 并扩展协议级写入能力

    兼容两种使用方式:
    1. 生成器模式: StreamingResponse(generate(), content_type='text/plain')
    2. 协议写入模式: await resp.write(data) / await resp.send_headers() / await resp.finish()
    """
    __slots__ = (
        'streaming_fn', 'stream_generator', 'status', 'content_type',
        'headers', '_cookies', 'background', 'is_streaming', '_body',
        '_started', '_finished', '_transport', '_protocol',
    )

    def __init__(
        self,
        streaming_fn: Union[AsyncGenerator[bytes, None], Callable[[], AsyncGenerator[bytes, None]]] = None,
        status: int = 200,
        content_type: str = "application/octet-stream",
        headers: Optional[Dict[str, str]] = None,
        body: Union[AsyncGenerator[bytes, None], Callable[[], AsyncGenerator[bytes, None]]] = None,
    ):
        actual_fn = streaming_fn or body
        if actual_fn is None:
            raise TypeError("StreamingResponse requires either 'streaming_fn' or 'body' argument")
        self.streaming_fn = actual_fn
        self.stream_generator = actual_fn
        self.status = status
        self.content_type = content_type
        self.headers = Headers(headers) if headers else Headers()
        self._cookies = {}
        self.background = None
        self.is_streaming = True
        self._body = b''

        self._started = False
        self._finished = False
        self._transport = None
        self._protocol = None

    def set_cookie(self, key: str, value: str = "", max_age: int = None,
                   expires: int = None, path: str = "/", domain: str = None,
                   secure: bool = False, httponly: bool = False, samesite: str = None):
        from kewe.response.response import ResponseCookie
        from datetime import datetime, timezone
        self._cookies[key] = ResponseCookie(
            name=key, value=value, max_age=max_age,
            expires=datetime.fromtimestamp(expires, tz=timezone.utc) if isinstance(expires, (int, float)) else expires,
            domain=domain, path=path, secure=secure,
            httponly=httponly, samesite=samesite or "Lax",
        )

    def delete_cookie(self, key: str, path: str = "/", domain: str = None):
        from kewe.response.response import ResponseCookie
        from datetime import datetime, timezone
        self._cookies[key] = ResponseCookie(
            name=key, value="", max_age=0,
            expires=datetime(1970, 1, 1, tzinfo=timezone.utc),
            domain=domain, path=path, secure=True, httponly=True, samesite="Lax",
        )

    def get_cookie_headers(self):
        headers = []
        import http.cookies
        import dataclasses
        for name, cookie_data in self._cookies.items():
            morsel = http.cookies.Morsel()
            if dataclasses.is_dataclass(cookie_data):
                morsel.set(name, cookie_data.value, cookie_data.value)
                for field in dataclasses.fields(cookie_data):
                    if field.name not in ('name', 'value') and getattr(cookie_data, field.name):
                        morsel[field.name.replace('_', '-')] = str(getattr(cookie_data, field.name))
            else:
                morsel.set(name, cookie_data.get('value', ''), cookie_data.get('value', ''))
                for k, v in cookie_data.items():
                    if k != 'value':
                        morsel[k] = v
            headers.append(('set-cookie', morsel.OutputString()))
        return headers

    async def write(self, data: bytes):
        if self._finished:
            raise RuntimeError("Response already finished")
        if not self._started:
            await self.send_headers()
        if self._protocol and hasattr(self._protocol, 'write'):
            self._protocol.write(data)
            await self._protocol.drain()
        logger.debug(f"Streamed {len(data)} bytes")

    async def send_headers(self):
        if self._started:
            return
        self._started = True
        from http import HTTPStatus
        try:
            reason = HTTPStatus(self.status).phrase
        except ValueError:
            reason = "Unknown"
        headers = [
            f"HTTP/1.1 {self.status} {reason}\r\n",
            f"Content-Type: {self.content_type}\r\n",
            "Transfer-Encoding: chunked\r\n",
        ]
        for name, value in self.headers.items():
            safe_name = str(name).replace('\r', '').replace('\n', '')
            safe_value = str(value).replace('\r', '').replace('\n', '')
            headers.append(f"{safe_name}: {safe_value}\r\n")
        for cookie_name, cookie in self._cookies.items():
            if hasattr(cookie, 'to_header'):
                headers.append(f"Set-Cookie: {cookie.to_header()}\r\n")
        headers.append("\r\n")
        if self._protocol and hasattr(self._protocol, 'write'):
            self._protocol.write(''.join(headers).encode())
            await self._protocol.drain()

    async def finish(self):
        if self._finished:
            return
        if not self._started:
            await self.send_headers()
        if self._protocol and hasattr(self._protocol, 'write'):
            self._protocol.write(b"0\r\n\r\n")
            await self._protocol.drain()
        self._finished = True

    async def __call__(self, *args):
        if len(args) == 3:
            scope, receive, send = args
            headers = [
                [b'content-type', self.content_type.encode()],
            ]
            for key, value in self.headers.items():
                headers.append([key.encode(), value.encode()])
            for cookie_name, cookie in self._cookies.items():
                if hasattr(cookie, 'to_header'):
                    headers.append([b'set-cookie', cookie.to_header().encode()])
            await send({
                'type': 'http.response.start',
                'status': self.status,
                'headers': headers
            })
            try:
                if callable(self.streaming_fn):
                    gen = self.streaming_fn()
                else:
                    gen = self.streaming_fn
                async for chunk in gen:
                    if isinstance(chunk, str):
                        chunk = chunk.encode('utf-8')
                    if chunk:
                        await send({
                            'type': 'http.response.body',
                            'body': chunk,
                            'more_body': True
                        })
                        await asyncio.sleep(0)
            except Exception as e:
                logger.error(f"Streaming error: {e}")
            await send({
                'type': 'http.response.body',
                'body': b'',
                'more_body': False
            })
        else:
            protocol = args[0] if args else None
            self._protocol = protocol
            try:
                if callable(self.streaming_fn):
                    gen = self.streaming_fn()
                else:
                    gen = self.streaming_fn
                await self.send_headers()
                async for chunk in gen:
                    if isinstance(chunk, str):
                        chunk = chunk.encode('utf-8')
                    if self._protocol and hasattr(self._protocol, 'write'):
                        size_hex = hex(len(chunk))[2:].encode()
                        self._protocol.write(size_hex + b"\r\n")
                        self._protocol.write(chunk)
                        self._protocol.write(b"\r\n")
                        await self._protocol.drain()
                await self.finish()
            except Exception as e:
                logger.error(f"Streaming error: {e}")
                raise


from kewe.response.response import ServerSentEvent


class ServerSentEventResponse(StreamingResponse):
    def __init__(
        self,
        streaming_fn: Union[AsyncGenerator[bytes, None], Callable[[], AsyncGenerator[bytes, None]]],
        status: int = 200,
        headers: Optional[Dict[str, str]] = None
    ):
        headers = headers or {}
        headers['Cache-Control'] = headers.get('Cache-Control', 'no-cache')
        headers['Connection'] = headers.get('Connection', 'keep-alive')
        super().__init__(
            streaming_fn,
            status=status,
            content_type='text/event-stream',
            headers=headers
        )

    @staticmethod
    def event(
        data: Any = None,
        event: str = None,
        id: str = None,
        retry: int = None
    ) -> bytes:
        from kewe.response.response import ServerSentEvent as SSE
        sse = SSE(data=str(data) if data is not None else None, event=event, id=id, retry=retry)
        return sse.encode()


class FileStreamResponse(StreamingResponse):
    def __init__(
        self,
        filepath: str,
        chunk_size: int = 8192,
        content_type: str = None,
        filename: str = None,
        headers: Optional[Dict[str, str]] = None
    ):
        self.filepath = filepath
        self.chunk_size = chunk_size

        if not os.path.exists(filepath):
            raise FileNotFoundError(f"File not found: {filepath}")

        if content_type is None:
            import mimetypes
            content_type, _ = mimetypes.guess_type(filepath)
            content_type = content_type or 'application/octet-stream'

        headers = headers or {}
        if filename:
            headers['Content-Disposition'] = f'attachment; filename="{filename}"'

        super().__init__(
            self._file_generator(),
            content_type=content_type,
            headers=headers
        )

    async def _file_generator(self) -> AsyncGenerator[bytes, None]:
        loop = asyncio.get_running_loop()
        queue: asyncio.Queue[Optional[bytes]] = asyncio.Queue(maxsize=8)

        def read_file():
            try:
                with open(self.filepath, 'rb') as f:
                    while True:
                        chunk = f.read(self.chunk_size)
                        if not chunk:
                            break
                        while True:
                            try:
                                loop.call_soon_threadsafe(queue.put_nowait, chunk)
                                break
                            except asyncio.QueueFull:
                                time.sleep(0.01)
            except Exception as e:
                logger.error(f"File read error: {e}")
            finally:
                try:
                    loop.call_soon_threadsafe(queue.put_nowait, None)
                except asyncio.QueueFull:
                    pass

        executor_future = loop.run_in_executor(None, read_file)
        try:
            while True:
                chunk = await queue.get()
                if chunk is None:
                    break
                yield chunk
        finally:
            executor_future.cancel()


def stream(
    streaming_fn, status=200, content_type="application/octet-stream", headers=None
) -> StreamingResponse:
    return StreamingResponse(streaming_fn, status, content_type, headers)


def sse(
    streaming_fn, status=200, headers=None
) -> ServerSentEventResponse:
    return ServerSentEventResponse(streaming_fn, status, headers)


def file_stream(
    filepath, chunk_size=8192, content_type=None, filename=None, headers=None
) -> FileStreamResponse:
    return FileStreamResponse(filepath, chunk_size, content_type, filename, headers)


def validate_file(
    request_headers: Dict[str, str],
    last_modified: Union[datetime, float, int],
    size: int = None
) -> Optional[Any]:
    from kewe.response import Response

    if isinstance(last_modified, (int, float)):
        last_modified = datetime.fromtimestamp(last_modified, tz=timezone.utc)

    if last_modified.tzinfo is None:
        last_modified = last_modified.replace(tzinfo=timezone.utc)

    if_modified_since = request_headers.get("if-modified-since", "")
    if if_modified_since:
        try:
            from email.utils import parsedate_to_datetime
            cached_time = parsedate_to_datetime(if_modified_since)
            if cached_time.tzinfo is None:
                cached_time = cached_time.replace(tzinfo=timezone.utc)
            if last_modified.replace(microsecond=0) <= cached_time:
                return Response(status=304)
        except (ValueError, TypeError):
            try:
                cached_time = datetime.strptime(
                    if_modified_since, "%a, %d %b %Y %H:%M:%S GMT"
                ).replace(tzinfo=timezone.utc)
                if last_modified.replace(microsecond=0) <= cached_time:
                    return Response(status=304)
            except ValueError:
                pass

    if_none_match = request_headers.get("if-none-match", "")
    if if_none_match and size is not None:
        mtime_ns = int(last_modified.timestamp() * 1e9)
        etag_value = f"{mtime_ns:x}-{size:x}"
        expected_etag = f'"{etag_value}"'

        if if_none_match == expected_etag or if_none_match == '*':
            return Response(status=304)

    return None


async def stream_file_range(
    location: Union[str, Path],
    start: int,
    end: int,
    chunk_size: int = 4096,
    mime_type: Optional[str] = None
) -> StreamingResponse:
    location = Path(location)

    if not location.exists():
        from kewe.errors.exceptions import NotFound
        raise NotFound(f"File not found: {location}")

    if mime_type is None:
        mime_type, _ = mimetypes.guess_type(str(location))
        mime_type = mime_type or "application/octet-stream"

    stat = location.stat()
    total_size = stat.st_size

    end = min(end, total_size - 1)
    content_length = end - start + 1

    headers = {
        "content-range": f"bytes {start}-{end}/{total_size}",
        "accept-ranges": "bytes",
        "content-length": str(content_length),
    }

    async def range_generator():
        loop = asyncio.get_running_loop()
        with open(location, 'rb') as f:
            f.seek(start)
            remaining = content_length
            while remaining > 0:
                read_size = min(chunk_size, remaining)
                chunk = await loop.run_in_executor(None, f.read, read_size)
                if not chunk:
                    break
                remaining -= len(chunk)
                yield chunk

    return StreamingResponse(
        streaming_fn=range_generator,
        status=206,
        content_type=mime_type,
        headers=headers
    )


class FileStreamIterator:

    def __init__(
        self,
        location: Union[str, Path],
        chunk_size: int = 4096,
        start: int = 0,
        end: Optional[int] = None
    ):
        self.location = Path(location)
        self.chunk_size = chunk_size
        self.start = start
        self.end = end
        self._file = None
        self._position = 0
        self._size_cache: Optional[int] = None

    async def __aenter__(self):
        loop = asyncio.get_running_loop()
        self._file = await loop.run_in_executor(None, self._open_and_seek)
        return self

    def _open_and_seek(self):
        f = open(self.location, 'rb')
        f.seek(self.start)
        self._position = self.start
        return f

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self._file:
            loop = asyncio.get_running_loop()
            await loop.run_in_executor(None, self._file.close)
        return False

    async def __aiter__(self):
        return self

    async def __anext__(self) -> bytes:
        if self._file is None:
            raise StopAsyncIteration

        if self.end is not None and self._position >= self.end:
            raise StopAsyncIteration

        loop = asyncio.get_running_loop()
        chunk = await loop.run_in_executor(None, self._file.read, self.chunk_size)
        if not chunk:
            raise StopAsyncIteration

        self._position += len(chunk)
        return chunk

    @property
    def size(self) -> int:
        if self._size_cache is None:
            self._size_cache = self.location.stat().st_size
        return self._size_cache

    @property
    def position(self) -> int:
        return self._position

    @property
    def remaining(self) -> int:
        if self.end is not None:
            return max(0, self.end - self._position)
        return max(0, self.size - self._position)


class StreamingHTTPResponse(StreamingResponse):
    """
    HTTP流式响应 — 基于StreamingResponse的HTTP协议流式响应

    提供HTTP协议级别的流式响应能力，支持：
    - 生成器模式流式输出
    - 协议写入模式（write/send_headers/finish）
    - 分块传输编码
    - HTTP/1.1 协议兼容
    """

    __slots__ = ('_chunk_size',)

    def __init__(
        self,
        streaming_fn: Union[AsyncGenerator[bytes, None], Callable[[], AsyncGenerator[bytes, None]]] = None,
        status: int = 200,
        content_type: str = "application/octet-stream",
        headers: Optional[Dict[str, str]] = None,
        body: Union[AsyncGenerator[bytes, None], Callable[[], AsyncGenerator[bytes, None]]] = None,
        chunk_size: int = 65536,
    ):
        super().__init__(
            streaming_fn=streaming_fn,
            status=status,
            content_type=content_type,
            headers=headers,
            body=body,
        )
        self._chunk_size = chunk_size

    @property
    def chunk_size(self) -> int:
        return self._chunk_size

    async def write_chunk(self, data: bytes):
        if self._finished:
            raise RuntimeError("Response already finished")
        if not self._started:
            await self.send_headers()
        if isinstance(data, str):
            data = data.encode('utf-8')
        offset = 0
        while offset < len(data):
            chunk = data[offset:offset + self._chunk_size]
            if self._protocol and hasattr(self._protocol, 'write'):
                size_hex = hex(len(chunk))[2:].encode()
                self._protocol.write(size_hex + b"\r\n")
                self._protocol.write(chunk)
                self._protocol.write(b"\r\n")
                await self._protocol.drain()
            offset += self._chunk_size