"""
Kewe Framework Type Stubs

提供类型提示支持，增强 IDE 自动补全和类型检查
"""
from typing import (
    Any, Callable, Dict, List, Optional, Union, 
    TypeVar, Generic, Awaitable, Coroutine, overload,
    AsyncGenerator, Sequence
)
from types import TracebackType

F = TypeVar('F', bound=Callable[..., Any])
T = TypeVar('T')


class Kewe:
    """Kewe 应用类"""
    
    name: str
    config: "KeweConfig"
    router: "Router"
    middleware_manager: "MiddlewareManager"
    state: "AppState"
    ctx: "AppState"
    container: Any
    services: Any
    gateway: Any
    metrics: "MetricsManager"
    
    def __init__(
        self,
        name: str = "KeweApp",
        config: Optional["KeweConfig"] = None,
        *,
        enable_gateway: Optional[bool] = None,
        lifespan: Optional[Callable] = None,
        **kwargs: Any
    ) -> None: ...
    
    @classmethod
    def get_app(cls, name: Optional[str] = None, *, force_create: bool = False) -> "Kewe": ...
    
    @classmethod
    def get_current(cls) -> Optional["Kewe"]: ...
    
    def route(
        self,
        path: str,
        methods: Optional[List[str]] = None,
        *,
        name: Optional[str] = None,
        host: Optional[str] = None,
        strict_slashes: bool = False,
        middlewares: Optional[List[Callable]] = None,
        version: Optional[Union[int, str]] = None,
        version_prefix: str = "v",
        dependencies: Optional[List[Callable]] = None,
        response_model: Optional[type] = None,
        **kwargs: Any
    ) -> Callable[[F], F]: ...
    
    def get(self, path: str, **kwargs: Any) -> Callable[[F], F]: ...
    def post(self, path: str, **kwargs: Any) -> Callable[[F], F]: ...
    def put(self, path: str, **kwargs: Any) -> Callable[[F], F]: ...
    def delete(self, path: str, **kwargs: Any) -> Callable[[F], F]: ...
    def patch(self, path: str, **kwargs: Any) -> Callable[[F], F]: ...
    def head(self, path: str, **kwargs: Any) -> Callable[[F], F]: ...
    def options(self, path: str, **kwargs: Any) -> Callable[[F], F]: ...
    def websocket(self, path: str, **kwargs: Any) -> Callable[[F], F]: ...
    
    def middleware(
        self,
        func_or_type: Union[Callable, str, None] = None,
        *,
        type: str = "onion",
        priority: int = 50
    ) -> Callable[[F], F]: ...
    
    def add_middleware(self, middleware_class: type, **kwargs: Any) -> None: ...
    
    def exception(
        self,
        status_code_or_type: Union[int, type],
    ) -> Callable[[F], F]: ...
    
    def register_blueprint(self, blueprint: "Blueprint", *, url_prefix: Optional[str] = None) -> "Kewe": ...
    def include_router(self, router: "Blueprint", *, prefix: str = "", tags: Optional[list] = None) -> "Kewe": ...
    
    def startup(self, func: Optional[F] = None) -> Union[F, Callable[[F], F]]: ...
    def shutdown(self, func: Optional[F] = None) -> Union[F, Callable[[F], F]]: ...
    def before_server_start(self, func: Optional[F] = None, *, priority: int = 0) -> Union[F, Callable[[F], F]]: ...
    def after_server_start(self, func: Optional[F] = None, *, priority: int = 0) -> Union[F, Callable[[F], F]]: ...
    def before_server_stop(self, func: Optional[F] = None, *, priority: int = 0) -> Union[F, Callable[[F], F]]: ...
    def after_server_stop(self, func: Optional[F] = None, *, priority: int = 0) -> Union[F, Callable[[F], F]]: ...
    
    def static(self, url_prefix: str = "/static", directory: str = "./static", **kwargs: Any) -> None: ...
    def mount(self, path: str, app: "Kewe", *, name: Optional[str] = None) -> "Kewe": ...
    
    def cors(
        self,
        *,
        origins: Optional[List[str]] = None,
        methods: Optional[List[str]] = None,
        headers: Optional[List[str]] = None,
        expose_headers: Optional[List[str]] = None,
        max_age: Optional[int] = None,
        supports_credentials: bool = False,
        **kwargs: Any
    ) -> None: ...
    
    def run(
        self,
        host: str = "0.0.0.0",
        port: int = 8000,
        debug: bool = False,
        workers: int = 1,
        **kwargs: Any
    ) -> None: ...
    
    def url_for(self, name: str, **kwargs: Any) -> str: ...
    def make_response(self, data: Any = None, status: int = 200, headers: Optional[Dict[str, str]] = None) -> "Response": ...
    
    @property
    def test_client(self) -> "TestClient": ...
    
    @property
    def dependency_overrides(self) -> "DependencyOverrideManager": ...
    
    def setup_session(self, config: Any = None, session_interface: Any = None) -> "Kewe": ...
    
    async def __call__(
        self,
        scope: Dict[str, Any],
        receive: Callable,
        send: Callable
    ) -> None: ...


class KeweConfig:
    """Kewe 配置类"""
    
    host: str
    port: int
    workers: int
    debug: bool
    access_log: bool
    log_level: int
    log_json: bool
    auto_optimize: bool
    use_uvloop: bool
    request_timeout: float
    graceful_timeout: float
    keep_alive: bool
    keep_alive_timeout: float
    request_max_size: int
    request_max_size_json: int
    request_max_size_form: int
    request_max_size_multipart: int
    enable_gateway: bool
    gateway_prefix: str
    request_id_header: str
    request_id_format: str
    auto_request_id: bool
    enable_security_headers: bool
    enable_compression: bool
    compression_min_size: int
    compression_level: int
    secret_key: Optional[str]
    environment: str
    env_config_paths: Dict[str, str]
    extra: Dict[str, Any]
    
    def __init__(self, **kwargs: Any) -> None: ...
    def to_config(self) -> Any: ...
    def load_from_env(self) -> None: ...
    def load_for_environment(self, env: Optional[str] = None) -> None: ...


class UserAgent:
    """User-Agent 解析对象"""
    string: str
    browser: Optional[str]
    platform: Optional[str]
    version: Optional[str]
    def __init__(self, ua_string: str) -> None: ...
    def __str__(self) -> str: ...
    def __repr__(self) -> str: ...
    def __bool__(self) -> bool: ...


class Request:
    """HTTP 请求类"""
    
    method: str
    path: str
    headers: Dict[str, str]
    query_params: Dict[str, List[str]]
    client_ip: str
    protocol: str
    state: Any
    ctx: Any
    app: Any
    
    @property
    def receive(self) -> Optional[Callable]: ...
    
    @receive.setter
    def receive(self, value: Optional[Callable]) -> None: ...
    
    @property
    def url(self) -> "URL": ...
    
    @property
    def base_url(self) -> "URL": ...
    
    @property
    def scheme(self) -> str: ...
    
    @property
    def host(self) -> str: ...
    
    @property
    def query_string(self) -> str: ...
    
    @property
    def content_type(self) -> str: ...
    
    @property
    def is_secure(self) -> bool: ...
    
    @property
    def is_json(self) -> bool: ...
    
    @property
    def is_multipart(self) -> bool: ...
    
    @property
    def is_urlencoded(self) -> bool: ...
    
    @property
    def is_safe(self) -> bool: ...
    
    @property
    def is_idempotent(self) -> bool: ...
    
    @property
    def is_ajax(self) -> bool: ...
    
    @property
    def is_cacheable(self) -> bool: ...
    
    @property
    def user_agent(self) -> UserAgent: ...
    
    @property
    def accept(self) -> str: ...
    
    @property
    def accept_encodings(self) -> List[str]: ...
    
    @property
    def accept_languages(self) -> List[str]: ...
    
    @property
    def referer(self) -> str: ...
    
    @property
    def referrer(self) -> str: ...
    
    @property
    def root_path(self) -> str: ...
    
    @property
    def path_params(self) -> Dict[str, Any]: ...
    
    @property
    def args(self) -> Any: ...

    @property
    def cookies(self) -> Dict[str, str]: ...
    
    @property
    def session(self) -> Any: ...
    
    @session.setter
    def session(self, value: Any) -> None: ...
    
    @property
    def scope(self) -> Optional[Dict[str, Any]]: ...
    
    @property
    def client(self) -> Optional[tuple]: ...
    
    @property
    def server(self) -> Optional[tuple]: ...
    
    @property
    def user(self) -> Any: ...
    
    @property
    async def body(self) -> bytes: ...
    
    @property
    async def json(self) -> Optional[Any]: ...
    
    @property
    async def form(self) -> "FormData": ...
    
    async def files(self) -> Dict[str, List["UploadedFile"]]: ...
    
    async def stream(self, chunk_size: int = 8192) -> AsyncGenerator[bytes, None]: ...
    async def text(self, encoding: str = 'utf-8') -> str: ...
    async def read(self, max_size: Optional[int] = None) -> bytes: ...
    async def is_disconnected(self) -> bool: ...
    
    def get_header(self, name: str, default: Any = None) -> Any: ...
    def header(self, name: str, default: Any = None) -> Any: ...
    def get_cookie(self, name: str, default: Optional[str] = None) -> Optional[str]: ...
    def get(self, key: str, default: Any = None) -> Any: ...
    def getlist(self, key: str) -> List[str]: ...
    def url_for(self, name: str, **kwargs: Any) -> Optional[str]: ...


class FormData:
    """表单数据"""
    def get(self, name: str, default: Any = None) -> Any: ...
    def getlist(self, name: str) -> List[str]: ...
    def getfile(self, name: str) -> Optional["UploadedFile"]: ...
    def getfiles(self, name: str) -> List["UploadedFile"]: ...
    @property
    def files(self) -> Dict[str, List["UploadedFile"]]: ...
    @property
    def fields(self) -> Dict[str, List[str]]: ...


class UploadedFile:
    """上传文件"""
    name: str
    filename: str
    content_type: str
    body: bytes
    @property
    def size(self) -> int: ...
    def save(self, path: str, allowed_dir: Optional[str] = None) -> None: ...


class URL:
    """URL对象"""
    scheme: str
    netloc: str
    path: str
    params: str
    query: str
    fragment: str
    
    def __init__(self, url: str = "", **kwargs: Any) -> None: ...
    @property
    def hostname(self) -> Optional[str]: ...
    @property
    def port(self) -> Optional[int]: ...
    

class Response:
    """HTTP 响应类"""
    
    status: int
    body: bytes
    headers: Dict[str, str]
    content_type: str
    background: Optional["BackgroundTasks"]
    
    @property
    def status_code(self) -> int: ...
    
    @status_code.setter
    def status_code(self, value: int) -> None: ...
    
    @property
    def is_streaming(self) -> bool: ...
    
    def __init__(
        self,
        body: Union[str, bytes] = b"",
        status: int = 200,
        headers: Optional[Dict[str, str]] = None,
        content_type: str = "application/octet-stream"
    ) -> None: ...
    
    def set_header(self, name: str, value: Any) -> "Response": ...
    def get_header(self, name: str, default: Any = None) -> Any: ...
    def has_header(self, name: str) -> bool: ...
    def delete_header(self, name: str) -> "Response": ...
    
    def set_cookie(
        self,
        name: str,
        value: str,
        *,
        expires: Optional[Any] = None,
        max_age: Optional[int] = None,
        domain: Optional[str] = None,
        path: str = "/",
        secure: bool = True,
        httponly: bool = True,
        samesite: str = "Lax"
    ) -> "Response": ...
    
    def delete_cookie(
        self,
        name: str,
        *,
        domain: Optional[str] = None,
        path: str = "/",
        secure: bool = True,
        httponly: bool = True,
        samesite: str = "Lax"
    ) -> "Response": ...
    
    async def __call__(self, scope: Any, receive: Any, send: Any) -> None: ...


class JSONResponse(Response): ...
class HTMLResponse(Response): ...
class PlainTextResponse(Response): ...
class RedirectResponse(Response): ...
class StreamingResponse(Response): ...
class FileResponse(Response): ...
class ServerSentEventResponse(Response): ...
class ServerSentEvent: ...


class BackgroundTask:
    def __init__(self, func: Callable, *args: Any, **kwargs: Any) -> None: ...
    async def __call__(self) -> None: ...


class BackgroundTasks:
    def __init__(self, tasks: Optional[List[BackgroundTask]] = None) -> None: ...
    def add_task(self, func: Callable, *args: Any, **kwargs: Any) -> None: ...
    async def run(self) -> None: ...


class ServerSentEvent:
    def __init__(
        self,
        data: Optional[str] = None,
        event: Optional[str] = None,
        id: Optional[str] = None,
        retry: Optional[int] = None,
        comment: Optional[str] = None,
    ) -> None: ...
    def encode(self) -> bytes: ...


class Blueprint:
    """蓝图类"""
    
    name: str
    url_prefix: str
    host: Optional[str]
    routes: List[Any]
    middlewares: List[tuple]
    error_handlers: Dict[int, Callable]
    blueprints: List["Blueprint"]
    
    def __init__(
        self,
        name: str,
        url_prefix: str = "",
        host: Optional[str] = None,
        strict_slashes: bool = False
    ) -> None: ...
    
    def route(self, path: str, methods: Optional[List[str]] = None, **kwargs: Any) -> Callable[[F], F]: ...
    def get(self, uri: str, **kwargs: Any) -> Callable[[F], F]: ...
    def post(self, uri: str, **kwargs: Any) -> Callable[[F], F]: ...
    def put(self, uri: str, **kwargs: Any) -> Callable[[F], F]: ...
    def delete(self, uri: str, **kwargs: Any) -> Callable[[F], F]: ...
    def patch(self, uri: str, **kwargs: Any) -> Callable[[F], F]: ...
    def head(self, uri: str, **kwargs: Any) -> Callable[[F], F]: ...
    def options(self, uri: str, **kwargs: Any) -> Callable[[F], F]: ...
    def middleware(self, middleware_or_request: Union[Callable, str, None] = None, attach_to: str = "request") -> Callable[[F], F]: ...
    def exception(self, status_code: int) -> Callable[[F], F]: ...
    def register(self, app: Kewe, url_prefix: str = "", host: Optional[str] = None) -> None: ...


class Router:
    """路由器类"""
    
    def __init__(self) -> None: ...
    def route(self, path: str, methods: Optional[List[str]] = None, **kwargs: Any) -> Callable[[F], F]: ...
    def get(self, path: str, **kwargs: Any) -> Callable[[F], F]: ...
    def post(self, path: str, **kwargs: Any) -> Callable[[F], F]: ...
    def put(self, path: str, **kwargs: Any) -> Callable[[F], F]: ...
    def delete(self, path: str, **kwargs: Any) -> Callable[[F], F]: ...
    def patch(self, path: str, **kwargs: Any) -> Callable[[F], F]: ...
    def head(self, path: str, **kwargs: Any) -> Callable[[F], F]: ...
    def options(self, path: str, **kwargs: Any) -> Callable[[F], F]: ...
    def websocket(self, path: str, **kwargs: Any) -> Callable[[F], F]: ...
    
    def add_route(
        self,
        path: str,
        methods: List[str],
        handler: Callable,
        *,
        name: Optional[str] = None,
        host: Optional[str] = None,
        strict_slashes: bool = False,
        middlewares: Optional[List[Callable]] = None
    ) -> None: ...
    
    def add_websocket_route(self, path: str, handler: Callable, **kwargs: Any) -> None: ...
    def find_route(self, path: str, method: str) -> Optional[Any]: ...
    def url_for(self, name: str, **kwargs: Any) -> str: ...
    def get_allowed_methods(self, path: str) -> List[str]: ...
    
    @property
    def routes(self) -> List[Any]: ...


class MiddlewareManager:
    """中间件管理器"""
    
    def __init__(self) -> None: ...
    
    def register(
        self,
        middleware: Callable,
        *,
        attach_to: str = "request",
        priority: int = 50
    ) -> None: ...
    
    async def process_request(self, request: Request) -> Optional[Response]: ...
    async def process_response(self, request: Request, response: Response) -> Response: ...


class WebSocketConnection:
    """WebSocket 连接类"""
    
    path: str
    query_string: str
    headers: Dict[str, str]
    state: "WebSocketState"
    ctx: Any
    id: int
    
    @property
    def open(self) -> bool: ...
    
    async def accept(self, subprotocol: Optional[str] = None) -> None: ...
    async def send(self, data: Union[str, bytes, Dict]) -> None: ...
    async def send_json(self, data: Any) -> None: ...
    async def receive(self) -> Optional["WebSocketMessage"]: ...
    async def close(self, code: int = 1000, reason: str = "") -> None: ...
    
    def __aiter__(self) -> "WebSocketConnection": ...
    async def __anext__(self) -> "WebSocketMessage": ...


class WebSocketState:
    """WebSocket 状态枚举"""
    CONNECTING: int
    CONNECTED: int
    DISCONNECTING: int
    DISCONNECTED: int


class WebSocketMessage:
    """WebSocket 消息"""
    type: str
    data: Union[str, bytes]


class WebSocketManager:
    """WebSocket 管理器"""
    
    connections: set
    rooms: Dict[str, set]
    
    def create_room(self, name: str) -> None: ...
    def remove_room(self, name: str) -> None: ...
    def join_room(self, room: str, connection: WebSocketConnection) -> None: ...
    def leave_room(self, room: str, connection: WebSocketConnection) -> None: ...
    async def broadcast(self, message: str) -> None: ...
    async def broadcast_to_room(self, room: str, message: str) -> None: ...
    async def close_all(self, code: int = 1000, reason: str = "") -> None: ...


class Depends:
    """依赖声明"""
    dependency: Optional[Callable]
    use_cache: bool
    
    def __init__(self, dependency: Optional[Callable] = None, *, use_cache: bool = True) -> None: ...


class Query:
    """查询参数依赖"""
    def __init__(self, default: Any = ..., *, alias: Optional[str] = None, **kwargs: Any) -> None: ...


class Header:
    """请求头依赖"""
    def __init__(self, default: Any = ..., *, alias: Optional[str] = None, **kwargs: Any) -> None: ...


class Cookie:
    """Cookie依赖"""
    def __init__(self, default: Any = ..., *, alias: Optional[str] = None, **kwargs: Any) -> None: ...


class Path:
    """路径参数依赖"""
    def __init__(self, default: Any = ..., *, alias: Optional[str] = None, **kwargs: Any) -> None: ...


class Body:
    """请求体依赖"""
    def __init__(self, default: Any = ..., *, alias: Optional[str] = None, **kwargs: Any) -> None: ...


class Form:
    """表单参数依赖"""
    def __init__(self, default: Any = ..., *, alias: Optional[str] = None, **kwargs: Any) -> None: ...


class File:
    """文件上传依赖"""
    def __init__(self, default: Any = ..., *, alias: Optional[str] = None, **kwargs: Any) -> None: ...


class Security(Depends):
    """安全依赖"""
    def __init__(self, dependency: Optional[Callable] = None, *, scopes: Optional[List[str]] = None, use_cache: bool = True) -> None: ...


class DependencyResolver:
    """依赖解析器"""
    def override(self, dependency: Callable, override: Callable) -> None: ...
    def clear_overrides(self) -> None: ...
    async def resolve(self, dependency: Callable, request: Any = None, app: Any = None) -> Any: ...
    async def resolve_handler(self, handler: Callable, request: Any = None, app: Any = None) -> Dict[str, Any]: ...


class DependencyOverrideManager:
    """依赖覆盖管理器"""
    def __setitem__(self, dependency: Callable, override: Callable) -> None: ...
    def __delitem__(self, dependency: Callable) -> None: ...
    def clear(self) -> None: ...


class TestClient:
    """同步测试客户端"""
    __test__: bool
    
    def __init__(self, app: Any, *, base_url: str = "http://testserver", raise_server_exceptions: bool = True) -> None: ...
    def __enter__(self) -> "TestClient": ...
    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None: ...
    async def __aenter__(self) -> "TestClient": ...
    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None: ...
    
    def get(self, path: str, *, headers: Optional[Dict[str, str]] = None, query: Optional[Dict[str, str]] = None) -> "TestResponse": ...
    def post(self, path: str, *, data: Any = None, headers: Optional[Dict[str, str]] = None, json: Optional[Dict] = None, files: Optional[Dict] = None) -> "TestResponse": ...
    def put(self, path: str, *, data: Any = None, headers: Optional[Dict[str, str]] = None, json: Optional[Dict] = None) -> "TestResponse": ...
    def delete(self, path: str, *, headers: Optional[Dict[str, str]] = None, query: Optional[Dict[str, str]] = None) -> "TestResponse": ...
    def patch(self, path: str, *, data: Any = None, headers: Optional[Dict[str, str]] = None, json: Optional[Dict] = None) -> "TestResponse": ...
    def head(self, path: str, *, headers: Optional[Dict[str, str]] = None, query: Optional[Dict[str, str]] = None) -> "TestResponse": ...
    def options(self, path: str, *, headers: Optional[Dict[str, str]] = None, query: Optional[Dict[str, str]] = None) -> "TestResponse": ...
    def websocket(self, path: str, headers: Optional[Dict[str, str]] = None, subprotocols: Optional[List[str]] = None) -> "TestWebSocket": ...


class AsyncTestClient:
    """异步测试客户端"""
    
    def __init__(self, app: Any, *, base_url: str = "http://testserver", raise_server_exceptions: bool = True) -> None: ...
    async def __aenter__(self) -> "AsyncTestClient": ...
    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None: ...
    
    async def get(self, path: str, *, headers: Optional[Dict[str, str]] = None, query: Optional[Dict[str, str]] = None) -> "TestResponse": ...
    async def post(self, path: str, *, data: Any = None, headers: Optional[Dict[str, str]] = None, json: Optional[Dict] = None, files: Optional[Dict] = None) -> "TestResponse": ...
    async def put(self, path: str, *, data: Any = None, headers: Optional[Dict[str, str]] = None, json: Optional[Dict] = None) -> "TestResponse": ...
    async def delete(self, path: str, *, headers: Optional[Dict[str, str]] = None, query: Optional[Dict[str, str]] = None) -> "TestResponse": ...
    async def patch(self, path: str, *, data: Any = None, headers: Optional[Dict[str, str]] = None, json: Optional[Dict] = None) -> "TestResponse": ...
    async def head(self, path: str, *, headers: Optional[Dict[str, str]] = None, query: Optional[Dict[str, str]] = None) -> "TestResponse": ...
    async def options(self, path: str, *, headers: Optional[Dict[str, str]] = None, query: Optional[Dict[str, str]] = None) -> "TestResponse": ...
    async def websocket(self, path: str, headers: Optional[Dict[str, str]] = None, subprotocols: Optional[List[str]] = None) -> "TestWebSocket": ...


class TestResponse:
    """测试响应"""
    status: int
    headers: Any
    body: bytes
    content_type: str
    
    @property
    def text(self) -> str: ...
    
    @property
    def json(self) -> Any: ...
    
    def raise_for_status(self) -> "TestResponse": ...


class TestWebSocket:
    """测试WebSocket"""
    async def connect(self, headers: Optional[Dict[str, str]] = None, subprotocols: Optional[List[str]] = None) -> "TestWebSocket": ...
    async def send_text(self, text: str) -> None: ...
    async def send_bytes(self, data: bytes) -> None: ...
    async def send_json(self, data: Any) -> None: ...
    async def receive(self, timeout: float = 5.0) -> Optional[Any]: ...
    async def receive_text(self, timeout: float = 5.0) -> Optional[str]: ...
    async def receive_json(self, timeout: float = 5.0) -> Any: ...
    async def close(self, code: int = 1000, reason: str = "") -> None: ...
    
    @property
    def closed(self) -> bool: ...
    
    @property
    def close_code(self) -> Optional[int]: ...


class AppState:
    """应用状态"""
    def __getattr__(self, name: str) -> Any: ...
    def __setattr__(self, name: str, value: Any) -> None: ...


def json(
    data: Any = None,
    *,
    status: int = 200,
    headers: Optional[Dict[str, str]] = None,
    **kwargs: Any
) -> Response: ...


def text(
    text_str: str = "",
    *,
    status: int = 200,
    headers: Optional[Dict[str, str]] = None,
    content_type: str = "text/plain"
) -> Response: ...


def html(
    html_str: str = "",
    *,
    status: int = 200,
    headers: Optional[Dict[str, str]] = None
) -> Response: ...


def redirect(
    url: str,
    *,
    status: int = 302,
    headers: Optional[Dict[str, str]] = None
) -> Response: ...


async def file(
    path: str,
    filename: Optional[str] = None,
    mime_type: Optional[str] = None,
    attachment: bool = False,
    base_dir: Optional[str] = None
) -> Response: ...


def stream(
    streaming_fn: Callable[[], Awaitable[None]],
    *,
    status: int = 200,
    headers: Optional[Dict[str, str]] = None,
    content_type: str = "text/plain"
) -> Response: ...


class KeweException(Exception):
    """Kewe 异常基类"""
    
    status_code: int
    message: str
    detail: Any
    error_code: Optional[str]
    context: Dict[str, Any]
    headers: Dict[str, str]
    
    def __init__(
        self,
        message: Optional[str] = None,
        status_code: int = 500,
        context: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
        detail: Any = None,
        error_code: Optional[str] = None
    ) -> None: ...
    
    def to_problem_details(self, request_path: str = "") -> Dict[str, Any]: ...
    def get_headers(self) -> Dict[str, str]: ...


class HTTPException(KeweException):
    """HTTP异常"""
    def __init__(self, status_code: int = 500, detail: Any = None, headers: Optional[Dict[str, str]] = None) -> None: ...


class RequestValidationError(KeweException):
    """请求验证错误"""
    errors: Any
    def __init__(self, errors: Any = None, message: str = "Validation Error") -> None: ...


class BadRequest(KeweException): ...
class Unauthorized(KeweException): ...
class Forbidden(KeweException): ...
class NotFound(KeweException): ...
class MethodNotAllowed(KeweException): ...
class Conflict(KeweException): ...
class Gone(KeweException): ...
class PayloadTooLarge(KeweException): ...
class UnsupportedMediaType(KeweException): ...
class UnprocessableEntity(KeweException): ...
class TooManyRequests(KeweException): ...
class InternalServerError(KeweException): ...
class ServiceUnavailable(KeweException): ...
class BadGateway(KeweException): ...
class GatewayTimeout(KeweException): ...


def abort(status_code: int, message: Optional[str] = None, detail: Optional[str] = None, headers: Optional[Dict[str, str]] = None) -> None: ...


class CircuitOpenError(KeweException):
    """熔断器打开异常"""
    name: str
    retry_after: Optional[int]
    def __init__(self, name: str = "default", retry_after: Optional[int] = None) -> None: ...


class CircuitBreakerConfig:
    """熔断器配置"""
    failure_threshold: int
    recovery_timeout: float
    half_open_max_calls: int
    success_threshold: int
    window_size: float

class CircuitBreaker:
    """熔断器"""
    name: str
    config: CircuitBreakerConfig
    
    def __init__(self, name: str = "default", config: Optional[CircuitBreakerConfig] = None, **kwargs: Any) -> None: ...
    async def call(self, func: Callable, *args: Any, **kwargs: Any) -> Any: ...
    def call_sync(self, func: Callable, *args: Any, **kwargs: Any) -> Any: ...
    def reset(self) -> None: ...
    def force_open(self) -> None: ...
    def get_status(self) -> Dict[str, Any]: ...

class CircuitBreakerRegistry:
    """熔断器注册表"""
    @classmethod
    def get_instance(cls) -> "CircuitBreakerRegistry": ...
    def get_or_create(self, name: str, config: Optional[CircuitBreakerConfig] = None, fallback: Optional[Callable] = None) -> CircuitBreaker: ...
    def get(self, name: str) -> Optional[CircuitBreaker]: ...
    def get_all_status(self) -> Dict[str, Dict[str, Any]]: ...
    def reset_all(self) -> None: ...


class AuditAction:
    """审计动作枚举"""
    CREATE: str
    READ: str
    UPDATE: str
    DELETE: str
    LOGIN: str
    LOGOUT: str
    LOGIN_FAILED: str
    PERMISSION_CHANGE: str
    ROLE_CHANGE: str
    CONFIG_CHANGE: str
    EXPORT: str
    IMPORT: str
    CUSTOM: str

class AuditSeverity:
    """审计严重级别枚举"""
    LOW: str
    MEDIUM: str
    HIGH: str
    CRITICAL: str

class AuditLogEntry:
    """审计日志条目"""
    timestamp: int
    event_type: str
    user_id: str
    jti: Optional[str]
    ip_address: Optional[str]
    device_fingerprint: Optional[str]
    details: Dict[str, Any]

class AuditLogManager:
    """审计日志管理器"""
    def __init__(self) -> None: ...
    def log(self, event_type: str, user_id: str, **kwargs: Any) -> AuditLogEntry: ...
    def get_logs(self, user_id: Optional[str] = None, event_type: Optional[str] = None, limit: int = 100) -> List[AuditLogEntry]: ...
    def cleanup_old_logs(self, retention_days: int = 30) -> int: ...
    def get_stats(self) -> Dict[str, Any]: ...


class MetricsManager:
    """指标管理器"""
    def add_request(self, method: str, path: str, status: int, response_time: float, is_error: bool = False) -> None: ...
    def get_metrics(self) -> Dict[str, Any]: ...
    def reset_metrics(self) -> None: ...
    def set_custom_metric(self, name: str, value: float) -> None: ...
    def increment_custom_metric(self, name: str, value: float = 1.0) -> None: ...


class CacheManager:
    """缓存管理器"""
    def add_backend(self, name: str, backend: Any) -> None: ...
    def set_default_backend(self, name: str) -> None: ...
    def get_backend(self, name: Optional[str] = None) -> Any: ...
    def get(self, key: str, backend: Optional[str] = None) -> Optional[Any]: ...
    def set(self, key: str, value: Any, ttl: Optional[int] = None, backend: Optional[str] = None) -> None: ...
    def delete(self, key: str, backend: Optional[str] = None) -> None: ...
    def clear(self, backend: Optional[str] = None) -> None: ...
    def exists(self, key: str, backend: Optional[str] = None) -> bool: ...


__all__ = [
    'Kewe',
    'KeweConfig',
    'Request',
    'Response',
    'Blueprint',
    'Router',
    'MiddlewareManager',
    'WebSocketConnection',
    'WebSocketState',
    'WebSocketMessage',
    'WebSocketManager',
    'Depends',
    'Query',
    'Header',
    'Cookie',
    'Path',
    'Body',
    'Form',
    'File',
    'Security',
    'DependencyResolver',
    'DependencyOverrideManager',
    'TestClient',
    'AsyncTestClient',
    'TestResponse',
    'TestWebSocket',
    'AppState',
    'JSONResponse',
    'HTMLResponse',
    'PlainTextResponse',
    'RedirectResponse',
    'StreamingResponse',
    'FileResponse',
    'ServerSentEventResponse',
    'ServerSentEvent',
    'BackgroundTask',
    'BackgroundTasks',
    'ServerSentEvent',
    'URL',
    'FormData',
    'UploadedFile',
    'json',
    'text',
    'html',
    'redirect',
    'file',
    'stream',
    'KeweException',
    'HTTPException',
    'RequestValidationError',
    'BadRequest',
    'Unauthorized',
    'Forbidden',
    'NotFound',
    'MethodNotAllowed',
    'Conflict',
    'Gone',
    'PayloadTooLarge',
    'UnsupportedMediaType',
    'UnprocessableEntity',
    'TooManyRequests',
    'InternalServerError',
    'ServiceUnavailable',
    'BadGateway',
    'GatewayTimeout',
    'CircuitOpenError',
    'CircuitBreakerConfig',
    'CircuitBreaker',
    'CircuitBreakerRegistry',
    'AuditAction',
    'AuditSeverity',
    'AuditLogEntry',
    'AuditLogManager',
    'MetricsManager',
    'CacheManager',
    'abort',
]
