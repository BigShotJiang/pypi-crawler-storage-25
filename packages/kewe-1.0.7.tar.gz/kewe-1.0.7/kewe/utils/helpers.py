#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.utils.helpers - General utility helpers for string, byte, and duration formatting
"""

import os
import sys
import re
import importlib
import importlib.util
import logging
from typing import Any, Optional, Type, Callable, Dict, List, Union
from pathlib import Path

logger = logging.getLogger(__name__)


def import_string(dotted_path: str) -> Any:
    """
    从字符串导入模块或类
    
    使用示例:
        User = import_string('myapp.models.User')
        func = import_string('myapp.utils.helper_function')
    
    Args:
        dotted_path: 点分隔的导入路径
        
    Returns:
        导入的模块、类或函数
        
    Raises:
        ImportError: 导入失败时
    """
    try:
        module_path, class_name = dotted_path.rsplit('.', 1)
    except ValueError as e:
        raise ImportError(
            f"{dotted_path} doesn't look like a module path"
        ) from e
    
    module = importlib.import_module(module_path)
    
    try:
        return getattr(module, class_name)
    except AttributeError as e:
        raise ImportError(
            f'Module "{module_path}" does not define a "{class_name}" attribute/class'
        ) from e


def load_module_from_file_location(name: str, location: str) -> Any:
    """
    从文件位置加载模块
    
    使用示例:
        mymodule = load_module_from_file_location('mymodule', '/path/to/mymodule.py')
    
    Args:
        name: 模块名称
        location: 文件路径
        
    Returns:
        加载的模块
    """
    spec = importlib.util.spec_from_file_location(name, location)
    if spec is None:
        raise ImportError(f"Cannot load module from {location}")
    
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    
    return module


def is_atty(stream) -> bool:
    """
    检查流是否是TTY（终端）
    
    Args:
        stream: 流对象
        
    Returns:
        是否是TTY
    """
    try:
        return stream.isatty()
    except AttributeError:
        return False


def has_color_support(stream) -> bool:
    """
    检查流是否支持颜色输出
    
    Args:
        stream: 流对象
        
    Returns:
        是否支持颜色
    """
    if not is_atty(stream):
        return False
    
    # 检查环境变量
    if os.environ.get('NO_COLOR'):
        return False
    
    if os.environ.get('FORCE_COLOR'):
        return True
    
    # Windows检测
    if sys.platform == 'win32':
        return True
    
    # 检查TERM环境变量
    term = os.environ.get('TERM', '')
    if 'color' in term.lower():
        return True
    
    return True


def walk_modules(
    package_path: str,
    include_packages: bool = False,
    recursive: bool = True
) -> List[str]:
    """
    遍历包中的所有模块
    
    Args:
        package_path: 包路径
        include_packages: 是否包含子包
        recursive: 是否递归遍历
        
    Returns:
        模块名称列表
    """
    modules = []
    package_dir = Path(package_path)
    
    if not package_dir.is_dir():
        return modules
    
    for root, dirs, files in os.walk(package_dir):
        # 跳过隐藏目录和__pycache__
        dirs[:] = [d for d in dirs if not d.startswith('.') and d != '__pycache__']
        
        # 计算相对路径
        relative_path = Path(root).relative_to(package_dir.parent)
        package_name = '.'.join(relative_path.parts)
        
        # 添加Python文件
        for file in files:
            if file.endswith('.py') and not file.startswith('_'):
                module_name = file[:-3]  # 去掉.py
                if package_name:
                    full_name = f"{package_name}.{module_name}"
                else:
                    full_name = module_name
                modules.append(full_name)
        
        # 添加包
        if include_packages:
            for dir_name in dirs:
                if not dir_name.startswith('_'):
                    if package_name:
                        full_name = f"{package_name}.{dir_name}"
                    else:
                        full_name = dir_name
                    modules.append(full_name)
        
        if not recursive:
            break
    
    return modules


def get_root_path(import_name: str) -> str:
    mod = sys.modules.get(import_name)
    if mod is not None and hasattr(mod, '__file__'):
        return os.path.dirname(os.path.abspath(mod.__file__))
    
    try:
        spec = importlib.util.find_spec(import_name)
    except (ModuleNotFoundError, ValueError):
        spec = None
    
    if spec is None or import_name == '__main__':
        return os.getcwd()
    
    if spec.origin:
        return os.path.dirname(os.path.abspath(spec.origin))
    
    if spec.submodule_search_locations:
        return spec.submodule_search_locations[0]
    
    __import__(import_name)
    mod = sys.modules[import_name]
    filepath = getattr(mod, '__file__', None)
    if filepath is None:
        raise RuntimeError(f"Cannot find root path for {import_name}")
    
    return os.path.dirname(os.path.abspath(filepath))


def get_env_bool(name: str, default: bool = False) -> bool:
    """
    获取布尔类型的环境变量
    
    Args:
        name: 环境变量名
        default: 默认值
        
    Returns:
        布尔值
    """
    value = os.environ.get(name)
    if value is None:
        return default
    
    return value.lower() in ('true', '1', 'yes', 'on', 'enabled')


def get_env_int(name: str, default: int = 0) -> int:
    """
    获取整数类型的环境变量
    
    Args:
        name: 环境变量名
        default: 默认值
        
    Returns:
        整数值
    """
    value = os.environ.get(name)
    if value is None:
        return default
    
    try:
        return int(value)
    except ValueError:
        return default


def get_env_list(
    name: str,
    default: Optional[List[str]] = None,
    separator: str = ','
) -> List[str]:
    """
    获取列表类型的环境变量
    
    Args:
        name: 环境变量名
        default: 默认值
        separator: 分隔符
        
    Returns:
        字符串列表
    """
    if default is None:
        default = []
    
    value = os.environ.get(name)
    if value is None:
        return default
    
    return [item.strip() for item in value.split(separator) if item.strip()]


def to_camel_case(snake_str: str) -> str:
    """
    将蛇形命名转换为驼峰命名
    
    Args:
        snake_str: 蛇形命名字符串
        
    Returns:
        驼峰命名字符串
    """
    components = snake_str.split('_')
    return components[0] + ''.join(x.title() for x in components[1:])


def to_snake_case(camel_str: str) -> str:
    """
    将驼峰命名转换为蛇形命名
    
    Args:
        camel_str: 驼峰命名字符串
        
    Returns:
        蛇形命名字符串
    """
    s1 = re.sub('(.)([A-Z][a-z]+)', r'\1_\2', camel_str)
    return re.sub('([a-z0-9])([A-Z])', r'\1_\2', s1).lower()


def slugify(value: str, allow_unicode: bool = False) -> str:
    """
    将字符串转换为slug格式
    
    Args:
        value: 输入字符串
        allow_unicode: 是否允许Unicode字符
        
    Returns:
        slug格式字符串
    """
    import unicodedata
    
    if allow_unicode:
        value = unicodedata.normalize('NFKC', value)
    else:
        value = unicodedata.normalize('NFKD', value)
        value = value.encode('ascii', 'ignore').decode('ascii')
    
    value = re.sub(r'[^\w\s-]', '', value.lower())
    return re.sub(r'[-\s]+', '-', value).strip('-_')


def humanize_bytes(size: int, precision: int = 2) -> str:
    """
    将字节数转换为人类可读的格式
    
    Args:
        size: 字节数
        precision: 小数精度
        
    Returns:
        人类可读的字符串
    """
    suffixes = ['B', 'KB', 'MB', 'GB', 'TB', 'PB']
    suffix_index = 0
    
    while size >= 1024 and suffix_index < len(suffixes) - 1:
        size /= 1024.0
        suffix_index += 1
    
    return f"{size:.{precision}f} {suffixes[suffix_index]}"


def humanize_duration(seconds: float, precision: int = 0) -> str:
    """
    将秒数转换为人类可读的持续时间格式
    
    Args:
        seconds: 秒数
        precision: 小数精度
        
    Returns:
        人类可读的字符串
    """
    units = [
        ('year', 60 * 60 * 24 * 365),
        ('day', 60 * 60 * 24),
        ('hour', 60 * 60),
        ('minute', 60),
        ('second', 1),
    ]
    
    for name, count in units:
        if seconds >= count:
            value = seconds / count
            if precision == 0:
                value = int(value)
            return f"{value:.{precision}f} {name}{'s' if value != 1 else ''}"
    
    return f"{seconds:.{precision}f} second{'s' if seconds != 1 else ''}"


def truncate_string(text: str, max_length: int, suffix: str = '...') -> str:
    """
    截断字符串
    
    Args:
        text: 原始字符串
        max_length: 最大长度
        suffix: 截断后缀
        
    Returns:
        截断后的字符串
    """
    if len(text) <= max_length:
        return text
    
    return text[:max_length - len(suffix)] + suffix


def ensure_dir(path: str) -> str:
    """
    确保目录存在，如果不存在则创建
    
    Args:
        path: 目录路径
        
    Returns:
        目录路径
    """
    os.makedirs(path, exist_ok=True)
    return path


def clean_filename(filename: str) -> str:
    """
    清理文件名，移除不安全字符
    
    Args:
        filename: 原始文件名
        
    Returns:
        清理后的文件名
    """
    # 移除路径分隔符和其他不安全字符
    filename = re.sub(r'[\\/*?:"<>|]', '', filename)
    # 移除控制字符
    filename = ''.join(char for char in filename if ord(char) >= 32)
    # 移除首尾空格和点
    filename = filename.strip(' .')
    # 限制长度
    return truncate_string(filename, 255)


def merge_dicts(base: Dict, override: Dict) -> Dict:
    """
    深度合并字典
    
    Args:
        base: 基础字典
        override: 覆盖字典
        
    Returns:
        合并后的字典
    """
    result = base.copy()
    
    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = merge_dicts(result[key], value)
        else:
            result[key] = value
    
    return result


def flatten_dict(
    d: Dict,
    parent_key: str = '',
    sep: str = '.'
) -> Dict[str, Any]:
    """
    扁平化嵌套字典
    
    Args:
        d: 嵌套字典
        parent_key: 父键
        sep: 分隔符
        
    Returns:
        扁平化字典
    """
    items = []
    for k, v in d.items():
        new_key = f"{parent_key}{sep}{k}" if parent_key else k
        if isinstance(v, dict):
            items.extend(flatten_dict(v, new_key, sep=sep).items())
        else:
            items.append((new_key, v))
    return dict(items)


def unflatten_dict(
    d: Dict[str, Any],
    sep: str = '.'
) -> Dict:
    """
    将扁平化字典还原为嵌套字典
    
    Args:
        d: 扁平化字典
        sep: 分隔符
        
    Returns:
        嵌套字典
    """
    result = {}
    for key, value in d.items():
        parts = key.split(sep)
        target = result
        for part in parts[:-1]:
            if part not in target:
                target[part] = {}
            target = target[part]
        target[parts[-1]] = value
    return result


def memoize(func: Callable = None, *, maxsize: int = 128):
    if func is None:
        return lambda f: memoize(f, maxsize=maxsize)
    
    from functools import lru_cache
    cached = lru_cache(maxsize=maxsize)(func)
    cached.__name__ = func.__name__
    cached.__doc__ = func.__doc__
    return cached


def retry(
    max_attempts: int = 3,
    delay: float = 1.0,
    exceptions: tuple = (Exception,)
):
    """
    重试装饰器
    
    Args:
        max_attempts: 最大尝试次数
        delay: 重试延迟（秒）
        exceptions: 捕获的异常类型
        
    Returns:
        装饰器
    """
    import time
    
    def decorator(func: Callable):
        def wrapper(*args, **kwargs):
            attempts = 0
            while attempts < max_attempts:
                try:
                    return func(*args, **kwargs)
                except exceptions as e:
                    attempts += 1
                    if attempts >= max_attempts:
                        raise
                    logger.warning(
                        f"Attempt {attempts} failed: {e}. Retrying in {delay}s..."
                    )
                    time.sleep(delay)
            return None
        return wrapper
    return decorator


# 便捷导入
__all__ = [
    'import_string',
    'load_module_from_file_location',
    'is_atty',
    'has_color_support',
    'walk_modules',
    'get_root_path',
    'get_env_bool',
    'get_env_int',
    'get_env_list',
    'to_camel_case',
    'to_snake_case',
    'slugify',
    'humanize_bytes',
    'humanize_duration',
    'truncate_string',
    'ensure_dir',
    'clean_filename',
    'merge_dicts',
    'flatten_dict',
    'unflatten_dict',
    'memoize',
    'retry',
]
