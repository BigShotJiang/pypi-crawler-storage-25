#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.utils.i18n - Internationalization and localization support
"""

from kewe.utils.compat import json
import os
from typing import Dict, Optional, Any, Callable
from dataclasses import dataclass
from pathlib import Path
from contextvars import ContextVar


@dataclass
class I18nConfig:
    default_locale: str = "en"
    supported_locales: list = None
    translations_dir: str = "./translations"
    fallback_locale: str = "en"
    fallback_chain: list = None

    def __post_init__(self):
        if self.supported_locales is None:
            self.supported_locales = ["en", "zh", "ja", "ko", "de", "fr", "es"]
        if self.fallback_chain is None:
            self.fallback_chain = [self.fallback_locale]


_current_locale_var: ContextVar[str] = ContextVar('current_locale', default='en')


class I18n:
    
    def __init__(self, config: I18nConfig = None):
        self.config = config or I18nConfig()
        self._translations: Dict[str, Dict] = {}
        self._load_translations()
        _current_locale_var.set(self.config.default_locale)
    
    def _load_translations(self):
        translations_path = Path(self.config.translations_dir)
        
        if not translations_path.exists():
            return
        
        for locale in self.config.supported_locales:
            file_path = translations_path / f"{locale}.json"
            if file_path.exists():
                with open(file_path, 'r', encoding='utf-8') as f:
                    self._translations[locale] = json.load(f)
    
    def gettext(self, key: str, locale: str = None, **kwargs) -> str:
        locale = locale or _current_locale_var.get(self.config.default_locale)
        
        translation = self._translations.get(locale, {}).get(key)
        if translation and translation != key:
            if kwargs:
                try:
                    return translation.format(**kwargs)
                except KeyError:
                    return translation
            return translation

        base_locale = locale.replace('_', '-').split('-')[0] if ('-' in locale or '_' in locale) else None
        if base_locale and base_locale != locale:
            translation = self._translations.get(base_locale, {}).get(key)
            if translation and translation != key:
                if kwargs:
                    try:
                        return translation.format(**kwargs)
                    except KeyError:
                        return translation
                return translation

        for fallback in self.config.fallback_chain:
            if fallback == locale or fallback == base_locale:
                continue
            translation = self._translations.get(fallback, {}).get(key)
            if translation and translation != key:
                if kwargs:
                    try:
                        return translation.format(**kwargs)
                    except KeyError:
                        return translation
                return translation

        if kwargs:
            try:
                return key.format(**kwargs)
            except KeyError:
                pass
        
        return key

    def ngettext(self, singular: str, plural: str, n: int, locale: str = None, **kwargs) -> str:
        locale = locale or _current_locale_var.get(self.config.default_locale)
        form = self._get_plural_form(n, locale)

        translations = self._translations.get(locale, {})
        key = singular
        entry = translations.get(key)

        if isinstance(entry, dict):
            result = entry.get(form, entry.get('other', plural))
        elif isinstance(entry, list) and len(entry) >= 2:
            result = entry[1] if n != 1 else entry[0]
        else:
            result = plural if n != 1 else singular

        if kwargs:
            try:
                return result.format(n=n, **kwargs)
            except KeyError:
                return result
        return result

    def _get_plural_form(self, n: int, locale: str) -> str:
        if n == 0:
            return 'zero'
        if n == 1:
            return 'one'

        lang = locale.replace('_', '-').split('-')[0].lower()

        if lang in ('zh', 'ja', 'ko'):
            return 'other'
        if lang in ('ru', 'uk', 'pl'):
            n_abs = abs(n) % 100
            if 11 <= n_abs <= 19:
                return 'many'
            n_last = n_abs % 10
            if n_last == 1:
                return 'one'
            if 2 <= n_last <= 4:
                return 'few'
            return 'many'
        if lang in ('ar',):
            if n == 0:
                return 'zero'
            if n == 1:
                return 'one'
            if n == 2:
                return 'two'
            if 3 <= n % 100 <= 10:
                return 'few'
            if 11 <= n % 100 <= 99:
                return 'many'
            return 'other'

        return 'other'

    def set_locale(self, locale: str):
        if locale in self.config.supported_locales:
            _current_locale_var.set(locale)
    
    def get_locale(self) -> str:
        return _current_locale_var.get(self.config.default_locale)
    
    def add_translation(self, locale: str, key: str, value: str):
        if locale not in self._translations:
            self._translations[locale] = {}
        self._translations[locale][key] = value


_ = None


def setup_i18n(app, config: I18nConfig = None):
    global _
    i18n = I18n(config)
    _ = i18n.gettext
    
    @app.middleware("request")
    async def set_locale_from_request(request):
        locale = request.headers.get('Accept-Language', '').split(',')[0].split('-')[0]
        if locale in i18n.config.supported_locales:
            i18n.set_locale(locale)
        request.i18n = i18n

    return i18n


__all__ = [
    "I18n",
    "I18nConfig",
    "setup_i18n",
    "_",
]
