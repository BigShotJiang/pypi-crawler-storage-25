#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.utils.token_encryptor - Token encryption and decryption utilities
"""

import base64
import hashlib
import secrets
from typing import Optional

try:
    from cryptography.fernet import Fernet
    HAS_CRYPTOGRAPHY = True
except ImportError:
    HAS_CRYPTOGRAPHY = False

from kewe.logging.logger import get_logger


class TokenEncryptor:

    def __init__(self, secret_key: Optional[str] = None):
        if not HAS_CRYPTOGRAPHY:
            raise ImportError(
                "cryptography is required for TokenEncryptor. "
                "Install it with: pip install kewe[security]"
            )
        if secret_key:
            key = base64.urlsafe_b64encode(hashlib.sha256(secret_key.encode()).digest())
            self.fernet = Fernet(key)
        else:
            self.fernet = Fernet(Fernet.generate_key())
        self.logger = get_logger(__name__)

    def encrypt(self, data: str) -> str:
        """
        加密数据

        Args:
            data: 要加密的数据

        Returns:
            加密后的数据
        """
        try:
            return self.fernet.encrypt(data.encode()).decode()
        except Exception as e:
            self.logger.error(f"加密数据失败: {e}")
            raise

    def decrypt(self, encrypted_data: str) -> str:
        """
        解密数据

        Args:
            encrypted_data: 加密的数据

        Returns:
            解密后的数据
        """
        try:
            return self.fernet.decrypt(encrypted_data.encode()).decode()
        except Exception as e:
            self.logger.error(f"解密数据失败: {e}")
            raise

    def generate_secret_key(self) -> str:
        """
        生成密钥

        Returns:
            生成的密钥
        """
        return Fernet.generate_key().decode()
