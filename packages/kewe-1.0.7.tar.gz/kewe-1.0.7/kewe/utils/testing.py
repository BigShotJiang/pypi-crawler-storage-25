#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.utils.testing - Test utilities including TestClient and WebSocket testing
"""

import asyncio
from kewe.utils.compat import json as _json
from typing import Dict, Any, Optional, Union, Callable, List
from dataclasses import dataclass
from urllib.parse import urlencode, urlparse, parse_qs
from contextlib import asynccontextmanager


from kewe.http.headers import CIMultiDict as CaseInsensitiveDict
import logging

logger = logging.getLogger(__name__)



@dataclass
class TestResponse:
    status: int
    headers: CaseInsensitiveDict
    body: bytes
    content_type: str
    url: str = ""
    cookies: Dict[str, str] = None
    encoding: str = "utf-8"

    def __post_init__(self):
        if self.cookies is None:
            self.cookies = {}

    @property
    def status_code(self) -> int:
        return self.status

    @property
    def text(self) -> str:
        return self.body.decode(self.encoding, errors='replace')

    @property
    def json(self) -> Any:
        try:
            return _json.loads(self.body)
        except (_json.JSONDecodeError, UnicodeDecodeError) as exc:
            raise exc

    def raise_for_status(self) -> 'TestResponse':
        if self.status >= 400:
            raise AssertionError(f"HTTP {self.status}: {self.text[:200]}")
        return self

    def __getitem__(self, key: str) -> str:
        return self.headers[key]

    def __repr__(self) -> str:
        return f"<TestResponse status={self.status} content_type={self.content_type}>"


@dataclass
class WebSocketMessage:
    type: str
    data: Any = None

    @property
    def text(self) -> Optional[str]:
        if self.type == 'text':
            return self.data
        return None

    @property
    def bytes(self) -> Optional[bytes]:
        if self.type == 'binary':
            return self.data
        return None


class TestWebSocket:
    def __init__(self, app, path: str):
        self.app = app
        self.path = path
        self._connected = False
        self._messages: List[WebSocketMessage] = []
        self._sent_messages: List[Dict[str, Any]] = []
        self._closed = False
        self._close_code: Optional[int] = None
        self._subprotocol: Optional[str] = None

    async def connect(
        self,
        headers: Dict[str, str] = None,
        subprotocols: List[str] = None
    ) -> 'TestWebSocket':
        if self._connected:
            raise RuntimeError("WebSocket already connected")

        self._connected = True

        parsed = urlparse(self.path)
        scope_path = parsed.path or "/"
        ws_handler, path_params = self._find_handler(scope_path)
        if not ws_handler:
            raise RuntimeError(f"No WebSocket handler found for path: {self.path}")

        scope = {
            'type': 'websocket',
            'path': scope_path,
            'headers': [(k.encode(), v.encode()) for k, v in (headers or {}).items()],
            'query_string': parsed.query.encode('utf-8'),
            'subprotocols': subprotocols or [],
            'path_params': path_params,
        }

        self._receive_queue: asyncio.Queue = asyncio.Queue()
        self._send_queue: asyncio.Queue = asyncio.Queue()
        await self._receive_queue.put({'type': 'websocket.connect'})

        self._handler_task = asyncio.create_task(
            self._run_handler(ws_handler, scope)
        )

        await asyncio.sleep(0.01)

        return self

    def _find_handler(self, path: str) -> tuple[Optional[Callable], dict[str, Any]]:
        if hasattr(self.app, 'router'):
            websocket_routes = getattr(self.app.router, '_websocket_routes', {}) or {}
            for route in websocket_routes.values():
                match = route['regex_pattern'].match(path)
                if not match:
                    continue

                raw_params = match.groupdict()
                if raw_params:
                    from kewe.routing.converter import convert_parameter

                    params = {}
                    for name, raw_value in raw_params.items():
                        converter_name = route.get('params', {}).get(name, 'str')
                        params[name] = convert_parameter(raw_value, converter_name, name)
                else:
                    params = {}
                return route['handler'], params

        if hasattr(self.app, '_websocket_routes'):
            for route in self.app._websocket_routes:
                if route['path'] == path:
                    return route['handler'], {}

        return None, {}

    async def _run_handler(self, handler: Callable, scope: Dict[str, Any]):
        from kewe.websocket import WebSocketConnection

        async def receive():
            return await self._receive_queue.get()

        async def send(message: Dict[str, Any]):
            self._sent_messages.append(message)

            if message['type'] == 'websocket.accept':
                self._subprotocol = message.get('subprotocol')
            elif message['type'] == 'websocket.send':
                data = message.get('text') or message.get('bytes')
                msg_type = 'text' if message.get('text') else 'binary'
                self._messages.append(WebSocketMessage(type=msg_type, data=data))
            elif message['type'] == 'websocket.close':
                self._closed = True
                self._close_code = message.get('code', 1000)

        ws = WebSocketConnection(_asgi_scope=scope, _asgi_receive=receive, _asgi_send=send)

        try:
            await handler(ws)
        except Exception:
            self._closed = True
            self._close_code = 1011

    async def send(self, text: str):
        """发送文本消息 — 等同于 send_text"""
        await self.send_text(text)

    async def send_text(self, text: str):
        if not self._connected or self._closed:
            raise RuntimeError("WebSocket not connected")

        await self._receive_queue.put({
            'type': 'websocket.receive',
            'text': text
        })

    async def send_bytes(self, data: bytes):
        if not self._connected or self._closed:
            raise RuntimeError("WebSocket not connected")

        await self._receive_queue.put({
            'type': 'websocket.receive',
            'bytes': data
        })

    async def send_json(self, data: Any):
        await self.send_text(_json.dumps(data))

    async def receive(self, timeout: float = 5.0) -> Optional[WebSocketMessage]:
        start_time = asyncio.get_running_loop().time()

        while True:
            if self._messages:
                return self._messages.pop(0)

            if self._closed:
                return None

            if asyncio.get_running_loop().time() - start_time > timeout:
                raise asyncio.TimeoutError("Timeout waiting for message")

            await asyncio.sleep(0.01)

    async def receive_text(self, timeout: float = 5.0) -> Optional[str]:
        msg = await self.receive(timeout)
        return msg.text if msg else None

    async def receive_bytes(self, timeout: float = 5.0) -> Optional[bytes]:
        msg = await self.receive(timeout)
        return msg.bytes if msg else None

    async def receive_json(self, timeout: float = 5.0) -> Any:
        text = await self.receive_text(timeout)
        return _json.loads(text) if text else None

    async def close(self, code: int = 1000, reason: str = ""):
        if self._closed:
            return

        await self._receive_queue.put({
            'type': 'websocket.disconnect',
            'code': code
        })

        self._closed = True
        self._close_code = code

        if self._handler_task and not self._handler_task.done():
            try:
                await asyncio.wait_for(self._handler_task, timeout=1.0)
            except asyncio.TimeoutError:
                self._handler_task.cancel()

    @property
    def closed(self) -> bool:
        return self._closed

    @property
    def close_code(self) -> Optional[int]:
        return self._close_code

    async def __aenter__(self) -> 'TestWebSocket':
        await self.connect()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()

    def __enter__(self) -> 'TestWebSocket':
        if not self._connected:
            try:
                loop = asyncio.get_running_loop()
                loop.run_until_complete(self.connect())
            except RuntimeError:
                asyncio.run(self.connect())
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if not self._closed:
            try:
                loop = asyncio.get_running_loop()
                loop.run_until_complete(self.close())
            except RuntimeError:
                asyncio.run(self.close())


def _build_asgi_scope(
    method: str,
    path: str,
    headers: Optional[Dict[str, str]] = None,
    query_string: str = "",
) -> Dict[str, Any]:
    """构建ASGI scope"""
    parsed = urlparse(path)
    scope_path = parsed.path or "/"
    scope_query = query_string.encode('utf-8') if query_string else b''

    raw_headers = []
    if headers:
        for k, v in headers.items():
            raw_headers.append((k.lower().encode('utf-8'), v.encode('utf-8') if isinstance(v, str) else v))

    return {
        'type': 'http',
        'asgi': {'version': '3.0'},
        'http_version': '1.1',
        'method': method.upper(),
        'path': scope_path,
        'raw_path': scope_path.encode('utf-8'),
        'query_string': scope_query,
        'root_path': '',
        'headers': raw_headers,
        'server': ('testserver', 80),
        'client': ('testclient', 50000),
        'scheme': 'http',
    }


class AsyncTestClient:
    """异步测试客户端 - 基于httpx+ASGITransport

    通过ASGI协议与应用交互，确保测试环境与生产环境一致。
    支持lifespan生命周期、Cookie持久化、流式响应。

    使用示例:
        async with AsyncTestClient(app) as client:
            response = await client.get("/")
            assert response.status == 200
    """

    def __init__(self, app, *, base_url: str = "http://testserver",
                 raise_server_exceptions: bool = True, follow_redirects: bool = True):
        self.app = app
        self.base_url = base_url
        self.raise_server_exceptions = raise_server_exceptions
        self.follow_redirects = follow_redirects
        self.cookies: Dict[str, str] = {}
        self._httpx_client = None
        self._lifespan_started = False
        self._portal = None

    async def _ensure_httpx(self):
        """确保httpx客户端已创建"""
        if self._httpx_client is not None:
            return

        try:
            import httpx
        except ImportError:
            raise ImportError(
                "httpx is required for the new TestClient. "
                "Install it with: pip install httpx"
            )

        asgi_app = self.app

        transport = httpx.ASGITransport(
            app=asgi_app,
            raise_app_exceptions=self.raise_server_exceptions,
        )

        self._httpx_client = httpx.AsyncClient(
            transport=transport,
            base_url=self.base_url,
            cookies=self.cookies,
            follow_redirects=getattr(self, 'follow_redirects', True),
        )

    async def __aenter__(self):
        await self._ensure_httpx()
        await self._startup()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.aclose()
        return False

    async def aclose(self) -> None:
        """显式关闭客户端"""
        await self._shutdown()
        if self._httpx_client:
            await self._httpx_client.aclose()
            self._httpx_client = None

    async def _startup(self):
        if self._lifespan_started:
            return
        if hasattr(self.app, '_lifespan') and self.app._lifespan is not None:
            from kewe.app import Kewe
            await Kewe._execute_lifespan_startup(self.app)
        if hasattr(self.app, 'middleware_manager'):
            try:
                await self.app.middleware_manager.execute_before_server_start(
                    self.app,
                    asyncio.get_running_loop()
                )
                await self.app.middleware_manager.execute_after_server_start(
                    self.app,
                    asyncio.get_running_loop()
                )
            except Exception:
                logger.warning("Test client cleanup failed", exc_info=True)
        self._lifespan_started = True

    async def _shutdown(self):
        if not self._lifespan_started:
            return
        if hasattr(self.app, 'middleware_manager'):
            try:
                await self.app.middleware_manager.execute_before_server_stop(
                    self.app,
                    asyncio.get_running_loop()
                )
                await self.app.middleware_manager.execute_after_server_stop(
                    self.app,
                    asyncio.get_running_loop()
                )
            except Exception:
                logger.debug("Non-critical operation failed", exc_info=True)
        if hasattr(self.app, '_lifespan') and self.app._lifespan is not None:
            from kewe.app import Kewe
            await Kewe._execute_lifespan_shutdown(self.app)
        self._lifespan_started = False

    def _convert_response(self, httpx_response) -> TestResponse:
        headers = CaseInsensitiveDict()
        for key, value in httpx_response.headers.multi_items():
            headers[key] = value

        content_type = headers.get('content-type', 'application/octet-stream')

        response_cookies = dict(httpx_response.cookies)

        encoding = "utf-8"
        ct_header = headers.get('content-type', '')
        if 'charset=' in ct_header:
            encoding = ct_header.split('charset=')[-1].split(';')[0].strip()

        return TestResponse(
            status=httpx_response.status_code,
            headers=headers,
            body=httpx_response.content,
            content_type=content_type,
            url=str(httpx_response.url),
            cookies=response_cookies,
            encoding=encoding,
        )

    async def _request(
        self,
        method: str,
        path: str,
        *,
        data: Optional[Union[Dict, str, bytes]] = None,
        headers: Optional[Dict[str, str]] = None,
        json: Optional[Dict] = None,
        query: Optional[Dict[str, str]] = None,
        params: Optional[Dict[str, str]] = None,
        files: Optional[Dict] = None,
        content: Optional[bytes] = None,
        cookies: Optional[Dict[str, str]] = None,
        follow_redirects: bool = True,
    ) -> TestResponse:
        await self._ensure_httpx()

        if not self._lifespan_started:
            await self._startup()

        if self._httpx_client and self._httpx_client.cookies:
            for cookie_name in list(self._httpx_client.cookies.jar):
                if cookie_name.name not in self.cookies:
                    self._httpx_client.cookies.jar.clear(cookie_name.domain, cookie_name.path, cookie_name.name)

        for name, value in self.cookies.items():
            self._httpx_client.cookies.set(name, value)

        request_headers = headers or {}

        request_kwargs = {
            'headers': request_headers,
        }

        effective_query = params or query
        if effective_query:
            request_kwargs['params'] = effective_query

        if cookies:
            request_kwargs['cookies'] = cookies

        if json is not None:
            request_kwargs['json'] = json
        elif files is not None:
            request_kwargs['files'] = files
        elif data is not None:
            if isinstance(data, dict):
                request_kwargs['data'] = data
            elif isinstance(data, str):
                request_kwargs['content'] = data.encode('utf-8')
            elif isinstance(data, bytes):
                request_kwargs['content'] = data
        elif content is not None:
            request_kwargs['content'] = content

        httpx_response = await self._httpx_client.request(
            method, path, follow_redirects=follow_redirects, **request_kwargs
        )

        for cookie_name, cookie_value in httpx_response.cookies.items():
            self.cookies[cookie_name] = cookie_value

        return self._convert_response(httpx_response)

    async def get(
        self,
        path: str,
        *,
        headers: Optional[Dict[str, str]] = None,
        query: Optional[Dict[str, str]] = None,
        params: Optional[Dict[str, str]] = None,
        json: Optional[Dict] = None,
        cookies: Optional[Dict[str, str]] = None,
        follow_redirects: bool = True,
    ) -> TestResponse:
        return await self._request('GET', path, headers=headers, query=query, params=params, json=json, cookies=cookies, follow_redirects=follow_redirects)

    async def post(
        self,
        path: str,
        *,
        data: Optional[Union[Dict, str, bytes]] = None,
        content: Optional[bytes] = None,
        headers: Optional[Dict[str, str]] = None,
        json: Optional[Dict] = None,
        files: Optional[Dict] = None,
        cookies: Optional[Dict[str, str]] = None,
        follow_redirects: bool = True,
    ) -> TestResponse:
        return await self._request('POST', path, data=data or content, headers=headers, json=json, files=files, cookies=cookies, follow_redirects=follow_redirects)

    async def put(
        self,
        path: str,
        *,
        data: Optional[Union[Dict, str, bytes]] = None,
        content: Optional[bytes] = None,
        headers: Optional[Dict[str, str]] = None,
        json: Optional[Dict] = None,
        cookies: Optional[Dict[str, str]] = None,
        follow_redirects: bool = True,
    ) -> TestResponse:
        return await self._request('PUT', path, data=data or content, headers=headers, json=json, cookies=cookies, follow_redirects=follow_redirects)

    async def delete(
        self,
        path: str,
        *,
        data: Optional[Union[Dict, str, bytes]] = None,
        json: Optional[Dict] = None,
        headers: Optional[Dict[str, str]] = None,
        query: Optional[Dict[str, str]] = None,
        params: Optional[Dict[str, str]] = None,
        cookies: Optional[Dict[str, str]] = None,
        follow_redirects: bool = True,
    ) -> TestResponse:
        return await self._request('DELETE', path, data=data, headers=headers, json=json, query=query, params=params, cookies=cookies, follow_redirects=follow_redirects)

    async def patch(
        self,
        path: str,
        *,
        data: Optional[Union[Dict, str, bytes]] = None,
        content: Optional[bytes] = None,
        headers: Optional[Dict[str, str]] = None,
        json: Optional[Dict] = None,
        cookies: Optional[Dict[str, str]] = None,
        follow_redirects: bool = True,
    ) -> TestResponse:
        return await self._request('PATCH', path, data=data or content, headers=headers, json=json, cookies=cookies, follow_redirects=follow_redirects)

    async def head(
        self,
        path: str,
        *,
        data: Optional[Union[Dict, str, bytes]] = None,
        json: Optional[Dict] = None,
        headers: Optional[Dict[str, str]] = None,
        query: Optional[Dict[str, str]] = None,
        params: Optional[Dict[str, str]] = None,
        cookies: Optional[Dict[str, str]] = None,
        follow_redirects: bool = True,
    ) -> TestResponse:
        return await self._request('HEAD', path, data=data, headers=headers, json=json, query=query, params=params, cookies=cookies, follow_redirects=follow_redirects)

    async def options(
        self,
        path: str,
        *,
        data: Optional[Union[Dict, str, bytes]] = None,
        json: Optional[Dict] = None,
        headers: Optional[Dict[str, str]] = None,
        query: Optional[Dict[str, str]] = None,
        params: Optional[Dict[str, str]] = None,
        cookies: Optional[Dict[str, str]] = None,
        follow_redirects: bool = True,
    ) -> TestResponse:
        return await self._request('OPTIONS', path, data=data, headers=headers, json=json, query=query, params=params, cookies=cookies, follow_redirects=follow_redirects)

    async def websocket(
        self,
        path: str,
        headers: Optional[Dict[str, str]] = None,
        subprotocols: Optional[List[str]] = None
    ) -> TestWebSocket:
        if not self._lifespan_started:
            await self._ensure_httpx()
            await self._startup()
        ws = TestWebSocket(self.app, path)
        await ws.connect(headers=headers, subprotocols=subprotocols)
        return ws


class _SessionTransaction:
    """Session 事务上下文管理器

    通过请求 / 并解析 session cookie 来获取 session 数据，
    退出时将修改后的 session 写回 cookie。
    """

    def __init__(self, client):
        self._client = client
        self.session = {}

    def __enter__(self):
        self._load_session()
        return self.session

    def __exit__(self, exc_type, exc_val, exc_tb):
        self._save_session()
        return False

    def _load_session(self):
        try:
            from kewe.cookies.session import Session
            from kewe.cookies.signed import Signer
            app = self._client.app
            session_cookie_name = getattr(app.config, 'session_cookie_name', 'session')
            cookie_value = self._client.cookies.get(session_cookie_name)
            if cookie_value and hasattr(app, 'secret_key') and app.secret_key:
                try:
                    signer = Signer(app.secret_key)
                    data = signer.unsign(cookie_value)
                    self.session = _json.loads(data)
                except Exception:
                    self.session = {}
            elif cookie_value:
                try:
                    import base64, json
                    self.session = _json.loads(base64.b64decode(cookie_value))
                except Exception:
                    self.session = {}
            else:
                self.session = {}
        except ImportError:
            self.session = {}

    def _save_session(self):
        try:
            from kewe.cookies.signed import Signer
            app = self._client.app
            session_cookie_name = getattr(app.config, 'session_cookie_name', 'session')
            data = _json.dumps(self.session)
            if hasattr(app, 'secret_key') and app.secret_key:
                signer = Signer(app.secret_key)
                cookie_value = signer.sign(data)
            else:
                import base64
                cookie_value = base64.b64encode(data.encode()).decode()
            self._client.cookies[session_cookie_name] = cookie_value
        except ImportError:
            pass


class TestClient:
    """同步测试客户端 - 基于httpx+ASGITransport

    通过ASGI协议与应用交互，确保测试环境与生产环境一致。
    支持lifespan生命周期、Cookie持久化。

    使用示例:
        with TestClient(app) as client:
            response = client.get("/")
            assert response.status == 200
    """

    __test__ = False

    def __call__(self, **kwargs):
        return self

    def __init__(self, app, *, base_url: str = "http://testserver",
                 raise_server_exceptions: bool = True, follow_redirects: bool = True,
                 direct_mode: bool = False):
        self.app = app
        self.base_url = base_url
        self.raise_server_exceptions = raise_server_exceptions
        self.follow_redirects = follow_redirects
        self.direct_mode = direct_mode
        self.cookies: Dict[str, str] = {}
        self._async_client: Optional[AsyncTestClient] = None
        self._loop = None
        self._lifespan_started = False

    @property
    def dependency_overrides(self):
        """依赖覆盖 - 便捷访问"""
        if hasattr(self.app, 'dependency_overrides'):
            return self.app.dependency_overrides
        if hasattr(self.app, '_dependency_override_manager'):
            return self.app._dependency_override_manager
        raise AttributeError(
            f"{type(self.app).__name__} has no dependency_overrides. "
            "Ensure you are using a Kewe application instance."
        )

    def _get_loop(self):
        try:
            loop = asyncio.get_running_loop()
            return loop
        except RuntimeError:
            pass

        if self._loop is None or self._loop.is_closed():
            self._loop = asyncio.new_event_loop()
        return self._loop

    def _run(self, coro):
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop is not None and loop.is_running():
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                future = pool.submit(asyncio.run, coro)
                return future.result(timeout=60)
        
        if self._loop is None or self._loop.is_closed():
            self._loop = asyncio.new_event_loop()
        return self._loop.run_until_complete(coro)

    def _get_async_client(self) -> AsyncTestClient:
        if self._async_client is None:
            self._async_client = AsyncTestClient(
                self.app,
                base_url=self.base_url,
                raise_server_exceptions=self.raise_server_exceptions,
                follow_redirects=self.follow_redirects,
            )
            self._async_client.cookies = self.cookies
        return self._async_client

    def __enter__(self):
        self._run(self._startup())
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self._run(self._shutdown())
        self.cookies.clear()
        if self._async_client and self._async_client._httpx_client:
            self._run(self._async_client._httpx_client.aclose())
            self._async_client._httpx_client = None
        return False

    def session_transaction(self):
        """Session 事务上下文管理器

        在上下文中可以直接读写 session，退出时自动保存。

        用法:
            with client.session_transaction() as session:
                session['user_id'] = 42
            # 后续请求中 session 包含 user_id
        """
        return _SessionTransaction(self)

    async def __aenter__(self):
        client = self._get_async_client()
        await client._ensure_httpx()
        await client._startup()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        client = self._get_async_client()
        await client._shutdown()
        if client._httpx_client:
            await client._httpx_client.aclose()
            client._httpx_client = None
        return False

    async def _startup(self):
        if self._lifespan_started:
            return
        client = self._get_async_client()
        await client._ensure_httpx()
        await client._startup()
        self._lifespan_started = True

    async def _shutdown(self):
        if not self._lifespan_started:
            return
        client = self._get_async_client()
        await client._shutdown()
        self._lifespan_started = False

    def _request(self, method: str, path: str, **kwargs) -> TestResponse:
        if self.direct_mode:
            return self._direct_request(method, path, **kwargs)
        client = self._get_async_client()
        return self._run(client._request(method, path, **kwargs))

    def _direct_request(self, method: str, path: str, **kwargs) -> TestResponse:
        from kewe.request.request import Request
        from kewe.base.context import RequestContextManager

        headers = kwargs.get('headers') or {}
        query = kwargs.get('query') or kwargs.get('params') or {}
        json_data = kwargs.get('json')
        data = kwargs.get('data')
        cookies = kwargs.get('cookies') or {}

        parsed = urlparse(path)
        scope_path = parsed.path or "/"
        scope_query = parsed.query

        if query:
            qs = urlencode(query)
            scope_query = f"{scope_query}&{qs}" if scope_query else qs

        raw_headers = []
        for k, v in headers.items():
            raw_headers.append((k.lower().encode('utf-8'), v.encode('utf-8') if isinstance(v, str) else v))

        all_cookies = {**self.cookies, **cookies}
        if all_cookies:
            cookie_str = "; ".join(f"{k}={v}" for k, v in all_cookies.items())
            raw_headers.append((b"cookie", cookie_str.encode('utf-8')))

        body = b""
        if json_data is not None:
            from kewe.utils.compat import json as kewe_json
            body = kewe_json.dumps(json_data)
            raw_headers.append((b"content-type", b"application/json"))
        elif data is not None:
            if isinstance(data, str):
                body = data.encode('utf-8')
            elif isinstance(data, bytes):
                body = data
            elif isinstance(data, dict):
                body = urlencode(data).encode('utf-8')
                raw_headers.append((b"content-type", b"application/x-www-form-urlencoded"))

        if body:
            raw_headers.append((b"content-length", str(len(body)).encode('utf-8')))

        scope = {
            'type': 'http',
            'asgi': {'version': '3.0'},
            'http_version': '1.1',
            'method': method.upper(),
            'path': scope_path,
            'raw_path': scope_path.encode('utf-8'),
            'query_string': scope_query.encode('utf-8') if scope_query else b'',
            'root_path': '',
            'headers': raw_headers,
            'server': ('testserver', 80),
            'client': ('testclient', 50000),
            'scheme': 'http',
        }

        async def _do_request():
            request = Request(
                method=method.upper(),
                path=scope_path,
                headers=dict(headers),
                query_params=parse_qs(scope_query) if scope_query else {},
                body=body,
                client_ip='testclient',
                _scope=scope,
            )
            if hasattr(self.app, 'handle_request'):
                response = await self.app.handle_request(request)
            else:
                response = await self.app(scope, None, None)

            resp_headers = CaseInsensitiveDict()
            if hasattr(response, 'headers'):
                for k, v in response.headers.items():
                    resp_headers[k] = v

            resp_body = b""
            if hasattr(response, 'body'):
                resp_body = response.body if isinstance(response.body, bytes) else response.body.encode('utf-8') if response.body else b""
            if not resp_body and hasattr(response, 'is_streaming') and response.is_streaming:
                try:
                    parts = []
                    gen = getattr(response, 'stream_generator', None) or getattr(response, '_stream_generator', None)
                    if gen is not None and hasattr(gen, '__aiter__'):
                        async for chunk in gen:
                            if isinstance(chunk, str):
                                chunk = chunk.encode('utf-8')
                            if chunk:
                                parts.append(chunk)
                    resp_body = b''.join(parts) if parts else b""
                except Exception:
                    resp_body = b""

            content_type = resp_headers.get('content-type', 'application/octet-stream')

            resp_cookies = {}
            set_cookie = resp_headers.get('set-cookie', '')
            if set_cookie:
                for cookie_part in set_cookie.split(','):
                    cookie_part = cookie_part.strip()
                    if '=' in cookie_part:
                        name_val = cookie_part.split(';')[0].strip()
                        if '=' in name_val:
                            cn, cv = name_val.split('=', 1)
                            resp_cookies[cn.strip()] = cv.strip()
                            self.cookies[cn.strip()] = cv.strip()

            encoding = "utf-8"
            ct_header = resp_headers.get('content-type', '')
            if 'charset=' in ct_header:
                encoding = ct_header.split('charset=')[-1].split(';')[0].strip()

            return TestResponse(
                status=response.status if hasattr(response, 'status') else 200,
                headers=resp_headers,
                body=resp_body,
                content_type=content_type,
                url=path,
                cookies=resp_cookies,
                encoding=encoding,
            )

        return self._run(_do_request())

    def get(self, path: str, *, headers: Optional[Dict[str, str]] = None, query: Optional[Dict[str, str]] = None, params: Optional[Dict[str, str]] = None, json: Optional[Dict] = None, cookies: Optional[Dict[str, str]] = None, follow_redirects: bool = True) -> TestResponse:
        return self._request('GET', path, headers=headers, query=query, params=params, json=json, cookies=cookies, follow_redirects=follow_redirects)

    def post(self, path: str, *, data=None, content=None, headers: Optional[Dict[str, str]] = None, json: Optional[Dict] = None, files: Optional[Dict] = None, cookies: Optional[Dict[str, str]] = None, follow_redirects: bool = True) -> TestResponse:
        return self._request('POST', path, data=data or content, headers=headers, json=json, files=files, cookies=cookies, follow_redirects=follow_redirects)

    def put(self, path: str, *, data=None, content=None, headers: Optional[Dict[str, str]] = None, json: Optional[Dict] = None, cookies: Optional[Dict[str, str]] = None, follow_redirects: bool = True) -> TestResponse:
        return self._request('PUT', path, data=data or content, headers=headers, json=json, cookies=cookies, follow_redirects=follow_redirects)

    def delete(self, path: str, *, data=None, content=None, headers: Optional[Dict[str, str]] = None, json: Optional[Dict] = None, query: Optional[Dict[str, str]] = None, params: Optional[Dict[str, str]] = None, cookies: Optional[Dict[str, str]] = None, follow_redirects: bool = True) -> TestResponse:
        return self._request('DELETE', path, data=data or content, headers=headers, json=json, query=query, params=params, cookies=cookies, follow_redirects=follow_redirects)

    def patch(self, path: str, *, data=None, content=None, headers: Optional[Dict[str, str]] = None, json: Optional[Dict] = None, cookies: Optional[Dict[str, str]] = None, follow_redirects: bool = True) -> TestResponse:
        return self._request('PATCH', path, data=data or content, headers=headers, json=json, cookies=cookies, follow_redirects=follow_redirects)

    def head(self, path: str, *, headers: Optional[Dict[str, str]] = None, query: Optional[Dict[str, str]] = None, params: Optional[Dict[str, str]] = None, cookies: Optional[Dict[str, str]] = None, follow_redirects: bool = True) -> TestResponse:
        return self._request('HEAD', path, headers=headers, query=query, params=params, cookies=cookies, follow_redirects=follow_redirects)

    def options(self, path: str, *, headers: Optional[Dict[str, str]] = None, query: Optional[Dict[str, str]] = None, params: Optional[Dict[str, str]] = None, cookies: Optional[Dict[str, str]] = None, follow_redirects: bool = True) -> TestResponse:
        return self._request('OPTIONS', path, headers=headers, query=query, params=params, cookies=cookies, follow_redirects=follow_redirects)

    def websocket(self, path: str, headers: Optional[Dict[str, str]] = None, subprotocols: Optional[List[str]] = None) -> TestWebSocket:
        if not self._lifespan_started:
            self._run(self._startup())
        ws = TestWebSocket(self.app, path)
        self._run(ws.connect(headers=headers, subprotocols=subprotocols))
        return ws


class TestCase:
    def __init__(self, app):
        self.app = app
        self.client = TestClient(app)

    def setup_method(self):
        pass

    def teardown_method(self):
        pass

    def assert_status(self, response: TestResponse, expected: int):
        assert response.status == expected, f"Expected status {expected}, got {response.status}"

    def assert_ok(self, response: TestResponse):
        assert 200 <= response.status < 300, f"Expected 2xx status, got {response.status}"

    def assert_json(self, response: TestResponse, expected: Optional[Dict] = None):
        assert 'application/json' in response.content_type, "Response is not JSON"
        if expected is not None:
            assert response.json == expected, f"JSON mismatch: {response.json} != {expected}"

    def assert_header(self, response: TestResponse, name: str, expected: str):
        assert name in response.headers, f"Header {name} not found"
        assert response.headers[name] == expected, f"Header {name} mismatch"


def create_test_client(app, **kwargs) -> TestClient:
    return TestClient(app, **kwargs)


def create_async_test_client(app, **kwargs) -> AsyncTestClient:
    return AsyncTestClient(app, **kwargs)


class DependencyOverrider:
    """
    依赖覆盖 - 依赖覆盖机制
    
    用于在测试中替换依赖，例如替换数据库连接为测试数据库
    
    使用示例:
        from kewe.utils.testing import DependencyOverrider
        from kewe.application.depends import Depends
        
        def override_db():
            return TestDatabase()
        
        with DependencyOverrider(app, {get_db: override_db}):
            response = client.get("/users")
    """
    
    def __init__(self, app, overrides: Dict[Callable, Callable]):
        self.app = app
        self.overrides = overrides
        self._original_overrides = {}
    
    def __enter__(self):
        resolver = getattr(self.app, '_dependency_resolver', None)
        if resolver is None:
            return self
        
        for original, replacement in self.overrides.items():
            from kewe.application.depends import _get_cache_key
            cache_key = _get_cache_key(original)
            self._original_overrides[cache_key] = resolver._overrides.get(cache_key)
            resolver._overrides[cache_key] = replacement
        
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        resolver = getattr(self.app, '_dependency_resolver', None)
        if resolver is None:
            return False
        
        for cache_key, original_value in self._original_overrides.items():
            if original_value is None:
                resolver._overrides.pop(cache_key, None)
            else:
                resolver._overrides[cache_key] = original_value
        
        return False

    async def __aenter__(self):
        return self.__enter__()

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        return self.__exit__(exc_type, exc_val, exc_tb)


try:
    import pytest
    
    @pytest.fixture
    def kewe_app():
        from kewe.app import Kewe
        app = Kewe("test")
        return app
    
    @pytest.fixture
    def kewe_client(kewe_app):
        with TestClient(kewe_app) as client:
            yield client
    
    @pytest.fixture
    async def kewe_async_client(kewe_app):
        async with AsyncTestClient(kewe_app) as client:
            yield client
    
    @pytest.fixture
    def kewe_dependency_override(kewe_app):
        overrides = {}
        
        def override(dependency, replacement):
            overrides[dependency] = replacement
        
        with DependencyOverrider(kewe_app, overrides):
            yield override

except ImportError:
    pass


__all__ = [
    'TestResponse',
    'WebSocketMessage',
    'TestWebSocket',
    'TestClient',
    'AsyncTestClient',
    'TestCase',
    'DependencyOverrider',
    'create_test_client',
    'create_async_test_client',
]
