#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.utils.pagination - Pagination helpers for API responses
"""

from dataclasses import dataclass, field
from typing import Any, Dict, Generic, List, Optional, Sequence, TypeVar
import base64
from kewe.utils.compat import json
import logging



logger = logging.getLogger(__name__)

T = TypeVar("T")

DEFAULT_PAGE = 1
DEFAULT_PER_PAGE = 20
MAX_PER_PAGE = 100


@dataclass
class PaginationParams:
    """分页参数 — 可从请求查询参数中提取

    用法:
        @app.get("/users")
        async def list_users(request):
            params = PaginationParams.from_request(request)
            ...
    """
    page: int = DEFAULT_PAGE
    per_page: int = DEFAULT_PER_PAGE
    max_per_page: int = MAX_PER_PAGE

    def __init__(self, page: int = DEFAULT_PAGE, per_page: int = DEFAULT_PER_PAGE,
                 max_per_page: int = MAX_PER_PAGE, size: Optional[int] = None):
        self.page = page
        self.per_page = size if size is not None else per_page
        self.max_per_page = max_per_page

    @classmethod
    def from_request(cls, request, *, page_key: str = "page",
                     per_page_key: str = "per_page",
                     max_per_page: int = MAX_PER_PAGE) -> "PaginationParams":
        """从请求查询参数中提取分页参数"""
        try:
            page = max(1, int(request.query_params.get(page_key, DEFAULT_PAGE)))
        except (ValueError, TypeError):
            page = DEFAULT_PAGE
        try:
            per_page = min(max(1, int(request.query_params.get(per_page_key, DEFAULT_PER_PAGE))),
                           max_per_page)
        except (ValueError, TypeError):
            per_page = min(DEFAULT_PER_PAGE, max_per_page)
        return cls(page=page, per_page=per_page, max_per_page=max_per_page)

    @property
    def offset(self) -> int:
        return (self.page - 1) * self.per_page

    @property
    def limit(self) -> int:
        return self.per_page


@dataclass
class PaginatedResponse(Generic[T]):
    """标准分页响应 — JSON:API 风格"""
    items: List[T] = field(default_factory=list)
    total: int = 0
    page: int = 1
    per_page: int = DEFAULT_PER_PAGE
    pages: int = 0
    has_prev: bool = False
    has_next: bool = False

    def __post_init__(self):
        if self.pages == 0 and self.per_page > 0:
            self.pages = max(1, -(-self.total // self.per_page))
        self.has_prev = self.page > 1
        self.has_next = self.page < self.pages

    def to_dict(self) -> Dict[str, Any]:
        """转换为 API 响应字典"""
        return {
            "items": self.items,
            "total": self.total,
            "page": self.page,
            "per_page": self.per_page,
            "pages": self.pages,
            "has_prev": self.has_prev,
            "has_next": self.has_next,
        }


def paginate(
    items: Sequence[T],
    total: Optional[int] = None,
    params: Optional[PaginationParams] = None,
    page: int = DEFAULT_PAGE,
    per_page: int = DEFAULT_PER_PAGE,
) -> PaginatedResponse[T]:
    """将列表/查询结果封装为标准分页响应

    用法:
        @app.get("/users")
        async def list_users(request):
            params = PaginationParams.from_request(request)
            all_users = get_all_users()
            return paginate(all_users, params=params)
    """
    if params is not None:
        page = params.page
        per_page = params.per_page

    total_count = total if total is not None else len(items)
    start = (page - 1) * per_page
    end = start + per_page

    if total is not None:
        page_items = list(items[start:end]) if hasattr(items, '__getitem__') else list(items)
    else:
        page_items = list(items[start:end])

    return PaginatedResponse(
        items=page_items,
        total=total_count,
        page=page,
        per_page=per_page,
    )


def encode_cursor(data: Dict[str, Any]) -> str:
    encoded = json.dumps(data)
    return base64.urlsafe_b64encode(encoded.encode()).decode()


def decode_cursor(cursor: str) -> Dict[str, Any]:
    decoded = base64.urlsafe_b64decode(cursor.encode()).decode()
    return json.loads(decoded)


@dataclass
class CursorPaginationParams:
    cursor: Optional[str] = None
    limit: int = DEFAULT_PER_PAGE
    max_limit: int = MAX_PER_PAGE

    @classmethod
    def from_request(cls, request, *, cursor_key: str = "cursor",
                     limit_key: str = "limit",
                     max_limit: int = MAX_PER_PAGE) -> "CursorPaginationParams":
        cursor = request.query_params.get(cursor_key, None)
        try:
            limit = min(max(1, int(request.query_params.get(limit_key, DEFAULT_PER_PAGE))), max_limit)
        except (ValueError, TypeError):
            limit = min(DEFAULT_PER_PAGE, max_limit)
        return cls(cursor=cursor, limit=limit, max_limit=max_limit)


@dataclass
class CursorPaginatedResponse(Generic[T]):
    items: List[T] = field(default_factory=list)
    next_cursor: Optional[str] = None
    prev_cursor: Optional[str] = None
    has_more: bool = False
    total: Optional[int] = None

    def to_dict(self) -> Dict[str, Any]:
        result = {
            "items": self.items,
            "next_cursor": self.next_cursor,
            "prev_cursor": self.prev_cursor,
            "has_more": self.has_more,
        }
        if self.total is not None:
            result["total"] = self.total
        return result


def paginate_cursor(
    items: Sequence[T],
    cursor_field: str = "id",
    limit: int = DEFAULT_PER_PAGE,
    cursor: Optional[str] = None,
    params: Optional[CursorPaginationParams] = None,
) -> CursorPaginatedResponse[T]:
    if params is not None:
        limit = params.limit
        cursor = params.cursor

    cursor_value = None
    if cursor:
        try:
            cursor_data = decode_cursor(cursor)
            cursor_value = cursor_data.get(cursor_field)
        except Exception:
            logger.warning("Cursor decode failed", exc_info=True)

    filtered = items
    if cursor_value is not None and hasattr(items, '__getitem__'):
        filtered = [item for item in items if _get_field(item, cursor_field) > cursor_value]

    page_items = list(filtered[:limit + 1]) if len(filtered) > limit else list(filtered)
    has_more = len(filtered) > limit
    if has_more:
        page_items = page_items[:limit]

    next_cursor = None
    if has_more and page_items:
        last_item = page_items[-1]
        next_cursor = encode_cursor({cursor_field: _get_field(last_item, cursor_field)})

    prev_cursor = None
    if cursor and page_items:
        first_item = page_items[0]
        prev_cursor = encode_cursor({cursor_field: _get_field(first_item, cursor_field)})

    return CursorPaginatedResponse(
        items=page_items,
        next_cursor=next_cursor,
        prev_cursor=prev_cursor,
        has_more=has_more,
    )


paginate_result = paginate


def _get_field(item: Any, field_name: str) -> Any:
    if isinstance(item, dict):
        return item.get(field_name)


CursorPaginator = CursorPaginatedResponse
Paginator = PaginatedResponse

__all__ = [
    'PaginationParams',
    'PaginatedResponse',
    'Paginator',
    'CursorPaginationParams',
    'CursorPaginatedResponse',
    'CursorPaginator',
    'paginate',
    'paginate_cursor',
    'encode_cursor',
    'decode_cursor',
]
