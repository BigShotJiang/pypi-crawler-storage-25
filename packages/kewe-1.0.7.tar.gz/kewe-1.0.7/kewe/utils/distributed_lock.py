#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.utils.distributed_lock - Distributed lock implementation for multi-worker coordination
"""

import asyncio
import time
import threading
import uuid
from typing import Optional

from kewe.logging.logger import get_logger
import logging

logger = logging.getLogger(__name__)



class DistributedLock:

    def __init__(self, lock_manager: 'LockManager', name: str, lock_timeout: int, auto_renew: bool = False):
        self.lock_manager = lock_manager
        self.name = name
        self.lock_timeout = lock_timeout
        self.acquired = False
        self._lock_value = str(uuid.uuid4())
        self.auto_renew = auto_renew
        self._renew_task: Optional[asyncio.Task] = None

    def acquire(self, blocking: bool = True, timeout: Optional[float] = None) -> bool:
        import warnings
        warnings.warn(
            "DistributedLock.acquire() uses blocking sleep and should not be used in async code. "
            "Use DistributedLock.aacquire() instead.",
            RuntimeWarning, stacklevel=2,
        )
        start_time = time.time()
        while True:
            if self.lock_manager._acquire(self.name, self.lock_timeout, self._lock_value):
                self.acquired = True
                return True
            if not blocking:
                return False
            if timeout and time.time() - start_time > timeout:
                return False
            time.sleep(0.1)

    async def aacquire(self, blocking: bool = True, timeout: Optional[float] = None) -> bool:
        start_time = time.time()
        while True:
            if self.lock_manager._acquire(self.name, self.lock_timeout, self._lock_value):
                self.acquired = True
                if self.auto_renew:
                    self._start_renewal()
                return True
            if not blocking:
                return False
            if timeout and time.time() - start_time > timeout:
                return False
            await asyncio.sleep(0.1)

    def _start_renewal(self):
        if self._renew_task is None or self._renew_task.done():
            try:
                loop = asyncio.get_running_loop()
                self._renew_task = loop.create_task(self._renew_loop())
            except RuntimeError:
                pass

    async def _renew_loop(self):
        try:
            while self.acquired:
                await asyncio.sleep(self.lock_timeout / 3)
                if self.acquired:
                    self.lock_manager._renew(self.name, self.lock_timeout, self._lock_value)
        except asyncio.CancelledError:
            pass

    def release(self):
        if self.acquired:
            self._stop_renewal()
            self.lock_manager._release(self.name, self._lock_value)
            self.acquired = False

    async def arelease(self):
        if self.acquired:
            self._stop_renewal()
            self.lock_manager._release(self.name, self._lock_value)
            self.acquired = False

    def _stop_renewal(self):
        if self._renew_task and not self._renew_task.done():
            self._renew_task.cancel()

    def __enter__(self):
        self.acquire()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.release()

    async def __aenter__(self):
        await self.aacquire()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.arelease()


class LockManager:
    """分布式锁管理器"""

    def __init__(self, redis_client: Optional[any] = None):
        self.redis = redis_client
        self.local_locks: dict = {}
        self.local_lock = threading.RLock()
        self.logger = get_logger(__name__)

    def get_lock(self, name: str, lock_timeout: int = 10, auto_renew: bool = False) -> DistributedLock:
        return DistributedLock(self, name, lock_timeout, auto_renew)

    def _renew(self, name: str, lock_timeout: int, lock_value: str) -> bool:
        if self.redis:
            try:
                key = f"lock:{name}"
                current = self.redis.get(key)
                expected = current.decode() if isinstance(current, bytes) else current
                if current and expected == lock_value:
                    self.redis.expire(key, lock_timeout)
                    return True
            except Exception as e:
                self.logger.error(f"续期分布式锁失败: {e}")
        return False

    def _acquire(self, name: str, lock_timeout: int, lock_value: str) -> bool:
        if self.redis:
            try:
                key = f"lock:{name}"
                if hasattr(self.redis, 'set'):
                    result = self.redis.set(key, lock_value, nx=True, ex=lock_timeout)
                    return result is not None
                else:
                    if self.redis.setnx(key, lock_value):
                        self.redis.expire(key, lock_timeout)
                        return True
                return False
            except Exception as e:
                self.logger.error(f"获取分布式锁失败: {e}")
                return self._acquire_local(name)
        else:
            return self._acquire_local(name)

    def _acquire_local(self, name: str) -> bool:
        with self.local_lock:
            if name not in self.local_locks:
                self.local_locks[name] = threading.RLock()
            return self.local_locks[name].acquire(blocking=False)

    def _release(self, name: str, lock_value: str = None):
        if self.redis:
            try:
                key = f"lock:{name}"
                if lock_value:
                    script = """
                    if redis.call("get", KEYS[1]) == ARGV[1] then
                        return redis.call("del", KEYS[1])
                    else
                        return 0
                    end
                    """
                    self.redis.eval(script, 1, key, lock_value)
                else:
                    self.redis.delete(key)
            except Exception as e:
                self.logger.error(f"释放分布式锁失败: {e}")
                self._release_local(name)
        else:
            self._release_local(name)

    def _release_local(self, name: str):
        with self.local_lock:
            if name in self.local_locks:
                try:
                    self.local_locks[name].release()
                except Exception:
                    logger.debug("Non-critical operation failed", exc_info=True)




