#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.application.logo - Logo, MOTD display, and version utilities
"""

import os
import sys
import platform
from abc import ABC, abstractmethod
from typing import Optional, Dict

_KEWE_FULL = (
    " _  __  __        __   \n"
    "| |/ /__\\ \\      / /__ \n"
    "| ' // _ \\ \\ /\\ / / _ \\\n"
    "| . \\  __/\\ V  V /  __/\n"
    "|_|\\_\\___| \\_/\\_/ \\___|\n"
    "                       "
)

_KEWE_SIMPLE = "KeWe"

_COFFEE_EMOJI = "\u2615"

_COFFEE_FULL = (
    " _  __  __        __      {emoji}\n"
    "| |/ /__\\ \\      / /__    {emoji}\n"
    "| ' // _ \\ \\ /\\ / / _ \\   {emoji}\n"
    "| . \\  __/\\ V  V /  __/   {emoji}\n"
    "|_|\\_\\___| \\_/\\_/ \\___|   {emoji}\n"
    "                           "
)

_COLOR_RESET = "\033[0m"
_COLOR_RED = "\033[31m"
_COLOR_GREEN = "\033[32m"
_COLOR_YELLOW = "\033[33m"
_COLOR_BLUE = "\033[34m"
_COLOR_MAGENTA = "\033[35m"
_COLOR_CYAN = "\033[36m"
_COLOR_WHITE = "\033[37m"
_COLOR_BOLD = "\033[1m"
_COLOR_DIM = "\033[2m"

# Bright ANSI colors (256-color fallback)
_COLOR_BRIGHT_BLUE = "\033[94m"
_COLOR_BRIGHT_CYAN = "\033[96m"

# Sanic-style palette: bold blue → cyan gradient
_KEWE_COLOR_PALETTE = [
    _COLOR_BOLD + _COLOR_BRIGHT_BLUE,
    _COLOR_BOLD + _COLOR_BLUE,
    _COLOR_BOLD + _COLOR_CYAN,
    _COLOR_BOLD + _COLOR_BRIGHT_CYAN,
]


def _supports_color() -> bool:
    if os.environ.get("NO_COLOR") is not None:
        return False
    if os.environ.get("KEWE_NO_COLOR") is not None:
        return False
    if os.environ.get("FORCE_COLOR") is not None:
        return True
    if os.environ.get("TERM") == "dumb":
        return False
    if not hasattr(sys.stdout, "isatty"):
        return False
    if not sys.stdout.isatty():
        return False
    if platform.system() == "Windows":
        try:
            import ctypes
            kernel32 = ctypes.windll.kernel32
            return kernel32.GetConsoleMode(kernel32.GetStdHandle(-11)) & 0x0004 != 0
        except Exception:
            return False
    return True


def _safe_coffee_emoji() -> str:
    try:
        _COFFEE_EMOJI.encode(sys.stdout.encoding or "utf-8")
        return _COFFEE_EMOJI
    except (UnicodeEncodeError, UnicodeDecodeError, AttributeError):
        return "(C)"


def _colorize_line(line: str, color: str) -> str:
    return f"{color}{line}{_COLOR_RESET}"


def _colorize_logo_multiline(logo: str) -> str:
    lines = logo.split("\n")
    colored_lines = []
    for i, line in enumerate(lines):
        if line.strip():
            color = _KEWE_COLOR_PALETTE[i % len(_KEWE_COLOR_PALETTE)]
            colored_lines.append(_colorize_line(line, color))
        else:
            colored_lines.append(line)
    return "\n".join(colored_lines)


def _colorize_logo_single(logo: str) -> str:
    return f"{_COLOR_CYAN}{_COLOR_BOLD}{logo}{_COLOR_RESET}"


def get_logo(full: bool = False, coffee: bool = False) -> str:
    """获取 KeWe 框架 Logo

    支持完整/简洁/咖啡三种模式。
    终端支持彩色时自动渲染为多色渐变效果。

    Args:
        full: 是否使用完整 ASCII art logo。默认 False（仅显示文本）。
        coffee: 是否使用咖啡主题 logo。默认 False。

    Returns:
        str: Logo 字符串
    """
    if coffee:
        emoji = _safe_coffee_emoji()
        logo = _COFFEE_FULL.format(emoji=emoji) if full else _KEWE_SIMPLE + f" {emoji}"
    elif full:
        logo = _KEWE_FULL
    else:
        logo = _KEWE_SIMPLE

    if _supports_color():
        if full and "\n" in logo:
            logo = _colorize_logo_multiline(logo)
        else:
            logo = _colorize_logo_single(logo)

    return logo


def get_version_display() -> str:
    """获取版本显示字符串"""
    try:
        from kewe import __version__
        return f"v{__version__}"
    except (ImportError, AttributeError):
        return "v?.?.?"


def get_runtime_info() -> Dict[str, str]:
    """获取运行时环境信息"""
    info = {
        "python": platform.python_version(),
        "platform": platform.platform(),
    }
    try:
        from kewe import __version__
        info["kewe"] = __version__
    except (ImportError, AttributeError):
        info["kewe"] = "unknown"
    return info


class MOTD(ABC):
    """Message of the Day 基类

    提供启动时统一的信息展示。
    """

    def __init__(
        self,
        logo: Optional[str],
        serve_location: str,
        data: Dict[str, str],
        extra: Optional[Dict[str, str]] = None,
    ):
        self.logo = logo
        self.serve_location = serve_location
        self.data = data
        self.extra = extra or {}

    @abstractmethod
    def display(self) -> None:
        ...

    @classmethod
    def output(
        cls,
        logo: Optional[str],
        serve_location: str,
        data: Dict[str, str],
        extra: Optional[Dict[str, str]] = None,
    ) -> None:
        motd = cls(logo, serve_location, data, extra)
        motd.display()


class MOTDBasic(MOTD):
    """基础 MOTD - 适用于不支持 ANSI 的终端"""

    def display(self) -> None:
        from kewe.logging.logger import get_logger
        logger = get_logger("kewe.root")

        if self.logo:
            for line in self.logo.split("\n"):
                if line.strip():
                    logger.info(line)

        logger.info(f"Going Fast @ {self.serve_location}")

        for key, value in self.data.items():
            logger.info(f"{key}: {value}")

        for key, value in self.extra.items():
            logger.info(f"{key}: {value}")


class MOTDTTY(MOTD):
    """TTY MOTD - 适用于支持 ANSI 的终端

    提供彩色、对齐的启动信息展示。
    """

    def display(self, version: bool = True, action: str = "Going Fast", out=None) -> None:
        if out is None:
            out = print

        if self.logo:
            out(self.logo)

        if version:
            version_str = get_version_display()
            if _supports_color():
                out(f"  {_COLOR_BOLD}{_COLOR_GREEN}{action}{_COLOR_RESET} @ {self.serve_location}  {_COLOR_DIM}{version_str}{_COLOR_RESET}")
            else:
                out(f"  {action} @ {self.serve_location}  {version_str}")
        else:
            if _supports_color():
                out(f"  {_COLOR_BOLD}{_COLOR_GREEN}{action}{_COLOR_RESET} @ {self.serve_location}")
            else:
                out(f"  {action} @ {self.serve_location}")

        all_keys = list(self.data.keys()) + list(self.extra.keys())
        max_key_len = max(len(k) for k in all_keys) if all_keys else 0

        for key, value in self.data.items():
            padded_key = key.rjust(max_key_len)
            if _supports_color():
                out(f"  {_COLOR_DIM}{padded_key}:{_COLOR_RESET} {value}")
            else:
                out(f"  {padded_key}: {value}")

        for key, value in self.extra.items():
            padded_key = key.rjust(max_key_len)
            if _supports_color():
                out(f"  {_COLOR_DIM}{padded_key}:{_COLOR_RESET} {value}")
            else:
                out(f"  {padded_key}: {value}")


def display_motd(
    serve_location: str,
    data: Optional[Dict[str, str]] = None,
    extra: Optional[Dict[str, str]] = None,
    full: bool = False,
    coffee: bool = False,
) -> None:
    """显示启动 MOTD

    统一入口函数，自动检测终端能力选择合适的 MOTD 渲染器。

    Args:
        serve_location: 服务地址，如 "http://0.0.0.0:8000"
        data: 主要信息字典，如 {"mode": "production", "workers": "4"}
        extra: 附加信息字典
        full: 是否显示完整 ASCII art logo
        coffee: 是否显示咖啡主题
    """
    logo = get_logo(full=full, coffee=coffee)
    data = data or {}
    extra = extra or {}

    if _supports_color():
        motd_cls = MOTDTTY
    else:
        motd_cls = MOTDBasic

    motd_cls.output(logo, serve_location, data, extra)
