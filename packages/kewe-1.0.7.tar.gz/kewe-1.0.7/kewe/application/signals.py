#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.application.signals - Event-driven signal system with dynamic pattern matching
"""

import asyncio
import logging
import threading
from typing import Dict, List, Callable, Any, Optional, Awaitable, Union
from dataclasses import dataclass, field
from enum import Enum
from collections import defaultdict
from functools import wraps
import inspect

logger = logging.getLogger(__name__)


class SignalEvent(Enum):
    """信号事件类型"""
    HTTP_ROUTING_BEFORE = "http.routing.before"
    HTTP_ROUTING_AFTER = "http.routing.after"
    HTTP_HANDLER_BEFORE = "http.handler.before"
    HTTP_HANDLER_AFTER = "http.handler.after"
    HTTP_LIFECYCLE_BEGIN = "http.lifecycle.begin"
    HTTP_LIFECYCLE_READ_HEAD = "http.lifecycle.read_head"
    HTTP_LIFECYCLE_REQUEST = "http.lifecycle.request"
    HTTP_LIFECYCLE_HANDLE = "http.lifecycle.handle"
    HTTP_LIFECYCLE_READ_BODY = "http.lifecycle.read_body"
    HTTP_LIFECYCLE_EXCEPTION = "http.lifecycle.exception"
    HTTP_LIFECYCLE_RESPONSE = "http.lifecycle.response"
    HTTP_LIFECYCLE_SEND = "http.lifecycle.send"
    HTTP_LIFECYCLE_COMPLETE = "http.lifecycle.complete"
    HTTP_MIDDLEWARE_BEFORE = "http.middleware.before"
    HTTP_MIDDLEWARE_AFTER = "http.middleware.after"
    
    SERVER_EXCEPTION_REPORT = "server.exception.report"
    SERVER_INIT_BEFORE = "server.init.before"
    SERVER_INIT_AFTER = "server.init.after"
    SERVER_SHUTDOWN_BEFORE = "server.shutdown.before"
    SERVER_SHUTDOWN_AFTER = "server.shutdown.after"
    
    WEBSOCKET_CONNECT = "websocket.connect"
    WEBSOCKET_DISCONNECT = "websocket.disconnect"
    WEBSOCKET_MESSAGE = "websocket.message"
    WEBSOCKET_HANDLER_BEFORE = "websocket.handler.before"
    WEBSOCKET_HANDLER_AFTER = "websocket.handler.after"
    WEBSOCKET_HANDLER_EXCEPTION = "websocket.handler.exception"
    
    ROUTE_ADDED = "route.added"
    ROUTE_REMOVED = "route.removed"
    
    MIDDLEWARE_ADDED = "middleware.added"
    
    BLUEPRINT_REGISTERED = "blueprint.registered"
    
    EXCEPTION_RAISED = "exception.raised"



@dataclass
class SignalContext:
    """信号上下文"""
    event: SignalEvent
    data: Dict[str, Any] = field(default_factory=dict)
    cancelled: bool = False
    skip_remaining: bool = False
    
    def cancel(self):
        """取消后续处理"""
        self.cancelled = True
    
    def skip(self):
        """跳过剩余处理器"""
        self.skip_remaining = True


@dataclass
class HandlerInfo:
    """处理器信息"""
    handler: Callable
    priority: int = 50
    once: bool = False
    condition: Optional[Callable[[SignalContext], bool]] = None


class Signal:
    """
    信号类 - 单个信号的管理
    
    使用示例:
        signal = Signal(SignalEvent.HTTP_REQUEST)
        
        @signal.handler
        async def log_request(ctx: SignalContext):
            print(f"Request: {ctx.data.get('request')}")
    """
    
    def __init__(self, event: SignalEvent):
        self.event = event
        self._handlers: List[HandlerInfo] = []
        self._once_handlers: List[HandlerInfo] = []
        self._lock = threading.Lock()
    
    def handler(
        self,
        priority: int = 50,
        once: bool = False,
        condition: Optional[Callable[[SignalContext], bool]] = None
    ) -> Callable:
        """
        注册处理器装饰器
        
        Args:
            priority: 优先级（数值越小越先执行）
            once: 是否只执行一次
            condition: 执行条件
        """
        def decorator(func: Callable) -> Callable:
            self._register_handler(func, priority, once, condition)
            return func
        return decorator
    
    def _register_handler(
        self,
        handler: Callable,
        priority: int = 50,
        once: bool = False,
        condition: Optional[Callable[[SignalContext], bool]] = None
    ):
        """注册处理器"""
        info = HandlerInfo(
            handler=handler,
            priority=priority,
            once=once,
            condition=condition
        )
        
        with self._lock:
            self._handlers.append(info)
            self._handlers.sort(key=lambda x: x.priority)
    
    def register(
        self,
        handler: Callable,
        priority: int = 50,
        once: bool = False,
        condition: Optional[Callable[[SignalContext], bool]] = None
    ):
        """注册处理器（非装饰器方式）"""
        self._register_handler(handler, priority, once, condition)
    
    def unregister(self, handler: Callable) -> bool:
        """注销处理器"""
        with self._lock:
            for i, info in enumerate(self._handlers):
                if info.handler == handler:
                    self._handlers.pop(i)
                    return True
        return False
    
    async def emit(self, data: Dict[str, Any] = None) -> SignalContext:
        ctx = SignalContext(event=self.event, data=data or {})

        with self._lock:
            handlers_snapshot = list(self._handlers)

        handlers_to_remove = []

        for info in handlers_snapshot:
            if ctx.cancelled or ctx.skip_remaining:
                break
            
            if info.condition and not info.condition(ctx):
                continue
            
            try:
                sig = inspect.signature(info.handler)
                params = list(sig.parameters.values())
                if len(params) > 0:
                    first_param = params[0]
                    first_annotation = first_param.annotation
                    if first_annotation is SignalContext or (
                        isinstance(first_annotation, str) and first_annotation == 'SignalContext'
                    ):
                        result = info.handler(ctx)
                    elif first_param.name == 'ctx':
                        result = info.handler(ctx)
                    else:
                        result = info.handler(data or {})
                else:
                    result = info.handler(data or {})
                if inspect.isawaitable(result):
                    await result
                
                if info.once:
                    handlers_to_remove.append(info)
                    
            except Exception as e:
                event_name = self.event.value if hasattr(self.event, 'value') else str(self.event)
                logger.error(f"Signal handler error for {event_name}: {e}")
        
        for info in handlers_to_remove:
            with self._lock:
                if info in self._handlers:
                    self._handlers.remove(info)
        
        return ctx
    
    def clear(self):
        """清除所有处理器"""
        self._handlers.clear()
    
    @property
    def has_handlers(self) -> bool:
        """是否有处理器"""
        return len(self._handlers) > 0


class SignalBus:
    """
    信号总线 - 管理所有信号
    
    使用示例:
        bus = SignalBus()
        
        @bus.on(SignalEvent.HTTP_REQUEST)
        async def log_request(ctx):
            print(f"Request received")
        
        await bus.emit(SignalEvent.HTTP_REQUEST, {"request": request})
    """
    
    def __init__(self):
        self._signals: Dict[SignalEvent, Signal] = {
            event: Signal(event) for event in SignalEvent
        }
        self._custom_signals: Dict[str, Signal] = {}
    
    def on(
        self,
        event: Union[SignalEvent, str],
        priority: int = 50,
        once: bool = False,
        condition: Optional[Callable[[SignalContext], bool]] = None
    ) -> Callable:
        """
        注册信号处理器装饰器
        
        Args:
            event: 信号事件
            priority: 优先级
            once: 是否只执行一次
            condition: 执行条件
        """
        def decorator(func: Callable) -> Callable:
            self.register(event, func, priority, once, condition)
            return func
        return decorator
    
    def register(
        self,
        event: Union[SignalEvent, str],
        handler: Callable,
        priority: int = 50,
        once: bool = False,
        condition: Optional[Callable[[SignalContext], bool]] = None
    ):
        """注册信号处理器"""
        if isinstance(event, SignalEvent):
            signal = self._signals.get(event)
            if signal is None:
                signal = Signal(event)
                self._signals[event] = signal
        else:
            signal = self._custom_signals.get(event)
            if signal is None:
                signal = Signal(event)
                self._custom_signals[event] = signal
        
        signal.register(handler, priority, once, condition)
    
    def unregister(self, event: Union[SignalEvent, str], handler: Callable) -> bool:
        """注销信号处理器"""
        if isinstance(event, SignalEvent):
            signal = self._signals.get(event)
        else:
            signal = self._custom_signals.get(event)
        
        if signal:
            return signal.unregister(handler)
        return False
    
    async def emit(
        self,
        event: Union[SignalEvent, str],
        data: Dict[str, Any] = None
    ) -> SignalContext:
        """触发信号"""
        if isinstance(event, SignalEvent):
            signal = self._signals.get(event)
        else:
            signal = self._custom_signals.get(event)
        
        if signal:
            return await signal.emit(data)
        
        return SignalContext(event=event if isinstance(event, SignalEvent) else None, data=data or {})
    
    def get_signal(self, event: Union[SignalEvent, str]) -> Optional[Signal]:
        """获取信号"""
        if isinstance(event, SignalEvent):
            return self._signals.get(event)
        return self._custom_signals.get(event)
    
    def create_custom_signal(self, name: str) -> Signal:
        """创建自定义信号"""
        if name not in self._custom_signals:
            self._custom_signals[name] = Signal(name)
        return self._custom_signals[name]
    
    def clear(self, event: Union[SignalEvent, str] = None):
        """清除信号处理器"""
        if event is None:
            for signal in self._signals.values():
                signal.clear()
            self._custom_signals.clear()
        elif isinstance(event, SignalEvent):
            if event in self._signals:
                self._signals[event].clear()
        elif event in self._custom_signals:
            self._custom_signals[event].clear()


_global_signal_bus: Optional[SignalBus] = None


def get_signal_bus() -> SignalBus:
    global _global_signal_bus
    if _global_signal_bus is None:
        _global_signal_bus = SignalBus()
    return _global_signal_bus


def set_signal_bus(bus: SignalBus):
    global _global_signal_bus
    _global_signal_bus = bus


class SignalManager(SignalBus):
    __slots__ = ('_name',)

    def __init__(self, name: str = "default"):
        super().__init__()
        self._name = name

    @property
    def name(self) -> str:
        return self._name

    def connect(self, signal_name: str, handler: Callable, priority: int = 0) -> str:
        return self.on(signal_name, handler, priority)

    def disconnect(self, signal_name: str, handler_id: str) -> bool:
        return self.off(signal_name, handler_id)

    def emit_sync(self, signal_name: str, **kwargs):
        import asyncio
        try:
            loop = asyncio.get_running_loop()
            loop.create_task(self.emit(signal_name, **kwargs))
        except RuntimeError:
            asyncio.run(self.emit(signal_name, **kwargs))


class SignalMiddleware:
    """
    信号中间件 - 将信号系统集成到请求处理流程
    
    使用示例:
        app = Kewe("MyApp")
        signal_middleware = SignalMiddleware(app.signal_bus)
        app.middleware_manager.register(signal_middleware.on_request, attach_to="request")
        app.middleware_manager.register(signal_middleware.on_response, attach_to="response")
    """
    
    def __init__(self, bus: SignalBus):
        if bus is None:
            raise ValueError(
                "SignalMiddleware requires a SignalBus instance. "
                "Use SignalMiddleware(app.signal_bus)."
            )
        self.bus = bus
    
    async def on_request(self, request):
        ctx = await self.bus.emit(SignalEvent.HTTP_LIFECYCLE_REQUEST, {
            "request": request,
            "method": request.method,
            "path": request.path,
            "headers": dict(request.headers),
            "client_ip": request.client_ip,
        })
        
        if ctx.cancelled:
            from kewe.response import json
            return json({"error": "Request cancelled"}, status=499)
        
        return True
    
    async def on_response(self, request, response):
        await self.bus.emit(SignalEvent.HTTP_LIFECYCLE_RESPONSE, {
            "request": request,
            "response": response,
            "status": response.status,
        })
    
    async def on_error(self, request, exception):
        await self.bus.emit(SignalEvent.HTTP_LIFECYCLE_EXCEPTION, {
            "request": request,
            "exception": exception,
        })


__all__ = [
    'SignalEvent',
    'EventWaiter',
    'SignalContext',
    'Signal',
    'SignalBus',
    'SignalMiddleware',
    'get_signal_bus',
    'set_signal_bus',
    'wait_for_event',
    'DynamicSignal',
    'SignalManager',
]


class DynamicSignal:
    """
    动态信号支持
    
    支持动态信号路径，如 "foo.bar.<thing>"
    
    使用示例:
        @app.signal("foo.bar.<thing>")
        async def signal_handler(thing):
            print(f"thing={thing}")
        
        await app.dispatch("foo.bar.baz")  # 匹配
        
        # 等待时使用通配符
        await app.event("foo.bar.*")
    """
    
    def __init__(self, pattern: str):
        self.pattern = pattern
        self._handlers: List[HandlerInfo] = []
        self._is_dynamic = '<' in pattern and '>' in pattern
        self._regex = self._compile_pattern(pattern) if self._is_dynamic else None
    
    def _compile_pattern(self, pattern: str):
        """编译动态模式为正则表达式"""
        import re
        regex_pattern = pattern
        regex_pattern = regex_pattern.replace('.', r'\.')
        regex_pattern = re.sub(r'<(\w+)>', r'(?P<\1>[^.]+)', regex_pattern)
        regex_pattern = f'^{regex_pattern}$'
        return re.compile(regex_pattern)
    
    def matches(self, event: str) -> Optional[Dict[str, str]]:
        """
        检查事件是否匹配模式
        
        Args:
            event: 事件名称
            
        Returns:
            匹配的参数字典，如果不匹配返回 None
        """
        if event == self.pattern:
            return {}
        
        if self._is_dynamic and self._regex:
            match = self._regex.match(event)
            if match:
                return match.groupdict()
        
        return None
    
    def add_handler(
        self,
        handler: Callable,
        priority: int = 50,
        once: bool = False,
        condition: Optional[Callable] = None
    ):
        """添加处理器"""
        self._handlers.append(HandlerInfo(
            handler=handler,
            priority=priority,
            once=once,
            condition=condition
        ))
        self._handlers.sort(key=lambda x: x.priority)
    
    async def emit(self, event: str, data: Dict[str, Any] = None):
        """触发信号"""
        params = self.matches(event)
        if params is None:
            return
        
        ctx = SignalContext(event=self.pattern, data={**(data or {}), **params})
        
        handlers_to_remove = []
        for info in self._handlers:
            if ctx.cancelled or ctx.skip_remaining:
                break
            
            if info.condition and not info.condition(ctx):
                continue
            
            try:
                result = info.handler(**params, **(data or {}))
                if inspect.isawaitable(result):
                    await result
                
                if info.once:
                    handlers_to_remove.append(info)
            except Exception as e:
                logger.error(f"Dynamic signal handler error: {e}")
        
        for info in handlers_to_remove:
            if info in self._handlers:
                self._handlers.remove(info)


class EventWaiter:
    """
    事件等待器
    
    支持 app.event() 等待特定事件
    
    使用示例:
        async def wait_for_event(app):
            while True:
                await app.event("foo.bar.baz")
                print("event found")
        
        @app.after_server_start
        async def after_server_start(app, loop):
            app.add_task(wait_for_event(app))
    """
    
    def __init__(self):
        self._waiters: Dict[str, List[asyncio.Event]] = defaultdict(list)
        self._data: Dict[str, Any] = {}
    
    def wait(self, event: str) -> asyncio.Event:
        """
        创建等待事件
        
        Args:
            event: 事件名称（支持通配符 *）
            
        Returns:
            asyncio.Event 实例
        """
        waiter = asyncio.Event()
        self._waiters[event].append(waiter)
        return waiter
    
    def notify(self, event: str, data: Any = None):
        """
        通知等待者
        
        Args:
            event: 事件名称
            data: 事件数据
        """
        self._data[event] = data
        
        if event in self._waiters:
            for waiter in self._waiters[event]:
                waiter.set()
            self._waiters[event].clear()
        
        for pattern, waiters in list(self._waiters.items()):
            if '*' in pattern:
                prefix = pattern.replace('*', '')
                if event.startswith(prefix):
                    for waiter in waiters:
                        waiter.set()
                    self._waiters[pattern].clear()
    
    async def wait_for(self, event: str, timeout: Optional[float] = None) -> Any:
        """
        等待事件
        
        Args:
            event: 事件名称
            timeout: 超时时间
            
        Returns:
            事件数据
        """
        waiter = self.wait(event)
        
        try:
            await asyncio.wait_for(waiter.wait(), timeout)
            return self._data.get(event)
        except asyncio.TimeoutError:
            return None


_global_event_waiter: Optional[EventWaiter] = None


def get_event_waiter() -> EventWaiter:
    """获取全局事件等待器"""
    global _global_event_waiter
    if _global_event_waiter is None:
        _global_event_waiter = EventWaiter()
    return _global_event_waiter


async def wait_for_event(event: str, timeout: Optional[float] = None) -> Any:
    """
    等待事件（全局）
    
    Args:
        event: 事件名称
        timeout: 超时时间
        
    Returns:
        事件数据
    """
    return await get_event_waiter().wait_for(event, timeout)
