#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.application.depends - Declarative dependency injection with parameter-level validation
"""

import asyncio
import inspect
import logging
from kewe.utils.compat import json as _json
import contextvars
import enum
from typing import Any, Callable, Dict, Optional, Type, List, Tuple, Union

try:
    from typing import Annotated as _Annotated, get_origin as _get_origin, get_args as _get_args
    _ANNOTATED_AVAILABLE = True
except ImportError:
    _ANNOTATED_AVAILABLE = False

logger = logging.getLogger(__name__)


class Depends:
    __slots__ = ('dependency', 'use_cache', 'cache_key')

    """
    依赖声明标记
    
    支持:
    - 函数作为依赖
    - 类作为依赖（自动实例化）
    - 依赖缓存
    - 嵌套依赖
    
    用法:
        def get_db(request: Request) -> Database:
            return request.app.db
        
        @app.get("/items")
        async def items(db: Database = Depends(get_db)):
            ...
        
        # 类作为依赖
        class CommonQueryParams:
            def __init__(self, request: Request):
                self.q = request.args.get("q", "")
                self.offset = int(request.args.get("offset", 0))
                self.limit = int(request.args.get("limit", 100))
        
        @app.get("/items")
        async def items(commons: CommonQueryParams = Depends(CommonQueryParams)):
            ...
    """
    
    def __init__(
        self,
        dependency: Any = None,
        *,
        use_cache: bool = True,
    ):
        self.dependency = dependency
        self.use_cache = use_cache
        self.cache_key = None
        
        if dependency is not None:
            self.cache_key = _get_cache_key(dependency)
    
    def __repr__(self) -> str:
        dep_name = getattr(self.dependency, '__name__', str(self.dependency))
        return f"Depends({dep_name})"


def _get_cache_key(func: Callable) -> str:
    module = getattr(func, '__module__', '')
    qualname = getattr(func, '__qualname__', getattr(func, '__name__', str(func)))
    return f"{module}.{qualname}"


_SENTINEL = object()


def _is_pydantic_model(cls):
    try:
        from pydantic import BaseModel
        return isinstance(cls, type) and issubclass(cls, BaseModel)
    except ImportError:
        return False


def _get_pydantic_model_marker(default):
    try:
        from kewe.plugins.pydantic_support import BodyModel, QueryModel, HeaderModel, PathModel
        if isinstance(default, BodyModel):
            return 'body'
        if isinstance(default, QueryModel):
            return 'query'
        if isinstance(default, HeaderModel):
            return 'header'
        if isinstance(default, PathModel):
            return 'path'
    except ImportError:
        pass
    return None


_SENTINEL = object()


class DependencyResolver:
    
    _sig_cache: Dict[str, Tuple[Any, Dict[str, Any]]] = {}
    
    def __init__(self):
        self._overrides: Dict[str, Callable] = {}
        self._global_dependencies: List[Depends] = []
        self._resolved_cache_var: contextvars.ContextVar[Dict[str, Any]] = contextvars.ContextVar(
            'dep_resolved_cache'
        )
        self._generator_cleanups_var: contextvars.ContextVar[List] = contextvars.ContextVar(
            'dep_generator_cleanups'
        )
    
    def override(self, dependency: Callable, override: Callable) -> None:
        """覆盖依赖（测试用）"""
        key = _get_cache_key(dependency)
        self._overrides[key] = override
    
    def clear_overrides(self) -> None:
        """清除所有覆盖"""
        self._overrides.clear()
    
    def add_global_dependency(self, depends: Depends) -> None:
        """添加全局依赖"""
        self._global_dependencies.append(depends)
    
    async def resolve(
        self,
        dependency: Callable,
        request: Any = None,
        app: Any = None,
        _resolving_stack: Optional[set] = None,
    ) -> Any:
        """
        解析依赖
        
        Args:
            dependency: 依赖函数
            request: 请求对象
            app: 应用实例
            _resolving_stack: 解析栈（循环依赖检测）
        """
        if _resolving_stack is None:
            _resolving_stack = set()
        
        cache_key = _get_cache_key(dependency)
        
        if cache_key in _resolving_stack:
            raise ValueError(f"Circular dependency detected: {cache_key}")
        
        use_cache = True
        if isinstance(dependency, Depends):
            use_cache = dependency.use_cache
        elif hasattr(dependency, 'use_cache'):
            use_cache = dependency.use_cache
        
        if use_cache:
            resolved_cache = self._resolved_cache_var.get(_SENTINEL)
            if resolved_cache is _SENTINEL:
                resolved_cache = {}
                self._resolved_cache_var.set(resolved_cache)
            elif cache_key in resolved_cache:
                return resolved_cache[cache_key]
        
        actual_func = self._overrides.get(cache_key, dependency)
        
        if isinstance(actual_func, Depends):
            actual_func = actual_func.dependency
        
        _resolving_stack = _resolving_stack | {cache_key}
        
        if inspect.isclass(actual_func):
            kwargs = await self._resolve_parameters(actual_func.__init__, request, app, _resolving_stack, skip_self=True)
            result = actual_func(**kwargs)
        else:
            kwargs = await self._resolve_parameters(actual_func, request, app, _resolving_stack)
            
            if asyncio.iscoroutinefunction(actual_func):
                result = await actual_func(**kwargs)
            else:
                gen = actual_func(**kwargs)

                if inspect.isgenerator(gen):
                    result = next(gen)
                    cleanups = self._generator_cleanups_var.get(_SENTINEL)
                    if cleanups is _SENTINEL:
                        cleanups = []
                        self._generator_cleanups_var.set(cleanups)

                    def make_cleanup(g):
                        def cleanup(exc=None):
                            try:
                                if exc is not None:
                                    g.throw(exc)
                                else:
                                    next(g)
                            except (StopIteration, Exception):
                                logger.debug("Dependency generator cleanup raised exception", exc_info=True)
                        return cleanup

                    cleanups.append(make_cleanup(gen))
                elif inspect.isasyncgen(gen):
                    result = await gen.__anext__()
                    cleanups = self._generator_cleanups_var.get(_SENTINEL)
                    if cleanups is _SENTINEL:
                        cleanups = []
                        self._generator_cleanups_var.set(cleanups)

                    def make_async_cleanup(g):
                        async def cleanup(exc=None):
                            try:
                                if exc is not None:
                                    await g.athrow(exc)
                                else:
                                    await g.__anext__()
                            except (StopAsyncIteration, Exception):
                                logger.debug("Async dependency generator cleanup raised exception", exc_info=True)
                        return cleanup

                    cleanups.append(make_async_cleanup(gen))
                else:
                    result = gen
        
        if use_cache:
            if resolved_cache is _SENTINEL:
                resolved_cache = {}
                self._resolved_cache_var.set(resolved_cache)
            resolved_cache[cache_key] = result
        
        return result
    
    async def _resolve_parameters(
        self,
        func: Callable,
        request: Any,
        app: Any,
        _resolving_stack: set,
        skip_self: bool = False,
    ) -> Dict[str, Any]:
        func_id = f"{getattr(func, '__module__', '')}.{getattr(func, '__qualname__', '')}"
        cached = DependencyResolver._sig_cache.get(func_id)
        if cached is not None:
            sig, type_hints = cached
        else:
            sig = inspect.signature(func)
            try:
                import typing
                type_hints = typing.get_type_hints(func)
            except Exception:
                try:
                    type_hints = inspect.get_annotations(func) if hasattr(inspect, 'get_annotations') else {}
                except Exception:
                    type_hints = {}
            DependencyResolver._sig_cache[func_id] = (sig, type_hints)
        kwargs = {}
        
        first_param_done = False
        for name, param in sig.parameters.items():
            if skip_self and name == 'self':
                continue

            if not first_param_done:
                first_param_done = True
                ann = param.annotation if param.annotation is not inspect.Parameter.empty else None
                is_request_type = False
                if ann is not None:
                    ann_name = getattr(ann, '__name__', '') or getattr(ann, '__qualname__', '')
                    if 'Request' in ann_name:
                        is_request_type = True
                if name in ('request', 'req') or is_request_type or ann is None:
                    kwargs[name] = request
                    continue

            if name in ('request', 'req'):
                kwargs[name] = request
                continue
            
            if name in ('app',):
                kwargs[name] = app
                continue

            if name == 'security_scopes':
                kwargs[name] = SecurityScopes(scopes=[])
                continue

            param_annotation = param.annotation if param.annotation is not inspect.Parameter.empty else None
            annotated_dep = self._extract_annotated_dependency(param_annotation)
            if annotated_dep is None:
                annotated_dep = self._extract_annotated_dependency(type_hints.get(name))
            if annotated_dep is not None:
                if isinstance(annotated_dep, Depends):
                    dep_func = annotated_dep.dependency
                    if dep_func is None:
                        if param_annotation is not None:
                            from typing import get_origin, get_args
                            try:
                                from typing import Annotated as _Annotated
                                if get_origin(param_annotation) is _Annotated:
                                    dep_func = get_args(param_annotation)[0]
                            except ImportError:
                                pass
                        if dep_func is None:
                            dep_func = type_hints.get(name)
                    if dep_func is not None:
                        is_optional = self._is_optional_type(type_hints.get(name))
                        try:
                            if isinstance(annotated_dep, Security) and annotated_dep.scopes:
                                if 'security_scopes' not in kwargs:
                                    kwargs['security_scopes'] = SecurityScopes(scopes=annotated_dep.scopes)
                                else:
                                    existing = kwargs['security_scopes']
                                    if isinstance(existing, SecurityScopes):
                                        existing.scopes = list(set(existing.scopes + annotated_dep.scopes))
                            dep_result = await self.resolve(
                                dep_func,
                                request=request,
                                app=app,
                                _resolving_stack=_resolving_stack,
                            )
                            kwargs[name] = dep_result
                        except Exception:
                            if is_optional:
                                kwargs[name] = None
                            else:
                                raise
                elif isinstance(annotated_dep, _ParamDependency):
                    p_type = type_hints.get(name)
                    if hasattr(annotated_dep, 'extract_async'):
                        kwargs[name] = await annotated_dep.extract_async(request, param_name=name, target_type=p_type)
                    elif hasattr(annotated_dep, 'extract'):
                        kwargs[name] = annotated_dep.extract(request, param_name=name, target_type=p_type)
                continue
            
            if isinstance(param.default, Depends):
                dep = param.default
                dep_func = dep.dependency
                if dep_func is None:
                    dep_func = type_hints.get(name)
                if dep_func is not None:
                    is_optional = self._is_optional_type(type_hints.get(name))
                    try:
                        dep_result = await self.resolve(
                            dep_func,
                            request=request,
                            app=app,
                            _resolving_stack=_resolving_stack,
                        )
                        kwargs[name] = dep_result
                    except Exception:
                        if is_optional:
                            kwargs[name] = None
                        else:
                            raise
                continue
            
            if isinstance(param.default, _ParamDependency):
                param_dep = param.default
                p_type = type_hints.get(name)
                if hasattr(param_dep, 'extract_async'):
                    kwargs[name] = await param_dep.extract_async(request, param_name=name, target_type=p_type)
                elif hasattr(param_dep, 'extract'):
                    kwargs[name] = param_dep.extract(request, param_name=name, target_type=p_type)
                continue

            pydantic_inject = await self._try_pydantic_inject(param, name, type_hints.get(name), request)
            if pydantic_inject is not _SENTINEL:
                kwargs[name] = pydantic_inject
                continue
            
            if param.default is not inspect.Parameter.empty:
                continue
            
            param_type = type_hints.get(name)
            if param_type is not None and app is not None and hasattr(app, 'container'):
                try:
                    if app.container.can_resolve(param_type):
                        if hasattr(app.container, 'aresolve'):
                            kwargs[name] = await app.container.aresolve(param_type)
                        else:
                            kwargs[name] = app.container.resolve(param_type)
                except Exception:
                    logger.debug("Failed to resolve container dependency for %s", param_type, exc_info=True)

        return kwargs

    @staticmethod
    def _is_optional_type(type_hint) -> bool:
        if type_hint is None:
            return False
        try:
            from typing import get_origin, get_args, Union
            origin = get_origin(type_hint)
            if origin is Union:
                args = get_args(type_hint)
                return type(None) in args
        except Exception:
            logger.debug("Failed to check optional type for %s", type_hint, exc_info=True)
        return False

    async def _try_pydantic_inject(self, param, name, type_hint, request):
        """尝试 Pydantic 模型自动注入

        当参数类型是 Pydantic BaseModel 且默认值是 BodyModel/QueryModel/HeaderModel/PathModel 时，
        自动从请求中提取并验证数据。
        """
        if type_hint is None or not _is_pydantic_model(type_hint):
            return _SENTINEL

        marker = _get_pydantic_model_marker(param.default)
        if marker is None:
            if _is_pydantic_model(type_hint) and param.default is inspect.Parameter.empty:
                marker = 'body'
            else:
                return _SENTINEL

        try:
            if marker == 'body':
                body_data = request._json
                if body_data is None:
                    raw = await request.body
                    if raw:
                        body_data = _json.loads(raw)
                if body_data is not None:
                    return type_hint.model_validate(body_data)
                return _SENTINEL

            elif marker == 'query':
                query_dict = dict(request.args)
                return type_hint.model_validate(query_dict)

            elif marker == 'header':
                header_dict = dict(request.headers)
                return type_hint.model_validate(header_dict)

            elif marker == 'path':
                path_dict = getattr(request, 'path_params', {}) or {}
                return type_hint.model_validate(path_dict)

        except Exception:
            if self._is_optional_type(type_hint):
                return None
            raise

        return _SENTINEL

    @staticmethod
    def _extract_annotated_dependency(type_hint):
        if type_hint is None or not _ANNOTATED_AVAILABLE:
            return None
        if _get_origin(type_hint) is not _Annotated:
            return None
        args = _get_args(type_hint)
        for metadata in args[1:]:
            if isinstance(metadata, (Depends, _ParamDependency)):
                return metadata
        return None
    
    async def resolve_handler(
        self,
        handler: Callable,
        request: Any = None,
        app: Any = None,
    ) -> Dict[str, Any]:
        self._resolved_cache_var.set({})
        self._generator_cleanups_var.set([])
        return await self._resolve_parameters(handler, request, app, [])
    
    async def cleanup_generators(self, exc=None):
        cleanups = self._generator_cleanups_var.get([])
        for cleanup in reversed(cleanups):
            try:
                if asyncio.iscoroutinefunction(cleanup):
                    await cleanup(exc)
                else:
                    cleanup(exc)
            except Exception as e:
                logger.error(
                    f"Error in dependency cleanup: {e}", exc_info=True
                )
        self._generator_cleanups_var.set([])
    
    def get_dependencies(self, func: Callable) -> List[Tuple[str, Depends]]:
        """获取函数的所有依赖声明"""
        sig = inspect.signature(func)
        deps = []
        
        for name, param in sig.parameters.items():
            if isinstance(param.default, Depends):
                deps.append((name, param.default))
        
        return deps


class DependencyOverrideManager:
    """依赖覆盖管理器 - 用于测试"""
    
    def __init__(self, resolver: DependencyResolver):
        self._resolver = resolver
        self._original_overrides: Dict[str, Callable] = {}
    
    def __setitem__(self, dependency: Callable, override: Callable):
        key = _get_cache_key(dependency)
        if key not in self._original_overrides:
            self._original_overrides[key] = self._resolver._overrides.get(key)
        self._resolver.override(dependency, override)
    
    def __delitem__(self, dependency: Callable):
        key = _get_cache_key(dependency)
        original = self._original_overrides.pop(key, None)
        if original is not None:
            self._resolver._overrides[key] = original
        else:
            self._resolver._overrides.pop(key, None)

    def __getitem__(self, dependency: Callable) -> Optional[Callable]:
        key = _get_cache_key(dependency)
        return self._resolver._overrides.get(key)

    def __contains__(self, dependency: Callable) -> bool:
        key = _get_cache_key(dependency)
        return key in self._resolver._overrides

    def get(self, dependency: Callable, default: Any = None) -> Any:
        key = _get_cache_key(dependency)
        return self._resolver._overrides.get(key, default)
    
    def clear(self):
        self._resolver.clear_overrides()
        self._original_overrides.clear()


__all__ = [
    'Depends',
    'DependencyResolver',
    'DependencyOverrideManager',
    'Query',
    'Header',
    'CookieParam',
    'Path',
    'Body',
    'Form',
    'File',
    'Security',
    'get_current_user',
    'get_current_active_user',
    'require_roles',
    'require_permissions',
    'FieldType',
    'Field',
    'Validator',
    'RequestValidator',
    'FieldValidationError',
    'validate_request',
    'validate',
]


class FieldType(enum.Enum):
    STRING = "string"
    INTEGER = "integer"
    FLOAT = "float"
    BOOLEAN = "boolean"
    EMAIL = "email"
    URL = "url"
    UUID = "uuid"
    DATE = "date"
    DATETIME = "datetime"
    LIST = "list"
    DICT = "dict"


class Field:

    def __init__(
        self,
        name: str,
        type: FieldType = FieldType.STRING,
        required: bool = False,
        default: Any = None,
        min_length: Optional[int] = None,
        max_length: Optional[int] = None,
        minimum: Optional[Union[int, float]] = None,
        maximum: Optional[Union[int, float]] = None,
        min_value: Optional[Union[int, float]] = None,
        max_value: Optional[Union[int, float]] = None,
        choices: Optional[List[Any]] = None,
        pattern: Optional[str] = None,
        description: Optional[str] = None,
    ):
        self.name = name
        self.type = type
        self.required = required
        self.default = default
        self.min_length = min_length
        self.max_length = max_length
        self.minimum = minimum if minimum is not None else min_value
        self.maximum = maximum if maximum is not None else max_value
        self.choices = choices
        self.pattern = pattern
        self.description = description


class FieldValidationError(Exception):

    def __init__(self, message: str, field: str = None, errors: List[Dict] = None):
        super().__init__(message)
        self.field = field
        self.errors = errors or []


class Validator:

    def __init__(self, fields: List[Field]):
        self.fields = fields
        self._field_map = {f.name: f for f in fields}

    def validate(self, data: Dict[str, Any]) -> Dict[str, Any]:
        result = {}
        errors = []

        for field in self.fields:
            value = data.get(field.name)

            if value is None:
                if field.required:
                    errors.append({
                        "field": field.name,
                        "message": f"Field '{field.name}' is required",
                        "type": "required",
                    })
                else:
                    result[field.name] = field.default
                continue

            try:
                value = self._coerce_type(value, field)
            except (ValueError, TypeError) as e:
                errors.append({
                    "field": field.name,
                    "message": str(e),
                    "type": "type_error",
                })
                continue

            if field.min_length is not None and isinstance(value, str) and len(value) < field.min_length:
                errors.append({
                    "field": field.name,
                    "message": f"Field '{field.name}' must be at least {field.min_length} characters",
                    "type": "min_length",
                })
                continue

            if field.max_length is not None and isinstance(value, str) and len(value) > field.max_length:
                errors.append({
                    "field": field.name,
                    "message": f"Field '{field.name}' must be at most {field.max_length} characters",
                    "type": "max_length",
                })
                continue

            if field.minimum is not None and isinstance(value, (int, float)) and value < field.minimum:
                errors.append({
                    "field": field.name,
                    "message": f"Field '{field.name}' must be at least {field.minimum}",
                    "type": "minimum",
                })
                continue

            if field.maximum is not None and isinstance(value, (int, float)) and value > field.maximum:
                errors.append({
                    "field": field.name,
                    "message": f"Field '{field.name}' must be at most {field.maximum}",
                    "type": "maximum",
                })
                continue

            if field.choices is not None and value not in field.choices:
                errors.append({
                    "field": field.name,
                    "message": f"Field '{field.name}' must be one of {field.choices}",
                    "type": "choices",
                })
                continue

            result[field.name] = value

        if errors:
            raise FieldValidationError(
                f"Validation failed for {len(errors)} field(s)",
                errors=errors,
            )

        return result

    def _coerce_type(self, value: Any, field: Field) -> Any:
        if field.type == FieldType.INTEGER:
            return int(value)
        elif field.type == FieldType.FLOAT:
            return float(value)
        elif field.type == FieldType.BOOLEAN:
            if isinstance(value, str):
                return value.lower() in ("true", "1", "yes")
            return bool(value)
        return value


class RequestValidator:

    def __init__(self):
        self._validators: Dict[str, Validator] = {}

    def add_validator(self, name: str, validator: Validator):
        self._validators[name] = validator

    def validate(self, name: str, data: Dict[str, Any]) -> Dict[str, Any]:
        if name not in self._validators:
            raise FieldValidationError(f"No validator registered for '{name}'")
        return self._validators[name].validate(data)

    def register(self, name: str, fields: List[Field]):
        validator = Validator(fields)
        self._validators[name] = validator
        return validator


def validate_request(**rules):
    """
    Request validation decorator.

    Usage:
        @validate_request(json=[Field("name", FieldType.STRING, required=True)])
        async def handler(request, validated_data):
            name = validated_data['json']['name']
    """
    validators = {}
    for source, fields in rules.items():
        if isinstance(fields, list):
            validators[source] = Validator(fields)
        elif isinstance(fields, Validator):
            validators[source] = fields

    def decorator(func):
        async def wrapper(request, *args, **kwargs):
            validated_data = {}
            errors = []

            for source, validator in validators.items():
                if source == 'json':
                    from kewe.request.request import _AwaitableProperty
                    raw_json = request.json if hasattr(request, 'json') else None
                    if isinstance(raw_json, _AwaitableProperty):
                        raw_json = await request.json
                    data = raw_json if raw_json else {}
                elif source == 'query':
                    data = dict(request.query_params) if hasattr(request, 'query_params') else {}
                elif source == 'form':
                    from kewe.request.request import _AwaitableProperty
                    raw_form = request.form if hasattr(request, 'form') else None
                    if isinstance(raw_form, _AwaitableProperty):
                        raw_form = await request.form
                    data = raw_form if raw_form else {}
                else:
                    data = {}

                try:
                    validated_data[source] = validator.validate(data)
                except FieldValidationError as e:
                    errors.extend(e.errors)

            if errors:
                from kewe.errors.exceptions import UnprocessableEntity
                raise UnprocessableEntity(detail=errors)

            return await func(request, validated_data, *args, **kwargs)

        wrapper._validators = validators
        wrapper.__name__ = func.__name__
        wrapper.__doc__ = func.__doc__
        return wrapper

    return decorator


validate = validate_request


def field(name: str, type: Union[FieldType, str] = FieldType.STRING, **kwargs) -> Field:
    """Field convenience function.

    Usage:
        f = field("username", "string", min_length=4, max_length=20)
    """
    if isinstance(type, str):
        type = FieldType(type)
    return Field(name, type, **kwargs)


class _ParamDependency:
    """参数级依赖基类 - Query/Header/Cookie/Path"""

    _location: str = "query"

    def __init__(
        self,
        default: Any = inspect.Parameter.empty,
        *,
        alias: Optional[str] = None,
        title: Optional[str] = None,
        description: Optional[str] = None,
        gt: Optional[float] = None,
        ge: Optional[float] = None,
        lt: Optional[float] = None,
        le: Optional[float] = None,
        min_length: Optional[int] = None,
        max_length: Optional[int] = None,
        regex: Optional[str] = None,
        **extra,
    ):
        self.default = default
        self.alias = alias
        self.title = title
        self.description = description
        self.gt = gt
        self.ge = ge
        self.lt = lt
        self.le = le
        self.min_length = min_length
        self.max_length = max_length
        self.regex = regex
        self.extra = extra

    def _validation_loc(self, param_name: str) -> list:
        return [self._location, param_name]

    def _make_validation_error(self, msg: str, typ: str, param_name: str = None):
        from kewe.errors.exceptions import RequestValidationError
        pname = param_name or getattr(self, 'alias', None) or 'value'
        return RequestValidationError(
            errors=[{"loc": self._validation_loc(pname), "msg": msg, "type": typ}],
            message=msg
        )

    def _validate(self, value: Any, target_type: type = None) -> Any:
        if value is None and self.default is not inspect.Parameter.empty and self.default is not ...:
            return self.default
        if value is None:
            if self.default is ...:
                param_name = getattr(self, 'alias', None) or getattr(self, '_name', '') or 'unknown'
                raise self._make_validation_error(
                    f"Field '{param_name}' is required", "missing", param_name
                )
            return None
        if target_type is not None and isinstance(value, str):
            try:
                if target_type is int:
                    value = int(value)
                elif target_type is float:
                    value = float(value)
                elif target_type is bool:
                    value = value.lower() in ('true', '1', 'yes')
                else:
                    origin = getattr(target_type, '__origin__', None)
                    if origin is list:
                        value = [v.strip() for v in value.split(',')]
            except (ValueError, TypeError) as e:
                param_name = getattr(self, 'alias', None) or getattr(self, '_name', '') or 'parameter'
                target_name = getattr(target_type, '__name__', str(target_type))
                raise self._make_validation_error(
                    f"Expected {target_name}, got '{value}'", "type_error", param_name
                ) from e
        if isinstance(value, str):
            if self.min_length is not None and len(value) < self.min_length:
                raise self._make_validation_error(
                    f"Min length {self.min_length}", "min_length")
            if self.max_length is not None and len(value) > self.max_length:
                raise self._make_validation_error(
                    f"Max length {self.max_length}", "max_length")
            if self.regex:
                import re
                if not re.match(self.regex, value):
                    raise self._make_validation_error(
                        "Pattern mismatch", "pattern")
        if isinstance(value, (int, float)):
            if self.gt is not None and value <= self.gt:
                raise self._make_validation_error(f"Must be > {self.gt}", "gt")
            if self.ge is not None and value < self.ge:
                raise self._make_validation_error(f"Must be >= {self.ge}", "ge")
            if self.lt is not None and value >= self.lt:
                raise self._make_validation_error(f"Must be < {self.lt}", "lt")
            if self.le is not None and value > self.le:
                raise self._make_validation_error(f"Must be <= {self.le}", "le")
        return value


class Query(_ParamDependency):
    """查询参数依赖"""
    _location = "query"

    def extract(self, request: Any, param_name: str = '', target_type: type = None) -> Any:
        key = self.alias or param_name
        if not key:
            return None
        query_params = getattr(request, 'query_params', None) or getattr(request, 'args', None)
        if query_params and hasattr(query_params, 'get'):
            value = query_params.get(key)
            if isinstance(value, list):
                origin = getattr(target_type, '__origin__', None) if target_type is not None else None
                if origin is list:
                    return self._validate(value, target_type)
                value = value[0] if value else None
        elif hasattr(request, 'args') and request.args:
            value = request.args.get(key)
            if isinstance(value, list):
                origin = getattr(target_type, '__origin__', None) if target_type is not None else None
                if origin is list:
                    return self._validate(value, target_type)
                value = value[0] if value else None
        else:
            value = None
        return self._validate(value, target_type)


class Header(_ParamDependency):
    """请求头依赖 - 自动转换下划线为连字符, 支持alias"""
    _location = "header"

    def extract(self, request: Any, param_name: str = '', target_type: type = None) -> Any:
        key = self.alias or param_name
        if not key:
            return None
        key = key.replace('_', '-')
        value = request.headers.get(key) if hasattr(request, 'headers') else None
        if value is None:
            key_lower = key.lower()
            value = request.headers.get(key_lower) if hasattr(request, 'headers') else None
        return self._validate(value, target_type)


class CookieParam(_ParamDependency):
    """Cookie参数依赖"""
    _location = "cookie"

    def extract(self, request: Any, param_name: str = '', target_type: type = None) -> Any:
        key = self.alias or param_name
        value = request.get_cookie(key) if key and hasattr(request, 'get_cookie') else None
        return self._validate(value, target_type)


class Path(_ParamDependency):
    """路径参数依赖"""
    _location = "path"

    def extract(self, request: Any, param_name: str = '', target_type: type = None) -> Any:
        key = self.alias or param_name
        path_params = getattr(request, 'path_params', {}) or {}
        if not path_params and hasattr(request, 'ctx') and hasattr(request.ctx, 'path_params'):
            path_params = request.ctx.path_params
        value = path_params.get(key) if key else None
        return self._validate(value, target_type)


class Body(_ParamDependency):
    """请求体依赖"""
    _location = "body"

    def extract(self, request: Any, param_name: str = '', target_type: type = None) -> Any:
        json_body = getattr(request, '_json', None)
        if json_body is None:
            body = getattr(request, '_full_body', None)
            if body is None:
                body_attr = getattr(request, 'body', None)
                if isinstance(body_attr, bytes):
                    body = body_attr
            if isinstance(body, bytes):
                try:
                    json_body = _json.loads(body)
                except Exception:
                    logger.debug("Failed to decode JSON body in Body extractor", exc_info=True)
        return self._validate(json_body, target_type)

    async def extract_async(self, request: Any, param_name: str = '', target_type: type = None) -> Any:
        json_body = await request.json_async
        return self._validate(json_body, target_type)


class Form(_ParamDependency):
    """表单参数依赖"""
    _location = "form"

    def extract(self, request: Any, param_name: str = '', target_type: type = None) -> Any:
        key = self.alias or param_name
        form_data = None
        if hasattr(request, 'form'):
            form_attr = request.form
            if not isinstance(form_attr, type(None)) and hasattr(form_attr, 'get'):
                form_data = form_attr
            elif hasattr(request, '_form') and request._form is not None:
                form_data = request._form
        if not form_data:
            form_data = getattr(request, '_form_data', None)
        if not key and form_data:
            return self._validate(form_data, target_type)
        if form_data and hasattr(form_data, 'get'):
            value = form_data.get(key)
            return self._validate(value, target_type)
        return self._validate(None, target_type)

    async def extract_async(self, request: Any, param_name: str = '', target_type: type = None) -> Any:
        key = self.alias or param_name
        content_type = getattr(request, 'content_type', '') or ''
        if 'application/json' in content_type:
            from kewe.errors.exceptions import BadRequest
            raise BadRequest(
                f"Form parameter '{key or param_name}' cannot be extracted from "
                f"request with Content-Type 'application/json'. "
                f"Use Body() instead for JSON requests."
            )
        form_data = await request.form_async
        if not key:
            return self._validate(form_data, target_type)
        value = form_data.get(key) if hasattr(form_data, 'get') else None
        return self._validate(value, target_type)


class File(_ParamDependency):
    """文件上传依赖"""
    _location = "body"

    def extract(self, request: Any, param_name: str = '', target_type: type = None) -> Any:
        key = self.alias or param_name
        files_attr = getattr(request, 'files', None)
        if files_attr is None:
            return self._validate(None, target_type)
        from kewe.request.request import _AwaitableProperty
        if isinstance(files_attr, _AwaitableProperty):
            files = getattr(request, '_files', None)
            if files is None:
                return self._validate(None, target_type)
        elif callable(files_attr):
            files = files_attr()
        else:
            files = files_attr
        if not key:
            return self._validate(files, target_type)
        value = files.get(key) if hasattr(files, 'get') else None
        if isinstance(value, list) and value:
            value = value[0]
        return self._validate(value, target_type)

    async def extract_async(self, request: Any, param_name: str = '', target_type: type = None) -> Any:
        key = self.alias or param_name
        files_attr = getattr(request, 'files', None)
        if files_attr is None:
            return self._validate(None, target_type)
        if callable(files_attr):
            files = await files_attr() if asyncio.iscoroutinefunction(files_attr) else files_attr()
        else:
            files = files_attr
        if not key:
            return self._validate(files, target_type)
        value = files.get(key) if hasattr(files, 'get') else None
        if isinstance(value, list) and value:
            value = value[0]
        return self._validate(value, target_type)


class SecurityScopes:
    """当前请求所需的安全作用域

    当使用 Security(dependency, scopes=["me", "read"]) 时，
    SecurityScopes 对象会自动注入到依赖函数中名为 security_scopes 的参数。
    """

    def __init__(self, scopes: List[str] = None):
        self.scopes = scopes or []

    def __repr__(self):
        return f"SecurityScopes(scopes={self.scopes})"


class Security(Depends):
    """安全依赖 - Security

    使用示例:
        async def get_current_user(
            token: str = Security(oauth2_scheme, scopes=["me"]),
            security_scopes: SecurityScopes = None
        ):
            required_scopes = security_scopes.scopes if security_scopes else []
            ...

        @app.get("/me")
        async def me(user: User = Depends(get_current_user)):
            ...
    """

    def __init__(self, dependency: Callable = None, *, scopes: List[str] = None, use_cache: bool = True):
        super().__init__(dependency=dependency, use_cache=use_cache)
        self.scopes = scopes or []


async def get_current_user(request: Any) -> Any:
    """
    获取当前认证用户

    从请求中提取并验证当前用户，支持多种认证策略。
    优先级：
    1. request.ctx.user（由AuthManager中间件设置）
    2. AuthManager.current_user（contextvars）
    3. 手动JWT/Header解析

    使用示例:
        from kewe.application.depends import Depends, get_current_user

        @app.get("/me")
        async def me(user = Depends(get_current_user)):
            return {"username": user.username}
    """
    if hasattr(request, 'ctx') and hasattr(request.ctx, 'user'):
        user = request.ctx.user
        if user is not None:
            return user

    try:
        from kewe.security.auth import AuthManager
        auth_manager = getattr(request.app, 'auth_manager', None)
        if auth_manager is not None and hasattr(auth_manager, 'current_user'):
            user = auth_manager.current_user
            if user is not None:
                return user
    except (ImportError, Exception):
        logger.debug("Failed to get current user from auth manager", exc_info=True)

    auth_header = request.headers.get("authorization", "")
    if not auth_header:
        from kewe.errors.exceptions import Unauthorized
        raise Unauthorized("Not authenticated")

    parts = auth_header.split(" ", 1)
    if len(parts) != 2:
        from kewe.errors.exceptions import Unauthorized
        raise Unauthorized("Invalid authorization header")

    scheme, token = parts[0].lower(), parts[1]

    if scheme == "bearer":
        try:
            jwt_auth = None
            if hasattr(request, 'app') and hasattr(request.app, 'auth'):
                auth_manager = request.app.auth
                if hasattr(auth_manager, 'jwt_auth'):
                    jwt_auth = auth_manager.jwt_auth
            if jwt_auth is None:
                from kewe.security.auth import JWTAuthenticator
                secret_key = ''
                if hasattr(request, 'app') and hasattr(request.app, 'config'):
                    config_obj = request.app.config
                    if hasattr(config_obj, 'secret_key'):
                        secret_key = config_obj.secret_key
                    elif hasattr(config_obj, 'to_config'):
                        try:
                            c = config_obj.to_config()
                            secret_key = getattr(c, 'secret_key', '')
                        except Exception:
                            logger.debug("Failed to extract secret_key from config.to_config()", exc_info=True)
                if not secret_key:
                    import warnings
                    warnings.warn(
                        "No secret_key configured. A random key has been generated, but "
                        "sessions/tokens will not persist across restarts. Please set "
                        "KeweConfig.secret_key in production.",
                        RuntimeWarning,
                        stacklevel=4
                    )
                    import secrets as _secrets
                    secret_key = _secrets.token_hex(32)
                jwt_auth = JWTAuthenticator(secret_key=secret_key)
            payload = jwt_auth._decode_token(token)
            if isinstance(payload, dict):
                user_id = payload.get("sub")
                if user_id is not None:
                    try:
                        auth_manager = getattr(request.app, 'auth_manager', None)
                        if auth_manager and hasattr(auth_manager, 'user_store'):
                            user = await auth_manager.user_store.get_user_by_id(user_id)
                            if user:
                                return user
                    except Exception:
                        logger.debug("Failed to lookup user from auth_manager.user_store", exc_info=True)
                from kewe.security.auth import User
                return User(
                    id=user_id or "",
                    username=payload.get("username", payload.get("sub", "")),
                    roles=payload.get("roles", []),
                    is_active=payload.get("is_active", True),
                )
        except (ImportError, Exception):
            logger.debug("Failed to decode Bearer token", exc_info=True)

    elif scheme == "basic":
        try:
            import base64
            decoded = base64.b64decode(token).decode('utf-8')
            if ':' in decoded:
                username, password = decoded.split(':', 1)
                verify_fn = getattr(request.app, 'verify_basic_auth', None) if hasattr(request, 'app') else None
                if verify_fn:
                    user = await verify_fn(username, password) if asyncio.iscoroutinefunction(verify_fn) else verify_fn(username, password)
                    if user:
                        return user
                    from kewe.errors.exceptions import Unauthorized
                    raise Unauthorized("Invalid credentials")
                from kewe.security.auth import User
                return User(
                    id=username,
                    username=username,
                )
        except (ImportError, Exception):
            logger.debug("Failed to decode Basic auth token", exc_info=True)

    from kewe.errors.exceptions import Unauthorized
    raise Unauthorized("Could not validate credentials")


async def get_current_active_user(request: Any) -> Any:
    """
    获取当前活跃用户 - 确保用户是活跃状态

    使用示例:
        from kewe.application.depends import Depends, get_current_active_user

        @app.get("/me")
        async def me(user = Depends(get_current_active_user)):
            return {"username": user.username}
    """
    user = await get_current_user(request)
    if hasattr(user, 'is_active') and not user.is_active:
        from kewe.errors.exceptions import Forbidden
        raise Forbidden("Inactive user")
    return user


def require_roles(*roles: str) -> Depends:
    """
    角色验证依赖工厂

    使用示例:
        from kewe.application.depends import require_roles

        @app.get("/admin", dependencies=[Depends(require_roles("admin"))])
        async def admin_panel():
            return {"message": "Admin panel"}

        @app.delete("/users/<user_id>")
        async def delete_user(user_id: int, user = Depends(require_roles("admin", "manager"))):
            ...
    """
    async def _check_roles(request: Any) -> Any:
        user = await get_current_user(request)
        user_roles = set(getattr(user, 'roles', []))
        required_roles = set(roles)
        if not required_roles.issubset(user_roles):
            from kewe.errors.exceptions import Forbidden
            missing = required_roles - user_roles
            raise Forbidden(f"Missing required roles: {', '.join(missing)}")
        return user

    return Depends(_check_roles)


def require_permissions(*permissions: str) -> Depends:
    """
    权限验证依赖工厂

    使用示例:
        from kewe.application.depends import require_permissions

        @app.delete("/users/<user_id>", dependencies=[Depends(require_permissions("user:delete"))])
        async def delete_user(user_id: int):
            ...
    """
    async def _check_permissions(request: Any) -> Any:
        user = await get_current_user(request)
        user_perms = set(getattr(user, 'permissions', []))
        required_perms = set(permissions)
        if not required_perms.issubset(user_perms):
            from kewe.errors.exceptions import Forbidden
            missing = required_perms - user_perms
            raise Forbidden(f"Missing required permissions: {', '.join(missing)}")
        return user

    return Depends(_check_permissions)
