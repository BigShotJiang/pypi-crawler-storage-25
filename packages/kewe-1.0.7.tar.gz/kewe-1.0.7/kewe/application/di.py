#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.application.di - Dependency injection container with lifetime management
"""

import logging
from typing import Any, Callable, Dict, Optional, Type, TypeVar, get_type_hints
from functools import wraps
from enum import Enum
import asyncio
import inspect
import threading
import contextvars

T = TypeVar('T')
logger = logging.getLogger(__name__)

_SCOPED_SENTINEL = object()


class Lifetime(Enum):
    """依赖生命周期"""
    SINGLETON = "singleton"      # 单例 - 全局只有一个实例
    TRANSIENT = "transient"      # 瞬态 - 每次请求新实例
    SCOPED = "scoped"            # 作用域 - 每个请求作用域一个实例


class Container:
    
    def __init__(self):
        self._registrations: Dict[Type, Dict[str, Any]] = {}
        self._singletons: Dict[Type, Any] = {}
        self._scoped_instances: Dict[int, Dict[Type, Any]] = {}
        self._sync_lock = threading.RLock()
        self._async_lock: Optional[asyncio.Lock] = None
        self._scope_lock = threading.Lock()
        self._current_scope_id = contextvars.ContextVar('di_scope_id', default=None)
        self._resolving_stack = contextvars.ContextVar('di_resolving', default=None)
    
    def _get_async_lock(self) -> asyncio.Lock:
        with self._sync_lock:
            if self._async_lock is None:
                self._async_lock = asyncio.Lock()
            return self._async_lock
    
    def register(
        self,
        interface: Type[T],
        implementation: Optional[Type[T]] = None,
        factory: Optional[Callable[..., T]] = None,
        instance: Optional[T] = None,
        lifetime: Lifetime = Lifetime.TRANSIENT
    ) -> 'Container':
        with self._sync_lock:
            self._registrations[interface] = {
                'implementation': implementation or interface,
                'factory': factory,
                'instance': instance,
                'lifetime': lifetime
            }
            
            if lifetime == Lifetime.SINGLETON and instance is not None:
                self._singletons[interface] = instance
                
        return self
    
    def register_instance(self, interface: Type[T], instance: T) -> 'Container':
        """注册单例实例"""
        return self.register(interface, instance=instance, lifetime=Lifetime.SINGLETON)
    
    def register_factory(
        self,
        interface: Type[T],
        factory: Callable[..., T],
        lifetime: Lifetime = Lifetime.TRANSIENT
    ) -> 'Container':
        """注册工厂函数"""
        return self.register(interface, factory=factory, lifetime=lifetime)
    
    def register_singleton(self, interface: Type[T], implementation: Optional[Type[T]] = None) -> 'Container':
        """注册单例"""
        return self.register(interface, implementation=implementation, lifetime=Lifetime.SINGLETON)
    
    def register_transient(self, interface: Type[T], implementation: Optional[Type[T]] = None) -> 'Container':
        """注册瞬态依赖"""
        return self.register(interface, implementation=implementation, lifetime=Lifetime.TRANSIENT)
    
    def register_scoped(self, interface: Type[T], implementation: Optional[Type[T]] = None) -> 'Container':
        """注册作用域依赖"""
        return self.register(interface, implementation=implementation, lifetime=Lifetime.SCOPED)
    
    def override(self, interface: Type[T], factory_or_instance: Any) -> None:
        """覆盖依赖注册（测试时替换依赖）

        Args:
            interface: 要覆盖的接口类型
            factory_or_instance: 替换的工厂函数或实例
        """
        if not hasattr(self, '_overrides'):
            self._overrides = {}
        if callable(factory_or_instance) and not isinstance(factory_or_instance, type):
            self._overrides[interface] = {'factory': factory_or_instance, 'lifetime': Lifetime.TRANSIENT}
        else:
            self._overrides[interface] = {'instance': factory_or_instance, 'lifetime': Lifetime.SINGLETON}
    
    def reset_overrides(self) -> None:
        """清除所有覆盖注册"""
        if hasattr(self, '_overrides'):
            self._overrides.clear()
    
    def unregister(self, interface: Type) -> None:
        """从容器移除注册"""
        with self._sync_lock:
            self._registrations.pop(interface, None)
            self._singletons.pop(interface, None)
    
    def __contains__(self, interface: Type) -> bool:
        return interface in self._registrations
    
    def resolve(self, interface: Type[T]) -> T:
        if hasattr(self, '_overrides') and interface in self._overrides:
            reg = self._overrides[interface]
            if 'instance' in reg:
                return reg['instance']
            if 'factory' in reg:
                return reg['factory']()

        reg = self._registrations.get(interface)
        if reg is None:
            raise KeyError(f"Dependency '{interface.__name__ if hasattr(interface, '__name__') else interface}' is not registered in the container")

        if reg['lifetime'] == Lifetime.SINGLETON:
            instance = self._singletons.get(interface)
            if instance is not None:
                return instance
            with self._sync_lock:
                instance = self._singletons.get(interface)
                if instance is not None:
                    return instance
                instance = self._create_instance(reg)
                self._singletons[interface] = instance
                return instance

        with self._sync_lock:
            return self._resolve_internal(interface)
    
    async def aresolve(self, interface: Type[T]) -> T:
        return await self._aresolve_internal(interface)
    
    async def _aresolve_internal(self, interface: Type[T]) -> T:
        if interface not in self._registrations:
            raise KeyError(f"Dependency '{interface.__name__ if hasattr(interface, '__name__') else interface}' is not registered in the container")
        
        resolving = self._resolving_stack.get()
        if resolving is None:
            resolving = set()
            self._resolving_stack.set(resolving)
        if interface in resolving:
            raise RuntimeError(f"Circular dependency detected: '{interface.__name__ if hasattr(interface, '__name__') else interface}' is already being resolved")
        resolving.add(interface)
        try:
            reg = self._registrations[interface]
            lifetime = reg['lifetime']
            
            if lifetime == Lifetime.SINGLETON:
                if interface in self._singletons:
                    return self._singletons[interface]
                async with self._get_async_lock():
                    if interface in self._singletons:
                        return self._singletons[interface]
                    instance = await self._acreate_instance(reg)
                    self._singletons[interface] = instance
                return instance
            
            elif lifetime == Lifetime.SCOPED:
                scope_id = self._current_scope_id.get()
                if scope_id is None:
                    raise RuntimeError("Cannot resolve scoped dependency outside of a scope")
                
                for _ in range(100):
                    with self._scope_lock:
                        if scope_id not in self._scoped_instances:
                            self._scoped_instances[scope_id] = {}
                        if interface in self._scoped_instances[scope_id]:
                            existing = self._scoped_instances[scope_id][interface]
                            if existing is not _SCOPED_SENTINEL:
                                return existing
                        else:
                            self._scoped_instances[scope_id][interface] = _SCOPED_SENTINEL
                            break
                    await asyncio.sleep(0.001)
                else:
                    with self._scope_lock:
                        self._scoped_instances[scope_id][interface] = _SCOPED_SENTINEL
                
                try:
                    instance = await self._acreate_instance(reg)
                except Exception:
                    with self._scope_lock:
                        if scope_id in self._scoped_instances and self._scoped_instances[scope_id].get(interface) is _SCOPED_SENTINEL:
                            del self._scoped_instances[scope_id][interface]
                    raise
                
                with self._scope_lock:
                    self._scoped_instances[scope_id][interface] = instance
                return instance
            
            else:
                return await self._acreate_instance(reg)
        finally:
            resolving.discard(interface)
    
    async def _acreate_instance(self, reg: Dict[str, Any]) -> Any:
        if reg.get('factory'):
            result = await self._ainvoke_with_injection(reg['factory'])
            if asyncio.iscoroutine(result):
                return await result
            return result
        
        if reg.get('instance'):
            return reg['instance']
        
        implementation = reg['implementation']
        return await self._acreate_instance_with_injection(implementation)
    
    def _resolve_internal(self, interface: Type[T]) -> T:
        if interface not in self._registrations:
            raise KeyError(f"Dependency '{interface.__name__ if hasattr(interface, '__name__') else interface}' is not registered in the container")
        
        resolving = self._resolving_stack.get()
        if resolving is None:
            resolving = set()
            self._resolving_stack.set(resolving)
        if interface in resolving:
            raise RuntimeError(f"Circular dependency detected: '{interface.__name__ if hasattr(interface, '__name__') else interface}' is already being resolved")
        
        resolving.add(interface)
        try:
            reg = self._registrations[interface]
            lifetime = reg['lifetime']
            
            if lifetime == Lifetime.SINGLETON:
                if interface in self._singletons:
                    return self._singletons[interface]
                
                instance = self._create_instance(reg)
                self._singletons[interface] = instance
                return instance
            
            if lifetime == Lifetime.SCOPED:
                scope_id = self._current_scope_id.get()
                if scope_id is None:
                    raise RuntimeError("Cannot resolve scoped dependency outside of a scope")
                
                with self._scope_lock:
                    if scope_id not in self._scoped_instances:
                        self._scoped_instances[scope_id] = {}
                    
                    if interface in self._scoped_instances[scope_id]:
                        return self._scoped_instances[scope_id][interface]
                    
                    instance = self._create_instance(reg)
                    self._scoped_instances[scope_id][interface] = instance
                    return instance
            
            return self._create_instance(reg)
        finally:
            resolving.discard(interface)
    
    def _create_instance(self, reg: Dict[str, Any]) -> Any:
        """创建实例"""
        # 如果有工厂函数，使用工厂函数
        if reg.get('factory'):
            return self._invoke_with_injection(reg['factory'])
        
        # 如果有实例，直接返回
        if reg.get('instance'):
            return reg['instance']
        
        # 使用实现类型创建实例
        implementation = reg['implementation']
        return self._create_instance_with_injection(implementation)
    
    def _create_instance_with_injection(self, cls: Type[T]) -> T:
        """使用依赖注入创建类实例"""
        try:
            sig = inspect.signature(cls.__init__)
            params = list(sig.parameters.items())[1:]
        except (ValueError, TypeError):
            return cls()
        
        try:
            type_hints = get_type_hints(cls.__init__)
        except (NameError, TypeError):
            type_hints = {}
        
        kwargs = {}
        for name, param in params:
            if param.default is not inspect.Parameter.empty:
                continue
            
            if param.kind in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD):
                continue
            
            param_type = type_hints.get(name)
            if param_type is None:
                continue
            
            if not self.can_resolve(param_type):
                continue
            
            kwargs[name] = self.resolve(param_type)
        
        return cls(**kwargs)
    
    def _invoke_with_injection(self, func: Callable) -> Any:
        """使用依赖注入调用函数"""
        sig = inspect.signature(func)
        params = list(sig.parameters.items())
        
        try:
            type_hints = get_type_hints(func)
        except (NameError, TypeError):
            type_hints = {}
        
        kwargs = {}
        for name, param in params:
            if param.default is not inspect.Parameter.empty:
                continue
            
            if param.kind in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD):
                continue
            
            param_type = type_hints.get(name)
            if param_type is None:
                continue
            
            if not self.can_resolve(param_type):
                continue
            
            kwargs[name] = self.resolve(param_type)
        
        return func(**kwargs)
    
    async def _ainvoke_with_injection(self, func: Callable) -> Any:
        sig = inspect.signature(func)
        params = list(sig.parameters.items())
        
        try:
            type_hints = get_type_hints(func)
        except (NameError, TypeError):
            type_hints = {}
        
        kwargs = {}
        for name, param in params:
            if param.default is not inspect.Parameter.empty:
                continue
            if param.kind in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD):
                continue
            param_type = type_hints.get(name)
            if param_type is None:
                continue
            if not self.can_resolve(param_type):
                continue
            kwargs[name] = await self.aresolve(param_type)
        
        return func(**kwargs)
    
    async def _acreate_instance_with_injection(self, cls: Type[T]) -> T:
        try:
            sig = inspect.signature(cls.__init__)
            params = list(sig.parameters.items())[1:]
        except (ValueError, TypeError):
            return cls()
        
        try:
            type_hints = get_type_hints(cls.__init__)
        except (NameError, TypeError):
            type_hints = {}
        
        kwargs = {}
        for name, param in params:
            if param.default is not inspect.Parameter.empty:
                continue
            if param.kind in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD):
                continue
            param_type = type_hints.get(name)
            if param_type is None:
                continue
            if not self.can_resolve(param_type):
                continue
            kwargs[name] = await self.aresolve(param_type)
        
        return cls(**kwargs)
    
    def scope(self, scope_id: Optional[int] = None):
        """
        创建作用域上下文管理器
        
        Args:
            scope_id: 作用域ID，如果不提供则自动生成
        """
        return Scope(self, scope_id)
    
    def set_scope(self, scope_id: int):
        self._current_scope_id.set(scope_id)
    
    def register_scoped_instance(self, interface: Type, instance: Any):
        scope_id = self._current_scope_id.get()
        if scope_id is not None:
            with self._scope_lock:
                if scope_id not in self._scoped_instances:
                    self._scoped_instances[scope_id] = {}
                self._scoped_instances[scope_id][interface] = instance
    
    def clear_scope(self, scope_id: int):
        with self._scope_lock:
            if scope_id in self._scoped_instances:
                instances = self._scoped_instances.pop(scope_id)
                for instance in instances.values():
                    for method_name in ('close', 'dispose', 'shutdown', 'cleanup', 'aclose'):
                        if hasattr(instance, method_name):
                            try:
                                result = getattr(instance, method_name)()
                                if asyncio.iscoroutine(result):
                                    try:
                                        loop = asyncio.get_event_loop()
                                        if loop.is_running():
                                            loop.create_task(self._schedule_async_cleanup(result, method_name))
                                        else:
                                            logger.warning(
                                                f"Async cleanup method '{method_name}' called in sync context "
                                                f"without running event loop. Resource may leak."
                                            )
                                    except RuntimeError:
                                        logger.warning(
                                            f"Async cleanup method '{method_name}' called in sync context. "
                                            f"Use 'async with container.scope()' instead."
                                        )
                            except Exception as e:
                                logger.warning(f"Error disposing scoped instance: {e}")

    @staticmethod
    async def _schedule_async_cleanup(coro, method_name: str):
        try:
            await coro
        except Exception as e:
            logger.warning(f"Async cleanup method '{method_name}' failed: {e}")
        
        if self._current_scope_id.get() == scope_id:
            self._current_scope_id.set(None)
    
    async def aclear_scope(self, scope_id: int):
        with self._scope_lock:
            if scope_id in self._scoped_instances:
                instances = self._scoped_instances.pop(scope_id)
            else:
                instances = {}
        
        if self._current_scope_id.get() == scope_id:
            self._current_scope_id.set(None)
        
        for instance in instances.values():
            if hasattr(instance, '__aexit__'):
                try:
                    await instance.__aexit__(None, None, None)
                except Exception as e:
                    logger.warning(f"Error calling __aexit__ on scoped instance: {e}")
                continue
            for method_name in ('aclose', 'close', 'dispose', 'shutdown', 'cleanup'):
                if hasattr(instance, method_name):
                    try:
                        result = getattr(instance, method_name)()
                        if asyncio.iscoroutine(result):
                            await result
                    except Exception as e:
                        logger.warning(f"Error disposing scoped instance: {e}")
    
    def can_resolve(self, interface: Type) -> bool:
        """检查是否可以解析指定类型"""
        return interface in self._registrations
    
    def build_provider(self) -> 'ServiceProvider':
        """构建服务提供者"""
        return ServiceProvider(self)


class Scope:
    
    _counter = 0
    _lock = threading.Lock()
    
    def __init__(self, container: Container, scope_id: Optional[int] = None):
        self.container = container
        
        if scope_id is None:
            with self._lock:
                Scope._counter += 1
                scope_id = Scope._counter
        
        self.scope_id = scope_id
    
    def __enter__(self):
        self.container.set_scope(self.scope_id)
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.container.clear_scope(self.scope_id)
    
    async def __aenter__(self):
        self.container.set_scope(self.scope_id)
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.container.aclear_scope(self.scope_id)


class ServiceProvider:
    """
    服务提供者
    用于在请求处理中解析依赖
    """
    
    def __init__(self, container: Container):
        self.container = container
    
    def get_service(self, interface: Type[T]) -> T:
        """获取服务"""
        return self.container.resolve(interface)
    
    def create_scope(self) -> Scope:
        """创建新作用域"""
        return self.container.scope()


class Inject:
    """
    依赖注入装饰器
    用于标记需要注入的参数
    """
    
    def __init__(self, interface: Optional[Type] = None):
        self.interface = interface


def inject(func: Callable) -> Callable:
    """
    依赖注入装饰器
    自动注入函数参数
    """
    @wraps(func)
    async def async_wrapper(*args, **kwargs):
        # 从app获取容器
        from .app import Kewe
        app = Kewe.get_current()
        if app and hasattr(app, 'container'):
            container = app.container
            
            # 获取函数签名
            sig = inspect.signature(func)
            params = list(sig.parameters.items())
            
            # 获取类型提示
            try:
                type_hints = get_type_hints(func)
            except (NameError, TypeError):
                type_hints = {}
            
            # 注入依赖
            for name, param in params[len(args):]:
                if name in kwargs:
                    continue
                
                param_type = type_hints.get(name)
                if param_type and container.can_resolve(param_type):
                    kwargs[name] = await container.aresolve(param_type)
        
        return await func(*args, **kwargs)
    
    @wraps(func)
    def sync_wrapper(*args, **kwargs):
        from .app import Kewe
        app = Kewe.get_current()
        if app and hasattr(app, 'container'):
            container = app.container
            
            sig = inspect.signature(func)
            params = list(sig.parameters.items())
            
            try:
                type_hints = get_type_hints(func)
            except (NameError, TypeError):
                type_hints = {}
            
            for name, param in params[len(args):]:
                if name in kwargs:
                    continue
                
                param_type = type_hints.get(name)
                if param_type and container.can_resolve(param_type):
                    kwargs[name] = container.resolve(param_type)
        
        return func(*args, **kwargs)
    
    if inspect.iscoroutinefunction(func):
        return async_wrapper
    return sync_wrapper


# 全局容器实例
_default_container: Optional[Container] = None


def get_container() -> Container:
    """获取默认容器"""
    global _default_container
    if _default_container is None:
        _default_container = Container()
    return _default_container


def set_container(container: Container):
    """设置默认容器"""
    global _default_container
    _default_container = container


# 便捷函数
def register(
    interface: Type[T],
    implementation: Optional[Type[T]] = None,
    factory: Optional[Callable[..., T]] = None,
    instance: Optional[T] = None,
    lifetime: Lifetime = Lifetime.TRANSIENT
) -> Container:
    """在默认容器中注册依赖"""
    return get_container().register(interface, implementation, factory, instance, lifetime)


def register_singleton(interface: Type[T], implementation: Optional[Type[T]] = None) -> Container:
    """在默认容器中注册单例"""
    return get_container().register_singleton(interface, implementation)


def register_transient(interface: Type[T], implementation: Optional[Type[T]] = None) -> Container:
    """在默认容器中注册瞬态依赖"""
    return get_container().register_transient(interface, implementation)


def register_scoped(interface: Type[T], implementation: Optional[Type[T]] = None) -> Container:
    """在默认容器中注册作用域依赖"""
    return get_container().register_scoped(interface, implementation)


def resolve(interface: Type[T]) -> T:
    """从默认容器解析依赖"""
    return get_container().resolve(interface)


def scope(scope_id: Optional[int] = None):
    """创建作用域"""
    return get_container().scope(scope_id)
