#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.application.state_store - Application-level state storage with thread-safe access
"""

import logging
import asyncio
from kewe.utils.compat import json
from typing import Any, Dict, Optional, Callable
from dataclasses import dataclass, field
from threading import RLock
from contextlib import contextmanager

logger = logging.getLogger(__name__)


class StateStore:
    """
    应用状态管理器
    
    用于存储和共享应用级别的状态数据
    线程安全，支持上下文管理器
    
    使用示例:
        app.state.users = []
        app.state.config = {"debug": True}
        
        # 动态属性
        app.state.set("db_connection", conn)
        conn = app.state.get("db_connection")
        
        # 上下文管理器
        with app.state.temp("request_id", "123"):
            print(app.state.request_id)  # "123"
        # 上下文结束后自动清理
    """
    
    def __init__(self):
        self._data: Dict[str, Any] = {}
        self._lock = RLock()
        self._listeners: Dict[str, list] = {}
    
    def __getattr__(self, name: str) -> Any:
        if name.startswith('_'):
            return super().__getattribute__(name)
        
        with self._lock:
            if name in self._data:
                return self._data[name]
            raise AttributeError(f"State has no attribute '{name}'")
    
    def __setattr__(self, name: str, value: Any) -> None:
        if name.startswith('_'):
            super().__setattr__(name, value)
            return
        
        with self._lock:
            old_value = self._data.get(name)
            self._data[name] = value
            listeners = list(self._listeners.get(name, [])) if hasattr(self, '_listeners') and name in self._listeners else []
        
        for callback in listeners:
            try:
                callback(name, old_value, value)
            except Exception as e:
                logger.error(f"State change listener error: {e}")
    
    def __delattr__(self, name: str) -> None:
        if name.startswith('_'):
            super().__delattr__(name)
            return
        
        with self._lock:
            if name in self._data:
                old_value = self._data.pop(name)
                listeners = list(self._listeners.get(name, [])) if hasattr(self, '_listeners') and name in self._listeners else []
            else:
                raise AttributeError(f"State has no attribute '{name}'")
        
        for callback in listeners:
            try:
                callback(name, old_value, None)
            except Exception as e:
                logger.error(f"State change listener error: {e}")
    
    def __contains__(self, name: str) -> bool:
        with self._lock:
            return name in self._data
    
    def __iter__(self):
        with self._lock:
            return iter(self._data.items())
    
    def __len__(self) -> int:
        with self._lock:
            return len(self._data)
    
    def __repr__(self) -> str:
        with self._lock:
            return f"StateStore({self._data})"
    
    def get(self, name: str, default: Any = None) -> Any:
        """
        获取状态值
        
        Args:
            name: 状态名称
            default: 默认值
            
        Returns:
            状态值或默认值
        """
        with self._lock:
            return self._data.get(name, default)
    
    def set(self, name: str, value: Any) -> None:
        with self._lock:
            old_value = self._data.get(name)
            self._data[name] = value
            listeners = list(self._listeners.get(name, []))
        for callback in listeners:
            try:
                callback(name, old_value, value)
            except Exception as e:
                logger.error(f"State change listener error: {e}")
    
    def delete(self, name: str) -> bool:
        with self._lock:
            if name in self._data:
                old_value = self._data.pop(name)
                listeners = list(self._listeners.get(name, []))
            else:
                return False
        for callback in listeners:
            try:
                callback(name, old_value, None)
            except Exception as e:
                logger.error(f"State change listener error: {e}")
        return True
    
    def update(self, data: Dict[str, Any]) -> None:
        """
        批量更新状态
        
        Args:
            data: 状态字典
        """
        with self._lock:
            for name, value in data.items():
                old_value = self._data.get(name)
                self._data[name] = value
                self._notify_change(name, old_value, value)
    
    def clear(self) -> None:
        """清除所有状态"""
        with self._lock:
            for name in list(self._data.keys()):
                old_value = self._data.pop(name)
                self._notify_change(name, old_value, None)
    
    def keys(self):
        """获取所有状态名称"""
        with self._lock:
            return self._data.keys()
    
    def values(self):
        """获取所有状态值"""
        with self._lock:
            return self._data.values()
    
    def items(self):
        """获取所有状态项"""
        with self._lock:
            return self._data.items()
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        with self._lock:
            return self._data.copy()
    
    def from_dict(self, data: Dict[str, Any]) -> None:
        """从字典加载"""
        self.update(data)
    
    @contextmanager
    def temp(self, name: str, value: Any):
        """
        临时状态上下文管理器
        
        Args:
            name: 状态名称
            value: 临时值
            
        使用示例:
            with app.state.temp("request_id", "123"):
                print(app.state.request_id)
        """
        old_value = self.get(name)
        existed = name in self
        
        try:
            self.set(name, value)
            yield
        finally:
            if existed:
                self.set(name, old_value)
            else:
                self.delete(name)
    
    def on_change(self, name: str, callback: Callable[[str, Any, Any], None]) -> None:
        """
        注册状态变更监听器
        
        Args:
            name: 状态名称
            callback: 回调函数 (name, old_value, new_value)
        """
        with self._lock:
            if name not in self._listeners:
                self._listeners[name] = []
            self._listeners[name].append(callback)
    
    def off_change(self, name: str, callback: Callable) -> bool:
        """
        移除状态变更监听器
        
        Args:
            name: 状态名称
            callback: 回调函数
            
        Returns:
            是否成功移除
        """
        with self._lock:
            if name in self._listeners and callback in self._listeners[name]:
                self._listeners[name].remove(callback)
                return True
            return False
    
    def _notify_change(self, name: str, old_value: Any, new_value: Any) -> None:
        """通知状态变更"""
        if name in self._listeners:
            for callback in self._listeners[name]:
                try:
                    callback(name, old_value, new_value)
                except Exception as e:
                    logger.error(f"State change listener error: {e}")


class StateRequestContext:
    """
    请求上下文状态
    
    每个请求独立的上下文状态存储
    """
    
    def __init__(self):
        self._data: Dict[str, Any] = {}
    
    def __getattr__(self, name: str) -> Any:
        if name.startswith('_'):
            return super().__getattribute__(name)
        
        if name in self._data:
            return self._data[name]
        raise AttributeError(f"Context has no attribute '{name}'")
    
    def __setattr__(self, name: str, value: Any) -> None:
        if name.startswith('_'):
            super().__setattr__(name, value)
            return
        self._data[name] = value
    
    def __delattr__(self, name: str) -> None:
        if name.startswith('_'):
            super().__delattr__(name)
            return
        if name in self._data:
            del self._data[name]
        else:
            raise AttributeError(f"Context has no attribute '{name}'")
    
    def get(self, name: str, default: Any = None) -> Any:
        """获取上下文值"""
        return self._data.get(name, default)
    
    def set(self, name: str, value: Any) -> None:
        """设置上下文值"""
        self._data[name] = value
    
    def delete(self, name: str) -> bool:
        """删除上下文值"""
        if name in self._data:
            del self._data[name]
            return True
        return False
    
    def clear(self) -> None:
        """清除所有上下文"""
        self._data.clear()
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return self._data.copy()


class SharedState:
    """
    共享状态管理器
    
    用于多进程/多worker之间的状态共享（需要外部存储支持）
    """
    
    def __init__(self, backend: str = "memory", **kwargs):
        """
        初始化共享状态
        
        Args:
            backend: 后端类型 (memory, redis, etc.)
            **kwargs: 后端配置参数
        """
        self.backend = backend
        self._config = kwargs
        self._client = None
        
        if backend == "redis":
            self._init_redis(**kwargs)
        else:
            self._data: Dict[str, Any] = {}
    
    def _init_redis(self, url: str = None, **kwargs):
        """初始化 Redis 后端"""
        try:
            import redis
            self._client = redis.from_url(url or "redis://localhost:6379/0", **kwargs)
        except ImportError:
            logger.warning("redis not installed, falling back to memory backend")
            self.backend = "memory"
            self._data = {}
    
    async def get(self, name: str, default: Any = None) -> Any:
        if self.backend == "redis":
            loop = asyncio.get_running_loop()
            value = await loop.run_in_executor(None, self._client.get, name)
            if value is not None:
                return json.loads(value)
            return default
        else:
            return self._data.get(name, default)
    
    async def set(self, name: str, value: Any, expire: int = None) -> None:
        if self.backend == "redis":
            serialized = json.dumps(value)
            loop = asyncio.get_running_loop()
            if expire:
                await loop.run_in_executor(None, lambda: self._client.setex(name, expire, serialized))
            else:
                await loop.run_in_executor(None, self._client.set, name, serialized)
        else:
            self._data[name] = value
    
    async def delete(self, name: str) -> bool:
        if self.backend == "redis":
            loop = asyncio.get_running_loop()
            result = await loop.run_in_executor(None, self._client.delete, name)
            return result > 0
        else:
            if name in self._data:
                del self._data[name]
                return True
            return False
    
    async def incr(self, name: str, amount: int = 1) -> int:
        if self.backend == "redis":
            loop = asyncio.get_running_loop()
            return await loop.run_in_executor(None, lambda: self._client.incrby(name, amount))
        else:
            self._data[name] = self._data.get(name, 0) + amount
            return self._data[name]


AppState = StateStore

__all__ = [
    'StateStore',
    'AppState',
    'StateRequestContext',
    'SharedState',
]
