#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.touchup.optimizer - Performance optimizer for automatic tuning
"""

import logging
import functools
from typing import Dict, List, Callable, Any, Optional
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class OptimizationResult:
    """优化结果"""
    name: str
    success: bool
    message: str
    duration_ms: float


class TouchupOptimizer:
    """
    Touchup优化器
    
    在应用启动时执行各种优化，提高运行时性能
    
    使用示例:
        optimizer = TouchupOptimizer()
        
        @optimizer.register('compile_regex')
        def compile_regex_patterns(app):
            # 预编译所有正则表达式
            pass
        
        # 运行所有优化
        results = optimizer.run_all(app)
    """
    
    def __init__(self):
        self._optimizations: Dict[str, Callable] = {}
        self._enabled: Dict[str, bool] = {}
        self._results: List[OptimizationResult] = []
    
    def register(
        self,
        name: str,
        enabled: bool = True
    ) -> Callable:
        """
        注册优化函数
        
        Args:
            name: 优化名称
            enabled: 是否启用
            
        Returns:
            装饰器函数
        """
        def decorator(func: Callable):
            self._optimizations[name] = func
            self._enabled[name] = enabled
            return func
        return decorator
    
    def enable(self, name: str):
        """启用优化"""
        if name in self._enabled:
            self._enabled[name] = True
            logger.debug(f"Enabled optimization: {name}")
    
    def disable(self, name: str):
        """禁用优化"""
        if name in self._enabled:
            self._enabled[name] = False
            logger.debug(f"Disabled optimization: {name}")
    
    def run(self, name: str, app: Any) -> Optional[OptimizationResult]:
        """
        运行单个优化
        
        Args:
            name: 优化名称
            app: Kewe应用实例
            
        Returns:
            优化结果
        """
        if name not in self._optimizations:
            logger.warning(f"Optimization not found: {name}")
            return None
        
        if not self._enabled.get(name, True):
            logger.debug(f"Optimization disabled: {name}")
            return None
        
        import time
        func = self._optimizations[name]
        
        start = time.time()
        try:
            result = func(app)
            duration = (time.time() - start) * 1000
            
            opt_result = OptimizationResult(
                name=name,
                success=True,
                message=str(result) if result else "OK",
                duration_ms=duration
            )
            
            logger.info(f"Optimization '{name}' completed in {duration:.2f}ms")
            
        except Exception as e:
            duration = (time.time() - start) * 1000
            opt_result = OptimizationResult(
                name=name,
                success=False,
                message=str(e),
                duration_ms=duration
            )
            logger.error(f"Optimization '{name}' failed: {e}")
        
        self._results.append(opt_result)
        return opt_result
    
    def run_all(self, app: Any) -> List[OptimizationResult]:
        """
        运行所有启用的优化
        
        Args:
            app: Kewe应用实例
            
        Returns:
            所有优化结果
        """
        self._results.clear()
        
        logger.info("Running touchup optimizations...")
        
        for name in self._optimizations:
            self.run(name, app)
        
        # 统计
        total = len(self._results)
        success = sum(1 for r in self._results if r.success)
        total_time = sum(r.duration_ms for r in self._results)
        
        logger.info(
            f"Touchup complete: {success}/{total} optimizations succeeded "
            f"in {total_time:.2f}ms"
        )
        
        return self._results.copy()
    
    def get_results(self) -> List[OptimizationResult]:
        """获取所有优化结果"""
        return self._results.copy()
    
    def clear_results(self):
        """清除优化结果"""
        self._results.clear()


# 全局优化器实例
_global_optimizer: Optional[TouchupOptimizer] = None


def get_optimizer() -> TouchupOptimizer:
    """获取全局优化器实例"""
    global _global_optimizer
    if _global_optimizer is None:
        _global_optimizer = TouchupOptimizer()
    return _global_optimizer


def touchup(name: str = None, enabled: bool = True):
    """
    Touchup装饰器
    
    使用示例:
        @touchup('my_optimization')
        def optimize_something(app):
            # 优化代码
            pass
    """
    def decorator(func: Callable):
        opt_name = name or func.__name__
        get_optimizer().register(opt_name, enabled)(func)
        return func
    return decorator


# 内置优化

@touchup('compile_route_patterns', enabled=True)
def compile_route_patterns(app):
    """验证路由正则表达式已编译（Router.add_route已编译，此处仅做校验）"""
    import re

    compiled = 0
    routes = getattr(app.router, 'routes', None) or getattr(app.router, '_routes', [])
    for route in routes:
        pattern = getattr(route, 'regex_pattern', None)
        if pattern is None:
            continue
        if isinstance(pattern, str):
            route.regex_pattern = re.compile(pattern)
            compiled += 1
        elif hasattr(pattern, 'match'):
            compiled += 1

    return f"Verified {compiled} route patterns compiled"


@touchup('optimize_middleware_chain', enabled=True)
def optimize_middleware_chain(app):
    """优化中间件调用链"""
    middleware_manager = getattr(app, 'middleware_manager', None)
    if middleware_manager is None:
        return "No middleware_manager found"

    request_mw = getattr(middleware_manager, '_request_middlewares', None)
    if request_mw is not None and hasattr(request_mw, 'sort'):
        request_mw.sort(
            key=lambda m: m.priority.value if hasattr(m, 'priority') else 0
        )

    response_mw = getattr(middleware_manager, '_response_middlewares', None)
    if response_mw is not None and hasattr(response_mw, 'sort'):
        response_mw.sort(
            key=lambda m: m.priority.value if hasattr(m, 'priority') else 0,
            reverse=True
        )

    count = len(request_mw) if request_mw else 0
    return f"Optimized {count} middlewares"


@touchup('cache_static_routes', enabled=True)
def cache_static_routes(app):
    """缓存静态路由"""
    routes = getattr(app.router, 'routes', None) or getattr(app.router, '_routes', [])
    if not routes:
        return "No routes found"

    static_routes = []
    dynamic_routes = []

    for route in routes:
        path = getattr(route, 'path', '')
        if '{' not in path:
            static_routes.append(route)
        else:
            dynamic_routes.append(route)

    if hasattr(app.router, '_routes'):
        app.router._routes = static_routes + dynamic_routes
    elif hasattr(app.router, 'routes'):
        app.router.routes = static_routes + dynamic_routes

    return f"Cached {len(static_routes)} static routes"


@touchup('prewarm_app_context', enabled=True)
def prewarm_app_context(app):
    """预热应用上下文"""
    config = getattr(app, 'config', None)
    if config is not None:
        to_dict = getattr(config, 'to_dict', None)
        if callable(to_dict):
            _ = to_dict()

    return "App context prewarmed"


@touchup('optimize_signal_handlers', enabled=True)
def optimize_signal_handlers(app):
    """优化信号处理器"""
    signals = getattr(app, 'signals', None)
    if signals is None:
        return "No signals found"

    handlers = getattr(signals, '_handlers', None)
    if handlers is None:
        return "No signal handlers found"

    for signal_type in handlers:
        handler_list = handlers[signal_type]
        if hasattr(handler_list, 'sort'):
            handler_list.sort(key=lambda h: getattr(h, '_priority', 0))

    return "Signal handlers optimized"


def run_touchup_optimizations(app) -> List[OptimizationResult]:
    """
    运行所有touchup优化的便捷函数
    
    Args:
        app: Kewe应用实例
        
    Returns:
        优化结果列表
    """
    return get_optimizer().run_all(app)


optimize_response = touchup

