#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.handlers.simple - Simple file browser and directory index handler
"""

from kewe.utils.compat import json
import mimetypes
from datetime import datetime
from pathlib import Path
from typing import Optional, List, Dict, Any
import logging

logger = logging.getLogger(__name__)


class FileBrowser:

    def __init__(
        self,
        root_path: str,
        show_hidden: bool = False,
        sort_by: str = 'name',
        sort_order: str = 'asc'
    ):
        self.root_path = Path(root_path).resolve()
        self.show_hidden = show_hidden
        self.sort_by = sort_by
        self.sort_order = sort_order

    def generate_index(
        self,
        request_path: str,
        url_prefix: str = ''
    ) -> str:
        full_path = self.root_path / request_path.lstrip('/')
        full_path = full_path.resolve()

        try:
            full_path.relative_to(self.root_path)
        except ValueError:
            raise ValueError("Access denied: path outside root directory")

        if not full_path.is_dir():
            raise ValueError(f"Not a directory: {request_path}")

        files = self._list_files(full_path)
        files = self._sort_files(files)

        try:
            relative_path = "/" + str(full_path.relative_to(self.root_path))
        except ValueError:
            relative_path = request_path

        parent_path = None
        if str(full_path) != str(self.root_path):
            parent_path = str(Path(request_path).parent).rstrip('/')
            if parent_path == '.' or parent_path == '':
                parent_path = '/'

        result = {
            'path': relative_path,
            'parent': parent_path,
            'items': [
                {
                    'name': f['name'],
                    'path': f['path'],
                    'is_dir': f['is_dir'],
                    'size': f['size'],
                    'size_human': self._format_size(f['size']) if not f['is_dir'] else None,
                    'modified': f['modified'].isoformat(),
                    'mime_type': self._get_mime_type(Path(f['path'])),
                }
                for f in files
            ],
            'total': len(files),
        }

        return json.dumps(result, indent=2)

    def _list_files(self, directory: Path) -> List[Dict[str, Any]]:
        files = []

        try:
            for entry in directory.iterdir():
                if not self.show_hidden and entry.name.startswith('.'):
                    continue

                stat = entry.stat()

                file_info = {
                    'name': entry.name,
                    'path': str(entry.relative_to(self.root_path)),
                    'is_dir': entry.is_dir(),
                    'size': stat.st_size,
                    'modified': datetime.fromtimestamp(stat.st_mtime),
                }

                files.append(file_info)
        except PermissionError:
            logger.warning(f"Permission denied: {directory}")
        except Exception as e:
            logger.error(f"Error listing directory {directory}: {e}")

        return files

    def _sort_files(self, files: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        dirs = [f for f in files if f['is_dir']]
        files_only = [f for f in files if not f['is_dir']]

        reverse = self.sort_order == 'desc'

        if self.sort_by == 'name':
            dirs.sort(key=lambda x: x['name'].lower(), reverse=reverse)
            files_only.sort(key=lambda x: x['name'].lower(), reverse=reverse)
        elif self.sort_by == 'size':
            dirs.sort(key=lambda x: x['name'].lower())
            files_only.sort(key=lambda x: x['size'], reverse=reverse)
        elif self.sort_by == 'modified':
            dirs.sort(key=lambda x: x['modified'], reverse=reverse)
            files_only.sort(key=lambda x: x['modified'], reverse=reverse)

        return dirs + files_only

    def _get_mime_type(self, path: Path) -> Optional[str]:
        mime_type, _ = mimetypes.guess_type(str(path))
        return mime_type

    def _format_size(self, size: int) -> str:
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if size < 1024.0:
                return f"{size:.1f} {unit}"
            size /= 1024.0
        return f"{size:.1f} PB"

    def is_safe_path(self, path: str) -> bool:
        try:
            full_path = (self.root_path / path.lstrip('/')).resolve()
            return str(full_path).startswith(str(self.root_path))
        except Exception:
            return False


def generate_directory_index(
    directory: str,
    request_path: str = '/',
    **kwargs
) -> str:
    browser = FileBrowser(directory, **kwargs)
    return browser.generate_index(request_path)
