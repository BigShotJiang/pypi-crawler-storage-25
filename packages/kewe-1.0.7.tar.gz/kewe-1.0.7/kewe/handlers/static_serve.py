#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.handlers.static_serve - Static file serving with directory listing support
"""

import os
import mimetypes
import logging
from typing import Optional, Dict, List, Tuple, Union
from datetime import datetime, timedelta
from pathlib import Path
from email.utils import formatdate, parsedate_to_datetime
import asyncio
from kewe.response import Response
from kewe.request import Request

logger = logging.getLogger(__name__)


class StaticConfig:
    def __init__(
        self,
        url_prefix: str = "/static",
        directory: str = "./static",
        index_file: str = "index.html",
        allow_directory_listing: bool = False,
        follow_symlinks: bool = False,
        max_file_size: int = 100 * 1024 * 1024,
        cache_max_age: int = 3600,
        gzip_level: int = 6,
        file_chunk_size: int = 64 * 1024,
        spa_fallback: bool = False,
        **kwargs
    ):
        self.url_prefix = url_prefix.rstrip("/")
        self.directory = os.path.abspath(directory)
        self.index_file = index_file
        self.allow_directory_listing = allow_directory_listing
        self.follow_symlinks = follow_symlinks
        self.max_file_size = max_file_size
        self.cache_max_age = cache_max_age
        self.gzip_level = gzip_level
        self.file_chunk_size = file_chunk_size
        self.spa_fallback = spa_fallback


class RangeRequest:
    def __init__(self, range_header: str, file_size: int):
        self.range_header = range_header
        self.file_size = file_size
        self.ranges: List[Tuple[int, int]] = []
        self._parse_range()

    def _parse_range(self):
        try:
            if not self.range_header.startswith("bytes="):
                return
            range_spec = self.range_header[6:]
            for part in range_spec.split(","):
                part = part.strip()
                if "-" not in part:
                    continue
                start_str, end_str = part.split("-", 1)
                if start_str and end_str:
                    start = int(start_str)
                    end = int(end_str)
                elif start_str:
                    start = int(start_str)
                    end = self.file_size - 1
                elif end_str:
                    suffix = int(end_str)
                    start = max(0, self.file_size - suffix)
                    end = self.file_size - 1
                else:
                    continue
                start = max(0, start)
                end = min(end, self.file_size - 1)
                if start <= end:
                    self.ranges.append((start, end))
        except (ValueError, IndexError):
            pass

    @property
    def has_ranges(self) -> bool:
        return len(self.ranges) > 0

    @property
    def is_satisfiable(self) -> bool:
        for start, end in self.ranges:
            if start < self.file_size and end < self.file_size:
                return True
        return False


class StaticFileHandler:
    MIME_TYPES = {
        '.html': 'text/html; charset=utf-8',
        '.css': 'text/css; charset=utf-8',
        '.js': 'application/javascript; charset=utf-8',
        '.json': 'application/json',
        '.xml': 'application/xml',
        '.png': 'image/png',
        '.jpg': 'image/jpeg',
        '.jpeg': 'image/jpeg',
        '.gif': 'image/gif',
        '.svg': 'image/svg+xml',
        '.ico': 'image/x-icon',
        '.webp': 'image/webp',
        '.woff': 'font/woff',
        '.woff2': 'font/woff2',
        '.ttf': 'font/ttf',
        '.eot': 'application/vnd.ms-fontobject',
        '.pdf': 'application/pdf',
        '.zip': 'application/zip',
        '.mp4': 'video/mp4',
        '.webm': 'video/webm',
        '.mp3': 'audio/mpeg',
        '.wav': 'audio/wav',
    }

    def __init__(self, config: StaticConfig = None):
        self.config = config or StaticConfig()
        self._file_cache = None
        try:
            from kewe.touchup.zerocopy import FileCache
            cache_max = getattr(self.config, 'file_cache_max_size', 50 * 1024 * 1024)
            self._file_cache = FileCache(max_size=cache_max)
        except (ImportError, Exception):
            logger.warning("Static file compression failed", exc_info=True)

    async def handle(self, request: Request) -> Response:
        path = request.path
        if path.startswith(self.config.url_prefix):
            path = path[len(self.config.url_prefix):]
        safe_path = self._get_safe_path(path)
        if safe_path is None:
            return self._error_response(403, "Forbidden")
        if not os.path.exists(safe_path):
            if self.config.spa_fallback:
                index_path = os.path.join(self.config.directory, self.config.index_file)
                if os.path.isfile(index_path):
                    return await self._handle_file(request, index_path)
            return self._error_response(404, "Not Found")
        if os.path.isdir(safe_path):
            return await self._handle_directory(request, safe_path, path)
        return await self._handle_file(request, safe_path)

    def _get_safe_path(self, path: str) -> Optional[str]:
        from urllib.parse import unquote
        decoded_path = unquote(path)
        clean = os.path.normpath(decoded_path.lstrip("/"))
        if clean.startswith("..") or os.path.isabs(clean):
            return None
        if unquote(clean) != clean:
            return None
        full_path = os.path.join(self.config.directory, clean)
        real_path = os.path.realpath(full_path)
        if not real_path.startswith(os.path.realpath(self.config.directory) + os.sep) and real_path != os.path.realpath(self.config.directory):
            return None
        if not self.config.follow_symlinks and os.path.islink(full_path):
            return None
        return real_path

    async def _handle_directory(self, request: Request, dir_path: str, url_path: str) -> Response:
        if self.config.index_file:
            index_path = os.path.join(dir_path, self.config.index_file)
            if os.path.isfile(index_path):
                return await self._handle_file(request, index_path)
        if self.config.allow_directory_listing:
            return await self._directory_listing(dir_path, url_path)
        return self._error_response(403, "Directory listing not allowed")

    async def _handle_file(self, request: Request, file_path: str) -> Response:
        try:
            stat = os.stat(file_path)
            file_size = stat.st_size
            last_modified = datetime.fromtimestamp(stat.st_mtime)
            etag = self._generate_etag(stat)

            if self._is_not_modified(request, etag, last_modified):
                return Response(status=304)

            accept_encoding = request.headers.get("accept-encoding", "")
            encoding = self._get_best_encoding(accept_encoding, file_path)
            if encoding:
                return await self._send_compressed_file(request, file_path, encoding, etag, last_modified)

            range_header = request.headers.get("range")
            if range_header and file_size > 0:
                if_range = request.headers.get("if-range")
                if if_range:
                    if if_range != etag and if_range != last_modified.strftime('%a, %d %b %Y %H:%M:%S GMT'):
                        range_header = None
                
                if range_header:
                    range_req = RangeRequest(range_header, file_size)
                    if range_req.has_ranges and range_req.is_satisfiable:
                        return await self._send_range_response(request, file_path, range_req, etag, last_modified)

            loop = asyncio.get_running_loop()
            content_type = self._get_content_type(file_path)

            stream_threshold = getattr(self.config, 'stream_threshold', 1 * 1024 * 1024)
            try:
                from kewe.touchup.zerocopy import ZeroCopyFileResponse
                if file_size > 64 * 1024:
                    response = ZeroCopyFileResponse(
                        file_path,
                        content_type=content_type,
                    )
                    self._add_cache_headers(response, etag, last_modified)
                    response.headers['accept-ranges'] = 'bytes'
                    response.headers['x-content-type-options'] = 'nosniff'
                    return response
            except ImportError:
                pass

            if self._file_cache is not None and file_size <= 64 * 1024:
                cached = self._file_cache.get(file_path)
                if cached is None:
                    cached = self._file_cache.put(file_path)
                if cached is not None:
                    response = Response(body=bytes(cached[:file_size]), status=200, content_type=content_type)
                    self._add_cache_headers(response, etag, last_modified)
                    response.headers['accept-ranges'] = 'bytes'
                    response.headers['x-content-type-options'] = 'nosniff'
                    return response

            if file_size > stream_threshold:
                from kewe.response import StreamingResponse

                def _file_iterator(fp, chunk_size=64 * 1024):
                    with open(fp, 'rb') as f:
                        while True:
                            chunk = f.read(chunk_size)
                            if not chunk:
                                break
                            yield chunk

                response = StreamingResponse(
                    _file_iterator(file_path),
                    status=200,
                    content_type=content_type,
                )
            else:
                content = await loop.run_in_executor(None, self._read_file, file_path)
                response = Response(body=content, status=200, content_type=content_type)
            self._add_cache_headers(response, etag, last_modified)
            response.headers['content-length'] = str(file_size)
            response.headers['accept-ranges'] = 'bytes'
            response.headers['x-content-type-options'] = 'nosniff'
            return response
        except Exception as e:
            logger.error(f"Error serving file {file_path}: {e}")
            return self._error_response(500, "Internal Server Error")

    async def _send_range_response(
        self, request: Request, file_path: str, range_req: RangeRequest, etag: str, last_modified: datetime
    ) -> Response:
        start, end = range_req.ranges[0]
        content_length = end - start + 1
        loop = asyncio.get_running_loop()
        content = await loop.run_in_executor(None, self._read_file_range, file_path, start, end)
        content_type = self._get_content_type(file_path)
        response = Response(body=content, status=206, content_type=content_type)
        response.headers['content-range'] = f'bytes {start}-{end}/{range_req.file_size}'
        response.headers['content-length'] = str(content_length)
        self._add_cache_headers(response, etag, last_modified)
        response.headers['accept-ranges'] = 'bytes'
        return response

    def _read_file(self, file_path: str) -> bytes:
        file_size = os.path.getsize(file_path)
        max_size = getattr(self.config, 'max_file_size', 100 * 1024 * 1024) if hasattr(self, 'config') else 100 * 1024 * 1024
        if file_size > max_size:
            raise ValueError(f"File too large: {file_size} > {max_size}")
        with open(file_path, 'rb') as f:
            return f.read()

    def _read_file_range(self, file_path: str, start: int, end: int) -> bytes:
        with open(file_path, 'rb') as f:
            f.seek(start)
            return f.read(end - start + 1)

    def _get_content_type(self, file_path: str) -> str:
        ext = os.path.splitext(file_path)[1].lower()
        if ext in self.MIME_TYPES:
            return self.MIME_TYPES[ext]
        mime_type, _ = mimetypes.guess_type(file_path)
        return mime_type or 'application/octet-stream'

    def _generate_etag(self, stat) -> str:
        return f'"{stat.st_mtime_ns:x}-{stat.st_size:x}"'

    def _is_not_modified(self, request: Request, etag: str, last_modified: datetime) -> bool:
        if_none_match = request.headers.get('if-none-match')
        if if_none_match:
            for client_etag in if_none_match.split(','):
                client_etag = client_etag.strip()
                if client_etag.startswith('W/'):
                    client_etag = client_etag[2:]
                if client_etag == etag:
                    return True
        if_modified_since = request.headers.get('if-modified-since')
        if if_modified_since:
            try:
                client_time = parsedate_to_datetime(if_modified_since)
                if last_modified < client_time:
                    return True
            except Exception:
                logger.debug("Non-critical operation failed", exc_info=True)
        return False

    def _add_cache_headers(self, response: Response, etag: str, last_modified: datetime):
        response.headers['etag'] = etag
        response.headers['last-modified'] = formatdate(timeval=last_modified.timestamp(), localtime=False, usegmt=True)
        if self.config.cache_max_age > 0:
            response.headers['cache-control'] = f'public, max-age={self.config.cache_max_age}'

    async def _directory_listing(self, dir_path: str, url_path: str) -> Response:
        try:
            entries = os.listdir(dir_path)
            entries.sort()
            html = self._generate_directory_html(dir_path, url_path, entries)
            return Response(body=html.encode('utf-8'), status=200, content_type='text/html; charset=utf-8')
        except Exception as e:
            logger.error(f"Error generating directory listing: {e}")
            return self._error_response(500, "Internal Server Error")

    def _generate_directory_html(self, dir_path: str, url_path: str, entries: List[str]) -> str:
        from html import escape as html_escape
        safe_url_path = html_escape(url_path)
        html_parts = [
            f'<html><head><title>Index of {safe_url_path}</title>',
            '<style>',
            'body { font-family: Arial, sans-serif; margin: 40px; }',
            'h1 { border-bottom: 1px solid #ccc; padding-bottom: 10px; }',
            'table { width: 100%; border-collapse: collapse; }',
            'th, td { text-align: left; padding: 8px; border-bottom: 1px solid #ddd; }',
            'th { background-color: #f2f2f2; }',
            'a { text-decoration: none; color: #0066cc; }',
            'a:hover { text-decoration: underline; }',
            '</style></head><body>',
            f'<h1>Index of {safe_url_path}</h1>',
            '<table><tr><th>Name</th><th>Size</th><th>Modified</th></tr>',
            '<tr><td><a href="../">..</a></td><td>-</td><td>-</td></tr>',
        ]
        for entry in entries:
            full_path = os.path.join(dir_path, entry)
            is_dir = os.path.isdir(full_path)
            icon = '&#128193;' if is_dir else '&#128196;'
            href = entry + '/' if is_dir else entry
            safe_entry = entry.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;')
            safe_href = href.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;')
            size = '-' if is_dir else self._format_size(os.path.getsize(full_path))
            try:
                modified = datetime.fromtimestamp(os.path.getmtime(full_path)).strftime('%Y-%m-%d %H:%M')
            except OSError:
                modified = '-'
            html_parts.append(f'<tr><td><a href="{safe_href}">{icon} {safe_entry}</a></td><td>{size}</td><td>{modified}</td></tr>')
        html_parts.append('</table></body></html>')
        return '\n'.join(html_parts)

    def _format_size(self, size: float) -> str:
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size < 1024:
                return f"{size:.1f} {unit}"
            size /= 1024
        return f"{size:.1f} TB"

    def _get_best_encoding(self, accept_encoding: str, file_path: str) -> Optional[str]:
        if 'br' in accept_encoding:
            br_path = f"{file_path}.br"
            if os.path.exists(br_path):
                return 'br'
        if 'gzip' in accept_encoding:
            gz_path = f"{file_path}.gz"
            if os.path.exists(gz_path):
                return 'gzip'
        return None

    async def _send_compressed_file(
        self, request: Request, file_path: str, encoding: str, etag: str, last_modified: datetime
    ) -> Response:
        compressed_path = f"{file_path}.gz" if encoding == 'gzip' else f"{file_path}.{encoding}"
        if not os.path.exists(compressed_path):
            await self._compress_file(file_path, compressed_path, encoding)
        loop = asyncio.get_running_loop()
        content = await loop.run_in_executor(None, self._read_file, compressed_path)
        content_type = self._get_content_type(file_path)
        response = Response(body=content, status=200, content_type=content_type)
        response.headers['content-encoding'] = encoding
        self._add_cache_headers(response, etag, last_modified)
        response.headers['content-length'] = str(len(content))
        response.headers['accept-ranges'] = 'bytes'
        return response

    async def _compress_file(self, file_path: str, compressed_path: str, encoding: str):
        try:
            with open(file_path, 'rb') as f_in:
                with open(compressed_path, 'wb') as f_out:
                    if encoding == 'gzip':
                        import gzip
                        with gzip.GzipFile(fileobj=f_out, mode='w', compresslevel=self.config.gzip_level) as f_gzip:
                            while True:
                                chunk = f_in.read(self.config.file_chunk_size)
                                if not chunk:
                                    break
                                f_gzip.write(chunk)
                    elif encoding == 'br':
                        import brotli
                        compressor = brotli.Compressor(quality=self.config.gzip_level)
                        while True:
                            chunk = f_in.read(self.config.file_chunk_size)
                            if not chunk:
                                break
                            f_out.write(compressor.process(chunk))
                        f_out.write(compressor.finish())
            logger.debug(f"Compressed {file_path} to {compressed_path}")
        except Exception as e:
            logger.error(f"Error compressing file {file_path}: {e}")

    def _error_response(self, status: int, message: str) -> Response:
        return Response(
            body=f"<html><body><h1>{status} - {message}</h1></body></html>".encode('utf-8'),
            status=status,
            content_type='text/html; charset=utf-8'
        )


def register_static(
    app,
    url_prefix: str = "/static",
    directory: str = "./static",
    *,
    name: Optional[str] = None,
    **kwargs,
):
    normalized_prefix = url_prefix.rstrip("/") or "/"
    config = StaticConfig(url_prefix=normalized_prefix, directory=directory, **kwargs)
    handler = StaticFileHandler(config)
    route_name = name or f"static_{normalized_prefix.strip('/').replace('/', '_') or 'root'}"

    @app.route(normalized_prefix, methods=["GET", "HEAD"], name=route_name)
    async def static_root_handler(request, path: str = ""):
        return await handler.handle(request)

    @app.route(f"{normalized_prefix}/", methods=["GET", "HEAD"], name=f"{route_name}_slash")
    async def static_root_slash_handler(request, path: str = ""):
        return await handler.handle(request)

    @app.route(f"{normalized_prefix}/<path:path>", methods=["GET", "HEAD"], name=f"{route_name}_path")
    async def static_handler(request, path: str = ""):
        return await handler.handle(request)
