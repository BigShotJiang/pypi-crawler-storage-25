#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.factory - Application factory helpers for creating configured Kewe apps
"""

from __future__ import annotations

from dataclasses import asdict, is_dataclass
from typing import Any, Callable, List, Mapping, Optional, Sequence

from kewe.application.config import Config, KeweConfig
from kewe.plugins.base import register_plugin


def _apply_mapping(config: KeweConfig, mapping: Mapping[str, Any]) -> None:
    for key, value in mapping.items():
        attr_name = key.lower()
        if hasattr(config, attr_name):
            setattr(config, attr_name, value)
        else:
            config.extra[key] = value


def _mapping_from_object(obj: Any) -> dict[str, Any]:
    if obj is None:
        return {}
    if isinstance(obj, Mapping):
        return dict(obj)
    if isinstance(obj, Config):
        return dict(obj)
    if is_dataclass(obj):
        return asdict(obj)

    result: dict[str, Any] = {}
    for key in dir(obj):
        if key.startswith("_"):
            continue
        value = getattr(obj, key)
        if callable(value):
            continue
        if isinstance(obj, KeweConfig):
            result[key] = value
        elif key.isupper():
            result[key] = value
    return result


def _normalize_plugins(plugins: Optional[list[Any]]) -> list[tuple[type, dict[str, Any]]]:
    normalized: list[tuple[type, dict[str, Any]]] = []
    for item in plugins or []:
        if isinstance(item, tuple) and len(item) == 2:
            plugin_class, plugin_config = item
            normalized.append((plugin_class, dict(plugin_config or {})))
        elif isinstance(item, dict) and "plugin" in item:
            normalized.append((item["plugin"], dict(item.get("config", {}))))
        else:
            normalized.append((item, {}))
    return normalized


def create_app(
    name: str = "KeweApp",
    *,
    app_class=None,
    config: Any = None,
    config_file: Optional[str] = None,
    config_object: Any = None,
    env_prefix: str = "KEWE_",
    enable_gateway: Optional[bool] = None,
    lifespan=None,
    plugins: Optional[list[Any]] = None,
    static: Optional[list[dict[str, Any]] | dict[str, Any]] = None,
    openapi: Optional[dict[str, Any]] = None,
    middleware: Optional[Sequence[Any]] = None,
    exception_handlers: Optional[Mapping[Any, Callable]] = None,
    on_startup: Optional[Sequence[Callable]] = None,
    on_shutdown: Optional[Sequence[Callable]] = None,
    routes: Optional[Sequence[Any]] = None,
    debug: Optional[bool] = None,
    root_path: str = "",
):
    """Create a Kewe application with layered configuration."""
    if app_class is None:
        from kewe.app import Kewe as app_class

    if isinstance(config, KeweConfig):
        import copy
        resolved_config = copy.deepcopy(config)
    else:
        resolved_config = KeweConfig()
        _apply_mapping(resolved_config, _mapping_from_object(config))

    _apply_mapping(resolved_config, _mapping_from_object(config_object))

    if config_file:
        raw_config = Config()
        raw_config.load_from_file(config_file)
        _apply_mapping(resolved_config, raw_config)

    env_config = Config()
    env_config.load_from_env(prefix=env_prefix)
    _apply_mapping(resolved_config, env_config)

    app = app_class(
        name=name,
        config=resolved_config,
        enable_gateway=enable_gateway,
        lifespan=lifespan,
    )

    if debug is not None:
        resolved_config.debug = debug

    if root_path:
        app.root_path = root_path

    if on_startup is not None:
        for handler in on_startup:
            app.register_listener("before_server_start", handler)

    if on_shutdown is not None:
        for handler in on_shutdown:
            app.register_listener("before_server_stop", handler)

    if middleware is not None:
        for mw in middleware:
            if isinstance(mw, tuple) and len(mw) == 2:
                app.middleware(mw[0], **(mw[1] if isinstance(mw[1], dict) else {}))
            else:
                app.middleware(mw)

    if exception_handlers is not None:
        for exc_class_or_code, handler in exception_handlers.items():
            app.exception(exc_class_or_code)(handler)

    if routes is not None:
        for route_item in routes:
            if isinstance(route_item, tuple) and len(route_item) >= 2:
                path, endpoint = route_item[0], route_item[1]
                methods = route_item[2] if len(route_item) > 2 else ["GET"]
                app.router.add_route(path=path, methods=methods, handler=endpoint)
            elif hasattr(route_item, 'path') and hasattr(route_item, 'endpoint'):
                methods = getattr(route_item, 'methods', ["GET"])
                app.router.add_route(path=route_item.path, methods=methods, handler=route_item.endpoint)

    for plugin_class, plugin_config in _normalize_plugins(plugins):
        register_plugin(app, plugin_class, **plugin_config)

    if openapi is not None:
        from kewe.plugins.openapi import OpenAPIPlugin

        register_plugin(app, OpenAPIPlugin, **dict(openapi))

    if static is not None:
        static_defs = static if isinstance(static, list) else [static]
        for item in static_defs:
            app.static(**dict(item))

    return app


__all__ = ["create_app"]
