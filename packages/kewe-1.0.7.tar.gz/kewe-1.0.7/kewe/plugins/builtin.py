#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.plugins.builtin - Built-in plugins for compression, CORS, and rate limiting
"""

import logging
from typing import List

from .base import Plugin
from kewe import __version__

logger = logging.getLogger(__name__)


class CORSPlugin(Plugin):
    """CORS跨域插件"""
    
    name = "cors"
    version = __version__
    
    def setup(self, app, **config):
        origins = config.get('origins', ['*'])
        methods = config.get('methods', ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'])
        headers = config.get('headers', ['Content-Type', 'Authorization'])
        expose_headers = config.get('expose_headers', [])
        max_age = config.get('max_age', 86400)
        
        @app.middleware('response')
        async def add_cors_headers(request, response):
            origin = request.headers.get('Origin', '*')
            if '*' in origins or origin in origins:
                response.headers['Access-Control-Allow-Origin'] = origin
            response.headers['Access-Control-Allow-Methods'] = ', '.join(methods)
            response.headers['Access-Control-Allow-Headers'] = ', '.join(headers)
            if expose_headers:
                response.headers['Access-Control-Expose-Headers'] = ', '.join(expose_headers)
            response.headers['Access-Control-Max-Age'] = str(max_age)
        
        @app.route('/*', methods=['OPTIONS'])
        async def handle_options(request):
            from kewe.response import Response
            response = Response(status=204)
            origin = request.headers.get('Origin', '*')
            if '*' in origins or origin in origins:
                response.headers['Access-Control-Allow-Origin'] = origin
            response.headers['Access-Control-Allow-Methods'] = ', '.join(methods)
            response.headers['Access-Control-Allow-Headers'] = ', '.join(headers)
            if expose_headers:
                response.headers['Access-Control-Expose-Headers'] = ', '.join(expose_headers)
            response.headers['Access-Control-Max-Age'] = str(max_age)
            return response


class CompressionPlugin(Plugin):
    """响应压缩插件"""
    
    name = "compression"
    version = __version__
    
    def setup(self, app, **config):
        min_size = config.get('min_size', 500)
        compression_level = config.get('compression_level', 6)
        
        @app.middleware('response')
        async def compress_response(request, response):
            import gzip
            
            accept_encoding = request.headers.get('Accept-Encoding', '')
            body = response.body
            
            if isinstance(body, str):
                body = body.encode('utf-8')
            
            if not body or len(body) < min_size:
                return
            
            if 'gzip' in accept_encoding:
                compressed = gzip.compress(body, compresslevel=compression_level)
                response.body = compressed
                response.headers['Content-Encoding'] = 'gzip'
                response.headers['Content-Length'] = str(len(compressed))


class RateLimitPlugin(Plugin):
    """速率限制插件"""
    
    name = "rate_limit"
    version = __version__
    
    def setup(self, app, **config):
        from kewe.cache.lru_cache import LRUCache
        import time
        
        requests_per_minute = config.get('requests_per_minute', 60)
        block_duration = config.get('block_duration', 60)
        self.cache = LRUCache(maxsize=10000)
        self.blocked = LRUCache(maxsize=10000)
        
        @app.middleware('request')
        async def check_rate_limit(request):
            client_ip = request.client_ip
            current_time = time.time()
            
            blocked_until = self.blocked.get(client_ip, 0)
            if current_time < blocked_until:
                from kewe.response import Response
                return Response(
                    body=b'Rate limit exceeded, please try again later',
                    status_code=429,
                    headers={'Content-Type': 'text/plain'}
                )
            
            requests = self.cache.get(client_ip, [])
            requests = [t for t in requests if current_time - t < 60]
            
            if len(requests) >= requests_per_minute:
                self.blocked.set(client_ip, current_time + block_duration)
                from kewe.response import Response
                return Response(
                    body=b'Rate limit exceeded',
                    status_code=429,
                    headers={'Content-Type': 'text/plain'}
                )
            
            requests.append(current_time)
            self.cache.set(client_ip, requests)


class SecurityPlugin(Plugin):
    """安全插件"""
    
    name = "security"
    version = __version__
    
    def setup(self, app, **config):
        @app.middleware('response')
        async def add_security_headers(request, response):
            response.headers['X-XSS-Protection'] = '1; mode=block'
            response.headers['X-Frame-Options'] = 'SAMEORIGIN'
            response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
            response.headers['Content-Security-Policy'] = "default-src 'self'"
            response.headers['X-Content-Type-Options'] = 'nosniff'


HealthPlugin = SecurityPlugin
InfoPlugin = SecurityPlugin

__all__ = [
    'CORSPlugin',
    'CompressionPlugin',
    'RateLimitPlugin',
    'SecurityPlugin',
    'HealthPlugin',
    'InfoPlugin',
]



