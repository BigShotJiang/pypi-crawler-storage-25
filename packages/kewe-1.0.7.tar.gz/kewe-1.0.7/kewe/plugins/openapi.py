#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.plugins.openapi - OpenAPI/Swagger documentation plugin
"""

from kewe.plugins import Plugin
from kewe import __version__
from typing import Dict, Any, List, Optional, Callable, Union
from kewe.utils.compat import json
import inspect
import re
import logging

logger = logging.getLogger(__name__)

_SWAGGER_UI_VERSION = "5.11.0"
_REDOC_VERSION = "2.1.3"

_HTTP_STATUS_DESCRIPTIONS = {
    100: "Continue", 101: "Switching Protocols",
    200: "OK", 201: "Created", 202: "Accepted", 204: "No Content",
    301: "Moved Permanently", 302: "Found", 304: "Not Modified", 307: "Temporary Redirect",
    400: "Bad Request", 401: "Unauthorized", 403: "Forbidden", 404: "Not Found",
    405: "Method Not Allowed", 409: "Conflict", 422: "Unprocessable Entity",
    429: "Too Many Requests", 500: "Internal Server Error", 502: "Bad Gateway",
    503: "Service Unavailable",
}

_SWAGGER_UI_HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>{title} - Swagger UI</title>
    {css_link}
    <style>
        body {{ margin: 0; padding: 0; }}       
        .swagger-ui {{ height: 100vh; width: 100%; }}
    </style>
</head>
<body>
    <div id="swagger-ui"></div>
    {js_scripts}
    <script>
    window.onload = function() {{
        SwaggerUIBundle({{
            url: "{openapi_url}",
            dom_id: '#swagger-ui',
            deepLinking: true,
            presets: [
                SwaggerUIBundle.presets.apis,
                SwaggerUIStandalonePreset
            ],
            plugins: [SwaggerUIBundle.plugins.DownloadUrl],
            layout: "StandaloneLayout",
            displayRequestDuration: true,
            showExtensions: true,
            docExpansion: "list",
            defaultModelsExpandDepth: 2,
            defaultModelExpandDepth: 2
        }})
    }}
    </script>
</body>
</html>
"""

_REDOC_HTML = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>{title} - ReDoc</title>
    {css_link}
    <style> body {{ margin: 0; padding: 0; }} </style>
</head>
<body>
    <div id="redoc"></div>
    {js_script}
    <script>
    Redoc.init("{openapi_url}", {{
        scrollYOffset: 50,
        hideDownloadButton: false,
        expandResponses: "200,201"
    }})
    </script>
</body>
</html>
"""


def _build_swagger_html(title: str, openapi_url: str, cdn: bool = True) -> str:
    if cdn:
        css_link = f'<link rel="stylesheet" type="text/css" href="https://unpkg.com/swagger-ui-dist@{_SWAGGER_UI_VERSION}/swagger-ui.css">'
        js_scripts = (
            f'<script src="https://unpkg.com/swagger-ui-dist@{_SWAGGER_UI_VERSION}/swagger-ui-bundle.js"></script>'
            f'<script src="https://unpkg.com/swagger-ui-dist@{_SWAGGER_UI_VERSION}/swagger-ui-standalone-preset.js"></script>'
        )
    else:
        css_link = '<style>/* Swagger UI CSS - inline mode: install swagger-ui-bundle for full offline support */</style>'
        js_scripts = (
            '<script>/* Swagger UI JS - inline mode */\n'
            'try { if(typeof SwaggerUIBundle === "undefined") { document.getElementById("swagger-ui").innerHTML = '
            '"<h2>Offline Mode</h2><p>Swagger UI resources not available locally. '
            'Set <code>cdn=True</code> or install <code>swagger-ui-bundle</code> package.</p>"; } } catch(e) {}\n'
            '</script>'
        )
        try:
            import swagger_ui_bundle
            bundle_dir = swagger_ui_bundle.get_dir()
            css_link = f'<link rel="stylesheet" type="text/css" href="/_kewe_static/swagger-ui.css">'
            js_scripts = (
                f'<script src="/_kewe_static/swagger-ui-bundle.js"></script>'
                f'<script src="/_kewe_static/swagger-ui-standalone-preset.js"></script>'
            )
        except ImportError:
            pass
    return _SWAGGER_UI_HTML.format(
        title=title, openapi_url=openapi_url,
        css_link=css_link, js_scripts=js_scripts
    )


def _build_redoc_html(title: str, openapi_url: str, cdn: bool = True) -> str:
    if cdn:
        css_link = f'<link rel="stylesheet" type="text/css" href="https://unpkg.com/redoc@{_REDOC_VERSION}/bundles/redoc.standalone.css">'
        js_script = f'<script src="https://unpkg.com/redoc@{_REDOC_VERSION}/bundles/redoc.standalone.js"></script>'
    else:
        css_link = '<style>/* ReDoc CSS - inline mode */</style>'
        js_script = (
            '<script>/* ReDoc JS - inline mode */\n'
            'try { if(typeof Redoc === "undefined") { document.getElementById("redoc").innerHTML = '
            '"<h2>Offline Mode</h2><p>ReDoc resources not available locally. '
            'Set <code>cdn=True</code> or install <code>redoc</code> package.</p>"; } } catch(e) {}\n'
            '</script>'
        )
    return _REDOC_HTML.format(
        title=title, openapi_url=openapi_url,
        css_link=css_link, js_script=js_script
    )


class OpenAPIPlugin(Plugin):
    """OpenAPI文档插件"""
    
    name = "openapi"
    version = __version__
    
    def setup(self, app, **config):
        self.config = config
        self.title = config.get('title', app.name or 'API')
        self.version = config.get('version', '1.0.0')
        self.description = config.get('description', '')
        self.openapi_version = config.get('openapi_version', '3.1.0')
        set_openapi_plugin(self, app=app)
        self.servers = config.get('servers', [])
        self.security = config.get('security', [])
        self.tags = config.get('tags', [])
        self.webhooks: Dict[str, Dict[str, Any]] = config.get('webhooks', {})
        self.external_docs = config.get('external_docs', None)
        self.contact = config.get('contact', None)
        self.license = config.get('license', None)
        self.terms_of_service = config.get('terms_of_service', None)
        
        self.paths: Dict[str, Dict[str, Any]] = {}
        self._operation_ids: set = set()
        self._spec_cache: Optional[Dict[str, Any]] = None
        self._spec_dirty: bool = True
        
        self.components = {
            'schemas': {},
            'securitySchemes': {},
            'responses': {},
            'parameters': {},
            'examples': {},
            'requestBodies': {},
            'headers': {},
            'links': {},
            'callbacks': {},
            'pathItems': {},
        }
        
        app.openapi = self
        app._openapi_plugin = self

        self._auto_register_security_schemes(app)
        
        openapi_url = config.get('openapi_url', '/openapi.json')
        
        @app.route(openapi_url)
        async def openapi_json(request):
            from kewe.response import json as json_resp
            return json_resp(self.generate_spec())
        
        @app.route("/openapi.yaml")
        async def openapi_yaml(request):
            from kewe.response import text, Response as _Response
            try:
                import yaml
            except ImportError:
                return text("PyYAML not installed. Install with: pip install pyyaml", status=500)
            spec = self.generate_spec()
            yaml_spec = yaml.dump(spec, default_flow_style=False, allow_unicode=True)
            return _Response(body=yaml_spec, status=200, content_type="application/x-yaml")
        
        self.cdn = config.get('cdn', True)

        swagger_url = config.get('swagger_ui_url', '/docs')
        if config.get('swagger_ui', True) and swagger_url:
            @app.route(swagger_url)
            async def swagger_ui(request):
                from kewe.response import html
                return html(_build_swagger_html(self.title, openapi_url, cdn=self.cdn))
        
        redoc_url = config.get('redoc_url', '/redoc')
        if config.get('redoc', True) and redoc_url:
            @app.route(redoc_url)
            async def redoc_ui(request):
                from kewe.response import html
                return html(_build_redoc_html(self.title, openapi_url, cdn=self.cdn))
        
        self._app = app
        self._backfill_routes(app)
        if hasattr(app, 'router') and hasattr(app.router, 'add_route_hook'):
            app.router.add_route_hook(self._on_route_added)
            app._openapi_hook_registered = True
    
    def _backfill_routes(self, app):
        if not hasattr(app, 'router'):
            return

        routes = []
        if hasattr(app.router, '_route_map'):
            routes = list(app.router._route_map.values())
        elif hasattr(app.router, 'routes'):
            routes = app.router.routes

        for route_info in routes:
            methods = list(route_info.methods) if route_info.methods else ['GET']
            try:
                extra_kwargs = {}
                if hasattr(route_info, 'response_model') and route_info.response_model:
                    extra_kwargs['response_model'] = route_info.response_model
                if hasattr(route_info, 'status_code') and route_info.status_code:
                    extra_kwargs['status_code'] = route_info.status_code
                if hasattr(route_info, 'tags') and route_info.tags:
                    extra_kwargs['tags'] = route_info.tags
                if hasattr(route_info, 'summary') and route_info.summary:
                    extra_kwargs['summary'] = route_info.summary
                if hasattr(route_info, 'description') and route_info.description:
                    extra_kwargs['description'] = route_info.description
                if hasattr(route_info, 'deprecated') and route_info.deprecated:
                    extra_kwargs['deprecated'] = route_info.deprecated
                self.collect_route_info(
                    route_info.path, methods, route_info.handler,
                    **extra_kwargs
                )
            except Exception as e:
                import logging
                logging.getLogger(__name__).warning(
                    f"Failed to backfill route {route_info.path}: {e}"
                )

    def _on_route_added(self, path, methods, handler, **kwargs):
        try:
            self.collect_route_info(path, list(methods), handler, **kwargs)
            self._spec_dirty = True
        except Exception as e:
            logger.warning(f"OpenAPI: failed to collect route info for {path}: {e}")
    
    def collect_route_info(self, path: str, methods: List[str], handler: Callable, **kwargs):
        """收集路由信息 - 由 Router.add_route 调用，替代猴子补丁方式"""
        openapi_info = kwargs.pop('openapi', {})
        response_model = kwargs.pop('response_model', None)
        status_code = kwargs.pop('status_code', None)
        tags_kwarg = kwargs.pop('tags', None)
        summary_kwarg = kwargs.pop('summary', None)
        description_kwarg = kwargs.pop('description', None)
        deprecated_kwarg = kwargs.pop('deprecated', None)
        responses_kwarg = kwargs.pop('responses', None)
        
        if hasattr(handler, '_openapi'):
            openapi_info = {**openapi_info, **handler._openapi}
        
        if openapi_info.get('exclude'):
            return
        
        openapi_path = self._convert_path(path)
        
        if openapi_path not in self.paths:
            self.paths[openapi_path] = {}
        
        auto_params = self._extract_path_params(path)
        auto_params.extend(self._extract_type_hint_params(handler, path))
        
        existing_params = openapi_info.get('parameters', [])
        existing_names = {p.get('name') for p in existing_params}
        for p in auto_params:
            if p.get('name') not in existing_names:
                existing_params.append(p)
        
        request_body = openapi_info.get('requestBody')
        if request_body is None:
            request_body = self._extract_request_body(handler)
        
        responses = openapi_info.get('responses', {})
        if not responses:
            responses = self._extract_response_schema(handler)

        if response_model is not None:
            success_code = str(status_code or 200)
            try:
                from pydantic import BaseModel
                if isinstance(response_model, type) and issubclass(response_model, BaseModel):
                    schema = self._pydantic_to_schema(response_model)
                else:
                    schema = self._type_to_schema(response_model) or {}
            except ImportError:
                schema = self._type_to_schema(response_model) or {}
            if schema:
                status_int = int(success_code)
                desc = _HTTP_STATUS_DESCRIPTIONS.get(status_int, 'Successful response')
                responses[success_code] = {
                    'description': desc,
                    'content': {
                        'application/json': {
                            'schema': schema
                        }
                    }
                }

        if responses_kwarg:
            for code, resp_info in responses_kwarg.items():
                responses[str(code)] = resp_info

        if not responses:
            responses = {'200': {'description': _HTTP_STATUS_DESCRIPTIONS.get(200, 'OK')}}

        if openapi_info.get('security') or self.security:
            error_responses = {}
            has_auth_error = any('401' not in responses for _ in [1])
            if '401' not in responses:
                error_responses['401'] = {
                    'description': _HTTP_STATUS_DESCRIPTIONS.get(401, 'Unauthorized'),
                    'content': {'application/json': {'schema': {'type': 'object', 'properties': {'detail': {'type': 'string'}}}}}
                }
            if '403' not in responses:
                error_responses['403'] = {
                    'description': _HTTP_STATUS_DESCRIPTIONS.get(403, 'Forbidden'),
                    'content': {'application/json': {'schema': {'type': 'object', 'properties': {'detail': {'type': 'string'}}}}}
                }
            if '422' not in responses:
                error_responses['422'] = {
                    'description': _HTTP_STATUS_DESCRIPTIONS.get(422, 'Validation Error'),
                    'content': {'application/json': {'schema': {'type': 'object', 'properties': {'detail': {'type': 'string'}}}}}
                }
            responses.update(error_responses)
        
        merged_tags = openapi_info.get('tags', [])
        if tags_kwarg:
            merged_tags = list(set(merged_tags + list(tags_kwarg)))

        auto_summary, auto_description = self._parse_docstring(handler)

        for method in methods:
            method_lower = method.lower()
            
            operation = {
                'summary': summary_kwarg or openapi_info.get('summary') or auto_summary,
                'description': description_kwarg or openapi_info.get('description') or auto_description,
                'parameters': existing_params,
                'responses': responses,
                'tags': merged_tags,
            }
            
            if request_body:
                operation['requestBody'] = request_body
            
            if openapi_info.get('security'):
                operation['security'] = openapi_info.get('security')
            
            is_deprecated = deprecated_kwarg if deprecated_kwarg is not None else openapi_info.get('deprecated', False)
            if is_deprecated:
                operation['deprecated'] = True
            
            custom_operation_id = openapi_info.get('operation_id')
            if custom_operation_id:
                operation['operationId'] = custom_operation_id
            else:
                operation_id = handler.__name__
                if operation_id != '<lambda>':
                    if operation_id in self._operation_ids:
                        base_id = operation_id
                        counter = 2
                        while f"{base_id}_{counter}" in self._operation_ids:
                            counter += 1
                        operation_id = f"{base_id}_{counter}"
                    self._operation_ids.add(operation_id)
                    operation['operationId'] = operation_id
            
            self.paths[openapi_path][method_lower] = operation
    
    def _parse_docstring(self, handler: Callable) -> tuple:
        doc = getattr(handler, '__doc__', None) or ''
        if not doc:
            return '', ''
        doc = doc.strip()
        lines = doc.split('\n', 1)
        summary = lines[0].strip()
        description = lines[1].strip() if len(lines) > 1 else ''
        return summary, description

    @staticmethod
    def _convert_path(path: str) -> str:
        """将路由路径转换为 OpenAPI 路径格式"""
        return re.sub(r'<(\w+)(?::\w+)?>', r'{\1}', path)
    
    @staticmethod
    def _extract_path_params(path: str) -> List[Dict[str, Any]]:
        """从路径中提取路径参数"""
        params = []
        for match in re.finditer(r'<(\w+)(?::(\w+))?>', path):
            name = match.group(1)
            type_hint = match.group(2) or 'string'
            type_map = {
                'int': 'integer',
                'float': 'number',
                'str': 'string',
                'string': 'string',
                'uuid': 'string',
                'path': 'string',
            }
            params.append({
                'name': name,
                'in': 'path',
                'required': True,
                'schema': {'type': type_map.get(type_hint, 'string')},
                'description': ''
            })
        return params
    
    def _extract_type_hint_params(self, handler: Callable, path: str) -> List[Dict[str, Any]]:
        params = []
        try:
            from kewe.application.depends import _ParamDependency
            sig = inspect.signature(handler)
            try:
                type_hints = inspect.get_annotations(handler) if hasattr(inspect, 'get_annotations') else {}
            except Exception:
                type_hints = {}
            
            from typing import get_origin, get_args
            
            path_param_names = set(re.findall(r'<(\w+)(?::\w+)?>', path))
            
            for name, param in sig.parameters.items():
                if name in ('request', 'req', 'self', 'cls') or name in path_param_names:
                    continue
                
                param_type = type_hints.get(name)
                if param_type is None:
                    param_type = param.annotation if param.annotation is not inspect.Parameter.empty else None
                
                if param_type is None:
                    if isinstance(param.default, _ParamDependency):
                        param_info = self._param_default_to_openapi(name, param.default, param)
                        if param_info:
                            params.append(param_info)
                        continue
                    continue
                
                if self._is_depends(param_type):
                    self._extract_depends_params(param_type, params)
                    continue
                
                if isinstance(param.default, _ParamDependency):
                    param_info = self._param_default_to_openapi(name, param.default, param)
                    if param_info:
                        params.append(param_info)
                    continue
                
                if get_origin(param_type) is not None:
                    from typing import Annotated
                    if get_origin(param_type) is Annotated:
                        args = get_args(param_type)
                        inner_type = args[0]
                        for metadata in args[1:]:
                            param_info = self._annotated_metadata_to_openapi(name, metadata, inner_type, param)
                            if param_info:
                                params.append(param_info)
                                break
                        else:
                            schema = self._type_to_schema(inner_type)
                            if schema:
                                params.append({
                                    'name': name,
                                    'in': 'query',
                                    'required': param.default is inspect.Parameter.empty,
                                    'schema': schema,
                                })
                        continue
                
                if isinstance(param_type, type):
                    try:
                        from pydantic import BaseModel
                        if issubclass(param_type, BaseModel):
                            continue
                    except ImportError:
                        pass
                
                schema = self._type_to_schema(param_type)
                if schema:
                    is_required = param.default is inspect.Parameter.empty
                    p = {
                        'name': name,
                        'in': 'query',
                        'required': is_required,
                        'schema': schema,
                    }
                    if param.default is not inspect.Parameter.empty:
                        p['schema']['default'] = param.default
                    params.append(p)
        except Exception:
            logger.debug("Non-critical operation failed", exc_info=True)
        
        return params
    
    def _annotated_metadata_to_openapi(self, name: str, metadata: Any, inner_type: Any, param: Any) -> Optional[Dict[str, Any]]:
        try:
            from kewe.application.depends import _ParamDependency, Query, Header, CookieParam, Path, Body, Form, File
            
            if isinstance(metadata, _ParamDependency):
                if isinstance(metadata, (Body, Form, File)):
                    return None

                location = 'query'
                if isinstance(metadata, (Header,)):
                    location = 'header'
                elif isinstance(metadata, (CookieParam,)):
                    location = 'cookie'
                elif isinstance(metadata, (Path,)):
                    location = 'path'
                
                schema = self._type_to_schema(inner_type)
                if schema:
                    is_required = True
                    if hasattr(metadata, 'required'):
                        is_required = metadata.required
                    elif hasattr(metadata, 'default'):
                        is_required = metadata.default is inspect.Parameter.empty or metadata.default is ...
                    elif param.default is not inspect.Parameter.empty:
                        is_required = False

                    p = {
                        'name': metadata.alias or name,
                        'in': location,
                        'required': is_required,
                        'schema': schema,
                    }
                    if hasattr(metadata, 'description') and metadata.description:
                        p['description'] = metadata.description
                    if hasattr(metadata, 'title') and metadata.title:
                        p['schema']['title'] = metadata.title
                    if hasattr(metadata, 'deprecated') and metadata.deprecated:
                        p['deprecated'] = True
                    if hasattr(metadata, 'example') and metadata.example is not None:
                        p['example'] = metadata.example
                    if hasattr(metadata, 'examples') and metadata.examples:
                        p['examples'] = metadata.examples
                    if hasattr(metadata, 'gt') and metadata.gt is not None:
                        p['schema']['exclusiveMinimum'] = metadata.gt
                    if hasattr(metadata, 'ge') and metadata.ge is not None:
                        p['schema']['minimum'] = metadata.ge
                    if hasattr(metadata, 'lt') and metadata.lt is not None:
                        p['schema']['exclusiveMaximum'] = metadata.lt
                    if hasattr(metadata, 'le') and metadata.le is not None:
                        p['schema']['maximum'] = metadata.le
                    if hasattr(metadata, 'min_length') and metadata.min_length is not None:
                        p['schema']['minLength'] = metadata.min_length
                    if hasattr(metadata, 'max_length') and metadata.max_length is not None:
                        p['schema']['maxLength'] = metadata.max_length
                    if hasattr(metadata, 'regex') and metadata.regex is not None:
                        p['schema']['pattern'] = metadata.regex
                    if hasattr(metadata, 'multiple_of') and metadata.multiple_of is not None:
                        p['schema']['multipleOf'] = metadata.multiple_of
                    return p
        except ImportError:
            pass
        return None
    
    def _param_default_to_openapi(self, name: str, param_dep: Any, param: Any) -> Optional[Dict[str, Any]]:
        try:
            from kewe.application.depends import _ParamDependency, Query, Header, CookieParam, Path, Body, Form, File
            
            if isinstance(param_dep, (Body, Form, File)):
                return None
            
            location = 'query'
            if isinstance(param_dep, (Header,)):
                location = 'header'
            elif isinstance(param_dep, (CookieParam,)):
                location = 'cookie'
            elif isinstance(param_dep, (Path,)):
                location = 'path'
            
            param_type = param.annotation if param.annotation is not inspect.Parameter.empty else str
            if param_type is inspect.Parameter.empty:
                param_type = str
            
            schema = self._type_to_schema(param_type)
            if not schema:
                schema = {'type': 'string'}
            
            is_required = True
            if hasattr(param_dep, 'default') and param_dep.default is not inspect.Parameter.empty and param_dep.default is not ...:
                is_required = False
                schema['default'] = param_dep.default
            
            p = {
                'name': getattr(param_dep, 'alias', None) or name,
                'in': location,
                'required': is_required,
                'schema': schema,
            }
            
            if hasattr(param_dep, 'description') and param_dep.description:
                p['description'] = param_dep.description
            if hasattr(param_dep, 'title') and param_dep.title:
                p['schema']['title'] = param_dep.title
            if hasattr(param_dep, 'deprecated') and param_dep.deprecated:
                p['deprecated'] = True
            if hasattr(param_dep, 'example') and param_dep.example is not None:
                p['example'] = param_dep.example
            if hasattr(param_dep, 'examples') and param_dep.examples:
                p['examples'] = param_dep.examples
            if hasattr(param_dep, 'gt') and param_dep.gt is not None:
                p['schema']['exclusiveMinimum'] = param_dep.gt
            if hasattr(param_dep, 'ge') and param_dep.ge is not None:
                p['schema']['minimum'] = param_dep.ge
            if hasattr(param_dep, 'lt') and param_dep.lt is not None:
                p['schema']['exclusiveMaximum'] = param_dep.lt
            if hasattr(param_dep, 'le') and param_dep.le is not None:
                p['schema']['maximum'] = param_dep.le
            if hasattr(param_dep, 'min_length') and param_dep.min_length is not None:
                p['schema']['minLength'] = param_dep.min_length
            if hasattr(param_dep, 'max_length') and param_dep.max_length is not None:
                p['schema']['maxLength'] = param_dep.max_length
            if hasattr(param_dep, 'regex') and param_dep.regex is not None:
                p['schema']['pattern'] = param_dep.regex
            if hasattr(param_dep, 'multiple_of') and param_dep.multiple_of is not None:
                p['schema']['multipleOf'] = param_dep.multiple_of
            
            return p
        except ImportError:
            return None
    
    def _is_depends(self, param_type) -> bool:
        try:
            from kewe.application.depends import Depends
            return isinstance(param_type, Depends)
        except ImportError:
            return False
    
    def _extract_depends_params(self, depends, params: List[Dict[str, Any]]):
        try:
            from kewe.application.depends import Depends, Query, Header, CookieParam, Path, Body, Form, File
            
            if not isinstance(depends, Depends):
                return
            
            dependency = depends.dependency
            if dependency is None:
                return
            
            if isinstance(dependency, (Query, Header, CookieParam, Path, Body, Form, File)):
                param_info = self._param_extractor_to_openapi(dependency)
                if param_info:
                    params.append(param_info)
            elif callable(dependency):
                try:
                    sig = inspect.signature(dependency)
                    type_hints = getattr(dependency, '__annotations__', {})
                    for name, param in sig.parameters.items():
                        if name in ('request', 'req', 'self', 'cls'):
                            continue
                        inner_type = type_hints.get(name)
                        if inner_type is None:
                            inner_type = param.annotation if param.annotation is not inspect.Parameter.empty else None
                        if inner_type and self._is_depends(inner_type):
                            self._extract_depends_params(inner_type, params)
                        elif inner_type:
                            schema = self._type_to_schema(inner_type)
                            if schema:
                                params.append({
                                    'name': name,
                                    'in': 'query',
                                    'required': param.default is inspect.Parameter.empty,
                                    'schema': schema,
                                })
                except Exception:
                    logger.debug("Non-critical operation failed", exc_info=True)
        except ImportError:
            pass
    
    def _param_extractor_to_openapi(self, extractor) -> Optional[Dict[str, Any]]:
        try:
            from kewe.application.depends import Query, Header, CookieParam, Path, Body, Form, File
            
            location_map = {
                Query: 'query',
                Header: 'header',
                CookieParam: 'cookie',
                Path: 'path',
            }
            
            if isinstance(extractor, (Body, Form, File)):
                return None
            
            location = location_map.get(type(extractor), 'query')
            schema = self._type_to_schema(extractor.convert_type) if hasattr(extractor, 'convert_type') else {'type': 'string'}
            
            name = getattr(extractor, 'alias', None) or getattr(extractor, 'key', '') or ''
            if not name:
                return None
            
            param = {
                'name': name,
                'in': location,
                'required': getattr(extractor, 'required', False),
                'schema': schema,
            }
            
            if hasattr(extractor, 'description') and extractor.description:
                param['description'] = extractor.description
            
            return param
        except Exception:
            return None
    
    def _extract_request_body(self, handler: Callable) -> Optional[Dict[str, Any]]:
        """Extract request body from function parameters"""
        try:
            from pydantic import BaseModel
        except ImportError:
            BaseModel = None

        try:
            from typing import get_origin, get_args, Annotated
        except ImportError:
            Annotated = None

        try:
            from kewe.application.depends import _ParamDependency
        except ImportError:
            _ParamDependency = None

        try:
            sig = inspect.signature(handler)
            try:
                type_hints = inspect.get_annotations(handler) if hasattr(inspect, 'get_annotations') else {}
            except Exception:
                type_hints = {}

            for name, param in sig.parameters.items():
                if name in ('request', 'req', 'self', 'cls'):
                    continue

                param_type = type_hints.get(name)
                if param_type is None:
                    param_type = param.annotation if param.annotation is not inspect.Parameter.empty else None

                if param_type is None:
                    if isinstance(param.default, _ParamDependency):
                        from kewe.application.depends import Body, Form, File
                        if isinstance(param.default, Body):
                            content_type = getattr(param.default, 'content_type', 'application/json')
                            media_type = content_type if content_type != 'application/json' else 'application/json'
                            schema = self._type_to_schema(getattr(param.default, 'annotation', None) or str) or {'type': 'object'}
                            return {
                                'required': True,
                                'content': {
                                    media_type: {
                                        'schema': schema
                                    }
                                }
                            }
                        elif isinstance(param.default, Form):
                            form_annotation = getattr(param.default, 'annotation', None) or str
                            schema = self._type_to_schema(form_annotation) or {'type': 'string'}
                            if schema.get('type') == 'object' and schema.get('properties'):
                                props = schema['properties']
                            else:
                                props = {name: schema}
                            return {
                                'required': True,
                                'content': {
                                    'application/x-www-form-urlencoded': {
                                        'schema': {'type': 'object', 'properties': props}
                                    }
                                }
                            }
                        elif isinstance(param.default, File):
                            file_name = getattr(param.default, 'name', None) or name or 'file'
                            return {
                                'required': True,
                                'content': {
                                    'multipart/form-data': {
                                        'schema': {'type': 'object', 'properties': {file_name: {'type': 'string', 'format': 'binary'}}}
                                    }
                                }
                            }
                    continue

                if Annotated is not None and get_origin(param_type) is Annotated:
                    args = get_args(param_type)
                    inner_type = args[0]
                    for metadata in args[1:]:
                        if isinstance(metadata, _ParamDependency):
                            from kewe.application.depends import Body, Form, File
                            if isinstance(metadata, Body):
                                schema = self._type_to_schema(inner_type) or {'type': 'object'}
                                return {
                                    'required': True,
                                    'content': {
                                        'application/json': {
                                            'schema': schema
                                        }
                                    }
                                }
                            elif isinstance(metadata, Form):
                                form_schema = self._type_to_schema(inner_type) or {'type': 'string'}
                                if form_schema.get('type') == 'object' and form_schema.get('properties'):
                                    form_props = form_schema['properties']
                                else:
                                    form_props = {name: form_schema}
                                return {
                                    'required': True,
                                    'content': {
                                        'application/x-www-form-urlencoded': {
                                            'schema': {'type': 'object', 'properties': form_props}
                                        }
                                    }
                                }
                            elif isinstance(metadata, File):
                                file_name = getattr(metadata, 'name', None) or name or 'file'
                                return {
                                    'required': True,
                                    'content': {
                                        'multipart/form-data': {
                                            'schema': {'type': 'object', 'properties': {file_name: {'type': 'string', 'format': 'binary'}}}
                                        }
                                    }
                                }

                if BaseModel is not None and isinstance(param_type, type) and issubclass(param_type, BaseModel):
                    schema = self._pydantic_to_schema(param_type)
                    return {
                        'required': True,
                        'content': {
                            'application/json': {
                                'schema': schema
                            }
                        }
                    }
        except Exception:
            logger.warning("OpenAPI request body extraction failed", exc_info=True)

        return None
    
    def _extract_response_schema(self, handler: Callable) -> Dict[str, Any]:
        try:
            type_hints = {}
            try:
                type_hints = inspect.get_annotations(handler) if hasattr(inspect, 'get_annotations') else {}
            except Exception:
                logger.debug("Non-critical operation failed", exc_info=True)

            return_type = type_hints.get('return')
            if return_type is None:
                return {}

            try:
                from typing import get_origin, get_args
                origin = get_origin(return_type)
                args = get_args(return_type)

                if origin is not None:
                    from pydantic import BaseModel
                    if origin is list or origin is List:
                        if args:
                            item_type = args[0]
                            if isinstance(item_type, type) and issubclass(item_type, BaseModel):
                                schema = self._pydantic_to_schema(item_type)
                                return {
                                    '200': {
                                        'description': _HTTP_STATUS_DESCRIPTIONS.get(200, 'OK'),
                                        'content': {
                                            'application/json': {
                                                'schema': {'type': 'array', 'items': schema}
                                            }
                                        }
                                    }
                                }
                            else:
                                items_schema = self._type_to_schema(item_type) or {}
                                return {
                                    '200': {
                                        'description': _HTTP_STATUS_DESCRIPTIONS.get(200, 'OK'),
                                        'content': {
                                            'application/json': {
                                                'schema': {'type': 'array', 'items': items_schema}
                                            }
                                        }
                                    }
                                }
            except ImportError:
                pass

            if isinstance(return_type, type):
                try:
                    from pydantic import BaseModel
                    if issubclass(return_type, BaseModel):
                        schema = self._pydantic_to_schema(return_type)
                        return {
                            '200': {
                                'description': _HTTP_STATUS_DESCRIPTIONS.get(200, 'OK'),
                                'content': {
                                    'application/json': {
                                        'schema': schema
                                    }
                                }
                            }
                        }
                except ImportError:
                    pass

            schema = self._type_to_schema(return_type)
            if schema:
                return {
                    '200': {
                        'description': _HTTP_STATUS_DESCRIPTIONS.get(200, 'OK'),
                        'content': {
                            'application/json': {
                                'schema': schema
                            }
                        }
                    }
                }

            return {}
        except Exception:
            logger.warning("OpenAPI response schema extraction failed", exc_info=True)
            return {}
    
    def _type_to_schema(self, type_hint) -> Optional[Dict[str, Any]]:
        """Convert Python type to OpenAPI Schema"""
        type_map = {
            int: {'type': 'integer'},
            float: {'type': 'number'},
            str: {'type': 'string'},
            bool: {'type': 'boolean'},
            list: {'type': 'array', 'items': {}},
            dict: {'type': 'object'},
            bytes: {'type': 'string', 'format': 'binary'},
            type(None): {},
        }

        if type_hint in type_map:
            return type_map[type_hint]

        import enum
        if isinstance(type_hint, type) and issubclass(type_hint, enum.Enum):
            values = [e.value for e in type_hint]
            base_type = type(values[0]) if values else str
            schema = self._type_to_schema(base_type) or {'type': 'string'}
            schema['enum'] = values
            schema['x-enum-name'] = type_hint.__name__
            return schema

        try:
            from typing import Literal, get_origin, get_args
            origin = get_origin(type_hint)
            if origin is Literal:
                args = get_args(type_hint)
                if not args:
                    return {'type': 'string'}
                base_type = type(args[0])
                if all(type(a) == base_type for a in args):
                    schema = self._type_to_schema(base_type) or {'type': 'string'}
                    schema['enum'] = list(args)
                    return schema
                return {'enum': list(args)}
        except ImportError:
            pass

        if isinstance(type_hint, type):
            if issubclass(type_hint, int):
                return {'type': 'integer'}
            if issubclass(type_hint, float):
                return {'type': 'number'}
            if issubclass(type_hint, str):
                return {'type': 'string'}
            if issubclass(type_hint, bool):
                return {'type': 'boolean'}
            if issubclass(type_hint, bytes):
                return {'type': 'string', 'format': 'binary'}
            try:
                from pydantic import BaseModel
                if issubclass(type_hint, BaseModel):
                    return self._pydantic_to_schema(type_hint)
            except ImportError:
                pass
            
            import dataclasses
            if dataclasses.is_dataclass(type_hint):
                return self._dataclass_to_schema(type_hint)
        
        try:
            from typing import get_origin, get_args, Annotated
            origin = get_origin(type_hint)
            args = get_args(type_hint)
            
            if origin is Annotated:
                inner_type = args[0] if args else str
                return self._type_to_schema(inner_type)

            if origin is list or origin is List:
                items = self._type_to_schema(args[0]) if args else {}
                return {'type': 'array', 'items': items}
            elif origin is dict or origin is Dict:
                if args and len(args) == 2:
                    val_schema = self._type_to_schema(args[1])
                    if val_schema:
                        return {'type': 'object', 'additionalProperties': val_schema}
                return {'type': 'object'}
            elif origin is Union:
                non_none_args = [a for a in args if a is not type(None)]
                has_none = type(None) in args
                if len(non_none_args) == 1:
                    schema = self._type_to_schema(non_none_args[0])
                    if schema:
                        if has_none:
                            if self.openapi_version.startswith('3.1'):
                                existing_type = schema.get('type')
                                if existing_type:
                                    schema['type'] = [existing_type, 'null']
                                else:
                                    schema['nullable'] = True
                            else:
                                schema['nullable'] = True
                    return schema
                elif len(non_none_args) > 1:
                    one_of = [self._type_to_schema(a) or {'type': 'string'} for a in non_none_args]
                    result = {'oneOf': one_of}
                    if has_none:
                        if self.openapi_version.startswith('3.1'):
                            result['oneOf'].append({'type': 'null'})
                        else:
                            result['nullable'] = True
                    return result
            elif origin is set or origin is frozenset:
                items = self._type_to_schema(args[0]) if args else {}
                return {'type': 'array', 'items': items, 'uniqueItems': True}
            elif origin is tuple:
                if args:
                    prefix_items = [self._type_to_schema(a) or {} for a in args]
                    if self.openapi_version.startswith('3.1'):
                        return {'type': 'array', 'prefixItems': prefix_items}
                    else:
                        return {'type': 'array', 'items': {'oneOf': prefix_items}} if len(prefix_items) > 1 else {'type': 'array', 'items': prefix_items[0] if prefix_items else {}}
                return {'type': 'array'}
        except Exception:
            logger.debug("Non-critical operation failed", exc_info=True)

        try:
            from datetime import datetime, date, time as time_type, timedelta
            if type_hint is datetime:
                return {'type': 'string', 'format': 'date-time'}
            if type_hint is date:
                return {'type': 'string', 'format': 'date'}
            if type_hint is time_type:
                return {'type': 'string', 'format': 'time'}
            if type_hint is timedelta:
                return {'type': 'number'}
        except Exception:
            logger.debug("Non-critical operation failed", exc_info=True)

        try:
            from uuid import UUID
            if type_hint is UUID:
                return {'type': 'string', 'format': 'uuid'}
        except Exception:
            logger.debug("Non-critical operation failed", exc_info=True)

        try:
            from decimal import Decimal
            if type_hint is Decimal:
                return {'type': 'string', 'format': 'decimal'}
        except Exception:
            logger.debug("Non-critical operation failed", exc_info=True)

        try:
            from ipaddress import IPv4Address, IPv6Address
            if type_hint is IPv4Address:
                return {'type': 'string', 'format': 'ipv4'}
            if type_hint is IPv6Address:
                return {'type': 'string', 'format': 'ipv6'}
        except Exception:
            logger.debug("Non-critical operation failed", exc_info=True)

        try:
            from pathlib import Path as PathType
            if type_hint is PathType:
                return {'type': 'string', 'format': 'uri'}
        except Exception:
            logger.debug("Non-critical operation failed", exc_info=True)

        return None
    
    def _dataclass_to_schema(self, cls) -> Dict[str, Any]:
        """Convert dataclass to OpenAPI Schema"""
        import dataclasses
        from typing import get_origin, get_args
        
        schema_name = cls.__name__
        properties = {}
        required = []
        
        for field in dataclasses.fields(cls):
            field_schema = self._type_to_schema(field.type) or {'type': 'string'}
            if field.default is dataclasses.MISSING and field.default_factory is dataclasses.MISSING:
                required.append(field.name)
            properties[field.name] = field_schema
        
        schema = {
            'type': 'object',
            'properties': properties,
        }
        if required:
            schema['required'] = required
        
        self.components['schemas'][schema_name] = schema
        return {'$ref': f'#/components/schemas/{schema_name}'}
    
    def _register_defs_recursive(self, defs: Dict[str, Any]):
        for def_name, def_schema in defs.items():
            if def_name not in self.components['schemas']:
                nested_defs = def_schema.pop('$defs', None)
                def_schema = self._rewrite_refs(def_schema)
                self.components['schemas'][def_name] = def_schema
                if nested_defs:
                    self._register_defs_recursive(nested_defs)

    def _pydantic_to_schema(self, model_type) -> Dict[str, Any]:
        try:
            schema = model_type.model_json_schema()
            schema_name = model_type.__name__
            defs = schema.pop('$defs', None)
            if defs:
                self._register_defs_recursive(defs)
                schema = self._rewrite_refs(schema)
            
            if hasattr(model_type, 'model_config'):
                json_schema_extra = model_type.model_config.get('json_schema_extra')
                if json_schema_extra:
                    if callable(json_schema_extra):
                        json_schema_extra(schema)
                    elif isinstance(json_schema_extra, dict):
                        schema.update(json_schema_extra)
            
            if 'examples' not in schema:
                examples = []
                for field_name, field_info in model_type.model_fields.items():
                    if hasattr(field_info, 'json_schema_extra') and field_info.json_schema_extra:
                        if isinstance(field_info.json_schema_extra, dict):
                            if 'examples' in field_info.json_schema_extra:
                                examples.append(field_info.json_schema_extra['examples'])
                if examples:
                    schema['examples'] = examples
            
            self.components['schemas'][schema_name] = schema
            return {'$ref': f'#/components/schemas/{schema_name}'}
        except Exception:
            return {'type': 'object'}

    @staticmethod
    def _rewrite_refs(obj):
        if isinstance(obj, dict):
            result = {}
            for k, v in obj.items():
                if k == '$ref' and isinstance(v, str) and v.startswith('#/$defs/'):
                    result[k] = v.replace('#/$defs/', '#/components/schemas/')
                else:
                    result[k] = OpenAPIPlugin._rewrite_refs(v)
            return result
        elif isinstance(obj, list):
            return [OpenAPIPlugin._rewrite_refs(item) for item in obj]
        return obj
    
    def generate_spec(self) -> Dict[str, Any]:
        """生成OpenAPI规范（带缓存）"""
        if not self._spec_dirty and self._spec_cache is not None:
            return self._spec_cache

        info = {
            'title': self.title,
            'version': self.version,
            'description': self.description,
        }
        if self.contact:
            info['contact'] = self.contact
        if self.license:
            info['license'] = self.license
        if self.terms_of_service:
            info['termsOfService'] = self.terms_of_service

        spec = {
            'openapi': self.openapi_version,
            'info': info,
            'paths': self.paths,
        }

        non_empty_components = {k: v for k, v in self.components.items() if v}
        if non_empty_components:
            spec['components'] = non_empty_components
        
        if self.servers:
            spec['servers'] = self.servers
        if self.security:
            spec['security'] = self.security
        if self.tags:
            spec['tags'] = self.tags
        if self.webhooks:
            spec['webhooks'] = self.webhooks
        if self.external_docs:
            spec['externalDocs'] = self.external_docs
        
        self._spec_cache = spec
        self._spec_dirty = False
        return spec
    
    def _auto_register_security_schemes(self, app):
        try:
            from kewe.security.jwt import JWTAuthManager
            if 'BearerAuth' not in self.components['securitySchemes']:
                self.components['securitySchemes']['BearerAuth'] = {
                    'type': 'http',
                    'scheme': 'bearer',
                    'bearerFormat': 'JWT',
                }
        except ImportError:
            pass

        try:
            from kewe.security.auth import APIKeyAuthenticator
            if 'APIKeyHeader' not in self.components['securitySchemes']:
                self.components['securitySchemes']['APIKeyHeader'] = {
                    'type': 'apiKey',
                    'in': 'header',
                    'name': 'X-API-Key',
                }
        except ImportError:
            pass

        try:
            from kewe.security.csrf import CSRFProtection
            if 'CSRFToken' not in self.components['securitySchemes']:
                self.components['securitySchemes']['CSRFToken'] = {
                    'type': 'apiKey',
                    'in': 'header',
                    'name': 'X-CSRF-Token',
                }
        except ImportError:
            pass

        try:
            from kewe.security.auth import OAuth2Authenticator
            if 'OAuth2' not in self.components['securitySchemes']:
                self.components['securitySchemes']['OAuth2'] = {
                    'type': 'oauth2',
                    'flows': {
                        'authorizationCode': {
                            'authorizationUrl': '/oauth/authorize',
                            'tokenUrl': '/oauth/token',
                            'scopes': {
                                'read': 'Read access',
                                'write': 'Write access',
                            },
                        },
                        'clientCredentials': {
                            'tokenUrl': '/oauth/token',
                            'scopes': {
                                'read': 'Read access',
                                'write': 'Write access',
                            },
                        },
                    },
                }
        except ImportError:
            pass

    def add_schema(self, name: str, schema: Dict[str, Any]):
        """添加Schema"""
        self.components['schemas'][name] = schema
        self._spec_dirty = True
    
    def add_security_scheme(self, name: str, type: str = None, scheme: str = None, **kwargs):
        """添加安全方案

        Args:
            name: 方案名称
            type: 安全方案类型 (http, apiKey, oauth2, openIdConnect)
            scheme: HTTP认证方案 (如 bearer, basic)
            **kwargs: 其他属性 (如 bearerFormat, in_, name, flows 等)
        """
        if isinstance(type, dict):
            self.components['securitySchemes'][name] = type
        else:
            sec_scheme = {}
            if type:
                sec_scheme['type'] = type
            if scheme:
                sec_scheme['scheme'] = scheme
            sec_scheme.update(kwargs)
            self.components['securitySchemes'][name] = sec_scheme
        self._spec_dirty = True

    def add_path(self, path: str, method: str, operation: Dict[str, Any]):
        """添加路径操作

        Args:
            path: URL路径
            method: HTTP方法 (get, post, put, delete, patch)
            operation: 操作定义
        """
        if path not in self.paths:
            self.paths[path] = {}
        self.paths[path][method.lower()] = operation
        self._spec_dirty = True
    
    def add_tag(self, tag: Dict[str, Any]):
        """添加标签"""
        self.tags.append(tag)
        self._spec_dirty = True
    
    def add_server(self, server: Dict[str, Any]):
        """添加服务器"""
        self.servers.append(server)
        self._spec_dirty = True

    def add_webhook(self, name: str, webhook: Dict[str, Any]):
        """添加Webhook"""
        self.webhooks[name] = webhook
        self._spec_dirty = True

    def add_callback(self, name: str, callback: Dict[str, Any]):
        """添加Callback"""
        self.components['callbacks'][name] = callback
        self._spec_dirty = True

    def add_link(self, name: str, link: Dict[str, Any]):
        """添加Link"""
        self.components['links'][name] = link
        self._spec_dirty = True

    def add_example(self, name: str, example: Dict[str, Any]):
        """添加Example"""
        self.components['examples'][name] = example
        self._spec_dirty = True

    def add_response_component(self, name: str, response: Dict[str, Any]):
        """添加响应组件"""
        self.components['responses'][name] = response
        self._spec_dirty = True

    def add_parameter_component(self, name: str, parameter: Dict[str, Any]):
        """添加参数组件"""
        self.components['parameters'][name] = parameter
        self._spec_dirty = True

    def add_request_body_component(self, name: str, request_body: Dict[str, Any]):
        """添加请求体组件"""
        self.components['requestBodies'][name] = request_body
        self._spec_dirty = True

    def add_header_component(self, name: str, header: Dict[str, Any]):
        """添加头部组件"""
        self.components['headers'][name] = header
        self._spec_dirty = True

    def set_external_docs(self, url: str, description: str = ""):
        """设置外部文档"""
        self.external_docs = {'url': url}
        if description:
            self.external_docs['description'] = description
        self._spec_dirty = True


def schema(name: str, **kwargs) -> Dict[str, Any]:
    """创建Schema"""
    return {
        'type': 'object',
        'properties': kwargs
    }

def parameter(name: str, in_: str, schema: Dict[str, Any], required: bool = False, description: str = "") -> Dict[str, Any]:
    """创建参数"""
    return {
        'name': name,
        'in': in_,
        'schema': schema,
        'required': required,
        'description': description
    }

def response(status: str, description: str, schema: Dict[str, Any] = None) -> Dict[str, Any]:
    """创建响应"""
    resp = {
        'description': description
    }
    if schema:
        resp['content'] = {
            'application/json': {
                'schema': schema
            }
        }
    return resp

def request_body(description: str, schema: Dict[str, Any], required: bool = True) -> Dict[str, Any]:
    """创建请求体"""
    return {
        'description': description,
        'required': required,
        'content': {
            'application/json': {
                'schema': schema
            }
        }
    }


class openapi_decorator:
    """
    OpenAPI Decorator - provides decorator API
    
    Usage:
        from kewe.plugins.openapi import openapi
        
        @app.get("/users/<id:int>")
        @openapi.summary("Get user by ID")
        @openapi.description("Returns a single user object")
        @openapi.response(200, {"application/json": UserSchema})
        @openapi.parameter("id", "path", {"type": "integer"}, required=True)
        async def get_user(request, id):
            ...
    """
    
    def __init__(self):
        self._info = {}
    
    def summary(self, text: str):
        """设置 API 摘要"""
        def decorator(func):
            if not hasattr(func, '_openapi'):
                func._openapi = {}
            func._openapi['summary'] = text
            return func
        return decorator
    
    def description(self, text: str):
        """设置 API 描述"""
        def decorator(func):
            if not hasattr(func, '_openapi'):
                func._openapi = {}
            func._openapi['description'] = text
            return func
        return decorator
    
    def tag(self, name: str, description: str = ""):
        """设置 API 标签"""
        def decorator(func):
            if not hasattr(func, '_openapi'):
                func._openapi = {}
            if 'tags' not in func._openapi:
                func._openapi['tags'] = []
            func._openapi['tags'].append(name)
            return func
        return decorator
    
    def parameter(self, name: str, in_: str, schema: Dict[str, Any], 
                  required: bool = False, description: str = "", deprecated: bool = False):
        """添加参数"""
        def decorator(func):
            if not hasattr(func, '_openapi'):
                func._openapi = {}
            if 'parameters' not in func._openapi:
                func._openapi['parameters'] = []
            func._openapi['parameters'].append({
                'name': name,
                'in': in_,
                'schema': schema,
                'required': required,
                'description': description,
                'deprecated': deprecated
            })
            return func
        return decorator
    
    def body(self, description: str, schema: Dict[str, Any], required: bool = True,
            content_type: str = "application/json"):
        """设置请求体"""
        def decorator(func):
            if not hasattr(func, '_openapi'):
                func._openapi = {}
            func._openapi['requestBody'] = {
                'description': description,
                'required': required,
                'content': {
                    content_type: {
                        'schema': schema
                    }
                }
            }
            return func
        return decorator
    
    def response(self, status: Union[int, str], description: str = "", 
                 content: Dict[str, Any] = None, headers: Dict[str, Any] = None):
        """添加响应"""
        def decorator(func):
            if not hasattr(func, '_openapi'):
                func._openapi = {}
            if 'responses' not in func._openapi:
                func._openapi['responses'] = {}
            
            status_str = str(status)
            response_obj = {'description': description}
            
            if content:
                response_obj['content'] = content
            if headers:
                response_obj['headers'] = headers
            
            func._openapi['responses'][status_str] = response_obj
            return func
        return decorator
    
    def deprecated(self, is_deprecated: bool = True):
        """标记为已弃用"""
        def decorator(func):
            if not hasattr(func, '_openapi'):
                func._openapi = {}
            func._openapi['deprecated'] = is_deprecated
            return func
        return decorator
    
    def security(self, name: str, scopes: List[str] = None):
        """设置安全要求"""
        def decorator(func):
            if not hasattr(func, '_openapi'):
                func._openapi = {}
            if 'security' not in func._openapi:
                func._openapi['security'] = []
            func._openapi['security'].append({name: scopes or []})
            return func
        return decorator
    
    def exclude(self, exclude: bool = True):
        """从文档中排除"""
        def decorator(func):
            if not hasattr(func, '_openapi'):
                func._openapi = {}
            func._openapi['exclude'] = exclude
            return func
        return decorator


class _OpenAPIFactory(openapi_decorator):
    
    def __call__(self, title: str = None, version: str = "1.0.0", **config):
        if title:
            config['title'] = title
        config['version'] = version
        return OpenAPIPlugin, config


openapi = _OpenAPIFactory()

_global_openapi_plugin: Optional[OpenAPIPlugin] = None


def get_openapi_plugin(app=None) -> Optional[OpenAPIPlugin]:
    if app is not None and hasattr(app, '_openapi_plugin'):
        return app._openapi_plugin
    return _global_openapi_plugin


def set_openapi_plugin(plugin: OpenAPIPlugin, app=None):
    global _global_openapi_plugin
    _global_openapi_plugin = plugin
    if app is not None:
        app._openapi_plugin = plugin


__all__ = [
    'OpenAPIPlugin',
    'openapi',
    'openapi_decorator',
    'schema',
    'parameter',
    'response',
    'request_body',
    'get_openapi_plugin',
    'set_openapi_plugin',
]
