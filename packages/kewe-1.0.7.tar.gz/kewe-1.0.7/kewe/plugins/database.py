#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.plugins.database - Database plugins for SQLAlchemy and Redis integration
"""

from kewe.plugins.base import Plugin, PluginManager
from typing import Dict, Any, Optional, List, Union
import asyncio
import logging

from kewe import __version__

logger = logging.getLogger(__name__)


class DatabasePlugin(Plugin):
    """数据库插件基类"""
    
    name = "database"
    version = __version__
    
    def setup(self, app, **config):
        self.config = config
        self._connections = {}
        self._pool = None
        app.db = self
        
        if hasattr(app, 'plugins') and isinstance(app.plugins, PluginManager):
            app.plugins.add_hook('before_server_start', self.connect)
            app.plugins.add_hook('after_server_stop', self.disconnect)
        else:
            if hasattr(app, 'before_server_start'):
                app.before_server_start(self.connect)
            if hasattr(app, 'after_server_stop'):
                app.after_server_stop(self.disconnect)
    
    async def connect(self, app=None):
        """连接数据库 - 子类应重写此方法"""
        logger.info(f"DatabasePlugin '{self.name}' connect called")
    
    async def disconnect(self, app=None):
        """断开数据库连接 - 子类应重写此方法"""
        for name, conn in self._connections.items():
            try:
                if hasattr(conn, 'close'):
                    if asyncio.iscoroutinefunction(conn.close):
                        await conn.close()
                    else:
                        conn.close()
            except Exception as e:
                logger.error(f"Error closing connection '{name}': {e}")
        self._connections.clear()
        logger.info(f"DatabasePlugin '{self.name}' disconnected")
    
    def get_connection(self, name: str = "default"):
        """获取数据库连接"""
        return self._connections.get(name)
    
    @property
    def is_connected(self) -> bool:
        """检查是否已连接"""
        return bool(self._connections)


class RedisPlugin(Plugin):
    """
    Redis缓存插件
    
    使用 redis-py 7.4+ 作为驱动
    
    新特性：
    - HGETDEL, HGETEX, HSETEX 命令
    - 改进的异步客户端安全性
    - 更好的连接池管理
    """
    
    name = "redis"
    version = __version__
    
    def setup(self, app, **config):
        self.config = config
        self._connections = {}
        self.url = config.get('url', 'redis://localhost:6379/0')
        
        app.redis = self
        
        if hasattr(app, 'plugins') and isinstance(app.plugins, PluginManager):
            app.plugins.add_hook('before_server_start', self.connect)
            app.plugins.add_hook('after_server_stop', self.disconnect)
        else:
            if hasattr(app, 'before_server_start'):
                app.before_server_start(self.connect)
            if hasattr(app, 'after_server_stop'):
                app.after_server_stop(self.disconnect)
    
    async def connect(self, app=None):
        """连接Redis"""
        try:
            import redis.asyncio as redis
            
            self.client = redis.from_url(
                self.url,
                decode_responses=True,
                max_connections=self.config.get('max_connections', 50),
                retry_on_timeout=self.config.get('retry_on_timeout', True),
                socket_keepalive=self.config.get('socket_keepalive', True),
            )
            await self.client.ping()
            logger.info("Connected to Redis (redis-py 7.4+)")
        except ImportError:
            logger.error("redis is not installed. Please install it with 'pip install redis'")
        except Exception as e:
            logger.error(f"Failed to connect to Redis: {e}")
    
    async def disconnect(self, app=None):
        """断开Redis连接"""
        if hasattr(self, 'client') and self.client:
            await self.client.close()
        self._connections.clear()
        logger.info("Disconnected from Redis")
    
    async def set(self, key: str, value: Any, ttl: Optional[int] = None):
        """设置键值对"""
        if ttl:
            await self.client.setex(key, ttl, value)
        else:
            await self.client.set(key, value)
    
    async def get(self, key: str) -> Optional[str]:
        """获取值"""
        return await self.client.get(key)
    
    async def delete(self, key: str):
        """删除键"""
        await self.client.delete(key)
    
    async def exists(self, key: str) -> bool:
        """检查键是否存在"""
        return await self.client.exists(key) > 0
    
    async def incr(self, key: str) -> int:
        """递增计数器"""
        return await self.client.incr(key)
    
    async def decr(self, key: str) -> int:
        """递减计数器"""
        return await self.client.decr(key)
    
    async def hset(self, name: str, key: str, value: Any):
        """设置哈希字段"""
        await self.client.hset(name, key, value)
    
    async def hget(self, name: str, key: str) -> Optional[str]:
        """获取哈希字段"""
        return await self.client.hget(name, key)
    
    async def hgetall(self, name: str) -> Dict[str, str]:
        """获取所有哈希字段"""
        return await self.client.hgetall(name)
    
    async def hdel(self, name: str, *keys: str) -> int:
        """删除哈希字段"""
        return await self.client.hdel(name, *keys)
    
    async def hgetdel(self, name: str, *keys: str) -> List[str]:
        """
        获取并删除哈希字段 (Redis 7.4+)
        
        Returns:
            被删除字段的值列表
        """
        return await self.client.hgetdel(name, *keys)
    
    async def hgetex(
        self,
        name: str,
        *keys: str,
        ttl: Optional[int] = None,
        persist: bool = False
    ) -> List[str]:
        """
        获取哈希字段并设置过期时间 (Redis 7.4+)
        
        Args:
            name: 哈希名
            keys: 字段列表
            ttl: 过期时间（秒）
            persist: 是否持久化
            
        Returns:
            字段值列表
        """
        return await self.client.hgetex(name, *keys, expire=ttl, persist=persist)
    
    async def hsetex(
        self,
        name: str,
        key: str,
        value: Any,
        ttl: Optional[int] = None
    ):
        """
        设置哈希字段并设置过期时间 (Redis 7.4+)
        
        Args:
            name: 哈希名
            key: 字段名
            value: 值
            ttl: 过期时间（秒）
        """
        await self.client.hsetex(name, key, value, expire=ttl)
    
    async def lpush(self, name: str, *values):
        """列表左侧插入"""
        return await self.client.lpush(name, *values)
    
    async def rpush(self, name: str, *values):
        """列表右侧插入"""
        return await self.client.rpush(name, *values)
    
    async def lpop(self, name: str) -> Optional[str]:
        """列表左侧弹出"""
        return await self.client.lpop(name)
    
    async def rpop(self, name: str) -> Optional[str]:
        """列表右侧弹出"""
        return await self.client.rpop(name)
    
    async def lrange(self, name: str, start: int = 0, end: int = -1) -> list:
        """获取列表范围"""
        return await self.client.lrange(name, start, end)
    
    async def publish(self, channel: str, message: str):
        """发布消息"""
        return await self.client.publish(channel, message)
    
    async def subscribe(self, *channels):
        """订阅频道"""
        pubsub = self.client.pubsub()
        await pubsub.subscribe(*channels)
        return pubsub
    
    async def json_get(self, name: str, path: str = "$") -> Any:
        """获取JSON值 (RedisJSON)"""
        return await self.client.json().get(name, path)
    
    async def json_set(self, name: str, path: str, value: Any):
        """设置JSON值 (RedisJSON)"""
        return await self.client.json().set(name, path, value)
    
    async def json_delete(self, name: str, path: str = "$"):
        """删除JSON值 (RedisJSON)"""
        return await self.client.json().delete(name, path)
    
    async def acquire_lock(
        self,
        name: str,
        timeout: int = 10,
        blocking_timeout: Optional[float] = None
    ) -> Any:
        lock = self.client.lock(name, timeout=timeout)
        acquired = await lock.acquire(blocking_timeout=blocking_timeout)
        if acquired:
            if not hasattr(self, '_locks'):
                self._locks: Dict[str, Any] = {}
            self._locks[name] = lock
        return acquired
    
    async def release_lock(self, name: str):
        if hasattr(self, '_locks') and name in self._locks:
            lock = self._locks.pop(name)
            try:
                await lock.release()
            except Exception as e:
                logger.error(f"Failed to release lock '{name}': {e}")


def redis(url: str = 'redis://localhost:6379/0', **config):
    """创建Redis插件"""
    config['url'] = url
    return RedisPlugin, config


__all__ = [
    'DatabasePlugin',
    'RedisPlugin',
    'SQLAlchemyPlugin',
    'get_db_session',
    'redis',
    'sqlalchemy',
    'initialize_database',
]


class SQLAlchemyPlugin(DatabasePlugin):
    """
    SQLAlchemy 异步 ORM 插件 - 数据库集成模块
    
    支持:
    - 异步会话管理
    - 每请求会话生命周期
    - 事务管理
    - 依赖注入集成
    - 自动集成kewe.database.Model基类
    - 查询构建器支持
    
    使用示例:
        from kewe.plugins.database import SQLAlchemyPlugin, get_db_session
        
        db = SQLAlchemyPlugin("postgresql+asyncpg://user:pass@localhost/db")
        app.use(db)
        
        @app.get("/users")
        async def get_users(session = Depends(get_db_session)):
            result = await session.execute(select(User))
            return result.scalars().all()
    """
    
    name = "sqlalchemy"
    version = __version__
    
    def __init__(self, database_url: str = None, **kwargs):
        self._database_url = database_url
        self._engine_kwargs = kwargs
        self._engine = None
        self._session_factory = None
        self._base = None
    
    def setup(self, app, **config):
        super().setup(app, **config)
        if self._database_url is None:
            self._database_url = config.get('url') or config.get('dsn')
        if self._database_url is None:
            raise ValueError("SQLAlchemy database URL is required")
        
        self._engine_kwargs.update(config.get('engine_kwargs', {}))
        
        app.db = self

        try:
            from kewe.database.models import get_declarative_base, get_global_base
            self._base = get_global_base() or get_declarative_base("KeweBase")
        except ImportError:
            logger.warning("Database models import failed", exc_info=True)
        
        app.middleware('onion')(self._session_middleware)
        
        if hasattr(app, 'before_server_start'):
            app.before_server_start(self.connect)
        if hasattr(app, 'after_server_stop'):
            app.after_server_stop(self.disconnect)
    
    async def connect(self, app=None):
        try:
            from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
            try:
                from sqlalchemy.ext.asyncio import async_sessionmaker
                session_factory_cls = async_sessionmaker
            except ImportError:
                from sqlalchemy.orm import sessionmaker
                session_factory_cls = sessionmaker
            
            default_pool_config = {
                "pool_size": 5,
                "max_overflow": 10,
                "pool_recycle": 3600,
                "pool_pre_ping": True,
            }
            for k, v in default_pool_config.items():
                if k not in self._engine_kwargs:
                    self._engine_kwargs[k] = v

            self._engine = create_async_engine(
                self._database_url,
                **self._engine_kwargs
            )
            
            self._session_factory = session_factory_cls(
                self._engine,
                class_=AsyncSession,
                expire_on_commit=False,
            )
            
            self._connections['default'] = self._engine
            logger.info(f"Connected to SQLAlchemy database: {self._database_url.split('@')[-1] if '@' in self._database_url else self._database_url}")
        except ImportError:
            logger.error("SQLAlchemy is not installed. Please install it with 'pip install sqlalchemy[asyncio]'")
        except Exception as e:
            logger.error(f"Failed to connect to SQLAlchemy database: {e}")
    
    async def disconnect(self, app=None):
        if self._engine:
            await self._engine.dispose()
        self._connections.clear()
        logger.info("Disconnected from SQLAlchemy database")
    
    @property
    def engine(self):
        return self._engine
    
    @property
    def session_factory(self):
        return self._session_factory
    
    def create_session(self):
        if self._session_factory is None:
            raise RuntimeError("SQLAlchemy not connected. Call connect() first.")
        return self._session_factory()
    
    async def _session_middleware(self, request, call_next):
        if self._session_factory is None:
            return await call_next(request)
        
        session = self._session_factory()
        if hasattr(request, 'state'):
            request.state.db_session = session
        if hasattr(request, 'ctx'):
            request.ctx.db_session = session
        
        response = None
        try:
            response = await call_next(request)
            await session.commit()

            if response is not None and hasattr(response, 'background') and response.background is not None:
                original_run = response.background.run

                async def _run_with_session_cleanup():
                    try:
                        await original_run()
                    finally:
                        await session.close()

                response.background.run = _run_with_session_cleanup
                return response

            return response
        except Exception:
            await session.rollback()
            raise
        finally:
            if response is None or not hasattr(response, 'background') or response.background is None:
                await session.close()
    
    async def create_tables(self):
        if self._engine and self._base:
            async with self._engine.begin() as conn:
                await conn.run_sync(self._base.metadata.create_all)
    
    def set_base(self, base):
        self._base = base

    def query(self, model, request=None):
        try:
            from kewe.database.query import QueryBuilder
            if request is not None:
                session = get_db_session(request)
            else:
                session = self.create_session()
            qb = QueryBuilder(model, session)
            qb._owned_session = request is None
            return qb
        except ImportError:
            raise ImportError(
                "QueryBuilder requires kewe.database.query. "
                "Make sure kewe.database module is available."
            )

    @property
    def migrate(self):
        if not hasattr(self, '_alembic_manager'):
            try:
                from kewe.database.alembic import AlembicManager
                self._alembic_manager = AlembicManager(database_url=self._database_url)
            except ImportError:
                return None
        return self._alembic_manager


def get_db_session(request):
    """
    获取当前请求的数据库会话 - 用于Depends依赖注入
    
    使用示例:
        from kewe.plugins.database import get_db_session
        from kewe.application.depends import Depends
        
        @app.get("/users")
        async def get_users(session = Depends(get_db_session)):
            from sqlalchemy import select
            result = await session.execute(select(User))
            return result.scalars().all()
    """
    session = None
    if hasattr(request, 'state') and hasattr(request.state, 'db_session'):
        session = request.state.db_session
    if session is None and hasattr(request, 'ctx') and hasattr(request.ctx, 'db_session'):
        session = request.ctx.db_session
    if session is None:
        raise RuntimeError(
            "Database session not available. "
            "Make sure SQLAlchemyPlugin is configured with app.middleware()."
        )
    return session


def sqlalchemy(url: str, **config):
    config['url'] = url
    return SQLAlchemyPlugin, config


def initialize_database(app, database_url: str, **engine_kwargs):
    from kewe.database.models import get_declarative_base, get_global_base
    plugin = SQLAlchemyPlugin(database_url, **engine_kwargs)
    plugin.set_base(get_global_base() or get_declarative_base("KeweBase"))
    plugin.setup(app)
    return plugin
