#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.plugins.base - Plugin base classes with lifecycle hooks
"""

from abc import ABC, abstractmethod
from typing import Dict, List, Any, Optional, Callable
import inspect
import asyncio
import threading
import logging

logger = logging.getLogger(__name__)


class Plugin(ABC):
    """
    插件基类
    
    所有插件必须继承此类
    """
    
    name: str = "base"
    version: str = "0.0.0"
    dependencies: List[str] = []
    
    def __init__(self, app=None):
        self.app = app
        self.config: Dict[str, Any] = {}
        self.initialized = False
        self.dependencies = list(self.dependencies)
    
    @abstractmethod
    def setup(self, app, **config):
        """
        设置插件
        
        Args:
            app: 应用实例
            **config: 配置参数
        """
        pass
    
    def register(self, app, **config):
        """注册插件到应用"""
        self.app = app
        self.config.update(config)
        
        self._check_dependencies(app)
        
        self.setup(app, **config)
        self.initialized = True
        
        if hasattr(app, '_register_plugin'):
            app._register_plugin(self)
        
        app_logger = getattr(app, 'logger', None) or getattr(app, '_logger', None)
        if app_logger:
            app_logger.info(f"Plugin '{self.name}' v{self.version} registered")
        else:
            logger.info(f"Plugin '{self.name}' v{self.version} registered")
    
    def _check_dependencies(self, app):
        """检查插件依赖"""
        plugin_manager = getattr(app, 'plugins', None)
        if plugin_manager and isinstance(plugin_manager, PluginManager):
            for dep in self.dependencies:
                if dep not in plugin_manager.list_plugins():
                    raise ValueError(f"Plugin '{self.name}' depends on '{dep}', which is not registered")
    
    def teardown(self):
        """卸载插件"""
        if self.initialized:
            self.cleanup()
            self.initialized = False
            logger.info(f"Plugin '{self.name}' v{self.version} teardown")

    def cleanup(self):
        """清理插件资源 - 子类应重写此方法释放数据库连接、后台线程等"""
        pass
    
    def on_event(self, event: str, handler: Callable):
        """注册事件处理器到插件管理器"""
        plugin_manager = getattr(self.app, 'plugins', None)
        if plugin_manager and isinstance(plugin_manager, PluginManager):
            plugin_manager.add_hook(event, handler)
    
    def get_info(self) -> Dict[str, Any]:
        """获取插件信息"""
        return {
            "name": self.name,
            "version": self.version,
            "dependencies": self.dependencies,
            "initialized": self.initialized,
        }


class PluginManager:
    """插件管理器"""
    
    def __init__(self, app=None):
        self.app = app
        self._plugins: Dict[str, Plugin] = {}
        self._hooks: Dict[str, List[Callable]] = {
            'before_server_start': [],
            'after_server_start': [],
            'before_server_stop': [],
            'after_server_stop': [],
            'before_request': [],
            'after_request': [],
            'request_exception': [],
            'server_exception': [],
        }
        self._event_handlers: Dict[str, List[Callable]] = {}
        self._pending_tasks: set = set()
        self._lock = threading.Lock()
    
    def register(self, plugin: Plugin, **config):
        """注册插件"""
        with self._lock:
            if plugin.name in self._plugins:
                raise ValueError(f"Plugin '{plugin.name}' is already registered")
            self._plugins[plugin.name] = plugin
        plugin.register(self.app, **config)
    
    def unregister(self, name: str):
        """卸载插件"""
        with self._lock:
            if name in self._plugins:
                plugin = self._plugins.pop(name)
            else:
                return
        plugin.teardown()
    
    def get(self, name: str) -> Optional[Plugin]:
        """获取插件"""
        with self._lock:
            return self._plugins.get(name)
    
    def list_plugins(self) -> List[str]:
        """列出所有已注册插件"""
        with self._lock:
            return list(self._plugins.keys())
    
    def add_hook(self, event: str, handler: Callable):
        """添加钩子函数"""
        with self._lock:
            if event not in self._hooks:
                self._hooks[event] = []
            self._hooks[event].append(handler)
    
    def remove_hook(self, event: str, handler: Callable):
        """移除钩子函数"""
        with self._lock:
            if event in self._hooks and handler in self._hooks[event]:
                self._hooks[event].remove(handler)
    
    async def run_hooks(self, event: str, *args, **kwargs):
        """运行钩子函数，返回非 None 结果列表"""
        results = []
        with self._lock:
            handlers = list(self._hooks.get(event, []))
        for handler in handlers:
            try:
                if inspect.iscoroutinefunction(handler):
                    result = await handler(*args, **kwargs)
                else:
                    result = handler(*args, **kwargs)
                if result is not None:
                    results.append(result)
                if event.startswith('before_') and result is not None:
                    break
            except Exception as e:
                logger.error(f"Error in {event} hook: {e}")
                if event.startswith('before_'):
                    raise
        return results
    
    def emit_event(self, event: str, *args, **kwargs):
        handlers = self._event_handlers.get(event, [])
        for handler in handlers:
            try:
                if inspect.iscoroutinefunction(handler):
                    try:
                        loop = asyncio.get_running_loop()
                        task = loop.create_task(handler(*args, **kwargs))
                        self._pending_tasks.add(task)
                        task.add_done_callback(self._pending_tasks.discard)
                    except RuntimeError:
                        logger.warning(f"No event loop, skipping async handler for event: {event}")
                else:
                    handler(*args, **kwargs)
            except Exception as e:
                logger.error(f"Error in {event} event handler: {e}")
    
    def on(self, event: str, handler: Callable):
        """注册事件处理器"""
        if event not in self._event_handlers:
            self._event_handlers[event] = []
        self._event_handlers[event].append(handler)


class Extension:
    """扩展装饰器 - 框架扩展"""
    
    def __init__(self, app=None):
        self.app = app
        if app is not None:
            self.init_app(app)
    
    def init_app(self, app):
        """初始化应用到扩展"""
        self.app = app


class MiddlewareExtension(Extension):
    """中间件扩展基类"""
    
    def init_app(self, app):
        super().init_app(app)
        if hasattr(self, 'process_request'):
            app.middleware('request')(self.process_request)
        if hasattr(self, 'process_response'):
            app.middleware('response')(self.process_response)
        if hasattr(self, 'process_exception'):
            app.middleware('exception')(self.process_exception)


class RouteExtension(Extension):
    """路由扩展基类"""
    
    def init_app(self, app):
        super().init_app(app)
        if hasattr(self, 'routes'):
            for route in self.routes:
                app.route(**route)


class BlueprintExtension(Extension):
    """蓝图扩展基类"""
    
    def init_app(self, app):
        super().init_app(app)
        if hasattr(self, 'blueprints'):
            for blueprint in self.blueprints:
                app.register_blueprint(blueprint)


def register_plugin(app, plugin_class, **config):
    """注册插件的便捷函数"""
    plugin = plugin_class()
    plugin.register(app, **config)
    return plugin


__all__ = [
    'Plugin',
    'PluginManager',
    'Extension',
    'MiddlewareExtension',
    'RouteExtension',
    'BlueprintExtension',
    'register_plugin',
]
