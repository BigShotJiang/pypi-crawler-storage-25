#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.plugins - Plugins package initialization
"""

from .base import (
    Plugin,
    PluginManager,
    Extension,
    MiddlewareExtension,
    RouteExtension,
    BlueprintExtension,
    register_plugin,
)

from .database import (
    DatabasePlugin,
    SQLAlchemyPlugin,
    get_db_session,
    RedisPlugin,
    redis,
)

from .openapi import (
    OpenAPIPlugin,
    openapi,
    schema,
    parameter,
    response,
    request_body,
)

from .builtin import (
    CORSPlugin,
    CompressionPlugin,
    RateLimitPlugin,
    SecurityPlugin,
)

from .pydantic_support import (
    PYDANTIC_AVAILABLE,
    PYDANTIC_VERSION,
    get_pydantic_version,
    is_pydantic_available,
    BaseSchema,
    ValidatedData,
    validate as pydantic_validate,
    pydantic_response,
    pydantic_response_list,
    create_validator,
    AnnotatedField,
)


__all__ = [
    'Plugin',
    'PluginManager',
    'Extension',
    'MiddlewareExtension',
    'RouteExtension',
    'BlueprintExtension',
    'register_plugin',
    'DatabasePlugin',
    'SQLAlchemyPlugin',
    'get_db_session',
    'RedisPlugin',
    'redis',
    'OpenAPIPlugin',
    'openapi',
    'schema',
    'parameter',
    'response',
    'request_body',
    'CORSPlugin',
    'CompressionPlugin',
    'RateLimitPlugin',
    'SecurityPlugin',
    'PYDANTIC_AVAILABLE',
    'PYDANTIC_VERSION',
    'get_pydantic_version',
    'is_pydantic_available',
    'BaseSchema',
    'ValidatedData',
    'pydantic_validate',
    'pydantic_response',
    'pydantic_response_list',
    'create_validator',
    'AnnotatedField',
]
