#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.http.url - URL parsing and construction utilities
"""

import urllib.parse
from typing import Optional


class HttpURL:
    """不可变URL对象 - URL实现
    
    提供对URL各部分的类型安全访问：
    - scheme: http/https
    - host: 域名+端口
    - path: 路径
    - query: 查询字符串
    - fragment: 片段
    """

    __slots__ = ('_url', '_parsed')

    def __init__(self, url: str = "", **kwargs):
        if isinstance(url, HttpURL):
            url = str(url)
        self._url = url
        self._parsed = urllib.parse.urlparse(url)

        if kwargs:
            components = self._parsed
            scheme = kwargs.get('scheme', components.scheme)
            netloc = kwargs.get('host', kwargs.get('netloc', components.netloc))
            path = kwargs.get('path', components.path)
            query = kwargs.get('query', components.query)
            fragment = kwargs.get('fragment', components.fragment)
            self._parsed = urllib.parse.ParseResult(
                scheme=scheme, netloc=netloc, path=path,
                params='', query=query, fragment=fragment
            )
            self._url = self._parsed.geturl()

    @property
    def scheme(self) -> str:
        return self._parsed.scheme or 'http'

    @property
    def netloc(self) -> str:
        return self._parsed.netloc

    @property
    def host(self) -> str:
        return self._parsed.hostname or ''

    @property
    def port(self) -> Optional[int]:
        return self._parsed.port

    @property
    def path(self) -> str:
        return self._parsed.path or '/'

    @property
    def query(self) -> str:
        return self._parsed.query

    @property
    def fragment(self) -> str:
        return self._parsed.fragment

    @property
    def username(self) -> Optional[str]:
        return self._parsed.username

    @property
    def password(self) -> Optional[str]:
        return self._parsed.password

    def replace(self, **kwargs) -> 'HttpURL':
        components = {
            'scheme': self.scheme,
            'netloc': self.netloc,
            'path': self.path,
            'query': self.query,
            'fragment': self.fragment,
        }
        if 'host' in kwargs:
            components['netloc'] = kwargs.pop('host')
        components.update(kwargs)
        new_parsed = urllib.parse.ParseResult(
            scheme=components['scheme'],
            netloc=components['netloc'],
            path=components['path'],
            params='',
            query=components['query'],
            fragment=components['fragment']
        )
        return HttpURL(new_parsed.geturl())

    @property
    def is_secure(self) -> bool:
        return self.scheme in ('https', 'wss', 'http/2', 'http/3')

    @property
    def query_params(self) -> dict:
        """解析后的查询参数字典"""
        return dict(urllib.parse.parse_qs(self.query))

    def join(self, relative_url: str) -> 'HttpURL':
        """解析相对URL，返回新的HttpURL对象"""
        base = self._parsed.geturl()
        resolved = urllib.parse.urljoin(base, relative_url)
        return HttpURL(resolved)

    def __str__(self) -> str:
        if self._parsed.password:
            netloc = self._parsed.hostname or ''
            if self._parsed.username:
                netloc = f"{self._parsed.username}:***@{netloc}"
            if self._parsed.port:
                netloc = f"{netloc}:{self._parsed.port}"
            safe_url = self._parsed._replace(netloc=netloc).geturl()
            return safe_url
        return self._url

    def __repr__(self) -> str:
        return f"URL({self._url!r})"

    def __eq__(self, other) -> bool:
        if isinstance(other, HttpURL):
            return str(self) == str(other)
        if isinstance(other, str):
            return str(self) == other
        return NotImplemented

    def __hash__(self) -> int:
        return hash(str(self))

    def __contains__(self, item) -> bool:
        return item in self._url

    def __bool__(self) -> bool:
        return bool(self._url)
