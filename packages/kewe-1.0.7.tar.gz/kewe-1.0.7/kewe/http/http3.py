#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.http.http3 - HTTP/3 (QUIC) protocol implementation
"""

import asyncio
import logging
import os
import ssl
from typing import Dict, Optional, Any, List, Callable, Union
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)

AIOQUIC_AVAILABLE = False
AIOQUIC_VERSION: Optional[str] = None

try:
    import aioquic
    from aioquic.asyncio import QuicConnectionProtocol, serve
    from aioquic.quic.configuration import QuicConfiguration
    from aioquic.quic.events import (
        QuicEvent, ProtocolNegotiated, StreamDataReceived, 
        StreamReset, ConnectionTerminated, HandshakeCompleted,
        ConnectionIdIssued, ConnectionIdRetired
    )
    from aioquic.h3.connection import H3Connection, H3Event
    from aioquic.h3.events import (
        HeadersReceived, DataReceived,
        PushPromiseReceived
    )
    from aioquic.h3.exceptions import H3Error, NoAvailablePushIDError
    
    AIOQUIC_AVAILABLE = True
    AIOQUIC_VERSION = getattr(aioquic, '__version__', 'unknown')
    logger.debug(f"aioquic {AIOQUIC_VERSION} is available")
except ImportError:
    logger.debug("aioquic not available, HTTP/3 support disabled")


def get_aioquic_version() -> Optional[str]:
    """获取aioquic版本"""
    return AIOQUIC_VERSION


def is_http3_available() -> bool:
    """检查HTTP/3是否可用"""
    return AIOQUIC_AVAILABLE


@dataclass
class HTTP3Request:
    """HTTP/3请求"""
    stream_id: int
    method: str = ""
    path: str = ""
    scheme: str = "https"
    host: str = ""
    headers: Dict[str, str] = field(default_factory=dict)
    body: bytes = b""
    trailers: Dict[str, str] = field(default_factory=dict)
    complete: bool = False
    query_string: str = ""
    query_params: Dict[str, list] = field(default_factory=dict)


@dataclass
class HTTP3Response:
    """HTTP/3响应"""
    stream_id: int
    status: int = 200
    headers: Dict[str, str] = field(default_factory=dict)
    body: bytes = b""
    trailers: Dict[str, str] = field(default_factory=dict)


if AIOQUIC_AVAILABLE:
    class HTTP3ConnectionHandler:
        """HTTP/3连接处理器"""

        MAX_STREAM_DATA = 1048576
        MAX_CONNECTION_DATA = 10485760

        def __init__(self, quic_connection, app):
            self.quic = quic_connection
            self.app = app
            self.h3 = H3Connection(quic_connection)
            self._requests: Dict[int, HTTP3Request] = {}
            self._responses: Dict[int, HTTP3Response] = {}
            self._active_tasks: set = set()
            self._zero_rtt_accepted = False
            self._connection_id = quic_connection.host_cid if hasattr(quic_connection, 'host_cid') else b''
            self._stream_credits: Dict[int, int] = {}
            self._connection_credit = self.MAX_CONNECTION_DATA
            self._flow_control_events: Dict[int, asyncio.Event] = {}
            self._closing = False
        
        @property
        def supports_zero_rtt(self) -> bool:
            """是否支持0-RTT"""
            return hasattr(self.quic, 'configuration') and getattr(
                self.quic.configuration, 'max_early_data', 0
            ) > 0
        
        def handle_event(self, event: QuicEvent):
            """处理QUIC事件"""
            if isinstance(event, ProtocolNegotiated):
                self.h3 = H3Connection(self.quic)
                if hasattr(event, 'alpn_protocol') and event.alpn_protocol:
                    logger.debug(f"HTTP/3 ALPN negotiated: {event.alpn_protocol}")
            
            elif isinstance(event, HandshakeCompleted):
                logger.debug("HTTP/3 handshake completed")
                self._zero_rtt_accepted = getattr(self.quic, '_zero_rtt_accepted', False)
                if self._zero_rtt_accepted:
                    logger.info("HTTP/3 0-RTT accepted")
            
            elif isinstance(event, StreamDataReceived):
                self._handle_stream_data(event)
            
            elif isinstance(event, StreamReset):
                self._handle_stream_reset(event)
            
            elif isinstance(event, ConnectionTerminated):
                logger.debug(f"Connection terminated: {event.error_code}")
            
            elif isinstance(event, ConnectionIdIssued):
                logger.debug(f"Connection ID issued (migration support)")
            
            elif isinstance(event, ConnectionIdRetired):
                logger.debug(f"Connection ID retired")
        
        def _handle_stream_data(self, event: StreamDataReceived):
            """处理流数据"""
            try:
                for h3_event in self.h3.handle_event(event):
                    self._handle_h3_event(h3_event)
            except H3Error as e:
                logger.error(f"H3 error: {e}")
        
        def _handle_h3_event(self, event: H3Event):
            """处理HTTP/3事件"""
            if isinstance(event, HeadersReceived):
                self._handle_headers(event)
            elif isinstance(event, DataReceived):
                self._handle_data(event)
        
        def _handle_headers(self, event: HeadersReceived):
            """处理请求头"""
            stream_id = event.stream_id
            
            if stream_id not in self._requests:
                self._requests[stream_id] = HTTP3Request(stream_id=stream_id)
            
            request = self._requests[stream_id]
            
            for name, value in event.headers:
                name_lower = name.lower()
                if name_lower == ':method':
                    request.method = value
                elif name_lower == ':path':
                    from urllib.parse import urlparse, parse_qs
                    parsed = urlparse(value)
                    request.path = parsed.path
                    request.query_string = parsed.query
                    request.query_params = parse_qs(parsed.query)
                elif name_lower == ':scheme':
                    request.scheme = value
                elif name_lower == ':authority':
                    request.host = value
                else:
                    request.headers[name_lower] = value
            
            if event.stream_ended:
                request.complete = True
                task = asyncio.create_task(self._process_request(stream_id))
                self._active_tasks.add(task)
                task.add_done_callback(self._active_tasks.discard)
        
        def _handle_data(self, event: DataReceived):
            """处理请求体数据"""
            stream_id = event.stream_id
            
            if stream_id in self._requests:
                req = self._requests[stream_id]
                if isinstance(req.body, bytes):
                    req.body = bytearray(req.body)
                req.body.extend(event.data)
                
                if event.stream_ended:
                    self._requests[stream_id].complete = True
                    task = asyncio.create_task(self._process_request(stream_id))
                    self._active_tasks.add(task)
                    task.add_done_callback(self._active_tasks.discard)
        
        def _handle_stream_reset(self, event: StreamReset):
            """处理流重置"""
            stream_id = event.stream_id
            
            if stream_id in self._requests:
                del self._requests[stream_id]
            
            if stream_id in self._responses:
                del self._responses[stream_id]
        
        def _get_client_ip(self) -> str:
            peer_addr = getattr(self.quic, '_peer_address', None)
            if peer_addr and hasattr(peer_addr, '__getitem__'):
                return peer_addr[0]
            return ""
        
        async def _process_request(self, stream_id: int):
            """处理HTTP请求"""
            if stream_id not in self._requests:
                return

            request = self._requests[stream_id]

            try:
                from kewe.request import Request as KeweRequest

                kewe_request = KeweRequest(
                    method=request.method,
                    path=request.path,
                    headers=request.headers,
                    query_params=getattr(request, 'query_params', None),
                    query_string=getattr(request, 'query_string', None),
                    body=request.body,
                    client_ip=self._get_client_ip(),
                    protocol="HTTP/3",
                    app=self.app,
                )

                response = await self.app.handle_request(kewe_request)

                if hasattr(response, '_stream_generator') and response._streaming:
                    self._send_streaming_response(stream_id, response)
                else:
                    self._send_response(stream_id, response.status, dict(response.headers), response.body)

            except Exception as e:
                logger.error(f"Error processing request: {e}")
                self._send_response(stream_id, 500, {}, b"Internal Server Error")

            finally:
                if stream_id in self._requests:
                    del self._requests[stream_id]

        def _send_streaming_response(self, stream_id: int, response):
            """发送流式响应"""
            response_headers = [
                (":status", str(response.status)),
            ]

            for name, value in response.headers.items():
                response_headers.append((name.lower(), value))

            self.h3.send_headers(stream_id, response_headers)

            async def _stream():
                try:
                    async for chunk in response._stream_generator:
                        if self._closing:
                            break
                        if isinstance(chunk, str):
                            chunk = chunk.encode('utf-8')
                        await self._send_with_flow_control(stream_id, chunk)
                except Exception as e:
                    logger.error(f"Streaming error: {e}")
                finally:
                    self.h3.send_data(stream_id, b"", end_stream=True)

            task = asyncio.create_task(_stream())
            self._active_tasks.add(task)
            task.add_done_callback(self._active_tasks.discard)

        async def _send_with_flow_control(self, stream_id: int, data: bytes):
            """带流控的数据发送 - QUIC层由aioquic处理流控"""
            chunk_size = 65536
            offset = 0
            while offset < len(data):
                chunk = data[offset:offset + chunk_size]
                self.h3.send_data(stream_id, chunk, end_stream=(offset + chunk_size >= len(data)))
                offset += chunk_size
                if offset < len(data):
                    await asyncio.sleep(0)
        
        def _send_response(
            self,
            stream_id: int,
            status: int,
            headers: Dict[str, str],
            body: bytes
        ):
            response_headers = [
                (":status", str(status)),
            ]
            
            for name, value in headers.items():
                response_headers.append((name.lower(), value))
            
            if "content-type" not in {k.lower() for k in headers.keys()}:
                response_headers.append(("content-type", "application/octet-stream"))
            
            if "content-length" not in {k.lower() for k in headers.keys()}:
                response_headers.append(("content-length", str(len(body))))
            
            self.h3.send_headers(stream_id, response_headers)
            
            if body:
                self.h3.send_data(stream_id, body, end_stream=True)
            else:
                self.h3.send_data(stream_id, b"", end_stream=True)
        
        def send_streaming_data(self, stream_id: int, data: bytes, end_stream: bool = False):
            self.h3.send_data(stream_id, data, end_stream=end_stream)
        
        def close(self):
            """关闭连接"""
            self.quic.close()


    class HTTP3Protocol(QuicConnectionProtocol):
        """HTTP/3协议处理器"""
        
        def __init__(self, *args, app=None, **kwargs):
            super().__init__(*args, **kwargs)
            self.app = app
            self._handler: Optional[HTTP3ConnectionHandler] = None
        
        def quic_event_received(self, event: QuicEvent):
            """接收QUIC事件"""
            if self._handler is None:
                self._handler = HTTP3ConnectionHandler(self._quic, self.app)
            
            self._handler.handle_event(event)


    class HTTP3Server:
        """HTTP/3服务器"""
        
        def __init__(
            self,
            app,
            host: str = "0.0.0.0",
            port: int = 443,
            certfile: str = None,
            keyfile: str = None,
            **kwargs
        ):
            self.app = app
            self.host = host
            self.port = port
            self.certfile = certfile
            self.keyfile = keyfile
            self._server = None
            self._kwargs = kwargs
        
        def _create_configuration(self) -> QuicConfiguration:
            """创建QUIC配置"""
            config = QuicConfiguration(
                alpn_protocols=["h3"],
                is_client=False,
                max_datagram_frame_size=65536,
            )
            
            if self.certfile and self.keyfile:
                config.load_cert_chain(self.certfile, self.keyfile)
            
            return config
        
        async def start(self):
            """启动服务器"""
            configuration = self._create_configuration()
            
            self._server = await serve(
                host=self.host,
                port=self.port,
                configuration=configuration,
                create_protocol=lambda *args, **kwargs: HTTP3Protocol(
                    *args, app=self.app, **kwargs
                ),
                **self._kwargs
            )
            
            logger.info(f"HTTP/3 server started on https://{self.host}:{self.port}")
        
        async def stop(self, timeout: float = 5.0):
            """停止服务器"""
            if self._server:
                self._server.close()
                await asyncio.sleep(0.1)
                logger.info("HTTP/3 server stopped")


    async def create_http3_server(
        app,
        host: str = "0.0.0.0",
        port: int = 443,
        certfile: str = None,
        keyfile: str = None,
        **kwargs
    ) -> HTTP3Server:
        """
        创建HTTP/3服务器
        
        Args:
            app: Kewe应用实例
            host: 主机地址
            port: 端口（默认443）
            certfile: SSL证书文件
            keyfile: SSL私钥文件
            
        Returns:
            HTTP3Server实例
        """
        if not AIOQUIC_AVAILABLE:
            raise ImportError(
                "HTTP/3 support requires 'aioquic' package. "
                "Install with: pip install aioquic"
            )
        
        server = HTTP3Server(
            app=app,
            host=host,
            port=port,
            certfile=certfile,
            keyfile=keyfile,
            **kwargs
        )
        
        await server.start()
        return server


    def create_quic_configuration(
        certfile: str = None,
        keyfile: str = None,
        max_datagram_frame_size: int = 65536,
        idle_timeout: float = 60.0,
        max_data: int = 10485760,
        max_stream_data: int = 1048576,
        max_streams_bidi: int = 100,
        max_streams_uni: int = 100,
        enable_0rtt: bool = True,
        enable_connection_migration: bool = True,
    ) -> QuicConfiguration:
        config = QuicConfiguration(
            alpn_protocols=["h3"],
            is_client=False,
            max_datagram_frame_size=max_datagram_frame_size,
            idle_timeout=idle_timeout,
        )
        
        if enable_0rtt:
            config.max_early_data = 65536
        
        if enable_connection_migration:
            config.active_connection_id_limit = 4
        
        if certfile and keyfile:
            config.load_cert_chain(certfile, keyfile)
        
        return config

else:
    HTTP3Protocol = object
    HTTP3Server = None
    HTTP3ConnectionHandler = None
    
    async def create_http3_server(*args, **kwargs):
        raise ImportError(
            "HTTP/3 support requires 'aioquic' package. "
            "Install with: pip install aioquic"
        )
    
    def create_quic_configuration(*args, **kwargs):
        raise ImportError(
            "HTTP/3 support requires 'aioquic' package. "
            "Install with: pip install aioquic"
        )


__all__ = [
    'AIOQUIC_AVAILABLE',
    'AIOQUIC_VERSION',
    'get_aioquic_version',
    'is_http3_available',
    'HTTP3Request',
    'HTTP3Response',
    'HTTP3Protocol',
    'HTTP3Server',
    'HTTP3ConnectionHandler',
    'create_http3_server',
    'create_quic_configuration',
]

if AIOQUIC_AVAILABLE:
    __all__.extend([
        'QuicConfiguration',
        'H3Connection',
        'H3Error',
    ])
    
    __all__.extend([
        'WebTransportSession',
        'WebTransportStream',
        'WebTransportHandler',
    ])


if AIOQUIC_AVAILABLE:
    class WebTransportStream:
        """
        WebTransport 流
        
        用于在 WebTransport 会话中发送和接收数据
        """
        
        def __init__(self, stream_id: int, session: 'WebTransportSession'):
            self.stream_id = stream_id
            self.session = session
            self._buffer: bytes = b""
            self._closed = False
            self._data_event = asyncio.Event()
        
        async def send(self, data: bytes):
            """发送数据"""
            if self._closed:
                raise RuntimeError("Stream is closed")

            self.session.h3.send_data(self.stream_id, data, end_stream=False)
        
        async def receive(self) -> bytes:
            """接收数据"""
            while not self._buffer and not self._closed:
                self._data_event.clear()
                await self._data_event.wait()
            
            data = self._buffer
            self._buffer = b""
            return data
        
        def close(self):
            """关闭流"""
            self._closed = True
            self._data_event.set()
        
        @property
        def is_closed(self) -> bool:
            """流是否已关闭"""
            return self._closed
        
        def _on_data(self, data: bytes):
            """收到数据时调用"""
            self._buffer += data
    
    
    class WebTransportSession:
        """
        WebTransport 会话
        
        管理单个 WebTransport 连接
        
        使用示例:
            async def handle_webtransport(session: WebTransportSession):
                async for stream in session.accept_stream():
                    data = await stream.receive()
                    await stream.send(data.upper())
        """
        
        def __init__(self, session_id: int, h3_connection, quic_connection):
            self.session_id = session_id
            self.h3 = h3_connection
            self.quic = quic_connection
            self._streams: Dict[int, WebTransportStream] = {}
            self._pending_streams: asyncio.Queue = asyncio.Queue()
            self._closed = False
            self._accepted = False
        
        async def accept(self):
            """接受 WebTransport 会话"""
            self._accepted = True
            self.h3.send_datagram(self.quic, b"", self.session_id)
        
        async def open_stream(self) -> WebTransportStream:
            """打开新的流"""
            stream_id = self.quic.get_next_available_stream_id()
            stream = WebTransportStream(stream_id, self)
            self._streams[stream_id] = stream
            return stream
        
        async def accept_stream(self) -> WebTransportStream:
            """接受新的流"""
            while True:
                if self._closed:
                    raise RuntimeError("Session is closed")
                
                stream = await self._pending_streams.get()
                return stream
        
        async def send_datagram(self, data: bytes):
            """发送数据报"""
            if self._closed:
                raise RuntimeError("Session is closed")
            
            self.h3.send_datagram(self.quic, data, self.session_id)
        
        def close(self, error_code: int = 0, reason: str = ""):
            """关闭会话 - 仅关闭WebTransport流，不关闭整个QUIC连接"""
            if self._closed:
                return

            self._closed = True

            for stream in self._streams.values():
                stream.close()

            try:
                self.h3.send_data(self.session_id, b"", end_stream=True)
            except Exception:
                logger.debug("Non-critical operation failed", exc_info=True)
        
        @property
        def is_closed(self) -> bool:
            """会话是否已关闭"""
            return self._closed
        
        def _on_stream_data(self, stream_id: int, data: bytes):
            """收到流数据时调用"""
            if stream_id not in self._streams:
                stream = WebTransportStream(stream_id, self)
                self._streams[stream_id] = stream
                self._pending_streams.put_nowait(stream)
            
            self._streams[stream_id]._on_data(data)
        
        def _on_stream_close(self, stream_id: int):
            """流关闭时调用"""
            if stream_id in self._streams:
                self._streams[stream_id].close()
                del self._streams[stream_id]
    
    
    class WebTransportHandler:
        """
        WebTransport 处理器基类
        
        使用示例:
            class MyWebTransportHandler(WebTransportHandler):
                async def on_session(self, session: WebTransportSession):
                    await session.accept()
                    
                    async for stream in session.accept_stream():
                        data = await stream.receive()
                        await stream.send(data.upper())
            
            # 在路由中使用
            @app.websocket("/wt")
            async def wt_handler(request):
                handler = MyWebTransportHandler()
                return handler
        """
        
        async def on_session(self, session: WebTransportSession):
            """
            处理 WebTransport 会话
            
            Args:
                session: WebTransport 会话对象
            """
            await session.accept()
            
            async for stream in session.accept_stream():
                try:
                    await self.on_stream(stream)
                except Exception as e:
                    logger.error(f"Error handling stream: {e}")
                    stream.close()
        
        async def on_stream(self, stream: WebTransportStream):
            try:
                data = await stream.read()
                if data:
                    logger.debug(f"WebTransport stream data received: {len(data)} bytes")
                    await stream.write(data)
            except Exception as e:
                logger.error(f"Error handling WebTransport stream: {e}")
                stream.close()
        
        async def on_datagram(self, data: bytes, session: WebTransportSession):
            logger.debug(f"WebTransport datagram received: {len(data)} bytes")
        
        async def on_error(self, error: Exception, session: WebTransportSession = None):
            """
            处理错误
            
            Args:
                error: 错误对象
                session: WebTransport 会话对象（可选）
            """
            logger.error(f"WebTransport error: {error}")
    
    
    class WebTransportCapsule:
        """WebTransport Capsule 协议支持"""
        
        TYPE_CLOSE = 0x00
        TYPE_DRAIN = 0x01
        
        @staticmethod
        def encode_close(error_code: int = 0, reason: str = "") -> bytes:
            """编码 CLOSE capsule"""
            reason_bytes = reason.encode('utf-8')
            return (
                bytes([WebTransportCapsule.TYPE_CLOSE]) +
                error_code.to_bytes(4, 'big') +
                len(reason_bytes).to_bytes(2, 'big') +
                reason_bytes
            )
        
        @staticmethod
        def encode_drain() -> bytes:
            """编码 DRAIN capsule"""
            return bytes([WebTransportCapsule.TYPE_DRAIN])
        
        @staticmethod
        def decode(data: bytes) -> tuple:
            """解码 capsule"""
            if not data:
                return None, b""
            
            capsule_type = data[0]
            
            if capsule_type == WebTransportCapsule.TYPE_CLOSE:
                if len(data) < 7:
                    return None, data
                error_code = int.from_bytes(data[1:5], 'big')
                reason_len = int.from_bytes(data[5:7], 'big')
                if len(data) < 7 + reason_len:
                    return None, data
                reason = data[7:7 + reason_len].decode('utf-8')
                return ('close', error_code, reason), data[7 + reason_len:]
            
            elif capsule_type == WebTransportCapsule.TYPE_DRAIN:
                return ('drain',), data[1:]
            
            return None, data
