#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.http.client - Async HTTP client with retry and connection pooling
"""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Any, Optional, Callable, Dict, List

logger = logging.getLogger(__name__)


class HttpClientConfig:
    """HTTP客户端配置"""

    def __init__(
        self,
        timeout: float = 10.0,
        max_connections: int = 100,
        max_keepalive_connections: int = 20,
        keepalive_expiry: float = 30.0,
        base_url: Optional[str] = None,
        headers: Optional[Dict[str, str]] = None,
        retry_max: int = 3,
        retry_backoff: float = 0.5,
        follow_redirects: bool = True,
        verify_ssl: bool = True,
    ):
        self.timeout = timeout
        self.max_connections = max_connections
        self.max_keepalive_connections = max_keepalive_connections
        self.keepalive_expiry = keepalive_expiry
        self.base_url = base_url
        self.headers = dict(headers or {})
        self.retry_max = retry_max
        self.retry_backoff = retry_backoff
        self.follow_redirects = follow_redirects
        self.verify_ssl = verify_ssl


class RetryConfig:
    """重试配置"""

    def __init__(
        self,
        max_retries: int = 3,
        retry_on_status: Optional[List[int]] = None,
        retry_on_exceptions: Optional[tuple] = None,
        backoff_factor: float = 0.5,
        backoff_max: float = 30.0,
        retry_methods: Optional[List[str]] = None,
    ):
        self.max_retries = max_retries
        self.retry_on_status = retry_on_status or [429, 500, 502, 503, 504]
        self.retry_on_exceptions = retry_on_exceptions or (Exception,)
        self.backoff_factor = backoff_factor
        self.backoff_max = backoff_max
        self.retry_methods = retry_methods or ["GET", "HEAD", "OPTIONS", "PUT", "DELETE"]

    def should_retry(self, method: str, status_code: Optional[int] = None, exception: Optional[Exception] = None) -> bool:
        if method.upper() not in self.retry_methods:
            return False
        if exception is not None:
            return isinstance(exception, self.retry_on_exceptions)
        if status_code is not None:
            return status_code in self.retry_on_status
        return False

    def get_delay(self, attempt: int) -> float:
        delay = self.backoff_factor * (2 ** attempt)
        return min(delay, self.backoff_max)


class AsyncHTTPClient:
    """
    增强版异步HTTP客户端

    功能：
    - 懒初始化（首次请求时创建httpx.AsyncClient）
    - 自动重试（指数退避）
    - 连接池管理
    - 应用生命周期集成（自动关闭）
    - 请求/响应拦截器

    使用示例:
        # 基本用法
        client = AsyncHTTPClient(base_url="https://api.example.com")
        response = await client.get("/users")

        # 与应用集成
        app.setup_http_client(base_url="https://api.example.com")
        # 在路由中
        response = await request.app.http_client.get("/users")

        # 重试配置
        client = AsyncHTTPClient(
            base_url="https://api.example.com",
            retry=RetryConfig(max_retries=5, backoff_factor=1.0),
        )
    """

    def __init__(
        self,
        *,
        base_url: Optional[str] = None,
        headers: Optional[dict[str, str]] = None,
        timeout: float = 10.0,
        transport: Any = None,
        retry: Optional[RetryConfig] = None,
        max_connections: int = 100,
        max_keepalive_connections: int = 20,
        keepalive_expiry: float = 30.0,
        **client_kwargs: Any,
    ):
        self.base_url = base_url
        self.headers = dict(headers or {})
        self.timeout = timeout
        self.transport = transport
        self.retry = retry or RetryConfig()
        self.max_connections = max_connections
        self.max_keepalive_connections = max_keepalive_connections
        self.keepalive_expiry = keepalive_expiry
        self.client_kwargs = dict(client_kwargs)
        self._client = None
        self._closed = False
        self._request_interceptors: List[Callable] = []
        self._response_interceptors: List[Callable] = []
        self._stats = {
            "total_requests": 0,
            "total_retries": 0,
            "total_errors": 0,
            "total_time": 0.0,
        }

    async def _ensure_client(self):
        if self._client is not None:
            return self._client

        try:
            import httpx
        except ImportError as exc:
            raise ImportError(
                "httpx is required for AsyncHTTPClient. Install it with: pip install httpx"
            ) from exc

        kwargs = dict(self.client_kwargs)
        kwargs.setdefault("headers", self.headers)
        kwargs.setdefault("timeout", self.timeout)
        if self.base_url is not None:
            kwargs.setdefault("base_url", self.base_url)
        if self.transport is not None:
            kwargs.setdefault("transport", self.transport)

        kwargs.setdefault("limits", httpx.Limits(
            max_connections=self.max_connections,
            max_keepalive_connections=self.max_keepalive_connections,
            keepalive_expiry=self.keepalive_expiry,
        ))

        self._client = httpx.AsyncClient(**kwargs)
        return self._client

    def add_request_interceptor(self, interceptor: Callable):
        """
        添加请求拦截器

        拦截器签名: async def interceptor(method, url, kwargs) -> (method, url, kwargs)
        """
        self._request_interceptors.append(interceptor)

    def add_response_interceptor(self, interceptor: Callable):
        """
        添加响应拦截器

        拦截器签名: async def interceptor(response) -> response
        """
        self._response_interceptors.append(interceptor)

    async def _apply_request_interceptors(self, method: str, url: str, kwargs: dict):
        for interceptor in self._request_interceptors:
            result = interceptor(method, url, kwargs)
            if asyncio.iscoroutine(result):
                result = await result
            if isinstance(result, tuple) and len(result) == 3:
                method, url, kwargs = result
        return method, url, kwargs

    async def _apply_response_interceptors(self, response: Any):
        for interceptor in self._response_interceptors:
            result = interceptor(response)
            if asyncio.iscoroutine(result):
                result = await result
            if result is not None:
                response = result
        return response

    async def request(self, method: str, url: str, **kwargs: Any):
        client = await self._ensure_client()
        start_time = time.monotonic()
        self._stats["total_requests"] += 1

        method, url, kwargs = await self._apply_request_interceptors(method, url, kwargs)

        last_exception = None
        last_response = None

        for attempt in range(self.retry.max_retries + 1):
            try:
                response = await client.request(method, url, **kwargs)
                response = await self._apply_response_interceptors(response)

                if not self.retry.should_retry(method, status_code=response.status_code):
                    elapsed = time.monotonic() - start_time
                    self._stats["total_time"] += elapsed
                    return response

                last_response = response

                if attempt < self.retry.max_retries:
                    delay = self.retry.get_delay(attempt)
                    retry_after = response.headers.get("retry-after")
                    if retry_after:
                        try:
                            delay = float(retry_after)
                        except (ValueError, TypeError):
                            pass
                    self._stats["total_retries"] += 1
                    logger.debug(f"Retrying {method} {url} (attempt {attempt + 1}/{self.retry.max_retries}) after {delay:.1f}s")
                    await asyncio.sleep(delay)

            except self.retry.retry_on_exceptions as e:
                last_exception = e
                if not self.retry.should_retry(method, exception=e):
                    self._stats["total_errors"] += 1
                    raise

                if attempt < self.retry.max_retries:
                    delay = self.retry.get_delay(attempt)
                    self._stats["total_retries"] += 1
                    logger.debug(f"Retrying {method} {url} (attempt {attempt + 1}/{self.retry.max_retries}) after {delay:.1f}s due to {type(e).__name__}")
                    await asyncio.sleep(delay)
                else:
                    self._stats["total_errors"] += 1
                    raise

        elapsed = time.monotonic() - start_time
        self._stats["total_time"] += elapsed

        if last_exception:
            raise last_exception
        return last_response

    async def get(self, url: str, **kwargs: Any):
        return await self.request("GET", url, **kwargs)

    async def post(self, url: str, **kwargs: Any):
        return await self.request("POST", url, **kwargs)

    async def put(self, url: str, **kwargs: Any):
        return await self.request("PUT", url, **kwargs)

    async def patch(self, url: str, **kwargs: Any):
        return await self.request("PATCH", url, **kwargs)

    async def delete(self, url: str, **kwargs: Any):
        return await self.request("DELETE", url, **kwargs)

    async def head(self, url: str, **kwargs: Any):
        return await self.request("HEAD", url, **kwargs)

    async def options(self, url: str, **kwargs: Any):
        return await self.request("OPTIONS", url, **kwargs)

    async def close(self):
        if self._client is not None and not self._closed:
            await self._client.aclose()
            self._client = None
            self._closed = True

    async def aclose(self):
        await self.close()

    @property
    def is_closed(self) -> bool:
        return self._closed

    @property
    def stats(self) -> Dict[str, Any]:
        return dict(self._stats)

    def reset_stats(self):
        self._stats = {
            "total_requests": 0,
            "total_retries": 0,
            "total_errors": 0,
            "total_time": 0.0,
        }

    async def __aenter__(self) -> "AsyncHTTPClient":
        await self._ensure_client()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()
        return False


def setup_http_client(
    app,
    *,
    base_url: Optional[str] = None,
    headers: Optional[dict[str, str]] = None,
    timeout: float = 10.0,
    retry: Optional[RetryConfig] = None,
    **kwargs: Any,
) -> AsyncHTTPClient:
    """
    设置HTTP客户端并集成到应用生命周期

    自动在应用关闭时关闭客户端连接。

    使用示例:
        from kewe.http.client import setup_http_client

        app = Kewe("myapp")
        client = setup_http_client(app, base_url="https://api.example.com")

        @app.get("/proxy/users")
        async def proxy_users(request):
            response = await request.app.http_client.get("/users")
            return json(response.json())
    """
    client = AsyncHTTPClient(
        base_url=base_url,
        headers=headers,
        timeout=timeout,
        retry=retry,
        **kwargs,
    )

    app.http_client = client

    if hasattr(app, "after_server_stop"):
        @app.after_server_stop
        async def _close_http_client(app):
            await client.close()

    if hasattr(app, "register_internal_service"):
        app.register_internal_service("http_client", client)

    return client


__all__ = ["AsyncHTTPClient", "RetryConfig", "HttpClientConfig", "setup_http_client"]
