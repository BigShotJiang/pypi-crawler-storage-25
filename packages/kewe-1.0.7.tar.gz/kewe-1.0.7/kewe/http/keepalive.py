#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.http.keepalive - HTTP keep-alive connection manager
"""

import asyncio
import logging
import time
from typing import Optional, Dict, Any
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class KeepAliveConfig:
    """Keep-Alive配置"""
    enabled: bool = True
    timeout: float = 5.0  # 秒
    max_requests: int = 100  # 最大请求数
    header: str = "keep-alive"  # 响应头值


class KeepAliveManager:
    """
    Keep-Alive连接管理器
    
    管理HTTP连接的Keep-Alive行为，包括：
    - 超时管理
    - 最大请求数限制
    - 连接状态跟踪
    
    使用示例:
        manager = KeepAliveManager(config)
        if manager.should_keep_alive(request, response):
            manager.update_connection(connection_id)
    """
    
    def __init__(self, config: KeepAliveConfig = None):
        self.config = config or KeepAliveConfig()
        self._connections: Dict[str, Dict[str, Any]] = {}
        self._cleanup_task: Optional[asyncio.Task] = None
    
    def start(self):
        """启动清理任务"""
        if self._cleanup_task is None:
            self._cleanup_task = asyncio.create_task(self._cleanup_loop())
    
    def stop(self):
        """停止清理任务"""
        if self._cleanup_task:
            self._cleanup_task.cancel()
            self._cleanup_task = None
    
    async def _cleanup_loop(self):
        """定期清理过期连接"""
        while True:
            try:
                await asyncio.sleep(1.0)
                self._cleanup_expired()
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Keep-alive cleanup error: {e}")
    
    def _cleanup_expired(self):
        """清理过期连接"""
        now = time.time()
        expired = []
        
        for conn_id, info in self._connections.items():
            # 检查超时
            if now - info['last_activity'] > self.config.timeout:
                expired.append(conn_id)
                continue
            
            # 检查最大请求数
            if info['request_count'] >= self.config.max_requests:
                expired.append(conn_id)
        
        for conn_id in expired:
            del self._connections[conn_id]
            logger.debug(f"Keep-alive connection expired: {conn_id}")
    
    def should_keep_alive(
        self,
        request_headers: Dict[str, str],
        response_status: int = 200
    ) -> bool:
        """
        判断是否应该保持连接
        
        Args:
            request_headers: 请求头
            response_status: 响应状态码
            
        Returns:
            是否应该保持连接
        """
        if not self.config.enabled:
            return False
        
        # 检查请求头中的Connection
        connection_header = request_headers.get('connection', '').lower()
        
        # 如果请求明确要求关闭
        if connection_header == 'close':
            return False
        
        # 如果请求是HTTP/1.0且没有Keep-Alive头
        protocol = request_headers.get('protocol', 'HTTP/1.1')
        if protocol == 'HTTP/1.0' and connection_header != 'keep-alive':
            return False
        
        # 错误响应通常不保持连接
        if response_status >= 500:
            return False
        
        return True
    
    def get_keep_alive_header(self) -> str:
        """获取Keep-Alive响应头值"""
        if not self.config.enabled:
            return "close"
        
        return f"timeout={int(self.config.timeout)}, max={self.config.max_requests}"
    
    def update_connection(self, connection_id: str):
        """
        更新连接状态
        
        Args:
            connection_id: 连接标识符
        """
        now = time.time()
        
        if connection_id not in self._connections:
            self._connections[connection_id] = {
                'created': now,
                'last_activity': now,
                'request_count': 1,
            }
        else:
            info = self._connections[connection_id]
            info['last_activity'] = now
            info['request_count'] += 1
    
    def is_connection_expired(self, connection_id: str) -> bool:
        """检查连接是否已过期"""
        if connection_id not in self._connections:
            return True
        
        info = self._connections[connection_id]
        now = time.time()
        
        # 检查超时
        if now - info['last_activity'] > self.config.timeout:
            return True
        
        # 检查最大请求数
        if info['request_count'] >= self.config.max_requests:
            return True
        
        return False
    
    def close_connection(self, connection_id: str):
        """关闭连接"""
        if connection_id in self._connections:
            del self._connections[connection_id]
            logger.debug(f"Keep-alive connection closed: {connection_id}")
    
    def get_connection_info(self, connection_id: str) -> Optional[Dict[str, Any]]:
        """获取连接信息"""
        return self._connections.get(connection_id)
    
    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        total = len(self._connections)
        
        if total == 0:
            return {
                'total_connections': 0,
                'avg_requests': 0,
                'avg_age': 0,
            }
        
        now = time.time()
        total_requests = sum(c['request_count'] for c in self._connections.values())
        total_age = sum(now - c['created'] for c in self._connections.values())
        
        return {
            'total_connections': total,
            'avg_requests': total_requests / total,
            'avg_age': total_age / total,
        }


class KeepAliveTimeout:
    """
    Keep-Alive超时管理
    
    用于管理单个连接的超时计时器
    """
    
    def __init__(self, timeout: float, on_timeout: callable):
        """
        初始化超时管理器
        
        Args:
            timeout: 超时时间（秒）
            on_timeout: 超时回调函数
        """
        self.timeout = timeout
        self.on_timeout = on_timeout
        self._timer: Optional[asyncio.TimerHandle] = None
        self._last_activity = time.time()
    
    def start(self):
        """启动超时计时器"""
        self._schedule_timeout()
    
    def stop(self):
        """停止超时计时器"""
        if self._timer:
            self._timer.cancel()
            self._timer = None
    
    def reset(self):
        """重置超时计时器"""
        self._last_activity = time.time()
        self.stop()
        self._schedule_timeout()
    
    def _schedule_timeout(self):
        """调度超时"""
        loop = asyncio.get_running_loop()
        self._timer = loop.call_later(self.timeout, self._on_timeout)
    
    def _on_timeout(self):
        """超时处理"""
        elapsed = time.time() - self._last_activity
        if elapsed >= self.timeout:
            try:
                self.on_timeout()
            except Exception as e:
                logger.error(f"Keep-alive timeout callback error: {e}")
        else:
            # 还有剩余时间，重新调度
            self._schedule_timeout()


# 便捷函数
def optimize_keep_alive_headers(
    headers: Dict[str, str],
    config: KeepAliveConfig,
    request_headers: Dict[str, str],
    response_status: int
) -> Dict[str, str]:
    """
    优化Keep-Alive头
    
    Args:
        headers: 当前响应头
        config: Keep-Alive配置
        request_headers: 请求头
        response_status: 响应状态码
        
    Returns:
        更新后的响应头
    """
    manager = KeepAliveManager(config)
    
    if manager.should_keep_alive(request_headers, response_status):
        headers['Connection'] = 'keep-alive'
        headers['Keep-Alive'] = manager.get_keep_alive_header()
    else:
        headers['Connection'] = 'close'
    
    return headers