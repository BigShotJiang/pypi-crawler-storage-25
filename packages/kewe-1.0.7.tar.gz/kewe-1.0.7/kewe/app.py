#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.app - Core Kewe application class
"""

import asyncio
import logging
import os
import ssl
import sys
import weakref
from typing import Callable, Dict, List, Optional, Any, Union, Coroutine, Sequence, Mapping
from functools import wraps

from kewe.request import Request
from kewe.response import Response, json as _json_resp
from kewe.utils.compat import json as _json
from kewe.middleware import MiddlewareManager, MiddlewarePriority
from kewe.errors.exceptions import KeweException, NotFound, MethodNotAllowed, InternalServerError
from kewe.routing.router import Router
from kewe.gateway.core import get_api_gateway, GatewayResponse, ErrorCode
from kewe.application.di import Container, ServiceProvider, scope
from kewe.base.context import RequestContextManager, g
from kewe.application.mixins import ApplicationMixin
from kewe.application.state_store import AppState
from kewe.application.config import KeweConfig

logger = logging.getLogger(__name__)


class Kewe(ApplicationMixin):
    """
    Kewe应用主类 - 集成API网关和依赖注入
    
    提供完整的日志配置支持
    继承ApplicationMixin获取所有便捷API
    
    应用注册表:
        app1 = Kewe("app1")
        app2 = Kewe.get_app("app1")  # 获取已注册的应用
        app3 = Kewe.get_app()  # 如果只有一个实例，无需参数
    """
    
    _current_app: Optional['Kewe'] = None
    _app_registry: weakref.WeakValueDictionary = weakref.WeakValueDictionary()
    
    @classmethod
    def get_app(
        cls,
        name: Optional[str] = None,
        *,
        force_create: bool = False
    ) -> 'Kewe':
        """
        从注册表获取应用实例
        """
        if name is None:
            if len(cls._app_registry) == 0:
                if force_create:
                    return cls()
                raise ValueError("No applications registered")
            if len(cls._app_registry) == 1:
                return next(iter(cls._app_registry.values()))
            registered = ", ".join(cls._app_registry.keys())
            raise ValueError(
                f"Multiple applications registered ({registered}), "
                "must specify name"
            )
        
        if name in cls._app_registry:
            return cls._app_registry[name]
        
        if force_create:
            return cls(name)
        
        registered = ", ".join(cls._app_registry.keys()) if cls._app_registry else "none"
        raise KeyError(
            f"Application '{name}' not found. "
            f"Registered applications: {registered}"
        )
    
    @classmethod
    def get_registered_apps(cls) -> Dict[str, 'Kewe']:
        """获取所有已注册的应用"""
        return cls._app_registry.copy()
    
    @classmethod
    def unregister_app(cls, name: str) -> bool:
        """从注册表移除应用"""
        if name in cls._app_registry:
            del cls._app_registry[name]
            if cls._current_app and cls._current_app.name == name:
                cls._current_app = None
            return True
        return False
    
    @classmethod
    def clear_registry(cls):
        """清空应用注册表"""
        cls._app_registry.clear()
        cls._current_app = None
    
    @classmethod
    def factory(
        cls,
        name: str = "KeweApp",
        *,
        config: Any = None,
        config_file: Optional[str] = None,
        config_object: Any = None,
        env_prefix: str = "KEWE_",
        enable_gateway: Optional[bool] = None,
        lifespan: Optional[Callable] = None,
        plugins: Optional[list[Any]] = None,
        static: Optional[list[dict[str, Any]]] = None,
        openapi: Optional[dict[str, Any]] = None,
        middleware: Optional[Sequence[Any]] = None,
        exception_handlers: Optional[Mapping[Any, Callable]] = None,
        on_startup: Optional[Sequence[Callable]] = None,
        on_shutdown: Optional[Sequence[Callable]] = None,
        routes: Optional[Sequence[Any]] = None,
        debug: Optional[bool] = None,
        root_path: str = "",
    ) -> 'Kewe':
        from kewe.factory import create_app

        return create_app(
            name=name,
            app_class=cls,
            config=config,
            config_file=config_file,
            config_object=config_object,
            env_prefix=env_prefix,
            enable_gateway=enable_gateway,
            lifespan=lifespan,
            plugins=plugins,
            static=static,
            openapi=openapi,
            middleware=middleware,
            exception_handlers=exception_handlers,
            on_startup=on_startup,
            on_shutdown=on_shutdown,
            routes=routes,
            debug=debug,
            root_path=root_path,
        )

    def __init__(
        self,
        name: str = "KeweApp",
        config: Optional[KeweConfig] = None,
        log_level: int = None,
        access_log: bool = None,
        json_log: bool = None,
        enable_gateway: bool = None,
        lifespan: Optional[Callable] = None,
        debug: Optional[bool] = None,
    ):
        """
        初始化Kewe应用
        
        Args:
            name: 应用名称
            config: 应用配置
            log_level: 日志级别
            access_log: 是否记录访问日志
            json_log: 是否使用JSON格式日志
            enable_gateway: 是否启用网关
            lifespan: 生命周期上下文管理器 (lifespan)
            debug: 调试模式
        """
        super().__init__()
        self.name = name
        self.config = config or KeweConfig()
        if debug is not None:
            self.config.debug = debug
        self._lifespan = lifespan
        self._lifespan_ctx = None
        if self.config.secret_key is None:
            import secrets as _secrets
            import warnings
            self.config.secret_key = _secrets.token_urlsafe(48)
            warnings.warn(
                "No secret_key configured. A random key has been generated, "
                "but sessions/tokens will not persist across restarts. "
                "Please set KeweConfig.secret_key in production.",
                RuntimeWarning,
                stacklevel=2,
            )
        
        Kewe._app_registry[name] = self
        
        self._log_level = log_level if log_level is not None else self.config.log_level
        self._access_log = access_log if access_log is not None else self.config.access_log
        self._json_log = json_log if json_log is not None else self.config.log_json
        if enable_gateway is not None:
            self.config.enable_gateway = enable_gateway
        
        self._setup_logging()
        
        self.logger = logging.getLogger(f"kewe.{name}")

        self.router = Router()
        self.router._app = self
        self._init_core()

    @property
    def secret_key(self) -> Optional[str]:
        """应用密钥

        优先使用 config.secret_key，回退到 None。
        用于 session 签名、CSRF token 等安全功能。
        """
        return getattr(self.config, 'secret_key', None)

    @secret_key.setter
    def secret_key(self, value: Optional[str]):
        if hasattr(self.config, 'secret_key'):
            self.config.secret_key = value
        else:
            self.config['secret_key'] = value
        if value and getattr(self, '_session_interface', None) is None:
            try:
                self.setup_session()
            except Exception:
                logger.debug("Non-critical operation failed", exc_info=True)

    def _init_core(self):
        self.middleware_manager = MiddlewareManager()
        self.error_handlers: Dict[int, Callable] = {}
        self._blueprints: List[Any] = []
        self._tasks: List[asyncio.Task] = []
        self._plugins: List[Any] = []
        
        from kewe.plugins.base import PluginManager
        self.plugins = PluginManager(self)
        
        from kewe.middleware.core import OnionMiddlewareChain
        self._onion_chain = OnionMiddlewareChain()
        self._asgi_stack = None
        
        self.signal_bus = None
        self._event_waiter = None
        self._signal_middleware = None
        
        self._state_manager = None
        self._ctx = None
        self._state = None
        self._shared_ctx = None
        
        self.container = Container()
        self.services = ServiceProvider(self.container)
        from kewe.application.depends import DependencyResolver, DependencyOverrideManager
        self._dependency_resolver = DependencyResolver()
        self._dependency_override_manager = DependencyOverrideManager(self._dependency_resolver)
        
        self.container.register_instance(Kewe, self)
        
        self._handler_signature_cache: Dict[int, Any] = {}
        
        self._register_default_error_handlers()
        
        self._register_auto_shutdown_handlers()
        
        if self.config.auto_request_id:
            self._register_request_id_middleware()
        
        self._register_request_body_size_middleware()
        
        if self.config.enable_security_headers:
            self._register_security_headers_middleware()
        
        self._session_interface = None
        self._services: Dict[str, Any] = {}
        self._closeable_services: List[Any] = []
        
        self._metrics_manager = None
        self._ws_manager = None
        self._cache_mgr = None
        
        if self.config.enable_gateway:
            self.gateway = get_api_gateway()
            self.gateway.bind_app(self, prefix=self.config.gateway_prefix)
            self._register_gateway_routes()
            logger.info(f"API Gateway initialized with prefix: {self.config.gateway_prefix}")
        else:
            self.gateway = None
        self._auth_manager = None
        self._error_tracker = None
        
        self._health_check_setup = False
        if getattr(self.config, 'auto_health_check', True):
            self.setup_health_checks(
                path=getattr(self.config, 'health_check_path', '/health')
            )
            self._health_check_setup = True

    def _register_gateway_routes(self):
        """注册网关路由到应用"""
        if self.gateway is None:
            return
        try:
            from kewe.gateway.adapter import register_gateway_route
            register_gateway_route(self, self.gateway, prefix=self.config.gateway_prefix)
        except Exception as e:
            logger.warning(f"Failed to register gateway routes: {e}")

    def _ensure_signal_bus(self):
        if self.signal_bus is None:
            from kewe.application.signals import SignalMiddleware, SignalBus, EventWaiter
            self.signal_bus = SignalBus()
            self._event_waiter = EventWaiter()
            self._signal_middleware = SignalMiddleware(self.signal_bus)
            self.middleware_manager.register(
                self._signal_middleware.on_request,
                attach_to="request",
                priority=0
            )
            self.middleware_manager.register(
                self._signal_middleware.on_response,
                attach_to="response",
                priority=0
            )

    def _ensure_state_manager(self):
        if self._state_manager is None:
            from kewe.application.state import ApplicationStateManager
            self._state_manager = ApplicationStateManager()
            self._ctx = self._state_manager
            from kewe.application.state_store import AppState
            self._state = AppState()

    def _ensure_shared_ctx(self):
        if self._shared_ctx is None:
            from kewe.worker.shared_ctx import SharedContext
            self._shared_ctx = SharedContext()

    def _ensure_metrics(self):
        if self._metrics_manager is None:
            from kewe.monitoring.metrics import get_metrics_manager
            self._metrics_manager = get_metrics_manager()
            self._services['metrics'] = self._metrics_manager

    def _ensure_ws_manager(self):
        if self._ws_manager is None:
            from kewe.websocket import get_websocket_manager
            self._ws_manager = get_websocket_manager()
            self._services['websocket_manager'] = self._ws_manager
            self._closeable_services.append(self._ws_manager)

    def _ensure_cache_mgr(self):
        if self._cache_mgr is None:
            from kewe.cache import CacheManager
            self._cache_mgr = CacheManager()
            self._services['cache_manager'] = self._cache_mgr
            self._closeable_services.append(self._cache_mgr)

    @property
    def error_tracker(self):
        """错误追踪器 — 懒初始化

        使用示例:
            app.error_tracker.add_reporter(WebhookReporter(url))
            # 异常自动被追踪
        """
        if self._error_tracker is None:
            from kewe.errors.tracker import ErrorTracker
            self._error_tracker = ErrorTracker()
        return self._error_tracker

    @property
    def auth(self):
        """认证管理器 — 懒初始化

        使用示例:
            @app.auth.login_required
            async def protected(request):
                return json({"user": request.user})

            @app.auth.roles_required("admin")
            async def admin_only(request):
                return json({"ok": True})
        """
        if self._auth_manager is None:
            from kewe.security.auth import AuthManager
            self._auth_manager = AuthManager(self)
        return self._auth_manager
    
    def _register_request_id_middleware(self):
        """注册请求ID中间件"""
        from kewe.middleware.core import RequestIDMiddleware, OnionMiddleware

        request_id_middleware = RequestIDMiddleware(
            header_name=self.config.request_id_header,
            response_header=self.config.request_id_header,
            format=self.config.request_id_format
        )

        async def request_id_onion(request, call_next):
            await request_id_middleware(request)
            response = await call_next(request)
            await request_id_middleware.response(request, response)
            return response

        self._onion_chain.add(OnionMiddleware(request_id_onion, priority=0))
        logger.debug(f"Request ID middleware registered (header: {self.config.request_id_header}, format: {self.config.request_id_format})")
    
    def _register_request_body_size_middleware(self):
        """注册请求体大小校验中间件"""
        
        @self.middleware("request", priority=MiddlewarePriority.HIGHEST.value + 1)
        async def check_request_body_size(request):
            content_length = request.headers.get('content-length')
            if not content_length:
                return True
            
            try:
                body_size = int(content_length)
            except (ValueError, TypeError):
                return True
            
            content_type = request.headers.get('content-type', '').lower()
            
            if 'application/json' in content_type:
                max_size = self.config.request_max_size_json
            elif 'multipart/form-data' in content_type:
                max_size = self.config.request_max_size_multipart
            elif 'application/x-www-form-urlencoded' in content_type:
                max_size = self.config.request_max_size_form
            else:
                max_size = self.config.request_max_size
            
            if body_size > max_size:
                from kewe.errors.exceptions import PayloadTooLarge
                raise PayloadTooLarge(
                    f"Request body too large: {body_size} bytes exceeds {max_size} bytes limit"
                )
            
            return True
    
    def _register_security_headers_middleware(self):
        from kewe.middleware.core import SecurityHeadersMiddleware, OnionMiddleware
        middleware = SecurityHeadersMiddleware()
        async def security_headers_onion(request, call_next):
            response = await call_next(request)
            await middleware.response(request, response)
            return response
        self._onion_chain.add(OnionMiddleware(security_headers_onion, priority=100))
    
    @property
    def shared_ctx(self):
        """跨 Worker 共享上下文"""
        self._ensure_shared_ctx()
        return self._shared_ctx
    
    @property
    def ctx(self):
        """应用上下文"""
        self._ensure_state_manager()
        return self._ctx
    
    @ctx.setter
    def ctx(self, value):
        self._ctx = value
    
    @property
    def state(self):
        """应用状态"""
        self._ensure_state_manager()
        return self._state
    
    @state.setter
    def state(self, value):
        self._state = value
    
    @property
    def debug(self) -> bool:
        """调试模式 — 便捷属性"""
        return self.config.debug
    
    @debug.setter
    def debug(self, value: bool):
        self.config.debug = value
    
    @property
    def is_running(self) -> bool:
        """应用是否正在运行"""
        self._ensure_state_manager()
        return getattr(self._state_manager, 'is_running', False)

    @property
    def blueprints(self) -> Dict[str, Any]:
        """已注册的蓝图

        返回 {name: blueprint} 的字典。
        """
        return {bp.name: bp for bp in self._blueprints if hasattr(bp, 'name')}

    async def stop(self):
        """程序化停止应用"""
        self._ensure_state_manager()
        if hasattr(self._state_manager, 'stop'):
            await self._state_manager.stop()
        self._running = False

    async def maybe_start(self, **kwargs):
        """如果未启动则启动"""
        if not self.is_running:
            await self.run(**kwargs)

    @property
    def metrics(self):
        """指标管理器"""
        self._ensure_metrics()
        return self._metrics_manager
    
    def get_service(self, name: str, default: Any = None) -> Any:
        """获取已注册的服务"""
        return self._services.get(name, default)
    
    def register_internal_service(self, name: str, service: Any) -> None:
        """注册内部服务到应用"""
        self._services[name] = service
    
    @property
    def repl_ctx(self):
        """REPL 上下文"""
        if not hasattr(self, '_repl_ctx'):
            from kewe.cli.repl import REPLContextManager
            self._repl_ctx = REPLContextManager(self)
        return self._repl_ctx
    
    async def event(self, event_name: str, timeout: Optional[float] = None) -> Any:
        """等待事件触发"""
        self._ensure_signal_bus()
        return await self._event_waiter.wait_for(event_name, timeout)
    
    def signal(
        self,
        event: str,
        priority: int = 50,
        condition: Optional[Callable] = None
    ) -> Callable:
        """注册信号处理器装饰器"""
        self._ensure_signal_bus()
        from kewe.application.signals import DynamicSignal
        
        if '<' in event and '>' in event:
            if not hasattr(self, '_dynamic_signals'):
                self._dynamic_signals: Dict[str, DynamicSignal] = {}
            
            if event not in self._dynamic_signals:
                self._dynamic_signals[event] = DynamicSignal(event)
            
            def decorator(func: Callable) -> Callable:
                self._dynamic_signals[event].add_handler(func, priority, condition=condition)
                return func
            return decorator
        
        return self.signal_bus.on(event, priority=priority, condition=condition)
    
    async def dispatch(self, event: str, data: Dict[str, Any] = None):
        """触发信号"""
        self._ensure_signal_bus()
        if self._event_waiter:
            self._event_waiter.notify(event, data)
        
        if hasattr(self, '_dynamic_signals'):
            for pattern, dynamic_signal in self._dynamic_signals.items():
                await dynamic_signal.emit(event, data)
        
        await self.signal_bus.emit(event, data)
    
    def _setup_logging(self) -> None:
        """设置日志系统"""
        from kewe.logging.setup import setup_logging
        
        setup_logging(
            level=self._log_level,
            json_format=self._json_log,
            access_log=self._access_log
        )
        
        logger.debug(f"Logging configured: level={logging.getLevelName(self._log_level)}, "
                    f"access_log={self._access_log}, json={self._json_log}")
    
    @classmethod
    def get_current(cls) -> Optional['Kewe']:
        """获取当前应用实例"""
        return cls._current_app
    
    def set_current(self):
        """设置为当前应用实例"""
        Kewe._current_app = self
    
    def run(
        self,
        host: str = "0.0.0.0",
        port: int = 8000,
        debug: bool = False,
        reload: bool = False,
        workers: int = 1,
        ssl_context=None,
        backlog: int = 100,
        request_timeout: float = 60.0,
        keep_alive_timeout: float = 5.0,
        request_max_size: int = 100 * 1024 * 1024,
        max_connections: int = 10000,
        graceful_shutdown_timeout: float = 30.0,
        access_log: bool = True,
        motd: bool = True,
        noisy_exceptions: bool = False,
        http_version: str = "1.1",
        http3_port: int = None,
        certfile: str = None,
        keyfile: str = None,
    ):
        """
        启动Kewe服务器

        Args:
            host: 监听地址
            port: 监听端口
            debug: 调试模式（启用详细日志、自动重载）
            reload: 自动重载（文件变更时重启）
            workers: 工作进程数
            ssl_context: SSL上下文
            backlog: TCP backlog
            request_timeout: 请求超时时间(秒)
            keep_alive_timeout: Keep-Alive超时时间(秒)
            request_max_size: 请求最大大小(字节)
            max_connections: 最大连接数
            graceful_shutdown_timeout: 优雅关闭超时时间(秒)
        """
        if debug:
            self.config.debug = True
            reload = reload or True
            import logging
            logging.getLogger("kewe").setLevel(logging.DEBUG)

        if reload and workers == 1:
            from kewe.server.reloader import RestartManager, ReloadConfig
            restart_mgr = RestartManager(self)
            watch_dirs = ['.']
            restart_mgr.setup(
                enable_hot_reload=True,
                config=ReloadConfig(watch_dirs=watch_dirs, interval=1.0),
            )
            logger.info(f"Auto-reload enabled, watching: {watch_dirs}")

        from kewe.server.http_server import KeweServer
        
        from kewe.application.state import AppState
        self._ensure_state_manager()
        self._state_manager.transition_to(
            AppState.INIT,
            "Application starting via run()"
        )

        # Display MOTD / Logo banner
        if motd:
            from kewe.application.logo import display_motd, get_runtime_info
            protocol = "https" if ssl_context else "http"
            serve_location = f"{protocol}://{host}:{port}"
            runtime_info = get_runtime_info()
            motd_data = {
                "mode": "debug" if debug else "production",
                "server": "kewe, HTTP/1.1",
                "python": runtime_info.get("python", "unknown"),
            }
            if workers > 1:
                motd_data["workers"] = str(workers)
            display_motd(serve_location, data=motd_data, full=True)
        
        if workers > 1:
            import socket
            import tempfile
            import pickle
            import os
            
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind((host, port))
            sock.listen(backlog)
            sock.setblocking(False)
            
            self.set_current()
            tmp_fd, tmp_path = tempfile.mkstemp(suffix='.kewe', prefix='app_')
            try:
                with os.fdopen(tmp_fd, 'wb') as f:
                    pickle.dump(self, f)
                os.environ['_KEWE_APP_PICKLE'] = tmp_path
            except Exception:
                try:
                    os.close(tmp_fd)
                except OSError:
                    pass
                os.unlink(tmp_path)
                raise
            
            import multiprocessing
            processes = []
            for i in range(workers):
                p = multiprocessing.Process(
                    target=self._run_worker,
                    args=(sock, ssl_context, request_timeout,
                          keep_alive_timeout, request_max_size, max_connections,
                          graceful_shutdown_timeout),
                    daemon=True,
                )
                p.start()
                processes.append(p)
            try:
                for p in processes:
                    p.join()
            except KeyboardInterrupt:
                for p in processes:
                    p.terminate()
            finally:
                sock.close()
                try:
                    os.unlink(tmp_path)
                except OSError:
                    pass
                os.environ.pop('_KEWE_APP_PICKLE', None)
        else:
            server = KeweServer(
                app=self,
                host=host,
                port=port,
                request_timeout=request_timeout,
                keep_alive_timeout=keep_alive_timeout,
                request_max_size=request_max_size,
                backlog=backlog,
                ssl_context=ssl_context,
                max_connections=max_connections,
                graceful_shutdown_timeout=graceful_shutdown_timeout,
            )
            if getattr(self.config, 'use_uvloop', True):
                try:
                    from kewe.utils.compat import auto_select_event_loop
                    auto_select_event_loop()
                except Exception:
                    logger.debug("Non-critical operation failed", exc_info=True)

            async def _start_with_http2_http3():
                await server.start()
                if http_version == "2":
                    try:
                        from kewe.http.http2 import create_http2_server, is_http2_available
                        if is_http2_available() and ssl_context:
                            h2_server = await create_http2_server(
                                self, host=host, port=port, ssl_context=ssl_context
                            )
                            logger.info(f"HTTP/2 server started on https://{host}:{port}")
                    except ImportError:
                        logger.warning("HTTP/2 requested but h2 not installed. Run: pip install h2")

                if http3_port:
                    try:
                        from kewe.http.http3 import create_http3_server, is_http3_available
                        if is_http3_available():
                            _cert = certfile or (ssl_context.get('certfile') if isinstance(ssl_context, dict) else None)
                            _key = keyfile or (ssl_context.get('keyfile') if isinstance(ssl_context, dict) else None)
                            if _cert and _key:
                                await create_http3_server(
                                    self, host=host, port=http3_port,
                                    certfile=_cert, keyfile=_key
                                )
                                logger.info(f"HTTP/3 server started on https://{host}:{http3_port}")
                            else:
                                logger.warning("HTTP/3 requires SSL certfile and keyfile")
                    except ImportError:
                        logger.warning("HTTP/3 requested but aioquic not installed. Run: pip install aioquic")

            asyncio.run(_start_with_http2_http3())
    
    @staticmethod
    def _run_worker(sock, ssl_context, request_timeout,
                    keep_alive_timeout, request_max_size, max_connections,
                    graceful_shutdown_timeout):
        from kewe.server.http_server import KeweServer
        app = Kewe._current_app
        if app is None:
            import pickle
            import os
            serialized_path = os.environ.get('_KEWE_APP_PICKLE')
            if serialized_path and os.path.exists(serialized_path):
                with open(serialized_path, 'rb') as f:
                    app = pickle.load(f)
        if app is None:
            import sys
            sys.stderr.write("Fatal: Could not retrieve app instance in worker process. "
                             "On Windows, use workers=1 or use the ASGI server (uvicorn) directly.\n")
            sys.exit(1)
        server = KeweServer(
            app=app,
            host=None,
            port=None,
            request_timeout=request_timeout,
            keep_alive_timeout=keep_alive_timeout,
            request_max_size=request_max_size,
            backlog=100,
            ssl_context=ssl_context,
            max_connections=max_connections,
            graceful_shutdown_timeout=graceful_shutdown_timeout,
            sock=sock,
        )
        if getattr(app.config, 'use_uvloop', True):
            try:
                from kewe.utils.compat import auto_select_event_loop
                auto_select_event_loop()
            except Exception:
                logger.debug("Non-critical operation failed", exc_info=True)
        asyncio.run(server.start())
    
    def _register_default_error_handlers(self):
        def _problem(data, status):
            resp = _json_resp(data, status=status)
            resp.content_type = 'application/problem+json'
            return resp

        @self.exception(404)
        async def not_found_handler(request, exception):
            return _problem(exception.to_problem_details(request.path), 404)
        
        @self.exception(500)
        async def server_error_handler(request, exception):
            return _problem(exception.to_problem_details(request.path), 500)
        
        @self.exception(400)
        async def bad_request_handler(request, exception):
            return _problem(exception.to_problem_details(request.path), 400)
        
        @self.exception(401)
        async def unauthorized_handler(request, exception):
            response = _problem(exception.to_problem_details(request.path), 401)
            if hasattr(exception, 'www_authenticate') and exception.www_authenticate:
                response.headers['WWW-Authenticate'] = exception.www_authenticate
            return response
        
        @self.exception(403)
        async def forbidden_handler(request, exception):
            return _problem(exception.to_problem_details(request.path), 403)
        
        @self.exception(405)
        async def method_not_allowed_handler(request, exception):
            response = _problem(exception.to_problem_details(request.path), 405)
            if hasattr(exception, 'allowed_methods') and exception.allowed_methods:
                response.headers['Allow'] = ', '.join(exception.allowed_methods)
            return response

        @self.exception(408)
        async def request_timeout_handler(request, exception):
            return _problem(exception.to_problem_details(request.path), 408)

        @self.exception(409)
        async def conflict_handler(request, exception):
            return _problem(exception.to_problem_details(request.path), 409)

        @self.exception(410)
        async def gone_handler(request, exception):
            return _problem(exception.to_problem_details(request.path), 410)

        @self.exception(412)
        async def precondition_failed_handler(request, exception):
            return _problem(exception.to_problem_details(request.path), 412)

        @self.exception(413)
        async def payload_too_large_handler(request, exception):
            return _problem(exception.to_problem_details(request.path), 413)

        @self.exception(415)
        async def unsupported_media_type_handler(request, exception):
            return _problem(exception.to_problem_details(request.path), 415)

        @self.exception(429)
        async def too_many_requests_handler(request, exception):
            response = _problem(exception.to_problem_details(request.path), 429)
            if hasattr(exception, 'retry_after') and exception.retry_after:
                response.headers['Retry-After'] = str(exception.retry_after)
            return response

        @self.exception(422)
        async def unprocessable_entity_handler(request, exception):
            response_data = exception.to_problem_details(request.path)
            if hasattr(exception, 'errors_list') and callable(exception.errors_list):
                try:
                    response_data['errors'] = exception.errors_list()
                except Exception:
                    logger.debug("Non-critical operation failed", exc_info=True)
            return _problem(response_data, 422)

        @self.exception(502)
        async def bad_gateway_handler(request, exception):
            return _problem(exception.to_problem_details(request.path), 502)

        @self.exception(503)
        async def service_unavailable_handler(request, exception):
            response = _problem(exception.to_problem_details(request.path), 503)
            if hasattr(exception, 'retry_after') and exception.retry_after:
                response.headers['Retry-After'] = str(exception.retry_after)
            return response

        @self.exception(504)
        async def gateway_timeout_handler(request, exception):
            return _problem(exception.to_problem_details(request.path), 504)

        @self.exception(511)
        async def network_auth_required_handler(request, exception):
            return _problem(exception.to_problem_details(request.path), 511)

        @self.exception(Exception)
        async def generic_exception_handler(request, exception):
            if isinstance(exception, KeweException):
                return _problem(exception.to_problem_details(request.path), exception.status_code)
            if isinstance(exception, InternalServerError):
                return _problem(exception.to_problem_details(request.path), 500)
            detail = str(exception) if self.config.debug else "An internal error occurred. Please try again later."
            return _problem({
                "type": "about:blank",
                "title": "Internal Server Error",
                "status": 500,
                "detail": detail,
                "instance": request.path,
            }, 500)
    
    def _register_plugin(self, plugin):
        """注册插件"""
        self._plugins.append(plugin)
    
    def route(
        self,
        path: str,
        methods: Optional[List[str]] = None,
        *,
        name: Optional[str] = None,
        endpoint: Optional[str] = None,
        host: Optional[str] = None,
        strict_slashes: bool = False,
        middlewares: Optional[List[Callable]] = None,
        version: Optional[Union[int, str]] = None,
        version_prefix: str = "v",
        dependencies: Optional[List[Callable]] = None,
        response_model: Optional[type] = None,
        status_code: Optional[int] = None,
        tags: Optional[List[str]] = None,
        responses: Optional[Dict[Union[int, str], Dict[str, Any]]] = None,
        summary: Optional[str] = None,
        description: Optional[str] = None,
        deprecated: bool = False,
        operation_id: Optional[str] = None,
        **kwargs
    ) -> Callable[[Callable], Callable]:
        """路由装饰器（自动检测 Pydantic 模型并绑定验证）
        
        Args:
            path: 路由路径
            methods: HTTP 方法列表
            name: 路由名称
            host: 主机限制
            strict_slashes: 是否严格斜杠
            middlewares: 路由级中间件
            version: API 版本
            version_prefix: 版本前缀
            dependencies: 路由级依赖列表 (dependencies 参数)
            response_model: 响应模型 (response_model 参数)
            status_code: 默认成功状态码 (status_code 参数)
            tags: OpenAPI 分组标签列表 (tags 参数)
            responses: OpenAPI 额外响应声明 (responses 参数)
            summary: OpenAPI 摘要
            description: OpenAPI 描述
            deprecated: 是否已弃用
        """
        if version is not None:
            path = f"/{version_prefix}{version}{path}"

        route_name = endpoint or name
        
        def decorator(handler: Callable) -> Callable:
            original_handler = handler
            pydantic_body_type = self._detect_pydantic_model(handler)
            
            if pydantic_body_type is not None:
                handler = self._wrap_with_pydantic_validation(handler, pydantic_body_type)
            
            if dependencies:
                handler = self._wrap_with_dependencies(handler, dependencies)
            
            if response_model is not None:
                handler = self._wrap_with_response_model(handler, response_model)

            if status_code is not None:
                handler._default_status_code = status_code

            if operation_id is not None:
                handler._operation_id = operation_id
            
            self.router.add_route(
                path=path,
                methods=methods or ["GET"],
                handler=handler,
                name=route_name,
                host=host,
                strict_slashes=strict_slashes,
                middlewares=middlewares,
                response_model=response_model,
                status_code=status_code,
                summary=summary,
                description=description,
                deprecated=deprecated,
                **kwargs
            )
            
            openapi_plugin = getattr(self, '_openapi_plugin', None)
            if openapi_plugin and hasattr(openapi_plugin, 'collect_route_info'):
                openapi_kwargs = dict(kwargs)
                if response_model is not None:
                    openapi_kwargs['response_model'] = response_model
                if tags is not None:
                    openapi_kwargs['tags'] = tags
                if responses is not None:
                    openapi_kwargs['responses'] = responses
                if status_code is not None:
                    openapi_kwargs['status_code'] = status_code
                if summary is not None:
                    openapi_kwargs['summary'] = summary
                if description is not None:
                    openapi_kwargs['description'] = description
                if deprecated:
                    openapi_kwargs['deprecated'] = deprecated
                if operation_id is not None:
                    openapi_kwargs['operation_id'] = operation_id
                if not hasattr(self, '_openapi_hook_registered'):
                    openapi_plugin.collect_route_info(
                        path=path,
                        methods=methods or ["GET"],
                        handler=handler,
                        **openapi_kwargs
                    )
            
            if pydantic_body_type is not None:
                self._register_pydantic_openapi_schema(path, methods or ["GET"], handler, pydantic_body_type)

            return handler
        return decorator
    
    def get(self, path: str, **kwargs) -> Callable:
        """快捷GET路由"""
        return self.route(path, methods=["GET"], **kwargs)
    
    def post(self, path: str, **kwargs) -> Callable:
        """快捷POST路由"""
        return self.route(path, methods=["POST"], **kwargs)
    
    def put(self, path: str, **kwargs) -> Callable:
        """快捷PUT路由"""
        return self.route(path, methods=["PUT"], **kwargs)
    
    def delete(self, path: str, **kwargs) -> Callable:
        """快捷DELETE路由"""
        return self.route(path, methods=["DELETE"], **kwargs)
    
    def patch(self, path: str, **kwargs) -> Callable:
        """快捷PATCH路由"""
        return self.route(path, methods=["PATCH"], **kwargs)
    
    def head(self, path: str, **kwargs) -> Callable:
        """快捷HEAD路由"""
        return self.route(path, methods=["HEAD"], **kwargs)
    
    def options(self, path: str, **kwargs) -> Callable:
        """快捷OPTIONS路由"""
        return self.route(path, methods=["OPTIONS"], **kwargs)
    
    def add_api_route(
        self,
        path: str,
        endpoint: Callable,
        *,
        methods: Optional[List[str]] = None,
        name: Optional[str] = None,
        tags: Optional[List[str]] = None,
        dependencies: Optional[List[Callable]] = None,
        response_model: Optional[type] = None,
        status_code: Optional[int] = None,
        summary: Optional[str] = None,
        description: Optional[str] = None,
        responses: Optional[Dict] = None,
        deprecated: bool = False,
        **kwargs
    ) -> None:
        """程序化路由注册（非装饰器风格）

        与 @app.route() 功能相同，但以函数调用方式注册路由，
        无需使用装饰器。add_api_route() 接口。
        """
        self.route(
            path,
            methods=methods,
            name=name,
            tags=tags,
            summary=summary,
            description=description,
            deprecated=deprecated,
            response_model=response_model,
            status_code=status_code,
            **kwargs
        )(endpoint)
        if dependencies:
            endpoint._route_dependencies = dependencies
        if responses:
            endpoint._route_responses = responses

    def websocket(self, path: str, *, name: Optional[str] = None,
                  subprotocols: Optional[List[str]] = None,
                  dependencies: Optional[List[Callable]] = None, **kwargs) -> Callable:
        """WebSocket路由装饰器

        Args:
            path: WebSocket路径
            name: 路由名称（用于 url_for）
            subprotocols: WebSocket 子协议列表
            dependencies: 路由级依赖列表

        使用示例:
            @app.websocket("/ws")
            async def ws_handler(websocket):
                await websocket.accept()
                data = await websocket.receive()
                await websocket.send("Hello!")
                await websocket.close()
        """
        def decorator(handler: Callable) -> Callable:
            handler._is_websocket = True
            handler._websocket_path = path
            handler._websocket_kwargs = kwargs
            if name:
                kwargs['name'] = name
            if subprotocols:
                kwargs['subprotocols'] = subprotocols
            if dependencies:
                handler._websocket_dependencies = dependencies
            self.router.add_websocket_route(path, handler, **kwargs)
            return handler
        return decorator
    
    def _wrap_with_dependencies(self, handler: Callable, dependencies: List[Callable]) -> Callable:
        """包装处理函数，在调用前执行依赖链
        
        dependencies 参数实现，支持 Depends 对象和普通函数。
        """
        import functools
        import inspect
        from kewe.application.depends import Depends as _Depends, DependencyResolver as _DR

        plain_deps = []
        depends_deps = []
        for dep in dependencies:
            if isinstance(dep, _Depends):
                depends_deps.append(dep)
            else:
                plain_deps.append(dep)

        if depends_deps:
            handler._route_dependencies = depends_deps

        @functools.wraps(handler)
        async def wrapped(request, *args, **kwargs):
            for dep in plain_deps:
                if inspect.iscoroutinefunction(dep):
                    result = await dep(request)
                else:
                    result = dep(request)
                
                if result is not None:
                    if isinstance(result, dict):
                        kwargs.update(result)
                    elif hasattr(request, 'ctx'):
                        if hasattr(result, '__dict__'):
                            for k, v in result.__dict__.items():
                                if not k.startswith('_'):
                                    setattr(request.ctx, k, v)
                        else:
                            setattr(request.ctx, type(result).__name__.lower(), result)
            
            return await handler(request, *args, **kwargs) if inspect.iscoroutinefunction(handler) else handler(request, *args, **kwargs)
        
        return wrapped
    
    def _wrap_with_response_model(self, handler: Callable, response_model: type) -> Callable:
        """包装处理函数，自动将返回值序列化为指定模型 - response_model

        核心功能：
        - 自动过滤响应数据，只保留response_model定义的字段
        - 验证失败时不影响原始响应（graceful degradation）
        - 支持dict/list/BaseModel实例/Response对象
        - 默认exclude_unset=True
        """
        import functools
        import inspect

        @functools.wraps(handler)
        async def wrapped(request, *args, **kwargs):
            result = await handler(request, *args, **kwargs) if inspect.iscoroutinefunction(handler) else handler(request, *args, **kwargs)

            try:
                from kewe.plugins.pydantic_support import filter_response_with_model, PYDANTIC_AVAILABLE
                if not PYDANTIC_AVAILABLE:
                    return result
            except ImportError:
                return result

            if isinstance(result, Response):
                try:
                    body_data = _json.loads(result.body) if isinstance(result.body, bytes) else None
                    if isinstance(body_data, dict):
                        filtered = filter_response_with_model(body_data, response_model)
                        result.body = _json.dumps(filtered).encode('utf-8')
                    elif isinstance(body_data, list):
                        filtered = filter_response_with_model(body_data, response_model)
                        result.body = _json.dumps(filtered).encode('utf-8')
                except Exception:
                    logger.debug("Non-critical operation failed", exc_info=True)
                return result

            if isinstance(result, dict):
                try:
                    filtered = filter_response_with_model(result, response_model)
                    from kewe.response import json as json_resp
                    return json_resp(filtered)
                except Exception:
                    return result

            if isinstance(result, list):
                try:
                    filtered = filter_response_with_model(result, response_model)
                    from kewe.response import json as json_resp
                    return json_resp(filtered)
                except Exception:
                    return result

            return result

        return wrapped
    
    def _detect_pydantic_model(self, handler: Callable) -> Optional[type]:
        """自动检测处理函数参数中的 Pydantic Body 模型

        仅检测需要 _wrap_with_pydantic_validation 包装的 body 模型。
        PathModel/QueryModel/HeaderModel 由 _invoke_handler_with_injection
        的 pydantic_markers 分支处理，不需要额外包装。
        """
        import inspect
        try:
            from pydantic import BaseModel
        except ImportError:
            return None

        from kewe.plugins.pydantic_support import BodyModel, QueryModel, HeaderModel, PathModel

        sig = inspect.signature(handler)
        try:
            type_hints = inspect.get_annotations(handler) if hasattr(inspect, 'get_annotations') else {}
        except Exception:
            return None

        for name, param in sig.parameters.items():
            if name in ('request', 'req', 'self'):
                continue

            param_type = type_hints.get(name)
            if param_type is None:
                param_type = param.annotation if param.annotation is not inspect.Parameter.empty else None

            if param_type is not None:
                if isinstance(param.default, (QueryModel, HeaderModel, PathModel)):
                    continue

                try:
                    if isinstance(param_type, type) and issubclass(param_type, BaseModel):
                        return param_type
                except TypeError:
                    pass

                if isinstance(param.default, BodyModel):
                    return param_type

        return None

    def _detect_pydantic_model_sources(self, handler: Callable) -> Dict[str, tuple]:
        """检测所有Pydantic模型参数及其来源（body/query/path/header）

        Returns:
            Dict[param_name, (model_type, source_marker)]
            source_marker: 'body'|'query'|'path'|'header'|'auto'
        """
        import inspect
        try:
            from pydantic import BaseModel
        except ImportError:
            return {}

        from kewe.plugins.pydantic_support import BodyModel, QueryModel, HeaderModel, PathModel

        actual_handler = handler
        while hasattr(actual_handler, '__wrapped__'):
            actual_handler = actual_handler.__wrapped__

        sig = inspect.signature(actual_handler)
        try:
            type_hints = inspect.get_annotations(actual_handler) if hasattr(inspect, 'get_annotations') else {}
        except Exception:
            return {}

        result = {}
        for name, param in sig.parameters.items():
            if name in ('request', 'req', 'self'):
                continue

            param_type = type_hints.get(name)
            if param_type is None:
                param_type = param.annotation if param.annotation is not inspect.Parameter.empty else None

            if param_type is None:
                continue

            is_basemodel = False
            try:
                if isinstance(param_type, type) and issubclass(param_type, BaseModel):
                    is_basemodel = True
            except TypeError:
                pass

            if not is_basemodel:
                continue

            if isinstance(param.default, BodyModel):
                result[name] = (param_type, 'body', param.default)
            elif isinstance(param.default, QueryModel):
                result[name] = (param_type, 'query', param.default)
            elif isinstance(param.default, HeaderModel):
                result[name] = (param_type, 'header', param.default)
            elif isinstance(param.default, PathModel):
                result[name] = (param_type, 'path', param.default)
            else:
                result[name] = (param_type, 'auto', None)

        return result
    
    def _wrap_with_pydantic_validation(self, handler: Callable, model_type: type) -> Callable:
        """用 Pydantic 验证包装处理函数 - 支持多来源模型注入和标准422错误"""
        import inspect
        import functools
        from kewe.plugins.pydantic_support import (
            _format_validation_errors, _create_422_response,
            BodyModel, QueryModel, HeaderModel, PathModel,
            extract_query_model, extract_header_model, extract_path_model,
        )

        model_sources = self._detect_pydantic_model_sources(handler)

        @functools.wraps(handler)
        async def wrapped(request: Request, **kwargs):
            all_errors: list = []
            handler_kwargs = {}
            sig = inspect.signature(handler)
            params = list(sig.parameters.keys())

            for p in params:
                if p in ('request', 'req'):
                    handler_kwargs[p] = request
                    continue

                if p in model_sources:
                    model_cls, source, marker = model_sources[p]
                    strict = getattr(marker, 'strict', False) if marker else False
                    context = getattr(marker, 'context', None) if marker else None

                    if source == 'body' or (source == 'auto' and request.method in ('POST', 'PUT', 'PATCH')):
                        try:
                            body = await request.json_async
                            if hasattr(model_cls, 'model_validate'):
                                validated = model_cls.model_validate(body or {}, strict=strict, context=context)
                            else:
                                validated = model_cls(**(body or {}))
                            handler_kwargs[p] = validated
                        except Exception as e:
                            if hasattr(e, 'errors'):
                                for err in _format_validation_errors(e):
                                    err['loc'] = ['body'] + err['loc']
                                    all_errors.append(err)
                            else:
                                all_errors.append({'loc': ['body'], 'msg': str(e), 'type': 'value_error'})

                    elif source == 'query' or (source == 'auto' and request.method not in ('POST', 'PUT', 'PATCH')):
                        try:
                            handler_kwargs[p] = extract_query_model(request, model_cls, strict=strict)
                        except Exception as e:
                            if hasattr(e, 'errors'):
                                for err in _format_validation_errors(e):
                                    err['loc'] = ['query'] + err['loc']
                                    all_errors.append(err)
                            else:
                                all_errors.append({'loc': ['query'], 'msg': str(e), 'type': 'value_error'})

                    elif source == 'header':
                        try:
                            handler_kwargs[p] = extract_header_model(request, model_cls, strict=strict)
                        except Exception as e:
                            if hasattr(e, 'errors'):
                                for err in _format_validation_errors(e):
                                    err['loc'] = ['header'] + err['loc']
                                    all_errors.append(err)
                            else:
                                all_errors.append({'loc': ['header'], 'msg': str(e), 'type': 'value_error'})

                    elif source == 'path':
                        try:
                            handler_kwargs[p] = extract_path_model(request, model_cls, kwargs, strict=strict)
                        except Exception as e:
                            if hasattr(e, 'errors'):
                                for err in _format_validation_errors(e):
                                    err['loc'] = ['path'] + err['loc']
                                    all_errors.append(err)
                            else:
                                all_errors.append({'loc': ['path'], 'msg': str(e), 'type': 'value_error'})
                else:
                    handler_kwargs[p] = kwargs.get(p)

            if all_errors:
                return _create_422_response(all_errors)

            return await handler(**handler_kwargs)

        wrapped.__name__ = getattr(handler, '__name__', 'wrapped')
        wrapped.__annotations__ = getattr(handler, '__annotations__', {})
        wrapped._kewe_pydantic_validated = True
        wrapped._kewe_pydantic_params = set(model_sources.keys())
        return wrapped
    
    def _register_pydantic_openapi_schema(self, path: str, methods: List[str], handler: Callable, model_type: type):
        if not self.gateway:
            return
        
        try:
            from kewe.plugins.openapi import get_openapi_plugin
            plugin = get_openapi_plugin()
            if plugin:
                schema = model_type.model_json_schema()
                schema_name = model_type.__name__
                plugin.add_schema(schema_name, schema)
        except (ImportError, Exception):
            logger.debug("Non-critical operation failed", exc_info=True)

    @property
    def openapi_url(self) -> str:
        return getattr(self, '_openapi_url', '/openapi.json')

    @openapi_url.setter
    def openapi_url(self, value: str):
        self._openapi_url = value

    @property
    def docs_url(self) -> str:
        return getattr(self, '_docs_url', '/docs')

    @docs_url.setter
    def docs_url(self, value: str):
        self._docs_url = value

    @property
    def openapi_schema(self) -> Optional[Dict[str, Any]]:
        if hasattr(self, '_openapi_plugin') and self._openapi_plugin is not None:
            return self._openapi_plugin.generate_spec()
        return None

    @openapi_schema.setter
    def openapi_schema(self, value):
        if hasattr(self, '_openapi_plugin') and self._openapi_plugin is not None:
            self._openapi_plugin._spec_cache = value
            self._openapi_plugin._spec_dirty = value is None

    def handle_exception(self, request, exception):
        return self._handle_exception(request, exception)

    def setup_openapi(self, **config):
        from kewe.plugins.base import register_plugin
        from kewe.plugins.openapi import OpenAPIPlugin
        register_plugin(self, OpenAPIPlugin, **config)
        return self._openapi_plugin

    def openapi(self, config: Optional[Dict[str, Any]] = None) -> 'OpenAPIPlugin':
        if not hasattr(self, '_openapi_plugin') or self._openapi_plugin is None:
            from kewe.plugins.base import register_plugin
            from kewe.plugins.openapi import OpenAPIPlugin
            register_plugin(self, OpenAPIPlugin, **(config or {}))
        return self._openapi_plugin
    
    def before_server_start(
        self,
        func: Callable = None,
        *,
        priority: int = 0
    ) -> Callable:
        """服务器启动前钩子"""
        def decorator(f: Callable) -> Callable:
            self.middleware_manager.register_before_server_start(f, priority=priority)
            return f
        
        if func is not None:
            return decorator(func)
        return decorator
    
    def after_server_start(
        self,
        func: Callable = None,
        *,
        priority: int = 0
    ) -> Callable:
        """服务器启动后钩子"""
        def decorator(f: Callable) -> Callable:
            self.middleware_manager.register_after_server_start(f, priority=priority)
            return f
        
        if func is not None:
            return decorator(func)
        return decorator
    
    def before_server_stop(
        self,
        func: Callable = None,
        *,
        priority: int = 0
    ) -> Callable:
        """服务器停止前钩子"""
        def decorator(f: Callable) -> Callable:
            self.middleware_manager.register_before_server_stop(f, priority=priority)
            return f
        
        if func is not None:
            return decorator(func)
        return decorator
    
    def after_server_stop(
        self,
        func: Callable = None,
        *,
        priority: int = 0
    ) -> Callable:
        def decorator(f: Callable) -> Callable:
            self.middleware_manager.register_after_server_stop(f, priority=priority)
            return f
        
        if func is not None:
            return decorator(func)
        return decorator

    def on_request_cancelled(self, func: Callable) -> Callable:
        self._on_request_cancelled = func
        return func

    def register_listener(self, event: str, handler: Callable = None, *, priority: int = 0):
        """注册生命周期监听器
        
        支持装饰器和函数式两种用法:
            @app.listener("before_server_start")
            async def on_startup(app, loop):
                ...
            
            app.register_listener("after_server_start", on_startup)
        """
        event_map = {
            'before_server_start': self.middleware_manager.register_before_server_start,
            'after_server_start': self.middleware_manager.register_after_server_start,
            'before_server_stop': self.middleware_manager.register_before_server_stop,
            'after_server_stop': self.middleware_manager.register_after_server_stop,
        }
        register_fn = event_map.get(event)
        if register_fn is None:
            raise ValueError(f"Unknown event '{event}', must be one of: {list(event_map.keys())}")
        
        if handler is not None:
            register_fn(handler, priority=priority)
            return handler
        
        def decorator(func: Callable) -> Callable:
            register_fn(func, priority=priority)
            return func
        return decorator
    
    def register_blueprint(
        self,
        blueprint: 'Blueprint',
        *,
        url_prefix: Optional[str] = None
    ) -> 'Kewe':
        from kewe.routing.blueprint_group import BlueprintGroup
        if isinstance(blueprint, BlueprintGroup):
            for bp in blueprint._blueprints:
                combined_prefix = (blueprint.url_prefix + (url_prefix or "")).rstrip('/')
                bp.register(self, combined_prefix)
            for grp in blueprint._groups:
                combined_prefix = (blueprint.url_prefix + (url_prefix or "")).rstrip('/')
                self.register_blueprint(grp, url_prefix=combined_prefix)
            return self
        bp = blueprint.copy(blueprint.name) if hasattr(blueprint, 'copy') else blueprint
        bp.register(self, url_prefix)
        self._blueprints.append(bp)
        return self

    def blueprint(self, blueprint: 'Blueprint', **kwargs) -> 'Kewe':
        return self.register_blueprint(blueprint, **kwargs)

    def include_router(self, router, *, prefix: str = "", tags: Optional[list] = None, dependencies: Optional[List[Callable]] = None) -> 'Kewe':
        """包含路由器 - include_router

        支持 Blueprint 和 Router 对象。

        Args:
            router: Blueprint/Router 实例
            prefix: URL前缀
            tags: OpenAPI 分组标签
            dependencies: 路由器级依赖列表，将注入到该路由器下的所有路由
        """
        from kewe.routing.router import Router as RouterClass

        if isinstance(router, RouterClass):
            for route in router.routes:
                if route.methods == ['HEAD'] and route.name and route.name.endswith('_head'):
                    continue
                full_path = (prefix + route.path) if prefix else route.path
                handler = route.handler
                if dependencies:
                    handler = self._wrap_with_dependencies(handler, dependencies)
                route_tags = list(route.tags) if hasattr(route, 'tags') and route.tags else []
                if tags:
                    route_tags = list(set(route_tags + list(tags)))
                self.router.add_route(
                    path=full_path,
                    methods=route.methods,
                    handler=handler,
                    name=route.name,
                    middlewares=route.middlewares if hasattr(route, 'middlewares') else None,
                    tags=route_tags if route_tags else None,
                    summary=route.summary if hasattr(route, 'summary') else None,
                    description=route.description if hasattr(route, 'description') else None,
                    deprecated=route.deprecated if hasattr(route, 'deprecated') else False,
                )
            if hasattr(router, '_websocket_routes') and router._websocket_routes:
                for ws_path, ws_route in router._websocket_routes.items():
                    full_ws_path = (prefix + ws_path) if prefix else ws_path
                    ws_handler = ws_route.get('handler')
                    if ws_handler and dependencies:
                        ws_handler._websocket_dependencies = dependencies
                    self.router.add_websocket_route(
                        full_ws_path,
                        ws_handler,
                        name=ws_route.get('name'),
                        subprotocols=ws_route.get('subprotocols'),
                    )
            return self

        url_prefix = prefix or None
        if tags and hasattr(router, 'tags'):
            router.tags = tags
        if dependencies:
            if not hasattr(router, '_router_dependencies'):
                router._router_dependencies = []
            router._router_dependencies.extend(dependencies)
        return self.register_blueprint(router, url_prefix=url_prefix)

    def startup(self, func: Optional[Callable] = None) -> Callable:
        """Register an application startup hook

        委托给 register_listener("before_server_start")，与 before_server_start 使用同一存储
        """
        return self.register_listener("before_server_start", func, priority=0)

    def shutdown(self, func: Optional[Callable] = None) -> Callable:
        """Register an application shutdown hook

        委托给 register_listener("before_server_stop")，与 before_server_stop 使用同一存储
        """
        return self.register_listener("before_server_stop", func, priority=0)

    def _register_auto_shutdown_handlers(self):
        """自动注册需要优雅关闭的组件的shutdown处理器"""
        if hasattr(self, '_auto_shutdown_registered'):
            return
        self._auto_shutdown_registered = True
        
        @self.shutdown
        async def _auto_shutdown(*args, **kwargs):
            self._ensure_state_manager()
            from kewe.application.state import AppState
            self._state_manager.transition_to(AppState.STOPPING, "Application shutting down")

            if hasattr(self, '_jwt_auth_manager') and hasattr(self._jwt_auth_manager, 'shutdown'):
                try:
                    result = self._jwt_auth_manager.shutdown()
                    if asyncio.iscoroutine(result):
                        await result
                except Exception:
                    logger.warning("Failed to shutdown JWT auth manager", exc_info=True)

            for service in list(getattr(self, '_closeable_services', [])):
                try:
                    if hasattr(service, 'aclose'):
                        await service.aclose()
                    elif hasattr(service, 'close'):
                        result = service.close()
                        if asyncio.iscoroutine(result):
                            await result
                    elif hasattr(service, 'shutdown'):
                        result = service.shutdown()
                        if asyncio.iscoroutine(result):
                            await result
                except Exception:
                    logger.warning(f"Failed to close service {type(service).__name__}", exc_info=True)
            
            if hasattr(self, 'container'):
                try:
                    for svc_name in list(getattr(self.container, '_singleton_cache', {}).keys()):
                        svc = self.container._singleton_cache.get(svc_name)
                        if hasattr(svc, 'shutdown'):
                            try:
                                svc.shutdown()
                            except Exception:
                                logger.warning(f"Failed to shutdown singleton {type(svc).__name__}", exc_info=True)
                except Exception:
                    logger.warning("Failed to cleanup container singletons", exc_info=True)

            from kewe.application.state import AppState
            self._state_manager.transition_to(AppState.STOPPED, "Application stopped")

    def add_middleware(self, middleware_class, **kwargs):
        from kewe.middleware.core import BaseHTTPMiddleware, OnionMiddleware, ASGIMiddlewareAdapter
        import inspect

        if isinstance(middleware_class, type) and issubclass(middleware_class, BaseHTTPMiddleware):
            instance = middleware_class(app=self, **kwargs)
            self._onion_chain.add(OnionMiddleware(instance))
        elif isinstance(middleware_class, type):
            instance = middleware_class(**kwargs)
            if hasattr(instance, '__call__'):
                sig = inspect.signature(instance.__call__)
                params = list(sig.parameters.keys())
                if len(params) >= 3 and 'scope' in params:
                    self._onion_chain.add(OnionMiddleware(ASGIMiddlewareAdapter(instance, self)))
                elif 'call_next' in params:
                    self._onion_chain.add(OnionMiddleware(instance))
                else:
                    sig = inspect.signature(instance.__call__)
                    params = list(sig.parameters.keys())
                    single_arg = len(params) == 2 and 'call_next' not in params  # self + request only

                    async def _adapt_as_onion(request, call_next):
                        result = instance(request)
                        if inspect.isawaitable(result):
                            result = await result
                        from kewe.response.response import Response
                        if isinstance(result, Response):
                            return result
                        if result is False:
                            from kewe.response import json as _json
                            return _json({"error": "Request rejected by middleware"}, status=403)
                        if single_arg:
                            return await call_next(request)
                        response = await call_next(request)
                        result2 = instance(request, response)
                        if inspect.isawaitable(result2):
                            result2 = await result2
                        if isinstance(result2, Response):
                            return result2
                        return response
                    self._onion_chain.add(OnionMiddleware(_adapt_as_onion))
        else:
            raise TypeError(f"Middleware must be a class, got {type(middleware_class)}")
    
    def add_task(self, task: Union[asyncio.Task[Any], Coroutine, Callable]) -> Optional[asyncio.Task[Any]]:
        if asyncio.iscoroutine(task):
            loop = asyncio.get_running_loop()
            t = loop.create_task(task)
            self._tasks.append(t)
            t.add_done_callback(self._handle_background_task_error)
            return t
        elif callable(task):
            loop = asyncio.get_running_loop()
            coro = task() if not asyncio.iscoroutinefunction(task) else task()
            if asyncio.iscoroutine(coro):
                t = loop.create_task(coro)
                self._tasks.append(t)
                t.add_done_callback(self._handle_background_task_error)
                return t
            else:
                return None
        elif isinstance(task, asyncio.Task):
            self._tasks.append(task)
            task.add_done_callback(self._handle_background_task_error)
            return task
        return None

    def task(self, name: str = None, **kwargs):
        def decorator(func):
            if not hasattr(self, '_task_registry'):
                self._task_registry = []
            self._task_registry.append({'name': name, 'func': func})
            return func
        return decorator
    
    async def handle_request(self, request: Request) -> Response:
        with RequestContextManager() as ctx:
            g.request = request
            g.app = self
            g._request_ctx = request.ctx
            
            if self._onion_chain.middlewares and not self._asgi_stack:
                return await self._onion_chain.execute(request, self._handle_request_inner)
            
            return await self._handle_request_inner(request)
    
    @staticmethod
    def _handle_background_task_error(task):
        try:
            task.result()
        except Exception as e:
            logger.error(f"Background task error: {e}", exc_info=True)

    async def _handle_request_inner(self, request: Request) -> Response:
        _teardown_exc = None
        _response = None
        try:
            await self._emit_signal("http.lifecycle.request", request=request)

            if hasattr(request.ctx, '_short_circuit_response'):
                _response = request.ctx._short_circuit_response
                return _response

            mw_result = await self.middleware_manager.execute_request_middleware(request)
            if not mw_result.continue_processing:
                if mw_result.response:
                    _response = mw_result.response
                    return _response
                _response = _json_resp({"error": "Request rejected by middleware"}, status=403)
                return _response
            
            path = request.path
            if '?' in path:
                path = path.split('?')[0]
            
            await self._emit_signal("http.routing.before", request=request, path=path)
            route = self.router.find_route(path, request.method)
            await self._emit_signal("http.routing.after", request=request, route=route)

            if request.method == "HEAD":
                request._head_request = True
                if not route or route.get('method_not_allowed'):
                    get_route = self.router.find_route(path, "GET")
                    if get_route and not get_route.get('method_not_allowed'):
                        route = get_route

            _allowed_methods = None
            if request.method == "OPTIONS":
                route_method_not_allowed = route and route.get('method_not_allowed')
                if not route or route_method_not_allowed:
                    _allowed_methods = self.router.get_allowed_methods(path)
                    if _allowed_methods:
                        _response = Response(status=204)
                        _response.headers['Allow'] = ', '.join(sorted(_allowed_methods))
                        return _response

            if route and route.get('method_not_allowed'):
                if _allowed_methods is None:
                    _allowed_methods = self.router.get_allowed_methods(path)
                if not _allowed_methods:
                    _allowed_methods = route.get('methods', [])
                exc = MethodNotAllowed(
                    f"Method {request.method} not allowed for {path}",
                    allowed_methods=_allowed_methods
                )
                raise exc
            
            if not route:
                if _allowed_methods is None:
                    _allowed_methods = self.router.get_allowed_methods(path)
                if _allowed_methods:
                    exc = MethodNotAllowed(
                        f"Method {request.method} not allowed for {path}",
                        allowed_methods=_allowed_methods
                    )
                    raise exc
                raise NotFound(f"Route not found: {path}")
            
            request.ctx.route = route
            request.ctx.path_params = route.get("params", {})
            
            if route.get("redirect_to"):
                from kewe.response import redirect as _redirect
                _response = _redirect(route["redirect_to"])
                return _response
            
            g.route = route
            g.path_params = route.get("params", {})
            
            route_middlewares = route.get("middlewares", [])
            for middleware in route_middlewares:
                if asyncio.iscoroutinefunction(middleware):
                    result = await middleware(request)
                else:
                    result = middleware(request)
                
                if result is False:
                    _response = _json_resp({"error": "Request rejected by route middleware"}, status=403)
                    return _response
            
            handler = route["handler"]
            
            route_deps = getattr(handler, '_route_dependencies', None)
            if route_deps:
                from kewe.application.depends import Depends, DependencyResolver
                _route_resolver = getattr(self, '_dependency_resolver', None) or DependencyResolver()
                if not hasattr(self, '_dependency_resolver') or self._dependency_resolver is None:
                    self._dependency_resolver = _route_resolver
                for dep in route_deps:
                    dep_func = dep.dependency if isinstance(dep, Depends) else dep
                    dep_result = await self._resolve_dep_optional(_route_resolver, dep_func, None, request)
                    if isinstance(dep_result, Response):
                        _response = dep_result
                        return _response
                if not getattr(request.ctx, '_dep_resolver', None):
                    request.ctx._dep_resolver = _route_resolver
            
            with self.container.scope() as scope:
                self.container.register_scoped_instance(Request, request)
                await self._emit_signal("http.handler.before", request=request, handler=handler)
                response = await self._invoke_handler_with_injection(handler, request)
                await self._emit_signal("http.handler.after", request=request, response=response)
            
            from kewe.response.streaming import StreamingResponse as _StreamingResp
            _streaming_types = (Response, _StreamingResp)
            
            if not isinstance(response, _streaming_types):
                if isinstance(response, tuple):
                    response = self._handle_tuple_response(response)
                elif isinstance(response, str):
                    from kewe.response import text as _text_resp
                    response = _text_resp(response)
                elif isinstance(response, bytes):
                    response = Response(body=response, content_type="application/octet-stream")
                elif response is None:
                    response = Response(status=204)
                else:
                    response = _json_resp(response)
            
            if getattr(request, '_head_request', False):
                if hasattr(response, '_headers') and hasattr(response, '_body'):
                    original_content_length = response._headers.get('content-length')
                    response._body = b""
                    if original_content_length:
                        response._headers['content-length'] = original_content_length
                elif hasattr(response, 'is_streaming') and response.is_streaming:
                    pass
            
            _response = response
            return _response
                
        except KeweException as e:
            _teardown_exc = e
            await self._emit_signal("http.lifecycle.exception", request=request, exception=e)
            await self.plugins.run_hooks('request_exception', request, e)
            _response = await self._handle_exception(request, e)
        except Exception as e:
            from kewe.errors.exceptions import _AbortResponse
            if isinstance(e, _AbortResponse):
                await self._emit_signal("http.lifecycle.exception", request=request, exception=e)
                await self.plugins.run_hooks('request_exception', request, e)
                _response = e.response
            else:
                _teardown_exc = e
                logger.error(f"Request handling error: {e}")
                await self._emit_signal("http.lifecycle.exception", request=request, exception=e)
                await self.plugins.run_hooks('request_exception', request, e)
                handler = self._find_error_handler(e, request)
                if handler:
                    _response = await self._safe_invoke_handler(handler, request, e)
                elif isinstance(e, KeweException):
                    server_err = e
                    _response = await self._handle_exception(request, server_err)
                else:
                    server_err = InternalServerError(str(e) or "Internal Server Error")
                    server_err.__cause__ = e
                    _response = await self._handle_exception(request, server_err)
        finally:
            if _response is not None:
                try:
                    _response = await self._run_after_request(request, _response)
                    await self._emit_signal("http.lifecycle.response", request=request, response=_response)
                except Exception as e:
                    logger.error(f"after_request handler error: {e}")

                if _response.background is not None:
                    task = asyncio.create_task(_response.background.run())
                    task.add_done_callback(self._handle_background_task_error)
                    _response.background = None

            dep_resolver = getattr(request.ctx, '_dep_resolver', None)
            if dep_resolver:
                await dep_resolver.cleanup_generators(exc=_teardown_exc)

            await self._emit_signal("http.lifecycle.complete", request=request, response=_response)
        return _response
    async def _emit_signal(self, event_name: str, **kwargs):
        signal_bus = getattr(self, 'signal_bus', None)
        if signal_bus is None:
            return
        active_signals = getattr(self, '_active_signals', None)
        if active_signals is not None and event_name not in active_signals:
            return
        try:
            await signal_bus.emit(event_name, data=kwargs)
        except Exception as e:
            logger.debug(f"Signal emit error for {event_name}: {e}")

    async def _resolve_dep_optional(self, resolver, dep_func, type_hint, request):
        from kewe.application.depends import DependencyResolver
        is_optional = DependencyResolver._is_optional_type(type_hint)
        try:
            return await resolver.resolve(dep_func, request=request, app=self)
        except Exception:
            if is_optional:
                return None
            raise

    def _handle_tuple_response(self, response: tuple) -> Response:
        """处理 handler 返回的 tuple — 支持 (body, status) 和 (body, status, headers) 格式

        与 KeWe 行为对齐:
            return {"key": "value"}, 201
            return {"key": "value"}, 201, {"X-Custom": "header"}
        """
        from kewe.response import json as _json_resp
        if len(response) == 2:
            body, status = response
            if isinstance(body, Response):
                body.status = status
                return body
            return _json_resp(body, status=status)
        elif len(response) == 3:
            body, status, headers = response
            if isinstance(body, Response):
                body.status = status
                if headers:
                    for k, v in headers.items():
                        body._headers[k.lower()] = v
                return body
            return _json_resp(body, status=status, headers=headers)
        else:
            return _json_resp(response)

    @staticmethod
    def _coerce_param(value: str, target_type) -> Any:
        """将查询参数字符串值转换为目标类型"""
        if target_type is int:
            return int(value)
        elif target_type is float:
            return float(value)
        elif target_type is bool:
            return value.lower() in ('true', '1', 'yes')
        elif target_type is str:
            return value
        return value

    async def _invoke_handler_with_injection(self, handler: Callable, request: Request) -> Any:
        import inspect as _inspect
        from typing import get_type_hints as _get_type_hints, get_origin as _get_origin, get_args as _get_args
        from kewe.application.depends import Depends as _Depends, DependencyResolver as _DependencyResolver, _ParamDependency as _ParamDep

        resolver = getattr(self, '_dependency_resolver', None)
        if resolver is None:
            resolver = _DependencyResolver()
            self._dependency_resolver = resolver
        request.ctx._dep_resolver = resolver
        resolver._resolved_cache_var.set({})
        resolver._generator_cleanups_var.set([])

        handler_id = id(handler)
        cached = self._handler_signature_cache.get(handler_id)

        if cached is None:
            actual_handler = handler
            while hasattr(actual_handler, '__wrapped__'):
                actual_handler = actual_handler.__wrapped__

            sig = _inspect.signature(actual_handler)
            params = list(sig.parameters.items())

            try:
                type_hints = _get_type_hints(actual_handler, include_extras=True)
            except (NameError, TypeError):
                try:
                    type_hints = _get_type_hints(actual_handler)
                except (NameError, TypeError):
                    type_hints = {}

            pydantic_markers = self._detect_pydantic_model_sources(handler)
            already_validated_params = getattr(handler, '_kewe_pydantic_params', None)
            if already_validated_params is not None:
                pydantic_markers = {k: v for k, v in pydantic_markers.items() if k not in already_validated_params}

            cached = (params, type_hints, actual_handler, pydantic_markers)
            self._handler_signature_cache[handler_id] = cached

        params, type_hints, actual_handler, pydantic_markers = cached

        kwargs = {}
        first_param_done = False
        for name, param in params:
            if not first_param_done:
                first_param_done = True
                ann = param.annotation if param.annotation is not _inspect.Parameter.empty else None
                is_request_type = False
                if ann is not None:
                    ann_name = getattr(ann, '__name__', '') or getattr(ann, '__qualname__', '')
                    if 'Request' in ann_name:
                        is_request_type = True
                if name in ('request', 'req') or is_request_type or ann is None:
                    kwargs[name] = request
                    continue

            if name == 'request' or name == 'req':
                kwargs[name] = request
            elif isinstance(param.default, _Depends):
                dep_result = await self._resolve_dep_optional(resolver, param.default.dependency, type_hints.get(name), request)
                kwargs[name] = dep_result
            elif isinstance(param.default, _ParamDep):
                param_dep = param.default
                param_type = type_hints.get(name)
                try:
                    if hasattr(param_dep, 'extract_async'):
                        value = await param_dep.extract_async(request, param_name=name, target_type=param_type)
                    else:
                        value = param_dep.extract(request, param_name=name, target_type=param_type)
                    kwargs[name] = value
                except ValueError as e:
                    from kewe.errors.exceptions import UnprocessableEntity
                    raise UnprocessableEntity(str(e))
            elif name in pydantic_markers:
                model_cls, source, marker = pydantic_markers[name]
                try:
                    kwargs[name] = await self._resolve_pydantic_model(request, model_cls, source, marker, kwargs)
                except Exception as e:
                    if hasattr(e, 'errors'):
                        from kewe.plugins.pydantic_support import _format_validation_errors
                        errors = _format_validation_errors(e)
                        prefix = source if source != 'auto' else 'body'
                        for err in errors:
                            err['loc'] = [prefix] + err['loc']
                        from kewe.errors.exceptions import UnprocessableEntity
                        raise UnprocessableEntity(_json.dumps(errors))
                    from kewe.errors.exceptions import UnprocessableEntity
                    raise UnprocessableEntity(str(e))
            elif param.default is not _inspect.Parameter.empty:
                param_type = type_hints.get(name)
                annotated_dep = self._extract_annotated_dependency(param_type) if param_type else None
                if annotated_dep is not None:
                    if isinstance(annotated_dep, _Depends):
                        dep_result = await self._resolve_dep_optional(resolver, annotated_dep.dependency, type_hints.get(name), request)
                        kwargs[name] = dep_result
                    elif isinstance(annotated_dep, _ParamDep):
                        try:
                            inner_type = self._get_annotated_inner_type(param_type)
                            if hasattr(annotated_dep, 'extract_async'):
                                value = await annotated_dep.extract_async(request, param_name=name, target_type=inner_type)
                            else:
                                value = annotated_dep.extract(request, param_name=name, target_type=inner_type)
                            kwargs[name] = value
                        except ValueError as e:
                            from kewe.errors.exceptions import UnprocessableEntity
                            raise UnprocessableEntity(str(e))
                    continue
                if name in request.query_params:
                    raw_val = request.query_params.get(name)
                    if param_type and param_type is not _inspect.Parameter.empty:
                        try:
                            kwargs[name] = self._coerce_param(raw_val, param_type)
                        except (ValueError, TypeError):
                            kwargs[name] = param.default
                    else:
                        kwargs[name] = raw_val
            else:
                param_type = type_hints.get(name)
                annotated_dep = self._extract_annotated_dependency(param_type)
                if annotated_dep is not None:
                    if isinstance(annotated_dep, _Depends):
                        dep_result = await self._resolve_dep_optional(resolver, annotated_dep.dependency, type_hints.get(name), request)
                        kwargs[name] = dep_result
                    elif isinstance(annotated_dep, _ParamDep):
                        try:
                            inner_type = self._get_annotated_inner_type(param_type)
                            if hasattr(annotated_dep, 'extract_async'):
                                value = await annotated_dep.extract_async(request, param_name=name, target_type=inner_type)
                            else:
                                value = annotated_dep.extract(request, param_name=name, target_type=inner_type)
                            kwargs[name] = value
                        except ValueError as e:
                            from kewe.errors.exceptions import UnprocessableEntity
                            raise UnprocessableEntity(str(e))
                elif param_type and self.container.can_resolve(param_type):
                    kwargs[name] = self.container.resolve(param_type)
                elif param_type == Request:
                    kwargs[name] = request
                else:
                    is_basemodel = False
                    try:
                        from pydantic import BaseModel as _BM
                        if isinstance(param_type, type) and issubclass(param_type, _BM):
                            is_basemodel = True
                    except (ImportError, TypeError):
                        pass
                    if is_basemodel:
                        try:
                            kwargs[name] = await self._resolve_pydantic_model(
                                request, param_type, 'auto', None, kwargs
                            )
                        except Exception as e:
                            from kewe.errors.exceptions import UnprocessableEntity
                            raise UnprocessableEntity(str(e))

            if name not in kwargs:
                path_params = {}
                if hasattr(request, 'ctx') and hasattr(request.ctx, 'path_params'):
                    path_params = request.ctx.path_params or {}
                elif hasattr(request, 'path_params'):
                    path_params = request.path_params or {}
                if name in path_params:
                    raw = path_params[name]
                    if param_type and param_type in (int, float, bool, str):
                        try:
                            kwargs[name] = param_type(raw)
                        except (ValueError, TypeError):
                            kwargs[name] = raw
                    else:
                        kwargs[name] = raw

        has_request_kwarg = any(n in kwargs for n in ('request', 'req'))
        if not has_request_kwarg and params:
            first_param_name = params[0][0]
            first_param = params[0][1]
            if first_param_name not in kwargs:
                first_type = first_param.annotation if first_param.annotation is not _inspect.Parameter.empty else None
                should_inject_request = (
                    first_param.kind in (
                        inspect.Parameter.POSITIONAL_ONLY,
                        inspect.Parameter.POSITIONAL_OR_KEYWORD,
                    )
                    and (first_type is None or first_type is Request or (isinstance(first_type, str) and first_type == 'Request'))
                )
                if should_inject_request:
                    kwargs[first_param_name] = request
                elif first_param.kind == inspect.Parameter.VAR_POSITIONAL:
                    return await handler(request, **kwargs) if asyncio.iscoroutinefunction(handler) else handler(request, **kwargs)

        if asyncio.iscoroutinefunction(actual_handler):
            return await actual_handler(**kwargs)
        else:
            return actual_handler(**kwargs)

    async def _resolve_pydantic_model(
        self,
        request: Request,
        model_cls: type,
        source: str,
        marker: Any,
        path_kwargs: dict,
    ) -> Any:
        """解析并验证Pydantic模型参数

        统一处理BodyModel/QueryModel/HeaderModel/PathModel标记，
        与依赖注入系统无缝集成。
        """
        from kewe.plugins.pydantic_support import (
            extract_query_model, extract_header_model, extract_path_model,
        )

        strict = getattr(marker, 'strict', False) if marker else False
        context = getattr(marker, 'context', None) if marker else None

        if source == 'body' or (source == 'auto' and request.method in ('POST', 'PUT', 'PATCH')):
            body = await request.json_async
            if hasattr(model_cls, 'model_validate'):
                return model_cls.model_validate(body or {}, strict=strict, context=context)
            return model_cls(**(body or {}))
        elif source == 'query':
            return extract_query_model(request, model_cls, strict=strict)
        elif source == 'header':
            return extract_header_model(request, model_cls, strict=strict)
        elif source == 'path':
            actual_path_params = getattr(request.ctx, 'path_params', None) or request.path_params or {}
            return extract_path_model(request, model_cls, actual_path_params, strict=strict)
        else:
            body = await request.json_async
            if hasattr(model_cls, 'model_validate'):
                return model_cls.model_validate(body or {}, strict=strict, context=context)
            return model_cls(**(body or {}))

    @staticmethod
    def _extract_annotated_dependency(type_hint):
        """从Annotated类型提示中提取依赖"""
        try:
            from typing import Annotated, get_origin, get_args
        except ImportError:
            return None
        if get_origin(type_hint) is Annotated:
            args = get_args(type_hint)
            from kewe.application.depends import Depends, _ParamDependency
            for arg in args[1:]:
                if isinstance(arg, (Depends, _ParamDependency)):
                    return arg
        return None

    @staticmethod
    def _get_annotated_inner_type(type_hint):
        """从Annotated类型提示中获取内部类型"""
        try:
            from typing import Annotated, get_origin, get_args
        except ImportError:
            return None
        if get_origin(type_hint) is Annotated:
            args = get_args(type_hint)
            if args:
                return args[0]
        return None
    
    async def _run_after_request(self, request: Request, response: Response) -> Response:
        """执行 after_request 钩子 — 在正常和异常路径中复用"""
        try:
            response = await self.middleware_manager.execute_response_middleware(request, response) or response
        except Exception as e:
            logger.error(f"Response middleware error: {e}")
        return response
    
    async def _handle_exception(self, request: Request, exception: KeweException) -> Response:
        if self._error_tracker is not None:
            try:
                await self._error_tracker.track(
                    exception,
                    request_info={"path": request.path, "method": request.method}
                )
            except Exception:
                logger.debug("Non-critical operation failed", exc_info=True)
        handler = self._find_error_handler(exception, request)
        
        if handler:
            try:
                original_exc = getattr(exception, '__cause__', None)
                exc_to_pass = exception
                if original_exc is not None:
                    for exc_type in type(original_exc).__mro__:
                        handlers_list = self.middleware_manager._error_handlers.get(exc_type)
                        if handlers_list:
                            for _, h in handlers_list:
                                if h is handler:
                                    exc_to_pass = original_exc
                                    break
                if asyncio.iscoroutinefunction(handler):
                    result = await self._invoke_error_handler(handler, request, exc_to_pass)
                else:
                    result = self._invoke_error_handler_sync(handler, request, exc_to_pass)
            except Exception as handler_exc:
                logger.error(f"Custom exception handler error: {handler_exc}", exc_info=True)
                resp = _json_resp(exception.to_problem_details(request.path), status=exception.status_code)
                if hasattr(exception, 'get_headers'):
                    for k, v in exception.get_headers().items():
                        if k.lower() not in {hk.lower() for hk in resp.headers}:
                            resp.headers[k] = v
                return resp
            
            result, result_status, result_headers = self._unpack_result(result)

            if isinstance(result, Response):
                if result_status is not None:
                    result.status = result_status
                elif result.status == 200 and exception.status_code != 200:
                    result.status = exception.status_code
                if result_headers:
                    for k, v in result_headers.items():
                        result.headers[k] = v
                if hasattr(exception, 'get_headers'):
                    for k, v in exception.get_headers().items():
                        if k.lower() not in {hk.lower() for hk in result.headers}:
                            result.headers[k] = v
                return result
            elif isinstance(result, dict):
                resp = _json_resp(result, status=result_status or exception.status_code)
            elif isinstance(result, str):
                resp = _json_resp({"detail": result}, status=result_status or exception.status_code)
            else:
                resp = _json_resp(result, status=result_status or exception.status_code)
            
            if hasattr(exception, 'get_headers'):
                for k, v in exception.get_headers().items():
                    if k.lower() not in {hk.lower() for hk in resp.headers}:
                        resp.headers[k] = v
            return resp
        
        resp = _json_resp(exception.to_problem_details(request.path), status=exception.status_code)
        if hasattr(exception, 'get_headers'):
            for k, v in exception.get_headers().items():
                if k.lower() not in {hk.lower() for hk in resp.headers}:
                    resp.headers[k] = v
        return resp
    
    def _find_error_handler(self, exception, request: Optional[Request] = None) -> Optional[Callable]:
        request_path = getattr(request, 'path', '') if request else ''
        status_code = getattr(exception, 'status_code', None)

        if status_code:
            status_handler = self.error_handlers.get(status_code)
            if status_handler:
                return status_handler

        for exc_type in type(exception).__mro__:
            if exc_type is Exception:
                continue
            handlers_list = self.middleware_manager._error_handlers.get(exc_type)
            if handlers_list:
                chosen = self._pick_handler(handlers_list, request_path)
                if chosen:
                    return chosen
            if exc_type is BaseException:
                break

        if hasattr(exception, '__cause__') and exception.__cause__:
            for exc_type in type(exception.__cause__).__mro__:
                if exc_type in (BaseException,):
                    break
                handlers_list = self.middleware_manager._error_handlers.get(exc_type)
                if handlers_list:
                    chosen = self._pick_handler(handlers_list, request_path)
                    if chosen:
                        return chosen

        if not isinstance(exception, KeweException) and status_code:
            status_handler = self.error_handlers.get(status_code)
            if status_handler:
                return status_handler

        generic_handlers = self.middleware_manager._error_handlers.get(Exception)
        if generic_handlers:
            chosen = self._pick_handler(generic_handlers, request_path)
            if chosen:
                return chosen

        return None

    async def _invoke_error_handler(self, handler, request, exception):
        """调用错误处理器 — 自动适配单参数和双参数签名"""
        import inspect
        sig = inspect.signature(handler)
        param_count = len([p for p in sig.parameters.values()
                          if p.kind not in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD)])
        if param_count <= 1:
            return await handler(exception)
        return await handler(request, exception)

    def _invoke_error_handler_sync(self, handler, request, exception):
        """同步调用错误处理器 — 自动适配单参数和双参数签名"""
        import inspect
        sig = inspect.signature(handler)
        param_count = len([p for p in sig.parameters.values()
                          if p.kind not in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD)])
        if param_count <= 1:
            return handler(exception)
        return handler(request, exception)

    @staticmethod
    def _unpack_result(result):
        if isinstance(result, tuple):
            body = result[0]
            status = result[1] if len(result) > 1 else None
            headers = result[2] if len(result) > 2 else None
            if isinstance(headers, (list, tuple)):
                headers = dict(headers)
            return body, status, headers
        return result, None, None

    def _pick_handler(self, handlers_list, request_path: str) -> Optional[Callable]:
        scoped_match = None
        global_match = None
        for url_prefix, handler in handlers_list:
            if url_prefix is None:
                if global_match is None:
                    global_match = handler
            else:
                if request_path == url_prefix or request_path.startswith(url_prefix + '/'):
                    if scoped_match is None or len(url_prefix) > len(scoped_match[0] or ''):
                        scoped_match = (url_prefix, handler)
        return scoped_match[1] if scoped_match else global_match

    async def _safe_invoke_handler(self, handler, request, exception) -> Response:
        try:
            exc_to_pass = exception
            if hasattr(exception, '__cause__') and exception.__cause__:
                for exc_type in type(exception.__cause__).__mro__:
                    handlers_list = self.middleware_manager._error_handlers.get(exc_type)
                    if handlers_list:
                        for _, h in handlers_list:
                            if h is handler:
                                exc_to_pass = exception.__cause__
                                break
            if asyncio.iscoroutinefunction(handler):
                result = await self._invoke_error_handler(handler, request, exc_to_pass)
            else:
                result = self._invoke_error_handler_sync(handler, request, exc_to_pass)
        except Exception as handler_exc:
            logger.error(f"Custom exception handler error: {handler_exc}", exc_info=True)
            server_err = InternalServerError("Internal Server Error")
            return _json_resp(server_err.to_problem_details(request.path), status=500)

        result, status, headers = self._unpack_result(result)
        if isinstance(result, Response):
            if status is not None:
                result.status = status
            if headers:
                for k, v in headers.items():
                    result.headers[k] = v
            return result
        elif isinstance(result, dict):
            return _json_resp(result, status=status or getattr(exception, 'status_code', 500))
        return _json_resp({"detail": str(exception)}, status=status or 500)
    
    def register_error_handler(self, code_or_exception, handler: Optional[Callable] = None):
        """注册错误处理器 - 的非装饰器方法

        传入 None 作为 handler 可注销已注册的处理器。

        使用示例:
            app.register_error_handler(404, handle_not_found)
            app.register_error_handler(ValueError, handle_value_error)
            app.register_error_handler(404, None)  # 注销 404 处理器
        """
        if handler is None:
            if isinstance(code_or_exception, int):
                self.error_handlers.pop(code_or_exception, None)
                if hasattr(self, 'middleware_manager'):
                    self.middleware_manager.unregister_status_code_handler(code_or_exception)
            elif isinstance(code_or_exception, type) and issubclass(code_or_exception, BaseException):
                self.middleware_manager.unregister_error_handler(code_or_exception)
            return
        if isinstance(code_or_exception, int):
            self.error_handlers[code_or_exception] = handler
            if hasattr(self, 'middleware_manager'):
                self.middleware_manager.register_status_code_handler(code_or_exception, handler)
        elif isinstance(code_or_exception, type) and issubclass(code_or_exception, BaseException):
            self.middleware_manager.register_error_handler(code_or_exception, handler)
        else:
            raise TypeError(f"Expected int status code or Exception subclass, got {type(code_or_exception)}")
    
    def url_for(self, endpoint: str = None, **kwargs) -> str:
        if endpoint is None:
            raise ValueError("url_for() requires a route endpoint name as first argument")
        return self.router.url_for(endpoint, **kwargs)
    
    def _get_current_request(self):
        from kewe.base.context import get_request_ctx
        ctx = get_request_ctx()
        if ctx is not None and hasattr(ctx, 'request'):
            return ctx.request
        return None
    
    @property
    def routes(self):
        """路由列表 - 属性
        
        返回应用中所有已注册的路由信息列表。
        """
        if hasattr(self.router, '_route_map'):
            return list(self.router._route_map.values())
        if hasattr(self.router, 'routes'):
            return self.router.routes
        return []
    
    @property
    def test_client(self):
        """测试客户端

        支持 app.test_client 属性访问。
        """
        from kewe.utils.testing import TestClient
        if not hasattr(self, '_test_client_instance'):
            self._test_client_instance = TestClient(self)
        return self._test_client_instance

    def ensure_sync(self, func: Callable, *args: Any, **kwargs: Any) -> Any:
        """确保函数以同步方式运行

        如果 func 是协程函数，在事件循环中运行它；
        如果 func 是普通函数，直接调用。
        """
        import asyncio
        if asyncio.iscoroutinefunction(func):
            try:
                loop = asyncio.get_running_loop()
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor() as pool:
                    future = loop.run_in_executor(pool, lambda: asyncio.run(func(*args, **kwargs)))
                    return future
            except RuntimeError:
                return asyncio.run(func(*args, **kwargs))
        result = func(*args, **kwargs)
        if asyncio.iscoroutine(result):
            try:
                loop = asyncio.get_running_loop()
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor() as pool:
                    future = loop.run_in_executor(pool, lambda: asyncio.run(result))
                    return future
            except RuntimeError:
                return asyncio.run(result)
        return result

    def test_request_context(
        self,
        path: str = "/",
        method: str = "GET",
        headers: Optional[Dict[str, str]] = None,
        query_string: Optional[str] = None,
        body: Optional[bytes] = None,
    ):
        """测试请求上下文管理器

        创建一个模拟请求上下文，用于在非请求环境中测试。

        用法:
            with app.test_request_context("/api/test?foo=bar", method="POST") as ctx:
                request = ctx.request
                ...

        Args:
            path: 请求路径（可包含查询字符串）
            method: HTTP 方法
            headers: 请求头
            query_string: 查询字符串
            body: 请求体

        Returns:
            上下文管理器
        """
        from contextlib import contextmanager
        from urllib.parse import parse_qs, urlparse

        parsed = urlparse(path)
        actual_path = parsed.path or "/"
        actual_qs = query_string or parsed.query or ""

        query_params = {}
        if actual_qs:
            for k, v_list in parse_qs(actual_qs).items():
                query_params[k] = v_list

        actual_headers = dict(headers) if headers else {}
        actual_body = body or b""

        @contextmanager
        def _ctx_manager():
            from kewe.base.context import RequestContextManager
            from kewe.request import Request
            req = Request(
                method=method,
                path=actual_path,
                headers=actual_headers,
                query_params=query_params,
                body=actual_body,
                client_ip="127.0.0.1",
                app=self,
            )
            with RequestContextManager() as ctx:
                g.request = req
                g.app = self
                ctx.request = req
                yield ctx

        return _ctx_manager()

    def app_context(self):
        """应用上下文管理器

        创建应用级上下文，用于在请求外访问应用级资源。

        用法:
            with app.app_context():
                current_app.config['KEY'] = 'value'
                ...
        """
        from contextlib import contextmanager
        from kewe.base.context import AppContext

        @contextmanager
        def _ctx_manager():
            ctx = AppContext(app=self)
            with ctx:
                yield ctx

        return _ctx_manager()
    
    @property
    def dependency_overrides(self):
        """依赖覆盖管理器（测试用）"""
        return self._dependency_override_manager
    
    def make_response(self, data=None, status: int = 200, headers: Optional[Dict[str, str]] = None) -> Response:
        if isinstance(data, Response):
            if headers:
                data.headers.update(headers)
            return data
        elif isinstance(data, dict):
            return _json_resp(data, status=status, headers=headers)
        elif isinstance(data, str):
            from kewe.response import text as text_resp
            return text_resp(data, status=status, headers=headers)
        elif isinstance(data, bytes):
            return Response(body=data, status=status, headers=headers)
        elif isinstance(data, tuple):
            if len(data) == 2:
                body, second = data
                if isinstance(second, dict):
                    return self.make_response(body, status=status, headers=second)
                else:
                    return self.make_response(body, status=second, headers=headers)
            elif len(data) == 3:
                body, status_code, hdrs = data
                if headers:
                    hdrs.update(headers)
                return self.make_response(body, status=status_code, headers=hdrs)
            return self.make_response(data[0], status=status, headers=headers)
        elif data is None:
            return Response(status=status, headers=headers)
        else:
            return _json_resp(data, status=status, headers=headers)
    
    @property
    def session_interface(self):
        return self._session_interface

    @session_interface.setter
    def session_interface(self, value):
        self._session_interface = value

    def setup_session(self, config=None, session_interface=None, secret_key: str = None):
        from kewe.cookies.session import setup_session, SessionConfig, SecureCookieSessionInterface, RedisSessionInterface
        cfg = config or SessionConfig()
        if not cfg.secret_key:
            actual_key = secret_key or getattr(self.config, 'secret_key', None)
            if actual_key:
                cfg.secret_key = actual_key
        if session_interface is None:
            if cfg.session_type == "redis":
                session_interface = RedisSessionInterface(cfg)
            else:
                session_interface = SecureCookieSessionInterface(cfg)
        setup_session(self, config=cfg, session_interface=session_interface)
        self._session_interface = session_interface
        return self

    def setup_http_client(
        self,
        *,
        base_url: Optional[str] = None,
        headers: Optional[Dict[str, str]] = None,
        timeout: float = 10.0,
        name: str = "http_client",
        **kwargs,
    ):
        """Register a shared async HTTP client on the application."""
        from kewe.http.client import AsyncHTTPClient

        client = AsyncHTTPClient(
            base_url=base_url,
            headers=headers,
            timeout=timeout,
            **kwargs,
        )
        self.register_internal_service(name, client)
        if client not in self._closeable_services:
            self._closeable_services.append(client)
        return client
    
    def setup_cache(
        self,
        backend: str = "memory",
        *,
        default_ttl: int = 300,
        redis_host: str = "localhost",
        redis_port: int = 6379,
        redis_db: int = 0,
        redis_password: Optional[str] = None,
        set_default: bool = True,
    ):
        from kewe.cache import CacheManager, RedisCache, setup_redis_cache

        cache_mgr = self.get_service('cache_manager')
        if cache_mgr is None:
            cache_mgr = CacheManager()
            self.register_internal_service('cache_manager', cache_mgr)

        if backend == "redis":
            setup_redis_cache(
                name="redis",
                host=redis_host,
                port=redis_port,
                db=redis_db,
                password=redis_password,
                set_default=set_default,
            )
        return cache_mgr

    def setup_csrf(
        self,
        *,
        secret_key: Optional[str] = None,
        cookie_name: str = "_csrf_token",
        header_name: str = "X-CSRFToken",
        secure: bool = True,
        httponly: bool = False,
        samesite: str = "Lax",
        excluded_methods: Optional[list] = None,
        excluded_paths: Optional[list] = None,
    ):
        from kewe.security.csrf import CSRFMiddleware

        actual_secret = secret_key or self.config.secret_key
        default_excluded = excluded_paths or []
        csrf_mw = CSRFMiddleware(
            secret_key=actual_secret,
            excluded_methods=excluded_methods or ["GET", "HEAD", "OPTIONS"],
            excluded_paths=default_excluded,
            cookie_name=cookie_name,
            header_name=header_name,
            samesite=samesite.lower(),
        )
        from kewe.middleware.core import OnionMiddleware
        self._onion_chain.add(OnionMiddleware(csrf_mw, priority=30))
        self.register_internal_service('csrf_middleware', csrf_mw)
        return csrf_mw

    def setup_rate_limit(
        self,
        max_requests: int = 100,
        window: int = 60,
        *,
        backend: str = "memory",
        key_func: Optional[Callable] = None,
        path: Optional[str] = None,
    ):
        from kewe.security.rate_limit import RateLimitMiddleware, MemoryBackend

        rate_backend = MemoryBackend()
        if backend == "redis":
            try:
                from kewe.security.rate_limit import RedisBackend
                rate_backend = RedisBackend()
            except (ImportError, Exception):
                pass
        rl_mw = RateLimitMiddleware(
            limit=max_requests,
            period=window,
            backend=rate_backend,
            key_func=key_func,
        )

        if path:
            @self.middleware("onion", priority=20)
            async def rate_limit_onion(request, call_next):
                if not request.path.startswith(path):
                    return await call_next(request)
                allowed = await rl_mw.check_limit(request)
                if not allowed:
                    from kewe.errors.exceptions import TooManyRequests
                    raise TooManyRequests("Rate limit exceeded")
                return await call_next(request)
        else:
            @self.middleware("onion", priority=20)
            async def rate_limit_global(request, call_next):
                allowed = await rl_mw.check_limit(request)
                if not allowed:
                    from kewe.errors.exceptions import TooManyRequests
                    raise TooManyRequests("Rate limit exceeded")
                return await call_next(request)

        self.register_internal_service('rate_limiter', rl_mw.limiter)
        return rl_mw.limiter

    def setup_health_checks(
        self,
        path: str = "/health",
        *,
        include_details: bool = True,
    ):
        existing = self.get_service('health_checker')
        if existing is not None:
            return existing

        from kewe.monitoring.health import HealthChecker, HealthEndpoint, HealthStatus

        endpoint = HealthEndpoint(self, path=path)
        self.register_internal_service('health_checker', endpoint.checker)
        return endpoint.checker

    def setup_monitoring(
        self,
        metrics_path: str = "/metrics",
        *,
        enable_access_metrics: bool = True,
    ):
        from kewe.monitoring.metrics import add_metrics_endpoint

        existing = self.get_service('monitoring_setup')
        if existing is None:
            try:
                add_metrics_endpoint(self, path=metrics_path)
            except ValueError:
                pass
            self.register_internal_service('monitoring_setup', True)

        if enable_access_metrics and self.get_service('access_metrics_setup') is None:
            @self.middleware("onion", priority=90)
            async def metrics_onion(request, call_next):
                import time
                start = time.monotonic()
                response = await call_next(request)
                elapsed = time.monotonic() - start
                self._metrics_manager.add_request(
                    method=request.method,
                    path=request.path,
                    status=response.status,
                    response_time=elapsed,
                )
                return response
            self.register_internal_service('access_metrics_setup', True)

        return self._metrics_manager

    def setup_tasks(self, *, broker_url: str = "redis://localhost:6379/0", max_concurrent: int = 10):
        from kewe.background.tasks import setup_tasks, TaskConfig

        config = TaskConfig(broker_url=broker_url)
        task_mgr = setup_tasks(self, config)
        self.register_internal_service('task_manager', task_mgr)
        if hasattr(task_mgr, 'close'):
            self._closeable_services.append(task_mgr)
        return task_mgr

    def setup_i18n(
        self,
        *,
        default_locale: str = "en",
        translations_dir: str = "./translations",
    ):
        from kewe.utils.i18n import I18nConfig, setup_i18n

        config = I18nConfig(default_locale=default_locale, translations_dir=translations_dir)
        i18n = setup_i18n(self, config)
        self.register_internal_service('i18n', i18n)
        return i18n

    def cors(
        self,
        *,
        origins: Optional[List[str]] = None,
        methods: Optional[List[str]] = None,
        headers: Optional[List[str]] = None,
        expose_headers: Optional[List[str]] = None,
        max_age: Optional[int] = None,
        supports_credentials: bool = False,
        **kwargs
    ) -> None:
        """添加CORS中间件"""
        from kewe.middleware.cors import add_cors
        cors_kwargs = {
            "origins": origins,
            "methods": methods,
            "allow_headers": headers,
            "expose_headers": expose_headers,
            "max_age": max_age,
            "supports_credentials": supports_credentials,
        }
        cors_kwargs.update(kwargs)
        cors_kwargs = {k: v for k, v in cors_kwargs.items() if v is not None}
        add_cors(self, **cors_kwargs)
    
    def static(
        self,
        url_prefix: str = "/static",
        directory: str = "./static",
        *,
        name: Optional[str] = None,
        allow_directory_listing: bool = False,
        spa_fallback: bool = False,
        file_or_directory: Optional[str] = None,
        uri: Optional[str] = None,
        **kwargs
    ) -> None:
        """注册静态文件服务

        兼容参数: app.static("/static", file_or_directory=".", uri="/static")
        spa_fallback: True 时，未匹配的路径回退到 index.html（SPA 模式）
        """
        effective_prefix = uri or url_prefix
        effective_dir = file_or_directory or directory
        from kewe.handlers.static_serve import register_static
        register_static(
            self,
            effective_prefix,
            effective_dir,
            name=name,
            allow_directory_listing=allow_directory_listing,
            spa_fallback=spa_fallback,
            **kwargs,
        )

    def send_from_directory(
        self,
        directory: str,
        filename: str,
        *,
        as_attachment: bool = False,
        mime_type: Optional[str] = None,
    ) -> Response:
        """安全地从指定目录发送文件

        阻止路径遍历攻击，确保文件只能从指定目录内获取。

        Args:
            directory: 基础目录（绝对路径或相对路径）
            filename: 相对于 directory 的文件名
            as_attachment: 是否作为附件下载
            mime_type: 自定义 MIME 类型

        Returns:
            Response 对象
        """
        import os as _os
        from kewe.response import FileResponse
        safe_dir = _os.path.realpath(directory)
        filepath = _os.path.realpath(_os.path.join(directory, filename))
        if not filepath.startswith(safe_dir + _os.sep) and filepath != safe_dir:
            return Response(body=b"Forbidden", status=403, content_type="text/plain")
        if not _os.path.isfile(filepath):
            return Response(body=b"Not Found", status=404, content_type="text/plain")
        download_name = _os.path.basename(filepath) if as_attachment else None
        return FileResponse(
            filepath,
            content_type=mime_type,
            filename=download_name,
        )

    def send_file(
        self,
        path: str,
        filename: Optional[str] = None,
        mime_type: Optional[str] = None,
        attachment: bool = False,
        base_dir: Optional[str] = None,
        **kwargs,
    ) -> Response:
        """发送文件响应

        委托给模块级 send_file()，支持 Range/ETag/Last-Modified/条件请求。

        Args:
            path: 文件路径
            filename: 下载时使用的文件名
            mime_type: 自定义 MIME 类型
            attachment: 是否作为附件下载
            base_dir: 基础目录（用于安全路径检查）
        """
        from kewe.response.response import send_file as _send_file
        return _send_file(
            path=path,
            filename=filename,
            mime_type=mime_type,
            attachment=attachment,
            base_dir=base_dir,
            **kwargs,
        )

    def mount(
        self,
        path: str,
        app: Any,
        *, 
        name: Optional[str] = None
    ) -> 'Kewe':
        """
        挂载子应用 - ASGI 委托模式，保持子应用隔离性
        
        mount() 实现，子应用作为独立的 ASGI 应用运行，
        前缀匹配后直接将请求传递给子应用，保持完全隔离。
        支持流式响应透传和 WebSocket 委托。
        
        在 ASGI __call__ 入口处拦截挂载路径，直接委托给子应用，
        不经过 Kewe 的请求处理管线，实现零缓冲流式透传。
        
        Args:
            path: 挂载路径
            app: 子应用实例（Kewe 实例或任意 ASGI 应用）
            name: 挂载点名称
        
        Returns:
            主应用实例
        """
        if not path.startswith('/'):
            path = '/' + path
        if not path.endswith('/'):
            path = path + '/'
        
        if not hasattr(self, '_mounted_apps'):
            self._mounted_apps = []
        
        self._mounted_apps.append({
            'path': path,
            'app': app,
            'name': name
        })
        
        return self
    
    async def __call__(
        self,
        scope: Dict[str, Any],
        receive: Callable,
        send: Callable
    ):
        """ASGI 接口 - 使 Kewe 应用实例可直接作为 ASGI 应用运行
        
        挂载子应用在 ASGI 层拦截，实现零缓冲流式透传。
        """
        if scope['type'] in ('http', 'websocket'):
            mounted_app, sub_scope = self._resolve_mount(scope)
            if mounted_app is not None:
                await mounted_app(sub_scope, receive, send)
                return

        if self._asgi_stack is not None:
            await self._asgi_stack(scope, receive, send)
        else:
            from kewe.server.asgi import ASGIAdapter
            if not hasattr(self, '_asgi_adapter'):
                self._asgi_adapter = ASGIAdapter(self)
            await self._asgi_adapter(scope, receive, send)
    
    def _resolve_mount(self, scope: Dict[str, Any]):
        """解析挂载路径，返回匹配的子应用和修改后的 scope
        
        Mount 实现，在 ASGI 层拦截挂载路径，
        直接委托给子应用，不经过 Kewe 的请求处理管线。
        
        Returns:
            (mounted_app, sub_scope) 或 (None, None)
        """
        mounted_apps = getattr(self, '_mounted_apps', None)
        if not mounted_apps:
            return None, None
        
        path = scope.get('path', '')
        
        for mount_info in mounted_apps:
            mount_path = mount_info['path']
            prefix = mount_path.rstrip('/')
            sub_app = mount_info['app']
            
            if path == prefix or path.startswith(mount_path):
                sub_path = path[len(prefix):]
                if not sub_path.startswith('/'):
                    sub_path = '/' + sub_path
                
                sub_scope = dict(scope)
                sub_scope['path'] = sub_path
                sub_scope['root_path'] = scope.get('root_path', '') + prefix
                sub_scope['raw_path'] = sub_path.encode('utf-8')
                
                return sub_app, sub_scope
        
        return None, None

    def build_middleware_stack(self) -> 'ASGIMiddlewareStack':
        """构建ASGI中间件栈 - build_middleware_stack

        将所有注册的洋葱中间件和ASGI中间件组合为纯ASGI嵌套栈。
        这确保中间件通过ASGI协议执行，与生产环境一致。

        使用示例:
            app.build_middleware_stack()
            # 现在可以通过 uvicorn 运行 app，中间件栈已构建

        Returns:
            ASGIMiddlewareStack 实例
        """
        from kewe.middleware.core import (
            ASGIMiddlewareStack, ServerErrorMiddleware, OnionMiddleware,
            ASGIOnionMiddleware,
        )
        from kewe.server.asgi import ASGIAdapter

        inner_app = ASGIAdapter(self)
        stack = ASGIMiddlewareStack(inner_app)

        for mw in reversed(self._onion_chain.middlewares):
            stack.add_middleware(ASGIOnionMiddleware, middleware_func=mw.func)

        stack.add_middleware(ServerErrorMiddleware, debug=self.config.debug)

        self._asgi_stack = stack
        return stack
    
    def _run_lifespan_startup(self):
        """执行 lifespan 上下文管理器的启动逻辑"""
        if self._lifespan is not None:
            import contextlib
            if contextlib.isasyncgenfunction(self._lifespan):
                self._lifespan_ctx = self._lifespan(self)
            elif hasattr(self._lifespan, '__aenter__'):
                self._lifespan_ctx = self._lifespan
            else:
                self._lifespan_ctx = None
        else:
            self._lifespan_ctx = None

    async def _execute_lifespan_startup(self):
        """异步执行 lifespan 启动"""
        if self._lifespan_ctx is not None:
            if hasattr(self._lifespan_ctx, '__aenter__'):
                await self._lifespan_ctx.__aenter__()
            elif hasattr(self._lifespan_ctx, '__anext__'):
                try:
                    await self._lifespan_ctx.__anext__()
                except StopAsyncIteration:
                    pass

    async def _execute_lifespan_shutdown(self):
        """异步执行 lifespan 关闭"""
        if self._lifespan_ctx is not None:
            try:
                if hasattr(self._lifespan_ctx, '__aexit__'):
                    await self._lifespan_ctx.__aexit__(None, None, None)
                elif hasattr(self._lifespan_ctx, 'athrow'):
                    try:
                        await self._lifespan_ctx.athrow(None, None, None)
                    except StopAsyncIteration:
                        pass
            except Exception as e:
                logger.error(f"Lifespan shutdown error: {e}")
