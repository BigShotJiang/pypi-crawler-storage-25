#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.base.cancel - Cancellation token for cooperative task cancellation
"""

import asyncio
from typing import Optional, Callable
from contextvars import ContextVar
import logging

logger = logging.getLogger(__name__)


# 当前请求的取消令牌
_cancel_token: ContextVar[Optional['CancelToken']] = ContextVar('cancel_token', default=None)


class CancelToken:
    """取消令牌 - 支持级联取消"""

    __slots__ = ('_cancelled', '_cancelled_event', '_callbacks', '_children', '_parent')

    def __init__(self, parent: 'CancelToken' = None):
        self._cancelled = False
        self._cancelled_event = asyncio.Event()
        self._callbacks: list = []
        self._children: list = []
        self._parent = parent
        if parent is not None:
            parent._children.append(self)
            parent.on_cancel(self.cancel)

    def cancel(self):
        """取消请求，同时级联取消所有子令牌"""
        if not self._cancelled:
            self._cancelled = True
            self._cancelled_event.set()
            for callback in self._callbacks:
                try:
                    callback()
                except Exception:
                    logger.debug("Non-critical operation failed", exc_info=True)
            for child in self._children:
                try:
                    child.cancel()
                except Exception:
                    logger.debug("Non-critical operation failed", exc_info=True)

    def create_child(self) -> 'CancelToken':
        """创建子令牌，父令牌取消时自动取消子令牌"""
        return CancelToken(parent=self)

    @property
    def cancelled(self) -> bool:
        return self._cancelled

    def on_cancel(self, callback: Callable):
        self._callbacks.append(callback)

    async def wait_for_cancel(self, timeout: Optional[float] = None) -> bool:
        try:
            await asyncio.wait_for(
                self._cancelled_event.wait(),
                timeout=timeout
            )
            return True
        except asyncio.TimeoutError:
            return False

    def check_cancelled(self):
        if self._cancelled:
            raise asyncio.CancelledError("Request was cancelled")


def get_cancel_token() -> Optional[CancelToken]:
    """获取当前取消令牌"""
    return _cancel_token.get()


def is_cancelled() -> bool:
    """检查当前请求是否已取消"""
    token = _cancel_token.get()
    return token is not None and token.cancelled


def check_cancelled():
    """检查并抛出取消异常"""
    token = _cancel_token.get()
    if token:
        token.check_cancelled()


class CancelScope:
    """取消作用域上下文管理器"""
    
    __slots__ = ('token', '_ctx_token')
    
    def __init__(self):
        self.token = CancelToken()
        self._ctx_token = None
    
    async def __aenter__(self):
        self._ctx_token = _cancel_token.set(self.token)
        return self.token
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        _cancel_token.reset(self._ctx_token)
        return False
