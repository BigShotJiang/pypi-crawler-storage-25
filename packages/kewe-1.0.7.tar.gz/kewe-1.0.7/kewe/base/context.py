#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.base.context - Request and application context with LocalProxy support
"""

from typing import Any, Optional, Dict, TypeVar, Generic, Type
from contextvars import ContextVar, Token
from dataclasses import dataclass

T = TypeVar('T')

_request_ctx: ContextVar[Optional['RequestContext']] = ContextVar('request_ctx', default=None)
_app_ctx: ContextVar[Optional['AppContext']] = ContextVar('app_ctx', default=None)


class ContextProperty(Generic[T]):
    """
    上下文属性描述符
    提供类型安全的属性访问
    """

    def __init__(self, name: str, default: Optional[T] = None):
        self.name = name
        self.default = default

    def __get__(self, obj: Any, objtype: Type) -> T:
        if obj is None:
            return self.default
        return obj._data.get(self.name, self.default)

    def __set__(self, obj: Any, value: T):
        obj._data[self.name] = value

    def __delete__(self, obj: Any):
        if self.name in obj._data:
            del obj._data[self.name]


class RequestContext:
    """
    请求上下文
    存储请求级别的全局状态
    """

    def __init__(self, request: Any = None, app: Any = None):
        self._data: Dict[str, Any] = {}
        self._token: Optional[Token] = None
        self.request = request
        self.app = app

    def __getattr__(self, name: str) -> Any:
        if name.startswith('_'):
            raise AttributeError(f"'{self.__class__.__name__}' object has no attribute '{name}'")
        if name not in self._data:
            raise AttributeError(f"'{self.__class__.__name__}' object has no attribute '{name}'")
        return self._data[name]

    def __setattr__(self, name: str, value: Any):
        if name.startswith('_') or name in ('request', 'app'):
            super().__setattr__(name, value)
        else:
            self._data[name] = value

    def __delattr__(self, name: str):
        if name.startswith('_'):
            super().__delattr__(name)
        else:
            if name in self._data:
                del self._data[name]

    def __contains__(self, name: str) -> bool:
        return name in self._data

    def __getitem__(self, key: str) -> Any:
        return self._data[key]

    def __setitem__(self, key: str, value: Any):
        self._data[key] = value

    def __repr__(self) -> str:
        return f"<RequestContext {self._data}>"

    def get(self, name: str, default: Any = None) -> Any:
        return self._data.get(name, default)

    def set(self, name: str, value: Any) -> 'RequestContext':
        self._data[name] = value
        return self

    def setdefault(self, name: str, default: Any = None) -> Any:
        return self._data.setdefault(name, default)

    def pop(self, name: str, default: Any = None) -> Any:
        return self._data.pop(name, default)

    def update(self, **kwargs) -> 'RequestContext':
        self._data.update(kwargs)
        return self

    def clear(self):
        self._data.clear()

    def to_dict(self) -> Dict[str, Any]:
        return self._data.copy()

    def _push(self) -> Token:
        self._token = _request_ctx.set(self)
        return self._token

    def _pop(self):
        if self._token:
            _request_ctx.reset(self._token)
            self._token = None

    def __enter__(self):
        self._push()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self._pop()
        return False

    async def __aenter__(self):
        self._push()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        self._pop()
        return False

    @classmethod
    def create_typed(cls, **kwargs) -> 'TypedRequestContext':
        return TypedRequestContext(**kwargs)


class TypedRequestContext(RequestContext):
    """
    类型化请求上下文
    提供编译时类型检查支持和常用属性快捷访问
    """

    @property
    def user_id(self) -> Optional[str]:
        return self._data.get('user_id')

    @user_id.setter
    def user_id(self, value: Optional[str]):
        self._data['user_id'] = value

    @property
    def request_id(self) -> Optional[str]:
        return self._data.get('request_id')

    @request_id.setter
    def request_id(self, value: Optional[str]):
        self._data['request_id'] = value

    @property
    def session_id(self) -> Optional[str]:
        return self._data.get('session_id')

    @session_id.setter
    def session_id(self, value: Optional[str]):
        self._data['session_id'] = value

    @property
    def ip_address(self) -> Optional[str]:
        return self._data.get('ip_address')

    @ip_address.setter
    def ip_address(self, value: Optional[str]):
        self._data['ip_address'] = value

    def require(self, name: str) -> Any:
        if name not in self._data:
            raise KeyError(f"Required context key '{name}' not found")
        return self._data[name]


class AppContext:
    """
    应用上下文 - 应用级数据存储
    """

    def __init__(self, app: Any = None):
        self._data: Dict[str, Any] = {}
        self._token: Optional[Token] = None
        self.app = app

    def __getattr__(self, name: str) -> Any:
        if name.startswith('_'):
            raise AttributeError(f"'{self.__class__.__name__}' object has no attribute '{name}'")
        if name not in self._data:
            raise AttributeError(f"'{self.__class__.__name__}' object has no attribute '{name}'")
        return self._data[name]

    def __setattr__(self, name: str, value: Any):
        if name.startswith('_') or name in ('app',):
            super().__setattr__(name, value)
        else:
            self._data[name] = value

    def __delattr__(self, name: str):
        if name.startswith('_'):
            super().__delattr__(name)
        else:
            if name in self._data:
                del self._data[name]
            else:
                raise AttributeError(f"'{self.__class__.__name__}' object has no attribute '{name}'")

    def get(self, name: str, default: Any = None) -> Any:
        return self._data.get(name, default)

    def set(self, name: str, value: Any) -> 'AppContext':
        self._data[name] = value
        return self

    def __enter__(self):
        self._token = _app_ctx.set(self)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self._token:
            _app_ctx.reset(self._token)
        return False


class LocalProxy:
    """
    本地代理
    代理到当前请求上下文
    """

    def __init__(self, name: Optional[str] = None):
        self._name = name

    def _get_current_object(self) -> Any:
        ctx = _request_ctx.get()
        if ctx is None:
            raise RuntimeError("Working outside of request context")

        if self._name is None:
            return ctx
        return ctx.get(self._name)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._get_current_object(), name)

    def __setattr__(self, name: str, value: Any):
        if name.startswith('_'):
            super().__setattr__(name, value)
        else:
            setattr(self._get_current_object(), name, value)

    def __delattr__(self, name: str):
        delattr(self._get_current_object(), name)

    def __getitem__(self, key: str) -> Any:
        return self._get_current_object()[key]

    def __setitem__(self, key: str, value: Any):
        self._get_current_object()[key] = value

    def __delitem__(self, key: str):
        del self._get_current_object()[key]

    def __contains__(self, key: str) -> bool:
        return key in self._get_current_object()

    def __iter__(self):
        return iter(self._get_current_object())

    def __len__(self) -> int:
        return len(self._get_current_object())

    def __repr__(self) -> str:
        try:
            obj = self._get_current_object()
        except RuntimeError:
            return f"<LocalProxy unbound>"
        return repr(obj)

    def __str__(self) -> str:
        try:
            obj = self._get_current_object()
        except RuntimeError:
            return "<LocalProxy unbound>"
        return str(obj)

    def __bool__(self) -> bool:
        try:
            return bool(self._get_current_object())
        except RuntimeError:
            return False

    def __eq__(self, other) -> bool:
        try:
            return self._get_current_object() == other
        except RuntimeError:
            return NotImplemented

    def __ne__(self, other) -> bool:
        try:
            return self._get_current_object() != other
        except RuntimeError:
            return NotImplemented

    def __hash__(self) -> int:
        return hash(id(self))

    def __call__(self, *args, **kwargs) -> Any:
        return self._get_current_object()(*args, **kwargs)

    def __add__(self, other):
        return self._get_current_object() + other

    def __radd__(self, other):
        return other + self._get_current_object()

    def __sub__(self, other):
        return self._get_current_object() - other

    def __mul__(self, other):
        return self._get_current_object() * other

    def __truediv__(self, other):
        return self._get_current_object() / other

    def __int__(self) -> int:
        return int(self._get_current_object())

    def __float__(self) -> float:
        return float(self._get_current_object())

    def get(self, name: str, default: Any = None) -> Any:
        try:
            ctx = _request_ctx.get()
            if ctx is None:
                return default
            return ctx.get(name, default)
        except RuntimeError:
            return default

    def set(self, name: str, value: Any):
        self._get_current_object().set(name, value)


class _GProxy:
    def __init__(self):
        pass

    def _get_target(self) -> Any:
        ctx = _request_ctx.get()
        if ctx is not None:
            return ctx
        raise RuntimeError("Working outside of request context. "
                           "The 'g' object can only be used during request handling.")

    def __getattr__(self, name: str) -> Any:
        if name.startswith('_'):
            return super().__getattribute__(name)
        target = self._get_target()
        try:
            return getattr(target, name)
        except AttributeError:
            try:
                request_ctx = super().__getattribute__('_request_ctx')
                if request_ctx is not None:
                    return getattr(request_ctx, name)
            except AttributeError:
                pass
            raise

    def __setattr__(self, name: str, value: Any):
        if name.startswith('_'):
            super().__setattr__(name, value)
        else:
            target = self._get_target()
            setattr(target, name, value)
            try:
                request_ctx = super().__getattribute__('_request_ctx')
                if request_ctx is not None:
                    setattr(request_ctx, name, value)
            except AttributeError:
                pass

    def __delattr__(self, name: str):
        if name.startswith('_'):
            super().__delattr__(name)
        else:
            delattr(self._get_target(), name)

    def __getitem__(self, key: str) -> Any:
        return self._get_target()[key]

    def __setitem__(self, key: str, value: Any):
        self._get_target()[key] = value

    def __contains__(self, key: str) -> bool:
        return key in self._get_target()

    def pop(self, name: str, default: Any = None) -> Any:
        """弹出属性 — 弹出属性"""
        target = self._get_target()
        if hasattr(target, 'pop'):
            return target.pop(name, default)
        if hasattr(target, name):
            val = getattr(target, name)
            delattr(target, name)
            return val
        return default


g = _GProxy()


class _RequestProxy:
    """请求全局代理 — 请求全局代理"""

    def _get_request(self):
        ctx = _request_ctx.get()
        if ctx is not None and ctx.request is not None:
            return ctx.request
        raise RuntimeError("Working outside of request context")

    def __getattr__(self, name):
        if name.startswith('_'):
            return super().__getattribute__(name)
        return getattr(self._get_request(), name)

    def __setattr__(self, name, value):
        if name.startswith('_'):
            super().__setattr__(name, value)
        else:
            setattr(self._get_request(), name, value)

    def __repr__(self):
        try:
            return repr(self._get_request())
        except RuntimeError:
            return '<RequestProxy unbound>'

    def __str__(self):
        try:
            return str(self._get_request())
        except RuntimeError:
            return '<RequestProxy unbound>'


class _CurrentAppProxy:
    """当前应用全局代理 — 当前应用全局代理"""

    def _get_app(self):
        ctx = _request_ctx.get()
        if ctx is not None and ctx.app is not None:
            return ctx.app
        app_ctx = _app_ctx.get()
        if app_ctx is not None and app_ctx.app is not None:
            return app_ctx.app
        raise RuntimeError("Working outside of application context")

    def _get_current_object(self):
        return self._get_app()

    def __getattr__(self, name):
        if name.startswith('_'):
            return super().__getattribute__(name)
        return getattr(self._get_app(), name)

    def __setattr__(self, name, value):
        if name.startswith('_'):
            super().__setattr__(name, value)
        else:
            setattr(self._get_app(), name, value)

    def __repr__(self):
        try:
            return repr(self._get_app())
        except RuntimeError:
            return '<CurrentAppProxy unbound>'


class _SessionProxy:
    """Session 全局代理 — Session全局代理"""

    def _get_session(self):
        ctx = _request_ctx.get()
        if ctx is not None and ctx.request is not None:
            session = getattr(ctx.request, 'session', None)
            if session is not None:
                return session
        raise RuntimeError("Working outside of request context or session not configured")

    def __getattr__(self, name):
        if name.startswith('_'):
            return super().__getattribute__(name)
        return getattr(self._get_session(), name)

    def __setattr__(self, name, value):
        if name.startswith('_'):
            super().__setattr__(name, value)
        else:
            self._get_session()[name] = value

    def __getitem__(self, key):
        return self._get_session()[key]

    def __setitem__(self, key, value):
        self._get_session()[key] = value

    def __delitem__(self, key):
        del self._get_session()[key]

    def __contains__(self, key):
        return key in self._get_session()

    def __repr__(self):
        try:
            return repr(self._get_session())
        except RuntimeError:
            return '<SessionProxy unbound>'


request = _RequestProxy()
current_app = _CurrentAppProxy()
session = _SessionProxy()


class LocalStorage:
    """本地存储 - 兼容旧接口"""

    def __init__(self):
        self._storage = {}

    def __getattr__(self, name: str) -> Any:
        ctx = get_request_ctx()
        if ctx and name in ctx._data:
            return ctx._data[name]
        if name in self._storage:
            return self._storage[name]
        raise AttributeError(f"'{self.__class__.__name__}' object has no attribute '{name}'")

    def __setattr__(self, name: str, value: Any):
        if name.startswith('_'):
            super().__setattr__(name, value)
        else:
            ctx = get_request_ctx()
            if ctx:
                ctx.set(name, value)
            else:
                import logging
                logging.getLogger(__name__).warning(
                    f"LocalStorage.{name} set outside request context; "
                    f"data will persist until process restart"
                )
                self._storage[name] = value

    def __getitem__(self, key: str) -> Any:
        ctx = get_request_ctx()
        if ctx:
            return ctx.get(key)
        return self._storage[key]

    def __setitem__(self, key: str, value: Any):
        ctx = get_request_ctx()
        if ctx:
            ctx.set(key, value)
        else:
            self._storage[key] = value


class RequestContextManager:
    """
    请求上下文管理器
    用于中间件或处理器中管理请求上下文
    """

    def __init__(self):
        self.ctx = RequestContext()

    def __enter__(self):
        self.ctx._push()
        return self.ctx

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.ctx._pop()
        return False

    async def __aenter__(self):
        self.ctx._push()
        return self.ctx

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        self.ctx._pop()
        return False

    @classmethod
    def get_current(cls) -> Optional[RequestContext]:
        try:
            return _request_ctx.get()
        except LookupError:
            return None


def get_request_ctx() -> Optional[RequestContext]:
    return _request_ctx.get()


def has_request_ctx() -> bool:
    return _request_ctx.get() is not None


def get_app_ctx() -> Optional[AppContext]:
    try:
        return _app_ctx.get()
    except LookupError:
        return None


def has_app_context() -> bool:
    return _app_ctx.get() is not None


get_request = get_request_ctx
get_app = get_app_ctx
has_request_context = has_request_ctx


__all__ = [
    'RequestContext',
    'TypedRequestContext',
    'AppContext',
    'LocalProxy',
    'LocalStorage',
    'RequestContextManager',
    'ContextProperty',
    'g',
    'request',
    'current_app',
    'session',
    'get_request_ctx',
    'get_app_ctx',
    'get_request',
    'get_app',
    'has_request_ctx',
    'has_request_context',
    'has_app_context',
]
