#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.errors.middleware - Error tracking middleware for request lifecycle
"""

import logging
import time
import traceback
from typing import Optional

from kewe.request import Request
from kewe.response import Response

from .tracker import ErrorTracker, ErrorSeverity, error_tracker

logger = logging.getLogger(__name__)


class ErrorTrackingMiddleware:
    """
    错误追踪中间件

    自动捕获请求处理中的异常并记录
    """

    def __init__(
        self,
        tracker: Optional[ErrorTracker] = None,
        capture_4xx: bool = False,
        capture_5xx: bool = True
    ):
        self.tracker = tracker or error_tracker
        self.capture_4xx = capture_4xx
        self.capture_5xx = capture_5xx

    async def process_request(self, request: Request):
        request._error_tracking_start_time = time.time()
        return None

    async def process_response(self, request: Request, response: Response):
        if response.status >= 500 and self.capture_5xx:
            await self._track_error_response(request, response, ErrorSeverity.ERROR)
        elif response.status >= 400 and self.capture_4xx:
            await self._track_error_response(request, response, ErrorSeverity.WARNING)

        return response

    async def process_exception(self, request: Request, exception: Exception):
        request_info = self._build_request_info(request)
        severity = self._determine_severity(exception)

        await self.tracker.track(
            exception=exception,
            severity=severity,
            request_info=request_info
        )

    _SENSITIVE_HEADERS = frozenset({
        'authorization', 'cookie', 'set-cookie', 'proxy-authorization',
        'x-api-key', 'x-auth-token', 'x-csrf-token', 'x-forwarded-for',
    })

    def _build_request_info(self, request: Request) -> dict:
        headers = {}
        if hasattr(request, 'headers'):
            for k, v in (request.headers.items() if hasattr(request.headers, 'items') else []):
                if k.lower() in self._SENSITIVE_HEADERS:
                    headers[k] = '[REDACTED]'
                else:
                    headers[k] = v

        info = {
            'method': request.method,
            'path': request.path,
            'query_params': dict(request.query_params) if hasattr(request, 'query_params') else {},
            'client_ip': request.client_ip if hasattr(request, 'client_ip') else 'unknown',
            'headers': headers,
        }

        if hasattr(request, '_error_tracking_start_time'):
            duration = time.time() - request._error_tracking_start_time
            info['duration_ms'] = round(duration * 1000, 2)

        return info

    def _determine_severity(self, exception: Exception) -> ErrorSeverity:
        from kewe.errors.exceptions import (
            NotFound, MethodNotAllowed, BadRequest,
            Unauthorized, Forbidden, InternalServerError
        )

        if isinstance(exception, InternalServerError):
            return ErrorSeverity.CRITICAL
        elif isinstance(exception, (NotFound, MethodNotAllowed)):
            return ErrorSeverity.INFO
        elif isinstance(exception, (BadRequest, Unauthorized, Forbidden)):
            return ErrorSeverity.WARNING
        else:
            return ErrorSeverity.ERROR

    async def _track_error_response(self, request: Request, response: Response, severity: ErrorSeverity):
        from kewe.errors.exceptions import KeweException
        exception = KeweException(
            message=f"HTTP {response.status}",
            status_code=response.status,
        )
        request_info = self._build_request_info(request)

        await self.tracker.track(
            exception=exception,
            severity=severity,
            request_info=request_info,
            context={'status_code': response.status}
        )


def setup_error_tracking(app, **kwargs):
    """
    为应用设置错误追踪

    Args:
        app: Kewe应用实例
        **kwargs: ErrorTrackingMiddleware参数
    """
    middleware = ErrorTrackingMiddleware(**kwargs)

    @app.middleware('request')
    async def error_tracking_request(request):
        return await middleware.process_request(request)

    @app.middleware('response')
    async def error_tracking_response(request, response):
        return await middleware.process_response(request, response)

    @app.before_server_start
    async def register_error_tracking_hook(app):
        original_handle = app._handle_exception

        async def wrapped_handle(request, exception):
            await middleware.process_exception(request, exception)
            return await original_handle(request, exception)

        app._handle_exception = wrapped_handle




