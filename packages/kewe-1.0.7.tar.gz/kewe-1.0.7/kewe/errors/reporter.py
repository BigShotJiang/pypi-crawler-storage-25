#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.errors.reporter - Error reporters supporting console, file, email, and webhook
"""

import asyncio
from kewe.utils.compat import json
import logging
import smtplib
from abc import ABC, abstractmethod
from datetime import datetime
from email.mime.text import MIMEText
from pathlib import Path
from typing import Dict, Any, Optional, List

from .tracker import ErrorRecord

logger = logging.getLogger(__name__)


class ErrorReporter(ABC):
    """错误报告器基类"""
    
    @abstractmethod
    async def report(self, record: ErrorRecord):
        """报告错误"""
        pass
    
    @abstractmethod
    async def report_batch(self, records: List[ErrorRecord]):
        """批量报告错误"""
        pass


class ConsoleReporter(ErrorReporter):
    """控制台报告器"""
    
    def __init__(self, verbose: bool = False):
        self.verbose = verbose
    
    async def report(self, record: ErrorRecord):
        """报告到控制台"""
        print(f"\n[ERROR] {record.exception_type}: {record.message}")
        if self.verbose:
            print(f"Time: {record.timestamp}")
            print(f"Severity: {record.severity.value}")
            if record.request_info:
                print(f"Request: {record.request_info}")
            print(f"Traceback:\n{record.traceback}")
    
    async def report_batch(self, records: List[ErrorRecord]):
        """批量报告"""
        for record in records:
            await self.report(record)


class FileReporter(ErrorReporter):
    """文件报告器"""
    
    def __init__(self, filepath: str, format: str = "json"):
        self.filepath = Path(filepath)
        self.format = format
        self.filepath.parent.mkdir(parents=True, exist_ok=True)
        self._write_lock: asyncio.Lock = asyncio.Lock()

    def _get_lock(self) -> asyncio.Lock:
        return self._write_lock

    async def report(self, record: ErrorRecord):
        async with self._get_lock():
            if self.format == "text":
                with open(self.filepath, 'a', encoding='utf-8') as f:
                    f.write(f"\n{'='*60}\n")
                    f.write(f"Time: {record.timestamp}\n")
                    f.write(f"Severity: {record.severity.value}\n")
                    f.write(f"Type: {record.exception_type}\n")
                    f.write(f"Message: {record.message}\n")
                    f.write(f"Count: {record.count}\n")
                    if record.request_info:
                        f.write(f"Request: {json.dumps(record.request_info, indent=2)}\n")
                    f.write(f"Traceback:\n{record.traceback}\n")
            else:
                data = record.to_dict()
                line = json.dumps(data)
                with open(self.filepath, 'a', encoding='utf-8') as f:
                    f.write(line + '\n')
    
    async def report_batch(self, records: List[ErrorRecord]):
        async with self._get_lock():
            if self.format == "text":
                with open(self.filepath, 'a', encoding='utf-8') as f:
                    for record in records:
                        f.write(f"\n{'='*60}\n")
                        f.write(f"Time: {record.timestamp}\n")
                        f.write(f"Severity: {record.severity.value}\n")
                        f.write(f"Type: {record.exception_type}\n")
                        f.write(f"Message: {record.message}\n")
                        f.write(f"Count: {record.count}\n")
                        if record.request_info:
                            f.write(f"Request: {json.dumps(record.request_info, indent=2)}\n")
                        f.write(f"Traceback:\n{record.traceback}\n")
            else:
                with open(self.filepath, 'a', encoding='utf-8') as f:
                    for record in records:
                        line = json.dumps(record.to_dict())
                        f.write(line + '\n')


class EmailReporter(ErrorReporter):
    """邮件报告器"""
    
    def __init__(
        self,
        smtp_host: str,
        smtp_port: int,
        username: str,
        password: str,
        from_addr: str,
        to_addrs: List[str],
        use_tls: bool = True
    ):
        self.smtp_host = smtp_host
        self.smtp_port = smtp_port
        self.username = username
        self.password = password
        self.from_addr = from_addr
        self.to_addrs = to_addrs
        self.use_tls = use_tls
    
    async def report(self, record: ErrorRecord):
        try:
            subject = f"[{record.severity.value.upper()}] {record.exception_type}"
            body = self._format_email_body(record)
            
            msg = MIMEText(body, 'plain', 'utf-8')
            msg['Subject'] = subject
            msg['From'] = self.from_addr
            msg['To'] = ', '.join(self.to_addrs)
            
            loop = asyncio.get_running_loop()
            await loop.run_in_executor(None, self._send_email_sync, msg)
            
            logger.info(f"Error report email sent: {record.id}")
        except Exception as e:
            logger.error(f"Failed to send error report email: {e}")
    
    def _send_email_sync(self, msg):
        with smtplib.SMTP(self.smtp_host, self.smtp_port) as server:
            if self.use_tls:
                server.starttls()
            server.login(self.username, self.password)
            server.send_message(msg)
    
    def _format_email_body(self, record: ErrorRecord) -> str:
        """格式化邮件正文"""
        lines = [
            "Error Report",
            "=" * 60,
            f"ID: {record.id}",
            f"Time: {record.timestamp}",
            f"Severity: {record.severity.value}",
            f"Type: {record.exception_type}",
            f"Message: {record.message}",
            f"Count: {record.count}",
            "",
        ]
        
        if record.request_info:
            lines.extend([
                "Request Info:",
                json.dumps(record.request_info, indent=2),
                ""
            ])
        
        lines.extend([
            "Traceback:",
            record.traceback
        ])
        
        return "\n".join(lines)
    
    async def report_batch(self, records: List[ErrorRecord]):
        try:
            subject = f"[BATCH] {len(records)} Errors Reported"
            body = self._format_batch_email_body(records)
            
            msg = MIMEText(body, 'plain', 'utf-8')
            msg['Subject'] = subject
            msg['From'] = self.from_addr
            msg['To'] = ', '.join(self.to_addrs)
            
            loop = asyncio.get_running_loop()
            await loop.run_in_executor(None, self._send_email_sync, msg)
            
            logger.info(f"Batch error report email sent: {len(records)} errors")
        except Exception as e:
            logger.error(f"Failed to send batch error report email: {e}")
    
    def _format_batch_email_body(self, records: List[ErrorRecord]) -> str:
        """格式化批量邮件正文"""
        lines = [
            "Batch Error Report",
            "=" * 60,
            f"Total Errors: {len(records)}",
            "",
            "Summary:",
        ]
        
        for record in records:
            lines.append(f"  [{record.severity.value}] {record.exception_type}: {record.message}")
        
        lines.extend([
            "",
            "Details:",
            "=" * 60
        ])
        
        for i, record in enumerate(records, 1):
            lines.extend([
                f"\nError #{i}",
                f"  ID: {record.id}",
                f"  Time: {record.timestamp}",
                f"  Type: {record.exception_type}",
                f"  Message: {record.message}",
            ])
        
        return "\n".join(lines)


class WebhookReporter(ErrorReporter):
    """Webhook报告器 - 发送错误到HTTP endpoint"""
    
    def __init__(self, webhook_url: str, headers: Optional[Dict] = None):
        self.webhook_url = webhook_url
        self.headers = headers or {}
    
    async def report(self, record: ErrorRecord):
        try:
            from kewe.http.client import AsyncHTTPClient
            
            payload = record.to_dict()
            
            async with AsyncHTTPClient() as client:
                response = await client.post(
                    self.webhook_url,
                    json=payload,
                    headers=self.headers,
                )
                if response.status_code >= 400:
                    logger.error(f"Webhook report failed: {response.status_code}")
        except ImportError:
            logger.error("httpx is required for WebhookReporter")
        except Exception as e:
            logger.error(f"Failed to send webhook report: {e}")
    
    async def report_batch(self, records: List[ErrorRecord]):
        try:
            from kewe.http.client import AsyncHTTPClient
            
            payload = {
                'errors': [record.to_dict() for record in records]
            }
            
            async with AsyncHTTPClient() as client:
                response = await client.post(
                    self.webhook_url,
                    json=payload,
                    headers=self.headers,
                )
                if response.status_code >= 400:
                    logger.error(f"Webhook batch report failed: {response.status_code}")
        except Exception as e:
            logger.error(f"Failed to send batch webhook report: {e}")
