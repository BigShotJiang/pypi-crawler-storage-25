#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.server.http_server - Built-in HTTP server implementation
"""

import asyncio
import logging
import socket
import ssl
import os
import signal
import threading
import time
from typing import Optional, Dict, Any, Callable, List, AsyncGenerator
from urllib.parse import parse_qs
from enum import Enum
from dataclasses import dataclass, field

try:
    import httptools
except ImportError:
    httptools = None

if httptools is None:
    class _HttpParserStub:
        is_complete = True
        def __init__(self, protocol):
            self._protocol = protocol
        def get_method(self):
            return b'GET'
        def feed_data(self, data):
            pass
    _HTTPTOOLS_AVAILABLE = False
else:
    _HTTPTOOLS_AVAILABLE = True

from kewe.request import Request
from kewe.utils.compat import json
from kewe.websocket import get_websocket_manager
from kewe import __version__

logger = logging.getLogger(__name__)


class _ServerWebSocketConnection:
    """服务器内部WebSocket连接包装 - 兼容WebSocketManager"""

    def __init__(self, scope, receive, send):
        self.id = id(self)
        self._scope = scope
        self._receive = receive
        self._send = send
        self.path = scope.get('path', '/')
        self._state = 'open'
        self.ctx = type('Context', (), {})()

    @property
    def open(self):
        return self._state == 'open'

    async def send(self, data):
        if isinstance(data, dict):
            await self._send(data)
        elif isinstance(data, str):
            await self._send({'type': 'websocket.send', 'text': data})
        elif isinstance(data, bytes):
            await self._send({'type': 'websocket.send', 'bytes': data})

    async def close(self, code=1000, reason=''):
        self._state = 'closed'
        if code < 1000 or code in (1004, 1005, 1006) or (1015 <= code <= 1999) or code >= 5000:
            code = 1000
        reason = reason[:123]
        try:
            await self._send({'type': 'websocket.close', 'code': code, 'reason': reason})
        except Exception:
            logger.debug("Non-critical operation failed", exc_info=True)


class ParserState(Enum):
    INIT = "init"
    HEADERS = "headers"
    BODY = "body"
    COMPLETE = "complete"
    ERROR = "error"


def _get_reason_phrase(status_code: int) -> str:
    try:
        from http import HTTPStatus
        return HTTPStatus(status_code).phrase
    except ValueError:
        return "Unknown"


@dataclass
class HttpStreamBuffer:
    """HTTP流式缓冲区"""
    chunks: List[bytes] = field(default_factory=list)
    total_size: int = 0
    max_size: int = 100 * 1024 * 1024
    
    def append(self, data: bytes) -> bool:
        """添加数据，返回是否超出限制"""
        self.total_size += len(data)
        if self.total_size > self.max_size:
            return False
        self.chunks.append(data)
        return True
    
    def get_body(self) -> bytes:
        """获取完整body"""
        return b''.join(self.chunks)
    
    def clear(self):
        """清空缓冲区"""
        self.chunks.clear()
        self.total_size = 0


class HttpRequestParser:
    """
    HTTP请求解析器 - 使用httptools实现高性能解析
    支持流式请求体处理
    """
    
    def __init__(self, max_body_size: int = 100 * 1024 * 1024):
        self.headers: Dict[str, str] = {}
        self._body_buffer: HttpStreamBuffer = HttpStreamBuffer(max_size=max_body_size)
        self.url: Optional[str] = None
        self.method: Optional[str] = None
        self.version: Optional[str] = None
        self._state: ParserState = ParserState.INIT
        self._should_upgrade: bool = False
        self._content_length: int = 0
        self._transfer_encoding: Optional[str] = None
        self._chunked: bool = False
        self._body_stream_handlers: List[Callable[[bytes], None]] = []
    
    def on_url(self, url: bytes):
        """URL回调"""
        self.url = url.decode('utf-8')
    
    def on_header(self, name: bytes, value: bytes):
        """头部回调"""
        name_str = name.decode('utf-8').lower()
        value_str = value.decode('utf-8')
        self.headers[name_str] = value_str
        
        if name_str == 'content-length':
            try:
                self._content_length = int(value_str)
            except ValueError:
                pass
        elif name_str == 'transfer-encoding':
            self._transfer_encoding = value_str.lower()
            self._chunked = 'chunked' in value_str
        elif name_str == 'upgrade':
            self._should_upgrade = True
    
    def on_body(self, body: bytes):
        """请求体回调 - 支持流式处理"""
        self._state = ParserState.BODY
        
        for handler in self._body_stream_handlers:
            try:
                handler(body)
            except Exception as e:
                logger.error(f"Body stream handler error: {e}")
        
        if not self._body_buffer.append(body):
            logger.warning(f"Request body too large: {self._body_buffer.total_size}")
    
    @property
    def body(self) -> bytes:
        """获取完整请求体"""
        return self._body_buffer.get_body()
    
    def on_message_begin(self):
        """消息开始"""
        self.headers = {}
        self._body_buffer.clear()
        self._state = ParserState.INIT
        self._should_upgrade = False
        self._content_length = 0
        self._transfer_encoding = None
        self._chunked = False
    
    def on_headers_complete(self):
        self._state = ParserState.HEADERS
        if self.headers.get('expect', '').lower() == '100-continue':
            transport = getattr(self, '_transport', None)
            if transport and not transport.is_closing():
                transport.write(b"HTTP/1.1 100 Continue\r\n\r\n")
    
    def on_message_complete(self):
        """消息解析完成"""
        self._state = ParserState.COMPLETE
    
    def reset(self):
        """重置解析器"""
        self.on_message_begin()
    
    def add_body_stream_handler(self, handler: Callable[[bytes], None]):
        """添加请求体流处理器"""
        self._body_stream_handlers.append(handler)
    
    def remove_body_stream_handler(self, handler: Callable[[bytes], None]):
        """移除请求体流处理器"""
        if handler in self._body_stream_handlers:
            self._body_stream_handlers.remove(handler)
    
    @property
    def is_complete(self) -> bool:
        return self._state == ParserState.COMPLETE
    
    @property
    def should_upgrade(self) -> bool:
        return self._should_upgrade


class RequestHandler(asyncio.Protocol):
    """
    请求处理器 - Protocol实现
    支持Keep-Alive、流式处理、超时控制
    """
    
    def __init__(
        self,
        app,
        loop=None,
        request_timeout: float = 60.0,
        keep_alive_timeout: float = 5.0,
        request_max_size: int = 100 * 1024 * 1024,
        max_connections: int = 10000,
        server=None
    ):
        self.app = app
        self.server = server
        self.parser: Optional[HttpRequestParser] = None
        self.transport: Optional[asyncio.Transport] = None
        self._current_request: Optional[Request] = None
        self._request_handler: Optional[asyncio.Task] = None
        self._loop: Optional[asyncio.AbstractEventLoop] = loop
        
        self._request_timeout = request_timeout
        self._keep_alive_timeout = keep_alive_timeout
        self._request_max_size = request_max_size
        self._keep_alive = True
        self._max_connections = max_connections
        
        self._timeout_handler: Optional[asyncio.Handle] = None
        
        self._peername: Optional[tuple] = None
        self._start_time: float = 0
        
        self._websocket_receive_queue: Optional[asyncio.Queue] = None
        self._original_data_received: Optional[Callable] = None
        self._websocket: Optional[_ServerWebSocketConnection] = None
        self._heartbeat_task: Optional[asyncio.Task] = None
        
        self._stream_queue: Optional[asyncio.Queue] = None
        self._streaming_mode: bool = False
        self._body_received_size: int = 0
        self._http_parser: Optional[Any] = None
    
    def connection_made(self, transport):
        """连接建立"""
        if hasattr(self.app, '_active_connections'):
            conn_lock = getattr(self.app, '_active_connections_lock', None)
            if conn_lock is None:
                from threading import Lock
                conn_lock = Lock()
                self.app._active_connections_lock = conn_lock
            with conn_lock:
                if self.app._active_connections >= self._max_connections:
                    transport.close()
                    return
                self.app._active_connections += 1
        
        self.transport = transport
        self.parser = HttpRequestParser(max_body_size=self._request_max_size)
        self.parser._transport = transport
        if httptools is not None:
            self._http_parser = (httptools.HttpRequestParser if httptools else _HttpParserStub)(self.parser)
        else:
            self._http_parser = None
        self._body_received_size = 0
        self._peername = transport.get_extra_info('peername')
        if self._loop is None:
            self._loop = asyncio.get_running_loop()
        self._start_time = self._loop.time()
        
        self._set_keep_alive_timeout()
        
        self._websocket_receive_queue = None
        self._websocket = None
        self._heartbeat_task = None
        self._ws_fragment_buffer = bytearray()
        self._ws_fragment_opcode = None
        
        logger.debug(f"Connection made from {self._peername}, active connections: {getattr(self.app, '_active_connections', 1)}")
    
    def connection_lost(self, exc):
        """连接断开"""
        if hasattr(self.app, '_active_connections'):
            conn_lock = getattr(self.app, '_active_connections_lock', None)
            if conn_lock is None:
                from threading import Lock
                conn_lock = Lock()
                self.app._active_connections_lock = conn_lock
            with conn_lock:
                self.app._active_connections = max(0, self.app._active_connections - 1)
        
        logger.debug(f"Connection lost: {exc}, active connections: {getattr(self.app, '_active_connections', 0)}")
        
        if self._timeout_handler:
            self._timeout_handler.cancel()
        
        if self._request_handler and not self._request_handler.done():
            self._request_handler.cancel()
        
        if self._heartbeat_task and not self._heartbeat_task.done():
            self._heartbeat_task.cancel()
        
        if self._websocket:
            try:
                asyncio.create_task(self._websocket.close())
            except RuntimeError:
                pass
        
        if self._stream_queue:
            self._stream_queue.put_nowait(None)
        
        self.transport = None
    
    def data_received(self, data: bytes):
        """接收数据"""
        if self._timeout_handler:
            self._timeout_handler.cancel()
        
        try:
            self._body_received_size += len(data)
            if self._body_received_size > self._request_max_size:
                self._send_error_response(413, "Request Entity Too Large")
                return
            
            self._http_parser.feed_data(data)
            
            if not self.parser.method:
                self.parser.method = self._http_parser.get_method().decode('utf-8')
            if not self.parser.version:
                # 兼容不同版本的httptools
                if hasattr(self._http_parser, 'get_http_version'):
                    version = self._http_parser.get_http_version()
                else:
                    version = self._http_parser.get_version()
                # 新版本httptools返回字符串如 '1.1'，旧版本返回整数或元组
                if isinstance(version, str):
                    self.parser.version = version
                elif isinstance(version, tuple):
                    self.parser.version = f"{version[0]}.{version[1]}"
                elif version == 1:
                    self.parser.version = '1.1'
                elif version == 0:
                    self.parser.version = '1.0'
            
            raw_url = self._http_parser.get_url() if hasattr(self._http_parser, 'get_url') else getattr(self.parser, 'url', b'/')
            self.parser.url = raw_url.decode('utf-8') if isinstance(raw_url, bytes) else raw_url
            
            # 兼容不同版本的httptools: is_complete() vs is_message_complete()
            if hasattr(self._http_parser, 'is_complete'):
                is_msg_complete = self._http_parser.is_complete()
            elif hasattr(self._http_parser, 'is_message_complete'):
                is_msg_complete = self._http_parser.is_message_complete()
            else:
                is_msg_complete = self.parser.is_complete
            
            if self._is_websocket_request():
                self._request_handler = self._loop.create_task(
                    self._handle_websocket()
                )
            elif is_msg_complete or (
                self._http_parser.get_method() in (b'GET', b'HEAD', b'OPTIONS', b'TRACE')
            ):
                self._request_handler = self._loop.create_task(
                    self._handle_request()
                )
                
        except Exception as e:
            logger.error(f"Error parsing request: {e}", exc_info=True)
            self._send_error_response(400, f"Bad Request: {e}")
    
    def _is_websocket_request(self) -> bool:
        """检查是否是WebSocket请求"""
        upgrade = self.parser.headers.get('upgrade', '').lower()
        connection = self.parser.headers.get('connection', '').lower()
        return (
            upgrade == 'websocket' and
            'upgrade' in [v.strip() for v in connection.split(',')]
        )
    
    def _get_server_addr(self) -> tuple:
        """安全获取服务器地址"""
        try:
            sockname = self.transport.get_extra_info('sockname')
            if sockname:
                return (sockname[0], sockname[1])
        except Exception:
            logger.debug("Non-critical operation failed", exc_info=True)
        return ('127.0.0.1', 8000)
    
    async def _handle_websocket(self):
        """处理WebSocket连接"""
        try:
            scope = {
                'type': 'websocket',
                'path': self.parser.url or '/',
                'headers': [(k.encode(), v.encode()) for k, v in self.parser.headers.items()],
                'query_string': self.parser.url.split('?', 1)[1].encode() if '?' in self.parser.url else b'',
                'client': self._peername,
                'server': self._get_server_addr(),
            }
            
            websocket_handler, ws_path_params = self._find_websocket_handler(scope['path'])
            if not websocket_handler:
                self._send_error_response(404, "WebSocket route not found")
                return
            
            await self._accept_websocket(scope, websocket_handler)
            
        except Exception as e:
            logger.error(f"WebSocket handling error: {e}")
            self._send_error_response(500, "Internal Server Error")
    
    def _find_websocket_handler(self, path: str):
        from kewe.websocket.manager import find_websocket_handler
        result = find_websocket_handler(self.app, path)
        if isinstance(result, tuple):
            handler, path_params = result
            return handler, path_params
        return result, {}
    
    async def _send_websocket_frame(self, opcode: int, payload: bytes):
        """发送WebSocket帧"""
        fin = 1
        mask = 0
        
        first_byte = (fin << 7) | opcode
        
        length = len(payload)
        if length <= 125:
            second_byte = length
            length_bytes = b''
        elif length <= 65535:
            second_byte = 126
            length_bytes = length.to_bytes(2, 'big')
        else:
            second_byte = 127
            length_bytes = length.to_bytes(8, 'big')
        
        frame = bytes([first_byte]) + bytes([second_byte]) + length_bytes + payload
        
        if self.transport and not self.transport.is_closing():
            self.transport.write(frame)
    
    def _send_websocket_close(self, code: int = 1000, reason: str = ""):
        """发送WebSocket关闭帧"""
        reason_bytes = reason.encode('utf-8')[:123]
        payload = code.to_bytes(2, 'big') + reason_bytes
        if self.transport and not self.transport.is_closing():
            frame = bytes([0x88]) + bytes([len(payload)]) + payload
            self.transport.write(frame)
    
    def _process_websocket_frames(self, data: bytes) -> int:
        """处理缓冲区中的所有完整帧，返回已消耗的字节数"""
        total_consumed = 0
        while total_consumed < len(data):
            remaining = data[total_consumed:]
            frame_size = self._calculate_frame_size(remaining)
            if frame_size == 0:
                break
            self._process_websocket_frame(remaining[:frame_size])
            total_consumed += frame_size
        return total_consumed
    
    def _calculate_frame_size(self, data: bytes) -> int:
        """计算一个完整帧的字节大小，不完整返回0"""
        if len(data) < 2:
            return 0
        
        offset = 0
        second_byte = data[1]
        length = second_byte & 0x7f
        offset = 2
        
        if length == 126:
            if offset + 2 > len(data):
                return 0
            length = int.from_bytes(data[offset:offset+2], 'big')
            offset += 2
        elif length == 127:
            if offset + 8 > len(data):
                return 0
            length = int.from_bytes(data[offset:offset+8], 'big')
            offset += 8
        
        mask = (second_byte >> 7) & 1
        if mask:
            offset += 4
        
        if offset + length > len(data):
            return 0
        
        return offset + length
    
    def _process_websocket_frame(self, data: bytes):
        if not data or len(data) < 2:
            return
        
        try:
            offset = 0
            first_byte = data[offset]
            offset += 1
            
            fin = (first_byte >> 7) & 1
            rsv1 = (first_byte >> 6) & 1
            rsv2 = (first_byte >> 5) & 1
            rsv3 = (first_byte >> 4) & 1
            opcode = first_byte & 0x0f
            
            if rsv1 or rsv2 or rsv3:
                logger.warning(f"WebSocket: RSV bits set, closing connection")
                self._send_websocket_close(1002, "Protocol error: RSV bits set")
                self.transport.close()
                return
            
            is_control = opcode in (0x8, 0x9, 0xA)
            
            if is_control and not fin:
                logger.warning(f"WebSocket: Fragmented control frame, closing connection")
                self._send_websocket_close(1002, "Protocol error: fragmented control frame")
                self.transport.close()
                return
            
            if offset >= len(data):
                return
            second_byte = data[offset]
            offset += 1
            
            mask = (second_byte >> 7) & 1
            length = second_byte & 0x7f
            
            if is_control and length > 125:
                logger.warning(f"WebSocket: Control frame payload too large ({length}), closing connection")
                self._send_websocket_close(1002, "Protocol error: control frame too large")
                self.transport.close()
                return
            
            if length == 126:
                if offset + 2 > len(data):
                    return
                length = int.from_bytes(data[offset:offset+2], 'big')
                offset += 2
            elif length == 127:
                if offset + 8 > len(data):
                    return
                length = int.from_bytes(data[offset:offset+8], 'big')
                offset += 8
            
            if length > 16 * 1024 * 1024:
                logger.warning(f"WebSocket frame too large: {length} bytes")
                self._send_websocket_close(1009, "Message too large")
                self.transport.close()
                return
            
            if mask:
                if offset + 4 > len(data):
                    return
                mask_key = data[offset:offset+4]
                offset += 4
            else:
                mask_key = None
            
            if offset + length > len(data):
                logger.warning(f"WebSocket frame incomplete: expected {length}, have {len(data) - offset}")
                return
            
            payload = data[offset:offset+length]
            
            if mask:
                unmasked = bytearray(len(payload))
                for i in range(len(payload)):
                    unmasked[i] = payload[i] ^ mask_key[i % 4]
                payload = bytes(unmasked)
            
            if opcode == 1:
                if fin:
                    try:
                        text = payload.decode('utf-8')
                    except UnicodeDecodeError:
                        self._send_websocket_close(1007, "Invalid UTF-8")
                        self.transport.close()
                        return
                    if self._websocket_receive_queue:
                        try:
                            self._websocket_receive_queue.put_nowait({
                                'type': 'websocket.receive',
                                'text': text
                            })
                        except asyncio.QueueFull:
                            pass
                else:
                    self._ws_fragment_opcode = 1
                    self._ws_fragment_buffer.extend(payload)
            elif opcode == 2:
                if fin:
                    if self._websocket_receive_queue:
                        try:
                            self._websocket_receive_queue.put_nowait({
                                'type': 'websocket.receive',
                                'bytes': payload
                            })
                        except asyncio.QueueFull:
                            pass
                else:
                    self._ws_fragment_opcode = 2
                    self._ws_fragment_buffer.extend(payload)
            elif opcode == 0:
                if self._ws_fragment_opcode is None:
                    self._send_websocket_close(1002, "Protocol error: unexpected continuation frame")
                    self.transport.close()
                    return
                self._ws_fragment_buffer.extend(payload)
                if fin:
                    if self._ws_fragment_opcode == 1:
                        try:
                            text = self._ws_fragment_buffer.decode('utf-8')
                        except UnicodeDecodeError:
                            self._send_websocket_close(1007, "Invalid UTF-8")
                            self.transport.close()
                            return
                        if self._websocket_receive_queue:
                            try:
                                self._websocket_receive_queue.put_nowait({
                                    'type': 'websocket.receive',
                                    'text': text
                                })
                            except asyncio.QueueFull:
                                pass
                    elif self._ws_fragment_opcode == 2:
                        if self._websocket_receive_queue:
                            try:
                                self._websocket_receive_queue.put_nowait({
                                    'type': 'websocket.receive',
                                    'bytes': bytes(self._ws_fragment_buffer)
                                })
                            except asyncio.QueueFull:
                                pass
                    self._ws_fragment_buffer.clear()
                    self._ws_fragment_opcode = None
            elif opcode == 8:
                code = 1000
                reason = ''
                if len(payload) >= 2:
                    code = int.from_bytes(payload[:2], 'big')
                    if code < 1000 or code in (1004, 1005, 1006) or (1015 <= code <= 1999) or (code >= 5000):
                        code = 1002
                    if len(payload) > 2:
                        try:
                            reason = payload[2:].decode('utf-8')
                        except UnicodeDecodeError:
                            reason = ''
                close_payload = code.to_bytes(2, 'big') + reason.encode('utf-8')[:123]
                self._loop.create_task(self._send_websocket_frame(8, close_payload))
                if self._websocket_receive_queue:
                    try:
                        self._websocket_receive_queue.put_nowait({
                            'type': 'websocket.disconnect',
                            'code': code
                        })
                    except asyncio.QueueFull:
                        pass
            elif opcode == 9:
                self._loop.create_task(self._send_websocket_frame(10, payload))
            elif opcode == 10:
                if hasattr(self, '_last_heartbeat'):
                    self._last_heartbeat = self._loop.time()
        except Exception as e:
            logger.error(f"WebSocket frame processing error: {e}")
            self.transport.close()
    
    async def _accept_websocket(self, scope: Dict[str, Any], handler: Callable):
        key = self.parser.headers.get('sec-websocket-key')
        if not key:
            self._send_error_response(400, "Missing Sec-WebSocket-Key")
            return

        connection_header = self.parser.headers.get('connection', '').lower()
        if 'upgrade' not in connection_header:
            self._send_error_response(400, "Missing Connection: Upgrade header")
            return

        upgrade_header = self.parser.headers.get('upgrade', '').lower()
        if upgrade_header != 'websocket':
            self._send_error_response(400, "Invalid Upgrade header")
            return

        version = self.parser.headers.get('sec-websocket-version')
        if not version:
            self._send_error_response(400, "Missing Sec-WebSocket-Version header")
            return
        if version != '13':
            self._send_error_response(400, "Unsupported WebSocket version")
            return
        
        import base64
        import hashlib
        
        magic_string = key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
        accept_key = base64.b64encode(hashlib.sha1(magic_string.encode()).digest()).decode()
        
        response = b"HTTP/1.1 101 Switching Protocols\r\n"
        response += b"Upgrade: websocket\r\n"
        response += b"Connection: Upgrade\r\n"
        response += f"Sec-WebSocket-Accept: {accept_key}\r\n".encode('utf-8')
        
        client_protocols = self.parser.headers.get('sec-websocket-protocol', '')
        if client_protocols:
            requested = [p.strip() for p in client_protocols.split(',')]
            if requested:
                selected = requested[0]
                response += f"Sec-WebSocket-Protocol: {selected}\r\n".encode('utf-8')
                scope['subprotocol'] = selected
        
        response += b"\r\n"
        
        self.transport.write(response)
        
        async def receive():
            return await self._websocket_receive_queue.get()
        
        async def send(message):
            if isinstance(message, dict):
                if message['type'] == 'websocket.send':
                    data = message.get('text') or message.get('bytes')
                    if data:
                        if isinstance(data, str):
                            await self._send_websocket_frame(1, data.encode('utf-8'))
                        elif isinstance(data, bytes):
                            await self._send_websocket_frame(2, data)
                elif message['type'] == 'websocket.ping':
                    data = message.get('bytes', b'')
                    await self._send_websocket_frame(9, data)
                elif message['type'] == 'websocket.close':
                    code = message.get('code', 1000)
                    reason = message.get('reason', '').encode('utf-8')
                    close_data = code.to_bytes(2, 'big') + reason
                    await self._send_websocket_frame(8, close_data)
        
        self._websocket_receive_queue = asyncio.Queue(maxsize=100)
        self._ws_buffer = bytearray()
        self._ws_max_message_size = 16 * 1024 * 1024
        self._ws_fragment_buffer = bytearray()
        self._ws_fragment_opcode = None
        
        original_data_received = self.data_received
        
        def websocket_data_received(data: bytes):
            try:
                self._ws_buffer.extend(data)
                if len(self._ws_buffer) > self._ws_max_message_size:
                    logger.warning("WebSocket message too large (buffered)")
                    self._ws_buffer.clear()
                    self.transport.close()
                    return
                consumed = self._process_websocket_frames(bytes(self._ws_buffer))
                if consumed > 0:
                    del self._ws_buffer[:consumed]
            except Exception as e:
                logger.error(f"WebSocket frame error: {e}")
                self._ws_buffer.clear()
                self.transport.close()
        
        self.data_received = websocket_data_received
        
        ws = _ServerWebSocketConnection(scope, receive, send)
        self._websocket = ws
        
        ws_manager = get_websocket_manager()
        await ws_manager.add(ws)
        
        self._last_heartbeat = self._loop.time()
        self._heartbeat_task = self._loop.create_task(self._websocket_heartbeat())
        
        try:
            await handler(ws)
        finally:
            if self._heartbeat_task and not self._heartbeat_task.done():
                self._heartbeat_task.cancel()
            
            self.data_received = original_data_received
            
            await ws_manager.remove(ws.id)
            self.transport.close()
    
    async def _websocket_heartbeat(self):
        """WebSocket心跳检测"""
        while True:
            try:
                await asyncio.sleep(30)
                if self._websocket:
                    await self._websocket.send({"type": "websocket.ping"})
                
                if self._loop.time() - self._last_heartbeat > 60:
                    logger.debug("WebSocket heartbeat timeout")
                    self.transport.close()
                    break
            except Exception as e:
                logger.error(f"WebSocket heartbeat error: {e}")
                break
    
    async def _handle_request(self):
        """异步处理请求"""
        try:
            request_task = self._loop.create_task(self._process_request())
            
            try:
                await asyncio.wait_for(
                    request_task,
                    timeout=self._request_timeout
                )
            except asyncio.TimeoutError:
                request_task.cancel()
                self._send_error_response(408, "Request Timeout")
                
        except Exception as e:
            logger.error(f"Error handling request: {e}")
            self._send_error_response(500, "Internal Server Error")
    
    async def _process_request(self):
        """处理请求逻辑"""
        try:
            request = self._build_request()
            self._current_request = request
            
            response = await self.app.handle_request(request)
            
            response_time = self._loop.time() - self._start_time
            if 'X-Response-Time' not in response.headers:
                response.headers['X-Response-Time'] = f"{response_time:.3f}s"
            
            self._send_response(response)
            
        except Exception as e:
            logger.error(f"Request processing error: {e}")
            self._send_error_response(500, "Internal Server Error")
    
    def _build_request(self) -> Request:
        """构建请求对象"""
        path = self.parser.url or "/"
        query_string = ""
        if "?" in path:
            path, query_string = path.split("?", 1)
        query_params = parse_qs(query_string, keep_blank_values=True)
        
        client_ip = self._peername[0] if self._peername else ""
        
        return Request(
            method=self.parser.method or "GET",
            path=path,
            headers=self.parser.headers,
            query_params=query_params,
            body=self.parser.body,
            client_ip=client_ip,
            protocol=f"HTTP/{self.parser.version or '1.1'}",
            app=self.app
        )
    
    def _send_response(self, response):
        if not self.transport or self.transport.is_closing():
            return
        
        try:
            is_streaming = getattr(response, 'is_streaming', False) and hasattr(response, 'stream_generator')
            
            status_line = f"HTTP/1.1 {response.status} {_get_reason_phrase(response.status)}\r\n"
            
            cookie_headers = response.get_cookie_headers()
            
            skip_headers = {'content-type', 'content-length', 'transfer-encoding', 'connection', 'server'}

            headers = f"Content-Type: {response.content_type}\r\n"

            if is_streaming:
                headers += f"Transfer-Encoding: chunked\r\n"
            elif 'content-length' not in response.headers:
                headers += f"Content-Length: {len(response.body) if response.body else 0}\r\n"
            else:
                headers += f"Content-Length: {response.headers['content-length']}\r\n"

            if 'server' not in response.headers:
                headers += f"Server: Kewe/{__version__}\r\n"

            if self._keep_alive:
                if 'connection' not in response.headers:
                    headers += f"Connection: keep-alive\r\n"
                headers += f"Keep-Alive: timeout={self._keep_alive_timeout}\r\n"
            else:
                if 'connection' not in response.headers:
                    headers += "Connection: close\r\n"

            for name, value in response.headers.items():
                if name.lower() in skip_headers:
                    continue
                safe_name = str(name).replace('\r', '').replace('\n', '')
                safe_value = str(value).replace('\r', '').replace('\n', '')
                headers += f"{safe_name}: {safe_value}\r\n"
            
            for name, value in cookie_headers:
                safe_name = str(name).replace('\r', '').replace('\n', '')
                safe_value = str(value).replace('\r', '').replace('\n', '')
                headers += f"{safe_name}: {safe_value}\r\n"
            
            if is_streaming:
                header_data = f"{status_line}{headers}\r\n".encode('utf-8')
                self.transport.write(header_data)
                self._streaming_task = asyncio.create_task(self._send_streaming_chunks(response.stream_generator))
                if self.server is not None:
                    self.server._streaming_tasks.add(self._streaming_task)
                    self._streaming_task.add_done_callback(
                        lambda t: self.server._streaming_tasks.discard(t)
                    )
            else:
                response_data = f"{status_line}{headers}\r\n".encode('utf-8') + response.body
                self.transport.write(response_data)
            
            if not is_streaming:
                if self._keep_alive:
                    self.parser.reset()
                    self._http_parser = (httptools.HttpRequestParser if httptools else _HttpParserStub)(self.parser)
                    self._body_received_size = 0
                    self._set_keep_alive_timeout()
                else:
                    self.transport.close()
                
        except Exception as e:
            logger.error(f"Error sending response: {e}")
            if self.transport and not self.transport.is_closing():
                self.transport.close()
    
    async def _send_streaming_chunks(self, generator):
        try:
            async for chunk in generator:
                if not self.transport or self.transport.is_closing():
                    break
                if isinstance(chunk, str):
                    chunk = chunk.encode('utf-8')
                chunk_header = f"{len(chunk):X}\r\n".encode('utf-8')
                self.transport.write(chunk_header + chunk + b"\r\n")
                await asyncio.sleep(0)
            
            if self.transport and not self.transport.is_closing():
                self.transport.write(b"0\r\n\r\n")
            
            if self._keep_alive:
                self.parser.reset()
                self._http_parser = (httptools.HttpRequestParser if httptools else _HttpParserStub)(self.parser)
                self._body_received_size = 0
                self._set_keep_alive_timeout()
            else:
                if self.transport and not self.transport.is_closing():
                    self.transport.close()
        except Exception as e:
            logger.error(f"Streaming error: {e}")
            if self.transport and not self.transport.is_closing():
                self.transport.close()
    
    def _send_error_response(self, status: int, message: str):
        if not self.transport or self.transport.is_closing():
            return
        
        try:
            body = json.dumps({"error": message}).encode('utf-8')
            
            should_close = status >= 500 or not self._keep_alive
            
            status_line = f"HTTP/1.1 {status} {_get_reason_phrase(status)}\r\n"
            conn_header = "close" if should_close else "keep-alive"
            headers = (
                "Content-Type: application/json\r\n"
                f"Content-Length: {len(body)}\r\n"
                f"Connection: {conn_header}\r\n"
                "\r\n"
            )
            response_data = (status_line + headers).encode('utf-8') + body
            
            self.transport.write(response_data)
            if should_close:
                self.transport.close()
            elif self._keep_alive:
                self.parser.reset()
                self._http_parser = (httptools.HttpRequestParser if httptools else _HttpParserStub)(self.parser)
                self._body_received_size = 0
                self._set_keep_alive_timeout()
        except Exception as e:
            logger.error(f"Error sending error response: {e}")
    
    def _set_keep_alive_timeout(self):
        """设置Keep-Alive超时"""
        if self._timeout_handler:
            self._timeout_handler.cancel()
        
        self._timeout_handler = self._loop.call_later(
            self._keep_alive_timeout,
            self._keep_alive_timeout_handler
        )
    
    def _keep_alive_timeout_handler(self):
        if self._request_handler and not self._request_handler.done():
            return
        logger.debug("Keep-Alive timeout, closing connection")
        if self.transport and not self.transport.is_closing():
            self.transport.close()


class KeweServer:
    """
    Kewe HTTP服务器 - server实现
    支持多worker、优雅关闭、信号处理、socket传递
    """
    
    def __init__(
        self,
        app,
        host: str = "0.0.0.0",
        port: int = 8000,
        request_timeout: float = 60.0,
        keep_alive_timeout: float = 5.0,
        request_max_size: int = 100 * 1024 * 1024,
        backlog: int = 100,
        ssl_context: Optional[ssl.SSLContext] = None,
        max_connections: int = 10000,
        graceful_shutdown_timeout: float = 30.0
    ):
        self.app = app
        self.host = host
        self.port = port
        self.server: Optional[asyncio.AbstractServer] = None
        self.loop: Optional[asyncio.AbstractEventLoop] = None
        
        self._request_timeout = request_timeout
        self._keep_alive_timeout = keep_alive_timeout
        self._request_max_size = request_max_size
        self._backlog = backlog
        self._ssl_context = ssl_context
        self._max_connections = max_connections
        
        self._running = False
        self._shutdown_event: Optional[asyncio.Event] = None
        self._connections: set = set()
        self._streaming_tasks: set = set()
        self._graceful_shutdown_timeout = graceful_shutdown_timeout
        self._is_shutting_down = False

        # KeepAliveManager集成 - 全局连接跟踪
        from kewe.http.keepalive import KeepAliveManager, KeepAliveConfig
        self._keepalive_manager = KeepAliveManager(
            KeepAliveConfig(timeout=keep_alive_timeout, max_requests=1000)
        )

        # 连接统计
        self._total_requests_served = 0
        self._total_bytes_received = 0
        self._total_bytes_sent = 0
        self._start_time: Optional[float] = None

        if not hasattr(self.app, '_active_connections'):
            self.app._active_connections = 0
        if not hasattr(self.app, '_active_connections_lock'):
            self.app._active_connections_lock = threading.Lock()
    
    def _create_protocol(self):
        return RequestHandler(
            self.app,
            loop=self.loop,
            request_timeout=self._request_timeout,
            keep_alive_timeout=self._keep_alive_timeout,
            request_max_size=self._request_max_size,
            max_connections=self._max_connections,
            server=self
        )
    
    async def start(self, sock: socket.socket = None):
        self.loop = asyncio.get_running_loop()
        self._shutdown_event = asyncio.Event()
        
        try:
            if hasattr(self.app, '_state_manager'):
                from kewe.application.state import AppState
                self.app._state_manager.transition_to(AppState.STARTING, "Server starting")
            
            await self._execute_lifecycle_hooks("before_server_start")
            
            if sock is not None:
                self.server = await self.loop.create_server(
                    self._create_protocol,
                    sock=sock,
                    ssl=self._ssl_context
                )
                sock_addr = sock.getsockname()
                logger.info(f"Server running on http{'s' if self._ssl_context else ''}://{sock_addr[0]}:{sock_addr[1]} (passed socket)")
            else:
                self.server = await self.loop.create_server(
                    self._create_protocol,
                    self.host,
                    self.port,
                    backlog=self._backlog,
                    ssl=self._ssl_context
                )
                logger.info(f"Server running on http{'s' if self._ssl_context else ''}://{self.host}:{self.port}")
            
            self._running = True
            self._start_time = time.monotonic()
            self._keepalive_manager.start()
            logger.info(f"Workers: {os.cpu_count()}")
            logger.info(f"Max connections: {self._max_connections}")
            logger.info(f"KeepAlive enabled: timeout={self._keep_alive_timeout}s")
            
            self._setup_signal_handlers()
            
            await self._execute_lifecycle_hooks("after_server_start")
            
            if hasattr(self.app, '_state_manager'):
                from kewe.application.state import AppState
                self.app._state_manager.transition_to(AppState.RUNNING, "Server running")
            
            await self._shutdown_event.wait()
            
        except Exception as e:
            logger.error(f"Server error: {e}")
            raise
        finally:
            await self.stop()
    
    async def _execute_lifecycle_hooks(self, hook_type: str):
        if hook_type == "before_server_start":
            if hasattr(self.app, '_lifespan_ctx') and self.app._lifespan_ctx is not None:
                try:
                    await self.app._lifespan_ctx.__aenter__()
                except Exception as e:
                    logger.error(f"lifespan startup error: {e}")
            if hasattr(self.app, 'middleware_manager'):
                mm = self.app.middleware_manager
                for mw in mm.before_server_start_middlewares:
                    try:
                        if mw.is_async:
                            await mw.middleware(self.app, self.loop)
                        else:
                            mw.middleware(self.app, self.loop)
                    except Exception as e:
                        logger.error(f"before_server_start hook error: {e}")
        elif hook_type == "after_server_start":
            if hasattr(self.app, 'middleware_manager'):
                mm = self.app.middleware_manager
                for mw in mm.after_server_start_middlewares:
                    try:
                        if mw.is_async:
                            await mw.middleware(self.app, self.loop)
                        else:
                            mw.middleware(self.app, self.loop)
                    except Exception as e:
                        logger.error(f"after_server_start hook error: {e}")
        elif hook_type == "before_server_stop":
            if hasattr(self.app, 'middleware_manager'):
                mm = self.app.middleware_manager
                for mw in mm.before_server_stop_middlewares:
                    try:
                        if mw.is_async:
                            await mw.middleware(self.app, self.loop)
                        else:
                            mw.middleware(self.app, self.loop)
                    except Exception as e:
                        logger.error(f"before_server_stop hook error: {e}")
        elif hook_type == "after_server_stop":
            if hasattr(self.app, 'middleware_manager'):
                mm = self.app.middleware_manager
                for mw in mm.after_server_stop_middlewares:
                    try:
                        if mw.is_async:
                            await mw.middleware(self.app, self.loop)
                        else:
                            mw.middleware(self.app, self.loop)
                    except Exception as e:
                        logger.error(f"after_server_stop hook error: {e}")
            if hasattr(self.app, '_lifespan_ctx') and self.app._lifespan_ctx is not None:
                try:
                    await self.app._lifespan_ctx.__aexit__(None, None, None)
                except Exception as e:
                    logger.error(f"lifespan shutdown error: {e}")
    
    def _setup_signal_handlers(self):
        """设置信号处理器"""
        try:
            for sig in ('SIGINT', 'SIGTERM'):
                if hasattr(signal, sig):
                    self.loop.add_signal_handler(
                        getattr(signal, sig),
                        self._signal_handler
                    )
        except (NotImplementedError, ValueError):
            pass
    
    def _signal_handler(self):
        """信号处理"""
        logger.info("Received shutdown signal")
        self._shutdown_event.set()
    
    async def stop(self, graceful: bool = True):
        if not self._running:
            return
        
        self._running = False
        self._is_shutting_down = True
        logger.info("Shutting down server...")
        
        await self._execute_lifecycle_hooks("before_server_stop")
        
        ws_manager = get_websocket_manager()
        await ws_manager.close_all()
        
        for task in list(self._streaming_tasks):
            if not task.done():
                task.cancel()
        if self._streaming_tasks:
            await asyncio.gather(*self._streaming_tasks, return_exceptions=True)
            self._streaming_tasks.clear()
        
        if self.server:
            self.server.close()
            
            if graceful and self.app._active_connections > 0:
                logger.info(
                    f"Waiting for {self.app._active_connections} active connections "
                    f"to close (timeout: {self._graceful_shutdown_timeout}s)"
                )
                
                try:
                    await asyncio.wait_for(
                        self._wait_for_connections(),
                        timeout=self._graceful_shutdown_timeout
                    )
                    logger.info("All connections closed gracefully")
                except asyncio.TimeoutError:
                    logger.warning(
                        f"Graceful shutdown timeout, forcing close "
                        f"({self.app._active_connections} connections remaining)"
                    )
            
            await self.server.wait_closed()
        
        await self._execute_lifecycle_hooks("after_server_stop")

        self._keepalive_manager.stop()

        self._is_shutting_down = False
        self._shutdown_event.clear()

        logger.info("Server stopped")
    
    async def _wait_for_connections(self):
        """等待所有连接关闭"""
        if not hasattr(self.app, '_connections_zero_event'):
            while self.app._active_connections > 0:
                await asyncio.sleep(0.1)
            return
        while self.app._active_connections > 0:
            try:
                await asyncio.wait_for(self.app._connections_zero_event.wait(), timeout=1.0)
                self.app._connections_zero_event.clear()
            except asyncio.TimeoutError:
                pass
    
    @property
    def is_shutting_down(self) -> bool:
        """服务器是否正在关闭"""
        return self._is_shutting_down

    @property
    def stats(self) -> dict:
        """服务器运行统计"""
        uptime = time.monotonic() - self._start_time if self._start_time else 0
        return {
            "running": self._running,
            "shutting_down": self._is_shutting_down,
            "uptime_seconds": round(uptime, 2),
            "active_connections": self.app._active_connections,
            "total_requests": self._total_requests_served,
            "total_bytes_received": self._total_bytes_received,
            "total_bytes_sent": self._total_bytes_sent,
            "max_connections": self._max_connections,
            "keepalive_timeout": self._keep_alive_timeout,
            "streaming_tasks": len(self._streaming_tasks),
            "host": self.host,
            "port": self.port,
        }

    def increment_requests(self):
        self._total_requests_served += 1

    def add_bytes_received(self, n: int):
        self._total_bytes_received += n

    def add_bytes_sent(self, n: int):
        self._total_bytes_sent += n


async def serve(
    app,
    host: str = "0.0.0.0",
    port: int = 8000,
    debug: bool = False,
    workers: int = 1,
    request_timeout: float = 60.0,
    keep_alive_timeout: float = 5.0,
    request_max_size: int = 100 * 1024 * 1024,
    ssl_context: Optional[ssl.SSLContext] = None,
    **kwargs
) -> None:
    """
    运行服务器 - serve函数
    
    Args:
        app: Kewe应用实例
        host: 主机地址
        port: 端口
        debug: 调试模式
        workers: worker数量
        request_timeout: 请求超时时间
        keep_alive_timeout: Keep-Alive超时时间
        request_max_size: 最大请求体大小
        ssl_context: SSL上下文
    """
    if workers > 1:
        from kewe.worker.manager import serve_multi
        await serve_multi(
            app,
            host=host,
            port=port,
            workers=workers,
            debug=debug,
            request_timeout=request_timeout,
            keep_alive_timeout=keep_alive_timeout,
            request_max_size=request_max_size,
            ssl_context=ssl_context,
            **kwargs
        )
    else:
        server = KeweServer(
            app,
            host=host,
            port=port,
            request_timeout=request_timeout,
            keep_alive_timeout=keep_alive_timeout,
            request_max_size=request_max_size,
            ssl_context=ssl_context
        )
        await server.start()


__all__ = [
    'HttpRequestParser',
    'RequestHandler',
    'KeweServer',
    'serve',
    'ParserState',
    'HttpStreamBuffer',
]
