#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.server.lifecycle - Server lifecycle management with graceful shutdown
"""

import asyncio
import logging
import threading
from enum import Enum, auto
from typing import Callable, List, Optional, Dict, Any, Coroutine
from dataclasses import dataclass, field
from datetime import datetime

logger = logging.getLogger(__name__)


class ServerState(Enum):
    """
    服务器状态枚举
    
    状态流转:
        NONE -> STARTING -> SERVING -> STOPPING -> STOPPED
    """
    NONE = auto()       # 初始状态
    STARTING = auto()   # 正在启动
    SERVING = auto()    # 服务中
    STOPPING = auto()   # 正在停止
    STOPPED = auto()    # 已停止
    
    def __str__(self):
        return self.name
    
    def __repr__(self):
        return f"ServerState.{self.name}"


@dataclass
class ServerStateTransition:
    """状态转换记录"""
    from_state: ServerState
    to_state: ServerState
    timestamp: datetime = field(default_factory=datetime.now)
    reason: Optional[str] = None
    
    def __str__(self):
        return f"{self.from_state.name} -> {self.to_state.name} at {self.timestamp}"


class ServerLifecycle:
    """
    服务器生命周期管理器
    
    提供:
    - 状态机管理
    - 状态转换监听
    - 生命周期钩子
    - 状态历史记录
    - 健康检查钩子
    - 优雅关闭超时
    """
    
    def __init__(self):
        self._state = ServerState.NONE
        self._state_lock = threading.Lock()
        self._transitions: List[ServerStateTransition] = []
        self._handlers: Dict[ServerState, List[Callable]] = {
            state: [] for state in ServerState
        }
        self._transition_handlers: List[Callable[[ServerState, ServerState], None]] = []
        self._health_check_handlers: List[Callable[[], Coroutine[Any, Any, bool]]] = []
        self._start_time: Optional[datetime] = None
        self._stop_time: Optional[datetime] = None
        self._graceful_shutdown_timeout: float = 30.0
        self._health_check_interval: float = 30.0
        self._health_check_task: Optional[asyncio.Task] = None

    def _get_state_lock(self):
        return self._state_lock
    
    @property
    def state(self) -> ServerState:
        """获取当前状态"""
        return self._state
    
    @property
    def is_running(self) -> bool:
        """检查是否正在运行"""
        return self._state == ServerState.SERVING
    
    @property
    def is_starting(self) -> bool:
        """检查是否正在启动"""
        return self._state == ServerState.STARTING
    
    @property
    def is_stopping(self) -> bool:
        """检查是否正在停止"""
        return self._state == ServerState.STOPPING
    
    @property
    def is_stopped(self) -> bool:
        """检查是否已停止"""
        return self._state == ServerState.STOPPED
    
    @property
    def uptime(self) -> Optional[float]:
        """获取运行时间（秒）"""
        if self._start_time is None:
            return None
        if self._stop_time is not None:
            return (self._stop_time - self._start_time).total_seconds()
        return (datetime.now() - self._start_time).total_seconds()
    
    @property
    def transitions(self) -> List[ServerStateTransition]:
        """获取状态转换历史"""
        return self._transitions.copy()
    
    def _validate_transition(self, from_state: ServerState, to_state: ServerState) -> bool:
        """
        验证状态转换是否合法
        
        合法转换:
            NONE -> STARTING
            STARTING -> SERVING
            STARTING -> STOPPED (启动失败)
            SERVING -> STOPPING
            STOPPING -> STOPPED
            STOPPED -> STARTING (重启)
        """
        valid_transitions = {
            ServerState.NONE: [ServerState.STARTING],
            ServerState.STARTING: [ServerState.SERVING, ServerState.STOPPED],
            ServerState.SERVING: [ServerState.STOPPING],
            ServerState.STOPPING: [ServerState.STOPPED],
            ServerState.STOPPED: [ServerState.STARTING],
        }
        return to_state in valid_transitions.get(from_state, [])
    
    async def transition_to(self, new_state: ServerState, reason: str = None) -> bool:
        with self._get_state_lock():
            old_state = self._state
            
            if old_state == new_state:
                logger.debug(f"Already in state {new_state}")
                return True
            
            if not self._validate_transition(old_state, new_state):
                logger.error(
                    f"Invalid state transition: {old_state} -> {new_state}"
                )
                return False
            
            transition = ServerStateTransition(
                from_state=old_state,
                to_state=new_state,
                reason=reason
            )
            self._transitions.append(transition)
            
            self._state = new_state
            
            if new_state == ServerState.SERVING:
                self._start_time = datetime.now()
            elif new_state == ServerState.STOPPED:
                self._stop_time = datetime.now()
            
            logger.info(f"Server state: {old_state} -> {new_state} ({reason or 'no reason'})")
        
        await self._call_state_handlers(new_state)
        await self._call_transition_handlers(old_state, new_state)
        
        return True
    
    async def _call_state_handlers(self, state: ServerState):
        """调用状态处理器"""
        handlers = self._handlers.get(state, [])
        for handler in handlers:
            try:
                if asyncio.iscoroutinefunction(handler):
                    await handler()
                else:
                    handler()
            except Exception as e:
                logger.error(f"State handler error for {state}: {e}")
    
    async def _call_transition_handlers(self, from_state: ServerState, to_state: ServerState):
        """调用转换处理器"""
        for handler in self._transition_handlers:
            try:
                if asyncio.iscoroutinefunction(handler):
                    await handler(from_state, to_state)
                else:
                    handler(from_state, to_state)
            except Exception as e:
                logger.error(f"Transition handler error: {e}")
    
    def on_state(self, state: ServerState, handler: Callable):
        """
        注册状态处理器
        
        Args:
            state: 监听的状态
            handler: 处理器函数
        """
        self._handlers[state].append(handler)
    
    def on_transition(self, handler: Callable[[ServerState, ServerState], None]):
        """
        注册状态转换处理器
        
        Args:
            handler: 处理器函数，接收(from_state, to_state)参数
        """
        self._transition_handlers.append(handler)
    
    # 便捷装饰器
    def on_starting(self, handler: Callable):
        """注册STARTING状态处理器"""
        self.on_state(ServerState.STARTING, handler)
        return handler
    
    def on_serving(self, handler: Callable):
        """注册SERVING状态处理器"""
        self.on_state(ServerState.SERVING, handler)
        return handler
    
    def on_stopping(self, handler: Callable):
        """注册STOPPING状态处理器"""
        self.on_state(ServerState.STOPPING, handler)
        return handler
    
    def on_stopped(self, handler: Callable):
        """注册STOPPED状态处理器"""
        self.on_state(ServerState.STOPPED, handler)
        return handler
    
    async def start(self) -> bool:
        """启动服务"""
        result = await self.transition_to(ServerState.STARTING, "Server starting")
        return result
    
    async def serve(self) -> bool:
        """开始服务"""
        result = await self.transition_to(ServerState.SERVING, "Server now serving")
        if result:
            self._start_health_check_loop()
        return result
    
    async def stop(self, timeout: Optional[float] = None) -> bool:
        """停止服务（支持优雅关闭超时）

        Args:
            timeout: 优雅关闭超时时间（秒），None使用默认值

        Returns:
            True if stopped gracefully, False if timed out
        """
        effective_timeout = timeout if timeout is not None else self._graceful_shutdown_timeout
        self._stop_health_check_loop()

        result = await self.transition_to(ServerState.STOPPING, "Server stopping")

        if result and effective_timeout > 0:
            try:
                loop = asyncio.get_running_loop()
                done = loop.create_task(self._wait_for_handlers(effective_timeout))
                await asyncio.wait_for(done, timeout=effective_timeout)
            except asyncio.TimeoutError:
                logger.warning(
                    f"Graceful shutdown timed out after {effective_timeout}s, forcing stop"
                )
                result = True
            except RuntimeError:
                result = True

        return result
    
    async def _wait_for_handlers(self, timeout: float):
        """等待所有停止处理器完成"""
        handlers = self._handlers.get(ServerState.STOPPING, [])
        if not handlers:
            return
        tasks = []
        for handler in handlers:
            try:
                if asyncio.iscoroutinefunction(handler):
                    tasks.append(asyncio.create_task(handler()))
            except Exception:
                logger.warning("Lifecycle handler creation failed", exc_info=True)
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
    
    async def finish(self) -> bool:
        """完成停止"""
        return await self.transition_to(ServerState.STOPPED, "Server stopped")

    def on_health_check(self, handler: Callable[[], Coroutine[Any, Any, bool]]):
        """注册健康检查处理器

        Args:
            handler: 异步函数，返回True表示健康，False表示不健康
        """
        self._health_check_handlers.append(handler)
        return handler

    async def check_health(self) -> Dict[str, Any]:
        """执行所有健康检查

        Returns:
            包含整体健康状态和各项检查结果的字典
        """
        results = {}
        all_healthy = True

        for handler in self._health_check_handlers:
            name = getattr(handler, '__name__', repr(handler))
            try:
                healthy = await handler()
                results[name] = {"healthy": bool(healthy), "error": None}
                if not healthy:
                    all_healthy = False
            except Exception as e:
                results[name] = {"healthy": False, "error": str(e)}
                all_healthy = False

        return {
            "status": "healthy" if all_healthy else "unhealthy",
            "state": self._state.name,
            "uptime": self.uptime,
            "checks": results,
        }

    def set_graceful_shutdown_timeout(self, timeout: float):
        """设置优雅关闭超时时间

        Args:
            timeout: 超时时间（秒）
        """
        self._graceful_shutdown_timeout = max(0.0, timeout)

    def set_health_check_interval(self, interval: float):
        """设置健康检查间隔

        Args:
            interval: 间隔时间（秒）
        """
        self._health_check_interval = max(1.0, interval)

    def _start_health_check_loop(self):
        """启动健康检查循环"""
        if self._health_check_task is not None:
            return
        try:
            loop = asyncio.get_running_loop()
            self._health_check_task = loop.create_task(self._health_check_loop())
        except RuntimeError:
            import logging
            logging.getLogger(__name__).warning(
                "Health check loop could not be started: no running event loop. "
                "Health endpoints will report stale data."
            )

    def _stop_health_check_loop(self):
        """停止健康检查循环"""
        if self._health_check_task is not None:
            self._health_check_task.cancel()
            self._health_check_task = None

    async def _health_check_loop(self):
        """健康检查循环"""
        try:
            while self._state == ServerState.SERVING:
                await asyncio.sleep(self._health_check_interval)
                if self._state != ServerState.SERVING:
                    break
                result = await self.check_health()
                if result["status"] != "healthy":
                    logger.warning(f"Health check failed: {result}")
        except asyncio.CancelledError:
            pass
        except Exception as e:
            logger.error(f"Health check loop error: {e}")
    
    def get_state_info(self) -> Dict[str, Any]:
        """获取状态信息"""
        return {
            'state': self._state.name,
            'is_running': self.is_running,
            'is_starting': self.is_starting,
            'is_stopping': self.is_stopping,
            'is_stopped': self.is_stopped,
            'uptime': self.uptime,
            'start_time': self._start_time.isoformat() if self._start_time else None,
            'stop_time': self._stop_time.isoformat() if self._stop_time else None,
            'transitions': [
                {
                    'from': t.from_state.name,
                    'to': t.to_state.name,
                    'timestamp': t.timestamp.isoformat(),
                    'reason': t.reason
                }
                for t in self._transitions
            ]
        }
    
    def __str__(self):
        return f"ServerLifecycle(state={self._state.name})"
    
    def __repr__(self):
        return f"ServerLifecycle(state={self._state.name}, uptime={self.uptime})"


# 全局生命周期实例
_global_lifecycle: Optional[ServerLifecycle] = None


def get_lifecycle() -> ServerLifecycle:
    """获取全局生命周期实例"""
    global _global_lifecycle
    if _global_lifecycle is None:
        _global_lifecycle = ServerLifecycle()
    return _global_lifecycle


def set_lifecycle(lifecycle: ServerLifecycle):
    """设置全局生命周期实例"""
    global _global_lifecycle
    _global_lifecycle = lifecycle


# 便捷函数
def get_server_state() -> ServerState:
    """获取当前服务器状态"""
    return get_lifecycle().state


def is_server_running() -> bool:
    """检查服务器是否正在运行"""
    return get_lifecycle().is_running


# 装饰器支持
def on_server_starting(func: Callable):
    """服务器启动时装饰器"""
    get_lifecycle().on_starting(func)
    return func


def on_server_serving(func: Callable):
    """服务器服务时装饰器"""
    get_lifecycle().on_serving(func)
    return func


def on_server_stopping(func: Callable):
    """服务器停止时装饰器"""
    get_lifecycle().on_stopping(func)
    return func


def on_server_stopped(func: Callable):
    """服务器已停止装饰器"""
    get_lifecycle().on_stopped(func)
    return func
