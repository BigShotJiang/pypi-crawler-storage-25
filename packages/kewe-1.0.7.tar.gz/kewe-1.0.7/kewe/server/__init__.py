#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.server - Server package initialization
"""

from .lifecycle import ServerState, ServerLifecycle
from .http_server import (
    HttpRequestParser,
    RequestHandler,
    KeweServer,
    serve,
    ParserState,
    HttpStreamBuffer,
)
from .asgi import ASGIState, ASGIContext, ASGIAdapter
from .daemon import DaemonConfig, DaemonManager
from .reloader import ReloadConfig, FileInfo, FileWatcher, GracefulRestart
from .ssl import SSLConfig, create_ssl_context, load_ssl_config
from .startup import StartupConfig, StartupManager

StreamBuffer = HttpStreamBuffer

__all__ = [
    'ServerState',
    'ServerLifecycle',
    'HttpRequestParser',
    'RequestHandler',
    'KeweServer',
    'serve',
    'ParserState',
    'HttpStreamBuffer',
    'StreamBuffer',
    'ASGIState',
    'ASGIContext',
    'ASGIAdapter',
    'DaemonConfig',
    'DaemonManager',
    'ReloadConfig',
    'FileInfo',
    'FileWatcher',
    'GracefulRestart',
    'SSLConfig',
    'create_ssl_context',
    'load_ssl_config',
    'StartupConfig',
    'StartupManager',
]
