#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.server.startup - Server startup management and process coordination
"""

import asyncio
import logging
import signal
import sys
from typing import Optional, Callable, List, Dict, Any
from dataclasses import dataclass

from kewe.application.state import ApplicationStateManager, AppState
from kewe.worker.manager import ProcessWorkerManager, WorkerConfig

logger = logging.getLogger(__name__)


@dataclass
class StartupConfig:
    """启动配置"""
    host: str = "0.0.0.0"
    port: int = 8000
    workers: int = 1
    debug: bool = False
    access_log: bool = True
    
    # 性能优化
    auto_optimize: bool = True
    use_uvloop: bool = True
    
    # 超时配置
    request_timeout: float = 60.0
    graceful_timeout: float = 10.0
    keep_alive_timeout: float = 5.0


class StartupManager:
    """
    启动管理器
    
    管理应用的完整启动流程
    """
    
    def __init__(self, app, config: StartupConfig = None):
        self.app = app
        self.config = config or StartupConfig()
        self.state_manager = ApplicationStateManager()
        self.worker_manager: Optional[ProcessWorkerManager] = None
        self._shutdown_event = asyncio.Event()
        self._startup_tasks: List[Callable] = []
        self._cleanup_tasks: List[Callable] = []
        
    def register_startup_task(self, task: Callable):
        """注册启动任务"""
        self._startup_tasks.append(task)
        
    def register_cleanup_task(self, task: Callable):
        """注册清理任务"""
        self._cleanup_tasks.append(task)
        
    async def startup(self):
        """启动应用"""
        logger.info("Starting Kewe application...")
        
        # 初始化状态
        await self.state_manager.start()
        
        try:
            # 1. 性能优化
            if self.config.auto_optimize:
                await self._optimize_performance()
                
            # 2. 执行启动任务
            await self._run_startup_tasks()
            
            # 3. 设置信号处理
            self._setup_signal_handlers()
            
            # 4. 启动服务器
            if self.config.workers > 1:
                await self._start_with_workers()
            else:
                await self._start_single()
                
        except Exception as e:
            logger.error(f"Startup failed: {e}")
            await self.shutdown()
            raise
            
    async def _optimize_performance(self):
        """性能优化 - 在事件循环创建前安装uvloop/winloop"""
        logger.info("Applying performance optimizations...")

        if self.config.use_uvloop:
            try:
                from kewe.utils.compat import auto_select_event_loop
                result = auto_select_event_loop()
                if result:
                    logger.info("Using optimized event loop for better performance")
                else:
                    logger.debug("No optimized event loop available, using default asyncio")
            except Exception as e:
                logger.debug(f"Event loop optimization not available: {e}")

        try:
            from kewe.touchup.performance import setup_performance_optimizations
            setup_performance_optimizations()
            logger.info("Performance optimizations applied")
        except Exception as e:
            logger.debug(f"Performance optimizations not fully available: {e}")

    @staticmethod
    def install_event_loop():
        """在事件循环创建前安装uvloop/winloop - 必须在asyncio.run()之前调用"""
        try:
            from kewe.utils.compat import auto_select_event_loop
            auto_select_event_loop()
        except Exception:
            logger.debug("Non-critical operation failed", exc_info=True)
                
    async def _run_startup_tasks(self):
        """执行启动任务"""
        logger.info(f"Running {len(self._startup_tasks)} startup tasks...")
        
        for task in self._startup_tasks:
            try:
                if asyncio.iscoroutinefunction(task):
                    await task()
                else:
                    task()
            except Exception as e:
                logger.error(f"Startup task failed: {e}")
                
    def _setup_signal_handlers(self):
        """设置信号处理器"""
        try:
            loop = asyncio.get_running_loop()
            for sig in (signal.SIGINT, signal.SIGTERM):
                loop.add_signal_handler(sig, self._signal_handler)
        except (NotImplementedError, ValueError):
            pass
            
    def _signal_handler(self):
        """信号处理"""
        logger.info("Received shutdown signal")
        task = asyncio.create_task(self.shutdown())
        task.add_done_callback(
            lambda t: logger.error("Shutdown task failed", exc_info=t.exception())
            if t.exception() else None
        )
        
    async def _start_single(self):
        """单进程启动"""
        logger.info(f"Starting single process server on {self.config.host}:{self.config.port}")
        
        from kewe.server import KeweServer
        
        server = KeweServer(
            self.app,
            self.config.host,
            self.config.port
        )
        
        await server.start()
        
        # 等待关闭信号
        await self._shutdown_event.wait()
        
        await server.stop()
        
    async def _start_with_workers(self):
        """多进程启动"""
        logger.info(f"Starting with {self.config.workers} workers...")
        
        worker_config = WorkerConfig(
            num_workers=self.config.workers,
            host=self.config.host,
            port=self.config.port,
            debug=self.config.debug,
            access_log=self.config.access_log,
            worker_timeout=int(self.config.graceful_timeout),
            keep_alive_timeout=int(self.config.keep_alive_timeout)
        )
        
        self.worker_manager = ProcessWorkerManager(worker_config)
        
        def worker_target():
            """Worker进程目标函数"""
            import asyncio
            from kewe.server import KeweServer
            
            async def run():
                server = KeweServer(
                    self.app,
                    self.config.host,
                    self.config.port
                )
                await server.start()
                
            asyncio.run(run())
            
        self.worker_manager.start_workers(worker_target)
        
        # 等待关闭信号
        await self._shutdown_event.wait()
        
    async def shutdown(self):
        """关闭应用"""
        logger.info("Shutting down...")
        
        # 停止接受新连接
        await self.state_manager.stop("Shutdown requested")
        
        # 停止Worker进程
        if self.worker_manager:
            self.worker_manager.stop_workers(graceful=True)
            
        # 执行清理任务
        await self._run_cleanup_tasks()
        
        # 触发关闭事件
        self._shutdown_event.set()
        
        logger.info("Shutdown complete")
        
    async def _run_cleanup_tasks(self):
        """执行清理任务"""
        logger.info(f"Running {len(self._cleanup_tasks)} cleanup tasks...")
        
        for task in self._cleanup_tasks:
            try:
                if asyncio.iscoroutinefunction(task):
                    await task()
                else:
                    task()
            except Exception as e:
                logger.error(f"Cleanup task failed: {e}")
                
    def get_status(self) -> Dict[str, Any]:
        """获取启动状态"""
        status = {
            'state': self.state_manager.get_status(),
            'config': {
                'host': self.config.host,
                'port': self.config.port,
                'workers': self.config.workers,
                'debug': self.config.debug
            }
        }
        
        if self.worker_manager:
            status['workers'] = self.worker_manager.get_worker_status()
            
        return status


async def run_app(
    app,
    host: str = "0.0.0.0",
    port: int = 8000,
    workers: int = 1,
    debug: bool = False,
    access_log: bool = True,
    auto_optimize: bool = True,
    **kwargs
):
    """
    运行应用的便捷函数
    
    示例:
        await run_app(app, host="0.0.0.0", port=8000, workers=4)
    """
    config = StartupConfig(
        host=host,
        port=port,
        workers=workers,
        debug=debug,
        access_log=access_log,
        auto_optimize=auto_optimize,
        **kwargs
    )
    
    manager = StartupManager(app, config)
    StartupManager.install_event_loop()
    await manager.startup()


def main():
    """主入口点"""
    import argparse
    
    parser = argparse.ArgumentParser(description="Kewe Application Server")
    parser.add_argument("module", nargs="?", default=None, help="Application module (e.g. myapp:app)")
    parser.add_argument("--host", default="0.0.0.0", help="Host to bind to")
    parser.add_argument("--port", type=int, default=8000, help="Port to bind to")
    parser.add_argument("--workers", type=int, default=1, help="Number of worker processes")
    parser.add_argument("--debug", action="store_true", help="Enable debug mode")
    parser.add_argument("--no-access-log", action="store_true", help="Disable access log")
    parser.add_argument("--reload", action="store_true", help="Enable auto-reload")
    
    args = parser.parse_args()
    
    if args.module:
        from kewe.cli.app import import_app
        try:
            _, app = import_app(args.module)
            run_kwargs = {
                "host": args.host,
                "port": args.port,
                "workers": args.workers,
                "debug": args.debug,
                "access_log": not args.no_access_log,
            }
            if args.reload:
                run_kwargs["reload"] = True
            asyncio.run(run_app(app, **run_kwargs))
        except (ImportError, AttributeError) as e:
            print(f"Error loading application: {e}")
            sys.exit(1)
    else:
        print("Kewe Startup Manager")
        print(f"Configuration: {args}")
        print("Usage: python -m kewe.server.startup myapp:app --host 0.0.0.0 --port 8000")


if __name__ == "__main__":
    main()
