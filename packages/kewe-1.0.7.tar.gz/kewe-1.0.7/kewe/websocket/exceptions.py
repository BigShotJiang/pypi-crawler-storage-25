#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.websocket.exceptions - WebSocket exception classes
"""

from kewe.errors.exceptions import KeweException


class WebSocketException(KeweException):
    """WebSocket基础异常 - 继承KeweException以纳入统一错误处理体系

    注意: WebSocket 关闭代码(code)和 HTTP 状态码(status_code)是不同的概念。
    code 用于 WebSocket 关闭帧, status_code 用于 HTTP 层面错误处理。
    """

    def __init__(self, message: str = "WebSocket error", code: int = 1011, reason: str = ""):
        super().__init__(message=message, status_code=400, error_code="WEBSOCKET_ERROR")
        self.code = code
        self.reason = reason


class WebSocketClosed(WebSocketException):
    """WebSocket连接已关闭"""

    def __init__(self, code: int = 1000, reason: str = ""):
        super().__init__(message=f"WebSocket closed: {code} - {reason}", code=code, reason=reason)
        self.error_code = "WEBSOCKET_CLOSED"


class WebSocketDisconnect(WebSocketException):
    """客户端断开WebSocket连接"""

    def __init__(self, code: int = 1000, reason: str = ""):
        super().__init__(
            message=f"WebSocket disconnected: {code}" + (f" - {reason}" if reason else ""),
            code=code,
            reason=reason,
        )
        self.error_code = "WEBSOCKET_DISCONNECT"


class WebSocketProtocolError(WebSocketException):
    """WebSocket协议错误"""

    def __init__(self, message: str = "WebSocket protocol error"):
        super().__init__(message=message)
        self.error_code = "WEBSOCKET_PROTOCOL_ERROR"


class WebSocketHandshakeError(WebSocketException):
    """WebSocket握手失败"""

    def __init__(self, message: str = "WebSocket handshake failed"):
        super().__init__(message=message, code=1002)
        self.error_code = "WEBSOCKET_HANDSHAKE_ERROR"


class WebSocketTimeout(WebSocketException):
    """WebSocket超时"""

    def __init__(self, message: str = "WebSocket timeout"):
        super().__init__(message=message, code=1002)
        self.error_code = "WEBSOCKET_TIMEOUT"

