#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.websocket.handler - WebSocket handler for connection lifecycle
"""

import asyncio
import logging
from typing import Callable, Optional, List
from functools import wraps

from .protocol import WebSocketProtocol
from .connection import WebSocketConnection
from .manager import websocket_manager

logger = logging.getLogger(__name__)


class WebSocketHandler:
    """
    WebSocket处理器
    
    处理WebSocket连接的生命周期
    """
    
    def __init__(
        self,
        handler: Callable,
        subprotocols: Optional[List[str]] = None,
        compression: bool = True
    ):
        self.handler = handler
        self.subprotocols = subprotocols or []
        self.compression = compression
    
    async def handle(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
        headers: dict,
        request=None
    ):
        """
        处理WebSocket连接
        
        Args:
            reader: 读取流
            writer: 写入流
            headers: HTTP请求头
            request: 原始请求对象
        """
        # 创建协议处理器
        protocol = WebSocketProtocol(
            subprotocols=self.subprotocols,
            compression=self.compression
        )
        
        # 执行握手
        if not await protocol.handshake(reader, writer, headers):
            logger.error("WebSocket handshake failed")
            return
        
        # 创建连接对象
        connection = WebSocketConnection(protocol, request)
        
        # 添加到管理器
        await websocket_manager.add(connection)
        
        try:
            # 调用处理器
            if asyncio.iscoroutinefunction(self.handler):
                await self.handler(connection)
            else:
                self.handler(connection)
        except Exception as e:
            logger.error(f"WebSocket handler error: {e}")
        finally:
            # 关闭连接
            await connection.close()
            # 从管理器移除
            await websocket_manager.remove(connection.id)


def websocket(
    path: str,
    subprotocols: Optional[List[str]] = None,
    compression: bool = True
):
    """
    WebSocket路由装饰器
    
    示例:
        @app.websocket('/ws')
        async def ws_handler(connection):
            while True:
                message = await connection.receive()
                if message is None:
                    break
                await connection.send(f"Echo: {message}")
    
    Args:
        path: WebSocket路径
        subprotocols: 支持的子协议列表
        compression: 是否启用压缩
    """
    def decorator(handler: Callable):
        handler._websocket_path = path
        handler._websocket_handler = WebSocketHandler(
            handler=handler,
            subprotocols=subprotocols,
            compression=compression
        )
        handler.__websocket__ = True
        return handler
    
    return decorator


# 便捷函数
async def broadcast(message: str):
    """广播消息给所有连接"""
    await websocket_manager.broadcast(message)


async def broadcast_to_group(group_name: str, message: str):
    """广播消息给分组"""
    await websocket_manager.broadcast_to_group(group_name, message)


def get_connection_count() -> int:
    """获取连接数量"""
    return websocket_manager.connection_count
