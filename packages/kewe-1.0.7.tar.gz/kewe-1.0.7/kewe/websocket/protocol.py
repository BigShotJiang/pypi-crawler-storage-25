#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.websocket.protocol - WebSocket protocol implementation
"""

import asyncio
import base64
import hashlib
import logging
import struct
import zlib
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from enum import Enum

logger = logging.getLogger(__name__)


class WebSocketOpCode(Enum):
    """WebSocket操作码"""
    CONTINUATION = 0x0
    TEXT = 0x1
    BINARY = 0x2
    CLOSE = 0x8
    PING = 0x9
    PONG = 0xa


@dataclass
class WebSocketExtension:
    """WebSocket扩展"""
    name: str
    params: Dict[str, Any] = field(default_factory=dict)


class WebSocketProtocol:
    """WebSocket协议处理器"""
    DEFAULT_MAX_PAYLOAD_SIZE = 1 * 1024 * 1024  # 1MB
    DEFAULT_MAX_DECOMPRESS_SIZE = 4 * 1024 * 1024  # 4MB

    def __init__(
        self,
        subprotocols: List[str] = None,
        extensions: List[WebSocketExtension] = None,
        compression: bool = True,
        max_payload_size: int = None
    ):
        self.subprotocols = subprotocols or []
        self.extensions = extensions or []
        self.compression = compression

        self._reader: asyncio.StreamReader = None
        self._writer: asyncio.StreamWriter = None
        self._subprotocol: Optional[str] = None
        self._accepted_extensions: List[WebSocketExtension] = []
        self._compression_context = None
        self._decompressor: Optional[zlib.decompressobj] = None
        self._compressor: Optional[zlib.compressobj] = None
        self._max_payload_size = max_payload_size or self.DEFAULT_MAX_PAYLOAD_SIZE

        self._closed = False
        self._close_code = None
        self._close_reason = None
        self._handshake_complete = False
        self._client_key = None
    
    async def handshake(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
        headers: Dict[str, str]
    ) -> bool:
        """
        执行WebSocket握手
        
        Args:
            reader: 读取流
            writer: 写入流
            headers: HTTP请求头
            
        Returns:
            握手是否成功
        """
        self._reader = reader
        self._writer = writer

        ws_key = headers.get('sec-websocket-key')
        if not ws_key:
            logger.error("Missing Sec-WebSocket-Key")
            return False

        self._client_key = ws_key
        
        # 验证WebSocket版本
        ws_version = headers.get('sec-websocket-version')
        if ws_version != '13':
            logger.error(f"Unsupported WebSocket version: {ws_version}")
            return False
        
        # 处理子协议
        client_protocols = headers.get('sec-websocket-protocol', '')
        if client_protocols:
            client_protocol_list = [p.strip() for p in client_protocols.split(',')]
            for protocol in self.subprotocols:
                if protocol in client_protocol_list:
                    self._subprotocol = protocol
                    break
        
        # 处理扩展
        client_extensions = headers.get('sec-websocket-extensions', '')
        if client_extensions and self.compression:
            # 检查是否支持permessage-deflate
            if 'permessage-deflate' in client_extensions:
                ext = WebSocketExtension(
                    name='permessage-deflate',
                    params={'server_no_context_takeover': True}
                )
                self._accepted_extensions.append(ext)
                self._compression_context = zlib.compressobj(
                    zlib.Z_DEFAULT_COMPRESSION,
                    zlib.DEFLATED,
                    -zlib.MAX_WBITS
                )
        
        # 计算Accept Key
        magic_string = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
        accept_key = base64.b64encode(
            hashlib.sha1((ws_key + magic_string).encode()).digest()
        ).decode()
        
        # 构建响应头
        response_headers = [
            "HTTP/1.1 101 Switching Protocols",
            "Upgrade: websocket",
            "Connection: Upgrade",
            f"Sec-WebSocket-Accept: {accept_key}"
        ]
        
        # 添加子协议
        if self._subprotocol:
            response_headers.append(f"Sec-WebSocket-Protocol: {self._subprotocol}")
        
        # 添加扩展
        if self._accepted_extensions:
            ext_header = "Sec-WebSocket-Extensions: " + ", ".join([
                f"{ext.name}" for ext in self._accepted_extensions
            ])
            response_headers.append(ext_header)
        
        # 发送响应
        response = "\r\n".join(response_headers) + "\r\n\r\n"
        writer.write(response.encode())
        await writer.drain()
        
        logger.info(f"WebSocket handshake successful, subprotocol: {self._subprotocol}")
        self._handshake_complete = True
        return True
    
    async def receive(self) -> Optional[tuple]:
        fragment_buffer = bytearray()
        fragment_opcode = None
        
        while True:
            try:
                header = await self._reader.read(2)
                if len(header) < 2:
                    return None
                
                fin = (header[0] >> 7) & 1
                rsv1 = (header[0] >> 6) & 1
                rsv2 = (header[0] >> 5) & 1
                rsv3 = (header[0] >> 4) & 1
                opcode = header[0] & 0x0f
                masked = (header[1] >> 7) & 1
                payload_len = header[1] & 0x7f
                
                has_compression = bool(self._compression_context) or any(
                    ext.name == 'permessage-deflate' for ext in self._accepted_extensions
                )
                if rsv1 and not (has_compression and opcode in (0x1, 0x2, 0x0)):
                    await self.close(1002, "Non-zero RSV1 bit without extension negotiation")
                    return None
                if rsv2 or rsv3:
                    await self.close(1002, "Non-zero RSV2/RSV3 bits without extension negotiation")
                    return None
                
                if payload_len == 126:
                    len_bytes = await self._reader.read(2)
                    payload_len = struct.unpack('!H', len_bytes)[0]
                elif payload_len == 127:
                    len_bytes = await self._reader.read(8)
                    payload_len = struct.unpack('!Q', len_bytes)[0]
                
                if payload_len > self._max_payload_size:
                    logger.error(f"Payload too large: {payload_len} > {self._max_payload_size}")
                    await self.close(1009, "Payload too large")
                    return None

                mask_key = None
                if masked:
                    mask_key = await self._reader.read(4)

                payload = await self._reader.read(payload_len)
                
                if masked and mask_key:
                    unmasked = bytearray(len(payload))
                    for i in range(len(payload)):
                        unmasked[i] = payload[i] ^ mask_key[i % 4]
                    payload = bytes(unmasked)
                
                if self._compression_context and opcode in [1, 2, 0]:
                    try:
                        if self._decompressor is None:
                            self._decompressor = zlib.decompressobj(-zlib.MAX_WBITS)
                        decompressed = self._decompressor.decompress(payload)
                        if fin:
                            decompressed += self._decompressor.flush()
                            self._decompressor = zlib.decompressobj(-zlib.MAX_WBITS)
                        if len(decompressed) > self.DEFAULT_MAX_DECOMPRESS_SIZE:
                            logger.error(f"Decompressed payload too large: {len(decompressed)}")
                            await self.close(1009, "Decompressed payload too large")
                            return None
                        payload = decompressed
                    except Exception as e:
                        logger.error(f"Decompression error: {e}")
                
                if opcode == WebSocketOpCode.CLOSE.value:
                    if not fin:
                        await self.close(1002, "Control frame must not be fragmented")
                        return None
                    if payload_len > 125:
                        await self.close(1002, "Control frame payload too large")
                        return None
                    close_payload = payload
                    if len(close_payload) >= 2:
                        self._close_code = struct.unpack('!H', close_payload[:2])[0]
                        self._close_reason = close_payload[2:].decode('utf-8', errors='ignore')
                    try:
                        await self.send(WebSocketOpCode.CLOSE.value, payload)
                    except Exception:
                        logger.debug("Non-critical operation failed", exc_info=True)
                    self._closed = True
                    return None
                
                elif opcode == WebSocketOpCode.PING.value:
                    if not fin:
                        await self.close(1002, "Control frame must not be fragmented")
                        return None
                    if payload_len > 125:
                        await self.close(1002, "Control frame payload too large")
                        return None
                    await self.send(WebSocketOpCode.PONG.value, payload)
                    continue
                
                elif opcode == WebSocketOpCode.PONG.value:
                    if not fin:
                        await self.close(1002, "Control frame must not be fragmented")
                        return None
                    continue
                
                if opcode == 0x0:
                    if fragment_opcode is None:
                        await self.close(1002, "Unexpected continuation frame")
                        return None
                    fragment_buffer.extend(payload)
                    if len(fragment_buffer) > self._max_payload_size:
                        logger.error(f"Fragmented message too large: {len(fragment_buffer)}")
                        await self.close(1009, "Message too large")
                        return None
                    if fin:
                        result_opcode = fragment_opcode
                        result_payload = bytes(fragment_buffer)
                        fragment_buffer.clear()
                        fragment_opcode = None
                        return (result_opcode, result_payload)
                elif opcode in (0x1, 0x2):
                    if fin:
                        return (opcode, payload)
                    else:
                        fragment_opcode = opcode
                        fragment_buffer.extend(payload)
            
            except asyncio.IncompleteReadError:
                self._closed = True
                return None
            except Exception as e:
                logger.error(f"Error receiving WebSocket frame: {e}")
                try:
                    await self.close(1011, "Internal error")
                except Exception:
                    logger.debug("Non-critical operation failed", exc_info=True)
                self._closed = True
                return None
    
    async def accept(self, subprotocol: str = None):
        """接受WebSocket握手，发送握手响应"""
        if self._handshake_complete:
            return

        accept_key = self._compute_accept_key(self._client_key)
        response = f"HTTP/1.1 101 Switching Protocols\r\n"
        response += f"Upgrade: websocket\r\n"
        response += f"Connection: Upgrade\r\n"
        response += f"Sec-WebSocket-Accept: {accept_key}\r\n"
        if subprotocol:
            response += f"Sec-WebSocket-Protocol: {subprotocol}\r\n"
        if self._compression_context:
            response += f"Sec-WebSocket-Extensions: permessage-deflate\r\n"
        response += "\r\n"

        self._writer.write(response.encode('utf-8'))
        await self._writer.drain()
        self._handshake_complete = True
        self._subprotocol = subprotocol

    async def send(self, opcode: int, data: bytes):
        """
        发送WebSocket帧
        
        Args:
            opcode: 操作码
            data: 数据
        """
        if self._closed:
            return
        
        # 压缩数据（如果是文本或二进制帧）
        compressed = False
        if self._compression_context and opcode in [1, 2]:
            try:
                if self._compressor is None:
                    self._compressor = zlib.compressobj(
                        zlib.Z_DEFAULT_COMPRESSION,
                        zlib.DEFLATED,
                        -zlib.MAX_WBITS
                    )
                data = self._compressor.compress(data)
                data += self._compressor.flush(zlib.Z_SYNC_FLUSH)
                compressed = True
            except Exception as e:
                logger.error(f"Compression error: {e}")

        header = bytearray()

        first_byte = 0x80
        if compressed:
            first_byte |= 0x40
        header.append(first_byte | opcode)
        
        # Mask + Payload length
        payload_len = len(data)
        if payload_len < 126:
            header.append(payload_len)
        elif payload_len < 65536:
            header.append(126)
            header.extend(struct.pack('!H', payload_len))
        else:
            header.append(127)
            header.extend(struct.pack('!Q', payload_len))
        
        # 发送帧
        self._writer.write(bytes(header) + data)
        await self._writer.drain()
    
    async def send_text(self, text: str):
        """发送文本消息"""
        await self.send(WebSocketOpCode.TEXT.value, text.encode('utf-8'))
    
    async def send_binary(self, data: bytes):
        """发送二进制消息"""
        await self.send(WebSocketOpCode.BINARY.value, data)
    
    async def close(self, code: int = 1000, reason: str = ""):
        """关闭连接"""
        if self._closed:
            return
        
        # 发送关闭帧
        payload = struct.pack('!H', code) + reason.encode('utf-8')
        await self.send(WebSocketOpCode.CLOSE.value, payload)
        
        self._closed = True
        self._close_code = code
        self._close_reason = reason
        
        if self._writer is not None:
            self._writer.close()
            await self._writer.wait_closed()
    
    @property
    def subprotocol(self) -> Optional[str]:
        """协商的子协议"""
        return self._subprotocol
    
    @property
    def closed(self) -> bool:
        """连接是否已关闭"""
        return self._closed
    
    @property
    def close_code(self) -> Optional[int]:
        """关闭码"""
        return self._close_code
    
    @property
    def close_reason(self) -> Optional[str]:
        """关闭原因"""
        return self._close_reason
