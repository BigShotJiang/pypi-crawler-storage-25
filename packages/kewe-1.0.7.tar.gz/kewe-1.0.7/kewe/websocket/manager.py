#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
kewe.websocket.manager - WebSocket connection manager with broadcasting
"""

import asyncio
import logging
import threading
from typing import Any, Dict, Set, Optional, List

from .connection import WebSocketConnection
from kewe.utils.compat import json as _json

logger = logging.getLogger(__name__)


class WebSocketManager:
    def __init__(self):
        self._connections: Dict[str, WebSocketConnection] = {}
        self._groups: Dict[str, Set[str]] = {}
        self._lock: asyncio.Lock = asyncio.Lock()
        self._sync_lock = threading.Lock()

    def _get_lock(self) -> asyncio.Lock:
        return self._lock

    async def add(self, connection: WebSocketConnection) -> str:
        async with self._get_lock():
            self._connections[connection.id] = connection
            logger.debug(f"WebSocket connection added: {connection.id}")
            return connection.id

    async def remove(self, connection_id: str):
        async with self._get_lock():
            if connection_id in self._connections:
                del self._connections[connection_id]
                logger.debug(f"WebSocket connection removed: {connection_id}")

                for group in self._groups.values():
                    group.discard(connection_id)

    async def get(self, connection_id: str) -> Optional[WebSocketConnection]:
        async with self._get_lock():
            return self._connections.get(connection_id)

    async def get_all(self) -> List[WebSocketConnection]:
        async with self._get_lock():
            return list(self._connections.values())

    async def join_group(self, connection_id: str, group_name: str):
        async with self._get_lock():
            if group_name not in self._groups:
                self._groups[group_name] = set()
            self._groups[group_name].add(connection_id)
            logger.debug(f"Connection {connection_id} joined group: {group_name}")

    async def leave_group(self, connection_id: str, group_name: str):
        async with self._get_lock():
            if group_name in self._groups:
                self._groups[group_name].discard(connection_id)
                logger.debug(f"Connection {connection_id} left group: {group_name}")

    def get_group(self, group_name: str) -> List[WebSocketConnection]:
        with self._sync_lock:
            if group_name not in self._groups:
                return []
            return [
                self._connections[cid]
                for cid in self._groups[group_name]
                if cid in self._connections
            ]

    async def broadcast(self, message: str, exclude: Optional[Set[str]] = None):
        async with self._get_lock():
            targets = [
                conn for cid, conn in self._connections.items()
                if exclude is None or cid not in exclude
            ]

        async def _send(conn):
            try:
                await conn.send(message)
            except Exception as e:
                logger.error(f"Broadcast error to {conn.id}: {e}")

        if targets:
            await asyncio.gather(*[_send(c) for c in targets], return_exceptions=True)

    async def broadcast_binary(self, data: bytes, exclude: Optional[Set[str]] = None):
        async with self._get_lock():
            targets = [
                conn for cid, conn in self._connections.items()
                if exclude is None or cid not in exclude
            ]

        async def _send(conn):
            try:
                await conn.send_binary(data)
            except Exception as e:
                logger.error(f"Binary broadcast error to {conn.id}: {e}")

        if targets:
            await asyncio.gather(*[_send(c) for c in targets], return_exceptions=True)

    async def broadcast_json(self, data: Any, exclude: Optional[Set[str]] = None):
        message = _json.dumps(data, ensure_ascii=False)
        await self.broadcast(message, exclude=exclude)

    async def broadcast_to_group(
        self,
        group_name: str,
        message: str,
        exclude: Optional[Set[str]] = None,
    ):
        async with self._get_lock():
            if group_name not in self._groups:
                return
            stale = [
                cid for cid in self._groups[group_name]
                if cid not in self._connections
            ]
            for cid in stale:
                self._groups[group_name].discard(cid)
            targets = [
                self._connections[cid]
                for cid in self._groups[group_name]
                if cid in self._connections and (exclude is None or cid not in exclude)
            ]

        async def _send(conn):
            try:
                await conn.send(message)
            except Exception as e:
                logger.error(f"Group broadcast error to {conn.id}: {e}")

        if targets:
            await asyncio.gather(*[_send(c) for c in targets], return_exceptions=True)

    async def broadcast_binary_to_group(
        self,
        group_name: str,
        data: bytes,
        exclude: Optional[Set[str]] = None,
    ):
        async with self._get_lock():
            if group_name not in self._groups:
                return
            stale = [
                cid for cid in self._groups[group_name]
                if cid not in self._connections
            ]
            for cid in stale:
                self._groups[group_name].discard(cid)
            targets = [
                self._connections[cid]
                for cid in self._groups[group_name]
                if cid in self._connections and (exclude is None or cid not in exclude)
            ]

        async def _send(conn):
            try:
                await conn.send_binary(data)
            except Exception as e:
                logger.error(f"Group binary broadcast error to {conn.id}: {e}")

        if targets:
            await asyncio.gather(*[_send(c) for c in targets], return_exceptions=True)

    async def broadcast_json_to_group(
        self,
        group_name: str,
        data: Any,
        exclude: Optional[Set[str]] = None,
    ):
        message = _json.dumps(data, ensure_ascii=False)
        await self.broadcast_to_group(group_name, message, exclude=exclude)

    @property
    def connection_count(self) -> int:
        return len(self._connections)

    @property
    def group_count(self) -> int:
        return len(self._groups)

    def get_stats(self) -> Dict[str, Any]:
        return {
            "total_connections": len(self._connections),
            "total_groups": len(self._groups),
            "groups": {
                name: len(members) for name, members in self._groups.items()
            },
        }

    async def close_all(self, code: int = 1000, reason: str = "Server shutdown"):
        async with self._get_lock():
            connections = list(self._connections.values())
            self._connections.clear()
            self._groups.clear()

        tasks = [conn.close(code, reason) for conn in connections]
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)

        logger.info("All WebSocket connections closed")


_global_ws_manager: Optional[WebSocketManager] = None
_manager_lock = threading.Lock()


def get_websocket_manager() -> WebSocketManager:
    global _global_ws_manager
    if _global_ws_manager is None:
        with _manager_lock:
            if _global_ws_manager is None:
                _global_ws_manager = WebSocketManager()
    return _global_ws_manager


def set_websocket_manager(manager: WebSocketManager) -> None:
    global _global_ws_manager
    with _manager_lock:
        _global_ws_manager = manager


websocket_manager = get_websocket_manager()


def find_websocket_handler(app: Any, path: str) -> tuple:
    if hasattr(app, "router"):
        ws_routes = getattr(app.router, "_websocket_routes", {})
        for route_info in ws_routes.values():
            regex_pattern = route_info.get("regex_pattern")
            if regex_pattern:
                match = regex_pattern.match(path)
                if match:
                    handler = route_info.get("handler")
                    if handler:
                        raw_params = match.groupdict()
                        path_params = {}
                        param_converters = route_info.get("params", {})
                        for param_name, raw_value in raw_params.items():
                            converter_name = param_converters.get(param_name, "str")
                            try:
                                from kewe.routing.converter import convert_parameter

                                path_params[param_name] = convert_parameter(
                                    raw_value,
                                    converter_name,
                                    param_name,
                                )
                            except Exception:
                                path_params[param_name] = raw_value
                        return handler, path_params

        route = app.router.find_route(path, "GET")
        if route:
            handler = route.get("handler")
            if handler and (
                hasattr(handler, "_is_websocket")
                or hasattr(handler, "_websocket_handler")
            ):
                return handler, route.get("params", {})

    if hasattr(app, "websocket_routes"):
        for route in app.websocket_routes:
            if route.get("path") == path:
                return route.get("handler"), {}

    return None, {}
