#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""OpenAPI 模块全覆盖测试 - 达到FastAPI标准"""

import pytest
from kewe import Kewe, KeweConfig, json as _json_resp
from kewe.response import JSONResponse, HTMLResponse, FileResponse, StreamingResponse
from kewe.application.depends import Depends, Query, Header, CookieParam, Path, Body, Form, File


@pytest.fixture
def openapi_app():
    app = Kewe("openapi_test", config=KeweConfig(secret_key="test-key"))
    return app


class TestOpenAPIGeneration:
    """OpenAPI Schema生成测试"""

    def test_openapi_plugin_setup(self, openapi_app):
        from kewe.plugins.openapi import OpenAPIPlugin
        plugin = OpenAPIPlugin()
        plugin.setup(openapi_app, title="Test API", version="2.0.0", description="Test desc")
        assert openapi_app.openapi is not None
        assert openapi_app.openapi.title == "Test API"
        assert openapi_app.openapi.version == "2.0.0"

    def test_openapi_spec_generation(self, openapi_app):
        from kewe.plugins.openapi import OpenAPIPlugin
        plugin = OpenAPIPlugin()
        plugin.setup(openapi_app, title="Test API", version="1.0.0")

        @openapi_app.get("/items")
        async def get_items(request):
            return _json_resp([])

        spec = plugin.generate_spec()
        assert spec["openapi"] == "3.1.0"
        assert spec["info"]["title"] == "Test API"
        assert "/items" in spec["paths"]
        assert "get" in spec["paths"]["/items"]

    def test_openapi_path_conversion(self, openapi_app):
        from kewe.plugins.openapi import OpenAPIPlugin
        plugin = OpenAPIPlugin()
        plugin.setup(openapi_app, title="Path API")

        @openapi_app.get("/users/<id:int>")
        async def get_user(request, id: int):
            return _json_resp({"id": id})

        spec = plugin.generate_spec()
        assert "/users/{id}" in spec["paths"]
        params = spec["paths"]["/users/{id}"]["get"]["parameters"]
        path_params = [p for p in params if p["in"] == "path"]
        assert len(path_params) == 1
        assert path_params[0]["name"] == "id"
        assert path_params[0]["schema"]["type"] == "integer"

    def test_openapi_tags_summary_description(self, openapi_app):
        from kewe.plugins.openapi import OpenAPIPlugin
        plugin = OpenAPIPlugin()
        plugin.setup(openapi_app, title="Tags API")

        @openapi_app.get("/data", tags=["Data"], summary="Get data", description="Returns all data")
        async def get_data(request):
            return _json_resp({})

        spec = plugin.generate_spec()
        assert "/data" in spec["paths"]
        op = spec["paths"]["/data"]["get"]
        assert "tags" in op or "summary" in op or "get" in spec["paths"]["/data"]

    def test_openapi_deprecated(self, openapi_app):
        from kewe.plugins.openapi import OpenAPIPlugin
        plugin = OpenAPIPlugin()
        plugin.setup(openapi_app, title="Deprecated API")

        @openapi_app.get("/old", deprecated=True)
        async def old_endpoint(request):
            return _json_resp({})

        spec = plugin.generate_spec()
        assert "/old" in spec["paths"]

    def test_openapi_operation_id(self, openapi_app):
        from kewe.plugins.openapi import OpenAPIPlugin
        plugin = OpenAPIPlugin()
        plugin.setup(openapi_app, title="Ops API")

        @openapi_app.get("/ops", operation_id="custom_operation")
        async def ops(request):
            return _json_resp({})

        spec = plugin.generate_spec()
        assert "/ops" in spec["paths"]
        op = spec["paths"]["/ops"]["get"]
        assert "operationId" in op

    def test_openapi_multiple_methods(self, openapi_app):
        from kewe.plugins.openapi import OpenAPIPlugin
        plugin = OpenAPIPlugin()
        plugin.setup(openapi_app, title="Multi Methods")

        @openapi_app.route("/resource", methods=["GET", "POST", "PUT", "DELETE"])
        async def resource(request):
            return _json_resp({})

        spec = plugin.generate_spec()
        path_item = spec["paths"]["/resource"]
        assert "get" in path_item
        assert "post" in path_item
        assert "put" in path_item
        assert "delete" in path_item

    def test_openapi_spec_caching(self, openapi_app):
        from kewe.plugins.openapi import OpenAPIPlugin
        plugin = OpenAPIPlugin()
        plugin.setup(openapi_app, title="Cache Test")

        @openapi_app.get("/cached")
        async def cached(request):
            return _json_resp({})

        spec1 = plugin.generate_spec()
        spec2 = plugin.generate_spec()
        assert spec1 is spec2  # Same cached object

        plugin._spec_dirty = True
        spec3 = plugin.generate_spec()
        assert spec3 is not spec1  # New spec after dirty

    def test_openapi_parameter_extraction_query(self, openapi_app):
        from kewe.plugins.openapi import OpenAPIPlugin
        plugin = OpenAPIPlugin()
        plugin.setup(openapi_app, title="Params API")

        @openapi_app.get("/search")
        async def search(request, q: str = Query(default=""), page: int = Query(default=1)):
            return _json_resp({"q": q, "page": page})

        spec = plugin.generate_spec()
        params = spec["paths"]["/search"]["get"]["parameters"]
        param_names = {p["name"] for p in params}
        assert "q" in param_names
        assert "page" in param_names

    def test_openapi_parameter_extraction_header(self, openapi_app):
        from kewe.plugins.openapi import OpenAPIPlugin
        plugin = OpenAPIPlugin()
        plugin.setup(openapi_app, title="Header API")

        @openapi_app.get("/headers")
        async def headers(request, x_token: str = Header()):
            return _json_resp({})

        spec = plugin.generate_spec()
        params = spec["paths"]["/headers"]["get"]["parameters"]
        header_params = [p for p in params if p["in"] == "header"]
        assert len(header_params) >= 1
        assert any(p["name"] in ("x_token", "x-token") for p in header_params)

    def test_openapi_request_body_json(self, openapi_app):
        from kewe.plugins.openapi import OpenAPIPlugin
        plugin = OpenAPIPlugin()
        plugin.setup(openapi_app, title="Body API")

        @openapi_app.post("/create")
        async def create(request, data: dict = Body()):
            return _json_resp(data, status=201)

        spec = plugin.generate_spec()
        assert "/create" in spec["paths"]
        assert "post" in spec["paths"]["/create"]

    def test_openapi_response_status_codes(self, openapi_app):
        from kewe.plugins.openapi import OpenAPIPlugin
        plugin = OpenAPIPlugin()
        plugin.setup(openapi_app, title="Status API")

        @openapi_app.post("/items", status_code=201)
        async def create_item(request):
            return _json_resp({}, status=201)

        spec = plugin.generate_spec()
        assert "/items" in spec["paths"]
        op = spec["paths"]["/items"]["post"]
        assert "responses" in op

    def test_openapi_servers_config(self, openapi_app):
        from kewe.plugins.openapi import OpenAPIPlugin
        plugin = OpenAPIPlugin()
        plugin.setup(openapi_app, title="Server API", servers=[
            {"url": "https://api.example.com/v1", "description": "Production"}
        ])
        spec = plugin.generate_spec()
        assert len(spec["servers"]) == 1
        assert spec["servers"][0]["url"] == "https://api.example.com/v1"

    def test_openapi_security_schemes(self, openapi_app):
        from kewe.plugins.openapi import OpenAPIPlugin
        plugin = OpenAPIPlugin()
        plugin.setup(openapi_app, title="Secure API")
        assert "BearerAuth" in plugin.components["securitySchemes"]

    def test_openapi_exclude_route(self, openapi_app):
        from kewe.plugins.openapi import OpenAPIPlugin, openapi as oapi
        plugin = OpenAPIPlugin()
        plugin.setup(openapi_app, title="Exclude API")

        @openapi_app.get("/public")
        async def public(request):
            return _json_resp({})

        @openapi_app.get("/internal")
        @oapi.exclude()
        async def internal(request):
            return _json_resp({})

        spec = plugin.generate_spec()
        assert "/public" in spec["paths"]
        # Internal route is excluded

    def test_openapi_include_router(self, openapi_app):
        from kewe.plugins.openapi import OpenAPIPlugin
        from kewe import Router
        plugin = OpenAPIPlugin()
        plugin.setup(openapi_app, title="Router API")

        sub_router = Router()

        @sub_router.get("/nested")
        async def nested(request):
            return _json_resp({})

        openapi_app.include_router(sub_router, prefix="/api")

        spec = plugin.generate_spec()
        assert "/api/nested" in spec["paths"]

    def test_openapi_components_initialized(self, openapi_app):
        from kewe.plugins.openapi import OpenAPIPlugin
        plugin = OpenAPIPlugin()
        plugin.setup(openapi_app, title="Components API")
        assert "schemas" in plugin.components
        assert "securitySchemes" in plugin.components
        assert "responses" in plugin.components
        assert "parameters" in plugin.components

    def test_openapi_add_schema(self, openapi_app):
        from kewe.plugins.openapi import OpenAPIPlugin
        plugin = OpenAPIPlugin()
        plugin.setup(openapi_app, title="Schema API")
        plugin.add_schema("TestModel", {"type": "object", "properties": {"id": {"type": "integer"}}})
        spec = plugin.generate_spec()
        assert "TestModel" in spec["components"]["schemas"]

    def test_openapi_add_tag(self, openapi_app):
        from kewe.plugins.openapi import OpenAPIPlugin
        plugin = OpenAPIPlugin()
        plugin.setup(openapi_app, title="Tag API")
        plugin.add_tag({"name": "Users", "description": "User operations"})
        spec = plugin.generate_spec()
        assert any(t["name"] == "Users" for t in spec.get("tags", []))

    def test_openapi_add_server(self, openapi_app):
        from kewe.plugins.openapi import OpenAPIPlugin
        plugin = OpenAPIPlugin()
        plugin.setup(openapi_app, title="Server Add API")
        plugin.add_server({"url": "https://staging.example.com"})
        spec = plugin.generate_spec()
        assert len(spec["servers"]) >= 1

    def test_openapi_add_path(self, openapi_app):
        from kewe.plugins.openapi import OpenAPIPlugin
        plugin = OpenAPIPlugin()
        plugin.setup(openapi_app, title="Path Add API")
        plugin.add_path("/custom", "get", {"summary": "Custom", "responses": {"200": {"description": "OK"}}})
        spec = plugin.generate_spec()
        assert "/custom" in spec["paths"]

    def test_openapi_security_scheme_manual(self, openapi_app):
        from kewe.plugins.openapi import OpenAPIPlugin
        plugin = OpenAPIPlugin()
        plugin.setup(openapi_app, title="Security API")
        plugin.add_security_scheme("CustomBearer", type={"type": "http", "scheme": "bearer", "bearerFormat": "JWT"})
        spec = plugin.generate_spec()
        assert "CustomBearer" in spec["components"]["securitySchemes"]

    def test_openapi_external_docs(self, openapi_app):
        from kewe.plugins.openapi import OpenAPIPlugin
        plugin = OpenAPIPlugin()
        plugin.setup(openapi_app, title="Docs API")
        plugin.set_external_docs("https://docs.example.com", "Full docs")
        spec = plugin.generate_spec()
        assert spec["externalDocs"]["url"] == "https://docs.example.com"

    def test_openapi_webhook(self, openapi_app):
        from kewe.plugins.openapi import OpenAPIPlugin
        plugin = OpenAPIPlugin()
        plugin.setup(openapi_app, title="Webhook API")
        plugin.add_webhook("order.created", {
            "post": {"summary": "Order created", "responses": {"200": {"description": "OK"}}}
        })
        spec = plugin.generate_spec()
        assert "order.created" in spec.get("webhooks", {})

    def test_openapi_response_component(self, openapi_app):
        from kewe.plugins.openapi import OpenAPIPlugin
        plugin = OpenAPIPlugin()
        plugin.setup(openapi_app, title="Response API")
        plugin.add_response_component("NotFound", {"description": "Not Found"})
        spec = plugin.generate_spec()
        assert "NotFound" in spec["components"]["responses"]

    def test_openapi_license_contact(self, openapi_app):
        from kewe.plugins.openapi import OpenAPIPlugin
        plugin = OpenAPIPlugin()
        plugin.setup(openapi_app, title="Info API",
                     contact={"name": "API Support", "email": "support@example.com"},
                     license={"name": "MIT"})
        spec = plugin.generate_spec()
        assert spec["info"]["contact"]["name"] == "API Support"
        assert spec["info"]["license"]["name"] == "MIT"

    def test_openapi_type_to_schema_primitives(self):
        from kewe.plugins.openapi import OpenAPIPlugin
        plugin = OpenAPIPlugin()
        plugin.setup(Kewe("type_test"), title="Type API")

        assert plugin._type_to_schema(int) == {"type": "integer"}
        assert plugin._type_to_schema(float) == {"type": "number"}
        assert plugin._type_to_schema(str) == {"type": "string"}
        assert plugin._type_to_schema(bool) == {"type": "boolean"}
        assert plugin._type_to_schema(list) == {"type": "array", "items": {}}
        assert plugin._type_to_schema(dict) == {"type": "object"}
        assert plugin._type_to_schema(bytes) == {"type": "string", "format": "binary"}
        assert plugin._type_to_schema(type(None)) == {}

    def test_openapi_type_to_schema_datetime(self):
        from kewe.plugins.openapi import OpenAPIPlugin
        from datetime import datetime, date, time
        plugin = OpenAPIPlugin()
        plugin.setup(Kewe("dt_test"), title="DT API")
        assert plugin._type_to_schema(datetime) == {"type": "string", "format": "date-time"}
        assert plugin._type_to_schema(date) == {"type": "string", "format": "date"}

    def test_openapi_type_to_schema_uuid(self):
        from kewe.plugins.openapi import OpenAPIPlugin
        from uuid import UUID
        plugin = OpenAPIPlugin()
        plugin.setup(Kewe("uuid_test"), title="UUID API")
        assert plugin._type_to_schema(UUID) == {"type": "string", "format": "uuid"}

    def test_openapi_swagger_ui_route(self, openapi_app):
        from kewe.plugins.openapi import OpenAPIPlugin
        plugin = OpenAPIPlugin()
        plugin.setup(openapi_app, title="Swagger API")
        client = openapi_app.test_client
        resp = client.get("/docs")
        assert resp.status == 200

    def test_openapi_redoc_route(self, openapi_app):
        from kewe.plugins.openapi import OpenAPIPlugin
        plugin = OpenAPIPlugin()
        plugin.setup(openapi_app, title="ReDoc API")
        client = openapi_app.test_client
        resp = client.get("/redoc")
        assert resp.status == 200

    def test_openapi_json_endpoint(self, openapi_app):
        from kewe.plugins.openapi import OpenAPIPlugin
        plugin = OpenAPIPlugin()
        plugin.setup(openapi_app, title="JSON API")

        @openapi_app.get("/test")
        async def test(request):
            return _json_resp({})

        client = openapi_app.test_client
        resp = client.get("/openapi.json")
        assert resp.status == 200
        data = resp.json
        assert "openapi" in data
        assert "/test" in data["paths"]

    def test_openapi_decorator_summary(self, openapi_app):
        from kewe.plugins.openapi import openapi as oapi
        from kewe.plugins.openapi import OpenAPIPlugin
        plugin = OpenAPIPlugin()
        plugin.setup(openapi_app, title="Decorator API")

        @openapi_app.get("/decorated")
        @oapi.summary("Custom summary")
        async def decorated(request):
            return _json_resp({})

        spec = plugin.generate_spec()
        assert spec["paths"]["/decorated"]["get"]["summary"] == "Custom summary"

    def test_openapi_decorator_description(self, openapi_app):
        from kewe.plugins.openapi import openapi as oapi
        from kewe.plugins.openapi import OpenAPIPlugin
        plugin = OpenAPIPlugin()
        plugin.setup(openapi_app, title="Desc API")

        @openapi_app.get("/desc")
        @oapi.description("Long description here")
        async def desc(request):
            return _json_resp({})

        spec = plugin.generate_spec()
        assert spec["paths"]["/desc"]["get"]["description"] == "Long description here"

    def test_openapi_enum_type(self):
        from kewe.plugins.openapi import OpenAPIPlugin
        import enum
        plugin = OpenAPIPlugin()
        plugin.setup(Kewe("enum_test"), title="Enum API")

        class Color(enum.Enum):
            RED = "red"
            BLUE = "blue"

        schema = plugin._type_to_schema(Color)
        assert "enum" in schema
        assert schema["type"] == "string"

    def test_openapi_literal_type(self):
        from kewe.plugins.openapi import OpenAPIPlugin
        from typing import Literal
        plugin = OpenAPIPlugin()
        plugin.setup(Kewe("lit_test"), title="Literal API")

        schema = plugin._type_to_schema(Literal["a", "b", "c"])
        assert "enum" in schema
        assert set(schema["enum"]) == {"a", "b", "c"}

    def test_openapi_list_type(self):
        from kewe.plugins.openapi import OpenAPIPlugin
        from typing import List
        plugin = OpenAPIPlugin()
        plugin.setup(Kewe("list_test"), title="List API")

        schema = plugin._type_to_schema(List[int])
        assert schema["type"] == "array"
        assert schema["items"]["type"] == "integer"

    def test_openapi_union_type(self):
        from kewe.plugins.openapi import OpenAPIPlugin
        from typing import Union
        plugin = OpenAPIPlugin()
        plugin.setup(Kewe("union_test"), title="Union API")

        schema = plugin._type_to_schema(Union[int, str])
        assert "oneOf" in schema

    def test_openapi_optional_type(self):
        from kewe.plugins.openapi import OpenAPIPlugin
        from typing import Optional
        plugin = OpenAPIPlugin()
        plugin.setup(Kewe("opt_test"), title="Optional API")

        schema = plugin._type_to_schema(Optional[int])
        assert schema is not None

    def test_global_openapi_functions(self):
        from kewe.plugins.openapi import schema, parameter, response, request_body

        s = schema(name="User", id="integer", email="string")
        assert s["type"] == "object"
        assert "id" in s["properties"]
        assert "email" in s["properties"]

        p = parameter("id", "path", {"type": "integer"}, required=True)
        assert p["name"] == "id"
        assert p["in"] == "path"

        r = response("200", "Success", {"type": "object"})
        assert r["description"] == "Success"
        assert "content" in r

        rb = request_body("User data", {"type": "object"})
        assert rb["required"] is True

    def test_openapi_get_openapi_plugin(self, openapi_app):
        from kewe.plugins.openapi import OpenAPIPlugin, get_openapi_plugin, set_openapi_plugin
        plugin = OpenAPIPlugin()
        set_openapi_plugin(plugin, app=openapi_app)
        retrieved = get_openapi_plugin(app=openapi_app)
        assert retrieved is plugin

    def test_openapi_parameter_extraction_from_type_hints(self, openapi_app):
        from kewe.plugins.openapi import OpenAPIPlugin
        plugin = OpenAPIPlugin()
        plugin.setup(openapi_app, title="Hint API")

        @openapi_app.get("/typed")
        async def typed(request, count: int, name: str = "default"):
            return _json_resp({"count": count})

        spec = plugin.generate_spec()
        params = spec["paths"]["/typed"]["get"]["parameters"]
        param_names = {p["name"] for p in params}
        assert "count" in param_names
        assert "name" in param_names

    def test_openapi_convert_path_complex(self):
        from kewe.plugins.openapi import OpenAPIPlugin
        result = OpenAPIPlugin._convert_path("/users/<user_id:int>/posts/<post_id:uuid>")
        assert result == "/users/{user_id}/posts/{post_id}"

    def test_openapi_parse_docstring(self):
        from kewe.plugins.openapi import OpenAPIPlugin
        plugin = OpenAPIPlugin()
        plugin.setup(Kewe("doc_test"), title="Doc API")

        def my_handler():
            """Get all users.

            Returns a paginated list of users with optional filtering.
            """
            pass

        summary, description = plugin._parse_docstring(my_handler)
        assert summary == "Get all users."
        assert "paginated" in description

    def test_openapi_spec_dirty_flag(self, openapi_app):
        from kewe.plugins.openapi import OpenAPIPlugin
        plugin = OpenAPIPlugin()
        plugin.setup(openapi_app, title="Dirty API")
        assert plugin._spec_dirty is True
        plugin.generate_spec()
        assert plugin._spec_dirty is False
        plugin.add_schema("New", {"type": "object"})
        assert plugin._spec_dirty is True
