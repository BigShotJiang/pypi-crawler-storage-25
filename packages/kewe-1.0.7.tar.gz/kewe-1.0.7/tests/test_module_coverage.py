import asyncio
import json
import os
import time
import tempfile
import threading
import pytest
from kewe.app import Kewe, KeweConfig
from kewe.response import json as json_resp, text as text_resp, Response
from kewe.errors.exceptions import NotFound, Unauthorized, BadRequest, KeweException
from kewe.security.rbac_manager import RBACManager
from kewe.cookies.session import Session
from kewe.cache import memoize, cache, MemoryCache
from kewe.cache.lru_cache import LRUCache
from kewe.application.di import Container, Lifetime, Scope
from kewe.application.depends import Field, FieldType, Validator, FieldValidationError, field
from kewe.request.form import parse_form_data
from kewe.monitoring.core import MetricsCollector, PerformanceMonitor
from kewe.errors.tracker import ErrorTracker, ErrorSeverity
from kewe.server.lifecycle import ServerLifecycle, ServerState
from kewe.background.tasks import TaskManager, TaskConfig


def _create_app():
    config = KeweConfig(secret_key="test-secret-key", enable_gateway=False)
    app = Kewe("module_test", config=config)
    return app


# ==================== 二进制文件测====================

class TestBinaryFileHandling:
    def test_file_stream_response(self):
        with tempfile.NamedTemporaryFile(delete=False, suffix=".bin") as f:
            f.write(b"\x00\x01\x02\x03" * 100)
            temp_path = f.name
        try:
            from kewe.response.streaming import FileStreamResponse
            resp = FileStreamResponse(temp_path, chunk_size=256)
            assert resp.status == 200
            assert resp.content_type is not None
        finally:
            os.unlink(temp_path)

    def test_file_stream_with_filename(self):
        with tempfile.NamedTemporaryFile(delete=False, suffix=".txt") as f:
            f.write(b"hello file world")
            temp_path = f.name
        try:
            from kewe.response.streaming import FileStreamResponse
            resp = FileStreamResponse(temp_path, filename="download.txt")
            assert resp.status == 200
        finally:
            os.unlink(temp_path)

    def test_binary_response_body(self):
        binary_data = bytes(range(256))
        resp = Response(body=binary_data, content_type="application/octet-stream")
        assert resp.body == binary_data
        assert resp.content_type == "application/octet-stream"

    def test_form_data_parsing(self):
        result = parse_form_data(b"name=Alice&age=30&hobby=code&hobby=read")
        assert result["name"] == ["Alice"]
        assert result["age"] == ["30"]
        assert result["hobby"] == ["code", "read"]

    def test_form_data_empty(self):
        assert parse_form_data(b"") == {}

    def test_form_data_bad_encoding(self):
        result = parse_form_data(b"\xff\xfe")
        assert isinstance(result, dict)


# ==================== Pydantic 验证测试 ====================

class TestValidation:
    def test_basic_validator(self):
        v = Validator([
            Field("name", FieldType.STRING, required=True, min_length=3),
            Field("age", FieldType.INTEGER, required=False, default=18, min_value=0, max_value=150),
        ])
        result = v.validate({"name": "Alice", "age": 25})
        assert result["name"] == "Alice"
        assert result["age"] == 25

    def test_validator_default_values(self):
        v = Validator([
            Field("name", FieldType.STRING, required=True),
            Field("status", FieldType.STRING, required=False, default="active"),
        ])
        result = v.validate({"name": "Bob"})
        assert result["status"] == "active"

    def test_validator_required_field_missing(self):
        v = Validator([Field("email", FieldType.EMAIL, required=True)])
        with pytest.raises(FieldValidationError):
            v.validate({})

    def test_validator_min_length(self):
        v = Validator([Field("name", FieldType.STRING, required=True, min_length=3)])
        with pytest.raises(FieldValidationError):
            v.validate({"name": "AB"})

    def test_validator_max_length(self):
        v = Validator([Field("name", FieldType.STRING, required=True, max_length=5)])
        with pytest.raises(FieldValidationError):
            v.validate({"name": "TooLongName"})

    def test_validator_email_field(self):
        v = Validator([Field("email", FieldType.EMAIL, required=True)])
        result = v.validate({"email": "test@example.com"})
        assert result["email"] == "test@example.com"

    def test_validator_integer_range(self):
        v = Validator([Field("score", FieldType.INTEGER, min_value=0, max_value=100)])
        result = v.validate({"score": 85})
        assert result["score"] == 85
        with pytest.raises(FieldValidationError):
            v.validate({"score": 150})

    def test_field_convenience_function(self):
        f = field("username", "string", min_length=4, max_length=20)
        assert f.name == "username"
        assert f.type == FieldType.STRING
        assert f.min_length == 4

    def test_validator_choices(self):
        v = Validator([Field("role", FieldType.STRING, required=True, choices=["admin", "user", "guest"])])
        result = v.validate({"role": "admin"})
        assert result["role"] == "admin"
        with pytest.raises(FieldValidationError):
            v.validate({"role": "hacker"})


# ==================== 结构化日志测====================

class TestStructuredLogging:
    def test_app_with_json_log_config(self):
        config = KeweConfig(secret_key="test", enable_gateway=False, log_json=True)
        app = Kewe("json_log_test", config=config)
        assert app.config.log_json is True

    def test_app_with_custom_log_level(self):
        import logging
        config = KeweConfig(secret_key="test", enable_gateway=False, log_level=logging.DEBUG)
        app = Kewe("debug_log_test", config=config)
        assert app.config.log_level == logging.DEBUG


# ==================== 上下文测====================

class TestAppContext:
    def test_app_state_storage(self):
        app = _create_app()
        app.ctx.custom_key = "custom_value"
        assert app.ctx.custom_key == "custom_value"

    def test_request_context_in_handler(self):
        app = _create_app()
        captured = {}

        @app.get("/ctx")
        async def ctx_handler(request):
            captured["path"] = request.path
            captured["method"] = request.method
            captured["headers_type"] = type(request.headers).__name__
            return json_resp({"ok": True})

        client = app.test_client
        resp = client.get("/ctx")
        assert resp.status == 200
        assert captured["path"] == "/ctx"
        assert captured["method"] == "GET"

    def test_shared_context(self):
        app = _create_app()
        ctx = app.shared_ctx
        assert ctx is not None


# ==================== ASGI 适配器测====================

class TestASGIAdapter:
    def test_asgi_adapter_creation(self):
        from kewe.server.asgi import ASGIAdapter
        app = _create_app()
        adapter = ASGIAdapter(app)
        assert adapter is not None

    def test_asgi_http_scope(self):
        from kewe.server.asgi import ASGIAdapter
        app = _create_app()

        @app.get("/asgi_test")
        async def asgi_handler(request):
            return json_resp({"asgi": True})

        adapter = ASGIAdapter(app)
        scope = {
            "type": "http",
            "method": "GET",
            "path": "/asgi_test",
            "query_string": b"",
            "headers": [],
            "server": ("127.0.0.1", 8000),
        }
        received = []
        sent_messages = []

        async def receive():
            if not received:
                received.append(True)
                return {"type": "http.request", "body": b"", "more_body": False}
            return {"type": "http.disconnect"}

        async def send(message):
            sent_messages.append(message)

        asyncio.run(adapter(scope, receive, send))
        assert any(m.get("type") == "http.response.start" for m in sent_messages)
        assert any(m.get("type") == "http.response.body" for m in sent_messages)

    def test_asgi_lifespan_scope(self):
        from kewe.server.asgi import ASGIAdapter
        app = _create_app()
        adapter = ASGIAdapter(app)

        scope = {"type": "lifespan"}
        received_startup = []
        received_shutdown = []

        async def receive():
            if not received_startup:
                received_startup.append(True)
                return {"type": "lifespan.startup"}
            if not received_shutdown:
                received_shutdown.append(True)
                return {"type": "lifespan.shutdown"}
            return {"type": "lifespan.shutdown"}

        sent_messages = []

        async def send(message):
            sent_messages.append(message)

        asyncio.run(adapter(scope, receive, send))


# ==================== 生命周期测试 ====================

class TestServerLifecycle:
    def test_lifecycle_state_transitions(self):
        lifecycle = ServerLifecycle()

        async def _test():
            assert lifecycle.state == ServerState.NONE
            assert await lifecycle.start()
            assert lifecycle.is_starting
            assert await lifecycle.serve()
            assert lifecycle.is_running
            assert await lifecycle.stop()
            assert lifecycle.is_stopping
            assert await lifecycle.finish()
            assert lifecycle.is_stopped

        asyncio.run(_test())

    def test_lifecycle_invalid_transition(self):
        lifecycle = ServerLifecycle()

        async def _test():
            result = await lifecycle.transition_to(ServerState.STOPPED)
            assert result is False

        asyncio.run(_test())

    def test_lifecycle_handlers(self):
        lifecycle = ServerLifecycle()
        called = []

        lifecycle.on_state(ServerState.SERVING, lambda: called.append("serving"))

        async def _test():
            await lifecycle.start()
            await lifecycle.serve()
            assert "serving" in called

        asyncio.run(_test())

    def test_lifecycle_decorator_handlers(self):
        lifecycle = ServerLifecycle()
        called = []

        @lifecycle.on_serving
        def on_serve():
            called.append("decorated_serving")

        async def _test():
            await lifecycle.start()
            await lifecycle.serve()
            assert "decorated_serving" in called

        asyncio.run(_test())

    def test_lifecycle_uptime(self):
        lifecycle = ServerLifecycle()

        async def _test():
            assert lifecycle.uptime is None
            await lifecycle.start()
            await lifecycle.serve()
            uptime = lifecycle.uptime
            assert uptime is not None
            assert uptime >= 0

        asyncio.run(_test())

    def test_lifecycle_state_info(self):
        lifecycle = ServerLifecycle()

        async def _test():
            info = lifecycle.get_state_info()
            assert "state" in info

        asyncio.run(_test())

    def test_lifecycle_restart(self):
        lifecycle = ServerLifecycle()

        async def _test():
            await lifecycle.start()
            await lifecycle.serve()
            await lifecycle.stop()
            await lifecycle.finish()
            assert lifecycle.is_stopped
            result = await lifecycle.start()
            assert result is True

        asyncio.run(_test())


# ==================== 流式 HTTP 响应测试 ====================

class TestStreamingHTTPResponse:
    def test_streaming_response_creation(self):
        from kewe.response.streaming import StreamingHTTPResponse

        async def gen():
            yield b"chunk1"
            yield b"chunk2"

        resp = StreamingHTTPResponse(gen(), content_type="text/plain")
        assert resp.status == 200

    def test_sse_response(self):
        from kewe.response.streaming import ServerSentEventResponse

        event_data = ServerSentEventResponse.event(data="hello", event="message")
        assert b"data: hello" in event_data
        assert b"event: message" in event_data

    def test_sse_response_with_retry(self):
        from kewe.response.streaming import ServerSentEventResponse

        event_data = ServerSentEventResponse.event(data="test", retry=5000)
        assert b"retry: 5000" in event_data

    def test_stream_convenience_function(self):
        from kewe.response.streaming import stream

        async def gen():
            yield b"hello"

        resp = stream(gen(), content_type="text/plain")
        assert resp.status == 200


# ==================== 后台任务测试 ====================

class TestBackgroundTasks:
    def test_task_manager_creation(self):
        manager = TaskManager(config=TaskConfig())
        assert manager is not None

    def test_run_in_background(self):
        results = []

        async def _test():
            manager = TaskManager(config=TaskConfig())
            async def my_task():
                results.append("done")
                return 42

            task = await manager.run_in_background(my_task())
            await asyncio.sleep(0.1)
            assert "done" in results

        asyncio.run(_test())

    def test_background_task_decorator(self):
        from kewe.background.tasks import background_task

        @background_task
        async def decorated_task(x):
            return x * 2

        assert callable(decorated_task)


# ==================== 缓存 LRU 测试 ====================

class TestLRUCache:
    def test_basic_get_set(self):
        c = LRUCache(max_size=10, ttl=60)
        c.set("key1", "value1")
        assert c.get("key1") == "value1"

    def test_overwrite(self):
        c = LRUCache(max_size=10)
        c.set("key1", "v1")
        c.set("key1", "v2")
        assert c.get("key1") == "v2"

    def test_delete(self):
        c = LRUCache(max_size=10)
        c.set("key1", "v1")
        assert c.delete("key1") is True
        assert c.get("key1") is None
        assert c.delete("nonexistent") is False

    def test_has(self):
        c = LRUCache(max_size=10)
        c.set("key1", "v1")
        assert c.has("key1") is True
        assert c.has("key2") is False

    def test_size(self):
        c = LRUCache(max_size=10)
        assert c.size() == 0
        c.set("k1", "v1")
        assert c.size() == 1

    def test_keys(self):
        c = LRUCache(max_size=10)
        c.set("a", 1)
        c.set("b", 2)
        assert set(c.keys()) == {"a", "b"}

    def test_clear(self):
        c = LRUCache(max_size=10)
        c.set("k1", "v1")
        c.set("k2", "v2")
        c.clear()
        assert c.size() == 0

    def test_ttl_expiry(self):
        c = LRUCache(max_size=10)
        c.set("temp", "data", ttl=1)
        assert c.get("temp") == "data"
        time.sleep(1.1)
        assert c.get("temp") is None

    def test_lru_eviction(self):
        c = LRUCache(max_size=3)
        c.set("a", 1)
        c.set("b", 2)
        c.set("c", 3)
        c.set("d", 4)
        assert c.size() <= 3
        assert c.get("a") is None

    def test_cleanup_expired(self):
        c = LRUCache(max_size=10)
        c.set("short1", "v1", ttl=1)
        c.set("short2", "v2", ttl=1)
        c.set("long", "v3", ttl=60)
        time.sleep(1.1)
        cleaned = c.cleanup_expired()
        assert cleaned >= 2
        assert c.get("long") == "v3"

    def test_get_stats(self):
        c = LRUCache(max_size=10, ttl=60)
        c.set("k1", "v1")
        c.get("k1")
        c.get("nonexistent")
        stats = c.get_stats()
        assert "size" in stats
        assert "max_size" in stats
        assert "hit_rate" in stats

    def test_async_get_set(self):
        c = LRUCache(max_size=10)

        async def _test():
            await c.aset("akey", "aval")
            val = await c.aget("akey")
            assert val == "aval"

        asyncio.run(_test())

    def test_async_delete(self):
        c = LRUCache(max_size=10)

        async def _test():
            await c.aset("akey", "aval")
            result = await c.adelete("akey")
            assert result is True
            val = await c.aget("akey")
            assert val is None

        asyncio.run(_test())

    def test_concurrent_lru_access(self):
        c = LRUCache(max_size=100)
        errors = []

        def worker(tid):
            try:
                for i in range(50):
                    key = f"k_{tid}_{i}"
                    c.set(key, f"v_{tid}_{i}")
                    val = c.get(key)
                    if val != f"v_{tid}_{i}":
                        errors.append(f"Mismatch: {key}={val}")
            except Exception as e:
                errors.append(str(e))

        threads = [threading.Thread(target=worker, args=(tid,)) for tid in range(5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert len(errors) == 0, f"LRU concurrency errors: {errors}"


# ==================== 监控测试 ====================

class TestMonitoring:
    def test_metrics_collector(self):
        mc = MetricsCollector()
        mc.counter("requests_total", 1, labels={"method": "GET"})
        mc.gauge("active_connections", 5)
        mc.histogram("response_time_ms", 123.4, labels={"path": "/api"})

    def test_prometheus_export(self):
        mc = MetricsCollector()
        mc.counter("test_counter", 1, labels={"env": "test"})
        prom = mc.get_prometheus_metrics()
        assert isinstance(prom, str)
        assert "test_counter" in prom

    def test_performance_monitor(self):
        pm = PerformanceMonitor()
        pm.record_request_start("GET", "/api")
        pm.record_request_end("GET", "/api", 200, 0.045)
        stats = pm.get_stats()
        assert stats["total_requests"] == 1
        assert stats["active_requests"] == 0

    def test_performance_monitor_errors(self):
        pm = PerformanceMonitor()
        pm.record_request_start("POST", "/api")
        pm.record_request_end("POST", "/api", 500, 0.1)
        stats = pm.get_stats()
        assert stats["error_requests"] == 1
        assert stats["error_rate"] > 0

    def test_concurrent_performance_monitor(self):
        pm = PerformanceMonitor()
        errors = []

        def worker(tid):
            try:
                for i in range(100):
                    pm.record_request_start("GET", f"/api/{tid}")
                    pm.record_request_end("GET", f"/api/{tid}", 200, 0.01)
            except Exception as e:
                errors.append(str(e))

        threads = [threading.Thread(target=worker, args=(tid,)) for tid in range(5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert len(errors) == 0, f"PerformanceMonitor concurrency errors: {errors}"
        stats = pm.get_stats()
        assert stats["total_requests"] == 500


# ==================== 错误追踪测试 ====================

class TestErrorTracker:
    def test_track_error(self):
        tracker = ErrorTracker(max_records=100)

        async def _test():
            try:
                raise ValueError("test error")
            except Exception as e:
                record = await tracker.track(e, severity=ErrorSeverity.ERROR)
                assert record.exception_type == "ValueError"
                assert record.message == "test error"
                assert record.count == 1

        asyncio.run(_test())

    def test_error_deduplication(self):
        tracker = ErrorTracker(max_records=100, deduplicate=True)

        async def _test():
            for _ in range(3):
                try:
                    raise ValueError("duplicate error")
                except Exception as e:
                    await tracker.track(e)

            records = tracker.get_all()
            val_err_records = [r for r in records if r.exception_type == "ValueError"]
            assert len(val_err_records) == 1
            assert val_err_records[0].count == 3

        asyncio.run(_test())

    def test_error_severity_filter(self):
        tracker = ErrorTracker(max_records=100)

        async def _test():
            try:
                raise RuntimeError("critical")
            except Exception as e:
                await tracker.track(e, severity=ErrorSeverity.CRITICAL)

            try:
                raise ValueError("warning")
            except Exception as e:
                await tracker.track(e, severity=ErrorSeverity.WARNING)

            critical = tracker.get_by_severity(ErrorSeverity.CRITICAL)
            assert len(critical) >= 1

        asyncio.run(_test())

    def test_error_stats(self):
        tracker = ErrorTracker(max_records=100)

        async def _test():
            try:
                raise ValueError("test")
            except Exception as e:
                await tracker.track(e)

            stats = tracker.stats
            assert "total_errors" in stats
            assert stats["total_errors"] >= 1

        asyncio.run(_test())

    def test_error_report(self):
        tracker = ErrorTracker(max_records=100)

        async def _test():
            try:
                raise ValueError("report test")
            except Exception as e:
                await tracker.track(e)

            report = tracker.generate_report()
            assert isinstance(report, str)
            assert len(report) > 0

        asyncio.run(_test())

    def test_error_handler_callback(self):
        tracker = ErrorTracker(max_records=100)
        handler_calls = []
        tracker.add_handler(lambda r: handler_calls.append(r))

        async def _test():
            try:
                raise ValueError("callback test")
            except Exception as e:
                await tracker.track(e)

            assert len(handler_calls) >= 1

        asyncio.run(_test())

    def test_error_clear(self):
        tracker = ErrorTracker(max_records=100)

        async def _test():
            try:
                raise ValueError("clear test")
            except Exception as e:
                await tracker.track(e)

            tracker.clear()
            assert len(tracker.get_all()) == 0

        asyncio.run(_test())


# ==================== 应用生命周期钩子测试 ====================

class TestAppLifecycleHooks:
    def test_before_server_start_hook(self):
        app = _create_app()
        called = []

        @app.before_server_start
        async def on_start():
            called.append("started")

        assert hasattr(app, 'middleware_manager')

    def test_after_server_stop_hook(self):
        app = _create_app()
        called = []

        @app.after_server_stop
        async def on_stop():
            called.append("stopped")

        assert hasattr(app, 'middleware_manager')


# ==================== 依赖覆盖测试 ====================

class TestDependencyOverrides:
    def test_dependency_overrides_property(self):
        app = _create_app()
        overrides = app.dependency_overrides
        assert overrides is not None


# ==================== 错误处理器测====================

class TestErrorHandlers:
    def test_custom_error_handler(self):
        app = _create_app()

        @app.exception(404)
        async def custom_404(request, exc):
            return json_resp({"custom_error": "not found", "message": exc.message})

        @app.get("/missing")
        async def missing(request):
            raise NotFound("Gone away")

        client = app.test_client
        resp = client.get("/missing")
        assert resp.status == 404
        data = json.loads(resp.body)
        assert data.get("custom_error") == "not found"

    def test_error_handler_mro(self):
        app = _create_app()

        class CustomError(KeweException):
            def __init__(self, message="custom error"):
                super().__init__(message, status_code=499)

        @app.exception(KeweException)
        async def handle_kewe(request, exc):
            return json_resp({"caught": exc.message}, status=exc.status)

        @app.get("/custom_err")
        async def err(request):
            raise CustomError("custom error occurred")

        client = app.test_client
        resp = client.get("/custom_err")
        assert resp.status == 499
        data = json.loads(resp.body)
        assert data.get("caught") == "custom error occurred"


# ==================== 信号系统测试 ====================

class TestSignalSystem:
    def test_signal_dispatch(self):
        app = _create_app()
        received = []

        @app.signal("user_created")
        async def on_user_created(data=None):
            received.append(data)

        async def _test():
            await app.dispatch("user_created", data={"user_id": 1})
            await asyncio.sleep(0.05)
            assert len(received) >= 1

        asyncio.run(_test())


# ==================== 蓝图测试 ====================

class TestBlueprint:
    def test_blueprint_registration(self):
        from kewe.routing.blueprints import Blueprint
        app = _create_app()
        bp = Blueprint("api", url_prefix="/api/v1")

        @bp.route("/users")
        async def users(request):
            return json_resp({"users": []})

        app.register_blueprint(bp)
        client = app.test_client
        resp = client.get("/api/v1/users")
        assert resp.status == 200


# ==================== Session 深度测试 ====================

class TestSessionDeep:
    def test_session_regenerate_id(self):
        s = Session()
        old_id = s.session_id
        s.regenerate_id()
        assert s.session_id != old_id
        assert s.modified is True

    def test_session_dict_operations(self):
        s = Session()
        s["user"] = "alice"
        s["role"] = "admin"
        assert s["user"] == "alice"
        assert "role" in s
        del s["role"]
        assert "role" not in s

    def test_session_permanent_flag(self):
        s = Session()
        s._permanent = True
        assert s._permanent is True


# ==================== CORS 测试 ====================

class TestCORS:
    def test_cors_configuration(self):
        app = _create_app()
        app.cors(
            origins=["*"],
            methods=["GET", "POST"],
            headers=["Content-Type"],
            max_age=3600
        )


# ==================== 静态文件测====================

class TestStaticFiles:
    def test_static_route_registration(self):
        app = _create_app()
        with tempfile.TemporaryDirectory() as tmpdir:
            app.static("/static", directory=tmpdir)


# ==================== 应用注册表测====================

class TestAppRegistry:
    def test_get_registered_apps(self):
        from kewe.app import Kewe
        apps = Kewe.get_registered_apps()
        assert isinstance(apps, dict) or hasattr(apps, 'items')

    def test_get_app_by_name(self):
        from kewe.app import Kewe
        app = Kewe("registry_test_app", config=KeweConfig(secret_key="test", enable_gateway=False))
        found = Kewe.get_app("registry_test_app")
        assert found is not None
        assert found.name == "registry_test_app"
