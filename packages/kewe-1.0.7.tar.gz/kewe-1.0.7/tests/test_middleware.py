#!/usr/bin/env python

"中间件系统测"""



import pytest

from kewe import Kewe

from kewe.response import Response





@pytest.mark.asyncio

async def test_request_middleware():

    "测试请求中间"""

    app = Kewe("TestApp", enable_gateway=False)

    middleware_called = False

    

    @app.middleware('request')

    async def test_middleware(request):

        nonlocal middleware_called

        middleware_called = True

        request.ctx.test_value = "test"

    

    @app.get("/test")

    async def test_handler(request):

        return {"test_value": request.ctx.test_value}

    

    # 使用异步测试客户
    from kewe.utils.testing import AsyncTestClient

    client = AsyncTestClient(app)

    response = await client.get("/test")

    

    assert middleware_called

    assert response.json == {"test_value": "test"}





@pytest.mark.asyncio

async def test_response_middleware():

    "测试响应中间"""

    app = Kewe("TestApp", enable_gateway=False)

    middleware_called = False

    

    @app.middleware('response')

    async def test_middleware(request, response):

        nonlocal middleware_called

        middleware_called = True

        response.headers['X-Test'] = "test"

    

    @app.get("/test")

    async def test_handler(request):

        return {"message": "test"}

    

    # 使用异步测试客户
    from kewe.utils.testing import AsyncTestClient

    client = AsyncTestClient(app)

    response = await client.get("/test")

    

    assert middleware_called

    assert response.headers.get('X-Test') == "test"





@pytest.mark.asyncio

async def test_middleware_priority():

    "测试中间件优先级"""

    app = Kewe("TestApp", enable_gateway=False)

    call_order = []

    

    @app.middleware(priority=10)

    async def high_priority_middleware(request):

        call_order.append("high")

    

    @app.middleware(priority=5)

    async def medium_priority_middleware(request):

        call_order.append("medium")

    

    @app.middleware(priority=1)

    async def low_priority_middleware(request):

        call_order.append("low")

    

    @app.get("/test")

    async def test_handler(request):

        return {"order": call_order}

    

    # 使用异步测试客户
    from kewe.utils.testing import AsyncTestClient

    client = AsyncTestClient(app)

    response = await client.get("/test")

    

    assert call_order == ["low", "medium", "high"]

