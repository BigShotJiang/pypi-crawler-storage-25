import pytest
from kewe import Kewe
from kewe.utils.testing import AsyncTestClient


@pytest.fixture
def app():
    return Kewe("TestStreaming", enable_gateway=False)


@pytest.fixture
async def client(app):
    return AsyncTestClient(app)


class TestStreamingResponse:
    @pytest.mark.asyncio
    async def test_streaming_response_object(self):
        from kewe.response import StreamingResponse
        
        async def generate():
            yield b"chunk1"
            yield b"chunk2"
            yield b"chunk3"
        
        resp = StreamingResponse(body=generate(), content_type="text/plain")
        assert resp.is_streaming is True
        assert resp.stream_generator is not None
    
    @pytest.mark.asyncio
    async def test_streaming_response_not_streaming(self):
        from kewe.response import json
        
        resp = json({"data": "test"})
        assert resp.is_streaming is False
    
    @pytest.mark.asyncio
    async def test_sse_response(self):
        try:
            from kewe.response.streaming import ServerSentEventResponse
            
            async def event_generator():
                yield {"event": "update", "data": "hello"}
                yield {"event": "update", "data": "world"}
            
            resp = ServerSentEventResponse(event_generator())
            assert resp is not None
        except ImportError:
            pytest.skip("streaming_response module not available")
    
    @pytest.mark.asyncio
    async def test_file_stream_response(self):
        try:
            from kewe.response.streaming import FileStreamResponse
            import tempfile
            import os
            
            with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
                f.write("test content for streaming")
                temp_path = f.name
            
            try:
                resp = FileStreamResponse(temp_path)
                assert resp is not None
            finally:
                os.unlink(temp_path)
        except ImportError:
            pytest.skip("streaming_response module not available")


class TestFileUpload:
    @pytest.mark.asyncio
    async def test_file_upload_json(self, app, client):
        @app.post("/upload-json")
        async def upload_handler(request):
            from kewe.response import json
            return json({"received": True})
        
        response = await client.post("/upload-json", json={"filename": "test.txt", "content": "hello"})
        assert response.status == 200
    
    @pytest.mark.asyncio
    async def test_file_upload_form_data(self, app, client):
        @app.post("/upload-form")
        async def upload_handler(request):
            from kewe.response import json
            return json({"received": True})
        
        response = await client.post("/upload-form", data={"field1": "value1", "field2": "value2"})
        assert response.status == 200


class TestUploadsModule:
    def test_file_storage(self):
        from kewe.request.uploads import FileStorage
        import io
        
        fs = FileStorage(
            stream=io.BytesIO(b"hello world"),
            filename="test.txt",
            name="file",
            content_type="text/plain"
        )
        assert fs.filename == "test.txt"
        assert fs.content_type == "text/plain"
    
    def test_upload_config(self):
        from kewe.request.uploads import UploadConfig
        
        config = UploadConfig(
            max_content_length=10 * 1024 * 1024,
            allowed_extensions={".txt", ".pdf", ".png"}
        )
        assert config.max_content_length == 10 * 1024 * 1024
        assert ".txt" in config.allowed_extensions
    
    def test_file_validator(self):
        from kewe.request.uploads import FileValidator, FileStorage
        import io
        
        validator = FileValidator(
            allowed_extensions=[".txt", ".pdf"],
            max_size=10 * 1024 * 1024
        )
        
        fs = FileStorage(
            stream=io.BytesIO(b"hello"),
            filename="test.txt",
            name="file",
            content_type="text/plain"
        )
        errors = validator.validate(fs)
        assert len(errors) == 0
        
        fs_bad = FileStorage(
            stream=io.BytesIO(b"hello"),
            filename="test.exe",
            name="file",
            content_type="application/octet-stream"
        )
        errors = validator.validate(fs_bad)
        assert len(errors) > 0
