import os
import sys
from io import StringIO
from unittest.mock import patch
import kewe

import pytest

from kewe.application.logo import (
    get_logo,
    get_version_display,
    get_runtime_info,
    display_motd,
    MOTDBasic,
    MOTDTTY,
    _supports_color,
    _KEWE_FULL,
    _KEWE_SIMPLE,
    _COFFEE_FULL,
    _colorize_logo_multiline,
    _colorize_logo_single,
    _safe_coffee_emoji,
    _KEWE_COLOR_PALETTE,
    _COLOR_CYAN,
    _COLOR_GREEN,
    _COLOR_YELLOW,
    _COLOR_RESET,
)


class TestASCIIArt:
    def test_kewe_full_spells_kewe(self):
        assert "__" in _KEWE_FULL
        assert "\\_\\_" in _KEWE_FULL

    def test_kewe_simple_is_kewe(self):
        assert _KEWE_SIMPLE == "KeWe"

    def test_coffee_full_has_placeholder(self):
        assert "{emoji}" in _COFFEE_FULL

    def test_kewe_full_has_5_lines(self):
        lines = [l for l in _KEWE_FULL.split("\n") if l.strip()]
        assert len(lines) == 5

    def test_kewe_full_contains_key_patterns(self):
        assert "| |" in _KEWE_FULL
        assert "\\_\\_" in _KEWE_FULL


class TestGetLogo:
    def test_simple_logo_default(self):
        with patch("kewe.application.logo._supports_color", return_value=False):
            logo = get_logo()
        assert "KeWe" in logo

    def test_full_logo_contains_ascii_art(self):
        with patch("kewe.application.logo._supports_color", return_value=False):
            logo = get_logo(full=True)
        assert "___" in logo
        assert "/_/" in logo or "\\_\\_" in logo

    def test_coffee_logo_simple(self):
        with patch("kewe.application.logo._supports_color", return_value=False):
            logo = get_logo(coffee=True)
        assert "KeWe" in logo

    def test_coffee_logo_full(self):
        with patch("kewe.application.logo._supports_color", return_value=False):
            logo = get_logo(full=True, coffee=True)
        assert "___" in logo

    def test_logo_with_color(self):
        with patch("kewe.application.logo._supports_color", return_value=True):
            logo = get_logo()
        assert "\033[" in logo

    def test_logo_without_color(self):
        with patch("kewe.application.logo._supports_color", return_value=False):
            logo = get_logo()
        assert "\033[" not in logo

    def test_full_logo_no_color_has_content(self):
        with patch("kewe.application.logo._supports_color", return_value=False):
            logo = get_logo(full=True)
        assert len(logo.strip()) > 10

    def test_full_logo_with_color_multiline(self):
        with patch("kewe.application.logo._supports_color", return_value=True):
            logo = get_logo(full=True)
        assert "\033[" in logo
        lines = [l for l in logo.split("\n") if l.strip()]
        assert len(lines) >= 5


class TestColorize:
    def test_colorize_single_line(self):
        result = _colorize_logo_single("KeWe")
        assert _COLOR_CYAN in result
        assert _COLOR_RESET in result
        assert "KeWe" in result

    def test_colorize_multiline(self):
        text = "line1\nline2\nline3"
        result = _colorize_logo_multiline(text)
        assert "\033[" in result
        assert "line1" in result
        assert "line2" in result
        assert "line3" in result

    def test_colorize_multiline_uses_palette(self):
        text = "a\nb\nc\nd\ne"
        result = _colorize_logo_multiline(text)
        for color in _KEWE_COLOR_PALETTE:
            assert color in result

    def test_colorize_multiline_skips_blank_lines(self):
        text = "hello\n\nworld"
        result = _colorize_logo_multiline(text)
        lines = result.split("\n")
        assert _KEWE_COLOR_PALETTE[0] in lines[0]
        assert lines[1] == ""
        assert _KEWE_COLOR_PALETTE[2] in lines[2]


class TestSafeCoffeeEmoji:
    def test_returns_emoji_on_utf8(self):
        with patch.object(sys, "stdout") as mock_stdout:
            mock_stdout.encoding = "utf-8"
            result = _safe_coffee_emoji()
            assert result == "\u2615"

    def test_returns_fallback_on_gbk(self):
        with patch.object(sys, "stdout") as mock_stdout:
            mock_stdout.encoding = "gbk"
            result = _safe_coffee_emoji()
            assert result == "(C)"


class TestGetVersionDisplay:
    def test_returns_version_string(self):
        version = get_version_display()
        assert version.startswith("v")
        assert kewe.__version__ in version

    def test_version_format(self):
        version = get_version_display()
        parts = version.lstrip("v").split(".")
        assert len(parts) >= 2


class TestGetRuntimeInfo:
    def test_returns_dict(self):
        info = get_runtime_info()
        assert isinstance(info, dict)

    def test_contains_python_version(self):
        info = get_runtime_info()
        assert "python" in info
        assert info["python"]

    def test_contains_platform(self):
        info = get_runtime_info()
        assert "platform" in info

    def test_contains_kewe_version(self):
        info = get_runtime_info()
        assert "kewe" in info
        assert info["kewe"] == kewe.__version__


class TestSupportsColor:
    def test_no_color_env_disables(self):
        with patch.dict(os.environ, {"NO_COLOR": "1"}):
            assert _supports_color() is False

    def test_kewe_no_color_env_disables(self):
        with patch.dict(os.environ, {"KEWE_NO_COLOR": "1"}, clear=False):
            assert _supports_color() is False

    def test_dumb_term_disables(self):
        with patch.dict(os.environ, {"TERM": "dumb"}, clear=False):
            assert _supports_color() is False


class TestMOTDBasic:
    def test_display_outputs_logo(self):
        motd = MOTDBasic(
            logo="TestLogo",
            serve_location="http://0.0.0.0:8000",
            data={"mode": "production"},
        )
        motd.display()
        assert True

    def test_output_class_method(self):
        MOTDBasic.output(
            logo="TestLogo",
            serve_location="http://0.0.0.0:8000",
            data={"mode": "production"},
        )
        assert True


class TestMOTDTTY:
    def test_display_with_version(self):
        lines = []
        out_fn = lines.append
        motd = MOTDTTY(
            logo="TestLogo",
            serve_location="http://0.0.0.0:8000",
            data={"mode": "production"},
        )
        with patch("kewe.application.logo._supports_color", return_value=False):
            motd.display(version=True, action="Going Fast", out=out_fn)
        assert any("Going Fast" in line for line in lines)
        assert any("0.0.0.0:8000" in line for line in lines)

    def test_display_without_version(self):
        lines = []
        out_fn = lines.append
        motd = MOTDTTY(
            logo="TestLogo",
            serve_location="http://0.0.0.0:8000",
            data={"mode": "production"},
        )
        with patch("kewe.application.logo._supports_color", return_value=False):
            motd.display(version=False, out=out_fn)
        assert any("0.0.0.0:8000" in line for line in lines)

    def test_display_with_extra(self):
        lines = []
        out_fn = lines.append
        motd = MOTDTTY(
            logo="TestLogo",
            serve_location="http://0.0.0.0:8000",
            data={"mode": "production"},
            extra={"gateway": "/api"},
        )
        with patch("kewe.application.logo._supports_color", return_value=False):
            motd.display(out=out_fn)
        assert any("gateway" in line for line in lines)
        assert any("/api" in line for line in lines)

    def test_display_with_color(self):
        lines = []
        out_fn = lines.append
        motd = MOTDTTY(
            logo="TestLogo",
            serve_location="http://0.0.0.0:8000",
            data={"mode": "production"},
        )
        with patch("kewe.application.logo._supports_color", return_value=True):
            motd.display(out=out_fn)
        assert any("\033[" in line for line in lines)

    def test_output_class_method(self):
        with patch("kewe.application.logo._supports_color", return_value=False):
            MOTDTTY.output(
                logo="TestLogo",
                serve_location="http://0.0.0.0:8000",
                data={"mode": "production"},
            )
        assert True

    def test_display_with_full_kewe_logo(self):
        lines = []
        out_fn = lines.append
        with patch("kewe.application.logo._supports_color", return_value=False):
            logo = get_logo(full=True)
        motd = MOTDTTY(
            logo=logo,
            serve_location="http://0.0.0.0:8000",
            data={"mode": "production"},
        )
        with patch("kewe.application.logo._supports_color", return_value=False):
            motd.display(out=out_fn)
        assert any("___" in line for line in lines)
        assert any("Going Fast" in line for line in lines)


class TestDisplayMotd:
    def test_display_motd_tty(self):
        with patch("kewe.application.logo._supports_color", return_value=True):
            display_motd(
                "http://0.0.0.0:8000",
                data={"mode": "production"},
            )
        assert True

    def test_display_motd_basic(self):
        with patch("kewe.application.logo._supports_color", return_value=False):
            display_motd(
                "http://0.0.0.0:8000",
                data={"mode": "production"},
            )
        assert True

    def test_display_motd_with_full_logo(self):
        with patch("kewe.application.logo._supports_color", return_value=False):
            display_motd(
                "http://0.0.0.0:8000",
                data={"mode": "production"},
                full=True,
            )
        assert True

    def test_display_motd_with_coffee(self):
        with patch("kewe.application.logo._supports_color", return_value=False):
            display_motd(
                "http://0.0.0.0:8000",
                data={"mode": "production"},
                coffee=True,
            )
        assert True

    def test_display_motd_empty_data(self):
        with patch("kewe.application.logo._supports_color", return_value=False):
            display_motd("http://0.0.0.0:8000")
        assert True

    def test_display_motd_full_with_color(self):
        with patch("kewe.application.logo._supports_color", return_value=True):
            display_motd(
                "http://0.0.0.0:8000",
                data={"mode": "production"},
                full=True,
            )
        assert True


class TestTopLevelImport:
    def test_import_from_kewe_logo(self):
        from kewe.application.logo import get_logo as gl
        from kewe.application.logo import display_motd as dm
        from kewe.application.logo import get_version_display as gvd
        from kewe.application.logo import get_runtime_info as gri
        from kewe.application.logo import MOTD, MOTDBasic, MOTDTTY
        assert callable(gl)
        assert callable(dm)
        assert callable(gvd)
        assert callable(gri)

    def test_lazy_import_from_kewe(self):
        import kewe
        gl = kewe.get_logo
        dm = kewe.display_motd
        assert callable(gl)
        assert callable(dm)
