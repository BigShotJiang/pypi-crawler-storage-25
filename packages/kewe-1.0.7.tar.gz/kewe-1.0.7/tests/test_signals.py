import pytest
from kewe.application.signals import Signal, SignalBus, SignalEvent, get_signal_bus, DynamicSignal, EventWaiter


class TestSignal:
    @pytest.mark.asyncio
    async def test_signal_creation(self):
        sig = Signal(SignalEvent.HTTP_HANDLER_BEFORE)
        assert sig is not None
    
    @pytest.mark.asyncio
    async def test_signal_register_and_emit(self):
        sig = Signal(SignalEvent.HTTP_HANDLER_BEFORE)
        results = []
        
        @sig.handler(priority=50)
        def handler(ctx):
            results.append(ctx.data.get("value"))
        
        await sig.emit({"value": "hello"})
        assert len(results) == 1
        assert results[0] == "hello"
    
    @pytest.mark.asyncio
    async def test_signal_unregister(self):
        sig = Signal(SignalEvent.HTTP_HANDLER_BEFORE)
        results = []
        
        def handler(ctx):
            results.append(True)
        
        sig.register(handler)
        sig.unregister(handler)
        await sig.emit({})
        assert len(results) == 0
    
    @pytest.mark.asyncio
    async def test_signal_multiple_handlers(self):
        sig = Signal(SignalEvent.HTTP_HANDLER_BEFORE)
        results = []
        
        def handler1(ctx):
            results.append("h1")
        
        def handler2(ctx):
            results.append("h2")
        
        sig.register(handler1)
        sig.register(handler2)
        await sig.emit({})
        assert len(results) == 2
    
    @pytest.mark.asyncio
    async def test_signal_priority(self):
        sig = Signal(SignalEvent.HTTP_HANDLER_BEFORE)
        results = []
        
        def handler_low(ctx):
            results.append("low")
        
        def handler_high(ctx):
            results.append("high")
        
        sig.register(handler_low, priority=100)
        sig.register(handler_high, priority=0)
        await sig.emit({})
        assert results[0] == "high"
        assert results[1] == "low"
    
    @pytest.mark.asyncio
    async def test_signal_has_handlers(self):
        sig = Signal(SignalEvent.HTTP_HANDLER_BEFORE)
        assert sig.has_handlers is False
        
        sig.register(lambda ctx: None)
        assert sig.has_handlers is True


class TestSignalBus:
    @pytest.mark.asyncio
    async def test_signal_bus_on(self):
        bus = SignalBus()
        results = []
        
        @bus.on(SignalEvent.HTTP_HANDLER_BEFORE)
        def handler(ctx):
            results.append(ctx.data.get("user"))
        
        await bus.emit(SignalEvent.HTTP_HANDLER_BEFORE, {"user": "alice"})
        assert len(results) == 1
        assert results[0] == "alice"
    
    @pytest.mark.asyncio
    async def test_signal_bus_multiple_events(self):
        bus = SignalBus()
        results = []
        
        @bus.on(SignalEvent.HTTP_HANDLER_BEFORE)
        def handler_a(ctx):
            results.append("a")
        
        @bus.on(SignalEvent.HTTP_HANDLER_AFTER)
        def handler_b(ctx):
            results.append("b")
        
        await bus.emit(SignalEvent.HTTP_HANDLER_BEFORE, {})
        await bus.emit(SignalEvent.HTTP_HANDLER_AFTER, {})
        assert "a" in results
        assert "b" in results
    
    @pytest.mark.asyncio
    async def test_signal_bus_no_handlers(self):
        bus = SignalBus()
        await bus.emit(SignalEvent.HTTP_HANDLER_AFTER, {})
    
    def test_get_signal_bus(self):
        bus = get_signal_bus()
        assert isinstance(bus, SignalBus)
    
    @pytest.mark.asyncio
    async def test_signal_bus_custom_signal(self):
        bus = SignalBus()
        results = []
        
        custom_signal = bus.create_custom_signal("custom.event")
        
        @custom_signal.handler()
        def handler(ctx):
            results.append(ctx.data.get("msg"))
        
        await bus.emit("custom.event", {"msg": "hello"})
        assert len(results) == 1
        assert results[0] == "hello"


class TestDynamicSignal:
    def test_dynamic_signal_matches(self):
        ds = DynamicSignal("user.<action>")
        result = ds.matches("user.created")
        assert result is not None
        assert result.get("action") == "created"
        
        no_match = ds.matches("order.created")
        assert no_match is None
    
    @pytest.mark.asyncio
    async def test_dynamic_signal_no_match(self):
        ds = DynamicSignal("user.<action>")
        results = []
        
        def handler(ctx):
            results.append(True)
        
        ds.add_handler(handler)
        
        await ds.emit("order.created", {})
        assert len(results) == 0


class TestEventWaiter:
    def test_event_waiter_creation(self):
        waiter = EventWaiter()
        assert waiter is not None
    
    def test_event_waiter_notify(self):
        waiter = EventWaiter()
        waiter.notify("test.event", {"data": "hello"})
