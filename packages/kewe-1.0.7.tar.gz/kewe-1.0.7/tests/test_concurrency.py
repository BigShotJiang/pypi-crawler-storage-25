#!/usr/bin/env python
"并发测试"""

import pytest
import asyncio
import concurrent.futures
from kewe import Kewe
from kewe.response import json
from kewe.utils.testing import TestClient


class TestConcurrency:
    "并发处理测试"""
    
    def test_concurrent_requests_sequential(self):
        "测试顺序请求处理"""
        app = Kewe("test-concurrent")
        
        request_count = 0
        
        @app.get("/counter")
        async def counter(request):
            nonlocal request_count
            request_count += 1
            return json({"count": request_count})
        
        client = TestClient(app)
        
        results = []
        for _ in range(10):
            results.append(client.get("/counter"))
        
        assert len(results) == 10
        assert all(r.status == 200 for r in results)
    
    def test_async_handler(self):
        "测试异步处理"""
        app = Kewe("test-async")
        
        @app.get("/async")
        async def async_handler(request):
            await asyncio.sleep(0.01)
            return json({"async": True})
        
        client = TestClient(app)
        
        response = client.get("/async")
        assert response.status == 200
        assert response.json["async"] is True
    
    def test_sync_handler(self):
        "测试同步处理"""
        app = Kewe("test-sync")
        
        @app.get("/sync")
        def sync_handler(request):
            return json({"sync": True})
        
        client = TestClient(app)
        
        response = client.get("/sync")
        assert response.status == 200
        assert response.json["sync"] is True


class TestMiddlewareConcurrency:
    "中间件并发测"""
    
    def test_middleware_state_isolation(self):
        "测试中间件状态隔"""
        app = Kewe("test-mw-isolation")
        
        execution_log = []
        
        @app.middleware("request")
        async def tracking_middleware(request):
            request.ctx.request_id = id(request)
            execution_log.append(("middleware", request.ctx.request_id))
            return True
        
        @app.get("/test")
        async def test_handler(request):
            execution_log.append(("handler", request.ctx.request_id))
            return json({"id": request.ctx.request_id})
        
        client = TestClient(app)
        
        response1 = client.get("/test")
        response2 = client.get("/test")
        
        assert response1.status == 200
        assert response2.status == 200


class TestRequestContext:
    "请求上下文测"""
    
    def test_request_ctx_isolation(self):
        "测试请求上下文隔"""
        app = Kewe("test-ctx-isolation")
        
        @app.middleware("request")
        async def set_context(request):
            request.ctx.user_id = 123
            request.ctx.timestamp = asyncio.get_event_loop().time()
            return True
        
        @app.get("/user")
        async def get_user(request):
            return json({
                "user_id": request.ctx.user_id,
                "has_timestamp": hasattr(request.ctx, 'timestamp')
            })
        
        client = TestClient(app)
        
        response = client.get("/user")
        assert response.status == 200
        assert response.json["user_id"] == 123
        assert response.json["has_timestamp"] is True
    
    def test_request_ctx_per_request(self):
        "测试每个请求独立上下"""
        app = Kewe("test-ctx-per-request")
        
        @app.middleware("request")
        async def set_counter(request):
            request.ctx.counter = 0
            return True
        
        @app.get("/increment")
        async def increment(request):
            request.ctx.counter += 1
            return json({"counter": request.ctx.counter})
        
        client = TestClient(app)
        
        response1 = client.get("/increment")
        response2 = client.get("/increment")
        
        assert response1.json["counter"] == 1
        assert response2.json["counter"] == 1


class TestErrorHandlingConcurrency:
    "错误处理并发测试"""
    
    def test_exception_isolation(self):
        "测试异常隔离"""
        app = Kewe("test-exception-isolation")
        
        call_count = 0
        
        @app.get("/error")
        async def error_handler(request):
            nonlocal call_count
            call_count += 1
            if call_count % 2 == 0:
                raise ValueError("Test error")
            return json({"ok": True})
        
        @app.exception(500)
        async def handle_500(request, exception):
            return json({"error": str(exception)}, status=500)
        
        client = TestClient(app)
        
        response1 = client.get("/error")
        response2 = client.get("/error")
        response3 = client.get("/error")
        
        assert response1.status == 200
        assert response2.status == 500
        assert response3.status == 200


class TestStreamingResponse:
    "流式响应测试"""
    
    def test_streaming_response(self):
        "测试流式响应"""
        app = Kewe("test-streaming")
        
        @app.get("/stream")
        async def stream_handler(request):
            return json({"streaming": True})
        
        client = TestClient(app)
        
        response = client.get("/stream")
        assert response.status == 200


class TestFileUpload:
    "文件上传测试"""
    
    def test_file_upload_basic(self):
        "测试基本文件上传"""
        app = Kewe("test-file-upload")
        
        @app.post("/upload")
        async def upload_handler(request):
            return json({"uploaded": True})
        
        client = TestClient(app)
        
        response = client.post("/upload", data=b"test file content")
        
        assert response.status == 200
    
    def test_large_body_handling(self):
        "测试大请求体处理"""
        app = Kewe("test-large-body")
        
        @app.post("/large")
        async def large_handler(request):
            body = (await request.json) if hasattr(request, 'json') else {}
            return json({"size": len(str(body))})
        
        client = TestClient(app)
        
        large_data = {"data": "x" * 10000}
        response = client.post("/large", json=large_data)
        
        assert response.status == 200


class TestConnectionManagement:
    "连接管理测试"""
    
    def test_connection_tracking(self):
        "测试连接追踪"""
        app = Kewe("test-connection")
        
        @app.get("/test")
        async def test_handler(request):
            return json({"ok": True})
        
        client = TestClient(app)
        
        response = client.get("/test")
        assert response.status == 200
