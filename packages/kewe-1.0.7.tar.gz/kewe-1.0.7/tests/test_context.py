import pytest
from kewe.base.context import RequestContext, AppContext, g
from kewe import Kewe


class TestRequestContext:
    def test_request_context_creation(self):
        app = Kewe("TestCtx", enable_gateway=False)
        from kewe.request import Request
        req = Request(method="GET", path="/", headers={}, query_params={}, body=b"", client_ip="127.0.0.1")
        ctx = RequestContext(request=req, app=app)
        assert ctx is not None
    
    def test_request_context_variables(self):
        app = Kewe("TestCtx", enable_gateway=False)
        from kewe.request import Request
        req = Request(method="GET", path="/", headers={}, query_params={}, body=b"", client_ip="127.0.0.1")
        ctx = RequestContext(request=req, app=app)
        ctx.set("user_id", 42)
        assert ctx.get("user_id") == 42
    
    def test_request_context_get_default(self):
        app = Kewe("TestCtx", enable_gateway=False)
        from kewe.request import Request
        req = Request(method="GET", path="/", headers={}, query_params={}, body=b"", client_ip="127.0.0.1")
        ctx = RequestContext(request=req, app=app)
        assert ctx.get("nonexistent") is None
        assert ctx.get("nonexistent", "default") == "default"
    
    def test_request_context_contains(self):
        app = Kewe("TestCtx", enable_gateway=False)
        from kewe.request import Request
        req = Request(method="GET", path="/", headers={}, query_params={}, body=b"", client_ip="127.0.0.1")
        ctx = RequestContext(request=req, app=app)
        ctx.set("key", "value")
        assert "key" in ctx
        assert "nonexistent" not in ctx
    
    def test_request_context_item_access(self):
        app = Kewe("TestCtx", enable_gateway=False)
        from kewe.request import Request
        req = Request(method="GET", path="/", headers={}, query_params={}, body=b"", client_ip="127.0.0.1")
        ctx = RequestContext(request=req, app=app)
        ctx["key"] = "value"
        assert ctx["key"] == "value"


class TestAppContext:
    def test_app_context_creation(self):
        app = Kewe("TestCtx", enable_gateway=False)
        ctx = AppContext(app)
        assert ctx is not None
    
    def test_app_context_variables(self):
        app = Kewe("TestCtx", enable_gateway=False)
        ctx = AppContext(app)
        ctx.set("db", "database_connection")
        assert ctx.get("db") == "database_connection"


class TestGObject:
    def test_g_object_set_get(self):
        from kewe.base.context import RequestContext
        with RequestContext() as ctx:
            g.test_user_id = 42
            assert g.test_user_id == 42
    
    def test_g_object_item_access(self):
        from kewe.base.context import RequestContext
        with RequestContext() as ctx:
            g["test_key"] = "value"
            assert g["test_key"] == "value"
