import pytest
from kewe import Kewe
from kewe.cookies.session import (
    Session, SessionConfig, SecureCookieSessionInterface,
    RedisSessionInterface, SessionMiddleware, setup_session
)
from kewe.utils.testing import AsyncTestClient


@pytest.fixture
def app():
    return Kewe("TestSession", enable_gateway=False)


@pytest.fixture
async def client(app):
    return AsyncTestClient(app)


class TestSession:
    def test_session_creation(self):
        session = Session()
        assert len(session) == 0
        assert session.modified is False
    
    def test_session_set_item(self):
        session = Session()
        session["user_id"] = 42
        assert session["user_id"] == 42
        assert session.modified is True
    
    def test_session_delete_item(self):
        session = Session()
        session["key"] = "value"
        session._modified = False
        del session["key"]
        assert session.modified is True
    
    def test_session_pop(self):
        session = Session()
        session["key"] = "value"
        session._modified = False
        result = session.pop("key")
        assert result == "value"
        assert session.modified is True
    
    def test_session_update(self):
        session = Session()
        session._modified = False
        session.update({"a": 1, "b": 2})
        assert session.modified is True
        assert session["a"] == 1
    
    def test_session_clear(self):
        session = Session({"a": 1, "b": 2})
        session._modified = False
        session.clear()
        assert len(session) == 0
        assert session.modified is True
    
    def test_session_permanent(self):
        session = Session()
        assert session.permanent is False
        session.permanent = True
        assert session.permanent is True
    
    def test_session_to_dict(self):
        session = Session()
        session["user_id"] = 42
        session.permanent = True
        
        d = session.to_dict()
        assert d["user_id"] == 42
        assert d["_permanent"] is True
    
    def test_session_from_dict(self):
        data = {"user_id": 42, "_permanent": True}
        session = Session.from_dict(data)
        assert session["user_id"] == 42
        assert session.permanent is True
        assert session.modified is False


class TestSecureCookieSessionInterface:
    def test_open_session_no_cookie(self):
        config = SessionConfig(secret_key="test-secret-key")
        interface = SecureCookieSessionInterface(config)
        
        class MockRequest:
            cookies = {}
        
        session = interface.open_session(MockRequest())
        assert isinstance(session, Session)
        assert len(session) == 0
    
    def test_save_and_open_session(self):
        config = SessionConfig(secret_key="test-secret-key")
        interface = SecureCookieSessionInterface(config)
        
        session = Session()
        session["user_id"] = 42
        
        class MockResponse:
            def set_cookie(self, **kwargs):
                self._cookie = kwargs
        
        response = MockResponse()
        interface.save_session(session, response)
        assert hasattr(response, '_cookie')
        assert response._cookie["key"] == "session"
    
    def test_open_session_invalid_signature(self):
        config = SessionConfig(secret_key="test-secret-key")
        interface = SecureCookieSessionInterface(config)
        
        class MockRequest:
            cookies = {"session": "invalid.body.signature"}
        
        session = interface.open_session(MockRequest())
        assert isinstance(session, Session)
        assert len(session) == 0


class TestSessionConfig:
    def test_default_config(self):
        config = SessionConfig()
        assert config.session_cookie_name == "session"
        assert config.session_cookie_httponly is True
        assert config.session_cookie_samesite == "Lax"
        assert config.session_type == "cookie"
        assert config.permanent_session_lifetime == 3600 * 24 * 31


class TestSessionIntegration:
    @pytest.mark.asyncio
    async def test_setup_session(self, app, client):
        setup_session(app, SessionConfig(secret_key="test-secret"))
        
        @app.get("/set-session")
        async def set_session(request):
            if hasattr(request, 'session'):
                request.session["user"] = "test_user"
            from kewe.response import json
            return json({"set": True})
        
        @app.get("/get-session")
        async def get_session(request):
            if hasattr(request, 'session'):
                return json({"user": request.session.get("user")})
            return json({"user": None})
        
        response = await client.get("/set-session")
        assert response.status == 200
