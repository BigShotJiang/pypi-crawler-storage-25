#!/usr/bin/env python

"配置系统测试"""

import pytest

import os

from kewe.application.config import Config, KeweConfig, load_config




def test_config_basic():

    "测试基本配置功能"""

    config = Config()

    

    # 设置配置

    config.DB_HOST = "localhost"

    config.DB_PORT = 5432

    

    # 获取配置

    assert config.DB_HOST == "localhost"

    assert config.DB_PORT == 5432

    assert config.get("DB_HOST") == "localhost"

    assert config.get("DB_PORT") == 5432

    assert config.get("NON_EXISTENT", "default") == "default"




def test_config_nested():

    "测试嵌套配置"""

    config = Config()

    

    # 设置嵌套配置

    config.set_nested("DB.HOST", "localhost")

    config.set_nested("DB.PORT", 5432)

    config.set_nested("DB.CREDENTIALS.USER", "admin")

    config.set_nested("DB.CREDENTIALS.PASSWORD", "password")

    

    # 获取嵌套配置

    assert config.get_nested("DB.HOST") == "localhost"

    assert config.get_nested("DB.PORT") == 5432

    assert config.get_nested("DB.CREDENTIALS.USER") == "admin"

    assert config.get_nested("DB.CREDENTIALS.PASSWORD") == "password"

    assert config.get_nested("NON_EXISTENT.PATH", "default") == "default"




def test_config_from_env():

    "测试从环境变量加载配置"""

    config = Config()

    

    # 设置环境变量

    os.environ["KEWE_DB__HOST"] = "localhost"

    os.environ["KEWE_DB__PORT"] = "5432"

    os.environ["KEWE_DEBUG"] = "true"

    os.environ["KEWE_WORKERS"] = "4"

    

    # 从环境变量加载

    config.load_from_env(prefix="KEWE_")

    

    # 检查配置

    assert config.get_nested("DB.HOST") == "localhost"

    assert config.get_nested("DB.PORT") == 5432

    assert config.DEBUG is True

    assert config.WORKERS == 4

    

    # 清理环境变量

    del os.environ["KEWE_DB__HOST"]

    del os.environ["KEWE_DB__PORT"]

    del os.environ["KEWE_DEBUG"]

    del os.environ["KEWE_WORKERS"]




def test_kewe_config():

    "测试KeweConfig"""

    config = KeweConfig()

    

    # 检查默认值

    assert config.host == "0.0.0.0"

    assert config.port == 8000

    assert config.debug == False

    assert config.workers == 1

    

    # 修改配置

    config.host = "127.0.0.1"

    config.port = 8080

    config.debug = True

    config.workers = 4

    

    # 检查修改后的值

    assert config.host == "127.0.0.1"

    assert config.port == 8080

    assert config.debug == True

    assert config.workers == 4




def test_load_config():

    "测试加载配置的便捷函数"""

    # 创建临时配置文件

    import tempfile

    import json

    

    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:

        json.dump({"host": "127.0.0.1", "port": 8080}, f)

        temp_file = f.name

    

    try:

        # 加载配置

        config = load_config(temp_file)

        

        # 检查配置

        assert config.host == "127.0.0.1"

        assert config.port == 8080

    finally:

        # 清理临时文件

        os.unlink(temp_file)
