#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""v1.1 真实RPS对比基准 — KeWe vs stdlib基线"""

import pytest, asyncio, time, json as stdlib_json
from kewe import Kewe, KeweConfig
from kewe.response import json as json_resp
from kewe.application.depends import Depends, Query, Body
from kewe.utils.compat import json as kewe_json


class TestRPSJSONSerialization:
    """JSON序列化RPS对比"""

    def test_orjson_vs_stdlib_throughput(self):
        """orjson vs stdlib 吞吐量对比"""
        payload = {"users": [{"id": i, "name": f"user_{i}", "email": f"u{i}@test.com",
                              "roles": ["user"], "active": True} for i in range(100)]}
        iterations = 2000

        # stdlib
        t0 = time.perf_counter()
        for _ in range(iterations):
            stdlib_json.dumps(payload)
        stdlib_elapsed = time.perf_counter() - t0
        stdlib_rps = iterations / stdlib_elapsed if stdlib_elapsed > 0 else 0

        # kewe (orjson)
        t0 = time.perf_counter()
        for _ in range(iterations):
            kewe_json.dumps(payload)
        kewe_elapsed = time.perf_counter() - t0
        kewe_rps = iterations / kewe_elapsed if kewe_elapsed > 0 else 0

        speedup = kewe_rps / stdlib_rps if stdlib_rps > 0 else 0
        assert kewe_rps > 0
        assert stdlib_rps > 0

    def test_large_payload_throughput(self):
        """大负载序列化吞吐量"""
        payload = {"data": [{"id": i, "content": "x" * 200} for i in range(500)]}
        iterations = 100

        t0 = time.perf_counter()
        for _ in range(iterations):
            kewe_json.dumps(payload)
        elapsed = time.perf_counter() - t0
        rps = iterations / elapsed if elapsed > 0 else 0
        assert rps > 0

    def test_deserialization_throughput(self):
        """反序列化吞吐量"""
        payload = {"users": [{"id": i, "name": f"user_{i}"} for i in range(200)]}
        json_str = kewe_json.dumps(payload)
        iterations = 2000

        t0 = time.perf_counter()
        for _ in range(iterations):
            kewe_json.loads(json_str)
        kewe_elapsed = time.perf_counter() - t0
        kewe_rps = iterations / kewe_elapsed if kewe_elapsed > 0 else 0

        t0 = time.perf_counter()
        for _ in range(iterations):
            stdlib_json.loads(json_str)
        stdlib_elapsed = time.perf_counter() - t0
        stdlib_rps = iterations / stdlib_elapsed if stdlib_elapsed > 0 else 0

        assert kewe_rps > 0


class TestRPSRouting:
    """路由RPS对比"""

    def test_static_route_rps(self):
        """静态路由RPS"""
        app = Kewe("rps_route", config=KeweConfig(secret_key="k"))

        @app.get("/api/v1/users/profile/settings/notifications")
        async def deep(request):
            return json_resp({"ok": True})

        c = app.test_client
        iterations = 500
        t0 = time.perf_counter()
        for _ in range(iterations):
            c.get("/api/v1/users/profile/settings/notifications")
        elapsed = time.perf_counter() - t0
        rps = iterations / elapsed if elapsed > 0 else 0
        assert rps > 0

    def test_param_route_rps(self):
        """带参数路由RPS"""
        app = Kewe("rps_param", config=KeweConfig(secret_key="k"))

        @app.get("/users/<id:int>/posts/<pid:int>/comments/<cid:int>")
        async def nested(request, id: int, pid: int, cid: int):
            return json_resp({"id": id, "pid": pid, "cid": cid})

        c = app.test_client
        iterations = 500
        t0 = time.perf_counter()
        for _ in range(iterations):
            c.get("/users/42/posts/99/comments/7")
        elapsed = time.perf_counter() - t0
        rps = iterations / elapsed if elapsed > 0 else 0
        assert rps > 0

    def test_url_for_rps(self):
        """url_for RPS"""
        app = Kewe("rps_url", config=KeweConfig(secret_key="k"))

        @app.get("/items/<id:int>", name="item_rps")
        async def item(request, id: int):
            return json_resp({"id": id})

        iterations = 5000
        t0 = time.perf_counter()
        for i in range(iterations):
            app.url_for("item_rps", id=i)
        elapsed = time.perf_counter() - t0
        rps = iterations / elapsed if elapsed > 0 else 0
        assert rps > 10000  # LRU缓存应非常快

    def test_many_routes_last_match(self):
        """100条路由中匹配最后一条"""
        app = Kewe("rps_many", config=KeweConfig(secret_key="k"))
        for i in range(99):
            @app.get(f"/route-{i}")
            async def h(request):
                return json_resp({})

        @app.get("/route-last")
        async def last(request):
            return json_resp({"found": True})

        c = app.test_client
        iterations = 200
        t0 = time.perf_counter()
        for _ in range(iterations):
            c.get("/route-last")
        elapsed = time.perf_counter() - t0
        rps = iterations / elapsed if elapsed > 0 else 0
        assert rps > 0


class TestRPSDI:
    """DI延迟RPS"""

    def test_depends_rps(self):
        """Depends解析延迟"""
        app = Kewe("rps_di", config=KeweConfig(secret_key="k"))

        async def get_db():
            return {"conn": "db_pool_1"}

        async def get_service(db=Depends(get_db)):
            return f"svc({db['conn']})"

        @app.get("/di-rps")
        async def handler(request, svc=Depends(get_service)):
            return json_resp({"svc": svc})

        c = app.test_client
        iterations = 200
        t0 = time.perf_counter()
        for _ in range(iterations):
            c.get("/di-rps")
        elapsed = time.perf_counter() - t0
        rps = iterations / elapsed if elapsed > 0 else 0
        assert rps > 0

    def test_query_param_rps(self):
        """Query参数提取延迟"""
        app = Kewe("rps_query", config=KeweConfig(secret_key="k"))

        @app.get("/search")
        async def search(request, q: str = Query(default=""), page: int = Query(default=1, ge=1),
                         size: int = Query(default=20, ge=1, le=100)):
            return json_resp({"q": q, "page": page, "size": size})

        c = app.test_client
        iterations = 200
        t0 = time.perf_counter()
        for _ in range(iterations):
            c.get("/search?q=test&page=3&size=25")
        elapsed = time.perf_counter() - t0
        rps = iterations / elapsed if elapsed > 0 else 0
        assert rps > 0


class TestRPSMiddleware:
    """中间件链RPS"""

    def test_onion_chain_rps(self):
        """5层洋葱链RPS"""
        app = Kewe("rps_mw", config=KeweConfig(secret_key="k"))

        for i in range(5):
            @app.middleware("onion")
            async def mw(request, call_next, i=i):
                r = await call_next(request)
                r.headers[f"X-MW-{i}"] = str(i)
                return r

        @app.get("/mw-rps")
        async def handler(request):
            return json_resp({})

        c = app.test_client
        iterations = 200
        t0 = time.perf_counter()
        for _ in range(iterations):
            c.get("/mw-rps")
        elapsed = time.perf_counter() - t0
        rps = iterations / elapsed if elapsed > 0 else 0
        assert rps > 0


class TestRPSRequestPool:
    """RequestPool吞吐量"""

    def test_pool_high_throughput(self):
        """高吞吐分配/释放"""
        from kewe.request.request import RequestPool
        pool = RequestPool(max_size=500)

        iterations = 10000
        t0 = time.perf_counter()
        for i in range(iterations):
            req = pool.acquire(method="GET", path=f"/api/{i % 100}")
            pool.release(req)
        elapsed = time.perf_counter() - t0
        rps = iterations / elapsed if elapsed > 0 else 0

        stats = pool.stats
        assert stats["reused"] > 0
        assert rps > 1000


class TestRPSConnectionPool:
    """连接池吞吐量"""

    def test_connection_pool_throughput(self):
        """连接池获取/释放吞吐量"""
        from kewe.touchup.performance import ConnectionPool

        async def factory():
            return type('Conn', (), {'close': lambda s: None})()

        async def bench():
            pool = ConnectionPool(factory=factory, max_size=100)
            iterations = 1000
            t0 = time.perf_counter()
            for _ in range(iterations):
                conn = await pool.acquire()
                await pool.release(conn)
            elapsed = time.perf_counter() - t0
            rps = iterations / elapsed if elapsed > 0 else 0
            await pool.close_all()
            assert rps > 0

        asyncio.run(bench())


class TestRPSConcurrency:
    """并发处理RPS"""

    def test_high_concurrency_throughput(self):
        """高并发请求吞吐量"""
        app = Kewe("rps_conc", config=KeweConfig(secret_key="k"))

        @app.get("/fast")
        async def fast(request):
            return json_resp({"ok": True})

        c = app.test_client
        iterations = 300
        t0 = time.perf_counter()
        for _ in range(iterations):
            c.get("/fast")
        elapsed = time.perf_counter() - t0
        rps = iterations / elapsed if elapsed > 0 else 0
        assert rps > 0


class TestRPSCache:
    """缓存延迟RPS"""

    def test_cache_get_set_rps(self):
        """缓存读写吞吐量"""
        from kewe.cache.manager import CacheManager
        cache = CacheManager()
        iterations = 10000

        t0 = time.perf_counter()
        for i in range(iterations):
            cache.set(f"k{i}", f"v{i}", ttl=60)
            cache.get(f"k{i}")
        elapsed = time.perf_counter() - t0
        rps = iterations / elapsed if elapsed > 0 else 0
        assert rps > 1000


class TestRPSCircuitBreaker:
    """熔断器延迟RPS"""

    def test_cb_closed_throughput(self):
        """CLOSED状态调用吞吐量"""
        from kewe.errors.circuit_breaker import CircuitBreaker
        cb = CircuitBreaker(name="rps_cb")

        def fast_call(x):
            return x * 2

        iterations = 1000
        t0 = time.perf_counter()
        for i in range(iterations):
            cb.call_sync(fast_call, i)
        elapsed = time.perf_counter() - t0
        rps = iterations / elapsed if elapsed > 0 else 0
        assert rps > 0


class TestRPSGateway:
    """网关路由RPS"""

    def test_trie_router_rps(self):
        """TrieRouter匹配吞吐量"""
        from kewe.gateway.core import TrieRouter, GatewayRoute

        router = TrieRouter()
        for i in range(100):
            route = GatewayRoute(
                path=f"/api/v1/users/{i}" if i % 2 == 0 else f"/api/v1/posts/{i}",
                method="GET", handler=lambda: None, version="v1"
            )
            router.add_route(route)

        iterations = 5000
        t0 = time.perf_counter()
        for i in range(iterations):
            router.match(f"/api/v1/users/{i % 50}", "GET", "v1")
        elapsed = time.perf_counter() - t0
        rps = iterations / elapsed if elapsed > 0 else 0
        assert rps > 1000


class TestRPSStartup:
    """启动延迟RPS"""

    def test_app_creation_speed(self):
        """应用创建速度"""
        iterations = 200
        t0 = time.perf_counter()
        for i in range(iterations):
            app = Kewe(f"startup_{i}", config=KeweConfig(secret_key="k"))
        elapsed = time.perf_counter() - t0
        rps = iterations / elapsed if elapsed > 0 else 0
        assert rps > 0
