#!/usr/bin/env python

"蓝图功能测试"""

import pytest

from kewe import Kewe
from kewe.application.config import KeweConfig
from kewe.routing.blueprints import Blueprint


def _make_app(name="TestApp"):
    config = KeweConfig(enable_gateway=False, auto_health_check=False)
    return Kewe(name, config=config)


def test_blueprint_basic():

    "测试基本蓝图功能"""

    app = _make_app()

    api = Blueprint("api", "/api")

    @api.get("/users")

    async def get_users(request):

        return {"users": []}

    @api.post("/users")

    async def create_user(request):

        return {"user": "created"}

    app.register_blueprint(api)

    routes = app.router.get_routes()

    assert len(routes) == 3

    assert any(route.path == "/api/users" for route in routes)

    get_routes = [r for r in routes if 'GET' in r.methods]

    head_routes = [r for r in routes if 'HEAD' in r.methods]

    assert len(get_routes) == 1

    assert len(head_routes) == 1




def test_blueprint_url_prefix():

    "测试蓝图URL前缀"""

    app = _make_app()

    api = Blueprint("api")

    @api.get("/users")

    async def get_users(request):

        return {"users": []}

    app.register_blueprint(api, url_prefix="/api/v1")

    routes = app.router.get_routes()

    assert len(routes) == 2

    assert any(r.path == "/api/v1/users" for r in routes)




def test_blueprint_nested():

    "测试嵌套蓝图"""

    app = _make_app()

    api = Blueprint("api", "/api")

    users = Blueprint("users", "/users")

    @users.get("/")

    async def get_users(request):

        return {"users": []}

    @users.get("/<id>")

    async def get_user(request):

        return {"id": request.ctx.path_params.get("id")}

    api.register_blueprint(users)

    app.register_blueprint(api)

    routes = app.router.get_routes()

    assert len(routes) == 4

    assert any(route.path == "/api/users/" for route in routes)

    assert any(route.path == "/api/users/<id>" for route in routes)
