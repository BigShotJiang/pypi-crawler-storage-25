#!/usr/bin/env python
"测试配置文件"""

import pytest
from kewe import Kewe


@pytest.fixture
def app():
    "创建Kewe应用实例"""
    return Kewe("TestApp", enable_gateway=False)


@pytest.fixture
def test_client(app):
    "创建异步测试客户端"""
    from kewe.utils.testing import AsyncTestClient
    return AsyncTestClient(app)
