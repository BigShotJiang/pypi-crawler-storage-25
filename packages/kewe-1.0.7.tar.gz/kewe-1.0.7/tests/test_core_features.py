#!/usr/bin/env python
"""核心功能测试"""

import pytest
import asyncio
from kewe import Kewe
from kewe.response import json
from kewe.middleware import SecurityHeadersMiddleware, MiddlewarePriority
from kewe.utils.testing import TestClient


class TestSecurityMiddleware:
    """安全中间件测试"""
    
    def test_security_headers_middleware(self):
        "测试安全头中间件"""
        app = Kewe("test-security")
        
        security_middleware = SecurityHeadersMiddleware(
            x_content_type_options="nosniff",
            x_frame_options="DENY",
            referrer_policy="strict-origin-when-cross-origin"
        )
        
        app.middleware_manager.register(
            security_middleware.response,
            attach_to="response"
        )
        
        @app.get("/")
        async def index(request):
            return json({"message": "ok"})
        
        client = TestClient(app)
        response = client.get("/")
        
        assert response.status == 200
        assert response.headers.get("x-content-type-options") == "nosniff"
        assert response.headers.get("x-frame-options") == "DENY"
        assert response.headers.get("referrer-policy") == "strict-origin-when-cross-origin"


class TestCookieSecurity:
    "Cookie安全测试"""
    
    def test_secure_cookie_defaults(self):
        from kewe.response.response import ResponseCookie as Cookie
        
        cookie = Cookie(name="session", value="test123")
        
        assert cookie.secure is False
        assert cookie.httponly is False
        assert cookie.samesite == "Lax"
    
    def test_set_cookie_secure_defaults(self):
        from kewe.response.response import ResponseCookie as Cookie
        
        cookie = Cookie(name="session", value="test123", secure=True, httponly=True)
        header = cookie.to_header()
        
        assert "Secure" in header
        assert "HttpOnly" in header
        assert "SameSite=Lax" in header


class TestRequestValidation:
    "请求验证测试"""
    
    def test_validation_decorator(self):
        "测试验证装饰"""
        from kewe.application.depends import  validate, Field, FieldType
        
        app = Kewe("test-validation")
        
        @app.post("/users")
        @validate(json=[
            Field("name", FieldType.STRING, min_length=2, max_length=50),
            Field("email", FieldType.EMAIL),
            Field("age", FieldType.INTEGER, min_value=18, max_value=100)
        ])
        async def create_user(request, validated_data):
            return json({"user": validated_data.get('json', {})})
        
        client = TestClient(app)
        
        response = client.post("/users", json={
            "name": "Test",
            "email": "test@example.com",
            "age": 25
        })
        assert response.status == 200
    
    def test_validation_required_field(self):
        "测试必填字段验证"""
        from kewe.application.depends import  validate, Field, FieldType
        
        app = Kewe("test-validation-required")
        
        @app.post("/items")
        @validate(json=[
            Field("name", FieldType.STRING, required=True),
            Field("description", FieldType.STRING, required=False)
        ])
        async def create_item(request, validated_data):
            return json({"item": validated_data.get('json', {})})
        
        client = TestClient(app)
        
        response = client.post("/items", json={"name": "Test"})
        assert response.status == 200


class TestHealthEndpoint:
    "健康检查端点测"""
    
    def test_health_check_endpoint(self):
        "测试健康检查端"""
        from kewe.monitoring.health import HealthChecker
        
        checker = HealthChecker()
        assert checker is not None
    
    def test_liveness_check(self):
        "测试存活检"""
        from kewe.application.config import KeweConfig
        config = KeweConfig(auto_health_check=False)
        app = Kewe("test-liveness", config=config)
        
        @app.get("/health/live")
        async def liveness(request):
            return json({"alive": True})
        
        client = TestClient(app)
        
        response = client.get("/health/live")
        assert response.status == 200
        assert response.json.get("alive") is True
    
    def test_readiness_check(self):
        "测试就绪检"""
        from kewe.application.config import KeweConfig
        config = KeweConfig(auto_health_check=False)
        app = Kewe("test-readiness", config=config)
        
        @app.get("/health/ready")
        async def readiness(request):
            return json({"ready": True})
        
        client = TestClient(app)
        
        response = client.get("/health/ready")
        assert response.status == 200
        assert response.json.get("ready") is True


class TestGracefulShutdown:
    "优雅关闭测试"""
    
    def test_graceful_shutdown_config(self):
        "测试优雅关闭配置"""
        app = Kewe("test-shutdown")
        app.config.keep_alive_timeout = 60.0
        
        assert app.config.keep_alive_timeout == 60.0


class TestMiddlewarePriority:
    "中间件优先级测试"""
    
    def test_middleware_execution_order(self):
        "测试中间件执行顺"""
        app = Kewe("test-priority")
        
        execution_order = []
        
        async def first_middleware(request):
            execution_order.append("first")
            return True
        
        async def second_middleware(request):
            execution_order.append("second")
            return True
        
        async def third_middleware(request):
            execution_order.append("third")
            return True
        
        app.middleware_manager.register(first_middleware, priority=100)
        app.middleware_manager.register(second_middleware, priority=50)
        app.middleware_manager.register(third_middleware, priority=10)
        
        @app.get("/")
        async def index(request):
            return json({"order": execution_order})
        
        client = TestClient(app)
        response = client.get("/")
        
        assert response.status == 200
        assert execution_order == ["third", "second", "first"]


class TestErrorHandling:
    "错误处理测试"""
    
    def test_custom_error_handler(self):
        """测试自定义错误处理器"""
        app = Kewe("test-error", enable_gateway=False)
        
        @app.exception(404)
        async def custom_404(request, exception):
            return json({"error": "Not Found", "custom": True}, status=404)
        
        @app.get("/exists")
        async def exists(request):
            return json({"message": "ok"})
        
        client = TestClient(app)
        
        response = client.get("/not-exists")
        assert response.status == 404
        assert response.json.get("custom") is True
    
    def test_exception_handler_returns_dict(self):
        """测试异常处理器返回字典"""
        app = Kewe("test-error-dict", enable_gateway=False)
        
        @app.exception(500)
        async def custom_500(request, exception):
            return {"error": "Internal Error", "details": str(exception)}
        
        @app.get("/error")
        async def trigger_error(request):
            raise ValueError("Test error")
        
        client = TestClient(app)
        response = client.get("/error")
        
        assert response.status == 500
