#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""API网关 & 熔断器 & WebSocket & HTTP客户端 全覆盖测试"""

import pytest
import time
import uuid
from kewe import Kewe, KeweConfig, json as _json_resp


@pytest.fixture
def gw_app():
    return Kewe("gw_test", config=KeweConfig(secret_key="test-key"))


class TestGatewayCore:
    """API网关核心测试"""

    def test_error_code_enum(self):
        from kewe.gateway.core import ErrorCode
        assert ErrorCode.SUCCESS.code == 0
        assert ErrorCode.SUCCESS.message == "成功"
        assert ErrorCode.UNAUTHORIZED.code == 1002
        assert ErrorCode.NOT_FOUND.code == 1004
        assert ErrorCode.RATE_LIMITED.code == 1006
        assert ErrorCode.SERVER_ERROR.code == 1007
        assert ErrorCode.VALIDATION_ERROR.code == 1010

    def test_gateway_request_dataclass(self):
        from kewe.gateway.core import GatewayRequest
        req = GatewayRequest(
            request_id=str(uuid.uuid4()),
            path="/api/test",
            method="GET",
        )
        assert req.path == "/api/test"
        assert req.method == "GET"

    def test_gateway_response_dataclass(self):
        from kewe.gateway.core import GatewayResponse
        resp = GatewayResponse(
            request_id=str(uuid.uuid4()),
            success=True,
            code=0,
            message="OK",
            data={"id": 1},
        )
        assert resp.success is True
        assert resp.code == 0
        d = resp.to_dict()
        assert d["success"] is True
        assert d["code"] == 0

    def test_gateway_response_error(self):
        from kewe.gateway.core import GatewayResponse
        resp = GatewayResponse(
            request_id=str(uuid.uuid4()),
            success=False,
            code=1002,
            message="Unauthorized",
        )
        assert resp.success is False
        assert resp.code == 1002

    def test_gateway_route_dataclass(self):
        from kewe.gateway.core import GatewayRoute
        route = GatewayRoute(
            path="/api/users",
            method="GET",
            handler=lambda: None,
            version="v1",
            require_auth=True,
            rate_limit=(100, 60),
        )
        assert route.path == "/api/users"
        assert route.method == "GET"
        assert route.require_auth is True
        assert route.rate_limit == (100, 60)

    def test_gateway_error_exception(self):
        from kewe.gateway.core import GatewayError, ErrorCode
        err = GatewayError(error_code=ErrorCode.UNAUTHORIZED, message="Auth failed")
        assert "Auth failed" in str(err)

    def test_trie_router_creation(self):
        from kewe.gateway.core import TrieRouter
        router = TrieRouter()
        assert router is not None

    def test_trie_router_add_route(self):
        from kewe.gateway.core import TrieRouter, GatewayRoute
        router = TrieRouter()
        route = GatewayRoute(path="/api/users", method="GET", handler=lambda: "users")
        router.add_route(route)
        routes = router.get_routes()
        assert len(routes) >= 1

    def test_trie_router_match_found(self):
        from kewe.gateway.core import TrieRouter, GatewayRoute
        router = TrieRouter()
        r1 = GatewayRoute(path="/api/users", method="GET", handler=lambda: "users", version="v1")
        r2 = GatewayRoute(path="/api/users/{id}", method="GET", handler=lambda: "user_detail", version="v1")
        router.add_route(r1)
        router.add_route(r2)

        matched, params = router.match("/api/users", "GET", "v1")
        assert matched is not None
        matched2, path_params = router.match("/api/users/42", "GET", "v1")
        assert matched2 is not None

    def test_trie_router_no_match(self):
        from kewe.gateway.core import TrieRouter, GatewayRoute
        router = TrieRouter()
        r = GatewayRoute(path="/api/users", method="GET", handler=lambda: "users", version="v1")
        router.add_route(r)
        result = router.match("/api/nonexistent", "GET", "v1")
        assert result is None

    def test_trie_router_clear(self):
        from kewe.gateway.core import TrieRouter, GatewayRoute
        router = TrieRouter()
        r = GatewayRoute(path="/api/test", method="GET", handler=lambda: "test")
        router.add_route(r)
        router.clear()
        routes = router.get_routes()
        assert len(routes) == 0

    def test_api_gateway_creation(self):
        from kewe.gateway.core import APIGateway
        gw = APIGateway()
        assert gw is not None

    def test_api_gateway_bind_app(self, gw_app):
        from kewe.gateway.core import APIGateway, GatewayRoute
        gw = APIGateway()
        gw.bind_app(gw_app, prefix="/api/v1")
        assert gw._app is not None

    def test_gateway_enable_on_kewe(self):
        app = Kewe("gw_enabled", config=KeweConfig(secret_key="k", enable_gateway=True))
        assert hasattr(app, 'gateway')
        assert app.gateway is not None


class TestCircuitBreaker:
    """熔断器全覆盖测试"""

    def test_circuit_state_enum(self):
        from kewe.errors.circuit_breaker import CircuitState
        assert CircuitState.CLOSED.value == "closed"
        assert CircuitState.OPEN.value == "open"
        assert CircuitState.HALF_OPEN.value == "half_open"

    def test_circuit_breaker_config_defaults(self):
        from kewe.errors.circuit_breaker import CircuitBreakerConfig
        config = CircuitBreakerConfig()
        assert config.failure_threshold == 5
        assert config.recovery_timeout == 30.0
        assert config.success_threshold == 3

    def test_circuit_breaker_config_custom(self):
        from kewe.errors.circuit_breaker import CircuitBreakerConfig
        config = CircuitBreakerConfig(failure_threshold=3, recovery_timeout=10.0,
                                      success_threshold=2, window_size=30.0)
        assert config.failure_threshold == 3
        assert config.recovery_timeout == 10.0

    def test_circuit_breaker_creation(self):
        from kewe.errors.circuit_breaker import CircuitBreaker
        cb = CircuitBreaker(name="test_cb")
        assert cb.name == "test_cb"

    def test_circuit_breaker_with_config(self):
        from kewe.errors.circuit_breaker import CircuitBreaker, CircuitBreakerConfig
        config = CircuitBreakerConfig(failure_threshold=3, recovery_timeout=10.0)
        cb = CircuitBreaker(name="configured_cb", config=config)
        assert cb.config.failure_threshold == 3

    def test_circuit_breaker_initial_state_closed(self):
        from kewe.errors.circuit_breaker import CircuitBreaker, CircuitState
        cb = CircuitBreaker(name="initial_test")
        state = cb.state
        assert state in (CircuitState.CLOSED, "closed", "CLOSED")

    def test_circuit_breaker_sync_call_success(self):
        from kewe.errors.circuit_breaker import CircuitBreaker

        def success_func(x):
            return x * 2

        cb = CircuitBreaker(name="sync_ok")
        result = cb.call_sync(success_func, 21)
        assert result == 42

    @pytest.mark.asyncio
    async def test_circuit_breaker_async_call_success(self):
        from kewe.errors.circuit_breaker import CircuitBreaker

        async def success_func(x):
            return x + 1

        cb = CircuitBreaker(name="async_ok")
        result = await cb.call(success_func, 41)
        assert result == 42

    def test_circuit_breaker_registry(self):
        from kewe.errors.circuit_breaker import CircuitBreakerRegistry
        registry = CircuitBreakerRegistry()
        cb1 = registry.get_or_create("service_a")
        cb2 = registry.get_or_create("service_b")
        cb1_again = registry.get_or_create("service_a")
        assert cb1 is cb1_again
        assert cb1 is not cb2

    def test_circuit_breaker_registry_get_all_status(self):
        from kewe.errors.circuit_breaker import CircuitBreakerRegistry
        registry = CircuitBreakerRegistry()
        registry.get_or_create("svc1")
        registry.get_or_create("svc2")
        status = registry.get_all_status()
        assert "svc1" in status
        assert "svc2" in status

    def test_circuit_open_error(self):
        from kewe.errors.circuit_breaker import CircuitOpenError
        err = CircuitOpenError("test_service")
        assert "test_service" in str(err)


class TestWebSocket:
    """WebSocket模块测试"""

    def test_websocket_route_registration(self, gw_app):
        @gw_app.websocket("/ws")
        async def ws_handler(websocket):
            await websocket.accept()

        assert hasattr(gw_app.router, '_websocket_routes')

    def test_websocket_exceptions(self):
        from kewe.websocket.exceptions import WebSocketException, WebSocketClosed
        e1 = WebSocketException("test error")
        assert "test error" in str(e1)
        e2 = WebSocketClosed("connection closed")
        assert isinstance(e2, WebSocketException)

    def test_websocket_manager_creation(self):
        from kewe.websocket.manager import WebSocketManager
        mgr = WebSocketManager()
        assert mgr is not None

    def test_websocket_protocol(self):
        from kewe.websocket.protocol import WebSocketProtocol
        proto = WebSocketProtocol()
        assert proto is not None

    def test_websocket_testing_tools(self):
        from kewe.websocket.testing import WebSocketState, WebSocketMessage
        assert WebSocketState is not None
        msg = WebSocketMessage(type="text", data="hello")
        assert msg.type == "text"
        assert msg.data == "hello"

    def test_websocket_broadcast_functions(self):
        from kewe.websocket import broadcast, broadcast_to_group, get_connection_count
        assert callable(broadcast)
        assert callable(broadcast_to_group)
        count = get_connection_count()
        assert isinstance(count, int)

    def test_websocket_blueprint_support(self, gw_app):
        from kewe import Blueprint
        bp = Blueprint("ws_bp")

        @bp.websocket("/live")
        async def live(websocket):
            await websocket.accept()

        gw_app.register_blueprint(bp, url_prefix="/realtime")
        assert hasattr(gw_app.router, '_websocket_routes')


class TestHTTPClient:
    """HTTP客户端与协议测试"""

    def test_http_client_creation(self):
        from kewe.http.client import AsyncHTTPClient
        client = AsyncHTTPClient()
        assert client is not None

    def test_http_client_config(self):
        from kewe.http.client import HttpClientConfig
        config = HttpClientConfig(base_url="https://api.example.com", timeout=10.0)
        assert config.base_url == "https://api.example.com"
        assert config.timeout == 10.0

    def test_http_client_retry_config(self):
        from kewe.http.client import RetryConfig
        config = RetryConfig(max_retries=3, backoff_factor=0.5)
        assert config.max_retries == 3

    def test_http_headers_creation(self):
        from kewe.http.headers import Headers, CIMultiDict
        h = Headers([("content-type", "application/json")])
        assert h.get("content-type") == "application/json"
        c = CIMultiDict()
        c.add("X-Custom", "v1")
        c.add("x-custom", "v2")
        assert len(c.getall("x-custom")) == 2

    def test_http_range_request_parser(self):
        from kewe.http.range_request import RangeHeaderParser
        parser = RangeHeaderParser()
        result = parser.parse("bytes=0-1023")
        assert result is not None

    def test_http_range_request_invalid(self):
        from kewe.http.range_request import RangeHeaderParser
        parser = RangeHeaderParser()
        result = parser.parse("invalid-range")
        assert result is None or result == []

    def test_http_keepalive_manager(self):
        from kewe.http.keepalive import KeepAliveManager, KeepAliveConfig
        config = KeepAliveConfig(enabled=True, timeout=5.0, max_requests=100)
        mgr = KeepAliveManager(config=config)
        assert mgr.config.timeout == 5.0
        assert mgr.config.max_requests == 100

    def test_http_keepalive_config_defaults(self):
        from kewe.http.keepalive import KeepAliveConfig
        config = KeepAliveConfig()
        assert config.enabled is True
        assert config.timeout == 5.0
        assert config.max_requests == 100

    def test_http_keepalive_optimize_headers(self):
        from kewe.http.keepalive import optimize_keep_alive_headers, KeepAliveConfig
        config = KeepAliveConfig(timeout=5, max_requests=100)
        headers = {}
        request_headers = {"Connection": "keep-alive"}
        result = optimize_keep_alive_headers(headers, config, request_headers, 200)
        assert isinstance(result, dict)

    def test_http_protocol_parser(self):
        from kewe.http.protocol import HttpParser
        parser = HttpParser()
        assert parser is not None

    def test_http_url(self):
        from kewe.http.url import HttpURL
        url = HttpURL("https://example.com/api/v1/users?id=1")
        assert url is not None
