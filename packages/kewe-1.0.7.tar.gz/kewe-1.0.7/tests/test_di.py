#!/usr/bin/env python

"依赖注入测试"""



import pytest

from kewe import Kewe





class UserService:

    "用户服务"""

    def __init__(self):

        self.users = []

    

    def add_user(self, name):

        self.users.append(name)

        return len(self.users) - 1

    

    def get_users(self):

        return self.users





class DatabaseService:

    "数据库服"""

    def __init__(self, user_service: UserService):

        self.user_service = user_service

    

    def get_all_users(self):

        return self.user_service.get_users()





@pytest.mark.asyncio

async def test_dependency_injection():

    "测试依赖注入"""

    app = Kewe("TestApp", enable_gateway=False)

    

    # 注册服务

    app.register_service(UserService, instance=UserService())

    app.register_service(DatabaseService)

    

    @app.get("/users")

    async def get_users(request, db: DatabaseService):

        return {"users": db.get_all_users()}

    

    @app.post("/users")

    async def add_user(request, user_service: UserService):

        data = await request.json

        user_id = user_service.add_user(data.get("name"))

        return {"id": user_id, "name": data.get("name")}

    

    # 使用异步测试客户
    from kewe.utils.testing import AsyncTestClient

    client = AsyncTestClient(app)

    

    # 添加用户

    response = await client.post("/users", json={"name": "test"})

    assert response.status == 200

    assert response.json == {"id": 0, "name": "test"}

    

    # 获取用户列表

    response = await client.get("/users")

    assert response.status == 200

    assert response.json == {"users": ["test"]}





@pytest.mark.asyncio

async def test_service_lifetime():

    "测试服务生命周期"""

    app = Kewe("TestApp", enable_gateway=False)

    

    # 注册单例服务

    app.register_service(UserService, lifetime="singleton")

    

    @app.get("/test")

    async def test_handler(request, user_service: UserService):

        return {"users_count": len(user_service.get_users())}

    

    # 使用异步测试客户
    from kewe.utils.testing import AsyncTestClient

    client = AsyncTestClient(app)

    

    # 第一次请
    response = await client.get("/test")

    assert response.status == 200

    assert response.json == {"users_count": 0}

    

    # 再次请求，应该使用同一个实
    response = await client.get("/test")

    assert response.status == 200

    assert response.json == {"users_count": 0}

