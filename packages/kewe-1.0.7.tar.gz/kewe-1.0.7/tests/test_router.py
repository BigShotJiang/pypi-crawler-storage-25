#!/usr/bin/env python

"路由系统测试"""

import pytest

from kewe import Kewe
from kewe.application.config import KeweConfig


def _make_app(name="TestApp"):
    config = KeweConfig(enable_gateway=False, auto_health_check=False)
    return Kewe(name, config=config)


def test_route_basic():

    "测试基本路由注册"""

    app = _make_app()

    @app.route("/test")

    async def test_handler(request):

        return {"message": "test"}

    routes = app.router.get_routes()

    assert len(routes) == 2

    assert routes[0].path == "/test"

    assert any("GET" in r.methods for r in routes)

    assert any("HEAD" in r.methods for r in routes)




def test_route_methods():

    "测试多方法路"""

    app = _make_app()

    @app.route("/test", methods=["GET", "POST"])

    async def test_handler(request):

        return {"message": "test"}

    routes = app.router.get_routes()

    assert len(routes) == 2

    main_route = [r for r in routes if 'GET' in r.methods][0]

    assert "GET" in main_route.methods

    assert "POST" in main_route.methods




def test_route_shortcuts():

    "测试路由快捷方式"""

    app = _make_app()

    @app.get("/get")

    async def get_handler(request):

        return {"method": "GET"}

    @app.post("/post")

    async def post_handler(request):

        return {"method": "POST"}

    @app.put("/put")

    async def put_handler(request):

        return {"method": "PUT"}

    @app.delete("/delete")

    async def delete_handler(request):

        return {"method": "DELETE"}

    @app.patch("/patch")

    async def patch_handler(request):

        return {"method": "PATCH"}

    routes = app.router.get_routes()

    assert len(routes) == 6




def test_route_params():

    "测试路由参数"""

    app = _make_app()

    @app.route("/users/<id:int>")

    async def user_handler(request):

        return {"id": request.ctx.path_params.get("id")}

    routes = app.router.get_routes()

    assert len(routes) == 2

    assert any(r.path == "/users/<id:int>" for r in routes)




def test_url_for():

    "测试URL反向解析"""

    app = _make_app()

    @app.route("/users/<id:int>", name="user_detail")

    async def user_handler(request):

        return {"id": request.ctx.path_params.get("id")}

    url = app.router.url_for("user_detail", id=123)

    assert url == "/users/123"
