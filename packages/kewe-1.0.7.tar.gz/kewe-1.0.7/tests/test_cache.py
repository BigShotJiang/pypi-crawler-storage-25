import pytest
import time
from kewe.cache import MemoryCache, CacheManager, cache, cache_response, memoize


class TestMemoryCache:
    def test_set_and_get(self):
        mc = MemoryCache()
        mc.set("key1", "value1")
        assert mc.get("key1") == "value1"
    
    def test_get_nonexistent(self):
        mc = MemoryCache()
        assert mc.get("nonexistent") is None
    
    def test_delete(self):
        mc = MemoryCache()
        mc.set("key1", "value1")
        mc.delete("key1")
        assert mc.get("key1") is None
    
    def test_exists(self):
        mc = MemoryCache()
        mc.set("key1", "value1")
        assert mc.exists("key1") is True
        assert mc.exists("nonexistent") is False
    
    def test_keys(self):
        mc = MemoryCache()
        mc.set("key1", "value1")
        mc.set("key2", "value2")
        keys = mc.keys()
        assert "key1" in keys
        assert "key2" in keys
    
    def test_ttl_expiry(self):
        mc = MemoryCache()
        mc.set("key1", "value1", ttl=0.1)
        assert mc.get("key1") == "value1"
        time.sleep(0.2)
        assert mc.get("key1") is None
    
    def test_cleanup_expired(self):
        mc = MemoryCache()
        mc.set("key1", "value1", ttl=0.1)
        mc.set("key2", "value2", ttl=10)
        time.sleep(0.2)
        mc.cleanup_expired()
        assert mc.get("key1") is None
        assert mc.get("key2") == "value2"
    
    def test_overwrite(self):
        mc = MemoryCache()
        mc.set("key1", "value1")
        mc.set("key1", "value2")
        assert mc.get("key1") == "value2"
    
    def test_clear(self):
        mc = MemoryCache()
        mc.set("key1", "value1")
        mc.set("key2", "value2")
        mc.clear()
        assert mc.get("key1") is None
        assert mc.get("key2") is None


class TestCacheManager:
    def test_add_backend(self):
        cm = CacheManager()
        mc = MemoryCache()
        cm.add_backend("test_memory", mc)
        backend = cm.get_backend("test_memory")
        assert backend is mc
    
    def test_get_default_backend(self):
        cm = CacheManager()
        backend = cm.get_backend()
        assert backend is not None
    
    def test_set_default_backend(self):
        cm = CacheManager()
        mc = MemoryCache()
        cm.add_backend("custom", mc)
        cm.set_default_backend("custom")
        assert cm.get_backend() is mc
    
    def test_cache_manager_get_set(self):
        cm = CacheManager()
        cm.set("test_key", "test_value")
        assert cm.get("test_key") == "test_value"
    
    def test_cache_manager_delete(self):
        cm = CacheManager()
        cm.set("test_key", "test_value")
        cm.delete("test_key")
        assert cm.get("test_key") is None
    
    def test_cache_manager_exists(self):
        cm = CacheManager()
        cm.set("test_key", "test_value")
        assert cm.exists("test_key") is True
        assert cm.exists("nonexistent") is False


class TestCacheDecorator:
    @pytest.mark.asyncio
    async def test_cache_decorator_hit(self):
        call_count = 0
        
        @cache(ttl=60)
        async def expensive_function(x):
            nonlocal call_count
            call_count += 1
            return x * 2
        
        result1 = await expensive_function(5)
        assert result1 == 10
        assert call_count == 1
    
    @pytest.mark.asyncio
    async def test_cache_decorator_different_args(self):
        call_count = 0
        
        @cache(ttl=60)
        async def func(x):
            nonlocal call_count
            call_count += 1
            return x * 2
        
        result1 = await func(1)
        result2 = await func(2)
        assert result1 == 2
        assert result2 == 4
        assert call_count == 2
    
    @pytest.mark.asyncio
    async def test_cache_decorator_no_cache(self):
        call_count = 0
        
        @cache(ttl=60, no_cache=True)
        async def func(x):
            nonlocal call_count
            call_count += 1
            return x * 2
        
        await func(5)
        await func(5)
        assert call_count == 2


class TestMemoize:
    def test_memoize(self):
        call_count = 0
        
        @memoize(maxsize=128)
        def func(x):
            nonlocal call_count
            call_count += 1
            return x * 2
        
        result1 = func(5)
        result2 = func(5)
        assert result1 == 10
        assert result2 == 10
        assert call_count == 1
    
    def test_memoize_different_args(self):
        call_count = 0
        
        @memoize(maxsize=128)
        def func(x):
            nonlocal call_count
            call_count += 1
            return x * 2
        
        func(1)
        func(2)
        assert call_count == 2
    
    def test_memoize_maxsize(self):
        @memoize(maxsize=2)
        def func(x):
            return x * 2
        
        func(1)
        func(2)
        func(3)
        assert func.cache_info()["maxsize"] == 2
    
    def test_memoize_cache_clear(self):
        @memoize(maxsize=128)
        def func(x):
            return x * 2
        
        func(1)
        func.cache_clear()
        assert func.cache_info()["currsize"] == 0
