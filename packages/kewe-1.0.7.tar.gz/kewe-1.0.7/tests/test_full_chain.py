import asyncio
import json
import time
import threading
import pytest
from kewe.app import Kewe, KeweConfig
from kewe.response import json as json_resp, text as text_resp, Response
from kewe.errors.exceptions import (
    NotFound, Unauthorized, Forbidden, BadRequest,
    TooManyRequests, PayloadTooLarge, KeweException
)
from kewe.security.rbac_manager import RBACManager
from kewe.cookies.session import Session
from kewe.cache import memoize, cache, MemoryCache, cache_manager
from kewe.application.di import Container, Lifetime, Scope
from kewe.application.depends import Depends, DependencyResolver


def _create_app():
    config = KeweConfig(secret_key="test-secret-key-for-e2e", enable_gateway=False)
    app = Kewe("e2e_test", config=config)
    return app


class TestFullChainLogin:
    def test_login_jwt_rbac_flow(self):
        app = _create_app()
        rbac = RBACManager()
        rbac.add_permission_to_role("admin", "manage_users")
        rbac.assign_role_to_user("user1", "admin")

        @app.post("/api/login")
        async def login(request):
            body = await request.json
            if body is None:
                body = {}
            username = body.get("username", "")
            password = body.get("password", "")
            if username == "admin" and password == "secret":
                return json_resp({"token": "jwt-token-admin", "user_id": "user1"})
            return json_resp({"error": "Invalid credentials"}, status=401)

        @app.get("/api/profile")
        async def profile(request):
            auth = request.headers.get("authorization", "")
            if not auth:
                raise Unauthorized("Missing token")
            if auth != "Bearer jwt-token-admin":
                raise Forbidden("Invalid token")
            return json_resp({"user_id": "user1", "role": "admin"})

        @app.get("/api/admin/users")
        async def admin_users(request):
            auth = request.headers.get("authorization", "")
            if auth != "Bearer jwt-token-admin":
                raise Forbidden("Not admin")
            user_id = "user1"
            if not rbac.has_permission(user_id, "manage_users"):
                raise Forbidden("No permission")
            return json_resp({"users": ["user1", "user2"]})

        client = app.test_client

        resp = client.post("/api/login",
                           json={"username": "admin", "password": "secret"})
        assert resp.status == 200
        data = json.loads(resp.body)
        assert data["token"] == "jwt-token-admin"
        token = data["token"]

        resp = client.get("/api/profile",
                          headers={"authorization": f"Bearer {token}"})
        assert resp.status == 200
        profile = json.loads(resp.body)
        assert profile["role"] == "admin"

        resp = client.get("/api/admin/users",
                          headers={"authorization": f"Bearer {token}"})
        assert resp.status == 200

        resp = client.get("/api/admin/users",
                          headers={"authorization": "Bearer bad-token"})
        assert resp.status == 403

        resp = client.get("/api/profile")
        assert resp.status == 401


class TestCRUDOperations:
    def test_full_crud_flow(self):
        app = _create_app()
        items = {}

        @app.get("/api/items")
        async def list_items(request):
            return json_resp(list(items.values()))

        @app.post("/api/items")
        async def create_item(request):
            body = await request.json
            if body is None:
                raise BadRequest("Invalid JSON")
            item_id = str(len(items) + 1)
            body["id"] = item_id
            items[item_id] = body
            return json_resp(body, status=201)

        @app.get("/api/items/<item_id:str>")
        async def get_item(request):
            item_id = request.ctx.path_params.get("item_id")
            if item_id not in items:
                raise NotFound(f"Item {item_id} not found")
            return json_resp(items[item_id])

        @app.put("/api/items/<item_id:str>")
        async def update_item(request):
            item_id = request.ctx.path_params.get("item_id")
            if item_id not in items:
                raise NotFound(f"Item {item_id} not found")
            body = await request.json
            if body is None:
                raise BadRequest("Invalid JSON")
            body["id"] = item_id
            items[item_id] = body
            return json_resp(body)

        @app.delete("/api/items/<item_id:str>")
        async def delete_item(request):
            item_id = request.ctx.path_params.get("item_id")
            if item_id not in items:
                raise NotFound(f"Item {item_id} not found")
            del items[item_id]
            return json_resp({"deleted": True})

        client = app.test_client

        resp = client.get("/api/items")
        assert resp.status == 200
        assert json.loads(resp.body) == []

        resp = client.post("/api/items",
                           json={"name": "Widget", "price": 9.99})
        assert resp.status == 201
        item = json.loads(resp.body)
        assert item["name"] == "Widget"
        item_id = item["id"]

        resp = client.get(f"/api/items/{item_id}")
        assert resp.status == 200

        resp = client.put(f"/api/items/{item_id}",
                          json={"name": "Widget Pro", "price": 19.99})
        assert resp.status == 200
        assert json.loads(resp.body)["name"] == "Widget Pro"

        resp = client.delete(f"/api/items/{item_id}")
        assert resp.status == 200

        resp = client.get(f"/api/items/{item_id}")
        assert resp.status == 404


class TestSessionFlow:
    def test_session_login_logout(self):
        app = _create_app()
        sessions = {}

        @app.post("/api/session/login")
        async def session_login(request):
            body = await request.json or {}
            username = body.get("username", "")
            session_id = "sess_" + username
            sessions[session_id] = {"user": username, "logged_in": True}
            resp = json_resp({"session_id": session_id})
            resp.set_cookie("sid", session_id, httponly=True)
            return resp

        @app.get("/api/session/me")
        async def session_me(request):
            sid = request.get_cookie("sid")
            if not sid or sid not in sessions:
                raise Unauthorized("Not logged in")
            return json_resp(sessions[sid])

        @app.post("/api/session/logout")
        async def session_logout(request):
            sid = request.get_cookie("sid")
            if sid and sid in sessions:
                del sessions[sid]
            resp = json_resp({"logged_out": True})
            resp.delete_cookie("sid")
            return resp

        client = app.test_client

        resp = client.post("/api/session/login",
                           json={"username": "testuser"})
        assert resp.status == 200

        resp = client.get("/api/session/me",
                          headers={"cookie": "sid=sess_testuser"})
        assert resp.status == 200

        client.cookies.clear()
        resp = client.get("/api/session/me")
        assert resp.status == 401


class TestErrorHandling:
    def test_exception_hierarchy(self):
        app = _create_app()

        @app.get("/api/bad")
        async def bad_request(request):
            raise BadRequest("Bad input")

        @app.get("/api/unauth")
        async def unauth(request):
            raise Unauthorized("Need auth")

        @app.get("/api/forbidden")
        async def forbidden(request):
            raise Forbidden("No access")

        @app.get("/api/notfound")
        async def notfound(request):
            raise NotFound("Gone")

        @app.get("/api/ratelimit")
        async def ratelimit(request):
            raise TooManyRequests("Slow down")

        @app.get("/api/payload")
        async def payload(request):
            raise PayloadTooLarge("Too big")

        client = app.test_client

        assert client.get("/api/bad").status == 400
        assert client.get("/api/unauth").status == 401
        assert client.get("/api/forbidden").status == 403
        assert client.get("/api/notfound").status == 404
        assert client.get("/api/ratelimit").status == 429
        assert client.get("/api/payload").status == 413

    def test_unhandled_exception_returns_500(self):
        app = _create_app()

        @app.get("/api/crash")
        async def crash(request):
            raise RuntimeError("Unexpected error")

        client = app.test_client
        resp = client.get("/api/crash")
        assert resp.status == 500


class TestDependencyInjection:
    def test_di_container_full_flow(self):
        container = Container()

        class IUserService:
            pass

        class UserService(IUserService):
            def __init__(self):
                self.body = {"users": ["a", "b"]}

        container.register(IUserService, UserService, lifetime=Lifetime.SINGLETON)
        svc1 = container.resolve(IUserService)
        svc2 = container.resolve(IUserService)
        assert svc1 is svc2
        assert svc1.body == {"users": ["a", "b"]}

    def test_di_scoped_lifetime(self):
        container = Container()

        class IRepo:
            pass

        class Repo(IRepo):
            pass

        container.register(IRepo, Repo, lifetime=Lifetime.SCOPED)

        with Scope(container, scope_id=100) as scope:
            r1 = container.resolve(IRepo)
            r2 = container.resolve(IRepo)
            assert r1 is r2

    def test_di_async_resolve(self):
        container = Container()

        class IService:
            pass

        class Service(IService):
            pass

        container.register(IService, Service, lifetime=Lifetime.TRANSIENT)

        async def _test():
            s = await container.aresolve(IService)
            assert isinstance(s, Service)

        asyncio.run(_test())


class TestCacheSystem:
    def test_memoize_basic(self):
        call_count = 0

        @memoize(maxsize=10)
        def compute(n):
            nonlocal call_count
            call_count += 1
            return n * n

        assert compute(5) == 25
        assert compute(5) == 25
        assert call_count == 1
        assert compute(3) == 9
        assert call_count == 2

    def test_cache_decorator(self):
        call_count = 0

        @cache(ttl=60)
        async def fetch_data(key):
            nonlocal call_count
            call_count += 1
            return {"key": key, "value": f"data_{key}"}

        async def _test():
            r1 = await fetch_data("a")
            assert r1["value"] == "data_a"
            assert call_count == 1
            r2 = await fetch_data("a")
            assert call_count == 1

        asyncio.run(_test())

    def test_memory_cache_ttl(self):
        mc = MemoryCache()
        mc.set("key1", "value1", ttl=1)
        assert mc.get("key1") == "value1"
        time.sleep(1.1)
        assert mc.get("key1") is None


class TestMiddlewareChain:
    def test_middleware_execution_order(self):
        app = _create_app()
        order = []

        @app.middleware("request")
        async def mw1(request):
            order.append("mw1_before")

        @app.middleware("request")
        async def mw2(request):
            order.append("mw2_before")

        @app.get("/api/test")
        async def handler(request):
            order.append("handler")
            return json_resp({"ok": True})

        client = app.test_client
        resp = client.get("/api/test")
        assert resp.status == 200
        assert "mw1_before" in order
        assert "mw2_before" in order
        assert "handler" in order


class TestConcurrentRequests:
    def test_concurrent_di_resolution(self):
        container = Container()

        class IService:
            pass

        class Service(IService):
            pass

        container.register(IService, Service, lifetime=Lifetime.SINGLETON)

        results = []
        errors = []

        def resolve_in_thread():
            try:
                svc = container.resolve(IService)
                results.append(id(svc))
            except Exception as e:
                errors.append(str(e))

        threads = [threading.Thread(target=resolve_in_thread) for _ in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert len(errors) == 0, f"Errors in concurrent DI: {errors}"
        assert len(set(results)) == 1, "Singleton should return same instance"

    def test_concurrent_cache_access(self):
        mc = MemoryCache()
        errors = []

        def cache_ops(thread_id):
            try:
                for i in range(50):
                    key = f"key_{thread_id}_{i}"
                    mc.set(key, f"value_{thread_id}_{i}")
                    val = mc.get(key)
                    assert val == f"value_{thread_id}_{i}", f"Cache mismatch: {val}"
            except Exception as e:
                errors.append(str(e))

        threads = [threading.Thread(target=cache_ops, args=(tid,)) for tid in range(5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert len(errors) == 0, f"Cache concurrency errors: {errors}"

    def test_concurrent_rbac_operations(self):
        rbac = RBACManager()
        errors = []

        def rbac_ops(thread_id):
            try:
                role = f"role_{thread_id}"
                rbac.add_permission_to_role(role, f"perm_{thread_id}")
                rbac.assign_role_to_user(f"user_{thread_id}", role)
                assert rbac.has_permission(f"user_{thread_id}", f"perm_{thread_id}")
            except Exception as e:
                errors.append(str(e))

        threads = [threading.Thread(target=rbac_ops, args=(tid,)) for tid in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert len(errors) == 0, f"RBAC concurrency errors: {errors}"

    def test_concurrent_session_operations(self):
        sessions = {}
        lock = threading.Lock()
        errors = []

        def session_ops(thread_id):
            try:
                sid = f"sess_{thread_id}"
                with lock:
                    sessions[sid] = {"user": f"user_{thread_id}"}
                s = Session()
                s["data"] = f"value_{thread_id}"
                assert s["data"] == f"value_{thread_id}"
                s.regenerate_id()
                assert s.modified is True
            except Exception as e:
                errors.append(str(e))

        threads = [threading.Thread(target=session_ops, args=(tid,)) for tid in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert len(errors) == 0, f"Session concurrency errors: {errors}"


class TestStressOperations:
    def test_route_lookup_stress(self):
        app = _create_app()

        for i in range(100):
            exec(f"""
@app.get("/api/resource{i}")
async def handler_{i}(request):
    return json_resp({{"id": {i}}})
""", {"app": app, "json_resp": json_resp})

        client = app.test_client
        for i in range(100):
            resp = client.get(f"/api/resource{i}")
            assert resp.status == 200, f"Failed for /api/resource{i}"

    def test_cache_stress(self):
        mc = MemoryCache()

        for i in range(1000):
            mc.set(f"key_{i}", f"value_{i}", ttl=60)

        for i in range(1000):
            val = mc.get(f"key_{i}")
            assert val == f"value_{i}", f"Cache miss for key_{i}"

        mc.clear()
        assert mc.get("key_0") is None

    def test_di_stress_resolve(self):
        container = Container()

        class IService:
            pass

        class Service(IService):
            pass

        container.register(IService, Service, lifetime=Lifetime.TRANSIENT)

        for _ in range(500):
            svc = container.resolve(IService)
            assert isinstance(svc, Service)

    def test_memoize_eviction(self):
        @memoize(maxsize=5)
        def compute(n):
            return n * n

        for i in range(20):
            compute(i)

        info = compute.cache_info()
        assert info["currsize"] <= 5


class TestResponseTypes:
    def test_json_response(self):
        app = _create_app()

        @app.get("/json")
        async def h(request):
            return json_resp({"key": "value"})

        resp = app.test_client.get("/json")
        assert resp.status == 200
        data = json.loads(resp.body)
        assert data["key"] == "value"

    def test_text_response(self):
        app = _create_app()

        @app.get("/text")
        async def h(request):
            return text_resp("hello world")

        resp = app.test_client.get("/text")
        assert resp.status == 200
        assert b"hello world" in resp.body

    def test_response_body_type_safety(self):
        from kewe.response import Response
        r = Response(body="hello")
        assert r.body == b"hello"
        r = Response(body=b"bytes")
        assert r.body == b"bytes"

        r_int = Response(body=12345)
        assert r_int.body == b"12345"

        r_float = Response(body=3.14)
        assert r_float.body is not None

        r_bool = Response(body=True)
        assert r_bool.body == b"true"

        r = Response(body=None)
        assert r.body == b""

    def test_response_set_body_type_safety(self):
        from kewe.response import Response
        r = Response(body="initial")
        r.body = "updated"
        assert r.body == b"updated"

        r.body = {"key": "value"}
        assert b"key" in r.body


class TestTokenPayloadExtra:
    def test_token_payload_from_dict(self):
        from kewe.security.jwt import TokenPayload
        payload = TokenPayload.from_dict({
            'sub': 'user1', 'jti': 'abc', 'iat': 1000, 'exp': 2000,
            'nbf': 1000, 'type': 'access', 'iss': 'kewe', 'aud': 'app', 'sid': 's1',
            'name': 'John', 'email': 'john@test.com', 'roles': ['admin']
        })
        assert payload.sub == 'user1'
        assert payload.extra.get('name') == 'John'
        assert payload.extra.get('roles') == ['admin']

    def test_token_payload_to_dict_includes_extra(self):
        from kewe.security.jwt import TokenPayload
        payload = TokenPayload.from_dict({
            'sub': 'user1', 'jti': 'abc', 'iat': 1000, 'exp': 2000,
            'nbf': 1000, 'type': 'access', 'iss': 'kewe', 'aud': 'app', 'sid': 's1',
            'custom': 'field'
        })
        d = payload.to_dict()
        assert d['custom'] == 'field'
        assert 'extra' not in d
