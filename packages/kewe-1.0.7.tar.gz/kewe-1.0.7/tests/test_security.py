#!/usr/bin/env python
"安全性测"""

import pytest
from kewe import Kewe
from kewe.response import json
from kewe.utils.testing import TestClient
from kewe.logging.access import AccessLogger, SENSITIVE_FIELDS, SENSITIVE_HEADERS


class TestLogMasking:
    "日志脱敏测试"""
    
    def test_mask_sensitive_value(self):
        "测试敏感值脱"""
        masked = AccessLogger.mask_value("secret_password_123")
        assert "secret" not in masked or "*" in masked
        assert len(masked) > 0
    
    def test_mask_short_value(self):
        "测试短值脱"""
        masked = AccessLogger.mask_value("ab")
        assert masked == "**"
    
    def test_mask_empty_value(self):
        "测试空值脱"""
        masked = AccessLogger.mask_value("")
        assert masked == ""
    
    def test_mask_sensitive_data_bearer(self):
        "测试Bearer token脱敏"""
        data = "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9"
        masked = AccessLogger.mask_sensitive_data(data)
        assert "Bearer" in masked
        assert "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9" not in masked
    
    def test_mask_sensitive_data_basic(self):
        "测试Basic auth脱敏"""
        data = "Authorization: Basic dXNlcjpwYXNzd29yZA=="
        masked = AccessLogger.mask_sensitive_data(data)
        assert "Basic" in masked
        assert "dXNlcjpwYXNzd29yZA==" not in masked
    
    def test_mask_query_string_password(self):
        "测试查询字符串密码脱"""
        query = "username=admin&password=secret123&token=abc123"
        masked = AccessLogger.mask_query_string(query)
        assert "username=admin" in masked
        assert "secret123" not in masked
        assert "abc123" not in masked
    
    def test_mask_query_string_token(self):
        "测试查询字符串token脱敏"""
        query = "access_token=eyJhbGciOiJIUzI1NiJ9&refresh_token=xyz789"
        masked = AccessLogger.mask_query_string(query)
        assert "eyJhbGciOiJIUzI1NiJ9" not in masked
        assert "xyz789" not in masked
    
    def test_mask_headers_authorization(self):
        "测试请求头Authorization脱敏"""
        headers = {
            "Authorization": "Bearer secret_token",
            "Content-Type": "application/json"
        }
        masked = AccessLogger.mask_headers(headers)
        assert masked["Content-Type"] == "application/json"
        assert "secret_token" not in masked["Authorization"]
    
    def test_mask_headers_cookie(self):
        "测试请求头Cookie脱敏"""
        headers = {
            "Cookie": "session=abc123; token=xyz789",
            "User-Agent": "Test"
        }
        masked = AccessLogger.mask_headers(headers)
        assert masked["User-Agent"] == "Test"
        assert "abc123" not in masked["Cookie"]
    
    def test_sensitive_fields_coverage(self):
        "测试敏感字段覆盖"""
        assert "password" in SENSITIVE_FIELDS
        assert "token" in SENSITIVE_FIELDS
        assert "api_key" in SENSITIVE_FIELDS
        assert "secret" in SENSITIVE_FIELDS
        assert "credit_card" in SENSITIVE_FIELDS
    
    def test_sensitive_headers_coverage(self):
        "测试敏感请求头覆"""
        assert "authorization" in SENSITIVE_HEADERS
        assert "cookie" in SENSITIVE_HEADERS
        assert "x-api-key" in SENSITIVE_HEADERS


class TestSecurityHeaders:
    "安全头测"""
    
    def test_default_security_headers(self):
        "测试默认安全"""
        from kewe.middleware import SecurityHeadersMiddleware
        
        middleware = SecurityHeadersMiddleware()
        
        assert middleware.x_content_type_options == "nosniff"
        assert middleware.x_frame_options == "DENY"
        assert middleware.x_xss_protection == "0"
        assert middleware.referrer_policy == "strict-origin-when-cross-origin"
        assert middleware.cross_origin_opener_policy == "same-origin"
        assert middleware.cross_origin_resource_policy == "same-origin"
    
    def test_csp_header(self):
        "测试CSP"""
        from kewe.middleware import SecurityHeadersMiddleware
        
        csp = "default-src 'self'; script-src 'self' 'unsafe-inline'"
        middleware = SecurityHeadersMiddleware(content_security_policy=csp)
        
        assert middleware.content_security_policy == csp
    
    def test_hsts_header(self):
        "测试HSTS"""
        from kewe.middleware import SecurityHeadersMiddleware
        
        hsts = "max-age=31536000; includeSubDomains; preload"
        middleware = SecurityHeadersMiddleware(strict_transport_security=hsts)
        
        assert middleware._hsts_value == hsts
    
    def test_hsts_auto_build(self):
        "测试HSTS自动构建"""
        from kewe.middleware import SecurityHeadersMiddleware
        
        middleware = SecurityHeadersMiddleware(
            hsts_max_age=63072000,
            hsts_include_subdomains=True,
            hsts_preload=True
        )
        
        assert "max-age=63072000" in middleware._hsts_value
        assert "includeSubDomains" in middleware._hsts_value
        assert "preload" in middleware._hsts_value


class TestCookieSecurityDefaults:
    "Cookie安全默认值测"""
    
    def test_cookie_secure_default(self):
        from kewe.response.response import ResponseCookie as Cookie
        
        cookie = Cookie(name="test", value="value")
        assert cookie.secure is False
    
    def test_cookie_httponly_default(self):
        from kewe.response.response import ResponseCookie as Cookie
        
        cookie = Cookie(name="test", value="value")
        assert cookie.httponly is False
    
    def test_cookie_samesite_default(self):
        from kewe.response.response import ResponseCookie as Cookie
        
        cookie = Cookie(name="test", value="value")
        assert cookie.samesite == "Lax"
    
    def test_cookie_to_header_includes_security(self):
        from kewe.response.response import ResponseCookie as Cookie
        
        cookie = Cookie(name="session", value="abc123", secure=True, httponly=True)
        header = cookie.to_header()
        
        assert "Secure" in header
        assert "HttpOnly" in header
        assert "SameSite=Lax" in header


class TestInputValidation:
    "输入验证安全测试"""
    
    def test_sql_injection_prevention(self):
        "测试SQL注入防护"""
        from kewe.application.depends import validate, Field, FieldType
        
        app = Kewe("test-sqli")
        
        @app.post("/search")
        @validate(json=[
            Field("query", FieldType.STRING, max_length=100)
        ])
        async def search(request, validated_data):
            query = validated_data.get('json', {}).get('query', '')
            return json({"query": query})
        
        client = TestClient(app)
        
        response = client.post("/search", json={
            "query": "'; DROP TABLE users; --"
        })
        
        assert response.status == 200
        assert "DROP TABLE" in response.json.get("query", "")
    
    def test_xss_prevention(self):
        "测试XSS防护"""
        app = Kewe("test-xss")
        
        @app.post("/comment")
        async def comment(request):
            return json({"comment": "received"})
        
        client = TestClient(app)
        
        response = client.post("/comment", json={
            "comment": "<script>alert('xss')</script>"
        })
        
        assert response.status == 200
    
    def test_path_traversal_prevention(self):
        "测试路径遍历防护"""
        from kewe.application.depends import validate, Field, FieldType
        
        app = Kewe("test-path")
        
        @app.get("/files/<filename:str>")
        async def get_file(request):
            filename = request.ctx.path_params.get("filename", "")
            if ".." in filename or "/" in filename:
                return json({"error": "Invalid path"}, status=400)
            return json({"filename": filename})
        
        client = TestClient(app)
        
        response = client.get("/files/../../../etc/passwd")
        assert response.status in [400, 404]


class TestRateLimiting:
    "速率限制测试"""
    
    def test_rate_limit_config(self):
        "测试速率限制配置"""
        from kewe.middleware import MiddlewarePriority
        
        assert MiddlewarePriority.HIGHEST.value == 0
        assert MiddlewarePriority.NORMAL.value == 50
        assert MiddlewarePriority.LOWEST.value == 100


class TestCSRFProtection:
    "CSRF防护测试"""
    
    def test_csrf_token_generation(self):
        "测试CSRF token生成"""
        import secrets
        token = secrets.token_urlsafe(32)
        
        assert token is not None
        assert len(token) > 0
    
    def test_csrf_token_validation(self):
        "测试CSRF token验证"""
        import secrets
        token = secrets.token_urlsafe(32)
        
        assert len(token) > 0
        assert token != "invalid_token"
