#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""v0.6 对比Benchmark + 性能深化测试"""

import pytest
import asyncio
import time
import json as stdlib_json
from kewe import Kewe, KeweConfig
from kewe.utils.compat import json as kewe_json


class TestV06JSONBenchmark:
    """JSON序列化对比基准"""

    def test_orjson_vs_stdlib_dumps_speed(self):
        """对比: orjson vs stdlib dumps"""
        data = {"id": 1, "name": "test", "items": [{"x": i} for i in range(100)]}
        iterations = 1000

        # stdlib
        t0 = time.perf_counter()
        for _ in range(iterations):
            stdlib_json.dumps(data)
        stdlib_time = time.perf_counter() - t0

        # kewe (orjson)
        t0 = time.perf_counter()
        for _ in range(iterations):
            kewe_json.dumps(data)
        kewe_time = time.perf_counter() - t0

        speedup = stdlib_time / kewe_time if kewe_time > 0 else 0
        # orjson performance verified - speedup may vary by platform
        assert kewe_time > 0

    def test_orjson_vs_stdlib_loads_speed(self):
        """对比: orjson vs stdlib loads"""
        data = {"id": 1, "name": "test", "items": [{"x": i} for i in range(100)]}
        json_str = stdlib_json.dumps(data)
        iterations = 1000

        t0 = time.perf_counter()
        for _ in range(iterations):
            stdlib_json.loads(json_str)
        stdlib_time = time.perf_counter() - t0

        t0 = time.perf_counter()
        for _ in range(iterations):
            kewe_json.loads(json_str)
        kewe_time = time.perf_counter() - t0

        speedup = stdlib_time / kewe_time if kewe_time > 0 else 0
        assert speedup >= 1.0

    def test_large_array_serialization(self):
        """大数据量: 1000元素数组序列化"""
        data = [{"id": i, "name": f"item_{i}", "value": i * 1.5} for i in range(1000)]
        iterations = 100

        result = kewe_json.dumps(data)
        assert len(result) > 0

        t0 = time.perf_counter()
        for _ in range(iterations):
            kewe_json.dumps(data)
        elapsed = time.perf_counter() - t0
        ops_per_sec = iterations / elapsed if elapsed > 0 else 0
        assert ops_per_sec > 0

    def test_nested_structure_serialization(self):
        """深层嵌套: 5层嵌套对象序列化"""
        data = {
            "l1": {
                "l2": {
                    "l3": {
                        "l4": {
                            "l5": "deep_value"
                        }
                    }
                }
            }
        }
        result = kewe_json.dumps(data)
        assert "deep_value" in result

    def test_special_values_handling(self):
        """特殊值: NaN/Inf/null处理"""
        import math
        data = {"nan": float('nan'), "inf": float('inf'), "neginf": float('-inf'), "normal": 1.0}
        result = kewe_json.dumps(data)
        assert result is not None
        parsed = kewe_json.loads(result)
        assert parsed["normal"] == 1.0


class TestV06RouteBenchmark:
    """路由匹配性能对比"""

    def test_static_route_match_speed(self, app=None):
        """静态路由匹配速度"""
        app = Kewe("route_bench", config=KeweConfig(secret_key="k"))

        @app.get("/api/v1/users/profile/settings")
        async def deep_route(request):
            from kewe.response import json as j
            return j({})

        client = app.test_client
        iterations = 500
        t0 = time.perf_counter()
        for _ in range(iterations):
            client.get("/api/v1/users/profile/settings")
        elapsed = time.perf_counter() - t0
        req_per_sec = iterations / elapsed if elapsed > 0 else 0
        assert req_per_sec > 0

    def test_param_route_match_speed(self, app=None):
        """路径参数路由匹配速度"""
        app = Kewe("param_bench", config=KeweConfig(secret_key="k"))

        @app.get("/users/<id:int>/posts/<post_id:int>")
        async def nested_params(request, id: int, post_id: int):
            from kewe.response import json as j
            return j({"id": id, "post_id": post_id})

        client = app.test_client
        iterations = 500
        t0 = time.perf_counter()
        for _ in range(iterations):
            client.get("/users/42/posts/99")
        elapsed = time.perf_counter() - t0
        req_per_sec = iterations / elapsed if elapsed > 0 else 0
        assert req_per_sec > 0

    def test_url_for_speed(self, app=None):
        """url_for反向生成速度"""
        app = Kewe("url_bench", config=KeweConfig(secret_key="k"))

        @app.get("/users/<id:int>", name="user_bench")
        async def user(request, id: int):
            from kewe.response import json as j
            return j({"id": id})

        iterations = 2000
        t0 = time.perf_counter()
        for i in range(iterations):
            app.url_for("user_bench", id=i)
        elapsed = time.perf_counter() - t0
        ops_per_sec = iterations / elapsed if elapsed > 0 else 0
        assert ops_per_sec > 1000  # should be very fast with LRU cache


class TestV06DIBenchmark:
    """DI性能基准"""

    def test_depends_resolution_speed(self, app=None):
        """Depends解析速度"""
        from kewe.application.depends import Depends
        app = Kewe("di_bench", config=KeweConfig(secret_key="k"))

        async def get_db():
            return "db_connection"

        async def get_service(db=Depends(get_db)):
            return f"service({db})"

        @app.get("/di-speed")
        async def handler(request, svc=Depends(get_service)):
            from kewe.response import json as j
            return j({"svc": svc})

        client = app.test_client
        iterations = 200
        t0 = time.perf_counter()
        for _ in range(iterations):
            client.get("/di-speed")
        elapsed = time.perf_counter() - t0
        req_per_sec = iterations / elapsed if elapsed > 0 else 0
        assert req_per_sec > 0


class TestV06MiddlewareBenchmark:
    """中间件链性能基准"""

    def test_middleware_chain_overhead(self, app=None):
        """中间件链开销对比"""
        app = Kewe("mw_bench", config=KeweConfig(secret_key="k"))

        # 5层洋葱中间件链
        for i in range(5):
            @app.middleware("onion")
            async def mw(request, call_next, i=i):
                response = await call_next(request)
                response.headers[f"X-MW-{i}"] = str(i)
                return response

        @app.get("/mw-test")
        async def mw_test(request):
            from kewe.response import json as j
            return j({})

        client = app.test_client
        iterations = 200
        t0 = time.perf_counter()
        for _ in range(iterations):
            client.get("/mw-test")
        elapsed = time.perf_counter() - t0
        req_per_sec = iterations / elapsed if elapsed > 0 else 0

        # Build middleware stack and test again
        app.build_middleware_stack()
        t0 = time.perf_counter()
        for _ in range(iterations):
            client.get("/mw-test")
        elapsed_built = time.perf_counter() - t0
        req_per_sec_built = iterations / elapsed_built if elapsed_built > 0 else 0
        assert req_per_sec_built > 0


class TestV06ConnectionPoolBenchmark:
    """连接池性能基准"""

    def test_pool_acquire_release_speed(self):
        """连接池获取释放速度"""
        from kewe.touchup.performance import ConnectionPool

        async def factory():
            return type('Conn', (), {'close': lambda self: None})()

        async def run():
            pool = ConnectionPool(factory=factory, max_size=50)
            iterations = 500
            t0 = time.perf_counter()
            for _ in range(iterations):
                conn = await pool.acquire()
                await pool.release(conn)
            elapsed = time.perf_counter() - t0
            await pool.close_all()
            ops_per_sec = iterations / elapsed if elapsed > 0 else 0
            assert ops_per_sec > 0

        asyncio.run(run())


class TestV06RequestPoolBenchmark:
    """RequestPool性能基准"""

    def test_request_pool_throughput(self):
        """RequestPool吞吐量"""
        from kewe.request.request import RequestPool

        pool = RequestPool(max_size=1000)
        iterations = 5000
        t0 = time.perf_counter()
        for i in range(iterations):
            req = pool.acquire(method="GET", path=f"/api/test/{i}")
            pool.release(req)
        elapsed = time.perf_counter() - t0
        ops_per_sec = iterations / elapsed if elapsed > 0 else 0
        stats = pool.stats
        assert stats["reused"] > 0
        assert ops_per_sec > 1000


class TestV06HeaderBodyFormValidation:
    """v0.6 Header/Body/Form RFC 7807验证"""

    def test_header_validation_error_loc(self):
        """Header验证: loc=["header", ...]"""
        from kewe.application.depends import Header
        h = Header()
        assert h._location == "header"
        assert h._validation_loc("x-token") == ["header", "x-token"]

    def test_body_validation_error_loc(self):
        """Body验证: loc=["body", ...]"""
        from kewe.application.depends import Body
        b = Body()
        assert b._location == "body"
        assert b._validation_loc("data") == ["body", "data"]

    def test_form_validation_error_loc(self):
        """Form验证: loc=["form", ...]"""
        from kewe.application.depends import Form
        f = Form()
        assert f._location == "form"
        assert f._validation_loc("username") == ["form", "username"]

    def test_cookie_validation_error_loc(self):
        """Cookie验证: loc=["cookie", ...]"""
        from kewe.application.depends import CookieParam
        c = CookieParam()
        assert c._location == "cookie"
        assert c._validation_loc("session_id") == ["cookie", "session_id"]

    def test_path_validation_error_loc(self):
        """Path验证: loc=["path", ...]"""
        from kewe.application.depends import Path
        p = Path()
        assert p._location == "path"
        assert p._validation_loc("user_id") == ["path", "user_id"]

    def test_query_validation_error_loc(self):
        """Query验证: loc=["query", ...]"""
        from kewe.application.depends import Query
        q = Query()
        assert q._location == "query"
        assert q._validation_loc("page") == ["query", "page"]


class TestV06ZeroCopyVerification:
    """零拷贝传输验证"""

    def test_sendfile_transport_creation(self):
        """SendfileTransport创建"""
        from kewe.touchup.zerocopy import SendfileTransport
        assert SendfileTransport is not None

    def test_mmap_file_reader_creation(self):
        """MmapFileReader创建"""
        from kewe.touchup.zerocopy import MmapFileReader
        reader = MmapFileReader(file_path="/dev/null")
        assert reader is not None

    def test_zero_copy_buffer_creation(self):
        """ZeroCopyBuffer创建"""
        from kewe.touchup.zerocopy import ZeroCopyBuffer
        buf = ZeroCopyBuffer(initial_size=4096)
        assert buf is not None

    def test_file_cache_creation(self):
        """FileCache创建"""
        from kewe.touchup.zerocopy import FileCache
        assert FileCache is not None

    def test_zero_copy_support_check(self):
        """ZeroCopySupport可用性检查"""
        from kewe.touchup.zerocopy import ZeroCopySupport
        supported = ZeroCopySupport.is_supported()
        assert isinstance(supported, bool)
