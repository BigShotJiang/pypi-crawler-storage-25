#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""最终覆盖测试 — 补齐关键模块覆盖率"""

import pytest
import asyncio
import time
from kewe import Kewe, KeweConfig


@pytest.fixture
def app():
    return Kewe("final_test", config=KeweConfig(secret_key="final-key"))


class TestFinalExceptionMatrix:
    """异常矩阵 — 全部HTTP异常端到端验证"""

    def test_all_exceptions_via_app(self, app):
        from kewe.errors.exceptions import (
            BadRequest, Forbidden, NotFound, MethodNotAllowed, Conflict,
            Gone, TooManyRequests, UnprocessableEntity, InternalServerError,
            BadGateway, ServiceUnavailable, GatewayTimeout
        )
        from kewe.response import json as j

        cases = [
            (BadRequest, 400, "/bad-req"),
            (Forbidden, 403, "/forbidden"),
            (NotFound, 404, "/not-found"),
            (MethodNotAllowed, 405, "/method-na"),
            (Conflict, 409, "/conflict"),
            (Gone, 410, "/gone"),
            (TooManyRequests, 429, "/rate-lim"),
            (UnprocessableEntity, 422, "/unproc"),
            (InternalServerError, 500, "/ise"),
            (BadGateway, 502, "/bad-gw"),
            (ServiceUnavailable, 503, "/svc-unav"),
            (GatewayTimeout, 504, "/gw-timeout"),
        ]
        for exc_class, expected_status, path in cases:
            @app.get(path)
            async def handler(request):
                raise exc_class()
            client = app.test_client
            resp = client.get(path)
            assert resp.status == expected_status, f"{exc_class.__name__}: {resp.status} != {expected_status}"


class TestFinalDI:
    """DI深度验证"""

    def test_depends_single_level(self, app):
        from kewe.application.depends import Depends
        from kewe.response import json as j

        async def get_config():
            return {"env": "test"}

        @app.get("/di-single")
        async def handler(req, cfg=Depends(get_config)):
            return j(cfg)

        client = app.test_client
        resp = client.get("/di-single")
        assert resp.status == 200
        assert resp.json["env"] == "test"

    def test_depends_override(self, app):
        from kewe.application.depends import Depends
        from kewe.response import json as j

        async def real_db():
            return "production_db"

        async def mock_db():
            return "mock_db"

        @app.get("/db-data")
        async def db_data(request, db=Depends(real_db)):
            return j({"db": db})

        app.dependency_overrides[real_db] = mock_db
        client = app.test_client
        resp = client.get("/db-data")
        assert resp.status == 200
        assert resp.json["db"] == "mock_db"


class TestFinalGateway:
    """网关深度验证"""

    def test_gateway_full_flow(self, app):
        from kewe.gateway.core import APIGateway, GatewayRoute
        from kewe.response import json as j

        gw = APIGateway()
        gw.bind_app(app, prefix="/api")

        async def get_users(request):
            return j({"users": [{"id": 1}]})

        route = GatewayRoute(
            path="/users",
            method="GET",
            handler=get_users,
            version="v1",
            require_auth=False,
        )
        gw.register_route(route)

        client = app.test_client
        resp = client.get("/api/users")
        assert resp.status == 200

    def test_gateway_require_auth(self, app):
        from kewe.gateway.core import APIGateway, GatewayRoute
        from kewe.response import json as j

        gw = APIGateway()
        gw.bind_app(app, prefix="/secure")

        async def secure_data(request):
            return j({"secret": "data"})

        route = GatewayRoute(
            path="/data",
            method="GET",
            handler=secure_data,
            require_auth=True,
        )
        gw.register_route(route)

        client = app.test_client
        resp = client.get("/secure/data")
        assert resp.status in (200, 401)


class TestFinalCache:
    """缓存深度验证"""

    def test_cache_ttl_expiry(self):
        from kewe.cache.manager import CacheManager
        cache = CacheManager()
        cache.set("ttl_key", "ttl_value", ttl=0.1)
        assert cache.get("ttl_key") == "ttl_value"
        time.sleep(0.15)
        assert cache.get("ttl_key") is None

    def test_cache_delete(self):
        from kewe.cache.manager import CacheManager
        cache = CacheManager()
        cache.set("del_key", "value")
        assert cache.get("del_key") == "value"
        cache.delete("del_key")
        assert cache.get("del_key") is None

    def test_cache_clear(self):
        from kewe.cache.manager import CacheManager
        cache = CacheManager()
        cache.set("k1", "v1")
        cache.set("k2", "v2")
        cache.clear()
        assert cache.get("k1") is None
        assert cache.get("k2") is None

    def test_cache_exists(self):
        from kewe.cache.manager import CacheManager
        cache = CacheManager()
        cache.set("exist_key", "value")
        assert cache.exists("exist_key") is True
        assert cache.exists("nonexistent") is False


class TestFinalCircuitBreaker:
    """熔断器深度验证"""

    def test_cb_states_closed(self):
        from kewe.errors.circuit_breaker import CircuitBreaker
        cb = CircuitBreaker(name="cb_states")
        assert cb.state in ("closed", "CLOSED")

    def test_cb_stats_tracking(self):
        from kewe.errors.circuit_breaker import CircuitBreaker
        cb = CircuitBreaker(name="stats_cb")

        def fail_func():
            raise ValueError("fail")

        for _ in range(3):
            try:
                cb.call_sync(fail_func)
            except ValueError:
                pass

        assert cb.stats.failures >= 3
        assert cb.stats.total_calls >= 3

    def test_cb_registry_multi(self):
        from kewe.errors.circuit_breaker import CircuitBreakerRegistry
        registry = CircuitBreakerRegistry()
        cb_a = registry.get_or_create("svc_a")
        cb_b = registry.get_or_create("svc_b")
        cb_c = registry.get_or_create("svc_c")
        status = registry.get_all_status()
        assert "svc_a" in status
        assert "svc_b" in status
        assert "svc_c" in status


class TestFinalWebSocket:
    """WebSocket深度验证"""

    def test_ws_route_decorator(self, app):
        @app.websocket("/chat")
        async def chat(websocket):
            await websocket.accept()

        assert hasattr(app.router, '_websocket_routes')

    def test_ws_broadcast_functions(self):
        from kewe.websocket import broadcast, broadcast_to_group, get_connection_count
        assert callable(broadcast)
        assert callable(broadcast_to_group)
        assert get_connection_count() == 0

    def test_ws_exceptions_hierarchy(self):
        from kewe.websocket.exceptions import (
            WebSocketException, WebSocketClosed,
            WebSocketProtocolError, WebSocketHandshakeError
        )
        e1 = WebSocketClosed()
        assert isinstance(e1, WebSocketException)
        e2 = WebSocketProtocolError()
        assert isinstance(e2, WebSocketException)
        e3 = WebSocketHandshakeError()
        assert isinstance(e3, WebSocketException)


class TestFinalServer:
    """服务器深度验证"""

    def test_server_creation(self):
        from kewe.server.http_server import KeweServer
        app = Kewe("server_test_final")
        server = KeweServer(app=app, host="127.0.0.1", port=19990)
        assert server.host == "127.0.0.1"

    def test_server_stats_structure(self):
        from kewe.server.http_server import KeweServer
        app = Kewe("stats_app")
        server = KeweServer(app=app, host="127.0.0.1", port=19991)
        stats = server.stats
        required = ["running", "active_connections", "uptime_seconds", "host", "port"]
        for key in required:
            assert key in stats, f"Missing key: {key}"

    def test_asgi_adapter(self):
        from kewe.server.asgi import ASGIAdapter
        app = Kewe("asgi_test")
        adapter = ASGIAdapter(app)
        assert adapter is not None

    def test_lifecycle_registration(self):
        import kewe.server.lifecycle as lc
        assert lc is not None


class TestFinalBlueprintGroup:
    """BlueprintGroup深度验证"""

    def test_blueprint_group_creation(self):
        from kewe import Blueprint
        from kewe.routing.blueprint_group import BlueprintGroup
        bp1 = Blueprint("v1_users")
        bp2 = Blueprint("v2_users")
        group = BlueprintGroup()
        assert group is not None

    def test_blueprint_group_register(self, app):
        from kewe import Blueprint
        from kewe.routing.blueprint_group import group
        from kewe.response import json as j

        bp1 = Blueprint("bp1")
        bp2 = Blueprint("bp2")

        @bp1.get("/one")
        async def one(request):
            return j({"bp": "one"})

        @bp2.get("/two")
        async def two(request):
            return j({"bp": "two"})

        g = group(bp1, bp2, url_prefix="/api/v1")
        app.register_blueprint(g)

        client = app.test_client
        r1 = client.get("/api/v1/one")
        r2 = client.get("/api/v1/two")
        assert r1.status == 200
        assert r2.status == 200
