#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
KeWe 生产级性能基准测试 - Production-level Performance Benchmark
测试维度：JSON序列化 RPS、路由匹配、DI开销、并发处理、内存/请求等
"""

import asyncio
import gc
import json
import os
import sys
import time
import tracemalloc
from dataclasses import dataclass
from concurrent.futures import ThreadPoolExecutor

import pytest

from kewe.utils.compat import json as compat_json, JsonWrapper
from kewe import (
    Kewe, KeweConfig, json as kewe_json, text,
    Response, JSONResponse, StreamingResponse,
    Depends, Query, Header, Body, Path as PathParam,
    TestClient, Router,
    run_in_threadpool, sync_to_async,
    CacheManager, CircuitBreaker,
)


def make_bench_app():
    config = KeweConfig(secret_key="bench-secret-key-2026")
    return Kewe(name="bench_app", config=config, enable_gateway=False)


@dataclass
class BenchResult:
    name: str
    iterations: int
    total_time: float
    avg_time_ms: float
    ops_per_sec: float
    memory_kb: float = 0.0

    def __str__(self):
        return (f"{self.name}: {self.ops_per_sec:,.0f} ops/s "
                f"({self.avg_time_ms:.4f}ms avg, {self.total_time:.3f}s total)")


def run_bench(name, func, iterations=10000, setup=None):
    result = None
    gc.disable()
    try:
        if setup:
            setup()
        start_mem = _get_current_memory()
        start = time.perf_counter()
        for _ in range(iterations):
            result = func()
        elapsed = time.perf_counter() - start
        end_mem = _get_current_memory()
        return BenchResult(
            name=name,
            iterations=iterations,
            total_time=elapsed,
            avg_time_ms=(elapsed / iterations) * 1000,
            ops_per_sec=iterations / elapsed if elapsed > 0 else float('inf'),
            memory_kb=(end_mem - start_mem) / 1024,
        )
    finally:
        gc.enable()
        if result is not None:
            del result


def run_async_bench(name, coro_func, iterations=10000, setup=None):
    async def _run():
        if setup:
            await setup() if asyncio.iscoroutinefunction(setup) else setup()
        gc.disable()
        try:
            start_mem = _get_current_memory()
            start = time.perf_counter()
            for _ in range(iterations):
                await coro_func()
            elapsed = time.perf_counter() - start
            end_mem = _get_current_memory()
            return BenchResult(
                name=name,
                iterations=iterations,
                total_time=elapsed,
                avg_time_ms=(elapsed / iterations) * 1000,
                ops_per_sec=iterations / elapsed if elapsed > 0 else float('inf'),
                memory_kb=(end_mem - start_mem) / 1024,
            )
        finally:
            gc.enable()
    return asyncio.run(_run())


def _get_current_memory():
    gc.collect()
    try:
        import psutil
        return psutil.Process().memory_info().rss
    except ImportError:
        return 0


class TestBenchmarkJSONSerialization:
    """纯JSON序列化 RPS 基准测试"""

    def test_stdlib_json_dumps(self):
        data = {"id": 1, "name": "test", "tags": ["a", "b", "c"], "meta": {"count": 100}}
        result = run_bench("stdlib_json_dumps", lambda: json.dumps(data), iterations=50000)
        assert result.ops_per_sec > 0

    def test_kewe_json_dumps(self):
        from kewe.utils.compat import json as j
        data = {"id": 1, "name": "test", "tags": ["a", "b", "c"], "meta": {"count": 100}}
        result = run_bench("kewe_json_dumps", lambda: j.dumps(data), iterations=50000)
        assert result.ops_per_sec > 0

    def test_kewe_json_dumpsb(self):
        from kewe.utils.compat import json as j
        data = {"id": 1, "name": "test", "tags": ["a", "b", "c"], "meta": {"count": 100}}
        result = run_bench("kewe_json_dumpsb", lambda: j.dumpsb(data), iterations=50000)
        assert result.ops_per_sec > 0

    def test_json_loads(self):
        import json as _json
        payload = _json.dumps({"id": 1, "name": "test", "items": list(range(50))})
        result = run_bench("json_loads", lambda: _json.loads(payload), iterations=50000)
        assert result.ops_per_sec > 0

    def test_kewe_json_loads(self):
        from kewe.utils.compat import json as j
        payload = j.dumps({"id": 1, "name": "test", "items": list(range(50))})
        result = run_bench("kewe_json_loads", lambda: j.loads(payload), iterations=50000)
        assert result.ops_per_sec > 0

    def test_large_json_serialization(self):
        from kewe.utils.compat import json as j
        data = {
            "items": [{"id": i, "name": f"item_{i}", "data": {"nested": list(range(10))}} for i in range(100)]
        }
        result = run_bench("large_json", lambda: j.dumps(data), iterations=5000)
        assert result.ops_per_sec > 0

    def test_json_deserialization_speed(self):
        from kewe.utils.compat import json as j
        data = {"id": 1, "name": "test" * 100, "items": list(range(100))}
        payload = j.dumps(data)
        result = run_bench("json_deser", lambda: j.loads(payload), iterations=20000)
        assert result.ops_per_sec > 0


class TestBenchmarkResponseCreation:
    """响应创建性能基准测试"""

    def test_json_response_creation(self):
        data = {"id": 1, "message": "ok", "status": "success"}
        result = run_bench("json_response", lambda: kewe_json(data), iterations=20000)
        assert result.avg_time_ms < 1.0

    def test_response_with_headers(self):
        data = {"id": 1}
        result = run_bench(
            "json_resp_headers",
            lambda: kewe_json(data, headers={"X-Custom-1": "v1", "X-Custom-2": "v2"}),
            iterations=20000
        )
        assert result.ops_per_sec > 0

    def test_response_with_status(self):
        data = {"error": "not found"}
        result = run_bench(
            "json_resp_status",
            lambda: kewe_json(data, status=404),
            iterations=20000
        )
        assert result.ops_per_sec > 0

    def test_text_response_creation(self):
        result = run_bench("text_response", lambda: text("Hello World"), iterations=20000)
        assert result.ops_per_sec > 0

    def test_plain_text_response(self):
        from kewe import PlainTextResponse
        result = run_bench("plain_text", lambda: PlainTextResponse("data"), iterations=20000)
        assert result.ops_per_sec > 0

    def test_json_response_class(self):
        result = run_bench("json_response_class", lambda: JSONResponse({"ok": True}), iterations=20000)
        assert result.ops_per_sec > 0


class TestBenchmarkRouting:
    """路由匹配性能基准测试"""

    def test_route_matching_static(self):
        app = make_bench_app()

        @app.route("/api/v1/users")
        async def users(request):
            return kewe_json([])

        client = TestClient(app)
        result = run_bench("route_static", lambda: client.get("/api/v1/users"), iterations=5000)
        assert result.avg_time_ms < 2.0

    def test_route_matching_path_params(self):
        app = make_bench_app()

        @app.route("/api/v1/users/<user_id:int>/posts/<post_id:int>")
        async def user_post(request, user_id, post_id):
            return kewe_json({"user": user_id, "post": post_id})

        client = TestClient(app)
        result = run_bench("route_params", lambda: client.get("/api/v1/users/42/posts/100"), iterations=5000)
        assert result.avg_time_ms < 2.0

    def test_route_matching_name_lookup(self):
        app = make_bench_app()

        @app.route("/named-route-1", name="route1")
        async def r1(request):
            return kewe_json({})

        @app.route("/named-route-2", name="route2")
        async def r2(request):
            return kewe_json({})

        result = run_bench("url_for", lambda: app.url_for("route2"), iterations=5000)
        assert result.avg_time_ms < 1.0

    def test_route_with_many_routes_lookup(self):
        app = make_bench_app()

        for i in range(100):
            @app.route(f"/api/v1/endpoint-{i}")
            async def handler(request): return kewe_json({})

        @app.route("/api/v1/endpoint-99/last")
        async def last_handler(request): return kewe_json({})

        client = TestClient(app)
        result = run_bench("many_routes_last", lambda: client.get("/api/v1/endpoint-99/last"), iterations=3000)
        assert result.ops_per_sec > 0

    def test_include_router_lookup(self):
        app = make_bench_app()
        router = Router()

        @router.route("/inner/<id:int>")
        async def inner(request, id):
            return kewe_json({"id": id})

        app.include_router(router, prefix="/api/v2")
        client = TestClient(app)
        result = run_bench("include_router", lambda: client.get("/api/v2/inner/42"), iterations=5000)
        assert result.ops_per_sec > 0


class TestBenchmarkDI:
    """依赖注入开销基准测试"""

    def test_di_depends_simple(self):
        app = make_bench_app()

        async def get_service():
            return {"db": "connected"}

        @app.route("/di-simple")
        async def handler(request, svc=Depends(get_service)):
            return kewe_json(svc)

        client = TestClient(app)
        result = run_bench("di_simple", lambda: client.get("/di-simple"), iterations=5000)
        assert result.avg_time_ms < 3.0

    def test_di_depends_nested(self):
        app = make_bench_app()

        async def get_conn():
            return {"conn": "open"}

        async def get_repo(conn=Depends(get_conn)):
            return {"repo": "data", "conn": conn}

        async def get_service(repo=Depends(get_repo)):
            return {"service": "active", "repo": repo}

        @app.route("/di-nested")
        async def handler(request, svc=Depends(get_service)):
            return kewe_json(svc)

        client = TestClient(app)
        result = run_bench("di_nested", lambda: client.get("/di-nested"), iterations=3000)
        assert result.ops_per_sec > 0

    def test_di_query_param(self):
        app = make_bench_app()

        @app.route("/di-query")
        async def handler(request, q: str = Query(default=""), page: int = Query(default=1)):
            return kewe_json({"q": q, "page": page})

        client = TestClient(app)
        result = run_bench("di_query", lambda: client.get("/di-query?q=test&page=2"), iterations=5000)
        assert result.ops_per_sec > 0

    def test_di_header_param(self):
        app = make_bench_app()

        @app.route("/di-header")
        async def handler(request, api_key: str = Header()):
            return kewe_json({"key": api_key})

        client = TestClient(app)
        result = run_bench(
            "di_header",
            lambda: client.get("/di-header", headers={"api-key": "secret"}),
            iterations=5000
        )
        assert result.ops_per_sec > 0

    def test_di_body_param(self):
        app = make_bench_app()

        @app.route("/di-body", methods=["POST"])
        async def handler(request, data: dict = Body()):
            return kewe_json(data)

        client = TestClient(app)
        result = run_bench(
            "di_body",
            lambda: client.post("/di-body", json={"name": "test", "count": 42}),
            iterations=3000
        )
        assert result.ops_per_sec > 0


class TestBenchmarkMiddleware:
    """中间件链深度基准测试"""

    def test_middleware_request_single(self):
        app = make_bench_app()

        @app.middleware("request")
        async def mw(request):
            return True

        @app.route("/mw-single")
        async def handler(request):
            return kewe_json({})

        client = TestClient(app)
        result = run_bench("mw_single", lambda: client.get("/mw-single"), iterations=5000)
        assert result.ops_per_sec > 0

    def test_middleware_onion_single(self):
        app = make_bench_app()

        @app.middleware("onion")
        async def onion_mw(request, call_next):
            return await call_next(request)

        @app.route("/onion-single")
        async def handler(request):
            return kewe_json({})

        client = TestClient(app)
        result = run_bench("onion_single", lambda: client.get("/onion-single"), iterations=5000)
        assert result.ops_per_sec > 0

    def test_middleware_chain_5_onion(self):
        app = make_bench_app()

        for i in range(5):
            @app.middleware("onion", priority=i * 10)
            async def mw(request, call_next):
                return await call_next(request)

        @app.route("/onion-chain")
        async def handler(request):
            return kewe_json({})

        client = TestClient(app)
        result = run_bench("onion_chain_5", lambda: client.get("/onion-chain"), iterations=3000)
        assert result.ops_per_sec > 0

    def test_middleware_chain_10_onion(self):
        app = make_bench_app()

        for i in range(10):
            @app.middleware("onion", priority=i * 10)
            async def mw(request, call_next):
                return await call_next(request)

        @app.route("/onion-chain-10")
        async def handler(request):
            return kewe_json({})

        client = TestClient(app)
        result = run_bench("onion_chain_10", lambda: client.get("/onion-chain-10"), iterations=3000)
        assert result.ops_per_sec > 0


class TestBenchmarkCache:
    """缓存命中率基准测试"""

    def test_cache_set_get(self):
        cache = CacheManager()

        def _bench():
            cache.set("key", "value", ttl=60)
            return cache.get("key")

        result = run_bench("cache_set_get", _bench, iterations=50000)
        assert result.avg_time_ms < 0.1

    def test_cache_hit_ratio(self):
        cache = CacheManager()
        cache.set("hot_key", "cached_value", ttl=600)
        hits = 0
        for _ in range(1000):
            if cache.get("hot_key") == "cached_value":
                hits += 1
        assert hits == 1000


class TestBenchmarkCircuitBreaker:
    """熔断器性能基准测试"""

    def test_circuit_breaker_closed_state(self):
        cb = CircuitBreaker(name="bench_cb", failure_threshold=100)

        async def fast_op():
            return {"ok": True}

        async def _bench():
            for _ in range(1000):
                await cb.call(fast_op)

        start = time.perf_counter()
        asyncio.run(_bench())
        elapsed = time.perf_counter() - start
        ops = 1000 / elapsed
        assert ops > 500


class TestBenchmarkConcurrency:
    """并发请求处理能力"""

    def test_concurrent_requests(self):
        app = make_bench_app()

        @app.route("/concurrent")
        async def handler(request):
            return kewe_json({"status": "ok"})

        client = TestClient(app)

        async def _make_requests(n):
            for _ in range(n):
                client.get("/concurrent")

        start = time.perf_counter()
        asyncio.run(_make_requests(500))
        elapsed = time.perf_counter() - start
        ops = 500 / elapsed
        assert ops > 100


class TestBenchmarkStartup:
    """启动时间与内存"""

    def test_app_creation_time(self):
        start = time.perf_counter()
        for _ in range(100):
            app = Kewe(name=f"test_{_}", config=KeweConfig(secret_key="k"), enable_gateway=False)
        elapsed = time.perf_counter() - start
        avg_ms = (elapsed / 100) * 1000
        assert avg_ms < 50.0

    def test_cold_start_memory(self):
        app = make_bench_app()

        @app.route("/")
        async def root(request):
            return kewe_json({"ok": True})

        gc.collect()
        mem_before = _get_current_memory()

        for _ in range(100):
            client = TestClient(app)
            client.get("/")

        gc.collect()
        mem_after = _get_current_memory()
        mem_diff_kb = (mem_after - mem_before) / 1024

        assert mem_diff_kb < 50_000


class TestBenchmarkExceptionHandling:
    """异常处理开销"""

    def test_exception_abort_speed(self):
        app = make_bench_app()

        @app.route("/abort")
        async def aborted(request):
            from kewe import abort
            abort(400, "Bad request")

        client = TestClient(app)
        result = run_bench("abort_400", lambda: client.get("/abort"), iterations=5000)
        assert result.ops_per_sec > 0

    def test_exception_raise_speed(self):
        app = make_bench_app()
        from kewe import BadRequest

        @app.route("/raise-400")
        async def bad(request):
            raise BadRequest("Invalid input")

        client = TestClient(app)
        result = run_bench("raise_400", lambda: client.get("/raise-400"), iterations=5000)
        assert result.ops_per_sec > 0


class TestBenchmarkHelpers:
    """工具函数性能"""

    def test_run_in_threadpool(self):
        def sync_op(x):
            return x * 2

        async def _bench():
            for _ in range(1000):
                await run_in_threadpool(sync_op, 21)

        start = time.perf_counter()
        asyncio.run(_bench())
        elapsed = time.perf_counter() - start
        assert (1000 / elapsed) > 100

    def test_sync_to_async_overhead(self):
        @sync_to_async
        def sync_func(x):
            return x + 1

        async def _bench():
            for _ in range(500):
                await sync_func(42)

        start = time.perf_counter()
        asyncio.run(_bench())
        elapsed = time.perf_counter() - start
        assert (500 / elapsed) > 50


class TestBenchmarkMemory:
    """内存基准测试"""

    def test_response_memory_per_request(self):
        app = make_bench_app()

        @app.route("/mem-test")
        async def handler(request):
            return kewe_json({"data": "test" * 50})

        client = TestClient(app)
        gc.collect()
        mem_start = _get_current_memory()

        for _ in range(1000):
            resp = client.get("/mem-test")
            del resp

        gc.collect()
        mem_end = _get_current_memory()
        mem_per_req = (mem_end - mem_start) / 1000 / 1024
        assert mem_per_req < 500


class TestBenchmarkWebSocket:
    """WebSocket性能基准"""

    def test_websocket_route_creation(self):
        app = make_bench_app()
        results = []

        @app.websocket("/ws-bench")
        async def ws_handler(websocket):
            await websocket.accept()
            await websocket.close()

        start = time.perf_counter()
        for _ in range(1000):
            results.append(app.websocket_routes if hasattr(app, 'websocket_routes') else [])
        elapsed = time.perf_counter() - start
        assert (1000 / elapsed) > 1000


class TestBenchmarkGateway:
    """网关性能基准"""

    def test_gateway_route_match(self):
        from kewe.gateway.core import TrieRouter, GatewayRoute
        router = TrieRouter()

        for i in range(100):
            route = GatewayRoute(
                path=f"/api/v1/endpoint/{i}",
                method="GET",
                handler=lambda r: {"id": i},
            )
            router.add_route(route)

        result = run_bench(
            "gateway_trie_match",
            lambda: router.match("/api/v1/endpoint/50", "GET", "v1"),
            iterations=20000
        )
        assert result.avg_time_ms < 0.5


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short", "-s"])