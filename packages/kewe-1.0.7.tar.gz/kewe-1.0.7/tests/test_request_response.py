#!/usr/bin/env python

"请求和响应处理测"""



import pytest

from kewe import Kewe

from kewe.response import json, text, html, redirect





@pytest.mark.asyncio

async def test_json_response():

    "测试JSON响应"""

    app = Kewe("TestApp", enable_gateway=False)

    

    @app.get("/json")

    async def json_handler(request):

        return json({"message": "test"}, status=200)

    

    # 使用异步测试客户
    from kewe.utils.testing import AsyncTestClient

    client = AsyncTestClient(app)

    response = await client.get("/json")

    

    assert response.status == 200

    assert response.json == {"message": "test"}

    assert response.headers.get('Content-Type') == "application/json"





@pytest.mark.asyncio

async def test_text_response():

    "测试文本响应"""

    app = Kewe("TestApp", enable_gateway=False)

    

    @app.get("/text")

    async def text_handler(request):

        return text("Hello, World!")

    

    # 使用异步测试客户
    from kewe.utils.testing import AsyncTestClient

    client = AsyncTestClient(app)

    response = await client.get("/text")

    

    assert response.status == 200

    assert response.text == "Hello, World!"

    assert response.headers.get('Content-Type') == "text/plain; charset=utf-8"





@pytest.mark.asyncio

async def test_html_response():

    "测试HTML响应"""

    app = Kewe("TestApp", enable_gateway=False)

    

    @app.get("/html")

    async def html_handler(request):

        return html("<h1>Hello, World!</h1>")

    

    # 使用异步测试客户
    from kewe.utils.testing import AsyncTestClient

    client = AsyncTestClient(app)

    response = await client.get("/html")

    

    assert response.status == 200

    assert "<h1>Hello, World!</h1>" in response.text

    assert response.headers.get('Content-Type') == "text/html; charset=utf-8"





@pytest.mark.asyncio

async def test_redirect_response():

    "测试重定向响"""

    app = Kewe("TestApp", enable_gateway=False)

    

    @app.get("/redirect")

    async def redirect_handler(request):

        return redirect("/target")

    

    @app.get("/target")

    async def target_handler(request):

        return {"message": "Target reached"}

    

    # 使用异步测试客户
    from kewe.utils.testing import AsyncTestClient

    client = AsyncTestClient(app)

    response = await client.get("/redirect", follow_redirects=False)

    

    assert response.status in (302, 307)

    assert response.headers.get('Location') == "/target"





@pytest.mark.asyncio

async def test_query_params():

    "测试查询参数"""

    app = Kewe("TestApp", enable_gateway=False)

    

    @app.get("/query")

    async def query_handler(request):

        return {

            "name": request.get("name"),

            "age": request.get("age"),

            "tags": request.getlist("tag")

        }

    

    # 使用异步测试客户
    from kewe.utils.testing import AsyncTestClient

    client = AsyncTestClient(app)

    response = await client.get("/query?name=test&age=20&tag=1&tag=2")

    

    assert response.status == 200

    assert response.json == {"name": "test", "age": "20", "tags": ["1", "2"]}





@pytest.mark.asyncio

async def test_json_body():

    "测试JSON请求"""

    app = Kewe("TestApp", enable_gateway=False)

    

    @app.post("/json-body")

    async def json_body_handler(request):

        data = await request.json

        return {"received": data}

    

    # 使用异步测试客户
    from kewe.utils.testing import AsyncTestClient

    client = AsyncTestClient(app)

    response = await client.post("/json-body", json={"name": "test", "age": 20})

    

    assert response.status == 200

    assert response.json == {"received": {"name": "test", "age": 20}}

