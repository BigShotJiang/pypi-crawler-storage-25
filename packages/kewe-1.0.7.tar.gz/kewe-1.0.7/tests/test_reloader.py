#!/usr/bin/env python

"自动重载功能测试"""



import pytest

import time

import tempfile

import os

from kewe.server.reloader import FileWatcher, Reloader





def test_file_watcher():

    "测试文件监视"""

    # 创建临时目录

    with tempfile.TemporaryDirectory() as temp_dir:

        # 创建文件监视
        watcher = FileWatcher([temp_dir])

        watcher.start()

        

        # 初始状态，应该没有变化

        assert not watcher.check()

        

        # 创建新文
        test_file = os.path.join(temp_dir, "test.py")

        with open(test_file, "w") as f:

            f.write("print('test')")

        

        # 检查文件变
        time.sleep(0.1)  # 等待文件系统更新

        assert watcher.check()

        

        # 修改文件

        with open(test_file, "w") as f:

            f.write("print('updated')")

        

        # 检查文件变
        time.sleep(0.1)  # 等待文件系统更新

        assert watcher.check()

        

        # 删除文件

        os.unlink(test_file)

        

        # 检查文件变
        time.sleep(0.1)  # 等待文件系统更新

        assert watcher.check()





def test_file_watcher_ignore():

    "测试文件监视器忽略模"""

    # 创建临时目录

    with tempfile.TemporaryDirectory() as temp_dir:

        # 创建子目
        sub_dir = os.path.join(temp_dir, "__pycache__")

        os.makedirs(sub_dir)

        

        # 创建文件监视
        watcher = FileWatcher([temp_dir])

        watcher.start()

        

        # 在__pycache__目录中创建文
        test_file = os.path.join(sub_dir, "test.pyc")

        with open(test_file, "w") as f:

            f.write("test")

        

        # 检查文件变化，应该忽略

        time.sleep(0.1)  # 等待文件系统更新

        assert not watcher.check()

