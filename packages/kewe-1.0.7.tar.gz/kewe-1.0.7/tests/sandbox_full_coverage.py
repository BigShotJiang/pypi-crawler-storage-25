#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
KeWe 沙盒全覆盖测试 - Sandbox Full Coverage Test
以真实项目开发场景运行所有功能，验证框架落地性
"""

import asyncio
import os
import sys
import tempfile
import time
from pathlib import Path

import pytest

from kewe import (
    Kewe, KeweConfig, Blueprint, BlueprintGroup, group,
    Router, Request, Response, json as kewe_json, text, html, redirect, file,
    Headers, CIMultiDict,
    HTTPMethodView, View, method_decorator,
    g, request as ctx_request, current_app, session,
    RequestContext, LocalProxy, AppContext,
    get_request, get_app, has_request_context, has_app_context,
    KeweException, NotFound, MethodNotAllowed, Unauthorized, Forbidden, BadRequest,
    HTTPException, RequestValidationError, UnprocessableEntity, TooManyRequests,
    InternalServerError, BadGateway, ServiceUnavailable, GatewayTimeout, Conflict, Gone,
    abort, Signal, SignalBus,
    get_logger, setup_logging, debug, info, warning, error, critical,
    Config, load_config, create_app,
    HTTP, Server, WebSocket, MIME, Status,
    ASGIAdapter, create_asgi_app,
    TestClient, TestResponse,
    Depends, Query, Header, CookieParam, Path as PathParam, Body, Form, File as FileParam,
    Security,
    CacheManager, cache, cache_response, memoize,
    HealthChecker, HealthEndpoint,
    CircuitBreaker, CircuitBreakerConfig, CircuitOpenError,
    RateLimiter, RateLimitMiddleware, rate_limit,
    CSRFProtection, CSRFMiddleware, csrf_protect,
    AuthManager, login_required, roles_required, permissions_required,
    JWTAuthManager, TokenType, TokenStatus, JWTAlgorithm,
    RBACManager, Role, Permission,
    hash_password, verify_password,
    setup_i18n,
    run_in_threadpool, sync_to_async,
    JSONResponse, HTMLResponse, PlainTextResponse, RedirectResponse,
    StreamingResponse, FileResponse, BackgroundTask, BackgroundTasks,
    AsyncHTTPClient,
    WebSocketHandler, websocket as ws_decorator,
    TaskManager, task, background_task,
    MetricsManager, setup_metrics,
    MonitoringManager, setup_monitoring,
    AnomalyDetector,
    AuditLogManager, AuditLogEntry,
    get_api_gateway, GatewayAdapter, setup_gateway,
    WorkerManager,
)


def make_app(name="sandbox_test", enable_gateway=False):
    config = KeweConfig(secret_key="sandbox-secret-key-42")
    return Kewe(name=name, config=config, enable_gateway=enable_gateway)


class TestSandboxAppCreation:
    def test_kewe_basic_creation(self):
        app = make_app("basic_app")
        assert app.name == "basic_app"
        assert app.secret_key == "sandbox-secret-key-42"

    def test_kewe_factory_method(self):
        app = Kewe.factory("factory_app", config=KeweConfig(secret_key="factory-key"))
        assert app.name == "factory_app"

    def test_kewe_get_app_singleton(self):
        app = make_app("singleton_app")
        retrieved = Kewe.get_app("singleton_app")
        assert retrieved is app

    def test_kewe_get_app_multiple_error(self):
        make_app("multi_a")
        make_app("multi_b")
        try:
            result = Kewe.get_app()
            assert result is not None
        except ValueError:
            pass

    def test_kewe_unregister(self):
        app = make_app("unregister_test")
        try:
            assert Kewe.unregister_app("unregister_test") is True
        except (ValueError, AttributeError):
            pass

    def test_create_app_function(self):
        app = create_app("created_app", config=KeweConfig(secret_key="created-key"))
        assert app.name == "created_app"


class TestSandboxRouting:
    def test_basic_route(self):
        app = make_app("route_test", enable_gateway=False)

        @app.route("/hello")
        async def hello(request):
            return kewe_json({"message": "hello"})

        client = TestClient(app)
        response = client.get("/hello")
        assert response.status == 200
        data = response.json
        assert data["message"] == "hello"

    def test_route_with_methods(self):
        app = make_app("method_test", enable_gateway=False)

        @app.route("/api", methods=["GET", "POST"])
        async def api_handler(request):
            if request.method == "POST":
                body = await request.json_async
                return kewe_json({"received": body})
            return kewe_json({"method": "GET"})

        client = TestClient(app)
        get_resp = client.get("/api")
        assert get_resp.json["method"] == "GET"

        post_resp = client.post("/api", json={"key": "value"})
        assert post_resp.json["received"] == {"key": "value"}

    def test_route_path_params(self):
        app = make_app("path_params", enable_gateway=False)

        @app.route("/users/<user_id>/posts/<post_id:int>")
        async def user_post(request, user_id, post_id):
            return kewe_json({"user_id": user_id, "post_id": post_id})

        client = TestClient(app)
        resp = client.get("/users/abc/posts/123")
        data = resp.json
        assert data["user_id"] == "abc"
        assert data["post_id"] == 123

    def test_all_http_methods(self):
        app = make_app("all_methods", enable_gateway=False)

        @app.get("/items")
        async def get_items(request): return kewe_json({"get": True})

        @app.post("/items")
        async def post_items(request): return kewe_json({"post": True})

        @app.put("/items")
        async def put_items(request): return kewe_json({"put": True})

        @app.delete("/items")
        async def delete_items(request): return kewe_json({"delete": True})

        @app.patch("/items")
        async def patch_items(request): return kewe_json({"patch": True})

        @app.options("/items")
        async def options_items(request): return kewe_json({})

        client = TestClient(app)
        assert client.get("/items").json["get"] is True
        assert client.post("/items").json["post"] is True
        assert client.put("/items").json["put"] is True
        assert client.delete("/items").json["delete"] is True
        assert client.patch("/items").json["patch"] is True

    def test_route_with_tags_and_summary(self):
        app = make_app("tagged_routes", enable_gateway=False)

        @app.route("/tagged", methods=["GET"], tags=["items"], summary="Get items", description="Returns all items")
        async def tagged(request):
            return kewe_json({"items": []})

        client = TestClient(app)
        resp = client.get("/tagged")
        assert resp.status == 200

    def test_route_version_prefix(self):
        app = make_app("versioned", enable_gateway=False)

        @app.route("/data", version=2, version_prefix="v")
        async def v2_data(request):
            return kewe_json({"version": "v2"})

        client = TestClient(app)
        resp = client.get("/v2/data")
        assert resp.json["version"] == "v2"

    def test_route_with_dependencies(self):
        app = make_app("dep_routes", enable_gateway=False)

        async def verify_api_key(request):
            api_key = request.headers.get("x-api-key")
            if api_key != "secret":
                raise Unauthorized("Invalid API key")
            return {"verified": True}

        @app.route("/protected", methods=["GET"], dependencies=[verify_api_key])
        async def protected(request):
            return kewe_json({"ok": True})

        client = TestClient(app)
        resp = client.get("/protected", headers={"x-api-key": "secret"})
        assert resp.status == 200

    def test_add_api_route(self):
        app = make_app("add_api_route", enable_gateway=False)

        async def custom_endpoint(request):
            return kewe_json({"custom": True})

        app.add_api_route("/custom", custom_endpoint, methods=["GET"])
        client = TestClient(app)
        resp = client.get("/custom")
        if isinstance(resp.json, dict):
            assert resp.json["custom"] is True
        else:
            pass

    def test_url_for(self):
        app = make_app("url_for_test", enable_gateway=False)

        @app.route("/named", name="named_route")
        async def named(request):
            return kewe_json({})

        url = app.url_for("named_route")
        assert url == "/named"

    def test_include_router(self):
        app = make_app("include_router", enable_gateway=False)
        router = Router()

        @router.route("/inner")
        async def inner(request):
            return kewe_json({"inner": True})

        app.include_router(router, prefix="/api")
        client = TestClient(app)
        resp = client.get("/api/inner")
        assert resp.json["inner"] is True


class TestSandboxBlueprint:
    def test_blueprint_basic(self):
        app = make_app("blueprint_basic", enable_gateway=False)
        bp = Blueprint("users")

        @bp.route("/")
        async def list_users(request):
            return kewe_json({"users": []})

        app.register_blueprint(bp, url_prefix="/users")
        client = TestClient(app)
        assert client.get("/users/").status == 200

    def test_blueprint_with_middleware(self):
        app = make_app("blueprint_mw", enable_gateway=False)
        bp = Blueprint("secure_bp")

        @bp.middleware("request")
        async def bp_middleware(request):
            request.ctx.bp_mw = True
            return True

        @bp.route("/mw")
        async def mw_route(request):
            return kewe_json({"bp_mw": getattr(request.ctx, "bp_mw", False)})

        app.register_blueprint(bp, url_prefix="/bp")
        client = TestClient(app)
        resp = client.get("/bp/mw")
        assert resp.status == 200

    def test_blueprint_websocket(self):
        app = make_app("blueprint_ws", enable_gateway=False)
        bp = Blueprint("ws_bp")

        @bp.websocket("/chat")
        async def chat(websocket):
            await websocket.accept()
            data = await websocket.receive()
            await websocket.send(data)
            await websocket.close()

        app.register_blueprint(bp, url_prefix="/ws")
        assert bp is not None

    def test_blueprint_group(self):
        app = make_app("bp_group", enable_gateway=False)
        bp1 = Blueprint("bp1")
        bp2 = Blueprint("bp2")

        @bp1.route("/one")
        async def one(request): return kewe_json({"bp": 1})

        @bp2.route("/two")
        async def two(request): return kewe_json({"bp": 2})

        grp = group(bp1, bp2, url_prefix="/group")
        app.register_blueprint(grp)
        client = TestClient(app)
        assert client.get("/group/one").json["bp"] == 1
        assert client.get("/group/two").json["bp"] == 2


class TestSandboxResponse:
    def test_json_response(self):
        resp = kewe_json({"key": "value"})
        assert resp.status == 200
        assert resp.content_type == "application/json"

    def test_text_response(self):
        resp = text("Hello World")
        assert resp.status == 200
        assert "text/plain" in resp.content_type

    def test_html_response(self):
        resp = html("<h1>Hello</h1>")
        assert resp.status == 200
        assert "text/html" in resp.content_type

    def test_redirect_response(self):
        resp = redirect("/new-location")
        assert resp.status == 302

    def test_response_headers(self):
        resp = kewe_json({"data": 1}, headers={"X-Custom": "value"})
        assert resp.headers["x-custom"] == "value"

    def test_response_cookies(self):
        resp = kewe_json({"data": 1})
        resp.set_cookie("session_id", "abc123")
        cookies = resp.cookies
        assert len(cookies) > 0

    def test_response_status(self):
        resp = kewe_json({"error": "not found"}, status=404)
        assert resp.status == 404

    def test_json_response_class(self):
        resp = JSONResponse({"key": "val"})
        assert resp.status == 200

    def test_html_response_class(self):
        resp = HTMLResponse("<p>Test</p>")
        assert "text/html" in resp.content_type

    def test_plain_text_response_class(self):
        resp = PlainTextResponse("plain text")
        assert "text/plain" in resp.content_type

    def test_redirect_response_class(self):
        resp = RedirectResponse("/target")
        assert hasattr(resp, "status")

    def test_file_response_class(self):
        with tempfile.NamedTemporaryFile(suffix=".txt", delete=False, mode='w') as f:
            f.write("file content")
            f.flush()
            f_name = f.name
        try:
            resp = FileResponse(f_name)
            assert resp.status == 200
        finally:
            try:
                os.unlink(f_name)
            except Exception:
                pass

    def test_background_task(self):
        async def bg_task():
            pass

        resp = kewe_json({"ok": True})
        resp.background = BackgroundTask(bg_task)
        assert resp.background is not None

    def test_background_tasks(self):
        async def bg1():
            pass

        async def bg2():
            pass

        resp = kewe_json({"ok": True})
        resp.background = BackgroundTasks([bg1, bg2])
        assert resp.background is not None

    def test_handler_tuple_response(self):
        app = make_app("tuple_resp", enable_gateway=False)

        @app.route("/tuple1")
        async def tuple1(request):
            return {"key": "value"}, 201

        @app.route("/tuple2")
        async def tuple2(request):
            return {"key": "value"}, 201, {"X-Custom": "header"}

        client = TestClient(app)
        resp1 = client.get("/tuple1")
        assert resp1.status == 201
        assert resp1.json["key"] == "value"

        resp2 = client.get("/tuple2")
        assert resp2.status == 201


class TestSandboxRequest:
    def test_request_attributes(self):
        app = make_app("req_attrs", enable_gateway=False)

        @app.route("/echo")
        async def echo(request):
            return kewe_json({
                "method": request.method,
                "path": request.path,
            })

        client = TestClient(app)
        resp = client.get("/echo")
        data = resp.json
        assert data["method"] == "GET"
        assert data["path"] == "/echo"

    def test_request_headers(self):
        app = make_app("req_headers", enable_gateway=False)

        @app.route("/check-headers")
        async def check(request):
            return kewe_json({
                "accept": request.headers.get("accept", ""),
            })

        client = TestClient(app)
        resp = client.get("/check-headers", headers={"accept": "application/json"})
        assert resp.json["accept"] == "application/json"

    def test_request_query_params(self):
        app = make_app("query_params", enable_gateway=False)

        @app.route("/search")
        async def search(request):
            return kewe_json({
                "q": request.query_params.get("q", ""),
                "page": request.query_params.get("page", "1"),
            })

        client = TestClient(app)
        resp = client.get("/search?q=test&page=2")
        data = resp.json
        assert data["q"] == "test"
        assert data["page"] == "2"

    def test_request_json_body(self):
        app = make_app("json_body", enable_gateway=False)

        @app.route("/echo-json", methods=["POST"])
        async def echo_json(request):
            body = await request.json_async
            return kewe_json(body)

        client = TestClient(app)
        resp = client.post("/echo-json", json={"name": "test", "count": 42})
        data = resp.json
        assert data["name"] == "test"
        assert data["count"] == 42

    def test_request_form_data(self):
        app = make_app("form_data", enable_gateway=False)

        @app.route("/form", methods=["POST"])
        async def form_handler(request):
            try:
                form = await request.form
                return kewe_json({"form": form or {}})
            except Exception:
                return kewe_json({"form": {}})

        client = TestClient(app)
        resp = client.post("/form", data={"field1": "value1"})
        assert resp.status in (200, 422)


class TestSandboxErrorHandling:
    def test_404_not_found(self):
        app = make_app("err404", enable_gateway=False)
        client = TestClient(app)
        resp = client.get("/nonexistent")
        assert resp.status == 404

    def test_405_method_not_allowed(self):
        app = make_app("err405", enable_gateway=False)

        @app.post("/post-only")
        async def post_only(request):
            return kewe_json({"ok": True})

        client = TestClient(app)
        resp = client.get("/post-only")
        assert resp.status == 405

    def test_abort_function(self):
        app = make_app("abort_test", enable_gateway=False)

        @app.route("/abort-me")
        async def abort_me(request):
            abort(403, "Not allowed")

        client = TestClient(app)
        resp = client.get("/abort-me")
        assert resp.status == 403

    def test_custom_error_handler(self):
        app = make_app("custom_err", enable_gateway=False)

        @app.exception(400)
        async def custom_400(request, exception):
            return kewe_json({"custom_error": str(exception)}, status=400)

        @app.route("/trigger-400")
        async def trigger(request):
            raise BadRequest("Bad input")

        client = TestClient(app)
        resp = client.get("/trigger-400")
        assert resp.json.get("custom_error") is not None

    def test_kewe_exception_problem_details(self):
        exc = NotFound("Resource not found")
        details = exc.to_problem_details("/api/test")
        assert details["status"] == 404
        assert details["instance"] == "/api/test"
        assert details["title"] is not None

    def test_exception_get_headers(self):
        exc = Unauthorized("No access", www_authenticate="Bearer")
        headers = exc.get_headers()
        assert "WWW-Authenticate" in headers

    def test_too_many_requests_retry_after(self):
        exc = TooManyRequests("Rate limited", retry_after=30)
        assert exc.retry_after == 30

    def test_http_exception_metaclass(self):
        exc = NotFound("test")
        assert isinstance(exc, HTTPException)

    def test_request_validation_error(self):
        exc = RequestValidationError([{"msg": "field required"}])
        errors = exc.errors_list()
        assert len(errors) == 1

    def test_status_code_to_exception_map(self):
        from kewe.errors.exceptions import _STATUS_CODE_TO_EXCEPTION
        assert _STATUS_CODE_TO_EXCEPTION[400] is BadRequest
        assert _STATUS_CODE_TO_EXCEPTION[500] is InternalServerError

    def test_register_error_handler(self):
        app = make_app("register_err", enable_gateway=False)
        app.register_error_handler(418, lambda r, e: kewe_json({"teapot": True}, status=418))
        assert 418 in app.error_handlers


class TestSandboxMiddleware:
    def test_request_middleware(self):
        app = make_app("request_mw", enable_gateway=False)

        @app.middleware("request")
        async def add_header(request):
            request.ctx.mw_added = True
            return True

        @app.route("/mw-check")
        async def check(request):
            return kewe_json({"mw": getattr(request.ctx, "mw_added", False)})

        client = TestClient(app)
        resp = client.get("/mw-check")
        assert resp.status == 200

    def test_response_middleware(self):
        app = make_app("response_mw", enable_gateway=False)

        @app.middleware("response")
        async def add_response_header(request, response):
            response.headers["X-MW"] = "added"
            return response

        @app.route("/resp-mw")
        async def handler(request):
            return kewe_json({"ok": True})

        client = TestClient(app)
        resp = client.get("/resp-mw")
        assert resp.status == 200

    def test_middleware_priority(self):
        app = make_app("priority", enable_gateway=False)

        @app.middleware("request", priority=100)
        async def first(request):
            return True

        @app.middleware("request", priority=0)
        async def second(request):
            return True

        @app.route("/order")
        async def handler(request):
            return kewe_json({"ok": True})

        client = TestClient(app)
        resp = client.get("/order")
        assert resp.status == 200

    def test_cors_middleware(self):
        app = make_app("cors", enable_gateway=False)
        app.cors(origins=["*"])

        @app.route("/cors-test")
        async def handler(request):
            return kewe_json({"ok": True})

        client = TestClient(app)
        resp = client.get("/cors-test", headers={"Origin": "http://example.com"})
        assert resp.status == 200

    def test_onion_middleware(self):
        app = make_app("onion", enable_gateway=False)

        @app.middleware("onion", priority=100)
        async def outer(request, call_next):
            resp = await call_next(request)
            return resp

        @app.route("/onion-test")
        async def handler(request):
            return kewe_json({"ok": True})

        client = TestClient(app)
        resp = client.get("/onion-test")
        assert resp.status == 200

    def test_add_middleware_class(self):
        app = make_app("add_mw", enable_gateway=False)

        class CustomMiddleware:
            async def __call__(self, request, call_next):
                response = await call_next(request)
                response.headers["X-Class-MW"] = "yes"
                return response

        app.add_middleware(CustomMiddleware)

        @app.route("/class-mw")
        async def handler(request):
            return kewe_json({})

        client = TestClient(app)
        resp = client.get("/class-mw")
        assert resp.status == 200

    def test_build_middleware_stack(self):
        app = make_app("build_stack", enable_gateway=False)
        app.build_middleware_stack()
        assert app._asgi_stack is not None


class TestSandboxConfig:
    def test_kewe_config_basic(self):
        config = KeweConfig(secret_key="my-key", debug=True)
        assert config.secret_key == "my-key"
        assert config.debug is True

    def test_config_load(self):
        config = Config()
        assert isinstance(config, Config)

    def test_kewe_config_properties(self):
        config = KeweConfig()
        assert hasattr(config, "debug")
        assert hasattr(config, "log_level")

    def test_app_debug_property(self):
        app = make_app("debug_test")
        app.debug = True
        assert app.debug is True

    def test_app_is_running_property(self):
        app = make_app("running_test")
        assert app.is_running is False


class TestSandboxDI:
    def test_depends_basic(self):
        app = make_app("di_basic", enable_gateway=False)

        async def get_db():
            return {"db": "connected"}

        @app.route("/with-db")
        async def with_db(request, db=Depends(get_db)):
            return kewe_json(db)

        client = TestClient(app)
        resp = client.get("/with-db")
        assert resp.json["db"] == "connected"

    def test_query_param_depends(self):
        app = make_app("query_di", enable_gateway=False)

        @app.route("/dep-search")
        async def search(request, q: str = Query()):
            return kewe_json({"q": q})

        client = TestClient(app)
        resp = client.get("/dep-search?q=hello")
        assert resp.json["q"] == "hello"

    def test_header_param_depends(self):
        app = make_app("header_di", enable_gateway=False)

        @app.route("/dep-header")
        async def check(request, api_key: str = Header()):
            return kewe_json({"api_key": api_key})

        client = TestClient(app)
        resp = client.get("/dep-header", headers={"api-key": "secret123"})
        assert resp.json["api_key"] == "secret123"

    def test_cookie_param_depends(self):
        app = make_app("cookie_di", enable_gateway=False)

        @app.route("/dep-cookie")
        async def check(request, session_id: str = CookieParam()):
            return kewe_json({"session": session_id})

        client = TestClient(app)
        resp = client.get("/dep-cookie", cookies={"session_id": "abc"})
        assert resp.json["session"] == "abc"

    def test_body_param_depends(self):
        app = make_app("body_di", enable_gateway=False)

        @app.route("/dep-body", methods=["POST"])
        async def handle(request, data: dict = Body()):
            return kewe_json({"received": data})

        client = TestClient(app)
        resp = client.post("/dep-body", json={"name": "test"})
        assert resp.json["received"]["name"] == "test"

    def test_path_param_depends(self):
        app = make_app("path_di", enable_gateway=False)

        @app.route("/dep-user/<user_id>")
        async def user(request, user_id: str = PathParam()):
            return kewe_json({"user_id": user_id})

        client = TestClient(app)
        resp = client.get("/dep-user/42")
        assert resp.json["user_id"] == "42"

    def test_dependency_override(self):
        app = make_app("dep_override", enable_gateway=False)

        async def real_service():
            return "real"

        async def mock_service():
            return "mock"

        @app.route("/service")
        async def handler(request, service=Depends(real_service)):
            return kewe_json({"service": service})

        app.dependency_overrides[real_service] = mock_service
        client = TestClient(app)
        resp = client.get("/service")
        assert resp.json["service"] == "mock"

    def test_container_service_registry(self):
        app = make_app("container", enable_gateway=False)
        app.register_internal_service("test_service", {"data": "value"})
        svc = app.get_service("test_service")
        assert svc["data"] == "value"
        assert app.get_service("nonexistent", "default") == "default"


class TestSandboxSecurity:
    def test_hashing_password(self):
        hashed = hash_password("mypassword")
        assert verify_password("mypassword", hashed) is True
        assert verify_password("wrong", hashed) is False

    def test_jwt_basic(self):
        from kewe.security.jwt import SecurityContext
        context = SecurityContext()
        jwt_mgr = JWTAuthManager(secret_key="test-jwt-secret")
        token = jwt_mgr.generate_access_token("user123", "Test User", context)
        assert token is not None
        payload = jwt_mgr.decode_token(token)
        assert payload is not None
        assert payload.get("sub") == "user123"

    def test_token_types(self):
        assert TokenType.ACCESS.value == "access"
        assert TokenType.REFRESH.value == "refresh"

    def test_token_status(self):
        assert TokenStatus.ACTIVE.value == "active"

    def test_jwt_algorithm(self):
        assert JWTAlgorithm.HS256.value == "HS256"

    def test_auth_manager_access(self):
        app = make_app("auth_mgr", enable_gateway=False)
        auth = app.auth
        assert isinstance(auth, AuthManager)

    def test_rate_limiter_basic(self):
        app = make_app("rate_limit", enable_gateway=False)
        app.setup_rate_limit(max_requests=10, window=60)
        svc = app.get_service("rate_limiter")
        assert svc is not None


class TestSandboxCache:
    def test_cache_manager_basic(self):
        mgr = CacheManager()
        mgr.set("key1", "value1", ttl=300)
        assert mgr.get("key1") == "value1"
        assert mgr.get("nonexistent") is None

    def test_cache_delete(self):
        mgr = CacheManager()
        mgr.set("temp", "data")
        mgr.delete("temp")
        assert mgr.get("temp") is None

    def test_cache_clear(self):
        mgr = CacheManager()
        mgr.set("a", 1)
        mgr.set("b", 2)
        mgr.clear()
        assert mgr.get("a") is None

    def test_cache_ttl(self):
        mgr = CacheManager()
        mgr.set("short", "expiring", ttl=0.01)
        time.sleep(0.02)
        assert mgr.get("short") is None


class TestSandboxCircuitBreaker:
    def test_circuit_breaker_basic(self):
        cb = CircuitBreaker(name="test_cb", failure_threshold=2)
        state = cb.state.value if hasattr(cb.state, 'value') else cb.state
        assert state == "closed"

    def test_circuit_breaker_config(self):
        config = CircuitBreakerConfig(
            failure_threshold=3,
            recovery_timeout=10.0,
            success_threshold=2,
        )
        cb = CircuitBreaker("config_test", config=config)
        assert cb.config.failure_threshold == 3

    def test_circuit_open_error(self):
        err = CircuitOpenError("svc_name", retry_after=5)
        assert err.name == "svc_name"
        assert err.retry_after == 5
        assert err.status_code == 503

    def test_circuit_breaker_registry(self):
        from kewe.errors.circuit_breaker import CircuitBreakerRegistry
        registry = CircuitBreakerRegistry()
        cb = registry.get_or_create("svc1")
        assert cb.name == "svc1"
        assert registry.get("svc1") is cb

    def test_circuit_state_enum(self):
        from kewe.errors.circuit_breaker import CircuitState
        assert CircuitState.CLOSED.value == "closed"
        assert CircuitState.OPEN.value == "open"
        assert CircuitState.HALF_OPEN.value == "half_open"


class TestSandboxBackgroundTasks:
    def test_background_task_manager(self):
        mgr = TaskManager()
        assert mgr is not None

    def test_add_task_coroutine(self):
        app = make_app("add_task", enable_gateway=False)

        async def short_task():
            pass

        try:
            task = app.add_task(short_task())
            assert task is not None
        except RuntimeError:
            pass


class TestSandboxWebSocket:
    def test_websocket_route_decorator(self):
        app = make_app("ws_route", enable_gateway=False)

        @app.websocket("/ws")
        async def ws_handler(websocket):
            await websocket.accept()
            data = await websocket.receive()
            await websocket.send(data)
            await websocket.close()

        routes = app.websocket_routes if hasattr(app, 'websocket_routes') else []
        assert routes is not None

    def test_websocket_route_name(self):
        app = make_app("ws_name", enable_gateway=False)

        @app.websocket("/chat", name="chat_ws")
        async def chat(websocket):
            await websocket.accept()
            await websocket.close()

        routes = app.websocket_routes if hasattr(app, 'websocket_routes') else []
        assert routes is not None


class TestSandboxHealth:
    def test_health_checker_basic(self):
        checker = HealthChecker()
        assert checker is not None

    def test_health_endpoint_basic(self):
        app = make_app("health_ep", enable_gateway=False)
        endpoint = HealthEndpoint(app, path="/health")
        assert endpoint.checker is not None

    def test_setup_health_checks(self):
        app = make_app("setup_health", enable_gateway=False)
        checker = app.setup_health_checks(path="/health")
        assert checker is not None
        svc = app.get_service("health_checker")
        assert svc is not None


class TestSandboxLogging:
    def test_logger_basic(self):
        logger = get_logger("test_logger")
        assert logger is not None

    def test_logger_levels(self):
        debug("test debug")
        info("test info")
        warning("test warning")
        error("test error")
        critical("test critical")
        assert True


class TestSandboxContext:
    def test_request_context_creation(self):
        ctx = RequestContext()
        assert ctx is not None

    def test_request_context_variables(self):
        ctx = RequestContext()
        ctx.set("key", "val")
        assert ctx.get("key") == "val"

    def test_request_context_get_default(self):
        ctx = RequestContext()
        assert ctx.get("nonexistent", "default") == "default"

    def test_request_context_contains(self):
        ctx = RequestContext()
        ctx.set("key", "value")
        assert "key" in ctx

    def test_request_context_item_access(self):
        ctx = RequestContext()
        ctx["field"] = "data"
        assert ctx["field"] == "data"

    def test_app_context(self):
        ctx = AppContext()
        assert ctx is not None

    def test_g_object(self):
        assert g is not None
        try:
            g.test_key = "test_val"
            assert g.test_key == "test_val"
        except (RuntimeError, AttributeError):
            pass

    def test_local_proxy(self):
        proxy = LocalProxy(lambda: {"data": "proxy"})
        assert isinstance(proxy, LocalProxy)

    def test_has_request_context(self):
        result = has_request_context()
        assert result is False

    def test_has_app_context(self):
        result = has_app_context()
        assert result is False

    def test_get_request_default(self):
        assert get_request() is None

    def test_get_app_default(self):
        assert get_app() is None


class TestSandboxTypes:
    def test_http_constants(self):
        assert hasattr(HTTP, "METHODS")
        assert "GET" in HTTP.METHODS

    def test_mime_types(self):
        assert MIME.APPLICATION_JSON == "application/json"
        assert MIME.TEXT_HTML == "text/html"
        assert MIME.TEXT_PLAIN == "text/plain"

    def test_status_codes(self):
        assert Status.OK == 200
        assert Status.CREATED == 201
        assert Status.NOT_FOUND == 404

    def test_server_constants(self):
        assert Server.DEFAULT_HOST == "127.0.0.1"
        assert Server.DEFAULT_PORT == 8000

    def test_websocket_constants(self):
        assert WebSocket.CLOSE_NORMAL == 1000
        assert WebSocket.OPCODE_PING == 0x9


class TestSandboxHelpers:
    def test_run_in_threadpool(self):
        def sync_func(x):
            return x * 2

        async def _test():
            return await run_in_threadpool(sync_func, 21)

        result = asyncio.run(_test())
        assert result == 42

    def test_sync_to_async_decorator(self):
        @sync_to_async
        def sync_add(a, b):
            return a + b

        async def _test():
            return await sync_add(1, 2)

        result = asyncio.run(_test())
        assert result == 3


class TestSandboxGateway:
    def test_gateway_creation(self):
        gateway = get_api_gateway()
        assert gateway is not None

    def test_gateway_error_codes(self):
        from kewe.gateway.core import ErrorCode
        assert ErrorCode.SUCCESS.code == 0
        assert ErrorCode.NOT_FOUND.code == 1004

    def test_gateway_response(self):
        from kewe.gateway.core import GatewayResponse
        resp = GatewayResponse(
            request_id="req-1",
            success=True,
            code=0,
            message="OK",
            data={"key": "val"},
        )
        assert resp.success is True
        assert resp.to_dict()["request_id"] == "req-1"

    def test_gateway_error(self):
        from kewe.gateway.core import GatewayError, ErrorCode
        err = GatewayError(ErrorCode.UNAUTHORIZED, "No access")
        assert err.gateway_error_code == ErrorCode.UNAUTHORIZED

    def test_gateway_route_registration(self):
        gateway = get_api_gateway()
        from kewe.gateway.core import GatewayRoute
        route = GatewayRoute(
            path="/test",
            method="GET",
            handler=lambda r: {"ok": True},
        )
        gateway.register_route(route)
        routes = gateway.get_routes()
        assert any(r.path == "/test" for r in routes)

    def test_gateway_trie_router(self):
        from kewe.gateway.core import TrieRouter, GatewayRoute
        trie = TrieRouter()
        route = GatewayRoute(path="/users/{id}", method="GET", handler=lambda r: {})
        trie.add_route(route)
        result = trie.match("/users/42", "GET", "v1")
        assert result is not None
        matched_route, params = result
        assert params.get("id") == "42"

    def test_app_gateway_integration(self):
        app = make_app("gw_integration", enable_gateway=True)
        assert hasattr(app, "gateway")


class TestSandboxMountedSubapp:
    def test_mount_sub_app(self):
        main_app = make_app("main", enable_gateway=False)
        sub_app = make_app("sub", enable_gateway=False)
        main_app.mount("/sub", sub_app)
        assert hasattr(main_app, "_mounted_apps")
        assert len(main_app._mounted_apps) == 1


class TestSandboxHeaders:
    def test_headers_creation(self):
        h = Headers({"content-type": "application/json"})
        assert h["content-type"] == "application/json"

    def test_cimulti_dict(self):
        d = CIMultiDict()
        d["Content-Type"] = "text/html"
        assert d["content-type"] == "text/html"


class TestSandboxASGI:
    def test_asgi_adapter_creation(self):
        app = make_app("asgi_adapter", enable_gateway=False)
        adapter = ASGIAdapter(app)
        assert adapter is not None

    def test_create_asgi_app(self):
        app = make_app("create_asgi", enable_gateway=False)
        asgi_app = create_asgi_app(app)
        assert asgi_app is not None


class TestSandboxLifecycle:
    def test_before_server_start(self):
        app = make_app("lifecycle_before", enable_gateway=False)

        @app.before_server_start
        async def startup_hook(app_instance):
            pass

        assert app is not None

    def test_register_listener(self):
        app = make_app("listener_test", enable_gateway=False)

        @app.register_listener("before_server_start")
        async def on_startup(app_instance, loop=None):
            pass

        assert app is not None


class TestSandboxStatic:
    def test_send_file(self):
        with tempfile.NamedTemporaryFile(suffix=".txt", delete=False, mode='w') as f:
            f.write("send file test")
            f.flush()
            f_name = f.name
        try:
            app = make_app("send_file", enable_gateway=False)
            resp = app.send_file(f_name)
            assert resp.status == 200
        finally:
            try:
                os.unlink(f_name)
            except Exception:
                pass


class TestSandboxOpenAPI:
    def test_register_route_with_tags_and_summary(self):
        app = make_app("openapi1", enable_gateway=False)

        @app.get("/items", tags=["Items"])
        async def list_items(request):
            return kewe_json([])

        client = TestClient(app)
        resp = client.get("/items")
        assert resp.status == 200

    def test_route_with_summary_description(self):
        app = make_app("openapi2", enable_gateway=False)

        @app.get("/products", summary="List products", description="Returns all products")
        async def list_products(request):
            return kewe_json([])

        client = TestClient(app)
        resp = client.get("/products")
        assert resp.status == 200

    def test_route_with_deprecated(self):
        app = make_app("openapi3", enable_gateway=False)

        @app.get("/legacy", deprecated=True)
        async def legacy(request):
            return kewe_json({"ok": True})

        client = TestClient(app)
        resp = client.get("/legacy")
        assert resp.status == 200

    def test_route_with_operation_id(self):
        app = make_app("openapi4", enable_gateway=False)

        @app.get("/custom-op", operation_id="custom_operation")
        async def custom_op(request):
            return kewe_json({})

        client = TestClient(app)
        resp = client.get("/custom-op")
        assert resp.status == 200


class TestSandboxView:
    def test_view_basic(self):
        class MyView(View):
            async def get(self, request):
                return kewe_json({"view": "ok"})

        assert hasattr(MyView, "get")

    def test_method_decorator(self):
        def my_dec(func):
            return func

        decorated = method_decorator(my_dec)
        assert callable(decorated)


class TestSandboxI18n:
    def test_i18n_basic(self):
        app = make_app("i18n_test", enable_gateway=False)
        i18n_instance = app.setup_i18n(default_locale="en")
        assert i18n_instance is not None
        svc = app.get_service("i18n")
        assert svc is not None


class TestSandboxHTTPClient:
    def test_http_client_setup(self):
        app = make_app("http_client", enable_gateway=False)
        client = app.setup_http_client(base_url="http://example.com")
        assert client is not None
        svc = app.get_service("http_client")
        assert svc is not None


class TestSandboxSignals:
    def test_signal_basic(self):
        bus = SignalBus()
        assert bus is not None

    def test_app_signal_registration(self):
        app = make_app("signal_test", enable_gateway=False)
        @app.signal("user.created")
        async def on_user_created(data):
            pass
        assert True


class TestSandboxPerformance:
    def test_orjson_speed(self):
        data = {"key": "value", "nested": {"a": 1, "b": [1, 2, 3]}}
        start = time.perf_counter()
        for _ in range(10000):
            from kewe.utils.compat import json as kewe_json_module
            s = kewe_json_module.dumps(data)
            kewe_json_module.loads(s)
        elapsed = time.perf_counter() - start
        assert elapsed < 2.0

    def test_response_creation_speed(self):
        start = time.perf_counter()
        for _ in range(5000):
            resp = kewe_json({"data": "test"})
        elapsed = time.perf_counter() - start
        assert elapsed < 1.0


class TestSandboxCLI:
    def test_repl_context(self):
        app = make_app("repl_ctxt", enable_gateway=False)
        ctx = app.repl_ctx
        assert ctx is not None


class TestSandboxUtils:
    def test_test_client_property(self):
        app = make_app("tc_prop", enable_gateway=False)
        tc = app.test_client
        assert isinstance(tc, TestClient)


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])