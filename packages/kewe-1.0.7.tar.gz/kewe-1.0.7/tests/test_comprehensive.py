import pytest
import asyncio
import time
import json
import logging
import tempfile
import os
import threading
from unittest.mock import MagicMock, AsyncMock, patch


class TestLRUCacheDeep:
    def test_lru_eviction_order(self):
        from kewe.cache.lru_cache import LRUCache
        cache = LRUCache(max_size=3)
        cache.set("a", 1)
        cache.set("b", 2)
        cache.set("c", 3)
        assert cache.size() == 3
        cache.set("d", 4)
        assert cache.get("a") is None
        assert cache.get("b") == 2
        assert cache.get("c") == 3
        assert cache.get("d") == 4

    def test_lru_get_refreshes_order(self):
        from kewe.cache.lru_cache import LRUCache
        cache = LRUCache(max_size=3)
        cache.set("a", 1)
        cache.set("b", 2)
        cache.set("c", 3)
        cache.get("a")
        cache.set("d", 4)
        assert cache.get("a") == 1
        assert cache.get("b") is None
        assert cache.get("c") == 3
        assert cache.get("d") == 4

    def test_lru_overwrite_keeps_position(self):
        from kewe.cache.lru_cache import LRUCache
        cache = LRUCache(max_size=3)
        cache.set("a", 1)
        cache.set("b", 2)
        cache.set("c", 3)
        cache.set("a", 10)
        assert cache.get("a") == 10
        cache.set("d", 4)
        assert cache.get("a") == 10
        assert cache.get("b") is None

    def test_lru_ttl_expiry(self):
        from kewe.cache.lru_cache import LRUCache
        cache = LRUCache(max_size=10, ttl=0.1)
        cache.set("key", "value")
        assert cache.get("key") == "value"
        time.sleep(0.2)
        assert cache.get("key") is None

    def test_lru_per_key_ttl(self):
        from kewe.cache.lru_cache import LRUCache
        cache = LRUCache(max_size=10)
        cache.set("short", "val1", ttl=0.1)
        cache.set("long", "val2", ttl=10)
        time.sleep(0.2)
        assert cache.get("short") is None
        assert cache.get("long") == "val2"

    def test_lru_has_method(self):
        from kewe.cache.lru_cache import LRUCache
        cache = LRUCache(max_size=10, ttl=0.1)
        cache.set("key", "value")
        assert cache.has("key") is True
        time.sleep(0.2)
        assert cache.has("key") is False

    def test_lru_has_nonexistent(self):
        from kewe.cache.lru_cache import LRUCache
        cache = LRUCache(max_size=10)
        assert cache.has("missing") is False

    def test_lru_delete(self):
        from kewe.cache.lru_cache import LRUCache
        cache = LRUCache(max_size=10)
        cache.set("key", "value")
        assert cache.delete("key") is True
        assert cache.delete("key") is False
        assert cache.get("key") is None

    def test_lru_clear(self):
        from kewe.cache.lru_cache import LRUCache
        cache = LRUCache(max_size=10)
        for i in range(5):
            cache.set(f"k{i}", i)
        cache.clear()
        assert cache.size() == 0
        for i in range(5):
            assert cache.get(f"k{i}") is None

    def test_lru_keys(self):
        from kewe.cache.lru_cache import LRUCache
        cache = LRUCache(max_size=10)
        cache.set("a", 1)
        cache.set("b", 2)
        cache.set("c", 3)
        keys = cache.keys()
        assert set(keys) == {"a", "b", "c"}

    def test_lru_cleanup_expired(self):
        from kewe.cache.lru_cache import LRUCache
        cache = LRUCache(max_size=10)
        cache.set("exp1", "v1", ttl=0.1)
        cache.set("exp2", "v2", ttl=0.1)
        cache.set("keep", "v3", ttl=10)
        time.sleep(0.2)
        cleaned = cache.cleanup_expired()
        assert cleaned == 2
        assert cache.get("keep") == "v3"

    def test_lru_stats(self):
        from kewe.cache.lru_cache import LRUCache
        cache = LRUCache(max_size=10, ttl=60)
        cache.set("a", 1)
        cache.get("a")
        cache.get("missing")
        stats = cache.get_stats()
        assert stats["size"] == 1
        assert stats["max_size"] == 10
        assert stats["hits"] == 1
        assert stats["misses"] == 1
        assert stats["hit_rate"] == 0.5

    def test_lru_default_ttl_vs_ttl_param(self):
        from kewe.cache.lru_cache import LRUCache
        cache = LRUCache(max_size=10, default_ttl=0.1)
        cache.set("a", 1)
        cache.set("b", 2, ttl=10)
        time.sleep(0.2)
        assert cache.get("a") is None
        assert cache.get("b") == 2

    @pytest.mark.asyncio
    async def test_lru_async_get_set(self):
        from kewe.cache.lru_cache import LRUCache
        cache = LRUCache(max_size=10)
        await cache.aset("key", "value")
        result = await cache.aget("key")
        assert result == "value"

    @pytest.mark.asyncio
    async def test_lru_async_delete(self):
        from kewe.cache.lru_cache import LRUCache
        cache = LRUCache(max_size=10)
        await cache.aset("key", "value")
        result = await cache.adelete("key")
        assert result is True
        result2 = await cache.aget("key")
        assert result2 is None

    @pytest.mark.asyncio
    async def test_lru_async_miss(self):
        from kewe.cache.lru_cache import LRUCache
        cache = LRUCache(max_size=10)
        result = await cache.aget("missing")
        assert result is None

    def test_lru_concurrent_access(self):
        from kewe.cache.lru_cache import LRUCache
        cache = LRUCache(max_size=100)
        errors = []

        def worker(tid):
            try:
                for i in range(50):
                    key = f"k_{tid}_{i}"
                    cache.set(key, f"v_{tid}_{i}")
                    val = cache.get(key)
                    assert val == f"v_{tid}_{i}", f"Mismatch: {val}"
            except Exception as e:
                errors.append(str(e))

        threads = [threading.Thread(target=worker, args=(t,)) for t in range(5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        assert len(errors) == 0, f"Concurrency errors: {errors}"


class TestLFUCache:
    @pytest.mark.asyncio
    async def test_lfu_basic_get_set(self):
        from kewe.cache import LFUCache
        cache = LFUCache(max_size=3)
        await cache.set("a", 1)
        await cache.set("b", 2)
        await cache.set("c", 3)
        assert await cache.get("a") == 1
        assert await cache.get("b") == 2
        assert await cache.get("c") == 3

    @pytest.mark.asyncio
    async def test_lfu_eviction_policy(self):
        from kewe.cache import LFUCache
        cache = LFUCache(max_size=3)
        await cache.set("a", 1)
        await cache.set("b", 2)
        await cache.set("c", 3)
        await cache.get("a")
        await cache.get("a")
        await cache.get("b")
        await cache.set("d", 4)
        assert await cache.get("a") == 1
        assert await cache.get("c") is None
        assert await cache.get("d") == 4

    @pytest.mark.asyncio
    async def test_lfu_ttl_expiry(self):
        from kewe.cache import LFUCache
        cache = LFUCache(max_size=10, default_ttl=0.1)
        await cache.set("key", "value")
        assert await cache.get("key") == "value"
        time.sleep(0.2)
        assert await cache.get("key") is None

    @pytest.mark.asyncio
    async def test_lfu_delete(self):
        from kewe.cache import LFUCache
        cache = LFUCache(max_size=10)
        await cache.set("key", "value")
        await cache.delete("key")
        assert await cache.get("key") is None

    @pytest.mark.asyncio
    async def test_lfu_overwrite(self):
        from kewe.cache import LFUCache
        cache = LFUCache(max_size=10)
        await cache.set("key", "old")
        await cache.set("key", "new")
        assert await cache.get("key") == "new"

    @pytest.mark.asyncio
    async def test_lfu_get_nonexistent(self):
        from kewe.cache import LFUCache
        cache = LFUCache(max_size=10)
        assert await cache.get("missing") is None


class TestBloomFilter:
    def test_bloom_add_and_contains(self):
        from kewe.cache import BloomFilter
        bf = BloomFilter(size=10000, hash_count=7)
        bf.add("user:1")
        bf.add("user:2")
        assert bf.contains("user:1") is True
        assert bf.contains("user:2") is True

    def test_bloom_false_negative_impossible(self):
        from kewe.cache import BloomFilter
        bf = BloomFilter(size=100000, hash_count=7)
        for i in range(100):
            bf.add(f"key_{i}")
        for i in range(100):
            assert bf.contains(f"key_{i}") is True

    def test_bloom_absent_key(self):
        from kewe.cache import BloomFilter
        bf = BloomFilter(size=100000, hash_count=7)
        bf.add("existing")
        result = bf.contains("nonexistent_key_xyz")
        assert isinstance(result, bool)


class TestCacheWarmer:
    @pytest.mark.asyncio
    async def test_cache_warmer(self):
        from kewe.cache import CacheWarmer, AdvancedCacheManager as CacheManager
        cm = CacheManager(cache_type="lru", max_size=100)
        warmer = CacheWarmer(cm.cache)
        call_count = 0

        async def loader():
            nonlocal call_count
            call_count += 1
            return "warm_data"

        warmer.register("warm_key", loader)
        await warmer.warm()
        assert call_count == 1
        result = cm.cache.get("warm_key")
        if asyncio.iscoroutine(result):
            result = await result
        assert result == "warm_data"


class TestAdvancedCacheManager:
    @pytest.mark.asyncio
    async def test_cache_manager_get_with_loader(self):
        from kewe.cache import AdvancedCacheManager as CacheManager
        cm = CacheManager(cache_type="lru", max_size=100)
        call_count = 0

        async def loader():
            nonlocal call_count
            call_count += 1
            return "loaded_data"

        result = await cm.get("test_key", loader=loader)
        assert result == "loaded_data"
        assert call_count == 1

    @pytest.mark.asyncio
    async def test_cache_manager_get_cached(self):
        from kewe.cache import AdvancedCacheManager as CacheManager
        cm = CacheManager(cache_type="lru", max_size=100)
        await cm.set("test_key", "cached_value")
        result = await cm.get("test_key")
        assert result == "cached_value"

    @pytest.mark.asyncio
    async def test_cache_manager_invalid_type(self):
        from kewe.cache import AdvancedCacheManager as CacheManager
        with pytest.raises(ValueError, match="Unknown cache type"):
            CacheManager(cache_type="invalid")

    @pytest.mark.asyncio
    async def test_cached_decorator(self):
        from kewe.cache import AdvancedCacheManager as CacheManager, cached
        cm = CacheManager(cache_type="lru", max_size=100)
        call_count = 0

        @cached(cm, ttl=60)
        async def expensive(x):
            nonlocal call_count
            call_count += 1
            return x * 2

        r1 = await expensive(5)
        assert r1 == 10
        assert call_count == 1


class TestServerLifecycle:
    @pytest.mark.asyncio
    async def test_full_lifecycle(self):
        from kewe.server.lifecycle import ServerLifecycle, ServerState
        lc = ServerLifecycle()
        assert lc.state == ServerState.NONE
        assert await lc.start()
        assert lc.state == ServerState.STARTING
        assert await lc.serve()
        assert lc.state == ServerState.SERVING
        assert lc.is_running is True
        assert await lc.stop()
        assert lc.state == ServerState.STOPPING
        assert await lc.finish()
        assert lc.state == ServerState.STOPPED
        assert lc.is_stopped is True

    @pytest.mark.asyncio
    async def test_invalid_transition(self):
        from kewe.server.lifecycle import ServerLifecycle, ServerState
        lc = ServerLifecycle()
        result = await lc.transition_to(ServerState.SERVING)
        assert result is False
        assert lc.state == ServerState.NONE

    @pytest.mark.asyncio
    async def test_restart_from_stopped(self):
        from kewe.server.lifecycle import ServerLifecycle, ServerState
        lc = ServerLifecycle()
        await lc.start()
        await lc.serve()
        await lc.stop()
        await lc.finish()
        assert lc.state == ServerState.STOPPED
        result = await lc.start()
        assert result is True
        assert lc.state == ServerState.STARTING

    @pytest.mark.asyncio
    async def test_startup_failure(self):
        from kewe.server.lifecycle import ServerLifecycle, ServerState
        lc = ServerLifecycle()
        await lc.start()
        result = await lc.transition_to(ServerState.STOPPED, reason="startup failed")
        assert result is True
        assert lc.state == ServerState.STOPPED

    @pytest.mark.asyncio
    async def test_state_handlers(self):
        from kewe.server.lifecycle import ServerLifecycle, ServerState
        lc = ServerLifecycle()
        called = []

        lc.on_state(ServerState.SERVING, lambda: called.append("serving"))
        lc.on_state(ServerState.STOPPED, lambda: called.append("stopped"))

        await lc.start()
        await lc.serve()
        assert "serving" in called
        await lc.stop()
        await lc.finish()
        assert "stopped" in called

    @pytest.mark.asyncio
    async def test_async_state_handlers(self):
        from kewe.server.lifecycle import ServerLifecycle, ServerState
        lc = ServerLifecycle()
        called = []

        async def on_serving():
            called.append("async_serving")

        lc.on_state(ServerState.SERVING, on_serving)
        await lc.start()
        await lc.serve()
        assert "async_serving" in called

    @pytest.mark.asyncio
    async def test_transition_handlers(self):
        from kewe.server.lifecycle import ServerLifecycle, ServerState
        lc = ServerLifecycle()
        transitions = []

        lc.on_transition(lambda f, t: transitions.append((f.name, t.name)))
        await lc.start()
        await lc.serve()
        assert len(transitions) >= 2
        assert transitions[0] == ("NONE", "STARTING")
        assert transitions[1] == ("STARTING", "SERVING")

    @pytest.mark.asyncio
    async def test_decorator_handlers(self):
        from kewe.server.lifecycle import ServerLifecycle, ServerState
        lc = ServerLifecycle()
        called = []

        @lc.on_starting
        def on_start():
            called.append("starting")

        @lc.on_serving
        def on_serve():
            called.append("serving")

        await lc.start()
        assert "starting" in called
        await lc.serve()
        assert "serving" in called

    @pytest.mark.asyncio
    async def test_uptime(self):
        from kewe.server.lifecycle import ServerLifecycle, ServerState
        lc = ServerLifecycle()
        assert lc.uptime is None
        await lc.start()
        await lc.serve()
        uptime = lc.uptime
        assert uptime is not None
        assert uptime >= 0

    @pytest.mark.asyncio
    async def test_state_info(self):
        from kewe.server.lifecycle import ServerLifecycle
        lc = ServerLifecycle()
        await lc.start()
        info = lc.get_state_info()
        assert info["state"] == "STARTING"
        assert info["is_running"] is False
        assert isinstance(info["transitions"], list)

    @pytest.mark.asyncio
    async def test_same_state_transition(self):
        from kewe.server.lifecycle import ServerLifecycle, ServerState
        lc = ServerLifecycle()
        await lc.start()
        result = await lc.transition_to(ServerState.STARTING)
        assert result is True
        assert lc.state == ServerState.STARTING

    @pytest.mark.asyncio
    async def test_handler_exception_does_not_break(self):
        from kewe.server.lifecycle import ServerLifecycle, ServerState
        lc = ServerLifecycle()

        def bad_handler():
            raise RuntimeError("handler error")

        lc.on_state(ServerState.STARTING, bad_handler)
        result = await lc.start()
        assert result is True

    @pytest.mark.asyncio
    async def test_global_lifecycle(self):
        from kewe.server.lifecycle import get_lifecycle, set_lifecycle, ServerLifecycle
        custom = ServerLifecycle()
        set_lifecycle(custom)
        assert get_lifecycle() is custom
        set_lifecycle(ServerLifecycle())


class TestASGIAdapter:
    @pytest.mark.asyncio
    async def test_http_request(self):
        from kewe.server.asgi import ASGIAdapter
        from kewe import Kewe

        app = Kewe("test_asgi", enable_gateway=False)

        @app.get("/hello")
        async def hello(request):
            from kewe.response import json
            return json({"msg": "hello"})

        adapter = ASGIAdapter(app)
        sent = []

        async def receive():
            return {"type": "http.request", "body": b"", "more_body": False}

        async def send(msg):
            sent.append(msg)

        scope = {
            "type": "http",
            "method": "GET",
            "path": "/hello",
            "query_string": b"",
            "headers": [],
            "http_version": "1.1",
            "server": ("127.0.0.1", 8000),
            "client": ("127.0.0.1", 12345),
        }

        await adapter(scope, receive, send)
        assert len(sent) >= 2
        assert sent[0]["type"] == "http.response.start"
        assert sent[0]["status"] == 200

    @pytest.mark.asyncio
    async def test_http_post_with_body(self):
        from kewe.server.asgi import ASGIAdapter
        from kewe import Kewe

        app = Kewe("test_asgi_post", enable_gateway=False)

        @app.post("/echo")
        async def echo(request):
            body = await request.json or {}
            from kewe.response import json
            return json(body)

        adapter = ASGIAdapter(app)
        sent = []

        async def receive():
            return {
                "type": "http.request",
                "body": b'{"name":"test"}',
                "more_body": False,
            }

        async def send(msg):
            sent.append(msg)

        scope = {
            "type": "http",
            "method": "POST",
            "path": "/echo",
            "query_string": b"",
            "headers": [(b"content-type", b"application/json")],
            "http_version": "1.1",
            "server": ("127.0.0.1", 8000),
            "client": ("127.0.0.1", 12345),
        }

        await adapter(scope, receive, send)
        assert sent[0]["status"] == 200

    @pytest.mark.asyncio
    async def test_lifespan_startup_shutdown(self):
        from kewe.server.asgi import ASGIAdapter
        from kewe import Kewe

        app = Kewe("test_lifespan", enable_gateway=False)
        adapter = ASGIAdapter(app)
        sent = []
        messages = [
            {"type": "lifespan.startup"},
            {"type": "lifespan.shutdown"},
        ]
        msg_idx = 0

        async def receive():
            nonlocal msg_idx
            msg = messages[msg_idx]
            msg_idx += 1
            return msg

        async def send(msg):
            sent.append(msg)

        scope = {"type": "lifespan"}
        await adapter(scope, receive, send)
        assert any(m["type"] == "lifespan.startup.complete" for m in sent)
        assert any(m["type"] == "lifespan.shutdown.complete" for m in sent)

    @pytest.mark.asyncio
    async def test_lifespan_startup_failure(self):
        from kewe.server.asgi import ASGIAdapter
        from kewe import Kewe

        app = Kewe("test_lifespan_fail", enable_gateway=False)

        async def bad_startup(a):
            raise RuntimeError("startup error")

        app.register_listener("before_server_start", bad_startup)

        adapter = ASGIAdapter(app)
        sent = []
        msg_idx = 0

        async def receive():
            nonlocal msg_idx
            if msg_idx == 0:
                msg_idx += 1
                return {"type": "lifespan.startup"}
            await asyncio.sleep(0.1)
            return {"type": "lifespan.shutdown"}

        async def send(msg):
            sent.append(msg)

        scope = {"type": "lifespan"}
        await adapter(scope, receive, send)
        assert any(m["type"] == "lifespan.startup.failed" for m in sent)

    @pytest.mark.asyncio
    async def test_unknown_scope_type(self):
        from kewe.server.asgi import ASGIAdapter
        from kewe import Kewe

        app = Kewe("test_unknown_scope", enable_gateway=False)
        adapter = ASGIAdapter(app)
        sent = []

        async def receive():
            return {}

        async def send(msg):
            sent.append(msg)

        scope = {"type": "unknown"}
        await adapter(scope, receive, send)
        assert len(sent) == 0

    @pytest.mark.asyncio
    async def test_asgi_context(self):
        from kewe.server.asgi import ASGIContext, ASGIState
        ctx = ASGIContext(scope={"type": "http"})
        assert ctx.state == ASGIState.REQUEST
        assert ctx.disconnect_received is False
        assert ctx.response_sent is False
        assert ctx.bytes_sent == 0

    @pytest.mark.asyncio
    async def test_asgi_response_builder(self):
        from kewe.server.asgi import ASGIResponse
        resp = ASGIResponse()
        resp.set_status(201)
        resp.set_header("X-Custom", "test")
        resp.write(b"hello")
        assert resp.status == 201
        assert len(resp.headers) == 1
        assert len(resp.body_parts) == 1

    @pytest.mark.asyncio
    async def test_asgi_app_factory(self):
        from kewe.server.asgi import create_asgi_app
        from kewe import Kewe

        def factory():
            app = Kewe("factory_app", enable_gateway=False)

            @app.get("/")
            async def index(request):
                from kewe.response import json
                return json({"ok": True})

            return app

        asgi_handler = create_asgi_app(factory)
        assert callable(asgi_handler)

    @pytest.mark.asyncio
    async def test_asgi_app_shortcut(self):
        from kewe.server.asgi import asgi_app
        from kewe import Kewe

        app = Kewe("shortcut_app", enable_gateway=False)
        adapter = asgi_app(app)
        assert adapter is not None


class TestStreamingHTTPResponse:
    @pytest.mark.asyncio
    async def test_streaming_http_response_creation(self):
        from kewe.response.streaming import StreamingHTTPResponse

        async def gen():
            yield b"chunk1"
            yield b"chunk2"

        resp = StreamingHTTPResponse(gen(), content_type="text/plain")
        assert resp.status == 200
        assert resp.content_type == "text/plain"

    @pytest.mark.asyncio
    async def test_streaming_http_response_with_callable(self):
        from kewe.response.streaming import StreamingHTTPResponse

        async def gen():
            yield b"data"

        resp = StreamingHTTPResponse(gen, content_type="application/octet-stream")
        assert resp.streaming_fn is gen

    @pytest.mark.asyncio
    async def test_streaming_http_response_custom_status(self):
        from kewe.response.streaming import StreamingHTTPResponse

        async def gen():
            yield b"created"

        resp = StreamingHTTPResponse(gen(), status=201)
        assert resp.status == 201

    @pytest.mark.asyncio
    async def test_streaming_http_response_custom_headers(self):
        from kewe.response.streaming import StreamingHTTPResponse

        async def gen():
            yield b"data"

        resp = StreamingHTTPResponse(
            gen(), headers={"X-Stream": "true"}, content_type="text/event-stream"
        )
        assert resp.headers["X-Stream"] == "true"

    @pytest.mark.asyncio
    async def test_sse_response(self):
        from kewe.response.streaming import ServerSentEventResponse

        async def events():
            yield {"event": "update", "data": "hello"}
            yield {"event": "update", "data": "world"}

        resp = ServerSentEventResponse(events())
        assert resp is not None
        assert resp.content_type == "text/event-stream"

    @pytest.mark.asyncio
    async def test_file_stream_response(self):
        from kewe.response.streaming import FileStreamResponse

        with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
            f.write("test file content for streaming")
            temp_path = f.name

        try:
            resp = FileStreamResponse(temp_path)
            assert resp is not None
        finally:
            os.unlink(temp_path)

    @pytest.mark.asyncio
    async def test_file_stream_response_nonexistent(self):
        from kewe.response.streaming import FileStreamResponse

        with pytest.raises((FileNotFoundError, OSError)):
            FileStreamResponse("/nonexistent/path/file.txt")


class TestContextDeep:
    def test_request_context_push_pop(self):
        from kewe.base.context import RequestContext, get_request_ctx
        ctx = RequestContext()
        assert get_request_ctx() is None
        token = ctx._push()
        assert get_request_ctx() is ctx
        ctx._pop()
        assert get_request_ctx() is None

    def test_request_context_context_manager(self):
        from kewe.base.context import RequestContext, get_request_ctx
        with RequestContext() as ctx:
            ctx.set("key", "value")
            assert get_request_ctx() is ctx
            assert ctx.get("key") == "value"
        assert get_request_ctx() is None

    @pytest.mark.asyncio
    async def test_request_context_async_context_manager(self):
        from kewe.base.context import RequestContext, get_request_ctx
        async with RequestContext() as ctx:
            ctx.set("akey", "aval")
            assert get_request_ctx() is ctx
        assert get_request_ctx() is None

    def test_request_context_attr_access(self):
        from kewe.base.context import RequestContext
        ctx = RequestContext()
        ctx.user_id = 42
        assert ctx.user_id == 42
        assert ctx.get("user_id") == 42

    def test_request_context_del_attr(self):
        from kewe.base.context import RequestContext
        ctx = RequestContext()
        ctx.set("key", "value")
        del ctx.key
        assert ctx.get("key") is None

    def test_request_context_setdefault(self):
        from kewe.base.context import RequestContext
        ctx = RequestContext()
        result = ctx.setdefault("key", "default")
        assert result == "default"
        result2 = ctx.setdefault("key", "other")
        assert result2 == "default"

    def test_request_context_pop(self):
        from kewe.base.context import RequestContext
        ctx = RequestContext()
        ctx.set("key", "value")
        result = ctx.pop("key")
        assert result == "value"
        assert ctx.get("key") is None
        result2 = ctx.pop("key", "fallback")
        assert result2 == "fallback"

    def test_request_context_update(self):
        from kewe.base.context import RequestContext
        ctx = RequestContext()
        ctx.update(a=1, b=2)
        assert ctx.get("a") == 1
        assert ctx.get("b") == 2

    def test_request_context_to_dict(self):
        from kewe.base.context import RequestContext
        ctx = RequestContext()
        ctx.set("x", 1)
        ctx.set("y", 2)
        d = ctx.to_dict()
        assert d == {"x": 1, "y": 2}

    def test_request_context_contains(self):
        from kewe.base.context import RequestContext
        ctx = RequestContext()
        ctx.set("key", "value")
        assert "key" in ctx
        assert "missing" not in ctx

    def test_request_context_item_access(self):
        from kewe.base.context import RequestContext
        ctx = RequestContext()
        ctx["key"] = "value"
        assert ctx["key"] == "value"

    def test_request_context_private_attr_error(self):
        from kewe.base.context import RequestContext
        ctx = RequestContext()
        with pytest.raises(AttributeError):
            _ = ctx._nonexistent

    def test_app_context_context_manager(self):
        from kewe.base.context import AppContext, get_app_ctx
        with AppContext() as ctx:
            ctx.set("db", "connection")
            assert get_app_ctx() is ctx
        assert get_app_ctx() is None

    def test_app_context_get_set(self):
        from kewe.base.context import AppContext
        ctx = AppContext()
        ctx.set("key", "value")
        assert ctx.get("key") == "value"
        assert ctx.get("missing") is None
        assert ctx.get("missing", "default") == "default"

    def test_app_context_attr_access(self):
        from kewe.base.context import AppContext
        ctx = AppContext()
        ctx.set("db", "postgres")
        assert ctx.db == "postgres"

    def test_has_request_context(self):
        from kewe.base.context import RequestContext, has_request_ctx
        assert has_request_ctx() is False
        with RequestContext():
            assert has_request_ctx() is True
        assert has_request_ctx() is False

    def test_has_app_context(self):
        from kewe.base.context import AppContext, has_app_context
        assert has_app_context() is False
        with AppContext():
            assert has_app_context() is True
        assert has_app_context() is False

    def test_g_proxy_with_context(self):
        from kewe.base.context import RequestContext, g
        with RequestContext() as ctx:
            g.test_val = 42
            assert g.test_val == 42
            assert ctx.get("test_val") == 42

    def test_g_proxy_item_access(self):
        from kewe.base.context import RequestContext, g
        with RequestContext() as ctx:
            g["test_key"] = "test_value"
            assert g["test_key"] == "test_value"

    def test_g_proxy_contains(self):
        from kewe.base.context import RequestContext, g
        with RequestContext() as ctx:
            g.test_check = True
            assert "test_check" in g

    def test_g_proxy_without_context(self):
        from kewe.base.context import g
        with pytest.raises(RuntimeError):
            g.fallback_val = "fallback"

    def test_local_proxy(self):
        from kewe.base.context import RequestContext, LocalProxy
        proxy = LocalProxy()
        with RequestContext() as ctx:
            ctx.set("key", "value")
            assert proxy.get("key") == "value"

    def test_local_proxy_outside_context(self):
        from kewe.base.context import LocalProxy
        proxy = LocalProxy()
        with pytest.raises(RuntimeError, match="Working outside"):
            proxy._get_current_object()

    def test_local_proxy_get_default_outside_context(self):
        from kewe.base.context import LocalProxy
        proxy = LocalProxy()
        result = proxy.get("key", "default")
        assert result == "default"

    def test_request_context_manager_class(self):
        from kewe.base.context import RequestContextManager
        with RequestContextManager() as ctx:
            ctx.set("key", "value")
            assert ctx.get("key") == "value"

    @pytest.mark.asyncio
    async def test_request_context_manager_async(self):
        from kewe.base.context import RequestContextManager
        async with RequestContextManager() as ctx:
            ctx.set("key", "value")
            assert ctx.get("key") == "value"

    def test_context_property_descriptor(self):
        from kewe.base.context import RequestContext, ContextProperty

        class MyContext(RequestContext):
            user_id: int = ContextProperty("user_id", default=0)

        ctx = MyContext()
        assert ctx.user_id == 0
        ctx.user_id = 42
        assert ctx.user_id == 42

    def test_local_storage(self):
        from kewe.base.context import LocalStorage, RequestContext
        ls = LocalStorage()
        with RequestContext() as ctx:
            ls.test_key = "test_value"
            assert ls.test_key == "test_value"

    def test_local_storage_without_context(self):
        from kewe.base.context import LocalStorage
        ls = LocalStorage()
        ls.persistent = "value"
        assert ls.persistent == "value"

    def test_context_isolation_between_async_tasks(self):
        from kewe.base.context import RequestContext, get_request_ctx
        results = {}

        async def task(name, value):
            with RequestContext() as ctx:
                ctx.set("val", value)
                await asyncio.sleep(0.01)
                results[name] = get_request_ctx().get("val")

        async def run():
            await asyncio.gather(
                task("a", 1),
                task("b", 2),
                task("c", 3),
            )

        asyncio.run(run())
        assert results["a"] == 1
        assert results["b"] == 2
        assert results["c"] == 3


class TestStructuredLogging:
    def test_json_formatter(self):
        from kewe.logging.formatters import JSONFormatter
        formatter = JSONFormatter()
        record = logging.LogRecord(
            name="kewe.test",
            level=logging.INFO,
            pathname="test.py",
            lineno=1,
            msg="test message",
            args=(),
            exc_info=None,
        )
        output = formatter.format(record)
        data = json.loads(output)
        assert data["level"] == "INFO"
        assert data["message"] == "test message"
        assert data["logger"] == "kewe.test"
        assert "timestamp" in data

    def test_json_formatter_with_http_fields(self):
        from kewe.logging.formatters import JSONFormatter
        formatter = JSONFormatter()
        record = logging.LogRecord(
            name="kewe.access",
            level=logging.INFO,
            pathname="test.py",
            lineno=1,
            msg="access log",
            args=(),
            exc_info=None,
        )
        record.method = "GET"
        record.path = "/api/test"
        record.status = 200
        record.client_ip = "127.0.0.1"
        output = formatter.format(record)
        data = json.loads(output)
        assert data["method"] == "GET"
        assert data["path"] == "/api/test"
        assert data["status"] == 200

    def test_json_formatter_with_exception(self):
        from kewe.logging.formatters import JSONFormatter
        formatter = JSONFormatter()
        try:
            raise ValueError("test error")
        except ValueError:
            import sys
            exc_info = sys.exc_info()

        record = logging.LogRecord(
            name="kewe.test",
            level=logging.ERROR,
            pathname="test.py",
            lineno=1,
            msg="error occurred",
            args=(),
            exc_info=exc_info,
        )
        output = formatter.format(record)
        data = json.loads(output)
        assert "exception" in data
        assert data["exception"]["type"] == "ValueError"

    def test_json_formatter_custom_fields(self):
        from kewe.logging.formatters import JSONFormatter
        formatter = JSONFormatter(fields=["timestamp", "level", "message"])
        record = logging.LogRecord(
            name="kewe.test",
            level=logging.INFO,
            pathname="test.py",
            lineno=1,
            msg="minimal",
            args=(),
            exc_info=None,
        )
        output = formatter.format(record)
        data = json.loads(output)
        assert "timestamp" in data
        assert "level" in data
        assert "message" in data

    def test_colored_formatter(self):
        from kewe.logging.formatters import ColoredFormatter
        formatter = ColoredFormatter(
            fmt="%(levelname)s - %(message)s", use_colors=False
        )
        record = logging.LogRecord(
            name="kewe.test",
            level=logging.WARNING,
            pathname="test.py",
            lineno=1,
            msg="warning msg",
            args=(),
            exc_info=None,
        )
        output = formatter.format(record)
        assert "WARNING" in output
        assert "warning msg" in output

    def test_access_log_formatter(self):
        from kewe.logging.access import AccessLogFormatter, AccessLogRecord
        formatter = AccessLogFormatter()
        record = AccessLogRecord(
            client_ip="127.0.0.1",
            method="GET",
            path="/api/test",
            status=200,
            content_length=1024,
            referer="-",
            user_agent="test-agent",
            duration=1.5,
        )
        output = formatter.format_record(record)
        assert "127.0.0.1" in output
        assert "GET" in output
        assert "/api/test" in output

    def test_detailed_formatter(self):
        from kewe.logging.formatters import DetailedFormatter
        formatter = DetailedFormatter(use_colors=False)
        record = logging.LogRecord(
            name="kewe.test",
            level=logging.ERROR,
            pathname="test.py",
            lineno=42,
            msg="detailed error",
            args=(),
            exc_info=None,
        )
        record.funcName = "test_func"
        output = formatter.format(record)
        assert "ERROR" in output
        assert "detailed error" in output

    def test_create_formatter(self):
        from kewe.logging.formatters import create_formatter
        f1 = create_formatter("colored", use_colors=False)
        f2 = create_formatter("json")
        f3 = create_formatter("access", use_colors=False)
        f4 = create_formatter("detailed", use_colors=False)
        assert f1 is not None
        assert f2 is not None
        assert f3 is not None
        assert f4 is not None


class TestLoggingFilters:
    def test_access_log_filter(self):
        from kewe.logging.filters import AccessLogFilter
        f = AccessLogFilter()
        record = logging.LogRecord(
            name="test", level=logging.INFO, pathname="", lineno=0,
            msg="", args=(), exc_info=None,
        )
        result = f.filter(record)
        assert result is True
        assert hasattr(record, "method")
        assert hasattr(record, "path")
        assert hasattr(record, "status")

    def test_error_log_filter(self):
        from kewe.logging.filters import ErrorLogFilter
        f = ErrorLogFilter()
        error_record = logging.LogRecord(
            name="test", level=logging.ERROR, pathname="", lineno=0,
            msg="", args=(), exc_info=None,
        )
        info_record = logging.LogRecord(
            name="test", level=logging.INFO, pathname="", lineno=0,
            msg="", args=(), exc_info=None,
        )
        assert f.filter(error_record) is True
        assert f.filter(info_record) is False

    def test_exclude_pattern_filter(self):
        from kewe.logging.filters import ExcludePatternFilter
        f = ExcludePatternFilter(exclude_patterns=["noise", "debug"])
        record1 = logging.LogRecord(
            name="test", level=logging.INFO, pathname="", lineno=0,
            msg="this is noise", args=(), exc_info=None,
        )
        record2 = logging.LogRecord(
            name="test", level=logging.INFO, pathname="", lineno=0,
            msg="important message", args=(), exc_info=None,
        )
        assert f.filter(record1) is False
        assert f.filter(record2) is True


class TestLoggingSetup:
    def test_setup_logging_default(self):
        from kewe.logging.setup import setup_logging, reset_logging
        setup_logging()
        kewe_logger = logging.getLogger("kewe")
        assert kewe_logger.level == logging.INFO
        reset_logging()

    def test_setup_logging_json(self):
        from kewe.logging.setup import setup_logging, reset_logging
        setup_logging(json_format=True)
        kewe_logger = logging.getLogger("kewe")
        assert len(kewe_logger.handlers) > 0
        reset_logging()

    def test_setup_logging_custom_level(self):
        from kewe.logging.setup import setup_logging, reset_logging
        setup_logging(level=logging.DEBUG)
        kewe_logger = logging.getLogger("kewe")
        assert kewe_logger.level == logging.DEBUG
        reset_logging()

    def test_setup_logging_with_config(self):
        from kewe.logging.setup import setup_logging, reset_logging
        config = {
            "version": 1,
            "handlers": {
                "console": {
                    "class": "logging.StreamHandler",
                    "level": "INFO",
                }
            },
            "root": {
                "level": "INFO",
                "handlers": ["console"],
            },
        }
        setup_logging(log_config=config)
        reset_logging()

    def test_reset_logging(self):
        from kewe.logging.setup import setup_logging, reset_logging
        setup_logging()
        reset_logging()
        kewe_logger = logging.getLogger("kewe")
        assert len(kewe_logger.handlers) == 0


class TestBackgroundTasks:
    @pytest.mark.asyncio
    async def test_task_manager_run_in_background(self):
        from kewe.background.tasks import TaskManager
        manager = TaskManager()
        results = []

        async def coro():
            results.append("done")

        task = await manager.run_in_background(coro())
        await task
        assert "done" in results

    @pytest.mark.asyncio
    async def test_task_manager_background_error(self):
        from kewe.background.tasks import TaskManager
        manager = TaskManager()

        async def failing():
            raise RuntimeError("task failed")

        task = await manager.run_in_background(failing())
        try:
            await task
        except RuntimeError:
            pass
        assert task.done()

    @pytest.mark.asyncio
    async def test_task_config_defaults(self):
        from kewe.background.tasks import TaskConfig
        config = TaskConfig()
        assert config.broker_url == "redis://localhost:6379/0"
        assert config.task_serializer == "json"
        assert config.timezone == "UTC"

    def test_task_config_accept_content(self):
        from kewe.background.tasks import TaskConfig
        config = TaskConfig()
        assert config.accept_content == ["json"]

    @pytest.mark.asyncio
    async def test_get_task_manager(self):
        from kewe.background.tasks import get_task_manager
        manager = get_task_manager()
        assert manager is not None

    def test_async_task_processor(self):
        from kewe.background.async_task_processor import AsyncTaskProcessor
        processor = AsyncTaskProcessor(max_workers=2)
        processor.start()
        assert processor.running is True
        processor.stop()
        assert processor.running is False

    def test_async_task_processor_submit(self):
        from kewe.background.async_task_processor import AsyncTaskProcessor
        processor = AsyncTaskProcessor(max_workers=2)
        processor.start()
        results = []

        def task_fn():
            results.append("executed")

        processor.submit_task(task_fn)
        time.sleep(0.5)
        processor.stop()
        assert "executed" in results

    def test_async_task_processor_not_running(self):
        from kewe.background.async_task_processor import AsyncTaskProcessor
        processor = AsyncTaskProcessor(max_workers=2)
        results = []

        def task_fn():
            results.append("should not run")

        processor.submit_task(task_fn)
        time.sleep(0.1)
        assert "should not run" not in results


class TestStartupManager:
    def test_startup_config(self):
        from kewe.server.startup import StartupConfig
        config = StartupConfig()
        assert config is not None

    def test_startup_manager(self):
        from kewe.server.startup import StartupManager
        from kewe import Kewe
        app = Kewe("startup_test", enable_gateway=False)
        manager = StartupManager(app)
        assert manager is not None


class TestBinaryFileHandling:
    @pytest.mark.asyncio
    async def test_binary_response_body(self):
        from kewe.response import Response
        binary_data = b"\x00\x01\x02\x03\xff\xfe\xfd"
        resp = Response(body=binary_data, content_type="application/octet-stream")
        assert resp.body == binary_data
        assert resp.content_type == "application/octet-stream"

    @pytest.mark.asyncio
    async def test_binary_image_response(self):
        from kewe.response import Response
        png_header = b"\x89PNG\r\n\x1a\n"
        resp = Response(body=png_header, content_type="image/png")
        assert resp.body == png_header

    def test_file_stream_response_binary(self):
        from kewe.response.streaming import FileStreamResponse
        binary_data = bytes(range(256))
        with tempfile.NamedTemporaryFile(mode="wb", suffix=".bin", delete=False) as f:
            f.write(binary_data)
            temp_path = f.name

        try:
            resp = FileStreamResponse(temp_path, content_type="application/octet-stream")
            assert resp is not None
        finally:
            os.unlink(temp_path)

    @pytest.mark.asyncio
    async def test_file_storage_binary(self):
        from kewe.request.uploads import FileStorage
        import io

        binary_data = b"\x00\x01\x02\x03\xff\xfe\xfd"
        fs = FileStorage(
            stream=io.BytesIO(binary_data),
            filename="data.bin",
            name="file",
            content_type="application/octet-stream",
        )
        assert fs.filename == "data.bin"
        assert fs.content_type == "application/octet-stream"
        content = await fs.read()
        assert content == binary_data

    def test_file_validator_binary(self):
        from kewe.request.uploads import FileValidator, FileStorage
        import io

        validator = FileValidator(
            allowed_extensions=[".bin", ".dat"],
            max_size=1024 * 1024,
        )
        fs = FileStorage(
            stream=io.BytesIO(b"\x00\x01"),
            filename="data.bin",
            name="file",
            content_type="application/octet-stream",
        )
        errors = validator.validate(fs)
        assert len(errors) == 0

        fs_bad = FileStorage(
            stream=io.BytesIO(b"\x00\x01"),
            filename="data.exe",
            name="file",
            content_type="application/octet-stream",
        )
        errors = validator.validate(fs_bad)
        assert len(errors) > 0


class TestPydanticSupport:
    @pytest.mark.asyncio
    async def test_pydantic_validation_basic(self):
        try:
            from pydantic import BaseModel
            from kewe.plugins.pydantic_support import validate_data

            class UserModel(BaseModel):
                name: str
                age: int

            result = validate_data(UserModel, {"name": "Alice", "age": 30})
            assert result.name == "Alice"
            assert result.age == 30
        except ImportError:
            pytest.skip("Pydantic not installed")

    @pytest.mark.asyncio
    async def test_pydantic_validation_error(self):
        try:
            from pydantic import BaseModel
            from kewe.plugins.pydantic_support import validate_data
            from pydantic import ValidationError as PydanticValidationError

            class UserModel(BaseModel):
                name: str
                age: int

            with pytest.raises(PydanticValidationError):
                validate_data(UserModel, {"name": "Alice", "age": "not_a_number"})
        except ImportError:
            pytest.skip("Pydantic not installed")

    @pytest.mark.asyncio
    async def test_pydantic_validate_json(self):
        try:
            from pydantic import BaseModel
            from kewe.plugins.pydantic_support import validate_json

            class UserModel(BaseModel):
                name: str
                age: int

            json_str = '{"name": "Bob", "age": 25}'
            result = validate_json(UserModel, json_str)
            assert result.name == "Bob"
            assert result.age == 25
        except ImportError:
            pytest.skip("Pydantic not installed")

    @pytest.mark.asyncio
    async def test_pydantic_model_to_dict(self):
        try:
            from pydantic import BaseModel
            from kewe.plugins.pydantic_support import model_to_dict

            class UserModel(BaseModel):
                name: str
                age: int

            user = UserModel(name="Charlie", age=35)
            d = model_to_dict(user)
            assert d["name"] == "Charlie"
            assert d["age"] == 35
        except ImportError:
            pytest.skip("Pydantic not installed")

    @pytest.mark.asyncio
    async def test_pydantic_model_to_json(self):
        try:
            from pydantic import BaseModel
            from kewe.plugins.pydantic_support import model_to_json

            class UserModel(BaseModel):
                name: str
                age: int

            user = UserModel(name="Dave", age=40)
            j = model_to_json(user)
            data = json.loads(j)
            assert data["name"] == "Dave"
            assert data["age"] == 40
        except ImportError:
            pytest.skip("Pydantic not installed")

    @pytest.mark.asyncio
    async def test_pydantic_create_model(self):
        try:
            from kewe.plugins.pydantic_support import create_model

            DynamicModel = create_model(
                "DynamicModel",
                name=(str, "default"),
                count=(int, 0),
            )
            instance = DynamicModel()
            assert instance.name == "default"
            assert instance.count == 0
        except ImportError:
            pytest.skip("Pydantic not installed")


class TestRequestValidation:
    def test_field_type_enum(self):
        from kewe.application.depends import  FieldType
        assert FieldType.STRING is not None
        assert FieldType.INTEGER is not None
        assert FieldType.BOOLEAN is not None

    def test_field_creation(self):
        from kewe.application.depends import  Field, FieldType
        f = Field(name="username", type=FieldType.STRING, required=True, min_length=3)
        assert f.name == "username"
        assert f.required is True
        assert f.min_length == 3

    def test_validator_creation(self):
        from kewe.application.depends import  Validator, Field, FieldType
        fields = [Field(name="test", type=FieldType.STRING)]
        v = Validator(fields)
        assert v is not None

    def test_request_validator(self):
        from kewe.application.depends import  RequestValidator
        rv = RequestValidator()
        assert rv is not None

    def test_validate_function(self):
        from kewe.application.depends import  Validator, Field, FieldType, FieldValidationError
        fields = [
            Field(name="name", type=FieldType.STRING, required=True),
        ]
        validator = Validator(fields)
        result = validator.validate({"name": "test"})
        assert result["name"] == "test"

        with pytest.raises(FieldValidationError):
            validator.validate({})

    def test_validation_error(self):
        from kewe.application.depends import  FieldValidationError
        err = FieldValidationError("Invalid field")
        assert "Invalid field" in str(err)


class TestFullChainIntegration:
    def test_login_to_protected_resource(self):
        from kewe import Kewe
        from kewe.response import json as json_resp
        from kewe.security.rbac_manager import RBACManager

        app = Kewe("integration_test", enable_gateway=False)
        rbac = RBACManager()
        rbac.add_permission_to_role("admin", "delete_user")
        rbac.assign_role_to_user("admin_user", "admin")

        @app.post("/auth/login")
        async def login(request):
            body = await request.json or {}
            if body.get("username") == "admin" and body.get("password") == "pass":
                return json_resp({"token": "admin_token", "user_id": "admin_user"})
            return json_resp({"error": "unauthorized"}, status=401)

        @app.get("/protected")
        async def protected(request):
            auth = request.headers.get("authorization", "")
            if not auth.startswith("Bearer "):
                from kewe.errors.exceptions import Unauthorized
                raise Unauthorized("Missing token")
            token = auth[7:]
            if token != "admin_token":
                from kewe.errors.exceptions import Forbidden
                raise Forbidden("Invalid token")
            return json_resp({"data": "secret"})

        @app.delete("/admin/users/<uid:str>")
        async def delete_user(request):
            auth = request.headers.get("authorization", "")
            token = auth[7:] if auth.startswith("Bearer ") else ""
            if token != "admin_token":
                from kewe.errors.exceptions import Forbidden
                raise Forbidden("Not admin")
            uid = request.ctx.path_params.get("uid")
            if not rbac.has_permission("admin_user", "delete_user"):
                from kewe.errors.exceptions import Forbidden
                raise Forbidden("No permission")
            return json_resp({"deleted": uid})

        client = app.test_client

        resp = client.post("/auth/login", json={"username": "admin", "password": "pass"})
        assert resp.status == 200
        token = json.loads(resp.body)["token"]

        resp = client.get("/protected", headers={"authorization": f"Bearer {token}"})
        assert resp.status == 200

        resp = client.get("/protected")
        assert resp.status == 401

        resp = client.delete("/admin/users/123", headers={"authorization": f"Bearer {token}"})
        assert resp.status == 200

        resp = client.delete("/admin/users/123", headers={"authorization": "Bearer bad"})
        assert resp.status == 403

    def test_crud_with_cache(self):
        from kewe import Kewe
        from kewe.response import json as json_resp
        from kewe.cache import MemoryCache

        app = Kewe("crud_cache_test", enable_gateway=False)
        cache = MemoryCache()
        db = {}

        @app.get("/items/<item_id:str>")
        async def get_item(request):
            item_id = request.ctx.path_params.get("item_id")
            cached = cache.get(f"item:{item_id}")
            if cached:
                return json_resp(cached)
            if item_id not in db:
                from kewe.errors.exceptions import NotFound
                raise NotFound("Not found")
            item = db[item_id]
            cache.set(f"item:{item_id}", item, ttl=60)
            return json_resp(item)

        @app.post("/items")
        async def create_item(request):
            body = await request.json or {}
            item_id = str(len(db) + 1)
            body["id"] = item_id
            db[item_id] = body
            cache.set(f"item:{item_id}", body, ttl=60)
            return json_resp(body, status=201)

        @app.put("/items/<item_id:str>")
        async def update_item(request):
            item_id = request.ctx.path_params.get("item_id")
            body = await request.json or {}
            body["id"] = item_id
            db[item_id] = body
            cache.set(f"item:{item_id}", body, ttl=60)
            return json_resp(body)

        @app.delete("/items/<item_id:str>")
        async def delete_item(request):
            item_id = request.ctx.path_params.get("item_id")
            if item_id in db:
                del db[item_id]
            cache.delete(f"item:{item_id}")
            return json_resp({"deleted": True})

        client = app.test_client

        resp = client.post("/items", json={"name": "Widget"})
        assert resp.status == 201
        item_id = json.loads(resp.body)["id"]

        resp = client.get(f"/items/{item_id}")
        assert resp.status == 200

        resp = client.put(f"/items/{item_id}", json={"name": "Widget Pro"})
        assert resp.status == 200

        resp = client.delete(f"/items/{item_id}")
        assert resp.status == 200

    def test_middleware_auth_chain(self):
        from kewe import Kewe
        from kewe.response import json as json_resp

        app = Kewe("mw_auth_test", enable_gateway=False)
        request_log = []

        @app.middleware("request")
        async def log_request(request):
            request_log.append(("request", request.path))
            return True

        @app.middleware("response")
        async def log_response(request, response):
            request_log.append(("response", request.path))
            return response

        @app.get("/api/public")
        async def public(request):
            return json_resp({"public": True})

        @app.get("/api/private")
        async def private(request):
            auth = request.headers.get("authorization", "")
            if not auth:
                from kewe.errors.exceptions import Unauthorized
                raise Unauthorized("Need auth")
            return json_resp({"private": True})

        client = app.test_client

        resp = client.get("/api/public")
        assert resp.status == 200
        assert len(request_log) >= 2

        resp = client.get("/api/private")
        assert resp.status == 401

        resp = client.get("/api/private", headers={"authorization": "Bearer token"})
        assert resp.status == 200


class TestConcurrencyStress:
    def test_concurrent_lru_cache(self):
        from kewe.cache.lru_cache import LRUCache
        cache = LRUCache(max_size=500)
        errors = []

        def worker(tid):
            try:
                for i in range(100):
                    key = f"k_{tid}_{i}"
                    cache.set(key, f"v_{tid}_{i}")
                    val = cache.get(key)
                    if val != f"v_{tid}_{i}":
                        errors.append(f"Mismatch for {key}: got {val}")
            except Exception as e:
                errors.append(str(e))

        threads = [threading.Thread(target=worker, args=(t,)) for t in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        assert len(errors) == 0, f"LRU concurrency errors: {errors}"

    def test_concurrent_memory_cache(self):
        from kewe.cache import MemoryCache
        cache = MemoryCache()
        errors = []

        def worker(tid):
            try:
                for i in range(100):
                    key = f"k_{tid}_{i}"
                    cache.set(key, f"v_{tid}_{i}")
                    val = cache.get(key)
                    if val != f"v_{tid}_{i}":
                        errors.append(f"Mismatch for {key}: got {val}")
            except Exception as e:
                errors.append(str(e))

        threads = [threading.Thread(target=worker, args=(t,)) for t in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        assert len(errors) == 0, f"MemoryCache concurrency errors: {errors}"

    def test_stress_route_lookup(self):
        from kewe import Kewe
        from kewe.response import json as json_resp

        app = Kewe("stress_routes", enable_gateway=False)
        for i in range(200):
            exec(
                f"""
@app.get("/api/r{i}")
async def handler_{i}(request):
    return json_resp({{"id": {i}}})
""",
                {"app": app, "json_resp": json_resp},
            )

        client = app.test_client
        for i in range(200):
            resp = client.get(f"/api/r{i}")
            assert resp.status == 200, f"Failed for /api/r{i}"

    def test_stress_cache_operations(self):
        from kewe.cache import MemoryCache
        cache = MemoryCache()
        for i in range(5000):
            cache.set(f"key_{i}", f"value_{i}", ttl=60)
        for i in range(5000):
            val = cache.get(f"key_{i}")
            assert val == f"value_{i}", f"Cache miss at {i}"
        cache.clear()

    def test_concurrent_context_isolation(self):
        from kewe.base.context import RequestContext, get_request_ctx
        errors = []

        def worker(tid):
            try:
                with RequestContext() as ctx:
                    ctx.set("tid", tid)
                    time.sleep(0.01)
                    current = get_request_ctx()
                    if current.get("tid") != tid:
                        errors.append(f"Context leak: expected {tid}, got {current.get('tid')}")
            except Exception as e:
                errors.append(str(e))

        threads = [threading.Thread(target=worker, args=(t,)) for t in range(20)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        assert len(errors) == 0, f"Context isolation errors: {errors}"

    @pytest.mark.asyncio
    async def test_async_concurrent_requests(self):
        from kewe import Kewe
        from kewe.response import json as json_resp

        app = Kewe("async_concurrent", enable_gateway=False)
        counter = {"value": 0}

        @app.get("/increment")
        async def increment(request):
            counter["value"] += 1
            return json_resp({"count": counter["value"]})

        client = app.test_client
        results = []
        for _ in range(50):
            resp = client.get("/increment")
            results.append(resp.status)
        assert all(s == 200 for s in results)
        assert counter["value"] == 50


class TestStreamingCore:
    def test_stream_config(self):
        from kewe.response.streaming import StreamConfig
        config = StreamConfig()
        assert config is not None

    def test_stream_buffer(self):
        from kewe.response.streaming import StreamBuffer
        buffer = StreamBuffer()
        assert buffer is not None

    def test_validate_file(self):
        from kewe.response.streaming import validate_file
        from datetime import datetime
        with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as f:
            f.write("test")
            temp_path = f.name
        try:
            result = validate_file({}, datetime.utcnow())
            assert result is None
        finally:
            os.unlink(temp_path)

    def test_validate_file_not_modified(self):
        from kewe.response.streaming import validate_file
        from datetime import datetime
        now = datetime.utcnow()
        headers = {"if-modified-since": now.strftime("%a, %d %b %Y %H:%M:%S GMT")}
        result = validate_file(headers, now)
        assert result is not None
        assert result.status == 304

    def test_validate_file_nonexistent(self):
        from kewe.response.streaming import validate_file
        from datetime import datetime
        result = validate_file({}, datetime.utcnow())
        assert result is None


class TestResponseStreaming:
    def test_streaming_response(self):
        from kewe.response import StreamingResponse

        async def gen():
            yield b"chunk1"
            yield b"chunk2"

        resp = StreamingResponse(body=gen(), content_type="text/plain")
        assert resp.is_streaming is True
        assert resp.stream_generator is not None

    def test_response_not_streaming(self):
        from kewe.response import json
        resp = json({"data": "test"})
        assert resp.is_streaming is False

    def test_response_binary_body(self):
        from kewe.response import Response
        resp = Response(body=b"\x00\x01\x02", content_type="application/octet-stream")
        assert resp.body == b"\x00\x01\x02"

    def test_response_type_safety(self):
        from kewe.response import Response
        r_int = Response(body=12345)
        assert r_int.body == b"12345"
        r = Response(body=None)
        assert r.body == b''
        r = Response(body={"key": "value"})
        assert b'"key"' in r.body


class TestKeweLogger:
    def test_kewe_logger(self):
        from kewe.logging.logger import KeweLogger, get_logger
        logger = get_logger("test_module")
        assert logger is not None

    def test_kewe_logger_methods(self):
        from kewe.logging.logger import KeweLogger, get_logger
        logger = get_logger("test_methods")
        logger.info("info message")
        logger.warning("warning message")
        logger.error("error message")
        logger.debug("debug message")


class TestShortcutRoutes:
    def test_app_get_shortcut(self):
        from kewe import Kewe
        from kewe.response import json as json_resp

        app = Kewe("shortcut_get", enable_gateway=False)

        @app.get("/hello")
        async def hello(request):
            return json_resp({"msg": "hello"})

        client = app.test_client
        resp = client.get("/hello")
        assert resp.status == 200

    def test_app_post_shortcut(self):
        from kewe import Kewe
        from kewe.response import json as json_resp

        app = Kewe("shortcut_post", enable_gateway=False)

        @app.post("/data")
        async def create(request):
            return json_resp({"created": True}, status=201)

        client = app.test_client
        resp = client.post("/data", json={"name": "test"})
        assert resp.status == 201

    def test_app_put_shortcut(self):
        from kewe import Kewe
        from kewe.response import json as json_resp

        app = Kewe("shortcut_put", enable_gateway=False)

        @app.put("/data/<item_id:str>")
        async def update(request):
            return json_resp({"updated": True})

        client = app.test_client
        resp = client.put("/data/123", json={"name": "updated"})
        assert resp.status == 200

    def test_app_delete_shortcut(self):
        from kewe import Kewe
        from kewe.response import json as json_resp

        app = Kewe("shortcut_delete", enable_gateway=False)

        @app.delete("/data/<item_id:str>")
        async def delete(request):
            return json_resp({"deleted": True})

        client = app.test_client
        resp = client.delete("/data/123")
        assert resp.status == 200

    def test_app_patch_shortcut(self):
        from kewe import Kewe
        from kewe.response import json as json_resp

        app = Kewe("shortcut_patch", enable_gateway=False)

        @app.patch("/data/<item_id:str>")
        async def patch(request):
            return json_resp({"patched": True})

        client = app.test_client
        resp = client.patch("/data/123", json={"name": "patched"})
        assert resp.status == 200


class TestBackgroundTasks:
    def test_background_task_creation(self):
        from kewe.response import BackgroundTask, BackgroundTasks

        async def send_email(to: str):
            pass

        task = BackgroundTask(send_email, "user@example.com")
        assert task.func is send_email
        assert task.args == ("user@example.com",)

    def test_background_tasks_add(self):
        from kewe.response import BackgroundTasks

        tasks = BackgroundTasks()
        tasks.add_task(lambda: None)
        tasks.add_task(lambda x: None, "arg")
        assert len(tasks.tasks) == 2

    @pytest.mark.asyncio
    async def test_background_tasks_run(self):
        from kewe.response import BackgroundTasks
        executed = []

        async def task1():
            executed.append("task1")

        def task2():
            executed.append("task2")

        tasks = BackgroundTasks()
        tasks.add_task(task1)
        tasks.add_task(task2)
        await tasks.run()
        assert "task1" in executed
        assert "task2" in executed

    @pytest.mark.asyncio
    async def test_background_tasks_error_handling(self):
        from kewe.response import BackgroundTasks
        executed = []

        async def failing_task():
            raise RuntimeError("task error")

        async def good_task():
            executed.append("good")

        tasks = BackgroundTasks()
        tasks.add_task(failing_task)
        tasks.add_task(good_task)
        await tasks.run()
        assert "good" in executed

    def test_response_background_attribute(self):
        from kewe.response import Response, BackgroundTasks

        resp = Response()
        assert resp.background is None

        tasks = BackgroundTasks()
        tasks.add_task(lambda: None)
        resp.background = tasks
        assert resp.background is not None
        assert len(resp.background.tasks) == 1


class TestRequestEnhancements:
    def test_request_url_property(self):
        from kewe.request import Request

        req = Request(
            method="GET",
            path="/api/users",
            headers={"host": "example.com"},
            query_params={"page": ["1"], "limit": ["10"]},
            body=b"",
            client_ip="127.0.0.1",
        )
        assert "example.com" in req.url
        assert "/api/users" in req.url
        assert "page=1" in req.url

    def test_request_url_no_query(self):
        from kewe.request import Request

        req = Request(
            method="GET",
            path="/api/users",
            headers={"host": "example.com"},
            query_params={},
            body=b"",
            client_ip="127.0.0.1",
        )
        assert req.url == "http://example.com/api/users"

    def test_request_base_url(self):
        from kewe.request import Request

        req = Request(
            method="GET",
            path="/api/users",
            headers={"host": "example.com"},
            query_params={},
            body=b"",
            client_ip="127.0.0.1",
        )
        assert req.base_url == "http://example.com"

    def test_request_scope_property(self):
        from kewe.request import Request

        req = Request(
            method="GET",
            path="/",
            headers={},
            query_params={},
            body=b"",
            client_ip="127.0.0.1",
        )
        assert req.scope is None
        req.scope = {"type": "http", "method": "GET"}
        assert req.scope["type"] == "http"

    def test_request_path_params_direct(self):
        from kewe.request import Request

        req = Request(
            method="GET",
            path="/users/123",
            headers={},
            query_params={},
            body=b"",
            client_ip="127.0.0.1",
        )
        req.ctx.path_params = {"user_id": "123"}
        assert req.path_params["user_id"] == "123"


class TestValidation422:
    def test_pydantic_validation_returns_422(self):
        from kewe import Kewe
        from kewe.response import json as json_resp

        app = Kewe("test_422", enable_gateway=False)

        try:
            from pydantic import BaseModel

            class UserModel(BaseModel):
                name: str
                age: int

            @app.post("/validate")
            async def validate_handler(request, user: UserModel):
                return json_resp({"name": user.name, "age": user.age})

            client = app.test_client
            resp = client.post("/validate", json={"name": "Alice", "age": "not_a_number"})
            assert resp.status == 422
        except ImportError:
            pytest.skip("Pydantic not installed")

    def test_pydantic_validation_success(self):
        from kewe import Kewe
        from kewe.response import json as json_resp

        app = Kewe("test_422_ok", enable_gateway=False)

        try:
            from pydantic import BaseModel

            class UserModel(BaseModel):
                name: str
                age: int

            @app.post("/validate")
            async def validate_handler(request, user: UserModel):
                return json_resp({"name": user.name, "age": user.age})

            client = app.test_client
            resp = client.post("/validate", json={"name": "Alice", "age": 30})
            assert resp.status == 200
        except ImportError:
            pytest.skip("Pydantic not installed")


class TestWebSocketRoute:
    def test_app_websocket_decorator(self):
        from kewe import Kewe

        app = Kewe("test_ws_route", enable_gateway=False)

        @app.websocket("/ws/chat")
        async def ws_chat(websocket):
            await websocket.accept()
            data = await websocket.receive()
            await websocket.send("Hello!")
            await websocket.close()

        assert hasattr(app.router, '_websocket_routes')
        assert '/ws/chat' in app.router._websocket_routes
        assert app.router._websocket_routes['/ws/chat']['handler'] is ws_chat

    def test_websocket_route_name(self):
        from kewe import Kewe

        app = Kewe("test_ws_name", enable_gateway=False)

        @app.websocket("/ws/echo", name="echo_ws")
        async def ws_echo(websocket):
            pass

        assert app.router._websocket_routes['/ws/echo']['name'] == 'echo_ws'


class TestCSRFExempt:
    def test_csrf_exempt_decorator(self):
        from kewe.security.csrf import csrf_exempt

        @csrf_exempt
        async def webhook(request):
            return {"ok": True}

        assert webhook._csrf_exempt is True

    def test_csrf_exempt_preserves_function(self):
        from kewe.security.csrf import csrf_exempt

        @csrf_exempt
        async def my_handler(request):
            return {"data": "test"}

        assert my_handler.__name__ == 'my_handler'


class TestSignatureCache:
    def test_signature_cache_populated(self):
        from kewe import Kewe
        from kewe.response import json as json_resp

        app = Kewe("test_sig_cache", enable_gateway=False)

        @app.get("/cached")
        async def cached_handler(request):
            return json_resp({"ok": True})

        client = app.test_client
        resp = client.get("/cached")
        assert resp.status == 200
        assert len(app._handler_signature_cache) > 0

    def test_signature_cache_reused(self):
        from kewe import Kewe
        from kewe.response import json as json_resp

        app = Kewe("test_sig_reuse", enable_gateway=False)

        @app.get("/reuse")
        async def reuse_handler(request):
            return json_resp({"ok": True})

        client = app.test_client
        resp1 = client.get("/reuse")
        cache_size = len(app._handler_signature_cache)
        resp2 = client.get("/reuse")
        assert cache_size == len(app._handler_signature_cache)
        assert resp1.status == 200
        assert resp2.status == 200


class TestOnionMiddlewareCache:
    def test_onion_cache_invalidation(self):
        from kewe.middleware.core import OnionMiddlewareChain, OnionMiddleware

        chain = OnionMiddlewareChain()
        assert chain._cached_chain is None

        async def mw1(request, call_next):
            return await call_next(request)

        chain.add(OnionMiddleware(mw1))
        assert chain._cached_chain is None
        assert chain._cache_key is None

    def test_onion_cache_key_changes(self):
        from kewe.middleware.core import OnionMiddlewareChain, OnionMiddleware

        chain = OnionMiddlewareChain()

        async def mw1(request, call_next):
            return await call_next(request)

        chain.add(OnionMiddleware(mw1))
        key1 = chain._get_cache_key()

        async def mw2(request, call_next):
            return await call_next(request)

        chain.add(OnionMiddleware(mw2))
        key2 = chain._get_cache_key()
        assert key1 != key2
