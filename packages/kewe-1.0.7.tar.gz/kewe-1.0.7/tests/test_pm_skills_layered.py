#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
PM-Skills 分层测试 — KeWe 框架
================================
三层测试模型:
  Tier 1 [P0]: 核心用例 (Happy Path / 基本功能)
  Tier 2 [P1]: 边界用例 (Edge / Limits / Type Boundaries)
  Tier 3 [P2]: 异常用例 (Error Handling / Invalid Inputs / Failure Modes)

遵循 ISTQB 标准: 每个测试标注优先级、前置条件、预期结果
"""

import pytest
import asyncio
import time
import os
import tempfile
import json as stdlib_json
from kewe import Kewe, KeweConfig
from kewe.application.depends import Depends, Query, Header, CookieParam, Path, Body
from kewe.response import json as json_resp, text, html, StreamingResponse
from kewe.errors.exceptions import (
    BadRequest, Unauthorized, Forbidden, NotFound, MethodNotAllowed,
    Conflict, Gone, TooManyRequests, InternalServerError,
    BadGateway, ServiceUnavailable, GatewayTimeout,
    UnprocessableEntity, HTTPException, abort
)


# ═══════════════════════════════════════════════════════════════════════════
# Tier 1: 核心用例 [P0] — 基本功能验证
# ═══════════════════════════════════════════════════════════════════════════

@pytest.fixture
def app():
    return Kewe("pm_skills_test", config=KeweConfig(secret_key="pm-skills-test-key"))


class TestTier1_Routing_Core:
    """[P0] 路由系统核心用例"""

    def test_t1_get_route_returns_200(self, app):
        """核心: GET路由注册与响应"""
        @app.get("/hello")
        async def hello(request):
            return json_resp({"msg": "hello"})
        client = app.test_client
        resp = client.get("/hello")
        assert resp.status == 200
        assert resp.json["msg"] == "hello"

    def test_t1_post_route_with_body(self, app):
        """核心: POST路由+请求体解析"""
        @app.post("/echo")
        async def echo(request):
            body = await request.json_async
            return json_resp(body)
        client = app.test_client
        resp = client.post("/echo", json={"key": "value"})
        assert resp.status == 200
        assert resp.json["key"] == "value"

    def test_t1_all_http_methods(self, app):
        """核心: 全部HTTP方法支持"""
        @app.get("/get-test")
        async def get_h(request): return json_resp({"method": "GET"})
        @app.post("/post-test")
        async def post_h(request): return json_resp({"method": "POST"})
        @app.put("/put-test")
        async def put_h(request): return json_resp({"method": "PUT"})
        @app.delete("/del-test")
        async def del_h(request): return json_resp({"method": "DELETE"})
        @app.patch("/patch-test")
        async def patch_h(request): return json_resp({"method": "PATCH"})

        client = app.test_client
        assert client.get("/get-test").status == 200
        assert client.post("/post-test").status == 200
        assert client.put("/put-test").status == 200
        assert client.delete("/del-test").status == 200
        assert client.patch("/patch-test").status == 200

    def test_t1_path_param_extraction(self, app):
        """核心: 路径参数提取与类型转换"""
        @app.get("/users/<id:int>")
        async def get_user(request, id: int):
            return json_resp({"id": id, "type": str(type(id).__name__)})
        client = app.test_client
        resp = client.get("/users/42")
        assert resp.status == 200
        assert resp.json["id"] == 42

    def test_t1_include_router_prefix(self, app):
        """核心: include_router + 前缀"""
        from kewe import Router
        router = Router()

        @router.get("/items")
        async def items(request):
            return json_resp({"source": "router"})

        app.include_router(router, prefix="/api/v1")
        client = app.test_client
        resp = client.get("/api/v1/items")
        assert resp.status == 200

    def test_t1_url_for_reverse(self, app):
        """核心: url_for反向生成"""
        @app.get("/profile/<name>", name="profile")
        async def profile(request, name):
            return json_resp({"name": name})
        url = app.url_for("profile", name="alice")
        assert url == "/profile/alice"

    def test_t1_multiple_path_params(self, app):
        """核心: 多个路径参数"""
        @app.get("/org/<org_id>/user/<user_id:int>")
        async def org_user(request, org_id, user_id: int):
            return json_resp({"org": org_id, "user": user_id})
        client = app.test_client
        resp = client.get("/org/acme/user/99")
        assert resp.status == 200
        assert resp.json["org"] == "acme"
        assert resp.json["user"] == 99


class TestTier1_Response_Core:
    """[P0] 响应系统核心用例"""

    def test_t1_json_response(self, app):
        """核心: JSONResponse"""
        resp = json_resp({"a": 1})
        assert resp.status == 200
        assert "application/json" in resp.content_type

    def test_t1_text_response(self, app):
        """核心: PlainTextResponse"""
        resp = text("hello world")
        assert resp.status == 200
        assert "text/plain" in resp.content_type

    def test_t1_html_response(self, app):
        """核心: HTMLResponse"""
        resp = html("<h1>Test</h1>")
        assert resp.status == 200
        assert "text/html" in resp.content_type

    def test_t1_redirect_response(self, app):
        """核心: RedirectResponse"""
        from kewe.response import redirect
        resp = redirect("/target")
        assert resp.status in (301, 302, 307, 308)

    def test_t1_custom_status_headers(self, app):
        """核心: 自定义状态码和响应头"""
        resp = json_resp({"created": True}, status=201,
                         headers={"X-Custom": "pm-skills"})
        assert resp.status == 201
        assert resp.headers.get("X-Custom") == "pm-skills"

    def test_t1_cookie_setting(self, app):
        """核心: Cookie设置"""
        resp = json_resp({"ok": True})
        resp.set_cookie("session_id", "abc123", max_age=3600, httponly=True)
        assert resp.cookies is not None or hasattr(resp, 'cookies')

    def test_t1_tuple_handler_return(self, app):
        """核心: 元组返回 (body, status, headers)"""
        @app.get("/tuple")
        async def tuple_handler(request):
            return {"data": 1}, 201, {"X-Type": "tuple"}
        client = app.test_client
        resp = client.get("/tuple")
        assert resp.status == 201
        assert resp.headers.get("X-Type") == "tuple"


class TestTier1_Middleware_Core:
    """[P0] 中间件核心用例"""

    def test_t1_request_middleware(self, app):
        """核心: 请求中间件"""
        @app.middleware("request")
        async def auth_mw(request):
            return True
        @app.get("/mw-test")
        async def mw_test(request):
            return json_resp({"ok": True})
        client = app.test_client
        resp = client.get("/mw-test")
        assert resp.status == 200

    def test_t1_response_middleware(self, app):
        """核心: 响应中间件"""
        @app.middleware("response")
        async def add_header(request, response):
            response.headers["X-MW"] = "present"
            return response
        @app.get("/resp-mw")
        async def resp_test(request):
            return json_resp({})
        client = app.test_client
        resp = client.get("/resp-mw")
        assert resp.headers.get("X-MW") == "present"


class TestTier1_DI_Core:
    """[P0] 依赖注入核心用例"""

    def test_t1_depends_simple(self, app):
        """核心: Depends基本依赖"""
        async def get_config():
            return {"debug": True}

        @app.get("/di-test")
        async def di_test(request, config=Depends(get_config)):
            return json_resp(config)
        client = app.test_client
        resp = client.get("/di-test")
        assert resp.status == 200
        assert resp.json["debug"] is True

    def test_t1_query_param(self, app):
        """核心: Query参数提取"""
        @app.get("/search")
        async def search(request, q: str = Query(default=""), page: int = Query(default=1)):
            return json_resp({"q": q, "page": page})
        client = app.test_client
        resp = client.get("/search?q=test&page=3")
        assert resp.status == 200
        assert resp.json["q"] == "test"
        assert resp.json["page"] == 3

    def test_t1_header_extraction(self, app):
        """核心: Header参数提取"""
        @app.get("/hdr")
        async def hdr(request, x_token: str = Header(default="")):
            return json_resp({"token": x_token})
        client = app.test_client
        resp = client.get("/hdr", headers={"X-Token": "secret123"})
        assert resp.status == 200
        assert resp.json["token"] == "secret123"


# ═══════════════════════════════════════════════════════════════════════════
# Tier 2: 边界用例 [P1] — 边界条件与极限值
# ═══════════════════════════════════════════════════════════════════════════

class TestTier2_Routing_Boundary:
    """[P1] 路由系统边界用例"""

    def test_t2_empty_path(self, app):
        """边界: 根路径"""
        @app.get("/")
        async def root(request):
            return json_resp({"root": True})
        client = app.test_client
        resp = client.get("/")
        assert resp.status == 200

    def test_t2_trailing_slash(self, app):
        """边界: 尾部斜杠"""
        @app.get("/data")
        async def data(request):
            return json_resp({"ok": True})
        client = app.test_client
        resp = client.get("/data/")
        assert resp.status in (200, 301, 302, 307, 308)

    def test_t2_very_long_path(self, app):
        """边界: 极长路径参数值"""
        @app.get("/deep/<segment>")
        async def deep(request, segment):
            return json_resp({"len": len(segment)})
        long_value = "a" * 200
        client = app.test_client
        resp = client.get(f"/deep/{long_value}")
        assert resp.status == 200

    def test_t2_special_chars_in_path(self, app):
        """边界: 路径中特殊字符"""
        @app.get("/items/<name>")
        async def item(request, name):
            return json_resp({"name": name})
        client = app.test_client
        resp = client.get("/items/hello%20world")
        assert resp.status in (200, 404)

    def test_t2_routes_with_same_prefix(self, app):
        """边界: 相同前缀路由优先级"""
        @app.get("/api/users")
        async def users(request):
            return json_resp({"all": True})
        @app.get("/api/users/<id:int>")
        async def user(request, id: int):
            return json_resp({"id": id})
        client = app.test_client
        r1 = client.get("/api/users")
        r2 = client.get("/api/users/1")
        assert r1.status == 200
        assert r2.status == 200

    def test_t2_large_number_of_routes(self, app):
        """边界: 大量路由注册"""
        for i in range(50):
            @app.get(f"/route-{i}")
            async def handler(request):
                return json_resp({})
        client = app.test_client
        resp = client.get("/route-49")
        assert resp.status == 200

    def test_t2_unicode_path_param(self, app):
        """边界: Unicode路径参数"""
        @app.get("/tags/<tag>")
        async def tag_handler(request, tag):
            return json_resp({"tag": tag})
        client = app.test_client
        resp = client.get("/tags/%E4%B8%AD%E6%96%87")
        assert resp.status == 200

    def test_t2_zero_value_path_param(self, app):
        """边界: 零值路径参数"""
        @app.get("/items/<id:int>")
        async def item(request, id: int):
            return json_resp({"id": id})
        client = app.test_client
        resp = client.get("/items/0")
        assert resp.status == 200
        assert resp.json["id"] == 0

    def test_t2_negative_path_param(self, app):
        """边界: 负数路径参数"""
        @app.get("/offset/<delta:int>")
        async def offset(request, delta: int):
            return json_resp({"delta": delta})
        client = app.test_client
        resp = client.get("/offset/-5")
        assert resp.status == 200
        assert resp.json["delta"] == -5


class TestTier2_Response_Boundary:
    """[P1] 响应系统边界用例"""

    def test_t2_empty_json_body(self, app):
        """边界: 空JSON响应体"""
        resp = json_resp({})
        assert resp.status == 200

    def test_t2_nested_json_structure(self, app):
        """边界: 深层嵌套JSON"""
        nested = {"level1": {"level2": {"level3": {"level4": {"level5": "deep"}}}}}
        resp = json_resp(nested)
        assert resp.status == 200

    def test_t2_large_json_response(self, app):
        """边界: 大JSON响应"""
        large = {"items": [{"id": i, "data": "x" * 100} for i in range(1000)]}
        resp = json_resp(large)
        assert resp.status == 200

    def test_t2_null_values_in_json(self, app):
        """边界: JSON中null值"""
        resp = json_resp({"key": None, "list": [None, 1, None]})
        assert resp.status == 200

    def test_t2_very_long_header_value(self, app):
        """边界: 极长响应头"""
        resp = json_resp({}, headers={"X-Long": "x" * 1000})
        assert resp.status == 200

    def test_t2_multiple_cookies(self, app):
        """边界: 多Cookie设置"""
        resp = json_resp({"ok": True})
        for i in range(5):
            resp.set_cookie(f"key_{i}", f"val_{i}")
        assert resp.cookies is not None or len(resp.cookies) >= 0 if hasattr(resp, 'cookies') else True

    def test_t2_empty_text_response(self, app):
        """边界: 空文本响应"""
        resp = text("")
        assert resp.status == 200


class TestTier2_DI_Boundary:
    """[P1] DI系统边界用例"""

    def test_t2_depends_with_no_cache(self, app):
        """边界: Depends不使用缓存"""
        counter = [0]

        async def increment():
            counter[0] += 1
            return counter[0]

        @app.get("/no-cache")
        async def no_cache(request, val=Depends(increment, use_cache=False)):
            return json_resp({"val": val})

        client = app.test_client
        r1 = client.get("/no-cache")
        r2 = client.get("/no-cache")
        assert r1.json["val"] != r2.json["val"]

    def test_t2_query_without_default(self, app):
        """边界: Query无默认值(必填)"""
        @app.get("/required")
        async def required(request, name: str = Query()):
            return json_resp({"name": name})
        client = app.test_client
        resp = client.get("/required?name=test")
        assert resp.status == 200

    def test_t2_multiple_depends(self, app):
        """边界: 多个Depends同时使用"""
        async def db():
            return "db_conn"

        async def cache():
            return "cache_conn"

        @app.get("/multi-dep")
        async def multi(request, d=Depends(db), c=Depends(cache)):
            return json_resp({"db": d, "cache": c})
        client = app.test_client
        resp = client.get("/multi-dep")
        assert resp.status == 200


# ═══════════════════════════════════════════════════════════════════════════
# Tier 3: 异常用例 [P2] — 错误处理与失败模式
# ═══════════════════════════════════════════════════════════════════════════

class TestTier3_ErrorHandling:
    """[P2] 错误处理异常用例"""

    def test_t3_not_found_404(self, app):
        """异常: 访问未注册路由返回404"""
        client = app.test_client
        resp = client.get("/nonexistent-path-xyz")
        assert resp.status == 404

    def test_t3_method_not_allowed_405(self, app):
        """异常: 错误HTTP方法返回405"""
        @app.get("/only-get")
        async def only_get(request):
            return json_resp({})
        client = app.test_client
        resp = client.post("/only-get")
        assert resp.status in (404, 405)

    def test_t3_abort_function(self, app):
        """异常: abort()抛出HTTP异常"""
        @app.get("/abort-test")
        async def abort_test(request):
            abort(400, "Custom bad request")
        client = app.test_client
        resp = client.get("/abort-test")
        assert resp.status == 400

    def test_t3_abort_all_status_codes(self, app):
        """异常: abort()支持常见HTTP状态码"""
        # 逐个注册以避免handler名称冲突
        @app.get("/abort-400")
        async def a400(request): abort(400)
        @app.get("/abort-404")
        async def a404(request): abort(404)
        @app.get("/abort-500")
        async def a500(request): abort(500)
        @app.get("/abort-502")
        async def a502(request): abort(502)

        client = app.test_client
        assert client.get("/abort-400").status == 400
        assert client.get("/abort-404").status == 404
        assert client.get("/abort-500").status == 500
        assert client.get("/abort-502").status == 502

    def test_t3_custom_error_handler(self, app):
        """异常: 自定义错误处理器"""
        @app.exception(403)
        async def custom_403(request, exc):
            return json_resp({"custom_error": "forbidden", "detail": str(exc)}, status=403)

        @app.get("/custom-403")
        async def trigger_403(request):
            raise Forbidden("Access denied by policy")

        client = app.test_client
        resp = client.get("/custom-403")
        assert resp.status == 403
        assert resp.json is not None

    def test_t3_raise_http_exception(self, app):
        """异常: 手动抛出HTTPException"""
        @app.get("/raise-exc")
        async def raise_exc(request):
            raise HTTPException(status_code=418, detail="I'm a teapot - custom")

        client = app.test_client
        resp = client.get("/raise-exc")
        assert resp.status == 418

    def test_t3_problem_details_format(self, app):
        """异常: RFC 7807问题详情格式"""
        @app.get("/problem")
        async def problem(request):
            raise NotFound(detail="User not found in database")

        client = app.test_client
        resp = client.get("/problem")
        assert resp.status == 404

    def test_t3_unauthorized_with_www_authenticate(self, app):
        """异常: 401带WWW-Authenticate头"""
        @app.get("/auth-needed")
        async def auth_needed(request):
            raise Unauthorized(www_authenticate="Bearer")

        client = app.test_client
        resp = client.get("/auth-needed")
        assert resp.status == 401
        header = resp.headers.get("WWW-Authenticate") or resp.headers.get("www-authenticate")
        assert header is not None

    def test_t3_method_not_allowed_with_allow_header(self, app):
        """异常: 405带Allow头"""
        @app.get("/only-get-405")
        async def only_get(request):
            return json_resp({})

        client = app.test_client
        resp = client.post("/only-get-405")
        assert resp.status in (404, 405)
        if resp.status == 405:
            allow = resp.headers.get("Allow") or resp.headers.get("allow")
            assert allow is not None

    def test_t3_too_many_requests_with_retry_after(self, app):
        """异常: 429带Retry-After头"""
        @app.get("/rate-limited")
        async def rate_limited(request):
            raise TooManyRequests(retry_after=60)

        client = app.test_client
        resp = client.get("/rate-limited")
        assert resp.status == 429
        retry = resp.headers.get("Retry-After") or resp.headers.get("retry-after")
        assert retry is not None

    def test_t3_conflict_exception(self, app):
        """异常: 409 Conflict"""
        @app.post("/create-conflict")
        async def conflict(request):
            raise Conflict("Resource already exists")

        client = app.test_client
        resp = client.post("/create-conflict")
        assert resp.status == 409

    def test_t3_gone_exception(self, app):
        """异常: 410 Gone"""
        @app.get("/old-resource")
        async def gone_resource(request):
            raise Gone("This resource has been permanently removed")
        client = app.test_client
        resp = client.get("/old-resource")
        assert resp.status == 410

    def test_t3_unprocessable_entity(self, app):
        """异常: 422 Unprocessable Entity"""
        @app.post("/validate")
        async def validate(request):
            raise UnprocessableEntity(detail=[{"loc": ["body", "name"], "msg": "required"}])
        client = app.test_client
        resp = client.post("/validate", json={})
        assert resp.status == 422

    def test_t3_bad_gateway(self, app):
        """异常: 502 Bad Gateway"""
        @app.get("/upstream-fail")
        async def upstream(request):
            raise BadGateway("Upstream service unavailable")
        client = app.test_client
        resp = client.get("/upstream-fail")
        assert resp.status == 502

    def test_t3_service_unavailable(self, app):
        """异常: 503 Service Unavailable"""
        @app.get("/maintenance")
        async def maintenance(request):
            raise ServiceUnavailable(retry_after=120)
        client = app.test_client
        resp = client.get("/maintenance")
        assert resp.status == 503

    def test_t3_gateway_timeout(self, app):
        """异常: 504 Gateway Timeout"""
        @app.get("/slow")
        async def slow(request):
            raise GatewayTimeout("Upstream did not respond in time")
        client = app.test_client
        resp = client.get("/slow")
        assert resp.status == 504


class TestTier3_InputValidation:
    """[P2] 输入验证异常用例"""

    def test_t3_invalid_json_body(self, app):
        """异常: 无效JSON请求体"""
        @app.post("/json-check")
        async def json_check(request):
            try:
                body = await request.json_async
                return json_resp(body)
            except Exception as e:
                raise BadRequest(str(e))
        client = app.test_client
        resp = client.post("/json-check", data="not-json", headers={"Content-Type": "application/json"})
        assert resp.status in (400, 422)

    def test_t3_missing_required_header(self, app):
        """异常: 缺少请求头时的行为"""
        @app.get("/need-auth")
        async def need_auth(request, token: str = Header(default=None)):
            return json_resp({"token": token})
        client = app.test_client
        resp = client.get("/need-auth")
        assert resp.status == 200
        assert resp.json["token"] is None

    def test_t3_wrong_path_param_type(self, app):
        """异常: 路径参数类型错误"""
        @app.get("/items/<id:int>")
        async def item(request, id: int):
            return json_resp({"id": id})
        client = app.test_client
        resp = client.get("/items/not-a-number")
        assert resp.status in (400, 404, 422)

    def test_t3_oversized_request_body(self, app):
        """异常: 超大请求体"""
        @app.post("/big-body")
        async def big(request):
            body = await request.body
            return json_resp({"len": len(body)})
        client = app.test_client
        big_data = "x" * 100000
        resp = client.post("/big-body", data=big_data, headers={"Content-Type": "text/plain"})
        assert resp.status in (200, 413, 500)


class TestTier3_DI_Failure:
    """[P2] 依赖注入失败场景"""

    def test_t3_depends_throws_exception(self, app):
        """异常: Depends依赖抛出异常"""
        async def failing_dep():
            raise ValueError("DB connection failed")

        @app.get("/fail-dep")
        async def fail_dep(request, db=Depends(failing_dep)):
            return json_resp({"db": db})

        client = app.test_client
        resp = client.get("/fail-dep")
        assert resp.status in (500, 503)

    def test_t3_circular_depends_detection(self, app):
        """异常: 循环依赖检测"""
        dep_a_ref = [None]
        dep_b_ref = [None]

        async def dep_a(b=Depends(lambda: dep_b_ref[0] if dep_b_ref[0] else lambda: "default_b")):
            return f"a+{b}" if not callable(b) else "a+default"

        async def dep_b(a=Depends(lambda: dep_a_ref[0] if dep_a_ref[0] else lambda: "default_a")):
            return f"b+{a}" if not callable(a) else "b+default"

        # 设置前向引用
        dep_a_ref[0] = dep_a
        dep_b_ref[0] = dep_b

        @app.get("/circular")
        async def circular(request, x=Depends(dep_a)):
            return json_resp({"x": x})

        client = app.test_client
        resp = client.get("/circular")
        assert resp.status in (200, 500)

    def test_t3_query_validation_failure(self, app):
        """异常: Query参数验证失败"""
        @app.get("/validate-query")
        async def validate_query(request, age: int = Query(ge=18, le=120)):
            return json_resp({"age": age})

        client = app.test_client
        resp = client.get("/validate-query?age=15")
        assert resp.status in (400, 422, 200)
