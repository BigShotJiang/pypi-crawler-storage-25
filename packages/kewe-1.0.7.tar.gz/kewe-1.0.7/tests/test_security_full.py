#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Security模块全覆盖测试 - JWT, Auth, CSRF, Password"""

import pytest
import time
from kewe import Kewe, KeweConfig, json as _json_resp
from kewe.application.depends import Depends, Header


@pytest.fixture
def security_app():
    return Kewe("security_test", config=KeweConfig(secret_key="test-secret-key-for-testing"))


class TestPasswordHashing:
    """密码哈希测试"""

    def test_hash_password_returns_string(self):
        from kewe.security.password import hash_password, generate_password_hash
        hashed = hash_password("my-password")
        assert isinstance(hashed, str)
        assert len(hashed) > 0

    def test_verify_password_correct(self):
        from kewe.security.password import hash_password, verify_password
        hashed = hash_password("correct-password")
        assert verify_password("correct-password", hashed) is True

    def test_verify_password_incorrect(self):
        from kewe.security.password import hash_password, verify_password
        hashed = hash_password("password123")
        assert verify_password("wrong-password", hashed) is False

    def test_verify_password_empty(self):
        from kewe.security.password import hash_password, verify_password
        hashed = hash_password("some-password")
        assert verify_password("", hashed) is False

    def test_hash_password_different_salts(self):
        from kewe.security.password import hash_password
        h1 = hash_password("same-password")
        h2 = hash_password("same-password")
        assert h1 != h2  # Different salts

    def test_generate_password_hash_function(self):
        from kewe.security.password import generate_password_hash
        hashed = generate_password_hash("test")
        assert isinstance(hashed, str)

    def test_check_password_hash_function(self):
        from kewe.security.password import generate_password_hash, check_password_hash
        hashed = generate_password_hash("test-pass")
        assert check_password_hash("test-pass", hashed) is True
        assert check_password_hash("wrong-pass", hashed) is False

    def test_hash_unicode_password(self):
        from kewe.security.password import hash_password, verify_password
        pwd = "密码测试123!@#"
        hashed = hash_password(pwd)
        assert verify_password(pwd, hashed) is True

    def test_hash_long_password(self):
        from kewe.security.password import hash_password, verify_password
        pwd = "a" * 1000
        hashed = hash_password(pwd)
        assert verify_password(pwd, hashed) is True

    def test_password_strength_check(self):
        from kewe.security.password import validate_password_strength
        ok, errors, strength = validate_password_strength("weak")
        assert ok is False or strength == "weak"


class TestJWT:
    """JWT认证测试"""

    def test_jwt_manager_creation(self):
        from kewe.security.jwt import JWTAuthManager
        jwt = JWTAuthManager(secret_key="test-secret")
        assert jwt is not None

    def test_jwt_token_type_values(self):
        from kewe.security.jwt import TokenType
        assert TokenType.ACCESS.value == "access"
        assert TokenType.REFRESH.value == "refresh"

    def test_jwt_token_status_values(self):
        from kewe.security.jwt import TokenStatus
        assert TokenStatus.ACTIVE.value == "active"
        assert TokenStatus.EXPIRED.value == "expired"
        assert TokenStatus.REVOKED.value == "revoked"

    def test_jwt_algorithm_values(self):
        from kewe.security.jwt import JWTAlgorithm
        assert JWTAlgorithm.HS256.value == "HS256"
        assert JWTAlgorithm.RS256.value == "RS256"

    def test_jwt_security_context(self):
        from kewe.security.jwt import SecurityContext
        ctx = SecurityContext(user_agent="test/1.0", ip_address="127.0.0.1")
        assert ctx.user_agent == "test/1.0"
        assert ctx.ip_address == "127.0.0.1"

    def test_jwt_generate_and_decode(self):
        from kewe.security.jwt import JWTAuthManager, SecurityContext
        jwt = JWTAuthManager(secret_key="my-secret-key-32chars!!")
        ctx = SecurityContext(user_agent="test/1.0", ip_address="127.0.0.1")
        token = jwt.generate_access_token(user_id="123", user_name="alice", context=ctx)
        assert isinstance(token, str)
        assert len(token) > 0

    def test_jwt_decode_valid_token(self):
        from kewe.security.jwt import JWTAuthManager, SecurityContext
        jwt = JWTAuthManager(secret_key="valid-secret-key-here-32")
        ctx = SecurityContext(user_agent="test/1.0", ip_address="127.0.0.1")
        token = jwt.generate_access_token(user_id="456", user_name="bob", context=ctx)
        payload = jwt.decode_token(token)
        assert payload is not None

    def test_jwt_decode_invalid_token(self):
        from kewe.security.jwt import JWTAuthManager
        jwt = JWTAuthManager(secret_key="good-secret-key-hello-32")
        try:
            payload = jwt.decode_token("invalid.token.here")
            assert payload is None or isinstance(payload, dict)
        except Exception:
            pass  # decode_token may raise on invalid tokens


class TestAuthManager:
    """AuthManager测试"""

    def test_auth_manager_creation(self, security_app):
        from kewe.security.auth import AuthManager
        mgr = AuthManager(app=security_app)
        assert mgr is not None

    def test_user_model(self):
        from kewe.security.auth import User
        user = User(id="1", username="admin", roles=["admin"], is_active=True)
        assert user.id == "1"
        assert user.username == "admin"
        assert "admin" in user.roles

    def test_auth_token_model(self):
        from kewe.security.auth import AuthToken
        token = AuthToken(access_token="abc", token_type="bearer")
        assert token.access_token == "abc"
        assert token.token_type == "bearer"

    def test_auth_error_enum(self):
        from kewe.security.auth import AuthError
        assert AuthError.INVALID_CREDENTIALS.value == "invalid_credentials"

    def test_login_required_decorator(self, security_app):
        from kewe.security.auth import login_required
        is_callable = callable(login_required)
        assert is_callable is True


class TestCSRF:
    """CSRF保护测试"""

    def test_csrf_protection_creation(self):
        from kewe.security.csrf import CSRFProtection
        csrf = CSRFProtection(secret_key="csrf-secret")
        assert csrf is not None

    def test_csrf_middleware_creation(self):
        from kewe.security.csrf import CSRFMiddleware
        mw = CSRFMiddleware(secret_key="test-secret")
        assert mw is not None

    def test_get_csrf_token(self):
        from kewe.security.csrf import get_csrf_token
        from kewe.request import Request
        from kewe import Kewe
        app = Kewe("csrf_test")
        req = Request(b"GET / HTTP/1.1\r\nHost: test\r\n\r\n", app)
        token = get_csrf_token(req, secret_key="csrf-key")
        assert isinstance(token, str)

    def test_set_csrf_cookie(self):
        from kewe.security.csrf import set_csrf_cookie
        from kewe.request import Request
        from kewe import Kewe
        app = Kewe("csrf_cookie_test")
        req = Request(b"GET / HTTP/1.1\r\nHost: test\r\n\r\n", app)
        resp = _json_resp({"ok": True})
        result = set_csrf_cookie(resp, req, secret_key="csrf-key")
        assert result is not None

    def test_csrf_protect_decorator(self):
        from kewe.security.csrf import csrf_protect
        assert callable(csrf_protect)


class TestRateLimiter:
    """限流器测试"""

    def test_rate_limiter_creation(self):
        from kewe.security.rate_limit import RateLimiter
        rl = RateLimiter(max_requests=10, window=60)
        assert rl is not None

    def test_rate_limiter_backend_types(self):
        from kewe.security.rate_limit import RateLimiterBackend, MemoryBackend
        assert RateLimiterBackend is not None
        backend = MemoryBackend()
        assert backend is not None

    def test_rate_limit_decorator(self):
        from kewe.security.rate_limit import rate_limit
        assert callable(rate_limit)

    def test_rate_limit_info(self):
        from kewe.security.rate_limit import RateLimitInfo
        info = RateLimitInfo(limit=100, remaining=99, reset_time=int(time.time() + 60))
        assert info.limit == 100
        assert info.remaining == 99

    def test_rate_limiter_middleware(self):
        from kewe.security.rate_limit import RateLimitMiddleware
        mw = RateLimitMiddleware(limit=100)
        assert mw is not None


class TestRBAC:
    """RBAC角色权限管理测试"""

    def test_role_creation(self):
        from kewe.security.rbac_manager import Role
        assert Role.ADMIN.value == "admin"
        assert Role.USER.value == "user"

    def test_permission_creation(self):
        from kewe.security.rbac_manager import Permission
        assert Permission.READ.value == "read"
        assert Permission.WRITE.value == "write"

    def test_rbac_manager_creation(self):
        from kewe.security.rbac_manager import RBACManager
        rbac = RBACManager()
        assert rbac is not None

    def test_rbac_add_role(self):
        from kewe.security.rbac_manager import RBACManager
        rbac = RBACManager()
        result = rbac.add_role("editor", {"read", "write"})
        assert result is True

    def test_rbac_add_permission(self):
        from kewe.security.rbac_manager import RBACManager
        rbac = RBACManager()
        rbac.add_permission_to_role("user", "upload")
        perms = rbac.get_role_permissions("user")
        assert "upload" in perms

    def test_roles_required_decorator_exists(self):
        from kewe.security.auth import roles_required
        assert callable(roles_required)

    def test_permissions_required_decorator_exists(self):
        from kewe.security.auth import permissions_required
        assert callable(permissions_required)


class TestAuthAPI:
    """认证API集成测试"""

    def test_jwt_auth_on_protected_route(self, security_app):
        from kewe.security.jwt import JWTAuthManager, SecurityContext

        jwt = JWTAuthManager(secret_key="my-protected-route-key-32")

        @security_app.get("/protected-jwt")
        async def protected(request):
            auth = request.headers.get("authorization", "")
            if not auth.startswith("Bearer "):
                from kewe import Unauthorized
                raise Unauthorized("Missing token")
            token = auth.split(" ", 1)[1]
            payload = jwt.decode_token(token)
            if payload is None:
                from kewe import Unauthorized
                raise Unauthorized("Invalid token")
            return _json_resp({"user": payload.get("sub")})

        ctx = SecurityContext(user_agent="test/1.0", ip_address="127.0.0.1")
        token = jwt.generate_access_token(user_id="999", user_name="test", context=ctx)
        client = security_app.test_client
        resp = client.get("/protected-jwt", headers={"authorization": f"Bearer {token}"})
        assert resp.status == 200

    def test_jwt_auth_without_token(self, security_app):
        @security_app.get("/no-token")
        async def no_token(request):
            auth = request.headers.get("authorization", "")
            if not auth:
                from kewe import Unauthorized
                raise Unauthorized("Missing token")
            return _json_resp({})

        client = security_app.test_client
        resp = client.get("/no-token")
        assert resp.status == 401

    def test_api_key_auth(self, security_app):
        @security_app.get("/api-key-auth")
        async def api_key_route(request):
            key = request.headers.get("x-api-key", "")
            if key != "secret-api-key":
                from kewe import Unauthorized
                raise Unauthorized("Invalid API key")
            return _json_resp({"auth": "api_key"})

        client = security_app.test_client
        resp = client.get("/api-key-auth", headers={"x-api-key": "secret-api-key"})
        assert resp.status == 200

        resp2 = client.get("/api-key-auth", headers={"x-api-key": "wrong-key"})
        assert resp2.status == 401

    def test_basic_auth_extraction(self, security_app):
        import base64

        @security_app.get("/basic-auth")
        async def basic_route(request):
            auth = request.headers.get("authorization", "")
            if not auth.startswith("Basic "):
                from kewe import Unauthorized
                raise Unauthorized("Missing basic auth")
            decoded = base64.b64decode(auth[6:]).decode()
            username, password = decoded.split(":", 1)
            if username == "admin" and password == "secret":
                return _json_resp({"user": username})
            from kewe import Unauthorized
            raise Unauthorized("Invalid credentials")

        credentials = base64.b64encode(b"admin:secret").decode()
        client = security_app.test_client
        resp = client.get("/basic-auth", headers={"authorization": f"Basic {credentials}"})
        assert resp.status == 200


class TestTokenStore:
    """Token存储测试"""

    def test_token_store_creation(self):
        from kewe.security.token_store import TokenStore
        store = TokenStore()
        assert store is not None

    def test_token_store_default_values(self):
        from kewe.security.token_store import TokenStore
        store = TokenStore()
        assert store.blacklist == {}
        assert store.refresh_tokens == {}
        assert store.redis is None

    def test_token_store_user_revocation(self):
        from kewe.security.token_store import TokenStore
        store = TokenStore()
        store.set_user_revocation_timestamp("user1")
        ts = store.get_user_revocation_timestamp("user1")
        assert ts is not None
        assert ts > 0

    def test_token_store_is_user_revoked(self):
        from kewe.security.token_store import TokenStore
        import time as _time
        store = TokenStore()
        store.set_user_revocation_timestamp("user2")
        assert store.is_user_token_revoked("user2", 0) is True
        assert store.is_user_token_revoked("user2", _time.time() + 3600) is False

    def test_token_store_cleanup(self):
        from kewe.security.token_store import TokenStore
        store = TokenStore()
        count = store.cleanup_expired_blacklist()
        assert count >= 0
