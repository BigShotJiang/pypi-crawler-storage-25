#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""v0.8 全覆盖测试 — 真实项目Blog API + 所有关键模块"""

import pytest
import asyncio
import time
from kewe import Kewe, KeweConfig, Blueprint, Router
from kewe.response import json as json_resp, text, html, StreamingResponse, BackgroundTask
from kewe.application.depends import Depends, Query, Header, Body


@pytest.fixture
def app():
    return Kewe("v08", config=KeweConfig(secret_key="v08-key-32chars!"))


class TestBlogAPI:
    """真实Blog API项目"""

    def test_full_crud_flow(self, app):
        db = {}
        counter = [0]

        async def get_db():
            return {"posts": db, "counter": counter}

        @app.middleware("request")
        async def logger(request):
            return True

        @app.middleware("response")
        async def add_header(request, resp):
            resp.headers["X-Blog"] = "v0.8"
            return resp

        @app.get("/posts")
        async def list_posts(request, page: int = Query(default=1, ge=1),
                             size: int = Query(default=10, ge=1, le=50),
                             db=Depends(get_db)):
            posts = list(db["posts"].values())
            start = (page - 1) * size
            return json_resp({
                "items": posts[start:start + size],
                "total": len(posts),
                "page": page
            })

        @app.get("/posts/<id:int>")
        async def get_post(request, id: int, db=Depends(get_db)):
            post = db["posts"].get(id)
            if not post:
                from kewe import NotFound
                raise NotFound(detail=f"Post {id} not found")
            return json_resp(post)

        @app.post("/posts")
        async def create_post(request, body: dict = Body(), db=Depends(get_db)):
            db["counter"][0] += 1
            post_id = db["counter"][0]
            post = {
                "id": post_id,
                "title": body.get("title", ""),
                "content": body.get("content", ""),
                "created_at": time.time()
            }
            db["posts"][post_id] = post
            return json_resp(post, status=201)

        @app.put("/posts/<id:int>")
        async def update_post(request, id: int, body: dict = Body(), db=Depends(get_db)):
            if id not in db["posts"]:
                from kewe import NotFound
                raise NotFound()
            db["posts"][id].update(body)
            return json_resp(db["posts"][id])

        @app.delete("/posts/<id:int>")
        async def delete_post(request, id: int, db=Depends(get_db)):
            if id not in db["posts"]:
                from kewe import NotFound
                raise NotFound()
            del db["posts"][id]
            return json_resp({"deleted": id})

        c = app.test_client

        # Create
        r = c.post("/posts", json={"title": "Hello World", "content": "First post"})
        assert r.status == 201
        assert r.json["id"] == 1

        # List
        r = c.get("/posts")
        assert r.status == 200
        assert r.json["total"] == 1

        # Get
        r = c.get("/posts/1")
        assert r.status == 200
        assert r.json["title"] == "Hello World"

        # Update
        r = c.put("/posts/1", json={"title": "Updated"})
        assert r.status == 200

        # Delete
        r = c.delete("/posts/1")
        assert r.status == 200

        # Not found
        r = c.get("/posts/999")
        assert r.status == 404

    def test_auth_flow(self, app):
        users = {"admin": "secret123"}

        @app.post("/login")
        async def login(request, body: dict = Body()):
            u = body.get("username", "")
            p = body.get("password", "")
            if u in users and users[u] == p:
                return json_resp({"token": f"bearer-{u}"})
            from kewe import Unauthorized
            raise Unauthorized()

        c = app.test_client
        r = c.post("/login", json={"username": "admin", "password": "secret123"})
        assert r.status == 200
        assert "bearer-admin" in r.json["token"]

        r = c.post("/login", json={"username": "admin", "password": "wrong"})
        assert r.status == 401


class TestAllExceptions:
    """全部HTTP异常端到端"""

    def test_exception_status_codes(self, app):
        from kewe.errors.exceptions import (
            BadRequest, Unauthorized, Forbidden, NotFound,
            MethodNotAllowed, Conflict, Gone, UnprocessableEntity,
            TooManyRequests, InternalServerError,
            BadGateway, ServiceUnavailable, GatewayTimeout
        )
        cases = [
            (BadRequest, 400), (Unauthorized, 401), (Forbidden, 403),
            (NotFound, 404), (MethodNotAllowed, 405), (Conflict, 409),
            (Gone, 410), (UnprocessableEntity, 422), (TooManyRequests, 429),
            (InternalServerError, 500), (BadGateway, 502),
            (ServiceUnavailable, 503), (GatewayTimeout, 504),
        ]
        for i, (exc_cls, expected) in enumerate(cases):
            @app.get(f"/exc-{i}")
            async def handler(request):
                raise exc_cls()

        c = app.test_client
        for i, (exc_cls, expected) in enumerate(cases):
            r = c.get(f"/exc-{i}")
            assert r.status == expected, f"{exc_cls.__name__}: {r.status} != {expected}"


class TestDI:
    """依赖注入深度测试"""

    def test_security_depends(self, app):
        from kewe.application.depends import Security

        async def get_token(request):
            return request.headers.get("authorization", "none")

        @app.get("/secure")
        async def secure(request, token=Security(get_token, scopes=["read"])):
            return json_resp({"token": token})

        r = app.test_client.get("/secure", headers={"authorization": "Bearer abc"})
        assert r.status == 200
        assert "Bearer abc" in r.json["token"]

    def test_dependency_override(self, app):
        async def real_svc():
            return "production"

        async def mock_svc():
            return "mock"

        @app.get("/svc")
        async def svc(request, s=Depends(real_svc)):
            return json_resp({"svc": s})

        app.dependency_overrides[real_svc] = mock_svc
        r = app.test_client.get("/svc")
        assert r.json["svc"] == "mock"

    def test_cookie_param(self, app):
        from kewe.application.depends import CookieParam

        @app.get("/cookie-test")
        async def cookie_test(request, sid: str = CookieParam(default="")):
            return json_resp({"sid": sid})

        r = app.test_client.get("/cookie-test")
        assert r.status == 200

    def test_form_param(self, app):
        from kewe.application.depends import Form

        @app.post("/login-form")
        async def login_form(request, username: str = Form(default=""),
                             password: str = Form(default="")):
            return json_resp({"user": username})

        r = app.test_client.post("/login-form", data={"username": "alice"})
        assert r.status in (200, 422)

    def test_path_param_extract(self, app):
        from kewe.application.depends import Path

        @app.get("/items/<item_id>")
        async def get_item(request, item_id: int = Path(ge=1)):
            return json_resp({"id": item_id})

        r = app.test_client.get("/items/42")
        assert r.status == 200
        assert r.json["id"] == 42


class TestSignals:
    """信号系统"""

    def test_signal_bus(self, app):
        from kewe.application.signals import SignalBus
        bus = SignalBus()
        results = []

        def handler(data):
            results.append(data)

        bus.on("test.event", handler)
        assert hasattr(bus, 'trigger') or hasattr(bus, 'emit')

    def test_signal_manager(self, app):
        from kewe.application.signals import SignalManager
        mgr = SignalManager(app)
        assert mgr is not None


class TestState:
    """状态管理"""

    def test_state_manager(self):
        from kewe.application.state import StateManager, AppState
        mgr = StateManager()
        assert mgr is not None
        assert AppState.STARTING is not None


class TestLifecycle:
    """生命周期"""

    def test_lifecycle_hooks(self, app):
        called = []

        @app.before_server_start
        async def before(app_inst):
            called.append("before_start")

        @app.after_server_stop
        async def after(app_inst):
            called.append("after_stop")

        assert callable(before)
        assert callable(after)


class TestStaticFiles:
    """静态文件"""

    def test_static_handler(self):
        from kewe.handlers.static_serve import StaticFileHandler
        h = StaticFileHandler()
        assert h is not None


class TestLogging:
    """日志"""

    def test_logger_functions(self):
        from kewe.logging.logger import get_logger, debug, info, warning, error, critical, setup_logging
        logger = get_logger("v08_test")
        assert logger is not None
        assert callable(debug)
        assert callable(info)
        assert callable(warning)
        assert callable(error)
        assert callable(critical)
        assert callable(setup_logging)


class TestConfig:
    """配置"""

    def test_config_basics(self):
        from kewe.application.config import KeweConfig
        kc = KeweConfig(secret_key="k", debug=True, host="0.0.0.0", port=9000,
                        keep_alive_timeout=30, request_max_size=5_000_000)
        assert kc.port == 9000


class TestHTTPClient:
    """HTTP客户端"""

    def test_client_config(self):
        from kewe.http.client import AsyncHTTPClient, HttpClientConfig, RetryConfig
        cfg = HttpClientConfig(base_url="https://api.example.com", timeout=15.0)
        assert cfg.timeout == 15.0
        retry = RetryConfig(max_retries=5, backoff_factor=1.0)
        assert retry.max_retries == 5

    def test_keepalive_config(self):
        from kewe.http.keepalive import KeepAliveConfig, KeepAliveManager
        cfg = KeepAliveConfig(timeout=10, max_requests=500, enabled=True)
        mgr = KeepAliveManager(cfg)
        assert mgr.config.max_requests == 500

    def test_range_parser(self):
        from kewe.http.range_request import RangeHeaderParser, ByteRange
        parser = RangeHeaderParser()
        result = parser.parse("bytes=0-1023")
        assert result is not None

    def test_http2_available(self):
        from kewe.http.http2 import is_http2_available, HTTP2Protocol, HTTP2ConnectionPool
        assert isinstance(is_http2_available(), bool)

    def test_http3_available(self):
        from kewe.http.http3 import is_http3_available, HTTP3Protocol
        assert isinstance(is_http3_available(), bool)


class TestCache:
    """缓存"""

    def test_cache_ttl(self):
        from kewe.cache.manager import CacheManager
        cache = CacheManager()
        cache.set("ttl_key", "val", ttl=0.1)
        assert cache.get("ttl_key") == "val"
        time.sleep(0.15)
        assert cache.get("ttl_key") is None

    def test_cache_clear(self):
        from kewe.cache.manager import CacheManager
        cache = CacheManager()
        cache.set("k1", "v1")
        cache.set("k2", "v2")
        cache.clear()
        assert cache.get("k1") is None


class TestGateway:
    """网关"""

    def test_gateway_route(self, app):
        from kewe.gateway.core import APIGateway, GatewayRoute
        gw = APIGateway()
        gw.bind_app(app, prefix="/v1")

        async def list_items(request):
            return json_resp({"items": []})

        gw.register_route(GatewayRoute(
            path="/items", method="GET", handler=list_items, require_auth=False
        ))
        r = app.test_client.get("/v1/items")
        assert r.status == 200

    def test_error_codes(self):
        from kewe.gateway.core import ErrorCode
        assert ErrorCode.SUCCESS.code == 0
        assert ErrorCode.UNAUTHORIZED.code == 1002
        assert ErrorCode.NOT_FOUND.code == 1004


class TestCircuitBreaker:
    """熔断器"""

    def test_cb_full(self):
        from kewe.errors.circuit_breaker import (
            CircuitBreaker, CircuitBreakerConfig, CircuitState,
            CircuitBreakerRegistry, CircuitOpenError
        )
        config = CircuitBreakerConfig(failure_threshold=3, recovery_timeout=60.0)
        cb = CircuitBreaker(name="payment", config=config)
        assert cb.state in ("closed", CircuitState.CLOSED)

        def ok():
            return "success"
        assert cb.call_sync(ok) == "success"

        def fail():
            raise ValueError("fail")
        for _ in range(3):
            try:
                cb.call_sync(fail)
            except ValueError:
                pass

        registry = CircuitBreakerRegistry()
        cb2 = registry.get_or_create("inventory")
        assert cb2.name == "inventory"
        assert "inventory" in registry.get_all_status()


class TestWebSocket:
    """WebSocket"""

    def test_ws_registration(self, app):
        @app.websocket("/ws-chat")
        async def chat(ws):
            await ws.accept()

        assert hasattr(app.router, '_websocket_routes')

    def test_ws_exceptions(self):
        from kewe.websocket.exceptions import (
            WebSocketException, WebSocketClosed,
            WebSocketProtocolError, WebSocketHandshakeError
        )
        e1 = WebSocketClosed()
        assert isinstance(e1, WebSocketException)
        e2 = WebSocketProtocolError()
        assert isinstance(e2, WebSocketException)


class TestBackgroundTasks:
    """后台任务"""

    def test_task_types(self):
        from kewe.background.tasks import TaskManager, task, schedule, background_task
        mgr = TaskManager()
        assert mgr is not None
        assert callable(task)
        assert callable(schedule)
        assert callable(background_task)

    def test_async_processor(self):
        from kewe.background.async_task_processor import AsyncTaskProcessor
        assert AsyncTaskProcessor is not None

    def test_cleanup_manager(self):
        from kewe.background.cleanup_task_manager import CleanupTaskManager
        assert CleanupTaskManager is not None


class TestRequestPool:
    """RequestPool"""

    def test_pool_throughput(self):
        from kewe.request.request import RequestPool
        pool = RequestPool(max_size=200)
        for i in range(100):
            req = pool.acquire(method="GET", path=f"/api/{i}")
            pool.release(req)
        stats = pool.stats
        assert stats["created"] > 0
        assert stats["reused"] > 0
        assert stats["pool_size"] <= 200


class TestServer:
    """服务器"""

    def test_server_config(self):
        from kewe.server.http_server import KeweServer
        app = Kewe("srv_v08")
        srv = KeweServer(app=app, host="127.0.0.1", port=9995,
                         keep_alive_timeout=30, max_connections=5000)
        stats = srv.stats
        assert stats["host"] == "127.0.0.1"
        assert stats["port"] == 9995
        assert "running" in stats

    def test_asgi_adapter(self):
        from kewe.server.asgi import ASGIAdapter, create_asgi_app
        app = Kewe("asgi_v08")
        adapter = ASGIAdapter(app)
        assert adapter is not None
        asgi_app = create_asgi_app(app)
        assert asgi_app is not None

    def test_startup_manager(self):
        from kewe.server.startup import StartupManager, StartupConfig
        assert StartupConfig is not None
        app = Kewe("startup_v08")
        mgr = StartupManager(app=app)
        assert mgr is not None


class TestPlugins:
    """插件"""

    def test_openapi_schema(self):
        from kewe.plugins.openapi import OpenAPIPlugin
        app = Kewe("oa_v08")
        plugin = OpenAPIPlugin()
        plugin.setup(app, title="Blog API", version="2.0.0",
                     description="A blog API")
        spec = plugin.generate_spec()
        assert spec["openapi"] == "3.1.0"
        assert spec["info"]["title"] == "Blog API"

    def test_pydantic_available(self):
        from kewe.plugins.pydantic_support import is_pydantic_available
        assert isinstance(is_pydantic_available(), bool)


class TestWorker:
    """Worker"""

    def test_worker_imports(self):
        from kewe.worker.custom import WorkerManager, WorkerState, SocketManager
        from kewe.worker.manager import WorkerConfig, ProcessWorkerManager
        from kewe.worker.shared_ctx import SharedContext
        from kewe.worker.multiplexer import Multiplexer

        assert WorkerManager is not None
        assert WorkerState is not None
        assert WorkerConfig is not None
        assert ProcessWorkerManager is not None
        assert SharedContext is not None
        assert Multiplexer is not None


class TestDatabase:
    """数据库"""

    def test_query_types(self):
        from kewe.database.query import (
            QueryBuilder, SelectQuery, InsertQuery,
            UpdateQuery, DeleteQuery, PaginationResult
        )
        assert QueryBuilder is not None
        assert SelectQuery is not None
        assert InsertQuery is not None
        assert UpdateQuery is not None
        assert DeleteQuery is not None
        assert PaginationResult is not None

    def test_alembic_available(self):
        from kewe.database.alembic import ALEMBIC_AVAILABLE
        assert isinstance(ALEMBIC_AVAILABLE, bool)


class TestZeroCopy:
    """零拷贝"""

    def test_zero_copy_imports(self):
        from kewe.touchup.zerocopy import (
            ZeroCopySupport, SendfileTransport, MmapFileReader,
            ZeroCopyBuffer, ZeroCopyFileResponse, FileCache
        )
        assert ZeroCopySupport is not None
        assert SendfileTransport is not None
        assert MmapFileReader is not None
        assert ZeroCopyBuffer is not None
        assert ZeroCopyFileResponse is not None
        assert FileCache is not None


class TestUtils:
    """工具"""

    def test_all_helpers(self):
        from kewe.utils.helpers import (
            to_camel_case, to_snake_case, humanize_bytes,
            humanize_duration, import_string, get_env_bool
        )
        assert callable(to_camel_case)
        assert callable(to_snake_case)
        assert callable(humanize_bytes)

    def test_compat(self):
        from kewe.utils.compat import json, run_in_threadpool, sync_to_async
        data = {"key": "value", "num": 42}
        assert json.loads(json.dumps(data)) == data
        r = asyncio.run(run_in_threadpool(lambda x, y: x * y, 6, 7))
        assert r == 42

    def test_i18n(self):
        from kewe.utils.i18n import I18nConfig, setup_i18n
        cfg = I18nConfig(default_locale="zh-CN")
        assert cfg.default_locale == "zh-CN"
        assert callable(setup_i18n)

    def test_pagination(self):
        from kewe.utils.pagination import PaginationParams
        assert PaginationParams is not None

    def test_token_encryptor(self):
        from kewe.utils.token_encryptor import TokenEncryptor
        assert TokenEncryptor is not None


class TestCookies:
    """Cookies"""

    def test_signed_cookie(self):
        from kewe.cookies.signed import SignedCookieManager, TimestampSigner
        signer = TimestampSigner(secret_key="test-key-32chars!")
        assert signer is not None
        mgr = SignedCookieManager(secret_key="test-key-32chars!")
        assert mgr is not None


class TestCLI:
    """CLI"""

    def test_repl(self):
        from kewe.cli.repl import REPLContext, create_repl_context
        ctx = REPLContext()
        assert ctx is not None
        assert callable(create_repl_context)


class TestHandlers:
    """Handlers"""

    def test_file_browser(self):
        from kewe.handlers.simple import FileBrowser, generate_directory_index
        assert FileBrowser is not None
        assert callable(generate_directory_index)


class TestFactory:
    """Factory"""

    def test_create_app(self):
        from kewe.factory import create_app
        app = create_app("test_app")
        assert app is not None
