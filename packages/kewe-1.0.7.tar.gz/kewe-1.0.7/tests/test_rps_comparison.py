#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""v1.1 KeWe vs Sanic vs FastAPI 真实RPS对比"""

import time, json as stdlib_json
from kewe import Kewe, KeweConfig
from kewe.response import json as kewe_json_resp
from kewe.utils.compat import json as kewe_orjson


def bench(name, fn, n):
    t0 = time.perf_counter()
    fn(n)
    e = time.perf_counter() - t0
    return {"name": name, "rps": n/e if e>0 else 0, "lat_ms": e/n*1000 if n>0 else 0}


class TestJSONCompare:
    PAYLOAD = {"users": [{"id": i, "name": f"u{i}"} for i in range(50)]}

    def test_stdlib_dumps(self):
        r = bench("stdlib json", lambda n: [stdlib_json.dumps(self.PAYLOAD) for _ in range(n)], 5000)
        assert r["rps"] > 0; return r

    def test_orjson_dumps(self):
        r = bench("orjson", lambda n: [kewe_orjson.dumps(self.PAYLOAD) for _ in range(n)], 5000)
        assert r["rps"] > 0; return r

    def test_stdlib_loads(self):
        s = stdlib_json.dumps(self.PAYLOAD)
        r = bench("stdlib loads", lambda n: [stdlib_json.loads(s) for _ in range(n)], 5000)
        assert r["rps"] > 0; return r

    def test_orjson_loads(self):
        s = kewe_orjson.dumps(self.PAYLOAD)
        r = bench("orjson loads", lambda n: [kewe_orjson.loads(s) for _ in range(n)], 5000)
        assert r["rps"] > 0; return r


class TestKeWeRPS:
    def test_simple_get(self):
        app = Kewe("k", config=KeweConfig(secret_key="x"))
        @app.get("/api/hello")
        async def h(request): return kewe_json_resp({"m": "H"})
        c = app.test_client
        r = bench("KeWe GET /api/hello", lambda n: [c.get("/api/hello") for _ in range(n)], 500)
        assert r["rps"] > 0; return r

    def test_path_param(self):
        app = Kewe("k", config=KeweConfig(secret_key="x"))
        @app.get("/users/<id:int>")
        async def h(request, id: int): return kewe_json_resp({"id": id})
        c = app.test_client
        r = bench("KeWe GET /users/:id", lambda n: [c.get(f"/users/{i%100}") for i in range(n)], 500)
        assert r["rps"] > 0; return r

    def test_post_json(self):
        app = Kewe("k", config=KeweConfig(secret_key="x"))
        @app.post("/api/echo")
        async def h(request):
            b = await request.json_async; return kewe_json_resp(b)
        c = app.test_client
        payload = {"key": "val", "num": 42}
        r = bench("KeWe POST /api/echo", lambda n: [c.post("/api/echo", json=payload) for _ in range(n)], 300)
        assert r["rps"] > 0; return r

    def test_di_query(self):
        from kewe.application.depends import Depends, Query
        app = Kewe("k", config=KeweConfig(secret_key="x"))
        async def db(): return "db_conn"
        @app.get("/api/data")
        async def h(request, db=Depends(db), page: int = Query(default=1, ge=1)):
            return kewe_json_resp({"db": db, "page": page})
        c = app.test_client
        r = bench("KeWe DI+Query", lambda n: [c.get("/api/data?page=2") for _ in range(n)], 300)
        assert r["rps"] > 0; return r


class TestSanicRPS:
    def test_simple_get(self):
        import sanic
        from sanic import Sanic
        from sanic.response import json as sj
        app = Sanic("sanic_test")
        @app.get("/api/hello")
        async def h(request): return sj({"m": "H"})
        tc = app.test_client
        r = bench("Sanic GET /api/hello", lambda n: [tc.get("/api/hello")[1] for _ in range(n)], 500)
        assert r["rps"] > 0; return r

    def test_path_param(self):
        from sanic import Sanic
        from sanic.response import json as sj
        app = Sanic("sanic_param_test")
        @app.get("/users/<id:int>")
        async def h(request, id: int): return sj({"id": id})
        tc = app.test_client
        r = bench("Sanic GET /users/:id", lambda n: [tc.get(f"/users/{i%100}")[1] for i in range(n)], 500)
        assert r["rps"] > 0; return r

    def test_post_json(self):
        from sanic import Sanic
        from sanic.response import json as sj
        app = Sanic("sanic_post_test")
        @app.post("/api/echo")
        async def h(request): return sj(request.json)
        tc = app.test_client
        payload = {"key": "val", "num": 42}
        r = bench("Sanic POST /api/echo", lambda n: [tc.post("/api/echo", json=payload) for _ in range(n)], 300)
        assert r["rps"] > 0; return r


class TestFastAPIRPS:
    def test_simple_get(self):
        from fastapi import FastAPI
        from fastapi.testclient import TestClient
        from fastapi.responses import JSONResponse
        app = FastAPI()
        @app.get("/api/hello")
        async def h(): return JSONResponse({"m": "H"})
        c = TestClient(app)
        r = bench("FastAPI GET /api/hello", lambda n: [c.get("/api/hello") for _ in range(n)], 500)
        assert r["rps"] > 0; return r

    def test_path_param(self):
        from fastapi import FastAPI
        from fastapi.testclient import TestClient
        from fastapi.responses import JSONResponse
        app = FastAPI()
        @app.get("/users/{id}")
        async def h(id: int): return JSONResponse({"id": id})
        c = TestClient(app)
        r = bench("FastAPI GET /users/{id}", lambda n: [c.get(f"/users/{i%100}") for i in range(n)], 500)
        assert r["rps"] > 0; return r

    def test_post_json(self):
        from fastapi import FastAPI
        from fastapi.testclient import TestClient
        from fastapi.responses import JSONResponse
        app = FastAPI()
        @app.post("/api/echo")
        async def h(body: dict):
            return JSONResponse(body)
        c = TestClient(app)
        payload = {"key": "val", "num": 42}
        r = bench("FastAPI POST /api/echo", lambda n: [c.post("/api/echo", json=payload) for _ in range(n)], 300)
        assert r["rps"] > 0; return r

    def test_di_query(self):
        from fastapi import FastAPI, Query, Depends
        from fastapi.testclient import TestClient
        from fastapi.responses import JSONResponse
        async def db(): return "db_conn"
        app = FastAPI()
        @app.get("/api/data")
        async def h(db: str = Depends(db), page: int = Query(1, ge=1)):
            return JSONResponse({"db": db, "page": page})
        c = TestClient(app)
        r = bench("FastAPI DI+Query", lambda n: [c.get("/api/data?page=2") for _ in range(n)], 300)
        assert r["rps"] > 0; return r


class TestFlaskRPS:
    def test_simple_get(self):
        from flask import Flask, jsonify
        app = Flask("flask_test")
        @app.get("/api/hello")
        def h(): return jsonify({"m": "H"})
        c = app.test_client()
        r = bench("Flask GET /api/hello", lambda n: [c.get("/api/hello") for _ in range(n)], 500)
        assert r["rps"] > 0; return r


class TestRPSSummary:
    def test_full_comparison(self):
        print("\n" + "="*80)
        print("  KeWe vs Sanic vs FastAPI vs Flask — 真实 RPS 对比")
        print("="*80)

        results = []
        results.append(TestJSONCompare().test_stdlib_dumps())
        results.append(TestJSONCompare().test_orjson_dumps())

        for m in ["test_simple_get", "test_path_param", "test_post_json", "test_di_query"]:
            results.append(getattr(TestKeWeRPS(), m)())

        for m in ["test_simple_get", "test_path_param", "test_post_json"]:
            results.append(getattr(TestSanicRPS(), m)())

        for m in ["test_simple_get", "test_path_param", "test_post_json", "test_di_query"]:
            results.append(getattr(TestFastAPIRPS(), m)())

        results.append(TestFlaskRPS().test_simple_get())

        print(f"\n{'Benchmark':<40} {'RPS':>10} {'Lat(ms)':>10}")
        print("-"*62)
        for r in results:
            print(f"{r['name']:<40} {r['rps']:>10.1f} {r['lat_ms']:>10.3f}")

        # 分组平均 (HTTP路由部分)
        kw = [r["rps"] for r in results if r["name"].startswith("KeWe ")]
        sn = [r["rps"] for r in results if r["name"].startswith("Sanic ")]
        fa = [r["rps"] for r in results if r["name"].startswith("FastAPI ")]

        avg = lambda x: sum(x)/len(x) if x else 0
        print("-"*62)
        print(f"{'KeWe 平均 (HTTP路由)':<40} {avg(kw):>10.1f}")
        print(f"{'Sanic 平均 (HTTP路由)':<40} {avg(sn):>10.1f}")
        print(f"{'FastAPI 平均 (HTTP路由)':<40} {avg(fa):>10.1f}")
        print("-"*62)
        if avg(sn)>0: print(f"KeWe vs Sanic: {avg(kw)/avg(sn):.2f}x")
        if avg(fa)>0: print(f"KeWe vs FastAPI: {avg(kw)/avg(fa):.2f}x")
        print("="*80)

        assert len(kw) >= 4
        assert len(sn) >= 3
        assert len(fa) >= 4
