#!/usr/bin/env python

"错误处理测试"""



import pytest

from kewe import Kewe

from kewe.errors.exceptions import NotFound, BadRequest, Unauthorized, Forbidden, InternalServerError





@pytest.mark.asyncio

async def test_404_error():

    "测试404错误处理"""

    app = Kewe("TestApp", enable_gateway=False)

    

    @app.get("/test")

    async def test_handler(request):

        return {"message": "test"}

    

    from kewe.utils.testing import AsyncTestClient

    client = AsyncTestClient(app)

    response = await client.get("/nonexistent")

    

    assert response.status == 404

    json_body = response.json

    assert json_body is not None

    assert "not found" in json_body.get("title", json_body.get("error", "")).lower()





@pytest.mark.asyncio

async def test_custom_error_handler():

    "测试自定义错误处理器"""

    app = Kewe("TestApp", enable_gateway=False)

    

    @app.exception(404)

    async def custom_404_handler(request, exception):

        return {"error": "Custom 404", "path": request.path}

    

    # 使用异步测试客户
    from kewe.utils.testing import AsyncTestClient

    client = AsyncTestClient(app)

    response = await client.get("/nonexistent")

    

    assert response.status == 404

    assert response.json == {"error": "Custom 404", "path": "/nonexistent"}





@pytest.mark.asyncio

async def test_500_error():

    "测试500错误处理"""

    app = Kewe("TestApp", enable_gateway=False)

    

    @app.get("/error")

    async def error_handler(request):

        raise InternalServerError("Internal Server Error")

    

    # 使用异步测试客户
    from kewe.utils.testing import AsyncTestClient

    client = AsyncTestClient(app)

    response = await client.get("/error")

    

    assert response.status == 500

    json_body = response.json

    assert json_body is not None

    assert "Internal Server Error" in json_body.get("title", json_body.get("error", ""))





@pytest.mark.asyncio

async def test_bad_request_error():

    "测试400错误处理"""

    app = Kewe("TestApp", enable_gateway=False)

    

    @app.post("/bad-request")

    async def bad_request_handler(request):

        data = await request.json

        if not data or "name" not in data:

            raise BadRequest("Missing required field: name")

        return {"name": data["name"]}

    

    # 使用异步测试客户
    from kewe.utils.testing import AsyncTestClient

    client = AsyncTestClient(app)

    response = await client.post("/bad-request", json={})

    

    assert response.status == 400

    json_body = response.json

    assert json_body is not None

    assert "Missing required field: name" in json_body.get("title", json_body.get("message", ""))

