#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""深度覆盖测试 — 覆盖剩余低覆盖率模块"""

import pytest
import asyncio
import time
import os
import tempfile
from kewe import Kewe, KeweConfig


@pytest.fixture
def app():
    return Kewe("deep_test", config=KeweConfig(secret_key="deep-test-key"))


class TestDeepErrorHandling:
    """深度异常处理测试"""

    def test_all_http_exceptions_status_codes(self):
        """验证所有HTTP异常类的status_code正确"""
        from kewe.errors.exceptions import (
            BadRequest, Unauthorized, PaymentRequired, Forbidden,
            NotFound, MethodNotAllowed, NotAcceptable,
            ProxyAuthenticationRequired, RequestTimeout,
            Conflict, Gone, LengthRequired, PreconditionFailed,
            PayloadTooLarge, UriTooLong, UnsupportedMediaType,
            RangeNotSatisfiable, ExpectationFailed, MisdirectedRequest,
            ImATeapot, UnprocessableEntity, Locked, FailedDependency,
            TooEarly, UpgradeRequired, PreconditionRequired,
            TooManyRequests, RequestHeaderFieldsTooLarge,
            UnavailableForLegalReasons,
            InternalServerError, NotImplemented as HTTPNotImplemented,
            BadGateway, ServiceUnavailable, GatewayTimeout,
            HttpVersionNotSupported, VariantAlsoNegotiates,
            InsufficientStorage, LoopDetected, NotExtended,
            NetworkAuthenticationRequired
        )
        exceptions = [
            (BadRequest, 400), (Unauthorized, 401), (PaymentRequired, 402),
            (Forbidden, 403), (NotFound, 404), (MethodNotAllowed, 405),
            (NotAcceptable, 406), (ProxyAuthenticationRequired, 407),
            (RequestTimeout, 408), (Conflict, 409), (Gone, 410),
            (LengthRequired, 411), (PreconditionFailed, 412),
            (PayloadTooLarge, 413), (UriTooLong, 414),
            (UnsupportedMediaType, 415), (RangeNotSatisfiable, 416),
            (ExpectationFailed, 417), (ImATeapot, 418),
            (MisdirectedRequest, 421), (UnprocessableEntity, 422),
            (Locked, 423), (FailedDependency, 424), (TooEarly, 425),
            (UpgradeRequired, 426), (PreconditionRequired, 428),
            (TooManyRequests, 429), (RequestHeaderFieldsTooLarge, 431),
            (UnavailableForLegalReasons, 451),
            (InternalServerError, 500), (HTTPNotImplemented, 501),
            (BadGateway, 502), (ServiceUnavailable, 503),
            (GatewayTimeout, 504), (HttpVersionNotSupported, 505),
            (VariantAlsoNegotiates, 506), (InsufficientStorage, 507),
            (LoopDetected, 508), (NotExtended, 510),
            (NetworkAuthenticationRequired, 511),
        ]
        for exc_class, expected_code in exceptions:
            exc = exc_class()
            assert exc.status_code == expected_code, f"{exc_class.__name__}: {exc.status_code} != {expected_code}"

    def test_kewe_exception_to_problem_details(self):
        """验证KeweException.to_problem_details RFC 7807格式"""
        from kewe.errors.exceptions import NotFound
        exc = NotFound(detail="User 123 not found")
        details = exc.to_problem_details("/users/123")
        assert details["status"] == 404
        assert details["title"] in ("Not Found", "Not found")
        assert "/users/123" in str(details.get("instance", ""))

    def test_kewe_exception_get_headers(self):
        """验证异常返回正确的响应头"""
        from kewe.errors.exceptions import (
            Unauthorized, MethodNotAllowed, TooManyRequests
        )
        exc1 = Unauthorized(www_authenticate="Bearer realm=api")
        headers1 = exc1.get_headers()
        assert "WWW-Authenticate" in headers1

        exc2 = MethodNotAllowed(allowed_methods=["GET", "POST"])
        headers2 = exc2.get_headers()
        assert "Allow" in headers2

        exc3 = TooManyRequests(retry_after=30)
        headers3 = exc3.get_headers()
        assert "Retry-After" in headers3

    def test_abort_with_response(self):
        """验证abort(Response(...))行为"""
        from kewe.response import json as _json
        from kewe.errors.exceptions import abort, _AbortResponse
        resp = _json({"custom": "abort"}, status=400)
        try:
            abort(resp)
            assert False, "Should have raised _AbortResponse"
        except _AbortResponse as e:
            assert e.response is resp


class TestDeepDI:
    """深度依赖注入测试"""

    def test_security_dependency_with_scopes(self, app):
        """验证Security依赖+作用域"""
        from kewe.application.depends import Security, Depends

        async def get_token(request):
            return request.headers.get("authorization", "")

        @app.get("/secure")
        async def secure(request, token=Security(get_token, scopes=["read", "write"])):
            from kewe.response import json as j
            return j({"token": token})

        client = app.test_client
        resp = client.get("/secure", headers={"authorization": "Bearer test123"})
        assert resp.status == 200
        assert resp.json["token"] == "Bearer test123"

    def test_body_dependency(self, app):
        """验证Body参数提取"""
        from kewe.application.depends import Body, Depends

        @app.post("/body-extract")
        async def body_extract(request, data: dict = Body()):
            from kewe.response import json as j
            return j(data)

        client = app.test_client
        resp = client.post("/body-extract", json={"name": "test", "value": 42})
        assert resp.status == 200
        assert resp.json["name"] == "test"

    def test_form_dependency(self, app):
        """验证Form参数提取"""
        from kewe.application.depends import Form, Depends

        @app.post("/form-extract")
        async def form_extract(request, username: str = Form(default="")):
            from kewe.response import json as j
            return j({"username": username})

        client = app.test_client
        resp = client.post("/form-extract", data={"username": "alice"})
        assert resp.status in (200, 422)


class TestDeepSignals:
    """深度信号系统测试"""

    def test_signal_bus(self):
        """验证SignalBus基本功能"""
        from kewe.application.signals import SignalBus
        bus = SignalBus()
        assert bus is not None
        assert hasattr(bus, 'on')
        assert hasattr(bus, 'emit') or hasattr(bus, 'trigger')

    def test_signal_manager(self, app):
        """验证SignalManager与app集成"""
        from kewe.application.signals import SignalManager
        mgr = SignalManager(app)
        received = []

        @mgr.on("order.created")
        async def on_order(data):
            received.append(data)

        assert callable(on_order)

    def test_app_signal_decorator(self, app):
        """验证@app.signal()装饰器"""
        received = []

        @app.signal("user.registered")
        async def on_user_registered(data):
            received.append(data)

        assert callable(on_user_registered)


class TestDeepState:
    """深度状态管理测试"""

    def test_state_manager(self, app):
        """验证StateManager"""
        from kewe.application.state import StateManager
        mgr = StateManager()
        assert mgr is not None

    def test_app_state_enum(self):
        """验证AppState枚举"""
        from kewe.application.state import AppState
        assert AppState.STARTING is not None
        assert AppState.RUNNING is not None
        assert AppState.STOPPED is not None


class TestDeepLifecycle:
    """深度生命周期测试"""

    def test_lifecycle_hooks(self, app):
        """验证生命周期钩子注册"""
        startup_called = []
        shutdown_called = []

        @app.before_server_start
        async def before_start(app_inst):
            startup_called.append(True)

        @app.after_server_stop
        async def after_stop(app_inst):
            shutdown_called.append(True)

        assert callable(before_start)
        assert callable(after_stop)


class TestDeepStatic:
    """深度静态文件测试"""

    def test_send_file_exists(self):
        """验证send_file可用"""
        from kewe.handlers.static_serve import StaticFileHandler
        handler = StaticFileHandler()
        assert handler is not None


class TestDeepLogging:
    """深度日志系统测试"""

    def test_log_levels(self):
        """验证日志级别"""
        from kewe.logging.logger import get_logger, debug, info, warning, error, critical
        logger = get_logger("test_deep")
        assert logger is not None

    def test_setup_logging(self):
        """验证setup_logging函数"""
        from kewe.logging.logger import setup_logging
        assert callable(setup_logging)

    def test_logging_formatters(self):
        """验证日志格式化器"""
        from kewe.logging.formatters import ColoredFormatter
        assert ColoredFormatter is not None


class TestDeepCompat:
    """深度兼容模块测试"""

    def test_json_wrapper_dumps_loads(self):
        """验证JsonWrapper dumps/loads"""
        from kewe.utils.compat import json
        data = {"key": "value", "num": 42, "list": [1, 2, 3]}
        encoded = json.dumps(data)
        assert isinstance(encoded, str)
        decoded = json.loads(encoded)
        assert decoded == data

    def test_json_wrapper_with_nan(self):
        """验证JsonWrapper处理NaN"""
        import math
        from kewe.utils.compat import json
        data = {"val": float('nan'), "inf": float('inf')}
        encoded = json.dumps(data)
        assert encoded is not None
        assert "null" in encoded.lower() or "NaN" not in encoded

    def test_run_in_threadpool(self):
        """验证run_in_threadpool"""
        from kewe.utils.compat import run_in_threadpool

        def blocking_func(x, y):
            return x + y

        result = asyncio.run(run_in_threadpool(blocking_func, 1, 2))
        assert result == 3

    def test_sync_to_async(self):
        """验证sync_to_async"""
        from kewe.utils.compat import sync_to_async

        @sync_to_async
        def blocking_func(x, y):
            return x * y

        result = asyncio.run(blocking_func(6, 7))
        assert result == 42


class TestDeepRequestPool:
    """深度RequestPool测试"""

    def test_request_pool_basic(self):
        """验证RequestPool基本功能"""
        from kewe.request.request import RequestPool
        pool = RequestPool(max_size=10)

        req = pool.acquire(method="GET", path="/test")
        assert req.method == "GET"
        assert req.path == "/test"

        pool.release(req)
        stats = pool.stats
        assert stats["created"] == 1
        assert stats["reused"] == 0
        assert stats["pool_size"] == 1

    def test_request_pool_reuse(self):
        """验证RequestPool对象复用"""
        from kewe.request.request import RequestPool
        pool = RequestPool(max_size=10)

        req1 = pool.acquire(method="GET", path="/a")
        pool.release(req1)

        req2 = pool.acquire(method="POST", path="/b")
        pool.release(req2)

        req3 = pool.acquire(method="PUT", path="/c")

        stats = pool.stats
        assert stats["reused"] >= 1

    def test_request_pool_overflow(self):
        """验证RequestPool超出容量时不回收"""
        from kewe.request.request import RequestPool
        pool = RequestPool(max_size=2)

        reqs = []
        for i in range(5):
            req = pool.acquire(method="GET", path=f"/{i}")
            reqs.append(req)
        for req in reqs:
            pool.release(req)

        stats = pool.stats
        assert stats["pool_size"] <= 2


class TestDeepKeweConfig:
    """深度配置测试"""

    def test_config_all_fields(self):
        """验证KeweConfig核心字段"""
        config = KeweConfig(
            secret_key="test-key",
            debug=True,
            host="localhost",
            port=9000,
            keep_alive=True,
            keep_alive_timeout=30,
            request_max_size=5_000_000,
        )
        assert config.secret_key == "test-key"
        assert config.port == 9000
        assert config.keep_alive is True
        assert config.keep_alive_timeout == 30
