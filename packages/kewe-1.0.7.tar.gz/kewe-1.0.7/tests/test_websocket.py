#!/usr/bin/env python
"WebSocket 功能测试"""

import pytest

from kewe import Kewe
from kewe.utils.testing import AsyncTestClient


@pytest.mark.asyncio
async def test_websocket_basic():
    app = Kewe("TestApp", enable_gateway=False)
    received_messages = []

    @app.websocket("/ws")
    async def websocket_handler(websocket):
        await websocket.accept()
        message = await websocket.receive()
        received_messages.append(message)
        await websocket.send(f"Echo: {message}")
        await websocket.close()

    async with AsyncTestClient(app) as client:
        ws = await client.websocket("/ws")
        await ws.send("hello")
        response = await ws.receive_text()

    assert response == "Echo: hello"
    assert received_messages == ["hello"]


@pytest.mark.asyncio
async def test_websocket_json():
    app = Kewe("TestApp", enable_gateway=False)

    @app.websocket("/ws/json")
    async def websocket_json_handler(websocket):
        await websocket.accept()
        payload = await websocket.receive_json()
        await websocket.send_json({"received": payload})
        await websocket.close()

    async with AsyncTestClient(app) as client:
        ws = await client.websocket("/ws/json")
        await ws.send_json({"value": 42})
        response = await ws.receive_json()

    assert response == {"received": {"value": 42}}
