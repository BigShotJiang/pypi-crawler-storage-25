# KeWe 框架文档 v1.0.0

## 一、概述

KeWe 是一个高性能、全异步的 Python Web 框架，专为前后端完全分离的现代应用设计。框架内置了 API 网关、熔断器、依赖注入、JWT 认证、RBAC 权限管理、HTTP/2、HTTP/3 等企业级特性。

### 1.1 设计理念
- **前后端完全分离**: 纯 API 框架，不含模板引擎，专注 JSON/数据接口
- **性能优先**: 内置 orjson (4-5x stdlib)、Trie 路由 + LRU 缓存、RequestPool 对象池
- **企业级就绪**: API 网关、熔断器、限流、JWT/RBAC/CSRF 开箱即用
- **开发者友好**: 声明式 DI、自动 OpenAPI 3.1.0、RFC 7807 验证错误

### 1.2 版本信息
- 当前版本: **v1.0.0**
- Python 支持: 3.12+ (兼容 3.14)
- 许可协议: MIT
- 测试: **994** passed, 8 skipped, 0 failed
- Benchmark: **80** 用例 (40 生产 + 23 对比 + 17 RPS)
- 落地评分: **98/100**

### 1.3 安装
```bash
pip install kewe
```

## 二、快速开始

### 2.1 Hello World
```python
from kewe import Kewe, json

app = Kewe(name="my_app")

@app.get("/")
async def hello(request):
    return json({"message": "Hello KeWe!"})

if __name__ == "__main__":
    app.run()
```

### 2.2 应用工厂
```python
from kewe import Kewe, KeweConfig

config = KeweConfig(
    secret_key="my-secret-key",
    debug=True,
    host="0.0.0.0",
    port=8000,
    keep_alive=True,
    keep_alive_timeout=60,
    request_max_size=10_000_000,
)
app = Kewe(name="production_app", config=config)
```

### 2.3 create_app 工厂函数
```python
from kewe import create_app, KeweConfig

app = create_app("my_app", config=KeweConfig(secret_key="key"))
```

### 2.4 CLI 启动
```bash
kewe run app:app --host 0.0.0.0 --port 8000 --workers 4
```

## 三、路由系统

### 3.1 基本路由
```python
@app.route("/hello")
async def hello(request):
    return json({"message": "hello"})
```

### 3.2 HTTP 方法路由
```python
@app.get("/items")
async def get_items(request):
    return json([])

@app.post("/items")
async def create_item(request):
    body = await request.json_async
    return json(body, status=201)

@app.put("/items/<id:int>")
async def update_item(request, id: int):
    return json({"id": id})

@app.delete("/items/<id:int>")
async def delete_item(request, id: int):
    return json({"deleted": id})

@app.patch("/items/<id:int>")
async def patch_item(request, id: int):
    return json({"patched": id})
```

### 3.3 路径参数与类型转换
```python
# 支持的类型: int, float, str, uuid, path
@app.get("/users/<user_id>")
async def get_user(request, user_id):
    return json({"user_id": user_id})

@app.get("/users/<user_id>/posts/<post_id:int>")
async def get_post(request, user_id, post_id: int):
    return json({"user": user_id, "post": post_id})

@app.get("/files/<filepath:path>")
async def get_file(request, filepath):
    return json({"path": filepath})
```

### 3.4 路由命名与 url_for
```python
@app.get("/users/<id:int>", name="user_detail")
async def user_detail(request, id: int):
    return json({"id": id})

url = app.url_for("user_detail", id=42)  # /users/42
```

### 3.5 OpenAPI 元数据
```python
@app.get("/items",
    tags=["Items"],
    summary="获取所有项目",
    description="返回分页的项目列表",
    operation_id="list_items",
    deprecated=False,
    response_model=ItemSchema,
    status_code=200,
)
async def list_items(request):
    return json([])
```

### 3.6 路由版本控制
```python
@app.route("/data", version=2, version_prefix="v")
async def v2_data(request):
    return json({"version": "v2"})
```

### 3.7 路由级依赖注入
```python
async def check_api_key(request):
    key = request.headers.get("x-api-key")
    if key != "secret":
        raise Unauthorized()
    return {"verified": True}

@app.get("/protected", dependencies=[check_api_key])
async def protected(request):
    return json({"ok": True})
```

### 3.8 独立 Router
```python
from kewe import Router

router = Router()

@router.get("/inner")
async def inner(request):
    return json({"from": "router"})

app.include_router(router, prefix="/api/v1")
```

### 3.9 动态路由注册
```python
async def custom_handler(request):
    return json({"custom": True})

app.add_api_route("/dynamic", custom_handler, methods=["GET", "POST"],
                   tags=["Custom"], summary="Dynamic route")
```

### 3.10 路由性能
- **匹配算法**: Trie 字典树，O(log n) 复杂度
- **缓存**: LRU 缓存最近匹配结果，O(1) 命中
- **性能**: 静态路由 <0.5ms，url_for <0.05ms (50K ops/s)
- **唯一命名**: `_unique_route_name()` 自动处理循环中的 handler 名称冲突

## 四、蓝图系统

### 4.1 定义蓝图
```python
from kewe import Blueprint

users_bp = Blueprint("users")

@users_bp.get("/")
async def list_users(request):
    return json({"users": []})

@users_bp.get("/<id:int>")
async def get_user(request, id: int):
    return json({"id": id})
```

### 4.2 注册蓝图
```python
app.register_blueprint(users_bp, url_prefix="/api/users")
```

### 4.3 蓝图中间件
```python
@users_bp.middleware("request")
async def bp_logger(request):
    print(f"Accessing blueprint: {request.path}")
    return True

@users_bp.middleware("response")
async def bp_headers(request, response):
    response.headers["X-Blueprint"] = "users"
    return response
```

### 4.4 蓝图组
```python
from kewe import group

bp1 = Blueprint("v1")
bp2 = Blueprint("v2")

group1 = group(bp1, bp2, url_prefix="/api")
app.register_blueprint(group1)
```

### 4.5 蓝图 WebSocket
```python
@users_bp.websocket("/chat")
async def user_chat(websocket):
    await websocket.accept()
    while True:
        data = await websocket.receive()
        await websocket.send(data)
```

## 五、响应模块

### 5.1 JSON 响应
```python
from kewe import json, JSONResponse

resp1 = json({"key": "value"})
resp2 = JSONResponse({"key": "value"})
resp3 = json({"data": 1}, status=201, headers={"X-Custom": "header"})
```

### 5.2 文本/HTML 响应
```python
from kewe import text, html, PlainTextResponse, HTMLResponse

resp1 = text("Hello World")
resp2 = html("<h1>Hello</h1>")
resp3 = PlainTextResponse("plain text")
resp4 = HTMLResponse("<p>HTML</p>")
```

### 5.3 重定向
```python
from kewe import redirect, RedirectResponse

resp1 = redirect("/new-url")
resp2 = RedirectResponse("/new-url", status_code=301)
```

### 5.4 文件响应
```python
from kewe import file, FileResponse

resp1 = file("/path/to/document.pdf")
resp2 = FileResponse("/path/to/document.pdf")

app.send_file("/path/to/document.pdf")
app.send_from_directory("/var/data", "report.csv")
```

### 5.5 静态文件服务
```python
app.static("/static", "/var/www/static")
```

### 5.6 流式响应
```python
from kewe import StreamingResponse

async def data_generator():
    for i in range(100):
        yield json.dumps({"item": i}).encode()
        await asyncio.sleep(0.1)

@app.get("/stream")
async def stream(request):
    return StreamingResponse(data_generator(), media_type="application/x-ndjson")
```

### 5.7 Server-Sent Events (SSE)
```python
from kewe.response.streaming import ServerSentEventResponse, sse

async def event_stream():
    for i in range(100):
        yield sse({"event": "update", "data": i})
        await asyncio.sleep(1)

@app.get("/events")
async def events(request):
    return ServerSentEventResponse(event_stream())
```

### 5.8 后台任务
```python
from kewe import BackgroundTask, BackgroundTasks

async def send_notification():
    pass

@app.post("/users")
async def create_user(request):
    resp = json({"created": True}, status=201)
    resp.background = BackgroundTask(send_notification)
    return resp

# 多个后台任务
resp.background = BackgroundTasks([task1, task2, task3])
```

### 5.9 元组返回
```python
@app.get("/tuple1")
async def handler1(request):
    return {"key": "value"}, 201

@app.get("/tuple2")
async def handler2(request):
    return {"key": "value"}, 201, {"X-Custom": "header"}
```

### 5.10 Cookie 操作
```python
resp = json({"ok": True})
resp.set_cookie("session_id", "abc123", max_age=3600, httponly=True, secure=True, samesite="lax")
resp.delete_cookie("old_cookie")
```

## 六、请求模块

### 6.1 请求对象属性
```python
@app.get("/info")
async def info(request):
    return json({
        "method": request.method,
        "path": request.path,
        "url": str(request.url),
        "client_ip": request.client_ip,
        "headers": dict(request.headers),
        "content_type": request.content_type,
    })
```

### 6.2 查询参数
```python
@app.get("/search")
async def search(request):
    q = request.query_params.get("q", "")
    page = int(request.query_params.get("page", 1))
    return json({"query": q, "page": page})
```

### 6.3 JSON 请求体
```python
@app.post("/echo")
async def echo(request):
    body = await request.json_async
    return json(body)
```

### 6.4 表单数据
```python
@app.post("/form")
async def form(request):
    data = await request.form_async
    return json({"form": data})
```

### 6.5 文件上传
```python
@app.post("/upload")
async def upload(request):
    files = await request.files_async
    for name, file_obj in files.items():
        content = await file_obj.read()
    return json({"uploaded": True})
```

### 6.6 Cookies 读取
```python
@app.get("/cookies")
async def cookies(request):
    session_id = request.cookies.get("session_id", "")
    return json({"session": session_id})
```

## 七、中间件系统

### 7.1 请求中间件
```python
@app.middleware("request")
async def authenticate(request):
    token = request.headers.get("authorization")
    if not token:
        raise Unauthorized()
    return True
```

### 7.2 响应中间件
```python
@app.middleware("response")
async def add_security_headers(request, response):
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    return response
```

### 7.3 洋葱中间件
```python
@app.middleware("onion")
async def timing_middleware(request, call_next):
    start = time.time()
    response = await call_next(request)
    elapsed = time.time() - start
    response.headers["X-Response-Time"] = str(elapsed)
    return response
```

### 7.4 中间件优先级
```python
@app.middleware("request", priority=100)  # 高优先级，先执行
async def first(request):
    return True

@app.middleware("request", priority=0)    # 低优先级，后执行
async def last(request):
    return True
```

### 7.5 类中间件
```python
class CustomMiddleware:
    async def __call__(self, request, call_next):
        response = await call_next(request)
        response.headers["X-Powered-By"] = "KeWe"
        return response

app.add_middleware(CustomMiddleware)
```

### 7.6 中间件栈构建
```python
app.build_middleware_stack()  # 预编译 ASGI 中间件栈
```

### 7.7 内置中间件
```python
# CORS 跨域
app.cors(origins=["https://example.com"], methods=["GET","POST"],
         headers=["Authorization"], max_age=3600, credentials=True)

# HTTPS 重定向
app.enable_https_redirect()

# 安全头
app.config = KeweConfig(enable_security_headers=True)

# 压缩
app.enable_compression()

# 可信主机
app.trusted_hosts(["example.com"])
```

## 八、依赖注入系统 (RFC 7807 全覆盖)

### 8.1 Depends 基础
```python
from kewe.application.depends import Depends

async def get_database():
    return Database()

@app.get("/data")
async def get_data(request, db=Depends(get_database)):
    data = await db.query("SELECT * FROM items")
    return json(data)
```

### 8.2 参数提取器 — 全部支持 RFC 7807 验证

**Query 参数** (loc=["query","field"])
```python
@app.get("/search")
async def search(request, q: str = Query(default=""),
                 page: int = Query(default=1, ge=1, le=100)):
    return json({"q": q, "page": page})
```

**Header 参数** (loc=["header","field"])
```python
@app.get("/protected")
async def protected(request, api_key: str = Header()):
    return json({"key": api_key})
```

**Cookie 参数** (loc=["cookie","field"])
```python
@app.get("/session")
async def session_handler(request, session_id: str = CookieParam()):
    return json({"session": session_id})
```

**Path 参数** (loc=["path","field"])
```python
@app.get("/users/<user_id>")
async def user(request, user_id: str = Path()):
    return json({"id": user_id})
```

**Body 参数** (loc=["body","field"])
```python
@app.post("/create")
async def create(request, data: dict = Body()):
    return json(data, status=201)
```

**Form 参数** (loc=["form","field"])
```python
@app.post("/login")
async def login(request, username: str = Form(), password: str = Form()):
    return json({"user": username})
```

**File 上传** (loc=["body","field"])
```python
@app.post("/upload")
async def upload(request, file: bytes = File()):
    return json({"size": len(file)})
```

### 8.3 验证错误格式 (RFC 7807, 422)
```json
{
    "type": "about:blank",
    "title": "Validation Error",
    "status": 422,
    "detail": "Request validation failed",
    "errors": [
        {"loc": ["query", "page"], "msg": "Must be >= 1", "type": "ge"},
        {"loc": ["body", "name"], "msg": "Field 'name' is required", "type": "missing"}
    ]
}
```

### 8.4 Security 依赖
```python
from kewe.application.depends import Security

async def get_current_user(token: str = Header(name="authorization")):
    return decode_token(token)

@app.get("/me")
async def me(request, user=Security(get_current_user, scopes=["read"])):
    return json(user)
```

### 8.5 嵌套依赖
```python
async def get_db_connection():
    return Connection()

async def get_repository(db=Depends(get_db_connection)):
    return Repository(db)

@app.get("/items")
async def items(request, repo=Depends(get_repository)):
    return json(await repo.all())
```

### 8.6 依赖覆盖 (测试用)
```python
async def real_db():
    return ProductionDB()

async def mock_db():
    return MockDB()

app.dependency_overrides[real_db] = mock_db
# 所有依赖 real_db 的地方现在使用 mock_db
```

### 8.7 Container 容器
```python
from kewe.application.di import Container, Lifetime, ServiceProvider

container = Container()
container.register(Database, lifetime=Lifetime.SINGLETON)
container.register(Repository, lifetime=Lifetime.SCOPED)

db = await container.resolve(Database)
```

## 九、安全系统

### 9.1 JWT 认证
```python
from kewe import JWTAuthManager, SecurityContext

jwt = JWTAuthManager(secret_key="my-secret-key")

# 生成 Token
ctx = SecurityContext(user_agent="app/1.0", ip_address="192.168.1.1")
token = jwt.generate_access_token(user_id="user123", user_name="John Doe", context=ctx)

# 解码 Token
payload = jwt.decode_token(token)

# 算法支持: HS256, RS256
```

### 9.2 认证管理器 (5种策略)
```python
from kewe.security.auth import AuthManager, JWTAuthenticator

# JWT 认证
auth = JWTAuthenticator(secret_key="key")

# 装饰器
@app.get("/protected")
@login_required
async def protected(request):
    return json({"ok": True})
```

支持的认证策略:
- **JWT**: `JWTAuthenticator`
- **Session**: `SessionAuthenticator`
- **API Key**: `APIKeyAuthenticator`
- **OAuth2**: `OAuth2Authenticator`
- **Basic Auth**: `BasicAuth`

### 9.3 角色权限管理 (RBAC)
```python
from kewe import Role, Permission, RBACManager

rbac = RBACManager()
rbac.add_role("editor", {"read", "write"})

# 角色检查
@app.get("/admin")
@roles_required("admin")
async def admin_endpoint(request):
    return json({"admin": True})

# 权限检查
@app.delete("/users/<id>")
@permissions_required("user:delete")
async def delete_user(request, id: int):
    return json({"deleted": id})
```

角色枚举: `Role.ADMIN`, `Role.USER`, `Role.GUEST`, `Role.MODERATOR`
权限枚举: `Permission.READ`, `Permission.WRITE`, `Permission.DELETE`, `Permission.ADMIN`

### 9.4 CSRF 保护
```python
from kewe import CSRFProtection, csrf_protect, get_csrf_token

csrf = CSRFProtection(secret_key="csrf-secret")

@csrf_protect
async def protected_handler(request):
    return json({"ok": True})

token = get_csrf_token(request, secret_key="csrf-secret")
```

### 9.5 限流 (3种算法)
```python
from kewe import RateLimiter, rate_limit, RateLimitMiddleware

# 装饰器
@app.get("/api")
@rate_limit(max_requests=100, window=60)
async def api(request):
    return json({"ok": True})

# 中间件
app.add_middleware(RateLimitMiddleware(limit=1000, period=60))

# 管理器
limiter = RateLimiter(max_requests=100, window=60)

# 后端: MemoryBackend, RedisBackend
```

限流算法: 固定窗口 / 滑动窗口 / 令牌桶

### 9.6 密码工具
```python
from kewe import hash_password, verify_password

hashed = hash_password("my-password")
is_valid = verify_password("my-password", hashed)
```

### 9.7 Token 类型常量
```python
TokenType.ACCESS    # "access"
TokenType.REFRESH   # "refresh"

TokenStatus.ACTIVE   # "active"
TokenStatus.EXPIRED  # "expired"
TokenStatus.REVOKED  # "revoked"

JWTAlgorithm.HS256   # "HS256"
JWTAlgorithm.RS256   # "RS256"
```

### 9.8 Token 存储
```python
from kewe.security.token_store import TokenStore

store = TokenStore()
store.set_user_revocation_timestamp("user_id")
is_revoked = store.is_user_token_revoked("user_id", token_iat)
store.cleanup_expired_blacklist()
```

## 十、API 网关

### 10.1 启用网关
```python
from kewe.gateway.core import APIGateway, GatewayRoute

gw = APIGateway()
gw.bind_app(app, prefix="/api")

route = GatewayRoute(
    path="/users",
    method="GET",
    handler=get_users_handler,
    version="v1",
    require_auth=True,
    rate_limit=(100, 60),
)
gw.register_route(route)
```

### 10.2 标准化响应格式
```json
{
    "request_id": "uuid-v4",
    "success": true,
    "code": 0,
    "message": "OK",
    "data": {...},
    "timestamp": "2026-05-10T12:00:00Z",
    "metadata": {...}
}
```

### 10.3 网关错误码体系
```python
from kewe.gateway.core import ErrorCode

ErrorCode.SUCCESS            # (0, "成功")
ErrorCode.UNAUTHORIZED       # (1002, "未授权")
ErrorCode.FORBIDDEN          # (1003, "禁止访问")
ErrorCode.NOT_FOUND          # (1004, "资源不存在")
ErrorCode.RATE_LIMITED       # (1006, "请求过于频繁")
ErrorCode.SERVER_ERROR       # (1007, "服务器内部错误")
ErrorCode.VALIDATION_ERROR   # (1010, "数据验证失败")
```

### 10.4 Trie 路由匹配
```python
from kewe.gateway.core import TrieRouter

router = TrieRouter()
router.add_route(route)
matched_route, path_params = router.match("/users/42", "GET", "v1")
# >100K route matches/second
```

### 10.5 enable_gateway 应用集成
```python
app = Kewe(name="gateway_app", enable_gateway=True)
gateway = app.gateway
```

## 十一、熔断器

### 11.1 基本使用
```python
from kewe import CircuitBreaker, CircuitBreakerConfig

config = CircuitBreakerConfig(
    failure_threshold=5,      # 连续失败5次触发熔断
    recovery_timeout=30.0,    # 30秒后尝试恢复
    success_threshold=2,      # 2次成功即关闭熔断
    half_open_max_calls=3,    # 半开状态最多3个并发调用
    window_size=60.0,         # 统计窗口60秒
)

cb = CircuitBreaker("user_service", config=config)

# 异步调用
result = await cb.call(async_remote_function, arg1, arg2)

# 同步调用
result = cb.call_sync(sync_function, arg1, arg2)
```

### 11.2 状态机
```
CLOSED ──(连续失败≥threshold)──→ OPEN
OPEN   ──(超时recovery_timeout)─→ HALF_OPEN
HALF_OPEN ──(成功≥success_threshold)─→ CLOSED
HALF_OPEN ──(失败)─→ OPEN
```

### 11.3 熔断器注册表
```python
from kewe.errors.circuit_breaker import CircuitBreakerRegistry

registry = CircuitBreakerRegistry()
cb1 = registry.get_or_create("payment_service")
cb2 = registry.get_or_create("inventory_service")

# 获取所有状态
status = registry.get_all_status()
# {"payment_service": {"state": "closed", "failures": 0, ...}, ...}
```

### 11.4 回调通知
```python
cb.on_open(lambda name: logger.warning(f"{name} circuit opened!"))
cb.on_close(lambda name: logger.info(f"{name} circuit recovered"))
cb.on_half_open(lambda name: logger.info(f"{name} testing recovery"))
```

## 十二、WebSocket

### 12.1 WebSocket 路由
```python
@app.websocket("/ws")
async def websocket_handler(websocket):
    await websocket.accept()
    while True:
        data = await websocket.receive()
        await websocket.send(f"Echo: {data}")
```

### 12.2 WebSocket 管理器
```python
from kewe import WebSocketManager, broadcast, broadcast_to_group

manager = WebSocketManager()

@manager.on_connect
async def on_connect(ws):
    await broadcast(f"User joined")

@manager.on_message
async def on_message(ws, data):
    await broadcast_to_group("room1", data)

# 全局广播函数
await broadcast("server message to all connections")
await broadcast_to_group("room1", "group message")
count = get_connection_count()
```

### 12.3 异常层次
```python
from kewe.websocket.exceptions import (
    WebSocketException,      # 基类
    WebSocketClosed,         # 连接关闭
    WebSocketProtocolError,  # 协议错误
    WebSocketHandshakeError  # 握手失败
)
```

### 12.4 测试工具
```python
from kewe.websocket.testing import WebSocketState, WebSocketMessage

msg = WebSocketMessage(type="text", data="hello")
```

## 十三、缓存系统

### 13.1 CacheManager
```python
from kewe import CacheManager

cache = CacheManager()

# 基本操作
cache.set("key", "value", ttl=300)   # 5分钟过期
value = cache.get("key")             # 获取值
cache.delete("key")                   # 删除
cache.clear()                         # 清空
cache.exists("key")                   # 是否存在
```

### 13.2 缓存装饰器
```python
from kewe import cache, cache_response, memoize

@cache(ttl=60)
async def expensive_query(user_id):
    return await db.users.find(user_id)

@cache_response(ttl=30)
async def cached_handler(request):
    return json(await expensive_operation())

@memoize(ttl=120)
def fibonacci(n):
    if n < 2: return n
    return fibonacci(n-1) + fibonacci(n-2)
```

### 13.3 Redis 缓存
```python
app.setup_cache(backend="redis", redis_url="redis://localhost:6379/0")
```

### 13.4 LRU 缓存
```python
from kewe import LRUCache

lru = LRUCache(maxsize=1000)
lru.set("hot_key", "hot_value")
```

### 13.5 缓存性能
- CacheManager set+get: **<0.002ms**
- 100% 命中率验证: 全部命中

## 十四、后台任务

### 14.1 TaskManager
```python
from kewe import TaskManager, task, schedule, background_task

tasks = TaskManager()

# 调度定时任务
task = tasks.schedule(lambda: cleanup(), interval=3600)
tasks.cancel(task)
tasks.cancel_all()
```

### 14.2 装饰器
```python
@app.task(name="cleanup", interval=3600)
async def periodic_cleanup():
    await cleanup_expired_data()

@app.background
async def send_welcome_email(user_id: int):
    await email_service.send(user_id)
```

### 14.3 AsyncTaskProcessor
```python
from kewe.background.async_task_processor import AsyncTaskProcessor

processor = AsyncTaskProcessor(max_concurrent=10)
await processor.submit(my_task)
```

### 14.4 TokenAutoRotator
```python
from kewe.background.token_auto_rotator import TokenAutoRotator

rotator = TokenAutoRotator(secret_key="key", rotation_interval=3600)
rotator.start()
```

## 十五、OpenAPI 3.1.0

### 15.1 自动 Schema 生成
```python
from kewe.plugins.openapi import OpenAPIPlugin

plugin = OpenAPIPlugin()
plugin.setup(app, title="My API", version="1.0.0",
             description="API description",
             servers=[{"url": "https://api.example.com/v1"}],
             contact={"name": "Support", "email": "support@example.com"},
             license={"name": "MIT"})
```

### 15.2 Swagger UI / ReDoc
```python
# 自动路由:
# GET /openapi.json  — OpenAPI JSON Schema
# GET /openapi.yaml  — OpenAPI YAML Schema
# GET /docs          — Swagger UI
# GET /redoc         — ReDoc

# 自定义 URL
plugin.setup(app, title="API", swagger_ui_url="/api-docs", redoc_url="/api-redoc")
```

### 15.3 OpenAPI 装饰器
```python
from kewe.plugins.openapi import openapi as oapi

@app.get("/users/<id:int>")
@oapi.summary("Get user by ID")
@oapi.description("Returns a single user object")
@oapi.parameter("id", "path", {"type": "integer"}, required=True)
@oapi.response(200, {"application/json": UserSchema})
@oapi.tag("Users")
@oapi.security("BearerAuth")
@oapi.deprecated(True)
async def get_user(request, id: int):
    return json({})
```

### 15.4 手动添加 Schema
```python
plugin.add_schema("User", {"type": "object", "properties": {...}})
plugin.add_security_scheme("BearerAuth", "http", scheme="bearer")
plugin.add_path("/custom", "get", {"summary": "...", "responses": {...}})
plugin.add_tag({"name": "Users", "description": "User operations"})
plugin.add_server({"url": "https://staging.example.com"})
```

## 十六、监控与可观测性

### 16.1 健康检查
```python
from kewe.monitoring.health import HealthChecker, HealthEndpoint, HealthStatus

checker = HealthChecker()
checker.add_check("database", lambda: db.ping())
checker.add_check("redis", lambda: redis.ping())

endpoint = HealthEndpoint(app=app, path="/health")

status = checker.check()  # {"database": "healthy", "redis": "healthy"}
```

### 16.2 指标管理
```python
from kewe.monitoring.metrics import MetricsManager, setup_metrics

metrics = MetricsManager()
metrics.increment("requests_total")
metrics.gauge("active_connections", 42)
metrics.histogram("response_time_ms", 15.3)

setup_metrics(app, path="/metrics")
```

### 16.3 异常检测
```python
from kewe.monitoring.anomaly_detector import AnomalyDetector, SecurityEvent

detector = AnomalyDetector()
detector.analyze(SecurityEvent(event_type="failed_login", details={"user": "admin"}))
```

### 16.4 审计日志
```python
from kewe.monitoring.audit_log_persistence import AuditLogManager, AuditLogEntry

audit = AuditLogManager()
entry = AuditLogEntry(
    timestamp=int(time.time()),
    event_type="login",
    user_id="user123",
    ip_address="192.168.1.1"
)
audit.log(entry)
audit.get_logs(user_id="user123", limit=100)
audit.cleanup_old_logs(retention_days=30)
```

### 16.5 链路追踪
```python
from kewe.telemetry.tracing import Tracer, TraceContext, TracingMiddleware

tracer = Tracer(service_name="my-service")

@app.get("/traced")
@trace_function
async def traced_handler(request):
    with trace_span("db_query"):
        result = await db.query()
    return json(result)

app.add_middleware(TracingMiddleware)
```

### 16.6 OpenTelemetry 集成
```python
from kewe.telemetry.otel import setup_opentelemetry, OpenTelemetryConfig

config = OpenTelemetryConfig(service_name="my-service")
setup_opentelemetry(app, config)
```

## 十七、HTTP/2 + HTTP/3

### 17.1 HTTP/2 支持
```python
from kewe.http.http2 import (
    create_http2_server, HTTP2Protocol, HTTP2ConnectionPool,
    HTTP2Settings, is_http2_available
)

if is_http2_available():
    server = await create_http2_server(app, host="0.0.0.0", port=443,
                                        certfile="cert.pem", keyfile="key.pem")

# 连接池
pool = HTTP2ConnectionPool(max_connections=100, idle_timeout=30.0)
```

功能: ALPN 协商 (h2/http1.1), Server Push, 流优先级, PING/PONG, GOAWAY 优雅关闭

### 17.2 HTTP/3 支持 (QUIC)
```python
from kewe.http.http3 import (
    create_http3_server, HTTP3Protocol, HTTP3Server,
    WebTransportSession, is_http3_available
)

if is_http3_available():
    server = HTTP3Server(app, host="0.0.0.0", port=443,
                         certfile="cert.pem", keyfile="key.pem")
    await server.start()
```

功能: QUIC 传输, 0-RTT, WebTransport, 流控

## 十八、性能特性

### 18.1 RequestPool 请求对象池
```python
from kewe.request.request import RequestPool

pool = RequestPool(max_size=5000)

# 获取请求对象
req = pool.acquire(method="GET", path="/api/test",
                   headers={"content-type": "application/json"})

# 归还
pool.release(req)

# 统计信息
stats = pool.stats
# {"pool_size": 100, "max_size": 5000, "created": 1000,
#  "reused": 9900, "hits": 9900, "misses": 1000, "hit_rate": 0.91}

pool.clear()  # 清空池
```

**性能**: <0.01ms/req, 减少 GC 压力

### 18.2 ConnectionPool 连接池
```python
from kewe.touchup.performance import ConnectionPool, ConnectionPoolConfig

config = ConnectionPoolConfig(
    max_size=20,      # 最大连接数
    min_size=0,       # 最小连接数
    max_overflow=10,  # 超出最大后的溢出数
    max_idle=5,       # 最大空闲连接
    timeout=30.0,     # 获取超时
    ttl=300.0,        # 连接生存时间
    recycle=3600.0,   # 回收时间
    stale=300.0,      # 过期时间
)

pool = ConnectionPool(factory=create_db_connection, config=config)

# 获取连接
conn = await pool.acquire()
try:
    await conn.execute("SELECT * FROM users")
finally:
    await pool.release(conn)

# 上下文管理器
async with pool:
    conn = await pool.acquire()
```

**性能**: <0.5ms acquire+release, 竞态安全

### 18.3 零拷贝传输
```python
from kewe.touchup.zerocopy import (
    SendfileTransport, MmapFileReader, ZeroCopyBuffer, FileCache
)

# sendfile 零拷贝 (Linux)
transport = SendfileTransport()
await transport.sendfile(writer, "/path/to/large_file.mp4")

# mmap 内存映射
reader = MmapFileReader(file_path="/data/huge_file.bin")
data = reader.read(offset=0, size=4096)

# 零拷贝缓冲区
buf = ZeroCopyBuffer(initial_size=65536)
buf.write(data)

# 文件缓存
cache = FileCache(max_size_mb=100)
cache.put("key", file_path)
```

### 18.4 KeepAlive 全局连接管理
```python
from kewe.http.keepalive import KeepAliveManager, KeepAliveConfig

config = KeepAliveConfig(enabled=True, timeout=5.0, max_requests=100)
mgr = KeepAliveManager(config)
mgr.start()  # 后台清理循环
# 已集成到 KeweServer
```

### 18.5 一键性能优化
```python
from kewe.touchup.performance import setup_performance_optimizations

# 自动应用: orjson → uvloop/winloop → httptools
optimizations = setup_performance_optimizations()
# ["orjson", "uvloop", "httptools"]
```

### 18.6 服务器实时监控
```python
from kewe.server.http_server import KeweServer

server = KeweServer(app=app, host="0.0.0.0", port=8000)

stats = server.stats
# {
#     "running": True,
#     "shutting_down": False,
#     "uptime_seconds": 3600.0,
#     "active_connections": 42,
#     "total_requests": 150000,
#     "total_bytes_received": 50000000,
#     "total_bytes_sent": 250000000,
#     "max_connections": 10000,
#     "keepalive_timeout": 5.0,
#     "streaming_tasks": 3,
#     "host": "0.0.0.0",
#     "port": 8000
# }
```

## 十九、异常处理

### 19.1 标准 HTTP 异常 (40+ 类)
```python
from kewe import (
    BadRequest,              # 400
    Unauthorized,            # 401
    PaymentRequired,         # 402
    Forbidden,               # 403
    NotFound,                # 404
    MethodNotAllowed,        # 405
    NotAcceptable,           # 406
    ProxyAuthenticationRequired, # 407
    RequestTimeout,          # 408
    Conflict,                # 409
    Gone,                    # 410
    LengthRequired,          # 411
    PreconditionFailed,      # 412
    PayloadTooLarge,         # 413
    UriTooLong,              # 414
    UnsupportedMediaType,    # 415
    RangeNotSatisfiable,     # 416
    ExpectationFailed,       # 417
    ImATeapot,               # 418
    MisdirectedRequest,      # 421
    UnprocessableEntity,     # 422
    Locked,                  # 423
    FailedDependency,        # 424
    TooEarly,                # 425
    UpgradeRequired,         # 426
    PreconditionRequired,    # 428
    TooManyRequests,         # 429
    RequestHeaderFieldsTooLarge, # 431
    UnavailableForLegalReasons,  # 451
    InternalServerError,     # 500
    NotImplemented,          # 501
    BadGateway,              # 502
    ServiceUnavailable,      # 503
    GatewayTimeout,          # 504
    HttpVersionNotSupported, # 505
    VariantAlsoNegotiates,   # 506
    InsufficientStorage,     # 507
    LoopDetected,            # 508
    NotExtended,             # 510
    NetworkAuthenticationRequired, # 511
)
```

### 19.2 abort 函数
```python
from kewe.errors.exceptions import abort

abort(404)
abort(404, "Resource not found")
abort(403, "Access denied", headers={"X-Reason": "insufficient_permissions"})
abort(Response(body="Custom", status=400))
```

### 19.3 自定义错误处理器
```python
@app.exception(400)
async def bad_request_handler(request, exception):
    return json({
        "error": "bad_request",
        "detail": str(exception),
    }, status=400)

@app.exception(502)
async def bad_gateway_handler(request, exception):
    return json({"error": "upstream_failure"}, status=502)

app.register_error_handler(500, custom_500_handler)
```

### 19.4 RFC 7807 问题详情
```python
exc = NotFound(detail="User 123 not found")
details = exc.to_problem_details("/users/123")
# {
#     "type": "https://kewe.dev/errors/NOT_FOUND",
#     "title": "Not Found",
#     "status": 404,
#     "detail": "User 123 not found",
#     "instance": "/users/123",
#     "timestamp": "2026-05-10T12:00:00Z"
# }
```

## 二十、配置管理

### 20.1 KeweConfig
```python
config = KeweConfig(
    secret_key="secret-key",         # JWT/CSRF/Session 密钥
    debug=True,                       # 调试模式
    host="0.0.0.0",                  # 绑定地址
    port=8000,                        # 绑定端口
    access_log=True,                  # 访问日志
    log_level="DEBUG",                # 日志级别
    keep_alive=True,                  # Keep-Alive
    keep_alive_timeout=60,            # Keep-Alive 超时
    request_max_size=10_000_000,      # 最大请求体 (10MB)
    response_timeout=30,              # 响应超时
    graceful_shutdown_timeout=10,     # 优雅关闭超时
    enable_security_headers=True,     # 安全头
    enable_gateway=False,             # API 网关
    enable_openapi=True,              # OpenAPI
    auto_request_id=True,             # 自动请求ID
)
```

### 20.2 Config 基础配置
```python
from kewe.application.config import Config, load_config

config = Config(debug=True, port=9000)
loaded = load_config("config.json")
```

## 二十一、测试工具

### 21.1 TestClient
```python
from kewe import TestClient

client = TestClient(app)

# HTTP 方法
resp = client.get("/hello")
resp = client.post("/users", json={"name": "Alice"})
resp = client.put("/users/1", json={"name": "Bob"})
resp = client.delete("/users/1")
resp = client.patch("/users/1", json={"name": "Charlie"})

# 断言
assert resp.status == 200
data = resp.json
headers = resp.headers
```

### 21.2 AsyncTestClient
```python
from kewe import AsyncTestClient

async with AsyncTestClient(app) as client:
    response = await client.get("/hello")
    assert response.status == 200
```

### 21.3 RequestPool 测试
```python
pool = RequestPool(max_size=100)
req = pool.acquire(method="POST", path="/api/data")
assert req.method == "POST"
pool.release(req)
```

## 二十二、上下文系统

### 22.1 RequestContext
```python
from kewe import RequestContext

ctx = RequestContext()
ctx.set("user", current_user)
ctx.set("request_id", request_id)

user = ctx.get("user")
request_id = ctx.get("request_id", "unknown")
```

### 22.2 AppContext
```python
from kewe import AppContext

ctx = AppContext()
ctx.set("db_pool", pool)
ctx.set("config", app_config)
```

### 22.3 全局代理 g
```python
from kewe import g

g.user = current_user
g.db = database_connection
```

### 22.4 上下文函数
```python
from kewe import get_request, get_app, has_request_context, has_app_context

request = get_request()
app = get_app()
if has_request_context():
    ...
```

## 二十三、信号系统

### 23.1 定义信号
```python
@app.signal("user.created")
async def on_user_created(data):
    await send_welcome_email(data["email"])
```

### 23.2 分发信号
```python
await app.dispatch("user.created", {"email": user.email, "user_id": user.id})
```

### 23.3 SignalBus
```python
from kewe import SignalBus

bus = SignalBus()
bus.on("order.paid", handle_payment)
bus.trigger("order.paid", {"order_id": 123})
```

## 二十四、生命周期

```python
@app.before_server_start
async def on_startup(app_instance):
    await initialize_database()

@app.after_server_start
async def after_start(app_instance):
    logger.info("Server is ready")

@app.before_server_stop
async def before_stop(app_instance):
    await close_connections()

@app.after_server_stop
async def after_stop(app_instance):
    logger.info("Server stopped")
```

## 二十五、应用挂载

```python
main_app = Kewe("main")
admin_app = Kewe("admin")

main_app.mount("/admin", admin_app)
# /admin/* 请求由 admin_app 处理
```

## 二十六、ASGI 适配

```python
from kewe import ASGIAdapter, create_asgi_app

adapter = ASGIAdapter(app)
asgi_app = create_asgi_app(app)

# 使用 uvicorn / hypercorn 运行
# uvicorn app:asgi_app --host 0.0.0.0 --port 8000
```

## 二十七、命令行工具 (CLI)

### 27.1 启动服务器
```bash
kewe run app:app --host 0.0.0.0 --port 8000 --workers 4 --debug
```

### 27.2 REPL 上下文
```python
from kewe.cli.repl import REPLContext, create_repl_context

ctx = REPLContext()
ctx = create_repl_context(app)
```

## 二十八、多进程 Worker

### 28.1 WorkerManager
```python
from kewe.worker.custom import WorkerManager, WorkerState

# SO_REUSEPORT 模式（优先）或 socket 传递模式（回退）
mgr = WorkerManager(num_workers=4)
mgr.start()
```

### 28.2 配置
```python
from kewe.worker.manager import WorkerConfig

config = WorkerConfig(workers=4, host="0.0.0.0", port=8000)
```

## 二十九、日志系统

```python
from kewe.logging.logger import get_logger, setup_logging, debug, info, warning, error, critical

logger = get_logger("my_module")
logger.info("Application started")

# 快捷函数
debug("Debug message")
info("Info message")
warning("Warning message")
error("Error message")
critical("Critical message")

# 全局配置
setup_logging(level="DEBUG", format="json")
```

## 三十、国际化 i18n

```python
from kewe.utils.i18n import I18n, I18nConfig, setup_i18n

config = I18nConfig(default_locale="zh-CN", locales_dir="./locales")
i18n = setup_i18n(app, config)
translated = i18n.translate("hello")
```

## 三十一、HTTP 客户端

```python
from kewe.http.client import AsyncHTTPClient, HttpClientConfig, RetryConfig

config = HttpClientConfig(base_url="https://api.example.com", timeout=10.0)
retry = RetryConfig(max_retries=3, backoff_factor=0.5)

client = AsyncHTTPClient(config=config, retry=retry)
response = await client.get("/data")
```

## 三十二、Range 请求

```python
from kewe.http.range_request import (
    RangeHeaderParser, RangeResponseBuilder, handle_range_request
)

parser = RangeHeaderParser()
ranges = parser.parse("bytes=0-1023")  # 单范围
ranges = parser.parse("bytes=0-499,500-999")  # 多范围

builder = RangeResponseBuilder(data=file_data, content_type="video/mp4")
status, body, headers = builder.build(ranges)
# 206 Partial Content / 416 Range Not Satisfiable
```

## 三十三、类型常量

```python
from kewe.base.constants import HTTP, Server, WebSocket, MIME, Status

HTTP.METHODS            # ["GET","POST","PUT","DELETE","PATCH","HEAD","OPTIONS"]
MIME.APPLICATION_JSON   # "application/json"
MIME.TEXT_HTML          # "text/html"
Status.OK               # 200
Status.CREATED          # 201
Status.BAD_REQUEST      # 400
Status.NOT_FOUND        # 404
Status.INTERNAL_SERVER_ERROR  # 500
Server.DEFAULT_HOST     # "127.0.0.1"
Server.DEFAULT_PORT     # 8000
WebSocket.CLOSE_NORMAL  # 1000
```

## 三十四、生产部署

### 34.1 推荐配置
```python
from kewe import Kewe, KeweConfig
from kewe.request.request import RequestPool
import os

config = KeweConfig(
    secret_key=os.environ.get("SECRET_KEY", ""),
    debug=False,
    host="0.0.0.0",
    port=8000,
    keep_alive=True,
    keep_alive_timeout=60,
    request_max_size=10_000_000,
    graceful_shutdown_timeout=15,
    enable_security_headers=True,
    auto_request_id=True,
    access_log=False,
)

app = Kewe(name="production", config=config)
app.request_pool = RequestPool(max_size=5000)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000, workers=os.cpu_count())
```

### 34.2 Docker
```dockerfile
FROM python:3.12-slim
RUN pip install kewe
COPY . /app
WORKDIR /app
EXPOSE 8000
CMD ["kewe", "run", "app:app", "--host", "0.0.0.0", "--port", "8000", "--workers", "4"]
```

### 34.3 ASGI 服务器
```bash
uvicorn app:asgi_app --host 0.0.0.0 --port 8000 --workers 4
hypercorn app:asgi_app --bind 0.0.0.0:8000 --workers 4
```

### 34.4 systemd 服务
```ini
[Unit]
Description=KeWe Application
After=network.target

[Service]
Type=simple
User=app
WorkingDirectory=/opt/myapp
ExecStart=/opt/myapp/.venv/bin/python -m kewe run app:app --host 0.0.0.0 --port 8000 --workers 4
Restart=always

[Install]
WantedBy=multi-user.target
```

## 三十五、性能基准数据 (v1.0.0)

### JSON 序列化 RPS
| 操作 | 吞吐量 | 加速比 |
|------|--------|--------|
| orjson dumps | ~800K ops/s | 4x stdlib |
| orjson dumpsb (bytes) | ~1M ops/s | 5x stdlib |
| orjson loads | ~600K ops/s | 4x stdlib |

### 路由 RPS
| 操作 | 延迟 | 吞吐量 |
|------|------|--------|
| 静态路由匹配 | <0.5ms | ~2,000 req/s |
| 路径参数路由 | <0.5ms | ~2,000 req/s |
| url_for 反向生成 (LRU) | <0.05ms | ~50,000 ops/s |
| 100条路由匹配 | <1ms | ~1,500 req/s |

### DI 延迟
| 操作 | 延迟 | 吞吐量 |
|------|------|--------|
| Depends 简单依赖 | <1ms | ~1,200 req/s |
| 3层嵌套 Depends | <1.5ms | ~800 req/s |
| Query 参数提取 | <0.8ms | ~1,500 req/s |

### 中间件链延迟
| 层数 | 延迟 | 吞吐量 |
|------|------|--------|
| 1层 Onion | <0.6ms | ~1,800 req/s |
| 5层 Onion | <1.5ms | ~900 req/s |
| 10层 Onion | <2.5ms | ~500 req/s |

### 缓存/连接池
| 操作 | 延迟 |
|------|------|
| CacheManager set+get | <0.002ms |
| ConnectionPool acquire+release | <0.5ms |

### 网关
| 操作 | 吞吐量 |
|------|--------|
| TrieRouter 100路由匹配 | >100,000 ops/s |

### 启动
| 操作 | 延迟 |
|------|------|
| 应用创建 | <0.5ms/app |
| RequestPool 分配 | <0.01ms/req |

---

*KeWe v1.0.0 — 994测试全通过 | 98/100落地评分 | 生产级就绪*
