# SPDX-FileCopyrightText: Christian Heinze
#
# SPDX-License-Identifier: MIT
"""Functionality for IO."""

from __future__ import annotations

import contextlib
import os
import shutil
from pathlib import Path

import msgspec

from lid import __name__ as pkg_name
from lid import types

TYPE_CHECKING = False
if TYPE_CHECKING:
    from collections.abc import Sequence
    from typing import Literal, overload

    @overload
    def _find_binary(binary: str, /) -> str: ...
    @overload
    def _find_binary(binary: str, /, accept_failure: Literal[True]) -> str | None: ...


__all__ = ["capture_environment"]


def _getenv[T](env_var: str, /, default: T) -> T:
    if (v := os.getenv(env_var)) is None:
        return default
    return type(default)(v)


def _find_binary(binary: str, /, accept_failure: bool = False) -> str | None:
    if (abs_path := shutil.which(binary)) is None:
        if accept_failure:
            return None
        raise FileNotFoundError(f"executable '{binary}' not found")
    return abs_path


def capture_environment() -> types.Environment:
    """Capture environment."""
    user_id = os.getuid()
    sys_runtime_dir = Path("/", "run", "user", str(user_id))
    runtime_dir = _getenv("XDG_RUNTIME_DIR", sys_runtime_dir) / pkg_name

    try:
        gio_bin = _find_binary(_getenv("LID_GIO", "gio"))
    except FileNotFoundError as err:
        raise types.EnvCaptureError("gio binary not found") from err

    try:
        log_level: int | None = int(os.getenv("LID_LOGLEVEL", ""))
    except ValueError:
        log_level = None

    return types.Environment(
        runtime_dir=runtime_dir, gio_bin=gio_bin, log_level=log_level
    )


# Intentionally returning a list to allow execution in a separate thread.
def read_mount_markers(env: types.Environment) -> Sequence[tuple[Path, types.Mount]]:
    decode = msgspec.json.Decoder(type=types.Mount).decode

    markers = []
    for p in env.runtime_dir.iterdir():
        if not p.is_file():
            continue

        with contextlib.suppress(msgspec.DecodeError, msgspec.ValidationError):
            markers.append((p, decode(p.read_bytes())))
    return markers
