# SPDX-FileCopyrightText: Christian Heinze
#
# SPDX-License-Identifier: MIT
"""Functionality for calling subprocesses."""

from __future__ import annotations

import asyncio
import contextvars
import logging
import os

from lid import types

TYPE_CHECKING = False
if TYPE_CHECKING:
    from collections.abc import Callable, Mapping
    from typing import Any

__all__ = ["raise_on_stderr", "run"]

log = logging.getLogger()

RUNNING = contextvars.ContextVar[str]("_RUNNING")


def raise_on_stderr(stderr: bytes, /) -> None:
    if stderr:
        running = RUNNING.get()
        err = stderr.decode("utf-8")
        raise types.SubprocessError(f"{running} generated error message:\n{err}")


async def run(
    bin_: str,
    *args: str,
    handle_stderr: Callable[[bytes], None] = raise_on_stderr,
    env_mods: Mapping[str, str] | None = None,
) -> str:
    """Run command and return stdout content."""
    proc_kwargs: dict[str, Any] = (
        {"env": os.environ | env_mods} if env_mods is not None else {}
    )
    proc = await asyncio.create_subprocess_exec(
        bin_,
        *args,
        stdin=asyncio.subprocess.DEVNULL,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        **proc_kwargs,
    )
    token = RUNNING.set(running := f"`{bin_} {' '.join(args)}`")
    log.debug("Running %s.", running)
    try:
        stdout, stderr = await proc.communicate()
    except asyncio.CancelledError:
        proc.terminate()
        RUNNING.reset(token)
        raise

    if proc.returncode != 0:
        log.error("Running %s failed (error code %s).", running, proc.returncode)
        RUNNING.reset(token)
        raise types.SubprocessError(
            f"{running} exited with return code {proc.returncode}:"
            f" {stderr.decode('utf-8')}"
        )
    try:
        if stderr:
            log.warning("Found STDERR output: `%s`.", stderr)

            handle_stderr(stderr)
        stdout = stdout.decode("utf-8")
    finally:
        RUNNING.reset(token)
    return stdout
