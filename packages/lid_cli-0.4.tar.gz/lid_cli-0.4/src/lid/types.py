# SPDX-FileCopyrightText: Christian Heinze
#
# SPDX-License-Identifier: MIT
"""Shared data structures."""

from __future__ import annotations

from dataclasses import dataclass

import msgspec

TYPE_CHECKING = False
if TYPE_CHECKING:
    from pathlib import Path


class LidError(RuntimeError):
    """Exception raised by lid functionality."""


class SubprocessError(LidError):
    """Raised when a subprocess concludes with an error."""


class EnvCaptureError(LidError):
    """Exception raised when capturing the environment fails."""


class GioError(LidError):
    """Exception raised when interaction with `gio` failes.

    This includes all issues not related to user input, e.g., unsupported formats
    int the `gio` output.
    """


class GioNotFoundError(LidError):
    """Exception raised when no matching volume can be found."""


@dataclass(slots=True)
class Environment:
    """Captures environment parameters."""

    runtime_dir: Path

    log_level: int | None

    gio_bin: str


class Mount(msgspec.Struct, forbid_unknown_fields=True, kw_only=True):
    """Summary of mount attempt/action.

    Parameters
    ----------
    name
        Volume ID as displayed by `gio mount --list`.
    mountpoint
        Mountpoint (local directory logically linked to volume file system).
    triggered
        True if the attempt actually mounted the volume.
    """

    name: str
    mountpoint: str

    triggered: bool
