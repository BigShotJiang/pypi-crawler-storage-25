# `gio`-based volume handling tool `lid`

## (Un)Install

To install, run

```bash
uv tool install lid-cli
```

Then run

```bash
yd --install-completion
```

to install auto-completion in your shell.

In `bash`, the completion code is stored in `~/.bash_completions/lid.sh` and that file is sourced from `~/.bashrc`.
Remove both and call `uv tool uninstall lid-cli` to remove this tool.

## (Un)Mounting

Currently, `lid` allows to (un)mount volumes using `gio`.

To find available volumes, run `lid ls` (add the `--mounted` option to restrict to mounted volumes).

Use `lid mount NAME` to mount a volume wherein name is the name displayed by `lid ls`.

Use `lid umount NAME` to unmount. `lid` will only unmount what it has itself mounted.
This allows to sandwich another action between a `lid mount` and a `lid umount` call to have the volume mounted during the action and retain the initial state afterwards
(if the volume was mounted before calling `lid mount` it is still mounted after `lid umount`).
