"""Tests for the public installable package surface."""

from pathlib import Path
from typing import Any, cast

from langgraph.checkpoint.base import BaseCheckpointSaver
from pytest import MonkeyPatch

from senpai_assistant import Assistant, configure_runtime_root, create_assistant_for_paths, get_runtime_root
from senpai_assistant.assistant import Assistant as InternalAssistant
from senpai_assistant.main import main
from senpai_assistant.main import main as internal_main


def _make_project_and_user_dirs(tmp_path: Path) -> tuple[Path, Path, Path]:
    user_dir = tmp_path / "users" / "u1"
    project_dir = user_dir / "projects" / "pizza_shop"
    connectors_dir = user_dir / "connectors"
    (project_dir / "profiles").mkdir(parents=True)
    (project_dir / "rules").mkdir(parents=True)
    connectors_dir.mkdir(parents=True)
    return project_dir, user_dir, connectors_dir


def test_public_package_reexports_assistant() -> None:
    assert Assistant is InternalAssistant


def test_public_package_reexports_main() -> None:
    assert main is internal_main


def test_public_package_configures_runtime_root(tmp_path: Path) -> None:
    configure_runtime_root(tmp_path)
    assert get_runtime_root() == tmp_path
    configure_runtime_root(None)


def test_create_assistant_for_paths_builds_from_user_dir(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    _project_dir, user_dir, connectors_dir = _make_project_and_user_dirs(tmp_path)

    captured: dict[str, object] = {}
    assistant_sentinel = cast(Assistant, object())

    def fake_get_or_build_index(path: Path, runtime_root: Path | None = None) -> Path:
        assert runtime_root == tmp_path / "runtime"
        return tmp_path / "runtime" / f"{path.name}.pkl"

    def fake_assistant(**kwargs: object) -> Assistant:
        captured.update(kwargs)
        return assistant_sentinel

    monkeypatch.setattr("senpai_assistant.factory.get_or_build_index", fake_get_or_build_index)
    monkeypatch.setattr("senpai_assistant.factory.Assistant", fake_assistant)

    assistant = create_assistant_for_paths(
        user_path=user_dir,
        thread_id="thread-1",
        runtime_root=tmp_path / "runtime",
        checkpointer=cast(BaseCheckpointSaver[Any], object()),
    )

    assert assistant is assistant_sentinel
    assert captured["thread_id"] == "thread-1"
    assert captured["project_path"] == (user_dir / "projects").resolve()
    assert captured["connectors_path"] == connectors_dir.resolve()
    assert captured["embedding_path"] == tmp_path / "runtime" / "projects.pkl"
    assert captured["connectors_embedding_path"] == tmp_path / "runtime" / "connectors.pkl"
    assert captured["runtime_root"] == tmp_path / "runtime"
    assert get_runtime_root() != tmp_path / "runtime"


def test_create_assistant_for_paths_defaults_project_root_to_user_path(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    _project_dir, user_dir, connectors_dir = _make_project_and_user_dirs(tmp_path)

    captured: dict[str, object] = {}
    assistant_sentinel = cast(Assistant, object())

    def fake_get_or_build_index(path: Path, runtime_root: Path | None = None) -> Path:
        assert runtime_root == tmp_path / "runtime"
        return tmp_path / "runtime" / f"{path.name}.pkl"

    def fake_assistant(**kwargs: object) -> Assistant:
        captured.update(kwargs)
        return assistant_sentinel

    monkeypatch.setattr("senpai_assistant.factory.get_or_build_index", fake_get_or_build_index)
    monkeypatch.setattr("senpai_assistant.factory.Assistant", fake_assistant)

    assistant = create_assistant_for_paths(
        user_path=user_dir,
        thread_id="thread-1",
        runtime_root=tmp_path / "runtime",
        checkpointer=cast(BaseCheckpointSaver[Any], object()),
    )

    assert assistant is assistant_sentinel
    assert captured["project_path"] == (user_dir / "projects").resolve()
    assert captured["connectors_path"] == connectors_dir.resolve()
    assert captured["embedding_path"] == tmp_path / "runtime" / "projects.pkl"


def test_create_assistant_for_paths_requires_checkpointer_by_default(tmp_path: Path) -> None:
    _project_dir, user_dir, _ = _make_project_and_user_dirs(tmp_path)

    try:
        create_assistant_for_paths(
            user_path=user_dir,
            runtime_root=tmp_path / "runtime",
        )
    except RuntimeError as exc:
        assert "requires an external checkpointer" in str(exc)
    else:  # pragma: no cover - defensive guard
        raise AssertionError("Expected RuntimeError when checkpointer is missing")


def test_create_assistant_for_paths_allows_explicit_sqlite_fallback(
    tmp_path: Path,
    monkeypatch: MonkeyPatch,
) -> None:
    _project_dir, user_dir, _ = _make_project_and_user_dirs(tmp_path)

    captured: dict[str, object] = {}
    assistant_sentinel = cast(Assistant, object())

    def fake_get_or_build_index(path: Path, runtime_root: Path | None = None) -> Path:
        assert runtime_root == tmp_path / "runtime"
        return tmp_path / "runtime" / f"{path.name}.pkl"

    def fake_assistant(**kwargs: object) -> Assistant:
        captured.update(kwargs)
        return assistant_sentinel

    monkeypatch.setattr("senpai_assistant.factory.get_or_build_index", fake_get_or_build_index)
    monkeypatch.setattr("senpai_assistant.factory.Assistant", fake_assistant)

    assistant = create_assistant_for_paths(
        user_path=user_dir,
        runtime_root=tmp_path / "runtime",
        require_checkpointer=False,
    )

    assert assistant is assistant_sentinel
    assert captured["checkpointer"] is None
    assert captured["runtime_root"] == tmp_path / "runtime"


def test_create_assistant_for_paths_rejects_invalid_user_path(tmp_path: Path) -> None:
    user_dir = tmp_path / "users" / "u1"
    (user_dir / "projects").mkdir(parents=True)

    try:
        create_assistant_for_paths(
            user_path=user_dir,
            runtime_root=tmp_path / "runtime",
            checkpointer=cast(BaseCheckpointSaver[Any], object()),
        )
    except ValueError as exc:
        message = str(exc)
        assert "Invalid SENSEI user path" in message
        assert "connectors" in message
        assert "projects" in message
    else:  # pragma: no cover - defensive guard
        raise AssertionError("Expected invalid user path to be rejected")
