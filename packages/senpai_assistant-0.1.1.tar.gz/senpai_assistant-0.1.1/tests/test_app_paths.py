"""Tests for runtime path resolution helpers."""

from __future__ import annotations

import tempfile
from collections.abc import Iterator
from pathlib import Path

import pytest

from senpai_assistant.utils import app_paths


@pytest.fixture(autouse=True)
def reset_runtime_home_override() -> Iterator[None]:
    """Keep process-wide runtime path overrides isolated between tests."""
    app_paths.set_senpai_home(None)
    yield
    app_paths.set_senpai_home(None)


def test_get_senpai_home_prefers_explicit_runtime_root(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.setenv("SENPAI_HOME", str(tmp_path / "env-home"))
    app_paths.set_senpai_home(tmp_path / "override-home")

    resolved = app_paths.get_senpai_home(runtime_root=tmp_path / "arg-home")

    assert resolved == tmp_path / "arg-home"


def test_get_senpai_home_prefers_process_override_over_env(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    monkeypatch.setenv("SENPAI_HOME", str(tmp_path / "env-home"))
    app_paths.set_senpai_home(tmp_path / "override-home")

    resolved = app_paths.get_senpai_home()

    assert resolved == tmp_path / "override-home"


def test_get_senpai_home_prefers_env_over_default(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.setenv("SENPAI_HOME", str(tmp_path / "env-home"))
    monkeypatch.setattr(app_paths, "_default_senpai_home", lambda: tmp_path / "default-home")

    resolved = app_paths.get_senpai_home()

    assert resolved == tmp_path / "env-home"


def test_get_senpai_home_uses_default_when_no_overrides(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.delenv("SENPAI_HOME", raising=False)
    monkeypatch.setattr(app_paths, "_default_senpai_home", lambda: tmp_path / "default-home")

    resolved = app_paths.get_senpai_home()

    assert resolved == tmp_path / "default-home"


def test_ensure_runtime_subdir_falls_back_to_temp_when_default_root_creation_fails(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    failing_root = tmp_path / "default-home"
    requested_path = failing_root / "data"
    fallback_root = tmp_path / "temp-root"
    original_mkdir = Path.mkdir

    monkeypatch.delenv("SENPAI_HOME", raising=False)
    monkeypatch.setattr(app_paths, "_default_senpai_home", lambda: failing_root)
    monkeypatch.setattr(tempfile, "gettempdir", lambda: str(fallback_root))

    def fake_mkdir(
        self: Path,
        mode: int = 0o777,
        parents: bool = False,
        exist_ok: bool = False,
    ) -> None:
        if self == requested_path:
            raise OSError("boom")
        original_mkdir(self, mode=mode, parents=parents, exist_ok=exist_ok)

    monkeypatch.setattr(Path, "mkdir", fake_mkdir)

    resolved = app_paths.ensure_runtime_subdir("data")

    assert resolved == fallback_root / "senpai-assistant" / "data"
    assert resolved.exists()


def test_ensure_runtime_subdir_raises_when_explicit_runtime_root_creation_fails(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    def fake_mkdir(
        self: Path,
        mode: int = 0o777,
        parents: bool = False,
        exist_ok: bool = False,
    ) -> None:
        raise OSError("boom")

    monkeypatch.setattr(Path, "mkdir", fake_mkdir)

    with pytest.raises(OSError, match="boom"):
        app_paths.ensure_runtime_subdir("data", runtime_root=tmp_path / "explicit-root")


def test_ensure_runtime_subdir_raises_when_process_override_creation_fails(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    app_paths.set_senpai_home(tmp_path / "override-root")

    def fake_mkdir(
        self: Path,
        mode: int = 0o777,
        parents: bool = False,
        exist_ok: bool = False,
    ) -> None:
        raise OSError("boom")

    monkeypatch.setattr(Path, "mkdir", fake_mkdir)

    with pytest.raises(OSError, match="boom"):
        app_paths.ensure_runtime_subdir("data")


def test_ensure_runtime_subdir_raises_when_env_override_creation_fails(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    monkeypatch.setenv("SENPAI_HOME", str(tmp_path / "env-root"))

    def fake_mkdir(
        self: Path,
        mode: int = 0o777,
        parents: bool = False,
        exist_ok: bool = False,
    ) -> None:
        raise OSError("boom")

    monkeypatch.setattr(Path, "mkdir", fake_mkdir)

    with pytest.raises(OSError, match="boom"):
        app_paths.ensure_runtime_subdir("data")
