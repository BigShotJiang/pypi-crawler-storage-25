"""Embedding creation module."""
