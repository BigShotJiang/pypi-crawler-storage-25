"""Helpers for saving, loading, and locating project embedding index files."""

import hashlib
import pickle
from pathlib import Path
from typing import Any, Dict, cast

from senpai_assistant.embeddings.types import FileType
from senpai_assistant.utils.app_paths import ensure_runtime_subdir


def get_index_path(project_dir: str | Path, runtime_root: str | Path | None = None) -> Path:
    """Return the path to the project's main embeddings index file.

    The index is stored under:
        <SENPAI_HOME>/embeddings/<project_name>-<path_hash>/index.pkl

    Args:
        project_dir (str | Path): Root directory of the project.
        runtime_root: Optional writable runtime root used to place embedding artifacts.

    Returns:
        Path: Path to the pickle file that stores the project index.
    """
    if isinstance(project_dir, str):
        project_dir = Path(project_dir)

    resolved_project_dir = project_dir.expanduser().resolve()
    project_name = resolved_project_dir.name
    project_hash = hashlib.sha256(str(resolved_project_dir).encode("utf-8")).hexdigest()[:12]
    embedding_files_dir = (
        ensure_runtime_subdir("embeddings", runtime_root=runtime_root) / f"{project_name}-{project_hash}"
    )
    embedding_files_dir.mkdir(parents=True, exist_ok=True)

    return embedding_files_dir / "index.pkl"


def save_index(
    project_dir: Path,
    embedding_content: Dict[FileType, dict[str, object]],
    runtime_root: str | Path | None = None,
) -> Path:
    """Save the embeddings index to disk.

    Args:
        project_dir (Path): Project root directory.
        embedding_content (Dict[str, Any]): Project content embedded
        runtime_root: Optional writable runtime root used to place embedding artifacts.

    Returns:
        Path: Path to the saved index file.
    """
    index_path = get_index_path(project_dir, runtime_root=runtime_root)

    with index_path.open("wb") as f:
        pickle.dump(embedding_content, f)

    return index_path


def load_index(index_path: Path) -> Dict[str, Any]:
    """Load an existing embeddings index from disk.

    Args:
        index_path (Path): Path to the index file (pickle format).

    Returns:
        Dict[str, Any]

    Raises:
        FileNotFoundError: If the index file does not exist.
    """
    if not index_path.exists():
        raise FileNotFoundError(f"No index found at {index_path}")

    with index_path.open("rb") as f:
        data = pickle.load(f)

    return cast(Dict[str, Any], data)
