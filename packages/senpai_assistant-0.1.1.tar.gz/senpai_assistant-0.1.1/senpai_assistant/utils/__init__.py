"""Utility helpers shared across the Senpai Assistant codebase."""
