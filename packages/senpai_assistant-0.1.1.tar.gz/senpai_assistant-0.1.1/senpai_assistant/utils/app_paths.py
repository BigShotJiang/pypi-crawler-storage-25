"""Helpers for writable Senpai runtime paths."""

from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

_APP_DIR_NAME = "senpai-assistant"
_runtime_home_override: Path | None = None


def _default_senpai_home() -> Path:
    """Return the platform-appropriate writable base directory."""
    home = Path.home()
    if sys.platform == "win32":
        return Path(os.getenv("LOCALAPPDATA", home / "AppData" / "Local")) / _APP_DIR_NAME
    if sys.platform == "darwin":
        return home / "Library" / "Application Support" / _APP_DIR_NAME
    return Path(os.getenv("XDG_STATE_HOME", home / ".local" / "state")) / _APP_DIR_NAME


def get_senpai_home(runtime_root: str | Path | None = None) -> Path:
    """Return the writable Senpai runtime root.

    Resolution order:
    1. Explicit `runtime_root` argument
    2. Process-wide override via `set_senpai_home`
    3. `SENPAI_HOME` environment variable
    4. OS-specific default local state directory
    """
    if runtime_root is not None:
        return Path(runtime_root).expanduser()
    if _runtime_home_override is not None:
        return _runtime_home_override
    override = os.getenv("SENPAI_HOME")
    if override:
        return Path(override).expanduser()
    return _default_senpai_home()


def set_senpai_home(path: str | Path | None) -> None:
    """Set or clear the process-wide runtime root override."""
    global _runtime_home_override
    if path is None:
        _runtime_home_override = None
        return
    _runtime_home_override = Path(path).expanduser()


def ensure_runtime_subdir(name: str, runtime_root: str | Path | None = None) -> Path:
    """Create and return a writable runtime subdirectory."""
    root = get_senpai_home(runtime_root=runtime_root)
    path = root / name
    try:
        path.mkdir(parents=True, exist_ok=True)
        return path
    except OSError:
        if runtime_root is not None or _runtime_home_override is not None or os.getenv("SENPAI_HOME"):
            raise

    fallback_root = Path(tempfile.gettempdir()) / _APP_DIR_NAME
    fallback_path = fallback_root / name
    fallback_path.mkdir(parents=True, exist_ok=True)
    return fallback_path
