"""Public package for Senpai Assistant consumers."""

from senpai_assistant.assistant import Assistant
from senpai_assistant.factory import create_assistant_for_paths
from senpai_assistant.main import main
from senpai_assistant.runtime import configure_runtime_root, get_runtime_root

__all__ = [
    "Assistant",
    "configure_runtime_root",
    "create_assistant_for_paths",
    "get_runtime_root",
    "main",
]
