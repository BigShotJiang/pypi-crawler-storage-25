"""Assistant module for LangChain create_agent-based conversational AI."""

from senpai_assistant.assistant.agent import create_assistant_agent
from senpai_assistant.assistant.assistant import Assistant

__all__ = ["create_assistant_agent", "Assistant"]
