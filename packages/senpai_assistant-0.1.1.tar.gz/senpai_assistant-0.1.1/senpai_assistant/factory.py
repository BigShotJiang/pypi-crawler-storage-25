"""High-level construction helpers for website integrations."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from langchain_core.language_models.chat_models import BaseChatModel
from langgraph.checkpoint.base import BaseCheckpointSaver

from senpai_assistant.assistant import Assistant
from senpai_assistant.embeddings.embedding_build import get_or_build_index
from senpai_assistant.utils.sensei_path_validation import validate_sensei_path


def create_assistant_for_paths(
    *,
    user_path: str | Path,
    thread_id: str | None = None,
    runtime_root: str | Path | None = None,
    model: BaseChatModel | None = None,
    checkpointer: BaseCheckpointSaver[Any] | None = None,
    db_path: str | Path | None = None,
    require_checkpointer: bool = True,
    include_create_tools: bool = True,
    model_kwargs: dict[str, Any] | None = None,
) -> Assistant:
    """Create an assistant from a Django-managed SENSEI user directory.

    Args:
        user_path: Root of the user directory that contains `connectors/` and
            `projects/`. Project files are discovered from `user_path/projects`.
        thread_id: Optional conversation identifier.
        runtime_root: Optional writable runtime root for embeddings/local state for
            this assistant instance. This is passed through explicitly and does not
            mutate process-global runtime configuration.
        model: Optional preconfigured chat model.
        checkpointer: External shared checkpoint store. Required by default for website usage.
        db_path: Optional SQLite path when not using an external checkpointer.
        require_checkpointer: When True, raise if `checkpointer` is missing instead of
            silently falling back to local SQLite.
        include_create_tools: Whether save_* tools should be enabled.
        model_kwargs: Extra keyword arguments forwarded to model initialization.

    Returns:
        Configured `Assistant` instance with project-workspace and connectors
        embeddings ready.
    """
    if require_checkpointer and checkpointer is None:
        raise RuntimeError(
            "create_assistant_for_paths() requires an external checkpointer. "
            "Pass a shared checkpointer for website usage, or set require_checkpointer=False "
            "to explicitly allow local SQLite fallback."
        )

    user_root = validate_sensei_path(user_path, "user").resolve()
    connectors_path = user_root / "connectors"
    project_root = (user_root / "projects").resolve()

    project_embedding_path = get_or_build_index(project_root, runtime_root=runtime_root)
    connectors_embedding_path = get_or_build_index(connectors_path, runtime_root=runtime_root)

    return Assistant(
        model=model,
        checkpointer=checkpointer,
        db_path=db_path,
        thread_id=thread_id,
        embedding_path=project_embedding_path,
        project_path=project_root,
        connectors_path=connectors_path,
        connectors_embedding_path=connectors_embedding_path,
        runtime_root=runtime_root,
        include_create_tools=include_create_tools,
        model_kwargs=model_kwargs,
    )
