"""Runtime configuration helpers for host applications."""

from __future__ import annotations

from pathlib import Path

from senpai_assistant.utils.app_paths import get_senpai_home, set_senpai_home


def configure_runtime_root(path: str | Path | None) -> None:
    """Configure the shared writable runtime root for embeddings and local state."""
    set_senpai_home(path)


def get_runtime_root() -> Path:
    """Return the currently configured writable runtime root."""
    return get_senpai_home()
