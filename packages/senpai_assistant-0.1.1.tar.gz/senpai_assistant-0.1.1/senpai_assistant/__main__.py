"""Module entrypoint for `python -m senpai_assistant`."""

from senpai_assistant.main import main

main()
