"""CLI entrypoints and shared helpers for the Senpai Assistant."""
