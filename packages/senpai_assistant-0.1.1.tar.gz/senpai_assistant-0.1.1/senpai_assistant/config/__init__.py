"""Configuration module for global variables."""
