# Senpai Assistant

Senpai Assistant is a Python package for building and running a SENSEI-focused assistant. It provides a console entry point and a public Python API for host applications that need to create assistants over SENSEI project files, connector files, reference docs, embeddings, and an external conversation checkpointer.

## Installation

```bash
pip install senpai-assistant
```

The package requires Python 3.12 or newer.

## CLI

After installation, run the assistant with:

```bash
senpai-assistant --help
```

You can also run the module directly:

```bash
python -m senpai_assistant --help
```

## Python API

```python
from pathlib import Path

from senpai_assistant import create_assistant_for_paths

assistant = create_assistant_for_paths(
    user_path=Path("/path/to/users/user_1"),
    thread_id="thread-1",
    runtime_root=Path("/var/lib/senpai-assistant"),
    checkpointer=checkpointer,
)
```

`checkpointer` should be a LangGraph checkpointer provided by the host application. For local CLI-style usage without an external checkpointer, pass `require_checkpointer=False` to allow the SQLite fallback.

The public package exports:

- `Assistant`
- `create_assistant_for_paths(...)`
- `configure_runtime_root(...)`
- `get_runtime_root()`
- `main`

`create_assistant_for_paths(...)` expects a SENSEI user directory containing `connectors/` and `projects/`. Projects are discovered from `user_path / "projects"`. In hosted deployments, pass an external LangGraph checkpointer so conversation state is not stored in local SQLite.

## Runtime Files

Senpai Assistant writes generated runtime artifacts under the configured runtime root. The resolution order is:

1. An explicit `runtime_root` argument.
2. The process-wide root set with `configure_runtime_root(...)`.
3. The `SENPAI_HOME` environment variable.
4. The default user data location for the current platform.

Embedding indexes are stored under that runtime root. Local CLI usage can fall back to SQLite, but application integrations should pass their own checkpointer.

## Releases

Releases are published from tags named `vX.Y.Z`. The tag version must match the version in `pyproject.toml`, and `CHANGELOG.md` must contain a matching `## [X.Y.Z]` section.

```bash
uv version 0.1.1
git add pyproject.toml uv.lock CHANGELOG.md
git commit -m "Release 0.1.1"
git tag v0.1.1
git push origin main --tags
```
