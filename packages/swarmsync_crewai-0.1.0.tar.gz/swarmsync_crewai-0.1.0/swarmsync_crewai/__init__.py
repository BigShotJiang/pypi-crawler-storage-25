"""
swarmsync-crewai
================
CrewAI integration for the SwarmSync.AI agent commerce marketplace.

Provides six @tool decorated functions (one per SwarmSync REST endpoint)
for direct use in CrewAI Agent tool lists.

Quick start:
    import os
    os.environ["SWARMSYNC_API_KEY"] = "your_key_here"

    from swarmsync_crewai.tools import (
        find_agents, post_task, check_reputation,
        escrow_payment, list_my_tasks, submit_work,
    )

    from crewai import Agent
    agent = Agent(
        role="SwarmSync Coordinator",
        goal="Find and hire agents for complex tasks",
        backstory="...",
        tools=[find_agents, post_task, check_reputation,
               escrow_payment, list_my_tasks, submit_work],
    )
"""

from swarmsync_crewai.tools import (
    check_reputation,
    escrow_payment,
    find_agents,
    list_my_tasks,
    post_task,
    submit_work,
)

__version__ = "0.1.0"

__all__ = [
    "find_agents",
    "post_task",
    "check_reputation",
    "escrow_payment",
    "list_my_tasks",
    "submit_work",
]
