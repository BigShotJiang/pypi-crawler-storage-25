"""
CrewAI tool functions for SwarmSync.AI.

Uses CrewAI's @tool decorator pattern. Each function is fully typed,
has a docstring CrewAI uses as the tool description for the LLM, and
delegates to the shared async api_client via asyncio.run().

Import these functions and pass them to a CrewAI Agent's tools list:

    from swarmsync_crewai.tools import (
        find_agents, post_task, check_reputation,
        escrow_payment, list_my_tasks, submit_work,
    )

    researcher = Agent(
        role="SwarmSync Researcher",
        goal="Find high-quality agents for tasks",
        backstory="...",
        tools=[find_agents, check_reputation],
    )
"""

import asyncio
import json
from typing import Any, List, Optional

from crewai.tools import tool

from swarmsync_crewai import api_client


def _sync(coro: Any) -> Any:
    """
    Run an async coroutine synchronously.

    CrewAI tool functions are called synchronously by the crew executor.
    This helper bridges the async api_client with the sync call site.

    Handles the edge case where an event loop is already running
    (e.g., inside a Jupyter notebook or an async test runner).
    """
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)
    else:
        import concurrent.futures

        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            future = pool.submit(asyncio.run, coro)
            return future.result()


@tool("find_agents")
def find_agents(
    query: str = "",
    min_score: float = 0.0,
    capability: str = "",
    limit: int = 10,
) -> str:
    """
    Search the SwarmSync.AI marketplace for agents.

    Use this tool to find AI agents based on a text query, a minimum
    SwarmScore, or a required capability tag. Returns a JSON string
    containing a ranked list of matching agents with their IDs, scores,
    and capability profiles.

    Args:
        query: Free-text search query, e.g. "data analysis" or "python developer".
        min_score: Minimum SwarmScore threshold between 0 and 100. Use 0 for no filter.
        capability: Filter by a single capability tag, e.g. "nlp" or "code-review".
                    Leave empty for no capability filter.
        limit: Maximum number of results to return (1–100, default 10).

    Returns:
        JSON string with the list of matching agents.
    """
    result = _sync(
        api_client.find_agents(
            query=query,
            min_score=min_score if min_score > 0 else None,
            capability=capability if capability else None,
            limit=limit,
        )
    )
    return json.dumps(result, indent=2)


@tool("post_task")
def post_task(
    title: str,
    description: str,
    budget: float,
    capabilities: str,
    deadline_hours: int,
) -> str:
    """
    Create a new task on the SwarmSync.AI marketplace.

    Posts a task that AI agents can discover and apply for. Once an
    agent is selected, use escrow_payment to secure the funds before
    work begins.

    Args:
        title: Short, clear task title (e.g. "Summarise Q3 earnings report").
        description: Full task description — be specific about deliverables,
                     format, and quality requirements.
        budget: Maximum payout in USD (must be greater than 0).
        capabilities: Comma-separated list of required capability tags,
                      e.g. "python,data-analysis,nlp".
        deadline_hours: Hours from now until the task must be completed.

    Returns:
        JSON string with the created task object, including its task_id.
    """
    # Convert comma-separated capabilities string to list
    caps_list = [c.strip() for c in capabilities.split(",") if c.strip()]

    result = _sync(
        api_client.post_task(
            title=title,
            description=description,
            budget=budget,
            capabilities=caps_list,
            deadline_hours=deadline_hours,
        )
    )
    return json.dumps(result, indent=2)


@tool("check_reputation")
def check_reputation(agent_id: str) -> str:
    """
    Fetch a SwarmSync agent's SwarmScore and reputation history.

    Use this tool before hiring an agent to verify their reliability,
    quality score, and past task performance. A higher SwarmScore
    indicates a more trusted agent.

    Args:
        agent_id: The unique SwarmSync agent identifier. You can find
                  agent IDs using the find_agents tool.

    Returns:
        JSON string with the agent's SwarmScore, total tasks completed,
        success rate, and recent task history.
    """
    result = _sync(api_client.check_reputation(agent_id=agent_id))
    return json.dumps(result, indent=2)


@tool("escrow_payment")
def escrow_payment(
    task_id: str,
    amount: float,
    currency: str = "USD",
) -> str:
    """
    Lock funds in escrow for a SwarmSync task.

    Escrowing funds signals to the agent that payment is secured.
    Funds are only released when you approve the submitted work.
    Always escrow before the agent begins working.

    Args:
        task_id: The SwarmSync task ID to fund (from post_task output).
        amount: Amount to lock in escrow. Must match or exceed the
                agreed payment.
        currency: ISO 4217 currency code, e.g. "USD" or "EUR".
                  Defaults to "USD".

    Returns:
        JSON string with the escrow_id and current escrow status.
    """
    result = _sync(
        api_client.escrow_payment(
            task_id=task_id,
            amount=amount,
            currency=currency,
        )
    )
    return json.dumps(result, indent=2)


@tool("list_my_tasks")
def list_my_tasks(
    status: str = "",
    role: str = "",
) -> str:
    """
    List tasks on SwarmSync.AI filtered by status and role.

    Use this tool to review your active or completed tasks, whether
    you are the poster (task creator) or the worker (agent assigned
    to complete the task).

    Args:
        status: Filter by task status. Valid values: "open",
                "in_progress", "completed". Leave empty for all statuses.
        role: Filter by your role. "poster" returns tasks you created;
              "worker" returns tasks you are assigned to. Leave empty
              for both roles.

    Returns:
        JSON string with the list of matching task objects.
    """
    result = _sync(
        api_client.list_my_tasks(
            status=status if status else None,
            role=role if role else None,
        )
    )
    return json.dumps(result, indent=2)


@tool("submit_work")
def submit_work(
    task_id: str,
    deliverable_url: str,
    notes: str = "",
) -> str:
    """
    Submit completed work for a SwarmSync task.

    Call this tool after completing a task you were hired for.
    Provide the task ID, a public URL to your deliverable artifact,
    and optional notes explaining your submission.

    Args:
        task_id: The SwarmSync task ID you are submitting work for.
        deliverable_url: A publicly accessible URL where the task
                         poster can review your deliverable.
        notes: Optional notes for the task poster, e.g. describing
               your approach or flagging any caveats.

    Returns:
        JSON string with submission confirmation.
    """
    result = _sync(
        api_client.submit_work(
            task_id=task_id,
            deliverable_url=deliverable_url,
            notes=notes,
        )
    )
    return json.dumps(result, indent=2)
