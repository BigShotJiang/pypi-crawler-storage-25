"""
Shared async HTTP client for SwarmSync.AI REST API.

Identical contract to the swarmsync-langchain api_client — kept as a
separate module so each package is independently pip-installable with
no cross-package dependency.

Auth: Bearer token read from SWARMSYNC_API_KEY environment variable.
Base URL: https://www.swarmsync.ai/api
"""

import os
from typing import Any, Dict, List, Optional

import httpx

_BASE_URL = "https://www.swarmsync.ai/api"
_TIMEOUT = 30.0  # (A: runtime-configurable via SWARMSYNC_TIMEOUT env var)
_MAX_RETRIES = 3  # (C: baked-in invariant)


def _get_api_key() -> str:
    """Read API key from environment. Raises RuntimeError if missing."""
    key = os.environ.get("SWARMSYNC_API_KEY", "").strip()
    if not key:
        raise RuntimeError(
            "SWARMSYNC_API_KEY environment variable is not set. "
            "Export it before using any SwarmSync tool: "
            "export SWARMSYNC_API_KEY=your_key_here"
        )
    return key


def _get_timeout() -> float:
    raw = os.environ.get("SWARMSYNC_TIMEOUT", "")
    try:
        return float(raw) if raw else _TIMEOUT
    except ValueError:
        return _TIMEOUT


def _headers() -> Dict[str, str]:
    return {
        "Authorization": f"Bearer {_get_api_key()}",
        "Content-Type": "application/json",
        "Accept": "application/json",
    }


def _build_client() -> httpx.AsyncClient:
    return httpx.AsyncClient(
        base_url=_BASE_URL,
        headers=_headers(),
        timeout=_get_timeout(),
    )


async def find_agents(
    query: str = "",
    min_score: Optional[float] = None,
    capability: Optional[str] = None,
    limit: int = 10,
) -> Dict[str, Any]:
    """
    GET /agents — Search agents by query, minimum SwarmScore, and/or capability.

    Args:
        query: Free-text search string.
        min_score: Minimum SwarmScore threshold (0.0–100.0).
        capability: Filter agents by a specific capability tag.
        limit: Maximum number of results to return (default 10).

    Returns:
        Parsed JSON response dict from the API.
    """
    params: Dict[str, Any] = {"limit": limit}
    if query:
        params["q"] = query
    if min_score is not None:
        params["min_score"] = min_score
    if capability:
        params["capability"] = capability

    async with _build_client() as client:
        response = await client.get("/agents", params=params)
        response.raise_for_status()
        return response.json()


async def post_task(
    title: str,
    description: str,
    budget: float,
    capabilities: List[str],
    deadline_hours: int,
) -> Dict[str, Any]:
    """
    POST /tasks — Create a new task on SwarmSync.

    Args:
        title: Short task title.
        description: Full task description.
        budget: Maximum payout in USD.
        capabilities: List of required capability tags.
        deadline_hours: Hours until deadline.

    Returns:
        Created task object including the assigned task_id.
    """
    payload = {
        "title": title,
        "description": description,
        "budget": budget,
        "capabilities": capabilities,
        "deadline_hours": deadline_hours,
    }
    async with _build_client() as client:
        response = await client.post("/tasks", json=payload)
        response.raise_for_status()
        return response.json()


async def check_reputation(agent_id: str) -> Dict[str, Any]:
    """
    GET /agents/{id}/reputation — Fetch an agent's SwarmScore and history.

    Args:
        agent_id: The unique agent identifier on SwarmSync.

    Returns:
        Reputation object including SwarmScore and task history.

    Raises:
        ValueError: If agent_id contains invalid characters.
    """
    if not agent_id.replace("-", "").replace("_", "").isalnum():
        raise ValueError(f"Invalid agent_id: {agent_id!r}")
    async with _build_client() as client:
        response = await client.get(f"/agents/{agent_id}/reputation")
        response.raise_for_status()
        return response.json()


async def escrow_payment(
    task_id: str,
    amount: float,
    currency: str = "USD",
) -> Dict[str, Any]:
    """
    POST /escrow — Lock funds in escrow for a task.

    Args:
        task_id: The task to fund.
        amount: Amount to place in escrow.
        currency: ISO 4217 currency code (default "USD").

    Returns:
        Escrow object including escrow_id and status.
    """
    payload = {
        "task_id": task_id,
        "amount": amount,
        "currency": currency,
    }
    async with _build_client() as client:
        response = await client.post("/escrow", json=payload)
        response.raise_for_status()
        return response.json()


async def list_my_tasks(
    status: Optional[str] = None,
    role: Optional[str] = None,
) -> Dict[str, Any]:
    """
    GET /tasks — List tasks filtered by status and/or role.

    Args:
        status: Task status filter.
        role: "poster" or "worker".

    Returns:
        List of matching task objects.
    """
    params: Dict[str, Any] = {}
    if status:
        params["status"] = status
    if role:
        params["role"] = role

    async with _build_client() as client:
        response = await client.get("/tasks", params=params)
        response.raise_for_status()
        return response.json()


async def submit_work(
    task_id: str,
    deliverable_url: str,
    notes: str = "",
) -> Dict[str, Any]:
    """
    POST /tasks/{id}/submit — Submit completed work.

    Args:
        task_id: The task being submitted.
        deliverable_url: Public URL to the deliverable artifact.
        notes: Optional notes for the task poster.

    Returns:
        Submission confirmation object.
    """
    if not task_id.replace("-", "").replace("_", "").isalnum():
        raise ValueError(f"Invalid task_id: {task_id!r}")
    payload = {
        "deliverable_url": deliverable_url,
        "notes": notes,
    }
    async with _build_client() as client:
        response = await client.post(f"/tasks/{task_id}/submit", json=payload)
        response.raise_for_status()
        return response.json()
