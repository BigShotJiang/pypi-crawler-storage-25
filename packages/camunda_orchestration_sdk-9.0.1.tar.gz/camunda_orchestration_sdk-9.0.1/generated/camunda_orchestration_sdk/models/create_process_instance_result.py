from __future__ import annotations
from camunda_orchestration_sdk.semantic_types import (
    BusinessId,
    ProcessDefinitionId,
    ProcessDefinitionKey,
    ProcessInstanceKey,
    TenantId,
)

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define

from ..types import str_any_dict_factory
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.create_process_instance_result_variables import (
        CreateProcessInstanceResultVariables,
    )


T = TypeVar("T", bound="CreateProcessInstanceResult")


@_attrs_define
class CreateProcessInstanceResult:
    """
    Attributes:
        process_definition_id (str): The BPMN process id of the process definition which was used to create the process.
            instance
             Example: my-process-model-1.
        process_definition_version (int): The version of the process definition which was used to create the process
            instance.
             Example: 3.
        tenant_id (str): The tenant id of the created process instance. Example: <default>.
        variables (CreateProcessInstanceResultVariables): All the variables visible in the root scope.
        process_definition_key (str): The key of the process definition which was used to create the process instance.
             Example: 2251799813686749.
        process_instance_key (str): The unique identifier of the created process instance; to be used wherever a request
            needs a process instance key (e.g. CancelProcessInstanceRequest).
             Example: 2251799813690746.
        tags (list[str]): List of tags. Tags need to start with a letter; then alphanumerics, `_`, `-`, `:`, or `.`;
            length ≤ 100. Example: ['high-touch', 'remediation'].
        business_id (None | str): Business id as provided on creation. Example: order-12345.
    """

    process_definition_id: ProcessDefinitionId
    process_definition_version: int
    tenant_id: TenantId
    variables: CreateProcessInstanceResultVariables
    process_definition_key: ProcessDefinitionKey
    process_instance_key: ProcessInstanceKey
    tags: list[str]
    business_id: None | BusinessId
    additional_properties: dict[str, Any] = _attrs_field(
        init=False, factory=str_any_dict_factory
    )

    def to_dict(self) -> dict[str, Any]:
        process_definition_id = self.process_definition_id

        process_definition_version = self.process_definition_version

        tenant_id = self.tenant_id

        variables = self.variables.to_dict()

        process_definition_key = self.process_definition_key

        process_instance_key = self.process_instance_key

        tags = self.tags

        business_id: None | BusinessId
        business_id = self.business_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "processDefinitionId": process_definition_id,
                "processDefinitionVersion": process_definition_version,
                "tenantId": tenant_id,
                "variables": variables,
                "processDefinitionKey": process_definition_key,
                "processInstanceKey": process_instance_key,
                "tags": tags,
                "businessId": business_id,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.create_process_instance_result_variables import (
            CreateProcessInstanceResultVariables,
        )

        d = dict(src_dict)
        process_definition_id = ProcessDefinitionId(d.pop("processDefinitionId"))

        process_definition_version = d.pop("processDefinitionVersion")

        tenant_id = TenantId(d.pop("tenantId"))

        variables = CreateProcessInstanceResultVariables.from_dict(d.pop("variables"))

        process_definition_key = ProcessDefinitionKey(d.pop("processDefinitionKey"))

        process_instance_key = ProcessInstanceKey(d.pop("processInstanceKey"))

        tags = cast(list[str], d.pop("tags"))

        def _parse_business_id(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        _raw_business_id = _parse_business_id(d.pop("businessId"))

        business_id = (
            BusinessId(_raw_business_id)
            if isinstance(_raw_business_id, str)
            else _raw_business_id
        )

        create_process_instance_result = cls(
            process_definition_id=process_definition_id,
            process_definition_version=process_definition_version,
            tenant_id=tenant_id,
            variables=variables,
            process_definition_key=process_definition_key,
            process_instance_key=process_instance_key,
            tags=tags,
            business_id=business_id,
        )

        create_process_instance_result.additional_properties = d
        return create_process_instance_result

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
