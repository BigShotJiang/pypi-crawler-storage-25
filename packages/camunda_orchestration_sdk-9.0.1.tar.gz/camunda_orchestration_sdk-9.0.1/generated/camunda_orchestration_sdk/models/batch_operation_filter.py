from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.batch_operation_filter_actor_type import BatchOperationFilterActorType
from ..models.batch_operation_state_exact_match import BatchOperationStateExactMatch
from ..models.batch_operation_type_exact_match import BatchOperationTypeExactMatch
from ..types import UNSET, Unset, str_any_dict_factory

if TYPE_CHECKING:
    from ..models.advanced_batch_operation_state_filter import (
        AdvancedBatchOperationStateFilter,
    )
    from ..models.advanced_batch_operation_type_filter import (
        AdvancedBatchOperationTypeFilter,
    )
    from ..models.advanced_string_filter import AdvancedStringFilter
    from ..models.basic_string_filter import BasicStringFilter


T = TypeVar("T", bound="BatchOperationFilter")


@_attrs_define
class BatchOperationFilter:
    """Batch operation filter request.

    Attributes:
        batch_operation_key (BasicStringFilter | str | Unset): The key (or operate legacy ID) of the batch operation.
        operation_type (AdvancedBatchOperationTypeFilter | BatchOperationTypeExactMatch | Unset): The type of the batch
            operation.
        state (AdvancedBatchOperationStateFilter | BatchOperationStateExactMatch | Unset): The state of the batch
            operation.
        actor_type (BatchOperationFilterActorType | Unset): The type of the actor who performed the operation.
        actor_id (AdvancedStringFilter | str | Unset): The ID of the actor who performed the operation.
    """

    batch_operation_key: BasicStringFilter | str | Unset = UNSET
    operation_type: (
        AdvancedBatchOperationTypeFilter | BatchOperationTypeExactMatch | Unset
    ) = UNSET
    state: AdvancedBatchOperationStateFilter | BatchOperationStateExactMatch | Unset = (
        UNSET
    )
    actor_type: BatchOperationFilterActorType | Unset = UNSET
    actor_id: AdvancedStringFilter | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(
        init=False, factory=str_any_dict_factory
    )

    def to_dict(self) -> dict[str, Any]:
        from ..models.advanced_string_filter import AdvancedStringFilter
        from ..models.basic_string_filter import BasicStringFilter

        batch_operation_key: dict[str, Any] | str | Unset
        if isinstance(self.batch_operation_key, Unset):
            batch_operation_key = UNSET
        elif isinstance(self.batch_operation_key, BasicStringFilter):
            batch_operation_key = self.batch_operation_key.to_dict()
        else:
            batch_operation_key = self.batch_operation_key

        operation_type: dict[str, Any] | str | Unset
        if isinstance(self.operation_type, Unset):
            operation_type = UNSET
        elif isinstance(self.operation_type, BatchOperationTypeExactMatch):
            operation_type = self.operation_type.value
        else:
            operation_type = self.operation_type.to_dict()

        state: dict[str, Any] | str | Unset
        if isinstance(self.state, Unset):
            state = UNSET
        elif isinstance(self.state, BatchOperationStateExactMatch):
            state = self.state.value
        else:
            state = self.state.to_dict()

        actor_type: str | Unset = UNSET
        if not isinstance(self.actor_type, Unset):
            actor_type = self.actor_type.value

        actor_id: dict[str, Any] | str | Unset
        if isinstance(self.actor_id, Unset):
            actor_id = UNSET
        elif isinstance(self.actor_id, AdvancedStringFilter):
            actor_id = self.actor_id.to_dict()
        else:
            actor_id = self.actor_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if batch_operation_key is not UNSET:
            field_dict["batchOperationKey"] = batch_operation_key
        if operation_type is not UNSET:
            field_dict["operationType"] = operation_type
        if state is not UNSET:
            field_dict["state"] = state
        if actor_type is not UNSET:
            field_dict["actorType"] = actor_type
        if actor_id is not UNSET:
            field_dict["actorId"] = actor_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.advanced_batch_operation_state_filter import (
            AdvancedBatchOperationStateFilter,
        )
        from ..models.advanced_batch_operation_type_filter import (
            AdvancedBatchOperationTypeFilter,
        )
        from ..models.advanced_string_filter import AdvancedStringFilter
        from ..models.basic_string_filter import BasicStringFilter

        d = dict(src_dict)

        def _parse_batch_operation_key(data: object) -> BasicStringFilter | str | Unset:
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()

                data = cast(dict[str, Any], data)
                batch_operation_key_type_1 = BasicStringFilter.from_dict(data)

                return batch_operation_key_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(BasicStringFilter | str | Unset, data)

        batch_operation_key = _parse_batch_operation_key(
            d.pop("batchOperationKey", UNSET)
        )

        def _parse_operation_type(
            data: object,
        ) -> AdvancedBatchOperationTypeFilter | BatchOperationTypeExactMatch | Unset:
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                operation_type_type_0 = BatchOperationTypeExactMatch(data)

                return operation_type_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, dict):
                raise TypeError()

            data = cast(dict[str, Any], data)
            operation_type_type_1 = AdvancedBatchOperationTypeFilter.from_dict(data)

            return operation_type_type_1

        operation_type = _parse_operation_type(d.pop("operationType", UNSET))

        def _parse_state(
            data: object,
        ) -> AdvancedBatchOperationStateFilter | BatchOperationStateExactMatch | Unset:
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                state_type_0 = BatchOperationStateExactMatch(data)

                return state_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, dict):
                raise TypeError()

            data = cast(dict[str, Any], data)
            state_type_1 = AdvancedBatchOperationStateFilter.from_dict(data)

            return state_type_1

        state = _parse_state(d.pop("state", UNSET))

        _actor_type = d.pop("actorType", UNSET)
        actor_type: BatchOperationFilterActorType | Unset
        if isinstance(_actor_type, Unset):
            actor_type = UNSET
        else:
            actor_type = BatchOperationFilterActorType(_actor_type)

        def _parse_actor_id(data: object) -> AdvancedStringFilter | str | Unset:
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()

                data = cast(dict[str, Any], data)
                actor_id_type_1 = AdvancedStringFilter.from_dict(data)

                return actor_id_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(AdvancedStringFilter | str | Unset, data)

        actor_id = _parse_actor_id(d.pop("actorId", UNSET))

        batch_operation_filter = cls(
            batch_operation_key=batch_operation_key,
            operation_type=operation_type,
            state=state,
            actor_type=actor_type,
            actor_id=actor_id,
        )

        batch_operation_filter.additional_properties = d
        return batch_operation_filter

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
