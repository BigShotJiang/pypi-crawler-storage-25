from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.batch_operation_item_state_exact_match import (
    BatchOperationItemStateExactMatch,
)
from ..models.batch_operation_type_exact_match import BatchOperationTypeExactMatch
from ..types import UNSET, Unset, str_any_dict_factory

if TYPE_CHECKING:
    from ..models.advanced_batch_operation_item_state_filter import (
        AdvancedBatchOperationItemStateFilter,
    )
    from ..models.advanced_batch_operation_type_filter import (
        AdvancedBatchOperationTypeFilter,
    )
    from ..models.advanced_process_instance_key_filter import (
        AdvancedProcessInstanceKeyFilter,
    )
    from ..models.basic_string_filter import BasicStringFilter


T = TypeVar("T", bound="BatchOperationItemFilter")


@_attrs_define
class BatchOperationItemFilter:
    """Batch operation item filter request.

    Attributes:
        batch_operation_key (BasicStringFilter | str | Unset): The key (or operate legacy ID) of the batch operation.
        item_key (BasicStringFilter | str | Unset): The key of the item, e.g. a process instance key.
        process_instance_key (AdvancedProcessInstanceKeyFilter | str | Unset): The process instance key of the processed
            item.
        state (AdvancedBatchOperationItemStateFilter | BatchOperationItemStateExactMatch | Unset): The state of the
            batch operation.
        operation_type (AdvancedBatchOperationTypeFilter | BatchOperationTypeExactMatch | Unset): The type of the batch
            operation.
    """

    batch_operation_key: BasicStringFilter | str | Unset = UNSET
    item_key: BasicStringFilter | str | Unset = UNSET
    process_instance_key: AdvancedProcessInstanceKeyFilter | str | Unset = UNSET
    state: (
        AdvancedBatchOperationItemStateFilter
        | BatchOperationItemStateExactMatch
        | Unset
    ) = UNSET
    operation_type: (
        AdvancedBatchOperationTypeFilter | BatchOperationTypeExactMatch | Unset
    ) = UNSET
    additional_properties: dict[str, Any] = _attrs_field(
        init=False, factory=str_any_dict_factory
    )

    def to_dict(self) -> dict[str, Any]:
        from ..models.advanced_process_instance_key_filter import (
            AdvancedProcessInstanceKeyFilter,
        )
        from ..models.basic_string_filter import BasicStringFilter

        batch_operation_key: dict[str, Any] | str | Unset
        if isinstance(self.batch_operation_key, Unset):
            batch_operation_key = UNSET
        elif isinstance(self.batch_operation_key, BasicStringFilter):
            batch_operation_key = self.batch_operation_key.to_dict()
        else:
            batch_operation_key = self.batch_operation_key

        item_key: dict[str, Any] | str | Unset
        if isinstance(self.item_key, Unset):
            item_key = UNSET
        elif isinstance(self.item_key, BasicStringFilter):
            item_key = self.item_key.to_dict()
        else:
            item_key = self.item_key

        process_instance_key: dict[str, Any] | str | Unset
        if isinstance(self.process_instance_key, Unset):
            process_instance_key = UNSET
        elif isinstance(self.process_instance_key, AdvancedProcessInstanceKeyFilter):
            process_instance_key = self.process_instance_key.to_dict()
        else:
            process_instance_key = self.process_instance_key

        state: dict[str, Any] | str | Unset
        if isinstance(self.state, Unset):
            state = UNSET
        elif isinstance(self.state, BatchOperationItemStateExactMatch):
            state = self.state.value
        else:
            state = self.state.to_dict()

        operation_type: dict[str, Any] | str | Unset
        if isinstance(self.operation_type, Unset):
            operation_type = UNSET
        elif isinstance(self.operation_type, BatchOperationTypeExactMatch):
            operation_type = self.operation_type.value
        else:
            operation_type = self.operation_type.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if batch_operation_key is not UNSET:
            field_dict["batchOperationKey"] = batch_operation_key
        if item_key is not UNSET:
            field_dict["itemKey"] = item_key
        if process_instance_key is not UNSET:
            field_dict["processInstanceKey"] = process_instance_key
        if state is not UNSET:
            field_dict["state"] = state
        if operation_type is not UNSET:
            field_dict["operationType"] = operation_type

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.advanced_batch_operation_item_state_filter import (
            AdvancedBatchOperationItemStateFilter,
        )
        from ..models.advanced_batch_operation_type_filter import (
            AdvancedBatchOperationTypeFilter,
        )
        from ..models.advanced_process_instance_key_filter import (
            AdvancedProcessInstanceKeyFilter,
        )
        from ..models.basic_string_filter import BasicStringFilter

        d = dict(src_dict)

        def _parse_batch_operation_key(data: object) -> BasicStringFilter | str | Unset:
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()

                data = cast(dict[str, Any], data)
                batch_operation_key_type_1 = BasicStringFilter.from_dict(data)

                return batch_operation_key_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(BasicStringFilter | str | Unset, data)

        batch_operation_key = _parse_batch_operation_key(
            d.pop("batchOperationKey", UNSET)
        )

        def _parse_item_key(data: object) -> BasicStringFilter | str | Unset:
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()

                data = cast(dict[str, Any], data)
                item_key_type_1 = BasicStringFilter.from_dict(data)

                return item_key_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(BasicStringFilter | str | Unset, data)

        item_key = _parse_item_key(d.pop("itemKey", UNSET))

        def _parse_process_instance_key(
            data: object,
        ) -> AdvancedProcessInstanceKeyFilter | str | Unset:
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()

                data = cast(dict[str, Any], data)
                process_instance_key_type_1 = (
                    AdvancedProcessInstanceKeyFilter.from_dict(data)
                )

                return process_instance_key_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(AdvancedProcessInstanceKeyFilter | str | Unset, data)

        process_instance_key = _parse_process_instance_key(
            d.pop("processInstanceKey", UNSET)
        )

        def _parse_state(
            data: object,
        ) -> (
            AdvancedBatchOperationItemStateFilter
            | BatchOperationItemStateExactMatch
            | Unset
        ):
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                state_type_0 = BatchOperationItemStateExactMatch(data)

                return state_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, dict):
                raise TypeError()

            data = cast(dict[str, Any], data)
            state_type_1 = AdvancedBatchOperationItemStateFilter.from_dict(data)

            return state_type_1

        state = _parse_state(d.pop("state", UNSET))

        def _parse_operation_type(
            data: object,
        ) -> AdvancedBatchOperationTypeFilter | BatchOperationTypeExactMatch | Unset:
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                operation_type_type_0 = BatchOperationTypeExactMatch(data)

                return operation_type_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, dict):
                raise TypeError()

            data = cast(dict[str, Any], data)
            operation_type_type_1 = AdvancedBatchOperationTypeFilter.from_dict(data)

            return operation_type_type_1

        operation_type = _parse_operation_type(d.pop("operationType", UNSET))

        batch_operation_item_filter = cls(
            batch_operation_key=batch_operation_key,
            item_key=item_key,
            process_instance_key=process_instance_key,
            state=state,
            operation_type=operation_type,
        )

        batch_operation_item_filter.additional_properties = d
        return batch_operation_item_filter

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
