from enum import Enum


class AuditLogResultRelatedEntityType(str, Enum):
    AUTHORIZATION = "AUTHORIZATION"
    BATCH = "BATCH"
    CLIENT = "CLIENT"
    DECISION = "DECISION"
    GROUP = "GROUP"
    INCIDENT = "INCIDENT"
    JOB = "JOB"
    MAPPING_RULE = "MAPPING_RULE"
    PROCESS_INSTANCE = "PROCESS_INSTANCE"
    RESOURCE = "RESOURCE"
    ROLE = "ROLE"
    TENANT = "TENANT"
    USER = "USER"
    USER_TASK = "USER_TASK"
    VARIABLE = "VARIABLE"

    def __str__(self) -> str:
        return str(self.value)
