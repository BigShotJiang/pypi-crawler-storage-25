from __future__ import annotations
from camunda_orchestration_sdk.semantic_types import TenantId

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define

from ..types import str_any_dict_factory
from attrs import field as _attrs_field

from ..models.cluster_variable_scope_enum import ClusterVariableScopeEnum

T = TypeVar("T", bound="ClusterVariableResultBase")


@_attrs_define
class ClusterVariableResultBase:
    """Cluster variable response item.

    Attributes:
        name (str): The name of the cluster variable. Unique within its scope (global or tenant-specific).
        scope (ClusterVariableScopeEnum): The scope of a cluster variable.
        tenant_id (None | str): Only provided if the cluster variable scope is TENANT. Null for global scope variables.
    """

    name: str
    scope: ClusterVariableScopeEnum
    tenant_id: None | TenantId
    additional_properties: dict[str, Any] = _attrs_field(
        init=False, factory=str_any_dict_factory
    )

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        scope = self.scope.value

        tenant_id: None | TenantId
        tenant_id = self.tenant_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "scope": scope,
                "tenantId": tenant_id,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        scope = ClusterVariableScopeEnum(d.pop("scope"))

        def _parse_tenant_id(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        _raw_tenant_id = _parse_tenant_id(d.pop("tenantId"))

        tenant_id = (
            TenantId(_raw_tenant_id)
            if isinstance(_raw_tenant_id, str)
            else _raw_tenant_id
        )

        cluster_variable_result_base = cls(
            name=name,
            scope=scope,
            tenant_id=tenant_id,
        )

        cluster_variable_result_base.additional_properties = d
        return cluster_variable_result_base

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
