from http import HTTPStatus
from typing import Any, cast
import httpx
from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.incident_process_instance_statistics_by_definition_query import (
    IncidentProcessInstanceStatisticsByDefinitionQuery,
)
from ...models.incident_process_instance_statistics_by_definition_query_result import (
    IncidentProcessInstanceStatisticsByDefinitionQueryResult,
)
from ...models.problem_detail import ProblemDetail
from ...types import Response


def _get_kwargs(
    *, body: IncidentProcessInstanceStatisticsByDefinitionQuery
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/incidents/statistics/process-instances-by-definition",
    }
    _kwargs["json"] = body.to_dict()
    headers["Content-Type"] = "application/json"
    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> IncidentProcessInstanceStatisticsByDefinitionQueryResult | ProblemDetail | None:
    if response.status_code == 200:
        response_200 = (
            IncidentProcessInstanceStatisticsByDefinitionQueryResult.from_dict(
                response.json()
            )
        )
        return response_200
    if response.status_code == 400:
        response_400 = ProblemDetail.from_dict(response.json())
        return response_400
    if response.status_code == 401:
        response_401 = ProblemDetail.from_dict(response.json())
        return response_401
    if response.status_code == 403:
        response_403 = ProblemDetail.from_dict(response.json())
        return response_403
    if response.status_code == 500:
        response_500 = ProblemDetail.from_dict(response.json())
        return response_500
    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[IncidentProcessInstanceStatisticsByDefinitionQueryResult | ProblemDetail]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: IncidentProcessInstanceStatisticsByDefinitionQuery,
) -> Response[IncidentProcessInstanceStatisticsByDefinitionQueryResult | ProblemDetail]:
    """Get process instance statistics by definition

     Returns statistics for active process instances with incidents, grouped by process
    definition. The result set is scoped to a specific incident error hash code, which must be
    provided as a filter in the request body.

    Args:
        body (IncidentProcessInstanceStatisticsByDefinitionQuery):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[IncidentProcessInstanceStatisticsByDefinitionQueryResult | ProblemDetail]
    """
    kwargs = _get_kwargs(body=body)
    response = client.get_httpx_client().request(**kwargs)
    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: IncidentProcessInstanceStatisticsByDefinitionQuery,
    **kwargs: Any,
) -> IncidentProcessInstanceStatisticsByDefinitionQueryResult:
    """Get process instance statistics by definition

     Returns statistics for active process instances with incidents, grouped by process
    definition. The result set is scoped to a specific incident error hash code, which must be
    provided as a filter in the request body.

    Args:
        body (IncidentProcessInstanceStatisticsByDefinitionQuery):

    Raises:
        errors.BadRequestError: If the response status code is 400. The provided data is not valid.
        errors.UnauthorizedError: If the response status code is 401. The request lacks valid authentication credentials.
        errors.ForbiddenError: If the response status code is 403. Forbidden. The request is not allowed.
        errors.InternalServerErrorError: If the response status code is 500. An internal error occurred while processing the request.
        errors.UnexpectedStatus: If the response status code is not documented.
        httpx.TimeoutException: If the request takes longer than Client.timeout.
    Returns:
        IncidentProcessInstanceStatisticsByDefinitionQueryResult"""
    response = sync_detailed(client=client, body=body)
    if response.status_code < 200 or response.status_code >= 300:
        if response.status_code == 400:
            raise errors.BadRequestError(
                status_code=response.status_code,
                content=response.content,
                parsed=cast(ProblemDetail, response.parsed),
                operation_id="get_process_instance_statistics_by_definition",
            )
        if response.status_code == 401:
            raise errors.UnauthorizedError(
                status_code=response.status_code,
                content=response.content,
                parsed=cast(ProblemDetail, response.parsed),
                operation_id="get_process_instance_statistics_by_definition",
            )
        if response.status_code == 403:
            raise errors.ForbiddenError(
                status_code=response.status_code,
                content=response.content,
                parsed=cast(ProblemDetail, response.parsed),
                operation_id="get_process_instance_statistics_by_definition",
            )
        if response.status_code == 500:
            raise errors.InternalServerErrorError(
                status_code=response.status_code,
                content=response.content,
                parsed=cast(ProblemDetail, response.parsed),
                operation_id="get_process_instance_statistics_by_definition",
            )
        raise errors.UnexpectedStatus(
            response.status_code,
            response.content,
            operation_id="get_process_instance_statistics_by_definition",
        )
    assert response.parsed is not None
    return cast(
        IncidentProcessInstanceStatisticsByDefinitionQueryResult, response.parsed
    )


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: IncidentProcessInstanceStatisticsByDefinitionQuery,
) -> Response[IncidentProcessInstanceStatisticsByDefinitionQueryResult | ProblemDetail]:
    """Get process instance statistics by definition

     Returns statistics for active process instances with incidents, grouped by process
    definition. The result set is scoped to a specific incident error hash code, which must be
    provided as a filter in the request body.

    Args:
        body (IncidentProcessInstanceStatisticsByDefinitionQuery):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[IncidentProcessInstanceStatisticsByDefinitionQueryResult | ProblemDetail]
    """
    kwargs = _get_kwargs(body=body)
    response = await client.get_async_httpx_client().request(**kwargs)
    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: IncidentProcessInstanceStatisticsByDefinitionQuery,
    **kwargs: Any,
) -> IncidentProcessInstanceStatisticsByDefinitionQueryResult:
    """Get process instance statistics by definition

     Returns statistics for active process instances with incidents, grouped by process
    definition. The result set is scoped to a specific incident error hash code, which must be
    provided as a filter in the request body.

    Args:
        body (IncidentProcessInstanceStatisticsByDefinitionQuery):

    Raises:
        errors.BadRequestError: If the response status code is 400. The provided data is not valid.
        errors.UnauthorizedError: If the response status code is 401. The request lacks valid authentication credentials.
        errors.ForbiddenError: If the response status code is 403. Forbidden. The request is not allowed.
        errors.InternalServerErrorError: If the response status code is 500. An internal error occurred while processing the request.
        errors.UnexpectedStatus: If the response status code is not documented.
        httpx.TimeoutException: If the request takes longer than Client.timeout.
    Returns:
        IncidentProcessInstanceStatisticsByDefinitionQueryResult"""
    response = await asyncio_detailed(client=client, body=body)
    if response.status_code < 200 or response.status_code >= 300:
        if response.status_code == 400:
            raise errors.BadRequestError(
                status_code=response.status_code,
                content=response.content,
                parsed=cast(ProblemDetail, response.parsed),
                operation_id="get_process_instance_statistics_by_definition",
            )
        if response.status_code == 401:
            raise errors.UnauthorizedError(
                status_code=response.status_code,
                content=response.content,
                parsed=cast(ProblemDetail, response.parsed),
                operation_id="get_process_instance_statistics_by_definition",
            )
        if response.status_code == 403:
            raise errors.ForbiddenError(
                status_code=response.status_code,
                content=response.content,
                parsed=cast(ProblemDetail, response.parsed),
                operation_id="get_process_instance_statistics_by_definition",
            )
        if response.status_code == 500:
            raise errors.InternalServerErrorError(
                status_code=response.status_code,
                content=response.content,
                parsed=cast(ProblemDetail, response.parsed),
                operation_id="get_process_instance_statistics_by_definition",
            )
        raise errors.UnexpectedStatus(
            response.status_code,
            response.content,
            operation_id="get_process_instance_statistics_by_definition",
        )
    assert response.parsed is not None
    return cast(
        IncidentProcessInstanceStatisticsByDefinitionQueryResult, response.parsed
    )
