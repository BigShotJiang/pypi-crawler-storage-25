from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote
import httpx
from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.delete_resource_request import DeleteResourceRequest
from ...models.delete_resource_response import DeleteResourceResponse
from ...models.problem_detail import ProblemDetail
from ...types import UNSET, Response, Unset


def _get_kwargs(
    resource_key: str, *, body: DeleteResourceRequest | None | Unset = UNSET
) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/resources/{resource_key}/deletion".format(
            resource_key=quote(str(resource_key), safe="")
        ),
    }
    if isinstance(body, DeleteResourceRequest):
        _kwargs["json"] = body.to_dict()
    else:
        _kwargs["json"] = body
    headers["Content-Type"] = "application/json"
    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DeleteResourceResponse | ProblemDetail | None:
    if response.status_code == 200:
        response_200 = DeleteResourceResponse.from_dict(response.json())
        return response_200
    if response.status_code == 400:
        response_400 = ProblemDetail.from_dict(response.json())
        return response_400
    if response.status_code == 404:
        response_404 = ProblemDetail.from_dict(response.json())
        return response_404
    if response.status_code == 500:
        response_500 = ProblemDetail.from_dict(response.json())
        return response_500
    if response.status_code == 503:
        response_503 = ProblemDetail.from_dict(response.json())
        return response_503
    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DeleteResourceResponse | ProblemDetail]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    resource_key: str,
    *,
    client: AuthenticatedClient | Client,
    body: DeleteResourceRequest | None | Unset = UNSET,
) -> Response[DeleteResourceResponse | ProblemDetail]:
    """Delete resource

     Deletes a deployed resource. This can be a process definition, decision requirements
    definition, or form definition deployed using the deploy resources endpoint. Specify the
    resource you want to delete in the `resourceKey` parameter.

    Once a resource has been deleted it cannot be recovered. If the resource needs to be
    available again, a new deployment of the resource is required.

    By default, only the resource itself is deleted from the runtime state. To also delete the
    historic data associated with a resource, set the `deleteHistory` flag in the request body
    to `true`. The historic data is deleted asynchronously via a batch operation. The details of
    the created batch operation are included in the response. Note that history deletion is only
    supported for process resources; for other resource types this flag is ignored and no history
    will be deleted.

    Args:
        resource_key (str): The system-assigned key for this resource.
        body (DeleteResourceRequest | None | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeleteResourceResponse | ProblemDetail]
    """
    kwargs = _get_kwargs(resource_key=resource_key, body=body)
    response = client.get_httpx_client().request(**kwargs)
    return _build_response(client=client, response=response)


def sync(
    resource_key: str,
    *,
    client: AuthenticatedClient | Client,
    body: DeleteResourceRequest | None | Unset = UNSET,
    **kwargs: Any,
) -> DeleteResourceResponse:
    """Delete resource

     Deletes a deployed resource. This can be a process definition, decision requirements
    definition, or form definition deployed using the deploy resources endpoint. Specify the
    resource you want to delete in the `resourceKey` parameter.

    Once a resource has been deleted it cannot be recovered. If the resource needs to be
    available again, a new deployment of the resource is required.

    By default, only the resource itself is deleted from the runtime state. To also delete the
    historic data associated with a resource, set the `deleteHistory` flag in the request body
    to `true`. The historic data is deleted asynchronously via a batch operation. The details of
    the created batch operation are included in the response. Note that history deletion is only
    supported for process resources; for other resource types this flag is ignored and no history
    will be deleted.

    Args:
        resource_key (str): The system-assigned key for this resource.
        body (DeleteResourceRequest | None | Unset):

    Raises:
        errors.BadRequestError: If the response status code is 400. The provided data is not valid.
        errors.NotFoundError: If the response status code is 404. The resource is not found.
        errors.InternalServerErrorError: If the response status code is 500. An internal error occurred while processing the request.
        errors.ServiceUnavailableError: If the response status code is 503. The service is currently unavailable. This may happen only on some requests where the system creates backpressure to prevent the server's compute resources from being exhausted, avoiding more severe failures. In this case, the title of the error object contains `RESOURCE_EXHAUSTED`. Clients are recommended to eventually retry those requests after a backoff period. You can learn more about the backpressure mechanism here: https://docs.camunda.io/docs/components/zeebe/technical-concepts/internal-processing/#handling-backpressure .
        errors.UnexpectedStatus: If the response status code is not documented.
        httpx.TimeoutException: If the request takes longer than Client.timeout.
    Returns:
        DeleteResourceResponse"""
    response = sync_detailed(resource_key=resource_key, client=client, body=body)
    if response.status_code < 200 or response.status_code >= 300:
        if response.status_code == 400:
            raise errors.BadRequestError(
                status_code=response.status_code,
                content=response.content,
                parsed=cast(ProblemDetail, response.parsed),
                operation_id="delete_resource",
            )
        if response.status_code == 404:
            raise errors.NotFoundError(
                status_code=response.status_code,
                content=response.content,
                parsed=cast(ProblemDetail, response.parsed),
                operation_id="delete_resource",
            )
        if response.status_code == 500:
            raise errors.InternalServerErrorError(
                status_code=response.status_code,
                content=response.content,
                parsed=cast(ProblemDetail, response.parsed),
                operation_id="delete_resource",
            )
        if response.status_code == 503:
            raise errors.ServiceUnavailableError(
                status_code=response.status_code,
                content=response.content,
                parsed=cast(ProblemDetail, response.parsed),
                operation_id="delete_resource",
            )
        raise errors.UnexpectedStatus(
            response.status_code, response.content, operation_id="delete_resource"
        )
    assert response.parsed is not None
    return cast(DeleteResourceResponse, response.parsed)


async def asyncio_detailed(
    resource_key: str,
    *,
    client: AuthenticatedClient | Client,
    body: DeleteResourceRequest | None | Unset = UNSET,
) -> Response[DeleteResourceResponse | ProblemDetail]:
    """Delete resource

     Deletes a deployed resource. This can be a process definition, decision requirements
    definition, or form definition deployed using the deploy resources endpoint. Specify the
    resource you want to delete in the `resourceKey` parameter.

    Once a resource has been deleted it cannot be recovered. If the resource needs to be
    available again, a new deployment of the resource is required.

    By default, only the resource itself is deleted from the runtime state. To also delete the
    historic data associated with a resource, set the `deleteHistory` flag in the request body
    to `true`. The historic data is deleted asynchronously via a batch operation. The details of
    the created batch operation are included in the response. Note that history deletion is only
    supported for process resources; for other resource types this flag is ignored and no history
    will be deleted.

    Args:
        resource_key (str): The system-assigned key for this resource.
        body (DeleteResourceRequest | None | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeleteResourceResponse | ProblemDetail]
    """
    kwargs = _get_kwargs(resource_key=resource_key, body=body)
    response = await client.get_async_httpx_client().request(**kwargs)
    return _build_response(client=client, response=response)


async def asyncio(
    resource_key: str,
    *,
    client: AuthenticatedClient | Client,
    body: DeleteResourceRequest | None | Unset = UNSET,
    **kwargs: Any,
) -> DeleteResourceResponse:
    """Delete resource

     Deletes a deployed resource. This can be a process definition, decision requirements
    definition, or form definition deployed using the deploy resources endpoint. Specify the
    resource you want to delete in the `resourceKey` parameter.

    Once a resource has been deleted it cannot be recovered. If the resource needs to be
    available again, a new deployment of the resource is required.

    By default, only the resource itself is deleted from the runtime state. To also delete the
    historic data associated with a resource, set the `deleteHistory` flag in the request body
    to `true`. The historic data is deleted asynchronously via a batch operation. The details of
    the created batch operation are included in the response. Note that history deletion is only
    supported for process resources; for other resource types this flag is ignored and no history
    will be deleted.

    Args:
        resource_key (str): The system-assigned key for this resource.
        body (DeleteResourceRequest | None | Unset):

    Raises:
        errors.BadRequestError: If the response status code is 400. The provided data is not valid.
        errors.NotFoundError: If the response status code is 404. The resource is not found.
        errors.InternalServerErrorError: If the response status code is 500. An internal error occurred while processing the request.
        errors.ServiceUnavailableError: If the response status code is 503. The service is currently unavailable. This may happen only on some requests where the system creates backpressure to prevent the server's compute resources from being exhausted, avoiding more severe failures. In this case, the title of the error object contains `RESOURCE_EXHAUSTED`. Clients are recommended to eventually retry those requests after a backoff period. You can learn more about the backpressure mechanism here: https://docs.camunda.io/docs/components/zeebe/technical-concepts/internal-processing/#handling-backpressure .
        errors.UnexpectedStatus: If the response status code is not documented.
        httpx.TimeoutException: If the request takes longer than Client.timeout.
    Returns:
        DeleteResourceResponse"""
    response = await asyncio_detailed(
        resource_key=resource_key, client=client, body=body
    )
    if response.status_code < 200 or response.status_code >= 300:
        if response.status_code == 400:
            raise errors.BadRequestError(
                status_code=response.status_code,
                content=response.content,
                parsed=cast(ProblemDetail, response.parsed),
                operation_id="delete_resource",
            )
        if response.status_code == 404:
            raise errors.NotFoundError(
                status_code=response.status_code,
                content=response.content,
                parsed=cast(ProblemDetail, response.parsed),
                operation_id="delete_resource",
            )
        if response.status_code == 500:
            raise errors.InternalServerErrorError(
                status_code=response.status_code,
                content=response.content,
                parsed=cast(ProblemDetail, response.parsed),
                operation_id="delete_resource",
            )
        if response.status_code == 503:
            raise errors.ServiceUnavailableError(
                status_code=response.status_code,
                content=response.content,
                parsed=cast(ProblemDetail, response.parsed),
                operation_id="delete_resource",
            )
        raise errors.UnexpectedStatus(
            response.status_code, response.content, operation_id="delete_resource"
        )
    assert response.parsed is not None
    return cast(DeleteResourceResponse, response.parsed)
