from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote
import httpx
from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.problem_detail import ProblemDetail
from ...types import UNSET, Response, Unset


def _get_kwargs(document_id: str, *, store_id: str | Unset = UNSET) -> dict[str, Any]:
    params: dict[str, Any] = {}
    params["storeId"] = store_id
    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}
    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/documents/{document_id}".format(
            document_id=quote(str(document_id), safe="")
        ),
        "params": params,
    }
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | ProblemDetail | None:
    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204
    if response.status_code == 404:
        response_404 = ProblemDetail.from_dict(response.json())
        return response_404
    if response.status_code == 500:
        response_500 = ProblemDetail.from_dict(response.json())
        return response_500
    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | ProblemDetail]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    document_id: str,
    *,
    client: AuthenticatedClient | Client,
    store_id: str | Unset = UNSET,
) -> Response[Any | ProblemDetail]:
    """Delete document

     Delete a document from the Camunda 8 cluster.

    Note that this is currently supported for document stores of type: AWS, Azure, GCP, in-memory (non-
    production), local (non-production)

    Args:
        document_id (str): Document Id that uniquely identifies a document.
        store_id (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | ProblemDetail]
    """
    kwargs = _get_kwargs(document_id=document_id, store_id=store_id)
    response = client.get_httpx_client().request(**kwargs)
    return _build_response(client=client, response=response)


def sync(
    document_id: str,
    *,
    client: AuthenticatedClient | Client,
    store_id: str | Unset = UNSET,
    **kwargs: Any,
) -> None:
    """Delete document

     Delete a document from the Camunda 8 cluster.

    Note that this is currently supported for document stores of type: AWS, Azure, GCP, in-memory (non-
    production), local (non-production)

    Args:
        document_id (str): Document Id that uniquely identifies a document.
        store_id (str | Unset):

    Raises:
        errors.NotFoundError: If the response status code is 404. The document with the given ID was not found.
        errors.InternalServerErrorError: If the response status code is 500. An internal error occurred while processing the request.
        errors.UnexpectedStatus: If the response status code is not documented.
        httpx.TimeoutException: If the request takes longer than Client.timeout.
    Returns:
        None"""
    response = sync_detailed(document_id=document_id, client=client, store_id=store_id)
    if response.status_code < 200 or response.status_code >= 300:
        if response.status_code == 404:
            raise errors.NotFoundError(
                status_code=response.status_code,
                content=response.content,
                parsed=cast(ProblemDetail, response.parsed),
                operation_id="delete_document",
            )
        if response.status_code == 500:
            raise errors.InternalServerErrorError(
                status_code=response.status_code,
                content=response.content,
                parsed=cast(ProblemDetail, response.parsed),
                operation_id="delete_document",
            )
        raise errors.UnexpectedStatus(
            response.status_code, response.content, operation_id="delete_document"
        )
    return None


async def asyncio_detailed(
    document_id: str,
    *,
    client: AuthenticatedClient | Client,
    store_id: str | Unset = UNSET,
) -> Response[Any | ProblemDetail]:
    """Delete document

     Delete a document from the Camunda 8 cluster.

    Note that this is currently supported for document stores of type: AWS, Azure, GCP, in-memory (non-
    production), local (non-production)

    Args:
        document_id (str): Document Id that uniquely identifies a document.
        store_id (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | ProblemDetail]
    """
    kwargs = _get_kwargs(document_id=document_id, store_id=store_id)
    response = await client.get_async_httpx_client().request(**kwargs)
    return _build_response(client=client, response=response)


async def asyncio(
    document_id: str,
    *,
    client: AuthenticatedClient | Client,
    store_id: str | Unset = UNSET,
    **kwargs: Any,
) -> None:
    """Delete document

     Delete a document from the Camunda 8 cluster.

    Note that this is currently supported for document stores of type: AWS, Azure, GCP, in-memory (non-
    production), local (non-production)

    Args:
        document_id (str): Document Id that uniquely identifies a document.
        store_id (str | Unset):

    Raises:
        errors.NotFoundError: If the response status code is 404. The document with the given ID was not found.
        errors.InternalServerErrorError: If the response status code is 500. An internal error occurred while processing the request.
        errors.UnexpectedStatus: If the response status code is not documented.
        httpx.TimeoutException: If the request takes longer than Client.timeout.
    Returns:
        None"""
    response = await asyncio_detailed(
        document_id=document_id, client=client, store_id=store_id
    )
    if response.status_code < 200 or response.status_code >= 300:
        if response.status_code == 404:
            raise errors.NotFoundError(
                status_code=response.status_code,
                content=response.content,
                parsed=cast(ProblemDetail, response.parsed),
                operation_id="delete_document",
            )
        if response.status_code == 500:
            raise errors.InternalServerErrorError(
                status_code=response.status_code,
                content=response.content,
                parsed=cast(ProblemDetail, response.parsed),
                operation_id="delete_document",
            )
        raise errors.UnexpectedStatus(
            response.status_code, response.content, operation_id="delete_document"
        )
    return None
