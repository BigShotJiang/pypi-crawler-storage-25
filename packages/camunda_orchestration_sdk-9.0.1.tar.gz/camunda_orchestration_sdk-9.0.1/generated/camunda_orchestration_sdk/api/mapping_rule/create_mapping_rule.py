from http import HTTPStatus
from typing import Any, cast
import httpx
from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.create_mapping_rule_response_201 import CreateMappingRuleResponse201
from ...models.mapping_rule_create_request import MappingRuleCreateRequest
from ...models.problem_detail import ProblemDetail
from ...types import UNSET, Response, Unset


def _get_kwargs(*, body: MappingRuleCreateRequest | Unset = UNSET) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    _kwargs: dict[str, Any] = {"method": "post", "url": "/mapping-rules"}
    if not isinstance(body, Unset):
        _kwargs["json"] = body.to_dict()
    headers["Content-Type"] = "application/json"
    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> CreateMappingRuleResponse201 | ProblemDetail | None:
    if response.status_code == 201:
        response_201 = CreateMappingRuleResponse201.from_dict(response.json())
        return response_201
    if response.status_code == 400:
        response_400 = ProblemDetail.from_dict(response.json())
        return response_400
    if response.status_code == 403:
        response_403 = ProblemDetail.from_dict(response.json())
        return response_403
    if response.status_code == 404:
        response_404 = ProblemDetail.from_dict(response.json())
        return response_404
    if response.status_code == 500:
        response_500 = ProblemDetail.from_dict(response.json())
        return response_500
    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[CreateMappingRuleResponse201 | ProblemDetail]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: MappingRuleCreateRequest | Unset = UNSET,
) -> Response[CreateMappingRuleResponse201 | ProblemDetail]:
    """Create mapping rule

     Create a new mapping rule

    Args:
        body (MappingRuleCreateRequest | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CreateMappingRuleResponse201 | ProblemDetail]
    """
    kwargs = _get_kwargs(body=body)
    response = client.get_httpx_client().request(**kwargs)
    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: MappingRuleCreateRequest | Unset = UNSET,
    **kwargs: Any,
) -> CreateMappingRuleResponse201:
    """Create mapping rule

     Create a new mapping rule

    Args:
        body (MappingRuleCreateRequest | Unset):

    Raises:
        errors.BadRequestError: If the response status code is 400. The provided data is not valid.
        errors.ForbiddenError: If the response status code is 403. The request to create a mapping rule was denied. More details are provided in the response body.
        errors.NotFoundError: If the response status code is 404. The request to create a mapping rule was denied.
        errors.InternalServerErrorError: If the response status code is 500. An internal error occurred while processing the request.
        errors.UnexpectedStatus: If the response status code is not documented.
        httpx.TimeoutException: If the request takes longer than Client.timeout.
    Returns:
        CreateMappingRuleResponse201"""
    response = sync_detailed(client=client, body=body)
    if response.status_code < 200 or response.status_code >= 300:
        if response.status_code == 400:
            raise errors.BadRequestError(
                status_code=response.status_code,
                content=response.content,
                parsed=cast(ProblemDetail, response.parsed),
                operation_id="create_mapping_rule",
            )
        if response.status_code == 403:
            raise errors.ForbiddenError(
                status_code=response.status_code,
                content=response.content,
                parsed=cast(ProblemDetail, response.parsed),
                operation_id="create_mapping_rule",
            )
        if response.status_code == 404:
            raise errors.NotFoundError(
                status_code=response.status_code,
                content=response.content,
                parsed=cast(ProblemDetail, response.parsed),
                operation_id="create_mapping_rule",
            )
        if response.status_code == 500:
            raise errors.InternalServerErrorError(
                status_code=response.status_code,
                content=response.content,
                parsed=cast(ProblemDetail, response.parsed),
                operation_id="create_mapping_rule",
            )
        raise errors.UnexpectedStatus(
            response.status_code, response.content, operation_id="create_mapping_rule"
        )
    assert response.parsed is not None
    return cast(CreateMappingRuleResponse201, response.parsed)


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: MappingRuleCreateRequest | Unset = UNSET,
) -> Response[CreateMappingRuleResponse201 | ProblemDetail]:
    """Create mapping rule

     Create a new mapping rule

    Args:
        body (MappingRuleCreateRequest | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CreateMappingRuleResponse201 | ProblemDetail]
    """
    kwargs = _get_kwargs(body=body)
    response = await client.get_async_httpx_client().request(**kwargs)
    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: MappingRuleCreateRequest | Unset = UNSET,
    **kwargs: Any,
) -> CreateMappingRuleResponse201:
    """Create mapping rule

     Create a new mapping rule

    Args:
        body (MappingRuleCreateRequest | Unset):

    Raises:
        errors.BadRequestError: If the response status code is 400. The provided data is not valid.
        errors.ForbiddenError: If the response status code is 403. The request to create a mapping rule was denied. More details are provided in the response body.
        errors.NotFoundError: If the response status code is 404. The request to create a mapping rule was denied.
        errors.InternalServerErrorError: If the response status code is 500. An internal error occurred while processing the request.
        errors.UnexpectedStatus: If the response status code is not documented.
        httpx.TimeoutException: If the request takes longer than Client.timeout.
    Returns:
        CreateMappingRuleResponse201"""
    response = await asyncio_detailed(client=client, body=body)
    if response.status_code < 200 or response.status_code >= 300:
        if response.status_code == 400:
            raise errors.BadRequestError(
                status_code=response.status_code,
                content=response.content,
                parsed=cast(ProblemDetail, response.parsed),
                operation_id="create_mapping_rule",
            )
        if response.status_code == 403:
            raise errors.ForbiddenError(
                status_code=response.status_code,
                content=response.content,
                parsed=cast(ProblemDetail, response.parsed),
                operation_id="create_mapping_rule",
            )
        if response.status_code == 404:
            raise errors.NotFoundError(
                status_code=response.status_code,
                content=response.content,
                parsed=cast(ProblemDetail, response.parsed),
                operation_id="create_mapping_rule",
            )
        if response.status_code == 500:
            raise errors.InternalServerErrorError(
                status_code=response.status_code,
                content=response.content,
                parsed=cast(ProblemDetail, response.parsed),
                operation_id="create_mapping_rule",
            )
        raise errors.UnexpectedStatus(
            response.status_code, response.content, operation_id="create_mapping_rule"
        )
    assert response.parsed is not None
    return cast(CreateMappingRuleResponse201, response.parsed)
