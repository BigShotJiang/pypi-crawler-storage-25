# deepfos-loguru-corotate

基于 **loguru** 的**集中日志轮转**与**多进程协同 reopen**：由单一进程（例如 Gunicorn master）按与 loguru `FileSink` 一致的规则执行 `rename` 轮转，再通过向**同一进程组**广播 **`SIGWINCH`**，使 worker / 子进程等在**保留原有 SIGWINCH 处理的前提下**链式执行 loguru 的 `remove` + `configure`，从而避免仍持有旧 inode 继续写归档前的文件。

## 功能概要

- **集中轮转**：轮询 `should_rotate`，到期则 `rename` 当前日志、重建目标文件、在 rotator 进程上执行本地 reopen，再 `os.killpg(..., SIGWINCH)` 通知同作业进程组。
- **SIGWINCH 链**：`ensure_reopen_inited` 安装处理器时保存原有处理函数；信号到达时**先**调用原处理（如框架自带的 reopen），**再**执行已登记的 loguru reopen。
- **fork 后状态**：可在 worker `post_worker_init` 等场景调用 `reset_reopen_state_after_fork`，避免子进程继承不应共享的状态。
- **压缩与保留**：轮转生成的归档路径可在延迟后执行与 loguru 策略对齐的压缩与 retention（实现依赖 loguru 内部 API）。

## 安装

```bash
pip install deepfos-loguru-corotate
```

或从源码

```bash
pip install .
```
