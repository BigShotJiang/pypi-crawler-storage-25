"""集中轮转 + 按 SIGWINCH 链式 reopen（loguru）

**轮转（仅 Gunicorn master 上的 ``log-rotation`` 线程）**

- 用与 loguru FileSink 一致的规则轮询 ``should_rotate``；到期则 ``rename`` 当前日志、建新
  ``pipeline.log``、在 master 上 ``run_all_reopen_callbacks()``。
- 再 ``os.killpg(os.getpgid(master), SIGWINCH)`` 向**同一进程组**广播，使 worker / daemon /
  代码服务等持有旧 inode 的进程重新打开日志。失败只打错误日志，无逐项 ``kill`` 兜底。
- 每次 rename 出的归档路径在约 300 秒后做一次 compress / retention（与 loguru 的 tar 策略对齐）。
- 时间型轮转时会缩短 sleep，避免长时间越过下一触发点。

**SIGWINCH 处理链（各进程内 ``ensure_reopen_inited`` 安装）**

- 保存 ``getsignal(SIGWINCH)`` 为 ``_sigwinch_previous``（若原为 ``SIG_DFL`` / ``SIG_IGN`` 或非
  可调用则视为无 predecessor），再挂上 ``_chain_sigwinch_reopen``。
- 信号到达时顺序为：**先**调用原处理（如 Gunicorn 内对 WINCH 的实现），**再**
  ``run_all_reopen_callbacks()``（移除并重新 ``configure`` 已登记的 loguru），**最后**打
  ``central rotation: SIGWINCH received``，避免诊断行仍写入已归档文件。
- 选用 SIGWINCH 广播时，多数辅助进程对 WINCH 默认为忽略或轻量处理，较 SIGUSR1 更不易误伤
  同组内的 ``multiprocessing.resource_tracker``；若 Gunicorn 以 ``daemon=True`` 运行，Arbiter
  对 WINCH 会走「优雅停 worker」分支，勿与生产前台/容器部署混用。

**Worker fork 之后**

- ``gunicorn.conf`` 的 ``post_worker_init`` 中依次调用 ``reset_reopen_state_after_fork``、
  ``ensure_reopen_inited``，在框架 ``init_signals`` 装完 SIGWINCH 之后登记链与 reopen 表；
  ``post_fork`` 阶段可不登记集中日志。
"""
import functools
import glob
import os
import pathlib
import signal
import threading
import time
from datetime import datetime
from types import FrameType
from typing import Any, Callable, Optional

from loguru import logger
from loguru._ctime_functions import get_ctime, set_ctime
from loguru._file_sink import FileSink, Rotation, generate_rename_path

__all__ = [
    "reset_reopen_state_after_fork",
    "ensure_reopen_inited",
    "managed_rotation_poll_loop",
]

_entries_lock = threading.RLock()
_reopen_entries = []


# ``ensure_reopen_inited`` 首次安装 SIGWINCH 时保留的原处理函数（如 Gunicorn reopen）
_sigwinch_previous: Optional[Callable[[int, Optional[FrameType]], Any]] = None


def _chain_sigwinch_reopen(signum: int, frame: Optional[FrameType]) -> None:
    """先 chain 原有的 SIGWINCH（如 Gunicorn reopen_files），再做集中日志 reopen。

    「SIGWINCH received」日志须在 reopen **之后** 再打，否则会仍写入 rename 前的旧 inode，
    使关键诊断出现在上一段归档里，误判为未 reopen。"""
    prev = _sigwinch_previous
    if prev is not None:
        try:
            prev(signum, frame)
        except Exception:
            logger.exception(f"SIGWINCH previous handler failed")
    run_all_reopen_callbacks()
    logger.debug(f"central rotation: SIGWINCH received pid={os.getpid()} signum={signum}")


class RotationMessage(str):
    """与 loguru FileSink.rotation 校验时的 message 形状对齐（含 ``.record['time']``）。"""
    def __new__(cls, text: str = "") -> "RotationMessage":
        obj = super().__new__(cls, text)
        obj.record = {"time": datetime.now().astimezone()}
        return obj


def should_rotate(path: pathlib.Path, rotation_fn: Any) -> bool:
    if not path.exists():
        return False

    with open(str(path), "a+", encoding="utf-8") as file_obj:
        file_obj.seek(0, os.SEEK_END)
        if isinstance(rotation_fn, functools.partial) and rotation_fn.func is Rotation.rotation_size:
            limit = rotation_fn.keywords.get("size_limit")
            if limit is not None:
                return file_obj.tell() >= limit
        return bool(rotation_fn(RotationMessage(), file_obj))


def managed_rotation_poll_loop(
    file_path: str,
    rotation: Any,
    poll_interval_sec: int,
    retention: Optional[str] = None,
):
    """轮询触发：rename -> 全组 SIGWINCH -> 延迟 compress / retention。

    仅由 Gunicorn **master** ``on_starting`` 启动的 ``log-rotation`` 线程调用；``rotator`` 即
    arbiter，``os.killpg(os.getpgid(rotator))`` 唤醒同作业组内全体子进程。若 ``killpg``
    失败只打错误日志，不设弱于 ``killpg`` 的逐项 ``kill`` 兜底。"""
    path = pathlib.Path(file_path)
    root, ext = os.path.splitext(str(path))
    compress_fn = FileSink._make_compression_function("tar.gz")
    rotation_fn = FileSink._make_rotation_function(rotation)
    retention_fn = (
        None if retention is None
        else FileSink._make_retention_function(str(retention).strip())
    )
    glob_patterns = FileSink._make_glob_patterns(str(path))
    is_time_rotation = isinstance(rotation_fn, Rotation.RotationTime)

    def compress_round(destination: str) -> None:
        try:
            if not os.path.isfile(destination) or os.path.getsize(destination) <= 0:
                try:
                    os.remove(destination)
                except OSError:
                    pass
                return
            compress_fn(destination)
            logs = {
                p for pattern in glob_patterns
                for p in glob.glob(pattern) if os.path.isfile(p)
            }
            if retention_fn is not None:
                retention_fn(list(logs))
        except Exception:
            logger.exception(f"central log compress/retention failed for {destination}")

    while True:
        try:
            if should_rotate(path, rotation_fn):
                # rename and reopen local
                creation_time = get_ctime(str(path))
                dest = generate_rename_path(root, ext, creation_time)
                os.rename(str(path), dest)
                path.write_bytes(b"")
                set_ctime(str(path), datetime.now().timestamp())
                run_all_reopen_callbacks()
                me = os.getpid()
                # 仅运行在 Gunicorn master；向本 PGID 广播 SIGWINCH（含 HTTP worker / daemon /
                # gRPC代码服务 / WorkerPool）。master 同组亦可再收一次 reopen，语义上可接受。
                try:
                    pgid = int(os.getpgid(me))
                except ProcessLookupError:
                    logger.error(
                        f"central rotation: getpgid failed for rotator pid={me}",
                    )
                else:
                    try:
                        os.killpg(pgid, signal.SIGWINCH)
                        logger.debug(
                            f"central rotation: sent SIGWINCH mode=killpg "
                            f"from rotator_pid={me} pgid={pgid} "
                            f"(whole job group incl. master)",
                        )
                    except ProcessLookupError:
                        logger.error(
                            f"central rotation: killpg ProcessLookupError "
                            f"rotator_pid={me} pgid={pgid}",
                        )
                    except OSError as e:
                        logger.error(
                            f"central rotation: killpg OSError "
                            f"rotator_pid={me} pgid={pgid} err={e}",
                        )
                timer = threading.Timer(300, compress_round, args=(dest,))
                timer.daemon = True
                timer.start()
                rotation_fn = FileSink._make_rotation_function(rotation)
        except Exception:
            logger.exception(f"central managed rotation iteration failed")

        interval = float(poll_interval_sec)
        if is_time_rotation and rotation_fn._limit is not None:
            secs = (rotation_fn._limit - datetime.now()).total_seconds()
            interval = min(interval, max(1.0, secs))
        logger.debug(f"poll next rotation after {interval} seconds")
        time.sleep(interval)


def run_all_reopen_callbacks() -> None:
    with _entries_lock:
        snapshot = list(_reopen_entries)
    for lg, kw in snapshot:
        try:
            lg.remove()
            lg.configure(**kw)
        except Exception:
            logger.exception(f"central log reopen failed for logger {lg}")

def ensure_reopen_inited(
    log_file: str,
    log_instance=logger,
    **kwargs: Any,
) -> None:
    new_row = (log_instance, dict(kwargs))
    with _entries_lock:
        # upsert settings
        for i, (lg, _) in enumerate(_reopen_entries):
            if lg is log_instance:
                _reopen_entries[i] = new_row
                break
        else:
            _reopen_entries.append(new_row)

    # 用 ``getsignal(SIGWINCH)`` 读到当前处理器作为 `_sigwinch_previous`，再套上链
    winch = signal.SIGWINCH
    current = signal.getsignal(winch)

    global _sigwinch_previous

    if current is _chain_sigwinch_reopen:
        return

    if current in (signal.SIG_DFL, signal.SIG_IGN) or not callable(current):
        _sigwinch_previous = None
    else:
        _sigwinch_previous = current

    try:
        signal.signal(winch, _chain_sigwinch_reopen)
    except (ValueError, OSError):
        pass


def reset_reopen_state_after_fork() -> None:
    with _entries_lock:
        _reopen_entries[:] = [(lg, kw) for lg, kw in _reopen_entries if lg is logger]
