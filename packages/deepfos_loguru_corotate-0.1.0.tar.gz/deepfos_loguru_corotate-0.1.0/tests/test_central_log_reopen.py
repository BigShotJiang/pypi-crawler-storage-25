from __future__ import annotations

import functools
import os
import signal
from unittest.mock import MagicMock, patch

import pytest
from loguru import logger as loguru_default_logger
from loguru._file_sink import FileSink, Rotation

from loguru_corotate.corotate import (
    RotationMessage,
    ensure_reopen_inited,
    managed_rotation_poll_loop,
    reset_reopen_state_after_fork,
    run_all_reopen_callbacks,
    should_rotate,
)


class TestShouldRotate:
    def test_missing_file_false(self, tmp_path):
        missing = tmp_path / "nope.log"
        rfn = FileSink._make_rotation_function("1 KB")
        assert should_rotate(missing, rfn) is False

    def test_size_rotation(self, tmp_path):
        log = tmp_path / "s.log"
        rot = FileSink._make_rotation_function("128 B")
        limit = None
        if isinstance(rot, functools.partial) and rot.func is Rotation.rotation_size:
            limit = rot.keywords.get("size_limit")
        assert limit is not None
        lim = int(limit)

        log.write_bytes(b"0" * (lim - 1))
        assert should_rotate(log, rot) is False
        with open(log, "ab") as f:
            f.write(b"0")
        assert should_rotate(log, rot) is True

    def test_rotation_message_has_record(self):
        m = RotationMessage("x")
        assert hasattr(m, "record")
        assert "time" in m.record


class TestResetReopenStateAfterFork:
    def test_keeps_only_default_loguru_logger(self):
        import loguru_corotate.corotate as m

        fake = MagicMock()
        with m._entries_lock:
            m._reopen_entries.clear()
            m._reopen_entries.append((fake, {}))
            m._reopen_entries.append((loguru_default_logger, {"handlers": []}))

        reset_reopen_state_after_fork()

        assert len(m._reopen_entries) == 1
        assert m._reopen_entries[0][0] is loguru_default_logger


class TestRunAllReopenCallbacks:
    def test_remove_and_configure(self):
        import loguru_corotate.corotate as m

        lg = MagicMock()
        kw = {"handlers": [{"sink": "/dev/null", "level": "INFO"}]}
        with m._entries_lock:
            m._reopen_entries.append((lg, kw))
        run_all_reopen_callbacks()
        lg.remove.assert_called_once()
        lg.configure.assert_called_once_with(**kw)


class TestEnsureReopenInited:
    def test_registers_SIGWINCH_on_first_logger_only(self, tmp_path):
        import loguru_corotate.corotate as m

        log_file = tmp_path / "w.log"
        log_file.touch()
        lg1 = MagicMock()
        lg2 = MagicMock()
        cfg = {"handlers": [{"sink": str(log_file), "level": "INFO"}]}

        phase = [0]

        def fake_getsignal(_sig):
            return signal.SIG_DFL if phase[0] == 0 else m._chain_sigwinch_reopen

        def fake_signal(sig, handler):
            phase[0] = 1
            return None

        with patch("loguru_corotate.corotate.signal.SIGWINCH", 30, create=True):
            with patch(
                "loguru_corotate.corotate.signal.getsignal",
                side_effect=fake_getsignal,
            ):
                with patch(
                    "loguru_corotate.corotate.signal.signal",
                    side_effect=fake_signal,
                ) as sig_signal:
                    ensure_reopen_inited(str(log_file), log_instance=lg1, **cfg)
                    sig_signal.assert_called_once()
                    _, handler = sig_signal.call_args.args
                    assert handler is m._chain_sigwinch_reopen

                    sig_signal.reset_mock()
                    ensure_reopen_inited(str(log_file), log_instance=lg1, **cfg)
                    sig_signal.assert_not_called()

                    ensure_reopen_inited(str(log_file), log_instance=lg2, **cfg)
                    sig_signal.assert_not_called()


class TestSIGWINCHChaining:
    def test_previous_handler_called_before_reopen_callbacks(self):
        """链式 SIGWINCH：先执行原先的 handler。"""
        import loguru_corotate.corotate as m

        lg = MagicMock()
        previous = MagicMock()

        def fake_getsignal(_sig):
            return previous

        with patch.object(signal, "SIGWINCH", 30, create=True):
            with patch(
                "loguru_corotate.corotate.signal.getsignal",
                side_effect=fake_getsignal,
            ), patch(
                "loguru_corotate.corotate.signal.signal",
                return_value=None,
            ):
                ensure_reopen_inited("__unused__", log_instance=lg, handlers=[])

        m._chain_sigwinch_reopen(30, None)
        previous.assert_called_once_with(30, None)
        lg.remove.assert_called_once()


class TestManagedRotationPollLoop:
    """同步 Timer + 短路 sleep：跑完一次轮转后退出。"""

    @pytest.fixture(autouse=True)
    def _suppress_real_killpg(self):
        """轮转会对 ``killpg(getpgid(arbiter))`` 广播 SIGWINCH；宿主 pytest 与同 PGID
        会收到真实信号，PyCharm 常表现为 exit code 158。默认打桩。"""
        with patch("loguru_corotate.corotate.os.killpg"):
            yield

    def _sync_timer_class(self):
        class SyncTimer:
            __slots__ = ("daemon", "_fn")

            def __init__(self, interval, function, args=None, kwargs=None):
                self.daemon = True
                args = args or ()
                kwargs = kwargs or {}
                self._fn = lambda: function(*args, **kwargs)

            def start(self) -> None:
                self._fn()

        return SyncTimer

    def test_one_rotate_then_exit(self, tmp_path):
        log_path = tmp_path / "m.log"
        log_path.write_bytes(b"x" * 800)

        sleep_n = {"n": 0}

        def bail_sleep(_s: float) -> None:
            sleep_n["n"] += 1
            if sleep_n["n"] >= 2:
                raise SystemExit(0)

        SyncTimer = self._sync_timer_class()

        with patch(
            "loguru_corotate.corotate.threading.Timer", SyncTimer
        ), patch("loguru_corotate.corotate.time.sleep", bail_sleep):
            with pytest.raises(SystemExit):
                managed_rotation_poll_loop(str(log_path), "128 B", 1, None)

        assert list(tmp_path.glob("*.tar.gz"))
        assert log_path.is_file() and log_path.stat().st_size == 0

    @pytest.mark.skipif(
        not hasattr(signal, "SIGWINCH"), reason="平台无 SIGWINCH（如 Windows）"
    )
    def test_rotation_broadcast_killpg_entire_job_group(self, tmp_path):
        """轮转时优先 ``killpg(getpgid(rotator))``，同组 daemon / grpc worker 均能收到。"""
        log_path = tmp_path / "k.log"
        log_path.write_bytes(b"y" * 800)

        sleep_n = {"n": 0}

        def bail_sleep(_s: float) -> None:
            sleep_n["n"] += 1
            if sleep_n["n"] >= 2:
                raise SystemExit(0)

        SyncTimer = self._sync_timer_class()
        expect_pgid = os.getpgid(os.getpid())

        with patch(
            "loguru_corotate.corotate.threading.Timer", SyncTimer
        ), patch("loguru_corotate.corotate.time.sleep", bail_sleep), patch(
            "loguru_corotate.corotate.os.killpg"
        ) as mock_killpg:
            with pytest.raises(SystemExit):
                managed_rotation_poll_loop(
                    str(log_path),
                    "128 B",
                    1,
                    None,
                )

        mock_killpg.assert_called_once_with(expect_pgid, signal.SIGWINCH)


class TestManagedRotationPollLoopTimeSleep:
    """时间轮转下的 sleep：用真实 ``rotation`` 字符串（如 ``10 seconds``）走 loguru 逻辑。

    ``while True`` 无法自然结束，因此仍 **only** patch ``time.sleep``：记录参数后 ``SystemExit``。
    """

    @pytest.fixture(autouse=True)
    def _suppress_real_killpg(self):
        """见 ``TestManagedRotationPollLoop._suppress_real_killpg``。"""
        with patch("loguru_corotate.corotate.os.killpg"):
            yield

    def test_real_time_rotation_sleep_below_long_poll_interval(self, tmp_path):
        """距下次边界远小于 ``DP_LOG_ROTATION_POLL_INTERVAL_SEC`` 时，睡眠取更短的一侧。"""
        log_path = tmp_path / "real_time.log"
        log_path.touch()

        sleeps: list[float] = []

        def capture_sleep(sec: float) -> None:
            sleeps.append(sec)
            raise SystemExit(0)

        long_poll = 7200
        period = 10.0
        with patch(
            "loguru_corotate.corotate.time.sleep",
            capture_sleep,
        ):
            with pytest.raises(SystemExit):
                managed_rotation_poll_loop(
                    str(log_path),
                    "10 seconds",
                    long_poll,
                    None,
                )

        assert len(sleeps) == 1
        assert sleeps[0] < long_poll
        assert sleeps[0] <= period + 2.0

    def test_limit_none_falls_through_to_poll_only_when_log_missing(self, tmp_path):
        """路径不存在时 ``should_rotate`` 不调用 ``rotation_fn``，``_limit`` 仍为 ``None``，不进入 min。"""
        missing = tmp_path / "missing.log"
        assert not missing.exists()

        sleeps: list[float] = []

        def capture_sleep(sec: float) -> None:
            sleeps.append(sec)
            raise SystemExit(0)

        with patch(
            "loguru_corotate.corotate.time.sleep",
            capture_sleep,
        ):
            with pytest.raises(SystemExit):
                managed_rotation_poll_loop(
                    str(missing),
                    "2 seconds",
                    37,
                )

        assert len(sleeps) == 1
        assert sleeps[0] == pytest.approx(37.0)

    def test_size_rotation_uses_poll_override_not_limit_branch(self, tmp_path):
        """非 RotationTime 不读 ``_limit``，整段睡眠即 poll/base。"""
        log_path = tmp_path / "sz.log"
        log_path.write_bytes(b"q")

        sleeps: list[float] = []

        def capture_sleep(sec: float) -> None:
            sleeps.append(sec)
            raise SystemExit(0)

        with patch(
            "loguru_corotate.corotate.time.sleep",
            capture_sleep,
        ):
            with pytest.raises(SystemExit):
                managed_rotation_poll_loop(
                    str(log_path),
                    "128 B",
                    33,
                )

        assert len(sleeps) == 1
        assert sleeps[0] == pytest.approx(33.0)
