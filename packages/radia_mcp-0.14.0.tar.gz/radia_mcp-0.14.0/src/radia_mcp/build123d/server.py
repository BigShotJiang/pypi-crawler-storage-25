"""
build123d MCP Server — CAE-Oriented CAD Modeling

Provides tools for:
- build123d API reference (primitives, operations, export/import)
- CAE-specific guidelines (clean geometry, mesh quality)
- Script execution with geometry validation
- STEP/BREP export for Netgen and Cubit pipelines

Usage:
    mcp-server-build123d              # Start MCP server (stdio transport)
    mcp-server-build123d --selftest   # Run self-test
"""

import sys
import json
import traceback
from pathlib import Path
from io import StringIO

from mcp.server.fastmcp import FastMCP

from .build123d_knowledge import get_build123d_documentation
from ..common import failure_log as _fl
from ..common import web_docs as _wd
from ..common import examples as _ex

mcp = FastMCP("mcp-server-build123d")


# ============================================================
# Failure heuristics
# ============================================================

_B3D_ERROR_HEURISTICS: list[tuple[str, str]] = [
    ("nameerror",                "Undefined name — check imports. build123d exposes everything via `from build123d import *` (already prepended)."),
    ("attributeerror",           "Wrong object type. Use `build123d_lookup(query=...)` to find the right method."),
    ("typeerror",                "Argument type mismatch. Consult `build123d_usage(topic='api')` or `build123d_web_docs(query='<symbol>')`."),
    ("brep_api_makeshape failed", "OCCT builder failed — likely degenerate geometry (zero-length edge, self-intersection). Simplify inputs."),
    ("standard_constructionerror","Degenerate construction (radius 0, collinear points, ...). Check numeric inputs."),
    ("no such mode",             "Mode builder wrong (BuildPart vs BuildSketch vs BuildLine). See `build123d_usage(topic='builders')`."),
    ("plane",                    "Plane/workplane mismatch. Use `Plane.XY` / `Plane.XZ` explicitly or pass `Location`."),
    ("fillet",                   "Fillet radius too large vs adjacent edge. Reduce radius or pick fewer edges."),
    ("chamfer",                  "Chamfer length too large. Reduce or pick non-adjacent edges."),
    ("import_step",              "STEP import failed. Check the path exists and the file is not corrupt."),
]


def _build123d_failure_hint(tb: str) -> str:
    """Pick a short hint from common build123d traceback patterns."""
    blob = tb.lower()
    for needle, advice in _B3D_ERROR_HEURISTICS:
        if needle in blob:
            return advice
    return ("No specific heuristic matched. Try "
            "`build123d_lookup(query=...)` (bundled docs + failure log) or "
            "`build123d_web_docs(query=...)` (live readthedocs).")


# ============================================================
# MCP Tools
# ============================================================

@mcp.tool()
def build123d_usage(topic: str = "overview") -> str:
    """
    Get build123d CAD modeling documentation for CAE workflows.

    build123d is a Python-native parametric CAD library on the OCCT kernel.
    This server focuses on CAE (FEM/BEM) geometry creation, not 3D printing.

    Args:
        topic: Documentation topic. Options:
            "overview"        - What build123d is, CAE pipeline, safe subset
            "lab_policy"      - Role split vs Cubit (tet vs hex), translation guidance
            "cubit_rosetta"   - Cubit `.jou` verb ↔ build123d mapping table
            "primitives_3d"   - Box, Cylinder, Cone, Sphere, Torus, Wedge + boolean
            "primitives_2d"   - Circle, Rectangle, Polygon, etc. (sketch objects)
            "operations"      - extrude, revolve, sweep, loft, fillet, mirror, split
            "curves"          - Line, Polyline, Spline, Arc types, Helix, Bezier
            "export_import"   - STEP, BREP, STL, glTF, SVG + CAE pipeline examples
            "topology"        - faces/edges/vertices queries, labels, selectors
            "cae_guidelines"  - Clean geometry rules, quality checks, label conventions
            "examples"        - IH coil, E-core transformer, dipole yoke, parametric
            "examples_intro"  - 36 introductory examples (Box/Cylinder -> loft/revolve/sweep)
            "examples_gallery"- 21 gallery examples (Benchy, Heat Exchanger, Vase, ...)
            "examples_lab_patterns" - Lab-specific: IH/Halbach/dipole/PEEC/maglev archetypes
            "coil_modeling"   - PEEC filament extraction from CAD
            "all"             - Complete documentation
    """
    return get_build123d_documentation(topic)


@mcp.tool()
def execute_build123d(
    script: str,
    export_dir: str = "",
    export_format: str = "step",
) -> str:
    """
    Execute a build123d Python script and return geometry information.

    The script should create build123d objects. The last Part, Sketch, or
    Compound assigned to a variable will be inspected and optionally exported.

    Args:
        script: Python code using build123d. Must be self-contained.
        export_dir: Directory for exported files. Empty string = no export.
        export_format: Export format: "step", "brep", or "stl".

    Returns:
        JSON with geometry info: validity, volume, area, face/edge counts,
        min edge length, bounding box, labels, and export path (if requested).
    """
    # Capture stdout
    old_stdout = sys.stdout
    sys.stdout = captured = StringIO()

    namespace = {}
    try:
        exec(  # noqa: S102
            "from build123d import *\n" + script,
            namespace,
        )
    except Exception as e:
        sys.stdout = old_stdout
        tb = traceback.format_exc()
        _fl.record_failure("build123d", {
            "input": script,
            "error": f"{type(e).__name__}: {e}",
            "traceback": tb[-1200:],
            "stdout": captured.getvalue()[-400:],
        })
        return json.dumps({
            "status": "error",
            "error": tb,
            "stdout": captured.getvalue(),
            "hint": _build123d_failure_hint(tb),
        }, indent=2)
    finally:
        sys.stdout = old_stdout

    stdout_text = captured.getvalue()

    # Find the last Shape-like object in namespace
    from build123d import Shape, Compound, Part, Sketch, Curve

    target = None
    target_name = None
    for name, obj in namespace.items():
        if name.startswith("_"):
            continue
        if isinstance(obj, Shape):
            target = obj
            target_name = name

    if target is None:
        return json.dumps({
            "status": "ok",
            "message": "Script executed but no Shape object found in namespace.",
            "stdout": stdout_text,
        }, indent=2)

    # Inspect geometry
    info = {
        "status": "ok",
        "variable": target_name,
        "type": type(target).__name__,
        "is_valid": target.is_valid,
        "label": target.label or "(none)",
    }

    try:
        info["volume"] = round(target.volume, 8)
    except Exception:
        info["volume"] = None

    try:
        info["area"] = round(target.area, 8)
    except Exception:
        info["area"] = None

    edges = target.edges()
    faces = target.faces()
    info["face_count"] = len(faces)
    info["edge_count"] = len(edges)
    info["vertex_count"] = len(target.vertices())

    if edges:
        edge_lengths = [e.length for e in edges]
        info["min_edge_length"] = round(min(edge_lengths), 8)
        info["max_edge_length"] = round(max(edge_lengths), 8)

    try:
        bb = target.bounding_box()
        info["bounding_box"] = {
            "min": [round(bb.min.X, 6), round(bb.min.Y, 6), round(bb.min.Z, 6)],
            "max": [round(bb.max.X, 6), round(bb.max.Y, 6), round(bb.max.Z, 6)],
            "size": [round(s, 6) for s in bb.size],
        }
    except Exception:
        pass

    # CAE quality warnings
    warnings = []
    if edges:
        min_e = info.get("min_edge_length", 0)
        bb_size = info.get("bounding_box", {}).get("size", [1, 1, 1])
        char_len = max(bb_size) if bb_size else 1
        if char_len > 0 and min_e / char_len < 0.001:
            warnings.append(
                f"Micro-edge detected: {min_e:.2e} "
                f"(ratio {min_e/char_len:.2e} of characteristic length {char_len:.4f})"
            )
    if not target.is_valid:
        warnings.append("Shape is not valid — may cause meshing issues")
    if warnings:
        info["cae_warnings"] = warnings

    # Export if requested
    if export_dir:
        from build123d import export_step, export_brep, export_stl

        export_path = Path(export_dir)
        export_path.mkdir(parents=True, exist_ok=True)
        base_name = target.label if target.label else target_name
        fmt = export_format.lower().strip()

        if fmt == "step":
            fpath = export_path / f"{base_name}.step"
            export_step(target, str(fpath))
            info["exported"] = str(fpath)
        elif fmt == "brep":
            fpath = export_path / f"{base_name}.brep"
            export_brep(target, str(fpath))
            info["exported"] = str(fpath)
        elif fmt == "stl":
            fpath = export_path / f"{base_name}.stl"
            export_stl(target, str(fpath))
            info["exported"] = str(fpath)
        else:
            info["export_error"] = f"Unknown format: {fmt}"

    if stdout_text:
        info["stdout"] = stdout_text

    return json.dumps(info, indent=2)


@mcp.tool()
def preview_shape_in_cubit(script: str, label: str = "preview") -> str:
    """
    Run a build123d script and show the resulting Shape in the
    **persistent Cubit Viewer** (GUI window), replacing OCP CAD Viewer.

    Lab direction (2026-04-19): Cubit Viewer is the single CAD preview
    target — industrial-grade visualization / measurement. OCP CAD
    Viewer has been retired; Plan A's persistent Cubit GUI handles
    both AI-driven and user-interactive workflows in one window.

    Pipeline:
      1. exec the build123d script (like execute_build123d).
      2. Extract the last Shape found in the namespace.
      3. Export to a temp STEP file.
      4. Hand to the persistent Cubit session (`cubit_show`-equivalent);
         the daemon imports STEP into its live Cubit GUI window.
      5. Temp STEP is deleted by default (Cubit now owns the geometry).

    Performance:
      - First call: ~0.7-1.0 s (Cubit daemon cold-start) + STEP roundtrip
      - Subsequent calls: <1 s (daemon warm + STEP import ~0.5 s)

    Args:
        script: self-contained build123d Python code.
        label: label attached to the shape (used for STEP filename).

    Returns:
        JSON with shape stats (volume / bbox / faces / edges) plus the
        Cubit session response (per-command ok flags).
    """
    import sys as _sys
    import tempfile as _tf
    import traceback as _tb
    from io import StringIO
    from pathlib import Path as _P

    namespace = {}
    _buf = StringIO()
    _orig_stdout = sys.stdout
    sys.stdout = _buf
    try:
        exec(  # noqa: S102
            "from build123d import *\n" + script,
            namespace,
        )
    except Exception:
        sys.stdout = _orig_stdout
        return json.dumps({
            "status": "error",
            "stage": "script_exec",
            "error": _tb.format_exc(),
            "stdout": _buf.getvalue(),
        }, indent=2)
    finally:
        sys.stdout = _orig_stdout
    stdout_text = _buf.getvalue()

    from build123d import Shape, export_step

    target = None
    target_name = None
    for n, obj in namespace.items():
        if n.startswith("_"):
            continue
        if isinstance(obj, Shape):
            target, target_name = obj, n
    if target is None:
        return json.dumps({
            "status": "error",
            "stage": "extract",
            "error": "Script executed but no build123d Shape was found.",
            "stdout": stdout_text,
        }, indent=2)

    # Write to a temp STEP; Cubit daemon imports, then we clean up.
    tmp = _P(_tf.mkdtemp(prefix="b123d_to_cubit_"))
    step_path = tmp / f"{label}.step"
    try:
        export_step(target, str(step_path))
    except Exception:
        return json.dumps({
            "status": "error",
            "stage": "step_export",
            "error": _tb.format_exc(),
        }, indent=2)

    # Hand to Cubit viewer (lazy-start daemon).
    try:
        from radia_mcp.cubit import cubit_session as _cs
    except ImportError as e:
        return json.dumps({
            "status": "error",
            "stage": "cubit_import",
            "error": f"radia_mcp.cubit not available: {e}",
        }, indent=2)

    try:
        sess = _cs.CubitSession.get()
        sess.ensure_started()
    except _cs.CubitSessionError as e:
        return json.dumps({
            "status": "error",
            "stage": "cubit_session",
            "error": str(e),
            "hint": ("Is Coreform Cubit installed? Override path via "
                     "`CUBIT_BIN_DIR` env var or `set_cubit_bin_dir()`."),
        }, indent=2)

    step_fwd = str(step_path).replace("\\", "/")
    try:
        r = sess.call("cmd", [f'import step "{step_fwd}"'])
    except _cs.CubitSessionError as e:
        return json.dumps({
            "status": "error",
            "stage": "cubit_rpc",
            "error": str(e),
        }, indent=2)

    info = {
        "status": "ok",
        "stage": "shown_in_cubit",
        "viewer": "cubit_persistent_session",
        "label": label,
        "variable": target_name,
        "type": type(target).__name__,
        "is_valid": target.is_valid,
        "cubit_result": r,
    }
    try:
        info["volume"] = round(target.volume, 6)
    except Exception:
        info["volume"] = None
    try:
        info["face_count"] = len(target.faces())
        info["edge_count"] = len(target.edges())
    except Exception:
        pass
    try:
        bb = target.bounding_box()
        info["bounding_box"] = {
            "min": [round(bb.min.X, 4), round(bb.min.Y, 4), round(bb.min.Z, 4)],
            "max": [round(bb.max.X, 4), round(bb.max.Y, 4), round(bb.max.Z, 4)],
        }
    except Exception:
        pass
    if stdout_text:
        info["stdout"] = stdout_text

    # Temp STEP can be cleaned now — Cubit has imported it.
    try:
        step_path.unlink(missing_ok=True)
        tmp.rmdir()
    except OSError:
        pass

    return json.dumps(info, indent=2)


@mcp.tool()
def inspect_geometry(file_path: str) -> str:
    """
    Inspect a STEP or BREP file for CAE quality.

    Loads the geometry and reports: validity, volume, area, face/edge/vertex
    counts, minimum edge length, bounding box, and CAE quality warnings.

    Args:
        file_path: Path to .step or .brep file.

    Returns:
        JSON with geometry inspection results and CAE quality warnings.
    """
    p = Path(file_path)
    if not p.exists():
        return json.dumps({"status": "error", "error": f"File not found: {file_path}"})

    try:
        suffix = p.suffix.lower()
        if suffix in (".step", ".stp"):
            from build123d import import_step
            shape = import_step(str(p))
        elif suffix in (".brep",):
            from build123d import import_brep
            shape = import_brep(str(p))
        else:
            return json.dumps({
                "status": "error",
                "error": f"Unsupported format: {suffix}. Use .step or .brep",
            })
    except Exception:
        return json.dumps({
            "status": "error",
            "error": traceback.format_exc(),
        })

    info = {
        "status": "ok",
        "file": str(p),
        "type": type(shape).__name__,
        "is_valid": shape.is_valid,
        "label": shape.label or "(none)",
    }

    try:
        info["volume"] = round(shape.volume, 8)
    except Exception:
        info["volume"] = None

    try:
        info["area"] = round(shape.area, 8)
    except Exception:
        info["area"] = None

    edges = shape.edges()
    faces = shape.faces()
    info["face_count"] = len(faces)
    info["edge_count"] = len(edges)
    info["vertex_count"] = len(shape.vertices())

    if edges:
        edge_lengths = sorted([e.length for e in edges])
        info["min_edge_length"] = round(edge_lengths[0], 8)
        info["max_edge_length"] = round(edge_lengths[-1], 8)
        info["edge_length_histogram"] = {
            "p5": round(edge_lengths[max(0, len(edge_lengths) // 20)], 8),
            "p25": round(edge_lengths[len(edge_lengths) // 4], 8),
            "median": round(edge_lengths[len(edge_lengths) // 2], 8),
            "p75": round(edge_lengths[3 * len(edge_lengths) // 4], 8),
        }

    try:
        bb = shape.bounding_box()
        info["bounding_box"] = {
            "min": [round(bb.min.X, 6), round(bb.min.Y, 6), round(bb.min.Z, 6)],
            "max": [round(bb.max.X, 6), round(bb.max.Y, 6), round(bb.max.Z, 6)],
            "size": [round(s, 6) for s in bb.size],
        }
    except Exception:
        pass

    # CAE quality analysis
    warnings = []
    if edges:
        min_e = info["min_edge_length"]
        bb_size = info.get("bounding_box", {}).get("size", [1, 1, 1])
        char_len = max(bb_size) if bb_size else 1
        if char_len > 0 and min_e / char_len < 0.001:
            warnings.append(
                f"Micro-edge: {min_e:.2e} "
                f"(ratio {min_e/char_len:.2e})"
            )
        if min_e / char_len < 0.01:
            warnings.append(
                f"Short edge: {min_e:.2e} may require local mesh refinement"
            )
    if not shape.is_valid:
        warnings.append("Shape is not valid")

    # Per-face info (labels, area, center, normal)
    if faces:
        face_info = []
        for idx, face in enumerate(faces):
            fi = {"index": idx, "area": round(face.area, 6)}
            if face.label:
                fi["label"] = face.label
            try:
                c = face.center()
                fi["center"] = [round(c.X, 6), round(c.Y, 6), round(c.Z, 6)]
            except Exception:
                pass
            try:
                n = face.normal_at(face.center())
                fi["normal"] = [round(n.X, 6), round(n.Y, 6), round(n.Z, 6)]
            except Exception:
                pass
            face_info.append(fi)
        info["faces"] = face_info

    # Check for children/assembly structure
    try:
        children = shape.children
        if children:
            info["children"] = []
            for child in children:
                child_info = {
                    "label": child.label or "(none)",
                    "type": type(child).__name__,
                }
                try:
                    child_info["volume"] = round(child.volume, 8)
                except Exception:
                    pass
                try:
                    child_info["face_count"] = len(child.faces())
                except Exception:
                    pass
                info["children"].append(child_info)
    except Exception:
        pass

    if warnings:
        info["cae_warnings"] = warnings

    return json.dumps(info, indent=2)


@mcp.tool()
def section_along_path(
    file_path: str,
    path_json: str,
    n_sections: int = 0,
) -> str:
    """
    Section a STEP/BREP coil solid along a discrete path and extract
    per-segment cross-section dimensions.

    Given a solid and a centerline path (list of [x, y, z] points in
    the same units as the CAD file, typically mm), the tool:
    1. Computes segment midpoints and tangent vectors
    2. Sections the solid perpendicular to the tangent at each midpoint
    3. Picks the face closest to the path center (multi-turn safe)
    4. Returns area, estimated width/height per segment

    This is the CAD-side half of the PEEC filament extraction pipeline.
    Feed the output into PEECBuilder.add_connected_segment() with
    the per-segment (w, h) values (convert to meters if CAD is in mm).

    Args:
        file_path: Path to .step or .brep file.
        path_json: JSON string encoding a list of [x, y, z] path points
            (N+1 points for N segments), in CAD units (typically mm).
            Example: "[[50,0,0],[0,50,4],[-50,0,8],[0,-50,12],[50,0,16]]"
        n_sections: If > 0, resample path to this many equidistant
            segments before sectioning.  0 = use path points as-is.

    Returns:
        JSON with per-segment: index, midpoint, area, w_est, h_est,
        plus a summary of the taper range.
    """
    import math
    import numpy as np

    p = Path(file_path)
    if not p.exists():
        return json.dumps({"status": "error", "error": f"File not found: {file_path}"})

    try:
        pts = json.loads(path_json)
    except Exception:
        return json.dumps({"status": "error", "error": "path_json is not valid JSON"})

    pts = np.array(pts, dtype=np.float64)
    if pts.ndim != 2 or pts.shape[1] != 3 or pts.shape[0] < 2:
        return json.dumps({
            "status": "error",
            "error": f"path must be (N, 3) with N >= 2, got shape {pts.shape}",
        })

    # Optional resample
    if n_sections > 0 and n_sections != pts.shape[0] - 1:
        from scipy.interpolate import interp1d
        cum = np.zeros(len(pts))
        for i in range(1, len(pts)):
            cum[i] = cum[i - 1] + np.linalg.norm(pts[i] - pts[i - 1])
        t_orig = cum / cum[-1]
        t_new = np.linspace(0, 1, n_sections + 1)
        pts = np.column_stack([
            interp1d(t_orig, pts[:, k], kind="cubic")(t_new)
            for k in range(3)
        ])

    n_seg = pts.shape[0] - 1
    midpoints = 0.5 * (pts[:-1] + pts[1:])
    diffs = np.diff(pts, axis=0)
    norms = np.linalg.norm(diffs, axis=1, keepdims=True)
    norms = np.maximum(norms, 1e-30)
    tangents = diffs / norms

    # Load solid
    suffix = p.suffix.lower()
    try:
        if suffix in (".step", ".stp"):
            from build123d import import_step
            solid = import_step(str(p))
        else:
            from build123d import import_brep
            solid = import_brep(str(p))
    except Exception:
        return json.dumps({"status": "error", "error": traceback.format_exc()})

    from build123d import section, Plane, Vector

    segments = []
    for i in range(n_seg):
        c = midpoints[i]
        t = tangents[i]
        origin = Vector(float(c[0]), float(c[1]), float(c[2]))
        z_dir = Vector(float(t[0]), float(t[1]), float(t[2]))
        sec_plane = Plane(origin=origin, z_dir=z_dir)
        try:
            cross = section(solid, section_by=sec_plane)
        except Exception:
            segments.append({"index": i, "error": "section failed"})
            continue

        if not cross or len(cross.faces()) == 0:
            segments.append({"index": i, "error": "no faces"})
            continue

        best_face = min(cross.faces(),
                        key=lambda f: (f.center() - origin).length)
        area = best_face.area
        side = math.sqrt(area)
        seg_len = float(norms[i, 0])

        segments.append({
            "index": i,
            "midpoint": [round(c[0], 6), round(c[1], 6), round(c[2], 6)],
            "length": round(seg_len, 6),
            "area": round(area, 6),
            "w_est": round(side, 6),
            "h_est": round(side, 6),
        })

    areas = [s["area"] for s in segments if "area" in s]
    ws = [s["w_est"] for s in segments if "w_est" in s]
    summary = {
        "n_segments": n_seg,
        "n_ok": len(areas),
        "area_range": [round(min(areas), 4), round(max(areas), 4)] if areas else None,
        "w_range": [round(min(ws), 4), round(max(ws), 4)] if ws else None,
    }

    return json.dumps({"status": "ok", "summary": summary, "segments": segments}, indent=2)


@mcp.tool()
def generate_helix_coil(
    radius: float = 50.0,
    pitch: float = 10.0,
    n_turns: float = 5.0,
    w_start: float = 4.0,
    h_start: float = 4.0,
    w_end: float = 4.0,
    h_end: float = 4.0,
    sections_per_turn: int = 12,
    export_dir: str = "",
    label: str = "helix_coil",
) -> str:
    """
    Generate a helical coil with optional cross-section taper.

    Creates a solid coil by lofting rectangular cross-sections along a
    helix path.  Cross-section dimensions interpolate linearly from
    (w_start, h_start) at the bottom to (w_end, h_end) at the top.

    All dimensions are in the CAD working units (typically mm).

    For PEEC filament extraction, use section_along_path() on the
    exported file with the helix centerline path.

    Args:
        radius: Helix radius (center of wire to axis).
        pitch: Axial advance per turn.
        n_turns: Number of turns (can be fractional).
        w_start: Cross-section width at bottom.
        h_start: Cross-section height at bottom.
        w_end: Cross-section width at top.
        h_end: Cross-section height at top.
        sections_per_turn: Loft sections per turn (12 = 30 deg each).
        export_dir: Directory for STEP export (empty = no export).
        label: Name for the solid and export filename.

    Returns:
        JSON with geometry info (volume, area, bbox) and the helix
        path as a list of [x, y, z] points (for section_along_path).
    """
    import math
    from build123d import (BuildSketch, Rectangle, Plane, Vector, loft,
                           export_step)

    n_sec = int(n_turns * sections_per_turn) + 1
    height = pitch * n_turns
    sketches = []
    path_pts = []

    for i in range(n_sec):
        t = i / (n_sec - 1) if n_sec > 1 else 0
        angle = 2 * math.pi * n_turns * t
        z = height * t
        cx = radius * math.cos(angle)
        cy = radius * math.sin(angle)
        w = w_start + (w_end - w_start) * t
        h = h_start + (h_end - h_start) * t

        dx = -radius * math.sin(angle) * 2 * math.pi * n_turns
        dy = radius * math.cos(angle) * 2 * math.pi * n_turns
        dz = height
        norm = math.sqrt(dx**2 + dy**2 + dz**2)
        tangent = (dx / norm, dy / norm, dz / norm)

        # Cross-section perpendicular to helix tangent
        x_dir_raw = (tangent[1], -tangent[0], 0)
        x_norm = math.sqrt(x_dir_raw[0]**2 + x_dir_raw[1]**2)
        if x_norm < 1e-10:
            x_dir_raw = (1, 0, 0)
            x_norm = 1.0
        x_dir = (x_dir_raw[0] / x_norm, x_dir_raw[1] / x_norm, 0)

        plane = Plane(origin=(cx, cy, z), x_dir=x_dir, z_dir=tangent)
        with BuildSketch(plane) as sk:
            Rectangle(w, h)
        sketches.append(sk.sketch)
        path_pts.append([round(cx, 6), round(cy, 6), round(z, 6)])

    coil = loft(sketches)
    coil.label = label

    info = {
        "status": "ok",
        "label": label,
        "n_turns": n_turns,
        "radius": radius,
        "pitch": pitch,
        "cross_section_start": [w_start, h_start],
        "cross_section_end": [w_end, h_end],
        "is_valid": coil.is_valid,
        "volume": round(coil.volume, 4),
        "face_count": len(coil.faces()),
        "edge_count": len(coil.edges()),
    }

    try:
        bb = coil.bounding_box()
        info["bounding_box"] = {
            "min": [round(bb.min.X, 4), round(bb.min.Y, 4), round(bb.min.Z, 4)],
            "max": [round(bb.max.X, 4), round(bb.max.Y, 4), round(bb.max.Z, 4)],
        }
    except Exception:
        pass

    info["path_points"] = path_pts

    if export_dir:
        export_path = Path(export_dir)
        export_path.mkdir(parents=True, exist_ok=True)
        fpath = export_path / f"{label}.step"
        export_step(coil, str(fpath))
        info["exported"] = str(fpath)

    return json.dumps(info, indent=2)


# ============================================================
# MCP Prompts
# ============================================================

@mcp.prompt()
def new_cae_geometry(geometry_type: str = "ih_coil") -> str:
    """Create a new CAE geometry with build123d."""
    base = (
        "Create a CAE-ready geometry using build123d.\n\n"
        "Use build123d_usage tool for API reference.\n\n"
        "Workflow:\n"
        "1. Create geometry with primitives + boolean (build123d_usage('primitives_3d'))\n"
        "2. Assign labels for material regions (build123d_usage('topology'))\n"
        "3. Validate: check is_valid, min edge length (build123d_usage('cae_guidelines'))\n"
        "4. Export BREP (for Netgen) or STEP (for Cubit)\n"
        "5. Use execute_build123d tool to run and validate\n\n"
    )

    geo = geometry_type.strip().lower()

    if geo in ("ih", "ih_coil", "induction_heating"):
        base += (
            "Induction Heating model:\n"
            "- Cylindrical workpiece (steel) + surrounding coil (copper)\n"
            "- Air domain enclosing both\n"
            "- Label: 'workpiece', 'coil', 'air'\n"
            "- See build123d_usage('examples') for complete code\n"
        )
    elif geo in ("transformer", "e_core", "ecore"):
        base += (
            "E-core Transformer:\n"
            "- E-shaped iron core (parametric: width, height, leg thickness)\n"
            "- Winding regions around center and/or outer legs\n"
            "- Label: 'iron_core', 'winding_primary', 'winding_secondary'\n"
            "- See build123d_usage('examples') for e_core function\n"
        )
    elif geo in ("dipole", "magnet", "accelerator"):
        base += (
            "Accelerator Dipole Magnet (quarter model):\n"
            "- Quarter-annular yoke (symmetry exploitation)\n"
            "- Bore region for beam pipe\n"
            "- Label: 'iron_yoke', 'bore', 'air'\n"
            "- See build123d_usage('examples') for yoke code\n"
        )
    else:
        base += (
            f"Custom geometry type: {geometry_type}\n"
            "- Start with build123d_usage('overview') for CAE-safe subset\n"
            "- Use primitives + boolean for clean geometry\n"
            "- Validate with execute_build123d before meshing\n"
        )

    return base


# ============================================================
# Convenience tools — common shapes routed straight to Cubit
# ============================================================
#
# 2026-04-19: `preview_shape_in_cubit` already handles the build123d →
# STEP → Cubit pipeline, but writing the build123d script every time
# for simple shapes (text, extrude, boolean) is noisy for the LLM /
# user.  These helpers produce the script internally and delegate.

def _hand_to_cubit(part_script: str, label: str) -> str:
    """Internal: run a build123d snippet, export STEP, send to Cubit.

    Reuses the full `preview_shape_in_cubit` path. Returns its JSON
    verbatim so callers can forward directly.
    """
    return preview_shape_in_cubit(script=part_script, label=label)


@mcp.tool()
def preview_text(text: str, font_size: float = 30.0,
                 thickness: float = 5.0,
                 font: str = "") -> str:
    """Generate 3D extruded text and send it to the live Cubit viewer.

    Builds a build123d `Text` sketch at `font_size`, extrudes by
    `thickness`, exports STEP, and delegates to Cubit. Each letter
    becomes its own prismatic volume — ideal for demonstrating hex
    meshing via `scheme auto` / `scheme sweep`.

    Args:
        text: the string to render. ASCII works reliably; Unicode depends
            on the font.
        font_size: text height (build123d units, typically mm).
        thickness: extrusion depth along Z.
        font: optional font family name (e.g., "Arial", "Times New Roman").
            Empty uses build123d's platform default.

    Returns the same JSON shape as `preview_shape_in_cubit`.
    """
    safe = text.replace("\\", "\\\\").replace('"', '\\"')
    font_line = f', font="{font}"' if font else ""
    # Expose the resulting Shape as a top-level name so preview_shape_in_cubit's
    # namespace scan ("isinstance(obj, Shape)") picks it up.
    script = (
        "with BuildPart() as _bp:\n"
        "    with BuildSketch():\n"
        f'        Text("{safe}", font_size={float(font_size)}{font_line}, '
        "align=(Align.CENTER, Align.CENTER))\n"
        f"    extrude(amount={float(thickness)})\n"
        "part = _bp.part\n"
    )
    return _hand_to_cubit(script, label=f"text_{safe[:16].replace(' ', '_')}")


@mcp.tool()
def preview_extrude(sketch_code: str, amount: float = 10.0,
                    label: str = "extrude") -> str:
    """Extrude a build123d sketch by `amount` and show in Cubit.

    You provide just the sketch body (the code that goes inside a
    `with BuildSketch():` block), this tool wraps it with BuildPart /
    BuildSketch / extrude and sends the result through.

    Args:
        sketch_code: lines placed inside `with BuildSketch():`. E.g.,
            "Circle(radius=5); Rectangle(10,5)".
        amount: extrusion depth (build123d units).
        label: name attached to the shape.

    Example:
        preview_extrude("Rectangle(20, 10); fillet=Rectangle(2, 2)",
                        amount=5.0)
    """
    # Indent user body inside the with-block.
    body_lines = sketch_code.splitlines() or [sketch_code]
    indented = "\n".join("        " + line.strip() if line.strip() else ""
                         for line in body_lines)
    script = (
        "with BuildPart() as _bp:\n"
        "    with BuildSketch():\n"
        f"{indented}\n"
        f"    extrude(amount={float(amount)})\n"
        "part = _bp.part\n"
    )
    return _hand_to_cubit(script, label=label)


@mcp.tool()
def preview_boolean(op: str, a_script: str, b_script: str,
                    label: str = "boolean") -> str:
    """Perform a boolean (union/subtract/intersect) of two build123d
    snippets and send the result to Cubit.

    Args:
        op: "union" / "subtract" / "intersect".
        a_script: build123d code producing the first part (must assign
            to `a`).  E.g., "a = Box(10, 10, 10)".
        b_script: same for second part, assigning to `b`.
        label: name attached to the shape.

    Example:
        preview_boolean(
            "subtract",
            "a = Box(20, 20, 20)",
            "b = Cylinder(radius=5, height=25)",
        )
    """
    op_map = {
        "union": "+",
        "subtract": "-",
        "minus": "-",
        "intersect": "&",
        "intersection": "&",
    }
    sym = op_map.get(op.strip().lower())
    if sym is None:
        return json.dumps({
            "status": "error",
            "stage": "op",
            "error": f"unknown op {op!r}; use union / subtract / intersect",
        })
    script = (
        f"{a_script.strip()}\n"
        f"{b_script.strip()}\n"
        f"part = a {sym} b\n"
    )
    return _hand_to_cubit(script, label=label)


# ============================================================
# Retrieval + web docs + failure log
# ============================================================

import math as _math
import re as _re

_STOP_WORDS = frozenset({
    "the", "a", "an", "of", "to", "in", "and", "or", "is", "are", "be",
    "on", "at", "for", "with", "as", "by", "from", "that", "this",
    "it", "its", "if", "so", "how", "what", "which", "when", "where",
})
_WORD_RE = _re.compile(r"[a-zA-Z_][a-zA-Z0-9_]*")


def _tokenize(s: str) -> list[str]:
    return [m.group(0).lower() for m in _WORD_RE.finditer(s)]


def _chunk_by_heading(text: str, target_lines: int = 40) -> list[tuple[int, str]]:
    """Same heading-anchored chunker as the cubit server."""
    lines = text.splitlines()
    chunks: list[tuple[int, str]] = []
    cur_start = 0
    cur: list[str] = []
    for i, line in enumerate(lines):
        is_heading = (line.startswith("# ") or line.startswith("## ")
                      or line.startswith("### "))
        if is_heading and cur and (i - cur_start) >= max(5, target_lines // 4):
            chunks.append((cur_start + 1, "\n".join(cur)))
            cur = []
            cur_start = i
        cur.append(line)
        if len(cur) >= target_lines * 2:
            chunks.append((cur_start + 1, "\n".join(cur)))
            cur = []
            cur_start = i + 1
    if cur:
        chunks.append((cur_start + 1, "\n".join(cur)))
    return chunks


def _heading_of(chunk: str) -> str:
    for line in chunk.splitlines():
        s = line.strip()
        if s:
            return s
    return ""


_B3D_KNOWLEDGE_TOPICS = [
    "overview", "primitives_3d", "primitives_2d", "operations",
    "curves", "export_import", "topology", "cae_guidelines",
    "examples", "coil_modeling",
]


def _b3d_build_corpus() -> list[dict]:
    if getattr(_b3d_build_corpus, "_cache", None) is not None:
        return _b3d_build_corpus._cache  # type: ignore[attr-defined]
    corpus: list[dict] = []
    for topic in _B3D_KNOWLEDGE_TOPICS:
        try:
            text = get_build123d_documentation(topic)
        except Exception:
            continue
        if not text:
            continue
        for start, chunk in _chunk_by_heading(text):
            tokens = _tokenize(chunk)
            if not tokens:
                continue
            corpus.append({
                "source": f"kb:{topic}",
                "start_line": start,
                "chunk": chunk,
                "heading": _heading_of(chunk),
                "tokens": tokens,
                "token_set": set(tokens),
            })
    # Failure log as extra source
    failures_text = _fl.failures_as_text("build123d", limit=50)
    if failures_text:
        for start, chunk in _chunk_by_heading(failures_text):
            tokens = _tokenize(chunk)
            if not tokens:
                continue
            corpus.append({
                "source": "failures",
                "start_line": start,
                "chunk": chunk,
                "heading": _heading_of(chunk),
                "tokens": tokens,
                "token_set": set(tokens),
            })
    _b3d_build_corpus._cache = corpus  # type: ignore[attr-defined]
    return corpus


def _score_tfidf(query_terms: list[str], doc: dict, idf: dict[str, float]) -> float:
    tokens = doc["tokens"]
    if not tokens:
        return 0.0
    tf: dict[str, int] = {}
    for tok in tokens:
        tf[tok] = tf.get(tok, 0) + 1
    inv_len = 1.0 / (1.0 + _math.log(1 + len(tokens)))
    score = 0.0
    hits = 0
    for term in query_terms:
        f = tf.get(term, 0)
        if f == 0:
            continue
        hits += 1
        score += (1.0 + _math.log(f)) * idf.get(term, 1.0) * inv_len
    if hits == 0:
        return 0.0
    head_lc = doc["heading"].lower()
    head_hits = sum(1 for t in query_terms if t in head_lc)
    if head_hits:
        score *= 1.0 + 0.75 * head_hits
    score *= 1.0 + 0.25 * (hits / max(1, len(query_terms)))
    return score


@mcp.tool()
def build123d_lookup(query: str, max_results: int = 5) -> str:
    """Retrieve relevant sections from the bundled build123d knowledge +
    failure log, scored by tf-idf with heading boost.

    Complements `build123d_usage(topic=...)` (full topic dump) by letting
    the LLM query with free-form keywords (e.g., "extrude until face",
    "loft profiles", "Plane rotation").

    Args:
        query: keywords (AND-scored).
        max_results: cap on returned chunks.
    """
    q = (query or "").strip()
    if not q:
        return json.dumps({"status": "error", "error": "empty query"})
    terms = [t for t in _tokenize(q) if t not in _STOP_WORDS]
    if not terms:
        return json.dumps({"status": "error",
                            "error": "no searchable terms (all stop words?)"})
    corpus = _b3d_build_corpus()
    n = max(1, len(corpus))
    idf = {
        t: _math.log((n + 1) / (sum(1 for d in corpus if t in d["token_set"]) + 1)) + 1.0
        for t in terms
    }
    scored: list[tuple[float, dict]] = []
    for doc in corpus:
        s = _score_tfidf(terms, doc, idf)
        if s > 0:
            scored.append((s, doc))
    scored.sort(key=lambda x: (-x[0], x[1]["source"], x[1]["start_line"]))
    top = scored[: max(1, int(max_results))]
    return json.dumps({
        "status": "ok",
        "query": q,
        "terms": terms,
        "candidates_total": len(scored),
        "returned": len(top),
        "results": [
            {
                "source": d["source"],
                "start_line": d["start_line"],
                "heading": d["heading"][:120],
                "score": round(s, 3),
                "chunk": d["chunk"],
            }
            for s, d in top
        ],
    }, indent=2)


@mcp.tool()
def build123d_recent_failures(limit: int = 10) -> str:
    """Return the last N failed `execute_build123d` invocations (from log)."""
    recs = _fl.recent_failures("build123d", limit=limit)
    return json.dumps({
        "status": "ok",
        "count": len(recs),
        "log_path": str(_fl._log_path("build123d")),
        "entries": recs,
    }, indent=2)


@mcp.tool()
def build123d_web_docs(query: str, max_hits: int = 5,
                       force_refresh: bool = False) -> str:
    """Fetch live build123d documentation (readthedocs) and grep for `query`.

    Complements `build123d_lookup` when a symbol is missing from the
    bundled kb or you need the authoritative API signature. Pages are
    cached for 24 h.

    Args:
        query: keywords (AND-matched, case-insensitive).
        max_hits: cap on matching lines across all indexed pages.
        force_refresh: bypass cache and re-fetch.
    """
    q = (query or "").strip()
    if not q:
        return json.dumps({"status": "error", "error": "empty query"})
    urls = _wd.DOCS_INDEX.get("build123d", [])
    all_hits: list[dict] = []
    errors: list[dict] = []
    remaining = max(1, int(max_hits))
    for url in urls:
        if remaining <= 0:
            break
        data = _wd.fetch(url, force_refresh=force_refresh)
        if data.get("status") != "ok":
            errors.append({"url": url, "error": data.get("error")})
            continue
        hits = _wd.search_text(data["text"], q, max_hits=remaining)
        if hits:
            for h in hits:
                h["url"] = data["url"]
                h["from_cache"] = data.get("from_cache", False)
                all_hits.append(h)
            remaining -= len(hits)
    return json.dumps({
        "status": "ok",
        "query": q,
        "hits": all_hits,
        "errors": errors,
    }, indent=2)


@mcp.tool()
def build123d_examples(query: str, limit: int = 3,
                       force_refresh: bool = False) -> str:
    """Search build123d + **bd_warehouse** Python examples (unioned).

    Two sources, one query:
      1. **`gumyr/build123d/examples/`** (~65 scripts: bicycle tire,
         Benchy, fillets, lofts, joints, roller coaster, vase, ...).
      2. **`gumyr/bd_warehouse`** (industrial parts lib: `bearing`,
         `fastener`, `flange`, `gear`, `open_builds`, `pipe`,
         `sprocket`) — fills gaps build123d itself doesn't cover
         (e.g., "gear involute" lives here, not in core examples).

    Both fetched via GitHub API; 7-day cache. Hits carry `source` so
    you can tell them apart.

    Args:
        query: keywords (e.g., "helix sweep", "gear involute",
            "bearing", "loft profile").
        limit: cap on returned examples.
        force_refresh: re-scrape both GitHub sources.
    """
    r = _ex.search_examples("build123d", query, limit=limit,
                             force_refresh=force_refresh)
    return json.dumps(r, indent=2, ensure_ascii=False)


@mcp.tool()
def build123d_examples_refresh(limit: int = 0) -> str:
    """Force-refresh both build123d sources from GitHub (core examples
    + bd_warehouse). `limit=0` fetches everything."""
    main = _ex.refresh_build123d_examples(limit=limit)
    warehouse = _ex.refresh_bd_warehouse_examples()
    return json.dumps({"build123d": main, "bd_warehouse": warehouse},
                      indent=2, ensure_ascii=False)


# ============================================================
# CadQuery interop (OCCT sibling — shared STEP boundary)
# ============================================================

def _find_cadquery_shape(namespace: dict):
    """Extract the last cadquery Shape-like object from an exec'd namespace.

    Priority:
      1. a `result` variable (cadquery convention for Workplane.val())
      2. the last `Workplane` assigned
      3. the last `Shape`/`Solid`/`Compound`
    """
    try:
        import cadquery as cq
    except ImportError:
        return None, "cadquery not installed"
    target = None
    target_name = None
    # 1. `result` wins (cadquery-cli convention)
    if "result" in namespace:
        target = namespace["result"]
        target_name = "result"
    else:
        # 2 + 3. scan for last Workplane / Shape
        for name, obj in namespace.items():
            if name.startswith("_"):
                continue
            if isinstance(obj, (cq.Workplane,)):
                target = obj
                target_name = name
            elif hasattr(cq, "Shape") and isinstance(obj, cq.Shape):
                target = obj
                target_name = name
    if target is None:
        return None, "no cadquery Workplane or Shape found in script namespace"
    # Normalize Workplane → underlying Compound / Solid
    if hasattr(target, "val") and hasattr(target, "vals"):
        vals = target.vals()
        if not vals:
            return None, "Workplane is empty"
        if len(vals) == 1:
            return (vals[0], target_name), None
        # Multiple shapes — combine into a Compound
        return (cq.Compound.makeCompound(vals), target_name), None
    return (target, target_name), None


@mcp.tool()
def execute_cadquery(script: str,
                     export_dir: str = "",
                     export_format: str = "step") -> str:
    """Execute a **CadQuery** Python script (sibling OCCT CAD lib).

    Enables interop with the broader CadQuery community and with
    `cadquery-mcp` (rishigundakaram/cadquery-mcp-server): AI can
    author or fetch CadQuery scripts and route them through our
    Radia pipeline without hand-porting to build123d.

    Scripts run with `from cadquery import *` prepended. By convention
    they assign the final geometry to `result` (plain Workplane or
    Shape). Falls back to "last Workplane/Shape in namespace" if
    `result` isn't set.

    Returns the same geometry-info shape as `execute_build123d`
    (validity, volume, area, face/edge/vertex counts, bounding box,
    min edge length, CAE warnings) so downstream tools don't care
    which backend authored the shape.

    Args:
        script: Python code using cadquery. Self-contained.
        export_dir: optional directory for STEP/BREP/STL export
            (empty = no export).
        export_format: "step" / "brep" / "stl".
    """
    try:
        import cadquery as cq
    except ImportError:
        return json.dumps({
            "status": "error",
            "error": ("cadquery not installed. Install with "
                      "`pip install radia-mcp[cadquery]` or "
                      "`pip install cadquery`."),
        }, indent=2)

    old_stdout = sys.stdout
    sys.stdout = captured = StringIO()

    namespace = {}
    try:
        exec(  # noqa: S102
            "from cadquery import *\n" + script,
            namespace,
        )
    except Exception as e:
        sys.stdout = old_stdout
        tb = traceback.format_exc()
        _fl.record_failure("cadquery", {
            "input": script,
            "error": f"{type(e).__name__}: {e}",
            "traceback": tb[-1200:],
            "stdout": captured.getvalue()[-400:],
        })
        return json.dumps({
            "status": "error",
            "error": tb,
            "stdout": captured.getvalue(),
            "hint": "Check imports (cadquery exposes `Workplane`, `cq` module, etc.)",
        }, indent=2)
    finally:
        sys.stdout = old_stdout

    stdout_text = captured.getvalue()

    found, err = _find_cadquery_shape(namespace)
    if found is None:
        return json.dumps({
            "status": "ok" if err is None else "error",
            "message": err or "no shape found",
            "stdout": stdout_text,
        }, indent=2)
    target, target_name = found

    info = {
        "status": "ok",
        "variable": target_name,
        "type": type(target).__name__,
    }
    try:
        info["is_valid"] = bool(target.isValid())
    except Exception:
        info["is_valid"] = None
    try:
        info["volume"] = round(target.Volume(), 8)
    except Exception:
        info["volume"] = None
    try:
        info["area"] = round(target.Area(), 8)
    except Exception:
        info["area"] = None
    try:
        faces = target.Faces()
        edges = target.Edges()
        info["face_count"] = len(faces)
        info["edge_count"] = len(edges)
        info["vertex_count"] = len(target.Vertices())
        if edges:
            lens = [e.Length() for e in edges]
            info["min_edge_length"] = round(min(lens), 8)
            info["max_edge_length"] = round(max(lens), 8)
    except Exception:
        pass
    try:
        bb = target.BoundingBox()
        info["bounding_box"] = {
            "min": [round(bb.xmin, 6), round(bb.ymin, 6), round(bb.zmin, 6)],
            "max": [round(bb.xmax, 6), round(bb.ymax, 6), round(bb.zmax, 6)],
            "size": [round(bb.xlen, 6), round(bb.ylen, 6), round(bb.zlen, 6)],
        }
    except Exception:
        pass

    # CAE quality warnings — same logic as execute_build123d
    warnings = []
    if info.get("min_edge_length"):
        bb_size = info.get("bounding_box", {}).get("size", [1, 1, 1])
        char_len = max(bb_size) if bb_size else 1
        min_e = info["min_edge_length"]
        if char_len > 0 and min_e / char_len < 0.001:
            warnings.append(
                f"Micro-edge detected: {min_e:.2e} "
                f"(ratio {min_e/char_len:.2e} of characteristic length {char_len:.4f})"
            )
    if info.get("is_valid") is False:
        warnings.append("Shape is not valid — may cause meshing issues")
    if warnings:
        info["cae_warnings"] = warnings

    # Export
    if export_dir:
        export_path = Path(export_dir)
        export_path.mkdir(parents=True, exist_ok=True)
        base_name = target_name
        fmt = export_format.lower().strip()
        try:
            if fmt == "step":
                fpath = export_path / f"{base_name}.step"
                target.exportStep(str(fpath))
                info["exported"] = str(fpath)
            elif fmt == "brep":
                fpath = export_path / f"{base_name}.brep"
                target.exportBrep(str(fpath))
                info["exported"] = str(fpath)
            elif fmt == "stl":
                fpath = export_path / f"{base_name}.stl"
                target.exportStl(str(fpath))
                info["exported"] = str(fpath)
            else:
                info["export_error"] = f"Unknown format: {fmt}"
        except Exception as e:
            info["export_error"] = f"{type(e).__name__}: {e}"

    if stdout_text:
        info["stdout"] = stdout_text

    return json.dumps(info, indent=2)


@mcp.tool()
def cadquery_to_cubit_hex(script: str,
                          target_size: float = 1.0,
                          prefer: str = "hex",
                          commit_to_gui: bool = True,
                          timeout_s: int = 600) -> str:
    """End-to-end: cadquery script → STEP → Cubit `cubit_mesh_auto`
    (batch-validated scheme ladder → winning recipe replayed in GUI).

    One call, three libraries, one output. Intended for the flow:
    "I have a cadquery geometry (from cadquery-mcp, a community
    gist, or my own script) — hex-mesh it and show me in Cubit."

    Args:
        script: cadquery script that assigns the final shape to
            `result` (or leaves one Workplane/Shape in the namespace).
        target_size: mesh element size (passed to `volume all size`).
        prefer: "hex" (require hex>0 to accept) or "any".
        commit_to_gui: replay winning recipe in the live Cubit GUI.
        timeout_s: per-rung timeout for the mesh-auto ladder.

    Returns:
        JSON with cadquery info (validity/volume/bbox) + STEP path +
        cubit_mesh_auto result (attempts ladder + winner + GUI replay).
    """
    try:
        import cadquery as cq  # noqa: F401
    except ImportError:
        return json.dumps({"status": "error",
                           "error": "cadquery not installed"}, indent=2)

    import tempfile
    tmp_dir = Path(tempfile.mkdtemp(prefix="cq_to_cubit_"))
    # Step 1: run cadquery → STEP
    cq_info_raw = execute_cadquery(script=script,
                                    export_dir=str(tmp_dir),
                                    export_format="step")
    cq_info = json.loads(cq_info_raw)
    if cq_info.get("status") != "ok" or "exported" not in cq_info:
        return json.dumps({
            "status": "error",
            "stage": "cadquery",
            "cadquery": cq_info,
        }, indent=2)

    step_path = cq_info["exported"].replace("\\", "/")

    # Step 2: hand off to cubit_mesh_auto (imported lazily — keeps
    # build123d server standalone if user installs without cubit)
    try:
        from ..cubit.server import cubit_mesh_auto
    except ImportError as e:
        return json.dumps({
            "status": "error",
            "stage": "cubit_import",
            "error": str(e),
            "cadquery": cq_info,
            "step_path": step_path,
        }, indent=2)

    mesh_raw = cubit_mesh_auto(step_path=step_path,
                                target_size=target_size,
                                prefer=prefer,
                                commit_to_gui=commit_to_gui,
                                timeout_s=timeout_s)
    mesh_info = json.loads(mesh_raw)
    return json.dumps({
        "status": mesh_info.get("status", "ok"),
        "cadquery": {
            k: cq_info[k] for k in
            ("is_valid", "volume", "face_count", "edge_count",
             "bounding_box", "cae_warnings")
            if k in cq_info
        },
        "step_path": step_path,
        "cubit_mesh_auto": mesh_info,
    }, indent=2)


# ============================================================
# Entry point
# ============================================================

def main():
    if "--selftest" in sys.argv:
        print("build123d MCP server self-test:")

        # Test knowledge base topics
        topics = [
            "overview", "primitives_3d", "primitives_2d", "operations",
            "curves", "export_import", "topology", "cae_guidelines",
            "examples", "coil_modeling",
        ]
        for t in topics:
            result = build123d_usage(t)
            print(f"  build123d_usage('{t}'): {len(result)} chars")
            assert len(result) > 100, f"Topic '{t}' too short"

        # Test execute
        result = execute_build123d("box = Box(10, 20, 30)")
        print(f"  execute_build123d('Box(10,20,30)'): {len(result)} chars")
        import json as _json
        data = _json.loads(result)
        assert data["status"] == "ok", f"Execute failed: {data}"
        assert data["is_valid"], "Box should be valid"
        assert abs(data["volume"] - 6000.0) < 1, f"Volume wrong: {data['volume']}"

        # Test generate_helix_coil
        result = generate_helix_coil(radius=30, pitch=8, n_turns=2,
                                     w_start=3, h_start=3, w_end=2, h_end=2,
                                     sections_per_turn=8)
        data = _json.loads(result)
        print(f"  generate_helix_coil: volume={data.get('volume')}, "
              f"path_pts={len(data.get('path_points', []))}")
        assert data["status"] == "ok", f"generate_helix_coil failed: {data}"
        assert data["is_valid"], "Helix coil should be valid"
        assert data["volume"] > 0, "Volume should be positive"
        assert len(data["path_points"]) > 10, "Path should have points"

        # Test prompt
        prompt = new_cae_geometry("ih_coil")
        print(f"  new_cae_geometry('ih_coil'): {len(prompt)} chars")
        assert "workpiece" in prompt

        print("  PASSED")
        return

    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
