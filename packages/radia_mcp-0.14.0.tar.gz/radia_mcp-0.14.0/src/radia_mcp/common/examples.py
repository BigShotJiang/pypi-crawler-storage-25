"""Scraped example library for build123d + Cubit.

Two sources, two layouts:

* **build123d** — GitHub `gumyr/build123d/examples/` (~65 curated Python
  files).  Listing via `api.github.com/repos/.../contents/examples`,
  bodies via `raw.githubusercontent.com`.  One cache file per example.

* **cubit** — Coreform forum (`forum.coreform.com`, Discourse).  Posts
  tagged / matching `tutorial example mesh` are fetched (JSON API),
  markdown code fences (```...```) are extracted as individual snippets.
  Each post becomes one "example" (metadata + concatenated code).

Both layouts serialize to `<state_dir>/examples/{source}/`:
  - `index.json` — list of `{name, title, url, code_path, tokens, token_set}`
  - `<name>.py` / `<name>.jou` — the actual code

The tf-idf retrieval machinery (`search_examples`) is shared with the
lookup tools — same scoring / heading-boost approach.
"""

from __future__ import annotations

import hashlib
import json
import math
import re
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

from .failure_log import state_dir
from .web_docs import _USER_AGENT, _TIMEOUT_SECONDS


_WORD_RE = re.compile(r"[a-zA-Z_][a-zA-Z0-9_]*")
_CODE_FENCE_RE = re.compile(r"```[a-z]*\n?([\s\S]*?)```", re.MULTILINE)
_REFRESH_TTL_SECONDS = 7 * 24 * 3600  # one week


def _examples_dir(source: str) -> Path:
	d = state_dir() / "examples" / source
	d.mkdir(parents=True, exist_ok=True)
	return d


def _index_path(source: str) -> Path:
	return _examples_dir(source) / "index.json"


def _tokenize(s: str) -> list[str]:
	"""Lower-case identifier tokens + their underscore-split sub-tokens.

	`roller_coaster` indexes as both `roller_coaster` and `roller` +
	`coaster`, so both the exact identifier and free-form queries match.
	"""
	out: list[str] = []
	for m in _WORD_RE.finditer(s):
		w = m.group(0).lower()
		out.append(w)
		if "_" in w:
			out.extend(p for p in w.split("_") if p)
	return out


def _http_get(url: str, accept: str = "text/plain") -> bytes | None:
	req = urllib.request.Request(url, headers={
		"User-Agent": _USER_AGENT,
		"Accept": accept,
	})
	try:
		with urllib.request.urlopen(req, timeout=_TIMEOUT_SECONDS) as resp:  # noqa: S310
			return resp.read()
	except (urllib.error.HTTPError, urllib.error.URLError,
	        TimeoutError, OSError):
		return None


def _safe_name(s: str) -> str:
	"""Sanitize a filename component."""
	return re.sub(r"[^A-Za-z0-9_.-]+", "_", s)[:96] or "unnamed"


# ---------------------------------------------------------------------------
# build123d: GitHub `gumyr/build123d/examples/*.py`
# ---------------------------------------------------------------------------

_BUILD123D_LIST_URL = ("https://api.github.com/repos/gumyr/build123d/"
                       "contents/examples")

_BD_WAREHOUSE_LIST_URL = ("https://api.github.com/repos/gumyr/bd_warehouse/"
                           "contents/src/bd_warehouse")
_BD_WAREHOUSE_EXAMPLES_URL = ("https://api.github.com/repos/gumyr/bd_warehouse/"
                               "contents/examples")

# Default local roots walked by refresh_cubit_local_examples. Anything a
# user wants indexed can also be passed explicitly via `roots=[...]`.
_DEFAULT_LOCAL_CUBIT_ROOTS = [
	r"S:\CoreformCubit",
	r"S:\Radia\01_GitHub\examples",
]

# Source families — `search_examples(family, ...)` unions all sub-sources
# so a single query sees forum + local + radia examples for Cubit,
# GitHub examples + bd_warehouse for build123d, etc.
FAMILIES: dict[str, list[str]] = {
	"cubit": ["cubit", "cubit_local"],
	"build123d": ["build123d", "bd_warehouse"],
}


def refresh_build123d_examples(limit: int = 0) -> dict:
	"""Fetch the build123d examples folder from GitHub and populate the cache.

	Args:
	    limit: cap on number of files to fetch (0 = all).

	Returns stats dict: {fetched, failed, total, index_path}.
	"""
	raw = _http_get(_BUILD123D_LIST_URL, accept="application/vnd.github+json")
	if not raw:
		return {"status": "error", "error": "GitHub listing fetch failed"}
	try:
		listing = json.loads(raw)
	except json.JSONDecodeError as e:
		return {"status": "error", "error": f"listing JSON decode: {e}"}
	if not isinstance(listing, list):
		return {"status": "error",
		        "error": f"unexpected listing shape: {str(listing)[:200]}"}

	py_files = [f for f in listing
	            if isinstance(f, dict) and f.get("name", "").endswith(".py")]
	if limit > 0:
		py_files = py_files[:limit]

	d = _examples_dir("build123d")
	index: list[dict[str, Any]] = []
	fetched = 0
	failed: list[str] = []

	for f in py_files:
		name = f.get("name", "")
		dl = f.get("download_url")
		if not (name and dl):
			failed.append(name)
			continue
		body_raw = _http_get(dl, accept="text/plain")
		if body_raw is None:
			failed.append(name)
			continue
		body = body_raw.decode("utf-8", errors="replace")

		code_path = d / _safe_name(name)
		try:
			code_path.write_text(body, encoding="utf-8")
		except OSError:
			failed.append(name)
			continue

		# Extract title from docstring/comments
		title = _guess_python_title(body, fallback=name)
		tokens = _tokenize(body)
		index.append({
			"name": name,
			"title": title,
			"url": f.get("html_url")
			       or f"https://github.com/gumyr/build123d/blob/dev/examples/{name}",
			"code_path": str(code_path),
			"size": f.get("size", 0),
			"tokens": tokens,
			"token_set": sorted(set(tokens)),
		})
		fetched += 1

	index_data = {
		"fetched_at": time.time(),
		"source": "build123d",
		"items": index,
	}
	_index_path("build123d").write_text(
		json.dumps(index_data, ensure_ascii=False, indent=2),
		encoding="utf-8",
	)
	return {
		"status": "ok",
		"fetched": fetched,
		"failed": failed,
		"total": len(py_files),
		"index_path": str(_index_path("build123d")),
	}


def _guess_python_title(body: str, fallback: str) -> str:
	"""Pick a 1-line title from a Python file.

	Priority: module docstring first line → first comment line → fallback.
	"""
	# Module docstring
	m = re.match(r'\s*(?:[ru]?["\']{3})([\s\S]*?)["\']{3}', body)
	if m:
		first = m.group(1).strip().splitlines()
		if first:
			return first[0][:120]
	# First `# ...` comment line
	for line in body.splitlines()[:20]:
		ls = line.strip()
		if ls.startswith("#") and len(ls) > 1:
			return ls.lstrip("# ").strip()[:120]
	return fallback


# ---------------------------------------------------------------------------
# bd_warehouse: GitHub `gumyr/bd_warehouse` (industrial-parts library)
# ---------------------------------------------------------------------------

def refresh_bd_warehouse_examples(include_examples_dir: bool = True) -> dict:
	"""Fetch bd_warehouse source modules + examples from GitHub.

	bd_warehouse is gumyr's industrial-parts companion to build123d
	(bearings, fasteners, flanges, gears, open_builds extrusions,
	pipes, sprockets). Each module is a single file with parametric
	classes. Scraped the same way as build123d examples.

	Args:
	    include_examples_dir: also index `examples/` subdir if present.
	"""
	d = _examples_dir("bd_warehouse")
	index: list[dict[str, Any]] = []
	fetched = 0
	failed: list[str] = []

	endpoints: list[tuple[str, str]] = [("src/bd_warehouse", _BD_WAREHOUSE_LIST_URL)]
	if include_examples_dir:
		endpoints.append(("examples", _BD_WAREHOUSE_EXAMPLES_URL))

	for subdir, url in endpoints:
		raw = _http_get(url, accept="application/vnd.github+json")
		if not raw:
			failed.append(f"listing: {subdir}")
			continue
		try:
			listing = json.loads(raw)
		except json.JSONDecodeError:
			failed.append(f"listing json: {subdir}")
			continue
		if not isinstance(listing, list):
			# Some sub-dirs (e.g. examples) might not exist — skip
			continue
		for f in listing:
			if not isinstance(f, dict):
				continue
			name = f.get("name", "")
			if not name.endswith(".py"):
				continue
			dl = f.get("download_url")
			if not dl:
				failed.append(name)
				continue
			body_raw = _http_get(dl, accept="text/plain")
			if body_raw is None:
				failed.append(name)
				continue
			body = body_raw.decode("utf-8", errors="replace")

			stored_name = f"{subdir.replace('/', '_')}__{_safe_name(name)}"
			code_path = d / stored_name
			try:
				code_path.write_text(body, encoding="utf-8")
			except OSError:
				failed.append(name)
				continue
			title = _guess_python_title(body, fallback=name)
			tokens = _tokenize(body)
			index.append({
				"name": name,
				"stored": stored_name,
				"title": title,
				"url": f.get("html_url")
				       or f"https://github.com/gumyr/bd_warehouse/blob/main/{subdir}/{name}",
				"code_path": str(code_path),
				"size": f.get("size", 0),
				"subdir": subdir,
				"tokens": tokens,
				"token_set": sorted(set(tokens)),
			})
			fetched += 1

	_index_path("bd_warehouse").write_text(
		json.dumps({"fetched_at": time.time(), "source": "bd_warehouse",
		            "items": index}, ensure_ascii=False, indent=2),
		encoding="utf-8",
	)
	return {
		"status": "ok",
		"fetched": fetched,
		"failed": failed,
		"index_path": str(_index_path("bd_warehouse")),
	}


# ---------------------------------------------------------------------------
# cubit_local: walks on-disk directories (S:\CoreformCubit, Radia/examples, ...)
# ---------------------------------------------------------------------------

_LOCAL_EXTS = (".jou", ".py")
_LOCAL_SKIP_DIRS = frozenset({
	".git", "__pycache__", "build", "dist", ".venv", "venv", "node_modules",
	"packages",  # don't re-index radia-mcp's own source
})
_LOCAL_MAX_FILE_BYTES = 200_000  # skip huge files (data dumps, generated meshes)


def _guess_local_title(body: str, path: Path) -> str:
	"""Pull a 1-line title from a .jou or .py file."""
	for raw_line in body.splitlines()[:30]:
		line = raw_line.strip()
		if not line:
			continue
		# Python docstring: opening triple-quote then text
		if line.startswith(("'''", '"""')) and len(line) > 3:
			return line.strip("'\" ")[:120]
		# Python comment / Cubit journal comment (both start with #)
		if line.startswith("#"):
			t = line.lstrip("# \t").strip()
			if t and not t.startswith("!"):
				return t[:120]
		# First meaningful non-comment line (useful when files have no header)
		return line[:120]
	return path.name


def refresh_cubit_local_examples(roots: list[str] | None = None,
                                 extra_skip_dirs: list[str] | None = None) -> dict:
	"""Walk local directories and index .jou / .py files as Cubit examples.

	Default roots: `S:\\CoreformCubit` (the lab's years of curated
	Cubit projects, ~145 files) and `S:\\Radia\\01_GitHub\\examples`
	(~400 files across radia / build123d / cubit / ngsolve / ih /
	electromagnet workflows). Users can pass `roots=[...]` to override.

	Each file:
	  - title from first non-empty comment / docstring line
	  - tokens from full body (tf-idf indexable)
	  - path kept as absolute — NOT copied to state_dir (these are
	    already on a shared drive; duplicating wastes space and drifts
	    as files evolve)

	Files larger than 200 kB are skipped to keep the index sane.
	"""
	roots = roots or _DEFAULT_LOCAL_CUBIT_ROOTS
	skip_dirs = set(_LOCAL_SKIP_DIRS)
	if extra_skip_dirs:
		skip_dirs.update(extra_skip_dirs)

	index: list[dict[str, Any]] = []
	indexed_paths: set[str] = set()
	skipped_big = 0
	read_errors = 0
	roots_walked: list[str] = []

	for root_s in roots:
		root = Path(root_s)
		if not root.exists():
			continue
		roots_walked.append(str(root))
		for path in root.rglob("*"):
			if not path.is_file():
				continue
			if path.suffix.lower() not in _LOCAL_EXTS:
				continue
			# Skip any path with a component in skip_dirs
			if any(part in skip_dirs for part in path.parts):
				continue
			try:
				size = path.stat().st_size
			except OSError:
				continue
			if size > _LOCAL_MAX_FILE_BYTES or size == 0:
				if size > _LOCAL_MAX_FILE_BYTES:
					skipped_big += 1
				continue
			p_abs = str(path.resolve())
			if p_abs in indexed_paths:
				continue
			try:
				body = path.read_text(encoding="utf-8", errors="replace")
			except OSError:
				read_errors += 1
				continue
			tokens = _tokenize(body)
			if not tokens:
				continue
			rel = str(path).replace("\\", "/")
			title = _guess_local_title(body, path)
			index.append({
				"name": path.name,
				"title": title,
				"url": f"file:///{rel}",
				"code_path": p_abs,
				"size": size,
				"root": str(root),
				"parent_dir": path.parent.name,
				"ext": path.suffix.lower(),
				"tokens": tokens,
				"token_set": sorted(set(tokens)),
			})
			indexed_paths.add(p_abs)

	_index_path("cubit_local").write_text(
		json.dumps({"fetched_at": time.time(), "source": "cubit_local",
		            "items": index, "roots_walked": roots_walked},
		           ensure_ascii=False, indent=2),
		encoding="utf-8",
	)
	return {
		"status": "ok",
		"indexed": len(index),
		"roots_walked": roots_walked,
		"skipped_too_big": skipped_big,
		"read_errors": read_errors,
		"index_path": str(_index_path("cubit_local")),
	}


# ---------------------------------------------------------------------------
# cubit: Discourse forum (forum.coreform.com)
# ---------------------------------------------------------------------------

_CUBIT_FORUM_BASE = "https://forum.coreform.com"
_CUBIT_QUERIES = [
	"tutorial example mesh",
	"hex meshing tutorial",
	"sweep scheme example",
	"journal file example",
	"radia_export example",
	"boundary layer mesh",
	"thin shell mesh",
	"mesh quality metric",
	"mesh refinement",
	"abaqus export",
	"high order curving",
	"polyhedron scheme",
	"multi sweep source target",
	"imprint merge",
	"webcut journal",
]


def refresh_cubit_examples(limit_per_query: int = 5) -> dict:
	"""Fetch Cubit example snippets from the Coreform forum.

	For each seed query, hits `/search.json`, takes up to `limit_per_query`
	top posts, fetches each post's raw markdown, extracts triple-backtick
	code fences as one concatenated journal snippet per post.

	Args:
	    limit_per_query: max posts per query (default 5).

	Returns stats dict.
	"""
	d = _examples_dir("cubit")
	seen_post_ids: set[int] = set()
	index: list[dict[str, Any]] = []
	fetched = 0
	failed: list[str] = []

	for q in _CUBIT_QUERIES:
		url = (f"{_CUBIT_FORUM_BASE}/search.json?q="
		       + urllib.parse.quote(q))
		raw = _http_get(url, accept="application/json")
		if raw is None:
			failed.append(f"search: {q}")
			continue
		try:
			search_json = json.loads(raw)
		except json.JSONDecodeError:
			failed.append(f"search json: {q}")
			continue
		topics_by_id = {t["id"]: t for t in search_json.get("topics", [])
		                if isinstance(t, dict)}
		posts = search_json.get("posts", [])[:limit_per_query]
		for post in posts:
			pid = post.get("id")
			if not pid or pid in seen_post_ids:
				continue
			seen_post_ids.add(pid)
			post_url = f"{_CUBIT_FORUM_BASE}/posts/{pid}.json"
			praw = _http_get(post_url, accept="application/json")
			if praw is None:
				failed.append(f"post {pid}")
				continue
			try:
				pdata = json.loads(praw)
			except json.JSONDecodeError:
				failed.append(f"post json {pid}")
				continue
			body = pdata.get("raw") or ""
			fences = _CODE_FENCE_RE.findall(body)
			if not fences:
				continue
			code = "\n\n# ---- next snippet ----\n\n".join(
				f.strip() for f in fences if f.strip()
			)
			if not code:
				continue

			topic = topics_by_id.get(post.get("topic_id"), {})
			title = topic.get("title", "") or f"forum post {pid}"
			slug = topic.get("slug", "")
			tid = topic.get("id", post.get("topic_id"))
			pnum = post.get("post_number", 1)
			html_url = (f"{_CUBIT_FORUM_BASE}/t/{slug}/{tid}/{pnum}"
			            if slug and tid else f"{_CUBIT_FORUM_BASE}/p/{pid}")

			name = f"{_safe_name(title)[:60]}__p{pid}.jou"
			code_path = d / name
			# Store both prose and code so retrieval indexes both
			blob = (f"# {title}\n# source: {html_url}\n# "
			        f"post id: {pid}\n\n# --- prose ---\n"
			        + "\n".join("# " + line for line in body.splitlines()[:60])
			        + "\n\n# --- code ---\n" + code + "\n")
			try:
				code_path.write_text(blob, encoding="utf-8")
			except OSError:
				failed.append(name)
				continue

			tokens = _tokenize(blob)
			index.append({
				"name": name,
				"title": title,
				"url": html_url,
				"code_path": str(code_path),
				"post_id": pid,
				"tokens": tokens,
				"token_set": sorted(set(tokens)),
			})
			fetched += 1

	index_data = {
		"fetched_at": time.time(),
		"source": "cubit",
		"items": index,
	}
	_index_path("cubit").write_text(
		json.dumps(index_data, ensure_ascii=False, indent=2),
		encoding="utf-8",
	)
	return {
		"status": "ok",
		"fetched": fetched,
		"failed": failed,
		"posts_seen": len(seen_post_ids),
		"index_path": str(_index_path("cubit")),
	}


# ---------------------------------------------------------------------------
# Retrieval
# ---------------------------------------------------------------------------

def _load_index(source: str) -> dict:
	p = _index_path(source)
	if not p.exists():
		return {"fetched_at": 0, "items": []}
	try:
		return json.loads(p.read_text(encoding="utf-8"))
	except (OSError, json.JSONDecodeError):
		return {"fetched_at": 0, "items": []}


def _is_stale(index: dict, ttl: int = _REFRESH_TTL_SECONDS) -> bool:
	return time.time() - float(index.get("fetched_at", 0)) > ttl


REFRESH_FUNCS = {
	"build123d": refresh_build123d_examples,
	"bd_warehouse": refresh_bd_warehouse_examples,
	"cubit": refresh_cubit_examples,
	"cubit_local": refresh_cubit_local_examples,
}


def _resolve_family(name: str) -> list[str]:
	"""Return the list of sub-sources for a family, or [name] if not a family."""
	return FAMILIES.get(name, [name])


def _ensure_fresh(source: str, force: bool) -> None:
	if force or _is_stale(_load_index(source)):
		fn = REFRESH_FUNCS.get(source)
		if fn is not None:
			try:
				fn()
			except Exception:
				# Refresh failure should not break search of the remaining sources
				pass


def search_examples(source: str, query: str, limit: int = 5,
                    force_refresh: bool = False,
                    auto_refresh_if_empty: bool = True) -> dict:
	"""tf-idf search across cached examples for `source`.

	`source` may be a single concrete source (`build123d`, `cubit`,
	`bd_warehouse`, `cubit_local`) or a family name (`build123d` resolves
	to `[build123d, bd_warehouse]`; `cubit` resolves to `[cubit,
	cubit_local]`).  For families the indexes are unioned and ranked
	together so one query sees GitHub + local + forum hits at once.

	Args:
	    source: concrete source name or family name.
	    query: keywords (AND-scored, stop-words stripped).
	    limit: cap on returned examples.
	    force_refresh: re-scrape ignoring cache.
	    auto_refresh_if_empty: if any sub-source's cache is empty or
	        stale, refresh that one before searching. Default True.

	Returns dict with `results` (each hit: source / name / title / url /
	score / excerpt / path) + per-sub-source `stats`.
	"""
	sub_sources = _resolve_family(source)
	if not sub_sources:
		return {"status": "error", "error": f"unknown source {source!r}",
		        "known": list(REFRESH_FUNCS.keys())}

	for sub in sub_sources:
		if force_refresh or auto_refresh_if_empty:
			_ensure_fresh(sub, force=force_refresh)

	combined: list[tuple[dict, str]] = []  # (item, owning_sub_source)
	stats: dict[str, dict] = {}
	for sub in sub_sources:
		idx = _load_index(sub)
		items = idx.get("items", [])
		stats[sub] = {"indexed": len(items),
		              "fetched_at": idx.get("fetched_at")}
		for it in items:
			combined.append((it, sub))

	if not combined:
		return {"status": "ok", "source": source, "query": query,
		        "sub_sources": sub_sources, "stats": stats,
		        "results": [], "note": "empty index"}

	q_terms = [t for t in _tokenize(query or "")]
	if not q_terms:
		return {"status": "error", "error": "empty query"}

	n = max(1, len(combined))
	idf: dict[str, float] = {}
	for t in q_terms:
		df = sum(1 for it, _ in combined if t in (it.get("token_set") or []))
		idf[t] = math.log((n + 1) / (df + 1)) + 1.0

	scored: list[tuple[float, dict, str]] = []
	for it, sub in combined:
		tokens = it.get("tokens") or []
		if not tokens:
			continue
		tf: dict[str, int] = {}
		for tok in tokens:
			tf[tok] = tf.get(tok, 0) + 1
		inv_len = 1.0 / (1.0 + math.log(1 + len(tokens)))
		score = 0.0
		hits = 0
		for term in q_terms:
			f = tf.get(term, 0)
			if f == 0:
				continue
			hits += 1
			score += (1.0 + math.log(f)) * idf.get(term, 1.0) * inv_len
		if hits == 0:
			continue
		title_lc = (it.get("title") or "").lower()
		head_hits = sum(1 for t in q_terms if t in title_lc)
		if head_hits:
			score *= 1.0 + 0.75 * head_hits
		score *= 1.0 + 0.25 * (hits / max(1, len(q_terms)))
		# Mild local-source boost: lab-curated examples are usually more
		# relevant to Radia users than random forum posts / general libs.
		if sub in ("cubit_local",):
			score *= 1.1
		scored.append((score, it, sub))

	scored.sort(key=lambda x: (-x[0], x[2], x[1].get("name", "")))
	top = scored[: max(1, int(limit))]

	results: list[dict] = []
	for score, it, sub in top:
		excerpt = ""
		p = Path(it.get("code_path", ""))
		if p.exists():
			try:
				excerpt = p.read_text(encoding="utf-8", errors="replace")[:1600]
			except OSError:
				pass
		results.append({
			"source": sub,
			"name": it.get("name"),
			"title": it.get("title"),
			"url": it.get("url"),
			"score": round(score, 3),
			"parent_dir": it.get("parent_dir"),  # local only
			"excerpt": excerpt,
			"path": it.get("code_path"),
		})

	return {
		"status": "ok",
		"source": source,
		"sub_sources": sub_sources,
		"query": query,
		"stats": stats,
		"total_scored": len(scored),
		"results": results,
	}
