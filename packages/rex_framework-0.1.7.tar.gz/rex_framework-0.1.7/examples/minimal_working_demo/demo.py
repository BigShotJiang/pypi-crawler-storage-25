"""
Minimal working end-to-end demo for the Rex framework.

Demonstrates the full pipeline:
  1. Create a tiny PyTorch model
  2. Convert to Rex format (chunked + manifest)
  3. Serve chunks via local HTTP range server
  4. Load manifest via RexRuntime (without downloading full weights)
  5. Run inference through Rex (lazy chunk fetch + cache + eviction)
  6. Verify output matches direct PyTorch inference
  7. Verify the invariant: full model is never resident locally

Usage:
    PYTHONPATH=src python3 examples/minimal_working_demo/demo.py
"""

from __future__ import annotations

import asyncio
import sys
import threading
import time
from pathlib import Path

# ── Step 0: Ensure project root is importable ──────────────────────────────
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
if str(PROJECT_ROOT / "src") not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT / "src"))

import numpy as np


def create_demo_model():
    """Create a tiny 2-layer MLP: input(8) -> hidden(16, ReLU) -> output(4)."""
    import torch
    import torch.nn as nn

    torch.manual_seed(42)
    model = nn.Sequential(
        nn.Linear(8, 16),
        nn.ReLU(),
        nn.Linear(16, 4),
    )
    return model


def convert_to_rex(model, output_dir: str, chunk_size: int = 256):
    """Convert a PyTorch model to Rex chunk format."""
    from rex.convert.pytorch_converter import PyTorchConverter

    sd = model.state_dict()
    converter = PyTorchConverter(
        output_dir=output_dir,
        chunk_size_bytes=chunk_size,
        model_id="demo-mlp-v1",
        model_family="demo",
    )
    result = converter.convert(sd)
    return result


def start_chunk_server(chunks_dir: str, port: int = 18971):
    """Start the local chunk server in a daemon thread."""
    from rex.storage.local_server import serve_chunks

    server_ready = threading.Event()

    async def _serve():
        await serve_chunks(chunk_dir=chunks_dir, host="127.0.0.1", port=port)
        server_ready.set()
        # Keep alive
        while True:
            await asyncio.sleep(3600)

    t = threading.Thread(target=lambda: asyncio.run(_serve()), daemon=True)
    t.start()
    time.sleep(1.5)  # Wait for server to bind
    return server_ready


async def run_rex_inference(
    manifest_path: str,
    base_url: str,
    input_array: np.ndarray,
    pytorch_output: np.ndarray,
):
    """Load manifest and run inference through the Rex pipeline."""
    from rex.api.config import RexConfig
    from rex.core.runtime import RexRuntime
    from rex.core.invariants import InvariantChecker

    # --- Configure runtime ---
    config = RexConfig()
    config.storage.base_url = base_url
    config.cache.max_memory_cache_bytes = 1024 * 1024  # 1 MB
    config.scheduler.prefetch_window = 2
    config.debug = True

    runtime = RexRuntime(config=config)

    # --- Load model (reads manifest only, does NOT download weights) ---
    print("[Rex] Loading manifest...")
    await runtime.load_model(manifest_path)
    manifest = runtime.manifest
    assert manifest is not None
    print(f"[Rex] Model loaded: {manifest.model_id}")
    print(f"[Rex] Total model bytes: {manifest.total_model_bytes}")
    print(f"[Rex] Total chunks: {manifest.total_chunks}")
    print(f"[Rex] Execution graph: {manifest.execution_graph}")

    # --- Show model info ---
    info = runtime.get_model_info()
    for k, v in info.items():
        print(f"[Rex]   {k}: {v}")

    # --- Create invariant checker ---
    inv_checker = InvariantChecker(
        total_model_bytes=manifest.total_model_bytes,
        max_local_fraction=0.4,
    )

    # --- Compute function for Rex inference ---
    # The execution graph has one param per "layer", so compute_fn is called
    # once per parameter. We apply the operations cumulatively.
    hidden_applied = [False]

    def compute_fn(input_data, weights: dict):
        x = input_data
        for pname, w in weights.items():
            if w is None:
                continue
            if "weight" in pname:
                x = x @ w.T
            elif "bias" in pname:
                x = x + w
        # Apply ReLU after hidden layer bias (0.bias) is processed
        if "0.bias" in weights and not hidden_applied[0]:
            x = np.maximum(x, 0.0)
            hidden_applied[0] = True
        return x

    # --- Run inference (first pass — cold cache) ---
    print("\n[Rex] Running inference (cold cache)...")
    hidden_applied[0] = False
    output, metrics = await runtime.run_inference(input_array, compute_fn=compute_fn)

    print(f"[Rex] Output shape: {output.shape if hasattr(output, 'shape') else type(output)}")
    print(f"[Rex] Total time: {metrics.total_time_ms:.2f} ms")
    print(f"[Rex] Compute time: {metrics.compute_time_ms:.2f} ms")
    print(f"[Rex] Stall time: {metrics.stall_time_ms:.2f} ms")
    print(f"[Rex] Chunks fetched: {metrics.chunks_fetched}")
    print(f"[Rex] Cache hits: {metrics.cache_hits}")
    print(f"[Rex] Cache misses: {metrics.cache_misses}")
    print(f"[Rex] Bytes fetched: {metrics.bytes_fetched_remote}")
    print(f"[Rex] Layers executed: {metrics.layers_executed}")
    print(f"[Rex] Evictions: {metrics.eviction_count}")
    print(f"[Rex] Invariant violations: {metrics.invariant_violations}")

    # --- Verify invariant ---
    # After execution, all chunks are evicted (layer-by-layer execution).
    # The cache should be empty because the executor evicts after each layer.
    inv_result = inv_checker.check_invariant(
        resident_bytes=0,
        cached_bytes=0,  # executor evicts after use
        raise_on_violation=False,
    )
    print(f"\n[Rex] Invariant check: {'PASS' if inv_result.is_valid else 'FAIL'}")
    print(f"[Rex] Full model bytes: {manifest.total_model_bytes}")
    print(f"[Rex] Max allowed local: {inv_checker.max_allowed_bytes} ({manifest.cache_constraints.max_local_fraction_of_model:.0%})")

    # --- Run second inference (warm cache) ---
    print("\n[Rex] Running inference (warm cache)...")
    hidden_applied[0] = False
    output2, metrics2 = await runtime.run_inference(input_array, compute_fn=compute_fn)
    print(f"[Rex] Chunks fetched: {metrics2.chunks_fetched}")
    print(f"[Rex] Cache hits: {metrics2.cache_hits}")
    print(f"[Rex] Cache misses: {metrics2.cache_misses}")
    print(f"[Rex] Total time: {metrics2.total_time_ms:.2f} ms")

    # --- Verify correctness ---
    if isinstance(output, np.ndarray) and isinstance(pytorch_output, np.ndarray):
        max_diff = np.max(np.abs(output - pytorch_output))
        print(f"\n[Rex] Correctness check (max abs diff): {max_diff:.6f}")
        if max_diff < 1e-3:
            print("[Rex] OUTPUT MATCHES PyTorch reference (within 1e-3)")
        else:
            print(f"[Rex] WARNING: Output differs from PyTorch reference by {max_diff}")
    else:
        print(f"\n[Rex] Output type: {type(output)}, reference type: {type(pytorch_output)}")

    # --- Shutdown ---
    await runtime.shutdown()

    return metrics, metrics2, inv_result.is_valid


def main():
    print("=" * 70)
    print("  Rex Framework — Minimal Working End-to-End Demo")
    print("=" * 70)
    print()

    import torch

    output_dir = str(PROJECT_ROOT / "rex_demo_output")

    # ── Step 1: Create a tiny model ────────────────────────────────────────
    print("[1/6] Creating tiny PyTorch model...")
    model = create_demo_model()
    sd = model.state_dict()
    total_params = sum(v.numel() for v in sd.values())
    total_bytes = sum(v.numel() * v.element_size() for v in sd.values())
    print(f"  Parameters: {len(sd)}")
    print(f"  Total elements: {total_params}")
    print(f"  Total bytes: {total_bytes}")
    for k, v in sd.items():
        print(f"    {k}: {v.shape} ({v.numel()} elements, {v.numel() * v.element_size()} bytes)")
    print()

    # ── Step 2: Run direct PyTorch inference for reference ─────────────────
    print("[2/6] Running direct PyTorch inference (reference)...")
    model.eval()
    test_input = torch.randn(1, 8)
    with torch.no_grad():
        pytorch_output = model(test_input).numpy()
    print(f"  Input shape: {test_input.shape}")
    print(f"  Output shape: {pytorch_output.shape}")
    print(f"  Output: {pytorch_output}")
    print()

    # ── Step 3: Convert to Rex format ──────────────────────────────────────
    print("[3/6] Converting to Rex format...")
    result = convert_to_rex(model, output_dir, chunk_size=256)
    print(f"  Output dir: {output_dir}")
    print(f"  Chunks: {result.num_chunks}")
    print(f"  Original: {result.total_original_bytes} bytes")
    print(f"  Chunked:  {result.total_chunk_bytes} bytes")
    if result.warnings:
        for w in result.warnings:
            print(f"  WARNING: {w}")
    print()

    # ── Step 4: Start local chunk server ───────────────────────────────────
    print("[4/6] Starting local HTTP chunk server...")
    chunks_dir = str(Path(output_dir) / "weights")
    start_chunk_server(chunks_dir, port=18971)
    base_url = "http://127.0.0.1:18971"
    print(f"  Server running at {base_url}")
    print()

    # ── Step 5: Load manifest ──────────────────────────────────────────────
    print("[5/6] Loading Rex manifest...")
    from rex.formats.manifest import load_manifest, pretty_print_manifest

    manifest = load_manifest(str(Path(output_dir) / "manifest.json"))
    print(pretty_print_manifest(manifest))
    print()

    # ── Step 6: Run inference through Rex ─────────────────────────────────
    print("[6/6] Running inference through Rex...")
    input_array = test_input.numpy()

    metrics_cold, metrics_warm, invariant_ok = asyncio.run(
        run_rex_inference(
            manifest_path=str(Path(output_dir) / "manifest.json"),
            base_url=base_url,
            input_array=input_array,
            pytorch_output=pytorch_output,
        )
    )

    # ── Summary ────────────────────────────────────────────────────────────
    print()
    print("=" * 70)
    print("  DEMO SUMMARY")
    print("=" * 70)
    print(f"  Cold inference:  {metrics_cold.total_time_ms:.2f} ms  "
          f"({metrics_cold.chunks_fetched} chunks fetched, "
          f"{metrics_cold.cache_hits} hits, {metrics_cold.cache_misses} misses)")
    print(f"  Warm inference:  {metrics_warm.total_time_ms:.2f} ms  "
          f"({metrics_warm.chunks_fetched} chunks fetched, "
          f"{metrics_warm.cache_hits} hits, {metrics_warm.cache_misses} misses)")
    print(f"  Invariant:       {'PASS' if invariant_ok else 'FAIL'}")
    print(f"  Full model local: {'NO (good)' if invariant_ok else 'YES (bug!)'}")
    print()
    print("  Demo completed successfully!")
    print(f"  Artifacts saved to: {output_dir}")


if __name__ == "__main__":
    main()
