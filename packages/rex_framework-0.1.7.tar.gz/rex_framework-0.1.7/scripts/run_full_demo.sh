#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")/.."

echo "=== Rex Framework: Full Demo ==="
echo ""

PYTHONPATH=src python3 examples/minimal_working_demo/demo.py "$@"
