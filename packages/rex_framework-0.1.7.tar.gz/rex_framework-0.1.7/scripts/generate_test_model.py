#!/usr/bin/env python3
"""Generate a tiny test model for Rex demos and tests."""
import torch
import torch.nn as nn
from pathlib import Path


class TinyTransformer(nn.Module):
    """Tiny transformer for Rex testing."""
    def __init__(self, d_model=16, n_heads=2, d_ff=32, n_layers=2, vocab_size=100):
        super().__init__()
        self.embedding = nn.Linear(vocab_size, d_model, bias=False)
        self.layers = nn.ModuleList()
        for _ in range(n_layers):
            self.layers.append(nn.ModuleDict({
                "attention.w_q": nn.Linear(d_model, d_model, bias=False),
                "attention.w_k": nn.Linear(d_model, d_model, bias=False),
                "attention.w_v": nn.Linear(d_model, d_model, bias=False),
                "attention.w_o": nn.Linear(d_model, d_model, bias=False),
                "ffn.fc1": nn.Linear(d_model, d_ff, bias=False),
                "ffn.fc2": nn.Linear(d_ff, d_model, bias=False),
                "norm1": nn.LayerNorm(d_model),
                "norm2": nn.LayerNorm(d_model),
            }))
        self.output = nn.Linear(d_model, vocab_size, bias=False)

    def forward(self, x):
        return x


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default="tests/fixtures/tiny_models/demo_model.pt")
    args = parser.parse_args()

    torch.manual_seed(42)
    model = TinyTransformer()
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    torch.save(model.state_dict(), args.output)
    print(f"Saved tiny model to {args.output}")
    print(f"  Parameters: {sum(p.numel() for p in model.parameters())}")
    for k, v in model.state_dict().items():
        print(f"  {k}: {v.shape}")


if __name__ == "__main__":
    main()
