"""Compatibility shim for legacy converter imports."""

from __future__ import annotations

from rex.convert.pytorch_converter import *  # noqa: F401,F403

