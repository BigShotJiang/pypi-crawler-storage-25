"""
Async prefetch engine for the Rex framework.

Manages concurrent chunk fetching from remote storage with priority
ordering, backpressure, retry logic, and comprehensive metrics.
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from collections.abc import Callable
from typing import TYPE_CHECKING, Any, Optional
from urllib.parse import urljoin

import structlog

from rex.core.prefetch_optimizer import PrefetchCandidate, plan_prefetch
from rex.core.types import (
    ByteRange,
    ChunkAddress,
    ChunkPriority,
    CompressionCodec,
    FetchResult,
)

if TYPE_CHECKING:
    from rex.storage.base import BaseStorageBackend

logger = structlog.get_logger(__name__)


@dataclass(order=True)
class PrefetchRequest:
    """A pending prefetch request with priority ordering."""
    priority: int = field(compare=True)
    sequence: int = field(compare=True)  # FIFO within same priority
    chunk_address: ChunkAddress = field(compare=False)
    request_time: float = field(default_factory=time.monotonic, compare=False)


@dataclass
class FetchMetrics:
    """Per-fetch timing and transfer metrics."""
    chunk_id: str
    duration_ms: float
    bytes_transferred: int
    success: bool
    from_cache: bool
    error: Optional[str] = None
    retries: int = 0


@dataclass
class AggregatePrefetchMetrics:
    """Aggregated prefetch metrics."""
    total_fetches: int = 0
    successful_fetches: int = 0
    failed_fetches: int = 0
    cache_hits: int = 0
    total_bytes_transferred: int = 0
    total_duration_ms: float = 0.0
    average_duration_ms: float = 0.0
    average_bandwidth_mbps: float = 0.0
    retry_count: int = 0
    cancelled_count: int = 0
    backpressure_pause_count: int = 0
    backpressure_pause_duration_ms: float = 0.0


# Priority mapping for the priority queue
_PRIORITY_VALUES: dict[ChunkPriority, int] = {
    ChunkPriority.HIGH: 0,
    ChunkPriority.LOW: 1,
    ChunkPriority.BACKGROUND: 2,
}


class AsyncPrefetcher:
    """Async prefetch engine with priority queue and bounded concurrency.

    Features:
        - Priority-ordered fetch queue (HIGH > LOW > BACKGROUND)
        - Bounded concurrent fetches (max_concurrent_fetches)
        - Exponential backoff retry on transient failures
        - Backpressure: pauses fetching when cache is near capacity
        - Per-fetch and aggregate timing metrics
        - Cancellation of pending/background fetches
        - Integration with storage backend for HTTP range fetches

    Args:
        storage_base_url: Base URL for the remote storage backend.
        max_concurrent_fetches: Maximum number of parallel fetch operations.
        max_retries: Maximum retry attempts per chunk.
        base_delay_seconds: Initial retry delay (doubles each attempt).
        backpressure_threshold: Cache fill fraction (0.0-1.0) at which
            to pause fetching. Default 0.9 (90%).
    """

    def __init__(
        self,
        storage_base_url: str,
        max_concurrent_fetches: int = 4,
        max_retries: int = 3,
        base_delay_seconds: float = 1.0,
        backpressure_threshold: float = 0.9,
        adaptive_concurrency: bool = True,
    ) -> None:
        self._storage_base_url = storage_base_url.rstrip("/")
        self._max_concurrent = max_concurrent_fetches
        self._max_retries = max_retries
        self._base_delay = base_delay_seconds
        self._backpressure_threshold = backpressure_threshold
        self._adaptive_concurrency = adaptive_concurrency

        self._queue: asyncio.PriorityQueue[PrefetchRequest] = asyncio.PriorityQueue()
        self._semaphore = asyncio.Semaphore(max_concurrent_fetches)
        self._sequence_counter = 0
        self._sequence_lock = asyncio.Lock()

        self._cancel_event = asyncio.Event()
        self._backpressure_event = asyncio.Event()
        self._backpressure_event.set()  # Not paused initially

        # Worker task
        self._worker_task: Optional[asyncio.Task[None]] = None
        self._running = False

        # Cache interface for backpressure checks
        self._cache_capacity_bytes: int = 0
        self._cache_fill_check: Optional[Callable[[], int]] = None
        self._storage_backend: Optional["BaseStorageBackend"] = None

        # Decompression configuration
        # When set, fetched chunk data is decompressed before being
        # returned to the caller (used when the manifest indicates
        # per-chunk compression is enabled).
        self._decompress_after_fetch: bool = False

        # Adaptive concurrency state (Target 8)
        self._target_concurrency: int = max_concurrent_fetches
        self._recent_latencies: list[float] = []  # recent fetch durations in ms

        # Metrics
        self._fetch_history: list[FetchMetrics] = []
        self._aggregate = AggregatePrefetchMetrics()
        self._lock = asyncio.Lock()

        self._log = logger.bind(component="prefetcher")
        self._log.info(
            "prefetcher_initialized",
            base_url=self._storage_base_url,
            max_concurrent=self._max_concurrent,
            max_retries=self._max_retries,
        )

    def set_cache_callback(
        self,
        get_current_bytes: Callable[[], int],
        cache_capacity_bytes: int,
    ) -> None:
        """Set a callback for checking cache fill level (backpressure).

        Args:
            get_current_bytes: Callable returning current cache usage in bytes.
            cache_capacity_bytes: Maximum cache capacity in bytes.
        """
        self._cache_fill_check = get_current_bytes
        self._cache_capacity_bytes = cache_capacity_bytes

    def set_decompress_after_fetch(
        self,
        enabled: bool = True,
    ) -> None:
        """Enable or disable automatic decompression after each fetch.

        When enabled, every chunk returned by ``_do_fetch`` is
        decompressed using :func:`rex.formats.compression.decompress`
        (the codec is auto-detected from the compression header).

        This should be turned on when the manifest's
        ``feature_flags[\"compressed_chunks\"]`` is ``True`` and chunks
        were written with per-chunk compression.

        Args:
            enabled: Whether to decompress after fetching.
        """
        self._decompress_after_fetch = enabled
        if enabled:
            self._log.info("decompress_after_fetch_enabled")

    def set_storage_backend(self, backend: "BaseStorageBackend") -> None:
        """Attach a storage backend used for live fetches."""
        self._storage_backend = backend
        self._log.info(
            "storage_backend_attached",
            backend_type=backend.__class__.__name__,
        )

    def _maybe_decompress(self, chunk_id: str, data: bytes) -> tuple[bool, bytes, str]:
        """Optionally decompress a fetched chunk."""
        if not self._decompress_after_fetch or len(data) == 0:
            return True, data, ""

        try:
            from rex.formats.compression import decompress, detect_codec

            codec = detect_codec(data)
            if codec is not None and codec != CompressionCodec.NONE:
                data, _ = decompress(data)
                self._log.debug(
                    "chunk_decompressed",
                    chunk_id=chunk_id,
                    codec=codec.value,
                )
        except Exception as decomp_exc:
            self._log.warning(
                "chunk_decompression_failed",
                chunk_id=chunk_id,
                error=str(decomp_exc),
            )
            return False, data, f"Decompression failed: {decomp_exc}"

        return True, data, ""

    # -----------------------------------------------------------------------
    # Target 8: Queueing-theoretic IO tuning
    # -----------------------------------------------------------------------

    @property
    def _queue_depth(self) -> int:
        """Current number of items waiting in the prefetch queue."""
        return self._queue.qsize()

    def _adjust_concurrency(self, last_fetch_ms: float) -> None:
        """Adjust ``_target_concurrency`` using a Little's Law approximation.

        If the queue is growing and average latency is low, increase concurrency.
        If the queue is empty and average latency is high, decrease concurrency.

        Args:
            last_fetch_ms: Duration of the most recent fetch in milliseconds.
        """
        if not self._adaptive_concurrency:
            return

        self._recent_latencies.append(last_fetch_ms)
        if len(self._recent_latencies) > 20:
            self._recent_latencies.pop(0)

        avg_latency = sum(self._recent_latencies) / max(1, len(self._recent_latencies))
        q_depth = self._queue_depth

        if q_depth > self._target_concurrency and avg_latency < 500.0:
            # Queue is building up and fetches are fast – add a worker slot
            self._target_concurrency = min(
                self._max_concurrent * 2,
                self._target_concurrency + 1,
            )
        elif q_depth == 0 and avg_latency > 1000.0:
            # Queue is drained but fetches are slow – shed a worker slot
            self._target_concurrency = max(1, self._target_concurrency - 1)

        self._log.debug(
            "concurrency_adjusted",
            target=self._target_concurrency,
            queue_depth=q_depth,
            avg_latency_ms=round(avg_latency, 1),
        )

    async def start(self) -> None:
        """Start the prefetch worker loop."""
        if self._running:
            return

        self._running = True
        self._cancel_event.clear()
        self._worker_task = asyncio.create_task(self._worker_loop())
        self._log.info("prefetcher_started")

    async def stop(self) -> None:
        """Stop the prefetch worker and cancel pending fetches."""
        self._running = False
        self._cancel_event.set()
        self._backpressure_event.set()  # Unblock worker

        if self._worker_task is not None:
            self._worker_task.cancel()
            try:
                await self._worker_task
            except asyncio.CancelledError:
                pass
            self._worker_task = None

        self._log.info("prefetcher_stopped")

    def enqueue(
        self,
        chunk_address: ChunkAddress,
        priority: ChunkPriority = ChunkPriority.LOW,
    ) -> None:
        """Add a chunk to the fetch queue.

        Args:
            chunk_address: The chunk to fetch.
            priority: Priority level for ordering.
        """
        if not self._running:
            self._log.warning("enqueue_while_stopped", chunk_id=chunk_address.chunk_id)
            return

        priority_val = _PRIORITY_VALUES.get(priority, 1)
        request = PrefetchRequest(
            priority=priority_val,
            sequence=self._sequence_counter,
            chunk_address=chunk_address,
        )
        self._sequence_counter += 1
        self._queue.put_nowait(request)
        self._log.debug(
            "chunk_enqueued",
            chunk_id=chunk_address.chunk_id,
            priority=priority.value,
        )

    def enqueue_optimized(
        self,
        candidates: list[tuple[ChunkAddress, PrefetchCandidate]],
        budget_bytes: int,
        priority: ChunkPriority = ChunkPriority.LOW,
    ) -> list[str]:
        """Plan a prefetch subset under a byte budget and enqueue it."""
        chosen = plan_prefetch([candidate for _, candidate in candidates], budget_bytes)
        chosen_ids = {candidate.chunk_id for candidate in chosen}
        for addr, candidate in candidates:
            if candidate.chunk_id in chosen_ids:
                self.enqueue(addr, priority=priority)
        return [candidate.chunk_id for candidate in chosen]

    def cancel_pending(self, chunk_id: Optional[str] = None) -> int:
        """Cancel pending fetch requests.

        Args:
            chunk_id: Specific chunk to cancel. If None, cancels all
                BACKGROUND priority requests.

        Returns:
            Number of cancelled requests (approximate; queue is async).
        """
        # Since PriorityQueue doesn't support efficient removal,
        # we set a cancel flag. The worker will skip cancelled items.
        self._log.debug(
            "cancel_requested",
            chunk_id=chunk_id,
        )
        # For full cancel, set the cancel event
        if chunk_id is None:
            self._cancel_event.set()
        self._aggregate.cancelled_count += 1
        return 0  # Actual cancellation handled by worker

    async def _worker_loop(self) -> None:
        """Main worker loop that processes the fetch queue."""
        self._log.debug("worker_loop_started")

        while self._running:
            try:
                # Wait for next request with timeout
                try:
                    request = await asyncio.wait_for(
                        self._queue.get(),
                        timeout=1.0,
                    )
                except asyncio.TimeoutError:
                    continue

                if self._cancel_event.is_set():
                    self._queue.task_done()
                    continue

                # Check backpressure
                if not self._backpressure_event.is_set():
                    self._log.debug("backpressure_active")
                    # Wait for backpressure to clear
                    try:
                        await asyncio.wait_for(
                            self._backpressure_event.wait(),
                            timeout=2.0,
                        )
                    except asyncio.TimeoutError:
                        self._log.debug("backpressure_timeout_requeue")
                        # Re-queue and try later
                        self._queue.put_nowait(request)
                        self._queue.task_done()
                        continue

                # Acquire concurrency semaphore
                async with self._semaphore:
                    await self._fetch_with_retry(request)

                self._queue.task_done()

            except asyncio.CancelledError:
                break
            except Exception:
                self._log.error("worker_loop_error", exc_info=True)

        self._log.debug("worker_loop_ended")

    async def _fetch_with_retry(self, request: PrefetchRequest) -> None:
        """Fetch a chunk with retry logic.

        Args:
            request: The prefetch request to process.
        """
        chunk_addr = request.chunk_address
        last_error: Optional[str] = None
        retries = 0

        for attempt in range(self._max_retries + 1):
            if self._cancel_event.is_set():
                return

            start_time = time.monotonic()
            try:
                result = await self._do_fetch(chunk_addr)
                duration_ms = (time.monotonic() - start_time) * 1000

                metrics = FetchMetrics(
                    chunk_id=chunk_addr.chunk_id,
                    duration_ms=duration_ms,
                    bytes_transferred=result.bytes_transferred,
                    success=result.success,
                    from_cache=result.from_cache,
                    error=result.error,
                    retries=retries,
                )

                async with self._lock:
                    self._fetch_history.append(metrics)
                    self._aggregate.total_fetches += 1
                    if result.success:
                        self._aggregate.successful_fetches += 1
                        self._aggregate.total_bytes_transferred += result.bytes_transferred
                    else:
                        self._aggregate.failed_fetches += 1
                    self._aggregate.total_duration_ms += duration_ms
                    self._aggregate.retry_count += retries

                if result.success:
                    self._log.debug(
                        "fetch_success",
                        chunk_id=chunk_addr.chunk_id,
                        duration_ms=round(duration_ms, 1),
                        bytes=result.bytes_transferred,
                        attempt=attempt + 1,
                    )
                    self._adjust_concurrency(duration_ms)
                    return
                else:
                    last_error = result.error
                    # Transient failures are retried
                    if attempt < self._max_retries:
                        delay = self._base_delay * (2 ** attempt)
                        self._log.warning(
                            "fetch_retry",
                            chunk_id=chunk_addr.chunk_id,
                            attempt=attempt + 1,
                            max_attempts=self._max_retries,
                            delay_seconds=delay,
                            error=result.error,
                        )
                        await asyncio.sleep(delay)

            except asyncio.CancelledError:
                return
            except Exception as exc:
                last_error = str(exc)
                if attempt < self._max_retries:
                    delay = self._base_delay * (2 ** attempt)
                    self._log.warning(
                        "fetch_exception_retry",
                        chunk_id=chunk_addr.chunk_id,
                        error=str(exc),
                        attempt=attempt + 1,
                        delay_seconds=delay,
                    )
                    await asyncio.sleep(delay)

        # All retries exhausted
        async with self._lock:
            self._aggregate.failed_fetches += 1
        self._log.error(
            "fetch_failed_all_retries",
            chunk_id=chunk_addr.chunk_id,
            error=last_error,
        )

    async def _do_fetch(self, chunk_addr: ChunkAddress) -> FetchResult:
        """Perform a single HTTP range fetch for a chunk.

        Args:
            chunk_addr: The chunk address with resource ID and byte range.

        Returns:
            FetchResult with data or error.
        """
        try:
            if self._storage_backend is not None:
                data = await self._storage_backend.fetch_range(
                    chunk_addr.resource_id,
                    chunk_addr.byte_range.start,
                    chunk_addr.byte_range.end,
                )
                ok, data, error = self._maybe_decompress(chunk_addr.chunk_id, data)
                if not ok:
                    return FetchResult(
                        chunk_id=chunk_addr.chunk_id,
                        success=False,
                        error=error,
                    )
                return FetchResult(
                    chunk_id=chunk_addr.chunk_id,
                    success=True,
                    data=data,
                    duration_ms=0,
                    bytes_transferred=len(data),
                    from_cache=False,
                )

            import aiohttp
        except ImportError:
            return FetchResult(
                chunk_id=chunk_addr.chunk_id,
                success=False,
                error="aiohttp not installed",
            )

        url = urljoin(self._storage_base_url + "/", chunk_addr.resource_id)
        headers = {
            "Range": chunk_addr.byte_range.to_http_header(),
            "Accept": "application/octet-stream",
        }

        timeout = aiohttp.ClientTimeout(total=30.0)
        try:
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get(url, headers=headers) as resp:
                    if resp.status == 200 or resp.status == 206:
                        data = await resp.read()
                        ok, data, error = self._maybe_decompress(chunk_addr.chunk_id, data)
                        if not ok:
                            return FetchResult(
                                chunk_id=chunk_addr.chunk_id,
                                success=False,
                                error=error,
                            )

                        return FetchResult(
                            chunk_id=chunk_addr.chunk_id,
                            success=True,
                            data=data,
                            duration_ms=0,
                            bytes_transferred=len(data),
                            from_cache=False,
                        )
                    if resp.status == 429:
                        return FetchResult(
                            chunk_id=chunk_addr.chunk_id,
                            success=False,
                            error="Rate limited (429)",
                        )
                    if resp.status >= 500:
                        return FetchResult(
                            chunk_id=chunk_addr.chunk_id,
                            success=False,
                            error=f"Server error (HTTP {resp.status})",
                        )
                    return FetchResult(
                        chunk_id=chunk_addr.chunk_id,
                        success=False,
                        error=f"HTTP {resp.status}",
                    )
        except asyncio.TimeoutError:
            return FetchResult(
                chunk_id=chunk_addr.chunk_id,
                success=False,
                error="Request timed out",
            )
        except aiohttp.ClientError as exc:
            return FetchResult(
                chunk_id=chunk_addr.chunk_id,
                success=False,
                error=f"Network error: {exc}",
            )

    def update_backpressure(self, cache_fill_fraction: float) -> None:
        """Update backpressure state based on cache fill level.

        Args:
            cache_fill_fraction: Current cache utilization (0.0-1.0).
        """
        if cache_fill_fraction >= self._backpressure_threshold:
            if self._backpressure_event.is_set():
                self._backpressure_event.clear()
                self._log.info(
                    "backpressure_activated",
                    fill_fraction=cache_fill_fraction,
                    threshold=self._backpressure_threshold,
                )
                self._aggregate.backpressure_pause_count += 1
        else:
            if not self._backpressure_event.is_set():
                self._backpressure_event.set()
                self._log.info(
                    "backpressure_released",
                    fill_fraction=cache_fill_fraction,
                )

    def emit_prefetch_metrics(self) -> dict[str, Any]:
        """Return a dict of aggregate prefetch metrics.

        Returns:
            Dictionary with all prefetch metrics.
        """
        agg = self._aggregate
        avg_duration = (
            agg.total_duration_ms / agg.total_fetches
            if agg.total_fetches > 0
            else 0.0
        )
        avg_bandwidth = (
            (agg.total_bytes_transferred * 8) / (agg.total_duration_ms / 1000) / 1e6
            if agg.total_duration_ms > 0
            else 0.0
        )
        return {
            "total_fetches": agg.total_fetches,
            "successful_fetches": agg.successful_fetches,
            "failed_fetches": agg.failed_fetches,
            "cache_hits": agg.cache_hits,
            "total_bytes_transferred": agg.total_bytes_transferred,
            "total_duration_ms": round(agg.total_duration_ms, 2),
            "average_duration_ms": round(avg_duration, 2),
            "average_bandwidth_mbps": round(avg_bandwidth, 2),
            "retry_count": agg.retry_count,
            "cancelled_count": agg.cancelled_count,
            "backpressure_pause_count": agg.backpressure_pause_count,
            "queue_size": self._queue.qsize(),
        }

    @property
    def queue_size(self) -> int:
        """Current number of pending requests in the queue."""
        return self._queue.qsize()

    @property
    def is_running(self) -> bool:
        """Whether the prefetcher is currently running."""
        return self._running


if __name__ == "__main__":
    import asyncio

    async def _demo() -> None:
        from rex.core.types import ByteRange

        print("=== AsyncPrefetcher Demo ===\n")

        # Create a prefetcher (won't actually fetch without a server)
        prefetcher = AsyncPrefetcher(
            storage_base_url="http://localhost:8080/models",
            max_concurrent_fetches=2,
            max_retries=2,
        )

        # Start
        await prefetcher.start()
        assert prefetcher.is_running

        # Enqueue some chunks
        for i in range(5):
            addr = ChunkAddress(
                chunk_id=f"chunk_{i}",
                resource_id="model_weights.bin",
                byte_range=ByteRange(start=i * 1024, end=(i + 1) * 1024),
            )
            priority = ChunkPriority.HIGH if i == 0 else ChunkPriority.LOW
            prefetcher.enqueue(addr, priority=priority)

        print(f"Queue size: {prefetcher.queue_size}")

        # Wait a bit for processing (will fail without server)
        await asyncio.sleep(0.5)

        # Metrics
        metrics = prefetcher.emit_prefetch_metrics()
        print(f"Metrics: {metrics}")

        # Backpressure test
        prefetcher.update_backpressure(0.95)
        prefetcher.update_backpressure(0.5)

        # Stop
        await prefetcher.stop()
        assert not prefetcher.is_running

        print("\n=== Demo completed! ===")

    asyncio.run(_demo())
