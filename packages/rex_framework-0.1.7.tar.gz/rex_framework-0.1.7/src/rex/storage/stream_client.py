"""WebSocket streaming storage backend for Rex.

This backend keeps a persistent WebSocket open to the Rex chunk server
and receives chunk payloads as framed binary messages.
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import struct
from pathlib import Path

import aiohttp
import structlog

from rex.core.errors import StorageUnavailableError
from rex.storage.base import BackendCapabilities, BaseStorageBackend, ResourceStat

log = structlog.get_logger(__name__)

_STREAM_VERSION = 1
_HEADER_FMT = "!BHQ"
_HEADER_SIZE = struct.calcsize(_HEADER_FMT)


class StreamingBackend(BaseStorageBackend):
    """Persistent WebSocket client that receives chunks as a live stream."""

    def __init__(
        self,
        base_url: str,
        *,
        auth_token: str | None = None,
        timeout_connect: float = 10.0,
        timeout_read: float = 60.0,
    ) -> None:
        super().__init__()
        self._base_url = base_url.rstrip("/")
        self._auth_token = auth_token
        self._timeout = aiohttp.ClientTimeout(
            total=timeout_read + timeout_connect,
            connect=timeout_connect,
        )
        self._session: aiohttp.ClientSession | None = None
        self._ws: aiohttp.ClientWebSocketResponse | None = None
        self._reader_task: asyncio.Task[None] | None = None
        self._closed = False
        self._eof = asyncio.Event()
        self._chunk_data: dict[str, bytes] = {}
        self._chunk_waiters: dict[str, list[asyncio.Future[bytes]]] = {}
        self._resource_to_chunk_id: dict[str, str] = {}
        self._resource_sizes: dict[str, int] = {}
        self._resource_etags: dict[str, str] = {}
        self._requested_chunk_ids: set[str] = set()

    def _headers(self) -> dict[str, str]:
        headers: dict[str, str] = {}
        if self._auth_token:
            headers["Authorization"] = f"Bearer {self._auth_token}"
        return headers

    def _resource_key(self, resource_id: str) -> str:
        if resource_id in self._resource_to_chunk_id:
            return resource_id
        basename = Path(resource_id).name
        if basename in self._resource_to_chunk_id:
            return basename
        return basename

    def _chunk_id_for_resource(self, resource_id: str) -> str:
        key = self._resource_key(resource_id)
        return self._resource_to_chunk_id.get(key, key)

    async def connect(
        self,
        manifest_id: str = "",
        wanted_chunks: list[str] | None = None,
        chunk_lookup: dict[str, str] | None = None,
    ) -> None:
        """Open the WebSocket and start the background reader."""
        if self._closed:
            raise RuntimeError("Backend is closed")

        if chunk_lookup:
            self._resource_to_chunk_id.update(
                {str(key): str(value) for key, value in chunk_lookup.items()}
            )

        headers = self._headers()
        self._session = aiohttp.ClientSession(timeout=self._timeout, headers=headers)
        ws_url = f"{self._base_url}/ws/stream"

        try:
            self._ws = await self._session.ws_connect(ws_url)
        except aiohttp.WSServerHandshakeError as exc:
            raise StorageUnavailableError(
                f"Cannot connect to stream at {ws_url}: {exc}"
            ) from exc

        self._requested_chunk_ids = set(wanted_chunks or [])
        payload = json.dumps(
            {
                "manifest_id": manifest_id,
                "chunks": wanted_chunks or [],
            }
        )
        await self._ws.send_str(payload)
        self._reader_task = asyncio.create_task(self._reader_loop())
        log.info("streaming_backend_connected", url=ws_url)

    async def _reader_loop(self) -> None:
        """Background task that demuxes incoming frames into chunk buffers."""
        try:
            assert self._ws is not None
            async for msg in self._ws:
                if msg.type == aiohttp.WSMsgType.BINARY:
                    await self._on_binary(msg.data)
                elif msg.type in (aiohttp.WSMsgType.CLOSED, aiohttp.WSMsgType.ERROR):
                    break
        except asyncio.CancelledError:
            pass
        finally:
            self._eof.set()
            self._flush_waiters(RuntimeError("stream closed"))
            log.debug("streaming_reader_loop_exited")

    def _flush_waiters(self, exc: Exception) -> None:
        for waiters in self._chunk_waiters.values():
            for fut in waiters:
                if not fut.done():
                    fut.set_exception(exc)
        self._chunk_waiters.clear()

    async def _on_binary(self, data: bytes) -> None:
        if len(data) < _HEADER_SIZE:
            log.warning("short_binary_frame", size=len(data))
            return

        version, id_len, data_len = struct.unpack(_HEADER_FMT, data[:_HEADER_SIZE])
        if version != _STREAM_VERSION:
            log.warning("unknown_stream_version", version=version)
            return

        if id_len == 0 and data_len == 0:
            self._eof.set()
            return

        expected = _HEADER_SIZE + id_len + data_len
        if len(data) != expected:
            log.warning("frame_size_mismatch", expected=expected, actual=len(data))
            return

        chunk_id = data[_HEADER_SIZE : _HEADER_SIZE + id_len].decode("utf-8")
        chunk_data = data[_HEADER_SIZE + id_len :]
        self._chunk_data[chunk_id] = chunk_data

        waiters = self._chunk_waiters.pop(chunk_id, [])
        for fut in waiters:
            if not fut.done():
                fut.set_result(chunk_data)

    async def fetch_range(
        self,
        resource_id: str,
        start: int,
        end: int,
    ) -> bytes:
        """Return bytes for the requested chunk from the live stream."""
        if start < 0 or end <= start:
            raise ValueError(f"Invalid byte range: [{start}, {end})")

        chunk_id = self._chunk_id_for_resource(resource_id)
        cached = self._chunk_data.get(chunk_id)
        if cached is not None:
            return cached[start:end]

        loop = asyncio.get_running_loop()
        fut: asyncio.Future[bytes] = loop.create_future()
        self._chunk_waiters.setdefault(chunk_id, []).append(fut)

        try:
            data = await asyncio.wait_for(fut, timeout=self._timeout.total or 60.0)
        except asyncio.TimeoutError as exc:
            raise StorageUnavailableError(
                f"Timed out waiting for streamed chunk '{chunk_id}'"
            ) from exc

        return data[start:end]

    async def stat(self, resource_id: str) -> ResourceStat:
        chunk_id = self._chunk_id_for_resource(resource_id)
        cached = self._chunk_data.get(chunk_id)
        size = len(cached) if cached is not None else 0
        return ResourceStat(
            size=size,
            etag=self._resource_etags.get(chunk_id, ""),
            content_type="application/octet-stream",
        )

    async def health_check(self) -> bool:
        return bool(self._ws is not None and not self._ws.closed)

    def auth_requirements(self) -> list[str]:
        return ["AUTH_TOKEN"] if self._auth_token else []

    def capabilities(self) -> BackendCapabilities:
        return BackendCapabilities(
            supports_range_requests=True,
            supports_multi_range=False,
            max_concurrent_requests=1,
            max_request_size_bytes=0,
            rate_limit_rpm=0,
        )

    async def close(self) -> None:
        self._closed = True
        self._eof.set()
        if self._reader_task is not None:
            self._reader_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._reader_task
            self._reader_task = None
        if self._ws is not None and not self._ws.closed:
            await self._ws.close()
        if self._session is not None and not self._session.closed:
            await self._session.close()
        self._ws = None
        self._session = None
        log.info("streaming_backend_closed")
