"""WebSocket streaming server for Rex chunk files.

The server exposes a persistent binary stream endpoint that can push
chunk payloads over a single socket instead of requiring a fresh HTTP
request per chunk.
"""

from __future__ import annotations

import asyncio
import json
import struct
from dataclasses import dataclass
from pathlib import Path

import aiohttp
import structlog
from aiohttp import web

from rex.formats.manifest import load_manifest
from rex.storage.local_server import FaultInjector

log = structlog.get_logger(__name__)

_STREAM_VERSION = 1
_HEADER_FMT = "!BHQ"  # version, chunk_id_len, data_len
_HEADER_SIZE = struct.calcsize(_HEADER_FMT)


@dataclass(frozen=True)
class _ChunkRecord:
    chunk_id: str
    resource_key: str
    file_path: Path


class StreamServer:
    """WebSocket chunk streamer attached to an existing aiohttp app."""

    def __init__(
        self,
        chunk_dir: str,
        *,
        manifest_path: str | None = None,
        faults: FaultInjector | None = None,
        bandwidth_mbps: float = 0.0,
    ) -> None:
        self._chunk_dir = Path(chunk_dir).resolve()
        self._manifest_path = self._resolve_manifest_path(manifest_path)
        self._manifest = (
            load_manifest(str(self._manifest_path))
            if self._manifest_path is not None
            else None
        )
        self._faults = faults or FaultInjector.disabled()
        self._bandwidth_mbps = bandwidth_mbps
        self._clients: set[web.WebSocketResponse] = set()
        self._records = self._build_chunk_records()
        self._records_by_key = {
            record.chunk_id: record for record in self._records
        }
        self._records_by_resource = {
            record.resource_key: record for record in self._records
        }

    def register(self, app: web.Application) -> None:
        app.router.add_get("/ws/stream", self._handle_ws)

    def _resolve_manifest_path(self, manifest_path: str | None) -> Path | None:
        candidates: list[Path] = []
        if manifest_path:
            candidates.append(Path(manifest_path))
        candidates.append(self._chunk_dir / "manifest.json")
        candidates.append(self._chunk_dir.parent / "manifest.json")

        for candidate in candidates:
            if candidate.is_file():
                return candidate.resolve()
        return None

    def _build_chunk_records(self) -> list[_ChunkRecord]:
        records: list[_ChunkRecord] = []
        if self._manifest is None:
            for file_path in sorted(self._chunk_dir.rglob("*.bin")):
                if file_path.is_file():
                    records.append(
                        _ChunkRecord(
                            chunk_id=file_path.name,
                            resource_key=file_path.name,
                            file_path=file_path.resolve(),
                        )
                    )
            return records

        for td in self._manifest.parameters.values():
            for addr in td.chunk_addresses:
                file_path = Path(addr.resource_id)
                if not file_path.is_file():
                    file_path = self._chunk_dir / Path(addr.resource_id).name
                records.append(
                    _ChunkRecord(
                        chunk_id=addr.chunk_id,
                        resource_key=Path(addr.resource_id).name,
                        file_path=file_path.resolve(),
                    )
                )
        return records

    def _requested_records(self, requested: list[str]) -> list[_ChunkRecord]:
        if not requested:
            return list(self._records)

        chosen: list[_ChunkRecord] = []
        for item in requested:
            record = self._records_by_key.get(item)
            if record is None:
                record = self._records_by_resource.get(Path(item).name)
            if record is not None:
                chosen.append(record)
        return chosen

    async def _handle_ws(self, request: web.Request) -> web.WebSocketResponse:
        ws = web.WebSocketResponse(
            heartbeat=30.0,
            autoping=True,
            max_msg_size=256 * 1024 * 1024,
        )
        await ws.prepare(request)
        self._clients.add(ws)
        log.info("ws_client_connected", num_clients=len(self._clients))

        try:
            async for msg in ws:
                if msg.type == aiohttp.WSMsgType.TEXT:
                    await self._push_requested(ws, msg.data)
                elif msg.type == aiohttp.WSMsgType.ERROR:
                    log.warning("ws_error", exception=ws.exception())
        finally:
            self._clients.discard(ws)
            log.info("ws_client_disconnected", num_clients=len(self._clients))

        return ws

    async def _push_requested(
        self,
        ws: web.WebSocketResponse,
        request_payload: str,
    ) -> None:
        try:
            req = json.loads(request_payload)
            requested = list(req.get("chunks", []))
        except json.JSONDecodeError:
            requested = []

        records = self._requested_records(requested)
        log.info("ws_push_start", total_files=len(records))

        for record in records:
            if not record.file_path.is_file():
                log.warning(
                    "ws_chunk_missing",
                    chunk_id=record.chunk_id,
                    path=str(record.file_path),
                )
                continue

            data = record.file_path.read_bytes()
            chunk_id_bytes = record.chunk_id.encode("utf-8")
            header = struct.pack(_HEADER_FMT, _STREAM_VERSION, len(chunk_id_bytes), len(data))
            await ws.send_bytes(header + chunk_id_bytes + data)

            if self._bandwidth_mbps > 0:
                bits = len(data) * 8
                delay = bits / (self._bandwidth_mbps * 1_000_000)
                await asyncio.sleep(delay)

        await ws.send_bytes(struct.pack(_HEADER_FMT, _STREAM_VERSION, 0, 0))
        log.info("ws_push_complete")


def attach_stream_routes(
    app: web.Application,
    chunk_dir: str,
    *,
    manifest_path: str | None = None,
    faults: FaultInjector | None = None,
    bandwidth_mbps: float = 0.0,
) -> None:
    """Attach the WebSocket stream route to an existing aiohttp app."""
    streamer = StreamServer(
        chunk_dir,
        manifest_path=manifest_path,
        faults=faults,
        bandwidth_mbps=bandwidth_mbps,
    )
    streamer.register(app)
