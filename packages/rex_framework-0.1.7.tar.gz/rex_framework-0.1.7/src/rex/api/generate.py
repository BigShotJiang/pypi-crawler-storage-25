"""Public API for running Rex inference.

Status: Implemented

Provides the rex.run_inference() entry point.
"""

from __future__ import annotations

import asyncio
import concurrent.futures
import contextlib
from typing import TYPE_CHECKING, Any

from rex.api.load import _shutdown_runtime_sync, load_model

if TYPE_CHECKING:
    from rex.api.config import RexConfig
    from rex.core.runtime import RexRuntime
    from rex.core.types import InferenceMetrics


async def run_inference(
    runtime: RexRuntime,
    input_data: Any,
) -> tuple[Any, InferenceMetrics]:
    """Run inference on a loaded Rex model.

    Args:
        runtime: RexRuntime instance from load_model().
        input_data: Input tensor or data for the model.

    Returns:
        Tuple of (model_output, inference_metrics).

    Example:
        runtime = rex.load_model("./rex_model/manifest.json")
        output, metrics = await rex.run_inference(runtime, input_tensor)
        print(f"Cache hits: {metrics.cache_hits}, misses: {metrics.cache_misses}")
    """
    return await runtime.run_inference(input_data)


def run_inference_sync(
    manifest_path: str,
    input_data: Any,
    config: RexConfig | None = None,
    **kwargs,
) -> tuple[Any, InferenceMetrics]:
    """Synchronous wrapper for running inference.

    Convenience function that loads a model and runs inference in one call.

    Args:
        manifest_path: Path to manifest.json.
        input_data: Input tensor.
        config: Optional RexConfig.
        **kwargs: Additional config overrides.

    Returns:
        Tuple of (model_output, inference_metrics).

    Example:
        output, metrics = rex.run_inference_sync(
            "./rex_model/manifest.json", input_tensor
        )
    """
    runtime = load_model(manifest_path, config, **kwargs)

    async def _run():
        return await runtime.run_inference(input_data)

    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    try:
        if loop and loop.is_running():
            with concurrent.futures.ThreadPoolExecutor() as pool:
                return pool.submit(asyncio.run, _run()).result()
        return asyncio.run(_run())
    finally:
        with contextlib.suppress(Exception):
            _shutdown_runtime_sync(runtime)
