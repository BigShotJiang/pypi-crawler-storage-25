"""Public API exports for Rex."""

from rex.api.generate import run_inference, run_inference_sync
from rex.api.load import load_model

__all__ = [
    "load_model",
    "run_inference",
    "run_inference_sync",
]
