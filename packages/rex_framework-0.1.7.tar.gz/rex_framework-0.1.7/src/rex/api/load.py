"""Public API for loading Rex models.

Status: Implemented

Provides the rex.load_model() entry point.
"""

from __future__ import annotations

import asyncio
import concurrent.futures
import contextlib
import weakref

from rex.api.config import RexConfig
from rex.core.runtime import RexRuntime
from rex.formats.manifest import (
    load_manifest,
    pretty_print_manifest,
    validate_manifest,
)


def _shutdown_runtime_sync(runtime: RexRuntime) -> None:
    """Run ``runtime.shutdown()`` from synchronous code."""
    async def _shutdown() -> None:
        await runtime.shutdown()

    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    if loop and loop.is_running():
        with concurrent.futures.ThreadPoolExecutor() as pool:
            pool.submit(asyncio.run, _shutdown()).result()
    else:
        asyncio.run(_shutdown())


def _register_runtime_cleanup(runtime: RexRuntime) -> None:
    """Best-effort cleanup for runtimes returned by the sync loader."""
    runtime_ref = weakref.ref(runtime)

    def _cleanup() -> None:
        runtime_obj = runtime_ref()
        if runtime_obj is None or not getattr(runtime_obj, "_model_loaded", False):
            return
        with contextlib.suppress(Exception):
            _shutdown_runtime_sync(runtime_obj)

    weakref.finalize(runtime, _cleanup)


def load_model(
    manifest_path: str,
    config: RexConfig | None = None,
    **kwargs,
) -> RexRuntime:
    """Load a Rex model from a manifest file.

    This loads only the manifest (small metadata file). Model weights
    are NOT downloaded; they remain on remote storage and are fetched
    on demand during inference.

    Args:
        manifest_path: Path to the manifest.json file.
        config: Optional RexConfig. If None, uses defaults.
        **kwargs: Override config fields (e.g., storage_url="http://...").

    Returns:
        RexRuntime instance ready for inference.

    Raises:
        FileNotFoundError: If manifest file does not exist.
        ManifestValidationError: If manifest is invalid.

    Example:
        from rex.api import load_model

        runtime = load_model("./rex_model/manifest.json")
        result = runtime.run_inference(input_tensor)
    """
    if config is None:
        config = RexConfig()

    # Apply kwargs overrides
    for key, value in kwargs.items():
        if key == "storage_url" and value:
            config.storage.base_url = value
        elif key == "cache_size_mb" and value:
            config.cache.max_memory_cache_bytes = int(value) * 1024 * 1024
        elif key == "auth_token" and value:
            config.storage.auth_token = value

    runtime = RexRuntime(config=config)

    async def _load() -> None:
        await runtime.load_model(manifest_path)

    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    if loop and loop.is_running():
        with concurrent.futures.ThreadPoolExecutor() as pool:
            pool.submit(asyncio.run, _load()).result()
    else:
        asyncio.run(_load())

    _register_runtime_cleanup(runtime)
    return runtime


def inspect_manifest(manifest_path: str) -> str:
    """Load and pretty-print a Rex manifest.

    Args:
        manifest_path: Path to manifest.json.

    Returns:
        Human-readable manifest summary.
    """
    manifest = load_manifest(manifest_path)
    return pretty_print_manifest(manifest)


def validate_model(manifest_path: str) -> list[str]:
    """Validate a Rex manifest and return errors.

    Args:
        manifest_path: Path to manifest.json.

    Returns:
        List of validation error strings. Empty if valid.
    """
    try:
        manifest = load_manifest(manifest_path)
    except Exception as e:
        return [f"Failed to load manifest: {e}"]

    return validate_manifest(manifest)
