"""
Rex Framework — Remote Executable eXecution.

Inference with remotely-stored model weights.
"""

__version__ = "0.1.7"
__status__ = "Alpha"

from rex.api.config import RexConfig
from rex.api.generate import run_inference, run_inference_sync
from rex.api.load import load_model

__all__ = [
    "RexConfig",
    "load_model",
    "run_inference",
    "run_inference_sync",
]
