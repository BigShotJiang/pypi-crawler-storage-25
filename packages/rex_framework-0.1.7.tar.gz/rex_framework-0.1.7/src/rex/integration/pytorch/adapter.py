"""Compatibility shim for legacy PyTorch adapter imports."""

from __future__ import annotations

from rex.integration.pytorch.module_wrapper import *  # noqa: F401,F403

