"""Unit tests for redesign section 4/5 planning helpers."""

from rex.cache.policies import CacheEntry, ProbabilisticUtilityPolicy
from rex.cache.predictor import EMABayesianReusePredictor
from rex.core.cost_model import ChunkCostModel
from rex.core.prefetch_optimizer import PrefetchCandidate, plan_prefetch


class TestReusePredictor:
    def test_probability_moves_with_observations(self):
        predictor = EMABayesianReusePredictor()
        baseline = predictor.predict_reuse_probability("c1")
        predictor.observe_access("c1", reused=True)
        predictor.observe_access("c1", reused=True)
        predictor.observe_access("c1", reused=False)
        assert predictor.predict_reuse_probability("c1") != baseline


class TestProbabilisticUtilityPolicy:
    def test_selects_lowest_expected_value_density(self):
        predictor = EMABayesianReusePredictor()
        predictor.observe_access("keep", reused=True)
        predictor.observe_access("keep", reused=True)
        predictor.observe_access("drop", reused=False)

        cost_model = ChunkCostModel(
            latency_ms={"keep": 100.0, "drop": 5.0},
            size_bytes={"keep": 100, "drop": 100},
        )
        policy = ProbabilisticUtilityPolicy(predictor=predictor, cost_model=cost_model)
        candidates = {
            "keep": CacheEntry("keep", b"x" * 100),
            "drop": CacheEntry("drop", b"y" * 100),
        }
        assert policy.select_victim(candidates) == "drop"


class TestPrefetchOptimizer:
    def test_selects_best_subset_under_budget(self):
        candidates = [
            PrefetchCandidate("a", size_bytes=10, probability=0.9, estimated_latency_ms=10.0),
            PrefetchCandidate("b", size_bytes=15, probability=0.5, estimated_latency_ms=5.0),
            PrefetchCandidate("c", size_bytes=100, probability=1.0, estimated_latency_ms=1.0),
        ]
        planned = plan_prefetch(candidates, budget_bytes=30)
        assert [c.chunk_id for c in planned] == ["a", "b"]