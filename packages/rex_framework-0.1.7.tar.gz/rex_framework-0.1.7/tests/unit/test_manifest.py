"""Unit tests for manifest format."""
import json
import pytest
from pathlib import Path
from rex.core.types import (
    RexManifest, TensorDescriptor, ByteRange, ChunkAddress,
    CompressionCodec, StorageBackendType, CacheConstraints,
)
from rex.formats.manifest import (
    ManifestSerializer, validate_manifest, save_manifest, load_manifest,
    pretty_print_manifest, SUPPORTED_VERSIONS,
)
from rex.core.errors import ManifestValidationError


def _make_sample_manifest() -> RexManifest:
    td = TensorDescriptor(
        name="layer0.w_q",
        shape=(16, 16),
        dtype="float32",
        num_chunks=1,
        total_bytes=1024,
        chunk_addresses=[
            ChunkAddress("weights/layer0.w_q.0000.bin", ByteRange(0, 1024), "layer0.w_q.0000"),
        ],
    )
    return RexManifest(
        manifest_version="0.1.0",
        model_id="test-model",
        model_family="demo",
        source_framework="pytorch",
        parameters={"layer0.w_q": td},
        execution_graph=["layer0.w_q"],
        total_model_bytes=1024,
        total_chunks=1,
    )


class TestManifestSerialization:
    def test_roundtrip(self):
        m = _make_sample_manifest()
        data = ManifestSerializer.serialize(m)
        m2 = ManifestSerializer.deserialize(data)
        assert m2.model_id == m.model_id
        assert m2.manifest_version == m.manifest_version
        assert "layer0.w_q" in m2.parameters

    def test_serialization_is_valid_json(self):
        m = _make_sample_manifest()
        data = ManifestSerializer.serialize(m)
        parsed = json.loads(data)
        assert parsed["model_id"] == "test-model"
        assert "created_at" in parsed


class TestManifestValidation:
    def test_valid_manifest(self):
        m = _make_sample_manifest()
        errors = validate_manifest(m)
        assert errors == []

    def test_empty_params(self):
        m = RexManifest(manifest_version="0.1.0", model_id="t", model_family="d", source_framework="pytorch")
        # Empty params is technically valid
        errors = validate_manifest(m)
        assert errors == []

    def test_bad_version(self):
        m = _make_sample_manifest()
        m.manifest_version = "99.0.0"
        errors = validate_manifest(m)
        assert any("version" in e.lower() for e in errors)

    def test_chunk_count_mismatch(self):
        m = _make_sample_manifest()
        td = m.parameters["layer0.w_q"]
        td.num_chunks = 5  # Wrong
        errors = validate_manifest(m)
        assert any("num_chunks" in e for e in errors)

    def test_exec_graph_references_unknown(self):
        m = _make_sample_manifest()
        m.execution_graph = ["nonexistent_param"]
        errors = validate_manifest(m)
        assert any("nonexistent_param" in e for e in errors)

    def test_invalid_cache_fraction(self):
        m = _make_sample_manifest()
        m.cache_constraints.max_local_fraction_of_model = 1.5
        errors = validate_manifest(m)
        assert any("fraction" in e for e in errors)


class TestManifestFileIO:
    def test_save_and_load(self, tmp_path):
        m = _make_sample_manifest()
        path = tmp_path / "manifest.json"
        save_manifest(m, path)
        loaded = load_manifest(path)
        assert loaded.model_id == "test-model"

    def test_load_nonexistent(self):
        with pytest.raises(FileNotFoundError):
            load_manifest("/nonexistent/manifest.json")

    def test_pretty_print(self):
        m = _make_sample_manifest()
        output = pretty_print_manifest(m)
        assert "test-model" in output
        assert "layer0.w_q" in output


class TestManifestFromDict:
    def test_missing_required_fields(self):
        with pytest.raises(ManifestValidationError):
            ManifestSerializer.from_dict({"model_id": "t"})  # Missing required fields

    def test_defaults_applied(self):
        d = {
            "manifest_version": "0.1.0",
            "model_id": "t",
            "model_family": "d",
            "source_framework": "pytorch",
        }
        m = ManifestSerializer.from_dict(d)
        assert m.cache_constraints.max_local_fraction_of_model == 0.4
        assert m.storage_backend == StorageBackendType.HTTP_RANGE
