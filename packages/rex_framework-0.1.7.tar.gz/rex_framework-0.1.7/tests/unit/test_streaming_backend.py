from __future__ import annotations

import json

import pytest
from aiohttp import web

from rex.api.config import RexConfig
from rex.core.runtime import RexRuntime
from rex.core.types import (
    ByteRange,
    CacheConstraints,
    ChunkAddress,
    RexManifest,
    StorageBackendType,
    TensorDescriptor,
)
from rex.storage import local_server
from rex.storage.http_range import HTTPRangeBackend
from rex.storage.stream_client import StreamingBackend
from rex.storage.stream_server import StreamServer


@pytest.mark.asyncio
async def test_streaming_backend_fetches_chunk(tmp_path):
    weights_dir = tmp_path / "weights"
    weights_dir.mkdir()
    chunk_path = weights_dir / "layer.weight.0000.bin"
    chunk_bytes = b"stream-test-payload"
    chunk_path.write_bytes(chunk_bytes)

    class _FakeWebSocket:
        def __init__(self) -> None:
            self.frames: list[bytes] = []

        async def send_bytes(self, data: bytes) -> None:
            self.frames.append(data)

    server = StreamServer(
        chunk_dir=str(weights_dir),
    )
    backend = StreamingBackend(base_url="http://127.0.0.1:0")
    try:
        chunk_key = chunk_path.name
        fake_ws = _FakeWebSocket()
        await server._push_requested(
            fake_ws,
            json.dumps(
                {
                    "manifest_id": "stream-test",
                    "chunks": [chunk_key],
                }
            ),
        )

        backend._resource_to_chunk_id.update({chunk_key: chunk_key})
        for frame in fake_ws.frames:
            await backend._on_binary(frame)

        streamed = await backend.fetch_range(chunk_key, 0, len(chunk_bytes))
        assert streamed == chunk_bytes
    finally:
        await backend.close()


def test_streaming_env_override(monkeypatch):
    monkeypatch.setenv("REX_ENABLE_STREAMING", "true")
    config = RexConfig()
    assert config.storage.enable_streaming is True


@pytest.mark.asyncio
async def test_runtime_uses_http_range_backend_for_http_range(monkeypatch):
    manifest = RexManifest(
        manifest_version="1.0.0",
        model_id="runtime-stream-test",
        model_family="unit-test",
        source_framework="pytorch",
        parameters={
            "layer.weight": TensorDescriptor(
                name="layer.weight",
                shape=(4, 4),
                dtype="float32",
                num_chunks=1,
                chunk_addresses=[
                    ChunkAddress(
                        chunk_id="layer.weight.0000",
                        resource_id="layer.weight.0000.bin",
                        byte_range=ByteRange(start=0, end=16),
                    ),
                ],
                total_bytes=16,
            ),
        },
        total_model_bytes=16,
        total_chunks=1,
        cache_constraints=CacheConstraints(),
        execution_graph=["layer.weight"],
    )

    async def _fake_load_manifest(_path: str) -> RexManifest:
        return manifest

    monkeypatch.setattr("rex.core.runtime.load_manifest", _fake_load_manifest)

    config = RexConfig()
    config.storage.base_url = "http://127.0.0.1:0"
    runtime = RexRuntime(config=config)
    try:
        await runtime.load_model("dummy-manifest.json")
        assert isinstance(runtime.storage, HTTPRangeBackend)
        assert runtime.prefetcher is not None
        assert runtime.prefetcher._storage_backend is runtime.storage
    finally:
        await runtime.shutdown()


@pytest.mark.asyncio
async def test_runtime_uses_streaming_backend_for_streaming_ws(monkeypatch):
    manifest = RexManifest(
        manifest_version="1.0.0",
        model_id="runtime-streaming-ws-test",
        model_family="unit-test",
        source_framework="pytorch",
        parameters={
            "layer.weight": TensorDescriptor(
                name="layer.weight",
                shape=(4, 4),
                dtype="float32",
                num_chunks=1,
                chunk_addresses=[
                    ChunkAddress(
                        chunk_id="layer.weight.0000",
                        resource_id="layer.weight.0000.bin",
                        byte_range=ByteRange(start=0, end=16),
                    ),
                ],
                total_bytes=16,
            ),
        },
        total_model_bytes=16,
        total_chunks=1,
        cache_constraints=CacheConstraints(),
        execution_graph=["layer.weight"],
    )

    async def _fake_connect(_self, *_, **__):
        return None

    async def _fake_load_manifest(_path: str) -> RexManifest:
        return manifest

    monkeypatch.setattr(StreamingBackend, "connect", _fake_connect)
    monkeypatch.setattr("rex.core.runtime.load_manifest", _fake_load_manifest)

    config = RexConfig()
    config.storage.base_url = "http://127.0.0.1:0"
    config.storage.backend_type = StorageBackendType.STREAMING_WS
    runtime = RexRuntime(config=config)
    try:
        await runtime.load_model("dummy-manifest.json")
        assert isinstance(runtime.storage, StreamingBackend)
        assert runtime.prefetcher is not None
        assert runtime.prefetcher._storage_backend is runtime.storage
    finally:
        await runtime.shutdown()


@pytest.mark.asyncio
async def test_local_server_always_registers_stream_route(monkeypatch, tmp_path):
    chunk_dir = tmp_path / "weights"
    chunk_dir.mkdir()

    observed_paths: list[str] = []

    real_add_get = web.UrlDispatcher.add_get

    def _recording_add_get(self, path, handler, **kwargs):
        observed_paths.append(path)
        return real_add_get(self, path, handler, **kwargs)

    class _DummyRunner:
        def __init__(self, app) -> None:
            self.app = app

        async def setup(self) -> None:
            return None

        async def cleanup(self) -> None:
            return None

    class _DummySite:
        def __init__(self, runner, host, port) -> None:
            self.runner = runner
            self.host = host
            self.port = port

        async def start(self) -> None:
            return None

    monkeypatch.setattr(web.UrlDispatcher, "add_get", _recording_add_get)
    monkeypatch.setattr(local_server.web, "AppRunner", _DummyRunner)
    monkeypatch.setattr(local_server.web, "TCPSite", _DummySite)
    monkeypatch.setattr(local_server, "_server_runner", None)
    monkeypatch.setattr(local_server, "_server_site", None)

    try:
        await local_server.start_server(
            host="127.0.0.1",
            port=0,
            chunk_dir=str(chunk_dir),
            stream=False,
            stream_bandwidth=0.0,
        )
        assert "/ws/stream" in observed_paths
    finally:
        await local_server.stop_server()
