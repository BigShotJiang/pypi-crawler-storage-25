"""Unit tests for the Scheduler."""
import pytest

from rex.core.errors import SchedulerError
from rex.core.scheduler import NetworkConditions, Scheduler
from rex.core.types import ByteRange, ChunkAddress, ChunkPriority


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_GRAPH = [
    "layer_0.weight",
    "layer_0.bias",
    "layer_1.weight",
    "layer_1.bias",
    "layer_2.weight",
]


def _make_chunk_addr(chunk_id: str) -> ChunkAddress:
    return ChunkAddress(
        chunk_id=chunk_id,
        resource_id="model.bin",
        byte_range=ByteRange(start=0, end=1024),
    )


def _make_chunk_lookup(graph: list[str] | None = None) -> dict[str, list[ChunkAddress]]:
    g = graph or _GRAPH
    return {name: [_make_chunk_addr(f"{name}.0")] for name in g}


def _make_scheduler(
    graph: list[str] | None = None,
    window: int = 3,
    adaptive: bool = True,
) -> tuple[Scheduler, dict[str, list[ChunkAddress]]]:
    g = graph or _GRAPH
    lookup = _make_chunk_lookup(g)
    s = Scheduler(
        execution_graph=g,
        chunk_lookup=lookup,
        prefetch_window=window,
        adaptive_window=adaptive,
    )
    return s, lookup


# ---------------------------------------------------------------------------
# plan_next_step
# ---------------------------------------------------------------------------


class TestPlanNextStep:
    def test_returns_correct_chunks(self):
        scheduler, _ = _make_scheduler()
        chunks = scheduler.plan_next_step(current_position=0)
        assert len(chunks) == 1
        assert chunks[0].chunk_id == "layer_0.weight.0"

    def test_at_end_returns_empty(self):
        scheduler, _ = _make_scheduler()
        chunks = scheduler.plan_next_step(current_position=5)
        assert chunks == []

    def test_out_of_range_returns_empty(self):
        scheduler, _ = _make_scheduler()
        chunks = scheduler.plan_next_step(current_position=99)
        assert chunks == []

    def test_negative_position_returns_empty(self):
        scheduler, _ = _make_scheduler()
        chunks = scheduler.plan_next_step(current_position=-1)
        assert chunks == []


# ---------------------------------------------------------------------------
# peek_ahead
# ---------------------------------------------------------------------------


class TestPeekAhead:
    def test_returns_future_chunks(self):
        scheduler, _ = _make_scheduler(window=3)
        # At position 0, peek ahead should show positions 1, 2, 3
        ahead = scheduler.peek_ahead(current_position=0)
        ids = [c.chunk_id for c in ahead]
        assert "layer_0.bias.0" in ids
        assert "layer_1.weight.0" in ids
        assert "layer_1.bias.0" in ids
        assert "layer_0.weight.0" not in ids  # current step excluded

    def test_does_not_include_current_step(self):
        scheduler, _ = _make_scheduler(window=3)
        current = scheduler.plan_next_step(current_position=0)
        ahead = scheduler.peek_ahead(current_position=0)
        for c in current:
            assert c.chunk_id not in [a.chunk_id for a in ahead]

    def test_custom_k_parameter(self):
        scheduler, _ = _make_scheduler(window=5)
        ahead = scheduler.peek_ahead(current_position=0, k=1)
        assert len(ahead) == 1
        assert ahead[0].chunk_id == "layer_0.bias.0"

    def test_truncated_at_end_of_graph(self):
        scheduler, _ = _make_scheduler(window=10)
        ahead = scheduler.peek_ahead(current_position=3)
        ids = [c.chunk_id for c in ahead]
        # Position 3 + 1 = 4 -> layer_2.weight (1 chunk)
        # Position 3 + 2 = 5 -> out of range
        assert len(ids) == 1
        assert "layer_2.weight.0" in ids


# ---------------------------------------------------------------------------
# advance
# ---------------------------------------------------------------------------


class TestAdvance:
    def test_advances_through_graph(self):
        scheduler, _ = _make_scheduler()
        assert scheduler.current_position == 0
        scheduler.advance()
        assert scheduler.current_position == 1
        scheduler.advance()
        assert scheduler.current_position == 2

    def test_advance_past_end_returns_false(self):
        scheduler, _ = _make_scheduler()
        for _ in range(len(_GRAPH) + 2):
            scheduler.advance()
        # Once past the end, further advances do nothing
        assert scheduler.current_position == len(_GRAPH)


# ---------------------------------------------------------------------------
# is_complete
# ---------------------------------------------------------------------------


class TestIsComplete:
    def test_not_complete_at_start(self):
        scheduler, _ = _make_scheduler()
        assert not scheduler.is_complete()

    def test_complete_after_all_advances(self):
        scheduler, _ = _make_scheduler()
        for _ in range(len(_GRAPH)):
            scheduler.advance()
        assert scheduler.is_complete()


# ---------------------------------------------------------------------------
# set_position
# ---------------------------------------------------------------------------


class TestSetPosition:
    def test_sets_valid_position(self):
        scheduler, _ = _make_scheduler()
        scheduler.set_position(3)
        assert scheduler.current_position == 3

    def test_set_to_zero(self):
        scheduler, _ = _make_scheduler()
        scheduler.advance()
        scheduler.set_position(0)
        assert scheduler.current_position == 0

    def test_set_to_end_is_valid(self):
        scheduler, _ = _make_scheduler()
        scheduler.set_position(len(_GRAPH))
        assert scheduler.is_complete()

    def test_negative_raises(self):
        scheduler, _ = _make_scheduler()
        with pytest.raises(SchedulerError):
            scheduler.set_position(-1)

    def test_beyond_end_raises(self):
        scheduler, _ = _make_scheduler()
        with pytest.raises(SchedulerError):
            scheduler.set_position(len(_GRAPH) + 1)


# ---------------------------------------------------------------------------
# get_priority
# ---------------------------------------------------------------------------


class TestGetPriority:
    def test_high_for_current_layer(self):
        scheduler, _ = _make_scheduler(window=3)
        addr = _make_chunk_addr("layer_0.weight.0")
        assert scheduler.get_priority(addr, current_pos=0) == ChunkPriority.HIGH

    def test_high_for_next_layer(self):
        scheduler, _ = _make_scheduler(window=3)
        addr = _make_chunk_addr("layer_0.bias.0")
        assert scheduler.get_priority(addr, current_pos=0) == ChunkPriority.HIGH

    def test_low_within_window(self):
        scheduler, _ = _make_scheduler(window=3)
        addr = _make_chunk_addr("layer_1.weight.0")
        # distance = 2 - 0 = 2, window = 3, so 2 <= 3 => LOW
        assert scheduler.get_priority(addr, current_pos=0) == ChunkPriority.LOW

    def test_background_beyond_window(self):
        scheduler, _ = _make_scheduler(window=2)
        addr = _make_chunk_addr("layer_2.weight.0")
        # distance = 4 - 0 = 4, window = 2, so 4 > 2 => BACKGROUND
        assert scheduler.get_priority(addr, current_pos=0) == ChunkPriority.BACKGROUND

    def test_unknown_chunk_returns_background(self):
        scheduler, _ = _make_scheduler(window=3)
        addr = _make_chunk_addr("nonexistent.0")
        assert scheduler.get_priority(addr, current_pos=0) == ChunkPriority.BACKGROUND


# ---------------------------------------------------------------------------
# Adaptive window
# ---------------------------------------------------------------------------


class TestAdaptiveWindow:
    def test_increases_for_good_network(self):
        scheduler, _ = _make_scheduler(window=4, adaptive=True)
        base = scheduler.prefetch_window
        good = NetworkConditions(latency_ms=10, bandwidth_mbps=500)
        scheduler.update_network_conditions(good)
        assert scheduler.prefetch_window > base

    def test_decreases_for_bad_network(self):
        scheduler, _ = _make_scheduler(window=4, adaptive=True)
        bad = NetworkConditions(latency_ms=800, bandwidth_mbps=1, packet_loss_rate=0.5)
        scheduler.update_network_conditions(bad)
        assert scheduler.prefetch_window < 4

    def test_non_adaptive_does_not_change(self):
        scheduler, _ = _make_scheduler(window=4, adaptive=False)
        good = NetworkConditions(latency_ms=10, bandwidth_mbps=500)
        scheduler.update_network_conditions(good)
        assert scheduler.prefetch_window == 4

    def test_terrible_network_sets_window_to_one(self):
        scheduler, _ = _make_scheduler(window=4, adaptive=True)
        terrible = NetworkConditions(latency_ms=900, bandwidth_mbps=0.5, packet_loss_rate=0.8)
        scheduler.update_network_conditions(terrible)
        assert scheduler.prefetch_window == 1


# ---------------------------------------------------------------------------
# get_metrics
# ---------------------------------------------------------------------------


class TestGetMetrics:
    def test_returns_correct_data(self):
        scheduler, _ = _make_scheduler(window=3)
        metrics = scheduler.get_metrics()
        assert metrics.current_position == 0
        assert metrics.total_positions == len(_GRAPH)
        assert metrics.prefetch_window == 3
        assert metrics.chunks_needed_current == 1
        assert metrics.chunks_needed_ahead == 3

    def test_metrics_at_end(self):
        scheduler, _ = _make_scheduler(window=3)
        for _ in range(len(_GRAPH)):
            scheduler.advance()
        metrics = scheduler.get_metrics()
        assert metrics.chunks_needed_current == 0
        assert metrics.chunks_needed_ahead == 0


# ---------------------------------------------------------------------------
# Error cases
# ---------------------------------------------------------------------------


class TestErrorCases:
    def test_empty_graph_raises(self):
        with pytest.raises(SchedulerError, match="must not be empty"):
            Scheduler(execution_graph=[], chunk_lookup={}, prefetch_window=1)

    def test_window_zero_raises(self):
        with pytest.raises(SchedulerError, match="must be >= 1"):
            Scheduler(execution_graph=["a"], chunk_lookup={"a": []}, prefetch_window=0)

    def test_window_negative_raises(self):
        with pytest.raises(SchedulerError, match="must be >= 1"):
            Scheduler(execution_graph=["a"], chunk_lookup={"a": []}, prefetch_window=-2)


# ---------------------------------------------------------------------------
# get_remaining_layers / get_completed_layers
# ---------------------------------------------------------------------------


class TestLayerLists:
    def test_remaining_layers_at_start(self):
        scheduler, _ = _make_scheduler()
        remaining = scheduler.get_remaining_layers()
        assert remaining == _GRAPH

    def test_remaining_layers_mid_graph(self):
        scheduler, _ = _make_scheduler()
        scheduler.advance()
        remaining = scheduler.get_remaining_layers()
        assert remaining == _GRAPH[1:]

    def test_completed_layers_empty_at_start(self):
        scheduler, _ = _make_scheduler()
        completed = scheduler.get_completed_layers()
        assert completed == []

    def test_completed_layers_after_advances(self):
        scheduler, _ = _make_scheduler()
        scheduler.advance()
        scheduler.advance()
        completed = scheduler.get_completed_layers()
        assert completed == _GRAPH[:2]

    def test_completed_and_remaining_exhaustive(self):
        scheduler, _ = _make_scheduler()
        completed = scheduler.get_completed_layers()
        remaining = scheduler.get_remaining_layers()
        assert completed + remaining == _GRAPH


# ---------------------------------------------------------------------------
# NetworkConditions
# ---------------------------------------------------------------------------


class TestNetworkConditions:
    def test_quality_score_good(self):
        nc = NetworkConditions(latency_ms=10, bandwidth_mbps=100)
        assert nc.quality_score > 0.7

    def test_quality_score_bad(self):
        nc = NetworkConditions(latency_ms=900, bandwidth_mbps=1, packet_loss_rate=0.9)
        assert nc.quality_score < 0.2

    def test_estimated_chunk_fetch_ms(self):
        nc = NetworkConditions(latency_ms=50, bandwidth_mbps=100)
        ms = nc.estimated_chunk_fetch_ms
        # transfer = 524288*8 / (100*1e6) * 1000 ≈ 41.9ms + 50ms latency
        assert ms > 50
