"""Unit tests for the graph-aware scheduler."""

from rex.core.cost_model import ChunkCostModel
from rex.core.graph_model import ExecutionDAG, GraphEdge, GraphNode
from rex.core.graph_scheduler import GraphScheduler
from rex.core.types import ByteRange, ChunkAddress


def _addr(chunk_id: str) -> ChunkAddress:
    return ChunkAddress(
        chunk_id=chunk_id,
        resource_id="weights.bin",
        byte_range=ByteRange(start=0, end=128),
    )


class TestGraphScheduler:
    def test_prefers_higher_critical_path_when_costs_tie(self):
        dag = ExecutionDAG(
            nodes={
                "a": GraphNode(name="a", compute_cost_ms=5.0, weight_chunk_ids={"ca"}),
                "b": GraphNode(name="b", compute_cost_ms=1.0, weight_chunk_ids={"cb"}),
                "c": GraphNode(name="c", compute_cost_ms=3.0, weight_chunk_ids={"cc"}),
            },
            edges=[GraphEdge("a", "c")],
        )
        lookup = {
            "a": [_addr("ca")],
            "b": [_addr("cb")],
            "c": [_addr("cc")],
        }

        scheduler = GraphScheduler(dag=dag, chunk_lookup=lookup, adaptive_window=False)
        assert scheduler.execution_graph[0] == "a"
        assert scheduler.execution_graph[-1] == "c"

    def test_penalizes_high_miss_cost_ready_node(self):
        dag = ExecutionDAG(
            nodes={
                "hot": GraphNode(name="hot", compute_cost_ms=1.0, weight_chunk_ids={"hot"}),
                "cheap": GraphNode(name="cheap", compute_cost_ms=1.0, weight_chunk_ids={"cheap"}),
            },
            edges=[],
        )
        lookup = {"hot": [_addr("hot")], "cheap": [_addr("cheap")]}
        costs = ChunkCostModel(latency_ms={"hot": 100.0, "cheap": 1.0})

        scheduler = GraphScheduler(
            dag=dag,
            chunk_lookup=lookup,
            adaptive_window=False,
            cost_model=costs,
            lambda_crit=1.0,
            lambda_miss=1.0,
        )
        assert scheduler.execution_graph[0] == "cheap"