"""Unit tests for eviction policies."""
import time

import pytest

from rex.cache.policies import (
    CacheEntry,
    EvictionPolicy,
    LRUPolicy,
    LFUPolicy,
    WeightedUtilityPolicy,
    create_policy,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_entries(count: int = 3, base_time: float | None = None) -> dict[str, CacheEntry]:
    """Create entries with sequential access times."""
    now = base_time or time.monotonic()
    entries = {}
    for i in range(count):
        entries[f"c{i}"] = CacheEntry(
            chunk_id=f"c{i}",
            data=b"x" * 100,
            last_access_time=now + i,  # c0 is oldest
            access_count=i + 1,
            prefetch_score=0.5,
        )
    return entries


# ---------------------------------------------------------------------------
# LRUPolicy
# ---------------------------------------------------------------------------


class TestLRUPolicy:
    def test_evicts_least_recently_used(self):
        entries = _make_entries(3)
        policy = LRUPolicy()
        victim = policy.select_victim(entries)
        assert victim == "c0"  # oldest access time

    def test_with_same_times_oldest_id_selected(self):
        """If all access times are equal, min returns deterministic result."""
        now = time.monotonic()
        entries = {
            "a": CacheEntry("a", b"x", last_access_time=now, access_count=1),
            "b": CacheEntry("b", b"x", last_access_time=now, access_count=1),
            "c": CacheEntry("c", b"x", last_access_time=now, access_count=1),
        }
        policy = LRUPolicy()
        # min() is deterministic based on key iteration order
        victim = policy.select_victim(entries)
        assert victim in entries


# ---------------------------------------------------------------------------
# LFUPolicy
# ---------------------------------------------------------------------------


class TestLFUPolicy:
    def test_evicts_least_frequently_used(self):
        entries = {
            "rare": CacheEntry("rare", b"x" * 100, access_count=1),
            "often": CacheEntry("often", b"x" * 100, access_count=10),
            "medium": CacheEntry("medium", b"x" * 100, access_count=5),
        }
        policy = LFUPolicy()
        victim = policy.select_victim(entries)
        assert victim == "rare"

    def test_ties_broken_by_lru(self):
        """When access_count is equal, fall back to LRU (oldest first)."""
        now = time.monotonic()
        entries = {
            "old": CacheEntry("old", b"x" * 100, last_access_time=now - 50, access_count=3),
            "new": CacheEntry("new", b"x" * 100, last_access_time=now, access_count=3),
        }
        policy = LFUPolicy()
        victim = policy.select_victim(entries)
        assert victim == "old"


# ---------------------------------------------------------------------------
# WeightedUtilityPolicy
# ---------------------------------------------------------------------------


class TestWeightedUtilityPolicy:
    def test_evicts_lowest_utility(self):
        """The implementation selects the entry with the lowest computed score.

        The formula is: score = alpha*recency + beta*(1-frequency) + gamma*(1-prefetch)
        and the victim is min(score). A recently accessed, frequently used,
        high-prefetch entry gets the lowest score and is evicted by min().
        """
        now = time.monotonic()
        entries = {
            "old_unpopular": CacheEntry(
                "old_unpopular", b"x" * 100,
                last_access_time=now - 100, access_count=1, prefetch_score=0.0,
            ),
            "recent_popular": CacheEntry(
                "recent_popular", b"x" * 100,
                last_access_time=now, access_count=10, prefetch_score=0.9,
            ),
        }
        policy = WeightedUtilityPolicy(alpha=0.5, beta=0.3, gamma=0.2)
        victim = policy.select_victim(entries)
        # recent_popular: recency=0, (1-freq)=0, (1-pref)=0 → score=0 (lowest)
        assert victim == "recent_popular"

    def test_custom_weights(self):
        """Custom weights change which entry gets the lowest score."""
        now = time.monotonic()
        entries = {
            "old_freq": CacheEntry(
                "old_freq", b"x" * 100,
                last_access_time=now - 100, access_count=100, prefetch_score=0.0,
            ),
            "recent_rare": CacheEntry(
                "recent_rare", b"x" * 100,
                last_access_time=now, access_count=1, prefetch_score=0.0,
            ),
        }
        # Pure recency (alpha=1): recent_rare has recency=0, old_freq has recency=1.
        # min() evicts recent_rare (score=0).
        policy = WeightedUtilityPolicy(alpha=1.0, beta=0.0, gamma=0.0)
        victim = policy.select_victim(entries)
        assert victim == "recent_rare"

        # Pure (1-frequency) (beta=1): recent_rare freq=1, old_freq freq=100.
        # (1-freq_norm) for rare = 1-0 = 1.0, for old = 1-1 = 0.0.
        # min() evicts old_freq (score=0).
        policy2 = WeightedUtilityPolicy(alpha=0.0, beta=1.0, gamma=0.0)
        victim2 = policy2.select_victim(entries)
        assert victim2 == "old_freq"

    def test_policy_name(self):
        policy = WeightedUtilityPolicy(alpha=0.7, beta=0.2, gamma=0.1)
        assert "alpha=0.7" in policy.policy_name()


# ---------------------------------------------------------------------------
# create_policy factory
# ---------------------------------------------------------------------------


class TestCreatePolicy:
    def test_creates_lru(self):
        policy = create_policy("lru")
        assert isinstance(policy, LRUPolicy)

    def test_creates_lfu(self):
        policy = create_policy("lfu")
        assert isinstance(policy, LFUPolicy)

    def test_creates_weighted_utility(self):
        policy = create_policy("weighted_utility")
        assert isinstance(policy, WeightedUtilityPolicy)

    def test_creates_wu_alias(self):
        policy = create_policy("wu")
        assert isinstance(policy, WeightedUtilityPolicy)

    def test_creates_weighted_utility_with_custom_weights(self):
        policy = create_policy("weighted_utility", alpha=1.0, beta=0.0, gamma=0.0)
        assert isinstance(policy, WeightedUtilityPolicy)
        assert policy.alpha == 1.0
        assert policy.beta == 0.0

    def test_unknown_name_raises(self):
        with pytest.raises(ValueError, match="Unknown eviction policy"):
            create_policy("fifo")

    def test_case_insensitive(self):
        policy = create_policy("LRU")
        assert isinstance(policy, LRUPolicy)

        policy = create_policy("  Lfu  ")
        assert isinstance(policy, LFUPolicy)


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------


class TestEdgeCases:
    def test_empty_candidates_raises_value_error(self):
        for cls in [LRUPolicy, LFUPolicy, WeightedUtilityPolicy]:
            policy = cls() if cls != WeightedUtilityPolicy else cls()
            with pytest.raises(ValueError, match="Cannot select victim"):
                policy.select_victim({})

    def test_single_candidate_always_selected(self):
        entry = CacheEntry("only", b"x" * 100)
        entries = {"only": entry}

        for cls in [LRUPolicy, LFUPolicy]:
            policy = cls()
            assert policy.select_victim(entries) == "only"

        wu = WeightedUtilityPolicy()
        assert wu.select_victim(entries) == "only"


# ---------------------------------------------------------------------------
# record_access, on_insert, on_evict callbacks
# ---------------------------------------------------------------------------


class TestCallbacks:
    def test_record_access_increments_count(self):
        entry = CacheEntry("c1", b"x" * 50, access_count=1)
        policy = LRUPolicy()
        old_count = entry.access_count
        old_time = entry.last_access_time

        # Brief sleep to ensure time.monotonic() differs
        time.sleep(0.001)
        policy.record_access("c1", entry)

        assert entry.access_count == old_count + 1
        assert entry.last_access_time > old_time

    def test_on_insert_updates_access_time(self):
        entry = CacheEntry("c1", b"x" * 50)
        old_time = entry.last_access_time
        time.sleep(0.001)

        policy = LRUPolicy()
        policy.on_insert("c1", entry)

        assert entry.last_access_time > old_time

    def test_on_evict_is_noop_by_default(self):
        policy = LRUPolicy()
        # Should not raise
        policy.on_evict("some_id")

    def test_lfu_record_access(self):
        entry = CacheEntry("c1", b"x" * 50, access_count=3)
        policy = LFUPolicy()
        policy.record_access("c1", entry)
        assert entry.access_count == 4
