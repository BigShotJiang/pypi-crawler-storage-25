"""Unit tests for planning cost model helpers."""

import pytest

from rex.core.cost_model import ChunkCostModel, prefetch_utility


class TestChunkCostModel:
    def test_missing_cost_uses_specific_values(self):
        model = ChunkCostModel(
            latency_ms={"c1": 10.0},
            decode_ms={"c1": 1.5},
        )
        assert model.missing_cost_ms("c1") == pytest.approx(11.5)

    def test_missing_cost_uses_defaults(self):
        model = ChunkCostModel(default_latency_ms=7.0, default_decode_ms=0.5)
        assert model.missing_cost_ms("unknown") == pytest.approx(7.5)

    def test_node_missing_cost_excludes_cached_chunks(self):
        model = ChunkCostModel(
            latency_ms={"c1": 10.0, "c2": 20.0},
            decode_ms={"c1": 1.0, "c2": 2.0},
        )
        cost = model.node_missing_cost_ms(
            required_chunk_ids={"c1", "c2"},
            cached_chunk_ids={"c2"},
        )
        assert cost == pytest.approx(11.0)

    def test_expected_eviction_cost_clamps_probability(self):
        model = ChunkCostModel(latency_ms={"c1": 10.0}, decode_ms={"c1": 2.0})
        assert model.expected_eviction_cost("c1", reuse_probability=1.5) == pytest.approx(12.0)
        assert model.expected_eviction_cost("c1", reuse_probability=-1.0) == pytest.approx(0.0)

    def test_value_density_uses_chunk_size(self):
        model = ChunkCostModel(
            latency_ms={"c1": 30.0},
            decode_ms={"c1": 0.0},
            size_bytes={"c1": 10},
        )
        density = model.value_density("c1", reuse_probability=0.5)
        assert density == pytest.approx(1.5)


class TestPrefetchUtility:
    def test_prefetch_utility_basic(self):
        u = prefetch_utility(probability=0.5, estimated_latency_ms=10.0)
        assert u == pytest.approx(0.05)

    def test_prefetch_utility_clamps_probability(self):
        assert prefetch_utility(probability=2.0, estimated_latency_ms=5.0) == pytest.approx(0.2)
        assert prefetch_utility(probability=-1.0, estimated_latency_ms=5.0) == pytest.approx(0.0)

    def test_prefetch_utility_handles_zero_latency(self):
        # Uses epsilon denominator to avoid division-by-zero.
        assert prefetch_utility(probability=0.5, estimated_latency_ms=0.0) > 0
