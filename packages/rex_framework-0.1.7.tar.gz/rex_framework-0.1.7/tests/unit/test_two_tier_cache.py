"""Unit tests for TwoTierCache."""
import asyncio
import pytest

from rex.cache.disk_cache import DiskCache
from rex.cache.memory_cache import MemoryCache
from rex.cache.two_tier import TwoTierCache


def _run(coro):
    """Helper to run async code in sync tests."""
    return asyncio.get_event_loop().run_until_complete(coro)


class TestTwoTierCacheMemoryHit:
    """Verify that a memory hit never touches disk."""

    def test_get_returns_from_memory(self, tmp_path):
        mem = MemoryCache(max_bytes=4096)
        disk = DiskCache(cache_dir=tmp_path / "dc")
        cache = TwoTierCache(memory_cache=mem, disk_cache=disk)

        _run(cache.put("c1", b"hello"))
        result = _run(cache.get("c1"))
        assert result == b"hello"

    def test_get_does_not_increment_disk_counters_on_memory_hit(self, tmp_path):
        mem = MemoryCache(max_bytes=4096)
        disk = DiskCache(cache_dir=tmp_path / "dc")
        cache = TwoTierCache(memory_cache=mem, disk_cache=disk)

        _run(cache.put("c1", b"data"))
        _run(cache.get("c1"))

        stats = _run(cache.get_stats())
        assert stats.disk_hits == 0
        assert stats.disk_misses == 0


class TestTwoTierCacheDiskFallback:
    """Verify disk fallback when memory misses."""

    def test_disk_fallback_populates_memory(self, tmp_path):
        mem = MemoryCache(max_bytes=4096)
        disk = DiskCache(cache_dir=tmp_path / "dc")
        cache = TwoTierCache(memory_cache=mem, disk_cache=disk)

        # Write directly to disk (bypassing two-tier put)
        disk.put("c1", b"from_disk")
        assert _run(mem.contains("c1")) is False

        # get should find it on disk and promote to memory
        result = _run(cache.get("c1"))
        assert result == b"from_disk"
        assert _run(mem.contains("c1")) is True

    def test_disk_hit_increments_counter(self, tmp_path):
        mem = MemoryCache(max_bytes=4096)
        disk = DiskCache(cache_dir=tmp_path / "dc")
        cache = TwoTierCache(memory_cache=mem, disk_cache=disk)

        disk.put("c1", b"from_disk")
        _run(cache.get("c1"))

        stats = _run(cache.get_stats())
        assert stats.disk_hits == 1

    def test_disk_miss_increments_counter(self, tmp_path):
        mem = MemoryCache(max_bytes=4096)
        disk = DiskCache(cache_dir=tmp_path / "dc")
        cache = TwoTierCache(memory_cache=mem, disk_cache=disk)

        result = _run(cache.get("nonexistent"))
        assert result is None

        stats = _run(cache.get_stats())
        assert stats.disk_misses == 1

    def test_full_miss_returns_none(self, tmp_path):
        mem = MemoryCache(max_bytes=4096)
        disk = DiskCache(cache_dir=tmp_path / "dc")
        cache = TwoTierCache(memory_cache=mem, disk_cache=disk)

        result = _run(cache.get("no_such_key"))
        assert result is None


class TestTwoTierCacheWriteThrough:
    """Verify that put writes to both tiers."""

    def test_put_writes_to_memory(self, tmp_path):
        mem = MemoryCache(max_bytes=4096)
        disk = DiskCache(cache_dir=tmp_path / "dc")
        cache = TwoTierCache(memory_cache=mem, disk_cache=disk)

        _run(cache.put("c1", b"hello"))
        assert _run(mem.contains("c1")) is True

    def test_put_writes_to_disk(self, tmp_path):
        mem = MemoryCache(max_bytes=4096)
        disk = DiskCache(cache_dir=tmp_path / "dc")
        cache = TwoTierCache(memory_cache=mem, disk_cache=disk)

        _run(cache.put("c1", b"hello"))
        assert disk.get("c1") == b"hello"

    def test_put_returns_memory_result(self, tmp_path):
        mem = MemoryCache(max_bytes=4096)
        disk = DiskCache(cache_dir=tmp_path / "dc")
        cache = TwoTierCache(memory_cache=mem, disk_cache=disk)

        result = _run(cache.put("c1", b"ok"))
        assert result is True

    def test_put_disk_still_written_when_memory_rejects(self, tmp_path):
        """Memory rejection should not prevent disk write."""
        mem = MemoryCache(max_bytes=10)  # tiny cache
        disk = DiskCache(cache_dir=tmp_path / "dc", max_bytes=0)
        cache = TwoTierCache(memory_cache=mem, disk_cache=disk)

        big_data = b"x" * 100  # exceeds memory capacity
        result = _run(cache.put("big", big_data))
        assert result is False  # memory rejected
        assert disk.get("big") == big_data  # but disk has it


class TestTwoTierCacheEvictionMemoryOnly:
    """Verify that evict only affects the memory tier."""

    def test_evict_from_memory(self, tmp_path):
        mem = MemoryCache(max_bytes=4096)
        disk = DiskCache(cache_dir=tmp_path / "dc")
        cache = TwoTierCache(memory_cache=mem, disk_cache=disk)

        _run(cache.put("c1", b"hello"))
        evicted = _run(cache.evict("c1"))
        assert evicted is True
        assert _run(mem.contains("c1")) is False

    def test_evict_retains_on_disk(self, tmp_path):
        mem = MemoryCache(max_bytes=4096)
        disk = DiskCache(cache_dir=tmp_path / "dc")
        cache = TwoTierCache(memory_cache=mem, disk_cache=disk)

        _run(cache.put("c1", b"hello"))
        _run(cache.evict("c1"))

        # Disk should still have it
        assert disk.get("c1") == b"hello"

    def test_evict_nonexistent_returns_false(self, tmp_path):
        mem = MemoryCache(max_bytes=4096)
        disk = DiskCache(cache_dir=tmp_path / "dc")
        cache = TwoTierCache(memory_cache=mem, disk_cache=disk)

        evicted = _run(cache.evict("nonexistent"))
        assert evicted is False

    def test_after_evict_disk_still_readable(self, tmp_path):
        """After evicting from memory, get should still return from disk."""
        mem = MemoryCache(max_bytes=4096)
        disk = DiskCache(cache_dir=tmp_path / "dc")
        cache = TwoTierCache(memory_cache=mem, disk_cache=disk)

        _run(cache.put("c1", b"persisted"))
        _run(cache.evict("c1"))

        # Memory miss, but disk has it
        data = _run(cache.get("c1"))
        assert data == b"persisted"

        # And memory is repopulated
        assert _run(mem.contains("c1")) is True


class TestTwoTierCacheStats:
    """Verify combined statistics."""

    def test_stats_include_memory_hits_and_misses(self, tmp_path):
        mem = MemoryCache(max_bytes=4096)
        disk = DiskCache(cache_dir=tmp_path / "dc")
        cache = TwoTierCache(memory_cache=mem, disk_cache=disk)

        _run(cache.put("c1", b"a"))
        _run(cache.get("c1"))  # memory hit
        _run(cache.get("c2"))  # full miss

        stats = _run(cache.get_stats())
        assert stats.hit_count == 1
        assert stats.miss_count == 1

    def test_stats_include_disk_counters(self, tmp_path):
        mem = MemoryCache(max_bytes=4096)
        disk = DiskCache(cache_dir=tmp_path / "dc")
        cache = TwoTierCache(memory_cache=mem, disk_cache=disk)

        disk.put("d1", b"disk_only")
        _run(cache.get("d1"))  # disk hit
        _run(cache.get("d2"))  # disk miss

        stats = _run(cache.get_stats())
        assert stats.disk_hits == 1
        assert stats.disk_misses == 1

    def test_stats_include_disk_bytes(self, tmp_path):
        mem = MemoryCache(max_bytes=4096)
        disk = DiskCache(cache_dir=tmp_path / "dc")
        cache = TwoTierCache(memory_cache=mem, disk_cache=disk)

        _run(cache.put("c1", b"12345"))
        stats = _run(cache.get_stats())
        assert stats.disk_bytes == 5

    def test_stats_max_bytes_matches_memory(self, tmp_path):
        mem = MemoryCache(max_bytes=4096)
        disk = DiskCache(cache_dir=tmp_path / "dc")
        cache = TwoTierCache(memory_cache=mem, disk_cache=disk)

        stats = _run(cache.get_stats())
        assert stats.max_bytes == 4096


class TestTwoTierCacheContains:
    """Verify contains checks both tiers."""

    def test_contains_memory_hit(self, tmp_path):
        mem = MemoryCache(max_bytes=4096)
        disk = DiskCache(cache_dir=tmp_path / "dc")
        cache = TwoTierCache(memory_cache=mem, disk_cache=disk)

        _run(cache.put("c1", b"a"))
        assert _run(cache.contains("c1")) is True

    def test_contains_disk_hit(self, tmp_path):
        mem = MemoryCache(max_bytes=4096)
        disk = DiskCache(cache_dir=tmp_path / "dc")
        cache = TwoTierCache(memory_cache=mem, disk_cache=disk)

        disk.put("c1", b"disk_only")
        assert _run(cache.contains("c1")) is True

    def test_contains_miss(self, tmp_path):
        mem = MemoryCache(max_bytes=4096)
        disk = DiskCache(cache_dir=tmp_path / "dc")
        cache = TwoTierCache(memory_cache=mem, disk_cache=disk)

        assert _run(cache.contains("nope")) is False


class TestTwoTierCacheClear:
    """Verify clear behaviour."""

    def test_clear_empties_memory_but_not_disk(self, tmp_path):
        mem = MemoryCache(max_bytes=4096)
        disk = DiskCache(cache_dir=tmp_path / "dc")
        cache = TwoTierCache(memory_cache=mem, disk_cache=disk)

        _run(cache.put("c1", b"hello"))
        _run(cache.clear())

        assert _run(mem.contains("c1")) is False
        assert disk.get("c1") == b"hello"  # disk retains

    def test_clear_disk_empties_disk_but_not_memory(self, tmp_path):
        mem = MemoryCache(max_bytes=4096)
        disk = DiskCache(cache_dir=tmp_path / "dc")
        cache = TwoTierCache(memory_cache=mem, disk_cache=disk)

        _run(cache.put("c1", b"hello"))
        _run(cache.clear_disk())

        assert _run(mem.contains("c1")) is True  # memory retains
        assert disk.get("c1") is None

    def test_clear_disk_resets_disk_counters(self, tmp_path):
        mem = MemoryCache(max_bytes=4096)
        disk = DiskCache(cache_dir=tmp_path / "dc")
        cache = TwoTierCache(memory_cache=mem, disk_cache=disk)

        disk.put("d1", b"x")
        _run(cache.get("d1"))  # disk hit
        _run(cache.get("d2"))  # disk miss

        _run(cache.clear_disk())

        stats = _run(cache.get_stats())
        assert stats.disk_hits == 0
        assert stats.disk_misses == 0


class TestTwoTierCacheWithoutDisk:
    """Verify the wrapper works as a thin pass-through when disk is None."""

    def test_get_put_evict_without_disk(self):
        mem = MemoryCache(max_bytes=4096)
        cache = TwoTierCache(memory_cache=mem, disk_cache=None)

        assert _run(cache.put("c1", b"data")) is True
        assert _run(cache.get("c1")) == b"data"
        assert _run(cache.contains("c1")) is True
        assert _run(cache.evict("c1")) is True
        assert _run(cache.get("c1")) is None

    def test_stats_without_disk(self):
        mem = MemoryCache(max_bytes=4096)
        cache = TwoTierCache(memory_cache=mem, disk_cache=None)

        _run(cache.put("c1", b"a"))
        _run(cache.get("c1"))

        stats = _run(cache.get_stats())
        assert stats.hit_count == 1
        assert stats.disk_hits == 0
        assert stats.disk_misses == 0
        assert stats.disk_bytes == 0

    def test_clear_without_disk(self):
        mem = MemoryCache(max_bytes=4096)
        cache = TwoTierCache(memory_cache=mem, disk_cache=None)

        _run(cache.put("c1", b"a"))
        _run(cache.clear())
        assert _run(cache.contains("c1")) is False
