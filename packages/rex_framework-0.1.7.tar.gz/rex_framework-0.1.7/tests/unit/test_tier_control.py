"""Tests for TierControlPolicy, FrequencyBasedTierControlPolicy, ThirdTierBackend (Target 5)."""
from __future__ import annotations

import asyncio
import pytest
from typing import Optional

from rex.cache.two_tier import (
    AlwaysPromotePolicy,
    FrequencyBasedTierControlPolicy,
    NeverPromotePolicy,
    ThirdTierBackend,
    TierControlPolicy,
    TwoTierCache,
)
from rex.cache.memory_cache import MemoryCache
from rex.cache.policies import LRUPolicy


def run(coro):
    return asyncio.get_event_loop().run_until_complete(coro)


class TestFrequencyBasedPolicy:
    def test_promotes_above_threshold(self):
        policy = FrequencyBasedTierControlPolicy(min_accesses=2)
        assert policy.should_promote("c", access_count=2, size_bytes=100)
        assert policy.should_promote("c", access_count=5, size_bytes=100)

    def test_does_not_promote_below_threshold(self):
        policy = FrequencyBasedTierControlPolicy(min_accesses=3)
        assert not policy.should_promote("c", access_count=1, size_bytes=100)
        assert not policy.should_promote("c", access_count=2, size_bytes=100)

    def test_default_min_accesses(self):
        policy = FrequencyBasedTierControlPolicy()
        assert policy.min_accesses == 2


class TestAlwaysNeverPolicies:
    def test_always_promotes(self):
        policy = AlwaysPromotePolicy()
        assert policy.should_promote("c", access_count=0, size_bytes=0)

    def test_never_promotes(self):
        policy = NeverPromotePolicy()
        assert not policy.should_promote("c", access_count=100, size_bytes=100)


class TestTierControlPolicyIsAbstract:
    def test_cannot_instantiate_abstract(self):
        with pytest.raises(TypeError):
            TierControlPolicy()  # type: ignore[abstract]


class InMemoryThirdTier(ThirdTierBackend):
    """Simple in-memory third-tier backend for testing."""
    def __init__(self):
        self._store: dict[str, bytes] = {}

    def get(self, chunk_id: str) -> Optional[bytes]:
        return self._store.get(chunk_id)

    def put(self, chunk_id: str, data: bytes) -> None:
        self._store[chunk_id] = data


class TestThirdTierBackend:
    def test_is_abstract(self):
        with pytest.raises(TypeError):
            ThirdTierBackend()  # type: ignore[abstract]

    def test_concrete_implementation(self):
        tier = InMemoryThirdTier()
        assert tier.get("x") is None
        tier.put("x", b"hello")
        assert tier.get("x") == b"hello"


class TestTwoTierCacheWithControlPolicy:
    def _make_cache(self, policy=None, third_tier=None):
        mem = MemoryCache(max_bytes=1024 * 1024, policy=LRUPolicy())
        return TwoTierCache(memory_cache=mem, control_policy=policy, third_tier=third_tier)

    def test_get_miss_returns_none(self):
        cache = self._make_cache()
        result = run(cache.get("missing"))
        assert result is None

    def test_get_hit_in_memory(self):
        cache = self._make_cache()
        run(cache.put("chunk_a", b"data"))
        result = run(cache.get("chunk_a"))
        assert result == b"data"

    def test_third_tier_fallback(self):
        third = InMemoryThirdTier()
        third.put("chunk_z", b"from_third")
        cache = self._make_cache(third_tier=third)
        result = run(cache.get("chunk_z"))
        assert result == b"from_third"

    def test_never_promote_policy_prevents_memory_promotion(self):
        """With NeverPromotePolicy, disk hits do not get promoted."""
        # Without a real disk cache, test that third-tier fallback still works
        # even with NeverPromotePolicy (third tier goes to memory directly).
        third = InMemoryThirdTier()
        third.put("chunk_q", b"qdata")
        cache = self._make_cache(
            policy=NeverPromotePolicy(),
            third_tier=third,
        )
        result = run(cache.get("chunk_q"))
        assert result == b"qdata"
