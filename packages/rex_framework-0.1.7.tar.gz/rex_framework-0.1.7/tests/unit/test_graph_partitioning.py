"""Tests for DAG graph partitioning (Targets 1+2)."""
from __future__ import annotations

import pytest

from rex.core.graph_model import ExecutionDAG, GraphEdge, GraphNode
from rex.core.graph_scheduler import GraphScheduler
from rex.core.types import ChunkAddress


def _make_chain_dag(n: int) -> tuple[ExecutionDAG, dict[str, list[ChunkAddress]], dict[str, int]]:
    """Create a linear chain DAG with n nodes, each owning one unique chunk."""
    nodes = {}
    edges = []
    chunk_lookup: dict[str, list[ChunkAddress]] = {}
    chunk_size_lookup: dict[str, int] = {}
    for i in range(n):
        name = f"layer_{i}"
        cid = f"chunk_{i}"
        nodes[name] = GraphNode(name=name, weight_chunk_ids={cid})
        chunk_lookup[name] = [ChunkAddress(chunk_id=cid, resource_id="http://x", byte_range=None)]
        chunk_size_lookup[cid] = 100
        if i > 0:
            edges.append(GraphEdge(src=f"layer_{i - 1}", dst=name))
    dag = ExecutionDAG(nodes=nodes, edges=edges)
    return dag, chunk_lookup, chunk_size_lookup


class TestPartitionByCacheBudget:
    def test_single_partition_when_budget_covers_all(self):
        dag, _, chunk_size_lookup = _make_chain_dag(4)
        partitions = dag.partition_by_cache_budget(
            cache_budget_bytes=10_000,
            chunk_size_lookup=chunk_size_lookup,
        )
        assert len(partitions) == 1
        assert sum(len(p) for p in partitions) == 4

    def test_splits_into_multiple_partitions(self):
        dag, _, chunk_size_lookup = _make_chain_dag(4)
        # Budget = 150 bytes → can fit at most 1 chunk (100 bytes) per partition
        partitions = dag.partition_by_cache_budget(
            cache_budget_bytes=150,
            chunk_size_lookup=chunk_size_lookup,
        )
        assert len(partitions) >= 2
        assert sum(len(p) for p in partitions) == 4

    def test_budget_zero_raises(self):
        dag, _, chunk_size_lookup = _make_chain_dag(2)
        with pytest.raises(ValueError, match="cache_budget_bytes must be > 0"):
            dag.partition_by_cache_budget(0, chunk_size_lookup)

    def test_node_exceeds_budget_raises(self):
        dag, _, _ = _make_chain_dag(2)
        chunk_size_lookup = {"chunk_0": 1000, "chunk_1": 1000}
        with pytest.raises(ValueError, match="exceeds cache budget"):
            dag.partition_by_cache_budget(500, chunk_size_lookup)

    def test_custom_order_respected(self):
        dag, _, chunk_size_lookup = _make_chain_dag(3)
        order = ["layer_2", "layer_1", "layer_0"]
        partitions = dag.partition_by_cache_budget(
            cache_budget_bytes=10_000,
            chunk_size_lookup=chunk_size_lookup,
            order=order,
        )
        assert partitions[0] == order


class TestGraphSchedulerPartitioning:
    def test_build_partitioned_schedule_returns_partitions(self):
        dag, chunk_lookup, chunk_size_lookup = _make_chain_dag(4)
        scheduler = GraphScheduler(dag=dag, chunk_lookup=chunk_lookup)
        partitions = scheduler.build_partitioned_schedule(
            cache_budget_bytes=150,
            chunk_size_lookup=chunk_size_lookup,
        )
        assert isinstance(partitions, list)
        assert all(isinstance(p, list) for p in partitions)
        assert sum(len(p) for p in partitions) == 4

    def test_memory_budget_feasibility_check(self):
        """With a tight memory budget, no nodes should be skipped (fallback)."""
        dag, chunk_lookup, _ = _make_chain_dag(3)
        # Provide size info so feasibility check has something to compare
        from rex.core.cost_model import ChunkCostModel
        cm = ChunkCostModel(size_bytes={f"chunk_{i}": 1000 for i in range(3)})
        scheduler = GraphScheduler(
            dag=dag,
            chunk_lookup=chunk_lookup,
            cost_model=cm,
            memory_budget_bytes=500,
        )
        # Schedule should still contain all nodes (fallback path)
        assert len(scheduler._build_schedule()) == 3

    def test_memory_budget_zero_disabled(self):
        dag, chunk_lookup, _ = _make_chain_dag(3)
        scheduler = GraphScheduler(
            dag=dag,
            chunk_lookup=chunk_lookup,
            memory_budget_bytes=0,
        )
        assert len(scheduler._build_schedule()) == 3
