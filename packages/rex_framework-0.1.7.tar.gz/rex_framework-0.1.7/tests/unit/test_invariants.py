"""Unit tests for InvariantChecker."""
import pytest

from rex.core.errors import InvariantViolationError
from rex.core.invariants import InvariantChecker


class TestValidCase:
    """Well under the limit."""

    def test_passes_when_well_under_limit(self):
        checker = InvariantChecker(
            total_model_bytes=10000,
            max_local_fraction=0.4,
            safety_margin_fraction=0.0,
        )
        result = checker.check_invariant(
            resident_bytes=1000, cached_bytes=0, raise_on_violation=False
        )
        assert result.is_valid
        assert result.max_allowed_bytes == 4000


class TestBoundaryCase:
    """At exactly max_allowed (no safety margin)."""

    def test_exactly_at_limit_passes(self):
        checker = InvariantChecker(
            total_model_bytes=10000,
            max_local_fraction=0.4,
            safety_margin_fraction=0.0,
        )
        result = checker.check_invariant(
            resident_bytes=4000, cached_bytes=0, raise_on_violation=False
        )
        assert result.is_valid

    def test_one_byte_over_fails(self):
        checker = InvariantChecker(
            total_model_bytes=10000,
            max_local_fraction=0.4,
            safety_margin_fraction=0.0,
        )
        result = checker.check_invariant(
            resident_bytes=4001, cached_bytes=0, raise_on_violation=False
        )
        assert not result.is_valid


class TestOverLimit:
    """Over the limit raises InvariantViolationError."""

    def test_raises_when_over_limit(self):
        checker = InvariantChecker(
            total_model_bytes=10000,
            max_local_fraction=0.4,
            safety_margin_fraction=0.0,
        )
        with pytest.raises(InvariantViolationError):
            checker.check_invariant(
                resident_bytes=5000, cached_bytes=0, raise_on_violation=True
            )

    def test_returns_invalid_when_over_limit_no_raise(self):
        checker = InvariantChecker(
            total_model_bytes=10000,
            max_local_fraction=0.4,
            safety_margin_fraction=0.0,
        )
        result = checker.check_invariant(
            resident_bytes=5000, cached_bytes=0, raise_on_violation=False
        )
        assert not result.is_valid
        assert result.effective_local_bytes == 5000
        assert result.max_allowed_bytes == 4000


class TestSafetyMargin:
    """Safety margin inflates effective bytes."""

    def test_effective_bytes_computed_correctly(self):
        checker = InvariantChecker(
            total_model_bytes=1_000_000_000,
            max_local_fraction=0.4,
            safety_margin_fraction=0.05,
        )
        # max_allowed = 400_000_000
        # With 380M local, effective = 380M / 0.95 ≈ 400M
        result = checker.check_invariant(
            resident_bytes=200_000_000,
            cached_bytes=180_000_000,
            raise_on_violation=False,
        )
        expected_effective = int(380_000_000 / 0.95)
        assert result.effective_local_bytes == expected_effective
        # 380M/0.95 = 400_000_000 which equals max_allowed => valid
        assert result.is_valid

    def test_safety_margin_triggers_early_violation(self):
        checker = InvariantChecker(
            total_model_bytes=1_000_000_000,
            max_local_fraction=0.4,
            safety_margin_fraction=0.05,
        )
        # 400M actual, effective = 400M/0.95 > 400M => violation
        result = checker.check_invariant(
            resident_bytes=200_000_000,
            cached_bytes=200_000_000,
            raise_on_violation=False,
        )
        assert not result.is_valid


class TestZeroSafetyMargin:
    """Zero safety margin means effective == actual."""

    def test_zero_safety_margin_no_inflation(self):
        checker = InvariantChecker(
            total_model_bytes=10000,
            max_local_fraction=0.4,
            safety_margin_fraction=0.0,
        )
        result = checker.check_invariant(
            resident_bytes=3000, cached_bytes=0, raise_on_violation=False
        )
        assert result.effective_local_bytes == 3000
        assert result.is_valid


class TestBytesUntilViolation:
    def test_correct_calculation(self):
        checker = InvariantChecker(
            total_model_bytes=10000,
            max_local_fraction=0.4,
            safety_margin_fraction=0.0,
        )
        remaining = checker.bytes_until_violation(resident_bytes=0, cached_bytes=0)
        assert remaining == 4000

        remaining = checker.bytes_until_violation(resident_bytes=3000, cached_bytes=0)
        assert remaining == 1000

    def test_returns_zero_when_already_over(self):
        checker = InvariantChecker(
            total_model_bytes=10000,
            max_local_fraction=0.4,
            safety_margin_fraction=0.0,
        )
        remaining = checker.bytes_until_violation(resident_bytes=5000, cached_bytes=0)
        assert remaining == 0

    def test_bytes_until_with_safety_margin(self):
        checker = InvariantChecker(
            total_model_bytes=10000,
            max_local_fraction=0.4,
            safety_margin_fraction=0.05,
        )
        # effective_max = 4000 * 0.95 = 3800
        remaining = checker.bytes_until_violation(resident_bytes=0, cached_bytes=0)
        assert remaining == 3800

        remaining = checker.bytes_until_violation(resident_bytes=2000, cached_bytes=0)
        assert remaining == 1800


class TestUpdateModelSize:
    def test_recalculates_max_allowed(self):
        checker = InvariantChecker(
            total_model_bytes=1_000_000_000,
            max_local_fraction=0.4,
        )
        assert checker.max_allowed_bytes == 400_000_000

        checker.update_model_size(2_000_000_000)
        assert checker.max_allowed_bytes == 800_000_000
        assert checker.total_model_bytes == 2_000_000_000

    def test_update_with_zero_raises(self):
        checker = InvariantChecker(
            total_model_bytes=10000,
            max_local_fraction=0.4,
        )
        with pytest.raises(ValueError, match="must be positive"):
            checker.update_model_size(0)


class TestInvalidConstruction:
    def test_zero_model_bytes_raises(self):
        with pytest.raises(ValueError, match="total_model_bytes must be positive"):
            InvariantChecker(total_model_bytes=0)

    def test_negative_model_bytes_raises(self):
        with pytest.raises(ValueError, match="total_model_bytes must be positive"):
            InvariantChecker(total_model_bytes=-100)

    def test_fraction_greater_than_one_raises(self):
        with pytest.raises(ValueError, match="max_local_fraction must be in"):
            InvariantChecker(total_model_bytes=10000, max_local_fraction=1.5)

    def test_fraction_zero_raises(self):
        with pytest.raises(ValueError, match="max_local_fraction must be in"):
            InvariantChecker(total_model_bytes=10000, max_local_fraction=0.0)

    def test_fraction_negative_raises(self):
        with pytest.raises(ValueError, match="max_local_fraction must be in"):
            InvariantChecker(total_model_bytes=10000, max_local_fraction=-0.1)

    def test_safety_margin_exactly_half_raises(self):
        with pytest.raises(ValueError, match="safety_margin_fraction"):
            InvariantChecker(
                total_model_bytes=10000,
                safety_margin_fraction=0.5,
            )

    def test_safety_margin_over_half_raises(self):
        with pytest.raises(ValueError, match="safety_margin_fraction"):
            InvariantChecker(
                total_model_bytes=10000,
                safety_margin_fraction=0.8,
            )


class TestRaiseOnViolationFalse:
    def test_does_not_raise(self):
        checker = InvariantChecker(
            total_model_bytes=10000,
            max_local_fraction=0.4,
            safety_margin_fraction=0.0,
        )
        result = checker.check_invariant(
            resident_bytes=9999, cached_bytes=0, raise_on_violation=False
        )
        assert not result.is_valid
        assert result.fraction_used > 0


class TestMultipleParameters:
    def test_resident_and_cached_both_count(self):
        checker = InvariantChecker(
            total_model_bytes=10000,
            max_local_fraction=0.4,
            safety_margin_fraction=0.0,
        )
        # 2000 resident + 1500 cached = 3500 < 4000 => valid
        result = checker.check_invariant(
            resident_bytes=2000, cached_bytes=1500, raise_on_violation=False
        )
        assert result.is_valid
        assert result.total_local_bytes == 3500

        # 2500 resident + 2000 cached = 4500 > 4000 => invalid
        result = checker.check_invariant(
            resident_bytes=2500, cached_bytes=2000, raise_on_violation=False
        )
        assert not result.is_valid
        assert result.total_local_bytes == 4500
