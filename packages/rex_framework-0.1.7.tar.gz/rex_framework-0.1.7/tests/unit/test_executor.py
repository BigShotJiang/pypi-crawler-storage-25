"""Unit tests for the SequentialExecutor."""
import asyncio
from unittest.mock import MagicMock, AsyncMock

import numpy as np
import pytest

from rex.cache.memory_cache import MemoryCache
from rex.core.chunk_index import ChunkIndex
from rex.core.executor import (
    EvictionStrategy,
    LayerTiming,
    ModelLayer,
    SequentialExecutor,
)
from rex.core.scheduler import Scheduler
from rex.core.types import ByteRange, ChunkAddress
from rex.core.virtual_tensor import VirtualTensor


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_addr(chunk_id: str) -> ChunkAddress:
    return ChunkAddress(
        chunk_id=chunk_id,
        resource_id="model.bin",
        byte_range=ByteRange(start=0, end=1024),
    )


def _make_vt(name: str, shape: tuple = (4, 4), dtype: str = "float32") -> VirtualTensor:
    addr = _make_addr(f"{name}.0")
    return VirtualTensor(name=name, shape=shape, dtype=dtype, chunk_addresses=[addr])


async def _make_scenario(
    num_layers: int = 3,
    params_per_layer: int = 1,
    eviction: EvictionStrategy = EvictionStrategy.NONE,
    retain_window: int = 2,
    pre_populate_cache: bool = False,
) -> tuple:
    """Build executor, layers, scheduler, cache, virtual tensors."""
    layer_names = []
    all_params = []
    for i in range(num_layers):
        layer_name = f"layer_{i}"
        params = [f"layer_{i}.param_{j}" for j in range(params_per_layer)]
        layer_names.append(layer_name)
        all_params.extend(params)

    execution_graph = all_params
    chunk_lookup = {name: [_make_addr(f"{name}.0")] for name in all_params}

    virtual_tensors = {}
    chunk_data = {}
    for name in all_params:
        vt = _make_vt(name)
        virtual_tensors[name] = vt
        shape = vt.shape
        dummy = np.full(shape, float(hash(name) % 100), dtype=np.float32)
        data = dummy.tobytes()
        chunk_data[name] = data
        vt.store_chunk_data(f"{name}.0", data)

    cache = MemoryCache(max_bytes=10 * 1024 * 1024)

    if pre_populate_cache:
        for name in all_params:
            await cache.put(f"{name}.0", chunk_data[name])

    scheduler = Scheduler(
        execution_graph=execution_graph,
        chunk_lookup=chunk_lookup,
        prefetch_window=2,
        adaptive_window=False,
    )

    model_layers = []
    for i in range(num_layers):
        params = [f"layer_{i}.param_{j}" for j in range(params_per_layer)]
        model_layers.append(
            ModelLayer(
                name=f"layer_{i}",
                param_names=params,
                compute_fn=lambda inp, weights, _i=i: inp * 2,
            )
        )

    executor = SequentialExecutor(
        cache=cache,
        retry_max_attempts=1,
        eviction_strategy=eviction,
        retain_window=retain_window,
    )

    return executor, model_layers, scheduler, cache, virtual_tensors, chunk_data


async def _run_executor(executor, model_layers, scheduler, cache, virtual_tensors, chunk_data=None):
    input_data = np.ones((1, 4), dtype=np.float32)
    output, metrics = await executor.execute(
        model_layers=model_layers,
        input_data=input_data,
        scheduler=scheduler,
        chunk_index=ChunkIndex(),
        virtual_tensors=virtual_tensors,
        storage_fetch_func=(
            (lambda addr: chunk_data.get(addr.chunk_id.replace(".0", ""), b"\x00" * 1024))
            if chunk_data
            else None
        ),
    )
    return output, metrics


# ---------------------------------------------------------------------------
# Execute with pre-populated cache
# ---------------------------------------------------------------------------


class TestExecutePrepopulatedCache:
    @pytest.mark.asyncio
    async def test_all_chunks_cached(self):
        executor, model_layers, scheduler, cache, vts, cdata = await _make_scenario(
            pre_populate_cache=True,
        )
        output, metrics = await _run_executor(executor, model_layers, scheduler, cache, vts, cdata)
        assert metrics.layers_executed == 3
        assert metrics.cache_misses == 0
        assert metrics.cache_hits >= 0


# ---------------------------------------------------------------------------
# Execute with no compute_fn (passthrough)
# ---------------------------------------------------------------------------


class TestNoComputeFn:
    @pytest.mark.asyncio
    async def test_passthrough_returns_input(self):
        executor, model_layers, scheduler, cache, vts, cdata = await _make_scenario(
            pre_populate_cache=True,
        )
        # Remove compute_fn from all layers
        for layer in model_layers:
            layer.compute_fn = None

        input_data = np.ones((1, 4), dtype=np.float32)
        output, metrics = await executor.execute(
            model_layers=model_layers,
            input_data=input_data,
            scheduler=scheduler,
            chunk_index=ChunkIndex(),
            virtual_tensors=vts,
        )
        assert metrics.layers_executed == 3
        np.testing.assert_array_equal(output, input_data)


# ---------------------------------------------------------------------------
# Layer timing tracking
# ---------------------------------------------------------------------------


class TestLayerTiming:
    @pytest.mark.asyncio
    async def test_timings_recorded(self):
        executor, model_layers, scheduler, cache, vts, cdata = await _make_scenario(
            pre_populate_cache=True,
        )
        await _run_executor(executor, model_layers, scheduler, cache, vts, cdata)
        timings = executor.get_layer_timings()
        assert len(timings) == 3
        for t in timings:
            assert isinstance(t, LayerTiming)
            assert t.success
            assert t.total_ms >= 0
            assert t.compute_ms >= 0
            assert t.layer_name.startswith("layer_")

    @pytest.mark.asyncio
    async def test_timing_summary_format(self):
        executor, model_layers, scheduler, cache, vts, cdata = await _make_scenario(
            pre_populate_cache=True,
        )
        await _run_executor(executor, model_layers, scheduler, cache, vts, cdata)
        summary = executor.get_timing_summary()
        assert "Layer Execution Timings" in summary
        assert "layer_0" in summary
        assert "Total" in summary
        assert "ms" in summary


# ---------------------------------------------------------------------------
# Eviction strategies
# ---------------------------------------------------------------------------


class TestEvictionAggressive:
    @pytest.mark.asyncio
    async def test_evicts_everything_after_use(self):
        executor, model_layers, scheduler, cache, vts, cdata = await _make_scenario(
            pre_populate_cache=True,
            eviction=EvictionStrategy.AGGRESSIVE,
        )
        output, metrics = await _run_executor(executor, model_layers, scheduler, cache, vts, cdata)
        assert metrics.layers_executed == 3
        # In aggressive mode, params_to_keep is empty, so all should be evicted
        assert metrics.eviction_count > 0


class TestEvictionNone:
    @pytest.mark.asyncio
    async def test_keeps_everything(self):
        executor, model_layers, scheduler, cache, vts, cdata = await _make_scenario(
            pre_populate_cache=True,
            eviction=EvictionStrategy.NONE,
        )
        output, metrics = await _run_executor(executor, model_layers, scheduler, cache, vts, cdata)
        assert metrics.layers_executed == 3
        # With NONE, nothing should be evicted
        assert metrics.eviction_count == 0


class TestEvictionRetainNLayers:
    @pytest.mark.asyncio
    async def test_keeps_recent_n_layers(self):
        executor, model_layers, scheduler, cache, vts, cdata = await _make_scenario(
            num_layers=4,
            params_per_layer=1,
            pre_populate_cache=True,
            eviction=EvictionStrategy.RETAIN_N_LAYERS,
            retain_window=1,
        )
        output, metrics = await _run_executor(executor, model_layers, scheduler, cache, vts, cdata)
        assert metrics.layers_executed == 4
        # Should evict something but not everything
        stats = await cache.get_stats()


# ---------------------------------------------------------------------------
# _fetch_chunk_with_retry
# ---------------------------------------------------------------------------


class TestFetchChunkWithRetry:
    @pytest.mark.asyncio
    async def test_retries_on_failure(self):
        """After N failures, returns None."""
        executor = SequentialExecutor(
            cache=MemoryCache(max_bytes=1024),
            retry_max_attempts=2,
        )
        addr = _make_addr("test.0")
        fail_count = 0

        def failing_fetch(a):
            nonlocal fail_count
            fail_count += 1
            raise RuntimeError("fetch failed")

        result = await executor._fetch_chunk_with_retry(addr, ChunkIndex(), failing_fetch)
        assert result is None
        assert fail_count == 2

    @pytest.mark.asyncio
    async def test_returns_none_when_no_fetch_func(self):
        executor = SequentialExecutor(
            cache=MemoryCache(max_bytes=1024),
            retry_max_attempts=3,
        )
        addr = _make_addr("test.0")
        result = await executor._fetch_chunk_with_retry(addr, ChunkIndex(), None)
        assert result is None

    @pytest.mark.asyncio
    async def test_succeeds_on_first_try(self):
        executor = SequentialExecutor(
            cache=MemoryCache(max_bytes=1024),
            retry_max_attempts=3,
        )
        addr = _make_addr("test.0")
        expected_data = b"chunk_data_here"

        def good_fetch(a):
            return expected_data

        result = await executor._fetch_chunk_with_retry(addr, ChunkIndex(), good_fetch)
        assert result == expected_data

    @pytest.mark.asyncio
    async def test_succeeds_after_retries(self):
        """Succeeds on the second attempt after one failure."""
        executor = SequentialExecutor(
            cache=MemoryCache(max_bytes=1024),
            retry_max_attempts=3,
        )
        addr = _make_addr("test.0")
        call_count = 0
        expected_data = b"eventual_success"

        def flaky_fetch(a):
            nonlocal call_count
            call_count += 1
            if call_count < 2:
                raise RuntimeError("transient error")
            return expected_data

        result = await executor._fetch_chunk_with_retry(addr, ChunkIndex(), flaky_fetch)
        assert result == expected_data
        assert call_count == 2

    @pytest.mark.asyncio
    async def test_returns_none_on_none_response(self):
        """If fetch_func returns None (not raises), retry continues then returns None."""
        executor = SequentialExecutor(
            cache=MemoryCache(max_bytes=1024),
            retry_max_attempts=2,
        )
        addr = _make_addr("test.0")

        result = await executor._fetch_chunk_with_retry(addr, ChunkIndex(), lambda a: None)
        assert result is None


# ---------------------------------------------------------------------------
# get_timing_summary
# ---------------------------------------------------------------------------


class TestGetTimingSummary:
    def test_empty_timings(self):
        executor = SequentialExecutor(cache=MemoryCache(max_bytes=1024))
        summary = executor.get_timing_summary()
        assert "Layer Execution Timings" in summary
        assert "Total" in summary

    def test_format_includes_all_fields(self):
        executor = SequentialExecutor(cache=MemoryCache(max_bytes=1024))
        executor._layer_timings = [
            LayerTiming(
                layer_name="test_layer",
                total_ms=10.5,
                materialize_ms=2.0,
                compute_ms=5.0,
                evict_ms=1.5,
            ),
        ]
        summary = executor.get_timing_summary()
        assert "test_layer" in summary
        assert "10.5ms" in summary

    def test_failed_layer_shows_status(self):
        executor = SequentialExecutor(cache=MemoryCache(max_bytes=1024))
        executor._layer_timings = [
            LayerTiming(
                layer_name="bad_layer",
                total_ms=1.0,
                success=False,
                error="something broke",
            ),
        ]
        summary = executor.get_timing_summary()
        assert "[FAILED]" in summary
