"""Unit tests for VirtualTensor state machine and lifecycle."""
import hashlib
import time

import numpy as np
import pytest

from rex.core.errors import (
    ChunkIntegrityError,
    InvalidStateTransitionError,
    MaterializationError,
)
from rex.core.types import ByteRange, ChunkAddress, TensorState
from rex.core.virtual_tensor import VirtualTensor


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_chunk_addr(chunk_id: str, start: int = 0, end: int = 8) -> ChunkAddress:
    return ChunkAddress(
        chunk_id=chunk_id,
        resource_id="test.bin",
        byte_range=ByteRange(start=start, end=end),
    )


def _make_tensor(
    name: str = "w",
    shape: tuple = (2, 2),
    dtype: str = "float32",
    num_chunks: int = 2,
    checksums: dict | None = None,
) -> tuple[VirtualTensor, list[bytes]]:
    """Create a VirtualTensor with matching raw chunk data.

    Returns (vt, list_of_chunk_bytes).
    """
    import numpy as np

    original = np.random.randn(*shape).astype(dtype)
    raw = original.tobytes()
    chunk_size = len(raw) // num_chunks
    chunks = [raw[i * chunk_size : (i + 1) * chunk_size] for i in range(num_chunks)]

    addrs = [
        _make_chunk_addr(
            f"{name}.{i}",
            start=i * chunk_size,
            end=(i + 1) * chunk_size,
        )
        for i in range(num_chunks)
    ]

    cksums = {}
    if checksums is None:
        for i, c in enumerate(chunks):
            cksums[f"{name}.{i}"] = hashlib.sha256(c).hexdigest()
    else:
        cksums = checksums

    vt = VirtualTensor(
        name=name,
        shape=shape,
        dtype=dtype,
        chunk_addresses=addrs,
        checksums=cksums,
    )
    return vt, chunks


def _fetch_fn(chunks: list[bytes]) -> callable:
    """Return a fetch_func that looks up chunk_id in a dict."""
    mapping = {f"w.{i}": c for i, c in enumerate(chunks)}
    # Also handle generic names
    return lambda addr: mapping.get(addr.chunk_id)


# ---------------------------------------------------------------------------
# Valid state transitions
# ---------------------------------------------------------------------------


class TestValidTransitions:
    """Tests for legal state transitions."""

    def test_remote_to_cached_to_resident(self):
        vt, chunks = _make_tensor()
        assert vt.is_remote
        assert vt.state == TensorState.REMOTE

        # Materialize triggers REMOTE -> CACHED -> RESIDENT
        result = vt.materialize(fetch_func=_fetch_fn(chunks))
        assert vt.state == TensorState.RESIDENT
        assert vt.is_resident
        assert isinstance(result, np.ndarray)
        assert result.shape == vt.shape

    def test_resident_to_cached_to_remote(self):
        vt, chunks = _make_tensor()
        vt.materialize(fetch_func=_fetch_fn(chunks))
        assert vt.is_resident

        # Demote: RESIDENT -> CACHED
        vt.demote()
        assert vt.is_cached
        assert vt.state == TensorState.CACHED

        # Evict: CACHED -> REMOTE
        vt.evict()
        assert vt.is_remote
        assert vt.state == TensorState.REMOTE


# ---------------------------------------------------------------------------
# Invalid state transitions
# ---------------------------------------------------------------------------


class TestInvalidTransitions:
    """Tests for illegal state transitions that should raise."""

    def test_remote_to_resident_direct_raises(self):
        """REMOTE -> RESIDENT is illegal (skips CACHED)."""
        vt, _ = _make_tensor()
        assert vt.is_remote
        with pytest.raises(InvalidStateTransitionError):
            vt._transition_to(TensorState.RESIDENT)

    def test_remote_to_remote_raises(self):
        """REMOTE -> REMOTE is illegal."""
        vt, _ = _make_tensor()
        with pytest.raises(InvalidStateTransitionError):
            vt._transition_to(TensorState.REMOTE)

    def test_evict_from_remote_raises(self):
        """Calling evict() when already REMOTE should raise."""
        vt, _ = _make_tensor()
        assert vt.is_remote
        with pytest.raises(InvalidStateTransitionError):
            vt.evict()

    def test_resident_to_remote_direct_raises(self):
        """RESIDENT -> REMOTE is illegal (skips CACHED)."""
        vt, _ = _make_tensor()
        # Manually force to RESIDENT via _transition_to chain is not possible
        # (REMOTE->CACHED->RESIDENT is the only path). So test via _transition_to.
        vt._transition_to(TensorState.CACHED)
        vt._transition_to(TensorState.RESIDENT)
        with pytest.raises(InvalidStateTransitionError):
            vt._transition_to(TensorState.REMOTE)


# ---------------------------------------------------------------------------
# demote()
# ---------------------------------------------------------------------------


class TestDemote:
    def test_demote_from_resident(self):
        vt, chunks = _make_tensor()
        vt.materialize(fetch_func=_fetch_fn(chunks))
        assert vt.is_resident
        vt.demote()
        assert vt.is_cached

    def test_demote_from_cached_raises(self):
        vt, _ = _make_tensor()
        vt._transition_to(TensorState.CACHED)
        with pytest.raises(InvalidStateTransitionError):
            vt.demote()

    def test_demote_from_remote_raises(self):
        vt, _ = _make_tensor()
        with pytest.raises(InvalidStateTransitionError):
            vt.demote()


# ---------------------------------------------------------------------------
# materialize()
# ---------------------------------------------------------------------------


class TestMaterialize:
    def test_no_fetch_func_no_cached_data_raises(self):
        vt, _ = _make_tensor()
        with pytest.raises(MaterializationError, match="No fetch function"):
            vt.materialize(fetch_func=None)

    def test_materialize_already_resident_returns_tensor(self):
        vt, chunks = _make_tensor()
        result1 = vt.materialize(fetch_func=_fetch_fn(chunks))
        assert vt.is_resident
        result2 = vt.materialize()  # no fetch needed
        np.testing.assert_array_equal(result1, result2)

    def test_checksum_verification_passes(self):
        vt, chunks = _make_tensor()
        result = vt.materialize(fetch_func=_fetch_fn(chunks))
        assert vt.is_resident
        assert isinstance(result, np.ndarray)

    def test_checksum_verification_fails_on_corrupt_data(self):
        vt, chunks = _make_tensor(name="corrupt")
        # Build a fetch function that returns corrupted data
        bad_data = b"\xff" * len(chunks[0])
        mapping = {f"corrupt.0": bad_data, f"corrupt.1": chunks[1]}
        with pytest.raises(ChunkIntegrityError):
            vt.materialize(fetch_func=lambda addr: mapping[addr.chunk_id])

    def test_materialize_fetch_failure_raises(self):
        vt, _ = _make_tensor()
        with pytest.raises(MaterializationError, match="Failed to fetch"):
            vt.materialize(fetch_func=lambda addr: (_ for _ in ()).throw(RuntimeError("network error")))

    def test_materialize_from_cached_to_resident(self):
        """If already CACHED (data in _chunk_data), materialize goes to RESIDENT."""
        vt, chunks = _make_tensor()
        # Manually store chunk data and transition to CACHED
        for addr in vt.chunk_addresses:
            vt.store_chunk_data(addr.chunk_id, _fetch_fn(chunks)(addr))
        vt._transition_to(TensorState.CACHED)
        assert vt.is_cached

        result = vt.materialize()  # no fetch_func needed
        assert vt.is_resident
        assert isinstance(result, np.ndarray)


# ---------------------------------------------------------------------------
# store_chunk_data + materialize without fetch_func
# ---------------------------------------------------------------------------


class TestStoreChunkData:
    def test_store_and_materialize_without_fetch(self):
        vt, chunks = _make_tensor()
        for addr in vt.chunk_addresses:
            vt.store_chunk_data(addr.chunk_id, _fetch_fn(chunks)(addr))
        # All data stored, transition manually or let materialize handle it
        vt._transition_to(TensorState.CACHED)
        result = vt.materialize()
        assert vt.is_resident
        assert isinstance(result, np.ndarray)
        assert result.shape == vt.shape


# ---------------------------------------------------------------------------
# partial_materialize()
# ---------------------------------------------------------------------------


class TestPartialMaterialize:
    def test_invalid_negative_start_raises(self):
        vt, _ = _make_tensor(num_chunks=4)
        with pytest.raises(ValueError, match="Invalid chunk range"):
            vt.partial_materialize(-1, 2)

    def test_invalid_end_exceeds_num_chunks_raises(self):
        vt, _ = _make_tensor(num_chunks=4)
        with pytest.raises(ValueError, match="Invalid chunk range"):
            vt.partial_materialize(0, 10)

    def test_start_equals_end_raises(self):
        vt, _ = _make_tensor(num_chunks=4)
        with pytest.raises(ValueError, match="Invalid chunk range"):
            vt.partial_materialize(2, 2)

    def test_start_greater_than_end_raises(self):
        vt, _ = _make_tensor(num_chunks=4)
        with pytest.raises(ValueError, match="Invalid chunk range"):
            vt.partial_materialize(3, 1)

    def test_partial_returns_correct_data(self):
        vt, chunks = _make_tensor(num_chunks=4, shape=(4, 4))
        result = vt.partial_materialize(1, 3, fetch_func=_fetch_fn(chunks))
        # Should contain elements from chunks 1 and 2
        import numpy as np

        dtype_np = np.dtype(np.float32)
        expected = np.concatenate([
            np.frombuffer(chunks[1], dtype=dtype_np),
            np.frombuffer(chunks[2], dtype=dtype_np),
        ])
        np.testing.assert_array_equal(result, expected)

    def test_partial_transitions_remote_to_cached(self):
        vt, chunks = _make_tensor(num_chunks=4)
        assert vt.is_remote
        vt.partial_materialize(0, 1, fetch_func=_fetch_fn(chunks))
        assert vt.is_cached


# ---------------------------------------------------------------------------
# Tracing hooks
# ---------------------------------------------------------------------------


class TestTracingHooks:
    def test_hooks_called_on_materialize(self):
        vt, chunks = _make_tensor()
        trace_log: list[tuple[str, dict]] = []

        def on_fetch_start(name, ctx):
            trace_log.append((name, ctx))

        def on_fetch_end(name, ctx):
            trace_log.append((name, ctx))

        vt.set_tracing_hooks(on_fetch_start=on_fetch_start, on_fetch_end=on_fetch_end)
        vt.materialize(fetch_func=_fetch_fn(chunks))

        hook_names = [entry[0] for entry in trace_log]
        assert "on_fetch_start" in hook_names
        assert "on_fetch_end" in hook_names

        # Verify context content
        start_ctx = [e[1] for e in trace_log if e[0] == "on_fetch_start"][0]
        assert start_ctx["tensor_name"] == "w"
        assert start_ctx["num_chunks"] == 2

        end_ctx = [e[1] for e in trace_log if e[0] == "on_fetch_end"][0]
        assert end_ctx["new_state"] == "resident"
        assert "duration_ms" in end_ctx

    def test_evict_hook_called(self):
        vt, chunks = _make_tensor()
        trace_log: list[tuple[str, dict]] = []

        vt.set_tracing_hooks(on_evict=lambda n, c: trace_log.append((n, c)))
        vt.materialize(fetch_func=_fetch_fn(chunks))
        vt.evict()

        assert len(trace_log) == 1
        assert trace_log[0][0] == "on_evict"
        assert trace_log[0][1]["tensor_name"] == "w"
        assert trace_log[0][1]["old_state"] == "resident"


# ---------------------------------------------------------------------------
# evict()
# ---------------------------------------------------------------------------


class TestEvict:
    def test_evict_clears_chunk_data(self):
        vt, chunks = _make_tensor()
        vt.materialize(fetch_func=_fetch_fn(chunks))
        assert len(vt._chunk_data) == 2
        vt.evict()
        assert len(vt._chunk_data) == 0

    def test_evict_from_cached_clears_data(self):
        vt, chunks = _make_tensor()
        vt.materialize(fetch_func=_fetch_fn(chunks))
        vt.demote()
        assert len(vt._chunk_data) == 2
        vt.evict()
        assert len(vt._chunk_data) == 0
        assert vt.is_remote


# ---------------------------------------------------------------------------
# total_bytes property
# ---------------------------------------------------------------------------


class TestTotalBytes:
    def test_float32_2x2(self):
        vt, _ = _make_tensor(shape=(2, 2), dtype="float32")
        # 2*2*4 = 16 bytes
        assert vt.total_bytes == 16

    def test_float16_4x4(self):
        vt, _ = _make_tensor(shape=(4, 4), dtype="float16")
        # 4*4*2 = 32 bytes
        assert vt.total_bytes == 32

    def test_float64_3d(self):
        vt, _ = _make_tensor(shape=(2, 3, 4), dtype="float64")
        # 2*3*4*8 = 192 bytes
        assert vt.total_bytes == 192

    def test_int32_1d(self):
        vt, _ = _make_tensor(shape=(10,), dtype="int32")
        assert vt.total_bytes == 40

    def test_bfloat16_fallback(self):
        # bfloat16 is not natively supported by numpy; the _dtype_to_numpy
        # mapper falls back to float32 (itemsize=4). Create the VT directly
        # instead of through _make_tensor (which uses np.astype).
        addr = _make_chunk_addr("bf16.0")
        vt = VirtualTensor(
            name="bf16", shape=(2, 2), dtype="bfloat16", chunk_addresses=[addr]
        )
        # bfloat16 falls back to float32 in the dtype map: 2*2*4=16
        assert vt.total_bytes == 16


# ---------------------------------------------------------------------------
# State properties
# ---------------------------------------------------------------------------


class TestStateProperties:
    def test_initial_state_is_remote(self):
        vt, _ = _make_tensor()
        assert vt.is_remote
        assert not vt.is_cached
        assert not vt.is_resident

    def test_cached_properties(self):
        vt, _ = _make_tensor()
        vt._transition_to(TensorState.CACHED)
        assert vt.is_cached
        assert not vt.is_remote
        assert not vt.is_resident

    def test_resident_properties(self):
        vt, _ = _make_tensor()
        vt._transition_to(TensorState.CACHED)
        vt._transition_to(TensorState.RESIDENT)
        assert vt.is_resident
        assert not vt.is_remote
        assert not vt.is_cached


# ---------------------------------------------------------------------------
# num_chunks
# ---------------------------------------------------------------------------


class TestNumChunks:
    def test_single_chunk(self):
        vt, _ = _make_tensor(num_chunks=1)
        assert vt.num_chunks == 1

    def test_multiple_chunks(self):
        vt, _ = _make_tensor(num_chunks=5)
        assert vt.num_chunks == 5
