"""Unit tests for Rex core types and errors."""
import pytest
from rex.core.types import (
    ByteRange, ChunkAddress, ChunkPriority, ChunkMetadata,
    CompressionCodec, TensorState, TensorDescriptor,
    RexManifest, CacheConstraints, FetchResult, InferenceMetrics,
    StorageBackendType, CachePolicyName,
)
from rex.core.errors import (
    FetchError, UnsupportedBackendError,
    ChunkIntegrityError, InvariantViolationError,
    InvalidStateTransitionError, ManifestValidationError,
)


class TestByteRange:
    def test_size(self):
        br = ByteRange(start=0, end=100)
        assert br.size == 100

    def test_http_header(self):
        br = ByteRange(start=100, end=200)
        assert br.to_http_header() == "bytes=100-199"

    def test_invalid_start_greater_than_end(self):
        with pytest.raises(AssertionError):
            ByteRange(start=10, end=5)

    def test_negative_start(self):
        with pytest.raises(AssertionError):
            ByteRange(start=-1, end=10)


class TestChunkAddress:
    def test_size_bytes(self):
        ca = ChunkAddress("test.bin", ByteRange(0, 512), "test.0000")
        assert ca.size_bytes == 512


class TestTensorDescriptor:
    def test_basic(self):
        td = TensorDescriptor(name="w", shape=(64, 128), dtype="float32", num_chunks=4, total_bytes=32768)
        assert td.shape == (64, 128)
        assert td.num_chunks == 4


class TestRexManifest:
    def test_defaults(self):
        m = RexManifest(manifest_version="0.1.0", model_id="t", model_family="d", source_framework="pytorch")
        assert m.default_chunk_size == 524288
        assert m.cache_constraints.max_local_fraction_of_model == 0.4
        assert m.feature_flags["compressed_chunks"] is False


class TestErrors:
    def test_fetch_error(self):
        e = FetchError("c1", "r1", status_code=404)
        assert "c1" in str(e) and "404" in str(e)

    def test_invariant_violation(self):
        e = InvariantViolationError(500, 1000, 0.5, 0.4)
        assert "50.0%" in str(e)

    def test_state_transition_error(self):
        e = InvalidStateTransitionError("c1", "REMOTE", "RESIDENT")
        assert "c1" in str(e)

    def test_unsupported_backend(self):
        e = UnsupportedBackendError("icloud", "no API")
        assert "icloud" in str(e)

    def test_chunk_integrity(self):
        e = ChunkIntegrityError("c1", "aabb", "ccdd")
        assert "mismatch" in str(e).lower()
