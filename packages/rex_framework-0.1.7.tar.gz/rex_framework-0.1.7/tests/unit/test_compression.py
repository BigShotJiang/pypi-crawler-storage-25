"""Unit tests for compression module."""
import pytest
from rex.formats.compression import compress, decompress, detect_codec, compression_ratio, CompressionError
from rex.core.types import CompressionCodec


class TestCompression:
    def test_none_roundtrip(self):
        data = b"hello world" * 100
        compressed = compress(data, CompressionCodec.NONE)
        result, codec = decompress(compressed)
        assert result == data

    def test_lz4_roundtrip(self):
        pytest.importorskip("lz4")
        data = b"x" * 10000
        compressed = compress(data, CompressionCodec.LZ4)
        assert len(compressed) < len(data)
        result, codec = decompress(compressed)
        assert result == data
        assert codec == CompressionCodec.LZ4

    def test_zstd_roundtrip(self):
        pytest.importorskip("zstandard")
        data = b"hello" * 5000
        compressed = compress(data, CompressionCodec.ZSTD)
        result, codec = decompress(compressed)
        assert result == data

    def test_empty_data(self):
        compressed = compress(b"", CompressionCodec.NONE)
        result, codec = decompress(compressed)
        assert result == b""

    def test_detect_codec_none(self):
        compressed = compress(b"test", CompressionCodec.NONE)
        assert detect_codec(compressed) == CompressionCodec.NONE

    def test_detect_codec_lz4(self):
        pytest.importorskip("lz4")
        compressed = compress(b"x" * 1000, CompressionCodec.LZ4)
        assert detect_codec(compressed) == CompressionCodec.LZ4

    def test_invalid_header(self):
        with pytest.raises(CompressionError):
            decompress(b"XYshort")

    def test_compression_ratio(self):
        assert compression_ratio(1000, 500) == 2.0
        assert compression_ratio(100, 0) == 1.0

    def test_too_short_data_raises(self):
        with pytest.raises(CompressionError):
            decompress(b"short")
