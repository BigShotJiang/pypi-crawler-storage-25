"""Tests for attention-locality and MoE prefetch priors (Target 7)."""
from __future__ import annotations

import pytest

from rex.core.prefetch_optimizer import (
    AttentionLocalityPrior,
    MoEExpertPrefetchHint,
    PrefetchCandidate,
    apply_attention_prior,
    apply_moe_prior,
)


def _cand(chunk_id: str, prob: float = 0.5) -> PrefetchCandidate:
    return PrefetchCandidate(
        chunk_id=chunk_id,
        size_bytes=100,
        probability=prob,
        estimated_latency_ms=10.0,
    )


class TestAttentionLocalityPrior:
    def test_prior_dataclass_fields(self):
        prior = AttentionLocalityPrior(head_count=8, locality_window=3)
        assert prior.head_count == 8
        assert prior.locality_window == 3

    def test_default_locality_window(self):
        prior = AttentionLocalityPrior(head_count=4)
        assert prior.locality_window == 4

    def test_boosted_near_head(self):
        candidates = [_cand(f"h{i}", prob=0.5) for i in range(8)]
        prior = AttentionLocalityPrior(head_count=8, locality_window=2)
        result = apply_attention_prior(candidates, prior, current_head_index=0)
        # Head 0 is at distance 0 from current → should be boosted
        assert result[0].probability > candidates[0].probability

    def test_distant_head_not_boosted(self):
        candidates = [_cand(f"h{i}", prob=0.5) for i in range(8)]
        prior = AttentionLocalityPrior(head_count=8, locality_window=1)
        result = apply_attention_prior(candidates, prior, current_head_index=0)
        # Head 7 is far from head 0 → probability unchanged
        assert result[7].probability == pytest.approx(candidates[7].probability)

    def test_empty_candidates(self):
        prior = AttentionLocalityPrior(head_count=8)
        result = apply_attention_prior([], prior)
        assert result == []

    def test_probabilities_capped_at_one(self):
        candidates = [_cand("h0", prob=1.0)]
        prior = AttentionLocalityPrior(head_count=1, locality_window=1)
        result = apply_attention_prior(candidates, prior)
        assert result[0].probability <= 1.0


class TestMoEExpertPrefetchHint:
    def test_hint_dataclass_fields(self):
        hint = MoEExpertPrefetchHint(
            expert_chunk_ids=["e0", "e1"],
            routing_probabilities=[0.7, 0.3],
            top_k=1,
        )
        assert hint.top_k == 1
        assert len(hint.expert_chunk_ids) == 2

    def test_default_top_k(self):
        hint = MoEExpertPrefetchHint(
            expert_chunk_ids=["e0"],
            routing_probabilities=[0.9],
        )
        assert hint.top_k == 2

    def test_top_k_experts_boosted(self):
        hint = MoEExpertPrefetchHint(
            expert_chunk_ids=["e0", "e1", "e2"],
            routing_probabilities=[0.6, 0.3, 0.1],
            top_k=2,
        )
        candidates = [_cand("e0", prob=0.4), _cand("e1", prob=0.4), _cand("e2", prob=0.4)]
        result = apply_moe_prior(candidates, hint)
        # e0 and e1 are top-2 → boosted
        assert result[0].probability > candidates[0].probability
        assert result[1].probability > candidates[1].probability
        # e2 is not top-2 → unchanged
        assert result[2].probability == pytest.approx(candidates[2].probability)

    def test_probability_capped_at_one(self):
        hint = MoEExpertPrefetchHint(
            expert_chunk_ids=["e0"],
            routing_probabilities=[1.0],
            top_k=1,
        )
        candidates = [_cand("e0", prob=1.0)]
        result = apply_moe_prior(candidates, hint)
        assert result[0].probability <= 1.0

    def test_empty_hint_no_change(self):
        hint = MoEExpertPrefetchHint(expert_chunk_ids=[], routing_probabilities=[])
        candidates = [_cand("e0", prob=0.5)]
        result = apply_moe_prior(candidates, hint)
        assert result[0].probability == pytest.approx(0.5)

    def test_non_expert_chunks_unchanged(self):
        hint = MoEExpertPrefetchHint(
            expert_chunk_ids=["e0"],
            routing_probabilities=[0.9],
            top_k=1,
        )
        candidates = [_cand("unrelated", prob=0.5)]
        result = apply_moe_prior(candidates, hint)
        assert result[0].probability == pytest.approx(0.5)
