"""Unit tests for execution graph modeling utilities."""

import pytest

from rex.core.graph_model import ExecutionDAG, GraphEdge, GraphNode
from rex.core.types import ByteRange, ChunkAddress


def _addr(chunk_id: str) -> ChunkAddress:
    return ChunkAddress(
        chunk_id=chunk_id,
        resource_id="weights.bin",
        byte_range=ByteRange(start=0, end=128),
    )


class TestExecutionDAGFromOrder:
    def test_builds_linear_dag(self):
        order = ["a", "b", "c"]
        lookup = {
            "a": [_addr("a.0")],
            "b": [_addr("b.0")],
            "c": [_addr("c.0")],
        }

        dag = ExecutionDAG.from_execution_order(order, lookup)
        assert dag.node_count == 3
        assert dag.edge_count == 2
        assert dag.topological_order() == order

    def test_missing_lookup_defaults_to_empty_chunk_set(self):
        order = ["a"]
        dag = ExecutionDAG.from_execution_order(order, chunk_lookup={})
        assert dag.nodes["a"].weight_chunk_ids == set()


class TestExecutionDAGValidation:
    def test_edges_with_unknown_nodes_raise(self):
        with pytest.raises(ValueError, match="unknown nodes"):
            ExecutionDAG(
                nodes={"a": GraphNode(name="a")},
                edges=[GraphEdge(src="a", dst="b")],
            )

    def test_cycle_detection_raises(self):
        dag = ExecutionDAG(
            nodes={
                "a": GraphNode(name="a"),
                "b": GraphNode(name="b"),
            },
            edges=[GraphEdge("a", "b"), GraphEdge("b", "a")],
        )
        with pytest.raises(ValueError, match="cycle"):
            dag.topological_order()


class TestCriticalPath:
    def test_critical_path_cost(self):
        dag = ExecutionDAG(
            nodes={
                "a": GraphNode(name="a", compute_cost_ms=1.0),
                "b": GraphNode(name="b", compute_cost_ms=2.5),
                "c": GraphNode(name="c", compute_cost_ms=3.0),
            },
            edges=[GraphEdge("a", "b"), GraphEdge("b", "c")],
        )
        assert dag.critical_path_cost_ms() == pytest.approx(6.5)


class TestPartitioning:
    def test_partition_by_cache_budget(self):
        dag = ExecutionDAG(
            nodes={
                "n1": GraphNode(name="n1", weight_chunk_ids={"c1"}),
                "n2": GraphNode(name="n2", weight_chunk_ids={"c2"}),
                "n3": GraphNode(name="n3", weight_chunk_ids={"c3"}),
            },
            edges=[GraphEdge("n1", "n2"), GraphEdge("n2", "n3")],
        )

        parts = dag.partition_by_cache_budget(
            cache_budget_bytes=2,
            chunk_size_lookup={"c1": 1, "c2": 1, "c3": 1},
        )
        assert parts == [["n1", "n2"], ["n3"]]

    def test_partition_raises_if_single_node_exceeds_budget(self):
        dag = ExecutionDAG(
            nodes={"n1": GraphNode(name="n1", weight_chunk_ids={"big"})},
            edges=[],
        )
        with pytest.raises(ValueError, match="exceeds cache budget"):
            dag.partition_by_cache_budget(
                cache_budget_bytes=10,
                chunk_size_lookup={"big": 11},
            )
