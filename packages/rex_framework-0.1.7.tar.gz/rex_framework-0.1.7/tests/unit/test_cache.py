"""Unit tests for cache system."""
import pytest
import asyncio
import time
from rex.cache.policies import LRUPolicy, LFUPolicy, WeightedUtilityPolicy, ProbabilisticUtilityPolicy, CacheEntry, create_policy
from rex.cache.residency import ResidencyTracker
from rex.cache.memory_cache import MemoryCache
from rex.cache.disk_cache import DiskCache
from rex.cache.two_tier import TwoTierCache
from rex.core.errors import InvariantViolationError
from rex.core.invariants import InvariantChecker
from rex.core.types import CachePolicyName


class TestCacheEntry:
    def test_creation(self):
        e = CacheEntry(chunk_id="c1", data=b"hello", last_access_time=time.time(), access_count=1, prefetch_score=0.5)
        assert e.chunk_id == "c1"


class TestLRUPolicy:
    def test_evicts_least_recently_used(self):
        now = time.time()
        entries = {
            "old": CacheEntry("old", b"x" * 100, last_access_time=now - 100, access_count=5, prefetch_score=0.1),
            "new": CacheEntry("new", b"x" * 100, last_access_time=now, access_count=1, prefetch_score=0.1),
        }
        policy = LRUPolicy()
        victim = policy.select_victim(entries)
        assert victim == "old"


class TestLFUPolicy:
    def test_evicts_least_frequently_used(self):
        entries = {
            "rare": CacheEntry("rare", b"x" * 100, last_access_time=0, access_count=1, prefetch_score=0.1),
            "often": CacheEntry("often", b"x" * 100, last_access_time=0, access_count=10, prefetch_score=0.1),
        }
        policy = LFUPolicy()
        victim = policy.select_victim(entries)
        assert victim == "rare"


class TestPolicyFactory:
    def test_probabilistic_policy_factory(self):
        policy = create_policy("probabilistic_utility")
        assert isinstance(policy, ProbabilisticUtilityPolicy)


class TestResidencyTracker:
    def test_track_resident(self):
        tracker = ResidencyTracker()
        tracker.record_resident("c1", 1024)
        tracker.record_resident("c2", 2048)
        assert tracker.get_resident_bytes() == 3072
        assert tracker.get_total_local_bytes() == 3072

    def test_track_cached(self):
        tracker = ResidencyTracker()
        tracker.record_cached("c1", 512)
        assert tracker.get_cached_bytes() == 512

    def test_evict_resident(self):
        tracker = ResidencyTracker()
        tracker.record_resident("c1", 1024)
        tracker.record_resident("c2", 2048)
        tracker.record_evicted("c1")
        assert tracker.get_resident_bytes() == 2048

    def test_clear(self):
        tracker = ResidencyTracker()
        tracker.record_resident("c1", 1024)
        tracker.clear()
        assert tracker.get_total_local_bytes() == 0


class TestMemoryCache:
    """Tests for the async MemoryCache."""

    def _run(self, coro):
        return asyncio.get_event_loop().run_until_complete(coro)

    def test_put_and_get(self):
        cache = MemoryCache(max_bytes=4096)
        self._run(cache.put("c1", b"hello"))
        result = self._run(cache.get("c1"))
        assert result == b"hello"

    def test_cache_miss(self):
        cache = MemoryCache(max_bytes=4096)
        result = self._run(cache.get("nonexistent"))
        assert result is None

    def test_contains(self):
        cache = MemoryCache(max_bytes=4096)
        self._run(cache.put("c1", b"data"))
        assert self._run(cache.contains("c1")) is True
        assert self._run(cache.contains("c2")) is False

    def test_evict(self):
        cache = MemoryCache(max_bytes=4096)
        self._run(cache.put("c1", b"data"))
        assert self._run(cache.evict("c1")) is True
        assert self._run(cache.contains("c1")) is False

    def test_stats(self):
        cache = MemoryCache(max_bytes=4096)
        self._run(cache.put("c1", b"data"))
        self._run(cache.get("c1"))  # hit
        self._run(cache.get("c2"))  # miss
        stats = self._run(cache.get_stats())
        assert stats.hit_count >= 1
        assert stats.miss_count >= 1

    def test_overcapacity_evicts(self):
        cache = MemoryCache(max_bytes=100)
        self._run(cache.put("c1", b"x" * 60))
        self._run(cache.put("c2", b"y" * 60))
        # At least one should exist
        assert self._run(cache.contains("c2"))


class TestDiskCache:
    def test_put_get(self, tmp_path):
        cache = DiskCache(cache_dir=tmp_path / "dc", max_bytes=0)
        cache.put("c1", b"hello disk")
        assert cache.get("c1") == b"hello disk"

    def test_miss(self, tmp_path):
        cache = DiskCache(cache_dir=tmp_path / "dc")
        assert cache.get("nonexistent") is None

    def test_evict(self, tmp_path):
        cache = DiskCache(cache_dir=tmp_path / "dc")
        cache.put("c1", b"data")
        assert cache.evict("c1")
        assert cache.get("c1") is None

    def test_clear(self, tmp_path):
        cache = DiskCache(cache_dir=tmp_path / "dc")
        cache.put("c1", b"a")
        cache.put("c2", b"b")
        cache.clear()
        assert cache.get("c1") is None


class TestTwoTierCache:
    def _run(self, coro):
        return asyncio.get_event_loop().run_until_complete(coro)

    def test_disk_promotion_updates_stats(self, tmp_path):
        memory = MemoryCache(max_bytes=1024)
        disk = DiskCache(cache_dir=tmp_path / "dc", max_bytes=0)
        cache = TwoTierCache(memory_cache=memory, disk_cache=disk)

        self._run(cache.put("c1", b"hello"))
        self._run(memory.evict("c1"))
        assert self._run(cache.get("c1")) == b"hello"

        stats = self._run(cache.get_stats())
        assert getattr(stats, "disk_hits") >= 1
        assert getattr(stats, "promotion_count") >= 1


class TestInvariantChecker:
    def _make_checker(self, total_bytes=10000, max_frac=0.4, safety=0.0):
        return InvariantChecker(
            total_model_bytes=total_bytes,
            max_local_fraction=max_frac,
            safety_margin_fraction=safety,
        )

    def test_passes_when_under_limit(self):
        checker = self._make_checker()
        result = checker.check_invariant(resident_bytes=3000, cached_bytes=0, raise_on_violation=False)
        assert result.is_valid

    def test_fails_when_over_limit(self):
        checker = self._make_checker()
        result = checker.check_invariant(resident_bytes=5000, cached_bytes=0, raise_on_violation=False)
        assert not result.is_valid

    def test_safety_margin(self):
        checker = self._make_checker(safety=0.05)
        # bytes_until_violation returns remaining bytes before violation
        remaining = checker.bytes_until_violation(resident_bytes=0, cached_bytes=0)
        assert remaining > 0


class TestMemoryCacheInvariantEnforcement:
    """Tests verifying that MemoryCache enforces the bounded-residency invariant."""

    def _run(self, coro):
        return asyncio.get_event_loop().run_until_complete(coro)

    def test_no_violation_when_under_limit(self):
        """Cache insertion within limit should succeed without raising."""
        checker = InvariantChecker(
            total_model_bytes=10_000,
            max_local_fraction=0.4,
            safety_margin_fraction=0.0,
        )
        # max_allowed = 4000 bytes; insert 100 bytes — well under limit
        cache = MemoryCache(max_bytes=4096, invariant_checker=checker)
        ok = self._run(cache.put("c1", b"x" * 100))
        assert ok

    def test_raises_on_invariant_violation(self):
        """Cache insertion that exceeds the invariant limit should raise."""
        checker = InvariantChecker(
            total_model_bytes=1_000,
            max_local_fraction=0.4,
            safety_margin_fraction=0.0,
        )
        # max_allowed = 400 bytes; insert 500 bytes -> violation
        cache = MemoryCache(max_bytes=4096, invariant_checker=checker)
        with pytest.raises(InvariantViolationError):
            self._run(cache.put("c1", b"x" * 500))

    def test_no_checker_does_not_raise(self):
        """Without an invariant checker, large inserts succeed without error."""
        cache = MemoryCache(max_bytes=4096)
        ok = self._run(cache.put("c1", b"x" * 4000))
        assert ok

    def test_invariant_enforced_on_update(self):
        """Updating an existing entry also triggers the invariant check."""
        checker = InvariantChecker(
            total_model_bytes=1_000,
            max_local_fraction=0.4,
            safety_margin_fraction=0.0,
        )
        # max_allowed = 400 bytes
        cache = MemoryCache(max_bytes=4096, invariant_checker=checker)
        # First put: 100 bytes — OK
        self._run(cache.put("c1", b"x" * 100))
        # Update same key with 500 bytes — should violate
        with pytest.raises(InvariantViolationError):
            self._run(cache.put("c1", b"y" * 500))

    def test_invariant_checker_property(self):
        """The invariant_checker property returns the configured checker."""
        checker = InvariantChecker(total_model_bytes=1_000, max_local_fraction=0.4)
        cache = MemoryCache(max_bytes=4096, invariant_checker=checker)
        assert cache.invariant_checker is checker

    def test_no_invariant_checker_property_is_none(self):
        """The invariant_checker property is None when not configured."""
        cache = MemoryCache(max_bytes=4096)
        assert cache.invariant_checker is None

    def test_get_resident_bytes_included_in_check(self):
        """get_resident_bytes callback is used to include resident bytes in the check."""
        checker = InvariantChecker(
            total_model_bytes=1_000,
            max_local_fraction=0.4,
            safety_margin_fraction=0.0,
        )
        # max_allowed = 400 bytes; resident callback returns 300 bytes
        # Inserting 200 bytes cached => total = 500 > 400 => violation
        cache = MemoryCache(
            max_bytes=4096,
            invariant_checker=checker,
            get_resident_bytes=lambda: 300,
        )
        with pytest.raises(InvariantViolationError):
            self._run(cache.put("c1", b"x" * 200))

    def test_no_violation_when_resident_bytes_within_limit(self):
        """No violation when resident + cached bytes are within the limit."""
        checker = InvariantChecker(
            total_model_bytes=1_000,
            max_local_fraction=0.4,
            safety_margin_fraction=0.0,
        )
        # max_allowed = 400 bytes; resident = 100, cached = 100 => total 200 — OK
        cache = MemoryCache(
            max_bytes=4096,
            invariant_checker=checker,
            get_resident_bytes=lambda: 100,
        )
        ok = self._run(cache.put("c1", b"x" * 100))
        assert ok
