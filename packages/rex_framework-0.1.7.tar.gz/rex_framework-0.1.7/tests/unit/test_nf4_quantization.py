"""Tests for NF4 quantization and select_precision (Target 9)."""
from __future__ import annotations

import numpy as np
import pytest

from rex.convert.quantize import (
    NF4_LEVELS,
    QuantizeError,
    dequantize_nf4,
    quantize_nf4,
    select_precision,
)


class TestNF4Levels:
    def test_has_16_levels(self):
        assert len(NF4_LEVELS) == 16

    def test_symmetric_range(self):
        assert NF4_LEVELS[0] == -1.0
        assert NF4_LEVELS[-1] == 1.0

    def test_sorted(self):
        assert NF4_LEVELS == sorted(NF4_LEVELS)


class TestQuantizeNF4:
    def test_output_types(self):
        arr = np.random.randn(16).astype(np.float32)
        packed, meta = quantize_nf4(arr)
        assert isinstance(packed, bytes)
        assert isinstance(meta, dict)

    def test_metadata_keys(self):
        arr = np.ones(8, dtype=np.float32)
        _, meta = quantize_nf4(arr)
        assert "abs_max" in meta
        assert "original_dtype" in meta
        assert meta["bits"] == 4
        assert meta["scheme"] == "nf4"
        assert meta["num_values"] == 8

    def test_zero_array(self):
        arr = np.zeros(8, dtype=np.float32)
        packed, meta = quantize_nf4(arr)
        assert meta["abs_max"] == pytest.approx(1.0)

    def test_roundtrip_accuracy(self):
        rng = np.random.default_rng(42)
        arr = rng.standard_normal(64).astype(np.float32)
        packed, meta = quantize_nf4(arr)
        restored = dequantize_nf4(packed, meta, arr.shape)
        assert restored.shape == arr.shape
        # NF4 is lossy; check relative error is reasonable
        rel_err = np.linalg.norm(arr - restored) / (np.linalg.norm(arr) + 1e-8)
        assert rel_err < 0.5

    def test_float16_input(self):
        arr = np.array([0.1, -0.5, 0.9], dtype=np.float16)
        packed, meta = quantize_nf4(arr)
        assert meta["num_values"] == 3

    def test_packed_bytes_smaller_than_float32(self):
        arr = np.ones(64, dtype=np.float32)
        packed, _ = quantize_nf4(arr)
        # 64 values × 4 bits = 32 bytes < 256 bytes (float32)
        assert len(packed) <= 32


class TestDequantizeNF4:
    def test_output_shape(self):
        arr = np.random.randn(4, 4).astype(np.float32)
        packed, meta = quantize_nf4(arr)
        restored = dequantize_nf4(packed, meta, (4, 4))
        assert restored.shape == (4, 4)

    def test_output_dtype_float32(self):
        arr = np.ones(8, dtype=np.float32)
        packed, meta = quantize_nf4(arr)
        restored = dequantize_nf4(packed, meta, (8,))
        assert restored.dtype == np.float32


class TestSelectPrecision:
    def test_returns_tuple(self):
        arr = np.random.randn(32).astype(np.float32)
        bits, scheme = select_precision(arr)
        assert isinstance(bits, int)
        assert isinstance(scheme, str)

    def test_smooth_array_uses_low_bits(self):
        """A smooth constant array should be well-represented at low bit widths."""
        arr = np.full(64, 0.5, dtype=np.float32)
        bits, scheme = select_precision(arr, max_bits=8, distortion_threshold=0.05)
        assert bits <= 8

    def test_high_distortion_threshold_picks_low_bits(self):
        arr = np.random.randn(64).astype(np.float32)
        bits, scheme = select_precision(arr, max_bits=8, distortion_threshold=0.99)
        assert bits <= 4

    def test_low_distortion_threshold_picks_high_bits(self):
        arr = np.random.randn(64).astype(np.float32)
        bits, scheme = select_precision(arr, max_bits=8, distortion_threshold=0.0)
        # No format can achieve 0 distortion (except INT8 maybe), should return INT8
        assert bits == 8

    def test_zero_array(self):
        arr = np.zeros(16, dtype=np.float32)
        bits, scheme = select_precision(arr)
        assert bits in (4, 8)
        assert scheme in ("nf4", "symmetric_uniform")

    def test_scheme_values(self):
        arr = np.random.randn(32).astype(np.float32)
        bits, scheme = select_precision(arr)
        assert scheme in ("nf4", "symmetric_uniform")
