"""Tests for horizon tuning and queue-state admission in plan_prefetch (Target 4)."""
from __future__ import annotations

import pytest

from rex.core.prefetch_optimizer import PrefetchCandidate, plan_prefetch


def _make_candidate(chunk_id: str, size: int = 100, prob: float = 0.8, latency: float = 50.0) -> PrefetchCandidate:
    return PrefetchCandidate(
        chunk_id=chunk_id,
        size_bytes=size,
        probability=prob,
        estimated_latency_ms=latency,
    )


class TestHorizonTuning:
    def test_horizon_one_no_decay(self):
        cands = [_make_candidate("a", prob=0.8)]
        result = plan_prefetch(cands, budget_bytes=1000, horizon=1, decay_factor=0.1)
        assert len(result) == 1
        assert result[0].probability == pytest.approx(0.8)

    def test_higher_horizon_reduces_probability(self):
        cands = [_make_candidate("a", prob=1.0)]
        result_h1 = plan_prefetch(cands, budget_bytes=1000, horizon=1, decay_factor=0.1)
        result_h3 = plan_prefetch(cands, budget_bytes=1000, horizon=3, decay_factor=0.1)
        assert result_h1[0].probability >= result_h3[0].probability

    def test_decay_can_drop_candidate_below_utility_threshold(self):
        """With extreme decay, a previously-admitted candidate may be de-prioritised."""
        cands = [
            _make_candidate("a", prob=0.9, size=100),
            _make_candidate("b", prob=0.1, size=100),
        ]
        # High horizon drops prob(a) heavily but both still admitted if budget allows
        result = plan_prefetch(cands, budget_bytes=1000, horizon=5, decay_factor=0.2)
        assert len(result) >= 1

    def test_zero_budget_returns_empty(self):
        cands = [_make_candidate("a")]
        result = plan_prefetch(cands, budget_bytes=0, horizon=2)
        assert result == []


class TestQueueStateAdmission:
    def test_low_priority_blocked_when_queue_full(self):
        """Low-probability candidates are dropped when queue is at max depth."""
        cands = [
            _make_candidate("a", prob=0.3),  # low priority
            _make_candidate("b", prob=0.8),  # high priority
        ]
        result = plan_prefetch(
            cands,
            budget_bytes=10_000,
            max_queue_depth=2,
            queue_depth=2,   # at limit
        )
        chunk_ids = {c.chunk_id for c in result}
        assert "a" not in chunk_ids  # dropped
        assert "b" in chunk_ids      # admitted

    def test_all_admitted_when_queue_below_limit(self):
        cands = [
            _make_candidate("a", prob=0.3),
            _make_candidate("b", prob=0.8),
        ]
        result = plan_prefetch(
            cands,
            budget_bytes=10_000,
            max_queue_depth=10,
            queue_depth=0,
        )
        assert len(result) == 2

    def test_no_limit_admits_all(self):
        cands = [_make_candidate(f"c{i}", prob=0.1) for i in range(5)]
        result = plan_prefetch(cands, budget_bytes=10_000, max_queue_depth=0, queue_depth=100)
        assert len(result) == 5

    def test_budget_still_respected_with_queue_limit(self):
        cands = [
            _make_candidate("x", size=600, prob=0.9),
            _make_candidate("y", size=600, prob=0.9),
        ]
        result = plan_prefetch(
            cands,
            budget_bytes=800,
            max_queue_depth=0,
        )
        assert len(result) == 1
