"""Tests for EMABayesianReusePredictor.confidence() and .feature_vector() (Target 3)."""
from __future__ import annotations

import pytest

from rex.cache.predictor import EMABayesianReusePredictor


class TestConfidence:
    def test_zero_observations_gives_zero_confidence(self):
        pred = EMABayesianReusePredictor()
        pred.observe_insert("chunk_a")
        assert pred.confidence("chunk_a") == 0.0

    def test_confidence_increases_with_observations(self):
        pred = EMABayesianReusePredictor()
        for _ in range(5):
            pred.observe_access("chunk_a", reused=True)
        conf = pred.confidence("chunk_a", max_observations=10)
        assert 0.0 < conf <= 1.0
        assert conf == pytest.approx(0.5)

    def test_confidence_saturates_at_one(self):
        pred = EMABayesianReusePredictor()
        for _ in range(20):
            pred.observe_access("chunk_a", reused=True)
        conf = pred.confidence("chunk_a", max_observations=10)
        assert conf == pytest.approx(1.0)

    def test_confidence_unknown_chunk_is_zero(self):
        pred = EMABayesianReusePredictor()
        assert pred.confidence("unknown") == 0.0


class TestFeatureVector:
    def test_feature_vector_keys(self):
        pred = EMABayesianReusePredictor()
        pred.observe_access("chunk_b", reused=True)
        fv = pred.feature_vector("chunk_b")
        assert set(fv.keys()) == {
            "probability", "confidence", "observations",
            "ema_probability", "posterior_mean"
        }

    def test_feature_vector_values_in_range(self):
        pred = EMABayesianReusePredictor()
        for _ in range(5):
            pred.observe_access("chunk_b", reused=True)
        fv = pred.feature_vector("chunk_b")
        assert 0.0 <= fv["probability"] <= 1.0
        assert 0.0 <= fv["confidence"] <= 1.0
        assert fv["observations"] == 5
        assert 0.0 <= fv["ema_probability"] <= 1.0
        assert 0.0 <= fv["posterior_mean"] <= 1.0

    def test_feature_vector_posterior_mean_correct(self):
        pred = EMABayesianReusePredictor(prior_alpha=1.0, prior_beta=1.0)
        pred.observe_access("chunk_c", reused=True)  # alpha becomes 2, beta stays 1
        fv = pred.feature_vector("chunk_c")
        assert fv["posterior_mean"] == pytest.approx(2.0 / 3.0, abs=1e-6)
