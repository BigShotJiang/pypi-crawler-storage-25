"""Tests for BlockedExecutionMetadata, OperatorFusionHook, fusion_opportunities (Target 6)."""
from __future__ import annotations

import pytest

from rex.core.graph_model import (
    BlockedExecutionMetadata,
    ExecutionDAG,
    GraphEdge,
    GraphNode,
    GraphNodeMetadata,
    OperatorFusionHook,
    fusion_opportunities,
)


class TestBlockedExecutionMetadata:
    def test_defaults(self):
        meta = BlockedExecutionMetadata(block_size=64, num_blocks=16)
        assert meta.block_size == 64
        assert meta.num_blocks == 16
        assert meta.block_overlap == 0

    def test_with_overlap(self):
        meta = BlockedExecutionMetadata(block_size=32, num_blocks=8, block_overlap=4)
        assert meta.block_overlap == 4


class TestOperatorFusionHook:
    def test_defaults(self):
        hook = OperatorFusionHook(fused_op_name="matmul_relu", input_node_names=["a", "b"])
        assert hook.output_dtype == "float32"
        assert hook.fused_op_name == "matmul_relu"

    def test_custom_dtype(self):
        hook = OperatorFusionHook(
            fused_op_name="op", input_node_names=["x"], output_dtype="float16"
        )
        assert hook.output_dtype == "float16"


class TestGraphNodeMetadata:
    def test_empty_metadata(self):
        meta = GraphNodeMetadata()
        assert meta.blocked_execution is None
        assert meta.fusion_hook is None

    def test_with_blocked_execution(self):
        be = BlockedExecutionMetadata(block_size=128, num_blocks=4)
        meta = GraphNodeMetadata(blocked_execution=be)
        assert meta.blocked_execution.block_size == 128


class TestExecutionDAGNodeMetadata:
    def _make_dag(self):
        nodes = {
            "a": GraphNode(name="a"),
            "b": GraphNode(name="b"),
        }
        edges = [GraphEdge(src="a", dst="b")]
        return ExecutionDAG(nodes=nodes, edges=edges)

    def test_node_metadata_field_exists(self):
        dag = self._make_dag()
        assert hasattr(dag, "node_metadata")
        assert isinstance(dag.node_metadata, dict)

    def test_attach_metadata_to_node(self):
        dag = self._make_dag()
        be = BlockedExecutionMetadata(block_size=64, num_blocks=8)
        dag.node_metadata["a"] = GraphNodeMetadata(blocked_execution=be)
        assert dag.node_metadata["a"].blocked_execution.block_size == 64


class TestFusionOpportunities:
    def _make_linear_dag(self, n: int) -> ExecutionDAG:
        nodes = {f"n{i}": GraphNode(name=f"n{i}") for i in range(n)}
        edges = [GraphEdge(src=f"n{i}", dst=f"n{i+1}") for i in range(n - 1)]
        return ExecutionDAG(nodes=nodes, edges=edges)

    def test_linear_chain_single_fusion(self):
        dag = self._make_linear_dag(3)
        hooks = fusion_opportunities(dag)
        assert len(hooks) >= 1
        assert isinstance(hooks[0], OperatorFusionHook)

    def test_fused_op_name_includes_node_names(self):
        dag = self._make_linear_dag(2)
        hooks = fusion_opportunities(dag)
        assert len(hooks) == 1
        assert "n0" in hooks[0].fused_op_name
        assert "n1" in hooks[0].fused_op_name

    def test_branching_dag_has_no_fusion(self):
        """Diamond: a -> b, a -> c, b -> d, c -> d — no linear chains."""
        nodes = {n: GraphNode(name=n) for n in ["a", "b", "c", "d"]}
        edges = [
            GraphEdge(src="a", dst="b"),
            GraphEdge(src="a", dst="c"),
            GraphEdge(src="b", dst="d"),
            GraphEdge(src="c", dst="d"),
        ]
        dag = ExecutionDAG(nodes=nodes, edges=edges)
        hooks = fusion_opportunities(dag)
        assert hooks == []

    def test_single_node_dag(self):
        dag = self._make_linear_dag(1)
        hooks = fusion_opportunities(dag)
        assert hooks == []

    def test_long_chain_produces_one_hook(self):
        dag = self._make_linear_dag(5)
        hooks = fusion_opportunities(dag)
        assert len(hooks) == 1
        assert len(hooks[0].input_node_names) == 5
