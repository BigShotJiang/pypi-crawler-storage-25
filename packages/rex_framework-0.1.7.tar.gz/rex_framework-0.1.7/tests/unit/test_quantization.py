"""Unit tests for quantization helpers."""

import numpy as np

from rex.convert.quantize import (
    dequantize_tensor_from_bytes,
    quantization_compression_ratio,
    quantize_tensor_to_bytes,
)


class TestQuantizationRoundTrip:
    def test_int8_round_trip(self):
        arr = np.array([[0.5, -1.25], [2.0, -0.75]], dtype=np.float32)
        data, meta = quantize_tensor_to_bytes(arr, bits=8)
        restored = dequantize_tensor_from_bytes(data, meta, arr.shape)
        assert restored.shape == arr.shape
        np.testing.assert_allclose(restored, arr, atol=0.05, rtol=0.05)

    def test_int4_round_trip(self):
        arr = np.linspace(-2.0, 2.0, 16, dtype=np.float32).reshape(4, 4)
        data, meta = quantize_tensor_to_bytes(arr, bits=4)
        restored = dequantize_tensor_from_bytes(data, meta, arr.shape)
        np.testing.assert_allclose(restored, arr, atol=0.35, rtol=0.2)

    def test_low_bit_serialization_reduces_size(self):
        arr = np.random.randn(64).astype(np.float32)
        int8_bytes, _ = quantize_tensor_to_bytes(arr, bits=8)
        int4_bytes, _ = quantize_tensor_to_bytes(arr, bits=4)
        assert len(int4_bytes) < len(int8_bytes)


class TestQuantizationMetadata:
    def test_compression_ratio_helper(self):
        assert quantization_compression_ratio(8) == 4.0