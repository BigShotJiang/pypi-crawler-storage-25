"""Unit tests for RexConfig defaults and overrides."""

from rex.api.config import RexConfig


class TestSchedulerConfigPhase1:
    def test_defaults_include_graph_metadata_flags(self):
        cfg = RexConfig()
        assert cfg.scheduler.scheduler_mode == "graph"
        assert cfg.scheduler.build_execution_dag_metadata is True

    def test_from_dict_can_override_new_fields(self):
        cfg = RexConfig.from_dict(
            {
                "scheduler_scheduler_mode": "graph",
                "scheduler_build_execution_dag_metadata": False,
            }
        )
        assert cfg.scheduler.scheduler_mode == "graph"
        assert cfg.scheduler.build_execution_dag_metadata is False
