from __future__ import annotations

import importlib.util
from types import SimpleNamespace

import pytest

import rex
from rex.api.config import RexConfig
from rex.api.generate import run_inference_sync
from rex.api.load import load_model
from rex.core.runtime import RexRuntime
from rex.core.types import (
    InferenceMetrics,
)


@pytest.mark.asyncio
async def test_load_model_does_not_infer_local_weights_directory(tmp_path, monkeypatch):
    manifest_dir = tmp_path / "rex_out"
    manifest_dir.mkdir(parents=True)
    manifest_path = manifest_dir / "manifest.json"
    manifest_path.write_text("{}", encoding="utf-8")

    async def _fake_runtime_load(_self, _path: str) -> None:
        return None

    monkeypatch.setattr(RexRuntime, "load_model", _fake_runtime_load)

    runtime = load_model(str(manifest_path))
    try:
        assert runtime._config.storage.base_url == ""
    finally:
        await runtime.shutdown()


def test_top_level_exports_are_available():
    assert rex.load_model is load_model
    assert rex.run_inference_sync is run_inference_sync
    assert callable(rex.run_inference)


def test_run_inference_sync_shuts_runtime_down(monkeypatch):
    class _DummyRuntime:
        def __init__(self) -> None:
            self.shutdown_called = False

        async def run_inference(self, _input_data):
            return "output", InferenceMetrics(total_time_ms=1.0)

        async def shutdown(self) -> None:
            self.shutdown_called = True

    dummy = _DummyRuntime()
    monkeypatch.setattr("rex.api.generate.load_model", lambda *_args, **_kwargs: dummy)

    output, metrics = run_inference_sync(
        "manifest.json",
        input_data=SimpleNamespace(),
        config=RexConfig(),
    )

    assert output == "output"
    assert metrics.total_time_ms == 1.0
    assert dummy.shutdown_called is True


def test_legacy_import_paths_remain_available():
    assert importlib.util.find_spec("rex.convert.converter") is not None
    assert importlib.util.find_spec("rex.integration.pytorch.adapter") is not None
