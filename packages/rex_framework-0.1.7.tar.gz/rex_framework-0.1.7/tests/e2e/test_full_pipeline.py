"""Comprehensive end-to-end test for the full Rex inference pipeline.

Tests the complete workflow:
  1. Convert a PyTorch model to Rex chunk format
  2. Start a local HTTP chunk server
  3. Load the manifest via RexRuntime
  4. Run inference through the Rex executor
  5. Verify chunks were fetched, invariant enforced, all layers executed
  6. Verify output matches direct PyTorch inference
"""

from __future__ import annotations

import socket
import time
from pathlib import Path

import numpy as np
import pytest
import torch
import torch.nn as nn

from rex.convert.pytorch_converter import PyTorchConverter
from rex.core.runtime import RexRuntime
from rex.api.config import RexConfig
from rex.core.graph_scheduler import GraphScheduler
from rex.core.types import InferenceMetrics


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class SimpleMLP(nn.Module):
    """Two-layer MLP: input(in_f) -> hidden(hidden, ReLU) -> output(out)."""

    def __init__(self, in_f: int = 16, hidden: int = 8, out: int = 4):
        super().__init__()
        self.layer1 = nn.Linear(in_f, hidden)
        self.layer2 = nn.Linear(hidden, out)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = torch.relu(self.layer1(x))
        x = self.layer2(x)
        return x


def _find_free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


# Module-level state for the server (shared across async tests)
_server_port = [0]
_server_url = [""]


def _compute_fn(input_data: np.ndarray, weights: dict[str, np.ndarray]) -> np.ndarray:
    """Compute function for the SimpleMLP.

    Each call receives one parameter (dict with one key).
    Applies: weight -> matmul, bias -> add, ReLU after hidden layer bias.
    """
    x = input_data
    for pname, w in weights.items():
        if w is None:
            continue
        if "weight" in pname:
            x = x @ w.T
        elif "bias" in pname:
            x = x + w
    # ReLU after the hidden layer's bias
    if any("layer1.bias" in p for p in weights):
        x = np.maximum(x, 0.0)
    return x


def _start_server(weights_dir: str, port: int) -> None:
    """Start chunk server in a daemon thread."""
    import asyncio
    import threading

    async def _run():
        from rex.storage.local_server import serve_chunks
        await serve_chunks(chunk_dir=weights_dir, host="127.0.0.1", port=port)
        while True:
            await asyncio.sleep(3600)

    t = threading.Thread(target=lambda: asyncio.run(_run()), daemon=True)
    t.start()
    time.sleep(1.5)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(scope="module")
def torch_model():
    """Create a seeded SimpleMLP model (module-scoped for reuse)."""
    torch.manual_seed(42)
    return SimpleMLP(in_f=16, hidden=8, out=4)


@pytest.fixture(scope="module")
def converted_model(torch_model, tmp_path_factory):
    """Convert the PyTorch model to Rex format. Returns (output_dir, torch_model)."""
    output_dir = tmp_path_factory.mktemp("rex_e2e") / "rex_model"
    state_dict = torch_model.state_dict()

    converter = PyTorchConverter(
        output_dir=str(output_dir),
        chunk_size_bytes=512,
        model_id="e2e-pipeline-test",
        model_family="test",
    )
    converter.convert(state_dict)

    return output_dir, torch_model


@pytest.fixture(scope="module", autouse=True)
def server(converted_model):
    """Start a local chunk server for all tests in this module."""
    global _server_port, _server_url
    output_dir = converted_model[0]
    port = _find_free_port()
    _server_port[0] = port
    _server_url[0] = f"http://127.0.0.1:{port}"

    weights_dir = str(output_dir / "weights")
    _start_server(weights_dir, port)
    yield


def _make_runtime(converted_model) -> RexRuntime:
    """Create a RexRuntime configured for the test server."""
    config = RexConfig()
    config.storage.base_url = _server_url[0]
    config.cache.max_memory_cache_bytes = 1 * 1024 * 1024
    return RexRuntime(config=config)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestFullPipeline:
    """End-to-end tests for the complete Rex inference pipeline."""

    def test_convert_produces_valid_output(self, converted_model):
        """Verify conversion produces expected artifacts."""
        output_dir = converted_model[0]

        manifest_path = output_dir / "manifest.json"
        assert manifest_path.exists(), "manifest.json not created"

        weights_dir = output_dir / "weights"
        assert weights_dir.exists(), "weights directory not created"
        weight_files = list(weights_dir.glob("*.bin"))
        assert len(weight_files) > 0, "No chunk files created"

    def test_server_serves_chunks(self, converted_model):
        """Verify the HTTP server responds to chunk requests."""
        import urllib.request

        output_dir = converted_model[0]
        weights_dir = output_dir / "weights"

        for chunk_file in weights_dir.glob("*.bin"):
            url = f"{_server_url[0]}/{chunk_file.name}"
            req = urllib.request.Request(url)
            with urllib.request.urlopen(req, timeout=5) as resp:
                assert resp.status == 200
                data = resp.read()
                assert len(data) > 0

    @pytest.mark.asyncio
    async def test_load_manifest(self, converted_model):
        """Verify RexRuntime can load the manifest."""
        output_dir = converted_model[0]
        runtime = _make_runtime(converted_model)
        try:
            await runtime.load_model(str(output_dir / "manifest.json"))
            assert runtime.is_model_loaded
            assert runtime.manifest is not None
            assert runtime.manifest.model_id == "e2e-pipeline-test"
            assert runtime.execution_dag is not None
            assert runtime._config.scheduler.scheduler_mode == "graph"
            assert isinstance(runtime._scheduler, GraphScheduler)
            info = runtime.get_model_info()
            assert info["total_chunks"] > 0
            assert info["total_model_bytes"] > 0
        finally:
            await runtime.shutdown()

    @pytest.mark.asyncio
    async def test_inference_chunks_fetched(self, converted_model):
        """Verify that chunks are actually fetched (cache_misses > 0)."""
        output_dir = converted_model[0]
        runtime = _make_runtime(converted_model)
        try:
            await runtime.load_model(str(output_dir / "manifest.json"))

            input_np = np.random.randn(1, 16).astype(np.float32)
            output, metrics = await runtime.run_inference(input_np, compute_fn=_compute_fn)

            assert metrics.cache_misses > 0, "Expected at least one cache miss"
            assert metrics.chunks_fetched > 0, "Expected at least one chunk to be fetched"
            assert metrics.bytes_fetched_remote > 0, "Expected bytes to be transferred"
            assert isinstance(output, np.ndarray)
        finally:
            await runtime.shutdown()

    @pytest.mark.asyncio
    async def test_invariant_not_violated_aggressive(self, converted_model):
        """Verify the 'never hold full model locally' invariant with aggressive eviction."""
        output_dir = converted_model[0]
        config = RexConfig()
        config.storage.base_url = _server_url[0]
        config.cache.max_memory_cache_bytes = 1 * 1024 * 1024
        config.scheduler.eviction_strategy = "aggressive"
        runtime = RexRuntime(config=config)
        try:
            await runtime.load_model(str(output_dir / "manifest.json"))

            input_np = np.random.randn(1, 16).astype(np.float32)
            output, metrics = await runtime.run_inference(input_np, compute_fn=_compute_fn)

            assert metrics.invariant_violations == 0, (
                f"Expected zero invariant violations, got {metrics.invariant_violations}"
            )
        finally:
            await runtime.shutdown()

    @pytest.mark.asyncio
    async def test_all_layers_executed(self, converted_model):
        """Verify all layers in the execution graph were executed."""
        output_dir = converted_model[0]
        runtime = _make_runtime(converted_model)
        try:
            await runtime.load_model(str(output_dir / "manifest.json"))

            num_params = len(runtime.manifest.parameters)
            input_np = np.random.randn(1, 16).astype(np.float32)
            output, metrics = await runtime.run_inference(input_np, compute_fn=_compute_fn)

            assert metrics.layers_executed == num_params
        finally:
            await runtime.shutdown()

    @pytest.mark.asyncio
    async def test_re_fetch_after_eviction(self, converted_model):
        """Verify chunks are re-fetched on second inference with aggressive eviction."""
        output_dir = converted_model[0]
        config = RexConfig()
        config.storage.base_url = _server_url[0]
        config.cache.max_memory_cache_bytes = 1 * 1024 * 1024
        config.scheduler.eviction_strategy = "aggressive"
        runtime = RexRuntime(config=config)
        try:
            await runtime.load_model(str(output_dir / "manifest.json"))

            input_np = np.random.randn(1, 16).astype(np.float32)

            _, metrics1 = await runtime.run_inference(input_np, compute_fn=_compute_fn)
            _, metrics2 = await runtime.run_inference(input_np, compute_fn=_compute_fn)

            assert metrics2.cache_misses > 0, (
                "Expected cache misses on second inference with aggressive eviction"
            )
            assert metrics2.layers_executed == metrics1.layers_executed
        finally:
            await runtime.shutdown()

    @pytest.mark.asyncio
    async def test_warm_cache_hit_with_retain_strategy(self, converted_model):
        """Verify warm cache hits when using retain_n_layers eviction strategy."""
        output_dir = converted_model[0]
        runtime = _make_runtime(converted_model)
        try:
            await runtime.load_model(str(output_dir / "manifest.json"))

            input_np = np.random.randn(1, 16).astype(np.float32)

            _, metrics1 = await runtime.run_inference(input_np, compute_fn=_compute_fn)
            _, metrics2 = await runtime.run_inference(input_np, compute_fn=_compute_fn)

            assert metrics2.cache_hits > 0, (
                f"Expected cache hits on warm inference, got {metrics2.cache_hits}"
            )
            assert metrics2.cache_misses < metrics1.cache_misses, (
                "Expected fewer cache misses on warm inference"
            )
            assert metrics2.layers_executed == metrics1.layers_executed
        finally:
            await runtime.shutdown()

    @pytest.mark.asyncio
    async def test_output_matches_pytorch(self, converted_model, torch_model):
        """Verify Rex output matches direct PyTorch inference."""
        output_dir = converted_model[0]
        runtime = _make_runtime(converted_model)
        try:
            await runtime.load_model(str(output_dir / "manifest.json"))

            np.random.seed(123)
            input_np = np.random.randn(2, 16).astype(np.float32)

            rex_output, metrics = await runtime.run_inference(input_np, compute_fn=_compute_fn)

            torch_model.eval()
            with torch.no_grad():
                pytorch_output = torch_model(torch.tensor(input_np)).numpy()

            assert rex_output.shape == pytorch_output.shape
            assert np.allclose(rex_output, pytorch_output, atol=1e-5), (
                f"Output mismatch. Max diff: {np.max(np.abs(rex_output - pytorch_output)):.2e}"
            )
        finally:
            await runtime.shutdown()

    @pytest.mark.asyncio
    async def test_metrics_are_sensible(self, converted_model):
        """Verify inference metrics are internally consistent."""
        output_dir = converted_model[0]
        runtime = _make_runtime(converted_model)
        try:
            await runtime.load_model(str(output_dir / "manifest.json"))

            input_np = np.random.randn(1, 16).astype(np.float32)
            _, metrics = await runtime.run_inference(input_np, compute_fn=_compute_fn)

            assert metrics.total_time_ms > 0
            assert metrics.total_time_ms >= metrics.compute_time_ms
            assert metrics.total_time_ms >= metrics.stall_time_ms
            assert isinstance(metrics, InferenceMetrics)
        finally:
            await runtime.shutdown()

    @pytest.mark.asyncio
    async def test_model_info_populated(self, converted_model):
        """Verify get_model_info returns complete information."""
        output_dir = converted_model[0]
        runtime = _make_runtime(converted_model)
        try:
            await runtime.load_model(str(output_dir / "manifest.json"))

            info = runtime.get_model_info()
            assert "model_id" in info
            assert info["model_id"] == "e2e-pipeline-test"
            assert info["source_framework"] == "pytorch"
            assert info["total_chunks"] > 0
            assert info["total_model_bytes"] > 0
        finally:
            await runtime.shutdown()

    @pytest.mark.asyncio
    async def test_layer_timings_recorded(self, converted_model):
        """Verify per-layer timing data is recorded."""
        output_dir = converted_model[0]
        runtime = _make_runtime(converted_model)
        try:
            await runtime.load_model(str(output_dir / "manifest.json"))

            input_np = np.random.randn(1, 16).astype(np.float32)
            await runtime.run_inference(input_np, compute_fn=_compute_fn)

            assert runtime._executor is not None
            timings = runtime._executor.get_layer_timings()
            assert len(timings) > 0

            for t in timings:
                assert t.total_ms >= 0
                assert t.success, f"Layer {t.layer_name} failed: {t.error}"
        finally:
            await runtime.shutdown()
