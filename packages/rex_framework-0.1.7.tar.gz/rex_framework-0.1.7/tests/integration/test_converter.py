"""Integration test for PyTorch converter."""
import pytest
import numpy as np
from pathlib import Path
from rex.convert.pytorch_converter import PyTorchConverter
from rex.convert.quantize import dequantize_tensor_from_bytes
from rex.formats.manifest import load_manifest, validate_manifest
from rex.formats.chunk_reader import ChunkReader
from rex.core.types import CompressionCodec


@pytest.fixture
def tiny_state_dict():
    """Create a tiny state dict for testing."""
    import torch
    return {
        "embedding.weight": torch.randn(100, 16),
        "layer0.attn.w_q": torch.randn(16, 16),
        "layer0.attn.w_k": torch.randn(16, 16),
        "layer0.attn.w_v": torch.randn(16, 16),
        "layer0.attn.w_o": torch.randn(16, 16),
        "layer0.ffn.fc1": torch.randn(16, 32),
        "layer0.ffn.fc2": torch.randn(32, 16),
        "layer0.norm1.weight": torch.randn(16),
        "layer0.norm1.bias": torch.randn(16),
        "output.weight": torch.randn(16, 100),
    }


class TestPyTorchConverter:
    def test_basic_conversion(self, tiny_state_dict, tmp_path):
        converter = PyTorchConverter(
            output_dir=tmp_path / "rex_out",
            chunk_size_bytes=1024,
            model_id="test-tiny",
            model_family="demo",
        )
        result = converter.convert(tiny_state_dict)

        assert result.num_parameters > 0
        assert result.num_chunks > 0
        assert result.total_original_bytes > 0
        assert result.conversion_time_seconds > 0

    def test_manifest_is_valid(self, tiny_state_dict, tmp_path):
        converter = PyTorchConverter(output_dir=tmp_path / "rex_out", model_id="test")
        converter.convert(tiny_state_dict)
        manifest = load_manifest(tmp_path / "rex_out" / "manifest.json")
        errors = validate_manifest(manifest)
        assert errors == []
        assert manifest.model_id == "test"

    def test_execution_graph_populated(self, tiny_state_dict, tmp_path):
        converter = PyTorchConverter(output_dir=tmp_path / "rex_out")
        result = converter.convert(tiny_state_dict)
        assert len(result.manifest.execution_graph) == len(tiny_state_dict)

    def test_chunk_files_exist(self, tiny_state_dict, tmp_path):
        converter = PyTorchConverter(output_dir=tmp_path / "rex_out")
        result = converter.convert(tiny_state_dict)
        weights_dir = tmp_path / "rex_out" / "weights"
        assert weights_dir.exists()
        chunk_files = list(weights_dir.glob("*.bin"))
        assert len(chunk_files) == result.num_chunks

    def test_reconstruction_correctness(self, tiny_state_dict, tmp_path):
        """Verify that chunks can be reassembled into original tensor."""
        converter = PyTorchConverter(output_dir=tmp_path / "rex_out")
        result = converter.convert(tiny_state_dict)
        manifest = load_manifest(tmp_path / "rex_out" / "manifest.json")
        reader = ChunkReader(verify_checksums=True)

        for name, original_tensor in tiny_state_dict.items():
            desc = manifest.parameters[name]
            chunks = []
            for ca in desc.chunk_addresses:
                chunk_path = tmp_path / "rex_out" / ca.resource_id
                chunk_data = chunk_path.read_bytes()
                chunks.append(chunk_data)

            raw = reader.reassemble_tensor(chunks, compression=manifest.compression)
            reconstructed = np.frombuffer(raw, dtype=np.dtype(desc.dtype)).reshape(desc.shape)
            original_np = np.asarray(original_tensor.detach().cpu().tolist())
            np.testing.assert_array_almost_equal(reconstructed, original_np, decimal=5)

    def test_deterministic_output(self, tiny_state_dict, tmp_path):
        """Same input produces same output."""
        c1 = PyTorchConverter(output_dir=tmp_path / "out1", model_id="m1")
        r1 = c1.convert(tiny_state_dict)

        c2 = PyTorchConverter(output_dir=tmp_path / "out2", model_id="m1")
        r2 = c2.convert(tiny_state_dict)

        assert r1.num_chunks == r2.num_chunks
        assert r1.total_chunk_bytes == r2.total_chunk_bytes

        # Verify manifest checksums match
        for name in r1.manifest.parameters:
            ca1 = r1.manifest.parameters[name].chunk_addresses
            ca2 = r2.manifest.parameters[name].chunk_addresses
            assert len(ca1) == len(ca2)
            for a1, a2 in zip(ca1, ca2):
                data1 = (tmp_path / "out1" / a1.resource_id).read_bytes()
                data2 = (tmp_path / "out2" / a2.resource_id).read_bytes()
                assert data1 == data2

    def test_lz4_compression(self, tiny_state_dict, tmp_path):
        pytest.importorskip("lz4")
        converter = PyTorchConverter(
            output_dir=tmp_path / "rex_lz4",
            compression=CompressionCodec.LZ4,
            model_id="test-lz4",
        )
        result = converter.convert(tiny_state_dict)
        # Compressed should be smaller (or at least not much larger)
        assert result.total_chunk_bytes <= result.total_original_bytes * 1.1
        assert result.manifest.compression == CompressionCodec.LZ4

    def test_jax_npz_conversion(self, tmp_path):
        ckpt = tmp_path / "jax_weights.npz"
        np.savez(
            ckpt,
            **{
                "dense.kernel": np.random.randn(8, 4).astype(np.float32),
                "dense.bias": np.random.randn(4).astype(np.float32),
            },
        )

        result = PyTorchConverter.convert_file(
            checkpoint_path=ckpt,
            output_dir=tmp_path / "jax_out",
            framework="jax",
            model_id="jax-test",
            model_family="jax-demo",
        )

        assert result.num_parameters == 2
        assert result.manifest.source_framework == "jax"

    def test_tensorflow_npz_conversion(self, tmp_path):
        ckpt = tmp_path / "tf_weights.npz"
        np.savez(
            ckpt,
            **{
                "dense/kernel": np.random.randn(6, 3).astype(np.float32),
                "dense/bias": np.random.randn(3).astype(np.float32),
            },
        )

        result = PyTorchConverter.convert_file(
            checkpoint_path=ckpt,
            output_dir=tmp_path / "tf_out",
            framework="tensorflow",
            model_id="tf-test",
            model_family="tf-demo",
        )

        assert result.num_parameters == 2
        assert result.manifest.source_framework == "tensorflow"

    def test_safetensors_uint32_conversion(self, tmp_path):
        safetensors = pytest.importorskip("safetensors.numpy")

        ckpt = tmp_path / "uint32_weights.safetensors"
        safetensors.save_file(
            {
                "embed.position_ids": np.arange(0, 1024, dtype=np.uint32),
                "dense.weight": np.random.randn(8, 8).astype(np.float32),
            },
            str(ckpt),
        )

        result = PyTorchConverter.convert_file(
            checkpoint_path=ckpt,
            output_dir=tmp_path / "st_out",
            framework="safetensors",
            model_id="st-uint32-test",
            model_family="safetensors-demo",
        )

        assert result.num_parameters == 2
        manifest = load_manifest(tmp_path / "st_out" / "manifest.json")
        assert manifest.parameters["embed.position_ids"].dtype in {"uint32", "<u4"}

    def test_quantized_int8_conversion(self, tmp_path):
        state_dict = {
            "dense.weight": np.linspace(-1.0, 1.0, 64, dtype=np.float32).reshape(8, 8),
            "dense.bias": np.linspace(-0.5, 0.5, 8, dtype=np.float32),
        }

        converter = PyTorchConverter(
            output_dir=tmp_path / "quant_out",
            quantization_bits=8,
            model_id="quant-test",
            model_family="demo",
        )
        result = converter.convert(state_dict)

        manifest = load_manifest(tmp_path / "quant_out" / "manifest.json")
        assert manifest.feature_flags["quantized_chunks"] is True
        assert manifest.parameters["dense.weight"].quantization is not None

        desc = manifest.parameters["dense.weight"]
        raw = b"".join(
            (tmp_path / "quant_out" / addr.resource_id).read_bytes()
            for addr in desc.chunk_addresses
        )
        restored = dequantize_tensor_from_bytes(raw, desc.quantization, desc.shape)
        np.testing.assert_allclose(restored, state_dict["dense.weight"], atol=0.1, rtol=0.1)
        assert result.total_chunk_bytes < result.total_original_bytes
