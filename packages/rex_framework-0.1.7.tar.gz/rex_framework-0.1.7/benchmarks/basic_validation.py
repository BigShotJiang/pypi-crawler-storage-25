"""Basic validation benchmark for the Rex framework.

Measures cold-start latency, warm-run latency, chunk fetch counts,
cache hit rates, and memory accounting on a small model.

This is NOT an optimized benchmark. Numbers are baseline only, useful for
tracking regressions, not for performance claims.

Usage:
    PYTHONPATH=src python3 benchmarks/basic_validation.py
"""

from __future__ import annotations

import asyncio
import json
import sys
import threading
import time
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT / "src") not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT / "src"))

import numpy as np


def create_benchmark_model(hidden_dim: int = 32, n_layers: int = 3):
    """Create a small MLP for benchmarking."""
    import torch
    import torch.nn as nn

    torch.manual_seed(0)
    layers = [nn.Linear(16, hidden_dim)]
    for _ in range(n_layers - 1):
        layers.append(nn.ReLU())
        layers.append(nn.Linear(hidden_dim, hidden_dim))
    layers.append(nn.ReLU())
    layers.append(nn.Linear(hidden_dim, 4))
    return nn.Sequential(*layers)


def run_benchmark(
    output_dir: str = "/tmp/rex_benchmark",
    port: int = 18980,
    num_warmup: int = 2,
    num_runs: int = 5,
    chunk_size: int = 512,
    hidden_dim: int = 32,
    n_layers: int = 3,
    cache_bytes: int = 2 * 1024 * 1024,
    scenario_name: str = "basic_validation",
):
    """Run the full benchmark pipeline."""
    results = {}

    # Step 1: Create and convert model
    print("=" * 60)
    print("  Rex Framework — Basic Validation Benchmark")
    print("=" * 60)
    print()

    t0 = time.monotonic()
    model = create_benchmark_model(hidden_dim=hidden_dim, n_layers=n_layers)

    from rex.convert.pytorch_converter import PyTorchConverter
    sd = model.state_dict()
    total_bytes = sum(v.numel() * v.element_size() for v in sd.values())
    converter = PyTorchConverter(
        output_dir=output_dir,
        chunk_size_bytes=chunk_size,
        model_id="benchmark-model",
        model_family="bench",
    )
    conv_result = converter.convert(sd)
    t_convert = (time.monotonic() - t0) * 1000

    results["scenario"] = scenario_name
    results["model"] = {
        "parameters": len(sd),
        "total_bytes": total_bytes,
        "total_chunks": conv_result.num_chunks,
        "chunk_size": chunk_size,
        "hidden_dim": hidden_dim,
        "n_layers": n_layers,
        "cache_bytes": cache_bytes,
        "conversion_ms": round(t_convert, 2),
    }
    print(f"[setup] Model: {len(sd)} params, {total_bytes} bytes, {conv_result.num_chunks} chunks")
    print(f"[setup] Conversion: {t_convert:.1f} ms")

    # Step 2: Start server
    t0 = time.monotonic()
    chunks_dir = str(Path(output_dir) / "weights")

    async def _run_server():
        from rex.storage.local_server import serve_chunks
        await serve_chunks(chunk_dir=chunks_dir, host="127.0.0.1", port=port)
        while True:
            await asyncio.sleep(3600)

    t = threading.Thread(target=lambda: asyncio.run(_run_server()), daemon=True)
    t.start()
    time.sleep(1.5)
    t_server = (time.monotonic() - t0) * 1000
    base_url = f"http://127.0.0.1:{port}"
    print(f"[setup] Server startup: {t_server:.1f} ms")
    print()

    # Step 3: Load manifest
    from rex.core.runtime import RexRuntime
    from rex.api.config import RexConfig

    config = RexConfig()
    config.storage.base_url = base_url
    config.cache.max_memory_cache_bytes = cache_bytes

    async def _run_benchmark():
        runtime = RexRuntime(config=config)
        await runtime.load_model(str(Path(output_dir) / "manifest.json"))

        manifest = runtime.manifest

        # Compute function for MLP
        _relu_state = [False]

        def compute_fn(input_data, weights):
            x = input_data
            for pname, w in weights.items():
                if w is None:
                    continue
                if "weight" in pname:
                    x = x @ w.T
                elif "bias" in pname:
                    x = x + w
            # Apply ReLU after bias layers (not output layer)
            if any("bias" in p and "output" not in p for p in weights):
                x = np.maximum(x, 0.0)
                _relu_state[0] = True
            return x

        input_np = np.random.randn(1, 16).astype(np.float32)

        # Warmup runs
        warmup_times = []
        for i in range(num_warmup):
            _relu_state[0] = False
            t0 = time.monotonic()
            _, m = await runtime.run_inference(input_np, compute_fn=compute_fn)
            elapsed = (time.monotonic() - t0) * 1000
            warmup_times.append(elapsed)
            print(f"[warmup {i+1}/{num_warmup}] {elapsed:.1f} ms  "
                  f"(fetches={m.chunks_fetched}, hits={m.cache_hits}, "
                  f"misses={m.cache_misses})")

        # Measured runs
        run_times = []
        all_metrics = []
        for i in range(num_runs):
            _relu_state[0] = False
            t0 = time.monotonic()
            output, m = await runtime.run_inference(input_np, compute_fn=compute_fn)
            elapsed = (time.monotonic() - t0) * 1000
            run_times.append(elapsed)
            all_metrics.append({
                "total_ms": round(m.total_time_ms, 2),
                "compute_ms": round(m.compute_time_ms, 2),
                "stall_ms": round(m.stall_time_ms, 2),
                "chunks_fetched": m.chunks_fetched,
                "cache_hits": m.cache_hits,
                "cache_misses": m.cache_misses,
                "bytes_fetched": m.bytes_fetched_remote,
                "evictions": m.eviction_count,
                "layers_executed": m.layers_executed,
                "invariant_violations": m.invariant_violations,
            })
            print(f"[run   {i+1}/{num_runs}] {elapsed:.1f} ms  "
                  f"(fetches={m.chunks_fetched}, hits={m.cache_hits}, "
                  f"misses={m.cache_misses})")

        await runtime.shutdown()
        return warmup_times, run_times, all_metrics, manifest

    warmup_times, run_times, all_metrics, manifest = asyncio.run(_run_benchmark())

    # Step 4: Compute statistics
    cold_start = warmup_times[0] if warmup_times else 0
    avg_time = np.mean(run_times) if run_times else 0
    p50_time = np.percentile(run_times, 50) if run_times else 0
    p95_time = np.percentile(run_times, 95) if run_times else 0
    avg_fetches = np.mean([m["chunks_fetched"] for m in all_metrics]) if all_metrics else 0

    avg_stall = np.mean([m["stall_ms"] for m in all_metrics]) if all_metrics else 0
    avg_compute = np.mean([m["compute_ms"] for m in all_metrics]) if all_metrics else 0

    results["benchmark"] = {
        "cold_start_ms": round(cold_start, 2),
        "avg_inference_ms": round(avg_time, 2),
        "p50_inference_ms": round(p50_time, 2),
        "p95_inference_ms": round(p95_time, 2),
        "avg_chunks_fetched": round(avg_fetches, 1),
        "avg_stall_ms": round(avg_stall, 2),
        "avg_compute_ms": round(avg_compute, 2),
        "num_warmup": num_warmup,
        "num_runs": num_runs,
        "individual_runs_ms": [round(t, 2) for t in run_times],
        "all_metrics": all_metrics,
    }

    results["disclaimer"] = (
        "These numbers are baseline measurements on a tiny model served locally. "
        "They are NOT representative of real-world performance with remote "
        "storage. Use them only for tracking regressions."
    )

    print()
    print("=" * 60)
    print("  RESULTS")
    print("=" * 60)
    print(f"  Cold start latency:  {cold_start:.2f} ms")
    print(f"  Avg inference:       {avg_time:.2f} ms")
    print(f"  P50 inference:       {p50_time:.2f} ms")
    print(f"  P95 inference:       {p95_time:.2f} ms")
    print(f"  Avg chunks/run:     {avg_fetches:.1f}")
    print(f"  Avg stall time:      {avg_stall:.2f} ms")
    print(f"  Avg compute time:   {avg_compute:.2f} ms")
    print(f"  Model bytes:        {total_bytes}")
    print(f"  Max cache fraction: {manifest.cache_constraints.max_local_fraction_of_model:.0%}")
    print()
    print("  DISCLAIMER: These are baseline numbers on a tiny local model.")
    print("  NOT suitable for performance claims.")

    return results


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Run Rex basic validation benchmark")
    parser.add_argument("--output-dir", default="/tmp/rex_benchmark")
    parser.add_argument("--port", type=int, default=18980)
    parser.add_argument("--warmup", type=int, default=2)
    parser.add_argument("--runs", type=int, default=5)
    parser.add_argument("--chunk-size", type=int, default=512)
    parser.add_argument("--hidden-dim", type=int, default=32)
    parser.add_argument("--layers", type=int, default=3)
    parser.add_argument("--cache-bytes", type=int, default=2 * 1024 * 1024)
    parser.add_argument("--scenario-name", default="basic_validation")
    parser.add_argument("--json-out", default=str(PROJECT_ROOT / "benchmarks" / "baseline_results.json"))
    args = parser.parse_args()

    result = run_benchmark(
        output_dir=args.output_dir,
        port=args.port,
        num_warmup=args.warmup,
        num_runs=args.runs,
        chunk_size=args.chunk_size,
        hidden_dim=args.hidden_dim,
        n_layers=args.layers,
        cache_bytes=args.cache_bytes,
        scenario_name=args.scenario_name,
    )

    out_path = Path(args.json_out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(result, indent=2))
    print(f"\nResults saved to: {out_path}")
