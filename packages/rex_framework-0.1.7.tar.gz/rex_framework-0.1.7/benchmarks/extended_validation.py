"""Extended benchmark validation suite for Rex.

Runs multiple benchmark scenarios using the basic validation benchmark harness
with different chunk/cache/model settings to catch regressions across profiles.

Usage:
    PYTHONPATH=src python benchmarks/extended_validation.py
"""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT / "src") not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT / "src"))

def _summarize(result: dict) -> dict:
    b = result["benchmark"]
    m = result["model"]
    return {
        "scenario": result.get("scenario", "unknown"),
        "avg_inference_ms": b["avg_inference_ms"],
        "p95_inference_ms": b["p95_inference_ms"],
        "avg_chunks_fetched": b["avg_chunks_fetched"],
        "avg_cache_hit_ratio": round(
            sum(x["cache_hits"] for x in b["all_metrics"]) /
            max(1, sum(x["cache_hits"] + x["cache_misses"] for x in b["all_metrics"])),
            4,
        ),
        "total_chunks": m["total_chunks"],
        "total_bytes": m["total_bytes"],
        "chunk_size": m["chunk_size"],
        "hidden_dim": m["hidden_dim"],
        "n_layers": m["n_layers"],
        "cache_bytes": m["cache_bytes"],
    }


def _run_scenario(cfg: dict, out_dir: Path) -> dict:
    script = PROJECT_ROOT / "benchmarks" / "basic_validation.py"
    json_out = out_dir / f"{cfg['scenario_name']}.json"
    cmd = [
        sys.executable,
        str(script),
        "--output-dir", cfg["output_dir"],
        "--port", str(cfg["port"]),
        "--warmup", str(cfg["num_warmup"]),
        "--runs", str(cfg["num_runs"]),
        "--chunk-size", str(cfg["chunk_size"]),
        "--hidden-dim", str(cfg["hidden_dim"]),
        "--layers", str(cfg["n_layers"]),
        "--cache-bytes", str(cfg["cache_bytes"]),
        "--scenario-name", cfg["scenario_name"],
        "--json-out", str(json_out),
    ]
    subprocess.run(cmd, check=True)
    return json.loads(json_out.read_text())


def main() -> None:
    out_dir = PROJECT_ROOT / "outputs" / "benchmark_outputs"
    out_dir.mkdir(parents=True, exist_ok=True)

    scenarios = [
        {
            "scenario_name": "small_chunks_baseline",
            "output_dir": str(out_dir / "small_chunks_baseline"),
            "port": 18990,
            "num_warmup": 1,
            "num_runs": 3,
            "chunk_size": 256,
            "hidden_dim": 32,
            "n_layers": 3,
            "cache_bytes": 2 * 1024 * 1024,
        },
        {
            "scenario_name": "larger_chunks_same_model",
            "output_dir": str(out_dir / "larger_chunks_same_model"),
            "port": 18991,
            "num_warmup": 1,
            "num_runs": 3,
            "chunk_size": 2048,
            "hidden_dim": 32,
            "n_layers": 3,
            "cache_bytes": 2 * 1024 * 1024,
        },
        {
            "scenario_name": "deeper_model_profile",
            "output_dir": str(out_dir / "deeper_model_profile"),
            "port": 18992,
            "num_warmup": 1,
            "num_runs": 3,
            "chunk_size": 1024,
            "hidden_dim": 64,
            "n_layers": 5,
            "cache_bytes": 4 * 1024 * 1024,
        },
    ]

    all_results = []
    summary = []

    for cfg in scenarios:
        print(f"\n=== Running scenario: {cfg['scenario_name']} ===")
        result = _run_scenario(cfg, out_dir)
        all_results.append(result)
        summary.append(_summarize(result))

    report = {
        "suite": "extended_validation",
        "scenarios": summary,
        "raw_results": all_results,
    }

    out_json = out_dir / "extended_benchmark_results.json"
    out_json.write_text(json.dumps(report, indent=2))
    print(f"\nSaved benchmark suite results: {out_json}")


if __name__ == "__main__":
    main()
