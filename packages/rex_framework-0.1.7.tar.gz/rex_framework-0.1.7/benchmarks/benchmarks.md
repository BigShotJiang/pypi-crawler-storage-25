# Rex Benchmarks

This file consolidates benchmark outcomes from the basic and extended validation suites and the open-weight Qwen2.5 1.5B run.

## Why This Matters

This benchmark set answers two different questions:
1. How much does Rex improve when chunk layout is tuned for the same model?
2. How should Rex be compared with direct full-model inference?

Rex is primarily a constrained-memory and remote-storage runtime. In this setup, it optimizes fetch planning and memory residency under a strict cache invariant. The cleanest latency improvement signal is the chunk-size A/B test in the extended suite.

## Commands Used

```bash
./rexenv/bin/python benchmarks/basic_validation.py \
  --json-out outputs/basic_validation_results.json

./rexenv/bin/python benchmarks/extended_validation.py

./rexenv/bin/rex-serve --dir ./rex_output/weights --port 8092

./rexenv/bin/rex-benchmark \
  --manifest ./rex_output/manifest.json \
  --base-url http://localhost:8092 \
  --inferences 10 \
  --warmup 2 \
  --output outputs/qwen15b_benchmark.json
```

## Benchmark Parameter Matrix

### Basic validation

| Parameter | Value |
|---|---|
| scenario | basic_validation |
| model parameters (state_dict entries) | 8 |
| model total bytes | 11,152 |
| total chunks | 25 |
| chunk size | 512 bytes |
| hidden dimension | 32 |
| model depth (`n_layers`) | 3 |
| cache budget | 2,097,152 bytes |
| warmup runs | 2 |
| measured runs | 5 |

### Extended suite scenarios

| Scenario | chunk_size | total_chunks | total_bytes | hidden_dim | n_layers | cache_bytes | warmup | runs |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| small_chunks_baseline | 256 | 46 | 11,152 | 32 | 3 | 2,097,152 | 1 | 3 |
| larger_chunks_same_model | 2048 | 10 | 11,152 | 32 | 3 | 2,097,152 | 1 | 3 |
| deeper_model_profile | 1024 | 75 | 71,952 | 64 | 5 | 4,194,304 | 1 | 3 |

### Open-weight Qwen run

| Parameter | Value |
|---|---|
| model_id | qwen2.5-1.5b-instruct-4bit |
| manifest_path | ./rex_output/manifest.json |
| base_url | http://localhost:8092 |
| eviction_strategy | retain_n_layers |
| warmup_runs | 2 |
| inference_runs | 10 |
| chunks fetched per run | 2,184 |
| layers executed per run | 732 |

## Baseline Benchmark (Small Model)

- Avg inference: 39.32 ms
- P95 inference: 63.12 ms
- Avg chunks fetched: 25.0
- Avg stall: 28.60 ms
- Avg compute: 0.46 ms
- Model bytes: 11,152
- Total chunks: 25

## Extended Benchmark Suite

| Scenario | Avg Inference (ms) | P95 (ms) | Avg Chunks Fetched | Model Chunks | Chunk Size |
|---|---:|---:|---:|---:|---:|
| small_chunks_baseline | 47.47 | 49.59 | 46.0 | 46 | 256 |
| larger_chunks_same_model | 11.81 | 11.84 | 10.0 | 10 | 2048 |
| deeper_model_profile | 102.64 | 121.17 | 75.0 | 75 | 1024 |

## Improvement Signal From Rex Chunk Strategy

The clearest gain is between these two rows in the extended suite:
- small_chunks_baseline
- larger_chunks_same_model

For the same model shape:
- Avg inference improved from 47.47 ms to 11.81 ms
- Absolute improvement: 35.66 ms
- Relative improvement: 75.1%
- Avg chunks fetched reduced from 46.0 to 10.0
- Chunk fetch reduction: 78.3%

Interpretation:
- Rex benefits when chunk count is reduced while preserving execution correctness.
- Less per-layer fetch pressure means less stall time and lower end-to-end latency.

## Rex vs Direct Full-Model Inference

This repository does not currently include a same-hardware, same-model direct-inference timing harness for Qwen2.5-1.5B in this benchmark set. Still, the outputs provide enough parameters to compare behavior dimensions clearly.

### Comparison dimensions

| Dimension | Rex (this benchmark set) | Direct full-model inference |
|---|---|---|
| Weight residency policy | Bounded by cache invariant (`max_local_fraction_of_model`) | Full weights resident locally |
| Initial storage assumption | Remote/ranged chunk fetch | Full model loaded before run |
| Startup transfer pattern | Incremental chunk fetch during execution | Front-loaded full weight load |
| Peak local weight footprint target | Bounded by cache policy | Approximately full model bytes |
| Cold-run latency driver | Network + IO stall + decode + compute | Mostly model-load + compute |
| Warm-run behavior | Depends on cache hit ratio and eviction strategy | Depends on framework/runtime caching |

### Qwen run numbers used in that comparison

- Input checkpoint bytes: 868,628,559 (~828 MB)
- Rex model bytes in manifest: 868,547,584
- Rex chunks per full run: 2,184
- Rex bytes fetched over 10 measured runs: 8,685,475,840
- Rex average measured latency: 138,805.543 ms

Practical interpretation:
- In this cold-fetch-oriented setup, Rex is not optimized for raw latency versus a fully resident local model.
- Rex is useful when the full model should not or cannot be kept resident locally, and when controlled chunk residency is more important than minimum single-run latency.

## Open-Weight Run (Qwen2.5 1.5B, 828 MB)



Model conversion and validation:
- Input checkpoint size: 868,628,559 bytes (~828 MB)
- Rex output: 732 parameters, 2,184 chunks, 828.3 MB
- Validation: valid=true, 13 PASS checks

Benchmark summary:
- Warmup runs: 2
- Inference runs: 10
- Avg total latency: 138,805.543 ms
- Min total latency: 126,401.774 ms
- Max total latency: 145,758.486 ms
- P95 latency: 145,758.486 ms
- Total chunks fetched: 21,840
- Total bytes fetched: 8,685,475,840
- Avg cache hit ratio: 0.0

## Test Status During This Run

- Collected: 257
- Passed: 256
- Skipped: 1
- Failed: 0

## Notes

- Small-model benchmark numbers are useful for regression trends.
- Open-weight run confirms the full Rex path works at larger checkpoint size.
- A 0.0 cache hit ratio here is expected for cold-fetch-oriented settings and current eviction behavior.
- For strict speed comparison with direct inference, add a dedicated same-model direct baseline harness in a follow-up run.
