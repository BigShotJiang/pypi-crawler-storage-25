# Rex Framework Architecture

This document describes the current architecture implemented in the repository.

## High-Level Flow

1. A model checkpoint is converted into Rex chunk files plus a manifest.
2. The manifest is loaded by the runtime.
3. The scheduler plans layer/chunk access.
4. The prefetcher and storage backend fetch chunks over HTTP Range.
5. Cache and residency subsystems enforce memory constraints.
6. The executor materializes tensors and runs compute layer by layer.
7. WebSocket streaming is the primary transport for `rex-serve`; the runtime and prefetcher share a persistent `/ws/stream` backend for HTTP/local-server loads.

## Core Subsystems

### Conversion
- Module: `src/rex/convert/`
- Entry point: `src/rex/cli/convert.py`
- Supported input frameworks:
  - PyTorch (`.pt`, `.pth`, `.ckpt`, `.bin`)
  - safetensors (`.safetensors`)
  - JAX (`.npz`)
  - TensorFlow (`.h5`, `.keras`, `.ckpt`, `.index`, `.npz`)

### Manifest and Formats
- Manifest schema: `schemas/rex-manifest.schema.json`
- Manifest runtime types: `src/rex/core/types.py`
- Serialization/validation: `src/rex/formats/manifest.py`

### Runtime
- Orchestrator: `src/rex/core/runtime.py`
- Executor: `src/rex/core/executor.py`
- Scheduler: `src/rex/core/scheduler.py`
- Prefetcher: `src/rex/core/prefetcher.py`
- Virtual tensor state machine: `src/rex/core/virtual_tensor.py`

### Caching and Invariants
- Memory cache: `src/rex/cache/memory_cache.py`
- Two-tier cache: `src/rex/cache/two_tier.py`
- Residency accounting: `src/rex/cache/residency.py`
- Invariant checks: `src/rex/core/invariants.py`

### Storage Backends
- HTTP Range backend: `src/rex/storage/http_range.py`
- Local server for testing: `src/rex/storage/local_server.py`
- WebSocket streaming: `src/rex/storage/stream_server.py`, `src/rex/storage/stream_client.py`
- Experimental/unsupported placeholders: Google Drive, OneDrive, iCloud

## CLI Surface
- `rex-convert`
- `rex-validate`
- `rex-inspect`
- `rex-serve`
- `rex-benchmark`
- `rex-run-demo`

## ADRs
Architecture decisions are tracked in `docs/adr/`.

## Mathematical Redesign Track (2026-04-14)

Rex now has a formal redesign blueprint that maps optimization theory to implementable module changes while preserving the strict cache invariant.

- Blueprint: `docs/rex_mathematical_redesign.md`
- Invariant source of truth: `src/rex/core/invariants.py`
- Planned upgrades:
  - Graph-aware DAG scheduling (non-breaking fallback to sequential mode)
  - Probabilistic cache eviction based on expected future miss cost
  - Predictive prefetch optimization under bandwidth constraints
  - Multi-tier cache control with invariant-safe admission
  - Blocked execution and fusion hooks for numerical efficiency

Phase 1 implemented modules:

- `src/rex/core/graph_model.py`
  - `GraphNode`, `GraphEdge`, `ExecutionDAG`
  - DAG build from manifest execution order and chunk lookup metadata
- `src/rex/core/cost_model.py`
  - `ChunkCostModel` and `prefetch_utility()`
- `src/rex/core/runtime.py`
  - Optional DAG metadata build during `load_model()` (no behavior change to sequential execution)

The redesign is additive and phased, with the current runtime path kept as a stable baseline.

## Validation Note (2026-04-14)

The current architecture has now been exercised against an open-weight safetensors checkpoint for conversion, manifest validation, inspection, and benchmark execution:

- Input: `inputs/qwen2.5-1.5b-instruct-4bit/model.safetensors` (828 MB)
- Converted Rex output: 2,184 chunks, 828.3 MB chunk set
- Validation and benchmark artifacts: `outputs/`
