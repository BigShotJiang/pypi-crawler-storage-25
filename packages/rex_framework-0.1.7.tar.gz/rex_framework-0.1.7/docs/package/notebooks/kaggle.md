# Kaggle

Kaggle notebooks work well when the manifest and chunk files are reachable over
an HTTPS host or mounted dataset path.

## Install in Kaggle

```python
!pip install "rex-framework[pytorch]" -q
import rex, torch
print(rex.__version__, torch.__version__)
```

## Load from an HTTPS host

```python
from rex.api.config import RexConfig
import rex

MANIFEST_URL = "https://your-static-host.com/rex_output/manifest.json"
CHUNKS_BASE_URL = "https://your-static-host.com/rex_output/weights"

config = RexConfig()
config.storage.base_url = CHUNKS_BASE_URL
config.cache.max_memory_cache_bytes = 512 * 1024 * 1024

runtime = rex.load_model(MANIFEST_URL, config=config)
```

## Load from a Kaggle Dataset

```python
from rex.api.config import RexConfig
import rex

MANIFEST_PATH = "/kaggle/input/my-rex-model/manifest.json"
CHUNKS_BASE_URL = "http://127.0.0.1:8080"

config = RexConfig()
config.storage.base_url = CHUNKS_BASE_URL

runtime = rex.load_model(MANIFEST_PATH, config=config)
```

## Use Kaggle Secrets for tokens

```python
from kaggle_secrets import UserSecretsClient

secrets = UserSecretsClient()
token = secrets.get_secret("REX_AUTH_TOKEN")
config.storage.auth_token = f"Bearer {token}"
```

## Run inference

```python
import rex
import numpy as np

input_data = np.random.randn(1, 768).astype(np.float32)
output, metrics = rex.run_inference_sync(MANIFEST_PATH, input_data, config=config)
print(output.shape)
print(metrics.total_time_ms)
```
