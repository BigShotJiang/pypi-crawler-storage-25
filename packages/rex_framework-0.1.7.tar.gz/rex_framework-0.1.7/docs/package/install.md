# Install

## Minimal install

```bash
pip install rex-framework
```

Use this for manifest validation, storage checks, and package inspection.

## Recommended install

```bash
pip install "rex-framework[pytorch]"
```

Use this for actual inference workloads.

## Optional extras

```bash
pip install "rex-framework[google-drive]"
pip install "rex-framework[onedrive]"
pip install "rex-framework[bench]"
pip install "rex-framework[all]"
```

## Python support

- `numpy` is installed automatically with the package.
- The `pytorch` extra supports Python `3.10` through `3.13`.
- PyTorch wheels are not published for Python `3.14`.
- On some platforms, especially macOS x86_64, Python `3.13` may still lack a compatible `torch` wheel.

## Verify the install

```bash
python -c "import torch, rex; print(torch.__version__); print(rex.__version__)"
```

