# CLI

The package ships a small CLI surface for common workflows.

| Command | Purpose |
|---|---|
| `rex-convert` | Convert a checkpoint to Rex format |
| `rex-serve` | Serve chunk files and streaming weights |
| `rex-validate` | Validate a manifest |
| `rex-inspect` | Inspect a manifest |
| `rex-benchmark` | Run latency and throughput benchmarks |
| `rex-run-demo` | Run the end-to-end demo |

## Common flow

```bash
rex-convert model.pt -o ./rex_output --framework pytorch --model-id my-model
rex-serve --dir ./rex_output/weights --port 8080
rex-validate ./rex_output/manifest.json
```

## Notes

- `rex-serve` exposes the WebSocket streaming endpoint for the explicit `STREAMING_WS` backend.
- The package documentation focuses on installation and usage, not repository internals.
