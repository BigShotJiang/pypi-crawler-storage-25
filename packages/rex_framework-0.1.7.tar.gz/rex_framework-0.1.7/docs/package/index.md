# Rex Framework Package Docs

Rex Framework is a package for inference with remotely stored model weights.
It fetches chunks on demand, keeps residency bounded, and lets the full model
stay remote.

This site documents the installed package only.
It does not cover private repository internals, ADRs, or development workflow.

## What the package gives you

- Python APIs for loading manifests and running inference.
- CLI tools for conversion, validation, inspection, serving, benchmarking, and demo runs.
- Notebook-friendly usage patterns for Kaggle and Google Colab.
- WebSocket streaming as an explicit backend mode for live weight delivery from `rex-serve`.
- Configuration via `RexConfig` and `REX_*` environment variables.

## Start here

1. Read the [install guide](install.md).
2. Follow the [Kaggle notebook guide](notebooks/kaggle.md) or [Colab guide](notebooks/colab.md) if you are running in a notebook.
3. Review [streaming](streaming.md) if you want live weight delivery through `rex-serve`.
4. Use [configuration](configuration.md) for runtime tuning.

## Common package story

```bash
pip install "rex-framework[pytorch]"
rex-serve --dir ./rex_output/weights --port 8080
```

Then point your runtime at the manifest and base URL for the chunk host.
