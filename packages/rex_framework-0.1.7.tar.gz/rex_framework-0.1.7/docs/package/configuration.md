# Configuration

`RexConfig` controls the package runtime.

## Storage

```python
from rex.api.config import RexConfig
from rex.core.types import StorageBackendType

config = RexConfig()
config.storage.base_url = "http://localhost:8080"
config.storage.backend_type = StorageBackendType.HTTP_RANGE
config.storage.max_concurrent_fetches = 4
config.storage.adaptive_concurrency = True
config.storage.retry_max_attempts = 3
config.storage.request_timeout_seconds = 30.0
```

## Cache and scheduler

```python
config.cache.max_memory_cache_bytes = 512 * 1024 * 1024
config.cache.max_local_fraction_of_model = 0.4
config.scheduler.enable_prefetch = True
config.scheduler.prefetch_window = 4
config.scheduler.scheduler_mode = "graph"
```

## Observability

```python
config.observability.log_level = "INFO"
config.observability.log_format = "console"
config.observability.enable_tracing = True
```

## Environment variables

- `REX_STORAGE_BACKEND`
- `REX_STORAGE_URL`
- `REX_AUTH_TOKEN`
- `REX_CACHE_SIZE_MB`
- `REX_CACHE_POLICY`
- `REX_PREFETCH_WINDOW`
- `REX_LOG_LEVEL`
- `REX_MAX_LOCAL_FRAC`
- `REX_DEBUG`
- `REX_ENABLE_STREAMING`

## Storage backend modes

- `HTTP_RANGE`: default path for normal chunk-host loads.
- `STREAMING_WS`: explicit WebSocket streaming mode for `rex-serve`.
- `GOOGLE_DRIVE`, `ONEDRIVE`, `ICLOUD`: alternate backend types where supported.
