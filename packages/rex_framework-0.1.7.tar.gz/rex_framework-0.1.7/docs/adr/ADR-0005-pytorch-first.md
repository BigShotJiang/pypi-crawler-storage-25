# ADR-0005: PyTorch as First-Class Backend

**Status:** Accepted

## Context
Rex needs a framework for the initial execution backend. Options: PyTorch, TensorFlow, JAX, ONNX Runtime.

## Decision
PyTorch for Phase A. Reasons:
1. Largest ecosystem for ML research
2. Eager execution aligns with Rex's layer-by-layer materialization
3. Colab/Kaggle pre-install PyTorch
4. state_dict is a simple dict → natural mapping to Rex parameters
5. Functional alternative (JAX) deferred but aligns with Rex's design philosophy

## Consequences
- Weight tensors assumed to be numpy-compatible via .numpy()
- Eager mode limitations accepted — dynamic control flow unsupported
- JAX conversion documented as future work (ADR-0005-appendix)

## Validation Addendum (2026-04-13)
- Sections 10-13 validation included a complex demo matrix across manifests converted from `.pt`, Google-Drive lineage `.pth`, `.bin`, `.ckpt`, `.safetensors`, JAX `.npz`, and TensorFlow `.h5/.keras/.npz` sources.
- Minimal demo correctness and invariant checks remained valid, and per-manifest inspect/validate/range checks passed for all tested manifest families.
