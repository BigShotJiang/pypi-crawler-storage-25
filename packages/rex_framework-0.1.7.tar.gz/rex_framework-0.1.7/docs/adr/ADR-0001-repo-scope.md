# ADR-0001: Repository Scope and Phase Strategy

**Status:** Accepted

## Context
The Rex framework needs to balance ambition with deliverability. A full ML framework with all backends is multi-month work. We need a phased approach.

## Decision
Three-phase shipping strategy:
- **Phase A** (v0.1): MVP — HTTP Range storage, local chunk server, PyTorch converter, virtual tensors, LRU cache, scheduler/prefetcher, CLI tools, tests.
- **Phase B** (v0.2): Cloud adapters, compression, quantization, expanded models.
- **Phase C** (v0.3): Speculative prefetch, MoE scheduling, JAX/TF support.

## Consequences
Phase A targets tiny transformers/MLPs. Feature flags in manifest track status. Nothing is marked "implemented" without code + tests.
