# ADR-0004: HTTP Range Storage as Primary Access Mechanism

**Status:** Accepted

## Context
Rex needs to access specific byte ranges of weight files without downloading entire files. Several approaches exist: full download, chunked APIs, WebDAV, HTTP Range.

## Decision
HTTP Range requests (RFC 7233) as the primary mechanism. Reasons:
1. Universally supported by cloud storage (Google Drive, S3, Cloudflare R2)
2. Simple to implement and test
3. Works with standard HTTP infrastructure (CDNs, proxies)
4. No proprietary SDK required for basic usage

## Consequences
- Latency = connect_time + range_size / bandwidth + server_processing
- Rate limits vary by backend (Google Drive: ~10 req/s per file)
- Range support on iCloud is limited — iCloud adapter marked Unsupported

## Validation Addendum (2026-04-13)
- Baseline and extended benchmark suites were run with local HTTP range serving and produced reproducible JSON artifacts under `outputs/`.
- Scenario runs showed expected sensitivity to chunk size (fewer/larger chunks reduced fetch count and total latency for the same model shape).
