# ADR-0006: Backend Support Matrix

**Status:** Accepted

## Context
Rex claims support for multiple cloud storage backends. Each has different API capabilities, auth requirements, and rate limits.

## Decision

| Backend | Status | Rationale |
|---------|--------|-----------|
| HTTP Range | Implemented | Universal, testable, documented |
| Local Server | Implemented | Critical for dev/test/benchmarks |
| Google Drive | Experimental | API exists, auth complex, rate limits low |
| OneDrive | Experimental | API exists, auth complex |
| iCloud | Unsupported | No public HTTP Range API |

## Consequences
- Unknown backends raise `UnsupportedBackendError` with clear message
- Each backend documents auth requirements and failure modes
- Google Drive/OneDrive may be promoted to Implemented after real-world testing

## Validation Addendum (2026-04-13)
- Section 9 validation confirmed HTTP Range backend and Local Server interoperability with verified byte-range correctness against local chunk files.
- Google Drive backend was exercised using the same file ID from prior sections; backend initialization and auth/capability paths worked, with health remaining credential/share dependent at runtime.
- OneDrive backend was exercised for initialization and health behavior; with no configured credentials/item ID in this environment, it correctly reported an unhealthy/not-configured state.
