# ADR-0003: Cache Invariant Enforcement

**Status:** Accepted

## Context
Rex's core promise is that the full model never resides locally. This must be enforced programmatically, not just by convention.

## Decision
The InvariantChecker enforces: `resident_bytes + cached_bytes <= max_local_fraction * total_model_bytes` (default 40%). The check runs after every cache insertion. A safety margin (default 5%) provides buffer against race conditions.

Violation raises `InvariantViolationError` and is logged as a critical event.

## Consequences
- Maximum 40% of model weights can be cached locally at any time
- The invariant checker is called after every cache.put()
- Safety margin protects against transient over-fills during concurrent operations

## Validation Addendum (2026-04-13)
- Section 8 core-component validation exercised invariant checks across manifests converted from `.pt`, Google Drive `.pth`, `.bin`, `.ckpt`, `.safetensors`, JAX `.npz`, and TensorFlow `.h5/.keras/.npz` sources.
- During the same run, a deadlock in `ResidencyTracker.summary()` (nested lock acquisition) was fixed so residency totals can be reported safely alongside invariant state.
