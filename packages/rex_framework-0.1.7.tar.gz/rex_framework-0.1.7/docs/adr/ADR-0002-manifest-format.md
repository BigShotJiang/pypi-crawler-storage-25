# ADR-0002: Manifest Format

**Status:** Accepted

## Context
Rex needs a metadata format that describes model architecture, chunk layout, and storage configuration. The manifest must be small enough to fetch before any inference while containing sufficient information for scheduling and caching.

## Decision
JSON format for v0.1, with the following key fields:
- `manifest_version` (semver, forward-compatible)
- `model_id`, `model_family`, `source_framework`
- `parameters`: dict of name → {shape, dtype, num_chunks, chunk_addresses}
- `execution_graph`: ordered list of parameter names for scheduling
- `cache_constraints`: max_local_fraction, max_memory_cache_bytes
- `feature_flags`: boolean map for compression, quantization, etc.

JSON chosen over protobuf/binary for debuggability and human readability. Binary format deferred to Phase C.

## Consequences
Manifests are typically < 1 MB even for large models. The `created_at` field enables staleness detection.
