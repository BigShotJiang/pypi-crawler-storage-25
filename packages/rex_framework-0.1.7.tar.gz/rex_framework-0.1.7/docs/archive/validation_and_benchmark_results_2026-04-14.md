# Validation And Benchmark Results - 2026-04-14 (Archived)

## Status

This file is the archived record of the 2026-04-14 validation and benchmark run.

## Note

The previous content in this file referenced model artifacts that are no longer part of the active validation path. The active documentation now reflects the open-weight Qwen2.5 1.5B run with completed benchmark output.
