# Documentation Index

This folder holds long-lived project documentation.

## Core Design Docs

- `architecture.md`: Runtime architecture and subsystem boundaries.
- `implementation_status.md`: Current implementation matrix and roadmap status.
- `rex_mathematical_redesign.md`: Mathematical design and phased optimization plan.
- `api-reference.md`: Pointers to source entry points.
- Streaming backend docs live in `src/rex/storage/stream_server.py` and `src/rex/storage/stream_client.py`; streaming is always on for HTTP/local-server loads.

## ADRs

- `adr/ADR-0001-repo-scope.md`
- `adr/ADR-0002-manifest-format.md`
- `adr/ADR-0003-cache-invariant.md`
- `adr/ADR-0004-http-range-storage.md`
- `adr/ADR-0005-pytorch-first.md`
- `adr/ADR-0006-backend-support-matrix.md`

## Archived Reports

- `archive/validation_and_benchmark_results_2026-04-14.md`

## Live Run Artifacts

Run-specific reports are archived under `docs/archive/`.

## Benchmark Summary

Consolidated benchmark narrative and parameter tables:

- `benchmarks/benchmarks.md`
