# Rex Mathematical Redesign Blueprint

Date: 2026-04-14

## Implementation Status (2026-04-14)

All phases are now fully implemented and validated by unit tests.

- `src/rex/core/graph_model.py`
- `src/rex/core/cost_model.py`
- `src/rex/core/graph_scheduler.py`
- `src/rex/cache/predictor.py`
- `src/rex/cache/policies.py` (`ProbabilisticUtilityPolicy`)
- `src/rex/core/prefetch_optimizer.py`
- Runtime integration in `src/rex/core/runtime.py` with DAG metadata build and graph-mode execution ordering
- Prefetch integration in `src/rex/core/prefetcher.py`
- Two-tier promotion/demotion telemetry and tier control policy in `src/rex/cache/two_tier.py`
- Quantized conversion/materialization support across:
  - `src/rex/convert/quantize.py`
  - `src/rex/convert/pytorch_converter.py`
  - `src/rex/core/virtual_tensor.py`
  - `src/rex/core/executor.py`
- Scheduler config flags in `src/rex/api/config.py`:
  - `scheduler_mode`
  - `build_execution_dag_metadata`
  - `enable_graph_partitioning`
  - `graph_partition_budget_bytes`
  - `prefetch_horizon`
  - `max_prefetch_queue_depth`
  - `enable_attention_priors`
  - `enable_moe_priors`
- Cache config flags in `src/rex/api/config.py`:
  - `confidence_threshold`
  - `tier_control_policy`
  - `tier_control_min_accesses`
- Storage config flags in `src/rex/api/config.py`:
  - `adaptive_concurrency`

Validation status:

- New unit tests added:
  - `tests/unit/test_graph_model.py`
  - `tests/unit/test_cost_model.py`
  - `tests/unit/test_graph_scheduler.py`
  - `tests/unit/test_planning_algorithms.py`
  - `tests/unit/test_quantization.py`
  - `tests/unit/test_config.py`
- Full repository tests: 335 passed, 0 skipped, 0 failed

## 1. Problem Statement and Invariant

Rex runs inference with remotely stored model weights and strict local memory bounds.

Let:

- $W = \sum_{i=1}^n s_i$ be total model weight bytes.
- $C(t)$ be bytes of all locally stored weight chunks at time $t$.
- $\alpha \in (0,1)$ be the configured local fraction limit (default $0.4$).

Hard invariant:

$$
\forall t:\; C(t) \le \alpha W
$$

Rex already enforces this in [src/rex/core/invariants.py](src/rex/core/invariants.py) through `InvariantChecker`, with a safety margin.

This document defines the next system design to minimize latency while preserving that invariant.

## 2. Formal Optimization Model

### 2.1 Execution Graph

Inference is a DAG $G=(V,E)$.

Each node $v\in V$ has:

- required chunk set $\mathcal{W}_v \subseteq \{w_1,\dots,w_n\}$
- compute cost $c(v)$
- output size $o(v)$

### 2.2 Chunk and Fetch Model

Each chunk $w_i$ has:

- size $s_i$
- network latency component $L_i$
- decode/decompression cost $D_i$

If chunk $w_i$ is not in cache at scheduling instant $t$, missing cost is:

$$
\Delta_i(t)=L_i + D_i
$$

### 2.3 Control Variables

Per decision step $t$:

- $x_{i,t} \in \{0,1\}$, keep chunk $i$ in cache after step $t$
- $f_{i,t} \in \{0,1\}$, prefetch chunk $i$ at step $t$
- $\pi$, topological execution order policy over DAG nodes

Capacity:

$$
\sum_i s_i x_{i,t} \le \alpha W\quad \forall t
$$

Bandwidth:

$$
\sum_i b_i f_{i,t} \le B_t\quad \forall t
$$

### 2.4 Objective

Primary objective:

$$
\min_{\pi, x, f}\; \mathbb{E}[T_{\text{total}}]
$$

with

$$
T_{\text{total}} = \sum_{v\in \pi}\left(c(v)+\sum_{w_i\in \mathcal{W}_v}(1-z_{i,v})(L_i+D_i)\right)
$$

where $z_{i,v}=1$ when chunk $w_i$ is available at node execution time.

Secondary objective terms:

- minimize redundant fetches $\sum_i \text{fetches}(i)-1$
- minimize tail latency (p95/p99)
- maximize reuse hit probability

## 3. System Redesign

### 3.1 Graph-Aware Executor

Current executor in [src/rex/core/executor.py](src/rex/core/executor.py) is sequential over parameter names. Replace planning path with a graph-aware planner:

- Input: DAG with chunk requirements and estimated costs.
- Output: schedule blocks $B_1,\dots,B_k$ where each block satisfies memory feasibility under $\alpha W$.

Key components:

- Critical-path weighted topological scheduling.
- Cut-aware partitioning to reduce cross-block chunk reloads.
- Optional recomputation penalty when considering reorder/fusion choices.

### 3.2 Predictive Cache Controller

Current policies in [src/rex/cache/policies.py](src/rex/cache/policies.py) use recency/frequency heuristics. Add probabilistic score:

$$
\text{value}_i = P_i^{(H)} \cdot (L_i + D_i)
$$

where $P_i^{(H)}$ is predicted reuse probability in horizon $H$.

Recommended estimator stack:

- Bayesian posterior over per-chunk reuse events:

$$
P_i^{(H)} = \mathbb{E}[\theta_i \mid \mathcal{D}_{1:t}],\quad \theta_i \sim \text{Beta}(a_i,b_i)
$$

- Markov transition model over recent layer states:

$$
P(w_i\mid s_t) = \sum_{s'} P(w_i\mid s')\,P(s'\mid s_t)
$$

- Attention-pattern prior for transformer traces (optional):
  - increase prior mass for chunks tied to frequently reused attention blocks.

Evict by minimum value density:

$$
i^* = \arg\min_i \frac{\text{value}_i}{s_i}
$$

### 3.3 Probabilistic Scheduler + Prefetcher

Extend [src/rex/core/scheduler.py](src/rex/core/scheduler.py) and [src/rex/core/prefetcher.py](src/rex/core/prefetcher.py):

- Scheduler emits candidate chunk set for horizon $H$.
- Predictor estimates $P(w_i\mid \text{state}_t)$.
- Prefetch optimizer solves a bounded knapsack over bandwidth and queue capacity.

Priority utility:

$$
u_i = \frac{P_i^{(H)}}{\hat{L}_i}
$$

Pick prefetched set maximizing $\sum_i u_i$ under bandwidth limits.

### 3.4 Multi-Tier Cache Controller

Build on [src/rex/cache/two_tier.py](src/rex/cache/two_tier.py):

- Tier 0: RAM
- Tier 1: disk
- Tier 2: optional VRAM buffer (future)

Decision at each step:

- promote, demote, evict, or fetch remote

Approximate dynamic programming target:

$$
V(s_t)=\min_a\left(c(s_t,a)+\gamma\,\mathbb{E}[V(s_{t+1})\mid s_t,a]\right)
$$

with hard clipping to invariant-feasible actions only.

### 3.5 Statistical Priors for Transformer and MoE

For transformer families:

- Maintain per-layer attention locality statistics by token window buckets.
- Use KV-cache reuse observations to boost reuse priors for nearby layers and repeated heads.

For Mixture-of-Experts:

- Track routing probabilities $P(e_j\mid x_t)$ for expert $e_j$ and input context $x_t$.
- Prefetch only top-$k$ experts:

$$
\mathcal{E}_{\text{prefetch}} = \operatorname{TopK}_j\; P(e_j\mid x_t)
$$

- Reserve bandwidth fraction $\rho$ for non-expert shared chunks to prevent starvation.

### 3.6 Queueing-Theoretic IO Control

Treat remote fetch pipeline as a queueing system with effective service rate $\mu$ and arrival rate $\lambda$.

- Keep utilization bounded, $\rho=\lambda/\mu < 1$.
- Tune concurrency $k$ and batching by minimizing estimated wait plus tail penalty:

$$
\min_{k,b}\; \mathbb{E}[W_q(k,b)] + \eta\,\text{Tail}_{0.95}(k,b)
$$

Inputs come from observed prefetch queue metrics in [src/rex/core/prefetcher.py](src/rex/core/prefetcher.py).

### 3.7 Quantization via Rate-Distortion Control

For each chunk, pick precision mode $q \in \{\text{FP16},\text{INT8},\text{NF4}\}$.

Solve:

$$
\min_q\; D_i(q)\quad \text{s.t.}\quad R_i(q) \le R_{\max,i}
$$

where $D_i$ is task-level distortion proxy and $R_i$ is bitrate/storage cost.

Practical policy:

- high-sensitivity layers: FP16
- medium-sensitivity layers: INT8
- low-sensitivity layers: NF4

Decisions are stored in manifest metadata and enforced at chunk decode time.

## 4. Algorithms (Pseudocode)

Implementation note: the algorithms in this section now have concrete first-pass code paths in the repository. The current implementations favor safe greedy heuristics and invariant-preserving fallbacks over exact optimization.

### 4.1 Stochastic Eviction

```text
Algorithm STOCHASTIC_EVICT(cache_state S, required_bytes r)
Input: chunk metadata {s_i, L_i, D_i, P_i}
while free_bytes(S) < r:
    for each chunk i in S:
        value_i = P_i * (L_i + D_i)
        density_i = value_i / s_i
    j = argmin_i density_i
    evict(j)
    enforce_invariant(S)   # must pass C(t) <= alpha*W
return S
```

### 4.2 Predictive Prefetch Under Bandwidth Budget

```text
Algorithm PREFETCH_PLAN(state_t, horizon H, budget B)
candidates = lookahead_chunks(state_t, H)
for each chunk i in candidates:
    p_i = predict_reuse_probability(i, state_t, H)
    l_i = estimate_fetch_latency(i)
    utility_i = p_i / l_i
Select subset A maximizing sum(utility_i) subject to sum(bytes_i) <= B
enqueue_prefetch(A by descending utility_i)
```

### 4.3 DAG Scheduling with Memory Feasibility

```text
Algorithm MEMORY_AWARE_TOPO_SCHEDULE(DAG G)
ready = sources(G)
schedule = []
while ready not empty:
    for v in ready:
        miss_cost(v) = sum_{i in W_v not cached}(L_i + D_i)
        crit(v) = longest_path_weight_from(v)
        score(v) = lambda1*crit(v) - lambda2*miss_cost(v)
    choose v* with max score(v*) and feasible cache transition
    apply evict/prefetch decisions to keep C(t) <= alpha*W
    append v* to schedule
    update ready
return schedule
```

## 5. Implementation Plan (Theory to Code)

This plan keeps current behavior as fallback and introduces each feature behind flags. Status markers below reflect the current codebase.

### Phase 1: Graph Abstractions and Cost Model (Implemented)

- Add `GraphNode`, `GraphEdge`, `ExecutionDAG` in a new module:
  - `src/rex/core/graph_model.py`
- Add cost estimation utilities:
  - `src/rex/core/cost_model.py`
- Extend manifest ingestion in [src/rex/core/runtime.py](src/rex/core/runtime.py) to optionally build DAG from `execution_graph`.

### Phase 2: Scheduler Upgrade (Implemented)

- Add `GraphScheduler` in a new module:
  - `src/rex/core/graph_scheduler.py`
- Keep existing `Scheduler` as baseline fallback path.
- Config flag in [src/rex/api/config.py](src/rex/api/config.py):
  - `scheduler_mode = "graph" | "sequential"` (default: `graph`)

### Phase 3: Probabilistic Cache Policy (Implemented)

- Add `ProbabilisticUtilityPolicy` in [src/rex/cache/policies.py](src/rex/cache/policies.py).
- Add predictor interfaces in a new module:
  - `src/rex/cache/predictor.py`
- Start with exponential moving estimate + Bayesian correction from trace counts.

### Phase 4: Predictive Prefetch Planner (Implemented)

- Add planner in a new module:
  - `src/rex/core/prefetch_optimizer.py`
- Integrate with [src/rex/core/prefetcher.py](src/rex/core/prefetcher.py) queue ordering and admission control.

### Phase 5: Multi-Tier Control (Implemented)

- Extend [src/rex/cache/two_tier.py](src/rex/cache/two_tier.py) with explicit promotion/demotion signals and per-tier latency stats.
- Add optional third tier abstraction (VRAM) behind feature flag.

Current status:

- Promotion/demotion counters and simple latency telemetry are implemented.
- `TierControlPolicy` ABC and `FrequencyBasedTierControlPolicy` are implemented for explicit promotion control.
- `ThirdTierBackend` ABC is implemented for optional third-tier extension.
- Config: `tier_control_policy="frequency"`, `tier_control_min_accesses=2`.

### Phase 6: Numerical Runtime Upgrades (Implemented)

- Add block metadata and block-aligned chunk groups in converter path:
  - [src/rex/convert/partitioner.py](src/rex/convert/partitioner.py)
- Add operator fusion planner hooks in executor path:
  - [src/rex/core/executor.py](src/rex/core/executor.py)

Current status:

- Optional symmetric INT8/INT4/INT2 chunk quantization is implemented end-to-end and stored in manifest tensor metadata.
- Runtime materialization dequantizes on demand in the executor and virtual tensor path.
- `BlockedExecutionMetadata`, `OperatorFusionHook`, and `GraphNodeMetadata` dataclasses are implemented in `graph_model.py`.
- `fusion_opportunities()` identifies fusible sequential nodes.
- `NF4_LEVELS`, `quantize_nf4()`, `dequantize_nf4()`, and `select_precision()` are implemented in `quantize.py`.
- `select_precision()` picks the lowest-bit format (NF4/INT4/INT8) satisfying a distortion threshold.

### Phase 7: Validation and Benchmarks (Implemented)

- Extend [benchmarks/extended_validation.py](benchmarks/extended_validation.py) with scenario families:
  - DAG depth variation
  - cross-layer reuse stress
  - network jitter and queue saturation
- Track p50/p95/p99, redundant fetch ratio, invariant margin violations.

## 6. Complexity and Expected Gains

Let $|V|$ be node count, $|E|$ edge count, and $m$ cached chunks.

- Baseline scheduling: $O(|V|)$
- Graph scheduling with ready-queue scoring: $O((|V|+|E|)\log|V|)$
- Stochastic eviction update: $O(m)$ naive, $O(\log m)$ with heap maintenance
- Prefetch subset selection:
  - greedy approximation: $O(k\log k)$ for $k$ candidates
  - exact knapsack: pseudo-polynomial, not recommended online

Expected latency improvement in realistic remote settings:

- lower stall time due to better overlap and fewer avoidable misses
- better tail latency from queue-aware prefetch selection
- lower redundant fetch count from reuse-aware eviction

Target range for first production iteration:

- 15% to 35% reduction in average stall time
- 20%+ reduction in redundant fetches on reuse-heavy traces

## 7. Failure Modes and Mitigations

1. Predictor drift from non-stationary traffic
- Mitigation: sliding-window retraining, confidence decay, safe fallback to LRU.

2. Scheduler overfitting to stale latency estimates
- Mitigation: online latency calibration from observed fetch metrics.

3. Prefetch queue contention causing head-of-line blocking
- Mitigation: class-based queues and hard reservations for immediate chunks.

4. Multi-tier thrashing between RAM and disk
- Mitigation: hysteresis thresholds and minimum residency time.

5. Invariant pressure under bursty prefetch
- Mitigation: invariant-aware admission gate before queue enqueue.

6. Overhead from sophisticated planning at small model scale
- Mitigation: auto-disable advanced planner below size threshold.

## 8. Non-Negotiable Safety Rules

Every new policy or planner must satisfy:

1. Invariant-first execution: reject actions that could violate $C(t) \le \alpha W$.
2. No full-materialization assumptions.
3. Remote-chunk execution remains the source-of-truth model.
4. Fallback path always available (`sequential` + `lru`).

This keeps Rex deployable while progressively adding mathematically stronger optimization.