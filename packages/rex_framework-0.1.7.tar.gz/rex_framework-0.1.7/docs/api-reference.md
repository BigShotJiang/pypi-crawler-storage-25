# API Reference

This file links to the concrete implementation entry points in the current repository.

For the merged end-user guide and operational workflow, use:

- `README.md`
- Archived report: `docs/archive/validation_and_benchmark_results_2026-04-14.md`

## Public API

### Configuration
- `src/rex/api/config.py`

### Model Load
- `src/rex/api/load.py`

### Inference Generate
- `src/rex/api/generate.py`

## Core Runtime APIs
- `src/rex/core/runtime.py`
- `src/rex/core/executor.py`
- `src/rex/core/scheduler.py`
- `src/rex/core/prefetcher.py`

## Storage APIs
- `src/rex/storage/http_range.py`
- `src/rex/storage/local_server.py`
- `src/rex/storage/stream_server.py`
- `src/rex/storage/stream_client.py`

## Core Planning APIs (Phase 1)
- `src/rex/core/graph_model.py`
- `src/rex/core/cost_model.py`

## Conversion APIs
- `src/rex/convert/pytorch_converter.py`
- `src/rex/formats/chunk_writer.py`
- `src/rex/formats/manifest.py`

## CLI APIs
- `src/rex/cli/main.py`
- `src/rex/cli/convert.py`
- `src/rex/cli/validate.py`
- `src/rex/cli/inspect.py`
- `src/rex/cli/serve.py`
- `src/rex/cli/benchmark.py`
