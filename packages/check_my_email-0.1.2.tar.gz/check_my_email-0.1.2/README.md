# deep_consultation

Library for Check my Email

## Install from PIP

```bash
pip install --upgrade check_my_email
```

## More information

More information can be found in [doc](https://github.com/trucomanx-pylibs/CheckMyEmail/tree/main/doc)

## License

This project is licensed under the GPLv3 License.

