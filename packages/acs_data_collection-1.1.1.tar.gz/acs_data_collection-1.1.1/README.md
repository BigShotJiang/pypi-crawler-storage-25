# ACS Data Collection Service

**AbovyansConsultingServices — сервис сбора данных с маркетплейсов в ClickHouse**

Коннекторы загружают данные из API. Проект работает на Docker и пишет в ClickHouse; библиотеку можно использовать и отдельно.

### Поддерживаемые платформы

WB, Ozon, МойСклад, Яндекс.Маркет, Яндекс.Директ, VK, Bitrix24, AlfaCRM, Google Sheets.

### Быстрый старт

1. Установите Docker.
2. Скачайте [docker-compose.yml](https://raw.githubusercontent.com/abovyanmg/data-collection-service/main/docker-compose.yml) в папку с настройками.
3. Положите туда же `settings.xlsx` (структура: лист db — БД и Telegram, остальные листы — платформы).
4. Запуск: `docker-compose up -d`

Подробнее по Docker: [DOCKER.md](DOCKER.md)

### Конфигурация

- **settings.xlsx** — лист «db»: host, port, user, password, database, bot_token, chats; листы платформ: токены, отчёты, расписание.
- ClickHouse: порт 8123 (HTTP), логи: `docker-compose logs -f`

### Поддержка

- Issues: https://github.com/abovyanmg/data-collection-service/issues
- Email: abovyan.mg@gmail.com

### Лицензия

Разработано: AbovyansConsultingServices. Основано на открытых технологиях.

### Контекст для разработки (ИИ-агентам)

- **Полная документация для агентов:** см. файл `AGENTS.md` в родительской папке ACS (выше repos). Там архитектура, правила, ссылки на Morin, пайплайн обновления.
- **История багов:** `BUGS_AND_FIXES.md` — детальный разбор всех починок с паттернами диагностики.
- **Библиотека:** `admin/library/acs_data_library/`; точка входа: `admin/docker/upload_main.py`. PyPI: `acs-data-collection`.
- **Текущая версия:** см. `setup.py` (поднимать при каждом релизе).
- **Золотое правило:** при багах сверяйся с рабочим кодом Morin на GitHub (https://github.com/morinad/morin).

### Безопасность

Владелец может передавать логины и пароли агентам (ИИ или людям) для выполнения и проверки проекта. **Ни при каких обстоятельствах** не размещать эти логины и пароли в общедоступных местах: в репозитории на GitHub, в файлах, которые выгружаются и могут стать доступны третьим лицам, в примерах кода, в коммитах и т.п. Только локально или в защищённых каналах.

### Версии

Текущая версия: **1.0.6** (2026-02-16). Полная история: `CHANGELOG.md` в папке ACS.

### Благодарности

**Спасибо за базис: Morinad**

**Особая благодарность Александру Морину (@alexdirect)** — за знания и вдохновение.
