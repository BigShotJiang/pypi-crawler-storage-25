"""Cookie utilities for Keycloak token storage.

Convention: kc_* prefix for all auth cookies.
- kc_access_token  (httponly) — Keycloak access token
- kc_refresh_token (httponly) — Keycloak refresh token
- kc_id_token      (httponly) — Keycloak ID token
- kc_expires_at    (JS-readable) — token expiry timestamp for frontend
"""

from __future__ import annotations

import time

from starlette.requests import Request
from starlette.responses import Response

# Cookie names
ACCESS_TOKEN = "kc_access_token"
REFRESH_TOKEN = "kc_refresh_token"
ID_TOKEN = "kc_id_token"
EXPIRES_AT = "kc_expires_at"
LOGOUT_MARKER = "kc_logout_marker"

# Temporary cookies for login flow
PKCE_VERIFIER = "pkce_verifier"
CSRF_NONCE = "csrf_nonce"


def is_https(request: Request) -> bool:
    """Detect HTTPS from request scheme or X-Forwarded-Proto header."""
    if request.url.scheme == "https":
        return True
    forwarded = request.headers.get("x-forwarded-proto", "")
    return forwarded.lower() == "https"


def get_public_origin(request: Request) -> str:
    """Derive the public-facing origin from request headers."""
    host = request.headers.get("x-forwarded-host") or request.headers.get("host", "localhost")
    scheme = "https" if is_https(request) else "http"
    return f"{scheme}://{host}"


def set_token_cookies(
    response: Response,
    *,
    access_token: str,
    refresh_token: str,
    id_token: str,
    expires_in: int,
    refresh_expires_in: int,
    secure: bool,
) -> None:
    """Write all kc_* cookies onto a response."""
    base_kwargs = {
        "path": "/",
        "httponly": True,
        "secure": secure,
        "samesite": "lax",
    }

    response.set_cookie(ACCESS_TOKEN, access_token, max_age=expires_in, **base_kwargs)
    response.set_cookie(REFRESH_TOKEN, refresh_token, max_age=refresh_expires_in, **base_kwargs)
    response.set_cookie(ID_TOKEN, id_token, max_age=refresh_expires_in, **base_kwargs)

    # kc_expires_at is JS-readable (no httponly) for frontend expiry checks.
    # It uses milliseconds to match existing frontend consumers.
    expires_at = str(int(time.time() * 1000) + expires_in * 1000)
    response.set_cookie(
        EXPIRES_AT,
        expires_at,
        max_age=expires_in,
        path="/",
        httponly=False,
        secure=secure,
        samesite="lax",
    )


def clear_token_cookies(response: Response, *, secure: bool) -> None:
    """Remove all kc_* cookies."""
    for name in (ACCESS_TOKEN, REFRESH_TOKEN, ID_TOKEN, EXPIRES_AT):
        response.delete_cookie(name, path="/", secure=secure, samesite="lax")


def set_logout_marker(response: Response, *, secure: bool, max_age: int = 600) -> None:
    """Mark the browser as intentionally logged out until the next login starts."""
    response.set_cookie(
        LOGOUT_MARKER,
        "1",
        max_age=max_age,
        path="/",
        httponly=True,
        secure=secure,
        samesite="lax",
    )


def clear_logout_marker(response: Response, *, secure: bool) -> None:
    """Remove the explicit logout marker."""
    response.delete_cookie(LOGOUT_MARKER, path="/", secure=secure, samesite="lax")


def set_temporary_auth_cookies(
    response: Response,
    *,
    code_verifier: str,
    csrf_nonce: str,
    secure: bool,
) -> None:
    """Set short-lived cookies for the PKCE + CSRF login flow."""
    kwargs = {
        "path": "/",
        "httponly": True,
        "secure": secure,
        "samesite": "lax",
        "max_age": 600,  # 10 minutes
    }
    response.set_cookie(PKCE_VERIFIER, code_verifier, **kwargs)
    response.set_cookie(CSRF_NONCE, csrf_nonce, **kwargs)


def clear_temporary_auth_cookies(response: Response, *, secure: bool) -> None:
    """Remove PKCE + CSRF cookies after callback."""
    for name in (PKCE_VERIFIER, CSRF_NONCE):
        response.delete_cookie(name, path="/", secure=secure, samesite="lax")
