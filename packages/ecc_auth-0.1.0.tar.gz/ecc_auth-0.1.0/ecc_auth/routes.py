"""FastAPI auth router — one-line mount for login/callback/me/refresh/logout."""

from __future__ import annotations

import base64
import inspect
import json
import logging
import secrets
from collections.abc import Awaitable, Callable
from typing import Any
from urllib.parse import quote, urlsplit

import httpx
import jwt
from fastapi import APIRouter, Cookie, HTTPException, Request
from fastapi.responses import JSONResponse, RedirectResponse

from ecc_auth.client import (
    build_authorization_url,
    exchange_code_for_token,
    refresh_token as refresh_token_request,
)
from ecc_auth.config import KeycloakConfig
from ecc_auth.cookies import (
    clear_logout_marker,
    clear_temporary_auth_cookies,
    clear_token_cookies,
    get_public_origin,
    is_https,
    set_logout_marker,
    set_temporary_auth_cookies,
    set_token_cookies,
)
from ecc_auth.identity import AuthIdentity
from ecc_auth.jwks import verify_access_token

logger = logging.getLogger(__name__)

# Types for optional application callbacks.
AuthCallbackResult = Awaitable[Any] | Any
OnUserAuthenticated = Callable[[AuthIdentity], AuthCallbackResult] | None
LoadCurrentUser = Callable[[AuthIdentity], AuthCallbackResult] | None


def _generate_nonce() -> str:
    """Generate a random nonce for CSRF protection."""
    return secrets.token_urlsafe(32)


def _get_request_origin(request: Request) -> str:
    """Best-effort public app origin.

    Prefer browser-facing Origin/Referer for dev-proxy setups (localhost:3000),
    then fall back to forwarded/host headers from the backend request.
    """
    for header in ("origin", "referer"):
        value = request.headers.get(header)
        if not value:
            continue
        parsed = urlsplit(value)
        if parsed.scheme in ("http", "https") and parsed.netloc:
            return f"{parsed.scheme}://{parsed.netloc}"
    return get_public_origin(request)


def _encode_auth_state(nonce: str, return_to: str, origin: str) -> str:
    """Encode login state as a URL-safe base64 JSON string."""
    payload = json.dumps({"nonce": nonce, "return_to": return_to, "origin": origin})
    return base64.urlsafe_b64encode(payload.encode()).decode()


def _decode_auth_state(state: str) -> dict | None:
    """Decode auth state, returning None on failure."""
    try:
        payload = base64.urlsafe_b64decode(state.encode())
        return json.loads(payload)
    except Exception:
        return None


def _normalize_return_to(return_to: str) -> str:
    """Ensure return_to is a relative path to prevent open redirect."""
    if not return_to or not return_to.startswith("/"):
        return "/"
    return return_to


async def _invoke_callback(callback: Callable[[AuthIdentity], AuthCallbackResult], identity: AuthIdentity) -> Any:
    result = callback(identity)
    if inspect.isawaitable(result):
        return await result
    return result


async def _build_me_payload(identity: AuthIdentity, load_current_user: LoadCurrentUser) -> dict[str, Any]:
    user = _identity_to_dict(identity)
    if load_current_user is not None:
        user = await _invoke_callback(load_current_user, identity)
    return {"user": user}


def _raise_upstream_http_error(exc: httpx.HTTPStatusError) -> None:
    if exc.response.status_code >= 500:
        raise HTTPException(status_code=503, detail="Authentication service unavailable") from exc


def create_auth_router(
    config: KeycloakConfig,
    *,
    on_user_authenticated: OnUserAuthenticated = None,
    load_current_user: LoadCurrentUser = None,
    default_return_to: str = "/",
) -> APIRouter:
    """Create a FastAPI router with standard Keycloak OIDC endpoints.

    Registers 5 endpoints:
    - GET  /login    — redirect to Keycloak
    - GET  /callback — handle Keycloak callback, set cookies
    - GET  /me       — return current user identity
    - POST /refresh  — refresh access token
    - POST /logout   — clear cookies, return Keycloak logout URL

    Args:
        config: Keycloak configuration.
        on_user_authenticated: Optional async callback invoked after successful
            login with the AuthIdentity. Use this for user upsert logic.
        load_current_user: Optional callback for /me that maps AuthIdentity
            into an application-specific user DTO.
        default_return_to: Default redirect path after login.
    """
    router = APIRouter(tags=["auth"])

    @router.get("/login")
    async def login(
        request: Request,
        return_to: str | None = None,
    ) -> RedirectResponse:
        """Initiate Keycloak login flow with Authlib discovery + PKCE."""
        resolved_return_to = _normalize_return_to(return_to or default_return_to)
        nonce = _generate_nonce()
        app_origin = _get_request_origin(request)
        state = _encode_auth_state(
            nonce=nonce,
            return_to=resolved_return_to,
            origin=app_origin,
        )

        redirect_uri = f"{app_origin}/api/auth/callback"
        authorization = await build_authorization_url(
            config,
            redirect_uri=redirect_uri,
            state=state,
            nonce=nonce,
        )

        response = RedirectResponse(url=authorization["url"], status_code=302)
        set_temporary_auth_cookies(
            response,
            code_verifier=authorization["code_verifier"],
            csrf_nonce=nonce,
            secure=is_https(request),
        )
        clear_logout_marker(response, secure=is_https(request))
        logger.info("Login initiated, redirecting to Keycloak")
        return response

    @router.get("/callback")
    async def callback(
        request: Request,
        code: str | None = None,
        state: str | None = None,
        pkce_verifier: str | None = Cookie(default=None),
        csrf_nonce: str | None = Cookie(default=None),
    ) -> RedirectResponse:
        """Handle Keycloak callback — exchange code, set token cookies."""
        fallback_origin = get_public_origin(request)
        error_base = f"{fallback_origin}/?error="

        if not state:
            return RedirectResponse(url=f"{error_base}missing_state", status_code=302)

        state_payload = _decode_auth_state(state)
        if state_payload is None:
            return RedirectResponse(url=f"{error_base}invalid_state", status_code=302)

        if not code:
            return RedirectResponse(url=f"{error_base}missing_code", status_code=302)

        if not csrf_nonce or csrf_nonce != state_payload.get("nonce"):
            return RedirectResponse(url=f"{error_base}csrf_mismatch", status_code=302)

        if not pkce_verifier:
            return RedirectResponse(url=f"{error_base}missing_pkce", status_code=302)

        app_origin = state_payload.get("origin") or fallback_origin
        error_base = f"{app_origin}/?error="

        try:
            redirect_uri = f"{app_origin}/api/auth/callback"
            token_data = await exchange_code_for_token(
                config,
                code=code,
                redirect_uri=redirect_uri,
                code_verifier=pkce_verifier,
            )

            access_token = token_data["access_token"]
            refresh_token_value = token_data["refresh_token"]
            id_token = token_data.get("id_token", "")
            expires_in = token_data.get("expires_in", 300)
            refresh_expires_in = token_data.get("refresh_expires_in", 1800)

            # Invoke user sync callback if provided
            if on_user_authenticated:
                claims = await verify_access_token(access_token, config)
                identity = AuthIdentity.from_claims(claims)
                await _invoke_callback(on_user_authenticated, identity)

            return_to = _normalize_return_to(state_payload.get("return_to", default_return_to))
            response = RedirectResponse(url=f"{app_origin}{return_to}", status_code=302)
            secure = is_https(request)

            set_token_cookies(
                response,
                access_token=access_token,
                refresh_token=refresh_token_value,
                id_token=id_token,
                expires_in=expires_in,
                refresh_expires_in=refresh_expires_in,
                secure=secure,
            )
            clear_logout_marker(response, secure=secure)
            clear_temporary_auth_cookies(response, secure=secure)

            logger.info("Login successful")
            return response

        except httpx.HTTPStatusError as exc:
            logger.exception("Token exchange failed: %s", exc.response.text)
            return RedirectResponse(url=f"{error_base}token_exchange_failed", status_code=302)
        except httpx.HTTPError:
            logger.exception("Callback failed due to upstream request error")
            return RedirectResponse(url=f"{error_base}callback_failed", status_code=302)
        except Exception:
            logger.exception("Callback failed")
            return RedirectResponse(url=f"{error_base}callback_failed", status_code=302)

    @router.get("/me")
    async def me(
        request: Request,
        kc_access_token: str | None = Cookie(default=None),
        kc_refresh_token: str | None = Cookie(default=None),
        kc_logout_marker: str | None = Cookie(default=None),
    ) -> JSONResponse:
        """Return current user identity from access token (JWKS verified)."""
        if kc_logout_marker:
            response = JSONResponse({"detail": "Logged out"}, status_code=401)
            clear_token_cookies(response, secure=is_https(request))
            return response

        if not kc_access_token and not kc_refresh_token:
            raise HTTPException(status_code=401, detail="Not authenticated")

        secure = is_https(request)

        # Try access token first
        if kc_access_token:
            try:
                claims = await verify_access_token(kc_access_token, config)
                identity = AuthIdentity.from_claims(claims)
                return JSONResponse(await _build_me_payload(identity, load_current_user))
            except jwt.InvalidTokenError:
                logger.debug("Access token verification failed, trying refresh")
            except Exception:
                logger.debug("Access token verification failed, trying refresh")

        # Fall back to refresh
        if not kc_refresh_token:
            response = JSONResponse({"detail": "Session expired"}, status_code=401)
            clear_token_cookies(response, secure=secure)
            return response

        try:
            token_data = await refresh_token_request(config, kc_refresh_token)
            claims = await verify_access_token(token_data["access_token"], config)
            identity = AuthIdentity.from_claims(claims)

            response = JSONResponse(await _build_me_payload(identity, load_current_user))
            set_token_cookies(
                response,
                access_token=token_data["access_token"],
                refresh_token=token_data["refresh_token"],
                id_token=token_data.get("id_token", ""),
                expires_in=token_data.get("expires_in", 300),
                refresh_expires_in=token_data.get("refresh_expires_in", 1800),
                secure=secure,
            )
            return response
        except httpx.HTTPStatusError as exc:
            _raise_upstream_http_error(exc)
            logger.exception("Refresh failed in /me: %s", exc.response.text)
            response = JSONResponse({"detail": "Session expired"}, status_code=401)
            clear_token_cookies(response, secure=secure)
            return response
        except httpx.HTTPError:
            logger.exception("Refresh failed in /me due to upstream request error")
            raise HTTPException(status_code=503, detail="Authentication service unavailable")
        except Exception:
            logger.exception("Refresh failed in /me")
            response = JSONResponse({"detail": "Session expired"}, status_code=401)
            clear_token_cookies(response, secure=secure)
            return response

    @router.post("/refresh")
    async def refresh(
        request: Request,
        kc_refresh_token: str | None = Cookie(default=None),
        kc_logout_marker: str | None = Cookie(default=None),
    ) -> JSONResponse:
        """Refresh the access token."""
        if kc_logout_marker:
            response = JSONResponse({"detail": "Logged out"}, status_code=401)
            clear_token_cookies(response, secure=is_https(request))
            return response

        if not kc_refresh_token:
            raise HTTPException(status_code=401, detail="Not authenticated")

        secure = is_https(request)

        try:
            token_data = await refresh_token_request(config, kc_refresh_token)
            response = JSONResponse({"ok": True})
            set_token_cookies(
                response,
                access_token=token_data["access_token"],
                refresh_token=token_data["refresh_token"],
                id_token=token_data.get("id_token", ""),
                expires_in=token_data.get("expires_in", 300),
                refresh_expires_in=token_data.get("refresh_expires_in", 1800),
                secure=secure,
            )
            return response
        except httpx.HTTPStatusError as exc:
            _raise_upstream_http_error(exc)
            response = JSONResponse({"detail": "Refresh failed"}, status_code=401)
            clear_token_cookies(response, secure=secure)
            return response
        except httpx.HTTPError:
            raise HTTPException(status_code=503, detail="Authentication service unavailable")

    @router.post("/logout")
    async def logout(
        request: Request,
        kc_id_token: str | None = Cookie(default=None),
    ) -> JSONResponse:
        """Logout: clear cookies and return Keycloak logout URL."""
        secure = is_https(request)
        post_logout_redirect = f"{_get_request_origin(request)}/"
        logout_url = (
            f"{config.end_session_endpoint}"
            f"?post_logout_redirect_uri={quote(post_logout_redirect)}"
            f"&client_id={quote(config.client_id)}"
        )
        if kc_id_token:
            logout_url += f"&id_token_hint={kc_id_token}"

        response = JSONResponse({"logoutUrl": logout_url})
        set_logout_marker(response, secure=secure)
        clear_token_cookies(response, secure=secure)
        clear_temporary_auth_cookies(response, secure=secure)
        logger.info("Logout successful")
        return response

    return router


def _identity_to_dict(identity: AuthIdentity) -> dict:
    """Convert AuthIdentity to a JSON-serializable dict."""
    return {
        "externalAuthId": identity.external_auth_id,
        "email": identity.email,
        "displayName": identity.display_name,
        "username": identity.username,
        "emailVerified": identity.email_verified,
        "givenName": identity.given_name,
        "familyName": identity.family_name,
    }
