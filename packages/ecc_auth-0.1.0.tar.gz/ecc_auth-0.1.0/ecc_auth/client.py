"""Authlib-backed OIDC client helpers."""

from __future__ import annotations

import ssl
from typing import TYPE_CHECKING

import httpx
from authlib.integrations.starlette_client import OAuth
from authlib.integrations.starlette_client.apps import StarletteOAuth2App

if TYPE_CHECKING:
    from ecc_auth.config import KeycloakConfig


def _build_httpx_kwargs(config: "KeycloakConfig") -> dict:
    """Build shared httpx kwargs for Keycloak requests.

    - `trust_env=False` prevents accidental use of shell/system proxy settings.
    - `verify` is relaxed when KEYCLOAK_TLS_INSECURE=true for test environments.
    """
    httpx_kwargs: dict = {
        "trust_env": False,
        "timeout": 20.0,
    }

    if config.tls_insecure:
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        httpx_kwargs["verify"] = ctx

    return httpx_kwargs


def create_oauth(config: KeycloakConfig) -> OAuth:
    """Create an Authlib OAuth instance configured for Keycloak.

    Authlib handles PKCE, state, nonce, and code exchange automatically
    via the starlette_client integration.

    We intentionally register explicit OIDC endpoints instead of relying on
    dynamic discovery (`server_metadata_url`) on every login. In this test
    environment the discovery fetch is intermittently flaky, which makes
    `/api/auth/login` fail before we even redirect to Keycloak.
    """
    oauth = OAuth()
    httpx_kwargs = _build_httpx_kwargs(config)

    oauth.register(
        name="keycloak",
        client_id=config.client_id,
        client_secret=config.client_secret,
        authorize_url=config.authorization_endpoint,
        access_token_url=config.token_endpoint,
        api_base_url=config.issuer,
        client_kwargs={
            "scope": "openid profile email",
            "code_challenge_method": "S256",
            **httpx_kwargs,
        },
    )
    return oauth


def create_keycloak_client(config: KeycloakConfig) -> StarletteOAuth2App:
    """Create the reusable Authlib Keycloak client."""
    client = create_oauth(config).create_client("keycloak")
    if client is None:
        raise RuntimeError("Failed to initialize Keycloak OAuth client")
    return client


async def build_authorization_url(
    config: KeycloakConfig,
    *,
    redirect_uri: str,
    state: str,
    nonce: str,
) -> dict:
    """Build the login redirect URL via Authlib discovery + PKCE."""
    client = create_keycloak_client(config)
    authorization = await client.create_authorization_url(
        redirect_uri=redirect_uri,
        state=state,
        nonce=nonce,
    )
    return {
        "url": authorization["url"],
        "state": authorization["state"],
        "code_verifier": authorization["code_verifier"],
    }


async def exchange_code_for_token(
    config: KeycloakConfig,
    *,
    code: str,
    redirect_uri: str,
    code_verifier: str,
) -> dict:
    """Exchange an authorization code for tokens via Authlib."""
    client = create_keycloak_client(config)
    return await client.fetch_access_token(
        redirect_uri=redirect_uri,
        code=code,
        code_verifier=code_verifier,
    )


async def refresh_token(config: KeycloakConfig, refresh_token_value: str) -> dict:
    """Refresh an access token using the Keycloak token endpoint.

    Authlib's starlette_client doesn't expose a direct refresh method,
    so we call the token endpoint manually via httpx.

    Returns the raw token response dict with keys:
    access_token, refresh_token, id_token, expires_in, refresh_expires_in, etc.
    """
    async with httpx.AsyncClient(**_build_httpx_kwargs(config)) as client:
        resp = await client.post(
            config.token_endpoint,
            data={
                "grant_type": "refresh_token",
                "client_id": config.client_id,
                "client_secret": config.client_secret,
                "refresh_token": refresh_token_value,
            },
        )
        resp.raise_for_status()
        return resp.json()
