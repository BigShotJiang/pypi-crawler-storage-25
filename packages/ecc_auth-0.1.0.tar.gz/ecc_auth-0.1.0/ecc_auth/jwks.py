"""JWKS local token verification — zero network overhead per request."""

from __future__ import annotations

import ssl
import time
from typing import TYPE_CHECKING, Any

import httpx
import jwt
from jwt import PyJWKClient, PyJWKClientError

if TYPE_CHECKING:
    from ecc_auth.config import KeycloakConfig

# Module-level cache: config.jwks_uri -> (PyJWKClient, created_at)
_jwk_clients: dict[str, tuple[PyJWKClient, float]] = {}

# Cache TTL: 1 hour (JWKS keys rarely rotate)
_CACHE_TTL = 3600


def _get_jwk_client(config: KeycloakConfig) -> PyJWKClient:
    """Get or create a cached PyJWKClient for the given config."""
    uri = config.jwks_uri
    now = time.monotonic()

    cached = _jwk_clients.get(uri)
    if cached and (now - cached[1]) < _CACHE_TTL:
        return cached[0]

    # PyJWKClient handles key caching internally and refetches on unknown kid
    ssl_context: ssl.SSLContext | None = None
    if config.tls_insecure:
        ssl_context = ssl.create_default_context()
        ssl_context.check_hostname = False
        ssl_context.verify_mode = ssl.CERT_NONE

    client = PyJWKClient(uri, cache_keys=True, ssl_context=ssl_context)
    _jwk_clients[uri] = (client, now)
    return client


async def verify_access_token(
    token: str,
    config: KeycloakConfig,
    *,
    audience: str | None = None,
) -> dict[str, Any]:
    """Verify a Keycloak access token using JWKS local verification.

    This replaces the per-request /userinfo call with local JWT verification:
    - 0ms network overhead (vs 50-200ms for /userinfo)
    - Keycloak can be briefly down without affecting already-issued tokens
    - Public keys are cached and auto-refreshed on unknown kid

    Args:
        token: The raw JWT access token string.
        config: Keycloak configuration.
        audience: Expected audience claim. If None, audience is not validated
                  (Keycloak access tokens may not always include aud).

    Returns:
        Decoded JWT claims dict.

    Raises:
        jwt.InvalidTokenError: If the token is invalid, expired, or untrusted.
    """
    jwk_client = _get_jwk_client(config)

    try:
        signing_key = jwk_client.get_signing_key_from_jwt(token)
    except PyJWKClientError:
        # Unknown kid — force refetch and retry once
        _jwk_clients.pop(config.jwks_uri, None)
        jwk_client = _get_jwk_client(config)
        signing_key = jwk_client.get_signing_key_from_jwt(token)

    decode_options: dict[str, Any] = {
        "algorithms": ["RS256"],
        "issuer": config.issuer,
    }
    if audience:
        decode_options["audience"] = audience
    else:
        decode_options["options"] = {"verify_aud": False}

    return jwt.decode(
        token,
        signing_key.key,
        **decode_options,
    )
