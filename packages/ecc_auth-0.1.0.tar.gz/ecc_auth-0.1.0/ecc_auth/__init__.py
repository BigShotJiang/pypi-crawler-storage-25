"""ecc-auth: Shared Keycloak OIDC authentication SDK for ECC projects."""

from ecc_auth.config import KeycloakConfig
from ecc_auth.dependencies import get_current_user, get_current_user_optional, init_dependencies
from ecc_auth.identity import AuthIdentity
from ecc_auth.routes import create_auth_router
from ecc_auth.jwks import verify_access_token

__all__ = [
    "KeycloakConfig",
    "AuthIdentity",
    "create_auth_router",
    "init_dependencies",
    "get_current_user",
    "get_current_user_optional",
    "verify_access_token",
]
