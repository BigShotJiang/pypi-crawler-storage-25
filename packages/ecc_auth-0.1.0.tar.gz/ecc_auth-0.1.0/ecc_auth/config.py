"""Keycloak configuration from environment variables."""

from __future__ import annotations

import os
from dataclasses import dataclass, field


@dataclass(frozen=True)
class KeycloakConfig:
    """Keycloak OIDC configuration.

    Reads from environment variables by default, but all fields can be
    overridden via constructor arguments.
    """

    url: str = field(default_factory=lambda: os.environ["KEYCLOAK_URL"])
    realm: str = field(default_factory=lambda: os.environ["KEYCLOAK_REALM"])
    client_id: str = field(default_factory=lambda: os.environ["KEYCLOAK_CLIENT_ID"])
    client_secret: str = field(default_factory=lambda: os.environ["KEYCLOAK_CLIENT_SECRET"])
    tls_insecure: bool = field(
        default_factory=lambda: os.environ.get("KEYCLOAK_TLS_INSECURE", "false").lower() == "true"
    )

    @property
    def issuer(self) -> str:
        return f"{self.url}/realms/{self.realm}"

    @property
    def discovery_url(self) -> str:
        return f"{self.issuer}/.well-known/openid-configuration"

    @property
    def jwks_uri(self) -> str:
        return f"{self.issuer}/protocol/openid-connect/certs"

    @property
    def token_endpoint(self) -> str:
        return f"{self.issuer}/protocol/openid-connect/token"

    @property
    def authorization_endpoint(self) -> str:
        return f"{self.issuer}/protocol/openid-connect/auth"

    @property
    def end_session_endpoint(self) -> str:
        return f"{self.issuer}/protocol/openid-connect/logout"
