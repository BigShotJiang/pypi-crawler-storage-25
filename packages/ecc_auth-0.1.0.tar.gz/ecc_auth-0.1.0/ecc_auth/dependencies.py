"""FastAPI dependencies for auth — drop-in replacements for hand-written get_current_user."""

from __future__ import annotations

from typing import TYPE_CHECKING

import jwt
from fastapi import Cookie, HTTPException

from ecc_auth.identity import AuthIdentity
from ecc_auth.jwks import verify_access_token

if TYPE_CHECKING:
    from ecc_auth.config import KeycloakConfig

# Module-level config reference, set by init_dependencies()
_config: KeycloakConfig | None = None


def init_dependencies(config: KeycloakConfig) -> None:
    """Initialize the dependency module with a KeycloakConfig.

    Call this once at app startup before using get_current_user / get_current_user_optional.
    Typically done right after creating the auth router:

        config = KeycloakConfig()
        router = create_auth_router(config)
        init_dependencies(config)
    """
    global _config
    _config = config


def _get_config() -> KeycloakConfig:
    if _config is None:
        raise RuntimeError(
            "ecc_auth dependencies not initialized. "
            "Call ecc_auth.init_dependencies(config) at app startup."
        )
    return _config


async def get_current_user(
    kc_access_token: str | None = Cookie(default=None),
) -> AuthIdentity:
    """FastAPI dependency: resolve current user from kc_access_token cookie.

    Uses JWKS local verification (0ms network overhead).
    Does NOT attempt refresh — refresh flows belong in explicit auth endpoints.

    Raises HTTPException 401 if not authenticated or token is invalid.
    """
    if not kc_access_token:
        raise HTTPException(status_code=401, detail="Not authenticated")

    config = _get_config()

    try:
        claims = await verify_access_token(kc_access_token, config)
        return AuthIdentity.from_claims(claims)
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid or expired token")
    except Exception:
        raise HTTPException(status_code=503, detail="Authentication service unavailable")


async def get_current_user_optional(
    kc_access_token: str | None = Cookie(default=None),
) -> AuthIdentity | None:
    """FastAPI dependency: resolve current user, returning None when unauthenticated."""
    try:
        return await get_current_user(kc_access_token)
    except HTTPException:
        return None
