"""AuthIdentity — unified claims contract across all ECC projects."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class AuthIdentity:
    """Normalized user identity from Keycloak claims.

    This is the shared contract: every ECC project maps Keycloak claims
    to this structure. Field names match the identity contract doc
    (docs/02-identity-contract.md).
    """

    external_auth_id: str  # Keycloak `sub`
    email: str | None
    display_name: str  # name > preferred_username > email > sub
    username: str  # preferred_username > email > sub
    email_verified: bool = False
    given_name: str | None = None
    family_name: str | None = None

    @classmethod
    def from_claims(cls, claims: dict) -> AuthIdentity:
        """Build an AuthIdentity from Keycloak token claims or userinfo."""
        sub = claims["sub"]
        email = claims.get("email")
        preferred_username = claims.get("preferred_username")
        name = claims.get("name")

        # Fallback chain for display_name: name > preferred_username > email > sub
        display_name = name or preferred_username or email or sub
        username = preferred_username or email or sub

        return cls(
            external_auth_id=sub,
            email=email,
            display_name=display_name,
            username=username,
            email_verified=claims.get("email_verified", False),
            given_name=claims.get("given_name"),
            family_name=claims.get("family_name"),
        )
