from __future__ import annotations

import time
from collections.abc import Callable
from http.cookies import SimpleCookie
from unittest.mock import AsyncMock, patch

import httpx
import jwt
from fastapi import FastAPI
from fastapi.testclient import TestClient
from starlette.responses import Response

from ecc_auth import init_dependencies
from ecc_auth.config import KeycloakConfig
from ecc_auth.cookies import EXPIRES_AT, LOGOUT_MARKER, set_token_cookies
from ecc_auth.routes import _decode_auth_state, create_auth_router


def _make_config() -> KeycloakConfig:
    return KeycloakConfig(
        url="https://keycloak.example.com",
        realm="ecc",
        client_id="client-id",
        client_secret="client-secret",
        tls_insecure=False,
    )


def _make_client(*, load_current_user: Callable | None = None) -> TestClient:
    app = FastAPI()
    app.include_router(
        create_auth_router(
            _make_config(),
            load_current_user=load_current_user,
        ),
        prefix="/api/auth",
    )
    return TestClient(app)


def _cookie_value(response: Response, name: str) -> str:
    cookie = SimpleCookie()
    get_cookies = getattr(response.headers, "get_list", None) or response.headers.getlist
    for header in get_cookies("set-cookie"):
        cookie.load(header)
    return cookie[name].value


def test_init_dependencies_is_exported_from_package_root() -> None:
    assert callable(init_dependencies)


def test_set_token_cookies_uses_millisecond_expiry() -> None:
    response = Response()
    before_ms = int(time.time() * 1000)

    set_token_cookies(
        response,
        access_token="access-token",
        refresh_token="refresh-token",
        id_token="id-token",
        expires_in=300,
        refresh_expires_in=1800,
        secure=False,
    )

    expires_at = int(_cookie_value(response, EXPIRES_AT))
    assert expires_at >= before_ms + 300_000 - 2_000
    assert expires_at <= before_ms + 300_000 + 2_000
    assert expires_at > 1_000_000_000_000


def test_login_uses_return_to_query_param() -> None:
    client = _make_client()
    authorization_mock = AsyncMock(
        return_value={
            "url": "https://keycloak.example.com/authorize",
            "state": "opaque-state",
            "code_verifier": "pkce-verifier",
        }
    )

    with patch("ecc_auth.routes.build_authorization_url", authorization_mock):
        response = client.get(
            "/api/auth/login",
            params={"return_to": "/snake"},
            follow_redirects=False,
        )

    assert response.status_code == 302
    state = authorization_mock.await_args.kwargs["state"]
    assert _decode_auth_state(state) == {
        "nonce": response.cookies["csrf_nonce"],
        "return_to": "/snake",
        "origin": "http://testserver",
    }
    assert response.cookies["pkce_verifier"] == "pkce-verifier"


def test_me_uses_hydrator_and_refresh_fallback() -> None:
    async def load_current_user(identity):
        return {
            "id": 123,
            "externalAuthId": identity.external_auth_id,
            "displayName": identity.display_name,
            "profile": {"profileCompleted": True},
        }

    client = _make_client(load_current_user=load_current_user)
    verify_mock = AsyncMock(
        side_effect=[
            jwt.ExpiredSignatureError("expired"),
            {
                "sub": "kc-sub",
                "name": "Alice",
                "preferred_username": "alice",
                "email": "alice@example.com",
                "email_verified": True,
            },
        ]
    )
    refresh_mock = AsyncMock(
        return_value={
            "access_token": "new-access-token",
            "refresh_token": "new-refresh-token",
            "id_token": "id-token",
            "expires_in": 300,
            "refresh_expires_in": 1800,
        }
    )

    with (
        patch("ecc_auth.routes.verify_access_token", verify_mock),
        patch("ecc_auth.routes.refresh_token_request", refresh_mock),
    ):
        client.cookies.set("kc_access_token", "expired-access-token")
        client.cookies.set("kc_refresh_token", "refresh-token")
        response = client.get("/api/auth/me")

    assert response.status_code == 200
    assert response.json() == {
        "user": {
            "id": 123,
            "externalAuthId": "kc-sub",
            "displayName": "Alice",
            "profile": {"profileCompleted": True},
        }
    }
    refresh_mock.assert_awaited_once()
    assert int(response.cookies[EXPIRES_AT]) > 1_000_000_000_000


def test_refresh_returns_503_when_keycloak_is_unavailable() -> None:
    client = _make_client()
    request = httpx.Request("POST", "https://keycloak.example.com/token")
    response = httpx.Response(status_code=503, request=request)

    with patch(
        "ecc_auth.routes.refresh_token_request",
        AsyncMock(side_effect=httpx.HTTPStatusError("upstream down", request=request, response=response)),
    ):
        client.cookies.set("kc_refresh_token", "refresh-token")
        result = client.post("/api/auth/refresh")

    assert result.status_code == 503
    assert result.json() == {"detail": "Authentication service unavailable"}


def test_logout_sets_marker_cookie() -> None:
    client = _make_client()
    client.cookies.set("kc_id_token", "id-token")

    response = client.post("/api/auth/logout")

    assert response.status_code == 200
    assert _cookie_value(response, LOGOUT_MARKER) == "1"
    assert response.json()["logoutUrl"].startswith("https://keycloak.example.com/realms/ecc/protocol/openid-connect/logout")


def test_me_skips_refresh_when_logout_marker_is_present() -> None:
    client = _make_client()
    refresh_mock = AsyncMock()

    with patch("ecc_auth.routes.refresh_token_request", refresh_mock):
        client.cookies.set("kc_access_token", "stale-access-token")
        client.cookies.set("kc_refresh_token", "refresh-token")
        client.cookies.set(LOGOUT_MARKER, "1")
        response = client.get("/api/auth/me")

    assert response.status_code == 401
    assert response.json() == {"detail": "Logged out"}
    refresh_mock.assert_not_awaited()


def test_refresh_skips_upstream_call_when_logout_marker_is_present() -> None:
    client = _make_client()
    refresh_mock = AsyncMock()

    with patch("ecc_auth.routes.refresh_token_request", refresh_mock):
        client.cookies.set("kc_refresh_token", "refresh-token")
        client.cookies.set(LOGOUT_MARKER, "1")
        response = client.post("/api/auth/refresh")

    assert response.status_code == 401
    assert response.json() == {"detail": "Logged out"}
    refresh_mock.assert_not_awaited()
