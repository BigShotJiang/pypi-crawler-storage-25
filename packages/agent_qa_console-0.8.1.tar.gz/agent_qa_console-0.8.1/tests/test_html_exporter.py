"""Unit tests for qa_mcp.tools.html_exporter — pure string/file functions."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from qa_mcp.tools.html_exporter import (
    _collect_fonts,
    _css_inline,
    _element_to_html,
    _extract_pseudo_from_elements,
    _pseudo_to_css,
    export_component_to_html,
    export_to_html,
)


def test_css_inline_basic_camel_to_kebab():
    out = _css_inline({"color": "red", "fontSize": "12px", "backgroundColor": "white"})
    parts = [p.strip() for p in out.split(";")]
    assert "color: red" in parts
    assert "font-size: 12px" in parts
    assert "background-color: white" in parts


def test_css_inline_skips_metadata_and_nested():
    out = _css_inline({"color": "red", "_pseudo": {"::before": {"x": "y"}}, "nested": {"a": 1}})
    assert out == "color: red"


def test_pseudo_to_css_builds_rule_with_content():
    out = _pseudo_to_css(".foo", "before", {"content": '"hi"', "color": "red"})
    assert out.startswith(".foo::before { ")
    assert 'content: "hi"' in out
    assert "color: red" in out
    assert out.endswith(" }")


def test_pseudo_to_css_empty_returns_empty_string():
    assert _pseudo_to_css(".foo", "before", {}) == ""
    assert _pseudo_to_css(".foo", "before", {"_skip": "x"}) == ""


def test_pseudo_to_css_strips_leading_colons():
    out = _pseudo_to_css(".x", "::after", {"color": "blue"})
    assert ".x::after {" in out


def test_element_to_html_self_closing_img_with_src():
    el = {"tag": "img", "src": "https://x/y.png", "styles": {}}
    out = _element_to_html(el)
    assert out.strip().startswith("<img")
    assert 'src="https://x/y.png"' in out
    assert out.strip().endswith("/>")


def test_element_to_html_anchor_with_href_classes_id():
    el = {
        "tag": "a", "href": "https://x", "id": "cta", "classes": "btn primary",
        "text": "Click", "styles": {"color": "#fff"},
    }
    out = _element_to_html(el)
    assert "<a " in out
    assert 'href="https://x"' in out
    assert 'class="btn primary"' in out
    assert 'id="cta"' in out
    assert "color: #fff" in out
    assert "Click" in out
    assert "</a>" in out


def test_element_to_html_escapes_script_text():
    el = {"tag": "script", "text": "<script>alert('xss')</script>", "styles": {}}
    out = _element_to_html(el)
    assert "&lt;script&gt;" in out


def test_element_to_html_empty_returns_empty_string():
    assert _element_to_html({}) == ""
    assert _element_to_html(None) == ""


def test_element_to_html_container_with_children():
    el = {
        "tag": "div", "classes": "card", "styles": {},
        "children": [
            {"tag": "h1", "text": "Title", "styles": {}},
            {"tag": "p", "text": "Body", "styles": {}},
        ],
    }
    out = _element_to_html(el)
    assert "<div class=\"card\">" in out
    assert "<h1" in out and "Title" in out
    assert "<p" in out and "Body" in out
    assert "</div>" in out


def test_element_to_html_empty_container_no_text_or_children():
    el = {"tag": "section", "styles": {}}
    out = _element_to_html(el).strip()
    assert out == "<section></section>"


def test_element_to_html_with_pseudo_assigns_class_and_collects_rule():
    rules: list[str] = []
    counter = [0]
    el = {
        "tag": "div", "text": "x", "styles": {"_pseudo": {"before": {"content": '"hi"'}}},
    }
    out = _element_to_html(el, pseudo_rules=rules, id_counter=counter)
    assert 'class="qa-mcp-el-1"' in out
    assert any("::before" in r for r in rules)


def test_collect_fonts_recursive():
    elements = [
        {"styles": {"fontFamily": "Inter"}, "children": [
            {"styles": {"fontFamily": "Roboto"}, "children": []}
        ]},
        {"styles": {"fontFamily": "Inter"}, "children": []},  # duplicate
        "not-a-dict",
    ]
    fonts = _collect_fonts(elements)
    assert fonts == {"Inter", "Roboto"}


def test_extract_pseudo_from_elements_assigns_sequential_classes():
    elements = [
        {"styles": {"_pseudo": {"before": {"content": '"a"'}}}, "children": []},
        {"styles": {}, "children": [
            {"styles": {"_pseudo": {"after": {"content": '"b"'}}}, "children": []},
        ]},
    ]
    rules = _extract_pseudo_from_elements(elements)
    assert any(".qa-mcp-el-1::before" in r for r in rules)
    assert any(".qa-mcp-el-2::after" in r for r in rules)


def test_export_to_html_writes_file_with_tailwind_and_fonts(tmp_path):
    extracted = {
        "sections": [
            {
                "tag": "section", "label": "hero", "styles": {"fontFamily": "Inter"},
                "children": [
                    {"tag": "h1", "text": "Hello", "styles": {}},
                ],
            }
        ],
        "keyframes": [{"css": "@keyframes a { from { opacity: 0; } to { opacity: 1; } }"}],
    }
    out = tmp_path / "out.html"
    res = export_to_html(extracted, str(out), title="My Page")
    assert res == str(out)
    text = out.read_text(encoding="utf-8")
    assert "<!DOCTYPE html>" in text
    assert 'lang="he" dir="rtl"' in text
    assert "<title>My Page</title>" in text
    assert "cdn.tailwindcss.com" in text
    assert "fonts.googleapis.com" in text
    assert "Inter" in text
    assert "@keyframes" in text
    assert "Hello" in text
    assert "hero" in text  # section label as comment


def test_export_to_html_without_tailwind_or_fonts(tmp_path):
    extracted = {"sections": [{"tag": "div", "styles": {}, "text": "x"}]}
    out = tmp_path / "bare.html"
    export_to_html(extracted, str(out), include_tailwind=False, include_fonts=False)
    text = out.read_text(encoding="utf-8")
    assert "cdn.tailwindcss.com" not in text
    assert "fonts.googleapis.com" not in text


def test_export_to_html_uses_elements_key_fallback(tmp_path):
    extracted = {"elements": [{"tag": "span", "text": "fallback", "styles": {}}]}
    out = tmp_path / "fallback.html"
    export_to_html(extracted, str(out))
    text = out.read_text(encoding="utf-8")
    assert "fallback" in text


def test_export_to_html_with_css_vars(tmp_path):
    extracted = {
        "sections": [
            {
                "tag": "div", "styles": {"_cssVariables": {"--brand": "#0f0"}},
                "children": [
                    {"tag": "span", "styles": {"_cssVariables": {"--accent": "#ff0"}}, "text": "x"},
                ],
            }
        ]
    }
    out = tmp_path / "vars.html"
    export_to_html(extracted, str(out))
    text = out.read_text(encoding="utf-8")
    assert "--brand: #0f0" in text
    assert "--accent: #ff0" in text


def test_export_component_to_html_wraps_single_component(tmp_path):
    comp = {"tag": "button", "text": "Click", "styles": {"color": "red"}}
    out = tmp_path / "comp.html"
    res = export_component_to_html(comp, str(out), title="Btn")
    assert res == str(out)
    text = out.read_text(encoding="utf-8")
    assert "<title>Btn</title>" in text
    assert "Click" in text
