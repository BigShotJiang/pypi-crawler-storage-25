"""End-to-end test for Wave 1 + Wave 2 features (roadmap-to-10):

Wave 1:
  - Multi-browser (chromium/webkit/firefox)
  - Network throttling
  - Lighthouse 0-100 score in perf_metrics
  - RTL extensions: plural / date_ambiguous
  - Git-friendly baselines (.meta.json sidecar)
  - qa_responsive_audit

Wave 2:
  - qa_run_suite from config dict
  - HTML report (single-file, embedded screenshots)
  - JUnit XML emitter
  - CLI exit codes
"""
import asyncio
import json
import sys
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from qa_mcp.browser import SessionManager
from qa_mcp.tools import browser_tools, qa_tools
from qa_mcp import suite as _suite


async def main():
    mgr = SessionManager()
    fails = []
    try:
        # ===================================================================
        # Wave 1.1 — multi-browser sanity (chromium only, others optional)
        # ===================================================================
        s = await browser_tools.browser_open(
            mgr, url="data:text/html,<h1>multi</h1>",
            headless=True, browser="chromium",
        )
        if s.get("browser") != "chromium":
            fails.append(f"W1.1: browser field missing or wrong: {s.get('browser')}")
        else:
            print(f"[W1.1] ✓ browser='{s['browser']}' returned")
        await browser_tools.browser_close(mgr, s["session_id"])

        # Webkit / Firefox: try, but it's OK if not installed locally.
        for engine in ("webkit", "firefox"):
            try:
                s = await browser_tools.browser_open(
                    mgr, url="data:text/html,<h1>x</h1>",
                    headless=True, browser=engine,
                )
                if s.get("browser") == engine:
                    print(f"        ✓ {engine} also works")
                await browser_tools.browser_close(mgr, s["session_id"])
            except Exception as e:
                print(f"        ⚠ {engine} not available: {type(e).__name__}")

        # ===================================================================
        # Wave 1.2 — network throttling
        # ===================================================================
        s = await browser_tools.browser_open(
            mgr, url="data:text/html,<h1>net</h1>",
            headless=True, network="slow_3g",
        )
        sid = s["session_id"]
        if s.get("emulation", {}).get("network") != "slow_3g":
            fails.append(f"W1.2: network emulation not echoed: {s.get('emulation')}")
        else:
            print(f"[W1.2] ✓ slow_3g applied at open")
        # Runtime change
        r = await browser_tools.browser_throttle_network(mgr, sid, preset="4g")
        if not r.get("ok"):
            fails.append(f"W1.2 runtime change failed: {r}")
        else:
            print(f"        ✓ runtime swap to 4g: {r['applied']}")
        await browser_tools.browser_close(mgr, sid)

        # ===================================================================
        # Wave 1.3 — perf score 0-100
        # ===================================================================
        s = await browser_tools.browser_open(
            mgr, url="data:text/html,<h1>fast</h1>", headless=True,
        )
        sid = s["session_id"]
        perf = await qa_tools.qa_perf_metrics(mgr, sid, wait_for_lcp_ms=500)
        score = perf.get("score")
        print(f"[W1.3] perf score: {score}")
        if score is None:
            fails.append("W1.3: perf score missing")
        elif not (0 <= score <= 100):
            fails.append(f"W1.3: score out of range: {score}")
        else:
            print(f"        ✓ score in 0-100 range")
        await browser_tools.browser_close(mgr, sid)

        # ===================================================================
        # Wave 1.4 — RTL plural + date_ambiguous
        # ===================================================================
        RTL_TEST_HTML = (
            "data:text/html;charset=utf-8,<!doctype html>"
            "<html lang='he' dir='rtl'><body>"
            "<p>1 פריטים</p>"  # plural after 1 → bug
            "<p>2 פריט</p>"  # singular after 2 → bug
            "<p>3 פריטים</p>"  # OK
            "<p>תאריך: 03/04/2026</p>"  # ambiguous → bug
            "<p>זמן: 14:00</p>"  # not ambiguous (has colon)
            "</body></html>"
        )
        s = await browser_tools.browser_open(mgr, url=RTL_TEST_HTML, headless=True)
        sid = s["session_id"]
        rtl = await qa_tools.qa_rtl_audit(mgr, sid)
        cats = [f["category"] for f in rtl["findings"]]
        plural_count = cats.count("rtl_plural")
        date_count = cats.count("rtl_date_ambiguous")
        print(f"[W1.4] rtl_plural={plural_count}, rtl_date_ambiguous={date_count}")
        if plural_count < 2:
            fails.append(f"W1.4: expected ≥2 rtl_plural, got {plural_count}")
        if date_count < 1:
            fails.append(f"W1.4: expected ≥1 rtl_date_ambiguous, got {date_count}")
        if plural_count >= 2 and date_count >= 1:
            print(f"        ✓ both new categories fire on test HTML")
        await browser_tools.browser_close(mgr, sid)

        # ===================================================================
        # Wave 1.5 — git-friendly baselines (.meta.json)
        # ===================================================================
        s = await browser_tools.browser_open(
            mgr, url="data:text/html,<h1>baseline</h1>", headless=True,
        )
        sid = s["session_id"]
        with tempfile.TemporaryDirectory() as tmp:
            saved = await qa_tools.qa_baseline_save(
                mgr, sid, "meta_test", full_page=False, baselines_dir=tmp,
            )
            meta_p = Path(saved["meta_path"])
            if not meta_p.exists():
                fails.append("W1.5: .meta.json sidecar not created")
            else:
                meta = json.loads(meta_p.read_text(encoding="utf-8"))
                required = {"name", "url", "viewport", "sha256", "browser", "created_at"}
                missing = required - set(meta.keys())
                if missing:
                    fails.append(f"W1.5: meta missing keys: {missing}")
                else:
                    print(f"[W1.5] ✓ .meta.json with {len(meta)} fields, "
                          f"sha256={meta['sha256'][:10]}...")
        await browser_tools.browser_close(mgr, sid)

        # ===================================================================
        # Wave 1.6 — qa_responsive_audit
        # ===================================================================
        RESP_HTML = (
            "data:text/html;charset=utf-8,<!doctype html>"
            "<html lang='he' dir='rtl'><body>"
            "<h1>responsive test</h1>"
            "<p>1 פריטים</p>"
            "</body></html>"
        )
        s = await browser_tools.browser_open(mgr, url=RESP_HTML, headless=True)
        sid = s["session_id"]
        resp = await qa_tools.qa_responsive_audit(
            mgr, sid, breakpoints=[375, 1366], audits=["rtl"],
        )
        keys = sorted(resp["results"].keys())
        print(f"[W1.6] responsive results for breakpoints: {keys}")
        if "375" not in resp["results"] or "1366" not in resp["results"]:
            fails.append(f"W1.6: missing breakpoint results: {keys}")
        elif "summary" not in resp:
            fails.append(f"W1.6: missing summary")
        else:
            print(f"        ✓ summary: {resp['summary']}")
        await browser_tools.browser_close(mgr, sid)

        # ===================================================================
        # Wave 2 — qa_run_suite + reports + exit codes
        # ===================================================================
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            html_out = str(tmp_path / "report.html")
            junit_out = str(tmp_path / "junit.xml")
            json_out = str(tmp_path / "result.json")
            cfg = {
                "name": "test-suite",
                "browser": "chromium",
                "headless": True,
                "scenarios": [
                    {
                        "name": "fast-page",
                        "path": "data:text/html;charset=utf-8,<!doctype html><html lang='en'>"
                                "<head><title>Fast</title><meta name='description' content='x'>"
                                "</head><body><main><h1>OK</h1></main></body></html>",
                        "audits": ["seo", "perf"],
                        "thresholds": {
                            "seo": {"max_issues": 10},
                            "perf": {"min_score": 0},  # passes anything
                        },
                    },
                    {
                        "name": "broken-page",
                        "path": "data:text/html,<html><body>no h1, no title</body></html>",
                        "audits": ["seo"],
                        "thresholds": {"seo": {"max_issues": 0}},  # will fail
                    },
                ],
                "report": {"html": html_out, "junit": junit_out, "json": json_out},
            }
            cfg_path = tmp_path / "qa.config.json"
            cfg_path.write_text(json.dumps(cfg), encoding="utf-8")

            # Run async core directly (cli_run uses asyncio.run which conflicts
            # with our test's already-running loop — that's fine, the CLI itself
            # is meant to be invoked from sync entry).
            suite_result = await _suite.run_suite(cfg)
            _suite.emit_html_report(suite_result, html_out)
            _suite.emit_junit_xml(suite_result, junit_out)
            Path(json_out).write_text(
                json.dumps(suite_result, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
            exit_code = 0 if suite_result["summary"]["failed"] == 0 else 1
            print(f"[W2] suite exit code: {exit_code} (expected 1 — broken-page fails)")
            if exit_code != 1:
                fails.append(f"W2 exit_code: expected 1 for failing suite, got {exit_code}")
            if not Path(html_out).exists():
                fails.append("W2: HTML report not written")
            else:
                size = Path(html_out).stat().st_size
                content = Path(html_out).read_text(encoding="utf-8")
                if "fast-page" not in content or "broken-page" not in content:
                    fails.append("W2: HTML doesn't contain scenario names")
                elif "FAIL" not in content:
                    fails.append("W2: HTML doesn't show FAIL badge")
                else:
                    print(f"        ✓ HTML report ({size} bytes) contains both scenarios")
            if not Path(junit_out).exists():
                fails.append("W2: JUnit XML not written")
            else:
                # Parse and check structure
                tree = ET.parse(junit_out)
                root = tree.getroot()
                tests = root.attrib.get("tests")
                failures = root.attrib.get("failures")
                if tests != "2":
                    fails.append(f"W2: junit tests={tests}, expected 2")
                elif failures != "1":
                    fails.append(f"W2: junit failures={failures}, expected 1")
                else:
                    print(f"        ✓ JUnit XML: tests={tests}, failures={failures}")
            if not Path(json_out).exists():
                fails.append("W2: JSON report not written")
            else:
                data = json.loads(Path(json_out).read_text(encoding="utf-8"))
                if data["summary"]["passed"] != 1 or data["summary"]["failed"] != 1:
                    fails.append(f"W2: JSON summary off: {data['summary']}")
                else:
                    print(f"        ✓ JSON report: 1 passed / 1 failed")

    finally:
        await mgr.close_all()

    if fails:
        print("\n❌ FAILURES:")
        for f in fails:
            print(f"   - {f}")
        sys.exit(1)
    print("\n✅ ALL WAVE 1+2 FEATURES VERIFIED")


if __name__ == "__main__":
    asyncio.run(main())
