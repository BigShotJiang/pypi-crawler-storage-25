"""Unit tests for qa_mcp.tools.qa_tools pure helpers (no browser)."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from qa_mcp.tools.qa_tools import (
    _collect_selectors_from_findings,
    _detect_field_purpose,
    _group_interaction_effects,
    _interpret_ux_metrics,
    _prioritize_ux_audit,
    _resolve_baseline_dir,
    _safe_name,
    _sev_rank,
    _summarize_findings,
    _trim_for_detail,
    _ux_profile,
    _ux_viewport_delta,
    qa_baseline_list,
    qa_fix_from_findings,
)


# ----------------- _safe_name -----------------


def test_safe_name_collapses_unsafe():
    assert _safe_name("hello world!") == "hello_world"
    assert _safe_name("a/b\\c d") == "a_b_c_d"
    assert _safe_name("") == "default"
    assert _safe_name("***") == "default"
    assert len(_safe_name("x" * 200)) <= 80


# ----------------- _sev_rank -----------------


def test_sev_rank_ordering():
    assert _sev_rank("critical") < _sev_rank("high")
    assert _sev_rank("high") == _sev_rank("serious")
    assert _sev_rank("medium") == _sev_rank("moderate")
    assert _sev_rank("low") == _sev_rank("minor")
    assert _sev_rank(None) == _sev_rank("info") == 4
    assert _sev_rank("invalid") == 4


# ----------------- _summarize_findings -----------------


def test_summarize_findings_buckets_by_severity_and_category():
    out = _summarize_findings([
        {"severity": "high", "category": "rtl"},
        {"severity": "high", "category": "rtl"},
        {"severity": "low", "category": "a11y"},
        {"category": "no-sev"},
    ])
    assert out["total"] == 4
    assert out["by_severity"]["high"] == 2
    assert out["by_severity"]["info"] == 1  # missing severity → info
    assert out["by_category"]["rtl"] == 2
    assert out["by_category"]["no-sev"] == 1


def test_summarize_findings_empty():
    out = _summarize_findings([])
    assert out["total"] == 0


# ----------------- _trim_for_detail -----------------


def test_trim_for_detail_summary_drops_lists():
    result = {
        "summary": {"total": 10},
        "findings": list(range(20)),
        "items": ["a", "b"],
        "score": 80,
    }
    out = _trim_for_detail(result, "summary")
    assert "findings" not in out
    assert "items" not in out
    assert out["score"] == 80
    assert out["_truncated"]["fields"]["findings"] == 20


def test_trim_for_detail_samples_caps_lists():
    result = {"findings": list(range(20))}
    out = _trim_for_detail(result, "samples")
    assert len(out["findings"]) == 5
    assert out["_truncated"]["fields"]["findings"] == 20


def test_trim_for_detail_full_unchanged():
    result = {"findings": list(range(20))}
    out = _trim_for_detail(result, "full")
    assert out == result
    assert "_truncated" not in out


def test_trim_for_detail_unknown_level_becomes_samples():
    result = {"findings": list(range(20))}
    out = _trim_for_detail(result, "weird")
    assert len(out["findings"]) == 5


def test_trim_for_detail_non_dict_passthrough():
    assert _trim_for_detail("not a dict", "summary") == "not a dict"


# ----------------- _ux_profile -----------------


def test_ux_profile_known_personas():
    for p in ("general", "conversion", "mobile_first", "elderly_user", "dashboard"):
        prof = _ux_profile(p)
        assert "max_ctas" in prof
        assert "min_touch" in prof


def test_ux_profile_unknown_falls_back_to_general():
    assert _ux_profile("weird") == _ux_profile("general")
    assert _ux_profile("") == _ux_profile("general")


# ----------------- _interpret_ux_metrics -----------------


def test_interpret_ux_metrics_h1_missing_emits_high():
    out = _interpret_ux_metrics({"headings": {"h1_count": 0}})
    assert any(f["category"] == "heading_hierarchy" and f["severity"] == "high"
               for f in out["findings"])


def test_interpret_ux_metrics_multiple_h1_emits_medium():
    out = _interpret_ux_metrics({"headings": {"h1_count": 3}})
    assert any(f["category"] == "heading_hierarchy" and f["severity"] == "medium"
               for f in out["findings"])


def test_interpret_ux_metrics_no_cta_in_fold():
    out = _interpret_ux_metrics({"headings": {"h1_count": 1},
                                  "interactive": {"cta_in_fold": 0}})
    assert any(f["category"] == "cta_clarity" for f in out["findings"])


def test_interpret_ux_metrics_too_many_ctas():
    out = _interpret_ux_metrics({"headings": {"h1_count": 1},
                                  "interactive": {"cta_in_fold": 4}})
    assert any(f["category"] == "cta_clarity" and "Too many" in f["title"]
               for f in out["findings"])


def test_interpret_ux_metrics_small_touch_targets():
    out = _interpret_ux_metrics({
        "headings": {"h1_count": 1},
        "interactive": {"cta_in_fold": 1},
        "touch_targets": {"small_count": 15},
    })
    assert any(f["category"] == "touch_targets" and f["severity"] == "high"
               for f in out["findings"])


def test_interpret_ux_metrics_density_high():
    out = _interpret_ux_metrics({
        "headings": {"h1_count": 1},
        "interactive": {"cta_in_fold": 1},
        "density": {"chars_per_px2": 0.008},
    })
    assert any(f["category"] == "density" for f in out["findings"])


def test_interpret_ux_metrics_low_scores():
    out = _interpret_ux_metrics({
        "headings": {"h1_count": 1},
        "interactive": {"cta_in_fold": 1},
        "scores": {
            "hierarchy_score": 30,
            "cognitive_load_score": 65,
            "density_score": 40,
            "touch_target_score": 80,  # passing
        },
    })
    cats = {f["category"] for f in out["findings"]}
    assert "hierarchy" in cats
    assert "cognitive_load" in cats
    assert "density" in cats


def test_interpret_ux_metrics_recommendations_list_capped():
    big = {
        "headings": {"h1_count": 0},
        "interactive": {"cta_in_fold": 5},
        "touch_targets": {"small_count": 30},
        "typography": {"distinct_font_sizes": 99},
        "color": {"distinct_text_colors": 99},
        "kpi": {"candidates_in_fold": 99},
        "density": {"chars_per_px2": 0.05},
    }
    out = _interpret_ux_metrics(big)
    assert len(out["recommendations"]) <= 10
    assert all("priority" in r for r in out["recommendations"])


# ----------------- _detect_field_purpose -----------------


def test_detect_field_purpose_each_kind():
    cases = [
        ({"name": "email"}, "email"),
        ({"name": "password"}, "password"),
        ({"placeholder": "CVV / CVC"}, "credit_card_cvc"),
        ({"name": "exp_date"}, "credit_card_exp"),
        ({"name": "cardholder"}, "credit_card_name"),
        ({"placeholder": "Card number"}, "credit_card"),
        ({"name": "national_id"}, "israeli_id"),
        ({"name": "firstname"}, "first_name"),
        ({"name": "lastname"}, "last_name"),
        ({"name": "phone"}, "phone"),
        ({"id": "company-org"}, "company"),
        ({"id": "street_address"}, "address"),
        ({"name": "zip"}, "zip"),
        ({"placeholder": "City"}, "city"),
        ({"id": "country-select"}, "country"),
    ]
    for el, expected in cases:
        assert _detect_field_purpose(el) == expected, (el, expected)


def test_detect_field_purpose_none():
    # Use a string that has no keyword substrings (note: "completely" contains "tel"!)
    assert _detect_field_purpose({"name": "xyzqwerty"}) is None
    assert _detect_field_purpose({}) is None


def test_detect_field_purpose_hebrew():
    assert _detect_field_purpose({"placeholder": "אימייל"}) == "email"
    assert _detect_field_purpose({"name": "סיסמה"}) == "password"
    assert _detect_field_purpose({"placeholder": "תעודת זהות"}) == "israeli_id"


# ----------------- _group_interaction_effects -----------------


def test_group_interaction_effects_counts_and_sorts():
    items = [
        {"animationName": "fadeIn", "duration": "1s", "delay": "0s", "selector": ".a"},
        {"animationName": "fadeIn", "duration": "1s", "delay": "0s", "selector": ".b"},
        {"animationName": "spin", "duration": "2s", "delay": "0s", "selector": ".c"},
    ]
    out = _group_interaction_effects(items, ["animationName", "duration", "delay"])
    assert len(out) == 2
    assert out[0]["count"] == 2  # fadeIn first
    assert out[0]["selectors"] == [".a", ".b"]
    assert out[0]["signature"]["animationName"] == "fadeIn"


def test_group_interaction_effects_empty():
    assert _group_interaction_effects([], ["k"]) == []


# ----------------- _resolve_baseline_dir -----------------


def test_resolve_baseline_dir_explicit_path(tmp_path):
    target = tmp_path / "shots"
    out = _resolve_baseline_dir(str(target))
    assert out == target
    assert target.exists()


def test_resolve_baseline_dir_default_when_no_arg(monkeypatch):
    out = _resolve_baseline_dir(None)
    assert out.exists() or out.parent.exists()


def test_qa_baseline_list_empty_and_populated(tmp_path):
    out = qa_baseline_list(str(tmp_path))
    assert out["count"] == 0
    assert out["baselines"] == []

    # Drop two .png stubs
    (tmp_path / "alpha.png").write_bytes(b"\x89PNG\r\n\x1a\nstub")
    (tmp_path / "beta.png").write_bytes(b"\x89PNG\r\n\x1a\nstub")
    out2 = qa_baseline_list(str(tmp_path))
    assert out2["count"] == 2
    names = {b["name"] for b in out2["baselines"]}
    assert names == {"alpha", "beta"}


# ----------------- _ux_viewport_delta -----------------


def test_ux_viewport_delta_returns_empty_when_one_side_missing():
    assert _ux_viewport_delta(None, {"scores": {}}) == {}
    assert _ux_viewport_delta({"scores": {}}, None) == {}


def test_ux_viewport_delta_flags_regression():
    desktop = {
        "scores": {"hierarchy_score": 90, "cognitive_load_score": 80,
                    "density_score": 80, "touch_target_score": 95},
        "interactive": {"cta_in_fold": 1, "in_fold": 3},
        "touch_targets": {"small_count": 0},
        "density": {"chars_per_px2": 0.001},
    }
    mobile = {
        "scores": {"hierarchy_score": 70, "cognitive_load_score": 80,
                    "density_score": 80, "touch_target_score": 95},
        "interactive": {"cta_in_fold": 1, "in_fold": 3},
        "touch_targets": {"small_count": 8},
        "density": {"chars_per_px2": 0.002},
    }
    out = _ux_viewport_delta(desktop, mobile)
    assert out["summary"]["regressions"] >= 2
    regression_metrics = {r["metric"] for r in out["mobile_regressions"]}
    assert "hierarchy_score" in regression_metrics
    assert "small_touch_targets" in regression_metrics


# ----------------- _collect_selectors_from_findings -----------------


def test_collect_selectors_dedupes_and_limits():
    findings = [
        {"selector": ".a"},
        {"selector": ".a"},  # duplicate
        {"selector": ".b", "samples": [{"selector": ".c"}, {"selector": ".d"}]},
        {"samples": [{"selector": ".e"}, "non-dict"]},
    ]
    out = _collect_selectors_from_findings(findings, limit=3)
    assert out[:2] == [".a", ".b"]
    assert len(out) <= 3


def test_collect_selectors_empty_returns_empty():
    assert _collect_selectors_from_findings([]) == []


# ----------------- _prioritize_ux_audit -----------------


def test_prioritize_ux_audit_aggregates_signals():
    result = {
        "desktop": {
            "ux": {"findings": [
                {"severity": "high", "category": "ux", "title": "no CTA"}
            ]},
            "rtl": {"summary": {"by_severity": {"high": 3}}},
            "a11y": {"summary": {"by_impact": {"critical": 1}}},
            "perf": {"grades": {"lcp": "poor", "fcp": "good"}, "metrics": {}, "cls_attribution": []},
        },
        "mobile": {
            "ux": {"findings": [
                {"severity": "medium", "category": "ux", "title": "small tap"}
            ]},
            "rtl": {"summary": {"by_severity": {"high": 1}}},
        },
        "viewport_comparison": {
            "mobile_regressions": [{"metric": "hierarchy_score", "desktop": 80,
                                     "mobile": 60, "severity": "medium"}]
        },
    }
    out = _prioritize_ux_audit(result)
    assert len(out["top_findings"]) > 0
    # Critical/high findings should be in must_fix
    severities = {f["severity"] for f in out["must_fix"]}
    assert "high" in severities or "critical" in severities


# ----------------- qa_fix_from_findings -----------------


def test_qa_fix_from_findings_with_and_without_summary():
    findings = [
        {"category": "rtl_currency", "sample": "₪99", "selector": ".price"},
    ]
    out = qa_fix_from_findings(findings, summary=True)
    assert "suggestions" in out
    assert "summary" in out
    assert len(out["suggestions"]) == 1

    no_summary = qa_fix_from_findings(findings, summary=False)
    assert "suggestions" in no_summary
    assert "summary" not in no_summary
