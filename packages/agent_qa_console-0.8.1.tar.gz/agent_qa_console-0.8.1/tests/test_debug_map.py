"""Check source mapper core logic is importable and functional."""
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from qa_mcp.tools.source_mapper import (
    _extract_search_terms,
    _search_file,
    _SOURCE_EXTS,
    map_findings_to_source,
)


def test_extract_search_terms_hebrew_numbers():
    terms = _extract_search_terms("מחיר: ₪99")
    assert any("₪99" in t or "99" in t for t in terms), f"should find currency number: {terms}"


def test_extract_search_terms_english_in_hebrew():
    terms = _extract_search_terms("גרסה Alpha זמינה")
    assert any("Alpha" in t for t in terms), f"should find English word: {terms}"


def test_map_findings_returns_unmapped_when_no_repo():
    """map_findings_to_source should handle a non-existent repo cleanly."""
    result = map_findings_to_source(
        [{"severity": "medium", "category": "rtl_currency", "sample": "₪99"}],
        repo_path="/nonexistent/path/should/not/exist",
    )
    assert isinstance(result, dict)
