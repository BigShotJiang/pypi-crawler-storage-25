"""Unit tests for qa_mcp.github_issues — mocked urllib, no real network."""
import io
import json
import sys
import urllib.error
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from qa_mcp.github_issues import (
    DEFAULT_LABELS,
    GitHubClient,
    GitHubError,
    _existing_fingerprints,
    _fingerprint,
    _issue_body,
    _issue_title,
    _labels_for_finding,
    _slug,
    create_github_issues,
    create_github_issues_from_file,
)


def _suite():
    return {
        "name": "demo",
        "scenarios": [
            {
                "name": "home",
                "url": "https://example.co.il/checkout",
                "screenshot_path": "/tmp/home.png",
                "findings": [
                    {
                        "severity": "high",
                        "source": "rtl",
                        "category": "rtl_dir_missing",
                        "title": "Missing dir",
                        "selector": ".hero",
                        "evidence": "<html lang=\"he\">",
                        "impact": "BiDi broken",
                        "fix": "add dir=\"rtl\"",
                        "repro_steps": ["Open URL", "View source"],
                    },
                    {
                        "severity": "low",
                        "source": "a11y",
                        "category": "axe.color-contrast",
                        "title": "low contrast",
                    },
                ],
            },
            {
                "name": "about",
                "url": "https://example.co.il/about",
                "findings": [
                    {"severity": "critical", "source": "perf", "title": "Slow LCP"},
                    {"severity": "info", "source": "seo", "title": "Missing OG"},
                    {"severity": "medium", "source": "logs", "title": "Console error"},
                    {"severity": "medium", "source": "links", "title": "Empty href"},
                    {"severity": "medium", "source": "custom", "title": "weird"},
                ],
            },
        ],
    }


def test_slug_keeps_hebrew_and_strips_punctuation():
    assert _slug("Hello, World!") == "hello-world"
    assert _slug("עברית!") == "עברית"
    assert _slug("***") == ""


def test_fingerprint_stable_across_calls():
    s = _suite()
    sc = s["scenarios"][0]
    f = sc["findings"][0]
    assert _fingerprint(sc, f) == _fingerprint(sc, f)


def test_fingerprint_changes_with_selector():
    s = _suite()
    sc = s["scenarios"][0]
    f1 = dict(sc["findings"][0])
    f2 = dict(f1)
    f2["selector"] = ".different"
    assert _fingerprint(sc, f1) != _fingerprint(sc, f2)


def test_labels_for_finding_each_source_branch():
    for source, expected in [
        ("a11y", "accessibility"),
        ("rtl", "rtl"),
        ("perf", "performance"),
        ("seo", "seo"),
        ("logs", "logs"),
        ("links", "links"),
    ]:
        labels = _labels_for_finding({"source": source, "severity": "high"})
        assert "qa-mcp" in labels
        assert "bug" in labels
        assert "severity:high" in labels
        assert expected in labels


def test_labels_for_finding_unknown_source_uses_slug():
    labels = _labels_for_finding({"source": "WEIRD!", "severity": "low"})
    assert any(l.startswith("qa:") for l in labels)


def test_labels_for_finding_missing_source_falls_back():
    labels = _labels_for_finding({})
    assert "qa-mcp" in labels and "severity:info" in labels


def test_issue_title_includes_severity_and_source_and_truncates():
    t = _issue_title({"severity": "high", "source": "rtl", "title": "x" * 300})
    assert t.startswith("[HIGH][rtl]")
    assert len(t) <= 240


def test_issue_body_contains_all_sections():
    body = _issue_body(
        _suite(),
        _suite()["scenarios"][0],
        _suite()["scenarios"][0]["findings"][0],
        "abc1234",
    )
    assert "qa-mcp:fingerprint=abc1234" in body
    assert "## Evidence" in body
    assert "## Selector" in body
    assert "## Impact" in body
    assert "## Suggested fix" in body
    assert "## Steps to reproduce" in body
    assert "1. Open URL" in body
    assert "Screenshot:" in body


def test_issue_body_omits_selector_section_when_missing():
    s = _suite()
    sc = s["scenarios"][1]
    f = sc["findings"][0]  # no selector, no screenshot
    body = _issue_body(s, sc, f, "fp")
    assert "## Selector" not in body
    assert "Screenshot:" not in body


def test_existing_fingerprints_extracts_marker():
    issues = [
        {"body": "<!-- qa-mcp:fingerprint=aaaabbbb1111 --> stuff", "number": 1},
        {"body": "no marker", "number": 2},
        {"body": None, "number": 3},
    ]
    found = _existing_fingerprints(issues)
    assert "aaaabbbb1111" in found
    assert len(found) == 1


def test_dry_run_emits_planned_issues_without_calls():
    out = create_github_issues(_suite(), "owner/repo", dry_run=True)
    assert out["dry_run"] is True
    assert out["planned"] == 7
    assert all("fingerprint" in i and "title" in i and "body" in i for i in out["issues"])


def test_default_labels_table_has_known_keys():
    assert "qa-mcp" in DEFAULT_LABELS
    assert "severity:critical" in DEFAULT_LABELS


def test_missing_token_raises():
    # Ensure no env vars
    with patch.dict("os.environ", {}, clear=True):
        try:
            create_github_issues(_suite(), "o/r", dry_run=False)
        except GitHubError as e:
            assert "Missing GITHUB_TOKEN" in str(e)
        else:
            raise AssertionError("expected GitHubError")


# ----------------- Mocked HTTP layer -----------------


class _Resp:
    def __init__(self, status: int, data: bytes):
        self.status = status
        self._data = data

    def read(self):
        return self._data

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False


class FakeAPI:
    """Records all GitHub API requests, returns canned responses by route."""

    def __init__(self):
        self.calls: list[tuple[str, str, dict | None]] = []
        # label name → exists?
        self.existing_labels: set[str] = set()
        self.existing_issues: list[dict] = []
        self._issue_seq = 100
        # Allow tests to force a 404 for label GETs
        self.fail_label_get: bool = True  # default: never exist → POST will be made

    def __call__(self, req, timeout=30):
        method = req.get_method() if hasattr(req, "get_method") else req.method
        url = req.full_url
        body_raw = req.data.decode("utf-8") if req.data else None
        body = json.loads(body_raw) if body_raw else None
        self.calls.append((method, url, body))

        # Strip api host
        path = url.replace("https://api.github.com", "")

        if path.startswith("/repos/") and "/labels/" in path and method == "GET":
            if self.fail_label_get:
                raise urllib.error.HTTPError(url, 404, "Not Found", {}, io.BytesIO(b"{}"))
            return _Resp(200, b'{"name":"x","color":"cfd3d7"}')

        if path.startswith("/repos/") and path.endswith("/labels") and method == "POST":
            return _Resp(201, json.dumps(body).encode())

        if "/issues?" in path and method == "GET":
            return _Resp(200, json.dumps(self.existing_issues).encode())

        if path.endswith("/comments") and method == "POST":
            return _Resp(
                201,
                json.dumps({"html_url": "https://github.com/x/y/issues/1#c1"}).encode(),
            )

        if path.endswith("/issues") and method == "POST":
            self._issue_seq += 1
            return _Resp(
                201,
                json.dumps({
                    "html_url": f"https://github.com/x/y/issues/{self._issue_seq}",
                    "number": self._issue_seq,
                }).encode(),
            )

        return _Resp(200, b"{}")


def test_github_client_request_raises_on_http_error():
    client = GitHubClient(token="t")
    err = urllib.error.HTTPError(
        "https://api.github.com/x", 422, "Validation", {}, io.BytesIO(b"bad")
    )
    with patch("urllib.request.urlopen", side_effect=err):
        try:
            client.request("GET", "/x")
        except GitHubError as e:
            assert "422" in str(e)
            assert "bad" in str(e)
        else:
            raise AssertionError("expected GitHubError")


def test_github_client_ensure_label_creates_when_missing():
    client = GitHubClient(token="t")
    api = FakeAPI()
    with patch("urllib.request.urlopen", api):
        client.ensure_label("o/r", "qa-mcp", "7c3aed")
    methods = [c[0] for c in api.calls]
    assert methods == ["GET", "POST"]


def test_github_client_ensure_label_skips_create_when_present():
    client = GitHubClient(token="t")
    api = FakeAPI()
    api.fail_label_get = False
    with patch("urllib.request.urlopen", api):
        client.ensure_label("o/r", "qa-mcp", "7c3aed")
    methods = [c[0] for c in api.calls]
    assert methods == ["GET"]


def test_github_client_ensure_label_propagates_non_404():
    client = GitHubClient(token="t")
    err = urllib.error.HTTPError(
        "u", 500, "Server", {}, io.BytesIO(b"oops")
    )
    with patch("urllib.request.urlopen", side_effect=err):
        try:
            client.ensure_label("o/r", "qa-mcp", "7c3aed")
        except GitHubError:
            pass
        else:
            raise AssertionError("expected GitHubError")


def test_create_github_issues_full_flow_creates_and_skips_existing():
    api = FakeAPI()
    suite = _suite()
    # Pre-existing issue with fingerprint of first finding → should be skipped
    sc = suite["scenarios"][0]
    fp1 = _fingerprint(sc, sc["findings"][0])
    api.existing_issues = [{
        "number": 42,
        "html_url": "https://github.com/x/y/issues/42",
        "state": "open",
        "body": f"<!-- qa-mcp:fingerprint={fp1} -->",
    }]
    with patch("urllib.request.urlopen", api):
        out = create_github_issues(
            suite, "owner/repo", token="t", dry_run=False, comment_existing=True
        )
    assert out["planned"] == 7
    assert out["skipped_existing"] == 1
    assert out["created"] == 6
    assert out["commented_existing"] == 1


def test_create_github_issues_from_file_round_trip(tmp_path):
    js = tmp_path / "qa-result.json"
    js.write_text(json.dumps(_suite(), ensure_ascii=False), encoding="utf-8")
    out = create_github_issues_from_file(str(js), "o/r", dry_run=True)
    assert out["dry_run"] is True
    assert out["planned"] == 7


def test_github_client_request_empty_body_returns_none():
    client = GitHubClient(token="t", api_url="https://api.github.com/")
    with patch("urllib.request.urlopen", return_value=_Resp(204, b"")):
        assert client.request("DELETE", "/x") is None
