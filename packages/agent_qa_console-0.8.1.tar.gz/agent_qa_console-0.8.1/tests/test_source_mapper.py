"""Realistic test of the full pipeline: RTL findings → fixes → source mapping."""
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from qa_mcp.tools.qa_tools import qa_fix_from_findings, qa_map_with_fixes

# Simulate real RTL audit findings from a Hebrew Next.js project.
# These samples come from the qa-mcp repo's own source code.
findings = [
    # Real text from our source: "35 browser primitives" appears in README/server.py
    {"severity":"high","category":"rtl_digits",
     "sample":"35 browser primitives and QA audits",
     "selector":"p"},
    # Real text: "32 → 35" from CHANGELOG  
    {"severity":"high","category":"rtl_digits",
     "sample":"32 → 35",
     "selector":"li"},
    # Currency example from our README
    {"severity":"medium","category":"rtl_currency",
     "sample":"₪99",
     "selector":"code"},
    # Digit in Hebrew context (from test fixtures)
    {"severity":"high","category":"rtl_digits",
     "sample":"יש 3 פריטים",
     "selector":"span"},
]

repo = str(Path(__file__).parent.parent.resolve())

# Step 1: Generate fixes
fixes_result = qa_fix_from_findings(findings)
fixes = fixes_result["suggestions"]
print("=== FIXES ===")
for f in fixes:
    print(f"  [{f['category']}] {f['fix_type']}: {f['before'][:50]} → {f['after'][:50]} | auto={not f['requires_review']} | confidence={f['confidence']}")

# Step 2: Map to source with fixes
print("\n=== SOURCE MAP ===")
result = qa_map_with_fixes(findings, fixes, repo)
print(f"  mapped: {result['mapped']}/{result['total_findings']} ({result['map_rate']})")
print(f"  auto_patches: {len(result['auto_patches'])}")

# Step 3: Show each mapped result
for r in result["results"]:
    f = r["finding"]
    mapped = len(r["source_matches"])
    status = "✓" if mapped > 0 else "✗"
    print(f"\n  {status} [{f['category']}] {f['sample'][:60]}")
    for m in r["source_matches"][:2]:
        rel = m["file"].replace(repo, "").lstrip("\\").lstrip("/")
        print(f"      └─ {rel}:{m['line']} ({m['match_type']}, {m['confidence']})")
    if r.get("diff"):
        print(f"      └─ DIFF READY")
        for line in r["diff"].strip().split("\n")[:3]:
            print(f"         {line}")

# Step 4: Show auto patches
print("\n=== AUTO PATCHES (ready for PR) ===")
for p in result["auto_patches"]:
    rel = p["file"].replace(repo, "").lstrip("\\").lstrip("/")
    print(f"  📄 {rel}:{p['line']}")
    print(f"     {p['before'][:40]} → {p['after'][:40]}")
    print(f"     confidence: {p['confidence']}, fix_type: {p['fix_type']}")
    for line in p["diff"].split("\n")[:3]:
        print(f"     {line}")
