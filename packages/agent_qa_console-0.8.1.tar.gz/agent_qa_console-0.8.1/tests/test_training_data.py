"""Unit tests for qa_mcp.training_data — pure helpers + filesystem APIs."""
import hashlib
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from qa_mcp import training_data as td


# ----------------- env helpers -----------------


def test_is_enabled_reads_env(monkeypatch):
    monkeypatch.delenv("QA_MCP_TRAINING_DATA_DIR", raising=False)
    assert td.is_enabled() is False
    monkeypatch.setenv("QA_MCP_TRAINING_DATA_DIR", "/tmp/x")
    assert td.is_enabled() is True


def test_root_returns_none_without_env(monkeypatch):
    monkeypatch.delenv("QA_MCP_TRAINING_DATA_DIR", raising=False)
    assert td._root() is None


def test_root_creates_dir(monkeypatch, tmp_path):
    target = tmp_path / "data"
    monkeypatch.setenv("QA_MCP_TRAINING_DATA_DIR", str(target))
    out = td._root()
    assert out == target
    assert target.exists()


def test_safe_host_strips_unsafe_chars():
    assert td._safe_host("https://example.com/path") == "example.com"
    assert td._safe_host("https://אתר.co.il") == "אתר.co.il" or td._safe_host("https://אתר.co.il")
    assert td._safe_host("") == "unknown"
    assert td._safe_host("not-a-url") == "unknown" or len(td._safe_host("not-a-url")) > 0


def test_run_dir_for_creates_and_caches(monkeypatch, tmp_path):
    monkeypatch.setenv("QA_MCP_TRAINING_DATA_DIR", str(tmp_path))
    # Clear cache so test is isolated
    td._RUN_DIRS.clear()
    f1 = td._run_dir_for("sess-1", "https://example.com/")
    f2 = td._run_dir_for("sess-1", "https://example.com/")
    assert f1 == f2  # cached on same key
    assert f1.exists()
    # Different URL → different cache entry
    f3 = td._run_dir_for("sess-1", "https://other.com/")
    assert f3 != f1
    assert (str(tmp_path) in str(f3))


def test_run_dir_for_returns_none_when_disabled(monkeypatch):
    monkeypatch.delenv("QA_MCP_TRAINING_DATA_DIR", raising=False)
    td._RUN_DIRS.clear()
    assert td._run_dir_for("s", "https://x.com") is None


# ----------------- PII redaction -----------------


def test_redact_email_phone_id():
    text = "Email: user.name+tag@example.co.il, phone 052-123-4567, id 123456789"
    out = td._redact(text)
    assert "[REDACTED_EMAIL]" in out
    assert "[REDACTED_PHONE]" in out
    assert "[REDACTED_ID]" in out
    assert "user.name+tag" not in out
    assert "123-4567" not in out
    assert "123456789" not in out


def test_redact_no_pii_unchanged():
    text = "Hello world בלי PII"
    assert td._redact(text) == text


# ----------------- _iter_runs, _read_meta -----------------


def _seed_run(root: Path, day="2026-01-01", host="example.com_120000",
              html: str = "<html>x</html>", findings: dict = None,
              with_meta: bool = True):
    run = root / day / host
    run.mkdir(parents=True, exist_ok=True)
    (run / "page.html").write_text(html, encoding="utf-8")
    if with_meta:
        meta = {
            "url": f"https://{host.split('_')[0]}/",
            "lang": "he",
            "html_sha256": hashlib.sha256(html.encode("utf-8")).hexdigest(),
            "html_bytes": len(html.encode("utf-8")),
            "captured_at": f"{day}T12:00:00",
        }
        (run / "meta.json").write_text(json.dumps(meta), encoding="utf-8")
    findings = findings or {"rtl": 2, "perf": 0}
    for audit, total in findings.items():
        (run / f"{audit}.json").write_text(
            json.dumps({"summary": {"total": total}, "findings": []}),
            encoding="utf-8",
        )
    return run


def test_iter_runs_skips_empty_dirs(tmp_path):
    root = tmp_path / "data"
    root.mkdir()
    # day with one valid run + one empty run + a stray file
    _seed_run(root)
    (root / "2026-01-01" / "empty-folder").mkdir(parents=True, exist_ok=True)
    (root / "stray-file.txt").write_text("nope", encoding="utf-8")
    runs = list(td._iter_runs(root))
    assert len(runs) == 1


def test_iter_runs_empty_dir():
    out = list(td._iter_runs(Path("does-not-exist-xyz")))
    assert out == []


def test_read_meta_handles_missing_and_invalid(tmp_path):
    assert td._read_meta(tmp_path) == {}
    bad = tmp_path / "meta.json"
    bad.write_text("not json", encoding="utf-8")
    assert td._read_meta(tmp_path) == {}
    bad.write_text(json.dumps({"k": 1}), encoding="utf-8")
    assert td._read_meta(tmp_path) == {"k": 1}


def test_hash_text_stable():
    assert td._hash_text("x") == td._hash_text("x")
    assert td._hash_text("x") != td._hash_text("y")


# ----------------- export_jsonl -----------------


def test_export_jsonl_messages_format(tmp_path):
    root = tmp_path / "data"
    _seed_run(root, host="a.com_120000", html="<html>A</html>", findings={"rtl": 1})
    out = tmp_path / "export.jsonl"
    res = td.export_jsonl(str(root), str(out))
    assert res["examples_written"] == 1
    assert res["format"] == "messages"
    line = out.read_text(encoding="utf-8").strip()
    rec = json.loads(line)
    assert rec["messages"][0]["role"] == "system"
    assert rec["task"] == "rtl"


def test_export_jsonl_prompt_completion_format_and_task_filter(tmp_path):
    root = tmp_path / "data"
    _seed_run(root, host="a.com_120000", findings={"rtl": 1, "perf": 0})
    out = tmp_path / "out.jsonl"
    res = td.export_jsonl(str(root), str(out), task="rtl",
                          output_format="prompt_completion")
    assert res["examples_written"] == 1
    rec = json.loads(out.read_text(encoding="utf-8").strip().splitlines()[0])
    assert "prompt" in rec and "completion" in rec


def test_export_jsonl_dedupes_identical_runs(tmp_path):
    root = tmp_path / "data"
    _seed_run(root, day="2026-01-01", host="a.com_120000", html="<html>SAME</html>",
              findings={"rtl": 1})
    _seed_run(root, day="2026-01-02", host="a.com_120000", html="<html>SAME</html>",
              findings={"rtl": 1})
    out = tmp_path / "x.jsonl"
    res = td.export_jsonl(str(root), str(out))
    # Both runs have rtl=1 — second is a duplicate
    assert res["skipped_duplicates"] >= 1
    assert res["examples_written"] == 1


def test_export_jsonl_trims_html(tmp_path):
    root = tmp_path / "data"
    big_html = "<html>" + "x" * 1000 + "</html>"
    _seed_run(root, html=big_html, findings={"rtl": 1})
    out = tmp_path / "trim.jsonl"
    td.export_jsonl(str(root), str(out), max_html_chars=50)
    rec = json.loads(out.read_text(encoding="utf-8").strip().splitlines()[0])
    user_msg = rec["messages"][1]["content"]
    # HTML is trimmed
    assert "x" * 50 not in user_msg or len(user_msg) < 1500


def test_export_jsonl_skips_runs_without_html(tmp_path):
    root = tmp_path / "data"
    # Create a run with audit but no page.html
    run = root / "2026-01-01" / "host_120000"
    run.mkdir(parents=True)
    (run / "rtl.json").write_text("{}", encoding="utf-8")
    out = tmp_path / "x.jsonl"
    res = td.export_jsonl(str(root), str(out))
    assert res["examples_written"] == 0
    assert res["skipped_other"] >= 1


def test_export_jsonl_handles_corrupt_audit_json(tmp_path):
    root = tmp_path / "data"
    _seed_run(root, findings={"rtl": 1})
    # Corrupt the audit file
    run = next(td._iter_runs(root))
    (run / "rtl.json").write_text("not json", encoding="utf-8")
    out = tmp_path / "x.jsonl"
    res = td.export_jsonl(str(root), str(out))
    assert res["skipped_other"] >= 1


# ----------------- find_diffs -----------------


def test_find_diffs_returns_changed_urls(tmp_path):
    root = tmp_path / "data"
    # Two scans of same URL with different HTML and different findings count
    _seed_run(root, day="2026-01-01", host="example.com_120000",
              html="<html>v1</html>", findings={"rtl": 5})
    _seed_run(root, day="2026-01-02", host="example.com_130000",
              html="<html>v2-different</html>", findings={"rtl": 2})

    res = td.find_diffs(str(root))
    assert res["total_urls_scanned_twice"] == 1
    assert res["total_with_changes"] == 1
    change = res["urls_with_changes"][0]
    assert "rtl" in change["delta"]
    assert change["delta"]["rtl"]["before"] == 5
    assert change["delta"]["rtl"]["after"] == 2
    assert change["delta"]["rtl"]["change"] == -3


def test_find_diffs_ignores_unchanged_html(tmp_path):
    root = tmp_path / "data"
    _seed_run(root, day="2026-01-01", host="example.com_120000",
              html="<html>same</html>", findings={"rtl": 1})
    _seed_run(root, day="2026-01-02", host="example.com_130000",
              html="<html>same</html>", findings={"rtl": 1})
    res = td.find_diffs(str(root))
    assert res["total_with_changes"] == 0


def test_find_diffs_handles_empty_dir(tmp_path):
    res = td.find_diffs(str(tmp_path))
    assert res["total_urls_scanned_twice"] == 0
    assert res["urls_with_changes"] == []


# ----------------- stats -----------------


def test_stats_aggregates_runs(tmp_path):
    root = tmp_path / "data"
    _seed_run(root, day="2026-01-01", host="example.com_120000",
              html="<html>A</html>", findings={"rtl": 3, "perf": 0})
    _seed_run(root, day="2026-01-01", host="other.com_120000",
              html="<html>B</html>", findings={"a11y": 5})
    out = td.stats(str(root))
    assert out["runs"] == 2
    assert out["unique_hosts"] == 2
    assert out["unique_urls"] == 2
    assert out["unique_html_pages"] == 2
    assert out["by_task"]["rtl"] == 1
    assert out["by_task"]["a11y"] == 1
    assert out["total_findings"] == 8  # 3+0+5
    assert out["by_lang"]["he"] == 2
    assert out["avg_html_bytes"] > 0
    assert out["ready_for_training"] is False


def test_stats_empty_dir(tmp_path):
    out = td.stats(str(tmp_path))
    assert out["runs"] == 0
    assert out["unique_hosts"] == 0
