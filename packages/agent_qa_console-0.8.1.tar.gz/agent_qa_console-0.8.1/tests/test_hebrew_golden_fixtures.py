"""Extended Hebrew golden fixtures — ecommerce, dashboard, mixed LTR, mobile."""
import asyncio
import sys
from pathlib import Path
from urllib.parse import quote

import pytest

pytestmark = pytest.mark.asyncio(loop_scope="function")

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))
from qa_mcp.browser import SessionManager
from qa_mcp.tools import browser_tools, qa_tools


def data_url(html: str) -> str:
    return "data:text/html;charset=utf-8," + quote(html)


ECOMMERCE_HEBREW = """<!doctype html>
<html lang="he" dir="rtl"><body>
  <h1>חנות בגדים</h1>
  <p class="price-free">משלוח חינם בהזמנה מעל 199 ₪</p>
  <p class="price">₪79</p>
  <p class="inventory">1 פריטים נותרו</p>
  <button class="add-to-cart">Add to Cart →</button>
  <p class="sku">SKU: AB-1234</p>
  <p class="delivery">משלוח תוך 3-5 ימי עסקים</p>
  <p class="sale">מבצע! 50% הנחה</p>
</body></html>"""

DASHBOARD_HEBREW = """<!doctype html>
<html lang="he" dir="rtl"><body>
  <h1>לוח בקרה</h1>
  <p class="stat">הקלטות החודש: 42</p>
  <p class="stat">דקות שמיעה: 279.8</p>
  <p class="stat">זמן ממוצע: 01:23</p>
  <p class="stat">שפות: 6</p>
  <p class="stat">תוכנית 2 פעילה</p>
</body></html>"""

MIXED_LTR_HEBREW = """<!doctype html>
<html lang="he" dir="rtl"><body>
  <h1>הגדרות חשבון</h1>
  <p>גרסה v1.2.3 — שוחרר בתאריך 2026-04-03</p>
  <p>ID: ABC-12345 · WhatsApp: 050-1234567</p>
  <p>האימייל שלך: user@company.co.il</p>
  <p>מחיר: 99 ₪ לחודש</p>
  <p>הבא ← · הקודם</p>
</body></html>"""

MOBILE_OVERFLOW_HEBREW = """<!doctype html>
<html lang="he" dir="rtl"><body style="width:375px">
  <h1>שלום</h1>
  <p style="white-space:nowrap;overflow:hidden;max-width:200px">
    טקסט עברי ארוך מאוד שאמור לגלוש בקונטיינר צר במיוחד במובייל
  </p>
</body></html>"""


async def _audit(html: str, **kwargs):
    mgr = SessionManager()
    try:
        s = await browser_tools.browser_open(mgr, url=data_url(html), headless=True, locale="he-IL", timezone="Asia/Jerusalem")
        return await qa_tools.qa_rtl_audit(mgr, s["session_id"], detail="full", **kwargs)
    finally:
        await mgr.close_all()


async def test_ecommerce_catches_plural_but_allows_israeli_currency_styles():
    result = await _audit(ECOMMERCE_HEBREW)
    cats = {f["category"] for f in result["findings"]}
    assert "rtl_currency" not in cats, f"₪79 is common Israeli price styling and should not be a default bug: {cats}"
    assert "rtl_plural" in cats, f"should catch 1 פריטים: {cats}"
    assert result["summary"]["client_safe_total"] >= 1, f"expected plural client_safe: {result['summary']}"


async def test_currency_position_can_be_strict_style_rule():
    result = await _audit(ECOMMERCE_HEBREW, strict_currency_position=True)
    currency_findings = [f for f in result["findings"] if f["category"] == "rtl_currency"]
    assert all("₪79" in f["sample"] for f in currency_findings), "strict mode should flag only symbol-first price"
    assert all(not f["client_safe"] for f in currency_findings), "currency style is review-only, not a deterministic Hebrew bug"


async def test_dashboard_numbers_are_clean():
    result = await _audit(DASHBOARD_HEBREW)
    # Dashboard stat numbers in Hebrew context are real BiDi concerns,
    # but should be review_required (low confidence), not client-safe.
    assert result["summary"]["review_required_total"] >= 3,\
        f"Dashboard mixed BiDi should be in review queue: {result['summary']}"
    # Time strings like "01:23" should be smart-ignored
    time_findings = [f for f in result["findings"] if "01:23" in f.get("sample","")]
    assert len(time_findings) == 0, f"Time strings should be smart-ignored: {time_findings}"
    # Plural issue "2 פעילה" is a real bug and should be client-safe
    plural = [f for f in result["findings"] if f["category"] == "rtl_plural"]
    assert len(plural) >= 1, f"Plural bug '2 פעילה' should be detected: {plural}"
    assert plural[0]["client_safe"], f"Plural issue should be client-safe: {plural[0]}"


async def test_mixed_ltr_hebrew_allows_version_and_id():
    result = await _audit(MIXED_LTR_HEBREW)
    # v1.2.3, 050-1234567 (phone), ID: ABC-12345 should be smart-ignored
    # Correct currency: 99 ₪ should be clean
    # ← is correct RTL arrow — should be clean
    # user@company.co.il natural email — clean
    cats = {f["category"] for f in result["findings"]}
    assert "rtl_currency" not in cats, f"Correct ₪ should be clean: {cats}"
    assert "rtl_arrow_direction" not in cats, f"← is correct RTL: {cats}"
    # At most 1 finding (latin_mixed for "user@company.co.il" in Hebrew, if it fires)
    assert result["summary"]["total"] <= 2, f"Too noisy on clean mixed content: {result['summary']}"
    # ID: ABC-12345 should not trigger rtl_digits thanks to ID/SKU smart-ignore
    id_findings = [f for f in result["findings"] if "ABC-12345" in f.get("sample","") and f["category"] == "rtl_digits"]
    assert len(id_findings) == 0, f"ID strings should be smart-ignored: {id_findings}"


async def test_mobile_overflow_detected():
    result = await _audit(MOBILE_OVERFLOW_HEBREW)
    overflow = [f for f in result["findings"] if f["category"] == "rtl_text_overflow"]
    # May or may not fire on inline data: URL — at minimum, category exists as code path
    assert isinstance(overflow, list), "rtl_text_overflow category should exist"
