"""VoiceBox QA: findings → fixes."""
import sys, json
sys.path.insert(0, "src")
from qa_mcp.tools.qa_tools import qa_fix_from_findings

findings = [
    {"severity":"high","category":"rtl_digits","sample":"279.8 דקות","selector":"div span"},
    {"severity":"high","category":"rtl_digits","sample":"דובר 1 · 00:12","selector":"div span"},
    {"severity":"high","category":"rtl_digits","sample":"דובר 2 · 01:03","selector":"div span"},
    {"severity":"high","category":"rtl_digits","sample":"דובר 1 · 01:18","selector":"div span"},
    {"severity":"high","category":"rtl_digits","sample":"12 הקלטות","selector":"div div"},
    {"severity":"high","category":"rtl_digits","sample":"8 שעות","selector":"div"},
    {"severity":"high","category":"rtl_digits","sample":"6 שפות","selector":"div"},
    {"severity":"medium","category":"rtl_currency","sample":"₪39","selector":"span"},
]

result = qa_fix_from_findings(findings)
print("=== FIX SUMMARY ===")
print(json.dumps(result["summary"], indent=2, ensure_ascii=False))

print("\n=== FIXES ===")
for s in result["suggestions"]:
    auto = "AUTO" if not s["requires_review"] else "REVIEW"
    print(f"  [{auto}] {s['fix_type']}: \"{s['before'][:60]}\" → \"{s['after'][:60]}\" ({s['confidence']})")
