"""Unit tests for qa_mcp.tools.component_extractor — pure helpers only.

The async qa_extract_elements needs a Playwright page so it's left for
integration tests; the classifier and CSS→Tailwind logic is the bulk
of the file in pure Python.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from qa_mcp.tools.component_extractor import (
    _classify_element,
    diff_elements,
    element_to_tailwind,
    styles_to_tailwind,
)


# ----------------- _classify_element -----------------


def test_classify_element_buttons_by_class():
    assert _classify_element("a", "primary-button", "Get Started", "") == "button"
    assert _classify_element("button", "btn", "Click", "") == "button"


def test_classify_element_nav_card_hero_form_footer():
    assert _classify_element("div", "navbar", "", "") == "nav"
    assert _classify_element("div", "feature-card", "", "") == "card"
    assert _classify_element("section", "hero", "", "") == "hero"
    assert _classify_element("form", "contact-form", "", "") == "form"
    assert _classify_element("footer", "", "", "") == "footer"


def test_classify_element_falls_back_to_button_for_short_anchors():
    # tag=a, text<50, no matching class → button fallback
    assert _classify_element("a", "", "Sign in", "") == "button"


def test_classify_element_returns_tag_when_no_match():
    assert _classify_element("span", "", "", "") == "span"


# ----------------- diff_elements -----------------


def test_diff_elements_full_match():
    a = {"type": "button", "text": "X", "styles": {"color": "red", "padding": "8px"}}
    b = {"type": "button", "text": "Y", "styles": {"color": "red", "padding": "8px"}}
    out = diff_elements(a, b)
    assert out["identical_properties"] == 2
    assert out["different_properties"] == 0
    assert out["similarity"] == 1.0
    assert out["diffs"] == []


def test_diff_elements_partial_diff():
    a = {"type": "card", "text": "A", "styles": {"color": "red", "padding": "8px"}}
    b = {"type": "card", "text": "B", "styles": {"color": "blue", "padding": "8px", "margin": "4px"}}
    out = diff_elements(a, b)
    assert out["identical_properties"] == 1
    assert out["different_properties"] == 2
    diff_props = {d["property"] for d in out["diffs"]}
    assert diff_props == {"color", "margin"}


def test_diff_elements_empty_styles():
    out = diff_elements({"type": "x", "styles": {}}, {"type": "x", "styles": {}})
    assert out["identical_properties"] == 0
    assert out["similarity"] == 0.0  # max(0,1)=1, 0/1=0


# ----------------- styles_to_tailwind: text scale -----------------


def test_styles_to_tailwind_text_size_buckets():
    assert "text-base" in styles_to_tailwind({"fontSize": "16px"})
    assert "text-xl" in styles_to_tailwind({"fontSize": "20px"})
    assert "text-3xl" in styles_to_tailwind({"fontSize": "30px"})
    assert "text-7xl" in styles_to_tailwind({"fontSize": "72px"})
    # Below table → fallback arbitrary value
    out = styles_to_tailwind({"fontSize": "9px"})
    assert any("text-[9px]" in c for c in out)


def test_styles_to_tailwind_font_weight():
    assert "font-bold" in styles_to_tailwind({"fontWeight": "700"})
    assert "font-semibold" in styles_to_tailwind({"fontWeight": "600"})
    # Unknown numeric → default normal
    assert "font-normal" in styles_to_tailwind({"fontWeight": "abc"})


def test_styles_to_tailwind_font_family_known_and_serif():
    out_inter = styles_to_tailwind({"fontFamily": "Inter, sans-serif"})
    assert "font-sans" in out_inter
    out_serif = styles_to_tailwind({"fontFamily": "Merriweather Serif, Georgia"})
    assert "font-serif" in out_serif
    out_mono = styles_to_tailwind({"fontFamily": "JetBrains Mono, Consolas"})
    assert "font-mono" in out_mono


def test_styles_to_tailwind_letter_spacing_buckets():
    assert "tracking-tighter" in styles_to_tailwind({"letterSpacing": "-2px"})
    assert "tracking-tight" in styles_to_tailwind({"letterSpacing": "-0.5px"})
    assert "tracking-wider" in styles_to_tailwind({"letterSpacing": "1.2px"})
    assert "tracking-widest" in styles_to_tailwind({"letterSpacing": "2.5px"})


def test_styles_to_tailwind_line_height_ratios():
    out = styles_to_tailwind({"fontSize": "16px", "lineHeight": "16px"})
    assert "leading-none" in out
    out2 = styles_to_tailwind({"fontSize": "16px", "lineHeight": "32px"})
    assert "leading-loose" in out2


def test_styles_to_tailwind_text_align_and_transform():
    assert "text-center" in styles_to_tailwind({"textAlign": "center"})
    assert "text-end" in styles_to_tailwind({"textAlign": "right"})
    assert "text-start" in styles_to_tailwind({"textAlign": "start"})
    assert "text-justify" in styles_to_tailwind({"textAlign": "justify"})
    assert "uppercase" in styles_to_tailwind({"textTransform": "uppercase"})
    assert "capitalize" in styles_to_tailwind({"textTransform": "capitalize"})


def test_styles_to_tailwind_border_radius_buckets():
    assert "rounded-full" in styles_to_tailwind({"borderRadius": "9999px"})
    assert "rounded-3xl" in styles_to_tailwind({"borderRadius": "30px"})
    assert "rounded-xl" in styles_to_tailwind({"borderRadius": "12px"})
    assert "rounded-md" in styles_to_tailwind({"borderRadius": "6px"})
    assert "rounded-sm" in styles_to_tailwind({"borderRadius": "2px"})


def test_styles_to_tailwind_padding_shorthands():
    assert any(c.startswith("p-") for c in styles_to_tailwind({"padding": "16px"}))
    out2 = styles_to_tailwind({"padding": "16px 24px"})
    assert any(c.startswith("py-") for c in out2)
    assert any(c.startswith("px-") for c in out2)
    # Single-value with non-px (parses 0)
    out_bad = styles_to_tailwind({"padding": "1em"})
    assert isinstance(out_bad, list)


def test_styles_to_tailwind_margin_shorthand():
    out = styles_to_tailwind({"margin": "16px"})
    assert any(c.startswith("m-") for c in out)
    # margin: 0px is skipped
    assert styles_to_tailwind({"margin": "0px"}) == []


def test_styles_to_tailwind_flex_layout_combos():
    out = styles_to_tailwind({
        "display": "flex",
        "flexDirection": "column",
        "justifyContent": "center",
        "alignItems": "center",
        "gap": "16px",
    })
    assert "flex" in out
    assert "flex-col" in out
    assert "justify-center" in out
    assert "items-center" in out
    assert any(c.startswith("gap-") for c in out)


def test_styles_to_tailwind_flex_row_reverse_and_space_between():
    out = styles_to_tailwind({
        "display": "flex",
        "flexDirection": "row-reverse",
        "justifyContent": "space-between",
    })
    assert "flex-row-reverse" in out
    assert "justify-between" in out


def test_styles_to_tailwind_grid_with_repeat():
    out = styles_to_tailwind({"display": "grid", "gridTemplateColumns": "repeat(3, 1fr)"})
    assert "grid" in out
    assert "grid-cols-3" in out


def test_styles_to_tailwind_inline_flex_and_inline_block():
    assert "inline-flex" in styles_to_tailwind({"display": "inline-flex"})
    assert "inline-block" in styles_to_tailwind({"display": "inline-block"})


def test_styles_to_tailwind_cursor_pointer_events_overflow_select():
    out = styles_to_tailwind({
        "cursor": "pointer",
        "pointerEvents": "none",
        "overflow": "hidden",
        "userSelect": "none",
        "whiteSpace": "nowrap",
    })
    assert "cursor-pointer" in out
    assert "pointer-events-none" in out
    assert "overflow-hidden" in out
    assert "select-none" in out
    assert "whitespace-nowrap" in out


def test_styles_to_tailwind_border_widths_and_backdrop():
    out = styles_to_tailwind({"border": "1px solid #000"})
    assert "border" in out
    out2 = styles_to_tailwind({"border": "2px solid #000"})
    assert "border-2" in out2
    out_bd = styles_to_tailwind({"backdropFilter": "blur(8px)"})
    assert "backdrop-blur" in out_bd


def test_styles_to_tailwind_height_and_width_arbitrary():
    out = styles_to_tailwind({"width": "200px", "height": "48px"})
    assert any(c.startswith("w-[") for c in out)
    assert any(c.startswith("h-[") for c in out)


def test_styles_to_tailwind_empty_styles_returns_empty():
    assert styles_to_tailwind({}) == []


# ----------------- element_to_tailwind -----------------


def test_element_to_tailwind_returns_expected_keys():
    el = {
        "type": "button",
        "tag": "button",
        "text": "Click me",
        "styles": {"backgroundColor": "rgb(0,0,0)", "fontSize": "16px"},
        "boundingBox": {"x": 10, "y": 20, "width": 100, "height": 40},
    }
    out = element_to_tailwind(el)
    assert out["type"] == "button"
    assert out["tag"] == "button"
    assert "tailwind_classes" in out
    assert out["raw_css"]["backgroundColor"] == "rgb(0,0,0)"
    assert out["boundingBox"] == el["boundingBox"]
    # text truncated to 100 chars
    long = element_to_tailwind({"text": "x" * 300, "styles": {}})
    assert len(long["text"]) == 100
