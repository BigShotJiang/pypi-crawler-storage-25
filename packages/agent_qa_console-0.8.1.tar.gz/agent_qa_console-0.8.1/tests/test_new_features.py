"""Smoke test the new features: viewport, waits, baseline, SEO, smart fill."""
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from qa_mcp.browser import SessionManager
from qa_mcp.tools import browser_tools, qa_tools


# Test page with form, headings, meta tags
TEST_HTML = (
    "data:text/html;charset=utf-8,<!doctype html>"
    "<html lang='he' dir='rtl'><head>"
    "<title>Test Page</title>"
    "<meta name='description' content='בדיקה'>"
    "<meta property='og:title' content='Test'>"
    "<link rel='canonical' href='https://example.com'>"
    "</head><body>"
    "<h1>שלום</h1>"
    "<form>"
    "  <input name='email' type='email' placeholder='אימייל'>"
    "  <input name='password' type='password' placeholder='סיסמה'>"
    "  <input name='full_name' placeholder='שם מלא'>"
    "  <button type='submit'>הרשם</button>"
    "</form>"
    "<img src='https://example.com/x.jpg'>"
    "</body></html>"
)


async def main():
    mgr = SessionManager()
    fails = []
    try:
        # Open
        s = await browser_tools.browser_open(mgr, url=TEST_HTML, headless=True)
        sid = s["session_id"]

        # 1. Viewport switch
        vp = await browser_tools.browser_set_viewport(mgr, sid, device="iphone-13")
        assert vp["ok"] and vp["viewport"]["width"] == 390, f"viewport wrong: {vp}"
        print(f"[1] ✓ viewport: {vp['viewport']} ({vp['device']})")

        # 2. Wait for selector
        wait = await browser_tools.browser_wait_for(mgr, sid, selector="h1", timeout_ms=3000)
        assert wait["ok"]
        print(f"[2] ✓ wait_for selector: {wait['matched']}")

        # 3. SEO check
        seo = await qa_tools.qa_seo_check(mgr, sid)
        print(f"[3] ✓ seo_check: title='{seo['page']['title']}', h1={seo['headings']['h1_count']}, "
              f"issues={seo['summary']['total_issues']}")
        assert seo["page"]["title"] == "Test Page"
        assert seo["headings"]["h1_count"] == 1

        # 4. Baseline save + compare (same page → 0 diff)
        save = await qa_tools.qa_baseline_save(mgr, sid, name="test_smoke")
        assert save["saved"]
        print(f"[4a] ✓ baseline_save: {save['size_bytes']} bytes")

        cmp = await qa_tools.qa_baseline_compare(mgr, sid, name="test_smoke")
        assert cmp["ok"] and cmp["passed"], f"compare failed: {cmp}"
        print(f"[4b] ✓ baseline_compare: pct_changed={cmp['pct_changed']}, passed={cmp['passed']}")

        listed = qa_tools.qa_baseline_list()
        assert listed["count"] >= 1
        print(f"[4c] ✓ baseline_list: {listed['count']} baselines")

        # 5. Smart fill
        fill = await qa_tools.qa_form_smart_fill(mgr, sid, intent="valid_signup")
        assert fill["ok"]
        purposes = {f["purpose"] for f in fill["filled"]}
        print(f"[5] ✓ form_smart_fill: filled={fill['summary']['filled']} "
              f"purposes={purposes} skipped={fill['summary']['skipped']}")
        assert "email" in purposes, f"didn't fill email: {fill}"
        assert "password" in purposes, f"didn't fill password: {fill}"

        # 6. Cookies (just verify we can read them)
        cookies = await browser_tools.browser_get_cookies(mgr, sid)
        print(f"[6] ✓ get_cookies: {cookies['count']} cookies")

        # 7. Storage state save
        state = await browser_tools.browser_save_storage_state(mgr, sid, name="test_smoke")
        assert state["ok"]
        print(f"[7] ✓ save_storage_state: {state['cookies_count']} cookies → {state['path']}")

        # Cleanup
        await browser_tools.browser_close(mgr, sid)
        print(f"[8] ✓ closed")

    finally:
        await mgr.close_all()

    if fails:
        for f in fails:
            print(f"❌ {f}")
        sys.exit(1)
    print("\n✅ ALL NEW FEATURES PASSED")


if __name__ == "__main__":
    asyncio.run(main())
