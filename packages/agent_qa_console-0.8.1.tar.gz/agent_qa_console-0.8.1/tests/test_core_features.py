"""Pytest async test for core browser+QA features."""
import sys
from pathlib import Path

import pytest

pytestmark = pytest.mark.asyncio(scope="function")

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))
from qa_mcp.browser import SessionManager
from qa_mcp.tools import browser_tools, qa_tools


async def test_select_option_works():
    mgr = SessionManager()
    try:
        s = await browser_tools.browser_open(mgr, url="data:text/html;charset=utf-8,<html><body><select><option>Pick</option><option value='1'>One</option><option value='2'>Two</option></select></body></html>", headless=True)
        state = await browser_tools.browser_get_state(mgr, s["session_id"])
        select_el = next(el for el in state["elements"] if el["tag"] == "select")
        assert len(select_el.get("options", [])) == 3
        result = await browser_tools.browser_select_option(mgr, s["session_id"], select_el["index"], label="Two")
        assert "2" in result.get("selected", [])
        await browser_tools.browser_close(mgr, s["session_id"])
    finally:
        await mgr.close_all()


async def test_dialog_handling():
    mgr = SessionManager()
    try:
        html = "data:text/html;charset=utf-8,<html><body><button onclick=\"confirm('hi')\">ok</button></body></html>"
        s = await browser_tools.browser_open(mgr, url=html, headless=True)
        state = await browser_tools.browser_get_state(mgr, s["session_id"])
        btn = next(el for el in state["elements"] if el["tag"] == "button")
        await browser_tools.browser_handle_dialog(mgr, s["session_id"], action="dismiss")
        await browser_tools.browser_click(mgr, s["session_id"], btn["index"])
        state2 = await browser_tools.browser_get_state(mgr, s["session_id"])
        assert state2.get("last_dialog", {}).get("result") == "dismiss"
        await browser_tools.browser_close(mgr, s["session_id"])
    finally:
        await mgr.close_all()


async def test_screenshot_saves():
    mgr = SessionManager()
    try:
        s = await browser_tools.browser_open(mgr, url="data:text/html,<h1>pic</h1>", headless=True)
        shot = await browser_tools.browser_screenshot(mgr, s["session_id"], full_page=False)
        assert "path" in shot
        assert shot["size_bytes"] > 0
        await browser_tools.browser_close(mgr, s["session_id"])
    finally:
        await mgr.close_all()


async def test_baseline_save_and_compare():
    mgr = SessionManager()
    try:
        s = await browser_tools.browser_open(mgr, url="data:text/html,<h1>bl</h1>", headless=True)
        saved = await qa_tools.qa_baseline_save(mgr, s["session_id"], name="test_pytest_v2", full_page=False)
        assert saved["saved"]
        cmp = await qa_tools.qa_baseline_compare(mgr, s["session_id"], name="test_pytest_v2", full_page=False)
        assert cmp["ok"] and cmp["passed"]
        await browser_tools.browser_close(mgr, s["session_id"])
    finally:
        await mgr.close_all()


async def test_cli_rtl_clean_hebrew():
    mgr = SessionManager()
    try:
        html = "data:text/html;charset=utf-8,%3Chtml%20lang%3D%27he%27%20dir%3D%27rtl%27%3E%3Cbody%3E%3Cp%3E%D7%9E%D7%97%D7%99%D7%A8%3A%2099%20%E2%82%AA%3C%2Fp%3E%3C%2Fbody%3E%3C%2Fhtml%3E"
        s = await browser_tools.browser_open(mgr, url=html, headless=True, locale="he-IL")
        rtl = await qa_tools.qa_rtl_audit(mgr, s["session_id"], detail="full")
        assert rtl["summary"]["total"] == 0
        await browser_tools.browser_close(mgr, s["session_id"])
    finally:
        await mgr.close_all()
