"""Unit tests for qa_mcp.suite pure helpers and emitters (no browser)."""
import json
import sys
import xml.etree.ElementTree as ET
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from qa_mcp.suite import (
    _eval_thresholds,
    _impact_to_severity,
    _make_repro,
    _normalize_findings,
    _slugify,
    cli_run,
    emit_html_report,
    emit_issue_files,
    emit_junit_xml,
    emit_markdown_report,
)


# ----------------- Pure helpers -----------------


def test_impact_to_severity_known_and_unknown():
    assert _impact_to_severity("critical") == "critical"
    assert _impact_to_severity("serious") == "high"
    assert _impact_to_severity("moderate") == "medium"
    assert _impact_to_severity("minor") == "low"
    assert _impact_to_severity(None) == "medium"
    assert _impact_to_severity("weird") == "medium"


def test_make_repro_includes_url_and_optional_steps():
    assert _make_repro("https://x") == ["Open https://x"]
    out = _make_repro("https://x", selector=".btn", extra="Look at it")
    assert out[0].startswith("Open ")
    assert "Inspect element: .btn" in out
    assert "Look at it" in out


def test_slugify_handles_hebrew_and_punctuation():
    assert _slugify("Hello, World!") == "hello-world"
    assert _slugify("Hebrew בדיקה") == "hebrew-בדיקה"
    assert _slugify("***") == "issue"
    assert len(_slugify("x" * 200, max_len=50)) <= 50


# ----------------- _normalize_findings -----------------


def _scn_with_audits(audits):
    return {"name": "scn", "url": "https://x", "audits": audits}


def test_normalize_rtl_findings():
    scn = _scn_with_audits({"rtl": {"findings": [
        {"severity": "high", "title": "T", "category": "rtl_dir_missing",
         "sample": "<html lang=he>", "selector": ".hero", "hint": "add dir"},
    ]}})
    out = _normalize_findings(scn)
    assert len(out) == 1
    assert out[0]["source"] == "rtl"
    assert out[0]["selector"] == ".hero"
    assert out[0]["severity"] == "high"
    assert "id" in out[0]


def test_normalize_a11y_uses_impact_to_severity_and_helpurl():
    scn = _scn_with_audits({"a11y": {"violations": [
        {"impact": "serious", "id": "color-contrast", "help": "Low contrast",
         "sample_html": "<div>x</div>", "sample_target": ".bad", "helpUrl": "https://axe/cc"},
    ]}})
    out = _normalize_findings(scn)
    assert out[0]["source"] == "a11y"
    assert out[0]["severity"] == "high"
    assert "https://axe/cc" in out[0]["fix"]


def test_normalize_links_uses_button_no_label_severity():
    scn = _scn_with_audits({"links": {"items": [
        {"flags": ["button_no_label"], "text": "x", "selector": "button"},
        {"flags": ["empty_href"], "text": "y", "href": ""},
        {"flags": []},  # filtered out — no flags
    ]}})
    out = _normalize_findings(scn)
    assert len(out) == 2
    severities = sorted(f["severity"] for f in out if f["source"] == "links")
    assert severities == ["low", "medium"]


def test_normalize_ux_findings():
    scn = _scn_with_audits({"ux": {"findings": [
        {"severity": "medium", "title": "Too many CTAs", "samples": [{"selector": ".x"}]},
    ]}})
    out = _normalize_findings(scn)
    assert out[0]["source"] == "ux"
    assert out[0]["selector"] == ".x"


def test_normalize_perf_only_emits_when_failing():
    # Good perf: no finding
    out = _normalize_findings(_scn_with_audits({"perf": {"score": 95, "grades": {"lcp": "good"}}}))
    assert out == []

    # Poor perf: high severity
    out = _normalize_findings(_scn_with_audits({"perf": {"score": 50, "grades": {"lcp": "poor"}}}))
    assert len(out) == 1
    assert out[0]["severity"] == "high"

    # Medium perf: needs_improvement → medium severity
    out = _normalize_findings(_scn_with_audits({"perf": {"score": 75, "grades": {"lcp": "needs_improvement"}}}))
    assert len(out) == 1
    assert out[0]["severity"] == "medium"


def test_normalize_seo_logs_security_all_emit_findings():
    scn = _scn_with_audits({
        "seo": {"issues": [{"severity": "high", "title": "missing title"}]},
        "logs": {"events": [{"level": "error", "kind": "exception", "text": "boom"}]},
        "security": {"findings": [{"severity": "medium", "title": "no HSTS"}]},
    })
    out = _normalize_findings(scn)
    sources = {f["source"] for f in out}
    assert sources == {"seo", "logs", "security"}


def test_normalize_findings_sorted_and_deduped_with_ids():
    scn = _scn_with_audits({"rtl": {"findings": [
        {"severity": "low", "title": "x", "category": "rtl_low"},
        {"severity": "critical", "title": "y", "category": "rtl_high"},
    ]}})
    out = _normalize_findings(scn)
    assert out[0]["severity"] == "critical"
    assert out[1]["severity"] == "low"
    assert all(len(f["id"]) == 12 for f in out)


# ----------------- _eval_thresholds -----------------


def test_eval_thresholds_rtl():
    viols = _eval_thresholds("rtl", {"summary": {"by_severity": {"high": 3, "medium": 1}}},
                             {"max_high": 1, "max_medium": 5})
    assert viols == ["rtl.high=3 > 1"]


def test_eval_thresholds_a11y():
    viols = _eval_thresholds("a11y",
                             {"summary": {"by_impact": {"critical": 1, "serious": 2}}},
                             {"max_critical": 0, "max_serious": 1})
    assert any("critical" in v for v in viols)
    assert any("serious" in v for v in viols)


def test_eval_thresholds_perf_score_and_grade():
    res = {"score": 50, "grades": {"lcp": "needs_improvement"}}
    viols = _eval_thresholds("perf", res, {"min_score": 80, "min_lcp_grade": "good"})
    assert any("perf.score" in v for v in viols)
    assert any("lcp.grade" in v for v in viols)


def test_eval_thresholds_seo_and_links_and_ux_and_security():
    assert _eval_thresholds("seo", {"summary": {"total_issues": 5}}, {"max_issues": 3}) == ["seo.total_issues=5 > 3"]
    assert _eval_thresholds("links", {"summary": {"flagged": 9}}, {"max_flagged": 4}) == ["links.flagged=9 > 4"]
    ux = _eval_thresholds("ux",
                          {"scores": {"hierarchy_score": 50}, "summary": {"by_severity": {"high": 3}}},
                          {"min_hierarchy_score": 70, "max_high": 1})
    assert any("hierarchy_score" in v for v in ux)
    assert any("ux.high" in v for v in ux)
    sec = _eval_thresholds("security",
                           {"summary": {"by_severity": {"high": 4}, "score": 40}},
                           {"max_high": 1, "min_score": 80})
    assert any("security.high" in v for v in sec)
    assert any("security.score" in v for v in sec)


def test_eval_thresholds_unknown_kind_empty():
    assert _eval_thresholds("nonexistent", {}, {"max_high": 0}) == []


# ----------------- emitters -----------------


def _suite_dict():
    return {
        "name": "demo",
        "started_at": "2026-01-01T00:00:00",
        "finished_at": "2026-01-01T00:00:05",
        "duration_seconds": 5.0,
        "browser": "chromium",
        "summary": {
            "total": 2, "passed": 1, "failed": 1,
            "violations_total": 1, "findings_total": 2,
            "findings_by_severity": {"high": 1, "low": 1},
        },
        "scenarios": [
            {
                "name": "home", "url": "https://example.co.il/",
                "passed": False, "violations": ["rtl.high=2 > 0"],
                "audits": {"rtl": {"summary": {"total": 3}}, "perf": {"score": 70}},
                "findings": [
                    {"severity": "high", "source": "rtl", "title": "<dir missing>",
                     "evidence": "x", "selector": ".hero", "impact": "BiDi", "fix": "add dir",
                     "repro_steps": ["Open URL"]},
                    {"severity": "low", "source": "seo", "title": "no canonical"},
                ],
            },
            {
                "name": "about", "url": "https://example.co.il/about",
                "passed": True, "violations": [],
                "audits": {"seo": {"error": "fetch failed"}},
                "findings": [],
            },
        ],
    }


def test_emit_junit_xml_valid_structure(tmp_path):
    out = tmp_path / "junit.xml"
    emit_junit_xml(_suite_dict(), str(out))
    tree = ET.parse(out)
    root = tree.getroot()
    assert root.tag == "testsuite"
    assert root.attrib["tests"] == "2"
    assert root.attrib["failures"] == "1"
    cases = root.findall("testcase")
    assert len(cases) == 2
    # First should have failure, second none
    assert cases[0].find("failure") is not None
    assert cases[1].find("failure") is None


def test_emit_junit_xml_with_scenario_error(tmp_path):
    suite = _suite_dict()
    suite["scenarios"][0]["error"] = "browser crashed\nstack..."
    out = tmp_path / "junit.xml"
    emit_junit_xml(suite, str(out))
    text = out.read_text(encoding="utf-8")
    assert "browser crashed" in text


def test_emit_html_report_contains_summary_and_scenarios(tmp_path):
    out = tmp_path / "report.html"
    emit_html_report(_suite_dict(), str(out))
    text = out.read_text(encoding="utf-8")
    assert "<!doctype html>" in text
    assert "demo" in text
    assert "PASS" in text and "FAIL" in text
    assert "rtl.high=2" in text  # violation rendered
    assert "Actionable findings" in text


def test_emit_html_report_embeds_screenshot(tmp_path):
    png = tmp_path / "shot.jpg"
    png.write_bytes(b"\xff\xd8\xff" + b"x" * 200)
    suite = _suite_dict()
    suite["scenarios"][0]["screenshot_path"] = str(png)
    out = tmp_path / "rep.html"
    emit_html_report(suite, str(out))
    assert "data:image/jpeg;base64," in out.read_text(encoding="utf-8")


def test_emit_html_report_audit_error_branch(tmp_path):
    out = tmp_path / "rep.html"
    emit_html_report(_suite_dict(), str(out))
    text = out.read_text(encoding="utf-8")
    assert "seo — error" in text


def test_emit_issue_files_creates_one_per_finding_and_index(tmp_path):
    out = emit_issue_files(_suite_dict(), str(tmp_path))
    assert out["count"] == 2
    files = list(tmp_path.glob("*.md"))
    issue_files = [p for p in files if p.name != "README.md"]
    assert len(issue_files) == 2
    readme = (tmp_path / "README.md").read_text(encoding="utf-8")
    assert "QA Issues" in readme
    # First file ordered by severity (high before low)
    first = sorted(issue_files)[0].read_text(encoding="utf-8")
    assert "[HIGH][rtl]" in first
    assert "## Selector" in first


def test_emit_markdown_report_with_and_without_findings(tmp_path):
    out = tmp_path / "rep.md"
    emit_markdown_report(_suite_dict(), str(out))
    text = out.read_text(encoding="utf-8")
    assert "# QA Report — demo" in text
    assert "## home — FAIL" in text
    assert "## about — PASS" in text
    assert "No actionable findings normalized for this scenario." in text
    assert "Threshold violations" in text


def test_cli_run_missing_config_returns_2(capsys):
    rc = cli_run("nonexistent.json")
    assert rc == 2
    out = capsys.readouterr().out
    assert "config not found" in out


def test_cli_run_full_path_emits_reports(tmp_path, monkeypatch):
    # Stub run_suite with a known result — bypass browser
    fake_result = _suite_dict()
    fake_result["summary"]["failed"] = 0

    async def fake_run_suite(cfg, on_progress=None):
        return fake_result

    monkeypatch.setattr("qa_mcp.suite.run_suite", fake_run_suite)
    cfg = {
        "name": "demo",
        "scenarios": [{"name": "x", "path": "/"}],
        "report": {
            "html": str(tmp_path / "out.html"),
            "junit": str(tmp_path / "out.xml"),
            "markdown": str(tmp_path / "out.md"),
            "issues": str(tmp_path / "issues"),
            "json": str(tmp_path / "out.json"),
        },
    }
    cfg_path = tmp_path / "qa.config.json"
    cfg_path.write_text(json.dumps(cfg), encoding="utf-8")
    rc = cli_run(str(cfg_path))
    assert rc == 0
    assert (tmp_path / "out.html").exists()
    assert (tmp_path / "out.xml").exists()
    assert (tmp_path / "out.md").exists()
    assert (tmp_path / "issues" / "README.md").exists()
    assert (tmp_path / "out.json").exists()
