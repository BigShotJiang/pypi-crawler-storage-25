"""End-to-end MCP test: spawn qa-mcp as a stdio subprocess, list tools,
call browser_open + qa_rtl_audit + browser_close. No LLM, no API keys."""
import asyncio
import json
import sys
from pathlib import Path

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client


async def main():
    venv_python = Path(__file__).parent.parent / ".venv" / "Scripts" / "python.exe"
    params = StdioServerParameters(
        command=str(venv_python),
        args=["-m", "qa_mcp.server"],
    )

    async with stdio_client(params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            tools = await session.list_tools()
            names = [t.name for t in tools.tools]
            print(f"[mcp] {len(names)} tools: {names}")

            expected = {"browser_open", "browser_navigate", "browser_screenshot",
                        "browser_get_state", "browser_click", "browser_type",
                        "browser_press_key", "browser_logs", "browser_close",
                        "qa_rtl_audit", "qa_perf_metrics", "qa_scan_links",
                        "qa_a11y_audit", "qa_fuzz_input"}
            missing = expected - set(names)
            assert not missing, f"missing: {missing}"

            test_html = ("data:text/html;charset=utf-8,<!doctype html>"
                         "<html lang='he'><body><h1>שלום</h1>"
                         "<p>מחיר: ₪99</p></body></html>")
            res = await session.call_tool("browser_open", {"url": test_html, "headless": True})
            sid = json.loads(res.content[0].text)["session_id"]
            print(f"[mcp] browser_open → session={sid[:8]}")

            res = await session.call_tool("qa_rtl_audit", {"session_id": sid})
            audit = json.loads(res.content[0].text)
            cats = list(audit["summary"].get("by_category", {}).keys())
            print(f"[mcp] qa_rtl_audit → {audit['summary']['total']} findings, categories={cats}")
            assert audit["summary"]["total"] >= 1

            res = await session.call_tool("browser_close", {"session_id": sid})
            print(f"[mcp] closed")

    print("\n[mcp] ✅ FULL MCP ROUNDTRIP PASSED — no LLM, no API keys")


if __name__ == "__main__":
    asyncio.run(main())
