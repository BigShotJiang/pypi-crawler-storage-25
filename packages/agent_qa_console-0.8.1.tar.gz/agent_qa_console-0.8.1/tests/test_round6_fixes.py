"""Round 6 review (2026-05-02) — close the 2 MCP gaps.

P0-1: NOISY_HOSTS missed Optimizely + 16 other trackers — drowned real bugs.
P0-2: last_dialog stuck across navigations — agent saw ghost dialogs from
      a prior page.
"""
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from qa_mcp.browser import SessionManager, _is_noisy, NOISY_HOSTS
from qa_mcp.tools import browser_tools


# Page that emits two real errors AND tries to load Optimizely (which fails
# with DNS error in headless because we don't actually let it through).
NOISY_PAGE_HTML = (
    "data:text/html;charset=utf-8,<!doctype html><html><body>"
    "<h1>noisy</h1>"
    # Will produce console.error
    "<script>console.error('REAL_BUG_1');</script>"
    "<script>console.error('REAL_BUG_2');</script>"
    # These would normally produce network_failed events. With the expanded
    # blocklist, they should be filtered.
    "<img src='https://298279967.log.optimizely.com/something.png'>"
    "<img src='https://api.segment.io/track'>"
    "<img src='https://api.amplitude.com/2/httpapi'>"
    "<script src='https://www.heap.io/h.js'></script>"
    "</body></html>"
)


async def main():
    mgr = SessionManager()
    fails = []
    try:
        # ===================================================================
        # P0-1 — analytics blocklist sanity (unit-level)
        # ===================================================================
        must_filter = [
            "https://298279967.log.optimizely.com/event",
            "https://api.segment.io/v1/track",
            "https://api.mixpanel.com/track",
            "https://api2.amplitude.com/2/httpapi",
            "https://heapanalytics.com/h",
            "https://rs.fullstory.com/rec",
            "https://app.pendo.io/data",
            "https://api-iam.intercom.io/messenger/web",
            "https://js.hs-scripts.com/12345.js",
            "https://www.crazyegg.com/script",
            "https://browser-intake-datadoghq.com/api/v2/rum",
        ]
        for u in must_filter:
            if not _is_noisy(u):
                fails.append(f"P0-1: should filter analytics URL: {u}")
        if not fails:
            print(f"[P0-1] ✓ blocklist filters {len(must_filter)} analytics URLs")
            print(f"        NOISY_HOSTS now has {len(NOISY_HOSTS)} entries "
                  f"(was 7 before Round 6)")

        # And things that should NOT be filtered (real-product domains)
        must_not_filter = [
            "https://voicebox.brainboxai.io/api/transcribe",
            "https://example.com/asdf.jpg",
            "https://api.stripe.com/v1/charges",  # stripe is not analytics
        ]
        for u in must_not_filter:
            if _is_noisy(u):
                fails.append(f"P0-1: false-positive — filtered real URL: {u}")
        if not any(f.startswith("P0-1") for f in fails):
            print(f"        ✓ no false positives on {len(must_not_filter)} real URLs")

        # ===================================================================
        # P0-1 — integration: live page with mixed real + noise events
        # ===================================================================
        s = await browser_tools.browser_open(mgr, headless=True)
        sid = s["session_id"]
        await browser_tools.browser_navigate(mgr, sid, NOISY_PAGE_HTML, wait_until="load")
        await asyncio.sleep(1.0)  # let resource fetches resolve / fail
        logs = await browser_tools.browser_logs(mgr, sid)
        print(f"[P0-1 integration] captured {logs['count']} events")
        # Real errors should be there
        real_count = sum(1 for e in logs["events"] if "REAL_BUG" in (e.get("text") or ""))
        # Noise should NOT be there
        noise_count = sum(1 for e in logs["events"]
                          if any(host in (e.get("url") or "")
                                 for host in ("optimizely.com", "segment.io",
                                              "amplitude.com", "heap.io")))
        print(f"        real_bugs={real_count}  filtered_noise_count={noise_count}")
        if real_count < 2:
            fails.append(f"P0-1 integration: real bugs lost ({real_count}/2)")
        if noise_count > 0:
            fails.append(f"P0-1 integration: noise leaked ({noise_count} events)")
        if real_count >= 2 and noise_count == 0:
            print(f"        ✓ real bugs surface, noise suppressed")
        await browser_tools.browser_close(mgr, sid)

        # ===================================================================
        # P0-2 — last_dialog clears on navigate
        # ===================================================================
        s = await browser_tools.browser_open(mgr, headless=True)
        sid = s["session_id"]
        # Trigger a dialog manually
        await browser_tools.browser_navigate(
            mgr, sid,
            "data:text/html,<button onclick='alert(\"hi\")'>go</button>",
            wait_until="load",
        )
        state = await browser_tools.browser_get_state(mgr, sid)
        btn = next(e for e in state["elements"] if e["tag"] == "button")
        await browser_tools.browser_click(mgr, sid, btn["index"])
        await asyncio.sleep(0.3)
        state2 = await browser_tools.browser_get_state(mgr, sid)
        if not state2.get("last_dialog"):
            fails.append("P0-2 setup: dialog wasn't captured at all")
        else:
            print(f"[P0-2] dialog captured: {state2['last_dialog']['type']}/"
                  f"{state2['last_dialog']['message']}")
            # Now navigate elsewhere — last_dialog should clear
            await browser_tools.browser_navigate(
                mgr, sid, "data:text/html,<h1>fresh page</h1>",
                wait_until="domcontentloaded",
            )
            state3 = await browser_tools.browser_get_state(mgr, sid)
            if state3.get("last_dialog") is not None:
                fails.append(f"P0-2: stale dialog survived navigation: {state3['last_dialog']}")
            else:
                print(f"        ✓ last_dialog cleared after navigate")
        await browser_tools.browser_close(mgr, sid)

    finally:
        await mgr.close_all()

    if fails:
        print("\n❌ FAILURES:")
        for f in fails:
            print(f"   - {f}")
        sys.exit(1)
    print("\n✅ ROUND 6 GAPS CLOSED")


if __name__ == "__main__":
    asyncio.run(main())
