"""Unit tests for qa_mcp.slack — mocked urllib, no network."""
import json
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from qa_mcp.slack import SEVERITY_EMOJI, notify_slack


def _mk_suite(**over):
    base = {
        "name": "demo",
        "browser": "chromium",
        "duration_seconds": 4.5,
        "summary": {"passed": 2, "failed": 1, "total": 3, "findings_total": 4},
        "scenarios": [
            {
                "name": "home",
                "findings": [
                    {"severity": "critical", "source": "rtl", "title": "missing dir"},
                    {"severity": "low", "source": "a11y", "title": "small contrast"},
                ],
            },
            {
                "name": "about",
                "findings": [
                    {"severity": "high", "source": "perf", "title": "slow LCP"},
                    {"severity": "info", "source": "seo", "title": "ok"},
                ],
            },
        ],
    }
    base.update(over)
    return base


URL = "https://hooks.slack.invalid/test"


def _capture(*, side_effect=None):
    captured = {}

    class _Resp:
        status = 200

        def __enter__(self):
            return self

        def __exit__(self, *a):
            return False

    def _urlopen(req, timeout=10):
        captured["url"] = req.full_url
        captured["body"] = json.loads(req.data.decode("utf-8"))
        captured["headers"] = dict(req.header_items())
        if side_effect:
            raise side_effect
        return _Resp()

    return captured, _urlopen


def test_severity_emoji_table_complete():
    for sev in ("critical", "high", "medium", "low", "info"):
        assert sev in SEVERITY_EMOJI


def test_notify_passes_payload_and_sorts_findings():
    captured, fake_urlopen = _capture()
    with patch("urllib.request.urlopen", fake_urlopen):
        out = notify_slack(URL, _mk_suite())
    assert out == {"ok": True, "status_code": 200, "findings_posted": 4}
    blocks = captured["body"]["blocks"]
    # header + fields + top-findings = 3 blocks
    assert blocks[0]["type"] == "header"
    assert ":warning:" in blocks[0]["text"]["text"]  # 1 FAILED
    assert "demo" in blocks[0]["text"]["text"]
    findings_section = blocks[-1]["text"]["text"]
    # severities ordered: critical, high, low, info
    assert findings_section.index("CRITICAL") < findings_section.index("HIGH")
    assert findings_section.index("HIGH") < findings_section.index("LOW")
    assert findings_section.index("LOW") < findings_section.index("INFO")


def test_notify_caps_findings_at_max():
    suite = _mk_suite()
    # blow up findings list
    suite["scenarios"][0]["findings"] = [
        {"severity": "high", "source": "x", "title": f"finding {i}"} for i in range(10)
    ]
    captured, fake_urlopen = _capture()
    with patch("urllib.request.urlopen", fake_urlopen):
        out = notify_slack(URL,suite, max_findings=3)
    assert out["findings_posted"] == 3
    section = captured["body"]["blocks"][-1]["text"]["text"]
    assert section.count(":red_circle:") == 3  # only 3 rendered


def test_notify_passed_branch_no_findings_block():
    suite = _mk_suite(summary={"passed": 3, "failed": 0, "total": 3, "findings_total": 0},
                      scenarios=[])
    captured, fake_urlopen = _capture()
    with patch("urllib.request.urlopen", fake_urlopen):
        out = notify_slack(URL,suite)
    blocks = captured["body"]["blocks"]
    assert any(":white_check_mark:" in b.get("text", {}).get("text", "") for b in blocks if b["type"] == "header")
    # 2 blocks only (header + fields) — no findings section
    assert len(blocks) == 2
    assert out["findings_posted"] == 0


def test_notify_channel_override_attached():
    captured, fake_urlopen = _capture()
    with patch("urllib.request.urlopen", fake_urlopen):
        notify_slack(URL,_mk_suite(), channel="#qa-alerts")
    assert captured["body"]["channel"] == "#qa-alerts"


def test_notify_handles_missing_summary_and_scenarios():
    captured, fake_urlopen = _capture()
    with patch("urllib.request.urlopen", fake_urlopen):
        out = notify_slack(URL,{"name": "bare"})
    assert out["ok"] is True
    blocks = captured["body"]["blocks"]
    # header + fields; no findings section
    assert len(blocks) == 2


def test_notify_network_error_returns_error_dict():
    _, fake_urlopen = _capture(side_effect=RuntimeError("boom"))
    with patch("urllib.request.urlopen", fake_urlopen):
        out = notify_slack(URL,_mk_suite())
    assert out == {"ok": False, "error": "boom"}


def test_notify_unknown_severity_falls_back():
    suite = _mk_suite(summary={"passed": 0, "failed": 1, "total": 1, "findings_total": 1},
                      scenarios=[{"name": "x", "findings": [
                          {"severity": "weird", "source": "?", "title": "huh"}
                      ]}])
    captured, fake_urlopen = _capture()
    with patch("urllib.request.urlopen", fake_urlopen):
        notify_slack(URL,suite)
    section = captured["body"]["blocks"][-1]["text"]["text"]
    assert ":grey_question:" in section
    assert "WEIRD" in section
