"""Validate the 3 fixes from 2026-05-02 audit (qa-mcp-test-results.txt).

#1 (P0): shared waitForContent — qa_a11y / qa_seo agree on h1 count after a JS-
         hydrated page settles.
#2 (P1): perf output exposes timing_reference + notes (not bare numbers).
#3 (P2): browser_navigate returns redirect_chain.
"""
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from qa_mcp.browser import SessionManager
from qa_mcp.tools import browser_tools, qa_tools


# Stable page — qa_seo and qa_a11y must agree on the DOM state since both
# now call _wait_for_content. (The original race was specifically on
# unstable hydrating SPAs in the wild; a synthetic data: URL can't
# reliably reproduce a network race, so we test the consistency invariant
# on a stable page instead.)
STABLE_HTML = (
    "data:text/html;charset=utf-8,<!doctype html>"
    "<html lang='en'><head><title>Stable</title>"
    "<meta name='description' content='test consistency'>"
    "</head><body>"
    "<main><h1>Hello</h1><p>body content</p></main>"
    "</body></html>"
)


async def main():
    mgr = SessionManager()
    fails = []
    try:
        s = await browser_tools.browser_open(mgr, url=STABLE_HTML, headless=True)
        sid = s["session_id"]

        # ---- FIX #1: parallel qa_seo + qa_a11y agree on h1 ----
        # On a stable page with one h1, the two tools must not contradict
        # (seo says h1_count=1 ↔ a11y does not raise page-has-heading-one).
        seo_task = asyncio.create_task(qa_tools.qa_seo_check(mgr, sid))
        a11y_task = asyncio.create_task(qa_tools.qa_a11y_audit(mgr, sid))
        seo, a11y = await asyncio.gather(seo_task, a11y_task)

        seo_h1 = seo["headings"]["h1_count"]
        a11y_violations = a11y.get("violations", []) if isinstance(a11y, dict) else []
        a11y_no_h1 = any(v.get("id") == "page-has-heading-one" for v in a11y_violations)

        print(f"[#1] seo h1_count={seo_h1}  a11y_flagged_missing_h1={a11y_no_h1}")
        if seo_h1 != 1:
            fails.append(f"FIX#1 setup: seo expected 1 h1, got {seo_h1}")
        elif a11y_no_h1:
            fails.append("FIX#1 race: seo sees the h1 but a11y still flags 'no h1' (race not fixed)")
        else:
            # Helper exists at the right place
            from qa_mcp.tools.qa_tools import _wait_for_content
            assert callable(_wait_for_content)
            print(f"      ✓ qa_seo and qa_a11y agree on a stable DOM; _wait_for_content registered")

        # ---- FIX #2: perf output has timing_reference + notes ----
        perf = await qa_tools.qa_perf_metrics(mgr, sid, wait_for_lcp_ms=1500)
        print(f"[#2] perf keys: {sorted(perf.keys())}")
        if "timing_reference" not in perf:
            fails.append("FIX#2: perf missing timing_reference field")
        else:
            tr = perf["timing_reference"]
            if "time_origin_ms" not in tr or "navigation_start" not in tr:
                fails.append(f"FIX#2: timing_reference incomplete: {tr}")
            else:
                print(f"      ✓ time_origin_ms={tr['time_origin_ms']} navigation_start={tr['navigation_start']}")
        if "notes" not in perf:
            fails.append("FIX#2: perf missing notes array")
        else:
            print(f"      notes: {perf['notes']} (fast page → likely empty, that's OK)")

        # ---- FIX #3: redirect_chain on browser_navigate ----
        # httpbin.org/redirect/2 → /redirect/1 → /get
        nav = await browser_tools.browser_navigate(
            mgr, sid, "https://httpbin.org/redirect/2", wait_until="domcontentloaded",
        )
        print(f"[#3] navigate result keys: {sorted(nav.keys())}")
        if "redirect_chain" not in nav:
            fails.append("FIX#3: browser_navigate missing redirect_chain")
        elif "redirect_count" not in nav:
            fails.append("FIX#3: browser_navigate missing redirect_count")
        elif nav["redirect_count"] < 2:
            # httpbin should produce 2 hops, but allow 1+ in case of internet hiccups
            print(f"      ⚠ redirect_count={nav['redirect_count']} (expected ≥2, network may be flaky)")
            if nav["redirect_count"] == 0:
                fails.append(f"FIX#3: redirect_chain empty after multi-hop redirect: {nav}")
        else:
            print(f"      ✓ redirect_chain captured ({nav['redirect_count']} hops): "
                  f"{[r['status'] for r in nav['redirect_chain']]}")

        await browser_tools.browser_close(mgr, sid)
    finally:
        await mgr.close_all()

    if fails:
        print("\n❌ FAILURES:")
        for f in fails:
            print(f"   - {f}")
        sys.exit(1)
    print("\n✅ ALL 2026-05-02 FIXES VERIFIED")


if __name__ == "__main__":
    asyncio.run(main())
