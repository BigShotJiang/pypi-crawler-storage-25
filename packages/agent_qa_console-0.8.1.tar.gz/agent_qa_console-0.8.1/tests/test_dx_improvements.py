"""Smoke tests for DX improvements:
  - browser_get_state with scope/exclude/max_elements (avoids 100KB blowup)
  - browser_evaluate with frame_chain (saves boilerplate for nested iframes)
  - browser_fill_form (React-aware bulk filler — bypasses the value-setter trap)

Run: python tests/test_dx_improvements.py
"""
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from qa_mcp.browser import SessionManager
from qa_mcp.tools import browser_tools


# Page with: a heavy nav (40 links), a small form, and nested iframes.
HEAVY_PAGE = (
    "data:text/html;charset=utf-8,<!doctype html><html><body>"
    "<nav>"
    + "".join(f"<a href='/p{i}'>nav-link-{i}</a>" for i in range(40))
    + "</nav>"
    "<main>"
    "  <form id='signup'>"
    "    <input id='firstName' name='firstName'>"
    "    <input id='userEmail' name='email' type='email'>"
    "    <textarea id='bio'></textarea>"
    "    <select id='country'>"
    "      <option value='il'>Israel</option>"
    "      <option value='us'>United States</option>"
    "    </select>"
    "    <input id='agree' type='checkbox'>"
    "    <label for='agree'>I agree</label>"
    "    <input id='gender_m' type='radio' name='gender' value='m'>"
    "    <label for='gender_m'>Male</label>"
    "    <input id='gender_f' type='radio' name='gender' value='f'>"
    "    <label for='gender_f'>Female</label>"
    "    <button id='submit' type='submit'>Submit</button>"
    "  </form>"
    "</main>"
    "<footer>"
    + "".join(f"<a href='/f{i}'>footer-link-{i}</a>" for i in range(20))
    + "</footer>"
    "</body></html>"
)


# Nested-frames page using srcdoc (no separate fetch).
NESTED_FRAMES = (
    "data:text/html;charset=utf-8,<!doctype html><html><body>"
    "<iframe id='outer' srcdoc=\"<html><body>"
    "OUTER_FRAME"
    "<iframe id='inner' srcdoc='<html><body>INNER_FRAME</body></html>'></iframe>"
    "</body></html>\"></iframe>"
    "</body></html>"
)


async def main() -> int:
    mgr = SessionManager()
    fails: list[str] = []

    try:
        # --- Test 1: scoping reduces snapshot size ---
        s = await browser_tools.browser_open(mgr, url=HEAVY_PAGE, headless=True)
        sid = s["session_id"]

        full = await browser_tools.browser_get_state(mgr, sid, text_snapshot_chars=0)
        scoped = await browser_tools.browser_get_state(
            mgr, sid, text_snapshot_chars=0, scope="#signup",
        )
        excluded = await browser_tools.browser_get_state(
            mgr, sid, text_snapshot_chars=0, exclude="nav, footer",
        )
        capped = await browser_tools.browser_get_state(
            mgr, sid, text_snapshot_chars=0, max_elements=5,
        )

        if full["element_count"] < 60:
            fails.append(f"full snapshot too small: {full['element_count']}")
        if scoped["element_count"] >= full["element_count"]:
            fails.append(f"scoped not smaller: scoped={scoped['element_count']} full={full['element_count']}")
        if scoped["element_count"] < 5:
            fails.append(f"scoped lost the form fields: {scoped['element_count']}")
        if "scope_applied" not in scoped:
            fails.append("scoped result missing scope_applied")
        if excluded["element_count"] >= full["element_count"]:
            fails.append(f"excluded not smaller: excluded={excluded['element_count']} full={full['element_count']}")
        if capped["element_count"] != 5:
            fails.append(f"max_elements ignored: got {capped['element_count']}")
        if not capped.get("truncated"):
            fails.append("capped result missing truncated=True flag")
        else:
            print(f"  ✓ scoping works (full={full['element_count']}, scoped={scoped['element_count']}, capped={capped['element_count']})")

        # --- Test 2: browser_fill_form ---
        fill = await browser_tools.browser_fill_form(mgr, sid, {
            "#firstName": "Netanel",
            "#userEmail": "n@brainbox.ai",
            "#bio": "Multi-line\nbiography text",
            "#country": {"label": "United States"},
            "#agree": True,
            "label[for=gender_m]": True,
        })
        if not fill["ok"]:
            fails.append(f"fill_form not ok: {fill['results']}")
        # Verify each value made it into the DOM.
        check = await browser_tools.browser_evaluate(mgr, sid, """
            () => ({
              firstName: document.getElementById('firstName').value,
              email: document.getElementById('userEmail').value,
              bio: document.getElementById('bio').value,
              country: document.getElementById('country').value,
              agreed: document.getElementById('agree').checked,
              male: document.getElementById('gender_m').checked,
            })
        """)
        c = check["result"]
        if c["firstName"] != "Netanel":
            fails.append(f"firstName not set: {c['firstName']!r}")
        if c["email"] != "n@brainbox.ai":
            fails.append(f"email not set: {c['email']!r}")
        if "Multi-line" not in c["bio"]:
            fails.append(f"bio not set: {c['bio']!r}")
        if c["country"] != "us":
            fails.append(f"country not selected by label: {c['country']!r}")
        if not c["agreed"]:
            fails.append("checkbox not checked")
        if not c["male"]:
            fails.append("radio not checked via label")
        if not fails:
            print("  ✓ browser_fill_form set all 6 fields correctly")
        elif len(fails) == 0:
            pass  # already accounted for above

        # --- Test 3: invalid selector reported per-field, doesn't crash ---
        partial = await browser_tools.browser_fill_form(mgr, sid, {
            "#firstName": "Replaced",
            "#nonexistent_field": "should fail",
        })
        if partial["ok"]:
            fails.append("fill_form with bad selector should not be ok overall")
        if partial["filled"] != 1 or partial["failed"] != 1:
            fails.append(f"per-field counts wrong: filled={partial['filled']} failed={partial['failed']}")
        else:
            print("  ✓ per-field error reporting works")

        await browser_tools.browser_close(mgr, sid)

        # --- Test 4: frame_chain ---
        s2 = await browser_tools.browser_open(mgr, url=NESTED_FRAMES, headless=True)
        sid2 = s2["session_id"]
        # Wait for inner srcdoc to settle.
        await asyncio.sleep(0.3)

        outer = await browser_tools.browser_evaluate(
            mgr, sid2,
            "() => document.body.innerText",
            frame_chain=["#outer"],
        )
        if "OUTER_FRAME" not in (outer.get("result") or ""):
            fails.append(f"frame_chain[#outer] missed text: {outer}")

        inner = await browser_tools.browser_evaluate(
            mgr, sid2,
            "() => document.body.innerText",
            frame_chain=["#outer", "#inner"],
        )
        if "INNER_FRAME" not in (inner.get("result") or ""):
            fails.append(f"frame_chain[#outer,#inner] missed text: {inner}")
        else:
            print("  ✓ frame_chain reaches nested iframe")

        # Bad frame_chain — should error gracefully, not throw.
        bad = await browser_tools.browser_evaluate(
            mgr, sid2,
            "() => 1",
            frame_chain=["#outer", "#nonexistent_iframe"],
        )
        if bad.get("ok"):
            fails.append(f"bad frame_chain should fail, got: {bad}")
        else:
            print("  ✓ bad frame_chain reports error cleanly")

        await browser_tools.browser_close(mgr, sid2)

    finally:
        await mgr.close_all()

    if fails:
        print("\nFAILURES:")
        for f in fails:
            print("  -", f)
        return 1
    print("\nALL DX IMPROVEMENTS WORK")
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
