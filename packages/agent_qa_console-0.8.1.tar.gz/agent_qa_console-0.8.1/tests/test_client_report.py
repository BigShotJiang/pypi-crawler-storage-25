"""Unit tests for qa_mcp.client_report — pure HTML/ZIP, no browser."""
import json
import sys
import zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from qa_mcp.client_report import (
    _data_uri,
    _html_report,
    _sev_he,
    _top_findings,
    create_client_report_zip,
)


def _suite_dict():
    return {
        "name": "demo-site",
        "browser": "chromium",
        "summary": {
            "total": 2,
            "passed": 1,
            "failed": 1,
            "findings_total": 4,
            "findings_by_severity": {"critical": 1, "high": 2, "low": 1},
        },
        "scenarios": [
            {
                "name": "home",
                "url": "https://example.co.il/",
                "passed": False,
                "violations": ["rtl", "perf"],
                "findings": [
                    {
                        "severity": "critical",
                        "source": "rtl",
                        "category": "rtl_dir_missing",
                        "title": "<dir missing>",
                        "evidence": "<html lang=\"he\">",
                        "selector": ".hero",
                        "impact": "BiDi broken",
                        "fix": "add dir=\"rtl\"",
                    },
                    {
                        "severity": "high",
                        "source": "perf",
                        "category": "lcp_slow",
                        "title": "Slow LCP",
                    },
                ],
            },
            {
                "name": "about",
                "url": "https://example.co.il/about",
                "passed": True,
                "violations": [],
                "findings": [
                    {"severity": "low", "source": "seo", "title": "missing alt"},
                    {"severity": "high", "source": "a11y", "title": "missing label"},
                ],
            },
        ],
    }


def test_sev_he_translates_known_and_unknown():
    assert _sev_he("critical") == "קריטי"
    assert _sev_he("high") == "חשוב"
    assert _sev_he("medium") == "בינוני"
    assert _sev_he("low") == "נמוך"
    assert _sev_he("info") == "מידע"
    # unknown falls through unchanged
    assert _sev_he("weird") == "weird"


def test_data_uri_empty_and_missing(tmp_path):
    assert _data_uri(None) == ""
    assert _data_uri("") == ""
    assert _data_uri(str(tmp_path / "nope.png")) == ""


def test_data_uri_encodes_png_and_jpg(tmp_path):
    png = tmp_path / "a.png"
    png.write_bytes(b"\x89PNG\r\n\x1a\n")
    uri = _data_uri(str(png))
    assert uri.startswith("data:image/png;base64,")
    assert "iVBORw0KGgo=" in uri or len(uri) > 30

    jpg = tmp_path / "b.jpg"
    jpg.write_bytes(b"\xff\xd8\xff")
    juri = _data_uri(str(jpg))
    assert juri.startswith("data:image/jpeg;base64,")

    jpeg = tmp_path / "c.jpeg"
    jpeg.write_bytes(b"\xff\xd8\xff")
    assert _data_uri(str(jpeg)).startswith("data:image/jpeg;base64,")


def test_top_findings_sorts_by_severity_and_limits():
    rows = _top_findings(_suite_dict(), limit=10)
    severities = [f.get("severity") for _, f in rows]
    assert severities == ["critical", "high", "high", "low"]

    limited = _top_findings(_suite_dict(), limit=2)
    assert len(limited) == 2
    assert [f["severity"] for _, f in limited] == ["critical", "high"]


def test_top_findings_handles_missing_severity_and_empty_suite():
    empty = _top_findings({"scenarios": []})
    assert empty == []
    weird = _top_findings({"scenarios": [{"name": "x", "findings": [{"title": "no-sev"}]}]})
    # unknown severity gets rank 9, still included
    assert len(weird) == 1


def test_html_report_contains_client_and_summary_numbers():
    suite = _suite_dict()
    out = _html_report(suite, "Demo Co", consultant="BrainboxAI")
    assert out.startswith("<!doctype html>")
    assert 'lang="he" dir="rtl"' in out
    assert "Demo Co" in out
    assert "BrainboxAI" in out
    # numeric summary fields rendered
    assert ">4<" in out  # findings_total
    assert ">2<" in out  # total scenarios
    # scenario rows for both home + about
    assert "home" in out and "about" in out
    # severity badge for critical and high
    assert "badge critical" in out
    assert "badge high" in out


def test_html_report_escapes_user_html():
    suite = _suite_dict()
    out = _html_report(suite, "Demo Co")
    # The title "<dir missing>" must be escaped
    assert "&lt;dir missing&gt;" in out
    # The evidence with quotes must be escaped
    assert "&lt;html lang=&quot;he&quot;&gt;" in out


def test_html_report_includes_screenshots_when_present(tmp_path):
    png = tmp_path / "shot.png"
    png.write_bytes(b"\x89PNG\r\n\x1a\n" + b"x" * 100)
    suite = _suite_dict()
    suite["scenarios"][0]["screenshot_path"] = str(png)
    out = _html_report(suite, "Demo Co")
    assert "data:image/png;base64," in out
    assert "class='shot'" in out


def test_html_report_no_findings_fallback():
    suite = {"name": "empty", "summary": {}, "scenarios": []}
    out = _html_report(suite, "Bare")
    assert "לא נמצאו ממצאים מרכזיים." in out


def test_create_client_report_zip_writes_full_structure(tmp_path):
    result = tmp_path / "qa-result.json"
    result.write_text(json.dumps(_suite_dict(), ensure_ascii=False), encoding="utf-8")
    zip_path = tmp_path / "out" / "report.zip"

    info = create_client_report_zip(str(result), str(zip_path), client="Acme")
    assert info["client"] == "Acme"
    assert info["zip_path"].endswith("report.zip")
    assert info["size_bytes"] > 0
    assert info["issues"] >= 0
    assert zip_path.exists()

    with zipfile.ZipFile(zip_path) as z:
        names = z.namelist()
    assert "דוח-בדיקת-איכות.html" in names
    assert "נספחים/client-summary-he.md" in names
    assert "נספחים/qa-result.json" in names


def test_create_client_report_zip_defaults_client_to_suite_name(tmp_path):
    result = tmp_path / "qa-result.json"
    result.write_text(json.dumps(_suite_dict(), ensure_ascii=False), encoding="utf-8")
    zip_path = tmp_path / "report.zip"

    info = create_client_report_zip(str(result), str(zip_path))
    assert info["client"] == "demo-site"


def test_create_client_report_zip_falls_back_when_suite_unnamed(tmp_path):
    suite = _suite_dict()
    suite.pop("name")
    result = tmp_path / "qa-result.json"
    result.write_text(json.dumps(suite, ensure_ascii=False), encoding="utf-8")
    zip_path = tmp_path / "report.zip"

    info = create_client_report_zip(str(result), str(zip_path))
    assert info["client"] == "QA Client"
