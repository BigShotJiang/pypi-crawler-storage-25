"""Round 5 review (2026-05-02) — close the 3 gaps:

1. qa_scan_links missed <input type=submit/button> on saucedemo login.
2. browser_get_state had no text_snapshot, so non-interactive errors
   (e.g. "Sorry, this user has been locked out") were invisible to the agent.
3. browser_open was inconsistent with browser_navigate — didn't return
   redirect_chain.
"""
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from qa_mcp.browser import SessionManager
from qa_mcp.tools import browser_tools, qa_tools


SAUCEDEMO_LOGIN_HTML = (
    "data:text/html,<!doctype html><html><body>"
    "<form>"
    "<input type='text' name='user' placeholder='username'>"
    "<input type='password' name='pw' placeholder='password'>"
    "<input type='submit' value='Login'>"
    "<input type='reset' value='Reset'>"
    "<input type='image' src='/btn.png'>"  # missing alt → flag
    "</form>"
    "</body></html>"
)

LOCKED_OUT_HTML = (
    "data:text/html,<!doctype html><html><body>"
    "<button id='login-button'>Login</button>"
    "<h3 class='error'>Epic sadface: Sorry, this user has been locked out</h3>"
    "</body></html>"
)


async def main():
    mgr = SessionManager()
    fails = []
    try:
        # ===================================================================
        # Gap 1 — qa_scan_links includes input[type=submit/button/...]
        # ===================================================================
        s = await browser_tools.browser_open(mgr, url=SAUCEDEMO_LOGIN_HTML, headless=True)
        sid = s["session_id"]
        scan = await qa_tools.qa_scan_links(mgr, sid)
        print(f"[Gap 1] scan_links count: {scan['count']}")
        if scan["count"] < 3:
            fails.append(f"Gap1: expected ≥3 (submit + reset + image), got {scan['count']}")
        else:
            kinds = sorted({i["kind"] for i in scan["items"]})
            print(f"        kinds: {kinds}")
            has_submit = any(i.get("input_type") == "submit" for i in scan["items"])
            has_reset = any(i.get("input_type") == "reset" for i in scan["items"])
            has_image = any(i.get("input_type") == "image" for i in scan["items"])
            if not (has_submit and has_reset and has_image):
                fails.append(f"Gap1: missing types: submit={has_submit}, reset={has_reset}, image={has_image}")
            else:
                # input[type=image] without alt should be flagged
                img_input = next(i for i in scan["items"] if i.get("input_type") == "image")
                if "image_input_no_alt" not in img_input["flags"]:
                    fails.append(f"Gap1: input[type=image] missing alt not flagged: {img_input}")
                else:
                    print(f"        ✓ all input button types scanned + image-no-alt flagged")
        await browser_tools.browser_close(mgr, sid)

        # ===================================================================
        # Gap 2 — text_snapshot shows non-interactive content
        # ===================================================================
        s = await browser_tools.browser_open(mgr, url=LOCKED_OUT_HTML, headless=True)
        sid = s["session_id"]
        state = await browser_tools.browser_get_state(mgr, sid)
        print(f"[Gap 2] text_snapshot keys: text_snapshot present? "
              f"{state.get('text_snapshot') is not None}")
        snap = state.get("text_snapshot") or ""
        if "locked out" not in snap:
            fails.append(f"Gap2: text_snapshot didn't capture error message: {snap[:200]}")
        else:
            print(f"        ✓ text_snapshot caught: '{snap[:100]}...'")
        # text_snapshot_chars=0 should disable
        state_no_snap = await browser_tools.browser_get_state(mgr, sid, text_snapshot_chars=0)
        if state_no_snap.get("text_snapshot") is not None:
            fails.append(f"Gap2: text_snapshot_chars=0 didn't disable: {state_no_snap.get('text_snapshot')}")
        else:
            print(f"        ✓ text_snapshot_chars=0 disables capture")
        await browser_tools.browser_close(mgr, sid)

        # ===================================================================
        # Gap 3 — browser_open returns redirect_chain
        # ===================================================================
        s = await browser_tools.browser_open(
            mgr, url="https://httpbin.org/redirect/2", headless=True,
        )
        print(f"[Gap 3] browser_open keys: {sorted(s.keys())}")
        if "redirect_chain" not in s:
            fails.append("Gap3: browser_open missing redirect_chain")
        elif "redirect_count" not in s:
            fails.append("Gap3: browser_open missing redirect_count")
        elif s["redirect_count"] < 1:
            print(f"        ⚠ redirect_count={s['redirect_count']} (network may be flaky): {s}")
        else:
            print(f"        ✓ browser_open returned {s['redirect_count']} redirect hops "
                  f"(consistent with browser_navigate)")
        await browser_tools.browser_close(mgr, s["session_id"])

        # Direct URL — chain should be empty (not missing)
        s2 = await browser_tools.browser_open(
            mgr, url="data:text/html,<h1>direct</h1>", headless=True,
        )
        if s2.get("redirect_chain") != []:
            fails.append(f"Gap3: empty chain expected for direct URL, got {s2.get('redirect_chain')}")
        elif s2.get("redirect_count") != 0:
            fails.append(f"Gap3: direct URL count != 0: {s2}")
        else:
            print(f"        ✓ direct URL returns empty chain (not missing)")
        await browser_tools.browser_close(mgr, s2["session_id"])

    finally:
        await mgr.close_all()

    if fails:
        print("\n❌ FAILURES:")
        for f in fails:
            print(f"   - {f}")
        sys.exit(1)
    print("\n✅ ALL ROUND 5 GAPS CLOSED")


if __name__ == "__main__":
    asyncio.run(main())
