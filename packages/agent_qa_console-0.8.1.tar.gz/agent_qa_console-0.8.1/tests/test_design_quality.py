"""Integration tests for qa_design_quality_check.

Uses `data:text/html` URLs with hand-crafted fragments that trigger specific
anti-patterns; asserts that the corresponding finding fires (or doesn't, for
the negative cases).
"""
import sys
from pathlib import Path
from urllib.parse import quote

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from qa_mcp.browser import SessionManager
from qa_mcp.tools import browser_tools, qa_tools


pytestmark = pytest.mark.asyncio


def _data_url(body: str) -> str:
    full = (
        "<!doctype html><html><head><meta charset='utf-8'>"
        "<title>Test</title></head><body>" + body + "</body></html>"
    )
    return "data:text/html;charset=utf-8," + quote(full)


async def _audit(body: str, detail: str = "full") -> dict:
    """Open a fresh session with `body`, run design-quality, close, return result."""
    mgr = SessionManager()
    try:
        opened = await browser_tools.browser_open(mgr, url=_data_url(body), headless=True)
        sid = opened["session_id"]
        try:
            return await qa_tools.qa_design_quality_check(mgr, sid, detail=detail)
        finally:
            await browser_tools.browser_close(mgr, sid)
    finally:
        await mgr.close_all()


# ---------- happy path: clean design = no findings ----------


async def test_clean_minimal_page_has_zero_findings():
    body = """
    <header><h1 style='text-align:left;font-family:Georgia,serif'>Specific product, specific audience</h1></header>
    <main><article><p>Detailed content paragraph with substance.</p></article></main>
    """
    result = await _audit(body)
    assert result["summary"]["total"] == 0
    assert result["summary"]["score"] == 100
    assert result["summary"]["grade"] == "A"


# ---------- per-rule triggers ----------


async def test_rule_1_purple_gradient_triggers():
    body = """
    <header style='background:linear-gradient(135deg,rgb(120,80,200),rgb(180,90,220))'>
      <h1 style='font-family:Inter'>Welcome</h1>
    </header>
    <main><p>Body</p></main>
    """
    result = await _audit(body)
    cats = {f["category"] for f in result["findings"]}
    assert "ai_slop_purple_gradient" in cats


async def test_rule_2_3col_feature_grid_triggers():
    body = """
    <h1 style='font-family:Georgia,serif'>Specific claim about product</h1>
    <section style='display:flex'>
      <div><div style='background:rgb(200,100,200);border-radius:30px;padding:8px;display:inline-block'><svg width='24' height='24'><circle r='10'/></svg></div><h3>Feature A</h3><p>Description A line goes here</p></div>
      <div><div style='background:rgb(100,200,200);border-radius:30px;padding:8px;display:inline-block'><svg width='24' height='24'><circle r='10'/></svg></div><h3>Feature B</h3><p>Description B line goes here</p></div>
      <div><div style='background:rgb(200,200,100);border-radius:30px;padding:8px;display:inline-block'><svg width='24' height='24'><circle r='10'/></svg></div><h3>Feature C</h3><p>Description C line goes here</p></div>
    </section>
    """
    result = await _audit(body)
    cats = {f["category"] for f in result["findings"]}
    assert "ai_slop_3col_feature_grid" in cats


async def test_rule_4_centered_everything_triggers():
    body = """
    <h1 style='text-align:center;font-family:Georgia,serif'>Title</h1>
    <h2 style='text-align:center;font-family:Georgia,serif'>Subtitle one</h2>
    <h2 style='text-align:center;font-family:Georgia,serif'>Subtitle two</h2>
    <h3 style='text-align:center;font-family:Georgia,serif'>Subtitle three</h3>
    """
    result = await _audit(body)
    cats = {f["category"] for f in result["findings"]}
    assert "ai_slop_centered_everything" in cats


async def test_rule_6_emoji_in_headings_triggers():
    body = """
    <h1 style='font-family:Georgia,serif'>\U0001F680 Rocket headline</h1>
    <h2 style='font-family:Georgia,serif'>⚡ Lightning section</h2>
    """
    result = await _audit(body)
    cats = {f["category"] for f in result["findings"]}
    assert "ai_slop_emoji_in_headings" in cats


async def test_rule_8_generic_hero_copy_triggers():
    body = """
    <h1 style='font-family:Georgia,serif'>Welcome to ACME — Your all-in-one solution</h1>
    <p>Body content</p>
    """
    result = await _audit(body)
    cats = {f["category"] for f in result["findings"]}
    assert "ai_slop_generic_hero_copy" in cats


async def test_rule_8_specific_hero_copy_passes():
    body = """
    <h1 style='font-family:Georgia,serif'>Linear is shaped by the practices and principles of fast-moving teams</h1>
    <p>Body content</p>
    """
    result = await _audit(body)
    cats = {f["category"] for f in result["findings"]}
    assert "ai_slop_generic_hero_copy" not in cats


async def test_rule_9_system_ui_font_triggers():
    body = """
    <h1 style='font-family:system-ui'>Title</h1>
    <p>Body</p>
    """
    result = await _audit(body)
    cats = {f["category"] for f in result["findings"]}
    assert "ai_slop_system_ui_font" in cats


async def test_rule_7_colored_left_border_cards_triggers():
    body = """
    <h1 style='font-family:Georgia,serif'>Specific title</h1>
    <article style='border-left:3px solid rgb(120,80,200);padding:12px'>Card 1</article>
    <article style='border-left:3px solid rgb(120,80,200);padding:12px'>Card 2</article>
    <article style='border-left:3px solid rgb(120,80,200);padding:12px'>Card 3</article>
    """
    result = await _audit(body)
    cats = {f["category"] for f in result["findings"]}
    assert "ai_slop_left_border_cards" in cats


# ---------- structural assertions ----------


async def test_findings_have_required_fields():
    body = """
    <header style='background:linear-gradient(135deg,rgb(120,80,200),rgb(180,90,220))'>
      <h1 style='font-family:system-ui'>Welcome to product</h1>
    </header>
    """
    result = await _audit(body)
    assert len(result["findings"]) >= 1
    for f in result["findings"]:
        assert "id" in f
        assert "severity" in f
        assert "category" in f
        assert "title" in f
        assert "hint" in f
        assert "positive_reference" in f
        assert 0 <= f["confidence"] <= 1


async def test_summary_score_grade_verdict():
    body = """
    <header style='background:linear-gradient(135deg,rgb(120,80,200),rgb(180,90,220))'>
      <h1 style='text-align:center;font-family:system-ui'>Welcome to ACME — Your all-in-one solution \U0001F680</h1>
      <h2 style='text-align:center;font-family:system-ui'>⚡ Lightning fast</h2>
      <h3 style='text-align:center;font-family:system-ui'>Generic feature</h3>
    </header>
    """
    result = await _audit(body)
    s = result["summary"]
    assert 0 <= s["score"] <= 100
    assert s["grade"] in ("A", "B", "C", "D", "F")
    assert isinstance(s["verdict"], str)
    # heavy slop → expect score below 75
    assert s["score"] < 75


async def test_detail_summary_drops_findings_list():
    body = "<h1 style='font-family:system-ui'>Welcome to ACME</h1>"
    result = await _audit(body, detail="summary")
    assert "findings" not in result  # dropped by _trim_for_detail
    assert "_truncated" in result
    assert "summary" in result
