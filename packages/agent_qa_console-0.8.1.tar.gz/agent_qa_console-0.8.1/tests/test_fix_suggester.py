"""Unit tests for qa_mcp.tools.fix_suggester — pure helpers + suggest_fixes."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from qa_mcp.tools.fix_suggester import (
    _CTA_HEBREW,
    _disambiguate_date,
    _fix_currency_position,
    _fix_plural,
    _translate_cta,
    fix_summary,
    suggest_fixes,
    wrap_latin_digits_in_bdi,
)


# ----------------- private helpers -----------------


def test_translate_cta_exact_match():
    assert _translate_cta("Get Started") == "התחל"
    assert _translate_cta("sign up") == "הרשם"
    assert _translate_cta("checkout") == "לתשלום"


def test_translate_cta_partial_match_prefers_longest():
    # "free trial" is longer than "free" or "trial" — should match
    out = _translate_cta("Start your free trial now")
    assert out == "ניסיון חינם"


def test_translate_cta_unknown_returns_none():
    assert _translate_cta("xyz qwerty") is None


def test_fix_plural_singular_form():
    out = _fix_plural("1 פריטים")
    assert out["fixable"] is True
    assert "1" in out["after"]
    assert out["confidence"] > 0


def test_fix_plural_dual_form():
    out = _fix_plural("2 פריטים")
    assert out["fixable"] is True
    assert out["after"].endswith("יים")


def test_fix_plural_many_form():
    out = _fix_plural("5 פריטים")
    assert out["fixable"] is True
    assert out["before"] == "5 פריטים"
    assert out["after"] == "5 פריטים"


def test_fix_plural_unparseable():
    out = _fix_plural("פריטים בלבד")
    assert out["fixable"] is False
    assert "reason" in out


def test_disambiguate_date_valid_dd_mm():
    out = _disambiguate_date("המבצע נגמר ב-03/04/2026 בלבד")
    assert out["fixable"] is True
    assert "באפריל" in out["after"]
    assert "2026" in out["after"]


def test_disambiguate_date_no_match():
    assert _disambiguate_date("שום תאריך כאן")["fixable"] is False


def test_wrap_latin_digits_in_bdi_simple():
    assert wrap_latin_digits_in_bdi("יש 3 פריטים") == "יש <bdi>3</bdi> פריטים"
    # Word-boundary regex wraps the digits; % stays outside (current behavior)
    assert wrap_latin_digits_in_bdi("5.5 שעות") == "<bdi>5.5</bdi> שעות"


def test_wrap_latin_digits_multiple_runs():
    out = wrap_latin_digits_in_bdi("בין 5 ל-10 ימים")
    assert "<bdi>5</bdi>" in out
    assert "<bdi>10</bdi>" in out


def test_fix_currency_position_basic_and_thousands():
    assert _fix_currency_position("₪99") == "99 ₪"
    assert _fix_currency_position("₪ 1,249") == "1,249 ₪"
    assert _fix_currency_position("99 ₪") is None  # already right


# ----------------- suggest_fixes — one finding per category -----------------


def _f(category, **extra):
    base = {"category": category, "sample": "", "selector": ".x", "title": "t"}
    base.update(extra)
    return base


def test_suggest_fixes_rtl_digits():
    out = suggest_fixes([_f("rtl_digits", sample="יש 3 פריטים")])
    assert len(out) == 1
    assert out[0]["fix_type"] == "wrap_bdi"
    assert "<bdi>3</bdi>" in out[0]["after"]
    assert out[0]["requires_review"] is False


def test_suggest_fixes_rtl_currency_with_and_without_match():
    # Match path
    out = suggest_fixes([_f("rtl_currency", sample="₪99")])
    assert len(out) == 1
    assert out[0]["after"] == "99 ₪"
    # No-match → no suggestion
    out2 = suggest_fixes([_f("rtl_currency", sample="99 ₪")])
    assert out2 == []


def test_suggest_fixes_arrow_direction():
    out = suggest_fixes([_f("rtl_arrow_direction", sample="הבא →")])
    assert out[0]["after"] == "הבא ←"
    # No arrow → no suggestion
    out2 = suggest_fixes([_f("rtl_arrow_direction", sample="הבא")])
    assert out2 == []


def test_suggest_fixes_english_cta_translatable_and_not():
    out = suggest_fixes([_f("rtl_english_cta", sample="Get Started")])
    assert out[0]["after"] == "התחל"
    assert out[0]["requires_review"] is True

    out2 = suggest_fixes([_f("rtl_english_cta", sample="qwerty xyz")])
    assert out2[0]["after"].startswith("[HE:")
    assert out2[0]["confidence"] < 0.5


def test_suggest_fixes_english_placeholder():
    out = suggest_fixes([_f("rtl_english_placeholder", sample="Enter email")])
    assert out[0]["fix_type"] == "text_replace"
    assert out[0]["after"].startswith("[HE:")


def test_suggest_fixes_dir_missing_always():
    out = suggest_fixes([_f("rtl_dir_missing")])
    assert out[0]["fix_type"] == "add_attribute"
    assert "dir='rtl'" in out[0]["after"]
    assert out[0]["confidence"] >= 0.99


def test_suggest_fixes_plural_and_date_and_latin_mixed():
    out = suggest_fixes([
        _f("rtl_plural", sample="1 פריטים"),
        _f("rtl_date_ambiguous", sample="03/04/2026"),
        _f("rtl_latin_mixed", sample="Click here"),
    ])
    by_cat = {s["category"]: s for s in out}
    assert "rtl_plural" in by_cat
    assert "rtl_date_ambiguous" in by_cat
    assert by_cat["rtl_latin_mixed"]["after"] == "<bdi>Click here</bdi>"


def test_suggest_fixes_unknown_category_produces_no_suggestion():
    out = suggest_fixes([_f("rtl_unknown_kind", sample="x")])
    assert out == []


def test_suggest_fixes_unfixable_plural_skipped():
    out = suggest_fixes([_f("rtl_plural", sample="not parseable")])
    assert out == []


def test_suggest_fixes_unfixable_date_skipped():
    out = suggest_fixes([_f("rtl_date_ambiguous", sample="no date here")])
    assert out == []


# ----------------- fix_summary -----------------


def test_fix_summary_groups_and_averages():
    suggestions = [
        {"category": "a", "requires_review": False, "confidence": 0.9},
        {"category": "a", "requires_review": True, "confidence": 0.6},
        {"category": "b", "requires_review": False, "confidence": 0.8},
    ]
    out = fix_summary(suggestions)
    assert out["total_suggestions"] == 3
    assert out["auto_fixable"] == 2
    assert out["needs_review"] == 1
    assert out["by_category"] == {"a": 2, "b": 1}
    assert 0.76 <= out["avg_confidence"] <= 0.77


def test_fix_summary_empty_zero_avg():
    out = fix_summary([])
    assert out["total_suggestions"] == 0
    assert out["avg_confidence"] == 0.0


def test_cta_dictionary_has_known_entries():
    assert "submit" in _CTA_HEBREW
    assert "checkout" in _CTA_HEBREW
