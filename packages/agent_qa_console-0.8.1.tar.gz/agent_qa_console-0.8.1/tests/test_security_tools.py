"""Unit tests for qa_mcp.tools.security_tools — pure helpers + check_* (no network)."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from qa_mcp.tools.security_tools import (
    EXPOSED_PATHS,
    HEADER_FIXES,
    SECURITY_HEADERS,
    SecFinding,
    _check_cookies,
    _check_email,
    _check_headers,
    _check_html,
    _finding,
    _grade,
    _score,
    _version_lt,
    _txt_records,
)


def test_sec_finding_to_dict_roundtrip():
    f = SecFinding("high", "ssl", "T", "D", remediation="R", url="https://x", evidence="e")
    d = f.to_dict()
    assert d["severity"] == "high"
    assert d["category"] == "ssl"
    assert d["url"] == "https://x"


def test_finding_constructor():
    f = _finding("low", "x", "title", "detail")
    assert f.severity == "low"
    assert f.category == "x"


def test_grade_boundaries():
    assert _grade(100) == "A"
    assert _grade(90) == "A"
    assert _grade(89) == "B"
    assert _grade(75) == "B"
    assert _grade(60) == "C"
    assert _grade(40) == "D"
    assert _grade(0) == "F"


def test_score_penalizes_severities():
    findings = [
        _finding("critical", "x", "t", "d"),  # 25
        _finding("high", "x", "t", "d"),  # 15
        _finding("medium", "missing_header", "t", "d"),  # 5 (not 8)
        _finding("low", "x", "t", "d"),  # 3
        _finding("info", "x", "t", "d"),  # 0
    ]
    score, grade = _score(findings)
    assert score == 100 - 25 - 15 - 5 - 3
    assert grade == _grade(score)


def test_score_floors_at_zero():
    findings = [_finding("critical", "x", "t", "d") for _ in range(20)]
    score, grade = _score(findings)
    assert score == 0
    assert grade == "F"


def test_check_headers_flags_missing_csp_and_hsts_high():
    out = _check_headers({"X-Frame-Options": "DENY"})
    titles = [f.title for f in out]
    assert any("Content-Security-Policy" in t for t in titles)
    assert any("Strict-Transport-Security" in t for t in titles)
    # CSP and HSTS should be high
    by_title = {f.title: f for f in out}
    assert by_title[f"Missing Content-Security-Policy"].severity == "high"
    assert by_title[f"Missing Strict-Transport-Security"].severity == "high"


def test_check_headers_server_and_xpoweredby_disclosure():
    out = _check_headers({h: "x" for h in SECURITY_HEADERS})
    out_with_server = _check_headers({**{h: "x" for h in SECURITY_HEADERS},
                                       "Server": "nginx/1.18.0", "X-Powered-By": "PHP/8.1"})
    assert any(f.category == "info_disclosure" for f in out_with_server)
    # Version-bearing Server header → medium
    sev_server = [f.severity for f in out_with_server
                  if f.title == "Server header exposed"][0]
    assert sev_server == "medium"
    # No info disclosure when no server/x-powered-by
    assert not any(f.category == "info_disclosure" for f in out)


def test_check_headers_hsts_short_maxage_and_no_subdomains():
    out = _check_headers({**{h: "x" for h in SECURITY_HEADERS},
                          "Strict-Transport-Security": "max-age=3600"})
    assert any("HSTS max-age too short" in f.title for f in out)
    assert any("includeSubDomains" in f.title for f in out)


def test_check_cookies_missing_flags():
    out = _check_cookies({"Set-Cookie": "session=abc"})
    assert len(out) == 1
    f = out[0]
    assert "Cookie 'session'" in f.title
    for flag in ("HttpOnly", "Secure", "SameSite"):
        assert flag in f.detail


def test_check_cookies_all_flags_present():
    out = _check_cookies({"Set-Cookie": "session=abc; HttpOnly; Secure; SameSite=Lax"})
    assert out == []


def test_check_cookies_ignores_non_cookie_headers():
    out = _check_cookies({"Content-Type": "text/html"})
    assert out == []


def test_check_html_mixed_content_https_only():
    html = '<img src="http://insecure.example/x.png"><script src="https://ok"></script>'
    out = _check_html(html, "https://example.com")
    assert any(f.category == "mixed_content" for f in out)
    # On HTTP base url, mixed content check skipped
    out_http = _check_html(html, "http://example.com")
    assert not any(f.category == "mixed_content" for f in out_http)


def test_check_html_meta_csp_flagged_as_info():
    html = '<meta http-equiv="Content-Security-Policy" content="default-src self">'
    out = _check_html(html, "https://x")
    assert any(f.category == "csp" for f in out)


def test_check_html_generator_version_disclosure():
    html = '<meta name="generator" content="WordPress 6.2.1">'
    out = _check_html(html, "https://x")
    assert any(f.category == "info_disclosure" for f in out)


def test_check_html_outdated_jquery():
    html = '<script src="/js/jquery-1.7.0.min.js"></script>'
    out = _check_html(html, "https://x")
    assert any("jQuery" in f.title for f in out)


def test_check_html_safe_jquery_not_flagged():
    html = '<script src="/js/jquery-3.7.0.min.js"></script>'
    out = _check_html(html, "https://x")
    assert not any("jQuery" in f.title for f in out)


def test_version_lt():
    assert _version_lt("1.7.0", "3.5.0") is True
    assert _version_lt("3.5.0", "3.5.0") is False
    assert _version_lt("3.7.1", "3.5.0") is False
    # Malformed version → False (safe default)
    assert _version_lt("abc", "1.0") is False


def test_txt_records_returns_empty_on_no_dnspython_or_failure(monkeypatch):
    # Simulate dnspython missing by patching dns.resolver.Resolver to raise
    import builtins
    real_import = builtins.__import__

    def fake_import(name, *args, **kwargs):
        if name.startswith("dns."):
            raise ImportError("no dns")
        return real_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", fake_import)
    assert _txt_records("example.com") == []


def test_check_email_no_records_emits_warnings(monkeypatch):
    # No DNS available → both SPF and DMARC unverified
    monkeypatch.setattr("qa_mcp.tools.security_tools._txt_records", lambda name: [])
    out = _check_email("example.com")
    categories = {f.category for f in out}
    assert "email_security" in categories
    titles = {f.title for f in out}
    assert any("SPF" in t for t in titles)
    assert any("DMARC" in t for t in titles)


def test_check_email_with_spf_and_dmarc(monkeypatch):
    def fake_txt(name):
        if name == "example.com":
            return ["v=spf1 include:_spf.google.com -all"]
        if name == "_dmarc.example.com":
            return ["v=DMARC1; p=reject"]
        return []
    monkeypatch.setattr("qa_mcp.tools.security_tools._txt_records", fake_txt)
    out = _check_email("example.com")
    # Neither missing-SPF nor missing-DMARC should fire
    titles = {f.title for f in out}
    assert "No SPF record" not in titles
    assert "No DMARC record" not in titles


def test_check_email_records_exist_but_no_spf_or_dmarc(monkeypatch):
    def fake_txt(name):
        if name == "example.com":
            return ["some random txt"]
        if name == "_dmarc.example.com":
            return ["random non-dmarc"]
        return []
    monkeypatch.setattr("qa_mcp.tools.security_tools._txt_records", fake_txt)
    out = _check_email("example.com")
    assert any(f.title == "No SPF record" for f in out)
    assert any(f.title == "No DMARC record" for f in out)


def test_constants_well_formed():
    assert "Content-Security-Policy" in SECURITY_HEADERS
    assert "Strict-Transport-Security" in SECURITY_HEADERS
    assert all(h in HEADER_FIXES for h in SECURITY_HEADERS)
    assert "/.env" in EXPOSED_PATHS
