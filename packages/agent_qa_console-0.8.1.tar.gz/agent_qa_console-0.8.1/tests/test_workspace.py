from __future__ import annotations

import json
import urllib.request
import asyncio
from pathlib import Path

from qa_mcp import server
from qa_mcp.workspace import workspace


def _get_json(url: str) -> dict:
    with urllib.request.urlopen(url, timeout=5) as res:  # noqa: S310 - local test server
        return json.loads(res.read().decode("utf-8"))


def test_workspace_server_snapshot(tmp_path: Path) -> None:
    try:
        workspace.reset(title="test workspace")
        info = workspace.start(port=0, open_browser=False)
        assert info["ok"] is True
        assert info["url"].startswith("http://127.0.0.1:")

        workspace.start_fix_loop("Verify signup flow", target="/signup")
        workspace.add_loop_step("testing", "Open signup page", status="running")
        workspace.set_phase("testing", summary="Smoke test console")
        workspace.set_intent("Inspect signup form", risk="read-only")
        workspace.emit("test", "hello", {"x": 1})
        workspace.add_finding("Broken label", severity="medium", selector="#email")
        image = tmp_path / "shot.jpg"
        image.write_bytes(b"fake image bytes")
        workspace.add_screenshot(str(image), label="Proof")

        snap = _get_json(info["url"] + "api/session")
        assert snap["title"] == "test workspace"
        assert snap["phase"]["phase"] == "testing"
        assert snap["fix_loop"]["goal"] == "Verify signup flow"
        assert snap["fix_loop"]["steps"][-1]["summary"] == "Open signup page"
        assert snap["intent"]["summary"] == "Inspect signup form"
        assert any(ev["message"] == "hello" for ev in snap["events"])
        assert snap["findings"][-1]["title"] == "Broken label"
        assert snap["screenshots"][-1]["label"] == "Proof"

        report = urllib.request.urlopen(info["url"] + "api/report.md", timeout=5).read().decode("utf-8")  # noqa: S310
        assert "# Agent QA Console" in report
        assert "Verify signup flow" in report
        assert "Smoke test console" in report
        assert "Inspect signup form" in report
        assert "Broken label" in report
        assert "Proof" in report
    finally:
        workspace.stop()


def test_console_tools_accept_pi_injected_session_id() -> None:
    async def run() -> None:
        try:
            opened = await server.qa_console_open(
                title="bridge injection test",
                open_browser=False,
                reset=True,
                session_id="dummy-session",
            )
            assert opened["ok"] is True
            event = await server.qa_console_event("hello", session_id="dummy-session")
            assert event["message"] == "hello"
            status = await server.qa_console_status(session_id="dummy-session")
            assert status["running"] is True
            closed = await server.qa_console_close(session_id="dummy-session")
            assert closed["stopped"] is True
        finally:
            workspace.stop()

    asyncio.run(run())


def test_workspace_approval_answer() -> None:
    try:
        workspace.reset(title="approval test")
        workspace.start(port=0, open_browser=False)
        approval = workspace.ask_approval_nowait("Continue?", choices=["approve", "reject"])
        assert approval["status"] == "pending"

        snap = _get_json(workspace.url + "api/session")
        assert snap["approvals"][-1]["id"] == approval["id"]

        data = json.dumps({"answer": "approve", "note": "Looks safe"}).encode("utf-8")
        req = urllib.request.Request(
            workspace.url + f"api/approval/{approval['id']}",
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=5) as res:  # noqa: S310 - local test server
            out = json.loads(res.read().decode("utf-8"))
        assert out["ok"] is True
        assert out["approval"]["answer"] == "approve"
        assert out["approval"]["note"] == "Looks safe"
    finally:
        workspace.stop()
