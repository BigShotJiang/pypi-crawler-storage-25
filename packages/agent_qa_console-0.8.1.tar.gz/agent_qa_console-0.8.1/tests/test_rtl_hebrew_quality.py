"""Golden Hebrew/RTL quality checks.

These tests guard the commercial QA use-case: clean Hebrew content should stay
quiet, while deterministic RTL/localization bugs should be client-safe and carry
evidence/confidence metadata.
"""
import asyncio
import sys
from pathlib import Path
from urllib.parse import quote

try:
    import pytest
    pytestmark = pytest.mark.asyncio
except ModuleNotFoundError:  # Allow running as a standalone smoke script in lean venvs.
    pytestmark = None

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from qa_mcp.browser import SessionManager
from qa_mcp.tools import browser_tools, qa_tools


def data_url(html: str) -> str:
    return "data:text/html;charset=utf-8," + quote(html)


CLEAN_HEBREW = """<!doctype html>
<html lang="he" dir="rtl"><body>
  <h1>בדיקת עברית תקינה</h1>
  <p id="count">יש לך 3 הודעות חדשות</p>
  <p id="phone">מוקד טלפוני 1299</p>
  <p id="time">שעות פעילות 09:00-17:00</p>
  <p id="version">גרסה v1.2.3</p>
  <p id="currency">מחיר: 99 ₪ בלבד</p>
  <a id="arrow" href="#">המשך ←</a>
  <input id="ph" placeholder="כתובת אימייל">
  <button id="cta">התחלה</button>
  <p id="plural1">1 פריט בעגלה</p>
  <p id="plural2">2 פריטים נבחרו</p>
  <time id="date">2026-04-03</time>
</body></html>"""

BAD_HEBREW = """<!doctype html>
<html lang="he"><body>
  <p id="currency">מחיר: ₪99 בלבד</p>
  <a id="arrow" href="#">המשך →</a>
  <input id="ph" placeholder="Enter your email">
  <button id="cta">Start now</button>
  <p id="plural1">1 פריטים בעגלה</p>
  <p id="plural2">2 פריט נבחרו</p>
  <p id="date">תאריך: 03/04/2026</p>
</body></html>"""

BORDERLINE_HEBREW = """<!doctype html>
<html lang="he" dir="rtl"><body>
  <p id="program">תוכנית 1 זמינה</p>
  <p id="mixed">מוצר Alpha חדש</p>
</body></html>"""

REALISTIC_HEBREW_NUMBERS = """<!doctype html>
<html lang="he" dir="rtl"><body>
  <p id="minutes">279.8 דקות</p>
  <p id="rating">4.9/5 · 150+ ביקורות</p>
  <p id="speaker1">דובר 1 · 00:12</p>
  <p id="speaker2">דובר 2 · 01:03</p>
  <p id="recordings">12 הקלטות</p>
  <p id="ready">8 מוכנים</p>
  <p id="percent">דיוק 97%</p>
  <p id="seconds">0 שניות</p>
</body></html>"""


async def _audit(html: str, **kwargs):
    mgr = SessionManager()
    try:
        opened = await browser_tools.browser_open(
            mgr,
            url=data_url(html),
            headless=True,
            locale="he-IL",
            timezone="Asia/Jerusalem",
        )
        sid = opened["session_id"]
        try:
            return await qa_tools.qa_rtl_audit(mgr, sid, detail="full", **kwargs)
        finally:
            await browser_tools.browser_close(mgr, sid)
    finally:
        await mgr.close_all()


async def test_clean_hebrew_has_zero_findings():
    result = await _audit(CLEAN_HEBREW)
    assert result["summary"]["total"] == 0
    assert result["summary"]["review_required_total"] == 0
    assert result["findings"] == []


async def test_bad_hebrew_has_client_safe_evidence():
    result = await _audit(BAD_HEBREW, report_mode="internal_full")
    cats = {f["category"] for f in result["findings"]}
    assert "rtl_currency" not in cats, "₪ before the number is common Israeli styling, not a default RTL bug"
    assert {
        "rtl_english_placeholder",
        "rtl_arrow_direction",
        "rtl_dir_missing",
        "rtl_plural",
        "rtl_date_ambiguous",
    }.issubset(cats)

    for finding in result["findings"]:
        assert "confidence" in finding
        assert "client_safe" in finding
        assert "review_required" in finding
        assert finding.get("evidence", {}).get("sample")
        assert finding.get("evidence", {}).get("selector")

    client_safe = await _audit(BAD_HEBREW, report_mode="client_safe")
    client_cats = {f["category"] for f in client_safe["findings"]}
    # Lower-confidence/date/English CTA advice stays in the review queue, not
    # in automated client-safe output.
    assert "rtl_date_ambiguous" not in client_cats
    assert "rtl_english_cta" not in client_cats
    assert "rtl_currency" not in client_cats
    assert "rtl_dir_missing" in client_cats
    assert "rtl_plural" in client_cats
    assert client_safe["summary"]["raw_total"] >= client_safe["summary"]["total"]
    assert client_safe["summary"]["review_required_total"] >= 1


async def test_borderline_bidi_goes_to_review_not_client_report():
    internal = await _audit(BORDERLINE_HEBREW, report_mode="internal_full")
    assert internal["summary"]["review_required_total"] >= 1
    assert all(not f["client_safe"] for f in internal["findings"])

    client_safe = await _audit(BORDERLINE_HEBREW, report_mode="client_safe")
    assert client_safe["summary"]["total"] == 0
    assert client_safe["summary"]["raw_total"] >= 1


async def test_realistic_hebrew_numbers_are_not_rtl_bugs():
    result = await _audit(REALISTIC_HEBREW_NUMBERS, report_mode="internal_full")
    digit_findings = [f for f in result["findings"] if f["category"] == "rtl_digits"]
    assert digit_findings == []

    client_safe = await _audit(REALISTIC_HEBREW_NUMBERS, report_mode="client_safe")
    assert client_safe["summary"]["total"] == 0


def main():
    asyncio.run(test_clean_hebrew_has_zero_findings())
    asyncio.run(test_bad_hebrew_has_client_safe_evidence())
    asyncio.run(test_borderline_bidi_goes_to_review_not_client_report())
    asyncio.run(test_realistic_hebrew_numbers_are_not_rtl_bugs())
    print("✅ RTL Hebrew golden tests passed")


if __name__ == "__main__":
    main()
