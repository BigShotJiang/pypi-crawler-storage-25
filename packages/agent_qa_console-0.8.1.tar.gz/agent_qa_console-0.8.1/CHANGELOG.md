# Changelog

All notable changes to qa-mcp.

## [Unreleased] — Agent DX improvements

Surfaced from a real Claude session against demoqa.com / uitestingplayground.com
where the calling agent kept hitting the same friction points. Each change
removes a workaround the agent had to invent.

### Added

- **`browser_get_state` scoping params** (`scope`, `exclude`, `max_elements`).
  On dense pages (sidebars with 100+ links, marketing footers), the full
  snapshot was breaching the 30K-token output cap, forcing the agent to
  fall back to raw `evaluate` + jq scraping. Pass `scope="form"` /
  `exclude="nav, footer"` / `max_elements=50` to stay inside the budget.
  Result includes `truncated: true` and `scope_applied` when used.
- **`browser_fill_form`** — bulk form filler that sidesteps the React trap
  where `el.value = "x"` is silently dropped because React's tracker
  doesn't see prototype-level changes. Calls the native HTMLInputElement
  setter and dispatches input+change. Handles input/textarea/select/
  checkbox/radio (incl. clicking `<label>` for checkbox lists),
  contenteditable, and bool toggles. Returns per-field results so the
  agent can see exactly which selector failed instead of guessing.
- **`browser_evaluate(frame_chain=[...])`** — descend into nested iframes
  by selector path. Saves writing
  `parent.contentDocument.querySelector('iframe').contentDocument…`
  by hand. Bad chains report `step N (sel): no element matched` instead
  of crashing.

### Changed

- `INDEX_INTERACTIVE_JS` now returns `{elements, truncated, totalCandidates}`
  instead of a bare list. `qa_form_smart_fill` was updated to match. If
  any out-of-tree caller imports `INDEX_INTERACTIVE_JS` directly, switch
  to `payload["elements"]`.

## [0.8.0] — 2026-05-04 — The Agent-first release

Closing the gap from interactive QA tool to agent-driven auditing platform.
Tool count: 35 → **53**. The agent now drives the entire QA lifecycle —
discover pages, run audits, create reports, open GitHub issues, analyze competitors,
and train fix-suggester models on captured data.

### Added — Discovery + Form helpers

- **`qa_find_text`** — Find DOM elements by visible text. Returns stable `index`
  values for click/type/scroll. Fuzzy matching, case-insensitive. Saves
  agents from writing `document.querySelector` manually.
- **`qa_form_inventory`** — List every form on the page with field types, labels,
  and guessed semantic purpose. Also surfaces `orphan_fields` outside `<form>`
  tags (common in React/SPA forms missed by form-scoped scans).

### Added — Flow automation

- **`qa_login_with_credentials`** — Login with known test credentials.
  Auto-detects username/password/submit fields; accepts optional CSS selectors.
- **`qa_flow_runner`** — Run explicit multi-step browser flows: type,
  type_selector, click, click_text, click_selector, select, wait_text,
  assert_text, assert_url, logs, screenshot, get_state. Sequential execution
  guarantees no races between steps.

### Added — Product/UX intelligence

- **`qa_tech_stack_detect`** — Detect frontend framework, UI/CSS libraries,
  animation libs, analytics, builders/CMS. Heuristic with confidence and evidence.
- **`qa_design_interaction_scan`** — Scan for animations, transitions,
  sticky/fixed widgets, chat/cookie/accessibility widgets, language/theme
  toggles, canvas/video/svg/picture/iframe media.
- **`qa_form_risk_audit`** — Form UX/risk audit: labels, autocomplete,
  GET vs POST, privacy consent, required fields.
- **`qa_inspiration_analyze_url`** — Analyze a website for inspiration without
  copying: extract abstract UX/design patterns, CTA placement, section structure.
  Returns what to adapt vs what not to copy.
- **`qa_originality_check`** — Compare inspiration source and draft site for
  similarity risk. Heuristic originality guardrail (copy overlap, structure,
  color signals). Not legal advice.

### Added — Agent-first orchestration

- **`qa_agent_explore_site`** — Discover important internal pages automatically
  (home, Hebrew, pricing, contact, login/signup, legal/docs), run multi-page QA
  suite, emit reports. Use when the user says "QA the whole site" without config.
- **`qa_agent_test_flow`** — High-level flow smoke test: inventory forms, form
  risk audit, smart-fill synthetic data, check browser logs. `submit=False` by
  default to avoid real leads/orders.
- **`qa_agent_audit_url`** — One-call full QA. Builds suite automatically, runs
  desktop+mobile, emits HTML/MD/JSON/issues reports. Use when the user says
  "QA this site" without writing config.

### Added — Security

- **`qa_security_passive_audit`** — Passive security audit: headers, TLS
  certificate, cookie flags, mixed content, exposed sensitive paths, CORS
  reflection, security.txt, optional SPF/DMARC DNS records. No active
  exploitation, no port scanning.

### Added — Client reports + GitHub integration

- **`qa_client_report`** — Create a polished client-facing ZIP report from
  `qa-result.json`. Self-contained Hebrew HTML report with embedded screenshots,
  Markdown summary, JSON, and issue files.
- **`qa_github_create_issues`** — Create real GitHub Issues from `qa-result.json`
  with automatic labels, deduplication via qa-mcp fingerprint, and optional
  commenting on existing open issues.

### Added — Training data pipeline

- **`qa_training_stats`** — Summarize captured training corpus: runs, unique
  hosts, by task, by language, ready-for-training flag (≥100 runs).
- **`qa_training_export`** — Export captured QA runs as JSONL for distillation
  fine-tuning (ChatML or prompt-completion format). Deduplicates identical scans.
- **`qa_training_diffs`** — Find URLs scanned multiple times whose HTML changed
  between scans. Captures real-world bug fixes and regressions — the highest-
  signal examples for training a qa-fix-suggester model.

Set `QA_MCP_TRAINING_DATA_DIR` to auto-capture every audit call. Build a
QA-fix-suggester model (e.g. Gemma 4 E2B) on your own data with unsloth.

### Stats

- Tool count: 35 → **53**
- New modules: `client_report.py`, `github_issues.py`, `training_data.py`,
  `tools/security_tools.py`
- Categories expanded from 4 to 11

## [0.7.0] — 2026-05-02 — The CI release

The "9.5 → 10" leap from the roadmap. Two waves of features that turn qa-mcp from an interactive assistant into a CI-grade tool teams can adopt.

### Added — Wave 1 (engine + scoring)

- **Multi-browser support** — `browser` arg on `browser_open` accepts `chromium` (default), `webkit` (Safari engine — catches BiDi / iOS-only flex bugs nothing else does), `firefox`. Auto-installs each engine on first use.
- **Network throttling** — `network` arg on `browser_open` plus standalone `browser_throttle_network`. Presets: `slow_3g` / `fast_3g` / `4g` / `wifi` / `offline`. Custom dict supported. Chromium only (CDP-based).
- **Lighthouse-style 0-100 score** — `qa_perf_metrics` returns a single weighted score per the Core Web Vitals weights (LCP 40%, CLS 35%, FCP 15%, TTFB 10%). The format clients/PMs expect.
- **RTL extensions** — 2 new categories with no equivalent in any other tool:
  - `rtl_plural` — Hebrew plural agreement (`"1 פריטים"` → bug, `"2 פריט"` → bug).
  - `rtl_date_ambiguous` — ambiguous `DD/MM` vs `MM/DD` formats in Hebrew context.
- **Git-friendly baselines** — `qa_baseline_save` now writes a `.meta.json` sidecar (sha256, viewport, url, browser, timestamp). PR reviewers can see meaningful diffs without git showing binary blob.
- **`qa_responsive_audit`** — runs audits across multiple breakpoints in one call. Default mobile / tablet / desktop. Returns per-breakpoint findings + `deltas` (what appears only at one width — typically RTL/a11y bugs that surface only on mobile).

### Added — Wave 2 (CI integration — the "make it a product" leap)

- **`qa_run_suite(config)`** + **`qa-mcp run qa.config.json`** — the headline feature. Reads a config, runs every scenario through Playwright + chosen audits, evaluates per-audit thresholds, returns pass/fail.
- **HTML report** — single-file output with embedded base64 screenshots. Hebrew RTL-aware. Open in any browser, send via Slack/email/issue tracker.
- **JUnit XML emitter** — consumed natively by GitHub Actions, GitLab CI, Jenkins, CircleCI. Per-scenario `<testcase>` with violations as `<failure>`.
- **JSON report** — for programmatic post-processing.
- **CLI exit codes** — `qa-mcp run` returns `0` if all thresholds pass, `1` if any violated. Drop into any CI step and the build gates automatically.
- **Threshold DSL** per audit:
  - rtl: `max_high`, `max_medium`, `max_low`
  - a11y: `max_critical`, `max_serious`, `max_moderate`, `max_minor`
  - perf: `min_score`, `min_lcp_grade`, etc.
  - seo: `max_issues`
  - links: `max_flagged`

### Stats

- Tool count: 32 → **35** (added `browser_throttle_network`, `qa_responsive_audit`, `qa_run_suite`)
- Test suites: 6 → **7** (added `test_waves_1_2.py`)
- Browsers supported: 1 → **3** (chromium / webkit / firefox)
- RTL categories: 8 → **10**

### Why it matters

Before 0.7.0 — qa-mcp was a great interactive tool a developer used through their AI agent. Now it can sit in a GitHub Action that gates every PR on Hebrew/RTL bugs, a11y, perf budgets, and visual regression — without writing a single line of test code. Just commit `qa.config.json`.

## [0.5.0] — 2026-05-02

Round 6 review (Claude Opus 4.7) graded **9.5/10**. Two MCP gaps closed; the rest were either site bugs in voicebox.brainboxai.io or already-fixed in 0.4.0 (the reviewer ran an older deployment).

### Fixed

- **`browser_logs` analytics blocklist** — was 7 hosts, now 38. Round 6 caught 8 `ERR_NAME_NOT_RESOLVED` on `*.log.optimizely.com` drowning out 2 real 404s on broken images. Added: Optimizely, Segment, Mixpanel, Amplitude, Heap, FullStory, Pendo, Intercom, HubSpot, Pardot, Crazy Egg, Bugsnag, Rollbar, Datadog RUM, New Relic, Tealium, Mouseflow, Smartlook, plus expanded Google/Meta/Microsoft entries.
- **`browser_logs` requestfailed handler now uses the blocklist** — previously only `on_response` filtered noise, so DNS/connection failures from analytics hosts leaked through.
- **`browser_navigate` resets `last_dialog`** — stale dialog state from a prior page no longer surfaces in `get_state` after navigation. Same for `frame_map`.

### Quality

- 6th test suite: `test_round6_fixes.py` validates blocklist + dialog reset.
- All 6 suites green: original fixes, audit-2026-05-02, remaining-fixes, P0-P1-P2, Round 5, Round 6.

## [0.4.0] — 2026-05-02

Round 5 review (Claude Opus 4.7 on `brainboxai.io` + `voicebox.brainboxai.io` + `saucedemo.com`) graded the project **9.3/10** and identified 3 new gaps. All closed.

### Added

- **`browser_get_state.text_snapshot`** — visible body text (capped, default 1500 chars). Without it agents missed non-interactive content like `"Epic sadface: Sorry, this user has been locked out"` after a failed login. Set `text_snapshot_chars=0` to skip.
- **`browser_open` returns `redirect_chain` + `redirect_count`** — symmetric with `browser_navigate`. Round 5 caught the inconsistency: opening `brainboxai.io` left `session.url` at the original even though the page was redirected to `voicebox.brainboxai.io`.

### Fixed

- **`qa_scan_links` missed input-as-button types** — the saucedemo Login (`<input type="submit">`) returned count=0. Selector now includes `input[type=submit | button | image | reset]`. New `input_type` field per item; `image_input_no_alt` flag; new `input_buttons` count in summary.

### Quality

- 5th test suite: `test_round5_gaps.py` validates all three closures.
- All 5 suites green: original fixes, audit-2026-05-02, remaining-fixes, P0-P1-P2, Round 5.

## [0.3.0] — 2026-05-02

Closing the gaps from a third independent review (`Claude Opus 4.7` on `the-internet.herokuapp.com`, 7 challenge scenarios). Tool count: 25 → 32.

### Added — P0 (was blocking client-facing work)

- **`browser_select_option(value | label | position)`** — `<select>` dropdowns finally work. Country pickers, language selectors, sort orders, multi-select all supported.
- **`browser_handle_dialog(action, prompt_text)`** + always-on dialog listener — `alert`/`confirm`/`prompt` no longer hang the page or fail silently. Default = auto-dismiss + capture. Dialog details exposed in `get_state().last_dialog`.
- **`browser_hover(index)`** — mega-menus, tooltips, hover previews now testable.

### Added — P1 (UX wins)

- **Screenshot defaults to disk** — no more 80-110K-token base64 dumps blowing up agent context. Returns `path`. Opt-in `include_base64=True` for inline bytes.
- **iframe walk in `browser_get_state`** — recursively penetrates every frame, assigns globally-unique indices. Click/type/hover automatically route to the correct frame. TinyMCE/CKEditor/ProseMirror/Lexical all reachable.
- **designMode body fallback in `browser_type`** — for classic-mode TinyMCE/CKEditor: clicks to focus, then keyboard types.

### Added — P2 (nice-to-haves shipped)

- **`browser_evaluate(expression)`** — escape hatch for arbitrary JS.
- **`browser_drag(source_index, target_index)`** — drag-and-drop within a frame.
- **`browser_scroll_to(index)`** — scroll element into view.
- **`browser_open` emulation params** — `geolocation`, `timezone`, `locale`, `user_agent` set at session creation.
- **`browser_set_geolocation`** — update lat/long mid-session for testing location-aware features.

### Changed

- `browser_get_state` now returns `frame_count` and `last_dialog`. Each element has `frame_url` (null = main frame), `contenteditable` flag, `designmode` flag, and for `<select>` an `options` array.
- `INDEX_INTERACTIVE_JS` accepts `startIdx` for frame-walk index continuity.
- `Session` dataclass tracks `pending_dialog_action`, `last_dialog`, `frame_map`.

## [0.2.0] — 2026-05-02

Hardening release driven by two real-world audits. Tool count stayed at 25, but reliability and configurability jumped.

### Added

- **`browser_navigate.redirect_chain`** — full chain including HTTP 3xx hops AND client-side meta-refresh / JS redirects. Each entry tagged `kind: "http" | "client_side"`.
- **`qa_perf_metrics(thresholds=…)`** — override Core Web Vitals cutoffs per metric. Output now includes `thresholds_used`, `timing_reference.time_origin_ms`, and a `notes[]` array (e.g. flags clustered metrics on JS-heavy SPAs to prevent false-positive bug reports).
- **`qa_rtl_audit(ignore_patterns=…, ignore_selectors=…)`** — project-specific allowlists. Regex for text, CSS for elements.
- **`qa_a11y_audit(min_impact=…)`** — filter axe violations by impact level (`minor` / `moderate` / `serious` / `critical`).
- **`qa_baseline_*(baselines_dir=…)`** — per-call override of baseline storage path. CI-friendly. Falls back to `QA_MCP_BASELINE_DIR` env or `~/.qa-mcp/baselines`.
- **8 form-fill intents** — added `valid_login`, `israeli_realistic`, `stripe_test_card`. Israeli ID + credit-card field detection.
- **PerformanceObserver buffered LCP** — catches LCP entries that fired before the script ran. Returns `reasons.lcp = "no_lcp_candidate"` instead of bare null.
- **`rtl_text_overflow`** category — viewport-aware Hebrew text overflow detection (common RTL bug on mobile).
- **`rtl_latin_mixed`** category — separated from `rtl_digits`, lower severity, with 80+ acronym whitelist (MP3, WAV, API, GPU, …).
- **Enriched browser logs** — generic `Script error.` annotated with `likely_cause` + `hint` (e.g. cross-origin script without CORS).
- **Stable selectors in RTL findings** — `id` → `data-testid` → `nth-of-type` path → CSS-escaped class. Plus `xpath` field. No more Tailwind-class noise.
- **Image counting in `qa_seo_check`** — counts `<img>`, `<picture>`, inline `<svg>`, CSS `background-image`. Total visual assets exposed.

### Fixed

- **Race condition between parallel `qa_*` calls** — shared `_wait_for_content()` barrier (`domcontentloaded` + `readyState=complete` + `networkidle`, each timeout-bounded). `qa_a11y` and `qa_seo_check` no longer disagree on the same DOM.
- **`rtl_digits` false-positive on MP3/WAV** — acronym whitelist applied before digit check.
- **`scan_links.js` empty-href detection** — used `getAttribute('href')` instead of `el.href` (which resolved to current URL).
- **`rtl_audit` Hebrew detection** — used body text + `lang` attribute instead of just `lang` (`lang="he"` has no Hebrew chars).

### Changed

- `qa_perf_metrics(wait_for_lcp_ms)` default raised to 2500ms; previously LCP was often `null`.
- Baselines default location remains `~/.qa-mcp/baselines` but now respects `QA_MCP_BASELINE_DIR` env.

### Quality

- 4 test suites covering all features:
  - `test_mcp_stdio.py` — MCP roundtrip
  - `test_new_features.py` — viewport, waits, baseline, SEO, smart fill
  - `test_fixes.py` — original 9 audit fixes
  - `test_audit_20260502.py` — race condition, perf clarity, redirect chain
  - `test_remaining_fixes.py` — allowlists, thresholds, baselines_dir, min_impact, client-side redirects

## [0.1.0] — 2026-05-02

Initial release: 25 MCP tools, Hebrew/RTL audit, axe-core integration, Web Vitals, form fuzzing, visual regression, SEO check, smart form fill, viewport presets, smart waits, cookie/storage state, dual-mode CLI, Chromium auto-install.
