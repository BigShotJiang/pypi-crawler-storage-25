"""Agent QA Console for agent-driven browser QA sessions.

The MCP server stays the source of truth for browser control. This module adds
an optional local web console that a calling coding agent can open for the user:
timeline, screenshots, findings, and approval gates.

Watch, guide, and approve your AI agent’s browser QA work.
"""
from __future__ import annotations

import asyncio
import concurrent.futures
import json
import mimetypes
import queue
import threading
import time
import uuid
import webbrowser
from dataclasses import dataclass, field
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from importlib import resources
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, unquote, urlparse


MAX_EVENTS = 500
MAX_FINDINGS = 250
MAX_SCREENSHOTS = 100
MAX_COMMANDS = 50
ALLOWED_IMAGE_SUFFIXES = {".jpg", ".jpeg", ".png", ".gif", ".webp"}
ALLOWED_COMMAND_KINDS = {"navigate", "back", "forward", "reload", "screenshot", "instruction", "stop", "element_selected", "inspect_selected", "explain_selected", "fix_selected"}
ALLOWED_BROWSER_INPUTS = {"click", "wheel", "type", "press"}
# Tiny valid JPEG fallback (1x1 dark pixel). Avoids browser console spam/white
# panel when the first live screenshot is temporarily unavailable.
FALLBACK_JPEG = bytes.fromhex(
    "ffd8ffe000104a46494600010101006000600000ffdb004300"
    "0302020302020303030304030304050805050404050a07070608"
    "0c0a0c0c0b0a0b0b0d0e12100d0e110e0b0b10161011131415"
    "15150c0f171816141812141514ffdb0043010304040504050905"
    "0509140d0b0d1414141414141414141414141414141414141414"
    "1414141414141414141414141414141414141414141414141414"
    "141414141414141414141414ffc0001108000100010301220002"
    "1101031101ffc400140001000000000000000000000000000000"
    "00000007ffc40014100100000000000000000000000000000000"
    "000000ffc4001401010000000000000000000000000000000000"
    "0007ffc400141101000000000000000000000000000000000000"
    "00ffda000c03010002110311003f00aa7fffd9"
)
FAVICON_ICO = b""


@dataclass
class ApprovalWaiter:
    request: dict[str, Any]
    condition: threading.Condition = field(default_factory=threading.Condition)


class Workspace:
    """In-process local console state + HTTP/SSE server."""

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._server: ThreadingHTTPServer | None = None
        self._thread: threading.Thread | None = None
        self._subscribers: list[queue.Queue[dict[str, Any]]] = []
        self._events: list[dict[str, Any]] = []
        self._findings: list[dict[str, Any]] = []
        self._screenshots: list[dict[str, Any]] = []
        self._approvals: dict[str, ApprovalWaiter] = {}
        self._commands: list[dict[str, Any]] = []
        self._intent: dict[str, Any] | None = None
        self._phase: dict[str, Any] | None = None
        self._fix_loop: dict[str, Any] | None = None
        self._live_session_id: str | None = None
        self._live_session: Any | None = None
        self._live_loop: asyncio.AbstractEventLoop | None = None
        self._last_live_frame: bytes | None = None
        self._last_live_frame_ts: float | None = None
        self._cursor: dict[str, Any] | None = None
        self._selectable_elements: dict[str, Any] | None = None
        self._title = "Agent QA Console"
        self._created_at = time.time()
        self._url: str | None = None

    @property
    def url(self) -> str | None:
        return self._url

    @property
    def running(self) -> bool:
        return self._server is not None

    def start(self, host: str = "127.0.0.1", port: int = 0, title: str | None = None,
              open_browser: bool = True) -> dict[str, Any]:
        with self._lock:
            if title:
                self._title = title
            if self._server is None:
                self._server = ThreadingHTTPServer((host, port), _WorkspaceHandler)
                actual_host, actual_port = self._server.server_address[:2]
                self._url = f"http://{str(actual_host)}:{int(actual_port)}/"
                self._thread = threading.Thread(
                    target=self._server.serve_forever,
                    name="agent-qa-console",
                    daemon=True,
                )
                self._thread.start()
                self.emit("session", "Agent QA Console started", {"url": self._url, "title": self._title})
            url = self._url
        if open_browser and url:
            webbrowser.open(url)
        return {"ok": True, "url": url, "title": self._title, "running": self.running}

    def stop(self) -> dict[str, Any]:
        with self._lock:
            server = self._server
            thread = self._thread
            url = self._url
            self._server = None
            self._thread = None
            self._url = None
        if server is not None:
            server.shutdown()
            server.server_close()
        if thread is not None and thread.is_alive():
            thread.join(timeout=2)
        self.emit("session", "Agent QA Console stopped", {"url": url})
        return {"ok": True, "stopped": bool(server), "url": url}

    def reset(self, title: str | None = None) -> dict[str, Any]:
        with self._lock:
            self._events.clear()
            self._findings.clear()
            self._screenshots.clear()
            self._approvals.clear()
            self._commands.clear()
            self._intent = None
            self._phase = None
            self._fix_loop = None
            self._live_session_id = None
            self._live_session = None
            self._live_loop = None
            self._last_live_frame = None
            self._last_live_frame_ts = None
            self._cursor = None
            self._selectable_elements = None
            self._created_at = time.time()
            if title:
                self._title = title
        self.emit("session", "Agent QA Console reset", {"title": self._title})
        return {"ok": True, "title": self._title}

    def emit(self, kind: str, message: str, data: dict[str, Any] | None = None,
             level: str = "info") -> dict[str, Any]:
        event = {
            "id": uuid.uuid4().hex,
            "ts": time.time(),
            "kind": kind,
            "level": level,
            "message": message,
            "data": data or {},
        }
        with self._lock:
            self._events.append(event)
            del self._events[:-MAX_EVENTS]
            subscribers = list(self._subscribers)
        for subscriber in subscribers:
            try:
                subscriber.put_nowait({"type": "event", "payload": event})
            except queue.Full:
                pass
        return event

    def add_finding(self, title: str, severity: str = "medium", description: str | None = None,
                    selector: str | None = None, screenshot_path: str | None = None,
                    fix: str | None = None, data: dict[str, Any] | None = None) -> dict[str, Any]:
        finding = {
            "id": uuid.uuid4().hex,
            "ts": time.time(),
            "title": title,
            "severity": severity,
            "description": description,
            "selector": selector,
            "screenshot_path": screenshot_path,
            "fix": fix,
            "data": data or {},
        }
        with self._lock:
            self._findings.append(finding)
            del self._findings[:-MAX_FINDINGS]
            subscribers = list(self._subscribers)
        for subscriber in subscribers:
            try:
                subscriber.put_nowait({"type": "finding", "payload": finding})
            except queue.Full:
                pass
        return finding

    def start_fix_loop(self, goal: str, target: str | None = None) -> dict[str, Any]:
        """Start a visible test-fix-verify loop for the current QA task."""
        loop = {
            "id": uuid.uuid4().hex,
            "ts": time.time(),
            "goal": goal,
            "target": target,
            "status": "testing",
            "steps": [],
        }
        with self._lock:
            self._fix_loop = loop
            subscribers = list(self._subscribers)
        for subscriber in subscribers:
            try:
                subscriber.put_nowait({"type": "fix_loop", "payload": loop})
            except queue.Full:
                pass
        self.emit("fix_loop", goal, {"target": target}, level="info")
        self.set_phase("testing", summary=goal, details=target)
        return dict(loop)

    def add_loop_step(self, phase: str, summary: str, status: str = "running",
                      details: str | None = None, files: list[str] | None = None) -> dict[str, Any]:
        """Append a step to the active test-fix-verify loop."""
        step = {
            "id": uuid.uuid4().hex,
            "ts": time.time(),
            "phase": phase,
            "status": status,
            "summary": summary,
            "details": details,
            "files": files or [],
        }
        with self._lock:
            if self._fix_loop is None:
                self._fix_loop = {
                    "id": uuid.uuid4().hex,
                    "ts": time.time(),
                    "goal": "QA repair loop",
                    "target": None,
                    "status": status,
                    "steps": [],
                }
            self._fix_loop["steps"].append(step)
            self._fix_loop["status"] = status
            loop = dict(self._fix_loop)
            loop["steps"] = list(self._fix_loop["steps"])
            subscribers = list(self._subscribers)
        for subscriber in subscribers:
            try:
                subscriber.put_nowait({"type": "fix_loop", "payload": loop})
            except queue.Full:
                pass
        self.emit("fix_loop_step", summary, {"phase": phase, "status": status, "files": files or []}, level="info" if status in {"passed", "fixed", "running"} else "warning")
        self.set_phase(phase, summary=summary, details=details)
        return step

    def set_phase(self, phase: str, summary: str | None = None,
                  details: str | None = None) -> dict[str, Any]:
        """Publish the current test-fix-verify phase."""
        allowed = {"planning", "testing", "failed", "fixing", "retesting", "passed", "needs-human"}
        normalized = phase.strip().lower()
        if normalized not in allowed:
            normalized = "needs-human"
        state = {"phase": normalized, "summary": summary, "details": details, "ts": time.time()}
        with self._lock:
            self._phase = state
            subscribers = list(self._subscribers)
        for subscriber in subscribers:
            try:
                subscriber.put_nowait({"type": "phase", "payload": state})
            except queue.Full:
                pass
        level = "info" if normalized in {"planning", "testing", "retesting", "passed"} else "warning"
        self.emit("phase", summary or normalized, {"phase": normalized, "details": details}, level=level)
        return state

    def set_intent(self, summary: str, risk: str = "read-only", details: str | None = None) -> dict[str, Any]:
        """Publish what the agent is trying to do right now."""
        intent = {"summary": summary, "risk": risk, "details": details, "ts": time.time()}
        with self._lock:
            self._intent = intent
            subscribers = list(self._subscribers)
        for subscriber in subscribers:
            try:
                subscriber.put_nowait({"type": "intent", "payload": intent})
            except queue.Full:
                pass
        self.emit("intent", summary, {"risk": risk, "details": details}, level="warning" if risk != "read-only" else "info")
        return intent

    def attach_browser(self, session_id: str, session: Any, loop: asyncio.AbstractEventLoop) -> dict[str, Any]:
        """Attach the actual Playwright page used by the agent to the console.

        The HTTP console runs in a background thread, while Playwright lives on
        the MCP event loop. We keep both the session object and its loop so the
        MJPEG endpoint can schedule page.screenshot() safely onto the owning
        loop. This is a real live view of the agent-controlled browser page, not
        an iframe of the target site.
        """
        with self._lock:
            self._live_session_id = session_id
            self._live_session = session
            self._live_loop = loop
            url = getattr(getattr(session, "page", None), "url", None)
            subscribers = list(self._subscribers)
        payload = {"session_id": session_id, "url": url}
        for subscriber in subscribers:
            try:
                subscriber.put_nowait({"type": "browser", "payload": payload})
            except queue.Full:
                pass
        self.emit("browser_live", "Attached live agent browser", payload)
        return {"ok": True, **payload}

    def set_cursor(self, x: float, y: float, action: str = "point", label: str | None = None,
                   session_id: str | None = None, pulse: bool = False) -> dict[str, Any]:
        """Publish the agent cursor position over the live browser frame.

        x/y are normalized viewport coordinates in the 0..1 range.
        """
        cursor = {
            "x": max(0.0, min(1.0, float(x))),
            "y": max(0.0, min(1.0, float(y))),
            "action": action,
            "label": label,
            "session_id": session_id,
            "pulse": bool(pulse),
            "ts": time.time(),
        }
        with self._lock:
            self._cursor = cursor
            subscribers = list(self._subscribers)
        for subscriber in subscribers:
            try:
                subscriber.put_nowait({"type": "cursor", "payload": cursor})
            except queue.Full:
                pass
        return {"ok": True, "cursor": cursor}

    def set_selectable_elements(self, session_id: str, url: str | None,
                                viewport: dict[str, Any] | None,
                                elements: list[dict[str, Any]]) -> dict[str, Any]:
        """Publish selectable DOM element boxes for the read-only browser view."""
        payload = {
            "session_id": session_id,
            "url": url,
            "viewport": viewport or {},
            "elements": elements,
            "ts": time.time(),
        }
        with self._lock:
            self._selectable_elements = payload
            subscribers = list(self._subscribers)
        for subscriber in subscribers:
            try:
                subscriber.put_nowait({"type": "selectable_elements", "payload": payload})
            except queue.Full:
                pass
        return {"ok": True, "count": len(elements)}

    def live_browser_state(self) -> dict[str, Any]:
        with self._lock:
            session = self._live_session
            session_id = self._live_session_id
        page = getattr(session, "page", None) if session is not None else None
        viewport = None
        url = None
        try:
            url = page.url if page is not None else None
            viewport = getattr(page, "viewport_size", None)
        except Exception:
            pass
        return {"session_id": session_id, "url": url, "viewport": viewport}

    def live_browser_frame(self, timeout: float = 3.0) -> bytes | None:
        """Return one JPEG frame from the live Playwright page.

        Called by the HTTP streaming thread. Uses run_coroutine_threadsafe so
        screenshots execute on the Playwright/MCP event loop.
        """
        with self._lock:
            session = self._live_session
            loop = self._live_loop
        page = getattr(session, "page", None) if session is not None else None
        if page is None or loop is None or loop.is_closed():
            return None

        async def _shot() -> bytes:
            # Keep this deliberately simple. Some real sites hang when waiting
            # for fonts/animations during screenshot; a longer timeout plus
            # caret=hide makes frame polling far less likely to flash white.
            return await page.screenshot(
                type="jpeg",
                quality=50,
                full_page=False,
                timeout=int(timeout * 1000),
                animations="disabled",
                caret="hide",
            )

        future = asyncio.run_coroutine_threadsafe(_shot(), loop)
        try:
            frame = future.result(timeout=timeout + 1.0)
            with self._lock:
                self._last_live_frame = frame
                self._last_live_frame_ts = time.time()
            return frame
        except (concurrent.futures.TimeoutError, Exception):
            future.cancel()
            with self._lock:
                return self._last_live_frame

    def send_browser_input(self, kind: str, payload: dict[str, Any] | None = None) -> dict[str, Any]:
        """Forward user input from the console to the real Playwright page."""
        normalized = (kind or "").strip().lower()
        if normalized not in ALLOWED_BROWSER_INPUTS:
            return {"ok": False, "error": f"unknown browser input kind: {kind}"}
        payload = payload or {}
        with self._lock:
            session = self._live_session
            loop = self._live_loop
        page = getattr(session, "page", None) if session is not None else None
        if page is None or loop is None or loop.is_closed():
            return {"ok": False, "error": "no live browser attached"}

        async def _apply() -> dict[str, Any]:
            if normalized == "click":
                viewport = page.viewport_size or {"width": 1, "height": 1}
                x = float(payload.get("x", 0)) * float(viewport.get("width") or 1)
                y = float(payload.get("y", 0)) * float(viewport.get("height") or 1)
                await page.mouse.click(x, y)
                return {"ok": True, "kind": normalized, "x": round(x, 1), "y": round(y, 1)}
            if normalized == "wheel":
                dx = float(payload.get("dx", 0))
                dy = float(payload.get("dy", 0))
                await page.mouse.wheel(dx, dy)
                return {"ok": True, "kind": normalized, "dx": dx, "dy": dy}
            if normalized == "type":
                text = str(payload.get("text", ""))
                await page.keyboard.type(text)
                return {"ok": True, "kind": normalized, "chars": len(text)}
            if normalized == "press":
                key = str(payload.get("key", ""))
                if not key:
                    return {"ok": False, "error": "missing key"}
                await page.keyboard.press(key)
                return {"ok": True, "kind": normalized, "key": key}
            return {"ok": False, "error": "unsupported input"}

        future = asyncio.run_coroutine_threadsafe(_apply(), loop)
        try:
            result = future.result(timeout=5)
        except Exception as exc:
            future.cancel()
            return {"ok": False, "error": str(exc)}
        if result.get("ok"):
            self.emit("browser_input", f"User {normalized} in live browser", result)
        return result

    def add_screenshot(self, path: str, label: str | None = None, url: str | None = None,
                       data: dict[str, Any] | None = None) -> dict[str, Any]:
        shot = {
            "id": uuid.uuid4().hex,
            "ts": time.time(),
            "path": path,
            "label": label or Path(path).name,
            "url": url,
            "data": data or {},
        }
        with self._lock:
            self._screenshots.append(shot)
            del self._screenshots[:-MAX_SCREENSHOTS]
            subscribers = list(self._subscribers)
        for subscriber in subscribers:
            try:
                subscriber.put_nowait({"type": "screenshot", "payload": shot})
            except queue.Full:
                pass
        self.emit("screenshot", shot["label"], {"path": path, "url": url})
        return shot

    def ask_approval_nowait(self, question: str, details: str | None = None,
                             choices: list[str] | None = None) -> dict[str, Any]:
        """Create an approval request without blocking for the answer."""
        request = {
            "id": uuid.uuid4().hex,
            "ts": time.time(),
            "question": question,
            "details": details,
            "choices": choices or ["approve", "reject"],
            "status": "pending",
            "answer": None,
            "note": None,
        }
        waiter = ApprovalWaiter(request=request)
        with self._lock:
            self._approvals[request["id"]] = waiter
            subscribers = list(self._subscribers)
        for subscriber in subscribers:
            try:
                subscriber.put_nowait({"type": "approval", "payload": request})
            except queue.Full:
                pass
        self.emit("approval", question, {"approval_id": request["id"]}, level="warning")
        return dict(request)

    async def ask_approval(self, question: str, details: str | None = None,
                           choices: list[str] | None = None,
                           timeout_seconds: int = 300) -> dict[str, Any]:
        request = self.ask_approval_nowait(question, details=details, choices=choices)
        with self._lock:
            waiter = self._approvals[request["id"]]

        def _wait() -> dict[str, Any]:
            deadline = time.time() + max(1, timeout_seconds)
            with waiter.condition:
                while waiter.request["status"] == "pending":
                    remaining = deadline - time.time()
                    if remaining <= 0:
                        waiter.request["status"] = "timeout"
                        break
                    waiter.condition.wait(timeout=remaining)
                return dict(waiter.request)

        result = await asyncio.to_thread(_wait)
        self.emit(
            "approval_result",
            f"Approval {result.get('status')}: {question}",
            {"approval_id": result.get("id"), "answer": result.get("answer"), "note": result.get("note")},
            level="info" if result.get("status") == "answered" else "warning",
        )
        return result

    def enqueue_command(self, kind: str, payload: dict[str, Any] | None = None) -> dict[str, Any]:
        """User-initiated command for the agent to consume on its next poll."""
        normalized = (kind or "").strip().lower()
        if normalized not in ALLOWED_COMMAND_KINDS:
            return {"ok": False, "error": f"unknown command kind: {kind}"}
        command = {
            "id": uuid.uuid4().hex,
            "ts": time.time(),
            "kind": normalized,
            "payload": payload or {},
            "consumed": False,
        }
        with self._lock:
            self._commands.append(command)
            del self._commands[:-MAX_COMMANDS]
            subscribers = list(self._subscribers)
        for subscriber in subscribers:
            try:
                subscriber.put_nowait({"type": "command", "payload": command})
            except queue.Full:
                pass
        message = self._command_message(command)
        self.emit("user_command", message, {"kind": normalized, **(payload or {})}, level="info")
        return {"ok": True, "command": dict(command)}

    @staticmethod
    def _command_message(command: dict[str, Any]) -> str:
        kind = command.get("kind")
        payload = command.get("payload") or {}
        if kind == "navigate":
            return f"User asked to navigate to {payload.get('url', '')}"
        if kind == "instruction":
            text = str(payload.get("text", "")).strip()
            return f"User: {text}" if text else "User sent an empty instruction"
        if kind == "back":
            return "User asked to go back"
        if kind == "forward":
            return "User asked to go forward"
        if kind == "reload":
            return "User asked to reload"
        if kind == "screenshot":
            return "User asked for a screenshot"
        if kind == "stop":
            return "User asked the agent to stop"
        if kind == "element_selected":
            label = payload.get("label") or payload.get("text") or payload.get("id") or payload.get("index")
            return f"User selected element: {label}"
        if kind == "inspect_selected":
            return f"User asked to inspect selected element: {payload.get('label') or payload.get('selector') or ''}"
        if kind == "explain_selected":
            return f"User asked to explain selected element: {payload.get('label') or payload.get('selector') or ''}"
        if kind == "fix_selected":
            return f"User asked to fix selected element: {payload.get('label') or payload.get('selector') or ''}"
        return f"User command: {kind}"

    def pending_commands(self, consume: bool = True) -> list[dict[str, Any]]:
        with self._lock:
            pending = [dict(c) for c in self._commands if not c.get("consumed")]
            if consume:
                for c in self._commands:
                    c["consumed"] = True
        return pending

    def answer_approval(self, approval_id: str, answer: str, note: str | None = None) -> dict[str, Any]:
        with self._lock:
            waiter = self._approvals.get(approval_id)
        if waiter is None:
            return {"ok": False, "error": "approval request not found"}
        with waiter.condition:
            waiter.request["status"] = "answered"
            waiter.request["answer"] = answer
            waiter.request["note"] = note
            waiter.request["answered_at"] = time.time()
            waiter.condition.notify_all()
        return {"ok": True, "approval": dict(waiter.request)}

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            return {
                "title": self._title,
                "created_at": self._created_at,
                "running": self.running,
                "url": self._url,
                "events": list(self._events),
                "findings": list(self._findings),
                "screenshots": list(self._screenshots),
                "approvals": [dict(w.request) for w in self._approvals.values()],
                "commands": [dict(c) for c in self._commands],
                "intent": dict(self._intent) if self._intent else None,
                "phase": dict(self._phase) if self._phase else None,
                "fix_loop": dict(self._fix_loop) if self._fix_loop else None,
                "browser": self.live_browser_state(),
                "cursor": dict(self._cursor) if self._cursor else None,
                "selectable_elements": dict(self._selectable_elements) if self._selectable_elements else None,
            }

    def markdown_report(self) -> str:
        """Render the current console session as a portable Markdown report."""
        snap = self.snapshot()
        lines = [
            f"# Agent QA Console — {snap['title']}",
            "",
            "Watch, guide, and approve your AI agent’s browser QA work.",
            "",
            "## Summary",
            "",
            f"- Actions: {len(snap['events'])}",
            f"- Findings: {len(snap['findings'])}",
            f"- Screenshots: {len(snap['screenshots'])}",
            f"- Approvals: {len(snap['approvals'])}",
            "",
        ]
        if snap.get("fix_loop"):
            loop = snap["fix_loop"]
            lines.extend([
                "## Test-fix-verify loop",
                "",
                f"- Goal: {loop.get('goal')}",
                f"- Target: {loop.get('target') or 'n/a'}",
                f"- Status: `{loop.get('status')}`",
                "",
            ])
            for step in loop.get("steps", []):
                lines.append(f"- `{step.get('phase')}` / `{step.get('status')}` — {step.get('summary')}")
                if step.get("files"):
                    lines.append(f"  - Files: {', '.join(step['files'])}")
            lines.append("")
        if snap.get("phase"):
            phase = snap["phase"]
            lines.extend([
                "## Current phase",
                "",
                f"- Phase: `{phase.get('phase')}`",
            ])
            if phase.get("summary"):
                lines.append(f"- Summary: {phase['summary']}")
            if phase.get("details"):
                lines.append(f"- Details: {phase['details']}")
            lines.append("")
        if snap.get("intent"):
            intent = snap["intent"]
            lines.extend([
                "## Current agent intent",
                "",
                f"- Intent: {intent.get('summary')}",
                f"- Risk: `{intent.get('risk')}`",
            ])
            if intent.get("details"):
                lines.append(f"- Details: {intent['details']}")
            lines.append("")
        if snap["findings"]:
            lines.extend(["## Findings", ""])
            for finding in snap["findings"]:
                lines.extend([
                    f"### {finding.get('title', 'Finding')}",
                    "",
                    f"- Severity: `{finding.get('severity', 'medium')}`",
                ])
                if finding.get("selector"):
                    lines.append(f"- Selector: `{finding['selector']}`")
                if finding.get("description"):
                    lines.extend(["", str(finding["description"])])
                if finding.get("fix"):
                    lines.extend(["", f"**Suggested fix:** {finding['fix']}"])
                if finding.get("screenshot_path"):
                    lines.append(f"- Screenshot: `{finding['screenshot_path']}`")
                lines.append("")
        if snap["approvals"]:
            lines.extend(["## Approvals", ""])
            for approval in snap["approvals"]:
                lines.extend([
                    f"- **{approval.get('question', 'Approval')}** — `{approval.get('status')}`",
                    f"  - Answer: `{approval.get('answer')}`",
                ])
                if approval.get("note"):
                    lines.append(f"  - Note: {approval['note']}")
            lines.append("")
        if snap["screenshots"]:
            lines.extend(["## Screenshots", ""])
            for shot in snap["screenshots"]:
                lines.append(f"- {shot.get('label', 'Screenshot')}: `{shot.get('path')}`")
            lines.append("")
        if snap["events"]:
            lines.extend(["## Timeline", ""])
            for event in snap["events"]:
                lines.append(f"- `{event.get('kind')}` / `{event.get('level')}` — {event.get('message')}")
            lines.append("")
        return "\n".join(lines).rstrip() + "\n"

    def subscribe(self) -> queue.Queue[dict[str, Any]]:
        q: queue.Queue[dict[str, Any]] = queue.Queue(maxsize=100)
        with self._lock:
            self._subscribers.append(q)
        return q

    def unsubscribe(self, q: queue.Queue[dict[str, Any]]) -> None:
        with self._lock:
            if q in self._subscribers:
                self._subscribers.remove(q)


workspace = Workspace()


def log_tool(tool: str, message: str, data: dict[str, Any] | None = None,
             level: str = "info") -> dict[str, Any]:
    return workspace.emit(tool, message, data, level=level)


def _read_asset(name: str) -> bytes:
    return resources.files("qa_mcp").joinpath("workspace").joinpath(name).read_bytes()


class _WorkspaceHandler(BaseHTTPRequestHandler):
    server_version = "agent-qa-console/1.0"

    def log_message(self, fmt: str, *args: Any) -> None:  # keep test/agent output clean
        return

    def do_GET(self) -> None:  # noqa: N802 - stdlib hook name
        parsed = urlparse(self.path)
        if parsed.path == "/":
            self._send_asset("index.html", "text/html; charset=utf-8")
        elif parsed.path == "/favicon.ico":
            self._send_bytes(FAVICON_ICO, "image/x-icon")
        elif parsed.path == "/style.css":
            self._send_asset("style.css", "text/css; charset=utf-8")
        elif parsed.path == "/app.js":
            self._send_asset("app.js", "application/javascript; charset=utf-8")
        elif parsed.path == "/api/session":
            self._send_json(workspace.snapshot())
        elif parsed.path == "/api/report.md":
            self._send_markdown(workspace.markdown_report())
        elif parsed.path == "/api/browser-frame.jpg":
            self._send_browser_frame()
        elif parsed.path == "/api/browser-stream.mjpeg":
            self._send_browser_stream()
        elif parsed.path == "/api/events":
            self._send_events()
        elif parsed.path == "/api/file":
            self._send_file(parsed.query)
        else:
            self.send_error(HTTPStatus.NOT_FOUND, "not found")

    def do_POST(self) -> None:  # noqa: N802 - stdlib hook name
        parsed = urlparse(self.path)
        if parsed.path.startswith("/api/approval/"):
            approval_id = unquote(parsed.path.rsplit("/", 1)[-1])
            body = self._read_json_body()
            answer = str(body.get("answer") or body.get("choice") or "")
            note = body.get("note")
            if not answer:
                self._send_json({"ok": False, "error": "missing answer"}, status=400)
                return
            self._send_json(workspace.answer_approval(approval_id, answer, note=note))
            return
        if parsed.path == "/api/command":
            body = self._read_json_body()
            kind = str(body.get("kind") or "")
            payload = body.get("payload") or {k: v for k, v in body.items() if k not in {"kind", "payload"}}
            result = workspace.enqueue_command(kind, payload if isinstance(payload, dict) else {})
            self._send_json(result, status=200 if result.get("ok") else 400)
            return
        if parsed.path == "/api/browser-input":
            body = self._read_json_body()
            kind = str(body.get("kind") or "")
            payload = body.get("payload") or {k: v for k, v in body.items() if k not in {"kind", "payload"}}
            result = workspace.send_browser_input(kind, payload if isinstance(payload, dict) else {})
            self._send_json(result, status=200 if result.get("ok") else 400)
            return
        self.send_error(HTTPStatus.NOT_FOUND, "not found")

    def _send_asset(self, name: str, content_type: str) -> None:
        try:
            data = _read_asset(name)
        except FileNotFoundError:
            self.send_error(HTTPStatus.NOT_FOUND, "asset not found")
            return
        self._send_bytes(data, content_type)

    def _send_bytes(self, data: bytes, content_type: str) -> None:
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _send_json(self, payload: Any, status: int = 200) -> None:
        data = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _send_markdown(self, text: str) -> None:
        data = text.encode("utf-8")
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", "text/markdown; charset=utf-8")
        self.send_header("Content-Disposition", "attachment; filename=agent-qa-console-report.md")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _send_browser_frame(self) -> None:
        frame = workspace.live_browser_frame(timeout=4.0) or FALLBACK_JPEG
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", "image/jpeg")
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate")
        self.send_header("Pragma", "no-cache")
        self.send_header("Content-Length", str(len(frame)))
        self.end_headers()
        self.wfile.write(frame)

    def _send_browser_stream(self) -> None:
        boundary = "agentqaframe"
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", f"multipart/x-mixed-replace; boundary={boundary}")
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate")
        self.send_header("Pragma", "no-cache")
        self.send_header("Connection", "close")
        self.end_headers()
        last_frame: bytes | None = None
        try:
            while True:
                frame = workspace.live_browser_frame(timeout=2.5)
                if frame is None:
                    frame = last_frame
                if frame is not None:
                    last_frame = frame
                    self.wfile.write(f"--{boundary}\r\n".encode("ascii"))
                    self.wfile.write(b"Content-Type: image/jpeg\r\n")
                    self.wfile.write(f"Content-Length: {len(frame)}\r\n\r\n".encode("ascii"))
                    self.wfile.write(frame)
                    self.wfile.write(b"\r\n")
                    self.wfile.flush()
                time.sleep(0.25)
        except (BrokenPipeError, ConnectionResetError, ValueError):
            pass

    def _send_events(self) -> None:
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Connection", "keep-alive")
        self.end_headers()
        subscriber = workspace.subscribe()
        try:
            self._write_sse("snapshot", workspace.snapshot())
            while True:
                try:
                    item = subscriber.get(timeout=15)
                    self._write_sse(item.get("type", "event"), item.get("payload"))
                except queue.Empty:
                    self.wfile.write(b": heartbeat\n\n")
                    self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError, ValueError):
            pass
        finally:
            workspace.unsubscribe(subscriber)

    def _write_sse(self, event: str, payload: Any) -> None:
        data = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
        self.wfile.write(f"event: {event}\n".encode("utf-8"))
        for line in data.splitlines() or [""]:
            self.wfile.write(f"data: {line}\n".encode("utf-8"))
        self.wfile.write(b"\n")
        self.wfile.flush()

    def _send_file(self, query: str) -> None:
        params = parse_qs(query)
        raw_path = params.get("path", [""])[0]
        if not raw_path:
            self._send_json({"ok": False, "error": "missing path"}, status=400)
            return
        path = Path(raw_path).expanduser().resolve()
        if path.suffix.lower() not in ALLOWED_IMAGE_SUFFIXES:
            self._send_json({"ok": False, "error": "only image files are served"}, status=403)
            return
        if not path.exists() or not path.is_file():
            self._send_json({"ok": False, "error": "file not found"}, status=404)
            return
        content_type = mimetypes.guess_type(str(path))[0] or "application/octet-stream"
        data = path.read_bytes()
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _read_json_body(self) -> dict[str, Any]:
        length = int(self.headers.get("Content-Length") or "0")
        if length <= 0:
            return {}
        try:
            return json.loads(self.rfile.read(length).decode("utf-8"))
        except Exception:
            return {}
