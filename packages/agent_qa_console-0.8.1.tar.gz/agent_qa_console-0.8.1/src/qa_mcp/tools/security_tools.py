"""Passive security audit for qa-mcp.

Lightweight, safe checks only: headers, cookies, TLS certificate, exposed paths,
CORS, mixed content, security.txt, basic tech disclosure, and optional DNS email
security if dnspython is installed. No port scans, no fuzzing, no exploit tools.
"""
from __future__ import annotations

import asyncio
import hashlib
import re
import socket
import ssl
import urllib.parse
import urllib.request
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Any

SECURITY_HEADERS = [
    "Content-Security-Policy",
    "Strict-Transport-Security",
    "X-Frame-Options",
    "X-Content-Type-Options",
    "Referrer-Policy",
    "Permissions-Policy",
]

EXPOSED_PATHS = [
    "/.env", "/.git/HEAD", "/.git/config", "/swagger", "/api-docs",
    "/openapi.json", "/phpinfo.php", "/server-status", "/server-info",
    "/.DS_Store", "/web.config", "/robots.txt", "/sitemap.xml",
    "/.well-known/security.txt", "/actuator/health", "/actuator/env",
    "/debug", "/_profiler", "/backup.zip", "/db.sql", "/dump.sql",
]

HEADER_FIXES = {
    "Content-Security-Policy": "Add a CSP header that restricts scripts, styles, frames and connections to trusted origins.",
    "Strict-Transport-Security": "Add HSTS: Strict-Transport-Security: max-age=31536000; includeSubDomains; preload",
    "X-Frame-Options": "Add X-Frame-Options: DENY or SAMEORIGIN, or use CSP frame-ancestors.",
    "X-Content-Type-Options": "Add X-Content-Type-Options: nosniff.",
    "Referrer-Policy": "Add Referrer-Policy: strict-origin-when-cross-origin or stricter.",
    "Permissions-Policy": "Add Permissions-Policy to disable unused browser capabilities.",
}

@dataclass
class SecFinding:
    severity: str
    category: str
    title: str
    detail: str
    remediation: str = ""
    url: str = ""
    evidence: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _finding(sev: str, cat: str, title: str, detail: str, remediation: str = "", url: str = "", evidence: str = "") -> SecFinding:
    return SecFinding(sev, cat, title, detail, remediation, url, evidence)


def _grade(score: int) -> str:
    if score >= 90: return "A"
    if score >= 75: return "B"
    if score >= 60: return "C"
    if score >= 40: return "D"
    return "F"


def _score(findings: list[SecFinding]) -> tuple[int, str]:
    weights = {"critical": 25, "high": 15, "medium": 8, "low": 3, "info": 0}
    penalty = 0
    for f in findings:
        # Same philosophy as brainbox-security: missing passive headers matter,
        # but should not tank a QA report like verified exploitable vulns.
        if f.category == "missing_header":
            penalty += 5
        else:
            penalty += weights.get(f.severity, 0)
    score = max(0, 100 - penalty)
    return score, _grade(score)


def _fetch(url: str, timeout: int = 10, headers: dict[str, str] | None = None) -> tuple[int, dict[str, str], bytes, str]:
    req = urllib.request.Request(url, headers={"User-Agent": "qa-mcp passive security audit", **(headers or {})})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        body = resp.read(512_000)
        final_url = resp.geturl()
        return resp.status, dict(resp.headers.items()), body, final_url


def _check_ssl(host: str) -> list[SecFinding]:
    out: list[SecFinding] = []
    try:
        ctx = ssl.create_default_context()
        with ctx.wrap_socket(socket.socket(), server_hostname=host) as s:
            s.settimeout(5)
            s.connect((host, 443))
            cert = s.getpeercert()
            cipher = s.cipher()
        exp = cert.get("notAfter")
        if exp:
            expiry = datetime.strptime(exp, "%b %d %H:%M:%S %Y %Z")
            days = (expiry - datetime.now(timezone.utc).replace(tzinfo=None)).days
            if days < 0:
                out.append(_finding("critical", "ssl", "SSL certificate expired", f"Expired {abs(days)} days ago", "Renew the TLS certificate."))
            elif days < 14:
                out.append(_finding("high", "ssl", "SSL certificate expiring soon", f"Expires in {days} days", "Renew the TLS certificate before expiry."))
            elif days < 30:
                out.append(_finding("medium", "ssl", "SSL certificate expiring", f"Expires in {days} days", "Plan certificate renewal."))
        if cipher and any(x in cipher[0].upper() for x in ("RC4", "3DES", "DES", "NULL", "EXPORT")):
            out.append(_finding("high", "ssl", "Weak TLS cipher negotiated", cipher[0], "Disable weak TLS ciphers."))
    except ssl.SSLCertVerificationError as e:
        out.append(_finding("critical", "ssl", "Invalid SSL certificate", str(e), "Install a valid trusted certificate."))
    except Exception as e:
        out.append(_finding("high", "ssl", "SSL connection failed", str(e), "Verify HTTPS/TLS configuration."))
    return out


def _check_headers(headers: dict[str, str]) -> list[SecFinding]:
    out: list[SecFinding] = []
    lower = {k.lower(): v for k, v in headers.items()}
    for h in SECURITY_HEADERS:
        if h.lower() not in lower:
            sev = "high" if h in ("Content-Security-Policy", "Strict-Transport-Security") else "medium"
            out.append(_finding(sev, "missing_header", f"Missing {h}", f"Header '{h}' is not set", HEADER_FIXES.get(h, "Add this security header.")))
    server = lower.get("server")
    if server:
        sev = "medium" if re.search(r"\d+\.\d+", server) else "low"
        out.append(_finding(sev, "info_disclosure", "Server header exposed", f"Server: {server}", "Remove detailed server/version disclosure where possible."))
    powered = lower.get("x-powered-by")
    if powered:
        out.append(_finding("medium", "info_disclosure", "X-Powered-By exposed", f"X-Powered-By: {powered}", "Remove X-Powered-By header."))
    hsts = lower.get("strict-transport-security", "")
    if hsts:
        m = re.search(r"max-age=(\d+)", hsts.lower())
        if m and int(m.group(1)) < 31_536_000:
            out.append(_finding("low", "misconfig", "HSTS max-age too short", f"max-age={m.group(1)}", "Use max-age >= 31536000."))
        if "includesubdomains" not in hsts.lower():
            out.append(_finding("info", "misconfig", "HSTS missing includeSubDomains", hsts, "Consider includeSubDomains if safe for all subdomains."))
    return out


def _check_cookies(headers: dict[str, str]) -> list[SecFinding]:
    out: list[SecFinding] = []
    for k, v in headers.items():
        if k.lower() != "set-cookie":
            continue
        low = v.lower(); name = v.split("=", 1)[0]
        issues = []
        if "httponly" not in low: issues.append("HttpOnly")
        if "secure" not in low: issues.append("Secure")
        if "samesite" not in low: issues.append("SameSite")
        if issues:
            out.append(_finding("medium", "cookie", f"Cookie '{name}' missing flags", ", ".join(issues), f"Add {', '.join(issues)} to cookie '{name}'."))
    return out


def _check_html(html: str, base_url: str) -> list[SecFinding]:
    out: list[SecFinding] = []
    if base_url.startswith("https://"):
        mixed = re.findall(r"(?:src|href|action)\s*=\s*['\"]?(http://[^\s'\"<>]+)", html, re.I)
        if mixed:
            out.append(_finding("medium", "mixed_content", "Mixed content detected", ", ".join(list(dict.fromkeys(mixed))[:10]), "Use HTTPS URLs for all resources."))
    if re.search(r"<meta\s+http-equiv=['\"]Content-Security-Policy", html, re.I):
        out.append(_finding("info", "csp", "CSP delivered via meta tag", "Header CSP is preferred", "Prefer Content-Security-Policy response header."))
    gen = re.search(r"<meta\s+name=['\"]generator['\"]\s+content=['\"]([^'\"]+)", html, re.I)
    if gen and re.search(r"\d+\.\d+", gen.group(1)):
        out.append(_finding("low", "info_disclosure", "Generator version exposed", gen.group(1), "Remove generator version metadata."))
    for lib, pat, safe, desc in [
        ("jQuery", r"jquery[/-](\d+\.\d+\.\d+)", "3.5.0", "Known historical XSS issues"),
        ("Bootstrap", r"bootstrap[/-](\d+\.\d+\.\d+)", "4.3.1", "Known tooltip/popover XSS issues"),
        ("lodash", r"lodash[/-](\d+\.\d+\.\d+)", "4.17.21", "Prototype pollution issues"),
    ]:
        m = re.search(pat, html.lower())
        if m and _version_lt(m.group(1), safe):
            out.append(_finding("medium", "outdated_js", f"Outdated {lib} {m.group(1)}", desc, f"Upgrade {lib} to >= {safe}."))
    return out


def _version_lt(a: str, b: str) -> bool:
    try:
        return [int(x) for x in a.split(".")] < [int(x) for x in b.split(".")]
    except Exception:
        return False


async def _probe_exposed(base_url: str, baseline_hash: str | None, baseline_size: int) -> list[SecFinding]:
    out: list[SecFinding] = []
    file_exts = (".sql", ".log", ".env", ".git", ".zip", ".bak", ".cfg", ".conf", ".json")

    async def one(path: str):
        try:
            status, headers, body, final = await asyncio.to_thread(_fetch, base_url.rstrip("/") + path, 6)
            if status != 200 or not body:
                return
            h = hashlib.md5(body).hexdigest(); size = len(body)
            if baseline_hash and h == baseline_hash:
                return
            if baseline_size and abs(size - baseline_size) < baseline_size * 0.05:
                return
            ctype = headers.get("Content-Type", "").lower()
            text = body[:600].decode(errors="replace")
            if any(path.endswith(ext) or ext in path for ext in file_exts) and "text/html" in ctype:
                return
            validators = {
                "/.env": "=", "/.git/HEAD": "ref:", "/.git/config": "[core]", "/openapi.json": "openapi",
                "/phpinfo.php": "phpinfo",
            }
            if path in validators and validators[path].lower() not in text.lower():
                return
            if path == "/.well-known/security.txt":
                out.append(_finding("info", "security_txt", "security.txt found", final, "Validate Contact and Expires fields.", final))
                return
            sev = "critical" if path in ("/.env", "/.git/HEAD", "/.git/config", "/db.sql", "/dump.sql", "/backup.zip", "/phpinfo.php", "/actuator/env") else "medium" if path in ("/swagger", "/api-docs", "/openapi.json", "/actuator/health") else "low"
            out.append(_finding(sev, "exposed_path", f"Exposed path: {path}", f"HTTP 200, {size} bytes", f"Block public access to {path}.", final))
        except Exception:
            pass

    await asyncio.gather(*(one(p) for p in EXPOSED_PATHS))
    return out


def _txt_records(name: str) -> list[str]:
    try:
        import dns.resolver  # type: ignore
        r = dns.resolver.Resolver(); r.timeout = 3; r.lifetime = 3
        return [str(x).strip('"') for x in r.resolve(name, "TXT")]
    except Exception:
        return []


def _check_email(domain: str) -> list[SecFinding]:
    out: list[SecFinding] = []
    root = _txt_records(domain)
    if root and not any("v=spf1" in x.lower() for x in root):
        out.append(_finding("high", "email_security", "No SPF record", "Domain TXT records exist but no v=spf1 found", "Add SPF TXT record."))
    elif not root:
        out.append(_finding("medium", "email_security", "SPF not verified", "TXT lookup unavailable or no TXT records", "Verify SPF DNS record."))
    dmarc = _txt_records("_dmarc." + domain)
    if dmarc and not any("v=dmarc1" in x.lower() for x in dmarc):
        out.append(_finding("high", "email_security", "No DMARC record", "_dmarc exists but no v=DMARC1 found", "Add DMARC policy."))
    elif not dmarc:
        out.append(_finding("high", "email_security", "No DMARC record", f"_dmarc.{domain} not found or lookup unavailable", "Add _dmarc TXT record."))
    return out


async def security_passive_audit(url: str) -> dict[str, Any]:
    parsed = urllib.parse.urlparse(url if "://" in url else "https://" + url)
    host = parsed.netloc or parsed.path.split("/")[0]
    start_url = parsed.geturl() if parsed.netloc else "https://" + host
    findings: list[SecFinding] = []
    status = None; headers: dict[str, str] = {}; body = b""; final_url = start_url
    try:
        status, headers, body, final_url = await asyncio.to_thread(_fetch, start_url, 12)
    except Exception:
        try:
            final_url = "http://" + host
            status, headers, body, final_url = await asyncio.to_thread(_fetch, final_url, 12)
            findings.append(_finding("critical", "https", "HTTPS not available", "Site loaded over HTTP", "Enable HTTPS and redirect HTTP to HTTPS.", final_url))
        except Exception as e:
            findings.append(_finding("critical", "availability", "Site unreachable", str(e), "Verify DNS/network availability.", start_url))
            score, grade = _score(findings)
            return _result(start_url, final_url, status, headers, findings, score, grade)

    if final_url.startswith("https://"):
        findings.extend(_check_ssl(host))
    findings.extend(_check_headers(headers))
    findings.extend(_check_cookies(headers))
    html = body.decode(errors="replace")
    findings.extend(_check_html(html, final_url))

    # CORS reflection check
    try:
        _, cors_headers, _, _ = await asyncio.to_thread(_fetch, final_url, 6, {"Origin": "https://evil.example"})
        acao = cors_headers.get("Access-Control-Allow-Origin", "")
        acac = cors_headers.get("Access-Control-Allow-Credentials", "").lower()
        if acao == "*" and acac == "true":
            findings.append(_finding("critical", "cors", "CORS wildcard with credentials", "ACAO=* and credentials=true", "Never combine wildcard CORS with credentials."))
        elif "evil.example" in acao:
            findings.append(_finding("high" if acac == "true" else "medium", "cors", "CORS reflects arbitrary origin", acao, "Whitelist allowed origins."))
    except Exception:
        pass

    baseline_hash = None; baseline_size = 0
    try:
        _, _, b, _ = await asyncio.to_thread(_fetch, final_url.rstrip("/") + "/qa_mcp_nonexistent_84729", 6)
        baseline_hash = hashlib.md5(b).hexdigest(); baseline_size = len(b)
    except Exception:
        pass
    findings.extend(await _probe_exposed(final_url, baseline_hash, baseline_size))
    findings.extend(await asyncio.to_thread(_check_email, host))

    score, grade = _score(findings)
    return _result(start_url, final_url, status, headers, findings, score, grade)


def _result(start_url: str, final_url: str, status: int | None, headers: dict[str, str], findings: list[SecFinding], score: int, grade: str) -> dict[str, Any]:
    by_sev = {s: sum(1 for f in findings if f.severity == s) for s in ("critical", "high", "medium", "low", "info")}
    return {
        "page": {"url": final_url, "requested_url": start_url, "status": status},
        "summary": {"total": len(findings), "by_severity": by_sev, "score": score, "grade": grade},
        "headers_sample": {k: headers[k] for k in list(headers)[:20]},
        "findings": [f.to_dict() for f in findings],
    }
