"""Component extractor - pixel-level UI element inventory.

Unlike qa_design_interaction_scan (which finds special elements like
animations/widgets) and qa_inspiration_analyze_url (which abstracts
design patterns), this tool extracts individual UI components with
their EXACT computed CSS properties: colors, typography, spacing,
borders, shadows, layout. The output is a structured inventory a
developer can use to recreate elements 1:1.

Architecture:
  1. Identify major UI components by semantic role/tag/class
  2. For each, extract computed styles via getComputedStyle()
  3. Also capture the DOM subtree (simplified) for structure
  4. Group by component type: buttons, cards, nav, hero, pricing, forms
  5. Return structured JSON with every CSS property relevant to recreation

Use this when the user says "copy this button", "recreate this card",
"what font does this use", or "give me the exact styles for this nav".
"""

from __future__ import annotations

import re
from typing import Any

from ..browser import SessionManager

# ---------- component type classifiers ----------

_COMPONENT_PATTERNS = {
    "button": [
        r"button", r"btn", r"cta", r"cta-button", r"primary-button",
        r"sign-up", r"signup", r"get-started", r"try-free",
    ],
    "nav": [
        r"nav", r"navbar", r"header", r"topbar", r"sidebar",
        r"navigation", r"menu",
    ],
    "hero": [
        r"hero", r"banner", r"jumbotron", r"masthead",
        r"above-fold", r"above-the-fold",
    ],
    "card": [
        r"card", r"tile", r"panel", r"feature-card", r"pricing-card",
        r"testimonial", r"review-card",
    ],
    "pricing": [
        r"pricing", r"plan", r"tier", r"price-card", r"package",
    ],
    "footer": [
        r"footer", r"bottom", r"copyright",
    ],
    "form": [
        r"form", r"input", r"signup-form", r"login-form", r"contact-form",
    ],
    "section": [
        r"section", r"segment", r"block",
    ],
    "badge": [
        r"badge", r"tag", r"chip", r"label", r"pill",
    ],
    "input_field": [
        r"input", r"textfield", r"textarea", r"select", r"dropdown",
    ],
}


def _classify_element(tag: str, classes: str, text: str, role: str) -> str:
    """Guess the component type from tag + class + text."""
    lower = (tag + " " + classes + " " + text + " " + role).lower()
    for comp_type, patterns in _COMPONENT_PATTERNS.items():
        for pat in patterns:
            if re.search(pat, lower):
                return comp_type
    # Fallback: use tag
    if tag in ("button", "a") and len(text) < 50:
        return "button"
    return tag


# ---------- CSS property whitelist (what matters for recreation) ----------

_STYLE_PROPS = {
    # Layout
    "display", "position", "flexDirection", "flexWrap", "justifyContent",
    "alignItems", "alignSelf", "gap", "gridTemplateColumns", "gridGap",
    # Box model
    "width", "height", "minWidth", "maxWidth", "minHeight", "maxHeight",
    "margin", "marginTop", "marginRight", "marginBottom", "marginLeft",
    "padding", "paddingTop", "paddingRight", "paddingBottom", "paddingLeft",
    # Typography
    "fontFamily", "fontSize", "fontWeight", "fontStyle", "lineHeight",
    "letterSpacing", "textAlign", "textTransform", "textDecoration",
    "color", "textShadow",
    # Colors & backgrounds
    "backgroundColor", "backgroundImage", "backgroundSize",
    "backgroundPosition", "opacity",
    # Borders
    "border", "borderTop", "borderRight", "borderBottom", "borderLeft",
    "borderRadius", "borderColor", "borderWidth", "borderStyle",
    "borderTopLeftRadius", "borderTopRightRadius",
    "borderBottomLeftRadius", "borderBottomRightRadius",
    # Shadows & effects
    "boxShadow", "filter", "backdropFilter",
    # Transitions/animations
    "transition", "animation", "transform",
    # Overflow/visibility
    "overflow", "overflowX", "overflowY", "visibility", "zIndex",
    # Cursor
    "cursor", "pointerEvents",
    # Grid/Flex specific
    "flex", "flexGrow", "flexShrink", "flexBasis",
    "gridColumn", "gridRow",
}


# ---------- JS extractor (runs in browser) ----------

_EXTRACTOR_JS = r"""
(opts) => {
  const MAX_ELEMENTS = (opts && opts.max_elements) || 50;
  const MAX_DEPTH = (opts && opts.max_depth) || 3;
  const INLINE_IMAGES = (opts && opts.inline_images) !== false;
  const SELECTORS = (opts && opts.selectors) || [
    'button:not([aria-hidden="true"])',
    'a[href]:not([aria-hidden="true"])',
    '.card, [class*="card"], [class*="Card"]',
    '.btn, [class*="btn"], [class*="Button"], [role="button"]',
    'nav, [class*="nav"], [class*="Nav"], header',
    'section, [class*="section"], [class*="Section"]',
    '.hero, [class*="hero"], [class*="Hero"], [class*="banner"]',
    '.pricing, [class*="pricing"], [class*="Pricing"], [class*="plan"]',
    'input, textarea, select',
    '.badge, [class*="badge"], .tag, [class*="tag"], .chip',
    'footer',
  ];

  const results = [];
  const seen = new Set();

  const STYLE_KEYS = [
    'display','position','flexDirection','flexWrap','justifyContent','alignItems','gap',
    'columnGap','rowGap',
    'width','height','minWidth','maxWidth','minHeight','maxHeight',
    'margin','marginTop','marginRight','marginBottom','marginLeft',
    'padding','paddingTop','paddingRight','paddingBottom','paddingLeft',
    'fontFamily','fontSize','fontWeight','fontStyle','lineHeight',
    'letterSpacing','textAlign','textTransform','textDecoration','color','textShadow',
    'backgroundColor','backgroundImage','backgroundSize','backgroundPosition','backgroundRepeat','opacity',
    'border','borderTop','borderRight','borderBottom','borderLeft',
    'borderRadius','borderColor','borderWidth','borderStyle',
    'borderTopLeftRadius','borderTopRightRadius',
    'borderBottomLeftRadius','borderBottomRightRadius',
    'boxShadow','filter','backdropFilter',
    'transition','animation','animationName','animationDuration','animationTimingFunction',
    'transform','transformOrigin',
    'overflow','overflowX','overflowY','visibility','zIndex',
    'cursor','pointerEvents','userSelect',
    'flex','flexGrow','flexShrink','flexBasis',
    'gridTemplateColumns','gridColumn','gridRow',
    'whiteSpace','wordBreak',
  ];

  function toCamelCase(kebab) {
    return kebab.replace(/-([a-z])/g, (_, c) => c.toUpperCase());
  }

  function extractComputedStyles(el) {
    const style = getComputedStyle(el);
    const extracted = {};
    for (const key of STYLE_KEYS) {
      const cssProp = key.replace(/([A-Z])/g, '-$1').toLowerCase();
      const val = style.getPropertyValue(cssProp);
      if (val && val !== 'none' && val !== 'normal' && val !== 'auto' &&
          val !== '0px' && val !== 'rgba(0, 0, 0, 0)' && val !== 'transparent' &&
          val !== '' && val !== '0s') {
        extracted[toCamelCase(cssProp)] = val;
      }
    }
    // Resolve CSS variables to names + values
    const variables = {};
    for (let i = 0; i < style.length; i++) {
      const prop = style.item(i);
      if (prop.startsWith('--')) {
        variables[prop] = style.getPropertyValue(prop).trim();
      }
    }
    if (Object.keys(variables).length) {
      extracted._cssVariables = variables;
    }
    return extracted;
  }

  function extractPseudoStyles(el, pseudo) {
    try {
      const style = getComputedStyle(el, pseudo);
      const extracted = {};
      let hasContent = false;
      for (const key of STYLE_KEYS) {
        const cssProp = key.replace(/([A-Z])/g, '-$1').toLowerCase();
        const val = style.getPropertyValue(cssProp);
        if (val && val !== 'none' && val !== 'normal' && val !== 'auto' &&
            val !== '0px' && val !== 'rgba(0, 0, 0, 0)' && val !== 'transparent' &&
            val !== '' && val !== '0s') {
          extracted[toCamelCase(cssProp)] = val;
          hasContent = true;
        }
      }
      const content = style.getPropertyValue('content');
      if (content && content !== 'none' && content !== 'normal') {
        extracted.content = content;
        hasContent = true;
      }
      return hasContent ? extracted : null;
    } catch (e) {
      return null;
    }
  }

  function tryInlineImage(src) {
    if (!src || !INLINE_IMAGES) return null;
    // Only inline same-origin images or data-URLs already
    if (src.startsWith('data:')) return src;
    try {
      const canvas = document.createElement('canvas');
      const img = document.createElement('img');
      img.crossOrigin = 'anonymous';
      img.src = src;
      // Synchronous canvas draw won't work; we note hints for Python side instead
      return { _hint: 'inline', src: src };
    } catch (e) {
      return null;
    }
  }

  function extractChildren(el, depth) {
    if (depth <= 0) return [];
    const kids = [];
    for (const child of el.children) {
      const tag = child.tagName.toLowerCase();
      const childStyles = extractComputedStyles(child);
      const childObj = {
        tag: tag,
        text: (child.innerText || child.textContent || '').trim().slice(0, 200),
        classes: (child.className && typeof child.className === 'string' ? child.className : '').slice(0, 300),
        styles: childStyles,
        children: extractChildren(child, depth - 1),
        src: child.src || child.getAttribute('src') || null,
        href: child.href || child.getAttribute('href') || null,
      };
      if (tag === 'img' && childObj.src) {
        const inlined = tryInlineImage(childObj.src);
        if (inlined) childObj._imageHint = inlined;
      }
      kids.push(childObj);
      if (kids.length >= 20) break; // cap per level
    }
    return kids;
  }

  for (const sel of SELECTORS) {
    try {
      const els = document.querySelectorAll(sel);
      for (const el of els) {
        if (seen.has(el)) continue;
        if (results.length >= MAX_ELEMENTS) break;
        seen.add(el);

        const extracted = extractComputedStyles(el);

        // Pseudo-elements
        const before = extractPseudoStyles(el, '::before');
        const after = extractPseudoStyles(el, '::after');
        if (before || after) {
          extracted._pseudo = {};
          if (before) extracted._pseudo.before = before;
          if (after) extracted._pseudo.after = after;
        }

        // Classify
        const tag = el.tagName.toLowerCase();
        const classes = el.className && typeof el.className === 'string' ? el.className : '';
        const text = (el.innerText || el.textContent || '').trim().slice(0, 200);
        const role = el.getAttribute('role') || '';
        const ariaLabel = el.getAttribute('aria-label') || '';

        let compType = tag;
        const lower = (tag + ' ' + classes + ' ' + text + ' ' + role + ' ' + ariaLabel).toLowerCase();
        if (/button|btn|cta/i.test(lower) || tag === 'button') compType = 'button';
        else if (/nav|navbar|header|menu|sidebar/i.test(lower) || tag === 'nav') compType = 'nav';
        else if (/hero|banner|jumbotron|masthead/i.test(lower)) compType = 'hero';
        else if (/card|tile|panel/i.test(lower)) compType = 'card';
        else if (/pricing|plan|tier/i.test(lower)) compType = 'pricing';
        else if (/footer|copyright/i.test(lower)) compType = 'footer';
        else if (/badge|tag|chip|pill/i.test(lower)) compType = 'badge';
        else if (tag === 'input' || tag === 'textarea' || tag === 'select') compType = 'input_field';

        const src = el.src || el.getAttribute('src') || null;
        const href = el.href || el.getAttribute('href') || null;

        results.push({
          type: compType,
          tag: tag,
          text: text,
          ariaLabel: ariaLabel,
          classes: classes.slice(0, 300),
          styles: extracted,
          children: extractChildren(el, MAX_DEPTH),
          href: href,
          src: src,
          _imageHint: tag === 'img' && src ? tryInlineImage(src) : null,
          boundingBox: {
            x: Math.round(el.getBoundingClientRect().x),
            y: Math.round(el.getBoundingClientRect().y),
            w: Math.round(el.getBoundingClientRect().width),
            h: Math.round(el.getBoundingClientRect().height),
          },
        });

        if (results.length >= MAX_ELEMENTS) break;
      }
    } catch(e) {}
    if (results.length >= MAX_ELEMENTS) break;
  }

  const groups = {};
  for (const r of results) {
    const t = r.type;
    if (!groups[t]) groups[t] = [];
    groups[t].push(r);
  }

  return {
    elements: results,
    groups: groups,
    summary: Object.fromEntries(
      Object.entries(groups).map(([k, v]) => [k, v.length])
    ),
    total: results.length,
    opts: { maxElements: MAX_ELEMENTS, maxDepth: MAX_DEPTH, inlineImages: INLINE_IMAGES },
  };
}
"""


# ---------- Python wrapper ----------


async def qa_extract_elements(
    mgr: SessionManager,
    session_id: str,
    max_elements: int = 50,
    max_depth: int = 3,
    selectors: list[str] | None = None,
    include_children: bool = True,
    inline_images: bool = True,
) -> dict[str, Any]:
    """Extract pixel-level UI components from the current page.

    For each major UI element (buttons, cards, nav, hero, pricing, forms),
    returns exact computed CSS: colors, typography, spacing, borders,
    shadows, layout. Plus bounding box, text content, and simplified DOM
    children.

    Unlike qa_design_interaction_scan (which finds special effects) and
    qa_inspiration_analyze_url (which abstracts patterns), this tool gives
    you the RAW CSS values you need to recreate elements 1:1.

    Args:
        session_id: Browser session from browser_open.
        max_elements: Cap on total elements returned (default 50).
        max_depth: How many levels deep to recurse into children (default 3).
        selectors: Optional list of CSS selectors to target specific
                   elements. If omitted, auto-discovers major components.
        include_children: Include DOM subtree for structure.
        inline_images: Note image URLs for inlining (default True).

    Returns:
        {
            elements: [{type, tag, text, classes, styles:{...},
                        boundingBox:{x,y,w,h}, children:[...]}],
            groups: {"button": [...], "card": [...], ...},
            summary: {"button": N, "card": N, ...},
            total: N
        }

    The `styles` dict contains only non-default CSS properties - every
    value you need to recreate the element in your own codebase.
    """
    s = mgr.get(session_id)
    from .qa_tools import _wait_for_content
    await _wait_for_content(s.page)

    result = await s.page.evaluate(_EXTRACTOR_JS, {
        "max_elements": max_elements,
        "max_depth": max_depth if include_children else 0,
        "selectors": selectors,
        "inline_images": inline_images,
    })

    return result


# ---------- style diff (compare two elements) ----------


def diff_elements(a: dict[str, Any], b: dict[str, Any]) -> dict[str, Any]:
    """Compare two extracted elements and return style differences.

    Useful for originality checks: "how similar is this button to that one?"
    """
    sa = a.get("styles", {})
    sb = b.get("styles", {})

    all_keys = set(sa.keys()) | set(sb.keys())
    diffs: list[dict[str, Any]] = []
    identical = 0
    different = 0

    for key in sorted(all_keys):
        va = sa.get(key)
        vb = sb.get(key)
        if va == vb:
            identical += 1
        else:
            different += 1
            diffs.append({"property": key, "a": va, "b": vb})

    return {
        "element_a": {"type": a.get("type"), "text": a.get("text", "")[:60]},
        "element_b": {"type": b.get("type"), "text": b.get("text", "")[:60]},
        "identical_properties": identical,
        "different_properties": different,
        "similarity": round(identical / max(len(all_keys), 1), 2),
        "diffs": diffs[:20],
    }


# ---------- style export (Tailwind / CSS / inline) ----------


def styles_to_tailwind(styles: dict[str, str]) -> list[str]:
    """Convert extracted CSS properties to Tailwind classes (best effort).
    
    Maps common property:value pairs to their Tailwind equivalents.
    Covers: colors, typography, spacing, layout, borders, shadows, sizing.
    """
    classes: list[str] = []

    # Background color
    bg = styles.get("backgroundColor")
    if bg:
        classes.append(f"/* bg: {bg} */")

    # Text color
    color = styles.get("color")
    if color:
        classes.append(f"/* text: {color} */")

    # Font size
    fs = styles.get("fontSize")
    if fs:
        try:
            px = int(float(fs.replace("px", "")))
        except ValueError:
            px = 16
        tw_map = {10:"xs", 12:"sm", 14:"sm", 16:"base", 18:"lg", 20:"xl", 24:"2xl", 30:"3xl", 36:"4xl", 48:"5xl", 60:"6xl", 72:"7xl"}
        for threshold, name in sorted(tw_map.items(), reverse=True):
            if px >= threshold:
                classes.append(f"text-{name}")
                break
        else:
            classes.append(f"text-[{fs}]")

    # Font weight
    fw = styles.get("fontWeight")
    if fw:
        try:
            fw_int = int(fw)
        except ValueError:
            fw_int = 400
        tw_fw = {100:"thin", 200:"extralight", 300:"light", 400:"normal", 500:"medium", 600:"semibold", 700:"bold", 800:"extrabold", 900:"black"}
        classes.append(f"font-{tw_fw.get(fw_int, 'normal')}")

    # Font family — note the full stack as comment
    ff = styles.get("fontFamily")
    if ff:
        classes.append(f"/* font-family: {ff} */")
        import re as _re
        first = _re.split(r"[,;]", ff)[0].strip().strip("'\"\"")
        if 'inter' in first.lower():
            classes.append("font-sans")
        elif 'roboto' in first.lower():
            classes.append("font-sans")
        elif 'serif' in first.lower():
            classes.append("font-serif")
        elif 'mono' in first.lower():
            classes.append("font-mono")

    # Letter spacing
    ls = styles.get("letterSpacing")
    if ls:
        try:
            lspx = float(ls.replace("px", ""))
            # Tailwind: tracking-tighter (-0.05em), tight (-0.025em), normal (0), wide (0.025em), wider (0.05em), widest (0.1em)
            if lspx <= -1:
                classes.append("tracking-tighter")
            elif lspx < -0.3:
                classes.append("tracking-tight")
            elif lspx >= 2:
                classes.append("tracking-widest")
            elif lspx >= 1:
                classes.append("tracking-wider")
            elif lspx >= 0.3:
                classes.append("tracking-wide")
        except ValueError:
            pass

    # Line height
    lh = styles.get("lineHeight")
    if lh:
        try:
            lhv = float(lh.replace("px", ""))
            fs_px = int(float((fs or "16px").replace("px", "")))
            ratio = lhv / fs_px if fs_px else 1
            if ratio <= 1:
                classes.append("leading-none")
            elif ratio <= 1.25:
                classes.append("leading-tight")
            elif ratio <= 1.375:
                classes.append("leading-snug")
            elif ratio <= 1.5:
                classes.append("leading-normal")
            elif ratio <= 1.625:
                classes.append("leading-relaxed")
            else:
                classes.append("leading-loose")
        except ValueError:
            pass

    # Text align
    ta = styles.get("textAlign")
    if ta == "center":
        classes.append("text-center")
    elif ta == "right" or ta == "end":
        classes.append("text-end")
    elif ta == "left" or ta == "start":
        classes.append("text-start")
    elif ta == "justify":
        classes.append("text-justify")

    # Text transform
    tt = styles.get("textTransform")
    if tt == "uppercase":
        classes.append("uppercase")
    elif tt == "lowercase":
        classes.append("lowercase")
    elif tt == "capitalize":
        classes.append("capitalize")

    # Border radius (all corners)
    br = styles.get("borderRadius")
    if br:
        try:
            px = int(float(br.replace("px", "")))
        except ValueError:
            px = 0
        if px >= 9999:
            classes.append("rounded-full")
        elif px >= 24:
            classes.append("rounded-3xl")
        elif px >= 16:
            classes.append("rounded-2xl")
        elif px >= 12:
            classes.append("rounded-xl")
        elif px >= 8:
            classes.append("rounded-lg")
        elif px >= 6:
            classes.append("rounded-md")
        elif px >= 4:
            classes.append("rounded")
        elif px >= 2:
            classes.append("rounded-sm")
        else:
            classes.append(f"rounded-[{br}]")

    # Padding — handle shorthand
    pad = styles.get("padding")
    if pad:
        parts = pad.split()
        try:
            if len(parts) == 1:
                px = int(float(parts[0].replace("px", "")))
                tw_pad = {0:"0", 4:"1", 8:"2", 12:"3", 16:"4", 20:"5", 24:"6", 28:"7", 32:"8", 40:"10", 48:"12", 64:"16", 80:"20", 96:"24"}
                for threshold, name in sorted(tw_pad.items(), reverse=True):
                    if px >= threshold:
                        classes.append(f"p-{name}")
                        break
            elif len(parts) == 2:
                py = int(float(parts[0].replace("px", "")))
                px = int(float(parts[1].replace("px", "")))
                tw_pad = {0:"0", 4:"1", 8:"2", 12:"3", 16:"4", 20:"5", 24:"6", 28:"7", 32:"8", 40:"10", 48:"12", 64:"16"}
                for threshold, name in sorted(tw_pad.items(), reverse=True):
                    if py >= threshold:
                        classes.append(f"py-{name}")
                        break
                for threshold, name in sorted(tw_pad.items(), reverse=True):
                    if px >= threshold:
                        classes.append(f"px-{name}")
                        break
            elif len(parts) == 4:
                pt = int(float(parts[0].replace("px", "")))
                pr = int(float(parts[1].replace("px", "")))
                pb = int(float(parts[2].replace("px", "")))
                pl = int(float(parts[3].replace("px", "")))
                # Use py if top==bottom, px if left==right
                if pt == pb:
                    for threshold, name in sorted(tw_pad.items(), reverse=True):
                        if pt >= threshold:
                            classes.append(f"py-{name}")
                            break
                if pr == pl:
                    for threshold, name in sorted(tw_pad.items(), reverse=True):
                        if px >= threshold:
                            classes.append(f"px-{name}")
                            break
        except (ValueError, IndexError):
            pass

    # Margin shorthand
    m = styles.get("margin")
    if m and m != "0px":
        parts = m.split()
        try:
            if len(parts) == 1:
                px = int(float(parts[0].replace("px", "")))
                tw_m = {4:"1", 8:"2", 12:"3", 16:"4", 20:"5", 24:"6", 32:"8", 40:"10", 48:"12"}
                for threshold, name in sorted(tw_m.items(), reverse=True):
                    if px >= threshold:
                        classes.append(f"m-{name}")
                        break
            elif len(parts) == 2:
                my = int(float(parts[0].replace("px", "")))
                mx = int(float(parts[1].replace("px", "")))
                for threshold, name in sorted(tw_m.items(), reverse=True):
                    if my >= threshold:
                        classes.append(f"my-{name}")
                        break
                for threshold, name in sorted(tw_m.items(), reverse=True):
                    if mx >= threshold:
                        classes.append(f"mx-{name}")
                        break
        except (ValueError, IndexError):
            pass

    # Width
    w = styles.get("width")
    if w and w != "auto":
        try:
            wpx = int(float(w.replace("px", "")))
            if wpx >= 3840:
                classes.append("w-screen")
            elif wpx >= 100:
                classes.append(f"w-[{w}]")
            else:
                classes.append(f"w-[{w}]")
        except ValueError:
            classes.append(f"/* width: {w} */")

    # Height
    h = styles.get("height")
    if h and h != "auto":
        try:
            int(float(h.replace("px", "")))
            classes.append(f"h-[{h}]")
        except ValueError:
            classes.append(f"/* height: {h} */")

    # Display / layout
    display = styles.get("display")
    if display == "flex":
        classes.append("flex")
        fd = styles.get("flexDirection")
        if fd == "column":
            classes.append("flex-col")
        elif fd == "row-reverse":
            classes.append("flex-row-reverse")
        elif fd == "column-reverse":
            classes.append("flex-col-reverse")
        jc = styles.get("justifyContent")
        if jc == "center":
            classes.append("justify-center")
        elif jc == "space-between":
            classes.append("justify-between")
        elif jc == "space-around":
            classes.append("justify-around")
        elif jc == "space-evenly":
            classes.append("justify-evenly")
        elif jc == "flex-end" or jc == "end":
            classes.append("justify-end")
        elif jc == "flex-start" or jc == "start":
            classes.append("justify-start")
        ai = styles.get("alignItems")
        if ai == "center":
            classes.append("items-center")
        elif ai == "flex-start" or ai == "start":
            classes.append("items-start")
        elif ai == "flex-end" or ai == "end":
            classes.append("items-end")
        elif ai == "stretch":
            classes.append("items-stretch")
        gap = styles.get("gap")
        if gap:
            parts = gap.split()
            gpx = int(float(parts[0].replace("px", "")))
            tw_gap = {4:"1", 8:"2", 12:"3", 16:"4", 20:"5", 24:"6", 32:"8", 40:"10", 48:"12"}
            for threshold, name in sorted(tw_gap.items(), reverse=True):
                if gpx >= threshold:
                    classes.append(f"gap-{name}")
                    break
        cg = styles.get("columnGap")
        if cg:
            try:
                cgpx = int(float(cg.replace("px", "")))
                for threshold, name in sorted(tw_gap.items(), reverse=True):
                    if cgpx >= threshold:
                        classes.append(f"gap-x-{name}")
                        break
            except ValueError:
                pass
        rg = styles.get("rowGap")
        if rg:
            try:
                rgpx = int(float(rg.replace("px", "")))
                for threshold, name in sorted(tw_gap.items(), reverse=True):
                    if rgpx >= threshold:
                        classes.append(f"gap-y-{name}")
                        break
            except ValueError:
                pass

    elif display == "grid":
        classes.append("grid")
        gtc = styles.get("gridTemplateColumns")
        if gtc and "repeat" in gtc:
            import re as _re
            m = _re.search(r'repeat\((\d+)', gtc)
            if m:
                classes.append(f"grid-cols-{m.group(1)}")

    elif display == "block":
        pass  # default
    elif display == "inline-block":
        classes.append("inline-block")
    elif display == "inline-flex":
        classes.append("inline-flex")

    # Box shadow
    shadow = styles.get("boxShadow")
    if shadow and shadow != "none":
        classes.append(f"/* shadow: {shadow} */")

    # Border
    border = styles.get("border")
    if border and border != "none" and border != "0px none rgb(0, 0, 0)":
        try:
            bw = int(float(border.split()[0].replace("px", "")))
            if bw == 1:
                classes.append("border")
            elif bw == 2:
                classes.append("border-2")
            elif bw == 4:
                classes.append("border-4")
            elif bw == 8:
                classes.append("border-8")
        except (ValueError, IndexError):
            pass
        classes.append(f"/* border: {border} */")

    # Border color
    bc = styles.get("borderColor")
    if bc:
        classes.append(f"/* border-color: {bc} */")

    # Background image
    bi = styles.get("backgroundImage")
    if bi and bi != "none":
        classes.append(f"/* background-image: {bi} */")

    # Backdrop filter (frosted glass)
    bf = styles.get("backdropFilter")
    if bf and bf != "none":
        classes.append("backdrop-blur")

    # Filter
    filt = styles.get("filter")
    if filt and filt != "none":
        classes.append(f"/* filter: {filt} */")

    # Transform
    tr = styles.get("transform")
    if tr and tr != "none":
        classes.append(f"/* transform: {tr} */")

    # Cursor
    cursor = styles.get("cursor")
    if cursor == "pointer":
        classes.append("cursor-pointer")
    elif cursor == "not-allowed":
        classes.append("cursor-not-allowed")

    # Pointer events
    pe = styles.get("pointerEvents")
    if pe == "none":
        classes.append("pointer-events-none")

    # Overflow
    ov = styles.get("overflow")
    if ov == "hidden":
        classes.append("overflow-hidden")
    elif ov == "auto":
        classes.append("overflow-auto")
    elif ov == "scroll":
        classes.append("overflow-scroll")

    # User select
    us = styles.get("userSelect")
    if us == "none":
        classes.append("select-none")
    elif us == "all":
        classes.append("select-all")

    # White space
    ws = styles.get("whiteSpace")
    if ws == "nowrap":
        classes.append("whitespace-nowrap")
    elif ws == "pre":
        classes.append("whitespace-pre")
    elif ws == "pre-line":
        classes.append("whitespace-pre-line")

    # Opacity
    op = styles.get("opacity")
    if op:
        try:
            opv = float(op)
            if opv != 1:
                classes.append(f"/* opacity: {op} */")
        except ValueError:
            pass

    # Z-index
    zi = styles.get("zIndex")
    if zi:
        classes.append(f"/* z-index: {zi} */")

    return classes


def element_to_tailwind(element: dict[str, Any]) -> dict[str, Any]:
    """Convert a single extracted element to Tailwind CSS classes."""
    return {
        "type": element.get("type"),
        "tag": element.get("tag"),
        "text": element.get("text", "")[:100],
        "tailwind_classes": styles_to_tailwind(element.get("styles", {})),
        "raw_css": element.get("styles", {}),
        "boundingBox": element.get("boundingBox"),
    }
