"""Anti-detection patches for Playwright / Chromium.

Cloudflare, Akamai, DataDome, and other CDN/WAF providers fingerprint
automated browsers. Playwright's bundled Chromium triggers several signals:

1. navigator.webdriver === true (the #1 signal)
2. Empty navigator.plugins / mimeTypes arrays
3. Missing window.chrome object
4. WebGL vendor/renderer strings (blank or generic)
5. Permission.query() behavior
6. CDP Runtime (__playwright__ globals)
7. TLS fingerprint (JA3/JA4 — cannot be patched in JS alone)

Layers of defense:
  Layer 1 — Launch args: --disable-blink-features=AutomationControlled
           removes the "Chrome is being controlled by automated test
           software" info bar and the navigator.webdriver flag at the
           browser level.
  Layer 2 — CDP via cdp_session.send('Page.addScriptToEvaluateOnNewDocument')
           runs BEFORE any page JS, even before add_init_script. This is
           the strongest JS-level defense.
  Layer 3 — add_init_script (fallback for browsers that don't expose
           CDP, e.g. WebKit/Firefox).

References (evolving — fingerprinters adapt):
  - Cloudflare Bot Management (public signals)
  - puppeteer-extra-plugin-stealth (reference implementation)
  - https://github.com/rebrowser/rebrowser-playwright (patched fork,

References:
  - puppeteer-extra-plugin-stealth
  - https://fingerprint.com/blog/bot-detection-techniques/
  - Chrome DevTools Protocol: Page.addScriptToEvaluateOnNewDocument
"""

from __future__ import annotations

import sys
from typing import Any


# ---------- Layer 1: Chrome launch args ----------

# Chromium args that reduce the automation fingerprint.
# --disable-blink-features=AutomationControlled is the critical one:
# it removes the navigator.webdriver flag at the browser level.
STEALTH_CHROMIUM_ARGS = [
    "--disable-blink-features=AutomationControlled",
    "--disable-features=IsolateOrigins,site-per-process",
    "--disable-site-isolation-trials",
    "--disable-web-security",  # allows cross-origin iframe access
    "--disable-features=TranslateUI",
    "--disable-ipc-flooding-protection",
    "--disable-renderer-backgrounding",
    "--disable-background-timer-throttling",
    "--disable-backgrounding-occluded-windows",
    "--disable-breakpad",
    "--disable-component-extensions-with-background-pages",
    "--disable-crash-reporter",
    "--disable-dev-shm-usage",
    "--disable-extensions",
    "--disable-hang-monitor",
    "--disable-popup-blocking",
    "--disable-prompt-on-repost",
    "--disable-sync",
    "--enable-features=NetworkService,NetworkServiceInProcess",
    "--force-color-profile=srgb",
    "--metrics-recording-only",
    "--no-first-run",
    "--password-store=basic",
    "--use-mock-keychain",
]

# Default user-agent to use when stealth is enabled (no override given).
# Matches a recent stable Chrome on Windows — avoids the bundled
# Chromium's distinctive UA string.
STEALTH_DEFAULT_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36"
)


# ---------- Layer 2: CDP-level patches (strongest) ----------

STEALTH_CDP_SCRIPT = r"""// stealth (CDP): neutralize automation signals
(function() {
  // 1. Hide navigator.webdriver — the #1 detection signal
  Object.defineProperty(navigator, 'webdriver', { get: () => false });

  // 2. Remove __playwright__ / __pw_manual__ globals
  delete window.__playwright;
  delete window.__pw_manual;
  delete window.__PW_inspect;

  // 3. Populate plugins array (Chrome PDF Plugin + Chrome PDF Viewer)
  Object.defineProperty(navigator, 'plugins', {
    get: () => {
      const makeMime = (type, suffixes, desc) => {
        const m = { type, suffixes, description: desc || '' };
        Object.setPrototypeOf(m, MimeType.prototype);
        return m;
      };
      const makePlugin = (name, filename, desc, mimeTypes) => {
        const plugin = { name, filename, description: desc, length: mimeTypes.length };
        mimeTypes.forEach((m, i) => { plugin[i] = m; });
        plugin.item = (i) => mimeTypes[i] || null;
        plugin.namedItem = (n) => mimeTypes.find(m => m.type === n) || null;
        Object.setPrototypeOf(plugin, Plugin.prototype);
        return plugin;
      };
      const pdfMime = makeMime('application/pdf', 'pdf', 'Portable Document Format');
      const viewerMime = makeMime('text/pdf', 'pdf', 'Portable Document Format');
      const arr = [
        makePlugin('Chrome PDF Plugin', 'internal-pdf-viewer', 'Portable Document Format', [pdfMime]),
        makePlugin('Chrome PDF Viewer', 'mhjfbmdgcfjbbpaeojofohoefgiehjai', '', [viewerMime]),
      ];
      Object.setPrototypeOf(arr, PluginArray.prototype);
      return arr;
    }
  });

  // 4. Populate mimeTypes
  Object.defineProperty(navigator, 'mimeTypes', {
    get: () => {
      const make = (type, suffixes, desc) => {
        const m = { type, suffixes, description: desc || '' };
        Object.setPrototypeOf(m, MimeType.prototype);
        return m;
      };
      const arr = [
        make('application/pdf', 'pdf', 'Portable Document Format'),
        make('text/pdf', 'pdf', 'Portable Document Format'),
      ];
      Object.setPrototypeOf(arr, MimeTypeArray.prototype);
      return arr;
    }
  });

  // 5. Add window.chrome (present in real Chrome)
  window.chrome = {
    runtime: { onConnect: { addListener: () => {}, removeListener: () => {} } },
    loadTimes: () => {},
    csi: () => {},
    app: {},
  };

  // 6. Override permissions.query
  const origQuery = navigator.permissions.query.bind(navigator.permissions);
  navigator.permissions.query = (parameters) => {
    if (parameters.name === 'notifications') {
      return Promise.resolve({
        state: Notification.permission,
        onchange: null,
        addEventListener: () => {},
        removeEventListener: () => {},
      });
    }
    return origQuery(parameters);
  };

  // 7. Fix WebGL vendor/renderer
  try {
    const getParamHandler = {
      apply(target, ctx, args) {
        const param = args[0];
        if (param === 37445) return 'Google Inc. (Intel)';
        if (param === 37446) return 'ANGLE (Intel, Intel(R) UHD Graphics 620 Direct3D11 vs_5_0 ps_5_0, D3D11)';
        return Reflect.apply(target, ctx, args);
      }
    };
    for (const name of ['webgl', 'experimental-webgl']) {
      const canvas = document.createElement('canvas');
      const gl = canvas.getContext(name);
      if (gl) {
        gl.getParameter = new Proxy(gl.getParameter, getParamHandler);
        const origExt = gl.getExtension.bind(gl);
        gl.getExtension = (extName) => {
          if (extName === 'WEBGL_debug_renderer_info') return null;
          return origExt(extName);
        };
      }
    }
  } catch(e) {}

  // 8. Navigator hardware concurrency, deviceMemory, platform
  Object.defineProperty(navigator, 'hardwareConcurrency', { get: () => 8 });
  Object.defineProperty(navigator, 'deviceMemory', { get: () => 8 });
  Object.defineProperty(navigator, 'platform', { get: () => 'Win32' });
  Object.defineProperty(navigator, 'vendor', { get: () => 'Google Inc.' });
  Object.defineProperty(navigator, 'maxTouchPoints', { get: () => 0 });

  // 9. Languages
  Object.defineProperty(navigator, 'languages', {
    get: () => ['en-US', 'en', 'he-IL', 'he'],
  });

  // 10. Remove CDP-related properties
  for (const key of Object.keys(window)) {
    if (key.startsWith('__playwright') || key.startsWith('__pw') || key === '__nightmare') {
      delete window[key];
    }
  }
})();
"""


# ---------- Layer 3: add_init_script (WebKit / Firefox fallback) ----------

# Same as the CDP script but split for clarity. Used when CDP is
# unavailable (WebKit, Firefox).
_STEALTH_INIT_SCRIPT = STEALTH_CDP_SCRIPT  # identical for now


STEALTH_PATCH_NAMES = [
    "webdriver",
    "playwright_globals",
    "plugins",
    "mime_types",
    "chrome_runtime",
    "permissions",
    "webgl",
    "hardware",
    "languages",
    "cdp_cleanup",
    "launch_args",
    "user_agent",
    "cdp_script",
]


async def apply_stealth(page_or_context: Any,
                         cdp_session: Any | None = None,
                         ) -> dict[str, bool]:
    """Apply anti-detection patches via CDP (preferred) or init script.

    Must be called BEFORE the first navigation.

    CDP-level patches via Page.addScriptToEvaluateOnNewDocument run
    before any page JavaScript — the strongest defense available in
    Playwright. Falls back to add_init_script when CDP is unavailable.

    Returns a dict of patch-name -> applied for observability.
    """
    applied: dict[str, bool] = {}

    # Init script always (works everywhere)
    try:
        await page_or_context.add_init_script(_STEALTH_INIT_SCRIPT)
        applied["init_script"] = True
    except Exception:
        applied["init_script"] = False

    # CDP-level: stronger, runs before any page JS
    if cdp_session:
        try:
            await cdp_session.send(
                "Page.addScriptToEvaluateOnNewDocument",
                {"source": STEALTH_CDP_SCRIPT},
            )
            applied["cdp_script"] = True
        except Exception as exc:
            print(
                f"[qa-mcp] stealth: CDP addScriptToEvaluateOnNewDocument "
                f"failed ({exc}); falling back to init script only",
                file=sys.stderr,
                flush=True,
            )
            applied["cdp_script"] = False
    else:
        applied["cdp_script"] = False

    # Mark the individual patches as applied (both layers)
    for name in [
        "webdriver", "playwright_globals", "plugins", "mime_types",
        "chrome_runtime", "permissions", "webgl", "hardware",
        "languages", "cdp_cleanup",
    ]:
        applied[name] = applied.get("init_script", False) or applied.get("cdp_script", False)

    return applied
