"""HTML exporter — from extracted DOM tree to pixel-perfect HTML.

Takes the output of qa_extract_elements (or the full DOM extraction)
and generates a standalone HTML file that replicates the original
design 1:1. No simplifications, no approximations.
"""

from __future__ import annotations

import html as html_module
from pathlib import Path
from typing import Any


def _css_inline(styles: dict[str, Any]) -> str:
    """Convert extracted styles dict to inline CSS string."""
    parts: list[str] = []
    for k, v in styles.items():
        if k.startswith("_"):
            continue  # skip internal metadata (pseudo, variables)
        if isinstance(v, dict):
            continue  # skip nested objects
        # camelCase to kebab-case
        css_key = k[0].lower() + "".join(f"-{c.lower()}" if c.isupper() else c for c in k[1:])
        parts.append(f"{css_key}: {v}")
    return "; ".join(parts)


def _pseudo_to_css(selector: str, pseudo: str, styles: dict[str, Any]) -> str:
    """Convert pseudo-element styles to CSS rule."""
    parts: list[str] = []
    for k, v in styles.items():
        if k.startswith("_"):
            continue
        if k == "content":
            parts.append(f"content: {v}")
            continue
        css_key = k[0].lower() + "".join(f"-{c.lower()}" if c.isupper() else c for c in k[1:])
        parts.append(f"{css_key}: {v}")
    if not parts:
        return ""
    pseudo_sel = f"{selector}::{pseudo.lstrip(':')}"
    return f"{pseudo_sel} {{ {'; '.join(parts)} }}"


def _element_to_html(el: dict[str, Any], depth: int = 0,
                     pseudo_rules: list[str] | None = None,
                     id_counter: list[int] | None = None) -> str:
    """Recursively convert an extracted element to HTML."""
    if not el:
        return ""

    tag = el.get("tag", "div")
    text = el.get("text", "")
    classes = el.get("classes", "")
    styles = el.get("styles", {})
    children = el.get("children", [])
    src = el.get("src")
    href = el.get("href")

    indent = "  " * depth
    inline_css = _css_inline(styles)

    # Generate unique class for pseudo-element targeting
    elem_cls = None
    if pseudo_rules is not None and styles.get("_pseudo"):
        if id_counter is None:
            id_counter = [0]
        id_counter[0] += 1
        elem_cls = f"qa-mcp-el-{id_counter[0]}"
        for pseudo, pseudo_styles in styles["_pseudo"].items():
            rule = _pseudo_to_css(f".{elem_cls}", pseudo, pseudo_styles)
            if rule:
                pseudo_rules.append(rule)

    # Build opening tag
    attrs = []
    cls_parts = []
    if classes:
        cls_parts.append(classes)
    if elem_cls:
        cls_parts.append(elem_cls)
    if cls_parts:
        attrs.append('class="{}"'.format(" ".join(cls_parts)))
    if inline_css:
        attrs.append(f'style="{inline_css}"')
    if el.get("id"):
        attrs.append(f'id="{el["id"]}"')
    if src and tag in ("img", "video", "audio", "source"):
        attrs.append(f'src="{src}"')
    if href and tag == "a":
        attrs.append(f'href="{href}"')

    attr_str = " " + " ".join(attrs) if attrs else ""

    # Self-closing tags
    if tag in ("img", "br", "hr", "input", "meta", "link", "source"):
        return f"{indent}<{tag}{attr_str} />\n"

    # Void elements (no children, may have text)
    if tag in ("script", "style", "pre", "code"):
        escaped = html_module.escape(text[:2000]) if text else ""
        return f"{indent}<{tag}{attr_str}>{escaped}</{tag}>\n"

    # Container elements
    if not children and not text:
        return f"{indent}<{tag}{attr_str}></{tag}>\n"

    if not children:
        escaped = html_module.escape(text)
        return f"{indent}<{tag}{attr_str}>{escaped}</{tag}>\n"

    # Has children — multi-line
    lines = [f"{indent}<{tag}{attr_str}>"]
    for child in children:
        if isinstance(child, dict):
            lines.append(_element_to_html(child, depth + 1, pseudo_rules, id_counter))
    if text and not any(c.get("text") == text for c in children if isinstance(c, dict)):
        lines.append(f"{indent}  {text}")
    lines.append(f"{indent}</{tag}>")
    return "\n".join(lines)


def _collect_fonts(element_list: list[dict[str, Any]]) -> set[str]:
    """Recursively collect all font families from elements."""
    fonts = set()
    for el in element_list:
        if not isinstance(el, dict):
            continue
        ff = el.get("styles", {}).get("fontFamily")
        if ff:
            fonts.add(ff)
        for child in el.get("children", []):
            if isinstance(child, dict):
                fonts.update(_collect_fonts([child]))
    return fonts


def _extract_pseudo_from_elements(element_list: list[dict[str, Any]]) -> list[str]:
    """Extract all pseudo-element CSS rules from a list of elements."""
    rules: list[str] = []
    counter = [0]

    def recurse(els: list[Any]) -> None:
        for el in els:
            if not isinstance(el, dict):
                continue
            pseudo = el.get("styles", {}).get("_pseudo")
            if pseudo:
                counter[0] += 1
                cls = f"qa-mcp-el-{counter[0]}"
                for p_name, p_styles in pseudo.items():
                    rule = _pseudo_to_css(f".{cls}", p_name, p_styles)
                    if rule:
                        rules.append(rule)
            recurse(el.get("children", []))

    recurse(element_list)
    return rules


def export_to_html(
    extracted: dict[str, Any],
    output_path: str,
    title: str = "Exported Design — qa-mcp",
    include_tailwind: bool = True,
    include_fonts: bool = True,
) -> str:
    """Generate a standalone HTML file from extracted elements.

    Args:
        extracted: Output from qa_extract_elements or similar extraction.
        output_path: Where to write the HTML file.
        title: Page title.
        include_tailwind: Add Tailwind CDN.
        include_fonts: Add Google Fonts for detected font families.

    Returns the path to the generated file.
    """
    sections = extracted.get("sections", extracted.get("elements", []))
    keyframes = extracted.get("keyframes", [])

    # Recursively collect font families
    font_families = _collect_fonts(sections)

    # Extract pseudo-element rules
    pseudo_rules = _extract_pseudo_from_elements(sections)

    # Collect CSS variables
    css_vars: dict[str, str] = {}
    for sec in sections:
        if not isinstance(sec, dict):
            continue
        css_vars.update(sec.get("styles", {}).get("_cssVariables", {}))
        for child in sec.get("children", []):
            if isinstance(child, dict):
                css_vars.update(child.get("styles", {}).get("_cssVariables", {}))

    # Build HTML
    lines: list[str] = []

    def add(s: str) -> None:
        lines.append(s)

    add("<!DOCTYPE html>")
    add('<html lang="he" dir="rtl">')
    add("<head>")
    add('<meta charset="UTF-8">')
    add('<meta name="viewport" content="width=device-width, initial-scale=1.0">')
    add(f"<title>{html_module.escape(title)}</title>")

    if include_tailwind:
        add('<script src="https://cdn.tailwindcss.com"></script>')

    if include_fonts and font_families:
        families = "&#38;".join(
            f"family={f.replace(' ', '+')}:wght@400;500;600;700"
            for f in sorted(font_families)
        )
        add(f'<link href="https://fonts.googleapis.com/css2?{families}" rel="stylesheet">')

    add("<style>")
    add("  * { box-sizing: border-box; }")
    add("  body { margin: 0; padding: 0; }")
    if font_families:
        primary = sorted(font_families)[0]
        add(f"  body {{ font-family: '{primary}', sans-serif; }}")
    if css_vars:
        add("  :root {")
        for k, v in sorted(css_vars.items()):
            add(f"    {k}: {v};")
        add("  }")
    if keyframes:
        for kf in keyframes:
            add(kf.get("css", ""))
    if pseudo_rules:
        add("  /* Pseudo-elements from original */")
        for rule in pseudo_rules:
            add(f"  {rule}")
    add("</style>")
    add("</head>")
    add("<body>")

    # Render each section
    for i, sec in enumerate(sections):
        if not isinstance(sec, dict):
            continue
        label = sec.get("label") or sec.get("type") or f"Section {i+1}"
        add(f"  <!-- {'═' * 20} {label} {'═' * 20} -->")
        add(_element_to_html(sec, depth=1))

    add("</body>")
    add("</html>")

    html = "\n".join(lines)

    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(html, encoding="utf-8")

    return str(path)


def export_component_to_html(
    component: dict[str, Any],
    output_path: str,
    title: str = "Component — qa-mcp",
) -> str:
    """Export a single extracted component to HTML."""
    return export_to_html(
        {"sections": [component], "keyframes": []},
        output_path,
        title=title,
        include_tailwind=True,
        include_fonts=True,
    )
