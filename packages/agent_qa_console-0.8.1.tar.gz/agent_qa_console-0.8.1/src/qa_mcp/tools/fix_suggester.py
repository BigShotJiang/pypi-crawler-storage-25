"""RTL fix suggester — from findings to concrete fixes.

Takes qa_rtl_audit findings and generates specific text/HTML/CSS fixes
for each RTL bug category. The calling agent can then present these as
actionable PR suggestions or apply them to the source code.

Each fix includes: the finding, the fix type, before→after text, a
confidence score, and the CSS selector so the developer (or agent) can
find the exact element in source.

Does NOT modify the page (that's qa_apply_fixes). This module only
generates the fix plan.
"""

from __future__ import annotations

import re
from typing import Any

# ---------- Hebrew digit map ----------

_LATIN_TO_HEBREW_DIGITS = str.maketrans("0123456789", "٠١٢٣٤٥٦٧٨٩")

# ---------- English CTA → Hebrew dictionary ----------

_CTA_HEBREW: dict[str, str] = {
    "get started": "התחל",
    "start now": "התחל עכשיו",
    "sign up": "הרשם",
    "sign in": "התחבר",
    "log in": "התחבר",
    "login": "התחברות",
    "logout": "התנתק",
    "register": "הרשמה",
    "submit": "שלח",
    "send": "שלח",
    "cancel": "בטל",
    "delete": "מחק",
    "edit": "ערוך",
    "save": "שמור",
    "close": "סגור",
    "back": "חזור",
    "next": "הבא",
    "previous": "הקודם",
    "continue": "המשך",
    "search": "חיפוש",
    "download": "הורד",
    "upload": "העלה",
    "share": "שתף",
    "buy now": "קנה עכשיו",
    "add to cart": "הוסף לסל",
    "checkout": "לתשלום",
    "learn more": "למידע נוסף",
    "read more": "קרא עוד",
    "contact us": "צור קשר",
    "about us": "אודות",
    "home": "בית",
    "help": "עזרה",
    "settings": "הגדרות",
    "profile": "פרופיל",
    "try free": "נסה בחינם",
    "free trial": "ניסיון חינם",
    "subscribe": "הירשם",
    "unsubscribe": "בטל הרשמה",
    "view all": "צפה בהכל",
    "view more": "צפה בעוד",
    "show more": "הצג עוד",
    "show less": "הצג פחות",
    "filter": "סינון",
    "sort": "מיין",
    "clear": "נקה",
    "reset": "אפס",
    "apply": "החל",
    "confirm": "אשר",
    "dismiss": "סגור",
    "ok": "אישור",
    "yes": "כן",
    "no": "לא",
    "agree": "מסכים",
    "disagree": "לא מסכים",
}


def _translate_cta(english_text: str) -> str | None:
    """Try to translate an English CTA to Hebrew. Returns None if no match."""
    key = english_text.strip().lower()
    if key in _CTA_HEBREW:
        return _CTA_HEBREW[key]
    # Partial match
    for en, he in sorted(_CTA_HEBREW.items(), key=lambda x: -len(x[0])):
        if en in key:
            return he
    return None


# ---------- Hebrew plural fixer ----------

# Simple dual-form fixer (Hebrew has 3 forms: 1, 2, many, but for a POC
# we handle the most common bug: "X פריטים" where X is 1 or 2).
def _fix_plural(sample: str) -> dict[str, Any]:
    """Analyze a plural bug sample and suggest a fix.

    Example: "1 פריטים" → suggests "פריט 1" or "1 פריט"
    """
    # Pattern: digit + space + Hebrew word(s)
    m = re.match(r"(\d+)\s+(.+)$", sample.strip())
    if not m:
        return {"fixable": False, "reason": "Could not parse number+noun pattern"}

    num = int(m.group(1))
    noun_phrase = m.group(2)

    # Very naive: if number is 1, suggest singular; if 2, suggest dual
    if num == 1:
        # Move number after noun (more natural in Hebrew: "פריט 1")
        suggestion = f"{noun_phrase.rstrip('יםות')} {num}"
        return {
            "fixable": True,
            "before": sample,
            "after": suggestion,
            "explanation": f"1 requires singular form: '{suggestion}'",
            "confidence": 0.7,
        }
    elif num == 2:
        suggestion = f"{num} {noun_phrase.rstrip('יםות')}יים"
        return {
            "fixable": True,
            "before": sample,
            "after": suggestion,
            "explanation": f"2 requires dual form: '{suggestion}'",
            "confidence": 0.5,
        }
    else:
        # 3+ — probably already with ים/ות suffix. Hard to fix without context.
        return {
            "fixable": True,
            "before": sample,
            "after": f"{num} {noun_phrase}",
            "explanation": "3+ should use plural suffix ים/ות",
            "confidence": 0.4,
        }


# ---------- Date disambiguator ----------

_HEBREW_MONTHS = [
    "", "ינואר", "פברואר", "מרץ", "אפריל", "מאי", "יוני",
    "יולי", "אוגוסט", "ספטמבר", "אוקטובר", "נובמבר", "דצמבר",
]


def _disambiguate_date(sample: str) -> dict[str, Any]:
    """Convert ambiguous DD/MM/YYYY to explicit Hebrew date.

    "03/04/2026" → could be March 4 or April 3. We assume DD/MM (Israeli format)
    and suggest an unambiguous format with the month spelled out.
    """
    m = re.search(r"(\d{1,2})/(\d{1,2})/(\d{2,4})", sample)
    if not m:
        return {"fixable": False, "reason": "No DD/MM/YYYY pattern found"}

    d1, d2, year = int(m.group(1)), int(m.group(2)), m.group(3)
    # Assume DD/MM for Hebrew context (Israeli convention)
    if 1 <= d1 <= 31 and 1 <= d2 <= 12:
        month_name = _HEBREW_MONTHS[d2] if d2 < len(_HEBREW_MONTHS) else str(d2)
        suggestion = f"{d1} ב{month_name} {year}"
        return {
            "fixable": True,
            "before": m.group(0),
            "after": suggestion,
            "explanation": f"Assume DD/MM (Israeli convention): {d1} ב{month_name}",
            "confidence": 0.6,
        }
    return {"fixable": False, "reason": "Could not determine date format"}


# ---------- Main fix generation ----------


def suggest_fixes(findings: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Generate fix suggestions for RTL findings.

    Each suggestion includes:
      - finding_index: which finding this fixes
      - category: the RTL category (rtl_digits, rtl_currency, etc.)
      - fix_type: what kind of fix (text_replace, wrap_bdi, swap_position, etc.)
      - before: the current text
      - after: the suggested text
      - selector: CSS selector to find the element
      - explanation: human-readable explanation of the fix
      - confidence: 0-1 how confident the fix is correct
      - requires_review: True if the fix needs human approval
    """
    suggestions: list[dict[str, Any]] = []

    for i, finding in enumerate(findings):
        category = finding.get("category", "")
        sample = finding.get("sample", "")
        selector = finding.get("selector", "")

        if category == "rtl_digits":
            # Option 1: wrap in <bdi> (safest, no false positives)
            # Option 2: convert to Hebrew digits (looks native but may
            #           not match the rest of the UI)
            suggestions.append({
                "finding_index": i,
                "category": category,
                "fix_type": "wrap_bdi",
                "before": sample,
                "after": wrap_latin_digits_in_bdi(sample),
                "selector": selector,
                "explanation": (
                    "Latin digits in Hebrew text break RTL rendering. "
                    "Wrapping digits in <bdi> isolates them from the "
                    "surrounding RTL context. Safer than Hebrew-digit "
                    "conversion (which may not match the UI style)."
                ),
                "confidence": 0.9,
                "requires_review": False,
            })

        elif category == "rtl_currency":
            # Move ₪ from left to right of the number
            fixed = _fix_currency_position(sample)
            if fixed:
                suggestions.append({
                    "finding_index": i,
                    "category": category,
                    "fix_type": "swap_position",
                    "before": sample,
                    "after": fixed,
                    "selector": selector,
                    "explanation": (
                        "In Hebrew, the shekel sign ₪ appears AFTER the "
                        "number (e.g. '99 ₪' not '₪99'). This matches "
                        "Israeli typographic convention."
                    ),
                    "confidence": 0.95,
                    "requires_review": False,
                })

        elif category == "rtl_arrow_direction":
            fixed = sample.replace("→", "←").replace("->", "<-")
            if fixed != sample:
                suggestions.append({
                    "finding_index": i,
                    "category": category,
                    "fix_type": "text_replace",
                    "before": sample,
                    "after": fixed,
                    "selector": selector,
                    "explanation": (
                        "In RTL content, arrows should point LEFT (←) not "
                        "RIGHT (→). This matches the natural reading "
                        "direction for Hebrew speakers."
                    ),
                    "confidence": 0.95,
                    "requires_review": False,
                })

        elif category == "rtl_english_cta":
            heb = _translate_cta(sample)
            if heb:
                suggestions.append({
                    "finding_index": i,
                    "category": category,
                    "fix_type": "text_replace",
                    "before": sample,
                    "after": heb,
                    "selector": selector,
                    "explanation": (
                        f"CTA '{sample}' should be in Hebrew on a Hebrew "
                        f"site. Suggested: '{heb}'."
                    ),
                    "confidence": 0.85 if len(sample.split()) <= 2 else 0.6,
                    "requires_review": True,
                })
            else:
                suggestions.append({
                    "finding_index": i,
                    "category": category,
                    "fix_type": "text_replace",
                    "before": sample,
                    "after": f"[HE: {sample}]",
                    "selector": selector,
                    "explanation": (
                        f"CTA '{sample}' appears in English on a Hebrew "
                        "site. No automatic Hebrew translation available. "
                        "Please provide a Hebrew equivalent."
                    ),
                    "confidence": 0.3,
                    "requires_review": True,
                })

        elif category == "rtl_english_placeholder":
            suggestions.append({
                "finding_index": i,
                "category": category,
                "fix_type": "text_replace",
                "before": sample,
                "after": f"[HE: {sample}]",
                "selector": selector,
                "explanation": (
                    f"Placeholder '{sample}' is in English on a Hebrew "
                    "form. Use a Hebrew placeholder instead."
                ),
                "confidence": 0.7,
                "requires_review": True,
            })

        elif category == "rtl_dir_missing":
            suggestions.append({
                "finding_index": i,
                "category": category,
                "fix_type": "add_attribute",
                "before": "<html lang='he' (no dir)>",
                "after": "<html lang='he' dir='rtl'>",
                "selector": "html",
                "explanation": (
                    "Add dir='rtl' to the <html> element. This is "
                    "required for proper RTL rendering of Hebrew pages, "
                    "even when lang='he' is set."
                ),
                "confidence": 0.99,
                "requires_review": False,
            })

        elif category == "rtl_plural":
            result = _fix_plural(sample)
            if result.get("fixable"):
                suggestions.append({
                    "finding_index": i,
                    "category": category,
                    "fix_type": "text_replace",
                    "before": result["before"],
                    "after": result["after"],
                    "selector": selector,
                    "explanation": result["explanation"],
                    "confidence": result["confidence"],
                    "requires_review": True,
                })

        elif category == "rtl_date_ambiguous":
            result = _disambiguate_date(sample)
            if result.get("fixable"):
                suggestions.append({
                    "finding_index": i,
                    "category": category,
                    "fix_type": "text_replace",
                    "before": result["before"],
                    "after": result["after"],
                    "selector": selector,
                    "explanation": result["explanation"],
                    "confidence": result["confidence"],
                    "requires_review": True,
                })

        elif category == "rtl_latin_mixed":
            suggestions.append({
                "finding_index": i,
                "category": category,
                "fix_type": "wrap_bdi",
                "before": sample,
                "after": f"<bdi>{sample}</bdi>",
                "selector": selector,
                "explanation": (
                    "Mixed Hebrew/Latin text without <bdi> wrapping "
                    "can cause BiDi rendering issues. Wrapping the "
                    "Latin portion isolates it from RTL context."
                ),
                "confidence": 0.8,
                "requires_review": False,
            })

    return suggestions


# ---------- utility fixers ----------

# Regex: matches a run of Latin digits (1-9) optionally with
# decimal dot, comma, or percent sign. Does NOT match within
# a <bdi> tag (already fixed).
_LATIN_DIGIT_RUN = re.compile(r"\b\d+(?:[.,]\d+)?%?\b")


def wrap_latin_digits_in_bdi(text: str) -> str:
    """Wrap Latin digit sequences in <bdi> tags.

    "יש 3 פריטים" → "יש <bdi>3</bdi> פריטים"
    "5.5% הנחה"   → "<bdi>5.5%</bdi> הנחה"
    """
    return _LATIN_DIGIT_RUN.sub(lambda m: f"<bdi>{m.group(0)}</bdi>", text)


# Matches ₪ before a number: ₪99, ₪ 99, ₪1,249
_CURRENCY_BEFORE = re.compile(r"₪\s*([\d,]+(?:\.\d+)?)")


def _fix_currency_position(text: str) -> str | None:
    """Move ₪ from before the number to after it.

    "₪99"      → "99 ₪"
    "₪ 1,249"  → "1,249 ₪"
    """
    m = _CURRENCY_BEFORE.search(text)
    if not m:
        return None
    return _CURRENCY_BEFORE.sub(r"\1 ₪", text)


# ---------- fix summary ----------


def fix_summary(suggestions: list[dict[str, Any]]) -> dict[str, Any]:
    """Summarize fix suggestions by category, confidence, and review needed."""
    by_category: dict[str, int] = {}
    auto_fixable = 0
    needs_review = 0
    total_confidence = 0.0

    for s in suggestions:
        cat = s["category"]
        by_category[cat] = by_category.get(cat, 0) + 1
        if s["requires_review"]:
            needs_review += 1
        else:
            auto_fixable += 1
        total_confidence += s.get("confidence", 0)

    count = len(suggestions)
    return {
        "total_suggestions": count,
        "auto_fixable": auto_fixable,
        "needs_review": needs_review,
        "avg_confidence": round(total_confidence / max(count, 1), 2),
        "by_category": by_category,
    }
