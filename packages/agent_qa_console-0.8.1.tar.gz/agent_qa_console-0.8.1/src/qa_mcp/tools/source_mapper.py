"""Source mapper — from QA findings to source files.

The killer feature that turns qa-mcp from a QA scanner into a
developer tool. Takes RTL audit findings (CSS selectors + text
samples from the rendered DOM) and maps them back to source files
in the developer's repository.

Challenge: production builds minify class names (CSS modules,
Tailwind hashes, styled-components). The SELECTOR is often useless
for source mapping. But the TEXT CONTENT survives minification —
if the text "₪1,249" appears in the DOM, it came from somewhere
in the source (JSX, locale file, CMS, database).

Approach (ordered by reliability):
  1. Text search — find the sample text in source files (grep).
     Works for hardcoded strings in JSX/TSX/Vue/Svelte/HTML.
  2. data-attribute search — if the selector contains data-testid,
     data-qa, data-cy, or id attributes, search source for those.
  3. i18n search — if text not found in components, search locale
     files (JSON, YAML, .po/.mo).
  4. Source map parsing — if .map files exist, resolve the
     minified selector to original source. (Future)

Each match includes:
  - repo_path: relative path to the source file
  - line: line number (1-indexed)
  - match_text: the line(s) of source code that contain the text
  - match_type: "exact_text" | "data_attribute" | "i18n_key" | "partial"
  - confidence: 0-1
  - suggested_edit: the proposed diff (if fix available)
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

# File extensions to search for text matches
_SOURCE_EXTS = {
    ".tsx", ".jsx", ".ts", ".js", ".mjs", ".cjs",
    ".vue", ".svelte", ".astro",
    ".html", ".htm", ".php", ".erb", ".haml", ".slim",
    ".heex", ".eex", ".leex",
    ".md", ".mdx",  # documentation often has hardcoded samples
}

_I18N_EXTS = {
    ".json", ".yaml", ".yml", ".toml",
    ".po", ".pot", ".mo",
    ".strings", ".xliff", ".xlf",
}

# Min size of searchable text fragment (chars).
# Shorter fragments produce too many false positives.
_MIN_FRAGMENT_LEN = 3

# Files/dirs to skip during search
_SKIP_DIRS = {
    "node_modules", ".git", ".next", "dist", "build",
    ".venv", "venv", "__pycache__", ".cache", ".pytest_cache",
    "public", "static", "out", "coverage", ".turbo",
}

# Patterns that indicate generated/minified files
_SKIP_PATTERNS = [
    "*.min.js", "*.min.css", "*.chunk.js", "*.chunk.css",
    "*.bundle.js", "*.bundle.css",
]


def _iter_source_files(repo_root: Path, extensions: set[str]) -> list[Path]:
    """Iterate source files, skipping large dependency dirs.
    
    Uses a two-pass approach: first find subdirs to skip, then
    rglob only the remaining directories. Much faster than
    rglob + filter on repos with large .venv/node_modules.
    """
    files: list[Path] = []
    # Build exclusion pattern for glob
    skip_dirs = _SKIP_DIRS
    
    for ext in extensions:
        for file_path in repo_root.rglob(f"*{ext}"):
            # Fast skip check — check if any part is in skip_dirs
            parts = file_path.relative_to(repo_root).parts
            if any(p in skip_dirs for p in parts):
                continue
            if any(file_path.match(p) for p in _SKIP_PATTERNS):
                continue
            files.append(file_path)
    
    return files


def _extract_search_terms(sample: str) -> list[str]:
    """Extract distinct, searchable terms from a text sample.

    Prioritizes the most unique-looking fragments — numbers,
    currency symbols, English words in Hebrew context — that are
    least likely to produce false positives when grepping.
    """
    terms: list[str] = []

    # 1. Full sample (if short enough to be useful)
    clean = sample.strip()
    if _MIN_FRAGMENT_LEN <= len(clean) <= 250:
        terms.append(clean)

    # 2. Extract numbers + context (e.g. "2.5", "1,249", "15%")
    number_pattern = re.findall(r"[\d,.]+\s*[%₪]?|[₪]\s*[\d,.]+", clean)
    for n in number_pattern:
        n_clean = n.strip()
        if len(n_clean) >= 2:
            terms.append(n_clean)

    # 3. Extract English words in Hebrew context
    english_words = re.findall(r"[A-Za-z]{3,}", clean)
    for w in english_words:
        if w.lower() not in {"the", "and", "for", "with", "from", "this", "that", "have", "been"}:
            terms.append(w)

    # 4. Currency symbol + number pairs
    currency_pattern = re.findall(r"₪\s*[\d,]+|[\d,]+\s*₪", clean)
    for c in currency_pattern:
        terms.append(c.strip())

    # Deduplicate, prioritize longer terms
    seen: set[str] = set()
    unique = []
    for t in sorted(terms, key=len, reverse=True):
        if t not in seen:
            seen.add(t)
            unique.append(t)

    return unique[:10]  # cap at 10 search terms


def _search_file(file_path: Path, terms: list[str]) -> list[dict[str, Any]]:
    """Search a single file for matching terms. Returns match objects."""
    matches: list[dict[str, Any]] = []
    try:
        content = file_path.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return matches

    lines = content.splitlines()
    for term in terms:
        term_lower = term.lower()
        for i, line in enumerate(lines, start=1):
            if term_lower in line.lower():
                matches.append({
                    "file": str(file_path),
                    "line": i,
                    "match_text": line.strip()[:200],
                    "term": term,
                    "match_type": "exact_text" if term in line else "case_insensitive",
                    "confidence": 0.9 if term in line else 0.7,
                })

    return matches


def _search_data_attributes(
    repo_root: Path, selector: str, xpath: str | None
) -> list[dict[str, Any]]:
    """Search source files for data-testid, id, or data-qa attributes
    that appear in the finding's CSS selector."""
    matches: list[dict[str, Any]] = []

    # Extract potential identifiers from the selector
    identifiers: list[str] = []

    # data-testid="..."
    for m in re.finditer(r'data-testid="([^"]+)"', selector):
        identifiers.append(m.group(1))
    # data-qa="..."
    for m in re.finditer(r'data-qa="([^"]+)"', selector):
        identifiers.append(m.group(1))
    # data-cy="..."
    for m in re.finditer(r'data-cy="([^"]+)"', selector):
        identifiers.append(m.group(1))
    # id="..."
    for m in re.finditer(r'#([\w-]+)', selector):
        identifiers.append(m.group(1))
    # [id="..."]
    for m in re.finditer(r'\[id="([^"]+)"\]', selector):
        identifiers.append(m.group(1))

    if not identifiers:
        return matches

    for ident in identifiers[:5]:
        if len(ident) < 3:
            continue
        for candidate in _iter_source_files(repo_root, _SOURCE_EXTS):
            try:
                content = candidate.read_text(encoding="utf-8", errors="replace")
            except Exception:
                continue
            if ident in content:
                # Find the line
                for i, line in enumerate(content.splitlines(), start=1):
                    if ident in line:
                        matches.append({
                            "file": str(candidate),
                            "line": i,
                            "match_text": line.strip()[:200],
                            "term": ident,
                            "match_type": "data_attribute",
                            "confidence": 0.8,
                        })
                        break  # one match per file per identifier
        if matches:
            break  # found it, don't search other extensions

    return matches[:3]


def _search_i18n(repo_root: Path, text: str) -> list[dict[str, Any]]:
    """Search locale/i18n files for the text. Many React/Next.js
    projects use JSON or YAML for translations."""
    matches: list[dict[str, Any]] = []

    locale_dirs = [
        "locales", "locale", "i18n", "translations",
        "lang", "languages", "messages", "intl",
        "public/locales", "src/locales", "src/i18n",
        "src/translations", "src/lang",
        "app/i18n", "app/locales",
    ]

    search_roots = [repo_root]
    for ld in locale_dirs:
        candidate = repo_root / ld
        if candidate.is_dir():
            search_roots.append(candidate)

    clean_text = text.strip()
    if len(clean_text) < _MIN_FRAGMENT_LEN:
        return matches

    for root in search_roots:
        for ext in _I18N_EXTS:
            for candidate in root.rglob(f"*{ext}"):
                # i18n dirs are small, simple filter is fine
                parts = candidate.relative_to(root).parts
                if any(p in _SKIP_DIRS for p in parts):
                    continue
                try:
                    content = candidate.read_text(encoding="utf-8", errors="replace")
                except Exception:
                    continue
                if clean_text in content:
                    for i, line in enumerate(content.splitlines(), start=1):
                        if clean_text in line:
                            matches.append({
                                "file": str(candidate),
                                "line": i,
                                "match_text": line.strip()[:200],
                                "term": clean_text,
                                "match_type": "i18n_key",
                                "confidence": 0.85,
                            })
                            break

    return matches[:5]


def _generate_diff(file_path: str, line: int, before: str, after: str,
                   fix_type: str = "text_replace") -> str | None:
    """Generate a minimal git-style diff for a fix.

    For 'wrap_bdi' fixes, the before/after represent the full sample
    text. We need to find the digit run in the source line and wrap it.
    For 'text_replace' and 'swap_position', the before→after is exact.
    """
    try:
        content = Path(file_path).read_text(encoding="utf-8", errors="replace")
    except Exception:
        return None

    lines = content.splitlines()
    if line < 1 or line > len(lines):
        return None

    original_line = lines[line - 1]

    if fix_type == "wrap_bdi":
        # The before text contains Latin digits; find them in the source
        # line and wrap with <bdi>
        import re as _re
        digit_match = _re.search(r"\b(\d+(?:[.,]\d+)?%?)\b", before)
        if not digit_match:
            return None
        digit = digit_match.group(1)
        if digit not in original_line:
            return None
        fixed_line = original_line.replace(digit, f"<bdi>{digit}</bdi>", 1)
        if fixed_line == original_line:
            return None
    elif fix_type == "swap_position":
        # "₪99" → "99 ₪"
        if before not in original_line:
            return None
        fixed_line = original_line.replace(before, after, 1)
    else:
        # text_replace, add_attribute
        if before not in original_line:
            # Try partial match: maybe only a fragment of 'before' is in the source
            if len(before) > 3 and before[:10] in original_line:
                fixed_line = original_line.replace(before[:10], after[:10], 1)
            else:
                return None
        else:
            fixed_line = original_line.replace(before, after, 1)

    if fixed_line == original_line:
        return None

    rel_path = str(Path(file_path))
    return (
        f"--- a/{rel_path}\n"
        f"+++ b/{rel_path}\n"
        f"@@ -{line},1 +{line},1 @@\n"
        f"-{original_line}\n"
        f"+{fixed_line}\n"
    )


# ---------- public API ----------


def map_findings_to_source(
    findings: list[dict[str, Any]],
    repo_path: str,
    include_i18n: bool = True,
    max_matches_per_finding: int = 3,
) -> dict[str, Any]:
    """Map RTL findings to source code locations.

    For each finding, searches the repository for the offending text.
    When found, returns file:line matches. When not found, marks as
    "unmapped" (likely from database/CMS/external source).

    Args:
        findings: RTL audit findings from qa_rtl_audit.
        repo_path: Absolute or relative path to the git repo root.
        include_i18n: Also search locale/i18n files.
        max_matches_per_finding: Cap matches per finding.

    Returns:
        {
            total_findings: N,
            mapped: count with at least one source match,
            unmapped: count with zero source matches,
            results: [{ finding, source_matches: [...], diff: "..." }]
        }
    """
    repo_root = Path(repo_path).resolve()
    if not repo_root.is_dir():
        return {
            "error": f"repo_path not found: {repo_path}",
            "total_findings": len(findings),
            "mapped": 0,
            "unmapped": len(findings),
            "results": [],
        }

    results: list[dict[str, Any]] = []
    mapped = 0
    unmapped = 0

    # Collect source files ONCE (expensive walk, especially with .venv)
    source_files = _iter_source_files(repo_root, _SOURCE_EXTS)

    for finding in findings:
        sample = finding.get("sample", "")
        selector = finding.get("selector", "")
        xpath = finding.get("xpath")
        category = finding.get("category", "")
        severity = finding.get("severity", "")

        source_matches: list[dict[str, Any]] = []

        # Strategy 1: Text search (most reliable)
        if len(sample.strip()) >= _MIN_FRAGMENT_LEN:
            terms = _extract_search_terms(sample)
            candidates: list[tuple[dict[str, Any], int]] = []
            for file_path in source_files:
                file_matches = _search_file(file_path, terms)
                for m in file_matches:
                    # Score: longer match term + exact match = higher
                    score = len(m["term"]) + (10 if m["match_type"] == "exact_text" else 0)
                    candidates.append((m, score))

            # Keep top matches
            candidates.sort(key=lambda x: -x[1])
            seen_files: set[str] = set()
            for m, _score in candidates:
                if m["file"] not in seen_files:
                    seen_files.add(m["file"])
                    source_matches.append(m)
                if len(source_matches) >= max_matches_per_finding:
                    break

        # Strategy 2: Data attribute search (if selector has identifiable attrs)
        if len(source_matches) < max_matches_per_finding and selector:
            attr_matches = _search_data_attributes(repo_root, selector, xpath)
            for am in attr_matches:
                if not any(m["file"] == am["file"] for m in source_matches):
                    source_matches.append(am)
                if len(source_matches) >= max_matches_per_finding:
                    break

        # Strategy 3: i18n search
        if len(source_matches) < max_matches_per_finding and include_i18n and sample.strip():
            i18n_matches = _search_i18n(repo_root, sample)
            for im in i18n_matches:
                if not any(m["file"] == im["file"] for m in source_matches):
                    source_matches.append(im)
                if len(source_matches) >= max_matches_per_finding:
                    break

        result: dict[str, Any] = {
            "finding": {
                "category": category,
                "severity": severity,
                "sample": sample,
                "selector": selector,
            },
            "source_matches": source_matches,
        }
        # Propagate fix suggestion if present
        sf = finding.get("suggested_fix")
        if sf:
            result["finding"]["suggested_fix"] = sf

        if source_matches:
            mapped += 1
            # If there's a fix suggestion, generate a diff
            fix = finding.get("suggested_fix") or finding.get("fix")
            if not fix:
                fix = finding.get("after")
            if fix and source_matches:
                best = source_matches[0]
                # Resolve fix: might be a string (after text) or dict with after+fix_type
                after_text = fix if isinstance(fix, str) else fix.get("after", "")
                fix_type = "text_replace" if isinstance(fix, str) else fix.get("fix_type", "text_replace")
                diff = _generate_diff(
                    best["file"], best["line"], sample, after_text,
                    fix_type=fix_type,
                )
                if diff:
                    result["diff"] = diff
        else:
            unmapped += 1

        results.append(result)

    return {
        "total_findings": len(findings),
        "mapped": mapped,
        "unmapped": unmapped,
        "map_rate": round(mapped / max(len(findings), 1), 2),
        "repo_path": str(repo_root),
        "results": results,
    }


def map_with_fixes(
    findings: list[dict[str, Any]],
    fix_suggestions: list[dict[str, Any]],
    repo_path: str,
    include_i18n: bool = True,
) -> dict[str, Any]:
    """Map findings to source AND attach fix suggestions as diffs.

    This is the combined workflow: RTL audit → fix suggestions →
    source mapping → ready-to-apply patches.

    Returns the same structure as map_findings_to_source, but
    each result includes a `diff` field for auto-fixable findings.
    """
    # First enrich findings with fix suggestions
    enriched: list[dict[str, Any]] = []
    fix_map: dict[int, dict[str, Any]] = {}
    for fs in fix_suggestions:
        idx = fs.get("finding_index")
        if idx is not None:
            fix_map[idx] = fs

    for i, finding in enumerate(findings):
        f = dict(finding)
        fix = fix_map.get(i)
        if fix:
            f["suggested_fix"] = {
                "before": fix.get("before", ""),
                "after": fix.get("after", ""),
                "fix_type": fix.get("fix_type", ""),
                "confidence": fix.get("confidence", 0),
                "requires_review": fix.get("requires_review", True),
                "explanation": fix.get("explanation", ""),
            }
        enriched.append(f)

    return map_findings_to_source(enriched, repo_path, include_i18n=include_i18n)


def best_patches(results: dict[str, Any], auto_only: bool = True) -> list[dict[str, Any]]:
    """Extract the best auto-fixable patches from source mapping results.

    Returns a list of { file, line, before, after, diff, confidence }
    ready to be turned into a git commit or PR.
    """
    patches: list[dict[str, Any]] = []
    for r in results.get("results", []):
        fix = r.get("finding", {}).get("suggested_fix", {})
        if not fix:
            continue
        if auto_only and fix.get("requires_review", True):
            continue
        if not r.get("source_matches"):
            continue
        best = r["source_matches"][0]
        if r.get("diff"):
            patches.append({
                "file": best["file"],
                "line": best["line"],
                "before": fix.get("before", ""),
                "after": fix.get("after", ""),
                "diff": r["diff"],
                "confidence": fix.get("confidence", 0),
                "fix_type": fix.get("fix_type", ""),
                "category": r["finding"].get("category", ""),
            })
    return patches
