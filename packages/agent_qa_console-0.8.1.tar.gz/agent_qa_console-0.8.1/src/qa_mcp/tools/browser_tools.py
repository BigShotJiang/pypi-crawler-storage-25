"""Browser primitives — building blocks the calling agent orchestrates."""
from __future__ import annotations

import base64
import os
from datetime import datetime
from pathlib import Path
from typing import Any

from ..browser import SessionManager


# JS that returns indexed interactive elements. Accepts startIdx so callers can
# walk multiple frames and assign globally-unique indices. Includes contenteditable
# (for rich-text editors like TinyMCE/CKEditor/Lexical) and select (for dropdowns).
#
# `opts` (optional) can scope the snapshot — critical on dense pages
# (large sidebars, footers) where the full snapshot exceeds 100KB JSON
# and forces the caller to fall back to raw DOM scraping:
#   - scope: CSS selector — only collect elements inside this root
#   - exclude: CSS selector — drop elements matching this (e.g. "nav, footer")
#   - maxElements: cap on returned elements (returns truncated=true if hit)
INDEX_INTERACTIVE_JS = r"""
(args) => {
  // Playwright passes a single arg to evaluate; we destructure here so callers
  // can stick to the ergonomic two-positional shape: evaluate(JS, [idx, opts]).
  // Backwards-compat: a bare integer (old shape) still works.
  let startIdx, opts;
  if (Array.isArray(args)) {
    startIdx = args[0] || 0;
    opts = args[1] || {};
  } else {
    startIdx = args || 0;
    opts = {};
  }
  const SEL = 'a, button, input, textarea, select, [role="button"], [role="link"], [role="textbox"], [role="checkbox"], [contenteditable="true"], [contenteditable=""]';
  const visible = (el) => {
    const r = el.getBoundingClientRect();
    if (r.width <= 0 || r.height <= 0) return false;
    const cs = getComputedStyle(el);
    if (cs.visibility === 'hidden' || cs.display === 'none' || parseFloat(cs.opacity) === 0) return false;
    return true;
  };
  // Resolve the root and excluded set. Bad selectors degrade gracefully —
  // we don't want one typo to break the whole snapshot.
  let root = document;
  if (opts.scope) {
    try {
      const r = document.querySelector(opts.scope);
      if (r) root = r;
    } catch (e) { /* invalid selector — keep document */ }
  }
  let excludedSet = null;
  if (opts.exclude) {
    try {
      excludedSet = new Set();
      for (const ex of root.querySelectorAll(opts.exclude)) {
        excludedSet.add(ex);
        for (const d of ex.querySelectorAll('*')) excludedSet.add(d);
      }
    } catch (e) { excludedSet = null; }
  }
  const cap = (typeof opts.maxElements === 'number' && opts.maxElements > 0)
    ? opts.maxElements : Infinity;
  const result = [];
  const seen = new WeakSet();
  let truncated = false;
  let totalCandidates = 0;
  for (const el of root.querySelectorAll(SEL)) {
    totalCandidates += 1;
    if (seen.has(el) || !visible(el)) continue;
    if (excludedSet && excludedSet.has(el)) continue;
    seen.add(el);
    if (result.length >= cap) { truncated = true; break; }
    const idx = startIdx + result.length;
    const tag = el.tagName.toLowerCase();
    const role = el.getAttribute('role') || tag;
    const text = (el.innerText || el.value || el.placeholder || el.getAttribute('aria-label') || '').trim().slice(0, 120);
    const r = el.getBoundingClientRect();
    el.setAttribute('data-qa-mcp-idx', String(idx));
    let options = null;
    if (tag === 'select') {
      options = Array.from(el.options).map(o => ({ value: o.value, label: o.text, selected: o.selected }));
    }
    const editable = (el.getAttribute('contenteditable') === 'true' || el.getAttribute('contenteditable') === '');
    result.push({
      index: idx, tag, role, text,
      type: el.type || null,
      name: el.name || null,
      id: el.id || null,
      placeholder: el.placeholder || null,
      href: tag === 'a' ? (el.getAttribute('href') || null) : null,
      contenteditable: editable,
      designmode: false,
      options,
      x: Math.round(r.x), y: Math.round(r.y),
      w: Math.round(r.width), h: Math.round(r.height),
    });
  }
  // TinyMCE / CKEditor classic mode: <iframe> with document.designMode='on'
  // and editing happens on <body>. The body has no contenteditable attribute,
  // so the standard selector misses it. Add the body as a synthetic editable.
  // Only when scanning the full document — a scoped snapshot wouldn't reach body.
  if (!opts.scope && document.designMode === 'on' && document.body && !seen.has(document.body) && result.length < cap) {
    const idx = startIdx + result.length;
    const r = document.body.getBoundingClientRect();
    document.body.setAttribute('data-qa-mcp-idx', String(idx));
    result.push({
      index: idx, tag: 'body', role: 'textbox',
      text: (document.body.innerText || '').trim().slice(0, 120),
      type: null, name: null, id: document.body.id || null,
      placeholder: null, href: null,
      contenteditable: true, designmode: true,
      options: null,
      x: Math.round(r.x), y: Math.round(r.y),
      w: Math.round(r.width), h: Math.round(r.height),
    });
  }
  return { elements: result, truncated, totalCandidates };
}
"""


async def _resolve_target(s, index: int):
    """Return (frame, selector) for a given element index. If the index was
    mapped to an iframe in the last get_state, route to that frame; else
    main frame.
    """
    selector = f'[data-qa-mcp-idx="{index}"]'
    frame_url = s.frame_map.get(index) if hasattr(s, "frame_map") else None
    if frame_url:
        # Match by URL; fall back to first frame with matching URL prefix.
        for f in s.page.frames:
            if f.url == frame_url:
                return f, selector
    return s.page.main_frame, selector


async def browser_open(mgr: SessionManager, url: str | None = None,
                       headless: bool = True,
                       geolocation: dict | None = None,
                       timezone: str | None = None,
                       locale: str | None = None,
                       user_agent: str | None = None,
                       browser: str = "chrome",
                       network: str | dict | None = None,
                       stealth: bool = True) -> dict[str, Any]:
    """Open a session.

    Engine: `browser` = 'chrome' (default), 'chromium'/'msedge' branded channels,
    'cloak' (CloakBrowser stealth Chromium; requires pip install cloakbrowser),
    'webkit' (Safari engine), or 'firefox'. Critical bugs surface only on WebKit
    (BiDi, flex, date inputs, IndexedDB).

    Emulation (context-level — set at open, not changeable later):
      - geolocation: {"latitude": 32.08, "longitude": 34.78}
      - timezone: IANA name like "Asia/Jerusalem"
      - locale: BCP-47 like "he-IL"
      - user_agent: full UA string

    Network throttling (Chromium-family only — CDP-based):
      - 'slow_3g' | 'fast_3g' | '4g' | 'wifi' | 'offline'
      - or dict with downloadThroughput, uploadThroughput, latency

    stealth (default True): apply anti-detection patches to bypass
      CDN bot protection (Cloudflare, Akamai, DataDome). Set False
      for internal/CI sites.
    """
    s, redirect_chain = await mgr.open(
        url=url, headless=headless,
        geolocation=geolocation, timezone=timezone,
        locale=locale, user_agent=user_agent,
        browser_engine=browser, network=network,
        stealth=stealth,
    )
    result: dict[str, Any] = {
        "session_id": s.id,
        "url": s.page.url,
        "title": await s.page.title() if url else "",
        "browser": s.browser_engine,
        "redirect_chain": redirect_chain,
        "redirect_count": len(redirect_chain),
        "emulation": {
            "geolocation": geolocation, "timezone": timezone,
            "locale": locale, "user_agent": user_agent,
            "network": network,
        },
    }
    if s.stealth:
        result["stealth"] = s.stealth
    return result


async def browser_throttle_network(mgr: SessionManager, session_id: str,
                                   preset: str | None = None,
                                   custom: dict | None = None) -> dict[str, Any]:
    """Change network conditions on an existing session. Chromium only.
    Pass `preset` ('slow_3g'/'fast_3g'/'4g'/'wifi'/'offline') or `custom`
    dict with downloadThroughput, uploadThroughput, latency.
    """
    from ..browser import _apply_network_throttle
    s = mgr.get(session_id)
    if s.browser_engine != "chromium":
        return {"ok": False, "error": f"network throttling requires chromium, "
                                       f"current: {s.browser_engine}"}
    if not preset and not custom:
        return {"ok": False, "error": "specify preset or custom"}
    try:
        await _apply_network_throttle(s.page, preset or custom)
        return {"ok": True, "applied": preset or custom}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


async def browser_navigate(mgr: SessionManager, session_id: str, url: str,
                           wait_until: str = "domcontentloaded") -> dict[str, Any]:
    """Navigate and capture the FULL redirect chain — both HTTP redirects
    (301/302/etc) AND client-side ones (meta-refresh, window.location, JS).

    Critical for Israeli sites: brainboxai.io → voicebox.brainboxai.io is
    typically a JS/meta redirect, which Playwright's request.redirected_from
    chain doesn't expose. We hook framenavigated to catch those too.
    """
    s = mgr.get(session_id)

    # Reset state that's specific to the previous page — Round 6 caught a
    # ghost dialog from /javascript_alerts surviving into /broken_images.
    # Frame map is rebuilt by the next get_state, but last_dialog has no
    # other reset trigger.
    s.last_dialog = None
    s.frame_map = {}

    # Track client-side navigations on the main frame during this goto.
    client_hops: list[dict[str, Any]] = []
    last_url: list[str | None] = [None]

    def on_framenavigated(frame):
        if frame is not s.page.main_frame:
            return
        u = frame.url
        if last_url[0] is not None and u != last_url[0] and u != "about:blank":
            client_hops.append({"from": last_url[0], "to": u, "kind": "client_side"})
        last_url[0] = u

    s.page.on("framenavigated", on_framenavigated)
    try:
        response = await s.page.goto(url, wait_until=wait_until)
    finally:
        s.page.remove_listener("framenavigated", on_framenavigated)

    # HTTP-level chain (301/302/303/307/308) walked from the final response.
    redirect_chain: list[dict[str, Any]] = []
    if response is not None:
        req = response.request
        prev = req.redirected_from
        while prev is not None:
            try:
                prev_resp = await prev.response()
                status = prev_resp.status if prev_resp else None
            except Exception:
                status = None
            redirect_chain.insert(0, {
                "from": prev.url,
                "to": req.url,
                "status": status,
                "kind": "http",
            })
            req = prev
            prev = req.redirected_from

    # Merge client-side hops AFTER the HTTP chain (they happen post-load).
    # Filter out the initial framenavigated that just fires for the goto target.
    for hop in client_hops:
        # Skip noise: same-origin "from=initial-blank" or self-loops
        if hop["from"] == hop["to"]:
            continue
        # Skip the trivial "about:blank → first url" before goto resolved
        if hop["from"] in ("about:blank", "", None):
            continue
        redirect_chain.append(hop)

    return {
        "url": s.page.url,
        "title": await s.page.title(),
        "status": response.status if response is not None else None,
        "redirect_chain": redirect_chain,
        "redirect_count": len(redirect_chain),
    }


async def browser_screenshot(mgr: SessionManager, session_id: str,
                             full_page: bool = False,
                             save_to: str | None = None,
                             include_base64: bool = False) -> dict[str, Any]:
    """JPEG screenshot. Default saves to disk and returns the path — does NOT
    embed base64 (full-page screenshots are 80-110K tokens and blow up
    context). Pass `include_base64=True` only when the caller really needs
    the bytes inline.

    If `save_to` is provided, writes there; else writes to
    ~/.qa-mcp/screenshots/shot_<timestamp>.jpg.
    """
    s = mgr.get(session_id)
    raw = await s.page.screenshot(type="jpeg", quality=70, full_page=full_page)
    if save_to:
        path = Path(save_to).expanduser()
    else:
        tmp_dir = Path(os.getenv("QA_DATA_DIR") or (Path.home() / ".qa-mcp")) / "screenshots"
        tmp_dir.mkdir(parents=True, exist_ok=True)
        ts = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        path = tmp_dir / f"shot_{ts}.jpg"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(raw)
    out: dict[str, Any] = {
        "path": str(path),
        "format": "jpeg",
        "size_bytes": len(raw),
        "url": s.page.url,
        "full_page": full_page,
    }
    if include_base64:
        out["base64"] = base64.b64encode(raw).decode("ascii")
    return out


_TEXT_SNAPSHOT_JS = r"""
(maxChars) => {
  // Visible body innerText, with whitespace collapsed and capped.
  // Without this, agents can't see error messages or status text that fired
  // after a click — they only see the indexed interactive elements.
  // Round 5 review: agent saw a new X-button appear after locked-out login
  // but had no idea WHY because "Epic sadface: ... locked out" was
  // non-interactive and invisible to get_state.
  const max = maxChars || 1500;
  const t = (document.body && document.body.innerText) || '';
  // Collapse runs of blank lines / whitespace
  const collapsed = t.replace(/\n{3,}/g, '\n\n').replace(/[ \t]+/g, ' ').trim();
  if (collapsed.length <= max) return collapsed;
  return collapsed.slice(0, max) + `\n…[${collapsed.length - max} chars truncated]`;
}
"""


async def browser_get_state(mgr: SessionManager, session_id: str,
                            text_snapshot_chars: int = 1500,
                            scope: str | None = None,
                            exclude: str | None = None,
                            max_elements: int | None = None) -> dict[str, Any]:
    """Snapshot interactive elements across the main frame AND every iframe.
    Each element gets a globally-unique index. Subsequent click/type/hover
    by index automatically routes to the correct frame.

    Also returns `text_snapshot` — the visible body text (capped at
    text_snapshot_chars). Without this, agents miss error messages and
    status text that aren't interactive (e.g. "Sorry, this user has been
    locked out" after a failed login). Set to 0 to skip the snapshot.

    Scoping (use on dense pages — large sidebars/footers can push the
    snapshot past the agent's context limit, forcing fallback to raw DOM):
      - scope: CSS selector — only collect elements inside this root
        (e.g. "form", "main", "[data-testid=signup]")
      - exclude: CSS selector — skip elements matching this
        (e.g. "nav, footer, [aria-hidden=true]")
      - max_elements: cap on returned elements — avoids 100KB blowups when
        a page has hundreds of interactive elements
    """
    s = mgr.get(session_id)
    s.frame_map = {}
    all_elements: list[dict] = []
    next_idx = 0
    truncated_any = False
    opts = {}
    if scope is not None:
        opts["scope"] = scope
    if exclude is not None:
        opts["exclude"] = exclude
    if max_elements is not None:
        opts["maxElements"] = max_elements
    for frame in s.page.frames:
        try:
            payload = await frame.evaluate(INDEX_INTERACTIVE_JS, [next_idx, opts])
        except Exception:
            # Cross-origin or detached — Playwright still bridges most cases,
            # but skip if it errors.
            continue
        # JS returns {elements, truncated, totalCandidates}.
        elements = payload.get("elements", []) if isinstance(payload, dict) else payload
        if isinstance(payload, dict) and payload.get("truncated"):
            truncated_any = True
        is_main = (frame is s.page.main_frame)
        for el in elements:
            el["frame_url"] = None if is_main else frame.url
            if not is_main:
                s.frame_map[el["index"]] = frame.url
            all_elements.append(el)
        next_idx += len(elements)
        # Honour the cap across frames too — once we've hit max in main,
        # don't keep walking sub-frames.
        if max_elements is not None and len(all_elements) >= max_elements:
            truncated_any = True
            break
    text_snapshot = None
    if text_snapshot_chars > 0:
        try:
            text_snapshot = await s.page.evaluate(_TEXT_SNAPSHOT_JS, text_snapshot_chars)
        except Exception:
            text_snapshot = None
    s.last_elements_by_index = {int(el["index"]): dict(el) for el in all_elements if "index" in el}
    out: dict[str, Any] = {
        "url": s.page.url,
        "title": await s.page.title(),
        "viewport": s.page.viewport_size,
        "elements": all_elements,
        "element_count": len(all_elements),
        "frame_count": len(s.page.frames),
        "last_dialog": s.last_dialog,
        "text_snapshot": text_snapshot,
    }
    if truncated_any:
        out["truncated"] = True
        out["hint"] = ("element list capped — narrow with `scope`/`exclude` "
                       "or raise `max_elements` if you need everything")
    if scope or exclude or max_elements is not None:
        out["scope_applied"] = {k: v for k, v in
                                {"scope": scope, "exclude": exclude,
                                 "max_elements": max_elements}.items()
                                if v is not None}
    return out


async def browser_click(mgr: SessionManager, session_id: str, index: int) -> dict[str, Any]:
    s = mgr.get(session_id)
    frame, selector = await _resolve_target(s, index)
    try:
        await frame.click(selector, timeout=5000)
        return {"ok": True, "url": s.page.url, "last_dialog": s.last_dialog}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


async def browser_type(mgr: SessionManager, session_id: str, index: int,
                       text: str, clear: bool = True) -> dict[str, Any]:
    s = mgr.get(session_id)
    frame, selector = await _resolve_target(s, index)
    try:
        # Standard inputs/textareas/contenteditable: fill() handles all three.
        if clear:
            await frame.fill(selector, "", timeout=5000)
        await frame.fill(selector, text, timeout=5000)
        return {"ok": True}
    except Exception:
        # Fallback for designMode editors (TinyMCE/CKEditor classic) where
        # fill() can't target <body>. Click to focus, then type.
        try:
            await frame.click(selector, timeout=5000)
            if clear:
                # Select all + delete
                await s.page.keyboard.press("Control+A")
                await s.page.keyboard.press("Delete")
            await s.page.keyboard.type(text)
            return {"ok": True, "method": "designmode_keyboard"}
        except Exception as e2:
            return {"ok": False, "error": f"{type(e2).__name__}: {e2}"}


async def browser_press_key(mgr: SessionManager, session_id: str,
                            key: str) -> dict[str, Any]:
    """Press a keyboard key or combo. Examples: 'Enter', 'Tab', 'Escape',
    'Control+Shift+P', 'Meta+K'."""
    s = mgr.get(session_id)
    await s.page.keyboard.press(key)
    return {"ok": True, "url": s.page.url}


# ---------- new interaction primitives ----------


async def browser_select_option(mgr: SessionManager, session_id: str,
                                index: int,
                                value: str | list[str] | None = None,
                                label: str | list[str] | None = None,
                                position: int | list[int] | None = None,
                                ) -> dict[str, Any]:
    """Select option(s) on a <select> element. Specify exactly one of:
      - value: option's `value` attribute (or list for multi-select)
      - label: visible text (or list)
      - position: 0-based index (or list)

    Pass a list to <select multiple>. Returns the actually-selected values."""
    s = mgr.get(session_id)
    frame, selector = await _resolve_target(s, index)
    if value is None and label is None and position is None:
        return {"ok": False, "error": "specify value, label, or position"}
    try:
        if value is not None:
            result = await frame.select_option(selector, value=value, timeout=5000)
        elif label is not None:
            result = await frame.select_option(selector, label=label, timeout=5000)
        else:
            result = await frame.select_option(selector, index=position, timeout=5000)
        return {"ok": True, "selected": result}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


async def browser_hover(mgr: SessionManager, session_id: str, index: int) -> dict[str, Any]:
    """Move mouse to element center. Triggers mouseenter/mouseover —
    needed for mega-menus, tooltips, hover previews. Re-call get_state
    afterwards if hover changed the DOM."""
    s = mgr.get(session_id)
    frame, selector = await _resolve_target(s, index)
    try:
        await frame.hover(selector, timeout=5000)
        return {"ok": True}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


async def browser_handle_dialog(mgr: SessionManager, session_id: str,
                                action: str = "accept",
                                prompt_text: str | None = None,
                                ) -> dict[str, Any]:
    """Configure how the NEXT JS dialog (alert/confirm/prompt) is handled.
    Default behavior of every session is to dismiss + capture; call this
    before triggering a dialog you want to accept (or fill a prompt for).

    action: "accept" | "dismiss"
    prompt_text: only used for prompt() — sent as the prompt's response.

    After the dialog fires, the action resets to "dismiss" (one-shot).
    Inspect the dialog via get_state().last_dialog."""
    s = mgr.get(session_id)
    if action not in ("accept", "dismiss"):
        return {"ok": False, "error": "action must be 'accept' or 'dismiss'"}
    s.pending_dialog_action = action
    s.pending_prompt_text = prompt_text
    return {"ok": True, "next_dialog_will": action,
            "prompt_text": prompt_text}


async def browser_drag(mgr: SessionManager, session_id: str,
                       source_index: int, target_index: int) -> dict[str, Any]:
    """Drag-and-drop from source element to target element."""
    s = mgr.get(session_id)
    src_frame, src_sel = await _resolve_target(s, source_index)
    tgt_frame, tgt_sel = await _resolve_target(s, target_index)
    if src_frame is not tgt_frame:
        return {"ok": False, "error": "drag across frames not supported"}
    try:
        await src_frame.drag_and_drop(src_sel, tgt_sel, timeout=10000)
        return {"ok": True}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


async def browser_scroll_to(mgr: SessionManager, session_id: str,
                            index: int) -> dict[str, Any]:
    """Scroll the element into view. Useful before screenshots or before
    interacting with elements in long pages."""
    s = mgr.get(session_id)
    frame, selector = await _resolve_target(s, index)
    try:
        await frame.locator(selector).scroll_into_view_if_needed(timeout=5000)
        return {"ok": True, "url": s.page.url, "scrollY": await s.page.evaluate("() => window.scrollY")}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


async def browser_scroll(mgr: SessionManager, session_id: str,
                         dx: float = 0, dy: float = 700) -> dict[str, Any]:
    """Scroll the page by mouse wheel deltas.

    This is the agent-facing primitive for making movement visible in the
    Agent QA Console live browser. Positive dy scrolls down; negative dy scrolls
    up. No raw HTTP/browser-input calls are needed.
    """
    s = mgr.get(session_id)
    try:
        await s.page.mouse.wheel(dx, dy)
        scroll_y = await s.page.evaluate("() => window.scrollY")
        return {"ok": True, "url": s.page.url, "dx": dx, "dy": dy, "scrollY": scroll_y}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


async def browser_evaluate(mgr: SessionManager, session_id: str,
                           expression: str,
                           frame_chain: list[str] | None = None,
                           ) -> dict[str, Any]:
    """Escape hatch — run arbitrary JS in the page and return its result.
    The expression must be a valid JS expression or function. Examples:
      - "document.title"
      - "() => Array.from(document.querySelectorAll('script')).length"
      - "() => ({ width: window.innerWidth, ua: navigator.userAgent })"

    Use sparingly — prefer the typed primitives. This is for cases the
    other tools don't cover.

    `frame_chain` (optional): list of CSS selectors to descend into nested
    iframes. Each selector picks an <iframe> in the previous level's
    document. Example for parent>child nesting:
      frame_chain=["#frame1", "iframe"]
    Saves writing `parent.contentDocument.querySelector('iframe').contentDocument...`
    by hand, and bypasses cross-origin same-process limits when Playwright
    can bridge."""
    s = mgr.get(session_id)
    try:
        if not frame_chain:
            result = await s.page.evaluate(expression)
            return {"ok": True, "result": result}
        # Walk the chain: start at main frame, find each iframe by selector.
        frame = s.page.main_frame
        for i, sel in enumerate(frame_chain):
            handle = await frame.query_selector(sel)
            if handle is None:
                return {"ok": False, "error": f"frame_chain step {i} ({sel!r}): no element matched"}
            content_frame = await handle.content_frame()
            if content_frame is None:
                return {"ok": False, "error": f"frame_chain step {i} ({sel!r}): element is not an iframe"}
            frame = content_frame
        result = await frame.evaluate(expression)
        return {"ok": True, "result": result, "frame_url": frame.url}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


async def browser_set_geolocation(mgr: SessionManager, session_id: str,
                                  latitude: float, longitude: float,
                                  accuracy: float | None = None) -> dict[str, Any]:
    """Update the session's geolocation. Pages calling
    navigator.geolocation.getCurrentPosition will see this position.
    Permission is automatically granted when set at browser_open time."""
    s = mgr.get(session_id)
    geo = {"latitude": latitude, "longitude": longitude}
    if accuracy is not None:
        geo["accuracy"] = accuracy
    try:
        await s.context.set_geolocation(geo)
        # Ensure permission is granted (it is if browser_open had geolocation,
        # else explicitly grant now).
        try:
            await s.context.grant_permissions(["geolocation"])
        except Exception:
            pass
        return {"ok": True, "geolocation": geo}
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}


async def browser_logs(mgr: SessionManager, session_id: str,
                       clear: bool = False) -> dict[str, Any]:
    s = mgr.get(session_id)
    out = [e.to_dict() for e in s.logs]
    if clear:
        s.logs.clear()
    return {"count": len(out), "events": out}


async def browser_close(mgr: SessionManager, session_id: str) -> dict[str, Any]:
    await mgr.close(session_id)
    return {"closed": session_id}


# ---------- viewport / device emulation ----------

DEVICE_PRESETS: dict[str, dict] = {
    "iphone-13":     {"width": 390,  "height": 844,  "deviceScaleFactor": 3, "isMobile": True,  "ua_hint": "iPhone"},
    "iphone-se":     {"width": 375,  "height": 667,  "deviceScaleFactor": 2, "isMobile": True,  "ua_hint": "iPhone"},
    "pixel-7":       {"width": 412,  "height": 915,  "deviceScaleFactor": 2.625, "isMobile": True, "ua_hint": "Android"},
    "ipad":          {"width": 820,  "height": 1180, "deviceScaleFactor": 2, "isMobile": True,  "ua_hint": "iPad"},
    "desktop-1080":  {"width": 1920, "height": 1080, "deviceScaleFactor": 1, "isMobile": False, "ua_hint": None},
    "desktop-1440":  {"width": 1440, "height": 900,  "deviceScaleFactor": 1, "isMobile": False, "ua_hint": None},
    "desktop-1366":  {"width": 1366, "height": 768,  "deviceScaleFactor": 1, "isMobile": False, "ua_hint": None},
}


async def browser_set_viewport(mgr: SessionManager, session_id: str,
                               device: str | None = None,
                               width: int | None = None,
                               height: int | None = None) -> dict[str, Any]:
    """Switch viewport. Either pass `device` preset or explicit width/height.

    Most RTL/Hebrew bugs surface on mobile — use 'iphone-13' / 'pixel-7' to
    catch them. Re-call browser_get_state after to refresh element indices."""
    s = mgr.get(session_id)
    if device:
        preset = DEVICE_PRESETS.get(device)
        if not preset:
            return {"ok": False, "error": f"unknown device. Available: {list(DEVICE_PRESETS)}"}
        await s.page.set_viewport_size({"width": preset["width"], "height": preset["height"]})
        return {"ok": True, "device": device, "viewport": s.page.viewport_size,
                "is_mobile_emulated": preset["isMobile"]}
    if width and height:
        await s.page.set_viewport_size({"width": width, "height": height})
        return {"ok": True, "viewport": s.page.viewport_size}
    return {"ok": False, "error": "provide either `device` or both `width` and `height`"}


# ---------- smart waits ----------


async def browser_wait_for(mgr: SessionManager, session_id: str,
                           selector: str | None = None,
                           url_pattern: str | None = None,
                           network_idle: bool = False,
                           text: str | None = None,
                           timeout_ms: int = 10000) -> dict[str, Any]:
    """Wait for one of: a selector to appear, URL to match a pattern,
    network to settle, or text to appear in the page.

    Use this after navigation on SPAs (React/Vue/Next.js) where the initial
    DOM is empty and content fills in async."""
    s = mgr.get(session_id)
    try:
        if selector:
            await s.page.wait_for_selector(selector, timeout=timeout_ms)
            return {"ok": True, "matched": "selector", "value": selector}
        if url_pattern:
            await s.page.wait_for_url(url_pattern, timeout=timeout_ms)
            return {"ok": True, "matched": "url_pattern", "value": url_pattern, "url_now": s.page.url}
        if network_idle:
            await s.page.wait_for_load_state("networkidle", timeout=timeout_ms)
            return {"ok": True, "matched": "networkidle"}
        if text:
            await s.page.wait_for_function(
                f"() => document.body && document.body.innerText.includes({text!r})",
                timeout=timeout_ms,
            )
            return {"ok": True, "matched": "text", "value": text}
        return {"ok": False, "error": "specify selector / url_pattern / network_idle / text"}
    except Exception as e:
        return {"ok": False, "error": f"timeout or error: {type(e).__name__}: {e}"}


# ---------- cookies + storage state ----------


async def browser_get_cookies(mgr: SessionManager, session_id: str,
                              urls: list[str] | None = None) -> dict[str, Any]:
    """Read cookies. Pass `urls` to filter."""
    s = mgr.get(session_id)
    cookies = await s.context.cookies(urls=urls)
    return {"count": len(cookies), "cookies": cookies}


async def browser_set_cookies(mgr: SessionManager, session_id: str,
                              cookies: list[dict]) -> dict[str, Any]:
    """Set cookies on the session. Each cookie dict needs at minimum: name,
    value, and either url OR domain+path."""
    s = mgr.get(session_id)
    await s.context.add_cookies(cookies)
    return {"ok": True, "added": len(cookies)}


async def browser_save_storage_state(mgr: SessionManager, session_id: str,
                                     name: str = "default") -> dict[str, Any]:
    """Save the full session state (cookies + localStorage + sessionStorage)
    to disk as JSON. Restore later with browser_restore_storage_state.

    Use case: log in once → save state → re-load it on every test session
    to skip the login flow."""
    import json
    import os
    import re
    from pathlib import Path

    s = mgr.get(session_id)
    safe = re.sub(r"[^\w\-]+", "_", name).strip("_")[:80] or "default"
    data_dir = Path(os.getenv("QA_DATA_DIR") or (Path.home() / ".qa-mcp"))
    out_dir = data_dir / "storage_states"
    out_dir.mkdir(parents=True, exist_ok=True)
    out = out_dir / f"{safe}.json"
    state = await s.context.storage_state()
    out.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"ok": True, "name": safe, "path": str(out),
            "cookies_count": len(state.get("cookies", [])),
            "origins_count": len(state.get("origins", []))}


async def browser_restore_storage_state(mgr: SessionManager, session_id: str,
                                        name: str) -> dict[str, Any]:
    """Restore a previously saved storage state into THE CURRENT session's
    context. Existing cookies are merged. localStorage is set per-origin —
    this requires navigating to each origin first; the simpler use is via
    browser_open with the state pre-loaded (call save first then re-open)."""
    import json
    import os
    import re
    from pathlib import Path

    s = mgr.get(session_id)
    safe = re.sub(r"[^\w\-]+", "_", name).strip("_")[:80] or "default"
    data_dir = Path(os.getenv("QA_DATA_DIR") or (Path.home() / ".qa-mcp"))
    src = data_dir / "storage_states" / f"{safe}.json"
    if not src.exists():
        return {"ok": False, "error": f"storage state '{safe}' not found at {src}"}

    state = json.loads(src.read_text(encoding="utf-8"))
    # Apply cookies (the safe subset)
    cookies = state.get("cookies", [])
    if cookies:
        await s.context.add_cookies(cookies)
    return {"ok": True, "name": safe, "applied_cookies": len(cookies),
            "note": "cookies applied. For full localStorage restore, recreate the session with this state file."}


# ---------- bulk form filling ----------

# React-aware form filler. The standard `el.value = 'x'` doesn't propagate
# through React's synthetic event system because React caches the previous
# value on the prototype-level setter and skips updates that look like noops.
# To bypass: call the NATIVE prototype setter (which React's tracker hooks),
# then dispatch input+change. This mirrors what user-event libraries do.
_FILL_FORM_JS = r"""
(fields) => {
  const results = [];
  const setNativeValue = (el, val) => {
    const proto = el.tagName === 'TEXTAREA'
      ? window.HTMLTextAreaElement.prototype
      : (el.tagName === 'SELECT'
         ? window.HTMLSelectElement.prototype
         : window.HTMLInputElement.prototype);
    const desc = Object.getOwnPropertyDescriptor(proto, 'value');
    if (desc && desc.set) {
      desc.set.call(el, val);
    } else {
      el.value = val;
    }
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  };

  for (const [selector, raw] of fields) {
    const r = { selector, ok: false };
    let el;
    try {
      el = document.querySelector(selector);
    } catch (e) {
      r.error = `invalid selector: ${e.message}`;
      results.push(r);
      continue;
    }
    if (!el) {
      r.error = 'no element matched';
      results.push(r);
      continue;
    }

    const tag = el.tagName.toLowerCase();
    const type = (el.type || '').toLowerCase();

    try {
      // Booleans → checkbox/radio toggle.
      if (typeof raw === 'boolean') {
        if (tag === 'label') {
          // Find the labelled input — we'll click the LABEL (so React picks it up).
          if (el.click && (raw === true)) {
            el.click();
            const target = el.htmlFor ? document.getElementById(el.htmlFor) : el.querySelector('input');
            r.ok = true; r.action = 'label_click';
            r.checked = target ? target.checked : null;
          } else if (raw === false) {
            const target = el.htmlFor ? document.getElementById(el.htmlFor) : el.querySelector('input');
            if (target && target.checked) el.click();
            r.ok = true; r.action = 'label_click_off';
            r.checked = target ? target.checked : null;
          }
        } else if (type === 'checkbox' || type === 'radio') {
          if (el.checked !== raw) {
            // Click the LABEL if available — React-friendly for checkbox lists.
            const lbl = el.id ? document.querySelector(`label[for="${el.id}"]`) : null;
            if (lbl) lbl.click(); else el.click();
          }
          r.ok = true; r.action = `${type}_set`; r.checked = el.checked;
        } else {
          r.error = `bool value but element is <${tag} type=${type}>`;
        }
        results.push(r);
        continue;
      }

      // <select>
      if (tag === 'select') {
        // Accept either a string (matches value, falls back to label) or
        // {value} / {label} dict.
        let want = raw;
        let mode = 'value';
        if (raw && typeof raw === 'object' && !Array.isArray(raw)) {
          if ('value' in raw) { want = raw.value; mode = 'value'; }
          else if ('label' in raw) { want = raw.label; mode = 'label'; }
        }
        let matched = null;
        for (const opt of el.options) {
          if (mode === 'value' ? opt.value === String(want) : opt.text === String(want)) {
            matched = opt; break;
          }
        }
        // Fallback: try the other mode if first failed.
        if (!matched) {
          for (const opt of el.options) {
            if (opt.value === String(want) || opt.text === String(want)) {
              matched = opt; break;
            }
          }
        }
        if (matched) {
          setNativeValue(el, matched.value);
          r.ok = true; r.action = 'select'; r.value = matched.value; r.label = matched.text;
        } else {
          r.error = `no <option> matched ${JSON.stringify(want)}`;
        }
        results.push(r);
        continue;
      }

      // Text input / textarea / contenteditable / number / email / etc.
      if (tag === 'input' || tag === 'textarea') {
        setNativeValue(el, String(raw));
        r.ok = true; r.action = 'set_value'; r.value = el.value;
      } else if (el.isContentEditable) {
        el.focus();
        el.textContent = String(raw);
        el.dispatchEvent(new Event('input', { bubbles: true }));
        r.ok = true; r.action = 'contenteditable'; r.value = el.textContent;
      } else {
        r.error = `don't know how to fill <${tag}>`;
      }
    } catch (e) {
      r.error = `${e.name}: ${e.message}`;
    }
    results.push(r);
  }
  return results;
}
"""


async def browser_fill_form(mgr: SessionManager, session_id: str,
                            fields: dict[str, Any]) -> dict[str, Any]:
    """Bulk-fill a form by mapping CSS selectors to values. Bypasses the
    common React trap where `el.value = 'x'` is silently ignored because
    React's synthetic event tracker doesn't see the change — we call the
    native prototype setter and dispatch input+change events.

    `fields` is a dict of { "css_selector": value }. Value semantics:

      - string / number → set the input/textarea/contenteditable value
      - bool True/False → toggle a checkbox/radio (or click its <label>)
      - {"value": "x"} or {"label": "Pretty Text"} → pick a <select> option
      - "Hello" on a <select> tries value first, then label as fallback

    Use it for routine fills. For interactive widgets that need real mouse
    events (React date pickers, custom dropdowns that trap focus, drag
    handles), keep using browser_click/type with indices.

    Returns per-field result so you can see exactly which selectors failed:
      { ok: True, filled: 5, failed: 1, results: [...] }
    """
    s = mgr.get(session_id)
    # Convert dict→list of pairs (preserves order, JSON-safe through Playwright).
    pairs = list(fields.items())
    try:
        results = await s.page.evaluate(_FILL_FORM_JS, pairs)
    except Exception as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}
    filled = sum(1 for r in results if r.get("ok"))
    failed = len(results) - filled
    return {
        "ok": failed == 0,
        "filled": filled,
        "failed": failed,
        "results": results,
    }
