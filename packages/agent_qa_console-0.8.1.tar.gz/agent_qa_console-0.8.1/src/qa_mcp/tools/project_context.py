"""Project context and visual element → source mapping helpers.

These helpers let Agent QA Console work next to a local codebase. The browser
selection payload tells us what the user clicked; this module tells the agent
where that thing probably lives in source.
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any
from urllib.parse import urlparse


_SOURCE_EXTS = {
    ".tsx", ".jsx", ".ts", ".js", ".mjs", ".cjs",
    ".vue", ".svelte", ".astro", ".html", ".htm",
    ".css", ".scss", ".sass", ".less", ".mdx",
}
_CONFIG_FILES = {
    "package.json", "next.config.js", "next.config.mjs", "next.config.ts",
    "vite.config.js", "vite.config.ts", "nuxt.config.ts", "svelte.config.js",
    "astro.config.mjs", "tsconfig.json", "jsconfig.json", "tailwind.config.js",
    "tailwind.config.ts", "components.json",
}
_SKIP_DIRS = {
    ".git", "node_modules", ".next", ".nuxt", ".svelte-kit", "dist", "build",
    "out", "coverage", ".cache", ".turbo", ".vercel", ".netlify", "target",
    ".venv", "venv", "__pycache__", ".pytest_cache", ".idea", ".vscode",
}
_ROUTE_DIRS = {"app", "pages", "src/app", "src/pages", "routes", "src/routes"}
_COMPONENT_HINTS = {"component", "components", "ui", "widgets", "sections", "features"}


def _safe_root(project_root: str | None) -> Path:
    root = Path(project_root or ".").expanduser().resolve()
    if not root.exists() or not root.is_dir():
        raise FileNotFoundError(f"project_root not found: {project_root or '.'}")
    return root


def _is_skipped(path: Path, root: Path) -> bool:
    try:
        rel = path.relative_to(root)
    except ValueError:
        return True
    return any(part in _SKIP_DIRS for part in rel.parts)


def _iter_files(root: Path, max_files: int = 2500) -> list[Path]:
    files: list[Path] = []
    for path in root.rglob("*"):
        if len(files) >= max_files:
            break
        if _is_skipped(path, root):
            continue
        if not path.is_file():
            continue
        if path.name in _CONFIG_FILES or path.suffix in _SOURCE_EXTS or path.suffix in {".json", ".yml", ".yaml"}:
            files.append(path)
    return files


def _rel(path: Path, root: Path) -> str:
    return str(path.relative_to(root)).replace("\\", "/")


def _read_small_json(path: Path) -> dict[str, Any]:
    try:
        if path.stat().st_size > 300_000:
            return {}
        return json.loads(path.read_text(encoding="utf-8", errors="replace"))
    except Exception:
        return {}


def _detect_framework(root: Path) -> dict[str, Any]:
    package = _read_small_json(root / "package.json") if (root / "package.json").exists() else {}
    deps = {**(package.get("dependencies") or {}), **(package.get("devDependencies") or {})}
    names = set(deps)
    framework = "unknown"
    if "next" in names or (root / "next.config.js").exists() or (root / "next.config.mjs").exists():
        framework = "nextjs"
    elif "@vitejs/plugin-react" in names or "vite" in names:
        framework = "vite"
    elif "nuxt" in names:
        framework = "nuxt"
    elif "@sveltejs/kit" in names:
        framework = "sveltekit"
    elif "astro" in names:
        framework = "astro"
    elif "react" in names:
        framework = "react"
    elif "vue" in names:
        framework = "vue"
    return {
        "framework": framework,
        "packageManager": "pnpm" if (root / "pnpm-lock.yaml").exists() else "yarn" if (root / "yarn.lock").exists() else "npm" if (root / "package-lock.json").exists() else None,
        "scripts": package.get("scripts") or {},
        "dependencies": sorted(list(names))[:80],
    }


def _load_aliases(root: Path) -> dict[str, Any]:
    cfg = {}
    for name in ("tsconfig.json", "jsconfig.json"):
        path = root / name
        if path.exists():
            cfg = _read_small_json(path)
            break
    opts = cfg.get("compilerOptions") or {}
    return {"baseUrl": opts.get("baseUrl"), "paths": opts.get("paths") or {}}


def _classify_files(files: list[Path], root: Path) -> tuple[list[str], list[str]]:
    routes: list[str] = []
    components: list[str] = []
    for path in files:
        rel = _rel(path, root)
        parts = set(rel.split("/"))
        if path.suffix not in _SOURCE_EXTS and path.suffix != ".mdx":
            continue
        if any(rel.startswith(rd + "/") for rd in _ROUTE_DIRS):
            name = path.name
            if name.startswith("page.") or name.startswith("route.") or name.startswith("layout.") or rel.startswith(("pages/", "src/pages/", "routes/", "src/routes/")):
                routes.append(rel)
        if parts & _COMPONENT_HINTS or re.search(r"(^|/)[A-Z][^/]+\.(tsx|jsx|vue|svelte|astro)$", rel):
            components.append(rel)
    return routes[:250], components[:500]


def _tree(files: list[Path], root: Path, max_files: int, max_depth: int) -> list[str]:
    lines: list[str] = []
    for path in sorted(files, key=lambda p: _rel(p, root))[:max_files]:
        rel = _rel(path, root)
        if len(rel.split("/")) > max_depth:
            continue
        lines.append(rel)
    return lines


def build_project_context(project_root: str | None = None,
                          max_files: int = 800,
                          max_depth: int = 5) -> dict[str, Any]:
    """Return compact source-tree context for an agent."""
    root = _safe_root(project_root)
    files = _iter_files(root, max_files=max(max_files * 4, 1000))
    routes, components = _classify_files(files, root)
    config_files = [_rel(p, root) for p in files if p.name in _CONFIG_FILES]
    return {
        "ok": True,
        "projectRoot": str(root),
        **_detect_framework(root),
        "aliases": _load_aliases(root),
        "counts": {"scannedFiles": len(files), "routes": len(routes), "components": len(components)},
        "configFiles": sorted(config_files),
        "routes": routes,
        "components": components,
        "tree": _tree(files, root, max_files=max_files, max_depth=max_depth),
        "skipDirs": sorted(_SKIP_DIRS),
    }


def _route_from_url(url: str | None) -> str:
    if not url:
        return "/"
    try:
        path = urlparse(url).path or "/"
    except Exception:
        path = "/"
    return path.rstrip("/") or "/"


def _next_route_candidates(route: str) -> list[str]:
    clean = route.strip("/")
    candidates: list[str] = []
    app_seg = clean or ""
    for base in ("app", "src/app"):
        prefix = f"{base}/{app_seg}" if app_seg else base
        candidates += [f"{prefix}/page.tsx", f"{prefix}/page.jsx", f"{prefix}/page.ts", f"{prefix}/page.js"]
    for base in ("pages", "src/pages"):
        if clean:
            candidates += [f"{base}/{clean}.tsx", f"{base}/{clean}.jsx", f"{base}/{clean}.ts", f"{base}/{clean}.js", f"{base}/{clean}/index.tsx", f"{base}/{clean}/index.jsx"]
        else:
            candidates += [f"{base}/index.tsx", f"{base}/index.jsx", f"{base}/index.ts", f"{base}/index.js"]
    return candidates


def _selection_terms(selection: dict[str, Any]) -> list[tuple[str, str, float]]:
    terms: list[tuple[str, str, float]] = []
    def add(kind: str, value: Any, score: float) -> None:
        if value is None:
            return
        text = str(value).strip()
        if len(text) < 2:
            return
        terms.append((kind, text, score))

    data = selection.get("dataAttrs") or {}
    for key in ("data-source", "data-file", "data-component", "data-testid", "data-test-id", "data-agent-id", "data-cy", "data-qa"):
        if key in data:
            add(key, data.get(key), 1.0)
    add("sourceHint", selection.get("sourceHint"), 1.0)
    add("id", selection.get("id"), 0.82)
    add("name", selection.get("name"), 0.72)
    add("ariaLabel", selection.get("ariaLabel"), 0.72)
    add("placeholder", selection.get("placeholder"), 0.72)
    add("text", selection.get("text"), 0.68)
    add("label", selection.get("label"), 0.65)
    class_name = selection.get("className")
    if class_name:
        for cls in re.split(r"\s+", str(class_name))[:8]:
            if len(cls) >= 3 and not re.match(r"^(flex|grid|px-|py-|p-|m-|mt-|mb-|text-|bg-|w-|h-)", cls):
                add("class", cls, 0.42)
    selector = selection.get("selector")
    if selector:
        for ident in re.findall(r"[#.]([A-Za-z0-9_-]{3,})", selector)[:8]:
            add("selector", ident, 0.45)
    return terms


def _search_term(files: list[Path], root: Path, term: str, kind: str, base_score: float, limit: int) -> list[dict[str, Any]]:
    matches: list[dict[str, Any]] = []
    needle = term.lower()
    if len(needle) > 180:
        needle = needle[:180]
    for path in files:
        if len(matches) >= limit:
            break
        try:
            if path.stat().st_size > 700_000:
                continue
            content = path.read_text(encoding="utf-8", errors="replace")
        except Exception:
            continue
        idx = content.lower().find(needle)
        if idx == -1:
            continue
        line_no = content.count("\n", 0, idx) + 1
        line = content.splitlines()[line_no - 1] if content.splitlines() else ""
        matches.append({
            "file": _rel(path, root),
            "line": line_no,
            "matchText": line.strip()[:240],
            "term": term[:180],
            "matchType": kind,
            "confidence": round(base_score, 2),
        })
    return matches


def map_selected_element_to_source(selection: dict[str, Any],
                                   project_root: str | None = None,
                                   max_matches: int = 12) -> dict[str, Any]:
    """Map one Console element selection payload to likely source files."""
    root = _safe_root(project_root)
    files = _iter_files(root, max_files=5000)
    source_files = [p for p in files if p.suffix in _SOURCE_EXTS or p.name in _CONFIG_FILES]
    route = _route_from_url(selection.get("url"))
    matches: list[dict[str, Any]] = []

    # 1. Direct source/file hints win.
    data = selection.get("dataAttrs") or {}
    direct_hints = [selection.get("sourceHint"), data.get("data-source"), data.get("data-file")]
    for hint in direct_hints:
        if not hint:
            continue
        candidate = (root / str(hint)).resolve()
        try:
            if candidate.exists() and candidate.is_file() and root in candidate.parents:
                matches.append({"file": _rel(candidate, root), "line": 1, "matchText": "direct source hint", "term": str(hint), "matchType": "direct_source_hint", "confidence": 1.1})
        except Exception:
            pass

    # 2. Route files by URL.
    for rel in _next_route_candidates(route):
        path = root / rel
        if path.exists() and path.is_file():
            matches.append({"file": rel, "line": 1, "matchText": f"route file for {route}", "term": route, "matchType": "route", "confidence": 0.78})

    # 3. Search source for DOM hints.
    for kind, term, score in _selection_terms(selection):
        if len(matches) >= max_matches:
            break
        for m in _search_term(source_files, root, term, kind, score, limit=4):
            if not any(existing["file"] == m["file"] and existing.get("line") == m.get("line") for existing in matches):
                matches.append(m)
            if len(matches) >= max_matches:
                break

    # Merge duplicate files, keeping best confidence/first line.
    by_file: dict[str, dict[str, Any]] = {}
    for m in matches:
        key = m["file"]
        old = by_file.get(key)
        if not old or m.get("confidence", 0) > old.get("confidence", 0):
            by_file[key] = m
    ranked = sorted(by_file.values(), key=lambda m: (-float(m.get("confidence", 0)), m["file"]))[:max_matches]

    return {
        "ok": True,
        "projectRoot": str(root),
        "selected": {
            "url": selection.get("url"),
            "route": route,
            "tag": selection.get("tag"),
            "label": selection.get("label"),
            "selector": selection.get("selector"),
            "id": selection.get("id"),
            "dataAttrs": data,
        },
        "matches": ranked,
        "count": len(ranked),
        "strategy": ["direct data-source/data-file", "route by URL", "data/id/text/class search"],
    }
