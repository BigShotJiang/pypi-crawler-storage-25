"""QA-specialty tools — programmatic audits, no LLM needed.

These return structured findings the calling agent can summarize, prioritize,
or push to a bug tracker. The intelligence is in the JS audit scripts (or in
the agent calling these), not in the MCP server itself.
"""
from __future__ import annotations

import hashlib
import os
import re
from datetime import datetime
from pathlib import Path
from typing import Any

from ..browser import SessionManager
from .. import training_data


_DATA_DIR = Path(os.getenv("QA_DATA_DIR") or (Path.home() / ".qa-mcp"))
# QA_MCP_BASELINE_DIR overrides the baselines location (e.g. mount a shared
# folder for CI/team use). Future: QA_MCP_BASELINE_S3_BUCKET for cloud.
_BASELINE_DIR = Path(os.getenv("QA_MCP_BASELINE_DIR") or (_DATA_DIR / "baselines"))
# mkdir deferred to _resolve_baseline_dir to avoid disk I/O at import time.


def _safe_name(name: str) -> str:
    return re.sub(r"[^\w\-]+", "_", name).strip("_")[:80] or "default"


_SCRIPT_CACHE: dict[str, str] = {}


def _read_script(name: str) -> str:
    cached = _SCRIPT_CACHE.get(name)
    if cached is not None:
        return cached
    from importlib import resources
    with resources.files("qa_mcp._scripts").joinpath(name).open("r", encoding="utf-8") as f:
        text = f.read()
    _SCRIPT_CACHE[name] = text
    return text


# ---------------- Output verbosity helper ----------------

# Audits often produce 100+ findings on real sites. Returning everything
# burns the calling agent's context (one ynet RTL scan = ~55K tokens).
# `detail` lets the agent ask for less — and the dropped data is still on
# disk via training_data.capture, plus the file_path returned in `samples`/
# `summary` modes points at the full JSON for follow-up.

_DETAIL_LEVELS = ("summary", "samples", "full")
_LIST_FIELDS = ("findings", "violations", "issues", "items", "results")
# Per-mode caps for any list-of-findings field on the result
_SAMPLE_CAPS = {"summary": 0, "samples": 5, "full": None}


def _trim_for_detail(result: dict[str, Any], detail: str) -> dict[str, Any]:
    """Trim a tool result by `detail` level. Never raises.

    summary  -> drop list fields entirely. Keep summary/page/score/grades.
    samples  -> keep first N findings per list field (default N=5).
    full     -> return as-is.
    """
    if not isinstance(result, dict):
        return result
    if detail == "full":
        return result
    if detail not in _DETAIL_LEVELS:
        # Unknown level -> behave like 'samples' rather than break
        detail = "samples"

    cap = _SAMPLE_CAPS[detail]
    out: dict[str, Any] = {}
    truncated: dict[str, int] = {}
    for k, v in result.items():
        if k in _LIST_FIELDS and isinstance(v, list):
            if cap == 0:
                truncated[k] = len(v)
                # Drop entirely in summary mode
                continue
            if cap is not None and len(v) > cap:
                truncated[k] = len(v)
                out[k] = v[:cap]
            else:
                out[k] = v
        else:
            out[k] = v
    if truncated:
        out["_truncated"] = {
            "detail_level": detail,
            "fields": truncated,
            "hint": "Re-run with detail='full' for the complete list, "
                    "or read the captured JSON via QA_MCP_TRAINING_DATA_DIR.",
        }
    return out


async def _wait_for_content(page, timeout_ms: int = 4000) -> None:
    """Shared pre-audit barrier. Without this, parallel qa_* calls can race on
    a partially-hydrated SPA — qa_a11y reports 'no h1' while qa_seo reports
    h1_count=1, etc. (See test-results 2026-05-02 bug #1.)

    Best-effort: each step has its own short timeout, total bounded ~timeout_ms.
    Never raises — a slow page should still produce findings, not a tool error.
    """
    per_step = max(500, timeout_ms // 3)
    try:
        await page.wait_for_load_state("domcontentloaded", timeout=per_step)
    except Exception:
        pass
    try:
        await page.wait_for_function(
            "document.readyState === 'complete'", timeout=per_step
        )
    except Exception:
        pass
    try:
        await page.wait_for_load_state("networkidle", timeout=per_step)
    except Exception:
        pass


async def qa_rtl_audit(mgr: SessionManager, session_id: str,
                       ignore_patterns: list[str] | None = None,
                       ignore_selectors: list[str] | None = None,
                       detail: str = "samples",
                       smart_ignore: bool = True,
                       report_mode: str = "internal_full",
                       min_confidence: float = 0.85,
                       strict_currency_position: bool = False,
                       ) -> dict[str, Any]:
    """RTL/Hebrew audit. Optional allowlist:
      - `ignore_patterns`: regex strings; text matching ANY is silenced
        (e.g. ["v\\d+\\.\\d+"] for version strings, brand-specific terms).
      - `ignore_selectors`: CSS selectors; matching elements are skipped
        entirely (e.g. [".version-badge", "[data-locale-mixed]"]).
      - `detail`: 'summary' | 'samples' (default) | 'full'. summary = counts
        only, samples = first 5 findings per category, full = everything.
        The full result is always captured to disk if QA_MCP_TRAINING_DATA_DIR
        is set, regardless of detail level.
      - `report_mode`: 'internal_full' returns all annotated findings;
        'client_safe' returns only high-confidence findings suitable for an
        automated client report.
      - `min_confidence`: threshold for client_safe findings (default 0.85).
      - `strict_currency_position`: optional team style-guide check for ₪
        placement. Off by default because Israeli sites commonly use both
        "₪99" and "99 ₪".

    Use sparingly — over-allowlisting masks real bugs."""
    s = mgr.get(session_id)
    await _wait_for_content(s.page)
    result = await s.page.evaluate(_read_script("rtl_audit.js"), {
        "ignore_patterns": ignore_patterns or [],
        "ignore_selectors": ignore_selectors or [],
        "smart_ignore": smart_ignore,
        "report_mode": report_mode,
        "min_confidence": min_confidence,
        "strict_currency_position": strict_currency_position,
    })
    # Cache findings on the session so qa_fix_suggestions can access them
    # without re-running the audit.
    findings_raw = result.get("findings", []) if isinstance(result, dict) else []
    s._last_rtl_findings = findings_raw
    await training_data.capture(mgr, session_id, "rtl", result)
    return _trim_for_detail(result, detail)


async def qa_perf_metrics(mgr: SessionManager, session_id: str,
                          wait_for_lcp_ms: int = 2500,
                          thresholds: dict[str, dict[str, float]] | None = None,
                          detail: str = "samples",
                          ) -> dict[str, Any]:
    """Web Vitals + timing. Waits up to `wait_for_lcp_ms` (default 2.5s) for
    the page to settle so LCP has a chance to fire.

    `thresholds` (optional) overrides Core Web Vitals cutoffs per-metric.
    Shape: {"lcp": {"good": 2000, "poor": 4000}, "fcp": {...}, ...}.
    Any omitted metric uses Google defaults. Use case: stricter SLO for
    enterprise SaaS, or relaxed for content sites on slow infra.
    """
    s = mgr.get(session_id)
    await _wait_for_content(s.page)
    # Best effort: wait for load event + a short post-load buffer for LCP.
    try:
        await s.page.wait_for_load_state("load", timeout=wait_for_lcp_ms)
    except Exception:
        pass
    if wait_for_lcp_ms > 0:
        await s.page.wait_for_timeout(min(wait_for_lcp_ms, 2500))
    result = await s.page.evaluate(_read_script("perf_metrics.js"), {"thresholds": thresholds or {}})
    await training_data.capture(mgr, session_id, "perf", result)
    return _trim_for_detail(result, detail)


async def qa_scan_links(mgr: SessionManager, session_id: str,
                        detail: str = "samples") -> dict[str, Any]:
    s = mgr.get(session_id)
    await _wait_for_content(s.page)
    result = await s.page.evaluate(_read_script("scan_links.js"))
    await training_data.capture(mgr, session_id, "links", result)
    return _trim_for_detail(result, detail)


async def qa_asset_audit(mgr: SessionManager, session_id: str,
                         detail: str = "samples",
                         max_probe: int = 20) -> dict[str, Any]:
    """Audit visual assets that failed to load in the real agent browser.

    This answers a production-critical question for the live console: if the
    center browser shows empty image slots, is the console broken, or did the
    target site/CDN block the image requests? It flags visible broken images,
    probes a bounded sample, and identifies CDN challenges such as Cloudflare
    (`cf-mitigated: challenge`).
    """
    s = mgr.get(session_id)
    await _wait_for_content(s.page)
    images = await s.page.evaluate("""
    () => Array.from(document.images).map((img, i) => {
      const r = img.getBoundingClientRect();
      const src = img.currentSrc || img.src || '';
      return {
        index: i,
        src,
        alt: img.alt || '',
        complete: img.complete,
        naturalWidth: img.naturalWidth,
        naturalHeight: img.naturalHeight,
        loading: img.loading || '',
        visibleWidth: Math.round(r.width),
        visibleHeight: Math.round(r.height),
        inViewport: r.bottom >= 0 && r.right >= 0 && r.top <= innerHeight && r.left <= innerWidth,
        selector: img.id ? `#${CSS.escape(img.id)}` : `img:nth-of-type(${i + 1})`,
      };
    })
    """)
    items: list[dict[str, Any]] = []
    findings: list[dict[str, Any]] = []
    broken_candidates = [
        img for img in images
        if img.get("src", "").startswith("http")
        and int(img.get("visibleWidth") or 0) > 0
        and int(img.get("visibleHeight") or 0) > 0
        and int(img.get("naturalWidth") or 0) == 0
    ]

    for img in broken_candidates[:max(0, max_probe)]:
        src = img.get("src") or ""
        probe = await s.page.evaluate(
            """async (url) => {
              try {
                const r = await fetch(url, {cache: 'no-store'});
                const headers = {};
                for (const [k, v] of r.headers.entries()) headers[k] = v;
                return {ok: r.ok, status: r.status, type: r.type, contentType: r.headers.get('content-type'), cfMitigated: r.headers.get('cf-mitigated'), headers};
              } catch (e) {
                return {ok: false, error: String(e)};
              }
            }""",
            src,
        )
        item = {**img, "probe": probe}
        items.append(item)
        status = probe.get("status") if isinstance(probe, dict) else None
        cf = (probe.get("cfMitigated") if isinstance(probe, dict) else None) or ""
        content_type = (probe.get("contentType") if isinstance(probe, dict) else None) or ""
        if str(cf).lower() == "challenge":
            findings.append({
                "severity": "medium",
                "category": "asset_blocked_cdn_challenge",
                "title": "Image asset blocked by CDN challenge",
                "description": "The browser received a Cloudflare/CDN challenge instead of image bytes, so the live console correctly shows an empty/broken image slot.",
                "selector": img.get("selector"),
                "src": src,
                "status": status,
                "evidence": {"cf-mitigated": cf, "content-type": content_type},
                "fix": "Use a trusted/manual browser profile or report this as external-site/CDN blocking. The QA console cannot render an image the target server refuses to serve.",
            })
        elif status and int(status) >= 400:
            findings.append({
                "severity": "medium",
                "category": "asset_http_error",
                "title": f"Image asset returned HTTP {status}",
                "description": "A visible image slot points to an asset URL that returned an HTTP error.",
                "selector": img.get("selector"),
                "src": src,
                "status": status,
                "evidence": {"content-type": content_type},
                "fix": "Fix the asset URL/permissions/CDN rule or remove the broken image slot.",
            })
        else:
            findings.append({
                "severity": "low",
                "category": "asset_broken_unknown",
                "title": "Visible image slot has no decoded image",
                "description": "The image occupies layout space but naturalWidth is 0 in the browser.",
                "selector": img.get("selector"),
                "src": src,
                "status": status,
                "evidence": probe if isinstance(probe, dict) else {},
                "fix": "Inspect lazy loading, decoding, CSP/CORS, and CDN rules.",
            })

    result = {
        "page": {"url": s.page.url, "title": await s.page.title()},
        "summary": {
            "images": len(images),
            "visible_broken_candidates": len(broken_candidates),
            "probed": len(items),
            "findings": len(findings),
            "by_category": _summarize_findings(findings).get("by_category", {}),
        },
        "items": items,
        "findings": findings,
    }
    await training_data.capture(mgr, session_id, "assets", result)
    return _trim_for_detail(result, detail)


async def qa_design_quality_check(mgr: SessionManager, session_id: str,
                                  detail: str = "samples") -> dict[str, Any]:
    """AI-slop / generic-UI detector.

    Runs 11 rule-based checks (no LLM, no API key) drawn from the gstack
    design-review blacklist:

      1. Purple/violet/indigo gradient backgrounds
      2. 3-column feature grid (icon + title + 2-line description × 3)
      3. Icons in colored circles as decoration
      4. Centered everything (text-align:center on most headings)
      5. Uniform bubbly border-radius across element types
      6. Emoji as design elements in headings
      7. Colored left-border accent on cards
      8. Generic hero copy ("Welcome to X", "Unlock the power of...", etc.)
      9. system-ui as the PRIMARY display/body font
      10. Decorative blob/wave SVGs filling empty space
      11. Stock SaaS section rhythm (hero → features → testimonials → pricing → CTA)

    Each finding includes a `positive_reference` pointing at how Linear/
    Stripe/Raycast/GitHub solve the same need — so the calling agent can
    propose a direction, not just flag the problem.

    Returns: { page, findings, summary: { total, by_severity, score (0-100),
              grade (A-F), verdict } }.

    Use this whenever the user asks "does my site look AI-generated?" or
    when reviewing a v0 / Lovable / bolt.new output.
    """
    s = mgr.get(session_id)
    await _wait_for_content(s.page)
    result = await s.page.evaluate(_read_script("design_quality.js"))
    await training_data.capture(mgr, session_id, "design_quality", result)
    return _trim_for_detail(result, detail)


def _sev_rank(severity: str) -> int:
    return {"critical": 0, "high": 1, "serious": 1, "medium": 2, "moderate": 2, "low": 3, "minor": 3, "info": 4}.get(severity or "info", 4)


def _summarize_findings(findings: list[dict[str, Any]]) -> dict[str, Any]:
    by_severity: dict[str, int] = {}
    by_category: dict[str, int] = {}
    for f in findings:
        sev = f.get("severity") or "info"
        cat = f.get("category") or "general"
        by_severity[sev] = by_severity.get(sev, 0) + 1
        by_category[cat] = by_category.get(cat, 0) + 1
    return {"total": len(findings), "by_severity": by_severity, "by_category": by_category}


def _ux_profile(persona: str) -> dict[str, Any]:
    profiles = {
        "general": {"max_ctas": 1, "max_font_sizes": 7, "max_text_colors": 9, "max_kpis": 5, "min_touch": 44},
        "conversion": {"max_ctas": 1, "max_font_sizes": 6, "max_text_colors": 8, "max_kpis": 4, "min_touch": 44},
        "mobile_first": {"max_ctas": 1, "max_font_sizes": 6, "max_text_colors": 8, "max_kpis": 4, "min_touch": 48},
        "business_owner": {"max_ctas": 1, "max_font_sizes": 6, "max_text_colors": 8, "max_kpis": 4, "min_touch": 44},
        "elderly_user": {"max_ctas": 1, "max_font_sizes": 5, "max_text_colors": 7, "max_kpis": 3, "min_touch": 48},
        "dashboard": {"max_ctas": 3, "max_font_sizes": 8, "max_text_colors": 10, "max_kpis": 8, "min_touch": 40},
    }
    return profiles.get((persona or "general").lower(), profiles["general"])


def _interpret_ux_metrics(result: dict[str, Any], persona: str = "general") -> dict[str, Any]:
    """Turn raw qa_ux_metrics numbers into actionable UX findings.

    No LLM judgment here: deterministic thresholds only. The calling agent can
    still override priority based on brand/product context.
    """
    p = _ux_profile(persona)
    findings: list[dict[str, Any]] = []
    scores = result.get("scores") or {}
    headings = result.get("headings") or {}
    interactive = result.get("interactive") or {}
    touch = result.get("touch_targets") or {}
    typography = result.get("typography") or {}
    color = result.get("color") or {}
    density = result.get("density") or {}
    kpi = result.get("kpi") or {}

    h1_count = headings.get("h1_count")
    if h1_count != 1:
        findings.append({
            "severity": "medium" if h1_count and h1_count > 1 else "high",
            "category": "heading_hierarchy",
            "title": f"Expected exactly one visible H1, found {h1_count}",
            "impact": "Users and assistive/search tooling may struggle to identify the page's primary purpose.",
            "fix": "Keep one primary H1 and demote secondary titles to H2/H3.",
        })
    if headings.get("order_ok") is False:
        findings.append({
            "severity": "medium",
            "category": "heading_hierarchy",
            "title": "Heading visual order is inconsistent",
            "impact": "The page hierarchy is harder to scan at a glance.",
            "fix": "Make H1 visually dominant, then H2, then H3; avoid styling lower headings larger than higher ones.",
        })

    cta_in_fold = interactive.get("cta_in_fold") or 0
    if cta_in_fold == 0:
        findings.append({
            "severity": "medium",
            "category": "cta_clarity",
            "title": "No clear CTA above the fold",
            "impact": "Users may not know what to do next without scrolling or searching.",
            "fix": "Place one primary action above the fold with clear verb-led copy.",
        })
    elif cta_in_fold > p["max_ctas"]:
        findings.append({
            "severity": "medium",
            "category": "cta_clarity",
            "title": f"Too many CTA candidates above the fold ({cta_in_fold})",
            "impact": "Competing actions create decision friction and reduce conversion clarity.",
            "fix": "Choose one primary CTA, make secondary actions visually quieter, and move tertiary actions below the fold.",
            "samples": interactive.get("cta_samples", []),
        })
    ratio = interactive.get("dominant_cta_ratio")
    if cta_in_fold > 1 and ratio is not None and ratio < 1.4:
        findings.append({
            "severity": "low",
            "category": "cta_clarity",
            "title": "Primary CTA is not visually dominant",
            "impact": "Users see several equal-weight actions instead of a clear next step.",
            "fix": "Increase contrast/size of the primary CTA or reduce prominence of alternatives.",
        })

    small_count = touch.get("small_count") or 0
    if small_count:
        severity = "high" if small_count >= 10 or p["min_touch"] >= 48 else "medium"
        findings.append({
            "severity": severity,
            "category": "touch_targets",
            "title": f"Small interactive targets detected ({small_count})",
            "impact": "Mobile/touch users are more likely to mis-tap or abandon the flow.",
            "fix": f"Increase clickable boxes to at least {p['min_touch']}×{p['min_touch']}px, especially primary controls.",
            "samples": touch.get("small_samples", []),
        })

    fs = typography.get("distinct_font_sizes") or 0
    if fs > p["max_font_sizes"]:
        findings.append({
            "severity": "low" if fs <= p["max_font_sizes"] + 2 else "medium",
            "category": "visual_noise",
            "title": f"Many distinct font sizes ({fs})",
            "impact": "Too many type sizes weaken visual rhythm and scanning speed.",
            "fix": "Consolidate typography into a small scale: display, h1, h2, body, caption.",
        })
    tc = color.get("distinct_text_colors") or 0
    if tc > p["max_text_colors"]:
        findings.append({
            "severity": "low" if tc <= p["max_text_colors"] + 2 else "medium",
            "category": "visual_noise",
            "title": f"Many distinct text colors ({tc})",
            "impact": "Excessive color variation increases cognitive load and can blur priority.",
            "fix": "Use a limited semantic palette: primary, secondary, muted, danger/success, link.",
        })

    kpis = kpi.get("candidates_in_fold") or 0
    if kpis > p["max_kpis"]:
        findings.append({
            "severity": "medium",
            "category": "kpi_overload",
            "title": f"Many KPI-like numbers above the fold ({kpis})",
            "impact": "Non-analyst users may miss the one number that matters most.",
            "fix": "Group KPIs, highlight one primary metric, and move secondary metrics lower or behind filters.",
            "samples": kpi.get("samples", []),
        })

    chars_per_px2 = density.get("chars_per_px2") or 0
    if chars_per_px2 > 0.003:
        findings.append({
            "severity": "medium" if chars_per_px2 < 0.006 else "high",
            "category": "density",
            "title": "High text density above the fold",
            "impact": "The first screen feels crowded and harder to parse quickly.",
            "fix": "Shorten copy, add whitespace, split dense paragraphs into bullets/cards, and move details below the fold.",
            "evidence": {"chars_per_px2": chars_per_px2},
        })

    for score_name, category, title in [
        ("hierarchy_score", "hierarchy", "Weak visual hierarchy score"),
        ("cognitive_load_score", "cognitive_load", "High cognitive load signal"),
        ("density_score", "density", "Low breathable-density score"),
        ("touch_target_score", "touch_targets", "Low touch-target score"),
    ]:
        val = scores.get(score_name)
        if val is not None and val < 70 and not any(f.get("category") == category for f in findings):
            findings.append({
                "severity": "medium" if val >= 50 else "high",
                "category": category,
                "title": f"{title}: {val}/100",
                "impact": "This heuristic score suggests users may need more effort than expected.",
                "fix": "Inspect the underlying raw metrics and simplify the page around the primary user goal.",
            })

    findings.sort(key=lambda f: (_sev_rank(f.get("severity", "info")), f.get("category", "")))
    recommendations = [
        {
            "priority": "must_fix" if f.get("severity") in ("critical", "high") else "should_fix" if f.get("severity") == "medium" else "nice_to_have",
            "title": f.get("title"),
            "fix": f.get("fix"),
            "category": f.get("category"),
        }
        for f in findings[:10]
    ]
    return {
        "persona": persona or "general",
        "findings": findings,
        "summary": _summarize_findings(findings),
        "recommendations": recommendations,
    }


async def qa_ux_metrics(mgr: SessionManager, session_id: str,
                        fold_height: int | None = None,
                        min_touch_px: int = 44,
                        detail: str = "samples",
                        persona: str = "general",
                        include_findings: bool = True,
                        ) -> dict[str, Any]:
    """Deterministic UX measurements: visual hierarchy, cognitive load, density,
    touch targets, CTA dominance, KPI candidates above the fold.

    Produces raw numbers + heuristic 0-100 scores. The scores are composites
    intended for trend tracking; a calling agent should reason about them
    against persona/goal rather than trust absolute values.

    `fold_height` (optional): override viewport-fold height in px. Defaults to
        window.innerHeight. Use 600 to simulate a small laptop, 740 for
        iPhone 13, etc.
    `min_touch_px` (optional): minimum width/height for an interactive element
        before it's flagged as a small target. Default 44 (Apple HIG / WCAG 2.5.5).
    """
    s = mgr.get(session_id)
    await _wait_for_content(s.page)
    profile = _ux_profile(persona)
    result = await s.page.evaluate(_read_script("ux_metrics.js"), {
        "fold_height": fold_height,
        "min_touch_px": max(min_touch_px, profile.get("min_touch", min_touch_px)),
    })
    if include_findings and isinstance(result, dict):
        result["interpretation"] = _interpret_ux_metrics(result, persona=persona)
        result["findings"] = result["interpretation"]["findings"]
        result["recommendations"] = result["interpretation"]["recommendations"]
    await training_data.capture(mgr, session_id, "ux_metrics", result)
    return _trim_for_detail(result, detail)


# axe-core injected from CDN. Returns WCAG violations grouped by impact.
_AXE_INJECTION = r"""
async () => {
  if (typeof window.axe === 'undefined') {
    await new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = 'https://cdnjs.cloudflare.com/ajax/libs/axe-core/4.10.0/axe.min.js';
      s.onload = resolve;
      s.onerror = reject;
      document.head.appendChild(s);
    });
  }
  const result = await window.axe.run({ runOnly: ['wcag2a', 'wcag2aa', 'best-practice'] });
  return {
    violations: result.violations.map(v => ({
      id: v.id, impact: v.impact, description: v.description,
      help: v.help, helpUrl: v.helpUrl, tags: v.tags,
      nodes_count: v.nodes.length,
      sample_target: v.nodes[0]?.target?.[0] || null,
      sample_html: (v.nodes[0]?.html || '').slice(0, 200),
    })),
    passes_count: result.passes.length,
    incomplete_count: result.incomplete.length,
    summary: {
      total: result.violations.length,
      by_impact: result.violations.reduce((acc, v) => {
        acc[v.impact || 'unknown'] = (acc[v.impact || 'unknown'] || 0) + 1;
        return acc;
      }, {}),
    },
  };
}
"""


_IMPACT_RANK = {"minor": 0, "moderate": 1, "serious": 2, "critical": 3}


_CONVERSION_AUDIT_JS = r"""
() => {
  const fold = window.innerHeight || 800;
  const vw = window.innerWidth || 1200;
  const ctaRe = /\b(buy|checkout|cart|order|pricing|price|start|get started|sign up|signup|register|join|book|demo|call|contact|quote|trial|subscribe|download|apply|donate|learn more|request|schedule|login|log in)\b/i;
  const badHrefRe = /^(#|javascript:|)$/i;
  const visible = (el) => {
    const r = el.getBoundingClientRect();
    const cs = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && cs.display !== 'none' && cs.visibility !== 'hidden' && cs.opacity !== '0';
  };
  const textOf = (el) => (el.innerText || el.value || el.getAttribute('aria-label') || el.getAttribute('title') || '').replace(/\s+/g, ' ').trim();
  const selectorOf = (el) => {
    if (el.id) return `#${CSS.escape(el.id)}`;
    const parts = [];
    let n = el;
    while (n && n.nodeType === 1 && parts.length < 4) {
      let p = n.tagName.toLowerCase();
      if (n.classList && n.classList.length) p += '.' + [...n.classList].slice(0,2).map(c => CSS.escape(c)).join('.');
      const parent = n.parentElement;
      if (parent) {
        const same = [...parent.children].filter(x => x.tagName === n.tagName);
        if (same.length > 1) p += `:nth-of-type(${same.indexOf(n)+1})`;
      }
      parts.unshift(p); n = parent;
    }
    return parts.join(' > ');
  };
  const interactive = [...document.querySelectorAll('a,button,input[type=button],input[type=submit],[role=button]')]
    .filter(visible).map(el => {
      const r = el.getBoundingClientRect();
      const text = textOf(el);
      const href = el.getAttribute('href') || '';
      const aboveFold = r.top >= 0 && r.top < fold;
      const isCta = ctaRe.test(text) || ctaRe.test(href);
      return {selector: selectorOf(el), tag: el.tagName.toLowerCase(), text: text.slice(0,80), href: href.slice(0,160), x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height), above_fold: aboveFold, is_cta: isCta, disabled: !!el.disabled || el.getAttribute('aria-disabled') === 'true', target: el.getAttribute('target')};
    });
  const ctas = interactive.filter(x => x.is_cta);
  const ctasInFold = ctas.filter(x => x.above_fold);
  const forms = [...document.querySelectorAll('form')].filter(visible).map(form => {
    const fields = [...form.querySelectorAll('input,textarea,select')].filter(visible).map(el => ({selector: selectorOf(el), type: el.getAttribute('type') || el.tagName.toLowerCase(), name: el.getAttribute('name') || '', label: textOf(el.labels?.[0] || el).slice(0,80), required: !!el.required || el.getAttribute('aria-required') === 'true', placeholder: el.getAttribute('placeholder') || ''}));
    const submit = [...form.querySelectorAll('button,input[type=submit],[role=button]')].find(visible);
    const r = form.getBoundingClientRect();
    return {selector: selectorOf(form), field_count: fields.length, fields, submit_text: submit ? textOf(submit).slice(0,80) : null, submit_selector: submit ? selectorOf(submit) : null, above_fold: r.top < fold};
  });
  const orphanFields = [...document.querySelectorAll('input,textarea,select')].filter(el => visible(el) && !el.closest('form')).map(el => ({selector: selectorOf(el), type: el.getAttribute('type') || el.tagName.toLowerCase(), name: el.getAttribute('name') || '', placeholder: el.getAttribute('placeholder') || '', required: !!el.required || el.getAttribute('aria-required') === 'true'}));
  const overlays = [...document.querySelectorAll('body *')].filter(visible).map(el => ({el, r: el.getBoundingClientRect(), cs: getComputedStyle(el)})).filter(o => ['fixed','sticky'].includes(o.cs.position) && o.r.width > vw * .5 && o.r.height > 50 && (o.r.top < fold || o.r.bottom > fold - 120)).slice(0,10).map(o => ({selector: selectorOf(o.el), text: textOf(o.el).slice(0,100), position: o.cs.position, x: Math.round(o.r.x), y: Math.round(o.r.y), w: Math.round(o.r.width), h: Math.round(o.r.height)}));
  const trustText = (document.body.innerText || '').toLowerCase();
  const trustSignals = ['testimonial','review','reviews','case study','customers','trusted','guarantee','secure','ssl','refund','privacy','rating','stars'].filter(t => trustText.includes(t));
  const findings = [];
  const add = (severity, title, impact, fix, evidence, selector=null) => findings.push({severity,title,category:'conversion',impact,fix,evidence,selector});
  if (!ctas.length) add('critical','No clear conversion CTA found','Users may not know how to buy, sign up, or contact you.','Add one primary CTA above the fold and repeat it near key sections.', {ctas_found:0});
  else if (!ctasInFold.length) add('high','No primary CTA above the fold','Mobile/first-time visitors may leave before reaching the next step.','Move the main CTA into the hero/header area and make it visually dominant.', {ctas_found:ctas.length, first_cta:ctas[0]}, ctas[0]?.selector);
  for (const c of ctas.filter(c => (c.tag === 'a' && badHrefRe.test(c.href)) || c.disabled).slice(0,5)) add('critical','Important CTA appears broken or disabled','A revenue action may not be completable.', 'Connect the CTA to a real destination/action and verify it after deploy.', c, c.selector);
  for (const c of ctas.filter(c => c.target === '_blank' && !/noopener/.test(String(document.querySelector(c.selector)?.rel || ''))).slice(0,3)) add('medium','CTA opens new tab without noopener','Small trust/security issue on outbound CTAs.','Add rel="noopener noreferrer" to target=_blank links.', c, c.selector);
  if (!forms.length && orphanFields.length) add('high','Fields exist outside a form','Lead capture may rely on fragile JavaScript and can be missed by standard browser submit behavior.','Ensure the SPA submit handler is tested and shows a clear success/error message.', {orphan_fields: orphanFields.slice(0,5)}, orphanFields[0]?.selector);
  for (const f of forms) {
    if (!f.submit_selector) add('critical','Form has no visible submit button','Users can fill fields but may not be able to send the lead/order.','Add a clear submit button with a conversion-oriented label.', f, f.selector);
    const hasContact = f.fields.some(x => /email|tel|phone/.test(`${x.type} ${x.name} ${x.placeholder}`.toLowerCase()));
    if (!hasContact && f.field_count >= 2) add('high','Lead form may not collect email/phone','The business may receive incomplete leads that cannot be followed up.','Add a required email or phone field.', f, f.selector);
  }
  if (overlays.length && ctasInFold.length) add('medium','Sticky/fixed overlay may compete with CTAs','Cookie/chat/sticky bars can cover or distract from the primary action, especially on mobile.','Verify overlay does not cover CTA/form at mobile widths.', {overlays: overlays.slice(0,3), ctas_in_fold: ctasInFold.slice(0,3)}, overlays[0]?.selector);
  if (!trustSignals.length && (ctas.length || forms.length)) add('medium','No obvious trust signals detected','Users may hesitate before submitting contact/payment info.','Add testimonials, reviews, guarantees, security/privacy notes, or customer logos near the CTA.', {trust_signals: []});
  return {page:{url: location.href, title: document.title, viewport:{width:vw,height:fold}}, summary:{ctas:ctas.length, ctas_above_fold:ctasInFold.length, forms:forms.length, orphan_fields:orphanFields.length, overlays:overlays.length, trust_signals:trustSignals.length, findings:findings.length, by_severity: findings.reduce((a,f)=>{a[f.severity]=(a[f.severity]||0)+1; return a;},{})}, ctas: ctas.slice(0,20), forms: forms.slice(0,10), orphan_fields: orphanFields.slice(0,20), overlays, trust_signals: trustSignals, findings};
}
"""


async def qa_conversion_audit(mgr: SessionManager, session_id: str,
                              detail: str = "samples") -> dict[str, Any]:
    """Audit revenue/lead-loss blockers: CTAs, lead forms, broken conversion
    links, mobile-above-the-fold CTA presence, overlays, and trust signals.

    This is deliberately business-facing: findings explain why an issue can
    cost signups/leads/sales, not just the technical defect.
    """
    s = mgr.get(session_id)
    await _wait_for_content(s.page)
    result = await s.page.evaluate(_CONVERSION_AUDIT_JS)
    await training_data.capture(mgr, session_id, "conversion", result)
    return _trim_for_detail(result, detail)


async def qa_a11y_audit(mgr: SessionManager, session_id: str,
                        min_impact: str | None = None,
                        detail: str = "samples") -> dict[str, Any]:
    """Accessibility audit via axe-core. WCAG 2 A/AA + best-practice.

    `min_impact` (optional): filter violations below this level.
    Choices: 'minor' < 'moderate' < 'serious' < 'critical'.
    Default None = return everything. Use 'serious' to focus triage on what
    actually breaks users.
    """
    s = mgr.get(session_id)
    await _wait_for_content(s.page)
    try:
        result = await s.page.evaluate(_AXE_INJECTION)
    except Exception as e:
        return {"error": f"axe-core injection failed (no internet?): {e}"}

    if min_impact:
        threshold = _IMPACT_RANK.get(min_impact.lower())
        if threshold is None:
            return {**result, "filter_error": f"unknown min_impact '{min_impact}'. "
                                              f"Choices: {list(_IMPACT_RANK)}"}
        violations = result.get("violations", [])
        filtered = [v for v in violations
                    if _IMPACT_RANK.get((v.get("impact") or "minor").lower(), 0) >= threshold]
        result["violations"] = filtered
        result["summary"]["total"] = len(filtered)
        result["summary"]["by_impact"] = {}
        for v in filtered:
            k = v.get("impact") or "unknown"
            result["summary"]["by_impact"][k] = result["summary"]["by_impact"].get(k, 0) + 1
        result["filter_applied"] = {"min_impact": min_impact}
    await training_data.capture(mgr, session_id, "a11y", result)
    return _trim_for_detail(result, detail)


# Battery of fuzz inputs ordered by risk
FUZZ_INPUTS_QUICK = [
    ("invalid_format", "abc"),
    ("empty", ""),
    ("whitespace", "   "),
    ("very_long", "x" * 250),
    ("emoji_unicode", "test✨🔥ñü@example.com"),
]
FUZZ_INPUTS_THOROUGH = FUZZ_INPUTS_QUICK + [
    ("hebrew_in_email", "test@דוגמה.com"),
    ("sql_ish", "' OR 1=1 --"),
    ("xss_attempt", "<script>alert(1)</script>"),
    ("zero_width", "​test@x.com"),
    ("rtl_mark", "‏test@x.com"),
    ("very_long_2", "a" * 2000),
    ("control_chars", "a\x00b\x07c"),
    ("newline", "line1\nline2@x.com"),
]


async def qa_fuzz_input(mgr: SessionManager, session_id: str, index: int,
                        depth: str = "quick") -> dict[str, Any]:
    s = mgr.get(session_id)
    selector = f'[data-qa-mcp-idx="{index}"]'
    inputs = FUZZ_INPUTS_QUICK if depth != "thorough" else FUZZ_INPUTS_THOROUGH
    results = []
    pre_logs = len(s.logs)

    for label, payload in inputs:
        entry = {"label": label, "input": payload[:80]}
        try:
            await s.page.fill(selector, "", timeout=3000)
            await s.page.fill(selector, payload, timeout=3000)
            await s.page.wait_for_timeout(120)
            try:
                value_now = await s.page.eval_on_selector(
                    selector, "el => el.value !== undefined ? el.value : el.innerText"
                )
                entry["accepted_value"] = (value_now or "")[:120]
            except Exception:
                entry["accepted_value"] = None
            try:
                validity = await s.page.eval_on_selector(selector, """
                    el => ({
                        invalid: el.matches(':invalid'),
                        validationMessage: el.validationMessage || null,
                        ariaInvalid: el.getAttribute('aria-invalid'),
                    })
                """)
                entry["validity"] = validity
            except Exception:
                entry["validity"] = None
        except Exception as e:
            entry["error"] = f"{type(e).__name__}: {e}"
        results.append(entry)

    new_logs = [e.to_dict() for e in s.logs[pre_logs:]]
    return {
        "index": index,
        "depth": depth,
        "results": results,
        "browser_events_during_fuzz": new_logs,
    }


# ---------- Visual regression ----------


def _resolve_baseline_dir(baselines_dir: str | None) -> Path:
    """Resolve which directory to use for baselines.

    Precedence: per-call arg > QA_MCP_BASELINE_DIR env > ~/.qa-mcp/baselines.
    Per-call lets CI mount a shared volume or per-PR sub-folder without
    relying on env at process start.
    """
    if baselines_dir:
        p = Path(baselines_dir).expanduser()
        p.mkdir(parents=True, exist_ok=True)
        return p
    _BASELINE_DIR.mkdir(parents=True, exist_ok=True)
    return _BASELINE_DIR


async def qa_baseline_save(mgr: SessionManager, session_id: str,
                           name: str, full_page: bool = True,
                           baselines_dir: str | None = None) -> dict[str, Any]:
    """Save the current page as a named baseline.

    Writes two files for git-friendliness:
      - <name>.png         (the image)
      - <name>.meta.json   (sidecar with hash, viewport, url, timestamp)

    The .meta.json is small + diff-able, so PR reviewers can see what
    changed (viewport, URL) without git showing a binary diff. `baselines_dir`
    overrides storage path (or QA_MCP_BASELINE_DIR env)."""
    import json as _json
    s = mgr.get(session_id)
    safe = _safe_name(name)
    base_dir = _resolve_baseline_dir(baselines_dir)
    out = base_dir / f"{safe}.png"
    meta_path = base_dir / f"{safe}.meta.json"
    raw = await s.page.screenshot(type="png", full_page=full_page)
    out.write_bytes(raw)
    meta = {
        "name": safe,
        "url": s.page.url,
        "title": await s.page.title(),
        "viewport": s.page.viewport_size,
        "full_page": full_page,
        "size_bytes": len(raw),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "browser": s.browser_engine,
    }
    meta_path.write_text(_json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")
    return {
        "saved": True,
        "name": safe,
        "path": str(out),
        "meta_path": str(meta_path),
        "baselines_dir": str(base_dir),
        "size_bytes": len(raw),
        "sha256": meta["sha256"],
        "url_at_save": s.page.url,
        "created_at": meta["created_at"],
    }


async def qa_baseline_compare(mgr: SessionManager, session_id: str, name: str,
                              full_page: bool = True,
                              tolerance_pct: float = 0.5,
                              baselines_dir: str | None = None) -> dict[str, Any]:
    """Compare current page screenshot to a saved baseline.

    Returns the % of changed pixels, a diff image path, and whether the diff
    exceeds `tolerance_pct` (default 0.5%). For perfect match → 0% changed.

    Pass `baselines_dir` to override storage location (must match the dir
    used in qa_baseline_save).
    """
    from PIL import Image, ImageChops
    s = mgr.get(session_id)
    safe = _safe_name(name)
    base_dir = _resolve_baseline_dir(baselines_dir)
    baseline_path = base_dir / f"{safe}.png"
    if not baseline_path.exists():
        return {
            "ok": False,
            "error": f"baseline '{safe}' not found at {baseline_path}. "
                     f"Run qa_baseline_save first.",
        }

    raw_now = await s.page.screenshot(type="png", full_page=full_page)
    diffs_dir = base_dir / "_diffs"
    diffs_dir.mkdir(exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    current_path = diffs_dir / f"{safe}_{ts}_current.png"
    diff_path = diffs_dir / f"{safe}_{ts}_diff.png"
    current_path.write_bytes(raw_now)

    base_img = Image.open(baseline_path).convert("RGB")
    cur_img = Image.open(current_path).convert("RGB")

    # Resize current to baseline size if mismatched (viewport differences)
    size_mismatch = base_img.size != cur_img.size
    if size_mismatch:
        cur_img_resized = cur_img.resize(base_img.size)
    else:
        cur_img_resized = cur_img

    diff_img = ImageChops.difference(base_img, cur_img_resized)
    bbox = diff_img.getbbox()  # bounding box of changed region, or None

    # Pixel-level: count pixels that differ
    total_pixels = base_img.size[0] * base_img.size[1]
    changed_pixels = 0
    if bbox:
        diff_img.save(diff_path)
        # Heuristic: any pixel with diff sum > 30 is "changed"
        for r, g, b in diff_img.getdata():
            if r + g + b > 30:
                changed_pixels += 1

    pct_changed = (changed_pixels / total_pixels * 100) if total_pixels else 0
    passed = pct_changed <= tolerance_pct and not size_mismatch

    return {
        "ok": True,
        "name": safe,
        "passed": passed,
        "pct_changed": round(pct_changed, 3),
        "tolerance_pct": tolerance_pct,
        "size_mismatch": size_mismatch,
        "baseline_size": list(base_img.size),
        "current_size": list(cur_img.size),
        "changed_region": list(bbox) if bbox else None,
        "baseline_path": str(baseline_path),
        "current_path": str(current_path),
        "diff_path": str(diff_path) if bbox else None,
        "url_now": s.page.url,
    }


def qa_baseline_list(baselines_dir: str | None = None) -> dict[str, Any]:
    """List all saved baselines. Pass `baselines_dir` to list a specific
    directory; otherwise uses the default."""
    base_dir = _resolve_baseline_dir(baselines_dir)
    items = []
    for p in sorted(base_dir.glob("*.png")):
        items.append({
            "name": p.stem,
            "path": str(p),
            "size_bytes": p.stat().st_size,
            "modified": datetime.fromtimestamp(p.stat().st_mtime).isoformat(timespec="seconds"),
        })
    return {"count": len(items), "baselines": items, "dir": str(base_dir)}


# ---------- SEO check ----------


_SEO_SCRIPT = r"""
() => {
  const meta = {};
  document.querySelectorAll('meta').forEach(m => {
    const k = m.getAttribute('name') || m.getAttribute('property') || m.getAttribute('http-equiv');
    if (k) meta[k] = m.getAttribute('content') || '';
  });
  const og = Object.fromEntries(Object.entries(meta).filter(([k]) => k.startsWith('og:')));
  const tw = Object.fromEntries(Object.entries(meta).filter(([k]) => k.startsWith('twitter:')));
  const schema = Array.from(document.querySelectorAll('script[type="application/ld+json"]'))
    .map(s => { try { return JSON.parse(s.textContent); } catch { return null; } })
    .filter(Boolean);
  const headings = {};
  for (let h = 1; h <= 6; h++) {
    headings[`h${h}_count`] = document.querySelectorAll(`h${h}`).length;
  }
  // Image counting — covers <img>, <picture>/<source>, inline <svg>, and
  // CSS background-image. Earlier version only counted <img> and reported
  // 0 on pages that use modern images.
  const imgTags = Array.from(document.querySelectorAll('img'));
  const altMissing = imgTags.filter(i => !i.alt && !i.getAttribute('aria-label')).length;
  const pictures = document.querySelectorAll('picture').length;
  const inlineSvgs = document.querySelectorAll('svg').length;
  // background-image scan: only on visible block-level elements (cap at 200
  // checks so it doesn't go quadratic on huge DOMs).
  let bgImages = 0;
  const visible = Array.from(document.querySelectorAll('body *')).slice(0, 5000);
  for (const el of visible) {
    if (bgImages >= 200) break;
    const cs = getComputedStyle(el);
    if (cs.backgroundImage && cs.backgroundImage !== 'none' &&
        !cs.backgroundImage.includes('linear-gradient') &&
        !cs.backgroundImage.includes('radial-gradient')) {
      bgImages++;
    }
  }
  const link = (rel) => document.querySelector(`link[rel="${rel}"]`)?.href || null;

  const issues = [];
  if (!document.title) issues.push({ severity: 'high', msg: 'Missing <title>' });
  if (!meta['description']) issues.push({ severity: 'high', msg: 'Missing meta description' });
  if (headings.h1_count === 0) issues.push({ severity: 'high', msg: 'No <h1>' });
  if (headings.h1_count > 1) issues.push({ severity: 'medium', msg: `Multiple <h1> (${headings.h1_count})` });
  if (!document.documentElement.lang) issues.push({ severity: 'medium', msg: 'Missing <html lang>' });
  if (altMissing > 0) issues.push({ severity: 'medium', msg: `${altMissing}/${imgTags.length} <img> tags missing alt` });
  if (!og['og:title']) issues.push({ severity: 'low', msg: 'Missing og:title' });
  if (!og['og:image']) issues.push({ severity: 'low', msg: 'Missing og:image' });
  if (!link('canonical')) issues.push({ severity: 'low', msg: 'Missing canonical link' });

  return {
    page: {
      url: location.href,
      title: document.title,
      lang: document.documentElement.lang || null,
      description: meta['description'] || null,
      canonical: link('canonical'),
      robots: meta['robots'] || null,
    },
    open_graph: og,
    twitter_card: tw,
    schema_org: schema,
    headings,
    images: {
      img_tags: imgTags.length,
      alt_missing: altMissing,
      picture_elements: pictures,
      inline_svg: inlineSvgs,
      css_background_images: bgImages,
      total_visual_assets: imgTags.length + inlineSvgs + bgImages,
    },
    issues,
    summary: { total_issues: issues.length },
  };
}
"""


async def qa_seo_check(mgr: SessionManager, session_id: str,
                       detail: str = "samples") -> dict[str, Any]:
    """SEO health check: meta tags, Open Graph, Twitter card, JSON-LD schema,
    heading hierarchy, alt-text coverage, canonical, lang. Returns structured
    findings + an `issues` array for quick triage."""
    s = mgr.get(session_id)
    await _wait_for_content(s.page)
    result = await s.page.evaluate(_SEO_SCRIPT)
    await training_data.capture(mgr, session_id, "seo", result)
    return _trim_for_detail(result, detail)


# ---------- Discovery helpers (cheap lookups that save evaluate() roundtrips) ----------


_FIND_TEXT_JS = r"""
({query, fuzzy, max_results, case_sensitive}) => {
  // Mark every interactive-ish element with an idx attr (idempotent — the
  // browser_get_state tool uses the same convention so indices stay stable).
  const SEL = 'a,button,input,textarea,select,[role="button"],[role="link"],'
            + '[role="tab"],[role="menuitem"],[contenteditable=""],[contenteditable="true"]';
  let nodes = Array.from(document.querySelectorAll(SEL));

  // Fallback: text might live in a non-interactive element (h1, p, span).
  // Include text-bearing block elements too, capped to keep it sane.
  const TEXTSEL = 'h1,h2,h3,h4,h5,h6,p,li,td,th,label,figcaption,strong,em,span,div';
  nodes = nodes.concat(Array.from(document.querySelectorAll(TEXTSEL)).slice(0, 500));

  const seen = new Set();
  nodes = nodes.filter(n => { if (seen.has(n)) return false; seen.add(n); return true; });

  const norm = s => (s || '').replace(/\s+/g, ' ').trim();
  const target = case_sensitive ? norm(query) : norm(query).toLowerCase();
  const tokens = target.split(' ').filter(Boolean);

  const matches = [];
  for (const el of nodes) {
    const raw = norm(el.innerText || el.textContent || el.value || el.placeholder || '');
    if (!raw) continue;
    const hay = case_sensitive ? raw : raw.toLowerCase();
    let hit = false;
    if (hay.includes(target)) {
      hit = true;
    } else if (fuzzy && tokens.length > 1) {
      hit = tokens.every(t => hay.includes(t));
    }
    if (!hit) continue;

    // Stable per-page idx attr so the result is usable without get_state
    let idx = el.getAttribute('data-qa-mcp-idx');
    if (idx === null) {
      idx = String(window.__qaMcpIdx = (window.__qaMcpIdx || 0) + 1);
      el.setAttribute('data-qa-mcp-idx', idx);
    }
    const rect = el.getBoundingClientRect();
    const visible = rect.width > 0 && rect.height > 0 &&
                    window.getComputedStyle(el).visibility !== 'hidden' &&
                    window.getComputedStyle(el).display !== 'none';
    matches.push({
      index: parseInt(idx),
      tag: el.tagName.toLowerCase(),
      role: el.getAttribute('role') || null,
      text: raw.slice(0, 160),
      href: el.getAttribute('href') || null,
      visible,
      bbox: visible ? {x: Math.round(rect.x), y: Math.round(rect.y),
                       w: Math.round(rect.width), h: Math.round(rect.height)} : null,
    });
    if (matches.length >= max_results) break;
  }
  return {query, fuzzy, case_sensitive, matches, total_found: matches.length};
}
"""


async def qa_find_text(mgr: SessionManager, session_id: str, query: str,
                       fuzzy: bool = True, max_results: int = 10,
                       case_sensitive: bool = False) -> dict[str, Any]:
    """Find DOM elements containing `query` text. Returns a list of matches,
    each with a stable `index` you can pass straight to browser_click /
    browser_type / browser_scroll_to.

    fuzzy=True (default): if `query` has multiple tokens, an element matches
    when ALL tokens appear in any order (good for "submit form" matching
    "Submit the form"). Substring match still wins first.
    """
    s = mgr.get(session_id)
    await _wait_for_content(s.page)
    return await s.page.evaluate(_FIND_TEXT_JS, {
        "query": query,
        "fuzzy": fuzzy,
        "max_results": max_results,
        "case_sensitive": case_sensitive,
    })


_FORM_INVENTORY_JS = r"""
() => {
  const guess_purpose = (el) => {
    const hints = [
      el.name, el.id, el.placeholder, el.getAttribute('autocomplete'),
      el.getAttribute('aria-label'),
      // label[for=id] or wrapping label
      (el.id && document.querySelector(`label[for="${el.id}"]`)?.innerText) || '',
      el.closest('label')?.innerText || '',
    ].join(' ').toLowerCase();
    if (/email|דוא|אימייל/.test(hints)) return 'email';
    if (/password|סיסמ/.test(hints)) return 'password';
    if (/phone|tel|נייד|טלפון/.test(hints)) return 'phone';
    if (/first.?name|שם.?פרטי/.test(hints)) return 'first_name';
    if (/last.?name|family|שם.?משפחה/.test(hints)) return 'last_name';
    if (/full.?name|^name|שם/.test(hints)) return 'name';
    if (/company|חברה|עסק/.test(hints)) return 'company';
    if (/address|כתובת/.test(hints)) return 'address';
    if (/city|עיר/.test(hints)) return 'city';
    if (/zip|postal|מיקוד/.test(hints)) return 'zip';
    if (/id.?number|ת\.?ז|תעודת/.test(hints)) return 'israeli_id';
    if (/card.?num|cc.?num|כרטיס/.test(hints)) return 'credit_card';
    if (/cvc|cvv/.test(hints)) return 'credit_card_cvc';
    if (/exp|תוקף/.test(hints)) return 'credit_card_exp';
    if (/message|comment|הודעה|תוכן/.test(hints)) return 'message';
    if (/subject|נושא/.test(hints)) return 'subject';
    return null;
  };

  const inspect_field = (el, idx) => {
    let stableIdx = el.getAttribute('data-qa-mcp-idx');
    if (stableIdx === null) {
      stableIdx = String(window.__qaMcpIdx = (window.__qaMcpIdx || 0) + 1);
      el.setAttribute('data-qa-mcp-idx', stableIdx);
    }
    const labelEl = (el.id && document.querySelector(`label[for="${el.id}"]`))
                    || el.closest('label');
    return {
      index: parseInt(stableIdx),
      tag: el.tagName.toLowerCase(),
      type: el.type || null,
      name: el.name || null,
      id: el.id || null,
      placeholder: el.placeholder || null,
      autocomplete: el.getAttribute('autocomplete') || null,
      label: labelEl ? (labelEl.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 80) : null,
      required: el.required || el.getAttribute('aria-required') === 'true',
      readonly: el.readOnly || el.disabled,
      maxlength: el.maxLength > 0 ? el.maxLength : null,
      pattern: el.pattern || null,
      purpose: guess_purpose(el),
    };
  };

  const FIELD_SEL = 'input:not([type="hidden"]):not([type="submit"]):not([type="button"]),'
                  + 'textarea, select, [contenteditable="true"]';

  const score_submit = (el) => {
    const text = [el.innerText, el.value, el.name, el.id, el.getAttribute('aria-label')].join(' ').toLowerCase();
    let score = 0;
    if (/continue|submit|send|login|log in|sign in|checkout|finish|order|place order|next|שלח|שליחה|המשך|התחבר|כניסה|הרשמה|לתשלום/.test(text)) score += 100;
    if (/cancel|back|reset|clear|remove|delete|close|ביטול|חזור|איפוס|מחק|סגור/.test(text)) score -= 100;
    if ((el.type || '').toLowerCase() === 'submit') score += 20;
    if (el.disabled || el.getAttribute('aria-disabled') === 'true') score -= 1000;
    return score;
  };

  const forms = Array.from(document.querySelectorAll('form'));
  const inventory = forms.map((form, i) => {
    const fields = Array.from(form.querySelectorAll(FIELD_SEL)).map(inspect_field);
    const submits = Array.from(form.querySelectorAll('button, input[type="submit"], input[type="button"], [role="button"]'));
    const submit = submits.sort((a, b) => score_submit(b) - score_submit(a))[0] || null;
    let submitIdx = null;
    let submitText = null;
    if (submit && score_submit(submit) > -50) {
      let sIdx = submit.getAttribute('data-qa-mcp-idx');
      if (sIdx === null) {
        sIdx = String(window.__qaMcpIdx = (window.__qaMcpIdx || 0) + 1);
        submit.setAttribute('data-qa-mcp-idx', sIdx);
      }
      submitIdx = parseInt(sIdx);
      submitText = (submit.innerText || submit.value || submit.getAttribute('aria-label') || '').trim();
    }
    return {
      form_index: i,
      action: form.action || null,
      method: (form.method || 'get').toUpperCase(),
      name: form.getAttribute('name') || form.id || null,
      field_count: fields.length,
      submit_index: submitIdx,
      submit_text: submitText,
      fields,
    };
  });

  // Also catch fields outside <form> tags (common with React/SPA frameworks)
  const allFields = Array.from(document.querySelectorAll(FIELD_SEL));
  const inFormFields = new Set();
  forms.forEach(f => f.querySelectorAll(FIELD_SEL).forEach(el => inFormFields.add(el)));
  const orphanFields = allFields
    .filter(el => !inFormFields.has(el))
    .map(inspect_field);

  return {
    forms,
    forms_count: forms.length,
    fields_in_forms: inventory.reduce((a, f) => a + f.field_count, 0),
    orphan_fields: orphanFields,
    orphan_fields_count: orphanFields.length,
    inventory,
  };
}
"""


async def qa_form_inventory(mgr: SessionManager, session_id: str) -> dict[str, Any]:
    """List every form on the page with its fields, types, labels, and a
    guessed `purpose` (email/password/phone/etc). Use this BEFORE
    qa_form_smart_fill to know what's there and pick the right intent.

    Returns:
      { forms_count, fields_in_forms, orphan_fields_count,
        inventory: [{form_index, action, method, name, field_count,
                     submit_index, fields: [{index, type, name, label,
                                             required, purpose, ...}]}],
        orphan_fields: [...] }  // fields outside any <form>, common in SPAs
    """
    s = mgr.get(session_id)
    await _wait_for_content(s.page)
    result = await s.page.evaluate(_FORM_INVENTORY_JS)
    # Drop the raw 'forms' element list (Playwright will JSON-fail on DOM nodes)
    if isinstance(result, dict):
        result.pop("forms", None)
    return result


# ---------- Smart form fill ----------


# Synthetic data per intent; each dict maps field-purpose → value.
# Israeli-specific values use real-looking but fake check-digit-valid samples.
_FORM_DATA = {
    "valid_signup": {
        "email": "qa.test+{rand}@example.com",
        "password": "QaTest{rand}!23",
        "name": "QA Test User",
        "first_name": "QA",
        "last_name": "Tester",
        "phone": "0501234567",
        "israeli_id": "123456782",  # valid check digit
        "company": "BrainboxAI Test",
        "address": "Rothschild 1, Tel Aviv",
        "city": "Tel Aviv",
        "zip": "6688101",
        "country": "Israel",
        "credit_card": "4242424242424242",  # Stripe test card
        "credit_card_cvc": "123",
        "credit_card_exp": "12/30",
    },
    "valid_login": {
        # Login flows usually only have email+password, sometimes username
        "email": "qa.test+{rand}@example.com",
        "password": "QaTest{rand}!23",
        "name": "qatest{rand}",  # username field
    },
    "invalid_email": {
        "email": "not-an-email",
        "password": "QaTest!23",
    },
    "very_long": {
        "email": "x" * 200 + "@example.com",
        "password": "y" * 200,
        "name": "z" * 200,
        "first_name": "a" * 200,
        "last_name": "b" * 200,
    },
    "empty": {"email": "", "password": "", "name": "", "first_name": "", "last_name": ""},
    "hebrew": {
        "email": "בודק@דוגמה.co.il",
        "password": "סיסמה123!",
        "name": "ישראל ישראלי",
        "first_name": "ישראל",
        "last_name": "ישראלי",
        "phone": "0501234567",
        "company": "ברינבוקס AI בע\"מ",
        "address": "רוטשילד 1, תל אביב",
        "city": "תל אביב",
    },
    "israeli_realistic": {
        "email": "yossi.cohen.{rand}@gmail.com",
        "password": "Yossi2024!",
        "name": "יוסי כהן",
        "first_name": "יוסי",
        "last_name": "כהן",
        "phone": "0521234567",
        "israeli_id": "123456782",
        "address": "דיזנגוף 100, תל אביב",
        "city": "תל אביב",
        "zip": "6433222",
    },
    "stripe_test_card": {
        # Useful for testing checkout flows without real charges.
        "credit_card": "4242424242424242",
        "credit_card_cvc": "123",
        "credit_card_exp": "12/30",
        "credit_card_name": "QA Tester",
    },
}


def _detect_field_purpose(el: dict) -> str | None:
    """Map an element dict (from get_state) to a synthetic-data key."""
    blobs = " ".join([
        (el.get("type") or ""),
        (el.get("name") or ""),
        (el.get("id") or ""),
        (el.get("placeholder") or ""),
        (el.get("text") or ""),
    ]).lower()
    rules = [
        ("email", ["email", "אימייל", "מייל", "@"]),
        ("password", ["password", "passwd", "pwd", "סיסמה"]),
        # Credit card BEFORE generic name/number to avoid false positives
        ("credit_card_cvc", ["cvc", "cvv", "security code", "קוד אבטחה"]),
        ("credit_card_exp", ["exp", "expiry", "expiration", "תפוגה"]),
        ("credit_card_name", ["card name", "cardholder", "שם בעל הכרטיס"]),
        ("credit_card", ["card number", "credit card", "card num", "ccnumber", "מספר כרטיס"]),
        ("israeli_id", ["israeli id", "תעודת זהות", "ת.ז", "id_number", "national_id", "תז", "ת״ז"]),
        ("first_name", ["firstname", "first_name", "fname", "given", "שם פרטי"]),
        ("last_name", ["lastname", "last_name", "lname", "surname", "family", "שם משפחה"]),
        ("name", ["name", "fullname", "full_name", "שם", "username", "שם משתמש"]),
        ("phone", ["phone", "tel", "mobile", "טלפון", "נייד"]),
        ("company", ["company", "organization", "org", "חברה"]),
        ("address", ["address", "street", "כתובת"]),
        ("city", ["city", "עיר"]),
        ("zip", ["zip", "postal", "מיקוד"]),
        ("country", ["country", "מדינה", "ארץ"]),
    ]
    for key, kws in rules:
        if any(kw in blobs for kw in kws):
            return key
    return None


async def qa_responsive_audit(mgr: SessionManager, session_id: str,
                              breakpoints: list[int] | None = None,
                              audits: list[str] | None = None,
                              ) -> dict[str, Any]:
    """Run audits at multiple viewport widths in one call.

    `breakpoints`: list of widths (default [375, 768, 1366] = mobile/tablet/desktop).
        Heights derived: 667 for ≤500, 1024 for ≤900, 768 for the rest.
    `audits`: which audits to run at each width — any of
        ["rtl", "a11y", "perf", "seo", "links", "ux"]. Default ["rtl", "a11y"].

    Returns:
        { "results": { 375: {...}, 768: {...}, 1366: {...} },
          "deltas": [findings that appear at one width but not another] }
    """
    from .browser_tools import browser_set_viewport
    s = mgr.get(session_id)
    breakpoints = breakpoints or [375, 768, 1366]
    audits = audits or ["rtl", "a11y"]
    audit_map = {
        "rtl": qa_rtl_audit,
        "a11y": qa_a11y_audit,
        "perf": qa_perf_metrics,
        "seo": qa_seo_check,
        "links": qa_scan_links,
        "ux": qa_ux_metrics,
    }
    results: dict[int, dict] = {}
    for w in breakpoints:
        h = 667 if w <= 500 else (1024 if w <= 900 else 768)
        await browser_set_viewport(mgr, session_id, width=w, height=h)
        # Settle layout briefly after viewport change
        await s.page.wait_for_timeout(200)
        per_width: dict[str, Any] = {"viewport": {"width": w, "height": h}}
        for a in audits:
            fn = audit_map.get(a)
            if not fn:
                per_width[a] = {"error": f"unknown audit '{a}'"}
                continue
            try:
                per_width[a] = await fn(mgr, session_id)
            except Exception as e:
                per_width[a] = {"error": f"{type(e).__name__}: {e}"}
        results[w] = per_width

    # Compute deltas — findings that appear at some breakpoints but not others.
    deltas: list[dict] = []
    for a in audits:
        if a not in ("rtl", "a11y"):
            continue
        # Build set of finding signatures per breakpoint
        sig_map: dict[int, set] = {}
        for w in breakpoints:
            findings = (results[w].get(a) or {}).get("findings") or \
                       (results[w].get(a) or {}).get("violations") or []
            sig_map[w] = {
                f"{f.get('category', f.get('id', ''))}::{(f.get('sample') or f.get('description') or '')[:60]}"
                for f in findings
            }
        # Findings unique to each width
        for w in breakpoints:
            others = set().union(*(sig_map[ow] for ow in breakpoints if ow != w))
            unique_to_w = sig_map[w] - others
            for sig in unique_to_w:
                deltas.append({"audit": a, "viewport": w, "finding": sig,
                               "kind": "appears_only_at_this_viewport"})
    return {
        "results": {str(w): v for w, v in results.items()},
        "breakpoints": breakpoints,
        "audits_run": audits,
        "deltas": deltas,
        "summary": {
            "total_findings_per_breakpoint": {
                str(w): sum(
                    len((results[w].get(a) or {}).get("findings", []) or
                        (results[w].get(a) or {}).get("violations", []))
                    for a in audits
                )
                for w in breakpoints
            },
            "viewport_specific_findings": len(deltas),
        },
    }


async def qa_form_smart_fill(mgr: SessionManager, session_id: str,
                             intent: str = "valid_signup",
                             submit: bool = False) -> dict[str, Any]:
    """Detect form fields on the page and fill them with synthetic data
    matched to `intent`. Optionally submits.

    Intents: 'valid_signup', 'invalid_email', 'very_long', 'empty', 'hebrew'.
    """
    if intent not in _FORM_DATA:
        return {"ok": False, "error": f"unknown intent. Choices: {list(_FORM_DATA)}"}

    s = mgr.get(session_id)
    # Get current state of inputs
    from .browser_tools import INDEX_INTERACTIVE_JS
    payload = await s.page.evaluate(INDEX_INTERACTIVE_JS, [0, {}])
    elements = payload.get("elements", []) if isinstance(payload, dict) else payload
    inputs = [e for e in elements
              if e["tag"] in ("input", "textarea")
              and e.get("type") not in ("submit", "button", "checkbox", "radio", "hidden", "file")]

    rand = datetime.now().strftime("%H%M%S")
    data = _FORM_DATA[intent]
    filled = []
    skipped = []

    for el in inputs:
        purpose = _detect_field_purpose(el)
        if not purpose or purpose not in data:
            skipped.append({"index": el["index"], "reason": "no_match",
                            "name": el.get("name"), "placeholder": el.get("placeholder")})
            continue
        value = data[purpose].format(rand=rand) if "{rand}" in data[purpose] else data[purpose]
        selector = f'[data-qa-mcp-idx="{el["index"]}"]'
        try:
            await s.page.fill(selector, value, timeout=3000)
            filled.append({"index": el["index"], "purpose": purpose, "value": value[:80]})
        except Exception as e:
            skipped.append({"index": el["index"], "reason": f"fill_failed: {e}"})

    submit_result = None
    if submit:
        submit_btn = next(
            (e for e in elements if e["tag"] == "button" and
             any(kw in (e.get("text") or "").lower()
                 for kw in ["submit", "sign up", "signup", "register", "send", "שלח", "הרשם", "הרשמה", "הצטרף"])),
            None,
        )
        if submit_btn:
            sel = f'[data-qa-mcp-idx="{submit_btn["index"]}"]'
            try:
                await s.page.click(sel, timeout=5000)
                submit_result = {"clicked": True, "index": submit_btn["index"]}
            except Exception as e:
                submit_result = {"clicked": False, "error": str(e)}
        else:
            submit_result = {"clicked": False, "error": "no submit button found"}

    return {
        "ok": True,
        "intent": intent,
        "filled": filled,
        "skipped": skipped,
        "summary": {"filled": len(filled), "skipped": len(skipped)},
        "submit_result": submit_result,
    }


async def qa_login_with_credentials(mgr: SessionManager, session_id: str,
                                    username: str, password: str,
                                    username_query: str | None = None,
                                    password_query: str | None = None,
                                    submit_query: str | None = None) -> dict[str, Any]:
    """Fill a login form using known credentials and submit it.

    This avoids qa_form_smart_fill's synthetic credentials for demo/test sites
    that publish fixed usernames/passwords (e.g. saucedemo). Selectors are
    optional; if omitted, fields are inferred from type/name/id/placeholder.
    """
    s = mgr.get(session_id)
    await _wait_for_content(s.page)
    before = s.page.url
    selectors = await s.page.evaluate(r"""
({username_query, password_query, submit_query}) => {
  const visible = el => { const r = el.getBoundingClientRect(); const cs = getComputedStyle(el); return r.width>0 && r.height>0 && cs.display !== 'none' && cs.visibility !== 'hidden'; };
  const css = el => {
    if (!el) return null;
    if (el.id) return '#' + CSS.escape(el.id);
    if (el.name) return `${el.tagName.toLowerCase()}[name="${CSS.escape(el.name)}"]`;
    return null;
  };
  const byQ = q => q ? document.querySelector(q) : null;
  const inputs = Array.from(document.querySelectorAll('input, textarea')).filter(visible);
  const user = byQ(username_query) || inputs.find(el => /email|user|login|name/i.test([el.name, el.id, el.placeholder, el.type].join(' ')) && el.type !== 'password') || inputs.find(el => el.type !== 'password');
  const pass = byQ(password_query) || inputs.find(el => el.type === 'password' || /password|pass|pwd/i.test([el.name, el.id, el.placeholder].join(' ')));
  const candidates = Array.from(document.querySelectorAll('button, input[type=submit], input[type=button], [role=button]')).filter(visible);
  const score = el => {
    const t = [el.innerText, el.value, el.name, el.id, el.getAttribute('aria-label')].join(' ').toLowerCase();
    let s = 0; if (/login|log in|sign in|submit|continue|כניסה|התחבר/.test(t)) s += 100; if (/cancel|back|reset/.test(t)) s -= 100; if ((el.type||'').toLowerCase()==='submit') s += 20; return s;
  };
  const submit = byQ(submit_query) || candidates.sort((a,b)=>score(b)-score(a))[0];
  return {user: username_query || css(user), pass: password_query || css(pass), submit: submit_query || css(submit), submit_text: submit ? (submit.innerText || submit.value || submit.id || '').trim() : null};
}
""", {"username_query": username_query, "password_query": password_query, "submit_query": submit_query})
    if not selectors.get("user") or not selectors.get("pass"):
        return {"ok": False, "before_url": before, "after_url": s.page.url, "error": "login fields not found", "selectors": selectors}
    await s.page.fill(selectors["user"], username, timeout=5000)
    await s.page.fill(selectors["pass"], password, timeout=5000)
    if not selectors.get("submit"):
        return {"ok": False, "before_url": before, "after_url": s.page.url, "error": "submit not found", "selectors": selectors}
    await s.page.click(selectors["submit"], timeout=5000)
    try:
        await s.page.wait_for_load_state("networkidle", timeout=5000)
    except Exception:
        pass
    try:
        await s.page.wait_for_timeout(250)
    except Exception:
        pass
    return {"ok": True, "before_url": before, "after_url": s.page.url, "clicked_text": selectors.get("submit_text"), "selectors": selectors}


async def qa_flow_runner(mgr: SessionManager, session_id: str,
                         steps: list[dict[str, Any]],
                         stop_on_error: bool = True) -> dict[str, Any]:
    """Run an explicit QA flow step-by-step.

    Supported actions: type, type_selector, click, click_text, click_selector,
    select, wait_text, assert_text, assert_url, logs, screenshot, get_state. UI-mutating steps are
    intentionally sequential to avoid race conditions.
    """
    from . import browser_tools
    results: list[dict[str, Any]] = []
    s = mgr.get(session_id)

    async def fail(i: int, step: dict, msg: str):
        rec = {"step": i, "action": step.get("action"), "ok": False, "error": msg, "step_input": step}
        results.append(rec)
        if stop_on_error:
            raise RuntimeError(msg)
        return rec

    for i, step in enumerate(steps, 1):
        action = step.get("action")
        try:
            if action == "type":
                idx = step.get("index")
                if idx is None and step.get("query"):
                    found = await qa_find_text(mgr, session_id, step["query"], max_results=1)
                    idx = found.get("matches", [{}])[0].get("index")
                if idx is None:
                    await fail(i, step, "missing index/query for type"); continue
                out = await browser_tools.browser_type(mgr, session_id, int(idx), str(step.get("text", "")), bool(step.get("clear", True)))
            elif action == "type_selector":
                await s.page.fill(step["selector"], str(step.get("text", "")), timeout=int(step.get("timeout_ms", 5000)))
                out = {"ok": True, "selector": step["selector"]}
            elif action == "click":
                out = await browser_tools.browser_click(mgr, session_id, int(step["index"]))
            elif action == "click_selector":
                await s.page.click(step["selector"], timeout=int(step.get("timeout_ms", 5000)))
                try:
                    await s.page.wait_for_load_state("networkidle", timeout=3000)
                except Exception:
                    pass
                out = {"ok": True, "selector": step["selector"], "url": s.page.url}
            elif action == "click_text":
                query = str(step["text"])
                found = await qa_find_text(mgr, session_id, query, max_results=1)
                matches = found.get("matches", [])
                idx = matches[0].get("index") if matches else None
                if idx is None:
                    # Fallback: browser_get_state sees input[type=submit] values
                    # and stable indices more reliably in some SPAs.
                    state = await browser_tools.browser_get_state(mgr, session_id, text_snapshot_chars=1000)
                    q = query.lower()
                    for el in state.get("elements", []):
                        blob = " ".join(str(el.get(k) or "") for k in ("text", "name", "id", "placeholder", "type")).lower()
                        if q in blob:
                            idx = el.get("index")
                            break
                if idx is None:
                    await fail(i, step, f"text not found: {step.get('text')}"); continue
                out = await browser_tools.browser_click(mgr, session_id, int(idx))
            elif action == "select":
                out = await browser_tools.browser_select_option(mgr, session_id, int(step["index"]), value=step.get("value"), label=step.get("label"), position=step.get("position"))
            elif action == "wait_text":
                out = await browser_tools.browser_wait_for(mgr, session_id, text=step["text"], timeout_ms=int(step.get("timeout_ms", 10000)))
            elif action == "assert_text":
                state = await browser_tools.browser_get_state(mgr, session_id, text_snapshot_chars=int(step.get("text_snapshot_chars", 4000)))
                ok = step["text"] in (state.get("text_snapshot") or "")
                out = {"ok": ok, "text": step["text"]}
                if not ok:
                    await fail(i, step, f"assert_text failed: {step['text']}"); continue
            elif action == "assert_url":
                import re
                pattern = step["pattern"]
                ok = re.search(pattern, s.page.url) is not None
                out = {"ok": ok, "url": s.page.url, "pattern": pattern}
                if not ok:
                    await fail(i, step, f"assert_url failed: {pattern} not in {s.page.url}"); continue
            elif action == "logs":
                out = await browser_tools.browser_logs(mgr, session_id, clear=bool(step.get("clear", False)))
            elif action == "screenshot":
                out = await browser_tools.browser_screenshot(mgr, session_id, full_page=bool(step.get("full_page", False)), save_to=step.get("save_to"))
            elif action == "get_state":
                out = await browser_tools.browser_get_state(mgr, session_id, text_snapshot_chars=int(step.get("text_snapshot_chars", 1500)))
            else:
                await fail(i, step, f"unknown action: {action}"); continue
            if isinstance(out, dict) and out.get("ok") is False:
                await fail(i, step, out.get("error") or f"{action} returned ok=false")
                continue
            results.append({"step": i, "action": action, "ok": True, "result": out})
        except Exception as e:
            if stop_on_error:
                return {"ok": False, "failed_step": i, "error": str(e), "steps": results, "url": s.page.url}
            results.append({"step": i, "action": action, "ok": False, "error": str(e)})
    return {"ok": all(r.get("ok", False) for r in results), "steps": results, "url": s.page.url}


async def qa_tech_stack_detect(mgr: SessionManager, session_id: str) -> dict[str, Any]:
    """Best-effort frontend/framework/UI library detection from DOM, scripts,
    styles, globals, and class names. Confidence is heuristic, never absolute."""
    s = mgr.get(session_id)
    await _wait_for_content(s.page)
    return await s.page.evaluate(r"""
() => {
  const scripts = Array.from(document.scripts).map(s => s.src || s.textContent?.slice(0, 200) || '');
  const links = Array.from(document.querySelectorAll('link[href]')).map(l => l.href);
  const metas = Array.from(document.querySelectorAll('meta')).map(m => ({name:m.name, property:m.getAttribute('property'), content:m.content}));
  const attrs = Array.from(document.querySelectorAll('*')).slice(0, 4000).flatMap(el => Array.from(el.attributes).map(a => a.name + '=' + a.value.slice(0,80)));
  const classes = Array.from(document.querySelectorAll('[class]')).slice(0, 4000).flatMap(el => String(el.className).split(/\s+/)).filter(Boolean);
  const html = document.documentElement.outerHTML.slice(0, 500000);
  const lower = (scripts.concat(links, attrs, classes, html.slice(0,5000))).join('\n').toLowerCase();
  const found = [];
  const add = (group, name, confidence, evidence) => found.push({group, name, confidence, evidence});
  if (document.querySelector('#__NEXT_DATA__') || lower.includes('/_next/')) add('framework','Next.js','high','__NEXT_DATA__ or /_next/ assets');
  if (window.React || lower.includes('reactroot') || lower.includes('react-dom')) add('framework','React','medium','React globals/markers/assets');
  if (document.querySelector('[ng-version]')) add('framework','Angular','high','ng-version attribute');
  if (document.querySelector('[data-v-]') || lower.includes('__vue__') || lower.includes('vue')) add('framework','Vue','medium','Vue markers/assets');
  if (lower.includes('/_astro/') || document.querySelector('[data-astro-cid]')) add('framework','Astro','high','Astro assets/attributes');
  if (lower.includes('wp-content') || lower.includes('wordpress')) add('cms','WordPress','high','wp-content/WordPress markers');
  if (lower.includes('webflow')) add('builder','Webflow','high','Webflow markers');
  if (lower.includes('wixstatic') || lower.includes('x-wix')) add('builder','Wix','high','Wix markers');
  if (lower.includes('cdn.shopify.com') || lower.includes('shopify')) add('commerce','Shopify','high','Shopify CDN/markers');
  const tw = classes.filter(c => /^(flex|grid|hidden|block|inline|text-|bg-|p[trblxy]?-|m[trblxy]?-|rounded|shadow|gap-|space-|max-w-|min-h-|items-|justify-)/.test(c)).length;
  if (tw > 20) add('css','Tailwind-like utility CSS', tw > 80 ? 'high' : 'medium', `${tw} utility-like classes`);
  if (classes.some(c => c.startsWith('Mui'))) add('ui','Material UI','high','Mui* class names');
  if (classes.some(c => c.startsWith('chakra'))) add('ui','Chakra UI','high','chakra* class names');
  if (classes.some(c => c.startsWith('ant-'))) add('ui','Ant Design','high','ant-* class names');
  if (attrs.some(a => a.includes('data-radix')) || lower.includes('radix')) add('ui','Radix / shadcn-like','medium','Radix attributes/assets');
  if (classes.some(c => c.includes('swiper')) || lower.includes('swiper')) add('interaction','Swiper','high','swiper classes/assets');
  if (window.gsap || lower.includes('gsap')) add('animation','GSAP','high','gsap global/assets');
  if (attrs.some(a => a.startsWith('data-aos')) || lower.includes('aos')) add('animation','AOS','medium','data-aos/AOS markers');
  if (lower.includes('lottie') || document.querySelector('lottie-player')) add('animation','Lottie','medium','lottie markers');
  if (window.THREE || lower.includes('three')) add('3d','Three.js','medium','three markers');
  if (lower.includes('googletagmanager.com')) add('analytics','Google Tag Manager','high','GTM script');
  if (lower.includes('google-analytics.com') || lower.includes('gtag(')) add('analytics','Google Analytics','high','GA script');
  if (document.querySelector('canvas')) add('media','Canvas','medium',`${document.querySelectorAll('canvas').length} canvas elements`);
  if (document.querySelector('video')) add('media','Video','medium',`${document.querySelectorAll('video').length} video elements`);
  return {url: location.href, title: document.title, detections: found, evidence_counts: {scripts: scripts.length, stylesheets: links.length, class_names: classes.length, attributes: attrs.length}, raw_samples: {scripts: scripts.filter(Boolean).slice(0,20), stylesheets: links.slice(0,20)}};
}
""")


def _group_interaction_effects(items: list[dict[str, Any]], keys: list[str]) -> list[dict[str, Any]]:
    groups: dict[str, dict[str, Any]] = {}
    for item in items or []:
        key_values = [str(item.get(k) or "") for k in keys]
        key = "|".join(key_values)
        g = groups.setdefault(key, {
            "count": 0,
            "signature": {k: item.get(k) for k in keys},
            "sample": item,
            "selectors": [],
        })
        g["count"] += 1
        sel = item.get("selector")
        if sel and len(g["selectors"]) < 5:
            g["selectors"].append(sel)
    return sorted(groups.values(), key=lambda g: g["count"], reverse=True)


async def qa_design_interaction_scan(mgr: SessionManager, session_id: str) -> dict[str, Any]:
    """Scan visible DOM for animations, transitions, fixed/sticky widgets,
    media effects, and standout interaction elements.

    Repetitive effects are grouped (e.g. 34 identical skeleton animations) so
    agents get signal instead of 50 near-identical samples.
    """
    s = mgr.get(session_id)
    await _wait_for_content(s.page)
    result = await s.page.evaluate(r"""
() => {
  const sel = el => {
    if (el.id) return '#' + CSS.escape(el.id);
    const cls = String(el.className || '').split(/\s+/).filter(Boolean).slice(0,3).map(c=>'.'+CSS.escape(c)).join('');
    return el.tagName.toLowerCase() + cls;
  };
  const visible = el => { const r = el.getBoundingClientRect(); const cs = getComputedStyle(el); return r.width>0 && r.height>0 && cs.visibility!=='hidden' && cs.display!=='none'; };
  const animations = [], transitions = [], fixed = [], media = [], widgets = [];
  for (const el of Array.from(document.querySelectorAll('body *')).slice(0, 3000)) {
    if (!visible(el)) continue;
    const cs = getComputedStyle(el); const r = el.getBoundingClientRect();
    if (cs.animationName && cs.animationName !== 'none') animations.push({selector: sel(el), text: (el.innerText||'').slice(0,80), animationName: cs.animationName, duration: cs.animationDuration, delay: cs.animationDelay, properties: [cs.transform !== 'none' ? 'transform' : null, Number(cs.opacity) < 1 ? 'opacity' : null].filter(Boolean)});
    if (cs.transitionDuration && cs.transitionDuration !== '0s' && cs.transitionDuration !== '0s, 0s') transitions.push({selector: sel(el), text: (el.innerText||'').slice(0,80), transitionProperty: cs.transitionProperty, duration: cs.transitionDuration});
    if (['fixed','sticky'].includes(cs.position)) fixed.push({selector: sel(el), text: (el.innerText||'').slice(0,100), position: cs.position, bbox:{x:r.x,y:r.y,w:r.width,h:r.height}, zIndex: cs.zIndex});
  }
  for (const tag of ['canvas','video','svg','picture','iframe']) {
    const els = Array.from(document.querySelectorAll(tag));
    if (els.length) media.push({type: tag, count: els.length, samples: els.slice(0,5).map(sel)});
  }
  const textAll = document.body.innerText.toLowerCase();
  const widgetRules = [
    ['cookie banner', /cookies?|עוגיות/.test(textAll)], ['chat widget', /chat|צ'אט|הקלידו הודעה|ai chat/.test(textAll)], ['accessibility widget', /accessibility|נגישות/.test(textAll)], ['language switcher', !!document.querySelector('[id*=lang i], [class*=lang i]')], ['theme toggle', !!document.querySelector('[id*=theme i], [class*=theme i]')], ['mobile menu', !!document.querySelector('[id*=hamburger i], [class*=hamburger i], [aria-label*=menu i]')]
  ];
  for (const [name, ok] of widgetRules) if (ok) widgets.push(name);
  return {url: location.href, viewport:{w: innerWidth, h: innerHeight}, special_elements: widgets, fixed_or_sticky: fixed.slice(0,30), animations: animations.slice(0,50), transitions: transitions.slice(0,50), media_effects: media, summary:{animations: animations.length, transitions: transitions.length, fixed_or_sticky: fixed.length, widgets: widgets.length}};
}
""")
    if isinstance(result, dict):
        animation_groups = _group_interaction_effects(
            result.get("animations") or [], ["animationName", "duration", "delay"]
        )
        transition_groups = _group_interaction_effects(
            result.get("transitions") or [], ["transitionProperty", "duration"]
        )
        result["grouped"] = {
            "animations": animation_groups,
            "transitions": transition_groups,
        }
        result["deduped_summary"] = {
            "animation_patterns": len(animation_groups),
            "transition_patterns": len(transition_groups),
            "top_animation": animation_groups[0] if animation_groups else None,
            "top_transition": transition_groups[0] if transition_groups else None,
        }
    return result


def _ux_viewport_delta(desktop: dict[str, Any] | None, mobile: dict[str, Any] | None) -> dict[str, Any]:
    if not desktop or not mobile:
        return {}
    def get(path: list[str], src: dict[str, Any]):
        cur: Any = src
        for p in path:
            if not isinstance(cur, dict):
                return None
            cur = cur.get(p)
        return cur
    comparisons = {
        "hierarchy_score": ["scores", "hierarchy_score"],
        "cognitive_load_score": ["scores", "cognitive_load_score"],
        "density_score": ["scores", "density_score"],
        "touch_target_score": ["scores", "touch_target_score"],
        "cta_in_fold": ["interactive", "cta_in_fold"],
        "small_touch_targets": ["touch_targets", "small_count"],
        "interactive_in_fold": ["interactive", "in_fold"],
        "text_density": ["density", "chars_per_px2"],
    }
    deltas = {}
    regressions = []
    for name, path in comparisons.items():
        d, m = get(path, desktop), get(path, mobile)
        if isinstance(d, (int, float)) and isinstance(m, (int, float)):
            delta = round(m - d, 3)
            deltas[name] = {"desktop": d, "mobile": m, "delta_mobile_minus_desktop": delta}
            if name.endswith("score") and delta <= -10:
                regressions.append({"metric": name, "desktop": d, "mobile": m, "severity": "medium"})
            if name == "small_touch_targets" and m > d:
                regressions.append({"metric": name, "desktop": d, "mobile": m, "severity": "high" if m - d >= 5 else "medium"})
    return {"deltas": deltas, "mobile_regressions": regressions, "summary": {"regressions": len(regressions)}}


def _collect_selectors_from_findings(findings: list[dict[str, Any]], limit: int = 5) -> list[str]:
    selectors: list[str] = []
    for f in findings:
        if f.get("selector"):
            selectors.append(f["selector"])
        for sample in f.get("samples") or []:
            if isinstance(sample, dict) and sample.get("selector"):
                selectors.append(sample["selector"])
        if len(selectors) >= limit:
            break
    # Stable de-duplication
    out = []
    for s in selectors:
        if s and s not in out:
            out.append(s)
    return out[:limit]


async def _highlight_screenshot(page, selectors: list[str], label: str) -> dict[str, Any] | None:
    if not selectors:
        return None
    safe = _safe_name(label)
    out_dir = _DATA_DIR / "screenshots"
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"ux-evidence-{safe}-{datetime.now().strftime('%Y%m%d-%H%M%S-%f')}.jpg"
    try:
        await page.evaluate(r"""
(args) => {
  const selectors = args.selectors || [];
  document.querySelectorAll('[data-qa-mcp-evidence]').forEach(n => n.remove());
  const first = selectors.map(s => { try { return document.querySelector(s); } catch { return null; } }).find(Boolean);
  if (first) first.scrollIntoView({block:'center', inline:'center'});
  selectors.forEach((selector, i) => {
    let el = null;
    try { el = document.querySelector(selector); } catch {}
    if (!el || !el.getBoundingClientRect) return;
    const r = el.getBoundingClientRect();
    if (r.width <= 0 || r.height <= 0) return;
    const box = document.createElement('div');
    box.setAttribute('data-qa-mcp-evidence', 'true');
    Object.assign(box.style, {
      position: 'fixed', left: `${Math.max(0, r.left - 3)}px`, top: `${Math.max(0, r.top - 3)}px`,
      width: `${r.width + 6}px`, height: `${r.height + 6}px`, border: '3px solid #ff2d55',
      borderRadius: '6px', zIndex: '2147483647', pointerEvents: 'none', boxSizing: 'border-box',
      boxShadow: '0 0 0 9999px rgba(0,0,0,0.08)'
    });
    const tag = document.createElement('div');
    tag.textContent = `UX ${i + 1}`;
    Object.assign(tag.style, {
      position: 'fixed', left: `${Math.max(0, r.left - 3)}px`, top: `${Math.max(0, r.top - 25)}px`,
      background: '#ff2d55', color: '#fff', font: '700 12px system-ui', padding: '2px 6px',
      borderRadius: '4px', zIndex: '2147483647', pointerEvents: 'none'
    });
    tag.setAttribute('data-qa-mcp-evidence', 'true');
    document.body.appendChild(box); document.body.appendChild(tag);
  });
}
""", {"selectors": selectors})
        await page.screenshot(path=str(path), type="jpeg", quality=80, full_page=False)
        return {"path": str(path), "selectors": selectors}
    except Exception as e:
        return {"error": f"{type(e).__name__}: {e}", "selectors": selectors}
    finally:
        try:
            await page.evaluate("() => document.querySelectorAll('[data-qa-mcp-evidence]').forEach(n => n.remove())")
        except Exception:
            pass


def _prioritize_ux_audit(result: dict[str, Any]) -> dict[str, Any]:
    items: list[dict[str, Any]] = []
    for viewport in ("desktop", "mobile"):
        ux = (result.get(viewport) or {}).get("ux") or {}
        for f in ux.get("findings", []) or []:
            items.append({**f, "source": f"ux:{viewport}", "viewport": viewport})
    for viewport in ("desktop", "mobile"):
        rtl = (result.get(viewport) or {}).get("rtl") or {}
        by = (rtl.get("summary") or {}).get("by_severity") or {}
        if by.get("high", 0):
            items.append({"source": f"rtl:{viewport}", "viewport": viewport, "severity": "high", "category": "rtl", "title": f"RTL audit found {by.get('high')} high-severity issues", "fix": "Run qa_rtl_audit(detail='samples'/'full') and fix dir, plural, BiDi and overflow issues."})
    a11y = (result.get("desktop") or {}).get("a11y") or {}
    by_imp = (a11y.get("summary") or {}).get("by_impact") or {}
    if by_imp.get("critical") or by_imp.get("serious"):
        items.append({"source": "a11y", "severity": "high" if by_imp.get("critical") else "medium", "category": "accessibility", "title": f"Accessibility blockers: {by_imp}", "fix": "Run qa_a11y_audit(detail='samples') and fix critical/serious axe violations first."})
    perf = (result.get("desktop") or {}).get("perf") or {}
    grades = perf.get("grades") or {}
    if any(v in ("poor", "needs_improvement") for v in grades.values()):
        poor = {k: v for k, v in grades.items() if v in ("poor", "needs_improvement")}
        items.append({"source": "perf", "severity": "high" if "poor" in poor.values() else "medium", "category": "performance", "title": f"Web Vitals need work: {poor}", "fix": "Use cls_attribution/LCP data, reserve media space, optimize hero assets and reduce blocking JS.", "evidence": {"metrics": perf.get("metrics"), "cls_attribution": perf.get("cls_attribution", [])[:3]}})
    for r in ((result.get("viewport_comparison") or {}).get("mobile_regressions") or []):
        items.append({"source": "responsive", "severity": r.get("severity", "medium"), "category": "mobile_regression", "title": f"Mobile regression in {r.get('metric')}: {r.get('desktop')} → {r.get('mobile')}", "fix": "Compare desktop/mobile screenshots and adjust responsive layout/spacing/touch sizing."})
    items.sort(key=lambda f: (_sev_rank(f.get("severity", "info")), f.get("source", "")))
    return {"top_findings": items[:10], "summary": _summarize_findings(items), "must_fix": [i for i in items if i.get("severity") in ("critical", "high")][:5], "should_fix": [i for i in items if i.get("severity") == "medium"][:5]}


async def qa_ux_audit_url(mgr: SessionManager, url: str,
                          persona: str = "general",
                          include_mobile: bool = True,
                          include_rtl: bool = True,
                          include_a11y: bool = True,
                          include_perf: bool = True,
                          include_evidence: bool = True,
                          browser: str = "chrome",
                          headless: bool = True) -> dict[str, Any]:
    """High-level UX audit: raw metrics + deterministic UX findings + mobile diff.

    This turns the low-level tools into one agent-friendly UX report while
    keeping every sub-result inspectable.
    """
    from . import browser_tools

    opened = await browser_tools.browser_open(mgr, url=url, headless=headless, browser=browser, locale="he-IL", timezone="Asia/Jerusalem")
    sid = opened["session_id"]
    result: dict[str, Any] = {
        "url": opened.get("url") or url,
        "title": opened.get("title"),
        "persona": persona,
        "browser": browser,
        "desktop": {},
        "mobile": None,
        "evidence": {},
    }
    try:
        result["desktop"]["ux"] = await qa_ux_metrics(mgr, sid, detail="full", persona=persona)
        result["desktop"]["interactions"] = await qa_design_interaction_scan(mgr, sid)
        result["desktop"]["links"] = await qa_scan_links(mgr, sid, detail="summary")
        if include_rtl:
            result["desktop"]["rtl"] = await qa_rtl_audit(mgr, sid, detail="summary")
        if include_a11y:
            result["desktop"]["a11y"] = await qa_a11y_audit(mgr, sid, min_impact="serious", detail="summary")
        if include_perf:
            result["desktop"]["perf"] = await qa_perf_metrics(mgr, sid, wait_for_lcp_ms=5000, detail="summary")
        if include_evidence:
            result["evidence"]["desktop_page"] = (await browser_tools.browser_screenshot(mgr, sid, full_page=False)).get("path")
            selectors = _collect_selectors_from_findings(result["desktop"]["ux"].get("findings", []))
            result["evidence"]["desktop_highlight"] = await _highlight_screenshot(mgr.get(sid).page, selectors, "desktop")

        if include_mobile:
            await browser_tools.browser_set_viewport(mgr, sid, device="iphone-13")
            await mgr.get(sid).page.wait_for_timeout(250)
            mobile: dict[str, Any] = {}
            mobile["ux"] = await qa_ux_metrics(mgr, sid, fold_height=740, detail="full", persona="mobile_first" if persona == "general" else persona)
            mobile["interactions"] = await qa_design_interaction_scan(mgr, sid)
            if include_rtl:
                mobile["rtl"] = await qa_rtl_audit(mgr, sid, detail="summary")
            result["mobile"] = mobile
            result["viewport_comparison"] = _ux_viewport_delta(result["desktop"].get("ux"), mobile.get("ux"))
            if include_evidence:
                result["evidence"]["mobile_page"] = (await browser_tools.browser_screenshot(mgr, sid, full_page=False)).get("path")
                selectors = _collect_selectors_from_findings(mobile["ux"].get("findings", []))
                result["evidence"]["mobile_highlight"] = await _highlight_screenshot(mgr.get(sid).page, selectors, "mobile")
        result["prioritized"] = _prioritize_ux_audit(result)
        result["summary"] = {
            "ux_findings": result["prioritized"]["summary"],
            "desktop_scores": (result["desktop"].get("ux") or {}).get("scores"),
            "mobile_scores": ((result.get("mobile") or {}).get("ux") or {}).get("scores") if result.get("mobile") else None,
        }
        return result
    finally:
        await browser_tools.browser_close(mgr, sid)


async def qa_form_risk_audit(mgr: SessionManager, session_id: str) -> dict[str, Any]:
    inv = await qa_form_inventory(mgr, session_id)
    findings: list[dict[str, Any]] = []
    for form in inv.get("inventory", []):
        method = (form.get("method") or "").upper()
        if method == "GET" and form.get("field_count", 0) > 0:
            findings.append({"severity": "medium", "category": "form_method_get", "title": "Form submits with GET", "hint": "Use POST for lead/contact forms to avoid exposing data in URLs.", "form_index": form.get("form_index")})
        for field in form.get("fields", []):
            if not field.get("label") and field.get("type") not in ("hidden", "submit"):
                findings.append({"severity": "medium" if field.get("required") else "low", "category": "missing_label", "title": "Field has no explicit label", "hint": "Add a visible <label> or aria-label tied to the field.", "field": field})
            if field.get("purpose") in ("email", "phone", "name") and not field.get("autocomplete"):
                findings.append({"severity": "low", "category": "missing_autocomplete", "title": "Useful autocomplete missing", "hint": "Add autocomplete='email', 'tel', or 'name' to improve mobile conversion.", "field": field})
        has_privacy = any('privacy' in str(f.get('name') or f.get('id') or '').lower() for f in form.get("fields", []))
        if not has_privacy:
            findings.append({"severity": "medium", "category": "privacy_consent_missing", "title": "No obvious privacy consent field", "hint": "Lead forms should include privacy/terms consent when collecting personal data.", "form_index": form.get("form_index")})
    return {"inventory": inv, "findings": findings, "summary": {"total": len(findings), "by_severity": {s: sum(1 for f in findings if f['severity']==s) for s in ['high','medium','low']}}}


async def qa_page_signature(mgr: SessionManager, session_id: str) -> dict[str, Any]:
    s = mgr.get(session_id)
    await _wait_for_content(s.page)
    return await s.page.evaluate(r"""
() => {
  const texts = Array.from(document.querySelectorAll('h1,h2,h3,p,a,button')).map(e => (e.innerText||'').trim()).filter(Boolean).slice(0,300);
  const colors = Array.from(document.querySelectorAll('body *')).slice(0,800).map(e => getComputedStyle(e).color + '|' + getComputedStyle(e).backgroundColor).filter(Boolean);
  const tags = Array.from(document.querySelectorAll('body *')).slice(0,2000).map(e => e.tagName.toLowerCase());
  const sections = Array.from(document.querySelectorAll('section, header, footer, main, nav')).map(e => ({tag:e.tagName.toLowerCase(), text:(e.innerText||'').trim().slice(0,300)})).slice(0,80);
  return {url: location.href, title: document.title, texts, colors: Array.from(new Set(colors)).slice(0,80), tags, sections};
}
""")


# ---------- fix suggester ----------


async def qa_fix_suggestions(mgr: SessionManager, session_id: str) -> dict[str, Any]:
    """Generate fix suggestions from the most recent qa_rtl_audit findings
    on this session. Each suggestion maps a finding to a concrete fix:
    text replacement, <bdi> wrapping, ₪ position swap, arrow direction,
    dir attribute, date disambiguation, plural agreement, or CTA translation.

    Returns { suggestions: [...], summary: { total, auto_fixable,
    needs_review, avg_confidence, by_category } }.

    The calling agent should present auto_fixable (requires_review=False)
    suggestions as low-risk PR candidates and needs_review as items that
    require human judgment (e.g. CTA translations, date format assumptions).
    """
    from .fix_suggester import suggest_fixes, fix_summary as _fs_summary

    s = mgr.get(session_id)
    findings = []
    if hasattr(s, "_last_rtl_findings") and s._last_rtl_findings:
        findings = s._last_rtl_findings
    else:
        return {
            "error": "No RTL findings cached for this session. "
                     "Run qa_rtl_audit first.",
            "suggestions": [],
        }

    suggestions = suggest_fixes(findings)
    return {
        "suggestions": suggestions,
        "summary": _fs_summary(suggestions),
    }


def qa_fix_from_findings(findings: list[dict[str, Any]],
                          summary: bool = True) -> dict[str, Any]:
    """Generate fix suggestions from a raw findings list (e.g. the
    'findings' array from qa_rtl_audit output). Use this when you
    already have the findings from a previous audit and want to
    generate fixes without a browser session.

    Args:
        findings: List of finding dicts from qa_rtl_audit.
        summary: If True, return both suggestions list and summary.
                 If False, return only the suggestions list.

    Returns { suggestions: [...], summary: {...} } when summary=True,
    or { suggestions: [...] } when summary=False.
    """
    from .fix_suggester import suggest_fixes as _suggest, fix_summary as _fs

    suggestions = _suggest(findings)
    result: dict[str, Any] = {"suggestions": suggestions}
    if summary:
        result["summary"] = _fs(suggestions)
    return result


# ---------- source mapper ----------


def qa_map_to_source(findings: list[dict[str, Any]],
                     repo_path: str,
                     include_i18n: bool = True) -> dict[str, Any]:
    """Map RTL audit findings to source code locations.

    Searches the repository for the offending text from each finding.
    Returns file:line matches with confidence scores. When text is
    found in source, the finding is 'mapped'. When not found, it's
    'unmapped' (likely from a database, CMS, or external API).

    Args:
        findings: RTL audit findings list.
        repo_path: Path to the git repository root.
        include_i18n: Also search locale/i18n files.

    Returns { total_findings, mapped, unmapped, map_rate, results }.
    """
    from .source_mapper import map_findings_to_source
    return map_findings_to_source(findings, repo_path, include_i18n=include_i18n)


def qa_map_with_fixes(findings: list[dict[str, Any]],
                      fix_suggestions: list[dict[str, Any]],
                      repo_path: str) -> dict[str, Any]:
    """Combined: map findings to source AND attach fix diffs.

    Takes findings from qa_rtl_audit + fix suggestions from
    qa_fix_from_findings, maps everything to source, and returns
    ready-to-apply patches (diffs) for auto-fixable findings.
    """
    from .source_mapper import map_with_fixes, best_patches
    result = map_with_fixes(findings, fix_suggestions, repo_path)
    result["auto_patches"] = best_patches(result, auto_only=True)
    result["all_patches"] = best_patches(result, auto_only=False)
    return result


# ---------- page decomposition / design inventory ----------


_DECOMPOSE_PAGE_JS = r"""
(opts) => {
  const O = opts || {};
  const maxSections = O.max_sections || 12;
  const maxComponents = O.max_components_per_section || 12;
  const viewport = { width: innerWidth, height: innerHeight };
  const STYLE_KEYS = [
    'display','position','inset','top','right','bottom','left','zIndex',
    'width','height','minWidth','maxWidth','minHeight','maxHeight','boxSizing',
    'margin','padding','gap','rowGap','columnGap','flexDirection','flexWrap','justifyContent','alignItems','gridTemplateColumns','gridTemplateRows',
    'fontFamily','fontSize','fontWeight','lineHeight','letterSpacing','textAlign','textTransform','color',
    'background','backgroundColor','backgroundImage','backgroundSize','backgroundPosition','backgroundRepeat','backgroundAttachment','backgroundBlendMode',
    'border','borderRadius','boxShadow','filter','backdropFilter','opacity','mixBlendMode',
    'transform','transformOrigin','transition','transitionProperty','transitionDuration','transitionTimingFunction',
    'animation','animationName','animationDuration','animationTimingFunction','animationDelay','animationIterationCount','animationDirection','animationFillMode',
    'overflow','overflowX','overflowY','clipPath','maskImage'
  ];
  const INTERACTIVE_SEL = 'a[href], button, [role="button"], input, select, textarea, summary, [onclick], [tabindex]:not([tabindex="-1"])';
  const COMPONENT_SEL = 'h1,h2,h3,h4,p,a[href],button,[role="button"],input,select,textarea,img,video,canvas,svg,form,[class*="card" i],[class*="btn" i],[class*="button" i],[class*="badge" i],[class*="chip" i]';

  const cssEsc = (s) => (typeof CSS !== 'undefined' && CSS.escape) ? CSS.escape(s) : String(s).replace(/[^\w-]/g, ch => '\\' + ch);
  const visible = (el) => {
    if (!el || !el.getBoundingClientRect) return false;
    const r = el.getBoundingClientRect();
    if (r.width <= 0 || r.height <= 0) return false;
    const cs = getComputedStyle(el);
    return cs.visibility !== 'hidden' && cs.display !== 'none' && Number(cs.opacity || 1) !== 0;
  };
  const selectorFor = (el) => {
    if (!el || el.nodeType !== 1) return '';
    if (el.id) return '#' + cssEsc(el.id);
    for (const a of ['data-testid','data-qa','data-cy','data-test','aria-label','name']) {
      const v = el.getAttribute && el.getAttribute(a);
      if (v) return `${el.tagName.toLowerCase()}[${a}="${String(v).replace(/"/g, '\\"')}"]`;
    }
    const parts = [];
    let cur = el;
    while (cur && cur.nodeType === 1 && cur !== document.documentElement && parts.length < 6) {
      const parent = cur.parentElement;
      if (!parent) break;
      const tag = cur.tagName.toLowerCase();
      const same = Array.from(parent.children).filter(c => c.tagName === cur.tagName);
      parts.unshift(`${tag}:nth-of-type(${same.indexOf(cur) + 1})`);
      cur = parent;
    }
    return parts.join(' > ');
  };
  const cleanStyleValue = (v) => {
    if (!v) return null;
    if (['none','normal','auto','0px','0s','rgba(0, 0, 0, 0)','transparent'].includes(v)) return null;
    return v;
  };
  const pickStyles = (el, pseudo=null) => {
    const cs = getComputedStyle(el, pseudo);
    const out = {};
    for (const key of STYLE_KEYS) {
      const prop = key.replace(/([A-Z])/g, '-$1').toLowerCase();
      const v = cleanStyleValue(cs.getPropertyValue(prop));
      if (v) out[key] = v;
    }
    const content = pseudo ? cleanStyleValue(cs.getPropertyValue('content')) : null;
    if (content) out.content = content;
    return out;
  };
  const bbox = (el) => {
    const r = el.getBoundingClientRect();
    return { x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height), area: Math.round(r.width * r.height) };
  };
  const bgUrls = (value) => Array.from(String(value || '').matchAll(/url\(["']?([^"')]+)["']?\)/g)).map(m => new URL(m[1], location.href).href);
  const backgroundInfo = (el) => {
    const styles = pickStyles(el);
    const before = pickStyles(el, '::before');
    const after = pickStyles(el, '::after');
    const out = {
      color: styles.backgroundColor || null,
      image: styles.backgroundImage || null,
      size: styles.backgroundSize || null,
      position: styles.backgroundPosition || null,
      repeat: styles.backgroundRepeat || null,
      attachment: styles.backgroundAttachment || null,
      blendMode: styles.backgroundBlendMode || null,
      gradients: [],
      urls: [],
      pseudo: {}
    };
    for (const src of [styles.backgroundImage, before.backgroundImage, after.backgroundImage]) {
      if (!src) continue;
      if (/gradient\(/i.test(src)) out.gradients.push(src);
      out.urls.push(...bgUrls(src));
    }
    if (Object.keys(before).length) out.pseudo.before = before;
    if (Object.keys(after).length) out.pseudo.after = after;
    return out;
  };
  const animationInfo = (el) => {
    const s = pickStyles(el);
    const items = [];
    if (s.animationName && s.animationName !== 'none') {
      items.push({ type:'css-animation', name:s.animationName, duration:s.animationDuration, delay:s.animationDelay, timing:s.animationTimingFunction, iteration:s.animationIterationCount, direction:s.animationDirection, fillMode:s.animationFillMode, transform:s.transform || null, opacity:s.opacity || null });
    }
    if (s.transitionDuration && s.transitionDuration !== '0s') {
      items.push({ type:'transition', property:s.transitionProperty, duration:s.transitionDuration, timing:s.transitionTimingFunction, transform:s.transform || null });
    }
    return items;
  };
  const classifySection = (el, index) => {
    const tag = el.tagName.toLowerCase();
    const blob = `${tag} ${el.id || ''} ${el.className || ''} ${el.getAttribute('role') || ''} ${(el.innerText || '').slice(0,200)}`.toLowerCase();
    if (tag === 'header' || /header|navbar|nav|topbar/.test(blob)) return 'header/nav';
    if (tag === 'footer' || /footer|copyright/.test(blob)) return 'footer';
    if (/hero|banner|masthead|above-fold/.test(blob) || index === 0) return 'hero';
    if (/pricing|plans|tiers|מחיר|תמחור/.test(blob)) return 'pricing';
    if (/faq|שאלות|accordion/.test(blob)) return 'faq';
    if (/testimonial|review|לקוחות|המלצות/.test(blob)) return 'testimonials';
    if (el.querySelector('form,input,textarea,select')) return 'form-section';
    if (el.querySelectorAll('[class*="card" i], article').length >= 2) return 'cards/grid';
    return 'section';
  };
  const classifyComponent = (el) => {
    const tag = el.tagName.toLowerCase();
    const blob = `${tag} ${el.id || ''} ${el.className || ''} ${el.getAttribute('role') || ''} ${(el.innerText || '').slice(0,120)}`.toLowerCase();
    if (/^h[1-6]$/.test(tag)) return 'heading';
    if (tag === 'button' || el.matches('[role="button"]') || /btn|button|cta/.test(blob)) return 'button/cta';
    if (tag === 'a') return 'link';
    if (['input','select','textarea'].includes(tag)) return 'input';
    if (tag === 'img') return 'image';
    if (tag === 'video') return 'video';
    if (tag === 'canvas') return 'canvas/webgl';
    if (tag === 'svg') return 'svg/icon';
    if (tag === 'form') return 'form';
    if (/card|tile|panel/.test(blob)) return 'card';
    if (/badge|chip|pill|tag/.test(blob)) return 'badge/chip';
    return tag;
  };
  const componentSummary = (root) => Array.from(root.querySelectorAll(COMPONENT_SEL)).filter(visible).slice(0, maxComponents).map(el => ({
    type: classifyComponent(el), tag: el.tagName.toLowerCase(), selector: selectorFor(el), text: (el.innerText || el.alt || el.getAttribute('aria-label') || '').trim().slice(0,100), bbox: bbox(el), styles: pickStyles(el), background: backgroundInfo(el), animations: animationInfo(el), src: el.currentSrc || el.src || el.getAttribute('src') || null, href: el.href || el.getAttribute('href') || null
  }));

  const candidates = [];
  const roots = Array.from(document.querySelectorAll('header, nav, main > section, main > div, section, article, aside, footer, [role="banner"], [role="main"], [role="contentinfo"]'));
  for (const el of roots) {
    if (!visible(el)) continue;
    const b = bbox(el);
    if (b.w < 120 || b.h < 40 || b.area < 8000) continue;
    candidates.push(el);
  }
  if (!candidates.length && document.body) candidates.push(document.body);
  const unique = [];
  const seen = new Set();
  for (const el of candidates.sort((a,b) => bbox(a).y - bbox(b).y || bbox(b).area - bbox(a).area)) {
    if (seen.has(el)) continue;
    if (unique.some(parent => parent.contains(el) && bbox(el).area / Math.max(bbox(parent).area,1) > 0.85)) continue;
    seen.add(el); unique.push(el);
    if (unique.length >= maxSections) break;
  }

  const colors = new Set(), fonts = new Set(), radii = new Set(), shadows = new Set(), gradients = new Set(), backgroundUrls = new Set();
  Array.from(document.querySelectorAll('body *')).filter(visible).slice(0, 2000).forEach(el => {
    const s = pickStyles(el), bg = backgroundInfo(el);
    if (s.color) colors.add(s.color);
    if (s.backgroundColor) colors.add(s.backgroundColor);
    if (s.fontFamily) fonts.add(s.fontFamily.split(',')[0].trim().replace(/["']/g,''));
    if (s.borderRadius) radii.add(s.borderRadius);
    if (s.boxShadow) shadows.add(s.boxShadow);
    bg.gradients.forEach(g => gradients.add(g));
    bg.urls.forEach(u => backgroundUrls.add(u));
  });

  const keyframes = {};
  const interactionRules = [];
  for (const sheet of Array.from(document.styleSheets)) {
    let rules = [];
    try { rules = Array.from(sheet.cssRules || []); } catch { continue; }
    for (const rule of rules) {
      if (rule.type === CSSRule.KEYFRAMES_RULE) keyframes[rule.name] = rule.cssText.slice(0, 3000);
      const txt = rule.cssText || '';
      if (/:hover|:focus|:active|data-state|aria-expanded|\.is-|\.active/.test(txt)) interactionRules.push(txt.slice(0, 700));
      if (interactionRules.length >= 50) break;
    }
  }

  const animations = [], transitions = [];
  Array.from(document.querySelectorAll('body *')).filter(visible).slice(0, 3000).forEach(el => {
    for (const a of animationInfo(el)) {
      const row = { selector: selectorFor(el), text:(el.innerText || '').trim().slice(0,80), ...a };
      if (a.type === 'css-animation') animations.push(row); else transitions.push(row);
    }
  });
  const groupBySig = (items, keys) => Object.values(items.reduce((acc, item) => {
    const sig = keys.map(k => item[k] || '').join('|');
    if (!acc[sig]) acc[sig] = { count:0, signature:Object.fromEntries(keys.map(k => [k, item[k] || null])), sample:item, selectors:[] };
    acc[sig].count += 1; if (item.selector && acc[sig].selectors.length < 5) acc[sig].selectors.push(item.selector); return acc;
  }, {})).sort((a,b) => b.count - a.count);

  const sections = unique.map((el, i) => ({
    index: i, type: classifySection(el, i), selector: selectorFor(el), text: (el.innerText || '').trim().slice(0, 500), bbox: bbox(el), styles: pickStyles(el), background: backgroundInfo(el), animations: animationInfo(el), components: componentSummary(el)
  }));

  const assets = {
    images: Array.from(document.images).filter(visible).slice(0, 80).map(img => ({ src: img.currentSrc || img.src, alt: img.alt || '', bbox: bbox(img) })),
    videos: Array.from(document.querySelectorAll('video')).slice(0, 20).map(v => ({ src: v.currentSrc || v.src || Array.from(v.querySelectorAll('source')).map(s => s.src)[0] || null, poster: v.poster || null, bbox: visible(v) ? bbox(v) : null })),
    svgs: Array.from(document.querySelectorAll('svg')).slice(0, 50).map(svg => ({ selector: selectorFor(svg), bbox: visible(svg) ? bbox(svg) : null, title: (svg.querySelector('title')?.textContent || '').trim() })),
    canvases: Array.from(document.querySelectorAll('canvas')).map(c => ({ selector: selectorFor(c), bbox: visible(c) ? bbox(c) : null })),
    iframes: Array.from(document.querySelectorAll('iframe')).slice(0, 20).map(f => ({ src: f.src, title: f.title || '', bbox: visible(f) ? bbox(f) : null })),
    background_urls: Array.from(backgroundUrls).slice(0, 80),
    fonts: Array.from(fonts).slice(0, 30)
  };

  const libraries = [];
  const html = document.documentElement.outerHTML.toLowerCase();
  if (window.gsap || html.includes('gsap')) libraries.push('GSAP');
  if (html.includes('framer-motion')) libraries.push('Framer Motion');
  if (html.includes('lottie') || document.querySelector('lottie-player')) libraries.push('Lottie');
  if (html.includes('aos') || document.querySelector('[data-aos]')) libraries.push('AOS');
  if (html.includes('swiper')) libraries.push('Swiper');
  if (window.THREE || html.includes('three')) libraries.push('Three.js/WebGL');

  return {
    page: { url: location.href, title: document.title, viewport, dir: document.documentElement.dir || '', lang: document.documentElement.lang || '' },
    summary: { sections: sections.length, components: sections.reduce((n,s) => n + s.components.length, 0), animation_patterns: groupBySig(animations, ['name','duration','delay']).length, transition_patterns: groupBySig(transitions, ['property','duration']).length, images: assets.images.length, videos: assets.videos.length, canvases: assets.canvases.length, svgs: assets.svgs.length },
    global_design: { colors: Array.from(colors).slice(0, 40), fonts: assets.fonts, radii: Array.from(radii).slice(0, 20), shadows: Array.from(shadows).slice(0, 20), gradients: Array.from(gradients).slice(0, 20), libraries },
    sections,
    effects: { animations: groupBySig(animations, ['name','duration','delay']).slice(0, 20), transitions: groupBySig(transitions, ['property','duration']).slice(0, 20), keyframes, interaction_rules: interactionRules },
    assets,
    originality_guardrails: [
      'Use this as an inspiration/design inventory, not as permission to copy a competitor pixel-perfect.',
      'Do not reuse proprietary images, icons, brand colors, copy, or exact class names from third-party sites.',
      'Rebuild original components that borrow patterns: hierarchy, motion timing, spacing rhythm, and interaction ideas.'
    ]
  };
}
"""


def _trim_decomposition(result: dict[str, Any], detail: str) -> dict[str, Any]:
    if detail == "full" or not isinstance(result, dict):
        return result
    out = dict(result)
    sections = result.get("sections") or []
    if detail == "summary":
        out.pop("sections", None)
        if "effects" in out:
            out["effects"] = {k: (v[:3] if isinstance(v, list) else ({} if k == "keyframes" else v)) for k, v in out["effects"].items()}
        return out
    # samples
    out["sections"] = []
    for sec in sections[:5]:
        s = dict(sec)
        s["components"] = (s.get("components") or [])[:5]
        out["sections"].append(s)
    if "effects" in out:
        out["effects"] = {
            "animations": (out["effects"].get("animations") or [])[:8],
            "transitions": (out["effects"].get("transitions") or [])[:8],
            "keyframes": dict(list((out["effects"].get("keyframes") or {}).items())[:5]),
            "interaction_rules": (out["effects"].get("interaction_rules") or [])[:10],
        }
    return out


async def qa_decompose_page(mgr: SessionManager,
                            url: str | None = None,
                            session_id: str | None = None,
                            max_sections: int = 12,
                            max_components_per_section: int = 12,
                            include_screenshots: bool = True,
                            screenshot_sections: int = 6,
                            include_mobile: bool = False,
                            detail: str = "samples",
                            headless: bool = True,
                            browser: str = "chrome") -> dict[str, Any]:
    """Decompose a page into an inspiration-safe design inventory.

    Extracts sections, component styles, backgrounds, pseudo-elements,
    animation/transition patterns, keyframes, hover/focus CSS rules, assets,
    and optional per-section screenshots. It intentionally returns design
    specs/patterns and asset URLs — not copied source code.
    """
    from . import browser_tools

    opened_here = False
    if session_id:
        sid = session_id
    elif url:
        opened = await browser_tools.browser_open(mgr, url=url, headless=headless, browser=browser, locale="he-IL", timezone="Asia/Jerusalem")
        sid = opened["session_id"]
        opened_here = True
    else:
        return {"error": "Provide either url or session_id"}

    async def run_one(label: str) -> dict[str, Any]:
        s = mgr.get(sid)
        await _wait_for_content(s.page)
        result = await s.page.evaluate(_DECOMPOSE_PAGE_JS, {
            "max_sections": max_sections,
            "max_components_per_section": max_components_per_section,
        })
        if include_screenshots:
            shot_dir = _DATA_DIR / "screenshots" / "decompose"
            shot_dir.mkdir(parents=True, exist_ok=True)
            for sec in (result.get("sections") or [])[:max(0, screenshot_sections)]:
                selector = sec.get("selector")
                if not selector:
                    continue
                try:
                    loc = s.page.locator(selector).first
                    await loc.scroll_into_view_if_needed(timeout=2000)
                    p = shot_dir / f"{_safe_name(label)}-section-{sec.get('index', 0)}-{datetime.now().strftime('%Y%m%d-%H%M%S-%f')}.jpg"
                    await loc.screenshot(path=str(p), type="jpeg", quality=82, timeout=5000)
                    sec["screenshot_path"] = str(p)
                except Exception as e:
                    sec["screenshot_error"] = f"{type(e).__name__}: {e}"
        return _trim_decomposition(result, detail)

    try:
        desktop = await run_one("desktop")
        out: dict[str, Any] = {"desktop": desktop}
        if include_mobile:
            await browser_tools.browser_set_viewport(mgr, sid, device="iphone-13")
            await mgr.get(sid).page.wait_for_timeout(250)
            out["mobile"] = await run_one("mobile")
        out["summary"] = {
            "desktop": desktop.get("summary"),
            "mobile": (out.get("mobile") or {}).get("summary") if include_mobile else None,
            "guardrail": "Use for inspiration/original implementation; do not copy third-party proprietary code/assets pixel-perfect.",
        }
        return out
    finally:
        if opened_here:
            await browser_tools.browser_close(mgr, sid)


# ---------- component extractor ----------


async def qa_extract_elements(mgr: SessionManager, session_id: str,
                              max_elements: int = 50,
                              max_depth: int = 3,
                              selectors: list[str] | None = None,
                              include_children: bool = True,
                              inline_images: bool = True) -> dict[str, Any]:
    """Extract pixel-level UI components with exact CSS for recreation."""
    from .component_extractor import qa_extract_elements as _extract
    return await _extract(mgr, session_id, max_elements=max_elements,
                          max_depth=max_depth, selectors=selectors,
                          include_children=include_children, inline_images=inline_images)


def qa_diff_elements(a: dict[str, Any], b: dict[str, Any]) -> dict[str, Any]:
    """Compare two extracted elements, return style differences."""
    from .component_extractor import diff_elements as _diff
    return _diff(a, b)


def qa_element_to_tailwind(element: dict[str, Any]) -> dict[str, Any]:
    """Convert extracted element styles to Tailwind CSS classes."""
    from .component_extractor import element_to_tailwind as _tw
    return _tw(element)


# ---------- HTML exporter ----------


def qa_export_to_html(extracted: dict[str, Any], output_path: str,
                      title: str = "Exported Design — qa-mcp") -> dict[str, Any]:
    """Export extracted DOM to a standalone HTML file.

    Takes the raw extraction output from browser_evaluate (the full DOM
    tree with getComputedStyle) and generates pixel-perfect HTML with
    inline CSS, Tailwind CDN, and Google Fonts for every font family.

    Returns { path, sections_count, fonts_detected }.
    """
    from .html_exporter import export_to_html
    path = export_to_html(extracted, output_path, title=title)
    fonts = set()
    for sec in extracted.get("sections", []):
        ff = (sec.get("styles") or {}).get("fontFamily")
        if ff:
            fonts.add(ff)
    return {
        "path": path,
        "sections_count": len(extracted.get("sections", [])),
        "fonts_detected": sorted(fonts),
    }
