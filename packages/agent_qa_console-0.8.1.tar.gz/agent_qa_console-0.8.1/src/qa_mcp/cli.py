"""CLI mode — direct invocation without an MCP client.

`agent-qa-console` doubles as a stdio MCP server (no args / `serve`) and
as a plain CLI for one-off audits. The legacy `qa-mcp` command remains as a
backward-compatible alias. No LLM, no API keys.
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

from .browser import SessionManager
from .tools import browser_tools, qa_tools


SEVERITY_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
SEVERITY_LABEL = {
    "critical": "🔴 critical", "high": "🟠 high", "medium": "🟡 medium",
    "low": "🔵 low", "info": "⚪ info",
}


def _print_json(obj: Any) -> None:
    print(json.dumps(obj, indent=2, ensure_ascii=False))


def _print_rtl(audit: dict) -> None:
    s = audit.get("summary", {})
    page = audit.get("page", {})
    print(f"\n📋 RTL audit — {page.get('url', '?')}")
    print(f"   lang={page.get('lang') or '(none)'}  dir={page.get('dir') or '(none)'}")
    print(f"   Total: {s.get('total', 0)} findings")
    by_sev = s.get("by_severity", {})
    if by_sev:
        parts = [f"{SEVERITY_LABEL.get(k, k)}={v}" for k, v in by_sev.items()]
        print(f"   By severity: {' · '.join(parts)}")
    findings = sorted(audit.get("findings", []),
                      key=lambda f: SEVERITY_ORDER.get(f.get("severity", "info"), 9))
    for i, f in enumerate(findings, 1):
        print(f"\n  {i}. {SEVERITY_LABEL.get(f['severity'], f['severity'])}  [{f['category']}]  {f['title']}")
        if f.get("sample"):
            print(f"     דוגמה: {f['sample']}")
        if f.get("hint"):
            print(f"     תיקון: {f['hint']}")


def _print_links(scan: dict) -> None:
    s = scan.get("summary", {})
    print(f"\n🔗 Links — {scan.get('count', 0)} clickables  "
          f"(internal={s.get('internal',0)}, external={s.get('external',0)}, "
          f"buttons={s.get('buttons',0)}, flagged={s.get('flagged',0)})")
    for it in [i for i in scan.get("items", []) if i.get("flags")][:30]:
        print(f"   ⚠ [{', '.join(it['flags'])}] {it.get('text','(no text)')!r}  "
              f"href={it.get('href')!r}")


def _print_perf(perf: dict) -> None:
    m = perf.get("metrics", {})
    g = perf.get("grades", {})
    grade_emoji = {"good": "🟢", "needs_improvement": "🟡", "poor": "🔴", None: "⚪"}
    print(f"\n⚡ Performance — {perf.get('page', {}).get('url', '?')}")
    for key, label in [("ttfb", "TTFB"), ("fcp", "FCP"), ("lcp", "LCP")]:
        val = m.get(f"{key}_ms")
        gr = g.get(key)
        print(f"   {grade_emoji.get(gr, '⚪')} {label}: {val} ms ({gr or 'n/a'})")
    print(f"   DOM ready: {m.get('dom_content_loaded_ms')}ms · "
          f"Load: {m.get('load_complete_ms')}ms · "
          f"Resources: {m.get('resource_count')}")


def _print_a11y(a11y: dict) -> None:
    if "error" in a11y:
        print(f"\n♿ A11y FAILED: {a11y['error']}")
        return
    s = a11y.get("summary", {})
    print(f"\n♿ A11y (axe-core) — {s.get('total', 0)} violations  "
          f"(passes={a11y.get('passes_count', 0)})")
    for v in a11y.get("violations", [])[:10]:
        print(f"   - [{v.get('impact')}] {v.get('id')}: {v.get('help')}")


# ---------- subcommands ----------


async def cmd_audit(args) -> None:
    """Combined: open + rtl + links + perf + a11y. The CLI's flagship."""
    mgr = SessionManager()
    try:
        s = await browser_tools.browser_open(mgr, url=args.url, headless=args.headless)
        sid = s["session_id"]
        rtl = await qa_tools.qa_rtl_audit(mgr, sid)
        links = await qa_tools.qa_scan_links(mgr, sid)
        perf = await qa_tools.qa_perf_metrics(mgr, sid)
        a11y = None if args.skip_a11y else await qa_tools.qa_a11y_audit(mgr, sid)
        logs = await browser_tools.browser_logs(mgr, sid)

        if args.json:
            _print_json({"rtl": rtl, "links": links, "perf": perf,
                         "a11y": a11y, "browser_logs": logs})
        else:
            _print_rtl(rtl)
            _print_perf(perf)
            _print_links(links)
            if a11y is not None:
                _print_a11y(a11y)
            if logs.get("count", 0):
                print(f"\n🌐 Browser logs ({logs['count']} events):")
                for ev in logs["events"][:10]:
                    print(f"   - [{ev['level']}/{ev['kind']}] {ev['text'][:120]}")
    finally:
        await mgr.close_all()


async def cmd_rtl(args) -> None:
    mgr = SessionManager()
    try:
        s = await browser_tools.browser_open(mgr, url=args.url, headless=args.headless)
        rtl = await qa_tools.qa_rtl_audit(mgr, s["session_id"])
        _print_json(rtl) if args.json else _print_rtl(rtl)
    finally:
        await mgr.close_all()


async def cmd_links(args) -> None:
    mgr = SessionManager()
    try:
        s = await browser_tools.browser_open(mgr, url=args.url, headless=args.headless)
        out = await qa_tools.qa_scan_links(mgr, s["session_id"])
        _print_json(out) if args.json else _print_links(out)
    finally:
        await mgr.close_all()


async def cmd_perf(args) -> None:
    mgr = SessionManager()
    try:
        s = await browser_tools.browser_open(mgr, url=args.url, headless=args.headless)
        out = await qa_tools.qa_perf_metrics(mgr, s["session_id"])
        _print_json(out) if args.json else _print_perf(out)
    finally:
        await mgr.close_all()


async def cmd_a11y(args) -> None:
    mgr = SessionManager()
    try:
        s = await browser_tools.browser_open(mgr, url=args.url, headless=args.headless)
        out = await qa_tools.qa_a11y_audit(mgr, s["session_id"])
        _print_json(out) if args.json else _print_a11y(out)
    finally:
        await mgr.close_all()


async def cmd_shot(args) -> None:
    mgr = SessionManager()
    try:
        s = await browser_tools.browser_open(mgr, url=args.url, headless=args.headless)
        shot = await browser_tools.browser_screenshot(
            mgr, s["session_id"], full_page=args.full, save_to=args.out,
        )
        print(f"📸 Saved {Path(shot['path']).absolute()} ({shot['size_bytes']:,} bytes)")
    finally:
        await mgr.close_all()


def cmd_run(args) -> int:
    """agent-qa-console run qa.config.json — CI mode. Exit code 0 = pass, 1 = threshold violated."""
    from . import suite as _suite
    code = _suite.cli_run(args.config, on_progress=lambda m: print(m))
    return code


def cmd_issues(args) -> int:
    """Export actionable findings from qa-result.json into Markdown issue files."""
    from . import suite as _suite
    p = Path(args.result_json)
    if not p.exists():
        print(f"[agent-qa-console] result JSON not found: {args.result_json}", file=sys.stderr)
        return 2
    data = json.loads(p.read_text(encoding="utf-8"))
    out = _suite.emit_issue_files(data, args.out)
    print(f"[agent-qa-console] Issues → {out['out_dir']} ({out['count']} files)")
    print(f"[agent-qa-console] Index  → {out['index']}")
    return 0


def cmd_github_issues(args) -> int:
    """Create real GitHub Issues from qa-result.json actionable findings."""
    from .github_issues import GitHubError, create_github_issues_from_file
    try:
        out = create_github_issues_from_file(
            result_json=args.result_json,
            repo=args.repo,
            dry_run=args.dry_run,
            api_url=args.api_url,
            comment_existing=args.comment_existing,
        )
    except GitHubError as e:
        print(f"[agent-qa-console] GitHub error: {e}", file=sys.stderr)
        return 2
    _print_json(out)
    if args.dry_run:
        print(f"[agent-qa-console] dry-run: would create {out.get('planned', 0)} issues for {args.repo}")
    else:
        print(f"[agent-qa-console] GitHub issues: created={out.get('created', 0)} skipped_existing={out.get('skipped_existing', 0)}")
    return 0


def cmd_client_report(args) -> int:
    """Create a polished client-facing ZIP report from qa-result.json."""
    from .client_report import create_client_report_zip
    out = create_client_report_zip(
        result_json=args.result_json,
        out_zip=args.out,
        client=args.client,
        consultant=args.consultant,
    )
    _print_json(out)
    print(f"[agent-qa-console] Client report ZIP → {out['zip_path']}")
    return 0


def _run_agent_command(agent: str, argv: list[str], *, already_ok: str | None = None) -> bool:
    exe = shutil.which(argv[0])
    if not exe:
        print(f"⚠️  {agent}: '{argv[0]}' was not found on PATH. Skipping.")
        return False
    proc = subprocess.run(argv, text=True, capture_output=True)
    out = ((proc.stdout or "") + "\n" + (proc.stderr or "")).strip()
    if proc.returncode == 0:
        print(f"✅ {agent}: configured")
        return True
    if already_ok and already_ok.lower() in out.lower():
        print(f"ℹ️  {agent}: already configured")
        return True
    print(f"❌ {agent}: failed\n{out}")
    return False


def _load_json_file(path: Path) -> dict:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        raise SystemExit(f"Cannot update {path}: invalid JSON ({e})") from e


def _write_json_file(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def _setup_cursor(name: str, command: str) -> bool:
    path = Path.home() / ".cursor" / "mcp.json"
    data = _load_json_file(path)
    data.setdefault("mcpServers", {})[name] = {"command": command}
    _write_json_file(path, data)
    print(f"✅ Cursor: configured {name} in {path}")
    return True


def _setup_opencode(name: str, command: str) -> bool:
    # OpenCode's global config is documented at ~/.config/opencode/opencode.json.
    # It accepts local MCP servers under the top-level `mcp` object.
    path = Path(os.environ.get("OPENCODE_CONFIG", Path.home() / ".config" / "opencode" / "opencode.json"))
    data = _load_json_file(path)
    data.setdefault("$schema", "https://opencode.ai/config.json")
    data.setdefault("mcp", {})[name] = {
        "type": "local",
        "command": [command],
        "enabled": True,
    }
    _write_json_file(path, data)
    print(f"✅ OpenCode: configured {name} in {path}")
    return True


def _setup_pi(pi_source: str) -> bool:
    # Pi uses packages/extensions rather than MCP JSON. The npm package wraps
    # Agent QA Console with native Pi tools. Local development can pass
    # --pi-source . or --pi-source C:/path/to/agent-qa-console.
    return _run_agent_command("Pi", ["pi", "install", pi_source], already_ok="already")


async def cmd_init(args) -> None:
    """Interactive setup wizard for first-time users."""
    if not sys.stdin.isatty():
        raise SystemExit("agent-qa-console init requires an interactive terminal. Use: agent-qa-console setup all")

    try:
        import questionary
    except ImportError as e:
        raise SystemExit("The init wizard requires questionary. Reinstall with: pipx upgrade agent-qa-console") from e

    agents = [
        ("all", "All detected/supported agents"),
        ("claude-code", "Claude Code"),
        ("codex", "Codex"),
        ("gemini", "Gemini CLI"),
        ("opencode", "OpenCode"),
        ("cursor", "Cursor"),
        ("pi", "Pi"),
        ("browser", "Browser runtime only"),
    ]

    print("\nAgent QA Console setup\n")
    print("Detected on PATH:")
    for key, label in agents[1:7]:
        exe = "claude" if key == "claude-code" else key
        status = "installed" if shutil.which(exe) else ("config file" if key == "cursor" else "not found")
        print(f"  - {label}: {status}")
    print("")

    target = questionary.select(
        "What do you want to configure?",
        choices=[f"{key} - {label}" for key, label in agents],
        default="all - All detected/supported agents",
    ).ask()
    if not target:
        raise SystemExit("Setup cancelled.")
    target_key = target.split(" - ", 1)[0]

    name = questionary.text("MCP server name:", default=getattr(args, "name", "qa")).ask() or "qa"
    command = questionary.text("MCP command:", default=getattr(args, "command", "agent-qa-console")).ask() or "agent-qa-console"
    pi_source = getattr(args, "pi_source", "npm:@brainboxai/agent-qa-console-pi")
    if target_key in {"all", "pi"}:
        pi_source = questionary.text("Pi package source:", default=pi_source).ask() or pi_source

    setup_args = argparse.Namespace(target=target_key, name=name, command=command, pi_source=pi_source)
    await cmd_setup(setup_args)


async def cmd_setup(args) -> None:
    """Install local runtime dependencies and optionally register agent integrations."""
    from .browser import _install_chromium_async
    from playwright.async_api import async_playwright, Error

    target = getattr(args, "target", "browser")
    command = getattr(args, "command", "agent-qa-console")
    name = getattr(args, "name", "qa")
    pi_source = getattr(args, "pi_source", "npm:@brainboxai/agent-qa-console-pi")

    print("[agent-qa-console] Checking Playwright Chromium...")
    pw = await async_playwright().start()
    try:
        try:
            b = await pw.chromium.launch(headless=True)
            await b.close()
            print("✅ Chromium already installed.")
        except Error:
            await _install_chromium_async()
            print("✅ Chromium installed.")
    finally:
        await pw.stop()

    if target in {"browser", "playwright"}:
        return

    targets = ["claude-code", "codex", "gemini", "opencode", "cursor", "pi"] if target == "all" else [target]
    ok = 0
    total = 0

    for item in targets:
        total += 1
        if item == "claude-code":
            ok += int(_run_agent_command("Claude Code", ["claude", "mcp", "add", name, command], already_ok="already"))
        elif item == "codex":
            ok += int(_run_agent_command("Codex", ["codex", "mcp", "add", name, "--", command], already_ok="already"))
        elif item == "gemini":
            ok += int(_run_agent_command("Gemini", ["gemini", "mcp", "add", name, command], already_ok="already"))
        elif item == "opencode":
            ok += int(_setup_opencode(name, command))
        elif item == "cursor":
            ok += int(_setup_cursor(name, command))
        elif item == "pi":
            ok += int(_setup_pi(pi_source))
        else:
            raise SystemExit(f"Unknown setup target: {item}")

    print(f"\n[agent-qa-console] Setup complete: {ok}/{total} integrations configured.")
    print("Try asking your agent:")
    print("  Open Agent QA Console for http://localhost:3000 and run RTL, a11y, links and asset audits.")


# ---------- dispatcher ----------


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="agent-qa-console",
        description=(
            "agent-qa-console — bare command runs an MCP server over stdio for AI agents.\n"
            "Use `agent-qa-console init` for an interactive setup wizard.\n"
            "With a subcommand, runs as a plain CLI for one-off audits.\n\n"
            "No LLM, no API keys required."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sub = p.add_subparsers(dest="cmd")

    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("url")
    common.add_argument("--no-headless", dest="headless", action="store_false",
                        default=True, help="Show the browser window")
    common.add_argument("--json", action="store_true",
                        help="Print raw JSON instead of human-readable")

    pa = sub.add_parser("audit", parents=[common],
                        help="Full audit: RTL + links + perf + a11y")
    pa.add_argument("--skip-a11y", action="store_true", help="Skip axe-core scan")

    sub.add_parser("rtl", parents=[common], help="RTL/Hebrew audit")
    sub.add_parser("links", parents=[common], help="Inventory of clickables")
    sub.add_parser("perf", parents=[common], help="Web Vitals")
    sub.add_parser("a11y", parents=[common], help="Accessibility (axe-core)")

    pshot = sub.add_parser("shot", parents=[common], help="Save a screenshot to disk")
    pshot.add_argument("--out", default="screenshot.jpg")
    pshot.add_argument("--full", action="store_true", help="Full-page screenshot")

    prun = sub.add_parser("run", help="CI mode — run a qa.config.json suite")
    prun.add_argument("config", help="Path to qa.config.json")

    pissues = sub.add_parser("issues", help="Export qa-result.json actionable findings to Markdown issue files")
    pissues.add_argument("result_json", help="Path to qa-result.json produced by agent-qa-console run")
    pissues.add_argument("--out", default="qa-issues", help="Output directory for issue .md files")

    pgh = sub.add_parser("github-issues", help="Create real GitHub Issues from qa-result.json findings")
    pgh.add_argument("result_json", help="Path to qa-result.json produced by agent-qa-console run")
    pgh.add_argument("--repo", required=True, help="GitHub repo as OWNER/REPO")
    pgh.add_argument("--dry-run", action="store_true", help="Preview without network calls or issue creation")
    pgh.add_argument("--api-url", default="https://api.github.com", help="GitHub API URL, for GitHub Enterprise")
    pgh.add_argument("--comment-existing", action="store_true", help="Comment on existing open issues when a finding repeats")

    pclient = sub.add_parser("client-report", help="Create a polished client-facing ZIP report from qa-result.json")
    pclient.add_argument("result_json", help="Path to qa-result.json produced by agent-qa-console run")
    pclient.add_argument("--out", required=True, help="Output ZIP path")
    pclient.add_argument("--client", default=None, help="Client/project name for the report")
    pclient.add_argument("--consultant", default="BrainboxAI", help="Consultant/company name")

    ppdf = sub.add_parser("pdf", help="Create branded PDF report from qa-result.json")
    ppdf.add_argument("result_json", help="Path to qa-result.json")
    ppdf.add_argument("--out", default="qa-report.pdf", help="Output PDF path")
    ppdf.add_argument("--client", default=None)
    ppdf.add_argument("--consultant", default="BrainboxAI")

    pslack = sub.add_parser("slack", help="Post QA summary to Slack")
    pslack.add_argument("result_json", help="Path to qa-result.json")
    pslack.add_argument("--webhook-url", required=True, help="Slack Incoming Webhook URL")
    pslack.add_argument("--channel", default=None)
    pslack.add_argument("--max-findings", type=int, default=5)

    pinit = sub.add_parser("init", help="Interactive first-run setup wizard")
    pinit.add_argument("--name", default="qa", help="MCP server/tool name")
    pinit.add_argument("--command", default="agent-qa-console", help="MCP command agents should run")
    pinit.add_argument("--pi-source", default="npm:@brainboxai/agent-qa-console-pi", help="Pi package source for `pi install`")

    psetup = sub.add_parser("setup", help="Install browser runtime and optional agent integrations")
    psetup.add_argument(
        "target",
        nargs="?",
        default="browser",
        choices=["browser", "playwright", "claude-code", "codex", "gemini", "opencode", "cursor", "pi", "all"],
        help="What to set up: browser/playwright only, one agent integration, or all supported agents",
    )
    psetup.add_argument("--name", default="qa", help="MCP server/tool name")
    psetup.add_argument("--command", default="agent-qa-console", help="MCP command agents should run")
    psetup.add_argument("--pi-source", default="npm:@brainboxai/agent-qa-console-pi", help="Pi package source for `pi install`")
    sub.add_parser("serve", help="Run as MCP stdio server (default if no subcommand)")
    return p


def run_cli(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if not args.cmd or args.cmd == "serve":
        from .server import mcp
        mcp.run(transport="stdio")
        return 0
    # `run` / `issues` are sync and return exit codes.
    if args.cmd == "run":
        return cmd_run(args)
    if args.cmd == "issues":
        return cmd_issues(args)
    if args.cmd == "github-issues":
        return cmd_github_issues(args)
    if args.cmd == "client-report":
        return cmd_client_report(args)

    # Sync handlers (return exit codes)
    if args.cmd == "pdf":
        from .pdf_export import create_client_report_pdf
        out = create_client_report_pdf(args.result_json, args.out, args.client, args.consultant)
        _print_json(out)
        return 0
    if args.cmd == "slack":
        from .slack import notify_slack
        import json as _json
        suite = _json.loads(Path(args.result_json).read_text(encoding="utf-8"))
        out = notify_slack(args.webhook_url, suite, channel=args.channel, max_findings=args.max_findings)
        _print_json(out)
        return 0 if out.get("ok") else 1

    handlers = {
        "audit": cmd_audit, "rtl": cmd_rtl, "links": cmd_links,
        "perf": cmd_perf, "a11y": cmd_a11y, "shot": cmd_shot,
        "init": cmd_init, "setup": cmd_setup,
    }
    try:
        asyncio.run(handlers[args.cmd](args))
        return 0
    except KeyboardInterrupt:
        return 130
    except Exception as e:
        print(f"❌ {type(e).__name__}: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(run_cli())
