"""Playwright-backed session manager. No LLM, no agent — pure browser control.

The calling agent (Claude Code / Codex / Cursor / etc.) provides all the
intelligence; this layer just runs commands and exposes structured DOM /
log / screenshot data.

First-run UX: if Chromium isn't installed, we auto-install on first launch.
Users only need `pipx install agent-qa-console` — no separate browser-install step.
"""
from __future__ import annotations

import asyncio
import sys
import time
import uuid
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Optional

if TYPE_CHECKING:
    from playwright.async_api import (
        Browser,
        BrowserContext,
        Page,
        Playwright,
    )

from .tools.stealth import (
    apply_stealth,
    STEALTH_CHROMIUM_ARGS,
    STEALTH_DEFAULT_UA,
)


# ---------- log buffer ----------


@dataclass
class LogEvent:
    ts: float
    kind: str  # "console" | "exception" | "http" | "network_failed"
    level: str  # "error" | "warning" | "info"
    text: str
    url: Optional[str] = None
    status: Optional[int] = None
    likely_cause: Optional[str] = None  # e.g. "cross_origin_script_without_cors"
    hint: Optional[str] = None

    def to_dict(self) -> dict:
        d = {"ts": round(self.ts, 3), "kind": self.kind, "level": self.level, "text": self.text}
        if self.url:
            d["url"] = self.url
        if self.status is not None:
            d["status"] = self.status
        if self.likely_cause:
            d["likely_cause"] = self.likely_cause
        if self.hint:
            d["hint"] = self.hint
        return d


def _enrich_exception(text: str) -> tuple[Optional[str], Optional[str]]:
    """If a generic 'Script error.' came in (CORS-blocked external script),
    annotate with a likely cause + actionable hint."""
    t = (text or "").strip().lower()
    if t.startswith("script error") and len(t) < 30:
        return (
            "cross_origin_script_without_cors",
            "Script likely loaded from another origin without CORS headers. "
            "Add crossorigin=\"anonymous\" to the <script> tag and serve the "
            "script with Access-Control-Allow-Origin to see the real error.",
        )
    return None, None


# Third-party analytics / tracking that drown out real bugs in browser_logs.
# Round 6 review caught 8 ERR_NAME_NOT_RESOLVED on log.optimizely.com burying
# 2 real 404s on broken images. Extended liberally — false-positive cost of
# filtering an analytics call is zero, false-negative cost of hiding a real
# bug is high.
NOISY_HOSTS = (
    # Google
    "google-analytics.com", "googletagmanager.com", "doubleclick.net",
    "googlesyndication.com", "googleadservices.com",
    # Meta / Facebook
    "facebook.com/tr", "facebook.net", "connect.facebook.net",
    # Microsoft / Bing
    "clarity.ms", "bat.bing.com",
    # Optimizely
    "optimizely.com", "log.optimizely.com",
    # Product analytics
    "segment.io", "segment.com", "mixpanel.com", "amplitude.com",
    "heap.io", "heapanalytics.com", "pendo.io",
    # Session replay / heatmaps
    "hotjar.com", "fullstory.com", "crazyegg.com", "mouseflow.com",
    "smartlook.com",
    # CRM / marketing
    "intercom.io", "intercomcdn.com", "hubspot.com", "hs-scripts.com",
    "hs-analytics.net", "pardot.com",
    # Error reporting (intentional separate service, often noisy on dev sites)
    "sentry.io", "bugsnag.com", "rollbar.com", "datadoghq.com",
    "newrelic.com",
    # Tag managers
    "tagmanager.google.com", "tealiumiq.com", "ensighten.com",
)


def _is_noisy(url: str) -> bool:
    return any(h in url for h in NOISY_HOSTS)


# ---------- browser auto-install ----------


_CHROMIUM_FAMILY = {"chromium", "chrome", "chrome-beta", "msedge", "msedge-beta", "cloak"}


def _normalize_browser_engine(browser: str | None) -> str:
    """Use real branded Chrome by default for QA.

    Playwright's bundled ``chromium`` identifies as a testing browser and can
    trigger Google/OAuth/CAPTCHA flows. Agent QA Console intentionally aliases
    ``chromium`` to the installed stable Chrome channel unless a caller chooses
    another browser family explicitly (webkit/firefox/msedge/etc.).
    """
    if not browser or browser == "chromium":
        return "chrome"
    return browser


def _is_chromium_family(browser: str) -> bool:
    return browser in _CHROMIUM_FAMILY


_CHROMIUM_MISSING_MARKERS = (
    "Executable doesn't exist",
    "playwright install",
    "browser was not installed",
)


async def _install_browser_async(browser: str = "chromium") -> None:
    sizes = {
        "chromium": "~150MB", "chrome": "system/stable Chrome", "chrome-beta": "system/beta Chrome",
        "msedge": "system/stable Edge", "msedge-beta": "system/beta Edge",
        "cloak": "~200MB stealth Chromium",
        "webkit": "~80MB", "firefox": "~80MB",
    }
    size = sizes.get(browser, "")
    print(f"[agent-qa-console] First-run setup: downloading {browser} ({size}, one-time)...",
          file=sys.stderr, flush=True)
    proc = await asyncio.create_subprocess_exec(
        sys.executable, "-m", "playwright", "install", browser,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    out, err = await proc.communicate()
    if proc.returncode != 0:
        raise RuntimeError(
            f"Auto-install failed (exit {proc.returncode}). "
            f"Run manually: python -m playwright install {browser}\n"
            f"stderr: {err.decode(errors='replace')[:500]}"
        )
    print(f"[agent-qa-console] {browser} ready.", file=sys.stderr, flush=True)


# Back-compat alias
_install_chromium_async = _install_browser_async


# ---------- session ----------


NETWORK_PRESETS: dict[str, dict[str, float]] = {
    # Throughputs in bytes/sec (Chromium CDP units).
    "offline":  {"offline": True,  "downloadThroughput": 0,        "uploadThroughput": 0,        "latency": 0},
    "slow_3g":  {"offline": False, "downloadThroughput": 50_000,   "uploadThroughput": 50_000,   "latency": 2000},
    "fast_3g":  {"offline": False, "downloadThroughput": 180_000,  "uploadThroughput": 84_000,   "latency": 562},
    "4g":       {"offline": False, "downloadThroughput": 4_000_000,"uploadThroughput": 3_000_000,"latency": 20},
    "wifi":     {"offline": False, "downloadThroughput": -1,       "uploadThroughput": -1,       "latency": 0},
}


async def _apply_network_throttle(page: "Page", network: str | dict) -> None:
    """Apply network conditions via CDP. Chromium only."""
    cdp = await page.context.new_cdp_session(page)
    if isinstance(network, str):
        params = NETWORK_PRESETS.get(network)
        if not params:
            raise ValueError(f"unknown network preset '{network}'. "
                             f"Choices: {list(NETWORK_PRESETS)}")
    else:
        params = {
            "offline": network.get("offline", False),
            "downloadThroughput": float(network.get("downloadThroughput", -1)),
            "uploadThroughput": float(network.get("uploadThroughput", -1)),
            "latency": float(network.get("latency", 0)),
        }
    await cdp.send("Network.enable")
    await cdp.send("Network.emulateNetworkConditions", params)


@dataclass
class Session:
    id: str
    browser: Browser
    context: BrowserContext
    page: Page
    logs: list[LogEvent] = field(default_factory=list)
    max_logs: int = 200
    browser_engine: str = "chromium"
    # Anti-detection patches applied (keys: webdriver, plugins, mime_types,
    # chrome_runtime, webgl, permissions, hardware). Only populated when
    # the session was opened with stealth=True.
    stealth: dict[str, bool] = field(default_factory=dict)
    # CDP session used by stealth to issue low-level browser commands
    # (e.g. Page.addScriptToEvaluateOnNewDocument for pre-JS patches).
    _cdp: Any | None = None
    # Dialog handling — see browser_handle_dialog. Default behavior is
    # auto-dismiss + capture into last_dialog so the agent isn't blocked.
    pending_dialog_action: str = "dismiss"
    pending_prompt_text: str | None = None
    last_dialog: dict | None = None
    # Frame routing — populated by browser_get_state when walking iframes.
    # Maps element index → frame URL so subsequent click/type/etc can target
    # the correct frame (otherwise contenteditable inside <iframe> is unreachable).
    frame_map: dict[int, str] = field(default_factory=dict)
    # Last indexed elements with screen-space boxes. Used by the workspace UI
    # to show a visible cursor where the agent clicked/typed/hovered.
    last_elements_by_index: dict[int, dict[str, Any]] = field(default_factory=dict)
    # Cache for RTL findings — populated by qa_rtl_audit, consumed by
    # qa_fix_suggestions without re-running the audit.
    _last_rtl_findings: list[dict[str, Any]] = field(default_factory=list)

    def push_log(self, ev: LogEvent) -> None:
        self.logs.append(ev)
        if len(self.logs) > self.max_logs:
            self.logs.pop(0)


# ---------- manager ----------


class SessionManager:
    """One per server process. Owns Playwright + a dict of Sessions."""

    def __init__(self):
        self._pw: Playwright | None = None
        self._sessions: dict[str, Session] = {}
        self._lock = asyncio.Lock()

    async def _ensure_pw(self) -> "Playwright":
        if self._pw is None:
            from playwright.async_api import async_playwright
            self._pw = await async_playwright().start()
        return self._pw

    async def _launch_browser(self, pw: Playwright, browser: str,
                              headless: bool,
                              extra_args: list[str] | None = None) -> Browser:
        """Launch Chromium-family / WebKit / Firefox. Auto-installs the
        engine on first run where Playwright supports it."""
        if browser == "cloak":
            try:
                from cloakbrowser import launch_async as launch_cloak_async
            except ImportError as exc:
                raise RuntimeError(
                    "browser='cloak' requires CloakBrowser. Install it with: "
                    "pip install cloakbrowser"
                ) from exc
            return await launch_cloak_async(
                headless=headless,
                args=extra_args,
            )

        engine = {
            "chromium": pw.chromium,
            "chrome": pw.chromium,
            "chrome-beta": pw.chromium,
            "msedge": pw.chromium,
            "msedge-beta": pw.chromium,
            "webkit": pw.webkit,
            "firefox": pw.firefox,
        }.get(browser)
        if engine is None:
            raise ValueError(f"unknown browser '{browser}'. "
                             f"Choices: chromium | chrome | chrome-beta | msedge | msedge-beta | cloak | webkit | firefox")
        launch_opts: dict[str, Any] = {"headless": headless}
        if browser != "chromium" and _is_chromium_family(browser):
            launch_opts["channel"] = browser
        if extra_args and _is_chromium_family(browser):
            launch_opts["args"] = extra_args
        from playwright.async_api import Error as PlaywrightError
        try:
            return await engine.launch(**launch_opts)
        except PlaywrightError as e:
            if not any(m in str(e) for m in _CHROMIUM_MISSING_MARKERS):
                raise
            await _install_browser_async(browser)
            return await engine.launch(**launch_opts)

    async def open(self, url: str | None = None, headless: bool = True,
                   viewport: dict | None = None,
                   geolocation: dict | None = None,
                   timezone: str | None = None,
                   locale: str | None = None,
                   user_agent: str | None = None,
                   browser_engine: str = "chrome",
                   network: str | dict | None = None,
                   stealth: bool = True,
                   ) -> tuple[Session, list[dict]]:
        """Open a session. Supports chrome (default), chromium, branded Chrome/Edge
        channels, cloak (CloakBrowser stealth Chromium), webkit (Safari), and firefox.
        If `url` is given, tracks redirect chain.

        `network` (optional): throttle network. Preset string ('slow_3g',
        'fast_3g', '4g', 'wifi', 'offline') or dict with downloadThroughput,
        uploadThroughput, latency. Applied via CDP (Chromium only).

        `stealth` (default True): apply anti-detection patches (hide
        navigator.webdriver, populate plugins/mimeTypes, realistic WebGL
        vendor, expose window.chrome). Required for sites behind Cloudflare
        and other CDN bot protection. Set False for internal/CI sites where
        bot detection is irrelevant.
        """
        browser_engine = _normalize_browser_engine(browser_engine)

        async with self._lock:
            pw = await self._ensure_pw()

        # When stealth is enabled:
        #  - Layer 1: Chromium launch args hide AutomationControlled
        #  - Layer 2: Default realistic Chrome UA (unless user overrides)
        #  - Layer 3: CDP addScriptToEvaluateOnNewDocument runs before
        #    any page JS — the strongest JS-level defense.
        #  - Layer 4: init script fallback (always applied).
        launch_args = STEALTH_CHROMIUM_ARGS if stealth and _is_chromium_family(browser_engine) else None
        browser = await self._launch_browser(
            pw, browser_engine, headless, extra_args=launch_args,
        )

        ctx_opts: dict[str, Any] = {
            "viewport": viewport or {"width": 1366, "height": 900},
        }
        if geolocation:
            ctx_opts["geolocation"] = geolocation
            ctx_opts["permissions"] = ["geolocation"]
        if timezone:
            ctx_opts["timezone_id"] = timezone
        if locale:
            ctx_opts["locale"] = locale
        # Use stealth default UA when no custom UA given and stealth is on.
        # Chromium's bundled UA string is a dead giveaway to CDN detectors.
        if user_agent:
            ctx_opts["user_agent"] = user_agent
        elif stealth and _is_chromium_family(browser_engine):
            ctx_opts["user_agent"] = STEALTH_DEFAULT_UA

        context = await browser.new_context(**ctx_opts)
        page = await context.new_page()

        # Anti-detection: Layer 3 (CDP) + Layer 4 (init script fallback).
        stealth_result: dict[str, bool] = {}
        if stealth:
            stealth_result["launch_args"] = launch_args is not None
            stealth_result["user_agent"] = ctx_opts.get("user_agent") == STEALTH_DEFAULT_UA
            # Open CDP session for Page.addScriptToEvaluateOnNewDocument
            cdp = await context.new_cdp_session(page) if _is_chromium_family(browser_engine) else None
            stealth_result.update(await apply_stealth(page, cdp_session=cdp))

        session = Session(id=str(uuid.uuid4()), browser=browser,
                          context=context, page=page)
        session.browser_engine = browser_engine
        if stealth_result:
            session.stealth = stealth_result
        self._wire_logs(session)

        # Apply network throttling BEFORE navigation so the goto sees throttled net.
        if network and _is_chromium_family(browser_engine):
            await _apply_network_throttle(page, network)
        elif network:
            print(f"[agent-qa-console] network throttling requested but only "
                  f"Chromium-family browsers support CDP-based throttling; got {browser_engine}",
                  file=sys.stderr, flush=True)

        redirect_chain: list[dict] = []
        if url:
            # Track client-side hops too — symmetric with browser_navigate so
            # the agent gets consistent results either way.
            client_hops: list[dict] = []
            last_url: list[str | None] = [None]

            def on_framenavigated(frame):
                if frame is not page.main_frame:
                    return
                u = frame.url
                if last_url[0] is not None and u != last_url[0] and u != "about:blank":
                    client_hops.append({"from": last_url[0], "to": u, "kind": "client_side"})
                last_url[0] = u

            page.on("framenavigated", on_framenavigated)
            try:
                response = await page.goto(url, wait_until="domcontentloaded")
            finally:
                page.remove_listener("framenavigated", on_framenavigated)

            if response is not None:
                req = response.request
                prev = req.redirected_from
                while prev is not None:
                    try:
                        prev_resp = await prev.response()
                        status = prev_resp.status if prev_resp else None
                    except Exception:
                        status = None
                    redirect_chain.insert(0, {
                        "from": prev.url, "to": req.url,
                        "status": status, "kind": "http",
                    })
                    req = prev
                    prev = req.redirected_from
            for hop in client_hops:
                if hop["from"] == hop["to"]:
                    continue
                if hop["from"] in ("about:blank", "", None):
                    continue
                redirect_chain.append(hop)

        self._sessions[session.id] = session
        return session, redirect_chain

    def get(self, session_id: str) -> Session:
        s = self._sessions.get(session_id)
        if not s:
            raise KeyError(f"unknown session_id: {session_id}")
        return s

    async def close(self, session_id: str) -> None:
        s = self._sessions.pop(session_id, None)
        if not s:
            return
        try:
            await s.context.close()
        except Exception:
            pass
        try:
            await s.browser.close()
        except Exception:
            pass

    async def close_all(self) -> None:
        for sid in list(self._sessions.keys()):
            await self.close(sid)
        if self._pw:
            try:
                await self._pw.stop()
            except Exception:
                pass
            self._pw = None

    # ---------- log wiring ----------

    def _wire_logs(self, s: Session) -> None:
        page = s.page

        def on_console(msg) -> None:
            level = msg.type
            if level not in ("error", "warning"):
                return
            text = msg.text[:500]
            s.push_log(LogEvent(ts=time.time(), kind="console", level=level, text=text))

        def on_pageerror(err) -> None:
            text = (str(err) or "(no message)")[:500]
            cause, hint = _enrich_exception(text)
            s.push_log(LogEvent(
                ts=time.time(), kind="exception", level="error", text=text,
                likely_cause=cause, hint=hint,
            ))

        def on_response(resp) -> None:
            try:
                status = resp.status
                if status < 400:
                    return
                url = resp.url
                if _is_noisy(url):
                    return
                s.push_log(LogEvent(
                    ts=time.time(), kind="http", level="error",
                    text=f"{status} {url}", url=url, status=status,
                ))
            except Exception:
                pass

        def on_requestfailed(req) -> None:
            try:
                err = req.failure
                if not err or "ERR_ABORTED" in err:
                    return
                # Same blocklist as HTTP responses — Optimizely DNS errors
                # were drowning out real bugs (Round 6).
                if _is_noisy(req.url):
                    return
                s.push_log(LogEvent(
                    ts=time.time(), kind="network_failed", level="error",
                    text=err, url=req.url,
                ))
            except Exception:
                pass

        def on_dialog(d) -> None:
            # Always-on handler. Without this the page hangs on alert()/
            # confirm()/prompt() and click() returns a misleading "success"
            # while the test is silently blocked.
            info = {
                "type": d.type,
                "message": d.message,
                "default_value": getattr(d, "default_value", None) or "",
            }
            action = s.pending_dialog_action or "dismiss"
            info["result"] = action
            s.last_dialog = info
            try:
                if action == "accept":
                    asyncio.create_task(d.accept(s.pending_prompt_text or ""))
                else:
                    asyncio.create_task(d.dismiss())
            except Exception:
                pass
            # Reset to default after each dialog (one-shot semantics for accept)
            s.pending_dialog_action = "dismiss"
            s.pending_prompt_text = None

        page.on("console", on_console)
        page.on("pageerror", on_pageerror)
        page.on("response", on_response)
        page.on("requestfailed", on_requestfailed)
        page.on("dialog", on_dialog)
