"""qa_run_suite — the CI-mode entry point.

Reads qa.config.json, runs each scenario through Playwright + audits,
collects findings, evaluates thresholds, emits HTML + JUnit reports,
and returns an exit code so CI can gate on failures.

Sample config:

    {
      "name": "voicebox-qa",
      "base_url": "https://voicebox.brainboxai.io",
      "browser": "chrome",
      "scenarios": [
        {
          "name": "homepage",
          "path": "/",
          "audits": ["rtl", "a11y", "perf", "seo"],
          "thresholds": {
            "a11y": { "max_critical": 0, "max_serious": 0 },
            "perf": { "min_score": 80 },
            "rtl":  { "max_high": 0 }
          }
        }
      ],
      "report": { "html": "./qa-report.html", "junit": "./qa-junit.xml" }
    }
"""
from __future__ import annotations

import asyncio
import base64
import html
import json
from datetime import datetime
from pathlib import Path
from typing import Any
from xml.sax.saxutils import escape as xml_escape, quoteattr as xml_quoteattr

from .browser import SessionManager
from .tools import browser_tools, qa_tools
from .tools import security_tools


_AUDIT_FNS = {
    "rtl": qa_tools.qa_rtl_audit,
    "a11y": qa_tools.qa_a11y_audit,
    "perf": qa_tools.qa_perf_metrics,
    "seo": qa_tools.qa_seo_check,
    "links": qa_tools.qa_scan_links,
    "ux": qa_tools.qa_ux_metrics,
    "conversion": qa_tools.qa_conversion_audit,
}

_SEVERITY_RANK = {"critical": 0, "high": 1, "serious": 1, "medium": 2, "moderate": 2, "low": 3, "minor": 3, "info": 4}


def _impact_to_severity(impact: str | None) -> str:
    return {
        "critical": "critical",
        "serious": "high",
        "moderate": "medium",
        "minor": "low",
    }.get(impact or "", "medium")


def _make_repro(url: str, selector: str | None = None, extra: str | None = None) -> list[str]:
    steps = [f"Open {url}"]
    if selector:
        steps.append(f"Inspect element: {selector}")
    if extra:
        steps.append(extra)
    return steps


def _normalize_findings(scn: dict) -> list[dict[str, Any]]:
    """Convert raw audit outputs into issue-like findings an engineer/client can act on.

    The raw JSON is still kept under scn["audits"]. This layer is for reports,
    triage, GitHub issues, and future agent reasoning.
    """
    url = scn.get("url", "")
    out: list[dict[str, Any]] = []
    audits = scn.get("audits", {}) or {}

    for f in (audits.get("rtl") or {}).get("findings", []) or []:
        out.append({
            "source": "rtl",
            "severity": f.get("severity", "medium"),
            "title": f.get("title") or f.get("category") or "RTL issue",
            "category": f.get("category"),
            "evidence": f.get("sample"),
            "selector": f.get("selector"),
            "impact": "Hebrew/RTL users may see confusing or unprofessional BiDi rendering.",
            "fix": f.get("hint") or "Wrap mixed-direction fragments with <bdi> or set explicit dir where needed.",
            "repro_steps": _make_repro(url, f.get("selector"), "Look for the highlighted Hebrew/RTL sample."),
        })

    for v in (audits.get("a11y") or {}).get("violations", []) or []:
        out.append({
            "source": "a11y",
            "severity": _impact_to_severity(v.get("impact")),
            "title": v.get("help") or v.get("id") or "Accessibility violation",
            "category": v.get("id"),
            "evidence": v.get("sample_html"),
            "selector": v.get("sample_target"),
            "impact": v.get("description") or "Users relying on assistive technologies may be blocked.",
            "fix": f"Follow axe guidance: {v.get('helpUrl')}" if v.get("helpUrl") else "Fix according to WCAG 2 A/AA guidance.",
            "repro_steps": _make_repro(url, v.get("sample_target"), "Run an axe-core accessibility scan."),
        })

    for it in (audits.get("links") or {}).get("items", []) or []:
        flags = it.get("flags") or []
        if not flags:
            continue
        out.append({
            "source": "links",
            "severity": "medium" if "button_no_label" in flags else "low",
            "title": f"Clickable element flagged: {', '.join(flags)}",
            "category": "clickable_flags",
            "evidence": it.get("text") or it.get("href") or it.get("selector"),
            "selector": it.get("selector"),
            "impact": "Users may not understand or safely activate this CTA/control.",
            "fix": "Add an accessible label, valid href, noopener for target=_blank, or remove disabled/dead controls as appropriate.",
            "repro_steps": _make_repro(url, it.get("selector"), "Inspect the clickable element and its accessible name/target."),
        })

    for f in (audits.get("conversion") or {}).get("findings", []) or []:
        out.append({
            "source": "conversion",
            "severity": f.get("severity", "medium"),
            "title": f.get("title") or "Conversion blocker",
            "category": f.get("category") or "conversion",
            "evidence": json.dumps(f.get("evidence"), ensure_ascii=False),
            "selector": f.get("selector"),
            "impact": f.get("impact") or "This can reduce leads, signups, or sales.",
            "fix": f.get("fix") or "Make the next revenue action obvious and verify the full flow.",
            "repro_steps": _make_repro(url, f.get("selector"), "Run qa_conversion_audit and inspect the CTA/form evidence."),
        })

    for f in (audits.get("ux") or {}).get("findings", []) or []:
        out.append({
            "source": "ux",
            "severity": f.get("severity", "medium"),
            "title": f.get("title") or f.get("category") or "UX issue",
            "category": f.get("category"),
            "evidence": json.dumps({"evidence": f.get("evidence"), "samples": f.get("samples")}, ensure_ascii=False),
            "selector": f.get("selector") or ((f.get("samples") or [{}])[0].get("selector") if f.get("samples") else None),
            "impact": f.get("impact") or "Users may need extra effort to understand or complete the primary action.",
            "fix": f.get("fix") or "Simplify the page around the primary user goal and re-run qa_ux_metrics.",
            "repro_steps": _make_repro(url, f.get("selector"), "Run qa_ux_metrics and inspect the raw UX metrics/findings."),
        })

    perf = audits.get("perf") or {}
    if perf:
        score = perf.get("score")
        grades = perf.get("grades") or {}
        poor = [k for k, v in grades.items() if v == "poor"]
        needs = [k for k, v in grades.items() if v == "needs_improvement"]
        if (score is not None and score < 80) or poor or needs:
            sev = "high" if poor or (score is not None and score < 60) else "medium"
            out.append({
                "source": "perf",
                "severity": sev,
                "title": f"Performance needs work — score {score}/100",
                "category": "web_vitals",
                "evidence": json.dumps({"score": score, "grades": grades, "metrics": perf.get("metrics")}, ensure_ascii=False),
                "selector": None,
                "impact": "Slow pages reduce conversion and make mobile usage feel unreliable.",
                "fix": "Optimize LCP assets, reduce blocking JS/CSS, cache static resources, and test on mobile network throttling.",
                "repro_steps": _make_repro(url, extra="Run qa_perf_metrics or Web Vitals on the page."),
            })

    for issue in (audits.get("seo") or {}).get("issues", []) or []:
        out.append({
            "source": "seo",
            "severity": issue.get("severity", "medium"),
            "title": issue.get("title") or issue.get("message") or issue.get("msg") or "SEO issue",
            "category": issue.get("category"),
            "evidence": issue.get("sample") or issue.get("message") or issue.get("msg"),
            "selector": issue.get("selector"),
            "impact": "Search/social previews may be degraded.",
            "fix": issue.get("hint") or "Fix the relevant meta/heading/schema/alt/canonical issue.",
            "repro_steps": _make_repro(url, issue.get("selector"), "Run qa_seo_check and inspect the reported metadata."),
        })

    for ev in (audits.get("logs") or {}).get("events", []) or []:
        level = ev.get("level")
        kind = ev.get("kind")
        severity = "high" if level == "error" or kind == "exception" else "medium"
        out.append({
            "source": "logs",
            "severity": severity,
            "title": f"Browser {kind or 'log'}: {level or 'event'}",
            "category": kind,
            "evidence": ev.get("text"),
            "selector": None,
            "impact": "Runtime errors can break user flows or indicate broken third-party integrations.",
            "fix": "Open DevTools Console/Network, identify the failing script/request, and remove or fix the integration.",
            "repro_steps": _make_repro(url, extra="Open DevTools Console and reload the page."),
        })

    for f in (audits.get("security") or {}).get("findings", []) or []:
        out.append({
            "source": "security",
            "severity": f.get("severity", "medium"),
            "title": f.get("title") or f.get("category") or "Security finding",
            "category": f.get("category"),
            "evidence": f.get("evidence") or f.get("detail"),
            "selector": None,
            "impact": "Security misconfiguration can increase risk, reduce trust, or affect compliance posture.",
            "fix": f.get("remediation") or "Review and harden this security control.",
            "repro_steps": _make_repro(url, extra="Run qa_security_passive_audit and inspect the reported response/DNS evidence."),
        })

    # Stable finding IDs for deduplication across runs
    import hashlib as _hl
    for f in out:
        id_seed = f"{f.get('source','')}|{f.get('category','')}|{f.get('selector','')}|{str(f.get('evidence',''))[:200]}"
        f["id"] = _hl.md5(id_seed.encode()).hexdigest()[:12]

    return sorted(out, key=lambda f: (_SEVERITY_RANK.get(f.get("severity", "info"), 9), f.get("source", "")))


def _eval_thresholds(audit_kind: str, result: dict, thresholds: dict) -> list[str]:
    """Return list of human-readable threshold violations. Empty = passing."""
    violations: list[str] = []
    if audit_kind == "rtl":
        by_sev = (result.get("summary") or {}).get("by_severity", {})
        for sev in ("high", "medium", "low"):
            cap = thresholds.get(f"max_{sev}")
            if cap is not None and by_sev.get(sev, 0) > cap:
                violations.append(f"rtl.{sev}={by_sev.get(sev, 0)} > {cap}")
    elif audit_kind == "a11y":
        by_imp = (result.get("summary") or {}).get("by_impact", {})
        for imp in ("critical", "serious", "moderate", "minor"):
            cap = thresholds.get(f"max_{imp}")
            if cap is not None and by_imp.get(imp, 0) > cap:
                violations.append(f"a11y.{imp}={by_imp.get(imp, 0)} > {cap}")
    elif audit_kind == "perf":
        score = result.get("score")
        min_score = thresholds.get("min_score")
        if min_score is not None and score is not None and score < min_score:
            violations.append(f"perf.score={score} < {min_score}")
        for metric in ("ttfb", "fcp", "lcp", "cls"):
            req = thresholds.get(f"min_{metric}_grade")
            if req:
                got = (result.get("grades") or {}).get(metric)
                rank = {"poor": 0, "needs_improvement": 1, "good": 2}
                if got is not None and rank.get(got, -1) < rank.get(req, 99):
                    violations.append(f"perf.{metric}.grade={got} < {req}")
    elif audit_kind == "seo":
        max_issues = thresholds.get("max_issues")
        n = (result.get("summary") or {}).get("total_issues", 0)
        if max_issues is not None and n > max_issues:
            violations.append(f"seo.total_issues={n} > {max_issues}")
    elif audit_kind == "links":
        max_flagged = thresholds.get("max_flagged")
        n = (result.get("summary") or {}).get("flagged", 0)
        if max_flagged is not None and n > max_flagged:
            violations.append(f"links.flagged={n} > {max_flagged}")
    elif audit_kind == "ux":
        scores = result.get("scores") or {}
        for score_name in ("hierarchy_score", "cognitive_load_score", "density_score", "touch_target_score"):
            min_score = thresholds.get(f"min_{score_name}") or thresholds.get("min_score")
            val = scores.get(score_name)
            if min_score is not None and val is not None and val < min_score:
                violations.append(f"ux.{score_name}={val} < {min_score}")
        by_sev = ((result.get("interpretation") or {}).get("summary") or result.get("summary") or {}).get("by_severity", {})
        for sev in ("high", "medium", "low"):
            cap = thresholds.get(f"max_{sev}")
            if cap is not None and by_sev.get(sev, 0) > cap:
                violations.append(f"ux.{sev}={by_sev.get(sev, 0)} > {cap}")
    elif audit_kind == "security":
        by_sev = (result.get("summary") or {}).get("by_severity", {})
        for sev in ("critical", "high", "medium", "low"):
            cap = thresholds.get(f"max_{sev}")
            if cap is not None and by_sev.get(sev, 0) > cap:
                violations.append(f"security.{sev}={by_sev.get(sev, 0)} > {cap}")
        min_score = thresholds.get("min_score")
        score = (result.get("summary") or {}).get("score")
        if min_score is not None and score is not None and score < min_score:
            violations.append(f"security.score={score} < {min_score}")
    return violations


async def run_suite(config: dict, on_progress=None) -> dict[str, Any]:
    """Execute every scenario in `config`. Returns full results dict
    suitable for HTML/JUnit emission. Does NOT exit — caller handles that.
    """
    base_url = config.get("base_url", "")
    browser_engine = config.get("browser", "chrome")
    headless = config.get("headless", True)
    stealth = config.get("stealth", True)
    scenarios = config.get("scenarios", [])
    auth = config.get("auth")
    if not scenarios:
        return {"error": "no scenarios in config"}

    # URL classifier — anything with a scheme: prefix is a full URL.
    # Without this, `data:` and `file:` URLs got joined to base_url.
    import re as _re
    _full_url_re = _re.compile(r"^[a-z][a-z0-9+.-]*:", _re.I)

    mgr = SessionManager()
    suite_results: list[dict] = []
    started_at = datetime.now()
    # Track finding IDs across scenarios for dedup
    seen_ids: set[str] = set()

    try:
        for idx, scn in enumerate(scenarios):
            scn_name = scn.get("name") or f"scenario-{idx}"
            path = scn.get("path") or scn.get("url") or "/"
            url = path if _full_url_re.match(path) else (base_url.rstrip("/") + "/" + path.lstrip("/"))
            audits = scn.get("audits", ["rtl", "a11y", "perf", "seo"])
            thresholds = scn.get("thresholds", {})
            viewport = scn.get("viewport")
            wait_for = scn.get("wait_for")

            if on_progress:
                on_progress(f"[{idx+1}/{len(scenarios)}] {scn_name} → {url}")

            scn_result: dict[str, Any] = {
                "name": scn_name,
                "url": url,
                "audits": {},
                "violations": [],
                "screenshot_path": None,
                "started_at": datetime.now().isoformat(timespec="seconds"),
            }
            try:
                opened = await browser_tools.browser_open(
                    mgr, url=url, headless=headless, browser=browser_engine,
                    stealth=stealth,
                )
                sid = opened["session_id"]

                # ── Auth support ──
                if auth:
                    # Restore saved storage state (highest priority)
                    if auth.get("storage_state"):
                        await browser_tools.browser_restore_storage_state(
                            mgr, sid, auth["storage_state"]
                        )
                    # Set cookies directly
                    if auth.get("cookies"):
                        await browser_tools.browser_set_cookies(
                            mgr, sid, auth["cookies"]
                        )
                    # Auto-login if credentials provided
                    if auth.get("login_url") and auth.get("credentials"):
                        login_url = auth["login_url"]
                        if not _full_url_re.match(login_url):
                            login_url = base_url.rstrip("/") + "/" + login_url.lstrip("/")
                        credentials = auth["credentials"]
                        success_sel = auth.get("success_selector")
                        max_retries = auth.get("max_retries", 2)
                        for attempt in range(max_retries):
                            try:
                                await browser_tools.browser_navigate(mgr, sid, login_url)
                                state = await browser_tools.browser_get_state(mgr, sid, scope="form", max_elements=20)
                                field_map = {}
                                for el in state.get("elements", []):
                                    name = el.get("name", "").lower()
                                    placeholder = (el.get("placeholder", "") or "").lower()
                                    if "email" in name or "email" in placeholder or "user" in name:
                                        field_map["email"] = el["index"]
                                    elif "pass" in name or "סיסמ" in placeholder:
                                        field_map["password"] = el["index"]
                                    elif "login" in name.lower() or "submit" in name.lower() or el.get("tag") == "button":
                                        field_map["submit"] = el["index"]
                                if "email" in field_map:
                                    await browser_tools.browser_type(mgr, sid, field_map["email"], credentials.get("email", ""))
                                if "password" in field_map:
                                    await browser_tools.browser_type(mgr, sid, field_map["password"], credentials.get("password", ""))
                                if "submit" in field_map:
                                    await browser_tools.browser_click(mgr, sid, field_map["submit"])
                                    if success_sel:
                                        try:
                                            await browser_tools.browser_wait_for(mgr, sid, selector=success_sel, timeout_ms=5000)
                                        except Exception:
                                            pass
                                    await browser_tools.browser_navigate(mgr, sid, url)
                                    break
                            except Exception:
                                if attempt == max_retries - 1:
                                    scn_result["auth_error"] = f"Login failed after {max_retries} attempts"
                if viewport:
                    await browser_tools.browser_set_viewport(
                        mgr, sid, width=viewport.get("width"),
                        height=viewport.get("height"),
                        device=viewport.get("device"),
                    )
                if wait_for:
                    await browser_tools.browser_wait_for(
                        mgr, sid,
                        selector=wait_for.get("selector"),
                        text=wait_for.get("text"),
                        network_idle=wait_for.get("network_idle", False),
                        timeout_ms=wait_for.get("timeout_ms", 10000),
                    )

                for a in audits:
                    if a == "security":
                        try:
                            scn_result["audits"][a] = await security_tools.security_passive_audit(url)
                            v = _eval_thresholds(a, scn_result["audits"][a], thresholds.get(a, {}))
                            scn_result["violations"].extend(v)
                        except Exception as e:
                            scn_result["audits"][a] = {"error": f"{type(e).__name__}: {e}"}
                        continue
                    if a == "logs":
                        try:
                            scn_result["audits"][a] = await browser_tools.browser_logs(mgr, sid)
                        except Exception as e:
                            scn_result["audits"][a] = {"error": f"{type(e).__name__}: {e}"}
                        continue

                    fn = _AUDIT_FNS.get(a)
                    if not fn:
                        scn_result["audits"][a] = {"error": f"unknown audit '{a}'"}
                        continue
                    try:
                        scn_result["audits"][a] = await fn(mgr, sid)
                        v = _eval_thresholds(a, scn_result["audits"][a],
                                             thresholds.get(a, {}))
                        scn_result["violations"].extend(v)
                    except Exception as e:
                        scn_result["audits"][a] = {"error": f"{type(e).__name__}: {e}"}

                scn_result["findings"] = _normalize_findings(scn_result)

                # ── Dedup: remove findings already seen in previous scenarios ──
                deduped: list[dict[str, Any]] = []
                for f in scn_result["findings"]:
                    fid = f.get("id", "")
                    if fid not in seen_ids:
                        seen_ids.add(fid)
                        deduped.append(f)
                scn_result["findings_deduped"] = len(scn_result["findings"]) - len(deduped)
                scn_result["findings"] = deduped

                # Screenshot for the report
                shot = await browser_tools.browser_screenshot(
                    mgr, sid, full_page=False,
                )
                scn_result["screenshot_path"] = shot.get("path")

                await browser_tools.browser_close(mgr, sid)
            except Exception as e:
                scn_result["error"] = f"{type(e).__name__}: {e}"

            scn_result["passed"] = (not scn_result["violations"]
                                    and "error" not in scn_result)
            scn_result["finished_at"] = datetime.now().isoformat(timespec="seconds")
            suite_results.append(scn_result)
    finally:
        await mgr.close_all()

    finished_at = datetime.now()
    return {
        "schema_version": "1.0.0",
        "tool_version": "0.8.0",
        "name": config.get("name", "qa-mcp-suite"),
        "started_at": started_at.isoformat(timespec="seconds"),
        "finished_at": finished_at.isoformat(timespec="seconds"),
        "duration_seconds": (finished_at - started_at).total_seconds(),
        "browser": browser_engine,
        "scenarios": suite_results,
        "summary": {
            "total": len(suite_results),
            "passed": sum(1 for r in suite_results if r.get("passed")),
            "failed": sum(1 for r in suite_results if not r.get("passed")),
            "violations_total": sum(len(r.get("violations", [])) for r in suite_results),
            "findings_total": sum(len(r.get("findings", [])) for r in suite_results),
            "findings_by_severity": {
                sev: sum(1 for r in suite_results for f in r.get("findings", []) if f.get("severity") == sev)
                for sev in ("critical", "high", "medium", "low", "info")
            },
        },
    }


# ---------- emitters ----------


def emit_junit_xml(suite: dict, out_path: str) -> None:
    """JUnit XML — consumed by GitHub Actions, GitLab CI, Jenkins, CircleCI, etc."""
    scenarios = suite.get("scenarios", [])
    total = len(scenarios)
    failures = sum(1 for s in scenarios if not s.get("passed"))
    duration = suite.get("duration_seconds", 0)
    lines = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        f'<testsuite name="{xml_escape(suite.get("name", "qa-mcp"))}" '
        f'tests="{total}" failures="{failures}" time="{duration:.2f}">',
    ]
    for s in scenarios:
        name_attr = xml_quoteattr(s.get("name", ""))
        url_text = xml_escape(s.get("url", ""))
        lines.append(f'  <testcase classname="qa-mcp" name={name_attr} time="0">')
        if not s.get("passed"):
            msgs = s.get("violations") or []
            err = s.get("error")
            if err:
                # Truncate to first line for the attribute; full body below.
                msgs = [f"error: {str(err).splitlines()[0]}"] + msgs
            full_text = xml_escape("\n".join(msgs))
            msg_attr = xml_quoteattr((msgs[0] if msgs else "failed")[:200])
            lines.append(f'    <failure message={msg_attr}>'
                         f'{full_text}\n  url: {url_text}\n    </failure>')
        lines.append("  </testcase>")
    lines.append("</testsuite>")
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    Path(out_path).write_text("\n".join(lines), encoding="utf-8")


def emit_html_report(suite: dict, out_path: str) -> None:
    """Single-file HTML — screenshots embedded as base64 so it's
    portable (email, slack, archive). Hebrew RTL-aware."""
    s = suite.get("summary", {})
    scenarios_html: list[str] = []
    for sc in suite.get("scenarios", []):
        passed = sc.get("passed")
        badge = '<span class="ok">PASS</span>' if passed else '<span class="fail">FAIL</span>'
        viol = sc.get("violations", [])
        viol_html = ""
        if viol:
            viol_html = "<ul class='viol'>" + "".join(
                f"<li>{html.escape(v)}</li>" for v in viol) + "</ul>"

        # Embed screenshot
        shot = ""
        if sc.get("screenshot_path") and Path(sc["screenshot_path"]).exists():
            try:
                b = base64.b64encode(Path(sc["screenshot_path"]).read_bytes()).decode("ascii")
                shot = f'<img src="data:image/jpeg;base64,{b}" class="shot">'
            except Exception:
                pass

        # Actionable findings
        findings_html = ""
        findings = sc.get("findings", []) or []
        if findings:
            items = []
            for f in findings[:50]:
                repro = "".join(f"<li>{html.escape(step)}</li>" for step in (f.get("repro_steps") or []))
                items.append(f"""
                <article class="finding sev-{html.escape(f.get('severity', 'info'))}">
                  <div><b>{html.escape(f.get('severity', 'info').upper())}</b> · {html.escape(f.get('source', ''))} · {html.escape(f.get('title', ''))}</div>
                  {f"<p><b>Evidence:</b> <code>{html.escape(str(f.get('evidence'))[:500])}</code></p>" if f.get('evidence') else ""}
                  {f"<p><b>Selector:</b> <code>{html.escape(str(f.get('selector')))}</code></p>" if f.get('selector') else ""}
                  <p><b>Impact:</b> {html.escape(f.get('impact', ''))}</p>
                  <p><b>Fix:</b> {html.escape(f.get('fix', ''))}</p>
                  <details><summary>Reproduce</summary><ol>{repro}</ol></details>
                </article>""")
            findings_html = f"<h3>Actionable findings ({len(findings)})</h3>" + "".join(items)

        # Audit details
        audits_html = ""
        for k, v in sc.get("audits", {}).items():
            if isinstance(v, dict) and v.get("error"):
                audits_html += f"<details><summary>{k} — error</summary>" \
                               f"<pre>{html.escape(v['error'])}</pre></details>"
                continue
            count = ((v.get("summary") or {}).get("total")
                     or len(v.get("findings", []))
                     or len(v.get("violations", []))
                     or (v.get("score") if k == "perf" else 0))
            label = f"{k}: {count}"
            if k == "perf" and v.get("score") is not None:
                label = f"perf score: {v['score']}/100"
            audits_html += (f"<details><summary>{label}</summary>"
                            f"<pre>{html.escape(json.dumps(v, indent=2, ensure_ascii=False)[:5000])}</pre>"
                            f"</details>")

        scenarios_html.append(f"""
        <section class="scn {'pass' if passed else 'fail'}">
          <header><h2>{html.escape(sc.get('name', ''))} {badge}</h2>
          <code>{html.escape(sc.get('url', ''))}</code></header>
          {viol_html}
          {shot}
          {findings_html}
          {audits_html}
        </section>""")

    css = """
        body { font-family: system-ui, -apple-system, sans-serif; margin: 24px; max-width: 1200px; }
        h1 { font-size: 24px; }
        .summary { background: #f5f5f5; padding: 12px 16px; border-radius: 8px; margin: 12px 0; }
        .scn { border: 1px solid #ddd; border-radius: 8px; padding: 16px; margin: 16px 0; }
        .scn.fail { border-color: #d33; background: #fff5f5; }
        .scn.pass { border-color: #2a2; background: #f5fff5; }
        .ok { color: #2a2; font-weight: 700; }
        .fail { color: #d33; font-weight: 700; }
        .shot { max-width: 100%; border: 1px solid #ccc; margin: 12px 0; }
        .finding { background: #fff; border: 1px solid #ddd; border-inline-start: 5px solid #999; border-radius: 8px; padding: 12px; margin: 10px 0; }
        .sev-critical { border-inline-start-color: #991b1b; }
        .sev-high { border-inline-start-color: #dc2626; }
        .sev-medium { border-inline-start-color: #d97706; }
        .sev-low { border-inline-start-color: #2563eb; }
        details { margin: 8px 0; }
        details summary { cursor: pointer; padding: 4px 8px; background: #eee; border-radius: 4px; }
        pre { background: #f7f7f7; padding: 8px; overflow-x: auto; font-size: 12px; max-height: 300px; }
        ul.viol { background: #fee; padding: 8px 24px; border-radius: 4px; }
        code { background: #eee; padding: 2px 6px; border-radius: 3px; }
    """

    html_out = f"""<!doctype html>
<html lang="he"><head>
<meta charset="utf-8">
<title>QA Report — {html.escape(suite.get('name', ''))}</title>
<style>{css}</style>
</head><body>
<h1>QA Report — {html.escape(suite.get('name', ''))}</h1>
<div class="summary">
  <p><b>Started:</b> {suite.get('started_at')} · <b>Duration:</b> {suite.get('duration_seconds', 0):.1f}s · <b>Browser:</b> {suite.get('browser')}</p>
  <p><b>Total:</b> {s.get('total')} · <b>Passed:</b> <span class="ok">{s.get('passed')}</span>
     · <b>Failed:</b> <span class="fail">{s.get('failed')}</span>
     · <b>Threshold violations:</b> {s.get('violations_total')}
     · <b>Actionable findings:</b> {s.get('findings_total', 0)}</p>
  <p><b>Findings by severity:</b> {html.escape(json.dumps(s.get('findings_by_severity', {}), ensure_ascii=False))}</p>
</div>
{''.join(scenarios_html)}
</body></html>"""
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    Path(out_path).write_text(html_out, encoding="utf-8")


def _slugify(text: str, max_len: int = 80) -> str:
    import re
    s = re.sub(r"[^\w\-א-ת]+", "-", text, flags=re.UNICODE).strip("-").lower()
    return s[:max_len].strip("-") or "issue"


def emit_issue_files(suite: dict, out_dir: str) -> dict[str, Any]:
    """Export each actionable finding as a GitHub-ready Markdown issue file."""
    target = Path(out_dir)
    target.mkdir(parents=True, exist_ok=True)
    written: list[str] = []
    idx = 1

    for sc in suite.get("scenarios", []) or []:
        scenario = sc.get("name", "scenario")
        url = sc.get("url", "")
        screenshot = sc.get("screenshot_path")
        for f in sc.get("findings", []) or []:
            severity = str(f.get("severity", "info")).upper()
            source = str(f.get("source", "qa"))
            title = str(f.get("title", "QA finding"))
            filename = f"{idx:03d}-{_slugify(severity)}-{_slugify(source)}-{_slugify(title)}.md"
            path = target / filename
            repro = "\n".join(f"{n}. {step}" for n, step in enumerate(f.get("repro_steps", []) or [], 1))
            body = [
                f"# [{severity}][{source}] {title}",
                "",
                f"- Scenario: `{scenario}`",
                f"- URL: {url}",
                f"- Category: `{f.get('category', '')}`",
                f"- Severity: `{f.get('severity', 'info')}`",
            ]
            if screenshot:
                body.append(f"- Screenshot: `{screenshot}`")
            body += [
                "",
                "## Evidence",
                "",
                f"```text\n{str(f.get('evidence') or '').strip()}\n```",
                "",
            ]
            if f.get("selector"):
                body += ["## Selector", "", f"```css\n{f.get('selector')}\n```", ""]
            body += [
                "## Impact",
                "",
                str(f.get("impact") or ""),
                "",
                "## Suggested fix",
                "",
                str(f.get("fix") or ""),
                "",
                "## Steps to reproduce",
                "",
                repro or "1. Open the URL and inspect the reported area.",
                "",
                "---",
                "Generated by qa-mcp issue export.",
                "",
            ]
            path.write_text("\n".join(body), encoding="utf-8")
            written.append(str(path))
            idx += 1

    index = target / "README.md"
    lines = [f"# QA Issues — {suite.get('name', 'qa-mcp')}", "", f"Generated issues: `{len(written)}`", ""]
    for p in written:
        rel = Path(p).name
        lines.append(f"- [{rel}](./{rel})")
    index.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return {"count": len(written), "out_dir": str(target), "files": written, "index": str(index)}


def emit_markdown_report(suite: dict, out_path: str) -> None:
    """Client/issue-friendly Markdown report with actionable findings."""
    s = suite.get("summary", {})
    lines = [
        f"# QA Report — {suite.get('name', 'qa-mcp')}",
        "",
        f"- Started: `{suite.get('started_at')}`",
        f"- Duration: `{suite.get('duration_seconds', 0):.1f}s`",
        f"- Browser: `{suite.get('browser')}`",
        f"- Scenarios: `{s.get('passed', 0)}/{s.get('total', 0)}` passed",
        f"- Threshold violations: `{s.get('violations_total', 0)}`",
        f"- Actionable findings: `{s.get('findings_total', 0)}`",
        f"- Findings by severity: `{json.dumps(s.get('findings_by_severity', {}), ensure_ascii=False)}`",
        "",
    ]

    for sc in suite.get("scenarios", []):
        status = "PASS" if sc.get("passed") else "FAIL"
        lines += [
            f"## {sc.get('name', '')} — {status}",
            "",
            f"URL: {sc.get('url', '')}",
            "",
        ]
        if sc.get("screenshot_path"):
            lines += [f"Screenshot: `{sc.get('screenshot_path')}`", ""]
        if sc.get("violations"):
            lines += ["### Threshold violations", ""]
            lines += [f"- {v}" for v in sc.get("violations", [])]
            lines.append("")

        findings = sc.get("findings", []) or []
        if findings:
            lines += [f"### Actionable findings ({len(findings)})", ""]
            for i, f in enumerate(findings, 1):
                lines += [
                    f"#### {i}. [{str(f.get('severity', 'info')).upper()}] {f.get('title', '')}",
                    "",
                    f"- Source: `{f.get('source', '')}`",
                    f"- Category: `{f.get('category', '')}`",
                ]
                if f.get("evidence"):
                    lines.append(f"- Evidence: `{str(f.get('evidence'))[:500]}`")
                if f.get("selector"):
                    lines.append(f"- Selector: `{f.get('selector')}`")
                lines += [
                    f"- Impact: {f.get('impact', '')}",
                    f"- Suggested fix: {f.get('fix', '')}",
                    "- Reproduce:",
                ]
                for step in f.get("repro_steps", []) or []:
                    lines.append(f"  - {step}")
                lines.append("")
        else:
            lines += ["No actionable findings normalized for this scenario.", ""]

    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    Path(out_path).write_text("\n".join(lines), encoding="utf-8")


def cli_run(config_path: str, on_progress=None) -> int:
    """Read config, run suite, emit reports, return exit code."""
    p = Path(config_path)
    if not p.exists():
        print(f"[qa-mcp] config not found: {config_path}")
        return 2
    cfg = json.loads(p.read_text(encoding="utf-8"))
    suite = asyncio.run(run_suite(cfg, on_progress=on_progress))

    rep = cfg.get("report", {})
    if rep.get("html"):
        emit_html_report(suite, rep["html"])
        print(f"[qa-mcp] HTML report → {rep['html']}")
    if rep.get("junit"):
        emit_junit_xml(suite, rep["junit"])
        print(f"[qa-mcp] JUnit XML → {rep['junit']}")
    md_path = rep.get("markdown") or rep.get("md")
    if md_path:
        emit_markdown_report(suite, md_path)
        print(f"[qa-mcp] Markdown → {md_path}")
    if rep.get("issues"):
        out = emit_issue_files(suite, rep["issues"])
        print(f"[qa-mcp] Issues → {out['out_dir']} ({out['count']} files)")
    if rep.get("json"):
        Path(rep["json"]).parent.mkdir(parents=True, exist_ok=True)
        Path(rep["json"]).write_text(json.dumps(suite, indent=2, ensure_ascii=False),
                                     encoding="utf-8")
        print(f"[qa-mcp] JSON   → {rep['json']}")

    s = suite.get("summary", {})
    print(f"[qa-mcp] {s.get('passed', 0)}/{s.get('total', 0)} passed, "
          f"{s.get('violations_total', 0)} threshold violations")
    return 0 if s.get("failed", 1) == 0 else 1
