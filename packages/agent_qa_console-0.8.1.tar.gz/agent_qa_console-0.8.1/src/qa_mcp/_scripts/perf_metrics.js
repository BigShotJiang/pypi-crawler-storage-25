// Web Vitals + page timing. Uses PerformanceObserver with buffered:true to
// catch LCP entries that fired before this script ran.
//
// Note: LCP requires the page to stay alive until the largest content paint
// happens. The Python wrapper waits ~2s after navigation before calling this.
// If LCP still null, we return reason="no_lcp_candidate" instead of bare null.
async (opts) => {
  // opts.thresholds (optional): override default Core Web Vitals cutoffs.
  // Shape: { ttfb:{good,poor}, fcp:{good,poor}, lcp:{good,poor}, cls:{good,poor} }
  // Any key omitted falls back to Google's defaults.
  const T = (opts && opts.thresholds) || {};
  const def = {
    ttfb: { good: 800,  poor: 1800 },
    fcp:  { good: 1800, poor: 3000 },
    lcp:  { good: 2500, poor: 4000 },
    cls:  { good: 0.1,  poor: 0.25 },
  };
  const TH = {
    ttfb: { ...def.ttfb, ...(T.ttfb || {}) },
    fcp:  { ...def.fcp,  ...(T.fcp  || {}) },
    lcp:  { ...def.lcp,  ...(T.lcp  || {}) },
    cls:  { ...def.cls,  ...(T.cls  || {}) },
  };

  const nav = performance.getEntriesByType('navigation')[0] || {};
  const paint = performance.getEntriesByType('paint');
  const fcp = paint.find(p => p.name === 'first-contentful-paint')?.startTime;

  // ---- LCP ----
  // First try buffered observer (catches entries from before this script).
  let lcp = null;
  let lcpReason = null;
  try {
    const lcpEntries = await new Promise((resolve) => {
      const collected = [];
      const obs = new PerformanceObserver((list) => {
        for (const e of list.getEntries()) collected.push(e);
      });
      try {
        obs.observe({ type: 'largest-contentful-paint', buffered: true });
      } catch {
        resolve([]);
        return;
      }
      // Give the observer a moment to flush buffered entries.
      setTimeout(() => {
        try { obs.disconnect(); } catch {}
        resolve(collected);
      }, 200);
    });
    if (lcpEntries.length) {
      lcp = lcpEntries[lcpEntries.length - 1].startTime;
    } else {
      lcpReason = 'no_lcp_candidate';
    }
  } catch (e) {
    lcpReason = `observer_error: ${e.message || e}`;
  }

  // Fallback: legacy entry API
  if (lcp == null) {
    const legacy = performance.getEntriesByType('largest-contentful-paint');
    if (legacy && legacy.length) {
      lcp = legacy[legacy.length - 1].startTime;
      lcpReason = null;
    }
  }

  // ---- CLS ----
  // Cumulative Layout Shift — best-effort via buffered observer.
  let cls = 0;
  let clsAttribution = [];
  const selectorFor = (el) => {
    if (!el || el.nodeType !== 1) return null;
    const esc = (s) => (typeof CSS !== 'undefined' && CSS.escape) ? CSS.escape(s) : String(s).replace(/[^\w-]/g, ch => '\\' + ch);
    if (el.id) return '#' + esc(el.id);
    for (const a of ['data-testid','data-qa','data-cy','data-test','aria-label','name']) {
      const v = el.getAttribute && el.getAttribute(a);
      if (v) return `${el.tagName.toLowerCase()}[${a}="${String(v).replace(/"/g, '\\"')}"]`;
    }
    const parts = [];
    let cur = el;
    while (cur && cur.nodeType === 1 && cur !== document.documentElement && parts.length < 5) {
      const parent = cur.parentElement;
      if (!parent) break;
      const tag = cur.tagName.toLowerCase();
      const same = Array.from(parent.children).filter(c => c.tagName === cur.tagName);
      parts.unshift(`${tag}:nth-of-type(${same.indexOf(cur) + 1})`);
      cur = parent;
    }
    return parts.join(' > ');
  };
  try {
    const clsEntries = await new Promise((resolve) => {
      const collected = [];
      const obs = new PerformanceObserver((list) => {
        for (const e of list.getEntries()) {
          if (!e.hadRecentInput) collected.push(e);
        }
      });
      try {
        obs.observe({ type: 'layout-shift', buffered: true });
      } catch {
        resolve([]);
        return;
      }
      setTimeout(() => {
        try { obs.disconnect(); } catch {}
        resolve(collected);
      }, 200);
    });
    cls = clsEntries.reduce((sum, e) => sum + (e.value || 0), 0);
    clsAttribution = clsEntries
      .slice()
      .sort((a, b) => (b.value || 0) - (a.value || 0))
      .slice(0, 8)
      .map(e => ({
        value: Math.round((e.value || 0) * 1000) / 1000,
        start_time_ms: Math.round(e.startTime || 0),
        sources: Array.from(e.sources || []).slice(0, 3).map(s => ({
          selector: selectorFor(s.node),
          text: (s.node && (s.node.innerText || s.node.alt || s.node.getAttribute?.('aria-label')) || '').trim().slice(0, 80),
          previous_rect: s.previousRect ? {x: Math.round(s.previousRect.x), y: Math.round(s.previousRect.y), w: Math.round(s.previousRect.width), h: Math.round(s.previousRect.height)} : null,
          current_rect: s.currentRect ? {x: Math.round(s.currentRect.x), y: Math.round(s.currentRect.y), w: Math.round(s.currentRect.width), h: Math.round(s.currentRect.height)} : null,
        })),
      }));
  } catch {}

  const ttfb = nav.responseStart ? Math.round(nav.responseStart - nav.requestStart) : null;
  const domContentLoaded = nav.domContentLoadedEventEnd ? Math.round(nav.domContentLoadedEventEnd) : null;
  const loadComplete = nav.loadEventEnd ? Math.round(nav.loadEventEnd) : null;

  const grade = (val, good, poor) => val == null ? null : (val <= good ? 'good' : val <= poor ? 'needs_improvement' : 'poor');

  // Sanity note for callers: an audit report (2026-05-02) flagged "FCP/LCP/DCL
  // clustered ±400ms must be a measurement bug." Actually plausible on slow,
  // JS-heavy SPAs (everything happens after hydration). Surface this so the
  // calling agent can interpret rather than assume tool failure.
  const notes = [];
  const fcpR = fcp ? Math.round(fcp) : null;
  const lcpR = lcp ? Math.round(lcp) : null;
  const ms = [fcpR, lcpR, domContentLoaded, loadComplete].filter(v => v != null);
  if (ms.length >= 3) {
    const range = Math.max(...ms) - Math.min(...ms);
    if (range < 500 && Math.min(...ms) > 3000) {
      notes.push({
        kind: 'metrics_clustered',
        message: `FCP/LCP/DCL/load all within ${range}ms (>3s). Typical of JS-heavy SPA where paint+hydration+load happen together. Not a measurement bug — values are relative to navigationStart per Performance API.`,
      });
    }
  }

  return {
    metrics: {
      ttfb_ms: ttfb,
      fcp_ms: fcpR,
      lcp_ms: lcpR,
      cls: Math.round(cls * 1000) / 1000,
      dom_content_loaded_ms: domContentLoaded,
      load_complete_ms: loadComplete,
      transfer_size_bytes: nav.transferSize || null,
      resource_count: performance.getEntriesByType('resource').length,
    },
    cls_attribution: clsAttribution,
    timing_reference: {
      // All *_ms values above are DOMHighResTimeStamps relative to this origin.
      time_origin_ms: Math.round(performance.timeOrigin),
      navigation_start: 0,  // by definition, in PerformanceNavigationTiming
    },
    grades: {
      ttfb: grade(ttfb, TH.ttfb.good, TH.ttfb.poor),
      fcp:  grade(fcp,  TH.fcp.good,  TH.fcp.poor),
      lcp:  grade(lcp,  TH.lcp.good,  TH.lcp.poor),
      cls:  grade(cls,  TH.cls.good,  TH.cls.poor),
    },
    thresholds_used: TH,
    score: (() => {
      // Lighthouse-style 0-100 weighted score. Weights mirror Lighthouse v10
      // mobile config so output is interpretable by anyone used to PageSpeed.
      // weights: LCP 25%, TBT 25% (we don't have TBT, give to TTFB 12% + CLS 25%),
      // FCP 10%, CLS 25%, SI 10% (skipped). Renormalized over present metrics.
      const score = (val, good, poor) => {
        if (val == null) return null;
        if (val <= good) return 100;
        if (val >= poor) return 0;
        // Linear interpolation between good→poor (Lighthouse uses log-normal,
        // but the ranking is the same and this is faster to reason about).
        return Math.round(100 * (1 - (val - good) / (poor - good)));
      };
      const parts = [
        ['ttfb', score(ttfb, TH.ttfb.good, TH.ttfb.poor),  10],
        ['fcp',  score(fcp,  TH.fcp.good,  TH.fcp.poor),   15],
        ['lcp',  score(lcp,  TH.lcp.good,  TH.lcp.poor),   40],
        ['cls',  score(cls,  TH.cls.good,  TH.cls.poor),   35],
      ].filter(([_, v]) => v != null);
      if (!parts.length) return null;
      const totalW = parts.reduce((s, [_, __, w]) => s + w, 0);
      const total = parts.reduce((s, [_, v, w]) => s + v * w, 0);
      return Math.round(total / totalW);
    })(),
    reasons: lcpReason ? { lcp: lcpReason } : {},
    notes,
    page: { url: location.href },
  };
}
