// UX metrics — deterministic measurements that feed agent-side persona reasoning.
//
// Philosophy: this script does NOT decide "is the UX good?". It produces the
// raw numbers a calling agent (Claude/Codex/etc.) needs to answer that
// question for a specific persona + goal. The scores included are heuristic
// composites — useful for trend detection across sites, but not a substitute
// for the agent's judgment.
//
// Companion to qa_rtl_audit / qa_a11y_audit / qa_perf_metrics: those answer
// "is it correct?". This answers "is it understandable at a glance?".
async (opts) => {
  const fold = (opts && opts.fold_height) || window.innerHeight;
  const minTouch = (opts && opts.min_touch_px) || 44;
  const vw = window.innerWidth;
  const vh = window.innerHeight;

  // ---------- Helpers ----------
  const isVisible = (el) => {
    if (!el || !el.getBoundingClientRect) return false;
    const r = el.getBoundingClientRect();
    if (r.width <= 0 || r.height <= 0) return false;
    const cs = getComputedStyle(el);
    if (cs.visibility === 'hidden' || cs.display === 'none' || cs.opacity === '0') return false;
    return true;
  };
  const inFold = (el) => {
    const r = el.getBoundingClientRect();
    return r.top < fold && r.bottom > 0 && r.left < vw && r.right > 0;
  };
  const normColor = (c) => {
    if (!c) return null;
    // Normalize rgba(0, 0, 0, 0) → null; treat transparent as no color.
    const m = c.match(/rgba?\(([^)]+)\)/);
    if (!m) return c;
    const parts = m[1].split(',').map(x => x.trim());
    if (parts.length === 4 && parseFloat(parts[3]) === 0) return null;
    return `rgb(${parts[0]},${parts[1]},${parts[2]})`;
  };
  const cssEsc = (s) => {
    if (typeof CSS !== 'undefined' && CSS.escape) return CSS.escape(s);
    return String(s).replace(/[^\w-]/g, ch => '\\' + ch);
  };
  const selectorFor = (el) => {
    if (!el || el.nodeType !== 1) return null;
    if (el.id) return '#' + cssEsc(el.id);
    for (const a of ['data-testid','data-qa','data-cy','data-test','aria-label','name']) {
      const v = el.getAttribute && el.getAttribute(a);
      if (v) return `${el.tagName.toLowerCase()}[${a}="${String(v).replace(/"/g, '\\"')}"]`;
    }
    const parts = [];
    let cur = el;
    while (cur && cur.nodeType === 1 && cur !== document.documentElement && parts.length < 5) {
      const parent = cur.parentElement;
      if (!parent) break;
      const tag = cur.tagName.toLowerCase();
      const same = Array.from(parent.children).filter(c => c.tagName === cur.tagName);
      parts.unshift(`${tag}:nth-of-type(${same.indexOf(cur) + 1})`);
      cur = parent;
    }
    return parts.join(' > ');
  };

  // ---------- Walk visible elements once ----------
  const all = Array.from(document.body.querySelectorAll('*')).filter(isVisible);
  const inFoldEls = all.filter(inFold);

  // ---------- Typography ----------
  // We collect font-size of every text-containing element. Distinct rounded sizes
  // = a proxy for typographic discipline. Brutalist/over-designed pages have 8+.
  const fontSizes = new Map();      // px → count
  const fontFamilies = new Set();
  let maxFontSize = 0;
  let maxFontSizeEl = null;
  let secondFontSize = 0;
  for (const el of all) {
    const cs = getComputedStyle(el);
    const fs = parseFloat(cs.fontSize) || 0;
    if (fs < 8) continue;
    // Only count elements that actually carry text directly (not just containers).
    const hasOwnText = Array.from(el.childNodes).some(n => n.nodeType === 3 && n.textContent.trim());
    if (!hasOwnText) continue;
    const rounded = Math.round(fs);
    fontSizes.set(rounded, (fontSizes.get(rounded) || 0) + 1);
    fontFamilies.add((cs.fontFamily || '').split(',')[0].trim());
    if (fs > maxFontSize) {
      secondFontSize = maxFontSize;
      maxFontSize = fs;
      maxFontSizeEl = el;
    } else if (fs > secondFontSize && fs < maxFontSize) {
      secondFontSize = fs;
    }
  }

  // ---------- Color palette ----------
  // Counting distinct text + background colors across the visible tree.
  // > 10 distinct = visual noise; < 4 = probably well-designed.
  const textColors = new Set();
  const bgColors = new Set();
  for (const el of all) {
    const cs = getComputedStyle(el);
    const tc = normColor(cs.color);
    const bg = normColor(cs.backgroundColor);
    if (tc) textColors.add(tc);
    if (bg) bgColors.add(bg);
  }

  // ---------- Interactive surface ----------
  // What can the user click? Includes <a>, <button>, [role=button], inputs.
  const interactiveSel = 'a, button, [role="button"], input:not([type="hidden"]), select, textarea, [onclick], [tabindex]:not([tabindex="-1"])';
  const interactive = all.filter(el => el.matches(interactiveSel));
  const interactiveInFold = interactive.filter(inFold);

  // Small touch targets — augments axe (which only checks WCAG 2.5.5, often filtered out).
  const smallTargets = interactive.filter(el => {
    const r = el.getBoundingClientRect();
    // Allow inline links inside paragraph text (height matches line height, not a button).
    if (el.tagName === 'A' && el.closest('p, li, span, h1, h2, h3, h4, h5, h6')) return false;
    return r.width < minTouch || r.height < minTouch;
  });

  // ---------- CTA candidates ----------
  // A CTA = a button-styled element OR an <a> that visually reads as a button.
  // Calibration finding (2026-05-10): the loose `(hasBg||hasBorder)&&pad>12`
  // check counted nav links as CTAs, producing 26 CTAs on linear.app — clearly
  // wrong. We now require: (a) NOT inside <nav>/<header>, (b) bg AND meaningful
  // padding, (c) font ≥ 13px, (d) bounding box ≥ 80×28 (real button shape).
  const ctaCandidates = interactive.filter(el => {
    if (el.tagName === 'BUTTON') return true;
    if (el.matches('[role="button"]')) return true;
    if (el.tagName === 'A') {
      // Filter out nav/header/footer links — they're navigation, not CTAs.
      if (el.closest('nav, header, footer, [role="navigation"], [role="menu"]')) return false;
      const cs = getComputedStyle(el);
      const fs = parseFloat(cs.fontSize) || 0;
      if (fs < 13) return false;
      const hasBg = normColor(cs.backgroundColor) !== null;
      const padX = parseFloat(cs.paddingLeft) + parseFloat(cs.paddingRight);
      const padY = parseFloat(cs.paddingTop) + parseFloat(cs.paddingBottom);
      if (!hasBg || padX < 16 || padY < 8) return false;
      const r = el.getBoundingClientRect();
      // Buttons have button-shape: not too small, not card-sized.
      // Calibration finding: linear.app has feature-cards as <a> tags with
      // bg+padding — they LOOK like big cards, not CTAs. Cap dimensions.
      if (r.width < 80 || r.height < 28) return false;
      if (r.width > 320 || r.height > 80) return false;
      return true;
    }
    return false;
  });
  const ctaInFold = ctaCandidates.filter(inFold);

  // Dominant CTA detection: is there ONE CTA that's clearly the biggest /
  // most-contrasted in the fold? Good UX has one. Bad has 3+ equal-weight.
  const ctaAreas = ctaInFold.map(el => {
    const r = el.getBoundingClientRect();
    return { el, area: r.width * r.height };
  }).sort((a, b) => b.area - a.area);
  let dominantCtaRatio = null;
  if (ctaAreas.length >= 2) {
    dominantCtaRatio = ctaAreas[0].area / (ctaAreas[1].area || 1);
  } else if (ctaAreas.length === 1) {
    dominantCtaRatio = Infinity; // only one CTA → fully dominant
  }

  // ---------- KPI candidates ----------
  // Large numeric strings (≥18px font, contain digits) — typical of dashboards.
  // Too many KPIs in fold = information overload for non-analyst users.
  const kpiCandidates = [];
  for (const el of all) {
    if (!inFold(el)) continue;
    const cs = getComputedStyle(el);
    const fs = parseFloat(cs.fontSize) || 0;
    if (fs < 18) continue;
    const text = (el.textContent || '').trim();
    if (!text) continue;
    // Element's OWN text, not aggregated children
    const ownText = Array.from(el.childNodes)
      .filter(n => n.nodeType === 3)
      .map(n => n.textContent.trim())
      .join('');
    if (!ownText) continue;
    // Has at least 2 consecutive digits and isn't just a year/date
    if (!/\d{2,}/.test(ownText)) continue;
    // Skip pure dates (YYYY-MM-DD or DD/MM/YYYY)
    if (/^\d{4}-\d{2}-\d{2}$/.test(ownText) || /^\d{1,2}[\/.\-]\d{1,2}[\/.\-]\d{2,4}$/.test(ownText)) continue;
    kpiCandidates.push({
      text: ownText.slice(0, 40),
      font_size: Math.round(fs),
      tag: el.tagName.toLowerCase(),
    });
  }

  // ---------- Density ----------
  // Total visible-text chars divided by fold area. Rough but works for the
  // "wall of text vs breathable layout" distinction.
  let totalTextChars = 0;
  for (const el of inFoldEls) {
    const ownText = Array.from(el.childNodes)
      .filter(n => n.nodeType === 3)
      .map(n => n.textContent.trim())
      .join('');
    totalTextChars += ownText.length;
  }
  const foldAreaPx = vw * Math.min(fold, vh);
  const textDensity = foldAreaPx > 0 ? totalTextChars / foldAreaPx : 0;

  // ---------- Heading structure ----------
  const headings = {};
  for (const tag of ['h1', 'h2', 'h3', 'h4', 'h5', 'h6']) {
    headings[tag] = document.querySelectorAll(tag).length;
  }
  const h1Count = headings.h1;
  // Heading-size sanity: h1 should be largest, h2 smaller, etc.
  const headingSizes = {};
  for (const tag of ['h1', 'h2', 'h3']) {
    const el = document.querySelector(tag);
    if (el && isVisible(el)) {
      headingSizes[tag] = parseFloat(getComputedStyle(el).fontSize) || 0;
    }
  }
  const headingOrderOk = (!headingSizes.h1 || !headingSizes.h2 || headingSizes.h1 >= headingSizes.h2)
    && (!headingSizes.h2 || !headingSizes.h3 || headingSizes.h2 >= headingSizes.h3);

  // ---------- Composite scores (0-100, HEURISTIC) ----------
  // Clamped helper
  const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));

  // hierarchy_score: rewards a single dominant headline + a single dominant CTA.
  // Penalizes: no h1, multiple h1s, h1 not visibly largest, equal-weight CTAs.
  let hs = 100;
  if (h1Count === 0) hs -= 30;
  if (h1Count > 1) hs -= 20;
  if (!headingOrderOk) hs -= 15;
  // Heading-to-body ratio: largest visible heading vs median body text.
  const heading_to_body_ratio = (() => {
    if (!maxFontSize) return null;
    // body-ish: 14-18px
    let body = 16;
    for (const [size, cnt] of fontSizes) {
      if (size >= 14 && size <= 18) { body = size; break; }
    }
    return Math.round((maxFontSize / body) * 100) / 100;
  })();
  if (heading_to_body_ratio !== null && heading_to_body_ratio < 1.5) hs -= 15;
  if (dominantCtaRatio !== null && dominantCtaRatio < 1.4 && ctaInFold.length > 1) hs -= 15;
  const hierarchy_score = clamp(hs, 0, 100);

  // cognitive_load_score: HIGH = simple. Penalizes too many distinct sizes/colors/CTAs.
  // Calibration (2026-05-10): original thresholds collapsed Linear/Stripe to 0.
  // Each penalty is now capped at 30 so one bad signal can't bottom the score —
  // a site with too many fonts AND too many colors AND too many CTAs deserves a
  // low score, but a site that just has rich typography shouldn't.
  const cap = (x) => Math.min(30, x);
  let cls_score = 100;
  cls_score -= cap(Math.max(0, fontSizes.size - 6) * 3);        // > 6 sizes = noise
  cls_score -= cap(Math.max(0, textColors.size - 8) * 2);       // > 8 text colors = noise
  cls_score -= cap(Math.max(0, ctaInFold.length - 3) * 5);      // > 3 CTAs in fold = paralysis
  cls_score -= cap(Math.max(0, kpiCandidates.length - 5) * 4);  // > 5 KPIs = analyst-only
  const cognitive_load_score = clamp(cls_score, 0, 100);

  // density_score: HIGH = breathable. Threshold based on common patterns:
  // marketing pages ~0.001 chars/px², dashboards ~0.003, ynet ~0.007.
  let ds = 100;
  if (textDensity > 0.001) ds -= Math.min(60, (textDensity - 0.001) * 30000);
  ds -= Math.max(0, interactiveInFold.length - 10) * 2;
  const density_score = clamp(Math.round(ds), 0, 100);

  // touch_target_score: % of interactive elements that meet 44×44 minimum.
  const touch_target_score = interactive.length === 0
    ? null
    : Math.round(100 * (1 - smallTargets.length / interactive.length));

  // ---------- Output ----------
  return {
    viewport: { width: vw, height: vh, fold_height: fold },
    typography: {
      distinct_font_sizes: fontSizes.size,
      distinct_font_families: fontFamilies.size,
      largest_font_size_px: Math.round(maxFontSize),
      second_largest_font_size_px: Math.round(secondFontSize),
      heading_to_body_ratio,
      size_distribution: Array.from(fontSizes.entries())
        .sort((a, b) => b[0] - a[0])
        .slice(0, 10)
        .map(([px, count]) => ({ px, count })),
    },
    color: {
      distinct_text_colors: textColors.size,
      distinct_background_colors: bgColors.size,
    },
    interactive: {
      total: interactive.length,
      in_fold: interactiveInFold.length,
      cta_candidates: ctaCandidates.length,
      cta_in_fold: ctaInFold.length,
      dominant_cta_ratio: dominantCtaRatio === Infinity ? null : (
        dominantCtaRatio !== null ? Math.round(dominantCtaRatio * 100) / 100 : null
      ),
      single_cta_in_fold: ctaInFold.length === 1,
      cta_samples: ctaInFold.slice(0, 5).map(el => {
        const r = el.getBoundingClientRect();
        return {
          tag: el.tagName.toLowerCase(),
          selector: selectorFor(el),
          text: (el.textContent || el.getAttribute('aria-label') || '').trim().slice(0, 60),
          width: Math.round(r.width),
          height: Math.round(r.height),
        };
      }),
    },
    touch_targets: {
      min_size_px: minTouch,
      small_count: smallTargets.length,
      small_samples: smallTargets.slice(0, 5).map(el => {
        const r = el.getBoundingClientRect();
        return {
          tag: el.tagName.toLowerCase(),
          selector: selectorFor(el),
          width: Math.round(r.width),
          height: Math.round(r.height),
          text: (el.textContent || '').trim().slice(0, 40),
        };
      }),
    },
    kpi: {
      candidates_in_fold: kpiCandidates.length,
      samples: kpiCandidates.slice(0, 8),
    },
    headings: {
      counts: headings,
      h1_count: h1Count,
      order_ok: headingOrderOk,
    },
    density: {
      text_chars_in_fold: totalTextChars,
      chars_per_px2: Math.round(textDensity * 1e6) / 1e6,
      interactive_in_fold: interactiveInFold.length,
    },
    scores: {
      // 0-100, higher is better. HEURISTIC — calibrate on real sites before
      // trusting absolute values. Trend / delta is more reliable than absolute.
      hierarchy_score,
      cognitive_load_score,
      density_score,
      touch_target_score,
      _note: "Scores are heuristic composites of the raw measurements above. " +
             "Use raw fields for persona-specific reasoning, scores for trend tracking.",
    },
    page: { url: location.href, title: document.title },
  };
}
