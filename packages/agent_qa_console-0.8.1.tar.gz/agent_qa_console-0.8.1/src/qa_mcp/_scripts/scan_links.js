// Inventory all clickables with risk flags.
(() => {
  const cssPath = (el) => {
    if (!el || el.nodeType !== 1) return '';
    if (el.id) return '#' + el.id;
    let parts = [];
    while (el && el.nodeType === 1 && parts.length < 4) {
      let part = el.tagName.toLowerCase();
      if (el.className && typeof el.className === 'string') {
        part += '.' + el.className.trim().split(/\s+/).slice(0, 2).join('.');
      }
      parts.unshift(part);
      el = el.parentElement;
    }
    return parts.join(' > ');
  };
  const sample = (text) => (text || '').trim().slice(0, 80);
  const here = location.origin;
  const items = [];

  // Selector includes input-as-button types — qa_scan_links was missing
  // these on Round 5 review (saucedemo login returned count=0 despite the
  // <input type="submit"> Login button).
  const SEL = 'a, button, [role="button"], input[type="submit"], input[type="button"], input[type="image"], input[type="reset"]';
  document.querySelectorAll(SEL).forEach((el) => {
    const tag = el.tagName.toLowerCase();
    const inputType = tag === 'input' ? (el.type || '').toLowerCase() : null;
    // Treat <input type=submit/button/image/reset> as button-like for kind/flag purposes.
    const isButtonLike = (tag === 'button' || tag === 'input' || el.getAttribute('role') === 'button');
    const text = sample(el.innerText || el.value || el.getAttribute('aria-label') || el.getAttribute('alt') || '');
    const rawHref = tag === 'a' ? el.getAttribute('href') : null;
    const resolvedHref = tag === 'a' ? (el.href || null) : null;
    let kind = tag === 'input' ? `input-${inputType}` : tag;
    if (tag === 'a') {
      kind = rawHref === null ? 'no-href'
           : rawHref === '' ? 'empty-href'
           : rawHref.startsWith('javascript:') ? 'js-link'
           : rawHref.startsWith('mailto:') ? 'mailto'
           : rawHref.startsWith('tel:') ? 'tel'
           : rawHref.startsWith('#') ? 'anchor'
           : (resolvedHref && new URL(resolvedHref, location.href).origin === here) ? 'internal'
           : 'external';
    }
    const target = el.getAttribute('target') || null;
    const cs = getComputedStyle(el);
    const disabled = el.disabled || el.getAttribute('aria-disabled') === 'true' || cs.pointerEvents === 'none';

    const flags = [];
    if (tag === 'a' && (rawHref === '' || rawHref === '#' || rawHref === null)) flags.push('empty_href');
    if (target === '_blank' && !el.rel?.includes('noopener')) flags.push('blank_no_noopener');
    if (isButtonLike && !text) flags.push('button_no_label');
    if (disabled) flags.push('disabled');
    // <input type=image> needs alt text for accessibility
    if (inputType === 'image' && !el.getAttribute('alt')) flags.push('image_input_no_alt');

    items.push({
      tag, kind, text,
      input_type: inputType,
      href: rawHref, resolved_href: resolvedHref,
      target, flags, selector: cssPath(el),
    });
  });

  return {
    count: items.length,
    items,
    summary: {
      internal: items.filter(i => i.kind === 'internal').length,
      external: items.filter(i => i.kind === 'external').length,
      anchor: items.filter(i => i.kind === 'anchor').length,
      buttons: items.filter(i => i.tag === 'button').length,
      input_buttons: items.filter(i => i.tag === 'input').length,
      flagged: items.filter(i => i.flags.length > 0).length,
    },
  };
})()
