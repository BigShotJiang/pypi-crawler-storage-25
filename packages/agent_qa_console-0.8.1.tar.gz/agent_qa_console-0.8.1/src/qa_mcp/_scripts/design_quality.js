// AI Slop / Design Quality audit. Detects "AI-generated UI" anti-patterns
// drawn from the gstack design-review skill blacklist.
//
// Severity ladder:
//   high   — the pattern alone makes the design look AI-generated
//   medium — strong signal, but might be intentional (e.g. emoji on a kids' site)
//   low    — minor; flag only when multiple low signals stack up
//
// Each finding includes: id, severity, category, title, hint, evidence,
// selectors[] (up to 3), positive_reference (Linear/Stripe/Raycast/GitHub
// counter-example when relevant), confidence (0-1).
(() => {
  const cssPath = (el) => {
    if (!el || el.nodeType !== 1) return '';
    if (el.id) return '#' + el.id;
    const parts = [];
    let cur = el;
    while (cur && cur.nodeType === 1 && parts.length < 4) {
      let part = cur.tagName.toLowerCase();
      if (cur.className && typeof cur.className === 'string') {
        const cls = cur.className.trim().split(/\s+/).slice(0, 2).join('.');
        if (cls) part += '.' + cls;
      }
      parts.unshift(part);
      cur = cur.parentElement;
    }
    return parts.join(' > ');
  };

  // ---------- helpers ----------

  const hslOf = (rgbString) => {
    // Parse rgb(r,g,b) or rgba(r,g,b,a) and convert to HSL.
    // Returns {h,s,l} where h:0-360, s:0-1, l:0-1, or null if parse fails.
    const m = /rgba?\(([^)]+)\)/.exec(rgbString || '');
    if (!m) return null;
    const parts = m[1].split(',').map(p => parseFloat(p.trim()));
    if (parts.length < 3 || parts.some(isNaN)) return null;
    const [r, g, b] = parts.map(v => v / 255);
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    const l = (max + min) / 2;
    let h = 0, s = 0;
    if (max !== min) {
      const d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      switch (max) {
        case r: h = ((g - b) / d + (g < b ? 6 : 0)) * 60; break;
        case g: h = ((b - r) / d + 2) * 60; break;
        case b: h = ((r - g) / d + 4) * 60; break;
      }
    }
    return { h, s, l };
  };

  const isPurpleHue = (h, s) => {
    // Violet/purple/indigo range, only if saturated enough.
    return s >= 0.35 && ((h >= 240 && h <= 310) || (h >= 220 && h <= 240 && s >= 0.5));
  };

  const visible = (el) => {
    if (!el || !el.getBoundingClientRect) return false;
    const r = el.getBoundingClientRect();
    if (r.width === 0 || r.height === 0) return false;
    const cs = getComputedStyle(el);
    return cs.display !== 'none' && cs.visibility !== 'hidden' && parseFloat(cs.opacity || '1') > 0.01;
  };

  const safeText = (el) => (el?.innerText || '').trim();

  const findings = [];
  const add = (f) => {
    f.id = `slop_${findings.length + 1}`;
    findings.push(f);
  };

  // ---------- Rule 1: Purple/violet/indigo gradients on hero/body ----------
  // Signal: linear/radial gradient on body/main/first <section> whose
  // dominant color stops are in the purple-violet-indigo hue range.
  (() => {
    const candidates = [document.body, document.querySelector('main'),
                       document.querySelector('section'), document.querySelector('header')]
                       .filter(Boolean);
    for (const el of candidates) {
      const cs = getComputedStyle(el);
      const bg = cs.backgroundImage || '';
      if (!bg.includes('gradient')) continue;
      // Pull every rgb(...)/rgba(...) inside the gradient string.
      const colors = Array.from(bg.matchAll(/rgba?\([^)]+\)/g)).map(m => m[0]);
      const purpleCount = colors.map(hslOf).filter(c => c && isPurpleHue(c.h, c.s)).length;
      if (purpleCount >= 2 || (purpleCount >= 1 && colors.length <= 2)) {
        add({
          severity: 'high',
          category: 'ai_slop_purple_gradient',
          title: 'Purple/violet gradient background detected',
          hint: 'Pick a single saturated brand color and earn contrast through hierarchy and typography, not gradient hue cycles.',
          evidence: { background_image: bg.slice(0, 200), purple_color_stops: purpleCount },
          selectors: [cssPath(el)],
          positive_reference: 'Linear (graphite + electric blue), Stripe (off-white + indigo accent)',
          confidence: 0.85,
        });
        return;
      }
    }
  })();

  // ---------- Rule 2: 3-column feature grid (icon-in-circle + h3 + paragraph) ----------
  (() => {
    // Look for parent containers with exactly 3 direct children that all
    // contain an icon-like element + heading + paragraph.
    const grids = document.querySelectorAll('section, div');
    for (const grid of grids) {
      const cs = getComputedStyle(grid);
      const isGrid = cs.display === 'grid' || cs.display === 'flex';
      if (!isGrid) continue;
      const children = Array.from(grid.children).filter(visible);
      if (children.length !== 3) continue;
      // Each child must contain an icon (svg/img/i) + a heading + a paragraph.
      const matches = children.filter(child => {
        const hasIcon = child.querySelector('svg, img, i[class*="icon"]');
        const hasHeading = child.querySelector('h2, h3, h4');
        const hasPara = child.querySelector('p');
        return hasIcon && hasHeading && hasPara;
      });
      if (matches.length === 3) {
        // Confirm the icon is in a colored circle on at least one.
        const iconParent = matches[0].querySelector('svg, img, i[class*="icon"]')?.parentElement;
        const iconCs = iconParent ? getComputedStyle(iconParent) : null;
        const circleIcon = iconCs && parseFloat(iconCs.borderRadius) >= 16 &&
                          iconCs.backgroundColor !== 'rgba(0, 0, 0, 0)';
        add({
          severity: 'high',
          category: 'ai_slop_3col_feature_grid',
          title: '3-column feature grid (icon + title + 2-line description × 3)',
          hint: 'The most recognizable AI-generated layout. Try an asymmetric grid, content-led rhythm, or merge into a single denser narrative section.',
          evidence: { icon_in_colored_circle: !!circleIcon, child_count: 3 },
          selectors: [cssPath(grid)],
          positive_reference: 'Stripe homepage (asymmetric, mixed-width feature blocks), Linear (no feature grid at all on landing)',
          confidence: circleIcon ? 0.95 : 0.8,
        });
        return; // only flag the first instance — pattern is the issue, not its frequency
      }
    }
  })();

  // ---------- Rule 3: Icons in colored circles ----------
  (() => {
    const icons = document.querySelectorAll('svg, img');
    const circleHosts = [];
    for (const icon of icons) {
      const parent = icon.parentElement;
      if (!parent || !visible(parent)) continue;
      const cs = getComputedStyle(parent);
      const radius = parseFloat(cs.borderRadius);
      const r = parent.getBoundingClientRect();
      // "Circle" = radius >= 50% of half the bounding box, and a real bg color
      const isCircle = radius > 0 && radius >= Math.min(r.width, r.height) * 0.4;
      const hasBgColor = cs.backgroundColor && cs.backgroundColor !== 'rgba(0, 0, 0, 0)' &&
                        !cs.backgroundColor.endsWith(', 0)');
      // Icon must be small (decoration, not content)
      const iconR = icon.getBoundingClientRect();
      const isSmall = iconR.width <= 48 && iconR.height <= 48;
      if (isCircle && hasBgColor && isSmall) {
        circleHosts.push(parent);
      }
    }
    if (circleHosts.length >= 3) {
      add({
        severity: 'medium',
        category: 'ai_slop_icons_in_colored_circles',
        title: `${circleHosts.length} icons in colored circles (SaaS starter template look)`,
        hint: 'Replace decorative icon-in-circle with monochrome line icons, or remove icons entirely if they decorate without informing.',
        evidence: { count: circleHosts.length },
        selectors: circleHosts.slice(0, 3).map(cssPath),
        positive_reference: 'Raycast (monochrome line icons), GitHub (Octicons used sparingly with content)',
        confidence: 0.75,
      });
    }
  })();

  // ---------- Rule 4: Centered everything (text-align:center on most headings) ----------
  (() => {
    const headings = Array.from(document.querySelectorAll('h1, h2, h3'));
    if (headings.length < 3) return;
    const centered = headings.filter(h => getComputedStyle(h).textAlign === 'center');
    const ratio = centered.length / headings.length;
    if (ratio >= 0.75) {
      add({
        severity: 'medium',
        category: 'ai_slop_centered_everything',
        title: `${Math.round(ratio * 100)}% of headings are center-aligned (${centered.length}/${headings.length})`,
        hint: 'Centered everything = no hierarchy. Use left-aligned headings; reserve center for marketing hero only.',
        evidence: { centered_headings: centered.length, total_headings: headings.length },
        selectors: centered.slice(0, 3).map(cssPath),
        positive_reference: 'GitHub, Linear, Stripe — all left-align body and most headings',
        confidence: 0.8,
      });
    }
  })();

  // ---------- Rule 5: Uniform bubbly border-radius across all elements ----------
  (() => {
    const els = Array.from(document.querySelectorAll('button, a, .card, [class*="card"], [class*="btn"], section > div, article'))
                  .filter(visible).slice(0, 200);
    if (els.length < 5) return;
    const radii = {};
    for (const el of els) {
      const r = parseFloat(getComputedStyle(el).borderTopLeftRadius);
      if (r >= 8) {
        const bucket = Math.round(r); // 1px buckets
        radii[bucket] = (radii[bucket] || 0) + 1;
      }
    }
    const entries = Object.entries(radii).sort((a, b) => b[1] - a[1]);
    if (!entries.length) return;
    const [topR, topCount] = entries[0];
    if (topCount >= 5 && parseInt(topR) >= 12) {
      add({
        severity: 'low',
        category: 'ai_slop_uniform_bubbly_radius',
        title: `${topCount} elements share a large border-radius of ${topR}px`,
        hint: 'Mixed radii by element type look intentional; uniform large radius on everything reads as a default Tailwind preset.',
        evidence: { repeated_radius_px: parseInt(topR), occurrences: topCount },
        selectors: [],
        positive_reference: 'Linear: buttons 6px, cards 10px, inputs 4px (clear hierarchy of softness)',
        confidence: 0.6,
      });
    }
  })();

  // ---------- Rule 6: Emoji as design elements in headings ----------
  (() => {
    const emojiRe = /[\u{1F300}-\u{1FAFF}\u{1F900}-\u{1F9FF}\u{2600}-\u{27BF}]/u;
    const hits = [];
    for (const h of document.querySelectorAll('h1, h2, h3, h4, .hero, [class*="hero"]')) {
      const txt = safeText(h);
      if (emojiRe.test(txt)) hits.push({ el: h, text: txt.slice(0, 80) });
    }
    if (hits.length >= 2) {
      add({
        severity: 'medium',
        category: 'ai_slop_emoji_in_headings',
        title: `Emoji used as decoration in ${hits.length} heading(s)`,
        hint: 'Rockets-in-headings and emoji-as-bullets are AI-template hallmarks. Use real iconography or strong typography for emphasis.',
        evidence: { samples: hits.slice(0, 3).map(h => h.text) },
        selectors: hits.slice(0, 3).map(h => cssPath(h.el)),
        positive_reference: 'Stripe, GitHub — zero emoji in marketing copy',
        confidence: 0.7,
      });
    }
  })();

  // ---------- Rule 7: Colored left-border on cards ----------
  (() => {
    const els = Array.from(document.querySelectorAll('div, article, section')).filter(visible);
    const matches = [];
    for (const el of els) {
      const cs = getComputedStyle(el);
      const lw = parseFloat(cs.borderLeftWidth);
      const tw = parseFloat(cs.borderTopWidth);
      const rw = parseFloat(cs.borderRightWidth);
      const bw = parseFloat(cs.borderBottomWidth);
      // Left border only, > 2px, colored (not transparent), not full border
      if (lw >= 2 && tw <= 1 && rw <= 1 && bw <= 1 &&
          cs.borderLeftColor !== 'rgba(0, 0, 0, 0)') {
        matches.push(el);
        if (matches.length >= 6) break;
      }
    }
    if (matches.length >= 3) {
      add({
        severity: 'low',
        category: 'ai_slop_left_border_cards',
        title: `${matches.length} cards use a colored left-border accent`,
        hint: 'border-left:3px solid <accent> on cards is a strong AI/template signature. Use background tint or icon for emphasis instead.',
        evidence: { count: matches.length },
        selectors: matches.slice(0, 3).map(cssPath),
        positive_reference: 'Stripe, Linear — solid card backgrounds with subtle shadow, no accent borders',
        confidence: 0.7,
      });
    }
  })();

  // ---------- Rule 8: Generic hero copy ----------
  (() => {
    const h1 = document.querySelector('h1');
    if (!h1) return;
    const txt = safeText(h1).toLowerCase();
    const patterns = [
      { re: /^welcome to /i, label: '"Welcome to..."' },
      { re: /unlock the power of/i, label: '"Unlock the power of..."' },
      { re: /your all[- ]in[- ]one/i, label: '"Your all-in-one..."' },
      { re: /(transform|revolutionize|empower).*(business|workflow|team)/i, label: 'Generic "transform/revolutionize/empower" claim' },
      { re: /the (future|next generation) of/i, label: '"The future/next generation of..."' },
      { re: /built for (modern|the modern)/i, label: '"Built for modern..."' },
      { re: /effortlessly /i, label: '"Effortlessly..."' },
    ];
    for (const p of patterns) {
      if (p.re.test(txt)) {
        add({
          severity: 'medium',
          category: 'ai_slop_generic_hero_copy',
          title: `Generic AI hero copy: ${p.label}`,
          hint: 'Replace with a specific claim: the actual job, audience, or paradox your product solves. "Linear is shaped by the practices and principles..." beats "The future of project management."',
          evidence: { h1_text: safeText(h1).slice(0, 120) },
          selectors: [cssPath(h1)],
          positive_reference: 'Linear: "Linear is a purpose-built tool for planning..." (specific, not promotional)',
          confidence: 0.85,
        });
        return;
      }
    }
  })();

  // ---------- Rule 9: system-ui as PRIMARY display/body font ----------
  (() => {
    const bodyFont = getComputedStyle(document.body).fontFamily.toLowerCase();
    const h1 = document.querySelector('h1');
    const h1Font = h1 ? getComputedStyle(h1).fontFamily.toLowerCase() : '';
    const isSystem = (ff) => /^\s*(system-ui|-apple-system|blinkmacsystemfont|"segoe ui")/.test(ff);
    if (isSystem(bodyFont) || isSystem(h1Font)) {
      add({
        severity: 'medium',
        category: 'ai_slop_system_ui_font',
        title: 'system-ui used as primary display/body font',
        hint: 'system-ui as the PRIMARY font is the "I gave up on typography" signal. Pick a real typeface — even one well-chosen font lifts a design.',
        evidence: { body_font: bodyFont.slice(0, 100), h1_font: h1Font.slice(0, 100) },
        selectors: ['body', 'h1'].filter((_, i) => isSystem([bodyFont, h1Font][i])),
        positive_reference: 'Linear (Inter Display custom), Stripe (Sohne custom), Raycast (Geist Mono custom)',
        confidence: 0.7,
      });
    }
  })();

  // ---------- Rule 10: Decorative blobs / wavy SVG dividers ----------
  (() => {
    const svgs = document.querySelectorAll('svg');
    let blobs = 0;
    const samples = [];
    for (const svg of svgs) {
      if (!visible(svg)) continue;
      const path = svg.querySelector('path');
      if (!path) continue;
      const d = path.getAttribute('d') || '';
      // Heuristic: long path string with mostly C (cubic bezier) commands and
      // few line commands → likely a blob/wave decoration. Real icons use
      // short geometric paths with L/M/Z commands.
      const len = d.length;
      const cCount = (d.match(/[Cc]/g) || []).length;
      const lCount = (d.match(/[Ll]/g) || []).length;
      if (len >= 80 && cCount >= 4 && cCount > lCount) {
        const r = svg.getBoundingClientRect();
        // Decoration is usually wide and short OR positioned absolutely
        const cs = getComputedStyle(svg);
        if (r.width >= 200 || cs.position === 'absolute' || cs.position === 'fixed') {
          blobs++;
          if (samples.length < 3) samples.push(cssPath(svg));
        }
      }
    }
    if (blobs >= 2) {
      add({
        severity: 'low',
        category: 'ai_slop_decorative_blobs',
        title: `${blobs} decorative blob/wave SVGs detected`,
        hint: 'Decorative blobs and wavy dividers fill empty space that better content would fill. Cut them — if a section feels empty, the content is too thin.',
        evidence: { count: blobs },
        selectors: samples,
        positive_reference: 'Linear, Stripe — flat sections, content carries the visual weight',
        confidence: 0.6,
      });
    }
  })();

  // ---------- Rule 11: Cookie-cutter section rhythm (hero → 3 features → testimonials → pricing → CTA) ----------
  (() => {
    const sections = Array.from(document.querySelectorAll('section, main > div')).filter(visible);
    if (sections.length < 4 || sections.length > 12) return;
    const classes = sections.map(s => (s.className || '').toLowerCase());
    const text = sections.map(s => safeText(s).slice(0, 200).toLowerCase());
    const has = (kw) => classes.some(c => c.includes(kw)) || text.some(t => t.includes(kw));
    const signals = {
      hero: has('hero') || has('banner') || !!sections[0]?.querySelector('h1'),
      features: has('feature'),
      testimonials: has('testimonial') || has('review') || has('quote'),
      pricing: has('pricing') || has('price') || has('plan'),
      cta: has('cta') || text.some(t => /(get started|try free|sign up|start now)/i.test(t)),
    };
    const hits = Object.values(signals).filter(Boolean).length;
    if (hits >= 4) {
      add({
        severity: 'low',
        category: 'ai_slop_cookie_cutter_rhythm',
        title: `Stock SaaS section rhythm (${hits}/5 signals: hero + features + testimonials + pricing + CTA)`,
        hint: 'Every AI-generated landing page has this exact rhythm. Reorder, merge, or skip sections that don\'t earn their place. A landing page without pricing is more memorable than one with pricing.',
        evidence: signals,
        selectors: [],
        positive_reference: 'Linear has no pricing on landing; Raycast leads with product imagery, not features',
        confidence: 0.5,
      });
    }
  })();

  // ---------- summary ----------
  const bySev = { high: 0, medium: 0, low: 0 };
  for (const f of findings) bySev[f.severity] = (bySev[f.severity] || 0) + 1;
  // Score: 100 baseline, -25 per high, -10 per medium, -3 per low
  let score = 100 - bySev.high * 25 - bySev.medium * 10 - bySev.low * 3;
  if (score < 0) score = 0;
  const grade = score >= 90 ? 'A' : score >= 75 ? 'B' : score >= 60 ? 'C' : score >= 40 ? 'D' : 'F';

  return {
    page: {
      url: location.href,
      title: document.title,
      viewport: { w: innerWidth, h: innerHeight },
    },
    findings,
    summary: {
      total: findings.length,
      by_severity: bySev,
      score,           // 0-100, higher = less AI slop
      grade,           // A-F
      verdict: score >= 75 ? 'looks human-designed'
             : score >= 50 ? 'AI signals present, but salvageable'
             : 'reads as AI-generated; needs design intervention',
    },
  };
})()
