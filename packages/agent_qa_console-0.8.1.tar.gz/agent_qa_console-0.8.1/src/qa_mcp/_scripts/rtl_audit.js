// RTL / Hebrew audit — viewport-aware, with proper category separation.
//
// Fix log (vs v0.1):
//  - rtl_digits now ONLY catches pure digits in Hebrew text (was catching
//    Latin-letter-mixed strings like "MP3, WAV, M4A" which are legitimate).
//  - New category rtl_latin_mixed for Latin letters next to Hebrew (lower
//    severity, with whitelist for common acronyms).
//  - New category rtl_text_overflow for text that visually overflows its
//    container (viewport-aware — different on mobile vs desktop).
//  - Selectors now: id → data-testid/data-qa → nth-of-type path. CSS.escape
//    on class fallback. xpath field added.
((opts) => {
  // opts.ignore_patterns: array of regex strings → text matching ANY of these
  //                      is silenced before checking (e.g. ["v\\d+\\.\\d+"]).
  // opts.ignore_selectors: array of CSS selectors → elements matching any
  //                      of these are skipped entirely (e.g. [".version-badge"]).
  const O = opts || {};
  const ignorePatterns = (O.ignore_patterns || []).map(p => {
    try { return new RegExp(p); } catch { return null; }
  }).filter(Boolean);
  const ignoreSelectors = O.ignore_selectors || [];
  const isIgnored = (el) => {
    for (const sel of ignoreSelectors) {
      try { if (el.matches && el.matches(sel)) return true; } catch {}
      try { if (el.closest && el.closest(sel)) return true; } catch {}
    }
    return false;
  };
  const textIgnored = (text) => ignorePatterns.some(re => re.test(text));
  const smartIgnore = O.smart_ignore !== false;
  const reportMode = O.report_mode || 'internal_full';
  const minConfidence = typeof O.min_confidence === 'number' ? O.min_confidence : 0.85;
  // Israeli Hebrew sites commonly use both "₪99" and "99 ₪" depending on
  // design/accounting/product style. Do not flag symbol position by default.
  // Enable only for teams with an explicit style guide preferring number-first.
  const strictCurrencyPosition = O.strict_currency_position === true;
  const isLikelySafeNumericText = (text, el) => {
    if (!smartIgnore) return false;
    const t = String(text || '').trim();
    if (!t) return false;
    const digitsOnly = t.replace(/[^0-9]/g, '');
    if (!digitsOnly) return true;

    const stripSafe = (s) => String(s)
      // Semantic / conventional machine-readable tokens.
      .replace(/\b(?:v\d+(?:\.\d+)+|#\d{2,}|id\s*\d{2,})\b/gi, ' ')
      // Date-like tokens are handled by rtl_date_ambiguous.
      .replace(/\b\d{1,2}[\/\-.]\d{1,2}[\/\-.]\d{2,4}\b/g, ' ')
      // Time ranges are safe numeric UI copy.
      .replace(/\b\d{1,2}:\d{2}(?:\s*-\s*\d{1,2}:\d{2})?\b/g, ' ')
      // Correct and incorrect currency placement is handled by rtl_currency.
      .replace(/₪\s*\d[\d,.]*/g, ' ')
      .replace(/\d[\d,.]*\s*₪/g, ' ')
      // Ratings / ratios / review counts: "4.9/5 · 150+ ביקורות".
      .replace(/\d+(?:\.\d+)?\s*\/\s*\d+(?:\.\d+)?(?:\s*[·•-]\s*\d+\+?\s*[֐-׿]+)?/g, ' ')
      .replace(/\d+\+\s*[֐-׿]+/g, ' ')
      // Percentages and numeric values are standard in Hebrew UI copy.
      .replace(/\d+(?:\.\d+)?\s*%/g, ' ')
      // Common Hebrew count/unit nouns. This is intentionally broad because
      // "12 הקלטות", "279.8 דקות" and similar counters are valid Hebrew UI.
      .replace(/\d+(?:\.\d+)?\s+(?:[֐-׿]+(?:ים|ות)|פריט|פריטים|הודעה|הודעות|שעה|שעות|דקה|דקות|יום|ימים|שפה|שפות|קובץ|קבצים|משתמש|משתמשים|לקוח|לקוחות|הקלטה|הקלטות|ביקורת|ביקורות|דקות|שניות|אחוז|אחוזים)/g, ' ')
      // Hebrew noun/label followed by a number, e.g. "דובר 1", "שלב 02".
      .replace(/(?:דובר|עמוד|שלב|סעיף|גרסה|חודש|שעה|שעות|מסך|פרק|חלק)\s+\d{1,4}/g, ' ')
      // IDs / SKUs / tracking: "ID: ABC-12345", "SKU: 456".
      .replace(/\b(?:ID|SKU|REF|ISRC|ISBN|UPC|EAN)[\s:]?[A-Za-z0-9-]{2,20}/gi, ' ');

    // Machine-readable values are intentional in semantic elements.
    if (el && ['TIME', 'DATA', 'OUTPUT'].includes(el.tagName)) return true;

    // Phone/service/hotline numbers embedded in Hebrew labels.
    if (/(מוקד|טלפון|טלפוני|נייד|פקס|מספר|חייג|שיחה|call|phone|hotline)/i.test(t) && digitsOnly.length >= 3 && digitsOnly.length <= 12) return true;
    if (/^(\+?972|0)?\d{7,10}$/.test(t.replace(/[\s\u200e\u200f\-()]/g, ''))) return true;

    // Numeric-only labels are not mixed BiDi text.
    if (/^[\d\s.,:+\-()%/]+$/.test(t)) return true;

    // If every digit belonged to a known safe token above, suppress rtl_digits.
    return !/\d/.test(stripSafe(t));
  };

  const findings = [];
  const HEB_RE = /[֐-׿]/;
  const lang = document.documentElement.lang || '';
  const bodyText = (document.body && document.body.innerText) || '';
  const isHebrewContext = lang.toLowerCase().startsWith('he') || HEB_RE.test(bodyText);
  const htmlDir = document.documentElement.dir || '';

  // Whitelist of common acronyms / format names / tech terms that legitimately
  // appear in Hebrew text and shouldn't be flagged as RTL bugs.
  const ACRONYM_WHITELIST = new Set([
    'MP3','MP4','WAV','M4A','OGG','FLAC','AAC','AVI','MOV','WEBM','WEBP','SVG','PNG','JPG','JPEG','GIF','PDF','DOC','DOCX','XLS','XLSX','PPT','PPTX','CSV','JSON','XML','HTML','CSS','JS','TS','API','APIs','AI','ML','GPU','CPU','RAM','SSD','HDD','USB','HDMI','HTTP','HTTPS','SSL','TLS','URL','URI','DNS','VPN','SaaS','IaaS','PaaS','CEO','CTO','CFO','VP','HR','PR','UX','UI','QA','SEO','SEM','CRM','ERP','iOS','iPhone','iPad','Mac','PC','Windows','Linux','Android','React','Vue','Node','Python','SQL','NoSQL','OK','LCP','FCP','TTFB','GPS','OTP','SMS','PIN','ID','CV','LCD','LED','OLED','3D','4K','8K','GB','MB','KB','TB','MHz','GHz','RGB','PWA','SPA','MVP','POC','ROI','KPI','OKR','BI','BPM','SLA','GDPR','HIPAA','OWASP','VR','AR','XR','NFT','DAO','BLT','NLP','LLM','GPT','ChatGPT','OpenAI','GitHub','GitLab','AWS','GCP','Azure','Stripe','PayPal','Visa','MasterCard','BIT','BiT'
  ]);

  // ---- selector helpers ----

  // CSS-escape a class/id segment per CSS.escape spec.
  const cssEsc = (s) => {
    if (typeof CSS !== 'undefined' && CSS.escape) return CSS.escape(s);
    return String(s).replace(/[^\w-]/g, ch => '\\' + ch);
  };

  // Stable selector strategy: prefer ids/data attrs, then path of nth-of-type,
  // then class-based with escape (last resort).
  const stableSelector = (el) => {
    if (!el || el.nodeType !== 1) return '';
    if (el.id) return '#' + cssEsc(el.id);
    const dataAttrs = ['data-testid','data-qa','data-cy','data-test','data-automation-id'];
    for (const a of dataAttrs) {
      const v = el.getAttribute(a);
      if (v) return `[${a}="${v.replace(/"/g, '\\"')}"]`;
    }
    // nth-of-type path from root
    const parts = [];
    let cur = el;
    while (cur && cur.nodeType === 1 && cur !== document.documentElement && parts.length < 6) {
      const parent = cur.parentElement;
      if (!parent) break;
      const tag = cur.tagName.toLowerCase();
      const sib = Array.from(parent.children).filter(c => c.tagName === cur.tagName);
      const idx = sib.indexOf(cur) + 1;
      parts.unshift(`${tag}:nth-of-type(${idx})`);
      cur = parent;
    }
    return parts.join(' > ') || el.tagName.toLowerCase();
  };

  // Simple xpath (root-rooted) for tools that prefer xpath
  const xpathFor = (el) => {
    if (!el || el.nodeType !== 1) return '';
    if (el.id) return `//*[@id="${el.id}"]`;
    const parts = [];
    let cur = el;
    while (cur && cur.nodeType === 1 && cur !== document.documentElement) {
      const parent = cur.parentElement;
      if (!parent) break;
      const sib = Array.from(parent.children).filter(c => c.tagName === cur.tagName);
      const idx = sib.indexOf(cur) + 1;
      parts.unshift(`${cur.tagName.toLowerCase()}[${idx}]`);
      cur = parent;
    }
    return '/' + parts.join('/');
  };

  const sample = (text) => (text || '').trim().slice(0, 80);

  // Strip whitelisted acronyms from text so we don't get false positives
  // when checking "is there latin in this hebrew?".
  const stripAcronyms = (text) => {
    return text.replace(/\b[A-Z][A-Z0-9]{1,8}\b/g, (m) => ACRONYM_WHITELIST.has(m) ? ' ' : m);
  };

  // ---- 1. Numeric BiDi review in Hebrew text ----
  // Important: modern Hebrew websites normally use European digits (0-9).
  // Digits are NOT a bug by themselves. W3C bidi guidance focuses on base
  // direction and isolation of opposite-direction runs; CLDR/Intl he-IL also
  // formats normal numbers with 0-9. Therefore this category is low-confidence
  // review-only and should fire only when a number appears in free Hebrew text
  // outside known-safe UI patterns.
  document.querySelectorAll('body *').forEach((el) => {
    if (isIgnored(el)) return;
    if (el.children.length > 0) return;
    const t = el.innerText || '';
    if (!HEB_RE.test(t)) return;
    if (t.length > 200) return;
    if (textIgnored(t)) return;
    const stripped = stripAcronyms(t);
    // Only flag if there's a digit NOT inside an acronym
    if (!/\d/.test(stripped)) return;
    if (isLikelySafeNumericText(t, el)) return;
    findings.push({
      severity: 'low',
      category: 'rtl_digits',
      title: 'בדיקת BiDi למספר בתוך טקסט עברי',
      hint: 'ספרות 0-9 תקינות בעברית. בדוק רק אם נדרש <bdi>/<data>/<time> כדי למנוע ערבוב כיווניות.',
      sample: sample(t),
      selector: stableSelector(el),
      xpath: xpathFor(el),
    });
  });

  // ---- 2. Currency style-guide check (off by default) ----
  if (isHebrewContext && strictCurrencyPosition) document.querySelectorAll('body *').forEach((el) => {
    if (isIgnored(el)) return;
    if (el.children.length > 0) return;
    const t = el.innerText || '';
    if (textIgnored(t)) return;
    if (/₪\s*\d/.test(t)) {
      findings.push({
        severity: 'medium',
        category: 'rtl_currency',
        title: 'סגנון מטבע ₪ לא תואם style guide מחמיר',
        hint: 'בישראל נפוצים גם "₪99" וגם "99 ₪". ממצא זה מופיע רק כשהופעל strict_currency_position.',
        sample: sample(t),
        selector: stableSelector(el),
        xpath: xpathFor(el),
      });
    }
  });

  // ---- 3. English placeholder in Hebrew form ----
  if (isHebrewContext) {
    document.querySelectorAll('input[placeholder], textarea[placeholder]').forEach((el) => {
      if (isIgnored(el)) return;
      const ph = el.placeholder || '';
      if (textIgnored(ph)) return;
      if (ph && !HEB_RE.test(ph) && /[a-zA-Z]/.test(ph)) {
        // Skip if it's a pure email format string ("you@example.com")
        if (/^[\w.+-]+@[\w.-]+\.\w+$/.test(ph.trim())) return;
        findings.push({
          severity: 'medium',
          category: 'rtl_english_placeholder',
          title: 'placeholder באנגלית בשדה עברי',
          hint: 'תרגם את ה-placeholder לעברית',
          sample: ph,
          selector: stableSelector(el),
          xpath: xpathFor(el),
        });
      }
    });
  }

  // ---- 4. Wrong arrow direction in CTAs ----
  document.querySelectorAll('button, a').forEach((el) => {
    if (isIgnored(el)) return;
    const t = (el.innerText || '').trim();
    if (textIgnored(t)) return;
    if (HEB_RE.test(t) && /→/.test(t) && !/←/.test(t)) {
      findings.push({
        severity: 'medium',
        category: 'rtl_arrow_direction',
        title: 'חץ → בכפתור עברי (אמור להיות ←)',
        hint: 'בכיוון RTL חץ "הבא" הוא ←',
        sample: sample(t),
        selector: stableSelector(el),
        xpath: xpathFor(el),
      });
    }
  });

  // ---- 5. English-only CTA in Hebrew product ----
  if (isHebrewContext) {
    document.querySelectorAll('button, a[role="button"]').forEach((el) => {
      if (isIgnored(el)) return;
      const t = (el.innerText || '').trim();
      if (textIgnored(t)) return;
      if (t.length > 0 && t.length < 30 && !HEB_RE.test(t) &&
          /^[A-Za-z\s'!?\-]+$/.test(t) && !ACRONYM_WHITELIST.has(t)) {
        findings.push({
          severity: 'medium',
          category: 'rtl_english_cta',
          title: 'כפתור CTA באנגלית במוצר עברי',
          hint: 'תרגם את הכיתוב לעברית',
          sample: t,
          selector: stableSelector(el),
          xpath: xpathFor(el),
        });
      }
    });
  }

  // ---- 6. NEW: Latin letters mixed inside Hebrew (separate from digits) ----
  if (isHebrewContext) document.querySelectorAll('body *').forEach((el) => {
    if (isIgnored(el)) return;
    if (el.children.length > 0) return;
    const t = el.innerText || '';
    if (!HEB_RE.test(t)) return;
    if (t.length > 200) return;
    if (textIgnored(t)) return;
    if (isLikelySafeNumericText(t, el)) return;
    const stripped = stripAcronyms(t);
    // Latin words in a Hebrew sentence, AFTER stripping known acronyms.
    // Treat this as low-confidence/review-only: brand names may be legitimate,
    // but they often need <bdi> to avoid BiDi drift.
    const latinWords = stripped.match(/\b[A-Za-z][A-Za-z0-9'_-]{1,20}\b/g) || [];
    if (latinWords.length === 0) return;
    if (latinWords.every(w => ACRONYM_WHITELIST.has(w))) return;
    if (el.tagName === 'BDI' || el.closest('bdi')) return;
    findings.push({
      severity: 'low',
      category: 'rtl_latin_mixed',
      title: 'אותיות לטיניות מעורבות בעברית ללא <bdi>',
      hint: 'עטוף את החלק הלטיני ב-<bdi> כדי למנוע BiDi drift',
      sample: sample(t),
      selector: stableSelector(el),
      xpath: xpathFor(el),
    });
  });

  // ---- 7. dir / lang mismatch ----
  if (lang.toLowerCase().startsWith('he') && htmlDir !== 'rtl') {
    findings.push({
      severity: 'high',
      category: 'rtl_dir_missing',
      title: 'lang="he" אבל אין dir="rtl" על <html>',
      hint: 'הוסף dir="rtl" ל-<html>',
      sample: `<html lang="${lang}" dir="${htmlDir}">`,
      selector: 'html',
      xpath: '/html',
    });
  }

  // ---- 9. Hebrew plural agreement ----
  // "1 פריטים" / "2 פריט" — wrong number-noun agreement.
  // Heuristics:
  //   "1 X" where X ends with ים (m.pl) or ות (f.pl) → singular expected
  //   "[2-10] X" where X does NOT end with ים/ות → plural expected
  // Skip well-known mass nouns and digit/time strings (we don't conjugate "1 km").
  if (isHebrewContext) {
    const PLURAL_END = /(ים|ות)$/;
    const HEB_WORD = /[֐-׿]+/;
    const NUM_RE = /\b(\d{1,2})\s+([֐-׿]+)\b/g;
    const MASS_NOUNS = new Set(['חצי','רבע','שליש','אחוז','קמ','מטר','קמ"ר','ק"ג','גרם','דולר','שקל']);
    document.querySelectorAll('body *').forEach((el) => {
      if (isIgnored(el)) return;
      if (el.children.length > 0) return;
      const t = el.innerText || '';
      if (!HEB_WORD.test(t)) return;
      if (t.length > 200) return;
      if (textIgnored(t)) return;
      let m;
      const re = /(\d{1,2})\s+([֐-׿]+)/g;
      while ((m = re.exec(t)) !== null) {
        const num = parseInt(m[1], 10);
        const word = m[2];
        if (MASS_NOUNS.has(word)) continue;
        const isPlural = PLURAL_END.test(word);
        let bug = null;
        if (num === 1 && isPlural) bug = `"${num} ${word}" — צורת רבים אחרי "1"`;
        else if (num >= 2 && num <= 10 && !isPlural) bug = `"${num} ${word}" — צורת יחיד אחרי "${num}"`;
        if (bug) {
          findings.push({
            severity: 'high',
            category: 'rtl_plural',
            title: 'הסכמת מספר-שם בעברית',
            hint: 'התאם את הצורה: "1 פריט" / "2 פריטים". לטקסט דינמי השתמש בפונקציית plural של i18n.',
            sample: bug,
            selector: stableSelector(el),
            xpath: xpathFor(el),
          });
          break;  // one finding per element
        }
      }
    });
  }

  // ---- 10. Ambiguous date format ----
  // "03/04/2026" — DD/MM or MM/DD? In Hebrew sites, ambiguous to readers
  // who consume content from US/EU sources. Flag when both numbers are ≤12.
  if (isHebrewContext) {
    const DATE_AMBIG = /\b(\d{1,2})[\/\-\.](\d{1,2})[\/\-\.](\d{2,4})\b/;
    document.querySelectorAll('body *').forEach((el) => {
      if (isIgnored(el)) return;
      if (el.children.length > 0) return;
      const t = el.innerText || '';
      if (t.length > 200) return;
      if (textIgnored(t)) return;
      const m = DATE_AMBIG.exec(t);
      if (!m) return;
      const a = parseInt(m[1], 10), b = parseInt(m[2], 10);
      // Only flag if both could be a month (1-12) AND not equal
      if (a >= 1 && a <= 12 && b >= 1 && b <= 12 && a !== b) {
        findings.push({
          severity: 'medium',
          category: 'rtl_date_ambiguous',
          title: 'פורמט תאריך דו-משמעי',
          hint: 'בעברית "03/04" יכול להיות 3 באפריל או 4 במרץ. השתמש ב-YYYY-MM-DD או חודש כתוב.',
          sample: m[0],
          selector: stableSelector(el),
          xpath: xpathFor(el),
        });
      }
    });
  }

  // ---- 8. NEW: Viewport-aware text overflow ----
  // Only meaningful on smaller viewports — flags Hebrew text that visually
  // overflows its parent container (common RTL bug on mobile).
  if (isHebrewContext) document.querySelectorAll('body *').forEach((el) => {
    if (isIgnored(el)) return;
    if (el.children.length > 0) return;
    const t = el.innerText || '';
    if (!HEB_RE.test(t)) return;
    if (t.length < 20) return;
    if (textIgnored(t)) return;
    const r = el.getBoundingClientRect();
    if (r.width < 1 || r.height < 1) return;
    // Detect horizontal overflow: scrollWidth > clientWidth on parent
    const parent = el.parentElement;
    if (!parent) return;
    const parentRect = parent.getBoundingClientRect();
    if (r.right > parentRect.right + 2 || r.left < parentRect.left - 2) {
      findings.push({
        severity: 'medium',
        category: 'rtl_text_overflow',
        title: 'טקסט עברי גולש מחוץ לקונטיינר',
        hint: 'בדוק overflow / max-width / direction בקונטיינר. נפוץ במובייל ב-RTL.',
        sample: sample(t),
        selector: stableSelector(el),
        xpath: xpathFor(el),
        viewport: { w: window.innerWidth, h: window.innerHeight },
      });
    }
  });

  // ---- Client-safe confidence layer ----
  // The raw heuristics above intentionally catch more than we show clients.
  // Confidence lets reports include only deterministic, low-noise findings while
  // keeping borderline UX/BiDi hints available for internal review.
  const CONFIDENCE_BY_CATEGORY = {
    rtl_dir_missing: 0.98,
    rtl_currency: 0.70,
    rtl_plural: 0.92,
    rtl_arrow_direction: 0.90,
    rtl_english_placeholder: 0.88,
    rtl_english_cta: 0.82,
    rtl_date_ambiguous: 0.78,
    rtl_text_overflow: 0.72,
    rtl_digits: 0.45,
    rtl_latin_mixed: 0.62,
  };
  const FIX_KIND_BY_CATEGORY = {
    rtl_dir_missing: 'code_config',
    rtl_currency: 'content_format',
    rtl_plural: 'i18n_pluralization',
    rtl_arrow_direction: 'rtl_icon_direction',
    rtl_english_placeholder: 'translation',
    rtl_english_cta: 'translation',
    rtl_date_ambiguous: 'date_format',
    rtl_text_overflow: 'responsive_layout',
    rtl_digits: 'bidi_markup_review',
    rtl_latin_mixed: 'bidi_markup_review',
  };
  const annotatedFindings = findings.map((f) => {
    const confidence = CONFIDENCE_BY_CATEGORY[f.category] ?? 0.70;
    const clientSafe = confidence >= minConfidence && !['rtl_digits', 'rtl_latin_mixed', 'rtl_text_overflow'].includes(f.category);
    return {
      ...f,
      confidence,
      client_safe: clientSafe,
      review_required: !clientSafe,
      fix_kind: FIX_KIND_BY_CATEGORY[f.category] || 'manual_review',
      evidence: {
        selector: f.selector,
        xpath: f.xpath,
        sample: f.sample,
        viewport: f.viewport || { w: window.innerWidth, h: window.innerHeight },
        url: location.href,
      },
    };
  });
  const outputFindings = reportMode === 'client_safe'
    ? annotatedFindings.filter(f => f.client_safe)
    : annotatedFindings;
  const reviewQueue = annotatedFindings.filter(f => !f.client_safe);

  return {
    findings: outputFindings,
    summary: {
      total: outputFindings.length,
      raw_total: annotatedFindings.length,
      client_safe_total: annotatedFindings.filter(f => f.client_safe).length,
      review_required_total: reviewQueue.length,
      report_mode: reportMode,
      min_confidence: minConfidence,
      by_severity: outputFindings.reduce((acc, f) => {
        acc[f.severity] = (acc[f.severity] || 0) + 1;
        return acc;
      }, {}),
      by_category: outputFindings.reduce((acc, f) => {
        acc[f.category] = (acc[f.category] || 0) + 1;
        return acc;
      }, {}),
    },
    review_queue: {
      total: reviewQueue.length,
      by_category: reviewQueue.reduce((acc, f) => {
        acc[f.category] = (acc[f.category] || 0) + 1;
        return acc;
      }, {}),
      samples: reviewQueue.slice(0, 5),
    },
    page: {
      url: location.href,
      lang,
      dir: htmlDir,
      viewport: { w: window.innerWidth, h: window.innerHeight },
    },
  };
})
