"""PDF export for qa-mcp client reports via Playwright built-in Chromium PDF.

Cross-platform — no WeasyPrint/GTK dependency. Uses Playwright's CDP-based
PDF generation, the same engine powering Chrome's "Save as PDF".
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any


def create_client_report_pdf(
    result_json: str,
    out_pdf: str,
    client: str | None = None,
    consultant: str = "BrainboxAI",
) -> dict[str, Any]:
    """Generate a branded PDF report using Playwright's built-in PDF engine.

    Launches a headless Chromium tab, renders the HTML report, and calls
    page.pdf(). Works on Windows, macOS, and Linux.

    Args:
        result_json: Path to qa-result.json.
        out_pdf: Output PDF path.
        client: Client/project name. Falls back to suite name.
        consultant: Consultant/company name for branding.

    Returns:
        { pdf_path, size_bytes, pages, client }
    """
    import asyncio
    from .client_report import _html_report

    suite = json.loads(Path(result_json).read_text(encoding="utf-8"))
    client_name = client or suite.get("name") or "QA Client"
    html_text = _html_report(suite, client_name, consultant)
    out = Path(out_pdf)
    out.parent.mkdir(parents=True, exist_ok=True)

    async def _gen():
        from playwright.async_api import async_playwright
        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=True)
            page = await browser.new_page()
            await page.set_content(html_text, wait_until="networkidle")
            await page.pdf(
                path=str(out),
                format="A4",
                print_background=True,
                margin={"top": "15mm", "right": "15mm", "bottom": "15mm", "left": "15mm"},
            )
            await browser.close()

    asyncio.get_event_loop().run_until_complete(_gen())

    # Estimate pages from HTML content (page-break hints are in the CSS)
    pages = html_text.count("page-break-before") + 1

    return {
        "pdf_path": str(out),
        "size_bytes": out.stat().st_size,
        "pages": pages,
        "client": client_name,
    }
