"""Training data collector — opt-in capture of every qa_* call.

Activated by setting the QA_MCP_TRAINING_DATA_DIR env var. When unset, this
module is a no-op: existing tools behave exactly as before.

Layout:
  <root>/
    <YYYY-MM-DD>/
      <hostname>_<HHMMSS>/
        meta.json       URL, viewport, locale, mcp_version, timestamp, hashes
        page.html       full DOM at audit time
        screenshot.jpg  full-page screenshot (best-effort)
        rtl.json        qa_rtl_audit output
        perf.json       qa_perf_metrics output
        seo.json        qa_seo_check output
        links.json      qa_scan_links output
        a11y.json       qa_a11y_audit output

One folder per audit run, so re-running on the same site doesn't clobber.
Aggregations across runs/days happen in qa_training_export.

PII redaction (when redact=True): masks emails, IL phone numbers, IL ID
numbers in HTML before saving. Redaction is applied AFTER the audit ran on
the real DOM, so findings are unaffected.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
from datetime import datetime
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

# Importlib for version
try:
    from importlib.metadata import version as _pkg_version
    _VERSION = _pkg_version("qa-mcp")
except Exception:
    _VERSION = "unknown"


def is_enabled() -> bool:
    return bool(os.getenv("QA_MCP_TRAINING_DATA_DIR"))


def _root() -> Path | None:
    raw = os.getenv("QA_MCP_TRAINING_DATA_DIR")
    if not raw:
        return None
    p = Path(raw).expanduser()
    p.mkdir(parents=True, exist_ok=True)
    return p


def _safe_host(url: str) -> str:
    try:
        host = urlparse(url).hostname or "unknown"
    except Exception:
        host = "unknown"
    return re.sub(r"[^\w\-.]", "_", host)[:60] or "unknown"


# Per-page run dir is keyed by (session_id, current_url) so multiple audits
# on the same page land in the same folder. Switching pages -> new folder.
_RUN_DIRS: dict[tuple[str, str], Path] = {}


def _run_dir_for(session_id: str, url: str) -> Path | None:
    root = _root()
    if root is None:
        return None
    key = (session_id, url)
    if key in _RUN_DIRS and _RUN_DIRS[key].exists():
        return _RUN_DIRS[key]
    now = datetime.now()
    day = root / now.strftime("%Y-%m-%d")
    day.mkdir(parents=True, exist_ok=True)
    folder = day / f"{_safe_host(url)}_{now.strftime('%H%M%S')}"
    folder.mkdir(parents=True, exist_ok=True)
    _RUN_DIRS[key] = folder
    return folder


# ---------------- PII redaction (cheap, conservative) ----------------

_RE_EMAIL = re.compile(r"[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}")
_RE_IL_PHONE = re.compile(r"\b0\d{1,2}[\s\-]?\d{3}[\s\-]?\d{4}\b")
_RE_IL_ID = re.compile(r"\b\d{9}\b")


def _redact(text: str) -> str:
    text = _RE_EMAIL.sub("[REDACTED_EMAIL]", text)
    text = _RE_IL_PHONE.sub("[REDACTED_PHONE]", text)
    text = _RE_IL_ID.sub("[REDACTED_ID]", text)
    return text


# ---------------- capture API ----------------

async def capture(mgr, session_id: str, audit: str, output: dict[str, Any],
                  redact: bool = False) -> None:
    """Save the inputs (HTML, screenshot, meta) + an audit's output.

    Best-effort, never raises. Skips silently if env not set or session is
    closed. Called from inside each qa_* tool right before it returns.
    """
    if not is_enabled():
        return
    try:
        s = mgr.get(session_id)
    except Exception:
        return
    page = getattr(s, "page", None)
    if page is None:
        return

    try:
        url = page.url
    except Exception:
        return

    folder = _run_dir_for(session_id, url)
    if folder is None:
        return

    # Always save the audit output (small)
    try:
        (folder / f"{audit}.json").write_text(
            json.dumps(output, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    except Exception:
        pass

    # Save inputs only once per run folder (page.html + screenshot + meta)
    page_html_path = folder / "page.html"
    if not page_html_path.exists():
        try:
            html = await page.content()
            if redact:
                html = _redact(html)
            page_html_path.write_text(html, encoding="utf-8")
        except Exception:
            pass

    meta_path = folder / "meta.json"
    if not meta_path.exists():
        try:
            viewport = page.viewport_size or {}
            try:
                title = await page.title()
            except Exception:
                title = ""
            try:
                lang = await page.evaluate("document.documentElement.lang || ''")
            except Exception:
                lang = ""
            try:
                dir_attr = await page.evaluate("document.documentElement.dir || ''")
            except Exception:
                dir_attr = ""
            html_text = page_html_path.read_text(encoding="utf-8") if page_html_path.exists() else ""
            meta = {
                "url": url,
                "title": title,
                "lang": lang,
                "dir": dir_attr,
                "viewport": viewport,
                "captured_at": datetime.now().isoformat(timespec="seconds"),
                "mcp_version": _VERSION,
                "redacted": bool(redact),
                "html_sha256": hashlib.sha256(html_text.encode("utf-8")).hexdigest()
                                if html_text else None,
                "html_bytes": len(html_text.encode("utf-8")) if html_text else 0,
            }
            meta_path.write_text(
                json.dumps(meta, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
        except Exception:
            pass

    screenshot_path = folder / "screenshot.jpg"
    if not screenshot_path.exists():
        try:
            await page.screenshot(
                path=str(screenshot_path),
                full_page=True,
                type="jpeg",
                quality=70,
            )
        except Exception:
            pass


# ---------------- export to JSONL ----------------

_AUDIT_FILES = ("rtl.json", "perf.json", "seo.json", "links.json", "a11y.json")


def _iter_runs(data_dir: Path):
    """Yield run folders that have at least one audit output."""
    if not data_dir.exists():
        return
    for day in sorted(data_dir.iterdir()):
        if not day.is_dir():
            continue
        for run in sorted(day.iterdir()):
            if not run.is_dir():
                continue
            if any((run / f).exists() for f in _AUDIT_FILES):
                yield run


def _hash_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _read_meta(run: Path) -> dict[str, Any]:
    meta_path = run / "meta.json"
    if not meta_path.exists():
        return {}
    try:
        return json.loads(meta_path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def export_jsonl(data_dir: str, output_path: str,
                 task: str | None = None,
                 output_format: str = "messages",
                 max_html_chars: int | None = None,
                 dedupe: bool = True) -> dict[str, Any]:
    """Export captured runs as a JSONL ready for fine-tuning.

    Parameters:
      data_dir: folder created by QA_MCP_TRAINING_DATA_DIR
      output_path: target .jsonl file
      task: 'rtl' | 'perf' | 'seo' | 'links' | 'a11y' | None.
            None = emit one example per (run, audit) for ALL audits present.
      output_format: 'messages' (ChatML, default) | 'prompt_completion'
      max_html_chars: trim HTML if it exceeds this length (helps small models).
                      None = no trimming.
      dedupe: skip identical (html_sha256, audit, output_sha256) triples.
              Default True. Two scans of the same site with the same HTML and
              the same audit result count as one example. If the page changed
              between scans (different HTML), both are kept — those are
              valuable signal of fixes.

    Returns: { examples_written, skipped_duplicates, skipped_other,
               output_path, format, task_filter, unique_html_pages }.
    """
    src = Path(data_dir).expanduser()
    out = Path(output_path).expanduser()
    out.parent.mkdir(parents=True, exist_ok=True)

    selected_audits = (f"{task}.json",) if task else _AUDIT_FILES
    written = 0
    skipped_duplicates = 0
    skipped_other = 0
    seen_keys: set[tuple[str, str, str]] = set()
    unique_html: set[str] = set()

    with out.open("w", encoding="utf-8") as fh:
        for run in _iter_runs(src):
            html_path = run / "page.html"
            if not html_path.exists():
                skipped_other += 1
                continue
            html_full = html_path.read_text(encoding="utf-8")
            html_hash = _hash_text(html_full)
            unique_html.add(html_hash)

            html = html_full
            if max_html_chars and len(html) > max_html_chars:
                html = html[:max_html_chars]
            meta = _read_meta(run)

            for audit_file in selected_audits:
                p = run / audit_file
                if not p.exists():
                    continue
                try:
                    output = json.loads(p.read_text(encoding="utf-8"))
                except Exception:
                    skipped_other += 1
                    continue

                audit_name = audit_file.removesuffix(".json")
                output_serialized = json.dumps(output, ensure_ascii=False, sort_keys=True)

                if dedupe:
                    key = (html_hash, audit_name, _hash_text(output_serialized))
                    if key in seen_keys:
                        skipped_duplicates += 1
                        continue
                    seen_keys.add(key)

                instruction = (
                    f"Audit the HTML below for {audit_name} issues. "
                    f"Return JSON with the same shape as qa-mcp's qa_{audit_name} tool."
                )
                user_msg = f"URL: {meta.get('url','')}\nlang: {meta.get('lang','')}\n\n```html\n{html}\n```"
                assistant_msg = json.dumps(output, ensure_ascii=False)

                if output_format == "prompt_completion":
                    record = {
                        "prompt": instruction + "\n\n" + user_msg,
                        "completion": assistant_msg,
                        "task": audit_name,
                        "url": meta.get("url"),
                    }
                else:  # messages (ChatML)
                    record = {
                        "messages": [
                            {"role": "system", "content": instruction},
                            {"role": "user", "content": user_msg},
                            {"role": "assistant", "content": assistant_msg},
                        ],
                        "task": audit_name,
                        "url": meta.get("url"),
                    }
                fh.write(json.dumps(record, ensure_ascii=False) + "\n")
                written += 1

    return {
        "examples_written": written,
        "skipped_duplicates": skipped_duplicates,
        "skipped_other": skipped_other,
        "unique_html_pages": len(unique_html),
        "output_path": str(out),
        "format": output_format,
        "task_filter": task,
        "dedupe": dedupe,
    }


def find_diffs(data_dir: str) -> dict[str, Any]:
    """Find URLs that were scanned multiple times AND whose HTML changed
    between scans. These are gold-standard signal: if a finding existed in
    scan 1 and disappeared in scan 2, that's a captured fix.

    Returns: { urls_with_changes: [{url, scans: [{run_dir, html_sha256,
              captured_at, findings_total}], delta: {rtl, perf, seo, links,
              a11y}}], total_urls_scanned_twice, total_with_changes }.
    """
    src = Path(data_dir).expanduser()
    by_url: dict[str, list[dict]] = {}

    for run in _iter_runs(src):
        meta = _read_meta(run)
        url = meta.get("url")
        if not url:
            continue
        entry = {
            "run_dir": str(run.relative_to(src)),
            "html_sha256": meta.get("html_sha256"),
            "captured_at": meta.get("captured_at"),
            "findings": {},
        }
        for audit_file in _AUDIT_FILES:
            p = run / audit_file
            if p.exists():
                try:
                    data = json.loads(p.read_text(encoding="utf-8"))
                    s = data.get("summary") if isinstance(data, dict) else None
                    if isinstance(s, dict) and isinstance(s.get("total"), int):
                        entry["findings"][audit_file.removesuffix(".json")] = s["total"]
                except Exception:
                    pass
        by_url.setdefault(url, []).append(entry)

    multi_scan = {u: scans for u, scans in by_url.items() if len(scans) > 1}
    with_changes = []
    for url, scans in multi_scan.items():
        scans_sorted = sorted(scans, key=lambda x: x.get("captured_at") or "")
        hashes = {s["html_sha256"] for s in scans_sorted if s.get("html_sha256")}
        if len(hashes) < 2:
            continue  # multiple scans but page didn't change
        first, last = scans_sorted[0], scans_sorted[-1]
        delta = {}
        for audit in ("rtl", "perf", "seo", "links", "a11y"):
            f0 = first["findings"].get(audit)
            f1 = last["findings"].get(audit)
            if f0 is not None and f1 is not None and f0 != f1:
                delta[audit] = {"before": f0, "after": f1, "change": f1 - f0}
        with_changes.append({
            "url": url,
            "scans": scans_sorted,
            "delta": delta,
        })

    return {
        "data_dir": str(src),
        "total_urls_scanned_twice": len(multi_scan),
        "total_with_changes": len(with_changes),
        "urls_with_changes": with_changes,
    }


def stats(data_dir: str) -> dict[str, Any]:
    """Summarize the captured corpus.

    Counts both raw runs and unique HTML pages — the gap between them tells
    you how much your corpus is repeated scans of the same content (which
    will be skipped during dedupe export). `ready_for_training` is gated on
    UNIQUE pages, not raw runs."""
    src = Path(data_dir).expanduser()
    runs = list(_iter_runs(src))
    by_task: dict[str, int] = {a.removesuffix(".json"): 0 for a in _AUDIT_FILES}
    by_lang: dict[str, int] = {}
    by_host: dict[str, int] = {}
    by_url: dict[str, int] = {}
    html_hashes: set[str] = set()
    html_sizes: list[int] = []
    findings_total = 0

    for run in runs:
        for audit_file in _AUDIT_FILES:
            p = run / audit_file
            if p.exists():
                by_task[audit_file.removesuffix(".json")] += 1
                try:
                    data = json.loads(p.read_text(encoding="utf-8"))
                    if isinstance(data, dict):
                        s = data.get("summary") or {}
                        if isinstance(s, dict):
                            t = s.get("total")
                            if isinstance(t, int):
                                findings_total += t
                except Exception:
                    pass
        meta_path = run / "meta.json"
        if meta_path.exists():
            try:
                meta = json.loads(meta_path.read_text(encoding="utf-8"))
                lang = meta.get("lang") or "unknown"
                by_lang[lang] = by_lang.get(lang, 0) + 1
                if meta.get("html_bytes"):
                    html_sizes.append(int(meta["html_bytes"]))
                if meta.get("html_sha256"):
                    html_hashes.add(meta["html_sha256"])
                host = _safe_host(meta.get("url") or "")
                by_host[host] = by_host.get(host, 0) + 1
                url = meta.get("url") or ""
                by_url[url] = by_url.get(url, 0) + 1
            except Exception:
                pass

    avg_html = int(sum(html_sizes) / len(html_sizes)) if html_sizes else 0
    rescans = sum(1 for c in by_url.values() if c > 1)
    unique_pages = len(html_hashes)
    return {
        "data_dir": str(src),
        "runs": len(runs),
        "unique_hosts": len(by_host),
        "unique_urls": len(by_url),
        "unique_html_pages": unique_pages,
        "rescans_count": rescans,
        "duplicate_runs": len(runs) - unique_pages if unique_pages else 0,
        "by_task": by_task,
        "by_lang": by_lang,
        "avg_html_bytes": avg_html,
        "total_html_mb": round(sum(html_sizes) / (1024 * 1024), 2) if html_sizes else 0,
        "total_findings": findings_total,
        "ready_for_training": unique_pages >= 100,
    }
