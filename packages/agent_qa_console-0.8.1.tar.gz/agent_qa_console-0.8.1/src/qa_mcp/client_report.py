"""Client-facing ZIP report generator for qa-mcp.

Turns a qa-mcp suite JSON into a polished, self-contained Hebrew HTML report
plus technical appendices and Markdown issue files. Designed for agent-first
use: the user asks for a client report, the agent calls one tool.
"""
from __future__ import annotations

import base64
import html
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from typing import Any

from . import suite as _suite


def _data_uri(path: str | None) -> str:
    if not path:
        return ""
    p = Path(path)
    if not p.exists():
        return ""
    mime = "image/jpeg" if p.suffix.lower() in {".jpg", ".jpeg"} else "image/png"
    return f"data:{mime};base64," + base64.b64encode(p.read_bytes()).decode("ascii")


def _sev_he(sev: str) -> str:
    return {"critical": "קריטי", "high": "חשוב", "medium": "בינוני", "low": "נמוך", "info": "מידע"}.get(sev, sev)


def _top_findings(suite: dict[str, Any], limit: int = 12) -> list[tuple[dict, dict]]:
    rank = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
    rows: list[tuple[dict, dict]] = []
    for sc in suite.get("scenarios", []) or []:
        for f in sc.get("findings", []) or []:
            rows.append((sc, f))
    rows.sort(key=lambda x: rank.get(x[1].get("severity", "info"), 9))
    return rows[:limit]


def _html_report(suite: dict[str, Any], client: str, consultant: str = "BrainboxAI") -> str:
    summary = suite.get("summary", {}) or {}
    scenarios = suite.get("scenarios", []) or []
    shots = [(sc.get("name", ""), _data_uri(sc.get("screenshot_path"))) for sc in scenarios if sc.get("screenshot_path")]
    shots = [(n, u) for n, u in shots if u][:3]

    scenario_rows = "".join(
        f"<tr><td>{html.escape(sc.get('name',''))}</td><td><span class='url'>{html.escape(sc.get('url',''))}</span></td>"
        f"<td class='{ 'good' if sc.get('passed') else 'bad' }'>{'עבר' if sc.get('passed') else 'דורש טיפול'}</td>"
        f"<td>{len(sc.get('findings', []) or [])}</td><td>{html.escape(', '.join(sc.get('violations', []) or []) or '—')}</td></tr>"
        for sc in scenarios
    )

    finding_cards = []
    for i, (sc, f) in enumerate(_top_findings(suite), 1):
        sev = f.get("severity", "info")
        evidence = html.escape(str(f.get("evidence") or "")[:700])
        selector = html.escape(str(f.get("selector") or ""))
        finding_cards.append(f"""
        <article class="finding">
          <div class="finding-head"><h3>{i}. {html.escape(str(f.get('title') or 'QA finding'))}</h3><span class="badge {html.escape(sev)}">{_sev_he(sev)}</span></div>
          <p class="muted">תרחיש: <code>{html.escape(sc.get('name',''))}</code> · מקור: <code>{html.escape(str(f.get('source','')))}</code> · קטגוריה: <code>{html.escape(str(f.get('category','')))}</code></p>
          {f'<pre>{evidence}</pre>' if evidence else ''}
          {f'<p><strong>Selector:</strong> <code>{selector}</code></p>' if selector else ''}
          <div class="impact"><strong>השפעה:</strong> {html.escape(str(f.get('impact') or ''))}</div>
          <div class="fix"><h4>תיקון מומלץ</h4><p>{html.escape(str(f.get('fix') or ''))}</p></div>
        </article>
        """)

    shot_html = "".join(
        f"<div class='shot'><img src='{uri}' alt='{html.escape(name)}'><div class='caption'>{html.escape(name)}</div></div>"
        for name, uri in shots
    )

    css = """
    *{box-sizing:border-box;margin:0;padding:0}:root{--bg:#0b0d12;--panel:#11141b;--panel2:#161a23;--border:#232936;--text:#e6e8ec;--muted:#9aa3b2;--accent:#6ee7b7;--good:#22c55e;--high:#f97316;--medium:#eab308;--critical:#ef4444;--info:#38bdf8}body{background:var(--bg);color:var(--text);font-family:Heebo,Arial,sans-serif;line-height:1.75}.wrap{max-width:1040px;margin:0 auto;padding:48px 24px 96px}.hero{background:linear-gradient(135deg,#0f1422,#1a1f2e 52%,#131826);border:1px solid var(--border);border-radius:22px;padding:46px 40px;margin-bottom:30px}.brand{font-size:13px;letter-spacing:4px;color:var(--accent);text-transform:uppercase;font-weight:800;margin-bottom:14px}h1{font-size:38px;font-weight:900}.for{font-size:20px;margin:8px 0 22px}.for strong{color:#fbbf24}.meta{display:flex;gap:24px;flex-wrap:wrap;padding-top:18px;border-top:1px solid var(--border);font-size:14px;color:var(--muted)}.summary{background:var(--panel);border:1px solid var(--border);border-right:4px solid #10b981;border-radius:16px;padding:28px 32px;margin-bottom:30px}.summary h2{color:var(--accent);font-size:22px;margin-bottom:12px}.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin:26px 0}.score{background:var(--panel);border:1px solid var(--border);border-radius:14px;padding:18px;text-align:center}.score .num{font-size:30px;font-weight:900}.score .label{font-size:13px;color:var(--muted)}.good{color:var(--good);font-weight:800}.bad{color:var(--high);font-weight:800}.section{font-size:27px;margin:46px 0 18px;padding-bottom:10px;border-bottom:1px solid var(--border)}table{width:100%;border-collapse:collapse;background:var(--panel);border:1px solid var(--border);border-radius:12px;overflow:hidden;margin:18px 0 34px}th,td{padding:13px 16px;text-align:right;border-bottom:1px solid var(--border);font-size:14px}th{background:var(--panel2);color:var(--muted);font-size:12px}.url,code{font-family:Consolas,monospace;direction:ltr;display:inline-block;color:var(--accent)}.finding{background:var(--panel);border:1px solid var(--border);border-radius:15px;padding:28px 32px;margin-bottom:24px}.finding-head{display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap}.finding h3{font-size:22px}.badge{font-size:11px;padding:5px 12px;border-radius:999px;font-weight:900}.badge.high{background:rgba(249,115,22,.17);color:var(--high)}.badge.medium{background:rgba(234,179,8,.17);color:var(--medium)}.badge.low{background:rgba(56,189,248,.14);color:var(--info)}.badge.critical{background:rgba(239,68,68,.17);color:var(--critical)}.muted{color:var(--muted);font-size:14px}.impact{background:var(--panel2);border-right:3px solid var(--info);padding:12px 18px;border-radius:8px;margin:16px 0;color:var(--muted)}.fix{background:rgba(34,197,94,.055);border:1px solid rgba(34,197,94,.22);padding:16px 20px;border-radius:10px}.fix h4{color:var(--good)}pre{background:#050608;color:var(--accent);padding:14px 18px;border-radius:8px;direction:ltr;text-align:left;white-space:pre-wrap;overflow-x:auto;margin:12px 0}.shot{margin:18px 0;border-radius:12px;overflow:hidden;border:1px solid var(--border)}.shot img{width:100%;display:block}.caption{background:var(--panel2);color:var(--muted);font-size:13px;padding:10px 15px}.cta{background:linear-gradient(135deg,#1a1f2e,#0f1422);border:1px solid #10b981;border-radius:16px;padding:34px;margin-top:44px;text-align:center}footer{text-align:center;margin-top:54px;padding-top:25px;border-top:1px solid var(--border);color:var(--muted);font-size:13px}@media(max-width:760px){.wrap{padding:24px 14px}.hero{padding:32px 22px}h1{font-size:30px}.grid{grid-template-columns:1fr 1fr}th,td{font-size:12px;padding:10px}.finding{padding:22px 20px}}
    """

    return f"""<!doctype html><html lang="he" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>דוח בדיקת איכות · {html.escape(client)}</title><style>{css}</style></head><body><div class="wrap">
    <header class="hero"><div class="brand">{html.escape(consultant)} · QA Audit · Client Report</div><h1>דוח בדיקת איכות אתר</h1><div class="for">עבור: <strong>{html.escape(client)}</strong></div><div class="meta"><span><strong>שם suite:</strong> {html.escape(str(suite.get('name','qa-mcp')))}</span><span><strong>תרחישים:</strong> {summary.get('total',0)}</span><span><strong>ממצאים:</strong> {summary.get('findings_total',0)}</span><span><strong>דפדפן:</strong> {html.escape(str(suite.get('browser','')))}</span></div></header>
    <section class="summary"><h2>תקציר מנהלים</h2><p>בוצעה בדיקת QA לאתר הכוללת ביצועים, SEO, לינקים/כפתורים, RTL/עברית, לוגים ותצלומי מסך. הדוח מרכז את הממצאים החשובים ומתרגם אותם למשימות תיקון ברורות.</p><p>נמצאו <strong>{summary.get('findings_total',0)}</strong> ממצאים, מתוכם <strong>{(summary.get('findings_by_severity') or {}).get('high',0)}</strong> ברמת חשיבות גבוהה.</p></section>
    <div class="grid"><div class="score"><div class="num">{summary.get('total',0)}</div><div class="label">תרחישים</div></div><div class="score"><div class="num">{summary.get('passed',0)}</div><div class="label">עברו</div></div><div class="score"><div class="num">{summary.get('failed',0)}</div><div class="label">דורשים טיפול</div></div><div class="score"><div class="num">{summary.get('findings_total',0)}</div><div class="label">ממצאים</div></div></div>
    <h2 class="section">סיכום לפי תרחיש</h2><table><thead><tr><th>תרחיש</th><th>URL</th><th>סטטוס</th><th>ממצאים</th><th>חריגות סף</th></tr></thead><tbody>{scenario_rows}</tbody></table>
    {shot_html}
    <h2 class="section">ממצאים מרכזיים</h2>{''.join(finding_cards) or '<p>לא נמצאו ממצאים מרכזיים.</p>'}
    <div class="cta"><h2>שורה תחתונה</h2><p>הדוח נועד לתת למפתח/לקוח רשימת תיקונים ממוקדת: מה הבעיה, למה היא חשובה, ואיך מתקנים אותה.</p></div><footer>הופק על ידי <strong>{html.escape(consultant)}</strong> באמצעות qa-mcp</footer>
    </div></body></html>"""


def create_client_report_zip(
    result_json: str,
    out_zip: str,
    client: str | None = None,
    consultant: str = "BrainboxAI",
) -> dict[str, Any]:
    suite = json.loads(Path(result_json).read_text(encoding="utf-8"))
    client_name = client or suite.get("name") or "QA Client"
    out = Path(out_zip)
    out.parent.mkdir(parents=True, exist_ok=True)

    html_text = _html_report(suite, client_name, consultant)
    md_text = []
    md_text.append(f"# דוח QA — {client_name}\n")
    md_text.append(f"ממצאים: {suite.get('summary', {}).get('findings_total', 0)}\n")
    for i, (sc, f) in enumerate(_top_findings(suite, 50), 1):
        md_text.append(f"## {i}. [{str(f.get('severity','info')).upper()}] {f.get('title','')}\n")
        md_text.append(f"- תרחיש: `{sc.get('name','')}`\n- URL: {sc.get('url','')}\n- מקור: `{f.get('source','')}`\n- ראיה: `{str(f.get('evidence') or '')[:500]}`\n- תיקון: {f.get('fix','')}\n")

    # Generate issue files into memory via a temp directory next to zip.
    tmp_issues = out.parent / (out.stem + "-issues-tmp")
    issues = _suite.emit_issue_files(suite, str(tmp_issues))

    with ZipFile(out, "w", ZIP_DEFLATED) as z:
        z.writestr("דוח-בדיקת-איכות.html", html_text)
        z.writestr("נספחים/client-summary-he.md", "\n".join(md_text))
        z.writestr("נספחים/qa-result.json", json.dumps(suite, indent=2, ensure_ascii=False))
        for p in sorted(tmp_issues.glob("*.md")):
            z.write(p, "נספחים/issues/" + p.name)
    # Cleanup temp issue files best-effort.
    try:
        for p in tmp_issues.glob("*.md"):
            p.unlink()
        tmp_issues.rmdir()
    except Exception:
        pass

    return {"zip_path": str(out), "size_bytes": out.stat().st_size, "client": client_name, "issues": issues.get("count", 0)}
