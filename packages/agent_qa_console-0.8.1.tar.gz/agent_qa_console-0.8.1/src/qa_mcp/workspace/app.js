const state = {
  events: [],
  findings: [],
  screenshots: [],
  approvals: [],
  intent: null,
  phase: null,
  fixLoop: null,
  browser: {
    url: null,
    title: null,
    viewport: null,
    mode: 'waiting',
  },
  cursor: null,
  selectableElements: null,
  selectedElement: null,
};

const els = {
  connection: document.getElementById('connectionState'),
  sessionMeta: document.getElementById('sessionMeta'),
  timeline: document.getElementById('timeline'),
  findings: document.getElementById('findings'),
  findingCount: document.getElementById('findingCount'),
  approvals: document.getElementById('approvals'),
  browserStage: document.getElementById('browserStage'),
  browserUrl: document.getElementById('browserUrl'),
  browserMode: document.getElementById('browserMode'),
  openImage: document.getElementById('openImage'),
  openLiveBrowser: document.getElementById('openLiveBrowser'),
  clearLocal: document.getElementById('clearLocal'),
  eventCount: document.getElementById('eventCount'),
  shotCount: document.getElementById('shotCount'),
  approvalCount: document.getElementById('approvalCount'),
  intentBox: document.getElementById('intentBox'),
  phaseBox: document.getElementById('phaseBox'),
  fixLoop: document.getElementById('fixLoop'),
  urlForm: document.getElementById('urlForm'),
  urlInput: document.getElementById('urlInput'),
  instructionForm: document.getElementById('instructionForm'),
  instructionInput: document.getElementById('instructionInput'),
  cmdBack: document.getElementById('cmdBack'),
  cmdForward: document.getElementById('cmdForward'),
  cmdReload: document.getElementById('cmdReload'),
  cmdScreenshot: document.getElementById('cmdScreenshot'),
  cmdStop: document.getElementById('cmdStop'),
  logsToggle: document.getElementById('logsToggle'),
  logsDrawer: document.getElementById('logsDrawer'),
  logsClose: document.getElementById('logsClose'),
  logsList: document.getElementById('logsList'),
  miniStatus: document.getElementById('miniStatus'),
  toastStack: document.getElementById('toastStack'),
  selectedActionBar: document.getElementById('selectedActionBar'),
  selectedActionLabel: document.getElementById('selectedActionLabel'),
  selectedActionSource: document.getElementById('selectedActionSource'),
};

function fmtTime(ts) {
  if (!ts) return '';
  return new Date(ts * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
}

function escapeHtml(value) {
  return String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function compactData(data) {
  if (!data || Object.keys(data).length === 0) return '';
  const copy = { ...data };
  delete copy.base64;
  const text = JSON.stringify(copy, null, 2);
  return text.length > 700 ? `${text.slice(0, 700)}…` : text;
}

function fileUrl(path) {
  return `/api/file?path=${encodeURIComponent(path)}`;
}

function renderMeta(snapshot) {
  const created = snapshot.created_at ? new Date(snapshot.created_at * 1000).toLocaleString() : 'unknown';
  if (els.sessionMeta) els.sessionMeta.textContent = `${snapshot.title || 'QA session'} · started ${created}`;
}

const TIMELINE_HIDDEN_KINDS = new Set(['finding']);
const EVENT_DATA_PRIMARY_KEYS = ['url', 'status', 'browser', 'session_id', 'submit', 'field_count', 'blocked'];

function eventSummary(data) {
  if (!data || typeof data !== 'object') return '';
  const parts = [];
  for (const key of EVENT_DATA_PRIMARY_KEYS) {
    if (data[key] === undefined || data[key] === null) continue;
    let value = data[key];
    if (typeof value === 'string' && value.length > 60) value = `${value.slice(0, 60)}…`;
    parts.push(`${key}=${value}`);
    if (parts.length >= 2) break;
  }
  return parts.join(' · ');
}

function logClass(ev) {
  const kind = String(ev?.kind || '');
  const level = String(ev?.level || 'info');
  if (level === 'error') return 'error';
  if (level === 'warning') return 'warning';
  if (kind.startsWith('user_') || kind === 'command') return 'user';
  if (kind.startsWith('browser_')) return 'browser';
  return 'info';
}

function humanLogKind(kind) {
  return String(kind || 'log').replace(/^browser_/, 'browser:').replace(/^qa_/, 'qa:').replace(/^user_/, 'user:').replaceAll('_', ' ');
}

function logDirection(ev) {
  const kind = String(ev?.kind || '');
  if (kind === 'user_command' || kind.startsWith('approval_')) return 'USER';
  if (kind.startsWith('browser_')) return 'BROWSER';
  if (kind.startsWith('qa_')) return 'QA';
  if (kind === 'session' || kind === 'project_context') return 'SYSTEM';
  return 'AGENT';
}

function renderLogs() {
  if (!els.logsList) return;
  const visible = state.events.filter((ev) => !TIMELINE_HIDDEN_KINDS.has(ev.kind));
  els.logsList.innerHTML = visible.slice().reverse().map((ev) => {
    const data = compactData(ev.data);
    const summary = eventSummary(ev.data);
    const level = String(ev.level || 'info').toUpperCase();
    const kind = humanLogKind(ev.kind);
    const message = ev.message || ev.kind || 'Event';
    return `
      <div class="log-line ${escapeHtml(logClass(ev))}">
        <span class="log-ts">${escapeHtml(fmtTime(ev.ts))}</span>
        <span class="log-level">${escapeHtml(level)}</span>
        <span class="log-source">${escapeHtml(logDirection(ev))}</span>
        <span class="log-event">${escapeHtml(kind)}</span>
        <span class="log-msg">${escapeHtml(message)}</span>
        ${summary ? `<span class="log-meta">${escapeHtml(summary)}</span>` : ''}
        ${data ? `<details class="log-json"><summary>json</summary><pre>${escapeHtml(data)}</pre></details>` : ''}
      </div>`;
  }).join('') || '<div class="logs-empty">No logs yet.</div>';
}

function renderTimeline() {
  const visible = state.events.filter((ev) => !TIMELINE_HIDDEN_KINDS.has(ev.kind));
  els.timeline.innerHTML = visible.slice().reverse().map((ev) => {
    const data = compactData(ev.data);
    const risk = ev.data && ev.data.risk ? String(ev.data.risk) : '';
    const riskBadge = risk ? `<span class="risk-badge ${escapeHtml(risk)}">${escapeHtml(risk)}</span>` : '';
    const summary = eventSummary(ev.data);
    const summaryLine = summary ? `<div class="event-summary">${escapeHtml(summary)}</div>` : '';
    const dataBlock = data
      ? `<details class="event-details"><summary>payload</summary><pre class="event-data">${escapeHtml(data)}</pre></details>`
      : '';
    return `
      <li class="timeline-item ${risk ? `risk-${escapeHtml(risk)}` : ''}">
        <div class="time">${escapeHtml(fmtTime(ev.ts))}</div>
        <div class="event-main">
          <div class="event-kind">${escapeHtml(ev.kind)} · ${escapeHtml(ev.level || 'info')} ${riskBadge}</div>
          <div class="event-message">${escapeHtml(ev.message)}</div>
          ${summaryLine}
          ${dataBlock}
        </div>
      </li>`;
  }).join('') || '<li class="empty-state">No actions yet.</li>';
}

function latestBrowserUrl() {
  if (state.browser.url) return state.browser.url;
  const shot = state.screenshots[state.screenshots.length - 1];
  if (shot?.url) return shot.url;
  for (let i = state.events.length - 1; i >= 0; i -= 1) {
    const data = state.events[i]?.data || {};
    if (typeof data.url === 'string' && data.url.startsWith('http') && !isWorkspaceUrl(data.url)) return data.url;
  }
  return null;
}

function isWorkspaceUrl(url) {
  return typeof url === 'string' && url.startsWith(window.location.origin);
}

function eventBrowserPatch(ev) {
  const data = ev?.data || {};
  const patch = {};
  if (typeof data.url === 'string' && data.url.startsWith('http') && !isWorkspaceUrl(data.url)) patch.url = data.url;
  if (typeof data.title === 'string') patch.title = data.title;
  if (data.viewport && typeof data.viewport === 'object') patch.viewport = data.viewport;
  if (data.device) patch.viewport = { ...(patch.viewport || {}), device: data.device };
  if (Object.keys(patch).length === 0) return;
  state.browser = { ...state.browser, ...patch, mode: 'live' };
}

let frameRefreshTimer = null;
let frameRefreshBusy = false;

function startFrameRefresh() {
  if (frameRefreshTimer) window.clearInterval(frameRefreshTimer);
  frameRefreshTimer = window.setInterval(() => {
    const img = document.getElementById('browserStream');
    if (!img || frameRefreshBusy) return;
    frameRefreshBusy = true;
    const next = new Image();
    next.onload = () => {
      img.src = next.src;
      frameRefreshBusy = false;
    };
    next.onerror = () => { frameRefreshBusy = false; };
    next.src = `/api/browser-frame.jpg?t=${Date.now()}`;
  }, 350);
}

function hasLiveBrowserTarget() {
  return Boolean(state.browser && state.browser.session_id && state.browser.url && !isWorkspaceUrl(state.browser.url));
}

function sendBrowserInput(kind, payload = {}) {
  if (!hasLiveBrowserTarget()) return Promise.resolve(null);
  return fetch('/api/browser-input', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ kind, payload }),
  }).catch(() => null);
}

function cursorPosition(cursor) {
  return {
    x: Math.max(0, Math.min(100, Number(cursor?.x || 0) * 100)),
    y: Math.max(0, Math.min(100, Number(cursor?.y || 0) * 100)),
  };
}

function elementLabel(el) {
  return String(el?.text || el?.placeholder || el?.id || el?.name || el?.role || el?.tag || `#${el?.index ?? ''}`).trim();
}

function shortSource(value) {
  const text = String(value || '').replaceAll('\\', '/');
  if (!text) return '';
  const parts = text.split('/').filter(Boolean);
  return parts.slice(-2).join('/');
}

function elementTechLabel(el) {
  const tag = String(el?.tag || 'element');
  const cls = String(el?.className || '').trim().split(/\s+/).filter(Boolean)[0];
  const ident = el?.id ? `#${el.id}` : (cls ? `.${cls}` : '');
  const data = el?.dataAttrs || {};
  const source = shortSource(el?.sourceHint || data['data-source'] || data['data-file'] || data['data-component']);
  return `${tag}${ident}${source ? ` · ${source}` : ''}`;
}

function updateSelectedActionBar() {
  if (!els.selectedActionBar) return;
  const el = state.selectedElement;
  const visible = Boolean(el);
  els.selectedActionBar.classList.toggle('visible', visible);
  els.selectedActionBar.setAttribute('aria-hidden', visible ? 'false' : 'true');
  if (!visible) return;
  if (els.selectedActionLabel) els.selectedActionLabel.textContent = elementLabel(el) || 'Selected element';
  if (els.selectedActionSource) els.selectedActionSource.textContent = elementTechLabel(el);
}

function updateMiniStatus(text) {
  if (!els.miniStatus) return;
  const selected = state.selectedElement ? `Selected: ${elementTechLabel(state.selectedElement)}` : null;
  const fallback = state.browser?.url ? 'Project linked · watching browser' : 'Waiting for browser';
  els.miniStatus.textContent = text || selected || fallback;
  updateSelectedActionBar();
}

function showToast(title, detail = '') {
  if (!els.toastStack) return;
  const node = document.createElement('div');
  node.className = 'toast-item';
  node.innerHTML = `<strong>${escapeHtml(title)}</strong>${detail ? `<span>${escapeHtml(detail)}</span>` : ''}`;
  els.toastStack.appendChild(node);
  window.setTimeout(() => node.classList.add('leaving'), 2600);
  window.setTimeout(() => node.remove(), 3100);
}

function renderSelectableElementsHtml() {
  const payload = state.selectableElements;
  const elements = payload?.elements || [];
  const viewport = payload?.viewport || {};
  const vw = Number(viewport.width || viewport.w || 0);
  const vh = Number(viewport.height || viewport.h || 0);
  if (!elements.length || !vw || !vh) return '';
  const boxes = elements.map((el) => {
    const x = Math.max(0, Math.min(100, (Number(el.x || 0) / vw) * 100));
    const y = Math.max(0, Math.min(100, (Number(el.y || 0) / vh) * 100));
    const w = Math.max(0.4, Math.min(100 - x, (Number(el.w || 0) / vw) * 100));
    const h = Math.max(0.4, Math.min(100 - y, (Number(el.h || 0) / vh) * 100));
    const label = escapeHtml(elementLabel(el));
    const tech = escapeHtml(elementTechLabel(el));
    const selectId = String(el.select_id ?? el.index ?? '');
    const selected = state.selectedElement && String(state.selectedElement.select_id ?? state.selectedElement.index) === selectId ? ' selected' : '';
    return `<button class="selectable-element${selected}" type="button" data-select-id="${escapeHtml(selectId)}" style="left:${x}%;top:${y}%;width:${w}%;height:${h}%;" title="${label}" aria-label="Select ${label}"><span>${label}</span><em>${tech}</em></button>`;
  }).join('');
  return `<div class="selection-layer" aria-label="Selectable page elements">${boxes}</div>`;
}

function fitBrowserViewport() {
  const stage = els.browserStage;
  const shell = document.getElementById('browserViewport');
  if (!stage || !shell) return;
  const viewport = state.browser?.viewport || state.selectableElements?.viewport || {};
  const vw = Number(viewport.width || viewport.w || 1366);
  const vh = Number(viewport.height || viewport.h || 900);
  if (!vw || !vh) return;
  const stageRect = stage.getBoundingClientRect();
  const availableW = Math.max(1, stageRect.width - 20);
  const availableH = Math.max(1, stageRect.height - 20);
  const aspect = vw / vh;
  let width = availableW;
  let height = width / aspect;
  if (height > availableH) {
    height = availableH;
    width = height * aspect;
  }
  shell.style.width = `${Math.floor(width)}px`;
  shell.style.height = `${Math.floor(height)}px`;
}

function renderCursorHtml() {
  if (!state.cursor) return '';
  const { x, y } = cursorPosition(state.cursor);
  const action = escapeHtml(state.cursor.action || 'point');
  const label = escapeHtml(state.cursor.label || `agent ${action}`);
  const pulseClass = state.cursor.pulse ? ' pulse' : '';
  return `
    <div class="agent-cursor${pulseClass}" style="left:${x}%; top:${y}%;" aria-label="${label}" title="${label}">
      <svg class="agent-cursor-icon" width="27" height="27" viewBox="0 0 27 27" fill="none" aria-hidden="true">
        <path d="M5 3.5L20.5 15.3L13.4 16.2L10.2 23.5L5 3.5Z" fill="white" stroke="#0B1220" stroke-width="1.7" stroke-linejoin="round"/>
        <path d="M13.2 16.4L17.5 23.1" stroke="#0B1220" stroke-width="2" stroke-linecap="round"/>
      </svg>
      <span class="agent-cursor-ping"></span>
      <span class="agent-cursor-label">${label}</span>
    </div>`;
}

function updateCursorOverlay() {
  const viewport = document.getElementById('browserViewport');
  if (!viewport || !state.cursor) return;
  let cursor = viewport.querySelector('.agent-cursor');
  if (!cursor) {
    viewport.insertAdjacentHTML('beforeend', renderCursorHtml());
    return;
  }
  const { x, y } = cursorPosition(state.cursor);
  const action = escapeHtml(state.cursor.action || 'point');
  const label = escapeHtml(state.cursor.label || `agent ${action}`);
  cursor.style.left = `${x}%`;
  cursor.style.top = `${y}%`;
  cursor.setAttribute('aria-label', label);
  cursor.setAttribute('title', label);
  const labelEl = cursor.querySelector('.agent-cursor-label');
  if (labelEl) labelEl.textContent = label;
  cursor.classList.remove('pulse');
  if (state.cursor.pulse) {
    void cursor.offsetWidth;
    cursor.classList.add('pulse');
  }
}

function renderBrowser() {
  const shot = state.screenshots[state.screenshots.length - 1];
  const url = latestBrowserUrl();
  const src = shot ? fileUrl(shot.path) : null;
  const viewport = state.browser.viewport;
  const viewportLabel = viewport
    ? `${viewport.device ? `${viewport.device} · ` : ''}${viewport.width || viewport.w || '?'}×${viewport.height || viewport.h || '?'}`
    : 'desktop';

  if (els.browserUrl) els.browserUrl.textContent = url || 'No browser URL yet';
  if (els.browserMode) els.browserMode.textContent = url ? `live target · ${viewportLabel}` : 'waiting';
  if (els.openLiveBrowser) els.openLiveBrowser.href = url || '#';
  if (els.openImage) els.openImage.href = src || '#';
  updateMiniStatus();

  if (!url && !src) {
    els.browserStage.innerHTML = '<div class="empty-state">The agent browser will appear here when navigation starts.</div>';
    return;
  }

  const frameSrc = `/api/browser-frame.jpg?t=${Date.now()}`;
  const fallback = src
    ? `<img class="browser-fallback-frame" src="${src}" alt="${escapeHtml(shot.label || 'Agent browser evidence frame')}">`
    : '<div class="browser-fallback-frame empty"><span>Waiting for the live browser frame…</span></div>';

  const aspectWidth = Number(viewport?.width || viewport?.w || 1366);
  const aspectHeight = Number(viewport?.height || viewport?.h || 900);
  const aspectStyle = aspectWidth > 0 && aspectHeight > 0
    ? ` style="--browser-aspect:${aspectWidth} / ${aspectHeight};"`
    : '';

  els.browserStage.innerHTML = `
    <div class="browser-viewport-shell" id="browserViewport" tabindex="0" role="application" aria-label="Interactive live agent browser"${aspectStyle}>
      ${fallback}
      <img class="browser-stream" id="browserStream" src="${frameSrc}" alt="Live agent browser" draggable="false">
      ${renderSelectableElementsHtml()}
      ${renderCursorHtml()}
    </div>`;
  window.requestAnimationFrame(fitBrowserViewport);
  startFrameRefresh();
}

function renderFindings() {
  els.findingCount.textContent = String(state.findings.length);
  els.findings.innerHTML = state.findings.slice().reverse().map((finding) => {
    const sev = finding.severity || 'medium';
    const shotLink = finding.screenshot_path
      ? `<a href="${fileUrl(finding.screenshot_path)}" target="_blank" rel="noreferrer">Open screenshot</a>`
      : '';
    return `
      <article class="finding-card">
        <span class="severity ${escapeHtml(sev)}">${escapeHtml(sev)}</span>
        <div class="finding-title">${escapeHtml(finding.title)}</div>
        ${finding.description ? `<div class="finding-description">${escapeHtml(finding.description)}</div>` : ''}
        ${finding.selector ? `<div class="finding-meta">Selector: ${escapeHtml(finding.selector)}</div>` : ''}
        ${finding.fix ? `<div class="finding-fix">Fix: ${escapeHtml(finding.fix)}</div>` : ''}
        ${shotLink ? `<div class="finding-meta">${shotLink}</div>` : ''}
      </article>`;
  }).join('') || '<div class="empty-state">No findings yet.</div>';
}

function renderApprovals() {
  els.approvals.innerHTML = state.approvals.slice().reverse().map((approval) => {
    const pending = approval.status === 'pending';
    const noteBox = pending ? `<textarea class="approval-note" data-note-for="${approval.id}" placeholder="Optional note for the agent…"></textarea>` : '';
    const actions = pending ? (approval.choices || ['approve', 'reject']).map((choice) => {
      const cls = choice === 'approve' || choice === 'yes' ? 'primary' : (choice === 'reject' || choice === 'no' ? 'danger' : '');
      return `<button class="action-button ${cls}" data-approval="${approval.id}" data-answer="${escapeHtml(choice)}">${escapeHtml(choice)}</button>`;
    }).join('') : `<div class="approval-details">Answered: ${escapeHtml(approval.answer || approval.status)}${approval.note ? ` · Note: ${escapeHtml(approval.note)}` : ''}</div>`;
    return `
      <article class="approval-card ${pending ? 'pending' : ''}">
        <div class="approval-question">${escapeHtml(approval.question)}</div>
        ${approval.details ? `<div class="approval-details">${escapeHtml(approval.details)}</div>` : ''}
        ${noteBox}
        <div class="approval-actions">${actions}</div>
      </article>`;
  }).join('') || '<div class="empty-state">No pending approvals.</div>';
}

function phaseLabel(phase) {
  return String(phase || 'planning').replace('-', ' ');
}

function renderFixLoop() {
  const loop = state.fixLoop;
  if (!loop) {
    els.fixLoop.innerHTML = '<div class="empty-state">No test-fix-verify loop yet.</div>';
    return;
  }
  const steps = loop.steps || [];
  els.fixLoop.innerHTML = `
    <div class="loop-summary">
      <strong>${escapeHtml(loop.goal || 'QA repair loop')}</strong>
      ${loop.target ? `<p>${escapeHtml(loop.target)}</p>` : ''}
      <span class="loop-status">${escapeHtml(loop.status || 'testing')}</span>
    </div>
    <ol class="loop-steps">
      ${steps.map((step) => `
        <li class="loop-step ${escapeHtml(step.status || '')}">
          <span>${escapeHtml(step.phase || 'step')} · ${escapeHtml(step.status || 'running')}</span>
          <strong>${escapeHtml(step.summary || '')}</strong>
          ${step.details ? `<p>${escapeHtml(step.details)}</p>` : ''}
          ${step.files && step.files.length ? `<p class="loop-files">${step.files.map(escapeHtml).join(', ')}</p>` : ''}
        </li>`).join('') || '<li class="empty-state">No loop steps yet.</li>'}
    </ol>`;
}

function renderStatus() {
  els.eventCount.textContent = String(state.events.length);
  els.shotCount.textContent = String(state.screenshots.length);
  els.approvalCount.textContent = String(state.approvals.filter((item) => item.status === 'pending').length);
  const phase = state.phase || { phase: 'planning', summary: null, details: null };
  els.phaseBox.dataset.phase = phase.phase || 'planning';
  els.phaseBox.innerHTML = `
    <span class="phase-label">Current phase</span>
    <strong>${escapeHtml(phaseLabel(phase.phase))}</strong>
    ${phase.summary ? `<p>${escapeHtml(phase.summary)}</p>` : ''}
    ${phase.details ? `<p class="phase-details">${escapeHtml(phase.details)}</p>` : ''}`;
  if (state.intent) {
    els.intentBox.innerHTML = `
      <span class="intent-label">Current intent · ${escapeHtml(state.intent.risk || 'read-only')}</span>
      <strong>${escapeHtml(state.intent.summary || 'Active QA step')}</strong>
      ${state.intent.details ? `<p>${escapeHtml(state.intent.details)}</p>` : ''}`;
    els.intentBox.dataset.risk = state.intent.risk || 'read-only';
  } else {
    els.intentBox.innerHTML = '<span class="intent-label">Current intent</span><strong>No active intent yet.</strong>';
    els.intentBox.dataset.risk = 'read-only';
  }
}

function renderAll() {
  renderStatus();
  renderTimeline();
  renderLogs();
  renderBrowser();
  renderFindings();
  renderFixLoop();
  renderApprovals();
}

function applySnapshot(snapshot) {
  state.events = snapshot.events || [];
  state.findings = snapshot.findings || [];
  state.screenshots = snapshot.screenshots || [];
  state.approvals = snapshot.approvals || [];
  state.intent = snapshot.intent || null;
  state.phase = snapshot.phase || null;
  state.fixLoop = snapshot.fix_loop || null;
  state.browser = { url: null, title: null, viewport: null, mode: 'waiting', ...(snapshot.browser || {}) };
  state.cursor = snapshot.cursor || null;
  state.selectableElements = snapshot.selectable_elements || null;
  for (const ev of state.events) eventBrowserPatch(ev);
  const lastShot = state.screenshots[state.screenshots.length - 1];
  if (!state.browser.url && lastShot?.url) state.browser = { ...state.browser, url: lastShot.url, mode: 'evidence' };
  renderMeta(snapshot);
  renderAll();
}

async function loadSnapshot() {
  const res = await fetch('/api/session', { cache: 'no-store' });
  applySnapshot(await res.json());
}

function connectEvents() {
  const source = new EventSource('/api/events');
  source.addEventListener('open', () => {
    if (els.connection) {
      els.connection.textContent = 'connected';
      els.connection.className = 'connection connected';
    }
  });
  source.addEventListener('error', () => {
    if (els.connection) {
      els.connection.textContent = 'reconnecting';
      els.connection.className = 'connection disconnected';
    }
  });
  source.addEventListener('snapshot', (event) => applySnapshot(JSON.parse(event.data)));
  source.addEventListener('event', (event) => {
    const ev = JSON.parse(event.data);
    state.events.push(ev);
    eventBrowserPatch(ev);
    renderStatus();
    renderTimeline();
    renderLogs();
    renderBrowser();
  });
  source.addEventListener('screenshot', (event) => {
    const shot = JSON.parse(event.data);
    state.screenshots.push(shot);
    if (shot.url) state.browser = { ...state.browser, url: shot.url, mode: 'evidence' };
    renderStatus();
    renderBrowser();
    updateSelectedActionBar();
  });
  source.addEventListener('finding', (event) => {
    state.findings.push(JSON.parse(event.data));
    renderFindings();
  });
  source.addEventListener('fix_loop', (event) => {
    state.fixLoop = JSON.parse(event.data);
    renderFixLoop();
  });
  source.addEventListener('phase', (event) => {
    state.phase = JSON.parse(event.data);
    renderStatus();
  });
  source.addEventListener('intent', (event) => {
    state.intent = JSON.parse(event.data);
    renderStatus();
  });
  source.addEventListener('browser', (event) => {
    state.browser = { ...state.browser, ...JSON.parse(event.data), mode: 'live' };
    renderBrowser();
  });
  source.addEventListener('cursor', (event) => {
    state.cursor = JSON.parse(event.data);
    updateCursorOverlay();
  });
  source.addEventListener('selectable_elements', (event) => {
    state.selectableElements = JSON.parse(event.data);
    state.selectedElement = null;
    renderBrowser();
    updateSelectedActionBar();
    updateMiniStatus();
  });
  source.addEventListener('approval', (event) => {
    const approval = JSON.parse(event.data);
    state.approvals = state.approvals.filter((item) => item.id !== approval.id).concat([approval]);
    renderStatus();
    renderApprovals();
  });
}

async function answerApproval(id, answer, note = '') {
  await fetch(`/api/approval/${encodeURIComponent(id)}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ answer, note }),
  });
  await loadSnapshot();
}

els.approvals.addEventListener('click', (event) => {
  const button = event.target.closest('button[data-approval]');
  if (!button) return;
  const note = els.approvals.querySelector(`[data-note-for="${CSS.escape(button.dataset.approval)}"]`)?.value || '';
  answerApproval(button.dataset.approval, button.dataset.answer, note);
});

els.clearLocal?.addEventListener('click', () => {
  state.events = [];
  renderStatus();
  renderTimeline();
  renderLogs();
});

function setLogsOpen(open) {
  if (!els.logsDrawer || !els.logsToggle) return;
  els.logsDrawer.classList.toggle('open', open);
  els.logsDrawer.setAttribute('aria-hidden', open ? 'false' : 'true');
  els.logsToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
  try { window.localStorage.setItem('qa-console.logs-open', open ? '1' : '0'); } catch (_) {}
  if (open) renderLogs();
}

els.logsToggle?.addEventListener('click', () => {
  const open = els.logsToggle.getAttribute('aria-expanded') !== 'true';
  setLogsOpen(open);
});

els.logsClose?.addEventListener('click', () => setLogsOpen(false));

els.selectedActionBar?.addEventListener('click', (event) => {
  const button = event.target.closest('button[data-selected-action]');
  if (!button || !state.selectedElement) return;
  const action = button.dataset.selectedAction;
  const label = elementLabel(state.selectedElement);
  const payload = {
    action,
    label,
    text: state.selectedElement.text || null,
    tag: state.selectedElement.tag || null,
    className: state.selectedElement.className || null,
    selector: state.selectedElement.selector || null,
    dataAttrs: state.selectedElement.dataAttrs || {},
    sourceHint: state.selectedElement.sourceHint || null,
    url: state.selectableElements?.url || state.browser?.url || null,
    session_id: state.selectableElements?.session_id || state.browser?.session_id || null,
  };
  const kind = action === 'fix' ? 'fix_selected' : action === 'explain' ? 'explain_selected' : 'inspect_selected';
  sendCommand(kind, payload);
  showToast(`${button.textContent} requested`, elementTechLabel(state.selectedElement));
});

window.addEventListener('keydown', (event) => {
  if (event.key === 'Escape') setLogsOpen(false);
});

async function sendCommand(kind, payload = {}) {
  try {
    await fetch('/api/command', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ kind, payload }),
    });
  } catch (err) {
    /* ignore — server will log */
  }
}

function flashButton(btn) {
  if (!btn) return;
  btn.classList.add('sent');
  setTimeout(() => btn.classList.remove('sent'), 350);
}

els.urlForm?.addEventListener('submit', (event) => {
  event.preventDefault();
  let url = els.urlInput.value.trim();
  if (!url) return;
  if (!/^https?:\/\//i.test(url)) url = `https://${url}`;
  sendCommand('navigate', { url });
  els.urlInput.value = '';
});

els.instructionForm?.addEventListener('submit', (event) => {
  event.preventDefault();
  const text = els.instructionInput.value.trim();
  if (!text) return;
  sendCommand('instruction', { text });
  els.instructionInput.value = '';
});

els.cmdBack?.addEventListener('click', () => { sendCommand('back'); flashButton(els.cmdBack); });
els.cmdForward?.addEventListener('click', () => { sendCommand('forward'); flashButton(els.cmdForward); });
els.cmdReload?.addEventListener('click', () => { sendCommand('reload'); flashButton(els.cmdReload); });
els.cmdScreenshot?.addEventListener('click', () => { sendCommand('screenshot'); flashButton(els.cmdScreenshot); });
els.cmdStop?.addEventListener('click', () => {
  if (confirm('Tell the agent to stop?')) {
    sendCommand('stop');
    flashButton(els.cmdStop);
  }
});

els.browserStage?.addEventListener('click', (event) => {
  const box = event.target.closest('.selectable-element');
  if (!box) return;
  event.preventDefault();
  event.stopPropagation();
  const selectId = String(box.dataset.selectId || '');
  const element = (state.selectableElements?.elements || []).find((item) => String(item.select_id ?? item.index) === selectId);
  if (!element) return;
  const label = elementLabel(element);
  state.selectedElement = element;
  renderBrowser();
  updateMiniStatus(`Selected: ${elementTechLabel(element)}`);
  showToast(`Selected: ${label}`, elementTechLabel(element));
  updateSelectedActionBar();
  sendCommand('element_selected', {
    select_id: element.select_id || null,
    index: element.index ?? null,
    label,
    text: element.text || null,
    placeholder: element.placeholder || null,
    id: element.id || null,
    className: element.className || null,
    name: element.name || null,
    tag: element.tag || null,
    role: element.role || null,
    type: element.type || null,
    href: element.href || null,
    ariaLabel: element.ariaLabel || null,
    title: element.title || null,
    alt: element.alt || null,
    dataAttrs: element.dataAttrs || {},
    sourceHint: element.sourceHint || null,
    outerHTML: element.outerHTML || null,
    selector: element.selector || null,
    bbox: { x: element.x, y: element.y, w: element.w, h: element.h },
    url: state.selectableElements?.url || state.browser?.url || null,
    session_id: state.selectableElements?.session_id || state.browser?.session_id || null,
  });
});

window.addEventListener('resize', () => window.requestAnimationFrame(fitBrowserViewport));

// The browser frame is intentionally view-only for direct page control.
// Human clicks only select known indexed elements for the agent to consume.

loadSnapshot().then(() => {
  try { if (window.localStorage.getItem('qa-console.logs-open') === '1') setLogsOpen(true); } catch (_) {}
}).catch(() => {});
connectEvents();
