"""Agent QA Console — MCP server exposing browser primitives + QA tools.

Watch, guide, and approve your AI agent’s browser QA work.

NO internal LLM. The calling agent (Claude Code, Codex, Cursor, Gemini CLI,
OpenCode, etc.) provides ALL intelligence — it reasons about the page,
calls our primitives, synthesizes findings.

Architecture:
  Calling agent (Claude/Codex/etc.)
    ↓ "audit voicebox.brainboxai.io"
    ↓ chooses tools based on its own judgment
  Agent QA Console
    ↓ executes tool: open browser, eval JS, click, screenshot
    ↓ returns structured JSON
  Calling agent
    ↓ summarizes for user

The QA expertise lives in:
  - Tool descriptions (rich docstrings teach the calling agent what each does)
  - JS audit scripts (rtl_audit.js, scan_links.js, perf_metrics.js)
  - axe-core (a11y)

Result: zero LLM cost on top of what the user already pays for their agent,
works with any MCP client, no API keys needed.
"""
from __future__ import annotations

import asyncio
import atexit
from pathlib import Path
from typing import Any

from mcp.server.fastmcp import FastMCP

from .browser import SessionManager
from .tools import browser_tools, qa_tools, project_context
from . import training_data as _training
from .workspace import workspace


mgr = SessionManager()
mcp = FastMCP("agent-qa-console")


TOOL_CORE = {
    # Browser essentials
    "browser_open", "browser_navigate", "browser_get_state", "browser_click",
    "browser_type", "browser_hover", "browser_scroll", "browser_screenshot",
    "browser_logs", "browser_close",
    # Console essentials
    "qa_console_open", "qa_console_pending_commands", "qa_console_ask_approval",
    "qa_console_status", "qa_console_close",
    # Main audits
    "qa_rtl_audit", "qa_a11y_audit", "qa_perf_metrics", "qa_seo_check",
    "qa_scan_links", "qa_asset_audit", "qa_conversion_audit",
    # High-level agent workflows
    "qa_agent_audit_url", "qa_dev_check_url", "qa_agent_explore_site",
    "qa_agent_test_flow",
    # Local source mapping
    "qa_project_context", "qa_map_selected_element_to_source",
    # Catalog itself
    "qa_tool_catalog",
}

TOOL_CATEGORIES = {
    "core_browser": {
        "browser_open", "browser_navigate", "browser_get_state", "browser_click",
        "browser_type", "browser_hover", "browser_scroll", "browser_screenshot",
        "browser_logs", "browser_close",
    },
    "advanced_browser": {
        "browser_evaluate", "browser_wait_for", "browser_press_key", "browser_select_option",
        "browser_fill_form", "browser_drag", "browser_scroll_to", "browser_handle_dialog",
        "browser_set_viewport", "browser_set_geolocation", "browser_throttle_network",
        "browser_get_cookies", "browser_set_cookies", "browser_save_storage_state",
        "browser_restore_storage_state",
    },
    "console_core": {
        "qa_console_open", "qa_console_pending_commands", "qa_console_ask_approval",
        "qa_console_status", "qa_console_close",
    },
    "console_internal": {
        "qa_console_event", "qa_console_set_intent", "qa_console_set_phase",
        "qa_console_start_fix_loop", "qa_console_loop_step", "qa_console_add_finding",
        "qa_console_capture",
    },
    "audits": {
        "qa_rtl_audit", "qa_a11y_audit", "qa_perf_metrics", "qa_seo_check",
        "qa_scan_links", "qa_asset_audit", "qa_conversion_audit", "qa_ux_metrics",
        "qa_responsive_audit", "qa_design_quality_check", "qa_form_risk_audit",
        "qa_security_passive_audit", "qa_tech_stack_detect", "qa_design_interaction_scan",
    },
    "high_level": {
        "qa_agent_audit_url", "qa_agent_context", "qa_agent_explore_site",
        "qa_agent_test_flow", "qa_dev_check_url", "qa_ux_audit_url",
    },
    "forms_flows": {
        "qa_form_inventory", "qa_form_smart_fill", "qa_fuzz_input",
        "qa_login_with_credentials", "qa_flow_runner",
    },
    "project_ci": {
        "qa_project_context", "qa_map_selected_element_to_source", "qa_project_init",
        "qa_project_check", "qa_project_check_file", "qa_pre_deploy_check",
        "qa_auto_plan_project", "qa_auto_check_project", "qa_validate_config",
        "qa_run_suite", "qa_baseline_save", "qa_baseline_compare", "qa_baseline_list",
    },
    "source_fixes": {
        "qa_fix_suggestions", "qa_fix_from_findings", "qa_map_to_source",
        "qa_map_with_fixes",
    },
    "reports_integrations": {
        "qa_client_report", "qa_client_report_pdf", "qa_github_create_issues",
        "qa_slack_notify",
    },
    "design_inspiration": {
        "qa_decompose_page", "qa_extract_elements", "qa_element_to_tailwind",
        "qa_export_to_html", "qa_diff_elements", "qa_inspiration_analyze_url",
        "qa_originality_check",
    },
    "training": {
        "qa_training_stats", "qa_training_export", "qa_training_diffs",
    },
    "catalog": {"qa_tool_catalog"},
}

TOOL_VISIBILITY_OVERRIDES = {
    name: "core" for name in TOOL_CORE
}
for _name in (
    TOOL_CATEGORIES["console_internal"]
    | TOOL_CATEGORIES["reports_integrations"]
    | TOOL_CATEGORIES["training"]
    | TOOL_CATEGORIES["design_inspiration"]
):
    TOOL_VISIBILITY_OVERRIDES.setdefault(_name, "advanced")


def tool_category(name: str) -> str:
    for category, names in TOOL_CATEGORIES.items():
        if name in names:
            return category
    return "other"


def tool_visibility(name: str) -> str:
    return TOOL_VISIBILITY_OVERRIDES.get(name, "advanced")


def visible_tool_names(names: list[str], profile: str = "core") -> list[str]:
    """Filter tool names for human/agent discovery without disabling calls."""
    normalized = (profile or "core").lower().strip()
    if normalized in {"all", "full", "advanced"}:
        return sorted(names)
    if normalized in {"recommended", "core", "default"}:
        return sorted([name for name in names if tool_visibility(name) == "core"])
    if normalized.startswith("category:"):
        category = normalized.split(":", 1)[1]
        wanted = TOOL_CATEGORIES.get(category, set())
        return sorted([name for name in names if name in wanted])
    return sorted([name for name in names if tool_visibility(name) == "core"])


def _cleanup_sync():
    try:
        loop = asyncio.new_event_loop()
        loop.run_until_complete(mgr.close_all())
        loop.close()
    except Exception:
        pass


atexit.register(_cleanup_sync)


def _is_workspace_url(url: str | None) -> bool:
    """Return True when a browser page is the Agent QA Console itself.

    Such pages must never become the live browser target; otherwise the center
    panel streams the dashboard recursively instead of the agent's real page.
    """
    if not url or not workspace.url:
        return False
    return str(url).rstrip("/").startswith(str(workspace.url).rstrip("/"))


async def _collect_visible_dom_elements(session_id: str, max_elements: int = 2000) -> list[dict[str, Any]]:
    """Collect all visible DOM boxes for human visual selection.

    This is intentionally broader than browser_get_state's interactive index:
    headings, text blocks, images, cards, divs, buttons, inputs, links, SVGs,
    canvases, and layout containers. The selected element is a user hint for
    the agent, not necessarily a direct browser_click index.
    """
    try:
        session = mgr.get(session_id)
        return await session.page.evaluate(
            r"""
            (maxElements) => {
              const skip = new Set(['HTML','HEAD','BODY','SCRIPT','STYLE','META','LINK','TITLE','NOSCRIPT','TEMPLATE','BR']);
              const out = [];
              const cssPath = (el) => {
                if (!el || !el.tagName) return '';
                if (el.id) return `${el.tagName.toLowerCase()}#${CSS.escape(el.id)}`;
                const parts = [];
                let node = el;
                while (node && node.nodeType === 1 && node !== document.body && parts.length < 6) {
                  let part = node.tagName.toLowerCase();
                  if (node.id) {
                    part += `#${CSS.escape(node.id)}`;
                    parts.unshift(part);
                    break;
                  }
                  const cls = Array.from(node.classList || []).slice(0, 3).map((c) => `.${CSS.escape(c)}`).join('');
                  part += cls;
                  const parent = node.parentElement;
                  if (parent) {
                    const sameTag = Array.from(parent.children).filter((child) => child.tagName === node.tagName);
                    if (sameTag.length > 1) part += `:nth-of-type(${sameTag.indexOf(node) + 1})`;
                  }
                  parts.unshift(part);
                  node = parent;
                }
                return parts.join(' > ');
              };
              const visibleText = (el) => {
                const raw = (el.innerText || el.getAttribute('aria-label') || el.getAttribute('alt') || el.getAttribute('title') || el.getAttribute('placeholder') || '').trim().replace(/\s+/g, ' ');
                return raw.slice(0, 160);
              };
              const dataAttrs = (el) => {
                const attrs = {};
                for (const attr of Array.from(el.attributes || [])) {
                  if (attr.name.startsWith('data-')) attrs[attr.name] = attr.value;
                }
                return attrs;
              };
              const shortOuterHtml = (el) => {
                const clone = el.cloneNode(false);
                let html = clone.outerHTML || '';
                return html.replace(/\s+/g, ' ').slice(0, 500);
              };
              for (const el of document.querySelectorAll('*')) {
                if (out.length >= maxElements) break;
                if (skip.has(el.tagName)) continue;
                const style = getComputedStyle(el);
                if (style.display === 'none' || style.visibility === 'hidden' || Number(style.opacity) === 0) continue;
                const rect = el.getBoundingClientRect();
                if (rect.width < 2 || rect.height < 2) continue;
                if (rect.bottom < 0 || rect.right < 0 || rect.top > innerHeight || rect.left > innerWidth) continue;
                const text = visibleText(el);
                const data = dataAttrs(el);
                out.push({
                  select_id: `dom-${out.length}`,
                  tag: el.tagName.toLowerCase(),
                  role: el.getAttribute('role') || null,
                  text,
                  id: el.id || null,
                  className: typeof el.className === 'string' ? el.className : null,
                  name: el.getAttribute('name') || null,
                  type: el.getAttribute('type') || null,
                  placeholder: el.getAttribute('placeholder') || null,
                  href: el.getAttribute('href') || null,
                  ariaLabel: el.getAttribute('aria-label') || null,
                  title: el.getAttribute('title') || null,
                  alt: el.getAttribute('alt') || null,
                  dataAttrs: data,
                  sourceHint: data['data-source'] || data['data-file'] || data['data-component'] || data['data-testid'] || data['data-test-id'] || data['data-agent-id'] || null,
                  outerHTML: shortOuterHtml(el),
                  selector: cssPath(el),
                  x: Math.max(0, rect.left),
                  y: Math.max(0, rect.top),
                  w: Math.min(innerWidth, rect.right) - Math.max(0, rect.left),
                  h: Math.min(innerHeight, rect.bottom) - Math.max(0, rect.top),
                });
              }
              return out;
            }
            """,
            max_elements,
        )
    except Exception:
        return []


async def _publish_selectable_elements(session_id: str,
                                       url: str | None = None,
                                       viewport: dict[str, Any] | None = None) -> None:
    """Refresh the Console selection overlay from the current live DOM."""
    try:
        session = mgr.get(session_id)
        page = session.page
        visual_elements = await _collect_visible_dom_elements(session_id)
        workspace.set_selectable_elements(
            session_id=session_id,
            url=url or page.url,
            viewport=viewport or getattr(page, "viewport_size", None),
            elements=visual_elements,
        )
    except Exception:
        pass


async def _move_agent_cursor_to_index(session_id: str, index: int, action: str,
                                      pulse: bool = False) -> dict[str, Any] | None:
    """Move the visible agent cursor to an indexed element before acting.

    The workspace overlay animates between cursor events. We publish the target
    before running the Playwright action and also move Playwright's real mouse
    to keep browser hover/click state consistent with the visible cursor.
    """
    try:
        session = mgr.get(session_id)
        el = getattr(session, "last_elements_by_index", {}).get(int(index))
        viewport = getattr(session.page, "viewport_size", None) or {}
        width = float(viewport.get("width") or 0)
        height = float(viewport.get("height") or 0)
        if not el or width <= 0 or height <= 0:
            return None
        abs_x = float(el.get("x") or 0) + (float(el.get("w") or 0) / 2.0)
        abs_y = float(el.get("y") or 0) + (float(el.get("h") or 0) / 2.0)
        x = abs_x / width
        y = abs_y / height
        text = str(el.get("text") or el.get("placeholder") or el.get("role") or "").strip()
        label = f"{action} #{index}" + (f" · {text[:40]}" if text else "")
        workspace.set_cursor(x, y, action=action, label=label, session_id=session_id, pulse=pulse)
        try:
            await session.page.mouse.move(abs_x, abs_y)
        except Exception:
            pass
        return {"x": x, "y": y, "label": label, "abs_x": abs_x, "abs_y": abs_y}
    except Exception:
        return None


def _publish_audit_findings(kind: str, result: dict[str, Any], max_cards: int = 8) -> None:
    """Publish compact audit summaries into the visual workspace."""
    summary = result.get("summary") if isinstance(result, dict) else None
    total = summary.get("total") if isinstance(summary, dict) else None
    if total is None:
        total = len(result.get("findings", [])) if isinstance(result, dict) else 0
    workspace.emit(kind, f"{kind} completed: {total} finding(s)", {"summary": summary or {}})

    findings = result.get("findings", []) if isinstance(result, dict) else []
    if not findings and isinstance(result, dict):
        findings = result.get("violations", []) or result.get("items", [])
    for item in findings[:max_cards]:
        if not isinstance(item, dict):
            continue
        title = item.get("title") or item.get("help") or item.get("message") or item.get("id") or kind
        severity = item.get("severity") or item.get("impact") or "medium"
        description = item.get("description") or item.get("hint") or item.get("sample") or item.get("evidence")
        selector = item.get("selector")
        if selector is None and item.get("nodes"):
            first_node = item["nodes"][0]
            if isinstance(first_node, dict):
                target = first_node.get("target")
                selector = ", ".join(target) if isinstance(target, list) else target
        workspace.add_finding(
            title=str(title),
            severity=str(severity),
            description=str(description) if description else None,
            selector=str(selector) if selector else None,
            data={"source": kind, "raw": item},
        )


# ---------- Tool catalog ----------


@mcp.tool()
def qa_tool_catalog(profile: str = "core") -> dict[str, Any]:
    """List Agent QA Console tool categories and recommended visibility.

    profile:
      - core/default/recommended: only tools recommended for normal agents.
      - all/full/advanced: every registered tool.
      - category:<name>: one category, e.g. category:project_ci.

    This is a discovery/catalog layer only; advanced tools still exist and can
    be called explicitly for backwards compatibility.
    """
    all_names = sorted([
        name for name, value in globals().items()
        if (name.startswith("browser_") or name.startswith("qa_")) and callable(value)
    ])
    selected = set(visible_tool_names(all_names, profile=profile))
    categories: dict[str, list[dict[str, str]]] = {}
    for name in all_names:
        if name not in selected:
            continue
        category = tool_category(name)
        categories.setdefault(category, []).append({
            "name": name,
            "visibility": tool_visibility(name),
        })
    return {
        "ok": True,
        "profile": profile,
        "total_visible": sum(len(items) for items in categories.values()),
        "total_registered": len(all_names),
        "categories": categories,
        "available_profiles": ["core", "all", "category:<category>"],
        "category_names": sorted(TOOL_CATEGORIES.keys()),
    }


# ---------- Agent QA Console ----------


@mcp.tool()
async def qa_console_open(title: str | None = None,
                          host: str = "127.0.0.1",
                          port: int = 0,
                          open_browser: bool = True,
                          reset: bool = False,
                          session_id: str | None = None,
                          project_root: str | None = None) -> dict[str, Any]:
    """Open the local Agent QA Console for the human user.

    Watch, guide, and approve your AI agent’s browser QA work.

    This does not replace the coding agent. It gives the user a browser UI that
    shows what the agent is doing: timeline, latest screenshot,
    findings, and approval buttons. Call this near the beginning of an
    interactive QA task.

    Args:
        title: Optional session label shown in the workspace.
        host: Bind host. Defaults to localhost only.
        port: 0 picks a free port. Pass a fixed port if you need a stable URL.
        open_browser: Open the workspace URL in the user's default browser.
        reset: Clear previous timeline/findings/screenshots before opening.
    """
    if reset:
        workspace.reset(title=title)
    result = workspace.start(host=host, port=port, title=title, open_browser=open_browser)
    if project_root is not None:
        try:
            ctx = project_context.build_project_context(project_root=project_root, max_files=800, max_depth=5)
            result["project_context"] = ctx
            workspace.emit(
                "project_context",
                f"Loaded project context: {ctx.get('framework')} · {ctx.get('counts', {}).get('scannedFiles')} files",
                {"projectRoot": ctx.get("projectRoot"), "framework": ctx.get("framework"), "counts": ctx.get("counts")},
            )
        except Exception as exc:
            result["project_context_error"] = str(exc)
    return result


@mcp.tool()
async def qa_console_close(session_id: str | None = None) -> dict[str, Any]:
    """Stop the local Agent QA Console server."""
    return workspace.stop()


@mcp.tool()
async def qa_console_status(session_id: str | None = None) -> dict[str, Any]:
    """Return current Agent QA Console state: URL, timeline count, findings,
    screenshots, and approvals. Useful when the agent wants to link the user
    back to the UI."""
    snap = workspace.snapshot()
    return {
        "running": snap["running"],
        "url": snap["url"],
        "title": snap["title"],
        "event_count": len(snap["events"]),
        "finding_count": len(snap["findings"]),
        "screenshot_count": len(snap["screenshots"]),
        "pending_approvals": [a for a in snap["approvals"] if a.get("status") == "pending"],
        "intent": snap.get("intent"),
        "phase": snap.get("phase"),
        "fix_loop": snap.get("fix_loop"),
    }


@mcp.tool()
async def qa_console_pending_commands(consume: bool = True,
                                      session_id: str | None = None) -> dict[str, Any]:
    """Return user commands from the Agent QA Console, including selected elements.

    Use after the user chooses an element in the read-only browser view. When
    consume=True, returned commands are marked consumed so repeated polls don't
    process the same selection twice.
    """
    commands = workspace.pending_commands(consume=consume)
    return {"ok": True, "commands": commands, "count": len(commands)}


@mcp.tool()
async def qa_console_start_fix_loop(goal: str,
                                    target: str | None = None,
                                    session_id: str | None = None) -> dict[str, Any]:
    """Start a visible test-fix-verify loop.

    Call this when the user asks the coding agent to QA a feature and fix what
    breaks. The MCP tracks the loop; the coding agent still performs source-code
    edits with its normal file tools.
    """
    return workspace.start_fix_loop(goal=goal, target=target)


@mcp.tool()
async def qa_console_loop_step(phase: str,
                               summary: str,
                               status: str = "running",
                               details: str | None = None,
                               files: list[str] | None = None,
                               session_id: str | None = None) -> dict[str, Any]:
    """Record one step in the active test-fix-verify loop.

    Use phases like testing, failed, fixing, retesting, passed, needs-human.
    Use status like running, failed, fixed, passed, needs-human.
    Include files when a source-code fix is proposed or applied.
    """
    return workspace.add_loop_step(phase=phase, summary=summary, status=status, details=details, files=files)


@mcp.tool()
async def qa_console_set_phase(phase: str,
                               summary: str | None = None,
                               details: str | None = None,
                               session_id: str | None = None) -> dict[str, Any]:
    """Set the current test-fix-verify phase in the Agent QA Console.

    Valid phases: planning, testing, failed, fixing, retesting, passed,
    needs-human. Use this to make the QA repair loop visible to the human.
    """
    return workspace.set_phase(phase=phase, summary=summary, details=details)


@mcp.tool()
async def qa_console_set_intent(summary: str,
                                risk: str = "read-only",
                                details: str | None = None,
                                session_id: str | None = None) -> dict[str, Any]:
    """Show what the agent is trying to do right now.

    Use this before a flow or audit step so the human sees the current goal.
    `risk` should be read-only, low, medium, or high. High-risk actions should
    be followed by qa_console_ask_approval before execution.
    """
    return workspace.set_intent(summary=summary, risk=risk, details=details)


@mcp.tool()
async def qa_console_event(message: str,
                           kind: str = "agent_note",
                           level: str = "info",
                           data: dict[str, Any] | None = None,
                           session_id: str | None = None) -> dict[str, Any]:
    """Add a human-readable timeline event to the Agent QA Console.

    Use this before meaningful actions: explain what the agent is about to do,
    why it matters, and whether the action is read-only or risky.
    """
    return workspace.emit(kind, message, data=data, level=level)


@mcp.tool()
async def qa_console_add_finding(title: str,
                                 severity: str = "medium",
                                 description: str | None = None,
                                 selector: str | None = None,
                                 screenshot_path: str | None = None,
                                 fix: str | None = None,
                                 data: dict[str, Any] | None = None,
                                 session_id: str | None = None) -> dict[str, Any]:
    """Add an actionable finding card to the Agent QA Console.

    The calling agent decides what is important; this tool turns that decision
    into a visible card for the user with severity, evidence, selector, and fix.
    """
    return workspace.add_finding(
        title=title,
        severity=severity,
        description=description,
        selector=selector,
        screenshot_path=screenshot_path,
        fix=fix,
        data=data,
    )


@mcp.tool()
async def qa_console_capture(session_id: str,
                             label: str = "Current browser state",
                             full_page: bool = False) -> dict[str, Any]:
    """Capture a browser screenshot and publish it to the Agent QA Console.

    Use this after page loads, form submissions, modal opens, failed assertions,
    and before asking the user for approval.
    """
    shot = await browser_tools.browser_screenshot(mgr, session_id, full_page=full_page)
    workspace.add_screenshot(shot["path"], label=label, url=shot.get("url"), data=shot)
    return {"ok": True, "screenshot": shot, "workspace_url": workspace.url}


@mcp.tool()
async def qa_console_ask_approval(question: str,
                                  details: str | None = None,
                                  choices: list[str] | None = None,
                                  timeout_seconds: int = 300,
                                  session_id: str | None = None) -> dict[str, Any]:
    """Ask the user for approval in the Agent QA Console and wait for a click.

    Use before risky actions: submitting real forms, deleting data, creating
    GitHub issues, changing files, or testing payments. Returns the selected
    answer or status='timeout'.
    """
    return await workspace.ask_approval(
        question=question,
        details=details,
        choices=choices,
        timeout_seconds=timeout_seconds,
    )


# ---------- browser primitives ----------


@mcp.tool()
async def browser_open(url: str | None = None, headless: bool = True,
                       geolocation: dict | None = None,
                       timezone: str | None = None,
                       locale: str | None = None,
                       user_agent: str | None = None,
                       browser: str = "chrome",
                       network: str | dict | None = None,
                       stealth: bool = True) -> dict[str, Any]:
    """Open a new browser session.

    First call per engine may take ~30s for the auto-install. Subsequent
    sessions launch in <1s.

    Args:
        url: Optional URL to navigate to immediately.
        headless: True (default) runs browser without UI window.
        browser: 'chrome' (default), 'chromium'/'msedge' branded channels,
            'cloak' (CloakBrowser stealth Chromium; requires pip install cloakbrowser),
            'webkit' (Safari), 'firefox'. iOS-style BiDi/flex bugs surface only on webkit.
        network: throttle preset 'slow_3g' | 'fast_3g' | '4g' | 'wifi' |
            'offline', or custom dict. Chromium only.
        geolocation: {"latitude": 32.08, "longitude": 34.78}.
        timezone: IANA name (e.g. "Asia/Jerusalem"). Cannot be changed later.
        locale: BCP-47 (e.g. "he-IL"). Cannot be changed later.
        user_agent: full UA string. Cannot be changed later.
        stealth: True (default). Apply anti-detection patches to bypass
            CDN/WAF bot protection (Cloudflare, Akamai, DataDome). Disable
            for internal/CI sites where it's not needed.
    """
    result = await browser_tools.browser_open(
        mgr, url=url, headless=headless,
        geolocation=geolocation, timezone=timezone,
        locale=locale, user_agent=user_agent,
        browser=browser, network=network,
        stealth=stealth,
    )
    opened_url = result.get("url")
    sid = result.get("session_id")
    if sid and not _is_workspace_url(opened_url):
        workspace.attach_browser(sid, mgr.get(sid), asyncio.get_running_loop())
        workspace.set_cursor(0.5, 0.5, action="ready", label="assistant", session_id=sid, pulse=False)
        await _publish_selectable_elements(sid, url=opened_url)
    workspace.emit(
        "browser_open",
        f"Opened browser session{' at ' + opened_url if opened_url else ''}",
        {"session_id": sid, "url": opened_url, "headless": headless, "browser": result.get("browser")},
    )
    return result


@mcp.tool()
async def browser_throttle_network(session_id: str,
                                   preset: str | None = None,
                                   custom: dict | None = None) -> dict[str, Any]:
    """Change network conditions on an existing session (Chromium only).
    preset: 'slow_3g' | 'fast_3g' | '4g' | 'wifi' | 'offline'.
    custom: {"downloadThroughput": <bytes/sec>, "uploadThroughput": <bytes/sec>,
             "latency": <ms>}."""
    return await browser_tools.browser_throttle_network(
        mgr, session_id, preset=preset, custom=custom,
    )


@mcp.tool()
async def browser_navigate(session_id: str, url: str,
                           wait_until: str = "domcontentloaded") -> dict[str, Any]:
    """Navigate the session to a new URL.

    wait_until: 'domcontentloaded' (default), 'load', or 'networkidle'."""
    result = await browser_tools.browser_navigate(mgr, session_id, url, wait_until)
    if not _is_workspace_url(result.get("url") or url):
        workspace.attach_browser(session_id, mgr.get(session_id), asyncio.get_running_loop())
        workspace.set_cursor(0.5, 0.5, action="ready", label="assistant", session_id=session_id, pulse=False)
        await _publish_selectable_elements(session_id, url=result.get("url") or url)
    workspace.emit(
        "browser_navigate",
        f"Navigated to {result.get('url') or url}",
        {"session_id": session_id, "url": result.get("url") or url, "status": result.get("status"), "redirect_count": result.get("redirect_count")},
        level="info" if result.get("status") in (None, 200) else "warning",
    )
    return result


@mcp.tool()
async def browser_screenshot(session_id: str, full_page: bool = False,
                             save_to: str | None = None,
                             include_base64: bool = False) -> dict[str, Any]:
    """Take a JPEG screenshot. Default: saves to disk and returns the path
    only — does NOT embed base64 (would blow up agent context with full-page
    images). Pass `include_base64=True` only when bytes are actually needed.

    `save_to` (optional): explicit path. Else auto-saves to ~/.qa-mcp/screenshots/."""
    result = await browser_tools.browser_screenshot(
        mgr, session_id, full_page, save_to=save_to, include_base64=include_base64,
    )
    workspace.add_screenshot(
        result["path"],
        label="Screenshot",
        url=result.get("url"),
        data={k: v for k, v in result.items() if k != "base64"},
    )
    return result


@mcp.tool()
async def browser_get_state(session_id: str,
                            text_snapshot_chars: int = 1500,
                            scope: str | None = None,
                            exclude: str | None = None,
                            max_elements: int | None = None) -> dict[str, Any]:
    """Snapshot interactive elements ACROSS the main frame and every iframe.
    Each element gets a globally-unique `index`. Click/type/hover by index
    automatically routes to the correct frame — TinyMCE/CKEditor work.

    Includes:
      - `text_snapshot` — visible body text (capped at text_snapshot_chars).
        Crucial for catching error messages and status text after actions.
        Set to 0 to skip.
      - `last_dialog` — most recent JS dialog the page raised.
      - `<select>` elements get an `options` array.
      - Each element has `frame_url` (null = main frame).

    Re-call after any DOM-changing action.

    Scoping (use on dense pages — large sidebars/100+ link indexes can blow
    the snapshot past the agent's context window):
      - scope: CSS selector — only snapshot elements inside this root
        (e.g. "form", "main", "[data-testid=signup]")
      - exclude: CSS selector — skip elements matching this
        (e.g. "nav, footer, [aria-hidden=true]")
      - max_elements: cap on returned elements; result includes
        `truncated: true` when hit"""
    result = await browser_tools.browser_get_state(
        mgr, session_id,
        text_snapshot_chars=text_snapshot_chars,
        scope=scope, exclude=exclude, max_elements=max_elements,
    )
    await _publish_selectable_elements(
        session_id=session_id,
        url=result.get("url"),
        viewport=result.get("viewport"),
    )
    workspace.emit(
        "browser_get_state",
        f"Read page state: {result.get('element_count', 0)} elements, {result.get('frame_count', 0)} frames",
        {"session_id": session_id, "url": result.get("url"), "truncated": result.get("truncated", False)},
    )
    return result


@mcp.tool()
async def browser_click(session_id: str, index: int) -> dict[str, Any]:
    """Click element by `index` from the most recent browser_get_state.
    Auto-routes to the right frame for cross-iframe elements. Returns
    `last_dialog` if a JS dialog fired during the click."""
    cursor = await _move_agent_cursor_to_index(session_id, index, action="click", pulse=False)
    result = await browser_tools.browser_click(mgr, session_id, index)
    await _publish_selectable_elements(session_id, url=result.get("url"))
    if result.get("ok") and cursor:
        workspace.set_cursor(cursor["x"], cursor["y"], action="click", label=cursor["label"], session_id=session_id, pulse=True)
    workspace.emit(
        "browser_click",
        f"Clicked element #{index}",
        {"session_id": session_id, "index": index, "url": result.get("url"), "ok": result.get("ok")},
        level="info" if result.get("ok") else "error",
    )
    return result


@mcp.tool()
async def browser_type(session_id: str, index: int, text: str,
                       clear: bool = True) -> dict[str, Any]:
    """Focus an input/textarea/contenteditable by index and type text.
    Clears existing value by default. Works on TinyMCE/CKEditor bodies."""
    await _move_agent_cursor_to_index(session_id, index, action="type", pulse=False)
    result = await browser_tools.browser_type(mgr, session_id, index, text, clear)
    await _publish_selectable_elements(session_id, url=result.get("url"))
    workspace.emit(
        "browser_type",
        f"Typed into element #{index}",
        {"session_id": session_id, "index": index, "chars": len(text), "clear": clear, "ok": result.get("ok")},
        level="info" if result.get("ok") else "error",
    )
    return result


@mcp.tool()
async def browser_press_key(session_id: str, key: str) -> dict[str, Any]:
    """Press a keyboard key or combo. Examples: 'Enter', 'Tab', 'Escape',
    'PageDown', 'Control+Shift+P', 'Meta+K'."""
    return await browser_tools.browser_press_key(mgr, session_id, key)


@mcp.tool()
async def browser_select_option(session_id: str, index: int,
                                value: str | list[str] | None = None,
                                label: str | list[str] | None = None,
                                position: int | list[int] | None = None,
                                ) -> dict[str, Any]:
    """Select option(s) on a <select> dropdown. Specify exactly one of:
      - value: option's `value` attribute
      - label: visible option text
      - position: 0-based index

    Pass a list to <select multiple>. Returns the actual selected values.
    Use this for country pickers, language selectors, sort orders, filters —
    none of which work with browser_type."""
    return await browser_tools.browser_select_option(
        mgr, session_id, index, value=value, label=label, position=position,
    )


@mcp.tool()
async def browser_hover(session_id: str, index: int) -> dict[str, Any]:
    """Move the mouse over an element. Triggers mouseenter/mouseover —
    needed for mega-menus, tooltips, hover previews. Re-call get_state
    afterwards if hover changed the DOM."""
    await _move_agent_cursor_to_index(session_id, index, action="hover", pulse=False)
    result = await browser_tools.browser_hover(mgr, session_id, index)
    await _publish_selectable_elements(session_id, url=result.get("url"))
    return result


@mcp.tool()
async def browser_handle_dialog(session_id: str,
                                action: str = "accept",
                                prompt_text: str | None = None) -> dict[str, Any]:
    """Configure how the NEXT JS dialog (alert/confirm/prompt) is handled.
    By default every dialog is auto-dismissed and captured into get_state's
    `last_dialog`. Call this BEFORE clicking the trigger when you want
    accept (or to provide prompt text).

    action: "accept" | "dismiss"
    prompt_text: only used for prompt() — sent as the response.

    Resets to "dismiss" after the dialog fires."""
    return await browser_tools.browser_handle_dialog(
        mgr, session_id, action=action, prompt_text=prompt_text,
    )


@mcp.tool()
async def browser_drag(session_id: str, source_index: int,
                       target_index: int) -> dict[str, Any]:
    """Drag-and-drop from one element to another. Both must be in the same frame."""
    return await browser_tools.browser_drag(mgr, session_id, source_index, target_index)


@mcp.tool()
async def browser_scroll_to(session_id: str, index: int) -> dict[str, Any]:
    """Scroll an element into view. Useful before screenshots or before
    clicking elements far down a long page."""
    result = await browser_tools.browser_scroll_to(mgr, session_id, index)
    workspace.emit(
        "browser_scroll_to",
        f"Scrolled element #{index} into view",
        {"session_id": session_id, "index": index, "url": result.get("url"), "scrollY": result.get("scrollY"), "ok": result.get("ok")},
        level="info" if result.get("ok") else "error",
    )
    return result


@mcp.tool()
async def browser_scroll(session_id: str,
                         dx: float = 0,
                         dy: float = 700) -> dict[str, Any]:
    """Scroll the live browser page by wheel delta.

    Use this to visibly move through a page while the human watches the Agent QA
    Console center panel. Positive dy scrolls down; negative dy scrolls up.
    This is the agent-facing alternative to raw /api/browser-input calls.
    """
    result = await browser_tools.browser_scroll(mgr, session_id, dx=dx, dy=dy)
    await _publish_selectable_elements(session_id, url=result.get("url"))
    workspace.emit(
        "browser_scroll",
        f"Scrolled page by dy={dy}",
        {"session_id": session_id, "url": result.get("url"), "dx": dx, "dy": dy, "scrollY": result.get("scrollY"), "ok": result.get("ok")},
        level="info" if result.get("ok") else "error",
    )
    return result


@mcp.tool()
async def browser_evaluate(session_id: str, expression: str,
                           frame_chain: list[str] | None = None) -> dict[str, Any]:
    """Escape hatch — run arbitrary JS in the page and return its result.
    Examples: 'document.title', '() => navigator.userAgent',
    '() => Array.from(document.querySelectorAll(\".product\")).length'.

    Use sparingly — prefer typed primitives. This is for cases the other
    tools don't cover.

    `frame_chain` (optional): list of CSS selectors descending into nested
    iframes. Each selector picks an <iframe> in the previous level. Saves
    writing `parent.contentDocument.querySelector('iframe').contentDocument...`
    by hand. Example for parent>child nesting:
      frame_chain=["#frame1", "iframe"]"""
    return await browser_tools.browser_evaluate(mgr, session_id, expression,
                                                frame_chain=frame_chain)


@mcp.tool()
async def browser_fill_form(session_id: str,
                            fields: dict[str, Any]) -> dict[str, Any]:
    """Bulk-fill a form by mapping CSS selectors to values. Bypasses the
    common React trap where `el.value = 'x'` is silently ignored — we call
    the native prototype setter and dispatch input+change events so React's
    synthetic event tracker registers the change.

    `fields` is { "css_selector": value }:
      - string / number → set input/textarea/contenteditable value
      - bool True/False → toggle checkbox/radio (or click its <label>)
      - {"value": "x"} or {"label": "Pretty Text"} → pick a <select> option
      - plain string on a <select> tries value first, then label

    Example:
      fields = {
        "#firstName": "Netanel",
        "#userEmail": "x@y.com",
        "#currentAddress": "Tel Aviv",          # textarea — auto-detected
        "label[for=gender-radio-1]": True,      # click the label
        "#country": {"label": "Israel"},        # select by visible text
      }

    Returns per-field results so you see exactly which selector failed.
    For widgets that need real mouse events (React date pickers, custom
    dropdowns, drag handles), use browser_click/type by index instead."""
    result = await browser_tools.browser_fill_form(mgr, session_id, fields)
    workspace.emit(
        "browser_fill_form",
        f"Filled {len(fields)} form field(s)",
        {"session_id": session_id, "field_count": len(fields), "ok": result.get("ok")},
        level="info" if result.get("ok", True) else "error",
    )
    return result


@mcp.tool()
async def browser_set_geolocation(session_id: str,
                                  latitude: float, longitude: float,
                                  accuracy: float | None = None) -> dict[str, Any]:
    """Update geolocation for navigator.geolocation calls. Permission is
    auto-granted. Useful for testing location-aware features (delivery
    pricing, language defaults, regional pricing)."""
    return await browser_tools.browser_set_geolocation(
        mgr, session_id, latitude=latitude, longitude=longitude, accuracy=accuracy,
    )


@mcp.tool()
async def browser_logs(session_id: str, clear: bool = False) -> dict[str, Any]:
    """Recent browser-side events: console errors/warnings, JS exceptions,
    4xx/5xx HTTP responses, network failures (analytics noise filtered out).

    Use this after any meaningful action to catch errors that wouldn't show
    visually. Pass clear=True to drain the buffer after reading."""
    result = await browser_tools.browser_logs(mgr, session_id, clear)
    level = "warning" if result.get("count", 0) else "info"
    workspace.emit(
        "browser_logs",
        f"Read browser logs: {result.get('count', 0)} event(s)",
        {"session_id": session_id, "clear": clear},
        level=level,
    )
    return result


@mcp.tool()
async def browser_close(session_id: str) -> dict[str, Any]:
    """Close session and free the browser. Always call when done."""
    result = await browser_tools.browser_close(mgr, session_id)
    workspace.emit("browser_close", f"Closed browser session {session_id}", {"session_id": session_id})
    return result


@mcp.tool()
async def browser_set_viewport(session_id: str,
                                device: str | None = None,
                                width: int | None = None,
                                height: int | None = None) -> dict[str, Any]:
    """Switch the browser's viewport. Pass either a `device` preset
    (iphone-13, iphone-se, pixel-7, ipad, desktop-1080, desktop-1440,
    desktop-1366) or explicit width+height.

    🇮🇱 Most RTL/Hebrew bugs surface on mobile — switch to 'iphone-13' or
    'pixel-7' before running qa_rtl_audit to catch them.

    Re-call browser_get_state afterwards because element indices change."""
    result = await browser_tools.browser_set_viewport(mgr, session_id, device, width, height)
    if not _is_workspace_url(mgr.get(session_id).page.url):
        workspace.attach_browser(session_id, mgr.get(session_id), asyncio.get_running_loop())
    viewport_label = device or f"{width}x{height}"
    workspace.emit(
        "browser_set_viewport",
        f"Changed viewport to {viewport_label}",
        {"session_id": session_id, "url": mgr.get(session_id).page.url, "viewport": result.get("viewport"), "device": device, "ok": result.get("ok")},
        level="info" if result.get("ok") else "error",
    )
    return result


@mcp.tool()
async def browser_wait_for(session_id: str,
                           selector: str | None = None,
                           url_pattern: str | None = None,
                           network_idle: bool = False,
                           text: str | None = None,
                           timeout_ms: int = 10000) -> dict[str, Any]:
    """Wait for the page to reach a state. Specify exactly one of:
    - `selector`: CSS selector to appear
    - `url_pattern`: URL or glob to match (e.g. '**/dashboard')
    - `network_idle=True`: no network requests for 500ms
    - `text`: substring to appear in the page

    Critical for SPAs (React/Vue/Next.js) where the initial DOM is empty
    and content fills in async — without waiting, browser_get_state returns
    nothing useful."""
    return await browser_tools.browser_wait_for(
        mgr, session_id, selector, url_pattern, network_idle, text, timeout_ms,
    )


@mcp.tool()
async def browser_get_cookies(session_id: str,
                              urls: list[str] | None = None) -> dict[str, Any]:
    """Read cookies for the session. Filter by `urls` if provided."""
    return await browser_tools.browser_get_cookies(mgr, session_id, urls)


@mcp.tool()
async def browser_set_cookies(session_id: str,
                              cookies: list[dict]) -> dict[str, Any]:
    """Set cookies. Each cookie needs name, value, and either url OR
    domain+path."""
    return await browser_tools.browser_set_cookies(mgr, session_id, cookies)


@mcp.tool()
async def browser_save_storage_state(session_id: str,
                                     name: str = "default") -> dict[str, Any]:
    """Save the full session state (cookies + localStorage) to disk under
    `name`. Use this after logging in to skip the login flow on later runs."""
    return await browser_tools.browser_save_storage_state(mgr, session_id, name)


@mcp.tool()
async def browser_restore_storage_state(session_id: str,
                                        name: str) -> dict[str, Any]:
    """Restore previously-saved cookies into the current session. (For full
    localStorage restore, save the state and re-open the session with it.)"""
    return await browser_tools.browser_restore_storage_state(mgr, session_id, name)


# ---------- fix suggester ----------


@mcp.tool()
async def qa_fix_suggestions(session_id: str) -> dict[str, Any]:
    """Generate concrete fix suggestions from the most recent RTL audit
    on this session. Prerequisite: run qa_rtl_audit first on same session."""


@mcp.tool()
def qa_fix_from_findings(findings: list[dict[str, Any]],
                          summary: bool = True) -> dict[str, Any]:
    """Generate fix suggestions directly from a RTL audit findings list.

    Use this when you already have the findings from qa_rtl_audit and
    want to generate fixes without a browser session. Each suggestion
    includes before/after text, confidence, and whether it needs review.

    Auto-fixable (requires_review=False): wrap_bdi, swap_position (₪),
    flip arrow, add dir='rtl'.
    Needs review: CTA translations, date formats, plural agreement.
    """
    return qa_tools.qa_fix_from_findings(findings, summary=summary)


# ---------- project context + source mapper ----------


@mcp.tool()
def qa_project_context(project_root: str | None = None,
                       max_files: int = 800,
                       max_depth: int = 5,
                       session_id: str | None = None) -> dict[str, Any]:
    """Return compact codebase context for visual QA source mapping.

    Use this when Agent QA Console is testing a locally-owned site and the
    coding agent is inside that repo. It returns a filtered tree, framework
    detection, route files, component files, aliases, config files and scripts.

    Skips heavy/generated dirs such as node_modules, .next, dist, build, .git.
    Defaults to the MCP process current working directory when project_root is
    omitted.
    """
    return project_context.build_project_context(
        project_root=project_root,
        max_files=max_files,
        max_depth=max_depth,
    )


@mcp.tool()
def qa_map_selected_element_to_source(selection: dict[str, Any] | None = None,
                                      project_root: str | None = None,
                                      max_matches: int = 12,
                                      session_id: str | None = None) -> dict[str, Any]:
    """Map a user-selected Console element payload to likely source files.

    Pass the payload from qa_console_pending_commands(kind='element_selected'),
    or omit selection to use the latest pending/recorded Console selection.
    Matching strategy: direct data-source/data-file, route by URL, then search
    data-testid/data-agent-id/id/name/aria/placeholder/text/classes in source.
    """
    if selection is None:
        commands = workspace.pending_commands(consume=False)
        for command in reversed(commands):
            if command.get("kind") == "element_selected" and isinstance(command.get("payload"), dict):
                selection = command["payload"]
                break
    if selection is None:
        return {"ok": False, "error": "no selection provided and no element_selected command found"}
    return project_context.map_selected_element_to_source(
        selection=selection,
        project_root=project_root,
        max_matches=max_matches,
    )


@mcp.tool()
def qa_map_to_source(findings: list[dict[str, Any]],
                     repo_path: str,
                     include_i18n: bool = True) -> dict[str, Any]:
    """Map RTL audit findings to source code file:line locations.

    Searches the git repository at repo_path for the offending text
    from each RTL finding. Returns file:line matches with confidence.
    Mapped findings are likely fixable in source; unmapped findings
    are probably from a database/CMS/external API.

    Use this to turn "fix .itemOldPrice-0-3-210" into "fix
    src/components/ProductCard.tsx:47".
    """
    return qa_tools.qa_map_to_source(findings, repo_path, include_i18n=include_i18n)


@mcp.tool()
def qa_map_with_fixes(findings: list[dict[str, Any]],
                      fix_suggestions: list[dict[str, Any]],
                      repo_path: str) -> dict[str, Any]:
    """Full pipeline: RTL findings + fix suggestions → source-mapped
    patches ready to apply.

    Returns { results: [...], auto_patches: [...], all_patches: [...] }
    where each patch has { file, line, before, after, diff, confidence }.
    auto_patches are low-risk (requires_review=False); all_patches
    includes everything.

    Use this after qa_rtl_audit + qa_fix_from_findings to get a
    complete fix plan mapped to actual source files.
    """
    return qa_tools.qa_map_with_fixes(findings, fix_suggestions, repo_path)


# ---------- component extractor / page decomposition ----------


@mcp.tool()
async def qa_decompose_page(url: str | None = None,
                            session_id: str | None = None,
                            max_sections: int = 12,
                            max_components_per_section: int = 12,
                            include_screenshots: bool = True,
                            screenshot_sections: int = 6,
                            include_mobile: bool = False,
                            detail: str = "samples",
                            headless: bool = True,
                            browser: str = "chrome") -> dict[str, Any]:
    """Decompose a page into sections, components, backgrounds and effects.

    Use when the user sees a beautiful site and wants to understand the design
    system and interaction ideas for an original implementation.

    Extracts:
    - page sections: header, hero, cards/grid, forms, pricing, footer, etc.
    - component inventory per section: headings, buttons, cards, inputs, media
    - computed styles: fonts, colors, spacing, shadows, radius, filters
    - backgrounds: colors, gradients, background images, pseudo-elements
    - effects: CSS animations, transitions, keyframes, hover/focus rules
    - assets inventory: image/video/svg/canvas/iframe/font/background URLs
    - optional screenshots per section; optional mobile decomposition

    Legal/originality guardrail: this returns an inspiration-safe design spec,
    not permission to copy proprietary code, assets, branding or exact layouts.
    Rebuild original components using the patterns and measurements.

    Provide either `url` to open/close a page automatically, or `session_id` to
    decompose the current browser session. `detail`: summary | samples | full.
    """
    return await qa_tools.qa_decompose_page(
        mgr, url=url, session_id=session_id,
        max_sections=max_sections,
        max_components_per_section=max_components_per_section,
        include_screenshots=include_screenshots,
        screenshot_sections=screenshot_sections,
        include_mobile=include_mobile,
        detail=detail,
        headless=headless,
        browser=browser,
    )


@mcp.tool()
async def qa_extract_elements(session_id: str,
                              max_elements: int = 50,
                              max_depth: int = 3,
                              selectors: list[str] | None = None,
                              include_children: bool = True,
                              inline_images: bool = True) -> dict[str, Any]:
    """Extract pixel-level UI components from the current page.

    For each major element (buttons, cards, nav, hero, pricing, forms,
    inputs), returns EXACT computed CSS: colors, typography, spacing,
    borders, shadows, layout. Plus bounding box, text, and DOM children.

    Features:
      - Recurses into DOM subtree (depth configurable via `max_depth`)
      - Extracts pseudo-element styles (::before, ::after)
      - Detects CSS custom properties (--variables)
      - Notes image URLs for inlining (set `inline_images=False` to skip)

    Unlike qa_design_interaction_scan (effects) and qa_inspiration_analyze_url
    (abstract patterns), this tool gives you RAW CSS for 1:1 recreation.

    Returns { elements, groups: {button:[...], card:[...], ...}, summary, total }.

    Use when the user says "copy this button", "recreate this card",
    "what font/color/spacing is this using".
    """
    return await qa_tools.qa_extract_elements(mgr, session_id,
        max_elements=max_elements, max_depth=max_depth, selectors=selectors,
        include_children=include_children, inline_images=inline_images)


@mcp.tool()
def qa_diff_elements(a: dict[str, Any], b: dict[str, Any]) -> dict[str, Any]:
    """Compare two extracted UI elements and return exact style differences.
    Returns { identical_properties, different_properties, similarity, diffs }.
    Use for originality checks: "how similar is my button to theirs?" """
    return qa_tools.qa_diff_elements(a, b)


@mcp.tool()
def qa_element_to_tailwind(element: dict[str, Any]) -> dict[str, Any]:
    """Convert a qa_extract_elements result to Tailwind CSS classes.
    Best-effort mapping of CSS properties to equivalent Tailwind utilities.
    Returns { type, tag, text, tailwind_classes: [...], raw_css: {...} }."""
    return qa_tools.qa_element_to_tailwind(element)


# ---------- HTML exporter ----------


@mcp.tool()
def qa_export_to_html(extracted: dict[str, Any], output_path: str,
                      title: str = "Exported Design — Agent QA Console") -> dict[str, Any]:
    """Export extracted DOM sections to a pixel-perfect HTML file.

    Takes the raw extraction from browser_evaluate (full DOM + computed
    styles) and generates a standalone HTML with inline CSS, Tailwind CDN,
    and Google Fonts for every detected font family.

    Use this after a full DOM extraction to get a 1:1 replica of the page's
    design as a standalone HTML file — same fonts, same colors, same spacing,
    same shadows, same layout.
    """
    return qa_tools.qa_export_to_html(extracted, output_path, title=title)


# ---------- QA-specialty tools ----------


@mcp.tool()
async def qa_rtl_audit(session_id: str,
                       ignore_patterns: list[str] | None = None,
                       ignore_selectors: list[str] | None = None,
                       detail: str = "samples",
                       smart_ignore: bool = True,
                       report_mode: str = "internal_full",
                       min_confidence: float = 0.85,
                       strict_currency_position: bool = False) -> dict[str, Any]:
    """🇮🇱 Hebrew/RTL bug scanner — the unique value of this MCP.

    Detects (with severity ratings):
    - Suspicious number/RTL BiDi cases — review-only by default; 0-9 digits are normal Hebrew web text
    - Optional strict ₪ style-guide check (off by default; Israeli sites commonly use both "₪99" and "99 ₪")
    - English placeholders/CTAs in Hebrew forms — medium
    - Wrong arrow direction in CTAs (→ instead of ←) — medium
    - Mixed Hebrew/Latin without <bdi> wrapping — low
    - dir/lang attribute mismatches — high

    `ignore_patterns` (optional): regex strings to silence specific text
        (e.g. ["v\\d+\\.\\d+"] to allow version strings).
    `ignore_selectors` (optional): CSS selectors for elements to skip
        entirely (e.g. [".version-badge"]).
    `detail` (optional): 'summary' | 'samples' (default) | 'full'.
        - summary: counts only, no findings list. ~500 chars.
        - samples: first 5 findings per category. ~5K chars. Best default.
        - full: every finding. Can exceed 200K chars on real sites.
        Use 'summary' when batch-scanning many sites, 'full' when drilling
        into one specific site.
    `smart_ignore` (default True): suppress likely-safe numeric tokens such as
        phone/hotline numbers, pure numeric labels, time strings, and version IDs.
    `report_mode`:
        - internal_full: all annotated findings + review queue.
        - client_safe: only high-confidence findings for automated client reports.
    `min_confidence` (default 0.85): threshold for client-safe findings.
    `strict_currency_position` (default False): if True, flags symbol-first ₪ prices as a style-guide review item.

    Returns: { findings: [{severity, category, title, hint, sample, selector, confidence, client_safe, evidence}], summary, review_queue, page }

    Use this for any Israeli SaaS, news site, e-commerce, or app.
    No tool in the market does this — it's the killer feature."""
    result = await qa_tools.qa_rtl_audit(
        mgr, session_id,
        ignore_patterns=ignore_patterns,
        ignore_selectors=ignore_selectors,
        detail=detail,
        smart_ignore=smart_ignore,
        report_mode=report_mode,
        min_confidence=min_confidence,
        strict_currency_position=strict_currency_position,
    )
    _publish_audit_findings("rtl_audit", result)
    return result


@mcp.tool()
async def qa_perf_metrics(session_id: str,
                          wait_for_lcp_ms: int = 2500,
                          thresholds: dict[str, dict[str, float]] | None = None,
                          detail: str = "samples",
                          ) -> dict[str, Any]:
    """Web Vitals + page timing. Grades TTFB/FCP/LCP/CLS against thresholds
    (default: Google's Core Web Vitals — good / needs_improvement / poor).

    Waits up to `wait_for_lcp_ms` for the page to settle so LCP fires —
    skipping this leaves LCP=null which makes the audit much less useful.

    `thresholds` (optional): override per-metric cutoffs.
        Example: {"lcp": {"good": 2000, "poor": 4000}}.
        Any omitted metric uses Core Web Vitals defaults.
    `detail` (optional): 'summary' | 'samples' (default) | 'full'.
        Perf rarely returns big lists, so all three are usually similar."""
    result = await qa_tools.qa_perf_metrics(
        mgr, session_id, wait_for_lcp_ms, thresholds, detail=detail,
    )
    score = result.get("score") or result.get("summary", {}).get("score")
    score_suffix = f" — score {score}" if score is not None else ""
    workspace.emit(
        "perf_metrics",
        f"Performance metrics completed{score_suffix}",
        {"score": score, "grades": result.get("grades"), "metrics": result.get("metrics")},
    )
    return result


@mcp.tool()
async def qa_scan_links(session_id: str,
                        detail: str = "samples") -> dict[str, Any]:
    """Inventory every <a>, <button>, [role=button] on the page with risk
    flags: empty href, target=_blank without noopener, button without label,
    disabled. Useful for 'audit all CTAs' tasks.

    `detail` (optional): 'summary' | 'samples' (default) | 'full'. Pages
        with hundreds of links produce huge output — prefer 'samples' unless
        you need every URL."""
    result = await qa_tools.qa_scan_links(mgr, session_id, detail=detail)
    flagged = [item for item in result.get("items", []) if item.get("flags")]
    workspace.emit(
        "scan_links",
        f"Scanned links: {len(flagged)} flagged item(s)",
        {"summary": result.get("summary"), "count": result.get("count")},
        level="warning" if flagged else "info",
    )
    for item in flagged[:8]:
        workspace.add_finding(
            title=f"Link issue: {', '.join(item.get('flags', []))}",
            severity="medium",
            description=item.get("text") or item.get("href") or "Clickable element has link risk flags.",
            selector=item.get("selector"),
            data={"source": "scan_links", "raw": item},
        )
    return result


@mcp.tool()
async def qa_asset_audit(session_id: str,
                         detail: str = "samples",
                         max_probe: int = 20) -> dict[str, Any]:
    """Audit images/assets that failed to load in the actual browser.

    Use when the live console shows empty image slots. It distinguishes a QA
    Console rendering issue from a real target-site/CDN issue such as
    Cloudflare returning `cf-mitigated: challenge` for image URLs.
    """
    result = await qa_tools.qa_asset_audit(mgr, session_id, detail=detail, max_probe=max_probe)
    workspace.emit(
        "asset_audit",
        f"Asset audit completed: {result.get('summary', {}).get('findings', 0)} finding(s)",
        {"summary": result.get("summary")},
        level="warning" if result.get("summary", {}).get("findings") else "info",
    )
    for item in result.get("findings", [])[:8]:
        workspace.add_finding(
            title=str(item.get("title") or "Asset issue"),
            severity=str(item.get("severity") or "medium"),
            description=str(item.get("description") or item.get("src") or "Asset failed to load"),
            selector=item.get("selector"),
            fix=item.get("fix"),
            data={"source": "asset_audit", "raw": item},
        )
    return result


@mcp.tool()
async def qa_design_quality_check(session_id: str,
                                   detail: str = "samples") -> dict[str, Any]:
    """🎨 AI-slop / generic-UI detector — rule-based, no LLM.

    Runs 11 anti-pattern checks drawn from the gstack design-review blacklist
    (purple gradients, 3-column feature grids, icons in colored circles,
    centered everything, uniform bubbly border-radius, emoji in headings,
    colored left-border cards, generic hero copy, system-ui as primary font,
    decorative blobs, cookie-cutter section rhythm).

    Returns a 0-100 score, A-F grade, and per-finding `positive_reference`
    pointing at how Linear / Stripe / Raycast / GitHub handle the same need —
    so the calling agent can propose a direction, not just flag the problem.

    Use this when:
      - User asks "does my site look AI-generated?"
      - Reviewing output from v0 / Lovable / bolt.new
      - Pre-launch design-quality gate in CI

    `detail` (optional): 'summary' | 'samples' (default) | 'full'.
    """
    return await qa_tools.qa_design_quality_check(mgr, session_id, detail=detail)


@mcp.tool()
async def qa_a11y_audit(session_id: str,
                        min_impact: str | None = None,
                        detail: str = "samples") -> dict[str, Any]:
    """Accessibility scan via axe-core (loaded from CDN). Returns WCAG 2 A/AA
    violations grouped by impact (critical, serious, moderate, minor).

    `min_impact` (optional): filter out violations below this level.
        Choices: 'minor' | 'moderate' | 'serious' | 'critical'.
        Use 'serious' to focus on what actually breaks users.
    `detail` (optional): 'summary' | 'samples' (default) | 'full'."""
    result = await qa_tools.qa_a11y_audit(
        mgr, session_id, min_impact=min_impact, detail=detail,
    )
    _publish_audit_findings("a11y_audit", result)
    return result


@mcp.tool()
async def qa_ux_metrics(session_id: str,
                        fold_height: int | None = None,
                        min_touch_px: int = 44,
                        detail: str = "samples",
                        persona: str = "general",
                        include_findings: bool = True) -> dict[str, Any]:
    """Deterministic UX measurements that feed persona-aware UX reasoning.

    Where a11y answers "is it correct for assistive tech?" and rtl_audit
    answers "is the Hebrew right?", this answers **"is it understandable
    at a glance?"** with raw numbers — no internal LLM judgment.

    Returns raw measurements:
    - typography: distinct_font_sizes, families, largest size, heading_to_body_ratio
    - color: distinct text/background colors (visual noise proxy)
    - interactive: total/in-fold counts, CTA candidates, dominant_cta_ratio
    - touch_targets: count + samples below min_touch_px (Apple HIG default 44)
    - kpi: large numerals visible above the fold (dashboard density)
    - density: chars_per_px2 in fold (wall-of-text vs breathable layout)
    - headings: counts per level, whether h1>h2>h3 by visible size

    Plus heuristic 0-100 scores: hierarchy_score, cognitive_load_score,
    density_score, touch_target_score. Treat scores as trend signals, not
    verdicts — calibrate against your own corpus before threshold gating.

    Also returns deterministic `findings` + `recommendations` when
    include_findings=True. Use `persona` to tune thresholds:
    general, conversion, mobile_first, business_owner, elderly_user, dashboard.

    `fold_height` (optional): override viewport fold in px. Useful for
        cross-device comparison (iphone-13 = 740, laptop = 600).
    `min_touch_px` (optional): minimum interactive box size before flagging.
        Default 44 (WCAG 2.5.5 / Apple HIG). Use 24 for dense desktop tools.
    `detail` (optional): 'summary' | 'samples' (default) | 'full'.

    Use this to answer agent questions like:
    - "Does this dashboard overload a non-analyst owner?" → kpi.candidates_in_fold,
      cognitive_load_score, distinct_font_sizes
    - "Is there one obvious next action?" → interactive.dominant_cta_ratio,
      single_cta_in_fold, hierarchy_score
    - "Will this work on mobile?" → touch_targets.small_count, run again with
      fold_height=740 after browser_set_viewport(device="iphone-13")
    - "Marketing page vs. product page feel?" → density.chars_per_px2,
      density_score, distinct_text_colors

    Combine with `browser_set_viewport` + re-run for mobile/desktop deltas."""
    return await qa_tools.qa_ux_metrics(
        mgr, session_id,
        fold_height=fold_height, min_touch_px=min_touch_px, detail=detail,
        persona=persona, include_findings=include_findings,
    )


@mcp.tool()
async def qa_conversion_audit(session_id: str,
                              detail: str = "samples") -> dict[str, Any]:
    """Business/revenue QA audit: finds conversion blockers such as missing
    or broken CTAs, no CTA above the fold, fragile lead forms, sticky overlays
    competing with actions, and missing trust signals.

    Use this when the client cares about lost leads/sales, not generic QA.
    `detail`: 'summary' | 'samples' (default) | 'full'."""
    return await qa_tools.qa_conversion_audit(mgr, session_id, detail=detail)


@mcp.tool()
async def qa_dev_check_url(url: str,
                           include_mobile: bool = True,
                           browser: str = "chrome",
                           output_dir: str | None = None,
                           max_issues: int = 8,
                           session_id: str | None = None) -> dict[str, Any]:
    """One-call developer QA check for work-in-progress apps.

    Designed for daily development, not a full audit. Opens `url`, checks the
    things that commonly break while building: page load, browser console/http
    errors, conversion/CTA blockers, forms, links, basic UX, desktop screenshot,
    and optional mobile screenshot + mobile conversion blockers.

    Returns a compact agent-friendly result:
      {status, top_issues, screenshots, summaries, raw_artifacts}
    so the AI agent can tell you exactly what to fix next without dumping every
    low-level audit output.
    """
    from pathlib import Path
    import re as _re
    from urllib.parse import urlparse

    max_issues = max(1, min(int(max_issues), 25))
    opened = await browser_tools.browser_open(mgr, url=url, headless=True, browser=browser)
    sid = opened["session_id"]

    out_dir: Path | None = None
    if output_dir:
        host = urlparse(opened.get("url") or url).netloc or "local"
        safe = _re.sub(r"[^\w\-]+", "-", host).strip("-") or "local"
        out_dir = Path(output_dir) / safe
        out_dir.mkdir(parents=True, exist_ok=True)

    def _issue(source: str, severity: str, title: str, impact: str,
               fix: str, evidence: Any = None, selector: str | None = None,
               device: str = "desktop") -> dict[str, Any]:
        return {
            "source": source,
            "severity": severity,
            "title": title,
            "impact": impact,
            "fix": fix,
            "evidence": evidence,
            "selector": selector,
            "device": device,
        }

    sev_rank = {"critical": 0, "high": 1, "serious": 1, "medium": 2, "moderate": 2, "low": 3, "minor": 3, "info": 4}

    try:
        await browser_tools.browser_wait_for(mgr, sid, network_idle=True, timeout_ms=8000)
        state = await browser_tools.browser_get_state(mgr, sid, text_snapshot_chars=1200, max_elements=40)
        logs = await browser_tools.browser_logs(mgr, sid)
        conversion = await qa_tools.qa_conversion_audit(mgr, sid, detail="full")
        forms = await qa_tools.qa_form_inventory(mgr, sid)
        links = await qa_tools.qa_scan_links(mgr, sid, detail="samples")
        ux = await qa_tools.qa_ux_metrics(mgr, sid, detail="samples", persona="conversion")
        screenshot = await browser_tools.browser_screenshot(
            mgr, sid, full_page=False,
            save_to=str(out_dir / "desktop.jpg") if out_dir else None,
        )

        issues: list[dict[str, Any]] = []
        for ev in logs.get("events", []) or []:
            if ev.get("level") == "error" or ev.get("kind") in ("http", "exception"):
                issues.append(_issue(
                    "logs", "high", f"Browser {ev.get('kind') or 'console'} error",
                    "Runtime/network errors can break user flows or hide failed integrations.",
                    "Open DevTools Console/Network, fix the failing request/script, then re-run qa_dev_check_url.",
                    ev.get("text"), None,
                ))
        for f in conversion.get("findings", []) or []:
            issues.append(_issue(
                "conversion", f.get("severity", "medium"), f.get("title") or "Conversion issue",
                f.get("impact") or "May reduce leads/signups/sales.",
                f.get("fix") or "Fix the conversion path and re-test.",
                f.get("evidence"), f.get("selector"), "desktop",
            ))
        for f in ux.get("findings", []) or []:
            issues.append(_issue(
                "ux", f.get("severity", "medium"), f.get("title") or "UX issue",
                f.get("impact") or "Users may struggle to complete the primary action.",
                f.get("fix") or "Simplify the page around the main task.",
                f.get("evidence") or f.get("samples"), f.get("selector"), "desktop",
            ))
        for it in links.get("items", []) or []:
            flags = it.get("flags") or []
            if flags:
                issues.append(_issue(
                    "links", "medium", f"Clickable element flagged: {', '.join(flags)}",
                    "Users may click a broken/unclear control.",
                    "Fix the href/label/disabled state and verify the click path.",
                    {"text": it.get("text"), "href": it.get("href"), "flags": flags}, it.get("selector"),
                ))

        mobile = None
        mobile_shot = None
        if include_mobile:
            await browser_tools.browser_set_viewport(mgr, sid, device="iphone-13")
            await browser_tools.browser_wait_for(mgr, sid, network_idle=True, timeout_ms=5000)
            mobile_conv = await qa_tools.qa_conversion_audit(mgr, sid, detail="full")
            mobile_shot = await browser_tools.browser_screenshot(
                mgr, sid, full_page=False,
                save_to=str(out_dir / "mobile.jpg") if out_dir else None,
            )
            for f in mobile_conv.get("findings", []) or []:
                issues.append(_issue(
                    "conversion", f.get("severity", "medium"), f.get("title") or "Mobile conversion issue",
                    f.get("impact") or "May reduce mobile leads/signups/sales.",
                    f.get("fix") or "Fix the mobile conversion path and re-test.",
                    f.get("evidence"), f.get("selector"), "mobile",
                ))
            mobile = {"conversion_summary": mobile_conv.get("summary"), "screenshot": mobile_shot.get("path")}

        # Deduplicate similar findings but keep desktop/mobile differences.
        deduped: list[dict[str, Any]] = []
        seen: set[tuple] = set()
        for item in sorted(issues, key=lambda x: (sev_rank.get(x.get("severity", "info"), 9), x.get("source", ""))):
            key = (item.get("device"), item.get("source"), item.get("title"), item.get("selector"), str(item.get("evidence"))[:160])
            if key not in seen:
                seen.add(key)
                deduped.append(item)

        top = deduped[:max_issues]
        status = "fail" if any(i.get("severity") in ("critical", "high", "serious") for i in top) else "pass"
        return {
            "ok": True,
            "status": status,
            "url": state.get("url") or opened.get("url") or url,
            "title": state.get("title"),
            "summary": {
                "issues_total": len(deduped),
                "top_issues_returned": len(top),
                "has_console_errors": any(i.get("source") == "logs" for i in deduped),
                "desktop_conversion": conversion.get("summary"),
                "forms_count": forms.get("forms_count"),
                "links_flagged": (links.get("summary") or {}).get("flagged"),
            },
            "top_issues": top,
            "screenshots": {
                "desktop": screenshot.get("path"),
                "mobile": (mobile_shot or {}).get("path"),
            },
            "suggested_next_actions": [
                "Fix critical/high issues first, then re-run qa_dev_check_url.",
                "Use selectors from top_issues to jump directly to the broken UI.",
                "Open screenshots to verify desktop/mobile visual state.",
            ],
            "raw_artifacts": {
                "opened": opened,
                "logs_count": logs.get("count"),
                "form_inventory": forms,
                "desktop_state_sample": {"viewport": state.get("viewport"), "text_snapshot": state.get("text_snapshot")},
                "mobile": mobile,
            },
        }
    finally:
        await browser_tools.browser_close(mgr, sid)


def _qa_expand_env(value: Any) -> Any:
    """Recursively expand "$ENV_VAR" strings in QA configs."""
    import os as _os
    if isinstance(value, str) and value.startswith("$") and len(value) > 1:
        return _os.getenv(value[1:], value)
    if isinstance(value, list):
        return [_qa_expand_env(v) for v in value]
    if isinstance(value, dict):
        return {k: _qa_expand_env(v) for k, v in value.items()}
    return value


def _qa_dangerous_step(step: dict[str, Any]) -> str | None:
    import re as _re
    action = str(step.get("action") or "")
    blob = " ".join(str(step.get(k) or "") for k in ("text", "selector", "query", "pattern"))
    dangerous = _re.compile(r"delete|remove|destroy|drop|truncate|pay|charge|purchase|publish|send|invite|cancel|refund|מחק|שלם|פרסם|שלח|בטל|החזר", _re.I)
    if action in ("click", "click_text", "click_selector", "type", "type_selector") and dangerous.search(blob):
        return f"dangerous step blocked by safe_mode: {action} {blob}"[:240]
    return None


def _qa_validate_config_obj(config: dict[str, Any]) -> dict[str, Any]:
    issues: list[dict[str, Any]] = []
    warnings: list[dict[str, Any]] = []
    if not isinstance(config, dict):
        issues.append({"severity": "critical", "message": "Config must be a JSON object"})
        return {"ok": False, "issues": issues, "warnings": warnings}
    if not (config.get("base_url") or config.get("url") or config.get("pages") or config.get("flows")):
        issues.append({"severity": "high", "message": "Config needs base_url/url or explicit pages/flows"})
    for i, p in enumerate(config.get("pages") or []):
        if not (p.get("url") or p.get("path")):
            issues.append({"severity": "high", "message": f"pages[{i}] missing url/path"})
    for i, f in enumerate(config.get("flows") or []):
        if not (f.get("url") or f.get("path") or config.get("base_url")):
            issues.append({"severity": "high", "message": f"flows[{i}] missing url/path and no base_url"})
        steps = f.get("steps") or []
        if not steps:
            warnings.append({"severity": "medium", "message": f"flows[{i}] has no steps"})
        for j, step in enumerate(steps):
            if not step.get("action"):
                issues.append({"severity": "high", "message": f"flows[{i}].steps[{j}] missing action"})
            danger = _qa_dangerous_step(step)
            if danger:
                warnings.append({"severity": "medium", "message": f"flows[{i}].steps[{j}] {danger}"})
            for key in ("text", "selector"):
                val = step.get(key)
                if isinstance(val, str) and val.startswith("$"):
                    import os as _os
                    if _os.getenv(val[1:]) is None:
                        issues.append({"severity": "high", "message": f"flows[{i}].steps[{j}] references missing env var {val}"})
    return {"ok": not issues, "issues": issues, "warnings": warnings, "summary": {"pages": len(config.get("pages") or []), "flows": len(config.get("flows") or []), "visual_baselines": len(config.get("visual_baselines") or [])}}


@mcp.tool()
def qa_validate_config(config: dict | None = None,
                       config_path: str | None = None,
                       session_id: str | None = None) -> dict[str, Any]:
    """Validate qa.project.json before running it. Checks required fields,
    missing env vars like $QA_PASSWORD, empty flows, and dangerous actions that
    safe_mode would block. `session_id` is ignored for Pi compatibility."""
    import json as _json
    from pathlib import Path
    if config_path:
        config = _json.loads(Path(config_path).expanduser().read_text(encoding="utf-8"))
    if config is None:
        return {"ok": False, "issues": [{"severity": "critical", "message": "Provide config or config_path"}], "warnings": []}
    return _qa_validate_config_obj(config)


@mcp.tool()
async def qa_auto_plan_project(url: str,
                               name: str = "auto-qa-project",
                               max_pages: int = 8,
                               output_path: str | None = None,
                               browser: str = "chrome",
                               session_id: str | None = None) -> dict[str, Any]:
    """Autonomously discover important pages/actions/forms and generate a
    starter qa.project.json. Safe by design: it does not submit forms or click
    destructive/payment/publish actions; it only plans suggested flows.
    """
    from pathlib import Path
    from urllib.parse import urljoin, urlparse
    import json as _json
    import re as _re

    max_pages = max(1, min(int(max_pages), 20))
    dangerous_re = _re.compile(r"delete|remove|destroy|pay|charge|purchase|publish|send|invite|cancel|מחק|שלם|פרסם|שלח|בטל", _re.I)
    important_re = _re.compile(r"login|sign|dashboard|admin|customer|user|client|contact|settings|payment|report|checkout|order|profile|account|pricing|לוגין|התחבר|לקוחות|דוחות|הגדרות|תשלום", _re.I)

    opened = await browser_tools.browser_open(mgr, url=url, headless=True, browser=browser)
    sid = opened["session_id"]
    try:
        await browser_tools.browser_wait_for(mgr, sid, network_idle=True, timeout_ms=8000)
        state = await browser_tools.browser_get_state(mgr, sid, text_snapshot_chars=2000, max_elements=80)
        forms = await qa_tools.qa_form_inventory(mgr, sid)
        links = await qa_tools.qa_scan_links(mgr, sid, detail="full")
        base = state.get("url") or opened.get("url") or url
        host = urlparse(base).netloc

        discovered: list[dict[str, Any]] = []
        seen = set()
        for it in (links.get("items") or []):
            href = it.get("resolved_href") or it.get("href")
            text = it.get("text") or ""
            if not href:
                continue
            abs_url = urljoin(base, href).split("#")[0] + (("#" + href.split("#",1)[1]) if "#" in href and href.startswith("#") else "")
            if urlparse(abs_url).netloc and urlparse(abs_url).netloc != host:
                continue
            signal = f"{text} {urlparse(abs_url).path} {urlparse(abs_url).fragment}"
            if abs_url not in seen and (important_re.search(signal) or len(discovered) < 3):
                seen.add(abs_url)
                discovered.append({"name": _re.sub(r"[^\w\-]+", "-", (text or urlparse(abs_url).path or "page")).strip("-")[:40] or "page", "url": abs_url, "text": text[:80]})
            if len(discovered) >= max_pages:
                break

        actions = []
        for e in state.get("elements", []):
            label = (e.get("text") or e.get("placeholder") or e.get("name") or e.get("id") or "").strip()
            if e.get("tag") in ("button", "a", "input") and label:
                actions.append({"label": label[:80], "index": e.get("index"), "tag": e.get("tag"), "href": e.get("href"), "risk": "dangerous" if dangerous_re.search(label + " " + str(e.get("href") or "")) else "safe"})

        flows = []
        form_fields = (forms.get("inventory") or []) + ([{"fields": forms.get("orphan_fields", []), "submit_text": None}] if forms.get("orphan_fields") else [])
        login_fields = []
        for inv in form_fields:
            fields = inv.get("fields") or []
            blob = " ".join(str(f.get(k) or "") for f in fields for k in ("type","name","label","placeholder","purpose")).lower()
            if "password" in blob or "email" in blob:
                login_fields = fields
                break
        if login_fields:
            def _field_selector(f: dict[str, Any], fallback: str) -> str:
                return f.get("selector") or (f"#{f.get('id')}" if f.get("id") else None) or (f"[name='{f.get('name')}']" if f.get("name") else None) or fallback
            email_field = next((f for f in login_fields if "email" in str(f).lower()), {})
            pass_field = next((f for f in login_fields if "password" in str(f).lower() or f.get("type") == "password"), {})
            email_sel = _field_selector(email_field, "#email")
            pass_sel = _field_selector(pass_field, "#password")
            steps = [{"action":"type_selector","selector":email_sel,"text":"qa@example.com"},{"action":"type_selector","selector":pass_sel,"text":"secret"}]
            # Prefer form submit selector over text matching: pages often have
            # nav links named "Login" before the actual login button.
            steps.append({"action":"click_selector","selector":"button[type=submit], input[type=submit], #loginBtn"})
            steps.append({"action":"logs"})
            flows.append({"name":"login smoke", "url": base, "steps": steps, "needs_credentials": True})

        for inv in form_fields:
            fields = inv.get("fields") or []
            if not fields:
                continue
            blob = " ".join(str(f.get(k) or "") for f in fields for k in ("type","name","label","placeholder","purpose")).lower()
            if "password" in blob:
                continue
            steps = []
            for f in fields[:6]:
                sel = f.get("selector") or (f"#{f.get('id')}" if f.get("id") else None) or (f"[name='{f.get('name')}']" if f.get("name") else None)
                if not sel:
                    continue
                purpose = str(f.get("purpose") or f.get("type") or f.get("name") or "").lower()
                val = "david@example.com" if "email" in purpose else "0501234567" if "phone" in purpose or "tel" in purpose else "David QA"
                steps.append({"action":"type_selector","selector":sel,"text":val})
            submit_text = inv.get("submit_text") or "Save"
            if steps:
                steps += [{"action":"click_text","text":submit_text},{"action":"logs"}]
                flows.append({"name":"form smoke", "url": base, "steps": steps})
                break

        qa_config = {"name": name, "base_url": base, "include_mobile": True, "max_issues": 8, "retries": 1, "auto_create_baselines": True, "pages": [{"name": p["name"], "url": p["url"]} for p in discovered] or [{"name":"home","url":base}], "flows": flows, "visual_baselines": [{"name":"home", "url": base, "tolerance_pct": 0.5, "full_page": True}]}
        result = {"ok": True, "url": base, "discovered_pages": discovered, "forms": forms, "safe_actions": [a for a in actions if a["risk"] == "safe"][:30], "dangerous_actions": [a for a in actions if a["risk"] == "dangerous"][:20], "suggested_flows": flows, "qa_project_json": qa_config}
        if output_path:
            p = Path(output_path); p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(_json.dumps(qa_config, indent=2, ensure_ascii=False), encoding="utf-8")
            result["output_path"] = str(p)
        return result
    finally:
        await browser_tools.browser_close(mgr, sid)


@mcp.tool()
async def qa_auto_check_project(url: str,
                                name: str = "auto-qa-project",
                                output_dir: str | None = None,
                                browser: str = "chrome",
                                session_id: str | None = None) -> dict[str, Any]:
    """Autonomous safe QA: plan project from URL, run page checks + safe generated
    flows, and return a pre-deploy-style result. Does not run dangerous actions.
    """
    plan = await qa_auto_plan_project(url=url, name=name, browser=browser)
    check = await qa_project_check(config=plan["qa_project_json"], output_dir=output_dir, browser=browser)
    return {"ok": True, "plan": {"pages": len(plan.get("discovered_pages", [])), "flows": len(plan.get("suggested_flows", [])), "dangerous_actions": plan.get("dangerous_actions", [])}, "check": check, "status": check.get("status")}


@mcp.tool()
def qa_project_init(project_path: str,
                    name: str = "my-app",
                    base_url: str = "http://localhost:3000",
                    session_id: str | None = None) -> dict[str, Any]:
    """Initialize a repo with QA-department structure and starter config.

    `session_id` is accepted for Pi/bridge auto-injection and ignored.

    Creates:
      qa.project.json
      qa/flows/
      qa/data/
      qa/baselines/
      qa/results/
    """
    import json as _json
    from pathlib import Path
    root = Path(project_path).expanduser()
    root.mkdir(parents=True, exist_ok=True)
    for rel in ("qa/flows", "qa/data", "qa/baselines", "qa/results"):
        (root / rel).mkdir(parents=True, exist_ok=True)
    cfg_path = root / "qa.project.json"
    if not cfg_path.exists():
        cfg = {
            "name": name,
            "base_url": base_url,
            "include_mobile": True,
            "max_issues": 8,
            "retries": 1,
            "pages": [
                {"name": "home", "path": "/"},
                {"name": "login", "path": "/login"},
                {"name": "dashboard", "path": "/dashboard"}
            ],
            "flows": [
                {
                    "name": "login works",
                    "path": "/login",
                    "steps": [
                        {"action": "type_selector", "selector": "#email", "text": "qa@example.com"},
                        {"action": "type_selector", "selector": "#password", "text": "secret"},
                        {"action": "click_text", "text": "Login"},
                        {"action": "assert_url", "pattern": "dashboard"}
                    ]
                }
            ],
            "visual_baselines": []
        }
        cfg_path.write_text(_json.dumps(cfg, indent=2, ensure_ascii=False), encoding="utf-8")
    readme = root / "qa" / "README.md"
    if not readme.exists():
        readme.write_text("# QA\n\nRun `qa_project_check_file` with `qa.project.json` before deploy.\n", encoding="utf-8")
    return {"ok": True, "project_path": str(root), "config_path": str(cfg_path), "created_dirs": ["qa/flows", "qa/data", "qa/baselines", "qa/results"]}


@mcp.tool()
async def qa_pre_deploy_check(config_path: str,
                              output_dir: str | None = None,
                              browser: str = "chrome",
                              retries: int | None = None,
                              create_github_issues: bool = False,
                              github_repo: str | None = None,
                              session_id: str | None = None) -> dict[str, Any]:
    """Pre-deploy QA gate for complex apps.

    Runs qa_project_check_file, retries failures once by default to classify
    flaky vs real failures, optionally creates GitHub issues, and returns a
    deployment gate verdict. `session_id` is accepted for Pi auto-injection.
    """
    import json as _json
    from pathlib import Path
    path = Path(config_path).expanduser()
    cfg = _qa_expand_env(_json.loads(path.read_text(encoding="utf-8")))
    validation = _qa_validate_config_obj(cfg)
    if not validation.get("ok"):
        return {"ok": False, "gate": "fail", "deploy_allowed": False, "config_path": str(path), "validation": validation}
    retry_count = int(cfg.get("retries", 1) if retries is None else retries)
    out = output_dir or str(path.parent / "qa" / "results" / "pre-deploy")

    first = await qa_project_check(config=cfg, output_dir=out, browser=browser)
    attempts = [first]
    flaky: list[dict[str, Any]] = []
    final = first
    if first.get("status") != "pass" and retry_count > 0:
        for _ in range(retry_count):
            again = await qa_project_check(config=cfg, output_dir=out, browser=browser)
            attempts.append(again)
            if again.get("status") == "pass":
                flaky = first.get("failures", [])
                final = again
                break
            final = again

    # Visual regression gate (optional):
    # config.visual_baselines = [{"name":"home", "path":"/", "tolerance_pct":0.5}]
    from urllib.parse import urljoin
    visual_results: list[dict[str, Any]] = []
    visual_failures: list[dict[str, Any]] = []
    baselines_dir = str(path.parent / "qa" / "baselines")
    auto_create_baselines = bool(cfg.get("auto_create_baselines", True))
    base_url = str(cfg.get("base_url") or cfg.get("url") or "")

    def _resolve_visual(item: dict[str, Any]) -> str:
        raw = str(item.get("url") or item.get("path") or "/")
        if raw.startswith(("http://", "https://", "file://")):
            return raw
        return urljoin(base_url.rstrip("/") + "/", raw.lstrip("/")) if base_url else raw

    for item in cfg.get("visual_baselines") or []:
        v_name = str(item.get("name") or item.get("path") or item.get("url") or "visual")
        v_url = _resolve_visual(item)
        sid = None
        try:
            opened = await browser_tools.browser_open(mgr, url=v_url, headless=True, browser=str(item.get("browser") or browser))
            sid = opened["session_id"]
            if item.get("wait_text"):
                await browser_tools.browser_wait_for(mgr, sid, text=str(item["wait_text"]), timeout_ms=int(item.get("timeout_ms", 10000)))
            cmp = await qa_tools.qa_baseline_compare(
                mgr, sid, name=v_name,
                full_page=bool(item.get("full_page", True)),
                tolerance_pct=float(item.get("tolerance_pct", cfg.get("visual_tolerance_pct", 0.5))),
                baselines_dir=baselines_dir,
            )
            if cmp.get("ok") is False and "not found" in str(cmp.get("error", "")).lower() and auto_create_baselines:
                saved = await qa_tools.qa_baseline_save(mgr, sid, name=v_name, full_page=bool(item.get("full_page", True)), baselines_dir=baselines_dir)
                cmp = {"ok": True, "passed": True, "created_baseline": True, "baseline": saved}
            passed = bool(cmp.get("passed", cmp.get("ok", False)))
            rec = {"name": v_name, "url": v_url, "status": "pass" if passed else "fail", "result": cmp}
            visual_results.append(rec)
            if not passed:
                visual_failures.append({"type": "visual", "name": v_name, "status": "fail", "result": cmp})
        except Exception as e:
            rec = {"name": v_name, "url": v_url, "status": "error", "error": f"{type(e).__name__}: {e}"}
            visual_results.append(rec)
            visual_failures.append({"type": "visual", "name": v_name, "status": "error", "error": rec["error"]})
        finally:
            if sid:
                await browser_tools.browser_close(mgr, sid)

    coverage = {
        "pages_defined": len(cfg.get("pages") or []),
        "flows_defined": len(cfg.get("flows") or []),
        "visual_baselines_defined": len(cfg.get("visual_baselines") or []),
        "critical_pages_checked": len(final.get("page_results") or []),
        "critical_flows_checked": len(final.get("flow_results") or []),
        "visual_baselines_checked": len(visual_results),
        "has_pre_deploy_gate": True,
        "has_retries": retry_count > 0,
    }

    gate = "pass" if final.get("status") == "pass" and not visual_failures else "fail"
    issue_result = None
    if create_github_issues and github_repo and final.get("result_json"):
        try:
            issue_result = qa_github_create_issues(final["result_json"], github_repo, dry_run=False)
        except Exception as e:
            issue_result = {"ok": False, "error": f"{type(e).__name__}: {e}"}

    result = {
        "ok": True,
        "gate": gate,
        "status": final.get("status"),
        "config_path": str(path),
        "attempts": len(attempts),
        "flaky_failures": flaky,
        "final_summary": final.get("summary"),
        "final_failures": (final.get("failures", []) or []) + visual_failures,
        "visual_results": visual_results,
        "coverage": coverage,
        "result_json": final.get("result_json"),
        "artifacts_dir": final.get("artifacts_dir"),
        "github_issues": issue_result,
        "deploy_allowed": gate == "pass",
    }
    return result


@mcp.tool()
async def qa_project_check_file(config_path: str,
                                output_dir: str | None = None,
                                browser: str = "chrome",
                                session_id: str | None = None) -> dict[str, Any]:
    """Run qa_project_check from a JSON config file.

    This is the practical pre-deploy entry point for complex apps: keep a
    `qa.project.json` in each repo, then ask the agent to run it. `session_id`
    is accepted for Pi/bridge auto-injection and ignored.
    """
    import json as _json
    from pathlib import Path
    path = Path(config_path).expanduser()
    config = _qa_expand_env(_json.loads(path.read_text(encoding="utf-8")))
    validation = _qa_validate_config_obj(config)
    if not validation.get("ok"):
        return {"ok": False, "status": "fail", "config_path": str(path), "validation": validation}
    if output_dir is None:
        output_dir = str(path.parent / "qa-results")
    return await qa_project_check(config=config, output_dir=output_dir, browser=browser)


@mcp.tool()
async def qa_project_check(config: dict,
                           output_dir: str | None = None,
                           browser: str = "chrome",
                           session_id: str | None = None) -> dict[str, Any]:
    """One-call QA for complex apps: run dev checks on key pages plus
    explicit user flows.

    Config shape:
      {
        "name": "my-app",
        "base_url": "http://localhost:3000",
        "pages": [{"name":"dashboard", "path":"/dashboard"}],
        "flows": [{"name":"login", "url":"http://.../login", "steps":[
          {"action":"type_selector", "selector":"#email", "text":"test@example.com"},
          {"action":"click_text", "text":"Login"},
          {"action":"assert_url", "pattern":"dashboard"}
        ]}]
      }

    Page checks use qa_dev_check_url. Flows use qa_flow_runner and add logs +
    screenshot on failure. Returns compact pass/fail summary for an AI agent.
    `session_id` is accepted for Pi/bridge auto-injection and ignored.
    """
    from pathlib import Path
    from urllib.parse import urljoin
    import re as _re
    import time as _time
    import json as _json

    config = _qa_expand_env(config)
    validation = _qa_validate_config_obj(config)
    if not validation.get("ok"):
        return {"ok": False, "status": "fail", "validation": validation}
    name = str(config.get("name") or "qa-project")
    safe_mode = bool(config.get("safe_mode", True))
    base_url = str(config.get("base_url") or config.get("url") or "")
    pages = config.get("pages") or []
    flows = config.get("flows") or []
    include_mobile = bool(config.get("include_mobile", True))
    max_issues = int(config.get("max_issues", 6))

    out_dir: Path | None = None
    if output_dir:
        safe = _re.sub(r"[^\w\-]+", "-", name).strip("-") or "qa-project"
        out_dir = Path(output_dir) / safe
        out_dir.mkdir(parents=True, exist_ok=True)

    def resolve(item: dict) -> str:
        raw = item.get("url") or item.get("path") or "/"
        raw = str(raw)
        if raw.startswith(("http://", "https://", "file://")):
            return raw
        if not base_url:
            return raw
        return urljoin(base_url.rstrip("/") + "/", raw.lstrip("/"))

    page_results: list[dict[str, Any]] = []
    for p in pages:
        p_name = str(p.get("name") or p.get("path") or p.get("url") or "page")
        p_url = resolve(p)
        try:
            res = await qa_dev_check_url(
                url=p_url,
                include_mobile=bool(p.get("include_mobile", include_mobile)),
                browser=str(p.get("browser") or browser),
                output_dir=str(out_dir / "pages" / _re.sub(r"[^\w\-]+", "-", p_name)) if out_dir else None,
                max_issues=int(p.get("max_issues", max_issues)),
            )
            page_results.append({"name": p_name, "url": p_url, "status": res.get("status"), "top_issues": res.get("top_issues", []), "screenshots": res.get("screenshots"), "summary": res.get("summary")})
        except Exception as e:
            page_results.append({"name": p_name, "url": p_url, "status": "error", "error": f"{type(e).__name__}: {e}"})

    flow_results: list[dict[str, Any]] = []
    for f in flows:
        f_name = str(f.get("name") or "flow")
        f_url = resolve(f)
        opened = None
        sid = None
        try:
            blocked = []
            if safe_mode:
                for idx, step in enumerate(f.get("steps") or [], 1):
                    danger = _qa_dangerous_step(step)
                    if danger:
                        blocked.append({"step": idx, "reason": danger, "step_input": step})
            if blocked:
                flow_results.append({"name": f_name, "url": f_url, "status": "blocked", "flow_ok": False, "failed_step": blocked[0]["step"], "error": blocked[0]["reason"], "blocked_steps": blocked, "log_errors": [], "steps": []})
                continue
            opened = await browser_tools.browser_open(mgr, url=f_url, headless=True, browser=str(f.get("browser") or browser))
            sid = opened["session_id"]
            if f.get("wait_text"):
                await browser_tools.browser_wait_for(mgr, sid, text=str(f["wait_text"]), timeout_ms=int(f.get("timeout_ms", 10000)))
            run = await qa_tools.qa_flow_runner(mgr, sid, f.get("steps") or [], stop_on_error=bool(f.get("stop_on_error", True)))
            logs = await browser_tools.browser_logs(mgr, sid)
            safe_flow_name = _re.sub(r"[^\w-]+", "-", f_name)
            shot = await browser_tools.browser_screenshot(
                mgr, sid, full_page=False,
                save_to=str(out_dir / "flows" / f"{safe_flow_name}.jpg") if out_dir else None,
            )
            log_errors = [ev for ev in logs.get("events", []) if ev.get("level") == "error" or ev.get("kind") in ("http", "exception")]
            status = "pass" if run.get("ok") and not log_errors else "fail"
            flow_results.append({"name": f_name, "url": f_url, "status": status, "flow_ok": run.get("ok"), "failed_step": run.get("failed_step"), "error": run.get("error"), "log_errors": log_errors[:5], "screenshot": shot.get("path"), "steps": run.get("steps", [])})
        except Exception as e:
            flow_results.append({"name": f_name, "url": f_url, "status": "error", "error": f"{type(e).__name__}: {e}"})
        finally:
            if sid:
                await browser_tools.browser_close(mgr, sid)

    failures = []
    for p in page_results:
        if p.get("status") != "pass":
            failures.append({"type": "page", "name": p.get("name"), "status": p.get("status"), "top_issue": (p.get("top_issues") or [{}])[0] if p.get("top_issues") else p.get("error")})
    for f in flow_results:
        if f.get("status") != "pass":
            failures.append({"type": "flow", "name": f.get("name"), "status": f.get("status"), "error": f.get("error"), "failed_step": f.get("failed_step"), "log_errors": f.get("log_errors")})

    result = {
        "ok": True,
        "status": "fail" if failures else "pass",
        "name": name,
        "summary": {"pages": len(page_results), "flows": len(flow_results), "failures": len(failures), "pages_failed": sum(1 for p in page_results if p.get("status") != "pass"), "flows_failed": sum(1 for f in flow_results if f.get("status") != "pass")},
        "failures": failures[:20],
        "page_results": page_results,
        "flow_results": flow_results,
        "suggested_next_actions": ["Fix failures in order: broken flows first, then critical/high page issues.", "Re-run qa_project_check after each fix to confirm regression is gone.", "Promote stable flows into config and run before deploy."],
        "artifacts_dir": str(out_dir) if out_dir else None,
    }
    if out_dir:
        path = out_dir / f"project-check-{int(_time.time())}.json"
        path.write_text(_json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
        result["result_json"] = str(path)
    return result


@mcp.tool()
async def qa_ux_audit_url(url: str,
                          persona: str = "general",
                          include_mobile: bool = True,
                          include_rtl: bool = True,
                          include_a11y: bool = True,
                          include_perf: bool = True,
                          include_evidence: bool = True,
                          browser: str = "chrome",
                          headless: bool = True) -> dict[str, Any]:
    """High-level UX audit for a URL.

    Runs UX metrics, deterministic UX findings/recommendations,
    interaction scan with deduped animations/transitions, link scan,
    optional RTL/a11y/perf checks, desktop-vs-mobile comparison, and evidence
    screenshots with highlighted UX selectors.

    `persona`: general | conversion | mobile_first | business_owner |
    elderly_user | dashboard. Use conversion for landing pages, dashboard for
    dense products, elderly_user for government/health/public-service flows.
    """
    return await qa_tools.qa_ux_audit_url(
        mgr, url=url, persona=persona, include_mobile=include_mobile,
        include_rtl=include_rtl, include_a11y=include_a11y,
        include_perf=include_perf, include_evidence=include_evidence,
        browser=browser, headless=headless,
    )


@mcp.tool()
async def qa_fuzz_input(session_id: str, index: int,
                        depth: str = "quick") -> dict[str, Any]:
    """Hammer an input field with edge-case strings:
    - quick (5 inputs): invalid format, empty, whitespace, very long, emoji
    - thorough (12 inputs): adds Hebrew-in-email, SQL-ish, XSS, control chars,
      zero-width, RTL mark, mega-long, newlines

    For each input: clears, types, observes the field's accepted value and
    validity state. Returns per-input results + any browser events (HTTP
    errors, JS exceptions) fired during the fuzz."""
    return await qa_tools.qa_fuzz_input(mgr, session_id, index, depth)


@mcp.tool()
async def qa_baseline_save(session_id: str, name: str,
                           full_page: bool = True,
                           baselines_dir: str | None = None) -> dict[str, Any]:
    """Save the current page as a named visual baseline. Default storage:
    ~/.qa-mcp/baselines/<name>.png. Override with `baselines_dir` (e.g. a
    shared CI mount, per-PR folder) or QA_MCP_BASELINE_DIR env."""
    return await qa_tools.qa_baseline_save(
        mgr, session_id, name, full_page, baselines_dir=baselines_dir,
    )


@mcp.tool()
async def qa_baseline_compare(session_id: str, name: str,
                              full_page: bool = True,
                              tolerance_pct: float = 0.5,
                              baselines_dir: str | None = None) -> dict[str, Any]:
    """Compare current page to a saved baseline. Returns % of pixels changed,
    bounding box of changes, and paths to baseline / current / diff images.

    `passed` is True if pct_changed <= tolerance_pct. Use for visual
    regression in CI: save baseline on main → compare on every PR.

    `baselines_dir` must match the path used in qa_baseline_save."""
    return await qa_tools.qa_baseline_compare(
        mgr, session_id, name, full_page, tolerance_pct,
        baselines_dir=baselines_dir,
    )


@mcp.tool()
async def qa_baseline_list(baselines_dir: str | None = None) -> dict[str, Any]:
    """List all saved baselines (name, path, size, last modified).
    Pass `baselines_dir` to list a non-default folder."""
    return qa_tools.qa_baseline_list(baselines_dir=baselines_dir)


@mcp.tool()
async def qa_seo_check(session_id: str,
                       detail: str = "samples") -> dict[str, Any]:
    """SEO health check: meta tags, Open Graph, Twitter card, JSON-LD
    schema, heading hierarchy (h1-h6 counts), alt-text coverage, canonical,
    robots, lang. Returns structured data + a flat `issues` array with
    severities for quick triage.

    `detail` (optional): 'summary' | 'samples' (default) | 'full'."""
    result = await qa_tools.qa_seo_check(mgr, session_id, detail=detail)
    issues = result.get("issues", [])
    workspace.emit(
        "seo_check",
        f"SEO check completed: {len(issues)} issue(s)",
        {"summary": result.get("summary")},
        level="warning" if issues else "info",
    )
    for item in issues[:8]:
        message = item.get("msg") or item.get("message") or item.get("title") or "SEO issue"
        workspace.add_finding(
            title=message,
            severity=item.get("severity", "medium"),
            description=item.get("hint") or message,
            data={"source": "seo_check", "raw": item},
        )
    return result


@mcp.tool()
async def qa_responsive_audit(session_id: str,
                              breakpoints: list[int] | None = None,
                              audits: list[str] | None = None) -> dict[str, Any]:
    """Run audits at multiple viewport widths in one call. Saves 3 manual
    runs of resize → audit. Returns per-breakpoint results plus `deltas`
    (findings unique to each width — typically RTL/a11y bugs that show
    only on mobile).

    breakpoints: defaults to [375, 768, 1366] (mobile/tablet/desktop).
    audits: any of ["rtl", "a11y", "perf", "seo", "links", "ux", "conversion"]. Default ["rtl", "a11y"]."""
    return await qa_tools.qa_responsive_audit(
        mgr, session_id, breakpoints=breakpoints, audits=audits,
    )


@mcp.tool()
async def qa_form_smart_fill(session_id: str, intent: str = "valid_signup",
                             submit: bool = False) -> dict[str, Any]:
    """Auto-detect form fields by name/placeholder/type and fill them with
    synthetic data matched to `intent`:

    - valid_signup: realistic plausible values
    - invalid_email: bad email + valid password
    - very_long: 200-char strings everywhere
    - empty: blank everything
    - hebrew: Hebrew name/email/etc.

    Optionally clicks a submit-like button afterwards. Returns which fields
    were filled, which were skipped, and the submit result."""
    result = await qa_tools.qa_form_smart_fill(mgr, session_id, intent, submit)
    workspace.emit(
        "form_smart_fill",
        f"Smart-filled form with intent '{intent}'{'; submitted' if submit else ''}",
        {"session_id": session_id, "intent": intent, "submit": submit, "ok": result.get("ok")},
        level="info" if result.get("ok", True) else "error",
    )
    return result


@mcp.tool()
async def qa_run_suite(config: dict, write_html_to: str | None = None,
                       write_junit_to: str | None = None,
                       write_markdown_to: str | None = None,
                       write_issues_to: str | None = None) -> dict[str, Any]:
    """Run a full QA suite from a config dict and emit reports.

    Config shape (same as qa.config.json — see project README):
      { "name", "base_url", "browser", "scenarios": [
          {"name", "path", "audits": ["rtl","a11y","perf","seo"], "thresholds": {...}}
      ] }

    Returns the full suite results dict (also writes HTML/JUnit if paths given).
    """
    from . import suite as _suite
    result = await _suite.run_suite(config)
    if write_html_to:
        _suite.emit_html_report(result, write_html_to)
        result["html_report_path"] = write_html_to
    if write_junit_to:
        _suite.emit_junit_xml(result, write_junit_to)
        result["junit_path"] = write_junit_to
    if write_markdown_to:
        _suite.emit_markdown_report(result, write_markdown_to)
        result["markdown_report_path"] = write_markdown_to
    if write_issues_to:
        result["issues_export"] = _suite.emit_issue_files(result, write_issues_to)
    return result


# ---------- discovery helpers ----------


@mcp.tool()
async def qa_find_text(session_id: str, query: str,
                       fuzzy: bool = True, max_results: int = 10,
                       case_sensitive: bool = False) -> dict[str, Any]:
    """Find DOM elements containing `query` text. Returns matches with stable
    `index` values you can pass straight to browser_click / browser_type /
    browser_scroll_to — no need to call browser_get_state first.

    `fuzzy` (default True): if `query` has multiple tokens, an element matches
        when ALL tokens appear in any order ("submit form" matches "Submit
        the form"). Substring match still wins first.
    `max_results` (default 10): cap matches.
    `case_sensitive` (default False).

    Returns: { query, matches: [{index, tag, text, href, visible, bbox}],
               total_found }.

    Use this instead of browser_evaluate('document.querySelector...') when
    you know the visible label of what you want to click."""
    return await qa_tools.qa_find_text(
        mgr, session_id, query, fuzzy=fuzzy,
        max_results=max_results, case_sensitive=case_sensitive,
    )


@mcp.tool()
async def qa_form_inventory(session_id: str) -> dict[str, Any]:
    """List every form on the page with its fields, types, labels, and a
    guessed semantic `purpose` (email/password/phone/credit_card/...).

    Run this BEFORE qa_form_smart_fill so you can see what's there and pick
    the right `intent`. Also surfaces `orphan_fields` — inputs that aren't
    inside any <form> tag, which is common in React/SPA forms and would
    otherwise be missed by form-scoped scans.

    Returns: { forms_count, fields_in_forms, orphan_fields_count,
               inventory: [{form_index, action, method, field_count,
                            submit_index, fields: [{index, type, label,
                                                    required, purpose}]}],
               orphan_fields: [...] }."""
    return await qa_tools.qa_form_inventory(mgr, session_id)


# ---------- training-data tools ----------


@mcp.tool()
def qa_training_stats(data_dir: str | None = None) -> dict[str, Any]:
    """Summarize the captured training corpus.

    Each call to a qa_* audit (rtl, perf, seo, links, a11y) is auto-captured
    when QA_MCP_TRAINING_DATA_DIR is set. This tool reports on what's there.

    `data_dir` (optional): override the env var path.

    Returns: { runs, unique_hosts, by_task, by_lang, avg_html_bytes,
               total_html_mb, total_findings, ready_for_training }.

    `ready_for_training` is True at >=100 runs (heuristic for distillation
    fine-tunes of small models like Gemma 4 E2B)."""
    import os as _os
    target = data_dir or _os.getenv("QA_MCP_TRAINING_DATA_DIR")
    if not target:
        return {"error": "No data_dir given and QA_MCP_TRAINING_DATA_DIR is unset."}
    return _training.stats(target)


@mcp.tool()
def qa_training_export(output_path: str,
                       data_dir: str | None = None,
                       task: str | None = None,
                       output_format: str = "messages",
                       max_html_chars: int | None = None,
                       dedupe: bool = True) -> dict[str, Any]:
    """Export the captured corpus as a JSONL ready for fine-tuning.

    `output_path`: target .jsonl file.
    `data_dir`: defaults to $QA_MCP_TRAINING_DATA_DIR.
    `task`: 'rtl' | 'perf' | 'seo' | 'links' | 'a11y' | None.
            None emits one example per (run, audit) for ALL audits.
    `output_format`: 'messages' (ChatML) | 'prompt_completion'.
    `max_html_chars`: trim HTML if too long (helps small-model context).
    `dedupe`: skip identical (html, audit, output) triples. Default True.
              Two scans of the same site with the same HTML count once.
              If the page changed between scans, both are kept — those are
              valuable signal of fixes (use qa_training_diffs to see them).

    Returns: { examples_written, skipped_duplicates, skipped_other,
               unique_html_pages, output_path, format, task_filter, dedupe }.

    Use with unsloth/transformers/axolotl for distillation training.
    Recommended first model: small task-specific (e.g. RTL only, Gemma 4 E2B)."""
    import os as _os
    target = data_dir or _os.getenv("QA_MCP_TRAINING_DATA_DIR")
    if not target:
        return {"error": "No data_dir given and QA_MCP_TRAINING_DATA_DIR is unset."}
    return _training.export_jsonl(
        data_dir=target,
        output_path=output_path,
        task=task,
        output_format=output_format,
        max_html_chars=max_html_chars,
        dedupe=dedupe,
    )


@mcp.tool()
def qa_training_diffs(data_dir: str | None = None) -> dict[str, Any]:
    """Find URLs scanned multiple times whose HTML changed between scans.

    These are the highest-signal examples in your corpus: a finding that
    appeared in scan 1 and disappeared in scan 2 is a captured *fix*.
    Useful for:
      - Showing clients that they actually improved after your QA work
      - Building a future qa-fix-suggester model (input: broken HTML +
        finding; output: fixed HTML)
      - Identifying regressions (counts went up between scans)

    `data_dir`: defaults to $QA_MCP_TRAINING_DATA_DIR.

    Returns: { total_urls_scanned_twice, total_with_changes,
               urls_with_changes: [{url, scans, delta}] }."""
    import os as _os
    target = data_dir or _os.getenv("QA_MCP_TRAINING_DATA_DIR")
    if not target:
        return {"error": "No data_dir given and QA_MCP_TRAINING_DATA_DIR is unset."}
    return _training.find_diffs(target)


# ---------- Flow automation tools ----------


@mcp.tool()
async def qa_login_with_credentials(session_id: str,
                                    username: str,
                                    password: str,
                                    username_query: str | None = None,
                                    password_query: str | None = None,
                                    submit_query: str | None = None) -> dict[str, Any]:
    """Login using known credentials on the current page.

    Use this for QA/demo sites or real test accounts when synthetic smart-fill
    credentials are not appropriate. Optional query args are CSS selectors for
    username/password/submit; otherwise fields are inferred.
    """
    return await qa_tools.qa_login_with_credentials(
        mgr, session_id, username=username, password=password,
        username_query=username_query, password_query=password_query,
        submit_query=submit_query,
    )


@mcp.tool()
async def qa_flow_runner(session_id: str,
                         steps: list[dict[str, Any]],
                         stop_on_error: bool = True) -> dict[str, Any]:
    """Run an explicit browser QA flow step-by-step.

    Supported actions: type, type_selector, click, click_text, click_selector,
    select, wait_text, assert_text, assert_url, logs, screenshot, get_state.

    Use this instead of parallel UI tool calls for multi-step flows. Steps run
    sequentially, so form filling and clicks do not race each other.
    """
    return await qa_tools.qa_flow_runner(mgr, session_id, steps, stop_on_error=stop_on_error)


# ---------- Product/UX intelligence tools ----------


@mcp.tool()
async def qa_tech_stack_detect(session_id: str) -> dict[str, Any]:
    """Detect frontend framework, UI/CSS libraries, animation libraries,
    analytics, builders/CMS, and media primitives from the current page.
    Heuristic: returns confidence and evidence, not a legal/forensic proof."""
    return await qa_tools.qa_tech_stack_detect(mgr, session_id)


@mcp.tool()
async def qa_design_interaction_scan(session_id: str) -> dict[str, Any]:
    """Scan the current page for special design/interaction elements:
    animations, transitions, sticky/fixed widgets, chat/cookie/accessibility
    widgets, language/theme toggles, canvas/video/svg/picture/iframe media."""
    return await qa_tools.qa_design_interaction_scan(mgr, session_id)


@mcp.tool()
async def qa_form_risk_audit(session_id: str) -> dict[str, Any]:
    """Form UX/risk audit: labels, autocomplete, GET vs POST, privacy consent,
    required fields, and field inventory. Use before testing a lead/signup flow."""
    result = await qa_tools.qa_form_risk_audit(mgr, session_id)
    findings = result.get("findings", [])
    workspace.emit(
        "form_risk_audit",
        f"Form risk audit completed: {len(findings)} finding(s)",
        {"summary": result.get("summary")},
        level="warning" if findings else "info",
    )
    for item in findings[:8]:
        field = item.get("field") if isinstance(item, dict) else None
        selector = f"#{field.get('id')}" if isinstance(field, dict) and field.get("id") else None
        workspace.add_finding(
            title=item.get("title", "Form risk"),
            severity=item.get("severity", "medium"),
            description=item.get("hint"),
            selector=selector,
            data={"source": "form_risk_audit", "raw": item},
        )
    return result


@mcp.tool()
async def qa_inspiration_analyze_url(url: str,
                                     output_dir: str | None = None,
                                     include_mobile: bool = True) -> dict[str, Any]:
    """Analyze a website for inspiration without copying: sections, CTAs,
    special elements, tech stack, interaction patterns, and what to adapt vs
    what not to copy. Returns abstract UX/design patterns, not source code."""
    from pathlib import Path
    import json as _json
    from urllib.parse import urlparse
    import re as _re

    opened = await browser_tools.browser_open(mgr, url=url, headless=True)
    sid = opened["session_id"]
    try:
        state = await browser_tools.browser_get_state(mgr, sid, text_snapshot_chars=4000)
        tech = await qa_tools.qa_tech_stack_detect(mgr, sid)
        interactions = await qa_tools.qa_design_interaction_scan(mgr, sid)
        seo = await qa_tools.qa_seo_check(mgr, sid, detail="samples")
        mobile = None
        if include_mobile:
            await browser_tools.browser_set_viewport(mgr, sid, device="iphone-13")
            mobile = await qa_tools.qa_design_interaction_scan(mgr, sid)

        text = state.get("text_snapshot", "")
        lines = [l.strip() for l in text.splitlines() if l.strip()]
        ctas = [e for e in state.get("elements", []) if e.get("tag") in ("a", "button") and e.get("text")]
        sections = (seo.get("headings") or {})
        report = {
            "url": state.get("url"),
            "title": state.get("title"),
            "hero_guess": lines[:8],
            "cta_patterns": [{"text": e.get("text"), "tag": e.get("tag"), "href": e.get("href")} for e in ctas[:20]],
            "section_signal": sections,
            "tech_stack": tech.get("detections", []),
            "special_elements": interactions.get("special_elements", []),
            "animations_summary": interactions.get("summary", {}),
            "media_effects": interactions.get("media_effects", []),
            "mobile_summary": (mobile or {}).get("summary"),
            "what_to_adapt": [
                "Abstract the information hierarchy and CTA placement, not the exact visual design.",
                "Borrow UX principles: clear promise, visible CTA, proof/trust cues, low-friction flow.",
                "Use detected interaction patterns as inspiration for original microinteractions.",
            ],
            "what_not_to_copy": [
                "Do not copy HTML/CSS, class names, exact copy, images, icons, brand colors, or unique animations.",
                "Do not recreate a competitor pixel-perfect; create a differentiated implementation.",
            ],
        }
        if output_dir:
            p = Path(output_dir); p.mkdir(parents=True, exist_ok=True)
            safe = _re.sub(r"[^\w\-]+", "-", urlparse(state.get("url") or url).netloc or "site")
            out = p / f"{safe}-inspiration.json"
            out.write_text(_json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
            report["report_path"] = str(out)
        return report
    finally:
        await browser_tools.browser_close(mgr, sid)


@mcp.tool()
async def qa_originality_check(source_url: str, draft_url: str) -> dict[str, Any]:
    """Compare an inspiration source and a draft site for similarity risk.
    This is a heuristic originality guardrail: copy overlap, section structure,
    color/style signals. It does not provide legal advice."""
    import difflib

    async def sig(url: str):
        opened = await browser_tools.browser_open(mgr, url=url, headless=True)
        sid = opened["session_id"]
        try:
            return await qa_tools.qa_page_signature(mgr, sid)
        finally:
            await browser_tools.browser_close(mgr, sid)

    a, b = await sig(source_url), await sig(draft_url)
    text_a = "\n".join(a.get("texts", []))[:20000]
    text_b = "\n".join(b.get("texts", []))[:20000]
    copy_similarity = difflib.SequenceMatcher(None, text_a.lower(), text_b.lower()).ratio()
    tags_a, tags_b = " ".join(a.get("tags", [])[:1000]), " ".join(b.get("tags", [])[:1000])
    structure_similarity = difflib.SequenceMatcher(None, tags_a, tags_b).ratio()
    colors_a, colors_b = set(a.get("colors", [])), set(b.get("colors", []))
    color_overlap = len(colors_a & colors_b) / max(1, len(colors_a | colors_b))
    risk_score = round((copy_similarity * 0.5 + structure_similarity * 0.3 + color_overlap * 0.2) * 100)
    risk = "high" if risk_score >= 70 or copy_similarity > 0.45 else "medium" if risk_score >= 45 else "low"
    return {
        "source": source_url,
        "draft": draft_url,
        "risk": risk,
        "risk_score": risk_score,
        "metrics": {"copy_similarity": round(copy_similarity, 3), "structure_similarity": round(structure_similarity, 3), "color_overlap": round(color_overlap, 3)},
        "guidance": [
            "Use this as a heuristic only, not legal advice.",
            "If risk is medium/high: rewrite copy, change section order, alter CTA structure, use different visual language and assets.",
            "Keep principles, not expression: adapt the idea, not the implementation.",
        ],
    }


@mcp.tool()
async def qa_agent_context(url: str,
                           depth: int = 1,
                           include_mobile: bool = True,
                           browser: str = "chrome",
                           output_dir: str | None = None,
                           max_elements: int = 60,
                           session_id: str | None = None) -> dict[str, Any]:
    """Agent-ready context package for a website/app. Opens the URL and returns
    the information an AI agent needs in one compact JSON: page purpose,
    language/RTL, key actions, forms, links/site map, screenshots, logs,
    tech stack, QA issues, next-best-actions, and evidence file paths.

    This is not a human report. It is a sensor/context layer for autonomous
    agents so they do not need to orchestrate 10 low-level browser tools.
    Use browser='cloak' for sites protected by bot detection.
    `session_id` is accepted for clients that auto-inject active sessions;
    this tool opens and closes its own session from `url`.
    """
    from pathlib import Path
    from urllib.parse import urljoin, urlparse
    import json as _json, re as _re, time as _time

    depth = max(0, min(int(depth), 2))
    max_elements = max(10, min(int(max_elements), 200))
    opened = await browser_tools.browser_open(mgr, url=url, headless=True, browser=browser)
    sid = opened["session_id"]
    evidence_dir: Path | None = None
    if output_dir:
        host = urlparse(opened.get("url") or url).netloc or "site"
        safe = _re.sub(r"[^\w\-]+", "-", host).strip("-") or "site"
        evidence_dir = Path(output_dir) / safe
        evidence_dir.mkdir(parents=True, exist_ok=True)

    def _top_actions(state: dict[str, Any]) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        danger_re = _re.compile(r"(delete|remove|cancel|purchase|buy|pay|submit|שלח|מחק|בטל|רכוש|קנה|תשלום)", _re.I)
        for e in state.get("elements", [])[:max_elements]:
            text = (e.get("text") or e.get("placeholder") or e.get("name") or "").strip()
            if not text and e.get("tag") not in ("input", "textarea", "select", "button", "a"):
                continue
            href = e.get("href")
            risk = "dangerous" if danger_re.search(text or href or "") else "safe"
            out.append({
                "id": f"el_{e.get('index')}", "index": e.get("index"),
                "label": text[:120], "tag": e.get("tag"), "role": e.get("role"),
                "type": e.get("type"), "href": href, "risk": risk,
                "bbox": {"x": e.get("x"), "y": e.get("y"), "w": e.get("w"), "h": e.get("h")},
            })
        return out

    def _summarize_issues(logs: dict[str, Any], rtl: dict[str, Any], a11y: dict[str, Any], seo: dict[str, Any], perf: dict[str, Any]) -> list[dict[str, Any]]:
        issues: list[dict[str, Any]] = []
        for ev in (logs.get("events") or [])[:10]:
            issues.append({"severity": "high" if ev.get("level") == "error" else "medium", "type": f"browser_{ev.get('kind')}", "evidence": ev.get("text"), "agent_hint": "Inspect console/network error before trusting the UI state."})
        for f in (rtl.get("findings") or [])[:8]:
            issues.append({"severity": f.get("severity", "medium"), "type": "rtl", "evidence": f.get("message") or f.get("description"), "agent_hint": "Check Hebrew/RTL layout on desktop and mobile."})
        for v in (a11y.get("violations") or [])[:8]:
            issues.append({"severity": v.get("impact", "medium"), "type": "a11y", "evidence": v.get("help") or v.get("description"), "agent_hint": "Prioritize critical/serious accessibility issues."})
        for it in (seo.get("issues") or [])[:6]:
            issues.append({"severity": it.get("severity", "medium"), "type": "seo", "evidence": it.get("message") or it.get("title"), "agent_hint": "Validate metadata/headings relevant to page purpose."})
        score = perf.get("score") or perf.get("performance_score")
        if isinstance(score, (int, float)) and score < 75:
            issues.append({"severity": "medium", "type": "performance", "evidence": f"Performance score {score}", "agent_hint": "Check heavy assets, hydration, and render-blocking resources."})
        return [i for i in issues if i.get("evidence")]

    try:
        await browser_tools.browser_wait_for(mgr, sid, network_idle=True, timeout_ms=10000)
        state = await browser_tools.browser_get_state(mgr, sid, text_snapshot_chars=5000, max_elements=max_elements)
        logs = await browser_tools.browser_logs(mgr, sid)
        tech = await qa_tools.qa_tech_stack_detect(mgr, sid)
        interactions = await qa_tools.qa_design_interaction_scan(mgr, sid)
        forms = await qa_tools.qa_form_inventory(mgr, sid)
        links = await qa_tools.qa_scan_links(mgr, sid, detail="samples")
        rtl = await qa_tools.qa_rtl_audit(mgr, sid, detail="summary")
        a11y = await qa_tools.qa_a11y_audit(mgr, sid, detail="summary")
        seo = await qa_tools.qa_seo_check(mgr, sid, detail="summary")
        perf = await qa_tools.qa_perf_metrics(mgr, sid)

        screenshot = await browser_tools.browser_screenshot(
            mgr, sid, full_page=False,
            save_to=str(evidence_dir / "desktop.jpg") if evidence_dir else None,
        )
        mobile_state = mobile_shot = mobile_rtl = None
        if include_mobile:
            await browser_tools.browser_set_viewport(mgr, sid, device="iphone-13")
            await browser_tools.browser_wait_for(mgr, sid, network_idle=True, timeout_ms=5000)
            mobile_state = await browser_tools.browser_get_state(mgr, sid, text_snapshot_chars=2500, max_elements=min(max_elements, 50))
            mobile_rtl = await qa_tools.qa_rtl_audit(mgr, sid, detail="summary")
            mobile_shot = await browser_tools.browser_screenshot(
                mgr, sid, full_page=False,
                save_to=str(evidence_dir / "mobile.jpg") if evidence_dir else None,
            )

        semantic = await mgr.get(sid).page.evaluate("""() => {
          const html = document.documentElement;
          const metas = [...document.querySelectorAll('meta')].slice(0, 40).map(m => ({name:m.getAttribute('name'), property:m.getAttribute('property'), content:(m.getAttribute('content')||'').slice(0,200)}));
          const headings = [...document.querySelectorAll('h1,h2,h3')].slice(0, 30).map(h => ({tag:h.tagName.toLowerCase(), text:(h.innerText||'').trim().slice(0,160)}));
          const forms = [...document.forms].slice(0, 10).map((f, i) => ({index:i, action:f.action, method:f.method, fields:[...f.elements].slice(0,30).map(el => ({tag:el.tagName.toLowerCase(), type:el.type||null, name:el.name||null, placeholder:el.placeholder||null, required:!!el.required}))}));
          return {lang: html.lang || null, dir: html.dir || getComputedStyle(html).direction, metas, headings, forms, path: location.pathname};
        }""")

        text = state.get("text_snapshot") or ""
        lines = [l.strip() for l in text.splitlines() if l.strip()]
        purpose = "landing_page"
        path_low = (semantic.get("path", "") or "").lower()
        heading_low = " ".join((h.get("text") or "") for h in (semantic.get("headings") or [])[:6]).lower()
        if "login" in path_low or "auth" in path_low or "signin" in path_low or "התחבר" in heading_low:
            purpose = "login_or_auth"
        elif "pricing" in path_low or "price" in path_low or "תמחור" in heading_low:
            purpose = "pricing"
        elif forms.get("forms") or semantic.get("forms"):
            purpose = "form_or_conversion"
        elif "dashboard" in path_low or "admin" in path_low:
            purpose = "dashboard_app"

        host = urlparse(state.get("url") or opened.get("url") or url).netloc
        discovered = []
        if depth:
            keywords = ("pricing", "price", "login", "signup", "contact", "docs", "guide", "תמחור", "התחבר", "צור", "מדריך")
            for it in (links.get("items") or [])[:80]:
                href = it.get("resolved_href") or it.get("href")
                if not href: continue
                abs_url = urljoin(state.get("url") or url, href).split("#")[0]
                p = urlparse(abs_url)
                if p.netloc == host and (depth > 1 or any(k in ((it.get("text") or "") + " " + p.path).lower() for k in keywords)) and abs_url not in discovered:
                    discovered.append(abs_url)
                if len(discovered) >= 12: break

        issues = _summarize_issues(logs, rtl, a11y, seo, perf)
        actions = _top_actions(state)
        next_actions = []
        if any(a.get("href") and "login" in str(a.get("href")).lower() for a in actions): next_actions.append("Open/login flow only with user-approved credentials or saved storage state.")
        if forms.get("count") or semantic.get("forms"): next_actions.append("Run qa_agent_test_flow with submit=False before any form submission.")
        if include_mobile and mobile_rtl and (mobile_rtl.get("summary", {}).get("high", 0) or mobile_rtl.get("high", 0)): next_actions.append("Inspect mobile RTL findings first; mobile layout has high-risk RTL signals.")
        if logs.get("count", 0): next_actions.append("Investigate browser logs before making UX conclusions.")
        next_actions += ["Use listed safe action indices for navigation.", "Use screenshot paths as visual evidence; avoid embedding image bytes in prompt."]

        context = {
            "ok": True,
            "opened": opened,
            "page": {"url": state.get("url"), "title": state.get("title"), "purpose": purpose, "language": semantic.get("lang"), "direction": semantic.get("dir"), "viewport": state.get("viewport"), "text_summary": lines[:18]},
            "agent_state": {"session_id": sid, "visited": [state.get("url")], "discovered_pages": discovered, "auth_required_guess": purpose == "login_or_auth", "safe_action_count": sum(1 for a in actions if a.get("risk") == "safe"), "dangerous_action_count": sum(1 for a in actions if a.get("risk") == "dangerous")},
            "actions": actions[:max_elements],
            "forms": forms,
            "semantic": semantic,
            "site_map": {"host": host, "important_links": discovered},
            "qa_signals": {"logs": logs, "rtl": rtl, "a11y": a11y, "seo": seo, "perf": perf, "tech_stack": tech, "interactions": interactions},
            "issues": issues[:30],
            "next_best_actions": next_actions[:10],
            "evidence_files": {"desktop_screenshot": screenshot.get("path"), "mobile_screenshot": (mobile_shot or {}).get("path"), "context_json": None},
            "mobile": {"state": mobile_state, "rtl": mobile_rtl} if include_mobile else None,
            "limits": {"depth": depth, "max_elements": max_elements, "full_text_truncated": "…[" in text},
        }
        if evidence_dir:
            out = evidence_dir / f"agent-context-{int(_time.time())}.json"
            context["evidence_files"]["context_json"] = str(out)
            out.write_text(_json.dumps(context, indent=2, ensure_ascii=False), encoding="utf-8")
        return context
    finally:
        await browser_tools.browser_close(mgr, sid)


@mcp.tool()
async def qa_agent_explore_site(url: str,
                                max_pages: int = 5,
                                output_dir: str | None = None,
                                include_mobile: bool = True) -> dict[str, Any]:
    """Agent-first multi-page exploration. Discovers important internal pages
    (home, Hebrew, pricing, contact, login/signup, legal/docs), runs QA suite,
    and emits HTML/Markdown/JSON/issues reports. Use when the user says 'QA the
    whole site' without providing a config."""
    from pathlib import Path
    from urllib.parse import urlparse, urljoin
    import json as _json, re as _re

    opened = await browser_tools.browser_open(mgr, url=url, headless=True)
    sid = opened["session_id"]
    try:
        links = await qa_tools.qa_scan_links(mgr, sid, detail="full")
        current = opened.get("url") or url
    finally:
        await browser_tools.browser_close(mgr, sid)

    host = urlparse(current).netloc
    candidates = [current]
    scored = []
    keywords = {"he": 90, "pricing": 80, "price": 80, "contact": 75, "login": 65, "signup": 65, "register": 65, "guide": 55, "docs": 55, "privacy": 25, "terms": 25, "accessibility": 25}
    for it in links.get("items", []) or []:
        href = it.get("resolved_href") or it.get("href")
        if not href: continue
        abs_url = urljoin(current, href)
        p = urlparse(abs_url)
        if p.netloc != host: continue
        key = (p.path + " " + (it.get("text") or "")).lower()
        score = max([v for k, v in keywords.items() if k in key] or [10])
        scored.append((score, abs_url.split("#")[0]))
    for _, u in sorted(scored, reverse=True):
        if u not in candidates:
            candidates.append(u)
        if len(candidates) >= max_pages:
            break

    scenarios = []
    for i, u in enumerate(candidates[:max_pages]):
        scenarios.append({"name": f"page-{i+1}-{urlparse(u).path.strip('/').replace('/', '-') or 'home'}", "path": u, "audits": ["rtl","a11y","perf","seo","links","security","logs"], "thresholds": {"rtl":{"max_high":0}, "a11y":{"max_critical":0,"max_serious":0}, "perf":{"min_score":80}, "seo":{"max_issues":5}, "links":{"max_flagged":0}, "security":{"max_critical":0,"max_high":0,"min_score":75}}, "wait_for": {"network_idle": True, "timeout_ms": 10000}})
        if include_mobile and i == 0:
            scenarios.append({"name": "home-mobile", "path": u, "viewport": {"device": "iphone-13"}, "audits": ["rtl","perf","seo","links","security","logs"], "thresholds": {"rtl":{"max_high":0}, "perf":{"min_score":80}, "seo":{"max_issues":5}, "links":{"max_flagged":0}, "security":{"max_critical":0,"max_high":0,"min_score":75}}, "wait_for": {"network_idle": True, "timeout_ms": 10000}})

    config = {"name": f"qa-explore-{host}", "base_url": current, "browser": "chrome", "headless": True, "scenarios": scenarios}
    from . import suite as _suite
    result = await _suite.run_suite(config)
    safe = _re.sub(r"[^\w\-]+", "-", host or "site")
    out_dir = Path(output_dir or (Path.cwd() / "qa-explore-report" / safe)); out_dir.mkdir(parents=True, exist_ok=True)
    html_path, md_path, json_path = str(out_dir/"qa-report.html"), str(out_dir/"qa-report.md"), str(out_dir/"qa-result.json")
    _suite.emit_html_report(result, html_path); _suite.emit_markdown_report(result, md_path)
    Path(json_path).write_text(_json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    result.update({"discovered_pages": candidates[:max_pages], "html_report_path": html_path, "markdown_report_path": md_path, "json_report_path": json_path, "issues_export": _suite.emit_issue_files(result, str(out_dir/"issues"))})
    return result


@mcp.tool()
async def qa_agent_test_flow(url: str,
                             flow: str = "contact-form",
                             submit: bool = False) -> dict[str, Any]:
    """High-level flow smoke test. Opens a URL, inventories forms, runs form
    risk audit, fills synthetic data for contact/signup/login-like flows, and
    checks browser logs. submit defaults False to avoid real leads/orders."""
    opened = await browser_tools.browser_open(mgr, url=url, headless=True)
    sid = opened["session_id"]
    try:
        inventory = await qa_tools.qa_form_inventory(mgr, sid)
        risk = await qa_tools.qa_form_risk_audit(mgr, sid)
        intent = "valid_signup" if flow in ("signup", "contact-form", "lead") else "valid_login" if flow == "login" else "hebrew"
        fill = await qa_tools.qa_form_smart_fill(mgr, sid, intent=intent, submit=submit)
        logs = await browser_tools.browser_logs(mgr, sid)
        state = await browser_tools.browser_get_state(mgr, sid, text_snapshot_chars=1500)
        return {"url": opened.get("url"), "flow": flow, "submitted": submit, "inventory": inventory, "risk_audit": risk, "fill_result": fill, "logs": logs, "visible_text_after": state.get("text_snapshot", "")[:1500]}
    finally:
        await browser_tools.browser_close(mgr, sid)


# ---------- Passive security ----------


@mcp.tool()
async def qa_security_passive_audit(url: str) -> dict[str, Any]:
    """Passive, safe security audit for a URL/domain.

    Checks security headers, TLS certificate, cookie flags, mixed content,
    exposed sensitive paths, CORS reflection, security.txt, basic information
    disclosure, and optional SPF/DMARC DNS records. No active exploitation,
    no port scanning, no brute force.
    """
    from .tools import security_tools
    return await security_tools.security_passive_audit(url)


# ---------- Client reports ----------


@mcp.tool()
def qa_client_report_pdf(result_json: str,
                        out_pdf: str | None = None,
                        client: str | None = None,
                        consultant: str = "BrainboxAI") -> dict[str, Any]:
    """Create a branded PDF report from an Agent QA Console result JSON.

    Generates a self-contained Hebrew PDF with QA findings, screenshots,
    and fix guidance. No external fonts or web access needed.

    Args:
        result_json: Path to qa-result.json.
        out_pdf: Output PDF path. Defaults to ./qa-report-<name>.pdf
        client: Client/project name for the report header.
        consultant: Consultant/company name.
    """
    from .pdf_export import create_client_report_pdf
    return create_client_report_pdf(
        result_json=result_json,
        out_pdf=out_pdf or "./qa-report.pdf",
        client=client,
        consultant=consultant,
    )


@mcp.tool()
def qa_client_report(result_json: str,
                     out_zip: str,
                     client: str | None = None,
                     consultant: str = "BrainboxAI",
                     include_pdf: bool = False) -> dict[str, Any]:
    """Create a polished client-facing ZIP report from qa-result.json.

    Use this when the user wants to send a professional QA report to a client.
    The ZIP contains a self-contained Hebrew HTML report with embedded images,
    a Markdown summary, raw JSON, and Markdown issue files. No external image
    files or web fonts are required for the main report to render.

    Set include_pdf=True to also generate a branded PDF alongside the ZIP.
    """
    from .client_report import create_client_report_zip
    result = create_client_report_zip(
        result_json=result_json,
        out_zip=out_zip,
        client=client,
        consultant=consultant,
    )
    if include_pdf:
        from .pdf_export import create_client_report_pdf
        pdf_out = str(Path(out_zip).with_suffix(".pdf"))
        pdf = create_client_report_pdf(result_json, pdf_out, client, consultant)
        result["pdf_path"] = pdf.get("pdf_path")
        result["pdf_size_bytes"] = pdf.get("size_bytes")
    return result


# ---------- Slack integration ----------


@mcp.tool()
def qa_slack_notify(result_json: str,
                   webhook_url: str,
                   channel: str | None = None,
                   max_findings: int = 5) -> dict[str, Any]:
    """Post a QA summary to Slack.

    Sends a formatted message with scenario pass/fail, top findings, and
    severity breakdown to a Slack channel via Incoming Webhook.

    Args:
        result_json: Path to qa-result.json.
        webhook_url: Slack Incoming Webhook URL.
        channel: Override the webhook's default channel (e.g. '#qa-alerts').
        max_findings: Maximum findings to list in the message.
    """
    import json
    from .slack import notify_slack
    suite = json.loads(Path(result_json).read_text(encoding="utf-8"))
    return notify_slack(webhook_url, suite, channel=channel, max_findings=max_findings)


# ---------- GitHub integration ----------


@mcp.tool()
def qa_github_create_issues(result_json: str,
                            repo: str,
                            dry_run: bool = True,
                            api_url: str = "https://api.github.com",
                            comment_existing: bool = False) -> dict[str, Any]:
    """Create real GitHub Issues from an Agent QA Console result JSON.

    Agent-first usage: after qa_agent_audit_url or qa_run_suite produced a
    qa-result.json, call this tool to open engineering tickets automatically.

    Requires GITHUB_TOKEN or GH_TOKEN in the environment unless dry_run=True.
    Deduplicates by an embedded Agent QA Console fingerprint so repeated scans do not
    spam duplicate issues.

    Args:
        result_json: Path to qa-result.json.
        repo: GitHub repository in OWNER/REPO form.
        dry_run: Default True for safety. Set False to create issues.
        api_url: GitHub API URL, override for GitHub Enterprise.
        comment_existing: If True, comment on existing open issues when a
            finding appears again.
    """
    from .github_issues import create_github_issues_from_file
    return create_github_issues_from_file(
        result_json=result_json,
        repo=repo,
        dry_run=dry_run,
        api_url=api_url,
        comment_existing=comment_existing,
    )


# ---------- agent-first orchestration ----------


@mcp.tool()
async def qa_agent_audit_url(url: str,
                             name: str | None = None,
                             focus: str = "full",
                             output_dir: str | None = None,
                             include_mobile: bool = True,
                             include_issues: bool = True) -> dict[str, Any]:
    """Agent-first website QA. Give it a URL; the tool builds and runs a
    practical QA suite automatically and emits reports.

    This is the high-level tool agents should prefer when the user simply says
    "QA this site" and does not want to write CLI commands or qa.config.json.

    Args:
        url: Site URL to audit.
        name: Optional report/suite name. Defaults to host-based name.
        focus: 'full' (default), 'rtl', 'a11y', 'perf', or 'conversion'.
        output_dir: Directory for reports. Defaults to ./qa-agent-report/<name>.
        include_mobile: Add an iPhone viewport scenario.
        include_issues: Export one Markdown issue file per actionable finding.

    Returns the full suite result plus paths to generated reports.
    """
    from pathlib import Path
    from urllib.parse import urlparse
    import re as _re

    parsed = urlparse(url if "://" in url else f"https://{url}")
    normalized_url = parsed.geturl()
    host = parsed.netloc or "site"
    safe = _re.sub(r"[^\w\-]+", "-", (name or host)).strip("-") or "site"
    out_dir = Path(output_dir or (Path.cwd() / "qa-agent-report" / safe))
    out_dir.mkdir(parents=True, exist_ok=True)

    audit_sets = {
        "full": ["ux", "rtl", "a11y", "perf", "seo", "links", "security", "logs"],
        "rtl": ["rtl", "a11y", "links", "logs"],
        "a11y": ["a11y", "links", "logs"],
        "perf": ["perf", "seo", "logs"],
        "conversion": ["ux", "rtl", "a11y", "seo", "links", "security", "logs"],
    }
    audits = audit_sets.get(focus, audit_sets["full"])

    thresholds = {
        "rtl": {"max_high": 0},
        "a11y": {"max_critical": 0, "max_serious": 0},
        "perf": {"min_score": 80},
        "seo": {"max_issues": 5},
        "links": {"max_flagged": 0},
        "ux": {"min_score": 70, "max_high": 0},
        "security": {"max_critical": 0, "max_high": 0, "min_score": 75},
    }

    scenarios: list[dict[str, Any]] = [
        {
            "name": "homepage-desktop",
            "path": normalized_url,
            "audits": audits,
            "thresholds": thresholds,
            "wait_for": {"network_idle": True, "timeout_ms": 10000},
        }
    ]
    if include_mobile:
        scenarios.append({
            "name": "homepage-mobile",
            "path": normalized_url,
            "audits": audits,
            "thresholds": thresholds,
            "viewport": {"device": "iphone-13"},
            "wait_for": {"network_idle": True, "timeout_ms": 10000},
        })

    config = {
        "name": name or f"qa-agent-{host}",
        "base_url": normalized_url,
        "browser": "chrome",
        "headless": True,
        "scenarios": scenarios,
    }

    from . import suite as _suite
    result = await _suite.run_suite(config)
    html_path = str(out_dir / "qa-report.html")
    md_path = str(out_dir / "qa-report.md")
    json_path = str(out_dir / "qa-result.json")
    _suite.emit_html_report(result, html_path)
    _suite.emit_markdown_report(result, md_path)
    Path(json_path).write_text(__import__("json").dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    result["html_report_path"] = html_path
    result["markdown_report_path"] = md_path
    result["json_report_path"] = json_path
    if include_issues:
        result["issues_export"] = _suite.emit_issue_files(result, str(out_dir / "issues"))
    return result


# ---------- entry point ----------


def main():
    """Console-script entry. Dispatches to CLI subcommand or stdio MCP server."""
    from .cli import run_cli
    raise SystemExit(run_cli())


if __name__ == "__main__":
    main()
