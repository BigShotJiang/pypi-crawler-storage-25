"""Slack webhook integration for qa-mcp.

Posts a summary of findings and threshold violations to a Slack channel.
Minimal, self-contained — just stdlib + urllib.
"""
from __future__ import annotations

import json
import urllib.request
from typing import Any


SEVERITY_EMOJI = {
    "critical": ":fire:",
    "high": ":red_circle:",
    "medium": ":large_yellow_circle:",
    "low": ":large_blue_circle:",
    "info": ":white_circle:",
}


def notify_slack(
    webhook_url: str,
    suite: dict[str, Any],
    channel: str | None = None,
    max_findings: int = 5,
) -> dict[str, Any]:
    """Post a QA summary to Slack.

    Args:
        webhook_url: Slack Incoming Webhook URL (or SLACK_WEBHOOK_URL env var).
        suite: qa-mcp suite result dict.
        channel: Override the webhook's default channel.
        max_findings: Cap on findings shown in the message body.

    Returns:
        { ok, status_code, findings_posted }
    """
    summary = suite.get("summary", {}) or {}
    passed = summary.get("passed", 0)
    failed = summary.get("failed", 0)
    total = summary.get("total", 0)
    findings_total = summary.get("findings_total", 0)

    status_emoji = ":white_check_mark:" if failed == 0 else ":warning:"
    status_text = "PASSED" if failed == 0 else f"{failed} FAILED"

    blocks: list[dict[str, Any]] = [
        {
            "type": "header",
            "text": {
                "type": "plain_text",
                "text": f"{status_emoji} QA: {suite.get('name', 'qa-mcp')} — {status_text}",
                "emoji": True,
            },
        },
        {
            "type": "section",
            "fields": [
                {"type": "mrkdwn", "text": f"*Scenarios:* {passed}/{total} passed"},
                {"type": "mrkdwn", "text": f"*Findings:* {findings_total} total"},
                {"type": "mrkdwn", "text": f"*Browser:* {suite.get('browser', '?')}"},
                {"type": "mrkdwn", "text": f"*Duration:* {suite.get('duration_seconds', 0):.1f}s"},
            ],
        },
    ]

    # Top findings
    all_findings: list[dict] = []
    for sc in suite.get("scenarios", []) or []:
        for f in sc.get("findings", []) or []:
            all_findings.append({"scenario": sc.get("name", ""), **f})

    sev_order = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
    all_findings.sort(key=lambda f: sev_order.get(f.get("severity", "info"), 9))

    if all_findings:
        items = []
        for f in all_findings[:max_findings]:
            emoji = SEVERITY_EMOJI.get(f.get("severity", "info"), ":grey_question:")
            items.append(
                f"{emoji} *[{f.get('severity', '?').upper()}] [{f.get('source', '?')}]* {f.get('title', '')[:120]}"
            )
        blocks.append({
            "type": "section",
            "text": {"type": "mrkdwn", "text": "*Top findings:*\n" + "\n".join(items)},
        })

    payload = {"blocks": blocks}
    if channel:
        payload["channel"] = channel

    try:
        req = urllib.request.Request(
            webhook_url,
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            return {"ok": True, "status_code": resp.status, "findings_posted": min(len(all_findings), max_findings)}
    except Exception as e:
        return {"ok": False, "error": str(e)}
