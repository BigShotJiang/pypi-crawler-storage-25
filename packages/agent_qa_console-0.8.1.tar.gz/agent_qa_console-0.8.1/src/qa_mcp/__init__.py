"""Agent QA Console — browser QA control plane for AI coding agents.

Watch, guide, and approve your AI agent’s browser QA work.

Designed so any MCP-compatible agent (Claude Code, Cursor, Codex, Gemini CLI,
OpenCode, etc.) can drive web QA without bringing its own browser.

The server is stateless from the caller's view but maintains live browser
sessions internally, keyed by a UUID returned from `browser_open`.
"""
__version__ = "0.8.0"
