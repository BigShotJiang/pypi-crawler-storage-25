from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.session_list_item import SessionListItem


T = TypeVar("T", bound="SessionListResponse")


@_attrs_define
class SessionListResponse:
    """
    Attributes:
        sessions (list[SessionListItem]): List of sessions
        total (int): Total number of sessions matching the query
        offset (int): Current offset
        limit (int): Current page size
    """

    sessions: list[SessionListItem]
    total: int
    offset: int
    limit: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        sessions = []
        for sessions_item_data in self.sessions:
            sessions_item = sessions_item_data.to_dict()
            sessions.append(sessions_item)

        total = self.total

        offset = self.offset

        limit = self.limit

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "sessions": sessions,
                "total": total,
                "offset": offset,
                "limit": limit,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.session_list_item import SessionListItem

        d = dict(src_dict)
        sessions = []
        _sessions = d.pop("sessions")
        for sessions_item_data in _sessions:
            sessions_item = SessionListItem.from_dict(sessions_item_data)

            sessions.append(sessions_item)

        total = d.pop("total")

        offset = d.pop("offset")

        limit = d.pop("limit")

        session_list_response = cls(
            sessions=sessions,
            total=total,
            offset=offset,
            limit=limit,
        )

        session_list_response.additional_properties = d
        return session_list_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
