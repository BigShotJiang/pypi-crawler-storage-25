"""
Tests for ACRCloud CLI
"""
