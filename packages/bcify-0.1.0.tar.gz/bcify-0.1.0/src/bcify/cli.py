from __future__ import annotations

import argparse
from pathlib import Path

from bcify.generator import build_scaffold_script


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="bcify",
        description="Generate a Bytecraft .bc scaffold from a project repository.",
    )
    parser.add_argument("source", help="Path to the source repository or project folder.")
    parser.add_argument(
        "-o",
        "--output",
        help="Path to the output .bc file. Defaults to <repo-name>.bc in the current directory.",
    )
    parser.add_argument(
        "--root-name",
        help="Folder name used in set-working-folder. Defaults to the source folder name.",
    )
    parser.add_argument(
        "--include-hidden",
        action="store_true",
        help="Include hidden files and directories except default ignored tool folders.",
    )
    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    source = Path(args.source).expanduser().resolve()
    if not source.exists():
        parser.error(f"Source path does not exist: {source}")
    if not source.is_dir():
        parser.error(f"Source path must be a directory: {source}")

    output = Path(args.output).expanduser().resolve() if args.output else Path.cwd() / f"{source.name}.bc"
    root_name = args.root_name or source.name

    script = build_scaffold_script(
        source_dir=source,
        root_name=root_name,
        include_hidden=args.include_hidden,
    )
    output.write_text(script, encoding="utf-8", newline="\n")

    print(f"Wrote scaffold: {output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
