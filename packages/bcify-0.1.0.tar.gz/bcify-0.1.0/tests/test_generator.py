from pathlib import Path

from bcify.generator import build_scaffold_script, is_probably_text


def test_build_scaffold_script_skips_binary_and_hidden(tmp_path: Path) -> None:
    project = tmp_path / "sample"
    project.mkdir()
    (project / "src").mkdir()
    (project / ".git").mkdir()
    (project / "README.md").write_text("# Sample\n", encoding="utf-8")
    (project / "src" / "main.py").write_text("print('hi')\n", encoding="utf-8")
    (project / "image.png").write_bytes(b"\x89PNG\r\n\x1a\n\x00\x00binary")
    (project / ".env").write_text("SECRET=test\n", encoding="utf-8")

    script = build_scaffold_script(project, root_name="sample")

    assert 'set-working-folder "sample"' in script
    assert 'make-folder "src"' in script
    assert 'make-file "README.md" with ---' in script
    assert 'make-file "src/main.py" with ---' in script
    assert "image.png" not in script
    assert ".env" not in script


def test_empty_file_is_treated_as_text(tmp_path: Path) -> None:
    empty_file = tmp_path / "empty.txt"
    empty_file.write_text("", encoding="utf-8")

    assert is_probably_text(empty_file) is True
