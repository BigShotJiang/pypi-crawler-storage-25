from ._utils import ew_ret, vw_ret, remove_items, decimal, asterisk, qcut_with_exception
from ._renders import HtmlRenderer, DocxRenderer
from ._double_sorting import MainTable, StrategyTable

import pandas as pd
import numpy as np
import statsmodels.api as sm

from IPython.display import display, HTML


def nw_ttest(df, ret, maxlags, model_cols=[]):
    '''
    newey-west robust t test
    '''
    res_dict = {}

    dependent = df[ret]

    if model_cols:
        independent = sm.add_constant(df[model_cols])
    else:
        independent = pd.Series(np.ones_like(dependent),
                                index=dependent.index, name="const")

    ols_model = sm.OLS(dependent, independent, missing="drop")

    if not maxlags:
        T = ols_model.nobs
        maxlags = int(4 * ((T / 100) ** (2 / 9)))

    reg_res = ols_model.fit(cov_type="HAC",
                            cov_kwds={'maxlags': maxlags}, kernel="bartlett")

    res_dict["mean"] = reg_res.params["const"]
    res_dict["tstats"] = reg_res.tvalues["const"]
    res_dict["pvalue"] = reg_res.pvalues["const"]

    return pd.Series(res_dict)


# ------------------------------------------------------------------
# Private helpers for SummaryTable
# ------------------------------------------------------------------

def _compute_z_spread(quantile_ret, qret, date, sortby_x, sortby_y, sortby_z, strategy_z):
    """
    For each (date, X_group, Y_group), compute the Z spread:
    Z_spread = q_ret(Z=high) - q_ret(Z=low)  [HML] or reversed [LMH].

    Returns a DataFrame with columns [date, sortby_x, sortby_y, 'z_spread'].
    """
    pivot = (
        quantile_ret
        .set_index([date, sortby_x, sortby_y, sortby_z])[qret]
        .unstack(sortby_z)
    )
    # Ensure integer column labels for reliable max/min
    pivot.columns = pivot.columns.astype(int)
    z_max = pivot.columns.max()
    z_min = pivot.columns.min()

    if strategy_z == "HML":
        spread = pivot[z_max] - pivot[z_min]
    elif strategy_z == "LMH":
        spread = pivot[z_min] - pivot[z_max]
    else:
        raise ValueError("Valid strategy_z: 'HML' or 'LMH'")

    spread.name = 'z_spread'
    df = spread.reset_index()
    # Cast group columns to int to avoid Categorical issues downstream
    df[sortby_x] = df[sortby_x].astype(int)
    df[sortby_y] = df[sortby_y].astype(int)
    return df


def _build_wide(z_spread_df, date, sortby_x, sortby_y):
    """
    Pivot z_spread_df to wide format:
        index = (date, sortby_y)
        columns = [x_max, ..., x_min, 'H-L']   (X groups descending, then H-L diff)

    H-L = z_spread(X=max) - z_spread(X=min).

    Returns wide_reset: flat DataFrame with columns [date, sortby_y, x_max, ..., x_min, 'H-L'].
    """
    wide = z_spread_df.pivot_table(
        index=[date, sortby_y], columns=sortby_x,
        values='z_spread', observed=True
    )
    wide.columns = wide.columns.astype(int)
    x_groups = sorted(wide.columns.tolist())
    x_max, x_min = max(x_groups), min(x_groups)

    wide['H-L'] = wide[x_max] - wide[x_min]

    ordered_cols = list(x_groups) + ['H-L']
    return wide[ordered_cols].reset_index()



# ------------------------------------------------------------------
# Sorting approach
# ------------------------------------------------------------------

class TripleSorting(object):
    def __init__(self, data, sortbys, nqs, date, ret, mkt_cap):
        """
        Three-variable sequential portfolio sorting.

        Parameters
        ----------
        data : pd.DataFrame
            Panel data with at least the columns for sortbys, ret, mkt_cap, and date.
        sortbys : list of str, length 3
            Names of the three sorting variables, e.g. ["X", "Y", "Z"].
            Sorting order: X first, then Y conditional on X, then Z conditional on X and Y.
        nqs : list, length 3
            Number of quantile groups (int) or explicit breakpoints (list) for each variable,
            e.g. [3, 5, 5].
        date : str
            Name of the date column.
        ret : str
            Name of the return column.
        mkt_cap : str
            Name of the market-cap column (used for value-weighted returns).
        """
        self.sortbys = sortbys
        self.nqs = nqs

        self.date = date
        self.ret = ret
        self.mkt_cap = mkt_cap

        columns = sortbys + [mkt_cap]
        self.data = data.dropna(subset=columns)
        self.data = self.data.reset_index(drop=True)

        self.data.index.name = "index"
        self.q_ret_name = "q_ret"

    def sorting(self, groupby, sortby, nq):
        # the smaller the label, the smaller the quantile
        n_groups = nq if isinstance(nq, int) else len(nq) - 1
        labels = list(range(1, n_groups + 1))

        groups = self.data.groupby(groupby, observed=False)
        quantiles = groups[sortby].apply(lambda x: qcut_with_exception(x, q=nq, labels=labels))

        quantiles = quantiles.reset_index(level=-1)
        quantiles = quantiles.reset_index(drop=True).set_index("index")
        return quantiles

    def quantile_return(self, groupby, vw):
        if vw:
            ret_func = vw_ret
        else:
            ret_func = ew_ret

        groups = self.data.groupby(groupby, observed=False)
        quantile_ret = groups.apply(lambda x: ret_func(data=x,
                                                       ret_col=self.ret,
                                                       mkt_cap_col=self.mkt_cap))
        quantile_ret.name = self.q_ret_name
        quantile_ret = quantile_ret.reset_index()
        return quantile_ret

    def _run_sequential_sorting(self, vw=False):
        """Shared sorting logic for sequential() and ascontrol()."""
        sortby1, sortby2, sortby3 = self.sortbys
        name1 = sortby1 + "_q"
        name2 = sortby2 + "_q"
        name3 = sortby3 + "_q"
        nq1, nq2, nq3 = self.nqs

        groupby = [self.date]

        self.data[name1] = self.sorting(groupby, sortby1, nq1)
        groupby.append(name1)
        self.data[name2] = self.sorting(groupby, sortby2, nq2)
        groupby.append(name2)
        self.data[name3] = self.sorting(groupby, sortby3, nq3)
        groupby.append(name3)

        quantile_ret = self.quantile_return(groupby, vw=vw)
        quantile_ret = quantile_ret.rename(columns={
            name1: sortby1,
            name2: sortby2,
            name3: sortby3,
        })
        return quantile_ret

    def sequential(self, vw=False):
        """
        Sequential three-variable sorting: X → Y → Z.

        Parameters
        ----------
        vw : bool, default False
            If True, use value-weighted returns; otherwise equal-weighted.

        Returns
        -------
        TripleSortingResults
        """
        sortby1, sortby2, sortby3 = self.sortbys
        quantile_ret = self._run_sequential_sorting(vw=vw)
        notes = [f"Sequential sorting: {sortby1} - {sortby2} - {sortby3}"]
        return TripleSortingResults(quantile_ret, self.q_ret_name,
                                    self.date, self.sortbys, notes)

    def ascontrol(self, vw=False):
        """
        AsControl three-variable sorting: X(moderator) → Y(control) → Z(core).

        Same sequential sorting as sequential(), then for each X group, Y is
        controlled out by averaging Z-group returns across all Y groups within
        each time period.

        Parameters
        ----------
        vw : bool, default False
            If True, use value-weighted returns; otherwise equal-weighted.

        Returns
        -------
        TripleSortingAsControlResults
        """
        sortby1, sortby2, sortby3 = self.sortbys
        quantile_ret = self._run_sequential_sorting(vw=vw)
        notes = [f"AsControl sorting: {sortby1}(moderator) - {sortby2}(control) - {sortby3}(core)"]
        return TripleSortingAsControlResults(quantile_ret, self.q_ret_name,
                                             self.date, self.sortbys, notes)


# ------------------------------------------------------------------
# Results wrapper
# ------------------------------------------------------------------

class TripleSortingResults(object):
    def __init__(self, quantile_ret, qret, date, sortbys, init_notes=[]):
        """
        Parameters
        ----------
        quantile_ret : pd.DataFrame
            Columns: [date, sortby1, sortby2, sortby3, qret]
        qret : str
            Name of the portfolio return column.
        date : str
            Name of the date column.
        sortbys : list of str, length 3
            [X, Y, Z] — the three sorting variable names.
        init_notes : list of str
            Initial footnotes for all tables.
        """
        self.res = quantile_ret
        self.notes = init_notes
        self.sortbys = sortbys
        self.qret = qret
        self.date = date

        self.sortby_x = sortbys[0]
        self.sortbys_yz = sortbys[1:]          # [Y, Z]
        self.x_groups = sorted(quantile_ret[self.sortby_x].dropna().unique())

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _inline_render(self, htmls):
        container = '<div style="display:flex;">'
        for html in htmls:
            container += '<div style="margin-right: 20px;">'
            container += html
            container += '</div>'
        container += '</div>'
        return container

    def _make_table_for_x(self, x_val, rf_df, rf, alpha_models,
                          layout, strategies, raw_ret, **kwargs):
        """
        For a given X-group value, build MainTable and the two StrategyTables
        (for Y and Z) using the same classes as DoubleSorting.
        """
        subset = self.res[self.res[self.sortby_x] == x_val].copy()

        sortby_y, sortby_z = self.sortbys_yz

        main = MainTable(subset, self.qret, rf_df, rf,
                         self.date, self.sortbys_yz,
                         layout=layout, raw_ret=raw_ret, **kwargs)

        if layout == "default":
            orientation_y = "horizontal"
            orientation_z = "vertical"
        elif layout == "reverse":
            orientation_y = "vertical"
            orientation_z = "horizontal"
        else:
            raise ValueError("Valid layout parameter: 'default' or 'reverse'")

        strategy_y = StrategyTable(
            qret_df=subset, qret=self.qret, date=self.date,
            sortby_strategy=sortby_y, sortby_other=sortby_z,
            alpha_models=alpha_models,
            orientation=orientation_y, strategy=strategies[0],
            rf_df=rf_df, rf=rf, **kwargs,
        )

        strategy_z = StrategyTable(
            qret_df=subset, qret=self.qret, date=self.date,
            sortby_strategy=sortby_z, sortby_other=sortby_y,
            alpha_models=alpha_models,
            orientation=orientation_z, strategy=strategies[1],
            rf_df=rf_df, rf=rf, **kwargs,
        )

        return main, strategy_y, strategy_z

    def _html_render_for_x(self, x_val, main, strategy_y, strategy_z,
                           layout, x_notes):
        """Render one X-group block to HTML and display it."""
        header = (
            f'<p style="font-weight:bold; font-size:14px; margin-top:16px;">'
            f'{self.sortby_x} = {x_val}</p>'
        )
        display(HTML(header))

        main_render = HtmlRenderer(main.means, main.tstats,
                                   main.hhead, main.vhead, x_notes)
        main_html = main_render.render()

        render_y = HtmlRenderer(strategy_y.means, strategy_y.tstats,
                                strategy_y.hhead, strategy_y.vhead,
                                strategy_y.notes)
        strategy_y_html = render_y.render()

        render_z = HtmlRenderer(strategy_z.means, strategy_z.tstats,
                                strategy_z.hhead, strategy_z.vhead,
                                strategy_z.notes)
        strategy_z_html = render_z.render()

        if layout == "default":
            html1 = self._inline_render([main_html, strategy_z_html])
            html2 = strategy_y_html
        else:  # reverse
            html1 = self._inline_render([main_html, strategy_y_html])
            html2 = strategy_z_html

        display(HTML(html1))
        display(HTML(html2))

    def _docx_save(self, tables_by_x, x_notes_by_x, summary_table, output_path):
        """Save all X-group tables and the summary table to a single Word document."""
        doc = None
        for x_val, (main, strategy_y, strategy_z) in tables_by_x.items():
            x_notes = x_notes_by_x[x_val]

            main_docx = DocxRenderer(main.means, main.tstats,
                                     main.hhead, main.vhead,
                                     [f"{self.sortby_x} = {x_val}"] + x_notes,
                                     doc=doc)
            doc = main_docx.render()

            sy_docx = DocxRenderer(strategy_y.means, strategy_y.tstats,
                                   strategy_y.hhead, strategy_y.vhead,
                                   strategy_y.notes, doc=doc)
            doc = sy_docx.render()

            sz_docx = DocxRenderer(strategy_z.means, strategy_z.tstats,
                                   strategy_z.hhead, strategy_z.vhead,
                                   strategy_z.notes, doc=doc)
            doc = sz_docx.render()

        # Append summary table
        st_docx = DocxRenderer(summary_table.means, summary_table.tstats,
                               summary_table.hhead, summary_table.vhead,
                               summary_table.notes, doc=doc)
        doc = st_docx.render()

        doc.save(output_path)
        print(f"\n\nFile saved at {output_path}")

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def summary(self, rf_df, rf, alpha_models, layout="default",
                strategies=["HML", "HML"], raw_ret=False, output_path=None,
                **kwargs):
        """
        Display triple-sorting results: one Y-Z double-sorting table per X group,
        followed by a summary table across all X groups.

        Parameters
        ----------
        rf_df : pd.DataFrame
            DataFrame with date column and risk-free rate column.
        rf : str
            Name of the risk-free rate column in rf_df.
        alpha_models : list of pd.DataFrame
            Each DataFrame is a pricing model (e.g. FF3, CH3) with date column and factor columns.
        layout : str, default "default"
            "default" — Y on rows, Z on columns in MainTable.
            "reverse" — Z on rows, Y on columns in MainTable.
        strategies : list of str, length 2, default ["HML", "HML"]
            Strategy ("HML" or "LMH") for [Y, Z] respectively.
        raw_ret : bool, default False
            If True, show raw return in MainTable instead of excess return.
        output_path : str or None
            If provided, save all tables to a Word (.docx) file at this path.
        **kwargs
            show_t, show_stars, show_t_strategy, show_stars_strategy,
            mean_decimal, t_decimal, nw_maxlags, pct_sign, etc.
        """
        ret_note = ("The above table reports raw return"
                    if raw_ret
                    else "The above table reports excess return rather than raw return")

        tables_by_x = {}
        x_notes_by_x = {}

        for x_val in self.x_groups:
            main, strategy_y, strategy_z = self._make_table_for_x(
                x_val, rf_df, rf, alpha_models, layout, strategies, raw_ret, **kwargs
            )
            x_notes = self.notes + [ret_note]

            self._html_render_for_x(x_val, main, strategy_y, strategy_z,
                                    layout, x_notes)

            tables_by_x[x_val] = (main, strategy_y, strategy_z)
            x_notes_by_x[x_val] = x_notes

        # Summary table
        display(HTML(
            '<p style="font-weight:bold; font-size:14px; margin-top:24px;">Summary Table</p>'
        ))
        summary_table = SummaryTable(
            self.res, self.qret, self.date, self.sortbys,
            rf_df, rf, alpha_models,
            strategies=strategies,
            nw_maxlags=kwargs.get('nw_maxlags'),
            **kwargs,
        )
        summary_render = HtmlRenderer(summary_table.means, summary_table.tstats,
                                      summary_table.hhead, summary_table.vhead,
                                      summary_table.notes)
        display(HTML(summary_render.render()))

        if output_path:
            self._docx_save(tables_by_x, x_notes_by_x, summary_table, output_path)


# ------------------------------------------------------------------
# Summary table
# ------------------------------------------------------------------

class SummaryTable(object):
    """
    Aggregated view of triple-sorting results.

    Rows: Y groups (Q1 … QN) + H-L + alpha rows
    Cols: High X | [Mid X …] | Low X | Diff

    Each cell shows the Z spread (H-L or L-H of Z) for that (X, Y) bucket,
    averaged over time with a Newey-West t-statistic.
    Diff = Z_spread(High X) − Z_spread(Low X) for each Y group.
    H-L row = Z_spread(Y high) − Z_spread(Y low) for each X column.
    """

    def __init__(self, quantile_ret, qret, date, sortbys,
                 rf_df, rf, alpha_models,
                 strategies=["HML", "HML"],
                 pct_sign=True, nw_maxlags=None, **kwargs):

        sortby_x, sortby_y, sortby_z = sortbys
        strategy_y, strategy_z = strategies
        self.pct_sign = '%' if pct_sign else ''
        self.alpha_prefix = "alpha "

        # Step 1: Z spread time series for each (date, X, Y)
        z_spread_df = _compute_z_spread(
            quantile_ret, qret, date, sortby_x, sortby_y, sortby_z, strategy_z
        )

        # Step 2: Wide table — index=(date, Y), columns=(X groups desc + 'H-L')
        wide_reset = _build_wide(z_spread_df, date, sortby_x, sortby_y)

        # data_cols: [x_max, ..., x_min, 'H-L'] — used as column keys and labels directly
        data_cols = [c for c in wide_reset.columns if c not in [date, sortby_y]]
        y_groups = sorted(wide_reset[sortby_y].dropna().unique().astype(int))

        # Step 3: NW t-test for each (Y_group, column) cell
        q_results = self._test_q_rows(wide_reset, sortby_y, y_groups, data_cols, nw_maxlags)

        # Step 4: H-L time series across Y groups + NW t-test
        hl_data = self._compute_hl(wide_reset, date, sortby_y, y_groups, data_cols, strategy_y)
        hl_results = self._test_hl(hl_data, data_cols, nw_maxlags)

        # Step 5: Alpha of H-L against each factor model
        alpha_results = self._test_alpha(hl_data, date, data_cols, alpha_models, nw_maxlags)

        # Step 6: Assemble means/tstats DataFrames
        # Row labels: integers (1,2,...) + 'H-L' — same style as MainTable
        y_labels = list(y_groups)

        self.means, self.tstats = self._build_tables(
            q_results, hl_results, alpha_results,
            y_labels, data_cols, y_groups, data_cols, **kwargs
        )

        strategy_z_desc = "High minus Low" if strategy_z == "HML" else "Low minus High"
        strategy_y_desc = "High minus Low" if strategy_y == "HML" else "Low minus High"
        # hhead = X variable name; hlabel = [x_max,...,x_min,'H-L'] — same style as double sorting
        self.hhead = sortby_x
        self.vhead = sortby_y
        self.notes = [
            f"The above table reports {sortby_z} spread",
            f"{sortby_z} spread: {strategy_z_desc}",
            f"H-L ({sortby_y}) strategy: {strategy_y_desc}",
            f"H-L (col) = {sortby_z} spread(High {sortby_x}) - {sortby_z} spread(Low {sortby_x})",
        ]

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _test_q_rows(self, wide_reset, sortby_y, y_groups, data_cols, maxlags):
        """NW t-test for each (Y_group, data_col) cell."""
        results = {}
        for y_val in y_groups:
            subset = wide_reset[wide_reset[sortby_y] == y_val]
            results[y_val] = {}
            for col in data_cols:
                series = subset[col].dropna()
                df = pd.DataFrame({'ret': series.values})
                results[y_val][col] = nw_ttest(df, 'ret', maxlags)
        return results

    def _compute_hl(self, wide_reset, date, sortby_y, y_groups, data_cols, strategy_y):
        """
        Compute H-L time series across Y groups for each data column.
        Returns a DataFrame indexed by date.
        """
        y_max = max(y_groups)
        y_min = min(y_groups)

        high = wide_reset[wide_reset[sortby_y] == y_max].set_index(date)[data_cols]
        low = wide_reset[wide_reset[sortby_y] == y_min].set_index(date)[data_cols]

        if strategy_y == "HML":
            return high - low
        else:
            return low - high

    def _test_hl(self, hl_data, data_cols, maxlags):
        """NW t-test for each H-L data column."""
        results = {}
        for col in data_cols:
            series = hl_data[col].dropna()
            df = pd.DataFrame({'ret': series.values})
            results[col] = nw_ttest(df, 'ret', maxlags)
        return results

    def _test_alpha(self, hl_data, date, data_cols, alpha_models, maxlags):
        """Compute alpha of H-L series against each factor model."""
        alpha_results = {}
        for n, model in enumerate(alpha_models):
            alpha_name = self.alpha_prefix + str(n + 1)
            alpha_results[alpha_name] = {}
            model_cols = remove_items([date], model.columns)
            for col in data_cols:
                hl_df = hl_data[col].reset_index()
                hl_df.columns = [date, 'ret']
                merged = hl_df.merge(model, on=date, how='left')
                alpha_results[alpha_name][col] = nw_ttest(
                    merged, 'ret', maxlags, model_cols=model_cols
                )
        return alpha_results

    def _fmt_mean(self, value, show_stars, pvalue, mean_decimal):
        s = decimal(value * 100, mean_decimal) + self.pct_sign
        if show_stars:
            s += asterisk(pvalue)
        return s

    def _fmt_t(self, value, show_t, t_decimal):
        if show_t:
            return f"({decimal(value, t_decimal)})"
        return "-"

    def _build_tables(self, q_results, hl_results, alpha_results,
                      y_labels, x_labels, y_groups, data_cols,
                      mean_decimal=3, t_decimal=3,
                      show_t=False,
                      **kwargs):
        """Assemble formatted means and tstats DataFrames.
        show_stars is always True for SummaryTable (not user-configurable).
        show_t follows the caller's parameter.
        """
        show_stars = True  # always show significance stars in SummaryTable
        means_rows = {}
        tstats_rows = {}

        # Q rows
        for y_val, y_label in zip(y_groups, y_labels):
            m_row, t_row = {}, {}
            for col, col_label in zip(data_cols, x_labels):
                res = q_results[y_val][col]
                m_row[col_label] = self._fmt_mean(
                    res['mean'], show_stars, res['pvalue'], mean_decimal
                )
                t_row[col_label] = self._fmt_t(res['tstats'], show_t, t_decimal)
            means_rows[y_label] = m_row
            tstats_rows[y_label] = t_row

        # H-L row
        m_row, t_row = {}, {}
        for col, col_label in zip(data_cols, x_labels):
            res = hl_results[col]
            m_row[col_label] = self._fmt_mean(
                res['mean'], show_stars, res['pvalue'], mean_decimal
            )
            t_row[col_label] = self._fmt_t(res['tstats'], show_t, t_decimal)
        means_rows['H-L'] = m_row
        tstats_rows['H-L'] = t_row

        # Alpha rows
        for alpha_name, alpha_vals in alpha_results.items():
            m_row, t_row = {}, {}
            for col, col_label in zip(data_cols, x_labels):
                res = alpha_vals[col]
                m_row[col_label] = self._fmt_mean(
                    res['mean'], show_stars, res['pvalue'], mean_decimal
                )
                t_row[col_label] = self._fmt_t(res['tstats'], show_t, t_decimal)
            means_rows[alpha_name] = m_row
            tstats_rows[alpha_name] = t_row

        means_df = pd.DataFrame(means_rows).T
        tstats_df = pd.DataFrame(tstats_rows).T
        return means_df, tstats_df


# ------------------------------------------------------------------
# AsControl results wrapper
# ------------------------------------------------------------------

class TripleSortingAsControlResults(object):
    """
    Results wrapper for TripleSorting.ascontrol().

    For each X group, Y is controlled out by averaging Z-group returns
    across Y groups within each time period. Each X-group table is a
    SingleSortingResults for the Z variable.
    """

    def __init__(self, quantile_ret, qret, date, sortbys, init_notes=[]):
        self.res = quantile_ret
        self.notes = init_notes
        self.sortbys = sortbys
        self.qret = qret
        self.date = date

        self.sortby_x = sortbys[0]
        self.sortby_y = sortbys[1]
        self.sortby_z = sortbys[2]
        self.x_groups = sorted(quantile_ret[self.sortby_x].dropna().unique())

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _make_ascontrol_for_x(self, x_val):
        """
        For X group x_val: average Z-group returns over all Y groups within
        each time period, returning a SingleSortingResults for Z.
        """
        from ._single_sorting import SortingResults as SingleSortingResults

        subset = self.res[self.res[self.sortby_x] == x_val].copy()

        ascontrol_ret = (
            subset
            .groupby([self.date, self.sortby_z], observed=False)[self.qret]
            .mean()
            .reset_index()
        )

        notes = [
            f"{self.sortby_x} = {x_val}",
            f"{self.sortby_y} controlled, {self.sortby_z} as main variable",
        ]
        return SingleSortingResults(ascontrol_ret, self.qret,
                                    self.date, self.sortby_z, notes)

    def _html_render_for_x(self, x_val, single_result,
                           rf_df, rf, alpha_models, strategy_z,
                           raw_ret, **kwargs):
        """Display ascontrol result for one X group."""
        header = (
            f'<p style="font-weight:bold; font-size:14px; margin-top:16px;">'
            f'{self.sortby_x} = {x_val}</p>'
        )
        display(HTML(header))

        single_result._make_table(
            rf_df=rf_df, rf=rf, alpha_models=alpha_models,
            layout="default", strategies=strategy_z,
            raw_ret=raw_ret, **kwargs,
        )
        single_result._html_render()

    def _docx_save(self, tables_by_x, summary_table, output_path):
        """Save all X-group tables and summary table to a Word document."""
        doc = None
        for x_val, single_result in tables_by_x.items():
            main = single_result.main
            s1 = single_result.strategies

            main_docx = DocxRenderer(main.means, main.tstats,
                                     main.hhead, main.vhead,
                                     single_result.notes + main.notes,
                                     doc=doc)
            doc = main_docx.render()

            s1_docx = DocxRenderer(s1.means, s1.tstats,
                                   s1.hhead, s1.vhead,
                                   s1.notes, doc=doc)
            doc = s1_docx.render()

        st_docx = DocxRenderer(summary_table.means, summary_table.tstats,
                               summary_table.hhead, summary_table.vhead,
                               summary_table.notes, doc=doc)
        doc = st_docx.render()

        doc.save(output_path)
        print(f"\n\nFile saved at {output_path}")

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def summary(self, rf_df, rf, alpha_models, strategy_z="HML",
                raw_ret=False, output_path=None, **kwargs):
        """
        Display ascontrol results: one Z SingleSorting table per X group
        (with Y controlled out), followed by an AsControlSummaryTable.

        Parameters
        ----------
        rf_df : pd.DataFrame
            DataFrame with date and risk-free rate columns.
        rf : str
            Name of the risk-free rate column.
        alpha_models : list of pd.DataFrame
            Factor model DataFrames for alpha computation.
        strategy_z : str, default "HML"
            Strategy for the Z (core) variable: "HML" or "LMH".
        raw_ret : bool, default False
            If True, show raw return; otherwise excess return.
        output_path : str or None
            If provided, save all tables to a .docx file.
        **kwargs
            show_t, show_stars, mean_decimal, t_decimal, nw_maxlags, etc.
        """
        tables_by_x = {}

        for x_val in self.x_groups:
            single_result = self._make_ascontrol_for_x(x_val)
            self._html_render_for_x(x_val, single_result,
                                    rf_df, rf, alpha_models, strategy_z,
                                    raw_ret, **kwargs)
            tables_by_x[x_val] = single_result

        display(HTML(
            '<p style="font-weight:bold; font-size:14px; margin-top:24px;">Summary Table</p>'
        ))
        summary_table = AsControlSummaryTable(
            self.res, self.qret, self.date, self.sortbys,
            rf_df, rf, alpha_models,
            strategy_z=strategy_z,
            nw_maxlags=kwargs.get('nw_maxlags'),
            **kwargs,
        )
        summary_render = HtmlRenderer(summary_table.means, summary_table.tstats,
                                      summary_table.hhead, summary_table.vhead,
                                      summary_table.notes)
        display(HTML(summary_render.render()))

        if output_path:
            self._docx_save(tables_by_x, summary_table, output_path)


# ------------------------------------------------------------------
# AsControl summary table
# ------------------------------------------------------------------

class AsControlSummaryTable(object):
    """
    Summary table for TripleSorting.ascontrol().

    Rows: Z groups (1…k) + H-L + alpha rows
    Cols: X groups (1…n, ascending) + H-L

    Each cell (X_j, Z_i): time-averaged ascontrol return of Z group i within
    X group j, after averaging out Y.  H-L col = X_high − X_low.
    H-L row = Z_high − Z_low (time-series difference, then averaged).
    """

    def __init__(self, quantile_ret, qret, date, sortbys,
                 rf_df, rf, alpha_models,
                 strategy_z="HML",
                 pct_sign=True, nw_maxlags=None, **kwargs):

        sortby_x, sortby_y, sortby_z = sortbys
        self.pct_sign = '%' if pct_sign else ''
        self.alpha_prefix = "alpha "

        # Step 1: average over Y for each (date, X, Z)
        ascontrol_df = (
            quantile_ret
            .groupby([date, sortby_x, sortby_z], observed=False)[qret]
            .mean()
            .reset_index()
        )
        ascontrol_df[sortby_x] = ascontrol_df[sortby_x].astype(int)
        ascontrol_df[sortby_z] = ascontrol_df[sortby_z].astype(int)

        # Step 2: pivot wide — rows=(date, Z), cols=X_groups
        wide = ascontrol_df.pivot_table(
            index=[date, sortby_z], columns=sortby_x,
            values=qret, observed=True
        )
        wide.columns = wide.columns.astype(int)
        x_groups = sorted(wide.columns.tolist())
        x_max, x_min = max(x_groups), min(x_groups)

        # Step 3: H-L column = X_high − X_low (time-series difference)
        wide['H-L'] = wide[x_max] - wide[x_min]
        ordered_cols = list(x_groups) + ['H-L']
        wide_reset = wide[ordered_cols].reset_index()
        data_cols = [c for c in wide_reset.columns if c not in [date, sortby_z]]

        z_groups = sorted(wide_reset[sortby_z].dropna().unique().astype(int))

        # Step 4: NW t-test for each (Z_group, col) cell
        q_results = self._test_q_rows(wide_reset, sortby_z, z_groups, data_cols, nw_maxlags)

        # Step 5: H-L row — Z_high minus Z_low time series
        hl_data = self._compute_hl(wide_reset, date, sortby_z, z_groups, data_cols, strategy_z)
        hl_results = self._test_hl(hl_data, data_cols, nw_maxlags)

        # Step 6: alpha rows
        alpha_results = self._test_alpha(hl_data, date, data_cols, alpha_models, nw_maxlags)

        # Step 7: assemble
        z_labels = list(z_groups)
        self.means, self.tstats = self._build_tables(
            q_results, hl_results, alpha_results,
            z_labels, data_cols, z_groups, data_cols, **kwargs
        )

        strategy_z_desc = "High minus Low" if strategy_z == "HML" else "Low minus High"
        self.hhead = sortby_x
        self.vhead = sortby_z
        self.notes = [
            f"The above table reports {sortby_z} return after controlling {sortby_y}",
            f"{sortby_z} H-L strategy: {strategy_z_desc}",
            f"H-L (col) = ascontrol {sortby_z} return(High {sortby_x}) - ascontrol {sortby_z} return(Low {sortby_x})",
        ]

    # ------------------------------------------------------------------
    # Internal helpers (mirror SummaryTable, adapted for Z rows)
    # ------------------------------------------------------------------

    def _test_q_rows(self, wide_reset, sortby_z, z_groups, data_cols, maxlags):
        results = {}
        for z_val in z_groups:
            subset = wide_reset[wide_reset[sortby_z] == z_val]
            results[z_val] = {}
            for col in data_cols:
                series = subset[col].dropna()
                df = pd.DataFrame({'ret': series.values})
                results[z_val][col] = nw_ttest(df, 'ret', maxlags)
        return results

    def _compute_hl(self, wide_reset, date, sortby_z, z_groups, data_cols, strategy_z):
        z_max = max(z_groups)
        z_min = min(z_groups)

        high = wide_reset[wide_reset[sortby_z] == z_max].set_index(date)[data_cols]
        low  = wide_reset[wide_reset[sortby_z] == z_min].set_index(date)[data_cols]

        if strategy_z == "HML":
            return high - low
        else:
            return low - high

    def _test_hl(self, hl_data, data_cols, maxlags):
        results = {}
        for col in data_cols:
            series = hl_data[col].dropna()
            df = pd.DataFrame({'ret': series.values})
            results[col] = nw_ttest(df, 'ret', maxlags)
        return results

    def _test_alpha(self, hl_data, date, data_cols, alpha_models, maxlags):
        alpha_results = {}
        for n, model in enumerate(alpha_models):
            alpha_name = self.alpha_prefix + str(n + 1)
            alpha_results[alpha_name] = {}
            model_cols = remove_items([date], model.columns)
            for col in data_cols:
                hl_df = hl_data[col].reset_index()
                hl_df.columns = [date, 'ret']
                merged = hl_df.merge(model, on=date, how='left')
                alpha_results[alpha_name][col] = nw_ttest(
                    merged, 'ret', maxlags, model_cols=model_cols
                )
        return alpha_results

    def _fmt_mean(self, value, show_stars, pvalue, mean_decimal):
        s = decimal(value * 100, mean_decimal) + self.pct_sign
        if show_stars:
            s += asterisk(pvalue)
        return s

    def _fmt_t(self, value, show_t, t_decimal):
        if show_t:
            return f"({decimal(value, t_decimal)})"
        return "-"

    def _build_tables(self, q_results, hl_results, alpha_results,
                      z_labels, x_labels, z_groups, data_cols,
                      mean_decimal=3, t_decimal=3,
                      show_t=False, **kwargs):
        show_stars = True  # always show stars in summary tables
        means_rows = {}
        tstats_rows = {}

        for z_val, z_label in zip(z_groups, z_labels):
            m_row, t_row = {}, {}
            for col, col_label in zip(data_cols, x_labels):
                res = q_results[z_val][col]
                m_row[col_label] = self._fmt_mean(res['mean'], show_stars, res['pvalue'], mean_decimal)
                t_row[col_label] = self._fmt_t(res['tstats'], show_t, t_decimal)
            means_rows[z_label] = m_row
            tstats_rows[z_label] = t_row

        m_row, t_row = {}, {}
        for col, col_label in zip(data_cols, x_labels):
            res = hl_results[col]
            m_row[col_label] = self._fmt_mean(res['mean'], show_stars, res['pvalue'], mean_decimal)
            t_row[col_label] = self._fmt_t(res['tstats'], show_t, t_decimal)
        means_rows['H-L'] = m_row
        tstats_rows['H-L'] = t_row

        for alpha_name, alpha_vals in alpha_results.items():
            m_row, t_row = {}, {}
            for col, col_label in zip(data_cols, x_labels):
                res = alpha_vals[col]
                m_row[col_label] = self._fmt_mean(res['mean'], show_stars, res['pvalue'], mean_decimal)
                t_row[col_label] = self._fmt_t(res['tstats'], show_t, t_decimal)
            means_rows[alpha_name] = m_row
            tstats_rows[alpha_name] = t_row

        means_df = pd.DataFrame(means_rows).T
        tstats_df = pd.DataFrame(tstats_rows).T
        return means_df, tstats_df
