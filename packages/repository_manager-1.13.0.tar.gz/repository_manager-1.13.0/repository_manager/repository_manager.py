#!/usr/bin/env python


"""
A command-line tool for managing Git repositories, supporting cloning and pulling
multiple repositories in parallel using Python's multiprocessing capabilities.
"""

import argparse
import datetime
import json
import os
import re
import subprocess
import sys
import threading
from pathlib import Path
from typing import Any

__version__ = "1.13.0"

import concurrent.futures
import select
import shutil
import signal

import yaml
from agent_utilities.base_utilities import get_library_file_path, to_boolean

try:
    from skill_graphs.skill_graph_utilities import get_skill_graphs_path
    from universal_skills.skill_utilities import get_universal_skills_path
except ImportError:
    get_universal_skills_path = None
    get_skill_graphs_path = None

from importlib.resources import files

from agent_utilities.base_utilities import get_logger

from repository_manager.models import (
    GitError,
    GitMetadata,
    GitResult,
    IncrementalReportWriter,
    MaintenanceConfig,
    ReadmeResult,
    SubdirectoryConfig,
    ValidationReport,
    WorkspaceConfig,
)

logger = get_logger("RepositoryManager")


def get_packaged_file_path(package: str, file: str) -> str:
    """Robustly find a file in a package using importlib.resources."""
    try:
        path = files(package).joinpath(file)
        if path.is_file():
            return str(path)
    except Exception:  # nosec B110
        pass

    local_path = os.path.join(os.path.dirname(__file__), file)
    if os.path.exists(local_path):
        return local_path

    return get_library_file_path(file=file)


# Robust environment variable retrieval with empty string fallbacks
_raw_workspace = os.getenv("REPOSITORY_MANAGER_WORKSPACE", "")
DEFAULT_REPOSITORY_MANAGER_WORKSPACE = os.path.abspath(
    os.path.expanduser(_raw_workspace if _raw_workspace else "/home/apps/workspace")
)

_raw_yml = os.getenv("WORKSPACE_YML", "")
DEFAULT_WORKSPACE_YML = (
    _raw_yml
    if _raw_yml
    else get_packaged_file_path("repository_manager", "workspace.yml")
)

_raw_threads = os.getenv("REPOSITORY_MANAGER_THREADS", "")
DEFAULT_REPOSITORY_MANAGER_THREADS = int(
    _raw_threads if _raw_threads and _raw_threads.isdigit() else "6"
)

_raw_branch = os.getenv("REPOSITORY_MANAGER_DEFAULT_BRANCH", "")
DEFAULT_REPOSITORY_MANAGER_DEFAULT_BRANCH = to_boolean(
    _raw_branch if _raw_branch else "False"
)


class Git:
    """A class to handle Git operations such as cloning and pulling repositories."""

    def __init__(
        self,
        path: str | None = None,
        threads: int | None = None,
        set_to_default_branch: bool = False,
        capture_output: bool = False,
        report_path: str | None = None,
    ):
        """Initialize the Git class with default settings."""
        self._explicit_path = path is not None
        self.path = path or DEFAULT_REPOSITORY_MANAGER_WORKSPACE
        self.report_path = report_path
        if not os.path.exists(self.path):
            try:
                os.makedirs(self.path, exist_ok=True)
            except Exception:  # nosec B110
                pass

        self.project_map: dict[str, str] = {}
        self.config: WorkspaceConfig | None = None
        self.threads = threads or DEFAULT_REPOSITORY_MANAGER_THREADS
        self.set_to_default_branch = set_to_default_branch
        self.capture_output = capture_output
        self.maximum_threads = 36
        if threads:
            self.set_threads(threads=threads)

        self.debug_log_path = os.path.join(self.path, "repository_manager_debug.log")
        self.debug_lock = threading.Lock()
        self.python_exe = self._find_python()

        # Initialize log file
        with open(self.debug_log_path, "a") as f:
            f.write(f"\n\n--- NEW SESSION: {datetime.datetime.now().isoformat()} ---\n")

    def _find_python(self) -> str:
        """Finds the best Python executable to use for validation."""
        venv_path = os.path.join(self.path, ".venv", "bin", "python3")
        if os.path.exists(venv_path):
            return venv_path
        return sys.executable

    def _get_pip_command(self, extra: str = "all") -> str:
        """Get the appropriate pip install command, preferring uv if available."""
        import shutil

        pip_cmd = "pip"
        if shutil.which("uv"):
            pip_cmd = "uv pip"

        return f"{pip_cmd} install --break-system-packages -e '.[{extra}]'"

    def _get_package_manager(self, path: str) -> str:
        """Determines the appropriate package manager for a given path."""
        if os.path.exists(os.path.join(path, "pnpm-lock.yaml")):
            return "pnpm"
        if os.path.exists(os.path.join(path, "yarn.lock")):
            return "yarn"
        return "npm"

    def setup_from_yaml(self, yaml_path: str) -> GitResult:
        """Sets up the workspace structure from a YAML file."""
        abs_yaml_path = os.path.abspath(os.path.expanduser(yaml_path))
        if not os.path.exists(abs_yaml_path):
            return GitResult(
                status="error",
                data="",
                error=GitError(message=f"YAML not found: {abs_yaml_path}", code=1),
            )

        if not self.load_projects_from_yaml(abs_yaml_path):
            return GitResult(
                status="error",
                data="",
                error=GitError(message="Failed to load YAML", code=1),
            )

        logger.info(f"Creating workspace structure at {self.path}...")
        os.makedirs(self.path, exist_ok=True)

        for _, project_path in self.project_map.items():
            os.makedirs(os.path.dirname(project_path), exist_ok=True)

        logger.info("Syncing repositories (Clone/Pull)...")
        results = []
        for url, project_path in self.project_map.items():
            if os.path.exists(project_path):
                results.append(self.pull_project(project_path))
            else:
                results.append(self.clone_repository(url, project_path))

        return GitResult(
            status="success",
            data=f"Workspace setup completed at {self.path}",
            metadata=GitMetadata(
                command="setup_workspace",
                workspace=self.path,
                return_code=0,
                timestamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
                + "Z",
            ),
        )

    def generate_workspace_tree(self, yaml_path: str | None = None) -> str:
        """Generates an ASCII tree of the workspace defined in YAML."""
        if yaml_path:
            self.load_projects_from_yaml(yaml_path)

        if not hasattr(self, "config") or not self.config:
            return "No workspace configuration loaded."

        lines = [f"Workspace: {self.config.name}", f"Root: {self.path}", ""]

        def _build_tree(subdirs, indent=""):
            for name, data in subdirs.items():
                lines.append(f"{indent}├── {name}/")
                new_indent = indent + "│   "
                for repo in data.repositories:
                    repo_name = repo.url.split("/")[-1].replace(".git", "")
                    lines.append(f"{new_indent}└── {repo_name} ({repo.url})")
                if data.subdirectories:
                    _build_tree(data.subdirectories, new_indent)

        _build_tree(self.config.subdirectories)
        return "\n".join(lines)

    def generate_workspace_mermaid(self, yaml_path: str | None = None) -> str:
        """Generates a Mermaid diagram of the workspace defined in YAML."""
        if yaml_path:
            self.load_projects_from_yaml(yaml_path)

        if not hasattr(self, "config") or not self.config:
            return "No workspace configuration loaded."

        lines = ["graph TD", f'    Root["{self.config.name}"]']

        def _build_mermaid(subdirs, parent_node):
            for name, data in subdirs.items():
                node_id = name.replace("-", "_")
                lines.append(f'    {parent_node} --> {node_id}["{name}/"]')
                for repo in data.repositories:
                    repo_name = repo.url.split("/")[-1].replace(".git", "")
                    repo_id = repo_name.replace("-", "_")
                    lines.append(f'    {node_id} --> {repo_id}["{repo_name}"]')
                if data.subdirectories:
                    _build_mermaid(data.subdirectories, node_id)

        _build_mermaid(self.config.subdirectories, "Root")
        return "\n".join(lines)

    def generate_agents_md(self, target_path: str | None = None) -> GitResult:
        """
        Generates/Updates the AGENTS.md catalog in the workspace root.
        """
        return self.generate_agents_documentation(target_path)

    def get_project_map(self) -> dict[str, str]:
        """
        Returns the mapping of repository URLs to their local project paths.
        Ensures paths are absolute and expanded.
        """
        return {
            url: os.path.abspath(os.path.expanduser(p))
            for url, p in self.project_map.items()
        }

    def get_workspace_projects(self) -> list[str]:
        """Returns a list of project basenames (e.g. 'genius-agent') defined in the workspace."""
        return [os.path.basename(p) for p in self.project_map.values()]

    async def _get_intelligence_engine(self, path: str | None = None) -> Any:
        """Helper to get a graph engine, reusing an active one if available."""
        from agent_utilities.knowledge_graph.engine import RegistryGraphEngine as Engine

        active = Engine.get_active()
        if active:
            return active

        from agent_utilities.knowledge_graph.pipeline import IntelligencePipeline
        from agent_utilities.models.knowledge_graph import PipelineConfig

        root = self._resolve_path(path)
        config = PipelineConfig(workspace_path=root)
        pipeline = IntelligencePipeline(config)
        await pipeline.run()
        return Engine(pipeline.graph)

    def _get_intelligence_engine_sync(self, path: str | None = None) -> Any:
        """Synchronous version of _get_intelligence_engine."""
        import asyncio

        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

        if loop.is_running():
            # If loop is already running, we can't run_until_complete.
            # We try to get the active engine or create one without a full pipeline run if possible.
            from agent_utilities.knowledge_graph.engine import (
                RegistryGraphEngine as Engine,
            )

            active = Engine.get_active()
            if active:
                return active
            # Fallback: create an empty engine (better than crashing)
            import networkx as nx

            return Engine(nx.MultiDiGraph())

        return loop.run_until_complete(self._get_intelligence_engine(path))

    async def graph_query(
        self, query: str, mode: str = "hybrid", path: str | None = None
    ) -> list[dict[str, Any]]:
        """Queries the Hybrid Graph using vector similarity or Cypher structure."""
        engine = await self._get_intelligence_engine(path)

        if mode == "structural":
            return engine.query_cypher(query)
        return engine.search_hybrid(query)

    def graph_path(
        self, source_id: str, target_id: str, path: str | None = None
    ) -> list[str]:
        """Finds the shortest path between two symbols across the workspace graph."""
        engine = self._get_intelligence_engine_sync(path)
        return engine.find_path(source_id, target_id)

    def graph_status(self, path: str | None = None) -> dict[str, Any]:
        """Returns the current status of the workspace graph."""
        engine = self._get_intelligence_engine_sync(path)
        # Re-run pipeline to get fresh metadata if needed?
        # For now, we return what we have.
        metadata = {
            "nodes": engine.graph.number_of_nodes(),
            "edges": engine.graph.number_of_edges(),
        }
        return metadata

    def graph_reset(self, path: str | None = None) -> str:
        """Purges the graph database and Forces a clean rebuild on next build."""
        root = self._resolve_path(path)
        repo_graph_dir = os.path.join(root, ".repo_graph")
        if os.path.exists(repo_graph_dir):
            import shutil

            shutil.rmtree(repo_graph_dir)

        # Also check for ladybug db
        ladybug_db = os.path.join(root, ".ladybug")
        if os.path.exists(ladybug_db):
            import shutil

            shutil.rmtree(ladybug_db)

        return "Graph database purged successfully."

    async def graph_impact(
        self, symbol: str, group_name: str | None = None, path: str | None = None
    ) -> list[dict[str, Any]]:
        """Calculates multi-repo impact for a symbol using the GraphEngine."""
        engine = await self._get_intelligence_engine(path)
        return engine.query_impact(symbol)

    def _resolve_path(self, path: str | None = None) -> str:
        """
        Resolve the path to an absolute path.
        If path is None, returns self.path.
        If path is absolute, returns it.
        If path is relative, joins it with self.path.
        """
        if path is None:
            return os.path.abspath(self.path)

        if os.path.isabs(path):
            return os.path.abspath(path)

        return os.path.abspath(os.path.join(self.path, path))

    def install_projects(
        self, extra: str = "all", threads: int | None = None, report: bool = True
    ) -> list[GitResult]:
        """Bulk installs Python and Node projects in the workspace."""
        threads = threads or self.threads
        if not self.project_map:
            logger.warning("No projects to install.")
            return []

        logger.info("Installing ecosystem using native uv workspace sync...")
        results = []

        import datetime
        import shutil

        # 1. Sync Python Ecosystem natively using uv workspace
        if shutil.which("uv"):
            cmd = "uv sync --all-packages"
            # execute at base_path where it will find the workspace pyproject.toml
            res = self.git_action(cmd, path=self.path)

            # Generate parity reporting for each Python project
            for _url, path in self.project_map.items():
                is_python = os.path.exists(
                    os.path.join(path, "pyproject.toml")
                ) or os.path.exists(os.path.join(path, "setup.py"))
                if not is_python:
                    continue

                pkg_result = GitResult(
                    status=res.status,
                    data=res.data,
                    error=res.error,
                    metadata=GitMetadata(
                        command="install",
                        workspace=path,
                        return_code=res.metadata.return_code if res.metadata else 0,
                        timestamp=datetime.datetime.now(
                            datetime.timezone.utc
                        ).isoformat()
                        + "Z",
                    ),
                )
                results.append(pkg_result)
        else:
            logger.warning("uv not found. Native workspace sync requires uv.")

        # 2. Install Node Ecosystem sequentially
        for _url, path in self.project_map.items():
            is_node = os.path.exists(os.path.join(path, "package.json"))
            if is_node:
                pm = self._get_package_manager(path)
                res = self.git_action(f"{pm} install", path=path)
                if pm == "pnpm" and "Ignored build scripts:" in res.data:
                    res.status = "error"
                    res.data = f"pnpm install succeeded but ignored build scripts:\n{res.data}\nPlease add allowed dependencies to package.json."
                results.append(res)

        successes = [r for r in results if r.status == "success"]
        failures = [r for r in results if r.status == "error"]

        report_md = "# INSTALLATION SUMMARY\n"
        report_md += (
            f"**Time:** {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}  \n"
        )
        report_md += f"**Total:** {len(results)} | **Success:** {len(successes)} ✅ | **Failure:** {len(failures)} ❌\n\n"

        if successes:
            report_md += "## Successes ✅\n"
            for r in successes:
                pkg = "unknown"
                if r.metadata:
                    pkg = r.metadata.workspace.split("/")[-1]
                report_md += f"- **{pkg}**: Installation success\n"

        if failures:
            report_md += "\n## Failures ❌\n"
            for r in failures:
                pkg = "unknown"
                if r.metadata:
                    pkg = r.metadata.workspace.split("/")[-1]
                error_msg = r.error.message if r.error else r.data
                report_md += f"- **{pkg}**: {error_msg}\n"

        if self.report_path and report:
            self._export_report(report_md, "install_report.md")

        return results

    def build_projects(self, threads: int | None = None) -> list[GitResult]:
        """Bulk builds Python and Node.js projects in the workspace."""
        threads = threads or self.threads
        if not self.project_map:
            logger.warning("No projects to build.")
            return []

        logger.info(
            f"Building {len(self.project_map)} projects in parallel ({threads} threads)..."
        )
        with concurrent.futures.ThreadPoolExecutor(max_workers=threads) as executor:
            futures = []
            for _url, path in self.project_map.items():
                if os.path.exists(os.path.join(path, "package.json")):
                    pm = self._get_package_manager(path)
                    cmd = f"{pm} install && {pm} run build"
                else:
                    cmd = f"{sys.executable} -m build"
                futures.append(executor.submit(self.git_action, cmd, path=path))
            return [f.result() for f in concurrent.futures.as_completed(futures)]

    def validate_projects(
        self,
        type: str = "all",
        threads: int | None = None,
        output_dir: str | None = None,
    ) -> ValidationReport:
        """Bulk validates agent/MCP servers using various modes (help, static, runtime).

        When ``output_dir`` is provided, validation results are written incrementally
        to a ``validation-reports-<timestamp>/`` directory structure under that path.
        Each scan phase writes its per-repo files immediately upon completion so
        results are available before the full run finishes.
        """
        threads = threads or self.threads
        if not self.project_map:
            logger.warning("No projects to validate.")
            return ValidationReport.from_results([])

        logger.info(
            f"Validating {len(self.project_map)} projects (mode={type}) in parallel ({threads} threads)..."
        )

        # Initialize incremental report writer if output directory is specified
        report_output = output_dir or (self.path if self.report_path else None)
        writer = (
            IncrementalReportWriter(output_dir=report_output) if report_output else None
        )

        run_all = type in ["all", "flat", "graph"]
        results = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=threads) as executor:
            agent_targets = []
            for url, path in self.project_map.items():
                pkg_name = url.split("/")[-1].replace(".git", "")
                pkg_underscore = pkg_name.replace("-", "_")

                pkg_dir = os.path.join(path, pkg_underscore)
                if not os.path.exists(pkg_dir):
                    for sub in ["src", "agent"]:
                        candidate = os.path.join(path, sub, pkg_underscore)
                        if os.path.exists(candidate):
                            pkg_dir = candidate
                            break

                agent_file = None
                if os.path.exists(os.path.join(pkg_dir, "agent_server.py")):
                    agent_file = "agent_server"

                is_mcp = os.path.exists(os.path.join(pkg_dir, "mcp_server.py"))
                is_graph = os.path.exists(os.path.join(pkg_dir, "graph_config.py"))

                # A project is valid for validation if it's an agent suite OR has a pyproject.toml/tests
                has_pyproject = os.path.exists(os.path.join(path, "pyproject.toml"))
                has_tests = os.path.exists(
                    os.path.join(path, "tests")
                ) or os.path.exists(os.path.join(path, "test"))

                is_agent_suite = (
                    is_mcp or agent_file or is_graph or has_pyproject or has_tests
                )

                if pkg_name == "pipelines":
                    agent_targets.append(
                        {
                            "name": pkg_name,
                            "path": path,
                            "skip_reason": "Skipped (Not a Python project)",
                        }
                    )
                    continue

                if not is_agent_suite:
                    agent_targets.append(
                        {
                            "name": pkg_name,
                            "path": path,
                            "skip_reason": "Skipped (Not a valid Python/Agent project)",
                        }
                    )
                    continue

                if type == "flat" and (is_graph or not agent_file):
                    continue
                if type == "graph" and not is_graph:
                    continue

                agent_targets.append(
                    {
                        "name": pkg_name,
                        "pkg": pkg_underscore,
                        "path": path,
                        "pkg_dir": pkg_dir,
                        "file": agent_file or "",
                        "is_mcp": is_mcp,  # type: ignore
                        "is_graph": is_graph,  # type: ignore
                    }
                )

            # --- Phase 1: Ecosystem Installation ---
            if run_all or type == "installation":
                install_results = self.install_projects(report=False)
                results.extend(install_results)
                if writer:
                    writer.write_phase("Ecosystem Installation", install_results)

            # --- Phase 2: Version Metadata Sync ---
            if run_all or type == "version-sync":
                bump_results = []

                for _url, path in self.project_map.items():
                    # Ensure pre-run cleanup of artifacts
                    self.cleanup_artifacts(path)

                    repo_name = Path(path).name
                    if (Path(path) / ".bumpversion.cfg").exists():
                        bump_results.append(
                            self.bump_version(
                                "patch", allow_dirty=True, path=path, dry_run=True
                            )
                        )
                    else:
                        reason = (
                            "Skipped (Not a Python project)"
                            if repo_name == "pipelines"
                            else "Skipped (Missing .bumpversion.cfg)"
                        )
                        bump_results.append(
                            GitResult(
                                status="skipped",
                                data=reason,
                                metadata=GitMetadata(
                                    command="bump2version",
                                    workspace=path,
                                    return_code=0,
                                    timestamp=datetime.datetime.now(
                                        datetime.timezone.utc
                                    ).isoformat()
                                    + "Z",
                                ),
                            )
                        )
                results.extend(bump_results)
                if writer:
                    writer.write_phase("Version Metadata Sync (Dry Run)", bump_results)

            # --- Phase 3: Agent Standards, MCP Help, Agent Help (parallel fast checks) ---
            # Collect skip results and futures separately by category
            static_results: list[GitResult] = []
            mcp_help_results: list[GitResult] = []
            agent_help_results: list[GitResult] = []
            fast_futures_static: list[concurrent.futures.Future] = []
            fast_futures_mcp: list[concurrent.futures.Future] = []
            fast_futures_agent: list[concurrent.futures.Future] = []
            skip_ts = datetime.datetime.now(datetime.timezone.utc).isoformat() + "Z"

            for target in agent_targets:
                if "skip_reason" in target:
                    reason = target["skip_reason"]

                    if type == "mcp":
                        mcp_help_results.append(
                            GitResult(
                                status="skipped",
                                data=reason,
                                metadata=GitMetadata(
                                    command="mcp_server --help",
                                    workspace=target["path"],
                                    return_code=0,
                                    timestamp=skip_ts,
                                ),
                            )
                        )
                    if type == "agent":
                        agent_help_results.append(
                            GitResult(
                                status="skipped",
                                data=reason,
                                metadata=GitMetadata(
                                    command="agent_server --help",
                                    workspace=target["path"],
                                    return_code=0,
                                    timestamp=skip_ts,
                                ),
                            )
                        )
                    if type == "static-analysis":
                        static_results.append(
                            GitResult(
                                status="skipped",
                                data=reason,
                                metadata=GitMetadata(
                                    command="static_check",
                                    workspace=target["path"],
                                    return_code=0,
                                    timestamp=skip_ts,
                                ),
                            )
                        )
                    continue

                if type == "mcp" and target.get("is_mcp"):
                    cmd = f"{self.python_exe} -m {target['pkg']}.mcp_server --help"
                    fast_futures_mcp.append(
                        executor.submit(self._check_help, cmd, path=target["path"])
                    )
                elif type == "mcp":
                    mcp_help_results.append(
                        GitResult(
                            status="skipped",
                            data="Skipped (Not an MCP server)",
                            metadata=GitMetadata(
                                command="mcp_server --help",
                                workspace=target["path"],
                                return_code=0,
                                timestamp=skip_ts,
                            ),
                        )
                    )

                if type == "agent" and target.get("file"):
                    cmd = (
                        f"{self.python_exe} -m {target['pkg']}.{target['file']} --help"
                    )
                    fast_futures_agent.append(
                        executor.submit(self._check_help, cmd, path=target["path"])
                    )
                elif type == "agent":
                    agent_help_results.append(
                        GitResult(
                            status="skipped",
                            data="Skipped (MCP-only server)",
                            metadata=GitMetadata(
                                command="agent_server --help",
                                workspace=target["path"],
                                return_code=0,
                                timestamp=skip_ts,
                            ),
                        )
                    )

                if type == "static-analysis":
                    if target.get("file"):
                        fast_futures_static.append(
                            executor.submit(self._check_agent_static, target)
                        )
                    else:
                        static_results.append(
                            GitResult(
                                status="skipped",
                                data="Skipped (No server.py for static check)",
                                metadata=GitMetadata(
                                    command="static_check",
                                    workspace=target["path"],
                                    return_code=0,
                                    timestamp=skip_ts,
                                ),
                            )
                        )

            # Collect fast futures by category and write reports incrementally
            static_results.extend(
                [
                    f.result()
                    for f in concurrent.futures.as_completed(fast_futures_static)
                ]
            )
            if static_results:
                results.extend(static_results)
                if writer:
                    writer.write_phase("Agent Standards Compliance", static_results)

            mcp_help_results.extend(
                [f.result() for f in concurrent.futures.as_completed(fast_futures_mcp)]
            )
            if mcp_help_results:
                results.extend(mcp_help_results)
                if writer:
                    writer.write_phase("MCP Help Check", mcp_help_results)

            agent_help_results.extend(
                [
                    f.result()
                    for f in concurrent.futures.as_completed(fast_futures_agent)
                ]
            )
            if agent_help_results:
                results.extend(agent_help_results)
                if writer:
                    writer.write_phase("Agent Help Check", agent_help_results)

            # --- Phase 4: Runtime Validation ---
            if type == "runtime-validation":
                runtime_results: list[GitResult] = []
                heavy_futures = []
                for idx, target in enumerate(agent_targets):
                    if "skip_reason" in target:
                        runtime_results.append(
                            GitResult(
                                status="skipped",
                                data=target["skip_reason"],
                                metadata=GitMetadata(
                                    command="runtime_check",
                                    workspace=target["path"],
                                    return_code=0,
                                    timestamp=skip_ts,
                                ),
                            )
                        )
                        continue

                    if target.get("file"):
                        port = 9000 + (idx % 3000)
                        heavy_futures.append(
                            executor.submit(self._check_agent_runtime, target, port)
                        )
                    else:
                        runtime_results.append(
                            GitResult(
                                status="skipped",
                                data="Skipped (No server.py for runtime check)",
                                metadata=GitMetadata(
                                    command="runtime_check",
                                    workspace=target["path"],
                                    return_code=0,
                                    timestamp=skip_ts,
                                ),
                            )
                        )

                runtime_results.extend(
                    [f.result() for f in concurrent.futures.as_completed(heavy_futures)]
                )
                results.extend(runtime_results)
                if writer:
                    writer.write_phase("Agent Runtime & Web UI", runtime_results)

            # --- Phase 5: Pre-commit Standard Compliance ---
            if run_all or type == "pre-commit":
                logger.info(
                    f"Checking pre-commit compliance for {len(self.project_map)} projects..."
                )
                pc_results = self.pre_commit_projects(run=True, autoupdate=False)
                results.extend(pc_results)
                if writer:
                    writer.write_phase("Pre-commit Standard Compliance", pc_results)

            # --- Phase 6: Pytest and Coverage ---
            if type == "test":
                logger.info(f"Running pytests for {len(agent_targets)} projects...")
                test_results = self.test_projects(targets=agent_targets)
                results.extend(test_results)
                if writer:
                    writer.write_phase("Additional Operational Checks", test_results)

            # --- Console summary ---
            successes = [r for r in results if r.status == "success"]
            failures = [r for r in results if r.status == "error"]
            skipped = [r for r in results if r.status == "skipped"]

            print("\n" + "=" * 50)
            print("VALIDATION SUMMARY")
            print(
                f"Total: {len(results)} | Success: {len(successes)} ✅ | Failure: {len(failures)} ❌ | Skipped: {len(skipped)} ⏭️"
            )
            if failures:
                print("\nFailures:")
                for r in failures:
                    pkg = "unknown"
                    if r.metadata:
                        pkg = r.metadata.workspace.split("/")[-1]
                    error_msg = r.error.message if r.error else r.data
                    print(f"- {pkg}: {error_msg}")
            print("=" * 50 + "\n")

            # Finalize directory report (writes index.md)
            report_dir = None
            if writer:
                report_dir = writer.finalize()
                print(f"📋 Report directory: {report_dir}")

            report = ValidationReport.from_results(results)

            return report

    def _export_report(self, markdown_content: str, default_name: str) -> None:
        """Exports markdown content to a file if reporting is enabled."""
        if not self.report_path:
            return

        report_file = self.report_path
        if report_file is True:
            report_file = os.path.join(self.path, default_name)
        elif not os.path.isabs(report_file):
            report_file = os.path.join(self.path, report_file)

        try:
            with open(report_file, "w") as f:
                f.write(markdown_content)
            logger.info(f"Report exported to: {report_file}")
        except Exception as e:
            logger.error(f"Failed to export report to {report_file}: {e}")

    def _check_help(self, command: str, path: str) -> GitResult:
        """Helper to run a --help command and return a standardized result."""
        result = self.git_action(command=command, path=path, quiet=True)
        if result.status == "success":
            result.data = "--help loaded successfully"
        return result

    def _check_agent_static(self, target: dict[str, str]) -> GitResult:
        """Internal helper to perform static analysis for agents checking for standards compliance."""
        pkg_underscore = target["pkg"]
        pkg_dir = target["pkg_dir"]
        path = target["path"]

        agent_file_name = target["file"]
        agent_file = os.path.join(pkg_dir, f"{agent_file_name}.py")

        try:
            with open(agent_file) as f:
                content = f.read()

            missing = []
            if "warnings.filterwarnings" not in content:
                missing.append("warning_filter")
            if "file=sys.stderr" not in content:
                missing.append("stderr_print")

            metadata = GitMetadata(
                command=f"static_check {agent_file}",
                workspace=path,
                return_code=0 if not missing else 1,
                timestamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
                + "Z",
            )

            if not missing:
                return GitResult(
                    status="success", data="Static patterns verified", metadata=metadata
                )
            else:
                return GitResult(
                    status="error",
                    data=f"Missing patterns: {', '.join(missing)}",
                    error=GitError(message="Static validation failed", code=1),
                    metadata=metadata,
                )
        except Exception as e:
            logger.error(f"Failed static check for {pkg_underscore}: {e}")
            return GitResult(
                status="error",
                data=str(e),
                error=GitError(message=f"Crash during static check: {e}", code=1),
                metadata=GitMetadata(
                    command="static_check", workspace=path, return_code=1, timestamp=""
                ),
            )

    def _check_agent_runtime(self, target: dict[str, str], port: int) -> GitResult:
        """Internal helper to test a single agent's runtime startup with Web UI."""
        pkg_underscore = target["pkg"]
        agent_file = target["file"]
        path = target["path"]
        pkg_dir = target["pkg_dir"]

        if not agent_file:
            return GitResult(
                status="skipped",
                data=f"No agent server found for {target['name']}",
                metadata=GitMetadata(
                    command="runtime_check",
                    workspace=path,
                    return_code=0,
                    timestamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
                    + "Z",
                ),
            )

        cmd = [
            sys.executable,
            "-m",
            f"{pkg_underscore}.{agent_file}",
            "--web",
            "--port",
            str(port),
        ]

        env = os.environ.copy()
        for key in [
            "LLM_API_KEY",
            "OPENAI_API_KEY",
            "ANTHROPIC_API_KEY",
            "GEMINI_API_KEY",
            "GROQ_API_KEY",
        ]:
            if key not in env:
                env[key] = "dummy"
        if "LLM_MODEL_ID" not in env:
            env["LLM_MODEL_ID"] = "dummy"

        env["VALIDATION_MODE"] = "True"

        try:
            # Environment Cleanup: Remove corrupted WAL files and migrate agent_data
            pkg_dir = target["pkg_dir"]
            import shutil
            from pathlib import Path

            # 1. Migrate and remove agent_data
            agent_data_dir = Path(pkg_dir) / "agent_data"
            if agent_data_dir.exists() and agent_data_dir.is_dir():
                mcp_src = agent_data_dir / "mcp_config.json"
                mcp_dst = Path(pkg_dir) / "mcp_config.json"
                if mcp_src.exists():
                    try:
                        shutil.copy2(mcp_src, mcp_dst)
                        logger.info(
                            f"Migrated mcp_config.json from agent_data for {target['name']}"
                        )
                    except Exception as e:
                        logger.error(
                            f"Failed to migrate mcp_config.json for {target['name']}: {e}"
                        )

                try:
                    shutil.rmtree(agent_data_dir)
                    logger.info(
                        f"Removed deprecated agent_data directory for {target['name']}"
                    )
                except Exception as e:
                    logger.warning(
                        f"Failed to remove agent_data directory for {target['name']}: {e}"
                    )

            # 2. Cleanup dangling WAL/SHM files
            for pattern in ["*.db-wal", "*.db-shm", "*.wal"]:
                for p in Path(pkg_dir).glob(pattern):
                    try:
                        p.unlink()
                        logger.info(f"Cleaned up dangling file: {p.name}")
                    except Exception as e:
                        logger.warning(f"Failed to remove {p.name}: {e}")

            # 3. Gitignore Maintenance
            gitignore_path = Path(path) / ".gitignore"
            if gitignore_path.exists():
                try:
                    content = gitignore_path.read_text()
                    if "knowledge_graph.db*" not in content:
                        with open(gitignore_path, "a") as f:
                            f.write(
                                "\n# Graph Database\nknowledge_graph.db*\n.repo_graph/\n.ladybug/\n"
                            )
                        logger.info(f"Updated .gitignore for {target['name']}")
                except Exception as e:
                    logger.warning(
                        f"Failed to update .gitignore for {target['name']}: {e}"
                    )

            proc = subprocess.Popen(
                cmd,
                cwd=path,
                env=env,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                preexec_fn=os.setsid if os.name != "nt" else None,
            )

            start_time = datetime.datetime.now()
            startup_time = start_time
            success = False
            error_msg = ""
            full_logs = ""

            import fcntl

            # Set non-blocking mode on stdout and stderr
            for pipe in [proc.stdout, proc.stderr]:
                if pipe is None:
                    continue
                fd = pipe.fileno()  # type: ignore
                fl = fcntl.fcntl(fd, fcntl.F_GETFL)
                fcntl.fcntl(fd, fcntl.F_SETFL, fl | os.O_NONBLOCK)

            while (datetime.datetime.now() - start_time).total_seconds() < 60:
                rlist, _, _ = select.select(
                    [p for p in [proc.stdout, proc.stderr] if p], [], [], 0.5
                )
                for r in rlist:
                    if r is None:
                        continue
                    try:
                        # Read available data without blocking
                        chunk = r.read(4096)
                        if not chunk:
                            continue

                        full_logs += chunk
                        # Split by newline and process each line
                        lines = chunk.splitlines()
                        for line in lines:
                            line = line.strip()
                            if not line:
                                continue

                            logger.debug(f"[{target['name']}] {line}")

                            if (
                                "Uvicorn running on" in line
                                or "Application startup complete" in line
                                or "Starting server on" in line
                            ):
                                success = True
                                startup_time = datetime.datetime.now()
                                logger.info(
                                    f"Startup signal detected for {target['name']}, waiting for settle..."
                                )

                            if (
                                "ERROR -" in line.upper()
                                or "ERROR:" in line.upper()
                                or "CRITICAL -" in line.upper()
                                or "CRITICAL:" in line.upper()
                                or "TRACEBACK" in line.upper()
                                or "IMPORTERROR" in line.upper()
                                or "NAMEERROR" in line.upper()
                                or "APPLICATION STARTUP FAILED" in line.upper()
                            ):
                                error_msg = line.strip()
                                logger.error(
                                    f"Startup error detected for {target['name']}: {error_msg}"
                                )
                                # No success, will break via poll() or loop timeout
                    except (OSError, BlockingIOError):
                        continue

                if proc.poll() is not None:
                    # If process exited, we are done
                    if not success:
                        error_msg = f"Process exited with code {proc.returncode}"
                    break

                if (
                    success
                    and (datetime.datetime.now() - startup_time).total_seconds() >= 3
                ):
                    break

            try:
                if os.name != "nt":
                    os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
                else:
                    proc.terminate()
                proc.wait(timeout=3)
            except Exception:  # nosec B110
                pass

            metadata = GitMetadata(
                command=" ".join(cmd),
                workspace=path,
                return_code=0 if success else (proc.returncode or 1),
                timestamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
                + "Z",
            )

            if success:
                return GitResult(
                    status="success",
                    data=f"Web UI started successfully on port {port}",
                    metadata=metadata,
                )
            else:
                if not error_msg:
                    error_msg = "Timeout (60s): No startup signal detected"
                return GitResult(
                    status="error",
                    data=full_logs[-1000:],
                    error=GitError(message=error_msg, code=metadata.return_code),
                    metadata=metadata,
                )

        except Exception as e:
            return GitResult(
                status="error",
                data=str(e),
                error=GitError(message=f"Crash during runtime check: {e}", code=1),
                metadata=GitMetadata(
                    command=" ".join(cmd), workspace=path, return_code=1, timestamp=""
                ),
            )

    @staticmethod
    def generate_markdown_summary(action: str, results: list[GitResult]) -> str:
        """Generates a beautiful markdown summary of bulk operation results."""
        successes = [r for r in results if r.status == "success"]
        failures = [r for r in results if r.status == "error"]
        skips = [r for r in results if r.status == "skipped"]

        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        md = [
            f"# {action.upper()} Summary",
            f"**Time:** {timestamp}  ",
            f"**Total:** {len(results)} | **Success:** {len(successes)} ✅ | **Failure:** {len(failures)} ❌ | **Skipped:** {len(skips)} ⏭️",
            "",
        ]

        if successes:
            md.append("## Successes ✅")
            for r in successes:
                name = (
                    os.path.basename(r.metadata.workspace) if r.metadata else "unknown"
                )

                msg = r.data or "Success"
                if action.lower() in ["installation", "build", "validation"]:
                    msg = "Success"
                elif msg.count("\n") > 2:
                    if "new_version=" not in msg and "current_version=" not in msg:
                        msg = "Success"

                md.append(f"- **{name}**: {msg}")
            md.append("")

        if failures:
            md.append("## Failures ❌")
            for r in failures:
                name = (
                    os.path.basename(r.metadata.workspace) if r.metadata else "unknown"
                )
                err_msg = r.error.message if r.error else "Unknown error"
                md.append(f"### ⚠️ {name}")
                if r.metadata:
                    md.append(f"**Command:** `{r.metadata.command}`")
                md.append("**Error:**")
                md.append(f"```text\n{err_msg}\n```")
                if r.data:
                    md.append("**Output:**")
                    md.append(f"```text\n{r.data}\n```")
                md.append("---")
            md.append("")

        if skips:
            md.append("## Skipped ⏭️")
            reasons: dict[str, list[str]] = {}
            for r in skips:
                reason = r.data or "No reason provided"
                if reason not in reasons:
                    reasons[reason] = []
                reasons[reason].append(
                    os.path.basename(r.metadata.workspace) if r.metadata else "unknown"
                )

            for reason, projects in sorted(reasons.items()):
                project_list = ", ".join(sorted(list(set(projects))))
                md.append(f"- **{reason}**: {project_list}")
            md.append("")

        return "\n".join(md)

    def git_action(
        self,
        command: str,
        path: str | None = None,
        quiet: bool = False,
        env: dict | None = None,
        timeout: int = 1800,
    ) -> GitResult:
        """
        Execute a Git command in the specified directory.

        Args:
            command (str): The Git command to execute.
            path (str, optional): The directory to execute the command in.
                Defaults to the base path.

        Returns:
            GitResult: The combined stdout and stderr output of the command in structured format.
        """
        target_path = self._resolve_path(path)

        # Ensure ~/.local/bin is in PATH for tools like bump2version
        current_env = env if env else os.environ.copy()
        local_bin = os.path.expanduser("~/.local/bin")
        if local_bin not in current_env.get("PATH", ""):
            current_env["PATH"] = f"{local_bin}:{current_env.get('PATH', '')}"

        # Ensure Python output is unbuffered so we get real-time logs
        current_env["PYTHONUNBUFFERED"] = "1"

        logger.info(f"Executing: {command} in {target_path}")

        process = subprocess.Popen(
            command,
            shell=True,  # nosec B602
            cwd=target_path,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            stdin=subprocess.DEVNULL,
            text=True,
            env=current_env,
            bufsize=1,  # Line buffered
        )

        output_lines = []
        try:
            # Write start marker
            with self.debug_lock:
                with open(self.debug_log_path, "a") as log_file:
                    log_file.write(
                        f"\n[{datetime.datetime.now().isoformat()}] Starting: {command}\n"
                    )
                    log_file.write(
                        f"[{datetime.datetime.now().isoformat()}] CWD: {target_path}\n"
                    )
                    log_file.flush()

            # Read output line by line as it becomes available
            if process.stdout:
                for line in process.stdout:
                    output_lines.append(line)
                    with self.debug_lock:
                        with open(self.debug_log_path, "a") as log_file:
                            log_file.write(
                                f"[{datetime.datetime.now().isoformat()}] {line}"
                            )
                            log_file.flush()

            # Wait for process to complete, with a safety timeout
            process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            logger.warning(f"Command timed out: {command}")
            if hasattr(os, "killpg"):
                try:
                    os.killpg(os.getpgid(process.pid), signal.SIGTERM)
                except Exception:  # nosec B110
                    process.kill()
            else:
                process.kill()

            with self.debug_lock:
                with open(self.debug_log_path, "a") as log_file:
                    log_file.write(
                        f"[{datetime.datetime.now().isoformat()}] ERROR: Command timed out after {timeout} seconds\n"
                    )
                    log_file.flush()

        out = "".join(output_lines)
        err = ""  # stderr was merged into stdout
        return_code = process.returncode

        metadata = GitMetadata(
            command=command,
            workspace=target_path,
            return_code=return_code,
            timestamp=datetime.datetime.now(datetime.timezone.utc).isoformat() + "Z",
        )

        error_obj = None
        if return_code != 0:
            error_obj = GitError(
                message=(
                    err.strip() if err else (out.strip() if out else "Unknown error")
                ),
                code=return_code,
            )

        result = GitResult(
            status="success" if return_code == 0 else "error",
            data=out.strip() if out else "",
            error=error_obj,
            metadata=metadata,
        )

        if result.status == "error":
            err_msg = result.error.message if result.error else "Unknown error"
            logger.error(f"Command failed: {command}\nError: {err_msg}")
        elif not quiet:
            logger.info(f"Command: {command}\nOutput: {result.data}")

        return result

    def cleanup_artifacts(self, target_dir: str) -> None:
        """Removes test artifacts and temporary files from the specified directory."""
        import shutil
        from pathlib import Path

        dir_path = Path(target_dir)
        if not dir_path.exists():
            return

        patterns_to_remove = [
            "knowledge_graph.db*",
            "*.db-wal",
            "*.db-shm",
            "*.wal",
            "*.log",
            "session<MagicMock*",
            "coverage.xml",
            ".coverage",
        ]

        dir_patterns_to_remove = {
            ".pytest_cache",
            "htmlcov",
            "agent_data",
        }

        ignored_dirs = {".venv", "node_modules", ".git"}

        # Use os.walk with top-down pruning to avoid iterating massive directories
        for dirpath, dirnames, filenames in os.walk(target_dir, topdown=True):
            # Prune ignored directories in-place (prevents os.walk from descending)
            dirnames[:] = [d for d in dirnames if d not in ignored_dirs]

            # Check for directory-level cleanup targets
            for d in list(dirnames):
                if d in dir_patterns_to_remove:
                    full_path = os.path.join(dirpath, d)
                    try:
                        shutil.rmtree(full_path)
                        logger.debug(f"Cleaned up directory: {full_path}")
                    except Exception as e:
                        logger.debug(f"Failed to clean up directory {full_path}: {e}")
                    dirnames.remove(d)

            # Check for file-level cleanup targets
            for f in filenames:
                file_path = Path(os.path.join(dirpath, f))
                for pat in patterns_to_remove:
                    if file_path.match(pat):
                        try:
                            file_path.unlink()
                            logger.debug(f"Cleaned up file: {file_path}")
                        except Exception as e:
                            logger.debug(f"Failed to clean up file {file_path}: {e}")
                        break

    def clone_projects(self, projects: list[str] | None = None) -> list[GitResult]:
        """
        Clone all specified Git projects in parallel using multiple threads.

        Returns:
            List[GitResult]: A list of GitResult objects, one for each clone operation.
        """
        try:
            expanded_path = os.path.expanduser(self.path)
            if not os.path.exists(expanded_path):
                os.makedirs(expanded_path, exist_ok=True)

            targets = []
            if self.project_map:
                for url, path in self.project_map.items():
                    targets.append((url, path))
            elif projects:
                for url in projects:
                    name = url.split("/")[-1].replace(".git", "")
                    targets.append((url, os.path.join(expanded_path, name)))

            if not targets:
                logger.warning("No projects to clone.")
                return []

            logger.info(
                f"Cloning {len(targets)} projects in parallel using {self.threads} threads..."
            )
            with concurrent.futures.ThreadPoolExecutor(
                max_workers=self.threads
            ) as executor:
                futures = {
                    executor.submit(self.clone_repository, url, path): (url, path)
                    for url, path in targets
                }
                results = []
                for future in concurrent.futures.as_completed(futures):
                    results.append(future.result())
            return results

        except Exception as e:
            logger.error(f"Parallel project cloning failed: {str(e)}")
            return [
                GitResult(
                    status="error",
                    data="",
                    error=GitError(
                        message=f"Parallel project cloning failed: {str(e)}", code=-1
                    ),
                    metadata=GitMetadata(
                        command="clone_projects",
                        workspace=self.path,
                        return_code=-1,
                        timestamp=datetime.datetime.now(
                            datetime.timezone.utc
                        ).isoformat()
                        + "Z",
                    ),
                )
            ]

    def clone_repository(self, url: str, target_path: str) -> GitResult:
        """
        Clone a single Git repository to a specific target path.

        Args:
            url (str): The repository URL to clone.
            target_path (str): The absolute path where the repository should be cloned.

        Returns:
            GitResult: The result of the Git clone command.
        """
        if not url:
            return GitResult(
                status="error",
                data="",
                error=GitError(message="No repository URL provided", code=1),
                metadata=GitMetadata(
                    command="clone",
                    workspace=target_path,
                    return_code=1,
                    timestamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
                    + "Z",
                ),
            )

        os.makedirs(os.path.dirname(target_path), exist_ok=True)

        command = f"git clone {url} {target_path}"
        result = self.git_action(command, path=os.path.dirname(target_path))
        logger.info(f"Cloning {url} to {target_path}: {result.status}")
        return result

    def pull_projects(self, project_dirs: list[str] | None = None) -> list[GitResult]:
        """
        Pull updates for multiple projects in parallel.
        """
        if project_dirs is None:
            if self.project_map:
                project_dirs = list(self.project_map.values())
            else:
                logger.warning("No projects found in project_map to pull.")
                return []

        if not project_dirs:
            logger.warning("No projects found to pull.")
            return []

        logger.info(
            f"Pulling {len(project_dirs)} projects in parallel using {self.threads} threads..."
        )
        with concurrent.futures.ThreadPoolExecutor(
            max_workers=self.threads
        ) as executor:
            return list(executor.map(self.pull_project, project_dirs))

    def pull_project(self, path: str | None = None) -> GitResult:
        """
        Pull updates for a single Git project and optionally checkout the default branch.

        Args:
            path (str): The path to the project to pull. Defaults to self.path.

        Returns:
            GitResult: The result of the pull operation.
        """
        target_path = self._resolve_path(path)
        results = []

        pull_result = self.git_action(command="git pull", path=target_path)
        results.append(pull_result)

        logger.info(
            f"Scanning: {target_path}\n"
            f"Pulling latest changes for {target_path}\n"
            f"{pull_result}"
        )

        if self.set_to_default_branch:
            default_branch_result = self.git_action(
                "git symbolic-ref refs/remotes/origin/HEAD",
                path=target_path,
            )
            if default_branch_result.status == "success":
                default_branch = re.sub(
                    "refs/remotes/origin/", "", default_branch_result.data
                ).strip()
                checkout_result = self.git_action(
                    f'git checkout "{default_branch}"',
                    path=target_path,
                )
                results.append(checkout_result)
                logger.info(f"Checking out default branch: {checkout_result}")
            else:
                results.append(default_branch_result)
                logger.error(
                    f"Failed to get default branch for {target_path}: {default_branch_result.error}"
                )

        combined_status = (
            "success" if all(r.status == "success" for r in results) else "error"
        )

        combined_data = "\n".join(
            [
                f"[{r.metadata.command if r.metadata else 'unknown'}]: {r.data}"
                for r in results
            ]
        )

        combined_error = next((r.error for r in results if r.error), None)

        metadata = GitMetadata(
            command="pull_project",
            workspace=target_path,
            return_code=0 if combined_status == "success" else 1,
            timestamp=datetime.datetime.now(datetime.timezone.utc).isoformat() + "Z",
        )

        return GitResult(
            status=combined_status,
            data=combined_data,
            error=combined_error,
            metadata=metadata,
        )

    def push_projects(self, project_dirs: list[str] | None = None) -> list[GitResult]:
        """
        Push updates for multiple projects in parallel.
        """
        if project_dirs is None:
            if self.project_map:
                project_dirs = list(self.project_map.values())
            else:
                logger.warning("No projects found in project_map to push.")
                return []

        if not project_dirs:
            logger.warning("No projects found to push.")
            return []

        logger.info(
            f"Pushing {len(project_dirs)} projects in parallel using {self.threads} threads..."
        )
        with concurrent.futures.ThreadPoolExecutor(
            max_workers=self.threads
        ) as executor:
            return list(executor.map(self.push_project, project_dirs))

    def push_project(self, path: str | None = None) -> GitResult:
        """
        Push updates and tags for a single Git project.
        """
        target_path = self._resolve_path(path)
        logger.info(f"Pushing latest changes and tags for {target_path}")
        return self.git_action(command="git push --follow-tags", path=target_path)

    def set_threads(self, threads: int) -> None:
        """
        Set the number of threads for parallel processing.

        Args:
            threads (int): The number of threads.

        Notes:
            If the input is invalid, defaults 6
        """
        try:
            if 0 < threads <= self.maximum_threads:
                self.threads = threads
            else:
                logger.warning(
                    f"Did not recognize {threads} as a valid value, defaulting to: {self.maximum_threads}"
                )
                self.threads = self.maximum_threads
        except Exception as e:
            logger.error(
                f"Did not recognize {threads} as a valid value, defaulting to: {self.maximum_threads}. Error: {e}"
            )
            self.threads = self.maximum_threads

    def pre_commit(
        self,
        run: bool = True,
        autoupdate: bool = False,
        path: str | None = None,
    ) -> GitResult:
        """
        Execute pre-commit commands in the specified path.

        Args:
            run (bool): Whether to run 'pre-commit run --all-files'. Default True.
            autoupdate (bool): Whether to run 'pre-commit autoupdate'. Default False.
            path (str, optional): Path to run in. Defaults to self.path.
        """
        target_path = self._resolve_path(path)

        # Clean artifacts before running pre-commit
        self.cleanup_artifacts(target_path)

        if not os.path.exists(os.path.join(target_path, ".pre-commit-config.yaml")):
            return GitResult(
                status="skipped",
                data="No .pre-commit-config.yaml found.",
                error=None,
                metadata=GitMetadata(
                    command="pre_commit_check",
                    workspace=target_path,
                    return_code=0,
                    timestamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
                    + "Z",
                ),
            )

        commands = []
        if autoupdate:
            commands.append("pre-commit autoupdate")
        if run:
            commands.append("git add -A")
            commands.append(
                "SKIP=no-commit-to-branch pre-commit run --all-files --verbose"
            )

        if not commands:
            return GitResult(
                status="skipped",
                data="No action selected (run=False, autoupdate=False).",
                error=None,
                metadata=GitMetadata(
                    command="pre_commit_check",
                    workspace=target_path,
                    return_code=0,
                    timestamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
                    + "Z",
                ),
            )

        full_command = " && ".join(commands)

        env = os.environ.copy()
        if "SKIP" in env:
            env["SKIP"] += ",no-commit-to-branch"
        else:
            env["SKIP"] = "no-commit-to-branch"

        result = self.git_action(command=full_command, path=target_path, env=env)

        if result.status == "error" and result.error:
            msg = result.error.message.lower()
            if "don't commit to branch" in msg or "no-commit-to-branch" in msg:
                other_failures = False
                lines = (result.error.message + "\n" + result.data).splitlines()
                for line in lines:
                    if (
                        "Failed" in line
                        and "don't commit to branch" not in line.lower()
                    ):
                        other_failures = True
                        break

                if not other_failures:
                    logger.info(
                        f"Ignoring safe pre-commit failure (branch lock) in {target_path}"
                    )
                    return GitResult(
                        status="success",
                        data=result.data or "Skipped branch lock check",
                        metadata=result.metadata,
                    )

        return result

    def test_projects(self, targets: list[dict[str, str]]) -> list[GitResult]:
        """
        Execute pytests with coverage for the specified projects in parallel.
        """
        results = []
        with concurrent.futures.ThreadPoolExecutor(
            max_workers=self.threads
        ) as executor:
            futures = []
            for target in targets:
                if "skip_reason" in target:
                    continue

                path = target["path"]
                # Try to find tests directory
                has_tests = os.path.exists(
                    os.path.join(path, "tests")
                ) or os.path.exists(os.path.join(path, "test"))
                if has_tests:
                    # Detect if we should use uv or standard python
                    if os.path.exists(os.path.join(path, "uv.lock")):
                        # Use uv run with test extra if it exists
                        cmd = "uv run --extra test pytest -v --cov=."
                    else:
                        # Fallback to standard pytest
                        cmd = f"{sys.executable} -m pytest -v --cov=."

                    # Ensure memory safety for ladybug and set validation mode
                    test_env = os.environ.copy()
                    test_env["LADYBUG_MAX_DB_SIZE"] = "1073741824"
                    test_env["VALIDATION_MODE"] = "True"
                    test_env["KNOWLEDGE_GRAPH_SYNC_BACKGROUND"] = "False"

                    futures.append(
                        executor.submit(
                            self.git_action,
                            cmd,
                            path=path,
                            env=test_env,
                            timeout=600,  # 10 minute timeout for tests
                        )
                    )
                else:
                    results.append(
                        GitResult(
                            status="skipped",
                            data="No tests directory found",
                            metadata=GitMetadata(
                                command="pytest",
                                workspace=path,
                                return_code=0,
                                timestamp=datetime.datetime.now(
                                    datetime.timezone.utc
                                ).isoformat()
                                + "Z",
                            ),
                        )
                    )

            for future in concurrent.futures.as_completed(futures):
                results.append(future.result())
        return results

    def pre_commit_projects(
        self,
        run: bool = True,
        autoupdate: bool = False,
        projects: list[str] | None = None,
    ) -> list[GitResult]:
        """
        Execute pre-commit commands for all projects in parallel.

        Returns:
            List[GitResult]: A list of GitResult objects.
        """
        try:
            expanded_path = os.path.expanduser(self.path)
            if not os.path.exists(expanded_path):
                return []

            if projects is None:
                if self.project_map:
                    project_dirs = [
                        p
                        for p in self.project_map.values()
                        if os.path.exists(os.path.join(p, ".pre-commit-config.yaml"))
                    ]
                else:
                    logger.warning("No projects found in project_map for pre-commit.")
                    return []
            else:
                project_dirs = [
                    os.path.abspath(os.path.expanduser(p))
                    for p in projects
                    if os.path.isdir(os.path.abspath(os.path.expanduser(p)))
                    and os.path.exists(
                        os.path.join(
                            os.path.abspath(os.path.expanduser(p)),
                            ".pre-commit-config.yaml",
                        )
                    )
                ]

            if not project_dirs:
                return []

            with concurrent.futures.ThreadPoolExecutor(
                max_workers=self.threads
            ) as executor:
                futures = {
                    executor.submit(self.pre_commit, run, autoupdate, d): d
                    for d in project_dirs
                }
                results = []
                for future in concurrent.futures.as_completed(futures):
                    results.append(future.result())

            return results

        except Exception as e:
            logger.error(f"Parallel pre-commit failed: {str(e)}")
            return [
                GitResult(
                    status="error",
                    data="",
                    error=GitError(
                        message=f"Parallel pre-commit failed: {str(e)}", code=-1
                    ),
                    metadata=GitMetadata(
                        command="pre_commit_projects",
                        workspace=self.path,
                        return_code=-1,
                        timestamp=datetime.datetime.now(
                            datetime.timezone.utc
                        ).isoformat()
                        + "Z",
                    ),
                )
            ]

    def install_project(self, path: str | None = None, extra: str = "all") -> GitResult:
        """
        Install a Python project using pip install -e .[extra].
        """
        target_path = self._resolve_path(path)

        command = self._get_pip_command(extra)

        logger.info(f"Installing project at {target_path} with {command}")
        result = self.git_action(command=command, path=target_path)

        for d in ["build", "dist"]:
            shutil.rmtree(os.path.join(target_path, d), ignore_errors=True)
        for egg_info in Path(target_path).glob("*.egg-info"):
            shutil.rmtree(egg_info, ignore_errors=True)

        return result

    def get_readme(self, path: str | None = None) -> ReadmeResult:
        """
        Get the content and path of the README.md file in the specified path.

        Args:
            path (str, optional): The directory path. Defaults to self.path.

        Returns:
            ReadmeResult: Object containing 'content' and 'path' of the README.md file.
        """
        target_dir = self._resolve_path(path)

        if not os.path.exists(target_dir):
            return ReadmeResult(content="", path="")

        readme_path = None
        for filename in os.listdir(target_dir):
            if filename.lower() == "readme.md":
                readme_path = os.path.join(target_dir, filename)
                break

        if not readme_path:
            return ReadmeResult(content="", path="")

        try:
            with open(readme_path, encoding="utf-8") as f:
                content = f.read()
            return ReadmeResult(content=content, path=readme_path)
        except Exception as e:
            logger.error(f"Error reading README: {e}")
            return ReadmeResult(content="", path=readme_path)

    def create_project(self, path: str) -> GitResult:
        """
        Create a new project directory and initialize it as a git repository.

        Args:
            path (str): The path of the project directory to create.

        Returns:
            GitResult: Result of the operation.
        """
        target_path = self._resolve_path(path)

        if os.path.exists(target_path):
            return GitResult(
                status="error",
                data="",
                error=GitError(
                    message=f"Directory already exists: {target_path}", code=1
                ),
                metadata=GitMetadata(
                    command="create_project",
                    workspace=target_path,
                    return_code=1,
                    timestamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
                    + "Z",
                ),
            )

        try:
            os.makedirs(target_path, exist_ok=True)
            init_result = self.git_action("git init", path=target_path)

            if init_result.status == "success":
                logger.info(f"Created project: {target_path}")
                return init_result
            else:
                return init_result

        except Exception as e:
            logger.error(f"Failed to create project {target_path}: {e}")
            return GitResult(
                status="error",
                data="",
                error=GitError(message=str(e), code=1),
                metadata=GitMetadata(
                    command="create_project",
                    workspace=target_path,
                    return_code=1,
                    timestamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
                    + "Z",
                ),
            )

    def bump_version(
        self,
        part: str,
        allow_dirty: bool = False,
        path: str | None = None,
        dry_run: bool = False,
        verbose: bool = False,
    ) -> GitResult:
        """
        Bump the version of the project using bump2version.

        Args:
            part (str): The part of the version to bump (major, minor, patch).
            allow_dirty (bool): Whether to allow dirty working directory.
            path (str): The path to the project directory.
            dry_run (bool): Whether to perform a dry run.
            verbose (bool): Whether to use verbose output (for dry-run visibility).

        Returns:
            GitResult: Result of the operation.
        """
        target_dir = self._resolve_path(path)

        if not os.path.exists(target_dir):
            return GitResult(
                status="error",
                data="",
                error=GitError(
                    message=f"Directory not found: {target_dir}",
                    code=1,
                ),
                metadata=GitMetadata(
                    command="bump_version",
                    workspace=target_dir,
                    return_code=1,
                    timestamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
                    + "Z",
                ),
            )

        valid_parts = ["major", "minor", "patch"]
        if part not in valid_parts:
            return GitResult(
                status="error",
                data="",
                error=GitError(
                    message=f"Invalid part '{part}'. Must be one of {valid_parts}",
                    code=1,
                ),
                metadata=GitMetadata(
                    command="bump_version",
                    workspace=target_dir,
                    return_code=1,
                    timestamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
                    + "Z",
                ),
            )

        command = (
            f"SKIP=no-commit-to-branch,uv-lock,pytest,pnpm-build bump2version {part}"
        )
        if allow_dirty:
            command += " --allow-dirty"
        if dry_run:
            command += " --dry-run"
        if verbose:
            command += " --verbose"

        # Pre-flight check for existing tags
        if not dry_run:
            pre_cmd = f"bump2version {part} --dry-run --list"
            if allow_dirty:
                pre_cmd += " --allow-dirty"
            pre_result = self.git_action(command=pre_cmd, path=target_dir, quiet=True)
            if pre_result.status == "success":
                match = re.search(r"new_version=(.*)", pre_result.data)
                if match:
                    new_version = match.group(1).strip()
                    tag_check = self.git_action(
                        command=f"git tag -l v{new_version}",
                        path=target_dir,
                        quiet=True,
                    )
                    if (
                        tag_check.status == "success"
                        and f"v{new_version}" in tag_check.data
                    ):
                        logger.warning(
                            f"Tag v{new_version} already exists in {target_dir}. Skipping bump."
                        )
                        return GitResult(
                            status="success",
                            data=f"current_version={new_version}\nnew_version={new_version}\n",
                            metadata=GitMetadata(
                                command="bump_version",
                                workspace=target_dir,
                                return_code=0,
                                timestamp=datetime.datetime.now(
                                    datetime.timezone.utc
                                ).isoformat()
                                + "Z",
                            ),
                        )
            command += " --list"

        try:
            result = self.git_action(command=command, path=target_dir)

            if result.status == "success":
                logger.info(f"Bumped version ({part}) in {target_dir}")

                if not dry_run:
                    # Synchronize uv.lock after pyproject.toml version bump
                    uv_lock_path = os.path.join(target_dir, "uv.lock")
                    if os.path.exists(uv_lock_path):
                        self.git_action(command="uv lock", path=target_dir, quiet=True)
                        status_check = self.git_action(
                            command="git status --porcelain pyproject.toml uv.lock",
                            path=target_dir,
                            quiet=True,
                        )
                        if status_check.data.strip():
                            # Commit the lockfile update into the bump commit
                            self.git_action(
                                command="git add pyproject.toml uv.lock",
                                path=target_dir,
                                quiet=True,
                            )
                            self.git_action(
                                command="SKIP=no-commit-to-branch,uv-lock,pytest,pnpm-build git commit --amend --no-edit",
                                path=target_dir,
                                quiet=True,
                            )

                            # Move the tag to point to the newly amended commit
                            match = re.search(r"new_version=(.*)", result.data)
                            if match:
                                new_version = match.group(1).strip()
                                self.git_action(
                                    command=f"git tag -f v{new_version}",
                                    path=target_dir,
                                    quiet=True,
                                )
            else:
                logger.error(f"Failed to bump version in {target_dir}: {result.error}")

            return result
        except Exception as e:
            logger.error(f"Error in bump_version: {e}")
            return GitResult(
                status="error",
                data="",
                error=GitError(message=str(e), code=1),
                metadata=GitMetadata(
                    command="bump_version",
                    workspace=target_dir,
                    return_code=1,
                    timestamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
                    + "Z",
                ),
            )

    def bulk_bump(
        self,
        part: str,
        dry_run: bool = False,
        exclude: list[str] | None = None,
        verbose: bool = False,
    ) -> list[GitResult]:
        """Bumps the version for all projects in the workspace in parallel."""
        exclude = exclude or []
        results = []

        for url, path in self.project_map.items():
            name = url.split("/")[-1].replace(".git", "")
            if name in exclude:
                continue

            project_dir = Path(path)
            if (project_dir / ".bumpversion.cfg").exists():
                results.append(
                    self.bump_version(
                        part,
                        allow_dirty=True,
                        path=str(project_dir),
                        dry_run=dry_run,
                        verbose=verbose,
                    )
                )
            else:
                results.append(
                    GitResult(
                        status="skipped",
                        data="Missing .bumpversion.cfg",
                        metadata=GitMetadata(
                            command="bulk_bump",
                            workspace=str(project_dir),
                            return_code=0,
                            timestamp=datetime.datetime.now(
                                datetime.timezone.utc
                            ).isoformat()
                            + "Z",
                        ),
                    )
                )
        return results

    def update_dependency(
        self, file_path: str, package_name: str, new_version: str, dry_run: bool = False
    ) -> bool:
        """Updates the version of a package in a pyproject.toml's dependencies."""
        target_file = Path(self._resolve_path(file_path))
        if not target_file.exists() or not target_file.is_file():
            return False

        content = target_file.read_text()
        pattern = rf'("{package_name}(?:\[.*?\])?>=)\d+\.\d+\.\d+'
        replacement = rf"\g<1>{new_version}"

        new_content, count = re.subn(pattern, replacement, content)
        if count > 0:
            if not dry_run:
                target_file.write_text(new_content)
            logger.info(
                f"{'[DRY RUN] Would update' if dry_run else 'Updated'} {package_name} to >={new_version} in {target_file}"
            )
            return True
        return False

    def phased_bumpversion(
        self,
        part: str = "patch",
        start_phase: int = 1,
        dry_run: bool = False,
        allow_pre_commit: bool = False,
        config: dict | None = None,
        single_phase: bool = False,
        project_filter: str | None = None,
    ) -> list[GitResult]:
        """
        Execute the phased bumpversion workflow: pre-commits + phased bumping.
        """
        all_results = []
        if config is None:
            config_model: MaintenanceConfig | None = None
            if hasattr(self, "config") and self.config and self.config.maintenance:
                config_model = self.config.maintenance
            else:
                yml_path = os.environ.get("WORKSPACE_YML") or "workspace.yml"
                if not os.path.isabs(yml_path):
                    yml_path = os.path.join(self.path, yml_path)

                if os.path.exists(yml_path):
                    if self.load_projects_from_yaml(yml_path) and self.config:
                        config_model = self.config.maintenance
                    else:
                        config_model = None
                else:
                    config_model = None

            maintenance_cfg = None
            if config_model:
                maintenance_cfg = config_model.model_dump()
            else:
                logger.error("No maintenance configuration found.")
                return []

            config = maintenance_cfg

        if allow_pre_commit:
            projects_to_check: list[Any] | None = None
            if config:
                projects_to_check = []
                has_bulk = False
                for phase in config.get("phases", []):
                    if phase.get("bulk_bump"):
                        has_bulk = True
                        break
                    projects_to_check.extend(phase.get("projects", []))
                    if phase.get("project"):
                        projects_to_check.append(phase.get("project"))
                if has_bulk:
                    projects_to_check = None

            pc_results = self.pre_commit_projects(
                run=True, autoupdate=True, projects=projects_to_check
            )
            all_results.extend(pc_results)

        def run_step_bump(project_name, phase_num):
            if start_phase <= phase_num:
                project_dir = None
                for url, p_path in self.project_map.items():
                    if url.endswith(f"/{project_name}.git") or url.endswith(
                        f"/{project_name}"
                    ):
                        project_dir = p_path
                        break

                if not project_dir:
                    return None

                result = self.bump_version(
                    part=part,
                    allow_dirty=True,
                    path=str(project_dir),
                    dry_run=dry_run,
                    verbose=dry_run or not dry_run,
                )
                all_results.append(result)

                if result.status == "success":
                    match = re.search(r"new_version=(.*)", result.data)
                    if match:
                        return match.group(1).strip()

                    match = re.search(r"current_version=(.*)", result.data)
                    return match.group(1).strip() if match else "success"
                return None
            return None

        processed_projects: set[str] = set()

        for phase in config.get("phases", []):
            phase_num = phase.get("phase")
            if phase_num < start_phase:
                continue

            projects = phase.get("projects", [])
            if phase.get("project"):
                projects.append(phase.get("project"))

            if project_filter:
                projects = [p for p in projects if p == project_filter]

                # Also apply project filter to bulk operations if applicable
                if not projects and phase.get("bulk_bump"):
                    if project_filter not in processed_projects:
                        projects = [project_filter]

            if not projects and not phase.get("bulk_bump"):
                continue

            if phase.get("bulk_bump") and not project_filter:
                bulk_results = self.bulk_bump(
                    part=part, dry_run=dry_run, exclude=list(processed_projects)
                )
                all_results.extend(bulk_results)
                continue

            for project_name in projects:
                processed_projects.add(project_name)
                new_version = run_step_bump(project_name, phase_num)

                if new_version:
                    for _, path in self.project_map.items():
                        pyproject = Path(path) / "pyproject.toml"
                        if pyproject.exists():
                            is_updated = self.update_dependency(
                                str(pyproject), project_name, new_version, dry_run
                            )
                            if is_updated:
                                all_results.append(
                                    GitResult(
                                        status="success",
                                        data=f"Updated {project_name} to {new_version} in pyproject.toml",
                                        metadata=GitMetadata(
                                            command="update_dependency",
                                            workspace=str(path),
                                            return_code=0,
                                            timestamp=datetime.datetime.now(
                                                datetime.timezone.utc
                                            ).isoformat()
                                            + "Z",
                                        ),
                                    )
                                )

        return all_results

    maintain_projects = phased_bumpversion

    def phased_push(
        self,
        start_phase: int = 1,
        config: dict | None = None,
        single_phase: bool = False,
        project_filter: str | None = None,
    ) -> list[GitResult]:
        """
        Execute the phased git push workflow.
        """
        import time

        all_results = []
        if config is None:
            config_model: MaintenanceConfig | None = None
            if hasattr(self, "config") and self.config and self.config.maintenance:
                config_model = self.config.maintenance
            else:
                yml_path = os.environ.get("WORKSPACE_YML") or "workspace.yml"
                if not os.path.isabs(yml_path):
                    yml_path = os.path.join(self.path, yml_path)

                if os.path.exists(yml_path):
                    if self.load_projects_from_yaml(yml_path) and self.config:
                        config_model = self.config.maintenance
                    else:
                        config_model = None
                else:
                    config_model = None

            if config_model:
                config = config_model.model_dump()
            else:
                logger.error("No maintenance configuration found.")
                return []

        processed_projects = set()

        for phase in config.get("phases", []):
            phase_num = phase.get("phase")
            if phase_num < start_phase:
                continue

            projects_to_push = []

            projects = phase.get("projects", [])
            if phase.get("project"):
                projects.append(phase.get("project"))

            if project_filter:
                projects = [p for p in projects if p == project_filter]
                if not projects and phase.get("bulk_push"):
                    if project_filter not in processed_projects:
                        projects = [project_filter]

            if phase.get("bulk_push") and not project_filter:
                for url, path in self.project_map.items():
                    name = url.split("/")[-1].replace(".git", "")
                    if name not in processed_projects:
                        projects_to_push.append(path)
            else:
                for project_name in projects:
                    processed_projects.add(project_name)
                    for url, p_path in self.project_map.items():
                        if url.endswith(f"/{project_name}.git") or url.endswith(
                            f"/{project_name}"
                        ):
                            projects_to_push.append(p_path)
                            break

            if not projects_to_push:
                continue

            phase_name = phase.get("name", f"Phase {phase_num}")
            logger.info(
                f"Starting {phase_name} push for {len(projects_to_push)} projects..."
            )

            with concurrent.futures.ThreadPoolExecutor(
                max_workers=self.threads
            ) as executor:
                futures = []
                for p_path in projects_to_push:
                    futures.append(executor.submit(self.push_project, path=p_path))

                for future in concurrent.futures.as_completed(futures):
                    all_results.append(future.result())

            wait_minutes = phase.get("wait_minutes", 0)
            if wait_minutes > 0:
                logger.info(
                    f"Phase {phase_num} complete. Waiting {wait_minutes} minutes before proceeding..."
                )
                time.sleep(wait_minutes * 60)

        return all_results

    def load_projects_from_yaml(self, yaml_path: str) -> bool:
        """
        Loads repository URLs from a YAML workspace file using Pydantic models.
        Strictly determines self.path relative to the configuration file.
        """
        abs_yaml_path = os.path.abspath(os.path.expanduser(yaml_path))
        yaml_dir = os.path.dirname(abs_yaml_path)

        if not os.path.exists(abs_yaml_path):
            logger.error(f"YAML file not found: {abs_yaml_path}")
            return False

        try:
            with open(abs_yaml_path) as f:
                data = yaml.safe_load(f)

            if not data:
                return False

            self.config = WorkspaceConfig(**data)

            yaml_config_path = os.path.expanduser(self.config.path)
            is_default_yaml = yaml_path == DEFAULT_WORKSPACE_YML

            if self._explicit_path:
                logger.info(f"Preserving explicit workspace path: {self.path}")
            elif os.path.isabs(yaml_config_path):
                self.path = os.path.abspath(yaml_config_path)
            elif is_default_yaml:
                self.path = os.path.abspath(
                    os.path.expanduser(DEFAULT_REPOSITORY_MANAGER_WORKSPACE)
                )
                logger.info(
                    f"Using packaged workspace.yml, preserving default path: {self.path}"
                )
            else:
                self.path = os.path.abspath(os.path.join(yaml_dir, yaml_config_path))

            logger.info(f"Workspace root resolved to: {self.path}")

            self.project_map = self._parse_subdirectories(
                self.config.subdirectories, self.path
            )

            for repo in self.config.repositories:
                repo_name = repo.url.split("/")[-1].replace(".git", "")
                self.project_map[repo.url] = os.path.join(self.path, repo_name)
            return True

        except Exception as e:
            logger.error(f"Failed to load projects from YAML: {e}")
            return False

    def _parse_subdirectories(
        self, subdirs: dict[str, SubdirectoryConfig], current_path: str
    ) -> dict[str, str]:
        """Helper to recursively parse subdirectories and collect repository paths."""
        project_map = {}
        for name, data in subdirs.items():
            new_path = os.path.join(current_path, name)

            for repo in data.repositories:
                repo_name = repo.url.split("/")[-1].replace(".git", "")
                project_map[repo.url] = os.path.join(new_path, repo_name)

            if data.subdirectories:
                project_map.update(
                    self._parse_subdirectories(data.subdirectories, new_path)
                )

        return project_map

    def generate_workspace_template(
        self, target_path: str, use_default: bool = True
    ) -> GitResult:
        """
        Generates a workspace.yml template at the specified path.
        """
        try:
            target_path = os.path.abspath(os.path.expanduser(target_path))
            if os.path.isdir(target_path):
                target_path = os.path.join(target_path, "workspace.yml")

            os.makedirs(os.path.dirname(target_path), exist_ok=True)

            template_content = ""
            if use_default:
                try:
                    from importlib.resources import files

                    template_content = (
                        files("repository_manager") / "workspace.yml"
                    ).read_text()
                except Exception:  # nosec B110
                    template_content = "name: My Workspace\npath: .\ndescription: New workspace\nsubdirectories: {}\n"
            else:
                template_content = "name: My Workspace\npath: .\ndescription: New workspace\nsubdirectories:\n  agents:\n    description: Agent repositories\n    repositories: []\n"

            with open(target_path, "w") as f:
                f.write(template_content)

            return GitResult(
                status="success",
                data=f"Template generated at {target_path}",
                metadata=GitMetadata(
                    command="generate_template",
                    workspace=target_path,
                    return_code=0,
                    timestamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
                    + "Z",
                ),
            )
        except Exception as e:
            logger.error(f"Failed to generate template: {e}")
            return GitResult(
                status="error", data="", error=GitError(message=str(e), code=1)
            )

    def save_workspace_config(
        self, yaml_path: str, config: WorkspaceConfig | None = None
    ) -> GitResult:
        """
        Saves the current or provided WorkspaceConfig to a YAML file.
        """
        try:
            cfg = config or self.config
            if not cfg:
                return GitResult(
                    status="error",
                    data="",
                    error=GitError(message="No configuration to save", code=1),
                )

            yaml_path = os.path.abspath(os.path.expanduser(yaml_path))
            os.makedirs(os.path.dirname(yaml_path), exist_ok=True)

            data = cfg.model_dump()
            with open(yaml_path, "w") as f:
                yaml.dump(data, f, sort_keys=False)

            return GitResult(
                status="success",
                data=f"Workspace saved to {yaml_path}",
                metadata=GitMetadata(
                    command="save_workspace",
                    workspace=yaml_path,
                    return_code=0,
                    timestamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
                    + "Z",
                ),
            )
        except Exception as e:
            logger.error(f"Failed to save workspace: {e}")
            return GitResult(
                status="error", data="", error=GitError(message=str(e), code=1)
            )

    def generate_agents_documentation(
        self, target_path: str | None = None
    ) -> GitResult:
        """
        Generates an AGENTS.md catalog by discovering agent types and main files.
        Uses a robust multi-level path discovery to identify Graph vs Flat agents.
        """
        try:
            target_path = target_path or os.path.join(self.path, "AGENTS.md")
            target_path = os.path.abspath(os.path.expanduser(target_path))

            rows = []
            for url, project_path in self.get_project_map().items():
                pkg_name = url.split("/")[-1].replace(".git", "")
                pkg_name_underscore = pkg_name.replace("-", "_")

                if not os.path.exists(project_path):
                    rows.append(f"| `{pkg_name}` | (Not Cloned) |")
                    continue

                is_graph = False
                is_agent = False

                search_paths = [
                    Path(project_path),
                    Path(project_path) / pkg_name,
                    Path(project_path) / pkg_name_underscore,
                ]

                for sp in search_paths:
                    if (sp / "graph_config.py").exists():
                        is_graph = True
                        is_agent = True
                        break
                    if (sp / "agent_server.py").exists() or (
                        sp / "mcp_server.py"
                    ).exists():
                        is_agent = True

                if not is_agent:
                    agent_type = "Library"
                else:
                    agent_type = "Graph" if is_graph else "Flat"

                rows.append(f"| `{pkg_name}` | {agent_type} |")

            rows.sort()
            catalog_table = "\n".join(rows)

            template_content = ""
            try:
                from importlib.resources import files

                template_content = (
                    files("repository_manager") / "AGENTS.md"
                ).read_text()
            except Exception:  # nosec B110
                template_content = "# Agent Catalog\n\n| Agent Package | Type |\n|:--------------|:-----|\n<!-- AGENT_CATALOG_PLACEHOLDER -->\n"

            if "<!-- AGENT_CATALOG_PLACEHOLDER -->" in template_content:
                final_content = template_content.replace(
                    "<!-- AGENT_CATALOG_PLACEHOLDER -->", catalog_table
                )
            else:
                logger.warning(
                    "Placeholder <!-- AGENT_CATALOG_PLACEHOLDER --> not found in template. Appending catalog."
                )
                final_content = (
                    template_content
                    + "\n\n## Dynamic Catalog\n\n| Agent Package | Type |\n|:--------------|:-----|\n"
                    + catalog_table
                )

            with open(target_path, "w") as f:
                f.write(final_content)

            return GitResult(
                status="success",
                data=f"Agents documentation generated at {target_path}",
                metadata=GitMetadata(
                    command="generate_agents_md",
                    workspace=target_path,
                    return_code=0,
                    timestamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
                    + "Z",
                ),
            )

        except Exception as e:
            logger.error(f"Failed to generate AGENTS.md: {e}")
            return GitResult(
                status="error", data="", error=GitError(message=str(e), code=1)
            )

    def get_consolidated_skill_paths(self) -> list[str]:
        """
        Returns absolute paths to the 15 specific building and documentation skills.
        """
        required_universal = [
            "agent-package-builder",
            "mcp-builder",
            "agent-builder",
            "skill-builder",
            "skill-graph-builder",
            "api-wrapper-builder",
            "web-search",
            "web-crawler",
        ]
        required_graphs = [
            "docker-docs",
            "fastapi-docs",
            "fastmcp-docs",
            "nodejs-docs",
            "vercel-docs",
            "python-docs",
            "pydantic-ai-docs",
        ]

        paths = []

        if get_universal_skills_path:
            try:
                from importlib.resources import files

                base = files("universal_skills") / "skills"
                for skill in required_universal:
                    skill_path = base / skill
                    if skill_path.joinpath("SKILL.md").is_file():
                        paths.append(str(skill_path))
            except Exception as e:
                logger.warning(f"Could not load universal skills via importlib: {e}")

                all_universal = get_universal_skills_path()
                paths.extend(
                    [
                        p
                        for p in all_universal
                        if os.path.basename(p) in required_universal
                    ]
                )

        if get_skill_graphs_path:
            try:
                from importlib.resources import files

                base = files("skill_graphs") / "skill_graphs"
                for graph in required_graphs:
                    graph_path = base / graph
                    if graph_path.joinpath("SKILL.md").is_file():
                        paths.append(str(graph_path))
            except Exception as e:
                logger.warning(f"Could not load skill graphs via importlib: {e}")

                all_graphs = get_skill_graphs_path(default_enabled=True)
                paths.extend(
                    [p for p in all_graphs if os.path.basename(p) in required_graphs]
                )

        return list(set(paths))

    def ensure_graph(self) -> Any | None:
        """
        Incrementally builds or updates the Hybrid Graph for the workspace.
        """
        if (
            not hasattr(self, "config")
            or not self.config
            or not self.config.graph
            or not getattr(self.config.graph, "enabled", False)
        ):
            logger.info("Hybrid Graph is disabled in workspace config.")
            return None

        logger.info("Initiating Hybrid Graph build/sync process...")

        # This will reuse active engine if available, or run pipeline
        engine = self._get_intelligence_engine_sync()

        logger.info("Hybrid Graph build process complete.")
        # Return summary
        return {
            "nodes": engine.graph.number_of_nodes(),
            "edges": engine.graph.number_of_edges(),
        }


def main() -> None:
    """
    Main entry point for the Repository Manager CLI.
    Supports workspace management, Git bulk operations, and maintenance.
    """
    parser = argparse.ArgumentParser(
        description="Repository Manager - 100% Model-Driven Pydantic Graph Agent",
        formatter_class=argparse.RawTextHelpFormatter,
        epilog="""
Examples:
  # Standard setup (clones all missing repos in parallel)
  repository-manager --clone

  # Generate documentation catalog
  repository-manager --agents-md

  # Maintenance workflow (Bump patch version everywhere)
  repository-manager --maintain --bump patch

  # Selective operations
  repository-manager --repositories "genius-agent, gitlab-api" --pull
  """,
    )

    group_general = parser.add_argument_group("General Options")
    group_general.add_argument(
        "-v", "--version", action="version", version=f"%(prog)s {__version__}"
    )
    group_general.add_argument(
        "-f",
        "--file",
        type=str,
        help="Path to workspace.yml file (Standard Source).",
        default=DEFAULT_WORKSPACE_YML,
    )
    group_general.add_argument(
        "-w",
        "--workspace",
        type=str,
        help="Path to the workspace root directory (default: ~/Workspace).",
        default=DEFAULT_REPOSITORY_MANAGER_WORKSPACE,
    )
    group_general.add_argument(
        "-t",
        "--threads",
        type=int,
        help="Parallel thread count (default: 6).",
        default=DEFAULT_REPOSITORY_MANAGER_THREADS,
    )
    group_general.add_argument(
        "-r",
        "--repositories",
        type=str,
        help="Comma-separated list of repository names to filter operations.",
    )

    group_workspace = parser.add_argument_group("Workspace Management")
    group_workspace.add_argument(
        "--setup",
        action="store_true",
        help="Initialize workspace: directory structure & clones missing repos.",
    )
    group_workspace.add_argument(
        "--tree",
        action="store_true",
        help="Visualize workspace hierarchy as ASCII tree.",
    )
    group_workspace.add_argument(
        "--mermaid", action="store_true", help="Generate Mermaid graph of workspace."
    )
    group_workspace.add_argument(
        "--agents-md",
        action="store_true",
        help="Generate AGENTS.md catalog of discovered agents.",
    )
    group_workspace.add_argument(
        "--save",
        action="store_true",
        help="Save current in-memory config back to YAML (Updates).",
    )

    group_git = parser.add_argument_group("Git Bulk Operations (Parallelized)")
    group_git.add_argument(
        "--clone",
        action="store_true",
        help="Clone all missing repositories in the workspace.",
    )
    group_git.add_argument(
        "--pull", action="store_true", help="Pull latest changes for all projects."
    )
    group_git.add_argument(
        "--default-branch",
        action="store_true",
        help="Switch all repos to their default branch (via origin/HEAD).",
    )

    group_maintenance = parser.add_argument_group("Maintenance Lifecycle")
    group_maintenance.add_argument(
        "--install",
        action="store_true",
        help="Run 'pip install --break-system-packages -e .' for all projects.",
    )
    group_maintenance.add_argument(
        "--build", action="store_true", help="Run 'python -m build' for all projects."
    )
    group_maintenance.add_argument(
        "--validate",
        action="store_true",
        help="Run comprehensive pre-release validation.",
    )
    group_maintenance.add_argument(
        "--type",
        choices=[
            "all",
            "static-analysis",
            "runtime-validation",
            "mcp",
            "agent",
            "flat",
            "graph",
            "test",
            "pre-commit",
        ],
        default="all",
        help="Filter validation mode or target (default: all).",
    )
    group_maintenance.add_argument(
        "--pre-commit",
        action="store_true",
        help="Run pre-commit checks and autoupdate hooks.",
    )
    group_maintenance.add_argument(
        "--maintain",
        action="store_true",
        help="Execute phased maintenance (Bump -> Pre-commit -> Verify).",
    )
    group_maintenance.add_argument(
        "--push",
        action="store_true",
        help="Execute phased push.",
    )
    group_maintenance.add_argument(
        "--bump",
        choices=["patch", "minor", "major"],
        help="Version bump part (major/minor/patch). Use with --maintain or standalone.",
    )
    group_maintenance.add_argument(
        "--report",
        nargs="?",
        const=True,
        help="Export markdown summary results to a file (default: Workspace root).",
    )
    group_maintenance.add_argument(
        "--phase",
        type=int,
        default=1,
        help="Starting phase for maintenance lifecycle (1-3).",
    )
    group_maintenance.add_argument(
        "--single-phase",
        action="store_true",
        help="Only execute the specified phase, do not proceed to subsequent phases.",
    )
    group_maintenance.add_argument(
        "--project",
        type=str,
        help="Only execute maintenance operations for a specific project.",
    )
    group_maintenance.add_argument(
        "--dry-run",
        action="store_true",
        help="Perform maintenance operations without committing changes. Use with --maintain.",
    )
    group_maintenance.add_argument(
        "--allow-pre-commit",
        action="store_true",
        help="Execute the pre-commit phase during maintenance workflow. Pre-commits are skipped by default.",
    )
    group_maintenance.add_argument(
        "--config",
        type=str,
        help="Path to an overridden maintenance JSON/YAML configuration. Use with --maintain.",
    )
    group_maintenance.add_argument(
        "--break-system-packages",
        action="store_true",
        help="Include --break-system-packages in pip install commands.",
    )

    group_graph = parser.add_argument_group("Graph Intelligence (Hybrid Search)")
    group_graph.add_argument(
        "--graph-query",
        type=str,
        help="Query the Hybrid Graph using vector similarity or Cypher structure.",
    )
    group_graph.add_argument(
        "--graph-mode",
        choices=["semantic", "structural", "hybrid"],
        default="hybrid",
        help="Search mode for graph-query (default: hybrid).",
    )
    group_graph.add_argument(
        "--graph-path",
        nargs=2,
        metavar=("SOURCE", "TARGET"),
        help="Find the shortest path between two symbols across the workspace graph.",
    )
    group_graph.add_argument(
        "--graph-status", action="store_true", help="Show current graph metrics."
    )
    group_graph.add_argument(
        "--graph-reset",
        action="store_true",
        help="Purge the graph database and force a clean rebuild.",
    )
    group_graph.add_argument(
        "--graph-update",
        action="store_true",
        help="Incrementally update the Hybrid Graph with latest structural changes.",
    )
    group_graph.add_argument(
        "--graph-impact",
        type=str,
        help="Calculate multi-repo impact for a symbol.",
    )

    args = parser.parse_args()

    git = Git(
        path=args.workspace
        if args.workspace != DEFAULT_REPOSITORY_MANAGER_WORKSPACE
        else None,
        threads=args.threads,
        report_path=args.report,
    )
    clone_flag = args.clone
    pull_flag = args.pull

    if args.default_branch:
        git.set_to_default_branch = True

    if args.threads:
        git.set_threads(threads=args.threads)

    if args.file:
        if os.path.exists(args.file):
            if not git.load_projects_from_yaml(args.file):
                logger.warning(f"Could not load {args.file} as a valid Workspace YAML.")
        else:
            logger.error(f"Workspace file not found: {args.file}")
            parser.print_help()
            sys.exit(2)

    if not git.project_map and os.path.exists(DEFAULT_WORKSPACE_YML):
        git.load_projects_from_yaml(DEFAULT_WORKSPACE_YML)

    if args.repositories:
        repositories = args.repositories.replace(" ", "").split(",")
        names_to_keep = set(repositories)
        if git.project_map:
            filtered = {}
            for url, path in git.project_map.items():
                name = url.split("/")[-1].replace(".git", "")
                if name in names_to_keep:
                    filtered[url] = path
            git.project_map = filtered
        else:
            for r in repositories:
                if "/" in r:
                    name = r.split("/")[-1].replace(".git", "")
                    git.project_map[r] = os.path.join(git.path, name)
                else:
                    git.project_map[os.path.join("https://github.com/", r)] = (
                        os.path.join(git.path, r)
                    )

    if args.file and os.path.exists(args.file):
        if args.tree:
            print(git.generate_workspace_tree(args.file))
            sys.exit(0)
        if args.mermaid:
            print(git.generate_workspace_mermaid(args.file))
            sys.exit(0)
        if args.agents_md:
            logger.info(f"Generating AGENTS.md catalog in {git.path}...")
            git.generate_agents_md()
            sys.exit(0)
        if args.setup:
            logger.info(f"Setting up workspace from {args.file}...")
            git.load_projects_from_yaml(args.file)

    if clone_flag:
        git.clone_projects()
    if pull_flag:
        git.pull_projects()

    if args.pre_commit:
        git.pre_commit_projects(run=True, autoupdate=True)

    if args.install:
        results = git.install_projects()
        summary = git.generate_markdown_summary("Installation", results)
        print(summary)
        git._export_report(summary, "install_report.md")

    if args.build:
        results = git.build_projects()
        summary = git.generate_markdown_summary("Build", results)
        print(summary)
        git._export_report(summary, "build_report.md")

    has_errors = False

    if args.validate:
        report = git.validate_projects(type=args.type)
        if report and report.failure_count > 0:
            has_errors = True
            logger.error("Validation failed with errors. Check the report for details.")

    if args.bump and not args.maintain:
        if has_errors and (args.push or args.bump):
            logger.error("Skipping bump due to preceding validation errors.")
            has_errors = True
        else:
            logger.info(f"Bumping version ({args.bump}) for all projects...")
            project_dirs = list(git.project_map.values())
            results = []
            for d in project_dirs:
                if (Path(d) / ".bumpversion.cfg").exists():
                    res = git.bump_version(
                        args.bump, allow_dirty=True, path=d, dry_run=args.dry_run
                    )
                    results.append(res)
                    if res.status == "error":
                        has_errors = True

            summary = git.generate_markdown_summary("Bulk Version Bump", results)
            print(summary)
            git._export_report(summary, "version_bump_report.md")

    if args.maintain:
        if has_errors and (args.push or args.maintain):
            logger.error(
                "Skipping maintenance bump due to preceding validation errors."
            )
            has_errors = True
        else:
            config = None
            if args.config:
                try:
                    with open(args.config) as f:
                        config = json.load(f)
                except Exception as e:
                    logger.error(f"Failed to load config from {args.config}: {e}")
                    sys.exit(1)

            results = git.phased_bumpversion(
                part=args.bump if args.bump else "patch",
                start_phase=args.phase,
                dry_run=args.dry_run,
                allow_pre_commit=args.allow_pre_commit,
                config=config,
                single_phase=args.single_phase,
                project_filter=args.project,
            )

            for res in results:
                if res.status == "error":
                    has_errors = True

            summary = git.generate_markdown_summary("Phased Maintenance Bump", results)

            print(summary)
            git._export_report(summary, "maintenance_report.md")

    if args.push:
        if has_errors:
            logger.error("Skipping push due to preceding validation or bump errors.")
        else:
            config = None
            if args.config:
                try:
                    with open(args.config) as f:
                        config = json.load(f)
                except Exception as e:
                    logger.error(f"Failed to load config from {args.config}: {e}")
                    sys.exit(1)
            push_results = git.phased_push(
                start_phase=args.phase,
                config=config,
                single_phase=args.single_phase,
                project_filter=args.project,
            )
            summary = git.generate_markdown_summary("Phased Push", push_results)
            print(summary)
            git._export_report(summary, "push_report.md")

    # Graph Operations
    if args.graph_status:
        print(json.dumps(git.graph_status(), indent=2))
    if args.graph_reset:
        print(git.graph_reset())
    if args.graph_update:
        logger.info("Starting structural graph update phase...")
        graph_report = git.ensure_graph()
        if graph_report:
            print(
                f"\nHybrid Graph Execution Complete\nNodes Processed: {graph_report.get('nodes', 0)}\nEdges Processed: {graph_report.get('edges', 0)}\n"
            )
        else:
            print("Graph update returned no results or is disabled.")
    if args.graph_query:
        import asyncio

        query_res = asyncio.run(git.graph_query(args.graph_query, mode=args.graph_mode))
        print(json.dumps(query_res, indent=2))
    if args.graph_path:
        path_res = git.graph_path(args.graph_path[0], args.graph_path[1])
        print(json.dumps(path_res, indent=2))
    if args.graph_impact:
        import asyncio

        impact_res = asyncio.run(git.graph_impact(args.graph_impact))
        print(json.dumps(impact_res, indent=2))


if __name__ == "__main__":
    """
    Execute the main function when the script is run directly.
    """
    main()
