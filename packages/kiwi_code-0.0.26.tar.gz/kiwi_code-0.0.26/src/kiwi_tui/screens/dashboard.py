"""Dashboard screen for Autobots TUI."""

from __future__ import annotations

from textual.app import ComposeResult
from textual.binding import Binding
from textual.screen import Screen
from textual.widgets import Header, Footer, Input, Static, Button, Markdown, LoadingIndicator
from textual.containers import Vertical, VerticalScroll, Horizontal, Center
from kiwi_tui.screens.file_browser import FileBrowserScreen
from kiwi_tui.screens.attach_content import AttachContentScreen
from kiwi_tui.screens.slash_picker import SlashPickerScreen
from kiwi_tui.screens.id_picker import IdPickerScreen
from kiwi_tui.screens.command_result import CommandResultScreen
from kiwi_tui.screens.help import HelpScreen
from kiwi_tui.widgets import ChatInput
from kiwi_tui.inline_file_picker import InlineFilePicker
from textual.worker import Worker, WorkerState
from loguru import logger
import json
import asyncio
import subprocess
import sys
import time
import re
import html
from pathlib import Path


class UserMessageRow(Horizontal):
    """A single user message rendered with a styled 'You' label."""

    def __init__(self, text: str, *, classes: str = "") -> None:
        super().__init__(classes=classes)
        self._text = text

    def compose(self) -> ComposeResult:
        yield Static("YOU:", classes="user-label", markup=False)
        yield Static(self._text, classes="user-body", markup=False)



class AssistantMessageRow(Horizontal):
    """A single assistant message rendered with a left dot + markdown body."""

    def __init__(self, markdown_text: str, *, classes: str = "") -> None:
        super().__init__(classes=classes)
        self._markdown_text = markdown_text

    def compose(self) -> ComposeResult:
        # Solid dot marker on the left side of the model response.
        yield Static("●", classes="assistant-dot", markup=False)
        yield Markdown(self._markdown_text, classes="assistant-body")

    def update_markdown(self, markdown_text: str) -> None:
        """Update the markdown content in-place."""
        self._markdown_text = markdown_text
        try:
            self.query_one(".assistant-body", Markdown).update(markdown_text)
        except Exception:
            # Defensive: if the widget tree isn't ready or the child was removed.
            pass

# Footer hint for inserting a newline differs by OS:
# - macOS terminals often don't forward modified Enter combos to terminal apps reliably, so we advertise Ctrl+N.
# - Windows terminals tend to support Shift+Enter for multi-line input.
NEWLINE_HINT_BINDING = (
    Binding("ctrl+n", "hint_newline", "↩ newline (Mac)", show=True, priority=True)
    if sys.platform == "darwin"
    else Binding("shift+enter", "hint_newline", "↩ newline (Win)", show=True, priority=True)
)

class DashboardScreen(Screen):
    """Main dashboard screen showing overview and stats."""

    DEFAULT_ACTION_ID = "69c2180355a89324a9926bc6"

    BINDINGS = [
        Binding("ctrl+u", "hint_upload", "@ files", show=True, priority=True),
        Binding("ctrl+g", "hint_slash", "/ commands", show=True, priority=True),
        NEWLINE_HINT_BINDING,
        Binding("ctrl+c", "screen.copy_text", "copy", show=True, priority=True),
        Binding("ctrl+j", "hint_send", "↵ send", show=True, priority=True),
        Binding("ctrl+o", "show_logs", "logs", show=True, priority=True),
        Binding("ctrl+r", "copy_run_id", "copy run id", show=False, priority=True),
    ]

    def __init__(self, *args, **kwargs):
        """Initialize the dashboard screen."""
        super().__init__(*args, **kwargs)
        self.current_action_id = self.DEFAULT_ACTION_ID
        self.current_run_id = None  # Track the current conversation run_id
        self.active_stream_tasks = []  # Track active SSE stream tasks to cancel them
        self._last_listed_ids: list[str] = []  # Index for #N shortcuts
        self._pending_urls: list[str] = []  # File URLs to attach to next message
        self._metadata: dict = {}  # Persistent metadata for all subsequent runs
        self._is_streaming: bool = False  # Track streaming state for send/stop toggle

        self._cmd_running: bool = False  # True while a /command is executing


        # Prevent toast spam from covering the Copy button.
        self._last_copy_notify_at: float = 0.0

        # Ensures Textual widget IDs remain unique even if the same list command is run multiple times.
        self._clickable_list_seq: int = 0

    CSS = """
    DashboardScreen {
        background: $background;
    }

    #messages {
        height: 1fr;
        width: 100%;
        background: $background;
    }

    #run-status-bar {
        width: 100%;
        height: 5;
        background: $background;
    }

    #status-action-col {
        width: 1fr;
    }

    #status-run-col {
        width: 44;
        align: right top;
    }



    #status-action, #status-run {
        width: 100%;
        height: 1;
        padding: 0 1;
        color: $brand-cyan;
        opacity: 1;
        text-style: bold;
        background: $background;
        content-align: left middle;
    }


    /* Keep run id pinned to the right edge (Windows terminals are often wide). */
    #status-run {
        width: auto;
        padding: 0;
    }
    #copy-run-id {
        width: auto;
        /* Explicit height so the full border (top+bottom) is visible. */
        height: 3;
        padding: 0 1;
        margin: 0;
    }



    #activity-bar {
        width: 100%;
        height: 1;
        padding: 0 1;
        color: $secondary;
        background: $background;
        display: none;
    }

    #activity-bar.visible {
        display: block;
    }

    #activity-spinner {
        width: 2;
        height: 1;
    }

    #activity-text {
        width: 1fr;
        height: 1;
        padding: 0 1;
    }


    #bottom-area, #input-bar, #input-row, #pending-files-bar {
        background: $background;
    }

    .message {
        width: 100%;
        height: auto;
        padding: 0 1;
        /* Add breathing room between all messages (user/assistant/info/error/etc.). */
        margin: 1 0 0 0;
    }

    .user-message {
        color: $accent;
        background: $user-msg-bg;
    }

    .user-label {
        width: auto;
        color: $brand-cyan;
        text-style: bold;
        padding: 0 1 0 0;
    }

    .user-body {
        width: 1fr;
        color: $foreground;
    }

    .assistant-message {
        color: $text;
        padding: 0 1;
    }

    .assistant-dot {
        width: 2;
        padding: 0 1 0 0;
        color: $brand-cyan;
        text-style: bold;
        content-align: center top;
    }

    .assistant-body {
        width: 1fr;
    }

    .assistant-message Markdown {
        margin: 0;
        padding: 0;
        width: 1fr;
    }

    .error-message {
        color: $error;
    }

    .info-message {
        color: $secondary;
        text-style: italic;
    }

    #bottom-area {
        height: auto;
        width: 100%;
    }

    #input-bar {
        height: auto;
        width: 100%;
        padding: 0;
    }

    #pending-files-bar {
        height: auto;
        width: 100%;
        padding: 0 1;
        color: $secondary;
    }

    #input-row {
        height: auto;
        width: 100%;
    }

    #button-row {
        display: none;
    }

    #button-spacer {
        width: 1fr;
        height: 1;
        background: transparent;
    }


    #chat-input {
        width: 1fr;
        height: 3;
        background: $background;
        border: none;
        border-top: solid $accent;
        border-bottom: solid $accent;
    }

    #chat-input:focus {
        background: $background;
        border: none;
        border-top: solid $primary;
        border-bottom: solid $primary;
    }

    Header {
        background: $background;
        color: $foreground;
    }

    Header > HeaderTitle {
        background: $background;
        color: $foreground;
        text-style: none;
    }

    Footer {
        background: $background;
        color: $foreground;
    }

    Footer > .footer--key {
        background: $background;
        color: $foreground;
        text-style: none;
    }

    Footer > .footer--description {
        background: $background;
        color: $foreground;
    }

    Footer > .footer--highlight {
        background: $background;
        color: $foreground;
    }

    Footer > .footer--highlight-key {
        background: $background;
        color: $brand-cyan;
        text-style: none;
    }

    #upload-btn, #slash-btn, #send-btn {
        width: auto;
        min-width: 3;
        height: 1;
        margin: 0 2 0 0;
        padding: 0 1;
        background: transparent;
        color: $primary;
        border: none;
        text-style: none;
        text-align: center;
        content-align: center middle;
    }

    #upload-btn:hover, #slash-btn:hover, #send-btn:hover {
        background: transparent;
        color: $text;
        text-style: none;
    }

    #send-btn.streaming {
        background: transparent;
        color: $error;
        border: none;
    }

    #send-btn.streaming:hover {
        background: transparent;
        color: $warning;
    }

    .action-row {
        height: auto;
        width: 100%;
        padding: 0 1;
    }

    .action-btn {
        width: 100%;
        height: auto;
        min-height: 1;
        padding: 0 1;
        margin: 0;
        background: transparent;
        color: $accent;
        border: none;
        text-align: left;
        content-align: left middle;
    }

    .action-btn:hover {
        background: $primary-background;
        color: $primary;
        text-style: bold;
    }
    .action-btn:focus {
        background: transparent;
        border: none;
    }
    """

    def compose(self) -> ComposeResult:
        """Compose dashboard widgets."""
        yield Header(icon="❊")

        with VerticalScroll(id="messages"):
            pass

        with Vertical(id="bottom-area"):
            yield InlineFilePicker(id="inline-file-picker")

            # Keep action/run info visible near the input (no need to scroll up).
            with Horizontal(id="run-status-bar"):
                with Vertical(id="status-action-col"):
                    yield Static("", id="status-action", markup=False)
                with Vertical(id="status-run-col"):
                    with Center():
                        yield Static("", id="status-run", markup=False)
                    with Center():
                        yield Button("Copy", id="copy-run-id", variant="default")

            with Vertical(id="input-bar"):
                with Horizontal(id="activity-bar"):
                    yield LoadingIndicator(id="activity-spinner")
                    yield Static("", id="activity-text", markup=False)
                yield Static("", id="pending-files-bar", markup=False)
                with Horizontal(id="input-row"):
                    yield ChatInput(placeholder="Message... (@ for files, / for commands)", id="chat-input")
                with Horizontal(id="button-row"):
                    yield Button("+", id="upload-btn", variant="default")
                    yield Button("/", id="slash-btn", variant="default")
                    yield Static("", id="button-spacer")
                    yield Button("Send", id="send-btn", variant="default")

        yield Footer()

    def on_mount(self) -> None:
        """Called when screen is mounted."""
        self.query_one("#chat-input", ChatInput).focus()


        self._update_run_status_bar()

    def _update_run_status_bar(self) -> None:
        """Update the small status line above the input (action/run state)."""
        try:
            action_w = self.query_one("#status-action", Static)
            run_w = self.query_one("#status-run", Static)
        except Exception:
            return
        run_id = self.current_run_id or "(none)"
        action_w.update(f"Action: {self.current_action_id}")
        run_w.update(f"Run: {run_id}")

    def action_show_logs(self) -> None:
        """Keyboard shortcut: open the CLI runtime logs."""
        self.open_runtime_logs()

    def open_runtime_logs(self) -> None:
        """Open the runtime logs screen for the current run (or pending runtime)."""
        from kiwi_tui.screens.runtime_logs import RuntimeLogsScreen
        from kiwi_tui.runtime_agent import log_path_for_run, log_path_for_pending

        lp = None
        title = "CLI logs"
        if self.current_run_id:
            lp = log_path_for_run(self.current_run_id)
            title = f"CLI logs — run {self.current_run_id}"
        else:
            pending_id = getattr(self.app, "pending_runtime_id", None)
            if pending_id:
                lp = log_path_for_pending(pending_id)
                title = f"CLI logs — pending {pending_id}"

        if not lp:
            self.notify("No CLI runtime logs available (use /connect-cli first).", severity="warning")
            return
        self.app.push_screen(RuntimeLogsScreen(lp, title=title))


    def on_chat_input_at_triggered(self, event: ChatInput.AtTriggered) -> None:
        """Handle @ key — open the file browser modal.

        The inline picker is scoped to the current working directory. For
        attachments, we want users to be able to pick any file they have access
        to on disk, even when the *runtime* is in restricted mode.

        Note: allowing upload/attach doesn't imply the runtime can read the local
        path later in restricted mode, and that's OK.
        """
        from kiwi_tui.screens.file_browser import FileBrowserScreen

        chat_input = self.query_one("#chat-input", ChatInput)

        # Best-effort: hide the inline picker (if present) and strip the trailing
        # "@..." from the input before showing the modal.
        try:
            picker = self.query_one("#inline-file-picker", InlineFilePicker)
            picker.hide_picker()
        except Exception:
            pass
        chat_input.picker_active = False

        val = chat_input.value
        at_pos = val.rfind("@")
        if at_pos != -1:
            chat_input.value = val[:at_pos]

        # Open the full file browser; it returns list[str] of selected files.
        self.app.push_screen(FileBrowserScreen(), callback=self._on_files_selected)

    def on_chat_input_at_filter_changed(self, event: ChatInput.AtFilterChanged) -> None:
        """Update inline file picker filter."""
        picker = self.query_one("#inline-file-picker", InlineFilePicker)
        if picker.is_visible:
            picker.filter(event.filter_text)

    def on_chat_input_at_picker_navigate(self, event: ChatInput.AtPickerNavigate) -> None:
        """Navigate inline file picker."""
        picker = self.query_one("#inline-file-picker", InlineFilePicker)
        if picker.is_visible:
            picker.move_highlight(event.delta)

    def on_chat_input_at_picker_select(self, event: ChatInput.AtPickerSelect) -> None:
        """Select file from inline picker."""
        picker = self.query_one("#inline-file-picker", InlineFilePicker)
        if picker.is_visible:
            picker.select_highlighted()

    def on_chat_input_at_picker_cancel(self, event: ChatInput.AtPickerCancel) -> None:
        """Cancel inline file picker."""
        self._close_inline_picker()

    def on_inline_file_picker_file_selected(self, event: InlineFilePicker.FileSelected) -> None:
        """Handle file selection from inline picker — upload the file."""
        self._close_inline_picker()
        file_path = event.path
        self._on_files_selected([file_path])

    def on_inline_file_picker_cancelled(self, event: InlineFilePicker.Cancelled) -> None:
        """Handle inline picker cancellation."""
        self._close_inline_picker()

    def _close_inline_picker(self) -> None:
        """Close the inline file picker and clean up @ text from input."""
        picker = self.query_one("#inline-file-picker", InlineFilePicker)
        chat_input = self.query_one("#chat-input", ChatInput)
        picker.hide_picker()
        chat_input.picker_active = False
        # Remove the @... text from the input
        val = chat_input.value
        at_pos = val.rfind("@")
        if at_pos != -1:
            chat_input.value = val[:at_pos]
        chat_input.focus()

    def on_chat_input_changed(self, event: ChatInput.Changed) -> None:
        """Track text changes to update inline file picker filter."""
        chat_input = event.text_area
        if not chat_input.picker_active:
            return
        val = chat_input.value
        at_pos = val.rfind("@")
        if at_pos == -1:
            # @ was deleted — close picker
            self._close_inline_picker()
            return
        filter_text = val[at_pos + 1 :]
        picker = self.query_one("#inline-file-picker", InlineFilePicker)
        picker.filter(filter_text)

    def on_chat_input_submitted(self, event: ChatInput.Submitted) -> None:
        """Handle message submission (Enter)."""
        self._do_send()

    def handle_slash_command(self, command: str) -> None:
        """Schedule a slash command to run without blocking the UI."""
        # If a command is already running, ignore (prevents the "hung" feeling / double execution).
        if self._cmd_running:
            return

        # /help is a UI-first experience (picker + copy). Don't run it through the CLI dispatcher.
        if command.strip().lower() == "/help":
            self.app.push_screen(HelpScreen())
            try:
                self.query_one("#chat-input", ChatInput).focus()
            except Exception:
                pass
            return

        self._set_command_running(True, f"Running {command} ...")
        self.run_worker(
            self._handle_slash_command_async(command),
            group="cmd",
            exclusive=True,
            exit_on_error=False,
        )

    async def _handle_slash_command_async(self, command: str) -> None:
        """Async implementation of slash-command dispatch.

        Important: any network / blocking calls must run in a thread via asyncio.to_thread
        so the Textual UI stays responsive and can render the loading indicator.
        """
        try:
            parts = command.strip().split()
            if not parts:
                return
            cmd = parts[0].lower()
            args = parts[1:]

            def show(body: str, *, is_error: bool = False, title: str | None = None) -> None:
                self._show_command_result(title or command, body, is_error=is_error)

            # --- TUI-specific commands ---

            if cmd == "/upload":
                if not args:
                    show("Usage: /upload <file_path> [file_path2 ...]")
                    return
                if not hasattr(self.app, "autobots_client"):
                    show("Error: Client not initialized", is_error=True)
                    return
                success, urls, message = await asyncio.to_thread(
                    lambda: self.app.autobots_client.upload_files(args)
                )
                if success:
                    self._pending_urls.extend(urls)
                    uploaded_names = [Path(u.rsplit("/", 1)[-1]).name for u in urls]
                    self._update_pending_files_bar()
                    show(
                        "Uploaded files:\n\n"
                        + "\n".join(f"- {name}" for name in uploaded_names)
                        + "\n\nAttached to your next message.",
                        title=command,
                    )
                else:
                    show(f"Upload failed: {message}", is_error=True)
                return

            if cmd == "/files":
                if self._pending_urls:
                    body = "Pending files:\n\n" + "\n".join(f"- {u}" for u in self._pending_urls)
                else:
                    body = "No files pending. Use /upload <path> to attach files."
                show(body)
                return

            if cmd == "/clear-files":
                count = len(self._pending_urls)
                self._pending_urls.clear()
                self._update_pending_files_bar()
                show(f"Cleared {count} pending file(s).")
                return

            if cmd == "/login":
                if self.app.token_manager.is_authenticated():
                    show("Already logged in. Use /logout first to switch accounts.")
                    return
                self.app.push_screen("login")
                return

            if cmd == "/logout":
                self.app.action_logout()
                return

            if cmd == "/metadata":
                if not args:
                    effective = {
                        "process_url_in_text": False,
                        "process_attachment_url": True,
                        "attachment_requested": 0,
                    }
                    effective.update(self._metadata)
                    overrides = f" (overrides: {', '.join(self._metadata.keys())})" if self._metadata else ""
                    show(f"Effective metadata{overrides}:\n\n```json\n{json.dumps(effective, indent=2)}\n```")
                    return
                sub = args[0].lower()
                if sub == "set":
                    if len(args) < 3:
                        show("Usage: /metadata set <key> <value>")
                        return
                    key = args[1]
                    raw_value = " ".join(args[2:])
                    if raw_value.lower() == "true":
                        value = True
                    elif raw_value.lower() == "false":
                        value = False
                    else:
                        try:
                            value = int(raw_value)
                        except ValueError:
                            try:
                                value = float(raw_value)
                            except ValueError:
                                value = raw_value
                    self._metadata[key] = value
                    show(f"Metadata set: {key} = {value}")
                elif sub == "remove":
                    if len(args) < 2:
                        show("Usage: /metadata remove <key>")
                        return
                    key = args[1]
                    if key in self._metadata:
                        del self._metadata[key]
                        show(f"Metadata removed: {key}")
                    else:
                        show(f"Key not found: {key}", is_error=True)
                elif sub == "clear":
                    self._metadata.clear()
                    show("Metadata cleared.")
                else:
                    show(
                        "Usage:\n"
                        "- /metadata\n"
                        "- /metadata set <key> <value>\n"
                        "- /metadata remove <key>\n"
                        "- /metadata clear"
                    )
                return

            if cmd == "/cancel":
                workers = self.workers
                for worker in workers:
                    if not worker.is_finished:
                        worker.cancel()
                self._set_streaming(False)
                show("Cancelled active request.")
                return

            if cmd == "/connect-cli":
                # Ensure the correct local CLI agent is running.
                #
                # Runtime identity is per run_id. If we haven't started a run yet
                # (current_run_id is None), we start a *pending* runtime and bind it
                # once the run_id is created.
                try:
                    if self.current_run_id:
                        self.app.ensure_runtime_for_run_id(self.current_run_id)
                    else:
                        self.app.ensure_pending_runtime()
                except Exception:
                    pass

                prompt = "Connect to the CLI right now before asking or doing anything."
                # Show the prompt as a user message for transparency, then run it.
                self.add_message(prompt, "user")
                self.process_message(prompt)
                return

            if cmd == "/show-logs":
                self.open_runtime_logs()
                return

            if cmd == "/new":
                for worker in self.workers:
                    if not worker.is_finished:
                        worker.cancel()
                self._set_streaming(False)
                self.current_action_id = self.DEFAULT_ACTION_ID
                self.current_run_id = None
                self._update_run_status_bar()
                self._clear_chat_messages()
                show(f"Starting new conversation with default action ({self.DEFAULT_ACTION_ID}).")
                return
            if cmd == "/use":
                if not args:
                    show("Usage: /use <action_id>")
                    return
                action_id = args[0]
                api_client = self._get_api_client_for_command(command)
                if not api_client:
                    return
                from kiwi_cli.commands import actions_get
                lines = await asyncio.to_thread(lambda: actions_get(api_client, id=action_id))
                if lines and lines[0].startswith("Error"):
                    show(f"Action not found: {action_id}", is_error=True)
                    return
                self.current_action_id = action_id
                self.current_run_id = None
                self._update_run_status_bar()
                self._clear_chat_messages()
                show("\n".join(["Switched to action:"] + lines))
                return

            if cmd == "/continue":
                if not args:
                    show("Usage: /continue <run_id>")
                    return
                run_id = args[0]
                api_client = self._get_api_client_for_command(command)
                if not api_client:
                    return
                from kiwi_cli.commands import runs_get
                lines = await asyncio.to_thread(lambda: runs_get(api_client, id=run_id))
                if lines and lines[0].startswith("Error"):
                    show(f"Run not found: {run_id}", is_error=True)
                    return
                self.current_run_id = run_id
                self._update_run_status_bar()
                show("\n".join(["Continuing run:"] + lines))
                await self._load_conversation_history_async(run_id)
                return

            if cmd == "/status":
                info = [
                    f"Action ID:  {self.current_action_id}",
                    f"Run ID:     {self.current_run_id or '(none — next message starts new run)'}",
                ]
                api_client = self._get_api_client_for_command(command)
                if api_client:
                    from kiwi_cli.commands import actions_get
                    action_lines = await asyncio.to_thread(
                        lambda: actions_get(api_client, id=self.current_action_id)
                    )
                    if action_lines and not action_lines[0].startswith("Error"):
                        info.append("")
                        info.extend(action_lines)
                show("\n".join(info))
                return

            if cmd == "/runtime":
                show("Runtime commands are currently disabled.", is_error=True)
                return

            # --- Shared commands (dispatch to kiwi_cli.commands) ---

            api_client = self._get_api_client_for_command(command)
            if not api_client:
                return

            stripped = command.strip().lstrip("/").split()
            group = stripped[0].lower() if stripped else ""
            sub = stripped[1].lower() if len(stripped) > 1 else ""
            is_list = sub == "list" or sub == ""

            if group == "actions" and is_list:
                await self._render_actions_list_async(command, api_client)
                return
            if group == "runs" and is_list:
                await self._render_runs_list_async(command, api_client)
                return
            if group == "graphs" and is_list:
                await self._render_graphs_list_async(command, api_client)
                return
            if group in ("graph-runs", "graph_runs") and is_list:
                await self._render_graph_runs_list_async(command, api_client)
                return

            from kiwi_cli.commands import dispatch
            try:
                lines = await asyncio.to_thread(lambda: dispatch(command, api_client))
                show("\n".join(lines))
            except Exception as e:
                show(f"Command error: {e}", is_error=True)
        except Exception as e:
            # Last-resort handler: never crash the TUI for command errors.
            self._show_command_result(command, f"Command error: {e}", is_error=True)
        finally:
            self._set_command_running(False)

    async def _load_conversation_history_async(self, run_id: str) -> None:
        """Fetch and render conversation history without blocking the UI."""
        if not hasattr(self.app, "autobots_client"):
            return
        success, result, _msg = await asyncio.to_thread(
            lambda: self.app.autobots_client.get_action_result(run_id)
        )
        if not success or not result:
            return
        self._render_conversation_history_from_action_result(result)

    async def _render_actions_list_async(self, command: str, api_client) -> None:
        from kiwi_cli.commands import _val, _fmt_date
        from autobots_client.api.actions import list_actions_v1_actions_get
        from autobots_client.types import UNSET
        opts = self._parse_command_opts(command)
        name = opts.get("name")
        limit = int(opts.get("limit", "20"))
        offset = int(opts.get("offset", "0"))
        resp = await asyncio.to_thread(
            lambda: list_actions_v1_actions_get.sync_detailed(
                client=api_client,
                name=name if name else UNSET,
                limit=limit,
                offset=offset,
            )
        )
        if resp.status_code != 200 or not resp.parsed:
            self._show_command_result(command, f"Error: HTTP {resp.status_code}", is_error=True)
            return
        result = resp.parsed
        title = (
            f"Actions ({result.total_count} total, showing {result.offset}-{result.offset + len(result.docs)}). "
            "Select an action"
        )
        options: list[tuple[str, str]] = []
        for idx, doc in enumerate(result.docs, 1):
            label = (
                f"{idx:<4} {_val(doc.name):<30} {_val(doc.type_.value):<25} "
                f"{_val(doc.version):<6} {_fmt_date(doc.created_at)}"
            )
            options.append((doc.field_id, label))
        self.app.push_screen(IdPickerScreen(title, options), callback=self._on_action_picked)

    async def _render_runs_list_async(self, command: str, api_client) -> None:
        from kiwi_cli.commands import _val, _fmt_date
        from autobots_client.api.action_results import list_action_result_v1_action_results_get
        from autobots_client.types import UNSET
        from autobots_client.models.event_result_status import EventResultStatus
        opts = self._parse_command_opts(command)
        status_enum = UNSET
        if opts.get("status"):
            try:
                status_enum = EventResultStatus(opts["status"].lower())
            except ValueError:
                self._show_command_result(
                    command,
                    f"Invalid status: {opts['status']}. Valid: processing, success, error, stuck, waiting",
                    is_error=True,
                )
                return
        resp = await asyncio.to_thread(
            lambda: list_action_result_v1_action_results_get.sync_detailed(
                client=api_client,
                action_id=opts.get("action_id") or UNSET,
                action_name=opts.get("action_name") or UNSET,
                status=status_enum,
                limit=int(opts.get("limit", "20")),
                offset=int(opts.get("offset", "0")),
            )
        )
        if resp.status_code != 200 or not resp.parsed:
            self._show_command_result(command, f"Error: HTTP {resp.status_code}", is_error=True)
            return
        result = resp.parsed
        title = (
            f"Action Runs ({result.total_count} total, showing {result.offset}-{result.offset + len(result.docs)}). "
            "Select a run"
        )
        options: list[tuple[str, str]] = []
        for idx, doc in enumerate(result.docs, 1):
            label = (
                f"{idx:<4} {doc.status.value:<12} {_val(doc.name):<30} "
                f"{_fmt_date(doc.created_at):<18} {_fmt_date(doc.updated_at)}"
            )
            options.append((doc.field_id, label))
        self.app.push_screen(IdPickerScreen(title, options), callback=self._on_run_picked)

    async def _render_graphs_list_async(self, command: str, api_client) -> None:
        from kiwi_cli.commands import _val, _fmt_date
        from autobots_client.api.action_graphs import list_action_graphs_v1_action_graphs_get
        from autobots_client.types import UNSET
        opts = self._parse_command_opts(command)
        name = opts.get("name")
        limit = int(opts.get("limit", "20"))
        offset = int(opts.get("offset", "0"))
        resp = await asyncio.to_thread(
            lambda: list_action_graphs_v1_action_graphs_get.sync_detailed(
                client=api_client,
                name=name if name else UNSET,
                limit=limit,
                offset=offset,
            )
        )
        if resp.status_code != 200 or not resp.parsed:
            self._show_command_result(command, f"Error: HTTP {resp.status_code}", is_error=True)
            return
        result = resp.parsed
        title = (
            f"Action Graphs ({result.total_count} total, showing {result.offset}-{result.offset + len(result.docs)}). "
            "Select a graph"
        )
        options: list[tuple[str, str]] = []
        for idx, doc in enumerate(result.docs, 1):
            label = (
                f"{idx:<4} {_val(doc.name):<30} {_val(doc.version):<6} "
                f"{_val(doc.is_published):<10} {_fmt_date(doc.created_at)}"
            )
            options.append((doc.field_id, label))
        self.app.push_screen(IdPickerScreen(title, options), callback=self._on_graph_picked)

    async def _render_graph_runs_list_async(self, command: str, api_client) -> None:
        from kiwi_cli.commands import _val, _fmt_date
        from autobots_client.api.action_graphs_results import (
            list_action_graph_result_v1_action_graphs_results_get,
        )
        from autobots_client.types import UNSET
        from autobots_client.models.event_result_status import EventResultStatus
        opts = self._parse_command_opts(command)
        status_enum = UNSET
        if opts.get("status"):
            try:
                status_enum = EventResultStatus(opts["status"].lower())
            except ValueError:
                self._show_command_result(
                    command,
                    f"Invalid status: {opts['status']}. Valid: processing, success, error, stuck, waiting",
                    is_error=True,
                )
                return
        resp = await asyncio.to_thread(
            lambda: list_action_graph_result_v1_action_graphs_results_get.sync_detailed(
                client=api_client,
                action_graph_id=opts.get("graph_id") or UNSET,
                action_graph_name=opts.get("graph_name") or UNSET,
                status=status_enum,
                limit=int(opts.get("limit", "20")),
                offset=int(opts.get("offset", "0")),
            )
        )
        if resp.status_code != 200 or not resp.parsed:
            self._show_command_result(command, f"Error: HTTP {resp.status_code}", is_error=True)
            return
        result = resp.parsed
        title = (
            f"Action Graph Runs ({result.total_count} total, showing {result.offset}-{result.offset + len(result.docs)}). "
            "Select a graph run"
        )
        options: list[tuple[str, str]] = []
        for idx, doc in enumerate(result.docs, 1):
            label = (
                f"{idx:<4} {doc.status.value:<12} {_val(doc.name):<30} "
                f"{_fmt_date(doc.created_at):<18} {_fmt_date(doc.updated_at)}"
            )
            options.append((doc.field_id, label))
        self.app.push_screen(IdPickerScreen(title, options), callback=self._on_graph_run_picked)


    def _get_api_client(self):
        """Get the AuthenticatedClient for API calls. Returns None with error message if not available."""
        from autobots_client import AuthenticatedClient

        if not hasattr(self.app, 'autobots_client'):
            self.add_message("Error: Client not initialized", "error")
            return None

        api_client = self.app.autobots_client.client
        if not isinstance(api_client, AuthenticatedClient):
            self.add_message("Error: Not authenticated", "error")
            return None
        return api_client

    def _show_command_result(self, title: str, body: str, *, is_error: bool = False) -> None:
        """Show command output in a modal (keeps it out of the chat timeline)."""
        self.app.push_screen(CommandResultScreen(title, body, is_error=is_error))

    def _get_api_client_for_command(self, title: str):
        """Get API client for slash commands without writing errors into chat."""
        from autobots_client import AuthenticatedClient

        if not hasattr(self.app, 'autobots_client'):
            self._show_command_result(title, "Error: Client not initialized", is_error=True)
            return None

        api_client = self.app.autobots_client.client
        if not isinstance(api_client, AuthenticatedClient):
            self._show_command_result(title, "Error: Not authenticated (try /login)", is_error=True)
            return None

        return api_client


    def _parse_command_opts(self, command: str, skip: int = 2) -> dict[str, str]:
        """Parse --key value pairs from a slash command string."""
        parts = command.strip().split()
        opts = {}
        i = skip
        while i < len(parts):
            if parts[i].startswith("--") and i + 1 < len(parts):
                opts[parts[i][2:].replace("-", "_")] = parts[i + 1]
                i += 2
            else:
                i += 1
        return opts

    def _mount_clickable_list(self, header: str, rows: list[tuple[str, str]]) -> None:
        """Mount a header and clickable button rows into the messages area.

        Note: Textual requires every widget ID to be globally unique. If the user runs
        the same list command multiple times (e.g. `/actions list` twice), we must not
        reuse the same IDs, otherwise Textual raises DuplicateIds.
        """
        self._clickable_list_seq += 1
        seq = self._clickable_list_seq

        messages = self.query_one("#messages", VerticalScroll)
        messages.mount(Static(header, classes="message info-message"))
        for base_id, label in rows:
            unique_id = f"{base_id}__{seq}"
            messages.mount(Button(label, id=unique_id, classes="action-btn"))
        messages.scroll_end(animate=False)
        self.query_one("#chat-input", ChatInput).focus()

    def _render_actions_list(self, command: str, api_client) -> None:
        """Render /actions list with clickable rows."""
        from kiwi_cli.commands import _val, _fmt_date
        from autobots_client.api.actions import list_actions_v1_actions_get
        from autobots_client.types import UNSET

        opts = self._parse_command_opts(command)
        name = opts.get("name")
        limit = int(opts.get("limit", "20"))
        offset = int(opts.get("offset", "0"))

        resp = list_actions_v1_actions_get.sync_detailed(
            client=api_client, name=name if name else UNSET, limit=limit, offset=offset,
        )
        if resp.status_code != 200:
            self._show_command_result(command, f"Error: HTTP {resp.status_code}", is_error=True)
            return

        result = resp.parsed
        result = resp.parsed
        title = (
            f"Actions ({result.total_count} total, showing {result.offset}-{result.offset + len(result.docs)}). "
            "Select an action"
        )
        options: list[tuple[str, str]] = []
        for idx, doc in enumerate(result.docs, 1):
            label = (
                f"{idx:<4} {_val(doc.name):<30} {_val(doc.type_.value):<25} "
                f"{_val(doc.version):<6} {_fmt_date(doc.created_at)}"
            )
            options.append((doc.field_id, label))
        self.app.push_screen(IdPickerScreen(title, options), callback=self._on_action_picked)

    def _render_runs_list(self, command: str, api_client) -> None:
        """Render /runs list with clickable rows."""
        from kiwi_cli.commands import _val, _fmt_date
        from autobots_client.api.action_results import list_action_result_v1_action_results_get
        from autobots_client.types import UNSET
        from autobots_client.models.event_result_status import EventResultStatus

        opts = self._parse_command_opts(command)
        status_enum = UNSET
        if opts.get("status"):
            try:
                status_enum = EventResultStatus(opts["status"].lower())
            except ValueError:
                self._show_command_result(
                    command,
                    f"Invalid status: {opts['status']}. Valid: processing, success, error, stuck, waiting",
                    is_error=True,
                )
                return

        resp = list_action_result_v1_action_results_get.sync_detailed(
            client=api_client,
            action_id=opts.get("action_id") or UNSET,
            action_name=opts.get("action_name") or UNSET,
            status=status_enum,
            limit=int(opts.get("limit", "20")),
            offset=int(opts.get("offset", "0")),
        )
        if resp.status_code != 200:
            self._show_command_result(command, f"Error: HTTP {resp.status_code}", is_error=True)
            return

        result = resp.parsed
        title = (
            f"Action Runs ({result.total_count} total, showing {result.offset}-{result.offset + len(result.docs)}). "
            "Select a run"
        )
        options: list[tuple[str, str]] = []
        for idx, doc in enumerate(result.docs, 1):
            label = (
                f"{idx:<4} {doc.status.value:<12} {_val(doc.name):<30} "
                f"{_fmt_date(doc.created_at):<18} {_fmt_date(doc.updated_at)}"
            )
            options.append((doc.field_id, label))
        self.app.push_screen(IdPickerScreen(title, options), callback=self._on_run_picked)

    def _render_graphs_list(self, command: str, api_client) -> None:
        """Render /graphs list with clickable rows."""
        from kiwi_cli.commands import _val, _fmt_date
        from autobots_client.api.action_graphs import list_action_graphs_v1_action_graphs_get
        from autobots_client.types import UNSET

        opts = self._parse_command_opts(command)
        name = opts.get("name")
        limit = int(opts.get("limit", "20"))
        offset = int(opts.get("offset", "0"))

        resp = list_action_graphs_v1_action_graphs_get.sync_detailed(
            client=api_client, name=name if name else UNSET, limit=limit, offset=offset,
        )
        if resp.status_code != 200 or not resp.parsed:
            self._show_command_result(command, f"Error: HTTP {resp.status_code}", is_error=True)
            return

        result = resp.parsed
        title = (
            f"Action Graphs ({result.total_count} total, showing {result.offset}-{result.offset + len(result.docs)}). "
            "Select a graph"
        )
        options: list[tuple[str, str]] = []
        for idx, doc in enumerate(result.docs, 1):
            label = (
                f"{idx:<4} {_val(doc.name):<30} {_val(doc.version):<6} "
                f"{_val(doc.is_published):<10} {_fmt_date(doc.created_at)}"
            )
            options.append((doc.field_id, label))
        self.app.push_screen(IdPickerScreen(title, options), callback=self._on_graph_picked)
    def _render_graph_runs_list(self, command: str, api_client) -> None:
        """Render /graph-runs list with clickable rows."""
        from kiwi_cli.commands import _val, _fmt_date
        from autobots_client.api.action_graphs_results import list_action_graph_result_v1_action_graphs_results_get
        from autobots_client.types import UNSET
        from autobots_client.models.event_result_status import EventResultStatus

        opts = self._parse_command_opts(command)
        status_enum = UNSET
        if opts.get("status"):
            try:
                status_enum = EventResultStatus(opts["status"].lower())
            except ValueError:
                self._show_command_result(
                    command,
                    f"Invalid status: {opts['status']}. Valid: processing, success, error, stuck, waiting",
                    is_error=True,
                )
                return

        resp = list_action_graph_result_v1_action_graphs_results_get.sync_detailed(
            client=api_client,
            action_graph_id=opts.get("graph_id") or UNSET,
            action_graph_name=opts.get("graph_name") or UNSET,
            status=status_enum,
            limit=int(opts.get("limit", "20")),
            offset=int(opts.get("offset", "0")),
        )
        if resp.status_code != 200:
            self._show_command_result(command, f"Error: HTTP {resp.status_code}", is_error=True)
            return

        result = resp.parsed
        title = (
            f"Action Graph Runs ({result.total_count} total, showing {result.offset}-{result.offset + len(result.docs)}). "
            "Select a graph run"
        )
        options: list[tuple[str, str]] = []
        for idx, doc in enumerate(result.docs, 1):
            label = (
                f"{idx:<4} {doc.status.value:<12} {_val(doc.name):<30} "
                f"{_fmt_date(doc.created_at):<18} {_fmt_date(doc.updated_at)}"
            )
            options.append((doc.field_id, label))
        self.app.push_screen(IdPickerScreen(title, options), callback=self._on_graph_run_picked)


    # ----------------------------
    # Modal picker callbacks
    # ----------------------------

    def _on_action_picked(self, action_id: str) -> None:
        """Callback for the /actions list picker (non-blocking)."""
        if not action_id:
            self.query_one("#chat-input", ChatInput).focus()
            return
        if self._cmd_running:
            return
        self._set_command_running(True, "Switching action ...")
        self.run_worker(
            self._on_action_picked_async(action_id),
            group="cmd",
            exclusive=True,
            exit_on_error=False,
        )

    async def _on_action_picked_async(self, action_id: str) -> None:
        try:
            api_client = self._get_api_client_for_command("/actions list")
            if not api_client:
                return
            from kiwi_cli.commands import actions_get
            lines = await asyncio.to_thread(lambda: actions_get(api_client, id=action_id))
            if lines and lines[0].startswith("Error"):
                self._show_command_result("Action selection", f"Action not found: {action_id}", is_error=True)
                return
            self.current_action_id = action_id
            self.current_run_id = None
            self._update_run_status_bar()
            self._clear_chat_messages()
            self.app.notify(f"Switched to action: {action_id}", severity="information")
        finally:
            self._set_command_running(False)
            self.query_one("#chat-input", ChatInput).focus()

    def _on_run_picked(self, run_id: str) -> None:
        """Callback for the /runs list picker (non-blocking)."""
        if not run_id:
            self.query_one("#chat-input", ChatInput).focus()
            return
        if self._cmd_running:
            return
        self._set_command_running(True, "Loading run ...")
        self.run_worker(
            self._on_run_picked_async(run_id),
            group="cmd",
            exclusive=True,
            exit_on_error=False,
        )

    async def _on_run_picked_async(self, run_id: str) -> None:
        try:
            api_client = self._get_api_client_for_command("/runs list")
            if not api_client:
                return
            from kiwi_cli.commands import runs_get
            lines = await asyncio.to_thread(lambda: runs_get(api_client, id=run_id))
            if lines and lines[0].startswith("Error"):
                self._show_command_result("Run selection", f"Run not found: {run_id}", is_error=True)
                return
            self.current_run_id = run_id
            self._update_run_status_bar()
            self.app.notify(f"Continuing run: {run_id}", severity="information")
            await self._load_conversation_history_async(run_id)
        finally:
            self._set_command_running(False)
            self.query_one("#chat-input", ChatInput).focus()

    def _on_graph_picked(self, graph_id: str) -> None:
        """Callback for the /graphs list picker (non-blocking)."""
        if not graph_id:
            self.query_one("#chat-input", ChatInput).focus()
            return
        if self._cmd_running:
            return
        self._set_command_running(True, "Loading graph ...")
        self.run_worker(
            self._on_graph_picked_async(graph_id),
            group="cmd",
            exclusive=True,
            exit_on_error=False,
        )

    async def _on_graph_picked_async(self, graph_id: str) -> None:
        try:
            api_client = self._get_api_client_for_command("/graphs list")
            if not api_client:
                return
            from kiwi_cli.commands import graphs_get
            lines = await asyncio.to_thread(lambda: graphs_get(api_client, id=graph_id))
            if lines and lines[0].startswith("Error"):
                self._show_command_result("Graph selection", f"Graph not found: {graph_id}", is_error=True)
                return
            self._show_command_result(f"Graph: {graph_id}", "\n".join(lines))
        finally:
            self._set_command_running(False)
            self.query_one("#chat-input", ChatInput).focus()

    def _on_graph_run_picked(self, graph_run_id: str) -> None:
        """Callback for the /graph-runs list picker (non-blocking)."""
        if not graph_run_id:
            self.query_one("#chat-input", ChatInput).focus()
            return
        if self._cmd_running:
            return
        self._set_command_running(True, "Loading graph run ...")
        self.run_worker(
            self._on_graph_run_picked_async(graph_run_id),
            group="cmd",
            exclusive=True,
            exit_on_error=False,
        )

    async def _on_graph_run_picked_async(self, graph_run_id: str) -> None:
        try:
            api_client = self._get_api_client_for_command("/graph-runs list")
            if not api_client:
                return
            from kiwi_cli.commands import graph_runs_get
            lines = await asyncio.to_thread(lambda: graph_runs_get(api_client, id=graph_run_id))
            if lines and lines[0].startswith("Error"):
                self._show_command_result("Graph run selection", f"Graph run not found: {graph_run_id}", is_error=True)
                return
            self.current_run_id = graph_run_id
            self._update_run_status_bar()
            self.app.notify(f"Continuing graph run: {graph_run_id}", severity="information")
        finally:
            self._set_command_running(False)
            self.query_one("#chat-input", ChatInput).focus()


    def action_copy_run_id(self) -> None:
        """Copy the current run_id to the system clipboard."""
        def _notify_once(msg: str, *, severity: str) -> None:
            now = time.monotonic()
            # Show at most one toast every 2.5s to avoid stacking over the Copy button.
            if now - self._last_copy_notify_at < 2.5:
                return
            self._last_copy_notify_at = now
            self.app.notify(msg, severity=severity)

        if not self.current_run_id:
            _notify_once("No run id to copy", severity="warning")
            return
        text = self.current_run_id
        copied = False

        # Prefer native OS clipboard tools (more reliable in terminal apps).
        try:
            if sys.platform == "darwin":
                subprocess.run(["pbcopy"], input=text.encode("utf-8"), check=True)
                copied = True
            elif sys.platform.startswith("linux"):
                subprocess.run(["xclip", "-selection", "clipboard"], input=text.encode("utf-8"), check=True)
                copied = True
            elif sys.platform.startswith("win"):
                subprocess.run(["clip"], input=text.encode("utf-8"), check=True)
                copied = True
        except Exception:
            copied = False

        # Fallback to Textual's clipboard integration.
        if not copied:
            try:
                self.app.copy_to_clipboard(text)
                copied = True
            except Exception:
                copied = False

        if copied:
            _notify_once("Copied run id to clipboard", severity="information")
        else:
            _notify_once("Failed to copy run id to clipboard", severity="error")


    def action_hint_upload(self) -> None:
        """Click handler for the '@ files' hint span."""
        self.app.push_screen(AttachContentScreen(), callback=self._on_attach_result)

    def action_hint_slash(self) -> None:
        """Click handler for the '/ commands' hint span."""
        self.app.push_screen(SlashPickerScreen(), callback=self._on_slash_selected)

    def action_hint_send(self) -> None:
        """Click handler for the '↵ send' hint span."""
        self._do_send()
    def action_hint_newline(self) -> None:
        """Keyboard shortcut: insert a newline into the chat input."""
        chat_input = self.query_one("#chat-input", ChatInput)
        chat_input.focus()
        chat_input.insert("\n")


    def _do_send(self) -> None:
        """Send the current chat input.

        While a run is in progress, the input is disabled and this becomes a no-op.
        """
        if self._is_streaming or self._cmd_running:
            return
        chat_input = self.query_one("#chat-input", ChatInput)
        message = chat_input.value.strip()
        # Allow sending empty prompts (useful for "continue"-style turns).
        # We still clear the input, but we don't record empty messages in history.
        if message:
            chat_input.record(message)
        chat_input.value = ""
        if message.startswith("/"):
            self.handle_slash_command(message)
        else:
            # Render a single space so the UI still shows a user row for empty prompts.
            self.add_message(message if message else " ", "user")
            self.process_message(message)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button presses."""
        raw_id = event.button.id or ""
        # Clickable list buttons get a unique suffix to avoid DuplicateIds; strip it here.
        btn_id = raw_id.split("__", 1)[0]

        if btn_id == "copy-run-id":
            self.action_copy_run_id()
            return


        if btn_id == "upload-btn":
            self.action_hint_upload()
            return

        if btn_id == "slash-btn":
            self.action_hint_slash()
            return

        if btn_id == "send-btn":
            self._do_send()
            return

        api_client = self._get_api_client()
        if not api_client:
            return

        if btn_id.startswith("action-select-"):
            # Switch to this action
            action_id = btn_id[len("action-select-"):]
            from kiwi_cli.commands import actions_get
            lines = actions_get(api_client, id=action_id)
            if lines and lines[0].startswith("Error"):
                self.add_message(f"Action not found: {action_id}", "error")
                return
            self.current_action_id = action_id
            self.current_run_id = None
            self._update_run_status_bar()
            self.add_message("\n".join(["Switched to action:"] + lines), "info")

        elif btn_id.startswith("graph-select-"):
            # Show graph details
            graph_id = btn_id[len("graph-select-"):]
            from kiwi_cli.commands import graphs_get
            lines = graphs_get(api_client, id=graph_id)
            if lines and lines[0].startswith("Error"):
                self.add_message(f"Graph not found: {graph_id}", "error")
                return
            self.add_message("\n".join(lines), "assistant")

        elif btn_id.startswith("run-select-"):
            # Continue this run
            run_id = btn_id[len("run-select-"):]
            from kiwi_cli.commands import runs_get
            lines = runs_get(api_client, id=run_id)
            if lines and lines[0].startswith("Error"):
                self.add_message(f"Run not found: {run_id}", "error")
                return
            self.current_run_id = run_id
            self._update_run_status_bar()
            self.add_message("\n".join(["Continuing run:"] + lines), "info")
            self._load_conversation_history(run_id)

        elif btn_id.startswith("graph-run-select-"):
            # Continue this graph run
            graph_run_id = btn_id[len("graph-run-select-"):]
            from kiwi_cli.commands import graph_runs_get
            lines = graph_runs_get(api_client, id=graph_run_id)
            if lines and lines[0].startswith("Error"):
                self.add_message(f"Graph run not found: {graph_run_id}", "error")
                return
            self.current_run_id = graph_run_id
            self.add_message("\n".join(["Continuing graph run:"] + lines), "info")

        else:
            return

        self.query_one("#chat-input", ChatInput).focus()

    @staticmethod
    def _prepare_markdown(text: str) -> str:
        """Convert image markdown to links since terminals can't render images."""
        return re.sub(r'!\[([^\]]*)\]\(([^)]+)\)', r'[\1](\2)', text)


    def _clear_chat_messages(self) -> None:
        """Clear the visible chat timeline.

        This is a UI reset only. It does not affect server-side conversation
        state. We use this when switching actions so the user sees a blank chat,
        and the next message starts a new run/conversation.
        """
        try:
            messages = self.query_one("#messages", VerticalScroll)
        except Exception:
            return
        for child in list(messages.children):
            try:
                child.remove()
            except Exception:
                pass
        messages.scroll_end(animate=False)

    def add_message(self, text: str, msg_type: str = "assistant") -> None:
        """Add a message to the chat."""
        messages = self.query_one("#messages", VerticalScroll)
        css_class = f"message {msg_type}-message"
        if msg_type == "assistant":
            prepared = self._prepare_markdown(text)
            messages.mount(AssistantMessageRow(prepared, classes=css_class))
        elif msg_type == "user":
            # Render a styled "YOU" label without enabling markup (keeps input safe).
            messages.mount(UserMessageRow(str(text), classes=css_class))
        else:
            # Use markup=False so arbitrary text (JSON, headers, brackets) can't crash Rich's markup parser.
            widget = Static(str(text), classes=css_class, markup=False)
            messages.mount(widget)
        messages.scroll_end(animate=False)

    def _apply_blocking_state(self) -> None:
        """Apply UI disabled/enabled state based on current busy flags."""
        disabled = self._is_streaming or self._cmd_running
        send_btn = self.query_one("#send-btn", Button)
        send_btn.label = "Send"
        send_btn.disabled = disabled
        # Block user input while busy.
        try:
            chat_input = self.query_one("#chat-input", ChatInput)
            chat_input.disabled = disabled
            if self._is_streaming:
                chat_input.placeholder = "Waiting for response..."
            elif self._cmd_running:
                chat_input.placeholder = "Running command..."
            else:
                chat_input.placeholder = "Message... (@ for files, / for commands)"
            if not disabled:
                chat_input.focus()
        except Exception:
            pass
        # Disable auxiliary buttons while busy.
        for btn_id in ("#upload-btn", "#slash-btn", "#copy-run-id"):
            try:
                self.query_one(btn_id, Button).disabled = disabled or (btn_id == "#copy-run-id" and not bool(self.current_run_id))
            except Exception:
                pass
        self._update_run_status_bar()

    def _set_command_running(self, running: bool, label: str = "") -> None:
        """Show/hide a small loading indicator for /commands and block input."""
        self._cmd_running = running
        try:
            bar = self.query_one("#activity-bar", Horizontal)
            text_w = self.query_one("#activity-text", Static)
            if running:
                text_w.update(label)
                bar.add_class("visible")
            else:
                text_w.update("")
                bar.remove_class("visible")
        except Exception:
            pass
        self._apply_blocking_state()

    def _set_streaming(self, streaming: bool) -> None:
        """Set busy/streaming mode (chat send)."""
        self._is_streaming = streaming
        self._apply_blocking_state()



    def _on_attach_result(self, result: dict) -> None:
        """Callback from AttachContentScreen."""
        if not result:
            self.query_one("#chat-input", ChatInput).focus()
            return
        if result.get("type") == "files":
            self.app.push_screen(FileBrowserScreen(), callback=self._on_files_selected)
        elif result.get("type") == "url":
            url = result["url"]
            self._pending_urls.append(url)
            name = Path(url.rsplit("/", 1)[-1]).name if "/" in url else url
            self.add_message(f"Attached: {name}", "info")
            self._update_pending_files_bar()
            self.query_one("#chat-input", ChatInput).focus()

    def _on_slash_selected(self, command: str) -> None:
        """Callback from SlashPickerScreen."""
        if not command:
            self.query_one("#chat-input", ChatInput).focus()
            return
        # Commands ending with space need args — insert into input
        if command.endswith(" "):
            chat_input = self.query_one("#chat-input", ChatInput)
            chat_input.value = command
            chat_input.cursor_position = len(command)
            chat_input.focus()
        else:
            # No args needed — execute immediately
            self.handle_slash_command(command)
            self.query_one("#chat-input", ChatInput).focus()

    def _on_files_selected(self, file_paths: list[str]) -> None:
        """Callback from FileBrowserScreen — upload selected files."""
        if not file_paths:
            self.query_one("#chat-input", ChatInput).focus()
            return
        if not hasattr(self.app, 'autobots_client'):
            self.add_message("Error: Client not initialized", "error")
            return
        names = [Path(p).name for p in file_paths]
        self.add_message(f"> Uploading: {', '.join(names)}", "user")
        success, urls, message = self.app.autobots_client.upload_files(file_paths)
        if success:
            self._pending_urls.extend(urls)
            uploaded_names = [Path(u.rsplit("/", 1)[-1]).name for u in urls]
            self.add_message(f"Uploaded: {', '.join(uploaded_names)}. Attached to your next message.", "info")
            self._update_pending_files_bar()
        else:
            self.add_message(f"Upload failed: {message}", "error")
        self.query_one("#chat-input", ChatInput).focus()

    def _update_pending_files_bar(self) -> None:
        """Update the pending-files bar to show queued file URLs or hide when empty."""
        bar = self.query_one("#pending-files-bar", Static)
        if self._pending_urls:
            names = [Path(url.rsplit("/", 1)[-1]).name for url in self._pending_urls]
            bar.update(f"Attached: {', '.join(names)}")
        else:
            bar.update("")

    def process_message(self, message: str) -> None:
        """Process user message by running action."""
        if not hasattr(self.app, 'autobots_client'):
            self.add_message("Error: Client not initialized", "error")
            return

        # Run action async and poll for result
        self.run_action_with_polling(message)

    def run_action_with_polling(self, user_input: str) -> None:
        """Run action and stream results via SSE."""
        # Mark as busy immediately (prevents double-submit before the HTTP request returns)
        self._set_streaming(True)
        # Kick off as a worker so the UI renders the user message first
        self.run_worker(self._run_action_worker(user_input), exclusive=True, group="stream")

    async def _run_action_worker(self, user_input: str) -> None:
        """Async worker: send the action request then stream results."""
        client = self.app.autobots_client

        # Attach any pending file URLs and clear them
        urls = self._pending_urls.copy()
        self._pending_urls.clear()
        self._update_pending_files_bar()

        # Run the blocking HTTP call in a thread so the UI stays responsive
        loop = asyncio.get_event_loop()
        try:
            success, run_id, message = await loop.run_in_executor(
                None,
                lambda: client.run_action_async(
                    self.current_action_id,
                    user_input,
                    action_result_id=self.current_run_id,
                    urls=urls if urls else None,
                    metadata=self._metadata if self._metadata else None,
                ),
            )
        except asyncio.CancelledError:
            # If the user hit Stop before the request returned, restore UI state.
            self._set_streaming(False)
            raise

        if not success:
            self.add_message(f"Error starting action: {message}", "error")
            self._set_streaming(False)
            return
        # Check if this is continuing an existing conversation
        if self.current_run_id and run_id == self.current_run_id:
            logger.info(f"Continuing conversation with run_id: {run_id}")
        else:
            self.current_run_id = run_id
            # If a pending runtime was started (e.g. via /connect-cli before the
            # run existed), bind it now that we have a run_id.
            try:
                self.app.bind_pending_runtime_to_run(run_id)
            except Exception:
                pass
            logger.info(f"Started new conversation with run_id: {run_id}")


        self._update_run_status_bar()

        # Cache run name (best-effort) so the quit-time runtime cleanup prompt can show it.
        try:
            self.run_worker(self._cache_run_name_worker(run_id), group="run-meta")
        except Exception:
            pass

        # Continue with streaming in the same worker
        await self.stream_results(run_id)

    async def _cache_run_name_worker(self, run_id: str) -> None:
        """Best-effort: cache the run's name in ~/.kiwi/runtimes so the quit prompt can show it."""
        try:
            wrapper = self.app.autobots_client
        except Exception:
            return

        from autobots_client import AuthenticatedClient
        from autobots_client.api.action_results import (
            get_action_result_v1_action_results_id_get,
        )

        api_client = getattr(wrapper, "client", None)
        if not isinstance(api_client, AuthenticatedClient):
            return

        try:
            resp = await asyncio.to_thread(
                lambda: get_action_result_v1_action_results_id_get.sync_detailed(
                    id=run_id,
                    client=api_client,
                )
            )
        except Exception:
            return
        if resp.status_code != 200 or not resp.parsed:
            return
        name = getattr(resp.parsed, "name", None)
        if not name or not str(name).strip():
            return
        name_str = str(name).strip()
        try:
            from kiwi_tui.runtime_agent import meta_path_for_run
            mp = meta_path_for_run(run_id)
            meta: dict[str, object] = {}
            if mp.exists():
                meta = json.loads(mp.read_text(encoding="utf-8") or "{}")
            meta["run_name"] = name_str
            mp.write_text(json.dumps(meta, indent=2, default=str), encoding="utf-8")
        except Exception:
            return


    async def stream_results(self, run_id: str) -> None:
        """Stream action status and display final result from results array.

        Runs SSE streaming and result-polling concurrently.  Whichever
        detects a terminal state first (success *or* error) wins.
        """
        client = self.app.autobots_client
        got_final_result = False

        # Track status widget for streaming transitional messages
        status_widget_container = [None]

        logger.info(f"Starting stream_results for {run_id}")

        def _remove_status_widget() -> None:
            """Remove the streaming status widget if it exists."""
            if status_widget_container[0]:
                try:
                    status_widget_container[0].remove()
                    status_widget_container[0] = None
                except Exception as e:
                    logger.warning(f"Failed to remove status widget: {e}")

        def _try_fetch_final_result() -> bool:
            """Attempt to fetch and display the final result. Returns True on success/error."""
            nonlocal got_final_result
            if got_final_result:
                return True
            success, final_result, message = client.get_action_result(run_id)
            if not success or not final_result:
                return False

            status = final_result.get("status", "").lower()
            logger.info(f"Polled run status: {status}")

            # Handle error/failed states
            if status in ("error", "failed"):
                logger.info(f"Run failed with status: {status}")
                _remove_status_widget()
                error_msg = final_result.get("message", "") or final_result.get("error", "") or "Action failed"
                self.add_message(f"Error: {error_msg}", "error")
                got_final_result = True
                return True

            # Only treat as complete if status indicates completion
            if status not in ("completed", "success", "finished"):
                return False

            action_doc = final_result.get("result", {})
            results_list = action_doc.get("results", []) if isinstance(action_doc, dict) else []
            # Verify the last result actually has output
            if results_list:
                last = results_list[-1]
                if isinstance(last, dict) and last.get("output"):
                    logger.info("Final result fetched successfully")
                    _remove_status_widget()
                    self.display_final_result(final_result)
                    got_final_result = True
                    return True
            return False

        def handle_status_message(data: dict) -> None:
            """Handle SSE messages — status updates and completion signals."""
            if not isinstance(data, dict) or got_final_result:
                return

            # Plain-text status messages (type="status" set by client.py)
            if data.get("type") == "status":
                text = data.get("text", "")
                text_lower = text.lower()
                logger.debug(f"SSE status: {text}")

                # Show all non-empty status messages as progress
                if text.strip():
                    status_widget_container[0] = self.update_streaming_message(
                        {"blocks": [{"text": text}]},
                        status_widget_container[0],
                    )

                # Detect completion from text signals (server sends these as plain text)
                if any(kw in text_lower for kw in ["finishing", "completed", "finished"]):
                    logger.info(f"Completion signal from SSE text: {text}")
                    _try_fetch_final_result()
                return

            # JSON status messages
            status = data.get("status", "").lower()
            if status:
                logger.info(f"SSE JSON status: {status}")
            if status in ["completed", "success", "finished", "error", "failed"]:
                _try_fetch_final_result()

        # ---- Concurrent polling task ----
        async def _poll_until_done() -> None:
            """Poll the run result every few seconds until it reaches a terminal state."""
            while not got_final_result:
                await asyncio.sleep(5)
                if got_final_result:
                    return
                try:
                    if _try_fetch_final_result():
                        return
                except Exception as e:
                    logger.warning(f"Poll error: {e}")

        poll_task = asyncio.create_task(_poll_until_done())

        # Run SSE streaming and polling concurrently. We intentionally do NOT
        # impose a hard timeout on the SSE stream; long-running actions may
        # legitimately take more than a few minutes. If the stream ends early
        # (e.g. network drop), we continue polling until we can fetch a terminal
        # result. Users can always use /cancel to stop waiting.
        status_task: asyncio.Task | None = asyncio.create_task(
            client.stream_action_result(run_id, handle_status_message)
        )

        try:
            while not got_final_result:
                tasks: list[asyncio.Task] = [poll_task]
                if status_task is not None:
                    tasks.append(status_task)

                done, _pending = await asyncio.wait(
                    tasks,
                    return_when=asyncio.FIRST_COMPLETED,
                )

                # Polling finished => we have (or attempted) a final result.
                if poll_task in done:
                    break

                # Streaming ended first (normal end or error). Keep polling.
                if status_task is not None and status_task in done:
                    try:
                        status_task.result()
                    except asyncio.CancelledError:
                        pass
                    except Exception as e:
                        logger.warning(f"SSE stream ended for {run_id}: {e}")
                    status_task = None

            # Ensure polling completes (it exits when got_final_result becomes True).
            if not poll_task.done():
                await poll_task
        except asyncio.CancelledError:
            logger.info(f"Stream cancelled for {run_id}")
            if status_task is not None:
                status_task.cancel()
            poll_task.cancel()
            _remove_status_widget()
            self._set_streaming(False)
            return
        except Exception as e:
            logger.error(f"Stream/poll error for {run_id}: {e}")
            poll_task.cancel()
            _remove_status_widget()
            self.add_message(
                f"Lost connection while waiting for result. The run may still be processing. "
                f"Use /continue {run_id} to reattach.",
                "error",
            )
            self._set_streaming(False)
            return
        finally:
            # If we got the result via polling, stop streaming to avoid leaks.
            if status_task is not None and not status_task.done():
                status_task.cancel()
                try:
                    await status_task
                except (asyncio.CancelledError, Exception):
                    pass

        # Always clean up status widget when SSE stream ends
        _remove_status_widget()

        # Final fallback — if neither SSE nor polling found the result
        if not got_final_result:
            logger.info(f"Final fallback poll for {run_id}")
            _try_fetch_final_result()

        if not got_final_result:
            self.add_message("Could not get result. Use /new to start over.", "error")

        self._set_streaming(False)

    def update_streaming_message(
        self,
        output: any,
        widget_ref: Markdown | AssistantMessageRow | None = None,
    ) -> Markdown | AssistantMessageRow | None:
        """Update or create a streaming message widget with new output.

        Returns the widget being updated/created for future updates.
        """
        text_content = self.extract_text_from_output(output)
        if not text_content:
            return widget_ref

        messages = self.query_one("#messages", VerticalScroll)

        markdown_text = self._prepare_markdown(text_content)
        if widget_ref is None:
            widget_ref = AssistantMessageRow(markdown_text, classes="message assistant-message")
            messages.mount(widget_ref)
        else:
            try:
                if isinstance(widget_ref, AssistantMessageRow):
                    widget_ref.update_markdown(markdown_text)
                else:
                    # Backward-compat: if an older ref is a Markdown widget.
                    widget_ref.update(markdown_text)
            except Exception as e:
                logger.warning(f"Failed to update widget: {e}")
                widget_ref = AssistantMessageRow(markdown_text, classes="message assistant-message")
                messages.mount(widget_ref)

        messages.scroll_end(animate=False)
        return widget_ref
    def extract_text_from_output(self, output: any) -> str:
        """Extract text content from output blocks structure and clean it for display."""
        if not isinstance(output, dict):
            return ""

        text_parts = []

        if "blocks" in output:
            blocks = output["blocks"]
            if isinstance(blocks, list):
                for block in blocks:
                    if isinstance(block, dict):
                        text = block.get("text", "").strip()
                        if text:
                            text_parts.append(self._clean_text_for_display(text))

        elif "text" in output:
            text = output["text"]
            if text:
                text = str(text) if not isinstance(text, str) else text
                text_parts.append(self._clean_text_for_display(text))

        return "\n".join(text_parts)

    def _clean_text_for_display(self, text: str) -> str:
        """Clean text for safe display in Textual (remove HTML, unescape entities, etc.)."""
        if not text:
            return ""

        # Unescape HTML entities (e.g., &amp; -> &, &lt; -> <)
        text = html.unescape(text)

        # Remove HTML tags if present
        text = re.sub(r'<[^>]+>', '', text)

        # Unescape literal \n to actual newlines if present
        if '\\n' in text:
            text = text.replace('\\n', '\n')

        return text.strip()

    def _load_conversation_history(self, run_id: str) -> None:
        """Load and render conversation history for a run (blocking).

        Prefer using `_load_conversation_history_async` when calling from UI events.
        """
        if not hasattr(self.app, "autobots_client"):
            return
        success, result, _msg = self.app.autobots_client.get_action_result(run_id)
        if not success or not result:
            return
        self._render_conversation_history_from_action_result(result)

    def _render_conversation_history_from_action_result(self, result: dict) -> None:
        """Replace the current chat view with the run's full server-side history."""
        if not isinstance(result, dict):
            return
        action_doc = result.get("result", {})
        if not isinstance(action_doc, dict):
            return
        results_list = action_doc.get("results", [])
        if not isinstance(results_list, list) or not results_list:
            return

        messages = self.query_one("#messages", VerticalScroll)
        for child in list(messages.children):
            try:
                child.remove()
            except Exception:
                pass

        for item in results_list:
            if not isinstance(item, dict):
                continue
            input_data = item.get("input")
            if input_data:
                input_text = self.extract_text_from_output(input_data) if isinstance(input_data, dict) else str(input_data)
                if input_text:
                    self.add_message(input_text, "user")
            output_data = item.get("output")
            if output_data:
                output_text = self.extract_text_from_output(output_data) if isinstance(output_data, dict) else str(output_data)
                if output_text:
                    self.add_message(output_text, "assistant")

        messages.scroll_end(animate=False)
        self._update_run_status_bar()
    def display_final_result(self, result: dict) -> None:
        """Display the final result from results array, showing only the latest output.

        Args:
            result: The result dictionary from get_action_result containing result.result.results[]
        """
        logger.info(f"Displaying final result from results array")

        # Extract results array from result.result.results
        if "result" not in result or not isinstance(result["result"], dict):
            logger.warning(f"No result.result field found")
            self.add_message("Action completed (no output)", "info")
            return

        action_doc = result["result"]
        logger.info(f"ActionDoc keys: {action_doc.keys()}")

        if "results" not in action_doc or not isinstance(action_doc["results"], list):
            logger.warning(f"No results array found in ActionDoc")
            self.add_message("Action completed (no output)", "info")
            return

        results_list = action_doc["results"]

        logger.info(f"Found {len(results_list)} items in results array")

        if len(results_list) == 0:
            logger.warning(f"Results array is empty")
            self.add_message("Action completed (no output)", "info")
            return

        # Only display the LAST result item's output.
        # The results array contains full conversation history; the user's input
        # was already shown when they typed it, so we only need the latest response.
        last_result = results_list[-1]
        if not isinstance(last_result, dict):
            logger.warning(f"Last result is not a dict")
            self.add_message("Action completed (no output)", "info")
            return

        logger.info(f"Processing last result, keys: {last_result.keys()}")

        # Extract and display only the output (skip input — already shown)
        if "output" in last_result and last_result["output"]:
            output_data = last_result["output"]
            output_text = self.extract_text_from_output(output_data)
            if output_text:
                logger.info(f"Last result output: {len(output_text)} chars, {len(output_text.splitlines())} lines")
                self.add_message(output_text, "assistant")
            else:
                logger.warning(f"Last result output extraction returned empty")
                self.add_message("Action completed (no output)", "info")
        else:
            logger.warning(f"Last result has no output field")
            self.add_message("Action completed (no output)", "info")

    def format_and_display_output(self, output: any) -> None:
        """Format and display output, extracting text and files from blocks."""
        if isinstance(output, dict):
            # Check for blocks structure
            if "blocks" in output:
                blocks = output["blocks"]
                if isinstance(blocks, list):
                    for block in blocks:
                        if isinstance(block, dict):
                            # Extract text
                            text = block.get("text", "").strip()
                            if text:
                                # Unescape unicode characters
                                text = text.encode().decode('unicode_escape')
                                self.add_message(text, "assistant")

                            # Extract files
                            files = block.get("files", [])
                            if files and isinstance(files, list):
                                for file_info in files:
                                    if isinstance(file_info, dict):
                                        file_name = file_info.get("name", "unnamed file")
                                        self.add_message(f"📎 File: {file_name}", "info")
                                    elif isinstance(file_info, str):
                                        self.add_message(f"📎 File: {file_info}", "info")
                return

            # Check for direct text field
            if "text" in output:
                text = output["text"]
                if text:
                    text = text.encode().decode('unicode_escape') if isinstance(text, str) else str(text)
                    self.add_message(text, "assistant")
                return

        # Fallback: display as-is
        if isinstance(output, dict):
            self.add_message(json.dumps(output, indent=2), "assistant")
        else:
            self.add_message(str(output), "assistant")

    def update_last_assistant_message(self, text: str) -> None:
        """Update the last assistant message with new text."""
        messages = self.query_one("#messages", VerticalScroll)
        assistant_messages = messages.query(".assistant-message")

        prepared = self._prepare_markdown(text)

        if assistant_messages:
            last_msg = assistant_messages[-1]
            if isinstance(last_msg, AssistantMessageRow):
                last_msg.update_markdown(prepared)
            else:
                # Backward-compat if we have an older Markdown widget in the tree.
                try:
                    last_msg.update(prepared)
                except Exception:
                    self.add_message(text, "assistant")
        else:
            self.add_message(text, "assistant")
