from dataclasses import dataclass

@dataclass(frozen=True)
class SlashCommand:
    category: str
    template: str
    description: str
    insert_text: str

    @property
    def needs_args(self) -> bool:
        return self.insert_text.endswith(" ")


# NOTE: Keep this aligned with DashboardScreen's TUI command handler.
SLASH_COMMANDS: list[SlashCommand] = [
    # Session
    SlashCommand("Session", "/help", "Show all slash commands", "/help"),
    SlashCommand("Session", "/new", "Start new conversation", "/new"),
    SlashCommand("Session", "/status", "Show current action & run", "/status"),
    SlashCommand("Session", "/cancel", "Cancel active request", "/cancel"),
    SlashCommand("Session", "/use <action_id>", "Switch to a different action", "/use "),
    SlashCommand("Session", "/continue <run_id>", "Continue an existing run", "/continue "),

    # Files
    SlashCommand("Files", "/upload <path> [path2 ...]", "Upload file(s) and attach to next message", "/upload "),
    SlashCommand("Files", "/files", "Show pending attachments", "/files"),
    SlashCommand("Files", "/clear-files", "Clear pending attachments", "/clear-files"),

    # Auth
    SlashCommand("Auth", "/login", "Log in", "/login"),
    SlashCommand("Auth", "/logout", "Log out", "/logout"),

    # Metadata
    SlashCommand("Metadata", "/metadata", "Show effective metadata", "/metadata"),
    SlashCommand("Metadata", "/metadata set <key> <value>", "Set a metadata field", "/metadata set "),
    SlashCommand("Metadata", "/metadata remove <key>", "Remove a metadata field", "/metadata remove "),
    SlashCommand("Metadata", "/metadata clear", "Clear all metadata overrides", "/metadata clear"),

    # Runtime (local CLI agent)
    SlashCommand("Runtime", "/connect-cli", "Tell the agent to connect to the local CLI", "/connect-cli"),
    SlashCommand("Runtime", "/show-logs", "Show local CLI (runtime) logs", "/show-logs"),
    SlashCommand("Runtime", "/runtime", "Runtime commands (currently disabled)", "/runtime"),

    # Query (API)
    SlashCommand("Query", "/actions list", "List recent actions", "/actions list"),
    SlashCommand("Query", "/actions get <id>", "Get an action by id", "/actions get "),
    SlashCommand("Query", "/runs list", "List recent runs", "/runs list"),
    SlashCommand("Query", "/runs get <id>", "Get a run by id", "/runs get "),
    SlashCommand("Query", "/graphs list", "List recent graphs", "/graphs list"),
    SlashCommand("Query", "/graphs get <id>", "Get a graph by id", "/graphs get "),
    SlashCommand("Query", "/graph-runs list", "List recent graph runs", "/graph-runs list"),
    SlashCommand("Query", "/graph-runs get <id>", "Get a graph run by id", "/graph-runs get "),
]


def autocomplete_commands() -> list[str]:
    """Return strings used for chat input autocomplete."""
    # We keep the insert_text version for consistency with the actual command parser.
    return [c.insert_text for c in SLASH_COMMANDS]
