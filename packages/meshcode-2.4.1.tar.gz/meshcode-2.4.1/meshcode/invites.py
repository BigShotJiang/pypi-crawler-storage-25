"""Invite + join CLI helpers (Phase 7B).

Lets users:
  meshcode invite <project> <agent> [--role "..."] [--days 7]
      → owner generates an invite token + share URL for one specific
        agent slot in their meshwork

  meshcode join <token> [--display-name "alice"]
      → friend redeems the invite, gets a scoped api key tied to one
        meshwork + one agent name, stores it in the OS keychain under
        a per-mesh profile, and creates a workspace ready to launch

  meshcode invites <project>
      → list outstanding + redeemed invites for a meshwork

  meshcode members <project>
      → list members of a meshwork

  meshcode revoke-invite <invite-id>
      → cancel an outstanding invite (or kick the redeemer if already in)

  meshcode revoke-member <project> <member-user-id>
      → kick a member out of a meshwork

All RPCs run via the publishable Supabase key + the user's own api_key
for ownership validation. Scoped guest keys never see the owner's main
key — they get a narrow key that only works on their one agent slot.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, Optional
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


# ============================================================
# Supabase RPC helpers
# ============================================================

_DEFAULT_SUPABASE_URL = "https://gjinagyyjttyxnaoavnz.supabase.co"
_DEFAULT_SUPABASE_KEY = "sb_publishable_qwN9PO1L7jUXhhbhhVk2CQ_z1FXG2Qf"


def _sb() -> Dict[str, str]:
    url = os.environ.get("SUPABASE_URL", "") or _DEFAULT_SUPABASE_URL
    key = os.environ.get("SUPABASE_KEY", "") or _DEFAULT_SUPABASE_KEY
    return {"url": url, "key": key}


def _rpc(name: str, body: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    sb = _sb()
    req = Request(
        f"{sb['url']}/rest/v1/rpc/{name}",
        data=json.dumps(body).encode(),
        method="POST",
        headers={
            "apikey": sb["key"],
            "Authorization": f"Bearer {sb['key']}",
            "Content-Type": "application/json",
        },
    )
    try:
        with urlopen(req, timeout=15) as resp:
            return json.loads(resp.read().decode())
    except HTTPError as e:
        try:
            err_body = e.read().decode()
            return json.loads(err_body)
        except Exception:
            print(f"[meshcode] HTTP {e.code} from {name}: {e.reason}", file=sys.stderr)
            return None
    except URLError as e:
        print(f"[meshcode] network error calling {name}: {e.reason}", file=sys.stderr)
        return None


def _get_default_api_key() -> Optional[str]:
    try:
        import importlib
        secrets_mod = importlib.import_module("meshcode.secrets")
        return secrets_mod.get_api_key(profile="default")
    except Exception:
        return None


# ============================================================
# meshcode invite — owner creates an invite
# ============================================================

def cmd_invite(project: str, agent: str, role: str = "", days: int = 7) -> int:
    api_key = _get_default_api_key()
    if not api_key:
        print("[meshcode] ERROR: not logged in. Run `meshcode login <api_key>` first.", file=sys.stderr)
        return 2

    result = _rpc("mc_create_invite", {
        "p_api_key": api_key,
        "p_meshwork_name": project,
        "p_agent_name": agent,
        "p_role_description": role,
        "p_expires_in_days": int(days),
    })
    if not isinstance(result, dict):
        print("[meshcode] ERROR: invite RPC returned no data", file=sys.stderr)
        return 1
    if result.get("error"):
        print(f"[meshcode] ERROR: {result['error']}", file=sys.stderr)
        return 1

    print()
    print(f"[meshcode] ✓ Invite created for agent '{agent}' in meshwork '{project}'")
    print(f"[meshcode]")
    print(f"[meshcode]   Role:       {result.get('role') or '(unset)'}")
    print(f"[meshcode]   Expires:    {result.get('expires_at')}")
    print(f"[meshcode]")
    print(f"[meshcode]   Share this URL with your teammate:")
    print(f"[meshcode]     {result.get('join_url')}")
    print(f"[meshcode]")
    print(f"[meshcode]   Or share the CLI command:")
    print(f"[meshcode]     {result.get('cli_command')}")
    print(f"[meshcode]")
    print(f"[meshcode]   The token is single-use. After they redeem it, they'll have a")
    print(f"[meshcode]   scoped api key that only works for the '{agent}' agent in this")
    print(f"[meshcode]   meshwork. You can revoke them anytime from the dashboard.")
    print()
    return 0


# ============================================================
# meshcode join — friend redeems an invite
# ============================================================

def cmd_join(token: str, display_name: Optional[str] = None) -> int:
    if not token or not token.startswith("mc_inv_"):
        print(f"[meshcode] ERROR: that doesn't look like an invite token (expected mc_inv_...)", file=sys.stderr)
        return 2

    # 1. Inspect first so the user sees what they're joining BEFORE we mint a key
    inspect = _rpc("mc_inspect_invite", {"p_token": token})
    if not isinstance(inspect, dict):
        print("[meshcode] ERROR: could not reach meshcode.io", file=sys.stderr)
        return 1
    if inspect.get("error"):
        print(f"[meshcode] ERROR: {inspect['error']}", file=sys.stderr)
        return 1

    print()
    print(f"[meshcode] You're about to join:")
    print(f"[meshcode]   Meshwork: {inspect.get('meshwork')}")
    print(f"[meshcode]   Agent:    {inspect.get('agent_name')}")
    print(f"[meshcode]   Role:     {inspect.get('role') or '(unset)'}")
    print(f"[meshcode]   Invited by: {inspect.get('invited_by')}")
    print(f"[meshcode]   Expires:  {inspect.get('expires_at')}")
    print()

    # 2. Redeem (anonymous — creates a guest user under the hood)
    redeem = _rpc("mc_redeem_invite", {
        "p_token": token,
        "p_display_name": display_name or "",
    })
    if not isinstance(redeem, dict):
        print("[meshcode] ERROR: could not redeem invite", file=sys.stderr)
        return 1
    # Handle both application errors ({"error": "..."}) and Postgres errors
    # ({"code": "42703", "message": "...", "details": ..., "hint": ...})
    if redeem.get("error"):
        print(f"[meshcode] ERROR: {redeem['error']}", file=sys.stderr)
        return 1
    if redeem.get("code") and redeem.get("message"):
        print(f"[meshcode] ERROR: database error {redeem['code']}: {redeem['message']}", file=sys.stderr)
        if redeem.get("hint"):
            print(f"[meshcode]   hint: {redeem['hint']}", file=sys.stderr)
        return 1

    scoped_key = redeem.get("api_key")
    # Backend returns both "project_name" (canonical) and "meshwork" (legacy)
    project = redeem.get("project_name") or redeem.get("meshwork")
    agent = redeem.get("agent_name")
    if not scoped_key or not project or not agent:
        missing = []
        if not scoped_key: missing.append("api_key")
        if not project: missing.append("project_name/meshwork")
        if not agent: missing.append("agent_name")
        print(f"[meshcode] ERROR: redeem succeeded but response missing fields: {', '.join(missing)}", file=sys.stderr)
        print(f"[meshcode]   got keys: {sorted(redeem.keys())}", file=sys.stderr)
        return 1

    # 3. Store scoped key in OS keychain under a per-mesh profile
    profile_name = f"mesh:{project}:{agent}"
    try:
        import importlib
        secrets_mod = importlib.import_module("meshcode.secrets")
    except Exception as e:
        print(f"[meshcode] ERROR: cannot load secrets module: {e}", file=sys.stderr)
        return 1

    if not secrets_mod.set_api_key(scoped_key, profile=profile_name, meta={
        "type": "scoped",
        "meshwork": project,
        "agent": agent,
        "role": redeem.get("role") or "",
        "expires_at": redeem.get("expires_at"),
        "display_name": redeem.get("display_name"),
        "guest_user_id": redeem.get("guest_user_id"),
    }):
        print(f"[meshcode] ERROR: could not store scoped api key in keychain", file=sys.stderr)
        return 1

    # 4. Create the workspace dir with this profile baked in
    try:
        sc = importlib.import_module("meshcode.setup_clients")
        rc = sc.setup_workspace(
            project, agent,
            role=redeem.get("role") or "",
            keychain_profile=profile_name,
        )
        if rc != 0:
            return rc
    except Exception as e:
        print(f"[meshcode] WARNING: workspace creation failed ({e}); manual setup needed", file=sys.stderr)

    print()
    print(f"[meshcode] 🎉 You've joined '{project}' as '{agent}'")
    print(f"[meshcode]")
    print(f"[meshcode]   To launch your agent now:")
    print(f"[meshcode]     meshcode run {agent}")
    print(f"[meshcode]")
    print(f"[meshcode]   Your scoped api key is in the OS keychain under profile:")
    print(f"[meshcode]     {profile_name}")
    print(f"[meshcode]")
    print(f"[meshcode]   This key only works for the '{agent}' agent in '{project}'.")
    print(f"[meshcode]   It cannot create new meshworks, see other agents' messages,")
    print(f"[meshcode]   or affect the inviter's billing.")
    print()
    return 0


# ============================================================
# meshcode invites <project> — list outstanding invites
# ============================================================

def cmd_list_invites(project: str) -> int:
    api_key = _get_default_api_key()
    if not api_key:
        print("[meshcode] ERROR: not logged in", file=sys.stderr)
        return 2

    # Resolve project_id by name first
    pid = _rpc("mc_resolve_project", {
        "p_api_key": api_key, "p_project_name": project,
    })
    if not isinstance(pid, dict) or not pid.get("project_id"):
        print(f"[meshcode] ERROR: meshwork '{project}' not found or not yours", file=sys.stderr)
        return 1

    result = _rpc("mc_list_invites", {
        "p_api_key": api_key,
        "p_meshwork_id": pid["project_id"],
    })
    if not isinstance(result, dict) or result.get("error"):
        print(f"[meshcode] ERROR: {(result or {}).get('error', 'rpc failed')}", file=sys.stderr)
        return 1

    invites = result.get("invites") or []
    if not invites:
        print(f"[meshcode] No invites for '{project}' yet.")
        print(f"[meshcode] Create one with: meshcode invite {project} <agent>")
        return 0

    print()
    print(f"[meshcode] Invites for '{project}':")
    print()
    for inv in invites:
        status = "REDEEMED" if inv.get("redeemed") else ("REVOKED" if inv.get("revoked") else "OPEN")
        print(f"  [{status}] {inv.get('token_prefix')}…  agent={inv.get('agent_name')}  expires={inv.get('expires_at')}")
        if inv.get("role"):
            print(f"           role: {inv['role']}")
    print()
    return 0


# ============================================================
# meshcode members <project> — list members
# ============================================================

def cmd_list_members(project: str) -> int:
    api_key = _get_default_api_key()
    if not api_key:
        print("[meshcode] ERROR: not logged in", file=sys.stderr)
        return 2

    pid = _rpc("mc_resolve_project", {
        "p_api_key": api_key, "p_project_name": project,
    })
    if not isinstance(pid, dict) or not pid.get("project_id"):
        print(f"[meshcode] ERROR: meshwork '{project}' not found or not yours", file=sys.stderr)
        return 1

    result = _rpc("mc_list_members", {
        "p_api_key": api_key,
        "p_meshwork_id": pid["project_id"],
    })
    if not isinstance(result, dict) or result.get("error"):
        print(f"[meshcode] ERROR: {(result or {}).get('error', 'rpc failed')}", file=sys.stderr)
        return 1

    members = result.get("members") or []
    if not members:
        print(f"[meshcode] No members in '{project}' yet (only you).")
        return 0

    print()
    print(f"[meshcode] Members of '{project}':")
    print()
    for m in members:
        guest_tag = " (guest)" if m.get("is_guest") else ""
        agent_tag = f"  [{m.get('agent_name')}]" if m.get("agent_name") else ""
        print(f"  • {m.get('display_name')}{guest_tag} — {m.get('role')}{agent_tag}")
        print(f"      user_id: {m.get('user_id')}")
        print(f"      joined:  {m.get('joined_at')}")
    print()
    return 0


# ============================================================
# meshcode revoke-invite <invite-id>
# ============================================================

def cmd_revoke_invite(invite_id: str) -> int:
    api_key = _get_default_api_key()
    if not api_key:
        print("[meshcode] ERROR: not logged in", file=sys.stderr)
        return 2

    result = _rpc("mc_revoke_invite", {
        "p_api_key": api_key,
        "p_invite_id": invite_id,
    })
    if not isinstance(result, dict) or result.get("error"):
        print(f"[meshcode] ERROR: {(result or {}).get('error', 'rpc failed')}", file=sys.stderr)
        return 1
    print(f"[meshcode] ✓ Invite {invite_id} revoked")
    return 0


# ============================================================
# meshcode revoke-member <project> <member-user-id>
# ============================================================

def cmd_revoke_member(project: str, member_user_id: str) -> int:
    api_key = _get_default_api_key()
    if not api_key:
        print("[meshcode] ERROR: not logged in", file=sys.stderr)
        return 2

    pid = _rpc("mc_resolve_project", {
        "p_api_key": api_key, "p_project_name": project,
    })
    if not isinstance(pid, dict) or not pid.get("project_id"):
        print(f"[meshcode] ERROR: meshwork '{project}' not found or not yours", file=sys.stderr)
        return 1

    result = _rpc("mc_revoke_member", {
        "p_api_key": api_key,
        "p_meshwork_id": pid["project_id"],
        "p_member_user_id": member_user_id,
    })
    if not isinstance(result, dict) or result.get("error"):
        print(f"[meshcode] ERROR: {(result or {}).get('error', 'rpc failed')}", file=sys.stderr)
        return 1
    print(f"[meshcode] ✓ Member {member_user_id} removed from '{project}'")
    return 0
