#!/usr/bin/env python3
"""
Tests for endee v0.1.17 features:
- ef_con field in index metadata / describe()
- update_filters() method on EndeeVectorStore
"""

import unittest
from typing import List

from endee import constants
from langchain_core.documents import Document
from langchain_core.embeddings import Embeddings

from langchain_endee import EndeeVectorStore
from tests.setup_class import EndeeLangChainTestSetup

# ==============================================================================
# Mock Embeddings
# ==============================================================================


class MockDenseEmbeddings(Embeddings):
    """Mock dense embeddings for testing."""

    def __init__(self, dimension: int = 384):
        self.dimension = dimension

    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        embeddings = []
        for text in texts:
            hash_val = hash(text)
            embedding = [(hash_val + i) % 100 / 100.0 for i in range(self.dimension)]
            embeddings.append(embedding)
        return embeddings

    def embed_query(self, text: str) -> List[float]:
        return self.embed_documents([text])[0]


# ==============================================================================
# Test Cases
# ==============================================================================


class TestEfConField(EndeeLangChainTestSetup):
    """Tests for the ef_con field in index metadata."""

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.embeddings = MockDenseEmbeddings(dimension=cls.dimension)

    def test_default_ef_con_in_constructor(self):
        """Test that ef_con defaults to constants.DEFAULT_EF_CON."""
        index_name = f"{self.test_index_name}_efcon_default"
        self.test_indexes.add(index_name)

        vector_store = EndeeVectorStore(
            embedding=self.embeddings,
            api_token=self.endee_api_token,
            index_name=index_name,
            dimension=self.dimension,
            space_type=self.space_type,
            force_recreate=True,
        )

        self.assertEqual(vector_store.ef_con, constants.DEFAULT_EF_CON)

    def test_custom_ef_con_in_constructor(self):
        """Test passing a custom ef_con value."""
        index_name = f"{self.test_index_name}_efcon_custom"
        self.test_indexes.add(index_name)

        custom_ef_con = 256
        vector_store = EndeeVectorStore(
            embedding=self.embeddings,
            api_token=self.endee_api_token,
            index_name=index_name,
            dimension=self.dimension,
            space_type=self.space_type,
            ef_con=custom_ef_con,
            force_recreate=True,
        )

        self.assertEqual(vector_store.ef_con, custom_ef_con)

    def test_ef_con_in_describe(self):
        """Test that describe() includes ef_con in the returned dict."""
        index_name = f"{self.test_index_name}_efcon_describe"
        self.test_indexes.add(index_name)

        custom_ef_con = 200
        vector_store = EndeeVectorStore(
            embedding=self.embeddings,
            api_token=self.endee_api_token,
            index_name=index_name,
            dimension=self.dimension,
            space_type=self.space_type,
            ef_con=custom_ef_con,
            force_recreate=True,
        )

        index_info = vector_store.index.describe()
        self.assertIn("ef_con", index_info)
        self.assertEqual(index_info["ef_con"], custom_ef_con)

    def test_ef_con_in_from_texts(self):
        """Test that from_texts forwards ef_con correctly."""
        index_name = f"{self.test_index_name}_efcon_from_texts"
        self.test_indexes.add(index_name)

        custom_ef_con = 64
        vector_store = EndeeVectorStore.from_texts(
            texts=["hello world"],
            embedding=self.embeddings,
            api_token=self.endee_api_token,
            index_name=index_name,
            dimension=self.dimension,
            space_type=self.space_type,
            ef_con=custom_ef_con,
            force_recreate=True,
        )

        self.assertEqual(vector_store.ef_con, custom_ef_con)
        index_info = vector_store.index.describe()
        self.assertIn("ef_con", index_info)
        self.assertEqual(index_info["ef_con"], custom_ef_con)

    def test_ef_con_in_from_documents(self):
        """Test that from_documents forwards ef_con correctly."""
        index_name = f"{self.test_index_name}_efcon_from_docs"
        self.test_indexes.add(index_name)

        custom_ef_con = 512
        documents = [Document(page_content="test doc", metadata={"key": "val"})]

        vector_store = EndeeVectorStore.from_documents(
            documents=documents,
            embedding=self.embeddings,
            api_token=self.endee_api_token,
            index_name=index_name,
            dimension=self.dimension,
            space_type=self.space_type,
            ef_con=custom_ef_con,
            force_recreate=True,
        )

        self.assertEqual(vector_store.ef_con, custom_ef_con)
        index_info = vector_store.index.describe()
        self.assertEqual(index_info["ef_con"], custom_ef_con)

    def test_ef_construction_field_constant(self):
        """Test that the EF_CONSTRUCTION_FIELD constant is available."""
        self.assertTrue(hasattr(constants, "EF_CONSTRUCTION_FIELD"))
        self.assertEqual(constants.EF_CONSTRUCTION_FIELD, "ef_con")


class TestUpdateFilters(EndeeLangChainTestSetup):
    """Tests for the update_filters() method."""

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.embeddings = MockDenseEmbeddings(dimension=cls.dimension)

        cls.update_filters_index = f"{cls.test_index_name}_update_filters"
        cls.test_indexes.add(cls.update_filters_index)

        cls.vector_store = EndeeVectorStore(
            embedding=cls.embeddings,
            api_token=cls.endee_api_token,
            index_name=cls.update_filters_index,
            dimension=cls.dimension,
            space_type=cls.space_type,
            force_recreate=True,
        )

        cls.doc_ids = cls.vector_store.add_texts(
            texts=[
                "Python is a great language.",
                "JavaScript powers the web.",
                "Rust is memory safe.",
            ],
            metadatas=[
                {"category": "programming", "language": "python"},
                {"category": "programming", "language": "javascript"},
                {"category": "programming", "language": "rust"},
            ],
        )

    def tearDown(self):
        # Do NOT run the parent tearDown here — it deletes all
        # "test_langchain_index*" indices between tests, which would remove
        # the shared cls.update_filters_index before the next test method runs.
        pass

    @classmethod
    def tearDownClass(cls):
        try:
            cls.nd.delete_index(name=cls.update_filters_index)
        except Exception:
            pass
        super().tearDownClass()

    def test_update_filters_basic(self):
        """Test updating filters for a single vector."""
        result = self.vector_store.update_filters(
            [
                {
                    "id": self.doc_ids[0],
                    "filter": {"category": "scripting", "language": "python"},
                },
            ]
        )

        self.assertIn("1", result)
        self.assertIn("filters updated", result)

    def test_update_filters_multiple(self):
        """Test updating filters for multiple vectors at once."""
        result = self.vector_store.update_filters(
            [
                {
                    "id": self.doc_ids[0],
                    "filter": {
                        "category": "programming",
                        "language": "python",
                        "level": "beginner",
                    },
                },
                {
                    "id": self.doc_ids[1],
                    "filter": {
                        "category": "web",
                        "language": "javascript",
                        "level": "intermediate",
                    },
                },
            ]
        )

        self.assertIn("2", result)
        self.assertIn("filters updated", result)

    def test_update_filters_returns_string(self):
        """Test that update_filters returns a string."""
        result = self.vector_store.update_filters(
            [
                {"id": self.doc_ids[2], "filter": {"category": "systems"}},
            ]
        )

        self.assertIsInstance(result, str)

    def test_update_filters_empty_raises_value_error(self):
        """Test that passing an empty list raises ValueError."""
        with self.assertRaises(ValueError):
            self.vector_store.update_filters([])

    def test_update_filters_verifiable_via_search(self):
        """Test that updated filters are reflected in search results."""
        # Update filter on first doc to a unique category
        unique_category = "unique_test_category"
        self.vector_store.update_filters(
            [
                {
                    "id": self.doc_ids[0],
                    "filter": {"category": unique_category, "language": "python"},
                },
            ]
        )

        # Search with the new filter value
        results = self.vector_store.similarity_search(
            "Python language",
            k=3,
            filter=[{"category": {"$eq": unique_category}}],
        )

        # Should find the updated document
        self.assertGreater(len(results), 0)

    def test_update_filters_nonexistent_id(self):
        """Test updating filters with a non-existent ID does not raise."""
        result = self.vector_store.update_filters(
            [
                {"id": "nonexistent-id-xyz", "filter": {"category": "ghost"}},
            ]
        )

        self.assertIsInstance(result, str)
        self.assertIn("filters updated", result)


if __name__ == "__main__":
    unittest.main(verbosity=2)
