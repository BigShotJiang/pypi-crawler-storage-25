from __future__ import annotations

import logging
import uuid
from enum import Enum
from typing import (
    TYPE_CHECKING,
    Any,
    Iterable,
    Sequence,
)

import requests
from endee import Endee as EndeeClient
from endee import Precision, constants
from langchain_core.documents import Document
from langchain_core.embeddings import Embeddings
from langchain_core.vectorstores import VectorStore

if TYPE_CHECKING:
    from langchain_endee.sparse_embeddings import SparseEmbeddings
logger = logging.getLogger(__name__)


class EndeeVectorStoreError(Exception):
    """`EndeeVectorStore` related exceptions."""


class RetrievalMode(str, Enum):
    """Modes for retrieving vectors from Endee."""

    DENSE = "dense"
    HYBRID = "hybrid"


class EndeeVectorStore(VectorStore):
    """Endee vector store integration for LangChain.

    Provides ANN search via HNSW with multiple distance metrics, metadata
    filtering ($eq, $in, $range), configurable precision levels, and
    optional hybrid search (dense + sparse).
    """

    # Maximum token limits for common embedding models
    EMBEDDING_MODEL_LIMITS = {
        "openai": 8191,  # text-embedding-3-small/large, text-embedding-ada-002
        "cohere": 512,  # embed-english-v3.0, embed-multilingual-v3.0
        "huggingface": 512,  # Most sentence-transformers models
        "default": 512,  # Conservative default
    }

    CONTENT_KEY: str = "text"
    METADATA_KEY: str = "metadata"

    def __init__(
        self,
        embedding: Embeddings,
        api_token: str | None = None,
        index_name: str | None = None,
        max_text_length: int | None = None,
        embedding_model_type: str | None = None,
        endee_client: EndeeClient | None = None,
        retrieval_mode: RetrievalMode = RetrievalMode.DENSE,
        dimension: int | None = None,
        space_type: str = "cosine",
        precision: str = Precision.INT16,
        M: int = constants.DEFAULT_M,
        ef_con: int = constants.DEFAULT_EF_CON,
        content_payload_key: str = CONTENT_KEY,
        sparse_embedding: SparseEmbeddings | None = None,
        metadata_payload_key: str = METADATA_KEY,
        force_recreate: bool = False,  # noqa: FBT001, FBT002
        validate_index_config: bool = True,  # noqa: FBT001, FBT002
    ) -> None:
        """Initialize EndeeVectorStore.

        Args:
            embedding: LangChain embedding function.
            api_token: Endee API token (optional for local deployment).
            index_name: Name of the Endee index.
            max_text_length: Max text length in tokens (auto-detected if None).
            embedding_model_type: ``"openai"``, ``"cohere"``, ``"huggingface"``,
                or ``"default"`` (auto-detected if None).
            endee_client: Existing Endee client (overrides ``api_token``).
            retrieval_mode: ``RetrievalMode.DENSE`` or ``RetrievalMode.HYBRID``.
            dimension: Vector dimension (required for new indexes).
            space_type: Distance metric — ``"cosine"``, ``"l2"``, or ``"ip"``.
            precision: Quantisation level (``Precision`` enum).
            M: HNSW bi-directional links per node. Default: 16.
            ef_con: HNSW construction quality. Default: 128.
            sparse_embedding: Sparse embedding model for hybrid search.
            force_recreate: Delete and recreate index if it exists.
            validate_index_config: Validate dimension on connect.
        """
        if embedding is None:
            msg = "Embedding function must be provided"
            raise ValueError(msg)

        self._embeddings = embedding
        self.content_payload_key = content_payload_key
        self.metadata_payload_key = metadata_payload_key
        self.space_type = space_type
        self.precision = precision
        self.dimension = dimension
        self.M = M
        self.ef_con = ef_con
        self.retrieval_mode = retrieval_mode
        self._sparse_embeddings = sparse_embedding

        # Initialize Endee client
        if endee_client is None:
            if api_token is None:
                try:
                    resp = requests.get(
                        "http://127.0.0.1:8080/api/v1/health",
                        timeout=2,
                    )
                    if resp.status_code != 200:
                        raise RuntimeError

                    data = resp.json()
                    if data.get("status") != "ok":
                        raise RuntimeError

                    self._client = EndeeClient(token="")
                except Exception as err:
                    raise ValueError(
                        "api_token must be provided if endee_client is not provided. "
                        "Local Endee server is also not running on http://127.0.0.1:8080"
                    ) from err
            else:
                self._client = EndeeClient(token=api_token)
        else:
            self._client = endee_client

        # Initialize or get index
        if index_name is None:
            msg = "index_name must be provided"
            raise ValueError(msg)

        self.index_name = index_name

        # Check if index exists
        existing_indexes = self._client.list_indexes()
        index_exists = any(
            idx.get("name") == index_name for idx in existing_indexes.get("indexes", [])
        )

        if index_exists and force_recreate:
            logger.info(f"Deleting existing index: {index_name}")
            self._client.delete_index(index_name)
            # Clear the LRU cache so get_index fetches fresh metadata
            if hasattr(self._client.get_index, "cache_clear"):
                self._client.get_index.cache_clear()
            index_exists = False

        if not index_exists:
            # Create new index
            # Validate dimension first
            if dimension is None:
                msg = (
                    f"Index '{index_name}' does not exist and dimension is not "
                    "provided. Please provide dimension to create a new index."
                )
                raise ValueError(msg)

            logger.info(f"Creating new Endee index: {index_name}")
            sparse_model = self._detect_sparse_model(sparse_embedding)

            self._create_index(
                name=index_name,
                dimension=dimension,
                space_type=space_type,
                precision=precision,
                M=M,
                ef_con=ef_con,
                sparse_model=sparse_model,
            )
            # Clear LRU cache so get_index fetches fresh metadata for the new index
            if hasattr(self._client.get_index, "cache_clear"):
                self._client.get_index.cache_clear()

        else:
            logger.info(f"Using existing Endee index: {index_name}")

        self._index = self._client.get_index(name=index_name)

        if validate_index_config:
            self._validate_index_config()

        # Auto-detect embedding model type if not provided
        if embedding_model_type is None:
            embedding_model_type = self._detect_embedding_model_type(embedding)

        self.embedding_model_type = embedding_model_type

        # Set max_text_length based on model type if not explicitly provided
        if max_text_length is None:
            self.max_text_length = self.EMBEDDING_MODEL_LIMITS.get(
                embedding_model_type, self.EMBEDDING_MODEL_LIMITS["default"]
            )
            logger.info(
                f"Auto-detected embedding model type: '{embedding_model_type}'. "
                f"Setting max_text_length to {self.max_text_length} tokens."
            )
        else:
            self.max_text_length = max_text_length
            logger.info(f"Using custom max_text_length: {max_text_length} tokens.")

    @property
    def embeddings(self) -> Embeddings:
        """The dense embedding model."""
        return self._embeddings

    @property
    def client(self) -> EndeeClient:
        """The underlying Endee client."""
        return self._client

    @property
    def sparse_embeddings(self) -> SparseEmbeddings:
        """The sparse embedding model. Raises ``ValueError`` if not set."""
        if self._sparse_embeddings is None:
            msg = (
                "Sparse embeddings are not set. "
                "Pass sparse_embedding= to the constructor."
            )
            raise ValueError(msg)
        return self._sparse_embeddings

    @property
    def index(self) -> Any:
        """The underlying Endee index object."""
        return self._index

    def _create_index(
        self,
        name: str,
        dimension: int,
        space_type: str,
        precision: str,
        M: int,  # noqa: N803
        ef_con: int,
        sparse_model: str | None = None,
    ) -> None:
        """Create a new Endee index.

        Args:
            name: Name of the index.
            dimension: Dimension of vectors.
            space_type: Distance metric (cosine, l2, ip).
            precision: Precision level (binary, int8, int16, float16, float32).
            M: HNSW graph connectivity parameter.
            ef_con: HNSW construction parameter.
            sparse_model: Sparse index mode. Use "default" to enable sparse
                search, or None for dense-only indexes.

        Raises:
            EndeeVectorStoreError: If index creation fails.
        """
        try:
            create_params: dict[str, Any] = {
                "name": name,
                "dimension": dimension,
                "space_type": space_type,
                "M": M,
                "ef_con": ef_con,
                "precision": precision,
            }
            if sparse_model is not None:
                create_params["sparse_model"] = sparse_model

            self._client.create_index(**create_params)
        except Exception as e:
            msg = f"Failed to create Endee index '{name}': {e}"
            raise EndeeVectorStoreError(msg) from e

    def _validate_index_config(self) -> None:
        """Validate that the index config matches the vector store settings.

        Checks dimension, space_type, hybrid/sparse consistency, precision,
        M, and ef_con. Raises for incompatible settings (dimension,
        space_type, hybrid mismatch). Warns for tuning differences.
        """
        try:
            info = self._index.describe()
        except Exception as e:
            logger.warning(f"Could not fetch index config: {e}")
            return

        errors: list[str] = []

        # Dimension — hard error (vectors won't work)
        if self.dimension is not None and info.get("dimension") != self.dimension:
            errors.append(
                f"dimension: index has {info.get('dimension')}, expected {self.dimension}"
            )

        # Space type — hard error (scores will be wrong)
        if info.get("space_type") and info["space_type"] != self.space_type:
            errors.append(
                f"space_type: index has '{info['space_type']}', expected '{self.space_type}'"
            )

        # Hybrid mismatch — hard error (search mode incompatible)
        index_is_hybrid = info.get("is_hybrid", False)
        user_wants_hybrid = self.retrieval_mode == RetrievalMode.HYBRID

        if user_wants_hybrid and not index_is_hybrid:
            errors.append(
                "retrieval_mode is HYBRID but the index is dense-only. "
                "Recreate the index with a sparse_embedding to enable hybrid search"
            )
        if user_wants_hybrid and self._sparse_embeddings is None:
            errors.append(
                "retrieval_mode is HYBRID but no sparse_embedding was provided"
            )

        if errors:
            msg = (
                "Index config mismatch:\n  "
                + "\n  ".join(errors)
                + "\nSet force_recreate=True to recreate the index."
            )
            raise EndeeVectorStoreError(msg)

        # Hybrid info — warn if index is hybrid but user is in dense mode
        if index_is_hybrid and not user_wants_hybrid:
            logger.warning(
                f"Index '{info.get('name')}' supports hybrid search "
                f"(sparse_model='{info.get('sparse_model')}') but "
                "retrieval_mode is DENSE. Pass retrieval_mode=RetrievalMode.HYBRID "
                "and a sparse_embedding to use hybrid search."
            )

        # Precision, M, ef_con — warn only (index still works, just different tuning)
        if info.get("precision") and str(info["precision"]) != str(self.precision):
            logger.warning(
                f"Index precision is '{info['precision']}', expected '{self.precision}'. "
                "The existing index precision will be used."
            )

        if info.get("M") and info["M"] != self.M:
            logger.warning(
                f"Index M is {info['M']}, expected {self.M}. "
                "The existing index M will be used."
            )

        if info.get("ef_con") and info["ef_con"] != self.ef_con:
            logger.warning(
                f"Index ef_con is {info['ef_con']}, expected {self.ef_con}. "
                "The existing index ef_con will be used."
            )

    def _detect_embedding_model_type(self, embedding: Embeddings) -> str:
        """Auto-detect the embedding model type from the embedding instance.

        Args:
            embedding: Embeddings instance.

        Returns:
            Detected model type string ('openai', 'cohere', 'huggingface', 'default').
        """
        class_name = embedding.__class__.__name__.lower()
        module_name = embedding.__class__.__module__.lower()

        # Check class name and module for common patterns
        if "openai" in class_name or "openai" in module_name:
            return "openai"
        elif "cohere" in class_name or "cohere" in module_name:
            return "cohere"
        elif (
            "huggingface" in class_name
            or "huggingface" in module_name
            or "sentence" in class_name
            or "transformers" in module_name
        ):
            return "huggingface"
        else:
            logger.warning(
                f"Could not auto-detect embedding model type from {class_name}. "
                f"Using default limit of {self.EMBEDDING_MODEL_LIMITS['default']} tokens."
            )
            return "default"

    @staticmethod
    def _detect_sparse_model(
        sparse_embedding: SparseEmbeddings | None,
    ) -> str | None:
        """Determine the ``sparse_model`` value for index creation.

        Args:
            sparse_embedding: The sparse embedding instance (or None).

        Returns:
            ``"endee_bm25"`` for ``EndeeModelSparse``,
            ``"default"`` for ``FastEmbedSparse`` (or any other implementation),
            ``None`` when no sparse embedding is provided.
        """
        if sparse_embedding is None:
            return None

        from langchain_endee.sparse_embeddings import EndeeModelSparse

        if isinstance(sparse_embedding, EndeeModelSparse):
            return "endee_bm25"

        return "default"

    def _estimate_tokens(self, text: str) -> int:
        """Estimate the number of tokens in a text.

        Uses a simple heuristic: ~4 characters per token for English text.

        Args:
            text: Input text string.

        Returns:
            Estimated token count.
        """
        # Simple approximation: 1 token ≈ 4 characters
        return len(text) // 4

    def _truncate_text(self, text: str, max_tokens: int | None = None) -> str:
        """Truncate text to fit within token limit.

        Args:
            text: Input text to truncate.
            max_tokens: Maximum number of tokens. If None, uses self.max_text_length.

        Returns:
            Truncated text string.
        """
        if max_tokens is None:
            max_tokens = self.max_text_length

        estimated_tokens = self._estimate_tokens(text)

        if estimated_tokens <= max_tokens:
            return text

        # Truncate to approximate character count
        # Leaving some buffer (90%) to be safe
        max_chars = int(max_tokens * 4 * 0.9)
        truncated = text[:max_chars]

        logger.warning(
            f"Text truncated from ~{estimated_tokens} to ~{max_tokens} tokens "
            f"(model type: {self.embedding_model_type})"
        )

        return truncated

    def _validate_batch_size(self, batch_size: int) -> int:
        """Validate and adjust batch size to Endee's limits.

        Args:
            batch_size: Requested batch size.

        Returns:
            Valid batch size.

        Raises:
            ValueError: If batch_size exceeds maximum allowed.
        """
        if batch_size > constants.MAX_VECTORS_PER_BATCH:
            msg = (
                f"batch_size ({batch_size}) cannot exceed "
                f"{constants.MAX_VECTORS_PER_BATCH} (Endee's maximum batch size)"
            )
            raise ValueError(msg)
        return batch_size

    def _prepare_texts_and_metadata(
        self,
        texts: Iterable[str],
        metadatas: list[dict] | None,
        ids: list[str] | None,
    ) -> tuple[list[str], list[str], list[dict]]:
        """Prepare and validate texts, IDs, and metadata.

        Args:
            texts: Input texts.
            metadatas: Optional metadata list.
            ids: Optional ID list.

        Returns:
            Tuple of (processed_texts, ids, metadatas).

        Raises:
            ValueError: If lengths don't match.
        """
        texts = list(texts)
        ids = list(ids) if ids else [str(uuid.uuid4()) for _ in texts]
        metadatas = metadatas or [{} for _ in texts]

        # Validate lengths match
        if len(texts) != len(ids):
            msg = (
                f"Number of texts ({len(texts)}) must match number of ids ({len(ids)})"
            )
            raise ValueError(msg)

        if len(texts) != len(metadatas):
            msg = (
                f"Number of texts ({len(texts)}) must match "
                f"number of metadatas ({len(metadatas)})"
            )
            raise ValueError(msg)

        # Truncate texts if needed
        processed_texts = [self._truncate_text(text) for text in texts]

        return processed_texts, ids, metadatas

    def _generate_embeddings_in_batches(
        self,
        texts: list[str],
        embedding_chunk_size: int,
    ) -> list[list[float]]:
        """Generate embeddings for texts in batches.

        Args:
            texts: List of texts to embed.
            embedding_chunk_size: Batch size for embedding generation.

        Returns:
            List of embedding vectors.

        Raises:
            Exception: If embedding generation fails.
        """
        embeddings = []

        for i in range(0, len(texts), embedding_chunk_size):
            sub_texts = texts[i : i + embedding_chunk_size]

            try:
                sub_embeddings = self.embeddings.embed_documents(sub_texts)
                embeddings.extend(sub_embeddings)
            except Exception as e:
                logger.error(
                    f"Error generating embeddings for batch {i}-{i + len(sub_texts)}: {e}"
                )
                raise

        return embeddings

    def _build_upsert_entries(
        self,
        ids: list[str],
        embeddings: list[list[float]],
        texts: list[str],
        metadatas: list[dict],
        sparse_indices: list[list[int]] | None = None,
        sparse_values: list[list[float]] | None = None,
    ) -> list[dict[str, Any]]:
        """Build entry dicts for ``index.upsert()``.

        Args:
            ids: Document IDs.
            embeddings: Dense embedding vectors.
            texts: Text content.
            metadatas: Metadata dictionaries.
            sparse_indices: Sparse vector indices per document (hybrid only).
            sparse_values: Sparse vector values per document (hybrid only).
        """
        entries = []
        for i, (entry_id, embedding, text, metadata) in enumerate(
            zip(ids, embeddings, texts, metadatas, strict=False)
        ):
            meta = {
                self.content_payload_key: text,
                self.metadata_payload_key: metadata,
            }
            filter_data = dict(metadata.items())

            entry: dict[str, Any] = {
                "id": entry_id,
                "vector": embedding,
                "meta": meta,
                "filter": filter_data,
            }

            if sparse_indices is not None and sparse_values is not None:
                entry["sparse_indices"] = sparse_indices[i]
                entry["sparse_values"] = sparse_values[i]

            entries.append(entry)

        return entries

    def _upsert_batch(self, entries: list[dict[str, Any]]) -> None:
        """Upsert a batch of entries to Endee index.

        Args:
            entries: List of entry dictionaries to upsert.

        Raises:
            Exception: If upsert operation fails.
        """
        try:
            self._index.upsert(entries)
        except Exception as e:
            logger.error(f"Error upserting batch of {len(entries)} entries: {e}")
            raise

    def _generate_sparse_embeddings_in_batches(
        self,
        texts: list[str],
        embedding_chunk_size: int,
    ) -> tuple[list[list[int]], list[list[float]]]:
        """Generate sparse embeddings for texts in batches.

        Args:
            texts: List of texts to embed.
            embedding_chunk_size: Batch size for embedding generation.

        Returns:
            Tuple of (indices, values) where each is a list per document.

        Raises:
            Exception: If sparse embedding generation fails.
        """
        all_indices: list[list[int]] = []
        all_values: list[list[float]] = []

        for i in range(0, len(texts), embedding_chunk_size):
            sub_texts = texts[i : i + embedding_chunk_size]

            try:
                sparse_vectors = self.sparse_embeddings.embed_documents(sub_texts)
                for sv in sparse_vectors:
                    all_indices.append(sv.indices)
                    all_values.append(sv.values)
            except Exception as e:
                logger.error(
                    f"Error generating sparse embeddings for batch {i}-{i + len(sub_texts)}: {e}"
                )
                raise

        return all_indices, all_values

    def add_texts(
        self,
        texts: Iterable[str],
        metadatas: list[dict] | None = None,
        *,
        ids: list[str] | None = None,
        batch_size: int = constants.MAX_VECTORS_PER_BATCH,
        embedding_chunk_size: int = 100,
        **kwargs: Any,
    ) -> list[str]:
        """Add texts with embeddings to the vector store.

        Handles text truncation, batched embedding generation, and upsert.

        Args:
            texts: Strings to add.
            metadatas: Optional metadata dicts (same length as texts).
            ids: Optional IDs (UUIDs generated if omitted).
            batch_size: Upsert batch size. Max 1000. Default: 1000.
            embedding_chunk_size: Embedding batch size. Default: 100.

        Returns:
            List of document IDs.
        """
        # Validate batch size
        batch_size = self._validate_batch_size(batch_size)

        # Prepare and validate inputs (includes automatic truncation)
        processed_texts, ids, metadatas = self._prepare_texts_and_metadata(
            texts, metadatas, ids
        )

        # Process in batches
        for i in range(0, len(processed_texts), batch_size):
            batch_end = i + batch_size

            # Extract batch
            chunk_texts = processed_texts[i:batch_end]
            chunk_ids = ids[i:batch_end]
            chunk_metadatas = metadatas[i:batch_end]

            logger.info(
                f"Processing batch {i // batch_size + 1}: {len(chunk_texts)} texts"
            )

            # Generate embeddings for this batch
            embeddings = self._generate_embeddings_in_batches(
                chunk_texts, embedding_chunk_size
            )

            sparse_indices = None
            sparse_values = None
            if self.retrieval_mode == RetrievalMode.HYBRID:
                sparse_indices, sparse_values = (
                    self._generate_sparse_embeddings_in_batches(
                        chunk_texts, embedding_chunk_size
                    )
                )

            entries = self._build_upsert_entries(
                chunk_ids,
                embeddings,
                chunk_texts,
                chunk_metadatas,
                sparse_indices=sparse_indices,
                sparse_values=sparse_values,
            )

            # Upsert to Endee
            self._upsert_batch(entries)

        logger.info(f"Successfully added {len(ids)} texts to vector store")
        return ids

    @classmethod
    def from_texts(
        cls,
        texts: list[str],
        embedding: Embeddings,
        metadatas: list[dict] | None = None,
        *,
        ids: list[str] | None = None,
        api_token: str | None = None,
        index_name: str | None = None,
        endee_client: EndeeClient | None = None,
        dimension: int | None = None,
        space_type: str = "cosine",
        precision: str = Precision.INT16,
        M: int = constants.DEFAULT_M,
        ef_con: int = constants.DEFAULT_EF_CON,
        content_payload_key: str = CONTENT_KEY,
        metadata_payload_key: str = METADATA_KEY,
        batch_size: int = constants.MAX_VECTORS_PER_BATCH,
        retrieval_mode: RetrievalMode = RetrievalMode.DENSE,
        sparse_embedding: SparseEmbeddings | None = None,
        embedding_chunk_size: int = 100,
        force_recreate: bool = False,  # noqa: FBT001, FBT002
        validate_index_config: bool = True,  # noqa: FBT001, FBT002
        **kwargs: Any,
    ) -> EndeeVectorStore:
        """Create an EndeeVectorStore from raw texts.

        Creates the index if needed, embeds all texts, and upserts them.
        See ``__init__`` for parameter descriptions.
        """
        if dimension is None and endee_client is None:
            msg = "dimension must be explicitly provided when creating a new index"
            raise ValueError(msg)

        endee = cls(
            embedding=embedding,
            api_token=api_token,
            index_name=index_name,
            endee_client=endee_client,
            dimension=dimension,
            space_type=space_type,
            precision=precision,
            M=M,
            retrieval_mode=retrieval_mode,
            sparse_embedding=sparse_embedding,
            ef_con=ef_con,
            content_payload_key=content_payload_key,
            metadata_payload_key=metadata_payload_key,
            force_recreate=force_recreate,
            validate_index_config=validate_index_config,
        )

        endee.add_texts(
            texts=texts,
            metadatas=metadatas,
            ids=ids,
            batch_size=batch_size,
            embedding_chunk_size=embedding_chunk_size,
            **kwargs,
        )
        return endee

    @classmethod
    def from_documents(
        cls,
        documents: list[Document],
        embedding: Embeddings,
        ids: Sequence[str] | None = None,
        api_token: str | None = None,
        index_name: str | None = None,
        endee_client: EndeeClient | None = None,
        dimension: int | None = None,
        space_type: str = "cosine",
        precision: str = Precision.INT16,
        retrieval_mode: RetrievalMode = RetrievalMode.DENSE,
        sparse_embedding: SparseEmbeddings | None = None,
        M: int = constants.DEFAULT_M,
        ef_con: int = constants.DEFAULT_EF_CON,
        content_payload_key: str = CONTENT_KEY,
        metadata_payload_key: str = METADATA_KEY,
        batch_size: int = constants.MAX_VECTORS_PER_BATCH,
        embedding_chunk_size: int = 100,
        force_recreate: bool = False,  # noqa: FBT001, FBT002
        validate_index_config: bool = True,  # noqa: FBT001, FBT002
        **kwargs: Any,
    ) -> EndeeVectorStore:
        """Create an EndeeVectorStore from LangChain Document objects.

        Extracts ``page_content`` and ``metadata``, then delegates to
        ``from_texts``. See ``__init__`` for parameter descriptions.
        """
        texts = [doc.page_content for doc in documents]
        metadatas = [doc.metadata for doc in documents]
        return cls.from_texts(
            texts=texts,
            embedding=embedding,
            metadatas=metadatas,
            ids=ids,
            api_token=api_token,
            index_name=index_name,
            endee_client=endee_client,
            dimension=dimension,
            space_type=space_type,
            retrieval_mode=retrieval_mode,
            sparse_embedding=sparse_embedding,
            precision=precision,
            M=M,
            ef_con=ef_con,
            content_payload_key=content_payload_key,
            metadata_payload_key=metadata_payload_key,
            batch_size=batch_size,
            embedding_chunk_size=embedding_chunk_size,
            force_recreate=force_recreate,
            validate_index_config=validate_index_config,
            **kwargs,
        )

    @classmethod
    def from_existing_index(
        cls,
        index_name: str,
        embedding: Embeddings,
        api_token: str | None = None,
        endee_client: EndeeClient | None = None,
        retrieval_mode: RetrievalMode = RetrievalMode.DENSE,
        sparse_embedding: SparseEmbeddings | None = None,
        content_payload_key: str = CONTENT_KEY,
        metadata_payload_key: str = METADATA_KEY,
        validate_index_config: bool = True,  # noqa: FBT001, FBT002
    ) -> EndeeVectorStore:
        """Connect to an existing Endee index without adding data.

        Pass ``retrieval_mode=RetrievalMode.HYBRID`` and a
        ``sparse_embedding`` to reconnect in hybrid mode.
        See ``__init__`` for other parameter descriptions.
        """
        return cls(
            embedding=embedding,
            api_token=api_token,
            index_name=index_name,
            endee_client=endee_client,
            retrieval_mode=retrieval_mode,
            sparse_embedding=sparse_embedding,
            content_payload_key=content_payload_key,
            metadata_payload_key=metadata_payload_key,
            validate_index_config=validate_index_config,
        )

    def similarity_search(
        self,
        query: str,
        k: int = 4,
        filter: list[dict[str, Any]] | None = None,  # noqa: A002
        ef: int = constants.DEFAULT_EF_SEARCH,
        prefilter_cardinality_threshold: int | None = None,
        filter_boost_percentage: int | None = None,
        include_vectors: bool = False,  # noqa: FBT001, FBT002
        rrf_rank_constant: int | None = None,
        dense_rrf_weight: float | None = None,
        **kwargs: Any,
    ) -> list[Document]:
        """Return docs most similar to query.

        Args:
            query: Text query.
            k: Number of results. Default: 4.
            filter: Metadata filter list (AND logic). Operators: $eq, $in, $range.
            ef: Search accuracy (higher = better recall). Default: 128.
            prefilter_cardinality_threshold: Brute-force threshold. Range: 1k–1M.
            filter_boost_percentage: Expand candidate pool by N%. Range: 0–100.
            include_vectors: Return raw vectors in results. Default: False.
            rrf_rank_constant: RRF fusion constant (hybrid only). Default: None.
            dense_rrf_weight: Weight for dense scores in RRF (hybrid only). Default: None.
        """
        docs_and_scores = self.similarity_search_with_score(
            query,
            k=k,
            filter=filter,
            ef=ef,
            prefilter_cardinality_threshold=prefilter_cardinality_threshold,
            filter_boost_percentage=filter_boost_percentage,
            include_vectors=include_vectors,
            rrf_rank_constant=rrf_rank_constant,
            dense_rrf_weight=dense_rrf_weight,
            **kwargs,
        )
        return [doc for doc, _ in docs_and_scores]

    def similarity_search_with_score(
        self,
        query: str,
        k: int = 4,
        filter: list[dict[str, Any]] | None = None,  # noqa: A002
        ef: int = constants.DEFAULT_EF_SEARCH,
        prefilter_cardinality_threshold: int | None = None,
        filter_boost_percentage: int | None = None,
        include_vectors: bool = False,  # noqa: FBT001, FBT002
        rrf_rank_constant: int | None = None,
        dense_rrf_weight: float | None = None,
        **kwargs: Any,
    ) -> list[tuple[Document, float]]:
        """Return docs most similar to query, with similarity scores.

        Automatically uses hybrid search when ``retrieval_mode`` is HYBRID.
        See ``similarity_search`` for parameter descriptions.
        """
        embedding = self.embeddings.embed_query(query)

        sparse_indices = None
        sparse_values = None
        if self.retrieval_mode == RetrievalMode.HYBRID:
            sparse_vector = self.sparse_embeddings.embed_query(query)
            sparse_indices = sparse_vector.indices
            sparse_values = sparse_vector.values

        return self.similarity_search_by_vector_with_score(
            embedding,
            k=k,
            filter=filter,
            ef=ef,
            prefilter_cardinality_threshold=prefilter_cardinality_threshold,
            filter_boost_percentage=filter_boost_percentage,
            include_vectors=include_vectors,
            sparse_indices=sparse_indices,
            sparse_values=sparse_values,
            rrf_rank_constant=rrf_rank_constant,
            dense_rrf_weight=dense_rrf_weight,
        )

    def similarity_search_by_vector(
        self,
        embedding: list[float],
        k: int = 4,
        filter: list[dict[str, Any]] | None = None,  # noqa: A002
        ef: int = constants.DEFAULT_EF_SEARCH,
        prefilter_cardinality_threshold: int | None = None,
        filter_boost_percentage: int | None = None,
        include_vectors: bool = False,  # noqa: FBT001, FBT002
        rrf_rank_constant: int | None = None,
        dense_rrf_weight: float | None = None,
    ) -> list[Document]:
        """Return docs most similar to a pre-computed embedding vector.

        See ``similarity_search`` for parameter descriptions.
        """
        docs_and_scores = self.similarity_search_by_vector_with_score(
            embedding,
            k=k,
            filter=filter,
            ef=ef,
            prefilter_cardinality_threshold=prefilter_cardinality_threshold,
            filter_boost_percentage=filter_boost_percentage,
            include_vectors=include_vectors,
            rrf_rank_constant=rrf_rank_constant,
            dense_rrf_weight=dense_rrf_weight,
        )
        return [doc for doc, _ in docs_and_scores]

    def similarity_search_by_vector_with_score(
        self,
        embedding: list[float],
        k: int = 4,
        filter: list[dict[str, Any]] | None = None,  # noqa: A002
        ef: int = constants.DEFAULT_EF_SEARCH,
        prefilter_cardinality_threshold: int | None = None,
        filter_boost_percentage: int | None = None,
        include_vectors: bool = False,  # noqa: FBT001, FBT002
        sparse_indices: list[int] | None = None,
        sparse_values: list[float] | None = None,
        rrf_rank_constant: int | None = None,
        dense_rrf_weight: float | None = None,
    ) -> list[tuple[Document, float]]:
        """Return docs most similar to an embedding vector, with scores.

        This is the core search method — all other search methods delegate here.
        See ``similarity_search`` for filter/ef params.

        Args:
            rrf_rank_constant: RRF fusion constant (hybrid only).
            dense_rrf_weight: Weight for dense scores in RRF (hybrid only).
        """
        query_params: dict[str, Any] = {
            "vector": embedding,
            "top_k": k,
            "ef": ef,
            "include_vectors": include_vectors,
        }

        if filter is not None:
            query_params["filter"] = filter

        if prefilter_cardinality_threshold is not None:
            query_params["prefilter_cardinality_threshold"] = (
                prefilter_cardinality_threshold
            )

        if filter_boost_percentage is not None:
            query_params["filter_boost_percentage"] = filter_boost_percentage

        if sparse_indices is not None and sparse_values is not None:
            query_params["sparse_indices"] = sparse_indices
            query_params["sparse_values"] = sparse_values

        if rrf_rank_constant is not None:
            query_params["rrf_rank_constant"] = rrf_rank_constant

        if dense_rrf_weight is not None:
            query_params["dense_rrf_weight"] = dense_rrf_weight

        results = self._index.query(**query_params)

        docs = []
        for res in results:
            meta = res.get("meta", {})
            text = meta.get(self.content_payload_key, "")
            metadata = meta.get(self.metadata_payload_key, {})

            metadata["_id"] = res.get("id")
            if "filter" in res:
                metadata["_filter"] = res["filter"]
            if "distance" in res:
                metadata["_distance"] = res["distance"]

            score = res.get("similarity", 0.0)

            if not text:
                logger.warning(
                    f"Found document with no `{self.content_payload_key}` key. "
                    "Skipping."
                )
                continue

            docs.append((Document(page_content=text, metadata=metadata), score))

        return docs

    def delete(
        self,
        ids: list[str] | None = None,
        filter: list[dict[str, Any]] | None = None,  # noqa: A002
        **kwargs: Any,
    ) -> bool | None:
        """Delete by IDs or filter. Returns True on success, False on error."""
        if ids is None and filter is None:
            msg = "Either ids or filter must be provided"
            raise ValueError(msg)

        try:
            if ids is not None:
                # Delete by IDs - one at a time for better error handling
                for doc_id in ids:
                    try:
                        self._index.delete_vector(doc_id)
                    except Exception as e:
                        logger.warning(f"Error deleting vector with ID {doc_id}: {e}")
                        return False
            elif filter is not None:
                # Delete by filter
                self._index.delete_with_filter(filter=filter)

            return True
        except Exception as e:
            logger.error(f"Error during deletion: {e}")
            return False

    def get_by_ids(self, ids: Sequence[str], /) -> list[Document]:
        """Retrieve documents by their IDs."""
        docs = []

        for doc_id in ids:
            try:
                result = self._index.get_vector(doc_id)

                meta = result.get("meta", {})
                text = meta.get(self.content_payload_key, "")
                metadata = meta.get(self.metadata_payload_key, {})

                # Add additional fields
                metadata["_id"] = result.get("id")
                if "filter" in result:
                    metadata["_filter"] = result["filter"]

                if text:
                    docs.append(Document(page_content=text, metadata=metadata))
                else:
                    logger.warning(
                        f"Document {doc_id} has no `{self.content_payload_key}` key."
                    )
            except Exception as e:
                logger.warning(f"Error retrieving document {doc_id}: {e}")

        return docs

    def update_filters(
        self,
        updates: list[dict],
    ) -> str:
        """Update filter metadata for vectors by ID (no re-embedding).

        Args:
            updates: List of ``{"id": str, "filter": dict}`` dicts.
        """
        if not updates:
            msg = "updates must be a non-empty list"
            raise ValueError(msg)

        try:
            return self._index.update_filters(updates)
        except Exception as e:
            msg = f"Failed to update filters: {e}"
            raise EndeeVectorStoreError(msg) from e
