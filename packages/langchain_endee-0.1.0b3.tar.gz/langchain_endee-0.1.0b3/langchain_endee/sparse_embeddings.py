"""Sparse embedding models for hybrid search with Endee."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Sequence

from endee._pydantic_compat import PYDANTIC_V2, ConfigDict
from langchain_core.runnables.config import run_in_executor
from pydantic import BaseModel, Field

# ---------------------------------------------------------------------------
# SparseVector — pydantic v1/v2 compatible
# ---------------------------------------------------------------------------

if PYDANTIC_V2:

    class SparseVector(BaseModel):
        """Sparse vector with non-zero indices and their values."""

        model_config = ConfigDict(extra="forbid")

        indices: list[int] = Field(..., description="indices must be unique")
        values: list[float] = Field(
            ..., description="values and indices must be the same length"
        )

else:

    class SparseVector(BaseModel):  # type: ignore[no-redef]
        """Sparse vector with non-zero indices and their values."""

        class Config:
            extra = "forbid"

        indices: list[int] = Field(..., description="indices must be unique")
        values: list[float] = Field(
            ..., description="values and indices must be the same length"
        )


# ---------------------------------------------------------------------------
# Abstract base
# ---------------------------------------------------------------------------


class SparseEmbeddings(ABC):
    """Interface for sparse embedding models used with Endee."""

    @abstractmethod
    def embed_documents(self, texts: list[str]) -> list[SparseVector]:
        """Embed a list of documents as sparse vectors."""

    @abstractmethod
    def embed_query(self, text: str) -> SparseVector:
        """Embed a single query as a sparse vector."""

    async def aembed_documents(self, texts: list[str]) -> list[SparseVector]:
        """Async version of ``embed_documents``."""
        return await run_in_executor(None, self.embed_documents, texts)

    async def aembed_query(self, text: str) -> SparseVector:
        """Async version of ``embed_query``."""
        return await run_in_executor(None, self.embed_query, text)


# ---------------------------------------------------------------------------
# EndeeModelSparse — native BM25 via endee_model (recommended)
# ---------------------------------------------------------------------------


class EndeeModelSparse(SparseEmbeddings):
    """Sparse embeddings using endee_model's native BM25.

    Computes BM25 term-frequency weights on the client. The Endee server
    applies IDF weighting when ``sparse_model="endee_bm25"`` is set on the
    index (done automatically by ``EndeeVectorStore``).

    Args:
        model_name: Model identifier. Default: ``"endee/bm25"``.
        k: BM25 saturation parameter. Default: 1.2.
        b: BM25 length normalisation parameter. Default: 0.75.
        avg_len: Expected average document length in tokens. Default: 256.0.
        language: Language for NLTK stopwords / Snowball stemmer.
        cache_dir: Optional cache directory for NLTK data.
        kwargs: Forwarded to ``endee_model.SparseModel``.
    """

    def __init__(
        self,
        model_name: str = "endee/bm25",
        k: float = 1.2,
        b: float = 0.75,
        avg_len: float = 256.0,
        language: str = "english",
        cache_dir: str | None = None,
        **kwargs: Any,
    ) -> None:
        try:
            from endee_model import SparseModel
        except ImportError as err:
            msg = (
                "The 'endee_model' package is not installed. "
                "Install it with: pip install endee-model"
            )
            raise ImportError(msg) from err

        self._model = SparseModel(
            model_name=model_name,
            cache_dir=cache_dir,
            k=k,
            b=b,
            avg_len=avg_len,
            language=language,
            **kwargs,
        )

    def embed_documents(self, texts: list[str]) -> list[SparseVector]:
        """Embed documents as sparse vectors (BM25 TF weights)."""
        return [
            SparseVector(indices=r.indices.tolist(), values=r.values.tolist())
            for r in self._model.embed(texts)
        ]

    def embed_query(self, text: str) -> SparseVector:
        """Embed a query as a sparse vector (unique term IDs, unit weights)."""
        r = next(self._model.query_embed(text))
        return SparseVector(indices=r.indices.tolist(), values=r.values.tolist())


# ---------------------------------------------------------------------------
# FastEmbedSparse — SPLADE / BM25 via fastembed (optional)
# ---------------------------------------------------------------------------


class FastEmbedSparse(SparseEmbeddings):
    """Sparse embedding model using FastEmbed for use with Endee.

    Uses `FastEmbed <https://qdrant.github.io/fastembed/>`_ for sparse text
    embeddings (SPLADE or BM25).

    Requires ``pip install fastembed`` (or ``pip install fastembed-gpu``).

    Args:
        model_name: Model to use. Default: ``"prithivida/Splade_PP_en_v1"``.
            - ``"prithivida/Splade_PP_en_v1"``: Neural sparse model (SPLADE).
            - ``"Qdrant/bm25"``: Classical BM25 algorithm, faster.
        batch_size: Batch size for encoding. Default: 128.
        cache_dir: Path to model cache directory.
        threads: Number of threads for the ONNX runtime session.
        providers: List of ONNX execution providers.
        parallel: Data-parallel encoding workers. ``>1`` for large datasets,
            ``0`` for all cores, ``None`` for default threading.
        kwargs: Forwarded to ``fastembed.SparseTextEmbedding``.
    """

    def __init__(
        self,
        model_name: str = "prithivida/Splade_PP_en_v1",
        batch_size: int = 128,
        cache_dir: str | None = None,
        threads: int | None = None,
        providers: Sequence[Any] | None = None,
        parallel: int | None = None,
        **kwargs: Any,
    ) -> None:
        try:
            from fastembed import SparseTextEmbedding  # type: ignore[import-not-found]
        except ImportError as err:
            msg = (
                "The 'fastembed' package is not installed. "
                "Install it with: pip install fastembed"
            )
            raise ImportError(msg) from err

        self._batch_size = batch_size
        self._parallel = parallel
        self._model = SparseTextEmbedding(
            model_name=model_name,
            cache_dir=cache_dir,
            threads=threads,
            providers=providers,
            **kwargs,
        )

    def embed_documents(self, texts: list[str]) -> list[SparseVector]:
        """Embed documents as sparse vectors."""
        results = self._model.embed(
            texts, batch_size=self._batch_size, parallel=self._parallel
        )
        return [
            SparseVector(indices=r.indices.tolist(), values=r.values.tolist())
            for r in results
        ]

    def embed_query(self, text: str) -> SparseVector:
        """Embed a query as a sparse vector."""
        r = next(self._model.query_embed(text))
        return SparseVector(indices=r.indices.tolist(), values=r.values.tolist())
