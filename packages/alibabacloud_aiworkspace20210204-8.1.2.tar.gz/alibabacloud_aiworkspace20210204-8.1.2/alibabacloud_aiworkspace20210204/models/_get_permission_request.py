# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from typing import Dict, Any

from darabonba.model import DaraModel

class GetPermissionRequest(DaraModel):
    def __init__(
        self,
        accessibility: str = None,
        caller_type: str = None,
        caller_uid: str = None,
        creator: str = None,
        labels: Dict[str, Any] = None,
        option: str = None,
        resource: str = None,
        security_token: str = None,
    ):
        # The accessibility. Valid values:
        # 
        # *   PUBLIC: All members in the workspace can access the workspace.
        # *   PRIVATE: Only the creator can access the workspace.
        self.accessibility = accessibility
        self.caller_type = caller_type
        self.caller_uid = caller_uid
        # The UID of the Alibaba Cloud account that is used to create the workspace.
        self.creator = creator
        self.labels = labels
        # The configuration. Separate multiple configurations with commas (,). Valid values:
        # 
        # *   ResourceEmpty: The Resource parameter is not configured.
        # *   DisableRam: The RAM check is not performed.
        self.option = option
        # The resource.
        self.resource = resource
        self.security_token = security_token

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.accessibility is not None:
            result['Accessibility'] = self.accessibility

        if self.caller_type is not None:
            result['CallerType'] = self.caller_type

        if self.caller_uid is not None:
            result['CallerUid'] = self.caller_uid

        if self.creator is not None:
            result['Creator'] = self.creator

        if self.labels is not None:
            result['Labels'] = self.labels

        if self.option is not None:
            result['Option'] = self.option

        if self.resource is not None:
            result['Resource'] = self.resource

        if self.security_token is not None:
            result['SecurityToken'] = self.security_token

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('Accessibility') is not None:
            self.accessibility = m.get('Accessibility')

        if m.get('CallerType') is not None:
            self.caller_type = m.get('CallerType')

        if m.get('CallerUid') is not None:
            self.caller_uid = m.get('CallerUid')

        if m.get('Creator') is not None:
            self.creator = m.get('Creator')

        if m.get('Labels') is not None:
            self.labels = m.get('Labels')

        if m.get('Option') is not None:
            self.option = m.get('Option')

        if m.get('Resource') is not None:
            self.resource = m.get('Resource')

        if m.get('SecurityToken') is not None:
            self.security_token = m.get('SecurityToken')

        return self

