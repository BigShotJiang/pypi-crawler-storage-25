"""Tests for the audit trail module."""

import json
import tempfile
from pathlib import Path

import pytest
from vaara.audit.trail import (
    AuditRecord,
    AuditTrail,
    EventType,
    EU_AI_ACT_MAPPINGS,
)
from vaara.taxonomy.actions import (
    ActionCategory,
    ActionRequest,
    ActionType,
    BlastRadius,
    RegulatoryDomain,
    Reversibility,
    UrgencyClass,
)


@pytest.fixture
def trail():
    return AuditTrail()


@pytest.fixture
def sample_request():
    at = ActionType(
        "tx.transfer", ActionCategory.FINANCIAL, Reversibility.IRREVERSIBLE,
        BlastRadius.SHARED, UrgencyClass.IRREVOCABLE,
        frozenset({RegulatoryDomain.MIFID2, RegulatoryDomain.DORA}),
    )
    return ActionRequest(
        agent_id="agent-007",
        tool_name="tx.transfer",
        action_type=at,
        parameters={"to": "0xabc", "amount": 1000},
        confidence=0.8,
    )


class TestAuditRecord:
    def test_compute_hash_deterministic(self):
        r = AuditRecord(
            record_id="r1", action_id="a1", event_type=EventType.ACTION_REQUESTED,
            timestamp=1000.0, agent_id="agent", tool_name="tool",
        )
        h1 = r.compute_hash()
        h2 = r.compute_hash()
        assert h1 == h2
        assert len(h1) == 64  # SHA-256 hex

    def test_different_content_different_hash(self):
        r1 = AuditRecord(
            record_id="r1", action_id="a1", event_type=EventType.ACTION_REQUESTED,
            timestamp=1000.0, agent_id="agent", tool_name="tool",
        )
        r2 = AuditRecord(
            record_id="r2", action_id="a1", event_type=EventType.ACTION_REQUESTED,
            timestamp=1000.0, agent_id="agent", tool_name="tool",
        )
        assert r1.compute_hash() != r2.compute_hash()

    def test_serialization_roundtrip(self):
        r = AuditRecord(
            record_id="r1", action_id="a1", event_type=EventType.RISK_SCORED,
            timestamp=1000.0, agent_id="agent", tool_name="tx.sign",
            data={"risk": 0.7},
        )
        d = r.to_dict()
        r2 = AuditRecord.from_dict(d)
        assert r2.record_id == "r1"
        assert r2.event_type == EventType.RISK_SCORED
        assert r2.data["risk"] == 0.7

    def test_narrative_generation(self):
        r = AuditRecord(
            record_id="r1", action_id="a1", event_type=EventType.ACTION_BLOCKED,
            timestamp=1000.0, agent_id="bad-agent", tool_name="tx.transfer",
            data={"risk_score": 0.9},
        )
        narrative = r.narrative
        assert "bad-agent" in narrative
        assert "BLOCKED" in narrative
        assert "tx.transfer" in narrative


class TestAuditTrail:
    def test_record_action_returns_action_id(self, trail, sample_request):
        action_id = trail.record_action_requested(sample_request)
        assert action_id  # Non-empty string
        assert trail.size == 1

    def test_hash_chain_integrity(self, trail, sample_request):
        trail.record_action_requested(sample_request)
        trail.record_decision(
            action_id="a1", agent_id="agent-007", tool_name="tx.transfer",
            decision="deny", reason="too risky", risk_score=0.9,
        )
        assert trail.chain_intact

    def test_chain_detects_tampering(self, trail, sample_request):
        trail.record_action_requested(sample_request)
        trail.record_decision(
            action_id="a1", agent_id="agent-007", tool_name="tx.transfer",
            decision="allow", reason="ok", risk_score=0.2,
        )
        # Tamper with a record
        trail._records[0].data["tampered"] = True
        error = trail.verify_chain()
        assert error is not None
        assert "Hash mismatch" in error

    def test_action_trail_groups_events(self, trail, sample_request):
        action_id = trail.record_action_requested(sample_request)
        trail.record_risk_scored(
            action_id=action_id, agent_id="agent-007", tool_name="tx.transfer",
            assessment={"risk": 0.7},
        )
        trail.record_decision(
            action_id=action_id, agent_id="agent-007", tool_name="tx.transfer",
            decision="deny", reason="high risk", risk_score=0.7,
        )
        events = trail.get_action_trail(action_id)
        assert len(events) == 3
        assert events[0].event_type == EventType.ACTION_REQUESTED
        assert events[1].event_type == EventType.RISK_SCORED
        assert events[2].event_type == EventType.ACTION_BLOCKED

    def test_regulatory_articles_attached(self, trail, sample_request):
        action_id = trail.record_action_requested(sample_request)
        events = trail.get_action_trail(action_id)
        record = events[0]
        assert len(record.regulatory_articles) > 0
        domains = {a["domain"] for a in record.regulatory_articles}
        assert "eu_ai_act" in domains

    def test_get_blocked_actions(self, trail):
        trail.record_decision(
            action_id="a1", agent_id="agent", tool_name="danger",
            decision="deny", reason="blocked", risk_score=0.9,
        )
        blocked = trail.get_blocked_actions()
        assert len(blocked) == 1
        assert blocked[0].event_type == EventType.ACTION_BLOCKED

    def test_export_json(self, trail, sample_request):
        trail.record_action_requested(sample_request)
        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
            path = Path(f.name)
        count = trail.export_json(path)
        assert count == 1
        data = json.loads(path.read_text())
        assert len(data) == 1
        path.unlink()

    def test_export_jsonl(self, trail, sample_request):
        trail.record_action_requested(sample_request)
        trail.record_decision(
            action_id="a1", agent_id="agent-007", tool_name="tx.transfer",
            decision="allow", reason="ok", risk_score=0.2,
        )
        with tempfile.NamedTemporaryFile(suffix=".jsonl", delete=False) as f:
            path = Path(f.name)
        count = trail.export_jsonl(path)
        assert count == 2
        lines = path.read_text().strip().split("\n")
        assert len(lines) == 2
        path.unlink()

    def test_narrative_output(self, trail, sample_request):
        action_id = trail.record_action_requested(sample_request)
        trail.record_decision(
            action_id=action_id, agent_id="agent-007", tool_name="tx.transfer",
            decision="deny", reason="too risky", risk_score=0.8,
        )
        narrative = trail.get_narrative(action_id)
        assert "agent-007" in narrative
        assert "tx.transfer" in narrative

    def test_on_record_callback(self, sample_request):
        captured = []
        trail = AuditTrail(on_record=lambda r: captured.append(r))
        trail.record_action_requested(sample_request)
        assert len(captured) == 1
        assert captured[0].event_type == EventType.ACTION_REQUESTED

    def test_outcome_recording(self, trail):
        trail.record_outcome(
            action_id="a1", agent_id="agent", tool_name="tx.swap",
            outcome_severity=0.3, description="Minor slippage",
        )
        outcomes = trail.get_records_by_type(EventType.OUTCOME_RECORDED)
        assert len(outcomes) == 1
        assert outcomes[0].data["outcome_severity"] == 0.3


class TestRegulatoryMappings:
    def test_eu_ai_act_mappings_cover_key_events(self):
        assert EventType.ACTION_REQUESTED in EU_AI_ACT_MAPPINGS
        assert EventType.RISK_SCORED in EU_AI_ACT_MAPPINGS
        assert EventType.DECISION_MADE in EU_AI_ACT_MAPPINGS
        assert EventType.OUTCOME_RECORDED in EU_AI_ACT_MAPPINGS

    def test_all_mappings_have_required_fields(self):
        for event_type, articles in EU_AI_ACT_MAPPINGS.items():
            for article in articles:
                assert article.domain == RegulatoryDomain.EU_AI_ACT
                assert article.article  # Non-empty
                assert article.requirement  # Non-empty
                assert article.how_satisfied  # Non-empty
