"""Tests for the interception pipeline — end-to-end integration."""

import pytest
from vaara.pipeline import InterceptionPipeline
from vaara.taxonomy.actions import (
    ActionCategory,
    ActionType,
    BlastRadius,
    RegulatoryDomain,
    Reversibility,
    UrgencyClass,
)


@pytest.fixture
def pipeline():
    return InterceptionPipeline()


class TestInterceptionPipeline:
    def test_intercept_low_risk(self, pipeline):
        result = pipeline.intercept(
            agent_id="trusted-agent",
            tool_name="data.read",
            parameters={"table": "users"},
            agent_confidence=0.95,
        )
        assert result.action_id  # Non-empty
        assert result.decision in ("allow", "escalate", "deny")
        assert 0.0 <= result.risk_score <= 1.0
        assert result.evaluation_ms > 0

    def test_intercept_high_risk(self, pipeline):
        # Register the tool mapping so it classifies correctly
        pipeline.registry.map_tool("phy.safety_override", "phy.safety_override")
        result = pipeline.intercept(
            agent_id="unknown-agent",
            tool_name="phy.safety_override",
            parameters={"system": "brakes"},
        )
        # Safety override with unknown agent should be denied or escalated
        assert result.decision in ("deny", "escalate")
        # Taxonomy base risk is 0.875, but MWU dilutes across 5 experts.
        # The conformal upper bound drives the decision, not point estimate.
        assert result.risk_interval[1] > 0.3  # Upper bound should be elevated

    def test_audit_trail_populated(self, pipeline):
        result = pipeline.intercept(
            agent_id="agent-1",
            tool_name="tx.sign",
            parameters={"hash": "0xabc"},
        )
        trail = pipeline.trail.get_action_trail(result.action_id)
        # Should have: requested, scored, decision (at minimum)
        assert len(trail) >= 3

    def test_outcome_feedback_loop(self, pipeline):
        result = pipeline.intercept(
            agent_id="agent-1",
            tool_name="data.read",
            agent_confidence=0.9,
        )
        # Report safe outcome
        pipeline.report_outcome(
            action_id=result.action_id,
            outcome_severity=0.0,
            description="Completed safely",
        )
        # Check outcome recorded in audit
        trail = pipeline.trail.get_action_trail(result.action_id)
        event_types = [r.event_type.value for r in trail]
        assert "outcome_recorded" in event_types

        # Check scorer updated
        assert pipeline.scorer.calibration_size >= 1

    def test_escalation_resolution(self, pipeline):
        result = pipeline.intercept(
            agent_id="agent-1",
            tool_name="tx.transfer",
            parameters={"amount": 1000000},
        )
        # Resolve it regardless of actual decision
        pipeline.resolve_escalation(
            action_id=result.action_id,
            resolution="allow",
            reviewer="admin@company.com",
            justification="Reviewed and approved",
        )
        trail = pipeline.trail.get_action_trail(result.action_id)
        event_types = [r.event_type.value for r in trail]
        assert "escalation_resolved" in event_types

    def test_multiple_agents(self, pipeline):
        for i in range(5):
            pipeline.intercept(
                agent_id=f"agent-{i}",
                tool_name="data.read",
                agent_confidence=0.8,
            )
        # All agents should have profiles
        for i in range(5):
            profile = pipeline.scorer.get_agent_profile(f"agent-{i}")
            assert profile is not None
            assert profile.total_actions == 1

    def test_sequence_across_actions(self, pipeline):
        # Build a data exfiltration sequence
        pipeline.intercept(
            agent_id="suspect",
            tool_name="data.read",
            parameters={"table": "sensitive"},
        )
        result = pipeline.intercept(
            agent_id="suspect",
            tool_name="data.export",
            parameters={"destination": "external"},
        )
        # Second action should have elevated sequence risk
        assert result.signals.get("sequence_pattern", 0) > 0

    def test_compliance_assessment(self, pipeline):
        # Generate some activity
        for i in range(15):
            result = pipeline.intercept(
                agent_id="agent-1",
                tool_name="data.read" if i % 2 == 0 else "tx.transfer",
                agent_confidence=0.7,
            )
            pipeline.report_outcome(result.action_id, 0.0)

        report = pipeline.run_compliance_assessment()
        assert report.trail_chain_intact
        assert report.summary  # Non-empty

    def test_status_snapshot(self, pipeline):
        status = pipeline.status()
        assert "scorer" in status
        assert "trail_size" in status
        assert "trail_chain_intact" in status
        assert status["trail_size"] == 0  # Empty initially

    def test_unknown_tool_handled(self, pipeline):
        result = pipeline.intercept(
            agent_id="agent",
            tool_name="completely.unknown.tool",
        )
        # Should still work — classified as unknown
        assert result.action_id
        assert result.action_type.name == "unknown"

    def test_custom_registry_integration(self, pipeline):
        # Register a custom action type
        custom = ActionType(
            "defi.flashloan",
            ActionCategory.FINANCIAL,
            Reversibility.IRREVERSIBLE,
            BlastRadius.GLOBAL,
            UrgencyClass.IRREVOCABLE,
            frozenset({RegulatoryDomain.DORA}),
            "Execute flash loan",
        )
        pipeline.registry.register(custom)
        pipeline.registry.map_tool("defi.flashloan", "defi.flashloan")

        result = pipeline.intercept(
            agent_id="defi-bot",
            tool_name="defi.flashloan",
            parameters={"amount": 1000000, "protocol": "aave"},
        )
        assert result.action_type.name == "defi.flashloan"
        assert result.action_type.category == ActionCategory.FINANCIAL
