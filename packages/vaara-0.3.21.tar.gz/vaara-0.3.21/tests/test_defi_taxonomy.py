"""Tests for DeFi-specific action taxonomy and sequences."""

import pytest

from vaara.taxonomy.actions import (
    ActionCategory,
    ActionRegistry,
    BlastRadius,
    Reversibility,
    UrgencyClass,
    create_default_registry,
)
from vaara.taxonomy.defi import (
    DEFI_ACTIONS,
    DEFI_SEQUENCES,
    Atomicity,
    DeFiActionType,
    MEVVulnerability,
    ProtocolType,
    create_defi_registry,
    get_defi_sequences,
    register_defi_actions,
)
from vaara.scorer.adaptive import AdaptiveScorer, SequencePattern


class TestDeFiActionTypes:
    def test_defi_action_count(self):
        """We define 25+ DeFi-specific action types."""
        assert len(DEFI_ACTIONS) >= 25

    def test_all_unique_names(self):
        names = [a.name for a in DEFI_ACTIONS]
        assert len(names) == len(set(names)), f"Duplicate names: {[n for n in names if names.count(n) > 1]}"

    def test_all_start_with_defi_prefix(self):
        for action in DEFI_ACTIONS:
            assert action.name.startswith("defi."), f"{action.name} missing defi. prefix"

    def test_all_have_descriptions(self):
        for action in DEFI_ACTIONS:
            assert action.description, f"{action.name} has no description"

    def test_all_have_protocol_type(self):
        for action in DEFI_ACTIONS:
            assert isinstance(action.protocol_type, ProtocolType)

    def test_base_risk_score_range(self):
        """All DeFi actions should have base risk in [0, 1]."""
        for action in DEFI_ACTIONS:
            score = action.base_risk_score
            assert 0.0 <= score <= 1.0, f"{action.name}: {score}"

    def test_mev_increases_base_risk(self):
        """MEV vulnerability should increase the base risk score."""
        base = DeFiActionType(
            name="test.no_mev",
            category=ActionCategory.FINANCIAL,
            reversibility=Reversibility.PARTIALLY,
            blast_radius=BlastRadius.LOCAL,
            mev_vulnerability=MEVVulnerability.NONE,
        )
        high_mev = DeFiActionType(
            name="test.high_mev",
            category=ActionCategory.FINANCIAL,
            reversibility=Reversibility.PARTIALLY,
            blast_radius=BlastRadius.LOCAL,
            mev_vulnerability=MEVVulnerability.HIGH,
        )
        assert high_mev.base_risk_score > base.base_risk_score

    def test_flash_atomicity_increases_risk(self):
        """Flash loan atomicity should increase risk."""
        single = DeFiActionType(
            name="test.single",
            category=ActionCategory.FINANCIAL,
            reversibility=Reversibility.PARTIALLY,
            blast_radius=BlastRadius.LOCAL,
            atomicity=Atomicity.SINGLE,
        )
        flash = DeFiActionType(
            name="test.flash",
            category=ActionCategory.FINANCIAL,
            reversibility=Reversibility.PARTIALLY,
            blast_radius=BlastRadius.LOCAL,
            atomicity=Atomicity.FLASH,
        )
        assert flash.base_risk_score > single.base_risk_score

    def test_cross_chain_increases_risk(self):
        """Cross-chain atomicity should increase risk."""
        single = DeFiActionType(
            name="test.single",
            category=ActionCategory.FINANCIAL,
            reversibility=Reversibility.PARTIALLY,
            blast_radius=BlastRadius.LOCAL,
            atomicity=Atomicity.SINGLE,
        )
        cross = DeFiActionType(
            name="test.cross",
            category=ActionCategory.FINANCIAL,
            reversibility=Reversibility.PARTIALLY,
            blast_radius=BlastRadius.LOCAL,
            atomicity=Atomicity.CROSS_CHAIN,
        )
        assert cross.base_risk_score > single.base_risk_score

    def test_defi_risk_never_decreases_base(self):
        """DeFi-specific factors should only ADD to base risk, never reduce it."""
        for action in DEFI_ACTIONS:
            # Create equivalent base action without DeFi metadata
            base_action = DeFiActionType(
                name="test.base",
                category=action.category,
                reversibility=action.reversibility,
                blast_radius=action.blast_radius,
                urgency=action.urgency,
                mev_vulnerability=MEVVulnerability.NONE,
                atomicity=Atomicity.SINGLE,
            )
            assert action.base_risk_score >= base_action.base_risk_score, (
                f"{action.name}: DeFi risk {action.base_risk_score} < base {base_action.base_risk_score}"
            )

    def test_flash_loan_highest_risk_class(self):
        """Flash loans should be among the highest-risk DeFi actions."""
        flash = next(a for a in DEFI_ACTIONS if a.name == "defi.flash_loan")
        assert flash.base_risk_score >= 0.5
        assert flash.mev_vulnerability == MEVVulnerability.CRITICAL
        assert flash.atomicity == Atomicity.FLASH

    def test_liquidation_high_risk(self):
        liq = next(a for a in DEFI_ACTIONS if a.name == "defi.liquidate")
        assert liq.base_risk_score >= 0.5
        assert liq.mev_vulnerability == MEVVulnerability.CRITICAL

    def test_swap_has_mev_vulnerability(self):
        swap = next(a for a in DEFI_ACTIONS if a.name == "defi.swap")
        assert swap.mev_vulnerability in (MEVVulnerability.MEDIUM, MEVVulnerability.HIGH)

    def test_oracle_update_global_blast(self):
        oracle = next(a for a in DEFI_ACTIONS if a.name == "defi.oracle_update")
        assert oracle.blast_radius == BlastRadius.GLOBAL

    def test_bridge_operations_cross_chain(self):
        bridges = [a for a in DEFI_ACTIONS if "bridge" in a.name]
        for b in bridges:
            assert b.atomicity == Atomicity.CROSS_CHAIN

    def test_unlimited_approval_higher_risk_than_exact(self):
        unlimited = next(a for a in DEFI_ACTIONS if a.name == "defi.approve_unlimited")
        exact = next(a for a in DEFI_ACTIONS if a.name == "defi.approve_exact")
        # Unlimited has SHARED blast vs LOCAL for exact
        assert unlimited.base_risk_score >= exact.base_risk_score


class TestDeFiSequences:
    def test_sequence_count(self):
        assert len(DEFI_SEQUENCES) >= 15

    def test_all_unique_names(self):
        names = [s.name for s in DEFI_SEQUENCES]
        assert len(names) == len(set(names))

    def test_all_have_descriptions(self):
        for seq in DEFI_SEQUENCES:
            assert seq.description, f"{seq.name} has no description"

    def test_risk_boost_range(self):
        for seq in DEFI_SEQUENCES:
            assert 0.0 < seq.risk_boost <= 1.0, f"{seq.name}: {seq.risk_boost}"

    def test_flash_loan_sequences_highest_risk(self):
        """Flash loan attack sequences should have high risk boosts."""
        flash_seqs = [s for s in DEFI_SEQUENCES if "flash_loan" in s.name]
        assert len(flash_seqs) >= 3
        for seq in flash_seqs:
            assert seq.risk_boost >= 0.6

    def test_governance_flash_vote_highest_boost(self):
        """Flash governance attack should have the highest boost."""
        gov_flash = next(s for s in DEFI_SEQUENCES if s.name == "governance_flash_vote")
        assert gov_flash.risk_boost >= 0.9

    def test_rug_pull_full_high_boost(self):
        rug = next(s for s in DEFI_SEQUENCES if s.name == "rug_pull_full")
        assert rug.risk_boost >= 0.7

    def test_get_defi_sequences_returns_copy(self):
        seqs1 = get_defi_sequences()
        seqs2 = get_defi_sequences()
        assert seqs1 is not seqs2
        assert len(seqs1) == len(seqs2)


class TestDeFiRegistry:
    def test_create_defi_registry(self):
        reg = create_defi_registry()
        # Should have both base and DeFi types
        all_types = reg.all_types
        assert "data.read" in all_types  # Base
        assert "defi.swap" in all_types  # DeFi
        assert "defi.flash_loan" in all_types

    def test_register_defi_actions_to_existing(self):
        reg = create_default_registry()
        base_count = len(reg.all_types)
        register_defi_actions(reg)
        assert len(reg.all_types) > base_count

    def test_classify_defi_tool(self):
        reg = create_defi_registry()
        action = reg.classify("defi.swap")
        assert action.name == "defi.swap"
        assert isinstance(action, DeFiActionType)
        assert action.protocol_type == ProtocolType.DEX

    def test_classify_unknown_defi_tool(self):
        reg = create_defi_registry()
        action = reg.classify("defi.unknown_thing")
        # Should still match via "defi." prefix if mapped, or UNKNOWN
        assert action is not None

    def test_defi_actions_dont_conflict_with_base(self):
        """DeFi action names shouldn't collide with base action names."""
        reg = create_defi_registry()
        base_reg = create_default_registry()
        base_names = set(base_reg.all_types.keys())
        defi_names = {a.name for a in DEFI_ACTIONS}
        overlap = base_names & defi_names
        assert not overlap, f"Name collision: {overlap}"


class TestDeFiScorerIntegration:
    """Test that DeFi sequences work with the adaptive scorer."""

    def test_scorer_with_defi_sequences(self):
        scorer = AdaptiveScorer(sequence_patterns=list(DEFI_SEQUENCES))
        assert len(scorer._sequences) >= 15

    def test_flash_loan_sequence_detected(self):
        all_seqs = list(DEFI_SEQUENCES)
        scorer = AdaptiveScorer(sequence_patterns=all_seqs)

        # Build up a flash loan attack pattern
        ctx1 = {"tool_name": "defi.flash_loan", "agent_id": "attacker",
                "base_risk_score": 0.5, "agent_confidence": None,
                "reversibility": "fully_reversible", "blast_radius": "global"}
        scorer.evaluate(ctx1)

        ctx2 = {"tool_name": "defi.swap", "agent_id": "attacker",
                "base_risk_score": 0.4, "agent_confidence": None,
                "reversibility": "irreversible", "blast_radius": "shared"}
        scorer.evaluate(ctx2)

        # Third action should trigger sequence detection
        ctx3 = {"tool_name": "defi.swap", "agent_id": "attacker",
                "base_risk_score": 0.4, "agent_confidence": None,
                "reversibility": "irreversible", "blast_radius": "shared"}
        result = scorer.evaluate(ctx3)
        raw = result.get("raw_result", {})
        signals = raw.get("signals", {})
        assert signals.get("sequence_pattern", 0.0) >= 0.5

    def test_rug_pull_sequence_detected(self):
        all_seqs = list(DEFI_SEQUENCES)
        scorer = AdaptiveScorer(sequence_patterns=all_seqs)

        for tool_name in ["defi.add_liquidity", "defi.remove_liquidity"]:
            ctx = {"tool_name": tool_name, "agent_id": "rugger",
                   "base_risk_score": 0.3, "agent_confidence": None,
                   "reversibility": "irreversible", "blast_radius": "shared"}
            result = scorer.evaluate(ctx)

        raw = result.get("raw_result", {})
        signals = raw.get("signals", {})
        assert signals.get("sequence_pattern", 0.0) >= 0.3
