"""Tests for the adaptive risk scorer."""

import pytest
from vaara.scorer.adaptive import (
    AdaptiveScorer,
    ConformalCalibrator,
    Decision,
    MWUExperts,
    SequencePattern,
    BUILTIN_SEQUENCES,
)


class TestMWUExperts:
    def test_initial_weights_uniform(self):
        mwu = MWUExperts(["a", "b", "c"])
        weights = mwu.weights
        assert len(weights) == 3
        assert abs(weights["a"] - 1/3) < 0.01

    def test_predict_weighted_average(self):
        mwu = MWUExperts(["a", "b"])
        # Uniform weights → simple average
        result = mwu.predict({"a": 0.2, "b": 0.8})
        assert abs(result - 0.5) < 0.01

    def test_update_shifts_weights(self):
        mwu = MWUExperts(["good", "bad"], eta=0.5)
        # "good" predicts 0.8, "bad" predicts 0.2, actual was 0.8
        for _ in range(10):
            mwu.update({"good": 0.8, "bad": 0.2}, outcome=0.8)
        # "good" should have higher weight
        assert mwu.weights["good"] > mwu.weights["bad"]

    def test_predict_clamped_0_1(self):
        mwu = MWUExperts(["x"])
        assert 0.0 <= mwu.predict({"x": -5.0}) <= 1.0
        assert 0.0 <= mwu.predict({"x": 5.0}) <= 1.0

    def test_min_weight_floor(self):
        mwu = MWUExperts(["a", "b"], eta=2.0, min_weight=0.05)
        # Extreme updates
        for _ in range(50):
            mwu.update({"a": 0.0, "b": 1.0}, outcome=0.0)
        # "b" is bad but shouldn't die completely
        assert mwu.weights["b"] >= 0.01  # At least close to floor after normalization


class TestConformalCalibrator:
    def test_not_calibrated_initially(self):
        cc = ConformalCalibrator(min_calibration=30)
        assert not cc.is_calibrated
        assert cc.calibration_size == 0

    def test_conservative_interval_before_calibration(self):
        cc = ConformalCalibrator(min_calibration=30)
        lower, upper = cc.predict_interval(0.5)
        # Before calibration: wide interval
        assert lower < 0.5
        assert upper > 0.5
        assert upper - lower >= 0.5  # At least 0.5 wide

    def test_calibration_reduces_interval(self):
        cc = ConformalCalibrator(min_calibration=10, alpha=0.10)
        # Add tight calibration points (predictions close to actuals)
        for i in range(50):
            predicted = 0.5
            actual = 0.5 + (i % 3 - 1) * 0.02  # ±0.02 noise
            cc.add_calibration_point(predicted, actual)

        assert cc.is_calibrated
        lower, upper = cc.predict_interval(0.5)
        # Should be tighter than the uncalibrated interval
        assert upper - lower < 0.5

    def test_miscoverage_widens_interval(self):
        cc = ConformalCalibrator(min_calibration=10, alpha=0.10, gamma=0.05)
        # Calibrate with tight residuals first
        for _ in range(20):
            cc.add_calibration_point(0.5, 0.5)

        _, upper_tight = cc.predict_interval(0.5)

        # Now add points where predictions are way off
        for _ in range(20):
            cc.add_calibration_point(0.5, 0.9)

        _, upper_wide = cc.predict_interval(0.5)
        assert upper_wide > upper_tight


class TestAdaptiveScorer:
    def test_ms_toolkit_protocol(self):
        scorer = AdaptiveScorer()
        assert scorer.name == "vaara_adaptive"
        result = scorer.evaluate({"tool_name": "data.read", "agent_id": "test"})
        assert "allowed" in result
        assert "action" in result
        assert "reason" in result
        assert "backend" in result
        assert result["backend"] == "vaara_adaptive"

    def test_low_risk_action_allowed(self):
        scorer = AdaptiveScorer(threshold_allow=0.5)
        result = scorer.evaluate({
            "tool_name": "data.read",
            "agent_id": "trusted",
            "base_risk_score": 0.1,
            "agent_confidence": 0.9,
        })
        assert result["allowed"] is True

    def test_high_risk_action_denied(self):
        scorer = AdaptiveScorer(threshold_deny=0.5)
        result = scorer.evaluate({
            "tool_name": "phy.safety_override",
            "agent_id": "unknown",
            "base_risk_score": 0.9,
            "agent_confidence": None,
        })
        # High base risk + unknown agent + no confidence → should be denied or escalated
        assert result["action"] in ("deny", "escalate")

    def test_sequence_detection(self):
        scorer = AdaptiveScorer(threshold_deny=0.8)
        # Build up a data exfiltration pattern
        scorer.evaluate({
            "tool_name": "data.read", "agent_id": "suspect",
            "base_risk_score": 0.1,
        })
        result = scorer.evaluate({
            "tool_name": "data.export", "agent_id": "suspect",
            "base_risk_score": 0.4,
        })
        # Sequence pattern should boost the risk
        raw = result.get("raw_result", {})
        assert raw.get("sequence_risk", 0) > 0

    def test_outcome_learning(self):
        scorer = AdaptiveScorer()
        initial_weights = dict(scorer.mwu_weights)

        # Simulate some actions with outcomes
        signals = {
            "taxonomy_base": 0.5,
            "agent_history": 0.3,
            "sequence_pattern": 0.0,
            "action_frequency": 0.0,
            "confidence_gap": 0.2,
        }
        scorer.record_outcome("agent-1", "test.tool", 0.5, 0.0, signals)
        scorer.record_outcome("agent-1", "test.tool", 0.5, 0.0, signals)

        assert scorer.mwu_update_count == 2
        # Weights should have shifted
        assert scorer.mwu_weights != initial_weights

    def test_status_snapshot(self):
        scorer = AdaptiveScorer()
        status = scorer.status()
        assert "calibrated" in status
        assert "mwu_weights" in status
        assert "thresholds" in status
        assert status["calibrated"] is False  # No data yet

    def test_agent_profile_builds(self):
        scorer = AdaptiveScorer()
        scorer.evaluate({
            "tool_name": "data.read", "agent_id": "agent-x",
            "base_risk_score": 0.1,
        })
        scorer.evaluate({
            "tool_name": "data.write", "agent_id": "agent-x",
            "base_risk_score": 0.3,
        })
        profile = scorer.get_agent_profile("agent-x")
        assert profile is not None
        assert profile.total_actions == 2

    def test_custom_sequence_pattern(self):
        custom = SequencePattern(
            "custom_danger", ("step1", "step2"), risk_boost=0.5, window_size=5,
        )
        scorer = AdaptiveScorer(sequence_patterns=[custom])
        scorer.evaluate({
            "tool_name": "step1", "agent_id": "a", "base_risk_score": 0.1,
        })
        result = scorer.evaluate({
            "tool_name": "step2", "agent_id": "a", "base_risk_score": 0.1,
        })
        raw = result.get("raw_result", {})
        assert raw.get("sequence_risk", 0) > 0

    def test_builtin_sequences_loaded(self):
        assert len(BUILTIN_SEQUENCES) >= 5
        names = {p.name for p in BUILTIN_SEQUENCES}
        assert "data_exfiltration" in names
        assert "financial_drain" in names
