"""SQLite persistence backend for the audit trail.

The in-memory trail is fast but volatile.  This backend writes every record
to SQLite as it arrives (via on_record callback) and can reconstruct the
full trail from disk.

Design principles:
- **WAL mode** for concurrent read/write (readers never block writers)
- **Append-only** — no UPDATE or DELETE, matching the immutability guarantee
- **Hash chain verified on load** — detects on-disk tampering
- **Regulatory domain indexed** — fast compliance queries by regulation
- **JSON data column** — flexible schema for action-specific fields

EU AI Act Article 12(2): Logging capabilities shall allow for the recording
of events relevant to identify situations that may result in the AI system
posing a risk.  SQLite's ACID guarantees that no event is silently lost.
"""

from __future__ import annotations

import json
import logging
import math
import sqlite3
import threading
import time
from pathlib import Path
from typing import Any, Optional

from vaara.audit.trail import AuditRecord, AuditTrail, EventType

logger = logging.getLogger(__name__)

SCHEMA_VERSION = 1


def _scrub_nonfinite(obj: Any) -> Any:
    # Strict JSON (RFC 8259) forbids NaN/Infinity tokens. Python's default
    # json.dumps emits them; Go encoding/json, Rust serde_json, strict Node
    # JSON.parse, and most JSON-RPC validators then reject the audit export
    # — regulator-side evidence becomes unreadable. Mirrors the Loop 34
    # mcp_server pattern and the Loop 35 _sanitize.json_safe guard, applied
    # here as a second line of defence for legacy records or direct
    # AuditRecord callers that bypass pipeline sanitisation.
    if isinstance(obj, float):
        return obj if math.isfinite(obj) else None
    if isinstance(obj, dict):
        return {k: _scrub_nonfinite(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_scrub_nonfinite(v) for v in obj]
    return obj


def _strict_json_dumps(obj: Any) -> str:
    return json.dumps(_scrub_nonfinite(obj), allow_nan=False, default=str)

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS audit_meta (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS audit_records (
    record_id     TEXT PRIMARY KEY,
    action_id     TEXT NOT NULL,
    event_type    TEXT NOT NULL,
    timestamp     REAL NOT NULL,
    agent_id      TEXT NOT NULL,
    tool_name     TEXT NOT NULL,
    data          TEXT NOT NULL DEFAULT '{}',
    regulatory    TEXT NOT NULL DEFAULT '[]',
    previous_hash TEXT NOT NULL DEFAULT '',
    record_hash   TEXT NOT NULL DEFAULT '',
    seq           INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_action_id   ON audit_records(action_id);
CREATE INDEX IF NOT EXISTS idx_agent_id    ON audit_records(agent_id);
CREATE INDEX IF NOT EXISTS idx_event_type  ON audit_records(event_type);
CREATE INDEX IF NOT EXISTS idx_timestamp   ON audit_records(timestamp);
CREATE INDEX IF NOT EXISTS idx_tool_name   ON audit_records(tool_name);
"""


class SQLiteAuditBackend:
    """Persistent audit trail backed by SQLite.

    Usage::

        backend = SQLiteAuditBackend("audit.db")
        trail = AuditTrail(on_record=backend.write_record)

        # On restart — reload the trail
        trail = backend.load_trail()

        # Compliance query — all DORA-relevant records
        records = backend.query_by_regulation("dora")

        # Export for external audit
        backend.export_jsonl(Path("audit_export.jsonl"))
    """

    def __init__(self, db_path: str | Path) -> None:
        self._db_path = Path(db_path)
        # check_same_thread=False lets us use this connection from any
        # thread (LangChain tool execution, web servers, async workers).
        # The Lock below serializes all access to the connection, which
        # is the SQLite python binding's thread-safety contract.
        self._conn = sqlite3.connect(
            str(self._db_path),
            isolation_level=None,  # Autocommit for WAL mode
            check_same_thread=False,
        )
        self._lock = threading.Lock()
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=NORMAL")
        self._conn.execute("PRAGMA foreign_keys=ON")
        self._init_schema()

    def _init_schema(self) -> None:
        """Create tables if they don't exist."""
        self._conn.executescript(SCHEMA_SQL)
        # Check/set schema version
        row = self._conn.execute(
            "SELECT value FROM audit_meta WHERE key='schema_version'"
        ).fetchone()
        if row is None:
            self._conn.execute(
                "INSERT INTO audit_meta (key, value) VALUES ('schema_version', ?)",
                (str(SCHEMA_VERSION),),
            )
        else:
            stored = int(row[0])
            if stored != SCHEMA_VERSION:
                raise RuntimeError(
                    f"Audit DB schema version mismatch: "
                    f"expected {SCHEMA_VERSION}, got {stored}"
                )

    def _get_max_seq(self) -> int:
        """Get the highest sequence number in the DB (diagnostic / tests)."""
        row = self._conn.execute(
            "SELECT COALESCE(MAX(seq), -1) FROM audit_records"
        ).fetchone()
        return row[0]

    # ── Write path ────────────────────────────────────────────────

    def write_record(self, record: AuditRecord) -> None:
        """Callback for AuditTrail.on_record — persists a single record.

        This is called synchronously for every audit event.  SQLite in WAL
        mode handles this efficiently. Serialized via self._lock so the
        underlying connection stays thread-safe.

        Seq is computed atomically inside the INSERT via subquery rather
        than from a cached in-process counter. Two processes sharing the
        same audit DB (e.g., pipeline + migration tool, MCP server +
        load_trail reader, multi-worker gunicorn) would otherwise each
        cache MAX(seq)+1 on open and then issue writes with colliding
        seq values, breaking ORDER BY seq ASC reconstruction in
        load_trail and the hash-chain integrity check below it. SQLite
        serializes writers at the transaction boundary, so the subquery
        reads MAX(seq) at the same point the INSERT takes effect.
        """
        with self._lock:
            self._conn.execute(
                """INSERT INTO audit_records
                   (record_id, action_id, event_type, timestamp, agent_id,
                    tool_name, data, regulatory, previous_hash, record_hash, seq)
                   VALUES (
                     ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                     COALESCE((SELECT MAX(seq) FROM audit_records), -1) + 1
                   )""",
                (
                    record.record_id,
                    record.action_id,
                    record.event_type.value,
                    record.timestamp,
                    record.agent_id,
                    record.tool_name,
                    _strict_json_dumps(record.data),
                    _strict_json_dumps(record.regulatory_articles),
                    record.previous_hash,
                    record.record_hash,
                ),
            )

    # ── Read path ─────────────────────────────────────────────────

    def load_trail(self, strict: bool = False) -> AuditTrail:
        """Reconstruct a full AuditTrail from the database.

        Verifies the hash chain on load. If the chain is broken, a log
        ERROR is emitted; with ``strict=True`` a ``RuntimeError`` is
        raised instead so callers that cannot safely proceed on a
        compromised trail (e.g., regulator-facing inspection, forensic
        export) fail loud rather than silently consuming tampered
        evidence.

        A single row with a corrupt ``data``/``regulatory`` JSON column
        no longer DoSes the entire load — that row is logged and loaded
        with empty dicts; the subsequent hash-chain verification will
        flag it via hash mismatch so corruption remains detectable.
        """
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM audit_records ORDER BY seq ASC"
            ).fetchall()

        trail = AuditTrail(on_record=self.write_record)

        corrupt_rows = 0
        for row in rows:
            try:
                record = self._row_to_record(row)
            except (json.JSONDecodeError, ValueError, KeyError) as exc:
                # Single-row corruption must not destroy the rest of the
                # audit reload. Reconstruct a "skeleton" record with empty
                # dicts and the raw hashes preserved; verify_chain() will
                # then flag the row via hash mismatch (original data was
                # part of the hash input), so corruption stays visible.
                corrupt_rows += 1
                logger.error(
                    "load_trail: corrupt record row seq=%s record_id=%s (%s: %s) — "
                    "loading skeleton; hash-chain verification will flag it",
                    row[10], row[0], type(exc).__name__, exc,
                )
                record = AuditRecord(
                    record_id=row[0],
                    action_id=row[1],
                    event_type=(
                        EventType(row[2]) if row[2] in EventType._value2member_map_
                        else EventType.POLICY_OVERRIDE
                    ),
                    timestamp=row[3] if isinstance(row[3], (int, float)) else 0.0,
                    agent_id=row[4] or "",
                    tool_name=row[5] or "",
                    data={"_corrupt": True, "_error": str(exc)},
                    regulatory_articles=[],
                    previous_hash=row[8] or "",
                    record_hash=row[9] or "",
                )
            # Inject directly into the trail (bypass on_record to avoid re-write)
            trail._records.append(record)
            trail._by_action[record.action_id].append(record)
            trail._last_hash = record.record_hash

        chain_error = trail.verify_chain()
        if chain_error:
            logger.error("AUDIT CHAIN INTEGRITY FAILURE: %s", chain_error)
            if strict:
                raise RuntimeError(
                    f"load_trail(strict=True) refused to return compromised "
                    f"trail: {chain_error}"
                )

        logger.info(
            "Loaded %d audit records from %s (corrupt_rows=%d)",
            len(rows), self._db_path, corrupt_rows,
        )
        return trail

    def count(self) -> int:
        """Total records in the database."""
        with self._lock:
            row = self._conn.execute(
                "SELECT COUNT(*) FROM audit_records"
            ).fetchone()
        return row[0]

    def query_by_action(self, action_id: str) -> list[AuditRecord]:
        """Get all records for a specific action."""
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM audit_records WHERE action_id=? ORDER BY seq ASC",
                (action_id,),
            ).fetchall()
        return [self._row_to_record(r) for r in rows]

    def query_by_agent(
        self, agent_id: str, limit: int = 100
    ) -> list[AuditRecord]:
        """Get recent records for an agent."""
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM audit_records WHERE agent_id=? "
                "ORDER BY seq DESC LIMIT ?",
                (agent_id, limit),
            ).fetchall()
        return [self._row_to_record(r) for r in reversed(rows)]

    def query_by_event_type(
        self, event_type: EventType, limit: int = 100
    ) -> list[AuditRecord]:
        """Get recent records of a specific event type."""
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM audit_records WHERE event_type=? "
                "ORDER BY seq DESC LIMIT ?",
                (event_type.value, limit),
            ).fetchall()
        return [self._row_to_record(r) for r in reversed(rows)]

    def query_by_regulation(
        self, domain: str, limit: int = 500
    ) -> list[AuditRecord]:
        """Get records relevant to a regulatory domain.

        Uses JSON contains matching on the regulatory column.
        """
        # Escape LIKE metacharacters in the caller-supplied domain.
        # Without this, domain='%' matches every row, and '_' acts as a
        # single-char wildcard — so "eu_ai_act" (a real enum value)
        # would match "euXaiYact" etc. ESCAPE '\\' lets us quote them.
        escaped = (
            domain.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
        )
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM audit_records WHERE regulatory LIKE ? ESCAPE '\\' "
                "ORDER BY seq DESC LIMIT ?",
                (f'%"{escaped}"%', limit),
            ).fetchall()
        return [self._row_to_record(r) for r in reversed(rows)]

    def query_time_range(
        self,
        start_ts: float,
        end_ts: Optional[float] = None,
        limit: int = 1000,
    ) -> list[AuditRecord]:
        """Get records within a time range."""
        if end_ts is None:
            end_ts = time.time()
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM audit_records "
                "WHERE timestamp >= ? AND timestamp <= ? "
                "ORDER BY seq ASC LIMIT ?",
                (start_ts, end_ts, limit),
            ).fetchall()
        return [self._row_to_record(r) for r in rows]

    def query_blocked(self, limit: int = 50) -> list[AuditRecord]:
        """Get recently blocked actions."""
        return self.query_by_event_type(EventType.ACTION_BLOCKED, limit)

    # ── Statistics ────────────────────────────────────────────────

    def stats(self) -> dict:
        """Database statistics for dashboards."""
        with self._lock:
            rows = self._conn.execute(
                "SELECT event_type, COUNT(*) FROM audit_records GROUP BY event_type"
            ).fetchall()
            agent_rows = self._conn.execute(
                "SELECT COUNT(DISTINCT agent_id) FROM audit_records"
            ).fetchone()
            time_rows = self._conn.execute(
                "SELECT MIN(timestamp), MAX(timestamp) FROM audit_records"
            ).fetchone()
        by_type = {row[0]: row[1] for row in rows}

        return {
            "total_records": self.count(),
            "by_event_type": by_type,
            "unique_agents": agent_rows[0],
            "time_range": {
                "earliest": time_rows[0],
                "latest": time_rows[1],
            },
            "db_path": str(self._db_path),
            "db_size_bytes": self._db_path.stat().st_size if self._db_path.exists() else 0,
        }

    # ── Export ────────────────────────────────────────────────────

    def export_jsonl(self, path: Path, limit: int = 0) -> int:
        """Export records as JSON Lines.  Returns count exported."""
        query = "SELECT * FROM audit_records ORDER BY seq ASC"
        if limit > 0:
            query += f" LIMIT {limit}"
        with self._lock:
            rows = self._conn.execute(query).fetchall()
        # encoding="utf-8" is explicit — audit exports routinely carry
        # non-ASCII agent names, reasons, and justifications, and the
        # platform default (esp. non-POSIX locales) is not guaranteed UTF-8.
        with open(path, "w", encoding="utf-8") as f:
            for row in rows:
                record = self._row_to_record(row)
                f.write(_strict_json_dumps(record.to_dict()) + "\n")
        return len(rows)

    # ── Internal ──────────────────────────────────────────────────

    @staticmethod
    def _row_to_record(row: tuple) -> AuditRecord:
        """Convert a database row to an AuditRecord."""
        return AuditRecord(
            record_id=row[0],
            action_id=row[1],
            event_type=EventType(row[2]),
            timestamp=row[3],
            agent_id=row[4],
            tool_name=row[5],
            data=json.loads(row[6]),
            regulatory_articles=json.loads(row[7]),
            previous_hash=row[8],
            record_hash=row[9],
        )

    def close(self) -> None:
        """Close the database connection."""
        with self._lock:
            self._conn.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
