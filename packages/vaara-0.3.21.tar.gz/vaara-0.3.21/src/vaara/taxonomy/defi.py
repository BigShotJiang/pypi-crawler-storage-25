"""DeFi-specific action taxonomy and dangerous sequence patterns.

Extends the base taxonomy (§2) with protocol-level action types that capture
the unique risk properties of decentralized finance operations:

- **Atomicity**: DeFi actions can be bundled into atomic transactions.
  A flash loan + swap + repay is one atomic tx but three logical actions.
  Atomicity enables risk that doesn't exist in TradFi — entire attack
  sequences complete or revert, making partial-execution safeguards useless.

- **Composability**: DeFi protocols compose — a Morpho vault calls Aave
  which calls Chainlink which calls Uniswap.  Each protocol is safe in
  isolation, but the *composition* creates emergent risk surfaces.
  This is precisely the compositional safety problem from §1.

- **MEV vulnerability**: Actions that touch AMM state are vulnerable to
  front-running, back-running, and sandwich attacks.  The risk is not in
  the agent's action but in what *other agents* do around it.

- **Irreversibility with finality**: On-chain actions are irreversible
  after block confirmation.  Unlike TradFi where settlement takes days
  and chargebacks exist, DeFi finality is absolute.

Protocol types:

    DEX     — Decentralized exchanges (Uniswap, Aerodrome, Curve)
    LENDING — Lending/borrowing (Aave, Morpho, Compound)
    BRIDGE  — Cross-chain bridges (Across, Stargate, LayerZero)
    VAULT   — Yield vaults and strategies (Morpho curators, Yearn)
    ORACLE  — Price feeds and data providers (Chainlink, Pyth, API3)
    GOV     — On-chain governance (Governor, Snapshot, Tally)
    NFT     — Non-fungible token operations
    PERP    — Perpetual futures and derivatives (GMX, dYdX, Synthetix)

References:
    - Werner et al. (2022), "SoK: Decentralized Finance (DeFi)"
    - Daian et al. (2020), "Flash Boys 2.0: Frontrunning in Decentralized Exchanges"
    - Qin et al. (2022), "Quantifying Blockchain Extractable Value"
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from vaara.taxonomy.actions import (
    ActionCategory,
    ActionRegistry,
    ActionType,
    BlastRadius,
    RegulatoryDomain,
    Reversibility,
    UrgencyClass,
)
from vaara.scorer.adaptive import SequencePattern


# ── DeFi protocol types ──────────────────────────────────────────────────

class ProtocolType(str, Enum):
    """DeFi protocol categories — each has distinct risk profiles."""
    DEX = "dex"
    LENDING = "lending"
    BRIDGE = "bridge"
    VAULT = "vault"
    ORACLE = "oracle"
    GOVERNANCE = "governance"
    NFT = "nft"
    PERP = "perpetuals"
    STAKING = "staking"
    UNKNOWN = "unknown"


class MEVVulnerability(str, Enum):
    """How vulnerable an action is to Miner/Maximal Extractable Value."""
    NONE = "none"               # Read-only or non-state-changing
    LOW = "low"                 # Minor sandwich potential
    MEDIUM = "medium"           # Standard AMM swap — sandwichable
    HIGH = "high"               # Large swap, oracle update — high MEV
    CRITICAL = "critical"       # Flash loan, liquidation — MEV bots compete


class Atomicity(str, Enum):
    """Whether the action is part of an atomic transaction."""
    SINGLE = "single"           # Standalone transaction
    BUNDLED = "bundled"         # Part of a multicall / batch
    FLASH = "flash"             # Part of a flash loan (must repay in same tx)
    CROSS_CHAIN = "cross_chain" # Spans multiple chains (NOT atomic)


# ── DeFi action type extension ───────────────────────────────────────────

@dataclass(frozen=True)
class DeFiActionType(ActionType):
    """Action type with DeFi-specific metadata.

    Extends the base ActionType with protocol, MEV, atomicity, and
    TVL exposure annotations.  The base_risk_score is augmented with
    DeFi-specific risk factors.

    The extended risk formula (§2.2 + DeFi extension):

        β_defi(τ) = min(1, β(τ) + s_mev(mev) + s_atom(atom)) / Z_defi

    where:
        s_mev(none) = 0, s_mev(low) = 0.05, s_mev(medium) = 0.1,
        s_mev(high) = 0.2, s_mev(critical) = 0.3

        s_atom(single) = 0, s_atom(bundled) = 0.05,
        s_atom(flash) = 0.2, s_atom(cross_chain) = 0.15

    Z_defi = 1.0 (additive to base, no rescaling — DeFi-specific
    risk factors ALWAYS increase the floor, never decrease it).
    """
    protocol_type: ProtocolType = ProtocolType.UNKNOWN
    mev_vulnerability: MEVVulnerability = MEVVulnerability.NONE
    atomicity: Atomicity = Atomicity.SINGLE
    tvl_exposure: Optional[str] = None  # Human-readable TVL at risk

    @property
    def base_risk_score(self) -> float:
        """Base risk with DeFi-specific additions.

        DeFi factors are additive — they never lower the base score.
        """
        base = super().base_risk_score

        mev_score = {
            MEVVulnerability.NONE: 0.0,
            MEVVulnerability.LOW: 0.05,
            MEVVulnerability.MEDIUM: 0.1,
            MEVVulnerability.HIGH: 0.2,
            MEVVulnerability.CRITICAL: 0.3,
        }[self.mev_vulnerability]

        atom_score = {
            Atomicity.SINGLE: 0.0,
            Atomicity.BUNDLED: 0.05,
            Atomicity.FLASH: 0.2,
            Atomicity.CROSS_CHAIN: 0.15,
        }[self.atomicity]

        return min(1.0, base + mev_score + atom_score)


# ── Built-in DeFi action types ──────────────────────────────────────────

DEFI_ACTIONS: list[DeFiActionType] = [
    # ── DEX Operations ──
    DeFiActionType(
        name="defi.swap",
        category=ActionCategory.FINANCIAL,
        reversibility=Reversibility.IRREVERSIBLE,
        blast_radius=BlastRadius.SHARED,
        urgency=UrgencyClass.IMMEDIATE,
        regulatory_domains=frozenset({RegulatoryDomain.MIFID2, RegulatoryDomain.DORA}),
        description="Token swap on DEX/AMM",
        protocol_type=ProtocolType.DEX,
        mev_vulnerability=MEVVulnerability.MEDIUM,
        atomicity=Atomicity.SINGLE,
    ),
    DeFiActionType(
        name="defi.swap_exact_output",
        category=ActionCategory.FINANCIAL,
        reversibility=Reversibility.IRREVERSIBLE,
        blast_radius=BlastRadius.SHARED,
        urgency=UrgencyClass.IMMEDIATE,
        regulatory_domains=frozenset({RegulatoryDomain.MIFID2, RegulatoryDomain.DORA}),
        description="Exact output swap — higher slippage risk",
        protocol_type=ProtocolType.DEX,
        mev_vulnerability=MEVVulnerability.HIGH,
        atomicity=Atomicity.SINGLE,
    ),
    DeFiActionType(
        name="defi.add_liquidity",
        category=ActionCategory.FINANCIAL,
        reversibility=Reversibility.PARTIALLY,
        blast_radius=BlastRadius.SHARED,
        urgency=UrgencyClass.TIMELY,
        regulatory_domains=frozenset({RegulatoryDomain.MIFID2}),
        description="Add liquidity to AMM pool",
        protocol_type=ProtocolType.DEX,
        mev_vulnerability=MEVVulnerability.LOW,
        atomicity=Atomicity.SINGLE,
    ),
    DeFiActionType(
        name="defi.remove_liquidity",
        category=ActionCategory.FINANCIAL,
        reversibility=Reversibility.IRREVERSIBLE,
        blast_radius=BlastRadius.SHARED,
        urgency=UrgencyClass.TIMELY,
        regulatory_domains=frozenset({RegulatoryDomain.MIFID2}),
        description="Remove liquidity from AMM pool",
        protocol_type=ProtocolType.DEX,
        mev_vulnerability=MEVVulnerability.MEDIUM,
        atomicity=Atomicity.SINGLE,
    ),

    # ── Lending Operations ──
    DeFiActionType(
        name="defi.supply_collateral",
        category=ActionCategory.FINANCIAL,
        reversibility=Reversibility.PARTIALLY,
        blast_radius=BlastRadius.SHARED,
        urgency=UrgencyClass.DEFERRABLE,
        regulatory_domains=frozenset({RegulatoryDomain.MIFID2, RegulatoryDomain.DORA}),
        description="Supply collateral to lending protocol",
        protocol_type=ProtocolType.LENDING,
        mev_vulnerability=MEVVulnerability.NONE,
        atomicity=Atomicity.SINGLE,
    ),
    DeFiActionType(
        name="defi.borrow",
        category=ActionCategory.FINANCIAL,
        reversibility=Reversibility.PARTIALLY,
        blast_radius=BlastRadius.SHARED,
        urgency=UrgencyClass.TIMELY,
        regulatory_domains=frozenset({RegulatoryDomain.MIFID2, RegulatoryDomain.DORA}),
        description="Borrow against collateral",
        protocol_type=ProtocolType.LENDING,
        mev_vulnerability=MEVVulnerability.LOW,
        atomicity=Atomicity.SINGLE,
    ),
    DeFiActionType(
        name="defi.repay",
        category=ActionCategory.FINANCIAL,
        reversibility=Reversibility.IRREVERSIBLE,
        blast_radius=BlastRadius.LOCAL,
        urgency=UrgencyClass.TIMELY,
        regulatory_domains=frozenset({RegulatoryDomain.DORA}),
        description="Repay borrowed amount",
        protocol_type=ProtocolType.LENDING,
        mev_vulnerability=MEVVulnerability.NONE,
        atomicity=Atomicity.SINGLE,
    ),
    DeFiActionType(
        name="defi.withdraw_collateral",
        category=ActionCategory.FINANCIAL,
        reversibility=Reversibility.IRREVERSIBLE,
        blast_radius=BlastRadius.SHARED,
        urgency=UrgencyClass.TIMELY,
        regulatory_domains=frozenset({RegulatoryDomain.MIFID2, RegulatoryDomain.DORA}),
        description="Withdraw collateral — may trigger liquidation if undercollateralized",
        protocol_type=ProtocolType.LENDING,
        mev_vulnerability=MEVVulnerability.MEDIUM,
        atomicity=Atomicity.SINGLE,
    ),
    DeFiActionType(
        name="defi.liquidate",
        category=ActionCategory.FINANCIAL,
        reversibility=Reversibility.IRREVERSIBLE,
        blast_radius=BlastRadius.SHARED,
        urgency=UrgencyClass.IRREVOCABLE,
        regulatory_domains=frozenset({RegulatoryDomain.MIFID2, RegulatoryDomain.DORA}),
        description="Liquidate undercollateralized position",
        protocol_type=ProtocolType.LENDING,
        mev_vulnerability=MEVVulnerability.CRITICAL,
        atomicity=Atomicity.SINGLE,
    ),

    # ── Flash Loan Operations ──
    DeFiActionType(
        name="defi.flash_loan",
        category=ActionCategory.FINANCIAL,
        reversibility=Reversibility.FULLY,  # Reverts if not repaid
        blast_radius=BlastRadius.GLOBAL,
        urgency=UrgencyClass.IRREVOCABLE,
        regulatory_domains=frozenset({RegulatoryDomain.MIFID2, RegulatoryDomain.DORA}),
        description="Initiate flash loan — atomic borrow+repay in single tx",
        protocol_type=ProtocolType.LENDING,
        mev_vulnerability=MEVVulnerability.CRITICAL,
        atomicity=Atomicity.FLASH,
        tvl_exposure="Potentially entire pool TVL",
    ),

    # ── Vault Operations ──
    DeFiActionType(
        name="defi.vault_deposit",
        category=ActionCategory.FINANCIAL,
        reversibility=Reversibility.PARTIALLY,
        blast_radius=BlastRadius.SHARED,
        urgency=UrgencyClass.DEFERRABLE,
        regulatory_domains=frozenset({RegulatoryDomain.MIFID2, RegulatoryDomain.EU_AI_ACT}),
        description="Deposit assets into yield vault",
        protocol_type=ProtocolType.VAULT,
        mev_vulnerability=MEVVulnerability.LOW,
        atomicity=Atomicity.SINGLE,
    ),
    DeFiActionType(
        name="defi.vault_withdraw",
        category=ActionCategory.FINANCIAL,
        reversibility=Reversibility.IRREVERSIBLE,
        blast_radius=BlastRadius.SHARED,
        urgency=UrgencyClass.TIMELY,
        regulatory_domains=frozenset({RegulatoryDomain.MIFID2, RegulatoryDomain.EU_AI_ACT}),
        description="Withdraw assets from yield vault",
        protocol_type=ProtocolType.VAULT,
        mev_vulnerability=MEVVulnerability.LOW,
        atomicity=Atomicity.SINGLE,
    ),
    DeFiActionType(
        name="defi.vault_rebalance",
        category=ActionCategory.FINANCIAL,
        reversibility=Reversibility.PARTIALLY,
        blast_radius=BlastRadius.SHARED,
        urgency=UrgencyClass.TIMELY,
        regulatory_domains=frozenset({RegulatoryDomain.MIFID2, RegulatoryDomain.EU_AI_ACT}),
        description="Rebalance vault allocation across markets",
        protocol_type=ProtocolType.VAULT,
        mev_vulnerability=MEVVulnerability.MEDIUM,
        atomicity=Atomicity.SINGLE,
    ),
    DeFiActionType(
        name="defi.vault_set_strategy",
        category=ActionCategory.GOVERNANCE,
        reversibility=Reversibility.PARTIALLY,
        blast_radius=BlastRadius.SHARED,
        urgency=UrgencyClass.DEFERRABLE,
        regulatory_domains=frozenset({RegulatoryDomain.EU_AI_ACT}),
        description="Change vault strategy or risk parameters",
        protocol_type=ProtocolType.VAULT,
        mev_vulnerability=MEVVulnerability.NONE,
        atomicity=Atomicity.SINGLE,
    ),

    # ── Bridge Operations ──
    DeFiActionType(
        name="defi.bridge_deposit",
        category=ActionCategory.FINANCIAL,
        reversibility=Reversibility.IRREVERSIBLE,
        blast_radius=BlastRadius.GLOBAL,
        urgency=UrgencyClass.IRREVOCABLE,
        regulatory_domains=frozenset({RegulatoryDomain.MIFID2, RegulatoryDomain.DORA}),
        description="Deposit to cross-chain bridge — funds leave source chain",
        protocol_type=ProtocolType.BRIDGE,
        mev_vulnerability=MEVVulnerability.LOW,
        atomicity=Atomicity.CROSS_CHAIN,
    ),
    DeFiActionType(
        name="defi.bridge_withdraw",
        category=ActionCategory.FINANCIAL,
        reversibility=Reversibility.IRREVERSIBLE,
        blast_radius=BlastRadius.GLOBAL,
        urgency=UrgencyClass.IRREVOCABLE,
        regulatory_domains=frozenset({RegulatoryDomain.MIFID2, RegulatoryDomain.DORA}),
        description="Claim from cross-chain bridge on destination chain",
        protocol_type=ProtocolType.BRIDGE,
        mev_vulnerability=MEVVulnerability.MEDIUM,
        atomicity=Atomicity.CROSS_CHAIN,
    ),

    # ── Oracle Operations ──
    DeFiActionType(
        name="defi.oracle_update",
        category=ActionCategory.DATA,
        reversibility=Reversibility.IRREVERSIBLE,
        blast_radius=BlastRadius.GLOBAL,
        urgency=UrgencyClass.IMMEDIATE,
        regulatory_domains=frozenset({RegulatoryDomain.DORA, RegulatoryDomain.EU_AI_ACT}),
        description="Push price update to on-chain oracle",
        protocol_type=ProtocolType.ORACLE,
        mev_vulnerability=MEVVulnerability.HIGH,
        atomicity=Atomicity.SINGLE,
    ),

    # ── Governance Operations ──
    DeFiActionType(
        name="defi.governance_propose",
        category=ActionCategory.GOVERNANCE,
        reversibility=Reversibility.PARTIALLY,
        blast_radius=BlastRadius.GLOBAL,
        urgency=UrgencyClass.DEFERRABLE,
        regulatory_domains=frozenset({RegulatoryDomain.EU_AI_ACT}),
        description="Create on-chain governance proposal",
        protocol_type=ProtocolType.GOVERNANCE,
        mev_vulnerability=MEVVulnerability.NONE,
        atomicity=Atomicity.SINGLE,
    ),
    DeFiActionType(
        name="defi.governance_vote",
        category=ActionCategory.GOVERNANCE,
        reversibility=Reversibility.IRREVERSIBLE,
        blast_radius=BlastRadius.GLOBAL,
        urgency=UrgencyClass.TIMELY,
        regulatory_domains=frozenset({RegulatoryDomain.EU_AI_ACT}),
        description="Cast governance vote",
        protocol_type=ProtocolType.GOVERNANCE,
        mev_vulnerability=MEVVulnerability.NONE,
        atomicity=Atomicity.SINGLE,
    ),
    DeFiActionType(
        name="defi.governance_execute",
        category=ActionCategory.GOVERNANCE,
        reversibility=Reversibility.IRREVERSIBLE,
        blast_radius=BlastRadius.GLOBAL,
        urgency=UrgencyClass.IRREVOCABLE,
        regulatory_domains=frozenset({RegulatoryDomain.EU_AI_ACT}),
        description="Execute passed governance proposal — irreversible state change",
        protocol_type=ProtocolType.GOVERNANCE,
        mev_vulnerability=MEVVulnerability.HIGH,
        atomicity=Atomicity.SINGLE,
    ),

    # ── Token Operations ──
    DeFiActionType(
        name="defi.approve_unlimited",
        category=ActionCategory.FINANCIAL,
        reversibility=Reversibility.PARTIALLY,
        blast_radius=BlastRadius.SHARED,
        urgency=UrgencyClass.DEFERRABLE,
        regulatory_domains=frozenset({RegulatoryDomain.MIFID2}),
        description="Approve unlimited token spending — persistent attack surface",
        protocol_type=ProtocolType.UNKNOWN,
        mev_vulnerability=MEVVulnerability.NONE,
        atomicity=Atomicity.SINGLE,
    ),
    DeFiActionType(
        name="defi.approve_exact",
        category=ActionCategory.FINANCIAL,
        reversibility=Reversibility.PARTIALLY,
        blast_radius=BlastRadius.LOCAL,
        urgency=UrgencyClass.DEFERRABLE,
        regulatory_domains=frozenset({RegulatoryDomain.MIFID2}),
        description="Approve exact token amount — bounded attack surface",
        protocol_type=ProtocolType.UNKNOWN,
        mev_vulnerability=MEVVulnerability.NONE,
        atomicity=Atomicity.SINGLE,
    ),

    # ── Perpetuals / Derivatives ──
    DeFiActionType(
        name="defi.perp_open_position",
        category=ActionCategory.FINANCIAL,
        reversibility=Reversibility.PARTIALLY,
        blast_radius=BlastRadius.SHARED,
        urgency=UrgencyClass.IMMEDIATE,
        regulatory_domains=frozenset({RegulatoryDomain.MIFID2, RegulatoryDomain.DORA}),
        description="Open leveraged perpetual position",
        protocol_type=ProtocolType.PERP,
        mev_vulnerability=MEVVulnerability.HIGH,
        atomicity=Atomicity.SINGLE,
    ),
    DeFiActionType(
        name="defi.perp_close_position",
        category=ActionCategory.FINANCIAL,
        reversibility=Reversibility.IRREVERSIBLE,
        blast_radius=BlastRadius.SHARED,
        urgency=UrgencyClass.IMMEDIATE,
        regulatory_domains=frozenset({RegulatoryDomain.MIFID2, RegulatoryDomain.DORA}),
        description="Close perpetual position",
        protocol_type=ProtocolType.PERP,
        mev_vulnerability=MEVVulnerability.HIGH,
        atomicity=Atomicity.SINGLE,
    ),
    DeFiActionType(
        name="defi.perp_update_margin",
        category=ActionCategory.FINANCIAL,
        reversibility=Reversibility.PARTIALLY,
        blast_radius=BlastRadius.LOCAL,
        urgency=UrgencyClass.TIMELY,
        regulatory_domains=frozenset({RegulatoryDomain.MIFID2}),
        description="Add or remove margin from perpetual position",
        protocol_type=ProtocolType.PERP,
        mev_vulnerability=MEVVulnerability.LOW,
        atomicity=Atomicity.SINGLE,
    ),

    # ── Contract Deployment ──
    DeFiActionType(
        name="defi.deploy_contract",
        category=ActionCategory.INFRASTRUCTURE,
        reversibility=Reversibility.IRREVERSIBLE,
        blast_radius=BlastRadius.GLOBAL,
        urgency=UrgencyClass.DEFERRABLE,
        regulatory_domains=frozenset({RegulatoryDomain.EU_AI_ACT, RegulatoryDomain.NIS2}),
        description="Deploy smart contract to blockchain",
        protocol_type=ProtocolType.UNKNOWN,
        mev_vulnerability=MEVVulnerability.LOW,
        atomicity=Atomicity.SINGLE,
    ),
]


# ── DeFi-specific dangerous sequences ───────────────────────────────────
#
# These patterns encode known DeFi attack vectors as ordered subsequences.
# Unlike general sequences (§6), DeFi sequences often exploit *atomicity*:
# the entire attack happens in one transaction, making interception harder.
#
# Our defense: score the INTENT (the sequence of logical actions the agent
# requests) rather than waiting for on-chain finality.  If an agent requests
# flash_loan followed by multiple swaps, that's a detectable pattern
# BEFORE the transaction is built.

DEFI_SEQUENCES: list[SequencePattern] = [
    # ── Flash Loan Attack Patterns ──
    SequencePattern(
        name="flash_loan_price_manipulation",
        actions=("defi.flash_loan", "defi.swap", "defi.swap"),
        risk_boost=0.7,
        window_size=6,
        description=(
            "Flash loan → swap → swap: classic price manipulation pattern. "
            "The first swap moves the price, the second profits from the move, "
            "and the flash loan repayment closes the loop atomically."
        ),
    ),
    SequencePattern(
        name="flash_loan_oracle_exploit",
        actions=("defi.flash_loan", "defi.swap", "defi.oracle_update"),
        risk_boost=0.8,
        window_size=6,
        description=(
            "Flash loan → swap → oracle update: oracle manipulation attack. "
            "Moves pool price to distort spot-based oracle, then exploits "
            "protocols relying on the manipulated price."
        ),
    ),
    SequencePattern(
        name="flash_loan_liquidation",
        actions=("defi.flash_loan", "defi.swap", "defi.liquidate"),
        risk_boost=0.7,
        window_size=6,
        description=(
            "Flash loan → swap → liquidate: forced liquidation attack. "
            "Move price to make a position undercollateralized, then "
            "liquidate it for the bonus."
        ),
    ),

    # ── Rug Pull / Exit Scam Patterns ──
    SequencePattern(
        name="rug_pull_liquidity",
        actions=("defi.add_liquidity", "defi.remove_liquidity"),
        risk_boost=0.4,
        window_size=4,
        description=(
            "Add then quickly remove liquidity — possible rug pull or "
            "JIT liquidity (just-in-time provision for MEV extraction)."
        ),
    ),
    SequencePattern(
        name="rug_pull_full",
        actions=("defi.deploy_contract", "defi.add_liquidity", "defi.remove_liquidity"),
        risk_boost=0.8,
        window_size=10,
        description=(
            "Deploy → add liquidity → remove liquidity: classic rug pull. "
            "Deploy token, create pool, attract deposits, drain."
        ),
    ),

    # ── Governance Attack Patterns ──
    SequencePattern(
        name="governance_flash_vote",
        actions=("defi.flash_loan", "defi.governance_vote", "defi.governance_execute"),
        risk_boost=0.9,
        window_size=8,
        description=(
            "Flash loan → vote → execute: flash governance attack. "
            "Borrow governance tokens, pass a proposal, execute it, "
            "return tokens. Bypasses intended governance process."
        ),
    ),
    SequencePattern(
        name="governance_rapid_execution",
        actions=("defi.governance_propose", "defi.governance_vote", "defi.governance_execute"),
        risk_boost=0.6,
        window_size=10,
        description=(
            "Propose → vote → execute in quick succession: governance capture. "
            "Normal governance has time delays between these steps."
        ),
    ),

    # ── Bridge Attack Patterns ──
    SequencePattern(
        name="bridge_drain",
        actions=("defi.bridge_deposit", "defi.bridge_withdraw", "defi.bridge_withdraw"),
        risk_boost=0.8,
        window_size=8,
        description=(
            "Deposit → withdraw → withdraw: double-claim exploit. "
            "Attempt to claim bridge funds multiple times."
        ),
    ),
    SequencePattern(
        name="cross_chain_arb_attack",
        actions=("defi.flash_loan", "defi.bridge_deposit", "defi.swap"),
        risk_boost=0.6,
        window_size=8,
        description=(
            "Flash loan → bridge → swap: cross-chain MEV or arbitrage "
            "that exploits bridge latency for price manipulation."
        ),
    ),

    # ── Vault Manipulation ──
    SequencePattern(
        name="vault_donation_attack",
        actions=("defi.vault_deposit", "defi.swap", "defi.vault_withdraw"),
        risk_boost=0.6,
        window_size=6,
        description=(
            "Deposit → swap → withdraw: vault share manipulation "
            "(donation/inflation attack on ERC-4626 vaults). "
            "See: ERC-4626 first-depositor vulnerability."
        ),
    ),
    SequencePattern(
        name="vault_strategy_drain",
        actions=("defi.vault_set_strategy", "defi.vault_withdraw"),
        risk_boost=0.5,
        window_size=4,
        description=(
            "Change strategy → withdraw: possible strategy manipulation "
            "to extract value during rebalance window."
        ),
    ),
    SequencePattern(
        name="rapid_vault_rebalance",
        actions=("defi.vault_rebalance", "defi.vault_rebalance", "defi.vault_rebalance"),
        risk_boost=0.4,
        window_size=6,
        description=(
            "Rapid successive rebalances — wash trading or market "
            "manipulation through repeated allocation changes."
        ),
    ),

    # ── Approval Exploitation ──
    SequencePattern(
        name="unlimited_approval_drain",
        actions=("defi.approve_unlimited", "defi.swap", "defi.swap"),
        risk_boost=0.5,
        window_size=6,
        description=(
            "Unlimited approval → repeated swaps: exploiting persistent "
            "approval to drain tokens across multiple transactions."
        ),
    ),

    # ── Oracle Manipulation ──
    SequencePattern(
        name="oracle_sandwich",
        actions=("defi.oracle_update", "defi.swap", "defi.oracle_update"),
        risk_boost=0.7,
        window_size=6,
        description=(
            "Oracle update → swap → oracle update: sandwich the oracle. "
            "Set a distorted price, trade on it, restore the price."
        ),
    ),

    # ── Lending Cascade ──
    SequencePattern(
        name="recursive_borrowing",
        actions=("defi.supply_collateral", "defi.borrow", "defi.supply_collateral", "defi.borrow"),
        risk_boost=0.5,
        window_size=8,
        description=(
            "Supply → borrow → supply → borrow: recursive leverage. "
            "Each cycle increases position size and liquidation risk."
        ),
    ),
    SequencePattern(
        name="collateral_withdrawal_under_debt",
        actions=("defi.borrow", "defi.withdraw_collateral"),
        risk_boost=0.6,
        window_size=4,
        description=(
            "Borrow → withdraw collateral: attempting to remove collateral "
            "while debt is outstanding — potential self-liquidation or exploit."
        ),
    ),
]


# ── Registry integration ─────────────────────────────────────────────────

def register_defi_actions(registry: ActionRegistry) -> None:
    """Register all DeFi action types with an existing registry.

    Also maps common tool name patterns so that DeFi tools are
    auto-classified even without explicit mapping.
    """
    for action_type in DEFI_ACTIONS:
        registry.register(action_type)
        # Auto-map: the action name itself is the tool name pattern
        registry.map_tool(action_type.name, action_type.name)


def create_defi_registry() -> ActionRegistry:
    """Create a registry with both base and DeFi action types."""
    from vaara.taxonomy.actions import create_default_registry
    registry = create_default_registry()
    register_defi_actions(registry)
    return registry


def get_defi_sequences() -> list[SequencePattern]:
    """Return all DeFi-specific dangerous sequence patterns."""
    return list(DEFI_SEQUENCES)
