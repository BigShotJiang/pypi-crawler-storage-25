# Channel-specific intros

One rule: never copy-paste across channels. Each community has its
own vocabulary — the intro that works on HN reads as marketing on
r/LocalLLaMA and as enterprise on OWASP.

All drafts assume the technical post (`01_langgraph_article_14_runtime_gate.md`)
is already cross-posted on dev.to by the time these go out.

---

## Hacker News — Show HN

**Title** (one of, pick based on mood):

- `Show HN: Vaara – Runtime Article 14 oversight for AI agents (Python)`
- `Show HN: Vaara – A conformal-prediction gate for LangGraph tool calls`
- `Show HN: Vaara – Risk scoring and audit trails for AI agent actions`

**Body** (keep it short — HN prefers terse submissions):

> Vaara is a Python library that sits between an AI agent and the
> tools it executes. For every tool call it classifies the action,
> scores risk with a conformal prediction interval, returns
> allow/escalate/deny, and writes a hash-chained audit trail.
>
> Purpose-built for EU AI Act Article 14 (human oversight of
> high-risk AI systems). Zero runtime dependencies. Five lines to
> wire into LangGraph. Ships with CrewAI and OpenAI Agents SDK
> integrations too.
>
> Free, Apache-2.0, `pip install vaara`.

**Link:** https://pypi.org/project/vaara/

**Rules from the launch plan:**
- Post 13:50–14:10 UTC Tuesday 2026-04-21 or Wednesday.
- Be in the thread for the first 90 minutes.
- First comment = the 5-line snippet (see `hn_first_comment.md`).
- Do **not** self-upvote.

---

## r/LocalLLaMA

Lean into the local / in-process angle. This subreddit hates SaaS.

> Wired up a runtime gate for LangGraph tool calls over the weekend
> — wanted something that could say "this action shouldn't execute"
> *before* the agent actually runs it, without a network round trip
> to someone's API.
>
> It's a Python library, in-process, zero runtime deps. Every tool
> call gets a conformal prediction interval on risk (lower + upper
> bound, not a point estimate) and lands in a hash-chained audit
> trail. Five lines to integrate:
>
>     from vaara.pipeline import InterceptionPipeline
>     from vaara.integrations.langchain import VaaraCallbackHandler
>     pipeline = InterceptionPipeline()
>     handler = VaaraCallbackHandler(pipeline, agent_id="bot")
>     agent.invoke(..., config={"callbacks": [handler]})
>
> Built primarily for EU AI Act Article 14 oversight, but the same
> primitive works anywhere you want a policy-layer veto on an
> LLM-picked action.
>
> PyPI: https://pypi.org/project/vaara/ · walkthrough: [dev.to link]

**Do not:** mention "governance" in the title. r/LocalLLaMA reads
that as enterprise. Title it "Runtime gate for LangGraph tool calls
— 5-line integration, in-process, zero deps."

---

## r/MachineLearning — `[P]` tag (weekend if HN flops)

Technical framing, no regulatory lead:

> **[P] Vaara — runtime oversight gate for LangGraph/CrewAI/OpenAI
> Agents**
>
> TL;DR: a Python library that sits between an LLM agent and its
> tools. On every proposed tool call:
>
> 1. Classifies the action (category, reversibility, blast radius,
>    regulatory domain).
> 2. Scores risk with split conformal prediction — returns a
>    calibrated `[lower, upper]` interval, not a point estimate.
> 3. Five expert signals combined via multiplicative weight update,
>    adapts online from outcome feedback. No retraining.
> 4. Hash-chained audit trail per Article 12 / 14 of the EU AI Act.
>
> Interval width drives allow/escalate/deny. Zero runtime deps.
>
> Feedback on the scorer design especially welcome — the formal
> spec is in `docs/formal_specification.md`.
>
> PyPI: https://pypi.org/project/vaara/

**Do not:** lead with compliance or fines. r/ML is allergic to
regulation-first framing.

---

## LangChain Community Slack — `#showcase`

Slack is conversational. Short, first-person, code block.

> Shipped this weekend: a `BaseCallbackHandler` that scores risk and
> writes an audit record for every tool call your LangGraph agent
> makes. Returns allow/escalate/deny, raises `ToolExecutionBlocked`
> on deny.
>
> ```python
> from vaara.integrations.langchain import VaaraCallbackHandler
> handler = VaaraCallbackHandler(pipeline, agent_id="bot")
> agent.invoke(..., config={"callbacks": [handler]})
> ```
>
> Built around EU AI Act Article 14 oversight, but works anywhere
> you want a pre-execution veto on a tool call. Python, zero
> runtime deps, in-process. Would love feedback from anyone running
> LangGraph in production: `pip install vaara`.
>
> Walkthrough: [dev.to link]

---

## MLOps.community Slack

Three channels, one post per channel. Rewrite the lead for each:

### `#llm-in-production`
> For anyone running LLM agents in prod, especially in regulated
> spaces: I shipped a runtime-gate library that scores every tool
> call with a conformal risk interval and keeps a hash-chained
> audit trail. In-process, Python, zero deps. Built for EU AI Act
> Article 14 but the primitive generalises. `pip install vaara`.

### `#agents`
> Runtime action classification and risk scoring for LangChain /
> LangGraph / CrewAI agents. Every tool call gets a conformal
> prediction interval + an audit record before it executes. The
> scorer adapts online — no retraining. Would love to know what
> primitives other teams wish existed at the agent/tool boundary.

### `#tools-and-platforms`
> New Python library for agent action governance: `pip install
> vaara`. BaseCallbackHandler for LangChain, CrewAI callback,
> OpenAI Agents SDK guardrail. Returns allow/escalate/deny with a
> conformal risk interval. Audit trail is SHA-256 hash-chained.

---

## OWASP GenAI Security Slack (LLM Top 10 + Agentic Initiative)

Security audience — lean on the attack model, not the SDK.

> For the excessive-agency / tool-misuse failure mode (LLM06 in the
> top-10): a library that enforces a pre-execution gate on every
> tool call an agent makes. Classifies the action, scores risk with
> a conformal interval, returns allow/escalate/deny, and writes a
> tamper-evident audit trail.
>
> Sequence detection is part of the default scorer —
> `read → export → delete` is a different risk from any of those
> alone. In-process, Python, zero runtime deps. PyPI: `vaara`.
>
> Interested in feedback on threat modelling and whether the
> evidence surface is what a red team would actually want during
> a post-incident review.

---

## CrewAI Discord — `#showcase`

CrewAI integration already ships. Keep this very short.

> Pushed a CrewAI callback that runs a risk-scoring gate on every
> agent tool call — conformal prediction interval, allow /
> escalate / deny decision, hash-chained audit trail. Integration
> is one line:
>
> ```python
> from vaara.integrations.crewai import VaaraCrewGovernance
> ```
>
> In-process Python, zero runtime deps. Built for EU AI Act
> Article 14 but useful anywhere you want a pre-execution veto.
> `pip install vaara`.

---

## AI Engineer Foundation Discord

Dev-tool-builder audience. Lean on the primitive, not the compliance.

> Shipped a runtime gate for LLM agents: imports into LangChain /
> CrewAI / OpenAI Agents in about five lines, scores every tool
> call with a conformal prediction interval, returns
> allow/escalate/deny, keeps a SHA-256 hash-chained audit trail.
>
> The scorer is five expert signals via multiplicative weight
> update — adapts online from outcome feedback, no retraining.
> Zero runtime dependencies by design (runtime gates can't sit
> behind a network call). PyPI: `vaara`.

---

## Dev.to

Full cross-post of `01_langgraph_article_14_runtime_gate.md`. Tags:
`python`, `langchain`, `llm`, `ai`. Optional: `europe`, `compliance`
— depends on whether you want dev or regulator pickup.

---

## LinkedIn (Day 7–10, not Day 0)

Full cross-post of `02_action_governance_category.md`. Tags:
`#EUAIAct`, `#AIGovernance`, `#Article14`, `#ResponsibleAI`,
`#AICompliance`. Link to PyPI in the second paragraph, not the
first — LinkedIn deranks posts that lead with external links.
