# Vaara 0.3.2 vs Microsoft Agent Governance Toolkit — honest diff

_Drafted 2026-04-19 as the factual backbone for the category/positioning
post. MS Toolkit shipped 2026-04-02._

## 1. Architecture / deployment

- **MS Toolkit:** in-process library **+** AKS sidecar **+** Azure
  Foundry middleware **+** Azure Container Apps. Runtimes: Python,
  TypeScript, Rust, Go, .NET. Public repo has 7 packages by the launch
  blog's count (monorepo has drifted; local audit from 2026-04-10 saw
  12 — use 7 in public writing).
- **Vaara 0.3.2:** pure Python, single-process, in-process interception
  via `InterceptionPipeline.intercept()`.

## 2. Policy model

- **MS:** declarative, deterministic. YAML, OPA/Rego, AWS Cedar. A
  `PolicyEvaluator` class with `PolicyDocument` + `PolicyRule`. Claims
  sub-millisecond enforcement (<0.1ms p99). A keyword-based
  `SemanticPolicyEngine` exists but is not ML-scored.
- **Vaara:** runtime scorer. Conformal interval + MWU. No YAML/Rego.

## 3. Audit / logging

- **MS:** "Audit Log → OTEL / Structured Logs." SHA-256 attestation
  hashes on control results. No hash-chaining / Merkle / sealing in
  public docs.
- **Vaara:** **SHA-256 hash-chained** trail, tamper-evident, in-memory
  default + optional SQLite sink.

## 4. Framework integrations

- **MS (first-class):** Microsoft Agent Framework, Semantic Kernel,
  LangChain/LangGraph, CrewAI, OpenAI Agents SDK, Google ADK,
  LlamaIndex, Haystack, PydanticAI, Dify, Azure AI Foundry.
- **Vaara:** LangChain, CrewAI, OpenAI Agents SDK, MCP server.

## 5. Regulatory mapping

- **MS:** EU AI Act, SOC 2, NIST AI RMF, Colorado AI Act, HIPAA (per
  InfoWorld). Framework-level, not article-level. Centre of gravity is
  **OWASP Agentic Top 10** (10/10 coverage).
- **Vaara:** article-level per-action tags across EU AI Act, GDPR,
  DORA, NIS2, MiFID II, HIPAA, SOC 2, product liability.

## 6. Runtime confidence

- **MS:** `TrustRoot` — 0–1000 behavioural reputation score across 5
  tiers with decay. Decision = allow/shadow/deny via thresholds. No
  uncertainty quantification.
- **Vaara:** conformal risk **interval** + MWU → allow/escalate/deny,
  with interval width exposing epistemic uncertainty.

## 7. License + source

- **MS:** MIT, public monorepo
  (`github.com/microsoft/agent-governance-toolkit`), 9,500+ tests,
  ClusterFuzzLite, SLSA, OpenSSF Scorecard, CodeQL.
- **Vaara:** Apache-2.0, PyPI-only, no public repo yet.

## 8. Install footprint

- **MS:** `pip install agent-governance-toolkit[full]` — multi-package
  stack, OTEL + OPA + Cedar bindings.
- **Vaara:** `pip install vaara` — **zero runtime dependencies**.

## Where Vaara genuinely differs

1. Hash-chained tamper-evident audit trail.
2. Conformal interval (distribution-free uncertainty), not a
   deterministic rule outcome.
3. Article-level EU AI Act / GDPR / DORA tags at action granularity.
4. Zero runtime deps, in-process, Python-only.

## Where Vaara is objectively smaller/less mature

1. 4 integrations vs 10+.
2. 1 language vs 5.
3. No public repo, no SLSA, no CodeQL, no 9,500-test battery.
4. Less deployment shape variety (in-process only).

## Category-post one-liner (safe to use)

> _Action governance is not model governance — and deterministic policy
> is not calibrated confidence. Microsoft's toolkit is the policy
> firewall; Vaara is the calibrated risk gate behind it._

## Positioning paragraph (safe to use)

> Vaara is not a competitor to Microsoft's Agent Governance Toolkit —
> it is a complementary primitive. MS Toolkit is a broad, multi-runtime
> policy platform focused on OWASP Agentic Top 10 with deterministic
> rule-based enforcement (YAML/Rego/Cedar) and behavioural trust
> scores. Vaara is a single-purpose, zero-dependency Python library
> that adds the one thing a declarative policy engine cannot: a
> distribution-free confidence interval per action, with a hash-chained
> audit trail mapped article-by-article to EU AI Act Article 14 and
> adjacent regimes. If you are enforcing "agent X may not call tool Y,"
> use MS Toolkit. If you are answering "should this action execute
> *now*, given uncertainty, and can I defend that decision to an EU AI
> Act auditor line-by-line," that is Vaara's job. They sit on the same
> interception layer and can run side by side.

## Claims to verify before the category post goes live

- Scan MS repo `docs/` for any `EU-AI-ACT.md` — only then can the
  "article-level is a Vaara differentiator" claim be made without
  hedge.
- Confirm MS has no hash-chaining / Merkle in their audit — public docs
  say no, but the repo may have additions.
