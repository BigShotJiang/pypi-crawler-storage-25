# HN first comment (paste within 90 seconds of Show HN submission)

The first comment under a Show HN post anchors the thread. Paste this
right after submitting — the launch plan target is <90 seconds, because
HN ranking decays hard and early comments drive engagement.

HN renders 4-space-indented lines as a code block.

---

## Version A — 5-line LangGraph teaser (default)

Author here.

Five-line LangGraph integration — the whole runtime gate:

    from vaara.pipeline import InterceptionPipeline
    from vaara.integrations.langchain import VaaraCallbackHandler

    pipeline = InterceptionPipeline()
    handler = VaaraCallbackHandler(pipeline, agent_id="treasury-bot")
    agent.invoke(..., config={"callbacks": [handler]})

Every tool call gets classified, risk-scored with a conformal interval
(lower + upper bound, not a point estimate), and written to a
hash-chained audit trail before it executes. The scorer adapts online
from outcome feedback — no retraining loop.

Full walkthrough, including the `try/except ToolExecutionBlocked`
escalation path: https://dev.to/[username]/[post-slug]

Happy to take questions on the scoring math, the EU AI Act Article 14
mapping, or the CrewAI / OpenAI Agents integrations.

---

## Version B — if HN title uses the category framing

Author here.

Short version of why this exists as a separate category from model
governance: `read_data`, `export_data`, and `delete_data` are each
benign in isolation. The sequence is a data exfiltration pattern, and
every model-governance dashboard will say the model is fine.

Runtime action gating is a different primitive. Five-line integration:

    from vaara.pipeline import InterceptionPipeline
    from vaara.integrations.langchain import VaaraCallbackHandler

    pipeline = InterceptionPipeline()
    handler = VaaraCallbackHandler(pipeline, agent_id="treasury-bot")
    agent.invoke(..., config={"callbacks": [handler]})

Pure Python library, zero runtime deps, hash-chained audit trail.
Happy to take questions.

---

## Notes

- Do **not** paste both versions. Pick one based on what the Show HN
  title leads with. Default is A (technical).
- Replace `[username]/[post-slug]` with the dev.to URL after that
  cross-post is live.
- The `agent.invoke(..., config={"callbacks": [handler]})` line is a
  shorthand — the real call needs `{"messages": [...]}` as the first
  arg. If someone quotes this back, send them to the dev.to post
  rather than arguing in-thread.
- The `name "vaara-execution-layer" is a squat, file a complaint with
  PyPI` flavour of comment: the package on PyPI is named `vaara`
  (clean). The repo dir is named differently. Don't get drawn in.
