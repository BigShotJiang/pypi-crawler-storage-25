# HN objection playbook

Ten predictable Show HN objections with paste-ready replies. HN
threads move in minutes — having the response drafted means you can
engage in a 60-second window without freezing.

Rule: answer honestly. If the objection is valid, say so.
"Acknowledge the thing" scores higher than "defend the thing."

---

## 1. "Why not just use OPA/Rego? We already have policy engines."

Good question, and there's actually no conflict. OPA/Rego is
deterministic: "if the request matches this pattern, deny." Vaara
is probabilistic — it runs when *pattern-match alone isn't enough*,
because the risk depends on sequence, agent history, blast radius,
and calibration data. They stack cleanly. OPA enforces the rules
you can write down; Vaara scores the decisions you can't.

Microsoft's Agent Governance Toolkit is in the OPA lane
(YAML/Rego/Cedar). That's the right tool for static policy. Vaara
is what you reach for when you need a calibrated confidence on
*this specific action in this specific context*.

---

## 2. "Why Python-only? What about TypeScript/Node agents?"

Honest answer: because the interesting agent frameworks today —
LangGraph, CrewAI, OpenAI Agents SDK — are Python-first, and the
audit trail + scoring logic is small enough that a Python-only
first release was the fastest way to get real feedback.

If there's demand for a TS port, the pipeline logic is ~1500 LOC
and the wire format is stable. Happy to talk through what a
TS/Node port would look like.

---

## 3. "Is this audited? Who's validated the conformal coverage claims?"

No third-party audit yet — it's a 0.3.x library. The conformal
prediction implementation is standard split conformal (Vovk et al.,
extended by Angelopoulos & Bates). The formal specification in
`docs/formal_specification.md` states the coverage guarantee and
the convergence rate of the MWU expert system (O(√(T log N))).

If you want to reproduce the coverage claim: the trace generator
in `src/vaara/sandbox/` lets you simulate a cold-start agent and
watch the empirical coverage of the prediction intervals converge.
Criticism on the choice of expert signals is especially welcome.

---

## 4. "How is this different from the Microsoft Agent Governance Toolkit?"

Different category. MS Toolkit is a policy enforcement framework —
YAML + Rego + Cedar, deterministic, sub-millisecond, multi-language
(Python, TypeScript, Rust, Go, .NET), deploys as library + AKS
sidecar + Azure Foundry middleware.

Vaara is a runtime risk scorer. In-process Python library, single
file to import, conformal prediction intervals + online learning +
hash-chained audit trail. It's not a policy engine; it's the
calibrated confidence layer *behind* one.

Short version: action governance is not model governance, and
deterministic policy is not calibrated confidence. MS Toolkit is
the policy firewall; Vaara is the risk gate behind it.

---

## 5. "Isn't this just a slow wrapper around LangChain callbacks? Add latency?"

The callback handler itself is ~200 lines. The scoring call is
CPU-bound, no I/O, submillisecond on the default expert config.
The audit trail write is in-process and hash-chain is append-only;
no fsync on hot path (optional SQLite persistence runs async).

If you want numbers: happy to run a latency benchmark on whatever
hardware you care about. The design constraint was "runtime gate
cannot sit behind a network call" — that rules out SaaS, not
in-process libraries.

---

## 6. "The five expert signals feel arbitrary. How were they chosen?"

Fair. They are (names as they appear in `adaptive.py`):

1. `taxonomy_base` — static risk from the action's taxonomy entry
   (reversibility, blast radius, urgency, regulatory domain).
2. `agent_history` — this agent's track record (denial rate, bad
   outcomes over its lifetime).
3. `sequence_pattern` — does the recent action sequence match a
   known dangerous pattern (exfiltration, privilege escalation,
   flash-loan attack)?
4. `action_frequency` — burst detection; unusual spikes in action
   rate.
5. `confidence_gap` — the agent's self-reported confidence vs its
   observed accuracy. A confidently-wrong agent is the worst kind.

They're the five that fell out of mapping EU AI Act Article 14
oversight requirements to observable runtime features. Not claimed
to be optimal — the MWU weighting exists *because* the right
combination is not knowable a priori. Outcomes drive the weights.

---

## 7. "Why 'Article 14' specifically? Most of us aren't in EU."

Article 14 is the *motivating* requirement, not the *only* use
case. The same primitive — pre-execution gate + calibrated risk
score + audit trail — maps to SOC 2 (logging + change control),
HIPAA (access controls), DORA (operational resilience), and
product liability cases where "what stopped this?" is the first
discovery question.

The taxonomy ships with tags for all of those. Use whichever
regulatory domain actually applies to you; the runtime behaviour
is identical.

---

## 8. "Is the scorer actually useful before calibration? Cold start?"

Cold-start behaviour is deliberate. With zero calibration data,
the MWU weights are uniform and the scorer runs in
"rule-based" mode — the taxonomy base score dominates. The
conformal interval is wide, so most unknown actions end up
escalated rather than auto-denied.

Once outcomes start arriving (the `report_outcome()` call on every
action), MWU re-weights toward experts that actually predict bad
outcomes. Convergence is O(√(T log N)) against the best fixed
expert. Trace generator in `docs/` lets you simulate this.

---

## 9. "Where are the benchmarks? How does it catch real attacks?"

The library is the infrastructure, not the benchmark. Anyone
running it on real agent traces gets a labelled dataset for free —
that's the feedback loop the scorer needs. A published benchmark
on synthetic data is on the roadmap, honestly behind "make the
integrations solid first."

If you have agent traces (especially from production or
red-teaming), I'd love to run it and publish the numbers. Not
going to cherry-pick a benchmark suite to make the library look
better than it is.

---

## 10. "Why a library, not a service? Hard to update policies centrally."

Two reasons. First, runtime gates can't sit behind a network call
— if the only thing stopping a bad action is a round trip to a
scorer somewhere, the action either fires before the gate answers
or the whole agent stalls. Second, "policies" in this case aren't
static rules; they're calibration data that flows back from
outcomes. That has to live next to the agent.

Central policy *rules* are a different primitive — that's what
OPA/Rego handles. Vaara wraps the non-deterministic layer, where
"update centrally" doesn't buy you much.

---

## 11. "What's the licensing? Can I use it commercially?"

Apache-2.0. Use it, modify it, embed it. No field-of-use
restrictions. If you build something on top, no obligation to
upstream changes.

---

## 12. "Is this tied to vaara.io? What's the monetization path?"

Library is Apache-2.0, free, no call-home. vaara.io is the
project's umbrella domain — it currently serves a related DeFi
product. Monetization for the agent governance side, if it ever
materialises, would be bespoke tuning engagements for deployers
with real production traces, not a gating license. The core gate
is infrastructure and stays that way.

---

## Notes on delivery

- Link-drop replies ("see the README") underperform full
  paragraphs, even when correct.
- If someone posts a genuinely better critique than is covered
  here: upvote it, reply "you're right, this is on the roadmap"
  with a concrete timeline. Don't defend.
- If someone gets the library confused with another `vaara`
  (a Finnish toilet-cleaning brand exists): one-line
  disambiguation, don't dwell.
- Don't argue with people who clearly didn't read the post. They
  lose interest faster than you do.
