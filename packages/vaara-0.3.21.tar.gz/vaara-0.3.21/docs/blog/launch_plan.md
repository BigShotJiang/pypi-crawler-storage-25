# Vaara 0.3.2 Launch Plan

_Drafted 2026-04-19. Assumes package is live on PyPI, two blog drafts and
enterprise PDF are in `docs/blog/`._

## The landscape (why timing matters)

**Microsoft Agent Governance Toolkit shipped 2026-04-02/03** — same
category, ~2 weeks old, ate the InfoWorld/Phoronix/HN cycle. Vaara is
not "better than MS." The wedge is narrower:

- **In-process Python library**, not a multi-language platform.
- **Purpose-built for EU AI Act Article 14**, not a general policy
  engine.
- **Single-file import, zero runtime deps** — fits a dev's 5-minute
  attention budget, not a procurement review.

Do not pitch as competitor. Pitch as the thing a Python team reaches for
when MS is too big.

## Positioning summary

- Lead with the **verb**: runtime oversight, runtime gate, runtime
  action classification.
- Avoid the word "governance" in HN/Reddit titles — reads enterprise,
  repels devs.
- Lead with **code in the first 20 lines** of every post.
- Compliance is the *why*, not the hook.

## Sequencing (14-day window)

### Day 0 — Tuesday, 2026-04-21, 14:00 UTC (10:00 AM ET)

**Technical post first.** Demo beats positioning on day one.

| Where | What | Title pattern |
|---|---|---|
| Hacker News | Show HN link to PyPI | `Show HN: Vaara – Runtime Article 14 oversight for AI agents (Python)` |
| r/LocalLLaMA | Link + 5-line code teaser | `Five-line LangGraph integration: a runtime gate for agent tool calls` |
| LangChain Community Slack `#showcase` | Native message, code block | "Shipped: LangChain CallbackHandler that scores + logs every tool call" |
| Dev.to | Full cross-post of `01_langgraph_article_14_runtime_gate.md` | Same title as file |
| r/MachineLearning `[P]` | Post link + summary (weekend if HN flops) | `[P] Vaara: runtime oversight gate for LangGraph agents` |

**HN rules:** post 13:50–14:10 UTC Tue or Wed. Don't self-upvote. Be in
the thread for the first 90 minutes — ranking decay is brutal. Link to
**PyPI** (`pypi.org/project/vaara`), not a marketing site. First comment
should be the 5-line LangGraph snippet.

### Day 1–2 — warm communities

- **MLOps.community Slack** — `#llm-in-production`, `#agents`,
  `#tools-and-platforms`.
- **OWASP GenAI Security Slack** (LLM Top 10 + Agentic Initiative) —
  governance-serious devs, not listicle farmers.
- **CrewAI Discord `#showcase`** — integration already ships in 0.3.2.
- **AI Engineer Foundation Discord** — Swyx-adjacent, concentrated
  dev-tool builders.

One post per community. No copy-paste across — rewrite the intro each
time to match the channel's vocabulary.

### Day 7–10 — category/positioning post

**LinkedIn + Substack cross-post** of `02_action_governance_category.md`.
Angles:

- "Action governance is not model governance."
- "The missing layer: runtime Article 14 oversight."
- Tags: `#EUAIAct`, `#AIGovernance`, `#Article14`, `#ResponsibleAI`,
  `#AICompliance`.

If HN day-0 scored <30, submit a second HN under the category framing
on a different day (Wed preferred). Different URL, different first
comment, don't resubmit the same link.

### Day 10–14 — enterprise PDF, 1:1 only

- DM the PDF to EU-AI-Act-active LinkedIn voices (list below).
- Do NOT put it behind a public download link on day 1 — burns the
  "serious enterprise artefact" signal.
- After ~5 accepted DMs, only then consider gating it behind an email
  form on vaara.io.

## People to engage (not mass-tag)

- **Luiza Jarovsky** (@LuizaJarovsky) — EU AI Act newsletter, 44k–93k
  subs. Reply to her Article 14 posts with a concrete 5-line code
  example.
- **Kai Zenner** (Axel Voss's office, LinkedIn) — inside-baseball on
  implementation. Comment on his Article 14 posts; do not cold-DM.
- **Gabriele Mazzini** (LinkedIn) — chief architect of the AI Act.
  Tier-3 engagement only; don't lead with a product pitch.
- **Dean Ball** (*Hyperdimensional* Substack) — technical-governance
  bridge. Best target for a guest essay in month 2.
- **Melissa Heikkilä** (FT) — only if one of the above re-shares first.

Rule: comment on three of their posts before mentioning Vaara. No
drive-by pitches.

## Titles that won't misfire

**Keep:** "runtime," "Article 14," "LangGraph," "Python," "five-minute,"
"in-process," "hash-chained audit."

**Cut:** "AI governance platform" (reads SaaS), "revolutionary,"
"next-generation," "comprehensive solution," anything with an em-dash
adjective stack.

## Follow-up defect (fixed in 0.3.2)

`pyproject.toml` dead URLs stripped in 0.3.2. Ship 0.3.2 to PyPI before
the technical post goes out.

## What I will not do

- No paid ads.
- No cold email blast (0/13 historical).
- No Immunefi (permabanned).
- No Discord spam.
- No product on HN without being live in the thread.

## Success signals (what "worked" looks like)

- **HN:** front page for >2 hours or >60 points. Either flips the
  next 48h of inbound.
- **PyPI:** 500+ downloads in the first week (0.3.2 vs 0.2.x baseline).
- **LinkedIn:** one named EU-AI-Act voice engages publicly.
- **Inbound:** one enterprise contact form submission or DM asking
  about paid tuning.

Miss all four → rewrite the category post, try again Day 21.

## Uncertainty flags (from research)

- Luiza's exact 2026 subscriber count varies across sources (44k–93k).
- r/LocalLLaMA's tolerance for compliance framing unverified — lead
  with the code.
- MS Toolkit feature-diff not done; spend 30 min on that before Day 7
  so the category post holds up under scrutiny.
