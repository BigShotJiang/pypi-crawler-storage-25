#exonware/xwsystem/tests/0.core/cli/__init__.py
#exonware/xwsystem/tests/core/cli/__init__.py
"""
CLI Core Tests Package
Tests for xwsystem CLI functionality including console operations,
progress tracking, prompts, and table formatting.
"""
