from __future__ import annotations

import json
import shutil
from datetime import datetime, timezone
from pathlib import Path

import click

from .builder import build_project, validate_project
from .config import load_job_config
from .uploader import upload_file_to_s3


TEMPLATES_DIR = Path(__file__).parent / "templates"


def _copy_template(src_name: str, dest_path: Path) -> None:
    src = TEMPLATES_DIR / src_name
    shutil.copy2(src, dest_path)


def _set_toml_name(toml_path: Path, name: str) -> None:
    import re
    text = toml_path.read_text(encoding="utf-8")
    text = re.sub(r'^name\s*=\s*"[^"]*"', f'name = "{name}"', text, count=1, flags=re.MULTILINE)
    toml_path.write_text(text, encoding="utf-8")


@click.group()
def cli() -> None:
    """Build and upload Python job packages for Goliath."""
    pass


@cli.command()
@click.argument("project_dir", type=click.Path(path_type=Path), default=".")
def init(project_dir: Path) -> None:
    """Create a starter job project."""
    project_dir.mkdir(parents=True, exist_ok=True)

    job_toml = project_dir / "job.toml"
    handler_py = project_dir / "handler.py"
    requirements_txt = project_dir / "requirements.txt"

    main_py = project_dir / "main.py"
    if main_py.exists():
        if click.confirm(f"A main.py already exists in {project_dir}. Remove it?"):
            main_py.unlink()
            click.echo("Removed main.py")
        else:
            click.echo("Skipping init.")
            return

    if not job_toml.exists():
        _copy_template("job.toml", job_toml)
        project_name = project_dir.resolve().name
        _set_toml_name(job_toml, project_name)

    if not handler_py.exists():
        _copy_template("handler.py", handler_py)

    if not requirements_txt.exists():
        requirements_txt.write_text("", encoding="utf-8")

    click.echo(f"Initialized starter project at: {project_dir}")


@cli.command()
@click.argument("project_dir", type=click.Path(exists=True, file_okay=False, path_type=Path), default=".")
def clean(project_dir: Path) -> None:
    """Remove all files created by init and build."""
    targets = [
        project_dir / "job.toml",
        project_dir / "handler.py",
        project_dir / "requirements.txt",
        project_dir / "dist",
    ]
    removed = []
    for target in targets:
        if target.is_dir():
            shutil.rmtree(target)
            removed.append(str(target))
        elif target.is_file():
            target.unlink()
            removed.append(str(target))

    if removed:
        for r in removed:
            click.echo(f"Removed: {r}")
    else:
        click.echo("Nothing to clean.")


@cli.command()
@click.argument("project_dir", type=click.Path(exists=True, file_okay=False, path_type=Path), default=".")
def validate(project_dir: Path) -> None:
    """Validate a job project."""
    validate_project(project_dir)
    click.secho("✔ Package is valid.", fg="green", bold=True)


@cli.command()
@click.argument("name")
@click.argument("project_dir", type=click.Path(exists=True, file_okay=False, path_type=Path), default=".")
def rename(name: str, project_dir: Path) -> None:
    """Change the job name in job.toml."""
    toml_path = project_dir / "job.toml"
    if not toml_path.exists():
        raise click.ClickException(f"No job.toml found in {project_dir}")
    _set_toml_name(toml_path, name)
    click.echo(f"Renamed job to: {name}")


@cli.command()
@click.argument("project_dir", type=click.Path(exists=True, file_okay=False, path_type=Path), default=".")
@click.option("--dist-dir", type=click.Path(path_type=Path), default=None)
def build(project_dir: Path, dist_dir: Path | None) -> None:
    """Build a zip package."""
    result = build_project(project_dir, dist_dir=dist_dir)
    click.echo(f"Built zip: {result.zip_path}")
    click.echo(f"Manifest:  {result.manifest_path}")


@cli.command()
@click.argument("zip_path", type=click.Path(exists=True, dir_okay=False, path_type=Path))
@click.option("--bucket", required=True)
@click.option("--key", default=None, help="S3 key. If omitted, one is generated.")
@click.option("--region", default=None)
def upload(zip_path: Path, bucket: str, key: str | None, region: str | None) -> None:
    """Upload a built zip to S3."""
    if key is None:
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        name = zip_path.stem  # e.g. "my-job" from "my-job.zip"
        key = f"job-packages/{name}/{stamp}/{zip_path.name}"

    result = upload_file_to_s3(
        file_path=zip_path,
        bucket=bucket,
        key=key,
        region=region,
    )
    click.echo(json.dumps(result, indent=2))


@cli.command(name="package")
@click.argument("project_dir", type=click.Path(exists=True, file_okay=False, path_type=Path), default=".")
@click.option("--bucket", required=True)
@click.option("--prefix", default="job-packages")
@click.option("--region", default=None)
@click.option("--dist-dir", type=click.Path(path_type=Path), default=None)
def package_cmd(
    project_dir: Path,
    bucket: str,
    prefix: str,
    region: str | None,
    dist_dir: Path | None,
) -> None:
    """Build and upload a project."""
    config = load_job_config(project_dir)
    result = build_project(project_dir, dist_dir=dist_dir)

    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    zip_key = f"{prefix}/{config.name}/{stamp}/{result.zip_path.name}"
    manifest_key = f"{prefix}/{config.name}/{stamp}/{result.manifest_path.name}"

    zip_upload = upload_file_to_s3(
        file_path=result.zip_path,
        bucket=bucket,
        key=zip_key,
        region=region,
    )
    manifest_upload = upload_file_to_s3(
        file_path=result.manifest_path,
        bucket=bucket,
        key=manifest_key,
        region=region,
    )

    click.echo(
        json.dumps(
            {
                "zip": zip_upload,
                "manifest": manifest_upload,
            },
            indent=2,
        )
    )


@cli.command(name="publish-build")
def publish_build() -> None:
    """Build the PyPI distribution (sdist + wheel)."""
    import subprocess

    dist = Path("dist")
    if dist.exists():
        shutil.rmtree(dist)
        click.echo("Cleaned old dist/")

    click.echo("Building sdist and wheel...")
    subprocess.run(["uv", "run", "python", "-m", "build"], check=True)

    click.echo("\nBuild complete! Distribution files are in dist/")
    click.echo("\nTo publish to PyPI, run:")
    click.secho("  uv run twine upload dist/*", fg="yellow", bold=True)


@cli.command()
@click.option("--region", default=None)
def deploy(region: str | None) -> None:
    """Build and upload with an interactive wizard."""
    project_dir = Path(".")

    click.echo("Building project...")
    result = build_project(project_dir)
    click.echo(f"Built zip: {result.zip_path}")

    deployment_name = click.prompt("Deployment name")
    bucket = click.prompt("S3 bucket", default="mto-lambdas")

    key = f"{deployment_name}/{deployment_name}.zip"

    click.echo(f"Uploading to s3://{bucket}/{key} ...")
    upload_result = upload_file_to_s3(
        file_path=result.zip_path,
        bucket=bucket,
        key=key,
        region=region,
    )
    click.echo(json.dumps(upload_result, indent=2))
    click.echo("Deploy complete.")


if __name__ == "__main__":
    cli()