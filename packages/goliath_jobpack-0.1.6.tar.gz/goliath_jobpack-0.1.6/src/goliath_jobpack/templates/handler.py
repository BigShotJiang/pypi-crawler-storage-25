from __future__ import annotations


def main(event: dict, context: dict) -> dict:
    print("Hello from Goliath job package")
    print("Event:", event)
    print("Context:", context)

    return {
        "success": True,
        "message": "Job completed successfully",
    }