# advoco

advoco is an Advent of Code runner and helper library. The user writes pure solver functions (`transform`, `part1`, `part2`); advoco handles input fetching, caching, day/year resolution, sample validation, and execution. There are two entry points: `advoco.do()` — the full workflow, name is a pun and must never change — and `advoco.do_offline()`, a simpler path that takes file input, skips all AoC site interaction, and just runs transform/parts and prints results.

## Quality Bar

Prefer clear and direct over compact and clever. Use type hints throughout, docstrings on public interfaces, and tests that convey intent. Avoid `assert` in production code, hidden side effects in constructors, and surprising control flow. When refactoring, preserve behavior and minimize scope unless explicitly told otherwise.

## Key Invariants

These must hold across all changes:

- **advoco handles all orchestration concerns.** Solver functions should never need to fetch input, manage caching, read environment variables, or infer puzzle metadata. advoco owns all of that.
- **Sample before real.** advoco always validates against sample input before running canonical input. If the sample fails, canonical input is never touched.
- **Part 2 is gated on Part 1.** Part 2 does not run until Part 1 has been solved.
- **Cache is write-once.** Puzzle inputs and answers never change. Once cached, they are never re-fetched or invalidated. Minimizing requests to AoC's servers is a first-class concern.
- **Entry points are `do` and `do_offline`.** Don't add others. Both names are stable API.

## How `do` Finds Solver Functions

`do` uses `inspect.stack()` to grab the calling frame, then `getattr` to discover `transform`, `part1`, and `part2` on the calling module. This is intentional — it's what allows a puzzle file to call `advoco.do()` with no imports or explicit wiring. When working on `do`, preserve this pattern.

## Day/Year Resolution

Precedence: explicit args/flags → calling context (digits in filename → day; `20XX` in parent directory → year) → current date in `America/New_York`. Once resolved, day/year is immutable for the run.

## Tooling

`uv` · `ruff` · `mypy` · `pytest`
