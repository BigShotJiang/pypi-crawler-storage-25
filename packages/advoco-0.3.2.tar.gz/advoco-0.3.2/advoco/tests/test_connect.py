from unittest.mock import MagicMock

import pytest
from bs4 import BeautifulSoup

from advoco.connect import get_auth_cookie_from_env, send_request
from advoco.exceptions import NoTokenError


#################### get_auth_cookie_from_env ####################


def test_get_auth_cookie_returns_session_dict(monkeypatch):
    monkeypatch.setenv("AOC_TOKEN", "abc123")
    assert get_auth_cookie_from_env() == {"session": "abc123"}


def test_get_auth_cookie_raises_without_token(monkeypatch):
    monkeypatch.delenv("AOC_TOKEN", raising=False)
    with pytest.raises(NoTokenError):
        get_auth_cookie_from_env()


#################### send_request ####################


@pytest.fixture
def mock_response():
    resp = MagicMock()
    resp.text = "puzzle input here"
    resp.content = b"<html><body><p>hello</p></body></html>"
    resp.raise_for_status.return_value = None
    return resp


@pytest.fixture
def mock_requests(monkeypatch, mock_response):
    mock_req = MagicMock(return_value=mock_response)
    monkeypatch.setattr("advoco.connect.requests.request", mock_req)
    monkeypatch.setenv("AOC_TOKEN", "testtoken")
    return mock_req


def test_send_request_returns_text(mock_requests):
    result = send_request("get", "2024", "1")
    assert result == "puzzle input here"


def test_send_request_returns_soup_when_requested(mock_requests):
    result = send_request("get", "2024", "1", mmm_soup=True)
    assert isinstance(result, BeautifulSoup)


def test_send_request_constructs_base_url(mock_requests):
    send_request("get", "2024", "5")
    assert mock_requests.call_args.args[1] == "https://adventofcode.com/2024/day/5"


def test_send_request_appends_endpoint_to_url(mock_requests):
    send_request("get", "2024", "5", endpoint="/input")
    assert (
        mock_requests.call_args.args[1] == "https://adventofcode.com/2024/day/5/input"
    )


def test_send_request_includes_auth_cookie(mock_requests):
    send_request("get", "2024", "1")
    assert mock_requests.call_args.kwargs["cookies"] == {"session": "testtoken"}


def test_send_request_posts_body_as_form_data(mock_requests):
    body = {"answer": "42", "level": "1"}
    send_request("post", "2024", "1", endpoint="/answer", body=body)
    assert mock_requests.call_args.kwargs["data"] == body


def test_send_request_calls_raise_for_status(mock_requests, mock_response):
    send_request("get", "2024", "1")
    mock_response.raise_for_status.assert_called_once()


def test_send_request_propagates_http_errors(monkeypatch):
    monkeypatch.setenv("AOC_TOKEN", "abc123")
    error_response = MagicMock()
    error_response.raise_for_status.side_effect = RuntimeError("404 Not Found")
    monkeypatch.setattr(
        "advoco.connect.requests.request", MagicMock(return_value=error_response)
    )
    with pytest.raises(RuntimeError):
        send_request("get", "2024", "1")
