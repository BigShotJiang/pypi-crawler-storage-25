import pytest
from bs4 import BeautifulSoup

from advoco.sample import get_sample_input, get_sample_answer
from advoco.exceptions import SampleTextNotFound, PuzzleNotAvailableError


def make_soup(html: str) -> BeautifulSoup:
    return BeautifulSoup(html, "html.parser")


@pytest.fixture(autouse=True)
def isolated_cache(tmp_path, monkeypatch):
    monkeypatch.setattr("advoco.cache.ADVOCO_CACHE_DIR", tmp_path)
    monkeypatch.setenv("AOC_TOKEN", "testtoken")


#################### get_sample_input ####################

STANDARD_SAMPLE_HTML = """
<html><body>
<article class="day-desc">
<p>For example, consider the following input:</p>
<pre><code>abc
def
ghi</code></pre>
</article>
</body></html>
"""

TRAILING_NEWLINE_HTML = """
<html><body>
<p>For example, consider the following input:</p>
<pre><code>1
2
3
</code></pre>
</body></html>
"""

NO_EXAMPLE_PARAGRAPH_HTML = """
<html><body>
<article class="day-desc">
<p>This puzzle has no example paragraph.</p>
<pre><code>sneaky code block</code></pre>
</article>
</body></html>
"""

NO_PRE_SIBLING_HTML = """
<html><body>
<p>For example, consider the following input:</p>
<p>But it's just another paragraph, not a pre block.</p>
</body></html>
"""

PRE_WITHOUT_CODE_HTML = """
<html><body>
<p>For example, consider the following input:</p>
<pre>no code tag inside here</pre>
</body></html>
"""


def test_get_sample_input_extracts_code_block(monkeypatch):
    monkeypatch.setattr(
        "advoco.sample.send_request", lambda *a, **kw: make_soup(STANDARD_SAMPLE_HTML)
    )
    assert get_sample_input("2024", "1") == "abc\ndef\nghi"


def test_get_sample_input_strips_trailing_newline(monkeypatch):
    monkeypatch.setattr(
        "advoco.sample.send_request", lambda *a, **kw: make_soup(TRAILING_NEWLINE_HTML)
    )
    result = get_sample_input("2024", "1")
    assert result == "1\n2\n3"
    assert not result.endswith("\n")


def test_get_sample_input_raises_when_no_example_paragraph(monkeypatch):
    monkeypatch.setattr(
        "advoco.sample.send_request",
        lambda *a, **kw: make_soup(NO_EXAMPLE_PARAGRAPH_HTML),
    )
    with pytest.raises(SampleTextNotFound):
        get_sample_input("2024", "1")


def test_get_sample_input_raises_when_no_pre_sibling(monkeypatch):
    monkeypatch.setattr(
        "advoco.sample.send_request", lambda *a, **kw: make_soup(NO_PRE_SIBLING_HTML)
    )
    with pytest.raises(SampleTextNotFound):
        get_sample_input("2024", "1")


def test_get_sample_input_raises_when_pre_has_no_code_child(monkeypatch):
    monkeypatch.setattr(
        "advoco.sample.send_request", lambda *a, **kw: make_soup(PRE_WITHOUT_CODE_HTML)
    )
    with pytest.raises(SampleTextNotFound):
        get_sample_input("2024", "1")


#################### get_sample_answer ####################

PART_ONE_HTML = """
<html><body>
<article class="day-desc">
<p>Working through it: <code><em>5</em></code>, then <code><em>42</em></code>.</p>
</article>
</body></html>
"""

TWO_PARTS_HTML = """
<html><body>
<article class="day-desc">
<p>Part 1 answer: <code><em>10</em></code>.</p>
</article>
<article class="day-desc">
<p>Part 2 answer: <code><em>99</em></code>.</p>
</article>
</body></html>
"""

NO_EM_HTML = """
<html><body>
<article class="day-desc">
<p>The answer is something but it's not highlighted in a code tag.</p>
</article>
</body></html>
"""


def test_get_sample_answer_returns_last_em_in_article(monkeypatch):
    monkeypatch.setattr(
        "advoco.sample.send_request", lambda *a, **kw: make_soup(PART_ONE_HTML)
    )
    assert get_sample_answer("2024", "1", "1") == "42"


def test_get_sample_answer_selects_correct_article_for_part(monkeypatch):
    monkeypatch.setattr(
        "advoco.sample.send_request", lambda *a, **kw: make_soup(TWO_PARTS_HTML)
    )
    assert get_sample_answer("2024", "1", "1") == "10"
    assert get_sample_answer("2024", "1", "2") == "99"


def test_get_sample_answer_raises_when_part_not_available(monkeypatch):
    monkeypatch.setattr(
        "advoco.sample.send_request", lambda *a, **kw: make_soup(PART_ONE_HTML)
    )
    with pytest.raises(PuzzleNotAvailableError):
        get_sample_answer("2024", "1", "2")


def test_get_sample_answer_raises_when_no_em_in_article(monkeypatch):
    monkeypatch.setattr(
        "advoco.sample.send_request", lambda *a, **kw: make_soup(NO_EM_HTML)
    )
    with pytest.raises(SampleTextNotFound):
        get_sample_answer("2024", "1", "1")
