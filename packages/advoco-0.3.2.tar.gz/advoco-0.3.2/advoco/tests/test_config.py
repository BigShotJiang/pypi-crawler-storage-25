from unittest.mock import MagicMock

import pytest

from advoco.config import (
    get_day_from_context,
    get_year_from_context,
    resolve_day_and_year,
)
from advoco.exceptions import DateOutOfRangeError


#################### get_day_from_context ####################


@pytest.mark.parametrize(
    "filename,expected",
    [
        ("1.py", "1"),
        ("25.py", "25"),
        ("day7.py", "7"),
        ("solution.py", ""),
    ],
)
def test_get_day_from_context_py_files(tmp_path, filename, expected):
    f = tmp_path / filename
    f.touch()
    assert get_day_from_context(f) == expected


def test_get_day_from_context_non_py_file_returns_empty(tmp_path):
    f = tmp_path / "1.txt"
    f.touch()
    assert get_day_from_context(f) == ""


def test_get_day_from_context_directory_returns_empty(tmp_path):
    d = tmp_path / "5"
    d.mkdir()
    assert get_day_from_context(d) == ""


#################### get_year_from_context ####################


@pytest.mark.parametrize(
    "dirname,expected",
    [
        ("2024", "2024"),
        ("2015", "2015"),
        ("aoc-2023", "2023"),
        ("solutions", ""),
        ("1999", ""),
    ],
)
def test_get_year_from_context_from_file(tmp_path, dirname, expected):
    year_dir = tmp_path / dirname
    year_dir.mkdir()
    f = year_dir / "1.py"
    f.touch()
    assert get_year_from_context(f) == expected


@pytest.mark.parametrize(
    "dirname,expected",
    [
        ("2024", "2024"),
        ("aoc-2023", "2023"),
        ("solutions", ""),
    ],
)
def test_get_year_from_context_from_directory(tmp_path, dirname, expected):
    d = tmp_path / dirname
    d.mkdir()
    assert get_year_from_context(d) == expected


def test_get_year_from_context_only_checks_immediate_parent(tmp_path):
    """Year must be in the immediate parent directory name, not any ancestor."""
    year_dir = tmp_path / "2024"
    year_dir.mkdir()
    subdir = year_dir / "solutions"
    subdir.mkdir()
    f = subdir / "1.py"
    f.touch()
    assert get_year_from_context(f) == ""


#################### resolve_day_and_year ####################


def test_resolve_explicit_args_win_over_context(tmp_path):
    year_dir = tmp_path / "2020"
    year_dir.mkdir()
    f = year_dir / "5.py"
    f.touch()
    day, year = resolve_day_and_year(f, day="12", year="2023")
    assert day == "12"
    assert year == "2023"


def test_resolve_day_and_year_from_context(tmp_path):
    year_dir = tmp_path / "2024"
    year_dir.mkdir()
    f = year_dir / "7.py"
    f.touch()
    day, year = resolve_day_and_year(f)
    assert day == "7"
    assert year == "2024"


def test_resolve_explicit_day_overrides_context(tmp_path):
    year_dir = tmp_path / "2024"
    year_dir.mkdir()
    f = year_dir / "7.py"
    f.touch()
    day, year = resolve_day_and_year(f, day="15")
    assert day == "15"
    assert year == "2024"


def test_resolve_explicit_year_overrides_context(tmp_path):
    year_dir = tmp_path / "2024"
    year_dir.mkdir()
    f = year_dir / "7.py"
    f.touch()
    day, year = resolve_day_and_year(f, year="2022")
    assert day == "7"
    assert year == "2022"


def test_resolve_falls_back_to_current_date(tmp_path, monkeypatch):
    f = tmp_path / "solution.py"  # no digits → no day from context
    f.touch()

    fake_now = MagicMock()
    fake_now.day = 5
    fake_now.year = 2024
    mock_datetime = MagicMock()
    mock_datetime.now.return_value = fake_now
    monkeypatch.setattr("advoco.config.datetime", mock_datetime)

    day, year = resolve_day_and_year(f)
    assert day == "5"
    assert year == "2024"


@pytest.mark.parametrize("day", ["0", "26", "99"])
def test_resolve_invalid_day_raises(tmp_path, day):
    f = tmp_path / "1.py"
    f.touch()
    with pytest.raises(DateOutOfRangeError):
        resolve_day_and_year(f, year="2024", day=day)


@pytest.mark.parametrize("year", ["2014", "2000", "1999"])
def test_resolve_invalid_year_raises(tmp_path, year):
    f = tmp_path / "1.py"
    f.touch()
    with pytest.raises(DateOutOfRangeError):
        resolve_day_and_year(f, day="1", year=year)


@pytest.mark.parametrize("day", ["1", "25"])
def test_resolve_valid_day_boundaries(tmp_path, day):
    f = tmp_path / "1.py"
    f.touch()
    result_day, _ = resolve_day_and_year(f, day=day, year="2024")
    assert result_day == day


def test_resolve_returns_strings(tmp_path):
    f = tmp_path / "1.py"
    f.touch()
    day, year = resolve_day_and_year(f, day="5", year="2024")
    assert isinstance(day, str)
    assert isinstance(year, str)
