from importlib.metadata import version as _pkg_version

from .do import do, do_offline

__version__ = _pkg_version("advoco")

__all__ = [
    "do",
    "do_offline",
    "__version__",
]
