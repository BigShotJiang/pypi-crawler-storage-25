#  Copyright 2022-present, the Waterdip Labs Pvt. Ltd.
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

import base64
import json
import os
from typing import Any, Dict, List, Optional, Tuple

from loguru import logger
from sqlalchemy import create_engine, text

from dcs_core.core.common.errors import DataChecksDataSourcesConnectionError
from dcs_core.core.common.models.data_source_resource import RawColumnInfo
from dcs_core.core.datasource.sql_datasource import SQLDataSource


class BigQueryDataSource(SQLDataSource):
    SQLGLOT_DIALECT = "bigquery"

    def __init__(self, data_source_name: str, data_connection: Dict):
        super().__init__(data_source_name, data_connection)
        self.project_id = self.data_connection.get("project")
        self.dataset_id = self.data_connection.get("dataset")
        self.schema_name = self.dataset_id
        self.keyfile = self.data_connection.get("keyfile")
        self.credentials_base64 = self.data_connection.get("credentials_base64")

    def connect(self) -> Any:
        """
        Connect to the data source
        """
        try:
            credentials = None
            if self.credentials_base64:
                credentials = self.credentials_base64
            elif self.keyfile:
                if os.path.exists(self.keyfile):
                    with open(self.keyfile, "rb") as f:
                        credentials = f.read()
                    credentials = json.loads(credentials)
                    credentials = base64.b64encode(json.dumps(credentials).encode("utf-8")).decode("utf-8")
                else:
                    try:
                        if self._is_base64(self.keyfile):
                            credentials = self.keyfile
                        else:
                            credentials = base64.b64decode(self.keyfile).decode("utf-8")
                    except Exception as e:
                        logger.error(f"Failed to decode keyfile: {e}")
                        credentials = json.loads(self.keyfile)
                        credentials = base64.b64encode(json.dumps(credentials).encode("utf-8")).decode("utf-8")

            if not credentials:
                raise
            url = f"bigquery://{self.project_id}/{self.dataset_id}"
            engine = create_engine(url, credentials_base64=credentials)
            self.connection = engine.connect()
            return self.connection
        except Exception as e:
            raise DataChecksDataSourcesConnectionError(message=f"Failed to connect to BigQuery data source: [{str(e)}]")

    def _is_base64(self, s: str) -> bool:
        try:
            if len(s) % 4 != 0:
                return False
            base64.b64decode(s, validate=True)
            return True
        except Exception:
            return False

    def quote_column(self, column: str) -> str:
        """
        Quote the column name
        :param column: name of the column
        :return: quoted column name
        """
        return f"`{column}`"

    def _resolve_dataset(self, schema: str | None = None) -> str:
        if schema and not (schema.lower() == "public" and not self.data_connection.get("schema")):
            return schema
        return self.data_connection.get("schema") or self.dataset_id

    def qualified_table_name(self, table_name: str) -> str:
        """
        Get the qualified table name
        :param table_name: name of the table
        :return: qualified table name
        """
        if self.project_id and self.dataset_id:
            return f"`{self.project_id}`.`{self.dataset_id}`.`{table_name}`"
        elif self.dataset_id:
            return f"`{self.dataset_id}`.`{table_name}`"
        elif self.project_id:
            return f"`{self.project_id}`.`{table_name}`"

        return f"`{table_name}`"

    def query_get_database_version(self, database_version_query: Optional[str] = None) -> str:
        if database_version_query:
            result = self.fetchone(database_version_query)
            return result[0] if result else None
        return "BigQuery"

    def query_get_table_indexes(self, table: str, schema: str | None = None) -> dict[str, dict]:
        schema = self._resolve_dataset(schema)
        query = f"""
            SELECT
                tc.constraint_name,
                kcu.column_name,
                kcu.ordinal_position
            FROM `{self.project_id}.{schema}.INFORMATION_SCHEMA.TABLE_CONSTRAINTS` AS tc
            JOIN `{self.project_id}.{schema}.INFORMATION_SCHEMA.KEY_COLUMN_USAGE` AS kcu
                ON tc.constraint_catalog = kcu.constraint_catalog
                AND tc.constraint_schema = kcu.constraint_schema
                AND tc.constraint_name = kcu.constraint_name
            WHERE tc.table_name = '{table}'
              AND tc.constraint_type = 'PRIMARY KEY'
            ORDER BY kcu.ordinal_position
        """

        try:
            rows = self.fetchall(query)
        except Exception:
            return {}

        indexes = {}
        if rows:
            constraint_name = rows[0][0]
            indexes[constraint_name] = {
                "columns": [],
                "index_type": "PRIMARY KEY",
                "is_primary_key": True,
            }

            for row in rows:
                indexes[constraint_name]["columns"].append(
                    {
                        "column_name": row[1],
                        "column_order": row[2],
                    }
                )

        return indexes

    def get_table_foreign_key_info(self, table_name: str, schema: str | None = None) -> list[dict]:
        schema = self._resolve_dataset(schema)
        query = f"""
            SELECT
                tc.constraint_name,
                tc.table_name,
                kcu.column_name AS fk_column,
                ccu.table_name AS referenced_table,
                ccu.column_name AS referenced_column
            FROM `{self.project_id}.{schema}.INFORMATION_SCHEMA.TABLE_CONSTRAINTS` AS tc
            JOIN `{self.project_id}.{schema}.INFORMATION_SCHEMA.KEY_COLUMN_USAGE` AS kcu
                ON tc.constraint_catalog = kcu.constraint_catalog
                AND tc.constraint_schema = kcu.constraint_schema
                AND tc.constraint_name = kcu.constraint_name
            JOIN `{self.project_id}.{schema}.INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE` AS ccu
                ON tc.constraint_catalog = ccu.constraint_catalog
                AND tc.constraint_schema = ccu.constraint_schema
                AND tc.constraint_name = ccu.constraint_name
            WHERE tc.table_name = '{table_name}'
              AND tc.constraint_type = 'FOREIGN KEY'
            ORDER BY kcu.ordinal_position
        """

        try:
            rows = self.fetchall(query)
        except Exception:
            return []

        return (
            [
                {
                    "constraint_name": row[0],
                    "table_name": row[1],
                    "fk_column": row[2],
                    "referenced_table": row[3],
                    "referenced_column": row[4],
                }
                for row in rows
            ]
            if rows
            else []
        )

    def query_get_table_names(
        self,
        schema: str | None = None,
        with_view: bool = False,
    ) -> dict:
        """
        Get the list of BigQuery tables and optionally views in a dataset.
        :param schema: optional dataset name
        :param with_view: whether to include views
        :return: dictionary with table names and optionally view names
        """
        schema = self._resolve_dataset(schema)
        project = self.project_id
        table_type_condition = "table_type IN ('BASE TABLE', 'VIEW')" if with_view else "table_type = 'BASE TABLE'"
        query = (
            f"SELECT table_name, table_type FROM `{project}.{schema}.INFORMATION_SCHEMA.TABLES` "
            f"WHERE {table_type_condition} "
            "ORDER BY table_name"
        )
        rows = self.fetchall(query)

        if with_view:
            result = {"table": [], "view": []}
            if rows:
                for row in rows:
                    table_name = row[0]
                    table_type = row[1].strip() if row[1] else row[1]

                    if table_type == "BASE TABLE":
                        result["table"].append(table_name)
                    elif table_type == "VIEW":
                        result["view"].append(table_name)
            return result

        return {"table": [row[0] for row in rows]} if rows else {"table": []}

    def fetch_rows(
        self,
        query: str,
        limit: int = 1,
        with_column_names: bool = False,
        complete_query: Optional[str] = None,
    ) -> Tuple[List, Optional[List[str]]]:
        query = complete_query or f"SELECT * FROM ({query}) AS subquery LIMIT {limit}"

        result = self.connection.execute(text(query))
        rows = result.fetchmany(limit)

        if with_column_names:
            column_names = [desc[0] for desc in result.cursor.description]
            return rows, column_names
        else:
            return rows, None

    def query_get_table_columns(
        self,
        table: str,
        schema: str | None = None,
    ) -> RawColumnInfo:
        """
        Get the list of tables in the database.
        :param schema: optional schema name
        :return: list of table names
        """
        schema = self._resolve_dataset(schema)
        query = (
            "SELECT column_name, data_type, "
            "NULL AS datetime_precision, "
            "NULL AS numeric_precision, "
            "NULL AS numeric_scale, "
            "NULL AS collation_name, "
            "NULL AS character_maximum_length "
            f"FROM `{self.project_id}.{schema}.INFORMATION_SCHEMA.COLUMNS` "
            f"WHERE table_name = '{table}'"
        )

        rows = self.fetchall(query)
        if not rows:
            raise RuntimeError(f"{table}: Table, {schema}: Schema, does not exist, or has no columns")
        column_info = {
            r[0]: RawColumnInfo(
                column_name=self.safe_get(r, 0),
                data_type=self.safe_get(r, 1),
                datetime_precision=self.safe_get(r, 2),
                numeric_precision=self.safe_get(r, 3),
                numeric_scale=self.safe_get(r, 4),
                collation_name=self.safe_get(r, 5),
                character_maximum_length=self.safe_get(r, 6),
            )
            for r in rows
        }
        return column_info

    def fetch_sample_values_from_database(
        self,
        table_name: str,
        column_names: list[str],
        limit: int = 5,
    ) -> Tuple[List[Tuple], List[str]]:
        schema = self._resolve_dataset(self.schema_name)

        if not column_names:
            raise ValueError("At least one column name must be provided")

        full_table_name = f"`{self.project_id}.{schema}.{table_name}`"
        if len(column_names) == 1 and column_names[0] == "*":
            query = f"SELECT * FROM {full_table_name} LIMIT {limit}"
        else:
            columns = ", ".join([self.quote_column(col) for col in column_names])
            query = f"SELECT {columns} FROM {full_table_name} LIMIT {limit}"

        result = self.connection.execute(text(query))
        column_names = [desc[0] for desc in result.cursor.description]
        rows = self.normalize_sample_rows(result.fetchall())
        return rows, column_names

    def create_view(
        self,
        query: Optional[str] = None,
        dataset: Optional[str] = None,
        view_name: Optional[str] = None,
    ) -> str | None:
        view_name = self.generate_view_name(view_name=view_name)
        dataset = self._resolve_dataset(dataset)
        full_name = f"`{self.project_id}`.`{dataset}`.`{view_name}`" if dataset else f"`{view_name}`"
        try:
            if query is None:
                create_view_query = f"CREATE VIEW {full_name} AS SELECT 1 AS dummy_column WHERE FALSE"
                self.connection.execute(create_view_query)
                return full_name
            else:
                create_view_query = f"CREATE VIEW {full_name} AS {query}"
                self.connection.execute(create_view_query)
                return full_name
        except Exception as e:
            logger.error(f"Error creating view: {e}")
            return None

    def drop_view(self, view_name: str, dataset: Optional[str] = None) -> bool:
        dataset = self._resolve_dataset(dataset)
        full_name = f"`{self.project_id}`.`{dataset}`.`{view_name}`" if dataset else f"`{view_name}`"
        try:
            drop_view_query = f"DROP VIEW {full_name}"
            self.connection.execute(drop_view_query)
            return True
        except Exception as e:
            logger.error(f"Error dropping view: {e}")
            return False

    def query_views_defination(self, schema: str) -> Dict[str, str]:
        dataset = self._resolve_dataset(schema)
        query = f"""
            SELECT table_name, view_definition
            FROM `{self.project_id}.{dataset}.INFORMATION_SCHEMA.VIEWS`
        """
        rows = self.fetchall(query)
        return {row[0]: row[1] for row in rows} if rows else {}

    def query_all_procedures_defination(self, schema: str) -> Dict[str, str]:
        dataset = self._resolve_dataset(schema)
        query = f"""
            SELECT routine_name, routine_definition
            FROM `{self.project_id}.{dataset}.INFORMATION_SCHEMA.ROUTINES`
            WHERE routine_type IN ('PROCEDURE', 'FUNCTION')
        """
        rows = self.fetchall(query)
        return {row[0]: row[1] for row in rows if row[1]} if rows else {}

    def query_trigger_definitions(self, schema: str) -> Dict[str, str]:
        return {}

    def get_trigger_dependency_map(self, schema: str) -> Dict[str, List[str]]:
        return {}

    def query_sequences(self, schema: str) -> Dict[str, dict]:
        return {}

    def get_view_dependency_map(self, schema: str) -> Dict[str, List[str]]:
        rows = self.query_views_defination(schema).items()
        result: Dict[str, List[str]] = {}
        for view_name, definition in rows or []:
            if definition:
                result[view_name] = self._extract_tables_from_sql(view_name, definition)
        return result

    def get_procedure_dependency_map(self, schema: str) -> Dict[str, List[str]]:
        rows = self.query_all_procedures_defination(schema).items()
        result: Dict[str, List[str]] = {}
        for proc_name, definition in rows or []:
            if definition:
                result[proc_name] = self._extract_tables_from_sql(proc_name, definition)
        return result
