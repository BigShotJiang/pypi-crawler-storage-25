#  Copyright 2022-present, the Waterdip Labs Pvt. Ltd.
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.
import datetime
import math
import os
from decimal import Decimal
from typing import Any, Dict, List, Optional, Tuple
from uuid import UUID

import duckdb
from loguru import logger

from dcs_core.core.common.errors import DataChecksDataSourcesConnectionError
from dcs_core.core.common.models.data_source_resource import RawColumnInfo
from dcs_core.core.datasource.sql_datasource import SQLDataSource


class DuckDb(SQLDataSource):
    SQLGLOT_DIALECT = "duckdb"

    def __init__(self, data_source_name: str, data_connection: Dict):
        super().__init__(data_source_name, data_connection)
        self.connection = None
        self.use_sa_text_query = False
        self.regex_patterns = {
            "uuid": r"^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$",
            "usa_phone": r"^(\+1[-.\s]?)?(\(?\d{3}\)?[-.\s]?)?\d{3}[-.\s]?\d{4}$",
            "email": r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$",
            "usa_zip_code": r"^[0-9]{5}(?:-[0-9]{4})?$",
            "ssn": r"^[0-9]{3}-[0-9]{2}-[0-9]{4}$",
            "sedol": r"^[B-DF-HJ-NP-TV-XZ0-9]{6}[0-9]$",
            "lei": r"^[A-Z0-9]{18}[0-9]{2}$",
            "cusip": r"^[0-9A-Z]{9}$",
            "figi": r"^BBG[A-Z0-9]{9}$",
            "isin": r"^[A-Z]{2}[A-Z0-9]{9}[0-9]$",
            "perm_id": r"^\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{3}$",
        }
        self.DEFAULT_NUMERIC_PRECISION = 16383

    def connect(self) -> Any:
        """
        Connect to the file data source
        """
        try:
            file_path = self.data_connection.get("file_path")
            self.connection = duckdb.connect(database=file_path)
            return self.connection
        except Exception as e:
            raise DataChecksDataSourcesConnectionError(f"Failed to connect to DuckDB: {e}")

    def is_connected(self) -> bool:
        """
        Check if the file data source is connected
        """
        return self.connection is not None

    def close(self):
        """
        Close the connection
        """
        logger.info("Closing DuckDB connection")
        if self.connection:
            self.connection.close()
        try:
            fp = self.data_connection.get("file_path")
            if fp and os.path.exists(fp):
                os.remove(fp)
        except Exception as e:
            logger.error(f"Failed to remove the file {self.data_connection.get('file_path')}: {e}")

    def qualified_table_name(self, table_name: str) -> str:
        """
        Get the qualified table name
        :param table_name: name of the table
        :return: qualified table name
        """
        return f'"{table_name}"'

    def quote_column(self, column: str) -> str:
        """
        Quote the column name
        :param column: name of the column
        :return: quoted column name
        """
        return f'"{column}"'

    def query_get_table_columns(
        self,
        table: str,
        schema: str | None = None,
    ) -> Dict[str, RawColumnInfo]:
        """
        Get the schema of a table.
        :param table: table name
        :return:  Dictionary with column names and their types
        """
        schema = schema or self.schema_name
        info_schema_path = ["information_schema", "columns"]
        if self.database:
            database = self.quote_database(self.database)
            info_schema_path.insert(0, database)

        query = f"""
            SELECT
                column_name,
                data_type,
                CASE WHEN data_type IN ('TIMESTAMP', 'TIME') THEN datetime_precision ELSE NULL END AS datetime_precision,
                CASE WHEN data_type = 'DECIMAL' THEN COALESCE(numeric_precision, 131072 + {self.DEFAULT_NUMERIC_PRECISION})
                     WHEN data_type IN ('DOUBLE', 'REAL', 'FLOAT') THEN numeric_precision
                     ELSE numeric_precision END AS numeric_precision,
                CASE WHEN data_type = 'DECIMAL' THEN COALESCE(numeric_scale, {self.DEFAULT_NUMERIC_PRECISION}) ELSE numeric_scale END AS numeric_scale,
                NULL AS collation_name,
                CASE WHEN data_type = 'VARCHAR' THEN character_maximum_length ELSE NULL END AS character_maximum_length
            FROM information_schema.columns
            WHERE table_name = '{table}'
            ORDER BY ordinal_position
        """

        rows = self.fetchall(query)
        if not rows:
            raise RuntimeError(f"{table}: Table, {schema}: Schema, does not exist, or has no columns")

        column_info = {
            r[0]: RawColumnInfo(
                column_name=self.safe_get(r, 0),
                data_type=self.safe_get(r, 1),
                datetime_precision=self.safe_get(r, 2),
                numeric_precision=self.safe_get(r, 3),
                numeric_scale=self.safe_get(r, 4),
                collation_name=self.safe_get(r, 5),
                character_maximum_length=self.safe_get(r, 6),
            )
            for r in rows
        }
        return column_info

    def query_get_table_indexes(self, table: str, schema: str | None = None) -> dict:
        return {}

    def get_table_foreign_key_info(self, table_name: str, schema: str | None = None) -> list:
        return []

    def fetch_sample_values_from_database(
        self,
        table_name: str,
        column_names: List[str],
        limit: int = 50,
    ) -> Tuple[List[Tuple], List[str]]:
        qualified = self.qualified_table_name(table_name)
        if len(column_names) == 1 and column_names[0] == "*":
            query = f"SELECT * FROM {qualified} LIMIT {limit}"
        else:
            cols = ", ".join([self.quote_column(col) for col in column_names])
            query = f"SELECT {cols} FROM {qualified} LIMIT {limit}"

        result = self.connection.execute(query)
        col_names = [desc[0] for desc in result.description]
        rows = self.normalize_sample_rows(result.fetchall())
        return rows, col_names

    def build_table_metrics_query(
        self,
        table_name: str,
        column_info: list[dict],
        additional_queries: Optional[List[str]] = None,
    ) -> list[dict]:
        if not column_info:
            return []

        qualified_table = self.qualified_table_name(table_name)

        _numeric_dtypes = frozenset(
            (
                "integer",
                "bigint",
                "smallint",
                "tinyint",
                "hugeint",
                "decimal",
                "numeric",
                "float",
                "double",
                "real",
            )
        )
        _integer_dtypes = frozenset(
            (
                "integer",
                "bigint",
                "smallint",
                "tinyint",
                "hugeint",
            )
        )

        # --- build aggregation SELECT ---
        query_parts = []
        for col in column_info:
            name = col["column_name"]
            dtype = col["data_type"].lower()
            quoted = self.quote_column(name)

            query_parts.append(f'COUNT(DISTINCT {quoted}) AS "{name}_distinct"')
            query_parts.append(f'COUNT(*) - COUNT(DISTINCT {quoted}) AS "{name}_duplicate"')
            query_parts.append(f'SUM(CASE WHEN {quoted} IS NULL THEN 1 ELSE 0 END) AS "{name}_is_null"')

            if dtype in _numeric_dtypes:
                query_parts.append(f'MIN({quoted}) AS "{name}_min"')
                query_parts.append(f'MAX({quoted}) AS "{name}_max"')
                query_parts.append(f'AVG({quoted}) AS "{name}_average"')
            elif dtype in ("varchar", "text", "char"):
                query_parts.append(f'MAX(LENGTH({quoted})) AS "{name}_max_character_length"')

        if additional_queries:
            query_parts.extend(additional_queries)

        joined_parts = ",\n    ".join(query_parts)
        query = f"SELECT\n    {joined_parts}\nFROM {qualified_table};"

        result = self.connection.execute(query)
        col_names = [desc[0] for desc in result.description]
        raw_row = result.fetchone()
        row = dict(zip(col_names, raw_row))

        def _normalize_metrics(value):
            if value is None:
                return None
            if isinstance(value, bool):
                return value
            if isinstance(value, Decimal):
                return float(value)
            if isinstance(value, (int, float)):
                return value
            if isinstance(value, datetime.datetime):
                return value.isoformat()
            if isinstance(value, datetime.date):
                return value.isoformat()
            if isinstance(value, datetime.timedelta):
                return str(value)
            if isinstance(value, datetime.time):
                return value.isoformat()
            if isinstance(value, UUID):
                return str(value)
            if isinstance(value, bytes):
                try:
                    return value.decode("utf-8")
                except Exception:
                    return value.hex()
            if isinstance(value, list):
                return [_normalize_metrics(v) for v in value]
            if isinstance(value, dict):
                return {k: _normalize_metrics(v) for k, v in value.items()}
            return str(value)

        # --- assemble per-column metrics ---
        # Longest-prefix-wins: if columns "foo" and "foo_bar" both exist,
        # key "foo_bar_distinct" belongs to "foo_bar" not "foo".
        key_owner: dict[str, str] = {}
        for col in column_info:
            n = col["column_name"]
            for key in row:
                if key.startswith(f"{n}_"):
                    if key not in key_owner or len(n) > len(key_owner[key]):
                        key_owner[key] = n

        column_wise = []
        for col in column_info:
            name = col["column_name"]
            col_metrics = {
                key[len(name) + 1 :]: _normalize_metrics(value)
                for key, value in row.items()
                if key_owner.get(key) == name
            }
            column_wise.append({"column_name": name, "metrics": col_metrics})

        # --- distribution graphs ---
        for col_data in column_wise:
            metrics = col_data["metrics"]
            distinct_count = metrics.get("distinct")
            col_name = col_data["column_name"]
            dtype = next(c["data_type"].lower() for c in column_info if c["column_name"] == col_name)
            quoted = self.quote_column(col_name)

            if dtype in _numeric_dtypes:
                col_min = metrics.get("min")
                col_max = metrics.get("max")
                if col_min is not None and col_max is not None and col_min != col_max:
                    col_min = float(col_min)
                    col_max = float(col_max)
                    bucket_count = 20
                    bucket_size = (col_max - col_min) / bucket_count
                    bucket_queries = [
                        f"SUM(CASE WHEN {quoted} >= {col_min + i * bucket_size} "
                        f"AND {quoted} < {col_min + (i + 1) * bucket_size} "
                        f'THEN 1 ELSE 0 END) AS "bucket_{i}"'
                        for i in range(bucket_count)
                    ]
                    bucket_sql = f"SELECT {', '.join(bucket_queries)} FROM {qualified_table}"
                    try:
                        bucket_result = self.connection.execute(bucket_sql).fetchone()
                        distribution = []
                        for i in range(bucket_count):
                            start_raw = col_min + i * bucket_size
                            end_raw = col_min + (i + 1) * bucket_size
                            if dtype in _integer_dtypes:
                                start, end = math.floor(start_raw), math.ceil(end_raw)
                            else:
                                start, end = round(start_raw, 2), round(end_raw, 2)
                            distribution.append(
                                {"col_val": f"{start} - {end}", "count": _normalize_metrics(bucket_result[i])}
                            )
                        metrics["distribution_graph"] = distribution
                    except Exception as e:
                        print(f"Failed to generate numeric distribution for {col_name}: {e}")
                continue

            if isinstance(distinct_count, (int, float)) and distinct_count <= 20:
                dist_query = (
                    f"SELECT {quoted}, COUNT(*) FROM {qualified_table} " f"GROUP BY {quoted} ORDER BY COUNT(*) DESC"
                )
                try:
                    dist_result = self.connection.execute(dist_query).fetchall()
                    metrics["distribution_graph"] = [
                        {"col_val": _normalize_metrics(r[0]), "count": _normalize_metrics(r[1])} for r in dist_result
                    ]
                except Exception as e:
                    print(f"Failed to generate distribution graph for column {col_name}: {e}")

        # --- final formatting ---
        for col_data in column_wise:
            metrics = col_data["metrics"]
            dtype = next(c["data_type"].lower() for c in column_info if c["column_name"] == col_data["column_name"])
            col_data["metrics"] = {
                "general_data": {k: v for k, v in metrics.items() if k != "distribution_graph"},
                "is_dtype_numeric": dtype in _numeric_dtypes,
                "distribution_data": metrics.get("distribution_graph", []),
            }

        return column_wise

    def query_sequences(self, schema: str) -> Dict[str, dict]:
        schema = schema or self.schema_name
        query = f"""
            SELECT sequence_name, start_value, increment_by, min_value,
                   max_value, last_value, cycle
            FROM duckdb_sequences()
            WHERE schema_name = '{schema}'
        """
        rows = self.fetchall(query)
        return (
            {
                row[0]: {
                    "start_value": row[1],
                    "increment": row[2],
                    "min_value": row[3],
                    "max_value": row[4],
                    "current_value": row[5],
                    "cycle": row[6],
                }
                for row in rows
            }
            if rows
            else {}
        )
