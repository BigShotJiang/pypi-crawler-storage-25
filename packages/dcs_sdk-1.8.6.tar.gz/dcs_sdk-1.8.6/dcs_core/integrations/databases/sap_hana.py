#  Copyright 2022-present, the Waterdip Labs Pvt. Ltd.
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

import datetime
import math
import re
from decimal import Decimal
from typing import Any, Dict, List, Optional, Tuple, Union
from uuid import UUID

from loguru import logger

from dcs_core.core.common.errors import DataChecksDataSourcesConnectionError
from dcs_core.core.common.models.data_source_resource import RawColumnInfo
from dcs_core.core.datasource.sql_datasource import SQLDataSource


class _HdbcliRow:
    """Mimics a SQLAlchemy Row with ._mapping support."""

    def __init__(self, row, keys):
        self._row = row
        self._mapping = dict(zip(keys, row))

    def __getitem__(self, idx):
        return self._row[idx]

    def __iter__(self):
        return iter(self._row)

    def __len__(self):
        return len(self._row)

    def __repr__(self):
        return repr(self._row)


class _HdbcliResult:
    """Wraps an hdbcli cursor to mimic a SQLAlchemy result proxy."""

    def __init__(self, cursor):
        self._cursor = cursor
        self._description = cursor.description or []
        self._keys = [d[0] for d in self._description]
        # DDL statements (CREATE/DROP VIEW, etc.) have no result set — guard fetchall()
        try:
            rows = cursor.fetchall() if self._description else []
        except Exception:
            rows = []
        self._rows = [_HdbcliRow(r, self._keys) for r in rows]

    @property
    def cursor(self):
        return self._cursor

    def fetchall(self):
        return self._rows

    def fetchone(self):
        return self._rows[0] if self._rows else None

    def fetchmany(self, size):
        return self._rows[:size]

    def __iter__(self):
        return iter(self._rows)


class _HdbcliConnection:
    """Wraps a raw hdbcli connection to mimic SQLAlchemy's Connection interface."""

    def __init__(self, conn):
        self._conn = conn
        self.engine = _NoOpEngine()

    def execute(self, query_or_text, *args, **kwargs):
        # Accept both SQLAlchemy text() objects and plain strings
        sql = str(query_or_text) if not isinstance(query_or_text, str) else query_or_text
        cursor = self._conn.cursor()
        cursor.execute(sql)
        return _HdbcliResult(cursor)

    def commit(self):
        try:
            self._conn.commit()
        except Exception:
            pass

    def close(self):
        self._conn.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()


class _NoOpEngine:
    def dispose(self):
        pass


class SapHanaDataSource(SQLDataSource):
    # sqlglot does not support a dedicated "hana" dialect name.
    # Use the generic parser for dependency extraction after HANA-specific normalization.
    SQLGLOT_DIALECT = None

    def __init__(self, data_source_name: str, data_connection: Dict):
        super().__init__(data_source_name, data_connection)
        self.use_sa_text_query = False

    def connect(self) -> Any:
        try:
            import hdbcli.dbapi as hdbcli

            host = self.data_connection.get("host")
            port = int(self.data_connection.get("port", 30015))
            username = self.data_connection.get("username")
            password = self.data_connection.get("password")
            database = self.data_connection.get("database")
            schema = self.data_connection.get("schema") or database

            self.schema_name = schema

            raw_conn = hdbcli.connect(
                address=host,
                port=port,
                user=username,
                password=password,
                databaseName=database,
                currentSchema=schema,
                autocommit=True,
            )
            self.connection = _HdbcliConnection(raw_conn)
            return self.connection
        except Exception as e:
            raise DataChecksDataSourcesConnectionError(message=f"Failed to connect to SAP HANA data source: [{str(e)}]")

    def qualified_table_name(self, table_name: str) -> str:
        schema = self.schema_name or self.database
        if schema:
            return f'"{schema}"."{table_name}"'
        return f'"{table_name}"'

    def quote_column(self, column: str) -> str:
        return f'"{column}"'

    def _hana_view_name(self, schema: str | None, view_name: str) -> str:
        s = schema or self.schema_name or self.database
        if s:
            return f'"{s}"."{view_name}"'
        return f'"{view_name}"'

    @staticmethod
    def _escape_sql_literal(value: Any) -> str:
        return str(value).replace("'", "''")

    @classmethod
    def _metadata_name_variants(cls, name: str) -> list[str]:
        stripped = str(name).strip()
        if "." in stripped:
            stripped = stripped.split(".")[-1]
        stripped = stripped.strip('"')
        variants = [stripped, stripped.upper(), stripped.lower()]
        return list(dict.fromkeys(v for v in variants if v))

    @classmethod
    def _metadata_name_filter(cls, column: str, name: str) -> str:
        literals = ", ".join(f"'{cls._escape_sql_literal(value)}'" for value in cls._metadata_name_variants(name))
        return f"{column} IN ({literals})"

    def _normalize_metadata_path(self, table_name: str, schema: str | None = None) -> tuple[str, str]:
        normalized_schema = schema or self.schema_name or self.database
        normalized_name = str(table_name).strip()

        if "." in normalized_name:
            parts = [part.strip().strip('"') for part in normalized_name.split(".") if part.strip()]
            if len(parts) >= 2:
                normalized_schema = parts[-2]
                normalized_name = parts[-1]
            else:
                normalized_name = parts[-1]
        else:
            normalized_name = normalized_name.strip('"')

        return normalized_schema, normalized_name

    def _query_hana_columns(self, schema: str, table_name: str):
        schema_literal = self._escape_sql_literal(schema)
        table_literal = self._escape_sql_literal(table_name)
        exact_query = (
            "SELECT COLUMN_NAME, DATA_TYPE_NAME, DT_PREC, COL_LEN, COL_SCALE, COL_COLL, COL_LEN2 "
            "FROM ("
            "SELECT COLUMN_NAME, LOWER(DATA_TYPE_NAME) AS DATA_TYPE_NAME, NULL AS DT_PREC, LENGTH AS COL_LEN, SCALE AS COL_SCALE, NULL AS COL_COLL, LENGTH AS COL_LEN2, POSITION "
            "FROM SYS.TABLE_COLUMNS "
            f"WHERE TABLE_NAME = '{table_literal}' AND SCHEMA_NAME = '{schema_literal}' "
            "UNION ALL "
            "SELECT COLUMN_NAME, LOWER(DATA_TYPE_NAME) AS DATA_TYPE_NAME, NULL AS DT_PREC, LENGTH AS COL_LEN, SCALE AS COL_SCALE, NULL AS COL_COLL, LENGTH AS COL_LEN2, POSITION "
            "FROM SYS.VIEW_COLUMNS "
            f"WHERE VIEW_NAME = '{table_literal}' AND SCHEMA_NAME = '{schema_literal}' "
            ") hana_cols ORDER BY POSITION"
        )
        rows = self.fetchall(exact_query)
        if rows:
            return rows

        table_filter = self._metadata_name_filter("TABLE_NAME", table_name)
        view_filter = self._metadata_name_filter("VIEW_NAME", table_name)
        fallback_query = (
            "SELECT COLUMN_NAME, DATA_TYPE_NAME, DT_PREC, COL_LEN, COL_SCALE, COL_COLL, COL_LEN2 "
            "FROM ("
            "SELECT COLUMN_NAME, LOWER(DATA_TYPE_NAME) AS DATA_TYPE_NAME, NULL AS DT_PREC, LENGTH AS COL_LEN, SCALE AS COL_SCALE, NULL AS COL_COLL, LENGTH AS COL_LEN2, POSITION "
            "FROM SYS.TABLE_COLUMNS "
            f"WHERE {table_filter} AND SCHEMA_NAME = '{schema_literal}' "
            "UNION ALL "
            "SELECT COLUMN_NAME, LOWER(DATA_TYPE_NAME) AS DATA_TYPE_NAME, NULL AS DT_PREC, LENGTH AS COL_LEN, SCALE AS COL_SCALE, NULL AS COL_COLL, LENGTH AS COL_LEN2, POSITION "
            "FROM SYS.VIEW_COLUMNS "
            f"WHERE {view_filter} AND SCHEMA_NAME = '{schema_literal}' "
            ") hana_cols ORDER BY POSITION"
        )
        rows = self.fetchall(fallback_query)
        return rows

    @staticmethod
    def _normalize_sqlscript_definition(definition: str | None) -> str:
        if not definition:
            return ""

        normalized = str(definition).strip()
        normalized = re.sub(r"--.*?$", "", normalized, flags=re.MULTILINE)
        normalized = re.sub(r"/\*.*?\*/", "", normalized, flags=re.DOTALL)

        begin_match = re.search(r"\bBEGIN\b(.*)\bEND\b", normalized, flags=re.IGNORECASE | re.DOTALL)
        if begin_match:
            normalized = begin_match.group(1).strip()

        # HANA SQLScript often uses `SELECT ... INTO out_var FROM ...`; sqlglot handles plain SELECT better.
        normalized = re.sub(
            r"\bINTO\s+[A-Za-z_][A-Za-z0-9_]*\s+FROM\b",
            " FROM",
            normalized,
            flags=re.IGNORECASE,
        )

        normalized = re.sub(r"^\s*DECLARE\b[^;]*;?", "", normalized, flags=re.IGNORECASE | re.MULTILINE)
        normalized = re.sub(r"\bDECLARE\s+EXIT\s+HANDLER\b[^;]*;?", "", normalized, flags=re.IGNORECASE)
        normalized = re.sub(r"\bDECLARE\s+[A-Za-z_][A-Za-z0-9_]*\s+\w+[^;]*;?", "", normalized, flags=re.IGNORECASE)
        normalized = re.sub(r"\b[A-Za-z_][A-Za-z0-9_]*\s*:=\s*[^;]*;?", "", normalized, flags=re.IGNORECASE)
        normalized = re.sub(r"\bIF\b", "", normalized, flags=re.IGNORECASE)
        normalized = re.sub(r"\bTHEN\b", "", normalized, flags=re.IGNORECASE)
        normalized = re.sub(r"\bELSE\b", "", normalized, flags=re.IGNORECASE)
        normalized = re.sub(r"\bEND IF\b\s*;?", "", normalized, flags=re.IGNORECASE)
        normalized = re.sub(r"\bSIGNAL\b[^;]*;?", "", normalized, flags=re.IGNORECASE)
        normalized = re.sub(r"\bRESIGNAL\b[^;]*;?", "", normalized, flags=re.IGNORECASE)
        normalized = re.sub(r"\bFOR SHARE LOCK OF\b[^;]*", "", normalized, flags=re.IGNORECASE)
        normalized = re.sub(r"^\s*AS\s*", "", normalized, flags=re.IGNORECASE)
        normalized = re.sub(r"\s+", " ", normalized).strip()

        sql_statements = re.findall(
            r"(?is)\b(?:WITH|SELECT|INSERT\s+INTO|UPDATE|DELETE\s+FROM|MERGE\s+INTO)\b.*?(?=;|$)",
            normalized,
        )
        if sql_statements:
            return "; ".join(statement.strip() for statement in sql_statements if statement.strip())

        return normalized

    @classmethod
    def _normalize_trigger_definition(cls, definition: str | None) -> str:
        if not definition:
            return ""

        normalized = str(definition).strip()
        if re.match(r"^\s*CREATE\s+(OR\s+REPLACE\s+)?TRIGGER\b", normalized, flags=re.IGNORECASE):
            return normalized

        return cls._normalize_sqlscript_definition(normalized)

    def _prepare_sql_for_dependency_extraction(self, object_name: str, sql: str) -> str:
        return self._normalize_sqlscript_definition(sql)

    def _fetch_first_working_query(self, queries: List[Tuple[str, callable]]):
        last_error = None
        for query, transform in queries:
            try:
                rows = self.fetchall(query)
                return transform(rows or [])
            except Exception as e:
                last_error = e
        if last_error:
            raise last_error
        return None

    @staticmethod
    def _hana_numeric_types() -> frozenset[str]:
        return frozenset(
            (
                "integer",
                "int",
                "bigint",
                "smallint",
                "tinyint",
                "decimal",
                "numeric",
                "float",
                "double",
                "real",
                "number",
                "smalldecimal",
            )
        )

    @staticmethod
    def _hana_string_types() -> frozenset[str]:
        return frozenset(("varchar", "nvarchar", "char", "nchar", "alphanum"))

    @staticmethod
    def _hana_datetime_types() -> frozenset[str]:
        return frozenset(("date", "time", "timestamp", "seconddate"))

    @staticmethod
    def _hana_boolean_types() -> frozenset[str]:
        return frozenset(("boolean",))

    @staticmethod
    def _hana_lob_like_types() -> frozenset[str]:
        return frozenset(("clob", "nclob", "text", "shorttext"))

    @staticmethod
    def _hana_binary_or_complex_types() -> frozenset[str]:
        return frozenset(
            (
                "blob",
                "binary",
                "varbinary",
                "bintxt",
                "array",
                "st_geometry",
                "st_point",
            )
        )

    def _build_sample_select_expression(self, column_name: str, data_type: str) -> str:
        quoted = self.quote_column(column_name)
        alias = self.quote_column(column_name)
        dtype = (data_type or "").lower()

        if dtype in self._hana_lob_like_types():
            return f"SUBSTRING(TO_NVARCHAR({quoted}), 1, 255) AS {alias}"

        if dtype in self._hana_binary_or_complex_types():
            return f"CAST(NULL AS NVARCHAR(255)) AS {alias}"

        return f"{quoted} AS {alias}"

    def _fetch_column_top_values(self, table_name: str, column_name: str, data_type: str, limit: int = 5) -> list:
        dtype = (data_type or "").lower()
        if dtype in self._hana_binary_or_complex_types():
            return []

        try:
            rows, _ = self.fetch_sample_values_from_database(
                table_name=table_name,
                column_names=[column_name],
                limit=max(limit * 2, limit),
            )
        except Exception as e:
            logger.warning(f"Failed to fetch top values for SAP HANA column {table_name}.{column_name}: {e}")
            return []

        seen = set()
        values = []
        for row in rows or []:
            value = row[0] if len(row) > 0 else None
            normalized = self._normalize_metric_value(value)
            dedupe_key = str(normalized) if normalized is not None else None
            if dedupe_key in (None, "") or dedupe_key in seen:
                continue
            seen.add(dedupe_key)
            values.append(normalized)
            if len(values) >= limit:
                break
        return values

    @staticmethod
    def _normalize_metric_value(value):
        if value is None:
            return None
        if isinstance(value, bool):
            return value
        if isinstance(value, Decimal):
            return float(value)
        if isinstance(value, (int, float)):
            return value
        if isinstance(value, datetime.datetime):
            return value.isoformat()
        if isinstance(value, datetime.date):
            return value.isoformat()
        if isinstance(value, datetime.timedelta):
            return str(value)
        if isinstance(value, datetime.time):
            return value.isoformat()
        if isinstance(value, UUID):
            return str(value)
        if isinstance(value, bytes):
            try:
                return value.decode("utf-8")
            except Exception:
                return value.hex()
        if isinstance(value, list):
            return [SapHanaDataSource._normalize_metric_value(v) for v in value]
        if isinstance(value, dict):
            return {k: SapHanaDataSource._normalize_metric_value(v) for k, v in value.items()}
        return str(value)

    def create_view(
        self,
        query: str | None = None,
        schema: str | None = None,
        view_name: str | None = None,
    ) -> str | None:
        view_name = self.generate_view_name(view_name=view_name)
        view_name_full = self._hana_view_name(schema, view_name)

        # HANA requires FROM DUMMY for a dummy select (no implicit FROM)
        if query is None:
            sql = f"CREATE VIEW {view_name_full} AS SELECT 1 AS dummy FROM DUMMY WHERE 1 = 0"
        else:
            sql = f"CREATE VIEW {view_name_full} AS {query}"

        try:
            self.connection.execute(sql)
            return view_name_full
        except Exception as e:
            logger.error(f"Error creating view {view_name_full}: {e}")
            return None

    def drop_view(self, view_name: str, schema: str | None) -> bool:
        # view_name may already be fully qualified with quotes — use as-is if so
        if '"' in view_name:
            full_view_name = view_name
        else:
            full_view_name = self._hana_view_name(schema, view_name)
        try:
            self.connection.execute(f"DROP VIEW {full_view_name}")
            return True
        except Exception as e:
            logger.error(f"Error dropping view {full_view_name}: {e}")
            return False

    def query_get_database_version(self, database_version_query: Optional[str] = None) -> str:
        query = database_version_query or "SELECT VERSION FROM SYS.M_DATABASE"
        try:
            result = self.fetchone(query)
            return str(result[0]) if result else "unknown"
        except Exception as e:
            logger.warning(f"Failed to get SAP HANA version: {e}")
            return "unknown"

    def query_get_table_names(
        self,
        schema: str | None = None,
        with_view: bool = False,
    ) -> dict:
        schema = schema or self.schema_name or self.database

        if with_view:
            # Tables
            table_query = f"SELECT TABLE_NAME FROM SYS.TABLES WHERE SCHEMA_NAME = '{schema}'"
            # Views
            view_query = f"SELECT VIEW_NAME FROM SYS.VIEWS WHERE SCHEMA_NAME = '{schema}'"
            table_rows = self.fetchall(table_query) or []
            view_rows = self.fetchall(view_query) or []
            return {
                "table": [r[0] for r in table_rows],
                "view": [r[0] for r in view_rows],
            }
        else:
            query = f"SELECT TABLE_NAME FROM SYS.TABLES WHERE SCHEMA_NAME = '{schema}'"
            rows = self.fetchall(query) or []
            return {"table": [r[0] for r in rows]}

    def query_get_table_columns(self, table: str, schema: str | None = None) -> RawColumnInfo:
        schema, table_name = self._normalize_metadata_path(table, schema)
        rows = self._query_hana_columns(schema=schema, table_name=table_name)
        if not rows:
            raise RuntimeError(f"{table_name}: Table, {schema}: Schema, does not exist, or has no columns")

        column_info = {
            r[0]: RawColumnInfo(
                column_name=self.safe_get(r, 0),
                data_type=self.safe_get(r, 1),
                datetime_precision=self.safe_get(r, 2),
                numeric_precision=self.safe_get(r, 3),
                numeric_scale=self.safe_get(r, 4),
                collation_name=self.safe_get(r, 5),
                character_maximum_length=self.safe_get(r, 6),
            )
            for r in rows
        }
        return column_info

    def fetch_rows(
        self,
        query: str,
        limit: int = 1,
        with_column_names: bool = False,
        complete_query: Optional[str] = None,
    ) -> Tuple[List, Optional[List[str]]]:
        # HANA requires named alias for derived tables (no anonymous "AS subquery")
        query = complete_query or f"SELECT * FROM ({query}) hana_subq LIMIT {limit}"
        result = self.connection.execute(query)
        rows = result.fetchmany(limit)

        if with_column_names:
            column_names = result._keys
            return rows, column_names
        return rows, None

    def fetch_sample_values_from_database(
        self,
        table_name: str,
        column_names: list[str],
        limit: int = 5,
    ) -> List[Tuple]:
        schema, normalized_table_name = self._normalize_metadata_path(table_name)
        qualified = f'"{schema}"."{normalized_table_name}"' if schema else f'"{normalized_table_name}"'

        if not column_names:
            raise ValueError("At least one column name must be provided")

        schema_columns = self.query_get_table_columns(normalized_table_name, schema=schema)
        available_columns = {col.column_name: col for col in schema_columns.values()}

        if len(column_names) == 1 and column_names[0] == "*":
            selected_columns = list(schema_columns.values())
        else:
            selected_columns = [available_columns[c] for c in column_names if c in available_columns]
            if not selected_columns:
                raise ValueError(f"No valid columns found for table '{table_name}'")

        select_exprs = [
            self._build_sample_select_expression(col.column_name, col.data_type) for col in selected_columns
        ]
        query = f"SELECT {', '.join(select_exprs)} FROM {qualified} LIMIT {limit}"

        result = self.connection.execute(query)
        col_names = result._keys
        rows = self.normalize_sample_rows(result.fetchall())
        return rows, col_names

    def build_table_metrics_query(
        self,
        table_name: str,
        column_info: list[dict],
        additional_queries: Optional[List[str]] = None,
    ) -> list[dict]:
        if not column_info:
            return []

        schema, normalized_table_name = self._normalize_metadata_path(table_name)

        _NUMERIC_TYPES = self._hana_numeric_types()
        _STRING_TYPES = self._hana_string_types()
        _DATETIME_TYPES = self._hana_datetime_types()
        _BOOLEAN_TYPES = self._hana_boolean_types()
        _LOB_TYPES = self._hana_lob_like_types()
        _BINARY_OR_COMPLEX_TYPES = self._hana_binary_or_complex_types()

        query_parts = []
        for col in column_info:
            name = col["column_name"]
            dtype = col["data_type"].lower()
            quoted = self.quote_column(name)
            alias = name.replace('"', "")

            query_parts.append(f'SUM(CASE WHEN {quoted} IS NULL THEN 1 ELSE 0 END) AS "{alias}_is_null"')

            if dtype in _NUMERIC_TYPES:
                query_parts.append(f'COUNT(DISTINCT {quoted}) AS "{alias}_distinct"')
                query_parts.append(f'COUNT(*) - COUNT(DISTINCT {quoted}) AS "{alias}_duplicate"')
                query_parts.append(f'MIN({quoted}) AS "{alias}_min"')
                query_parts.append(f'MAX({quoted}) AS "{alias}_max"')
                query_parts.append(f'AVG(TO_DOUBLE({quoted})) AS "{alias}_average"')
            elif dtype in _STRING_TYPES:
                query_parts.append(f'COUNT(DISTINCT {quoted}) AS "{alias}_distinct"')
                query_parts.append(f'COUNT(*) - COUNT(DISTINCT {quoted}) AS "{alias}_duplicate"')
                query_parts.append(f'MAX(LENGTH({quoted})) AS "{alias}_max_character_length"')
            elif dtype in _DATETIME_TYPES:
                query_parts.append(f'COUNT(DISTINCT {quoted}) AS "{alias}_distinct"')
                query_parts.append(f'COUNT(*) - COUNT(DISTINCT {quoted}) AS "{alias}_duplicate"')
                query_parts.append(f'MIN({quoted}) AS "{alias}_min"')
                query_parts.append(f'MAX({quoted}) AS "{alias}_max"')
            elif dtype in _BOOLEAN_TYPES:
                query_parts.append(f'COUNT(DISTINCT {quoted}) AS "{alias}_distinct"')
                query_parts.append(f'COUNT(*) - COUNT(DISTINCT {quoted}) AS "{alias}_duplicate"')
            elif dtype in _LOB_TYPES:
                query_parts.append(
                    f'MAX(LENGTH(SUBSTRING(TO_NVARCHAR({quoted}), 1, 5000))) AS "{alias}_max_character_length"'
                )
            elif dtype in _BINARY_OR_COMPLEX_TYPES:
                continue

        if additional_queries:
            query_parts.extend(additional_queries)

        qualified = f'"{schema}"."{normalized_table_name}"' if schema else f'"{normalized_table_name}"'
        joined_parts = ",\n    ".join(query_parts)
        query = f"SELECT\n    {joined_parts}\nFROM {qualified}"

        result = self.connection.execute(query)
        row = dict(list(result)[0]._mapping)

        key_owner: dict[str, str] = {}
        for col in column_info:
            n = col["column_name"]
            for key in row:
                if key.startswith(f"{n}_"):
                    if key not in key_owner or len(n) > len(key_owner[key]):
                        key_owner[key] = n

        column_wise = []
        for col in column_info:
            name = col["column_name"]
            col_metrics = {
                key[len(name) + 1 :]: self._normalize_metric_value(value)
                for key, value in row.items()
                if key_owner.get(key) == name
            }
            column_wise.append({"column_name": name, "metrics": col_metrics})

        for col_data in column_wise:
            metrics = col_data["metrics"]
            col_name = col_data["column_name"]
            dtype = next(c["data_type"].lower() for c in column_info if c["column_name"] == col_name)
            quoted = self.quote_column(col_name)
            is_dtype_numeric = dtype in _NUMERIC_TYPES

            if is_dtype_numeric:
                col_min = metrics.get("min")
                col_max = metrics.get("max")

                if col_min is not None and col_max is not None and col_min != col_max:
                    col_min = float(col_min)
                    col_max = float(col_max)
                    bucket_count = 20
                    bucket_size = (col_max - col_min) / bucket_count
                    bucket_queries = []
                    for i in range(bucket_count):
                        start = col_min + i * bucket_size
                        end = col_min + (i + 1) * bucket_size
                        bucket_queries.append(
                            f"SUM(CASE WHEN {quoted} >= {start} AND {quoted} < {end} THEN 1 ELSE 0 END) AS bucket_{i}"
                        )
                    bucket_sql = f"SELECT {', '.join(bucket_queries)} FROM {qualified}"
                    try:
                        bucket_result = self.connection.execute(bucket_sql).fetchone()
                        distribution = []
                        for i in range(bucket_count):
                            start_raw = col_min + i * bucket_size
                            end_raw = col_min + (i + 1) * bucket_size
                            if dtype in ("integer", "int", "bigint", "smallint", "tinyint"):
                                start = math.floor(start_raw)
                                end = math.ceil(end_raw)
                            else:
                                start = round(start_raw, 2)
                                end = round(end_raw, 2)
                            distribution.append(
                                {"col_val": f"{start} - {end}", "count": self._normalize_metric_value(bucket_result[i])}
                            )
                        metrics["distribution_graph"] = distribution
                    except Exception as e:
                        logger.warning(f"Failed to generate numeric distribution for {col_name}: {e}")
                continue

            distinct_count = metrics.get("distinct")
            if isinstance(distinct_count, (int, float)) and distinct_count <= 20:
                dist_query = f"SELECT {quoted}, COUNT(*) FROM {qualified} GROUP BY {quoted} ORDER BY COUNT(*) DESC"
                try:
                    dist_result = self.connection.execute(dist_query).fetchall()
                    distribution = [
                        {"col_val": self._normalize_metric_value(r[0]), "count": self._normalize_metric_value(r[1])}
                        for r in dist_result
                    ]
                    metrics["distribution_graph"] = distribution
                except Exception as e:
                    logger.warning(f"Failed to generate distribution graph for column {col_name}: {e}")

        for col_data in column_wise:
            metrics = col_data["metrics"]
            col_name = col_data["column_name"]
            dtype = next(c["data_type"].lower() for c in column_info if c["column_name"] == col_name)

            if metrics.get("distribution_graph"):
                metrics["top_values"] = [
                    item.get("col_val")
                    for item in metrics["distribution_graph"]
                    if item.get("col_val") not in (None, "")
                ][:5]
            elif dtype not in _BINARY_OR_COMPLEX_TYPES:
                metrics["top_values"] = self._fetch_column_top_values(
                    table_name=normalized_table_name,
                    column_name=col_name,
                    data_type=dtype,
                    limit=5,
                )
            else:
                metrics["top_values"] = []

        for col_data in column_wise:
            metrics = col_data["metrics"]
            dtype = next(c["data_type"].lower() for c in column_info if c["column_name"] == col_data["column_name"])
            is_dtype_numeric = dtype in _NUMERIC_TYPES
            col_data["metrics"] = {
                "general_data": {k: v for k, v in metrics.items() if k != "distribution_graph"},
                "is_dtype_numeric": is_dtype_numeric,
                "distribution_data": metrics.get("distribution_graph", []),
            }

        return column_wise

    def query_get_table_indexes(self, table: str, schema: str | None = None) -> dict[str, dict]:
        schema, table_name = self._normalize_metadata_path(table, schema)
        table_filter = self._metadata_name_filter("i.TABLE_NAME", table_name)
        schema_literal = self._escape_sql_literal(schema)
        query = f"""
            SELECT
                i.INDEX_NAME,
                ic.COLUMN_NAME,
                ic.POSITION,
                i.CONSTRAINT,
                i.INDEX_TYPE
            FROM SYS.INDEXES i
            JOIN SYS.INDEX_COLUMNS ic
                ON i.INDEX_NAME = ic.INDEX_NAME
                AND i.SCHEMA_NAME = ic.SCHEMA_NAME
            WHERE {table_filter}
              AND i.SCHEMA_NAME = '{schema_literal}'
            ORDER BY i.INDEX_NAME, ic.POSITION
        """
        try:
            rows = self.fetchall(query)
        except Exception:
            return {}

        indexes = {}
        for row in rows or []:
            index_name = row[0]
            col_name = row[1]
            seq = row[2]
            constraint = row[3]
            index_type = row[4]

            if index_name not in indexes:
                is_pk = constraint == "PRIMARY KEY"
                is_unique = constraint in ("PRIMARY KEY", "UNIQUE")
                indexes[index_name] = {
                    "columns": [],
                    "index_type": index_type,
                    "is_primary_key": is_pk,
                    "is_unique": is_unique,
                }
            indexes[index_name]["columns"].append({"column_name": col_name, "column_order": seq})

        return indexes

    def get_table_autoincrement_info(self, table_name: str, schema: str | None = None) -> dict:
        schema, table_name = self._normalize_metadata_path(table_name, schema)
        table_filter = self._metadata_name_filter("TABLE_NAME", table_name)
        schema_literal = self._escape_sql_literal(schema)
        # SAP HANA uses GENERATED BY DEFAULT AS IDENTITY
        query = f"""
            SELECT
                COLUMN_NAME,
                DATA_TYPE_NAME,
                GENERATION_TYPE
            FROM SYS.TABLE_COLUMNS
            WHERE {table_filter}
              AND SCHEMA_NAME = '{schema_literal}'
              AND GENERATION_TYPE IS NOT NULL
        """
        result: dict = {"identity_columns": []}
        try:
            rows = self.fetchall(query)
            for row in rows or []:
                result["identity_columns"].append(
                    {
                        "column_name": row[0],
                        "data_type": row[1],
                        "identity_generation": row[2] or "BY DEFAULT",
                        "start_value": "1",
                        "increment": "1",
                        "minimum_value": None,
                        "maximum_value": None,
                        "cycle": "NO",
                    }
                )
        except Exception as e:
            logger.warning(f"Failed to fetch identity info for table '{table_name}': {e}")

        return result

    def query_sequences(self, schema: str) -> Dict[str, dict]:
        schema = schema or self.schema_name or self.database
        try:
            return (
                self._fetch_first_working_query(
                    [
                        (
                            f"""
                        SELECT SEQUENCE_NAME, START_NUMBER, INCREMENT_BY, MIN_VALUE, MAX_VALUE, IS_CYCLED
                        FROM SYS.SEQUENCES
                        WHERE SCHEMA_NAME = '{schema}'
                        """,
                            lambda rows: {
                                row[0]: {
                                    "start_value": row[1],
                                    "increment": row[2],
                                    "min_value": row[3],
                                    "max_value": row[4],
                                    "cycle": row[5],
                                }
                                for row in rows
                            },
                        ),
                        (
                            f"""
                        SELECT SEQUENCE_NAME, START_WITH, INCREMENT_BY, MIN_VALUE, MAX_VALUE, IS_CYCLED
                        FROM SYS.SEQUENCES
                        WHERE SCHEMA_NAME = '{schema}'
                        """,
                            lambda rows: {
                                row[0]: {
                                    "start_value": row[1],
                                    "increment": row[2],
                                    "min_value": row[3],
                                    "max_value": row[4],
                                    "cycle": row[5],
                                }
                                for row in rows
                            },
                        ),
                    ]
                )
                or {}
            )
        except Exception as e:
            logger.warning(f"Failed to fetch sequences for schema '{schema}': {e}")
            return {}

    def query_trigger_definitions(self, schema: str) -> Dict[str, str]:
        schema = schema or self.schema_name or self.database
        try:
            return (
                self._fetch_first_working_query(
                    [
                        (
                            f"""
                        SELECT TRIGGER_NAME, DEFINITION
                        FROM SYS.TRIGGERS
                        WHERE SCHEMA_NAME = '{schema}'
                        """,
                            lambda rows: {row[0]: self._normalize_trigger_definition(row[1]) for row in rows if row[1]},
                        ),
                        (
                            f"""
                        SELECT TRIGGER_NAME, ACTION_STATEMENT
                        FROM SYS.TRIGGERS
                        WHERE SCHEMA_NAME = '{schema}'
                        """,
                            lambda rows: {row[0]: self._normalize_trigger_definition(row[1]) for row in rows if row[1]},
                        ),
                        (
                            f"""
                        SELECT TRIGGER_NAME, TRIGGER_BODY
                        FROM SYS.TRIGGERS
                        WHERE SCHEMA_NAME = '{schema}'
                        """,
                            lambda rows: {row[0]: self._normalize_trigger_definition(row[1]) for row in rows if row[1]},
                        ),
                    ]
                )
                or {}
            )
        except Exception as e:
            logger.warning(f"Failed to fetch triggers for schema '{schema}': {e}")
            return {}

    def get_table_foreign_key_info(self, table_name: str, schema: str | None = None):
        schema, table_name = self._normalize_metadata_path(table_name, schema)
        table_filter = self._metadata_name_filter("TABLE_NAME", table_name)
        schema_literal = self._escape_sql_literal(schema)
        query = f"""
            SELECT
                CONSTRAINT_NAME,
                TABLE_NAME,
                COLUMN_NAME,
                REFERENCED_TABLE_NAME,
                REFERENCED_COLUMN_NAME
            FROM SYS.REFERENTIAL_CONSTRAINTS
            WHERE {table_filter}
              AND SCHEMA_NAME = '{schema_literal}'
        """
        try:
            rows = self.fetchall(query)
        except Exception as e:
            logger.warning(f"Failed to fetch FK info for table '{table_name}': {e}")
            return []

        return [
            {
                "constraint_name": row[0],
                "table_name": row[1],
                "fk_column": row[2],
                "referenced_table": row[3],
                "referenced_column": row[4],
            }
            for row in (rows or [])
        ]

    def query_get_distinct_count(self, table: str, field: str, filters: str = None) -> int:
        qualified = self.qualified_table_name(table)
        field = self.quote_column(field)
        query = f"SELECT COUNT(DISTINCT {field}) FROM {qualified}"
        if filters:
            query += f" WHERE {filters}"
        return self.fetchone(query)[0]

    def query_get_string_length_metric(
        self, table: str, field: str, metric: str, filters: str = None
    ) -> Union[int, float]:
        qualified = self.qualified_table_name(table)
        field = self.quote_column(field)
        fn_map = {"max": "MAX(LENGTH", "min": "MIN(LENGTH", "avg": "AVG(LENGTH"}
        if metric.lower() not in fn_map:
            raise ValueError(f"Invalid metric '{metric}'. Choose from 'max', 'min', or 'avg'.")
        query = f"SELECT {fn_map[metric.lower()]}({field})) FROM {qualified}"
        if filters:
            query += f" WHERE {filters}"
        result = self.fetchone(query)[0]
        return round(result, 2) if metric.lower() == "avg" else result

    def query_get_variance(self, table: str, field: str, filters: str = None) -> float:
        qualified = self.qualified_table_name(table)
        field = self.quote_column(field)
        query = f"SELECT VAR_SAMP(TO_DOUBLE({field})) FROM {qualified}"
        if filters:
            query += f" WHERE {filters}"
        result = self.fetchone(query)[0]
        return round(float(result), 2) if result is not None else None

    def query_get_stddev(self, table: str, field: str, filters: str = None) -> float:
        qualified = self.qualified_table_name(table)
        field = self.quote_column(field)
        query = f"SELECT STDDEV_SAMP(TO_DOUBLE({field})) FROM {qualified}"
        if filters:
            query += f" WHERE {filters}"
        result = self.fetchone(query)[0]
        return round(float(result), 2) if result is not None else None

    def query_get_avg(self, table: str, field: str, filters: str = None) -> float:
        qualified = self.qualified_table_name(table)
        field = self.quote_column(field)
        query = f"SELECT AVG(TO_DOUBLE({field})) FROM {qualified}"
        if filters:
            query += f" WHERE {filters}"
        result = self.fetchone(query)[0]
        return round(float(result), 2) if result is not None else None

    def query_get_percentile(self, table: str, field: str, percentile: float, filters: str = None) -> float:
        qualified = self.qualified_table_name(table)
        field = self.quote_column(field)
        # HANA supports PERCENTILE_DISC with WITHIN GROUP
        query = f"SELECT PERCENTILE_DISC({percentile}) WITHIN GROUP (ORDER BY {field}) FROM {qualified}"
        if filters:
            query += f" WHERE {filters}"
        result = self.fetchone(query)[0]
        return round(float(result), 2) if result is not None else None

    def query_negative_metric(self, table: str, field: str, operation: str, filters: str = None) -> Union[int, float]:
        qualified = self.qualified_table_name(table)
        field = self.quote_column(field)
        negative_query = f"SELECT COUNT(*) FROM {qualified} WHERE {field} < 0"
        if filters:
            negative_query += f" AND {filters}"
        total_count_query = f"SELECT COUNT(*) FROM {qualified}"
        if filters:
            total_count_query += f" WHERE {filters}"
        if operation == "percent":
            neg_count = self.fetchone(negative_query)[0]
            total_count = self.fetchone(total_count_query)[0]
            if total_count == 0:
                return 0.0
            return round((neg_count / total_count) * 100, 2)
        return self.fetchone(negative_query)[0]

    def query_string_pattern_validity(
        self,
        table: str,
        field: str,
        regex_pattern: str = None,
        predefined_regex_pattern: str = None,
        filters: str = None,
    ) -> Tuple[int, int]:
        filters_clause = f"WHERE {filters}" if filters else ""
        qualified = self.qualified_table_name(table)
        field = self.quote_column(field)

        if not regex_pattern and not predefined_regex_pattern:
            raise ValueError("Either regex_pattern or predefined_regex_pattern should be provided")

        pattern = self.regex_patterns[predefined_regex_pattern] if predefined_regex_pattern else regex_pattern
        # HANA uses LIKE_REGEXPR for regex matching
        regex_query = f"CASE WHEN LIKE_REGEXPR('{pattern}', {field}) = TRUE THEN 1 ELSE 0 END"
        query = f"SELECT SUM({regex_query}) AS valid_count, COUNT(*) AS total_count FROM {qualified} {filters_clause}"
        result = self.fetchone(query)
        return result[0], result[1]

    def query_valid_invalid_values_validity(
        self,
        table: str,
        field: str,
        regex_pattern: str = None,
        filters: str = None,
        values: List[str] = None,
    ) -> Tuple[int, int]:
        filters_clause = f"WHERE {filters}" if filters else ""
        qualified = self.qualified_table_name(table)
        field = self.quote_column(field)
        if values:
            values_str = ", ".join([f"'{v}'" for v in values])
            regex_query = f"CASE WHEN {field} IN ({values_str}) THEN 1 ELSE 0 END"
        else:
            regex_query = f"CASE WHEN LIKE_REGEXPR('{regex_pattern}', {field}) = TRUE THEN 1 ELSE 0 END"
        query = f"SELECT SUM({regex_query}) AS valid_count, COUNT(*) AS total_count FROM {qualified} {filters_clause}"
        result = self.fetchone(query)
        return result[0], result[1]

    def query_get_usa_state_code_validity(self, table: str, field: str, filters: str = None) -> Tuple[int, int]:
        valid_state_codes_str = ", ".join(f"'{code}'" for code in self.valid_state_codes)
        filters_clause = f"WHERE {filters}" if filters else ""
        qualified = self.qualified_table_name(table)
        field = self.quote_column(field)
        regex_query = f"CASE WHEN LIKE_REGEXPR('^[A-Z]{{2}}$', {field}) = TRUE AND UPPER({field}) IN ({valid_state_codes_str}) THEN 1 ELSE 0 END"
        query = f"SELECT SUM({regex_query}) AS valid_count, COUNT(*) AS total_count FROM {qualified} {filters_clause}"
        result = self.fetchone(query)
        return result[0], result[1]

    def query_views_defination(self, schema: str) -> Dict[str, str]:
        schema = schema or self.schema_name or self.database
        query = f"SELECT VIEW_NAME, DEFINITION FROM SYS.VIEWS WHERE SCHEMA_NAME = '{schema}'"
        try:
            rows = self.fetchall(query)
            return {row[0]: row[1] for row in rows} if rows else {}
        except Exception as e:
            logger.warning(f"Failed to fetch view definitions for schema '{schema}': {e}")
            return {}

    def query_all_procedures_defination(self, schema: str) -> Dict[str, str]:
        schema = schema or self.schema_name or self.database
        try:
            return (
                self._fetch_first_working_query(
                    [
                        (
                            f"""
                        SELECT PROCEDURE_NAME, DEFINITION
                        FROM SYS.PROCEDURES
                        WHERE SCHEMA_NAME = '{schema}'
                        """,
                            lambda rows: {
                                row[0]: self._normalize_sqlscript_definition(row[1]) for row in rows if row[1]
                            },
                        ),
                        (
                            f"""
                        SELECT PROCEDURE_NAME, ROUTINE_DEFINITION
                        FROM SYS.PROCEDURES
                        WHERE SCHEMA_NAME = '{schema}'
                        """,
                            lambda rows: {
                                row[0]: self._normalize_sqlscript_definition(row[1]) for row in rows if row[1]
                            },
                        ),
                    ]
                )
                or {}
            )
        except Exception as e:
            logger.warning(f"Failed to fetch procedure definitions for schema '{schema}': {e}")
            return {}

    def profiling_sql_aggregates_numeric(self, table_name: str, column_name: str) -> Dict:
        col = self.quote_column(column_name)
        qualified = self.qualified_table_name(table_name)
        query = f"""
            SELECT
                AVG(TO_DOUBLE({col})) AS avg,
                MIN({col}) AS min,
                MAX({col}) AS max,
                SUM(TO_DOUBLE({col})) AS sum,
                STDDEV_SAMP(TO_DOUBLE({col})) AS stddev,
                VAR_SAMP(TO_DOUBLE({col})) AS variance,
                COUNT(DISTINCT({col})) AS distinct_count,
                SUM(CASE WHEN {col} IS NULL THEN 1 ELSE 0 END) AS missing_count
            FROM {qualified}
        """
        result = self.fetchone(query)
        return {
            "avg": result[0],
            "min": result[1],
            "max": result[2],
            "sum": result[3],
            "stddev": result[4],
            "variance": result[5],
            "distinct_count": result[6],
            "missing_count": result[7],
        }

    def query_timestamp_metric(self, table: str, field: str, predefined_regex: str, filters: str = None):
        # HANA stores timestamps as native types — check if value <= NOW()
        qualified = self.qualified_table_name(table)
        field_q = self.quote_column(field)
        filters_clause = f"WHERE {filters}" if filters else ""
        valid_query = f"SELECT COUNT(*) FROM {qualified} {filters_clause}"
        total_query = f"SELECT COUNT(*) FROM {qualified} {filters_clause}"
        try:
            valid_count = self.fetchone(valid_query)[0]
            total_count = self.fetchone(total_query)[0]
            return valid_count, total_count
        except Exception as e:
            logger.error(f"Error in query_timestamp_metric: {e}")
            return 0, 0

    def query_timestamp_not_in_future_metric(self, table: str, field: str, predefined_regex: str, filters: str = None):
        qualified = self.qualified_table_name(table)
        field_q = self.quote_column(field)
        filters_clause = f"AND {filters}" if filters else ""
        valid_query = f"SELECT COUNT(*) FROM {qualified} WHERE {field_q} <= CURRENT_TIMESTAMP {filters_clause}"
        total_query = f"SELECT COUNT(*) FROM {qualified}" + (f" WHERE {filters}" if filters else "")
        try:
            valid_count = self.fetchone(valid_query)[0]
            total_count = self.fetchone(total_query)[0]
            return valid_count, total_count
        except Exception as e:
            logger.error(f"Error in query_timestamp_not_in_future_metric: {e}")
            return 0, 0

    def query_timestamp_date_not_in_future_metric(
        self, table: str, field: str, predefined_regex: str, filters: str = None
    ):
        qualified = self.qualified_table_name(table)
        field_q = self.quote_column(field)
        filters_clause = f"AND {filters}" if filters else ""
        valid_query = f"SELECT COUNT(*) FROM {qualified} WHERE CAST({field_q} AS DATE) <= CURRENT_DATE {filters_clause}"
        total_query = f"SELECT COUNT(*) FROM {qualified}" + (f" WHERE {filters}" if filters else "")
        try:
            valid_count = self.fetchone(valid_query)[0]
            total_count = self.fetchone(total_query)[0]
            return valid_count, total_count
        except Exception as e:
            logger.error(f"Error in query_timestamp_date_not_in_future_metric: {e}")
            return 0, 0

    def query_get_time_diff(self, table: str, field: str) -> int:
        qualified = self.qualified_table_name(table)
        field = self.quote_column(field)
        query = f"SELECT {field} FROM {qualified} ORDER BY {field} DESC LIMIT 1"
        result = self.fetchone(query)
        if result:
            updated_time = result[0]
            if isinstance(updated_time, str):
                updated_time = datetime.datetime.strptime(updated_time, "%Y-%m-%d %H:%M:%S.%f")
            return int(
                (datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None) - updated_time).total_seconds()
            )
        return 0
