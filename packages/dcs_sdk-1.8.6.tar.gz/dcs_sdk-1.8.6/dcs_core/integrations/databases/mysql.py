#  Copyright 2022-present, the Waterdip Labs Pvt. Ltd.
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

import datetime
import math
import re
from decimal import Decimal
from typing import Any, Dict, List, Optional, Tuple, Union
from uuid import UUID

from loguru import logger
from sqlalchemy import create_engine, text
from sqlalchemy.engine import URL

from dcs_core.core.common.errors import DataChecksDataSourcesConnectionError
from dcs_core.core.common.models.data_source_resource import RawColumnInfo
from dcs_core.integrations.databases.db2 import DB2DataSource


class MysqlDataSource(DB2DataSource):
    SQLGLOT_DIALECT = "mysql"

    def __init__(self, data_source_name: str, data_connection: Dict):
        super().__init__(data_source_name, data_connection)
        self.regex_patterns = {
            "uuid": r"^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$",
            "usa_phone": r"^\\+?1?[-.[:space:]]?\\(?[0-9]{3}\\)?[-.[:space:]]?[0-9]{3}[-.[:space:]]?[0-9]{4}$",
            "email": r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$",
            "usa_zip_code": r"^[0-9B-DF-HJ-NP-TV-Z]{6}[0-9]$",
            "ssn": r"^(?!666|000|9\\d{2})\\d{3}-(?!00)\\d{2}-(?!0{4})\\d{4}$",
            "sedol": r"^[B-DF-HJ-NP-TV-XZ0-9]{6}[0-9]$",
            "lei": r"^[A-Z0-9]{18}[0-9]{2}$",
            "cusip": r"^[0-9A-Z]{9}$",
            "figi": r"^BBG[A-Z0-9]{9}$",
            "isin": r"^[A-Z]{2}[A-Z0-9]{9}[0-9]$",
            "perm_id": r"^[0-9]{4}[- ]?[0-9]{4}[- ]?[0-9]{4}[- ]?[0-9]{4}[- ]?[0-9]{2,3}$",
        }

    def connect(self) -> Any:
        """
        Connect to the data source
        """
        try:
            ssl = True if self.data_connection.get("security", False) in ["ssl", "SSL"] else False
            self.schema_name = self.data_connection.get("database")
            url = URL.create(
                drivername="mysql+pymysql",
                username=self.data_connection.get("username"),
                password=self.data_connection.get("password"),
                host=self.data_connection.get("host"),
                port=self.data_connection.get("port"),
                database=self.data_connection.get("database"),
            )
            engine = create_engine(
                url,
                isolation_level="AUTOCOMMIT",
                connect_args={"ssl": {"ssl": ssl} if ssl else None},
            )
            self.connection = engine.connect()
            return self.connection
        except Exception as e:
            raise DataChecksDataSourcesConnectionError(message=f"Failed to connect to Mysql data source: [{str(e)}]")

    def qualified_table_name(self, table_name: str) -> str:
        """
        Get the qualified table name
        :param table_name: name of the table
        :return: qualified table name
        """
        if self.database:
            return f"`{self.database}`.`{table_name}`"
        return f"`{table_name}`"

    def quote_column(self, column: str) -> str:
        """
        Quote the column name
        :param column: name of the column
        :return: quoted column name
        """
        return f"`{column}`"

    @staticmethod
    def _normalize_mysql_definition(definition: str | None) -> str:
        if not definition:
            return ""

        normalized = str(definition).strip()
        normalized = re.sub(r"--.*?$", "", normalized, flags=re.MULTILINE)
        normalized = re.sub(r"#.*?$", "", normalized, flags=re.MULTILINE)
        normalized = re.sub(r"/\*.*?\*/", "", normalized, flags=re.DOTALL)

        trigger_action_match = re.search(r"\bFOR\s+EACH\s+ROW\b(.*)$", normalized, flags=re.IGNORECASE | re.DOTALL)
        if trigger_action_match:
            normalized = trigger_action_match.group(1).strip()

        begin_match = re.search(r"\bBEGIN\b(.*)\bEND\b", normalized, flags=re.IGNORECASE | re.DOTALL)
        if begin_match:
            normalized = begin_match.group(1).strip()

        normalized = re.sub(
            r"\bDECLARE\b[^;]*;?",
            "",
            normalized,
            flags=re.IGNORECASE,
        )
        normalized = re.sub(r"\bIF\s+NOT\s+EXISTS\s*\(", "", normalized, flags=re.IGNORECASE)
        normalized = re.sub(r"\bIF\s+EXISTS\s*\(", "", normalized, flags=re.IGNORECASE)
        normalized = re.sub(r"\bIF\b", "", normalized, flags=re.IGNORECASE)
        normalized = re.sub(r"\bTHEN\b", "", normalized, flags=re.IGNORECASE)
        normalized = re.sub(r"\bELSEIF\b", "ELSE IF", normalized, flags=re.IGNORECASE)
        normalized = re.sub(r"\bELSE\b", "", normalized, flags=re.IGNORECASE)
        normalized = re.sub(r"\bEND IF\b\s*;?", "", normalized, flags=re.IGNORECASE)
        normalized = re.sub(r"\bLOOP\b", "", normalized, flags=re.IGNORECASE)
        normalized = re.sub(r"\bEND LOOP\b\s*;?", "", normalized, flags=re.IGNORECASE)
        normalized = re.sub(r"\bWHILE\b", "", normalized, flags=re.IGNORECASE)
        normalized = re.sub(r"\bEND WHILE\b\s*;?", "", normalized, flags=re.IGNORECASE)
        normalized = re.sub(r"\bREPEAT\b", "", normalized, flags=re.IGNORECASE)
        normalized = re.sub(r"\bUNTIL\b[^;]*;?", "", normalized, flags=re.IGNORECASE)
        normalized = re.sub(r"\bLEAVE\b[^;]*;?", "", normalized, flags=re.IGNORECASE)
        normalized = re.sub(r"\bITERATE\b[^;]*;?", "", normalized, flags=re.IGNORECASE)
        normalized = re.sub(r"\bSIGNAL\b[^;]*;?", "", normalized, flags=re.IGNORECASE)
        normalized = re.sub(r"\bRESIGNAL\b[^;]*;?", "", normalized, flags=re.IGNORECASE)
        normalized = re.sub(r"\bCALL\b[^;]*;?", "", normalized, flags=re.IGNORECASE)
        normalized = re.sub(r"\s+", " ", normalized).strip()

        sql_statements = re.findall(
            r"(?is)\b(?:WITH|SELECT|INSERT\s+INTO|UPDATE|DELETE\s+FROM|REPLACE\s+INTO|MERGE\s+INTO)\b.*?(?=;|$)",
            normalized,
        )
        if sql_statements:
            return "; ".join(statement.strip() for statement in sql_statements if statement.strip())

        return normalized

    def _fetch_mysql_show_create_definition(
        self,
        object_type: str,
        schema: str,
        object_name: str,
    ) -> str:
        query = f"SHOW CREATE {object_type} `{schema}`.`{object_name}`"
        row = self.fetchone(query)
        if not row:
            return ""

        if hasattr(row, "_mapping"):
            mapping = row._mapping
            if object_type.upper() == "PROCEDURE":
                return mapping.get("Create Procedure") or mapping.get("Create Function") or ""
            if object_type.upper() == "TRIGGER":
                return mapping.get("SQL Original Statement") or ""

        if object_type.upper() == "PROCEDURE":
            return row[2] if len(row) > 2 else ""
        if object_type.upper() == "TRIGGER":
            return row[2] if len(row) > 2 else ""
        return ""

    def query_get_table_names(
        self,
        schema: str | None = None,
        with_view: bool = False,
    ) -> dict:
        """
        Get the list of tables in the database.
        :param schema: optional schema name
        :param with_view: whether to include views
        :return: dictionary with table names and optionally view names
        """
        database = self.database
        if with_view:
            table_type_condition = "TABLE_TYPE IN ('BASE TABLE', 'VIEW')"
        else:
            table_type_condition = "TABLE_TYPE = 'BASE TABLE'"

        query = f"SELECT TABLE_NAME, TABLE_TYPE FROM information_schema.tables WHERE TABLE_SCHEMA = '{database}' AND {table_type_condition}"
        rows = self.fetchall(query)

        if with_view:
            result = {"table": [], "view": []}
            if rows:
                for row in rows:
                    table_name = row[0]
                    table_type = row[1].strip() if row[1] else row[1]

                    if table_type == "BASE TABLE":
                        result["table"].append(table_name)
                    elif table_type == "VIEW":
                        result["view"].append(table_name)
        else:
            result = {"table": []}
            if rows:
                result["table"] = [row[0] for row in rows]

        return result

    def query_get_table_columns(self, table: str, schema: str | None = None) -> RawColumnInfo:
        """
        Get the schema of a table.
        :param table: table name
        :return: RawColumnInfo object containing column information
        """
        schema = self.database
        query = (
            "SELECT column_name, data_type, datetime_precision, numeric_precision, numeric_scale, NULL as collation_name, character_maximum_length "
            "FROM information_schema.columns "
            f"WHERE table_name = '{table}' AND table_schema = '{schema}'"
        )
        rows = self.fetchall(query)
        if not rows:
            raise RuntimeError(f"{table}: Table, {schema}: Schema, does not exist, or has no columns")

        column_info = {
            r[0]: RawColumnInfo(
                column_name=self.safe_get(r, 0),
                data_type=self.safe_get(r, 1),
                datetime_precision=self.safe_get(r, 2),
                numeric_precision=self.safe_get(r, 3),
                numeric_scale=self.safe_get(r, 4),
                collation_name=self.safe_get(r, 5),
                character_maximum_length=self.safe_get(r, 6),
            )
            for r in rows
        }
        return column_info

    def fetch_rows(
        self,
        query: str,
        limit: int = 1,
        with_column_names: bool = False,
        complete_query: Optional[str] = None,
    ) -> Tuple[List, Optional[List[str]]]:
        """
        Fetch rows from the database.

        :param query: SQL query to execute.
        :param limit: Number of rows to fetch.
        :param with_column_names: Whether to include column names in the result.
        :return: Tuple of (rows, column_names or None)
        """
        query = complete_query or f"SELECT * FROM ({query}) AS subquery LIMIT {limit}"

        result = self.connection.execute(text(query))
        rows = result.fetchmany(limit)

        if with_column_names:
            column_names = result.keys()
            return rows, list(column_names)
        else:
            return rows, None

    def fetch_sample_values_from_database(
        self,
        table_name: str,
        column_names: list[str],
        limit: int = 5,
    ) -> List[Tuple]:
        table_name = self.qualified_table_name(table_name)

        if not column_names:
            raise ValueError("At least one column name must be provided")

        if len(column_names) == 1 and column_names[0] == "*":
            query = f"SELECT * FROM {table_name} LIMIT {limit}"
        else:
            columns = ", ".join([self.quote_column(col) for col in column_names])
            query = f"SELECT {columns} FROM {table_name} LIMIT {limit}"

        result = self.connection.execute(text(query))
        column_names = [desc[0] for desc in result.cursor.description]
        rows = self.normalize_sample_rows(result.fetchall())
        return rows, column_names

    def build_table_metrics_query(
        self,
        table_name: str,
        column_info: list[dict],
        additional_queries: Optional[List[str]] = None,
    ) -> list[dict]:
        query_parts = []
        if not column_info:
            return []

        _NUMERIC_TYPES = (
            "int",
            "integer",
            "bigint",
            "smallint",
            "tinyint",
            "decimal",
            "numeric",
            "float",
            "double",
            "real",
        )
        _STRING_TYPES = ("varchar", "text", "char", "tinytext", "mediumtext", "longtext", "enum", "set")
        _DATETIME_TYPES = ("date", "datetime", "time", "timestamp", "year", "boolean", "tinyint(1)")

        for col in column_info:
            name = col["column_name"]
            dtype = col["data_type"].lower()
            quoted = self.quote_column(name)

            query_parts.append(f"COUNT(DISTINCT {quoted}) AS `{name}_distinct`")
            query_parts.append(f"COUNT(*) - COUNT(DISTINCT {quoted}) AS `{name}_duplicate`")
            query_parts.append(f"SUM(CASE WHEN {quoted} IS NULL THEN 1 ELSE 0 END) AS `{name}_is_null`")

            if dtype in _NUMERIC_TYPES:
                query_parts.append(f"MIN({quoted}) AS `{name}_min`")
                query_parts.append(f"MAX({quoted}) AS `{name}_max`")
                query_parts.append(f"AVG({quoted}) AS `{name}_average`")
            elif dtype in _STRING_TYPES:
                query_parts.append(f"MAX(CHAR_LENGTH({quoted})) AS `{name}_max_character_length`")
            elif dtype in _DATETIME_TYPES:
                query_parts.append(f"MIN({quoted}) AS `{name}_min`")
                query_parts.append(f"MAX({quoted}) AS `{name}_max`")

        if additional_queries:
            for queries in additional_queries:
                query_parts.append(queries)

        qualified_table = self.qualified_table_name(table_name)
        joined_parts = ",\n    ".join(query_parts)
        query = f"SELECT\n    {joined_parts}\nFROM {qualified_table};"

        result = self.connection.execute(text(query))
        row = dict(list(result)[0]._mapping)

        def _normalize_metrics(value):
            if value is None:
                return None
            if isinstance(value, bool):
                return value
            if isinstance(value, Decimal):
                return float(value)
            if isinstance(value, (int, float)):
                return value
            if isinstance(value, datetime.datetime):
                return value.isoformat()
            if isinstance(value, datetime.date):
                return value.isoformat()
            if isinstance(value, datetime.timedelta):
                return str(value)
            if isinstance(value, datetime.time):
                return value.isoformat()
            if isinstance(value, UUID):
                return str(value)
            if isinstance(value, bytes):
                try:
                    return value.decode("utf-8")
                except Exception:
                    return value.hex()
            if isinstance(value, list):
                return [_normalize_metrics(v) for v in value]
            if isinstance(value, dict):
                return {k: _normalize_metrics(v) for k, v in value.items()}
            return str(value)

        key_owner: dict[str, str] = {}
        for col in column_info:
            n = col["column_name"]
            for key in row:
                if key.startswith(f"{n}_"):
                    if key not in key_owner or len(n) > len(key_owner[key]):
                        key_owner[key] = n

        column_wise = []
        for col in column_info:
            name = col["column_name"]
            col_metrics = {
                key[len(name) + 1 :]: _normalize_metrics(value)
                for key, value in row.items()
                if key_owner.get(key) == name
            }
            column_wise.append({"column_name": name, "metrics": col_metrics})

        for col_data in column_wise:
            metrics = col_data["metrics"]
            col_name = col_data["column_name"]
            dtype = next(c["data_type"].lower() for c in column_info if c["column_name"] == col_name)
            quoted = self.quote_column(col_name)
            is_dtype_numeric = dtype in _NUMERIC_TYPES

            if is_dtype_numeric:
                col_min = metrics.get("min")
                col_max = metrics.get("max")

                if col_min is not None and col_max is not None and col_min != col_max:
                    col_min = float(col_min)
                    col_max = float(col_max)
                    bucket_count = 20
                    bucket_size = (col_max - col_min) / bucket_count
                    bucket_queries = []
                    for i in range(bucket_count):
                        start = col_min + i * bucket_size
                        end = col_min + (i + 1) * bucket_size
                        bucket_queries.append(
                            f"SUM(CASE WHEN {quoted} >= {start} AND {quoted} < {end} THEN 1 ELSE 0 END) AS bucket_{i}"
                        )
                    bucket_sql = f"SELECT {', '.join(bucket_queries)} FROM {qualified_table}"
                    try:
                        bucket_result = self.connection.execute(text(bucket_sql)).fetchone()
                        distribution = []
                        for i in range(bucket_count):
                            start_raw = col_min + i * bucket_size
                            end_raw = col_min + (i + 1) * bucket_size
                            if dtype in ("int", "integer", "bigint", "smallint", "tinyint"):
                                start = math.floor(start_raw)
                                end = math.ceil(end_raw)
                            else:
                                start = round(start_raw, 2)
                                end = round(end_raw, 2)
                            distribution.append(
                                {"col_val": f"{start} - {end}", "count": _normalize_metrics(bucket_result[i])}
                            )
                        metrics["distribution_graph"] = distribution
                    except Exception as e:
                        logger.warning(f"Failed to generate numeric distribution for {col_name}: {e}")
                continue

            distinct_count = metrics.get("distinct")
            if isinstance(distinct_count, (int, float)) and distinct_count <= 20:
                dist_query = (
                    f"SELECT {quoted}, COUNT(*) FROM {qualified_table} GROUP BY {quoted} ORDER BY COUNT(*) DESC"
                )
                try:
                    dist_result = self.connection.execute(text(dist_query)).fetchall()
                    distribution = [
                        {"col_val": _normalize_metrics(r[0]), "count": _normalize_metrics(r[1])} for r in dist_result
                    ]
                    metrics["distribution_graph"] = distribution
                except Exception as e:
                    logger.warning(f"Failed to generate distribution graph for column {col_name}: {e}")

        for col_data in column_wise:
            metrics = col_data["metrics"]
            dtype = next(c["data_type"].lower() for c in column_info if c["column_name"] == col_data["column_name"])
            is_dtype_numeric = dtype in _NUMERIC_TYPES
            col_data["metrics"] = {
                "general_data": {k: v for k, v in metrics.items() if k != "distribution_graph"},
                "is_dtype_numeric": is_dtype_numeric,
                "distribution_data": metrics.get("distribution_graph", []),
            }

        return column_wise

    def query_get_table_indexes(self, table: str, schema: str | None = None) -> dict[str, dict]:
        schema = self.database

        query = f"""
            SELECT
                s.INDEX_NAME,
                s.COLUMN_NAME,
                s.SEQ_IN_INDEX,
                s.NON_UNIQUE,
                s.INDEX_TYPE
            FROM information_schema.STATISTICS s
            WHERE s.TABLE_SCHEMA = '{schema}'
              AND s.TABLE_NAME = '{table}'
            ORDER BY s.INDEX_NAME, s.SEQ_IN_INDEX
        """

        try:
            rows = self.fetchall(query)
        except Exception:
            return {}

        indexes = {}
        for row in rows or []:
            index_name = row[0]
            col_name = row[1]
            seq = row[2]
            non_unique = row[3]
            index_type = row[4]

            if index_name not in indexes:
                is_pk = index_name == "PRIMARY"
                indexes[index_name] = {
                    "columns": [],
                    "index_type": index_type,
                    "is_primary_key": is_pk,
                    "is_unique": non_unique == 0,
                }
            indexes[index_name]["columns"].append({"column_name": col_name, "column_order": seq})

        return indexes

    def get_table_autoincrement_info(self, table_name: str, schema: str | None = None) -> dict:
        schema = self.database

        query = f"""
            SELECT
                column_name,
                data_type,
                extra
            FROM information_schema.columns
            WHERE table_name = '{table_name}'
              AND table_schema = '{schema}'
              AND extra LIKE '%auto_increment%'
        """

        result: dict = {"identity_columns": []}
        try:
            rows = self.fetchall(query)
            for row in rows or []:
                result["identity_columns"].append(
                    {
                        "column_name": row[0],
                        "data_type": row[1],
                        "identity_generation": "BY DEFAULT",
                        "start_value": "1",
                        "increment": "1",
                        "minimum_value": None,
                        "maximum_value": None,
                        "cycle": "NO",
                    }
                )
        except Exception as e:
            logger.warning(f"Failed to fetch AUTO_INCREMENT info for table '{table_name}': {e}")

        return result

    def query_get_distinct_count(self, table: str, field: str, filters: str = None) -> int:
        """
        Get the distinct count value
        :param table: table name
        :param field: column name
        :param filters: filter condition
        :return:
        """
        qualified_table_name = self.qualified_table_name(table)
        field = self.quote_column(field)
        query = "SELECT COUNT(DISTINCT {}) FROM {}".format(field, qualified_table_name)
        if filters:
            query += " WHERE {}".format(filters)

        return self.fetchone(query)[0]

    def query_get_percentile(self, table: str, field: str, percentile: float, filters: str = None) -> float:
        """
        Get the specified percentile value of a numeric column in a table.
        :param table: table name
        :param field: column name
        :param percentile: percentile to calculate (e.g., 0.2 for 20th percentile)
        :param filters: filter condition
        :return: the value at the specified percentile
        """
        qualified_table_name = self.qualified_table_name(table)
        field = self.quote_column(field)
        rank = int(percentile * 100)

        query = f"""
            SELECT {field} FROM (
                SELECT {field}, NTILE(100) OVER (ORDER BY {field}) AS percentile_rank
                FROM {qualified_table_name}
                {f'WHERE {filters}' if filters else ''}
            ) AS ranked
            WHERE percentile_rank = {rank}
            ORDER BY {field}
            LIMIT 1
        """

        result = self.fetchone(query)
        return round(result[0], 2) if result and result[0] is not None else None

    def query_negative_metric(self, table: str, field: str, operation: str, filters: str = None) -> Union[int, float]:
        qualified_table_name = self.qualified_table_name(table)
        field = self.quote_column(field)

        negative_query = f"SELECT COUNT(*) FROM {qualified_table_name} WHERE {field} < 0"

        if filters:
            negative_query += f" AND {filters}"

        total_count_query = f"SELECT COUNT(*) FROM {qualified_table_name}"

        if filters:
            total_count_query += f" WHERE {filters}"

        if operation == "percent":
            query = f"SELECT (CAST(({negative_query}) AS float) / CAST(({total_count_query}) AS float)) * 100"
        else:
            query = negative_query

        result = self.fetchone(query)[0]
        return round(result, 2) if operation == "percent" else result

    def query_get_string_length_metric(
        self, table: str, field: str, metric: str, filters: str = None
    ) -> Union[int, float]:
        """
        Get the string length metric (max, min, avg) in a column of a table.

        :param table: table name
        :param field: column name
        :param metric: the metric to calculate ('max', 'min', 'avg')
        :param filters: filter condition
        :return: the calculated metric as int for 'max' and 'min', float for 'avg'
        """
        qualified_table_name = self.qualified_table_name(table)
        field = self.quote_column(field)

        if metric.lower() == "max":
            sql_function = "MAX(LENGTH"
        elif metric.lower() == "min":
            sql_function = "MIN(LENGTH"
        elif metric.lower() == "avg":
            sql_function = "AVG(LENGTH"
        else:
            raise ValueError(f"Invalid metric '{metric}'. Choose from 'max', 'min', or 'avg'.")

        query = f"SELECT {sql_function}({field})) FROM {qualified_table_name}"

        if filters:
            query += f" WHERE {filters}"

        result = self.fetchone(query)[0]
        return round(result, 2) if metric.lower() == "avg" else result

    def query_string_pattern_validity(
        self,
        table: str,
        field: str,
        regex_pattern: str = None,
        predefined_regex_pattern: str = None,
        filters: str = None,
    ) -> Tuple[int, int]:
        """
        Get the count of valid values based on the regex pattern.
        :param table: table name
        :param field: column name
        :param regex_pattern: custom regex pattern
        :param predefined_regex_pattern: predefined regex pattern
        :param filters: filter condition
        :return: count of valid values, count of total row count
        """
        filters = f"WHERE {filters}" if filters else ""
        qualified_table_name = self.qualified_table_name(table)
        field = self.quote_column(field)

        if not regex_pattern and not predefined_regex_pattern:
            raise ValueError("Either regex_pattern or predefined_regex_pattern should be provided")

        if predefined_regex_pattern:
            regex = self.regex_patterns[predefined_regex_pattern]
        else:
            regex = regex_pattern

        regex_query = f"CASE WHEN {field} REGEXP '{regex}' THEN 1 ELSE 0 END"
        query = f"""
            SELECT SUM({regex_query}) AS valid_count, COUNT(*) AS total_count
            FROM {qualified_table_name} {filters}
        """
        result = self.fetchone(query)
        return result[0], result[1]

    def query_get_usa_state_code_validity(self, table: str, field: str, filters: str = None) -> Tuple[int, int]:
        """
        Get the count of valid USA state codes
        :param table: table name
        :param field: column name
        :param filters: filter condition
        :return: count of valid state codes, count of total row count
        """

        valid_state_codes_str = ", ".join(f"'{code}'" for code in self.valid_state_codes)

        filters = f"WHERE {filters}" if filters else ""

        qualified_table_name = self.qualified_table_name(table)
        field = self.quote_column(field)

        regex_query = f"""
            CASE WHEN REGEXP_LIKE({field}, '^[A-Z]{{2}}$') AND UPPER({field}) IN ({valid_state_codes_str}) THEN 1 ELSE 0 END
        """

        query = f"""
            SELECT SUM({regex_query}) AS valid_count, COUNT(*) AS total_count
            FROM {qualified_table_name} {filters}
        """
        result = self.fetchone(query)
        return result[0], result[1]

    def query_timestamp_metric(self):
        raise NotImplementedError("Method not implemented for MySQLDataSource")

    def query_timestamp_not_in_future_metric(self):
        raise NotImplementedError("Method not implemented for MySQLDataSource")

    def query_timestamp_date_not_in_future_metric(self):
        raise NotImplementedError("Method not implemented for MySQLDataSource")

    def query_get_time_diff(self, table: str, field: str) -> int:
        """
        Get the time difference
        :param table: name of the index
        :param field: field name of updated time column
        :return: time difference in seconds
        """
        qualified_table_name = self.qualified_table_name(table)
        field = self.quote_column(field)
        query = f"""
            SELECT {field}
            FROM {qualified_table_name}
            ORDER BY {field} DESC
            LIMIT 1;
        """
        result = self.fetchone(query)
        if result:
            updated_time = result[0]
            if isinstance(updated_time, str):
                updated_time = datetime.datetime.strptime(updated_time, "%Y-%m-%d %H:%M:%S.%f")
            return int(
                (datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None) - updated_time).total_seconds()
            )
        return 0

    def get_table_foreign_key_info(self, table_name: str, schema: str | None = None):
        schema = self.database

        query = f"""
            SELECT
                kcu.CONSTRAINT_NAME AS constraint_name,
                kcu.TABLE_NAME AS table_name,
                kcu.COLUMN_NAME AS fk_column,
                kcu.REFERENCED_TABLE_NAME AS referenced_table,
                kcu.REFERENCED_COLUMN_NAME AS referenced_column
            FROM information_schema.TABLE_CONSTRAINTS tc
            JOIN information_schema.KEY_COLUMN_USAGE kcu
                ON tc.CONSTRAINT_NAME = kcu.CONSTRAINT_NAME
                AND tc.TABLE_SCHEMA = kcu.TABLE_SCHEMA
            WHERE tc.CONSTRAINT_TYPE = 'FOREIGN KEY'
            AND tc.TABLE_NAME = '{table_name}'
            AND tc.TABLE_SCHEMA = '{schema}';
        """

        try:
            rows = self.fetchall(query)
        except Exception as e:
            logger.error(f"Failed to fetch fk info for dataset: {table_name} ({e})")
            return []

        data = [
            {
                "constraint_name": row[0],
                "table_name": row[1],
                "fk_column": row[2],
                "referenced_table": row[3],
                "referenced_column": row[4],
            }
            for row in rows
        ]
        return data

    def query_sequences(self, schema: str) -> Dict[str, dict]:
        return {}

    def query_all_procedures_defination(self, schema: str) -> Dict[str, str]:
        schema = self.database
        query = f"""
            SELECT ROUTINE_NAME
            FROM information_schema.ROUTINES
            WHERE ROUTINE_SCHEMA = '{schema}'
        """
        rows = self.fetchall(query)
        definitions = {}
        for row in rows or []:
            routine_name = row[0]
            definition = self._fetch_mysql_show_create_definition("PROCEDURE", schema, routine_name)
            if definition:
                definitions[routine_name] = self._normalize_mysql_definition(definition)
        return definitions

    def query_trigger_definitions(self, schema: str) -> Dict[str, str]:
        schema = self.database
        query = f"""
            SELECT TRIGGER_NAME
            FROM information_schema.TRIGGERS
            WHERE TRIGGER_SCHEMA = '{schema}'
        """
        rows = self.fetchall(query)
        definitions = {}
        for row in rows or []:
            trigger_name = row[0]
            definition = self._fetch_mysql_show_create_definition("TRIGGER", schema, trigger_name)
            if definition:
                definitions[trigger_name] = self._normalize_mysql_definition(definition)
        return definitions
