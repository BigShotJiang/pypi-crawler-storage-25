#  Copyright 2022-present, the Waterdip Labs Pvt. Ltd.
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

from typing import Any, Dict, List, Tuple

from sqlalchemy import create_engine, text
from sqlalchemy.engine import URL

from dcs_core.core.common.errors import DataChecksDataSourcesConnectionError
from dcs_core.core.datasource.sql_datasource import SQLDataSource


class RedShiftDataSource(SQLDataSource):
    SQLGLOT_DIALECT = "redshift"

    def __init__(self, data_source_name: str, data_connection: Dict):
        super().__init__(data_source_name, data_connection)

    def connect(self) -> Any:
        """
        Connect to the data source
        """
        try:
            url = URL.create(
                "redshift+psycopg2",
                username=self.data_connection.get("username"),
                password=self.data_connection.get("password"),
                host=self.data_connection.get("host"),
                port=self.data_connection.get("port"),
                database=self.data_connection.get("database"),
            )
            schema = self.data_connection.get("schema")
            engine = create_engine(
                url,
                connect_args={"options": f"-csearch_path={schema}"} if schema else None,
                isolation_level="AUTOCOMMIT",
            )

            self.schema_name = schema
            self.connection = engine.connect()
            return self.connection
        except Exception as e:
            raise DataChecksDataSourcesConnectionError(
                message=f"Failed to connect to AWS RedShift data source: [{str(e)}]"
            )

    def qualified_table_name(self, table_name: str) -> str:
        if self.schema_name:
            return f'"{self.schema_name}"."{table_name}"'
        return f'"{table_name}"'

    def quote_column(self, column: str) -> str:
        return f'"{column}"'

    def fetch_sample_values_from_database(
        self,
        table_name: str,
        column_names: list[str],
        limit: int = 5,
    ) -> Tuple[List[Tuple], List[str]]:
        qualified_table_name = self.qualified_table_name(table_name)

        if not column_names:
            raise ValueError("At least one column name must be provided")

        if len(column_names) == 1 and column_names[0] == "*":
            query = f"SELECT * FROM {qualified_table_name} LIMIT {limit}"
        else:
            columns = ", ".join([self.quote_column(col) for col in column_names])
            query = f"SELECT {columns} FROM {qualified_table_name} LIMIT {limit}"

        result = self.connection.execute(text(query))
        column_names = list(result.keys())
        rows = self.normalize_sample_rows(result.fetchall())
        return rows, column_names

    def query_sequences(self, schema: str) -> Dict[str, dict]:
        schema = schema or self.schema_name
        query = f"""
            SELECT sequence_name, start_value, increment, minimum_value,
                   maximum_value, cycle_option
            FROM information_schema.sequences
            WHERE sequence_schema = '{schema}'
        """
        rows = self.fetchall(query)
        return (
            {
                row[0]: {
                    "start_value": row[1],
                    "increment": row[2],
                    "min_value": row[3],
                    "max_value": row[4],
                    "current_value": None,
                    "cycle": row[5] == "YES",
                }
                for row in rows
            }
            if rows
            else {}
        )

    def get_view_dependency_map(self, schema: str) -> Dict[str, List[str]]:
        schema = schema or self.schema_name
        query = f"""
            SELECT view_name, table_name
            FROM information_schema.view_table_usage
            WHERE view_schema = '{schema}'
        """
        rows = self.fetchall(query)
        result: Dict[str, List[str]] = {}
        for view_name, table_name in rows or []:
            result.setdefault(view_name, []).append(table_name)
        return result

    def get_procedure_dependency_map(self, schema: str) -> Dict[str, List[str]]:
        schema = schema or self.schema_name
        query = f"""
            SELECT p.proname, pg_get_functiondef(p.oid)
            FROM pg_proc p
            JOIN pg_namespace n ON n.oid = p.pronamespace
            WHERE n.nspname = '{schema}'
        """
        rows = self.fetchall(query)
        result = {}
        for proc_name, definition in rows or []:
            if definition:
                result[proc_name] = self._extract_tables_from_sql(proc_name, definition)
        return result
