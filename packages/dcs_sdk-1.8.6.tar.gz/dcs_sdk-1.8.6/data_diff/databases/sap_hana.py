#  Copyright 2022-present, the Waterdip Labs Pvt. Ltd.
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

from typing import Any, ClassVar, Dict, Tuple, Type, Union

import attrs

from data_diff.abcs.database_types import (
    Boolean,
    ColType_UUID,
    Date,
    Datetime,
    DbPath,
    Decimal,
    Float,
    FractionalType,
    Integer,
    Native_UUID,
    String_UUID,
    TemporalType,
    Text,
    Time,
    Timestamp,
)
from data_diff.databases.base import (
    CHECKSUM_HEXDIGITS,
    CHECKSUM_OFFSET,
    TIMESTAMP_PRECISION_POS,
    BaseDialect,
    ConnectError,
    ThreadedDatabase,
    ThreadLocalInterpreter,
    import_helper,
)


@import_helper("hdbcli")
def import_hdbcli():
    import hdbcli.dbapi as hdbcli

    return hdbcli


@attrs.define(frozen=False)
class Dialect(BaseDialect):
    name = "SAP HANA"
    ROUNDS_ON_PREC_LOSS = True
    SUPPORTS_PRIMARY_KEY: ClassVar[bool] = True
    SUPPORTS_INDEXES: ClassVar[bool] = True
    TYPE_CLASSES = {
        # Dates / Times
        "date": Date,
        "time": Time,
        "seconddate": Timestamp,
        "timestamp": Timestamp,
        # Numbers
        "decimal": Decimal,
        "smalldecimal": Decimal,
        "float": Float,
        "real": Float,
        "double": Float,
        "integer": Integer,
        "int": Integer,
        "bigint": Integer,
        "smallint": Integer,
        "tinyint": Integer,
        # Text — varchar/nvarchar/char/nchar all normalize to same string repr
        "varchar": Text,
        "nvarchar": Text,
        "char": Text,
        "nchar": Text,
        "clob": Text,
        "nclob": Text,
        "text": Text,
        "alphanum": Text,
        "shorttext": Text,
        # Boolean
        "boolean": Boolean,
    }

    def quote(self, s: str, is_table: bool = False) -> str:
        return f'"{s}"'

    def render_tablepath(self, c, elem) -> str:
        path = tuple(p.strip('"') for p in elem.path)
        if len(path) == 1 and path[0] in self.TABLE_NAMES and self.default_schema:
            return f'"{self.default_schema}"."{path[0]}"'
        return ".".join(f'"{p}"' for p in path)

    def to_string(self, s: str) -> str:
        # NVARCHAR without length = max length in HANA; handles all text types including
        # varchar, nvarchar, char, nchar cross-DB comparisons (varchar<>nvarchar safe)
        return f"CAST({s} AS NVARCHAR)"

    def is_distinct_from(self, a: str, b: str) -> str:
        # HANA has no <=> operator; use explicit NULL-safe comparison
        return f"(({a} <> {b} OR {a} IS NULL OR {b} IS NULL) AND NOT ({a} IS NULL AND {b} IS NULL))"

    def random(self) -> str:
        return "RAND()"

    def type_repr(self, t) -> str:
        try:
            return {str: "NVARCHAR(1024)"}[t]
        except KeyError:
            return super().type_repr(t)

    def limit_select(
        self,
        select_query: str,
        offset=None,
        limit=None,
        has_order_by=None,
    ) -> str:
        # HANA does not support `AS alias` on derived tables in FROM — drop the AS keyword
        return f"SELECT * FROM ({select_query}) LIMITED_SELECT LIMIT {limit}"

    def explain_as_text(self, query: str) -> str:
        return f"EXPLAIN PLAN FOR {query}"

    def optimizer_hints(self, s: str):
        return f"/*+ {s} */ "

    def set_timezone_to_utc(self) -> str:
        # HANA timezone is set at connection level via currentSchema/sessionVariable;
        # returning a no-op valid SQL so the Connect_SetUTC wrapper doesn't error
        return "SELECT 1 FROM DUMMY"

    def md5_as_int(self, s: str) -> str:
        # No native MD5 in HANA — use HASH_SHA256 (64-char hex).
        # Take last CHECKSUM_HEXDIGITS (12) hex chars = 6 bytes, cast to BIGINT.
        SHA256_HEXDIGITS = 64
        hex_substr = (
            f"SUBSTRING(HASH_SHA256(TO_NVARCHAR({s})), "
            f"{1 + SHA256_HEXDIGITS - CHECKSUM_HEXDIGITS}, {CHECKSUM_HEXDIGITS})"
        )
        return f"CAST(HEXTOBIN({hex_substr}) AS BIGINT) - {CHECKSUM_OFFSET}"

    def md5_as_hex(self, s: str) -> str:
        return f"HASH_SHA256(TO_NVARCHAR({s}))"

    def normalize_timestamp(self, value: str, coltype: TemporalType) -> str:
        # Date: YYYY-MM-DD with NULL guard for cross-DB consistency
        if isinstance(coltype, Date):
            return f"CASE WHEN {value} IS NULL THEN NULL ELSE " f"TO_NVARCHAR({value}, 'YYYY-MM-DD') END"

        # Time: HH:MM:SS.ffffff with NULL guard
        if isinstance(coltype, Time):
            return f"CASE WHEN {value} IS NULL THEN NULL ELSE " f"TO_NVARCHAR({value}, 'HH24:MI:SS.FF6') END"

        # Timestamp / Seconddate: 'YYYY-MM-DD HH:MM:SS.ffffff' with NULL guard
        # HANA has no CAST(x AS TIMESTAMP(n)) — use plain CAST then TO_NVARCHAR format mask
        precision = getattr(coltype, "precision", 6) or 6
        if coltype.rounds:
            # rounds=True: re-cast to TIMESTAMP (triggers DB rounding), format at full 6 digits
            s = f"TO_NVARCHAR(CAST({value} AS TIMESTAMP), 'YYYY-MM-DD HH24:MI:SS.FF6')"
            # Pad to 6 fractional digits for cross-DB string comparison
            padded = f"RPAD(RPAD({s}, {TIMESTAMP_PRECISION_POS + 6}, '.'), {TIMESTAMP_PRECISION_POS + 6}, '0')"
        else:
            s = f"TO_NVARCHAR(CAST({value} AS TIMESTAMP), 'YYYY-MM-DD HH24:MI:SS.FF{precision}')"
            # Pad shorter precision to always 6 digits
            padded = f"RPAD(RPAD({s}, {TIMESTAMP_PRECISION_POS + precision}, '.'), {TIMESTAMP_PRECISION_POS + 6}, '0')"

        return f"CASE WHEN {value} IS NULL THEN NULL ELSE {padded} END"

    def normalize_number(self, value: str, coltype: FractionalType) -> str:
        precision = getattr(coltype, "precision", 0) or 0
        return self.to_string(f"CAST({value} AS DECIMAL(38, {precision}))")

    def normalize_uuid(self, value: str, coltype: ColType_UUID) -> str:
        if isinstance(coltype, String_UUID):
            return f"TRIM(CAST({value} AS NVARCHAR))"
        return self.to_string(value)

    def normalize_boolean(self, value: str, _coltype: Boolean) -> str:
        # HANA requires explicit = TRUE comparison in WHEN clause (no bare boolean expression)
        return self.to_string(f"CASE WHEN {value} IS NULL THEN NULL WHEN {value} = TRUE THEN 1 ELSE 0 END")

    def parse_table_name(self, name: str) -> DbPath:
        parts = tuple(name.split("."))
        self.TABLE_NAMES.append(parts[-1])
        return parts

    def create_view(self, query: str, schema: str | None, view_name: str | None = None) -> Tuple[str, str]:
        view_name = self.generate_view_name(view_name=view_name)
        db = self.default_schema or schema
        view_name_full = f'"{db}"."{view_name}"' if db else f'"{view_name}"'
        return f"CREATE VIEW {view_name_full} AS {query}", view_name_full

    def drop_view(self, view_name: str, schema: str | None) -> str:
        if '"' in view_name:
            return f"DROP VIEW {view_name}"
        if "." in view_name:
            parts = view_name.split(".", 1)
            return f'DROP VIEW "{parts[0]}"."{parts[1]}"'
        db = self.default_schema or schema
        view_name_full = f'"{db}"."{view_name}"' if db else f'"{view_name}"'
        return f"DROP VIEW {view_name_full}"


@attrs.define(frozen=False, init=False, kw_only=True)
class SAPHana(ThreadedDatabase):
    DIALECT_CLASS: ClassVar[Type[BaseDialect]] = Dialect
    SUPPORTS_ALPHANUMS = False
    SUPPORTS_UNIQUE_CONSTAINT = True
    CONNECT_URI_HELP = "hana://<user>:<password>@<host>:<port>/<database>"
    CONNECT_URI_PARAMS = ["database?"]

    _args: Dict[str, Any]

    def __init__(self, *, thread_count, **kw) -> None:
        super().__init__(thread_count=thread_count)
        self._args = kw
        self._args = {k: v for k, v in self._args.items() if v}
        # In HANA, schema and database are distinct concepts.
        # Use schema (if provided) as default_schema, falling back to database.
        # The database value is kept in _args for connection but schema drives table qualification.
        schema = kw.get("schema") or kw.get("database")
        if not schema:
            raise ValueError("SAP HANA connection must specify a database or schema")
        self.default_schema = schema
        self.dialect.default_schema = self.default_schema

    def create_connection(self):
        hdbcli = import_hdbcli()
        try:
            host = self._args.get("host")
            port = int(self._args.get("port", 30015))
            user = self._args.get("user")
            password = self._args.get("password")
            database = self._args.get("database")
            conn = hdbcli.connect(
                address=host,
                port=port,
                user=user,
                password=password,
                databaseName=database,
                currentSchema=self.default_schema,
            )
            return conn
        except Exception as e:
            raise ConnectError(*e.args) from e

    def _query_in_worker(self, sql_code: Union[str, ThreadLocalInterpreter], is_commit: bool = False):
        if self._init_error:
            raise self._init_error
        return self._query_conn(self.thread_local.conn, sql_code, is_commit=is_commit)

    def create_view_from_query(
        self,
        query: str,
        schema: str | None = None,
        view_name: str | None = None,
        real_database: str | None = None,
    ) -> str:
        view_schema = schema or self.default_schema
        view_name_gen = self.dialect.generate_view_name(view_name)
        view_name_full = f'"{view_schema}"."{view_name_gen}"' if view_schema else f'"{view_name_gen}"'
        view_query = f"CREATE VIEW {view_name_full} AS {query}"
        self.query(view_query, is_commit=True)
        return f"{view_schema}.{view_name_gen}" if view_schema else view_name_gen

    def _strip_quotes(self, s: str) -> str:
        return s.strip('"')

    def select_table_schema(self, path: DbPath) -> str:
        path = tuple(self._strip_quotes(p) for p in path)
        schema, name = self._normalize_table_path(path)
        # LOWER(DATA_TYPE_NAME) so TYPE_CLASSES lookup (lowercase keys) works.
        # COLUMN_NAME returned as-is — exact case from DB matches what user specified in config.
        # UNION ALL with SYS.VIEW_COLUMNS so query-based comparisons (views) are also resolved.
        return (
            "SELECT COLUMN_NAME, LOWER_DATA_TYPE_NAME, DT_PREC, COL_LEN, COL_SCALE, COL_COLL, COL_LEN2 "
            "FROM ("
            "SELECT COLUMN_NAME, LOWER(DATA_TYPE_NAME) AS LOWER_DATA_TYPE_NAME, NULL AS DT_PREC, LENGTH AS COL_LEN, SCALE AS COL_SCALE, NULL AS COL_COLL, LENGTH AS COL_LEN2, POSITION "
            "FROM SYS.TABLE_COLUMNS "
            f"WHERE TABLE_NAME = '{name}' AND SCHEMA_NAME = '{schema}' "
            "UNION ALL "
            "SELECT COLUMN_NAME, LOWER(DATA_TYPE_NAME) AS LOWER_DATA_TYPE_NAME, NULL AS DT_PREC, LENGTH AS COL_LEN, SCALE AS COL_SCALE, NULL AS COL_COLL, LENGTH AS COL_LEN2, POSITION "
            "FROM SYS.VIEW_COLUMNS "
            f"WHERE VIEW_NAME = '{name}' AND SCHEMA_NAME = '{schema}' "
            ") hana_cols ORDER BY POSITION"
        )

    def select_table_unique_columns(self, path: DbPath) -> str:
        path = tuple(self._strip_quotes(p) for p in path)
        schema, name = self._normalize_table_path(path)
        return (
            "SELECT COLUMN_NAME "
            "FROM SYS.CONSTRAINTS "
            f"WHERE TABLE_NAME = '{name}' AND SCHEMA_NAME = '{schema}' "
            "AND IS_UNIQUE_KEY = 'TRUE'"
        )
