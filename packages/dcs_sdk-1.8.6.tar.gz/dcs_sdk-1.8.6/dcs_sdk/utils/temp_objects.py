#  Copyright 2022-present, the Waterdip Labs Pvt. Ltd.
#
#  Licensed under the Apache License, Version 2.0 (the "License");
#  you may not use this file except in compliance with the License.
#  You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS,
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#  See the License for the specific language governing permissions and
#  limitations under the License.

import secrets
import string
import time

TEMP_OBJECT_PREFIX = "datachecks_"


def ensure_temp_object_prefix(name: str, uppercase: bool = False) -> str:
    normalized_name = name.strip()
    if normalized_name.lower().startswith(TEMP_OBJECT_PREFIX):
        return normalized_name.upper() if uppercase else normalized_name

    prefixed_name = f"{TEMP_OBJECT_PREFIX}{normalized_name}"
    return prefixed_name.upper() if uppercase else prefixed_name


def generate_temp_object_name(object_type: str = "view", uppercase: bool = False) -> str:
    random_string = "".join(secrets.choice(string.ascii_letters + string.digits) for _ in range(8)).lower()
    timestamp = int(time.time())
    return ensure_temp_object_prefix(
        f"{object_type}_{timestamp}_{random_string}",
        uppercase=uppercase,
    )
