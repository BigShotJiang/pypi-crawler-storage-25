from setuptools import setup, find_packages

setup(
    name="danger-ff-version-updater",
    version="7.7.7.7.7",
    author="T.ME/DANGER_FF_DEV",
    description="Fetch Free Fire client endpoints, versions, and server URL with region-based logic",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=[
        "requests",
        "google-play-scraper"
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
)