# freefire-endpoints

Free Fire ke liye **Client URL, Server URL, Release Version, Client Version** fetch karne wala package.

## Installation

```bash
pip install danger-ff-version-updater