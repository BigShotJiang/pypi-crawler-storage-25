import requests
from google_play_scraper import app

def _get_latest_version(package_name="com.dts.freefireth", lang="fr", country="fr"):
    """Play Store se latest app version fetch karega"""
    try:
        app_info = app(package_name, lang=lang, country=country)
        return app_info["version"]
    except Exception as e:
        raise Exception(f"Play Store se version nahi mila: {e}")

def _fetch_api_data(version, region="ME"):
    """version.ggwhitehawk.com se data fetch karega"""
    url = "https://version.ggwhitehawk.com/live/ver.php"
    params = {
        "version": version,
        "lang": "en",
        "device": "android",
        "channel": "android",
        "appsttore": "googleplay",
        "region": region,
        "whitelist_version": "1.3.0",
        "whitelist_sp_version": "1.0.0",
        "device_name": "google G011A"
    }
    resp = requests.get(url, params=params, timeout=10)
    resp.raise_for_status()
    return resp.json()
def get_categories():
    base = get_freefire_info("US")
    sv = base["server_url"]          # e.g., "https://loginbp.ggpolarbear.com/"
    rv = base["release_version"]
    cv = base["client_version"]

    # Helper to add https:// and trailing slash if missing
    def format_url(domain):
        # domain could be "client.ind.freefiremobile.com" or "clientbp.ggpolarbear.com" etc.
        if not domain.startswith("http"):
            domain = "https://" + domain
        if not domain.endswith("/"):
            domain = domain + "/"
        return domain

    def client_domain(region):
        r = region.upper()
        if r == "IND":
            return "client.ind.freefiremobile.com"
        if r in {"BR", "US", "NA", "SAC"}:
            return "client.us.freefiremobile.com"
        # Dynamic
        if "loginbp." in sv:
            return sv.replace("loginbp.", "clientbp.").replace("https://", "").rstrip("/")
        return sv.replace("https://", "").rstrip("/")

    ind_domain = client_domain("IND")
    america_domain = client_domain("US")
    others_domain = client_domain("ME")

    return {
        "IND": {
            "client_url": format_url(ind_domain),
            "server_url": sv,
            "release_version": rv,
            "client_version": cv
        },
        "AMERICA": {
            "client_url": format_url(america_domain),
            "server_url": sv,
            "release_version": rv,
            "client_version": cv
        },
        "OTHERS": {
            "client_url": format_url(others_domain),
            "server_url": sv,
            "release_version": rv,
            "client_version": cv
        }
    }
def _build_client_url(server_url, region):
    """Region ke according client URL return karega"""
    region_upper = region.upper()

    # 1. IND hardcoded
    if region_upper == "IND":
        return "client.ind.freefiremobile.com"

    # 2. BR, US, NA, SAC hardcoded
    if region_upper in {"BR", "US", "NA", "SAC"}:
        return "client.us.freefiremobile.com"

    # 3. Else: loginbp.xxx.com -> clientbp.xxx.com
    if "loginbp." in server_url:
        return server_url.replace("loginbp.", "clientbp.")
    else:
        # fallback – agar pattern match nahi hota toh server_url hi return kar do
        return server_url

def get_freefire_info(region="US", package_name="com.dts.freefireth", lang="fr", country="fr"):
    """
    Main function – Free Fire ke saare endpoints & versions return karega

    Returns:
        dict: {
            "release_version": str,   # latest_release_version
            "client_version": str,    # remote_version
            "server_url": str,        # loginbp.xxx.com
            "client_url": str         # region ke according client domain
        }
    """
    # 1. Latest version from Play Store
    current_version = _get_latest_version(package_name, lang, country)

    # 2. API se data fetch
    api_data = _fetch_api_data(current_version)

    server_url = api_data["server_url"]
    release_version = api_data["latest_release_version"]
    client_version = api_data["remote_version"]

    # 3. Client URL decide karo
    client_url = _build_client_url(server_url, region)

    return {
        "release_version": release_version,
        "client_version": client_version,
        "server_url": server_url,
        "client_url": client_url
    }