from .core import get_freefire_info, get_categories

__all__ = ["get_freefire_info"]