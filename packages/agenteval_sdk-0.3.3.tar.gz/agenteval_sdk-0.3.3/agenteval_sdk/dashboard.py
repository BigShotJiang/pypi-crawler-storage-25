"""Local Flask dashboard for viewing traces stored in the SDK's SQLite DB.

Launch via ``agenteval dashboard`` or directly::

    python -m agenteval_sdk.dashboard
"""

from __future__ import annotations

import os
from typing import Optional

from flask import Flask, jsonify, render_template, request

from .local_store import LocalStore

_TEMPLATE_DIR = os.path.join(os.path.dirname(__file__), "templates")


def create_app(db_path: Optional[str] = None) -> Flask:
    """Build and return the Flask application."""
    app = Flask(__name__, template_folder=_TEMPLATE_DIR)
    store = LocalStore(db_path)

    @app.route("/")
    def index():
        return render_template("dashboard.html")

    @app.route("/trace-tree")
    def trace_tree():
        case_id = request.args.get("case_id", "")
        return render_template("trace_tree.html", case_id=case_id)

    @app.route("/api/trace-tree/<trace_id>")
    def api_trace_tree(trace_id):
        spans = store.get_by_trace_id(trace_id)
        return jsonify(spans)

    @app.route("/api/traces")
    def api_traces():
        limit = request.args.get("limit", 100, type=int)
        limit = min(max(limit, 1), 1000)
        rows = store.get_recent(limit=limit)
        return jsonify(rows)

    @app.route("/api/status")
    def api_status():
        total = store.count()
        synced = store.count(synced_only=True)
        return jsonify({
            "db_path": store.path,
            "total": total,
            "synced": synced,
            "pending": total - synced,
        })

    @app.route("/api/clear", methods=["POST"])
    def api_clear():
        deleted = store.clear()
        return jsonify({"deleted": deleted})

    return app


def run(db_path: Optional[str] = None, port: int = 8787, open_browser: bool = True) -> None:
    """Start the dashboard server."""
    app = create_app(db_path)
    url = f"http://127.0.0.1:{port}"
    print(f"AgentEval local dashboard running at {url}")
    print("Press Ctrl+C to stop.\n")

    if open_browser:
        import webbrowser
        import threading
        threading.Timer(1.0, webbrowser.open, args=[url]).start()

    app.run(host="127.0.0.1", port=port, debug=False)


if __name__ == "__main__":
    run()
