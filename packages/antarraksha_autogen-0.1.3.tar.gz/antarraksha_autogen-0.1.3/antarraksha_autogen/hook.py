"""AutoGen hook for Antarraksha enforcement."""

from typing import Any, Dict, List, Optional

from .client import AntarrakshaClient


class AntarrakshaAutoGenHook:
    """Antarraksha enforcement hook for Microsoft AutoGen agents.

    Usage:
        from antarraksha_autogen import AntarrakshaAutoGenHook

        hook = AntarrakshaAutoGenHook(
            base_url="https://antarraksha.ai",
            agent_id="my-autogen-agent",
            passport_id="ANTK-PASS-xxx",
        )

        # Use as a message filter in AutoGen
        hook.filter_message(sender="assistant", message="Execute command: ls -la")
    """

    def __init__(
        self,
        base_url: str = "https://antarraksha.ai",
        agent_id: Optional[str] = None,
        passport_id: Optional[str] = None,
        sdk_key: Optional[str] = None,
        fail_closed: bool = True,
    ):
        self.client = AntarrakshaClient(
            base_url=base_url,
            agent_id=agent_id,
            passport_id=passport_id,
            sdk_key=sdk_key,
            framework="autogen",
            fail_closed=fail_closed,
        )
        if not sdk_key and agent_id:
            try:
                self.client.register(capabilities=["autogen_agent"])
            except Exception:
                pass

    def filter_message(self, sender: str, message: str) -> Dict[str, Any]:
        result = self.client.intercept(
            call_type="message",
            call_name=f"autogen_message_{sender}",
            parameters={"sender": sender, "message_length": len(message)},
        )
        return result

    def check_code_execution(self, code: str, language: str = "python") -> Dict[str, Any]:
        return self.client.intercept(
            call_type="code_execution",
            call_name=f"execute_{language}",
            parameters={"language": language, "code_length": len(code)},
        )

    def check_function_call(self, function_name: str, arguments: Optional[Dict] = None) -> Dict[str, Any]:
        return self.client.intercept(
            call_type="function_call",
            call_name=function_name,
            parameters=arguments or {},
        )

    def check_group_chat_message(self, sender: str, recipient: str, message_length: int) -> Dict[str, Any]:
        return self.client.intercept(
            call_type="group_chat",
            call_name=f"{sender}_to_{recipient}",
            parameters={"sender": sender, "recipient": recipient, "message_length": message_length},
        )
