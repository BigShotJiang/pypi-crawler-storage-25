"""Core Antarraksha enforcement client."""

import hashlib
import json
import time
from typing import Any, Dict, List, Optional

import requests


class AntarrakshaClient:
    """Client for Antarraksha AI Agent Enforcement Platform."""

    def __init__(
        self,
        base_url: str = "https://antarraksha.ai",
        agent_id: Optional[str] = None,
        passport_id: Optional[str] = None,
        sdk_key: Optional[str] = None,
        framework: str = "langchain",
        enforcement_mode: str = "inline",
        timeout: float = 5.0,
        fail_closed: bool = True,
    ):
        self.base_url = base_url.rstrip("/")
        self.agent_id = agent_id
        self.passport_id = passport_id
        self.sdk_key = sdk_key
        self.framework = framework
        self.enforcement_mode = enforcement_mode
        self.timeout = timeout
        self.fail_closed = fail_closed
        self._session = requests.Session()
        self._session.headers.update({
            "Content-Type": "application/json",
            "X-Antarraksha-Framework": framework,
            "X-Antarraksha-SDK-Version": "0.1.0",
        })

    def register(self, capabilities: Optional[List[str]] = None) -> Dict[str, Any]:
        resp = self._session.post(
            f"{self.base_url}/api/integration/sdk/register",
            json={
                "agentId": self.agent_id,
                "passportId": self.passport_id,
                "framework": self.framework,
                "version": "0.1.0",
                "capabilities": capabilities or [],
                "enforcementMode": self.enforcement_mode,
            },
            timeout=self.timeout,
        )
        resp.raise_for_status()
        data = resp.json()
        self.sdk_key = data.get("registration", {}).get("sdkKey")
        return data

    def intercept(
        self,
        call_type: str,
        call_name: str,
        parameters: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        if not self.sdk_key:
            if self.fail_closed:
                return {"decision": "DENY", "reason": "No SDK key — fail-closed", "allowed": False}
            return {"decision": "ALLOW", "reason": "No SDK key — fail-open", "allowed": True}

        try:
            resp = self._session.post(
                f"{self.base_url}/api/integration/sdk/intercept",
                json={
                    "sdkKey": self.sdk_key,
                    "callType": call_type,
                    "callName": call_name,
                    "parameters": parameters or {},
                },
                timeout=self.timeout,
            )
            resp.raise_for_status()
            return resp.json()
        except (requests.RequestException, Exception) as e:
            if self.fail_closed:
                return {"decision": "DENY", "reason": f"Enforcement unreachable — fail-closed: {e}", "allowed": False}
            return {"decision": "ALLOW", "reason": f"Enforcement unreachable — fail-open: {e}", "allowed": True}

    def heartbeat(self) -> Dict[str, Any]:
        if not self.sdk_key:
            return {"error": "No SDK key"}
        resp = self._session.post(
            f"{self.base_url}/api/integration/sdk/heartbeat",
            json={"sdkKey": self.sdk_key},
            timeout=self.timeout,
        )
        resp.raise_for_status()
        return resp.json()

    def submit_agent(
        self,
        agent_name: str,
        agent_url: str,
        description: str,
        model: str,
        capabilities: List[str],
        contact_email: str,
    ) -> Dict[str, Any]:
        resp = self._session.post(
            f"{self.base_url}/api/external/submit",
            json={
                "agentName": agent_name,
                "agentUrl": agent_url,
                "description": description,
                "model": model,
                "capabilities": capabilities,
                "contactEmail": contact_email,
            },
            timeout=self.timeout,
        )
        resp.raise_for_status()
        return resp.json()

    def verify_certificate(self, certificate_id: str) -> Dict[str, Any]:
        resp = self._session.get(
            f"{self.base_url}/api/gaasi/certification/verify/{certificate_id}",
            timeout=self.timeout,
        )
        resp.raise_for_status()
        return resp.json()

    def verify_passport(self, passport_id: str) -> Dict[str, Any]:
        resp = self._session.get(
            f"{self.base_url}/api/passport/verify/{passport_id}",
            timeout=self.timeout,
        )
        resp.raise_for_status()
        return resp.json()
