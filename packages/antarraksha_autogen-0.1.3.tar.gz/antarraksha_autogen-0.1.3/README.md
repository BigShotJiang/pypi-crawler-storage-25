# antarraksha-autogen

Antarraksha AI Agent Enforcement SDK for Microsoft AutoGen.

## Installation

```bash
pip install antarraksha-autogen
```

## Quick Start

Instantiate the Antarraksha hook and call its filter methods from inside your AutoGen message handlers and code executors. Registration happens automatically on first use — no login, no API key, no signup required.

```python
from antarraksha_autogen import AntarrakshaAutoGenHook

hook = AntarrakshaAutoGenHook(agent_id="my-autogen-agent")

result = hook.filter_message(sender="assistant", message="Execute command: ls -la")
if result["decision"] == "DENY":
    raise PermissionError(result["reason"])

result = hook.check_code_execution(code="import os; os.system('rm -rf /')", language="python")
if result["decision"] == "DENY":
    raise PermissionError(result["reason"])
```

Wire `filter_message` into your AutoGen agent's message middleware and `check_code_execution` into your code-executor pre-hook. Every intercepted call is logged and visible at `https://antarraksha.ai/registry`.

## Parameters

| Parameter | Default | Description |
|---|---|---|
| `agent_id` | `None` | Unique identifier for your agent. Triggers auto-registration on first use. |
| `base_url` | `"https://antarraksha.ai"` | Antarraksha endpoint. Override for self-hosted / dev. |
| `passport_id` | `None` | Optional pre-issued passport ID (e.g. `ANTK-PASS-xxx`). |
| `sdk_key` | `None` | Optional pre-issued SDK key. If omitted and `agent_id` is set, the SDK auto-registers and obtains one. |
| `fail_closed` | `True` | If `True`, deny on enforcement-server unreachable. Set `False` for fail-open during early integration. |

## Corporate Network Note

If you're behind a corporate TLS-inspection proxy and see `SSLCertVerificationError`, install:

```bash
pip install pip-system-certs
```

This makes Python trust your Windows / macOS system certificate store.
