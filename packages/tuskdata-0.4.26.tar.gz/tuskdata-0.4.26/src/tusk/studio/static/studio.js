// Tusk Studio - Main JavaScript Module
// CodeMirror 6 imports
import {EditorState, StateField, StateEffect, RangeSet} from "https://esm.sh/@codemirror/state@6"
import {EditorView, keymap, lineNumbers, highlightActiveLine, drawSelection, Decoration} from "https://esm.sh/@codemirror/view@6"
import {defaultKeymap, indentWithTab, historyKeymap, history} from "https://esm.sh/@codemirror/commands@6"
import {sql, PostgreSQL, SQLite} from "https://esm.sh/@codemirror/lang-sql@6"
import {autocompletion, completeFromList} from "https://esm.sh/@codemirror/autocomplete@6"
import {oneDark} from "https://esm.sh/@codemirror/theme-one-dark@6"
import {bracketMatching, defaultHighlightStyle, syntaxHighlighting} from "https://esm.sh/@codemirror/language@6"
import {searchKeymap, highlightSelectionMatches, selectNextOccurrence} from "https://esm.sh/@codemirror/search@6"
import {closeBrackets, closeBracketsKeymap, completionKeymap} from "https://esm.sh/@codemirror/autocomplete@6"
import {toggleLineComment} from "https://esm.sh/@codemirror/commands@6"

// ─── Top-level state ─────────────────────────────────────────────
// `currentEngine` is referenced from many functions further down the
// file. With `let` it's in the temporal dead zone until the declaration
// line executes, so a function called during module load (or by another
// script before studio.js fully evaluated) used to throw
// `Cannot access 'currentEngine' before initialization`. Hoisting the
// declaration to the top fixes that.
let currentEngine = 'postgres'; // 'postgres' | 'sqlite' | 'duckdb'
window.currentEngine = currentEngine;

// ─── HTML escape helper (XSS guard for innerHTML / attribute interpolation) ─
// Used to safely interpolate user-controlled strings (connection names,
// saved query names, history snippets, file paths) into innerHTML and
// HTML attributes. Without this, a connection named `'); alert(1); //`
// would execute as JS via the inline onclick handlers we generate.
function escapeHtml(s) {
    if (s == null) return "";
    return String(s)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;");
}
window.escapeHtml = escapeHtml;

// ─── Error highlight extension ──────────────────────────────────
// `setQueryError` effect adds a line decoration with an underline on the
// SQL line that the server flagged. `clearQueryError` clears it.
const setQueryError = StateEffect.define();
const clearQueryError = StateEffect.define();
const queryErrorField = StateField.define({
    create() { return Decoration.none; },
    update(deco, tr) {
        deco = deco.map(tr.changes);
        for (const e of tr.effects) {
            if (e.is(clearQueryError)) deco = Decoration.none;
            else if (e.is(setQueryError)) {
                const {from, to} = e.value;
                // Defensive: CodeMirror's `Decoration.mark` throws
                // `Mark decorations may not be empty` when from >= to.
                // The caller should never dispatch an empty range, but
                // off-by-one bugs at end-of-doc used to slip through —
                // skip rather than crash the editor.
                if (typeof from === "number" && typeof to === "number" && to > from) {
                    deco = Decoration.set([
                        Decoration.mark({class: "cm-query-error"}).range(from, to),
                    ]);
                }
            }
        }
        // Auto-clear on any further edit
        if (tr.docChanged && deco.size) deco = Decoration.none;
        return deco;
    },
    provide: f => EditorView.decorations.from(f),
});

const queryErrorTheme = EditorView.theme({
    ".cm-query-error": {
        textDecoration: "underline wavy var(--red, #cc2e3d)",
        textUnderlineOffset: "3px",
        background: "rgba(204, 46, 61, 0.10)",
    },
});

window.highlightQueryError = function(position) {
    if (!editor || !position) return;
    const doc = editor.state.doc;
    if (doc.length === 0) return;  // empty doc — nothing to highlight
    let offset = Math.max(0, Math.min(doc.length - 1, position - 1));
    // Underline from offset to end of token (next whitespace/punctuation).
    const text = doc.toString();
    let end = offset;
    while (end < text.length && /[A-Za-z0-9_.]/.test(text[end])) end++;
    // Always keep `end > offset` so Decoration.mark gets a non-empty range.
    if (end <= offset) end = Math.min(text.length, offset + 1);
    if (end <= offset) {
        // Last-resort: walk one back if we're at the very end.
        offset = Math.max(0, end - 1);
    }
    if (end > offset) {
        editor.dispatch({effects: setQueryError.of({from: offset, to: end})});
    }
};

window.clearQueryErrorHighlight = function() {
    if (!editor) return;
    editor.dispatch({effects: clearQueryError.of(null)});
};

let currentConnection = null;
let currentSchema = {};
let editor = null;

// Query execution state
let queryAbortController = null;

// Query tabs state
let tabs = [];
let activeTabId = null;
let tabCounter = 0;

// Load tabs from localStorage on start
function loadTabsFromLocalStorage() {
    try {
        const saved = localStorage.getItem('tusk_tabs');
        if (saved) {
            const data = JSON.parse(saved);
            tabs = data.tabs || [];
            activeTabId = data.activeTabId;
            tabCounter = data.tabCounter || 0;

            // Clean up results from loaded tabs (to avoid memory issues)
            tabs.forEach(t => t.results = null);

            return tabs.length > 0;
        }
    } catch (e) {
        console.error('Failed to load tabs from localStorage:', e);
    }
    return false;
}

// Save tabs to localStorage
function saveTabsToLocalStorage() {
    try {
        // Save current editor content to active tab before saving
        if (activeTabId && editor) {
            const currentTab = tabs.find(t => t.id === activeTabId);
            if (currentTab) {
                currentTab.sql = editor.state.doc.toString();
            }
        }

        // Don't save results (too large), just save the SQL and tab info
        const tabsToSave = tabs.map(t => ({
            id: t.id,
            name: t.name,
            sql: t.sql,
            connectionId: t.connectionId
        }));

        localStorage.setItem('tusk_tabs', JSON.stringify({
            tabs: tabsToSave,
            activeTabId,
            tabCounter
        }));
    } catch (e) {
        console.error('Failed to save tabs to localStorage:', e);
    }
}

// Results state for current tab
let currentResults = null;
let sortColumn = null;
let sortDirection = 'asc';
let filterText = '';
let currentPage = 1;
const PAGE_SIZE = 100;

// Server-side pagination state
let serverPagination = false;  // true when using server-side pagination
let currentSql = '';  // SQL for re-fetching pages
let mapGeoData = null;  // Separate geometry data for map

// Generate a unique tab ID
function generateTabId() {
    return `tab-${++tabCounter}`;
}

// Create a new tab
window.createTab = function(name = null, sqlText = "SELECT * FROM ") {
    const id = generateTabId();
    const tab = {
        id,
        name: name || `Query ${tabCounter}`,
        sql: sqlText,
        savedSql: sqlText,
        dirty: false,
        connectionId: currentConnection?.id || null,
        results: null
    };
    tabs.push(tab);
    switchTab(id);
    saveTabsToLocalStorage();
    return id;
}

window.markActiveTabDirty = function() {
    const tab = tabs.find(t => t.id === activeTabId);
    if (!tab || !editor) return;
    const current = editor.state.doc.toString();
    const dirty = current !== (tab.savedSql ?? "");
    if (tab.dirty !== dirty) {
        tab.dirty = dirty;
        renderTabs();
    }
}

window.renameTab = function(tabId) {
    const tab = tabs.find(t => t.id === tabId);
    if (!tab) return;
    const next = window.prompt("Rename tab:", tab.name);
    if (next && next.trim()) {
        tab.name = next.trim();
        renderTabs();
        saveTabsToLocalStorage();
    }
}

// Switch to a tab
window.switchTab = function(tabId) {
    // Save current tab content before switching
    if (activeTabId && editor) {
        const currentTab = tabs.find(t => t.id === activeTabId);
        if (currentTab) {
            currentTab.sql = editor.state.doc.toString();
            currentTab.results = currentResults;
            currentTab.connectionId = currentConnection?.id || currentTab.connectionId || null;
        }
    }

    activeTabId = tabId;
    const tab = tabs.find(t => t.id === tabId);

    if (tab && editor) {
        // Restore tab content
        editor.dispatch({
            changes: { from: 0, to: editor.state.doc.length, insert: tab.sql }
        });

        // Restore results
        currentResults = tab.results;
        window.currentResults = currentResults;
        sortColumn = null;
        sortDirection = 'asc';
        filterText = '';
        currentPage = 1;

        // Reset the result-pane view to Table on every tab switch.
        // Otherwise, if the previous tab left the view on Map / JSON /
        // Plan, the new tab opens to that pane (often empty) and the
        // user has to click Table by hand to see their results.
        if (typeof window.setResultView === 'function') {
            window.setResultView('table');
        }

        renderResults();

        // Follow tab's connection if it differs from the current one.
        // selectConnection() reloads schema + autocomplete, so only call
        // it when the connection actually changes.
        if (tab.connectionId && tab.connectionId !== currentConnection?.id
                && typeof window.selectConnectionById === 'function') {
            window.selectConnectionById(tab.connectionId);
        }
    }

    renderTabs();
    saveTabsToLocalStorage();
}

// Close a tab
window.closeTab = function(tabId, event) {
    if (event) {
        event.stopPropagation();
    }

    const tabIndex = tabs.findIndex(t => t.id === tabId);
    if (tabIndex === -1) return;

    const tab = tabs[tabIndex];
    if (tab && tab.dirty) {
        if (!window.confirm(`"${tab.name}" has unsaved changes. Close anyway?`)) {
            return;
        }
    }

    // Don't close the last tab
    if (tabs.length === 1) {
        // Reset it instead
        tabs[0].sql = "SELECT * FROM ";
        tabs[0].results = null;
        currentResults = null;
        if (editor) {
            editor.dispatch({
                changes: { from: 0, to: editor.state.doc.length, insert: tabs[0].sql }
            });
        }
        renderResults();
        renderTabs();
        saveTabsToLocalStorage();
        return;
    }

    tabs.splice(tabIndex, 1);

    // If we closed the active tab, switch to an adjacent one
    if (activeTabId === tabId) {
        const newIndex = Math.min(tabIndex, tabs.length - 1);
        switchTab(tabs[newIndex].id);
    } else {
        renderTabs();
        saveTabsToLocalStorage();
    }
}

// Render tabs UI — v0.4 .qtab styling
function renderTabs() {
    const container = document.getElementById('query-tabs');
    if (!container) return;
    container.innerHTML = tabs.map(tab => `
        <div class="qtab ${tab.id === activeTabId ? 'active' : ''} ${tab.dirty ? 'dirty' : ''}"
             data-tab-id="${escapeHtml(tab.id)}"
             onclick="switchTab(this.dataset.tabId)"
             ondblclick="renameTab(this.dataset.tabId)"
             title="Double-click to rename">
            <i data-lucide="file-text"></i>
            <span>${escapeHtml(tab.name)}</span>
            <span class="x" onclick="event.stopPropagation(); closeTab(this.parentElement.dataset.tabId, event)" title="Close tab">
                <i data-lucide="x"></i>
            </span>
        </div>
    `).join('');
    if (window.lucide) lucide.createIcons();
    // Update editor toolbar dirty chip
    const dirty = tabs.find(t => t.id === activeTabId)?.dirty;
    const chip = document.getElementById('dirty-chip');
    if (chip) chip.style.display = dirty ? '' : 'none';
}

// Format cell value for display
const _ISO_DATE_RE = /^\d{4}-\d{2}-\d{2}([ T]\d{2}:\d{2}(:\d{2}(\.\d+)?)?(Z|[+-]\d{2}:?\d{2})?)?$/;

function _formatNumber(n) {
    if (!Number.isFinite(n)) return String(n);
    if (Number.isInteger(n)) return n.toLocaleString();
    // Keep up to 6 fractional digits, trim trailing zeroes.
    return n.toLocaleString(undefined, { maximumFractionDigits: 6 });
}

function _formatMaybeDate(s) {
    if (!_ISO_DATE_RE.test(s)) return null;
    const d = new Date(s.includes('T') || s.includes(' ') ? s : s + 'T00:00:00Z');
    if (Number.isNaN(d.getTime())) return null;
    // Compact: YYYY-MM-DD HH:MM:SS if it has time, else just date.
    const pad = (n) => String(n).padStart(2, '0');
    const base = `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}`;
    if (!s.includes('T') && !s.includes(' ')) return base;
    return `${base} ${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}:${pad(d.getUTCSeconds())}`;
}

function formatCell(value, type = '') {
    if (value === null) {
        return '<span class="null-badge">NULL</span>';
    }
    if (value === true) return '<span class="text-green-400">✓</span>';
    if (value === false) return '<span class="text-red-400">✗</span>';
    if (typeof value === 'number') {
        return `<span class="text-amber-300">${_formatNumber(value)}</span>`;
    }
    if (typeof value === 'object') {
        const json = JSON.stringify(value).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
        return `<span class="text-purple-400 font-mono text-xs">${json}</span>`;
    }
    const raw = String(value);
    const asDate = _formatMaybeDate(raw);
    if (asDate) {
        return `<span class="text-sky-300" title="${raw.replace(/"/g, '&quot;')}">${asDate}</span>`;
    }
    const escaped = raw.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    if (escaped.length > 100) {
        return `<span title="${escaped.replace(/"/g, '&quot;')}">${escaped.slice(0, 100)}...</span>`;
    }
    return escaped;
}

// Per-column filter state (column index → substring filter)
let columnFilters = {};
// Selected row indices (client-side rows, after filter/sort)
let selectedRows = new Set();

// Get filtered and sorted data
function getProcessedRows() {
    if (!currentResults || !currentResults.rows) return [];

    let rows = [...currentResults.rows];

    // Apply global filter
    if (filterText) {
        const lowerFilter = filterText.toLowerCase();
        rows = rows.filter(row =>
            row.some(cell =>
                cell !== null && String(cell).toLowerCase().includes(lowerFilter)
            )
        );
    }

    // Apply per-column filters
    const colFilterEntries = Object.entries(columnFilters).filter(([, v]) => v);
    if (colFilterEntries.length) {
        rows = rows.filter(row =>
            colFilterEntries.every(([i, needle]) => {
                const cell = row[Number(i)];
                if (cell === null || cell === undefined) return false;
                return String(cell).toLowerCase().includes(needle.toLowerCase());
            })
        );
    }

    // Apply sort
    if (sortColumn !== null && currentResults.columns[sortColumn]) {
        rows.sort((a, b) => {
            const aVal = a[sortColumn];
            const bVal = b[sortColumn];

            if (aVal === null && bVal === null) return 0;
            if (aVal === null) return sortDirection === 'asc' ? 1 : -1;
            if (bVal === null) return sortDirection === 'asc' ? -1 : 1;

            if (typeof aVal === 'number' && typeof bVal === 'number') {
                return sortDirection === 'asc' ? aVal - bVal : bVal - aVal;
            }

            const aStr = String(aVal).toLowerCase();
            const bStr = String(bVal).toLowerCase();
            if (sortDirection === 'asc') {
                return aStr.localeCompare(bStr);
            }
            return bStr.localeCompare(aStr);
        });
    }

    return rows;
}

// Map a SQL/PG type code or string to a UI category for cell coloring
function _typeCategory(type) {
    const t = String(type || '').toLowerCase();
    if (!t) return 'str';
    if (t === 'geometry' || t.includes('geom') || t.includes('geo')) return 'geo';
    if (t.includes('uuid')) return 'uuid';
    if (t.includes('bool') || t === '16') return 'bool';
    if (t.includes('json')) return 'json';
    if (t.includes('int') || t.includes('numeric') || t.includes('decimal')
        || t.includes('real') || t.includes('double') || t.includes('float')
        || /^(20|21|23|700|701|1700|1043)$/.test(t)) return 'num';
    if (t.includes('timestamp') || t.includes('date') || t.includes('time')) return 'date';
    return 'str';
}

function _typeShort(type) {
    const t = String(type || '').toLowerCase();
    if (!t) return '';
    // PG OIDs → friendly names
    const map = {
        '16': 'bool', '20': 'int8', '21': 'int2', '23': 'int4',
        '25': 'text', '700': 'float4', '701': 'float8', '1043': 'varchar',
        '1700': 'numeric', '1082': 'date', '1114': 'timestamp', '1184': 'timestamptz',
        '2950': 'uuid', '114': 'json', '3802': 'jsonb',
    };
    if (map[t]) return map[t];
    if (t.length <= 12) return t;
    return t.slice(0, 12);
}

function _cellClass(cell, category) {
    if (cell === null || cell === undefined) return 'null-cell';
    return category + '-cell';
}

// Update the chips at the top-left of the results toolbar
function _updateResultChips(rowCount, execMs, isPaginated, hasGeo) {
    const stats = document.getElementById('result-stats-chip');
    const statsText = document.getElementById('result-stats-text');
    if (stats && statsText) {
        if (rowCount === null) {
            stats.style.display = 'none';
        } else {
            stats.style.display = '';
            const formatted = typeof rowCount === 'number' ? rowCount.toLocaleString() : rowCount;
            statsText.textContent = `${formatted} rows · ${execMs}ms`;
        }
    }
    const pag = document.getElementById('result-pagination-chip');
    if (pag) pag.style.display = isPaginated ? '' : 'none';
    const geo = document.getElementById('result-geo-chip');
    if (geo) geo.style.display = hasGeo ? '' : 'none';
    const mapBtn = document.getElementById('result-view-map');
    if (mapBtn) mapBtn.style.display = hasGeo ? '' : 'none';
    const parquet = document.getElementById('result-parquet-btn');
    if (parquet) parquet.style.display = (currentEngine === 'duckdb') ? '' : 'none';
}

// Render the bottom status bar — mirrors the mockup:
//   "1 selected of 47          Page 1 of 1 · streamed   « ‹ › »"
function _updateStatusBar(opts) {
    const sel = document.getElementById('status-selected');
    const pagerInfo = document.getElementById('status-pager-info');
    const stream = document.getElementById('status-stream');
    const first = document.getElementById('pager-first');
    const prev = document.getElementById('pager-prev');
    const next = document.getElementById('pager-next');
    const last = document.getElementById('pager-last');

    const total = opts.total || 0;
    if (sel) sel.textContent = `${selectedRows.size} selected of ${total.toLocaleString()}`;
    if (pagerInfo) pagerInfo.textContent = `Page ${opts.page} of ${opts.totalPages || 1}`;
    if (stream) {
        const isServer = serverPagination && currentResults?.total_count !== undefined;
        stream.textContent = isServer ? 'streamed via server pagination' : 'in-memory result';
    }
    if (first) first.disabled = opts.page <= 1;
    if (prev) prev.disabled = opts.page <= 1;
    if (next) next.disabled = opts.page >= (opts.totalPages || 1);
    if (last) last.disabled = opts.page >= (opts.totalPages || 1);
}

// Update the connection chip + the right-side meta in the tabs row
function _updateConnMeta() {
    const meta = document.getElementById('active-conn-meta');
    const chip = document.getElementById('conn-chip');
    const chipLabel = document.getElementById('conn-chip-label');
    if (!currentConnection) {
        if (meta) meta.innerHTML = '<span class="dot gray"></span><span>No connection</span>';
        if (chip) chip.style.display = 'none';
        return;
    }
    const typeLabel = {postgres: 'PostgreSQL', sqlite: 'SQLite', duckdb: 'DuckDB'}[currentConnection.type] || currentConnection.type;
    if (meta) {
        meta.innerHTML = `<span class="dot green"></span><span>${tuskEscapeHtml(currentConnection.name)}</span><span class="conn-meta-sep">·</span><span>${tuskEscapeHtml(typeLabel)}</span>`;
    }
    if (chip && chipLabel) {
        chip.style.display = '';
        chipLabel.textContent = `${typeLabel} · ${currentConnection.name}`;
    }
}

// Approximate memory usage for the rows currently in the page (UI hint)
function _estimateBytes(rows) {
    if (!rows || !rows.length) return 0;
    let total = 0;
    for (const row of rows) {
        for (const c of row) {
            if (c === null || c === undefined) continue;
            if (typeof c === 'string') total += c.length * 2;
            else if (typeof c === 'number') total += 8;
            else if (typeof c === 'boolean') total += 4;
            else total += JSON.stringify(c).length * 2;
        }
    }
    return total;
}

// Render results table — v0.4 round 2 .dtable markup
function renderResults() {
    const headerEl = document.getElementById('results-header');
    const tableEl = document.getElementById('results-table');

    if (!currentResults) {
        if (headerEl) headerEl.innerHTML = '';
        if (tableEl) tableEl.innerHTML = '<div class="results-empty"><div class="ico"><i data-lucide="table"></i></div>Run a query to see results.</div>';
        _updateResultChips(null, 0, false, false);
        _updateStatusBar({page: 1, totalPages: 1, cols: 0, bytes: 0});
        if (window.lucide) lucide.createIcons();
        return;
    }

    if (currentResults.error) {
        if (headerEl) headerEl.innerHTML = '';
        if (tableEl) tableEl.innerHTML = `<div class="inline-error results-error"><i data-lucide="alert-circle"></i><pre>${tuskEscapeHtml(currentResults.error)}</pre></div>`;
        _updateResultChips(null, 0, false, false);
        _updateStatusBar({page: 1, totalPages: 1, cols: 0, bytes: 0});
        if (window.lucide) lucide.createIcons();
        return;
    }

    if (!currentResults.columns || currentResults.columns.length === 0) {
        if (headerEl) headerEl.innerHTML = '';
        if (tableEl) tableEl.innerHTML = `<div class="results-empty"><div class="ico"><i data-lucide="check"></i></div>Query executed successfully (no results) · ${currentResults.execution_time_ms || 0}ms</div>`;
        _updateResultChips(currentResults.row_count || 0, currentResults.execution_time_ms || 0, false, false);
        _updateStatusBar({page: 1, totalPages: 1, cols: 0, bytes: 0});
        if (window.lucide) lucide.createIcons();
        return;
    }

    // Pagination mode
    const isServerPaginated = serverPagination && currentResults.total_count !== undefined;
    const totalCount = isServerPaginated ? currentResults.total_count : currentResults.row_count;

    let processedRows, totalFiltered, totalPages, startIdx, endIdx, pageRows;
    if (isServerPaginated) {
        processedRows = currentResults.rows || [];
        totalFiltered = totalCount;
        totalPages = Math.ceil(totalCount / PAGE_SIZE);
        startIdx = (currentPage - 1) * PAGE_SIZE;
        endIdx = Math.min(startIdx + currentResults.row_count, totalCount);
        pageRows = processedRows;
    } else {
        processedRows = getProcessedRows();
        totalFiltered = processedRows.length;
        totalPages = Math.ceil(totalFiltered / PAGE_SIZE);
        startIdx = (currentPage - 1) * PAGE_SIZE;
        endIdx = Math.min(startIdx + PAGE_SIZE, totalFiltered);
        pageRows = processedRows.slice(startIdx, endIdx);
    }

    // Pre-compute type categories per column + unique counts (cheap on
    // a single page; skip when the page is huge to keep render fast).
    const categories = currentResults.columns.map(c => _typeCategory(c.type));
    const uniqueCounts = (pageRows.length <= 500)
        ? currentResults.columns.map((_, j) => {
            const set = new Set();
            for (const r of pageRows) {
                const v = r[j];
                set.add(v === null || v === undefined ? '\x00' : (typeof v === 'object' ? JSON.stringify(v) : String(v)));
            }
            return set.size;
        })
        : currentResults.columns.map(() => null);

    // Header chips above the table
    _updateResultChips(totalCount, currentResults.execution_time_ms || 0, isServerPaginated, hasGeoColumn());

    // Optional secondary header text (filtered count + filter input)
    if (headerEl) {
        const filterRow = !isServerPaginated ? `
            <input type="text"
                   id="results-filter"
                   class="results-header-filter"
                   placeholder="Filter visible rows…"
                   value="${tuskEscapeHtml(filterText || '')}"
                   onkeyup="filterResults(this.value)">
        ` : '';
        const filteredHint = (!isServerPaginated && filterText)
            ? `<span class="results-header-filtered">${totalFiltered.toLocaleString()} filtered</span>`
            : '';
        headerEl.innerHTML = `
            <div class="results-header-row">
                <div class="results-header-stats">
                    <span>${(totalCount || 0).toLocaleString()} rows</span>
                    <span class="sep">·</span>
                    <span>${currentResults.execution_time_ms || 0}ms</span>
                    ${filteredHint ? '<span class="sep">·</span>' + filteredHint : ''}
                </div>
                ${filterRow}
            </div>
        `;
    }

    // Per-column filter row (client-side mode only)
    const colFilterRow = isServerPaginated ? '' : `
        <tr class="col-filter-row">
            <th class="sticky-check"></th>
            ${currentResults.columns.map((c, i) => `
                <th>
                    <input type="text"
                           value="${tuskEscapeHtml(columnFilters[i] || '')}"
                           oninput="setColumnFilter(${i}, this.value)"
                           placeholder="filter…">
                </th>
            `).join('')}
        </tr>`;

    tableEl.innerHTML = `
        <table class="dtable">
            <thead>
                <tr>
                    <th class="sticky-check">
                        <input type="checkbox"
                               ${_allRowsSelected(pageRows) ? 'checked' : ''}
                               onchange="toggleAllRows(this.checked)"
                               title="Select all rows on this page">
                    </th>
                    ${currentResults.columns.map((c, i) => {
                        const cat = categories[i];
                        const u = uniqueCounts[i];
                        const uniqueLabel = (u !== null && pageRows.length > 0)
                            ? `· ${u} unique`
                            : '';
                        return `
                        <th onclick="sortByColumn(${i})" title="${tuskEscapeHtml(c.name)} · ${tuskEscapeHtml(c.type || '')}">
                            <div class="col-head">
                                <span class="col-name">${tuskEscapeHtml(c.name)}</span>
                                ${sortColumn === i ? `<span class="sort-arrow">${sortDirection === 'asc' ? '↑' : '↓'}</span>` : ''}
                            </div>
                            <div class="col-stat">
                                <span class="type-chip ${cat}">${tuskEscapeHtml(_typeShort(c.type))}</span>
                                ${uniqueLabel ? `<span class="col-unique">${tuskEscapeHtml(uniqueLabel)}</span>` : ''}
                            </div>
                        </th>`;
                    }).join('')}
                </tr>
                ${colFilterRow}
            </thead>
            <tbody>
                ${pageRows.map((row, i) => {
                    const rowKey = _rowKey(row);
                    const checked = selectedRows.has(rowKey);
                    return `
                    <tr ${checked ? 'class="sel"' : ''}
                        data-row-index="${i}"
                        data-row-key="${escapeHtml(rowKey)}"
                        onclick="openRowDetail(${i}, event)">
                        <td class="sticky-check" onclick="event.stopPropagation()">
                            <input type="checkbox" ${checked ? 'checked' : ''} onclick="toggleRow(this.closest('tr').dataset.rowKey, event)">
                        </td>
                        ${row.map((cell, j) => {
                            const cls = _cellClass(cell, categories[j]);
                            return `<td class="${cls}" title="${_titleSafe(cell)}">${formatCell(cell)}</td>`;
                        }).join('')}
                    </tr>`;
                }).join('')}
            </tbody>
        </table>
    `;

    _updateStatusBar({
        page: currentPage,
        totalPages: totalPages,
        cols: currentResults.columns.length,
        total: totalCount,
        bytes: _estimateBytes(pageRows),
    });

    if (window.lucide) lucide.createIcons();
}

// Total page count (for the v0.4 status-bar pager)
window.getTotalPages = function() {
    if (!currentResults) return 1;
    const isServerPaginated = serverPagination && currentResults.total_count !== undefined;
    if (isServerPaginated) {
        return Math.max(1, Math.ceil((currentResults.total_count || 0) / PAGE_SIZE));
    }
    const rows = getProcessedRows();
    return Math.max(1, Math.ceil(rows.length / PAGE_SIZE));
};

function _rowKey(row) {
    return row.map(c => c === null ? '\x00' : typeof c === 'object' ? JSON.stringify(c) : String(c)).join('\x1f');
}

function _titleSafe(value) {
    if (value === null || value === undefined) return '';
    const s = typeof value === 'object' ? JSON.stringify(value) : String(value);
    return s.replace(/"/g, '&quot;').slice(0, 500);
}

function _allRowsSelected(rows) {
    return rows.length > 0 && rows.every(r => selectedRows.has(_rowKey(r)));
}

window.setColumnFilter = function(colIndex, value) {
    if (value) columnFilters[colIndex] = value;
    else delete columnFilters[colIndex];
    currentPage = 1;
    renderResults();
}

window.toggleRow = function(rowKey, ev) {
    if (ev) ev.stopPropagation();
    if (selectedRows.has(rowKey)) selectedRows.delete(rowKey);
    else selectedRows.add(rowKey);
    renderResults();
}

// Heuristic: extract single source table from a SELECT query so the
// row-detail drawer can offer Edit / Copy-as-INSERT against the right
// target. Returns null for joins, subqueries, or anything we can't
// confidently parse.
function _detectSourceTable(sql) {
    if (!sql) return null;
    const stripped = sql.replace(/--.*$/gm, '').replace(/\s+/g, ' ').trim();
    if (!/^SELECT\b/i.test(stripped)) return null;
    if (/\bJOIN\b/i.test(stripped)) return null;
    if (/\bUNION\b/i.test(stripped)) return null;
    const m = stripped.match(/\bFROM\s+([a-zA-Z_][\w\.]*|"[^"]+"(\.[^"\s]+)?)/i);
    if (!m) return null;
    const candidate = m[1];
    // Skip subqueries: FROM (SELECT...) AS x
    if (candidate.startsWith('(')) return null;
    return candidate;
}

window.openRowDetail = function(pageRowIndex, ev) {
    if (ev && ev.target) {
        // Don't open the drawer when clicking the row's checkbox (that has
        // its own onclick that already stops propagation, but be defensive).
        const tag = ev.target.tagName;
        if (tag === 'INPUT' || tag === 'BUTTON' || tag === 'A') return;
    }
    // If the user is selecting text inside the cell (drag-select),
    // don't hijack the click into a drawer open.
    const sel = window.getSelection && window.getSelection();
    if (sel && sel.toString && sel.toString().length > 0) return;
    if (!currentResults || !currentResults.columns || !currentResults.rows) return;

    const rows = serverPagination ? currentResults.rows : getProcessedRows()
        .slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);
    const row = rows[pageRowIndex];
    if (!row) return;

    const totalRows = serverPagination
        ? (currentResults.total_count || rows.length)
        : currentResults.row_count;
    const absoluteIndex = serverPagination
        ? ((currentPage - 1) * PAGE_SIZE) + pageRowIndex
        : ((currentPage - 1) * PAGE_SIZE) + pageRowIndex;

    const sql = (tabs.find(t => t.id === activeTabId) || {}).sql || currentSql;

    // Visual highlight
    document.querySelectorAll('#results-table tr.row-active').forEach(el => el.classList.remove('row-active'));
    const tr = document.querySelector(`#results-table tbody tr[data-row-index="${pageRowIndex}"]`);
    if (tr) tr.classList.add('row-active');

    if (window.tuskRowDetail) {
        tuskRowDetail.open({
            columns: currentResults.columns.map(c => c.name),
            row: row,
            rowIndex: absoluteIndex,
            totalRows: totalRows,
            table: _detectSourceTable(sql),
        });
    }
}

window.toggleAllRows = function(checked) {
    const rows = getProcessedRows().slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);
    for (const r of rows) {
        const key = _rowKey(r);
        if (checked) selectedRows.add(key); else selectedRows.delete(key);
    }
    renderResults();
}

function _sqlLiteral(v) {
    if (v === null || v === undefined) return 'NULL';
    if (v === true) return 'TRUE';
    if (v === false) return 'FALSE';
    if (typeof v === 'number') return String(v);
    if (typeof v === 'object') return "'" + JSON.stringify(v).replace(/'/g, "''") + "'";
    return "'" + String(v).replace(/'/g, "''") + "'";
}

window.copyAsInsert = async function() {
    if (!currentResults || !currentResults.columns) return;
    const all = getProcessedRows();
    let rows;
    if (selectedRows.size > 0) {
        rows = all.filter(r => selectedRows.has(_rowKey(r)));
    } else {
        rows = all.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);
    }
    if (!rows.length) {
        tuskToast('No rows to copy', 'warning');
        return;
    }
    const table = 'target_table';  // user edits after paste
    const cols = currentResults.columns.map(c => `"${c.name}"`).join(', ');
    const stmts = rows.map(r => `INSERT INTO ${table} (${cols}) VALUES (${r.map(_sqlLiteral).join(', ')});`);
    const text = stmts.join('\n');
    try {
        await navigator.clipboard.writeText(text);
        tuskToast(`Copied ${stmts.length} INSERT statement${stmts.length === 1 ? '' : 's'} to clipboard`, 'success');
    } catch (err) {
        tuskToast('Could not access clipboard', 'error');
    }
}

// Sort by column
window.sortByColumn = function(colIndex) {
    if (sortColumn === colIndex) {
        sortDirection = sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
        sortColumn = colIndex;
        sortDirection = 'asc';
    }
    currentPage = 1;
    renderResults();
}

// Filter results
window.filterResults = function(text) {
    filterText = text;
    currentPage = 1;
    renderResults();
}

// Go to page
window.goToPage = function(page) {
    // Server-side pagination: re-fetch from server
    if (serverPagination && currentConnection?.type === 'postgres') {
        const totalCount = currentResults?.total_count || 0;
        const totalPages = Math.ceil(totalCount / PAGE_SIZE);
        if (page >= 1 && page <= totalPages) {
            window.currentPage = page;
            runQuery({ sql: currentSql, page: page, isPageFetch: true });
        }
        return;
    }

    // Client-side pagination
    const processedRows = getProcessedRows();
    const totalPages = Math.ceil(processedRows.length / PAGE_SIZE);
    if (page >= 1 && page <= totalPages) {
        currentPage = page;
        window.currentPage = page;
        renderResults();
    }
}

function _resultsToCSV(rows, columns, includeHeader = true) {
    const headers = columns.map(c => c.name);
    const escape = (cell) => {
        if (cell === null || cell === undefined) return '';
        const str = String(cell);
        if (str.includes(',') || str.includes('"') || str.includes('\n')) {
            return `"${str.replace(/"/g, '""')}"`;
        }
        return str;
    };
    const lines = rows.map(row => row.map(escape).join(','));
    return (includeHeader ? [headers.join(','), ...lines] : lines).join('\n');
}

// Copy results as CSV to clipboard. Honors selection (selected rows
// only) when at least one is selected, otherwise the current page.
window.copyAsCSV = async function() {
    if (!currentResults || !currentResults.columns) return;
    const all = getProcessedRows();
    let rows;
    if (selectedRows.size > 0) {
        rows = all.filter(r => selectedRows.has(_rowKey(r)));
    } else {
        rows = all.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);
    }
    if (!rows.length) {
        tuskToast('No rows to copy', 'warning');
        return;
    }
    try {
        await navigator.clipboard.writeText(_resultsToCSV(rows, currentResults.columns));
        tuskToast(`Copied ${rows.length} row${rows.length === 1 ? '' : 's'} as CSV`, 'success');
    } catch (err) {
        tuskToast('Could not access clipboard', 'error');
    }
};

// Export to CSV
window.exportCSV = function() {
    if (!currentResults || !currentResults.columns) return;

    const rows = getProcessedRows();
    const headers = currentResults.columns.map(c => c.name);

    const csvContent = [
        headers.join(','),
        ...rows.map(row =>
            row.map(cell => {
                if (cell === null) return '';
                const str = String(cell);
                if (str.includes(',') || str.includes('"') || str.includes('\n')) {
                    return `"${str.replace(/"/g, '""')}"`;
                }
                return str;
            }).join(',')
        )
    ].join('\n');

    downloadFile(csvContent, 'query_results.csv', 'text/csv');
}

// Export to JSON
window.exportJSON = function() {
    if (!currentResults || !currentResults.columns) return;

    const rows = getProcessedRows();
    const headers = currentResults.columns.map(c => c.name);

    const jsonData = rows.map(row => {
        const obj = {};
        headers.forEach((h, i) => obj[h] = row[i]);
        return obj;
    });

    downloadFile(JSON.stringify(jsonData, null, 2), 'query_results.json', 'application/json');
}

// Download file helper
function downloadFile(content, filename, mimeType) {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

// Initialize CodeMirror editor
function initEditor(schema = {}, connType = 'postgres') {
    const sqlDialect = connType === 'sqlite' ? SQLite : PostgreSQL;

    // Build schema for autocomplete: { tableName: [columns] }
    const schemaForAutocomplete = {};
    // Also build a flat list of all completions
    const allCompletions = [];
    const seenColumns = new Set();
    const seenSchemas = new Set();

    for (const [schemaName, tables] of Object.entries(schema)) {
        // Add schema name to completions (for "public." etc)
        if (!seenSchemas.has(schemaName)) {
            seenSchemas.add(schemaName);
            allCompletions.push({
                label: schemaName,
                type: "namespace",
                detail: `schema (${Object.keys(tables).length} tables)`
            });
        }

        for (const [tableName, columns] of Object.entries(tables)) {
            schemaForAutocomplete[tableName] = columns.map(c => c.name);
            // Also add schema-qualified version
            schemaForAutocomplete[`${schemaName}.${tableName}`] = columns.map(c => c.name);

            // Add table to completions (simple name)
            allCompletions.push({
                label: tableName,
                type: "class",
                detail: `${schemaName} (${columns.length} cols)`
            });

            // Add schema-qualified table name (public.users)
            allCompletions.push({
                label: `${schemaName}.${tableName}`,
                type: "class",
                detail: `table (${columns.length} cols)`
            });

            // Add columns to completions (deduplicated)
            for (const col of columns) {
                if (!seenColumns.has(col.name)) {
                    seenColumns.add(col.name);
                    allCompletions.push({
                        label: col.name,
                        type: "property",
                        detail: `${col.type} (${tableName})`
                    });
                }
            }
        }
    }

    // Custom completer that provides tables and columns globally
    const schemaCompleter = completeFromList(allCompletions);

    // Get the active tab's SQL or default
    const activeTab = tabs.find(t => t.id === activeTabId);
    const initialDoc = activeTab ? activeTab.sql : (editor ? editor.state.doc.toString() : "SELECT * FROM ");

    const state = EditorState.create({
        doc: initialDoc,
        extensions: [
            lineNumbers(),
            highlightActiveLine(),
            drawSelection({cursorBlinkRate: 1000}),
            history(),
            bracketMatching(),
            closeBrackets(),
            highlightSelectionMatches(),
            syntaxHighlighting(defaultHighlightStyle),
            keymap.of([
                ...closeBracketsKeymap,
                ...defaultKeymap,
                ...historyKeymap,
                ...searchKeymap,
                ...completionKeymap,
                indentWithTab,
                { key: "Ctrl-Enter", run: () => { runQuery(); return true; } },
                { key: "Cmd-Enter", run: () => { runQuery(); return true; } },
                { key: "Ctrl-/", run: toggleLineComment },
                { key: "Cmd-/", run: toggleLineComment },
                // Multi-cursor: select next occurrence of word under cursor.
                { key: "Ctrl-d", run: selectNextOccurrence },
                { key: "Cmd-d", run: selectNextOccurrence },
                // Cmd-S / Ctrl-S — open Save Query modal. The
                // document-level handler at the bottom of this file
                // covers the case where the editor isn't focused, but
                // when CodeMirror has focus it captures keydown first
                // and the browser's native Save dialog wins. Binding
                // here as well makes Save behave the same regardless
                // of where the cursor is (B5 in 0.4.25).
                { key: "Mod-s", run: () => { showSaveQueryModal(); return true; }, preventDefault: true },
            ]),
            queryErrorField,
            queryErrorTheme,
            sql({
                dialect: sqlDialect,
                schema: schemaForAutocomplete,
                upperCaseKeywords: true,
            }),
            autocompletion({
                override: [schemaCompleter]
            }),
            // Apply oneDark only when body is in dark mode. The light theme
            // is handled via CSS overrides in studio-redesign.css.
            ...(document.body.getAttribute('data-theme') === 'dark' ? [oneDark] : []),
            EditorView.theme({
                "&": { height: "100%" },
                ".cm-scroller": { overflow: "auto" }
            }),
            EditorView.updateListener.of(u => {
                if (u.docChanged) markActiveTabDirty();
            }),
        ]
    });

    const editorEl = document.getElementById('sql-editor');
    editorEl.innerHTML = '';

    editor = new EditorView({
        state,
        parent: editorEl
    });
    window.editor = editor;
}

// Initialize with empty schema
initEditor();
_updateConnMeta();

// Try to restore tabs from localStorage, or create initial tab
if (!loadTabsFromLocalStorage() || tabs.length === 0) {
    createTab();
} else {
    // Restore tabs and switch to the active one
    renderTabs();
    if (activeTabId) {
        const tab = tabs.find(t => t.id === activeTabId);
        if (tab && editor) {
            editor.dispatch({
                changes: { from: 0, to: editor.state.doc.length, insert: tab.sql }
            });
        }
    }
}

// Toggle connection fields
window.toggleConnFields = function() {
    const type = document.querySelector('input[name="type"]:checked').value;
    document.getElementById('postgres-fields').classList.toggle('hidden', type !== 'postgres');

    const isFileDb = type === 'sqlite' || type === 'duckdb';
    document.getElementById('file-db-fields').classList.toggle('hidden', !isFileDb);

    // Update placeholder and hint based on type
    const pathInput = document.getElementById('conn-path');
    const pathHint = document.getElementById('path-hint');
    if (type === 'sqlite') {
        pathInput.placeholder = '~/data/app.db';
        pathHint.textContent = 'Full path to your SQLite database file';
    } else if (type === 'duckdb') {
        pathInput.placeholder = '~/data/analytics.duckdb';
        pathHint.textContent = 'Full path to your DuckDB database file';
    }
}

// Load connections and history on start
loadConnections().then(() => {
    // Auto-select last used connection
    try {
        const lastConn = localStorage.getItem('tusk_last_connection');
        if (lastConn && !currentConnection) {
            const conn = JSON.parse(lastConn);
            // Verify connection still exists by checking the list (data-conn-id
            // attribute, set in the connections render).
            const connEl = document.querySelector(
                `[data-conn-id="${(window.CSS && CSS.escape) ? CSS.escape(conn.id) : conn.id}"]`
            );
            if (connEl) {
                selectConnection(conn.id, conn.name, conn.type);
            }
        }
    } catch (e) {
        console.error('Failed to restore last connection:', e);
    }
});
loadHistory();

let connectionStatuses = {};

async function loadConnections() {
    const res = await fetch('/api/connections');
    const conns = await res.json();

    const list = document.getElementById('connections-list');
    if (conns.length === 0) {
        list.innerHTML = '<div class="text-gray-500 text-sm py-2">No connections yet</div>';
        return;
    }

    list.innerHTML = conns.map(c => {
        const icon = c.type === 'duckdb' ? '🦆' : c.type === 'sqlite' ? '🗃️' : '🐘';
        const status = connectionStatuses[c.id];
        const statusColor = status === true ? 'bg-green-500'
            : status === false ? 'bg-red-500'
            : currentConnection?.id === c.id ? 'bg-green-500' : 'bg-gray-500';
        const statusTitle = status === true ? 'Online'
            : status === false ? 'Offline'
            : 'Unknown';
        const idAttr = escapeHtml(c.id);
        const nameAttr = escapeHtml(c.name);
        const typeAttr = escapeHtml(c.type);
        return `
        <div class="group flex items-center gap-2 px-2 py-1.5 rounded-lg cursor-pointer hover:bg-[#21262d] ${currentConnection?.id === c.id ? 'bg-[#21262d] ring-1 ring-indigo-500/50' : ''}"
             data-conn-id="${idAttr}" data-conn-name="${nameAttr}" data-conn-type="${typeAttr}"
             onclick="selectConnection(this.dataset.connId, this.dataset.connName, this.dataset.connType)">
            <span class="w-2 h-2 rounded-full ${statusColor}" title="${statusTitle}"></span>
            <span>${icon}</span>
            <span class="text-sm flex-1 truncate" title="${nameAttr}">${escapeHtml(c.name)}</span>
            <div class="opacity-0 group-hover:opacity-100 flex items-center gap-1">
                ${c.type === 'postgres' ? `
                    <button onclick="event.stopPropagation(); showDatabasesModal(this.closest('[data-conn-id]').dataset.connId)"
                            class="text-gray-500 hover:text-indigo-400 transition-colors text-xs" title="Browse databases">
                        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4"></path>
                        </svg>
                    </button>
                ` : ''}
                <button onclick="event.stopPropagation(); reconnectConnection(this.closest('[data-conn-id]').dataset.connId)"
                        class="text-gray-500 hover:text-amber-400 transition-colors text-xs" title="Recycle pool + SSH tunnel (use after a network blip)">
                    <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path>
                    </svg>
                </button>
                <button onclick="event.stopPropagation(); showEditConnModal(this.closest('[data-conn-id]').dataset.connId)"
                        class="text-gray-500 hover:text-blue-400 transition-colors text-xs" title="Edit connection">
                    <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"></path>
                    </svg>
                </button>
                <button onclick="event.stopPropagation(); deleteConnection(this.closest('[data-conn-id]').dataset.connId)"
                        class="text-gray-500 hover:text-red-400 transition-colors">×</button>
            </div>
        </div>
    `}).join('');

    // Check connection statuses in background
    checkConnectionStatuses(conns);
}

async function checkConnectionStatuses(conns) {
    for (const c of conns) {
        try {
            const res = await fetch(`/api/connections/${c.id}/status`);
            const data = await res.json();
            connectionStatuses[c.id] = data.online;
        } catch {
            connectionStatuses[c.id] = false;
        }
    }
    // Re-render with updated statuses
    const res = await fetch('/api/connections');
    const updatedConns = await res.json();
    const list = document.getElementById('connections-list');
    if (list && updatedConns.length > 0) {
        list.innerHTML = updatedConns.map(c => {
            const icon = c.type === 'duckdb' ? '🦆' : c.type === 'sqlite' ? '🗃️' : '🐘';
            const status = connectionStatuses[c.id];
            const statusColor = status === true ? 'bg-green-500'
                : status === false ? 'bg-red-500'
                : 'bg-gray-500';
            const statusTitle = status === true ? 'Online' : status === false ? 'Offline' : 'Unknown';
            const idAttr = escapeHtml(c.id);
            const nameAttr = escapeHtml(c.name);
            const typeAttr = escapeHtml(c.type);
            return `
            <div class="group flex items-center gap-2 px-2 py-1.5 rounded-lg cursor-pointer hover:bg-[#21262d] ${currentConnection?.id === c.id ? 'bg-[#21262d] ring-1 ring-indigo-500/50' : ''}"
                 data-conn-id="${idAttr}" data-conn-name="${nameAttr}" data-conn-type="${typeAttr}"
                 onclick="selectConnection(this.dataset.connId, this.dataset.connName, this.dataset.connType)">
                <span class="w-2 h-2 rounded-full ${statusColor}" title="${statusTitle}"></span>
                <span>${icon}</span>
                <span class="text-sm flex-1 truncate" title="${nameAttr}">${escapeHtml(c.name)}</span>
                <div class="opacity-0 group-hover:opacity-100 flex items-center gap-1">
                    ${c.type === 'postgres' ? `
                        <button onclick="event.stopPropagation(); showDatabasesModal(this.closest('[data-conn-id]').dataset.connId)"
                                class="text-gray-500 hover:text-indigo-400 transition-colors text-xs" title="Browse databases">
                            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4"></path>
                            </svg>
                        </button>
                    ` : ''}
                    <button onclick="event.stopPropagation(); showEditConnModal(this.closest('[data-conn-id]').dataset.connId)"
                            class="text-gray-500 hover:text-blue-400 transition-colors text-xs" title="Edit connection">
                        <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"></path>
                        </svg>
                    </button>
                    <button onclick="event.stopPropagation(); deleteConnection(this.closest('[data-conn-id]').dataset.connId)"
                            class="text-gray-500 hover:text-red-400 transition-colors">×</button>
                </div>
            </div>
        `}).join('');
    }
}

// Resolve a connection by id from the cached list (used when switching
// tabs auto-restores their pinned connection).
window.selectConnectionById = async function(id) {
    try {
        const res = await fetch('/api/connections');
        const conns = await res.json();
        const conn = conns.find?.(c => c.id === id);
        if (conn) selectConnection(conn.id, conn.name, conn.type);
    } catch (e) {
        console.error('selectConnectionById failed', e);
    }
};

window.selectConnection = async function(id, name, type) {
    currentConnection = { id, name, type };
    window.currentConnection = currentConnection;
    _updateConnMeta();

    // Pin the active tab to this connection so future switches stick.
    const activeTab = tabs.find(t => t.id === activeTabId);
    if (activeTab) {
        activeTab.connectionId = id;
        saveTabsToLocalStorage();
    }

    // Save last connection to localStorage
    localStorage.setItem('tusk_last_connection', JSON.stringify({ id, name, type }));

    loadConnections();

    // Load schema
    const res = await fetch(`/api/connections/${id}/schema`);
    const schema = await res.json();

    if (schema.error) {
        document.getElementById('schema-tree').innerHTML = `<div class="text-red-400 py-2">${escapeHtml(schema.error)}</div>`;
        return;
    }

    currentSchema = schema;

    // Reinitialize editor with schema for autocomplete
    initEditor(schema, type);

    // Render schema tree
    renderSchemaTree(schema);

    // Load row counts asynchronously (don't block)
    loadRowCounts();
}

// Render schema tree
let tableRowCounts = {};

function renderSchemaTree(schema, filter = '') {
    const tree = document.getElementById('schema-tree');
    const filterLower = filter.toLowerCase();

    const schemaHtml = Object.entries(schema).map(([schemaName, tables]) => {
        // Filter tables if search is active
        const filteredTables = Object.entries(tables).filter(([tableName]) =>
            !filterLower || tableName.toLowerCase().includes(filterLower)
        );

        if (filteredTables.length === 0) return '';

        const schemaNameEsc = escapeHtml(schemaName);
        return `
        <details open class="mt-1">
            <summary class="cursor-pointer text-gray-400 hover:text-white py-1">📁 ${schemaNameEsc}</summary>
            <div class="ml-3">
                ${filteredTables.map(([tableName, cols]) => {
                    const rowCount = tableRowCounts[`${schemaName}.${tableName}`];
                    const rowCountStr = rowCount !== undefined ? `<span class="text-indigo-400/70">${formatRowCount(rowCount)}</span>` : '';
                    const tableNameEsc = escapeHtml(tableName);
                    return `
                    <details class="mt-0.5"
                             data-schema="${schemaNameEsc}" data-table="${tableNameEsc}">
                        <summary class="cursor-pointer hover:text-white py-0.5 flex items-center gap-1 group"
                                 ondblclick="event.stopPropagation(); insertTable(this.closest('details').dataset.table)"
                                 title="Double-click to insert table name">
                            <span>📋</span> ${tableNameEsc}
                            <span class="text-xs text-gray-600">(${cols.length})</span>
                            ${rowCountStr}
                            <span class="ml-auto opacity-0 group-hover:opacity-100 flex items-center gap-1">
                                <button class="text-[10px] px-1 rounded bg-[#21262d] hover:bg-indigo-600 text-gray-300 hover:text-white"
                                        onclick="event.stopPropagation(); insertTableTemplate(this.closest('details').dataset.schema, this.closest('details').dataset.table)"
                                        title="Open INSERT template in a new tab">INSERT</button>
                            </span>
                        </summary>
                        <div class="ml-4 text-xs text-gray-500">
                            ${cols.map(c => {
                                const refsEsc = escapeHtml(c.references || '');
                                let icon = '<span class="text-gray-600">⋮</span>';
                                let tooltip = '';
                                if (c.is_primary_key && c.is_foreign_key) {
                                    icon = '<span class="text-yellow-500" title="Primary Key">🔑</span><span class="text-blue-400" title="FK: ' + refsEsc + '">🔗</span>';
                                } else if (c.is_primary_key) {
                                    icon = '<span class="text-yellow-500" title="Primary Key">🔑</span>';
                                } else if (c.is_foreign_key) {
                                    icon = '<span class="text-blue-400" title="FK: ' + refsEsc + '">🔗</span>';
                                    tooltip = ' → ' + escapeHtml((c.references || '').split('.').pop());
                                }
                                return `
                                <div class="py-0.5 hover:text-gray-300 cursor-pointer flex items-center gap-1"
                                     data-col-name="${escapeHtml(c.name)}"
                                     onclick="insertColumn(this.dataset.colName)"
                                     title="${refsEsc}">
                                    ${icon}
                                    ${escapeHtml(c.name)} <span class="text-gray-600">${escapeHtml(c.type)}</span>${tooltip ? '<span class="text-blue-400/60 text-[10px]">' + tooltip + '</span>' : ''}
                                </div>
                            `}).join('')}
                        </div>
                    </details>
                `}).join('')}
            </div>
        </details>
    `}).join('');

    tree.innerHTML = `
        <div class="flex items-center justify-between mb-2">
            <button onclick="refreshSchema()" class="text-xs text-gray-500 hover:text-white flex items-center gap-1" title="Refresh schema (F5)">
                <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path>
                </svg>
                Refresh
            </button>
        </div>
    ` + (schemaHtml || '<div class="text-gray-500 py-2">No tables match filter</div>');
}

function formatRowCount(count) {
    if (count >= 1000000) return `${(count / 1000000).toFixed(1)}M`;
    if (count >= 1000) return `${(count / 1000).toFixed(1)}K`;
    return count.toString();
}

window.filterSchema = function(query) {
    if (!currentSchema || Object.keys(currentSchema).length === 0) return;
    renderSchemaTree(currentSchema, query);
}

async function loadRowCounts() {
    if (!currentConnection) return;
    try {
        const res = await fetch(`/api/connections/${currentConnection.id}/row-counts`);
        const data = await res.json();
        if (data.counts) {
            tableRowCounts = data.counts;
            renderSchemaTree(currentSchema);
        }
    } catch (e) {
        console.error('Failed to load row counts:', e);
    }
}

// Refresh schema
window.refreshSchema = async function() {
    if (!currentConnection) return;

    const res = await fetch(`/api/connections/${currentConnection.id}/schema`);
    const schema = await res.json();

    if (!schema.error) {
        currentSchema = schema;
        initEditor(schema, currentConnection.type);
        renderSchemaTree(schema);
    }
}

window.insertTable = function(table) {
    if (editor) {
        const cursor = editor.state.selection.main.head;
        editor.dispatch({
            changes: { from: cursor, insert: table }
        });
        editor.focus();
    }
}

// Build an INSERT template for a table from its column metadata in the
// current schema and drop it into a fresh tab. Skips columns that are
// PK + auto-generated when we can detect that (PG SERIAL/IDENTITY look
// like names ending with `_id` + integer type — best-effort, user edits).
window.insertTableTemplate = function(schemaName, tableName) {
    const tables = currentSchema?.[schemaName];
    const cols = tables?.[tableName] || [];
    if (!cols.length) {
        tuskToast(`No column metadata for ${tableName}`, 'warning');
        return;
    }
    const ident = (s) => /^[a-z_][a-z0-9_]*$/.test(s) ? s : `"${s}"`;
    const colNames = cols.map(c => ident(c.name));
    const placeholders = cols.map(c => {
        const t = (c.type || '').toLowerCase();
        if (t.includes('int') || t.includes('numeric') || t.includes('decimal') || t.includes('real') || t.includes('double')) return '0';
        if (t.includes('bool')) return 'false';
        if (t.includes('json')) return "'{}'";
        if (t.includes('timestamp') || t.includes('date') || t.includes('time')) return 'NOW()';
        if (t.includes('uuid')) return 'gen_random_uuid()';
        return "''";
    });
    const lines = [
        `INSERT INTO ${ident(schemaName)}.${ident(tableName)} (`,
        '    ' + colNames.join(', '),
        ') VALUES (',
        '    ' + placeholders.join(', '),
        ');'
    ];
    const text = lines.join('\n');
    createTab(`Insert ${tableName}`, text);
    if (editor) editor.focus();
};

window.insertColumn = function(column) {
    if (editor) {
        const cursor = editor.state.selection.main.head;
        editor.dispatch({
            changes: { from: cursor, insert: column }
        });
        editor.focus();
    }
}

window.deleteConnection = async function(id) {
    if (!await tuskConfirm('Delete this connection?')) return;
    await fetch(`/api/connections/${id}`, { method: 'DELETE' });
    if (currentConnection?.id === id) {
        currentConnection = null;
        document.getElementById('schema-tree').innerHTML = '<div class="text-gray-500 py-2">Select a connection</div>';
    }
    loadConnections();
}

// Query execution state
let isRunning = false;
let currentRequestId = null;

function newRequestId() {
    if (crypto && crypto.randomUUID) return crypto.randomUUID().replace(/-/g, '');
    return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

window.runQuery = async function(options = {}) {
    if (!currentConnection) {
        tuskToast('Select a connection first', 'warning');
        return;
    }

    if (isRunning) return;

    const sqlText = options.sql || editor.state.doc.toString();
    const page = options.page || 1;
    const isPageFetch = options.isPageFetch || false;

    isRunning = true;
    queryAbortController = new AbortController();
    currentRequestId = newRequestId();

    // Update Run button to show Cancel
    const runBtn = document.getElementById('run-btn');
    runBtn.disabled = false;
    runBtn.onclick = cancelQuery;
    runBtn.innerHTML = `
        <svg class="w-4 h-4 animate-spin" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path>
        </svg>
        Cancel
    `;
    runBtn.classList.remove('bg-green-600', 'hover:bg-green-700');
    runBtn.classList.add('bg-red-600', 'hover:bg-red-700');

    document.getElementById('results-header').innerHTML = `
        <span class="text-gray-400 flex items-center gap-2">
            <svg class="w-4 h-4 animate-spin" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <circle cx="12" cy="12" r="10" stroke-opacity="0.25" stroke-width="4"></circle>
                <path d="M12 2a10 10 0 0110 10" stroke-width="4"></path>
            </svg>
            ${isPageFetch ? 'Loading page...' : 'Running query...'} <span class="text-gray-500">(press Escape or click Cancel to stop)</span>
        </span>
    `;
    if (!isPageFetch) {
        document.getElementById('results-table').innerHTML = '';
    }
    clearQueryErrorHighlight();

    try {
        // Server-side pagination works for every engine now (postgres, duckdb, sqlite)
        const body = {
            connection_id: currentConnection.id,
            sql: sqlText,
            request_id: currentRequestId,
            page: page,
            page_size: PAGE_SIZE,
        };

        const res = await fetch('/api/query', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body),
            signal: queryAbortController.signal
        });

        currentResults = await res.json();
        window.currentResults = currentResults;

        // Check if we're in server-side pagination mode
        serverPagination = currentResults.total_count !== undefined;
        currentSql = sqlText;
        window.currentSql = sqlText;
        currentPage = page;
        window.currentPage = page;

        // Reset sort/filter for new queries (not page fetches)
        if (!isPageFetch) {
            sortColumn = null;
            sortDirection = 'asc';
            filterText = '';
            mapGeoData = null;  // Clear cached map data
        }

        // Store results in active tab
        const activeTab = tabs.find(t => t.id === activeTabId);
        if (activeTab) {
            activeTab.sql = sqlText;
            activeTab.results = currentResults;
            activeTab.serverPagination = serverPagination;
        }

        if (currentResults && currentResults.error && currentResults.error_position) {
            highlightQueryError(currentResults.error_position);
        }

        // Snap back to the Table view whenever a brand-new query runs.
        // Page fetches keep whatever pane the user was on (table is the
        // only pane that re-renders during pagination anyway).
        if (!isPageFetch && typeof window.setResultView === 'function') {
            window.setResultView('table');
        }

        renderResults();
    } catch (err) {
        if (err.name === 'AbortError') {
            currentResults = { error: 'Query cancelled by user' };
        } else {
            currentResults = { error: err.message };
        }
        renderResults();
    } finally {
        isRunning = false;
        queryAbortController = null;
        currentRequestId = null;
        resetRunButton();

        // Refresh history after query execution (but not for page fetches)
        if (!isPageFetch) {
            loadHistory();
        }
    }
}

window.cancelQuery = function() {
    const reqId = currentRequestId;
    if (queryAbortController) {
        queryAbortController.abort();
    }
    if (reqId) {
        fetch('/api/query/cancel', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ request_id: reqId }),
        }).catch(() => {});
    }
}

function resetRunButton() {
    const runBtn = document.getElementById('run-btn');
    runBtn.disabled = false;
    runBtn.onclick = runQuery;
    runBtn.innerHTML = '<span>▶</span> Run';
    runBtn.classList.remove('bg-red-600', 'hover:bg-red-700');
    runBtn.classList.add('bg-green-600', 'hover:bg-green-700');
}

// Drop the cached pool + SSH tunnel for a connection and re-test.
// The recycle button on each connection row calls this — useful when
// the network blipped and Tusk is still holding stale handles to a
// server that's actually back online.
window.reconnectConnection = async function(connId) {
    if (!connId) return;
    try {
        tuskToast('Recycling connection…', 'info');
        const res = await tuskFetchJSON(`/api/connections/${connId}/reconnect`, { method: 'POST' });
        if (res.success) {
            tuskToast('Reconnected: ' + (res.message || 'OK'), 'success');
            // Refresh status indicator on the sidebar.
            connectionStatuses[connId] = true;
            await loadConnections();
            // If this is the active connection, refresh its schema too.
            if (currentConnection?.id === connId && typeof loadSchema === 'function') {
                try { await loadSchema(connId); } catch (_) {}
            }
        } else {
            tuskToast('Reconnect failed: ' + (res.error || res.message || 'unknown'), 'error');
        }
    } catch (e) {
        tuskToast('Reconnect failed: ' + e.message, 'error');
    }
};

// Test connection
window.testConnection = async function() {
    const form = document.getElementById('conn-form');
    const formData = new FormData(form);
    const data = Object.fromEntries(formData);

    const editId = document.getElementById('conn-edit-id').value;
    const btn = document.getElementById('test-conn-btn');
    const originalText = btn.innerHTML;

    btn.disabled = true;
    btn.innerHTML = 'Testing...';

    try {
        let res;
        if (editId) {
            // Test existing connection
            res = await fetch(`/api/connections/${editId}/test`, { method: 'POST' });
        } else {
            // Create temp connection and test
            res = await fetch('/api/connections/test', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
        }

        const result = await res.json();

        if (result.success) {
            btn.innerHTML = '✓ Connected!';
            btn.classList.remove('bg-[#21262d]');
            btn.classList.add('bg-green-600');
            setTimeout(() => {
                btn.innerHTML = originalText;
                btn.classList.remove('bg-green-600');
                btn.classList.add('bg-[#21262d]');
            }, 2000);
        } else {
            btn.innerHTML = '✗ Failed';
            btn.classList.remove('bg-[#21262d]');
            btn.classList.add('bg-red-600');
            tuskToast('Connection failed: ' + result.message, 'error');
            setTimeout(() => {
                btn.innerHTML = originalText;
                btn.classList.remove('bg-red-600');
                btn.classList.add('bg-[#21262d]');
            }, 2000);
        }
    } catch (err) {
        tuskToast('Test failed: ' + err.message, 'error');
        btn.innerHTML = originalText;
    } finally {
        btn.disabled = false;
    }
}

window.showConnModal = function(editMode = false) {
    // Reset form to add mode
    document.getElementById('conn-modal-title').textContent = 'Add Connection';
    document.getElementById('conn-edit-id').value = '';
    document.getElementById('conn-submit-btn').textContent = 'Connect';
    document.getElementById('password-hint').classList.add('hidden');
    document.getElementById('conn-type-selector').classList.remove('hidden');

    // Reset form fields
    if (!editMode) {
        document.getElementById('conn-form').reset();
        document.getElementById('conn-host').value = 'localhost';
        document.getElementById('conn-port').value = '5432';
        toggleConnFields();
    }

    window.dispatchEvent(new Event('open-conn-modal'));
    document.getElementById('conn-name').focus();
}

window.showEditConnModal = async function(connId) {
    // Fetch connection details
    const res = await fetch(`/api/connections/${connId}`);
    const conn = await res.json();

    if (conn.error) {
        tuskToast('Could not load connection: ' + conn.error, 'error');
        return;
    }

    // Set form to edit mode
    document.getElementById('conn-modal-title').textContent = 'Edit Connection';
    document.getElementById('conn-edit-id').value = connId;
    document.getElementById('conn-submit-btn').textContent = 'Save Changes';
    document.getElementById('password-hint').classList.remove('hidden');

    // Hide type selector in edit mode (can't change type)
    document.getElementById('conn-type-selector').classList.add('hidden');

    // Fill form fields
    document.getElementById('conn-name').value = conn.name || '';

    // Set type radio (hidden but needed for form)
    document.querySelector(`input[name="type"][value="${conn.type}"]`).checked = true;
    toggleConnFields();

    if (conn.type === 'postgres') {
        document.getElementById('conn-host').value = conn.host || '';
        document.getElementById('conn-port').value = conn.port || 5432;
        document.getElementById('conn-database').value = conn.database || '';
        document.getElementById('conn-user').value = conn.user || '';
        document.getElementById('conn-password').value = ''; // Don't show password
        // SSH tunnel fields. The API never returns ssh_password / ssh_private_key
        // (include_secrets=False) — leave them blank so partial edits don't wipe them.
        const sshHost = document.getElementById('conn-ssh-host');
        const sshPort = document.getElementById('conn-ssh-port');
        const sshUser = document.getElementById('conn-ssh-user');
        const sshKey  = document.getElementById('conn-ssh-key');
        const sshPwd  = document.getElementById('conn-ssh-password');
        if (sshHost) sshHost.value = conn.ssh_host || '';
        if (sshPort) sshPort.value = conn.ssh_port || 22;
        if (sshUser) sshUser.value = conn.ssh_user || '';
        if (sshKey)  sshKey.value  = '';
        if (sshPwd)  sshPwd.value  = '';
    } else if (conn.type === 'sqlite' || conn.type === 'duckdb') {
        document.getElementById('conn-path').value = conn.path || '';
    }

    window.dispatchEvent(new Event('open-conn-modal'));
    document.getElementById('conn-name').focus();
}

window.hideConnModal = function() {
    window.dispatchEvent(new Event('close-conn-modal'));
    // Reset edit state
    document.getElementById('conn-edit-id').value = '';
}

// Keyboard shortcuts
document.addEventListener('keydown', (e) => {
    // Escape - cancel running query (modal closing handled by Alpine.js)
    if (e.key === 'Escape') {
        if (isRunning && queryAbortController) {
            cancelQuery();
        }
    }
    // Ctrl+T / Cmd+T - new tab
    if ((e.ctrlKey || e.metaKey) && e.key === 't') {
        e.preventDefault();
        createTab();
    }
    // Ctrl+W / Cmd+W - close current tab
    if ((e.ctrlKey || e.metaKey) && e.key === 'w') {
        e.preventDefault();
        if (activeTabId) {
            closeTab(activeTabId);
        }
    }
    // F5 - refresh schema
    if (e.key === 'F5') {
        e.preventDefault();
        refreshSchema();
    }
    // Ctrl+Tab - next tab
    if (e.ctrlKey && e.key === 'Tab') {
        e.preventDefault();
        if (tabs.length > 1) {
            const currentIndex = tabs.findIndex(t => t.id === activeTabId);
            const nextIndex = e.shiftKey
                ? (currentIndex - 1 + tabs.length) % tabs.length
                : (currentIndex + 1) % tabs.length;
            switchTab(tabs[nextIndex].id);
        }
    }
});

// Modal backdrop clicks handled by Alpine.js x-show

document.getElementById('conn-form').onsubmit = async (e) => {
    e.preventDefault();
    const form = new FormData(e.target);
    const data = Object.fromEntries(form);

    const editId = document.getElementById('conn-edit-id').value;
    const isEdit = editId && editId.length > 0;

    let res;
    if (isEdit) {
        // Update existing connection
        res = await fetch(`/api/connections/${editId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
    } else {
        // Create new connection
        res = await fetch('/api/connections', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
    }

    const result = await res.json();

    if (result.error) {
        tuskToast('Error: ' + result.error, 'error');
        return;
    }

    hideConnModal();
    loadConnections();
    e.target.reset();

    // Auto-select the connection (new or edited)
    if (result.id) {
        setTimeout(() => selectConnection(result.id, result.name, result.type), 100);
    }
};

// Settings Modal Functions
window.showSettingsModal = async function() {
    window.dispatchEvent(new Event('open-settings-modal'));
    await loadPgPaths();
}

window.hideSettingsModal = function() {
    window.dispatchEvent(new Event('close-settings-modal'));
}

async function loadPgPaths() {
    const res = await fetch('/api/settings/pg-bin-path/detect');
    const data = await res.json();

    const list = document.getElementById('pg-paths-list');
    const input = document.getElementById('pg-bin-path-input');

    if (data.current) {
        input.value = data.current;
    }

    if (data.available.length === 0) {
        list.innerHTML = '<div class="text-yellow-400 text-sm">No PostgreSQL installations detected</div>';
        return;
    }

    list.innerHTML = data.available.map(p => {
        const pathAttr = escapeHtml(p.path);
        return `
        <div class="flex items-center justify-between p-2 rounded-lg bg-[#0d1117] border border-[#30363d] ${data.current === p.path || (!data.current && data.detected.startsWith(p.path)) ? 'ring-1 ring-indigo-500' : ''}"
             data-pg-path="${pathAttr}">
            <div class="flex-1 min-w-0">
                <div class="font-mono text-sm truncate">${pathAttr}</div>
                <div class="text-xs text-gray-500">${escapeHtml(p.version)}</div>
            </div>
            <button onclick="selectPgPath(this.closest('[data-pg-path]').dataset.pgPath)" class="text-sm text-indigo-400 hover:text-indigo-300 px-2">Use</button>
        </div>
    `;
    }).join('');
}

window.selectPgPath = async function(path) {
    document.getElementById('pg-bin-path-input').value = path;
    await setPgBinPath();
}

window.setPgBinPath = async function() {
    const path = document.getElementById('pg-bin-path-input').value.trim();

    const res = await fetch('/api/settings/pg-bin-path', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ path })
    });

    const result = await res.json();

    if (result.success) {
        await loadPgPaths();
    } else {
        tuskToast(result.error, 'error');
    }
}

window.clearPgBinPath = async function() {
    document.getElementById('pg-bin-path-input').value = '';
    await setPgBinPath();
}

// History Functions
let historyData = [];

async function loadHistory() {
    const res = await fetch('/api/history?limit=50');
    const data = await res.json();
    historyData = data.history || [];
    renderHistory(historyData);
}

function renderHistory(items) {
    const list = document.getElementById('history-list');

    if (!items || items.length === 0) {
        list.innerHTML = '<div class="text-gray-500 py-1">No history yet</div>';
        return;
    }

    list.innerHTML = items.map(h => {
        // Truncate SQL for display
        const sqlPreview = h.sql.length > 35 ? h.sql.slice(0, 35) + '...' : h.sql;
        const statusIcon = h.status === 'success' ? '✓' : '✗';
        const statusColor = h.status === 'success' ? 'text-green-500' : 'text-red-500';
        const connName = h.connection_name || 'Unknown';
        const connShort = connName.length > 10 ? connName.slice(0, 10) + '..' : connName;
        const connNameEsc = escapeHtml(connName);
        const sqlFullEsc = escapeHtml(h.sql);
        const execMs = Number(h.execution_time_ms) || 0;

        return `
            <div class="group px-2 py-1.5 rounded hover:bg-[#21262d] cursor-pointer"
                 onclick="useHistoryQuery(${Number(h.id)})"
                 title="${sqlFullEsc}">
                <div class="flex items-center gap-1 text-[10px] text-gray-600 mb-0.5">
                    <span class="${statusColor}">${statusIcon}</span>
                    <span title="${connNameEsc}">${escapeHtml(connShort)}</span>
                    <span class="ml-auto">${execMs}ms</span>
                </div>
                <div class="truncate text-gray-400 font-mono text-xs">${escapeHtml(sqlPreview)}</div>
            </div>
        `;
    }).join('');
}

window.filterHistory = function(query) {
    if (!query.trim()) {
        renderHistory(historyData);
        return;
    }
    const q = query.toLowerCase();
    const filtered = historyData.filter(h =>
        h.sql.toLowerCase().includes(q) ||
        (h.connection_name || '').toLowerCase().includes(q)
    );
    renderHistory(filtered);
}

window.useHistoryQuery = async function(id) {
    // Find the query in history and set it in the editor
    const res = await fetch('/api/history?limit=100');
    const data = await res.json();

    const entry = data.history.find(h => h.id === id);
    if (entry && editor) {
        // Check if this is a DuckDB query
        if (entry.connection_id === 'duckdb-local') {
            setEngine('duckdb');
        } else if (entry.connection_id && entry.connection_id !== currentConnection?.id) {
            // Try to connect to the same database
            const connRes = await fetch('/api/connections');
            const connections = await connRes.json();
            const conn = connections.find(c => c.id === entry.connection_id);

            if (conn) {
                await selectConnection(conn.id, conn.name, conn.type);
            } else {
                // Connection no longer exists, just show a warning
                console.warn(`Connection "${entry.connection_name}" no longer exists`);
            }
        }

        // Check if current tab has real content (not empty or default)
        const currentSql = editor.state.doc.toString().trim();
        const isEmptyOrDefault = !currentSql ||
                                  currentSql === 'SELECT * FROM' ||
                                  currentSql === 'SELECT * FROM ';

        if (isEmptyOrDefault) {
            // Replace current tab content
            editor.dispatch({
                changes: { from: 0, to: editor.state.doc.length, insert: entry.sql }
            });
        } else {
            // Open in new tab
            createTab(`History ${id}`, entry.sql);
        }

        editor.focus();
    }
}

window.clearHistory = async function() {
    if (!await tuskConfirm('Clear all query history?')) return;

    await fetch('/api/history', { method: 'DELETE' });
    loadHistory();
}

// Databases Modal Functions
let currentDatabasesConnId = null;

window.showDatabasesModal = async function(connId) {
    currentDatabasesConnId = connId;
    window.dispatchEvent(new Event('open-databases-modal'));
    document.getElementById('databases-list').innerHTML = '<div class="text-gray-500">Loading databases...</div>';

    const res = await fetch(`/api/connections/${connId}/databases`);
    const data = await res.json();

    const list = document.getElementById('databases-list');

    if (data.error) {
        list.innerHTML = `<div class="text-red-400">${escapeHtml(data.error)}</div>`;
        return;
    }

    if (!data.databases || data.databases.length === 0) {
        list.innerHTML = '<div class="text-gray-500">No databases found</div>';
        return;
    }

    list.innerHTML = data.databases.map(db => {
        const dbNameEsc = escapeHtml(db.name);
        return `
        <div class="flex items-center justify-between p-3 rounded-lg hover:bg-[#21262d] ${db.is_current ? 'bg-[#21262d] ring-1 ring-green-500/50' : ''}"
             data-db-name="${dbNameEsc}">
            <div class="flex-1 min-w-0">
                <div class="flex items-center gap-2">
                    <span class="font-medium">${dbNameEsc}</span>
                    ${db.is_current ? '<span class="text-xs px-2 py-0.5 rounded-full bg-green-500/20 text-green-400">current</span>' : ''}
                </div>
                <div class="text-xs text-gray-500 mt-1">
                    ${escapeHtml(db.size_human)} · Owner: ${escapeHtml(db.owner)}
                </div>
            </div>
            ${!db.is_current ? `
                <button onclick="connectToDatabase(this.closest('[data-db-name]').dataset.dbName)"
                        class="text-indigo-400 hover:text-indigo-300 hover:bg-indigo-500/20 px-3 py-1 rounded transition-colors text-sm">
                    Connect
                </button>
            ` : ''}
        </div>
    `;
    }).join('');
}

window.hideDatabasesModal = function() {
    window.dispatchEvent(new Event('close-databases-modal'));
    currentDatabasesConnId = null;
}

window.connectToDatabase = async function(dbName) {
    if (!currentDatabasesConnId) return;

    const res = await fetch(`/api/connections/${currentDatabasesConnId}/clone`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ database: dbName })
    });

    const result = await res.json();

    if (result.error) {
        tuskToast('Error: ' + result.error, 'error');
        return;
    }

    hideDatabasesModal();
    await loadConnections();

    // Select the new or existing connection
    setTimeout(() => selectConnection(result.id, result.name, result.type), 100);
}

// Databases modal backdrop click handled by Alpine.js

// Saved Queries Functions
loadSavedQueries();

async function loadSavedQueries() {
    const res = await fetch('/api/saved-queries');
    const data = await res.json();

    const list = document.getElementById('saved-queries-list');

    if (!data.queries || data.queries.length === 0) {
        list.innerHTML = '<div class="text-gray-500 py-1">No saved queries</div>';
        return;
    }

    // Group by folder
    const folders = {};
    const noFolder = [];

    data.queries.forEach(q => {
        if (q.folder) {
            if (!folders[q.folder]) folders[q.folder] = [];
            folders[q.folder].push(q);
        } else {
            noFolder.push(q);
        }
    });

    let html = '';

    // Render queries without folder first
    noFolder.forEach(q => {
        html += renderSavedQueryItem(q);
    });

    // Render folders
    for (const [folder, queries] of Object.entries(folders)) {
        html += `
            <details class="mt-1">
                <summary class="cursor-pointer text-gray-400 hover:text-white py-1 text-xs">📁 ${escapeHtml(folder)}</summary>
                <div class="ml-2">
                    ${queries.map(q => renderSavedQueryItem(q)).join('')}
                </div>
            </details>
        `;
    }

    list.innerHTML = html;
}

function renderSavedQueryItem(q) {
    const sqlPreview = q.sql.length > 30 ? q.sql.slice(0, 30) + '...' : q.sql;
    const id = Number(q.id);
    return `
        <div class="group flex items-center gap-2 px-2 py-1 rounded hover:bg-[#21262d] cursor-pointer"
             onclick="loadSavedQuery(${id})"
             title="${escapeHtml(q.sql)}">
            <span class="text-indigo-400 text-xs">⭐</span>
            <span class="flex-1 truncate text-gray-300 text-xs">${escapeHtml(q.name)}</span>
            <button onclick="event.stopPropagation(); editSavedQuery(${id})"
                    class="opacity-0 group-hover:opacity-100 text-gray-500 hover:text-blue-400 text-xs">✎</button>
            <button onclick="event.stopPropagation(); deleteSavedQuery(${id})"
                    class="opacity-0 group-hover:opacity-100 text-gray-500 hover:text-red-400 text-xs">×</button>
        </div>
    `;
}

window.loadSavedQuery = async function(id) {
    const res = await fetch(`/api/saved-queries/${id}`);
    const query = await res.json();

    if (query.error) {
        tuskToast('Error loading query: ' + query.error, 'error');
        return;
    }

    if (editor) {
        editor.dispatch({
            changes: { from: 0, to: editor.state.doc.length, insert: query.sql }
        });
        editor.focus();
    }
}

window.showSaveQueryModal = function(editId = null) {
    const sql = editor ? editor.state.doc.toString() : '';

    if (!sql.trim()) {
        tuskToast('No query to save', 'warning');
        return;
    }

    document.getElementById('save-query-id').value = editId || '';
    document.getElementById('save-query-title').textContent = editId ? 'Edit Saved Query' : 'Save Query';
    document.getElementById('save-query-name').value = '';
    document.getElementById('save-query-folder').value = '';
    document.getElementById('save-query-preview').textContent = sql.slice(0, 200) + (sql.length > 200 ? '...' : '');

    window.dispatchEvent(new Event('open-save-query-modal'));
    document.getElementById('save-query-name').focus();
}

window.hideSaveQueryModal = function() {
    window.dispatchEvent(new Event('close-save-query-modal'));
}

window.editSavedQuery = async function(id) {
    const res = await fetch(`/api/saved-queries/${id}`);
    const query = await res.json();

    if (query.error) {
        tuskToast('Error loading query: ' + query.error, 'error');
        return;
    }

    document.getElementById('save-query-id').value = id;
    document.getElementById('save-query-title').textContent = 'Edit Saved Query';
    document.getElementById('save-query-name').value = query.name;
    document.getElementById('save-query-folder').value = query.folder || '';
    document.getElementById('save-query-preview').textContent = query.sql.slice(0, 200) + (query.sql.length > 200 ? '...' : '');

    window.dispatchEvent(new Event('open-save-query-modal'));
    document.getElementById('save-query-name').focus();
}

window.deleteSavedQuery = async function(id) {
    if (!await tuskConfirm('Delete this saved query?')) return;

    await fetch(`/api/saved-queries/${id}`, { method: 'DELETE' });
    loadSavedQueries();
}

document.getElementById('save-query-form').onsubmit = async (e) => {
    e.preventDefault();

    const id = document.getElementById('save-query-id').value;
    const name = document.getElementById('save-query-name').value.trim();
    const folder = document.getElementById('save-query-folder').value.trim();
    const sql = editor ? editor.state.doc.toString() : '';

    if (!name) {
        tuskToast('Please enter a query name', 'warning');
        return;
    }

    let res;
    if (id) {
        // Update existing
        res = await fetch(`/api/saved-queries/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, folder: folder || null, sql })
        });
    } else {
        // Create new
        res = await fetch('/api/saved-queries', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                name,
                sql,
                folder: folder || null,
                connection_id: currentConnection?.id || null
            })
        });
    }

    const result = await res.json();

    if (result.error) {
        tuskToast('Error: ' + result.error, 'error');
        return;
    }

    hideSaveQueryModal();
    loadSavedQueries();
}

// Add Ctrl+S shortcut for saving queries
document.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 's') {
        e.preventDefault();
        showSaveQueryModal();
    }
});

// Save query modal backdrop click handled by Alpine.js

// Save tabs before leaving the page
window.addEventListener('beforeunload', () => {
    saveTabsToLocalStorage();
});

// Periodically save tabs (every 5 seconds if there are changes)
setInterval(() => {
    saveTabsToLocalStorage();
}, 5000);

// ============================================================================
// Engine Selection (PostgreSQL vs DuckDB)
// ============================================================================
// `currentEngine` is declared at the top of the file (hoisted out of
// the TDZ) so functions defined earlier can reference it safely.

window.setEngine = function(engine) {
    currentEngine = engine;
    window.currentEngine = engine;

    // Update legacy button styles if those elements still exist (old layout)
    const pg = document.getElementById('engine-postgres');
    const sl = document.getElementById('engine-sqlite');
    const dd = document.getElementById('engine-duckdb');
    if (pg) pg.classList.toggle('active', engine === 'postgres');
    if (sl) sl.classList.toggle('active', engine === 'sqlite');
    if (dd) dd.classList.toggle('active', engine === 'duckdb');

    // v0.4 redesign: engine chip in editor toolbar
    const chip = document.getElementById('engine-chip-label');
    if (chip) {
        chip.textContent = {
            postgres: 'PostgreSQL',
            sqlite: 'SQLite',
            duckdb: 'DuckDB',
        }[engine] || engine;
    }

    const info = document.getElementById('engine-info');
    if (info) {
        if (engine === 'duckdb') info.textContent = '→ In-Memory (Parquet, CSV, JSON)';
        else info.textContent = currentConnection ? `→ ${currentConnection.name}` : '(select a connection)';
    }

    // Show/hide Parquet button based on engine
    const parquet = document.getElementById('result-parquet-btn');
    if (parquet) parquet.style.display = engine === 'duckdb' ? '' : 'none';
}

window.selectDuckDB = function() {
    setEngine('duckdb');

    // Update visual indicator
    document.getElementById('duckdb-status').classList.remove('bg-gray-500');
    document.getElementById('duckdb-status').classList.add('bg-green-500');

    // Deselect Postgres connections visually
    if (currentConnection) {
        loadConnections();
    }
}

// Update engine info when connection changes
const originalSelectConnection = window.selectConnection;
window.selectConnection = async function(id, name, type) {
    await originalSelectConnection(id, name, type);

    // Set engine based on connection type
    if (type === 'sqlite') {
        setEngine('sqlite');
    } else if (type === 'duckdb') {
        setEngine('duckdb');
    } else {
        setEngine('postgres');
    }

    // Reset DuckDB indicator if not using DuckDB
    if (type !== 'duckdb') {
        document.getElementById('duckdb-status').classList.remove('bg-green-500');
        document.getElementById('duckdb-status').classList.add('bg-gray-500');
    }
}

// Initialize engine display
setEngine('postgres');

// ============================================================================
// Files Management
// ============================================================================

let currentPreviewFile = null;

// Load files on start
loadFiles();

async function loadFiles() {
    const res = await fetch('/api/files/folders');
    const data = await res.json();

    const list = document.getElementById('files-list');

    if (!data.folders || data.folders.length === 0) {
        list.innerHTML = '<div class="text-gray-500 py-1">No folders added</div>';
        return;
    }

    list.innerHTML = data.folders.map(folder => {
        const folderPathEsc = escapeHtml(folder.path);
        return `
        <details open class="mt-1" data-folder-path="${folderPathEsc}">
            <summary class="cursor-pointer text-gray-400 hover:text-white py-1 text-xs flex items-center gap-1">
                <span>📁</span> ${escapeHtml(folder.name)}
                <button onclick="event.stopPropagation(); removeFolder(this.closest('details').dataset.folderPath)"
                        class="ml-auto text-gray-600 hover:text-red-400 text-xs">×</button>
            </summary>
            <div class="ml-3 mt-1 space-y-0.5">
                ${folder.files.length === 0 ? '<div class="text-gray-600 text-xs py-1">No data files</div>' : ''}
                ${folder.files.map(f => {
                    const fPathEsc = escapeHtml(f.path);
                    const fTypeEsc = escapeHtml(f.file_type);
                    const fNameEsc = escapeHtml(f.name);
                    return `
                    <div class="flex items-center gap-1.5 px-2 py-1 rounded hover:bg-[#21262d] cursor-pointer text-xs"
                         data-file-path="${fPathEsc}" data-file-type="${fTypeEsc}" data-file-name="${fNameEsc}"
                         onclick="previewFile(this.dataset.filePath, this.dataset.fileType, this.dataset.fileName)">
                        <span>${escapeHtml(f.icon)}</span>
                        <span class="flex-1 truncate text-gray-300" title="${fNameEsc}">${fNameEsc}</span>
                        <span class="text-gray-600">${escapeHtml(f.size_human)}</span>
                    </div>
                `;
                }).join('')}
            </div>
        </details>
    `;
    }).join('');
}

window.showAddFolderModal = function() {
    window.dispatchEvent(new Event('open-folder-modal'));
    document.getElementById('folder-path').focus();
}

// ============================================================================
// Create New Database File
// ============================================================================

window.showCreateFileModal = function() {
    window.dispatchEvent(new Event('open-create-file-modal'));
    document.getElementById('create-file-path').focus();
}

window.hideCreateFileModal = function() {
    window.dispatchEvent(new Event('close-create-file-modal'));
    document.getElementById('create-file-path').value = '';
}

document.getElementById('create-file-form').onsubmit = async (e) => {
    e.preventDefault();

    const fileType = document.querySelector('input[name="file_type"]:checked').value;
    const path = document.getElementById('create-file-path').value.trim();

    if (!path) return;

    try {
        const res = await fetch('/api/files/create', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ type: fileType, path })
        });

        const result = await res.json();

        if (result.success) {
            hideCreateFileModal();
            loadFiles();
            tuskToast(`Created ${fileType.toUpperCase()} database: ${result.path}`, 'success');
        } else {
            tuskToast('Error: ' + result.error, 'error');
        }
    } catch (err) {
        tuskToast('Error: ' + err.message, 'error');
    }
}

// Create file modal backdrop click handled by Alpine.js

window.hideFolderModal = function() {
    window.dispatchEvent(new Event('close-folder-modal'));
    document.getElementById('folder-path').value = '';
}

window.removeFolder = async function(path) {
    if (!await tuskConfirm('Remove this folder from the list?')) return;

    await fetch('/api/files/folders', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ path })
    });

    loadFiles();
}

document.getElementById('folder-form').onsubmit = async (e) => {
    e.preventDefault();

    const path = document.getElementById('folder-path').value.trim();
    if (!path) return;

    const res = await fetch('/api/files/folders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ path })
    });

    const result = await res.json();

    if (!result.success) {
        tuskToast('Error: ' + result.error, 'error');
        return;
    }

    hideFolderModal();
    loadFiles();
}

// Folder modal backdrop click handled by Alpine.js

// ============================================================================
// File Preview
// ============================================================================

window.previewFile = async function(path, fileType, name) {
    currentPreviewFile = { path, fileType, name };

    window.dispatchEvent(new Event('open-file-preview-modal'));
    document.getElementById('file-preview-title').textContent = name;
    document.getElementById('file-preview-info').innerHTML = 'Loading...';
    document.getElementById('file-preview-content').innerHTML = '<div class="text-gray-500">Loading preview...</div>';

    // Get file info
    const infoRes = await fetch(`/api/files/info?path=${encodeURIComponent(path)}`);
    const info = await infoRes.json();

    if (info.error) {
        document.getElementById('file-preview-info').innerHTML = `<span class="text-red-400">${escapeHtml(info.error)}</span>`;
        return;
    }

    // Display info
    if (fileType === 'sqlite') {
        document.getElementById('file-preview-info').innerHTML = `
            <span class="text-gray-400">SQLite Database</span> ·
            <span class="text-gray-500">${info.tables?.length || 0} tables</span>
        `;

        // Show tables
        const pathEsc = escapeHtml(path);
        document.getElementById('file-preview-content').innerHTML = `
            <div class="space-y-2">
                ${info.tables?.map(t => {
                    const tNameEsc = escapeHtml(t.name);
                    return `
                    <div class="flex items-center justify-between p-2 rounded bg-[#0d1117] hover:bg-[#21262d] cursor-pointer"
                         data-sqlite-path="${pathEsc}" data-sqlite-table="${tNameEsc}"
                         onclick="previewSqliteTable(this.dataset.sqlitePath, this.dataset.sqliteTable)">
                        <span class="font-mono text-sm">${tNameEsc}</span>
                        <span class="text-xs text-gray-500">${t.row_count?.toLocaleString() || 0} rows</span>
                    </div>
                `;
                }).join('') || '<div class="text-gray-500">No tables found</div>'}
            </div>
        `;
    } else {
        document.getElementById('file-preview-info').innerHTML = `
            <span class="text-gray-400">${escapeHtml(fileType.toUpperCase())}</span> ·
            <span class="text-gray-500">${escapeHtml(info.row_count_human || info.row_count?.toLocaleString() + ' rows')}</span> ·
            <span class="text-gray-500">${info.columns?.length || 0} columns</span>
        `;

        // Get preview data
        const previewRes = await fetch(`/api/files/preview?path=${encodeURIComponent(path)}`);
        const preview = await previewRes.json();

        if (preview.error) {
            document.getElementById('file-preview-content').innerHTML = `<span class="text-red-400">${escapeHtml(preview.error)}</span>`;
            return;
        }

        // Render preview table
        renderPreviewTable(preview);
    }
}

window.previewSqliteTable = async function(path, table) {
    document.getElementById('file-preview-info').innerHTML = `Loading ${escapeHtml(table)}...`;

    const previewRes = await fetch(`/api/files/preview?path=${encodeURIComponent(path)}&table=${encodeURIComponent(table)}`);
    const preview = await previewRes.json();

    if (preview.error) {
        document.getElementById('file-preview-content').innerHTML = `<span class="text-red-400">${escapeHtml(preview.error)}</span>`;
        return;
    }

    document.getElementById('file-preview-info').innerHTML = `
        <span class="text-gray-400">SQLite</span> ·
        <span class="font-mono text-sm">${escapeHtml(table)}</span> ·
        <span class="text-gray-500">${Number(preview.row_count) || 0} rows (showing first 100)</span>
    `;

    currentPreviewFile.table = table;
    renderPreviewTable(preview);
}

function renderPreviewTable(data) {
    if (!data.columns || data.columns.length === 0) {
        document.getElementById('file-preview-content').innerHTML = '<div class="text-gray-500">No data</div>';
        return;
    }

    document.getElementById('file-preview-content').innerHTML = `
        <div class="overflow-x-auto">
            <table class="w-full text-xs">
                <thead class="bg-[#21262d] sticky top-0">
                    <tr>
                        ${data.columns.map(c => `
                            <th class="px-3 py-2 text-left text-gray-400 font-medium border-b border-[#30363d]">
                                ${escapeHtml(c.name)}
                                <span class="text-gray-600 font-normal ml-1">${escapeHtml(c.type)}</span>
                            </th>
                        `).join('')}
                    </tr>
                </thead>
                <tbody class="font-mono">
                    ${data.rows.slice(0, 50).map((row, i) => `
                        <tr class="${i % 2 === 0 ? '' : 'bg-[#0d1117]/50'}">
                            ${row.map(cell => `
                                <td class="px-3 py-1.5 border-b border-[#30363d]/50 max-w-[200px] truncate">
                                    ${cell === null ? '<span class="null-badge">NULL</span>' : escapeHtml(String(cell))}
                                </td>
                            `).join('')}
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        </div>
    `;
}

window.hideFilePreviewModal = function() {
    window.dispatchEvent(new Event('close-file-preview-modal'));
    currentPreviewFile = null;
}

window.insertFileQuery = function() {
    if (!currentPreviewFile) return;

    let query = '';
    const path = currentPreviewFile.path;

    if (currentPreviewFile.fileType === 'parquet') {
        query = `SELECT * FROM read_parquet('${path}') LIMIT 100`;
    } else if (currentPreviewFile.fileType === 'csv' || currentPreviewFile.fileType === 'tsv') {
        query = `SELECT * FROM read_csv_auto('${path}', max_line_size=20000000) LIMIT 100`;
    } else if (currentPreviewFile.fileType === 'json') {
        query = `SELECT * FROM read_json_auto('${path}', maximum_object_size=134217728) LIMIT 100`;
    } else if (currentPreviewFile.fileType === 'sqlite' && currentPreviewFile.table) {
        query = `SELECT * FROM sqlite_scan('${path}', '${currentPreviewFile.table}') LIMIT 100`;
    }

    if (query && editor) {
        editor.dispatch({
            changes: { from: 0, to: editor.state.doc.length, insert: query }
        });
        setEngine('duckdb');
        hideFilePreviewModal();
        editor.focus();
    }
}

// File preview modal backdrop click handled by Alpine.js

// ============================================================================
// Update runQuery to support DuckDB
// ============================================================================

const originalRunQuery = window.runQuery;
window.runQuery = async function() {
    if (currentEngine === 'duckdb') {
        await runDuckDBQuery();
    } else {
        await originalRunQuery();
    }
}

// ============================================================================
// Export to Parquet
// ============================================================================

window.showParquetModal = function() {
    if (!currentResults || !currentResults.columns || currentResults.columns.length === 0) {
        tuskToast('No results to export', 'warning');
        return;
    }

    if (currentEngine !== 'duckdb') {
        tuskToast('Parquet export only available with DuckDB engine', 'warning');
        return;
    }

    window.dispatchEvent(new Event('open-parquet-modal'));
    document.getElementById('parquet-path').focus();
}

window.hideParquetModal = function() {
    window.dispatchEvent(new Event('close-parquet-modal'));
    document.getElementById('parquet-path').value = '';
}

document.getElementById('parquet-form').onsubmit = async (e) => {
    e.preventDefault();

    const path = document.getElementById('parquet-path').value.trim();
    if (!path) return;

    const sql = editor ? editor.state.doc.toString() : '';
    if (!sql.trim()) {
        tuskToast('No query to export', 'warning');
        return;
    }

    try {
        const res = await fetch('/api/duckdb/export-parquet', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ sql, path })
        });

        const result = await res.json();

        if (result.success) {
            tuskToast('Exported successfully to: ' + result.path, 'success');
            hideParquetModal();
        } else {
            tuskToast('Export failed: ' + result.error, 'error');
        }
    } catch (err) {
        tuskToast('Export failed: ' + err.message, 'error');
    }
}

// Parquet modal backdrop click handled by Alpine.js

async function runDuckDBQuery() {
    if (isRunning) return;

    const sqlText = editor.state.doc.toString();

    isRunning = true;
    queryAbortController = new AbortController();

    // Update Run button to show Cancel
    const runBtn = document.getElementById('run-btn');
    runBtn.disabled = false;
    runBtn.onclick = cancelQuery;
    runBtn.innerHTML = `
        <svg class="w-4 h-4 animate-spin" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path>
        </svg>
        Cancel
    `;
    runBtn.classList.remove('bg-green-600', 'hover:bg-green-700');
    runBtn.classList.add('bg-red-600', 'hover:bg-red-700');

    document.getElementById('results-header').innerHTML = `
        <span class="text-gray-400 flex items-center gap-2">
            <svg class="w-4 h-4 animate-spin" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <circle cx="12" cy="12" r="10" stroke-opacity="0.25" stroke-width="4"></circle>
                <path d="M12 2a10 10 0 0110 10" stroke-width="4"></path>
            </svg>
            Running DuckDB query...
        </span>
    `;
    document.getElementById('results-table').innerHTML = '';

    try {
        const res = await fetch('/api/duckdb/query', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ sql: sqlText }),
            signal: queryAbortController.signal
        });

        currentResults = await res.json();

        // Reset sort/filter/page for new results
        sortColumn = null;
        sortDirection = 'asc';
        filterText = '';
        currentPage = 1;

        // Store results in active tab
        const activeTab = tabs.find(t => t.id === activeTabId);
        if (activeTab) {
            activeTab.sql = sqlText;
            activeTab.results = currentResults;
        }

        renderResults();
    } catch (err) {
        if (err.name === 'AbortError') {
            currentResults = { error: 'Query cancelled by user' };
        } else {
            currentResults = { error: err.message };
        }
        renderResults();
    } finally {
        isRunning = false;
        queryAbortController = null;
        resetRunButton();
    }
}

// ============================================================================
// Geo Visualization
// ============================================================================

let currentGeoData = null;
let geoColumnIndex = null;
let map = null;

function hasGeoColumn() {
    if (!currentResults || !currentResults.columns || !currentResults.rows) return false;
    const geoIndices = detectGeoColumns(currentResults.columns, currentResults.rows);
    return geoIndices.length > 0;
}
window.hasGeoColumn = hasGeoColumn;

// WKT patterns for geo detection
const WKT_PATTERN = /^(POINT|LINESTRING|POLYGON|MULTIPOINT|MULTILINESTRING|MULTIPOLYGON|GEOMETRYCOLLECTION)\s*(Z|M|ZM)?\s*\(/i;
const EWKT_PATTERN = /^SRID=\d+;(POINT|LINESTRING|POLYGON|MULTIPOINT|MULTILINESTRING|MULTIPOLYGON|GEOMETRYCOLLECTION)\s*(Z|M|ZM)?\s*\(/i;

function isGeometryValue(value) {
    if (value === null || value === undefined) return false;
    if (typeof value !== 'string') return false;

    const v = value.trim();

    // Check WKT/EWKT
    if (WKT_PATTERN.test(v) || EWKT_PATTERN.test(v)) return true;

    // Check GeoJSON
    if (v.startsWith('{') && v.includes('"type"')) {
        try {
            const data = JSON.parse(v);
            if (data.type && ['Point', 'LineString', 'Polygon', 'MultiPoint', 'MultiLineString', 'MultiPolygon', 'GeometryCollection', 'Feature', 'FeatureCollection'].includes(data.type)) {
                return true;
            }
        } catch (e) { /* not JSON, fall through to hex WKB check */ }
    }

    // Check hex WKB (starts with 01 or 00, all hex chars)
    if (v.length >= 10 && /^(01|00)[0-9a-fA-F]+$/.test(v)) return true;

    return false;
}

function detectGeoColumns(columns, rows) {
    const geoIndices = [];
    const geoColNames = ['geom', 'geometry', 'the_geom', 'shape', 'geo', 'location', 'wkb_geometry'];
    const geoTypeNames = ['geometry', 'geography', 'point', 'polygon', 'linestring'];

    for (let i = 0; i < columns.length; i++) {
        const colName = (columns[i].name || '').toLowerCase();
        const colType = (columns[i].type || '').toLowerCase();

        // Check by type
        if (geoTypeNames.some(t => colType.includes(t))) {
            geoIndices.push(i);
            continue;
        }

        // Check by name
        if (geoColNames.includes(colName) || colName.endsWith('_geom') || colName.endsWith('_geometry')) {
            geoIndices.push(i);
            continue;
        }

        // Check actual values
        if (rows && rows.length > 0) {
            for (let j = 0; j < Math.min(5, rows.length); j++) {
                if (rows[j] && rows[j][i] && isGeometryValue(rows[j][i])) {
                    geoIndices.push(i);
                    break;
                }
            }
        }
    }

    return geoIndices;
}

function parseWKT(wkt) {
    if (!wkt) return null;
    wkt = wkt.trim();

    // Handle EWKT
    if (wkt.toUpperCase().startsWith('SRID=')) {
        wkt = wkt.split(';')[1] || wkt;
    }

    // Strip Z/M/ZM dimension modifiers: "POLYGON Z ((" → "POLYGON (("
    wkt = wkt.replace(/^(MULTI)?(POINT|LINESTRING|POLYGON|GEOMETRYCOLLECTION)\s+(Z|M|ZM)\s*\(/i, '$1$2 (');

    const upper = wkt.toUpperCase();

    try {
        if (upper.startsWith('POINT')) {
            const match = wkt.match(/POINT\s*\(\s*([-\d.]+)\s+([-\d.]+)/i);
            if (match) {
                return { type: 'Point', coordinates: [parseFloat(match[1]), parseFloat(match[2])] };
            }
        } else if (upper.startsWith('LINESTRING')) {
            const coords = extractCoords(wkt);
            if (coords.length > 0) {
                return { type: 'LineString', coordinates: coords };
            }
        } else if (upper.startsWith('POLYGON')) {
            const rings = extractPolygonRings(wkt);
            if (rings.length > 0) {
                return { type: 'Polygon', coordinates: rings };
            }
        } else if (upper.startsWith('MULTIPOINT')) {
            const coords = extractCoords(wkt);
            if (coords.length > 0) {
                return { type: 'MultiPoint', coordinates: coords };
            }
        } else if (upper.startsWith('MULTILINESTRING')) {
            const lines = extractMultiCoords(wkt);
            if (lines.length > 0) {
                return { type: 'MultiLineString', coordinates: lines };
            }
        } else if (upper.startsWith('MULTIPOLYGON')) {
            const polygons = extractMultiPolygonCoords(wkt);
            if (polygons.length > 0) {
                return { type: 'MultiPolygon', coordinates: polygons };
            }
        }
    } catch (e) { /* malformed WKT — return null below so caller falls back */ }

    return null;
}

function extractCoords(wkt) {
    const start = wkt.indexOf('(');
    const end = wkt.lastIndexOf(')');
    if (start === -1 || end === -1) return [];

    const content = wkt.slice(start + 1, end).replace(/\(|\)/g, '');
    const coords = [];

    content.split(',').forEach(part => {
        const nums = part.trim().split(/\s+/);
        if (nums.length >= 2) {
            coords.push([parseFloat(nums[0]), parseFloat(nums[1])]);
        }
    });

    return coords;
}

function extractPolygonRings(wkt) {
    const start = wkt.indexOf('(');
    const end = wkt.lastIndexOf(')');
    if (start === -1 || end === -1) return [];

    const content = wkt.slice(start + 1, end);
    const rings = [];
    let depth = 0;
    let current = '';

    for (const char of content) {
        if (char === '(') {
            depth++;
            if (depth === 1) { current = ''; continue; }
        } else if (char === ')') {
            depth--;
            if (depth === 0) {
                const coords = [];
                current.split(',').forEach(part => {
                    const nums = part.trim().split(/\s+/);
                    if (nums.length >= 2) {
                        coords.push([parseFloat(nums[0]), parseFloat(nums[1])]);
                    }
                });
                if (coords.length > 0) rings.push(coords);
                current = '';
                continue;
            }
        }
        if (depth >= 1) current += char;
    }

    return rings;
}

function extractMultiCoords(wkt) {
    const start = wkt.indexOf('(');
    const end = wkt.lastIndexOf(')');
    if (start === -1 || end === -1) return [];

    const content = wkt.slice(start + 1, end);
    const lines = [];
    let depth = 0;
    let current = '';

    for (const char of content) {
        if (char === '(') {
            depth++;
            if (depth === 1) { current = ''; continue; }
        } else if (char === ')') {
            depth--;
            if (depth === 0) {
                const coords = [];
                current.split(',').forEach(part => {
                    const nums = part.trim().split(/\s+/);
                    if (nums.length >= 2) {
                        coords.push([parseFloat(nums[0]), parseFloat(nums[1])]);
                    }
                });
                if (coords.length > 0) lines.push(coords);
                current = '';
                continue;
            }
        }
        if (depth >= 1) current += char;
    }

    return lines;
}

function extractMultiPolygonCoords(wkt) {
    // MULTIPOLYGON(((x y, x y, ...), (hole)), ((x y, x y, ...)))
    // Find the opening paren after MULTIPOLYGON
    const mIdx = wkt.toUpperCase().indexOf('MULTIPOLYGON');
    if (mIdx === -1) return [];
    const outerStart = wkt.indexOf('(', mIdx);
    if (outerStart === -1) return [];

    const polygons = [];
    let depth = 0;
    let polyStart = -1;

    // Walk through, tracking depth to split individual polygons at depth=1
    for (let i = outerStart; i < wkt.length; i++) {
        const ch = wkt[i];
        if (ch === '(') {
            depth++;
            // depth 2 = start of a polygon's ring group ((ring),(ring))
            if (depth === 2) polyStart = i;
        } else if (ch === ')') {
            depth--;
            // depth 1 = end of a polygon's ring group
            if (depth === 1 && polyStart !== -1) {
                const polyWkt = 'POLYGON' + wkt.slice(polyStart, i + 1);
                const rings = extractPolygonRings(polyWkt);
                if (rings.length > 0) polygons.push(rings);
                polyStart = -1;
            }
            if (depth === 0) break;
        }
    }

    return polygons;
}

function geometryToGeoJSON(value) {
    if (!value) return null;

    // Already GeoJSON object
    if (typeof value === 'object' && value.type) return value;

    if (typeof value === 'string') {
        const v = value.trim();

        // Try GeoJSON string
        if (v.startsWith('{')) {
            try {
                const data = JSON.parse(v);
                if (data.type) return data;
            } catch (e) { /* not JSON — try WKT below */ }
        }

        // Try WKT
        return parseWKT(v);
    }

    return null;
}

function rowsToGeoJSON(columns, rows, geoColIdx) {
    const features = [];
    const colNames = columns.map((c, i) => c.name || `col_${i}`);

    for (const row of rows) {
        if (geoColIdx >= row.length) continue;

        const geom = geometryToGeoJSON(row[geoColIdx]);
        if (!geom) continue;

        const properties = {};
        for (let i = 0; i < row.length; i++) {
            if (i === geoColIdx) continue;
            const colName = colNames[i] || `col_${i}`;
            const val = row[i];

            if (val === null || val === undefined) {
                properties[colName] = null;
            } else if (typeof val === 'object') {
                properties[colName] = JSON.stringify(val);
            } else {
                properties[colName] = val;
            }
        }

        features.push({
            type: 'Feature',
            geometry: geom,
            properties: properties
        });
    }

    return { type: 'FeatureCollection', features: features };
}

window.showMapModal = async function() {
    if (!currentResults || !currentResults.columns) return;

    const geoIndices = detectGeoColumns(currentResults.columns, currentResults.rows || []);
    if (geoIndices.length === 0) {
        tuskToast('No geometry columns detected', 'warning');
        return;
    }

    geoColumnIndex = geoIndices[0]; // Use first geo column

    // For server-paginated results, fetch all geometries from dedicated endpoint
    if (serverPagination && currentConnection?.type === 'postgres' && currentSql) {
        // Show loading state
        window.dispatchEvent(new Event('open-map-modal'));
        document.getElementById('map-feature-count').textContent = 'Loading geometries...';

        try {
            // Fetch geometries separately (only geometry column, optimized for map)
            const res = await fetch('/api/query/map-data', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    connection_id: currentConnection.id,
                    sql: currentSql,
                    max_features: 100000,
                    // simplify_tolerance: 0.0001,  // Optional: simplify large geometries
                }),
            });

            const mapData = await res.json();

            if (mapData.error) {
                tuskToast(`Map data error: ${mapData.error}`, 'error');
                window.dispatchEvent(new Event('close-map-modal'));
                return;
            }

            currentGeoData = mapData;
            mapGeoData = mapData;

            const truncatedNote = mapData.truncated
                ? ` (showing ${mapData.returned_count.toLocaleString()} of ${mapData.total_count.toLocaleString()})`
                : '';
            document.getElementById('map-feature-count').textContent =
                `${mapData.features.length.toLocaleString()} features${truncatedNote}`;

            setTimeout(() => initMap(), 100);
            return;

        } catch (err) {
            tuskToast(`Failed to load map data: ${err.message}`, 'error');
            window.dispatchEvent(new Event('close-map-modal'));
            return;
        }
    }

    // Client-side: build GeoJSON from current results
    currentGeoData = rowsToGeoJSON(currentResults.columns, currentResults.rows || [], geoColumnIndex);

    if (currentGeoData.features.length === 0) {
        tuskToast('No valid geometries found', 'warning');
        return;
    }

    // Check for projected coordinates and show CRS bar if needed
    if (window.tuskReproject) {
        currentGeoData = window.tuskReproject(currentGeoData);
    }

    // Register callback for CRS reproject button
    window._tuskMapUpdateCallback = function(reprojected, epsgCode) {
        currentGeoData = reprojected;
        document.getElementById('map-feature-count').textContent = `${currentGeoData.features.length} features (EPSG:${epsgCode} → 4326)`;
        if (map) { map.remove(); map = null; }
        setTimeout(() => initMap(), 50);
    };

    window.dispatchEvent(new Event('open-map-modal'));
    document.getElementById('map-feature-count').textContent = `${currentGeoData.features.length} features`;

    // Initialize map after modal is visible
    setTimeout(() => initMap(), 100);
}

window.hideMapModal = function() {
    window.dispatchEvent(new Event('close-map-modal'));
    if (map) {
        map.remove();
        map = null;
    }
}

function initMap() {
    const container = document.getElementById('map-container');
    container.innerHTML = '';

    // Calculate bounds from features
    let bounds = null;

    for (const feature of currentGeoData.features) {
        const geom = feature.geometry;
        if (!geom) continue;

        const coords = getAllCoords(geom);
        for (const coord of coords) {
            if (!bounds) {
                bounds = [[coord[0], coord[1]], [coord[0], coord[1]]];
            } else {
                bounds[0][0] = Math.min(bounds[0][0], coord[0]);
                bounds[0][1] = Math.min(bounds[0][1], coord[1]);
                bounds[1][0] = Math.max(bounds[1][0], coord[0]);
                bounds[1][1] = Math.max(bounds[1][1], coord[1]);
            }
        }
    }

    // Default center if no bounds
    const center = bounds
        ? [(bounds[0][0] + bounds[1][0]) / 2, (bounds[0][1] + bounds[1][1]) / 2]
        : [0, 0];

    map = new maplibregl.Map({
        container: container,
        style: {
            version: 8,
            sources: {
                'carto-dark': {
                    type: 'raster',
                    tiles: ['https://a.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}@2x.png'],
                    tileSize: 256,
                    attribution: '&copy; <a href="https://carto.com/">CARTO</a>'
                }
            },
            layers: [{
                id: 'carto-dark-layer',
                type: 'raster',
                source: 'carto-dark',
                minzoom: 0,
                maxzoom: 22
            }]
        },
        center: center,
        zoom: 2
    });

    map.on('load', () => {
        // Add GeoJSON source
        map.addSource('data', {
            type: 'geojson',
            data: currentGeoData
        });

        // Add polygon layer
        map.addLayer({
            id: 'polygons',
            type: 'fill',
            source: 'data',
            filter: ['any',
                ['==', ['geometry-type'], 'Polygon'],
                ['==', ['geometry-type'], 'MultiPolygon']
            ],
            paint: {
                'fill-color': '#6366f1',
                'fill-opacity': 0.4
            }
        });

        // Add polygon outline
        map.addLayer({
            id: 'polygon-outlines',
            type: 'line',
            source: 'data',
            filter: ['any',
                ['==', ['geometry-type'], 'Polygon'],
                ['==', ['geometry-type'], 'MultiPolygon']
            ],
            paint: {
                'line-color': '#818cf8',
                'line-width': 2
            }
        });

        // Add line layer
        map.addLayer({
            id: 'lines',
            type: 'line',
            source: 'data',
            filter: ['any',
                ['==', ['geometry-type'], 'LineString'],
                ['==', ['geometry-type'], 'MultiLineString']
            ],
            paint: {
                'line-color': '#22c55e',
                'line-width': 3
            }
        });

        // Add point layer
        map.addLayer({
            id: 'points',
            type: 'circle',
            source: 'data',
            filter: ['any',
                ['==', ['geometry-type'], 'Point'],
                ['==', ['geometry-type'], 'MultiPoint']
            ],
            paint: {
                'circle-radius': 6,
                'circle-color': '#f59e0b',
                'circle-stroke-width': 2,
                'circle-stroke-color': '#fbbf24'
            }
        });

        // Fit to bounds
        if (bounds) {
            map.fitBounds(bounds, { padding: 50, maxZoom: 15 });
        }

        // Escape HTML to prevent XSS in popups
        function escHtml(s) {
            const d = document.createElement('div');
            d.textContent = String(s ?? '');
            return d.innerHTML;
        }

        // Add popup on click
        let clickPopup = null;

        // Properties are emitted in arbitrary order by Postgres / MapLibre.
        // Force human-friendly fields to the top of the popup so users see
        // "Name" before they see "id".
        const POPUP_LEAD_FIELDS = [
            'name', 'title', 'label', 'description', 'address',
            'name_en', 'name_es', 'name_local', 'name_alt',
            'city', 'country', 'region', 'type', 'category', 'kind',
            'status', 'code',
        ];

        function _orderProps(props) {
            const lead = [];
            const seen = new Set();
            for (const key of POPUP_LEAD_FIELDS) {
                if (key in props && props[key] !== null && props[key] !== '') {
                    lead.push([key, props[key]]);
                    seen.add(key);
                }
            }
            const rest = [];
            // id last; everything else in declaration order between.
            for (const [k, v] of Object.entries(props)) {
                if (seen.has(k) || k === 'id') continue;
                rest.push([k, v]);
            }
            if ('id' in props) rest.push(['id', props.id]);
            return [...lead, ...rest];
        }

        function showClickPopup(e) {
            if (!e.features || e.features.length === 0) return;
            if (clickPopup) clickPopup.remove();

            const props = e.features[0].properties || {};
            const ordered = _orderProps(props);

            // Lead with whichever label-like field exists, big-and-bold.
            let title = '';
            for (const key of POPUP_LEAD_FIELDS) {
                if (props[key]) { title = escHtml(String(props[key])); break; }
            }

            let html = '<div class="text-xs max-w-xs max-h-64 overflow-auto">';
            if (title) {
                html += `<div class="font-semibold text-sm text-white mb-1.5">${title}</div>`;
            }
            html += '<table class="w-full">';
            for (const [key, value] of ordered) {
                const displayVal = (value === null || value === '')
                    ? '<span class="text-gray-500">—</span>'
                    : escHtml(String(value).slice(0, 200));
                html += `<tr>
                    <td class="font-medium pr-2 text-gray-400 align-top whitespace-nowrap">${escHtml(key)}</td>
                    <td class="text-gray-200">${displayVal}</td>
                </tr>`;
            }
            html += '</table></div>';

            clickPopup = new maplibregl.Popup({ className: 'dark-popup', maxWidth: '320px' })
                .setLngLat(e.lngLat)
                .setHTML(html)
                .addTo(map);
        }

        // Register click handlers for each layer
        map.on('click', 'points', showClickPopup);
        map.on('click', 'lines', showClickPopup);
        map.on('click', 'polygons', showClickPopup);
        map.on('click', 'polygon-outlines', showClickPopup);

        // Hover tooltip
        let hoverPopup = null;

        function getFeatureLabel(props) {
            // Keep this list in sync with `_LABEL_NAMES` in postgres.py
            // (the backend chooses which columns to ship; the frontend
            // chooses which one to show). Order matters — first hit
            // wins, so the human-readable name comes before id. B2 in
            // 0.4.26 added Spanish/Portuguese equivalents.
            const labelFields = [
                'name', 'Name', 'NAME', 'nombre', 'Nombre', 'nome',
                'title', 'titulo', 'label', 'etiqueta',
                'name_en', 'name_es', 'name_local', 'name_alt',
                'nombre_corto', 'nombre_normalizado',
                'descripcion', 'description', 'address', 'direccion',
                'id', 'ID', 'osm_id',
            ];
            for (const field of labelFields) {
                if (props[field]) return String(props[field]);
            }
            // Check for OSM tags (could be JSON string or object)
            if (props.tags) {
                let tags = props.tags;
                if (typeof tags === 'string') {
                    try { tags = JSON.parse(tags); } catch(e) { return null; }
                }
                if (tags.name) return tags.name;
                if (tags['name:en']) return tags['name:en'];
                // Fallback to any key that contains 'name'
                for (const [k, v] of Object.entries(tags)) {
                    if (k.toLowerCase().includes('name') && v) return String(v);
                }
            }
            // Fallback: first string property that's not too long
            for (const [k, v] of Object.entries(props)) {
                if (typeof v === 'string' && v.length > 0 && v.length < 50 && !k.startsWith('_')) {
                    return v;
                }
            }
            return null;
        }

        function showHoverTooltip(e) {
            if (!e.features || !e.features[0]) return;
            const props = e.features[0].properties;
            const label = getFeatureLabel(props);
            if (!label) return;

            if (hoverPopup) hoverPopup.remove();
            hoverPopup = new maplibregl.Popup({
                closeButton: false,
                closeOnClick: false,
                className: 'hover-tooltip',
                offset: 10
            })
                .setLngLat(e.lngLat)
                .setHTML(`<div class="bg-[#1c2128] text-white px-2 py-1 rounded text-xs font-medium shadow-lg border border-[#30363d]">${escHtml(label)}</div>`)
                .addTo(map);
        }

        function hideHoverTooltip() {
            if (hoverPopup) {
                hoverPopup.remove();
                hoverPopup = null;
            }
        }

        // Change cursor and show tooltip on hover - register for each layer
        const layers = ['points', 'lines', 'polygons'];

        layers.forEach(layer => {
            map.on('mouseenter', layer, (e) => {
                map.getCanvas().style.cursor = 'pointer';
                showHoverTooltip(e);
            });
            map.on('mouseleave', layer, () => {
                map.getCanvas().style.cursor = '';
                hideHoverTooltip();
            });
            map.on('mousemove', layer, showHoverTooltip);
        });
    });
}

function _rawCoords(geom) {
    const coords = [];
    const type = geom.type;
    const c = geom.coordinates;
    if (type === 'Point') coords.push(c);
    else if (type === 'MultiPoint' || type === 'LineString') coords.push(...c);
    else if (type === 'MultiLineString' || type === 'Polygon') c.forEach(r => coords.push(...r));
    else if (type === 'MultiPolygon') c.forEach(p => p.forEach(r => coords.push(...r)));
    return coords.filter(c => Array.isArray(c) && c.length >= 2 && isFinite(c[0]) && isFinite(c[1]));
}

function getAllCoords(geom) {
    return _rawCoords(geom).filter(coord =>
        coord[0] >= -180 && coord[0] <= 180 &&
        coord[1] >= -90 && coord[1] <= 90
    );
}

window.exportGeoJSON = function() {
    if (!currentGeoData) return;

    const blob = new Blob([JSON.stringify(currentGeoData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'export.geojson';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

// Map modal backdrop click and escape handled by Alpine.js

// ─── Editor ↔ results splitter ──────────────────────────────────
// Drag the thin bar between the editor and the results to resize the
// editor pane. The editor host (`#sql-editor`) gets an explicit pixel
// height; the results pane fills the rest.
//
// Leading semicolon: the previous statement might end without one and
// JS would parse `(function ...)` as a call on whatever the previous
// expression evaluated to — exactly the bug the v0.4.4 frontend smoke
// test caught (`(intermediate value)(...) is not a function`).
;(function initSplitter() {
    const splitter = document.getElementById('editor-results-splitter');
    const editorHost = document.getElementById('sql-editor');
    if (!splitter || !editorHost) return;

    const KEY = 'tusk_editor_pane_h';
    const saved = parseInt(localStorage.getItem(KEY));
    const initial = Number.isFinite(saved) && saved >= 120 ? saved : 220;
    editorHost.style.height = initial + 'px';

    let dragging = false;
    let startY = 0;
    let startHeight = 0;
    splitter.addEventListener('mousedown', (e) => {
        e.preventDefault();
        dragging = true;
        startY = e.clientY;
        startHeight = editorHost.getBoundingClientRect().height;
        document.body.style.cursor = 'row-resize';
        document.body.style.userSelect = 'none';
    });
    document.addEventListener('mousemove', (e) => {
        if (!dragging) return;
        const next = Math.max(120, Math.min(800, startHeight + (e.clientY - startY)));
        editorHost.style.height = next + 'px';
    });
    document.addEventListener('mouseup', () => {
        if (!dragging) return;
        dragging = false;
        document.body.style.cursor = '';
        document.body.style.userSelect = '';
        const h = parseInt(editorHost.style.height);
        if (Number.isFinite(h)) localStorage.setItem(KEY, h);
    });
})();

// ─── Mobile / responsive niceties ───────────────────────────────
// On narrow viewports, the sidebar would push the editor offscreen.
// Add a "Sidebar" toggle button + sticky overlay behavior.
;(function initResponsive() {
    if (window.matchMedia && window.matchMedia('(max-width: 768px)').matches) {
        const aside = document.querySelector('aside.sidebar');
        if (aside && !aside.dataset.collapsed) {
            aside.dataset.collapsed = '1';
            aside.style.display = 'none';
        }
        // Inject a small toggle button into the top nav so the sidebar
        // can be reopened. The base.html top nav already has icon-btn
        // styles available.
        const nav = document.querySelector('.tusk-topnav');
        if (nav && !document.getElementById('mobile-sidebar-toggle')) {
            const btn = document.createElement('button');
            btn.id = 'mobile-sidebar-toggle';
            btn.className = 'tusk-icon-btn md:hidden';
            btn.title = 'Toggle sidebar';
            btn.innerHTML = '<svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M4 6h16M4 12h16M4 18h16"/></svg>';
            btn.onclick = () => {
                const a = document.querySelector('aside.sidebar');
                if (!a) return;
                a.style.display = (a.style.display === 'none') ? '' : 'none';
            };
            nav.insertBefore(btn, nav.firstChild);
        }
    }
})();
