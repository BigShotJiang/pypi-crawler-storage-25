###############################################################################
#     Title : PgRDARqst.py
#    Author : Zaihua Ji,  zji@ucar.edu
#      Date : 09/25/2020
#             2025-02-10 transferred to package rda_python_dsrqst from
#             https://github.com/NCAR/rda-shared-libraries.git
#   Purpose : python library module for holding some functions for submitting request
#             on command line
#    Github : https://github.com/NCAR/rda-python-dsrqst.git
###############################################################################
import os
import re
import smtplib
from email.message import EmailMessage
from .pg_rqst import PgRqst

class PgRDARqst(PgRqst):
   """RDA request submission library for submitting and managing data requests.

   Extends PgRqst with methods for submitting subset/temporal requests,
   checking request status, sending email notifications, and managing
   request control records. Supports both command-line and web request
   submission workflows.
   """

   USG = (
      "\n\nUsage for function rda_request(rqst, logact)\n\n" +
      "  rqst - a dictionary array for request information:\n" +
      "   'rtype'   : RequestType (mandatory)\n" +
      "   'dsid'    : DatasetId (mandatory)\n" +
      "   'gindex'  : GroupIndex (optional, default to 0)\n" +
      "   'email'   : UserEmail (optional, default to UserLoginID@ucar.edu)\n" +
      "   'rstat'   : RequestStatus (optional, default to value in request control record)\n" +
      "   'sflag'   : SubsetFlags (optional, 1 Variable, 2 - Temporal, 3 Spatial)\n" +
      "   'tflag'   : TarFlag (Optional, default to N - No tar, Y-tar small files)\n" +
      "   'dfmt'    : DataFormat (optional, specify for data format conversion)\n" +
      "   'afmt'    : ArchiveFormat (optional, set to compress result)\n" +
      " 'size_request' : DataSizerequested (optional)\n" +
      " 'size_input'   : DataSizeInvolved (optional)\n" +
      "   'fcount'  : NumberofFilesRequested (optional)\n" +
      "   'ptlimit' : ParitionFileCountLimit (optional)\n" +
      "   'ptsize'  : ParitionDataSizeLimit (optional)\n" +
      "   'command' : RequestCommand (optional, command different from the one in request control)\n" +
      " 'validsubset' : ValidationCommand (optional, command to validate rinfo at subset submission time)\n" +
      "  'location' : RequestLocation (optional, default to current working directory)\n" +
      "  'fromflag' : RequestFromFlag (optional, default to 'C' - command line; 'W' - web request)\n" +
      "   'rinfo'   : RequesInfo (detail request information, mandatory for subset request)\n" +
      "   'rnote'   : RequestNote (optional, readable version of 'rinfo')\n\n" +
      "     logact - optional logging action flag, self.LOGWRN as default.\n\n" +
      "      Return: message for the request being added.\n" +
      " For example: msg = rda_request(rqst)\n")
   SUSG = (
      "\n\nUsage for function rda_request_status(ridx, email, logact)\n\n" +
      "    ridx - Request index\n" +
      "   email - User email address\n" +
      "  logact - optional logging action flag, self.LOGWRN as default\n\n" +
      "   Return: number of requests matched and a dictionary array for request status:\n" +
      "  'rindex'       : Request Index\n" +
      "  'rqstid'       : Request ID\n" +
      "  'email'        : User Email\n" +
      "  'dsid'         : Dataset Id\n" +
      "  'gindex'       : Group Index (0 if no group)\n" +
      "  'rqsttype'     : Request Type\n" +
      "  'status'       : Request Status (include progress if under building)\n" +
      "  'size_request' : Data Size requested\n" +
      "  'size_input'   : Data Size Involved\n" +
      "  'fcount'       : Number of Files requested\n" +
      "  'ptlimit'      : file count limit for each partition\n" +
      "  'ptsize'       : data size limit for each partition\n" +
      "  'date_rqst'    : Date request submitted\n" +
      "  'time_rqst'    : Time request submitted\n" +
      "  'date_ready'   : Date request built\n" +
      "  'time_ready'   : Time request built\n" +
      "  'date_purge'   : Date request to be purged\n" +
      "  'time_purge'   : Time request to be purged\n" +
      "  'data_format'  : Data Format (example, NETCDF)\n" +
      "  'file_format'  : Archive Foramt (example, GZ)\n" +
      "  'specialist'   : Specialist who handles the request\n" +
      "  'location'     : Path to the requested data\n" +
      "  'rnote'        : Readable subsetting request detail\n" +
      "  'rinfo'        : Subsetting request string\n" +
      "For example:\n" +
      "(cnt, pgrecs) = rda_request_status(ridx, email)\n" +
      "if cnt == 2:\n" +
      "   status0 = pgrecs['status'][0]\n" +
      "   status1 = pgrecs['status'][1]\n" +
      "\n")

   def __init__(self):
      """Initialize PgRDARqst with validation command and partition settings."""
      super().__init__()  # initialize parent class
      self.VLDCMD = None
      self.PTLIMIT = self.PTSIZE = 0

   def rda_request(self, rqst = None, logact = None):
      """Submit an RDA data request.

      Args:
         rqst: Dictionary with request information (rtype, dsid, email, rinfo, etc.).
               Pass None to display usage help.
         logact: Logging action flag, defaults to LOGWRN.

      Returns:
         String message or dictionary with request submission result.
      """
      if logact is None: logact = self.LOGWRN
      if not rqst:
         self.pglog(self.USG, self.WARNLG)
         return self.pglog("Miss request information in form of dictionary array", logact|self.RETMSG)
      pgrqst = {}    # intialize empty dictionary
      msg = self.common_request_info(pgrqst, rqst, logact)
      if msg: return msg
      msg = self.process_request_detail(pgrqst, rqst, logact)
      if msg: return msg
      msg = self.add_request_record(pgrqst, logact)
      if msg: return msg
      # retrieve new request record
      pgrqst = self.pgget("dsrqst", "*", "rindex = {}".format(pgrqst['rindex']), logact|self.EXITLG)
      msg = self.build_request_message(pgrqst, logact)
      self.send_request_email(pgrqst, msg, logact)
      response_msg = self.return_request_message(pgrqst, 1, logact)
      # request submitted, return success message
      if isinstance(response_msg, str):
         return response_msg + msg
      else:
         response_msg['summary'] = msg
         return response_msg

   def common_request_info(self, pgrqst, rqst, logact):
      """Fill in common request information fields from the request dictionary.

      Args:
         pgrqst: Request record dictionary to populate.
         rqst: Input request dictionary with user-provided values.
         logact: Logging action flag.

      Returns:
         Error message string on failure, None on success.
      """
      wdir = rtype = dsid = email = None
      self.PTLIMIT = self.PTSIZE = 0
      gindex = 0
      if 'rtype' in rqst and rqst['rtype']: rtype = rqst['rtype']
      if not rtype:
         self.pglog(self.USG, self.WARNLG)
         return self.pglog("Request type is missing to subset a request", logact|self.RETMSG)
      if 'dsid' in rqst and rqst['dsid']: dsid = self.format_dataset_id(rqst['dsid'])
      if not dsid:
         self.pglog(self.USG, self.WARNLG)
         return self.pglog("Dataset ID is missing to submit a request", logact|self.RETMSG)
      if 'gindex' in rqst and rqst['gindex']: gindex = rqst['gindex']
      if not gindex and 'rinfo' in rqst and rqst['rinfo']:
         ms = re.search(r'(g|t)index=(\d+)',  rqst['rinfo'])
         if ms: gindex = int(ms.group(2))
      if 'email' in rqst and rqst['email']: email = rqst['email']
      if not email: email = self.PGLOG['CURUID'] + "@ucar.edu"
      unames = self.get_ruser_names(email, 1)
      if not unames: return f"Please register your email {email} at https://gdex.ucar.edu/dashboard/ to submit a data request."
      if 'location' in rqst and rqst['location']: wdir = rqst['location']
      if wdir:
         if wdir == "web":
            wdir = None
         elif not self.check_local_file(wdir, 0, logact):
            return self.pglog(wdir + ": working directory not exists for submit a request", logact|self.RETMSG)
      else:
         wdir = os.getcwd()
      msg = dsid
      if gindex: msg += f"_{gindex}"
      pgctl = self.get_rqst_control(dsid, gindex, rtype, logact)
      if not pgctl:
         return self.pglog(msg + ": NO Request Control record found", logact|self.RETMSG)
      if pgctl['maxrqst'] > 0:
         msg = self.allow_request(rtype, unames, pgctl, rqst['fromflag'] if 'fromflag' in rqst else 'C')
         if msg: return msg
      if pgctl['maxperiod'] and 'rinfo' in rqst and rqst['rinfo']:
         msg = self.valid_request_period(rtype, unames, pgctl, rqst['rinfo'], rqst['fromflag'] if 'fromflag' in rqst else 'C')
         if msg: return msg
      pgrqst['dsid'] = dsid
      pgrqst['email'] = email
      if wdir: pgrqst['location'] = wdir
      pgrqst['fromflag'] = rqst['fromflag'] if 'fromflag' in rqst else 'C'
      if 'ip' in rqst and rqst['ip']: pgrqst['ip'] = rqst['ip']
      # use values in control record
      pgrqst['rqsttype'] = pgctl['rqsttype']
      pgrqst['specialist'] = pgctl['specialist']
      pgrqst['cindex'] = pgctl['cindex']
      pgrqst['gindex'] = pgctl['gindex']
      self.VLDCMD = rqst['validsubset'] if 'validsubset' in rqst and rqst['validsubset'] else pgctl['validsubset']
      if 'command' in rqst and rqst['command']: pgrqst['command'] = rqst['command']
      if 'ptlimit' in rqst and rqst['ptlimit']:
         self.PTLIMIT = pgrqst['ptlimit'] = rqst['ptlimit']
      elif 'ptlimit' in pgctl and pgctl['ptlimit']:
         self.PTLIMIT = pgctl['ptlimit']
      elif 'ptsize' in rqst and rqst['ptsize']:
         self.PTSIZE = pgrqst['ptsize'] = rqst['ptsize']
      elif 'ptsize' in pgctl and pgctl['ptsize']:
         self.PTSIZE = pgctl['ptsize']
      # set request status
      if 'rstat' in rqst and rqst['rstat']:
         pgrqst['status'] = ('Q' if rqst['rstat'] == 'Q'  else 'W')
      elif pgctl['control'] == "A":
         pgrqst['status'] = "Q"
      else:
         pgrqst['status'] = "W"
      # set other request info
      hash = {'sflag' : "subflag", 'tflag' : "tarflag", 'dfmt' : "data_format", 'afmt' : "file_format", 'enote' : "enotice"}
      for key, fld in hash.items():
         if key in rqst and rqst[key]:
            pgrqst[fld] = rqst[key]
         elif fld in pgctl and pgctl[fld]:
            pgrqst[fld] = pgctl[fld]
      # make sure archive format in upper case
      if 'file_format' in pgrqst: pgrqst['file_format'] = pgrqst['file_format'].upper()
      return None

   def allow_request(self, rtype, unames, pgctl, fromflag = None):
      """Check if the user is allowed to submit another request based on maxrqst limit.

      Args:
         rtype: Request type character.
         unames: User name record dictionary.
         pgctl: Request control record.
         fromflag: Request origin flag ('W' for web, 'C' for command line).

      Returns:
         Error message/dictionary if denied, None if allowed.
      """
      cnt = self.pgget("dsrqst", "", "cindex = {} AND email = '{}' AND status <> 'P'".format(pgctl['cindex'], unames['email']))
      if cnt < pgctl['maxrqst']:
         return None
      else:
         rstr = self.request_type(rtype)
         gstr = (" Product" if pgctl['gindex'] else '')
         if fromflag and fromflag == "W":
            return {
               'error': {
                  'code': 'too_many_requests',
                  'message': f'Too many outstanding requests'
               },
               'message': f'Your {rstr} request is denied since you have {cnt} outstanding requests already for this Dataset{gstr} (a maximum of {pgctl["maxrqst"]} is allowed). Please try again later after your other requests have completed processing.',
               'data': {
                  'max_requests': pgctl['maxrqst'],
                  'current_requests': cnt
               }
            }
         else:
            return ("{}: Your {} request is denied since you have {} outstanding ".format(unames['name'], rstr, cnt) +
                 "requests already for this Dataset{}. Please try again later after your other requests have completed processing.".format(gstr))

   def valid_request_period(self, rtype, unames, pgctl, rinfo, fromflag = None):
      """Validate that the request temporal period does not exceed the maximum allowed.

      Args:
         rtype: Request type character.
         unames: User name record dictionary.
         pgctl: Request control record with maxperiod setting.
         rinfo: Request info string containing date range.
         fromflag: Request origin flag ('W' for web, 'C' for command line).

      Returns:
         Error message/dictionary if period exceeded, None if valid.
      """
      dates = None
      ms = re.search(r'dates=(\d+-\d+-\d+)( | \d+:\d+ )(\d+-\d+-\d+)', rinfo)
      if ms:
         dates = [ms.group(1), ms.group(3)]
      else:
         ms = re.search(r'startdate=(\d+-\d+-\d+)', rinfo)
         if ms:
            date1 = ms.group(1)
            ms = re.search(r'enddate=(\d+-\d+-\d+)', rinfo)
            if ms: dates = [date1, ms.group(1)]
      if not dates: return None      
      ms = re.match(r'^(\d+)([YMWD])$', pgctl['maxperiod'], re.I)
      if not ms: return None
      val = int(ms.group(1))
      unit = ms.group(2).upper()
      yr = mn = dy = 0
      if unit == 'Y':
         yr = val
         unit = 'Year'
      elif unit == 'M':
         mn = val
         unit = 'Month'
      elif unit == 'W':
         dy = 7*val
         unit = 'Week'
      else:
         dy = val
         unit = 'Day'
      if self.adddate(dates[0], yr, mn, dy) > dates[1]: return None
      pstr = "{} {}{}".format(val, unit, ('s' if val > 1 else ''))
      rstr = self.request_type(rtype)
      gstr = (" Product" if pgctl['gindex'] else '')
      if fromflag and fromflag == "W":
         return {
            'error': {
               'code': 'request_period_exceeded',
               'message': 'Request Period Exceeded'
            },
            'message': f'Your {rstr} request period, {dates[0]} - {dates[1]}, is longer than {pstr} for this Dataset{gstr}. Please choose a shorter data period.',
            'data': {
               'request_start_date': dates[0],
               'request_end_date': dates[1],
               'maximum_period': pstr
            }
         }
      else:
         return ("{}: Your {} request period, ".format(unames['name'], rstr) +
              "{} - {}, is longer than {} for ".format(dates[0], dates[1], pstr) +
              "this Dataset{}. Please choose a shorter data period.".format(gstr))

   def process_request_detail(self, pgrqst, rqst, logact):
      """Process and fill in detail request info based on the request type.

      Args:
         pgrqst: Request record dictionary to populate.
         rqst: Input request dictionary with user-provided values.
         logact: Logging action flag.

      Returns:
         Error message string on failure, None on success.
      """
      rtype = pgrqst['rqsttype']
      if rtype == "S" or rtype == "T":
         if 'rinfo' in rqst and rqst['rinfo']:
            pgrqst['rinfo'] = rqst['rinfo']
         else:
            self.pglog(self.USG, self.WARNLG)
            return self.pglog("Miss subset request detail for {}".format(rqst['dsid']), logact|self.RETMSG)
         if 'rnote' in rqst and rqst['rnote']:
            pgrqst['note'] = rqst['rnote']
         else:
            pgrqst['note'] = rqst['rinfo']
         msg = self.subset_request_submitted(pgrqst, logact)
         if msg: return msg
         if self.VLDCMD:
            msg = self.valid_request_info(pgrqst['dsid'], rqst['rinfo'], logact)
            if msg: return msg
      else:
         return self.pglog("Request type 'rtype' is not supported yet", logact|self.RETMSG)
      pgrqst['size_request'] = rqst['size_request'] if 'size_request' in rqst and rqst['size_request'] else 0
      pgrqst['size_input'] = rqst['size_input'] if 'size_input' in rqst and rqst['size_input'] else 0
      pgrqst['fcount'] = rqst['fcount'] if 'fcount' in rqst and rqst['fcount'] else 0
      pgrqst['ptcount'] = self.initialize_ptcount(pgrqst)
      return None

   def valid_request_info(self, dsid, rinfo, logact):
      """Validate request info by running the validation command if one is configured.

      Args:
         dsid: Dataset ID string.
         rinfo: Request info string to validate.
         logact: Logging action flag.

      Returns:
         Error message from validation command, or None if valid.
      """
      self.pgsystem("echo {} | {} {}".format(rinfo, self.VLDCMD, dsid), logact, 262+1024)
      return self.PGLOG['SYSERR']

   def add_request_record(self, pgrqst, logact):
      """Add a new request record to the dsrqst table.

      Args:
         pgrqst: Request record dictionary to insert.
         logact: Logging action flag.

      Returns:
         Error message string on failure, None on success.
      """
      unames = self.get_ruser_names(pgrqst['email'], 1)
      nidx = self.new_request_id(logact)
      lname = self.convert_chars(unames.get('lstname', None), 'RQST').upper()
      pgrqst['rqstid'] = "{}{}".format(lname, nidx)   # set request ID
      (pgrqst['date_rqst'], pgrqst['time_rqst']) = self.get_date_time()
      ridx = self.pgadd("dsrqst", pgrqst, logact|self.EXITLG|self.AUTOID|self.DODFLT)
      if ridx > 0:
         if ridx != nidx:  # reset request ID
            record = {'rqstid' : "{}{}".format(lname, ridx)}
            self.pgupdt("dsrqst", record, "rindex = {}".format(ridx), logact|self.EXITLG)
         self.pglog("{}: Request Index {} added for <{}> {}".format(pgrqst['dsid'], ridx, unames['name'], pgrqst['email']), self.LOGWRN)
         pgrqst['rindex'] = ridx
         return None
      else:
         return self.pglog("Fail to add request record for '{}'".format(pgrqst['dsid']), logact|self.RETMSG)

   def new_request_id(self, logact):
      """Find a unique request ID by getting the next available rindex value.

      Args:
         logact: Logging action flag.

      Returns:
         Next available request index (max rindex + 1), or 0 if no records.
      """
      pgrec = self.pgget("dsrqst", "MAX(rindex) maxid", '', logact)
      if pgrec:
         return (pgrec['maxid'] + 1)
      else:
         return 0

   def subset_request_submitted(self, rqst, logact):
      """Check if an identical subset request was already submitted.

      Args:
         rqst: Request record dictionary with dsid, gindex, rqsttype, email, rinfo.
         logact: Logging action flag.

      Returns:
         Message string or dictionary if duplicate found, None otherwise.
      """
      pgrqst = self.pgget("dsrqst", "*", "dsid = '{}' AND gindex = {} ".format(rqst['dsid'], rqst['gindex']) +
                           "AND rqsttype = '{}' AND email = '{}' ".format(rqst['rqsttype'], rqst['email']) +
                           "AND rinfo = '{}'".format(rqst['rinfo']), logact|self.EXITLG)
      if not pgrqst: return None
      msg = self.build_request_message(pgrqst, logact)
      response_msg = self.return_request_message(pgrqst, 0, logact)
      if isinstance(response_msg, dict):
         response_msg['summary'] = msg
         response_msg['data'].update({
            'date_purge': pgrqst['date_purge']
         })
         return response_msg
      else:
         return response_msg + msg

   def build_request_message(self, rqst, logact):
      """Build a summary string message for a submitted request.

      Args:
         rqst: Request record dictionary.
         logact: Logging action flag.

      Returns:
         Formatted request summary string.
      """
      ridx = rqst['rindex']
      dsid = rqst['dsid']
      rstr = self.request_type(rqst['rqsttype'])
      drec = self.pgget("dataset", "title", "dsid = '{}'".format(dsid), logact|self.EXITLG)
      buf = ("Request Summary:\n" +
             "Index    : {}\n".format(ridx) +
             "ID       : {}\n".format(rqst['rqstid']) +
             "Category : {}\n".format(rstr) +
             "Status   : {}\n".format(self.request_status(rqst['status'])) +
             "Dataset  : {}\n".format(dsid) +
             "Title    : {}\n".format(drec['title']) +
             "Email    : {}\n".format(rqst['email']) +
             "Date     : {}\n".format(rqst['date_rqst']) +
             "Time     : {}\n".format(rqst['time_rqst']))
      if 'data_format' in rqst and rqst['data_format']: buf += "Format   : {}\n".format(rqst['data_format'])
      if 'file_format' in rqst and rqst['file_format']: buf += "Compress : {}\n".format(rqst['file_format'])
      if 'note' in rqst and rqst['note']:
         desc = rqst['note']
      elif 'rinfo' in rqst and rqst['rinfo']:
         desc = rqst['rinfo']
      else:
         desc = None
      if desc: buf += "\nRequest Detail:\n{}\n".format(self.break_long_string(desc))
      if 'fcount' in rqst and rqst['fcount'] and 'size_input' in rqst and rqst['size_input']:
         s = 's' if rqst['fcount'] > 1 else ''
         buf += "\nTotal {} file{} ({}) requested.\n".format(rqst['fcount'], s, self.format_float_value(rqst['size_input']))
      return buf

   def send_request_email(self, rqst, msg, logact):
      """Email request information to the specialist and optional CC recipients.

      Args:
         rqst: Request record dictionary.
         msg: Request summary message string.
         logact: Logging action flag.
      """
      pgctl = self.get_rqst_control(rqst['dsid'], rqst['gindex'], rqst['rqsttype'], logact)
      if not pgctl or pgctl.get('ccemail', None) == 'N': return
      ridx = rqst['rindex']
      dsid = rqst['dsid']
      rstr = self.request_type(rqst['rqsttype'])
      sender = "gdexdata@ucar.edu"
      receiver = rqst['specialist'] + "@ucar.edu"
      ccemail = pgctl.get('ccemail', None)
      if ccemail:
         ccemails = []
         emails = re.split(r'[,\s]+', ccemail)
         for email in emails:
            if email == 'S':
               continue # specialist already in 'To' field
            elif not re.search(r'@', email):
               ccemails.append(email + "@ucar.edu")
            elif re.match(r'^.+@.+\.\w+$', email):
               ccemails.append(email)
            else:
               self.pglog(f"{email}: invalid email address in request control record", logact|self.WARNLG)
         if ccemails:
            ccemail = ', '.join(ccemails)
         else:
            ccemail = None
      subject = f"{rstr} Request '{ridx}' from dataset {dsid}"
      uname = f"{rqst['email']}"
      if 'fromflag' in rqst and rqst['fromflag'] == "W":
         method = "GDEX web interface"
      elif 'fromflag' in rqst and rqst['fromflag'] == "A":
         method = "gdex_client API"
      else:
         method = "command line"
      header = (f"A {rstr} request (request index {ridx}) has been submitted for dataset {dsid} " +
                f"by {uname} from the {method}. A summary of the request information is given below.\n\n The request is currently ")
      if rqst['status'] == "Q":
         header += ("granted and queued for processing. An email notice will be sent " +
                    f"to you and {uname} when the requested data are ready.\n\n")
      else:
         header += ("waiting your approval:\n\n" +
                    "  * To grant this Request, you may issue the " +
                    f"command 'dsrqst sr -ri {ridx} -rs Q' to put this request in queue.\n\n" +
                    f"  * To decline this request, run the command 'dsrqst dl -ri {ridx}' to " +
                    "remove the request from RDADB and please, for courtsey, reply to " +
                    f"the user at {uname} to explain why this request is refused.\n\n")
      logmsg = f"Email {receiver}"
      email_msg = EmailMessage()
      email_msg['Subject'] = subject
      email_msg['From'] = sender
      email_msg['To'] = receiver
      if ccemail:
         email_msg['Cc'] = ccemail
         logmsg += f", CC: {ccemail}"
      email_msg.set_content(header + msg)
      logmsg += f", Subject: {subject}\n"
      try:
         with smtplib.SMTP(self.PGLOG['EMLSRVR'], self.PGLOG['EMLPORT']) as smtp:
            smtp.send_message(email_msg)
      except Exception as e:
         self.pglog(f"Failed to send email to {receiver} for request {ridx}:\n{e}\n{logmsg}", (logact|self.ERRLOG)&~self.EXITLG)

   def get_rqst_control(self, dsid, gindex, rtype, logact):
      """Get the request control record for a request.

      Searches for matching control record by dataset, group, and request type,
      traversing parent groups if no match found at the current level.

      Args:
         dsid: Dataset ID string.
         gindex: Group index (0 if no group).
         rtype: Request type character.
         logact: Logging action flag.

      Returns:
         Control record dictionary, or None if not found.
      """
      gcnd = f"dsid = '{dsid}' AND gindex = {gindex}"
      if rtype == "T" or rtype == "S":
         tcnd = " AND (rqsttype = 'T' OR rqsttype = 'S')"
         ocnd = " ORDER BY rqsttype DESC"
      else:
         tcnd = f" AND rqsttype = '{rtype}'"
         ocnd = ""
      i = 0
      while True:
         cnd = gcnd + tcnd + ocnd
         pgctl = self.pgget("rcrqst", "*", cnd, logact)
         if not pgctl:
            if gindex:
               pgrec = self.pgget("dsgroup", "pindex", gcnd, logact)
               if pgrec:
                  gindex = pgrec['pindex']
                  gcnd = "dsid = '{}' AND gindex = {}".format(dsid, gindex)
                  i += 1
                  continue
            elif i == 0:
               if ocnd:
                  ocnd += ", gindex"
               else:
                  ocnd = " ORDER BY gindex"
               gcnd = "dsid = '{}'".format(dsid)
               i += 1
               continue
            return None
         break
      return pgctl

   def return_request_message(self, rqst, success, logact):
      """Create and return the response message for a request submission.

      Args:
         rqst: Request record dictionary.
         success: 1 if request was submitted successfully, 0 if duplicate.
         logact: Logging action flag.

      Returns:
         String message for command-line callers, or dictionary for web callers.
      """
      ridx = rqst['rindex']
      dsid = rqst['dsid']
      rstr = self.request_type(rqst['rqsttype'])
      title  = "{} Request {}".format(rstr, ridx)
      name = rqst['specialist']
      email = name + "@ucar.edu"
      rec = self.pgget("dssgrp", "lstname, fstname", "logname = '{}'".format(name), logact)
      if rec: name = "{} {}".format(rec['fstname'], rec['lstname'])
      error = None
      msg = "{}:\n\nYour {} request has been ".format(title, rstr)
      if success:
         msg += ("submitted successfully.\nA summary of your request is given below.\n\n" +
                 "Your request will be processed soon. You will be informed via email\n" +
                 "when the data are ready to be downloaded.\n" +
                 "\nYou may check the progress of your request in your User Dashboard " +
                 "online at\n{}/dashboard/\n".format(self.PGLOG['DSSURL']) +
                 "under the 'Customized Data Requests' section.")
      else:
         msg += ("DECLINED since you have submitted\na duplicate request as " +
                 "in the summary shown below.\n")
         if rqst['status'] == "O":
            msg += ("\nYour previous Request {} is available under\n" +
                    "{} until {}.\n".format(rqst['rindex'], rqst['location'], rqst['date_purge']))
         error = "Duplicate Request"
      msg += ("\nIf the information is CORRECT no further action is needed.\n" +
              "If the information is NOT CORRECT, or if you have additional comments\n" +
              "you may send an email to {} ({}) with questions or comments.\n\n".format(email, name))
      if 'fromflag' in rqst and rqst['fromflag'] == "W":
         # return a dictionary array if from web request
         response_msg = {
            'message': msg,
            'data': {
               'rindex': ridx,
               'rstr': rstr,
               'title': title,
            }
         }
         if error: response_msg['error'] = {
            'code': 'duplicate_request',
            'message': error
            }
         return response_msg
      else:
         # return a string message if from command line or other
         return msg

   def rda_request_status(self, ridx = 0, email = None, logact = None):
      """Get expanded request status information by request index or email.

      Args:
         ridx: Request index (integer or string with request ID).
         email: User email address to look up requests.
         logact: Logging action flag, defaults to ERRLOG.

      Returns:
         Tuple of (count, records_dictionary) with request status information.
      """
      if logact is None: logact = self.ERRLOG
      if ridx and not isinstance(ridx, int):
         ms = re.match(r'^\D+(\d+)$', ridx)
         if ms:
            ridx = int(ms.group(1))
         elif re.match(r'^.+@.+\.\w+$', ridx):
            email = ridx
            ridx = 0
         else:
            ridx = int(ridx)
      if ridx:
         cnd = "rindex = {}".format(ridx)
      elif email:
         cnd = "email = '{}' ORDER BY rindex".format(email)
      else:
         self.pglog(self.USG, self.WARNLG)
         return (0, None)
      pgrecs = self.pgmget("dsrqst", "*", cnd, logact)
      if pgrecs:
         cnt = len(pgrecs['rindex'])
         if cnt > 0: pgrecs['status'] = self.get_request_status(pgrecs)
      else:
         cnt = 0
      return (cnt, pgrecs)

   def initialize_ptcount(self, pgrqst):
      """Initialize partition count based on file count and size limits.

      Args:
         pgrqst: Request record dictionary.

      Returns:
         0 if partitioning will be set dynamically later, 1 if no further partitioning needed.
      """
      if self.PTLIMIT:
         fcount = 0
         if 'fcount' in pgrqst and pgrqst['fcount']: fcount = pgrqst['fcount']
         if not fcount or fcount > self.PTLIMIT: return 0
      elif self.PTSIZE:
         fsize = 0
         if 'size_input' in pgrqst and  pgrqst['size_input']:
            fsize = pgrqst['size_input']
         elif 'size_request' in pgrqst and  pgrqst['size_request']:
            fsize = pgrqst['size_request']
         if not fsize or fsize > self.PTSIZE: return 0
      return 1
