# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
# auto-generated at build time — do not edit
BUILD_COMMIT = "9c14435"
BUILD_COMMIT_FULL = "9c144350864eda94eef7088e831461a76afdfa60"
BUILD_BRANCH = "dev"
BUILD_TAG = "v0.3.6"
BUILD_DIRTY = False
BUILD_TIMESTAMP = "2026-04-22T23:39:04Z"
