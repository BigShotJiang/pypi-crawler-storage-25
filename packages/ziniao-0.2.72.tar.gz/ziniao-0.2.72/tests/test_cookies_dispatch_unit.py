"""Unit tests for cookies list dispatch (raw CDP path)."""

from __future__ import annotations

from typing import Any
from unittest.mock import MagicMock

import pytest

from ziniao_mcp.cli import dispatch
from ziniao_mcp.core import cdp_raw


@pytest.mark.asyncio
async def test_cookies_list_uses_raw_cdp_truncates_value(monkeypatch: pytest.MonkeyPatch) -> None:
    long_val = "x" * 150

    async def fake_get(
        _port: int, _url: str, *, timeout: float = 10.0
    ) -> list[dict[str, Any]]:
        assert timeout == 10.0
        return [
            {
                "name": "a",
                "value": long_val,
                "domain": "d.com",
                "path": "/",
                "secure": True,
                "httpOnly": False,
                "sameSite": "",
            },
            {
                "name": "b",
                "value": "short",
                "domain": "d.com",
                "path": "/p",
                "secure": False,
                "httpOnly": True,
                "sameSite": "Lax",
            },
        ]

    monkeypatch.setattr(cdp_raw, "get_cookies_for_url", fake_get)

    tab = MagicMock()
    tab.target.url = "https://d.com/app"
    store = MagicMock()
    store.cdp_port = 12345
    sm = MagicMock()
    sm.get_active_tab.return_value = tab
    sm.get_active_session.return_value = store

    r = await dispatch._cookies(sm, {"action": "list"})
    assert r.get("ok") is True
    assert r.get("cookie_source") == "raw_cdp_network"
    cookies = r.get("cookies") or []
    assert len(cookies) == 2
    assert cookies[0]["name"] == "a"
    assert cookies[0]["value"] == "x" * 100
    assert cookies[1]["value"] == "short"


@pytest.mark.asyncio
async def test_cookies_list_raw_cdp_error(monkeypatch: pytest.MonkeyPatch) -> None:
    async def fake_raise(
        _port: int, _url: str, *, timeout: float = 10.0
    ) -> list[dict[str, Any]]:
        raise TimeoutError("raw CDP Network.getCookies timed out after 10s")

    monkeypatch.setattr(cdp_raw, "get_cookies_for_url", fake_raise)

    tab = MagicMock()
    tab.target.url = "https://x.com/"
    store = MagicMock()
    store.cdp_port = 9999
    sm = MagicMock()
    sm.get_active_tab.return_value = tab
    sm.get_active_session.return_value = store

    r = await dispatch._cookies(sm, {"action": "list"})
    assert r.get("ok") is not True
    err = str(r.get("error") or "")
    assert "cookie list (raw CDP)" in err
    assert "timed out" in err
