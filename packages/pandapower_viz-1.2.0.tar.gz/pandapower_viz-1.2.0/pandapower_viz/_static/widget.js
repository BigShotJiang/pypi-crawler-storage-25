const q = {
  // Element types
  bus: "#60a5fa",
  ext_grid: "#fbbf24",
  load: "#f87171",
  sgen: "#4ade80",
  gen: "#facc15",
  line: "#94a3b8",
  trafo: "#a78bfa",
  switch_closed: "#9ca3af",
  switch_open: "#ef4444",
  solar: "#fbbf24",
  wind: "#38bdf8",
  storage: "#22c55e",
  // Interactive states
  highlight: "#22d3ee",
  hover: "#38bdf8"
}, nv = /* @__PURE__ */ new Map();
function Wr(i) {
  let e = nv.get(i);
  return e || (e = "data:image/svg+xml," + encodeURIComponent(i), nv.set(i, e)), e;
}
function BS(i) {
  return Wr(
    `<svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 22 22"><line x1="11" y1="1" x2="11" y2="7" stroke="${i}" stroke-width="2"/><line x1="3" y1="7" x2="19" y2="7" stroke="${i}" stroke-width="2"/><line x1="5" y1="11" x2="17" y2="11" stroke="${i}" stroke-width="1.5"/><line x1="7.5" y1="15" x2="14.5" y2="15" stroke="${i}" stroke-width="1.2"/><line x1="9.5" y1="19" x2="12.5" y2="19" stroke="${i}" stroke-width="1"/></svg>`
  );
}
function LS(i) {
  return Wr(
    `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20"><circle cx="10" cy="10" r="8.5" fill="none" stroke="${i}" stroke-width="1.5"/><text x="10" y="14" text-anchor="middle" font-family="STIX Two Text, serif" font-size="10" font-weight="bold" fill="${i}">G</text></svg>`
  );
}
function jS(i) {
  return Wr(
    `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="20" viewBox="0 0 16 20"><line x1="8" y1="0" x2="8" y2="6" stroke="${i}" stroke-width="1.5"/><polygon points="2,6 14,6 8,19" fill="${i}"/></svg>`
  );
}
function ov(i) {
  return Wr(
    `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16"><circle cx="8" cy="8" r="6.5" fill="none" stroke="${i}" stroke-width="2"/></svg>`
  );
}
function zS(i) {
  return Wr(
    `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20"><circle cx="10" cy="10" r="8.5" fill="none" stroke="${i}" stroke-width="1.5"/><circle cx="10" cy="10" r="3" fill="${i}"/><line x1="10" y1="2.5" x2="10" y2="5" stroke="${i}" stroke-width="1.2"/><line x1="10" y1="15" x2="10" y2="17.5" stroke="${i}" stroke-width="1.2"/><line x1="2.5" y1="10" x2="5" y2="10" stroke="${i}" stroke-width="1.2"/><line x1="15" y1="10" x2="17.5" y2="10" stroke="${i}" stroke-width="1.2"/><line x1="4.7" y1="4.7" x2="6.2" y2="6.2" stroke="${i}" stroke-width="1"/><line x1="13.8" y1="13.8" x2="15.3" y2="15.3" stroke="${i}" stroke-width="1"/><line x1="4.7" y1="15.3" x2="6.2" y2="13.8" stroke="${i}" stroke-width="1"/><line x1="13.8" y1="6.2" x2="15.3" y2="4.7" stroke="${i}" stroke-width="1"/></svg>`
  );
}
function WS(i) {
  return Wr(
    `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20"><circle cx="10" cy="10" r="8.5" fill="none" stroke="${i}" stroke-width="1.5"/><text x="10" y="14" text-anchor="middle" font-family="STIX Two Text, serif" font-size="12" fill="${i}">~</text></svg>`
  );
}
function HS(i) {
  return Wr(
    `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20"><circle cx="10" cy="10" r="8.5" fill="none" stroke="${i}" stroke-width="1.5"/><line x1="10" y1="16" x2="10" y2="5" stroke="${i}" stroke-width="1.5"/><polyline points="6.5,9 10,5 13.5,9" fill="none" stroke="${i}" stroke-width="1.5"/></svg>`
  );
}
function VS(i) {
  return Wr(
    `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18"><line x1="9" y1="0" x2="9" y2="5" stroke="${i}" stroke-width="1.2"/><line x1="9" y1="13" x2="9" y2="18" stroke="${i}" stroke-width="1.2"/><line x1="3" y1="5" x2="15" y2="5" stroke="${i}" stroke-width="2.5"/><line x1="5" y1="9" x2="13" y2="9" stroke="${i}" stroke-width="1.2"/><line x1="3" y1="13" x2="15" y2="13" stroke="${i}" stroke-width="2.5"/></svg>`
  );
}
function wt(i) {
  if (!i || typeof i != "object")
    return {};
  const e = i;
  if ("_object" in e) {
    let t;
    if (typeof e._object == "string")
      try {
        t = JSON.parse(e._object);
      } catch {
        return {};
      }
    else
      t = e._object;
    return wt(t);
  }
  if ("columns" in e && "index" in e && "data" in e) {
    const t = e.columns, r = e.index, n = e.data, o = {};
    for (let s = 0; s < r.length; s++) {
      const a = { index: r[s] };
      for (let l = 0; l < t.length; l++)
        a[t[l]] = n[s][l];
      o[String(r[s])] = a;
    }
    return o;
  }
  return {};
}
function US(i) {
  return "_object" in i && i._object && typeof i._object == "object" ? i._object : i;
}
function GS(i) {
  const e = i, t = US(e);
  return {
    bus: wt(t.bus),
    line: wt(t.line),
    trafo: wt(t.trafo),
    load: wt(t.load),
    sgen: wt(t.sgen),
    gen: wt(t.gen),
    switch: wt(t.switch),
    ext_grid: wt(t.ext_grid),
    storage: wt(t.storage),
    res_bus: t.res_bus ? wt(t.res_bus) : void 0,
    res_line: t.res_line ? wt(t.res_line) : void 0,
    name: t.name || e.name || void 0,
    f_hz: t.f_hz || e.f_hz || void 0,
    sn_mva: t.sn_mva || e.sn_mva || void 0
  };
}
function KS(i) {
  const e = [], t = [], r = /* @__PURE__ */ new Set();
  return Object.values(i.ext_grid).forEach((n) => {
    r.add(n.bus);
  }), Object.entries(i.bus).forEach(([n, o]) => {
    const s = typeof o.index == "number" ? o.index : parseInt(n), a = r.has(s), l = o.name || o.agui_cod || `Bus ${s}`, d = `
      <b>Bus ${s}</b><br/>
      Name: ${l}<br/>
      Voltage: ${o.vn_kv} kV<br/>
      Type: ${o.type || "N/A"}
    `, h = a ? q.ext_grid : q.bus;
    e.push({
      id: s,
      label: String(s),
      title: d,
      color: h,
      shape: a ? "image" : "dot",
      size: a ? 10 : 6,
      borderWidth: a ? 0 : 1,
      font: { color: "#fef6e9" },
      type: a ? "ext_grid" : "bus",
      data: o,
      image: a ? BS(h) : void 0
    });
  }), Object.entries(i.load).forEach(([n, o]) => {
    const s = typeof o.index == "number" ? o.index : parseInt(n);
    if (o.in_service === !1 || !i.bus[String(o.bus)]) return;
    const a = `
      <b>Load ${s}</b><br/>
      Bus: ${o.bus}<br/>
      P: ${(o.p_mw || 0).toFixed(3)} MW<br/>
      Q: ${(o.q_mvar || 0).toFixed(3)} MVAr
    `;
    e.push({
      id: `load_${s}`,
      label: String(s),
      title: a,
      color: q.load,
      shape: "image",
      size: 10,
      borderWidth: 0,
      font: { color: "#fef6e9" },
      type: "load",
      data: o,
      image: jS(q.load)
    }), t.push({
      id: `load_conn_${s}`,
      from: o.bus,
      to: `load_${s}`,
      label: "",
      title: "",
      color: { color: q.load, highlight: q.load },
      width: 1,
      dashes: !1,
      type: "line",
      data: o
    });
  }), Object.entries(i.sgen).forEach(([n, o]) => {
    const s = typeof o.index == "number" ? o.index : parseInt(n);
    if (o.in_service === !1 || !i.bus[String(o.bus)]) return;
    const a = o.type || "";
    let l = q.sgen, d = "Static Gen";
    a === "PV" ? (l = q.solar, d = "Solar PV") : a === "WP" && (l = q.wind, d = "Wind");
    const h = `
      <b>${d} ${s}</b><br/>
      Bus: ${o.bus}<br/>
      P: ${(o.p_mw || 0).toFixed(3)} MW<br/>
      Q: ${(o.q_mvar || 0).toFixed(3)} MVAr
      ${o.name ? `<br/>Name: ${o.name}` : ""}
    `;
    let c;
    a === "PV" ? c = zS(l) : a === "WP" ? c = WS(l) : c = HS(l), e.push({
      id: `sgen_${s}`,
      label: String(s),
      title: h,
      color: l,
      shape: "image",
      size: 10,
      borderWidth: 0,
      font: { color: "#fef6e9" },
      type: "sgen",
      data: o,
      image: c
    }), t.push({
      id: `sgen_conn_${s}`,
      from: o.bus,
      to: `sgen_${s}`,
      label: "",
      title: "",
      color: { color: l, highlight: l },
      width: 1,
      dashes: !1,
      type: "line",
      data: o
    });
  }), Object.entries(i.gen).forEach(([n, o]) => {
    const s = typeof o.index == "number" ? o.index : parseInt(n);
    if (o.in_service === !1 || !i.bus[String(o.bus)]) return;
    const a = `
      <b>Generator ${s}</b><br/>
      Bus: ${o.bus}<br/>
      P: ${(o.p_mw || 0).toFixed(3)} MW<br/>
      Vm: ${(o.vm_pu || 0).toFixed(3)} pu
    `;
    e.push({
      id: `gen_${s}`,
      label: String(s),
      title: a,
      color: q.gen,
      shape: "image",
      size: 12,
      borderWidth: 0,
      font: { color: "#fef6e9" },
      type: "gen",
      data: o,
      image: LS(q.gen)
    }), t.push({
      id: `gen_conn_${s}`,
      from: o.bus,
      to: `gen_${s}`,
      label: "",
      title: "",
      color: { color: q.gen, highlight: q.gen },
      width: 1,
      dashes: !1,
      type: "line",
      data: o
    });
  }), Object.entries(i.storage).forEach(([n, o]) => {
    const s = typeof o.index == "number" ? o.index : parseInt(n);
    if (o.in_service === !1 || !i.bus[String(o.bus)]) return;
    const a = o.soc_percent || 0, l = `
      <b>Battery Storage ${s}</b><br/>
      Bus: ${o.bus}<br/>
      P: ${(o.p_mw || 0).toFixed(3)} MW<br/>
      Capacity: ${(o.max_e_mwh || 0).toFixed(1)} MWh<br/>
      Max Power: ${(o.max_p_mw || 0).toFixed(1)} MW<br/>
      SoC: ${a.toFixed(1)}%
      ${o.name ? `<br/>Name: ${o.name}` : ""}
    `;
    e.push({
      id: `storage_${s}`,
      label: String(s),
      title: l,
      color: q.storage,
      shape: "image",
      size: 10,
      borderWidth: 0,
      font: { color: "#fef6e9" },
      type: "storage",
      data: o,
      image: VS(q.storage)
    }), t.push({
      id: `storage_conn_${s}`,
      from: o.bus,
      to: `storage_${s}`,
      label: "",
      title: "",
      color: { color: q.storage, highlight: q.storage },
      width: 1,
      dashes: !1,
      type: "line",
      data: o
    });
  }), Object.entries(i.line).forEach(([n, o]) => {
    var c, u, f;
    const s = typeof o.index == "number" ? o.index : parseInt(n), a = o.from_bus, l = o.to_bus;
    if (!i.bus[String(a)] || !i.bus[String(l)])
      return;
    const d = (u = (c = i.res_line) == null ? void 0 : c[n]) == null ? void 0 : u.loading_percent, h = `
      <b>Line ${s}</b><br/>
      From: Bus ${a}<br/>
      To: Bus ${l}<br/>
      Length: ${((f = o.length_km) == null ? void 0 : f.toFixed(3)) || "N/A"} km<br/>
      Max I: ${o.max_i_ka || "N/A"} kA
      ${d !== void 0 ? `<br/>Loading: ${d.toFixed(1)}%` : ""}
    `;
    t.push({
      id: `line_${s}`,
      from: a,
      to: l,
      label: String(s),
      title: h,
      color: {
        color: q.line,
        highlight: "#5f787d"
      },
      width: 1,
      dashes: o.in_service === !1,
      type: "line",
      data: o
    });
  }), Object.entries(i.trafo).forEach(([n, o]) => {
    const s = typeof o.index == "number" ? o.index : parseInt(n), a = o.hv_bus, l = o.lv_bus;
    if (!i.bus[String(a)] || !i.bus[String(l)])
      return;
    const d = `
      <b>Transformer ${s}</b><br/>
      HV Bus: ${a} (${o.vn_hv_kv} kV)<br/>
      LV Bus: ${l} (${o.vn_lv_kv} kV)<br/>
      Rating: ${o.sn_mva || "N/A"} MVA
      ${o.tap_pos !== void 0 ? `<br/>Tap: ${o.tap_pos}` : ""}
    `, h = `trafo_${s}_w1`, c = `trafo_${s}_w2`;
    e.push({
      id: h,
      label: "",
      title: d,
      color: q.trafo,
      shape: "image",
      size: 10,
      borderWidth: 0,
      font: { color: "#fef6e9" },
      type: "trafo",
      data: o,
      image: ov(q.trafo)
    }), e.push({
      id: c,
      label: "",
      title: d,
      color: q.trafo,
      shape: "image",
      size: 10,
      borderWidth: 0,
      font: { color: "#fef6e9" },
      type: "trafo",
      data: o,
      image: ov(q.trafo)
    }), t.push({
      id: `trafo_${s}_hv`,
      from: a,
      to: h,
      label: "",
      title: d,
      color: { color: q.trafo, highlight: "#5f787d" },
      width: 2,
      dashes: o.in_service === !1,
      type: "trafo",
      data: o
    }), t.push({
      id: `trafo_${s}_mid`,
      from: h,
      to: c,
      label: "",
      title: d,
      color: { color: q.trafo, highlight: "#5f787d" },
      width: 2,
      dashes: o.in_service === !1,
      type: "trafo",
      data: o
    }), t.push({
      id: `trafo_${s}_lv`,
      from: c,
      to: l,
      label: "",
      title: d,
      color: { color: q.trafo, highlight: "#5f787d" },
      width: 2,
      dashes: o.in_service === !1,
      type: "trafo",
      data: o
    });
  }), Object.entries(i.switch).forEach(([n, o]) => {
    if (o.et !== "b") return;
    const s = typeof o.index == "number" ? o.index : parseInt(n), a = o.bus, l = o.element;
    if (!i.bus[String(a)] || !i.bus[String(l)])
      return;
    const d = `
      <b>Switch ${s}</b><br/>
      Bus: ${a}<br/>
      Element: ${l}<br/>
      Type: ${o.type || "N/A"}<br/>
      State: ${o.closed ? "CLOSED" : "OPEN"}
    `, h = o.closed ? q.switch_closed : q.switch_open;
    t.push({
      id: `switch_${s}`,
      from: a,
      to: l,
      label: String(s),
      title: d,
      color: { color: h, highlight: "#5f787d" },
      width: 2,
      dashes: !0,
      type: "switch",
      data: o
    });
  }), { nodes: e, edges: t };
}
function YS(i) {
  const e = /* @__PURE__ */ new Map(), t = (r) => {
    let n = e.get(r);
    return n || (n = { hasLoad: !1, hasGen: !1, hasExtGrid: !1, totalLoadMW: 0, totalGenMW: 0, loadCount: 0, genCount: 0 }, e.set(r, n)), n;
  };
  return Object.values(i.load).forEach((r) => {
    if (r.in_service === !1) return;
    const n = t(r.bus);
    n.hasLoad = !0, n.totalLoadMW += r.p_mw || 0, n.loadCount++;
  }), Object.values(i.gen).forEach((r) => {
    if (r.in_service === !1) return;
    const n = t(r.bus);
    n.hasGen = !0, n.totalGenMW += r.p_mw || 0, n.genCount++;
  }), Object.values(i.sgen).forEach((r) => {
    if (r.in_service === !1) return;
    const n = t(r.bus);
    n.hasGen = !0, n.totalGenMW += r.p_mw || 0, n.genCount++;
  }), Object.values(i.ext_grid).forEach((r) => {
    r.in_service !== !1 && (t(r.bus).hasExtGrid = !0);
  }), e;
}
function qS(i) {
  const e = [], t = [], r = YS(i);
  return Object.entries(i.bus).forEach(([n, o]) => {
    const s = typeof o.index == "number" ? o.index : parseInt(n), a = r.get(s), l = o.name || o.agui_cod || `Bus ${s}`;
    let d = q.bus;
    a != null && a.hasExtGrid ? d = "#fbbf24" : a != null && a.hasGen && (a != null && a.hasLoad) ? d = "#2dd4bf" : a != null && a.hasGen ? d = "#4ade80" : a != null && a.hasLoad && (d = "#fb923c");
    const h = ((a == null ? void 0 : a.totalLoadMW) || 0) + ((a == null ? void 0 : a.totalGenMW) || 0), c = Math.max(4, Math.min(12, 5 + Math.log10(Math.max(1, h)))), u = `<b>Bus ${s}</b><br/>Name: ${l}<br/>Voltage: ${o.vn_kv} kV` + (a ? `<br/>Loads: ${a.loadCount} (${a.totalLoadMW.toFixed(1)} MW)<br/>Gens: ${a.genCount} (${a.totalGenMW.toFixed(1)} MW)` : "");
    e.push({
      id: s,
      label: String(s),
      title: u,
      color: d,
      shape: "dot",
      size: c,
      borderWidth: a != null && a.hasExtGrid ? 3 : 1,
      font: { color: "#fef6e9" },
      type: a != null && a.hasExtGrid ? "ext_grid" : "bus",
      data: o
    });
  }), Object.entries(i.line).forEach(([n, o]) => {
    const s = typeof o.index == "number" ? o.index : parseInt(n);
    !i.bus[String(o.from_bus)] || !i.bus[String(o.to_bus)] || t.push({
      id: `line_${s}`,
      from: o.from_bus,
      to: o.to_bus,
      label: "",
      title: `Line ${s}: Bus ${o.from_bus} → Bus ${o.to_bus}`,
      color: { color: q.line, highlight: "#5f787d" },
      width: 1,
      dashes: o.in_service === !1,
      type: "line",
      data: o
    });
  }), Object.entries(i.trafo).forEach(([n, o]) => {
    const s = typeof o.index == "number" ? o.index : parseInt(n);
    !i.bus[String(o.hv_bus)] || !i.bus[String(o.lv_bus)] || t.push({
      id: `trafo_${s}`,
      from: o.hv_bus,
      to: o.lv_bus,
      label: "",
      title: `Trafo ${s}: ${o.vn_hv_kv}/${o.vn_lv_kv} kV, ${o.sn_mva} MVA`,
      color: { color: q.trafo, highlight: "#5f787d" },
      width: 2,
      dashes: o.in_service === !1,
      type: "trafo",
      data: o
    });
  }), Object.entries(i.switch).forEach(([n, o]) => {
    if (o.et !== "b") return;
    const s = typeof o.index == "number" ? o.index : parseInt(n);
    if (!i.bus[String(o.bus)] || !i.bus[String(o.element)]) return;
    const a = o.closed ? q.switch_closed : q.switch_open;
    t.push({
      id: `switch_${s}`,
      from: o.bus,
      to: o.element,
      label: "",
      title: `Switch ${s}: ${o.closed ? "CLOSED" : "OPEN"}`,
      color: { color: a, highlight: "#5f787d" },
      width: 2,
      dashes: !0,
      type: "switch",
      data: o
    });
  }), { nodes: e, edges: t, busAnnotations: r };
}
function XS(i, e, t) {
  var a, l, d;
  const r = e.bus[String(i)], n = t.get(i), o = {}, s = r;
  if (o.Index = i, o.Name = (r == null ? void 0 : r.name) || (s == null ? void 0 : s.agui_cod) || "N/A", o["Voltage Level (kV)"] = (r == null ? void 0 : r.vn_kv) || "N/A", o.Type = (r == null ? void 0 : r.type) || "N/A", o["In Service"] = (r == null ? void 0 : r.in_service) !== !1, s != null && s.agui_cod && (o["AGUI Code"] = s.agui_cod), n && (n.loadCount > 0 && (o["Connected Loads"] = n.loadCount, o["Total Load (MW)"] = n.totalLoadMW.toFixed(2)), n.genCount > 0 && (o["Connected Generators"] = n.genCount, o["Total Generation (MW)"] = n.totalGenMW.toFixed(2)), n.hasExtGrid && (o["External Grid"] = !0)), (a = e.res_bus) != null && a[i]) {
    const h = e.res_bus[i];
    o["Vm (pu)"] = ((l = h.vm_pu) == null ? void 0 : l.toFixed(4)) || "N/A", o["Va (degree)"] = ((d = h.va_degree) == null ? void 0 : d.toFixed(2)) || "N/A";
  }
  return {
    type: n != null && n.hasExtGrid ? "External Grid Bus" : "Bus",
    id: i,
    name: (r == null ? void 0 : r.name) || (s == null ? void 0 : s.agui_cod) || `Bus ${i}`,
    properties: o
  };
}
function sv(i, e) {
  var r, n, o, s, a, l, d, h, c;
  const t = {};
  if ("shape" in i) {
    const u = i, f = String(u.id);
    if (f.startsWith("load_")) {
      const g = f.replace("load_", ""), p = e.load[g];
      if (p)
        return t.Index = p.index, t.Bus = p.bus, t["P (MW)"] = (p.p_mw || 0).toFixed(4), t["Q (MVAr)"] = (p.q_mvar || 0).toFixed(4), t["In Service"] = p.in_service !== !1, { type: "Load", id: p.index, name: `Load ${p.index}`, properties: t };
    }
    if (f.startsWith("sgen_")) {
      const g = f.replace("sgen_", ""), p = e.sgen[g];
      if (p) {
        let m = "Static Generator";
        return p.type === "PV" ? m = "Solar PV Plant" : p.type === "WP" && (m = "Wind Farm"), t.Index = p.index, t.Bus = p.bus, t["P (MW)"] = (p.p_mw || 0).toFixed(4), t["Q (MVAr)"] = (p.q_mvar || 0).toFixed(4), p.type && (t.Type = p.type), p.name && (t.Name = p.name), t["In Service"] = p.in_service !== !1, { type: m, id: p.index, name: p.name || `SGen ${p.index}`, properties: t };
      }
    }
    if (f.startsWith("storage_")) {
      const g = f.replace("storage_", ""), p = e.storage[g];
      if (p)
        return t.Index = p.index, t.Bus = p.bus, t["P (MW)"] = (p.p_mw || 0).toFixed(4), t["Capacity (MWh)"] = (p.max_e_mwh || 0).toFixed(2), t["Max Power (MW)"] = (p.max_p_mw || 0).toFixed(2), t["Min Power (MW)"] = (p.min_p_mw || 0).toFixed(2), t["State of Charge (%)"] = (p.soc_percent || 0).toFixed(1), p.name && (t.Name = p.name), t["In Service"] = p.in_service !== !1, { type: "Battery Storage", id: p.index, name: p.name || `BESS ${p.index}`, properties: t };
    }
    if (f.startsWith("gen_")) {
      const g = f.replace("gen_", ""), p = e.gen[g];
      if (p)
        return t.Index = p.index, t.Bus = p.bus, t["P (MW)"] = (p.p_mw || 0).toFixed(4), t["Vm (pu)"] = (p.vm_pu || 0).toFixed(4), t["In Service"] = p.in_service !== !1, { type: "Generator", id: p.index, name: `Gen ${p.index}`, properties: t };
    }
    if (f.startsWith("trafo_")) {
      const g = f.replace("trafo_", "").replace("_w1", "").replace("_w2", ""), p = e.trafo[g];
      if (p)
        return t.Index = p.index, t["HV Bus"] = p.hv_bus, t["LV Bus"] = p.lv_bus, t["Rating (MVA)"] = p.sn_mva || "N/A", t["HV (kV)"] = p.vn_hv_kv || "N/A", t["LV (kV)"] = p.vn_lv_kv || "N/A", p.tap_pos !== void 0 && (t["Tap Position"] = p.tap_pos, t["Tap Min"] = p.tap_min || "N/A", t["Tap Max"] = p.tap_max || "N/A"), t["In Service"] = p.in_service !== !1, { type: "Transformer", id: p.index, name: `Transformer ${p.index}`, properties: t };
    }
    const v = u.data, y = v;
    if (t.Index = v.index, t.Name = v.name || y.agui_cod || "N/A", t["Voltage Level (kV)"] = v.vn_kv, t.Type = v.type || "N/A", t["In Service"] = v.in_service !== !1, y.agui_cod && (t["AGUI Code"] = y.agui_cod), (r = e.res_bus) != null && r[v.index]) {
      const g = e.res_bus[v.index];
      t["Vm (pu)"] = ((n = g.vm_pu) == null ? void 0 : n.toFixed(4)) || "N/A", t["Va (degree)"] = ((o = g.va_degree) == null ? void 0 : o.toFixed(2)) || "N/A";
    }
    return {
      type: u.type === "ext_grid" ? "External Grid Bus" : "Bus",
      id: v.index,
      name: v.name || y.agui_cod || `Bus ${v.index}`,
      properties: t
    };
  } else {
    const u = i, f = u.id;
    if (f.startsWith("load_conn_") || f.startsWith("sgen_conn_") || f.startsWith("gen_conn_"))
      return { type: "Connection", id: f, name: "Element Connection", properties: {} };
    if (f.startsWith("trafo_")) {
      const v = f.replace("trafo_", "").replace("_hv", "").replace("_mid", "").replace("_lv", ""), y = e.trafo[v];
      if (y)
        return t.Index = y.index, t["HV Bus"] = y.hv_bus, t["LV Bus"] = y.lv_bus, t["Rating (MVA)"] = y.sn_mva || "N/A", t["HV (kV)"] = y.vn_hv_kv || "N/A", t["LV (kV)"] = y.vn_lv_kv || "N/A", y.tap_pos !== void 0 && (t["Tap Position"] = y.tap_pos), t["In Service"] = y.in_service !== !1, { type: "Transformer", id: y.index, name: `Transformer ${y.index}`, properties: t };
    }
    if (f.startsWith("switch_")) {
      const v = f.replace("switch_", "").replace("_a", "").replace("_b", ""), y = e.switch[v];
      if (y)
        return t.Index = y.index, t.Bus = y.bus, t.Element = y.element, t.Type = y.type || "N/A", t.Closed = y.closed, { type: "Switch", id: y.index, name: `Switch ${y.index}`, properties: t };
    }
    if (u.type === "line") {
      const v = u.data, y = v;
      if (t.Index = v.index, t.Name = v.name || "N/A", t["From Bus"] = v.from_bus, t["To Bus"] = v.to_bus, t["Length (km)"] = ((s = v.length_km) == null ? void 0 : s.toFixed(3)) || "N/A", t["R (Ω/km)"] = ((a = v.r_ohm_per_km) == null ? void 0 : a.toFixed(4)) || "N/A", t["X (Ω/km)"] = ((l = v.x_ohm_per_km) == null ? void 0 : l.toFixed(4)) || "N/A", t["Max I (kA)"] = v.max_i_ka || "N/A", t["In Service"] = v.in_service !== !1, y.agui_cod && (t["AGUI Code"] = y.agui_cod), (d = e.res_line) != null && d[v.index]) {
        const g = e.res_line[v.index];
        t["Loading (%)"] = ((h = g.loading_percent) == null ? void 0 : h.toFixed(2)) || "N/A", t["I (kA)"] = ((c = g.i_ka) == null ? void 0 : c.toFixed(4)) || "N/A";
      }
      return { type: "Line", id: v.index, name: v.name || `Line ${v.index}`, properties: t };
    }
    return { type: "Edge", id: f, name: f, properties: {} };
  }
}
function JS(i) {
  const e = [];
  for (const t of Object.values(i.bus)) {
    if (!t.geo) continue;
    let r, n;
    const o = t.geo.match(/POINT\s*\(\s*([-\d.]+)\s+([-\d.]+)\s*\)/i);
    if (o)
      r = parseFloat(o[1]), n = parseFloat(o[2]);
    else
      try {
        const s = typeof t.geo == "string" ? t.geo : JSON.stringify(t.geo), a = JSON.parse(s);
        (a == null ? void 0 : a.type) === "Point" && Array.isArray(a.coordinates) && a.coordinates.length >= 2 && (r = a.coordinates[0], n = a.coordinates[1]);
      } catch {
      }
    r === void 0 || n === void 0 || isNaN(n) || isNaN(r) || e.push({
      bus: t.index,
      name: t.name || `Bus ${t.index}`,
      latitude: n,
      longitude: r,
      vn_kv: t.vn_kv
    });
  }
  return e;
}
const ZS = ["load_", "sgen_", "gen_", "storage_", "trafo_"];
function ni(i) {
  const e = String(i);
  return ZS.some((t) => e.startsWith(t));
}
function $a(i) {
  return !ni(i);
}
function t$(i, e, t = 5e3, r = 3e3) {
  var ce;
  const n = /* @__PURE__ */ new Map(), o = /* @__PURE__ */ new Map(), s = new Set(i.map((x) => x.id)), a = i.filter((x) => $a(x.id)), l = i.filter((x) => ni(x.id)), d = e.filter((x) => $a(x.from) && $a(x.to));
  a.forEach((x) => {
    o.set(x.id, /* @__PURE__ */ new Set());
  }), d.forEach((x) => {
    var j, D;
    s.has(x.from) && s.has(x.to) && ((j = o.get(x.from)) == null || j.add(x.to), (D = o.get(x.to)) == null || D.add(x.from));
  });
  const h = a.filter((x) => x.type === "ext_grid"), c = h.length > 0 ? h.map((x) => x.id) : [(ce = a.reduce((x, j) => {
    var R, W;
    const D = ((R = o.get(j.id)) == null ? void 0 : R.size) || 0, _ = ((W = o.get(x.id)) == null ? void 0 : W.size) || 0;
    return D > _ ? j : x;
  }, a[0])) == null ? void 0 : ce.id].filter(Boolean);
  c.length === 0 && a.length > 0 && c.push(a[0].id);
  const u = /* @__PURE__ */ new Set(), f = /* @__PURE__ */ new Map(), v = /* @__PURE__ */ new Map();
  c.forEach((x) => {
    f.set(x, []), v.set(x, 0);
  });
  const y = [...c];
  let g = 0;
  for (c.forEach((x) => u.add(x)); g < y.length; ) {
    const x = y[g++], j = v.get(x) || 0;
    (o.get(x) || /* @__PURE__ */ new Set()).forEach((_) => {
      u.has(_) || (u.add(_), v.set(_, j + 1), f.has(x) || f.set(x, []), f.get(x).push(_), f.set(_, []), y.push(_));
    });
  }
  const p = /* @__PURE__ */ new Map();
  function m(x) {
    const j = f.get(x) || [];
    if (j.length === 0)
      return p.set(x, 1), 1;
    let D = 0;
    for (const _ of j)
      D += m(_);
    return p.set(x, D), D;
  }
  c.forEach((x) => m(x));
  const $ = Math.max(0, ...Array.from(v.values())), w = r / ($ + 3), T = 100;
  function A(x, j, D) {
    const _ = v.get(x) || 0, R = T + (_ + 1) * w, W = (j + D) / 2;
    n.set(x, { x: W, y: R });
    const J = f.get(x) || [];
    if (J.length > 0) {
      const te = p.get(x) || 1, Se = D - j;
      let rt = j;
      J.forEach((zt) => {
        const $r = p.get(zt) || 1, Ri = rt + $r / te * Se;
        A(zt, rt, Ri), rt = Ri;
      });
    }
  }
  const L = c.reduce((x, j) => x + (p.get(j) || 1), 0);
  let G = T;
  const ne = t - 2 * T;
  c.forEach((x) => {
    const j = p.get(x) || 1, D = G + j / L * ne;
    A(x, G, D), G = D;
  }), a.forEach((x) => {
    u.has(x.id) || n.set(x.id, {
      x: T + Math.random() * (t - 2 * T),
      y: r - T * 2
    });
  });
  const oe = 40, Pe = /* @__PURE__ */ new Map(), pe = /* @__PURE__ */ new Map();
  return e.forEach((x) => {
    ni(x.to) && pe.set(String(x.to), x), ni(x.from) && pe.set(String(x.from), x);
  }), l.forEach((x) => {
    const j = String(x.id);
    let D = null;
    const _ = pe.get(j);
    if (_ && (D = String(_.to) === j ? _.from : _.to), D !== null && n.has(D)) {
      const R = n.get(D), W = Pe.get(D) || 0;
      Pe.set(D, W + 1);
      const J = W * Math.PI / 4 + Math.PI / 2, te = Math.cos(J) * oe, Se = Math.sin(J) * oe;
      n.set(x.id, {
        x: R.x + te,
        y: R.y + Se
      });
    } else
      n.set(x.id, {
        x: T + Math.random() * (t - 2 * T),
        y: r - T
      });
  }), n;
}
function QS(i, e, t, r = 5e3, n = 3e3) {
  const o = /* @__PURE__ */ new Map(), s = JS(t), a = 120, l = /* @__PURE__ */ new Map();
  if (s.forEach((_) => l.set(_.bus, { lat: _.latitude, lon: _.longitude })), l.size === 0)
    return t$(i, e, r, n);
  let d = 1 / 0, h = -1 / 0, c = 1 / 0, u = -1 / 0;
  l.forEach(({ lat: _, lon: R }) => {
    _ < d && (d = _), _ > h && (h = _), R < c && (c = R), R > u && (u = R);
  });
  const f = h - d || 1e-3, v = u - c || 1e-3, y = r - 2 * a, g = n - 2 * a, p = (d + h) / 2, m = Math.cos(p * Math.PI / 180), $ = v * m / f, w = y / g;
  let T, A;
  $ > w ? (T = y / v, A = T / m) : (A = g / f, T = A * m);
  const L = v * T, G = f * A, ne = a + (y - L) / 2, oe = a + (g - G) / 2, Pe = i.filter((_) => $a(_.id)), pe = i.filter((_) => ni(_.id));
  Pe.forEach((_) => {
    const R = typeof _.id == "number" ? _.id : parseInt(String(_.id), 10), W = l.get(R);
    if (W) {
      const J = ne + (W.lon - c) * T, te = oe + (h - W.lat) * A;
      o.set(_.id, { x: J, y: te });
    } else
      o.set(_.id, { x: r / 2, y: n / 2 });
  });
  const ce = /* @__PURE__ */ new Map(), x = /* @__PURE__ */ new Map();
  e.forEach((_) => {
    const R = String(_.id).match(/^trafo_(\d+)_(hv|mid|lv)$/);
    if (R) {
      const [, W, J] = R, te = ce.get(W) || {};
      J === "hv" ? (te.hv = _.from, te.w1 = _.to) : J === "mid" ? (te.w1 = _.from, te.w2 = _.to) : (te.w2 = _.from, te.lv = _.to), ce.set(W, te);
    }
    ni(_.to) && x.set(String(_.to), _), ni(_.from) && x.set(String(_.from), _);
  }), ce.forEach((_) => {
    if (_.hv && _.lv && _.w1 && _.w2) {
      const R = o.get(_.hv), W = o.get(_.lv);
      if (R && W) {
        const J = (R.x + W.x) / 2, te = (R.y + W.y) / 2, Se = W.x - R.x, rt = W.y - R.y, zt = Math.hypot(Se, rt) || 1, $r = 6;
        o.set(_.w1, { x: J - Se / zt * $r, y: te - rt / zt * $r }), o.set(_.w2, { x: J + Se / zt * $r, y: te + rt / zt * $r });
        return;
      }
    }
    if (_.hv && _.w1) {
      const R = o.get(_.hv);
      R && o.set(_.w1, { ...R });
    }
    if (_.lv && _.w2) {
      const R = o.get(_.lv);
      R && o.set(_.w2, { ...R });
    }
  });
  const j = 30, D = /* @__PURE__ */ new Map();
  return pe.forEach((_) => {
    const R = String(_.id);
    if (R.startsWith("trafo_")) return;
    let W = null;
    const J = x.get(R);
    if (J && (W = String(J.to) === R ? J.from : J.to), W !== null && o.has(W)) {
      const te = o.get(W), Se = D.get(W) || 0;
      D.set(W, Se + 1);
      const rt = Se * Math.PI / 4 + Math.PI / 2;
      o.set(_.id, {
        x: te.x + Math.cos(rt) * j,
        y: te.y + Math.sin(rt) * j
      });
    } else
      o.set(_.id, { x: a + Math.random() * y, y: n - a });
  }), o;
}
/**
 * vis-data
 * http://visjs.org/
 *
 * Manage unstructured data using DataSet. Add, update, and remove data, and listen for changes in the data.
 *
 * @version 7.1.10
 * @date    2025-07-06T08:42:20.006Z
 *
 * @copyright (c) 2011-2017 Almende B.V, http://almende.com
 * @copyright (c) 2017-2019 visjs contributors, https://github.com/visjs
 *
 * @license
 * vis.js is dual licensed under both
 *
 *   1. The Apache 2.0 License
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *   and
 *
 *   2. The MIT License
 *      http://opensource.org/licenses/MIT
 *
 * vis.js may be distributed under either license.
 */
function dl(i, e) {
  if (!(i instanceof e))
    throw new TypeError("Cannot call a class as a function");
}
var cd = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};
function z(i) {
  return i && i.__esModule && Object.prototype.hasOwnProperty.call(i, "default") ? i.default : i;
}
var r$ = { exports: {} }, Ds = function(i) {
  return i && i.Math === Math && i;
}, fe = (
  // eslint-disable-next-line es/no-global-this -- safe
  Ds(typeof globalThis == "object" && globalThis) || Ds(typeof window == "object" && window) || // eslint-disable-next-line no-restricted-globals -- safe
  Ds(typeof self == "object" && self) || Ds(typeof cd == "object" && cd) || // eslint-disable-next-line no-new-func -- fallback
  /* @__PURE__ */ function() {
    return this;
  }() || cd || Function("return this")()
), ee = function(i) {
  try {
    return !!i();
  } catch {
    return !0;
  }
}, eO = ee, Fo = !eO(function() {
  var i = (function() {
  }).bind();
  return typeof i != "function" || i.hasOwnProperty("prototype");
}), tO = Fo, i$ = Function.prototype, av = i$.apply, lv = i$.call, In = typeof Reflect == "object" && Reflect.apply || (tO ? lv.bind(av) : function() {
  return lv.apply(av, arguments);
}), n$ = Fo, o$ = Function.prototype, _c = o$.call, rO = n$ && o$.bind.bind(_c, _c), he = n$ ? rO : function(i) {
  return function() {
    return _c.apply(i, arguments);
  };
}, s$ = he, iO = s$({}.toString), nO = s$("".slice), Hr = function(i) {
  return nO(iO(i), 8, -1);
}, oO = Hr, sO = he, a$ = function(i) {
  if (oO(i) === "Function") return sO(i);
}, Ec = typeof document == "object" && document.all, aO = typeof Ec > "u" && Ec !== void 0, l$ = {
  all: Ec,
  IS_HTMLDDA: aO
}, d$ = l$, lO = d$.all, $e = d$.IS_HTMLDDA ? function(i) {
  return typeof i == "function" || i === lO;
} : function(i) {
  return typeof i == "function";
}, Si = {}, dO = ee, Le = !dO(function() {
  return Object.defineProperty({}, 1, { get: function() {
    return 7;
  } })[1] !== 7;
}), hO = Fo, ks = Function.prototype.call, je = hO ? ks.bind(ks) : function() {
  return ks.apply(ks, arguments);
}, hl = {}, h$ = {}.propertyIsEnumerable, c$ = Object.getOwnPropertyDescriptor, cO = c$ && !h$.call({ 1: 2 }, 1);
hl.f = cO ? function(e) {
  var t = c$(this, e);
  return !!t && t.enumerable;
} : h$;
var Oi = function(i, e) {
  return {
    enumerable: !(i & 1),
    configurable: !(i & 2),
    writable: !(i & 4),
    value: e
  };
}, uO = he, fO = ee, vO = Hr, ud = Object, pO = uO("".split), cl = fO(function() {
  return !ud("z").propertyIsEnumerable(0);
}) ? function(i) {
  return vO(i) === "String" ? pO(i, "") : ud(i);
} : ud, Pn = function(i) {
  return i == null;
}, gO = Pn, yO = TypeError, Cu = function(i) {
  if (gO(i)) throw new yO("Can't call method on " + i);
  return i;
}, mO = cl, bO = Cu, Jt = function(i) {
  return mO(bO(i));
}, dv = $e, u$ = l$, $O = u$.all, He = u$.IS_HTMLDDA ? function(i) {
  return typeof i == "object" ? i !== null : dv(i) || i === $O;
} : function(i) {
  return typeof i == "object" ? i !== null : dv(i);
}, ve = {}, fd = ve, vd = fe, wO = $e, hv = function(i) {
  return wO(i) ? i : void 0;
}, tt = function(i, e) {
  return arguments.length < 2 ? hv(fd[i]) || hv(vd[i]) : fd[i] && fd[i][e] || vd[i] && vd[i][e];
}, _O = he, Me = _O({}.isPrototypeOf), Vr = typeof navigator < "u" && String(navigator.userAgent) || "", f$ = fe, pd = Vr, cv = f$.process, uv = f$.Deno, fv = cv && cv.versions || uv && uv.version, vv = fv && fv.v8, Ct, Ba;
vv && (Ct = vv.split("."), Ba = Ct[0] > 0 && Ct[0] < 4 ? 1 : +(Ct[0] + Ct[1]));
!Ba && pd && (Ct = pd.match(/Edge\/(\d+)/), (!Ct || Ct[1] >= 74) && (Ct = pd.match(/Chrome\/(\d+)/), Ct && (Ba = +Ct[1])));
var xn = Ba, pv = xn, EO = ee, SO = fe, OO = SO.String, Cn = !!Object.getOwnPropertySymbols && !EO(function() {
  var i = Symbol("symbol detection");
  return !OO(i) || !(Object(i) instanceof Symbol) || // Chrome 38-40 symbols are not inherited from DOM collections prototypes to instances
  !Symbol.sham && pv && pv < 41;
}), TO = Cn, v$ = TO && !Symbol.sham && typeof Symbol.iterator == "symbol", IO = tt, PO = $e, xO = Me, CO = v$, AO = Object, Bo = CO ? function(i) {
  return typeof i == "symbol";
} : function(i) {
  var e = IO("Symbol");
  return PO(e) && xO(e.prototype, AO(i));
}, MO = String, An = function(i) {
  try {
    return MO(i);
  } catch {
    return "Object";
  }
}, DO = $e, kO = An, NO = TypeError, ft = function(i) {
  if (DO(i)) return i;
  throw new NO(kO(i) + " is not a function");
}, RO = ft, FO = Pn, Au = function(i, e) {
  var t = i[e];
  return FO(t) ? void 0 : RO(t);
}, gd = je, yd = $e, md = He, BO = TypeError, LO = function(i, e) {
  var t, r;
  if (e === "string" && yd(t = i.toString) && !md(r = gd(t, i)) || yd(t = i.valueOf) && !md(r = gd(t, i)) || e !== "string" && yd(t = i.toString) && !md(r = gd(t, i))) return r;
  throw new BO("Can't convert object to primitive value");
}, p$ = { exports: {} }, jO = !0, gv = fe, zO = Object.defineProperty, WO = function(i, e) {
  try {
    zO(gv, i, { value: e, configurable: !0, writable: !0 });
  } catch {
    gv[i] = e;
  }
  return e;
}, HO = fe, VO = WO, yv = "__core-js_shared__", UO = HO[yv] || VO(yv, {}), Mu = UO, mv = Mu;
(p$.exports = function(i, e) {
  return mv[i] || (mv[i] = e !== void 0 ? e : {});
})("versions", []).push({
  version: "3.33.2",
  mode: "pure",
  copyright: "© 2014-2023 Denis Pushkarev (zloirock.ru)",
  license: "https://github.com/zloirock/core-js/blob/v3.33.2/LICENSE",
  source: "https://github.com/zloirock/core-js"
});
var Mn = p$.exports, GO = Cu, KO = Object, vt = function(i) {
  return KO(GO(i));
}, YO = he, qO = vt, XO = YO({}.hasOwnProperty), De = Object.hasOwn || function(e, t) {
  return XO(qO(e), t);
}, JO = he, ZO = 0, QO = Math.random(), eT = JO(1 .toString), ul = function(i) {
  return "Symbol(" + (i === void 0 ? "" : i) + ")_" + eT(++ZO + QO, 36);
}, tT = fe, rT = Mn, bv = De, iT = ul, nT = Cn, oT = v$, qi = tT.Symbol, bd = rT("wks"), sT = oT ? qi.for || qi : qi && qi.withoutSetter || iT, ge = function(i) {
  return bv(bd, i) || (bd[i] = nT && bv(qi, i) ? qi[i] : sT("Symbol." + i)), bd[i];
}, aT = je, $v = He, wv = Bo, lT = Au, dT = LO, hT = ge, cT = TypeError, uT = hT("toPrimitive"), fT = function(i, e) {
  if (!$v(i) || wv(i)) return i;
  var t = lT(i, uT), r;
  if (t) {
    if (e === void 0 && (e = "default"), r = aT(t, i, e), !$v(r) || wv(r)) return r;
    throw new cT("Can't convert object to primitive value");
  }
  return e === void 0 && (e = "number"), dT(i, e);
}, vT = fT, pT = Bo, fl = function(i) {
  var e = vT(i, "string");
  return pT(e) ? e : e + "";
}, gT = fe, _v = He, Sc = gT.document, yT = _v(Sc) && _v(Sc.createElement), Du = function(i) {
  return yT ? Sc.createElement(i) : {};
}, mT = Le, bT = ee, $T = Du, g$ = !mT && !bT(function() {
  return Object.defineProperty($T("div"), "a", {
    get: function() {
      return 7;
    }
  }).a !== 7;
}), wT = Le, _T = je, ET = hl, ST = Oi, OT = Jt, TT = fl, IT = De, PT = g$, Ev = Object.getOwnPropertyDescriptor;
Si.f = wT ? Ev : function(e, t) {
  if (e = OT(e), t = TT(t), PT) try {
    return Ev(e, t);
  } catch {
  }
  if (IT(e, t)) return ST(!_T(ET.f, e, t), e[t]);
};
var xT = ee, CT = $e, AT = /#|\.prototype\./, Lo = function(i, e) {
  var t = DT[MT(i)];
  return t === NT ? !0 : t === kT ? !1 : CT(e) ? xT(e) : !!e;
}, MT = Lo.normalize = function(i) {
  return String(i).replace(AT, ".").toLowerCase();
}, DT = Lo.data = {}, kT = Lo.NATIVE = "N", NT = Lo.POLYFILL = "P", y$ = Lo, Sv = a$, RT = ft, FT = Fo, BT = Sv(Sv.bind), Ur = function(i, e) {
  return RT(i), e === void 0 ? i : FT ? BT(i, e) : function() {
    return i.apply(e, arguments);
  };
}, pt = {}, LT = Le, jT = ee, m$ = LT && jT(function() {
  return Object.defineProperty(function() {
  }, "prototype", {
    value: 42,
    writable: !1
  }).prototype !== 42;
}), zT = He, WT = String, HT = TypeError, mt = function(i) {
  if (zT(i)) return i;
  throw new HT(WT(i) + " is not an object");
}, VT = Le, UT = g$, GT = m$, Ns = mt, Ov = fl, KT = TypeError, $d = Object.defineProperty, YT = Object.getOwnPropertyDescriptor, wd = "enumerable", _d = "configurable", Ed = "writable";
pt.f = VT ? GT ? function(e, t, r) {
  if (Ns(e), t = Ov(t), Ns(r), typeof e == "function" && t === "prototype" && "value" in r && Ed in r && !r[Ed]) {
    var n = YT(e, t);
    n && n[Ed] && (e[t] = r.value, r = {
      configurable: _d in r ? r[_d] : n[_d],
      enumerable: wd in r ? r[wd] : n[wd],
      writable: !1
    });
  }
  return $d(e, t, r);
} : $d : function(e, t, r) {
  if (Ns(e), t = Ov(t), Ns(r), UT) try {
    return $d(e, t, r);
  } catch {
  }
  if ("get" in r || "set" in r) throw new KT("Accessors not supported");
  return "value" in r && (e[t] = r.value), e;
};
var qT = Le, XT = pt, JT = Oi, gr = qT ? function(i, e, t) {
  return XT.f(i, e, JT(1, t));
} : function(i, e, t) {
  return i[e] = t, i;
}, Rs = fe, ZT = In, QT = a$, eI = $e, tI = Si.f, rI = y$, Fi = ve, iI = Ur, Bi = gr, Tv = De, nI = function(i) {
  var e = function(t, r, n) {
    if (this instanceof e) {
      switch (arguments.length) {
        case 0:
          return new i();
        case 1:
          return new i(t);
        case 2:
          return new i(t, r);
      }
      return new i(t, r, n);
    }
    return ZT(i, this, arguments);
  };
  return e.prototype = i.prototype, e;
}, F = function(i, e) {
  var t = i.target, r = i.global, n = i.stat, o = i.proto, s = r ? Rs : n ? Rs[t] : (Rs[t] || {}).prototype, a = r ? Fi : Fi[t] || Bi(Fi, t, {})[t], l = a.prototype, d, h, c, u, f, v, y, g, p;
  for (u in e)
    d = rI(r ? u : t + (n ? "." : "#") + u, i.forced), h = !d && s && Tv(s, u), v = a[u], h && (i.dontCallGetSet ? (p = tI(s, u), y = p && p.value) : y = s[u]), f = h && y ? y : e[u], !(h && typeof v == typeof f) && (i.bind && h ? g = iI(f, Rs) : i.wrap && h ? g = nI(f) : o && eI(f) ? g = QT(f) : g = f, (i.sham || f && f.sham || v && v.sham) && Bi(g, "sham", !0), Bi(a, u, g), o && (c = t + "Prototype", Tv(Fi, c) || Bi(Fi, c, {}), Bi(Fi[c], u, f), i.real && l && (d || !l[u]) && Bi(l, u, f)));
}, oI = F, sI = Le, Iv = pt.f;
oI({ target: "Object", stat: !0, forced: Object.defineProperty !== Iv, sham: !sI }, {
  defineProperty: Iv
});
var aI = ve, b$ = aI.Object, lI = r$.exports = function(e, t, r) {
  return b$.defineProperty(e, t, r);
};
b$.defineProperty.sham && (lI.sham = !0);
var dI = r$.exports, hI = dI, $$ = hI, cI = $$, uI = cI, fI = uI, vI = fI, w$ = vI, vl = /* @__PURE__ */ z(w$), pI = Hr, Gr = Array.isArray || function(e) {
  return pI(e) === "Array";
}, gI = Math.ceil, yI = Math.floor, mI = Math.trunc || function(e) {
  var t = +e;
  return (t > 0 ? yI : gI)(t);
}, bI = mI, pl = function(i) {
  var e = +i;
  return e !== e || e === 0 ? 0 : bI(e);
}, $I = pl, wI = Math.min, _I = function(i) {
  return i > 0 ? wI($I(i), 9007199254740991) : 0;
}, EI = _I, bt = function(i) {
  return EI(i.length);
}, SI = TypeError, OI = 9007199254740991, gl = function(i) {
  if (i > OI) throw SI("Maximum allowed index exceeded");
  return i;
}, TI = fl, II = pt, PI = Oi, Dn = function(i, e, t) {
  var r = TI(e);
  r in i ? II.f(i, r, PI(0, t)) : i[r] = t;
}, xI = ge, CI = xI("toStringTag"), _$ = {};
_$[CI] = "z";
var ku = String(_$) === "[object z]", AI = ku, MI = $e, wa = Hr, DI = ge, kI = DI("toStringTag"), NI = Object, RI = wa(/* @__PURE__ */ function() {
  return arguments;
}()) === "Arguments", FI = function(i, e) {
  try {
    return i[e];
  } catch {
  }
}, yr = AI ? wa : function(i) {
  var e, t, r;
  return i === void 0 ? "Undefined" : i === null ? "Null" : typeof (t = FI(e = NI(i), kI)) == "string" ? t : RI ? wa(e) : (r = wa(e)) === "Object" && MI(e.callee) ? "Arguments" : r;
}, BI = he, LI = $e, Oc = Mu, jI = BI(Function.toString);
LI(Oc.inspectSource) || (Oc.inspectSource = function(i) {
  return jI(i);
});
var E$ = Oc.inspectSource, zI = he, WI = ee, S$ = $e, HI = yr, VI = tt, UI = E$, O$ = function() {
}, GI = [], T$ = VI("Reflect", "construct"), Nu = /^\s*(?:class|function)\b/, KI = zI(Nu.exec), YI = !Nu.test(O$), Jn = function(e) {
  if (!S$(e)) return !1;
  try {
    return T$(O$, GI, e), !0;
  } catch {
    return !1;
  }
}, I$ = function(e) {
  if (!S$(e)) return !1;
  switch (HI(e)) {
    case "AsyncFunction":
    case "GeneratorFunction":
    case "AsyncGeneratorFunction":
      return !1;
  }
  try {
    return YI || !!KI(Nu, UI(e));
  } catch {
    return !0;
  }
};
I$.sham = !0;
var yl = !T$ || WI(function() {
  var i;
  return Jn(Jn.call) || !Jn(Object) || !Jn(function() {
    i = !0;
  }) || i;
}) ? I$ : Jn, Pv = Gr, qI = yl, XI = He, JI = ge, ZI = JI("species"), xv = Array, QI = function(i) {
  var e;
  return Pv(i) && (e = i.constructor, qI(e) && (e === xv || Pv(e.prototype)) ? e = void 0 : XI(e) && (e = e[ZI], e === null && (e = void 0))), e === void 0 ? xv : e;
}, eP = QI, ml = function(i, e) {
  return new (eP(i))(e === 0 ? 0 : e);
}, tP = ee, rP = ge, iP = xn, nP = rP("species"), jo = function(i) {
  return iP >= 51 || !tP(function() {
    var e = [], t = e.constructor = {};
    return t[nP] = function() {
      return { foo: 1 };
    }, e[i](Boolean).foo !== 1;
  });
}, oP = F, sP = ee, aP = Gr, lP = He, dP = vt, hP = bt, Cv = gl, Av = Dn, cP = ml, uP = jo, fP = ge, vP = xn, P$ = fP("isConcatSpreadable"), pP = vP >= 51 || !sP(function() {
  var i = [];
  return i[P$] = !1, i.concat()[0] !== i;
}), gP = function(i) {
  if (!lP(i)) return !1;
  var e = i[P$];
  return e !== void 0 ? !!e : aP(i);
}, yP = !pP || !uP("concat");
oP({ target: "Array", proto: !0, forced: yP }, {
  // eslint-disable-next-line no-unused-vars -- required for `.length`
  concat: function(e) {
    var t = dP(this), r = cP(t, 0), n = 0, o, s, a, l, d;
    for (o = -1, a = arguments.length; o < a; o++)
      if (d = o === -1 ? t : arguments[o], gP(d))
        for (l = hP(d), Cv(n + l), s = 0; s < l; s++, n++) s in d && Av(r, n, d[s]);
      else
        Cv(n + 1), Av(r, n++, d);
    return r.length = n, r;
  }
});
var mP = yr, bP = String, Ti = function(i) {
  if (mP(i) === "Symbol") throw new TypeError("Cannot convert a Symbol value to a string");
  return bP(i);
}, bl = {}, $P = pl, wP = Math.max, _P = Math.min, $l = function(i, e) {
  var t = $P(i);
  return t < 0 ? wP(t + e, 0) : _P(t, e);
}, EP = Jt, SP = $l, OP = bt, TP = function(i) {
  return function(e, t, r) {
    var n = EP(e), o = OP(n), s = SP(r, o), a;
    if (i && t !== t) {
      for (; o > s; )
        if (a = n[s++], a !== a) return !0;
    } else for (; o > s; s++)
      if ((i || s in n) && n[s] === t) return i || s || 0;
    return !i && -1;
  };
}, IP = {
  // `Array.prototype.indexOf` method
  // https://tc39.es/ecma262/#sec-array.prototype.indexof
  indexOf: TP(!1)
}, zo = {}, PP = he, Sd = De, xP = Jt, CP = IP.indexOf, AP = zo, Mv = PP([].push), x$ = function(i, e) {
  var t = xP(i), r = 0, n = [], o;
  for (o in t) !Sd(AP, o) && Sd(t, o) && Mv(n, o);
  for (; e.length > r; ) Sd(t, o = e[r++]) && (~CP(n, o) || Mv(n, o));
  return n;
}, Ru = [
  "constructor",
  "hasOwnProperty",
  "isPrototypeOf",
  "propertyIsEnumerable",
  "toLocaleString",
  "toString",
  "valueOf"
], MP = x$, DP = Ru, wl = Object.keys || function(e) {
  return MP(e, DP);
}, kP = Le, NP = m$, RP = pt, FP = mt, BP = Jt, LP = wl;
bl.f = kP && !NP ? Object.defineProperties : function(e, t) {
  FP(e);
  for (var r = BP(t), n = LP(t), o = n.length, s = 0, a; o > s; ) RP.f(e, a = n[s++], r[a]);
  return e;
};
var jP = tt, C$ = jP("document", "documentElement"), zP = Mn, WP = ul, Dv = zP("keys"), _l = function(i) {
  return Dv[i] || (Dv[i] = WP(i));
}, HP = mt, VP = bl, kv = Ru, UP = zo, GP = C$, KP = Du, YP = _l, Nv = ">", Rv = "<", Tc = "prototype", Ic = "script", A$ = YP("IE_PROTO"), Od = function() {
}, M$ = function(i) {
  return Rv + Ic + Nv + i + Rv + "/" + Ic + Nv;
}, Fv = function(i) {
  i.write(M$("")), i.close();
  var e = i.parentWindow.Object;
  return i = null, e;
}, qP = function() {
  var i = KP("iframe"), e = "java" + Ic + ":", t;
  return i.style.display = "none", GP.appendChild(i), i.src = String(e), t = i.contentWindow.document, t.open(), t.write(M$("document.F=Object")), t.close(), t.F;
}, Fs, _a = function() {
  try {
    Fs = new ActiveXObject("htmlfile");
  } catch {
  }
  _a = typeof document < "u" ? document.domain && Fs ? Fv(Fs) : qP() : Fv(Fs);
  for (var i = kv.length; i--; ) delete _a[Tc][kv[i]];
  return _a();
};
UP[A$] = !0;
var Ii = Object.create || function(e, t) {
  var r;
  return e !== null ? (Od[Tc] = HP(e), r = new Od(), Od[Tc] = null, r[A$] = e) : r = _a(), t === void 0 ? r : VP.f(r, t);
}, Wo = {}, XP = x$, JP = Ru, ZP = JP.concat("length", "prototype");
Wo.f = Object.getOwnPropertyNames || function(e) {
  return XP(e, ZP);
};
var Fu = {}, Bv = $l, QP = bt, ex = Dn, tx = Array, rx = Math.max, D$ = function(i, e, t) {
  for (var r = QP(i), n = Bv(e, r), o = Bv(t === void 0 ? r : t, r), s = tx(rx(o - n, 0)), a = 0; n < o; n++, a++) ex(s, a, i[n]);
  return s.length = a, s;
}, ix = Hr, nx = Jt, k$ = Wo.f, ox = D$, N$ = typeof window == "object" && window && Object.getOwnPropertyNames ? Object.getOwnPropertyNames(window) : [], sx = function(i) {
  try {
    return k$(i);
  } catch {
    return ox(N$);
  }
};
Fu.f = function(e) {
  return N$ && ix(e) === "Window" ? sx(e) : k$(nx(e));
};
var Ho = {};
Ho.f = Object.getOwnPropertySymbols;
var ax = gr, kn = function(i, e, t, r) {
  return r && r.enumerable ? i[e] = t : ax(i, e, t), i;
}, lx = pt, Bu = function(i, e, t) {
  return lx.f(i, e, t);
}, Vo = {}, dx = ge;
Vo.f = dx;
var Lv = ve, hx = De, cx = Vo, ux = pt.f, we = function(i) {
  var e = Lv.Symbol || (Lv.Symbol = {});
  hx(e, i) || ux(e, i, {
    value: cx.f(i)
  });
}, fx = je, vx = tt, px = ge, gx = kn, R$ = function() {
  var i = vx("Symbol"), e = i && i.prototype, t = e && e.valueOf, r = px("toPrimitive");
  e && !e[r] && gx(e, r, function(n) {
    return fx(t, this);
  }, {});
}, yx = ku, mx = yr, bx = yx ? {}.toString : function() {
  return "[object " + mx(this) + "]";
}, $x = ku, wx = pt.f, _x = gr, Ex = De, Sx = bx, Ox = ge, jv = Ox("toStringTag"), Pi = function(i, e, t, r) {
  if (i) {
    var n = t ? i : i.prototype;
    Ex(n, jv) || wx(n, jv, { configurable: !0, value: e }), r && !$x && _x(n, "toString", Sx);
  }
}, Tx = fe, Ix = $e, zv = Tx.WeakMap, Px = Ix(zv) && /native code/.test(String(zv)), xx = Px, F$ = fe, Cx = He, Ax = gr, Td = De, Id = Mu, Mx = _l, Dx = zo, Wv = "Object already initialized", Pc = F$.TypeError, kx = F$.WeakMap, La, bo, ja, Nx = function(i) {
  return ja(i) ? bo(i) : La(i, {});
}, Rx = function(i) {
  return function(e) {
    var t;
    if (!Cx(e) || (t = bo(e)).type !== i)
      throw new Pc("Incompatible receiver, " + i + " required");
    return t;
  };
};
if (xx || Id.state) {
  var Wt = Id.state || (Id.state = new kx());
  Wt.get = Wt.get, Wt.has = Wt.has, Wt.set = Wt.set, La = function(i, e) {
    if (Wt.has(i)) throw new Pc(Wv);
    return e.facade = i, Wt.set(i, e), e;
  }, bo = function(i) {
    return Wt.get(i) || {};
  }, ja = function(i) {
    return Wt.has(i);
  };
} else {
  var Li = Mx("state");
  Dx[Li] = !0, La = function(i, e) {
    if (Td(i, Li)) throw new Pc(Wv);
    return e.facade = i, Ax(i, Li, e), e;
  }, bo = function(i) {
    return Td(i, Li) ? i[Li] : {};
  }, ja = function(i) {
    return Td(i, Li);
  };
}
var Nn = {
  set: La,
  get: bo,
  has: ja,
  enforce: Nx,
  getterFor: Rx
}, Fx = Ur, Bx = he, Lx = cl, jx = vt, zx = bt, Wx = ml, Hv = Bx([].push), Bs = function(i) {
  var e = i === 1, t = i === 2, r = i === 3, n = i === 4, o = i === 6, s = i === 7, a = i === 5 || o;
  return function(l, d, h, c) {
    for (var u = jx(l), f = Lx(u), v = Fx(d, h), y = zx(f), g = 0, p = c || Wx, m = e ? p(l, y) : t || s ? p(l, 0) : void 0, $, w; y > g; g++) if ((a || g in f) && ($ = f[g], w = v($, g, u), i))
      if (e) m[g] = w;
      else if (w) switch (i) {
        case 3:
          return !0;
        case 5:
          return $;
        case 6:
          return g;
        case 2:
          Hv(m, $);
      }
      else switch (i) {
        case 4:
          return !1;
        case 7:
          Hv(m, $);
      }
    return o ? -1 : r || n ? n : m;
  };
}, Rn = {
  // `Array.prototype.forEach` method
  // https://tc39.es/ecma262/#sec-array.prototype.foreach
  forEach: Bs(0),
  // `Array.prototype.map` method
  // https://tc39.es/ecma262/#sec-array.prototype.map
  map: Bs(1),
  // `Array.prototype.filter` method
  // https://tc39.es/ecma262/#sec-array.prototype.filter
  filter: Bs(2),
  // `Array.prototype.some` method
  // https://tc39.es/ecma262/#sec-array.prototype.some
  some: Bs(3)
}, El = F, Uo = fe, Lu = je, Hx = he, un = Le, fn = Cn, Vx = ee, Fe = De, Ux = Me, xc = mt, Sl = Jt, ju = fl, Gx = Ti, Cc = Oi, $o = Ii, B$ = wl, Kx = Wo, L$ = Fu, Yx = Ho, j$ = Si, z$ = pt, qx = bl, W$ = hl, Vv = kn, Xx = Bu, zu = Mn, Jx = _l, H$ = zo, Uv = ul, Zx = ge, Qx = Vo, eC = we, tC = R$, rC = Pi, V$ = Nn, Ol = Rn.forEach, at = Jx("hidden"), Tl = "Symbol", wo = "prototype", iC = V$.set, Gv = V$.getterFor(Tl), kt = Object[wo], oi = Uo.Symbol, no = oi && oi[wo], nC = Uo.RangeError, oC = Uo.TypeError, Pd = Uo.QObject, U$ = j$.f, si = z$.f, G$ = L$.f, sC = W$.f, K$ = Hx([].push), ur = zu("symbols"), Go = zu("op-symbols"), aC = zu("wks"), Ac = !Pd || !Pd[wo] || !Pd[wo].findChild, Y$ = function(i, e, t) {
  var r = U$(kt, e);
  r && delete kt[e], si(i, e, t), r && i !== kt && si(kt, e, r);
}, Mc = un && Vx(function() {
  return $o(si({}, "a", {
    get: function() {
      return si(this, "a", { value: 7 }).a;
    }
  })).a !== 7;
}) ? Y$ : si, xd = function(i, e) {
  var t = ur[i] = $o(no);
  return iC(t, {
    type: Tl,
    tag: i,
    description: e
  }), un || (t.description = e), t;
}, Il = function(e, t, r) {
  e === kt && Il(Go, t, r), xc(e);
  var n = ju(t);
  return xc(r), Fe(ur, n) ? (r.enumerable ? (Fe(e, at) && e[at][n] && (e[at][n] = !1), r = $o(r, { enumerable: Cc(0, !1) })) : (Fe(e, at) || si(e, at, Cc(1, {})), e[at][n] = !0), Mc(e, n, r)) : si(e, n, r);
}, Wu = function(e, t) {
  xc(e);
  var r = Sl(t), n = B$(r).concat(Z$(r));
  return Ol(n, function(o) {
    (!un || Lu(q$, r, o)) && Il(e, o, r[o]);
  }), e;
}, lC = function(e, t) {
  return t === void 0 ? $o(e) : Wu($o(e), t);
}, q$ = function(e) {
  var t = ju(e), r = Lu(sC, this, t);
  return this === kt && Fe(ur, t) && !Fe(Go, t) ? !1 : r || !Fe(this, t) || !Fe(ur, t) || Fe(this, at) && this[at][t] ? r : !0;
}, X$ = function(e, t) {
  var r = Sl(e), n = ju(t);
  if (!(r === kt && Fe(ur, n) && !Fe(Go, n))) {
    var o = U$(r, n);
    return o && Fe(ur, n) && !(Fe(r, at) && r[at][n]) && (o.enumerable = !0), o;
  }
}, J$ = function(e) {
  var t = G$(Sl(e)), r = [];
  return Ol(t, function(n) {
    !Fe(ur, n) && !Fe(H$, n) && K$(r, n);
  }), r;
}, Z$ = function(i) {
  var e = i === kt, t = G$(e ? Go : Sl(i)), r = [];
  return Ol(t, function(n) {
    Fe(ur, n) && (!e || Fe(kt, n)) && K$(r, ur[n]);
  }), r;
};
fn || (oi = function() {
  if (Ux(no, this)) throw new oC("Symbol is not a constructor");
  var e = !arguments.length || arguments[0] === void 0 ? void 0 : Gx(arguments[0]), t = Uv(e), r = function(n) {
    var o = this === void 0 ? Uo : this;
    o === kt && Lu(r, Go, n), Fe(o, at) && Fe(o[at], t) && (o[at][t] = !1);
    var s = Cc(1, n);
    try {
      Mc(o, t, s);
    } catch (a) {
      if (!(a instanceof nC)) throw a;
      Y$(o, t, s);
    }
  };
  return un && Ac && Mc(kt, t, { configurable: !0, set: r }), xd(t, e);
}, no = oi[wo], Vv(no, "toString", function() {
  return Gv(this).tag;
}), Vv(oi, "withoutSetter", function(i) {
  return xd(Uv(i), i);
}), W$.f = q$, z$.f = Il, qx.f = Wu, j$.f = X$, Kx.f = L$.f = J$, Yx.f = Z$, Qx.f = function(i) {
  return xd(Zx(i), i);
}, un && Xx(no, "description", {
  configurable: !0,
  get: function() {
    return Gv(this).description;
  }
}));
El({ global: !0, wrap: !0, forced: !fn, sham: !fn }, {
  Symbol: oi
});
Ol(B$(aC), function(i) {
  eC(i);
});
El({ target: Tl, stat: !0, forced: !fn }, {
  useSetter: function() {
    Ac = !0;
  },
  useSimple: function() {
    Ac = !1;
  }
});
El({ target: "Object", stat: !0, forced: !fn, sham: !un }, {
  // `Object.create` method
  // https://tc39.es/ecma262/#sec-object.create
  create: lC,
  // `Object.defineProperty` method
  // https://tc39.es/ecma262/#sec-object.defineproperty
  defineProperty: Il,
  // `Object.defineProperties` method
  // https://tc39.es/ecma262/#sec-object.defineproperties
  defineProperties: Wu,
  // `Object.getOwnPropertyDescriptor` method
  // https://tc39.es/ecma262/#sec-object.getownpropertydescriptors
  getOwnPropertyDescriptor: X$
});
El({ target: "Object", stat: !0, forced: !fn }, {
  // `Object.getOwnPropertyNames` method
  // https://tc39.es/ecma262/#sec-object.getownpropertynames
  getOwnPropertyNames: J$
});
tC();
rC(oi, Tl);
H$[at] = !0;
var dC = Cn, Q$ = dC && !!Symbol.for && !!Symbol.keyFor, hC = F, cC = tt, uC = De, fC = Ti, e1 = Mn, vC = Q$, Cd = e1("string-to-symbol-registry"), pC = e1("symbol-to-string-registry");
hC({ target: "Symbol", stat: !0, forced: !vC }, {
  for: function(i) {
    var e = fC(i);
    if (uC(Cd, e)) return Cd[e];
    var t = cC("Symbol")(e);
    return Cd[e] = t, pC[t] = e, t;
  }
});
var gC = F, yC = De, mC = Bo, bC = An, $C = Mn, wC = Q$, Kv = $C("symbol-to-string-registry");
gC({ target: "Symbol", stat: !0, forced: !wC }, {
  keyFor: function(e) {
    if (!mC(e)) throw new TypeError(bC(e) + " is not a symbol");
    if (yC(Kv, e)) return Kv[e];
  }
});
var _C = he, Ko = _C([].slice), EC = he, Yv = Gr, SC = $e, qv = Hr, OC = Ti, Xv = EC([].push), TC = function(i) {
  if (SC(i)) return i;
  if (Yv(i)) {
    for (var e = i.length, t = [], r = 0; r < e; r++) {
      var n = i[r];
      typeof n == "string" ? Xv(t, n) : (typeof n == "number" || qv(n) === "Number" || qv(n) === "String") && Xv(t, OC(n));
    }
    var o = t.length, s = !0;
    return function(a, l) {
      if (s)
        return s = !1, l;
      if (Yv(this)) return l;
      for (var d = 0; d < o; d++) if (t[d] === a) return l;
    };
  }
}, IC = F, t1 = tt, r1 = In, PC = je, Yo = he, i1 = ee, Jv = $e, Zv = Bo, n1 = Ko, xC = TC, CC = Cn, AC = String, Cr = t1("JSON", "stringify"), Ls = Yo(/./.exec), Qv = Yo("".charAt), MC = Yo("".charCodeAt), DC = Yo("".replace), kC = Yo(1 .toString), NC = /[\uD800-\uDFFF]/g, ep = /^[\uD800-\uDBFF]$/, tp = /^[\uDC00-\uDFFF]$/, rp = !CC || i1(function() {
  var i = t1("Symbol")("stringify detection");
  return Cr([i]) !== "[null]" || Cr({ a: i }) !== "{}" || Cr(Object(i)) !== "{}";
}), ip = i1(function() {
  return Cr("\uDF06\uD834") !== '"\\udf06\\ud834"' || Cr("\uDEAD") !== '"\\udead"';
}), RC = function(i, e) {
  var t = n1(arguments), r = xC(e);
  if (!(!Jv(r) && (i === void 0 || Zv(i))))
    return t[1] = function(n, o) {
      if (Jv(r) && (o = PC(r, this, AC(n), o)), !Zv(o)) return o;
    }, r1(Cr, null, t);
}, FC = function(i, e, t) {
  var r = Qv(t, e - 1), n = Qv(t, e + 1);
  return Ls(ep, i) && !Ls(tp, n) || Ls(tp, i) && !Ls(ep, r) ? "\\u" + kC(MC(i, 0), 16) : i;
};
Cr && IC({ target: "JSON", stat: !0, forced: rp || ip }, {
  // eslint-disable-next-line no-unused-vars -- required for `.length`
  stringify: function(e, t, r) {
    var n = n1(arguments), o = r1(rp ? RC : Cr, null, n);
    return ip && typeof o == "string" ? DC(o, NC, FC) : o;
  }
});
var BC = F, LC = Cn, jC = ee, o1 = Ho, zC = vt, WC = !LC || jC(function() {
  o1.f(1);
});
BC({ target: "Object", stat: !0, forced: WC }, {
  getOwnPropertySymbols: function(e) {
    var t = o1.f;
    return t ? t(zC(e)) : [];
  }
});
var HC = we;
HC("asyncIterator");
var VC = we;
VC("hasInstance");
var UC = we;
UC("isConcatSpreadable");
var GC = we;
GC("iterator");
var KC = we;
KC("match");
var YC = we;
YC("matchAll");
var qC = we;
qC("replace");
var XC = we;
XC("search");
var JC = we;
JC("species");
var ZC = we;
ZC("split");
var QC = we, eA = R$;
QC("toPrimitive");
eA();
var tA = tt, rA = we, iA = Pi;
rA("toStringTag");
iA(tA("Symbol"), "Symbol");
var nA = we;
nA("unscopables");
var oA = fe, sA = Pi;
sA(oA.JSON, "JSON", !0);
var aA = ve, lA = aA.Symbol, Fn = {}, Dc = Le, dA = De, s1 = Function.prototype, hA = Dc && Object.getOwnPropertyDescriptor, a1 = dA(s1, "name"), cA = a1 && (function() {
}).name === "something";
a1 && (!Dc || Dc && hA(s1, "name").configurable);
var uA = {
  PROPER: cA
}, fA = ee, l1 = !fA(function() {
  function i() {
  }
  return i.prototype.constructor = null, Object.getPrototypeOf(new i()) !== i.prototype;
}), vA = De, pA = $e, gA = vt, yA = _l, mA = l1, np = yA("IE_PROTO"), kc = Object, bA = kc.prototype, Pl = mA ? kc.getPrototypeOf : function(i) {
  var e = gA(i);
  if (vA(e, np)) return e[np];
  var t = e.constructor;
  return pA(t) && e instanceof t ? t.prototype : e instanceof kc ? bA : null;
}, $A = ee, wA = $e, _A = He, EA = Ii, op = Pl, SA = kn, OA = ge, Nc = OA("iterator"), d1 = !1, rr, Ad, Md;
[].keys && (Md = [].keys(), "next" in Md ? (Ad = op(op(Md)), Ad !== Object.prototype && (rr = Ad)) : d1 = !0);
var TA = !_A(rr) || $A(function() {
  var i = {};
  return rr[Nc].call(i) !== i;
});
TA ? rr = {} : rr = EA(rr);
wA(rr[Nc]) || SA(rr, Nc, function() {
  return this;
});
var h1 = {
  IteratorPrototype: rr,
  BUGGY_SAFARI_ITERATORS: d1
}, IA = h1.IteratorPrototype, PA = Ii, xA = Oi, CA = Pi, AA = Fn, MA = function() {
  return this;
}, DA = function(i, e, t, r) {
  var n = e + " Iterator";
  return i.prototype = PA(IA, { next: xA(+!r, t) }), CA(i, n, !1, !0), AA[n] = MA, i;
}, kA = he, NA = ft, RA = function(i, e, t) {
  try {
    return kA(NA(Object.getOwnPropertyDescriptor(i, e)[t]));
  } catch {
  }
}, FA = $e, BA = String, LA = TypeError, jA = function(i) {
  if (typeof i == "object" || FA(i)) return i;
  throw new LA("Can't set " + BA(i) + " as a prototype");
}, zA = RA, WA = mt, HA = jA, c1 = Object.setPrototypeOf || ("__proto__" in {} ? function() {
  var i = !1, e = {}, t;
  try {
    t = zA(Object.prototype, "__proto__", "set"), t(e, []), i = e instanceof Array;
  } catch {
  }
  return function(n, o) {
    return WA(n), HA(o), i ? t(n, o) : n.__proto__ = o, n;
  };
}() : void 0), VA = F, UA = je, GA = uA, KA = DA, YA = Pl, qA = Pi, sp = kn, XA = ge, ap = Fn, JA = h1, ZA = GA.PROPER, js = JA.BUGGY_SAFARI_ITERATORS, Dd = XA("iterator"), lp = "keys", zs = "values", dp = "entries", QA = function() {
  return this;
}, Hu = function(i, e, t, r, n, o, s) {
  KA(t, e, r);
  var a = function(p) {
    if (p === n && u) return u;
    if (!js && p && p in h) return h[p];
    switch (p) {
      case lp:
        return function() {
          return new t(this, p);
        };
      case zs:
        return function() {
          return new t(this, p);
        };
      case dp:
        return function() {
          return new t(this, p);
        };
    }
    return function() {
      return new t(this);
    };
  }, l = e + " Iterator", d = !1, h = i.prototype, c = h[Dd] || h["@@iterator"] || n && h[n], u = !js && c || a(n), f = e === "Array" && h.entries || c, v, y, g;
  if (f && (v = YA(f.call(new i())), v !== Object.prototype && v.next && (qA(v, l, !0, !0), ap[l] = QA)), ZA && n === zs && c && c.name !== zs && (d = !0, u = function() {
    return UA(c, this);
  }), n)
    if (y = {
      values: a(zs),
      keys: o ? u : a(lp),
      entries: a(dp)
    }, s) for (g in y)
      (js || d || !(g in h)) && sp(h, g, y[g]);
    else VA({ target: e, proto: !0, forced: js || d }, y);
  return s && h[Dd] !== u && sp(h, Dd, u, {}), ap[e] = u, y;
}, Vu = function(i, e) {
  return { value: i, done: e };
}, eM = Jt, hp = Fn, u1 = Nn;
pt.f;
var tM = Hu, Ws = Vu, f1 = "Array Iterator", rM = u1.set, iM = u1.getterFor(f1);
tM(Array, "Array", function(i, e) {
  rM(this, {
    type: f1,
    target: eM(i),
    // target
    index: 0,
    // next index
    kind: e
    // kind
  });
}, function() {
  var i = iM(this), e = i.target, t = i.index++;
  if (!e || t >= e.length)
    return i.target = void 0, Ws(void 0, !0);
  switch (i.kind) {
    case "keys":
      return Ws(t, !1);
    case "values":
      return Ws(e[t], !1);
  }
  return Ws([t, e[t]], !1);
}, "values");
hp.Arguments = hp.Array;
var nM = {
  CSSRuleList: 0,
  CSSStyleDeclaration: 0,
  CSSValueList: 0,
  ClientRectList: 0,
  DOMRectList: 0,
  DOMStringList: 0,
  DOMTokenList: 1,
  DataTransferItemList: 0,
  FileList: 0,
  HTMLAllCollection: 0,
  HTMLCollection: 0,
  HTMLFormElement: 0,
  HTMLSelectElement: 0,
  MediaList: 0,
  MimeTypeArray: 0,
  NamedNodeMap: 0,
  NodeList: 1,
  PaintRequestList: 0,
  Plugin: 0,
  PluginArray: 0,
  SVGLengthList: 0,
  SVGNumberList: 0,
  SVGPathSegList: 0,
  SVGPointList: 0,
  SVGStringList: 0,
  SVGTransformList: 0,
  SourceBufferList: 0,
  StyleSheetList: 0,
  TextTrackCueList: 0,
  TextTrackList: 0,
  TouchList: 0
}, oM = nM, sM = fe, aM = yr, lM = gr, cp = Fn, dM = ge, up = dM("toStringTag");
for (var kd in oM) {
  var fp = sM[kd], Nd = fp && fp.prototype;
  Nd && aM(Nd) !== up && lM(Nd, up, kd), cp[kd] = cp.Array;
}
var hM = lA, v1 = hM, cM = ge, uM = pt.f, vp = cM("metadata"), pp = Function.prototype;
pp[vp] === void 0 && uM(pp, vp, {
  value: null
});
var fM = we;
fM("asyncDispose");
var vM = we;
vM("dispose");
var pM = we;
pM("metadata");
var gM = v1, yM = gM, mM = tt, bM = he, Uu = mM("Symbol"), $M = Uu.keyFor, wM = bM(Uu.prototype.valueOf), p1 = Uu.isRegisteredSymbol || function(e) {
  try {
    return $M(wM(e)) !== void 0;
  } catch {
    return !1;
  }
}, _M = F, EM = p1;
_M({ target: "Symbol", stat: !0 }, {
  isRegisteredSymbol: EM
});
var SM = Mn, g1 = tt, OM = he, TM = Bo, IM = ge, za = g1("Symbol"), gp = za.isWellKnownSymbol, y1 = g1("Object", "getOwnPropertyNames"), PM = OM(za.prototype.valueOf), yp = SM("wks");
for (var Rd = 0, mp = y1(za), xM = mp.length; Rd < xM; Rd++)
  try {
    var bp = mp[Rd];
    TM(za[bp]) && IM(bp);
  } catch {
  }
var m1 = function(e) {
  if (gp && gp(e)) return !0;
  try {
    for (var t = PM(e), r = 0, n = y1(yp), o = n.length; r < o; r++)
      if (yp[n[r]] == t) return !0;
  } catch {
  }
  return !1;
}, CM = F, AM = m1;
CM({ target: "Symbol", stat: !0, forced: !0 }, {
  isWellKnownSymbol: AM
});
var MM = we;
MM("matcher");
var DM = we;
DM("observable");
var kM = F, NM = p1;
kM({ target: "Symbol", stat: !0 }, {
  isRegistered: NM
});
var RM = F, FM = m1;
RM({ target: "Symbol", stat: !0, forced: !0 }, {
  isWellKnown: FM
});
var BM = we;
BM("metadataKey");
var LM = we;
LM("patternMatch");
var jM = we;
jM("replaceAll");
var zM = yM, WM = zM, Gu = WM, Xi = /* @__PURE__ */ z(Gu), Ku = he, HM = pl, VM = Ti, UM = Cu, GM = Ku("".charAt), $p = Ku("".charCodeAt), KM = Ku("".slice), YM = function(i) {
  return function(e, t) {
    var r = VM(UM(e)), n = HM(t), o = r.length, s, a;
    return n < 0 || n >= o ? i ? "" : void 0 : (s = $p(r, n), s < 55296 || s > 56319 || n + 1 === o || (a = $p(r, n + 1)) < 56320 || a > 57343 ? i ? GM(r, n) : s : i ? KM(r, n, n + 2) : (s - 55296 << 10) + (a - 56320) + 65536);
  };
}, qM = {
  // `String.prototype.at` method
  // https://github.com/mathiasbynens/String.prototype.at
  charAt: YM(!0)
}, XM = qM.charAt, JM = Ti, b1 = Nn, ZM = Hu, wp = Vu, $1 = "String Iterator", QM = b1.set, eD = b1.getterFor($1);
ZM(String, "String", function(i) {
  QM(this, {
    type: $1,
    string: JM(i),
    index: 0
  });
}, function() {
  var e = eD(this), t = e.string, r = e.index, n;
  return r >= t.length ? wp(void 0, !0) : (n = XM(t, r), e.index += n.length, wp(n, !1));
});
var tD = Vo, rD = tD.f("iterator"), iD = rD, w1 = iD, nD = w1, oD = nD, sD = oD, aD = sD, _1 = aD, lD = /* @__PURE__ */ z(_1);
function vn(i) {
  "@babel/helpers - typeof";
  return vn = typeof Xi == "function" && typeof lD == "symbol" ? function(e) {
    return typeof e;
  } : function(e) {
    return e && typeof Xi == "function" && e.constructor === Xi && e !== Xi.prototype ? "symbol" : typeof e;
  }, vn(i);
}
var dD = Vo, hD = dD.f("toPrimitive"), cD = hD, uD = cD, fD = uD, vD = fD, pD = vD, gD = pD, yD = gD, mD = /* @__PURE__ */ z(yD);
function bD(i, e) {
  if (vn(i) !== "object" || i === null) return i;
  var t = i[mD];
  if (t !== void 0) {
    var r = t.call(i, e);
    if (vn(r) !== "object") return r;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (e === "string" ? String : Number)(i);
}
function E1(i) {
  var e = bD(i, "string");
  return vn(e) === "symbol" ? e : String(e);
}
function _p(i, e) {
  for (var t = 0; t < e.length; t++) {
    var r = e[t];
    r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), vl(i, E1(r.key), r);
  }
}
function xl(i, e, t) {
  return e && _p(i.prototype, e), t && _p(i, t), vl(i, "prototype", {
    writable: !1
  }), i;
}
function Ar(i, e, t) {
  return e = E1(e), e in i ? vl(i, e, {
    value: t,
    enumerable: !0,
    configurable: !0,
    writable: !0
  }) : i[e] = t, i;
}
var S1 = he, $D = ft, wD = He, _D = De, Ep = Ko, ED = Fo, O1 = Function, SD = S1([].concat), OD = S1([].join), Fd = {}, TD = function(i, e, t) {
  if (!_D(Fd, e)) {
    for (var r = [], n = 0; n < e; n++) r[n] = "a[" + n + "]";
    Fd[e] = O1("C,a", "return new C(" + OD(r, ",") + ")");
  }
  return Fd[e](i, t);
}, T1 = ED ? O1.bind : function(e) {
  var t = $D(this), r = t.prototype, n = Ep(arguments, 1), o = function() {
    var a = SD(n, Ep(arguments));
    return this instanceof o ? TD(t, a.length, a) : t.apply(e, a);
  };
  return wD(r) && (o.prototype = r), o;
}, ID = F, Sp = T1;
ID({ target: "Function", proto: !0, forced: Function.bind !== Sp }, {
  bind: Sp
});
var PD = fe, xD = ve, Ke = function(i, e) {
  var t = xD[i + "Prototype"], r = t && t[e];
  if (r) return r;
  var n = PD[i], o = n && n.prototype;
  return o && o[e];
}, CD = Ke, AD = CD("Function", "bind"), MD = Me, DD = AD, Bd = Function.prototype, kD = function(i) {
  var e = i.bind;
  return i === Bd || MD(Bd, i) && e === Bd.bind ? DD : e;
}, ND = kD, I1 = ND, RD = I1, P1 = /* @__PURE__ */ z(RD), FD = ft, BD = vt, LD = cl, jD = bt, zD = TypeError, WD = function(i) {
  return function(e, t, r, n) {
    FD(t);
    var o = BD(e), s = LD(o), a = jD(o), l = i ? a - 1 : 0, d = i ? -1 : 1;
    if (r < 2) for (; ; ) {
      if (l in s) {
        n = s[l], l += d;
        break;
      }
      if (l += d, i ? l < 0 : a <= l)
        throw new zD("Reduce of empty array with no initial value");
    }
    for (; i ? l >= 0 : a > l; l += d) l in s && (n = t(n, s[l], l, o));
    return n;
  };
}, HD = {
  // `Array.prototype.reduce` method
  // https://tc39.es/ecma262/#sec-array.prototype.reduce
  left: WD(!1)
}, VD = ee, Cl = function(i, e) {
  var t = [][i];
  return !!t && VD(function() {
    t.call(null, e || function() {
      return 1;
    }, 1);
  });
}, UD = fe, GD = Hr, qo = GD(UD.process) === "process", KD = F, YD = HD.left, qD = Cl, Op = xn, XD = qo, JD = !XD && Op > 79 && Op < 83, ZD = JD || !qD("reduce");
KD({ target: "Array", proto: !0, forced: ZD }, {
  reduce: function(e) {
    var t = arguments.length;
    return YD(this, e, t, t > 1 ? arguments[1] : void 0);
  }
});
var QD = Ke, e2 = QD("Array", "reduce"), t2 = Me, r2 = e2, Ld = Array.prototype, i2 = function(i) {
  var e = i.reduce;
  return i === Ld || t2(Ld, i) && e === Ld.reduce ? r2 : e;
}, n2 = i2, o2 = n2, s2 = o2, a2 = /* @__PURE__ */ z(s2), l2 = F, d2 = Rn.filter, h2 = jo, c2 = h2("filter");
l2({ target: "Array", proto: !0, forced: !c2 }, {
  filter: function(e) {
    return d2(this, e, arguments.length > 1 ? arguments[1] : void 0);
  }
});
var u2 = Ke, f2 = u2("Array", "filter"), v2 = Me, p2 = f2, jd = Array.prototype, g2 = function(i) {
  var e = i.filter;
  return i === jd || v2(jd, i) && e === jd.filter ? p2 : e;
}, y2 = g2, m2 = y2, b2 = m2, Ji = /* @__PURE__ */ z(b2), $2 = F, w2 = Rn.map, _2 = jo, E2 = _2("map");
$2({ target: "Array", proto: !0, forced: !E2 }, {
  map: function(e) {
    return w2(this, e, arguments.length > 1 ? arguments[1] : void 0);
  }
});
var S2 = Ke, O2 = S2("Array", "map"), T2 = Me, I2 = O2, zd = Array.prototype, P2 = function(i) {
  var e = i.map;
  return i === zd || T2(zd, i) && e === zd.map ? I2 : e;
}, x2 = P2, C2 = x2, A2 = C2, At = /* @__PURE__ */ z(A2), M2 = Gr, D2 = bt, k2 = gl, N2 = Ur, x1 = function(i, e, t, r, n, o, s, a) {
  for (var l = n, d = 0, h = s ? N2(s, a) : !1, c, u; d < r; )
    d in t && (c = h ? h(t[d], d, e) : t[d], o > 0 && M2(c) ? (u = D2(c), l = x1(i, e, c, u, l, o - 1) - 1) : (k2(l + 1), i[l] = c), l++), d++;
  return l;
}, R2 = x1, F2 = F, B2 = R2, L2 = ft, j2 = vt, z2 = bt, W2 = ml;
F2({ target: "Array", proto: !0 }, {
  flatMap: function(e) {
    var t = j2(this), r = z2(t), n;
    return L2(e), n = W2(t, 0), n.length = B2(n, t, t, r, 0, 1, e, arguments.length > 1 ? arguments[1] : void 0), n;
  }
});
var H2 = Ke;
H2("Array", "flatMap");
var V2 = je, Tp = mt, U2 = Au, C1 = function(i, e, t) {
  var r, n;
  Tp(i);
  try {
    if (r = U2(i, "return"), !r) {
      if (e === "throw") throw t;
      return t;
    }
    r = V2(r, i);
  } catch (o) {
    n = !0, r = o;
  }
  if (e === "throw") throw t;
  if (n) throw r;
  return Tp(r), t;
}, G2 = mt, K2 = C1, Y2 = function(i, e, t, r) {
  try {
    return r ? e(G2(t)[0], t[1]) : e(t);
  } catch (n) {
    K2(i, "throw", n);
  }
}, q2 = ge, X2 = Fn, J2 = q2("iterator"), Z2 = Array.prototype, A1 = function(i) {
  return i !== void 0 && (X2.Array === i || Z2[J2] === i);
}, Q2 = yr, Ip = Au, ek = Pn, tk = Fn, rk = ge, ik = rk("iterator"), Al = function(i) {
  if (!ek(i)) return Ip(i, ik) || Ip(i, "@@iterator") || tk[Q2(i)];
}, nk = je, ok = ft, sk = mt, ak = An, lk = Al, dk = TypeError, Yu = function(i, e) {
  var t = arguments.length < 2 ? lk(i) : e;
  if (ok(t)) return sk(nk(t, i));
  throw new dk(ak(i) + " is not iterable");
}, hk = Ur, ck = je, uk = vt, fk = Y2, vk = A1, pk = yl, gk = bt, Pp = Dn, yk = Yu, mk = Al, xp = Array, bk = function(e) {
  var t = uk(e), r = pk(this), n = arguments.length, o = n > 1 ? arguments[1] : void 0, s = o !== void 0;
  s && (o = hk(o, n > 2 ? arguments[2] : void 0));
  var a = mk(t), l = 0, d, h, c, u, f, v;
  if (a && !(this === xp && vk(a)))
    for (u = yk(t, a), f = u.next, h = r ? new this() : []; !(c = ck(f, u)).done; l++)
      v = s ? fk(u, o, [c.value, l], !0) : c.value, Pp(h, l, v);
  else
    for (d = gk(t), h = r ? new this(d) : xp(d); d > l; l++)
      v = s ? o(t[l], l) : t[l], Pp(h, l, v);
  return h.length = l, h;
}, $k = ge, M1 = $k("iterator"), D1 = !1;
try {
  var wk = 0, Cp = {
    next: function() {
      return { done: !!wk++ };
    },
    return: function() {
      D1 = !0;
    }
  };
  Cp[M1] = function() {
    return this;
  }, Array.from(Cp, function() {
    throw 2;
  });
} catch {
}
var k1 = function(i, e) {
  try {
    if (!e && !D1) return !1;
  } catch {
    return !1;
  }
  var t = !1;
  try {
    var r = {};
    r[M1] = function() {
      return {
        next: function() {
          return { done: t = !0 };
        }
      };
    }, i(r);
  } catch {
  }
  return t;
}, _k = F, Ek = bk, Sk = k1, Ok = !Sk(function(i) {
  Array.from(i);
});
_k({ target: "Array", stat: !0, forced: Ok }, {
  from: Ek
});
var Tk = ve, Ik = Tk.Array.from, Pk = Ik, N1 = Pk, xk = N1, qu = /* @__PURE__ */ z(xk), Ck = Al, Ak = Ck, Mk = Ak, Dk = Mk, kk = Dk, Nk = kk, Rk = Nk, Fk = Rk, R1 = Fk, F1 = /* @__PURE__ */ z(R1), Bk = R1, Xu = /* @__PURE__ */ z(Bk), Lk = F, jk = Gr;
Lk({ target: "Array", stat: !0 }, {
  isArray: jk
});
var zk = ve, Wk = zk.Array.isArray, Hk = Wk, B1 = Hk, Vk = B1, Uk = Vk, Gk = Uk, Kk = Gk, Yk = Kk, L1 = /* @__PURE__ */ z(Yk);
function qk(i) {
  if (L1(i)) return i;
}
var Xk = Le, Jk = Gr, Zk = TypeError, Qk = Object.getOwnPropertyDescriptor, eN = Xk && !function() {
  if (this !== void 0) return !0;
  try {
    Object.defineProperty([], "length", { writable: !1 }).length = 1;
  } catch (i) {
    return i instanceof TypeError;
  }
}(), j1 = eN ? function(i, e) {
  if (Jk(i) && !Qk(i, "length").writable)
    throw new Zk("Cannot set read only .length");
  return i.length = e;
} : function(i, e) {
  return i.length = e;
}, tN = F, rN = vt, iN = bt, nN = j1, oN = gl, sN = ee, aN = sN(function() {
  return [].push.call({ length: 4294967296 }, 1) !== 4294967297;
}), lN = function() {
  try {
    Object.defineProperty([], "length", { writable: !1 }).push();
  } catch (i) {
    return i instanceof TypeError;
  }
}, dN = aN || !lN();
tN({ target: "Array", proto: !0, forced: dN }, {
  // eslint-disable-next-line no-unused-vars -- required for `.length`
  push: function(e) {
    var t = rN(this), r = iN(t), n = arguments.length;
    oN(r + n);
    for (var o = 0; o < n; o++)
      t[r] = arguments[o], r++;
    return nN(t, r), r;
  }
});
var hN = Ke, cN = hN("Array", "push"), uN = Me, fN = cN, Wd = Array.prototype, vN = function(i) {
  var e = i.push;
  return i === Wd || uN(Wd, i) && e === Wd.push ? fN : e;
}, pN = vN, gN = pN, yN = gN, mN = yN, bN = mN, $N = bN, z1 = $N, wN = /* @__PURE__ */ z(z1);
function _N(i, e) {
  var t = i == null ? null : typeof Xi < "u" && F1(i) || i["@@iterator"];
  if (t != null) {
    var r, n, o, s, a = [], l = !0, d = !1;
    try {
      if (o = (t = t.call(i)).next, e === 0) {
        if (Object(t) !== t) return;
        l = !1;
      } else for (; !(l = (r = o.call(t)).done) && (wN(a).call(a, r.value), a.length !== e); l = !0) ;
    } catch (h) {
      d = !0, n = h;
    } finally {
      try {
        if (!l && t.return != null && (s = t.return(), Object(s) !== s)) return;
      } finally {
        if (d) throw n;
      }
    }
    return a;
  }
}
var EN = F, Ap = Gr, SN = yl, ON = He, Mp = $l, TN = bt, IN = Jt, PN = Dn, xN = ge, CN = jo, AN = Ko, MN = CN("slice"), DN = xN("species"), Hd = Array, kN = Math.max;
EN({ target: "Array", proto: !0, forced: !MN }, {
  slice: function(e, t) {
    var r = IN(this), n = TN(r), o = Mp(e, n), s = Mp(t === void 0 ? n : t, n), a, l, d;
    if (Ap(r) && (a = r.constructor, SN(a) && (a === Hd || Ap(a.prototype)) ? a = void 0 : ON(a) && (a = a[DN], a === null && (a = void 0)), a === Hd || a === void 0))
      return AN(r, o, s);
    for (l = new (a === void 0 ? Hd : a)(kN(s - o, 0)), d = 0; o < s; o++, d++) o in r && PN(l, d, r[o]);
    return l.length = d, l;
  }
});
var NN = Ke, RN = NN("Array", "slice"), FN = Me, BN = RN, Vd = Array.prototype, LN = function(i) {
  var e = i.slice;
  return i === Vd || FN(Vd, i) && e === Vd.slice ? BN : e;
}, jN = LN, W1 = jN, zN = W1, WN = zN, HN = WN, VN = HN, H1 = VN, UN = /* @__PURE__ */ z(H1), GN = N1, KN = GN, YN = KN, qN = YN, XN = qN, V1 = /* @__PURE__ */ z(XN);
function Rc(i, e) {
  (e == null || e > i.length) && (e = i.length);
  for (var t = 0, r = new Array(e); t < e; t++) r[t] = i[t];
  return r;
}
function U1(i, e) {
  var t;
  if (i) {
    if (typeof i == "string") return Rc(i, e);
    var r = UN(t = Object.prototype.toString.call(i)).call(t, 8, -1);
    if (r === "Object" && i.constructor && (r = i.constructor.name), r === "Map" || r === "Set") return V1(i);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return Rc(i, e);
  }
}
function JN() {
  throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function nt(i, e) {
  return qk(i) || _N(i, e) || U1(i, e) || JN();
}
function ZN(i) {
  if (L1(i)) return Rc(i);
}
function QN(i) {
  if (typeof Xi < "u" && F1(i) != null || i["@@iterator"] != null) return V1(i);
}
function eR() {
  throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function lt(i) {
  return ZN(i) || QN(i) || U1(i) || eR();
}
var tR = v1, Ml = /* @__PURE__ */ z(tR), rR = Ke, iR = rR("Array", "concat"), nR = Me, oR = iR, Ud = Array.prototype, sR = function(i) {
  var e = i.concat;
  return i === Ud || nR(Ud, i) && e === Ud.concat ? oR : e;
}, aR = sR, lR = aR, dR = lR, Dl = /* @__PURE__ */ z(dR), hR = W1, kl = /* @__PURE__ */ z(hR), cR = tt, uR = he, fR = Wo, vR = Ho, pR = mt, gR = uR([].concat), Ju = cR("Reflect", "ownKeys") || function(e) {
  var t = fR.f(pR(e)), r = vR.f;
  return r ? gR(t, r(e)) : t;
}, yR = F, mR = Ju;
yR({ target: "Reflect", stat: !0 }, {
  ownKeys: mR
});
var bR = ve, $R = bR.Reflect.ownKeys, wR = $R, _R = wR, ER = _R, SR = /* @__PURE__ */ z(ER), OR = B1, gt = /* @__PURE__ */ z(OR), TR = F, IR = vt, G1 = wl, PR = ee, xR = PR(function() {
  G1(1);
});
TR({ target: "Object", stat: !0, forced: xR }, {
  keys: function(e) {
    return G1(IR(e));
  }
});
var CR = ve, AR = CR.Object.keys, MR = AR, DR = MR, kR = DR, Zu = /* @__PURE__ */ z(kR), NR = Rn.forEach, RR = Cl, FR = RR("forEach"), BR = FR ? [].forEach : function(e) {
  return NR(this, e, arguments.length > 1 ? arguments[1] : void 0);
}, LR = F, Dp = BR;
LR({ target: "Array", proto: !0, forced: [].forEach !== Dp }, {
  forEach: Dp
});
var jR = Ke, zR = jR("Array", "forEach"), WR = zR, HR = WR, VR = yr, UR = De, GR = Me, KR = HR, Gd = Array.prototype, YR = {
  DOMTokenList: !0,
  NodeList: !0
}, K1 = function(i) {
  var e = i.forEach;
  return i === Gd || GR(Gd, i) && e === Gd.forEach || UR(YR, VR(i)) ? KR : e;
}, qR = K1, pi = /* @__PURE__ */ z(qR), XR = F, JR = he, ZR = Gr, QR = JR([].reverse), kp = [1, 2];
XR({ target: "Array", proto: !0, forced: String(kp) === String(kp.reverse()) }, {
  reverse: function() {
    return ZR(this) && (this.length = this.length), QR(this);
  }
});
var eF = Ke, tF = eF("Array", "reverse"), rF = Me, iF = tF, Kd = Array.prototype, nF = function(i) {
  var e = i.reverse;
  return i === Kd || rF(Kd, i) && e === Kd.reverse ? iF : e;
}, oF = nF, Y1 = oF, sF = Y1, aF = /* @__PURE__ */ z(sF), Np = An, lF = TypeError, q1 = function(i, e) {
  if (!delete i[e]) throw new lF("Cannot delete property " + Np(e) + " of " + Np(i));
}, dF = F, hF = vt, cF = $l, uF = pl, fF = bt, vF = j1, pF = gl, gF = ml, yF = Dn, Yd = q1, mF = jo, bF = mF("splice"), $F = Math.max, wF = Math.min;
dF({ target: "Array", proto: !0, forced: !bF }, {
  splice: function(e, t) {
    var r = hF(this), n = fF(r), o = cF(e, n), s = arguments.length, a, l, d, h, c, u;
    for (s === 0 ? a = l = 0 : s === 1 ? (a = 0, l = n - o) : (a = s - 2, l = wF($F(uF(t), 0), n - o)), pF(n + a - l), d = gF(r, l), h = 0; h < l; h++)
      c = o + h, c in r && yF(d, h, r[c]);
    if (d.length = l, a < l) {
      for (h = o; h < n - l; h++)
        c = h + l, u = h + a, c in r ? r[u] = r[c] : Yd(r, u);
      for (h = n; h > n - l + a; h--) Yd(r, h - 1);
    } else if (a > l)
      for (h = n - l; h > o; h--)
        c = h + l - 1, u = h + a - 1, c in r ? r[u] = r[c] : Yd(r, u);
    for (h = 0; h < a; h++)
      r[h + o] = arguments[h + 2];
    return vF(r, n - l + a), d;
  }
});
var _F = Ke, EF = _F("Array", "splice"), SF = Me, OF = EF, qd = Array.prototype, TF = function(i) {
  var e = i.splice;
  return i === qd || SF(qd, i) && e === qd.splice ? OF : e;
}, IF = TF, PF = IF, xF = PF, X1 = /* @__PURE__ */ z(xF), Rp = Le, CF = he, AF = je, MF = ee, Xd = wl, DF = Ho, kF = hl, NF = vt, RF = cl, ji = Object.assign, Fp = Object.defineProperty, FF = CF([].concat), BF = !ji || MF(function() {
  if (Rp && ji({ b: 1 }, ji(Fp({}, "a", {
    enumerable: !0,
    get: function() {
      Fp(this, "b", {
        value: 3,
        enumerable: !1
      });
    }
  }), { b: 2 })).b !== 1) return !0;
  var i = {}, e = {}, t = Symbol("assign detection"), r = "abcdefghijklmnopqrst";
  return i[t] = 7, r.split("").forEach(function(n) {
    e[n] = n;
  }), ji({}, i)[t] !== 7 || Xd(ji({}, e)).join("") !== r;
}) ? function(e, t) {
  for (var r = NF(e), n = arguments.length, o = 1, s = DF.f, a = kF.f; n > o; )
    for (var l = RF(arguments[o++]), d = s ? FF(Xd(l), s(l)) : Xd(l), h = d.length, c = 0, u; h > c; )
      u = d[c++], (!Rp || AF(a, l, u)) && (r[u] = l[u]);
  return r;
} : ji, LF = F, Bp = BF;
LF({ target: "Object", stat: !0, forced: Object.assign !== Bp }, {
  assign: Bp
});
var jF = ve, zF = jF.Object.assign, WF = zF, HF = WF, VF = HF, UF = /* @__PURE__ */ z(VF), GF = F, KF = ee, YF = vt, J1 = Pl, qF = l1, XF = KF(function() {
  J1(1);
});
GF({ target: "Object", stat: !0, forced: XF, sham: !qF }, {
  getPrototypeOf: function(e) {
    return J1(YF(e));
  }
});
var JF = ve, ZF = JF.Object.getPrototypeOf, QF = ZF, eB = QF, tB = F, rB = Le, iB = Ii;
tB({ target: "Object", stat: !0, sham: !rB }, {
  create: iB
});
var nB = ve, oB = nB.Object, sB = function(e, t) {
  return oB.create(e, t);
}, aB = sB, Z1 = aB, lB = Z1, dB = /* @__PURE__ */ z(lB), Fc = ve, hB = In;
Fc.JSON || (Fc.JSON = { stringify: JSON.stringify });
var cB = function(e, t, r) {
  return hB(Fc.JSON.stringify, null, arguments);
}, uB = cB, fB = uB, vB = fB, pB = /* @__PURE__ */ z(vB), gB = typeof Bun == "function" && Bun && typeof Bun.version == "string", yB = TypeError, Q1 = function(i, e) {
  if (i < e) throw new yB("Not enough arguments");
  return i;
}, ew = fe, mB = In, bB = $e, $B = gB, wB = Vr, _B = Ko, EB = Q1, SB = ew.Function, OB = /MSIE .\./.test(wB) || $B && function() {
  var i = ew.Bun.version.split(".");
  return i.length < 3 || i[0] === "0" && (i[1] < 3 || i[1] === "3" && i[2] === "0");
}(), tw = function(i, e) {
  var t = e ? 2 : 1;
  return OB ? function(r, n) {
    var o = EB(arguments.length, 1) > t, s = bB(r) ? r : SB(r), a = o ? _B(arguments, t) : [], l = o ? function() {
      mB(s, this, a);
    } : s;
    return e ? i(l, n) : i(l);
  } : i;
}, TB = F, rw = fe, IB = tw, Lp = IB(rw.setInterval, !0);
TB({ global: !0, bind: !0, forced: rw.setInterval !== Lp }, {
  setInterval: Lp
});
var PB = F, iw = fe, xB = tw, jp = xB(iw.setTimeout, !0);
PB({ global: !0, bind: !0, forced: iw.setTimeout !== jp }, {
  setTimeout: jp
});
var CB = ve, AB = CB.setTimeout, MB = AB, DB = /* @__PURE__ */ z(MB), nw = { exports: {} };
(function(i) {
  function e(r) {
    if (r)
      return t(r);
    this._callbacks = /* @__PURE__ */ new Map();
  }
  function t(r) {
    return Object.assign(r, e.prototype), r._callbacks = /* @__PURE__ */ new Map(), r;
  }
  e.prototype.on = function(r, n) {
    const o = this._callbacks.get(r) ?? [];
    return o.push(n), this._callbacks.set(r, o), this;
  }, e.prototype.once = function(r, n) {
    const o = (...s) => {
      this.off(r, o), n.apply(this, s);
    };
    return o.fn = n, this.on(r, o), this;
  }, e.prototype.off = function(r, n) {
    if (r === void 0 && n === void 0)
      return this._callbacks.clear(), this;
    if (n === void 0)
      return this._callbacks.delete(r), this;
    const o = this._callbacks.get(r);
    if (o) {
      for (const [s, a] of o.entries())
        if (a === n || a.fn === n) {
          o.splice(s, 1);
          break;
        }
      o.length === 0 ? this._callbacks.delete(r) : this._callbacks.set(r, o);
    }
    return this;
  }, e.prototype.emit = function(r, ...n) {
    const o = this._callbacks.get(r);
    if (o) {
      const s = [...o];
      for (const a of s)
        a.apply(this, n);
    }
    return this;
  }, e.prototype.listeners = function(r) {
    return this._callbacks.get(r) ?? [];
  }, e.prototype.listenerCount = function(r) {
    if (r)
      return this.listeners(r).length;
    let n = 0;
    for (const o of this._callbacks.values())
      n += o.length;
    return n;
  }, e.prototype.hasListeners = function(r) {
    return this.listenerCount(r) > 0;
  }, e.prototype.addEventListener = e.prototype.on, e.prototype.removeListener = e.prototype.off, e.prototype.removeEventListener = e.prototype.off, e.prototype.removeAllListeners = e.prototype.off, i.exports = e;
})(nw);
var kB = nw.exports, NB = /* @__PURE__ */ z(kB);
/*! Hammer.JS - v2.0.17-rc - 2019-12-16
 * http://naver.github.io/egjs
 *
 * Forked By Naver egjs
 * Copyright (c) hammerjs
 * Licensed under the MIT license */
function Rt() {
  return Rt = Object.assign || function(i) {
    for (var e = 1; e < arguments.length; e++) {
      var t = arguments[e];
      for (var r in t)
        Object.prototype.hasOwnProperty.call(t, r) && (i[r] = t[r]);
    }
    return i;
  }, Rt.apply(this, arguments);
}
function It(i, e) {
  i.prototype = Object.create(e.prototype), i.prototype.constructor = i, i.__proto__ = e;
}
function Hs(i) {
  if (i === void 0)
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return i;
}
var Bc;
typeof Object.assign != "function" ? Bc = function(e) {
  if (e == null)
    throw new TypeError("Cannot convert undefined or null to object");
  for (var t = Object(e), r = 1; r < arguments.length; r++) {
    var n = arguments[r];
    if (n != null)
      for (var o in n)
        n.hasOwnProperty(o) && (t[o] = n[o]);
  }
  return t;
} : Bc = Object.assign;
var gi = Bc, zp = ["", "webkit", "Moz", "MS", "ms", "o"], RB = typeof document > "u" ? {
  style: {}
} : document.createElement("div"), FB = "function", Zi = Math.round, yi = Math.abs, Qu = Date.now;
function Nl(i, e) {
  for (var t, r, n = e[0].toUpperCase() + e.slice(1), o = 0; o < zp.length; ) {
    if (t = zp[o], r = t ? t + n : e, r in i)
      return r;
    o++;
  }
}
var ir;
typeof window > "u" ? ir = {} : ir = window;
var ow = Nl(RB.style, "touchAction"), sw = ow !== void 0;
function BB() {
  if (!sw)
    return !1;
  var i = {}, e = ir.CSS && ir.CSS.supports;
  return ["auto", "manipulation", "pan-y", "pan-x", "pan-x pan-y", "none"].forEach(function(t) {
    return i[t] = e ? ir.CSS.supports("touch-action", t) : !0;
  }), i;
}
var aw = "compute", lw = "auto", Lc = "manipulation", ai = "none", _o = "pan-x", Eo = "pan-y", Vs = BB(), LB = /mobile|tablet|ip(ad|hone|od)|android/i, dw = "ontouchstart" in ir, jB = Nl(ir, "PointerEvent") !== void 0, zB = dw && LB.test(navigator.userAgent), Xo = "touch", WB = "pen", ef = "mouse", HB = "kinect", VB = 25, Qe = 1, xi = 2, xe = 4, ct = 8, Wa = 1, Jo = 2, Zo = 4, Qo = 8, pn = 16, qt = Jo | Zo, li = Qo | pn, hw = qt | li, cw = ["x", "y"], Ha = ["clientX", "clientY"];
function nr(i, e, t) {
  var r;
  if (i)
    if (i.forEach)
      i.forEach(e, t);
    else if (i.length !== void 0)
      for (r = 0; r < i.length; )
        e.call(t, i[r], r, i), r++;
    else
      for (r in i)
        i.hasOwnProperty(r) && e.call(t, i[r], r, i);
}
function Rl(i, e) {
  return typeof i === FB ? i.apply(e && e[0] || void 0, e) : i;
}
function ti(i, e) {
  return i.indexOf(e) > -1;
}
function UB(i) {
  if (ti(i, ai))
    return ai;
  var e = ti(i, _o), t = ti(i, Eo);
  return e && t ? ai : e || t ? e ? _o : Eo : ti(i, Lc) ? Lc : lw;
}
var uw = /* @__PURE__ */ function() {
  function i(t, r) {
    this.manager = t, this.set(r);
  }
  var e = i.prototype;
  return e.set = function(r) {
    r === aw && (r = this.compute()), sw && this.manager.element.style && Vs[r] && (this.manager.element.style[ow] = r), this.actions = r.toLowerCase().trim();
  }, e.update = function() {
    this.set(this.manager.options.touchAction);
  }, e.compute = function() {
    var r = [];
    return nr(this.manager.recognizers, function(n) {
      Rl(n.options.enable, [n]) && (r = r.concat(n.getTouchAction()));
    }), UB(r.join(" "));
  }, e.preventDefaults = function(r) {
    var n = r.srcEvent, o = r.offsetDirection;
    if (this.manager.session.prevented) {
      n.preventDefault();
      return;
    }
    var s = this.actions, a = ti(s, ai) && !Vs[ai], l = ti(s, Eo) && !Vs[Eo], d = ti(s, _o) && !Vs[_o];
    if (a) {
      var h = r.pointers.length === 1, c = r.distance < 2, u = r.deltaTime < 250;
      if (h && c && u)
        return;
    }
    if (!(d && l) && (a || l && o & qt || d && o & li))
      return this.preventSrc(n);
  }, e.preventSrc = function(r) {
    this.manager.session.prevented = !0, r.preventDefault();
  }, i;
}();
function tf(i, e) {
  for (; i; ) {
    if (i === e)
      return !0;
    i = i.parentNode;
  }
  return !1;
}
function fw(i) {
  var e = i.length;
  if (e === 1)
    return {
      x: Zi(i[0].clientX),
      y: Zi(i[0].clientY)
    };
  for (var t = 0, r = 0, n = 0; n < e; )
    t += i[n].clientX, r += i[n].clientY, n++;
  return {
    x: Zi(t / e),
    y: Zi(r / e)
  };
}
function Wp(i) {
  for (var e = [], t = 0; t < i.pointers.length; )
    e[t] = {
      clientX: Zi(i.pointers[t].clientX),
      clientY: Zi(i.pointers[t].clientY)
    }, t++;
  return {
    timeStamp: Qu(),
    pointers: e,
    center: fw(e),
    deltaX: i.deltaX,
    deltaY: i.deltaY
  };
}
function Va(i, e, t) {
  t || (t = cw);
  var r = e[t[0]] - i[t[0]], n = e[t[1]] - i[t[1]];
  return Math.sqrt(r * r + n * n);
}
function jc(i, e, t) {
  t || (t = cw);
  var r = e[t[0]] - i[t[0]], n = e[t[1]] - i[t[1]];
  return Math.atan2(n, r) * 180 / Math.PI;
}
function vw(i, e) {
  return i === e ? Wa : yi(i) >= yi(e) ? i < 0 ? Jo : Zo : e < 0 ? Qo : pn;
}
function GB(i, e) {
  var t = e.center, r = i.offsetDelta || {}, n = i.prevDelta || {}, o = i.prevInput || {};
  (e.eventType === Qe || o.eventType === xe) && (n = i.prevDelta = {
    x: o.deltaX || 0,
    y: o.deltaY || 0
  }, r = i.offsetDelta = {
    x: t.x,
    y: t.y
  }), e.deltaX = n.x + (t.x - r.x), e.deltaY = n.y + (t.y - r.y);
}
function pw(i, e, t) {
  return {
    x: e / i || 0,
    y: t / i || 0
  };
}
function KB(i, e) {
  return Va(e[0], e[1], Ha) / Va(i[0], i[1], Ha);
}
function YB(i, e) {
  return jc(e[1], e[0], Ha) + jc(i[1], i[0], Ha);
}
function qB(i, e) {
  var t = i.lastInterval || e, r = e.timeStamp - t.timeStamp, n, o, s, a;
  if (e.eventType !== ct && (r > VB || t.velocity === void 0)) {
    var l = e.deltaX - t.deltaX, d = e.deltaY - t.deltaY, h = pw(r, l, d);
    o = h.x, s = h.y, n = yi(h.x) > yi(h.y) ? h.x : h.y, a = vw(l, d), i.lastInterval = e;
  } else
    n = t.velocity, o = t.velocityX, s = t.velocityY, a = t.direction;
  e.velocity = n, e.velocityX = o, e.velocityY = s, e.direction = a;
}
function XB(i, e) {
  var t = i.session, r = e.pointers, n = r.length;
  t.firstInput || (t.firstInput = Wp(e)), n > 1 && !t.firstMultiple ? t.firstMultiple = Wp(e) : n === 1 && (t.firstMultiple = !1);
  var o = t.firstInput, s = t.firstMultiple, a = s ? s.center : o.center, l = e.center = fw(r);
  e.timeStamp = Qu(), e.deltaTime = e.timeStamp - o.timeStamp, e.angle = jc(a, l), e.distance = Va(a, l), GB(t, e), e.offsetDirection = vw(e.deltaX, e.deltaY);
  var d = pw(e.deltaTime, e.deltaX, e.deltaY);
  e.overallVelocityX = d.x, e.overallVelocityY = d.y, e.overallVelocity = yi(d.x) > yi(d.y) ? d.x : d.y, e.scale = s ? KB(s.pointers, r) : 1, e.rotation = s ? YB(s.pointers, r) : 0, e.maxPointers = t.prevInput ? e.pointers.length > t.prevInput.maxPointers ? e.pointers.length : t.prevInput.maxPointers : e.pointers.length, qB(t, e);
  var h = i.element, c = e.srcEvent, u;
  c.composedPath ? u = c.composedPath()[0] : c.path ? u = c.path[0] : u = c.target, tf(u, h) && (h = u), e.target = h;
}
function JB(i, e, t) {
  var r = t.pointers.length, n = t.changedPointers.length, o = e & Qe && r - n === 0, s = e & (xe | ct) && r - n === 0;
  t.isFirst = !!o, t.isFinal = !!s, o && (i.session = {}), t.eventType = e, XB(i, t), i.emit("hammer.input", t), i.recognize(t), i.session.prevInput = t;
}
function So(i) {
  return i.trim().split(/\s+/g);
}
function lo(i, e, t) {
  nr(So(e), function(r) {
    i.addEventListener(r, t, !1);
  });
}
function ho(i, e, t) {
  nr(So(e), function(r) {
    i.removeEventListener(r, t, !1);
  });
}
function Hp(i) {
  var e = i.ownerDocument || i;
  return e.defaultView || e.parentWindow || window;
}
var Bn = /* @__PURE__ */ function() {
  function i(t, r) {
    var n = this;
    this.manager = t, this.callback = r, this.element = t.element, this.target = t.options.inputTarget, this.domHandler = function(o) {
      Rl(t.options.enable, [t]) && n.handler(o);
    }, this.init();
  }
  var e = i.prototype;
  return e.handler = function() {
  }, e.init = function() {
    this.evEl && lo(this.element, this.evEl, this.domHandler), this.evTarget && lo(this.target, this.evTarget, this.domHandler), this.evWin && lo(Hp(this.element), this.evWin, this.domHandler);
  }, e.destroy = function() {
    this.evEl && ho(this.element, this.evEl, this.domHandler), this.evTarget && ho(this.target, this.evTarget, this.domHandler), this.evWin && ho(Hp(this.element), this.evWin, this.domHandler);
  }, i;
}();
function mi(i, e, t) {
  if (i.indexOf && !t)
    return i.indexOf(e);
  for (var r = 0; r < i.length; ) {
    if (t && i[r][t] == e || !t && i[r] === e)
      return r;
    r++;
  }
  return -1;
}
var ZB = {
  pointerdown: Qe,
  pointermove: xi,
  pointerup: xe,
  pointercancel: ct,
  pointerout: ct
}, QB = {
  2: Xo,
  3: WB,
  4: ef,
  5: HB
  // see https://twitter.com/jacobrossi/status/480596438489890816
}, gw = "pointerdown", yw = "pointermove pointerup pointercancel";
ir.MSPointerEvent && !ir.PointerEvent && (gw = "MSPointerDown", yw = "MSPointerMove MSPointerUp MSPointerCancel");
var mw = /* @__PURE__ */ function(i) {
  It(e, i);
  function e() {
    var r, n = e.prototype;
    return n.evEl = gw, n.evWin = yw, r = i.apply(this, arguments) || this, r.store = r.manager.session.pointerEvents = [], r;
  }
  var t = e.prototype;
  return t.handler = function(n) {
    var o = this.store, s = !1, a = n.type.toLowerCase().replace("ms", ""), l = ZB[a], d = QB[n.pointerType] || n.pointerType, h = d === Xo, c = mi(o, n.pointerId, "pointerId");
    l & Qe && (n.button === 0 || h) ? c < 0 && (o.push(n), c = o.length - 1) : l & (xe | ct) && (s = !0), !(c < 0) && (o[c] = n, this.callback(this.manager, l, {
      pointers: o,
      changedPointers: [n],
      pointerType: d,
      srcEvent: n
    }), s && o.splice(c, 1));
  }, e;
}(Bn);
function Oo(i) {
  return Array.prototype.slice.call(i, 0);
}
function rf(i, e, t) {
  for (var r = [], n = [], o = 0; o < i.length; ) {
    var s = e ? i[o][e] : i[o];
    mi(n, s) < 0 && r.push(i[o]), n[o] = s, o++;
  }
  return t && (e ? r = r.sort(function(a, l) {
    return a[e] > l[e];
  }) : r = r.sort()), r;
}
var eL = {
  touchstart: Qe,
  touchmove: xi,
  touchend: xe,
  touchcancel: ct
}, tL = "touchstart touchmove touchend touchcancel", nf = /* @__PURE__ */ function(i) {
  It(e, i);
  function e() {
    var r;
    return e.prototype.evTarget = tL, r = i.apply(this, arguments) || this, r.targetIds = {}, r;
  }
  var t = e.prototype;
  return t.handler = function(n) {
    var o = eL[n.type], s = rL.call(this, n, o);
    s && this.callback(this.manager, o, {
      pointers: s[0],
      changedPointers: s[1],
      pointerType: Xo,
      srcEvent: n
    });
  }, e;
}(Bn);
function rL(i, e) {
  var t = Oo(i.touches), r = this.targetIds;
  if (e & (Qe | xi) && t.length === 1)
    return r[t[0].identifier] = !0, [t, t];
  var n, o, s = Oo(i.changedTouches), a = [], l = this.target;
  if (o = t.filter(function(d) {
    return tf(d.target, l);
  }), e === Qe)
    for (n = 0; n < o.length; )
      r[o[n].identifier] = !0, n++;
  for (n = 0; n < s.length; )
    r[s[n].identifier] && a.push(s[n]), e & (xe | ct) && delete r[s[n].identifier], n++;
  if (a.length)
    return [
      // merge targetTouches with changedTargetTouches so it contains ALL touches, including 'end' and 'cancel'
      rf(o.concat(a), "identifier", !0),
      a
    ];
}
var iL = {
  mousedown: Qe,
  mousemove: xi,
  mouseup: xe
}, nL = "mousedown", oL = "mousemove mouseup", of = /* @__PURE__ */ function(i) {
  It(e, i);
  function e() {
    var r, n = e.prototype;
    return n.evEl = nL, n.evWin = oL, r = i.apply(this, arguments) || this, r.pressed = !1, r;
  }
  var t = e.prototype;
  return t.handler = function(n) {
    var o = iL[n.type];
    o & Qe && n.button === 0 && (this.pressed = !0), o & xi && n.which !== 1 && (o = xe), this.pressed && (o & xe && (this.pressed = !1), this.callback(this.manager, o, {
      pointers: [n],
      changedPointers: [n],
      pointerType: ef,
      srcEvent: n
    }));
  }, e;
}(Bn), sL = 2500, Vp = 25;
function Up(i) {
  var e = i.changedPointers, t = e[0];
  if (t.identifier === this.primaryTouch) {
    var r = {
      x: t.clientX,
      y: t.clientY
    }, n = this.lastTouches;
    this.lastTouches.push(r);
    var o = function() {
      var a = n.indexOf(r);
      a > -1 && n.splice(a, 1);
    };
    setTimeout(o, sL);
  }
}
function aL(i, e) {
  i & Qe ? (this.primaryTouch = e.changedPointers[0].identifier, Up.call(this, e)) : i & (xe | ct) && Up.call(this, e);
}
function lL(i) {
  for (var e = i.srcEvent.clientX, t = i.srcEvent.clientY, r = 0; r < this.lastTouches.length; r++) {
    var n = this.lastTouches[r], o = Math.abs(e - n.x), s = Math.abs(t - n.y);
    if (o <= Vp && s <= Vp)
      return !0;
  }
  return !1;
}
var bw = /* @__PURE__ */ function() {
  var i = /* @__PURE__ */ function(e) {
    It(t, e);
    function t(n, o) {
      var s;
      return s = e.call(this, n, o) || this, s.handler = function(a, l, d) {
        var h = d.pointerType === Xo, c = d.pointerType === ef;
        if (!(c && d.sourceCapabilities && d.sourceCapabilities.firesTouchEvents)) {
          if (h)
            aL.call(Hs(Hs(s)), l, d);
          else if (c && lL.call(Hs(Hs(s)), d))
            return;
          s.callback(a, l, d);
        }
      }, s.touch = new nf(s.manager, s.handler), s.mouse = new of(s.manager, s.handler), s.primaryTouch = null, s.lastTouches = [], s;
    }
    var r = t.prototype;
    return r.destroy = function() {
      this.touch.destroy(), this.mouse.destroy();
    }, t;
  }(Bn);
  return i;
}();
function dL(i) {
  var e, t = i.options.inputClass;
  return t ? e = t : jB ? e = mw : zB ? e = nf : dw ? e = bw : e = of, new e(i, JB);
}
function Qi(i, e, t) {
  return Array.isArray(i) ? (nr(i, t[e], t), !0) : !1;
}
var Ea = 1, Ot = 2, gn = 4, Mr = 8, or = Mr, To = 16, Gt = 32, hL = 1;
function cL() {
  return hL++;
}
function Us(i, e) {
  var t = e.manager;
  return t ? t.get(i) : i;
}
function Gp(i) {
  return i & To ? "cancel" : i & Mr ? "end" : i & gn ? "move" : i & Ot ? "start" : "";
}
var es = /* @__PURE__ */ function() {
  function i(t) {
    t === void 0 && (t = {}), this.options = Rt({
      enable: !0
    }, t), this.id = cL(), this.manager = null, this.state = Ea, this.simultaneous = {}, this.requireFail = [];
  }
  var e = i.prototype;
  return e.set = function(r) {
    return gi(this.options, r), this.manager && this.manager.touchAction.update(), this;
  }, e.recognizeWith = function(r) {
    if (Qi(r, "recognizeWith", this))
      return this;
    var n = this.simultaneous;
    return r = Us(r, this), n[r.id] || (n[r.id] = r, r.recognizeWith(this)), this;
  }, e.dropRecognizeWith = function(r) {
    return Qi(r, "dropRecognizeWith", this) ? this : (r = Us(r, this), delete this.simultaneous[r.id], this);
  }, e.requireFailure = function(r) {
    if (Qi(r, "requireFailure", this))
      return this;
    var n = this.requireFail;
    return r = Us(r, this), mi(n, r) === -1 && (n.push(r), r.requireFailure(this)), this;
  }, e.dropRequireFailure = function(r) {
    if (Qi(r, "dropRequireFailure", this))
      return this;
    r = Us(r, this);
    var n = mi(this.requireFail, r);
    return n > -1 && this.requireFail.splice(n, 1), this;
  }, e.hasRequireFailures = function() {
    return this.requireFail.length > 0;
  }, e.canRecognizeWith = function(r) {
    return !!this.simultaneous[r.id];
  }, e.emit = function(r) {
    var n = this, o = this.state;
    function s(a) {
      n.manager.emit(a, r);
    }
    o < Mr && s(n.options.event + Gp(o)), s(n.options.event), r.additionalEvent && s(r.additionalEvent), o >= Mr && s(n.options.event + Gp(o));
  }, e.tryEmit = function(r) {
    if (this.canEmit())
      return this.emit(r);
    this.state = Gt;
  }, e.canEmit = function() {
    for (var r = 0; r < this.requireFail.length; ) {
      if (!(this.requireFail[r].state & (Gt | Ea)))
        return !1;
      r++;
    }
    return !0;
  }, e.recognize = function(r) {
    var n = gi({}, r);
    if (!Rl(this.options.enable, [this, n])) {
      this.reset(), this.state = Gt;
      return;
    }
    this.state & (or | To | Gt) && (this.state = Ea), this.state = this.process(n), this.state & (Ot | gn | Mr | To) && this.tryEmit(n);
  }, e.process = function(r) {
  }, e.getTouchAction = function() {
  }, e.reset = function() {
  }, i;
}(), zc = /* @__PURE__ */ function(i) {
  It(e, i);
  function e(r) {
    var n;
    return r === void 0 && (r = {}), n = i.call(this, Rt({
      event: "tap",
      pointers: 1,
      taps: 1,
      interval: 300,
      // max time between the multi-tap taps
      time: 250,
      // max time of the pointer to be down (like finger on the screen)
      threshold: 9,
      // a minimal movement is ok, but keep it low
      posThreshold: 10
    }, r)) || this, n.pTime = !1, n.pCenter = !1, n._timer = null, n._input = null, n.count = 0, n;
  }
  var t = e.prototype;
  return t.getTouchAction = function() {
    return [Lc];
  }, t.process = function(n) {
    var o = this, s = this.options, a = n.pointers.length === s.pointers, l = n.distance < s.threshold, d = n.deltaTime < s.time;
    if (this.reset(), n.eventType & Qe && this.count === 0)
      return this.failTimeout();
    if (l && d && a) {
      if (n.eventType !== xe)
        return this.failTimeout();
      var h = this.pTime ? n.timeStamp - this.pTime < s.interval : !0, c = !this.pCenter || Va(this.pCenter, n.center) < s.posThreshold;
      this.pTime = n.timeStamp, this.pCenter = n.center, !c || !h ? this.count = 1 : this.count += 1, this._input = n;
      var u = this.count % s.taps;
      if (u === 0)
        return this.hasRequireFailures() ? (this._timer = setTimeout(function() {
          o.state = or, o.tryEmit();
        }, s.interval), Ot) : or;
    }
    return Gt;
  }, t.failTimeout = function() {
    var n = this;
    return this._timer = setTimeout(function() {
      n.state = Gt;
    }, this.options.interval), Gt;
  }, t.reset = function() {
    clearTimeout(this._timer);
  }, t.emit = function() {
    this.state === or && (this._input.tapCount = this.count, this.manager.emit(this.options.event, this._input));
  }, e;
}(es), yn = /* @__PURE__ */ function(i) {
  It(e, i);
  function e(r) {
    return r === void 0 && (r = {}), i.call(this, Rt({
      pointers: 1
    }, r)) || this;
  }
  var t = e.prototype;
  return t.attrTest = function(n) {
    var o = this.options.pointers;
    return o === 0 || n.pointers.length === o;
  }, t.process = function(n) {
    var o = this.state, s = n.eventType, a = o & (Ot | gn), l = this.attrTest(n);
    return a && (s & ct || !l) ? o | To : a || l ? s & xe ? o | Mr : o & Ot ? o | gn : Ot : Gt;
  }, e;
}(es);
function $w(i) {
  return i === pn ? "down" : i === Qo ? "up" : i === Jo ? "left" : i === Zo ? "right" : "";
}
var sf = /* @__PURE__ */ function(i) {
  It(e, i);
  function e(r) {
    var n;
    return r === void 0 && (r = {}), n = i.call(this, Rt({
      event: "pan",
      threshold: 10,
      pointers: 1,
      direction: hw
    }, r)) || this, n.pX = null, n.pY = null, n;
  }
  var t = e.prototype;
  return t.getTouchAction = function() {
    var n = this.options.direction, o = [];
    return n & qt && o.push(Eo), n & li && o.push(_o), o;
  }, t.directionTest = function(n) {
    var o = this.options, s = !0, a = n.distance, l = n.direction, d = n.deltaX, h = n.deltaY;
    return l & o.direction || (o.direction & qt ? (l = d === 0 ? Wa : d < 0 ? Jo : Zo, s = d !== this.pX, a = Math.abs(n.deltaX)) : (l = h === 0 ? Wa : h < 0 ? Qo : pn, s = h !== this.pY, a = Math.abs(n.deltaY))), n.direction = l, s && a > o.threshold && l & o.direction;
  }, t.attrTest = function(n) {
    return yn.prototype.attrTest.call(this, n) && // replace with a super call
    (this.state & Ot || !(this.state & Ot) && this.directionTest(n));
  }, t.emit = function(n) {
    this.pX = n.deltaX, this.pY = n.deltaY;
    var o = $w(n.direction);
    o && (n.additionalEvent = this.options.event + o), i.prototype.emit.call(this, n);
  }, e;
}(yn), ww = /* @__PURE__ */ function(i) {
  It(e, i);
  function e(r) {
    return r === void 0 && (r = {}), i.call(this, Rt({
      event: "swipe",
      threshold: 10,
      velocity: 0.3,
      direction: qt | li,
      pointers: 1
    }, r)) || this;
  }
  var t = e.prototype;
  return t.getTouchAction = function() {
    return sf.prototype.getTouchAction.call(this);
  }, t.attrTest = function(n) {
    var o = this.options.direction, s;
    return o & (qt | li) ? s = n.overallVelocity : o & qt ? s = n.overallVelocityX : o & li && (s = n.overallVelocityY), i.prototype.attrTest.call(this, n) && o & n.offsetDirection && n.distance > this.options.threshold && n.maxPointers === this.options.pointers && yi(s) > this.options.velocity && n.eventType & xe;
  }, t.emit = function(n) {
    var o = $w(n.offsetDirection);
    o && this.manager.emit(this.options.event + o, n), this.manager.emit(this.options.event, n);
  }, e;
}(yn), _w = /* @__PURE__ */ function(i) {
  It(e, i);
  function e(r) {
    return r === void 0 && (r = {}), i.call(this, Rt({
      event: "pinch",
      threshold: 0,
      pointers: 2
    }, r)) || this;
  }
  var t = e.prototype;
  return t.getTouchAction = function() {
    return [ai];
  }, t.attrTest = function(n) {
    return i.prototype.attrTest.call(this, n) && (Math.abs(n.scale - 1) > this.options.threshold || this.state & Ot);
  }, t.emit = function(n) {
    if (n.scale !== 1) {
      var o = n.scale < 1 ? "in" : "out";
      n.additionalEvent = this.options.event + o;
    }
    i.prototype.emit.call(this, n);
  }, e;
}(yn), Ew = /* @__PURE__ */ function(i) {
  It(e, i);
  function e(r) {
    return r === void 0 && (r = {}), i.call(this, Rt({
      event: "rotate",
      threshold: 0,
      pointers: 2
    }, r)) || this;
  }
  var t = e.prototype;
  return t.getTouchAction = function() {
    return [ai];
  }, t.attrTest = function(n) {
    return i.prototype.attrTest.call(this, n) && (Math.abs(n.rotation) > this.options.threshold || this.state & Ot);
  }, e;
}(yn), Sw = /* @__PURE__ */ function(i) {
  It(e, i);
  function e(r) {
    var n;
    return r === void 0 && (r = {}), n = i.call(this, Rt({
      event: "press",
      pointers: 1,
      time: 251,
      // minimal time of the pointer to be pressed
      threshold: 9
    }, r)) || this, n._timer = null, n._input = null, n;
  }
  var t = e.prototype;
  return t.getTouchAction = function() {
    return [lw];
  }, t.process = function(n) {
    var o = this, s = this.options, a = n.pointers.length === s.pointers, l = n.distance < s.threshold, d = n.deltaTime > s.time;
    if (this._input = n, !l || !a || n.eventType & (xe | ct) && !d)
      this.reset();
    else if (n.eventType & Qe)
      this.reset(), this._timer = setTimeout(function() {
        o.state = or, o.tryEmit();
      }, s.time);
    else if (n.eventType & xe)
      return or;
    return Gt;
  }, t.reset = function() {
    clearTimeout(this._timer);
  }, t.emit = function(n) {
    this.state === or && (n && n.eventType & xe ? this.manager.emit(this.options.event + "up", n) : (this._input.timeStamp = Qu(), this.manager.emit(this.options.event, this._input)));
  }, e;
}(es), Ow = {
  /**
   * @private
   * set if DOM events are being triggered.
   * But this is slower and unused by simple implementations, so disabled by default.
   * @type {Boolean}
   * @default false
   */
  domEvents: !1,
  /**
   * @private
   * The value for the touchAction property/fallback.
   * When set to `compute` it will magically set the correct value based on the added recognizers.
   * @type {String}
   * @default compute
   */
  touchAction: aw,
  /**
   * @private
   * @type {Boolean}
   * @default true
   */
  enable: !0,
  /**
   * @private
   * EXPERIMENTAL FEATURE -- can be removed/changed
   * Change the parent input target element.
   * If Null, then it is being set the to main element.
   * @type {Null|EventTarget}
   * @default null
   */
  inputTarget: null,
  /**
   * @private
   * force an input class
   * @type {Null|Function}
   * @default null
   */
  inputClass: null,
  /**
   * @private
   * Some CSS properties can be used to improve the working of Hammer.
   * Add them to this method and they will be set when creating a new Manager.
   * @namespace
   */
  cssProps: {
    /**
     * @private
     * Disables text selection to improve the dragging gesture. Mainly for desktop browsers.
     * @type {String}
     * @default 'none'
     */
    userSelect: "none",
    /**
     * @private
     * Disable the Windows Phone grippers when pressing an element.
     * @type {String}
     * @default 'none'
     */
    touchSelect: "none",
    /**
     * @private
     * Disables the default callout shown when you touch and hold a touch target.
     * On iOS, when you touch and hold a touch target such as a link, Safari displays
     * a callout containing information about the link. This property allows you to disable that callout.
     * @type {String}
     * @default 'none'
     */
    touchCallout: "none",
    /**
     * @private
     * Specifies whether zooming is enabled. Used by IE10>
     * @type {String}
     * @default 'none'
     */
    contentZooming: "none",
    /**
     * @private
     * Specifies that an entire element should be draggable instead of its contents. Mainly for desktop browsers.
     * @type {String}
     * @default 'none'
     */
    userDrag: "none",
    /**
     * @private
     * Overrides the highlight color shown when the user taps a link or a JavaScript
     * clickable element in iOS. This property obeys the alpha value, if specified.
     * @type {String}
     * @default 'rgba(0,0,0,0)'
     */
    tapHighlightColor: "rgba(0,0,0,0)"
  }
}, Kp = [[Ew, {
  enable: !1
}], [_w, {
  enable: !1
}, ["rotate"]], [ww, {
  direction: qt
}], [sf, {
  direction: qt
}, ["swipe"]], [zc], [zc, {
  event: "doubletap",
  taps: 2
}, ["tap"]], [Sw]], uL = 1, Yp = 2;
function qp(i, e) {
  var t = i.element;
  if (t.style) {
    var r;
    nr(i.options.cssProps, function(n, o) {
      r = Nl(t.style, o), e ? (i.oldCssProps[r] = t.style[r], t.style[r] = n) : t.style[r] = i.oldCssProps[r] || "";
    }), e || (i.oldCssProps = {});
  }
}
function fL(i, e) {
  var t = document.createEvent("Event");
  t.initEvent(i, !0, !0), t.gesture = e, e.target.dispatchEvent(t);
}
var Xp = /* @__PURE__ */ function() {
  function i(t, r) {
    var n = this;
    this.options = gi({}, Ow, r || {}), this.options.inputTarget = this.options.inputTarget || t, this.handlers = {}, this.session = {}, this.recognizers = [], this.oldCssProps = {}, this.element = t, this.input = dL(this), this.touchAction = new uw(this, this.options.touchAction), qp(this, !0), nr(this.options.recognizers, function(o) {
      var s = n.add(new o[0](o[1]));
      o[2] && s.recognizeWith(o[2]), o[3] && s.requireFailure(o[3]);
    }, this);
  }
  var e = i.prototype;
  return e.set = function(r) {
    return gi(this.options, r), r.touchAction && this.touchAction.update(), r.inputTarget && (this.input.destroy(), this.input.target = r.inputTarget, this.input.init()), this;
  }, e.stop = function(r) {
    this.session.stopped = r ? Yp : uL;
  }, e.recognize = function(r) {
    var n = this.session;
    if (!n.stopped) {
      this.touchAction.preventDefaults(r);
      var o, s = this.recognizers, a = n.curRecognizer;
      (!a || a && a.state & or) && (n.curRecognizer = null, a = null);
      for (var l = 0; l < s.length; )
        o = s[l], n.stopped !== Yp && // 1
        (!a || o === a || // 2
        o.canRecognizeWith(a)) ? o.recognize(r) : o.reset(), !a && o.state & (Ot | gn | Mr) && (n.curRecognizer = o, a = o), l++;
    }
  }, e.get = function(r) {
    if (r instanceof es)
      return r;
    for (var n = this.recognizers, o = 0; o < n.length; o++)
      if (n[o].options.event === r)
        return n[o];
    return null;
  }, e.add = function(r) {
    if (Qi(r, "add", this))
      return this;
    var n = this.get(r.options.event);
    return n && this.remove(n), this.recognizers.push(r), r.manager = this, this.touchAction.update(), r;
  }, e.remove = function(r) {
    if (Qi(r, "remove", this))
      return this;
    var n = this.get(r);
    if (r) {
      var o = this.recognizers, s = mi(o, n);
      s !== -1 && (o.splice(s, 1), this.touchAction.update());
    }
    return this;
  }, e.on = function(r, n) {
    if (r === void 0 || n === void 0)
      return this;
    var o = this.handlers;
    return nr(So(r), function(s) {
      o[s] = o[s] || [], o[s].push(n);
    }), this;
  }, e.off = function(r, n) {
    if (r === void 0)
      return this;
    var o = this.handlers;
    return nr(So(r), function(s) {
      n ? o[s] && o[s].splice(mi(o[s], n), 1) : delete o[s];
    }), this;
  }, e.emit = function(r, n) {
    this.options.domEvents && fL(r, n);
    var o = this.handlers[r] && this.handlers[r].slice();
    if (!(!o || !o.length)) {
      n.type = r, n.preventDefault = function() {
        n.srcEvent.preventDefault();
      };
      for (var s = 0; s < o.length; )
        o[s](n), s++;
    }
  }, e.destroy = function() {
    this.element && qp(this, !1), this.handlers = {}, this.session = {}, this.input.destroy(), this.element = null;
  }, i;
}(), vL = {
  touchstart: Qe,
  touchmove: xi,
  touchend: xe,
  touchcancel: ct
}, pL = "touchstart", gL = "touchstart touchmove touchend touchcancel", yL = /* @__PURE__ */ function(i) {
  It(e, i);
  function e() {
    var r, n = e.prototype;
    return n.evTarget = pL, n.evWin = gL, r = i.apply(this, arguments) || this, r.started = !1, r;
  }
  var t = e.prototype;
  return t.handler = function(n) {
    var o = vL[n.type];
    if (o === Qe && (this.started = !0), !!this.started) {
      var s = mL.call(this, n, o);
      o & (xe | ct) && s[0].length - s[1].length === 0 && (this.started = !1), this.callback(this.manager, o, {
        pointers: s[0],
        changedPointers: s[1],
        pointerType: Xo,
        srcEvent: n
      });
    }
  }, e;
}(Bn);
function mL(i, e) {
  var t = Oo(i.touches), r = Oo(i.changedTouches);
  return e & (xe | ct) && (t = rf(t.concat(r), "identifier", !0)), [t, r];
}
function Tw(i, e, t) {
  var r = "DEPRECATED METHOD: " + e + `
` + t + ` AT 
`;
  return function() {
    var n = new Error("get-stack-trace"), o = n && n.stack ? n.stack.replace(/^[^\(]+?[\n$]/gm, "").replace(/^\s+at\s+/gm, "").replace(/^Object.<anonymous>\s*\(/gm, "{anonymous}()@") : "Unknown Stack Trace", s = window.console && (window.console.warn || window.console.log);
    return s && s.call(window.console, r, o), i.apply(this, arguments);
  };
}
var Iw = Tw(function(i, e, t) {
  for (var r = Object.keys(e), n = 0; n < r.length; )
    (!t || t && i[r[n]] === void 0) && (i[r[n]] = e[r[n]]), n++;
  return i;
}, "extend", "Use `assign`."), bL = Tw(function(i, e) {
  return Iw(i, e, !0);
}, "merge", "Use `assign`.");
function $L(i, e, t) {
  var r = e.prototype, n;
  n = i.prototype = Object.create(r), n.constructor = i, n._super = r, t && gi(n, t);
}
function Jp(i, e) {
  return function() {
    return i.apply(e, arguments);
  };
}
var wL = /* @__PURE__ */ function() {
  var i = (
    /**
      * @private
      * @const {string}
      */
    function(t, r) {
      return r === void 0 && (r = {}), new Xp(t, Rt({
        recognizers: Kp.concat()
      }, r));
    }
  );
  return i.VERSION = "2.0.17-rc", i.DIRECTION_ALL = hw, i.DIRECTION_DOWN = pn, i.DIRECTION_LEFT = Jo, i.DIRECTION_RIGHT = Zo, i.DIRECTION_UP = Qo, i.DIRECTION_HORIZONTAL = qt, i.DIRECTION_VERTICAL = li, i.DIRECTION_NONE = Wa, i.DIRECTION_DOWN = pn, i.INPUT_START = Qe, i.INPUT_MOVE = xi, i.INPUT_END = xe, i.INPUT_CANCEL = ct, i.STATE_POSSIBLE = Ea, i.STATE_BEGAN = Ot, i.STATE_CHANGED = gn, i.STATE_ENDED = Mr, i.STATE_RECOGNIZED = or, i.STATE_CANCELLED = To, i.STATE_FAILED = Gt, i.Manager = Xp, i.Input = Bn, i.TouchAction = uw, i.TouchInput = nf, i.MouseInput = of, i.PointerEventInput = mw, i.TouchMouseInput = bw, i.SingleTouchInput = yL, i.Recognizer = es, i.AttrRecognizer = yn, i.Tap = zc, i.Pan = sf, i.Swipe = ww, i.Pinch = _w, i.Rotate = Ew, i.Press = Sw, i.on = lo, i.off = ho, i.each = nr, i.merge = bL, i.extend = Iw, i.bindFn = Jp, i.assign = gi, i.inherit = $L, i.bindFn = Jp, i.prefixed = Nl, i.toArray = Oo, i.inArray = mi, i.uniqueArray = rf, i.splitStr = So, i.boolOrFn = Rl, i.hasParent = tf, i.addEventListeners = lo, i.removeEventListeners = ho, i.defaults = gi({}, Ow, {
    preset: Kp
  }), i;
}(), _L = wL;
function Pw(i, e) {
  var t = typeof Ml < "u" && Xu(i) || i["@@iterator"];
  if (!t) {
    if (gt(i) || (t = EL(i)) || e) {
      t && (i = t);
      var r = 0, n = function() {
      };
      return { s: n, n: function() {
        return r >= i.length ? { done: !0 } : { done: !1, value: i[r++] };
      }, e: function(d) {
        throw d;
      }, f: n };
    }
    throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
  }
  var o = !0, s = !1, a;
  return { s: function() {
    t = t.call(i);
  }, n: function() {
    var d = t.next();
    return o = d.done, d;
  }, e: function(d) {
    s = !0, a = d;
  }, f: function() {
    try {
      !o && t.return != null && t.return();
    } finally {
      if (s) throw a;
    }
  } };
}
function EL(i, e) {
  var t;
  if (i) {
    if (typeof i == "string") return Zp(i, e);
    var r = kl(t = Object.prototype.toString.call(i)).call(t, 8, -1);
    if (r === "Object" && i.constructor && (r = i.constructor.name), r === "Map" || r === "Set") return qu(i);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return Zp(i, e);
  }
}
function Zp(i, e) {
  (e == null || e > i.length) && (e = i.length);
  for (var t = 0, r = new Array(e); t < e; t++) r[t] = i[t];
  return r;
}
var xw = Ml("DELETE");
function SL(i) {
  for (var e, t = arguments.length, r = new Array(t > 1 ? t - 1 : 0), n = 1; n < t; n++)
    r[n - 1] = arguments[n];
  return Cw.apply(void 0, Dl(e = [{}, i]).call(e, r));
}
function Cw() {
  var i = Ua.apply(void 0, arguments);
  return Mw(i), i;
}
function Ua() {
  for (var i = arguments.length, e = new Array(i), t = 0; t < i; t++)
    e[t] = arguments[t];
  if (e.length < 2)
    return e[0];
  if (e.length > 2) {
    var r;
    return Ua.apply(void 0, Dl(r = [Cw(e[0], e[1])]).call(r, lt(kl(e).call(e, 2))));
  }
  var n = e[0], o = e[1];
  if (n instanceof Date && o instanceof Date)
    return n.setTime(o.getTime()), n;
  var s = Pw(SR(o)), a;
  try {
    for (s.s(); !(a = s.n()).done; ) {
      var l = a.value;
      Object.prototype.propertyIsEnumerable.call(o, l) && (o[l] === xw ? delete n[l] : n[l] !== null && o[l] !== null && typeof n[l] == "object" && typeof o[l] == "object" && !gt(n[l]) && !gt(o[l]) ? n[l] = Ua(n[l], o[l]) : n[l] = Aw(o[l]));
    }
  } catch (d) {
    s.e(d);
  } finally {
    s.f();
  }
  return n;
}
function Aw(i) {
  return gt(i) ? At(i).call(i, function(e) {
    return Aw(e);
  }) : typeof i == "object" && i !== null ? i instanceof Date ? new Date(i.getTime()) : Ua({}, i) : i;
}
function Mw(i) {
  for (var e = 0, t = Zu(i); e < t.length; e++) {
    var r = t[e];
    i[r] === xw ? delete i[r] : typeof i[r] == "object" && i[r] !== null && Mw(i[r]);
  }
}
function OL() {
  var i = function() {
  };
  return {
    on: i,
    off: i,
    destroy: i,
    emit: i,
    get() {
      return {
        set: i
      };
    }
  };
}
var TL = typeof window < "u" ? window.Hammer || _L : function() {
  return OL();
};
function tr(i) {
  var e = this, t;
  this._cleanupQueue = [], this.active = !1, this._dom = {
    container: i,
    overlay: document.createElement("div")
  }, this._dom.overlay.classList.add("vis-overlay"), this._dom.container.appendChild(this._dom.overlay), this._cleanupQueue.push(function() {
    e._dom.overlay.parentNode.removeChild(e._dom.overlay);
  });
  var r = TL(this._dom.overlay);
  r.on("tap", P1(t = this._onTapOverlay).call(t, this)), this._cleanupQueue.push(function() {
    r.destroy();
  });
  var n = ["tap", "doubletap", "press", "pinch", "pan", "panstart", "panmove", "panend"];
  pi(n).call(n, function(o) {
    r.on(o, function(s) {
      s.srcEvent.stopPropagation();
    });
  }), document && document.body && (this._onClick = function(o) {
    IL(o.target, i) || e.deactivate();
  }, document.body.addEventListener("click", this._onClick), this._cleanupQueue.push(function() {
    document.body.removeEventListener("click", e._onClick);
  })), this._escListener = function(o) {
    ("key" in o ? o.key === "Escape" : o.keyCode === 27) && e.deactivate();
  };
}
NB(tr.prototype);
tr.current = null;
tr.prototype.destroy = function() {
  var i, e;
  this.deactivate();
  var t = Pw(aF(i = X1(e = this._cleanupQueue).call(e, 0)).call(i)), r;
  try {
    for (t.s(); !(r = t.n()).done; ) {
      var n = r.value;
      n();
    }
  } catch (o) {
    t.e(o);
  } finally {
    t.f();
  }
};
tr.prototype.activate = function() {
  tr.current && tr.current.deactivate(), tr.current = this, this.active = !0, this._dom.overlay.style.display = "none", this._dom.container.classList.add("vis-active"), this.emit("change"), this.emit("activate"), document.body.addEventListener("keydown", this._escListener);
};
tr.prototype.deactivate = function() {
  this.active = !1, this._dom.overlay.style.display = "block", this._dom.container.classList.remove("vis-active"), document.body.removeEventListener("keydown", this._escListener), this.emit("change"), this.emit("deactivate");
};
tr.prototype._onTapOverlay = function(i) {
  this.activate(), i.srcEvent.stopPropagation();
};
function IL(i, e) {
  for (; i; ) {
    if (i === e)
      return !0;
    i = i.parentNode;
  }
  return !1;
}
var PL = yl, xL = An, CL = TypeError, Dw = function(i) {
  if (PL(i)) return i;
  throw new CL(xL(i) + " is not a constructor");
}, AL = F, ML = tt, Jd = In, DL = T1, Qp = Dw, kL = mt, eg = He, NL = Ii, kw = ee, af = ML("Reflect", "construct"), RL = Object.prototype, FL = [].push, Nw = kw(function() {
  function i() {
  }
  return !(af(function() {
  }, [], i) instanceof i);
}), Rw = !kw(function() {
  af(function() {
  });
}), tg = Nw || Rw;
AL({ target: "Reflect", stat: !0, forced: tg, sham: tg }, {
  construct: function(e, t) {
    Qp(e), kL(t);
    var r = arguments.length < 3 ? e : Qp(arguments[2]);
    if (Rw && !Nw) return af(e, t, r);
    if (e === r) {
      switch (t.length) {
        case 0:
          return new e();
        case 1:
          return new e(t[0]);
        case 2:
          return new e(t[0], t[1]);
        case 3:
          return new e(t[0], t[1], t[2]);
        case 4:
          return new e(t[0], t[1], t[2], t[3]);
      }
      var n = [null];
      return Jd(FL, n, t), new (Jd(DL, e, n))();
    }
    var o = r.prototype, s = NL(eg(o) ? o : RL), a = Jd(e, s, t);
    return eg(a) ? a : s;
  }
});
var BL = ve, LL = BL.Reflect.construct, jL = LL, zL = jL, WL = zL, Sa = /* @__PURE__ */ z(WL), HL = ve, VL = HL.Object.getOwnPropertySymbols, UL = VL, GL = UL, KL = GL, rg = /* @__PURE__ */ z(KL), Fw = { exports: {} }, YL = F, qL = ee, XL = Jt, Bw = Si.f, Lw = Le, JL = !Lw || qL(function() {
  Bw(1);
});
YL({ target: "Object", stat: !0, forced: JL, sham: !Lw }, {
  getOwnPropertyDescriptor: function(e, t) {
    return Bw(XL(e), t);
  }
});
var ZL = ve, jw = ZL.Object, QL = Fw.exports = function(e, t) {
  return jw.getOwnPropertyDescriptor(e, t);
};
jw.getOwnPropertyDescriptor.sham && (QL.sham = !0);
var ej = Fw.exports, tj = ej, rj = tj, ij = rj, zw = /* @__PURE__ */ z(ij), nj = F, oj = Le, sj = Ju, aj = Jt, lj = Si, dj = Dn;
nj({ target: "Object", stat: !0, sham: !oj }, {
  getOwnPropertyDescriptors: function(e) {
    for (var t = aj(e), r = lj.f, n = sj(t), o = {}, s = 0, a, l; n.length > s; )
      l = r(t, a = n[s++]), l !== void 0 && dj(o, a, l);
    return o;
  }
});
var hj = ve, cj = hj.Object.getOwnPropertyDescriptors, uj = cj, fj = uj, vj = fj, ig = /* @__PURE__ */ z(vj), Ww = { exports: {} }, pj = F, gj = Le, ng = bl.f;
pj({ target: "Object", stat: !0, forced: Object.defineProperties !== ng, sham: !gj }, {
  defineProperties: ng
});
var yj = ve, Hw = yj.Object, mj = Ww.exports = function(e, t) {
  return Hw.defineProperties(e, t);
};
Hw.defineProperties.sham && (mj.sham = !0);
var bj = Ww.exports, $j = bj, wj = $j, _j = wj, Ej = /* @__PURE__ */ z(_j), Sj = $$, Oj = /* @__PURE__ */ z(Sj);
function Vw(i) {
  if (i === void 0)
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return i;
}
var Tj = Z1, Ij = Tj, Pj = Ij, xj = Pj, Uw = xj, Cj = /* @__PURE__ */ z(Uw), Aj = F, Mj = c1;
Aj({ target: "Object", stat: !0 }, {
  setPrototypeOf: Mj
});
var Dj = ve, kj = Dj.Object.setPrototypeOf, Nj = kj, Rj = Nj, Fj = Rj, Bj = Fj, Lj = Bj, jj = Lj, Gw = jj, Wc = /* @__PURE__ */ z(Gw), zj = I1, Wj = zj, Hj = Wj, Vj = Hj, Uj = Vj, Kw = /* @__PURE__ */ z(Uj);
function Hc(i, e) {
  var t;
  return Hc = Wc ? Kw(t = Wc).call(t) : function(n, o) {
    return n.__proto__ = o, n;
  }, Hc(i, e);
}
function Gj(i, e) {
  if (typeof e != "function" && e !== null)
    throw new TypeError("Super expression must either be null or a function");
  i.prototype = Cj(e && e.prototype, {
    constructor: {
      value: i,
      writable: !0,
      configurable: !0
    }
  }), vl(i, "prototype", {
    writable: !1
  }), e && Hc(i, e);
}
function Kj(i, e) {
  if (e && (vn(e) === "object" || typeof e == "function"))
    return e;
  if (e !== void 0)
    throw new TypeError("Derived constructors may only return object or undefined");
  return Vw(i);
}
var Yj = eB, qj = Yj, Xj = qj, Jj = Xj, Yw = Jj, og = /* @__PURE__ */ z(Yw);
function Ga(i) {
  var e;
  return Ga = Wc ? Kw(e = og).call(e) : function(r) {
    return r.__proto__ || og(r);
  }, Ga(i);
}
var qw = { exports: {} }, Xw = { exports: {} };
(function(i) {
  var e = Gu, t = _1;
  function r(n) {
    "@babel/helpers - typeof";
    return i.exports = r = typeof e == "function" && typeof t == "symbol" ? function(o) {
      return typeof o;
    } : function(o) {
      return o && typeof e == "function" && o.constructor === e && o !== e.prototype ? "symbol" : typeof o;
    }, i.exports.__esModule = !0, i.exports.default = i.exports, r(n);
  }
  i.exports = r, i.exports.__esModule = !0, i.exports.default = i.exports;
})(Xw);
var Zj = Xw.exports, Qj = K1, ez = Qj, tz = ez, rz = tz, iz = rz, sg = De, nz = Ju, oz = Si, sz = pt, az = function(i, e, t) {
  for (var r = nz(e), n = sz.f, o = oz.f, s = 0; s < r.length; s++) {
    var a = r[s];
    !sg(i, a) && !(t && sg(t, a)) && n(i, a, o(e, a));
  }
}, lz = He, dz = gr, hz = function(i, e) {
  lz(e) && "cause" in e && dz(i, "cause", e.cause);
}, cz = he, Jw = Error, uz = cz("".replace), fz = function(i) {
  return String(new Jw(i).stack);
}("zxcasd"), Zw = /\n\s*at [^:]*:[^\n]*/, vz = Zw.test(fz), pz = function(i, e) {
  if (vz && typeof i == "string" && !Jw.prepareStackTrace)
    for (; e--; ) i = uz(i, Zw, "");
  return i;
}, gz = ee, yz = Oi, mz = !gz(function() {
  var i = new Error("a");
  return "stack" in i ? (Object.defineProperty(i, "stack", yz(1, 7)), i.stack !== 7) : !0;
}), bz = gr, $z = pz, wz = mz, ag = Error.captureStackTrace, _z = function(i, e, t, r) {
  wz && (ag ? ag(i, e) : bz(i, "stack", $z(t, r)));
}, Ez = Ur, Sz = je, Oz = mt, Tz = An, Iz = A1, Pz = bt, lg = Me, xz = Yu, Cz = Al, dg = C1, Az = TypeError, Oa = function(i, e) {
  this.stopped = i, this.result = e;
}, hg = Oa.prototype, Ci = function(i, e, t) {
  var r = t && t.that, n = !!(t && t.AS_ENTRIES), o = !!(t && t.IS_RECORD), s = !!(t && t.IS_ITERATOR), a = !!(t && t.INTERRUPTED), l = Ez(e, r), d, h, c, u, f, v, y, g = function(m) {
    return d && dg(d, "normal", m), new Oa(!0, m);
  }, p = function(m) {
    return n ? (Oz(m), a ? l(m[0], m[1], g) : l(m[0], m[1])) : a ? l(m, g) : l(m);
  };
  if (o)
    d = i.iterator;
  else if (s)
    d = i;
  else {
    if (h = Cz(i), !h) throw new Az(Tz(i) + " is not iterable");
    if (Iz(h)) {
      for (c = 0, u = Pz(i); u > c; c++)
        if (f = p(i[c]), f && lg(hg, f)) return f;
      return new Oa(!1);
    }
    d = xz(i, h);
  }
  for (v = o ? i.next : d.next; !(y = Sz(v, d)).done; ) {
    try {
      f = p(y.value);
    } catch (m) {
      dg(d, "throw", m);
    }
    if (typeof f == "object" && f && lg(hg, f)) return f;
  }
  return new Oa(!1);
}, Mz = Ti, Dz = function(i, e) {
  return i === void 0 ? arguments.length < 2 ? "" : e : Mz(i);
}, kz = F, Nz = Me, Rz = Pl, Ka = c1, Fz = az, Qw = Ii, Zd = gr, Qd = Oi, Bz = hz, Lz = _z, jz = Ci, zz = Dz, Wz = ge, Hz = Wz("toStringTag"), Ya = Error, Vz = [].push, mn = function(e, t) {
  var r = Nz(eh, this), n;
  Ka ? n = Ka(new Ya(), r ? Rz(this) : eh) : (n = r ? this : Qw(eh), Zd(n, Hz, "Error")), t !== void 0 && Zd(n, "message", zz(t)), Lz(n, mn, n.stack, 1), arguments.length > 2 && Bz(n, arguments[2]);
  var o = [];
  return jz(e, Vz, { that: o }), Zd(n, "errors", o), n;
};
Ka ? Ka(mn, Ya) : Fz(mn, Ya, { name: !0 });
var eh = mn.prototype = Qw(Ya.prototype, {
  constructor: Qd(1, mn),
  message: Qd(1, ""),
  name: Qd(1, "AggregateError")
});
kz({ global: !0 }, {
  AggregateError: mn
});
var Uz = tt, Gz = Bu, Kz = ge, Yz = Le, cg = Kz("species"), e0 = function(i) {
  var e = Uz(i);
  Yz && e && !e[cg] && Gz(e, cg, {
    configurable: !0,
    get: function() {
      return this;
    }
  });
}, qz = Me, Xz = TypeError, lf = function(i, e) {
  if (qz(e, i)) return i;
  throw new Xz("Incorrect invocation");
}, ug = mt, Jz = Dw, Zz = Pn, Qz = ge, e3 = Qz("species"), t0 = function(i, e) {
  var t = ug(i).constructor, r;
  return t === void 0 || Zz(r = ug(t)[e3]) ? e : Jz(r);
}, t3 = Vr, r0 = /(?:ipad|iphone|ipod).*applewebkit/i.test(t3), yt = fe, r3 = In, i3 = Ur, fg = $e, n3 = De, i0 = ee, vg = C$, o3 = Ko, pg = Du, s3 = Q1, a3 = r0, l3 = qo, Vc = yt.setImmediate, gg = yt.clearImmediate, d3 = yt.process, th = yt.Dispatch, h3 = yt.Function, yg = yt.MessageChannel, c3 = yt.String, rh = 0, co = {}, mg = "onreadystatechange", Io, Zr, ih, nh;
i0(function() {
  Io = yt.location;
});
var df = function(i) {
  if (n3(co, i)) {
    var e = co[i];
    delete co[i], e();
  }
}, oh = function(i) {
  return function() {
    df(i);
  };
}, bg = function(i) {
  df(i.data);
}, $g = function(i) {
  yt.postMessage(c3(i), Io.protocol + "//" + Io.host);
};
(!Vc || !gg) && (Vc = function(e) {
  s3(arguments.length, 1);
  var t = fg(e) ? e : h3(e), r = o3(arguments, 1);
  return co[++rh] = function() {
    r3(t, void 0, r);
  }, Zr(rh), rh;
}, gg = function(e) {
  delete co[e];
}, l3 ? Zr = function(i) {
  d3.nextTick(oh(i));
} : th && th.now ? Zr = function(i) {
  th.now(oh(i));
} : yg && !a3 ? (ih = new yg(), nh = ih.port2, ih.port1.onmessage = bg, Zr = i3(nh.postMessage, nh)) : yt.addEventListener && fg(yt.postMessage) && !yt.importScripts && Io && Io.protocol !== "file:" && !i0($g) ? (Zr = $g, yt.addEventListener("message", bg, !1)) : mg in pg("script") ? Zr = function(i) {
  vg.appendChild(pg("script"))[mg] = function() {
    vg.removeChild(this), df(i);
  };
} : Zr = function(i) {
  setTimeout(oh(i), 0);
});
var n0 = {
  set: Vc
}, o0 = function() {
  this.head = null, this.tail = null;
};
o0.prototype = {
  add: function(i) {
    var e = { item: i, next: null }, t = this.tail;
    t ? t.next = e : this.head = e, this.tail = e;
  },
  get: function() {
    var i = this.head;
    if (i) {
      var e = this.head = i.next;
      return e === null && (this.tail = null), i.item;
    }
  }
};
var s0 = o0, u3 = Vr, f3 = /ipad|iphone|ipod/i.test(u3) && typeof Pebble < "u", v3 = Vr, p3 = /web0s(?!.*chrome)/i.test(v3), bi = fe, wg = Ur, g3 = Si.f, sh = n0.set, y3 = s0, m3 = r0, b3 = f3, $3 = p3, ah = qo, _g = bi.MutationObserver || bi.WebKitMutationObserver, Eg = bi.document, Sg = bi.process, Gs = bi.Promise, Og = g3(bi, "queueMicrotask"), Uc = Og && Og.value, zi, lh, dh, Ks, Tg;
if (!Uc) {
  var Ys = new y3(), qs = function() {
    var i, e;
    for (ah && (i = Sg.domain) && i.exit(); e = Ys.get(); ) try {
      e();
    } catch (t) {
      throw Ys.head && zi(), t;
    }
    i && i.enter();
  };
  !m3 && !ah && !$3 && _g && Eg ? (lh = !0, dh = Eg.createTextNode(""), new _g(qs).observe(dh, { characterData: !0 }), zi = function() {
    dh.data = lh = !lh;
  }) : !b3 && Gs && Gs.resolve ? (Ks = Gs.resolve(void 0), Ks.constructor = Gs, Tg = wg(Ks.then, Ks), zi = function() {
    Tg(qs);
  }) : ah ? zi = function() {
    Sg.nextTick(qs);
  } : (sh = wg(sh, bi), zi = function() {
    sh(qs);
  }), Uc = function(i) {
    Ys.head || zi(), Ys.add(i);
  };
}
var w3 = Uc, _3 = function(i, e) {
  try {
    arguments.length === 1 ? console.error(i) : console.error(i, e);
  } catch {
  }
}, Ln = function(i) {
  try {
    return { error: !1, value: i() };
  } catch (e) {
    return { error: !0, value: e };
  }
}, E3 = fe, jn = E3.Promise, a0 = typeof Deno == "object" && Deno && typeof Deno.version == "object", S3 = a0, O3 = qo, T3 = !S3 && !O3 && typeof window == "object" && typeof document == "object", I3 = fe, uo = jn, P3 = $e, x3 = y$, C3 = E$, A3 = ge, M3 = T3, D3 = a0, hh = xn, Ig = uo && uo.prototype, k3 = A3("species"), Pg = !1, l0 = P3(I3.PromiseRejectionEvent), N3 = x3("Promise", function() {
  var i = C3(uo), e = i !== String(uo);
  if (!e && hh === 66 || !(Ig.catch && Ig.finally)) return !0;
  if (!hh || hh < 51 || !/native code/.test(i)) {
    var t = new uo(function(o) {
      o(1);
    }), r = function(o) {
      o(function() {
      }, function() {
      });
    }, n = t.constructor = {};
    if (n[k3] = r, Pg = t.then(function() {
    }) instanceof r, !Pg) return !0;
  }
  return !e && (M3 || D3) && !l0;
}), ts = {
  CONSTRUCTOR: N3,
  REJECTION_EVENT: l0
}, Zt = {}, xg = ft, R3 = TypeError, F3 = function(i) {
  var e, t;
  this.promise = new i(function(r, n) {
    if (e !== void 0 || t !== void 0) throw new R3("Bad Promise constructor");
    e = r, t = n;
  }), this.resolve = xg(e), this.reject = xg(t);
};
Zt.f = function(i) {
  return new F3(i);
};
var B3 = F, qa = qo, Br = fe, rs = je, L3 = kn, j3 = Pi, z3 = e0, W3 = ft, Gc = $e, H3 = He, V3 = lf, U3 = t0, d0 = n0.set, hf = w3, G3 = _3, K3 = Ln, Y3 = s0, h0 = Nn, Kc = jn, c0 = ts, u0 = Zt, Fl = "Promise", f0 = c0.CONSTRUCTOR, q3 = c0.REJECTION_EVENT, ch = h0.getterFor(Fl), X3 = h0.set, J3 = Kc && Kc.prototype, en = Kc, uh = J3, v0 = Br.TypeError, Yc = Br.document, cf = Br.process, qc = u0.f, Z3 = qc, Q3 = !!(Yc && Yc.createEvent && Br.dispatchEvent), p0 = "unhandledrejection", e5 = "rejectionhandled", Cg = 0, g0 = 1, t5 = 2, uf = 1, y0 = 2, Xs, Ag, r5, m0 = function(i) {
  var e;
  return H3(i) && Gc(e = i.then) ? e : !1;
}, b0 = function(i, e) {
  var t = e.value, r = e.state === g0, n = r ? i.ok : i.fail, o = i.resolve, s = i.reject, a = i.domain, l, d, h;
  try {
    n ? (r || (e.rejection === y0 && n5(e), e.rejection = uf), n === !0 ? l = t : (a && a.enter(), l = n(t), a && (a.exit(), h = !0)), l === i.promise ? s(new v0("Promise-chain cycle")) : (d = m0(l)) ? rs(d, l, o, s) : o(l)) : s(t);
  } catch (c) {
    a && !h && a.exit(), s(c);
  }
}, $0 = function(i, e) {
  i.notified || (i.notified = !0, hf(function() {
    for (var t = i.reactions, r; r = t.get(); )
      b0(r, i);
    i.notified = !1, e && !i.rejection && i5(i);
  }));
}, w0 = function(i, e, t) {
  var r, n;
  Q3 ? (r = Yc.createEvent("Event"), r.promise = e, r.reason = t, r.initEvent(i, !1, !0), Br.dispatchEvent(r)) : r = { promise: e, reason: t }, !q3 && (n = Br["on" + i]) ? n(r) : i === p0 && G3("Unhandled promise rejection", t);
}, i5 = function(i) {
  rs(d0, Br, function() {
    var e = i.facade, t = i.value, r = Mg(i), n;
    if (r && (n = K3(function() {
      qa ? cf.emit("unhandledRejection", t, e) : w0(p0, e, t);
    }), i.rejection = qa || Mg(i) ? y0 : uf, n.error))
      throw n.value;
  });
}, Mg = function(i) {
  return i.rejection !== uf && !i.parent;
}, n5 = function(i) {
  rs(d0, Br, function() {
    var e = i.facade;
    qa ? cf.emit("rejectionHandled", e) : w0(e5, e, i.value);
  });
}, tn = function(i, e, t) {
  return function(r) {
    i(e, r, t);
  };
}, an = function(i, e, t) {
  i.done || (i.done = !0, t && (i = t), i.value = e, i.state = t5, $0(i, !0));
}, Xc = function(i, e, t) {
  if (!i.done) {
    i.done = !0, t && (i = t);
    try {
      if (i.facade === e) throw new v0("Promise can't be resolved itself");
      var r = m0(e);
      r ? hf(function() {
        var n = { done: !1 };
        try {
          rs(
            r,
            e,
            tn(Xc, n, i),
            tn(an, n, i)
          );
        } catch (o) {
          an(n, o, i);
        }
      }) : (i.value = e, i.state = g0, $0(i, !1));
    } catch (n) {
      an({ done: !1 }, n, i);
    }
  }
};
f0 && (en = function(e) {
  V3(this, uh), W3(e), rs(Xs, this);
  var t = ch(this);
  try {
    e(tn(Xc, t), tn(an, t));
  } catch (r) {
    an(t, r);
  }
}, uh = en.prototype, Xs = function(e) {
  X3(this, {
    type: Fl,
    done: !1,
    notified: !1,
    parent: !1,
    reactions: new Y3(),
    rejection: !1,
    state: Cg,
    value: void 0
  });
}, Xs.prototype = L3(uh, "then", function(e, t) {
  var r = ch(this), n = qc(U3(this, en));
  return r.parent = !0, n.ok = Gc(e) ? e : !0, n.fail = Gc(t) && t, n.domain = qa ? cf.domain : void 0, r.state === Cg ? r.reactions.add(n) : hf(function() {
    b0(n, r);
  }), n.promise;
}), Ag = function() {
  var i = new Xs(), e = ch(i);
  this.promise = i, this.resolve = tn(Xc, e), this.reject = tn(an, e);
}, u0.f = qc = function(i) {
  return i === en || i === r5 ? new Ag(i) : Z3(i);
});
B3({ global: !0, wrap: !0, forced: f0 }, {
  Promise: en
});
j3(en, Fl, !1, !0);
z3(Fl);
var o5 = jn, s5 = k1, a5 = ts.CONSTRUCTOR, Bl = a5 || !s5(function(i) {
  o5.all(i).then(void 0, function() {
  });
}), l5 = F, d5 = je, h5 = ft, c5 = Zt, u5 = Ln, f5 = Ci, v5 = Bl;
l5({ target: "Promise", stat: !0, forced: v5 }, {
  all: function(e) {
    var t = this, r = c5.f(t), n = r.resolve, o = r.reject, s = u5(function() {
      var a = h5(t.resolve), l = [], d = 0, h = 1;
      f5(e, function(c) {
        var u = d++, f = !1;
        h++, d5(a, t, c).then(function(v) {
          f || (f = !0, l[u] = v, --h || n(l));
        }, o);
      }), --h || n(l);
    });
    return s.error && o(s.value), r.promise;
  }
});
var p5 = F, g5 = ts.CONSTRUCTOR, Dg = jn;
Dg && Dg.prototype;
p5({ target: "Promise", proto: !0, forced: g5, real: !0 }, {
  catch: function(i) {
    return this.then(void 0, i);
  }
});
var y5 = F, m5 = je, b5 = ft, $5 = Zt, w5 = Ln, _5 = Ci, E5 = Bl;
y5({ target: "Promise", stat: !0, forced: E5 }, {
  race: function(e) {
    var t = this, r = $5.f(t), n = r.reject, o = w5(function() {
      var s = b5(t.resolve);
      _5(e, function(a) {
        m5(s, t, a).then(r.resolve, n);
      });
    });
    return o.error && n(o.value), r.promise;
  }
});
var S5 = F, O5 = je, T5 = Zt, I5 = ts.CONSTRUCTOR;
S5({ target: "Promise", stat: !0, forced: I5 }, {
  reject: function(e) {
    var t = T5.f(this);
    return O5(t.reject, void 0, e), t.promise;
  }
});
var P5 = mt, x5 = He, C5 = Zt, _0 = function(i, e) {
  if (P5(i), x5(e) && e.constructor === i) return e;
  var t = C5.f(i), r = t.resolve;
  return r(e), t.promise;
}, A5 = F, M5 = tt, D5 = jO, k5 = jn, N5 = ts.CONSTRUCTOR, R5 = _0, F5 = M5("Promise"), B5 = !N5;
A5({ target: "Promise", stat: !0, forced: D5 }, {
  resolve: function(e) {
    return R5(B5 && this === F5 ? k5 : this, e);
  }
});
var L5 = F, j5 = je, z5 = ft, W5 = Zt, H5 = Ln, V5 = Ci, U5 = Bl;
L5({ target: "Promise", stat: !0, forced: U5 }, {
  allSettled: function(e) {
    var t = this, r = W5.f(t), n = r.resolve, o = r.reject, s = H5(function() {
      var a = z5(t.resolve), l = [], d = 0, h = 1;
      V5(e, function(c) {
        var u = d++, f = !1;
        h++, j5(a, t, c).then(function(v) {
          f || (f = !0, l[u] = { status: "fulfilled", value: v }, --h || n(l));
        }, function(v) {
          f || (f = !0, l[u] = { status: "rejected", reason: v }, --h || n(l));
        });
      }), --h || n(l);
    });
    return s.error && o(s.value), r.promise;
  }
});
var G5 = F, K5 = je, Y5 = ft, q5 = tt, X5 = Zt, J5 = Ln, Z5 = Ci, Q5 = Bl, kg = "No one promise resolved";
G5({ target: "Promise", stat: !0, forced: Q5 }, {
  any: function(e) {
    var t = this, r = q5("AggregateError"), n = X5.f(t), o = n.resolve, s = n.reject, a = J5(function() {
      var l = Y5(t.resolve), d = [], h = 0, c = 1, u = !1;
      Z5(e, function(f) {
        var v = h++, y = !1;
        c++, K5(l, t, f).then(function(g) {
          y || u || (u = !0, o(g));
        }, function(g) {
          y || u || (y = !0, d[v] = g, --c || s(new r(d, kg)));
        });
      }), --c || s(new r(d, kg));
    });
    return a.error && s(a.value), n.promise;
  }
});
var eW = F, Jc = jn, tW = ee, rW = tt, iW = $e, nW = t0, Ng = _0, oW = Jc && Jc.prototype, sW = !!Jc && tW(function() {
  oW.finally.call({ then: function() {
  } }, function() {
  });
});
eW({ target: "Promise", proto: !0, real: !0, forced: sW }, {
  finally: function(i) {
    var e = nW(this, rW("Promise")), t = iW(i);
    return this.then(
      t ? function(r) {
        return Ng(e, i()).then(function() {
          return r;
        });
      } : i,
      t ? function(r) {
        return Ng(e, i()).then(function() {
          throw r;
        });
      } : i
    );
  }
});
var aW = ve, lW = aW.Promise, dW = lW, hW = dW, cW = F, uW = Zt;
cW({ target: "Promise", stat: !0 }, {
  withResolvers: function() {
    var e = uW.f(this);
    return {
      promise: e.promise,
      resolve: e.resolve,
      reject: e.reject
    };
  }
});
var fW = hW, vW = fW, pW = F, gW = Zt, yW = Ln;
pW({ target: "Promise", stat: !0, forced: !0 }, {
  try: function(i) {
    var e = gW.f(this), t = yW(i);
    return (t.error ? e.reject : e.resolve)(t.value), e.promise;
  }
});
var mW = vW, bW = mW, $W = bW, wW = Y1, _W = wW, EW = _W, SW = EW, OW = SW;
(function(i) {
  var e = Zj.default, t = w$, r = Gu, n = Uw, o = Yw, s = iz, a = z1, l = Gw, d = $W, h = OW, c = H1;
  function u() {
    i.exports = u = function() {
      return v;
    }, i.exports.__esModule = !0, i.exports.default = i.exports;
    var f, v = {}, y = Object.prototype, g = y.hasOwnProperty, p = t || function(C, O, I) {
      C[O] = I.value;
    }, m = typeof r == "function" ? r : {}, $ = m.iterator || "@@iterator", w = m.asyncIterator || "@@asyncIterator", T = m.toStringTag || "@@toStringTag";
    function A(C, O, I) {
      return t(C, O, {
        value: I,
        enumerable: !0,
        configurable: !0,
        writable: !0
      }), C[O];
    }
    try {
      A({}, "");
    } catch {
      A = function(I, N, K) {
        return I[N] = K;
      };
    }
    function L(C, O, I, N) {
      var K = O && O.prototype instanceof x ? O : x, V = n(K.prototype), Oe = new dd(N || []);
      return p(V, "_invoke", {
        value: rt(C, I, Oe)
      }), V;
    }
    function G(C, O, I) {
      try {
        return {
          type: "normal",
          arg: C.call(O, I)
        };
      } catch (N) {
        return {
          type: "throw",
          arg: N
        };
      }
    }
    v.wrap = L;
    var ne = "suspendedStart", oe = "suspendedYield", Pe = "executing", pe = "completed", ce = {};
    function x() {
    }
    function j() {
    }
    function D() {
    }
    var _ = {};
    A(_, $, function() {
      return this;
    });
    var R = o, W = R && R(R(hd([])));
    W && W !== y && g.call(W, $) && (_ = W);
    var J = D.prototype = x.prototype = n(_);
    function te(C) {
      var O;
      s(O = ["next", "throw", "return"]).call(O, function(I) {
        A(C, I, function(N) {
          return this._invoke(I, N);
        });
      });
    }
    function Se(C, O) {
      function I(K, V, Oe, qe) {
        var it = G(C[K], C, V);
        if (it.type !== "throw") {
          var Xr = it.arg, wr = Xr.value;
          return wr && e(wr) == "object" && g.call(wr, "__await") ? O.resolve(wr.__await).then(function(Jr) {
            I("next", Jr, Oe, qe);
          }, function(Jr) {
            I("throw", Jr, Oe, qe);
          }) : O.resolve(wr).then(function(Jr) {
            Xr.value = Jr, Oe(Xr);
          }, function(Jr) {
            return I("throw", Jr, Oe, qe);
          });
        }
        qe(it.arg);
      }
      var N;
      p(this, "_invoke", {
        value: function(V, Oe) {
          function qe() {
            return new O(function(it, Xr) {
              I(V, Oe, it, Xr);
            });
          }
          return N = N ? N.then(qe, qe) : qe();
        }
      });
    }
    function rt(C, O, I) {
      var N = ne;
      return function(K, V) {
        if (N === Pe) throw new Error("Generator is already running");
        if (N === pe) {
          if (K === "throw") throw V;
          return {
            value: f,
            done: !0
          };
        }
        for (I.method = K, I.arg = V; ; ) {
          var Oe = I.delegate;
          if (Oe) {
            var qe = zt(Oe, I);
            if (qe) {
              if (qe === ce) continue;
              return qe;
            }
          }
          if (I.method === "next") I.sent = I._sent = I.arg;
          else if (I.method === "throw") {
            if (N === ne) throw N = pe, I.arg;
            I.dispatchException(I.arg);
          } else I.method === "return" && I.abrupt("return", I.arg);
          N = Pe;
          var it = G(C, O, I);
          if (it.type === "normal") {
            if (N = I.done ? pe : oe, it.arg === ce) continue;
            return {
              value: it.arg,
              done: I.done
            };
          }
          it.type === "throw" && (N = pe, I.method = "throw", I.arg = it.arg);
        }
      };
    }
    function zt(C, O) {
      var I = O.method, N = C.iterator[I];
      if (N === f) return O.delegate = null, I === "throw" && C.iterator.return && (O.method = "return", O.arg = f, zt(C, O), O.method === "throw") || I !== "return" && (O.method = "throw", O.arg = new TypeError("The iterator does not provide a '" + I + "' method")), ce;
      var K = G(N, C.iterator, O.arg);
      if (K.type === "throw") return O.method = "throw", O.arg = K.arg, O.delegate = null, ce;
      var V = K.arg;
      return V ? V.done ? (O[C.resultName] = V.value, O.next = C.nextLoc, O.method !== "return" && (O.method = "next", O.arg = f), O.delegate = null, ce) : V : (O.method = "throw", O.arg = new TypeError("iterator result is not an object"), O.delegate = null, ce);
    }
    function $r(C) {
      var O, I = {
        tryLoc: C[0]
      };
      1 in C && (I.catchLoc = C[1]), 2 in C && (I.finallyLoc = C[2], I.afterLoc = C[3]), a(O = this.tryEntries).call(O, I);
    }
    function Ri(C) {
      var O = C.completion || {};
      O.type = "normal", delete O.arg, C.completion = O;
    }
    function dd(C) {
      this.tryEntries = [{
        tryLoc: "root"
      }], s(C).call(C, $r, this), this.reset(!0);
    }
    function hd(C) {
      if (C || C === "") {
        var O = C[$];
        if (O) return O.call(C);
        if (typeof C.next == "function") return C;
        if (!isNaN(C.length)) {
          var I = -1, N = function K() {
            for (; ++I < C.length; ) if (g.call(C, I)) return K.value = C[I], K.done = !1, K;
            return K.value = f, K.done = !0, K;
          };
          return N.next = N;
        }
      }
      throw new TypeError(e(C) + " is not iterable");
    }
    return j.prototype = D, p(J, "constructor", {
      value: D,
      configurable: !0
    }), p(D, "constructor", {
      value: j,
      configurable: !0
    }), j.displayName = A(D, T, "GeneratorFunction"), v.isGeneratorFunction = function(C) {
      var O = typeof C == "function" && C.constructor;
      return !!O && (O === j || (O.displayName || O.name) === "GeneratorFunction");
    }, v.mark = function(C) {
      return l ? l(C, D) : (C.__proto__ = D, A(C, T, "GeneratorFunction")), C.prototype = n(J), C;
    }, v.awrap = function(C) {
      return {
        __await: C
      };
    }, te(Se.prototype), A(Se.prototype, w, function() {
      return this;
    }), v.AsyncIterator = Se, v.async = function(C, O, I, N, K) {
      K === void 0 && (K = d);
      var V = new Se(L(C, O, I, N), K);
      return v.isGeneratorFunction(O) ? V : V.next().then(function(Oe) {
        return Oe.done ? Oe.value : V.next();
      });
    }, te(J), A(J, T, "Generator"), A(J, $, function() {
      return this;
    }), A(J, "toString", function() {
      return "[object Generator]";
    }), v.keys = function(C) {
      var O = Object(C), I = [];
      for (var N in O) a(I).call(I, N);
      return h(I).call(I), function K() {
        for (; I.length; ) {
          var V = I.pop();
          if (V in O) return K.value = V, K.done = !1, K;
        }
        return K.done = !0, K;
      };
    }, v.values = hd, dd.prototype = {
      constructor: dd,
      reset: function(O) {
        var I;
        if (this.prev = 0, this.next = 0, this.sent = this._sent = f, this.done = !1, this.delegate = null, this.method = "next", this.arg = f, s(I = this.tryEntries).call(I, Ri), !O) for (var N in this) N.charAt(0) === "t" && g.call(this, N) && !isNaN(+c(N).call(N, 1)) && (this[N] = f);
      },
      stop: function() {
        this.done = !0;
        var O = this.tryEntries[0].completion;
        if (O.type === "throw") throw O.arg;
        return this.rval;
      },
      dispatchException: function(O) {
        if (this.done) throw O;
        var I = this;
        function N(Xr, wr) {
          return Oe.type = "throw", Oe.arg = O, I.next = Xr, wr && (I.method = "next", I.arg = f), !!wr;
        }
        for (var K = this.tryEntries.length - 1; K >= 0; --K) {
          var V = this.tryEntries[K], Oe = V.completion;
          if (V.tryLoc === "root") return N("end");
          if (V.tryLoc <= this.prev) {
            var qe = g.call(V, "catchLoc"), it = g.call(V, "finallyLoc");
            if (qe && it) {
              if (this.prev < V.catchLoc) return N(V.catchLoc, !0);
              if (this.prev < V.finallyLoc) return N(V.finallyLoc);
            } else if (qe) {
              if (this.prev < V.catchLoc) return N(V.catchLoc, !0);
            } else {
              if (!it) throw new Error("try statement without catch or finally");
              if (this.prev < V.finallyLoc) return N(V.finallyLoc);
            }
          }
        }
      },
      abrupt: function(O, I) {
        for (var N = this.tryEntries.length - 1; N >= 0; --N) {
          var K = this.tryEntries[N];
          if (K.tryLoc <= this.prev && g.call(K, "finallyLoc") && this.prev < K.finallyLoc) {
            var V = K;
            break;
          }
        }
        V && (O === "break" || O === "continue") && V.tryLoc <= I && I <= V.finallyLoc && (V = null);
        var Oe = V ? V.completion : {};
        return Oe.type = O, Oe.arg = I, V ? (this.method = "next", this.next = V.finallyLoc, ce) : this.complete(Oe);
      },
      complete: function(O, I) {
        if (O.type === "throw") throw O.arg;
        return O.type === "break" || O.type === "continue" ? this.next = O.arg : O.type === "return" ? (this.rval = this.arg = O.arg, this.method = "return", this.next = "end") : O.type === "normal" && I && (this.next = I), ce;
      },
      finish: function(O) {
        for (var I = this.tryEntries.length - 1; I >= 0; --I) {
          var N = this.tryEntries[I];
          if (N.finallyLoc === O) return this.complete(N.completion, N.afterLoc), Ri(N), ce;
        }
      },
      catch: function(O) {
        for (var I = this.tryEntries.length - 1; I >= 0; --I) {
          var N = this.tryEntries[I];
          if (N.tryLoc === O) {
            var K = N.completion;
            if (K.type === "throw") {
              var V = K.arg;
              Ri(N);
            }
            return V;
          }
        }
        throw new Error("illegal catch attempt");
      },
      delegateYield: function(O, I, N) {
        return this.delegate = {
          iterator: hd(O),
          resultName: I,
          nextLoc: N
        }, this.method === "next" && (this.arg = f), ce;
      }
    }, v;
  }
  i.exports = u, i.exports.__esModule = !0, i.exports.default = i.exports;
})(qw);
var TW = qw.exports, Ta = TW(), IW = Ta;
try {
  regeneratorRuntime = Ta;
} catch {
  typeof globalThis == "object" ? globalThis.regeneratorRuntime = Ta : Function("r", "regeneratorRuntime = r")(Ta);
}
var ot = /* @__PURE__ */ z(IW), E0 = { exports: {} }, PW = ee, xW = PW(function() {
  if (typeof ArrayBuffer == "function") {
    var i = new ArrayBuffer(8);
    Object.isExtensible(i) && Object.defineProperty(i, "a", { value: 8 });
  }
}), CW = ee, AW = He, MW = Hr, Rg = xW, Ia = Object.isExtensible, DW = CW(function() {
  Ia(1);
}), kW = DW || Rg ? function(e) {
  return !AW(e) || Rg && MW(e) === "ArrayBuffer" ? !1 : Ia ? Ia(e) : !0;
} : Ia, NW = ee, RW = !NW(function() {
  return Object.isExtensible(Object.preventExtensions({}));
}), FW = F, BW = he, LW = zo, jW = He, ff = De, zW = pt.f, Fg = Wo, WW = Fu, vf = kW, HW = ul, VW = RW, S0 = !1, fr = HW("meta"), UW = 0, pf = function(i) {
  zW(i, fr, { value: {
    objectID: "O" + UW++,
    // object ID
    weakData: {}
    // weak collections IDs
  } });
}, GW = function(i, e) {
  if (!jW(i)) return typeof i == "symbol" ? i : (typeof i == "string" ? "S" : "P") + i;
  if (!ff(i, fr)) {
    if (!vf(i)) return "F";
    if (!e) return "E";
    pf(i);
  }
  return i[fr].objectID;
}, KW = function(i, e) {
  if (!ff(i, fr)) {
    if (!vf(i)) return !0;
    if (!e) return !1;
    pf(i);
  }
  return i[fr].weakData;
}, YW = function(i) {
  return VW && S0 && vf(i) && !ff(i, fr) && pf(i), i;
}, qW = function() {
  XW.enable = function() {
  }, S0 = !0;
  var i = Fg.f, e = BW([].splice), t = {};
  t[fr] = 1, i(t).length && (Fg.f = function(r) {
    for (var n = i(r), o = 0, s = n.length; o < s; o++)
      if (n[o] === fr) {
        e(n, o, 1);
        break;
      }
    return n;
  }, FW({ target: "Object", stat: !0, forced: !0 }, {
    getOwnPropertyNames: WW.f
  }));
}, XW = E0.exports = {
  enable: qW,
  fastKey: GW,
  getWeakData: KW,
  onFreeze: YW
};
LW[fr] = !0;
var O0 = E0.exports, JW = F, ZW = fe, QW = O0, eH = ee, tH = gr, rH = Ci, iH = lf, nH = $e, oH = He, sH = Pn, aH = Pi, lH = pt.f, dH = Rn.forEach, hH = Le, T0 = Nn, cH = T0.set, uH = T0.getterFor, I0 = function(i, e, t) {
  var r = i.indexOf("Map") !== -1, n = i.indexOf("Weak") !== -1, o = r ? "set" : "add", s = ZW[i], a = s && s.prototype, l = {}, d;
  if (!hH || !nH(s) || !(n || a.forEach && !eH(function() {
    new s().entries().next();
  })))
    d = t.getConstructor(e, i, r, o), QW.enable();
  else {
    d = e(function(u, f) {
      cH(iH(u, h), {
        type: i,
        collection: new s()
      }), sH(f) || rH(f, u[o], { that: u, AS_ENTRIES: r });
    });
    var h = d.prototype, c = uH(i);
    dH(["add", "clear", "delete", "forEach", "get", "has", "set", "keys", "values", "entries"], function(u) {
      var f = u === "add" || u === "set";
      u in a && !(n && u === "clear") && tH(h, u, function(v, y) {
        var g = c(this).collection;
        if (!f && n && !oH(v)) return u === "get" ? void 0 : !1;
        var p = g[u](v === 0 ? 0 : v, y);
        return f ? this : p;
      });
    }), n || lH(h, "size", {
      configurable: !0,
      get: function() {
        return c(this).collection.size;
      }
    });
  }
  return aH(d, i, !1, !0), l[i] = d, JW({ global: !0, forced: !0 }, l), n || t.setStrong(d, i, r), d;
}, fH = kn, vH = function(i, e, t) {
  for (var r in e)
    t && t.unsafe && i[r] ? i[r] = e[r] : fH(i, r, e[r], t);
  return i;
}, pH = Ii, gH = Bu, Bg = vH, yH = Ur, mH = lf, bH = Pn, $H = Ci, wH = Hu, Js = Vu, _H = e0, Zn = Le, Lg = O0.fastKey, P0 = Nn, jg = P0.set, fh = P0.getterFor, x0 = {
  getConstructor: function(i, e, t, r) {
    var n = i(function(d, h) {
      mH(d, o), jg(d, {
        type: e,
        index: pH(null),
        first: void 0,
        last: void 0,
        size: 0
      }), Zn || (d.size = 0), bH(h) || $H(h, d[r], { that: d, AS_ENTRIES: t });
    }), o = n.prototype, s = fh(e), a = function(d, h, c) {
      var u = s(d), f = l(d, h), v, y;
      return f ? f.value = c : (u.last = f = {
        index: y = Lg(h, !0),
        key: h,
        value: c,
        previous: v = u.last,
        next: void 0,
        removed: !1
      }, u.first || (u.first = f), v && (v.next = f), Zn ? u.size++ : d.size++, y !== "F" && (u.index[y] = f)), d;
    }, l = function(d, h) {
      var c = s(d), u = Lg(h), f;
      if (u !== "F") return c.index[u];
      for (f = c.first; f; f = f.next)
        if (f.key === h) return f;
    };
    return Bg(o, {
      // `{ Map, Set }.prototype.clear()` methods
      // https://tc39.es/ecma262/#sec-map.prototype.clear
      // https://tc39.es/ecma262/#sec-set.prototype.clear
      clear: function() {
        for (var h = this, c = s(h), u = c.index, f = c.first; f; )
          f.removed = !0, f.previous && (f.previous = f.previous.next = void 0), delete u[f.index], f = f.next;
        c.first = c.last = void 0, Zn ? c.size = 0 : h.size = 0;
      },
      // `{ Map, Set }.prototype.delete(key)` methods
      // https://tc39.es/ecma262/#sec-map.prototype.delete
      // https://tc39.es/ecma262/#sec-set.prototype.delete
      delete: function(d) {
        var h = this, c = s(h), u = l(h, d);
        if (u) {
          var f = u.next, v = u.previous;
          delete c.index[u.index], u.removed = !0, v && (v.next = f), f && (f.previous = v), c.first === u && (c.first = f), c.last === u && (c.last = v), Zn ? c.size-- : h.size--;
        }
        return !!u;
      },
      // `{ Map, Set }.prototype.forEach(callbackfn, thisArg = undefined)` methods
      // https://tc39.es/ecma262/#sec-map.prototype.foreach
      // https://tc39.es/ecma262/#sec-set.prototype.foreach
      forEach: function(h) {
        for (var c = s(this), u = yH(h, arguments.length > 1 ? arguments[1] : void 0), f; f = f ? f.next : c.first; )
          for (u(f.value, f.key, this); f && f.removed; ) f = f.previous;
      },
      // `{ Map, Set}.prototype.has(key)` methods
      // https://tc39.es/ecma262/#sec-map.prototype.has
      // https://tc39.es/ecma262/#sec-set.prototype.has
      has: function(h) {
        return !!l(this, h);
      }
    }), Bg(o, t ? {
      // `Map.prototype.get(key)` method
      // https://tc39.es/ecma262/#sec-map.prototype.get
      get: function(h) {
        var c = l(this, h);
        return c && c.value;
      },
      // `Map.prototype.set(key, value)` method
      // https://tc39.es/ecma262/#sec-map.prototype.set
      set: function(h, c) {
        return a(this, h === 0 ? 0 : h, c);
      }
    } : {
      // `Set.prototype.add(value)` method
      // https://tc39.es/ecma262/#sec-set.prototype.add
      add: function(h) {
        return a(this, h = h === 0 ? 0 : h, h);
      }
    }), Zn && gH(o, "size", {
      configurable: !0,
      get: function() {
        return s(this).size;
      }
    }), n;
  },
  setStrong: function(i, e, t) {
    var r = e + " Iterator", n = fh(e), o = fh(r);
    wH(i, e, function(s, a) {
      jg(this, {
        type: r,
        target: s,
        state: n(s),
        kind: a,
        last: void 0
      });
    }, function() {
      for (var s = o(this), a = s.kind, l = s.last; l && l.removed; ) l = l.previous;
      return !s.target || !(s.last = l = l ? l.next : s.state.first) ? (s.target = void 0, Js(void 0, !0)) : Js(a === "keys" ? l.key : a === "values" ? l.value : [l.key, l.value], !1);
    }, t ? "entries" : "values", !t, !0), _H(e);
  }
}, EH = I0, SH = x0;
EH("Map", function(i) {
  return function() {
    return i(this, arguments.length ? arguments[0] : void 0);
  };
}, SH);
var OH = ve, TH = OH.Map, IH = TH, PH = IH, xH = PH, C0 = /* @__PURE__ */ z(xH), CH = F, AH = Rn.some, MH = Cl, DH = MH("some");
CH({ target: "Array", proto: !0, forced: !DH }, {
  some: function(e) {
    return AH(this, e, arguments.length > 1 ? arguments[1] : void 0);
  }
});
var kH = Ke, NH = kH("Array", "some"), RH = Me, FH = NH, vh = Array.prototype, BH = function(i) {
  var e = i.some;
  return i === vh || RH(vh, i) && e === vh.some ? FH : e;
}, LH = BH, jH = LH, zH = jH, WH = /* @__PURE__ */ z(zH), HH = Ke, VH = HH("Array", "keys"), UH = VH, GH = UH, KH = yr, YH = De, qH = Me, XH = GH, ph = Array.prototype, JH = {
  DOMTokenList: !0,
  NodeList: !0
}, ZH = function(i) {
  var e = i.keys;
  return i === ph || qH(ph, i) && e === ph.keys || YH(JH, KH(i)) ? XH : e;
}, QH = ZH, Wi = /* @__PURE__ */ z(QH), zg = D$, e4 = Math.floor, Zc = function(i, e) {
  var t = i.length, r = e4(t / 2);
  return t < 8 ? t4(i, e) : r4(
    i,
    Zc(zg(i, 0, r), e),
    Zc(zg(i, r), e),
    e
  );
}, t4 = function(i, e) {
  for (var t = i.length, r = 1, n, o; r < t; ) {
    for (o = r, n = i[r]; o && e(i[o - 1], n) > 0; )
      i[o] = i[--o];
    o !== r++ && (i[o] = n);
  }
  return i;
}, r4 = function(i, e, t, r) {
  for (var n = e.length, o = t.length, s = 0, a = 0; s < n || a < o; )
    i[s + a] = s < n && a < o ? r(e[s], t[a]) <= 0 ? e[s++] : t[a++] : s < n ? e[s++] : t[a++];
  return i;
}, i4 = Zc, n4 = Vr, Wg = n4.match(/firefox\/(\d+)/i), o4 = !!Wg && +Wg[1], s4 = Vr, a4 = /MSIE|Trident/.test(s4), l4 = Vr, Hg = l4.match(/AppleWebKit\/(\d+)\./), d4 = !!Hg && +Hg[1], h4 = F, A0 = he, c4 = ft, u4 = vt, Vg = bt, f4 = q1, Ug = Ti, gf = ee, v4 = i4, p4 = Cl, Gg = o4, g4 = a4, Kg = xn, Yg = d4, Ir = [], qg = A0(Ir.sort), y4 = A0(Ir.push), m4 = gf(function() {
  Ir.sort(void 0);
}), b4 = gf(function() {
  Ir.sort(null);
}), $4 = p4("sort"), M0 = !gf(function() {
  if (Kg) return Kg < 70;
  if (!(Gg && Gg > 3)) {
    if (g4) return !0;
    if (Yg) return Yg < 603;
    var i = "", e, t, r, n;
    for (e = 65; e < 76; e++) {
      switch (t = String.fromCharCode(e), e) {
        case 66:
        case 69:
        case 70:
        case 72:
          r = 3;
          break;
        case 68:
        case 71:
          r = 4;
          break;
        default:
          r = 2;
      }
      for (n = 0; n < 47; n++)
        Ir.push({ k: t + n, v: r });
    }
    for (Ir.sort(function(o, s) {
      return s.v - o.v;
    }), n = 0; n < Ir.length; n++)
      t = Ir[n].k.charAt(0), i.charAt(i.length - 1) !== t && (i += t);
    return i !== "DGBEFHACIJK";
  }
}), w4 = m4 || !b4 || !$4 || !M0, _4 = function(i) {
  return function(e, t) {
    return t === void 0 ? -1 : e === void 0 ? 1 : i !== void 0 ? +i(e, t) || 0 : Ug(e) > Ug(t) ? 1 : -1;
  };
};
h4({ target: "Array", proto: !0, forced: w4 }, {
  sort: function(e) {
    e !== void 0 && c4(e);
    var t = u4(this);
    if (M0) return e === void 0 ? qg(t) : qg(t, e);
    var r = [], n = Vg(t), o, s;
    for (s = 0; s < n; s++)
      s in t && y4(r, t[s]);
    for (v4(r, _4(e)), o = Vg(r), s = 0; s < o; ) t[s] = r[s++];
    for (; s < n; ) f4(t, s++);
    return t;
  }
});
var E4 = Ke, S4 = E4("Array", "sort"), O4 = Me, T4 = S4, gh = Array.prototype, I4 = function(i) {
  var e = i.sort;
  return i === gh || O4(gh, i) && e === gh.sort ? T4 : e;
}, P4 = I4, x4 = P4, C4 = x4, Qc = /* @__PURE__ */ z(C4), A4 = Ke, M4 = A4("Array", "values"), D4 = M4, k4 = D4, N4 = yr, R4 = De, F4 = Me, B4 = k4, yh = Array.prototype, L4 = {
  DOMTokenList: !0,
  NodeList: !0
}, j4 = function(i) {
  var e = i.values;
  return i === yh || F4(yh, i) && e === yh.values || R4(L4, N4(i)) ? B4 : e;
}, z4 = j4, Xg = /* @__PURE__ */ z(z4), W4 = w1, rn = /* @__PURE__ */ z(W4), H4 = Ke, V4 = H4("Array", "entries"), U4 = V4, G4 = U4, K4 = yr, Y4 = De, q4 = Me, X4 = G4, mh = Array.prototype, J4 = {
  DOMTokenList: !0,
  NodeList: !0
}, Z4 = function(i) {
  var e = i.entries;
  return i === mh || q4(mh, i) && e === mh.entries || Y4(J4, K4(i)) ? X4 : e;
}, Q4 = Z4, eV = /* @__PURE__ */ z(Q4);
let Zs;
const tV = new Uint8Array(16);
function rV() {
  if (!Zs && (Zs = typeof crypto < "u" && crypto.getRandomValues && crypto.getRandomValues.bind(crypto), !Zs))
    throw new Error("crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported");
  return Zs(tV);
}
const ze = [];
for (let i = 0; i < 256; ++i)
  ze.push((i + 256).toString(16).slice(1));
function iV(i, e = 0) {
  return ze[i[e + 0]] + ze[i[e + 1]] + ze[i[e + 2]] + ze[i[e + 3]] + "-" + ze[i[e + 4]] + ze[i[e + 5]] + "-" + ze[i[e + 6]] + ze[i[e + 7]] + "-" + ze[i[e + 8]] + ze[i[e + 9]] + "-" + ze[i[e + 10]] + ze[i[e + 11]] + ze[i[e + 12]] + ze[i[e + 13]] + ze[i[e + 14]] + ze[i[e + 15]];
}
const nV = typeof crypto < "u" && crypto.randomUUID && crypto.randomUUID.bind(crypto);
var Jg = {
  randomUUID: nV
};
function oV(i, e, t) {
  if (Jg.randomUUID && !i)
    return Jg.randomUUID();
  i = i || {};
  const r = i.random || (i.rng || rV)();
  return r[6] = r[6] & 15 | 64, r[8] = r[8] & 63 | 128, iV(r);
}
function Zg(i) {
  return typeof i == "string" || typeof i == "number";
}
var sV = /* @__PURE__ */ function() {
  function i(e) {
    dl(this, i), Ar(this, "_queue", []), Ar(this, "_timeout", null), Ar(this, "_extended", null), this.delay = null, this.max = 1 / 0, this.setOptions(e);
  }
  return xl(i, [{
    key: "setOptions",
    value: function(t) {
      t && typeof t.delay < "u" && (this.delay = t.delay), t && typeof t.max < "u" && (this.max = t.max), this._flushIfNeeded();
    }
    /**
     * Extend an object with queuing functionality.
     * The object will be extended with a function flush, and the methods provided in options.replace will be replaced with queued ones.
     * @param object - The object to be extended.
     * @param options - Additional options.
     * @returns The created queue.
     */
  }, {
    key: "destroy",
    value: (
      /**
       * Destroy the queue. The queue will first flush all queued actions, and in case it has extended an object, will restore the original object.
       */
      function() {
        if (this.flush(), this._extended) {
          for (var t = this._extended.object, r = this._extended.methods, n = 0; n < r.length; n++) {
            var o = r[n];
            o.original ? t[o.name] = o.original : delete t[o.name];
          }
          this._extended = null;
        }
      }
    )
    /**
     * Replace a method on an object with a queued version.
     * @param object - Object having the method.
     * @param method - The method name.
     */
  }, {
    key: "replace",
    value: function(t, r) {
      var n = this, o = t[r];
      if (!o)
        throw new Error("Method " + r + " undefined");
      t[r] = function() {
        for (var s = arguments.length, a = new Array(s), l = 0; l < s; l++)
          a[l] = arguments[l];
        n.queue({
          args: a,
          fn: o,
          context: this
        });
      };
    }
    /**
     * Queue a call.
     * @param entry - The function or entry to be queued.
     */
  }, {
    key: "queue",
    value: function(t) {
      typeof t == "function" ? this._queue.push({
        fn: t
      }) : this._queue.push(t), this._flushIfNeeded();
    }
    /**
     * Check whether the queue needs to be flushed.
     */
  }, {
    key: "_flushIfNeeded",
    value: function() {
      var t = this;
      this._queue.length > this.max && this.flush(), this._timeout != null && (clearTimeout(this._timeout), this._timeout = null), this.queue.length > 0 && typeof this.delay == "number" && (this._timeout = DB(function() {
        t.flush();
      }, this.delay));
    }
    /**
     * Flush all queued calls
     */
  }, {
    key: "flush",
    value: function() {
      var t, r;
      pi(t = X1(r = this._queue).call(r, 0)).call(t, function(n) {
        n.fn.apply(n.context || n.fn, n.args || []);
      });
    }
  }], [{
    key: "extend",
    value: function(t, r) {
      var n = new i(r);
      if (t.flush !== void 0)
        throw new Error("Target object already has a property flush");
      t.flush = function() {
        n.flush();
      };
      var o = [{
        name: "flush",
        original: void 0
      }];
      if (r && r.replace)
        for (var s = 0; s < r.replace.length; s++) {
          var a = r.replace[s];
          o.push({
            name: a,
            // @TODO: better solution?
            original: t[a]
          }), n.replace(t, a);
        }
      return n._extended = {
        object: t,
        methods: o
      }, n;
    }
  }]), i;
}(), aV = /* @__PURE__ */ function() {
  function i() {
    dl(this, i), Ar(this, "_subscribers", {
      "*": [],
      add: [],
      remove: [],
      update: []
    }), Ar(this, "subscribe", i.prototype.on), Ar(this, "unsubscribe", i.prototype.off);
  }
  return xl(i, [{
    key: "_trigger",
    value: (
      /**
       * Trigger an event
       * @param event - Event name.
       * @param payload - Event payload.
       * @param senderId - Id of the sender.
       */
      function(t, r, n) {
        var o, s;
        if (t === "*")
          throw new Error("Cannot trigger event *");
        pi(o = Dl(s = []).call(s, lt(this._subscribers[t]), lt(this._subscribers["*"]))).call(o, function(a) {
          a(t, r, n ?? null);
        });
      }
    )
    /**
     * Subscribe to an event, add an event listener.
     * @remarks Non-function callbacks are ignored.
     * @param event - Event name.
     * @param callback - Callback method.
     */
  }, {
    key: "on",
    value: function(t, r) {
      typeof r == "function" && this._subscribers[t].push(r);
    }
    /**
     * Unsubscribe from an event, remove an event listener.
     * @remarks If the same callback was subscribed more than once **all** occurences will be removed.
     * @param event - Event name.
     * @param callback - Callback method.
     */
  }, {
    key: "off",
    value: function(t, r) {
      var n;
      this._subscribers[t] = Ji(n = this._subscribers[t]).call(n, function(o) {
        return o !== r;
      });
    }
  }]), i;
}(), lV = I0, dV = x0;
lV("Set", function(i) {
  return function() {
    return i(this, arguments.length ? arguments[0] : void 0);
  };
}, dV);
var hV = ve, cV = hV.Set, uV = cV, fV = uV, vV = fV, bh = /* @__PURE__ */ z(vV), pV = Yu, gV = pV, yV = gV, mV = yV, bV = mV, $V = bV, wV = $V, _V = wV, EV = _V, SV = EV, $h = /* @__PURE__ */ z(SV);
function Ht(i, e) {
  var t = typeof Ml < "u" && Xu(i) || i["@@iterator"];
  if (!t) {
    if (gt(i) || (t = OV(i)) || e) {
      t && (i = t);
      var r = 0, n = function() {
      };
      return { s: n, n: function() {
        return r >= i.length ? { done: !0 } : { done: !1, value: i[r++] };
      }, e: function(d) {
        throw d;
      }, f: n };
    }
    throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
  }
  var o = !0, s = !1, a;
  return { s: function() {
    t = t.call(i);
  }, n: function() {
    var d = t.next();
    return o = d.done, d;
  }, e: function(d) {
    s = !0, a = d;
  }, f: function() {
    try {
      !o && t.return != null && t.return();
    } finally {
      if (s) throw a;
    }
  } };
}
function OV(i, e) {
  var t;
  if (i) {
    if (typeof i == "string") return Qg(i, e);
    var r = kl(t = Object.prototype.toString.call(i)).call(t, 8, -1);
    if (r === "Object" && i.constructor && (r = i.constructor.name), r === "Map" || r === "Set") return qu(i);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return Qg(i, e);
  }
}
function Qg(i, e) {
  (e == null || e > i.length) && (e = i.length);
  for (var t = 0, r = new Array(e); t < e; t++) r[t] = i[t];
  return r;
}
var ey = /* @__PURE__ */ function(i) {
  function e(t) {
    dl(this, e), this._pairs = t;
  }
  return xl(e, [{
    key: i,
    value: /* @__PURE__ */ ot.mark(function t() {
      var r, n, o, s, a;
      return ot.wrap(function(d) {
        for (; ; ) switch (d.prev = d.next) {
          case 0:
            r = Ht(this._pairs), d.prev = 1, r.s();
          case 3:
            if ((n = r.n()).done) {
              d.next = 9;
              break;
            }
            return o = nt(n.value, 2), s = o[0], a = o[1], d.next = 7, [s, a];
          case 7:
            d.next = 3;
            break;
          case 9:
            d.next = 14;
            break;
          case 11:
            d.prev = 11, d.t0 = d.catch(1), r.e(d.t0);
          case 14:
            return d.prev = 14, r.f(), d.finish(14);
          case 17:
          case "end":
            return d.stop();
        }
      }, t, this, [[1, 11, 14, 17]]);
    })
    /**
     * Return an iterable of key, value pairs for every entry in the stream.
     */
  }, {
    key: "entries",
    value: /* @__PURE__ */ ot.mark(function t() {
      var r, n, o, s, a;
      return ot.wrap(function(d) {
        for (; ; ) switch (d.prev = d.next) {
          case 0:
            r = Ht(this._pairs), d.prev = 1, r.s();
          case 3:
            if ((n = r.n()).done) {
              d.next = 9;
              break;
            }
            return o = nt(n.value, 2), s = o[0], a = o[1], d.next = 7, [s, a];
          case 7:
            d.next = 3;
            break;
          case 9:
            d.next = 14;
            break;
          case 11:
            d.prev = 11, d.t0 = d.catch(1), r.e(d.t0);
          case 14:
            return d.prev = 14, r.f(), d.finish(14);
          case 17:
          case "end":
            return d.stop();
        }
      }, t, this, [[1, 11, 14, 17]]);
    })
    /**
     * Return an iterable of keys in the stream.
     */
  }, {
    key: "keys",
    value: /* @__PURE__ */ ot.mark(function t() {
      var r, n, o, s;
      return ot.wrap(function(l) {
        for (; ; ) switch (l.prev = l.next) {
          case 0:
            r = Ht(this._pairs), l.prev = 1, r.s();
          case 3:
            if ((n = r.n()).done) {
              l.next = 9;
              break;
            }
            return o = nt(n.value, 1), s = o[0], l.next = 7, s;
          case 7:
            l.next = 3;
            break;
          case 9:
            l.next = 14;
            break;
          case 11:
            l.prev = 11, l.t0 = l.catch(1), r.e(l.t0);
          case 14:
            return l.prev = 14, r.f(), l.finish(14);
          case 17:
          case "end":
            return l.stop();
        }
      }, t, this, [[1, 11, 14, 17]]);
    })
    /**
     * Return an iterable of values in the stream.
     */
  }, {
    key: "values",
    value: /* @__PURE__ */ ot.mark(function t() {
      var r, n, o, s;
      return ot.wrap(function(l) {
        for (; ; ) switch (l.prev = l.next) {
          case 0:
            r = Ht(this._pairs), l.prev = 1, r.s();
          case 3:
            if ((n = r.n()).done) {
              l.next = 9;
              break;
            }
            return o = nt(n.value, 2), s = o[1], l.next = 7, s;
          case 7:
            l.next = 3;
            break;
          case 9:
            l.next = 14;
            break;
          case 11:
            l.prev = 11, l.t0 = l.catch(1), r.e(l.t0);
          case 14:
            return l.prev = 14, r.f(), l.finish(14);
          case 17:
          case "end":
            return l.stop();
        }
      }, t, this, [[1, 11, 14, 17]]);
    })
    /**
     * Return an array containing all the ids in this stream.
     * @remarks
     * The array may contain duplicities.
     * @returns The array with all ids from this stream.
     */
  }, {
    key: "toIdArray",
    value: function() {
      var r;
      return At(r = lt(this._pairs)).call(r, function(n) {
        return n[0];
      });
    }
    /**
     * Return an array containing all the items in this stream.
     * @remarks
     * The array may contain duplicities.
     * @returns The array with all items from this stream.
     */
  }, {
    key: "toItemArray",
    value: function() {
      var r;
      return At(r = lt(this._pairs)).call(r, function(n) {
        return n[1];
      });
    }
    /**
     * Return an array containing all the entries in this stream.
     * @remarks
     * The array may contain duplicities.
     * @returns The array with all entries from this stream.
     */
  }, {
    key: "toEntryArray",
    value: function() {
      return lt(this._pairs);
    }
    /**
     * Return an object map containing all the items in this stream accessible by ids.
     * @remarks
     * In case of duplicate ids (coerced to string so `7 == '7'`) the last encoutered appears in the returned object.
     * @returns The object map of all id → item pairs from this stream.
     */
  }, {
    key: "toObjectMap",
    value: function() {
      var r = dB(null), n = Ht(this._pairs), o;
      try {
        for (n.s(); !(o = n.n()).done; ) {
          var s = nt(o.value, 2), a = s[0], l = s[1];
          r[a] = l;
        }
      } catch (d) {
        n.e(d);
      } finally {
        n.f();
      }
      return r;
    }
    /**
     * Return a map containing all the items in this stream accessible by ids.
     * @returns The map of all id → item pairs from this stream.
     */
  }, {
    key: "toMap",
    value: function() {
      return new C0(this._pairs);
    }
    /**
     * Return a set containing all the (unique) ids in this stream.
     * @returns The set of all ids from this stream.
     */
  }, {
    key: "toIdSet",
    value: function() {
      return new bh(this.toIdArray());
    }
    /**
     * Return a set containing all the (unique) items in this stream.
     * @returns The set of all items from this stream.
     */
  }, {
    key: "toItemSet",
    value: function() {
      return new bh(this.toItemArray());
    }
    /**
     * Cache the items from this stream.
     * @remarks
     * This method allows for items to be fetched immediatelly and used (possibly multiple times) later.
     * It can also be used to optimize performance as {@link DataStream} would otherwise reevaluate everything upon each iteration.
     *
     * ## Example
     * ```javascript
     * const ds = new DataSet([…])
     *
     * const cachedStream = ds.stream()
     *   .filter(…)
     *   .sort(…)
     *   .map(…)
     *   .cached(…) // Data are fetched, processed and cached here.
     *
     * ds.clear()
     * chachedStream // Still has all the items.
     * ```
     * @returns A new {@link DataStream} with cached items (detached from the original {@link DataSet}).
     */
  }, {
    key: "cache",
    value: function() {
      return new e(lt(this._pairs));
    }
    /**
     * Get the distinct values of given property.
     * @param callback - The function that picks and possibly converts the property.
     * @typeParam T - The type of the distinct value.
     * @returns A set of all distinct properties.
     */
  }, {
    key: "distinct",
    value: function(r) {
      var n = new bh(), o = Ht(this._pairs), s;
      try {
        for (o.s(); !(s = o.n()).done; ) {
          var a = nt(s.value, 2), l = a[0], d = a[1];
          n.add(r(d, l));
        }
      } catch (h) {
        o.e(h);
      } finally {
        o.f();
      }
      return n;
    }
    /**
     * Filter the items of the stream.
     * @param callback - The function that decides whether an item will be included.
     * @returns A new data stream with the filtered items.
     */
  }, {
    key: "filter",
    value: function(r) {
      var n = this._pairs;
      return new e({
        [rn]() {
          return /* @__PURE__ */ ot.mark(function o() {
            var s, a, l, d, h;
            return ot.wrap(function(u) {
              for (; ; ) switch (u.prev = u.next) {
                case 0:
                  s = Ht(n), u.prev = 1, s.s();
                case 3:
                  if ((a = s.n()).done) {
                    u.next = 10;
                    break;
                  }
                  if (l = nt(a.value, 2), d = l[0], h = l[1], !r(h, d)) {
                    u.next = 8;
                    break;
                  }
                  return u.next = 8, [d, h];
                case 8:
                  u.next = 3;
                  break;
                case 10:
                  u.next = 15;
                  break;
                case 12:
                  u.prev = 12, u.t0 = u.catch(1), s.e(u.t0);
                case 15:
                  return u.prev = 15, s.f(), u.finish(15);
                case 18:
                case "end":
                  return u.stop();
              }
            }, o, null, [[1, 12, 15, 18]]);
          })();
        }
      });
    }
    /**
     * Execute a callback for each item of the stream.
     * @param callback - The function that will be invoked for each item.
     */
  }, {
    key: "forEach",
    value: function(r) {
      var n = Ht(this._pairs), o;
      try {
        for (n.s(); !(o = n.n()).done; ) {
          var s = nt(o.value, 2), a = s[0], l = s[1];
          r(l, a);
        }
      } catch (d) {
        n.e(d);
      } finally {
        n.f();
      }
    }
    /**
     * Map the items into a different type.
     * @param callback - The function that does the conversion.
     * @typeParam Mapped - The type of the item after mapping.
     * @returns A new data stream with the mapped items.
     */
  }, {
    key: "map",
    value: function(r) {
      var n = this._pairs;
      return new e({
        [rn]() {
          return /* @__PURE__ */ ot.mark(function o() {
            var s, a, l, d, h;
            return ot.wrap(function(u) {
              for (; ; ) switch (u.prev = u.next) {
                case 0:
                  s = Ht(n), u.prev = 1, s.s();
                case 3:
                  if ((a = s.n()).done) {
                    u.next = 9;
                    break;
                  }
                  return l = nt(a.value, 2), d = l[0], h = l[1], u.next = 7, [d, r(h, d)];
                case 7:
                  u.next = 3;
                  break;
                case 9:
                  u.next = 14;
                  break;
                case 11:
                  u.prev = 11, u.t0 = u.catch(1), s.e(u.t0);
                case 14:
                  return u.prev = 14, s.f(), u.finish(14);
                case 17:
                case "end":
                  return u.stop();
              }
            }, o, null, [[1, 11, 14, 17]]);
          })();
        }
      });
    }
    /**
     * Get the item with the maximum value of given property.
     * @param callback - The function that picks and possibly converts the property.
     * @returns The item with the maximum if found otherwise null.
     */
  }, {
    key: "max",
    value: function(r) {
      var n = $h(this._pairs), o = n.next();
      if (o.done)
        return null;
      for (var s = o.value[1], a = r(o.value[1], o.value[0]); !(o = n.next()).done; ) {
        var l = nt(o.value, 2), d = l[0], h = l[1], c = r(h, d);
        c > a && (a = c, s = h);
      }
      return s;
    }
    /**
     * Get the item with the minimum value of given property.
     * @param callback - The function that picks and possibly converts the property.
     * @returns The item with the minimum if found otherwise null.
     */
  }, {
    key: "min",
    value: function(r) {
      var n = $h(this._pairs), o = n.next();
      if (o.done)
        return null;
      for (var s = o.value[1], a = r(o.value[1], o.value[0]); !(o = n.next()).done; ) {
        var l = nt(o.value, 2), d = l[0], h = l[1], c = r(h, d);
        c < a && (a = c, s = h);
      }
      return s;
    }
    /**
     * Reduce the items into a single value.
     * @param callback - The function that does the reduction.
     * @param accumulator - The initial value of the accumulator.
     * @typeParam T - The type of the accumulated value.
     * @returns The reduced value.
     */
  }, {
    key: "reduce",
    value: function(r, n) {
      var o = Ht(this._pairs), s;
      try {
        for (o.s(); !(s = o.n()).done; ) {
          var a = nt(s.value, 2), l = a[0], d = a[1];
          n = r(n, d, l);
        }
      } catch (h) {
        o.e(h);
      } finally {
        o.f();
      }
      return n;
    }
    /**
     * Sort the items.
     * @param callback - Item comparator.
     * @returns A new stream with sorted items.
     */
  }, {
    key: "sort",
    value: function(r) {
      var n = this;
      return new e({
        [rn]: function() {
          var o;
          return $h(Qc(o = lt(n._pairs)).call(o, function(s, a) {
            var l = nt(s, 2), d = l[0], h = l[1], c = nt(a, 2), u = c[0], f = c[1];
            return r(h, f, d, u);
          }));
        }
      });
    }
  }]), e;
}(rn);
function ty(i, e) {
  var t = Zu(i);
  if (rg) {
    var r = rg(i);
    e && (r = Ji(r).call(r, function(n) {
      return zw(i, n).enumerable;
    })), t.push.apply(t, r);
  }
  return t;
}
function ry(i) {
  for (var e = 1; e < arguments.length; e++) {
    var t, r, n = arguments[e] != null ? arguments[e] : {};
    e % 2 ? pi(t = ty(Object(n), !0)).call(t, function(o) {
      Ar(i, o, n[o]);
    }) : ig ? Ej(i, ig(n)) : pi(r = ty(Object(n))).call(r, function(o) {
      Oj(i, o, zw(n, o));
    });
  }
  return i;
}
function wh(i, e) {
  var t = typeof Ml < "u" && Xu(i) || i["@@iterator"];
  if (!t) {
    if (gt(i) || (t = TV(i)) || e) {
      t && (i = t);
      var r = 0, n = function() {
      };
      return { s: n, n: function() {
        return r >= i.length ? { done: !0 } : { done: !1, value: i[r++] };
      }, e: function(d) {
        throw d;
      }, f: n };
    }
    throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
  }
  var o = !0, s = !1, a;
  return { s: function() {
    t = t.call(i);
  }, n: function() {
    var d = t.next();
    return o = d.done, d;
  }, e: function(d) {
    s = !0, a = d;
  }, f: function() {
    try {
      !o && t.return != null && t.return();
    } finally {
      if (s) throw a;
    }
  } };
}
function TV(i, e) {
  var t;
  if (i) {
    if (typeof i == "string") return iy(i, e);
    var r = kl(t = Object.prototype.toString.call(i)).call(t, 8, -1);
    if (r === "Object" && i.constructor && (r = i.constructor.name), r === "Map" || r === "Set") return qu(i);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return iy(i, e);
  }
}
function iy(i, e) {
  (e == null || e > i.length) && (e = i.length);
  for (var t = 0, r = new Array(e); t < e; t++) r[t] = i[t];
  return r;
}
function IV(i) {
  var e = PV();
  return function() {
    var r = Ga(i), n;
    if (e) {
      var o = Ga(this).constructor;
      n = Sa(r, arguments, o);
    } else
      n = r.apply(this, arguments);
    return Kj(this, n);
  };
}
function PV() {
  if (typeof Reflect > "u" || !Sa || Sa.sham) return !1;
  if (typeof Proxy == "function") return !0;
  try {
    return Boolean.prototype.valueOf.call(Sa(Boolean, [], function() {
    })), !0;
  } catch {
    return !1;
  }
}
function xV(i, e) {
  return i[e] == null && (i[e] = oV()), i;
}
var bn = /* @__PURE__ */ function(i) {
  Gj(t, i);
  var e = IV(t);
  function t(r, n) {
    var o;
    return dl(this, t), o = e.call(this), Ar(Vw(o), "_queue", null), r && !gt(r) && (n = r, r = []), o._options = n || {}, o._data = new C0(), o.length = 0, o._idProp = o._options.fieldId || "id", r && r.length && o.add(r), o.setOptions(n), o;
  }
  return xl(t, [{
    key: "idProp",
    get: (
      /** Flush all queued calls. */
      /** @inheritDoc */
      /** @inheritDoc */
      function() {
        return this._idProp;
      }
    )
  }, {
    key: "setOptions",
    value: function(n) {
      n && n.queue !== void 0 && (n.queue === !1 ? this._queue && (this._queue.destroy(), this._queue = null) : (this._queue || (this._queue = sV.extend(this, {
        replace: ["add", "update", "remove"]
      })), n.queue && typeof n.queue == "object" && this._queue.setOptions(n.queue)));
    }
    /**
     * Add a data item or an array with items.
     *
     * After the items are added to the DataSet, the DataSet will trigger an event `add`. When a `senderId` is provided, this id will be passed with the triggered event to all subscribers.
     *
     * ## Example
     *
     * ```javascript
     * // create a DataSet
     * const data = new vis.DataSet()
     *
     * // add items
     * const ids = data.add([
     * { id: 1, text: 'item 1' },
     * { id: 2, text: 'item 2' },
     * { text: 'item without an id' }
     * ])
     *
     * console.log(ids) // [1, 2, '<UUIDv4>']
     * ```
     * @param data - Items to be added (ids will be generated if missing).
     * @param senderId - Sender id.
     * @returns addedIds - Array with the ids (generated if not present) of the added items.
     * @throws When an item with the same id as any of the added items already exists.
     */
  }, {
    key: "add",
    value: function(n, o) {
      var s = this, a = [], l;
      if (gt(n)) {
        var d = At(n).call(n, function(u) {
          return u[s._idProp];
        });
        if (WH(d).call(d, function(u) {
          return s._data.has(u);
        }))
          throw new Error("A duplicate id was found in the parameter array.");
        for (var h = 0, c = n.length; h < c; h++)
          l = this._addItem(n[h]), a.push(l);
      } else if (n && typeof n == "object")
        l = this._addItem(n), a.push(l);
      else
        throw new Error("Unknown dataType");
      return a.length && this._trigger("add", {
        items: a
      }, o), a;
    }
    /**
     * Update existing items. When an item does not exist, it will be created.
     * @remarks
     * The provided properties will be merged in the existing item. When an item does not exist, it will be created.
     *
     * After the items are updated, the DataSet will trigger an event `add` for the added items, and an event `update`. When a `senderId` is provided, this id will be passed with the triggered event to all subscribers.
     *
     * ## Example
     *
     * ```javascript
     * // create a DataSet
     * const data = new vis.DataSet([
     *   { id: 1, text: 'item 1' },
     *   { id: 2, text: 'item 2' },
     *   { id: 3, text: 'item 3' }
     * ])
     *
     * // update items
     * const ids = data.update([
     *   { id: 2, text: 'item 2 (updated)' },
     *   { id: 4, text: 'item 4 (new)' }
     * ])
     *
     * console.log(ids) // [2, 4]
     * ```
     *
     * ## Warning for TypeScript users
     * This method may introduce partial items into the data set. Use add or updateOnly instead for better type safety.
     * @param data - Items to be updated (if the id is already present) or added (if the id is missing).
     * @param senderId - Sender id.
     * @returns updatedIds - The ids of the added (these may be newly generated if there was no id in the item from the data) or updated items.
     * @throws When the supplied data is neither an item nor an array of items.
     */
  }, {
    key: "update",
    value: function(n, o) {
      var s = this, a = [], l = [], d = [], h = [], c = this._idProp, u = function(p) {
        var m = p[c];
        if (m != null && s._data.has(m)) {
          var $ = p, w = UF({}, s._data.get(m)), T = s._updateItem($);
          l.push(T), h.push($), d.push(w);
        } else {
          var A = s._addItem(p);
          a.push(A);
        }
      };
      if (gt(n))
        for (var f = 0, v = n.length; f < v; f++)
          n[f] && typeof n[f] == "object" ? u(n[f]) : console.warn("Ignoring input item, which is not an object at index " + f);
      else if (n && typeof n == "object")
        u(n);
      else
        throw new Error("Unknown dataType");
      if (a.length && this._trigger("add", {
        items: a
      }, o), l.length) {
        var y = {
          items: l,
          oldData: d,
          data: h
        };
        this._trigger("update", y, o);
      }
      return Dl(a).call(a, l);
    }
    /**
     * Update existing items. When an item does not exist, an error will be thrown.
     * @remarks
     * The provided properties will be deeply merged into the existing item.
     * When an item does not exist (id not present in the data set or absent), an error will be thrown and nothing will be changed.
     *
     * After the items are updated, the DataSet will trigger an event `update`.
     * When a `senderId` is provided, this id will be passed with the triggered event to all subscribers.
     *
     * ## Example
     *
     * ```javascript
     * // create a DataSet
     * const data = new vis.DataSet([
     *   { id: 1, text: 'item 1' },
     *   { id: 2, text: 'item 2' },
     *   { id: 3, text: 'item 3' },
     * ])
     *
     * // update items
     * const ids = data.update([
     *   { id: 2, text: 'item 2 (updated)' }, // works
     *   // { id: 4, text: 'item 4 (new)' }, // would throw
     *   // { text: 'item 4 (new)' }, // would also throw
     * ])
     *
     * console.log(ids) // [2]
     * ```
     * @param data - Updates (the id and optionally other props) to the items in this data set.
     * @param senderId - Sender id.
     * @returns updatedIds - The ids of the updated items.
     * @throws When the supplied data is neither an item nor an array of items, when the ids are missing.
     */
  }, {
    key: "updateOnly",
    value: function(n, o) {
      var s, a = this;
      gt(n) || (n = [n]);
      var l = At(s = At(n).call(n, function(h) {
        var c = a._data.get(h[a._idProp]);
        if (c == null)
          throw new Error("Updating non-existent items is not allowed.");
        return {
          oldData: c,
          update: h
        };
      })).call(s, function(h) {
        var c = h.oldData, u = h.update, f = c[a._idProp], v = SL(c, u);
        return a._data.set(f, v), {
          id: f,
          oldData: c,
          updatedData: v
        };
      });
      if (l.length) {
        var d = {
          items: At(l).call(l, function(h) {
            return h.id;
          }),
          oldData: At(l).call(l, function(h) {
            return h.oldData;
          }),
          data: At(l).call(l, function(h) {
            return h.updatedData;
          })
        };
        return this._trigger("update", d, o), d.items;
      } else
        return [];
    }
    /** @inheritDoc */
  }, {
    key: "get",
    value: function(n, o) {
      var s = void 0, a = void 0, l = void 0;
      Zg(n) ? (s = n, l = o) : gt(n) ? (a = n, l = o) : l = n;
      var d = l && l.returnType === "Object" ? "Object" : "Array", h = l && Ji(l), c = [], u = void 0, f = void 0, v = void 0;
      if (s != null)
        u = this._data.get(s), u && h && !h(u) && (u = void 0);
      else if (a != null)
        for (var y = 0, g = a.length; y < g; y++)
          u = this._data.get(a[y]), u != null && (!h || h(u)) && c.push(u);
      else {
        var p;
        f = lt(Wi(p = this._data).call(p));
        for (var m = 0, $ = f.length; m < $; m++)
          v = f[m], u = this._data.get(v), u != null && (!h || h(u)) && c.push(u);
      }
      if (l && l.order && s == null && this._sort(c, l.order), l && l.fields) {
        var w = l.fields;
        if (s != null && u != null)
          u = this._filterFields(u, w);
        else
          for (var T = 0, A = c.length; T < A; T++)
            c[T] = this._filterFields(c[T], w);
      }
      if (d == "Object") {
        for (var L = {}, G = 0, ne = c.length; G < ne; G++) {
          var oe = c[G], Pe = oe[this._idProp];
          L[Pe] = oe;
        }
        return L;
      } else if (s != null) {
        var pe;
        return (pe = u) !== null && pe !== void 0 ? pe : null;
      } else
        return c;
    }
    /** @inheritDoc */
  }, {
    key: "getIds",
    value: function(n) {
      var o = this._data, s = n && Ji(n), a = n && n.order, l = lt(Wi(o).call(o)), d = [];
      if (s)
        if (a) {
          for (var h = [], c = 0, u = l.length; c < u; c++) {
            var f = l[c], v = this._data.get(f);
            v != null && s(v) && h.push(v);
          }
          this._sort(h, a);
          for (var y = 0, g = h.length; y < g; y++)
            d.push(h[y][this._idProp]);
        } else
          for (var p = 0, m = l.length; p < m; p++) {
            var $ = l[p], w = this._data.get($);
            w != null && s(w) && d.push(w[this._idProp]);
          }
      else if (a) {
        for (var T = [], A = 0, L = l.length; A < L; A++) {
          var G = l[A];
          T.push(o.get(G));
        }
        this._sort(T, a);
        for (var ne = 0, oe = T.length; ne < oe; ne++)
          d.push(T[ne][this._idProp]);
      } else
        for (var Pe = 0, pe = l.length; Pe < pe; Pe++) {
          var ce = l[Pe], x = o.get(ce);
          x != null && d.push(x[this._idProp]);
        }
      return d;
    }
    /** @inheritDoc */
  }, {
    key: "getDataSet",
    value: function() {
      return this;
    }
    /** @inheritDoc */
  }, {
    key: "forEach",
    value: function(n, o) {
      var s = o && Ji(o), a = this._data, l = lt(Wi(a).call(a));
      if (o && o.order)
        for (var d = this.get(o), h = 0, c = d.length; h < c; h++) {
          var u = d[h], f = u[this._idProp];
          n(u, f);
        }
      else
        for (var v = 0, y = l.length; v < y; v++) {
          var g = l[v], p = this._data.get(g);
          p != null && (!s || s(p)) && n(p, g);
        }
    }
    /** @inheritDoc */
  }, {
    key: "map",
    value: function(n, o) {
      for (var s = o && Ji(o), a = [], l = this._data, d = lt(Wi(l).call(l)), h = 0, c = d.length; h < c; h++) {
        var u = d[h], f = this._data.get(u);
        f != null && (!s || s(f)) && a.push(n(f, u));
      }
      return o && o.order && this._sort(a, o.order), a;
    }
    /**
     * Filter the fields of an item.
     * @param item - The item whose fields should be filtered.
     * @param fields - The names of the fields that will be kept.
     * @typeParam K - Field name type.
     * @returns The item without any additional fields.
     */
  }, {
    key: "_filterFields",
    value: function(n, o) {
      var s;
      return n && a2(s = gt(o) ? (
        // Use the supplied array
        o
      ) : (
        // Use the keys of the supplied object
        Zu(o)
      )).call(s, function(a, l) {
        return a[l] = n[l], a;
      }, {});
    }
    /**
     * Sort the provided array with items.
     * @param items - Items to be sorted in place.
     * @param order - A field name or custom sort function.
     * @typeParam T - The type of the items in the items array.
     */
  }, {
    key: "_sort",
    value: function(n, o) {
      if (typeof o == "string") {
        var s = o;
        Qc(n).call(n, function(a, l) {
          var d = a[s], h = l[s];
          return d > h ? 1 : d < h ? -1 : 0;
        });
      } else if (typeof o == "function")
        Qc(n).call(n, o);
      else
        throw new TypeError("Order must be a function or a string");
    }
    /**
     * Remove an item or multiple items by “reference” (only the id is used) or by id.
     *
     * The method ignores removal of non-existing items, and returns an array containing the ids of the items which are actually removed from the DataSet.
     *
     * After the items are removed, the DataSet will trigger an event `remove` for the removed items. When a `senderId` is provided, this id will be passed with the triggered event to all subscribers.
     *
     * ## Example
     * ```javascript
     * // create a DataSet
     * const data = new vis.DataSet([
     * { id: 1, text: 'item 1' },
     * { id: 2, text: 'item 2' },
     * { id: 3, text: 'item 3' }
     * ])
     *
     * // remove items
     * const ids = data.remove([2, { id: 3 }, 4])
     *
     * console.log(ids) // [2, 3]
     * ```
     * @param id - One or more items or ids of items to be removed.
     * @param senderId - Sender id.
     * @returns The ids of the removed items.
     */
  }, {
    key: "remove",
    value: function(n, o) {
      for (var s = [], a = [], l = gt(n) ? n : [n], d = 0, h = l.length; d < h; d++) {
        var c = this._remove(l[d]);
        if (c) {
          var u = c[this._idProp];
          u != null && (s.push(u), a.push(c));
        }
      }
      return s.length && this._trigger("remove", {
        items: s,
        oldData: a
      }, o), s;
    }
    /**
     * Remove an item by its id or reference.
     * @param id - Id of an item or the item itself.
     * @returns The removed item if removed, null otherwise.
     */
  }, {
    key: "_remove",
    value: function(n) {
      var o;
      if (Zg(n) ? o = n : n && typeof n == "object" && (o = n[this._idProp]), o != null && this._data.has(o)) {
        var s = this._data.get(o) || null;
        return this._data.delete(o), --this.length, s;
      }
      return null;
    }
    /**
     * Clear the entire data set.
     *
     * After the items are removed, the {@link DataSet} will trigger an event `remove` for all removed items. When a `senderId` is provided, this id will be passed with the triggered event to all subscribers.
     * @param senderId - Sender id.
     * @returns removedIds - The ids of all removed items.
     */
  }, {
    key: "clear",
    value: function(n) {
      for (var o, s = lt(Wi(o = this._data).call(o)), a = [], l = 0, d = s.length; l < d; l++)
        a.push(this._data.get(s[l]));
      return this._data.clear(), this.length = 0, this._trigger("remove", {
        items: s,
        oldData: a
      }, n), s;
    }
    /**
     * Find the item with maximum value of a specified field.
     * @param field - Name of the property that should be searched for max value.
     * @returns Item containing max value, or null if no items.
     */
  }, {
    key: "max",
    value: function(n) {
      var o, s = null, a = null, l = wh(Xg(o = this._data).call(o)), d;
      try {
        for (l.s(); !(d = l.n()).done; ) {
          var h = d.value, c = h[n];
          typeof c == "number" && (a == null || c > a) && (s = h, a = c);
        }
      } catch (u) {
        l.e(u);
      } finally {
        l.f();
      }
      return s || null;
    }
    /**
     * Find the item with minimum value of a specified field.
     * @param field - Name of the property that should be searched for min value.
     * @returns Item containing min value, or null if no items.
     */
  }, {
    key: "min",
    value: function(n) {
      var o, s = null, a = null, l = wh(Xg(o = this._data).call(o)), d;
      try {
        for (l.s(); !(d = l.n()).done; ) {
          var h = d.value, c = h[n];
          typeof c == "number" && (a == null || c < a) && (s = h, a = c);
        }
      } catch (u) {
        l.e(u);
      } finally {
        l.f();
      }
      return s || null;
    }
    /**
     * Find all distinct values of a specified field
     * @param prop - The property name whose distinct values should be returned.
     * @returns Unordered array containing all distinct values. Items without specified property are ignored.
     */
  }, {
    key: "distinct",
    value: function(n) {
      for (var o = this._data, s = lt(Wi(o).call(o)), a = [], l = 0, d = 0, h = s.length; d < h; d++) {
        for (var c = s[d], u = o.get(c), f = u[n], v = !1, y = 0; y < l; y++)
          if (a[y] == f) {
            v = !0;
            break;
          }
        !v && f !== void 0 && (a[l] = f, l++);
      }
      return a;
    }
    /**
     * Add a single item. Will fail when an item with the same id already exists.
     * @param item - A new item to be added.
     * @returns Added item's id. An id is generated when it is not present in the item.
     */
  }, {
    key: "_addItem",
    value: function(n) {
      var o = xV(n, this._idProp), s = o[this._idProp];
      if (this._data.has(s))
        throw new Error("Cannot add item: item with id " + s + " already exists");
      return this._data.set(s, o), ++this.length, s;
    }
    /**
     * Update a single item: merge with existing item.
     * Will fail when the item has no id, or when there does not exist an item with the same id.
     * @param update - The new item
     * @returns The id of the updated item.
     */
  }, {
    key: "_updateItem",
    value: function(n) {
      var o = n[this._idProp];
      if (o == null)
        throw new Error("Cannot update item: item has no id (item: " + pB(n) + ")");
      var s = this._data.get(o);
      if (!s)
        throw new Error("Cannot update item: no item with id " + o + " found");
      return this._data.set(o, ry(ry({}, s), n)), o;
    }
    /** @inheritDoc */
  }, {
    key: "stream",
    value: function(n) {
      if (n) {
        var o = this._data;
        return new ey({
          [rn]() {
            return /* @__PURE__ */ ot.mark(function a() {
              var l, d, h, c;
              return ot.wrap(function(f) {
                for (; ; ) switch (f.prev = f.next) {
                  case 0:
                    l = wh(n), f.prev = 1, l.s();
                  case 3:
                    if ((d = l.n()).done) {
                      f.next = 11;
                      break;
                    }
                    if (h = d.value, c = o.get(h), c == null) {
                      f.next = 9;
                      break;
                    }
                    return f.next = 9, [h, c];
                  case 9:
                    f.next = 3;
                    break;
                  case 11:
                    f.next = 16;
                    break;
                  case 13:
                    f.prev = 13, f.t0 = f.catch(1), l.e(f.t0);
                  case 16:
                    return f.prev = 16, l.f(), f.finish(16);
                  case 19:
                  case "end":
                    return f.stop();
                }
              }, a, null, [[1, 13, 16, 19]]);
            })();
          }
        });
      } else {
        var s;
        return new ey({
          [rn]: P1(s = eV(this._data)).call(s, this._data)
        });
      }
    }
  }]), t;
}(aV);
function CV(i, e) {
  return typeof e == "object" && e !== null && i === e.idProp && typeof e.add == "function" && typeof e.clear == "function" && typeof e.distinct == "function" && typeof pi(e) == "function" && typeof e.get == "function" && typeof e.getDataSet == "function" && typeof e.getIds == "function" && typeof e.length == "number" && typeof At(e) == "function" && typeof e.max == "function" && typeof e.min == "function" && typeof e.off == "function" && typeof e.on == "function" && typeof e.remove == "function" && typeof e.setOptions == "function" && typeof e.stream == "function" && typeof e.update == "function" && typeof e.updateOnly == "function";
}
function D0(i, e) {
  return typeof e == "object" && e !== null && i === e.idProp && typeof pi(e) == "function" && typeof e.get == "function" && typeof e.getDataSet == "function" && typeof e.getIds == "function" && typeof e.length == "number" && typeof At(e) == "function" && typeof e.off == "function" && typeof e.on == "function" && typeof e.stream == "function" && CV(i, e.getDataSet());
}
/**
 * vis-network
 * https://visjs.github.io/vis-network/
 *
 * A dynamic, browser-based visualization library.
 *
 * @version 9.1.13
 * @date    2025-06-28T12:43:17.849Z
 *
 * @copyright (c) 2011-2017 Almende B.V, http://almende.com
 * @copyright (c) 2017-2019 visjs contributors, https://github.com/visjs
 *
 * @license
 * vis.js is dual licensed under both
 *
 *   1. The Apache 2.0 License
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *   and
 *
 *   2. The MIT License
 *      http://opensource.org/licenses/MIT
 *
 * vis.js may be distributed under either license.
 */
var _h = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};
function U(i) {
  return i && i.__esModule && Object.prototype.hasOwnProperty.call(i, "default") ? i.default : i;
}
var Qs = function(i) {
  return i && i.Math === Math && i;
}, _e = (
  // eslint-disable-next-line es/no-global-this -- safe
  Qs(typeof globalThis == "object" && globalThis) || Qs(typeof window == "object" && window) || // eslint-disable-next-line no-restricted-globals -- safe
  Qs(typeof self == "object" && self) || Qs(typeof _h == "object" && _h) || // eslint-disable-next-line no-new-func -- fallback
  /* @__PURE__ */ function() {
    return this;
  }() || _h || Function("return this")()
), Z = function(i) {
  try {
    return !!i();
  } catch {
    return !0;
  }
}, AV = Z, is = !AV(function() {
  var i = (function() {
  }).bind();
  return typeof i != "function" || i.hasOwnProperty("prototype");
}), MV = is, k0 = Function.prototype, ny = k0.apply, oy = k0.call, Ll = typeof Reflect == "object" && Reflect.apply || (MV ? oy.bind(ny) : function() {
  return oy.apply(ny, arguments);
}), N0 = is, R0 = Function.prototype, eu = R0.call, DV = N0 && R0.bind.bind(eu, eu), Q = N0 ? DV : function(i) {
  return function() {
    return eu.apply(i, arguments);
  };
}, F0 = Q, kV = F0({}.toString), NV = F0("".slice), mr = function(i) {
  return NV(kV(i), 8, -1);
}, RV = mr, FV = Q, yf = function(i) {
  if (RV(i) === "Function") return FV(i);
}, tu = typeof document == "object" && document.all, BV = typeof tu > "u" && tu !== void 0, B0 = {
  all: tu,
  IS_HTMLDDA: BV
}, L0 = B0, LV = L0.all, Ve = L0.IS_HTMLDDA ? function(i) {
  return typeof i == "function" || i === LV;
} : function(i) {
  return typeof i == "function";
}, ns = {}, jV = Z, Ne = !jV(function() {
  return Object.defineProperty({}, 1, { get: function() {
    return 7;
  } })[1] !== 7;
}), zV = is, ea = Function.prototype.call, Bt = zV ? ea.bind(ea) : function() {
  return ea.apply(ea, arguments);
}, os = {}, j0 = {}.propertyIsEnumerable, z0 = Object.getOwnPropertyDescriptor, WV = z0 && !j0.call({ 1: 2 }, 1);
os.f = WV ? function(e) {
  var t = z0(this, e);
  return !!t && t.enumerable;
} : j0;
var ss = function(i, e) {
  return {
    enumerable: !(i & 1),
    configurable: !(i & 2),
    writable: !(i & 4),
    value: e
  };
}, HV = Q, VV = Z, UV = mr, Eh = Object, GV = HV("".split), jl = VV(function() {
  return !Eh("z").propertyIsEnumerable(0);
}) ? function(i) {
  return UV(i) === "String" ? GV(i, "") : Eh(i);
} : Eh, zn = function(i) {
  return i == null;
}, KV = zn, YV = TypeError, as = function(i) {
  if (KV(i)) throw new YV("Can't call method on " + i);
  return i;
}, qV = jl, XV = as, Lt = function(i) {
  return qV(XV(i));
}, sy = Ve, W0 = B0, JV = W0.all, Ye = W0.IS_HTMLDDA ? function(i) {
  return typeof i == "object" ? i !== null : sy(i) || i === JV;
} : function(i) {
  return typeof i == "object" ? i !== null : sy(i);
}, ie = {}, Sh = ie, Oh = _e, ZV = Ve, ay = function(i) {
  return ZV(i) ? i : void 0;
}, jt = function(i, e) {
  return arguments.length < 2 ? ay(Sh[i]) || ay(Oh[i]) : Sh[i] && Sh[i][e] || Oh[i] && Oh[i][e];
}, QV = Q, ke = QV({}.isPrototypeOf), ls = typeof navigator < "u" && String(navigator.userAgent) || "", H0 = _e, Th = ls, ly = H0.process, dy = H0.Deno, hy = ly && ly.versions || dy && dy.version, cy = hy && hy.v8, Mt, Xa;
cy && (Mt = cy.split("."), Xa = Mt[0] > 0 && Mt[0] < 4 ? 1 : +(Mt[0] + Mt[1]));
!Xa && Th && (Mt = Th.match(/Edge\/(\d+)/), (!Mt || Mt[1] >= 74) && (Mt = Th.match(/Chrome\/(\d+)/), Mt && (Xa = +Mt[1])));
var ds = Xa, uy = ds, e6 = Z, t6 = _e, r6 = t6.String, Wn = !!Object.getOwnPropertySymbols && !e6(function() {
  var i = Symbol("symbol detection");
  return !r6(i) || !(Object(i) instanceof Symbol) || // Chrome 38-40 symbols are not inherited from DOM collections prototypes to instances
  !Symbol.sham && uy && uy < 41;
}), i6 = Wn, V0 = i6 && !Symbol.sham && typeof Symbol.iterator == "symbol", n6 = jt, o6 = Ve, s6 = ke, a6 = V0, l6 = Object, hs = a6 ? function(i) {
  return typeof i == "symbol";
} : function(i) {
  var e = n6("Symbol");
  return o6(e) && s6(e.prototype, l6(i));
}, d6 = String, cs = function(i) {
  try {
    return d6(i);
  } catch {
    return "Object";
  }
}, h6 = Ve, c6 = cs, u6 = TypeError, Hn = function(i) {
  if (h6(i)) return i;
  throw new u6(c6(i) + " is not a function");
}, f6 = Hn, v6 = zn, mf = function(i, e) {
  var t = i[e];
  return v6(t) ? void 0 : f6(t);
}, Ih = Bt, Ph = Ve, xh = Ye, p6 = TypeError, g6 = function(i, e) {
  var t, r;
  if (e === "string" && Ph(t = i.toString) && !xh(r = Ih(t, i)) || Ph(t = i.valueOf) && !xh(r = Ih(t, i)) || e !== "string" && Ph(t = i.toString) && !xh(r = Ih(t, i))) return r;
  throw new p6("Can't convert object to primitive value");
}, U0 = { exports: {} }, fy = _e, y6 = Object.defineProperty, m6 = function(i, e) {
  try {
    y6(fy, i, { value: e, configurable: !0, writable: !0 });
  } catch {
    fy[i] = e;
  }
  return e;
}, b6 = _e, $6 = m6, vy = "__core-js_shared__", w6 = b6[vy] || $6(vy, {}), bf = w6, py = bf;
(U0.exports = function(i, e) {
  return py[i] || (py[i] = e !== void 0 ? e : {});
})("versions", []).push({
  version: "3.33.0",
  mode: "pure",
  copyright: "© 2014-2023 Denis Pushkarev (zloirock.ru)",
  license: "https://github.com/zloirock/core-js/blob/v3.33.0/LICENSE",
  source: "https://github.com/zloirock/core-js"
});
var Vn = U0.exports, _6 = as, E6 = Object, Pt = function(i) {
  return E6(_6(i));
}, S6 = Q, O6 = Pt, T6 = S6({}.hasOwnProperty), Ue = Object.hasOwn || function(e, t) {
  return T6(O6(e), t);
}, I6 = Q, P6 = 0, x6 = Math.random(), C6 = I6(1 .toString), zl = function(i) {
  return "Symbol(" + (i === void 0 ? "" : i) + ")_" + C6(++P6 + x6, 36);
}, A6 = _e, M6 = Vn, gy = Ue, D6 = zl, k6 = Wn, N6 = V0, nn = A6.Symbol, Ch = M6("wks"), R6 = N6 ? nn.for || nn : nn && nn.withoutSetter || D6, Ie = function(i) {
  return gy(Ch, i) || (Ch[i] = k6 && gy(nn, i) ? nn[i] : R6("Symbol." + i)), Ch[i];
}, F6 = Bt, yy = Ye, my = hs, B6 = mf, L6 = g6, j6 = Ie, z6 = TypeError, W6 = j6("toPrimitive"), H6 = function(i, e) {
  if (!yy(i) || my(i)) return i;
  var t = B6(i, W6), r;
  if (t) {
    if (e === void 0 && (e = "default"), r = F6(t, i, e), !yy(r) || my(r)) return r;
    throw new z6("Can't convert object to primitive value");
  }
  return e === void 0 && (e = "number"), L6(i, e);
}, V6 = H6, U6 = hs, Wl = function(i) {
  var e = V6(i, "string");
  return U6(e) ? e : e + "";
}, G6 = _e, by = Ye, ru = G6.document, K6 = by(ru) && by(ru.createElement), G0 = function(i) {
  return K6 ? ru.createElement(i) : {};
}, Y6 = Ne, q6 = Z, X6 = G0, K0 = !Y6 && !q6(function() {
  return Object.defineProperty(X6("div"), "a", {
    get: function() {
      return 7;
    }
  }).a !== 7;
}), J6 = Ne, Z6 = Bt, Q6 = os, eU = ss, tU = Lt, rU = Wl, iU = Ue, nU = K0, $y = Object.getOwnPropertyDescriptor;
ns.f = J6 ? $y : function(e, t) {
  if (e = tU(e), t = rU(t), nU) try {
    return $y(e, t);
  } catch {
  }
  if (iU(e, t)) return eU(!Z6(Q6.f, e, t), e[t]);
};
var oU = Z, sU = Ve, aU = /#|\.prototype\./, us = function(i, e) {
  var t = dU[lU(i)];
  return t === cU ? !0 : t === hU ? !1 : sU(e) ? oU(e) : !!e;
}, lU = us.normalize = function(i) {
  return String(i).replace(aU, ".").toLowerCase();
}, dU = us.data = {}, hU = us.NATIVE = "N", cU = us.POLYFILL = "P", uU = us, wy = yf, fU = Hn, vU = is, pU = wy(wy.bind), Hl = function(i, e) {
  return fU(i), e === void 0 ? i : vU ? pU(i, e) : function() {
    return i.apply(e, arguments);
  };
}, $t = {}, gU = Ne, yU = Z, Y0 = gU && yU(function() {
  return Object.defineProperty(function() {
  }, "prototype", {
    value: 42,
    writable: !1
  }).prototype !== 42;
}), mU = Ye, bU = String, $U = TypeError, br = function(i) {
  if (mU(i)) return i;
  throw new $U(bU(i) + " is not an object");
}, wU = Ne, _U = K0, EU = Y0, ta = br, _y = Wl, SU = TypeError, Ah = Object.defineProperty, OU = Object.getOwnPropertyDescriptor, Mh = "enumerable", Dh = "configurable", kh = "writable";
$t.f = wU ? EU ? function(e, t, r) {
  if (ta(e), t = _y(t), ta(r), typeof e == "function" && t === "prototype" && "value" in r && kh in r && !r[kh]) {
    var n = OU(e, t);
    n && n[kh] && (e[t] = r.value, r = {
      configurable: Dh in r ? r[Dh] : n[Dh],
      enumerable: Mh in r ? r[Mh] : n[Mh],
      writable: !1
    });
  }
  return Ah(e, t, r);
} : Ah : function(e, t, r) {
  if (ta(e), t = _y(t), ta(r), _U) try {
    return Ah(e, t, r);
  } catch {
  }
  if ("get" in r || "set" in r) throw new SU("Accessors not supported");
  return "value" in r && (e[t] = r.value), e;
};
var TU = Ne, IU = $t, PU = ss, Un = TU ? function(i, e, t) {
  return IU.f(i, e, PU(1, t));
} : function(i, e, t) {
  return i[e] = t, i;
}, ra = _e, xU = Ll, CU = yf, AU = Ve, MU = ns.f, DU = uU, Hi = ie, kU = Hl, Vi = Un, Ey = Ue, NU = function(i) {
  var e = function(t, r, n) {
    if (this instanceof e) {
      switch (arguments.length) {
        case 0:
          return new i();
        case 1:
          return new i(t);
        case 2:
          return new i(t, r);
      }
      return new i(t, r, n);
    }
    return xU(i, this, arguments);
  };
  return e.prototype = i.prototype, e;
}, H = function(i, e) {
  var t = i.target, r = i.global, n = i.stat, o = i.proto, s = r ? ra : n ? ra[t] : (ra[t] || {}).prototype, a = r ? Hi : Hi[t] || Vi(Hi, t, {})[t], l = a.prototype, d, h, c, u, f, v, y, g, p;
  for (u in e)
    d = DU(r ? u : t + (n ? "." : "#") + u, i.forced), h = !d && s && Ey(s, u), v = a[u], h && (i.dontCallGetSet ? (p = MU(s, u), y = p && p.value) : y = s[u]), f = h && y ? y : e[u], !(h && typeof v == typeof f) && (i.bind && h ? g = kU(f, ra) : i.wrap && h ? g = NU(f) : o && AU(f) ? g = CU(f) : g = f, (i.sham || f && f.sham || v && v.sham) && Vi(g, "sham", !0), Vi(a, u, g), o && (c = t + "Prototype", Ey(Hi, c) || Vi(Hi, c, {}), Vi(Hi[c], u, f), i.real && l && (d || !l[u]) && Vi(l, u, f)));
}, RU = Math.ceil, FU = Math.floor, BU = Math.trunc || function(e) {
  var t = +e;
  return (t > 0 ? FU : RU)(t);
}, LU = BU, Vl = function(i) {
  var e = +i;
  return e !== e || e === 0 ? 0 : LU(e);
}, jU = Vl, zU = Math.max, WU = Math.min, fs = function(i, e) {
  var t = jU(i);
  return t < 0 ? zU(t + e, 0) : WU(t, e);
}, HU = Vl, VU = Math.min, UU = function(i) {
  return i > 0 ? VU(HU(i), 9007199254740991) : 0;
}, GU = UU, Qt = function(i) {
  return GU(i.length);
}, KU = Lt, YU = fs, qU = Qt, Sy = function(i) {
  return function(e, t, r) {
    var n = KU(e), o = qU(n), s = YU(r, o), a;
    if (i && t !== t) {
      for (; o > s; )
        if (a = n[s++], a !== a) return !0;
    } else for (; o > s; s++)
      if ((i || s in n) && n[s] === t) return i || s || 0;
    return !i && -1;
  };
}, $f = {
  // `Array.prototype.includes` method
  // https://tc39.es/ecma262/#sec-array.prototype.includes
  includes: Sy(!0),
  // `Array.prototype.indexOf` method
  // https://tc39.es/ecma262/#sec-array.prototype.indexof
  indexOf: Sy(!1)
}, vs = {}, XU = Q, Nh = Ue, JU = Lt, ZU = $f.indexOf, QU = vs, Oy = XU([].push), q0 = function(i, e) {
  var t = JU(i), r = 0, n = [], o;
  for (o in t) !Nh(QU, o) && Nh(t, o) && Oy(n, o);
  for (; e.length > r; ) Nh(t, o = e[r++]) && (~ZU(n, o) || Oy(n, o));
  return n;
}, wf = [
  "constructor",
  "hasOwnProperty",
  "isPrototypeOf",
  "propertyIsEnumerable",
  "toLocaleString",
  "toString",
  "valueOf"
], e8 = q0, t8 = wf, ps = Object.keys || function(e) {
  return e8(e, t8);
}, gs = {};
gs.f = Object.getOwnPropertySymbols;
var Ty = Ne, r8 = Q, i8 = Bt, n8 = Z, Rh = ps, o8 = gs, s8 = os, a8 = Pt, l8 = jl, Ui = Object.assign, Iy = Object.defineProperty, d8 = r8([].concat), h8 = !Ui || n8(function() {
  if (Ty && Ui({ b: 1 }, Ui(Iy({}, "a", {
    enumerable: !0,
    get: function() {
      Iy(this, "b", {
        value: 3,
        enumerable: !1
      });
    }
  }), { b: 2 })).b !== 1) return !0;
  var i = {}, e = {}, t = Symbol("assign detection"), r = "abcdefghijklmnopqrst";
  return i[t] = 7, r.split("").forEach(function(n) {
    e[n] = n;
  }), Ui({}, i)[t] !== 7 || Rh(Ui({}, e)).join("") !== r;
}) ? function(e, t) {
  for (var r = a8(e), n = arguments.length, o = 1, s = o8.f, a = s8.f; n > o; )
    for (var l = l8(arguments[o++]), d = s ? d8(Rh(l), s(l)) : Rh(l), h = d.length, c = 0, u; h > c; )
      u = d[c++], (!Ty || i8(a, l, u)) && (r[u] = l[u]);
  return r;
} : Ui, c8 = H, Py = h8;
c8({ target: "Object", stat: !0, forced: Object.assign !== Py }, {
  assign: Py
});
var u8 = ie, f8 = u8.Object.assign, v8 = f8, p8 = v8, g8 = p8, Ce = /* @__PURE__ */ U(g8), y8 = Q, Ul = y8([].slice), X0 = Q, m8 = Hn, b8 = Ye, $8 = Ue, xy = Ul, w8 = is, J0 = Function, _8 = X0([].concat), E8 = X0([].join), Fh = {}, S8 = function(i, e, t) {
  if (!$8(Fh, e)) {
    for (var r = [], n = 0; n < e; n++) r[n] = "a[" + n + "]";
    Fh[e] = J0("C,a", "return new C(" + E8(r, ",") + ")");
  }
  return Fh[e](i, t);
}, O8 = w8 ? J0.bind : function(e) {
  var t = m8(this), r = t.prototype, n = xy(arguments, 1), o = function() {
    var a = _8(n, xy(arguments));
    return this instanceof o ? S8(t, a.length, a) : t.apply(e, a);
  };
  return b8(r) && (o.prototype = r), o;
}, T8 = H, Cy = O8;
T8({ target: "Function", proto: !0, forced: Function.bind !== Cy }, {
  bind: Cy
});
var I8 = ie, Ge = function(i) {
  return I8[i + "Prototype"];
}, P8 = Ge, x8 = P8("Function").bind, C8 = ke, A8 = x8, Bh = Function.prototype, M8 = function(i) {
  var e = i.bind;
  return i === Bh || C8(Bh, i) && e === Bh.bind ? A8 : e;
}, D8 = M8, k8 = D8, N8 = k8, S = /* @__PURE__ */ U(N8);
function _f(i, e, t, r) {
  i.beginPath(), i.arc(e, t, r, 0, 2 * Math.PI, !1), i.closePath();
}
function R8(i, e, t, r) {
  i.beginPath(), i.rect(e - r, t - r, r * 2, r * 2), i.closePath();
}
function F8(i, e, t, r) {
  i.beginPath(), r *= 1.15, t += 0.275 * r;
  const n = r * 2, o = n / 2, s = Math.sqrt(3) / 6 * n, a = Math.sqrt(n * n - o * o);
  i.moveTo(e, t - (a - s)), i.lineTo(e + o, t + s), i.lineTo(e - o, t + s), i.lineTo(e, t - (a - s)), i.closePath();
}
function B8(i, e, t, r) {
  i.beginPath(), r *= 1.15, t -= 0.275 * r;
  const n = r * 2, o = n / 2, s = Math.sqrt(3) / 6 * n, a = Math.sqrt(n * n - o * o);
  i.moveTo(e, t + (a - s)), i.lineTo(e + o, t - s), i.lineTo(e - o, t - s), i.lineTo(e, t + (a - s)), i.closePath();
}
function L8(i, e, t, r) {
  i.beginPath(), r *= 0.82, t += 0.1 * r;
  for (let n = 0; n < 10; n++) {
    const o = n % 2 === 0 ? r * 1.3 : r * 0.5;
    i.lineTo(e + o * Math.sin(n * 2 * Math.PI / 10), t - o * Math.cos(n * 2 * Math.PI / 10));
  }
  i.closePath();
}
function j8(i, e, t, r) {
  i.beginPath(), i.lineTo(e, t + r), i.lineTo(e + r, t), i.lineTo(e, t - r), i.lineTo(e - r, t), i.closePath();
}
function Z0(i, e, t, r, n, o) {
  const s = Math.PI / 180;
  r - 2 * o < 0 && (o = r / 2), n - 2 * o < 0 && (o = n / 2), i.beginPath(), i.moveTo(e + o, t), i.lineTo(e + r - o, t), i.arc(e + r - o, t + o, o, s * 270, s * 360, !1), i.lineTo(e + r, t + n - o), i.arc(e + r - o, t + n - o, o, 0, s * 90, !1), i.lineTo(e + o, t + n), i.arc(e + o, t + n - o, o, s * 90, s * 180, !1), i.lineTo(e, t + o), i.arc(e + o, t + o, o, s * 180, s * 270, !1), i.closePath();
}
function iu(i, e, t, r, n) {
  const o = 0.5522848, s = r / 2 * o, a = n / 2 * o, l = e + r, d = t + n, h = e + r / 2, c = t + n / 2;
  i.beginPath(), i.moveTo(e, c), i.bezierCurveTo(e, c - a, h - s, t, h, t), i.bezierCurveTo(h + s, t, l, c - a, l, c), i.bezierCurveTo(l, c + a, h + s, d, h, d), i.bezierCurveTo(h - s, d, e, c + a, e, c), i.closePath();
}
function Q0(i, e, t, r, n) {
  const o = 0.3333333333333333, s = r, a = n * o, l = 0.5522848, d = s / 2 * l, h = a / 2 * l, c = e + s, u = t + a, f = e + s / 2, v = t + a / 2, y = t + (n - a / 2), g = t + n;
  i.beginPath(), i.moveTo(c, v), i.bezierCurveTo(c, v + h, f + d, u, f, u), i.bezierCurveTo(f - d, u, e, v + h, e, v), i.bezierCurveTo(e, v - h, f - d, t, f, t), i.bezierCurveTo(f + d, t, c, v - h, c, v), i.lineTo(c, y), i.bezierCurveTo(c, y + h, f + d, g, f, g), i.bezierCurveTo(f - d, g, e, y + h, e, y), i.lineTo(e, v);
}
function e_(i, e, t, r, n, o) {
  i.beginPath(), i.moveTo(e, t);
  const s = o.length, a = r - e, l = n - t, d = l / a;
  let h = Math.sqrt(a * a + l * l), c = 0, u = !0, f = 0, v = +o[0];
  for (; h >= 0.1; )
    v = +o[c++ % s], v > h && (v = h), f = Math.sqrt(v * v / (1 + d * d)), f = a < 0 ? -f : f, e += f, t += d * f, u === !0 ? i.lineTo(e, t) : i.moveTo(e, t), h -= v, u = !u;
}
function z8(i, e, t, r) {
  i.beginPath();
  const n = 6, o = Math.PI * 2 / n;
  i.moveTo(e + r, t);
  for (let s = 1; s < n; s++)
    i.lineTo(e + r * Math.cos(o * s), t + r * Math.sin(o * s));
  i.closePath();
}
const Ay = {
  circle: _f,
  dashedLine: e_,
  database: Q0,
  diamond: j8,
  ellipse: iu,
  ellipse_vis: iu,
  hexagon: z8,
  roundRect: Z0,
  square: R8,
  star: L8,
  triangle: F8,
  triangleDown: B8
};
function W8(i) {
  return Object.prototype.hasOwnProperty.call(Ay, i) ? Ay[i] : function(e) {
    for (var t = arguments.length, r = new Array(t > 1 ? t - 1 : 0), n = 1; n < t; n++)
      r[n - 1] = arguments[n];
    CanvasRenderingContext2D.prototype[i].call(e, r);
  };
}
var t_ = { exports: {} };
(function(i) {
  i.exports = e;
  function e(r) {
    if (r) return t(r);
  }
  function t(r) {
    for (var n in e.prototype)
      r[n] = e.prototype[n];
    return r;
  }
  e.prototype.on = e.prototype.addEventListener = function(r, n) {
    return this._callbacks = this._callbacks || {}, (this._callbacks["$" + r] = this._callbacks["$" + r] || []).push(n), this;
  }, e.prototype.once = function(r, n) {
    function o() {
      this.off(r, o), n.apply(this, arguments);
    }
    return o.fn = n, this.on(r, o), this;
  }, e.prototype.off = e.prototype.removeListener = e.prototype.removeAllListeners = e.prototype.removeEventListener = function(r, n) {
    if (this._callbacks = this._callbacks || {}, arguments.length == 0)
      return this._callbacks = {}, this;
    var o = this._callbacks["$" + r];
    if (!o) return this;
    if (arguments.length == 1)
      return delete this._callbacks["$" + r], this;
    for (var s, a = 0; a < o.length; a++)
      if (s = o[a], s === n || s.fn === n) {
        o.splice(a, 1);
        break;
      }
    return o.length === 0 && delete this._callbacks["$" + r], this;
  }, e.prototype.emit = function(r) {
    this._callbacks = this._callbacks || {};
    for (var n = new Array(arguments.length - 1), o = this._callbacks["$" + r], s = 1; s < arguments.length; s++)
      n[s - 1] = arguments[s];
    if (o) {
      o = o.slice(0);
      for (var s = 0, a = o.length; s < a; ++s)
        o[s].apply(this, n);
    }
    return this;
  }, e.prototype.listeners = function(r) {
    return this._callbacks = this._callbacks || {}, this._callbacks["$" + r] || [];
  }, e.prototype.hasListeners = function(r) {
    return !!this.listeners(r).length;
  };
})(t_);
var H8 = t_.exports, r_ = /* @__PURE__ */ U(H8), V8 = mr, Ai = Array.isArray || function(e) {
  return V8(e) === "Array";
}, U8 = TypeError, G8 = 9007199254740991, i_ = function(i) {
  if (i > G8) throw U8("Maximum allowed index exceeded");
  return i;
}, K8 = Wl, Y8 = $t, q8 = ss, ys = function(i, e, t) {
  var r = K8(e);
  r in i ? Y8.f(i, r, q8(0, t)) : i[r] = t;
}, X8 = Ie, J8 = X8("toStringTag"), n_ = {};
n_[J8] = "z";
var Ef = String(n_) === "[object z]", Z8 = Ef, Q8 = Ve, Pa = mr, e9 = Ie, t9 = e9("toStringTag"), r9 = Object, i9 = Pa(/* @__PURE__ */ function() {
  return arguments;
}()) === "Arguments", n9 = function(i, e) {
  try {
    return i[e];
  } catch {
  }
}, Mi = Z8 ? Pa : function(i) {
  var e, t, r;
  return i === void 0 ? "Undefined" : i === null ? "Null" : typeof (t = n9(e = r9(i), t9)) == "string" ? t : i9 ? Pa(e) : (r = Pa(e)) === "Object" && Q8(e.callee) ? "Arguments" : r;
}, o9 = Q, s9 = Ve, nu = bf, a9 = o9(Function.toString);
s9(nu.inspectSource) || (nu.inspectSource = function(i) {
  return a9(i);
});
var l9 = nu.inspectSource, d9 = Q, h9 = Z, o_ = Ve, c9 = Mi, u9 = jt, f9 = l9, s_ = function() {
}, v9 = [], a_ = u9("Reflect", "construct"), Sf = /^\s*(?:class|function)\b/, p9 = d9(Sf.exec), g9 = !Sf.test(s_), Qn = function(e) {
  if (!o_(e)) return !1;
  try {
    return a_(s_, v9, e), !0;
  } catch {
    return !1;
  }
}, l_ = function(e) {
  if (!o_(e)) return !1;
  switch (c9(e)) {
    case "AsyncFunction":
    case "GeneratorFunction":
    case "AsyncGeneratorFunction":
      return !1;
  }
  try {
    return g9 || !!p9(Sf, f9(e));
  } catch {
    return !0;
  }
};
l_.sham = !0;
var d_ = !a_ || h9(function() {
  var i;
  return Qn(Qn.call) || !Qn(Object) || !Qn(function() {
    i = !0;
  }) || i;
}) ? l_ : Qn, My = Ai, y9 = d_, m9 = Ye, b9 = Ie, $9 = b9("species"), Dy = Array, w9 = function(i) {
  var e;
  return My(i) && (e = i.constructor, y9(e) && (e === Dy || My(e.prototype)) ? e = void 0 : m9(e) && (e = e[$9], e === null && (e = void 0))), e === void 0 ? Dy : e;
}, _9 = w9, Of = function(i, e) {
  return new (_9(i))(e === 0 ? 0 : e);
}, E9 = Z, S9 = Ie, O9 = ds, T9 = S9("species"), ms = function(i) {
  return O9 >= 51 || !E9(function() {
    var e = [], t = e.constructor = {};
    return t[T9] = function() {
      return { foo: 1 };
    }, e[i](Boolean).foo !== 1;
  });
}, I9 = H, P9 = Z, x9 = Ai, C9 = Ye, A9 = Pt, M9 = Qt, ky = i_, Ny = ys, D9 = Of, k9 = ms, N9 = Ie, R9 = ds, h_ = N9("isConcatSpreadable"), F9 = R9 >= 51 || !P9(function() {
  var i = [];
  return i[h_] = !1, i.concat()[0] !== i;
}), B9 = function(i) {
  if (!C9(i)) return !1;
  var e = i[h_];
  return e !== void 0 ? !!e : x9(i);
}, L9 = !F9 || !k9("concat");
I9({ target: "Array", proto: !0, forced: L9 }, {
  // eslint-disable-next-line no-unused-vars -- required for `.length`
  concat: function(e) {
    var t = A9(this), r = D9(t, 0), n = 0, o, s, a, l, d;
    for (o = -1, a = arguments.length; o < a; o++)
      if (d = o === -1 ? t : arguments[o], B9(d))
        for (l = M9(d), ky(n + l), s = 0; s < l; s++, n++) s in d && Ny(r, n, d[s]);
      else
        ky(n + 1), Ny(r, n++, d);
    return r.length = n, r;
  }
});
var j9 = Mi, z9 = String, er = function(i) {
  if (j9(i) === "Symbol") throw new TypeError("Cannot convert a Symbol value to a string");
  return z9(i);
}, Gl = {}, W9 = Ne, H9 = Y0, V9 = $t, U9 = br, G9 = Lt, K9 = ps;
Gl.f = W9 && !H9 ? Object.defineProperties : function(e, t) {
  U9(e);
  for (var r = G9(t), n = K9(t), o = n.length, s = 0, a; o > s; ) V9.f(e, a = n[s++], r[a]);
  return e;
};
var Y9 = jt, q9 = Y9("document", "documentElement"), X9 = Vn, J9 = zl, Ry = X9("keys"), Kl = function(i) {
  return Ry[i] || (Ry[i] = J9(i));
}, Z9 = br, Q9 = Gl, Fy = wf, eG = vs, tG = q9, rG = G0, iG = Kl, By = ">", Ly = "<", ou = "prototype", su = "script", c_ = iG("IE_PROTO"), Lh = function() {
}, u_ = function(i) {
  return Ly + su + By + i + Ly + "/" + su + By;
}, jy = function(i) {
  i.write(u_("")), i.close();
  var e = i.parentWindow.Object;
  return i = null, e;
}, nG = function() {
  var i = rG("iframe"), e = "java" + su + ":", t;
  return i.style.display = "none", tG.appendChild(i), i.src = String(e), t = i.contentWindow.document, t.open(), t.write(u_("document.F=Object")), t.close(), t.F;
}, ia, xa = function() {
  try {
    ia = new ActiveXObject("htmlfile");
  } catch {
  }
  xa = typeof document < "u" ? document.domain && ia ? jy(ia) : nG() : jy(ia);
  for (var i = Fy.length; i--; ) delete xa[ou][Fy[i]];
  return xa();
};
eG[c_] = !0;
var bs = Object.create || function(e, t) {
  var r;
  return e !== null ? (Lh[ou] = Z9(e), r = new Lh(), Lh[ou] = null, r[c_] = e) : r = xa(), t === void 0 ? r : Q9.f(r, t);
}, $s = {}, oG = q0, sG = wf, aG = sG.concat("length", "prototype");
$s.f = Object.getOwnPropertyNames || function(e) {
  return oG(e, aG);
};
var Yl = {}, zy = fs, lG = Qt, dG = ys, hG = Array, cG = Math.max, f_ = function(i, e, t) {
  for (var r = lG(i), n = zy(e, r), o = zy(t === void 0 ? r : t, r), s = hG(cG(o - n, 0)), a = 0; n < o; n++, a++) dG(s, a, i[n]);
  return s.length = a, s;
}, uG = mr, fG = Lt, v_ = $s.f, vG = f_, p_ = typeof window == "object" && window && Object.getOwnPropertyNames ? Object.getOwnPropertyNames(window) : [], pG = function(i) {
  try {
    return v_(i);
  } catch {
    return vG(p_);
  }
};
Yl.f = function(e) {
  return p_ && uG(e) === "Window" ? pG(e) : v_(fG(e));
};
var gG = Un, ws = function(i, e, t, r) {
  return r && r.enumerable ? i[e] = t : gG(i, e, t), i;
}, yG = $t, Tf = function(i, e, t) {
  return yG.f(i, e, t);
}, _s = {}, mG = Ie;
_s.f = mG;
var Wy = ie, bG = Ue, $G = _s, wG = $t.f, Ee = function(i) {
  var e = Wy.Symbol || (Wy.Symbol = {});
  bG(e, i) || wG(e, i, {
    value: $G.f(i)
  });
}, _G = Bt, EG = jt, SG = Ie, OG = ws, g_ = function() {
  var i = EG("Symbol"), e = i && i.prototype, t = e && e.valueOf, r = SG("toPrimitive");
  e && !e[r] && OG(e, r, function(n) {
    return _G(t, this);
  }, {});
}, TG = Ef, IG = Mi, PG = TG ? {}.toString : function() {
  return "[object " + IG(this) + "]";
}, xG = Ef, CG = $t.f, AG = Un, MG = Ue, DG = PG, kG = Ie, Hy = kG("toStringTag"), Gn = function(i, e, t, r) {
  if (i) {
    var n = t ? i : i.prototype;
    MG(n, Hy) || CG(n, Hy, { configurable: !0, value: e }), r && !xG && AG(n, "toString", DG);
  }
}, NG = _e, RG = Ve, Vy = NG.WeakMap, y_ = RG(Vy) && /native code/.test(String(Vy)), FG = y_, m_ = _e, BG = Ye, LG = Un, jh = Ue, zh = bf, jG = Kl, zG = vs, Uy = "Object already initialized", au = m_.TypeError, WG = m_.WeakMap, Ja, Po, Za, HG = function(i) {
  return Za(i) ? Po(i) : Ja(i, {});
}, VG = function(i) {
  return function(e) {
    var t;
    if (!BG(e) || (t = Po(e)).type !== i)
      throw new au("Incompatible receiver, " + i + " required");
    return t;
  };
};
if (FG || zh.state) {
  var Vt = zh.state || (zh.state = new WG());
  Vt.get = Vt.get, Vt.has = Vt.has, Vt.set = Vt.set, Ja = function(i, e) {
    if (Vt.has(i)) throw new au(Uy);
    return e.facade = i, Vt.set(i, e), e;
  }, Po = function(i) {
    return Vt.get(i) || {};
  }, Za = function(i) {
    return Vt.has(i);
  };
} else {
  var Gi = jG("state");
  zG[Gi] = !0, Ja = function(i, e) {
    if (jh(i, Gi)) throw new au(Uy);
    return e.facade = i, LG(i, Gi, e), e;
  }, Po = function(i) {
    return jh(i, Gi) ? i[Gi] : {};
  }, Za = function(i) {
    return jh(i, Gi);
  };
}
var Di = {
  set: Ja,
  get: Po,
  has: Za,
  enforce: HG,
  getterFor: VG
}, UG = Hl, GG = Q, KG = jl, YG = Pt, qG = Qt, XG = Of, Gy = GG([].push), Qr = function(i) {
  var e = i === 1, t = i === 2, r = i === 3, n = i === 4, o = i === 6, s = i === 7, a = i === 5 || o;
  return function(l, d, h, c) {
    for (var u = YG(l), f = KG(u), v = UG(d, h), y = qG(f), g = 0, p = c || XG, m = e ? p(l, y) : t || s ? p(l, 0) : void 0, $, w; y > g; g++) if ((a || g in f) && ($ = f[g], w = v($, g, u), i))
      if (e) m[g] = w;
      else if (w) switch (i) {
        case 3:
          return !0;
        case 5:
          return $;
        case 6:
          return g;
        case 2:
          Gy(m, $);
      }
      else switch (i) {
        case 4:
          return !1;
        case 7:
          Gy(m, $);
      }
    return o ? -1 : r || n ? n : m;
  };
}, Kr = {
  // `Array.prototype.forEach` method
  // https://tc39.es/ecma262/#sec-array.prototype.foreach
  forEach: Qr(0),
  // `Array.prototype.map` method
  // https://tc39.es/ecma262/#sec-array.prototype.map
  map: Qr(1),
  // `Array.prototype.filter` method
  // https://tc39.es/ecma262/#sec-array.prototype.filter
  filter: Qr(2),
  // `Array.prototype.some` method
  // https://tc39.es/ecma262/#sec-array.prototype.some
  some: Qr(3),
  // `Array.prototype.every` method
  // https://tc39.es/ecma262/#sec-array.prototype.every
  every: Qr(4),
  // `Array.prototype.find` method
  // https://tc39.es/ecma262/#sec-array.prototype.find
  find: Qr(5),
  // `Array.prototype.findIndex` method
  // https://tc39.es/ecma262/#sec-array.prototype.findIndex
  findIndex: Qr(6)
}, ql = H, Xl = _e, If = Bt, JG = Q, $n = Ne, wn = Wn, ZG = Z, Be = Ue, QG = ke, lu = br, Jl = Lt, Pf = Wl, eK = er, du = ss, xo = bs, b_ = ps, tK = $s, $_ = Yl, rK = gs, w_ = ns, __ = $t, iK = Gl, E_ = os, Ky = ws, nK = Tf, xf = Vn, oK = Kl, S_ = vs, Yy = zl, sK = Ie, aK = _s, lK = Ee, dK = g_, hK = Gn, O_ = Di, Zl = Kr.forEach, dt = oK("hidden"), Ql = "Symbol", Co = "prototype", cK = O_.set, qy = O_.getterFor(Ql), Nt = Object[Co], di = Xl.Symbol, oo = di && di[Co], uK = Xl.RangeError, fK = Xl.TypeError, Wh = Xl.QObject, T_ = w_.f, hi = __.f, I_ = $_.f, vK = E_.f, P_ = JG([].push), vr = xf("symbols"), Es = xf("op-symbols"), pK = xf("wks"), hu = !Wh || !Wh[Co] || !Wh[Co].findChild, x_ = function(i, e, t) {
  var r = T_(Nt, e);
  r && delete Nt[e], hi(i, e, t), r && i !== Nt && hi(Nt, e, r);
}, cu = $n && ZG(function() {
  return xo(hi({}, "a", {
    get: function() {
      return hi(this, "a", { value: 7 }).a;
    }
  })).a !== 7;
}) ? x_ : hi, Hh = function(i, e) {
  var t = vr[i] = xo(oo);
  return cK(t, {
    type: Ql,
    tag: i,
    description: e
  }), $n || (t.description = e), t;
}, ed = function(e, t, r) {
  e === Nt && ed(Es, t, r), lu(e);
  var n = Pf(t);
  return lu(r), Be(vr, n) ? (r.enumerable ? (Be(e, dt) && e[dt][n] && (e[dt][n] = !1), r = xo(r, { enumerable: du(0, !1) })) : (Be(e, dt) || hi(e, dt, du(1, {})), e[dt][n] = !0), cu(e, n, r)) : hi(e, n, r);
}, Cf = function(e, t) {
  lu(e);
  var r = Jl(t), n = b_(r).concat(D_(r));
  return Zl(n, function(o) {
    (!$n || If(C_, r, o)) && ed(e, o, r[o]);
  }), e;
}, gK = function(e, t) {
  return t === void 0 ? xo(e) : Cf(xo(e), t);
}, C_ = function(e) {
  var t = Pf(e), r = If(vK, this, t);
  return this === Nt && Be(vr, t) && !Be(Es, t) ? !1 : r || !Be(this, t) || !Be(vr, t) || Be(this, dt) && this[dt][t] ? r : !0;
}, A_ = function(e, t) {
  var r = Jl(e), n = Pf(t);
  if (!(r === Nt && Be(vr, n) && !Be(Es, n))) {
    var o = T_(r, n);
    return o && Be(vr, n) && !(Be(r, dt) && r[dt][n]) && (o.enumerable = !0), o;
  }
}, M_ = function(e) {
  var t = I_(Jl(e)), r = [];
  return Zl(t, function(n) {
    !Be(vr, n) && !Be(S_, n) && P_(r, n);
  }), r;
}, D_ = function(i) {
  var e = i === Nt, t = I_(e ? Es : Jl(i)), r = [];
  return Zl(t, function(n) {
    Be(vr, n) && (!e || Be(Nt, n)) && P_(r, vr[n]);
  }), r;
};
wn || (di = function() {
  if (QG(oo, this)) throw new fK("Symbol is not a constructor");
  var e = !arguments.length || arguments[0] === void 0 ? void 0 : eK(arguments[0]), t = Yy(e), r = function(n) {
    this === Nt && If(r, Es, n), Be(this, dt) && Be(this[dt], t) && (this[dt][t] = !1);
    var o = du(1, n);
    try {
      cu(this, t, o);
    } catch (s) {
      if (!(s instanceof uK)) throw s;
      x_(this, t, o);
    }
  };
  return $n && hu && cu(Nt, t, { configurable: !0, set: r }), Hh(t, e);
}, oo = di[Co], Ky(oo, "toString", function() {
  return qy(this).tag;
}), Ky(di, "withoutSetter", function(i) {
  return Hh(Yy(i), i);
}), E_.f = C_, __.f = ed, iK.f = Cf, w_.f = A_, tK.f = $_.f = M_, rK.f = D_, aK.f = function(i) {
  return Hh(sK(i), i);
}, $n && nK(oo, "description", {
  configurable: !0,
  get: function() {
    return qy(this).description;
  }
}));
ql({ global: !0, wrap: !0, forced: !wn, sham: !wn }, {
  Symbol: di
});
Zl(b_(pK), function(i) {
  lK(i);
});
ql({ target: Ql, stat: !0, forced: !wn }, {
  useSetter: function() {
    hu = !0;
  },
  useSimple: function() {
    hu = !1;
  }
});
ql({ target: "Object", stat: !0, forced: !wn, sham: !$n }, {
  // `Object.create` method
  // https://tc39.es/ecma262/#sec-object.create
  create: gK,
  // `Object.defineProperty` method
  // https://tc39.es/ecma262/#sec-object.defineproperty
  defineProperty: ed,
  // `Object.defineProperties` method
  // https://tc39.es/ecma262/#sec-object.defineproperties
  defineProperties: Cf,
  // `Object.getOwnPropertyDescriptor` method
  // https://tc39.es/ecma262/#sec-object.getownpropertydescriptors
  getOwnPropertyDescriptor: A_
});
ql({ target: "Object", stat: !0, forced: !wn }, {
  // `Object.getOwnPropertyNames` method
  // https://tc39.es/ecma262/#sec-object.getownpropertynames
  getOwnPropertyNames: M_
});
dK();
hK(di, Ql);
S_[dt] = !0;
var yK = Wn, k_ = yK && !!Symbol.for && !!Symbol.keyFor, mK = H, bK = jt, $K = Ue, wK = er, N_ = Vn, _K = k_, Vh = N_("string-to-symbol-registry"), EK = N_("symbol-to-string-registry");
mK({ target: "Symbol", stat: !0, forced: !_K }, {
  for: function(i) {
    var e = wK(i);
    if ($K(Vh, e)) return Vh[e];
    var t = bK("Symbol")(e);
    return Vh[e] = t, EK[t] = e, t;
  }
});
var SK = H, OK = Ue, TK = hs, IK = cs, PK = Vn, xK = k_, Xy = PK("symbol-to-string-registry");
SK({ target: "Symbol", stat: !0, forced: !xK }, {
  keyFor: function(e) {
    if (!TK(e)) throw new TypeError(IK(e) + " is not a symbol");
    if (OK(Xy, e)) return Xy[e];
  }
});
var CK = Q, Jy = Ai, AK = Ve, Zy = mr, MK = er, Qy = CK([].push), DK = function(i) {
  if (AK(i)) return i;
  if (Jy(i)) {
    for (var e = i.length, t = [], r = 0; r < e; r++) {
      var n = i[r];
      typeof n == "string" ? Qy(t, n) : (typeof n == "number" || Zy(n) === "Number" || Zy(n) === "String") && Qy(t, MK(n));
    }
    var o = t.length, s = !0;
    return function(a, l) {
      if (s)
        return s = !1, l;
      if (Jy(this)) return l;
      for (var d = 0; d < o; d++) if (t[d] === a) return l;
    };
  }
}, kK = H, R_ = jt, F_ = Ll, NK = Bt, Ss = Q, B_ = Z, em = Ve, tm = hs, L_ = Ul, RK = DK, FK = Wn, BK = String, Dr = R_("JSON", "stringify"), na = Ss(/./.exec), rm = Ss("".charAt), LK = Ss("".charCodeAt), jK = Ss("".replace), zK = Ss(1 .toString), WK = /[\uD800-\uDFFF]/g, im = /^[\uD800-\uDBFF]$/, nm = /^[\uDC00-\uDFFF]$/, om = !FK || B_(function() {
  var i = R_("Symbol")("stringify detection");
  return Dr([i]) !== "[null]" || Dr({ a: i }) !== "{}" || Dr(Object(i)) !== "{}";
}), sm = B_(function() {
  return Dr("\uDF06\uD834") !== '"\\udf06\\ud834"' || Dr("\uDEAD") !== '"\\udead"';
}), HK = function(i, e) {
  var t = L_(arguments), r = RK(e);
  if (!(!em(r) && (i === void 0 || tm(i))))
    return t[1] = function(n, o) {
      if (em(r) && (o = NK(r, this, BK(n), o)), !tm(o)) return o;
    }, F_(Dr, null, t);
}, VK = function(i, e, t) {
  var r = rm(t, e - 1), n = rm(t, e + 1);
  return na(im, i) && !na(nm, n) || na(nm, i) && !na(im, r) ? "\\u" + zK(LK(i, 0), 16) : i;
};
Dr && kK({ target: "JSON", stat: !0, forced: om || sm }, {
  // eslint-disable-next-line no-unused-vars -- required for `.length`
  stringify: function(e, t, r) {
    var n = L_(arguments), o = F_(om ? HK : Dr, null, n);
    return sm && typeof o == "string" ? jK(o, WK, VK) : o;
  }
});
var UK = H, GK = Wn, KK = Z, j_ = gs, YK = Pt, qK = !GK || KK(function() {
  j_.f(1);
});
UK({ target: "Object", stat: !0, forced: qK }, {
  getOwnPropertySymbols: function(e) {
    var t = j_.f;
    return t ? t(YK(e)) : [];
  }
});
var XK = Ee;
XK("asyncIterator");
var JK = Ee;
JK("hasInstance");
var ZK = Ee;
ZK("isConcatSpreadable");
var QK = Ee;
QK("iterator");
var e7 = Ee;
e7("match");
var t7 = Ee;
t7("matchAll");
var r7 = Ee;
r7("replace");
var i7 = Ee;
i7("search");
var n7 = Ee;
n7("species");
var o7 = Ee;
o7("split");
var s7 = Ee, a7 = g_;
s7("toPrimitive");
a7();
var l7 = jt, d7 = Ee, h7 = Gn;
d7("toStringTag");
h7(l7("Symbol"), "Symbol");
var c7 = Ee;
c7("unscopables");
var u7 = _e, f7 = Gn;
f7(u7.JSON, "JSON", !0);
var v7 = ie, p7 = v7.Symbol, Kn = {}, uu = Ne, g7 = Ue, z_ = Function.prototype, y7 = uu && Object.getOwnPropertyDescriptor, W_ = g7(z_, "name"), m7 = W_ && (function() {
}).name === "something";
W_ && (!uu || uu && y7(z_, "name").configurable);
var b7 = {
  PROPER: m7
}, $7 = Z, H_ = !$7(function() {
  function i() {
  }
  return i.prototype.constructor = null, Object.getPrototypeOf(new i()) !== i.prototype;
}), w7 = Ue, _7 = Ve, E7 = Pt, S7 = Kl, O7 = H_, am = S7("IE_PROTO"), fu = Object, T7 = fu.prototype, td = O7 ? fu.getPrototypeOf : function(i) {
  var e = E7(i);
  if (w7(e, am)) return e[am];
  var t = e.constructor;
  return _7(t) && e instanceof t ? t.prototype : e instanceof fu ? T7 : null;
}, I7 = Z, P7 = Ve, x7 = Ye, C7 = bs, lm = td, A7 = ws, M7 = Ie, vu = M7("iterator"), V_ = !1, sr, Uh, Gh;
[].keys && (Gh = [].keys(), "next" in Gh ? (Uh = lm(lm(Gh)), Uh !== Object.prototype && (sr = Uh)) : V_ = !0);
var D7 = !x7(sr) || I7(function() {
  var i = {};
  return sr[vu].call(i) !== i;
});
D7 ? sr = {} : sr = C7(sr);
P7(sr[vu]) || A7(sr, vu, function() {
  return this;
});
var U_ = {
  IteratorPrototype: sr,
  BUGGY_SAFARI_ITERATORS: V_
}, k7 = U_.IteratorPrototype, N7 = bs, R7 = ss, F7 = Gn, B7 = Kn, L7 = function() {
  return this;
}, j7 = function(i, e, t, r) {
  var n = e + " Iterator";
  return i.prototype = N7(k7, { next: R7(+!r, t) }), F7(i, n, !1, !0), B7[n] = L7, i;
}, z7 = H, W7 = Bt, H7 = b7, V7 = j7, U7 = td, G7 = Gn, dm = ws, K7 = Ie, hm = Kn, Y7 = U_, q7 = H7.PROPER, oa = Y7.BUGGY_SAFARI_ITERATORS, Kh = K7("iterator"), cm = "keys", sa = "values", um = "entries", X7 = function() {
  return this;
}, Af = function(i, e, t, r, n, o, s) {
  V7(t, e, r);
  var a = function(p) {
    if (p === n && u) return u;
    if (!oa && p && p in h) return h[p];
    switch (p) {
      case cm:
        return function() {
          return new t(this, p);
        };
      case sa:
        return function() {
          return new t(this, p);
        };
      case um:
        return function() {
          return new t(this, p);
        };
    }
    return function() {
      return new t(this);
    };
  }, l = e + " Iterator", d = !1, h = i.prototype, c = h[Kh] || h["@@iterator"] || n && h[n], u = !oa && c || a(n), f = e === "Array" && h.entries || c, v, y, g;
  if (f && (v = U7(f.call(new i())), v !== Object.prototype && v.next && (G7(v, l, !0, !0), hm[l] = X7)), q7 && n === sa && c && c.name !== sa && (d = !0, u = function() {
    return W7(c, this);
  }), n)
    if (y = {
      values: a(sa),
      keys: o ? u : a(cm),
      entries: a(um)
    }, s) for (g in y)
      (oa || d || !(g in h)) && dm(h, g, y[g]);
    else z7({ target: e, proto: !0, forced: oa || d }, y);
  return s && h[Kh] !== u && dm(h, Kh, u, {}), hm[e] = u, y;
}, Mf = function(i, e) {
  return { value: i, done: e };
}, J7 = Lt, fm = Kn, G_ = Di;
$t.f;
var Z7 = Af, aa = Mf, K_ = "Array Iterator", Q7 = G_.set, eY = G_.getterFor(K_);
Z7(Array, "Array", function(i, e) {
  Q7(this, {
    type: K_,
    target: J7(i),
    // target
    index: 0,
    // next index
    kind: e
    // kind
  });
}, function() {
  var i = eY(this), e = i.target, t = i.kind, r = i.index++;
  if (!e || r >= e.length)
    return i.target = void 0, aa(void 0, !0);
  switch (t) {
    case "keys":
      return aa(r, !1);
    case "values":
      return aa(e[r], !1);
  }
  return aa([r, e[r]], !1);
}, "values");
fm.Arguments = fm.Array;
var tY = {
  CSSRuleList: 0,
  CSSStyleDeclaration: 0,
  CSSValueList: 0,
  ClientRectList: 0,
  DOMRectList: 0,
  DOMStringList: 0,
  DOMTokenList: 1,
  DataTransferItemList: 0,
  FileList: 0,
  HTMLAllCollection: 0,
  HTMLCollection: 0,
  HTMLFormElement: 0,
  HTMLSelectElement: 0,
  MediaList: 0,
  MimeTypeArray: 0,
  NamedNodeMap: 0,
  NodeList: 1,
  PaintRequestList: 0,
  Plugin: 0,
  PluginArray: 0,
  SVGLengthList: 0,
  SVGNumberList: 0,
  SVGPathSegList: 0,
  SVGPointList: 0,
  SVGStringList: 0,
  SVGTransformList: 0,
  SourceBufferList: 0,
  StyleSheetList: 0,
  TextTrackCueList: 0,
  TextTrackList: 0,
  TouchList: 0
}, rY = tY, iY = _e, nY = Mi, oY = Un, vm = Kn, sY = Ie, pm = sY("toStringTag");
for (var Yh in rY) {
  var gm = iY[Yh], qh = gm && gm.prototype;
  qh && nY(qh) !== pm && oY(qh, pm, Yh), vm[Yh] = vm.Array;
}
var aY = p7, Y_ = aY, lY = Y_, dY = /* @__PURE__ */ U(lY), hY = H, ym = Ai, cY = d_, uY = Ye, mm = fs, fY = Qt, vY = Lt, pY = ys, gY = Ie, yY = ms, mY = Ul, bY = yY("slice"), $Y = gY("species"), Xh = Array, wY = Math.max;
hY({ target: "Array", proto: !0, forced: !bY }, {
  slice: function(e, t) {
    var r = vY(this), n = fY(r), o = mm(e, n), s = mm(t === void 0 ? n : t, n), a, l, d;
    if (ym(r) && (a = r.constructor, cY(a) && (a === Xh || ym(a.prototype)) ? a = void 0 : uY(a) && (a = a[$Y], a === null && (a = void 0)), a === Xh || a === void 0))
      return mY(r, o, s);
    for (l = new (a === void 0 ? Xh : a)(wY(s - o, 0)), d = 0; o < s; o++, d++) o in r && pY(l, d, r[o]);
    return l.length = d, l;
  }
});
var _Y = Ge, EY = _Y("Array").slice, SY = ke, OY = EY, Jh = Array.prototype, TY = function(i) {
  var e = i.slice;
  return i === Jh || SY(Jh, i) && e === Jh.slice ? OY : e;
}, IY = TY, PY = IY, xY = PY, Ut = /* @__PURE__ */ U(xY), CY = jt, AY = Q, MY = $s, DY = gs, kY = br, NY = AY([].concat), RY = CY("Reflect", "ownKeys") || function(e) {
  var t = MY.f(kY(e)), r = DY.f;
  return r ? NY(t, r(e)) : t;
}, FY = H, BY = Ai;
FY({ target: "Array", stat: !0 }, {
  isArray: BY
});
var LY = ie, jY = LY.Array.isArray, zY = jY, WY = zY, HY = WY, be = /* @__PURE__ */ U(HY), VY = H, UY = Kr.map, GY = ms, KY = GY("map");
VY({ target: "Array", proto: !0, forced: !KY }, {
  map: function(e) {
    return UY(this, e, arguments.length > 1 ? arguments[1] : void 0);
  }
});
var YY = Ge, qY = YY("Array").map, XY = ke, JY = qY, Zh = Array.prototype, ZY = function(i) {
  var e = i.map;
  return i === Zh || XY(Zh, i) && e === Zh.map ? JY : e;
}, QY = ZY, eq = QY, tq = eq, _n = /* @__PURE__ */ U(tq), rq = H, iq = Pt, q_ = ps, nq = Z, oq = nq(function() {
  q_(1);
});
rq({ target: "Object", stat: !0, forced: oq }, {
  keys: function(e) {
    return q_(iq(e));
  }
});
var sq = ie, aq = sq.Object.keys, lq = aq, dq = lq, hq = dq, me = /* @__PURE__ */ U(hq), cq = H, uq = Q, X_ = Date, fq = uq(X_.prototype.getTime);
cq({ target: "Date", stat: !0 }, {
  now: function() {
    return fq(new X_());
  }
});
var vq = ie, pq = vq.Date.now, gq = pq, yq = gq, mq = yq, Qa = /* @__PURE__ */ U(mq), bq = Z, Yn = function(i, e) {
  var t = [][i];
  return !!t && bq(function() {
    t.call(null, e || function() {
      return 1;
    }, 1);
  });
}, $q = Kr.forEach, wq = Yn, _q = wq("forEach"), Eq = _q ? [].forEach : function(e) {
  return $q(this, e, arguments.length > 1 ? arguments[1] : void 0);
}, Sq = H, bm = Eq;
Sq({ target: "Array", proto: !0, forced: [].forEach !== bm }, {
  forEach: bm
});
var Oq = Ge, Tq = Oq("Array").forEach, Iq = Tq, Pq = Iq, xq = Mi, Cq = Ue, Aq = ke, Mq = Pq, Qh = Array.prototype, Dq = {
  DOMTokenList: !0,
  NodeList: !0
}, kq = function(i) {
  var e = i.forEach;
  return i === Qh || Aq(Qh, i) && e === Qh.forEach || Cq(Dq, xq(i)) ? Mq : e;
}, Nq = kq, se = /* @__PURE__ */ U(Nq), Rq = H, Fq = Q, Bq = Ai, Lq = Fq([].reverse), $m = [1, 2];
Rq({ target: "Array", proto: !0, forced: String($m) === String($m.reverse()) }, {
  reverse: function() {
    return Bq(this) && (this.length = this.length), Lq(this);
  }
});
var jq = Ge, zq = jq("Array").reverse, Wq = ke, Hq = zq, ec = Array.prototype, Vq = function(i) {
  var e = i.reverse;
  return i === ec || Wq(ec, i) && e === ec.reverse ? Hq : e;
}, Uq = Vq, Gq = Uq, Kq = Gq, ci = /* @__PURE__ */ U(Kq), Yq = Ne, qq = Ai, Xq = TypeError, Jq = Object.getOwnPropertyDescriptor, Zq = Yq && !function() {
  if (this !== void 0) return !0;
  try {
    Object.defineProperty([], "length", { writable: !1 }).length = 1;
  } catch (i) {
    return i instanceof TypeError;
  }
}(), Qq = Zq ? function(i, e) {
  if (qq(i) && !Jq(i, "length").writable)
    throw new Xq("Cannot set read only .length");
  return i.length = e;
} : function(i, e) {
  return i.length = e;
}, wm = cs, eX = TypeError, J_ = function(i, e) {
  if (!delete i[e]) throw new eX("Cannot delete property " + wm(e) + " of " + wm(i));
}, tX = H, rX = Pt, iX = fs, nX = Vl, oX = Qt, sX = Qq, aX = i_, lX = Of, dX = ys, tc = J_, hX = ms, cX = hX("splice"), uX = Math.max, fX = Math.min;
tX({ target: "Array", proto: !0, forced: !cX }, {
  splice: function(e, t) {
    var r = rX(this), n = oX(r), o = iX(e, n), s = arguments.length, a, l, d, h, c, u;
    for (s === 0 ? a = l = 0 : s === 1 ? (a = 0, l = n - o) : (a = s - 2, l = fX(uX(nX(t), 0), n - o)), aX(n + a - l), d = lX(r, l), h = 0; h < l; h++)
      c = o + h, c in r && dX(d, h, r[c]);
    if (d.length = l, a < l) {
      for (h = o; h < n - l; h++)
        c = h + l, u = h + a, c in r ? r[u] = r[c] : tc(r, u);
      for (h = n; h > n - l + a; h--) tc(r, h - 1);
    } else if (a > l)
      for (h = n - l; h > o; h--)
        c = h + l - 1, u = h + a - 1, c in r ? r[u] = r[c] : tc(r, u);
    for (h = 0; h < a; h++)
      r[h + o] = arguments[h + 2];
    return sX(r, n - l + a), d;
  }
});
var vX = Ge, pX = vX("Array").splice, gX = ke, yX = pX, rc = Array.prototype, mX = function(i) {
  var e = i.splice;
  return i === rc || gX(rc, i) && e === rc.splice ? yX : e;
}, bX = mX, $X = bX, wX = $X, ar = /* @__PURE__ */ U(wX), _X = H, EX = $f.includes, SX = Z, OX = SX(function() {
  return !Array(1).includes();
});
_X({ target: "Array", proto: !0, forced: OX }, {
  includes: function(e) {
    return EX(this, e, arguments.length > 1 ? arguments[1] : void 0);
  }
});
var TX = Ge, IX = TX("Array").includes, PX = Ye, xX = mr, CX = Ie, AX = CX("match"), MX = function(i) {
  var e;
  return PX(i) && ((e = i[AX]) !== void 0 ? !!e : xX(i) === "RegExp");
}, DX = MX, kX = TypeError, NX = function(i) {
  if (DX(i))
    throw new kX("The method doesn't accept regular expressions");
  return i;
}, RX = Ie, FX = RX("match"), BX = function(i) {
  var e = /./;
  try {
    "/./"[i](e);
  } catch {
    try {
      return e[FX] = !1, "/./"[i](e);
    } catch {
    }
  }
  return !1;
}, LX = H, jX = Q, zX = NX, WX = as, _m = er, HX = BX, VX = jX("".indexOf);
LX({ target: "String", proto: !0, forced: !HX("includes") }, {
  includes: function(e) {
    return !!~VX(
      _m(WX(this)),
      _m(zX(e)),
      arguments.length > 1 ? arguments[1] : void 0
    );
  }
});
var UX = Ge, GX = UX("String").includes, Em = ke, KX = IX, YX = GX, ic = Array.prototype, nc = String.prototype, qX = function(i) {
  var e = i.includes;
  return i === ic || Em(ic, i) && e === ic.includes ? KX : typeof i == "string" || i === nc || Em(nc, i) && e === nc.includes ? YX : e;
}, XX = qX, JX = XX, ZX = JX, kr = /* @__PURE__ */ U(ZX), QX = H, eJ = Z, tJ = Pt, Z_ = td, rJ = H_, iJ = eJ(function() {
  Z_(1);
});
QX({ target: "Object", stat: !0, forced: iJ, sham: !rJ }, {
  getPrototypeOf: function(e) {
    return Z_(tJ(e));
  }
});
var nJ = ie, oJ = nJ.Object.getPrototypeOf, sJ = oJ, aJ = sJ, lJ = aJ, Sm = /* @__PURE__ */ U(lJ), dJ = Ge, hJ = dJ("Array").concat, cJ = ke, uJ = hJ, oc = Array.prototype, fJ = function(i) {
  var e = i.concat;
  return i === oc || cJ(oc, i) && e === oc.concat ? uJ : e;
}, vJ = fJ, pJ = vJ, gJ = pJ, yJ = /* @__PURE__ */ U(gJ), mJ = H, bJ = Kr.filter, $J = ms, wJ = $J("filter");
mJ({ target: "Array", proto: !0, forced: !wJ }, {
  filter: function(e) {
    return bJ(this, e, arguments.length > 1 ? arguments[1] : void 0);
  }
});
var _J = Ge, EJ = _J("Array").filter, SJ = ke, OJ = EJ, sc = Array.prototype, TJ = function(i) {
  var e = i.filter;
  return i === sc || SJ(sc, i) && e === sc.filter ? OJ : e;
}, IJ = TJ, PJ = IJ, xJ = PJ, ht = /* @__PURE__ */ U(xJ), Q_ = Ne, CJ = Z, eE = Q, AJ = td, MJ = ps, DJ = Lt, kJ = os.f, tE = eE(kJ), NJ = eE([].push), RJ = Q_ && CJ(function() {
  var i = /* @__PURE__ */ Object.create(null);
  return i[2] = 2, !tE(i, 2);
}), FJ = function(i) {
  return function(e) {
    for (var t = DJ(e), r = MJ(t), n = RJ && AJ(t) === null, o = r.length, s = 0, a = [], l; o > s; )
      l = r[s++], (!Q_ || (n ? l in t : tE(t, l))) && NJ(a, i ? [l, t[l]] : t[l]);
    return a;
  };
}, BJ = {
  // `Object.values` method
  // https://tc39.es/ecma262/#sec-object.values
  values: FJ(!1)
}, LJ = H, jJ = BJ.values;
LJ({ target: "Object", stat: !0 }, {
  values: function(e) {
    return jJ(e);
  }
});
var zJ = ie, WJ = zJ.Object.values, HJ = WJ, VJ = HJ, UJ = VJ, GJ = /* @__PURE__ */ U(UJ), Df = `	
\v\f\r                　\u2028\u2029\uFEFF`, KJ = Q, YJ = as, qJ = er, pu = Df, Om = KJ("".replace), XJ = RegExp("^[" + pu + "]+"), JJ = RegExp("(^|[^" + pu + "])[" + pu + "]+$"), ZJ = function(i) {
  return function(e) {
    var t = qJ(YJ(e));
    return i & 1 && (t = Om(t, XJ, "")), i & 2 && (t = Om(t, JJ, "$1")), t;
  };
}, rE = {
  // `String.prototype.trim` method
  // https://tc39.es/ecma262/#sec-string.prototype.trim
  trim: ZJ(3)
}, iE = _e, QJ = Z, eZ = Q, tZ = er, rZ = rE.trim, Tm = Df, fo = iE.parseInt, Im = iE.Symbol, Pm = Im && Im.iterator, nE = /^[+-]?0x/i, iZ = eZ(nE.exec), nZ = fo(Tm + "08") !== 8 || fo(Tm + "0x16") !== 22 || Pm && !QJ(function() {
  fo(Object(Pm));
}), oZ = nZ ? function(e, t) {
  var r = rZ(tZ(e));
  return fo(r, t >>> 0 || (iZ(nE, r) ? 16 : 10));
} : fo, sZ = H, xm = oZ;
sZ({ global: !0, forced: parseInt !== xm }, {
  parseInt: xm
});
var aZ = ie, lZ = aZ.parseInt, dZ = lZ, hZ = dZ, cZ = hZ, Dt = /* @__PURE__ */ U(cZ), uZ = H, fZ = yf, vZ = $f.indexOf, pZ = Yn, gu = fZ([].indexOf), oE = !!gu && 1 / gu([1], 1, -0) < 0, gZ = oE || !pZ("indexOf");
uZ({ target: "Array", proto: !0, forced: gZ }, {
  indexOf: function(e) {
    var t = arguments.length > 1 ? arguments[1] : void 0;
    return oE ? gu(this, e, t) || 0 : vZ(this, e, t);
  }
});
var yZ = Ge, mZ = yZ("Array").indexOf, bZ = ke, $Z = mZ, ac = Array.prototype, wZ = function(i) {
  var e = i.indexOf;
  return i === ac || bZ(ac, i) && e === ac.indexOf ? $Z : e;
}, _Z = wZ, EZ = _Z, SZ = EZ, re = /* @__PURE__ */ U(SZ), OZ = H, TZ = Ne, IZ = bs;
OZ({ target: "Object", stat: !0, sham: !TZ }, {
  create: IZ
});
var PZ = ie, xZ = PZ.Object, CZ = function(e, t) {
  return xZ.create(e, t);
}, AZ = CZ, MZ = AZ, DZ = MZ, ui = /* @__PURE__ */ U(DZ), yu = ie, kZ = Ll;
yu.JSON || (yu.JSON = { stringify: JSON.stringify });
var NZ = function(e, t, r) {
  return kZ(yu.JSON.stringify, null, arguments);
}, RZ = NZ, FZ = RZ, BZ = FZ, Os = /* @__PURE__ */ U(BZ), LZ = typeof Bun == "function" && Bun && typeof Bun.version == "string", jZ = TypeError, zZ = function(i, e) {
  if (i < e) throw new jZ("Not enough arguments");
  return i;
}, sE = _e, WZ = Ll, HZ = Ve, VZ = LZ, UZ = ls, GZ = Ul, KZ = zZ, YZ = sE.Function, qZ = /MSIE .\./.test(UZ) || VZ && function() {
  var i = sE.Bun.version.split(".");
  return i.length < 3 || i[0] === "0" && (i[1] < 3 || i[1] === "3" && i[2] === "0");
}(), aE = function(i, e) {
  var t = e ? 2 : 1;
  return qZ ? function(r, n) {
    var o = KZ(arguments.length, 1) > t, s = HZ(r) ? r : YZ(r), a = o ? GZ(arguments, t) : [], l = o ? function() {
      WZ(s, this, a);
    } : s;
    return e ? i(l, n) : i(l);
  } : i;
}, XZ = H, lE = _e, JZ = aE, Cm = JZ(lE.setInterval, !0);
XZ({ global: !0, bind: !0, forced: lE.setInterval !== Cm }, {
  setInterval: Cm
});
var ZZ = H, dE = _e, QZ = aE, Am = QZ(dE.setTimeout, !0);
ZZ({ global: !0, bind: !0, forced: dE.setTimeout !== Am }, {
  setTimeout: Am
});
var eQ = ie, tQ = eQ.setTimeout, rQ = tQ, lr = /* @__PURE__ */ U(rQ), iQ = Pt, Mm = fs, nQ = Qt, oQ = function(e) {
  for (var t = iQ(this), r = nQ(t), n = arguments.length, o = Mm(n > 1 ? arguments[1] : void 0, r), s = n > 2 ? arguments[2] : void 0, a = s === void 0 ? r : Mm(s, r); a > o; ) t[o++] = e;
  return t;
}, sQ = H, aQ = oQ;
sQ({ target: "Array", proto: !0 }, {
  fill: aQ
});
var lQ = Ge, dQ = lQ("Array").fill, hQ = ke, cQ = dQ, lc = Array.prototype, uQ = function(i) {
  var e = i.fill;
  return i === lc || hQ(lc, i) && e === lc.fill ? cQ : e;
}, fQ = uQ, vQ = fQ, pQ = vQ, Ts = /* @__PURE__ */ U(pQ);
/*! Hammer.JS - v2.0.17-rc - 2019-12-16
 * http://naver.github.io/egjs
 *
 * Forked By Naver egjs
 * Copyright (c) hammerjs
 * Licensed under the MIT license */
function Ft() {
  return Ft = Object.assign || function(i) {
    for (var e = 1; e < arguments.length; e++) {
      var t = arguments[e];
      for (var r in t)
        Object.prototype.hasOwnProperty.call(t, r) && (i[r] = t[r]);
    }
    return i;
  }, Ft.apply(this, arguments);
}
function xt(i, e) {
  i.prototype = Object.create(e.prototype), i.prototype.constructor = i, i.__proto__ = e;
}
function la(i) {
  if (i === void 0)
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return i;
}
var mu;
typeof Object.assign != "function" ? mu = function(e) {
  if (e == null)
    throw new TypeError("Cannot convert undefined or null to object");
  for (var t = Object(e), r = 1; r < arguments.length; r++) {
    var n = arguments[r];
    if (n != null)
      for (var o in n)
        n.hasOwnProperty(o) && (t[o] = n[o]);
  }
  return t;
} : mu = Object.assign;
var $i = mu, Dm = ["", "webkit", "Moz", "MS", "ms", "o"], gQ = typeof document > "u" ? {
  style: {}
} : document.createElement("div"), yQ = "function", on = Math.round, wi = Math.abs, kf = Date.now;
function rd(i, e) {
  for (var t, r, n = e[0].toUpperCase() + e.slice(1), o = 0; o < Dm.length; ) {
    if (t = Dm[o], r = t ? t + n : e, r in i)
      return r;
    o++;
  }
}
var dr;
typeof window > "u" ? dr = {} : dr = window;
var hE = rd(gQ.style, "touchAction"), cE = hE !== void 0;
function mQ() {
  if (!cE)
    return !1;
  var i = {}, e = dr.CSS && dr.CSS.supports;
  return ["auto", "manipulation", "pan-y", "pan-x", "pan-x pan-y", "none"].forEach(function(t) {
    return i[t] = e ? dr.CSS.supports("touch-action", t) : !0;
  }), i;
}
var uE = "compute", fE = "auto", bu = "manipulation", fi = "none", Ao = "pan-x", Mo = "pan-y", da = mQ(), bQ = /mobile|tablet|ip(ad|hone|od)|android/i, vE = "ontouchstart" in dr, $Q = rd(dr, "PointerEvent") !== void 0, wQ = vE && bQ.test(navigator.userAgent), Is = "touch", _Q = "pen", Nf = "mouse", EQ = "kinect", SQ = 25, et = 1, ki = 2, Ae = 4, ut = 8, el = 1, Ps = 2, xs = 4, Cs = 8, En = 16, Xt = Ps | xs, vi = Cs | En, pE = Xt | vi, gE = ["x", "y"], tl = ["clientX", "clientY"];
function hr(i, e, t) {
  var r;
  if (i)
    if (i.forEach)
      i.forEach(e, t);
    else if (i.length !== void 0)
      for (r = 0; r < i.length; )
        e.call(t, i[r], r, i), r++;
    else
      for (r in i)
        i.hasOwnProperty(r) && e.call(t, i[r], r, i);
}
function id(i, e) {
  return typeof i === yQ ? i.apply(e && e[0] || void 0, e) : i;
}
function ri(i, e) {
  return i.indexOf(e) > -1;
}
function OQ(i) {
  if (ri(i, fi))
    return fi;
  var e = ri(i, Ao), t = ri(i, Mo);
  return e && t ? fi : e || t ? e ? Ao : Mo : ri(i, bu) ? bu : fE;
}
var yE = /* @__PURE__ */ function() {
  function i(t, r) {
    this.manager = t, this.set(r);
  }
  var e = i.prototype;
  return e.set = function(r) {
    r === uE && (r = this.compute()), cE && this.manager.element.style && da[r] && (this.manager.element.style[hE] = r), this.actions = r.toLowerCase().trim();
  }, e.update = function() {
    this.set(this.manager.options.touchAction);
  }, e.compute = function() {
    var r = [];
    return hr(this.manager.recognizers, function(n) {
      id(n.options.enable, [n]) && (r = r.concat(n.getTouchAction()));
    }), OQ(r.join(" "));
  }, e.preventDefaults = function(r) {
    var n = r.srcEvent, o = r.offsetDirection;
    if (this.manager.session.prevented) {
      n.preventDefault();
      return;
    }
    var s = this.actions, a = ri(s, fi) && !da[fi], l = ri(s, Mo) && !da[Mo], d = ri(s, Ao) && !da[Ao];
    if (a) {
      var h = r.pointers.length === 1, c = r.distance < 2, u = r.deltaTime < 250;
      if (h && c && u)
        return;
    }
    if (!(d && l) && (a || l && o & Xt || d && o & vi))
      return this.preventSrc(n);
  }, e.preventSrc = function(r) {
    this.manager.session.prevented = !0, r.preventDefault();
  }, i;
}();
function Rf(i, e) {
  for (; i; ) {
    if (i === e)
      return !0;
    i = i.parentNode;
  }
  return !1;
}
function mE(i) {
  var e = i.length;
  if (e === 1)
    return {
      x: on(i[0].clientX),
      y: on(i[0].clientY)
    };
  for (var t = 0, r = 0, n = 0; n < e; )
    t += i[n].clientX, r += i[n].clientY, n++;
  return {
    x: on(t / e),
    y: on(r / e)
  };
}
function km(i) {
  for (var e = [], t = 0; t < i.pointers.length; )
    e[t] = {
      clientX: on(i.pointers[t].clientX),
      clientY: on(i.pointers[t].clientY)
    }, t++;
  return {
    timeStamp: kf(),
    pointers: e,
    center: mE(e),
    deltaX: i.deltaX,
    deltaY: i.deltaY
  };
}
function rl(i, e, t) {
  t || (t = gE);
  var r = e[t[0]] - i[t[0]], n = e[t[1]] - i[t[1]];
  return Math.sqrt(r * r + n * n);
}
function $u(i, e, t) {
  t || (t = gE);
  var r = e[t[0]] - i[t[0]], n = e[t[1]] - i[t[1]];
  return Math.atan2(n, r) * 180 / Math.PI;
}
function bE(i, e) {
  return i === e ? el : wi(i) >= wi(e) ? i < 0 ? Ps : xs : e < 0 ? Cs : En;
}
function TQ(i, e) {
  var t = e.center, r = i.offsetDelta || {}, n = i.prevDelta || {}, o = i.prevInput || {};
  (e.eventType === et || o.eventType === Ae) && (n = i.prevDelta = {
    x: o.deltaX || 0,
    y: o.deltaY || 0
  }, r = i.offsetDelta = {
    x: t.x,
    y: t.y
  }), e.deltaX = n.x + (t.x - r.x), e.deltaY = n.y + (t.y - r.y);
}
function $E(i, e, t) {
  return {
    x: e / i || 0,
    y: t / i || 0
  };
}
function IQ(i, e) {
  return rl(e[0], e[1], tl) / rl(i[0], i[1], tl);
}
function PQ(i, e) {
  return $u(e[1], e[0], tl) + $u(i[1], i[0], tl);
}
function xQ(i, e) {
  var t = i.lastInterval || e, r = e.timeStamp - t.timeStamp, n, o, s, a;
  if (e.eventType !== ut && (r > SQ || t.velocity === void 0)) {
    var l = e.deltaX - t.deltaX, d = e.deltaY - t.deltaY, h = $E(r, l, d);
    o = h.x, s = h.y, n = wi(h.x) > wi(h.y) ? h.x : h.y, a = bE(l, d), i.lastInterval = e;
  } else
    n = t.velocity, o = t.velocityX, s = t.velocityY, a = t.direction;
  e.velocity = n, e.velocityX = o, e.velocityY = s, e.direction = a;
}
function CQ(i, e) {
  var t = i.session, r = e.pointers, n = r.length;
  t.firstInput || (t.firstInput = km(e)), n > 1 && !t.firstMultiple ? t.firstMultiple = km(e) : n === 1 && (t.firstMultiple = !1);
  var o = t.firstInput, s = t.firstMultiple, a = s ? s.center : o.center, l = e.center = mE(r);
  e.timeStamp = kf(), e.deltaTime = e.timeStamp - o.timeStamp, e.angle = $u(a, l), e.distance = rl(a, l), TQ(t, e), e.offsetDirection = bE(e.deltaX, e.deltaY);
  var d = $E(e.deltaTime, e.deltaX, e.deltaY);
  e.overallVelocityX = d.x, e.overallVelocityY = d.y, e.overallVelocity = wi(d.x) > wi(d.y) ? d.x : d.y, e.scale = s ? IQ(s.pointers, r) : 1, e.rotation = s ? PQ(s.pointers, r) : 0, e.maxPointers = t.prevInput ? e.pointers.length > t.prevInput.maxPointers ? e.pointers.length : t.prevInput.maxPointers : e.pointers.length, xQ(t, e);
  var h = i.element, c = e.srcEvent, u;
  c.composedPath ? u = c.composedPath()[0] : c.path ? u = c.path[0] : u = c.target, Rf(u, h) && (h = u), e.target = h;
}
function AQ(i, e, t) {
  var r = t.pointers.length, n = t.changedPointers.length, o = e & et && r - n === 0, s = e & (Ae | ut) && r - n === 0;
  t.isFirst = !!o, t.isFinal = !!s, o && (i.session = {}), t.eventType = e, CQ(i, t), i.emit("hammer.input", t), i.recognize(t), i.session.prevInput = t;
}
function Do(i) {
  return i.trim().split(/\s+/g);
}
function vo(i, e, t) {
  hr(Do(e), function(r) {
    i.addEventListener(r, t, !1);
  });
}
function po(i, e, t) {
  hr(Do(e), function(r) {
    i.removeEventListener(r, t, !1);
  });
}
function Nm(i) {
  var e = i.ownerDocument || i;
  return e.defaultView || e.parentWindow || window;
}
var qn = /* @__PURE__ */ function() {
  function i(t, r) {
    var n = this;
    this.manager = t, this.callback = r, this.element = t.element, this.target = t.options.inputTarget, this.domHandler = function(o) {
      id(t.options.enable, [t]) && n.handler(o);
    }, this.init();
  }
  var e = i.prototype;
  return e.handler = function() {
  }, e.init = function() {
    this.evEl && vo(this.element, this.evEl, this.domHandler), this.evTarget && vo(this.target, this.evTarget, this.domHandler), this.evWin && vo(Nm(this.element), this.evWin, this.domHandler);
  }, e.destroy = function() {
    this.evEl && po(this.element, this.evEl, this.domHandler), this.evTarget && po(this.target, this.evTarget, this.domHandler), this.evWin && po(Nm(this.element), this.evWin, this.domHandler);
  }, i;
}();
function _i(i, e, t) {
  if (i.indexOf && !t)
    return i.indexOf(e);
  for (var r = 0; r < i.length; ) {
    if (t && i[r][t] == e || !t && i[r] === e)
      return r;
    r++;
  }
  return -1;
}
var MQ = {
  pointerdown: et,
  pointermove: ki,
  pointerup: Ae,
  pointercancel: ut,
  pointerout: ut
}, DQ = {
  2: Is,
  3: _Q,
  4: Nf,
  5: EQ
  // see https://twitter.com/jacobrossi/status/480596438489890816
}, wE = "pointerdown", _E = "pointermove pointerup pointercancel";
dr.MSPointerEvent && !dr.PointerEvent && (wE = "MSPointerDown", _E = "MSPointerMove MSPointerUp MSPointerCancel");
var EE = /* @__PURE__ */ function(i) {
  xt(e, i);
  function e() {
    var r, n = e.prototype;
    return n.evEl = wE, n.evWin = _E, r = i.apply(this, arguments) || this, r.store = r.manager.session.pointerEvents = [], r;
  }
  var t = e.prototype;
  return t.handler = function(n) {
    var o = this.store, s = !1, a = n.type.toLowerCase().replace("ms", ""), l = MQ[a], d = DQ[n.pointerType] || n.pointerType, h = d === Is, c = _i(o, n.pointerId, "pointerId");
    l & et && (n.button === 0 || h) ? c < 0 && (o.push(n), c = o.length - 1) : l & (Ae | ut) && (s = !0), !(c < 0) && (o[c] = n, this.callback(this.manager, l, {
      pointers: o,
      changedPointers: [n],
      pointerType: d,
      srcEvent: n
    }), s && o.splice(c, 1));
  }, e;
}(qn);
function ko(i) {
  return Array.prototype.slice.call(i, 0);
}
function Ff(i, e, t) {
  for (var r = [], n = [], o = 0; o < i.length; ) {
    var s = e ? i[o][e] : i[o];
    _i(n, s) < 0 && r.push(i[o]), n[o] = s, o++;
  }
  return t && (e ? r = r.sort(function(a, l) {
    return a[e] > l[e];
  }) : r = r.sort()), r;
}
var kQ = {
  touchstart: et,
  touchmove: ki,
  touchend: Ae,
  touchcancel: ut
}, NQ = "touchstart touchmove touchend touchcancel", Bf = /* @__PURE__ */ function(i) {
  xt(e, i);
  function e() {
    var r;
    return e.prototype.evTarget = NQ, r = i.apply(this, arguments) || this, r.targetIds = {}, r;
  }
  var t = e.prototype;
  return t.handler = function(n) {
    var o = kQ[n.type], s = RQ.call(this, n, o);
    s && this.callback(this.manager, o, {
      pointers: s[0],
      changedPointers: s[1],
      pointerType: Is,
      srcEvent: n
    });
  }, e;
}(qn);
function RQ(i, e) {
  var t = ko(i.touches), r = this.targetIds;
  if (e & (et | ki) && t.length === 1)
    return r[t[0].identifier] = !0, [t, t];
  var n, o, s = ko(i.changedTouches), a = [], l = this.target;
  if (o = t.filter(function(d) {
    return Rf(d.target, l);
  }), e === et)
    for (n = 0; n < o.length; )
      r[o[n].identifier] = !0, n++;
  for (n = 0; n < s.length; )
    r[s[n].identifier] && a.push(s[n]), e & (Ae | ut) && delete r[s[n].identifier], n++;
  if (a.length)
    return [
      // merge targetTouches with changedTargetTouches so it contains ALL touches, including 'end' and 'cancel'
      Ff(o.concat(a), "identifier", !0),
      a
    ];
}
var FQ = {
  mousedown: et,
  mousemove: ki,
  mouseup: Ae
}, BQ = "mousedown", LQ = "mousemove mouseup", Lf = /* @__PURE__ */ function(i) {
  xt(e, i);
  function e() {
    var r, n = e.prototype;
    return n.evEl = BQ, n.evWin = LQ, r = i.apply(this, arguments) || this, r.pressed = !1, r;
  }
  var t = e.prototype;
  return t.handler = function(n) {
    var o = FQ[n.type];
    o & et && n.button === 0 && (this.pressed = !0), o & ki && n.which !== 1 && (o = Ae), this.pressed && (o & Ae && (this.pressed = !1), this.callback(this.manager, o, {
      pointers: [n],
      changedPointers: [n],
      pointerType: Nf,
      srcEvent: n
    }));
  }, e;
}(qn), jQ = 2500, Rm = 25;
function Fm(i) {
  var e = i.changedPointers, t = e[0];
  if (t.identifier === this.primaryTouch) {
    var r = {
      x: t.clientX,
      y: t.clientY
    }, n = this.lastTouches;
    this.lastTouches.push(r);
    var o = function() {
      var a = n.indexOf(r);
      a > -1 && n.splice(a, 1);
    };
    setTimeout(o, jQ);
  }
}
function zQ(i, e) {
  i & et ? (this.primaryTouch = e.changedPointers[0].identifier, Fm.call(this, e)) : i & (Ae | ut) && Fm.call(this, e);
}
function WQ(i) {
  for (var e = i.srcEvent.clientX, t = i.srcEvent.clientY, r = 0; r < this.lastTouches.length; r++) {
    var n = this.lastTouches[r], o = Math.abs(e - n.x), s = Math.abs(t - n.y);
    if (o <= Rm && s <= Rm)
      return !0;
  }
  return !1;
}
var SE = /* @__PURE__ */ function() {
  var i = /* @__PURE__ */ function(e) {
    xt(t, e);
    function t(n, o) {
      var s;
      return s = e.call(this, n, o) || this, s.handler = function(a, l, d) {
        var h = d.pointerType === Is, c = d.pointerType === Nf;
        if (!(c && d.sourceCapabilities && d.sourceCapabilities.firesTouchEvents)) {
          if (h)
            zQ.call(la(la(s)), l, d);
          else if (c && WQ.call(la(la(s)), d))
            return;
          s.callback(a, l, d);
        }
      }, s.touch = new Bf(s.manager, s.handler), s.mouse = new Lf(s.manager, s.handler), s.primaryTouch = null, s.lastTouches = [], s;
    }
    var r = t.prototype;
    return r.destroy = function() {
      this.touch.destroy(), this.mouse.destroy();
    }, t;
  }(qn);
  return i;
}();
function HQ(i) {
  var e, t = i.options.inputClass;
  return t ? e = t : $Q ? e = EE : wQ ? e = Bf : vE ? e = SE : e = Lf, new e(i, AQ);
}
function sn(i, e, t) {
  return Array.isArray(i) ? (hr(i, t[e], t), !0) : !1;
}
var Ca = 1, Tt = 2, Sn = 4, Nr = 8, cr = Nr, No = 16, Kt = 32, VQ = 1;
function UQ() {
  return VQ++;
}
function ha(i, e) {
  var t = e.manager;
  return t ? t.get(i) : i;
}
function Bm(i) {
  return i & No ? "cancel" : i & Nr ? "end" : i & Sn ? "move" : i & Tt ? "start" : "";
}
var As = /* @__PURE__ */ function() {
  function i(t) {
    t === void 0 && (t = {}), this.options = Ft({
      enable: !0
    }, t), this.id = UQ(), this.manager = null, this.state = Ca, this.simultaneous = {}, this.requireFail = [];
  }
  var e = i.prototype;
  return e.set = function(r) {
    return $i(this.options, r), this.manager && this.manager.touchAction.update(), this;
  }, e.recognizeWith = function(r) {
    if (sn(r, "recognizeWith", this))
      return this;
    var n = this.simultaneous;
    return r = ha(r, this), n[r.id] || (n[r.id] = r, r.recognizeWith(this)), this;
  }, e.dropRecognizeWith = function(r) {
    return sn(r, "dropRecognizeWith", this) ? this : (r = ha(r, this), delete this.simultaneous[r.id], this);
  }, e.requireFailure = function(r) {
    if (sn(r, "requireFailure", this))
      return this;
    var n = this.requireFail;
    return r = ha(r, this), _i(n, r) === -1 && (n.push(r), r.requireFailure(this)), this;
  }, e.dropRequireFailure = function(r) {
    if (sn(r, "dropRequireFailure", this))
      return this;
    r = ha(r, this);
    var n = _i(this.requireFail, r);
    return n > -1 && this.requireFail.splice(n, 1), this;
  }, e.hasRequireFailures = function() {
    return this.requireFail.length > 0;
  }, e.canRecognizeWith = function(r) {
    return !!this.simultaneous[r.id];
  }, e.emit = function(r) {
    var n = this, o = this.state;
    function s(a) {
      n.manager.emit(a, r);
    }
    o < Nr && s(n.options.event + Bm(o)), s(n.options.event), r.additionalEvent && s(r.additionalEvent), o >= Nr && s(n.options.event + Bm(o));
  }, e.tryEmit = function(r) {
    if (this.canEmit())
      return this.emit(r);
    this.state = Kt;
  }, e.canEmit = function() {
    for (var r = 0; r < this.requireFail.length; ) {
      if (!(this.requireFail[r].state & (Kt | Ca)))
        return !1;
      r++;
    }
    return !0;
  }, e.recognize = function(r) {
    var n = $i({}, r);
    if (!id(this.options.enable, [this, n])) {
      this.reset(), this.state = Kt;
      return;
    }
    this.state & (cr | No | Kt) && (this.state = Ca), this.state = this.process(n), this.state & (Tt | Sn | Nr | No) && this.tryEmit(n);
  }, e.process = function(r) {
  }, e.getTouchAction = function() {
  }, e.reset = function() {
  }, i;
}(), wu = /* @__PURE__ */ function(i) {
  xt(e, i);
  function e(r) {
    var n;
    return r === void 0 && (r = {}), n = i.call(this, Ft({
      event: "tap",
      pointers: 1,
      taps: 1,
      interval: 300,
      // max time between the multi-tap taps
      time: 250,
      // max time of the pointer to be down (like finger on the screen)
      threshold: 9,
      // a minimal movement is ok, but keep it low
      posThreshold: 10
    }, r)) || this, n.pTime = !1, n.pCenter = !1, n._timer = null, n._input = null, n.count = 0, n;
  }
  var t = e.prototype;
  return t.getTouchAction = function() {
    return [bu];
  }, t.process = function(n) {
    var o = this, s = this.options, a = n.pointers.length === s.pointers, l = n.distance < s.threshold, d = n.deltaTime < s.time;
    if (this.reset(), n.eventType & et && this.count === 0)
      return this.failTimeout();
    if (l && d && a) {
      if (n.eventType !== Ae)
        return this.failTimeout();
      var h = this.pTime ? n.timeStamp - this.pTime < s.interval : !0, c = !this.pCenter || rl(this.pCenter, n.center) < s.posThreshold;
      this.pTime = n.timeStamp, this.pCenter = n.center, !c || !h ? this.count = 1 : this.count += 1, this._input = n;
      var u = this.count % s.taps;
      if (u === 0)
        return this.hasRequireFailures() ? (this._timer = setTimeout(function() {
          o.state = cr, o.tryEmit();
        }, s.interval), Tt) : cr;
    }
    return Kt;
  }, t.failTimeout = function() {
    var n = this;
    return this._timer = setTimeout(function() {
      n.state = Kt;
    }, this.options.interval), Kt;
  }, t.reset = function() {
    clearTimeout(this._timer);
  }, t.emit = function() {
    this.state === cr && (this._input.tapCount = this.count, this.manager.emit(this.options.event, this._input));
  }, e;
}(As), On = /* @__PURE__ */ function(i) {
  xt(e, i);
  function e(r) {
    return r === void 0 && (r = {}), i.call(this, Ft({
      pointers: 1
    }, r)) || this;
  }
  var t = e.prototype;
  return t.attrTest = function(n) {
    var o = this.options.pointers;
    return o === 0 || n.pointers.length === o;
  }, t.process = function(n) {
    var o = this.state, s = n.eventType, a = o & (Tt | Sn), l = this.attrTest(n);
    return a && (s & ut || !l) ? o | No : a || l ? s & Ae ? o | Nr : o & Tt ? o | Sn : Tt : Kt;
  }, e;
}(As);
function OE(i) {
  return i === En ? "down" : i === Cs ? "up" : i === Ps ? "left" : i === xs ? "right" : "";
}
var jf = /* @__PURE__ */ function(i) {
  xt(e, i);
  function e(r) {
    var n;
    return r === void 0 && (r = {}), n = i.call(this, Ft({
      event: "pan",
      threshold: 10,
      pointers: 1,
      direction: pE
    }, r)) || this, n.pX = null, n.pY = null, n;
  }
  var t = e.prototype;
  return t.getTouchAction = function() {
    var n = this.options.direction, o = [];
    return n & Xt && o.push(Mo), n & vi && o.push(Ao), o;
  }, t.directionTest = function(n) {
    var o = this.options, s = !0, a = n.distance, l = n.direction, d = n.deltaX, h = n.deltaY;
    return l & o.direction || (o.direction & Xt ? (l = d === 0 ? el : d < 0 ? Ps : xs, s = d !== this.pX, a = Math.abs(n.deltaX)) : (l = h === 0 ? el : h < 0 ? Cs : En, s = h !== this.pY, a = Math.abs(n.deltaY))), n.direction = l, s && a > o.threshold && l & o.direction;
  }, t.attrTest = function(n) {
    return On.prototype.attrTest.call(this, n) && // replace with a super call
    (this.state & Tt || !(this.state & Tt) && this.directionTest(n));
  }, t.emit = function(n) {
    this.pX = n.deltaX, this.pY = n.deltaY;
    var o = OE(n.direction);
    o && (n.additionalEvent = this.options.event + o), i.prototype.emit.call(this, n);
  }, e;
}(On), TE = /* @__PURE__ */ function(i) {
  xt(e, i);
  function e(r) {
    return r === void 0 && (r = {}), i.call(this, Ft({
      event: "swipe",
      threshold: 10,
      velocity: 0.3,
      direction: Xt | vi,
      pointers: 1
    }, r)) || this;
  }
  var t = e.prototype;
  return t.getTouchAction = function() {
    return jf.prototype.getTouchAction.call(this);
  }, t.attrTest = function(n) {
    var o = this.options.direction, s;
    return o & (Xt | vi) ? s = n.overallVelocity : o & Xt ? s = n.overallVelocityX : o & vi && (s = n.overallVelocityY), i.prototype.attrTest.call(this, n) && o & n.offsetDirection && n.distance > this.options.threshold && n.maxPointers === this.options.pointers && wi(s) > this.options.velocity && n.eventType & Ae;
  }, t.emit = function(n) {
    var o = OE(n.offsetDirection);
    o && this.manager.emit(this.options.event + o, n), this.manager.emit(this.options.event, n);
  }, e;
}(On), IE = /* @__PURE__ */ function(i) {
  xt(e, i);
  function e(r) {
    return r === void 0 && (r = {}), i.call(this, Ft({
      event: "pinch",
      threshold: 0,
      pointers: 2
    }, r)) || this;
  }
  var t = e.prototype;
  return t.getTouchAction = function() {
    return [fi];
  }, t.attrTest = function(n) {
    return i.prototype.attrTest.call(this, n) && (Math.abs(n.scale - 1) > this.options.threshold || this.state & Tt);
  }, t.emit = function(n) {
    if (n.scale !== 1) {
      var o = n.scale < 1 ? "in" : "out";
      n.additionalEvent = this.options.event + o;
    }
    i.prototype.emit.call(this, n);
  }, e;
}(On), PE = /* @__PURE__ */ function(i) {
  xt(e, i);
  function e(r) {
    return r === void 0 && (r = {}), i.call(this, Ft({
      event: "rotate",
      threshold: 0,
      pointers: 2
    }, r)) || this;
  }
  var t = e.prototype;
  return t.getTouchAction = function() {
    return [fi];
  }, t.attrTest = function(n) {
    return i.prototype.attrTest.call(this, n) && (Math.abs(n.rotation) > this.options.threshold || this.state & Tt);
  }, e;
}(On), xE = /* @__PURE__ */ function(i) {
  xt(e, i);
  function e(r) {
    var n;
    return r === void 0 && (r = {}), n = i.call(this, Ft({
      event: "press",
      pointers: 1,
      time: 251,
      // minimal time of the pointer to be pressed
      threshold: 9
    }, r)) || this, n._timer = null, n._input = null, n;
  }
  var t = e.prototype;
  return t.getTouchAction = function() {
    return [fE];
  }, t.process = function(n) {
    var o = this, s = this.options, a = n.pointers.length === s.pointers, l = n.distance < s.threshold, d = n.deltaTime > s.time;
    if (this._input = n, !l || !a || n.eventType & (Ae | ut) && !d)
      this.reset();
    else if (n.eventType & et)
      this.reset(), this._timer = setTimeout(function() {
        o.state = cr, o.tryEmit();
      }, s.time);
    else if (n.eventType & Ae)
      return cr;
    return Kt;
  }, t.reset = function() {
    clearTimeout(this._timer);
  }, t.emit = function(n) {
    this.state === cr && (n && n.eventType & Ae ? this.manager.emit(this.options.event + "up", n) : (this._input.timeStamp = kf(), this.manager.emit(this.options.event, this._input)));
  }, e;
}(As), CE = {
  /**
   * @private
   * set if DOM events are being triggered.
   * But this is slower and unused by simple implementations, so disabled by default.
   * @type {Boolean}
   * @default false
   */
  domEvents: !1,
  /**
   * @private
   * The value for the touchAction property/fallback.
   * When set to `compute` it will magically set the correct value based on the added recognizers.
   * @type {String}
   * @default compute
   */
  touchAction: uE,
  /**
   * @private
   * @type {Boolean}
   * @default true
   */
  enable: !0,
  /**
   * @private
   * EXPERIMENTAL FEATURE -- can be removed/changed
   * Change the parent input target element.
   * If Null, then it is being set the to main element.
   * @type {Null|EventTarget}
   * @default null
   */
  inputTarget: null,
  /**
   * @private
   * force an input class
   * @type {Null|Function}
   * @default null
   */
  inputClass: null,
  /**
   * @private
   * Some CSS properties can be used to improve the working of Hammer.
   * Add them to this method and they will be set when creating a new Manager.
   * @namespace
   */
  cssProps: {
    /**
     * @private
     * Disables text selection to improve the dragging gesture. Mainly for desktop browsers.
     * @type {String}
     * @default 'none'
     */
    userSelect: "none",
    /**
     * @private
     * Disable the Windows Phone grippers when pressing an element.
     * @type {String}
     * @default 'none'
     */
    touchSelect: "none",
    /**
     * @private
     * Disables the default callout shown when you touch and hold a touch target.
     * On iOS, when you touch and hold a touch target such as a link, Safari displays
     * a callout containing information about the link. This property allows you to disable that callout.
     * @type {String}
     * @default 'none'
     */
    touchCallout: "none",
    /**
     * @private
     * Specifies whether zooming is enabled. Used by IE10>
     * @type {String}
     * @default 'none'
     */
    contentZooming: "none",
    /**
     * @private
     * Specifies that an entire element should be draggable instead of its contents. Mainly for desktop browsers.
     * @type {String}
     * @default 'none'
     */
    userDrag: "none",
    /**
     * @private
     * Overrides the highlight color shown when the user taps a link or a JavaScript
     * clickable element in iOS. This property obeys the alpha value, if specified.
     * @type {String}
     * @default 'rgba(0,0,0,0)'
     */
    tapHighlightColor: "rgba(0,0,0,0)"
  }
}, Lm = [[PE, {
  enable: !1
}], [IE, {
  enable: !1
}, ["rotate"]], [TE, {
  direction: Xt
}], [jf, {
  direction: Xt
}, ["swipe"]], [wu], [wu, {
  event: "doubletap",
  taps: 2
}, ["tap"]], [xE]], GQ = 1, jm = 2;
function zm(i, e) {
  var t = i.element;
  if (t.style) {
    var r;
    hr(i.options.cssProps, function(n, o) {
      r = rd(t.style, o), e ? (i.oldCssProps[r] = t.style[r], t.style[r] = n) : t.style[r] = i.oldCssProps[r] || "";
    }), e || (i.oldCssProps = {});
  }
}
function KQ(i, e) {
  var t = document.createEvent("Event");
  t.initEvent(i, !0, !0), t.gesture = e, e.target.dispatchEvent(t);
}
var Wm = /* @__PURE__ */ function() {
  function i(t, r) {
    var n = this;
    this.options = $i({}, CE, r || {}), this.options.inputTarget = this.options.inputTarget || t, this.handlers = {}, this.session = {}, this.recognizers = [], this.oldCssProps = {}, this.element = t, this.input = HQ(this), this.touchAction = new yE(this, this.options.touchAction), zm(this, !0), hr(this.options.recognizers, function(o) {
      var s = n.add(new o[0](o[1]));
      o[2] && s.recognizeWith(o[2]), o[3] && s.requireFailure(o[3]);
    }, this);
  }
  var e = i.prototype;
  return e.set = function(r) {
    return $i(this.options, r), r.touchAction && this.touchAction.update(), r.inputTarget && (this.input.destroy(), this.input.target = r.inputTarget, this.input.init()), this;
  }, e.stop = function(r) {
    this.session.stopped = r ? jm : GQ;
  }, e.recognize = function(r) {
    var n = this.session;
    if (!n.stopped) {
      this.touchAction.preventDefaults(r);
      var o, s = this.recognizers, a = n.curRecognizer;
      (!a || a && a.state & cr) && (n.curRecognizer = null, a = null);
      for (var l = 0; l < s.length; )
        o = s[l], n.stopped !== jm && // 1
        (!a || o === a || // 2
        o.canRecognizeWith(a)) ? o.recognize(r) : o.reset(), !a && o.state & (Tt | Sn | Nr) && (n.curRecognizer = o, a = o), l++;
    }
  }, e.get = function(r) {
    if (r instanceof As)
      return r;
    for (var n = this.recognizers, o = 0; o < n.length; o++)
      if (n[o].options.event === r)
        return n[o];
    return null;
  }, e.add = function(r) {
    if (sn(r, "add", this))
      return this;
    var n = this.get(r.options.event);
    return n && this.remove(n), this.recognizers.push(r), r.manager = this, this.touchAction.update(), r;
  }, e.remove = function(r) {
    if (sn(r, "remove", this))
      return this;
    var n = this.get(r);
    if (r) {
      var o = this.recognizers, s = _i(o, n);
      s !== -1 && (o.splice(s, 1), this.touchAction.update());
    }
    return this;
  }, e.on = function(r, n) {
    if (r === void 0 || n === void 0)
      return this;
    var o = this.handlers;
    return hr(Do(r), function(s) {
      o[s] = o[s] || [], o[s].push(n);
    }), this;
  }, e.off = function(r, n) {
    if (r === void 0)
      return this;
    var o = this.handlers;
    return hr(Do(r), function(s) {
      n ? o[s] && o[s].splice(_i(o[s], n), 1) : delete o[s];
    }), this;
  }, e.emit = function(r, n) {
    this.options.domEvents && KQ(r, n);
    var o = this.handlers[r] && this.handlers[r].slice();
    if (!(!o || !o.length)) {
      n.type = r, n.preventDefault = function() {
        n.srcEvent.preventDefault();
      };
      for (var s = 0; s < o.length; )
        o[s](n), s++;
    }
  }, e.destroy = function() {
    this.element && zm(this, !1), this.handlers = {}, this.session = {}, this.input.destroy(), this.element = null;
  }, i;
}(), YQ = {
  touchstart: et,
  touchmove: ki,
  touchend: Ae,
  touchcancel: ut
}, qQ = "touchstart", XQ = "touchstart touchmove touchend touchcancel", JQ = /* @__PURE__ */ function(i) {
  xt(e, i);
  function e() {
    var r, n = e.prototype;
    return n.evTarget = qQ, n.evWin = XQ, r = i.apply(this, arguments) || this, r.started = !1, r;
  }
  var t = e.prototype;
  return t.handler = function(n) {
    var o = YQ[n.type];
    if (o === et && (this.started = !0), !!this.started) {
      var s = ZQ.call(this, n, o);
      o & (Ae | ut) && s[0].length - s[1].length === 0 && (this.started = !1), this.callback(this.manager, o, {
        pointers: s[0],
        changedPointers: s[1],
        pointerType: Is,
        srcEvent: n
      });
    }
  }, e;
}(qn);
function ZQ(i, e) {
  var t = ko(i.touches), r = ko(i.changedTouches);
  return e & (Ae | ut) && (t = Ff(t.concat(r), "identifier", !0)), [t, r];
}
function AE(i, e, t) {
  var r = "DEPRECATED METHOD: " + e + `
` + t + ` AT 
`;
  return function() {
    var n = new Error("get-stack-trace"), o = n && n.stack ? n.stack.replace(/^[^\(]+?[\n$]/gm, "").replace(/^\s+at\s+/gm, "").replace(/^Object.<anonymous>\s*\(/gm, "{anonymous}()@") : "Unknown Stack Trace", s = window.console && (window.console.warn || window.console.log);
    return s && s.call(window.console, r, o), i.apply(this, arguments);
  };
}
var ME = AE(function(i, e, t) {
  for (var r = Object.keys(e), n = 0; n < r.length; )
    (!t || t && i[r[n]] === void 0) && (i[r[n]] = e[r[n]]), n++;
  return i;
}, "extend", "Use `assign`."), QQ = AE(function(i, e) {
  return ME(i, e, !0);
}, "merge", "Use `assign`.");
function eee(i, e, t) {
  var r = e.prototype, n;
  n = i.prototype = Object.create(r), n.constructor = i, n._super = r, t && $i(n, t);
}
function Hm(i, e) {
  return function() {
    return i.apply(e, arguments);
  };
}
var DE = /* @__PURE__ */ function() {
  var i = (
    /**
      * @private
      * @const {string}
      */
    function(t, r) {
      return r === void 0 && (r = {}), new Wm(t, Ft({
        recognizers: Lm.concat()
      }, r));
    }
  );
  return i.VERSION = "2.0.17-rc", i.DIRECTION_ALL = pE, i.DIRECTION_DOWN = En, i.DIRECTION_LEFT = Ps, i.DIRECTION_RIGHT = xs, i.DIRECTION_UP = Cs, i.DIRECTION_HORIZONTAL = Xt, i.DIRECTION_VERTICAL = vi, i.DIRECTION_NONE = el, i.DIRECTION_DOWN = En, i.INPUT_START = et, i.INPUT_MOVE = ki, i.INPUT_END = Ae, i.INPUT_CANCEL = ut, i.STATE_POSSIBLE = Ca, i.STATE_BEGAN = Tt, i.STATE_CHANGED = Sn, i.STATE_ENDED = Nr, i.STATE_RECOGNIZED = cr, i.STATE_CANCELLED = No, i.STATE_FAILED = Kt, i.Manager = Wm, i.Input = qn, i.TouchAction = yE, i.TouchInput = Bf, i.MouseInput = Lf, i.PointerEventInput = EE, i.TouchMouseInput = SE, i.SingleTouchInput = JQ, i.Recognizer = As, i.AttrRecognizer = On, i.Tap = wu, i.Pan = jf, i.Swipe = TE, i.Pinch = IE, i.Rotate = PE, i.Press = xE, i.on = vo, i.off = po, i.each = hr, i.merge = QQ, i.extend = ME, i.bindFn = Hm, i.assign = $i, i.inherit = eee, i.bindFn = Hm, i.prefixed = rd, i.toArray = ko, i.inArray = _i, i.uniqueArray = Ff, i.splitStr = Do, i.boolOrFn = id, i.hasParent = Rf, i.addEventListeners = vo, i.removeEventListeners = po, i.defaults = $i({}, CE, {
    preset: Lm
  }), i;
}();
DE.defaults;
var tee = DE;
dY("DELETE");
function nd() {
  for (var i = arguments.length, e = new Array(i), t = 0; t < i; t++)
    e[t] = arguments[t];
  return ree(e.length ? e : [Qa()]);
}
function ree(i) {
  let [e, t, r] = iee(i), n = 1;
  const o = () => {
    const s = 2091639 * e + n * 23283064365386963e-26;
    return e = t, t = r, r = s - (n = s | 0);
  };
  return o.uint32 = () => o() * 4294967296, o.fract53 = () => o() + (o() * 2097152 | 0) * 11102230246251565e-32, o.algorithm = "Alea", o.seed = i, o.version = "0.9", o;
}
function iee() {
  const i = nee();
  let e = i(" "), t = i(" "), r = i(" ");
  for (let n = 0; n < arguments.length; n++)
    e -= i(n < 0 || arguments.length <= n ? void 0 : arguments[n]), e < 0 && (e += 1), t -= i(n < 0 || arguments.length <= n ? void 0 : arguments[n]), t < 0 && (t += 1), r -= i(n < 0 || arguments.length <= n ? void 0 : arguments[n]), r < 0 && (r += 1);
  return [e, t, r];
}
function nee() {
  let i = 4022871197;
  return function(e) {
    const t = e.toString();
    for (let r = 0; r < t.length; r++) {
      i += t.charCodeAt(r);
      let n = 0.02519603282416938 * i;
      i = n >>> 0, n -= i, n *= i, i = n >>> 0, n -= i, i += n * 4294967296;
    }
    return (i >>> 0) * 23283064365386963e-26;
  };
}
function oee() {
  const i = () => {
  };
  return {
    on: i,
    off: i,
    destroy: i,
    emit: i,
    get() {
      return {
        set: i
      };
    }
  };
}
const zf = typeof window < "u" ? window.Hammer || tee : function() {
  return oee();
};
function Yt(i) {
  var e;
  this._cleanupQueue = [], this.active = !1, this._dom = {
    container: i,
    overlay: document.createElement("div")
  }, this._dom.overlay.classList.add("vis-overlay"), this._dom.container.appendChild(this._dom.overlay), this._cleanupQueue.push(() => {
    this._dom.overlay.parentNode.removeChild(this._dom.overlay);
  });
  const t = zf(this._dom.overlay);
  t.on("tap", S(e = this._onTapOverlay).call(e, this)), this._cleanupQueue.push(() => {
    t.destroy();
  });
  const r = ["tap", "doubletap", "press", "pinch", "pan", "panstart", "panmove", "panend"];
  se(r).call(r, (n) => {
    t.on(n, (o) => {
      o.srcEvent.stopPropagation();
    });
  }), document && document.body && (this._onClick = (n) => {
    see(n.target, i) || this.deactivate();
  }, document.body.addEventListener("click", this._onClick), this._cleanupQueue.push(() => {
    document.body.removeEventListener("click", this._onClick);
  })), this._escListener = (n) => {
    ("key" in n ? n.key === "Escape" : n.keyCode === 27) && this.deactivate();
  };
}
r_(Yt.prototype);
Yt.current = null;
Yt.prototype.destroy = function() {
  this.deactivate();
  for (const t of ci(i = ar(e = this._cleanupQueue).call(e, 0)).call(i)) {
    var i, e;
    t();
  }
};
Yt.prototype.activate = function() {
  Yt.current && Yt.current.deactivate(), Yt.current = this, this.active = !0, this._dom.overlay.style.display = "none", this._dom.container.classList.add("vis-active"), this.emit("change"), this.emit("activate"), document.body.addEventListener("keydown", this._escListener);
};
Yt.prototype.deactivate = function() {
  this.active = !1, this._dom.overlay.style.display = "block", this._dom.container.classList.remove("vis-active"), document.body.removeEventListener("keydown", this._escListener), this.emit("change"), this.emit("deactivate");
};
Yt.prototype._onTapOverlay = function(i) {
  this.activate(), i.srcEvent.stopPropagation();
};
function see(i, e) {
  for (; i; ) {
    if (i === e)
      return !0;
    i = i.parentNode;
  }
  return !1;
}
const aee = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i, lee = /^#?([a-f\d])([a-f\d])([a-f\d])$/i, dee = /^rgb\( *(1?\d{1,2}|2[0-4]\d|25[0-5]) *, *(1?\d{1,2}|2[0-4]\d|25[0-5]) *, *(1?\d{1,2}|2[0-4]\d|25[0-5]) *\)$/i, hee = /^rgba\( *(1?\d{1,2}|2[0-4]\d|25[0-5]) *, *(1?\d{1,2}|2[0-4]\d|25[0-5]) *, *(1?\d{1,2}|2[0-4]\d|25[0-5]) *, *([01]|0?\.\d+) *\)$/i;
function Sr(i) {
  if (i)
    for (; i.hasChildNodes() === !0; ) {
      const e = i.firstChild;
      e && (Sr(e), i.removeChild(e));
    }
}
function ln(i) {
  return i instanceof String || typeof i == "string";
}
function Vm(i) {
  return typeof i == "object" && i !== null;
}
function Ei(i, e, t, r) {
  let n = !1;
  r === !0 && (n = e[t] === null && i[t] !== void 0), n ? delete i[t] : i[t] = e[t];
}
function kE(i, e) {
  let t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !1;
  for (const r in i)
    if (e[r] !== void 0)
      if (e[r] === null || typeof e[r] != "object")
        Ei(i, e, r, t);
      else {
        const n = i[r], o = e[r];
        Vm(n) && Vm(o) && kE(n, o, t);
      }
}
function Xn(i, e, t) {
  let r = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : !1;
  if (be(t))
    throw new TypeError("Arrays are not supported by deepExtend");
  for (let n = 0; n < i.length; n++) {
    const o = i[n];
    if (Object.prototype.hasOwnProperty.call(t, o))
      if (t[o] && t[o].constructor === Object)
        e[o] === void 0 && (e[o] = {}), e[o].constructor === Object ? le(e[o], t[o], !1, r) : Ei(e, t, o, r);
      else {
        if (be(t[o]))
          throw new TypeError("Arrays are not supported by deepExtend");
        Ei(e, t, o, r);
      }
  }
  return e;
}
function il(i, e, t) {
  let r = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : !1;
  if (be(t))
    throw new TypeError("Arrays are not supported by deepExtend");
  for (const n in t)
    if (Object.prototype.hasOwnProperty.call(t, n) && !kr(i).call(i, n))
      if (t[n] && t[n].constructor === Object)
        e[n] === void 0 && (e[n] = {}), e[n].constructor === Object ? le(e[n], t[n]) : Ei(e, t, n, r);
      else if (be(t[n])) {
        e[n] = [];
        for (let o = 0; o < t[n].length; o++)
          e[n].push(t[n][o]);
      } else
        Ei(e, t, n, r);
  return e;
}
function le(i, e) {
  let t = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !1, r = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : !1;
  for (const o in e)
    if (Object.prototype.hasOwnProperty.call(e, o) || t === !0)
      if (typeof e[o] == "object" && e[o] !== null && Sm(e[o]) === Object.prototype)
        i[o] === void 0 ? i[o] = le({}, e[o], t) : typeof i[o] == "object" && i[o] !== null && Sm(i[o]) === Object.prototype ? le(i[o], e[o], t) : Ei(i, e, o, r);
      else if (be(e[o])) {
        var n;
        i[o] = Ut(n = e[o]).call(n);
      } else
        Ei(i, e, o, r);
  return i;
}
function nl(i, e) {
  return [...i, e];
}
function cee(i) {
  return Ut(i).call(i);
}
function uee(i) {
  return i.getBoundingClientRect().left;
}
function fee(i) {
  return i.getBoundingClientRect().top;
}
function X(i, e) {
  if (be(i)) {
    const t = i.length;
    for (let r = 0; r < t; r++)
      e(i[r], r, i);
  } else
    for (const t in i)
      Object.prototype.hasOwnProperty.call(i, t) && e(i[t], t, i);
}
function Wf(i) {
  let e;
  switch (i.length) {
    case 3:
    case 4:
      return e = lee.exec(i), e ? {
        r: Dt(e[1] + e[1], 16),
        g: Dt(e[2] + e[2], 16),
        b: Dt(e[3] + e[3], 16)
      } : null;
    case 6:
    case 7:
      return e = aee.exec(i), e ? {
        r: Dt(e[1], 16),
        g: Dt(e[2], 16),
        b: Dt(e[3], 16)
      } : null;
    default:
      return null;
  }
}
function St(i, e) {
  if (kr(i).call(i, "rgba"))
    return i;
  if (kr(i).call(i, "rgb")) {
    const t = i.substr(re(i).call(i, "(") + 1).replace(")", "").split(",");
    return "rgba(" + t[0] + "," + t[1] + "," + t[2] + "," + e + ")";
  } else {
    const t = Wf(i);
    return t == null ? i : "rgba(" + t.r + "," + t.g + "," + t.b + "," + e + ")";
  }
}
function NE(i, e, t) {
  var r;
  return "#" + Ut(r = ((1 << 24) + (i << 16) + (e << 8) + t).toString(16)).call(r, 1);
}
function _u(i, e) {
  if (ln(i)) {
    let r = i;
    if (FE(r)) {
      var t;
      const n = _n(t = r.substr(4).substr(0, r.length - 5).split(",")).call(t, function(o) {
        return Dt(o);
      });
      r = NE(n[0], n[1], n[2]);
    }
    if (RE(r) === !0) {
      const n = vee(r), o = {
        h: n.h,
        s: n.s * 0.8,
        v: Math.min(1, n.v * 1.02)
      }, s = {
        h: n.h,
        s: Math.min(1, n.s * 1.25),
        v: n.v * 0.8
      }, a = Eu(s.h, s.s, s.v), l = Eu(o.h, o.s, o.v);
      return {
        background: r,
        border: a,
        highlight: {
          background: l,
          border: a
        },
        hover: {
          background: l,
          border: a
        }
      };
    } else
      return {
        background: r,
        border: r,
        highlight: {
          background: r,
          border: r
        },
        hover: {
          background: r,
          border: r
        }
      };
  } else
    return {
      background: i.background || void 0,
      border: i.border || void 0,
      highlight: ln(i.highlight) ? {
        border: i.highlight,
        background: i.highlight
      } : {
        background: i.highlight && i.highlight.background || void 0,
        border: i.highlight && i.highlight.border || void 0
      },
      hover: ln(i.hover) ? {
        border: i.hover,
        background: i.hover
      } : {
        border: i.hover && i.hover.border || void 0,
        background: i.hover && i.hover.background || void 0
      }
    };
}
function so(i, e, t) {
  i = i / 255, e = e / 255, t = t / 255;
  const r = Math.min(i, Math.min(e, t)), n = Math.max(i, Math.max(e, t));
  if (r === n)
    return {
      h: 0,
      s: 0,
      v: r
    };
  const o = i === r ? e - t : t === r ? i - e : t - i, a = 60 * ((i === r ? 3 : t === r ? 1 : 5) - o / (n - r)) / 360, l = (n - r) / n;
  return {
    h: a,
    s: l,
    v: n
  };
}
function Aa(i, e, t) {
  let r, n, o;
  const s = Math.floor(i * 6), a = i * 6 - s, l = t * (1 - e), d = t * (1 - a * e), h = t * (1 - (1 - a) * e);
  switch (s % 6) {
    case 0:
      r = t, n = h, o = l;
      break;
    case 1:
      r = d, n = t, o = l;
      break;
    case 2:
      r = l, n = t, o = h;
      break;
    case 3:
      r = l, n = d, o = t;
      break;
    case 4:
      r = h, n = l, o = t;
      break;
    case 5:
      r = t, n = l, o = d;
      break;
  }
  return {
    r: Math.floor(r * 255),
    g: Math.floor(n * 255),
    b: Math.floor(o * 255)
  };
}
function Eu(i, e, t) {
  const r = Aa(i, e, t);
  return NE(r.r, r.g, r.b);
}
function vee(i) {
  const e = Wf(i);
  if (!e)
    throw new TypeError("'".concat(i, "' is not a valid color."));
  return so(e.r, e.g, e.b);
}
function RE(i) {
  return /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(i);
}
function FE(i) {
  return dee.test(i);
}
function pee(i) {
  return hee.test(i);
}
function Rr(i) {
  if (i === null || typeof i != "object")
    return null;
  if (i instanceof Element)
    return i;
  const e = ui(i);
  for (const t in i)
    Object.prototype.hasOwnProperty.call(i, t) && typeof i[t] == "object" && (e[t] = Rr(i[t]));
  return e;
}
function Et(i, e, t) {
  let r = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : {};
  const n = function(f) {
    return f != null;
  }, o = function(f) {
    return f !== null && typeof f == "object";
  }, s = function(f) {
    for (const v in f)
      if (Object.prototype.hasOwnProperty.call(f, v))
        return !1;
    return !0;
  };
  if (!o(i))
    throw new Error("Parameter mergeTarget must be an object");
  if (!o(e))
    throw new Error("Parameter options must be an object");
  if (!n(t))
    throw new Error("Parameter option must have a value");
  if (!o(r))
    throw new Error("Parameter globalOptions must be an object");
  const a = function(f, v, y) {
    o(f[y]) || (f[y] = {});
    const g = v[y], p = f[y];
    for (const m in g)
      Object.prototype.hasOwnProperty.call(g, m) && (p[m] = g[m]);
  }, l = e[t], h = o(r) && !s(r) ? r[t] : void 0, c = h ? h.enabled : void 0;
  if (l === void 0)
    return;
  if (typeof l == "boolean") {
    o(i[t]) || (i[t] = {}), i[t].enabled = l;
    return;
  }
  if (l === null && !o(i[t]))
    if (n(h))
      i[t] = ui(h);
    else
      return;
  if (!o(l))
    return;
  let u = !0;
  l.enabled !== void 0 ? u = l.enabled : c !== void 0 && (u = h.enabled), a(i, e, t), i[t].enabled = u;
}
const gee = {
  /**
   * Provides no easing and no acceleration.
   *
   * @param t - Time.
   * @returns Value at time t.
   */
  linear(i) {
    return i;
  },
  /**
   * Accelerate from zero velocity.
   *
   * @param t - Time.
   * @returns Value at time t.
   */
  easeInQuad(i) {
    return i * i;
  },
  /**
   * Decelerate to zero velocity.
   *
   * @param t - Time.
   * @returns Value at time t.
   */
  easeOutQuad(i) {
    return i * (2 - i);
  },
  /**
   * Accelerate until halfway, then decelerate.
   *
   * @param t - Time.
   * @returns Value at time t.
   */
  easeInOutQuad(i) {
    return i < 0.5 ? 2 * i * i : -1 + (4 - 2 * i) * i;
  },
  /**
   * Accelerate from zero velocity.
   *
   * @param t - Time.
   * @returns Value at time t.
   */
  easeInCubic(i) {
    return i * i * i;
  },
  /**
   * Decelerate to zero velocity.
   *
   * @param t - Time.
   * @returns Value at time t.
   */
  easeOutCubic(i) {
    return --i * i * i + 1;
  },
  /**
   * Accelerate until halfway, then decelerate.
   *
   * @param t - Time.
   * @returns Value at time t.
   */
  easeInOutCubic(i) {
    return i < 0.5 ? 4 * i * i * i : (i - 1) * (2 * i - 2) * (2 * i - 2) + 1;
  },
  /**
   * Accelerate from zero velocity.
   *
   * @param t - Time.
   * @returns Value at time t.
   */
  easeInQuart(i) {
    return i * i * i * i;
  },
  /**
   * Decelerate to zero velocity.
   *
   * @param t - Time.
   * @returns Value at time t.
   */
  easeOutQuart(i) {
    return 1 - --i * i * i * i;
  },
  /**
   * Accelerate until halfway, then decelerate.
   *
   * @param t - Time.
   * @returns Value at time t.
   */
  easeInOutQuart(i) {
    return i < 0.5 ? 8 * i * i * i * i : 1 - 8 * --i * i * i * i;
  },
  /**
   * Accelerate from zero velocity.
   *
   * @param t - Time.
   * @returns Value at time t.
   */
  easeInQuint(i) {
    return i * i * i * i * i;
  },
  /**
   * Decelerate to zero velocity.
   *
   * @param t - Time.
   * @returns Value at time t.
   */
  easeOutQuint(i) {
    return 1 + --i * i * i * i * i;
  },
  /**
   * Accelerate until halfway, then decelerate.
   *
   * @param t - Time.
   * @returns Value at time t.
   */
  easeInOutQuint(i) {
    return i < 0.5 ? 16 * i * i * i * i * i : 1 + 16 * --i * i * i * i * i;
  }
};
function Or(i, e) {
  let t;
  be(e) || (e = [e]);
  for (const r of i)
    if (r) {
      t = r[e[0]];
      for (let n = 1; n < e.length; n++)
        t && (t = t[e[n]]);
      if (typeof t < "u")
        break;
    }
  return t;
}
const yee = {
  black: "#000000",
  navy: "#000080",
  darkblue: "#00008B",
  mediumblue: "#0000CD",
  blue: "#0000FF",
  darkgreen: "#006400",
  green: "#008000",
  teal: "#008080",
  darkcyan: "#008B8B",
  deepskyblue: "#00BFFF",
  darkturquoise: "#00CED1",
  mediumspringgreen: "#00FA9A",
  lime: "#00FF00",
  springgreen: "#00FF7F",
  aqua: "#00FFFF",
  cyan: "#00FFFF",
  midnightblue: "#191970",
  dodgerblue: "#1E90FF",
  lightseagreen: "#20B2AA",
  forestgreen: "#228B22",
  seagreen: "#2E8B57",
  darkslategray: "#2F4F4F",
  limegreen: "#32CD32",
  mediumseagreen: "#3CB371",
  turquoise: "#40E0D0",
  royalblue: "#4169E1",
  steelblue: "#4682B4",
  darkslateblue: "#483D8B",
  mediumturquoise: "#48D1CC",
  indigo: "#4B0082",
  darkolivegreen: "#556B2F",
  cadetblue: "#5F9EA0",
  cornflowerblue: "#6495ED",
  mediumaquamarine: "#66CDAA",
  dimgray: "#696969",
  slateblue: "#6A5ACD",
  olivedrab: "#6B8E23",
  slategray: "#708090",
  lightslategray: "#778899",
  mediumslateblue: "#7B68EE",
  lawngreen: "#7CFC00",
  chartreuse: "#7FFF00",
  aquamarine: "#7FFFD4",
  maroon: "#800000",
  purple: "#800080",
  olive: "#808000",
  gray: "#808080",
  skyblue: "#87CEEB",
  lightskyblue: "#87CEFA",
  blueviolet: "#8A2BE2",
  darkred: "#8B0000",
  darkmagenta: "#8B008B",
  saddlebrown: "#8B4513",
  darkseagreen: "#8FBC8F",
  lightgreen: "#90EE90",
  mediumpurple: "#9370D8",
  darkviolet: "#9400D3",
  palegreen: "#98FB98",
  darkorchid: "#9932CC",
  yellowgreen: "#9ACD32",
  sienna: "#A0522D",
  brown: "#A52A2A",
  darkgray: "#A9A9A9",
  lightblue: "#ADD8E6",
  greenyellow: "#ADFF2F",
  paleturquoise: "#AFEEEE",
  lightsteelblue: "#B0C4DE",
  powderblue: "#B0E0E6",
  firebrick: "#B22222",
  darkgoldenrod: "#B8860B",
  mediumorchid: "#BA55D3",
  rosybrown: "#BC8F8F",
  darkkhaki: "#BDB76B",
  silver: "#C0C0C0",
  mediumvioletred: "#C71585",
  indianred: "#CD5C5C",
  peru: "#CD853F",
  chocolate: "#D2691E",
  tan: "#D2B48C",
  lightgrey: "#D3D3D3",
  palevioletred: "#D87093",
  thistle: "#D8BFD8",
  orchid: "#DA70D6",
  goldenrod: "#DAA520",
  crimson: "#DC143C",
  gainsboro: "#DCDCDC",
  plum: "#DDA0DD",
  burlywood: "#DEB887",
  lightcyan: "#E0FFFF",
  lavender: "#E6E6FA",
  darksalmon: "#E9967A",
  violet: "#EE82EE",
  palegoldenrod: "#EEE8AA",
  lightcoral: "#F08080",
  khaki: "#F0E68C",
  aliceblue: "#F0F8FF",
  honeydew: "#F0FFF0",
  azure: "#F0FFFF",
  sandybrown: "#F4A460",
  wheat: "#F5DEB3",
  beige: "#F5F5DC",
  whitesmoke: "#F5F5F5",
  mintcream: "#F5FFFA",
  ghostwhite: "#F8F8FF",
  salmon: "#FA8072",
  antiquewhite: "#FAEBD7",
  linen: "#FAF0E6",
  lightgoldenrodyellow: "#FAFAD2",
  oldlace: "#FDF5E6",
  red: "#FF0000",
  fuchsia: "#FF00FF",
  magenta: "#FF00FF",
  deeppink: "#FF1493",
  orangered: "#FF4500",
  tomato: "#FF6347",
  hotpink: "#FF69B4",
  coral: "#FF7F50",
  darkorange: "#FF8C00",
  lightsalmon: "#FFA07A",
  orange: "#FFA500",
  lightpink: "#FFB6C1",
  pink: "#FFC0CB",
  gold: "#FFD700",
  peachpuff: "#FFDAB9",
  navajowhite: "#FFDEAD",
  moccasin: "#FFE4B5",
  bisque: "#FFE4C4",
  mistyrose: "#FFE4E1",
  blanchedalmond: "#FFEBCD",
  papayawhip: "#FFEFD5",
  lavenderblush: "#FFF0F5",
  seashell: "#FFF5EE",
  cornsilk: "#FFF8DC",
  lemonchiffon: "#FFFACD",
  floralwhite: "#FFFAF0",
  snow: "#FFFAFA",
  yellow: "#FFFF00",
  lightyellow: "#FFFFE0",
  ivory: "#FFFFF0",
  white: "#FFFFFF"
};
let mee = class {
  /**
   * @param {number} [pixelRatio=1]
   */
  constructor() {
    let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 1;
    this.pixelRatio = e, this.generated = !1, this.centerCoordinates = {
      x: 289 / 2,
      y: 289 / 2
    }, this.r = 289 * 0.49, this.color = {
      r: 255,
      g: 255,
      b: 255,
      a: 1
    }, this.hueCircle = void 0, this.initialColor = {
      r: 255,
      g: 255,
      b: 255,
      a: 1
    }, this.previousColor = void 0, this.applied = !1, this.updateCallback = () => {
    }, this.closeCallback = () => {
    }, this._create();
  }
  /**
   * this inserts the colorPicker into a div from the DOM
   *
   * @param {Element} container
   */
  insertTo(e) {
    this.hammer !== void 0 && (this.hammer.destroy(), this.hammer = void 0), this.container = e, this.container.appendChild(this.frame), this._bindHammer(), this._setSize();
  }
  /**
   * the callback is executed on apply and save. Bind it to the application
   *
   * @param {Function} callback
   */
  setUpdateCallback(e) {
    if (typeof e == "function")
      this.updateCallback = e;
    else
      throw new Error("Function attempted to set as colorPicker update callback is not a function.");
  }
  /**
   * the callback is executed on apply and save. Bind it to the application
   *
   * @param {Function} callback
   */
  setCloseCallback(e) {
    if (typeof e == "function")
      this.closeCallback = e;
    else
      throw new Error("Function attempted to set as colorPicker closing callback is not a function.");
  }
  /**
   *
   * @param {string} color
   * @returns {string}
   * @private
   */
  _isColorString(e) {
    if (typeof e == "string")
      return yee[e];
  }
  /**
   * Set the color of the colorPicker
   * Supported formats:
   * 'red'                   --> HTML color string
   * '#ffffff'               --> hex string
   * 'rgb(255,255,255)'      --> rgb string
   * 'rgba(255,255,255,1.0)' --> rgba string
   * {r:255,g:255,b:255}     --> rgb object
   * {r:255,g:255,b:255,a:1.0} --> rgba object
   *
   * @param {string | object} color
   * @param {boolean} [setInitial=true]
   */
  setColor(e) {
    let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !0;
    if (e === "none")
      return;
    let r;
    const n = this._isColorString(e);
    if (n !== void 0 && (e = n), ln(e) === !0) {
      if (FE(e) === !0) {
        const o = e.substr(4).substr(0, e.length - 5).split(",");
        r = {
          r: o[0],
          g: o[1],
          b: o[2],
          a: 1
        };
      } else if (pee(e) === !0) {
        const o = e.substr(5).substr(0, e.length - 6).split(",");
        r = {
          r: o[0],
          g: o[1],
          b: o[2],
          a: o[3]
        };
      } else if (RE(e) === !0) {
        const o = Wf(e);
        r = {
          r: o.r,
          g: o.g,
          b: o.b,
          a: 1
        };
      }
    } else if (e instanceof Object && e.r !== void 0 && e.g !== void 0 && e.b !== void 0) {
      const o = e.a !== void 0 ? e.a : "1.0";
      r = {
        r: e.r,
        g: e.g,
        b: e.b,
        a: o
      };
    }
    if (r === void 0)
      throw new Error("Unknown color passed to the colorPicker. Supported are strings: rgb, hex, rgba. Object: rgb ({r:r,g:g,b:b,[a:a]}). Supplied: " + Os(e));
    this._setColor(r, t);
  }
  /**
   * this shows the color picker.
   * The hue circle is constructed once and stored.
   */
  show() {
    this.closeCallback !== void 0 && (this.closeCallback(), this.closeCallback = void 0), this.applied = !1, this.frame.style.display = "block", this._generateHueCircle();
  }
  // ------------------------------------------ PRIVATE ----------------------------- //
  /**
   * Hide the picker. Is called by the cancel button.
   * Optional boolean to store the previous color for easy access later on.
   *
   * @param {boolean} [storePrevious=true]
   * @private
   */
  _hide() {
    (arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !0) === !0 && (this.previousColor = Ce({}, this.color)), this.applied === !0 && this.updateCallback(this.initialColor), this.frame.style.display = "none", lr(() => {
      this.closeCallback !== void 0 && (this.closeCallback(), this.closeCallback = void 0);
    }, 0);
  }
  /**
   * bound to the save button. Saves and hides.
   *
   * @private
   */
  _save() {
    this.updateCallback(this.color), this.applied = !1, this._hide();
  }
  /**
   * Bound to apply button. Saves but does not close. Is undone by the cancel button.
   *
   * @private
   */
  _apply() {
    this.applied = !0, this.updateCallback(this.color), this._updatePicker(this.color);
  }
  /**
   * load the color from the previous session.
   *
   * @private
   */
  _loadLast() {
    this.previousColor !== void 0 ? this.setColor(this.previousColor, !1) : alert("There is no last color to load...");
  }
  /**
   * set the color, place the picker
   *
   * @param {object} rgba
   * @param {boolean} [setInitial=true]
   * @private
   */
  _setColor(e) {
    (arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !0) === !0 && (this.initialColor = Ce({}, e)), this.color = e;
    const r = so(e.r, e.g, e.b), n = 2 * Math.PI, o = this.r * r.s, s = this.centerCoordinates.x + o * Math.sin(n * r.h), a = this.centerCoordinates.y + o * Math.cos(n * r.h);
    this.colorPickerSelector.style.left = s - 0.5 * this.colorPickerSelector.clientWidth + "px", this.colorPickerSelector.style.top = a - 0.5 * this.colorPickerSelector.clientHeight + "px", this._updatePicker(e);
  }
  /**
   * bound to opacity control
   *
   * @param {number} value
   * @private
   */
  _setOpacity(e) {
    this.color.a = e / 100, this._updatePicker(this.color);
  }
  /**
   * bound to brightness control
   *
   * @param {number} value
   * @private
   */
  _setBrightness(e) {
    const t = so(this.color.r, this.color.g, this.color.b);
    t.v = e / 100;
    const r = Aa(t.h, t.s, t.v);
    r.a = this.color.a, this.color = r, this._updatePicker();
  }
  /**
   * update the color picker. A black circle overlays the hue circle to mimic the brightness decreasing.
   *
   * @param {object} rgba
   * @private
   */
  _updatePicker() {
    let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : this.color;
    const t = so(e.r, e.g, e.b), r = this.colorPickerCanvas.getContext("2d");
    this.pixelRation === void 0 && (this.pixelRatio = (window.devicePixelRatio || 1) / (r.webkitBackingStorePixelRatio || r.mozBackingStorePixelRatio || r.msBackingStorePixelRatio || r.oBackingStorePixelRatio || r.backingStorePixelRatio || 1)), r.setTransform(this.pixelRatio, 0, 0, this.pixelRatio, 0, 0);
    const n = this.colorPickerCanvas.clientWidth, o = this.colorPickerCanvas.clientHeight;
    r.clearRect(0, 0, n, o), r.putImageData(this.hueCircle, 0, 0), r.fillStyle = "rgba(0,0,0," + (1 - t.v) + ")", r.circle(this.centerCoordinates.x, this.centerCoordinates.y, this.r), Ts(r).call(r), this.brightnessRange.value = 100 * t.v, this.opacityRange.value = 100 * e.a, this.initialColorDiv.style.backgroundColor = "rgba(" + this.initialColor.r + "," + this.initialColor.g + "," + this.initialColor.b + "," + this.initialColor.a + ")", this.newColorDiv.style.backgroundColor = "rgba(" + this.color.r + "," + this.color.g + "," + this.color.b + "," + this.color.a + ")";
  }
  /**
   * used by create to set the size of the canvas.
   *
   * @private
   */
  _setSize() {
    this.colorPickerCanvas.style.width = "100%", this.colorPickerCanvas.style.height = "100%", this.colorPickerCanvas.width = 289 * this.pixelRatio, this.colorPickerCanvas.height = 289 * this.pixelRatio;
  }
  /**
   * create all dom elements
   * TODO: cleanup, lots of similar dom elements
   *
   * @private
   */
  _create() {
    var e, t, r, n;
    if (this.frame = document.createElement("div"), this.frame.className = "vis-color-picker", this.colorPickerDiv = document.createElement("div"), this.colorPickerSelector = document.createElement("div"), this.colorPickerSelector.className = "vis-selector", this.colorPickerDiv.appendChild(this.colorPickerSelector), this.colorPickerCanvas = document.createElement("canvas"), this.colorPickerDiv.appendChild(this.colorPickerCanvas), this.colorPickerCanvas.getContext) {
      const s = this.colorPickerCanvas.getContext("2d");
      this.pixelRatio = (window.devicePixelRatio || 1) / (s.webkitBackingStorePixelRatio || s.mozBackingStorePixelRatio || s.msBackingStorePixelRatio || s.oBackingStorePixelRatio || s.backingStorePixelRatio || 1), this.colorPickerCanvas.getContext("2d").setTransform(this.pixelRatio, 0, 0, this.pixelRatio, 0, 0);
    } else {
      const s = document.createElement("DIV");
      s.style.color = "red", s.style.fontWeight = "bold", s.style.padding = "10px", s.innerText = "Error: your browser does not support HTML canvas", this.colorPickerCanvas.appendChild(s);
    }
    this.colorPickerDiv.className = "vis-color", this.opacityDiv = document.createElement("div"), this.opacityDiv.className = "vis-opacity", this.brightnessDiv = document.createElement("div"), this.brightnessDiv.className = "vis-brightness", this.arrowDiv = document.createElement("div"), this.arrowDiv.className = "vis-arrow", this.opacityRange = document.createElement("input");
    try {
      this.opacityRange.type = "range", this.opacityRange.min = "0", this.opacityRange.max = "100";
    } catch {
    }
    this.opacityRange.value = "100", this.opacityRange.className = "vis-range", this.brightnessRange = document.createElement("input");
    try {
      this.brightnessRange.type = "range", this.brightnessRange.min = "0", this.brightnessRange.max = "100";
    } catch {
    }
    this.brightnessRange.value = "100", this.brightnessRange.className = "vis-range", this.opacityDiv.appendChild(this.opacityRange), this.brightnessDiv.appendChild(this.brightnessRange);
    const o = this;
    this.opacityRange.onchange = function() {
      o._setOpacity(this.value);
    }, this.opacityRange.oninput = function() {
      o._setOpacity(this.value);
    }, this.brightnessRange.onchange = function() {
      o._setBrightness(this.value);
    }, this.brightnessRange.oninput = function() {
      o._setBrightness(this.value);
    }, this.brightnessLabel = document.createElement("div"), this.brightnessLabel.className = "vis-label vis-brightness", this.brightnessLabel.innerText = "brightness:", this.opacityLabel = document.createElement("div"), this.opacityLabel.className = "vis-label vis-opacity", this.opacityLabel.innerText = "opacity:", this.newColorDiv = document.createElement("div"), this.newColorDiv.className = "vis-new-color", this.newColorDiv.innerText = "new", this.initialColorDiv = document.createElement("div"), this.initialColorDiv.className = "vis-initial-color", this.initialColorDiv.innerText = "initial", this.cancelButton = document.createElement("div"), this.cancelButton.className = "vis-button vis-cancel", this.cancelButton.innerText = "cancel", this.cancelButton.onclick = S(e = this._hide).call(e, this, !1), this.applyButton = document.createElement("div"), this.applyButton.className = "vis-button vis-apply", this.applyButton.innerText = "apply", this.applyButton.onclick = S(t = this._apply).call(t, this), this.saveButton = document.createElement("div"), this.saveButton.className = "vis-button vis-save", this.saveButton.innerText = "save", this.saveButton.onclick = S(r = this._save).call(r, this), this.loadButton = document.createElement("div"), this.loadButton.className = "vis-button vis-load", this.loadButton.innerText = "load last", this.loadButton.onclick = S(n = this._loadLast).call(n, this), this.frame.appendChild(this.colorPickerDiv), this.frame.appendChild(this.arrowDiv), this.frame.appendChild(this.brightnessLabel), this.frame.appendChild(this.brightnessDiv), this.frame.appendChild(this.opacityLabel), this.frame.appendChild(this.opacityDiv), this.frame.appendChild(this.newColorDiv), this.frame.appendChild(this.initialColorDiv), this.frame.appendChild(this.cancelButton), this.frame.appendChild(this.applyButton), this.frame.appendChild(this.saveButton), this.frame.appendChild(this.loadButton);
  }
  /**
   * bind hammer to the color picker
   *
   * @private
   */
  _bindHammer() {
    this.drag = {}, this.pinch = {}, this.hammer = new zf(this.colorPickerCanvas), this.hammer.get("pinch").set({
      enable: !0
    }), this.hammer.on("hammer.input", (e) => {
      e.isFirst && this._moveSelector(e);
    }), this.hammer.on("tap", (e) => {
      this._moveSelector(e);
    }), this.hammer.on("panstart", (e) => {
      this._moveSelector(e);
    }), this.hammer.on("panmove", (e) => {
      this._moveSelector(e);
    }), this.hammer.on("panend", (e) => {
      this._moveSelector(e);
    });
  }
  /**
   * generate the hue circle. This is relatively heavy (200ms) and is done only once on the first time it is shown.
   *
   * @private
   */
  _generateHueCircle() {
    if (this.generated === !1) {
      const e = this.colorPickerCanvas.getContext("2d");
      this.pixelRation === void 0 && (this.pixelRatio = (window.devicePixelRatio || 1) / (e.webkitBackingStorePixelRatio || e.mozBackingStorePixelRatio || e.msBackingStorePixelRatio || e.oBackingStorePixelRatio || e.backingStorePixelRatio || 1)), e.setTransform(this.pixelRatio, 0, 0, this.pixelRatio, 0, 0);
      const t = this.colorPickerCanvas.clientWidth, r = this.colorPickerCanvas.clientHeight;
      e.clearRect(0, 0, t, r);
      let n, o, s, a;
      this.centerCoordinates = {
        x: t * 0.5,
        y: r * 0.5
      }, this.r = 0.49 * t;
      const l = 2 * Math.PI / 360, d = 1 / 360, h = 1 / this.r;
      let c;
      for (s = 0; s < 360; s++)
        for (a = 0; a < this.r; a++)
          n = this.centerCoordinates.x + a * Math.sin(l * s), o = this.centerCoordinates.y + a * Math.cos(l * s), c = Aa(s * d, a * h, 1), e.fillStyle = "rgb(" + c.r + "," + c.g + "," + c.b + ")", e.fillRect(n - 0.5, o - 0.5, 2, 2);
      e.strokeStyle = "rgba(0,0,0,1)", e.circle(this.centerCoordinates.x, this.centerCoordinates.y, this.r), e.stroke(), this.hueCircle = e.getImageData(0, 0, t, r);
    }
    this.generated = !0;
  }
  /**
   * move the selector. This is called by hammer functions.
   *
   * @param {Event}  event   The event
   * @private
   */
  _moveSelector(e) {
    const t = this.colorPickerDiv.getBoundingClientRect(), r = e.center.x - t.left, n = e.center.y - t.top, o = 0.5 * this.colorPickerDiv.clientHeight, s = 0.5 * this.colorPickerDiv.clientWidth, a = r - s, l = n - o, d = Math.atan2(a, l), h = 0.98 * Math.min(Math.sqrt(a * a + l * l), s), c = Math.cos(d) * h + o, u = Math.sin(d) * h + s;
    this.colorPickerSelector.style.top = c - 0.5 * this.colorPickerSelector.clientHeight + "px", this.colorPickerSelector.style.left = u - 0.5 * this.colorPickerSelector.clientWidth + "px";
    let f = d / (2 * Math.PI);
    f = f < 0 ? f + 1 : f;
    const v = h / this.r, y = so(this.color.r, this.color.g, this.color.b);
    y.h = f, y.s = v;
    const g = Aa(y.h, y.s, y.v);
    g.a = this.color.a, this.color = g, this.initialColorDiv.style.backgroundColor = "rgba(" + this.initialColor.r + "," + this.initialColor.g + "," + this.initialColor.b + "," + this.initialColor.a + ")", this.newColorDiv.style.backgroundColor = "rgba(" + this.color.r + "," + this.color.g + "," + this.color.b + "," + this.color.a + ")";
  }
};
function Su() {
  for (var i = arguments.length, e = new Array(i), t = 0; t < i; t++)
    e[t] = arguments[t];
  if (e.length < 1)
    throw new TypeError("Invalid arguments.");
  if (e.length === 1)
    return document.createTextNode(e[0]);
  {
    const r = document.createElement(e[0]);
    return r.appendChild(Su(...Ut(e).call(e, 1))), r;
  }
}
let bee = class {
  /**
   * @param {object} parentModule        | the location where parentModule.setOptions() can be called
   * @param {object} defaultContainer    | the default container of the module
   * @param {object} configureOptions    | the fully configured and predefined options set found in allOptions.js
   * @param {number} pixelRatio          | canvas pixel ratio
   * @param {Function} hideOption        | custom logic to dynamically hide options
   */
  constructor(e, t, r) {
    let n = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : 1, o = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : () => !1;
    this.parent = e, this.changedOptions = [], this.container = t, this.allowCreation = !1, this.hideOption = o, this.options = {}, this.initialized = !1, this.popupCounter = 0, this.defaultOptions = {
      enabled: !1,
      filter: !0,
      container: void 0,
      showButton: !0
    }, Ce(this.options, this.defaultOptions), this.configureOptions = r, this.moduleOptions = {}, this.domElements = [], this.popupDiv = {}, this.popupLimit = 5, this.popupHistory = {}, this.colorPicker = new mee(n), this.wrapper = void 0;
  }
  /**
   * refresh all options.
   * Because all modules parse their options by themselves, we just use their options. We copy them here.
   *
   * @param {object} options
   */
  setOptions(e) {
    if (e !== void 0) {
      this.popupHistory = {}, this._removePopup();
      let t = !0;
      if (typeof e == "string")
        this.options.filter = e;
      else if (be(e))
        this.options.filter = e.join();
      else if (typeof e == "object") {
        if (e == null)
          throw new TypeError("options cannot be null");
        e.container !== void 0 && (this.options.container = e.container), ht(e) !== void 0 && (this.options.filter = ht(e)), e.showButton !== void 0 && (this.options.showButton = e.showButton), e.enabled !== void 0 && (t = e.enabled);
      } else typeof e == "boolean" ? (this.options.filter = !0, t = e) : typeof e == "function" && (this.options.filter = e, t = !0);
      ht(this.options) === !1 && (t = !1), this.options.enabled = t;
    }
    this._clean();
  }
  /**
   *
   * @param {object} moduleOptions
   */
  setModuleOptions(e) {
    this.moduleOptions = e, this.options.enabled === !0 && (this._clean(), this.options.container !== void 0 && (this.container = this.options.container), this._create());
  }
  /**
   * Create all DOM elements
   *
   * @private
   */
  _create() {
    this._clean(), this.changedOptions = [];
    const e = ht(this.options);
    let t = 0, r = !1;
    for (const n in this.configureOptions)
      Object.prototype.hasOwnProperty.call(this.configureOptions, n) && (this.allowCreation = !1, r = !1, typeof e == "function" ? (r = e(n, []), r = r || this._handleObject(this.configureOptions[n], [n], !0)) : (e === !0 || re(e).call(e, n) !== -1) && (r = !0), r !== !1 && (this.allowCreation = !0, t > 0 && this._makeItem([]), this._makeHeader(n), this._handleObject(this.configureOptions[n], [n])), t++);
    this._makeButton(), this._push();
  }
  /**
   * draw all DOM elements on the screen
   *
   * @private
   */
  _push() {
    this.wrapper = document.createElement("div"), this.wrapper.className = "vis-configuration-wrapper", this.container.appendChild(this.wrapper);
    for (let e = 0; e < this.domElements.length; e++)
      this.wrapper.appendChild(this.domElements[e]);
    this._showPopupIfNeeded();
  }
  /**
   * delete all DOM elements
   *
   * @private
   */
  _clean() {
    for (let e = 0; e < this.domElements.length; e++)
      this.wrapper.removeChild(this.domElements[e]);
    this.wrapper !== void 0 && (this.container.removeChild(this.wrapper), this.wrapper = void 0), this.domElements = [], this._removePopup();
  }
  /**
   * get the value from the actualOptions if it exists
   *
   * @param {Array} path    | where to look for the actual option
   * @returns {*}
   * @private
   */
  _getValue(e) {
    let t = this.moduleOptions;
    for (let r = 0; r < e.length; r++)
      if (t[e[r]] !== void 0)
        t = t[e[r]];
      else {
        t = void 0;
        break;
      }
    return t;
  }
  /**
   * all option elements are wrapped in an item
   *
   * @param {Array} path    | where to look for the actual option
   * @param {Array.<Element>} domElements
   * @returns {number}
   * @private
   */
  _makeItem(e) {
    if (this.allowCreation === !0) {
      const o = document.createElement("div");
      o.className = "vis-configuration vis-config-item vis-config-s" + e.length;
      for (var t = arguments.length, r = new Array(t > 1 ? t - 1 : 0), n = 1; n < t; n++)
        r[n - 1] = arguments[n];
      return se(r).call(r, (s) => {
        o.appendChild(s);
      }), this.domElements.push(o), this.domElements.length;
    }
    return 0;
  }
  /**
   * header for major subjects
   *
   * @param {string} name
   * @private
   */
  _makeHeader(e) {
    const t = document.createElement("div");
    t.className = "vis-configuration vis-config-header", t.innerText = e, this._makeItem([], t);
  }
  /**
   * make a label, if it is an object label, it gets different styling.
   *
   * @param {string} name
   * @param {Array} path    | where to look for the actual option
   * @param {string} objectLabel
   * @returns {HTMLElement}
   * @private
   */
  _makeLabel(e, t) {
    let r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !1;
    const n = document.createElement("div");
    if (n.className = "vis-configuration vis-config-label vis-config-s" + t.length, r === !0) {
      for (; n.firstChild; )
        n.removeChild(n.firstChild);
      n.appendChild(Su("i", "b", e));
    } else
      n.innerText = e + ":";
    return n;
  }
  /**
   * make a dropdown list for multiple possible string optoins
   *
   * @param {Array.<number>} arr
   * @param {number} value
   * @param {Array} path    | where to look for the actual option
   * @private
   */
  _makeDropdown(e, t, r) {
    const n = document.createElement("select");
    n.className = "vis-configuration vis-config-select";
    let o = 0;
    t !== void 0 && re(e).call(e, t) !== -1 && (o = re(e).call(e, t));
    for (let l = 0; l < e.length; l++) {
      const d = document.createElement("option");
      d.value = e[l], l === o && (d.selected = "selected"), d.innerText = e[l], n.appendChild(d);
    }
    const s = this;
    n.onchange = function() {
      s._update(this.value, r);
    };
    const a = this._makeLabel(r[r.length - 1], r);
    this._makeItem(r, a, n);
  }
  /**
   * make a range object for numeric options
   *
   * @param {Array.<number>} arr
   * @param {number} value
   * @param {Array} path    | where to look for the actual option
   * @private
   */
  _makeRange(e, t, r) {
    const n = e[0], o = e[1], s = e[2], a = e[3], l = document.createElement("input");
    l.className = "vis-configuration vis-config-range";
    try {
      l.type = "range", l.min = o, l.max = s;
    } catch {
    }
    l.step = a;
    let d = "", h = 0;
    t !== void 0 ? (t < 0 && t * 1.2 < o ? (l.min = Math.ceil(t * 1.2), h = l.min, d = "range increased") : t / 1.2 < o && (l.min = Math.ceil(t / 1.2), h = l.min, d = "range increased"), t * 1.2 > s && s !== 1 && (l.max = Math.ceil(t * 1.2), h = l.max, d = "range increased"), l.value = t) : l.value = n;
    const c = document.createElement("input");
    c.className = "vis-configuration vis-config-rangeinput", c.value = l.value;
    const u = this;
    l.onchange = function() {
      c.value = this.value, u._update(Number(this.value), r);
    }, l.oninput = function() {
      c.value = this.value;
    };
    const f = this._makeLabel(r[r.length - 1], r), v = this._makeItem(r, f, l, c);
    d !== "" && this.popupHistory[v] !== h && (this.popupHistory[v] = h, this._setupPopup(d, v));
  }
  /**
   * make a button object
   *
   * @private
   */
  _makeButton() {
    if (this.options.showButton === !0) {
      const e = document.createElement("div");
      e.className = "vis-configuration vis-config-button", e.innerText = "generate options", e.onclick = () => {
        this._printOptions();
      }, e.onmouseover = () => {
        e.className = "vis-configuration vis-config-button hover";
      }, e.onmouseout = () => {
        e.className = "vis-configuration vis-config-button";
      }, this.optionsContainer = document.createElement("div"), this.optionsContainer.className = "vis-configuration vis-config-option-container", this.domElements.push(this.optionsContainer), this.domElements.push(e);
    }
  }
  /**
   * prepare the popup
   *
   * @param {string} string
   * @param {number} index
   * @private
   */
  _setupPopup(e, t) {
    if (this.initialized === !0 && this.allowCreation === !0 && this.popupCounter < this.popupLimit) {
      const r = document.createElement("div");
      r.id = "vis-configuration-popup", r.className = "vis-configuration-popup", r.innerText = e, r.onclick = () => {
        this._removePopup();
      }, this.popupCounter += 1, this.popupDiv = {
        html: r,
        index: t
      };
    }
  }
  /**
   * remove the popup from the dom
   *
   * @private
   */
  _removePopup() {
    this.popupDiv.html !== void 0 && (this.popupDiv.html.parentNode.removeChild(this.popupDiv.html), clearTimeout(this.popupDiv.hideTimeout), clearTimeout(this.popupDiv.deleteTimeout), this.popupDiv = {});
  }
  /**
   * Show the popup if it is needed.
   *
   * @private
   */
  _showPopupIfNeeded() {
    if (this.popupDiv.html !== void 0) {
      const t = this.domElements[this.popupDiv.index].getBoundingClientRect();
      this.popupDiv.html.style.left = t.left + "px", this.popupDiv.html.style.top = t.top - 30 + "px", document.body.appendChild(this.popupDiv.html), this.popupDiv.hideTimeout = lr(() => {
        this.popupDiv.html.style.opacity = 0;
      }, 1500), this.popupDiv.deleteTimeout = lr(() => {
        this._removePopup();
      }, 1800);
    }
  }
  /**
   * make a checkbox for boolean options.
   *
   * @param {number} defaultValue
   * @param {number} value
   * @param {Array} path    | where to look for the actual option
   * @private
   */
  _makeCheckbox(e, t, r) {
    const n = document.createElement("input");
    n.type = "checkbox", n.className = "vis-configuration vis-config-checkbox", n.checked = e, t !== void 0 && (n.checked = t, t !== e && (typeof e == "object" ? t !== e.enabled && this.changedOptions.push({
      path: r,
      value: t
    }) : this.changedOptions.push({
      path: r,
      value: t
    })));
    const o = this;
    n.onchange = function() {
      o._update(this.checked, r);
    };
    const s = this._makeLabel(r[r.length - 1], r);
    this._makeItem(r, s, n);
  }
  /**
   * make a text input field for string options.
   *
   * @param {number} defaultValue
   * @param {number} value
   * @param {Array} path    | where to look for the actual option
   * @private
   */
  _makeTextInput(e, t, r) {
    const n = document.createElement("input");
    n.type = "text", n.className = "vis-configuration vis-config-text", n.value = t, t !== e && this.changedOptions.push({
      path: r,
      value: t
    });
    const o = this;
    n.onchange = function() {
      o._update(this.value, r);
    };
    const s = this._makeLabel(r[r.length - 1], r);
    this._makeItem(r, s, n);
  }
  /**
   * make a color field with a color picker for color fields
   *
   * @param {Array.<number>} arr
   * @param {number} value
   * @param {Array} path    | where to look for the actual option
   * @private
   */
  _makeColorField(e, t, r) {
    const n = e[1], o = document.createElement("div");
    t = t === void 0 ? n : t, t !== "none" ? (o.className = "vis-configuration vis-config-colorBlock", o.style.backgroundColor = t) : o.className = "vis-configuration vis-config-colorBlock none", t = t === void 0 ? n : t, o.onclick = () => {
      this._showColorPicker(t, o, r);
    };
    const s = this._makeLabel(r[r.length - 1], r);
    this._makeItem(r, s, o);
  }
  /**
   * used by the color buttons to call the color picker.
   *
   * @param {number} value
   * @param {HTMLElement} div
   * @param {Array} path    | where to look for the actual option
   * @private
   */
  _showColorPicker(e, t, r) {
    t.onclick = function() {
    }, this.colorPicker.insertTo(t), this.colorPicker.show(), this.colorPicker.setColor(e), this.colorPicker.setUpdateCallback((n) => {
      const o = "rgba(" + n.r + "," + n.g + "," + n.b + "," + n.a + ")";
      t.style.backgroundColor = o, this._update(o, r);
    }), this.colorPicker.setCloseCallback(() => {
      t.onclick = () => {
        this._showColorPicker(e, t, r);
      };
    });
  }
  /**
   * parse an object and draw the correct items
   *
   * @param {object} obj
   * @param {Array} [path=[]]    | where to look for the actual option
   * @param {boolean} [checkOnly=false]
   * @returns {boolean}
   * @private
   */
  _handleObject(e) {
    let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : [], r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !1, n = !1;
    const o = ht(this.options);
    let s = !1;
    for (const a in e)
      if (Object.prototype.hasOwnProperty.call(e, a)) {
        n = !0;
        const l = e[a], d = nl(t, a);
        if (typeof o == "function" && (n = o(a, t), n === !1 && !be(l) && typeof l != "string" && typeof l != "boolean" && l instanceof Object && (this.allowCreation = !1, n = this._handleObject(l, d, !0), this.allowCreation = r === !1)), n !== !1) {
          s = !0;
          const h = this._getValue(d);
          if (be(l))
            this._handleArray(l, h, d);
          else if (typeof l == "string")
            this._makeTextInput(l, h, d);
          else if (typeof l == "boolean")
            this._makeCheckbox(l, h, d);
          else if (l instanceof Object) {
            if (!this.hideOption(t, a, this.moduleOptions))
              if (l.enabled !== void 0) {
                const c = nl(d, "enabled"), u = this._getValue(c);
                if (u === !0) {
                  const f = this._makeLabel(a, d, !0);
                  this._makeItem(d, f), s = this._handleObject(l, d) || s;
                } else
                  this._makeCheckbox(l, u, d);
              } else {
                const c = this._makeLabel(a, d, !0);
                this._makeItem(d, c), s = this._handleObject(l, d) || s;
              }
          } else
            console.error("dont know how to handle", l, a, d);
        }
      }
    return s;
  }
  /**
   * handle the array type of option
   *
   * @param {Array.<number>} arr
   * @param {number} value
   * @param {Array} path    | where to look for the actual option
   * @private
   */
  _handleArray(e, t, r) {
    typeof e[0] == "string" && e[0] === "color" ? (this._makeColorField(e, t, r), e[1] !== t && this.changedOptions.push({
      path: r,
      value: t
    })) : typeof e[0] == "string" ? (this._makeDropdown(e, t, r), e[0] !== t && this.changedOptions.push({
      path: r,
      value: t
    })) : typeof e[0] == "number" && (this._makeRange(e, t, r), e[0] !== t && this.changedOptions.push({
      path: r,
      value: Number(t)
    }));
  }
  /**
   * called to update the network with the new settings.
   *
   * @param {number} value
   * @param {Array} path    | where to look for the actual option
   * @private
   */
  _update(e, t) {
    const r = this._constructOptions(e, t);
    this.parent.body && this.parent.body.emitter && this.parent.body.emitter.emit && this.parent.body.emitter.emit("configChange", r), this.initialized = !0, this.parent.setOptions(r);
  }
  /**
   *
   * @param {string | boolean} value
   * @param {Array.<string>} path
   * @param {{}} optionsObj
   * @returns {{}}
   * @private
   */
  _constructOptions(e, t) {
    let r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {}, n = r;
    e = e === "true" ? !0 : e, e = e === "false" ? !1 : e;
    for (let o = 0; o < t.length; o++)
      t[o] !== "global" && (n[t[o]] === void 0 && (n[t[o]] = {}), o !== t.length - 1 ? n = n[t[o]] : n[t[o]] = e);
    return r;
  }
  /**
   * @private
   */
  _printOptions() {
    const e = this.getOptions();
    for (; this.optionsContainer.firstChild; )
      this.optionsContainer.removeChild(this.optionsContainer.firstChild);
    this.optionsContainer.appendChild(Su("pre", "const options = " + Os(e, null, 2)));
  }
  /**
   *
   * @returns {{}} options
   */
  getOptions() {
    const e = {};
    for (let t = 0; t < this.changedOptions.length; t++)
      this._constructOptions(this.changedOptions[t].value, this.changedOptions[t].path, e);
    return e;
  }
}, $ee = class {
  /**
   * @param {Element} container       The container object.
   * @param {string}  overflowMethod  How the popup should act to overflowing ('flip' or 'cap')
   */
  constructor(e, t) {
    this.container = e, this.overflowMethod = t || "cap", this.x = 0, this.y = 0, this.padding = 5, this.hidden = !1, this.frame = document.createElement("div"), this.frame.className = "vis-tooltip", this.container.appendChild(this.frame);
  }
  /**
   * @param {number} x   Horizontal position of the popup window
   * @param {number} y   Vertical position of the popup window
   */
  setPosition(e, t) {
    this.x = Dt(e), this.y = Dt(t);
  }
  /**
   * Set the content for the popup window. This can be HTML code or text.
   *
   * @param {string | Element} content
   */
  setText(e) {
    if (e instanceof Element) {
      for (; this.frame.firstChild; )
        this.frame.removeChild(this.frame.firstChild);
      this.frame.appendChild(e);
    } else
      this.frame.innerText = e;
  }
  /**
   * Show the popup window
   *
   * @param {boolean} [doShow]    Show or hide the window
   */
  show(e) {
    if (e === void 0 && (e = !0), e === !0) {
      const t = this.frame.clientHeight, r = this.frame.clientWidth, n = this.frame.parentNode.clientHeight, o = this.frame.parentNode.clientWidth;
      let s = 0, a = 0;
      if (this.overflowMethod == "flip") {
        let l = !1, d = !0;
        this.y - t < this.padding && (d = !1), this.x + r > o - this.padding && (l = !0), l ? s = this.x - r : s = this.x, d ? a = this.y - t : a = this.y;
      } else
        a = this.y - t, a + t + this.padding > n && (a = n - t - this.padding), a < this.padding && (a = this.padding), s = this.x, s + r + this.padding > o && (s = o - r - this.padding), s < this.padding && (s = this.padding);
      this.frame.style.left = s + "px", this.frame.style.top = a + "px", this.frame.style.visibility = "visible", this.hidden = !1;
    } else
      this.hide();
  }
  /**
   * Hide the popup window
   */
  hide() {
    this.hidden = !0, this.frame.style.left = "0", this.frame.style.top = "0", this.frame.style.visibility = "hidden";
  }
  /**
   * Remove the popup window
   */
  destroy() {
    this.frame.parentNode.removeChild(this.frame);
  }
}, eo = !1, Um;
const Ou = "background: #FFeeee; color: #dd0000";
let wee = class ye {
  /**
   * Main function to be called
   *
   * @param {object} options
   * @param {object} referenceOptions
   * @param {object} subObject
   * @returns {boolean}
   * @static
   */
  static validate(e, t, r) {
    eo = !1, Um = t;
    let n = t;
    return r !== void 0 && (n = t[r]), ye.parse(e, n, []), eo;
  }
  /**
   * Will traverse an object recursively and check every value
   *
   * @param {object} options
   * @param {object} referenceOptions
   * @param {Array} path    | where to look for the actual option
   * @static
   */
  static parse(e, t, r) {
    for (const n in e)
      Object.prototype.hasOwnProperty.call(e, n) && ye.check(n, e, t, r);
  }
  /**
   * Check every value. If the value is an object, call the parse function on that object.
   *
   * @param {string} option
   * @param {object} options
   * @param {object} referenceOptions
   * @param {Array} path    | where to look for the actual option
   * @static
   */
  static check(e, t, r, n) {
    if (r[e] === void 0 && r.__any__ === void 0) {
      ye.getSuggestion(e, r, n);
      return;
    }
    let o = e, s = !0;
    r[e] === void 0 && r.__any__ !== void 0 && (o = "__any__", s = ye.getType(t[e]) === "object");
    let a = r[o];
    s && a.__type__ !== void 0 && (a = a.__type__), ye.checkFields(e, t, r, o, a, n);
  }
  /**
   *
   * @param {string}  option           | the option property
   * @param {object}  options          | The supplied options object
   * @param {object}  referenceOptions | The reference options containing all options and their allowed formats
   * @param {string}  referenceOption  | Usually this is the same as option, except when handling an __any__ tag.
   * @param {string}  refOptionObj     | This is the type object from the reference options
   * @param {Array}   path             | where in the object is the option
   * @static
   */
  static checkFields(e, t, r, n, o, s) {
    const a = function(h) {
      console.error("%c" + h + ye.printLocation(s, e), Ou);
    }, l = ye.getType(t[e]), d = o[l];
    d !== void 0 ? ye.getType(d) === "array" && re(d).call(d, t[e]) === -1 ? (a('Invalid option detected in "' + e + '". Allowed values are:' + ye.print(d) + ' not "' + t[e] + '". '), eo = !0) : l === "object" && n !== "__any__" && (s = nl(s, e), ye.parse(t[e], r[n], s)) : o.any === void 0 && (a('Invalid type received for "' + e + '". Expected: ' + ye.print(me(o)) + ". Received [" + l + '] "' + t[e] + '"'), eo = !0);
  }
  /**
   *
   * @param {object | boolean | number | string | Array.<number> | Date | Node | Moment | undefined | null} object
   * @returns {string}
   * @static
   */
  static getType(e) {
    const t = typeof e;
    return t === "object" ? e === null ? "null" : e instanceof Boolean ? "boolean" : e instanceof Number ? "number" : e instanceof String ? "string" : be(e) ? "array" : e instanceof Date ? "date" : e.nodeType !== void 0 ? "dom" : e._isAMomentObject === !0 ? "moment" : "object" : t === "number" ? "number" : t === "boolean" ? "boolean" : t === "string" ? "string" : t === void 0 ? "undefined" : t;
  }
  /**
   * @param {string} option
   * @param {object} options
   * @param {Array.<string>} path
   * @static
   */
  static getSuggestion(e, t, r) {
    const n = ye.findInOptions(e, t, r, !1), o = ye.findInOptions(e, Um, [], !0), s = 8, a = 4;
    let l;
    n.indexMatch !== void 0 ? l = " in " + ye.printLocation(n.path, e, "") + 'Perhaps it was incomplete? Did you mean: "' + n.indexMatch + `"?

` : o.distance <= a && n.distance > o.distance ? l = " in " + ye.printLocation(n.path, e, "") + "Perhaps it was misplaced? Matching option found at: " + ye.printLocation(o.path, o.closestMatch, "") : n.distance <= s ? l = '. Did you mean "' + n.closestMatch + '"?' + ye.printLocation(n.path, e) : l = ". Did you mean one of these: " + ye.print(me(t)) + ye.printLocation(r, e), console.error('%cUnknown option detected: "' + e + '"' + l, Ou), eo = !0;
  }
  /**
   * traverse the options in search for a match.
   *
   * @param {string} option
   * @param {object} options
   * @param {Array} path    | where to look for the actual option
   * @param {boolean} [recursive=false]
   * @returns {{closestMatch: string, path: Array, distance: number}}
   * @static
   */
  static findInOptions(e, t, r) {
    let n = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : !1, o = 1e9, s = "", a = [];
    const l = e.toLowerCase();
    let d;
    for (const c in t) {
      let u;
      if (t[c].__type__ !== void 0 && n === !0) {
        const f = ye.findInOptions(e, t[c], nl(r, c));
        o > f.distance && (s = f.closestMatch, a = f.path, o = f.distance, d = f.indexMatch);
      } else {
        var h;
        re(h = c.toLowerCase()).call(h, l) !== -1 && (d = c), u = ye.levenshteinDistance(e, c), o > u && (s = c, a = cee(r), o = u);
      }
    }
    return {
      closestMatch: s,
      path: a,
      distance: o,
      indexMatch: d
    };
  }
  /**
   * @param {Array.<string>} path
   * @param {object} option
   * @param {string} prefix
   * @returns {string}
   * @static
   */
  static printLocation(e, t) {
    let n = `

` + (arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : `Problem value found at: 
`) + `options = {
`;
    for (let o = 0; o < e.length; o++) {
      for (let s = 0; s < o + 1; s++)
        n += "  ";
      n += e[o] + `: {
`;
    }
    for (let o = 0; o < e.length + 1; o++)
      n += "  ";
    n += t + `
`;
    for (let o = 0; o < e.length + 1; o++) {
      for (let s = 0; s < e.length - o; s++)
        n += "  ";
      n += `}
`;
    }
    return n + `

`;
  }
  /**
   * @param {object} options
   * @returns {string}
   * @static
   */
  static print(e) {
    return Os(e).replace(/(")|(\[)|(\])|(,"__type__")/g, "").replace(/(,)/g, ", ");
  }
  /**
   *  Compute the edit distance between the two given strings
   * http://en.wikibooks.org/wiki/Algorithm_Implementation/Strings/Levenshtein_distance#JavaScript
   *
   * Copyright (c) 2011 Andrei Mackenzie
   *
   * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
   *
   * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
   *
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
   *
   * @param {string} a
   * @param {string} b
   * @returns {Array.<Array.<number>>}}
   * @static
   */
  static levenshteinDistance(e, t) {
    if (e.length === 0) return t.length;
    if (t.length === 0) return e.length;
    const r = [];
    let n;
    for (n = 0; n <= t.length; n++)
      r[n] = [n];
    let o;
    for (o = 0; o <= e.length; o++)
      r[0][o] = o;
    for (n = 1; n <= t.length; n++)
      for (o = 1; o <= e.length; o++)
        t.charAt(n - 1) == e.charAt(o - 1) ? r[n][o] = r[n - 1][o - 1] : r[n][o] = Math.min(
          r[n - 1][o - 1] + 1,
          // substitution
          Math.min(
            r[n][o - 1] + 1,
            // insertion
            r[n - 1][o] + 1
          )
        );
    return r[t.length][e.length];
  }
};
const _ee = Yt, Eee = bee, dn = zf, See = $ee, BE = Ou, Oee = wee;
function Tee(i) {
  return Pr = i, Cee();
}
var LE = {
  fontsize: "font.size",
  fontcolor: "font.color",
  labelfontcolor: "font.color",
  fontname: "font.face",
  color: ["color.border", "color.background"],
  fillcolor: "color.background",
  tooltip: "title",
  labeltooltip: "title"
}, Hf = ui(LE);
Hf.color = "color.color";
Hf.style = "dashes";
var Xe = {
  NULL: 0,
  DELIMITER: 1,
  IDENTIFIER: 2,
  UNKNOWN: 3
}, Gm = {
  "{": !0,
  "}": !0,
  "[": !0,
  "]": !0,
  ";": !0,
  "=": !0,
  ",": !0,
  "->": !0,
  "--": !0
}, Pr = "", Tn = 0, Y = "", B = "", st = Xe.NULL;
function Iee() {
  Tn = 0, Y = Pr.charAt(0);
}
function Re() {
  Tn++, Y = Pr.charAt(Tn);
}
function Ki() {
  return Pr.charAt(Tn + 1);
}
function Km(i) {
  var e = i.charCodeAt(0);
  return e < 47 ? e === 35 || e === 46 : e < 59 ? e > 47 : e < 91 ? e > 64 : e < 96 ? e === 95 : e < 123 ? e > 96 : !1;
}
function Lr(i, e) {
  if (i || (i = {}), e)
    for (var t in e)
      e.hasOwnProperty(t) && (i[t] = e[t]);
  return i;
}
function Pee(i, e, t) {
  for (var r = e.split("."), n = i; r.length; ) {
    var o = r.shift();
    r.length ? (n[o] || (n[o] = {}), n = n[o]) : n[o] = t;
  }
}
function jE(i, e) {
  for (var t, r, n = null, o = [i], s = i; s.parent; )
    o.push(s.parent), s = s.parent;
  if (s.nodes) {
    for (t = 0, r = s.nodes.length; t < r; t++)
      if (e.id === s.nodes[t].id) {
        n = s.nodes[t];
        break;
      }
  }
  for (n || (n = {
    id: e.id
  }, i.node && (n.attr = Lr(n.attr, i.node))), t = o.length - 1; t >= 0; t--) {
    var a, l = o[t];
    l.nodes || (l.nodes = []), re(a = l.nodes).call(a, n) === -1 && l.nodes.push(n);
  }
  e.attr && (n.attr = Lr(n.attr, e.attr));
}
function xee(i, e) {
  if (i.edges || (i.edges = []), i.edges.push(e), i.edge) {
    var t = Lr({}, i.edge);
    e.attr = Lr(t, e.attr);
  }
}
function zE(i, e, t, r, n) {
  var o = {
    from: e,
    to: t,
    type: r
  };
  return i.edge && (o.attr = Lr({}, i.edge)), o.attr = Lr(o.attr || {}, n), n != null && n.hasOwnProperty("arrows") && n.arrows != null && (o.arrows = {
    to: {
      enabled: !0,
      type: n.arrows.type
    }
  }, n.arrows = null), o;
}
function de() {
  for (st = Xe.NULL, B = ""; Y === " " || Y === "	" || Y === `
` || Y === "\r"; )
    Re();
  do {
    var i = !1;
    if (Y === "#") {
      for (var e = Tn - 1; Pr.charAt(e) === " " || Pr.charAt(e) === "	"; )
        e--;
      if (Pr.charAt(e) === `
` || Pr.charAt(e) === "") {
        for (; Y != "" && Y != `
`; )
          Re();
        i = !0;
      }
    }
    if (Y === "/" && Ki() === "/") {
      for (; Y != "" && Y != `
`; )
        Re();
      i = !0;
    }
    if (Y === "/" && Ki() === "*") {
      for (; Y != ""; )
        if (Y === "*" && Ki() === "/") {
          Re(), Re();
          break;
        } else
          Re();
      i = !0;
    }
    for (; Y === " " || Y === "	" || Y === `
` || Y === "\r"; )
      Re();
  } while (i);
  if (Y === "") {
    st = Xe.DELIMITER;
    return;
  }
  var t = Y + Ki();
  if (Gm[t]) {
    st = Xe.DELIMITER, B = t, Re(), Re();
    return;
  }
  if (Gm[Y]) {
    st = Xe.DELIMITER, B = Y, Re();
    return;
  }
  if (Km(Y) || Y === "-") {
    for (B += Y, Re(); Km(Y); )
      B += Y, Re();
    B === "false" ? B = !1 : B === "true" ? B = !0 : isNaN(Number(B)) || (B = Number(B)), st = Xe.IDENTIFIER;
    return;
  }
  if (Y === '"') {
    for (Re(); Y != "" && (Y != '"' || Y === '"' && Ki() === '"'); )
      Y === '"' ? (B += Y, Re()) : Y === "\\" && Ki() === "n" ? (B += `
`, Re()) : B += Y, Re();
    if (Y != '"')
      throw Je('End of string " expected');
    Re(), st = Xe.IDENTIFIER;
    return;
  }
  for (st = Xe.UNKNOWN; Y != ""; )
    B += Y, Re();
  throw new SyntaxError('Syntax error in part "' + UE(B, 30) + '"');
}
function Cee() {
  var i = {};
  if (Iee(), de(), B === "strict" && (i.strict = !0, de()), (B === "graph" || B === "digraph") && (i.type = B, de()), st === Xe.IDENTIFIER && (i.id = B, de()), B != "{")
    throw Je("Angle bracket { expected");
  if (de(), WE(i), B != "}")
    throw Je("Angle bracket } expected");
  if (de(), B !== "")
    throw Je("End of file expected");
  return de(), delete i.node, delete i.edge, delete i.graph, i;
}
function WE(i) {
  for (; B !== "" && B != "}"; )
    Aee(i), B === ";" && de();
}
function Aee(i) {
  var e = HE(i);
  if (e) {
    VE(i, e);
    return;
  }
  var t = Mee(i);
  if (!t) {
    if (st != Xe.IDENTIFIER)
      throw Je("Identifier expected");
    var r = B;
    if (de(), B === "=") {
      if (de(), st != Xe.IDENTIFIER)
        throw Je("Identifier expected");
      i[r] = B, de();
    } else
      Dee(i, r);
  }
}
function HE(i) {
  var e = null;
  if (B === "subgraph" && (e = {}, e.type = "subgraph", de(), st === Xe.IDENTIFIER && (e.id = B, de())), B === "{") {
    if (de(), e || (e = {}), e.parent = i, e.node = i.node, e.edge = i.edge, e.graph = i.graph, WE(e), B != "}")
      throw Je("Angle bracket } expected");
    de(), delete e.node, delete e.edge, delete e.graph, delete e.parent, i.subgraphs || (i.subgraphs = []), i.subgraphs.push(e);
  }
  return e;
}
function Mee(i) {
  return B === "node" ? (de(), i.node = go(), "node") : B === "edge" ? (de(), i.edge = go(), "edge") : B === "graph" ? (de(), i.graph = go(), "graph") : null;
}
function Dee(i, e) {
  var t = {
    id: e
  }, r = go();
  r && (t.attr = r), jE(i, t), VE(i, e);
}
function VE(i, e) {
  for (; B === "->" || B === "--"; ) {
    var t, r = B;
    de();
    var n = HE(i);
    if (n)
      t = n;
    else {
      if (st != Xe.IDENTIFIER)
        throw Je("Identifier or subgraph expected");
      t = B, jE(i, {
        id: t
      }), de();
    }
    var o = go(), s = zE(i, e, t, r, o);
    xee(i, s), e = t;
  }
}
function go() {
  for (var i, e = null, t = {
    dashed: !0,
    solid: !1,
    dotted: [1, 5]
  }, r = {
    dot: "circle",
    box: "box",
    crow: "crow",
    curve: "curve",
    icurve: "inv_curve",
    normal: "triangle",
    inv: "inv_triangle",
    diamond: "diamond",
    tee: "bar",
    vee: "vee"
  }, n = new Array(), o = new Array(); B === "["; ) {
    for (de(), e = {}; B !== "" && B != "]"; ) {
      if (st != Xe.IDENTIFIER)
        throw Je("Attribute name expected");
      var s = B;
      if (de(), B != "=")
        throw Je("Equal sign = expected");
      if (de(), st != Xe.IDENTIFIER)
        throw Je("Attribute value expected");
      var a = B;
      s === "style" && (a = t[a]);
      var l;
      s === "arrowhead" && (l = r[a], s = "arrows", a = {
        to: {
          enabled: !0,
          type: l
        }
      }), s === "arrowtail" && (l = r[a], s = "arrows", a = {
        from: {
          enabled: !0,
          type: l
        }
      }), n.push({
        attr: e,
        name: s,
        value: a
      }), o.push(s), de(), B == "," && de();
    }
    if (B != "]")
      throw Je("Bracket ] expected");
    de();
  }
  if (kr(o).call(o, "dir")) {
    var d = {};
    for (d.arrows = {}, i = 0; i < n.length; i++)
      if (n[i].name === "arrows")
        if (n[i].value.to != null)
          d.arrows.to = i;
        else if (n[i].value.from != null)
          d.arrows.from = i;
        else
          throw Je("Invalid value of arrows");
      else n[i].name === "dir" && (d.dir = i);
    var h = n[d.dir].value;
    if (!kr(o).call(o, "arrows"))
      if (h === "both")
        n.push({
          attr: n[d.dir].attr,
          name: "arrows",
          value: {
            to: {
              enabled: !0
            }
          }
        }), d.arrows.to = n.length - 1, n.push({
          attr: n[d.dir].attr,
          name: "arrows",
          value: {
            from: {
              enabled: !0
            }
          }
        }), d.arrows.from = n.length - 1;
      else if (h === "forward")
        n.push({
          attr: n[d.dir].attr,
          name: "arrows",
          value: {
            to: {
              enabled: !0
            }
          }
        }), d.arrows.to = n.length - 1;
      else if (h === "back")
        n.push({
          attr: n[d.dir].attr,
          name: "arrows",
          value: {
            from: {
              enabled: !0
            }
          }
        }), d.arrows.from = n.length - 1;
      else if (h === "none")
        n.push({
          attr: n[d.dir].attr,
          name: "arrows",
          value: ""
        }), d.arrows.to = n.length - 1;
      else
        throw Je('Invalid dir type "' + h + '"');
    var c, u;
    if (h === "both")
      d.arrows.to && d.arrows.from ? (u = n[d.arrows.to].value.to.type, c = n[d.arrows.from].value.from.type, n[d.arrows.to] = {
        attr: n[d.arrows.to].attr,
        name: n[d.arrows.to].name,
        value: {
          to: {
            enabled: !0,
            type: u
          },
          from: {
            enabled: !0,
            type: c
          }
        }
      }, ar(n).call(n, d.arrows.from, 1)) : d.arrows.to ? (u = n[d.arrows.to].value.to.type, c = "arrow", n[d.arrows.to] = {
        attr: n[d.arrows.to].attr,
        name: n[d.arrows.to].name,
        value: {
          to: {
            enabled: !0,
            type: u
          },
          from: {
            enabled: !0,
            type: c
          }
        }
      }) : d.arrows.from && (u = "arrow", c = n[d.arrows.from].value.from.type, n[d.arrows.from] = {
        attr: n[d.arrows.from].attr,
        name: n[d.arrows.from].name,
        value: {
          to: {
            enabled: !0,
            type: u
          },
          from: {
            enabled: !0,
            type: c
          }
        }
      });
    else if (h === "back")
      d.arrows.to && d.arrows.from ? (u = "", c = n[d.arrows.from].value.from.type, n[d.arrows.from] = {
        attr: n[d.arrows.from].attr,
        name: n[d.arrows.from].name,
        value: {
          to: {
            enabled: !0,
            type: u
          },
          from: {
            enabled: !0,
            type: c
          }
        }
      }) : d.arrows.to ? (u = "", c = "arrow", d.arrows.from = d.arrows.to, n[d.arrows.from] = {
        attr: n[d.arrows.from].attr,
        name: n[d.arrows.from].name,
        value: {
          to: {
            enabled: !0,
            type: u
          },
          from: {
            enabled: !0,
            type: c
          }
        }
      }) : d.arrows.from && (u = "", c = n[d.arrows.from].value.from.type, n[d.arrows.to] = {
        attr: n[d.arrows.from].attr,
        name: n[d.arrows.from].name,
        value: {
          to: {
            enabled: !0,
            type: u
          },
          from: {
            enabled: !0,
            type: c
          }
        }
      }), n[d.arrows.from] = {
        attr: n[d.arrows.from].attr,
        name: n[d.arrows.from].name,
        value: {
          from: {
            enabled: !0,
            type: n[d.arrows.from].value.from.type
          }
        }
      };
    else if (h === "none") {
      var f;
      d.arrows.to ? f = d.arrows.to : f = d.arrows.from, n[f] = {
        attr: n[f].attr,
        name: n[f].name,
        value: ""
      };
    } else if (h === "forward")
      d.arrows.to && d.arrows.from ? (u = n[d.arrows.to].value.to.type, c = "", n[d.arrows.to] = {
        attr: n[d.arrows.to].attr,
        name: n[d.arrows.to].name,
        value: {
          to: {
            enabled: !0,
            type: u
          },
          from: {
            enabled: !0,
            type: c
          }
        }
      }) : d.arrows.to ? (u = n[d.arrows.to].value.to.type, c = "", n[d.arrows.to] = {
        attr: n[d.arrows.to].attr,
        name: n[d.arrows.to].name,
        value: {
          to: {
            enabled: !0,
            type: u
          },
          from: {
            enabled: !0,
            type: c
          }
        }
      }) : d.arrows.from && (u = "arrow", c = "", d.arrows.to = d.arrows.from, n[d.arrows.to] = {
        attr: n[d.arrows.to].attr,
        name: n[d.arrows.to].name,
        value: {
          to: {
            enabled: !0,
            type: u
          },
          from: {
            enabled: !0,
            type: c
          }
        }
      }), n[d.arrows.to] = {
        attr: n[d.arrows.to].attr,
        name: n[d.arrows.to].name,
        value: {
          to: {
            enabled: !0,
            type: n[d.arrows.to].value.to.type
          }
        }
      };
    else
      throw Je('Invalid dir type "' + h + '"');
    ar(n).call(n, d.dir, 1);
  }
  var v;
  if (kr(o).call(o, "penwidth")) {
    var y = [];
    for (v = n.length, i = 0; i < v; i++)
      n[i].name !== "width" && (n[i].name === "penwidth" && (n[i].name = "width"), y.push(n[i]));
    n = y;
  }
  for (v = n.length, i = 0; i < v; i++)
    Pee(n[i].attr, n[i].name, n[i].value);
  return e;
}
function Je(i) {
  return new SyntaxError(i + ', got "' + UE(B, 30) + '" (char ' + Tn + ")");
}
function UE(i, e) {
  return i.length <= e ? i : i.substr(0, 27) + "...";
}
function kee(i, e, t) {
  be(i) ? se(i).call(i, function(r) {
    be(e) ? se(e).call(e, function(n) {
      t(r, n);
    }) : t(r, e);
  }) : be(e) ? se(e).call(e, function(r) {
    t(i, r);
  }) : t(i, e);
}
function dc(i, e, t) {
  for (var r = e.split("."), n = r.pop(), o = i, s = 0; s < r.length; s++) {
    var a = r[s];
    a in o || (o[a] = {}), o = o[a];
  }
  return o[n] = t, i;
}
function Ym(i, e) {
  var t = {};
  for (var r in i)
    if (i.hasOwnProperty(r)) {
      var n = e[r];
      be(n) ? se(n).call(n, function(o) {
        dc(t, o, i[r]);
      }) : typeof n == "string" ? dc(t, n, i[r]) : dc(t, r, i[r]);
    }
  return t;
}
function Nee(i) {
  var e = Tee(i), t = {
    nodes: [],
    edges: [],
    options: {}
  };
  if (e.nodes) {
    var r;
    se(r = e.nodes).call(r, function(s) {
      var a = {
        id: s.id,
        label: String(s.label || s.id)
      };
      Lr(a, Ym(s.attr, LE)), a.image && (a.shape = "image"), t.nodes.push(a);
    });
  }
  if (e.edges) {
    var n, o = function(s) {
      var a = {
        from: s.from,
        to: s.to
      };
      return Lr(a, Ym(s.attr, Hf)), a.arrows == null && s.type === "->" && (a.arrows = "to"), a;
    };
    se(n = e.edges).call(n, function(s) {
      var a, l;
      if (s.from instanceof Object ? a = s.from.nodes : a = {
        id: s.from
      }, s.to instanceof Object ? l = s.to.nodes : l = {
        id: s.to
      }, s.from instanceof Object && s.from.edges) {
        var d;
        se(d = s.from.edges).call(d, function(c) {
          var u = o(c);
          t.edges.push(u);
        });
      }
      if (kee(a, l, function(c, u) {
        var f = zE(t, c.id, u.id, s.type, s.attr), v = o(f);
        t.edges.push(v);
      }), s.to instanceof Object && s.to.edges) {
        var h;
        se(h = s.to.edges).call(h, function(c) {
          var u = o(c);
          t.edges.push(u);
        });
      }
    });
  }
  return e.attr && (t.options = e.attr), t;
}
function Ree(i, e) {
  var t;
  const r = {
    edges: {
      inheritColor: !1
    },
    nodes: {
      fixed: !1,
      parseColor: !1
    }
  };
  e != null && (e.fixed != null && (r.nodes.fixed = e.fixed), e.parseColor != null && (r.nodes.parseColor = e.parseColor), e.inheritColor != null && (r.edges.inheritColor = e.inheritColor));
  const n = i.edges, o = _n(n).call(n, (a) => {
    const l = {
      from: a.source,
      id: a.id,
      to: a.target
    };
    return a.attributes != null && (l.attributes = a.attributes), a.label != null && (l.label = a.label), a.attributes != null && a.attributes.title != null && (l.title = a.attributes.title), a.type === "Directed" && (l.arrows = "to"), a.color && r.edges.inheritColor === !1 && (l.color = a.color), l;
  });
  return {
    nodes: _n(t = i.nodes).call(t, (a) => {
      const l = {
        id: a.id,
        fixed: r.nodes.fixed && a.x != null && a.y != null
      };
      return a.attributes != null && (l.attributes = a.attributes), a.label != null && (l.label = a.label), a.size != null && (l.size = a.size), a.attributes != null && a.attributes.title != null && (l.title = a.attributes.title), a.title != null && (l.title = a.title), a.x != null && (l.x = a.x), a.y != null && (l.y = a.y), a.color != null && (r.nodes.parseColor === !0 ? l.color = a.color : l.color = {
        background: a.color,
        border: a.color,
        highlight: {
          background: a.color,
          border: a.color
        },
        hover: {
          background: a.color,
          border: a.color
        }
      }), l;
    }),
    edges: o
  };
}
const Fee = {
  addDescription: "Click in an empty space to place a new node.",
  addEdge: "Add Edge",
  addNode: "Add Node",
  back: "Back",
  close: "Close",
  createEdgeError: "Cannot link edges to a cluster.",
  del: "Delete selected",
  deleteClusterError: "Clusters cannot be deleted.",
  edgeDescription: "Click on a node and drag the edge to another node to connect them.",
  edit: "Edit",
  editClusterError: "Clusters cannot be edited.",
  editEdge: "Edit Edge",
  editEdgeDescription: "Click on the control points and drag them to a node to connect to it.",
  editNode: "Edit Node"
}, Bee = {
  addDescription: "Klicke auf eine freie Stelle, um einen neuen Knoten zu plazieren.",
  addEdge: "Kante hinzufügen",
  addNode: "Knoten hinzufügen",
  back: "Zurück",
  close: "Schließen",
  createEdgeError: "Es ist nicht möglich, Kanten mit Clustern zu verbinden.",
  del: "Lösche Auswahl",
  deleteClusterError: "Cluster können nicht gelöscht werden.",
  edgeDescription: "Klicke auf einen Knoten und ziehe die Kante zu einem anderen Knoten, um diese zu verbinden.",
  edit: "Editieren",
  editClusterError: "Cluster können nicht editiert werden.",
  editEdge: "Kante editieren",
  editEdgeDescription: "Klicke auf die Verbindungspunkte und ziehe diese auf einen Knoten, um sie zu verbinden.",
  editNode: "Knoten editieren"
}, Lee = {
  addDescription: "Haga clic en un lugar vacío para colocar un nuevo nodo.",
  addEdge: "Añadir arista",
  addNode: "Añadir nodo",
  back: "Atrás",
  close: "Cerrar",
  createEdgeError: "No se puede conectar una arista a un grupo.",
  del: "Eliminar selección",
  deleteClusterError: "No es posible eliminar grupos.",
  edgeDescription: "Haga clic en un nodo y arrastre la arista hacia otro nodo para conectarlos.",
  edit: "Editar",
  editClusterError: "No es posible editar grupos.",
  editEdge: "Editar arista",
  editEdgeDescription: "Haga clic en un punto de control y arrastrelo a un nodo para conectarlo.",
  editNode: "Editar nodo"
}, jee = {
  addDescription: "Clicca per aggiungere un nuovo nodo",
  addEdge: "Aggiungi un vertice",
  addNode: "Aggiungi un nodo",
  back: "Indietro",
  close: "Chiudere",
  createEdgeError: "Non si possono collegare vertici ad un cluster",
  del: "Cancella la selezione",
  deleteClusterError: "I cluster non possono essere cancellati",
  edgeDescription: "Clicca su un nodo e trascinalo ad un altro nodo per connetterli.",
  edit: "Modifica",
  editClusterError: "I clusters non possono essere modificati.",
  editEdge: "Modifica il vertice",
  editEdgeDescription: "Clicca sui Punti di controllo e trascinali ad un nodo per connetterli.",
  editNode: "Modifica il nodo"
}, zee = {
  addDescription: "Klik op een leeg gebied om een nieuwe node te maken.",
  addEdge: "Link toevoegen",
  addNode: "Node toevoegen",
  back: "Terug",
  close: "Sluiten",
  createEdgeError: "Kan geen link maken naar een cluster.",
  del: "Selectie verwijderen",
  deleteClusterError: "Clusters kunnen niet worden verwijderd.",
  edgeDescription: "Klik op een node en sleep de link naar een andere node om ze te verbinden.",
  edit: "Wijzigen",
  editClusterError: "Clusters kunnen niet worden aangepast.",
  editEdge: "Link wijzigen",
  editEdgeDescription: "Klik op de verbindingspunten en sleep ze naar een node om daarmee te verbinden.",
  editNode: "Node wijzigen"
}, Wee = {
  addDescription: "Clique em um espaço em branco para adicionar um novo nó",
  addEdge: "Adicionar aresta",
  addNode: "Adicionar nó",
  back: "Voltar",
  close: "Fechar",
  createEdgeError: "Não foi possível linkar arestas a um cluster.",
  del: "Remover selecionado",
  deleteClusterError: "Clusters não puderam ser removidos.",
  edgeDescription: "Clique em um nó e arraste a aresta até outro nó para conectá-los",
  edit: "Editar",
  editClusterError: "Clusters não puderam ser editados.",
  editEdge: "Editar aresta",
  editEdgeDescription: "Clique nos pontos de controle e os arraste para um nó para conectá-los",
  editNode: "Editar nó"
}, Hee = {
  addDescription: "Кликните в свободное место, чтобы добавить новый узел.",
  addEdge: "Добавить ребро",
  addNode: "Добавить узел",
  back: "Назад",
  close: "Закрывать",
  createEdgeError: "Невозможно соединить ребра в кластер.",
  del: "Удалить выбранное",
  deleteClusterError: "Кластеры не могут быть удалены",
  edgeDescription: "Кликните на узел и протяните ребро к другому узлу, чтобы соединить их.",
  edit: "Редактировать",
  editClusterError: "Кластеры недоступны для редактирования.",
  editEdge: "Редактировать ребро",
  editEdgeDescription: "Кликните на контрольные точки и перетащите их в узел, чтобы подключиться к нему.",
  editNode: "Редактировать узел"
}, Vee = {
  addDescription: "单击空白处放置新节点。",
  addEdge: "添加连接线",
  addNode: "添加节点",
  back: "返回",
  close: "關閉",
  createEdgeError: "无法将连接线连接到群集。",
  del: "删除选定",
  deleteClusterError: "无法删除群集。",
  edgeDescription: "单击某个节点并将该连接线拖动到另一个节点以连接它们。",
  edit: "编辑",
  editClusterError: "无法编辑群集。",
  editEdge: "编辑连接线",
  editEdgeDescription: "单击控制节点并将它们拖到节点上连接。",
  editNode: "编辑节点"
}, Uee = {
  addDescription: "Kлікніть на вільне місце, щоб додати новий вузол.",
  addEdge: "Додати край",
  addNode: "Додати вузол",
  back: "Назад",
  close: "Закрити",
  createEdgeError: "Не можливо об'єднати краї в групу.",
  del: "Видалити обране",
  deleteClusterError: "Групи не можуть бути видалені.",
  edgeDescription: "Клікніть на вузол і перетягніть край до іншого вузла, щоб їх з'єднати.",
  edit: "Редагувати",
  editClusterError: "Групи недоступні для редагування.",
  editEdge: "Редагувати край",
  editEdgeDescription: "Клікніть на контрольні точки і перетягніть їх у вузол, щоб підключитися до нього.",
  editNode: "Редагувати вузол"
}, Gee = {
  addDescription: "Cliquez dans un endroit vide pour placer un nœud.",
  addEdge: "Ajouter un lien",
  addNode: "Ajouter un nœud",
  back: "Retour",
  close: "Fermer",
  createEdgeError: "Impossible de créer un lien vers un cluster.",
  del: "Effacer la sélection",
  deleteClusterError: "Les clusters ne peuvent pas être effacés.",
  edgeDescription: "Cliquez sur un nœud et glissez le lien vers un autre nœud pour les connecter.",
  edit: "Éditer",
  editClusterError: "Les clusters ne peuvent pas être édités.",
  editEdge: "Éditer le lien",
  editEdgeDescription: "Cliquez sur les points de contrôle et glissez-les pour connecter un nœud.",
  editNode: "Éditer le nœud"
}, Kee = {
  addDescription: "Kluknutím do prázdného prostoru můžete přidat nový vrchol.",
  addEdge: "Přidat hranu",
  addNode: "Přidat vrchol",
  back: "Zpět",
  close: "Zavřít",
  createEdgeError: "Nelze připojit hranu ke shluku.",
  del: "Smazat výběr",
  deleteClusterError: "Nelze mazat shluky.",
  edgeDescription: "Přetažením z jednoho vrcholu do druhého můžete spojit tyto vrcholy novou hranou.",
  edit: "Upravit",
  editClusterError: "Nelze upravovat shluky.",
  editEdge: "Upravit hranu",
  editEdgeDescription: "Přetažením kontrolního vrcholu hrany ji můžete připojit k jinému vrcholu.",
  editNode: "Upravit vrchol"
};
var Yee = /* @__PURE__ */ Object.freeze({
  __proto__: null,
  cn: Vee,
  cs: Kee,
  de: Bee,
  en: Fee,
  es: Lee,
  fr: Gee,
  it: jee,
  nl: zee,
  pt: Wee,
  ru: Hee,
  uk: Uee
});
function qee(i, e) {
  try {
    const [r, n] = e.split(/[-_ /]/, 2), o = r != null ? r.toLowerCase() : null, s = n != null ? n.toUpperCase() : null;
    if (o && s) {
      const a = o + "-" + s;
      if (Object.prototype.hasOwnProperty.call(i, a))
        return a;
      var t;
      console.warn(yJ(t = "Unknown variant ".concat(s, " of language ")).call(t, o, "."));
    }
    if (o) {
      const a = o;
      if (Object.prototype.hasOwnProperty.call(i, a))
        return a;
      console.warn("Unknown language ".concat(o));
    }
    return console.warn("Unknown locale ".concat(e, ", falling back to English.")), "en";
  } catch (r) {
    return console.error(r), console.warn("Unexpected error while normalizing locale ".concat(e, ", falling back to English.")), "en";
  }
}
class Xee {
  /**
   * @ignore
   */
  constructor() {
    this.NUM_ITERATIONS = 4, this.image = new Image(), this.canvas = document.createElement("canvas");
  }
  /**
   * Called when the image has been successfully loaded.
   */
  init() {
    if (this.initialized()) return;
    this.src = this.image.src;
    const e = this.image.width, t = this.image.height;
    this.width = e, this.height = t;
    const r = Math.floor(t / 2), n = Math.floor(t / 4), o = Math.floor(t / 8), s = Math.floor(t / 16), a = Math.floor(e / 2), l = Math.floor(e / 4), d = Math.floor(e / 8), h = Math.floor(e / 16);
    this.canvas.width = 3 * l, this.canvas.height = r, this.coordinates = [[0, 0, a, r], [a, 0, l, n], [a, n, d, o], [5 * d, n, h, s]], this._fillMipMap();
  }
  /**
   * @returns {boolean} true if init() has been called, false otherwise.
   */
  initialized() {
    return this.coordinates !== void 0;
  }
  /**
   * Redraw main image in various sizes to the context.
   *
   * The rationale behind this is to reduce artefacts due to interpolation
   * at differing zoom levels.
   *
   * Source: http://stackoverflow.com/q/18761404/1223531
   *
   * This methods takes the resizing out of the drawing loop, in order to
   * reduce performance overhead.
   *
   * TODO: The code assumes that a 2D context can always be gotten. This is
   * not necessarily true! OTOH, if not true then usage of this class
   * is senseless.
   * @private
   */
  _fillMipMap() {
    const e = this.canvas.getContext("2d"), t = this.coordinates[0];
    e.drawImage(this.image, t[0], t[1], t[2], t[3]);
    for (let r = 1; r < this.NUM_ITERATIONS; r++) {
      const n = this.coordinates[r - 1], o = this.coordinates[r];
      e.drawImage(this.canvas, n[0], n[1], n[2], n[3], o[0], o[1], o[2], o[3]);
    }
  }
  /**
   * Draw the image, using the mipmap if necessary.
   *
   * MipMap is only used if param factor > 2; otherwise, original bitmap
   * is resized. This is also used to skip mipmap usage, e.g. by setting factor = 1
   *
   * Credits to 'Alex de Mulder' for original implementation.
   * @param {CanvasRenderingContext2D} ctx  context on which to draw zoomed image
   * @param {Float} factor scale factor at which to draw
   * @param {number} left
   * @param {number} top
   * @param {number} width
   * @param {number} height
   */
  drawImageAtPosition(e, t, r, n, o, s) {
    if (this.initialized())
      if (t > 2) {
        t *= 0.5;
        let a = 0;
        for (; t > 2 && a < this.NUM_ITERATIONS; )
          t *= 0.5, a += 1;
        a >= this.NUM_ITERATIONS && (a = this.NUM_ITERATIONS - 1);
        const l = this.coordinates[a];
        e.drawImage(this.canvas, l[0], l[1], l[2], l[3], r, n, o, s);
      } else
        e.drawImage(this.image, r, n, o, s);
  }
}
class Jee {
  /**
   * @param {ImageCallback} callback
   */
  constructor(e) {
    this.images = {}, this.imageBroken = {}, this.callback = e;
  }
  /**
   * @param {string} url                      The original Url that failed to load, if the broken image is successfully loaded it will be added to the cache using this Url as the key so that subsequent requests for this Url will return the broken image
   * @param {string} brokenUrl                Url the broken image to try and load
   * @param {Image} imageToLoadBrokenUrlOn   The image object
   */
  _tryloadBrokenUrl(e, t, r) {
    if (!(e === void 0 || r === void 0)) {
      if (t === void 0) {
        console.warn("No broken url image defined");
        return;
      }
      r.image.onerror = () => {
        console.error("Could not load brokenImage:", t);
      }, r.image.src = t;
    }
  }
  /**
   *
   * @param {vis.Image} imageToRedrawWith
   * @private
   */
  _redrawWithImage(e) {
    this.callback && this.callback(e);
  }
  /**
   * @param {string} url          Url of the image
   * @param {string} brokenUrl    Url of an image to use if the url image is not found
   * @returns {Image} img          The image object
   */
  load(e, t) {
    const r = this.images[e];
    if (r) return r;
    const n = new Xee();
    return this.images[e] = n, n.image.onload = () => {
      this._fixImageCoordinates(n.image), n.init(), this._redrawWithImage(n);
    }, n.image.onerror = () => {
      console.error("Could not load image:", e), this._tryloadBrokenUrl(e, t, n);
    }, n.image.src = e, n;
  }
  /**
   * IE11 fix -- thanks dponch!
   *
   * Local helper function
   * @param {vis.Image} imageToCache
   * @private
   */
  _fixImageCoordinates(e) {
    e.width === 0 && (document.body.appendChild(e), e.width = e.offsetWidth, e.height = e.offsetHeight, document.body.removeChild(e));
  }
}
var GE = { exports: {} }, Zee = Z, Qee = Zee(function() {
  if (typeof ArrayBuffer == "function") {
    var i = new ArrayBuffer(8);
    Object.isExtensible(i) && Object.defineProperty(i, "a", { value: 8 });
  }
}), ete = Z, tte = Ye, rte = mr, qm = Qee, Ma = Object.isExtensible, ite = ete(function() {
  Ma(1);
}), nte = ite || qm ? function(e) {
  return !tte(e) || qm && rte(e) === "ArrayBuffer" ? !1 : Ma ? Ma(e) : !0;
} : Ma, ote = Z, KE = !ote(function() {
  return Object.isExtensible(Object.preventExtensions({}));
}), ste = H, ate = Q, lte = vs, dte = Ye, Vf = Ue, hte = $t.f, Xm = $s, cte = Yl, Uf = nte, ute = zl, fte = KE, YE = !1, pr = ute("meta"), vte = 0, Gf = function(i) {
  hte(i, pr, { value: {
    objectID: "O" + vte++,
    // object ID
    weakData: {}
    // weak collections IDs
  } });
}, pte = function(i, e) {
  if (!dte(i)) return typeof i == "symbol" ? i : (typeof i == "string" ? "S" : "P") + i;
  if (!Vf(i, pr)) {
    if (!Uf(i)) return "F";
    if (!e) return "E";
    Gf(i);
  }
  return i[pr].objectID;
}, gte = function(i, e) {
  if (!Vf(i, pr)) {
    if (!Uf(i)) return !0;
    if (!e) return !1;
    Gf(i);
  }
  return i[pr].weakData;
}, yte = function(i) {
  return fte && YE && Uf(i) && !Vf(i, pr) && Gf(i), i;
}, mte = function() {
  bte.enable = function() {
  }, YE = !0;
  var i = Xm.f, e = ate([].splice), t = {};
  t[pr] = 1, i(t).length && (Xm.f = function(r) {
    for (var n = i(r), o = 0, s = n.length; o < s; o++)
      if (n[o] === pr) {
        e(n, o, 1);
        break;
      }
    return n;
  }, ste({ target: "Object", stat: !0, forced: !0 }, {
    getOwnPropertyNames: cte.f
  }));
}, bte = GE.exports = {
  enable: mte,
  fastKey: pte,
  getWeakData: gte,
  onFreeze: yte
};
lte[pr] = !0;
var od = GE.exports, $te = Ie, wte = Kn, _te = $te("iterator"), Ete = Array.prototype, Ste = function(i) {
  return i !== void 0 && (wte.Array === i || Ete[_te] === i);
}, Ote = Mi, Jm = mf, Tte = zn, Ite = Kn, Pte = Ie, xte = Pte("iterator"), qE = function(i) {
  if (!Tte(i)) return Jm(i, xte) || Jm(i, "@@iterator") || Ite[Ote(i)];
}, Cte = Bt, Ate = Hn, Mte = br, Dte = cs, kte = qE, Nte = TypeError, Rte = function(i, e) {
  var t = arguments.length < 2 ? kte(i) : e;
  if (Ate(t)) return Mte(Cte(t, i));
  throw new Nte(Dte(i) + " is not iterable");
}, Fte = Bt, Zm = br, Bte = mf, Lte = function(i, e, t) {
  var r, n;
  Zm(i);
  try {
    if (r = Bte(i, "return"), !r) {
      if (e === "throw") throw t;
      return t;
    }
    r = Fte(r, i);
  } catch (o) {
    n = !0, r = o;
  }
  if (e === "throw") throw t;
  if (n) throw r;
  return Zm(r), t;
}, jte = Hl, zte = Bt, Wte = br, Hte = cs, Vte = Ste, Ute = Qt, Qm = ke, Gte = Rte, Kte = qE, eb = Lte, Yte = TypeError, Da = function(i, e) {
  this.stopped = i, this.result = e;
}, tb = Da.prototype, Kf = function(i, e, t) {
  var r = t && t.that, n = !!(t && t.AS_ENTRIES), o = !!(t && t.IS_RECORD), s = !!(t && t.IS_ITERATOR), a = !!(t && t.INTERRUPTED), l = jte(e, r), d, h, c, u, f, v, y, g = function(m) {
    return d && eb(d, "normal", m), new Da(!0, m);
  }, p = function(m) {
    return n ? (Wte(m), a ? l(m[0], m[1], g) : l(m[0], m[1])) : a ? l(m, g) : l(m);
  };
  if (o)
    d = i.iterator;
  else if (s)
    d = i;
  else {
    if (h = Kte(i), !h) throw new Yte(Hte(i) + " is not iterable");
    if (Vte(h)) {
      for (c = 0, u = Ute(i); u > c; c++)
        if (f = p(i[c]), f && Qm(tb, f)) return f;
      return new Da(!1);
    }
    d = Gte(i, h);
  }
  for (v = o ? i.next : d.next; !(y = zte(v, d)).done; ) {
    try {
      f = p(y.value);
    } catch (m) {
      eb(d, "throw", m);
    }
    if (typeof f == "object" && f && Qm(tb, f)) return f;
  }
  return new Da(!1);
}, qte = ke, Xte = TypeError, Yf = function(i, e) {
  if (qte(e, i)) return i;
  throw new Xte("Incorrect invocation");
}, Jte = H, Zte = _e, Qte = od, ere = Z, tre = Un, rre = Kf, ire = Yf, nre = Ve, ore = Ye, sre = zn, are = Gn, lre = $t.f, dre = Kr.forEach, hre = Ne, XE = Di, cre = XE.set, ure = XE.getterFor, qf = function(i, e, t) {
  var r = i.indexOf("Map") !== -1, n = i.indexOf("Weak") !== -1, o = r ? "set" : "add", s = Zte[i], a = s && s.prototype, l = {}, d;
  if (!hre || !nre(s) || !(n || a.forEach && !ere(function() {
    new s().entries().next();
  })))
    d = t.getConstructor(e, i, r, o), Qte.enable();
  else {
    d = e(function(u, f) {
      cre(ire(u, h), {
        type: i,
        collection: new s()
      }), sre(f) || rre(f, u[o], { that: u, AS_ENTRIES: r });
    });
    var h = d.prototype, c = ure(i);
    dre(["add", "clear", "delete", "forEach", "get", "has", "set", "keys", "values", "entries"], function(u) {
      var f = u === "add" || u === "set";
      u in a && !(n && u === "clear") && tre(h, u, function(v, y) {
        var g = c(this).collection;
        if (!f && n && !ore(v)) return u === "get" ? void 0 : !1;
        var p = g[u](v === 0 ? 0 : v, y);
        return f ? this : p;
      });
    }), n || lre(h, "size", {
      configurable: !0,
      get: function() {
        return c(this).collection.size;
      }
    });
  }
  return are(d, i, !1, !0), l[i] = d, Jte({ global: !0, forced: !0 }, l), n || t.setStrong(d, i, r), d;
}, fre = ws, Xf = function(i, e, t) {
  for (var r in e)
    t && t.unsafe && i[r] ? i[r] = e[r] : fre(i, r, e[r], t);
  return i;
}, vre = jt, pre = Tf, gre = Ie, yre = Ne, rb = gre("species"), mre = function(i) {
  var e = vre(i);
  yre && e && !e[rb] && pre(e, rb, {
    configurable: !0,
    get: function() {
      return this;
    }
  });
}, bre = bs, $re = Tf, ib = Xf, wre = Hl, _re = Yf, Ere = zn, Sre = Kf, Ore = Af, ca = Mf, Tre = mre, to = Ne, nb = od.fastKey, JE = Di, ob = JE.set, hc = JE.getterFor, ZE = {
  getConstructor: function(i, e, t, r) {
    var n = i(function(d, h) {
      _re(d, o), ob(d, {
        type: e,
        index: bre(null),
        first: void 0,
        last: void 0,
        size: 0
      }), to || (d.size = 0), Ere(h) || Sre(h, d[r], { that: d, AS_ENTRIES: t });
    }), o = n.prototype, s = hc(e), a = function(d, h, c) {
      var u = s(d), f = l(d, h), v, y;
      return f ? f.value = c : (u.last = f = {
        index: y = nb(h, !0),
        key: h,
        value: c,
        previous: v = u.last,
        next: void 0,
        removed: !1
      }, u.first || (u.first = f), v && (v.next = f), to ? u.size++ : d.size++, y !== "F" && (u.index[y] = f)), d;
    }, l = function(d, h) {
      var c = s(d), u = nb(h), f;
      if (u !== "F") return c.index[u];
      for (f = c.first; f; f = f.next)
        if (f.key === h) return f;
    };
    return ib(o, {
      // `{ Map, Set }.prototype.clear()` methods
      // https://tc39.es/ecma262/#sec-map.prototype.clear
      // https://tc39.es/ecma262/#sec-set.prototype.clear
      clear: function() {
        for (var h = this, c = s(h), u = c.index, f = c.first; f; )
          f.removed = !0, f.previous && (f.previous = f.previous.next = void 0), delete u[f.index], f = f.next;
        c.first = c.last = void 0, to ? c.size = 0 : h.size = 0;
      },
      // `{ Map, Set }.prototype.delete(key)` methods
      // https://tc39.es/ecma262/#sec-map.prototype.delete
      // https://tc39.es/ecma262/#sec-set.prototype.delete
      delete: function(d) {
        var h = this, c = s(h), u = l(h, d);
        if (u) {
          var f = u.next, v = u.previous;
          delete c.index[u.index], u.removed = !0, v && (v.next = f), f && (f.previous = v), c.first === u && (c.first = f), c.last === u && (c.last = v), to ? c.size-- : h.size--;
        }
        return !!u;
      },
      // `{ Map, Set }.prototype.forEach(callbackfn, thisArg = undefined)` methods
      // https://tc39.es/ecma262/#sec-map.prototype.foreach
      // https://tc39.es/ecma262/#sec-set.prototype.foreach
      forEach: function(h) {
        for (var c = s(this), u = wre(h, arguments.length > 1 ? arguments[1] : void 0), f; f = f ? f.next : c.first; )
          for (u(f.value, f.key, this); f && f.removed; ) f = f.previous;
      },
      // `{ Map, Set}.prototype.has(key)` methods
      // https://tc39.es/ecma262/#sec-map.prototype.has
      // https://tc39.es/ecma262/#sec-set.prototype.has
      has: function(h) {
        return !!l(this, h);
      }
    }), ib(o, t ? {
      // `Map.prototype.get(key)` method
      // https://tc39.es/ecma262/#sec-map.prototype.get
      get: function(h) {
        var c = l(this, h);
        return c && c.value;
      },
      // `Map.prototype.set(key, value)` method
      // https://tc39.es/ecma262/#sec-map.prototype.set
      set: function(h, c) {
        return a(this, h === 0 ? 0 : h, c);
      }
    } : {
      // `Set.prototype.add(value)` method
      // https://tc39.es/ecma262/#sec-set.prototype.add
      add: function(h) {
        return a(this, h = h === 0 ? 0 : h, h);
      }
    }), to && $re(o, "size", {
      configurable: !0,
      get: function() {
        return s(this).size;
      }
    }), n;
  },
  setStrong: function(i, e, t) {
    var r = e + " Iterator", n = hc(e), o = hc(r);
    Ore(i, e, function(s, a) {
      ob(this, {
        type: r,
        target: s,
        state: n(s),
        kind: a,
        last: void 0
      });
    }, function() {
      for (var s = o(this), a = s.kind, l = s.last; l && l.removed; ) l = l.previous;
      return !s.target || !(s.last = l = l ? l.next : s.state.first) ? (s.target = void 0, ca(void 0, !0)) : ca(a === "keys" ? l.key : a === "values" ? l.value : [l.key, l.value], !1);
    }, t ? "entries" : "values", !t, !0), Tre(e);
  }
}, Ire = qf, Pre = ZE;
Ire("Map", function(i) {
  return function() {
    return i(this, arguments.length ? arguments[0] : void 0);
  };
}, Pre);
var Jf = Q, xre = Vl, Cre = er, Are = as, Mre = Jf("".charAt), sb = Jf("".charCodeAt), Dre = Jf("".slice), kre = function(i) {
  return function(e, t) {
    var r = Cre(Are(e)), n = xre(t), o = r.length, s, a;
    return n < 0 || n >= o ? i ? "" : void 0 : (s = sb(r, n), s < 55296 || s > 56319 || n + 1 === o || (a = sb(r, n + 1)) < 56320 || a > 57343 ? i ? Mre(r, n) : s : i ? Dre(r, n, n + 2) : (s - 55296 << 10) + (a - 56320) + 65536);
  };
}, Nre = {
  // `String.prototype.at` method
  // https://github.com/mathiasbynens/String.prototype.at
  charAt: kre(!0)
}, Rre = Nre.charAt, Fre = er, QE = Di, Bre = Af, ab = Mf, eS = "String Iterator", Lre = QE.set, jre = QE.getterFor(eS);
Bre(String, "String", function(i) {
  Lre(this, {
    type: eS,
    string: Fre(i),
    index: 0
  });
}, function() {
  var e = jre(this), t = e.string, r = e.index, n;
  return r >= t.length ? ab(void 0, !0) : (n = Rre(t, r), e.index += n.length, ab(n, !1));
});
var zre = ie, Wre = zre.Map, Hre = Wre, Vre = Hre, Ure = Vre, Zf = /* @__PURE__ */ U(Ure);
class Gre {
  /**
   * @ignore
   */
  constructor() {
    this.clear(), this._defaultIndex = 0, this._groupIndex = 0, this._defaultGroups = [
      {
        border: "#2B7CE9",
        background: "#97C2FC",
        highlight: {
          border: "#2B7CE9",
          background: "#D2E5FF"
        },
        hover: {
          border: "#2B7CE9",
          background: "#D2E5FF"
        }
      },
      // 0: blue
      {
        border: "#FFA500",
        background: "#FFFF00",
        highlight: {
          border: "#FFA500",
          background: "#FFFFA3"
        },
        hover: {
          border: "#FFA500",
          background: "#FFFFA3"
        }
      },
      // 1: yellow
      {
        border: "#FA0A10",
        background: "#FB7E81",
        highlight: {
          border: "#FA0A10",
          background: "#FFAFB1"
        },
        hover: {
          border: "#FA0A10",
          background: "#FFAFB1"
        }
      },
      // 2: red
      {
        border: "#41A906",
        background: "#7BE141",
        highlight: {
          border: "#41A906",
          background: "#A1EC76"
        },
        hover: {
          border: "#41A906",
          background: "#A1EC76"
        }
      },
      // 3: green
      {
        border: "#E129F0",
        background: "#EB7DF4",
        highlight: {
          border: "#E129F0",
          background: "#F0B3F5"
        },
        hover: {
          border: "#E129F0",
          background: "#F0B3F5"
        }
      },
      // 4: magenta
      {
        border: "#7C29F0",
        background: "#AD85E4",
        highlight: {
          border: "#7C29F0",
          background: "#D3BDF0"
        },
        hover: {
          border: "#7C29F0",
          background: "#D3BDF0"
        }
      },
      // 5: purple
      {
        border: "#C37F00",
        background: "#FFA807",
        highlight: {
          border: "#C37F00",
          background: "#FFCA66"
        },
        hover: {
          border: "#C37F00",
          background: "#FFCA66"
        }
      },
      // 6: orange
      {
        border: "#4220FB",
        background: "#6E6EFD",
        highlight: {
          border: "#4220FB",
          background: "#9B9BFD"
        },
        hover: {
          border: "#4220FB",
          background: "#9B9BFD"
        }
      },
      // 7: darkblue
      {
        border: "#FD5A77",
        background: "#FFC0CB",
        highlight: {
          border: "#FD5A77",
          background: "#FFD1D9"
        },
        hover: {
          border: "#FD5A77",
          background: "#FFD1D9"
        }
      },
      // 8: pink
      {
        border: "#4AD63A",
        background: "#C2FABC",
        highlight: {
          border: "#4AD63A",
          background: "#E6FFE3"
        },
        hover: {
          border: "#4AD63A",
          background: "#E6FFE3"
        }
      },
      // 9: mint
      {
        border: "#990000",
        background: "#EE0000",
        highlight: {
          border: "#BB0000",
          background: "#FF3333"
        },
        hover: {
          border: "#BB0000",
          background: "#FF3333"
        }
      },
      // 10:bright red
      {
        border: "#FF6000",
        background: "#FF6000",
        highlight: {
          border: "#FF6000",
          background: "#FF6000"
        },
        hover: {
          border: "#FF6000",
          background: "#FF6000"
        }
      },
      // 12: real orange
      {
        border: "#97C2FC",
        background: "#2B7CE9",
        highlight: {
          border: "#D2E5FF",
          background: "#2B7CE9"
        },
        hover: {
          border: "#D2E5FF",
          background: "#2B7CE9"
        }
      },
      // 13: blue
      {
        border: "#399605",
        background: "#255C03",
        highlight: {
          border: "#399605",
          background: "#255C03"
        },
        hover: {
          border: "#399605",
          background: "#255C03"
        }
      },
      // 14: green
      {
        border: "#B70054",
        background: "#FF007E",
        highlight: {
          border: "#B70054",
          background: "#FF007E"
        },
        hover: {
          border: "#B70054",
          background: "#FF007E"
        }
      },
      // 15: magenta
      {
        border: "#AD85E4",
        background: "#7C29F0",
        highlight: {
          border: "#D3BDF0",
          background: "#7C29F0"
        },
        hover: {
          border: "#D3BDF0",
          background: "#7C29F0"
        }
      },
      // 16: purple
      {
        border: "#4557FA",
        background: "#000EA1",
        highlight: {
          border: "#6E6EFD",
          background: "#000EA1"
        },
        hover: {
          border: "#6E6EFD",
          background: "#000EA1"
        }
      },
      // 17: darkblue
      {
        border: "#FFC0CB",
        background: "#FD5A77",
        highlight: {
          border: "#FFD1D9",
          background: "#FD5A77"
        },
        hover: {
          border: "#FFD1D9",
          background: "#FD5A77"
        }
      },
      // 18: pink
      {
        border: "#C2FABC",
        background: "#74D66A",
        highlight: {
          border: "#E6FFE3",
          background: "#74D66A"
        },
        hover: {
          border: "#E6FFE3",
          background: "#74D66A"
        }
      },
      // 19: mint
      {
        border: "#EE0000",
        background: "#990000",
        highlight: {
          border: "#FF3333",
          background: "#BB0000"
        },
        hover: {
          border: "#FF3333",
          background: "#BB0000"
        }
      }
      // 20:bright red
    ], this.options = {}, this.defaultOptions = {
      useDefaultGroups: !0
    }, Ce(this.options, this.defaultOptions);
  }
  /**
   *
   * @param {object} options
   */
  setOptions(e) {
    const t = ["useDefaultGroups"];
    if (e !== void 0) {
      for (const r in e)
        if (Object.prototype.hasOwnProperty.call(e, r) && re(t).call(t, r) === -1) {
          const n = e[r];
          this.add(r, n);
        }
    }
  }
  /**
   * Clear all groups
   */
  clear() {
    this._groups = new Zf(), this._groupNames = [];
  }
  /**
   * Get group options of a groupname.
   * If groupname is not found, a new group may be created.
   * @param {*}       groupname     Can be a number, string, Date, etc.
   * @param {boolean} [shouldCreate] If true, create a new group
   * @returns {object} The found or created group
   */
  get(e) {
    let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !0, r = this._groups.get(e);
    if (r === void 0 && t)
      if (this.options.useDefaultGroups === !1 && this._groupNames.length > 0) {
        const n = this._groupIndex % this._groupNames.length;
        ++this._groupIndex, r = {}, r.color = this._groups.get(this._groupNames[n]), this._groups.set(e, r);
      } else {
        const n = this._defaultIndex % this._defaultGroups.length;
        this._defaultIndex++, r = {}, r.color = this._defaultGroups[n], this._groups.set(e, r);
      }
    return r;
  }
  /**
   * Add custom group style.
   * @param {string} groupName - The name of the group, a new group will be
   * created if a group with the same name doesn't exist, otherwise the old
   * groups style will be overwritten.
   * @param {object} style - An object containing borderColor, backgroundColor,
   * etc.
   * @returns {object} The created group object.
   */
  add(e, t) {
    return this._groups.has(e) || this._groupNames.push(e), this._groups.set(e, t), t;
  }
}
var Kre = H;
Kre({ target: "Number", stat: !0 }, {
  isNaN: function(e) {
    return e !== e;
  }
});
var Yre = ie, qre = Yre.Number.isNaN, Xre = qre, Jre = Xre, Zre = Jre, Tu = /* @__PURE__ */ U(Zre), Qre = _e, eie = Qre.isFinite, tie = Number.isFinite || function(e) {
  return typeof e == "number" && eie(e);
}, rie = H, iie = tie;
rie({ target: "Number", stat: !0 }, { isFinite: iie });
var nie = ie, oie = nie.Number.isFinite, sie = oie, aie = sie, lie = aie, ii = /* @__PURE__ */ U(lie), die = H, hie = Kr.some, cie = Yn, uie = cie("some");
die({ target: "Array", proto: !0, forced: !uie }, {
  some: function(e) {
    return hie(this, e, arguments.length > 1 ? arguments[1] : void 0);
  }
});
var fie = Ge, vie = fie("Array").some, pie = ke, gie = vie, cc = Array.prototype, yie = function(i) {
  var e = i.some;
  return i === cc || pie(cc, i) && e === cc.some ? gie : e;
}, mie = yie, bie = mie, $ie = bie, wie = /* @__PURE__ */ U($ie), tS = { exports: {} }, _ie = H, Eie = Ne, lb = $t.f;
_ie({ target: "Object", stat: !0, forced: Object.defineProperty !== lb, sham: !Eie }, {
  defineProperty: lb
});
var Sie = ie, rS = Sie.Object, Oie = tS.exports = function(e, t, r) {
  return rS.defineProperty(e, t, r);
};
rS.defineProperty.sham && (Oie.sham = !0);
var Tie = tS.exports, Iie = Tie, iS = Iie, Pie = iS, xie = Pie, Cie = xie, Aie = Cie, Mie = Aie, Die = /* @__PURE__ */ U(Mie), kie = Ie, Nie = $t.f, db = kie("metadata"), hb = Function.prototype;
hb[db] === void 0 && Nie(hb, db, {
  value: null
});
var Rie = Ee;
Rie("asyncDispose");
var Fie = Ee;
Fie("dispose");
var Bie = Ee;
Bie("metadata");
var Lie = Y_, jie = Lie, zie = jt, Wie = Q, Qf = zie("Symbol"), Hie = Qf.keyFor, Vie = Wie(Qf.prototype.valueOf), nS = Qf.isRegisteredSymbol || function(e) {
  try {
    return Hie(Vie(e)) !== void 0;
  } catch {
    return !1;
  }
}, Uie = H, Gie = nS;
Uie({ target: "Symbol", stat: !0 }, {
  isRegisteredSymbol: Gie
});
var Kie = Vn, oS = jt, Yie = Q, qie = hs, Xie = Ie, ol = oS("Symbol"), cb = ol.isWellKnownSymbol, sS = oS("Object", "getOwnPropertyNames"), Jie = Yie(ol.prototype.valueOf), ub = Kie("wks");
for (var uc = 0, fb = sS(ol), Zie = fb.length; uc < Zie; uc++)
  try {
    var vb = fb[uc];
    qie(ol[vb]) && Xie(vb);
  } catch {
  }
var aS = function(e) {
  if (cb && cb(e)) return !0;
  try {
    for (var t = Jie(e), r = 0, n = sS(ub), o = n.length; r < o; r++)
      if (ub[n[r]] == t) return !0;
  } catch {
  }
  return !1;
}, Qie = H, ene = aS;
Qie({ target: "Symbol", stat: !0, forced: !0 }, {
  isWellKnownSymbol: ene
});
var tne = Ee;
tne("matcher");
var rne = Ee;
rne("observable");
var ine = H, nne = nS;
ine({ target: "Symbol", stat: !0 }, {
  isRegistered: nne
});
var one = H, sne = aS;
one({ target: "Symbol", stat: !0, forced: !0 }, {
  isWellKnown: sne
});
var ane = Ee;
ane("metadataKey");
var lne = Ee;
lne("patternMatch");
var dne = Ee;
dne("replaceAll");
var hne = jie, cne = hne, une = cne, ua = /* @__PURE__ */ U(une), fne = _s, vne = fne.f("iterator"), pne = vne, gne = pne, yne = gne, mne = yne, bne = mne, $ne = bne, wne = $ne, _ne = /* @__PURE__ */ U(wne);
function Ro(i) {
  "@babel/helpers - typeof";
  return Ro = typeof ua == "function" && typeof _ne == "symbol" ? function(e) {
    return typeof e;
  } : function(e) {
    return e && typeof ua == "function" && e.constructor === ua && e !== ua.prototype ? "symbol" : typeof e;
  }, Ro(i);
}
var Ene = _s, Sne = Ene.f("toPrimitive"), One = Sne, Tne = One, Ine = Tne, Pne = Ine, xne = Pne, Cne = xne, Ane = Cne, Mne = /* @__PURE__ */ U(Ane);
function Dne(i, e) {
  if (Ro(i) !== "object" || i === null) return i;
  var t = i[Mne];
  if (t !== void 0) {
    var r = t.call(i, e);
    if (Ro(r) !== "object") return r;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (e === "string" ? String : Number)(i);
}
function kne(i) {
  var e = Dne(i, "string");
  return Ro(e) === "symbol" ? e : String(e);
}
function sd(i, e, t) {
  return e = kne(e), e in i ? Die(i, e, {
    value: t,
    enumerable: !0,
    configurable: !0,
    writable: !0
  }) : i[e] = t, i;
}
var lS = _e, Nne = Z, Rne = Q, Fne = er, Bne = rE.trim, Lne = Df, jne = Rne("".charAt), sl = lS.parseFloat, pb = lS.Symbol, gb = pb && pb.iterator, zne = 1 / sl(Lne + "-0") !== -1 / 0 || gb && !Nne(function() {
  sl(Object(gb));
}), Wne = zne ? function(e) {
  var t = Bne(Fne(e)), r = sl(t);
  return r === 0 && jne(t, 0) === "-" ? -0 : r;
} : sl, Hne = H, yb = Wne;
Hne({ global: !0, forced: parseFloat !== yb }, {
  parseFloat: yb
});
var Vne = ie, Une = Vne.parseFloat, Gne = Une, Kne = Gne, Yne = Kne, dS = /* @__PURE__ */ U(Yne), qne = H, Xne = Z, Jne = Yl.f, Zne = Xne(function() {
  return !Object.getOwnPropertyNames(1);
});
qne({ target: "Object", stat: !0, forced: Zne }, {
  getOwnPropertyNames: Jne
});
var Qne = ie, eoe = Qne.Object, toe = function(e) {
  return eoe.getOwnPropertyNames(e);
}, roe = toe, ioe = roe, noe = ioe, ooe = /* @__PURE__ */ U(noe), soe = ie, aoe = soe.Object.getOwnPropertySymbols, loe = aoe, doe = loe, hoe = doe, jr = /* @__PURE__ */ U(hoe), hS = { exports: {} }, coe = H, uoe = Z, foe = Lt, cS = ns.f, uS = Ne, voe = !uS || uoe(function() {
  cS(1);
});
coe({ target: "Object", stat: !0, forced: voe, sham: !uS }, {
  getOwnPropertyDescriptor: function(e, t) {
    return cS(foe(e), t);
  }
});
var poe = ie, fS = poe.Object, goe = hS.exports = function(e, t) {
  return fS.getOwnPropertyDescriptor(e, t);
};
fS.getOwnPropertyDescriptor.sham && (goe.sham = !0);
var yoe = hS.exports, moe = yoe, boe = moe, $oe = boe, Yr = /* @__PURE__ */ U($oe), woe = H, _oe = Ne, Eoe = RY, Soe = Lt, Ooe = ns, Toe = ys;
woe({ target: "Object", stat: !0, sham: !_oe }, {
  getOwnPropertyDescriptors: function(e) {
    for (var t = Soe(e), r = Ooe.f, n = Eoe(t), o = {}, s = 0, a, l; n.length > s; )
      l = r(t, a = n[s++]), l !== void 0 && Toe(o, a, l);
    return o;
  }
});
var Ioe = ie, Poe = Ioe.Object.getOwnPropertyDescriptors, xoe = Poe, Coe = xoe, Aoe = Coe, zr = /* @__PURE__ */ U(Aoe), vS = { exports: {} }, Moe = H, Doe = Ne, mb = Gl.f;
Moe({ target: "Object", stat: !0, forced: Object.defineProperties !== mb, sham: !Doe }, {
  defineProperties: mb
});
var koe = ie, pS = koe.Object, Noe = vS.exports = function(e, t) {
  return pS.defineProperties(e, t);
};
pS.defineProperties.sham && (Noe.sham = !0);
var Roe = vS.exports, Foe = Roe, Boe = Foe, Loe = Boe, ad = /* @__PURE__ */ U(Loe), joe = iS, ld = /* @__PURE__ */ U(joe);
function ev(i, e) {
  const t = ["node", "edge", "label"];
  let r = !0;
  const n = Or(e, "chosen");
  if (typeof n == "boolean")
    r = n;
  else if (typeof n == "object") {
    if (re(t).call(t, i) === -1)
      throw new Error("choosify: subOption '" + i + "' should be one of '" + t.join("', '") + "'");
    const o = Or(e, ["chosen", i]);
    (typeof o == "boolean" || typeof o == "function") && (r = o);
  }
  return r;
}
function Iu(i, e, t) {
  if (i.width <= 0 || i.height <= 0)
    return !1;
  if (t !== void 0) {
    const o = {
      x: e.x - t.x,
      y: e.y - t.y
    };
    if (t.angle !== 0) {
      const s = -t.angle;
      e = {
        x: Math.cos(s) * o.x - Math.sin(s) * o.y,
        y: Math.sin(s) * o.x + Math.cos(s) * o.y
      };
    } else
      e = o;
  }
  const r = i.x + i.width, n = i.y + i.width;
  return i.left < e.x && r > e.x && i.top < e.y && n > e.y;
}
function al(i) {
  return typeof i == "string" && i !== "";
}
function gS(i, e, t, r) {
  let n = r.x, o = r.y;
  if (typeof r.distanceToBorder == "function") {
    const s = r.distanceToBorder(i, e), a = Math.sin(e) * s, l = Math.cos(e) * s;
    l === s ? (n += s, o = r.y) : a === s ? (n = r.x, o -= s) : (n += l, o -= a);
  } else r.shape.width > r.shape.height ? (n = r.x + r.shape.width * 0.5, o = r.y - t) : (n = r.x + t, o = r.y - r.shape.height * 0.5);
  return {
    x: n,
    y: o
  };
}
var zoe = Ge, Woe = zoe("Array").values, Hoe = Woe, Voe = Hoe, Uoe = Mi, Goe = Ue, Koe = ke, Yoe = Voe, fc = Array.prototype, qoe = {
  DOMTokenList: !0,
  NodeList: !0
}, Xoe = function(i) {
  var e = i.values;
  return i === fc || Koe(fc, i) && e === fc.values || Goe(qoe, Uoe(i)) ? Yoe : e;
}, Joe = Xoe, yS = /* @__PURE__ */ U(Joe);
class Zoe {
  /**
   * @param {MeasureText} measureText
   */
  constructor(e) {
    this.measureText = e, this.current = 0, this.width = 0, this.height = 0, this.lines = [];
  }
  /**
   * Append given text to the given line.
   * @param {number}  l    index of line to add to
   * @param {string}  text string to append to line
   * @param {'bold'|'ital'|'boldital'|'mono'|'normal'} [mod]
   * @private
   */
  _add(e, t) {
    let r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : "normal";
    this.lines[e] === void 0 && (this.lines[e] = {
      width: 0,
      height: 0,
      blocks: []
    });
    let n = t;
    (t === void 0 || t === "") && (n = " ");
    const o = this.measureText(n, r), s = Ce({}, yS(o));
    s.text = t, s.width = o.width, s.mod = r, (t === void 0 || t === "") && (s.width = 0), this.lines[e].blocks.push(s), this.lines[e].width += s.width;
  }
  /**
   * Returns the width in pixels of the current line.
   * @returns {number}
   */
  curWidth() {
    const e = this.lines[this.current];
    return e === void 0 ? 0 : e.width;
  }
  /**
   * Add text in block to current line
   * @param {string} text
   * @param {'bold'|'ital'|'boldital'|'mono'|'normal'} [mod]
   */
  append(e) {
    let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "normal";
    this._add(this.current, e, t);
  }
  /**
   * Add text in block to current line and start a new line
   * @param {string} text
   * @param {'bold'|'ital'|'boldital'|'mono'|'normal'} [mod]
   */
  newLine(e) {
    let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "normal";
    this._add(this.current, e, t), this.current++;
  }
  /**
   * Determine and set the heights of all the lines currently contained in this instance
   *
   * Note that width has already been set.
   * @private
   */
  determineLineHeights() {
    for (let e = 0; e < this.lines.length; e++) {
      const t = this.lines[e];
      let r = 0;
      if (t.blocks !== void 0)
        for (let n = 0; n < t.blocks.length; n++) {
          const o = t.blocks[n];
          r < o.height && (r = o.height);
        }
      t.height = r;
    }
  }
  /**
   * Determine the full size of the label text, as determined by current lines and blocks
   * @private
   */
  determineLabelSize() {
    let e = 0, t = 0;
    for (let r = 0; r < this.lines.length; r++) {
      const n = this.lines[r];
      n.width > e && (e = n.width), t += n.height;
    }
    this.width = e, this.height = t;
  }
  /**
   * Remove all empty blocks and empty lines we don't need
   *
   * This must be done after the width/height determination,
   * so that these are set properly for processing here.
   * @returns {Array<Line>} Lines with empty blocks (and some empty lines) removed
   * @private
   */
  removeEmptyBlocks() {
    const e = [];
    for (let t = 0; t < this.lines.length; t++) {
      const r = this.lines[t];
      if (r.blocks.length === 0 || t === this.lines.length - 1 && r.width === 0)
        continue;
      const n = {};
      Ce(n, r), n.blocks = [];
      let o;
      const s = [];
      for (let a = 0; a < r.blocks.length; a++) {
        const l = r.blocks[a];
        l.width !== 0 ? s.push(l) : o === void 0 && (o = l);
      }
      s.length === 0 && o !== void 0 && s.push(o), n.blocks = s, e.push(n);
    }
    return e;
  }
  /**
   * Set the sizes for all lines and the whole thing.
   * @returns {{width: (number|*), height: (number|*), lines: Array}}
   */
  finalize() {
    this.determineLineHeights(), this.determineLabelSize();
    const e = this.removeEmptyBlocks();
    return {
      width: this.width,
      height: this.height,
      lines: e
    };
  }
}
const Qoe = {
  // HTML
  "<b>": /<b>/,
  "<i>": /<i>/,
  "<code>": /<code>/,
  "</b>": /<\/b>/,
  "</i>": /<\/i>/,
  "</code>": /<\/code>/,
  // Markdown
  "*": /\*/,
  // bold
  _: /_/,
  // ital
  "`": /`/,
  // mono
  afterBold: /[^*]/,
  afterItal: /[^_]/,
  afterMono: /[^`]/
};
class bb {
  /**
   * Create an instance
   * @param {string} text  text to parse for markup
   */
  constructor(e) {
    this.text = e, this.bold = !1, this.ital = !1, this.mono = !1, this.spacing = !1, this.position = 0, this.buffer = "", this.modStack = [], this.blocks = [];
  }
  /**
   * Return the mod label currently on the top of the stack
   * @returns {string}  label of topmost mod
   * @private
   */
  mod() {
    return this.modStack.length === 0 ? "normal" : this.modStack[0];
  }
  /**
   * Return the mod label currently active
   * @returns {string}  label of active mod
   * @private
   */
  modName() {
    if (this.modStack.length === 0) return "normal";
    if (this.modStack[0] === "mono") return "mono";
    if (this.bold && this.ital)
      return "boldital";
    if (this.bold)
      return "bold";
    if (this.ital)
      return "ital";
  }
  /**
   * @private
   */
  emitBlock() {
    this.spacing && (this.add(" "), this.spacing = !1), this.buffer.length > 0 && (this.blocks.push({
      text: this.buffer,
      mod: this.modName()
    }), this.buffer = "");
  }
  /**
   * Output text to buffer
   * @param {string} text  text to add
   * @private
   */
  add(e) {
    e === " " && (this.spacing = !0), this.spacing && (this.buffer += " ", this.spacing = !1), e != " " && (this.buffer += e);
  }
  /**
   * Handle parsing of whitespace
   * @param {string} ch  the character to check
   * @returns {boolean} true if the character was processed as whitespace, false otherwise
   */
  parseWS(e) {
    return /[ \t]/.test(e) ? (this.mono ? this.add(e) : this.spacing = !0, !0) : !1;
  }
  /**
   * @param {string} tagName  label for block type to set
   * @private
   */
  setTag(e) {
    this.emitBlock(), this[e] = !0, this.modStack.unshift(e);
  }
  /**
   * @param {string} tagName  label for block type to unset
   * @private
   */
  unsetTag(e) {
    this.emitBlock(), this[e] = !1, this.modStack.shift();
  }
  /**
   * @param {string} tagName label for block type we are currently processing
   * @param {string|RegExp} tag string to match in text
   * @returns {boolean} true if the tag was processed, false otherwise
   */
  parseStartTag(e, t) {
    return !this.mono && !this[e] && this.match(t) ? (this.setTag(e), !0) : !1;
  }
  /**
   * @param {string|RegExp} tag
   * @param {number} [advance] if set, advance current position in text
   * @returns {boolean} true if match at given position, false otherwise
   * @private
   */
  match(e) {
    let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !0;
    const [r, n] = this.prepareRegExp(e), o = r.test(this.text.substr(this.position, n));
    return o && t && (this.position += n - 1), o;
  }
  /**
   * @param {string} tagName label for block type we are currently processing
   * @param {string|RegExp} tag string to match in text
   * @param {RegExp} [nextTag] regular expression to match for characters *following* the current tag
   * @returns {boolean} true if the tag was processed, false otherwise
   */
  parseEndTag(e, t, r) {
    let n = this.mod() === e;
    return e === "mono" ? n = n && this.mono : n = n && !this.mono, n && this.match(t) ? (r !== void 0 ? (this.position === this.text.length - 1 || this.match(r, !1)) && this.unsetTag(e) : this.unsetTag(e), !0) : !1;
  }
  /**
   * @param {string|RegExp} tag  string to match in text
   * @param {value} value  string to replace tag with, if found at current position
   * @returns {boolean} true if the tag was processed, false otherwise
   */
  replace(e, t) {
    return this.match(e) ? (this.add(t), this.position += length - 1, !0) : !1;
  }
  /**
   * Create a regular expression for the tag if it isn't already one.
   *
   * The return value is an array `[RegExp, number]`, with exactly two value, where:
   * - RegExp is the regular expression to use
   * - number is the lenth of the input string to match
   * @param {string|RegExp} tag  string to match in text
   * @returns {Array}  regular expression to use and length of input string to match
   * @private
   */
  prepareRegExp(e) {
    let t, r;
    if (e instanceof RegExp)
      r = e, t = 1;
    else {
      const n = Qoe[e];
      n !== void 0 ? r = n : r = new RegExp(e), t = e.length;
    }
    return [r, t];
  }
}
class ese {
  /**
   * @param {CanvasRenderingContext2D} ctx Canvas rendering context
   * @param {Label} parent reference to the Label instance using current instance
   * @param {boolean} selected
   * @param {boolean} hover
   */
  constructor(e, t, r, n) {
    this.ctx = e, this.parent = t, this.selected = r, this.hover = n;
    const o = (s, a) => {
      if (s === void 0) return 0;
      const l = this.parent.getFormattingValues(e, r, n, a);
      let d = 0;
      return s !== "" && (d = this.ctx.measureText(s).width), {
        width: d,
        values: l
      };
    };
    this.lines = new Zoe(o);
  }
  /**
   * Split passed text of a label into lines and blocks.
   *
   * # NOTE
   *
   * The handling of spacing is option dependent:
   *
   * - if `font.multi : false`, all spaces are retained
   * - if `font.multi : true`, every sequence of spaces is compressed to a single space
   *
   * This might not be the best way to do it, but this is as it has been working till now.
   * In order not to break existing functionality, for the time being this behaviour will
   * be retained in any code changes.
   * @param {string} text  text to split
   * @returns {Array<line>}
   */
  process(e) {
    if (!al(e))
      return this.lines.finalize();
    const t = this.parent.fontOptions;
    e = e.replace(/\r\n/g, `
`), e = e.replace(/\r/g, `
`);
    const r = String(e).split(`
`), n = r.length;
    if (t.multi)
      for (let o = 0; o < n; o++) {
        const s = this.splitBlocks(r[o], t.multi);
        if (s !== void 0) {
          if (s.length === 0) {
            this.lines.newLine("");
            continue;
          }
          if (t.maxWdt > 0)
            for (let a = 0; a < s.length; a++) {
              const l = s[a].mod, d = s[a].text;
              this.splitStringIntoLines(d, l, !0);
            }
          else
            for (let a = 0; a < s.length; a++) {
              const l = s[a].mod, d = s[a].text;
              this.lines.append(d, l);
            }
          this.lines.newLine();
        }
      }
    else if (t.maxWdt > 0)
      for (let o = 0; o < n; o++)
        this.splitStringIntoLines(r[o]);
    else
      for (let o = 0; o < n; o++)
        this.lines.newLine(r[o]);
    return this.lines.finalize();
  }
  /**
   * normalize the markup system
   * @param {boolean|'md'|'markdown'|'html'} markupSystem
   * @returns {string}
   */
  decodeMarkupSystem(e) {
    let t = "none";
    return e === "markdown" || e === "md" ? t = "markdown" : (e === !0 || e === "html") && (t = "html"), t;
  }
  /**
   *
   * @param {string} text
   * @returns {Array}
   */
  splitHtmlBlocks(e) {
    const t = new bb(e), r = (n) => /&/.test(n) ? (t.replace(t.text, "&lt;", "<") || t.replace(t.text, "&amp;", "&") || t.add("&"), !0) : !1;
    for (; t.position < t.text.length; ) {
      const n = t.text.charAt(t.position);
      t.parseWS(n) || /</.test(n) && (t.parseStartTag("bold", "<b>") || t.parseStartTag("ital", "<i>") || t.parseStartTag("mono", "<code>") || t.parseEndTag("bold", "</b>") || t.parseEndTag("ital", "</i>") || t.parseEndTag("mono", "</code>")) || r(n) || t.add(n), t.position++;
    }
    return t.emitBlock(), t.blocks;
  }
  /**
   *
   * @param {string} text
   * @returns {Array}
   */
  splitMarkdownBlocks(e) {
    const t = new bb(e);
    let r = !0;
    const n = (o) => /\\/.test(o) ? (t.position < this.text.length + 1 && (t.position++, o = this.text.charAt(t.position), / \t/.test(o) ? t.spacing = !0 : (t.add(o), r = !1)), !0) : !1;
    for (; t.position < t.text.length; ) {
      const o = t.text.charAt(t.position);
      t.parseWS(o) || n(o) || (r || t.spacing) && (t.parseStartTag("bold", "*") || t.parseStartTag("ital", "_") || t.parseStartTag("mono", "`")) || t.parseEndTag("bold", "*", "afterBold") || t.parseEndTag("ital", "_", "afterItal") || t.parseEndTag("mono", "`", "afterMono") || (t.add(o), r = !1), t.position++;
    }
    return t.emitBlock(), t.blocks;
  }
  /**
   * Explodes a piece of text into single-font blocks using a given markup
   * @param {string} text
   * @param {boolean|'md'|'markdown'|'html'} markupSystem
   * @returns {Array.<{text: string, mod: string}>}
   * @private
   */
  splitBlocks(e, t) {
    const r = this.decodeMarkupSystem(t);
    if (r === "none")
      return [{
        text: e,
        mod: "normal"
      }];
    if (r === "markdown")
      return this.splitMarkdownBlocks(e);
    if (r === "html")
      return this.splitHtmlBlocks(e);
  }
  /**
   * @param {string} text
   * @returns {boolean} true if text length over the current max with
   * @private
   */
  overMaxWidth(e) {
    const t = this.ctx.measureText(e).width;
    return this.lines.curWidth() + t > this.parent.fontOptions.maxWdt;
  }
  /**
   * Determine the longest part of the sentence which still fits in the
   * current max width.
   * @param {Array} words  Array of strings signifying a text lines
   * @returns {number}      index of first item in string making string go over max
   * @private
   */
  getLongestFit(e) {
    let t = "", r = 0;
    for (; r < e.length; ) {
      const o = t + (t === "" ? "" : " ") + e[r];
      if (this.overMaxWidth(o)) break;
      t = o, r++;
    }
    return r;
  }
  /**
   * Determine the longest part of the string which still fits in the
   * current max width.
   * @param {Array} words Array of strings signifying a text lines
   * @returns {number} index of first item in string making string go over max
   */
  getLongestFitWord(e) {
    let t = 0;
    for (; t < e.length && !this.overMaxWidth(Ut(e).call(e, 0, t)); )
      t++;
    return t;
  }
  /**
   * Split the passed text into lines, according to width constraint (if any).
   *
   * The method assumes that the input string is a single line, i.e. without lines break.
   *
   * This method retains spaces, if still present (case `font.multi: false`).
   * A space which falls on an internal line break, will be replaced by a newline.
   * There is no special handling of tabs; these go along with the flow.
   * @param {string} str
   * @param {string} [mod]
   * @param {boolean} [appendLast]
   * @private
   */
  splitStringIntoLines(e) {
    let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "normal", r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !1;
    this.parent.getFormattingValues(this.ctx, this.selected, this.hover, t), e = e.replace(/^( +)/g, "$1\r"), e = e.replace(/([^\r][^ ]*)( +)/g, "$1\r$2\r");
    let n = e.split("\r");
    for (; n.length > 0; ) {
      let o = this.getLongestFit(n);
      if (o === 0) {
        const s = n[0], a = this.getLongestFitWord(s);
        this.lines.newLine(Ut(s).call(s, 0, a), t), n[0] = Ut(s).call(s, a);
      } else {
        let s = o;
        n[o - 1] === " " ? o-- : n[s] === " " && s++;
        const a = Ut(n).call(n, 0, o).join("");
        o == n.length && r ? this.lines.append(a, t) : this.lines.newLine(a, t), n = Ut(n).call(n, s);
      }
    }
  }
}
const ro = ["bold", "ital", "boldital", "mono"];
class hn {
  /**
   * @param {object} body
   * @param {object} options
   * @param {boolean} [edgelabel]
   */
  constructor(e, t) {
    let r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !1;
    this.body = e, this.pointToSelf = !1, this.baseSize = void 0, this.fontOptions = {}, this.setOptions(t), this.size = {
      top: 0,
      left: 0,
      width: 0,
      height: 0,
      yLine: 0
    }, this.isEdgeLabel = r;
  }
  /**
   * @param {object} options the options of the parent Node-instance
   */
  setOptions(e) {
    if (this.elementOptions = e, this.initFontOptions(e.font), al(e.label) ? this.labelDirty = !0 : e.label = void 0, e.font !== void 0 && e.font !== null) {
      if (typeof e.font == "string")
        this.baseSize = this.fontOptions.size;
      else if (typeof e.font == "object") {
        const t = e.font.size;
        t !== void 0 && (this.baseSize = t);
      }
    }
  }
  /**
   * Init the font Options structure.
   *
   * Member fontOptions serves as an accumulator for the current font options.
   * As such, it needs to be completely separated from the node options.
   * @param {object} newFontOptions the new font options to process
   * @private
   */
  initFontOptions(e) {
    if (X(ro, (t) => {
      this.fontOptions[t] = {};
    }), hn.parseFontString(this.fontOptions, e)) {
      this.fontOptions.vadjust = 0;
      return;
    }
    X(e, (t, r) => {
      t != null && typeof t != "object" && (this.fontOptions[r] = t);
    });
  }
  /**
   * If in-variable is a string, parse it as a font specifier.
   *
   * Note that following is not done here and have to be done after the call:
   * - Not all font options are set (vadjust, mod)
   * @param {object} outOptions  out-parameter, object in which to store the parse results (if any)
   * @param {object} inOptions  font options to parse
   * @returns {boolean} true if font parsed as string, false otherwise
   * @static
   */
  static parseFontString(e, t) {
    if (!t || typeof t != "string") return !1;
    const r = t.split(" ");
    return e.size = +r[0].replace("px", ""), e.face = r[1], e.color = r[2], !0;
  }
  /**
   * Set the width and height constraints based on 'nearest' value
   * @param {Array} pile array of option objects to consider
   * @returns {object} the actual constraint values to use
   * @private
   */
  constrain(e) {
    const t = {
      constrainWidth: !1,
      maxWdt: -1,
      minWdt: -1,
      constrainHeight: !1,
      minHgt: -1,
      valign: "middle"
    }, r = Or(e, "widthConstraint");
    if (typeof r == "number")
      t.maxWdt = Number(r), t.minWdt = Number(r);
    else if (typeof r == "object") {
      const o = Or(e, ["widthConstraint", "maximum"]);
      typeof o == "number" && (t.maxWdt = Number(o));
      const s = Or(e, ["widthConstraint", "minimum"]);
      typeof s == "number" && (t.minWdt = Number(s));
    }
    const n = Or(e, "heightConstraint");
    if (typeof n == "number")
      t.minHgt = Number(n);
    else if (typeof n == "object") {
      const o = Or(e, ["heightConstraint", "minimum"]);
      typeof o == "number" && (t.minHgt = Number(o));
      const s = Or(e, ["heightConstraint", "valign"]);
      typeof s == "string" && (s === "top" || s === "bottom") && (t.valign = s);
    }
    return t;
  }
  /**
   * Set options and update internal state
   * @param {object} options  options to set
   * @param {Array}  pile     array of option objects to consider for option 'chosen'
   */
  update(e, t) {
    this.setOptions(e, !0), this.propagateFonts(t), le(this.fontOptions, this.constrain(t)), this.fontOptions.chooser = ev("label", t);
  }
  /**
   * When margins are set in an element, adjust sizes is called to remove them
   * from the width/height constraints. This must be done prior to label sizing.
   * @param {{top: number, right: number, bottom: number, left: number}} margins
   */
  adjustSizes(e) {
    const t = e ? e.right + e.left : 0;
    this.fontOptions.constrainWidth && (this.fontOptions.maxWdt -= t, this.fontOptions.minWdt -= t);
    const r = e ? e.top + e.bottom : 0;
    this.fontOptions.constrainHeight && (this.fontOptions.minHgt -= r);
  }
  /////////////////////////////////////////////////////////
  // Methods for handling options piles
  // Eventually, these will be moved to a separate class
  /////////////////////////////////////////////////////////
  /**
   * Add the font members of the passed list of option objects to the pile.
   * @param {Pile} dstPile  pile of option objects add to
   * @param {Pile} srcPile  pile of option objects to take font options from
   * @private
   */
  addFontOptionsToPile(e, t) {
    for (let r = 0; r < t.length; ++r)
      this.addFontToPile(e, t[r]);
  }
  /**
   * Add given font option object to the list of objects (the 'pile') to consider for determining
   * multi-font option values.
   * @param {Pile} pile  pile of option objects to use
   * @param {object} options  instance to add to pile
   * @private
   */
  addFontToPile(e, t) {
    if (t === void 0 || t.font === void 0 || t.font === null) return;
    const r = t.font;
    e.push(r);
  }
  /**
   * Collect all own-property values from the font pile that aren't multi-font option objectss.
   * @param {Pile} pile  pile of option objects to use
   * @returns {object} object with all current own basic font properties
   * @private
   */
  getBasicOptions(e) {
    const t = {};
    for (let r = 0; r < e.length; ++r) {
      let n = e[r];
      const o = {};
      hn.parseFontString(o, n) && (n = o), X(n, (s, a) => {
        s !== void 0 && (Object.prototype.hasOwnProperty.call(t, a) || (re(ro).call(ro, a) !== -1 ? t[a] = {} : t[a] = s));
      });
    }
    return t;
  }
  /**
   * Return the value for given option for the given multi-font.
   *
   * All available option objects are trawled in the set order to construct the option values.
   *
   * ---------------------------------------------------------------------
   * ## Traversal of pile for multi-fonts
   *
   * The determination of multi-font option values is a special case, because any values not
   * present in the multi-font options should by definition be taken from the main font options,
   * i.e. from the current 'parent' object of the multi-font option.
   *
   * ### Search order for multi-fonts
   *
   * 'bold' used as example:
   *
   * - search in option group 'bold' in local properties
   * - search in main font option group in local properties
   *
   * ---------------------------------------------------------------------
   * @param {Pile} pile  pile of option objects to use
   * @param {MultiFontStyle} multiName sub path for the multi-font
   * @param {string} option  the option to search for, for the given multi-font
   * @returns {string|number} the value for the given option
   * @private
   */
  getFontOption(e, t, r) {
    let n;
    for (let o = 0; o < e.length; ++o) {
      const s = e[o];
      if (Object.prototype.hasOwnProperty.call(s, t)) {
        if (n = s[t], n == null) continue;
        const a = {};
        if (hn.parseFontString(a, n) && (n = a), Object.prototype.hasOwnProperty.call(n, r))
          return n[r];
      }
    }
    if (Object.prototype.hasOwnProperty.call(this.fontOptions, r))
      return this.fontOptions[r];
    throw new Error("Did not find value for multi-font for property: '" + r + "'");
  }
  /**
   * Return all options values for the given multi-font.
   *
   * All available option objects are trawled in the set order to construct the option values.
   * @param {Pile} pile  pile of option objects to use
   * @param {MultiFontStyle} multiName sub path for the mod-font
   * @returns {MultiFontOptions}
   * @private
   */
  getFontOptions(e, t) {
    const r = {}, n = ["color", "size", "face", "mod", "vadjust"];
    for (let o = 0; o < n.length; ++o) {
      const s = n[o];
      r[s] = this.getFontOption(e, t, s);
    }
    return r;
  }
  /////////////////////////////////////////////////////////
  // End methods for handling options piles
  /////////////////////////////////////////////////////////
  /**
   * Collapse the font options for the multi-font to single objects, from
   * the chain of option objects passed (the 'pile').
   * @param {Pile} pile  sequence of option objects to consider.
   *                     First item in list assumed to be the newly set options.
   */
  propagateFonts(e) {
    const t = [];
    this.addFontOptionsToPile(t, e), this.fontOptions = this.getBasicOptions(t);
    for (let r = 0; r < ro.length; ++r) {
      const n = ro[r], o = this.fontOptions[n], s = this.getFontOptions(t, n);
      X(s, (a, l) => {
        o[l] = a;
      }), o.size = Number(o.size), o.vadjust = Number(o.vadjust);
    }
  }
  /**
   * Main function. This is called from anything that wants to draw a label.
   * @param {CanvasRenderingContext2D} ctx
   * @param {number} x
   * @param {number} y
   * @param {boolean} selected
   * @param {boolean} hover
   * @param {string} [baseline]
   */
  draw(e, t, r, n, o) {
    let s = arguments.length > 5 && arguments[5] !== void 0 ? arguments[5] : "middle";
    if (this.elementOptions.label === void 0) return;
    let a = this.fontOptions.size * this.body.view.scale;
    this.elementOptions.label && a < this.elementOptions.scaling.label.drawThreshold - 1 || (a >= this.elementOptions.scaling.label.maxVisible && (a = Number(this.elementOptions.scaling.label.maxVisible) / this.body.view.scale), this.calculateLabelSize(e, n, o, t, r, s), this._drawBackground(e), this._drawText(e, t, this.size.yLine, s, a));
  }
  /**
   * Draws the label background
   * @param {CanvasRenderingContext2D} ctx
   * @private
   */
  _drawBackground(e) {
    if (this.fontOptions.background !== void 0 && this.fontOptions.background !== "none") {
      e.fillStyle = this.fontOptions.background;
      const t = this.getSize();
      e.fillRect(t.left, t.top, t.width, t.height);
    }
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {number} x
   * @param {number} y
   * @param {string} [baseline]
   * @param {number} viewFontSize
   * @private
   */
  _drawText(e, t, r) {
    let n = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : "middle", o = arguments.length > 4 ? arguments[4] : void 0;
    [t, r] = this._setAlignment(e, t, r, n), e.textAlign = "left", t = t - this.size.width / 2, this.fontOptions.valign && this.size.height > this.size.labelHeight && (this.fontOptions.valign === "top" && (r -= (this.size.height - this.size.labelHeight) / 2), this.fontOptions.valign === "bottom" && (r += (this.size.height - this.size.labelHeight) / 2));
    for (let s = 0; s < this.lineCount; s++) {
      const a = this.lines[s];
      if (a && a.blocks) {
        let l = 0;
        this.isEdgeLabel || this.fontOptions.align === "center" ? l += (this.size.width - a.width) / 2 : this.fontOptions.align === "right" && (l += this.size.width - a.width);
        for (let d = 0; d < a.blocks.length; d++) {
          const h = a.blocks[d];
          e.font = h.font;
          const [c, u] = this._getColor(h.color, o, h.strokeColor);
          h.strokeWidth > 0 && (e.lineWidth = h.strokeWidth, e.strokeStyle = u, e.lineJoin = "round"), e.fillStyle = c, h.strokeWidth > 0 && e.strokeText(h.text, t + l, r + h.vadjust), e.fillText(h.text, t + l, r + h.vadjust), l += h.width;
        }
        r += a.height;
      }
    }
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {number} x
   * @param {number} y
   * @param {string} baseline
   * @returns {Array.<number>}
   * @private
   */
  _setAlignment(e, t, r, n) {
    if (this.isEdgeLabel && this.fontOptions.align !== "horizontal" && this.pointToSelf === !1) {
      t = 0, r = 0;
      const o = 2;
      this.fontOptions.align === "top" ? (e.textBaseline = "alphabetic", r -= 2 * o) : this.fontOptions.align === "bottom" ? (e.textBaseline = "hanging", r += 2 * o) : e.textBaseline = "middle";
    } else
      e.textBaseline = n;
    return [t, r];
  }
  /**
   * fade in when relative scale is between threshold and threshold - 1.
   * If the relative scale would be smaller than threshold -1 the draw function would have returned before coming here.
   * @param {string} color  The font color to use
   * @param {number} viewFontSize
   * @param {string} initialStrokeColor
   * @returns {Array.<string>} An array containing the font color and stroke color
   * @private
   */
  _getColor(e, t, r) {
    let n = e || "#000000", o = r || "#ffffff";
    if (t <= this.elementOptions.scaling.label.drawThreshold) {
      const s = Math.max(0, Math.min(1, 1 - (this.elementOptions.scaling.label.drawThreshold - t)));
      n = St(n, s), o = St(o, s);
    }
    return [n, o];
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {boolean} selected
   * @param {boolean} hover
   * @returns {{width: number, height: number}}
   */
  getTextSize(e) {
    let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1, r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !1;
    return this._processLabel(e, t, r), {
      width: this.size.width,
      height: this.size.height,
      lineCount: this.lineCount
    };
  }
  /**
   * Get the current dimensions of the label
   * @returns {rect}
   */
  getSize() {
    let t = this.size.left, r = this.size.top - 0.5 * 2;
    if (this.isEdgeLabel) {
      const o = -this.size.width * 0.5;
      switch (this.fontOptions.align) {
        case "middle":
          t = o, r = -this.size.height * 0.5;
          break;
        case "top":
          t = o, r = -(this.size.height + 2);
          break;
        case "bottom":
          t = o, r = 2;
          break;
      }
    }
    return {
      left: t,
      top: r,
      width: this.size.width,
      height: this.size.height
    };
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {boolean} selected
   * @param {boolean} hover
   * @param {number} [x]
   * @param {number} [y]
   * @param {'middle'|'hanging'} [baseline]
   */
  calculateLabelSize(e, t, r) {
    let n = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : 0, o = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : 0, s = arguments.length > 5 && arguments[5] !== void 0 ? arguments[5] : "middle";
    this._processLabel(e, t, r), this.size.left = n - this.size.width * 0.5, this.size.top = o - this.size.height * 0.5, this.size.yLine = o + (1 - this.lineCount) * 0.5 * this.fontOptions.size, s === "hanging" && (this.size.top += 0.5 * this.fontOptions.size, this.size.top += 4, this.size.yLine += 4);
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {boolean} selected
   * @param {boolean} hover
   * @param {string} mod
   * @returns {{color, size, face, mod, vadjust, strokeWidth: *, strokeColor: (*|string|allOptions.edges.font.strokeColor|{string}|allOptions.nodes.font.strokeColor|Array)}}
   */
  getFormattingValues(e, t, r, n) {
    const o = function(l, d, h) {
      return d === "normal" ? h === "mod" ? "" : l[h] : l[d][h] !== void 0 ? l[d][h] : l[h];
    }, s = {
      color: o(this.fontOptions, n, "color"),
      size: o(this.fontOptions, n, "size"),
      face: o(this.fontOptions, n, "face"),
      mod: o(this.fontOptions, n, "mod"),
      vadjust: o(this.fontOptions, n, "vadjust"),
      strokeWidth: this.fontOptions.strokeWidth,
      strokeColor: this.fontOptions.strokeColor
    };
    (t || r) && (n === "normal" && this.fontOptions.chooser === !0 && this.elementOptions.labelHighlightBold ? s.mod = "bold" : typeof this.fontOptions.chooser == "function" && this.fontOptions.chooser(s, this.elementOptions.id, t, r));
    let a = "";
    return s.mod !== void 0 && s.mod !== "" && (a += s.mod + " "), a += s.size + "px " + s.face, e.font = a.replace(/"/g, ""), s.font = e.font, s.height = s.size, s;
  }
  /**
   *
   * @param {boolean} selected
   * @param {boolean} hover
   * @returns {boolean}
   */
  differentState(e, t) {
    return e !== this.selectedState || t !== this.hoverState;
  }
  /**
   * This explodes the passed text into lines and determines the width, height and number of lines.
   * @param {CanvasRenderingContext2D} ctx
   * @param {boolean} selected
   * @param {boolean} hover
   * @param {string} inText  the text to explode
   * @returns {{width, height, lines}|*}
   * @private
   */
  _processLabelText(e, t, r, n) {
    return new ese(e, this, t, r).process(n);
  }
  /**
   * This explodes the label string into lines and sets the width, height and number of lines.
   * @param {CanvasRenderingContext2D} ctx
   * @param {boolean} selected
   * @param {boolean} hover
   * @private
   */
  _processLabel(e, t, r) {
    if (this.labelDirty === !1 && !this.differentState(t, r)) return;
    const n = this._processLabelText(e, t, r, this.elementOptions.label);
    this.fontOptions.minWdt > 0 && n.width < this.fontOptions.minWdt && (n.width = this.fontOptions.minWdt), this.size.labelHeight = n.height, this.fontOptions.minHgt > 0 && n.height < this.fontOptions.minHgt && (n.height = this.fontOptions.minHgt), this.lines = n.lines, this.lineCount = n.lines.length, this.size.width = n.width, this.size.height = n.height, this.selectedState = t, this.hoverState = r, this.labelDirty = !1;
  }
  /**
   * Check if this label is visible
   * @returns {boolean} true if this label will be show, false otherwise
   */
  visible() {
    return !(this.size.width === 0 || this.size.height === 0 || this.elementOptions.label === void 0 || this.fontOptions.size * this.body.view.scale < this.elementOptions.scaling.label.drawThreshold - 1);
  }
}
class Ni {
  /**
   * @param {object} options
   * @param {object} body
   * @param {Label} labelModule
   */
  constructor(e, t, r) {
    this.body = t, this.labelModule = r, this.setOptions(e), this.top = void 0, this.left = void 0, this.height = void 0, this.width = void 0, this.radius = void 0, this.margin = void 0, this.refreshNeeded = !0, this.boundingBox = {
      top: 0,
      left: 0,
      right: 0,
      bottom: 0
    };
  }
  /**
   *
   * @param {object} options
   */
  setOptions(e) {
    this.options = e;
  }
  /**
   *
   * @param {Label} labelModule
   * @private
   */
  _setMargins(e) {
    this.margin = {}, this.options.margin && (typeof this.options.margin == "object" ? (this.margin.top = this.options.margin.top, this.margin.right = this.options.margin.right, this.margin.bottom = this.options.margin.bottom, this.margin.left = this.options.margin.left) : (this.margin.top = this.options.margin, this.margin.right = this.options.margin, this.margin.bottom = this.options.margin, this.margin.left = this.options.margin)), e.adjustSizes(this.margin);
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {number} angle
   * @returns {number}
   * @private
   */
  _distanceToBorder(e, t) {
    const r = this.options.borderWidth;
    return e && this.resize(e), Math.min(Math.abs(this.width / 2 / Math.cos(t)), Math.abs(this.height / 2 / Math.sin(t))) + r;
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {ArrowOptions} values
   */
  enableShadow(e, t) {
    t.shadow && (e.shadowColor = t.shadowColor, e.shadowBlur = t.shadowSize, e.shadowOffsetX = t.shadowX, e.shadowOffsetY = t.shadowY);
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {ArrowOptions} values
   */
  disableShadow(e, t) {
    t.shadow && (e.shadowColor = "rgba(0,0,0,0)", e.shadowBlur = 0, e.shadowOffsetX = 0, e.shadowOffsetY = 0);
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {ArrowOptions} values
   */
  enableBorderDashes(e, t) {
    if (t.borderDashes !== !1)
      if (e.setLineDash !== void 0) {
        let r = t.borderDashes;
        r === !0 && (r = [5, 15]), e.setLineDash(r);
      } else
        console.warn("setLineDash is not supported in this browser. The dashed borders cannot be used."), this.options.shapeProperties.borderDashes = !1, t.borderDashes = !1;
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {ArrowOptions} values
   */
  disableBorderDashes(e, t) {
    t.borderDashes !== !1 && (e.setLineDash !== void 0 ? e.setLineDash([0]) : (console.warn("setLineDash is not supported in this browser. The dashed borders cannot be used."), this.options.shapeProperties.borderDashes = !1, t.borderDashes = !1));
  }
  /**
   * Determine if the shape of a node needs to be recalculated.
   * @param {boolean} selected
   * @param {boolean} hover
   * @returns {boolean}
   * @protected
   */
  needsRefresh(e, t) {
    return this.refreshNeeded === !0 ? (this.refreshNeeded = !1, !0) : this.width === void 0 || this.labelModule.differentState(e, t);
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {ArrowOptions} values
   */
  initContextForDraw(e, t) {
    const r = t.borderWidth / this.body.view.scale;
    e.lineWidth = Math.min(this.width, r), e.strokeStyle = t.borderColor, e.fillStyle = t.color;
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {ArrowOptions} values
   */
  performStroke(e, t) {
    const r = t.borderWidth / this.body.view.scale;
    e.save(), r > 0 && (this.enableBorderDashes(e, t), e.stroke(), this.disableBorderDashes(e, t)), e.restore();
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {ArrowOptions} values
   */
  performFill(e, t) {
    e.save(), e.fillStyle = t.color, this.enableShadow(e, t), Ts(e).call(e), this.disableShadow(e, t), e.restore(), this.performStroke(e, t);
  }
  /**
   *
   * @param {number} margin
   * @private
   */
  _addBoundingBoxMargin(e) {
    this.boundingBox.left -= e, this.boundingBox.top -= e, this.boundingBox.bottom += e, this.boundingBox.right += e;
  }
  /**
   * Actual implementation of this method call.
   *
   * Doing it like this makes it easier to override
   * in the child classes.
   * @param {number} x width
   * @param {number} y height
   * @param {CanvasRenderingContext2D} ctx
   * @param {boolean} selected
   * @param {boolean} hover
   * @private
   */
  _updateBoundingBox(e, t, r, n, o) {
    r !== void 0 && this.resize(r, n, o), this.left = e - this.width / 2, this.top = t - this.height / 2, this.boundingBox.left = this.left, this.boundingBox.top = this.top, this.boundingBox.bottom = this.top + this.height, this.boundingBox.right = this.left + this.width;
  }
  /**
   * Default implementation of this method call.
   * This acts as a stub which can be overridden.
   * @param {number} x width
   * @param {number} y height
   * @param {CanvasRenderingContext2D} ctx
   * @param {boolean} selected
   * @param {boolean} hover
   */
  updateBoundingBox(e, t, r, n, o) {
    this._updateBoundingBox(e, t, r, n, o);
  }
  /**
   * Determine the dimensions to use for nodes with an internal label
   *
   * Currently, these are: Circle, Ellipse, Database, Box
   * The other nodes have external labels, and will not call this method
   *
   * If there is no label, decent default values are supplied.
   * @param {CanvasRenderingContext2D} ctx
   * @param {boolean} [selected]
   * @param {boolean} [hover]
   * @returns {{width:number, height:number}}
   */
  getDimensionsFromLabel(e, t, r) {
    this.textSize = this.labelModule.getTextSize(e, t, r);
    let n = this.textSize.width, o = this.textSize.height;
    const s = 14;
    return n === 0 && (n = s, o = s), {
      width: n,
      height: o
    };
  }
}
let tse = class extends Ni {
  /**
   * @param {object} options
   * @param {object} body
   * @param {Label} labelModule
   */
  constructor(e, t, r) {
    super(e, t, r), this._setMargins(r);
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {boolean} [selected]
   * @param {boolean} [hover]
   */
  resize(e) {
    let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : this.selected, r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : this.hover;
    if (this.needsRefresh(t, r)) {
      const n = this.getDimensionsFromLabel(e, t, r);
      this.width = n.width + this.margin.right + this.margin.left, this.height = n.height + this.margin.top + this.margin.bottom, this.radius = this.width / 2;
    }
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {number} x width
   * @param {number} y height
   * @param {boolean} selected
   * @param {boolean} hover
   * @param {ArrowOptions} values
   */
  draw(e, t, r, n, o, s) {
    this.resize(e, n, o), this.left = t - this.width / 2, this.top = r - this.height / 2, this.initContextForDraw(e, s), Z0(e, this.left, this.top, this.width, this.height, s.borderRadius), this.performFill(e, s), this.updateBoundingBox(t, r, e, n, o), this.labelModule.draw(e, this.left + this.textSize.width / 2 + this.margin.left, this.top + this.textSize.height / 2 + this.margin.top, n, o);
  }
  /**
   *
   * @param {number} x width
   * @param {number} y height
   * @param {CanvasRenderingContext2D} ctx
   * @param {boolean} selected
   * @param {boolean} hover
   */
  updateBoundingBox(e, t, r, n, o) {
    this._updateBoundingBox(e, t, r, n, o);
    const s = this.options.shapeProperties.borderRadius;
    this._addBoundingBoxMargin(s);
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {number} angle
   * @returns {number}
   */
  distanceToBorder(e, t) {
    e && this.resize(e);
    const r = this.options.borderWidth;
    return Math.min(Math.abs(this.width / 2 / Math.cos(t)), Math.abs(this.height / 2 / Math.sin(t))) + r;
  }
};
class tv extends Ni {
  /**
   * @param {object} options
   * @param {object} body
   * @param {Label} labelModule
   */
  constructor(e, t, r) {
    super(e, t, r), this.labelOffset = 0, this.selected = !1;
  }
  /**
   *
   * @param {object} options
   * @param {object} [imageObj]
   * @param {object} [imageObjAlt]
   */
  setOptions(e, t, r) {
    this.options = e, t === void 0 && r === void 0 || this.setImages(t, r);
  }
  /**
   * Set the images for this node.
   *
   * The images can be updated after the initial setting of options;
   * therefore, this method needs to be reentrant.
   *
   * For correct working in error cases, it is necessary to properly set
   * field 'nodes.brokenImage' in the options.
   * @param {Image} imageObj  required; main image to show for this node
   * @param {Image|undefined} imageObjAlt optional; image to show when node is selected
   */
  setImages(e, t) {
    t && this.selected ? (this.imageObj = t, this.imageObjAlt = e) : (this.imageObj = e, this.imageObjAlt = t);
  }
  /**
   * Set selection and switch between the base and the selected image.
   *
   * Do the switch only if imageObjAlt exists.
   * @param {boolean} selected value of new selected state for current node
   */
  switchImages(e) {
    const t = e && !this.selected || !e && this.selected;
    if (this.selected = e, this.imageObjAlt !== void 0 && t) {
      const r = this.imageObj;
      this.imageObj = this.imageObjAlt, this.imageObjAlt = r;
    }
  }
  /**
   * Returns Image Padding from node options
   * @returns {{top: number,left: number,bottom: number,right: number}} image padding inside this shape
   * @private
   */
  _getImagePadding() {
    const e = {
      top: 0,
      right: 0,
      bottom: 0,
      left: 0
    };
    if (this.options.imagePadding) {
      const t = this.options.imagePadding;
      typeof t == "object" ? (e.top = t.top, e.right = t.right, e.bottom = t.bottom, e.left = t.left) : (e.top = t, e.right = t, e.bottom = t, e.left = t);
    }
    return e;
  }
  /**
   * Adjust the node dimensions for a loaded image.
   *
   * Pre: this.imageObj is valid
   */
  _resizeImage() {
    let e, t;
    if (this.options.shapeProperties.useImageSize === !1) {
      let r = 1, n = 1;
      this.imageObj.width && this.imageObj.height && (this.imageObj.width > this.imageObj.height ? r = this.imageObj.width / this.imageObj.height : n = this.imageObj.height / this.imageObj.width), e = this.options.size * 2 * r, t = this.options.size * 2 * n;
    } else {
      const r = this._getImagePadding();
      e = this.imageObj.width + r.left + r.right, t = this.imageObj.height + r.top + r.bottom;
    }
    this.width = e, this.height = t, this.radius = 0.5 * this.width;
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {number} x width
   * @param {number} y height
   * @param {ArrowOptions} values
   * @private
   */
  _drawRawCircle(e, t, r, n) {
    this.initContextForDraw(e, n), _f(e, t, r, n.size), this.performFill(e, n);
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {ArrowOptions} values
   * @private
   */
  _drawImageAtPosition(e, t) {
    if (this.imageObj.width != 0) {
      e.globalAlpha = t.opacity !== void 0 ? t.opacity : 1, this.enableShadow(e, t);
      let r = 1;
      this.options.shapeProperties.interpolation === !0 && (r = this.imageObj.width / this.width / this.body.view.scale);
      const n = this._getImagePadding(), o = this.left + n.left, s = this.top + n.top, a = this.width - n.left - n.right, l = this.height - n.top - n.bottom;
      this.imageObj.drawImageAtPosition(e, r, o, s, a, l), this.disableShadow(e, t);
    }
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {number} x width
   * @param {number} y height
   * @param {boolean} selected
   * @param {boolean} hover
   * @private
   */
  _drawImageLabel(e, t, r, n, o) {
    let s = 0;
    if (this.height !== void 0) {
      s = this.height * 0.5;
      const l = this.labelModule.getTextSize(e, n, o);
      l.lineCount >= 1 && (s += l.height / 2);
    }
    const a = r + s;
    this.options.label && (this.labelOffset = s), this.labelModule.draw(e, t, a, n, o, "hanging");
  }
}
let rse = class extends tv {
  /**
   * @param {object} options
   * @param {object} body
   * @param {Label} labelModule
   */
  constructor(e, t, r) {
    super(e, t, r), this._setMargins(r);
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {boolean} [selected]
   * @param {boolean} [hover]
   */
  resize(e) {
    let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : this.selected, r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : this.hover;
    if (this.needsRefresh(t, r)) {
      const n = this.getDimensionsFromLabel(e, t, r), o = Math.max(n.width + this.margin.right + this.margin.left, n.height + this.margin.top + this.margin.bottom);
      this.options.size = o / 2, this.width = o, this.height = o, this.radius = this.width / 2;
    }
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {number} x width
   * @param {number} y height
   * @param {boolean} selected
   * @param {boolean} hover
   * @param {ArrowOptions} values
   */
  draw(e, t, r, n, o, s) {
    this.resize(e, n, o), this.left = t - this.width / 2, this.top = r - this.height / 2, this._drawRawCircle(e, t, r, s), this.updateBoundingBox(t, r), this.labelModule.draw(e, this.left + this.textSize.width / 2 + this.margin.left, r, n, o);
  }
  /**
   *
   * @param {number} x width
   * @param {number} y height
   */
  updateBoundingBox(e, t) {
    this.boundingBox.top = t - this.options.size, this.boundingBox.left = e - this.options.size, this.boundingBox.right = e + this.options.size, this.boundingBox.bottom = t + this.options.size;
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @returns {number}
   */
  distanceToBorder(e) {
    return e && this.resize(e), this.width * 0.5;
  }
};
class ise extends tv {
  /**
   * @param {object} options
   * @param {object} body
   * @param {Label} labelModule
   * @param {Image} imageObj
   * @param {Image} imageObjAlt
   */
  constructor(e, t, r, n, o) {
    super(e, t, r), this.setImages(n, o);
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {boolean} [selected]
   * @param {boolean} [hover]
   */
  resize(e) {
    let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : this.selected, r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : this.hover;
    if (this.imageObj.src === void 0 || this.imageObj.width === void 0 || this.imageObj.height === void 0) {
      const o = this.options.size * 2;
      this.width = o, this.height = o, this.radius = 0.5 * this.width;
      return;
    }
    this.needsRefresh(t, r) && this._resizeImage();
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {number} x width
   * @param {number} y height
   * @param {boolean} selected
   * @param {boolean} hover
   * @param {ArrowOptions} values
   */
  draw(e, t, r, n, o, s) {
    this.switchImages(n), this.resize();
    let a = t, l = r;
    this.options.shapeProperties.coordinateOrigin === "top-left" ? (this.left = t, this.top = r, a += this.width / 2, l += this.height / 2) : (this.left = t - this.width / 2, this.top = r - this.height / 2), this._drawRawCircle(e, a, l, s), e.save(), e.clip(), this._drawImageAtPosition(e, s), e.restore(), this._drawImageLabel(e, a, l, n, o), this.updateBoundingBox(t, r);
  }
  // TODO: compare with Circle.updateBoundingBox(), consolidate? More stuff is happening here
  /**
   *
   * @param {number} x width
   * @param {number} y height
   */
  updateBoundingBox(e, t) {
    this.options.shapeProperties.coordinateOrigin === "top-left" ? (this.boundingBox.top = t, this.boundingBox.left = e, this.boundingBox.right = e + this.options.size * 2, this.boundingBox.bottom = t + this.options.size * 2) : (this.boundingBox.top = t - this.options.size, this.boundingBox.left = e - this.options.size, this.boundingBox.right = e + this.options.size, this.boundingBox.bottom = t + this.options.size), this.boundingBox.left = Math.min(this.boundingBox.left, this.labelModule.size.left), this.boundingBox.right = Math.max(this.boundingBox.right, this.labelModule.size.left + this.labelModule.size.width), this.boundingBox.bottom = Math.max(this.boundingBox.bottom, this.boundingBox.bottom + this.labelOffset);
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @returns {number}
   */
  distanceToBorder(e) {
    return e && this.resize(e), this.width * 0.5;
  }
}
class qr extends Ni {
  /**
   * @param {object} options
   * @param {object} body
   * @param {Label} labelModule
   */
  constructor(e, t, r) {
    super(e, t, r);
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {boolean} [selected]
   * @param {boolean} [hover]
   * @param {object} [values]
   */
  resize(e) {
    let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : this.selected, r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : this.hover, n = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : {
      size: this.options.size
    };
    if (this.needsRefresh(t, r)) {
      var o, s;
      this.labelModule.getTextSize(e, t, r);
      const a = 2 * n.size;
      this.width = (o = this.customSizeWidth) !== null && o !== void 0 ? o : a, this.height = (s = this.customSizeHeight) !== null && s !== void 0 ? s : a, this.radius = 0.5 * this.width;
    }
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {string} shape
   * @param {number} sizeMultiplier - Unused! TODO: Remove next major release
   * @param {number} x
   * @param {number} y
   * @param {boolean} selected
   * @param {boolean} hover
   * @param {ArrowOptions} values
   * @private
   * @returns {object} Callbacks to draw later on higher layers.
   */
  _drawShape(e, t, r, n, o, s, a, l) {
    return this.resize(e, s, a, l), this.left = n - this.width / 2, this.top = o - this.height / 2, this.initContextForDraw(e, l), W8(t)(e, n, o, l.size), this.performFill(e, l), this.options.icon !== void 0 && this.options.icon.code !== void 0 && (e.font = (s ? "bold " : "") + this.height / 2 + "px " + (this.options.icon.face || "FontAwesome"), e.fillStyle = this.options.icon.color || "black", e.textAlign = "center", e.textBaseline = "middle", e.fillText(this.options.icon.code, n, o)), {
      drawExternalLabel: () => {
        if (this.options.label !== void 0) {
          this.labelModule.calculateLabelSize(e, s, a, n, o, "hanging");
          const d = o + 0.5 * this.height + 0.5 * this.labelModule.size.height;
          this.labelModule.draw(e, n, d, s, a, "hanging");
        }
        this.updateBoundingBox(n, o);
      }
    };
  }
  /**
   *
   * @param {number} x
   * @param {number} y
   */
  updateBoundingBox(e, t) {
    this.boundingBox.top = t - this.options.size, this.boundingBox.left = e - this.options.size, this.boundingBox.right = e + this.options.size, this.boundingBox.bottom = t + this.options.size, this.options.label !== void 0 && this.labelModule.size.width > 0 && (this.boundingBox.left = Math.min(this.boundingBox.left, this.labelModule.size.left), this.boundingBox.right = Math.max(this.boundingBox.right, this.labelModule.size.left + this.labelModule.size.width), this.boundingBox.bottom = Math.max(this.boundingBox.bottom, this.boundingBox.bottom + this.labelModule.size.height));
  }
}
function $b(i, e) {
  var t = me(i);
  if (jr) {
    var r = jr(i);
    e && (r = ht(r).call(r, function(n) {
      return Yr(i, n).enumerable;
    })), t.push.apply(t, r);
  }
  return t;
}
function nse(i) {
  for (var e = 1; e < arguments.length; e++) {
    var t, r, n = arguments[e] != null ? arguments[e] : {};
    e % 2 ? se(t = $b(Object(n), !0)).call(t, function(o) {
      sd(i, o, n[o]);
    }) : zr ? ad(i, zr(n)) : se(r = $b(Object(n))).call(r, function(o) {
      ld(i, o, Yr(n, o));
    });
  }
  return i;
}
class ose extends qr {
  /**
   * @param {object} options
   * @param {object} body
   * @param {Label} labelModule
   * @param {Function} ctxRenderer
   */
  constructor(e, t, r, n) {
    super(e, t, r, n), this.ctxRenderer = n;
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {number} x width
   * @param {number} y height
   * @param {boolean} selected
   * @param {boolean} hover
   * @param {ArrowOptions} values
   * @returns {object} Callbacks to draw later on different layers.
   */
  draw(e, t, r, n, o, s) {
    this.resize(e, n, o, s), this.left = t - this.width / 2, this.top = r - this.height / 2, e.save();
    const a = this.ctxRenderer({
      ctx: e,
      id: this.options.id,
      x: t,
      y: r,
      state: {
        selected: n,
        hover: o
      },
      style: nse({}, s),
      label: this.options.label
    });
    if (a.drawNode != null && a.drawNode(), e.restore(), a.drawExternalLabel) {
      const l = a.drawExternalLabel;
      a.drawExternalLabel = () => {
        e.save(), l(), e.restore();
      };
    }
    return a.nodeDimensions && (this.customSizeWidth = a.nodeDimensions.width, this.customSizeHeight = a.nodeDimensions.height), a;
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {number} angle
   * @returns {number}
   */
  distanceToBorder(e, t) {
    return this._distanceToBorder(e, t);
  }
}
class sse extends Ni {
  /**
   * @param {object} options
   * @param {object} body
   * @param {Label} labelModule
   */
  constructor(e, t, r) {
    super(e, t, r), this._setMargins(r);
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {boolean} selected
   * @param {boolean} hover
   */
  resize(e, t, r) {
    if (this.needsRefresh(t, r)) {
      const o = this.getDimensionsFromLabel(e, t, r).width + this.margin.right + this.margin.left;
      this.width = o, this.height = o, this.radius = this.width / 2;
    }
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {number} x width
   * @param {number} y height
   * @param {boolean} selected
   * @param {boolean} hover
   * @param {ArrowOptions} values
   */
  draw(e, t, r, n, o, s) {
    this.resize(e, n, o), this.left = t - this.width / 2, this.top = r - this.height / 2, this.initContextForDraw(e, s), Q0(e, t - this.width / 2, r - this.height / 2, this.width, this.height), this.performFill(e, s), this.updateBoundingBox(t, r, e, n, o), this.labelModule.draw(e, this.left + this.textSize.width / 2 + this.margin.left, this.top + this.textSize.height / 2 + this.margin.top, n, o);
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {number} angle
   * @returns {number}
   */
  distanceToBorder(e, t) {
    return this._distanceToBorder(e, t);
  }
}
let ase = class extends qr {
  /**
   * @param {object} options
   * @param {object} body
   * @param {Label} labelModule
   */
  constructor(e, t, r) {
    super(e, t, r);
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {number} x width
   * @param {number} y height
   * @param {boolean} selected
   * @param {boolean} hover
   * @param {ArrowOptions} values
   * @returns {object} Callbacks to draw later on higher layers.
   */
  draw(e, t, r, n, o, s) {
    return this._drawShape(e, "diamond", 4, t, r, n, o, s);
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {number} angle
   * @returns {number}
   */
  distanceToBorder(e, t) {
    return this._distanceToBorder(e, t);
  }
};
class lse extends qr {
  /**
   * @param {object} options
   * @param {object} body
   * @param {Label} labelModule
   */
  constructor(e, t, r) {
    super(e, t, r);
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {number} x width
   * @param {number} y height
   * @param {boolean} selected
   * @param {boolean} hover
   * @param {ArrowOptions} values
   * @returns {object} Callbacks to draw later on higher layers.
   */
  draw(e, t, r, n, o, s) {
    return this._drawShape(e, "circle", 2, t, r, n, o, s);
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @returns {number}
   */
  distanceToBorder(e) {
    return e && this.resize(e), this.options.size;
  }
}
class wb extends Ni {
  /**
   * @param {object} options
   * @param {object} body
   * @param {Label} labelModule
   */
  constructor(e, t, r) {
    super(e, t, r);
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {boolean} [selected]
   * @param {boolean} [hover]
   */
  resize(e) {
    let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : this.selected, r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : this.hover;
    if (this.needsRefresh(t, r)) {
      const n = this.getDimensionsFromLabel(e, t, r);
      this.height = n.height * 2, this.width = n.width + n.height, this.radius = 0.5 * this.width;
    }
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {number} x width
   * @param {number} y height
   * @param {boolean} selected
   * @param {boolean} hover
   * @param {ArrowOptions} values
   */
  draw(e, t, r, n, o, s) {
    this.resize(e, n, o), this.left = t - this.width * 0.5, this.top = r - this.height * 0.5, this.initContextForDraw(e, s), iu(e, this.left, this.top, this.width, this.height), this.performFill(e, s), this.updateBoundingBox(t, r, e, n, o), this.labelModule.draw(e, t, r, n, o);
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {number} angle
   * @returns {number}
   */
  distanceToBorder(e, t) {
    e && this.resize(e);
    const r = this.width * 0.5, n = this.height * 0.5, o = Math.sin(t) * r, s = Math.cos(t) * n;
    return r * n / Math.sqrt(o * o + s * s);
  }
}
class dse extends Ni {
  /**
   * @param {object} options
   * @param {object} body
   * @param {Label} labelModule
   */
  constructor(e, t, r) {
    super(e, t, r), this._setMargins(r);
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx - Unused.
   * @param {boolean} [selected]
   * @param {boolean} [hover]
   */
  resize(e, t, r) {
    this.needsRefresh(t, r) && (this.iconSize = {
      width: Number(this.options.icon.size),
      height: Number(this.options.icon.size)
    }, this.width = this.iconSize.width + this.margin.right + this.margin.left, this.height = this.iconSize.height + this.margin.top + this.margin.bottom, this.radius = 0.5 * this.width);
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {number} x width
   * @param {number} y height
   * @param {boolean} selected
   * @param {boolean} hover
   * @param {ArrowOptions} values
   * @returns {object} Callbacks to draw later on higher layers.
   */
  draw(e, t, r, n, o, s) {
    return this.resize(e, n, o), this.options.icon.size = this.options.icon.size || 50, this.left = t - this.width / 2, this.top = r - this.height / 2, this._icon(e, t, r, n, o, s), {
      drawExternalLabel: () => {
        this.options.label !== void 0 && this.labelModule.draw(e, this.left + this.iconSize.width / 2 + this.margin.left, r + this.height / 2 + 5, n), this.updateBoundingBox(t, r);
      }
    };
  }
  /**
   *
   * @param {number} x
   * @param {number} y
   */
  updateBoundingBox(e, t) {
    this.boundingBox.top = t - this.options.icon.size * 0.5, this.boundingBox.left = e - this.options.icon.size * 0.5, this.boundingBox.right = e + this.options.icon.size * 0.5, this.boundingBox.bottom = t + this.options.icon.size * 0.5, this.options.label !== void 0 && this.labelModule.size.width > 0 && (this.boundingBox.left = Math.min(this.boundingBox.left, this.labelModule.size.left), this.boundingBox.right = Math.max(this.boundingBox.right, this.labelModule.size.left + this.labelModule.size.width), this.boundingBox.bottom = Math.max(this.boundingBox.bottom, this.boundingBox.bottom + this.labelModule.size.height + 5));
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {number} x width
   * @param {number} y height
   * @param {boolean} selected
   * @param {boolean} hover - Unused
   * @param {ArrowOptions} values
   */
  _icon(e, t, r, n, o, s) {
    const a = Number(this.options.icon.size);
    this.options.icon.code !== void 0 ? (e.font = [
      this.options.icon.weight != null ? this.options.icon.weight : n ? "bold" : "",
      // If the weight is forced (for example to make Font Awesome 5 work
      // properly) substitute slightly bigger size for bold font face.
      (this.options.icon.weight != null && n ? 5 : 0) + a + "px",
      this.options.icon.face
    ].join(" "), e.fillStyle = this.options.icon.color || "black", e.textAlign = "center", e.textBaseline = "middle", this.enableShadow(e, s), e.fillText(this.options.icon.code, t, r), this.disableShadow(e, s)) : console.error("When using the icon shape, you need to define the code in the icon options object. This can be done per node or globally.");
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {number} angle
   * @returns {number}
   */
  distanceToBorder(e, t) {
    return this._distanceToBorder(e, t);
  }
}
let hse = class extends tv {
  /**
   * @param {object} options
   * @param {object} body
   * @param {Label} labelModule
   * @param {Image} imageObj
   * @param {Image} imageObjAlt
   */
  constructor(e, t, r, n, o) {
    super(e, t, r), this.setImages(n, o);
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx - Unused.
   * @param {boolean} [selected]
   * @param {boolean} [hover]
   */
  resize(e) {
    let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : this.selected, r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : this.hover;
    if (this.imageObj.src === void 0 || this.imageObj.width === void 0 || this.imageObj.height === void 0) {
      const o = this.options.size * 2;
      this.width = o, this.height = o;
      return;
    }
    this.needsRefresh(t, r) && this._resizeImage();
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {number} x width
   * @param {number} y height
   * @param {boolean} selected
   * @param {boolean} hover
   * @param {ArrowOptions} values
   */
  draw(e, t, r, n, o, s) {
    e.save(), this.switchImages(n), this.resize();
    let a = t, l = r;
    if (this.options.shapeProperties.coordinateOrigin === "top-left" ? (this.left = t, this.top = r, a += this.width / 2, l += this.height / 2) : (this.left = t - this.width / 2, this.top = r - this.height / 2), this.options.shapeProperties.useBorderWithImage === !0) {
      const d = this.options.borderWidth, h = this.options.borderWidthSelected || 2 * this.options.borderWidth, c = (n ? h : d) / this.body.view.scale;
      e.lineWidth = Math.min(this.width, c), e.beginPath();
      let u = n ? this.options.color.highlight.border : o ? this.options.color.hover.border : this.options.color.border, f = n ? this.options.color.highlight.background : o ? this.options.color.hover.background : this.options.color.background;
      s.opacity !== void 0 && (u = St(u, s.opacity), f = St(f, s.opacity)), e.strokeStyle = u, e.fillStyle = f, e.rect(this.left - 0.5 * e.lineWidth, this.top - 0.5 * e.lineWidth, this.width + e.lineWidth, this.height + e.lineWidth), Ts(e).call(e), this.performStroke(e, s), e.closePath();
    }
    this._drawImageAtPosition(e, s), this._drawImageLabel(e, a, l, n, o), this.updateBoundingBox(t, r), e.restore();
  }
  /**
   *
   * @param {number} x
   * @param {number} y
   */
  updateBoundingBox(e, t) {
    this.resize(), this.options.shapeProperties.coordinateOrigin === "top-left" ? (this.left = e, this.top = t) : (this.left = e - this.width / 2, this.top = t - this.height / 2), this.boundingBox.left = this.left, this.boundingBox.top = this.top, this.boundingBox.bottom = this.top + this.height, this.boundingBox.right = this.left + this.width, this.options.label !== void 0 && this.labelModule.size.width > 0 && (this.boundingBox.left = Math.min(this.boundingBox.left, this.labelModule.size.left), this.boundingBox.right = Math.max(this.boundingBox.right, this.labelModule.size.left + this.labelModule.size.width), this.boundingBox.bottom = Math.max(this.boundingBox.bottom, this.boundingBox.bottom + this.labelOffset));
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {number} angle
   * @returns {number}
   */
  distanceToBorder(e, t) {
    return this._distanceToBorder(e, t);
  }
};
class cse extends qr {
  /**
   * @param {object} options
   * @param {object} body
   * @param {Label} labelModule
   */
  constructor(e, t, r) {
    super(e, t, r);
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {number} x width
   * @param {number} y height
   * @param {boolean} selected
   * @param {boolean} hover
   * @param {ArrowOptions} values
   * @returns {object} Callbacks to draw later on higher layers.
   */
  draw(e, t, r, n, o, s) {
    return this._drawShape(e, "square", 2, t, r, n, o, s);
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {number} angle
   * @returns {number}
   */
  distanceToBorder(e, t) {
    return this._distanceToBorder(e, t);
  }
}
class use extends qr {
  /**
   * @param {object} options
   * @param {object} body
   * @param {Label} labelModule
   */
  constructor(e, t, r) {
    super(e, t, r);
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {number} x width
   * @param {number} y height
   * @param {boolean} selected
   * @param {boolean} hover
   * @param {ArrowOptions} values
   * @returns {object} Callbacks to draw later on higher layers.
   */
  draw(e, t, r, n, o, s) {
    return this._drawShape(e, "hexagon", 4, t, r, n, o, s);
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {number} angle
   * @returns {number}
   */
  distanceToBorder(e, t) {
    return this._distanceToBorder(e, t);
  }
}
class fse extends qr {
  /**
   * @param {object} options
   * @param {object} body
   * @param {Label} labelModule
   */
  constructor(e, t, r) {
    super(e, t, r);
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {number} x width
   * @param {number} y height
   * @param {boolean} selected
   * @param {boolean} hover
   * @param {ArrowOptions} values
   * @returns {object} Callbacks to draw later on higher layers.
   */
  draw(e, t, r, n, o, s) {
    return this._drawShape(e, "star", 4, t, r, n, o, s);
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {number} angle
   * @returns {number}
   */
  distanceToBorder(e, t) {
    return this._distanceToBorder(e, t);
  }
}
class vse extends Ni {
  /**
   * @param {object} options
   * @param {object} body
   * @param {Label} labelModule
   */
  constructor(e, t, r) {
    super(e, t, r), this._setMargins(r);
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {boolean} selected
   * @param {boolean} hover
   */
  resize(e, t, r) {
    this.needsRefresh(t, r) && (this.textSize = this.labelModule.getTextSize(e, t, r), this.width = this.textSize.width + this.margin.right + this.margin.left, this.height = this.textSize.height + this.margin.top + this.margin.bottom, this.radius = 0.5 * this.width);
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {number} x width
   * @param {number} y height
   * @param {boolean} selected
   * @param {boolean} hover
   * @param {ArrowOptions} values
   */
  draw(e, t, r, n, o, s) {
    this.resize(e, n, o), this.left = t - this.width / 2, this.top = r - this.height / 2, this.enableShadow(e, s), this.labelModule.draw(e, this.left + this.textSize.width / 2 + this.margin.left, this.top + this.textSize.height / 2 + this.margin.top, n, o), this.disableShadow(e, s), this.updateBoundingBox(t, r, e, n, o);
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {number} angle
   * @returns {number}
   */
  distanceToBorder(e, t) {
    return this._distanceToBorder(e, t);
  }
}
let pse = class extends qr {
  /**
   * @param {object} options
   * @param {object} body
   * @param {Label} labelModule
   */
  constructor(e, t, r) {
    super(e, t, r);
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {number} x
   * @param {number} y
   * @param {boolean} selected
   * @param {boolean} hover
   * @param {ArrowOptions} values
   * @returns {object} Callbacks to draw later on higher layers.
   */
  draw(e, t, r, n, o, s) {
    return this._drawShape(e, "triangle", 3, t, r, n, o, s);
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {number} angle
   * @returns {number}
   */
  distanceToBorder(e, t) {
    return this._distanceToBorder(e, t);
  }
};
class gse extends qr {
  /**
   * @param {object} options
   * @param {object} body
   * @param {Label} labelModule
   */
  constructor(e, t, r) {
    super(e, t, r);
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {number} x
   * @param {number} y
   * @param {boolean} selected
   * @param {boolean} hover
   * @param {ArrowOptions} values
   * @returns {object} Callbacks to draw later on higher layers.
   */
  draw(e, t, r, n, o, s) {
    return this._drawShape(e, "triangleDown", 3, t, r, n, o, s);
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {number} angle
   * @returns {number}
   */
  distanceToBorder(e, t) {
    return this._distanceToBorder(e, t);
  }
}
function _b(i, e) {
  var t = me(i);
  if (jr) {
    var r = jr(i);
    e && (r = ht(r).call(r, function(n) {
      return Yr(i, n).enumerable;
    })), t.push.apply(t, r);
  }
  return t;
}
function Eb(i) {
  for (var e = 1; e < arguments.length; e++) {
    var t, r, n = arguments[e] != null ? arguments[e] : {};
    e % 2 ? se(t = _b(Object(n), !0)).call(t, function(o) {
      sd(i, o, n[o]);
    }) : zr ? ad(i, zr(n)) : se(r = _b(Object(n))).call(r, function(o) {
      ld(i, o, Yr(n, o));
    });
  }
  return i;
}
class ue {
  /**
   *
   * @param {object} options An object containing options for the node. All
   *                            options are optional, except for the id.
   *                              {number} id     Id of the node. Required
   *                              {string} label  Text label for the node
   *                              {number} x      Horizontal position of the node
   *                              {number} y      Vertical position of the node
   *                              {string} shape  Node shape
   *                              {string} image  An image url
   *                              {string} title  A title text, can be HTML
   *                              {anytype} group A group name or number
   * @param {object} body               Shared state of current network instance
   * @param {Network.Images} imagelist  A list with images. Only needed when the node has an image
   * @param {Groups} grouplist          A list with groups. Needed for retrieving group options
   * @param {object} globalOptions      Current global node options; these serve as defaults for the node instance
   * @param {object} defaultOptions     Global default options for nodes; note that this is also the prototype
   *                                    for parameter `globalOptions`.
   */
  constructor(e, t, r, n, o, s) {
    this.options = Rr(o), this.globalOptions = o, this.defaultOptions = s, this.body = t, this.edges = [], this.id = void 0, this.imagelist = r, this.grouplist = n, this.x = void 0, this.y = void 0, this.baseSize = this.options.size, this.baseFontSize = this.options.font.size, this.predefinedPosition = !1, this.selected = !1, this.hover = !1, this.labelModule = new hn(
      this.body,
      this.options,
      !1
      /* Not edge label */
    ), this.setOptions(e);
  }
  /**
   * Attach a edge to the node
   * @param {Edge} edge
   */
  attachEdge(e) {
    var t;
    re(t = this.edges).call(t, e) === -1 && this.edges.push(e);
  }
  /**
   * Detach a edge from the node
   * @param {Edge} edge
   */
  detachEdge(e) {
    var t;
    const r = re(t = this.edges).call(t, e);
    if (r != -1) {
      var n;
      ar(n = this.edges).call(n, r, 1);
    }
  }
  /**
   * Set or overwrite options for the node
   * @param {object} options an object with options
   * @returns {null|boolean}
   */
  setOptions(e) {
    const t = this.options.shape;
    if (!e)
      return;
    if (typeof e.color < "u" && (this._localColor = e.color), e.id !== void 0 && (this.id = e.id), this.id === void 0)
      throw new Error("Node must have an id");
    ue.checkMass(e, this.id), e.x !== void 0 && (e.x === null ? (this.x = void 0, this.predefinedPosition = !1) : (this.x = Dt(e.x), this.predefinedPosition = !0)), e.y !== void 0 && (e.y === null ? (this.y = void 0, this.predefinedPosition = !1) : (this.y = Dt(e.y), this.predefinedPosition = !0)), e.size !== void 0 && (this.baseSize = e.size), e.value !== void 0 && (e.value = dS(e.value)), ue.parseOptions(this.options, e, !0, this.globalOptions, this.grouplist);
    const r = [e, this.options, this.defaultOptions];
    return this.chooser = ev("node", r), this._load_images(), this.updateLabelModule(e), e.opacity !== void 0 && ue.checkOpacity(e.opacity) && (this.options.opacity = e.opacity), this.updateShape(t), e.hidden !== void 0 || e.physics !== void 0;
  }
  /**
   * Load the images from the options, for the nodes that need them.
   *
   * Images are always loaded, even if they are not used in the current shape.
   * The user may switch to an image shape later on.
   * @private
   */
  _load_images() {
    if ((this.options.shape === "circularImage" || this.options.shape === "image") && this.options.image === void 0)
      throw new Error("Option image must be defined for node type '" + this.options.shape + "'");
    if (this.options.image !== void 0) {
      if (this.imagelist === void 0)
        throw new Error("Internal Error: No images provided");
      if (typeof this.options.image == "string")
        this.imageObj = this.imagelist.load(this.options.image, this.options.brokenImage, this.id);
      else {
        if (this.options.image.unselected === void 0)
          throw new Error("No unselected image provided");
        this.imageObj = this.imagelist.load(this.options.image.unselected, this.options.brokenImage, this.id), this.options.image.selected !== void 0 ? this.imageObjAlt = this.imagelist.load(this.options.image.selected, this.options.brokenImage, this.id) : this.imageObjAlt = void 0;
      }
    }
  }
  /**
   * Check that opacity is only between 0 and 1
   * @param {number} opacity
   * @returns {boolean}
   */
  static checkOpacity(e) {
    return 0 <= e && e <= 1;
  }
  /**
   * Check that origin is 'center' or 'top-left'
   * @param {string} origin
   * @returns {boolean}
   */
  static checkCoordinateOrigin(e) {
    return e === void 0 || e === "center" || e === "top-left";
  }
  /**
   * Copy group option values into the node options.
   *
   * The group options override the global node options, so the copy of group options
   * must happen *after* the global node options have been set.
   *
   * This method must also be called also if the global node options have changed and the group options did not.
   * @param {object} parentOptions
   * @param {object} newOptions  new values for the options, currently only passed in for check
   * @param {object} groupList
   */
  static updateGroupOptions(e, t, r) {
    var n;
    if (r === void 0) return;
    const o = e.group;
    if (t !== void 0 && t.group !== void 0 && o !== t.group)
      throw new Error("updateGroupOptions: group values in options don't match.");
    if (!(typeof o == "number" || typeof o == "string" && o != "")) return;
    const a = r.get(o);
    a.opacity !== void 0 && t.opacity === void 0 && (ue.checkOpacity(a.opacity) || (console.error("Invalid option for node opacity. Value must be between 0 and 1, found: " + a.opacity), a.opacity = void 0));
    const l = ht(n = ooe(t)).call(n, (d) => t[d] != null);
    l.push("font"), il(l, e, a), e.color = _u(e.color);
  }
  /**
   * This process all possible shorthands in the new options and makes sure that the parentOptions are fully defined.
   * Static so it can also be used by the handler.
   * @param {object} parentOptions
   * @param {object} newOptions
   * @param {boolean} [allowDeletion]
   * @param {object} [globalOptions]
   * @param {object} [groupList]
   * @static
   */
  static parseOptions(e, t) {
    let r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !1, n = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : {}, o = arguments.length > 4 ? arguments[4] : void 0;
    if (il(["color", "fixed", "shadow"], e, t, r), ue.checkMass(t), e.opacity !== void 0 && (ue.checkOpacity(e.opacity) || (console.error("Invalid option for node opacity. Value must be between 0 and 1, found: " + e.opacity), e.opacity = void 0)), t.opacity !== void 0 && (ue.checkOpacity(t.opacity) || (console.error("Invalid option for node opacity. Value must be between 0 and 1, found: " + t.opacity), t.opacity = void 0)), t.shapeProperties && !ue.checkCoordinateOrigin(t.shapeProperties.coordinateOrigin) && console.error("Invalid option for node coordinateOrigin, found: " + t.shapeProperties.coordinateOrigin), Et(e, t, "shadow", n), t.color !== void 0 && t.color !== null) {
      const a = _u(t.color);
      kE(e.color, a);
    } else r === !0 && t.color === null && (e.color = Rr(n.color));
    t.fixed !== void 0 && t.fixed !== null && (typeof t.fixed == "boolean" ? (e.fixed.x = t.fixed, e.fixed.y = t.fixed) : (t.fixed.x !== void 0 && typeof t.fixed.x == "boolean" && (e.fixed.x = t.fixed.x), t.fixed.y !== void 0 && typeof t.fixed.y == "boolean" && (e.fixed.y = t.fixed.y))), r === !0 && t.font === null && (e.font = Rr(n.font)), ue.updateGroupOptions(e, t, o), t.scaling !== void 0 && Et(e.scaling, t.scaling, "label", n.scaling);
  }
  /**
   *
   * @returns {{color: *, borderWidth: *, borderColor: *, size: *, borderDashes: (boolean|Array|allOptions.nodes.shapeProperties.borderDashes|{boolean, array}), borderRadius: (number|allOptions.nodes.shapeProperties.borderRadius|{number}|Array), shadow: *, shadowColor: *, shadowSize: *, shadowX: *, shadowY: *}}
   */
  getFormattingValues() {
    const e = {
      color: this.options.color.background,
      opacity: this.options.opacity,
      borderWidth: this.options.borderWidth,
      borderColor: this.options.color.border,
      size: this.options.size,
      borderDashes: this.options.shapeProperties.borderDashes,
      borderRadius: this.options.shapeProperties.borderRadius,
      shadow: this.options.shadow.enabled,
      shadowColor: this.options.shadow.color,
      shadowSize: this.options.shadow.size,
      shadowX: this.options.shadow.x,
      shadowY: this.options.shadow.y
    };
    if (this.selected || this.hover ? this.chooser === !0 ? this.selected ? (this.options.borderWidthSelected != null ? e.borderWidth = this.options.borderWidthSelected : e.borderWidth *= 2, e.color = this.options.color.highlight.background, e.borderColor = this.options.color.highlight.border, e.shadow = this.options.shadow.enabled) : this.hover && (e.color = this.options.color.hover.background, e.borderColor = this.options.color.hover.border, e.shadow = this.options.shadow.enabled) : typeof this.chooser == "function" && (this.chooser(e, this.options.id, this.selected, this.hover), e.shadow === !1 && (e.shadowColor !== this.options.shadow.color || e.shadowSize !== this.options.shadow.size || e.shadowX !== this.options.shadow.x || e.shadowY !== this.options.shadow.y) && (e.shadow = !0)) : e.shadow = this.options.shadow.enabled, this.options.opacity !== void 0) {
      const t = this.options.opacity;
      e.borderColor = St(e.borderColor, t), e.color = St(e.color, t), e.shadowColor = St(e.shadowColor, t);
    }
    return e;
  }
  /**
   *
   * @param {object} options
   */
  updateLabelModule(e) {
    (this.options.label === void 0 || this.options.label === null) && (this.options.label = ""), ue.updateGroupOptions(this.options, Eb(Eb({}, e), {}, {
      color: e && e.color || this._localColor || void 0
    }), this.grouplist);
    const t = this.grouplist.get(this.options.group, !1), r = [
      e,
      // new options
      this.options,
      // current node options, see comment above for prototype
      t,
      // group options, if any
      this.globalOptions,
      // Currently set global node options
      this.defaultOptions
      // Default global node options
    ];
    this.labelModule.update(this.options, r), this.labelModule.baseSize !== void 0 && (this.baseFontSize = this.labelModule.baseSize);
  }
  /**
   *
   * @param {string} currentShape
   */
  updateShape(e) {
    if (e === this.options.shape && this.shape)
      this.shape.setOptions(this.options, this.imageObj, this.imageObjAlt);
    else
      switch (this.options.shape) {
        case "box":
          this.shape = new tse(this.options, this.body, this.labelModule);
          break;
        case "circle":
          this.shape = new rse(this.options, this.body, this.labelModule);
          break;
        case "circularImage":
          this.shape = new ise(this.options, this.body, this.labelModule, this.imageObj, this.imageObjAlt);
          break;
        case "custom":
          this.shape = new ose(this.options, this.body, this.labelModule, this.options.ctxRenderer);
          break;
        case "database":
          this.shape = new sse(this.options, this.body, this.labelModule);
          break;
        case "diamond":
          this.shape = new ase(this.options, this.body, this.labelModule);
          break;
        case "dot":
          this.shape = new lse(this.options, this.body, this.labelModule);
          break;
        case "ellipse":
          this.shape = new wb(this.options, this.body, this.labelModule);
          break;
        case "icon":
          this.shape = new dse(this.options, this.body, this.labelModule);
          break;
        case "image":
          this.shape = new hse(this.options, this.body, this.labelModule, this.imageObj, this.imageObjAlt);
          break;
        case "square":
          this.shape = new cse(this.options, this.body, this.labelModule);
          break;
        case "hexagon":
          this.shape = new use(this.options, this.body, this.labelModule);
          break;
        case "star":
          this.shape = new fse(this.options, this.body, this.labelModule);
          break;
        case "text":
          this.shape = new vse(this.options, this.body, this.labelModule);
          break;
        case "triangle":
          this.shape = new pse(this.options, this.body, this.labelModule);
          break;
        case "triangleDown":
          this.shape = new gse(this.options, this.body, this.labelModule);
          break;
        default:
          this.shape = new wb(this.options, this.body, this.labelModule);
          break;
      }
    this.needsRefresh();
  }
  /**
   * select this node
   */
  select() {
    this.selected = !0, this.needsRefresh();
  }
  /**
   * unselect this node
   */
  unselect() {
    this.selected = !1, this.needsRefresh();
  }
  /**
   * Reset the calculated size of the node, forces it to recalculate its size
   */
  needsRefresh() {
    this.shape.refreshNeeded = !0;
  }
  /**
   * get the title of this node.
   * @returns {string} title    The title of the node, or undefined when no title
   *                           has been set.
   */
  getTitle() {
    return this.options.title;
  }
  /**
   * Calculate the distance to the border of the Node
   * @param {CanvasRenderingContext2D}   ctx
   * @param {number} angle        Angle in radians
   * @returns {number} distance   Distance to the border in pixels
   */
  distanceToBorder(e, t) {
    return this.shape.distanceToBorder(e, t);
  }
  /**
   * Check if this node has a fixed x and y position
   * @returns {boolean}      true if fixed, false if not
   */
  isFixed() {
    return this.options.fixed.x && this.options.fixed.y;
  }
  /**
   * check if this node is selecte
   * @returns {boolean} selected   True if node is selected, else false
   */
  isSelected() {
    return this.selected;
  }
  /**
   * Retrieve the value of the node. Can be undefined
   * @returns {number} value
   */
  getValue() {
    return this.options.value;
  }
  /**
   * Get the current dimensions of the label
   * @returns {rect}
   */
  getLabelSize() {
    return this.labelModule.size();
  }
  /**
   * Adjust the value range of the node. The node will adjust it's size
   * based on its value.
   * @param {number} min
   * @param {number} max
   * @param {number} total
   */
  setValueRange(e, t, r) {
    if (this.options.value !== void 0) {
      const n = this.options.scaling.customScalingFunction(e, t, r, this.options.value), o = this.options.scaling.max - this.options.scaling.min;
      if (this.options.scaling.label.enabled === !0) {
        const s = this.options.scaling.label.max - this.options.scaling.label.min;
        this.options.font.size = this.options.scaling.label.min + n * s;
      }
      this.options.size = this.options.scaling.min + n * o;
    } else
      this.options.size = this.baseSize, this.options.font.size = this.baseFontSize;
    this.updateLabelModule();
  }
  /**
   * Draw this node in the given canvas
   * The 2d context of a HTML canvas can be retrieved by canvas.getContext("2d");
   * @param {CanvasRenderingContext2D}   ctx
   * @returns {object} Callbacks to draw later on higher layers.
   */
  draw(e) {
    const t = this.getFormattingValues();
    return this.shape.draw(e, this.x, this.y, this.selected, this.hover, t) || {};
  }
  /**
   * Update the bounding box of the shape
   * @param {CanvasRenderingContext2D}   ctx
   */
  updateBoundingBox(e) {
    this.shape.updateBoundingBox(this.x, this.y, e);
  }
  /**
   * Recalculate the size of this node in the given canvas
   * The 2d context of a HTML canvas can be retrieved by canvas.getContext("2d");
   * @param {CanvasRenderingContext2D}   ctx
   */
  resize(e) {
    const t = this.getFormattingValues();
    this.shape.resize(e, this.selected, this.hover, t);
  }
  /**
   * Determine all visual elements of this node instance, in which the given
   * point falls within the bounding shape.
   * @param {point} point
   * @returns {Array.<nodeClickItem|nodeLabelClickItem>} list with the items which are on the point
   */
  getItemsOnPoint(e) {
    const t = [];
    return this.labelModule.visible() && Iu(this.labelModule.getSize(), e) && t.push({
      nodeId: this.id,
      labelId: 0
    }), Iu(this.shape.boundingBox, e) && t.push({
      nodeId: this.id
    }), t;
  }
  /**
   * Check if this object is overlapping with the provided object
   * @param {object} obj   an object with parameters left, top, right, bottom
   * @returns {boolean}     True if location is located on node
   */
  isOverlappingWith(e) {
    return this.shape.left < e.right && this.shape.left + this.shape.width > e.left && this.shape.top < e.bottom && this.shape.top + this.shape.height > e.top;
  }
  /**
   * Check if this object is overlapping with the provided object
   * @param {object} obj   an object with parameters left, top, right, bottom
   * @returns {boolean}     True if location is located on node
   */
  isBoundingBoxOverlappingWith(e) {
    return this.shape.boundingBox.left < e.right && this.shape.boundingBox.right > e.left && this.shape.boundingBox.top < e.bottom && this.shape.boundingBox.bottom > e.top;
  }
  /**
   * Check valid values for mass
   *
   * The mass may not be negative or zero. If it is, reset to 1
   * @param {object} options
   * @param {Node.id} id
   * @static
   */
  static checkMass(e, t) {
    if (e.mass !== void 0 && e.mass <= 0) {
      let r = "";
      t !== void 0 && (r = " in node id: " + t), console.error("%cNegative or zero mass disallowed" + r + ", setting mass to 1.", BE), e.mass = 1;
    }
  }
}
class yse {
  /**
   * @param {object} body
   * @param {Images} images
   * @param {Array.<Group>} groups
   * @param {LayoutEngine} layoutEngine
   */
  constructor(e, t, r, n) {
    var o;
    if (this.body = e, this.images = t, this.groups = r, this.layoutEngine = n, this.body.functions.createNode = S(o = this.create).call(o, this), this.nodesListeners = {
      add: (s, a) => {
        this.add(a.items);
      },
      update: (s, a) => {
        this.update(a.items, a.data, a.oldData);
      },
      remove: (s, a) => {
        this.remove(a.items);
      }
    }, this.defaultOptions = {
      borderWidth: 1,
      borderWidthSelected: void 0,
      brokenImage: void 0,
      color: {
        border: "#2B7CE9",
        background: "#97C2FC",
        highlight: {
          border: "#2B7CE9",
          background: "#D2E5FF"
        },
        hover: {
          border: "#2B7CE9",
          background: "#D2E5FF"
        }
      },
      opacity: void 0,
      // number between 0 and 1
      fixed: {
        x: !1,
        y: !1
      },
      font: {
        color: "#343434",
        size: 14,
        // px
        face: "arial",
        background: "none",
        strokeWidth: 0,
        // px
        strokeColor: "#ffffff",
        align: "center",
        vadjust: 0,
        multi: !1,
        bold: {
          mod: "bold"
        },
        boldital: {
          mod: "bold italic"
        },
        ital: {
          mod: "italic"
        },
        mono: {
          mod: "",
          size: 15,
          // px
          face: "monospace",
          vadjust: 2
        }
      },
      group: void 0,
      hidden: !1,
      icon: {
        face: "FontAwesome",
        //'FontAwesome',
        code: void 0,
        //'\uf007',
        size: 50,
        //50,
        color: "#2B7CE9"
        //'#aa00ff'
      },
      image: void 0,
      // --> URL
      imagePadding: {
        // only for image shape
        top: 0,
        right: 0,
        bottom: 0,
        left: 0
      },
      label: void 0,
      labelHighlightBold: !0,
      level: void 0,
      margin: {
        top: 5,
        right: 5,
        bottom: 5,
        left: 5
      },
      mass: 1,
      physics: !0,
      scaling: {
        min: 10,
        max: 30,
        label: {
          enabled: !1,
          min: 14,
          max: 30,
          maxVisible: 30,
          drawThreshold: 5
        },
        customScalingFunction: function(s, a, l, d) {
          if (a === s)
            return 0.5;
          {
            const h = 1 / (a - s);
            return Math.max(0, (d - s) * h);
          }
        }
      },
      shadow: {
        enabled: !1,
        color: "rgba(0,0,0,0.5)",
        size: 10,
        x: 5,
        y: 5
      },
      shape: "ellipse",
      shapeProperties: {
        borderDashes: !1,
        // only for borders
        borderRadius: 6,
        // only for box shape
        interpolation: !0,
        // only for image and circularImage shapes
        useImageSize: !1,
        // only for image and circularImage shapes
        useBorderWithImage: !1,
        // only for image shape
        coordinateOrigin: "center"
        // only for image and circularImage shapes
      },
      size: 25,
      title: void 0,
      value: void 0,
      x: void 0,
      y: void 0
    }, this.defaultOptions.mass <= 0)
      throw "Internal error: mass in defaultOptions of NodesHandler may not be zero or negative";
    this.options = Rr(this.defaultOptions), this.bindEventListeners();
  }
  /**
   * Binds event listeners
   */
  bindEventListeners() {
    var e, t;
    this.body.emitter.on("refreshNodes", S(e = this.refresh).call(e, this)), this.body.emitter.on("refresh", S(t = this.refresh).call(t, this)), this.body.emitter.on("destroy", () => {
      X(this.nodesListeners, (r, n) => {
        this.body.data.nodes && this.body.data.nodes.off(n, r);
      }), delete this.body.functions.createNode, delete this.nodesListeners.add, delete this.nodesListeners.update, delete this.nodesListeners.remove, delete this.nodesListeners;
    });
  }
  /**
   *
   * @param {object} options
   */
  setOptions(e) {
    if (e !== void 0) {
      if (ue.parseOptions(this.options, e), e.opacity !== void 0 && (Tu(e.opacity) || !ii(e.opacity) || e.opacity < 0 || e.opacity > 1 ? console.error("Invalid option for node opacity. Value must be between 0 and 1, found: " + e.opacity) : this.options.opacity = e.opacity), e.shape !== void 0)
        for (const t in this.body.nodes)
          Object.prototype.hasOwnProperty.call(this.body.nodes, t) && this.body.nodes[t].updateShape();
      if (typeof e.font < "u" || typeof e.widthConstraint < "u" || typeof e.heightConstraint < "u")
        for (const t of me(this.body.nodes))
          this.body.nodes[t].updateLabelModule(), this.body.nodes[t].needsRefresh();
      if (e.size !== void 0)
        for (const t in this.body.nodes)
          Object.prototype.hasOwnProperty.call(this.body.nodes, t) && this.body.nodes[t].needsRefresh();
      (e.hidden !== void 0 || e.physics !== void 0) && this.body.emitter.emit("_dataChanged");
    }
  }
  /**
   * Set a data set with nodes for the network
   * @param {Array | DataSet | DataView} nodes         The data containing the nodes.
   * @param {boolean} [doNotEmit] - Suppress data changed event.
   * @private
   */
  setData(e) {
    let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1;
    const r = this.body.data.nodes;
    if (D0("id", e))
      this.body.data.nodes = e;
    else if (be(e))
      this.body.data.nodes = new bn(), this.body.data.nodes.add(e);
    else if (!e)
      this.body.data.nodes = new bn();
    else
      throw new TypeError("Array or DataSet expected");
    if (r && X(this.nodesListeners, function(n, o) {
      r.off(o, n);
    }), this.body.nodes = {}, this.body.data.nodes) {
      const n = this;
      X(this.nodesListeners, function(s, a) {
        n.body.data.nodes.on(a, s);
      });
      const o = this.body.data.nodes.getIds();
      this.add(o, !0);
    }
    t === !1 && this.body.emitter.emit("_dataChanged");
  }
  /**
   * Add nodes
   * @param {number[] | string[]} ids
   * @param {boolean} [doNotEmit]
   * @private
   */
  add(e) {
    let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1, r;
    const n = [];
    for (let o = 0; o < e.length; o++) {
      r = e[o];
      const s = this.body.data.nodes.get(r), a = this.create(s);
      n.push(a), this.body.nodes[r] = a;
    }
    this.layoutEngine.positionInitially(n), t === !1 && this.body.emitter.emit("_dataChanged");
  }
  /**
   * Update existing nodes, or create them when not yet existing
   * @param {number[] | string[]} ids id's of changed nodes
   * @param {Array} changedData array with changed data
   * @param {Array|undefined} oldData optional; array with previous data
   * @private
   */
  update(e, t, r) {
    const n = this.body.nodes;
    let o = !1;
    for (let s = 0; s < e.length; s++) {
      const a = e[s];
      let l = n[a];
      const d = t[s];
      l !== void 0 ? l.setOptions(d) && (o = !0) : (o = !0, l = this.create(d), n[a] = l);
    }
    !o && r !== void 0 && (o = wie(t).call(t, function(s, a) {
      const l = r[a];
      return l && l.level !== s.level;
    })), o === !0 ? this.body.emitter.emit("_dataChanged") : this.body.emitter.emit("_dataUpdated");
  }
  /**
   * Remove existing nodes. If nodes do not exist, the method will just ignore it.
   * @param {number[] | string[]} ids
   * @private
   */
  remove(e) {
    const t = this.body.nodes;
    for (let r = 0; r < e.length; r++) {
      const n = e[r];
      delete t[n];
    }
    this.body.emitter.emit("_dataChanged");
  }
  /**
   * create a node
   * @param {object} properties
   * @param {class} [constructorClass]
   * @returns {*}
   */
  create(e) {
    let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : ue;
    return new t(e, this.body, this.images, this.groups, this.options, this.defaultOptions);
  }
  /**
   *
   * @param {boolean} [clearPositions]
   */
  refresh() {
    let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !1;
    X(this.body.nodes, (t, r) => {
      const n = this.body.data.nodes.get(r);
      n !== void 0 && (e === !0 && t.setOptions({
        x: null,
        y: null
      }), t.setOptions({
        fixed: !1
      }), t.setOptions(n));
    });
  }
  /**
   * Returns the positions of the nodes.
   * @param {Array.<Node.id> | string} [ids]  --> optional, can be array of nodeIds, can be string
   * @returns {{}}
   */
  getPositions(e) {
    const t = {};
    if (e !== void 0) {
      if (be(e) === !0) {
        for (let r = 0; r < e.length; r++)
          if (this.body.nodes[e[r]] !== void 0) {
            const n = this.body.nodes[e[r]];
            t[e[r]] = {
              x: Math.round(n.x),
              y: Math.round(n.y)
            };
          }
      } else if (this.body.nodes[e] !== void 0) {
        const r = this.body.nodes[e];
        t[e] = {
          x: Math.round(r.x),
          y: Math.round(r.y)
        };
      }
    } else
      for (let r = 0; r < this.body.nodeIndices.length; r++) {
        const n = this.body.nodes[this.body.nodeIndices[r]];
        t[this.body.nodeIndices[r]] = {
          x: Math.round(n.x),
          y: Math.round(n.y)
        };
      }
    return t;
  }
  /**
   * Retrieves the x y position of a specific id.
   * @param {string} id The id to retrieve.
   * @throws {TypeError} If no id is included.
   * @throws {ReferenceError} If an invalid id is provided.
   * @returns {{ x: number, y: number }} Returns X, Y canvas position of the node with given id.
   */
  getPosition(e) {
    if (e == null)
      throw new TypeError("No id was specified for getPosition method.");
    if (this.body.nodes[e] == null)
      throw new ReferenceError("NodeId provided for getPosition does not exist. Provided: ".concat(e));
    return {
      x: Math.round(this.body.nodes[e].x),
      y: Math.round(this.body.nodes[e].y)
    };
  }
  /**
   * Load the XY positions of the nodes into the dataset.
   */
  storePositions() {
    const e = [], t = this.body.data.nodes.getDataSet();
    for (const r of t.get()) {
      const n = r.id, o = this.body.nodes[n], s = Math.round(o.x), a = Math.round(o.y);
      (r.x !== s || r.y !== a) && e.push({
        id: n,
        x: s,
        y: a
      });
    }
    t.update(e);
  }
  /**
   * get the bounding box of a node.
   * @param {Node.id} nodeId
   * @returns {j|*}
   */
  getBoundingBox(e) {
    if (this.body.nodes[e] !== void 0)
      return this.body.nodes[e].shape.boundingBox;
  }
  /**
   * Get the Ids of nodes connected to this node.
   * @param {Node.id} nodeId
   * @param {'to'|'from'|undefined} direction values 'from' and 'to' select respectively parent and child nodes only.
   *                                          Any other value returns both parent and child nodes.
   * @returns {Array}
   */
  getConnectedNodes(e, t) {
    const r = [];
    if (this.body.nodes[e] !== void 0) {
      const n = this.body.nodes[e], o = {};
      for (let s = 0; s < n.edges.length; s++) {
        const a = n.edges[s];
        t !== "to" && a.toId == n.id ? o[a.fromId] === void 0 && (r.push(a.fromId), o[a.fromId] = !0) : t !== "from" && a.fromId == n.id && o[a.toId] === void 0 && (r.push(a.toId), o[a.toId] = !0);
      }
    }
    return r;
  }
  /**
   * Get the ids of the edges connected to this node.
   * @param {Node.id} nodeId
   * @returns {*}
   */
  getConnectedEdges(e) {
    const t = [];
    if (this.body.nodes[e] !== void 0) {
      const r = this.body.nodes[e];
      for (let n = 0; n < r.edges.length; n++)
        t.push(r.edges[n].id);
    } else
      console.error("NodeId provided for getConnectedEdges does not exist. Provided: ", e);
    return t;
  }
  /**
   * Move a node.
   * @param {Node.id} nodeId
   * @param {number} x
   * @param {number} y
   */
  moveNode(e, t, r) {
    this.body.nodes[e] !== void 0 ? (this.body.nodes[e].x = Number(t), this.body.nodes[e].y = Number(r), lr(() => {
      this.body.emitter.emit("startSimulation");
    }, 0)) : console.error("Node id supplied to moveNode does not exist. Provided: ", e);
  }
}
var mse = H, Sb = Math.hypot, bse = Math.abs, $se = Math.sqrt, wse = !!Sb && Sb(1 / 0, NaN) !== 1 / 0;
mse({ target: "Math", stat: !0, forced: wse }, {
  // eslint-disable-next-line no-unused-vars -- required for `.length`
  hypot: function(e, t) {
    for (var r = 0, n = 0, o = arguments.length, s = 0, a, l; n < o; )
      a = bse(arguments[n++]), s < a ? (l = s / a, r = r * l * l + 1, s = a) : a > 0 ? (l = a / s, r += l * l) : r += a;
    return s === 1 / 0 ? 1 / 0 : s * $se(r);
  }
});
var _se = ie, Ese = _se.Math.hypot, Sse = Ese, Ose = Sse, Tse = Ose, Ise = /* @__PURE__ */ U(Tse);
class Te {
  /**
   * Apply transformation on points for display.
   *
   * The following is done:
   * - rotate by the specified angle
   * - multiply the (normalized) coordinates by the passed length
   * - offset by the target coordinates
   * @param points - The point(s) to be transformed.
   * @param arrowData - The data determining the result of the transformation.
   */
  static transform(e, t) {
    be(e) || (e = [e]);
    const r = t.point.x, n = t.point.y, o = t.angle, s = t.length;
    for (let a = 0; a < e.length; ++a) {
      const l = e[a], d = l.x * Math.cos(o) - l.y * Math.sin(o), h = l.x * Math.sin(o) + l.y * Math.cos(o);
      l.x = r + s * d, l.y = n + s * h;
    }
  }
  /**
   * Draw a closed path using the given real coordinates.
   * @param ctx - The path will be rendered into this context.
   * @param points - The points of the path.
   */
  static drawPath(e, t) {
    e.beginPath(), e.moveTo(t[0].x, t[0].y);
    for (let r = 1; r < t.length; ++r)
      e.lineTo(t[r].x, t[r].y);
    e.closePath();
  }
}
let Pse = class extends Te {
  /**
   * Draw this shape at the end of a line.
   * @param ctx - The shape will be rendered into this context.
   * @param arrowData - The data determining the shape.
   * @returns False as there is no way to fill an image.
   */
  static draw(e, t) {
    if (t.image) {
      e.save(), e.translate(t.point.x, t.point.y), e.rotate(Math.PI / 2 + t.angle);
      const r = t.imageWidth != null ? t.imageWidth : t.image.width, n = t.imageHeight != null ? t.imageHeight : t.image.height;
      t.image.drawImageAtPosition(
        e,
        1,
        // scale
        -r / 2,
        // x
        0,
        // y
        r,
        n
      ), e.restore();
    }
    return !1;
  }
};
class xse extends Te {
  /**
   * Draw this shape at the end of a line.
   * @param ctx - The shape will be rendered into this context.
   * @param arrowData - The data determining the shape.
   * @returns True because ctx.fill() can be used to fill the arrow.
   */
  static draw(e, t) {
    const r = [{
      x: 0,
      y: 0
    }, {
      x: -1,
      y: 0.3
    }, {
      x: -0.9,
      y: 0
    }, {
      x: -1,
      y: -0.3
    }];
    return Te.transform(r, t), Te.drawPath(e, r), !0;
  }
}
class Cse {
  /**
   * Draw this shape at the end of a line.
   * @param ctx - The shape will be rendered into this context.
   * @param arrowData - The data determining the shape.
   * @returns True because ctx.fill() can be used to fill the arrow.
   */
  static draw(e, t) {
    const r = [{
      x: -1,
      y: 0
    }, {
      x: 0,
      y: 0.3
    }, {
      x: -0.4,
      y: 0
    }, {
      x: 0,
      y: -0.3
    }];
    return Te.transform(r, t), Te.drawPath(e, r), !0;
  }
}
class Ase {
  /**
   * Draw this shape at the end of a line.
   * @param ctx - The shape will be rendered into this context.
   * @param arrowData - The data determining the shape.
   * @returns True because ctx.fill() can be used to fill the arrow.
   */
  static draw(e, t) {
    const r = {
      x: -0.4,
      y: 0
    };
    Te.transform(r, t), e.strokeStyle = e.fillStyle, e.fillStyle = "rgba(0, 0, 0, 0)";
    const n = Math.PI, o = t.angle - n / 2, s = t.angle + n / 2;
    return e.beginPath(), e.arc(r.x, r.y, t.length * 0.4, o, s, !1), e.stroke(), !0;
  }
}
class Mse {
  /**
   * Draw this shape at the end of a line.
   * @param ctx - The shape will be rendered into this context.
   * @param arrowData - The data determining the shape.
   * @returns True because ctx.fill() can be used to fill the arrow.
   */
  static draw(e, t) {
    const r = {
      x: -0.3,
      y: 0
    };
    Te.transform(r, t), e.strokeStyle = e.fillStyle, e.fillStyle = "rgba(0, 0, 0, 0)";
    const n = Math.PI, o = t.angle + n / 2, s = t.angle + 3 * n / 2;
    return e.beginPath(), e.arc(r.x, r.y, t.length * 0.4, o, s, !1), e.stroke(), !0;
  }
}
class Dse {
  /**
   * Draw this shape at the end of a line.
   * @param ctx - The shape will be rendered into this context.
   * @param arrowData - The data determining the shape.
   * @returns True because ctx.fill() can be used to fill the arrow.
   */
  static draw(e, t) {
    const r = [{
      x: 0.02,
      y: 0
    }, {
      x: -1,
      y: 0.3
    }, {
      x: -1,
      y: -0.3
    }];
    return Te.transform(r, t), Te.drawPath(e, r), !0;
  }
}
class kse {
  /**
   * Draw this shape at the end of a line.
   * @param ctx - The shape will be rendered into this context.
   * @param arrowData - The data determining the shape.
   * @returns True because ctx.fill() can be used to fill the arrow.
   */
  static draw(e, t) {
    const r = [{
      x: 0,
      y: 0.3
    }, {
      x: 0,
      y: -0.3
    }, {
      x: -1,
      y: 0
    }];
    return Te.transform(r, t), Te.drawPath(e, r), !0;
  }
}
class Nse {
  /**
   * Draw this shape at the end of a line.
   * @param ctx - The shape will be rendered into this context.
   * @param arrowData - The data determining the shape.
   * @returns True because ctx.fill() can be used to fill the arrow.
   */
  static draw(e, t) {
    const r = {
      x: -0.4,
      y: 0
    };
    return Te.transform(r, t), _f(e, r.x, r.y, t.length * 0.4), !0;
  }
}
class Rse {
  /**
   * Draw this shape at the end of a line.
   * @param ctx - The shape will be rendered into this context.
   * @param arrowData - The data determining the shape.
   * @returns True because ctx.fill() can be used to fill the arrow.
   */
  static draw(e, t) {
    const r = [{
      x: 0,
      y: 0.5
    }, {
      x: 0,
      y: -0.5
    }, {
      x: -0.15,
      y: -0.5
    }, {
      x: -0.15,
      y: 0.5
    }];
    return Te.transform(r, t), Te.drawPath(e, r), !0;
  }
}
class Fse {
  /**
   * Draw this shape at the end of a line.
   * @param ctx - The shape will be rendered into this context.
   * @param arrowData - The data determining the shape.
   * @returns True because ctx.fill() can be used to fill the arrow.
   */
  static draw(e, t) {
    const r = [{
      x: 0,
      y: 0.3
    }, {
      x: 0,
      y: -0.3
    }, {
      x: -0.6,
      y: -0.3
    }, {
      x: -0.6,
      y: 0.3
    }];
    return Te.transform(r, t), Te.drawPath(e, r), !0;
  }
}
class Bse {
  /**
   * Draw this shape at the end of a line.
   * @param ctx - The shape will be rendered into this context.
   * @param arrowData - The data determining the shape.
   * @returns True because ctx.fill() can be used to fill the arrow.
   */
  static draw(e, t) {
    const r = [{
      x: 0,
      y: 0
    }, {
      x: -0.5,
      y: -0.3
    }, {
      x: -1,
      y: 0
    }, {
      x: -0.5,
      y: 0.3
    }];
    return Te.transform(r, t), Te.drawPath(e, r), !0;
  }
}
class Lse {
  /**
   * Draw this shape at the end of a line.
   * @param ctx - The shape will be rendered into this context.
   * @param arrowData - The data determining the shape.
   * @returns True because ctx.fill() can be used to fill the arrow.
   */
  static draw(e, t) {
    const r = [{
      x: -1,
      y: 0.3
    }, {
      x: -0.5,
      y: 0
    }, {
      x: -1,
      y: -0.3
    }, {
      x: 0,
      y: 0
    }];
    return Te.transform(r, t), Te.drawPath(e, r), !0;
  }
}
class mS {
  /**
   * Draw an endpoint.
   * @param ctx - The shape will be rendered into this context.
   * @param arrowData - The data determining the shape.
   * @returns True if ctx.fill() can be used to fill the arrow, false otherwise.
   */
  static draw(e, t) {
    let r;
    switch (t.type && (r = t.type.toLowerCase()), r) {
      case "image":
        return Pse.draw(e, t);
      case "circle":
        return Nse.draw(e, t);
      case "box":
        return Fse.draw(e, t);
      case "crow":
        return Cse.draw(e, t);
      case "curve":
        return Ase.draw(e, t);
      case "diamond":
        return Bse.draw(e, t);
      case "inv_curve":
        return Mse.draw(e, t);
      case "triangle":
        return Dse.draw(e, t);
      case "inv_triangle":
        return kse.draw(e, t);
      case "bar":
        return Rse.draw(e, t);
      case "vee":
        return Lse.draw(e, t);
      case "arrow":
      default:
        return xse.draw(e, t);
    }
  }
}
function Ob(i, e) {
  var t = me(i);
  if (jr) {
    var r = jr(i);
    e && (r = ht(r).call(r, function(n) {
      return Yr(i, n).enumerable;
    })), t.push.apply(t, r);
  }
  return t;
}
function Tb(i) {
  for (var e = 1; e < arguments.length; e++) {
    var t, r, n = arguments[e] != null ? arguments[e] : {};
    e % 2 ? se(t = Ob(Object(n), !0)).call(t, function(o) {
      sd(i, o, n[o]);
    }) : zr ? ad(i, zr(n)) : se(r = Ob(Object(n))).call(r, function(o) {
      ld(i, o, Yr(n, o));
    });
  }
  return i;
}
class bS {
  /**
   * Create a new instance.
   * @param options - The options object of given edge.
   * @param _body - The body of the network.
   * @param _labelModule - Label module.
   */
  constructor(e, t, r) {
    this._body = t, this._labelModule = r, this.color = {}, this.colorDirty = !0, this.hoverWidth = 1.5, this.selectionWidth = 2, this.setOptions(e), this.fromPoint = this.from, this.toPoint = this.to;
  }
  /** @inheritDoc */
  connect() {
    this.from = this._body.nodes[this.options.from], this.to = this._body.nodes[this.options.to];
  }
  /** @inheritDoc */
  cleanup() {
    return !1;
  }
  /**
   * Set new edge options.
   * @param options - The new edge options object.
   */
  setOptions(e) {
    this.options = e, this.from = this._body.nodes[this.options.from], this.to = this._body.nodes[this.options.to], this.id = this.options.id;
  }
  /** @inheritDoc */
  drawLine(e, t, r, n) {
    let o = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : this.getViaNode();
    e.strokeStyle = this.getColor(e, t), e.lineWidth = t.width, t.dashes !== !1 ? this._drawDashedLine(e, t, o) : this._drawLine(e, t, o);
  }
  /**
   * Draw a line with given style between two nodes through supplied node(s).
   * @param ctx - The context that will be used for rendering.
   * @param values - Formatting values like color, opacity or shadow.
   * @param viaNode - Additional control point(s) for the edge.
   * @param fromPoint - TODO: Seems ignored, remove?
   * @param toPoint - TODO: Seems ignored, remove?
   */
  _drawLine(e, t, r, n, o) {
    if (this.from != this.to)
      this._line(e, t, r, n, o);
    else {
      const [s, a, l] = this._getCircleData(e);
      this._circle(e, t, s, a, l);
    }
  }
  /**
   * Draw a dashed line with given style between two nodes through supplied node(s).
   * @param ctx - The context that will be used for rendering.
   * @param values - Formatting values like color, opacity or shadow.
   * @param viaNode - Additional control point(s) for the edge.
   * @param _fromPoint - Ignored (TODO: remove in the future).
   * @param _toPoint - Ignored (TODO: remove in the future).
   */
  _drawDashedLine(e, t, r, n, o) {
    e.lineCap = "round";
    const s = be(t.dashes) ? t.dashes : [5, 5];
    if (e.setLineDash !== void 0) {
      if (e.save(), e.setLineDash(s), e.lineDashOffset = 0, this.from != this.to)
        this._line(e, t, r);
      else {
        const [a, l, d] = this._getCircleData(e);
        this._circle(e, t, a, l, d);
      }
      e.setLineDash([0]), e.lineDashOffset = 0, e.restore();
    } else {
      if (this.from != this.to)
        e_(e, this.from.x, this.from.y, this.to.x, this.to.y, s);
      else {
        const [a, l, d] = this._getCircleData(e);
        this._circle(e, t, a, l, d);
      }
      this.enableShadow(e, t), e.stroke(), this.disableShadow(e, t);
    }
  }
  /**
   * Find the intersection between the border of the node and the edge.
   * @param node - The node (either from or to node of the edge).
   * @param ctx - The context that will be used for rendering.
   * @param options - Additional options.
   * @returns Cartesian coordinates of the intersection between the border of the node and the edge.
   */
  findBorderPosition(e, t, r) {
    return this.from != this.to ? this._findBorderPosition(e, t, r) : this._findBorderPositionCircle(e, t, r);
  }
  /** @inheritDoc */
  findBorderPositions(e) {
    if (this.from != this.to)
      return {
        from: this._findBorderPosition(this.from, e),
        to: this._findBorderPosition(this.to, e)
      };
    {
      var t;
      const [r, n] = Ut(t = this._getCircleData(e)).call(t, 0, 2);
      return {
        from: this._findBorderPositionCircle(this.from, e, {
          x: r,
          y: n,
          low: 0.25,
          high: 0.6,
          direction: -1
        }),
        to: this._findBorderPositionCircle(this.from, e, {
          x: r,
          y: n,
          low: 0.6,
          high: 0.8,
          direction: 1
        })
      };
    }
  }
  /**
   * Compute the center point and radius of an edge connected to the same node at both ends.
   * @param ctx - The context that will be used for rendering.
   * @returns `[x, y, radius]`
   */
  _getCircleData(e) {
    const t = this.options.selfReference.size;
    e !== void 0 && this.from.shape.width === void 0 && this.from.shape.resize(e);
    const r = gS(e, this.options.selfReference.angle, t, this.from);
    return [r.x, r.y, t];
  }
  /**
   * Get a point on a circle.
   * @param x - Center of the circle on the x axis.
   * @param y - Center of the circle on the y axis.
   * @param radius - Radius of the circle.
   * @param position - Value between 0 (line start) and 1 (line end).
   * @returns Cartesian coordinates of requested point on the circle.
   */
  _pointOnCircle(e, t, r, n) {
    const o = n * 2 * Math.PI;
    return {
      x: e + r * Math.cos(o),
      y: t - r * Math.sin(o)
    };
  }
  /**
   * Find the intersection between the border of the node and the edge.
   * @remarks
   * This function uses binary search to look for the point where the circle crosses the border of the node.
   * @param nearNode - The node (either from or to node of the edge).
   * @param ctx - The context that will be used for rendering.
   * @param options - Additional options.
   * @returns Cartesian coordinates of the intersection between the border of the node and the edge.
   */
  _findBorderPositionCircle(e, t, r) {
    const n = r.x, o = r.y;
    let s = r.low, a = r.high;
    const l = r.direction, d = 10, h = this.options.selfReference.size, c = 0.05;
    let u, f = (s + a) * 0.5, v = 0;
    this.options.arrowStrikethrough === !0 && (l === -1 ? v = this.options.endPointOffset.from : l === 1 && (v = this.options.endPointOffset.to));
    let y = 0;
    do {
      f = (s + a) * 0.5, u = this._pointOnCircle(n, o, h, f);
      const g = Math.atan2(e.y - u.y, e.x - u.x), p = e.distanceToBorder(t, g) + v, m = Math.sqrt(Math.pow(u.x - e.x, 2) + Math.pow(u.y - e.y, 2)), $ = p - m;
      if (Math.abs($) < c)
        break;
      $ > 0 ? l > 0 ? s = f : a = f : l > 0 ? a = f : s = f, ++y;
    } while (s <= a && y < d);
    return Tb(Tb({}, u), {}, {
      t: f
    });
  }
  /**
   * Get the line width of the edge. Depends on width and whether one of the connected nodes is selected.
   * @param selected - Determines wheter the line is selected.
   * @param hover - Determines wheter the line is being hovered, only applies if selected is false.
   * @returns The width of the line.
   */
  getLineWidth(e, t) {
    return e === !0 ? Math.max(this.selectionWidth, 0.3 / this._body.view.scale) : t === !0 ? Math.max(this.hoverWidth, 0.3 / this._body.view.scale) : Math.max(this.options.width, 0.3 / this._body.view.scale);
  }
  /**
   * Compute the color or gradient for given edge.
   * @param ctx - The context that will be used for rendering.
   * @param values - Formatting values like color, opacity or shadow.
   * @param _selected - Ignored (TODO: remove in the future).
   * @param _hover - Ignored (TODO: remove in the future).
   * @returns Color string if single color is inherited or gradient if two.
   */
  getColor(e, t) {
    if (t.inheritsColor !== !1) {
      if (t.inheritsColor === "both" && this.from.id !== this.to.id) {
        const r = e.createLinearGradient(this.from.x, this.from.y, this.to.x, this.to.y);
        let n = this.from.options.color.highlight.border, o = this.to.options.color.highlight.border;
        return this.from.selected === !1 && this.to.selected === !1 ? (n = St(this.from.options.color.border, t.opacity), o = St(this.to.options.color.border, t.opacity)) : this.from.selected === !0 && this.to.selected === !1 ? o = this.to.options.color.border : this.from.selected === !1 && this.to.selected === !0 && (n = this.from.options.color.border), r.addColorStop(0, n), r.addColorStop(1, o), r;
      }
      return t.inheritsColor === "to" ? St(this.to.options.color.border, t.opacity) : St(this.from.options.color.border, t.opacity);
    } else
      return St(t.color, t.opacity);
  }
  /**
   * Draw a line from a node to itself, a circle.
   * @param ctx - The context that will be used for rendering.
   * @param values - Formatting values like color, opacity or shadow.
   * @param x - Center of the circle on the x axis.
   * @param y - Center of the circle on the y axis.
   * @param radius - Radius of the circle.
   */
  _circle(e, t, r, n, o) {
    this.enableShadow(e, t);
    let s = 0, a = Math.PI * 2;
    if (!this.options.selfReference.renderBehindTheNode) {
      const l = this.options.selfReference.angle, d = this.options.selfReference.angle + Math.PI, h = this._findBorderPositionCircle(this.from, e, {
        x: r,
        y: n,
        low: l,
        high: d,
        direction: -1
      }), c = this._findBorderPositionCircle(this.from, e, {
        x: r,
        y: n,
        low: l,
        high: d,
        direction: 1
      });
      s = Math.atan2(h.y - n, h.x - r), a = Math.atan2(c.y - n, c.x - r);
    }
    e.beginPath(), e.arc(r, n, o, s, a, !1), e.stroke(), this.disableShadow(e, t);
  }
  /**
   * @inheritDoc
   * @remarks
   * http://stackoverflow.com/questions/849211/shortest-distancae-between-a-point-and-a-line-segment
   */
  getDistanceToEdge(e, t, r, n, o, s) {
    if (this.from != this.to)
      return this._getDistanceToEdge(e, t, r, n, o, s);
    {
      const [a, l, d] = this._getCircleData(void 0), h = a - o, c = l - s;
      return Math.abs(Math.sqrt(h * h + c * c) - d);
    }
  }
  /**
   * Calculate the distance between a point (x3, y3) and a line segment from (x1, y1) to (x2, y2).
   * @param x1 - First end of the line segment on the x axis.
   * @param y1 - First end of the line segment on the y axis.
   * @param x2 - Second end of the line segment on the x axis.
   * @param y2 - Second end of the line segment on the y axis.
   * @param x3 - Position of the point on the x axis.
   * @param y3 - Position of the point on the y axis.
   * @returns The distance between the line segment and the point.
   */
  _getDistanceToLine(e, t, r, n, o, s) {
    const a = r - e, l = n - t, d = a * a + l * l;
    let h = ((o - e) * a + (s - t) * l) / d;
    h > 1 ? h = 1 : h < 0 && (h = 0);
    const c = e + h * a, u = t + h * l, f = c - o, v = u - s;
    return Math.sqrt(f * f + v * v);
  }
  /** @inheritDoc */
  getArrowData(e, t, r, n, o, s) {
    let a, l, d, h, c, u, f;
    const v = s.width;
    t === "from" ? (d = this.from, h = this.to, c = s.fromArrowScale < 0, u = Math.abs(s.fromArrowScale), f = s.fromArrowType) : t === "to" ? (d = this.to, h = this.from, c = s.toArrowScale < 0, u = Math.abs(s.toArrowScale), f = s.toArrowType) : (d = this.to, h = this.from, c = s.middleArrowScale < 0, u = Math.abs(s.middleArrowScale), f = s.middleArrowType);
    const y = 15 * u + 3 * v;
    if (d != h) {
      const $ = Ise(d.x - h.x, d.y - h.y), w = y / $;
      if (t !== "middle")
        if (this.options.smooth.enabled === !0) {
          const T = this._findBorderPosition(d, e, {
            via: r
          }), A = this.getPoint(T.t + w * (t === "from" ? 1 : -1), r);
          a = Math.atan2(T.y - A.y, T.x - A.x), l = T;
        } else
          a = Math.atan2(d.y - h.y, d.x - h.x), l = this._findBorderPosition(d, e);
      else {
        const T = (c ? -w : w) / 2, A = this.getPoint(0.5 + T, r), L = this.getPoint(0.5 - T, r);
        a = Math.atan2(A.y - L.y, A.x - L.x), l = this.getPoint(0.5, r);
      }
    } else {
      const [$, w, T] = this._getCircleData(e);
      if (t === "from") {
        const A = this.options.selfReference.angle, L = this.options.selfReference.angle + Math.PI, G = this._findBorderPositionCircle(this.from, e, {
          x: $,
          y: w,
          low: A,
          high: L,
          direction: -1
        });
        a = G.t * -2 * Math.PI + 1.5 * Math.PI + 0.1 * Math.PI, l = G;
      } else if (t === "to") {
        const A = this.options.selfReference.angle, L = this.options.selfReference.angle + Math.PI, G = this._findBorderPositionCircle(this.from, e, {
          x: $,
          y: w,
          low: A,
          high: L,
          direction: 1
        });
        a = G.t * -2 * Math.PI + 1.5 * Math.PI - 1.1 * Math.PI, l = G;
      } else {
        const A = this.options.selfReference.angle / (2 * Math.PI);
        l = this._pointOnCircle($, w, T, A), a = A * -2 * Math.PI + 1.5 * Math.PI + 0.1 * Math.PI;
      }
    }
    const g = l.x - y * 0.9 * Math.cos(a), p = l.y - y * 0.9 * Math.sin(a);
    return {
      point: l,
      core: {
        x: g,
        y: p
      },
      angle: a,
      length: y,
      type: f
    };
  }
  /** @inheritDoc */
  drawArrowHead(e, t, r, n, o) {
    e.strokeStyle = this.getColor(e, t), e.fillStyle = e.strokeStyle, e.lineWidth = t.width, mS.draw(e, o) && (this.enableShadow(e, t), Ts(e).call(e), this.disableShadow(e, t));
  }
  /**
   * Set the shadow formatting values in the context if enabled, do nothing otherwise.
   * @param ctx - The context that will be used for rendering.
   * @param values - Formatting values for the shadow.
   */
  enableShadow(e, t) {
    t.shadow === !0 && (e.shadowColor = t.shadowColor, e.shadowBlur = t.shadowSize, e.shadowOffsetX = t.shadowX, e.shadowOffsetY = t.shadowY);
  }
  /**
   * Reset the shadow formatting values in the context if enabled, do nothing otherwise.
   * @param ctx - The context that will be used for rendering.
   * @param values - Formatting values for the shadow.
   */
  disableShadow(e, t) {
    t.shadow === !0 && (e.shadowColor = "rgba(0,0,0,0)", e.shadowBlur = 0, e.shadowOffsetX = 0, e.shadowOffsetY = 0);
  }
  /**
   * Render the background according to the formatting values.
   * @param ctx - The context that will be used for rendering.
   * @param values - Formatting values for the background.
   */
  drawBackground(e, t) {
    if (t.background !== !1) {
      const r = {
        strokeStyle: e.strokeStyle,
        lineWidth: e.lineWidth,
        dashes: e.dashes
      };
      e.strokeStyle = t.backgroundColor, e.lineWidth = t.backgroundSize, this.setStrokeDashed(e, t.backgroundDashes), e.stroke(), e.strokeStyle = r.strokeStyle, e.lineWidth = r.lineWidth, e.dashes = r.dashes, this.setStrokeDashed(e, t.dashes);
    }
  }
  /**
   * Set the line dash pattern if supported. Logs a warning to the console if it isn't supported.
   * @param ctx - The context that will be used for rendering.
   * @param dashes - The pattern [line, space, line…], true for default dashed line or false for normal line.
   */
  setStrokeDashed(e, t) {
    if (t !== !1)
      if (e.setLineDash !== void 0) {
        const r = be(t) ? t : [5, 5];
        e.setLineDash(r);
      } else
        console.warn("setLineDash is not supported in this browser. The dashed stroke cannot be used.");
    else
      e.setLineDash !== void 0 ? e.setLineDash([]) : console.warn("setLineDash is not supported in this browser. The dashed stroke cannot be used.");
  }
}
function Ib(i, e) {
  var t = me(i);
  if (jr) {
    var r = jr(i);
    e && (r = ht(r).call(r, function(n) {
      return Yr(i, n).enumerable;
    })), t.push.apply(t, r);
  }
  return t;
}
function Pb(i) {
  for (var e = 1; e < arguments.length; e++) {
    var t, r, n = arguments[e] != null ? arguments[e] : {};
    e % 2 ? se(t = Ib(Object(n), !0)).call(t, function(o) {
      sd(i, o, n[o]);
    }) : zr ? ad(i, zr(n)) : se(r = Ib(Object(n))).call(r, function(o) {
      ld(i, o, Yr(n, o));
    });
  }
  return i;
}
class rv extends bS {
  /**
   * Create a new instance.
   * @param options - The options object of given edge.
   * @param body - The body of the network.
   * @param labelModule - Label module.
   */
  constructor(e, t, r) {
    super(e, t, r);
  }
  /**
   * Find the intersection between the border of the node and the edge.
   * @remarks
   * This function uses binary search to look for the point where the bezier curve crosses the border of the node.
   * @param nearNode - The node (either from or to node of the edge).
   * @param ctx - The context that will be used for rendering.
   * @param viaNode - Additional node(s) the edge passes through.
   * @returns Cartesian coordinates of the intersection between the border of the node and the edge.
   */
  _findBorderPositionBezier(e, t) {
    let r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : this._getViaCoordinates();
    const n = 10, o = 0.2;
    let s = !1, a = 1, l = 0, d = this.to, h, c, u = this.options.endPointOffset ? this.options.endPointOffset.to : 0;
    e.id === this.from.id && (d = this.from, s = !0, u = this.options.endPointOffset ? this.options.endPointOffset.from : 0), this.options.arrowStrikethrough === !1 && (u = 0);
    let f = 0;
    do {
      c = (l + a) * 0.5, h = this.getPoint(c, r);
      const v = Math.atan2(d.y - h.y, d.x - h.x), y = d.distanceToBorder(t, v) + u, g = Math.sqrt(Math.pow(h.x - d.x, 2) + Math.pow(h.y - d.y, 2)), p = y - g;
      if (Math.abs(p) < o)
        break;
      p < 0 ? s === !1 ? l = c : a = c : s === !1 ? a = c : l = c, ++f;
    } while (l <= a && f < n);
    return Pb(Pb({}, h), {}, {
      t: c
    });
  }
  /**
   * Calculate the distance between a point (x3,y3) and a line segment from (x1,y1) to (x2,y2).
   * @remarks
   * http://stackoverflow.com/questions/849211/shortest-distancae-between-a-point-and-a-line-segment
   * @param x1 - First end of the line segment on the x axis.
   * @param y1 - First end of the line segment on the y axis.
   * @param x2 - Second end of the line segment on the x axis.
   * @param y2 - Second end of the line segment on the y axis.
   * @param x3 - Position of the point on the x axis.
   * @param y3 - Position of the point on the y axis.
   * @param via - The control point for the edge.
   * @returns The distance between the line segment and the point.
   */
  _getDistanceToBezierEdge(e, t, r, n, o, s, a) {
    let l = 1e9, d, h, c, u, f, v = e, y = t;
    for (h = 1; h < 10; h++)
      c = 0.1 * h, u = Math.pow(1 - c, 2) * e + 2 * c * (1 - c) * a.x + Math.pow(c, 2) * r, f = Math.pow(1 - c, 2) * t + 2 * c * (1 - c) * a.y + Math.pow(c, 2) * n, h > 0 && (d = this._getDistanceToLine(v, y, u, f, o, s), l = d < l ? d : l), v = u, y = f;
    return l;
  }
  /**
   * Render a bezier curve between two nodes.
   * @remarks
   * The method accepts zero, one or two control points.
   * Passing zero control points just draws a straight line.
   * @param ctx - The context that will be used for rendering.
   * @param values - Style options for edge drawing.
   * @param viaNode1 - First control point for curve drawing.
   * @param viaNode2 - Second control point for curve drawing.
   */
  _bezierCurve(e, t, r, n) {
    e.beginPath(), e.moveTo(this.fromPoint.x, this.fromPoint.y), r != null && r.x != null ? n != null && n.x != null ? e.bezierCurveTo(r.x, r.y, n.x, n.y, this.toPoint.x, this.toPoint.y) : e.quadraticCurveTo(r.x, r.y, this.toPoint.x, this.toPoint.y) : e.lineTo(this.toPoint.x, this.toPoint.y), this.drawBackground(e, t), this.enableShadow(e, t), e.stroke(), this.disableShadow(e, t);
  }
  /** @inheritDoc */
  getViaNode() {
    return this._getViaCoordinates();
  }
}
class xb extends rv {
  /**
   * Create a new instance.
   * @param options - The options object of given edge.
   * @param body - The body of the network.
   * @param labelModule - Label module.
   */
  constructor(e, t, r) {
    super(e, t, r), this.via = this.via, this._boundFunction = () => {
      this.positionBezierNode();
    }, this._body.emitter.on("_repositionBezierNodes", this._boundFunction);
  }
  /** @inheritDoc */
  setOptions(e) {
    super.setOptions(e);
    let t = !1;
    this.options.physics !== e.physics && (t = !0), this.options = e, this.id = this.options.id, this.from = this._body.nodes[this.options.from], this.to = this._body.nodes[this.options.to], this.setupSupportNode(), this.connect(), t === !0 && (this.via.setOptions({
      physics: this.options.physics
    }), this.positionBezierNode());
  }
  /** @inheritDoc */
  connect() {
    this.from = this._body.nodes[this.options.from], this.to = this._body.nodes[this.options.to], this.from === void 0 || this.to === void 0 || this.options.physics === !1 ? this.via.setOptions({
      physics: !1
    }) : this.from.id === this.to.id ? this.via.setOptions({
      physics: !1
    }) : this.via.setOptions({
      physics: !0
    });
  }
  /** @inheritDoc */
  cleanup() {
    return this._body.emitter.off("_repositionBezierNodes", this._boundFunction), this.via !== void 0 ? (delete this._body.nodes[this.via.id], this.via = void 0, !0) : !1;
  }
  /**
   * Create and add a support node if not already present.
   * @remarks
   * Bezier curves require an anchor point to calculate the smooth flow.
   * These points are nodes.
   * These nodes are invisible but are used for the force calculation.
   *
   * The changed data is not called, if needed, it is returned by the main edge constructor.
   */
  setupSupportNode() {
    if (this.via === void 0) {
      const e = "edgeId:" + this.id, t = this._body.functions.createNode({
        id: e,
        shape: "circle",
        physics: !0,
        hidden: !0
      });
      this._body.nodes[e] = t, this.via = t, this.via.parentEdgeId = this.id, this.positionBezierNode();
    }
  }
  /**
   * Position bezier node.
   */
  positionBezierNode() {
    this.via !== void 0 && this.from !== void 0 && this.to !== void 0 ? (this.via.x = 0.5 * (this.from.x + this.to.x), this.via.y = 0.5 * (this.from.y + this.to.y)) : this.via !== void 0 && (this.via.x = 0, this.via.y = 0);
  }
  /** @inheritDoc */
  _line(e, t, r) {
    this._bezierCurve(e, t, r);
  }
  /** @inheritDoc */
  _getViaCoordinates() {
    return this.via;
  }
  /** @inheritDoc */
  getViaNode() {
    return this.via;
  }
  /** @inheritDoc */
  getPoint(e) {
    let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : this.via;
    if (this.from === this.to) {
      const [r, n, o] = this._getCircleData(), s = 2 * Math.PI * (1 - e);
      return {
        x: r + o * Math.sin(s),
        y: n + o - o * (1 - Math.cos(s))
      };
    } else
      return {
        x: Math.pow(1 - e, 2) * this.fromPoint.x + 2 * e * (1 - e) * t.x + Math.pow(e, 2) * this.toPoint.x,
        y: Math.pow(1 - e, 2) * this.fromPoint.y + 2 * e * (1 - e) * t.y + Math.pow(e, 2) * this.toPoint.y
      };
  }
  /** @inheritDoc */
  _findBorderPosition(e, t) {
    return this._findBorderPositionBezier(e, t, this.via);
  }
  /** @inheritDoc */
  _getDistanceToEdge(e, t, r, n, o, s) {
    return this._getDistanceToBezierEdge(e, t, r, n, o, s, this.via);
  }
}
class Cb extends rv {
  /**
   * Create a new instance.
   * @param options - The options object of given edge.
   * @param body - The body of the network.
   * @param labelModule - Label module.
   */
  constructor(e, t, r) {
    super(e, t, r);
  }
  /** @inheritDoc */
  _line(e, t, r) {
    this._bezierCurve(e, t, r);
  }
  /** @inheritDoc */
  getViaNode() {
    return this._getViaCoordinates();
  }
  /**
   * Compute the coordinates of the via node.
   * @remarks
   * We do not use the to and fromPoints here to make the via nodes the same as edges without arrows.
   * @returns Cartesian coordinates of the via node.
   */
  _getViaCoordinates() {
    const e = this.options.smooth.roundness, t = this.options.smooth.type;
    let r = Math.abs(this.from.x - this.to.x), n = Math.abs(this.from.y - this.to.y);
    if (t === "discrete" || t === "diagonalCross") {
      let o, s;
      r <= n ? o = s = e * n : o = s = e * r, this.from.x > this.to.x && (o = -o), this.from.y >= this.to.y && (s = -s);
      let a = this.from.x + o, l = this.from.y + s;
      return t === "discrete" && (r <= n ? a = r < e * n ? this.from.x : a : l = n < e * r ? this.from.y : l), {
        x: a,
        y: l
      };
    } else if (t === "straightCross") {
      let o = (1 - e) * r, s = (1 - e) * n;
      return r <= n ? (o = 0, this.from.y < this.to.y && (s = -s)) : (this.from.x < this.to.x && (o = -o), s = 0), {
        x: this.to.x + o,
        y: this.to.y + s
      };
    } else if (t === "horizontal") {
      let o = (1 - e) * r;
      return this.from.x < this.to.x && (o = -o), {
        x: this.to.x + o,
        y: this.from.y
      };
    } else if (t === "vertical") {
      let o = (1 - e) * n;
      return this.from.y < this.to.y && (o = -o), {
        x: this.from.x,
        y: this.to.y + o
      };
    } else if (t === "curvedCW") {
      r = this.to.x - this.from.x, n = this.from.y - this.to.y;
      const o = Math.sqrt(r * r + n * n), s = Math.PI, l = (Math.atan2(n, r) + (e * 0.5 + 0.5) * s) % (2 * s);
      return {
        x: this.from.x + (e * 0.5 + 0.5) * o * Math.sin(l),
        y: this.from.y + (e * 0.5 + 0.5) * o * Math.cos(l)
      };
    } else if (t === "curvedCCW") {
      r = this.to.x - this.from.x, n = this.from.y - this.to.y;
      const o = Math.sqrt(r * r + n * n), s = Math.PI, l = (Math.atan2(n, r) + (-e * 0.5 + 0.5) * s) % (2 * s);
      return {
        x: this.from.x + (e * 0.5 + 0.5) * o * Math.sin(l),
        y: this.from.y + (e * 0.5 + 0.5) * o * Math.cos(l)
      };
    } else {
      let o, s;
      r <= n ? o = s = e * n : o = s = e * r, this.from.x > this.to.x && (o = -o), this.from.y >= this.to.y && (s = -s);
      let a = this.from.x + o, l = this.from.y + s;
      return r <= n ? this.from.x <= this.to.x ? a = this.to.x < a ? this.to.x : a : a = this.to.x > a ? this.to.x : a : this.from.y >= this.to.y ? l = this.to.y > l ? this.to.y : l : l = this.to.y < l ? this.to.y : l, {
        x: a,
        y: l
      };
    }
  }
  /** @inheritDoc */
  _findBorderPosition(e, t) {
    let r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
    return this._findBorderPositionBezier(e, t, r.via);
  }
  /** @inheritDoc */
  _getDistanceToEdge(e, t, r, n, o, s) {
    let a = arguments.length > 6 && arguments[6] !== void 0 ? arguments[6] : this._getViaCoordinates();
    return this._getDistanceToBezierEdge(e, t, r, n, o, s, a);
  }
  /** @inheritDoc */
  getPoint(e) {
    let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : this._getViaCoordinates();
    const r = e, n = Math.pow(1 - r, 2) * this.fromPoint.x + 2 * r * (1 - r) * t.x + Math.pow(r, 2) * this.toPoint.x, o = Math.pow(1 - r, 2) * this.fromPoint.y + 2 * r * (1 - r) * t.y + Math.pow(r, 2) * this.toPoint.y;
    return {
      x: n,
      y: o
    };
  }
}
class jse extends rv {
  /**
   * Create a new instance.
   * @param options - The options object of given edge.
   * @param body - The body of the network.
   * @param labelModule - Label module.
   */
  constructor(e, t, r) {
    super(e, t, r);
  }
  /**
   * Calculate the distance between a point (x3,y3) and a line segment from (x1,y1) to (x2,y2).
   * @remarks
   * http://stackoverflow.com/questions/849211/shortest-distancae-between-a-point-and-a-line-segment
   * https://en.wikipedia.org/wiki/B%C3%A9zier_curve
   * @param x1 - First end of the line segment on the x axis.
   * @param y1 - First end of the line segment on the y axis.
   * @param x2 - Second end of the line segment on the x axis.
   * @param y2 - Second end of the line segment on the y axis.
   * @param x3 - Position of the point on the x axis.
   * @param y3 - Position of the point on the y axis.
   * @param via1 - The first point this edge passes through.
   * @param via2 - The second point this edge passes through.
   * @returns The distance between the line segment and the point.
   */
  _getDistanceToBezierEdge2(e, t, r, n, o, s, a, l) {
    let d = 1e9, h = e, c = t;
    const u = [0, 0, 0, 0];
    for (let f = 1; f < 10; f++) {
      const v = 0.1 * f;
      u[0] = Math.pow(1 - v, 3), u[1] = 3 * v * Math.pow(1 - v, 2), u[2] = 3 * Math.pow(v, 2) * (1 - v), u[3] = Math.pow(v, 3);
      const y = u[0] * e + u[1] * a.x + u[2] * l.x + u[3] * r, g = u[0] * t + u[1] * a.y + u[2] * l.y + u[3] * n;
      if (f > 0) {
        const p = this._getDistanceToLine(h, c, y, g, o, s);
        d = p < d ? p : d;
      }
      h = y, c = g;
    }
    return d;
  }
}
class Ab extends jse {
  /**
   * Create a new instance.
   * @param options - The options object of given edge.
   * @param body - The body of the network.
   * @param labelModule - Label module.
   */
  constructor(e, t, r) {
    super(e, t, r);
  }
  /** @inheritDoc */
  _line(e, t, r) {
    const n = r[0], o = r[1];
    this._bezierCurve(e, t, n, o);
  }
  /**
   * Compute the additional points the edge passes through.
   * @returns Cartesian coordinates of the points the edge passes through.
   */
  _getViaCoordinates() {
    const e = this.from.x - this.to.x, t = this.from.y - this.to.y;
    let r, n, o, s;
    const a = this.options.smooth.roundness;
    return (Math.abs(e) > Math.abs(t) || this.options.smooth.forceDirection === !0 || this.options.smooth.forceDirection === "horizontal") && this.options.smooth.forceDirection !== "vertical" ? (n = this.from.y, s = this.to.y, r = this.from.x - a * e, o = this.to.x + a * e) : (n = this.from.y - a * t, s = this.to.y + a * t, r = this.from.x, o = this.to.x), [{
      x: r,
      y: n
    }, {
      x: o,
      y: s
    }];
  }
  /** @inheritDoc */
  getViaNode() {
    return this._getViaCoordinates();
  }
  /** @inheritDoc */
  _findBorderPosition(e, t) {
    return this._findBorderPositionBezier(e, t);
  }
  /** @inheritDoc */
  _getDistanceToEdge(e, t, r, n, o, s) {
    let [a, l] = arguments.length > 6 && arguments[6] !== void 0 ? arguments[6] : this._getViaCoordinates();
    return this._getDistanceToBezierEdge2(e, t, r, n, o, s, a, l);
  }
  /** @inheritDoc */
  getPoint(e) {
    let [t, r] = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : this._getViaCoordinates();
    const n = e, o = [Math.pow(1 - n, 3), 3 * n * Math.pow(1 - n, 2), 3 * Math.pow(n, 2) * (1 - n), Math.pow(n, 3)], s = o[0] * this.fromPoint.x + o[1] * t.x + o[2] * r.x + o[3] * this.toPoint.x, a = o[0] * this.fromPoint.y + o[1] * t.y + o[2] * r.y + o[3] * this.toPoint.y;
    return {
      x: s,
      y: a
    };
  }
}
class Mb extends bS {
  /**
   * Create a new instance.
   * @param options - The options object of given edge.
   * @param body - The body of the network.
   * @param labelModule - Label module.
   */
  constructor(e, t, r) {
    super(e, t, r);
  }
  /** @inheritDoc */
  _line(e, t) {
    e.beginPath(), e.moveTo(this.fromPoint.x, this.fromPoint.y), e.lineTo(this.toPoint.x, this.toPoint.y), this.enableShadow(e, t), e.stroke(), this.disableShadow(e, t);
  }
  /** @inheritDoc */
  getViaNode() {
  }
  /** @inheritDoc */
  getPoint(e) {
    return {
      x: (1 - e) * this.fromPoint.x + e * this.toPoint.x,
      y: (1 - e) * this.fromPoint.y + e * this.toPoint.y
    };
  }
  /** @inheritDoc */
  _findBorderPosition(e, t) {
    let r = this.to, n = this.from;
    e.id === this.from.id && (r = this.from, n = this.to);
    const o = Math.atan2(r.y - n.y, r.x - n.x), s = r.x - n.x, a = r.y - n.y, l = Math.sqrt(s * s + a * a), d = e.distanceToBorder(t, o), h = (l - d) / l;
    return {
      x: (1 - h) * n.x + h * r.x,
      y: (1 - h) * n.y + h * r.y,
      t: 0
    };
  }
  /** @inheritDoc */
  _getDistanceToEdge(e, t, r, n, o, s) {
    return this._getDistanceToLine(e, t, r, n, o, s);
  }
}
class Fr {
  /**
   * @param {object} options        values specific to this edge, must contain at least 'from' and 'to'
   * @param {object} body           shared state from Network instance
   * @param {Network.Images} imagelist  A list with images. Only needed when the edge has image arrows.
   * @param {object} globalOptions  options from the EdgesHandler instance
   * @param {object} defaultOptions default options from the EdgeHandler instance. Value and reference are constant
   */
  constructor(e, t, r, n, o) {
    if (t === void 0)
      throw new Error("No body provided");
    this.options = Rr(n), this.globalOptions = n, this.defaultOptions = o, this.body = t, this.imagelist = r, this.id = void 0, this.fromId = void 0, this.toId = void 0, this.selected = !1, this.hover = !1, this.labelDirty = !0, this.baseWidth = this.options.width, this.baseFontSize = this.options.font.size, this.from = void 0, this.to = void 0, this.edgeType = void 0, this.connected = !1, this.labelModule = new hn(
      this.body,
      this.options,
      !0
      /* It's an edge label */
    ), this.setOptions(e);
  }
  /**
   * Set or overwrite options for the edge
   * @param {object} options  an object with options
   * @returns {undefined|boolean} undefined if no options, true if layout affecting data changed, false otherwise.
   */
  setOptions(e) {
    if (!e)
      return;
    let t = typeof e.physics < "u" && this.options.physics !== e.physics || typeof e.hidden < "u" && (this.options.hidden || !1) !== (e.hidden || !1) || typeof e.from < "u" && this.options.from !== e.from || typeof e.to < "u" && this.options.to !== e.to;
    Fr.parseOptions(this.options, e, !0, this.globalOptions), e.id !== void 0 && (this.id = e.id), e.from !== void 0 && (this.fromId = e.from), e.to !== void 0 && (this.toId = e.to), e.title !== void 0 && (this.title = e.title), e.value !== void 0 && (e.value = dS(e.value));
    const r = [e, this.options, this.defaultOptions];
    return this.chooser = ev("edge", r), this.updateLabelModule(e), t = this.updateEdgeType() || t, this._setInteractionWidths(), this.connect(), t;
  }
  /**
   *
   * @param {object} parentOptions
   * @param {object} newOptions
   * @param {boolean} [allowDeletion]
   * @param {object} [globalOptions]
   * @param {boolean} [copyFromGlobals]
   */
  static parseOptions(e, t) {
    let r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !1, n = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : {}, o = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : !1;
    if (Xn(["endPointOffset", "arrowStrikethrough", "id", "from", "hidden", "hoverWidth", "labelHighlightBold", "length", "line", "opacity", "physics", "scaling", "selectionWidth", "selfReferenceSize", "selfReference", "to", "title", "value", "width", "font", "chosen", "widthConstraint"], e, t, r), t.endPointOffset !== void 0 && t.endPointOffset.from !== void 0 && (ii(t.endPointOffset.from) ? e.endPointOffset.from = t.endPointOffset.from : (e.endPointOffset.from = n.endPointOffset.from !== void 0 ? n.endPointOffset.from : 0, console.error("endPointOffset.from is not a valid number"))), t.endPointOffset !== void 0 && t.endPointOffset.to !== void 0 && (ii(t.endPointOffset.to) ? e.endPointOffset.to = t.endPointOffset.to : (e.endPointOffset.to = n.endPointOffset.to !== void 0 ? n.endPointOffset.to : 0, console.error("endPointOffset.to is not a valid number"))), al(t.label) ? e.label = t.label : al(e.label) || (e.label = void 0), Et(e, t, "smooth", n), Et(e, t, "shadow", n), Et(e, t, "background", n), t.dashes !== void 0 && t.dashes !== null ? e.dashes = t.dashes : r === !0 && t.dashes === null && (e.dashes = ui(n.dashes)), t.scaling !== void 0 && t.scaling !== null ? (t.scaling.min !== void 0 && (e.scaling.min = t.scaling.min), t.scaling.max !== void 0 && (e.scaling.max = t.scaling.max), Et(e.scaling, t.scaling, "label", n.scaling)) : r === !0 && t.scaling === null && (e.scaling = ui(n.scaling)), t.arrows !== void 0 && t.arrows !== null)
      if (typeof t.arrows == "string") {
        const a = t.arrows.toLowerCase();
        e.arrows.to.enabled = re(a).call(a, "to") != -1, e.arrows.middle.enabled = re(a).call(a, "middle") != -1, e.arrows.from.enabled = re(a).call(a, "from") != -1;
      } else if (typeof t.arrows == "object")
        Et(e.arrows, t.arrows, "to", n.arrows), Et(e.arrows, t.arrows, "middle", n.arrows), Et(e.arrows, t.arrows, "from", n.arrows);
      else
        throw new Error("The arrow newOptions can only be an object or a string. Refer to the documentation. You used:" + Os(t.arrows));
    else r === !0 && t.arrows === null && (e.arrows = ui(n.arrows));
    if (t.color !== void 0 && t.color !== null) {
      const a = ln(t.color) ? {
        color: t.color,
        highlight: t.color,
        hover: t.color,
        inherit: !1,
        opacity: 1
      } : t.color, l = e.color;
      if (o)
        le(l, n.color, !1, r);
      else
        for (const d in l)
          Object.prototype.hasOwnProperty.call(l, d) && delete l[d];
      if (ln(l))
        l.color = l, l.highlight = l, l.hover = l, l.inherit = !1, a.opacity === void 0 && (l.opacity = 1);
      else {
        let d = !1;
        a.color !== void 0 && (l.color = a.color, d = !0), a.highlight !== void 0 && (l.highlight = a.highlight, d = !0), a.hover !== void 0 && (l.hover = a.hover, d = !0), a.inherit !== void 0 && (l.inherit = a.inherit), a.opacity !== void 0 && (l.opacity = Math.min(1, Math.max(0, a.opacity))), d === !0 ? l.inherit = !1 : l.inherit === void 0 && (l.inherit = "from");
      }
    } else r === !0 && t.color === null && (e.color = Rr(n.color));
    r === !0 && t.font === null && (e.font = Rr(n.font)), Object.prototype.hasOwnProperty.call(t, "selfReferenceSize") && (console.warn("The selfReferenceSize property has been deprecated. Please use selfReference property instead. The selfReference can be set like thise selfReference:{size:30, angle:Math.PI / 4}"), e.selfReference.size = t.selfReferenceSize);
  }
  /**
   *
   * @returns {ArrowOptions}
   */
  getFormattingValues() {
    const e = this.options.arrows.to === !0 || this.options.arrows.to.enabled === !0, t = this.options.arrows.from === !0 || this.options.arrows.from.enabled === !0, r = this.options.arrows.middle === !0 || this.options.arrows.middle.enabled === !0, n = this.options.color.inherit, o = {
      toArrow: e,
      toArrowScale: this.options.arrows.to.scaleFactor,
      toArrowType: this.options.arrows.to.type,
      toArrowSrc: this.options.arrows.to.src,
      toArrowImageWidth: this.options.arrows.to.imageWidth,
      toArrowImageHeight: this.options.arrows.to.imageHeight,
      middleArrow: r,
      middleArrowScale: this.options.arrows.middle.scaleFactor,
      middleArrowType: this.options.arrows.middle.type,
      middleArrowSrc: this.options.arrows.middle.src,
      middleArrowImageWidth: this.options.arrows.middle.imageWidth,
      middleArrowImageHeight: this.options.arrows.middle.imageHeight,
      fromArrow: t,
      fromArrowScale: this.options.arrows.from.scaleFactor,
      fromArrowType: this.options.arrows.from.type,
      fromArrowSrc: this.options.arrows.from.src,
      fromArrowImageWidth: this.options.arrows.from.imageWidth,
      fromArrowImageHeight: this.options.arrows.from.imageHeight,
      arrowStrikethrough: this.options.arrowStrikethrough,
      color: n ? void 0 : this.options.color.color,
      inheritsColor: n,
      opacity: this.options.color.opacity,
      hidden: this.options.hidden,
      length: this.options.length,
      shadow: this.options.shadow.enabled,
      shadowColor: this.options.shadow.color,
      shadowSize: this.options.shadow.size,
      shadowX: this.options.shadow.x,
      shadowY: this.options.shadow.y,
      dashes: this.options.dashes,
      width: this.options.width,
      background: this.options.background.enabled,
      backgroundColor: this.options.background.color,
      backgroundSize: this.options.background.size,
      backgroundDashes: this.options.background.dashes
    };
    if (this.selected || this.hover)
      if (this.chooser === !0) {
        if (this.selected) {
          const s = this.options.selectionWidth;
          typeof s == "function" ? o.width = s(o.width) : typeof s == "number" && (o.width += s), o.width = Math.max(o.width, 0.3 / this.body.view.scale), o.color = this.options.color.highlight, o.shadow = this.options.shadow.enabled;
        } else if (this.hover) {
          const s = this.options.hoverWidth;
          typeof s == "function" ? o.width = s(o.width) : typeof s == "number" && (o.width += s), o.width = Math.max(o.width, 0.3 / this.body.view.scale), o.color = this.options.color.hover, o.shadow = this.options.shadow.enabled;
        }
      } else typeof this.chooser == "function" && (this.chooser(o, this.options.id, this.selected, this.hover), o.color !== void 0 && (o.inheritsColor = !1), o.shadow === !1 && (o.shadowColor !== this.options.shadow.color || o.shadowSize !== this.options.shadow.size || o.shadowX !== this.options.shadow.x || o.shadowY !== this.options.shadow.y) && (o.shadow = !0));
    else
      o.shadow = this.options.shadow.enabled, o.width = Math.max(o.width, 0.3 / this.body.view.scale);
    return o;
  }
  /**
   * update the options in the label module
   * @param {object} options
   */
  updateLabelModule(e) {
    const t = [
      e,
      this.options,
      this.globalOptions,
      // Currently set global edge options
      this.defaultOptions
    ];
    this.labelModule.update(this.options, t), this.labelModule.baseSize !== void 0 && (this.baseFontSize = this.labelModule.baseSize);
  }
  /**
   * update the edge type, set the options
   * @returns {boolean}
   */
  updateEdgeType() {
    const e = this.options.smooth;
    let t = !1, r = !0;
    return this.edgeType !== void 0 && ((this.edgeType instanceof xb && e.enabled === !0 && e.type === "dynamic" || this.edgeType instanceof Ab && e.enabled === !0 && e.type === "cubicBezier" || this.edgeType instanceof Cb && e.enabled === !0 && e.type !== "dynamic" && e.type !== "cubicBezier" || this.edgeType instanceof Mb && e.type.enabled === !1) && (r = !1), r === !0 && (t = this.cleanup())), r === !0 ? e.enabled === !0 ? e.type === "dynamic" ? (t = !0, this.edgeType = new xb(this.options, this.body, this.labelModule)) : e.type === "cubicBezier" ? this.edgeType = new Ab(this.options, this.body, this.labelModule) : this.edgeType = new Cb(this.options, this.body, this.labelModule) : this.edgeType = new Mb(this.options, this.body, this.labelModule) : this.edgeType.setOptions(this.options), t;
  }
  /**
   * Connect an edge to its nodes
   */
  connect() {
    this.disconnect(), this.from = this.body.nodes[this.fromId] || void 0, this.to = this.body.nodes[this.toId] || void 0, this.connected = this.from !== void 0 && this.to !== void 0, this.connected === !0 ? (this.from.attachEdge(this), this.to.attachEdge(this)) : (this.from && this.from.detachEdge(this), this.to && this.to.detachEdge(this)), this.edgeType.connect();
  }
  /**
   * Disconnect an edge from its nodes
   */
  disconnect() {
    this.from && (this.from.detachEdge(this), this.from = void 0), this.to && (this.to.detachEdge(this), this.to = void 0), this.connected = !1;
  }
  /**
   * get the title of this edge.
   * @returns {string} title    The title of the edge, or undefined when no title
   *                           has been set.
   */
  getTitle() {
    return this.title;
  }
  /**
   * check if this node is selecte
   * @returns {boolean} selected   True if node is selected, else false
   */
  isSelected() {
    return this.selected;
  }
  /**
   * Retrieve the value of the edge. Can be undefined
   * @returns {number} value
   */
  getValue() {
    return this.options.value;
  }
  /**
   * Adjust the value range of the edge. The edge will adjust it's width
   * based on its value.
   * @param {number} min
   * @param {number} max
   * @param {number} total
   */
  setValueRange(e, t, r) {
    if (this.options.value !== void 0) {
      const n = this.options.scaling.customScalingFunction(e, t, r, this.options.value), o = this.options.scaling.max - this.options.scaling.min;
      if (this.options.scaling.label.enabled === !0) {
        const s = this.options.scaling.label.max - this.options.scaling.label.min;
        this.options.font.size = this.options.scaling.label.min + n * s;
      }
      this.options.width = this.options.scaling.min + n * o;
    } else
      this.options.width = this.baseWidth, this.options.font.size = this.baseFontSize;
    this._setInteractionWidths(), this.updateLabelModule();
  }
  /**
   *
   * @private
   */
  _setInteractionWidths() {
    typeof this.options.hoverWidth == "function" ? this.edgeType.hoverWidth = this.options.hoverWidth(this.options.width) : this.edgeType.hoverWidth = this.options.hoverWidth + this.options.width, typeof this.options.selectionWidth == "function" ? this.edgeType.selectionWidth = this.options.selectionWidth(this.options.width) : this.edgeType.selectionWidth = this.options.selectionWidth + this.options.width;
  }
  /**
   * Redraw a edge
   * Draw this edge in the given canvas
   * The 2d context of a HTML canvas can be retrieved by canvas.getContext("2d");
   * @param {CanvasRenderingContext2D}   ctx
   */
  draw(e) {
    const t = this.getFormattingValues();
    if (t.hidden)
      return;
    const r = this.edgeType.getViaNode();
    this.edgeType.drawLine(e, t, this.selected, this.hover, r), this.drawLabel(e, r);
  }
  /**
   * Redraw arrows
   * Draw this arrows in the given canvas
   * The 2d context of a HTML canvas can be retrieved by canvas.getContext("2d");
   * @param {CanvasRenderingContext2D}   ctx
   */
  drawArrows(e) {
    const t = this.getFormattingValues();
    if (t.hidden)
      return;
    const r = this.edgeType.getViaNode(), n = {};
    this.edgeType.fromPoint = this.edgeType.from, this.edgeType.toPoint = this.edgeType.to, t.fromArrow && (n.from = this.edgeType.getArrowData(e, "from", r, this.selected, this.hover, t), t.arrowStrikethrough === !1 && (this.edgeType.fromPoint = n.from.core), t.fromArrowSrc && (n.from.image = this.imagelist.load(t.fromArrowSrc)), t.fromArrowImageWidth && (n.from.imageWidth = t.fromArrowImageWidth), t.fromArrowImageHeight && (n.from.imageHeight = t.fromArrowImageHeight)), t.toArrow && (n.to = this.edgeType.getArrowData(e, "to", r, this.selected, this.hover, t), t.arrowStrikethrough === !1 && (this.edgeType.toPoint = n.to.core), t.toArrowSrc && (n.to.image = this.imagelist.load(t.toArrowSrc)), t.toArrowImageWidth && (n.to.imageWidth = t.toArrowImageWidth), t.toArrowImageHeight && (n.to.imageHeight = t.toArrowImageHeight)), t.middleArrow && (n.middle = this.edgeType.getArrowData(e, "middle", r, this.selected, this.hover, t), t.middleArrowSrc && (n.middle.image = this.imagelist.load(t.middleArrowSrc)), t.middleArrowImageWidth && (n.middle.imageWidth = t.middleArrowImageWidth), t.middleArrowImageHeight && (n.middle.imageHeight = t.middleArrowImageHeight)), t.fromArrow && this.edgeType.drawArrowHead(e, t, this.selected, this.hover, n.from), t.middleArrow && this.edgeType.drawArrowHead(e, t, this.selected, this.hover, n.middle), t.toArrow && this.edgeType.drawArrowHead(e, t, this.selected, this.hover, n.to);
  }
  /**
   *
   * @param {CanvasRenderingContext2D} ctx
   * @param {Node} viaNode
   */
  drawLabel(e, t) {
    if (this.options.label !== void 0) {
      const r = this.from, n = this.to;
      this.labelModule.differentState(this.selected, this.hover) && this.labelModule.getTextSize(e, this.selected, this.hover);
      let o;
      if (r.id != n.id) {
        this.labelModule.pointToSelf = !1, o = this.edgeType.getPoint(0.5, t), e.save();
        const s = this._getRotation(e);
        s.angle != 0 && (e.translate(s.x, s.y), e.rotate(s.angle)), this.labelModule.draw(e, o.x, o.y, this.selected, this.hover), e.restore();
      } else {
        this.labelModule.pointToSelf = !0;
        const s = gS(e, this.options.selfReference.angle, this.options.selfReference.size, r);
        o = this._pointOnCircle(s.x, s.y, this.options.selfReference.size, this.options.selfReference.angle), this.labelModule.draw(e, o.x, o.y, this.selected, this.hover);
      }
    }
  }
  /**
   * Determine all visual elements of this edge instance, in which the given
   * point falls within the bounding shape.
   * @param {point} point
   * @returns {Array.<edgeClickItem|edgeLabelClickItem>} list with the items which are on the point
   */
  getItemsOnPoint(e) {
    const t = [];
    if (this.labelModule.visible()) {
      const n = this._getRotation();
      Iu(this.labelModule.getSize(), e, n) && t.push({
        edgeId: this.id,
        labelId: 0
      });
    }
    const r = {
      left: e.x,
      top: e.y
    };
    return this.isOverlappingWith(r) && t.push({
      edgeId: this.id
    }), t;
  }
  /**
   * Check if this object is overlapping with the provided object
   * @param {object} obj   an object with parameters left, top
   * @returns {boolean}     True if location is located on the edge
   */
  isOverlappingWith(e) {
    if (this.connected) {
      const r = this.from.x, n = this.from.y, o = this.to.x, s = this.to.y, a = e.left, l = e.top;
      return this.edgeType.getDistanceToEdge(r, n, o, s, a, l) < 10;
    } else
      return !1;
  }
  /**
   * Determine the rotation point, if any.
   * @param {CanvasRenderingContext2D} [ctx] if passed, do a recalculation of the label size
   * @returns {rotationPoint} the point to rotate around and the angle in radians to rotate
   * @private
   */
  _getRotation(e) {
    const t = this.edgeType.getViaNode(), r = this.edgeType.getPoint(0.5, t);
    e !== void 0 && this.labelModule.calculateLabelSize(e, this.selected, this.hover, r.x, r.y);
    const n = {
      x: r.x,
      y: this.labelModule.size.yLine,
      angle: 0
    };
    if (!this.labelModule.visible() || this.options.font.align === "horizontal")
      return n;
    const o = this.from.y - this.to.y, s = this.from.x - this.to.x;
    let a = Math.atan2(o, s);
    return (a < -1 && s < 0 || a > 0 && s < 0) && (a += Math.PI), n.angle = a, n;
  }
  /**
   * Get a point on a circle
   * @param {number} x
   * @param {number} y
   * @param {number} radius
   * @param {number} angle
   * @returns {object} point
   * @private
   */
  _pointOnCircle(e, t, r, n) {
    return {
      x: e + r * Math.cos(n),
      y: t - r * Math.sin(n)
    };
  }
  /**
   * Sets selected state to true
   */
  select() {
    this.selected = !0;
  }
  /**
   * Sets selected state to false
   */
  unselect() {
    this.selected = !1;
  }
  /**
   * cleans all required things on delete
   * @returns {*}
   */
  cleanup() {
    return this.edgeType.cleanup();
  }
  /**
   * Remove edge from the list and perform necessary cleanup.
   */
  remove() {
    this.cleanup(), this.disconnect(), delete this.body.edges[this.id];
  }
  /**
   * Check if both connecting nodes exist
   * @returns {boolean}
   */
  endPointsValid() {
    return this.body.nodes[this.fromId] !== void 0 && this.body.nodes[this.toId] !== void 0;
  }
}
class zse {
  /**
   * @param {object} body
   * @param {Array.<Image>} images
   * @param {Array.<Group>} groups
   */
  constructor(e, t, r) {
    var n;
    this.body = e, this.images = t, this.groups = r, this.body.functions.createEdge = S(n = this.create).call(n, this), this.edgesListeners = {
      add: (o, s) => {
        this.add(s.items);
      },
      update: (o, s) => {
        this.update(s.items);
      },
      remove: (o, s) => {
        this.remove(s.items);
      }
    }, this.options = {}, this.defaultOptions = {
      arrows: {
        to: {
          enabled: !1,
          scaleFactor: 1,
          type: "arrow"
        },
        // boolean / {arrowScaleFactor:1} / {enabled: false, arrowScaleFactor:1}
        middle: {
          enabled: !1,
          scaleFactor: 1,
          type: "arrow"
        },
        from: {
          enabled: !1,
          scaleFactor: 1,
          type: "arrow"
        }
      },
      endPointOffset: {
        from: 0,
        to: 0
      },
      arrowStrikethrough: !0,
      color: {
        color: "#848484",
        highlight: "#848484",
        hover: "#848484",
        inherit: "from",
        opacity: 1
      },
      dashes: !1,
      font: {
        color: "#343434",
        size: 14,
        // px
        face: "arial",
        background: "none",
        strokeWidth: 2,
        // px
        strokeColor: "#ffffff",
        align: "horizontal",
        multi: !1,
        vadjust: 0,
        bold: {
          mod: "bold"
        },
        boldital: {
          mod: "bold italic"
        },
        ital: {
          mod: "italic"
        },
        mono: {
          mod: "",
          size: 15,
          // px
          face: "courier new",
          vadjust: 2
        }
      },
      hidden: !1,
      hoverWidth: 1.5,
      label: void 0,
      labelHighlightBold: !0,
      length: void 0,
      physics: !0,
      scaling: {
        min: 1,
        max: 15,
        label: {
          enabled: !0,
          min: 14,
          max: 30,
          maxVisible: 30,
          drawThreshold: 5
        },
        customScalingFunction: function(o, s, a, l) {
          if (s === o)
            return 0.5;
          {
            const d = 1 / (s - o);
            return Math.max(0, (l - o) * d);
          }
        }
      },
      selectionWidth: 1.5,
      selfReference: {
        size: 20,
        angle: Math.PI / 4,
        renderBehindTheNode: !0
      },
      shadow: {
        enabled: !1,
        color: "rgba(0,0,0,0.5)",
        size: 10,
        x: 5,
        y: 5
      },
      background: {
        enabled: !1,
        color: "rgba(111,111,111,1)",
        size: 10,
        dashes: !1
      },
      smooth: {
        enabled: !0,
        type: "dynamic",
        forceDirection: "none",
        roundness: 0.5
      },
      title: void 0,
      width: 1,
      value: void 0
    }, le(this.options, this.defaultOptions), this.bindEventListeners();
  }
  /**
   * Binds event listeners
   */
  bindEventListeners() {
    var e = this, t, r;
    this.body.emitter.on("_forceDisableDynamicCurves", function(n) {
      let o = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !0;
      n === "dynamic" && (n = "continuous");
      let s = !1;
      for (const a in e.body.edges)
        if (Object.prototype.hasOwnProperty.call(e.body.edges, a)) {
          const l = e.body.edges[a], d = e.body.data.edges.get(a);
          if (d != null) {
            const h = d.smooth;
            h !== void 0 && h.enabled === !0 && h.type === "dynamic" && (n === void 0 ? l.setOptions({
              smooth: !1
            }) : l.setOptions({
              smooth: {
                type: n
              }
            }), s = !0);
          }
        }
      o === !0 && s === !0 && e.body.emitter.emit("_dataChanged");
    }), this.body.emitter.on("_dataUpdated", () => {
      this.reconnectEdges();
    }), this.body.emitter.on("refreshEdges", S(t = this.refresh).call(t, this)), this.body.emitter.on("refresh", S(r = this.refresh).call(r, this)), this.body.emitter.on("destroy", () => {
      X(this.edgesListeners, (n, o) => {
        this.body.data.edges && this.body.data.edges.off(o, n);
      }), delete this.body.functions.createEdge, delete this.edgesListeners.add, delete this.edgesListeners.update, delete this.edgesListeners.remove, delete this.edgesListeners;
    });
  }
  /**
   *
   * @param {object} options
   */
  setOptions(e) {
    if (e !== void 0) {
      Fr.parseOptions(this.options, e, !0, this.defaultOptions, !0);
      let t = !1;
      if (e.smooth !== void 0)
        for (const r in this.body.edges)
          Object.prototype.hasOwnProperty.call(this.body.edges, r) && (t = this.body.edges[r].updateEdgeType() || t);
      if (e.font !== void 0)
        for (const r in this.body.edges)
          Object.prototype.hasOwnProperty.call(this.body.edges, r) && this.body.edges[r].updateLabelModule();
      (e.hidden !== void 0 || e.physics !== void 0 || t === !0) && this.body.emitter.emit("_dataChanged");
    }
  }
  /**
   * Load edges by reading the data table
   * @param {Array | DataSet | DataView} edges    The data containing the edges.
   * @param {boolean} [doNotEmit] - Suppress data changed event.
   * @private
   */
  setData(e) {
    let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1;
    const r = this.body.data.edges;
    if (D0("id", e))
      this.body.data.edges = e;
    else if (be(e))
      this.body.data.edges = new bn(), this.body.data.edges.add(e);
    else if (!e)
      this.body.data.edges = new bn();
    else
      throw new TypeError("Array or DataSet expected");
    if (r && X(this.edgesListeners, (n, o) => {
      r.off(o, n);
    }), this.body.edges = {}, this.body.data.edges) {
      X(this.edgesListeners, (o, s) => {
        this.body.data.edges.on(s, o);
      });
      const n = this.body.data.edges.getIds();
      this.add(n, !0);
    }
    this.body.emitter.emit("_adjustEdgesForHierarchicalLayout"), t === !1 && this.body.emitter.emit("_dataChanged");
  }
  /**
   * Add edges
   * @param {number[] | string[]} ids
   * @param {boolean} [doNotEmit]
   * @private
   */
  add(e) {
    let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1;
    const r = this.body.edges, n = this.body.data.edges;
    for (let o = 0; o < e.length; o++) {
      const s = e[o], a = r[s];
      a && a.disconnect();
      const l = n.get(s, {
        showInternalIds: !0
      });
      r[s] = this.create(l);
    }
    this.body.emitter.emit("_adjustEdgesForHierarchicalLayout"), t === !1 && this.body.emitter.emit("_dataChanged");
  }
  /**
   * Update existing edges, or create them when not yet existing
   * @param {number[] | string[]} ids
   * @private
   */
  update(e) {
    const t = this.body.edges, r = this.body.data.edges;
    let n = !1;
    for (let o = 0; o < e.length; o++) {
      const s = e[o], a = r.get(s), l = t[s];
      l !== void 0 ? (l.disconnect(), n = l.setOptions(a) || n, l.connect()) : (this.body.edges[s] = this.create(a), n = !0);
    }
    n === !0 ? (this.body.emitter.emit("_adjustEdgesForHierarchicalLayout"), this.body.emitter.emit("_dataChanged")) : this.body.emitter.emit("_dataUpdated");
  }
  /**
   * Remove existing edges. Non existing ids will be ignored
   * @param {number[] | string[]} ids
   * @param {boolean} [emit]
   * @private
   */
  remove(e) {
    let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !0;
    if (e.length === 0) return;
    const r = this.body.edges;
    X(e, (n) => {
      const o = r[n];
      o !== void 0 && o.remove();
    }), t && this.body.emitter.emit("_dataChanged");
  }
  /**
   * Refreshes Edge Handler
   */
  refresh() {
    X(this.body.edges, (e, t) => {
      const r = this.body.data.edges.get(t);
      r !== void 0 && e.setOptions(r);
    });
  }
  /**
   *
   * @param {object} properties
   * @returns {Edge}
   */
  create(e) {
    return new Fr(e, this.body, this.images, this.options, this.defaultOptions);
  }
  /**
   * Reconnect all edges
   * @private
   */
  reconnectEdges() {
    let e;
    const t = this.body.nodes, r = this.body.edges;
    for (e in t)
      Object.prototype.hasOwnProperty.call(t, e) && (t[e].edges = []);
    for (e in r)
      if (Object.prototype.hasOwnProperty.call(r, e)) {
        const n = r[e];
        n.from = null, n.to = null, n.connect();
      }
  }
  /**
   *
   * @param {Edge.id} edgeId
   * @returns {Array}
   */
  getConnectedNodes(e) {
    const t = [];
    if (this.body.edges[e] !== void 0) {
      const r = this.body.edges[e];
      r.fromId !== void 0 && t.push(r.fromId), r.toId !== void 0 && t.push(r.toId);
    }
    return t;
  }
  /**
   * There is no direct relation between the nodes and the edges DataSet,
   * so the right place to do call this is in the handler for event `_dataUpdated`.
   */
  _updateState() {
    this._addMissingEdges(), this._removeInvalidEdges();
  }
  /**
   * Scan for missing nodes and remove corresponding edges, if any.
   * @private
   */
  _removeInvalidEdges() {
    const e = [];
    X(this.body.edges, (t, r) => {
      const n = this.body.nodes[t.toId], o = this.body.nodes[t.fromId];
      n !== void 0 && n.isCluster === !0 || o !== void 0 && o.isCluster === !0 || (n === void 0 || o === void 0) && e.push(r);
    }), this.remove(e, !1);
  }
  /**
   * add all edges from dataset that are not in the cached state
   * @private
   */
  _addMissingEdges() {
    const e = this.body.data.edges;
    if (e == null)
      return;
    const t = this.body.edges, r = [];
    se(e).call(e, (n, o) => {
      t[o] === void 0 && r.push(o);
    }), this.add(r, !0);
  }
}
class $S {
  /**
   * @param {object} body
   * @param {{physicsNodeIndices: Array, physicsEdgeIndices: Array, forces: {}, velocities: {}}} physicsBody
   * @param {object} options
   */
  constructor(e, t, r) {
    this.body = e, this.physicsBody = t, this.barnesHutTree, this.setOptions(r), this._rng = nd("BARNES HUT SOLVER");
  }
  /**
   *
   * @param {object} options
   */
  setOptions(e) {
    this.options = e, this.thetaInversed = 1 / this.options.theta, this.overlapAvoidanceFactor = 1 - Math.max(0, Math.min(1, this.options.avoidOverlap));
  }
  /**
   * This function calculates the forces the nodes apply on each other based on a gravitational model.
   * The Barnes Hut method is used to speed up this N-body simulation.
   * @private
   */
  solve() {
    if (this.options.gravitationalConstant !== 0 && this.physicsBody.physicsNodeIndices.length > 0) {
      let e;
      const t = this.body.nodes, r = this.physicsBody.physicsNodeIndices, n = r.length, o = this._formBarnesHutTree(t, r);
      this.barnesHutTree = o;
      for (let s = 0; s < n; s++)
        e = t[r[s]], e.options.mass > 0 && this._getForceContributions(o.root, e);
    }
  }
  /**
   * @param {object} parentBranch
   * @param {Node} node
   * @private
   */
  _getForceContributions(e, t) {
    this._getForceContribution(e.children.NW, t), this._getForceContribution(e.children.NE, t), this._getForceContribution(e.children.SW, t), this._getForceContribution(e.children.SE, t);
  }
  /**
   * This function traverses the barnesHutTree. It checks when it can approximate distant nodes with their center of mass.
   * If a region contains a single node, we check if it is not itself, then we apply the force.
   * @param {object} parentBranch
   * @param {Node} node
   * @private
   */
  _getForceContribution(e, t) {
    if (e.childrenCount > 0) {
      const r = e.centerOfMass.x - t.x, n = e.centerOfMass.y - t.y, o = Math.sqrt(r * r + n * n);
      o * e.calcSize > this.thetaInversed ? this._calculateForces(o, r, n, t, e) : e.childrenCount === 4 ? this._getForceContributions(e, t) : e.children.data.id != t.id && this._calculateForces(o, r, n, t, e);
    }
  }
  /**
   * Calculate the forces based on the distance.
   * @param {number} distance
   * @param {number} dx
   * @param {number} dy
   * @param {Node} node
   * @param {object} parentBranch
   * @private
   */
  _calculateForces(e, t, r, n, o) {
    e === 0 && (e = 0.1, t = e), this.overlapAvoidanceFactor < 1 && n.shape.radius && (e = Math.max(0.1 + this.overlapAvoidanceFactor * n.shape.radius, e - n.shape.radius));
    const s = this.options.gravitationalConstant * o.mass * n.options.mass / Math.pow(e, 3), a = t * s, l = r * s;
    this.physicsBody.forces[n.id].x += a, this.physicsBody.forces[n.id].y += l;
  }
  /**
   * This function constructs the barnesHut tree recursively. It creates the root, splits it and starts placing the nodes.
   * @param {Array.<Node>} nodes
   * @param {Array.<number>} nodeIndices
   * @returns {{root: {centerOfMass: {x: number, y: number}, mass: number, range: {minX: number, maxX: number, minY: number, maxY: number}, size: number, calcSize: number, children: {data: null}, maxWidth: number, level: number, childrenCount: number}}} BarnesHutTree
   * @private
   */
  _formBarnesHutTree(e, t) {
    let r;
    const n = t.length;
    let o = e[t[0]].x, s = e[t[0]].y, a = e[t[0]].x, l = e[t[0]].y;
    for (let g = 1; g < n; g++) {
      const p = e[t[g]], m = p.x, $ = p.y;
      p.options.mass > 0 && (m < o && (o = m), m > a && (a = m), $ < s && (s = $), $ > l && (l = $));
    }
    const d = Math.abs(a - o) - Math.abs(l - s);
    d > 0 ? (s -= 0.5 * d, l += 0.5 * d) : (o += 0.5 * d, a -= 0.5 * d);
    const c = Math.max(1e-5, Math.abs(a - o)), u = 0.5 * c, f = 0.5 * (o + a), v = 0.5 * (s + l), y = {
      root: {
        centerOfMass: {
          x: 0,
          y: 0
        },
        mass: 0,
        range: {
          minX: f - u,
          maxX: f + u,
          minY: v - u,
          maxY: v + u
        },
        size: c,
        calcSize: 1 / c,
        children: {
          data: null
        },
        maxWidth: 0,
        level: 0,
        childrenCount: 4
      }
    };
    this._splitBranch(y.root);
    for (let g = 0; g < n; g++)
      r = e[t[g]], r.options.mass > 0 && this._placeInTree(y.root, r);
    return y;
  }
  /**
   * this updates the mass of a branch. this is increased by adding a node.
   * @param {object} parentBranch
   * @param {Node} node
   * @private
   */
  _updateBranchMass(e, t) {
    const r = e.centerOfMass, n = e.mass + t.options.mass, o = 1 / n;
    r.x = r.x * e.mass + t.x * t.options.mass, r.x *= o, r.y = r.y * e.mass + t.y * t.options.mass, r.y *= o, e.mass = n;
    const s = Math.max(Math.max(t.height, t.radius), t.width);
    e.maxWidth = e.maxWidth < s ? s : e.maxWidth;
  }
  /**
   * determine in which branch the node will be placed.
   * @param {object} parentBranch
   * @param {Node} node
   * @param {boolean} skipMassUpdate
   * @private
   */
  _placeInTree(e, t, r) {
    (r != !0 || r === void 0) && this._updateBranchMass(e, t);
    const n = e.children.NW.range;
    let o;
    n.maxX > t.x ? n.maxY > t.y ? o = "NW" : o = "SW" : n.maxY > t.y ? o = "NE" : o = "SE", this._placeInRegion(e, t, o);
  }
  /**
   * actually place the node in a region (or branch)
   * @param {object} parentBranch
   * @param {Node} node
   * @param {'NW'| 'NE' | 'SW' | 'SE'} region
   * @private
   */
  _placeInRegion(e, t, r) {
    const n = e.children[r];
    switch (n.childrenCount) {
      case 0:
        n.children.data = t, n.childrenCount = 1, this._updateBranchMass(n, t);
        break;
      case 1:
        n.children.data.x === t.x && n.children.data.y === t.y ? (t.x += this._rng(), t.y += this._rng()) : (this._splitBranch(n), this._placeInTree(n, t));
        break;
      case 4:
        this._placeInTree(n, t);
        break;
    }
  }
  /**
   * this function splits a branch into 4 sub branches. If the branch contained a node, we place it in the subbranch
   * after the split is complete.
   * @param {object} parentBranch
   * @private
   */
  _splitBranch(e) {
    let t = null;
    e.childrenCount === 1 && (t = e.children.data, e.mass = 0, e.centerOfMass.x = 0, e.centerOfMass.y = 0), e.childrenCount = 4, e.children.data = null, this._insertRegion(e, "NW"), this._insertRegion(e, "NE"), this._insertRegion(e, "SW"), this._insertRegion(e, "SE"), t != null && this._placeInTree(e, t);
  }
  /**
   * This function subdivides the region into four new segments.
   * Specifically, this inserts a single new segment.
   * It fills the children section of the parentBranch
   * @param {object} parentBranch
   * @param {'NW'| 'NE' | 'SW' | 'SE'} region
   * @private
   */
  _insertRegion(e, t) {
    let r, n, o, s;
    const a = 0.5 * e.size;
    switch (t) {
      case "NW":
        r = e.range.minX, n = e.range.minX + a, o = e.range.minY, s = e.range.minY + a;
        break;
      case "NE":
        r = e.range.minX + a, n = e.range.maxX, o = e.range.minY, s = e.range.minY + a;
        break;
      case "SW":
        r = e.range.minX, n = e.range.minX + a, o = e.range.minY + a, s = e.range.maxY;
        break;
      case "SE":
        r = e.range.minX + a, n = e.range.maxX, o = e.range.minY + a, s = e.range.maxY;
        break;
    }
    e.children[t] = {
      centerOfMass: {
        x: 0,
        y: 0
      },
      mass: 0,
      range: {
        minX: r,
        maxX: n,
        minY: o,
        maxY: s
      },
      size: 0.5 * e.size,
      calcSize: 2 * e.calcSize,
      children: {
        data: null
      },
      maxWidth: 0,
      level: e.level + 1,
      childrenCount: 0
    };
  }
  //---------------------------  DEBUGGING BELOW  ---------------------------//
  /**
   * This function is for debugging purposed, it draws the tree.
   * @param {CanvasRenderingContext2D} ctx
   * @param {string} color
   * @private
   */
  _debug(e, t) {
    this.barnesHutTree !== void 0 && (e.lineWidth = 1, this._drawBranch(this.barnesHutTree.root, e, t));
  }
  /**
   * This function is for debugging purposes. It draws the branches recursively.
   * @param {object} branch
   * @param {CanvasRenderingContext2D} ctx
   * @param {string} color
   * @private
   */
  _drawBranch(e, t, r) {
    r === void 0 && (r = "#FF0000"), e.childrenCount === 4 && (this._drawBranch(e.children.NW, t), this._drawBranch(e.children.NE, t), this._drawBranch(e.children.SE, t), this._drawBranch(e.children.SW, t)), t.strokeStyle = r, t.beginPath(), t.moveTo(e.range.minX, e.range.minY), t.lineTo(e.range.maxX, e.range.minY), t.stroke(), t.beginPath(), t.moveTo(e.range.maxX, e.range.minY), t.lineTo(e.range.maxX, e.range.maxY), t.stroke(), t.beginPath(), t.moveTo(e.range.maxX, e.range.maxY), t.lineTo(e.range.minX, e.range.maxY), t.stroke(), t.beginPath(), t.moveTo(e.range.minX, e.range.maxY), t.lineTo(e.range.minX, e.range.minY), t.stroke();
  }
}
class Wse {
  /**
   * @param {object} body
   * @param {{physicsNodeIndices: Array, physicsEdgeIndices: Array, forces: {}, velocities: {}}} physicsBody
   * @param {object} options
   */
  constructor(e, t, r) {
    this._rng = nd("REPULSION SOLVER"), this.body = e, this.physicsBody = t, this.setOptions(r);
  }
  /**
   *
   * @param {object} options
   */
  setOptions(e) {
    this.options = e;
  }
  /**
   * Calculate the forces the nodes apply on each other based on a repulsion field.
   * This field is linearly approximated.
   * @private
   */
  solve() {
    let e, t, r, n, o, s, a, l;
    const d = this.body.nodes, h = this.physicsBody.physicsNodeIndices, c = this.physicsBody.forces, u = this.options.nodeDistance, f = -2 / 3 / u, v = 4 / 3;
    for (let y = 0; y < h.length - 1; y++) {
      a = d[h[y]];
      for (let g = y + 1; g < h.length; g++)
        l = d[h[g]], e = l.x - a.x, t = l.y - a.y, r = Math.sqrt(e * e + t * t), r === 0 && (r = 0.1 * this._rng(), e = r), r < 2 * u && (r < 0.5 * u ? s = 1 : s = f * r + v, s = s / r, n = e * s, o = t * s, c[a.id].x -= n, c[a.id].y -= o, c[l.id].x += n, c[l.id].y += o);
    }
  }
}
class Hse {
  /**
   * @param {object} body
   * @param {{physicsNodeIndices: Array, physicsEdgeIndices: Array, forces: {}, velocities: {}}} physicsBody
   * @param {object} options
   */
  constructor(e, t, r) {
    this.body = e, this.physicsBody = t, this.setOptions(r);
  }
  /**
   *
   * @param {object} options
   */
  setOptions(e) {
    this.options = e, this.overlapAvoidanceFactor = Math.max(0, Math.min(1, this.options.avoidOverlap || 0));
  }
  /**
   * Calculate the forces the nodes apply on each other based on a repulsion field.
   * This field is linearly approximated.
   * @private
   */
  solve() {
    const e = this.body.nodes, t = this.physicsBody.physicsNodeIndices, r = this.physicsBody.forces, n = this.options.nodeDistance;
    for (let o = 0; o < t.length - 1; o++) {
      const s = e[t[o]];
      for (let a = o + 1; a < t.length; a++) {
        const l = e[t[a]];
        if (s.level === l.level) {
          const d = n + this.overlapAvoidanceFactor * ((s.shape.radius || 0) / 2 + (l.shape.radius || 0) / 2), h = l.x - s.x, c = l.y - s.y, u = Math.sqrt(h * h + c * c), f = 0.05;
          let v;
          u < d ? v = -Math.pow(f * u, 2) + Math.pow(f * d, 2) : v = 0, u !== 0 && (v = v / u);
          const y = h * v, g = c * v;
          r[s.id].x -= y, r[s.id].y -= g, r[l.id].x += y, r[l.id].y += g;
        }
      }
    }
  }
}
class vc {
  /**
   * @param {object} body
   * @param {{physicsNodeIndices: Array, physicsEdgeIndices: Array, forces: {}, velocities: {}}} physicsBody
   * @param {object} options
   */
  constructor(e, t, r) {
    this.body = e, this.physicsBody = t, this.setOptions(r);
  }
  /**
   *
   * @param {object} options
   */
  setOptions(e) {
    this.options = e;
  }
  /**
   * This function calculates the springforces on the nodes, accounting for the support nodes.
   * @private
   */
  solve() {
    let e, t;
    const r = this.physicsBody.physicsEdgeIndices, n = this.body.edges;
    let o, s, a;
    for (let l = 0; l < r.length; l++)
      t = n[r[l]], t.connected === !0 && t.toId !== t.fromId && this.body.nodes[t.toId] !== void 0 && this.body.nodes[t.fromId] !== void 0 && (t.edgeType.via !== void 0 ? (e = t.options.length === void 0 ? this.options.springLength : t.options.length, o = t.to, s = t.edgeType.via, a = t.from, this._calculateSpringForce(o, s, 0.5 * e), this._calculateSpringForce(s, a, 0.5 * e)) : (e = t.options.length === void 0 ? this.options.springLength * 1.5 : t.options.length, this._calculateSpringForce(t.from, t.to, e)));
  }
  /**
   * This is the code actually performing the calculation for the function above.
   * @param {Node} node1
   * @param {Node} node2
   * @param {number} edgeLength
   * @private
   */
  _calculateSpringForce(e, t, r) {
    const n = e.x - t.x, o = e.y - t.y, s = Math.max(Math.sqrt(n * n + o * o), 0.01), a = this.options.springConstant * (r - s) / s, l = n * a, d = o * a;
    this.physicsBody.forces[e.id] !== void 0 && (this.physicsBody.forces[e.id].x += l, this.physicsBody.forces[e.id].y += d), this.physicsBody.forces[t.id] !== void 0 && (this.physicsBody.forces[t.id].x -= l, this.physicsBody.forces[t.id].y -= d);
  }
}
class Vse {
  /**
   * @param {object} body
   * @param {{physicsNodeIndices: Array, physicsEdgeIndices: Array, forces: {}, velocities: {}}} physicsBody
   * @param {object} options
   */
  constructor(e, t, r) {
    this.body = e, this.physicsBody = t, this.setOptions(r);
  }
  /**
   *
   * @param {object} options
   */
  setOptions(e) {
    this.options = e;
  }
  /**
   * This function calculates the springforces on the nodes, accounting for the support nodes.
   * @private
   */
  solve() {
    let e, t, r, n, o, s, a, l;
    const d = this.body.edges, h = 0.5, c = this.physicsBody.physicsEdgeIndices, u = this.physicsBody.physicsNodeIndices, f = this.physicsBody.forces;
    for (let w = 0; w < u.length; w++) {
      const T = u[w];
      f[T].springFx = 0, f[T].springFy = 0;
    }
    for (let w = 0; w < c.length; w++)
      t = d[c[w]], t.connected === !0 && (e = t.options.length === void 0 ? this.options.springLength : t.options.length, r = t.from.x - t.to.x, n = t.from.y - t.to.y, l = Math.sqrt(r * r + n * n), l = l === 0 ? 0.01 : l, a = this.options.springConstant * (e - l) / l, o = r * a, s = n * a, t.to.level != t.from.level ? (f[t.toId] !== void 0 && (f[t.toId].springFx -= o, f[t.toId].springFy -= s), f[t.fromId] !== void 0 && (f[t.fromId].springFx += o, f[t.fromId].springFy += s)) : (f[t.toId] !== void 0 && (f[t.toId].x -= h * o, f[t.toId].y -= h * s), f[t.fromId] !== void 0 && (f[t.fromId].x += h * o, f[t.fromId].y += h * s)));
    a = 1;
    let v, y;
    for (let w = 0; w < u.length; w++) {
      const T = u[w];
      v = Math.min(a, Math.max(-a, f[T].springFx)), y = Math.min(a, Math.max(-a, f[T].springFy)), f[T].x += v, f[T].y += y;
    }
    let g = 0, p = 0;
    for (let w = 0; w < u.length; w++) {
      const T = u[w];
      g += f[T].x, p += f[T].y;
    }
    const m = g / u.length, $ = p / u.length;
    for (let w = 0; w < u.length; w++) {
      const T = u[w];
      f[T].x -= m, f[T].y -= $;
    }
  }
}
class ka {
  /**
   * @param {object} body
   * @param {{physicsNodeIndices: Array, physicsEdgeIndices: Array, forces: {}, velocities: {}}} physicsBody
   * @param {object} options
   */
  constructor(e, t, r) {
    this.body = e, this.physicsBody = t, this.setOptions(r);
  }
  /**
   *
   * @param {object} options
   */
  setOptions(e) {
    this.options = e;
  }
  /**
   * Calculates forces for each node
   */
  solve() {
    let e, t, r, n;
    const o = this.body.nodes, s = this.physicsBody.physicsNodeIndices, a = this.physicsBody.forces;
    for (let l = 0; l < s.length; l++) {
      const d = s[l];
      n = o[d], e = -n.x, t = -n.y, r = Math.sqrt(e * e + t * t), this._calculateForces(r, e, t, a, n);
    }
  }
  /**
   * Calculate the forces based on the distance.
   * @param {number} distance
   * @param {number} dx
   * @param {number} dy
   * @param {Object<Node.id, vis.Node>} forces
   * @param {Node} node
   * @private
   */
  _calculateForces(e, t, r, n, o) {
    const s = e === 0 ? 0 : this.options.centralGravity / e;
    n[o.id].x = t * s, n[o.id].y = r * s;
  }
}
class Use extends $S {
  /**
   * @param {object} body
   * @param {{physicsNodeIndices: Array, physicsEdgeIndices: Array, forces: {}, velocities: {}}} physicsBody
   * @param {object} options
   */
  constructor(e, t, r) {
    super(e, t, r), this._rng = nd("FORCE ATLAS 2 BASED REPULSION SOLVER");
  }
  /**
   * Calculate the forces based on the distance.
   * @param {number} distance
   * @param {number} dx
   * @param {number} dy
   * @param {Node} node
   * @param {object} parentBranch
   * @private
   */
  _calculateForces(e, t, r, n, o) {
    e === 0 && (e = 0.1 * this._rng(), t = e), this.overlapAvoidanceFactor < 1 && n.shape.radius && (e = Math.max(0.1 + this.overlapAvoidanceFactor * n.shape.radius, e - n.shape.radius));
    const s = n.edges.length + 1, a = this.options.gravitationalConstant * o.mass * n.options.mass * s / Math.pow(e, 2), l = t * a, d = r * a;
    this.physicsBody.forces[n.id].x += l, this.physicsBody.forces[n.id].y += d;
  }
}
class Gse extends ka {
  /**
   * @param {object} body
   * @param {{physicsNodeIndices: Array, physicsEdgeIndices: Array, forces: {}, velocities: {}}} physicsBody
   * @param {object} options
   */
  constructor(e, t, r) {
    super(e, t, r);
  }
  /**
   * Calculate the forces based on the distance.
   * @param {number} distance
   * @param {number} dx
   * @param {number} dy
   * @param {Object<Node.id, Node>} forces
   * @param {Node} node
   * @private
   */
  _calculateForces(e, t, r, n, o) {
    if (e > 0) {
      const s = o.edges.length + 1, a = this.options.centralGravity * s * o.options.mass;
      n[o.id].x = t * a, n[o.id].y = r * a;
    }
  }
}
class Kse {
  /**
   * @param {object} body
   */
  constructor(e) {
    this.body = e, this.physicsBody = {
      physicsNodeIndices: [],
      physicsEdgeIndices: [],
      forces: {},
      velocities: {}
    }, this.physicsEnabled = !0, this.simulationInterval = 1e3 / 60, this.requiresTimeout = !0, this.previousStates = {}, this.referenceState = {}, this.freezeCache = {}, this.renderTimer = void 0, this.adaptiveTimestep = !1, this.adaptiveTimestepEnabled = !1, this.adaptiveCounter = 0, this.adaptiveInterval = 3, this.stabilized = !1, this.startedStabilization = !1, this.stabilizationIterations = 0, this.ready = !1, this.options = {}, this.defaultOptions = {
      enabled: !0,
      barnesHut: {
        theta: 0.5,
        gravitationalConstant: -2e3,
        centralGravity: 0.3,
        springLength: 95,
        springConstant: 0.04,
        damping: 0.09,
        avoidOverlap: 0
      },
      forceAtlas2Based: {
        theta: 0.5,
        gravitationalConstant: -50,
        centralGravity: 0.01,
        springConstant: 0.08,
        springLength: 100,
        damping: 0.4,
        avoidOverlap: 0
      },
      repulsion: {
        centralGravity: 0.2,
        springLength: 200,
        springConstant: 0.05,
        nodeDistance: 100,
        damping: 0.09,
        avoidOverlap: 0
      },
      hierarchicalRepulsion: {
        centralGravity: 0,
        springLength: 100,
        springConstant: 0.01,
        nodeDistance: 120,
        damping: 0.09
      },
      maxVelocity: 50,
      minVelocity: 0.75,
      // px/s
      solver: "barnesHut",
      stabilization: {
        enabled: !0,
        iterations: 1e3,
        // maximum number of iteration to stabilize
        updateInterval: 50,
        onlyDynamicEdges: !1,
        fit: !0
      },
      timestep: 0.5,
      adaptiveTimestep: !0,
      wind: {
        x: 0,
        y: 0
      }
    }, Ce(this.options, this.defaultOptions), this.timestep = 0.5, this.layoutFailed = !1, this.bindEventListeners();
  }
  /**
   * Binds event listeners
   */
  bindEventListeners() {
    this.body.emitter.on("initPhysics", () => {
      this.initPhysics();
    }), this.body.emitter.on("_layoutFailed", () => {
      this.layoutFailed = !0;
    }), this.body.emitter.on("resetPhysics", () => {
      this.stopSimulation(), this.ready = !1;
    }), this.body.emitter.on("disablePhysics", () => {
      this.physicsEnabled = !1, this.stopSimulation();
    }), this.body.emitter.on("restorePhysics", () => {
      this.setOptions(this.options), this.ready === !0 && this.startSimulation();
    }), this.body.emitter.on("startSimulation", () => {
      this.ready === !0 && this.startSimulation();
    }), this.body.emitter.on("stopSimulation", () => {
      this.stopSimulation();
    }), this.body.emitter.on("destroy", () => {
      this.stopSimulation(!1), this.body.emitter.off();
    }), this.body.emitter.on("_dataChanged", () => {
      this.updatePhysicsData();
    });
  }
  /**
   * set the physics options
   * @param {object} options
   */
  setOptions(e) {
    if (e !== void 0)
      if (e === !1)
        this.options.enabled = !1, this.physicsEnabled = !1, this.stopSimulation();
      else if (e === !0)
        this.options.enabled = !0, this.physicsEnabled = !0, this.startSimulation();
      else {
        this.physicsEnabled = !0, il(["stabilization"], this.options, e), Et(this.options, e, "stabilization"), e.enabled === void 0 && (this.options.enabled = !0), this.options.enabled === !1 && (this.physicsEnabled = !1, this.stopSimulation());
        const t = this.options.wind;
        t && ((typeof t.x != "number" || Tu(t.x)) && (t.x = 0), (typeof t.y != "number" || Tu(t.y)) && (t.y = 0)), this.timestep = this.options.timestep;
      }
    this.init();
  }
  /**
   * configure the engine.
   */
  init() {
    let e;
    this.options.solver === "forceAtlas2Based" ? (e = this.options.forceAtlas2Based, this.nodesSolver = new Use(this.body, this.physicsBody, e), this.edgesSolver = new vc(this.body, this.physicsBody, e), this.gravitySolver = new Gse(this.body, this.physicsBody, e)) : this.options.solver === "repulsion" ? (e = this.options.repulsion, this.nodesSolver = new Wse(this.body, this.physicsBody, e), this.edgesSolver = new vc(this.body, this.physicsBody, e), this.gravitySolver = new ka(this.body, this.physicsBody, e)) : this.options.solver === "hierarchicalRepulsion" ? (e = this.options.hierarchicalRepulsion, this.nodesSolver = new Hse(this.body, this.physicsBody, e), this.edgesSolver = new Vse(this.body, this.physicsBody, e), this.gravitySolver = new ka(this.body, this.physicsBody, e)) : (e = this.options.barnesHut, this.nodesSolver = new $S(this.body, this.physicsBody, e), this.edgesSolver = new vc(this.body, this.physicsBody, e), this.gravitySolver = new ka(this.body, this.physicsBody, e)), this.modelOptions = e;
  }
  /**
   * initialize the engine
   */
  initPhysics() {
    this.physicsEnabled === !0 && this.options.enabled === !0 ? this.options.stabilization.enabled === !0 ? this.stabilize() : (this.stabilized = !1, this.ready = !0, this.body.emitter.emit("fit", {}, this.layoutFailed), this.startSimulation()) : (this.ready = !0, this.body.emitter.emit("fit"));
  }
  /**
   * Start the simulation
   */
  startSimulation() {
    if (this.physicsEnabled === !0 && this.options.enabled === !0) {
      if (this.stabilized = !1, this.adaptiveTimestep = !1, this.body.emitter.emit("_resizeNodes"), this.viewFunction === void 0) {
        var e;
        this.viewFunction = S(e = this.simulationStep).call(e, this), this.body.emitter.on("initRedraw", this.viewFunction), this.body.emitter.emit("_startRendering");
      }
    } else
      this.body.emitter.emit("_redraw");
  }
  /**
   * Stop the simulation, force stabilization.
   * @param {boolean} [emit]
   */
  stopSimulation() {
    let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !0;
    this.stabilized = !0, e === !0 && this._emitStabilized(), this.viewFunction !== void 0 && (this.body.emitter.off("initRedraw", this.viewFunction), this.viewFunction = void 0, e === !0 && this.body.emitter.emit("_stopRendering"));
  }
  /**
   * The viewFunction inserts this step into each render loop. It calls the physics tick and handles the cleanup at stabilized.
   *
   */
  simulationStep() {
    const e = Qa();
    this.physicsTick(), (Qa() - e < 0.4 * this.simulationInterval || this.runDoubleSpeed === !0) && this.stabilized === !1 && (this.physicsTick(), this.runDoubleSpeed = !0), this.stabilized === !0 && this.stopSimulation();
  }
  /**
   * trigger the stabilized event.
   * @param {number} [amountOfIterations]
   * @private
   */
  _emitStabilized() {
    let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : this.stabilizationIterations;
    (this.stabilizationIterations > 1 || this.startedStabilization === !0) && lr(() => {
      this.body.emitter.emit("stabilized", {
        iterations: e
      }), this.startedStabilization = !1, this.stabilizationIterations = 0;
    }, 0);
  }
  /**
   * Calculate the forces for one physics iteration and move the nodes.
   * @private
   */
  physicsStep() {
    this.gravitySolver.solve(), this.nodesSolver.solve(), this.edgesSolver.solve(), this.moveNodes();
  }
  /**
   * Make dynamic adjustments to the timestep, based on current state.
   *
   * Helper function for physicsTick().
   * @private
   */
  adjustTimeStep() {
    this._evaluateStepQuality() === !0 ? this.timestep = 1.2 * this.timestep : this.timestep / 1.2 < this.options.timestep ? this.timestep = this.options.timestep : (this.adaptiveCounter = -1, this.timestep = Math.max(this.options.timestep, this.timestep / 1.2));
  }
  /**
   * A single simulation step (or 'tick') in the physics simulation
   * @private
   */
  physicsTick() {
    this._startStabilizing(), this.stabilized !== !0 && (this.adaptiveTimestep === !0 && this.adaptiveTimestepEnabled === !0 ? (this.adaptiveCounter % this.adaptiveInterval === 0 ? (this.timestep = 2 * this.timestep, this.physicsStep(), this.revert(), this.timestep = 0.5 * this.timestep, this.physicsStep(), this.physicsStep(), this.adjustTimeStep()) : this.physicsStep(), this.adaptiveCounter += 1) : (this.timestep = this.options.timestep, this.physicsStep()), this.stabilized === !0 && this.revert(), this.stabilizationIterations++);
  }
  /**
   * Nodes and edges can have the physics toggles on or off. A collection of indices is created here so we can skip the check all the time.
   * @private
   */
  updatePhysicsData() {
    this.physicsBody.forces = {}, this.physicsBody.physicsNodeIndices = [], this.physicsBody.physicsEdgeIndices = [];
    const e = this.body.nodes, t = this.body.edges;
    for (const r in e)
      Object.prototype.hasOwnProperty.call(e, r) && e[r].options.physics === !0 && this.physicsBody.physicsNodeIndices.push(e[r].id);
    for (const r in t)
      Object.prototype.hasOwnProperty.call(t, r) && t[r].options.physics === !0 && this.physicsBody.physicsEdgeIndices.push(t[r].id);
    for (let r = 0; r < this.physicsBody.physicsNodeIndices.length; r++) {
      const n = this.physicsBody.physicsNodeIndices[r];
      this.physicsBody.forces[n] = {
        x: 0,
        y: 0
      }, this.physicsBody.velocities[n] === void 0 && (this.physicsBody.velocities[n] = {
        x: 0,
        y: 0
      });
    }
    for (const r in this.physicsBody.velocities)
      e[r] === void 0 && delete this.physicsBody.velocities[r];
  }
  /**
   * Revert the simulation one step. This is done so after stabilization, every new start of the simulation will also say stabilized.
   */
  revert() {
    const e = me(this.previousStates), t = this.body.nodes, r = this.physicsBody.velocities;
    this.referenceState = {};
    for (let n = 0; n < e.length; n++) {
      const o = e[n];
      t[o] !== void 0 ? t[o].options.physics === !0 && (this.referenceState[o] = {
        positions: {
          x: t[o].x,
          y: t[o].y
        }
      }, r[o].x = this.previousStates[o].vx, r[o].y = this.previousStates[o].vy, t[o].x = this.previousStates[o].x, t[o].y = this.previousStates[o].y) : delete this.previousStates[o];
    }
  }
  /**
   * This compares the reference state to the current state
   * @returns {boolean}
   * @private
   */
  _evaluateStepQuality() {
    let e, t, r;
    const n = this.body.nodes, o = this.referenceState, s = 0.3;
    for (const a in this.referenceState)
      if (Object.prototype.hasOwnProperty.call(this.referenceState, a) && n[a] !== void 0 && (e = n[a].x - o[a].positions.x, t = n[a].y - o[a].positions.y, r = Math.sqrt(Math.pow(e, 2) + Math.pow(t, 2)), r > s))
        return !1;
    return !0;
  }
  /**
   * move the nodes one timestep and check if they are stabilized
   */
  moveNodes() {
    const e = this.physicsBody.physicsNodeIndices;
    let t = 0, r = 0;
    const n = 5;
    for (let o = 0; o < e.length; o++) {
      const s = e[o], a = this._performStep(s);
      t = Math.max(t, a), r += a;
    }
    this.adaptiveTimestepEnabled = r / e.length < n, this.stabilized = t < this.options.minVelocity;
  }
  /**
   * Calculate new velocity for a coordinate direction
   * @param {number} v  velocity for current coordinate
   * @param {number} f  regular force for current coordinate
   * @param {number} m  mass of current node
   * @returns {number} new velocity for current coordinate
   * @private
   */
  calculateComponentVelocity(e, t, r) {
    const n = this.modelOptions.damping * e, o = (t - n) / r;
    e += o * this.timestep;
    const s = this.options.maxVelocity || 1e9;
    return Math.abs(e) > s && (e = e > 0 ? s : -s), e;
  }
  /**
   * Perform the actual step
   * @param {Node.id} nodeId
   * @returns {number} the new velocity of given node
   * @private
   */
  _performStep(e) {
    const t = this.body.nodes[e], r = this.physicsBody.forces[e];
    this.options.wind && (r.x += this.options.wind.x, r.y += this.options.wind.y);
    const n = this.physicsBody.velocities[e];
    return this.previousStates[e] = {
      x: t.x,
      y: t.y,
      vx: n.x,
      vy: n.y
    }, t.options.fixed.x === !1 ? (n.x = this.calculateComponentVelocity(n.x, r.x, t.options.mass), t.x += n.x * this.timestep) : (r.x = 0, n.x = 0), t.options.fixed.y === !1 ? (n.y = this.calculateComponentVelocity(n.y, r.y, t.options.mass), t.y += n.y * this.timestep) : (r.y = 0, n.y = 0), Math.sqrt(Math.pow(n.x, 2) + Math.pow(n.y, 2));
  }
  /**
   * When initializing and stabilizing, we can freeze nodes with a predefined position.
   * This greatly speeds up stabilization because only the supportnodes for the smoothCurves have to settle.
   * @private
   */
  _freezeNodes() {
    const e = this.body.nodes;
    for (const t in e)
      if (Object.prototype.hasOwnProperty.call(e, t) && e[t].x && e[t].y) {
        const r = e[t].options.fixed;
        this.freezeCache[t] = {
          x: r.x,
          y: r.y
        }, r.x = !0, r.y = !0;
      }
  }
  /**
   * Unfreezes the nodes that have been frozen by _freezeDefinedNodes.
   * @private
   */
  _restoreFrozenNodes() {
    const e = this.body.nodes;
    for (const t in e)
      Object.prototype.hasOwnProperty.call(e, t) && this.freezeCache[t] !== void 0 && (e[t].options.fixed.x = this.freezeCache[t].x, e[t].options.fixed.y = this.freezeCache[t].y);
    this.freezeCache = {};
  }
  /**
   * Find a stable position for all nodes
   * @param {number} [iterations]
   */
  stabilize() {
    let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : this.options.stabilization.iterations;
    if (typeof e != "number" && (e = this.options.stabilization.iterations, console.error("The stabilize method needs a numeric amount of iterations. Switching to default: ", e)), this.physicsBody.physicsNodeIndices.length === 0) {
      this.ready = !0;
      return;
    }
    this.adaptiveTimestep = this.options.adaptiveTimestep, this.body.emitter.emit("_resizeNodes"), this.stopSimulation(), this.stabilized = !1, this.body.emitter.emit("_blockRedraw"), this.targetIterations = e, this.options.stabilization.onlyDynamicEdges === !0 && this._freezeNodes(), this.stabilizationIterations = 0, lr(() => this._stabilizationBatch(), 0);
  }
  /**
   * If not already stabilizing, start it and emit a start event.
   * @returns {boolean} true if stabilization started with this call
   * @private
   */
  _startStabilizing() {
    return this.startedStabilization === !0 ? !1 : (this.body.emitter.emit("startStabilizing"), this.startedStabilization = !0, !0);
  }
  /**
   * One batch of stabilization
   * @private
   */
  _stabilizationBatch() {
    const e = () => this.stabilized === !1 && this.stabilizationIterations < this.targetIterations, t = () => {
      this.body.emitter.emit("stabilizationProgress", {
        iterations: this.stabilizationIterations,
        total: this.targetIterations
      });
    };
    this._startStabilizing() && t();
    let r = 0;
    for (; e() && r < this.options.stabilization.updateInterval; )
      this.physicsTick(), r++;
    if (t(), e()) {
      var n;
      lr(S(n = this._stabilizationBatch).call(n, this), 0);
    } else
      this._finalizeStabilization();
  }
  /**
   * Wrap up the stabilization, fit and emit the events.
   * @private
   */
  _finalizeStabilization() {
    this.body.emitter.emit("_allowRedraw"), this.options.stabilization.fit === !0 && this.body.emitter.emit("fit"), this.options.stabilization.onlyDynamicEdges === !0 && this._restoreFrozenNodes(), this.body.emitter.emit("stabilizationIterationsDone"), this.body.emitter.emit("_requestRedraw"), this.stabilized === !0 ? this._emitStabilized() : this.startSimulation(), this.ready = !0;
  }
  //---------------------------  DEBUGGING BELOW  ---------------------------//
  /**
   * Debug function that display arrows for the forces currently active in the network.
   *
   * Use this when debugging only.
   * @param {CanvasRenderingContext2D} ctx
   * @private
   */
  _drawForces(e) {
    for (let t = 0; t < this.physicsBody.physicsNodeIndices.length; t++) {
      const r = this.physicsBody.physicsNodeIndices[t], n = this.body.nodes[r], o = this.physicsBody.forces[r], s = 20, a = 0.03, l = Math.sqrt(Math.pow(o.x, 2) + Math.pow(o.x, 2)), d = Math.min(Math.max(5, l), 15), h = 3 * d, c = Eu((180 - Math.min(1, Math.max(0, a * l)) * 180) / 360, 1, 1), u = {
        x: n.x + s * o.x,
        y: n.y + s * o.y
      };
      e.lineWidth = d, e.strokeStyle = c, e.beginPath(), e.moveTo(n.x, n.y), e.lineTo(u.x, u.y), e.stroke();
      const f = Math.atan2(o.y, o.x);
      e.fillStyle = c, mS.draw(e, {
        type: "arrow",
        point: u,
        angle: f,
        length: h
      }), Ts(e).call(e);
    }
  }
}
let fa;
const Yse = new Uint8Array(16);
function qse() {
  if (!fa && (fa = typeof crypto < "u" && crypto.getRandomValues && crypto.getRandomValues.bind(crypto), !fa))
    throw new Error("crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported");
  return fa(Yse);
}
const We = [];
for (let i = 0; i < 256; ++i)
  We.push((i + 256).toString(16).slice(1));
function Xse(i, e = 0) {
  return We[i[e + 0]] + We[i[e + 1]] + We[i[e + 2]] + We[i[e + 3]] + "-" + We[i[e + 4]] + We[i[e + 5]] + "-" + We[i[e + 6]] + We[i[e + 7]] + "-" + We[i[e + 8]] + We[i[e + 9]] + "-" + We[i[e + 10]] + We[i[e + 11]] + We[i[e + 12]] + We[i[e + 13]] + We[i[e + 14]] + We[i[e + 15]];
}
const Jse = typeof crypto < "u" && crypto.randomUUID && crypto.randomUUID.bind(crypto);
var Db = {
  randomUUID: Jse
};
function yo(i, e, t) {
  if (Db.randomUUID && !i)
    return Db.randomUUID();
  i = i || {};
  const r = i.random || (i.rng || qse)();
  return r[6] = r[6] & 15 | 64, r[8] = r[8] & 63 | 128, Xse(r);
}
class Ze {
  /**
   * @ignore
   */
  constructor() {
  }
  /**
   * Find the center position of the network considering the bounding boxes
   * @param {Array.<Node>} allNodes
   * @param {Array.<Node>} [specificNodes]
   * @returns {{minX: number, maxX: number, minY: number, maxY: number}}
   * @static
   */
  static getRange(e) {
    let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : [], r = 1e9, n = -1e9, o = 1e9, s = -1e9, a;
    if (t.length > 0)
      for (let l = 0; l < t.length; l++)
        a = e[t[l]], o > a.shape.boundingBox.left && (o = a.shape.boundingBox.left), s < a.shape.boundingBox.right && (s = a.shape.boundingBox.right), r > a.shape.boundingBox.top && (r = a.shape.boundingBox.top), n < a.shape.boundingBox.bottom && (n = a.shape.boundingBox.bottom);
    return o === 1e9 && s === -1e9 && r === 1e9 && n === -1e9 && (r = 0, n = 0, o = 0, s = 0), {
      minX: o,
      maxX: s,
      minY: r,
      maxY: n
    };
  }
  /**
   * Find the center position of the network
   * @param {Array.<Node>} allNodes
   * @param {Array.<Node>} [specificNodes]
   * @returns {{minX: number, maxX: number, minY: number, maxY: number}}
   * @static
   */
  static getRangeCore(e) {
    let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : [], r = 1e9, n = -1e9, o = 1e9, s = -1e9, a;
    if (t.length > 0)
      for (let l = 0; l < t.length; l++)
        a = e[t[l]], o > a.x && (o = a.x), s < a.x && (s = a.x), r > a.y && (r = a.y), n < a.y && (n = a.y);
    return o === 1e9 && s === -1e9 && r === 1e9 && n === -1e9 && (r = 0, n = 0, o = 0, s = 0), {
      minX: o,
      maxX: s,
      minY: r,
      maxY: n
    };
  }
  /**
   * @param {object} range = {minX: minX, maxX: maxX, minY: minY, maxY: maxY};
   * @returns {{x: number, y: number}}
   * @static
   */
  static findCenter(e) {
    return {
      x: 0.5 * (e.maxX + e.minX),
      y: 0.5 * (e.maxY + e.minY)
    };
  }
  /**
   * This returns a clone of the options or options of the edge or node to be used for construction of new edges or check functions for new nodes.
   * @param {vis.Item} item
   * @param {'node'|undefined} type
   * @returns {{}}
   * @static
   */
  static cloneOptions(e, t) {
    const r = {};
    return t === void 0 || t === "node" ? (le(r, e.options, !0), r.x = e.x, r.y = e.y, r.amountOfConnections = e.edges.length) : le(r, e.options, !0), r;
  }
}
class Zse extends ue {
  /**
   * @param {object} options
   * @param {object} body
   * @param {Array.<HTMLImageElement>}imagelist
   * @param {Array} grouplist
   * @param {object} globalOptions
   * @param {object} defaultOptions     Global default options for nodes
   */
  constructor(e, t, r, n, o, s) {
    super(e, t, r, n, o, s), this.isCluster = !0, this.containedNodes = {}, this.containedEdges = {};
  }
  /**
   * Transfer child cluster data to current and disconnect the child cluster.
   *
   * Please consult the header comment in 'Clustering.js' for the fields set here.
   * @param {string|number} childClusterId  id of child cluster to open
   */
  _openChildCluster(e) {
    const t = this.body.nodes[e];
    if (this.containedNodes[e] === void 0)
      throw new Error("node with id: " + e + " not in current cluster");
    if (!t.isCluster)
      throw new Error("node with id: " + e + " is not a cluster");
    delete this.containedNodes[e], X(t.edges, (r) => {
      delete this.containedEdges[r.id];
    }), X(t.containedNodes, (r, n) => {
      this.containedNodes[n] = r;
    }), t.containedNodes = {}, X(t.containedEdges, (r, n) => {
      this.containedEdges[n] = r;
    }), t.containedEdges = {}, X(t.edges, (r) => {
      X(this.edges, (n) => {
        var o, s;
        const a = re(o = n.clusteringEdgeReplacingIds).call(o, r.id);
        a !== -1 && (X(r.clusteringEdgeReplacingIds, (l) => {
          n.clusteringEdgeReplacingIds.push(l), this.body.edges[l].edgeReplacedById = n.id;
        }), ar(s = n.clusteringEdgeReplacingIds).call(s, a, 1));
      });
    }), t.edges = [];
  }
}
class Qse {
  /**
   * @param {object} body
   */
  constructor(e) {
    this.body = e, this.clusteredNodes = {}, this.clusteredEdges = {}, this.options = {}, this.defaultOptions = {}, Ce(this.options, this.defaultOptions), this.body.emitter.on("_resetData", () => {
      this.clusteredNodes = {}, this.clusteredEdges = {};
    });
  }
  /**
   *
   * @param {number} hubsize
   * @param {object} options
   */
  clusterByHubsize(e, t) {
    e === void 0 ? e = this._getHubSize() : typeof e == "object" && (t = this._checkOptions(e), e = this._getHubSize());
    const r = [];
    for (let n = 0; n < this.body.nodeIndices.length; n++) {
      const o = this.body.nodes[this.body.nodeIndices[n]];
      o.edges.length >= e && r.push(o.id);
    }
    for (let n = 0; n < r.length; n++)
      this.clusterByConnection(r[n], t, !0);
    this.body.emitter.emit("_dataChanged");
  }
  /**
   * loop over all nodes, check if they adhere to the condition and cluster if needed.
   * @param {object} options
   * @param {boolean} [refreshData]
   */
  cluster() {
    let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}, t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !0;
    if (e.joinCondition === void 0)
      throw new Error("Cannot call clusterByNodeData without a joinCondition function in the options.");
    e = this._checkOptions(e);
    const r = {}, n = {};
    X(this.body.nodes, (o, s) => {
      o.options && e.joinCondition(o.options) === !0 && (r[s] = o, X(o.edges, (a) => {
        this.clusteredEdges[a.id] === void 0 && (n[a.id] = a);
      }));
    }), this._cluster(r, n, e, t);
  }
  /**
   * Cluster all nodes in the network that have only X edges
   * @param {number} edgeCount
   * @param {object} options
   * @param {boolean} [refreshData]
   */
  clusterByEdgeCount(e, t) {
    let r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !0;
    t = this._checkOptions(t);
    const n = [], o = {};
    let s, a, l;
    for (let d = 0; d < this.body.nodeIndices.length; d++) {
      const h = {}, c = {}, u = this.body.nodeIndices[d], f = this.body.nodes[u];
      if (o[u] === void 0) {
        l = 0, a = [];
        for (let v = 0; v < f.edges.length; v++)
          s = f.edges[v], this.clusteredEdges[s.id] === void 0 && (s.toId !== s.fromId && l++, a.push(s));
        if (l === e) {
          const v = function(g) {
            if (t.joinCondition === void 0 || t.joinCondition === null)
              return !0;
            const p = Ze.cloneOptions(g);
            return t.joinCondition(p);
          };
          let y = !0;
          for (let g = 0; g < a.length; g++) {
            s = a[g];
            const p = this._getConnectedId(s, u);
            if (v(f))
              c[s.id] = s, h[u] = f, h[p] = this.body.nodes[p], o[u] = !0;
            else {
              y = !1;
              break;
            }
          }
          if (me(h).length > 0 && me(c).length > 0 && y === !0) {
            const p = function() {
              for (let m = 0; m < n.length; ++m)
                for (const $ in h)
                  if (n[m].nodes[$] !== void 0)
                    return n[m];
            }();
            if (p !== void 0) {
              for (const m in h)
                p.nodes[m] === void 0 && (p.nodes[m] = h[m]);
              for (const m in c)
                p.edges[m] === void 0 && (p.edges[m] = c[m]);
            } else
              n.push({
                nodes: h,
                edges: c
              });
          }
        }
      }
    }
    for (let d = 0; d < n.length; d++)
      this._cluster(n[d].nodes, n[d].edges, t, !1);
    r === !0 && this.body.emitter.emit("_dataChanged");
  }
  /**
   * Cluster all nodes in the network that have only 1 edge
   * @param {object} options
   * @param {boolean} [refreshData]
   */
  clusterOutliers(e) {
    let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !0;
    this.clusterByEdgeCount(1, e, t);
  }
  /**
   * Cluster all nodes in the network that have only 2 edge
   * @param {object} options
   * @param {boolean} [refreshData]
   */
  clusterBridges(e) {
    let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !0;
    this.clusterByEdgeCount(2, e, t);
  }
  /**
   * suck all connected nodes of a node into the node.
   * @param {Node.id} nodeId
   * @param {object} options
   * @param {boolean} [refreshData]
   */
  clusterByConnection(e, t) {
    var r;
    let n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !0;
    if (e === void 0)
      throw new Error("No nodeId supplied to clusterByConnection!");
    if (this.body.nodes[e] === void 0)
      throw new Error("The nodeId given to clusterByConnection does not exist!");
    const o = this.body.nodes[e];
    t = this._checkOptions(t, o), t.clusterNodeProperties.x === void 0 && (t.clusterNodeProperties.x = o.x), t.clusterNodeProperties.y === void 0 && (t.clusterNodeProperties.y = o.y), t.clusterNodeProperties.fixed === void 0 && (t.clusterNodeProperties.fixed = {}, t.clusterNodeProperties.fixed.x = o.options.fixed.x, t.clusterNodeProperties.fixed.y = o.options.fixed.y);
    const s = {}, a = {}, l = o.id, d = Ze.cloneOptions(o);
    s[l] = o;
    for (let c = 0; c < o.edges.length; c++) {
      const u = o.edges[c];
      if (this.clusteredEdges[u.id] === void 0) {
        const f = this._getConnectedId(u, l);
        if (this.clusteredNodes[f] === void 0)
          if (f !== l)
            if (t.joinCondition === void 0)
              a[u.id] = u, s[f] = this.body.nodes[f];
            else {
              const v = Ze.cloneOptions(this.body.nodes[f]);
              t.joinCondition(d, v) === !0 && (a[u.id] = u, s[f] = this.body.nodes[f]);
            }
          else
            a[u.id] = u;
      }
    }
    const h = _n(r = me(s)).call(r, function(c) {
      return s[c].id;
    });
    for (const c in s) {
      if (!Object.prototype.hasOwnProperty.call(s, c)) continue;
      const u = s[c];
      for (let f = 0; f < u.edges.length; f++) {
        const v = u.edges[f];
        re(h).call(h, this._getConnectedId(v, u.id)) > -1 && (a[v.id] = v);
      }
    }
    this._cluster(s, a, t, n);
  }
  /**
   * This function creates the edges that will be attached to the cluster
   * It looks for edges that are connected to the nodes from the "outside' of the cluster.
   * @param {{Node.id: vis.Node}} childNodesObj
   * @param {{vis.Edge.id: vis.Edge}} childEdgesObj
   * @param {object} clusterNodeProperties
   * @param {object} clusterEdgeProperties
   * @private
   */
  _createClusterEdges(e, t, r, n) {
    let o, s, a, l, d, h;
    const c = me(e), u = [];
    for (let y = 0; y < c.length; y++) {
      s = c[y], a = e[s];
      for (let g = 0; g < a.edges.length; g++)
        o = a.edges[g], this.clusteredEdges[o.id] === void 0 && (o.toId == o.fromId ? t[o.id] = o : o.toId == s ? (l = r.id, d = o.fromId, h = d) : (l = o.toId, d = r.id, h = l), e[h] === void 0 && u.push({
          edge: o,
          fromId: d,
          toId: l
        }));
    }
    const f = [], v = function(y) {
      for (let g = 0; g < f.length; g++) {
        const p = f[g], m = y.fromId === p.fromId && y.toId === p.toId, $ = y.fromId === p.toId && y.toId === p.fromId;
        if (m || $)
          return p;
      }
      return null;
    };
    for (let y = 0; y < u.length; y++) {
      const g = u[y], p = g.edge;
      let m = v(g);
      m === null ? (m = this._createClusteredEdge(g.fromId, g.toId, p, n), f.push(m)) : m.clusteringEdgeReplacingIds.push(p.id), this.body.edges[p.id].edgeReplacedById = m.id, this._backupEdgeOptions(p), p.setOptions({
        physics: !1
      });
    }
  }
  /**
   * This function checks the options that can be supplied to the different cluster functions
   * for certain fields and inserts defaults if needed
   * @param {object} options
   * @returns {*}
   * @private
   */
  _checkOptions() {
    let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    return e.clusterEdgeProperties === void 0 && (e.clusterEdgeProperties = {}), e.clusterNodeProperties === void 0 && (e.clusterNodeProperties = {}), e;
  }
  /**
   *
   * @param {object}    childNodesObj         | object with node objects, id as keys, same as childNodes except it also contains a source node
   * @param {object}    childEdgesObj         | object with edge objects, id as keys
   * @param {Array}     options               | object with {clusterNodeProperties, clusterEdgeProperties, processProperties}
   * @param {boolean}   refreshData | when true, do not wrap up
   * @private
   */
  _cluster(e, t, r) {
    let n = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : !0;
    const o = [];
    for (const h in e)
      Object.prototype.hasOwnProperty.call(e, h) && this.clusteredNodes[h] !== void 0 && o.push(h);
    for (let h = 0; h < o.length; ++h)
      delete e[o[h]];
    if (me(e).length == 0 || me(e).length == 1 && r.clusterNodeProperties.allowSingleNodeCluster != !0)
      return;
    let s = le({}, r.clusterNodeProperties);
    if (r.processProperties !== void 0) {
      const h = [];
      for (const u in e)
        if (Object.prototype.hasOwnProperty.call(e, u)) {
          const f = Ze.cloneOptions(e[u]);
          h.push(f);
        }
      const c = [];
      for (const u in t)
        if (Object.prototype.hasOwnProperty.call(t, u) && u.substr(0, 12) !== "clusterEdge:") {
          const f = Ze.cloneOptions(t[u], "edge");
          c.push(f);
        }
      if (s = r.processProperties(s, h, c), !s)
        throw new Error("The processProperties function does not return properties!");
    }
    s.id === void 0 && (s.id = "cluster:" + yo());
    const a = s.id;
    s.label === void 0 && (s.label = "cluster");
    let l;
    s.x === void 0 && (l = this._getClusterPosition(e), s.x = l.x), s.y === void 0 && (l === void 0 && (l = this._getClusterPosition(e)), s.y = l.y), s.id = a;
    const d = this.body.functions.createNode(s, Zse);
    d.containedNodes = e, d.containedEdges = t, d.clusterEdgeProperties = r.clusterEdgeProperties, this.body.nodes[s.id] = d, this._clusterEdges(e, t, s, r.clusterEdgeProperties), s.id = void 0, n === !0 && this.body.emitter.emit("_dataChanged");
  }
  /**
   *
   * @param {Edge} edge
   * @private
   */
  _backupEdgeOptions(e) {
    this.clusteredEdges[e.id] === void 0 && (this.clusteredEdges[e.id] = {
      physics: e.options.physics
    });
  }
  /**
   *
   * @param {Edge} edge
   * @private
   */
  _restoreEdge(e) {
    const t = this.clusteredEdges[e.id];
    t !== void 0 && (e.setOptions({
      physics: t.physics
    }), delete this.clusteredEdges[e.id]);
  }
  /**
   * Check if a node is a cluster.
   * @param {Node.id} nodeId
   * @returns {*}
   */
  isCluster(e) {
    return this.body.nodes[e] !== void 0 ? this.body.nodes[e].isCluster === !0 : (console.error("Node does not exist."), !1);
  }
  /**
   * get the position of the cluster node based on what's inside
   * @param {object} childNodesObj    | object with node objects, id as keys
   * @returns {{x: number, y: number}}
   * @private
   */
  _getClusterPosition(e) {
    const t = me(e);
    let r = e[t[0]].x, n = e[t[0]].x, o = e[t[0]].y, s = e[t[0]].y, a;
    for (let l = 1; l < t.length; l++)
      a = e[t[l]], r = a.x < r ? a.x : r, n = a.x > n ? a.x : n, o = a.y < o ? a.y : o, s = a.y > s ? a.y : s;
    return {
      x: 0.5 * (r + n),
      y: 0.5 * (o + s)
    };
  }
  /**
   * Open a cluster by calling this function.
   * @param {vis.Edge.id}  clusterNodeId | the ID of the cluster node
   * @param {object} options
   * @param {boolean} refreshData | wrap up afterwards if not true
   */
  openCluster(e, t) {
    let r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !0;
    if (e === void 0)
      throw new Error("No clusterNodeId supplied to openCluster.");
    const n = this.body.nodes[e];
    if (n === void 0)
      throw new Error("The clusterNodeId supplied to openCluster does not exist.");
    if (n.isCluster !== !0 || n.containedNodes === void 0 || n.containedEdges === void 0)
      throw new Error("The node:" + e + " is not a valid cluster.");
    const o = this.findNode(e), s = re(o).call(o, e) - 1;
    if (s >= 0) {
      const h = o[s];
      this.body.nodes[h]._openChildCluster(e), delete this.body.nodes[e], r === !0 && this.body.emitter.emit("_dataChanged");
      return;
    }
    const a = n.containedNodes, l = n.containedEdges;
    if (t !== void 0 && t.releaseFunction !== void 0 && typeof t.releaseFunction == "function") {
      const h = {}, c = {
        x: n.x,
        y: n.y
      };
      for (const f in a)
        if (Object.prototype.hasOwnProperty.call(a, f)) {
          const v = this.body.nodes[f];
          h[f] = {
            x: v.x,
            y: v.y
          };
        }
      const u = t.releaseFunction(c, h);
      for (const f in a)
        if (Object.prototype.hasOwnProperty.call(a, f)) {
          const v = this.body.nodes[f];
          u[f] !== void 0 && (v.x = u[f].x === void 0 ? n.x : u[f].x, v.y = u[f].y === void 0 ? n.y : u[f].y);
        }
    } else
      X(a, function(h) {
        h.options.fixed.x === !1 && (h.x = n.x), h.options.fixed.y === !1 && (h.y = n.y);
      });
    for (const h in a)
      if (Object.prototype.hasOwnProperty.call(a, h)) {
        const c = this.body.nodes[h];
        c.vx = n.vx, c.vy = n.vy, c.setOptions({
          physics: !0
        }), delete this.clusteredNodes[h];
      }
    const d = [];
    for (let h = 0; h < n.edges.length; h++)
      d.push(n.edges[h]);
    for (let h = 0; h < d.length; h++) {
      const c = d[h], u = this._getConnectedId(c, e), f = this.clusteredNodes[u];
      for (let v = 0; v < c.clusteringEdgeReplacingIds.length; v++) {
        const y = c.clusteringEdgeReplacingIds[v], g = this.body.edges[y];
        if (g !== void 0)
          if (f !== void 0) {
            const p = this.body.nodes[f.clusterId];
            p.containedEdges[g.id] = g, delete l[g.id];
            let m = g.fromId, $ = g.toId;
            g.toId == u ? $ = f.clusterId : m = f.clusterId, this._createClusteredEdge(m, $, g, p.clusterEdgeProperties, {
              hidden: !1,
              physics: !0
            });
          } else
            this._restoreEdge(g);
      }
      c.remove();
    }
    for (const h in l)
      Object.prototype.hasOwnProperty.call(l, h) && this._restoreEdge(l[h]);
    delete this.body.nodes[e], r === !0 && this.body.emitter.emit("_dataChanged");
  }
  /**
   *
   * @param {Cluster.id} clusterId
   * @returns {Array.<Node.id>}
   */
  getNodesInCluster(e) {
    const t = [];
    if (this.isCluster(e) === !0) {
      const r = this.body.nodes[e].containedNodes;
      for (const n in r)
        Object.prototype.hasOwnProperty.call(r, n) && t.push(this.body.nodes[n].id);
    }
    return t;
  }
  /**
   * Get the stack clusterId's that a certain node resides in. cluster A -> cluster B -> cluster C -> node
   *
   * If a node can't be found in the chain, return an empty array.
   * @param {string|number} nodeId
   * @returns {Array}
   */
  findNode(e) {
    const t = [];
    let n = 0, o;
    for (; this.clusteredNodes[e] !== void 0 && n < 100; ) {
      if (o = this.body.nodes[e], o === void 0) return [];
      t.push(o.id), e = this.clusteredNodes[e].clusterId, n++;
    }
    return o = this.body.nodes[e], o === void 0 ? [] : (t.push(o.id), ci(t).call(t), t);
  }
  /**
   * Using a clustered nodeId, update with the new options
   * @param {Node.id} clusteredNodeId
   * @param {object} newOptions
   */
  updateClusteredNode(e, t) {
    if (e === void 0)
      throw new Error("No clusteredNodeId supplied to updateClusteredNode.");
    if (t === void 0)
      throw new Error("No newOptions supplied to updateClusteredNode.");
    if (this.body.nodes[e] === void 0)
      throw new Error("The clusteredNodeId supplied to updateClusteredNode does not exist.");
    this.body.nodes[e].setOptions(t), this.body.emitter.emit("_dataChanged");
  }
  /**
   * Using a base edgeId, update all related clustered edges with the new options
   * @param {vis.Edge.id} startEdgeId
   * @param {object} newOptions
   */
  updateEdge(e, t) {
    if (e === void 0)
      throw new Error("No startEdgeId supplied to updateEdge.");
    if (t === void 0)
      throw new Error("No newOptions supplied to updateEdge.");
    if (this.body.edges[e] === void 0)
      throw new Error("The startEdgeId supplied to updateEdge does not exist.");
    const r = this.getClusteredEdges(e);
    for (let n = 0; n < r.length; n++)
      this.body.edges[r[n]].setOptions(t);
    this.body.emitter.emit("_dataChanged");
  }
  /**
   * Get a stack of clusterEdgeId's (+base edgeid) that a base edge is the same as. cluster edge C -> cluster edge B -> cluster edge A -> base edge(edgeId)
   * @param {vis.Edge.id} edgeId
   * @returns {Array.<vis.Edge.id>}
   */
  getClusteredEdges(e) {
    const t = [];
    let n = 0;
    for (; e !== void 0 && this.body.edges[e] !== void 0 && n < 100; )
      t.push(this.body.edges[e].id), e = this.body.edges[e].edgeReplacedById, n++;
    return ci(t).call(t), t;
  }
  /**
   * Get the base edge id of clusterEdgeId. cluster edge (clusteredEdgeId) -> cluster edge B -> cluster edge C -> base edge
   * @param {vis.Edge.id} clusteredEdgeId
   * @returns {vis.Edge.id} baseEdgeId
   *
   * TODO: deprecate in 5.0.0. Method getBaseEdges() is the correct one to use.
   */
  getBaseEdge(e) {
    return this.getBaseEdges(e)[0];
  }
  /**
   * Get all regular edges for this clustered edge id.
   * @param {vis.Edge.id} clusteredEdgeId
   * @returns {Array.<vis.Edge.id>} all baseEdgeId's under this clustered edge
   */
  getBaseEdges(e) {
    const t = [e], r = [], n = [], o = 100;
    let s = 0;
    for (; t.length > 0 && s < o; ) {
      const a = t.pop();
      if (a === void 0) continue;
      const l = this.body.edges[a];
      if (l === void 0) continue;
      s++;
      const d = l.clusteringEdgeReplacingIds;
      if (d === void 0)
        n.push(a);
      else
        for (let h = 0; h < d.length; ++h) {
          const c = d[h];
          re(t).call(t, d) !== -1 || re(r).call(r, d) !== -1 || t.push(c);
        }
      r.push(a);
    }
    return n;
  }
  /**
   * Get the Id the node is connected to
   * @param {vis.Edge} edge
   * @param {Node.id} nodeId
   * @returns {*}
   * @private
   */
  _getConnectedId(e, t) {
    return e.toId != t ? e.toId : (e.fromId != t, e.fromId);
  }
  /**
   * We determine how many connections denote an important hub.
   * We take the mean + 2*std as the important hub size. (Assuming a normal distribution of data, ~2.2%)
   * @returns {number}
   * @private
   */
  _getHubSize() {
    let e = 0, t = 0, r = 0, n = 0;
    for (let l = 0; l < this.body.nodeIndices.length; l++) {
      const d = this.body.nodes[this.body.nodeIndices[l]];
      d.edges.length > n && (n = d.edges.length), e += d.edges.length, t += Math.pow(d.edges.length, 2), r += 1;
    }
    e = e / r, t = t / r;
    const o = t - Math.pow(e, 2), s = Math.sqrt(o);
    let a = Math.floor(e + 2 * s);
    return a > n && (a = n), a;
  }
  /**
   * Create an edge for the cluster representation.
   * @param {Node.id} fromId
   * @param {Node.id} toId
   * @param {vis.Edge} baseEdge
   * @param {object} clusterEdgeProperties
   * @param {object} extraOptions
   * @returns {Edge} newly created clustered edge
   * @private
   */
  _createClusteredEdge(e, t, r, n, o) {
    const s = Ze.cloneOptions(r, "edge");
    le(s, n), s.from = e, s.to = t, s.id = "clusterEdge:" + yo(), o !== void 0 && le(s, o);
    const a = this.body.functions.createEdge(s);
    return a.clusteringEdgeReplacingIds = [r.id], a.connect(), this.body.edges[a.id] = a, a;
  }
  /**
   * Add the passed child nodes and edges to the given cluster node.
   * @param {object | Node} childNodes  hash of nodes or single node to add in cluster
   * @param {object | Edge} childEdges  hash of edges or single edge to take into account when clustering
   * @param {Node} clusterNode  cluster node to add nodes and edges to
   * @param {object} [clusterEdgeProperties]
   * @private
   */
  _clusterEdges(e, t, r, n) {
    if (t instanceof Fr) {
      const o = t, s = {};
      s[o.id] = o, t = s;
    }
    if (e instanceof ue) {
      const o = e, s = {};
      s[o.id] = o, e = s;
    }
    if (r == null)
      throw new Error("_clusterEdges: parameter clusterNode required");
    n === void 0 && (n = r.clusterEdgeProperties), this._createClusterEdges(e, t, r, n);
    for (const o in t)
      if (Object.prototype.hasOwnProperty.call(t, o) && this.body.edges[o] !== void 0) {
        const s = this.body.edges[o];
        this._backupEdgeOptions(s), s.setOptions({
          physics: !1
        });
      }
    for (const o in e)
      Object.prototype.hasOwnProperty.call(e, o) && (this.clusteredNodes[o] = {
        clusterId: r.id,
        node: this.body.nodes[o]
      }, this.body.nodes[o].setOptions({
        physics: !1
      }));
  }
  /**
   * Determine in which cluster given nodeId resides.
   *
   * If not in cluster, return undefined.
   *
   * NOTE: If you know a cleaner way to do this, please enlighten me (wimrijnders).
   * @param {Node.id} nodeId
   * @returns {Node|undefined} Node instance for cluster, if present
   * @private
   */
  _getClusterNodeForNode(e) {
    if (e === void 0) return;
    const t = this.clusteredNodes[e];
    if (t === void 0) return;
    const r = t.clusterId;
    if (r !== void 0)
      return this.body.nodes[r];
  }
  /**
   * Internal helper function for conditionally removing items in array
   *
   * Done like this because Array.filter() is not fully supported by all IE's.
   * @param {Array} arr
   * @param {Function} callback
   * @returns {Array}
   * @private
   */
  _filter(e, t) {
    const r = [];
    return X(e, (n) => {
      t(n) && r.push(n);
    }), r;
  }
  /**
   * Scan all edges for changes in clustering and adjust this if necessary.
   *
   * Call this (internally) after there has been a change in node or edge data.
   *
   * Pre: States of this.body.nodes and this.body.edges consistent
   * Pre: this.clusteredNodes and this.clusteredEdge consistent with containedNodes and containedEdges
   *      of cluster nodes.
   */
  _updateState() {
    let e;
    const t = [], r = {}, n = (l) => {
      X(this.body.nodes, (d) => {
        d.isCluster === !0 && l(d);
      });
    };
    for (e in this.clusteredNodes) {
      if (!Object.prototype.hasOwnProperty.call(this.clusteredNodes, e)) continue;
      this.body.nodes[e] === void 0 && t.push(e);
    }
    n(function(l) {
      for (let d = 0; d < t.length; d++)
        delete l.containedNodes[t[d]];
    });
    for (let l = 0; l < t.length; l++)
      delete this.clusteredNodes[t[l]];
    X(this.clusteredEdges, (l) => {
      const d = this.body.edges[l];
      (d === void 0 || !d.endPointsValid()) && (r[l] = l);
    }), n(function(l) {
      X(l.containedEdges, (d, h) => {
        !d.endPointsValid() && !r[h] && (r[h] = h);
      });
    }), X(this.body.edges, (l, d) => {
      let h = !0;
      const c = l.clusteringEdgeReplacingIds;
      if (c !== void 0) {
        let u = 0;
        X(c, (f) => {
          const v = this.body.edges[f];
          v !== void 0 && v.endPointsValid() && (u += 1);
        }), h = u > 0;
      }
      (!l.endPointsValid() || !h) && (r[d] = d);
    }), n((l) => {
      X(r, (d) => {
        delete l.containedEdges[d], X(l.edges, (h, c) => {
          if (h.id === d) {
            l.edges[c] = null;
            return;
          }
          h.clusteringEdgeReplacingIds = this._filter(h.clusteringEdgeReplacingIds, function(u) {
            return !r[u];
          });
        }), l.edges = this._filter(l.edges, function(h) {
          return h !== null;
        });
      });
    }), X(r, (l) => {
      delete this.clusteredEdges[l];
    }), X(r, (l) => {
      delete this.body.edges[l];
    });
    const o = me(this.body.edges);
    X(o, (l) => {
      const d = this.body.edges[l], h = this._isClusteredNode(d.fromId) || this._isClusteredNode(d.toId);
      if (h !== this._isClusteredEdge(d.id))
        if (h) {
          const c = this._getClusterNodeForNode(d.fromId);
          c !== void 0 && this._clusterEdges(this.body.nodes[d.fromId], d, c);
          const u = this._getClusterNodeForNode(d.toId);
          u !== void 0 && this._clusterEdges(this.body.nodes[d.toId], d, u);
        } else
          delete this._clusterEdges[l], this._restoreEdge(d);
    });
    let s = !1, a = !0;
    for (; a; ) {
      const l = [];
      n(function(d) {
        const h = me(d.containedNodes).length, c = d.options.allowSingleNodeCluster === !0;
        (c && h < 1 || !c && h < 2) && l.push(d.id);
      });
      for (let d = 0; d < l.length; ++d)
        this.openCluster(
          l[d],
          {},
          !1
          /* Don't refresh, we're in an refresh/update already */
        );
      a = l.length > 0, s = s || a;
    }
    s && this._updateState();
  }
  /**
   * Determine if node with given id is part of a cluster.
   * @param {Node.id} nodeId
   * @returns {boolean} true if part of a cluster.
   */
  _isClusteredNode(e) {
    return this.clusteredNodes[e] !== void 0;
  }
  /**
   * Determine if edge with given id is not visible due to clustering.
   *
   * An edge is considered clustered if:
   * - it is directly replaced by a clustering edge
   * - any of its connecting nodes is in a cluster
   * @param {vis.Edge.id} edgeId
   * @returns {boolean} true if part of a cluster.
   */
  _isClusteredEdge(e) {
    return this.clusteredEdges[e] !== void 0;
  }
}
class eae {
  /**
   * @param {object} body
   * @param {Canvas} canvas
   */
  constructor(e, t) {
    this.body = e, this.canvas = t, this.redrawRequested = !1, this.requestAnimationFrameRequestId = void 0, this.renderingActive = !1, this.renderRequests = 0, this.allowRedraw = !0, this.dragging = !1, this.zooming = !1, this.options = {}, this.defaultOptions = {
      hideEdgesOnDrag: !1,
      hideEdgesOnZoom: !1,
      hideNodesOnDrag: !1
    }, Ce(this.options, this.defaultOptions), this.bindEventListeners();
  }
  /**
   * Binds event listeners
   */
  bindEventListeners() {
    var e;
    this.body.emitter.on("dragStart", () => {
      this.dragging = !0;
    }), this.body.emitter.on("dragEnd", () => {
      this.dragging = !1;
    }), this.body.emitter.on("zoom", () => {
      this.zooming = !0, window.clearTimeout(this.zoomTimeoutId), this.zoomTimeoutId = lr(() => {
        var t;
        this.zooming = !1, S(t = this._requestRedraw).call(t, this)();
      }, 250);
    }), this.body.emitter.on("_resizeNodes", () => {
      this._resizeNodes();
    }), this.body.emitter.on("_redraw", () => {
      this.renderingActive === !1 && this._redraw();
    }), this.body.emitter.on("_blockRedraw", () => {
      this.allowRedraw = !1;
    }), this.body.emitter.on("_allowRedraw", () => {
      this.allowRedraw = !0, this.redrawRequested = !1;
    }), this.body.emitter.on("_requestRedraw", S(e = this._requestRedraw).call(e, this)), this.body.emitter.on("_startRendering", () => {
      this.renderRequests += 1, this.renderingActive = !0, this._startRendering();
    }), this.body.emitter.on("_stopRendering", () => {
      this.renderRequests -= 1, this.renderingActive = this.renderRequests > 0, this.requestAnimationFrameRequestId = void 0;
    }), this.body.emitter.on("destroy", () => {
      this.renderRequests = 0, this.allowRedraw = !1, this.renderingActive = !1, window.cancelAnimationFrame(this.requestAnimationFrameRequestId), this.body.emitter.off();
    });
  }
  /**
   *
   * @param {object} options
   */
  setOptions(e) {
    e !== void 0 && Xn(["hideEdgesOnDrag", "hideEdgesOnZoom", "hideNodesOnDrag"], this.options, e);
  }
  /**
   *
   * @private
   */
  _startRendering() {
    if (this.renderingActive === !0 && this.requestAnimationFrameRequestId === void 0) {
      var e;
      this.requestAnimationFrameRequestId = window.requestAnimationFrame(S(e = this._renderStep).call(e, this), this.simulationInterval);
    }
  }
  /**
   *
   * @private
   */
  _renderStep() {
    this.renderingActive === !0 && (this.requestAnimationFrameRequestId = void 0, this._startRendering(), this._redraw());
  }
  /**
   * Redraw the network with the current data
   * chart will be resized too.
   */
  redraw() {
    this.body.emitter.emit("setSize"), this._redraw();
  }
  /**
   * Redraw the network with the current data
   * @private
   */
  _requestRedraw() {
    this.redrawRequested !== !0 && this.renderingActive === !1 && this.allowRedraw === !0 && (this.redrawRequested = !0, window.requestAnimationFrame(() => {
      this._redraw(!1);
    }));
  }
  /**
   * Redraw the network with the current data
   * @param {boolean} [hidden] | Used to get the first estimate of the node sizes.
   *                                   Only the nodes are drawn after which they are quickly drawn over.
   * @private
   */
  _redraw() {
    let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !1;
    if (this.allowRedraw === !0) {
      this.body.emitter.emit("initRedraw"), this.redrawRequested = !1;
      const t = {
        drawExternalLabels: null
      };
      (this.canvas.frame.canvas.width === 0 || this.canvas.frame.canvas.height === 0) && this.canvas.setSize(), this.canvas.setTransform();
      const r = this.canvas.getContext(), n = this.canvas.frame.canvas.clientWidth, o = this.canvas.frame.canvas.clientHeight;
      if (r.clearRect(0, 0, n, o), this.canvas.frame.clientWidth === 0)
        return;
      if (r.save(), r.translate(this.body.view.translation.x, this.body.view.translation.y), r.scale(this.body.view.scale, this.body.view.scale), r.beginPath(), this.body.emitter.emit("beforeDrawing", r), r.closePath(), e === !1 && (this.dragging === !1 || this.dragging === !0 && this.options.hideEdgesOnDrag === !1) && (this.zooming === !1 || this.zooming === !0 && this.options.hideEdgesOnZoom === !1) && this._drawEdges(r), this.dragging === !1 || this.dragging === !0 && this.options.hideNodesOnDrag === !1) {
        const {
          drawExternalLabels: s
        } = this._drawNodes(r, e);
        t.drawExternalLabels = s;
      }
      e === !1 && (this.dragging === !1 || this.dragging === !0 && this.options.hideEdgesOnDrag === !1) && (this.zooming === !1 || this.zooming === !0 && this.options.hideEdgesOnZoom === !1) && this._drawArrows(r), t.drawExternalLabels != null && t.drawExternalLabels(), e === !1 && this._drawSelectionBox(r), r.beginPath(), this.body.emitter.emit("afterDrawing", r), r.closePath(), r.restore(), e === !0 && r.clearRect(0, 0, n, o);
    }
  }
  /**
   * Redraw all nodes
   * @param {CanvasRenderingContext2D}   ctx
   * @param {boolean} [alwaysShow]
   * @private
   */
  _resizeNodes() {
    this.canvas.setTransform();
    const e = this.canvas.getContext();
    e.save(), e.translate(this.body.view.translation.x, this.body.view.translation.y), e.scale(this.body.view.scale, this.body.view.scale);
    const t = this.body.nodes;
    let r;
    for (const n in t)
      Object.prototype.hasOwnProperty.call(t, n) && (r = t[n], r.resize(e), r.updateBoundingBox(e, r.selected));
    e.restore();
  }
  /**
   * Redraw all nodes
   * @param {CanvasRenderingContext2D} ctx  2D context of a HTML canvas
   * @param {boolean} [alwaysShow]
   * @private
   * @returns {object} Callbacks to draw later on higher layers.
   */
  _drawNodes(e) {
    let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1;
    const r = this.body.nodes, n = this.body.nodeIndices;
    let o;
    const s = [], a = [], l = 20, d = this.canvas.DOMtoCanvas({
      x: -l,
      y: -l
    }), h = this.canvas.DOMtoCanvas({
      x: this.canvas.frame.canvas.clientWidth + l,
      y: this.canvas.frame.canvas.clientHeight + l
    }), c = {
      top: d.y,
      left: d.x,
      bottom: h.y,
      right: h.x
    }, u = [];
    for (let g = 0; g < n.length; g++)
      if (o = r[n[g]], o.hover)
        a.push(n[g]);
      else if (o.isSelected())
        s.push(n[g]);
      else if (t === !0) {
        const p = o.draw(e);
        p.drawExternalLabel != null && u.push(p.drawExternalLabel);
      } else if (o.isBoundingBoxOverlappingWith(c) === !0) {
        const p = o.draw(e);
        p.drawExternalLabel != null && u.push(p.drawExternalLabel);
      } else
        o.updateBoundingBox(e, o.selected);
    let f;
    const v = s.length, y = a.length;
    for (f = 0; f < v; f++) {
      o = r[s[f]];
      const g = o.draw(e);
      g.drawExternalLabel != null && u.push(g.drawExternalLabel);
    }
    for (f = 0; f < y; f++) {
      o = r[a[f]];
      const g = o.draw(e);
      g.drawExternalLabel != null && u.push(g.drawExternalLabel);
    }
    return {
      drawExternalLabels: () => {
        for (const g of u)
          g();
      }
    };
  }
  /**
   * Redraw all edges
   * @param {CanvasRenderingContext2D} ctx  2D context of a HTML canvas
   * @private
   */
  _drawEdges(e) {
    const t = this.body.edges, r = this.body.edgeIndices;
    for (let n = 0; n < r.length; n++) {
      const o = t[r[n]];
      o.connected === !0 && o.draw(e);
    }
  }
  /**
   * Redraw all arrows
   * @param {CanvasRenderingContext2D} ctx  2D context of a HTML canvas
   * @private
   */
  _drawArrows(e) {
    const t = this.body.edges, r = this.body.edgeIndices;
    for (let n = 0; n < r.length; n++) {
      const o = t[r[n]];
      o.connected === !0 && o.drawArrows(e);
    }
  }
  /**
   * Redraw selection box
   * @param {CanvasRenderingContext2D} ctx  2D context of a HTML canvas
   * @private
   */
  _drawSelectionBox(e) {
    if (this.body.selectionBox.show) {
      e.beginPath();
      const t = this.body.selectionBox.position.end.x - this.body.selectionBox.position.start.x, r = this.body.selectionBox.position.end.y - this.body.selectionBox.position.start.y;
      e.rect(this.body.selectionBox.position.start.x, this.body.selectionBox.position.start.y, t, r), e.fillStyle = "rgba(151, 194, 252, 0.2)", e.fillRect(this.body.selectionBox.position.start.x, this.body.selectionBox.position.start.y, t, r), e.strokeStyle = "rgba(151, 194, 252, 1)", e.stroke();
    } else
      e.closePath();
  }
}
var tae = ie, rae = tae.setInterval, iae = rae, nae = /* @__PURE__ */ U(iae);
function ll(i, e) {
  e.inputHandler = function(t) {
    t.isFirst && e(t);
  }, i.on("hammer.input", e.inputHandler);
}
function wS(i, e) {
  return e.inputHandler = function(t) {
    t.isFinal && e(t);
  }, i.on("hammer.input", e.inputHandler);
}
class oae {
  /**
   * @param {object} body
   */
  constructor(e) {
    this.body = e, this.pixelRatio = 1, this.cameraState = {}, this.initialized = !1, this.canvasViewCenter = {}, this._cleanupCallbacks = [], this.options = {}, this.defaultOptions = {
      autoResize: !0,
      height: "100%",
      width: "100%"
    }, Ce(this.options, this.defaultOptions), this.bindEventListeners();
  }
  /**
   * Binds event listeners
   */
  bindEventListeners() {
    var e;
    this.body.emitter.once("resize", (t) => {
      t.width !== 0 && (this.body.view.translation.x = t.width * 0.5), t.height !== 0 && (this.body.view.translation.y = t.height * 0.5);
    }), this.body.emitter.on("setSize", S(e = this.setSize).call(e, this)), this.body.emitter.on("destroy", () => {
      this.hammerFrame.destroy(), this.hammer.destroy(), this._cleanUp();
    });
  }
  /**
   * @param {object} options
   */
  setOptions(e) {
    if (e !== void 0 && Xn(["width", "height", "autoResize"], this.options, e), this._cleanUp(), this.options.autoResize === !0) {
      var t;
      if (window.ResizeObserver) {
        const n = new ResizeObserver(() => {
          this.setSize() === !0 && this.body.emitter.emit("_requestRedraw");
        }), {
          frame: o
        } = this;
        n.observe(o), this._cleanupCallbacks.push(() => {
          n.unobserve(o);
        });
      } else {
        const n = nae(() => {
          this.setSize() === !0 && this.body.emitter.emit("_requestRedraw");
        }, 1e3);
        this._cleanupCallbacks.push(() => {
          clearInterval(n);
        });
      }
      const r = S(t = this._onResize).call(t, this);
      window.addEventListener("resize", r), this._cleanupCallbacks.push(() => {
        window.removeEventListener("resize", r);
      });
    }
  }
  /**
   * @private
   */
  _cleanUp() {
    var e, t, r;
    se(e = ci(t = ar(r = this._cleanupCallbacks).call(r, 0)).call(t)).call(e, (n) => {
      try {
        n();
      } catch (o) {
        console.error(o);
      }
    });
  }
  /**
   * @private
   */
  _onResize() {
    this.setSize(), this.body.emitter.emit("_redraw");
  }
  /**
   * Get and store the cameraState
   * @param {number} [pixelRatio]
   * @private
   */
  _getCameraState() {
    let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : this.pixelRatio;
    this.initialized === !0 && (this.cameraState.previousWidth = this.frame.canvas.width / e, this.cameraState.previousHeight = this.frame.canvas.height / e, this.cameraState.scale = this.body.view.scale, this.cameraState.position = this.DOMtoCanvas({
      x: 0.5 * this.frame.canvas.width / e,
      y: 0.5 * this.frame.canvas.height / e
    }));
  }
  /**
   * Set the cameraState
   * @private
   */
  _setCameraState() {
    if (this.cameraState.scale !== void 0 && this.frame.canvas.clientWidth !== 0 && this.frame.canvas.clientHeight !== 0 && this.pixelRatio !== 0 && this.cameraState.previousWidth > 0 && this.cameraState.previousHeight > 0) {
      const e = this.frame.canvas.width / this.pixelRatio / this.cameraState.previousWidth, t = this.frame.canvas.height / this.pixelRatio / this.cameraState.previousHeight;
      let r = this.cameraState.scale;
      e != 1 && t != 1 ? r = this.cameraState.scale * 0.5 * (e + t) : e != 1 ? r = this.cameraState.scale * e : t != 1 && (r = this.cameraState.scale * t), this.body.view.scale = r;
      const n = this.DOMtoCanvas({
        x: 0.5 * this.frame.canvas.clientWidth,
        y: 0.5 * this.frame.canvas.clientHeight
      }), o = {
        // offset from view, distance view has to change by these x and y to center the node
        x: n.x - this.cameraState.position.x,
        y: n.y - this.cameraState.position.y
      };
      this.body.view.translation.x += o.x * this.body.view.scale, this.body.view.translation.y += o.y * this.body.view.scale;
    }
  }
  /**
   *
   * @param {number|string} value
   * @returns {string}
   * @private
   */
  _prepareValue(e) {
    if (typeof e == "number")
      return e + "px";
    if (typeof e == "string") {
      if (re(e).call(e, "%") !== -1 || re(e).call(e, "px") !== -1)
        return e;
      if (re(e).call(e, "%") === -1)
        return e + "px";
    }
    throw new Error("Could not use the value supplied for width or height:" + e);
  }
  /**
   * Create the HTML
   */
  _create() {
    for (; this.body.container.hasChildNodes(); )
      this.body.container.removeChild(this.body.container.firstChild);
    if (this.frame = document.createElement("div"), this.frame.className = "vis-network", this.frame.style.position = "relative", this.frame.style.overflow = "hidden", this.frame.tabIndex = 0, this.frame.canvas = document.createElement("canvas"), this.frame.canvas.style.position = "relative", this.frame.appendChild(this.frame.canvas), this.frame.canvas.getContext)
      this._setPixelRatio(), this.setTransform();
    else {
      const e = document.createElement("DIV");
      e.style.color = "red", e.style.fontWeight = "bold", e.style.padding = "10px", e.innerText = "Error: your browser does not support HTML canvas", this.frame.canvas.appendChild(e);
    }
    this.body.container.appendChild(this.frame), this.body.view.scale = 1, this.body.view.translation = {
      x: 0.5 * this.frame.canvas.clientWidth,
      y: 0.5 * this.frame.canvas.clientHeight
    }, this._bindHammer();
  }
  /**
   * This function binds hammer, it can be repeated over and over due to the uniqueness check.
   * @private
   */
  _bindHammer() {
    this.hammer !== void 0 && this.hammer.destroy(), this.drag = {}, this.pinch = {}, this.hammer = new dn(this.frame.canvas), this.hammer.get("pinch").set({
      enable: !0
    }), this.hammer.get("pan").set({
      threshold: 5,
      direction: dn.DIRECTION_ALL
    }), ll(this.hammer, (e) => {
      this.body.eventListeners.onTouch(e);
    }), this.hammer.on("tap", (e) => {
      this.body.eventListeners.onTap(e);
    }), this.hammer.on("doubletap", (e) => {
      this.body.eventListeners.onDoubleTap(e);
    }), this.hammer.on("press", (e) => {
      this.body.eventListeners.onHold(e);
    }), this.hammer.on("panstart", (e) => {
      this.body.eventListeners.onDragStart(e);
    }), this.hammer.on("panmove", (e) => {
      this.body.eventListeners.onDrag(e);
    }), this.hammer.on("panend", (e) => {
      this.body.eventListeners.onDragEnd(e);
    }), this.hammer.on("pinch", (e) => {
      this.body.eventListeners.onPinch(e);
    }), this.frame.canvas.addEventListener("wheel", (e) => {
      this.body.eventListeners.onMouseWheel(e);
    }), this.frame.canvas.addEventListener("mousemove", (e) => {
      this.body.eventListeners.onMouseMove(e);
    }), this.frame.canvas.addEventListener("contextmenu", (e) => {
      this.body.eventListeners.onContext(e);
    }), this.hammerFrame = new dn(this.frame), wS(this.hammerFrame, (e) => {
      this.body.eventListeners.onRelease(e);
    });
  }
  /**
   * Set a new size for the network
   * @param {string} width   Width in pixels or percentage (for example '800px'
   *                         or '50%')
   * @param {string} height  Height in pixels or percentage  (for example '400px'
   *                         or '30%')
   * @returns {boolean}
   */
  setSize() {
    let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : this.options.width, t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : this.options.height;
    e = this._prepareValue(e), t = this._prepareValue(t);
    let r = !1;
    const n = this.frame.canvas.width, o = this.frame.canvas.height, s = this.pixelRatio;
    if (this._setPixelRatio(), e != this.options.width || t != this.options.height || this.frame.style.width != e || this.frame.style.height != t)
      this._getCameraState(s), this.frame.style.width = e, this.frame.style.height = t, this.frame.canvas.style.width = "100%", this.frame.canvas.style.height = "100%", this.frame.canvas.width = Math.round(this.frame.canvas.clientWidth * this.pixelRatio), this.frame.canvas.height = Math.round(this.frame.canvas.clientHeight * this.pixelRatio), this.options.width = e, this.options.height = t, this.canvasViewCenter = {
        x: 0.5 * this.frame.clientWidth,
        y: 0.5 * this.frame.clientHeight
      }, r = !0;
    else {
      const a = Math.round(this.frame.canvas.clientWidth * this.pixelRatio), l = Math.round(this.frame.canvas.clientHeight * this.pixelRatio);
      (this.frame.canvas.width !== a || this.frame.canvas.height !== l) && this._getCameraState(s), this.frame.canvas.width !== a && (this.frame.canvas.width = a, r = !0), this.frame.canvas.height !== l && (this.frame.canvas.height = l, r = !0);
    }
    return r === !0 && (this.body.emitter.emit("resize", {
      width: Math.round(this.frame.canvas.width / this.pixelRatio),
      height: Math.round(this.frame.canvas.height / this.pixelRatio),
      oldWidth: Math.round(n / this.pixelRatio),
      oldHeight: Math.round(o / this.pixelRatio)
    }), this._setCameraState()), this.initialized = !0, r;
  }
  /**
   *
   * @returns {CanvasRenderingContext2D}
   */
  getContext() {
    return this.frame.canvas.getContext("2d");
  }
  /**
   * Determine the pixel ratio for various browsers.
   * @returns {number}
   * @private
   */
  _determinePixelRatio() {
    const e = this.getContext();
    if (e === void 0)
      throw new Error("Could not get canvax context");
    let t = 1;
    typeof window < "u" && (t = window.devicePixelRatio || 1);
    const r = e.webkitBackingStorePixelRatio || e.mozBackingStorePixelRatio || e.msBackingStorePixelRatio || e.oBackingStorePixelRatio || e.backingStorePixelRatio || 1;
    return t / r;
  }
  /**
   * Lazy determination of pixel ratio.
   * @private
   */
  _setPixelRatio() {
    this.pixelRatio = this._determinePixelRatio();
  }
  /**
   * Set the transform in the contained context, based on its pixelRatio
   */
  setTransform() {
    const e = this.getContext();
    if (e === void 0)
      throw new Error("Could not get canvax context");
    e.setTransform(this.pixelRatio, 0, 0, this.pixelRatio, 0, 0);
  }
  /**
   * Convert the X coordinate in DOM-space (coordinate point in browser relative to the container div) to
   * the X coordinate in canvas-space (the simulation sandbox, which the camera looks upon)
   * @param {number} x
   * @returns {number}
   * @private
   */
  _XconvertDOMtoCanvas(e) {
    return (e - this.body.view.translation.x) / this.body.view.scale;
  }
  /**
   * Convert the X coordinate in canvas-space (the simulation sandbox, which the camera looks upon) to
   * the X coordinate in DOM-space (coordinate point in browser relative to the container div)
   * @param {number} x
   * @returns {number}
   * @private
   */
  _XconvertCanvasToDOM(e) {
    return e * this.body.view.scale + this.body.view.translation.x;
  }
  /**
   * Convert the Y coordinate in DOM-space (coordinate point in browser relative to the container div) to
   * the Y coordinate in canvas-space (the simulation sandbox, which the camera looks upon)
   * @param {number} y
   * @returns {number}
   * @private
   */
  _YconvertDOMtoCanvas(e) {
    return (e - this.body.view.translation.y) / this.body.view.scale;
  }
  /**
   * Convert the Y coordinate in canvas-space (the simulation sandbox, which the camera looks upon) to
   * the Y coordinate in DOM-space (coordinate point in browser relative to the container div)
   * @param {number} y
   * @returns {number}
   * @private
   */
  _YconvertCanvasToDOM(e) {
    return e * this.body.view.scale + this.body.view.translation.y;
  }
  /**
   * @param {point} pos
   * @returns {point}
   */
  canvasToDOM(e) {
    return {
      x: this._XconvertCanvasToDOM(e.x),
      y: this._YconvertCanvasToDOM(e.y)
    };
  }
  /**
   *
   * @param {point} pos
   * @returns {point}
   */
  DOMtoCanvas(e) {
    return {
      x: this._XconvertDOMtoCanvas(e.x),
      y: this._YconvertDOMtoCanvas(e.y)
    };
  }
}
function sae(i, e) {
  const t = Ce({
    nodes: e,
    minZoomLevel: Number.MIN_VALUE,
    maxZoomLevel: 1
  }, i ?? {});
  if (!be(t.nodes))
    throw new TypeError("Nodes has to be an array of ids.");
  if (t.nodes.length === 0 && (t.nodes = e), !(typeof t.minZoomLevel == "number" && t.minZoomLevel > 0))
    throw new TypeError("Min zoom level has to be a number higher than zero.");
  if (!(typeof t.maxZoomLevel == "number" && t.minZoomLevel <= t.maxZoomLevel))
    throw new TypeError("Max zoom level has to be a number higher than min zoom level.");
  return t;
}
class aae {
  /**
   * @param {object} body
   * @param {Canvas} canvas
   */
  constructor(e, t) {
    var r, n;
    this.body = e, this.canvas = t, this.animationSpeed = 1 / this.renderRefreshRate, this.animationEasingFunction = "easeInOutQuint", this.easingTime = 0, this.sourceScale = 0, this.targetScale = 0, this.sourceTranslation = 0, this.targetTranslation = 0, this.lockedOnNodeId = void 0, this.lockedOnNodeOffset = void 0, this.touchTime = 0, this.viewFunction = void 0, this.body.emitter.on("fit", S(r = this.fit).call(r, this)), this.body.emitter.on("animationFinished", () => {
      this.body.emitter.emit("_stopRendering");
    }), this.body.emitter.on("unlockNode", S(n = this.releaseNode).call(n, this));
  }
  /**
   *
   * @param {object} [options]
   */
  setOptions() {
    let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    this.options = e;
  }
  /**
   * This function zooms out to fit all data on screen based on amount of nodes
   * @param {object} [options={{nodes=Array}}]
   * @param options
   * @param {boolean} [initialZoom]  | zoom based on fitted formula or range, true = fitted, default = false;
   */
  fit(e) {
    let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1;
    e = sae(e, this.body.nodeIndices);
    const r = this.canvas.frame.canvas.clientWidth, n = this.canvas.frame.canvas.clientHeight;
    let o, s;
    if (r === 0 || n === 0)
      s = 1, o = Ze.getRange(this.body.nodes, e.nodes);
    else if (t === !0) {
      let d = 0;
      for (const u in this.body.nodes)
        Object.prototype.hasOwnProperty.call(this.body.nodes, u) && this.body.nodes[u].predefinedPosition === !0 && (d += 1);
      if (d > 0.5 * this.body.nodeIndices.length) {
        this.fit(e, !1);
        return;
      }
      o = Ze.getRange(this.body.nodes, e.nodes), s = 12.662 / (this.body.nodeIndices.length + 7.4147) + 0.0964822;
      const c = Math.min(r / 600, n / 600);
      s *= c;
    } else {
      this.body.emitter.emit("_resizeNodes"), o = Ze.getRange(this.body.nodes, e.nodes);
      const d = Math.abs(o.maxX - o.minX) * 1.1, h = Math.abs(o.maxY - o.minY) * 1.1, c = r / d, u = n / h;
      s = c <= u ? c : u;
    }
    s > e.maxZoomLevel ? s = e.maxZoomLevel : s < e.minZoomLevel && (s = e.minZoomLevel);
    const l = {
      position: Ze.findCenter(o),
      scale: s,
      animation: e.animation
    };
    this.moveTo(l);
  }
  // animation
  /**
   * Center a node in view.
   * @param {number} nodeId
   * @param {number} [options]
   */
  focus(e) {
    let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    if (this.body.nodes[e] !== void 0) {
      const r = {
        x: this.body.nodes[e].x,
        y: this.body.nodes[e].y
      };
      t.position = r, t.lockedOnNode = e, this.moveTo(t);
    } else
      console.error("Node: " + e + " cannot be found.");
  }
  /**
   *
   * @param {object} options  |  options.offset   = {x:number, y:number}   // offset from the center in DOM pixels
   *                          |  options.scale    = number                 // scale to move to
   *                          |  options.position = {x:number, y:number}   // position to move to
   *                          |  options.animation = {duration:number, easingFunction:String} || Boolean   // position to move to
   */
  moveTo(e) {
    if (e === void 0) {
      e = {};
      return;
    }
    if (e.offset != null) {
      if (e.offset.x != null) {
        if (e.offset.x = +e.offset.x, !ii(e.offset.x))
          throw new TypeError('The option "offset.x" has to be a finite number.');
      } else
        e.offset.x = 0;
      if (e.offset.y != null) {
        if (e.offset.y = +e.offset.y, !ii(e.offset.y))
          throw new TypeError('The option "offset.y" has to be a finite number.');
      } else
        e.offset.x = 0;
    } else
      e.offset = {
        x: 0,
        y: 0
      };
    if (e.position != null) {
      if (e.position.x != null) {
        if (e.position.x = +e.position.x, !ii(e.position.x))
          throw new TypeError('The option "position.x" has to be a finite number.');
      } else
        e.position.x = 0;
      if (e.position.y != null) {
        if (e.position.y = +e.position.y, !ii(e.position.y))
          throw new TypeError('The option "position.y" has to be a finite number.');
      } else
        e.position.x = 0;
    } else
      e.position = this.getViewPosition();
    if (e.scale != null) {
      if (e.scale = +e.scale, !(e.scale > 0))
        throw new TypeError('The option "scale" has to be a number greater than zero.');
    } else
      e.scale = this.body.view.scale;
    e.animation === void 0 && (e.animation = {
      duration: 0
    }), e.animation === !1 && (e.animation = {
      duration: 0
    }), e.animation === !0 && (e.animation = {}), e.animation.duration === void 0 && (e.animation.duration = 1e3), e.animation.easingFunction === void 0 && (e.animation.easingFunction = "easeInOutQuad"), this.animateView(e);
  }
  /**
   *
   * @param {object} options  |  options.offset   = {x:number, y:number}   // offset from the center in DOM pixels
   *                          |  options.time     = number                 // animation time in milliseconds
   *                          |  options.scale    = number                 // scale to animate to
   *                          |  options.position = {x:number, y:number}   // position to animate to
   *                          |  options.easingFunction = String           // linear, easeInQuad, easeOutQuad, easeInOutQuad,
   *                                                                       // easeInCubic, easeOutCubic, easeInOutCubic,
   *                                                                       // easeInQuart, easeOutQuart, easeInOutQuart,
   *                                                                       // easeInQuint, easeOutQuint, easeInOutQuint
   */
  animateView(e) {
    if (e === void 0)
      return;
    this.animationEasingFunction = e.animation.easingFunction, this.releaseNode(), e.locked === !0 && (this.lockedOnNodeId = e.lockedOnNode, this.lockedOnNodeOffset = e.offset), this.easingTime != 0 && this._transitionRedraw(!0), this.sourceScale = this.body.view.scale, this.sourceTranslation = this.body.view.translation, this.targetScale = e.scale, this.body.view.scale = this.targetScale;
    const t = this.canvas.DOMtoCanvas({
      x: 0.5 * this.canvas.frame.canvas.clientWidth,
      y: 0.5 * this.canvas.frame.canvas.clientHeight
    }), r = {
      // offset from view, distance view has to change by these x and y to center the node
      x: t.x - e.position.x,
      y: t.y - e.position.y
    };
    if (this.targetTranslation = {
      x: this.sourceTranslation.x + r.x * this.targetScale + e.offset.x,
      y: this.sourceTranslation.y + r.y * this.targetScale + e.offset.y
    }, e.animation.duration === 0)
      if (this.lockedOnNodeId != null) {
        var n;
        this.viewFunction = S(n = this._lockedRedraw).call(n, this), this.body.emitter.on("initRedraw", this.viewFunction);
      } else
        this.body.view.scale = this.targetScale, this.body.view.translation = this.targetTranslation, this.body.emitter.emit("_requestRedraw");
    else {
      var o;
      this.animationSpeed = 1 / (60 * e.animation.duration * 1e-3) || 1 / 60, this.animationEasingFunction = e.animation.easingFunction, this.viewFunction = S(o = this._transitionRedraw).call(o, this), this.body.emitter.on("initRedraw", this.viewFunction), this.body.emitter.emit("_startRendering");
    }
  }
  /**
   * used to animate smoothly by hijacking the redraw function.
   * @private
   */
  _lockedRedraw() {
    const e = {
      x: this.body.nodes[this.lockedOnNodeId].x,
      y: this.body.nodes[this.lockedOnNodeId].y
    }, t = this.canvas.DOMtoCanvas({
      x: 0.5 * this.canvas.frame.canvas.clientWidth,
      y: 0.5 * this.canvas.frame.canvas.clientHeight
    }), r = {
      // offset from view, distance view has to change by these x and y to center the node
      x: t.x - e.x,
      y: t.y - e.y
    }, n = this.body.view.translation, o = {
      x: n.x + r.x * this.body.view.scale + this.lockedOnNodeOffset.x,
      y: n.y + r.y * this.body.view.scale + this.lockedOnNodeOffset.y
    };
    this.body.view.translation = o;
  }
  /**
   * Resets state of a locked on Node
   */
  releaseNode() {
    this.lockedOnNodeId !== void 0 && this.viewFunction !== void 0 && (this.body.emitter.off("initRedraw", this.viewFunction), this.lockedOnNodeId = void 0, this.lockedOnNodeOffset = void 0);
  }
  /**
   * @param {boolean} [finished]
   * @private
   */
  _transitionRedraw() {
    let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !1;
    this.easingTime += this.animationSpeed, this.easingTime = e === !0 ? 1 : this.easingTime;
    const t = gee[this.animationEasingFunction](this.easingTime);
    if (this.body.view.scale = this.sourceScale + (this.targetScale - this.sourceScale) * t, this.body.view.translation = {
      x: this.sourceTranslation.x + (this.targetTranslation.x - this.sourceTranslation.x) * t,
      y: this.sourceTranslation.y + (this.targetTranslation.y - this.sourceTranslation.y) * t
    }, this.easingTime >= 1) {
      if (this.body.emitter.off("initRedraw", this.viewFunction), this.easingTime = 0, this.lockedOnNodeId != null) {
        var r;
        this.viewFunction = S(r = this._lockedRedraw).call(r, this), this.body.emitter.on("initRedraw", this.viewFunction);
      }
      this.body.emitter.emit("animationFinished");
    }
  }
  /**
   *
   * @returns {number}
   */
  getScale() {
    return this.body.view.scale;
  }
  /**
   *
   * @returns {{x: number, y: number}}
   */
  getViewPosition() {
    return this.canvas.DOMtoCanvas({
      x: 0.5 * this.canvas.frame.canvas.clientWidth,
      y: 0.5 * this.canvas.frame.canvas.clientHeight
    });
  }
}
function kb(i) {
  var e = i && i.preventDefault || !1, t = i && i.container || window, r = {}, n = { keydown: {}, keyup: {} }, o = {}, s;
  for (s = 97; s <= 122; s++)
    o[String.fromCharCode(s)] = { code: 65 + (s - 97), shift: !1 };
  for (s = 65; s <= 90; s++)
    o[String.fromCharCode(s)] = { code: s, shift: !0 };
  for (s = 0; s <= 9; s++)
    o["" + s] = { code: 48 + s, shift: !1 };
  for (s = 1; s <= 12; s++)
    o["F" + s] = { code: 111 + s, shift: !1 };
  for (s = 0; s <= 9; s++)
    o["num" + s] = { code: 96 + s, shift: !1 };
  o["num*"] = { code: 106, shift: !1 }, o["num+"] = { code: 107, shift: !1 }, o["num-"] = { code: 109, shift: !1 }, o["num/"] = { code: 111, shift: !1 }, o["num."] = { code: 110, shift: !1 }, o.left = { code: 37, shift: !1 }, o.up = { code: 38, shift: !1 }, o.right = { code: 39, shift: !1 }, o.down = { code: 40, shift: !1 }, o.space = { code: 32, shift: !1 }, o.enter = { code: 13, shift: !1 }, o.shift = { code: 16, shift: void 0 }, o.esc = { code: 27, shift: !1 }, o.backspace = { code: 8, shift: !1 }, o.tab = { code: 9, shift: !1 }, o.ctrl = { code: 17, shift: !1 }, o.alt = { code: 18, shift: !1 }, o.delete = { code: 46, shift: !1 }, o.pageup = { code: 33, shift: !1 }, o.pagedown = { code: 34, shift: !1 }, o["="] = { code: 187, shift: !1 }, o["-"] = { code: 189, shift: !1 }, o["]"] = { code: 221, shift: !1 }, o["["] = { code: 219, shift: !1 };
  var a = function(h) {
    d(h, "keydown");
  }, l = function(h) {
    d(h, "keyup");
  }, d = function(h, c) {
    if (n[c][h.keyCode] !== void 0) {
      for (var u = n[c][h.keyCode], f = 0; f < u.length; f++)
        (u[f].shift === void 0 || u[f].shift == !0 && h.shiftKey == !0 || u[f].shift == !1 && h.shiftKey == !1) && u[f].fn(h);
      e == !0 && h.preventDefault();
    }
  };
  return r.bind = function(h, c, u) {
    if (u === void 0 && (u = "keydown"), o[h] === void 0)
      throw new Error("unsupported key: " + h);
    n[u][o[h].code] === void 0 && (n[u][o[h].code] = []), n[u][o[h].code].push({ fn: c, shift: o[h].shift });
  }, r.bindAll = function(h, c) {
    c === void 0 && (c = "keydown");
    for (var u in o)
      o.hasOwnProperty(u) && r.bind(u, h, c);
  }, r.getKey = function(h) {
    for (var c in o)
      if (o.hasOwnProperty(c)) {
        if (h.shiftKey == !0 && o[c].shift == !0 && h.keyCode == o[c].code)
          return c;
        if (h.shiftKey == !1 && o[c].shift == !1 && h.keyCode == o[c].code)
          return c;
        if (h.keyCode == o[c].code && c == "shift")
          return c;
      }
    return "unknown key, currently not supported";
  }, r.unbind = function(h, c, u) {
    if (u === void 0 && (u = "keydown"), o[h] === void 0)
      throw new Error("unsupported key: " + h);
    if (c !== void 0) {
      var f = [], v = n[u][o[h].code];
      if (v !== void 0)
        for (var y = 0; y < v.length; y++)
          v[y].fn == c && v[y].shift == o[h].shift || f.push(n[u][o[h].code][y]);
      n[u][o[h].code] = f;
    } else
      n[u][o[h].code] = [];
  }, r.reset = function() {
    n = { keydown: {}, keyup: {} };
  }, r.destroy = function() {
    n = { keydown: {}, keyup: {} }, t.removeEventListener("keydown", a, !0), t.removeEventListener("keyup", l, !0);
  }, t.addEventListener("keydown", a, !0), t.addEventListener("keyup", l, !0), r;
}
class lae {
  /**
   * @param {object} body
   * @param {Canvas} canvas
   */
  constructor(e, t) {
    this.body = e, this.canvas = t, this.iconsCreated = !1, this.navigationHammers = [], this.boundFunctions = {}, this.touchTime = 0, this.activated = !1, this.body.emitter.on("activate", () => {
      this.activated = !0, this.configureKeyboardBindings();
    }), this.body.emitter.on("deactivate", () => {
      this.activated = !1, this.configureKeyboardBindings();
    }), this.body.emitter.on("destroy", () => {
      this.keycharm !== void 0 && this.keycharm.destroy();
    }), this.options = {};
  }
  /**
   *
   * @param {object} options
   */
  setOptions(e) {
    e !== void 0 && (this.options = e, this.create());
  }
  /**
   * Creates or refreshes navigation and sets key bindings
   */
  create() {
    this.options.navigationButtons === !0 ? this.iconsCreated === !1 && this.loadNavigationElements() : this.iconsCreated === !0 && this.cleanNavigation(), this.configureKeyboardBindings();
  }
  /**
   * Cleans up previous navigation items
   */
  cleanNavigation() {
    if (this.navigationHammers.length != 0) {
      for (let e = 0; e < this.navigationHammers.length; e++)
        this.navigationHammers[e].destroy();
      this.navigationHammers = [];
    }
    this.navigationDOM && this.navigationDOM.wrapper && this.navigationDOM.wrapper.parentNode && this.navigationDOM.wrapper.parentNode.removeChild(this.navigationDOM.wrapper), this.iconsCreated = !1;
  }
  /**
   * Creation of the navigation controls nodes. They are drawn over the rest of the nodes and are not affected by scale and translation
   * they have a triggerFunction which is called on click. If the position of the navigation controls is dependent
   * on this.frame.canvas.clientWidth or this.frame.canvas.clientHeight, we flag horizontalAlignLeft and verticalAlignTop false.
   * This means that the location will be corrected by the _relocateNavigation function on a size change of the canvas.
   * @private
   */
  loadNavigationElements() {
    this.cleanNavigation(), this.navigationDOM = {};
    const e = ["up", "down", "left", "right", "zoomIn", "zoomOut", "zoomExtends"], t = ["_moveUp", "_moveDown", "_moveLeft", "_moveRight", "_zoomIn", "_zoomOut", "_fit"];
    this.navigationDOM.wrapper = document.createElement("div"), this.navigationDOM.wrapper.className = "vis-navigation", this.canvas.frame.appendChild(this.navigationDOM.wrapper);
    for (let s = 0; s < e.length; s++) {
      this.navigationDOM[e[s]] = document.createElement("div"), this.navigationDOM[e[s]].className = "vis-button vis-" + e[s], this.navigationDOM.wrapper.appendChild(this.navigationDOM[e[s]]);
      const a = new dn(this.navigationDOM[e[s]]);
      if (t[s] === "_fit") {
        var r;
        ll(a, S(r = this._fit).call(r, this));
      } else {
        var n;
        ll(a, S(n = this.bindToRedraw).call(n, this, t[s]));
      }
      this.navigationHammers.push(a);
    }
    const o = new dn(this.canvas.frame);
    wS(o, () => {
      this._stopMovement();
    }), this.navigationHammers.push(o), this.iconsCreated = !0;
  }
  /**
   *
   * @param {string} action
   */
  bindToRedraw(e) {
    if (this.boundFunctions[e] === void 0) {
      var t;
      this.boundFunctions[e] = S(t = this[e]).call(t, this), this.body.emitter.on("initRedraw", this.boundFunctions[e]), this.body.emitter.emit("_startRendering");
    }
  }
  /**
   *
   * @param {string} action
   */
  unbindFromRedraw(e) {
    this.boundFunctions[e] !== void 0 && (this.body.emitter.off("initRedraw", this.boundFunctions[e]), this.body.emitter.emit("_stopRendering"), delete this.boundFunctions[e]);
  }
  /**
   * this stops all movement induced by the navigation buttons
   * @private
   */
  _fit() {
    (/* @__PURE__ */ new Date()).valueOf() - this.touchTime > 700 && (this.body.emitter.emit("fit", {
      duration: 700
    }), this.touchTime = (/* @__PURE__ */ new Date()).valueOf());
  }
  /**
   * this stops all movement induced by the navigation buttons
   * @private
   */
  _stopMovement() {
    for (const e in this.boundFunctions)
      Object.prototype.hasOwnProperty.call(this.boundFunctions, e) && (this.body.emitter.off("initRedraw", this.boundFunctions[e]), this.body.emitter.emit("_stopRendering"));
    this.boundFunctions = {};
  }
  /**
   *
   * @private
   */
  _moveUp() {
    this.body.view.translation.y += this.options.keyboard.speed.y;
  }
  /**
   *
   * @private
   */
  _moveDown() {
    this.body.view.translation.y -= this.options.keyboard.speed.y;
  }
  /**
   *
   * @private
   */
  _moveLeft() {
    this.body.view.translation.x += this.options.keyboard.speed.x;
  }
  /**
   *
   * @private
   */
  _moveRight() {
    this.body.view.translation.x -= this.options.keyboard.speed.x;
  }
  /**
   *
   * @private
   */
  _zoomIn() {
    const e = this.body.view.scale, t = this.body.view.scale * (1 + this.options.keyboard.speed.zoom), r = this.body.view.translation, n = t / e, o = (1 - n) * this.canvas.canvasViewCenter.x + r.x * n, s = (1 - n) * this.canvas.canvasViewCenter.y + r.y * n;
    this.body.view.scale = t, this.body.view.translation = {
      x: o,
      y: s
    }, this.body.emitter.emit("zoom", {
      direction: "+",
      scale: this.body.view.scale,
      pointer: null
    });
  }
  /**
   *
   * @private
   */
  _zoomOut() {
    const e = this.body.view.scale, t = this.body.view.scale / (1 + this.options.keyboard.speed.zoom), r = this.body.view.translation, n = t / e, o = (1 - n) * this.canvas.canvasViewCenter.x + r.x * n, s = (1 - n) * this.canvas.canvasViewCenter.y + r.y * n;
    this.body.view.scale = t, this.body.view.translation = {
      x: o,
      y: s
    }, this.body.emitter.emit("zoom", {
      direction: "-",
      scale: this.body.view.scale,
      pointer: null
    });
  }
  /**
   * bind all keys using keycharm.
   */
  configureKeyboardBindings() {
    if (this.keycharm !== void 0 && this.keycharm.destroy(), this.options.keyboard.enabled === !0 && (this.options.keyboard.bindToWindow === !0 ? this.keycharm = kb({
      container: window,
      preventDefault: !0
    }) : this.keycharm = kb({
      container: this.canvas.frame,
      preventDefault: !0
    }), this.keycharm.reset(), this.activated === !0)) {
      var e, t, r, n, o, s, a, l, d, h, c, u, f, v, y, g, p, m, $, w, T, A, L, G;
      S(e = this.keycharm).call(e, "up", () => {
        this.bindToRedraw("_moveUp");
      }, "keydown"), S(t = this.keycharm).call(t, "down", () => {
        this.bindToRedraw("_moveDown");
      }, "keydown"), S(r = this.keycharm).call(r, "left", () => {
        this.bindToRedraw("_moveLeft");
      }, "keydown"), S(n = this.keycharm).call(n, "right", () => {
        this.bindToRedraw("_moveRight");
      }, "keydown"), S(o = this.keycharm).call(o, "=", () => {
        this.bindToRedraw("_zoomIn");
      }, "keydown"), S(s = this.keycharm).call(s, "num+", () => {
        this.bindToRedraw("_zoomIn");
      }, "keydown"), S(a = this.keycharm).call(a, "num-", () => {
        this.bindToRedraw("_zoomOut");
      }, "keydown"), S(l = this.keycharm).call(l, "-", () => {
        this.bindToRedraw("_zoomOut");
      }, "keydown"), S(d = this.keycharm).call(d, "[", () => {
        this.bindToRedraw("_zoomOut");
      }, "keydown"), S(h = this.keycharm).call(h, "]", () => {
        this.bindToRedraw("_zoomIn");
      }, "keydown"), S(c = this.keycharm).call(c, "pageup", () => {
        this.bindToRedraw("_zoomIn");
      }, "keydown"), S(u = this.keycharm).call(u, "pagedown", () => {
        this.bindToRedraw("_zoomOut");
      }, "keydown"), S(f = this.keycharm).call(f, "up", () => {
        this.unbindFromRedraw("_moveUp");
      }, "keyup"), S(v = this.keycharm).call(v, "down", () => {
        this.unbindFromRedraw("_moveDown");
      }, "keyup"), S(y = this.keycharm).call(y, "left", () => {
        this.unbindFromRedraw("_moveLeft");
      }, "keyup"), S(g = this.keycharm).call(g, "right", () => {
        this.unbindFromRedraw("_moveRight");
      }, "keyup"), S(p = this.keycharm).call(p, "=", () => {
        this.unbindFromRedraw("_zoomIn");
      }, "keyup"), S(m = this.keycharm).call(m, "num+", () => {
        this.unbindFromRedraw("_zoomIn");
      }, "keyup"), S($ = this.keycharm).call($, "num-", () => {
        this.unbindFromRedraw("_zoomOut");
      }, "keyup"), S(w = this.keycharm).call(w, "-", () => {
        this.unbindFromRedraw("_zoomOut");
      }, "keyup"), S(T = this.keycharm).call(T, "[", () => {
        this.unbindFromRedraw("_zoomOut");
      }, "keyup"), S(A = this.keycharm).call(A, "]", () => {
        this.unbindFromRedraw("_zoomIn");
      }, "keyup"), S(L = this.keycharm).call(L, "pageup", () => {
        this.unbindFromRedraw("_zoomIn");
      }, "keyup"), S(G = this.keycharm).call(G, "pagedown", () => {
        this.unbindFromRedraw("_zoomOut");
      }, "keyup");
    }
  }
}
class dae {
  /**
   * @param {object} body
   * @param {Canvas} canvas
   * @param {SelectionHandler} selectionHandler
   */
  constructor(e, t, r) {
    var n, o, s, a, l, d, h, c, u, f, v, y, g;
    this.body = e, this.canvas = t, this.selectionHandler = r, this.navigationHandler = new lae(e, t), this.body.eventListeners.onTap = S(n = this.onTap).call(n, this), this.body.eventListeners.onTouch = S(o = this.onTouch).call(o, this), this.body.eventListeners.onDoubleTap = S(s = this.onDoubleTap).call(s, this), this.body.eventListeners.onHold = S(a = this.onHold).call(a, this), this.body.eventListeners.onDragStart = S(l = this.onDragStart).call(l, this), this.body.eventListeners.onDrag = S(d = this.onDrag).call(d, this), this.body.eventListeners.onDragEnd = S(h = this.onDragEnd).call(h, this), this.body.eventListeners.onMouseWheel = S(c = this.onMouseWheel).call(c, this), this.body.eventListeners.onPinch = S(u = this.onPinch).call(u, this), this.body.eventListeners.onMouseMove = S(f = this.onMouseMove).call(f, this), this.body.eventListeners.onRelease = S(v = this.onRelease).call(v, this), this.body.eventListeners.onContext = S(y = this.onContext).call(y, this), this.touchTime = 0, this.drag = {}, this.pinch = {}, this.popup = void 0, this.popupObj = void 0, this.popupTimer = void 0, this.body.functions.getPointer = S(g = this.getPointer).call(g, this), this.options = {}, this.defaultOptions = {
      dragNodes: !0,
      dragView: !0,
      hover: !1,
      keyboard: {
        enabled: !1,
        speed: {
          x: 10,
          y: 10,
          zoom: 0.02
        },
        bindToWindow: !0,
        autoFocus: !0
      },
      navigationButtons: !1,
      tooltipDelay: 300,
      zoomView: !0,
      zoomSpeed: 1
    }, Ce(this.options, this.defaultOptions), this.bindEventListeners();
  }
  /**
   * Binds event listeners
   */
  bindEventListeners() {
    this.body.emitter.on("destroy", () => {
      clearTimeout(this.popupTimer), delete this.body.functions.getPointer;
    });
  }
  /**
   *
   * @param {object} options
   */
  setOptions(e) {
    e !== void 0 && (il(["hideEdgesOnDrag", "hideEdgesOnZoom", "hideNodesOnDrag", "keyboard", "multiselect", "selectable", "selectConnectedEdges"], this.options, e), Et(this.options, e, "keyboard"), e.tooltip && (Ce(this.options.tooltip, e.tooltip), e.tooltip.color && (this.options.tooltip.color = _u(e.tooltip.color)))), this.navigationHandler.setOptions(this.options);
  }
  /**
   * Get the pointer location from a touch location
   * @param {{x: number, y: number}} touch
   * @returns {{x: number, y: number}} pointer
   * @private
   */
  getPointer(e) {
    return {
      x: e.x - uee(this.canvas.frame.canvas),
      y: e.y - fee(this.canvas.frame.canvas)
    };
  }
  /**
   * On start of a touch gesture, store the pointer
   * @param {Event}  event   The event
   * @private
   */
  onTouch(e) {
    (/* @__PURE__ */ new Date()).valueOf() - this.touchTime > 50 && (this.drag.pointer = this.getPointer(e.center), this.drag.pinched = !1, this.pinch.scale = this.body.view.scale, this.touchTime = (/* @__PURE__ */ new Date()).valueOf());
  }
  /**
   * handle tap/click event: select/unselect a node
   * @param {Event} event
   * @private
   */
  onTap(e) {
    const t = this.getPointer(e.center), r = this.selectionHandler.options.multiselect && (e.changedPointers[0].ctrlKey || e.changedPointers[0].metaKey);
    this.checkSelectionChanges(t, r), this.selectionHandler.commitAndEmit(t, e), this.selectionHandler.generateClickEvent("click", e, t);
  }
  /**
   * handle doubletap event
   * @param {Event} event
   * @private
   */
  onDoubleTap(e) {
    const t = this.getPointer(e.center);
    this.selectionHandler.generateClickEvent("doubleClick", e, t);
  }
  /**
   * handle long tap event: multi select nodes
   * @param {Event} event
   * @private
   */
  onHold(e) {
    const t = this.getPointer(e.center), r = this.selectionHandler.options.multiselect;
    this.checkSelectionChanges(t, r), this.selectionHandler.commitAndEmit(t, e), this.selectionHandler.generateClickEvent("click", e, t), this.selectionHandler.generateClickEvent("hold", e, t);
  }
  /**
   * handle the release of the screen
   * @param {Event} event
   * @private
   */
  onRelease(e) {
    if ((/* @__PURE__ */ new Date()).valueOf() - this.touchTime > 10) {
      const t = this.getPointer(e.center);
      this.selectionHandler.generateClickEvent("release", e, t), this.touchTime = (/* @__PURE__ */ new Date()).valueOf();
    }
  }
  /**
   *
   * @param {Event} event
   */
  onContext(e) {
    const t = this.getPointer({
      x: e.clientX,
      y: e.clientY
    });
    this.selectionHandler.generateClickEvent("oncontext", e, t);
  }
  /**
   * Select and deselect nodes depending current selection change.
   * @param {{x: number, y: number}} pointer
   * @param {boolean} [add]
   */
  checkSelectionChanges(e) {
    (arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1) === !0 ? this.selectionHandler.selectAdditionalOnPoint(e) : this.selectionHandler.selectOnPoint(e);
  }
  /**
   * Remove all node and edge id's from the first set that are present in the second one.
   * @param {{nodes: Array.<Node>, edges: Array.<vis.Edge>}} firstSet
   * @param {{nodes: Array.<Node>, edges: Array.<vis.Edge>}} secondSet
   * @returns {{nodes: Array.<Node>, edges: Array.<vis.Edge>}}
   * @private
   */
  _determineDifference(e, t) {
    const r = function(n, o) {
      const s = [];
      for (let a = 0; a < n.length; a++) {
        const l = n[a];
        re(o).call(o, l) === -1 && s.push(l);
      }
      return s;
    };
    return {
      nodes: r(e.nodes, t.nodes),
      edges: r(e.edges, t.edges)
    };
  }
  /**
   * This function is called by onDragStart.
   * It is separated out because we can then overload it for the datamanipulation system.
   * @param {Event} event
   * @private
   */
  onDragStart(e) {
    if (this.drag.dragging)
      return;
    this.drag.pointer === void 0 && this.onTouch(e);
    const t = this.selectionHandler.getNodeAt(this.drag.pointer);
    if (this.drag.dragging = !0, this.drag.selection = [], this.drag.translation = Ce({}, this.body.view.translation), this.drag.nodeId = void 0, e.srcEvent.shiftKey) {
      this.body.selectionBox.show = !0;
      const r = this.getPointer(e.center);
      this.body.selectionBox.position.start = {
        x: this.canvas._XconvertDOMtoCanvas(r.x),
        y: this.canvas._YconvertDOMtoCanvas(r.y)
      }, this.body.selectionBox.position.end = {
        x: this.canvas._XconvertDOMtoCanvas(r.x),
        y: this.canvas._YconvertDOMtoCanvas(r.y)
      };
    } else if (t !== void 0 && this.options.dragNodes === !0) {
      this.drag.nodeId = t.id, t.isSelected() === !1 && this.selectionHandler.setSelection({
        nodes: [t.id]
      }), this.selectionHandler.generateClickEvent("dragStart", e, this.drag.pointer);
      for (const r of this.selectionHandler.getSelectedNodes()) {
        const n = {
          id: r.id,
          node: r,
          // store original x, y, xFixed and yFixed, make the node temporarily Fixed
          x: r.x,
          y: r.y,
          xFixed: r.options.fixed.x,
          yFixed: r.options.fixed.y
        };
        r.options.fixed.x = !0, r.options.fixed.y = !0, this.drag.selection.push(n);
      }
    } else
      this.selectionHandler.generateClickEvent("dragStart", e, this.drag.pointer, void 0, !0);
  }
  /**
   * handle drag event
   * @param {Event} event
   * @private
   */
  onDrag(e) {
    if (this.drag.pinched === !0)
      return;
    this.body.emitter.emit("unlockNode");
    const t = this.getPointer(e.center), r = this.drag.selection;
    if (r && r.length && this.options.dragNodes === !0) {
      this.selectionHandler.generateClickEvent("dragging", e, t);
      const n = t.x - this.drag.pointer.x, o = t.y - this.drag.pointer.y;
      se(r).call(r, (s) => {
        const a = s.node;
        s.xFixed === !1 && (a.x = this.canvas._XconvertDOMtoCanvas(this.canvas._XconvertCanvasToDOM(s.x) + n)), s.yFixed === !1 && (a.y = this.canvas._YconvertDOMtoCanvas(this.canvas._YconvertCanvasToDOM(s.y) + o));
      }), this.body.emitter.emit("startSimulation");
    } else {
      if (e.srcEvent.shiftKey) {
        if (this.selectionHandler.generateClickEvent("dragging", e, t, void 0, !0), this.drag.pointer === void 0) {
          this.onDragStart(e);
          return;
        }
        this.body.selectionBox.position.end = {
          x: this.canvas._XconvertDOMtoCanvas(t.x),
          y: this.canvas._YconvertDOMtoCanvas(t.y)
        }, this.body.emitter.emit("_requestRedraw");
      }
      if (this.options.dragView === !0 && !e.srcEvent.shiftKey) {
        if (this.selectionHandler.generateClickEvent("dragging", e, t, void 0, !0), this.drag.pointer === void 0) {
          this.onDragStart(e);
          return;
        }
        const n = t.x - this.drag.pointer.x, o = t.y - this.drag.pointer.y;
        this.body.view.translation = {
          x: this.drag.translation.x + n,
          y: this.drag.translation.y + o
        }, this.body.emitter.emit("_requestRedraw");
      }
    }
  }
  /**
   * handle drag start event
   * @param {Event} event
   * @private
   */
  onDragEnd(e) {
    if (this.drag.dragging = !1, this.body.selectionBox.show) {
      var t;
      this.body.selectionBox.show = !1;
      const r = this.body.selectionBox.position, n = {
        minX: Math.min(r.start.x, r.end.x),
        minY: Math.min(r.start.y, r.end.y),
        maxX: Math.max(r.start.x, r.end.x),
        maxY: Math.max(r.start.y, r.end.y)
      }, o = ht(t = this.body.nodeIndices).call(t, (a) => {
        const l = this.body.nodes[a];
        return l.x >= n.minX && l.x <= n.maxX && l.y >= n.minY && l.y <= n.maxY;
      });
      se(o).call(o, (a) => this.selectionHandler.selectObject(this.body.nodes[a]));
      const s = this.getPointer(e.center);
      this.selectionHandler.commitAndEmit(s, e), this.selectionHandler.generateClickEvent("dragEnd", e, this.getPointer(e.center), void 0, !0), this.body.emitter.emit("_requestRedraw");
    } else {
      const r = this.drag.selection;
      r && r.length ? (se(r).call(r, function(n) {
        n.node.options.fixed.x = n.xFixed, n.node.options.fixed.y = n.yFixed;
      }), this.selectionHandler.generateClickEvent("dragEnd", e, this.getPointer(e.center)), this.body.emitter.emit("startSimulation")) : (this.selectionHandler.generateClickEvent("dragEnd", e, this.getPointer(e.center), void 0, !0), this.body.emitter.emit("_requestRedraw"));
    }
  }
  /**
   * Handle pinch event
   * @param {Event}  event   The event
   * @private
   */
  onPinch(e) {
    const t = this.getPointer(e.center);
    this.drag.pinched = !0, this.pinch.scale === void 0 && (this.pinch.scale = 1);
    const r = this.pinch.scale * e.scale;
    this.zoom(r, t);
  }
  /**
   * Zoom the network in or out
   * @param {number} scale a number around 1, and between 0.01 and 10
   * @param {{x: number, y: number}} pointer    Position on screen
   * @private
   */
  zoom(e, t) {
    if (this.options.zoomView === !0) {
      const r = this.body.view.scale;
      e < 1e-5 && (e = 1e-5), e > 10 && (e = 10);
      let n;
      this.drag !== void 0 && this.drag.dragging === !0 && (n = this.canvas.DOMtoCanvas(this.drag.pointer));
      const o = this.body.view.translation, s = e / r, a = (1 - s) * t.x + o.x * s, l = (1 - s) * t.y + o.y * s;
      if (this.body.view.scale = e, this.body.view.translation = {
        x: a,
        y: l
      }, n != null) {
        const d = this.canvas.canvasToDOM(n);
        this.drag.pointer.x = d.x, this.drag.pointer.y = d.y;
      }
      this.body.emitter.emit("_requestRedraw"), r < e ? this.body.emitter.emit("zoom", {
        direction: "+",
        scale: this.body.view.scale,
        pointer: t
      }) : this.body.emitter.emit("zoom", {
        direction: "-",
        scale: this.body.view.scale,
        pointer: t
      });
    }
  }
  /**
   * Event handler for mouse wheel event, used to zoom the timeline
   * See http://adomas.org/javascript-mouse-wheel/
   * https://github.com/EightMedia/hammer.js/issues/256
   * @param {MouseEvent}  event
   * @private
   */
  onMouseWheel(e) {
    if (this.options.zoomView === !0) {
      if (e.deltaY !== 0) {
        let t = this.body.view.scale;
        t *= 1 + (e.deltaY < 0 ? 1 : -1) * (this.options.zoomSpeed * 0.1);
        const r = this.getPointer({
          x: e.clientX,
          y: e.clientY
        });
        this.zoom(t, r);
      }
      e.preventDefault();
    }
  }
  /**
   * Mouse move handler for checking whether the title moves over a node with a title.
   * @param  {Event} event
   * @private
   */
  onMouseMove(e) {
    const t = this.getPointer({
      x: e.clientX,
      y: e.clientY
    });
    let r = !1;
    this.popup !== void 0 && (this.popup.hidden === !1 && this._checkHidePopup(t), this.popup.hidden === !1 && (r = !0, this.popup.setPosition(t.x + 3, t.y - 5), this.popup.show())), this.options.keyboard.autoFocus && this.options.keyboard.bindToWindow === !1 && this.options.keyboard.enabled === !0 && this.canvas.frame.focus(), r === !1 && (this.popupTimer !== void 0 && (clearInterval(this.popupTimer), this.popupTimer = void 0), this.drag.dragging || (this.popupTimer = lr(() => this._checkShowPopup(t), this.options.tooltipDelay))), this.options.hover === !0 && this.selectionHandler.hoverObject(e, t);
  }
  /**
   * Check if there is an element on the given position in the network
   * (a node or edge). If so, and if this element has a title,
   * show a popup window with its title.
   * @param {{x:number, y:number}} pointer
   * @private
   */
  _checkShowPopup(e) {
    const t = this.canvas._XconvertDOMtoCanvas(e.x), r = this.canvas._YconvertDOMtoCanvas(e.y), n = {
      left: t,
      top: r,
      right: t,
      bottom: r
    }, o = this.popupObj === void 0 ? void 0 : this.popupObj.id;
    let s = !1, a = "node";
    if (this.popupObj === void 0) {
      const l = this.body.nodeIndices, d = this.body.nodes;
      let h;
      const c = [];
      for (let u = 0; u < l.length; u++)
        h = d[l[u]], h.isOverlappingWith(n) === !0 && (s = !0, h.getTitle() !== void 0 && c.push(l[u]));
      c.length > 0 && (this.popupObj = d[c[c.length - 1]], s = !0);
    }
    if (this.popupObj === void 0 && s === !1) {
      const l = this.body.edgeIndices, d = this.body.edges;
      let h;
      const c = [];
      for (let u = 0; u < l.length; u++)
        h = d[l[u]], h.isOverlappingWith(n) === !0 && h.connected === !0 && h.getTitle() !== void 0 && c.push(l[u]);
      c.length > 0 && (this.popupObj = d[c[c.length - 1]], a = "edge");
    }
    this.popupObj !== void 0 ? this.popupObj.id !== o && (this.popup === void 0 && (this.popup = new See(this.canvas.frame)), this.popup.popupTargetType = a, this.popup.popupTargetId = this.popupObj.id, this.popup.setPosition(e.x + 3, e.y - 5), this.popup.setText(this.popupObj.getTitle()), this.popup.show(), this.body.emitter.emit("showPopup", this.popupObj.id)) : this.popup !== void 0 && (this.popup.hide(), this.body.emitter.emit("hidePopup"));
  }
  /**
   * Check if the popup must be hidden, which is the case when the mouse is no
   * longer hovering on the object
   * @param {{x:number, y:number}} pointer
   * @private
   */
  _checkHidePopup(e) {
    const t = this.selectionHandler._pointerToPositionObject(e);
    let r = !1;
    if (this.popup.popupTargetType === "node") {
      if (this.body.nodes[this.popup.popupTargetId] !== void 0 && (r = this.body.nodes[this.popup.popupTargetId].isOverlappingWith(t), r === !0)) {
        const n = this.selectionHandler.getNodeAt(e);
        r = n === void 0 ? !1 : n.id === this.popup.popupTargetId;
      }
    } else
      this.selectionHandler.getNodeAt(e) === void 0 && this.body.edges[this.popup.popupTargetId] !== void 0 && (r = this.body.edges[this.popup.popupTargetId].isOverlappingWith(t));
    r === !1 && (this.popupObj = void 0, this.popup.hide(), this.body.emitter.emit("hidePopup"));
  }
}
var hae = qf, cae = ZE;
hae("Set", function(i) {
  return function() {
    return i(this, arguments.length ? arguments[0] : void 0);
  };
}, cae);
var uae = ie, fae = uae.Set, vae = fae, pae = vae, gae = pae, Tr = /* @__PURE__ */ U(gae), yae = Q, Nb = Xf, va = od.getWeakData, mae = Yf, bae = br, $ae = zn, pc = Ye, wae = Kf, _S = Kr, Rb = Ue, ES = Di, _ae = ES.set, Eae = ES.getterFor, Sae = _S.find, Oae = _S.findIndex, Tae = yae([].splice), Iae = 0, pa = function(i) {
  return i.frozen || (i.frozen = new SS());
}, SS = function() {
  this.entries = [];
}, gc = function(i, e) {
  return Sae(i.entries, function(t) {
    return t[0] === e;
  });
};
SS.prototype = {
  get: function(i) {
    var e = gc(this, i);
    if (e) return e[1];
  },
  has: function(i) {
    return !!gc(this, i);
  },
  set: function(i, e) {
    var t = gc(this, i);
    t ? t[1] = e : this.entries.push([i, e]);
  },
  delete: function(i) {
    var e = Oae(this.entries, function(t) {
      return t[0] === i;
    });
    return ~e && Tae(this.entries, e, 1), !!~e;
  }
};
var Pae = {
  getConstructor: function(i, e, t, r) {
    var n = i(function(l, d) {
      mae(l, o), _ae(l, {
        type: e,
        id: Iae++,
        frozen: void 0
      }), $ae(d) || wae(d, l[r], { that: l, AS_ENTRIES: t });
    }), o = n.prototype, s = Eae(e), a = function(l, d, h) {
      var c = s(l), u = va(bae(d), !0);
      return u === !0 ? pa(c).set(d, h) : u[c.id] = h, l;
    };
    return Nb(o, {
      // `{ WeakMap, WeakSet }.prototype.delete(key)` methods
      // https://tc39.es/ecma262/#sec-weakmap.prototype.delete
      // https://tc39.es/ecma262/#sec-weakset.prototype.delete
      delete: function(l) {
        var d = s(this);
        if (!pc(l)) return !1;
        var h = va(l);
        return h === !0 ? pa(d).delete(l) : h && Rb(h, d.id) && delete h[d.id];
      },
      // `{ WeakMap, WeakSet }.prototype.has(key)` methods
      // https://tc39.es/ecma262/#sec-weakmap.prototype.has
      // https://tc39.es/ecma262/#sec-weakset.prototype.has
      has: function(d) {
        var h = s(this);
        if (!pc(d)) return !1;
        var c = va(d);
        return c === !0 ? pa(h).has(d) : c && Rb(c, h.id);
      }
    }), Nb(o, t ? {
      // `WeakMap.prototype.get(key)` method
      // https://tc39.es/ecma262/#sec-weakmap.prototype.get
      get: function(d) {
        var h = s(this);
        if (pc(d)) {
          var c = va(d);
          return c === !0 ? pa(h).get(d) : c ? c[h.id] : void 0;
        }
      },
      // `WeakMap.prototype.set(key, value)` method
      // https://tc39.es/ecma262/#sec-weakmap.prototype.set
      set: function(d, h) {
        return a(this, d, h);
      }
    } : {
      // `WeakSet.prototype.add(value)` method
      // https://tc39.es/ecma262/#sec-weakset.prototype.add
      add: function(d) {
        return a(this, d, !0);
      }
    }), n;
  }
}, xae = KE, Fb = _e, Na = Q, Bb = Xf, Cae = od, Aae = qf, OS = Pae, ga = Ye, ya = Di.enforce, Mae = Z, Dae = y_, Ms = Object, kae = Array.isArray, ma = Ms.isExtensible, TS = Ms.isFrozen, Nae = Ms.isSealed, IS = Ms.freeze, Rae = Ms.seal, Lb = {}, jb = {}, Fae = !Fb.ActiveXObject && "ActiveXObject" in Fb, io, PS = function(i) {
  return function() {
    return i(this, arguments.length ? arguments[0] : void 0);
  };
}, xS = Aae("WeakMap", PS, OS), Yi = xS.prototype, Ra = Na(Yi.set), Bae = function() {
  return xae && Mae(function() {
    var i = IS([]);
    return Ra(new xS(), i, 1), !TS(i);
  });
};
if (Dae) if (Fae) {
  io = OS.getConstructor(PS, "WeakMap", !0), Cae.enable();
  var zb = Na(Yi.delete), ba = Na(Yi.has), Wb = Na(Yi.get);
  Bb(Yi, {
    delete: function(i) {
      if (ga(i) && !ma(i)) {
        var e = ya(this);
        return e.frozen || (e.frozen = new io()), zb(this, i) || e.frozen.delete(i);
      }
      return zb(this, i);
    },
    has: function(e) {
      if (ga(e) && !ma(e)) {
        var t = ya(this);
        return t.frozen || (t.frozen = new io()), ba(this, e) || t.frozen.has(e);
      }
      return ba(this, e);
    },
    get: function(e) {
      if (ga(e) && !ma(e)) {
        var t = ya(this);
        return t.frozen || (t.frozen = new io()), ba(this, e) ? Wb(this, e) : t.frozen.get(e);
      }
      return Wb(this, e);
    },
    set: function(e, t) {
      if (ga(e) && !ma(e)) {
        var r = ya(this);
        r.frozen || (r.frozen = new io()), ba(this, e) ? Ra(this, e, t) : r.frozen.set(e, t);
      } else Ra(this, e, t);
      return this;
    }
  });
} else Bae() && Bb(Yi, {
  set: function(e, t) {
    var r;
    return kae(e) && (TS(e) ? r = Lb : Nae(e) && (r = jb)), Ra(this, e, t), r === Lb && IS(e), r === jb && Rae(e), this;
  }
});
var Lae = ie, jae = Lae.WeakMap, zae = jae, Wae = zae, Hae = Wae, mo = /* @__PURE__ */ U(Hae);
function ae(i, e, t, r) {
  if (typeof e == "function" ? i !== e || !r : !e.has(i)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return t === "m" ? r : t === "a" ? r.call(i) : r ? r.value : e.get(i);
}
function Pu(i, e, t, r, n) {
  if (typeof e == "function" ? i !== e || !0 : !e.has(i)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return e.set(i, t), t;
}
var ei, _t, _r, Er, Fa;
function Hb(i, e) {
  const t = new Tr();
  for (const r of e)
    i.has(r) || t.add(r);
  return t;
}
class Vb {
  constructor() {
    ei.set(this, new Tr()), _t.set(this, new Tr());
  }
  get size() {
    return ae(this, _t, "f").size;
  }
  add() {
    for (var e = arguments.length, t = new Array(e), r = 0; r < e; r++)
      t[r] = arguments[r];
    for (const n of t)
      ae(this, _t, "f").add(n);
  }
  delete() {
    for (var e = arguments.length, t = new Array(e), r = 0; r < e; r++)
      t[r] = arguments[r];
    for (const n of t)
      ae(this, _t, "f").delete(n);
  }
  clear() {
    ae(this, _t, "f").clear();
  }
  getSelection() {
    return [...ae(this, _t, "f")];
  }
  getChanges() {
    return {
      added: [...Hb(ae(this, ei, "f"), ae(this, _t, "f"))],
      deleted: [...Hb(ae(this, _t, "f"), ae(this, ei, "f"))],
      previous: [...new Tr(ae(this, ei, "f"))],
      current: [...new Tr(ae(this, _t, "f"))]
    };
  }
  commit() {
    const e = this.getChanges();
    Pu(this, ei, ae(this, _t, "f")), Pu(this, _t, new Tr(ae(this, ei, "f")));
    for (const t of e.added)
      t.select();
    for (const t of e.deleted)
      t.unselect();
    return e;
  }
}
ei = new mo(), _t = new mo();
class Vae {
  constructor() {
    let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : () => {
    };
    _r.set(this, new Vb()), Er.set(this, new Vb()), Fa.set(this, void 0), Pu(this, Fa, e);
  }
  get sizeNodes() {
    return ae(this, _r, "f").size;
  }
  get sizeEdges() {
    return ae(this, Er, "f").size;
  }
  getNodes() {
    return ae(this, _r, "f").getSelection();
  }
  getEdges() {
    return ae(this, Er, "f").getSelection();
  }
  addNodes() {
    ae(this, _r, "f").add(...arguments);
  }
  addEdges() {
    ae(this, Er, "f").add(...arguments);
  }
  deleteNodes(e) {
    ae(this, _r, "f").delete(e);
  }
  deleteEdges(e) {
    ae(this, Er, "f").delete(e);
  }
  clear() {
    ae(this, _r, "f").clear(), ae(this, Er, "f").clear();
  }
  commit() {
    const e = {
      nodes: ae(this, _r, "f").commit(),
      edges: ae(this, Er, "f").commit()
    };
    for (var t = arguments.length, r = new Array(t), n = 0; n < t; n++)
      r[n] = arguments[n];
    return ae(this, Fa, "f").call(this, e, ...r), e;
  }
}
_r = new mo(), Er = new mo(), Fa = new mo();
class Uae {
  /**
   * @param {object} body
   * @param {Canvas} canvas
   */
  constructor(e, t) {
    this.body = e, this.canvas = t, this._selectionAccumulator = new Vae(), this.hoverObj = {
      nodes: {},
      edges: {}
    }, this.options = {}, this.defaultOptions = {
      multiselect: !1,
      selectable: !0,
      selectConnectedEdges: !0,
      hoverConnectedEdges: !0
    }, Ce(this.options, this.defaultOptions), this.body.emitter.on("_dataChanged", () => {
      this.updateSelection();
    });
  }
  /**
   *
   * @param {object} [options]
   */
  setOptions(e) {
    e !== void 0 && Xn(["multiselect", "hoverConnectedEdges", "selectable", "selectConnectedEdges"], this.options, e);
  }
  /**
   * handles the selection part of the tap;
   * @param {{x: number, y: number}} pointer
   * @returns {boolean}
   */
  selectOnPoint(e) {
    let t = !1;
    if (this.options.selectable === !0) {
      const r = this.getNodeAt(e) || this.getEdgeAt(e);
      this.unselectAll(), r !== void 0 && (t = this.selectObject(r)), this.body.emitter.emit("_requestRedraw");
    }
    return t;
  }
  /**
   *
   * @param {{x: number, y: number}} pointer
   * @returns {boolean}
   */
  selectAdditionalOnPoint(e) {
    let t = !1;
    if (this.options.selectable === !0) {
      const r = this.getNodeAt(e) || this.getEdgeAt(e);
      r !== void 0 && (t = !0, r.isSelected() === !0 ? this.deselectObject(r) : this.selectObject(r), this.body.emitter.emit("_requestRedraw"));
    }
    return t;
  }
  /**
   * Create an object containing the standard fields for an event.
   * @param {Event} event
   * @param {{x: number, y: number}} pointer Object with the x and y screen coordinates of the mouse
   * @returns {{}}
   * @private
   */
  _initBaseEvent(e, t) {
    const r = {};
    return r.pointer = {
      DOM: {
        x: t.x,
        y: t.y
      },
      canvas: this.canvas.DOMtoCanvas(t)
    }, r.event = e, r;
  }
  /**
   * Generate an event which the user can catch.
   *
   * This adds some extra data to the event with respect to cursor position and
   * selected nodes and edges.
   * @param {string} eventType                          Name of event to send
   * @param {Event}  event
   * @param {{x: number, y: number}} pointer            Object with the x and y screen coordinates of the mouse
   * @param {object | undefined} oldSelection             If present, selection state before event occured
   * @param {boolean|undefined} [emptySelection]  Indicate if selection data should be passed
   */
  generateClickEvent(e, t, r, n) {
    let o = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : !1;
    const s = this._initBaseEvent(t, r);
    if (o === !0)
      s.nodes = [], s.edges = [];
    else {
      const a = this.getSelection();
      s.nodes = a.nodes, s.edges = a.edges;
    }
    n !== void 0 && (s.previousSelection = n), e == "click" && (s.items = this.getClickedItems(r)), t.controlEdge !== void 0 && (s.controlEdge = t.controlEdge), this.body.emitter.emit(e, s);
  }
  /**
   *
   * @param {object} obj
   * @param {boolean} [highlightEdges]
   * @returns {boolean}
   */
  selectObject(e) {
    let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : this.options.selectConnectedEdges;
    return e !== void 0 ? (e instanceof ue ? (t === !0 && this._selectionAccumulator.addEdges(...e.edges), this._selectionAccumulator.addNodes(e)) : this._selectionAccumulator.addEdges(e), !0) : !1;
  }
  /**
   *
   * @param {object} obj
   */
  deselectObject(e) {
    e.isSelected() === !0 && (e.selected = !1, this._removeFromSelection(e));
  }
  /**
   * retrieve all nodes overlapping with given object
   * @param {object} object  An object with parameters left, top, right, bottom
   * @returns {number[]}   An array with id's of the overlapping nodes
   * @private
   */
  _getAllNodesOverlappingWith(e) {
    const t = [], r = this.body.nodes;
    for (let n = 0; n < this.body.nodeIndices.length; n++) {
      const o = this.body.nodeIndices[n];
      r[o].isOverlappingWith(e) && t.push(o);
    }
    return t;
  }
  /**
   * Return a position object in canvasspace from a single point in screenspace
   * @param {{x: number, y: number}} pointer
   * @returns {{left: number, top: number, right: number, bottom: number}}
   * @private
   */
  _pointerToPositionObject(e) {
    const t = this.canvas.DOMtoCanvas(e);
    return {
      left: t.x - 1,
      top: t.y + 1,
      right: t.x + 1,
      bottom: t.y - 1
    };
  }
  /**
   * Get the top node at the passed point (like a click)
   * @param {{x: number, y: number}} pointer
   * @param {boolean} [returnNode]
   * @returns {Node | undefined} node
   */
  getNodeAt(e) {
    let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !0;
    const r = this._pointerToPositionObject(e), n = this._getAllNodesOverlappingWith(r);
    if (n.length > 0)
      return t === !0 ? this.body.nodes[n[n.length - 1]] : n[n.length - 1];
  }
  /**
   * retrieve all edges overlapping with given object, selector is around center
   * @param {object} object  An object with parameters left, top, right, bottom
   * @param {number[]} overlappingEdges An array with id's of the overlapping nodes
   * @private
   */
  _getEdgesOverlappingWith(e, t) {
    const r = this.body.edges;
    for (let n = 0; n < this.body.edgeIndices.length; n++) {
      const o = this.body.edgeIndices[n];
      r[o].isOverlappingWith(e) && t.push(o);
    }
  }
  /**
   * retrieve all nodes overlapping with given object
   * @param {object} object  An object with parameters left, top, right, bottom
   * @returns {number[]}   An array with id's of the overlapping nodes
   * @private
   */
  _getAllEdgesOverlappingWith(e) {
    const t = [];
    return this._getEdgesOverlappingWith(e, t), t;
  }
  /**
   * Get the edges nearest to the passed point (like a click)
   * @param {{x: number, y: number}} pointer
   * @param {boolean} [returnEdge]
   * @returns {Edge | undefined} node
   */
  getEdgeAt(e) {
    let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !0;
    const r = this.canvas.DOMtoCanvas(e);
    let n = 10, o = null;
    const s = this.body.edges;
    for (let a = 0; a < this.body.edgeIndices.length; a++) {
      const l = this.body.edgeIndices[a], d = s[l];
      if (d.connected) {
        const h = d.from.x, c = d.from.y, u = d.to.x, f = d.to.y, v = d.edgeType.getDistanceToEdge(h, c, u, f, r.x, r.y);
        v < n && (o = l, n = v);
      }
    }
    if (o !== null)
      return t === !0 ? this.body.edges[o] : o;
  }
  /**
   * Add object to the selection array.
   * @param {object} obj
   * @private
   */
  _addToHover(e) {
    e instanceof ue ? this.hoverObj.nodes[e.id] = e : this.hoverObj.edges[e.id] = e;
  }
  /**
   * Remove a single option from selection.
   * @param {object} obj
   * @private
   */
  _removeFromSelection(e) {
    e instanceof ue ? (this._selectionAccumulator.deleteNodes(e), this._selectionAccumulator.deleteEdges(...e.edges)) : this._selectionAccumulator.deleteEdges(e);
  }
  /**
   * Unselect all nodes and edges.
   */
  unselectAll() {
    this._selectionAccumulator.clear();
  }
  /**
   * return the number of selected nodes
   * @returns {number}
   */
  getSelectedNodeCount() {
    return this._selectionAccumulator.sizeNodes;
  }
  /**
   * return the number of selected edges
   * @returns {number}
   */
  getSelectedEdgeCount() {
    return this._selectionAccumulator.sizeEdges;
  }
  /**
   * select the edges connected to the node that is being selected
   * @param {Node} node
   * @private
   */
  _hoverConnectedEdges(e) {
    for (let t = 0; t < e.edges.length; t++) {
      const r = e.edges[t];
      r.hover = !0, this._addToHover(r);
    }
  }
  /**
   * Remove the highlight from a node or edge, in response to mouse movement
   * @param {Event}  event
   * @param {{x: number, y: number}} pointer object with the x and y screen coordinates of the mouse
   * @param {Node|vis.Edge} object
   * @private
   */
  emitBlurEvent(e, t, r) {
    const n = this._initBaseEvent(e, t);
    r.hover === !0 && (r.hover = !1, r instanceof ue ? (n.node = r.id, this.body.emitter.emit("blurNode", n)) : (n.edge = r.id, this.body.emitter.emit("blurEdge", n)));
  }
  /**
   * Create the highlight for a node or edge, in response to mouse movement
   * @param {Event}  event
   * @param {{x: number, y: number}} pointer object with the x and y screen coordinates of the mouse
   * @param {Node|vis.Edge} object
   * @returns {boolean} hoverChanged
   * @private
   */
  emitHoverEvent(e, t, r) {
    const n = this._initBaseEvent(e, t);
    let o = !1;
    return r.hover === !1 && (r.hover = !0, this._addToHover(r), o = !0, r instanceof ue ? (n.node = r.id, this.body.emitter.emit("hoverNode", n)) : (n.edge = r.id, this.body.emitter.emit("hoverEdge", n))), o;
  }
  /**
   * Perform actions in response to a mouse movement.
   * @param {Event}  event
   * @param {{x: number, y: number}} pointer | object with the x and y screen coordinates of the mouse
   */
  hoverObject(e, t) {
    let r = this.getNodeAt(t);
    r === void 0 && (r = this.getEdgeAt(t));
    let n = !1;
    for (const o in this.hoverObj.nodes)
      Object.prototype.hasOwnProperty.call(this.hoverObj.nodes, o) && (r === void 0 || r instanceof ue && r.id != o || r instanceof Fr) && (this.emitBlurEvent(e, t, this.hoverObj.nodes[o]), delete this.hoverObj.nodes[o], n = !0);
    for (const o in this.hoverObj.edges)
      Object.prototype.hasOwnProperty.call(this.hoverObj.edges, o) && (n === !0 ? (this.hoverObj.edges[o].hover = !1, delete this.hoverObj.edges[o]) : (r === void 0 || r instanceof Fr && r.id != o || r instanceof ue && !r.hover) && (this.emitBlurEvent(e, t, this.hoverObj.edges[o]), delete this.hoverObj.edges[o], n = !0));
    if (r !== void 0) {
      const o = me(this.hoverObj.edges).length, s = me(this.hoverObj.nodes).length, a = r instanceof Fr && o === 0 && s === 0, l = r instanceof ue && o === 0 && s === 0;
      (n || a || l) && (n = this.emitHoverEvent(e, t, r)), r instanceof ue && this.options.hoverConnectedEdges === !0 && this._hoverConnectedEdges(r);
    }
    n === !0 && this.body.emitter.emit("_requestRedraw");
  }
  /**
   * Commit the selection changes but don't emit any events.
   */
  commitWithoutEmitting() {
    this._selectionAccumulator.commit();
  }
  /**
   * Select and deselect nodes depending current selection change.
   *
   * For changing nodes, select/deselect events are fired.
   *
   * NOTE: For a given edge, if one connecting node is deselected and with the
   * same click the other node is selected, no events for the edge will fire. It
   * was selected and it will remain selected.
   * @param {{x: number, y: number}} pointer - The x and y coordinates of the
   * click, tap, dragend… that triggered this.
   * @param {UIEvent} event - The event that triggered this.
   */
  commitAndEmit(e, t) {
    let r = !1;
    const n = this._selectionAccumulator.commit(), o = {
      nodes: n.nodes.previous,
      edges: n.edges.previous
    };
    n.edges.deleted.length > 0 && (this.generateClickEvent("deselectEdge", t, e, o), r = !0), n.nodes.deleted.length > 0 && (this.generateClickEvent("deselectNode", t, e, o), r = !0), n.nodes.added.length > 0 && (this.generateClickEvent("selectNode", t, e), r = !0), n.edges.added.length > 0 && (this.generateClickEvent("selectEdge", t, e), r = !0), r === !0 && this.generateClickEvent("select", t, e);
  }
  /**
   * Retrieve the currently selected node and edge ids.
   * @returns {{nodes: Array.<string>, edges: Array.<string>}} Arrays with the
   * ids of the selected nodes and edges.
   */
  getSelection() {
    return {
      nodes: this.getSelectedNodeIds(),
      edges: this.getSelectedEdgeIds()
    };
  }
  /**
   * Retrieve the currently selected nodes.
   * @returns {Array} An array with selected nodes.
   */
  getSelectedNodes() {
    return this._selectionAccumulator.getNodes();
  }
  /**
   * Retrieve the currently selected edges.
   * @returns {Array} An array with selected edges.
   */
  getSelectedEdges() {
    return this._selectionAccumulator.getEdges();
  }
  /**
   * Retrieve the currently selected node ids.
   * @returns {Array} An array with the ids of the selected nodes.
   */
  getSelectedNodeIds() {
    var e;
    return _n(e = this._selectionAccumulator.getNodes()).call(e, (t) => t.id);
  }
  /**
   * Retrieve the currently selected edge ids.
   * @returns {Array} An array with the ids of the selected edges.
   */
  getSelectedEdgeIds() {
    var e;
    return _n(e = this._selectionAccumulator.getEdges()).call(e, (t) => t.id);
  }
  /**
   * Updates the current selection
   * @param {{nodes: Array.<string>, edges: Array.<string>}} selection
   * @param {object} options                                 Options
   */
  setSelection(e) {
    let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    if (!e || !e.nodes && !e.edges)
      throw new TypeError("Selection must be an object with nodes and/or edges properties");
    if ((t.unselectAll || t.unselectAll === void 0) && this.unselectAll(), e.nodes)
      for (const r of e.nodes) {
        const n = this.body.nodes[r];
        if (!n)
          throw new RangeError('Node with id "' + r + '" not found');
        this.selectObject(n, t.highlightEdges);
      }
    if (e.edges)
      for (const r of e.edges) {
        const n = this.body.edges[r];
        if (!n)
          throw new RangeError('Edge with id "' + r + '" not found');
        this.selectObject(n);
      }
    this.body.emitter.emit("_requestRedraw"), this._selectionAccumulator.commit();
  }
  /**
   * select zero or more nodes with the option to highlight edges
   * @param {number[] | string[]} selection     An array with the ids of the
   *                                            selected nodes.
   * @param {boolean} [highlightEdges]
   */
  selectNodes(e) {
    let t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !0;
    if (!e || e.length === void 0) throw "Selection must be an array with ids";
    this.setSelection({
      nodes: e
    }, {
      highlightEdges: t
    });
  }
  /**
   * select zero or more edges
   * @param {number[] | string[]} selection     An array with the ids of the
   *                                            selected nodes.
   */
  selectEdges(e) {
    if (!e || e.length === void 0) throw "Selection must be an array with ids";
    this.setSelection({
      edges: e
    });
  }
  /**
   * Validate the selection: remove ids of nodes which no longer exist
   * @private
   */
  updateSelection() {
    for (const e in this._selectionAccumulator.getNodes())
      Object.prototype.hasOwnProperty.call(this.body.nodes, e.id) || this._selectionAccumulator.deleteNodes(e);
    for (const e in this._selectionAccumulator.getEdges())
      Object.prototype.hasOwnProperty.call(this.body.edges, e.id) || this._selectionAccumulator.deleteEdges(e);
  }
  /**
   * Determine all the visual elements clicked which are on the given point.
   *
   * All elements are returned; this includes nodes, edges and their labels.
   * The order returned is from highest to lowest, i.e. element 0 of the return
   * value is the topmost item clicked on.
   *
   * The return value consists of an array of the following possible elements:
   *
   * - `{nodeId:number}`             - node with given id clicked on
   * - `{nodeId:number, labelId:0}`  - label of node with given id clicked on
   * - `{edgeId:number}`             - edge with given id clicked on
   * - `{edge:number, labelId:0}`    - label of edge with given id clicked on
   *
   * ## NOTES
   *
   * - Currently, there is only one label associated with a node or an edge,
   * but this is expected to change somewhere in the future.
   * - Since there is no z-indexing yet, it is not really possible to set the nodes and
   * edges in the correct order. For the time being, nodes come first.
   * @param {point} pointer  mouse position in screen coordinates
   * @returns {Array.<nodeClickItem|nodeLabelClickItem|edgeClickItem|edgeLabelClickItem>}
   * @private
   */
  getClickedItems(e) {
    const t = this.canvas.DOMtoCanvas(e), r = [], n = this.body.nodeIndices, o = this.body.nodes;
    for (let l = n.length - 1; l >= 0; l--) {
      const h = o[n[l]].getItemsOnPoint(t);
      r.push.apply(r, h);
    }
    const s = this.body.edgeIndices, a = this.body.edges;
    for (let l = s.length - 1; l >= 0; l--) {
      const h = a[s[l]].getItemsOnPoint(t);
      r.push.apply(r, h);
    }
    return r;
  }
}
var Ub = f_, Gae = Math.floor, xu = function(i, e) {
  var t = i.length, r = Gae(t / 2);
  return t < 8 ? Kae(i, e) : Yae(
    i,
    xu(Ub(i, 0, r), e),
    xu(Ub(i, r), e),
    e
  );
}, Kae = function(i, e) {
  for (var t = i.length, r = 1, n, o; r < t; ) {
    for (o = r, n = i[r]; o && e(i[o - 1], n) > 0; )
      i[o] = i[--o];
    o !== r++ && (i[o] = n);
  }
  return i;
}, Yae = function(i, e, t, r) {
  for (var n = e.length, o = t.length, s = 0, a = 0; s < n || a < o; )
    i[s + a] = s < n && a < o ? r(e[s], t[a]) <= 0 ? e[s++] : t[a++] : s < n ? e[s++] : t[a++];
  return i;
}, qae = xu, Xae = ls, Gb = Xae.match(/firefox\/(\d+)/i), Jae = !!Gb && +Gb[1], Zae = ls, Qae = /MSIE|Trident/.test(Zae), ele = ls, Kb = ele.match(/AppleWebKit\/(\d+)\./), tle = !!Kb && +Kb[1], rle = H, CS = Q, ile = Hn, nle = Pt, Yb = Qt, ole = J_, qb = er, iv = Z, sle = qae, ale = Yn, Xb = Jae, lle = Qae, Jb = ds, Zb = tle, xr = [], Qb = CS(xr.sort), dle = CS(xr.push), hle = iv(function() {
  xr.sort(void 0);
}), cle = iv(function() {
  xr.sort(null);
}), ule = ale("sort"), AS = !iv(function() {
  if (Jb) return Jb < 70;
  if (!(Xb && Xb > 3)) {
    if (lle) return !0;
    if (Zb) return Zb < 603;
    var i = "", e, t, r, n;
    for (e = 65; e < 76; e++) {
      switch (t = String.fromCharCode(e), e) {
        case 66:
        case 69:
        case 70:
        case 72:
          r = 3;
          break;
        case 68:
        case 71:
          r = 4;
          break;
        default:
          r = 2;
      }
      for (n = 0; n < 47; n++)
        xr.push({ k: t + n, v: r });
    }
    for (xr.sort(function(o, s) {
      return s.v - o.v;
    }), n = 0; n < xr.length; n++)
      t = xr[n].k.charAt(0), i.charAt(i.length - 1) !== t && (i += t);
    return i !== "DGBEFHACIJK";
  }
}), fle = hle || !cle || !ule || !AS, vle = function(i) {
  return function(e, t) {
    return t === void 0 ? -1 : e === void 0 ? 1 : i !== void 0 ? +i(e, t) || 0 : qb(e) > qb(t) ? 1 : -1;
  };
};
rle({ target: "Array", proto: !0, forced: fle }, {
  sort: function(e) {
    e !== void 0 && ile(e);
    var t = nle(this);
    if (AS) return e === void 0 ? Qb(t) : Qb(t, e);
    var r = [], n = Yb(t), o, s;
    for (s = 0; s < n; s++)
      s in t && dle(r, t[s]);
    for (sle(r, vle(e)), o = Yb(r), s = 0; s < o; ) t[s] = r[s++];
    for (; s < n; ) ole(t, s++);
    return t;
  }
});
var ple = Ge, gle = ple("Array").sort, yle = ke, mle = gle, yc = Array.prototype, ble = function(i) {
  var e = i.sort;
  return i === yc || yle(yc, i) && e === yc.sort ? mle : e;
}, $le = ble, wle = $le, _le = wle, cn = /* @__PURE__ */ U(_le), Ele = Hn, Sle = Pt, Ole = jl, Tle = Qt, Ile = TypeError, Ple = function(i) {
  return function(e, t, r, n) {
    Ele(t);
    var o = Sle(e), s = Ole(o), a = Tle(o), l = i ? a - 1 : 0, d = i ? -1 : 1;
    if (r < 2) for (; ; ) {
      if (l in s) {
        n = s[l], l += d;
        break;
      }
      if (l += d, i ? l < 0 : a <= l)
        throw new Ile("Reduce of empty array with no initial value");
    }
    for (; i ? l >= 0 : a > l; l += d) l in s && (n = t(n, s[l], l, o));
    return n;
  };
}, xle = {
  // `Array.prototype.reduce` method
  // https://tc39.es/ecma262/#sec-array.prototype.reduce
  left: Ple(!1)
}, Cle = _e, Ale = mr, Mle = Ale(Cle.process) === "process", Dle = H, kle = xle.left, Nle = Yn, e$ = ds, Rle = Mle, Fle = !Rle && e$ > 79 && e$ < 83, Ble = Fle || !Nle("reduce");
Dle({ target: "Array", proto: !0, forced: Ble }, {
  reduce: function(e) {
    var t = arguments.length;
    return kle(this, e, t, t > 1 ? arguments[1] : void 0);
  }
});
var Lle = Ge, jle = Lle("Array").reduce, zle = ke, Wle = jle, mc = Array.prototype, Hle = function(i) {
  var e = i.reduce;
  return i === mc || zle(mc, i) && e === mc.reduce ? Wle : e;
}, Vle = Hle, Ule = Vle, Gle = Ule, MS = /* @__PURE__ */ U(Gle);
class DS {
  /**
   * @ignore
   */
  abstract() {
    throw new Error("Can't instantiate abstract class!");
  }
  /**
   * This is a dummy call which is used to suppress the jsdoc errors of type:
   *
   * "'param' is assigned a value but never used"
   * @ignore
   */
  fake_use() {
  }
  /**
   * Type to use to translate dynamic curves to, in the case of hierarchical layout.
   * Dynamic curves do not work for these.
   *
   * The value should be perpendicular to the actual direction of the layout.
   * @returns {string} Direction, either 'vertical' or 'horizontal'
   */
  curveType() {
    return this.abstract();
  }
  /**
   * Return the value of the coordinate that is not fixed for this direction.
   * @param {Node} node The node to read
   * @returns {number} Value of the unfixed coordinate
   */
  getPosition(e) {
    return this.fake_use(e), this.abstract();
  }
  /**
   * Set the value of the coordinate that is not fixed for this direction.
   * @param {Node} node The node to adjust
   * @param {number} position
   * @param {number} [level] if specified, the hierarchy level that this node should be fixed to
   */
  setPosition(e, t) {
    let r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : void 0;
    this.fake_use(e, t, r), this.abstract();
  }
  /**
   * Get the width of a tree.
   *
   * A `tree` here is a subset of nodes within the network which are not connected to other nodes,
   * only among themselves. In essence, it is a sub-network.
   * @param {number} index The index number of a tree
   * @returns {number} the width of a tree in the view coordinates
   */
  getTreeSize(e) {
    return this.fake_use(e), this.abstract();
  }
  /**
   * Sort array of nodes on the unfixed coordinates.
   *
   * Note:** chrome has non-stable sorting implementation, which
   * has a tendency to change the order of the array items,
   * even if the custom sort function returns 0.
   *
   * For this reason, an external sort implementation is used,
   * which has the added benefit of being faster than the standard
   * platforms implementation. This has been verified on `node.js`,
   * `firefox` and `chrome` (all linux).
   * @param {Array.<Node>} nodeArray array of nodes to sort
   */
  sort(e) {
    this.fake_use(e), this.abstract();
  }
  /**
   * Assign the fixed coordinate of the node to the given level
   * @param {Node} node The node to adjust
   * @param {number} level The level to fix to
   */
  fix(e, t) {
    this.fake_use(e, t), this.abstract();
  }
  /**
   * Add an offset to the unfixed coordinate of the given node.
   * @param {NodeId} nodeId Id of the node to adjust
   * @param {number} diff Offset to add to the unfixed coordinate
   */
  shift(e, t) {
    this.fake_use(e, t), this.abstract();
  }
}
class Kle extends DS {
  /**
   * Constructor
   * @param {object} layout reference to the parent LayoutEngine instance.
   */
  constructor(e) {
    super(), this.layout = e;
  }
  /** @inheritDoc */
  curveType() {
    return "horizontal";
  }
  /** @inheritDoc */
  getPosition(e) {
    return e.x;
  }
  /** @inheritDoc */
  setPosition(e, t) {
    let r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : void 0;
    r !== void 0 && this.layout.hierarchical.addToOrdering(e, r), e.x = t;
  }
  /** @inheritDoc */
  getTreeSize(e) {
    const t = this.layout.hierarchical.getTreeSize(this.layout.body.nodes, e);
    return {
      min: t.min_x,
      max: t.max_x
    };
  }
  /** @inheritDoc */
  sort(e) {
    cn(e).call(e, function(t, r) {
      return t.x - r.x;
    });
  }
  /** @inheritDoc */
  fix(e, t) {
    e.y = this.layout.options.hierarchical.levelSeparation * t, e.options.fixed.y = !0;
  }
  /** @inheritDoc */
  shift(e, t) {
    this.layout.body.nodes[e].x += t;
  }
}
class Yle extends DS {
  /**
   * Constructor
   * @param {object} layout reference to the parent LayoutEngine instance.
   */
  constructor(e) {
    super(), this.layout = e;
  }
  /** @inheritDoc */
  curveType() {
    return "vertical";
  }
  /** @inheritDoc */
  getPosition(e) {
    return e.y;
  }
  /** @inheritDoc */
  setPosition(e, t) {
    let r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : void 0;
    r !== void 0 && this.layout.hierarchical.addToOrdering(e, r), e.y = t;
  }
  /** @inheritDoc */
  getTreeSize(e) {
    const t = this.layout.hierarchical.getTreeSize(this.layout.body.nodes, e);
    return {
      min: t.min_y,
      max: t.max_y
    };
  }
  /** @inheritDoc */
  sort(e) {
    cn(e).call(e, function(t, r) {
      return t.y - r.y;
    });
  }
  /** @inheritDoc */
  fix(e, t) {
    e.x = this.layout.options.hierarchical.levelSeparation * t, e.options.fixed.x = !0;
  }
  /** @inheritDoc */
  shift(e, t) {
    this.layout.body.nodes[e].y += t;
  }
}
var qle = H, Xle = Kr.every, Jle = Yn, Zle = Jle("every");
qle({ target: "Array", proto: !0, forced: !Zle }, {
  every: function(e) {
    return Xle(this, e, arguments.length > 1 ? arguments[1] : void 0);
  }
});
var Qle = Ge, ede = Qle("Array").every, tde = ke, rde = ede, bc = Array.prototype, ide = function(i) {
  var e = i.every;
  return i === bc || tde(bc, i) && e === bc.every ? rde : e;
}, nde = ide, ode = nde, sde = ode, kS = /* @__PURE__ */ U(sde);
function ade(i, e) {
  const t = new Tr();
  return se(i).call(i, (r) => {
    var n;
    se(n = r.edges).call(n, (o) => {
      o.connected && t.add(o);
    });
  }), se(t).call(t, (r) => {
    const n = r.from.id, o = r.to.id;
    e[n] == null && (e[n] = 0), (e[o] == null || e[n] >= e[o]) && (e[o] = e[n] + 1);
  }), e;
}
function lde(i) {
  return NS(
    // Pick only leaves (nodes without children).
    (e) => {
      var t, r;
      return kS(
        t = ht(
          r = e.edges
          // Take only visible nodes into account.
        ).call(r, (n) => i.has(n.toId))
        // Check that all edges lead to this node (leaf).
      ).call(t, (n) => n.to === e);
    },
    // Use the lowest level.
    (e, t) => t > e,
    // Go against the direction of the edges.
    "from",
    i
  );
}
function dde(i) {
  return NS(
    // Pick only roots (nodes without parents).
    (e) => {
      var t, r;
      return kS(
        t = ht(
          r = e.edges
          // Take only visible nodes into account.
        ).call(r, (n) => i.has(n.toId))
        // Check that all edges lead from this node (root).
      ).call(t, (n) => n.from === e);
    },
    // Use the highest level.
    (e, t) => t < e,
    // Go in the direction of the edges.
    "to",
    i
  );
}
function NS(i, e, t, r) {
  var n;
  const o = ui(null), s = MS(n = [...yS(r).call(r)]).call(n, (c, u) => c + 1 + u.edges.length, 0), a = t + "Id", l = t === "to" ? 1 : -1;
  for (const [c, u] of r) {
    if (
      // Skip if the node is not visible.
      !r.has(c) || // Skip if the node is not an entry node.
      !i(u)
    )
      continue;
    o[c] = 0;
    const f = [u];
    let v = 0, y;
    for (; y = f.pop(); ) {
      var d, h;
      if (!r.has(c))
        continue;
      const g = o[y.id] + l;
      if (se(d = ht(h = y.edges).call(h, (p) => (
        // Ignore disconnected edges.
        p.connected && // Ignore circular edges.
        p.to !== p.from && // Ignore edges leading to the node that's currently being processed.
        p[t] !== y && // Ignore edges connecting to an invisible node.
        r.has(p.toId) && // Ignore edges connecting from an invisible node.
        r.has(p.fromId)
      ))).call(d, (p) => {
        const m = p[a], $ = o[m];
        ($ == null || e(g, $)) && (o[m] = g, f.push(p[t]));
      }), v > s)
        return ade(r, o);
      ++v;
    }
  }
  return o;
}
class hde {
  /**
   * @ignore
   */
  constructor() {
    this.childrenReference = {}, this.parentReference = {}, this.trees = {}, this.distributionOrdering = {}, this.levels = {}, this.distributionIndex = {}, this.isTree = !1, this.treeIndex = -1;
  }
  /**
   * Add the relation between given nodes to the current state.
   * @param {Node.id} parentNodeId
   * @param {Node.id} childNodeId
   */
  addRelation(e, t) {
    this.childrenReference[e] === void 0 && (this.childrenReference[e] = []), this.childrenReference[e].push(t), this.parentReference[t] === void 0 && (this.parentReference[t] = []), this.parentReference[t].push(e);
  }
  /**
   * Check if the current state is for a formal tree or formal forest.
   *
   * This is the case if every node has at most one parent.
   *
   * Pre: parentReference init'ed properly for current network
   */
  checkIfTree() {
    for (const e in this.parentReference)
      if (this.parentReference[e].length > 1) {
        this.isTree = !1;
        return;
      }
    this.isTree = !0;
  }
  /**
   * Return the number of separate trees in the current network.
   * @returns {number}
   */
  numTrees() {
    return this.treeIndex + 1;
  }
  /**
   * Assign a tree id to a node
   * @param {Node} node
   * @param {string|number} treeId
   */
  setTreeIndex(e, t) {
    t !== void 0 && this.trees[e.id] === void 0 && (this.trees[e.id] = t, this.treeIndex = Math.max(t, this.treeIndex));
  }
  /**
   * Ensure level for given id is defined.
   *
   * Sets level to zero for given node id if not already present
   * @param {Node.id} nodeId
   */
  ensureLevel(e) {
    this.levels[e] === void 0 && (this.levels[e] = 0);
  }
  /**
   * get the maximum level of a branch.
   *
   * TODO: Never entered; find a test case to test this!
   * @param {Node.id} nodeId
   * @returns {number}
   */
  getMaxLevel(e) {
    const t = {}, r = (n) => {
      if (t[n] !== void 0)
        return t[n];
      let o = this.levels[n];
      if (this.childrenReference[n]) {
        const s = this.childrenReference[n];
        if (s.length > 0)
          for (let a = 0; a < s.length; a++)
            o = Math.max(o, r(s[a]));
      }
      return t[n] = o, o;
    };
    return r(e);
  }
  /**
   *
   * @param {Node} nodeA
   * @param {Node} nodeB
   */
  levelDownstream(e, t) {
    this.levels[t.id] === void 0 && (this.levels[e.id] === void 0 && (this.levels[e.id] = 0), this.levels[t.id] = this.levels[e.id] + 1);
  }
  /**
   * Small util method to set the minimum levels of the nodes to zero and
   * eliminate gaps (for cyclic).
   */
  setMinLevelToZero() {
    var e;
    const t = new Zf();
    let r = 0;
    const n = cn(e = [...new Tr(GJ(this.levels))]).call(e, (o, s) => o - s);
    for (const o of n)
      t.set(o, r++);
    for (const o in this.levels)
      Object.prototype.hasOwnProperty.call(this.levels, o) && (this.levels[o] = t.get(this.levels[o]));
  }
  /**
   * Get the min and max xy-coordinates of a given tree
   * @param {Array.<Node>} nodes
   * @param {number} index
   * @returns {{min_x: number, max_x: number, min_y: number, max_y: number}}
   */
  getTreeSize(e, t) {
    let r = 1e9, n = -1e9, o = 1e9, s = -1e9;
    for (const a in this.trees)
      if (Object.prototype.hasOwnProperty.call(this.trees, a) && this.trees[a] === t) {
        const l = e[a];
        r = Math.min(l.x, r), n = Math.max(l.x, n), o = Math.min(l.y, o), s = Math.max(l.y, s);
      }
    return {
      min_x: r,
      max_x: n,
      min_y: o,
      max_y: s
    };
  }
  /**
   * Check if two nodes have the same parent(s)
   * @param {Node} node1
   * @param {Node} node2
   * @returns {boolean} true if the two nodes have a same ancestor node, false otherwise
   */
  hasSameParent(e, t) {
    const r = this.parentReference[e.id], n = this.parentReference[t.id];
    if (r === void 0 || n === void 0)
      return !1;
    for (let o = 0; o < r.length; o++)
      for (let s = 0; s < n.length; s++)
        if (r[o] == n[s])
          return !0;
    return !1;
  }
  /**
   * Check if two nodes are in the same tree.
   * @param {Node} node1
   * @param {Node} node2
   * @returns {boolean} true if this is so, false otherwise
   */
  inSameSubNetwork(e, t) {
    return this.trees[e.id] === this.trees[t.id];
  }
  /**
   * Get a list of the distinct levels in the current network
   * @returns {Array}
   */
  getLevels() {
    return me(this.distributionOrdering);
  }
  /**
   * Add a node to the ordering per level
   * @param {Node} node
   * @param {number} level
   */
  addToOrdering(e, t) {
    this.distributionOrdering[t] === void 0 && (this.distributionOrdering[t] = []);
    let r = !1;
    const n = this.distributionOrdering[t];
    for (const o in n)
      if (n[o] === e) {
        r = !0;
        break;
      }
    r || (this.distributionOrdering[t].push(e), this.distributionIndex[e.id] = this.distributionOrdering[t].length - 1);
  }
}
class cde {
  /**
   * @param {object} body
   */
  constructor(e) {
    this.body = e, this._resetRNG(Math.random() + ":" + Qa()), this.setPhysics = !1, this.options = {}, this.optionsBackup = {
      physics: {}
    }, this.defaultOptions = {
      randomSeed: void 0,
      improvedLayout: !0,
      clusterThreshold: 150,
      hierarchical: {
        enabled: !1,
        levelSeparation: 150,
        nodeSpacing: 100,
        treeSpacing: 200,
        blockShifting: !0,
        edgeMinimization: !0,
        parentCentralization: !0,
        direction: "UD",
        // UD, DU, LR, RL
        sortMethod: "hubsize"
        // hubsize, directed
      }
    }, Ce(this.options, this.defaultOptions), this.bindEventListeners();
  }
  /**
   * Binds event listeners
   */
  bindEventListeners() {
    this.body.emitter.on("_dataChanged", () => {
      this.setupHierarchicalLayout();
    }), this.body.emitter.on("_dataLoaded", () => {
      this.layoutNetwork();
    }), this.body.emitter.on("_resetHierarchicalLayout", () => {
      this.setupHierarchicalLayout();
    }), this.body.emitter.on("_adjustEdgesForHierarchicalLayout", () => {
      if (this.options.hierarchical.enabled !== !0)
        return;
      const e = this.direction.curveType();
      this.body.emitter.emit("_forceDisableDynamicCurves", e, !1);
    });
  }
  /**
   *
   * @param {object} options
   * @param {object} allOptions
   * @returns {object}
   */
  setOptions(e, t) {
    if (e !== void 0) {
      const r = this.options.hierarchical, n = r.enabled;
      if (Xn(["randomSeed", "improvedLayout", "clusterThreshold"], this.options, e), Et(this.options, e, "hierarchical"), e.randomSeed !== void 0 && this._resetRNG(e.randomSeed), r.enabled === !0)
        return n === !0 && this.body.emitter.emit("refresh", !0), r.direction === "RL" || r.direction === "DU" ? r.levelSeparation > 0 && (r.levelSeparation *= -1) : r.levelSeparation < 0 && (r.levelSeparation *= -1), this.setDirectionStrategy(), this.body.emitter.emit("_resetHierarchicalLayout"), this.adaptAllOptionsForHierarchicalLayout(t);
      if (n === !0)
        return this.body.emitter.emit("refresh"), le(t, this.optionsBackup);
    }
    return t;
  }
  /**
   * Reset the random number generator with given seed.
   * @param {any} seed - The seed that will be forwarded the the RNG.
   */
  _resetRNG(e) {
    this.initialRandomSeed = e, this._rng = nd(this.initialRandomSeed);
  }
  /**
   *
   * @param {object} allOptions
   * @returns {object}
   */
  adaptAllOptionsForHierarchicalLayout(e) {
    if (this.options.hierarchical.enabled === !0) {
      const t = this.optionsBackup.physics;
      e.physics === void 0 || e.physics === !0 ? (e.physics = {
        enabled: t.enabled === void 0 ? !0 : t.enabled,
        solver: "hierarchicalRepulsion"
      }, t.enabled = t.enabled === void 0 ? !0 : t.enabled, t.solver = t.solver || "barnesHut") : typeof e.physics == "object" ? (t.enabled = e.physics.enabled === void 0 ? !0 : e.physics.enabled, t.solver = e.physics.solver || "barnesHut", e.physics.solver = "hierarchicalRepulsion") : e.physics !== !1 && (t.solver = "barnesHut", e.physics = {
        solver: "hierarchicalRepulsion"
      });
      let r = this.direction.curveType();
      if (e.edges === void 0)
        this.optionsBackup.edges = {
          smooth: {
            enabled: !0,
            type: "dynamic"
          }
        }, e.edges = {
          smooth: !1
        };
      else if (e.edges.smooth === void 0)
        this.optionsBackup.edges = {
          smooth: {
            enabled: !0,
            type: "dynamic"
          }
        }, e.edges.smooth = !1;
      else if (typeof e.edges.smooth == "boolean")
        this.optionsBackup.edges = {
          smooth: e.edges.smooth
        }, e.edges.smooth = {
          enabled: e.edges.smooth,
          type: r
        };
      else {
        const n = e.edges.smooth;
        n.type !== void 0 && n.type !== "dynamic" && (r = n.type), this.optionsBackup.edges = {
          smooth: {
            enabled: n.enabled === void 0 ? !0 : n.enabled,
            type: n.type === void 0 ? "dynamic" : n.type,
            roundness: n.roundness === void 0 ? 0.5 : n.roundness,
            forceDirection: n.forceDirection === void 0 ? !1 : n.forceDirection
          }
        }, e.edges.smooth = {
          enabled: n.enabled === void 0 ? !0 : n.enabled,
          type: r,
          roundness: n.roundness === void 0 ? 0.5 : n.roundness,
          forceDirection: n.forceDirection === void 0 ? !1 : n.forceDirection
        };
      }
      this.body.emitter.emit("_forceDisableDynamicCurves", r);
    }
    return e;
  }
  /**
   *
   * @param {Array.<Node>} nodesArray
   */
  positionInitially(e) {
    if (this.options.hierarchical.enabled !== !0) {
      this._resetRNG(this.initialRandomSeed);
      const t = e.length + 50;
      for (let r = 0; r < e.length; r++) {
        const n = e[r], o = 2 * Math.PI * this._rng();
        n.x === void 0 && (n.x = t * Math.cos(o)), n.y === void 0 && (n.y = t * Math.sin(o));
      }
    }
  }
  /**
   * Use Kamada Kawai to position nodes. This is quite a heavy algorithm so if there are a lot of nodes we
   * cluster them first to reduce the amount.
   */
  layoutNetwork() {
    if (this.options.hierarchical.enabled !== !0 && this.options.improvedLayout === !0) {
      const e = this.body.nodeIndices;
      let t = 0;
      for (let r = 0; r < e.length; r++)
        this.body.nodes[e[r]].predefinedPosition === !0 && (t += 1);
      if (t < 0.5 * e.length) {
        let n = 0;
        const o = this.options.clusterThreshold, s = {
          clusterNodeProperties: {
            shape: "ellipse",
            // Bugfix: avoid type 'image', no images supplied
            label: "",
            // avoid label handling
            group: "",
            // avoid group handling
            font: {
              multi: !1
            }
            // avoid font propagation
          },
          clusterEdgeProperties: {
            label: "",
            // avoid label handling
            font: {
              multi: !1
            },
            // avoid font propagation
            smooth: {
              enabled: !1
              // avoid drawing penalty for complex edges
            }
          }
        };
        if (e.length > o) {
          const l = e.length;
          for (; e.length > o && n <= 10; ) {
            n += 1;
            const d = e.length;
            n % 3 === 0 ? this.body.modules.clustering.clusterBridges(s) : this.body.modules.clustering.clusterOutliers(s);
            const h = e.length;
            if (d == h && n % 3 !== 0) {
              this._declusterAll(), this.body.emitter.emit("_layoutFailed"), console.info("This network could not be positioned by this version of the improved layout algorithm. Please disable improvedLayout for better performance.");
              return;
            }
          }
          this.body.modules.kamadaKawai.setOptions({
            springLength: Math.max(150, 2 * l)
          });
        }
        n > 10 && console.info("The clustering didn't succeed within the amount of interations allowed, progressing with partial result."), this.body.modules.kamadaKawai.solve(e, this.body.edgeIndices, !0), this._shiftToCenter();
        const a = 70;
        for (let l = 0; l < e.length; l++) {
          const d = this.body.nodes[e[l]];
          d.predefinedPosition === !1 && (d.x += (0.5 - this._rng()) * a, d.y += (0.5 - this._rng()) * a);
        }
        this._declusterAll(), this.body.emitter.emit("_repositionBezierNodes");
      }
    }
  }
  /**
   * Move all the nodes towards to the center so gravitational pull wil not move the nodes away from view
   * @private
   */
  _shiftToCenter() {
    const e = Ze.getRangeCore(this.body.nodes, this.body.nodeIndices), t = Ze.findCenter(e);
    for (let r = 0; r < this.body.nodeIndices.length; r++) {
      const n = this.body.nodes[this.body.nodeIndices[r]];
      n.x -= t.x, n.y -= t.y;
    }
  }
  /**
   * Expands all clusters
   * @private
   */
  _declusterAll() {
    let e = !0;
    for (; e === !0; ) {
      e = !1;
      for (let t = 0; t < this.body.nodeIndices.length; t++)
        this.body.nodes[this.body.nodeIndices[t]].isCluster === !0 && (e = !0, this.body.modules.clustering.openCluster(this.body.nodeIndices[t], {}, !1));
      e === !0 && this.body.emitter.emit("_dataChanged");
    }
  }
  /**
   *
   * @returns {number|*}
   */
  getSeed() {
    return this.initialRandomSeed;
  }
  /**
   * This is the main function to layout the nodes in a hierarchical way.
   * It checks if the node details are supplied correctly
   * @private
   */
  setupHierarchicalLayout() {
    if (this.options.hierarchical.enabled === !0 && this.body.nodeIndices.length > 0) {
      let e, t, r = !1, n = !1;
      this.lastNodeOnLevel = {}, this.hierarchical = new hde();
      for (t in this.body.nodes)
        Object.prototype.hasOwnProperty.call(this.body.nodes, t) && (e = this.body.nodes[t], e.options.level !== void 0 ? (r = !0, this.hierarchical.levels[t] = e.options.level) : n = !0);
      if (n === !0 && r === !0)
        throw new Error("To use the hierarchical layout, nodes require either no predefined levels or levels have to be defined for all nodes.");
      {
        if (n === !0) {
          const s = this.options.hierarchical.sortMethod;
          s === "hubsize" ? this._determineLevelsByHubsize() : s === "directed" ? this._determineLevelsDirected() : s === "custom" && this._determineLevelsCustomCallback();
        }
        for (const s in this.body.nodes)
          Object.prototype.hasOwnProperty.call(this.body.nodes, s) && this.hierarchical.ensureLevel(s);
        const o = this._getDistribution();
        this._generateMap(), this._placeNodesByHierarchy(o), this._condenseHierarchy(), this._shiftToCenter();
      }
    }
  }
  /**
   * @private
   */
  _condenseHierarchy() {
    var e = this;
    let t = !1;
    const r = {}, n = () => {
      const p = s();
      let m = 0;
      for (let $ = 0; $ < p.length - 1; $++) {
        const w = p[$].max - p[$ + 1].min;
        m += w + this.options.hierarchical.treeSpacing, o($ + 1, m);
      }
    }, o = (p, m) => {
      const $ = this.hierarchical.trees;
      for (const w in $)
        Object.prototype.hasOwnProperty.call($, w) && $[w] === p && this.direction.shift(w, m);
    }, s = () => {
      const p = [];
      for (let m = 0; m < this.hierarchical.numTrees(); m++)
        p.push(this.direction.getTreeSize(m));
      return p;
    }, a = (p, m) => {
      if (!m[p.id] && (m[p.id] = !0, this.hierarchical.childrenReference[p.id])) {
        const $ = this.hierarchical.childrenReference[p.id];
        if ($.length > 0)
          for (let w = 0; w < $.length; w++)
            a(this.body.nodes[$[w]], m);
      }
    }, l = function(p) {
      let m = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 1e9, $ = 1e9, w = 1e9, T = 1e9, A = -1e9;
      for (const L in p)
        if (Object.prototype.hasOwnProperty.call(p, L)) {
          const G = e.body.nodes[L], ne = e.hierarchical.levels[G.id], oe = e.direction.getPosition(G), [Pe, pe] = e._getSpaceAroundNode(G, p);
          $ = Math.min(Pe, $), w = Math.min(pe, w), ne <= m && (T = Math.min(oe, T), A = Math.max(oe, A));
        }
      return [T, A, $, w];
    }, d = (p, m) => {
      const $ = this.hierarchical.getMaxLevel(p.id), w = this.hierarchical.getMaxLevel(m.id);
      return Math.min($, w);
    }, h = (p, m, $) => {
      const w = this.hierarchical;
      for (let T = 0; T < m.length; T++) {
        const A = m[T], L = w.distributionOrdering[A];
        if (L.length > 1)
          for (let G = 0; G < L.length - 1; G++) {
            const ne = L[G], oe = L[G + 1];
            w.hasSameParent(ne, oe) && w.inSameSubNetwork(ne, oe) && p(ne, oe, $);
          }
      }
    }, c = function(p, m) {
      let $ = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !1;
      const w = e.direction.getPosition(p), T = e.direction.getPosition(m), A = Math.abs(T - w), L = e.options.hierarchical.nodeSpacing;
      if (A > L) {
        const G = {}, ne = {};
        a(p, G), a(m, ne);
        const oe = d(p, m), Pe = l(G, oe), pe = l(ne, oe), ce = Pe[1], x = pe[0], j = pe[2];
        if (Math.abs(ce - x) > L) {
          let _ = ce - x + L;
          _ < -j + L && (_ = -j + L), _ < 0 && (e._shiftBlock(m.id, _), t = !0, $ === !0 && e._centerParent(m));
        }
      }
    }, u = (p, m) => {
      const $ = m.id, w = m.edges, T = this.hierarchical.levels[m.id], A = this.options.hierarchical.levelSeparation * this.options.hierarchical.levelSeparation, L = {}, G = [];
      for (let j = 0; j < w.length; j++) {
        const D = w[j];
        if (D.toId != D.fromId) {
          const _ = D.toId == $ ? D.from : D.to;
          L[w[j].id] = _, this.hierarchical.levels[_.id] < T && G.push(D);
        }
      }
      const ne = (j, D) => {
        let _ = 0;
        for (let R = 0; R < D.length; R++)
          if (L[D[R].id] !== void 0) {
            const W = this.direction.getPosition(L[D[R].id]) - j;
            _ += W / Math.sqrt(W * W + A);
          }
        return _;
      }, oe = (j, D) => {
        let _ = 0;
        for (let R = 0; R < D.length; R++)
          if (L[D[R].id] !== void 0) {
            const W = this.direction.getPosition(L[D[R].id]) - j;
            _ -= A * Math.pow(W * W + A, -1.5);
          }
        return _;
      }, Pe = (j, D) => {
        let _ = this.direction.getPosition(m);
        const R = {};
        for (let W = 0; W < j; W++) {
          const J = ne(_, D), te = oe(_, D), Se = 40, rt = Math.max(-Se, Math.min(Se, Math.round(J / te)));
          if (_ = _ - rt, R[_] !== void 0)
            break;
          R[_] = W;
        }
        return _;
      }, pe = (j) => {
        const D = this.direction.getPosition(m);
        if (r[m.id] === void 0) {
          const Se = {};
          a(m, Se), r[m.id] = Se;
        }
        const _ = l(r[m.id]), R = _[2], W = _[3], J = j - D;
        let te = 0;
        J > 0 ? te = Math.min(J, W - this.options.hierarchical.nodeSpacing) : J < 0 && (te = -Math.min(-J, R - this.options.hierarchical.nodeSpacing)), te != 0 && (this._shiftBlock(m.id, te), t = !0);
      }, ce = (j) => {
        const D = this.direction.getPosition(m), [_, R] = this._getSpaceAroundNode(m), W = j - D;
        let J = D;
        W > 0 ? J = Math.min(D + (R - this.options.hierarchical.nodeSpacing), j) : W < 0 && (J = Math.max(D - (_ - this.options.hierarchical.nodeSpacing), j)), J !== D && (this.direction.setPosition(m, J), t = !0);
      };
      let x = Pe(p, G);
      pe(x), x = Pe(p, w), ce(x);
    }, f = (p) => {
      let m = this.hierarchical.getLevels();
      m = ci(m).call(m);
      for (let $ = 0; $ < p; $++) {
        t = !1;
        for (let w = 0; w < m.length; w++) {
          const T = m[w], A = this.hierarchical.distributionOrdering[T];
          for (let L = 0; L < A.length; L++)
            u(1e3, A[L]);
        }
        if (t !== !0)
          break;
      }
    }, v = (p) => {
      let m = this.hierarchical.getLevels();
      m = ci(m).call(m);
      for (let $ = 0; $ < p && (t = !1, h(c, m, !0), t === !0); $++)
        ;
    }, y = () => {
      for (const p in this.body.nodes)
        Object.prototype.hasOwnProperty.call(this.body.nodes, p) && this._centerParent(this.body.nodes[p]);
    }, g = () => {
      let p = this.hierarchical.getLevels();
      p = ci(p).call(p);
      for (let m = 0; m < p.length; m++) {
        const $ = p[m], w = this.hierarchical.distributionOrdering[$];
        for (let T = 0; T < w.length; T++)
          this._centerParent(w[T]);
      }
    };
    this.options.hierarchical.blockShifting === !0 && (v(5), y()), this.options.hierarchical.edgeMinimization === !0 && f(20), this.options.hierarchical.parentCentralization === !0 && g(), n();
  }
  /**
   * This gives the space around the node. IF a map is supplied, it will only check against nodes NOT in the map.
   * This is used to only get the distances to nodes outside of a branch.
   * @param {Node} node
   * @param {{Node.id: vis.Node}} map
   * @returns {number[]}
   * @private
   */
  _getSpaceAroundNode(e, t) {
    let r = !0;
    t === void 0 && (r = !1);
    const n = this.hierarchical.levels[e.id];
    if (n !== void 0) {
      const o = this.hierarchical.distributionIndex[e.id], s = this.direction.getPosition(e), a = this.hierarchical.distributionOrdering[n];
      let l = 1e9, d = 1e9;
      if (o !== 0) {
        const h = a[o - 1];
        if (r === !0 && t[h.id] === void 0 || r === !1) {
          const c = this.direction.getPosition(h);
          l = s - c;
        }
      }
      if (o != a.length - 1) {
        const h = a[o + 1];
        if (r === !0 && t[h.id] === void 0 || r === !1) {
          const c = this.direction.getPosition(h);
          d = Math.min(d, c - s);
        }
      }
      return [l, d];
    } else
      return [0, 0];
  }
  /**
   * We use this method to center a parent node and check if it does not cross other nodes when it does.
   * @param {Node} node
   * @private
   */
  _centerParent(e) {
    if (this.hierarchical.parentReference[e.id]) {
      const t = this.hierarchical.parentReference[e.id];
      for (let r = 0; r < t.length; r++) {
        const n = t[r], o = this.body.nodes[n], s = this.hierarchical.childrenReference[n];
        if (s !== void 0) {
          const a = this._getCenterPosition(s), l = this.direction.getPosition(o), [d, h] = this._getSpaceAroundNode(o), c = l - a;
          (c < 0 && Math.abs(c) < h - this.options.hierarchical.nodeSpacing || c > 0 && Math.abs(c) < d - this.options.hierarchical.nodeSpacing) && this.direction.setPosition(o, a);
        }
      }
    }
  }
  /**
   * This function places the nodes on the canvas based on the hierarchial distribution.
   * @param {object} distribution | obtained by the function this._getDistribution()
   * @private
   */
  _placeNodesByHierarchy(e) {
    this.positionedNodes = {};
    for (const r in e)
      if (Object.prototype.hasOwnProperty.call(e, r)) {
        var t;
        let n = me(e[r]);
        n = this._indexArrayToNodes(n), cn(t = this.direction).call(t, n);
        let o = 0;
        for (let s = 0; s < n.length; s++) {
          const a = n[s];
          if (this.positionedNodes[a.id] === void 0) {
            const l = this.options.hierarchical.nodeSpacing;
            let d = l * o;
            o > 0 && (d = this.direction.getPosition(n[s - 1]) + l), this.direction.setPosition(a, d, r), this._validatePositionAndContinue(a, r, d), o++;
          }
        }
      }
  }
  /**
   * This is a recursively called function to enumerate the branches from the largest hubs and place the nodes
   * on a X position that ensures there will be no overlap.
   * @param {Node.id} parentId
   * @param {number} parentLevel
   * @private
   */
  _placeBranchNodes(e, t) {
    var r;
    const n = this.hierarchical.childrenReference[e];
    if (n === void 0)
      return;
    const o = [];
    for (let a = 0; a < n.length; a++)
      o.push(this.body.nodes[n[a]]);
    cn(r = this.direction).call(r, o);
    for (let a = 0; a < o.length; a++) {
      const l = o[a], d = this.hierarchical.levels[l.id];
      if (d > t && this.positionedNodes[l.id] === void 0) {
        const h = this.options.hierarchical.nodeSpacing;
        let c;
        a === 0 ? c = this.direction.getPosition(this.body.nodes[e]) : c = this.direction.getPosition(o[a - 1]) + h, this.direction.setPosition(l, c, d), this._validatePositionAndContinue(l, d, c);
      } else
        return;
    }
    const s = this._getCenterPosition(o);
    this.direction.setPosition(this.body.nodes[e], s, t);
  }
  /**
   * This method checks for overlap and if required shifts the branch. It also keeps records of positioned nodes.
   * Finally it will call _placeBranchNodes to place the branch nodes.
   * @param {Node} node
   * @param {number} level
   * @param {number} pos
   * @private
   */
  _validatePositionAndContinue(e, t, r) {
    if (this.hierarchical.isTree) {
      if (this.lastNodeOnLevel[t] !== void 0) {
        const n = this.direction.getPosition(this.body.nodes[this.lastNodeOnLevel[t]]);
        if (r - n < this.options.hierarchical.nodeSpacing) {
          const o = n + this.options.hierarchical.nodeSpacing - r, s = this._findCommonParent(this.lastNodeOnLevel[t], e.id);
          this._shiftBlock(s.withChild, o);
        }
      }
      this.lastNodeOnLevel[t] = e.id, this.positionedNodes[e.id] = !0, this._placeBranchNodes(e.id, t);
    }
  }
  /**
   * Receives an array with node indices and returns an array with the actual node references.
   * Used for sorting based on node properties.
   * @param {Array.<Node.id>} idArray
   * @returns {Array.<Node>}
   */
  _indexArrayToNodes(e) {
    const t = [];
    for (let r = 0; r < e.length; r++)
      t.push(this.body.nodes[e[r]]);
    return t;
  }
  /**
   * This function get the distribution of levels based on hubsize
   * @returns {object}
   * @private
   */
  _getDistribution() {
    const e = {};
    let t, r;
    for (t in this.body.nodes)
      if (Object.prototype.hasOwnProperty.call(this.body.nodes, t)) {
        r = this.body.nodes[t];
        const n = this.hierarchical.levels[t] === void 0 ? 0 : this.hierarchical.levels[t];
        this.direction.fix(r, n), e[n] === void 0 && (e[n] = {}), e[n][t] = r;
      }
    return e;
  }
  /**
   * Return the active (i.e. visible) edges for this node
   * @param {Node} node
   * @returns {Array.<vis.Edge>} Array of edge instances
   * @private
   */
  _getActiveEdges(e) {
    const t = [];
    return X(e.edges, (r) => {
      var n;
      re(n = this.body.edgeIndices).call(n, r.id) !== -1 && t.push(r);
    }), t;
  }
  /**
   * Get the hubsizes for all active nodes.
   * @returns {number}
   * @private
   */
  _getHubSizes() {
    const e = {}, t = this.body.nodeIndices;
    X(t, (n) => {
      const o = this.body.nodes[n], s = this._getActiveEdges(o).length;
      e[s] = !0;
    });
    const r = [];
    return X(e, (n) => {
      r.push(Number(n));
    }), cn(r).call(r, function(n, o) {
      return o - n;
    }), r;
  }
  /**
   * this function allocates nodes in levels based on the recursive branching from the largest hubs.
   * @private
   */
  _determineLevelsByHubsize() {
    const e = (r, n) => {
      this.hierarchical.levelDownstream(r, n);
    }, t = this._getHubSizes();
    for (let r = 0; r < t.length; ++r) {
      const n = t[r];
      if (n === 0) break;
      X(this.body.nodeIndices, (o) => {
        const s = this.body.nodes[o];
        n === this._getActiveEdges(s).length && this._crawlNetwork(e, o);
      });
    }
  }
  /**
   * TODO: release feature
   * TODO: Determine if this feature is needed at all
   * @private
   */
  _determineLevelsCustomCallback() {
    const t = function(n, o, s) {
    }, r = (n, o, s) => {
      let a = this.hierarchical.levels[n.id];
      a === void 0 && (a = this.hierarchical.levels[n.id] = 1e5);
      const l = t(Ze.cloneOptions(n, "node"), Ze.cloneOptions(o, "node"), Ze.cloneOptions(s, "edge"));
      this.hierarchical.levels[o.id] = a + l;
    };
    this._crawlNetwork(r), this.hierarchical.setMinLevelToZero();
  }
  /**
   * Allocate nodes in levels based on the direction of the edges.
   * @private
   */
  _determineLevelsDirected() {
    var e;
    const t = MS(e = this.body.nodeIndices).call(e, (r, n) => (r.set(n, this.body.nodes[n]), r), new Zf());
    this.options.hierarchical.shakeTowards === "roots" ? this.hierarchical.levels = dde(t) : this.hierarchical.levels = lde(t), this.hierarchical.setMinLevelToZero();
  }
  /**
   * Update the bookkeeping of parent and child.
   * @private
   */
  _generateMap() {
    const e = (t, r) => {
      this.hierarchical.levels[r.id] > this.hierarchical.levels[t.id] && this.hierarchical.addRelation(t.id, r.id);
    };
    this._crawlNetwork(e), this.hierarchical.checkIfTree();
  }
  /**
   * Crawl over the entire network and use a callback on each node couple that is connected to each other.
   * @param {Function} [callback]          | will receive nodeA, nodeB and the connecting edge. A and B are distinct.
   * @param {Node.id} startingNodeId
   * @private
   */
  _crawlNetwork() {
    let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : function() {
    }, t = arguments.length > 1 ? arguments[1] : void 0;
    const r = {}, n = (o, s) => {
      if (r[o.id] === void 0) {
        this.hierarchical.setTreeIndex(o, s), r[o.id] = !0;
        let a;
        const l = this._getActiveEdges(o);
        for (let d = 0; d < l.length; d++) {
          const h = l[d];
          h.connected === !0 && (h.toId == o.id ? a = h.from : a = h.to, o.id != a.id && (e(o, a, h), n(a, s)));
        }
      }
    };
    if (t === void 0) {
      let o = 0;
      for (let s = 0; s < this.body.nodeIndices.length; s++) {
        const a = this.body.nodeIndices[s];
        if (r[a] === void 0) {
          const l = this.body.nodes[a];
          n(l, o), o += 1;
        }
      }
    } else {
      const o = this.body.nodes[t];
      if (o === void 0) {
        console.error("Node not found:", t);
        return;
      }
      n(o);
    }
  }
  /**
   * Shift a branch a certain distance
   * @param {Node.id} parentId
   * @param {number} diff
   * @private
   */
  _shiftBlock(e, t) {
    const r = {}, n = (o) => {
      if (r[o])
        return;
      r[o] = !0, this.direction.shift(o, t);
      const s = this.hierarchical.childrenReference[o];
      if (s !== void 0)
        for (let a = 0; a < s.length; a++)
          n(s[a]);
    };
    n(e);
  }
  /**
   * Find a common parent between branches.
   * @param {Node.id} childA
   * @param {Node.id} childB
   * @returns {{foundParent, withChild}}
   * @private
   */
  _findCommonParent(e, t) {
    const r = {}, n = (s, a) => {
      const l = this.hierarchical.parentReference[a];
      if (l !== void 0)
        for (let d = 0; d < l.length; d++) {
          const h = l[d];
          s[h] = !0, n(s, h);
        }
    }, o = (s, a) => {
      const l = this.hierarchical.parentReference[a];
      if (l !== void 0)
        for (let d = 0; d < l.length; d++) {
          const h = l[d];
          if (s[h] !== void 0)
            return {
              foundParent: h,
              withChild: a
            };
          const c = o(s, h);
          if (c.foundParent !== null)
            return c;
        }
      return {
        foundParent: null,
        withChild: a
      };
    };
    return n(r, e), o(r, t);
  }
  /**
   * Set the strategy pattern for handling the coordinates given the current direction.
   *
   * The individual instances contain all the operations and data specific to a layout direction.
   * @param {Node} node
   * @param {{x: number, y: number}} position
   * @param {number} level
   * @param {boolean} [doNotUpdate]
   * @private
   */
  setDirectionStrategy() {
    this.options.hierarchical.direction === "UD" || this.options.hierarchical.direction === "DU" ? this.direction = new Kle(this) : this.direction = new Yle(this);
  }
  /**
   * Determine the center position of a branch from the passed list of child nodes
   *
   * This takes into account the positions of all the child nodes.
   * @param {Array.<Node|vis.Node.id>} childNodes  Array of either child nodes or node id's
   * @returns {number}
   * @private
   */
  _getCenterPosition(e) {
    let t = 1e9, r = -1e9;
    for (let n = 0; n < e.length; n++) {
      let o;
      if (e[n].id !== void 0)
        o = e[n];
      else {
        const a = e[n];
        o = this.body.nodes[a];
      }
      const s = this.direction.getPosition(o);
      t = Math.min(t, s), r = Math.max(r, s);
    }
    return 0.5 * (t + r);
  }
}
class ude {
  /**
   * @param {object} body
   * @param {Canvas} canvas
   * @param {SelectionHandler} selectionHandler
   * @param {InteractionHandler} interactionHandler
   */
  constructor(e, t, r, n) {
    var o, s;
    this.body = e, this.canvas = t, this.selectionHandler = r, this.interactionHandler = n, this.editMode = !1, this.manipulationDiv = void 0, this.editModeDiv = void 0, this.closeDiv = void 0, this._domEventListenerCleanupQueue = [], this.temporaryUIFunctions = {}, this.temporaryEventFunctions = [], this.touchTime = 0, this.temporaryIds = {
      nodes: [],
      edges: []
    }, this.guiEnabled = !1, this.inMode = !1, this.selectedControlNode = void 0, this.options = {}, this.defaultOptions = {
      enabled: !1,
      initiallyActive: !1,
      addNode: !0,
      addEdge: !0,
      editNode: void 0,
      editEdge: !0,
      deleteNode: !0,
      deleteEdge: !0,
      controlNodeStyle: {
        shape: "dot",
        size: 6,
        color: {
          background: "#ff0000",
          border: "#3c3c3c",
          highlight: {
            background: "#07f968",
            border: "#3c3c3c"
          }
        },
        borderWidth: 2,
        borderWidthSelected: 2
      }
    }, Ce(this.options, this.defaultOptions), this.body.emitter.on("destroy", () => {
      this._clean();
    }), this.body.emitter.on("_dataChanged", S(o = this._restore).call(o, this)), this.body.emitter.on("_resetData", S(s = this._restore).call(s, this));
  }
  /**
   * If something changes in the data during editing, switch back to the initial datamanipulation state and close all edit modes.
   * @private
   */
  _restore() {
    this.inMode !== !1 && (this.options.initiallyActive === !0 ? this.enableEditMode() : this.disableEditMode());
  }
  /**
   * Set the Options
   * @param {object} options
   * @param {object} allOptions
   * @param {object} globalOptions
   */
  setOptions(e, t, r) {
    t !== void 0 && (t.locale !== void 0 ? this.options.locale = t.locale : this.options.locale = r.locale, t.locales !== void 0 ? this.options.locales = t.locales : this.options.locales = r.locales), e !== void 0 && (typeof e == "boolean" ? this.options.enabled = e : (this.options.enabled = !0, le(this.options, e)), this.options.initiallyActive === !0 && (this.editMode = !0), this._setup());
  }
  /**
   * Enable or disable edit-mode. Draws the DOM required and cleans up after itself.
   * @private
   */
  toggleEditMode() {
    this.editMode === !0 ? this.disableEditMode() : this.enableEditMode();
  }
  /**
   * Enables Edit Mode
   */
  enableEditMode() {
    this.editMode = !0, this._clean(), this.guiEnabled === !0 && (this.manipulationDiv.style.display = "block", this.closeDiv.style.display = "block", this.editModeDiv.style.display = "none", this.showManipulatorToolbar());
  }
  /**
   * Disables Edit Mode
   */
  disableEditMode() {
    this.editMode = !1, this._clean(), this.guiEnabled === !0 && (this.manipulationDiv.style.display = "none", this.closeDiv.style.display = "none", this.editModeDiv.style.display = "block", this._createEditButton());
  }
  /**
   * Creates the main toolbar. Removes functions bound to the select event. Binds all the buttons of the toolbar.
   * @private
   */
  showManipulatorToolbar() {
    if (this._clean(), this.manipulationDOM = {}, this.guiEnabled === !0) {
      var e, t;
      this.editMode = !0, this.manipulationDiv.style.display = "block", this.closeDiv.style.display = "block";
      const r = this.selectionHandler.getSelectedNodeCount(), n = this.selectionHandler.getSelectedEdgeCount(), o = r + n, s = this.options.locales[this.options.locale];
      let a = !1;
      this.options.addNode !== !1 && (this._createAddNodeButton(s), a = !0), this.options.addEdge !== !1 && (a === !0 ? this._createSeperator(1) : a = !0, this._createAddEdgeButton(s)), r === 1 && typeof this.options.editNode == "function" ? (a === !0 ? this._createSeperator(2) : a = !0, this._createEditNodeButton(s)) : n === 1 && r === 0 && this.options.editEdge !== !1 && (a === !0 ? this._createSeperator(3) : a = !0, this._createEditEdgeButton(s)), o !== 0 && (r > 0 && this.options.deleteNode !== !1 ? (a === !0 && this._createSeperator(4), this._createDeleteButton(s)) : r === 0 && this.options.deleteEdge !== !1 && (a === !0 && this._createSeperator(4), this._createDeleteButton(s))), this._bindElementEvents(this.closeDiv, S(e = this.toggleEditMode).call(e, this)), this._temporaryBindEvent("select", S(t = this.showManipulatorToolbar).call(t, this));
    }
    this.body.emitter.emit("_redraw");
  }
  /**
   * Create the toolbar for adding Nodes
   */
  addNodeMode() {
    var e;
    if (this.editMode !== !0 && this.enableEditMode(), this._clean(), this.inMode = "addNode", this.guiEnabled === !0) {
      var t;
      const r = this.options.locales[this.options.locale];
      this.manipulationDOM = {}, this._createBackButton(r), this._createSeperator(), this._createDescription(r.addDescription || this.options.locales.en.addDescription), this._bindElementEvents(this.closeDiv, S(t = this.toggleEditMode).call(t, this));
    }
    this._temporaryBindEvent("click", S(e = this._performAddNode).call(e, this));
  }
  /**
   * call the bound function to handle the editing of the node. The node has to be selected.
   */
  editNode() {
    this.editMode !== !0 && this.enableEditMode(), this._clean();
    const e = this.selectionHandler.getSelectedNodes()[0];
    if (e !== void 0)
      if (this.inMode = "editNode", typeof this.options.editNode == "function")
        if (e.isCluster !== !0) {
          const t = le({}, e.options, !1);
          if (t.x = e.x, t.y = e.y, this.options.editNode.length === 2)
            this.options.editNode(t, (r) => {
              r != null && this.inMode === "editNode" && this.body.data.nodes.getDataSet().update(r), this.showManipulatorToolbar();
            });
          else
            throw new Error("The function for edit does not support two arguments (data, callback)");
        } else
          alert(this.options.locales[this.options.locale].editClusterError || this.options.locales.en.editClusterError);
      else
        throw new Error("No function has been configured to handle the editing of nodes.");
    else
      this.showManipulatorToolbar();
  }
  /**
   * create the toolbar to connect nodes
   */
  addEdgeMode() {
    var e, t, r, n, o;
    if (this.editMode !== !0 && this.enableEditMode(), this._clean(), this.inMode = "addEdge", this.guiEnabled === !0) {
      var s;
      const a = this.options.locales[this.options.locale];
      this.manipulationDOM = {}, this._createBackButton(a), this._createSeperator(), this._createDescription(a.edgeDescription || this.options.locales.en.edgeDescription), this._bindElementEvents(this.closeDiv, S(s = this.toggleEditMode).call(s, this));
    }
    this._temporaryBindUI("onTouch", S(e = this._handleConnect).call(e, this)), this._temporaryBindUI("onDragEnd", S(t = this._finishConnect).call(t, this)), this._temporaryBindUI("onDrag", S(r = this._dragControlNode).call(r, this)), this._temporaryBindUI("onRelease", S(n = this._finishConnect).call(n, this)), this._temporaryBindUI("onDragStart", S(o = this._dragStartEdge).call(o, this)), this._temporaryBindUI("onHold", () => {
    });
  }
  /**
   * create the toolbar to edit edges
   */
  editEdgeMode() {
    if (this.editMode !== !0 && this.enableEditMode(), this._clean(), this.inMode = "editEdge", typeof this.options.editEdge == "object" && typeof this.options.editEdge.editWithoutDrag == "function" && (this.edgeBeingEditedId = this.selectionHandler.getSelectedEdgeIds()[0], this.edgeBeingEditedId !== void 0)) {
      const s = this.body.edges[this.edgeBeingEditedId];
      this._performEditEdge(s.from.id, s.to.id);
      return;
    }
    if (this.guiEnabled === !0) {
      var e;
      const s = this.options.locales[this.options.locale];
      this.manipulationDOM = {}, this._createBackButton(s), this._createSeperator(), this._createDescription(s.editEdgeDescription || this.options.locales.en.editEdgeDescription), this._bindElementEvents(this.closeDiv, S(e = this.toggleEditMode).call(e, this));
    }
    if (this.edgeBeingEditedId = this.selectionHandler.getSelectedEdgeIds()[0], this.edgeBeingEditedId !== void 0) {
      var t, r, n, o;
      const s = this.body.edges[this.edgeBeingEditedId], a = this._getNewTargetNode(s.from.x, s.from.y), l = this._getNewTargetNode(s.to.x, s.to.y);
      this.temporaryIds.nodes.push(a.id), this.temporaryIds.nodes.push(l.id), this.body.nodes[a.id] = a, this.body.nodeIndices.push(a.id), this.body.nodes[l.id] = l, this.body.nodeIndices.push(l.id), this._temporaryBindUI("onTouch", S(t = this._controlNodeTouch).call(t, this)), this._temporaryBindUI("onTap", () => {
      }), this._temporaryBindUI("onHold", () => {
      }), this._temporaryBindUI("onDragStart", S(r = this._controlNodeDragStart).call(r, this)), this._temporaryBindUI("onDrag", S(n = this._controlNodeDrag).call(n, this)), this._temporaryBindUI("onDragEnd", S(o = this._controlNodeDragEnd).call(o, this)), this._temporaryBindUI("onMouseMove", () => {
      }), this._temporaryBindEvent("beforeDrawing", (d) => {
        const h = s.edgeType.findBorderPositions(d);
        a.selected === !1 && (a.x = h.from.x, a.y = h.from.y), l.selected === !1 && (l.x = h.to.x, l.y = h.to.y);
      }), this.body.emitter.emit("_redraw");
    } else
      this.showManipulatorToolbar();
  }
  /**
   * delete everything in the selection
   */
  deleteSelected() {
    this.editMode !== !0 && this.enableEditMode(), this._clean(), this.inMode = "delete";
    const e = this.selectionHandler.getSelectedNodeIds(), t = this.selectionHandler.getSelectedEdgeIds();
    let r;
    if (e.length > 0) {
      for (let n = 0; n < e.length; n++)
        if (this.body.nodes[e[n]].isCluster === !0) {
          alert(this.options.locales[this.options.locale].deleteClusterError || this.options.locales.en.deleteClusterError);
          return;
        }
      typeof this.options.deleteNode == "function" && (r = this.options.deleteNode);
    } else t.length > 0 && typeof this.options.deleteEdge == "function" && (r = this.options.deleteEdge);
    if (typeof r == "function") {
      const n = {
        nodes: e,
        edges: t
      };
      if (r.length === 2)
        r(n, (o) => {
          o != null && this.inMode === "delete" ? (this.body.data.edges.getDataSet().remove(o.edges), this.body.data.nodes.getDataSet().remove(o.nodes), this.body.emitter.emit("startSimulation"), this.showManipulatorToolbar()) : (this.body.emitter.emit("startSimulation"), this.showManipulatorToolbar());
        });
      else
        throw new Error("The function for delete does not support two arguments (data, callback)");
    } else
      this.body.data.edges.getDataSet().remove(t), this.body.data.nodes.getDataSet().remove(e), this.body.emitter.emit("startSimulation"), this.showManipulatorToolbar();
  }
  //********************************************** PRIVATE ***************************************//
  /**
   * draw or remove the DOM
   * @private
   */
  _setup() {
    this.options.enabled === !0 ? (this.guiEnabled = !0, this._createWrappers(), this.editMode === !1 ? this._createEditButton() : this.showManipulatorToolbar()) : (this._removeManipulationDOM(), this.guiEnabled = !1);
  }
  /**
   * create the div overlays that contain the DOM
   * @private
   */
  _createWrappers() {
    if (this.manipulationDiv === void 0 && (this.manipulationDiv = document.createElement("div"), this.manipulationDiv.className = "vis-manipulation", this.editMode === !0 ? this.manipulationDiv.style.display = "block" : this.manipulationDiv.style.display = "none", this.canvas.frame.appendChild(this.manipulationDiv)), this.editModeDiv === void 0 && (this.editModeDiv = document.createElement("div"), this.editModeDiv.className = "vis-edit-mode", this.editMode === !0 ? this.editModeDiv.style.display = "none" : this.editModeDiv.style.display = "block", this.canvas.frame.appendChild(this.editModeDiv)), this.closeDiv === void 0) {
      var e, t;
      this.closeDiv = document.createElement("button"), this.closeDiv.className = "vis-close", this.closeDiv.setAttribute("aria-label", (e = (t = this.options.locales[this.options.locale]) === null || t === void 0 ? void 0 : t.close) !== null && e !== void 0 ? e : this.options.locales.en.close), this.closeDiv.style.display = this.manipulationDiv.style.display, this.canvas.frame.appendChild(this.closeDiv);
    }
  }
  /**
   * generate a new target node. Used for creating new edges and editing edges
   * @param {number} x
   * @param {number} y
   * @returns {Node}
   * @private
   */
  _getNewTargetNode(e, t) {
    const r = le({}, this.options.controlNodeStyle);
    r.id = "targetNode" + yo(), r.hidden = !1, r.physics = !1, r.x = e, r.y = t;
    const n = this.body.functions.createNode(r);
    return n.shape.boundingBox = {
      left: e,
      right: e,
      top: t,
      bottom: t
    }, n;
  }
  /**
   * Create the edit button
   */
  _createEditButton() {
    var e;
    this._clean(), this.manipulationDOM = {}, Sr(this.editModeDiv);
    const t = this.options.locales[this.options.locale], r = this._createButton("editMode", "vis-edit vis-edit-mode", t.edit || this.options.locales.en.edit);
    this.editModeDiv.appendChild(r), this._bindElementEvents(r, S(e = this.toggleEditMode).call(e, this));
  }
  /**
   * this function cleans up after everything this module does. Temporary elements, functions and events are removed, physics restored, hammers removed.
   * @private
   */
  _clean() {
    this.inMode = !1, this.guiEnabled === !0 && (Sr(this.editModeDiv), Sr(this.manipulationDiv), this._cleanupDOMEventListeners()), this._cleanupTemporaryNodesAndEdges(), this._unbindTemporaryUIs(), this._unbindTemporaryEvents(), this.body.emitter.emit("restorePhysics");
  }
  /**
   * Each dom element has it's own hammer. They are stored in this.manipulationHammers. This cleans them up.
   * @private
   */
  _cleanupDOMEventListeners() {
    for (const t of ar(e = this._domEventListenerCleanupQueue).call(e, 0)) {
      var e;
      t();
    }
  }
  /**
   * Remove all DOM elements created by this module.
   * @private
   */
  _removeManipulationDOM() {
    this._clean(), Sr(this.manipulationDiv), Sr(this.editModeDiv), Sr(this.closeDiv), this.manipulationDiv && this.canvas.frame.removeChild(this.manipulationDiv), this.editModeDiv && this.canvas.frame.removeChild(this.editModeDiv), this.closeDiv && this.canvas.frame.removeChild(this.closeDiv), this.manipulationDiv = void 0, this.editModeDiv = void 0, this.closeDiv = void 0;
  }
  /**
   * create a seperator line. the index is to differentiate in the manipulation dom
   * @param {number} [index]
   * @private
   */
  _createSeperator() {
    let e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 1;
    this.manipulationDOM["seperatorLineDiv" + e] = document.createElement("div"), this.manipulationDOM["seperatorLineDiv" + e].className = "vis-separator-line", this.manipulationDiv.appendChild(this.manipulationDOM["seperatorLineDiv" + e]);
  }
  // ----------------------    DOM functions for buttons    --------------------------//
  /**
   *
   * @param {Locale} locale
   * @private
   */
  _createAddNodeButton(e) {
    var t;
    const r = this._createButton("addNode", "vis-add", e.addNode || this.options.locales.en.addNode);
    this.manipulationDiv.appendChild(r), this._bindElementEvents(r, S(t = this.addNodeMode).call(t, this));
  }
  /**
   *
   * @param {Locale} locale
   * @private
   */
  _createAddEdgeButton(e) {
    var t;
    const r = this._createButton("addEdge", "vis-connect", e.addEdge || this.options.locales.en.addEdge);
    this.manipulationDiv.appendChild(r), this._bindElementEvents(r, S(t = this.addEdgeMode).call(t, this));
  }
  /**
   *
   * @param {Locale} locale
   * @private
   */
  _createEditNodeButton(e) {
    var t;
    const r = this._createButton("editNode", "vis-edit", e.editNode || this.options.locales.en.editNode);
    this.manipulationDiv.appendChild(r), this._bindElementEvents(r, S(t = this.editNode).call(t, this));
  }
  /**
   *
   * @param {Locale} locale
   * @private
   */
  _createEditEdgeButton(e) {
    var t;
    const r = this._createButton("editEdge", "vis-edit", e.editEdge || this.options.locales.en.editEdge);
    this.manipulationDiv.appendChild(r), this._bindElementEvents(r, S(t = this.editEdgeMode).call(t, this));
  }
  /**
   *
   * @param {Locale} locale
   * @private
   */
  _createDeleteButton(e) {
    var t;
    let r;
    this.options.rtl ? r = "vis-delete-rtl" : r = "vis-delete";
    const n = this._createButton("delete", r, e.del || this.options.locales.en.del);
    this.manipulationDiv.appendChild(n), this._bindElementEvents(n, S(t = this.deleteSelected).call(t, this));
  }
  /**
   *
   * @param {Locale} locale
   * @private
   */
  _createBackButton(e) {
    var t;
    const r = this._createButton("back", "vis-back", e.back || this.options.locales.en.back);
    this.manipulationDiv.appendChild(r), this._bindElementEvents(r, S(t = this.showManipulatorToolbar).call(t, this));
  }
  /**
   *
   * @param {number|string} id
   * @param {string} className
   * @param {label} label
   * @param {string} labelClassName
   * @returns {HTMLElement}
   * @private
   */
  _createButton(e, t, r) {
    let n = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : "vis-label";
    return this.manipulationDOM[e + "Div"] = document.createElement("button"), this.manipulationDOM[e + "Div"].className = "vis-button " + t, this.manipulationDOM[e + "Label"] = document.createElement("div"), this.manipulationDOM[e + "Label"].className = n, this.manipulationDOM[e + "Label"].innerText = r, this.manipulationDOM[e + "Div"].appendChild(this.manipulationDOM[e + "Label"]), this.manipulationDOM[e + "Div"];
  }
  /**
   *
   * @param {Label} label
   * @private
   */
  _createDescription(e) {
    this.manipulationDOM.descriptionLabel = document.createElement("div"), this.manipulationDOM.descriptionLabel.className = "vis-none", this.manipulationDOM.descriptionLabel.innerText = e, this.manipulationDiv.appendChild(this.manipulationDOM.descriptionLabel);
  }
  // -------------------------- End of DOM functions for buttons ------------------------------//
  /**
   * this binds an event until cleanup by the clean functions.
   * @param {Event}  event   The event
   * @param {Function} newFunction
   * @private
   */
  _temporaryBindEvent(e, t) {
    this.temporaryEventFunctions.push({
      event: e,
      boundFunction: t
    }), this.body.emitter.on(e, t);
  }
  /**
   * this overrides an UI function until cleanup by the clean function
   * @param {string} UIfunctionName
   * @param {Function} newFunction
   * @private
   */
  _temporaryBindUI(e, t) {
    if (this.body.eventListeners[e] !== void 0)
      this.temporaryUIFunctions[e] = this.body.eventListeners[e], this.body.eventListeners[e] = t;
    else
      throw new Error("This UI function does not exist. Typo? You tried: " + e + " possible are: " + Os(me(this.body.eventListeners)));
  }
  /**
   * Restore the overridden UI functions to their original state.
   * @private
   */
  _unbindTemporaryUIs() {
    for (const e in this.temporaryUIFunctions)
      Object.prototype.hasOwnProperty.call(this.temporaryUIFunctions, e) && (this.body.eventListeners[e] = this.temporaryUIFunctions[e], delete this.temporaryUIFunctions[e]);
    this.temporaryUIFunctions = {};
  }
  /**
   * Unbind the events created by _temporaryBindEvent
   * @private
   */
  _unbindTemporaryEvents() {
    for (let e = 0; e < this.temporaryEventFunctions.length; e++) {
      const t = this.temporaryEventFunctions[e].event, r = this.temporaryEventFunctions[e].boundFunction;
      this.body.emitter.off(t, r);
    }
    this.temporaryEventFunctions = [];
  }
  /**
   * Bind an hammer instance to a DOM element.
   * @param {Element} domElement
   * @param {Function} boundFunction
   */
  _bindElementEvents(e, t) {
    const r = new dn(e, {});
    ll(r, t), this._domEventListenerCleanupQueue.push(() => {
      r.destroy();
    });
    const n = (o) => {
      let {
        keyCode: s,
        key: a
      } = o;
      (a === "Enter" || a === " " || s === 13 || s === 32) && t();
    };
    e.addEventListener("keyup", n, !1), this._domEventListenerCleanupQueue.push(() => {
      e.removeEventListener("keyup", n, !1);
    });
  }
  /**
   * Neatly clean up temporary edges and nodes
   * @private
   */
  _cleanupTemporaryNodesAndEdges() {
    for (let o = 0; o < this.temporaryIds.edges.length; o++) {
      var e;
      this.body.edges[this.temporaryIds.edges[o]].disconnect(), delete this.body.edges[this.temporaryIds.edges[o]];
      const s = re(e = this.body.edgeIndices).call(e, this.temporaryIds.edges[o]);
      if (s !== -1) {
        var t;
        ar(t = this.body.edgeIndices).call(t, s, 1);
      }
    }
    for (let o = 0; o < this.temporaryIds.nodes.length; o++) {
      var r;
      delete this.body.nodes[this.temporaryIds.nodes[o]];
      const s = re(r = this.body.nodeIndices).call(r, this.temporaryIds.nodes[o]);
      if (s !== -1) {
        var n;
        ar(n = this.body.nodeIndices).call(n, s, 1);
      }
    }
    this.temporaryIds = {
      nodes: [],
      edges: []
    };
  }
  // ------------------------------------------ EDIT EDGE FUNCTIONS -----------------------------------------//
  /**
   * the touch is used to get the position of the initial click
   * @param {Event}  event   The event
   * @private
   */
  _controlNodeTouch(e) {
    this.selectionHandler.unselectAll(), this.lastTouch = this.body.functions.getPointer(e.center), this.lastTouch.translation = Ce({}, this.body.view.translation);
  }
  /**
   * the drag start is used to mark one of the control nodes as selected.
   * @private
   */
  _controlNodeDragStart() {
    const e = this.lastTouch, t = this.selectionHandler._pointerToPositionObject(e), r = this.body.nodes[this.temporaryIds.nodes[0]], n = this.body.nodes[this.temporaryIds.nodes[1]], o = this.body.edges[this.edgeBeingEditedId];
    this.selectedControlNode = void 0;
    const s = r.isOverlappingWith(t), a = n.isOverlappingWith(t);
    s === !0 ? (this.selectedControlNode = r, o.edgeType.from = r) : a === !0 && (this.selectedControlNode = n, o.edgeType.to = n), this.selectedControlNode !== void 0 && this.selectionHandler.selectObject(this.selectedControlNode), this.body.emitter.emit("_redraw");
  }
  /**
   * dragging the control nodes or the canvas
   * @param {Event}  event   The event
   * @private
   */
  _controlNodeDrag(e) {
    this.body.emitter.emit("disablePhysics");
    const t = this.body.functions.getPointer(e.center), r = this.canvas.DOMtoCanvas(t);
    this.selectedControlNode !== void 0 ? (this.selectedControlNode.x = r.x, this.selectedControlNode.y = r.y) : this.interactionHandler.onDrag(e), this.body.emitter.emit("_redraw");
  }
  /**
   * connecting or restoring the control nodes.
   * @param {Event}  event   The event
   * @private
   */
  _controlNodeDragEnd(e) {
    const t = this.body.functions.getPointer(e.center), r = this.selectionHandler._pointerToPositionObject(t), n = this.body.edges[this.edgeBeingEditedId];
    if (this.selectedControlNode === void 0)
      return;
    this.selectionHandler.unselectAll();
    const o = this.selectionHandler._getAllNodesOverlappingWith(r);
    let s;
    for (let a = o.length - 1; a >= 0; a--)
      if (o[a] !== this.selectedControlNode.id) {
        s = this.body.nodes[o[a]];
        break;
      }
    if (s !== void 0 && this.selectedControlNode !== void 0)
      if (s.isCluster === !0)
        alert(this.options.locales[this.options.locale].createEdgeError || this.options.locales.en.createEdgeError);
      else {
        const a = this.body.nodes[this.temporaryIds.nodes[0]];
        this.selectedControlNode.id === a.id ? this._performEditEdge(s.id, n.to.id) : this._performEditEdge(n.from.id, s.id);
      }
    else
      n.updateEdgeType(), this.body.emitter.emit("restorePhysics");
    this.body.emitter.emit("_redraw");
  }
  // ------------------------------------ END OF EDIT EDGE FUNCTIONS -----------------------------------------//
  // ------------------------------------------- ADD EDGE FUNCTIONS -----------------------------------------//
  /**
   * the function bound to the selection event. It checks if you want to connect a cluster and changes the description
   * to walk the user through the process.
   * @param {Event} event
   * @private
   */
  _handleConnect(e) {
    if ((/* @__PURE__ */ new Date()).valueOf() - this.touchTime > 100) {
      this.lastTouch = this.body.functions.getPointer(e.center), this.lastTouch.translation = Ce({}, this.body.view.translation), this.interactionHandler.drag.pointer = this.lastTouch, this.interactionHandler.drag.translation = this.lastTouch.translation;
      const t = this.lastTouch, r = this.selectionHandler.getNodeAt(t);
      if (r !== void 0)
        if (r.isCluster === !0)
          alert(this.options.locales[this.options.locale].createEdgeError || this.options.locales.en.createEdgeError);
        else {
          const n = this._getNewTargetNode(r.x, r.y);
          this.body.nodes[n.id] = n, this.body.nodeIndices.push(n.id);
          const o = this.body.functions.createEdge({
            id: "connectionEdge" + yo(),
            from: r.id,
            to: n.id,
            physics: !1,
            smooth: {
              enabled: !0,
              type: "continuous",
              roundness: 0.5
            }
          });
          this.body.edges[o.id] = o, this.body.edgeIndices.push(o.id), this.temporaryIds.nodes.push(n.id), this.temporaryIds.edges.push(o.id);
        }
      this.touchTime = (/* @__PURE__ */ new Date()).valueOf();
    }
  }
  /**
   *
   * @param {Event} event
   * @private
   */
  _dragControlNode(e) {
    const t = this.body.functions.getPointer(e.center), r = this.selectionHandler._pointerToPositionObject(t);
    let n;
    this.temporaryIds.edges[0] !== void 0 && (n = this.body.edges[this.temporaryIds.edges[0]].fromId);
    const o = this.selectionHandler._getAllNodesOverlappingWith(r);
    let s;
    for (let l = o.length - 1; l >= 0; l--) {
      var a;
      if (re(a = this.temporaryIds.nodes).call(a, o[l]) === -1) {
        s = this.body.nodes[o[l]];
        break;
      }
    }
    if (e.controlEdge = {
      from: n,
      to: s ? s.id : void 0
    }, this.selectionHandler.generateClickEvent("controlNodeDragging", e, t), this.temporaryIds.nodes[0] !== void 0) {
      const l = this.body.nodes[this.temporaryIds.nodes[0]];
      l.x = this.canvas._XconvertDOMtoCanvas(t.x), l.y = this.canvas._YconvertDOMtoCanvas(t.y), this.body.emitter.emit("_redraw");
    } else
      this.interactionHandler.onDrag(e);
  }
  /**
   * Connect the new edge to the target if one exists, otherwise remove temp line
   * @param {Event}  event   The event
   * @private
   */
  _finishConnect(e) {
    const t = this.body.functions.getPointer(e.center), r = this.selectionHandler._pointerToPositionObject(t);
    let n;
    this.temporaryIds.edges[0] !== void 0 && (n = this.body.edges[this.temporaryIds.edges[0]].fromId);
    const o = this.selectionHandler._getAllNodesOverlappingWith(r);
    let s;
    for (let l = o.length - 1; l >= 0; l--) {
      var a;
      if (re(a = this.temporaryIds.nodes).call(a, o[l]) === -1) {
        s = this.body.nodes[o[l]];
        break;
      }
    }
    this._cleanupTemporaryNodesAndEdges(), s !== void 0 && (s.isCluster === !0 ? alert(this.options.locales[this.options.locale].createEdgeError || this.options.locales.en.createEdgeError) : this.body.nodes[n] !== void 0 && this.body.nodes[s.id] !== void 0 && this._performAddEdge(n, s.id)), e.controlEdge = {
      from: n,
      to: s ? s.id : void 0
    }, this.selectionHandler.generateClickEvent("controlNodeDragEnd", e, t), this.body.emitter.emit("_redraw");
  }
  /**
   *
   * @param {Event} event
   * @private
   */
  _dragStartEdge(e) {
    const t = this.lastTouch;
    this.selectionHandler.generateClickEvent("dragStart", e, t, void 0, !0);
  }
  // --------------------------------------- END OF ADD EDGE FUNCTIONS -------------------------------------//
  // ------------------------------ Performing all the actual data manipulation ------------------------//
  /**
   * Adds a node on the specified location
   * @param {object} clickData
   * @private
   */
  _performAddNode(e) {
    const t = {
      id: yo(),
      x: e.pointer.canvas.x,
      y: e.pointer.canvas.y,
      label: "new"
    };
    if (typeof this.options.addNode == "function")
      if (this.options.addNode.length === 2)
        this.options.addNode(t, (r) => {
          r != null && this.inMode === "addNode" && this.body.data.nodes.getDataSet().add(r), this.showManipulatorToolbar();
        });
      else
        throw this.showManipulatorToolbar(), new Error("The function for add does not support two arguments (data,callback)");
    else
      this.body.data.nodes.getDataSet().add(t), this.showManipulatorToolbar();
  }
  /**
   * connect two nodes with a new edge.
   * @param {Node.id} sourceNodeId
   * @param {Node.id} targetNodeId
   * @private
   */
  _performAddEdge(e, t) {
    const r = {
      from: e,
      to: t
    };
    if (typeof this.options.addEdge == "function")
      if (this.options.addEdge.length === 2)
        this.options.addEdge(r, (n) => {
          n != null && this.inMode === "addEdge" && (this.body.data.edges.getDataSet().add(n), this.selectionHandler.unselectAll(), this.showManipulatorToolbar());
        });
      else
        throw new Error("The function for connect does not support two arguments (data,callback)");
    else
      this.body.data.edges.getDataSet().add(r), this.selectionHandler.unselectAll(), this.showManipulatorToolbar();
  }
  /**
   * connect two nodes with a new edge.
   * @param {Node.id} sourceNodeId
   * @param {Node.id} targetNodeId
   * @private
   */
  _performEditEdge(e, t) {
    const r = {
      id: this.edgeBeingEditedId,
      from: e,
      to: t,
      label: this.body.data.edges.get(this.edgeBeingEditedId).label
    };
    let n = this.options.editEdge;
    if (typeof n == "object" && (n = n.editWithoutDrag), typeof n == "function")
      if (n.length === 2)
        n(r, (o) => {
          o == null || this.inMode !== "editEdge" ? (this.body.edges[r.id].updateEdgeType(), this.body.emitter.emit("_redraw"), this.showManipulatorToolbar()) : (this.body.data.edges.getDataSet().update(o), this.selectionHandler.unselectAll(), this.showManipulatorToolbar());
        });
      else
        throw new Error("The function for edit does not support two arguments (data, callback)");
    else
      this.body.data.edges.getDataSet().update(r), this.selectionHandler.unselectAll(), this.showManipulatorToolbar();
  }
}
const P = "string", E = "boolean", b = "number", ao = "array", k = "object", RS = "dom", fde = "any", $c = ["arrow", "bar", "box", "circle", "crow", "curve", "diamond", "image", "inv_curve", "inv_triangle", "triangle", "vee"], wc = {
  borderWidth: {
    number: b
  },
  borderWidthSelected: {
    number: b,
    undefined: "undefined"
  },
  brokenImage: {
    string: P,
    undefined: "undefined"
  },
  chosen: {
    label: {
      boolean: E,
      function: "function"
    },
    node: {
      boolean: E,
      function: "function"
    },
    __type__: {
      object: k,
      boolean: E
    }
  },
  color: {
    border: {
      string: P
    },
    background: {
      string: P
    },
    highlight: {
      border: {
        string: P
      },
      background: {
        string: P
      },
      __type__: {
        object: k,
        string: P
      }
    },
    hover: {
      border: {
        string: P
      },
      background: {
        string: P
      },
      __type__: {
        object: k,
        string: P
      }
    },
    __type__: {
      object: k,
      string: P
    }
  },
  opacity: {
    number: b,
    undefined: "undefined"
  },
  fixed: {
    x: {
      boolean: E
    },
    y: {
      boolean: E
    },
    __type__: {
      object: k,
      boolean: E
    }
  },
  font: {
    align: {
      string: P
    },
    color: {
      string: P
    },
    size: {
      number: b
    },
    face: {
      string: P
    },
    background: {
      string: P
    },
    strokeWidth: {
      number: b
    },
    strokeColor: {
      string: P
    },
    vadjust: {
      number: b
    },
    multi: {
      boolean: E,
      string: P
    },
    bold: {
      color: {
        string: P
      },
      size: {
        number: b
      },
      face: {
        string: P
      },
      mod: {
        string: P
      },
      vadjust: {
        number: b
      },
      __type__: {
        object: k,
        string: P
      }
    },
    boldital: {
      color: {
        string: P
      },
      size: {
        number: b
      },
      face: {
        string: P
      },
      mod: {
        string: P
      },
      vadjust: {
        number: b
      },
      __type__: {
        object: k,
        string: P
      }
    },
    ital: {
      color: {
        string: P
      },
      size: {
        number: b
      },
      face: {
        string: P
      },
      mod: {
        string: P
      },
      vadjust: {
        number: b
      },
      __type__: {
        object: k,
        string: P
      }
    },
    mono: {
      color: {
        string: P
      },
      size: {
        number: b
      },
      face: {
        string: P
      },
      mod: {
        string: P
      },
      vadjust: {
        number: b
      },
      __type__: {
        object: k,
        string: P
      }
    },
    __type__: {
      object: k,
      string: P
    }
  },
  group: {
    string: P,
    number: b,
    undefined: "undefined"
  },
  heightConstraint: {
    minimum: {
      number: b
    },
    valign: {
      string: P
    },
    __type__: {
      object: k,
      boolean: E,
      number: b
    }
  },
  hidden: {
    boolean: E
  },
  icon: {
    face: {
      string: P
    },
    code: {
      string: P
    },
    size: {
      number: b
    },
    color: {
      string: P
    },
    weight: {
      string: P,
      number: b
    },
    __type__: {
      object: k
    }
  },
  id: {
    string: P,
    number: b
  },
  image: {
    selected: {
      string: P,
      undefined: "undefined"
    },
    unselected: {
      string: P,
      undefined: "undefined"
    },
    __type__: {
      object: k,
      string: P
    }
  },
  imagePadding: {
    top: {
      number: b
    },
    right: {
      number: b
    },
    bottom: {
      number: b
    },
    left: {
      number: b
    },
    __type__: {
      object: k,
      number: b
    }
  },
  label: {
    string: P,
    undefined: "undefined"
  },
  labelHighlightBold: {
    boolean: E
  },
  level: {
    number: b,
    undefined: "undefined"
  },
  margin: {
    top: {
      number: b
    },
    right: {
      number: b
    },
    bottom: {
      number: b
    },
    left: {
      number: b
    },
    __type__: {
      object: k,
      number: b
    }
  },
  mass: {
    number: b
  },
  physics: {
    boolean: E
  },
  scaling: {
    min: {
      number: b
    },
    max: {
      number: b
    },
    label: {
      enabled: {
        boolean: E
      },
      min: {
        number: b
      },
      max: {
        number: b
      },
      maxVisible: {
        number: b
      },
      drawThreshold: {
        number: b
      },
      __type__: {
        object: k,
        boolean: E
      }
    },
    customScalingFunction: {
      function: "function"
    },
    __type__: {
      object: k
    }
  },
  shadow: {
    enabled: {
      boolean: E
    },
    color: {
      string: P
    },
    size: {
      number: b
    },
    x: {
      number: b
    },
    y: {
      number: b
    },
    __type__: {
      object: k,
      boolean: E
    }
  },
  shape: {
    string: ["custom", "ellipse", "circle", "database", "box", "text", "image", "circularImage", "diamond", "dot", "star", "triangle", "triangleDown", "square", "icon", "hexagon"]
  },
  ctxRenderer: {
    function: "function"
  },
  shapeProperties: {
    borderDashes: {
      boolean: E,
      array: ao
    },
    borderRadius: {
      number: b
    },
    interpolation: {
      boolean: E
    },
    useImageSize: {
      boolean: E
    },
    useBorderWithImage: {
      boolean: E
    },
    coordinateOrigin: {
      string: ["center", "top-left"]
    },
    __type__: {
      object: k
    }
  },
  size: {
    number: b
  },
  title: {
    string: P,
    dom: RS,
    undefined: "undefined"
  },
  value: {
    number: b,
    undefined: "undefined"
  },
  widthConstraint: {
    minimum: {
      number: b
    },
    maximum: {
      number: b
    },
    __type__: {
      object: k,
      boolean: E,
      number: b
    }
  },
  x: {
    number: b
  },
  y: {
    number: b
  },
  __type__: {
    object: k
  }
}, vde = {
  configure: {
    enabled: {
      boolean: E
    },
    filter: {
      boolean: E,
      string: P,
      array: ao,
      function: "function"
    },
    container: {
      dom: RS
    },
    showButton: {
      boolean: E
    },
    __type__: {
      object: k,
      boolean: E,
      string: P,
      array: ao,
      function: "function"
    }
  },
  edges: {
    arrows: {
      to: {
        enabled: {
          boolean: E
        },
        scaleFactor: {
          number: b
        },
        type: {
          string: $c
        },
        imageHeight: {
          number: b
        },
        imageWidth: {
          number: b
        },
        src: {
          string: P
        },
        __type__: {
          object: k,
          boolean: E
        }
      },
      middle: {
        enabled: {
          boolean: E
        },
        scaleFactor: {
          number: b
        },
        type: {
          string: $c
        },
        imageWidth: {
          number: b
        },
        imageHeight: {
          number: b
        },
        src: {
          string: P
        },
        __type__: {
          object: k,
          boolean: E
        }
      },
      from: {
        enabled: {
          boolean: E
        },
        scaleFactor: {
          number: b
        },
        type: {
          string: $c
        },
        imageWidth: {
          number: b
        },
        imageHeight: {
          number: b
        },
        src: {
          string: P
        },
        __type__: {
          object: k,
          boolean: E
        }
      },
      __type__: {
        string: ["from", "to", "middle"],
        object: k
      }
    },
    endPointOffset: {
      from: {
        number: b
      },
      to: {
        number: b
      },
      __type__: {
        object: k,
        number: b
      }
    },
    arrowStrikethrough: {
      boolean: E
    },
    background: {
      enabled: {
        boolean: E
      },
      color: {
        string: P
      },
      size: {
        number: b
      },
      dashes: {
        boolean: E,
        array: ao
      },
      __type__: {
        object: k,
        boolean: E
      }
    },
    chosen: {
      label: {
        boolean: E,
        function: "function"
      },
      edge: {
        boolean: E,
        function: "function"
      },
      __type__: {
        object: k,
        boolean: E
      }
    },
    color: {
      color: {
        string: P
      },
      highlight: {
        string: P
      },
      hover: {
        string: P
      },
      inherit: {
        string: ["from", "to", "both"],
        boolean: E
      },
      opacity: {
        number: b
      },
      __type__: {
        object: k,
        string: P
      }
    },
    dashes: {
      boolean: E,
      array: ao
    },
    font: {
      color: {
        string: P
      },
      size: {
        number: b
      },
      face: {
        string: P
      },
      background: {
        string: P
      },
      strokeWidth: {
        number: b
      },
      strokeColor: {
        string: P
      },
      align: {
        string: ["horizontal", "top", "middle", "bottom"]
      },
      vadjust: {
        number: b
      },
      multi: {
        boolean: E,
        string: P
      },
      bold: {
        color: {
          string: P
        },
        size: {
          number: b
        },
        face: {
          string: P
        },
        mod: {
          string: P
        },
        vadjust: {
          number: b
        },
        __type__: {
          object: k,
          string: P
        }
      },
      boldital: {
        color: {
          string: P
        },
        size: {
          number: b
        },
        face: {
          string: P
        },
        mod: {
          string: P
        },
        vadjust: {
          number: b
        },
        __type__: {
          object: k,
          string: P
        }
      },
      ital: {
        color: {
          string: P
        },
        size: {
          number: b
        },
        face: {
          string: P
        },
        mod: {
          string: P
        },
        vadjust: {
          number: b
        },
        __type__: {
          object: k,
          string: P
        }
      },
      mono: {
        color: {
          string: P
        },
        size: {
          number: b
        },
        face: {
          string: P
        },
        mod: {
          string: P
        },
        vadjust: {
          number: b
        },
        __type__: {
          object: k,
          string: P
        }
      },
      __type__: {
        object: k,
        string: P
      }
    },
    hidden: {
      boolean: E
    },
    hoverWidth: {
      function: "function",
      number: b
    },
    label: {
      string: P,
      undefined: "undefined"
    },
    labelHighlightBold: {
      boolean: E
    },
    length: {
      number: b,
      undefined: "undefined"
    },
    physics: {
      boolean: E
    },
    scaling: {
      min: {
        number: b
      },
      max: {
        number: b
      },
      label: {
        enabled: {
          boolean: E
        },
        min: {
          number: b
        },
        max: {
          number: b
        },
        maxVisible: {
          number: b
        },
        drawThreshold: {
          number: b
        },
        __type__: {
          object: k,
          boolean: E
        }
      },
      customScalingFunction: {
        function: "function"
      },
      __type__: {
        object: k
      }
    },
    selectionWidth: {
      function: "function",
      number: b
    },
    selfReferenceSize: {
      number: b
    },
    selfReference: {
      size: {
        number: b
      },
      angle: {
        number: b
      },
      renderBehindTheNode: {
        boolean: E
      },
      __type__: {
        object: k
      }
    },
    shadow: {
      enabled: {
        boolean: E
      },
      color: {
        string: P
      },
      size: {
        number: b
      },
      x: {
        number: b
      },
      y: {
        number: b
      },
      __type__: {
        object: k,
        boolean: E
      }
    },
    smooth: {
      enabled: {
        boolean: E
      },
      type: {
        string: ["dynamic", "continuous", "discrete", "diagonalCross", "straightCross", "horizontal", "vertical", "curvedCW", "curvedCCW", "cubicBezier"]
      },
      roundness: {
        number: b
      },
      forceDirection: {
        string: ["horizontal", "vertical", "none"],
        boolean: E
      },
      __type__: {
        object: k,
        boolean: E
      }
    },
    title: {
      string: P,
      undefined: "undefined"
    },
    width: {
      number: b
    },
    widthConstraint: {
      maximum: {
        number: b
      },
      __type__: {
        object: k,
        boolean: E,
        number: b
      }
    },
    value: {
      number: b,
      undefined: "undefined"
    },
    __type__: {
      object: k
    }
  },
  groups: {
    useDefaultGroups: {
      boolean: E
    },
    __any__: wc,
    __type__: {
      object: k
    }
  },
  interaction: {
    dragNodes: {
      boolean: E
    },
    dragView: {
      boolean: E
    },
    hideEdgesOnDrag: {
      boolean: E
    },
    hideEdgesOnZoom: {
      boolean: E
    },
    hideNodesOnDrag: {
      boolean: E
    },
    hover: {
      boolean: E
    },
    keyboard: {
      enabled: {
        boolean: E
      },
      speed: {
        x: {
          number: b
        },
        y: {
          number: b
        },
        zoom: {
          number: b
        },
        __type__: {
          object: k
        }
      },
      bindToWindow: {
        boolean: E
      },
      autoFocus: {
        boolean: E
      },
      __type__: {
        object: k,
        boolean: E
      }
    },
    multiselect: {
      boolean: E
    },
    navigationButtons: {
      boolean: E
    },
    selectable: {
      boolean: E
    },
    selectConnectedEdges: {
      boolean: E
    },
    hoverConnectedEdges: {
      boolean: E
    },
    tooltipDelay: {
      number: b
    },
    zoomView: {
      boolean: E
    },
    zoomSpeed: {
      number: b
    },
    __type__: {
      object: k
    }
  },
  layout: {
    randomSeed: {
      undefined: "undefined",
      number: b,
      string: P
    },
    improvedLayout: {
      boolean: E
    },
    clusterThreshold: {
      number: b
    },
    hierarchical: {
      enabled: {
        boolean: E
      },
      levelSeparation: {
        number: b
      },
      nodeSpacing: {
        number: b
      },
      treeSpacing: {
        number: b
      },
      blockShifting: {
        boolean: E
      },
      edgeMinimization: {
        boolean: E
      },
      parentCentralization: {
        boolean: E
      },
      direction: {
        string: ["UD", "DU", "LR", "RL"]
      },
      sortMethod: {
        string: ["hubsize", "directed"]
      },
      shakeTowards: {
        string: ["leaves", "roots"]
      },
      __type__: {
        object: k,
        boolean: E
      }
    },
    __type__: {
      object: k
    }
  },
  manipulation: {
    enabled: {
      boolean: E
    },
    initiallyActive: {
      boolean: E
    },
    addNode: {
      boolean: E,
      function: "function"
    },
    addEdge: {
      boolean: E,
      function: "function"
    },
    editNode: {
      function: "function"
    },
    editEdge: {
      editWithoutDrag: {
        function: "function"
      },
      __type__: {
        object: k,
        boolean: E,
        function: "function"
      }
    },
    deleteNode: {
      boolean: E,
      function: "function"
    },
    deleteEdge: {
      boolean: E,
      function: "function"
    },
    controlNodeStyle: wc,
    __type__: {
      object: k,
      boolean: E
    }
  },
  nodes: wc,
  physics: {
    enabled: {
      boolean: E
    },
    barnesHut: {
      theta: {
        number: b
      },
      gravitationalConstant: {
        number: b
      },
      centralGravity: {
        number: b
      },
      springLength: {
        number: b
      },
      springConstant: {
        number: b
      },
      damping: {
        number: b
      },
      avoidOverlap: {
        number: b
      },
      __type__: {
        object: k
      }
    },
    forceAtlas2Based: {
      theta: {
        number: b
      },
      gravitationalConstant: {
        number: b
      },
      centralGravity: {
        number: b
      },
      springLength: {
        number: b
      },
      springConstant: {
        number: b
      },
      damping: {
        number: b
      },
      avoidOverlap: {
        number: b
      },
      __type__: {
        object: k
      }
    },
    repulsion: {
      centralGravity: {
        number: b
      },
      springLength: {
        number: b
      },
      springConstant: {
        number: b
      },
      nodeDistance: {
        number: b
      },
      damping: {
        number: b
      },
      __type__: {
        object: k
      }
    },
    hierarchicalRepulsion: {
      centralGravity: {
        number: b
      },
      springLength: {
        number: b
      },
      springConstant: {
        number: b
      },
      nodeDistance: {
        number: b
      },
      damping: {
        number: b
      },
      avoidOverlap: {
        number: b
      },
      __type__: {
        object: k
      }
    },
    maxVelocity: {
      number: b
    },
    minVelocity: {
      number: b
    },
    solver: {
      string: ["barnesHut", "repulsion", "hierarchicalRepulsion", "forceAtlas2Based"]
    },
    stabilization: {
      enabled: {
        boolean: E
      },
      iterations: {
        number: b
      },
      updateInterval: {
        number: b
      },
      onlyDynamicEdges: {
        boolean: E
      },
      fit: {
        boolean: E
      },
      __type__: {
        object: k,
        boolean: E
      }
    },
    timestep: {
      number: b
    },
    adaptiveTimestep: {
      boolean: E
    },
    wind: {
      x: {
        number: b
      },
      y: {
        number: b
      },
      __type__: {
        object: k
      }
    },
    __type__: {
      object: k,
      boolean: E
    }
  },
  //globals :
  autoResize: {
    boolean: E
  },
  clickToUse: {
    boolean: E
  },
  locale: {
    string: P
  },
  locales: {
    __any__: {
      any: fde
    },
    __type__: {
      object: k
    }
  },
  height: {
    string: P
  },
  width: {
    string: P
  },
  __type__: {
    object: k
  }
}, FS = {
  nodes: {
    borderWidth: [1, 0, 10, 1],
    borderWidthSelected: [2, 0, 10, 1],
    color: {
      border: ["color", "#2B7CE9"],
      background: ["color", "#97C2FC"],
      highlight: {
        border: ["color", "#2B7CE9"],
        background: ["color", "#D2E5FF"]
      },
      hover: {
        border: ["color", "#2B7CE9"],
        background: ["color", "#D2E5FF"]
      }
    },
    opacity: [0, 0, 1, 0.1],
    fixed: {
      x: !1,
      y: !1
    },
    font: {
      color: ["color", "#343434"],
      size: [14, 0, 100, 1],
      face: ["arial", "verdana", "tahoma"],
      background: ["color", "none"],
      strokeWidth: [0, 0, 50, 1],
      strokeColor: ["color", "#ffffff"]
    },
    //group: 'string',
    hidden: !1,
    labelHighlightBold: !0,
    //icon: {
    //  face: 'string',  //'FontAwesome',
    //  code: 'string',  //'\uf007',
    //  size: [50, 0, 200, 1],  //50,
    //  color: ['color','#2B7CE9']   //'#aa00ff'
    //},
    //image: 'string', // --> URL
    physics: !0,
    scaling: {
      min: [10, 0, 200, 1],
      max: [30, 0, 200, 1],
      label: {
        enabled: !1,
        min: [14, 0, 200, 1],
        max: [30, 0, 200, 1],
        maxVisible: [30, 0, 200, 1],
        drawThreshold: [5, 0, 20, 1]
      }
    },
    shadow: {
      enabled: !1,
      color: "rgba(0,0,0,0.5)",
      size: [10, 0, 20, 1],
      x: [5, -30, 30, 1],
      y: [5, -30, 30, 1]
    },
    shape: ["ellipse", "box", "circle", "database", "diamond", "dot", "square", "star", "text", "triangle", "triangleDown", "hexagon"],
    shapeProperties: {
      borderDashes: !1,
      borderRadius: [6, 0, 20, 1],
      interpolation: !0,
      useImageSize: !1
    },
    size: [25, 0, 200, 1]
  },
  edges: {
    arrows: {
      to: {
        enabled: !1,
        scaleFactor: [1, 0, 3, 0.05],
        type: "arrow"
      },
      middle: {
        enabled: !1,
        scaleFactor: [1, 0, 3, 0.05],
        type: "arrow"
      },
      from: {
        enabled: !1,
        scaleFactor: [1, 0, 3, 0.05],
        type: "arrow"
      }
    },
    endPointOffset: {
      from: [0, -10, 10, 1],
      to: [0, -10, 10, 1]
    },
    arrowStrikethrough: !0,
    color: {
      color: ["color", "#848484"],
      highlight: ["color", "#848484"],
      hover: ["color", "#848484"],
      inherit: ["from", "to", "both", !0, !1],
      opacity: [1, 0, 1, 0.05]
    },
    dashes: !1,
    font: {
      color: ["color", "#343434"],
      size: [14, 0, 100, 1],
      face: ["arial", "verdana", "tahoma"],
      background: ["color", "none"],
      strokeWidth: [2, 0, 50, 1],
      strokeColor: ["color", "#ffffff"],
      align: ["horizontal", "top", "middle", "bottom"]
    },
    hidden: !1,
    hoverWidth: [1.5, 0, 5, 0.1],
    labelHighlightBold: !0,
    physics: !0,
    scaling: {
      min: [1, 0, 100, 1],
      max: [15, 0, 100, 1],
      label: {
        enabled: !0,
        min: [14, 0, 200, 1],
        max: [30, 0, 200, 1],
        maxVisible: [30, 0, 200, 1],
        drawThreshold: [5, 0, 20, 1]
      }
    },
    selectionWidth: [1.5, 0, 5, 0.1],
    selfReferenceSize: [20, 0, 200, 1],
    selfReference: {
      size: [20, 0, 200, 1],
      angle: [Math.PI / 2, -6 * Math.PI, 6 * Math.PI, Math.PI / 8],
      renderBehindTheNode: !0
    },
    shadow: {
      enabled: !1,
      color: "rgba(0,0,0,0.5)",
      size: [10, 0, 20, 1],
      x: [5, -30, 30, 1],
      y: [5, -30, 30, 1]
    },
    smooth: {
      enabled: !0,
      type: ["dynamic", "continuous", "discrete", "diagonalCross", "straightCross", "horizontal", "vertical", "curvedCW", "curvedCCW", "cubicBezier"],
      forceDirection: ["horizontal", "vertical", "none"],
      roundness: [0.5, 0, 1, 0.05]
    },
    width: [1, 0, 30, 1]
  },
  layout: {
    //randomSeed: [0, 0, 500, 1],
    //improvedLayout: true,
    hierarchical: {
      enabled: !1,
      levelSeparation: [150, 20, 500, 5],
      nodeSpacing: [100, 20, 500, 5],
      treeSpacing: [200, 20, 500, 5],
      blockShifting: !0,
      edgeMinimization: !0,
      parentCentralization: !0,
      direction: ["UD", "DU", "LR", "RL"],
      sortMethod: ["hubsize", "directed"],
      shakeTowards: ["leaves", "roots"]
      // leaves, roots
    }
  },
  interaction: {
    dragNodes: !0,
    dragView: !0,
    hideEdgesOnDrag: !1,
    hideEdgesOnZoom: !1,
    hideNodesOnDrag: !1,
    hover: !1,
    keyboard: {
      enabled: !1,
      speed: {
        x: [10, 0, 40, 1],
        y: [10, 0, 40, 1],
        zoom: [0.02, 0, 0.1, 5e-3]
      },
      bindToWindow: !0,
      autoFocus: !0
    },
    multiselect: !1,
    navigationButtons: !1,
    selectable: !0,
    selectConnectedEdges: !0,
    hoverConnectedEdges: !0,
    tooltipDelay: [300, 0, 1e3, 25],
    zoomView: !0,
    zoomSpeed: [1, 0.1, 2, 0.1]
  },
  manipulation: {
    enabled: !1,
    initiallyActive: !1
  },
  physics: {
    enabled: !0,
    barnesHut: {
      theta: [0.5, 0.1, 1, 0.05],
      gravitationalConstant: [-2e3, -3e4, 0, 50],
      centralGravity: [0.3, 0, 10, 0.05],
      springLength: [95, 0, 500, 5],
      springConstant: [0.04, 0, 1.2, 5e-3],
      damping: [0.09, 0, 1, 0.01],
      avoidOverlap: [0, 0, 1, 0.01]
    },
    forceAtlas2Based: {
      theta: [0.5, 0.1, 1, 0.05],
      gravitationalConstant: [-50, -500, 0, 1],
      centralGravity: [0.01, 0, 1, 5e-3],
      springLength: [95, 0, 500, 5],
      springConstant: [0.08, 0, 1.2, 5e-3],
      damping: [0.4, 0, 1, 0.01],
      avoidOverlap: [0, 0, 1, 0.01]
    },
    repulsion: {
      centralGravity: [0.2, 0, 10, 0.05],
      springLength: [200, 0, 500, 5],
      springConstant: [0.05, 0, 1.2, 5e-3],
      nodeDistance: [100, 0, 500, 5],
      damping: [0.09, 0, 1, 0.01]
    },
    hierarchicalRepulsion: {
      centralGravity: [0.2, 0, 10, 0.05],
      springLength: [100, 0, 500, 5],
      springConstant: [0.01, 0, 1.2, 5e-3],
      nodeDistance: [120, 0, 500, 5],
      damping: [0.09, 0, 1, 0.01],
      avoidOverlap: [0, 0, 1, 0.01]
    },
    maxVelocity: [50, 0, 150, 1],
    minVelocity: [0.1, 0.01, 0.5, 0.01],
    solver: ["barnesHut", "forceAtlas2Based", "repulsion", "hierarchicalRepulsion"],
    timestep: [0.5, 0.01, 1, 0.01],
    wind: {
      x: [0, -10, 10, 0.1],
      y: [0, -10, 10, 0.1]
    }
    //adaptiveTimestep: true
  }
}, pde = (i, e, t) => {
  var r;
  return !!(kr(i).call(i, "physics") && kr(r = FS.physics.solver).call(r, e) && t.physics.solver !== e && e !== "wind");
};
class gde {
  /**
   * @ignore
   */
  constructor() {
  }
  /**
   *
   * @param {object} body
   * @param {Array.<Node>} nodesArray
   * @param {Array.<Edge>} edgesArray
   * @returns {{}}
   */
  getDistances(e, t, r) {
    const n = {}, o = e.edges;
    for (let a = 0; a < t.length; a++) {
      const l = t[a], d = {};
      n[l] = d;
      for (let h = 0; h < t.length; h++)
        d[t[h]] = a == h ? 0 : 1e9;
    }
    for (let a = 0; a < r.length; a++) {
      const l = o[r[a]];
      l.connected === !0 && n[l.fromId] !== void 0 && n[l.toId] !== void 0 && (n[l.fromId][l.toId] = 1, n[l.toId][l.fromId] = 1);
    }
    const s = t.length;
    for (let a = 0; a < s; a++) {
      const l = t[a], d = n[l];
      for (let h = 0; h < s - 1; h++) {
        const c = t[h], u = n[c];
        for (let f = h + 1; f < s; f++) {
          const v = t[f], y = n[v], g = Math.min(u[v], u[l] + d[v]);
          u[v] = g, y[c] = g;
        }
      }
    }
    return n;
  }
}
class yde {
  /**
   * @param {object} body
   * @param {number} edgeLength
   * @param {number} edgeStrength
   */
  constructor(e, t, r) {
    this.body = e, this.springLength = t, this.springConstant = r, this.distanceSolver = new gde();
  }
  /**
   * Not sure if needed but can be used to update the spring length and spring constant
   * @param {object} options
   */
  setOptions(e) {
    e && (e.springLength && (this.springLength = e.springLength), e.springConstant && (this.springConstant = e.springConstant));
  }
  /**
   * Position the system
   * @param {Array.<Node>} nodesArray
   * @param {Array.<vis.Edge>} edgesArray
   * @param {boolean} [ignoreClusters]
   */
  solve(e, t) {
    let r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !1;
    const n = this.distanceSolver.getDistances(this.body, e, t);
    this._createL_matrix(n), this._createK_matrix(n), this._createE_matrix();
    const o = 0.01, s = 1;
    let a = 0;
    const l = Math.max(1e3, Math.min(10 * this.body.nodeIndices.length, 6e3)), d = 5;
    let h = 1e9, c = 0, u = 0, f = 0, v = 0, y = 0;
    for (; h > o && a < l; )
      for (a += 1, [c, h, u, f] = this._getHighestEnergyNode(r), v = h, y = 0; v > s && y < d; )
        y += 1, this._moveNode(c, u, f), [v, u, f] = this._getEnergy(c);
  }
  /**
   * get the node with the highest energy
   * @param {boolean} ignoreClusters
   * @returns {number[]}
   * @private
   */
  _getHighestEnergyNode(e) {
    const t = this.body.nodeIndices, r = this.body.nodes;
    let n = 0, o = t[0], s = 0, a = 0;
    for (let l = 0; l < t.length; l++) {
      const d = t[l];
      if (r[d].predefinedPosition !== !0 || r[d].isCluster === !0 && e === !0 || r[d].options.fixed.x !== !0 || r[d].options.fixed.y !== !0) {
        const [h, c, u] = this._getEnergy(d);
        n < h && (n = h, o = d, s = c, a = u);
      }
    }
    return [o, n, s, a];
  }
  /**
   * calculate the energy of a single node
   * @param {Node.id} m
   * @returns {number[]}
   * @private
   */
  _getEnergy(e) {
    const [t, r] = this.E_sums[e];
    return [Math.sqrt(t ** 2 + r ** 2), t, r];
  }
  /**
   * move the node based on it's energy
   * the dx and dy are calculated from the linear system proposed by Kamada and Kawai
   * @param {number} m
   * @param {number} dE_dx
   * @param {number} dE_dy
   * @private
   */
  _moveNode(e, t, r) {
    const n = this.body.nodeIndices, o = this.body.nodes;
    let s = 0, a = 0, l = 0;
    const d = o[e].x, h = o[e].y, c = this.K_matrix[e], u = this.L_matrix[e];
    for (let w = 0; w < n.length; w++) {
      const T = n[w];
      if (T !== e) {
        const A = o[T].x, L = o[T].y, G = c[T], ne = u[T], oe = 1 / ((d - A) ** 2 + (h - L) ** 2) ** 1.5;
        s += G * (1 - ne * (h - L) ** 2 * oe), a += G * (ne * (d - A) * (h - L) * oe), l += G * (1 - ne * (d - A) ** 2 * oe);
      }
    }
    const f = s, v = a, y = t, g = l, p = r, m = (y / f + p / v) / (v / f - g / v), $ = -(v * m + y) / f;
    o[e].x += $, o[e].y += m, this._updateE_matrix(e);
  }
  /**
   * Create the L matrix: edge length times shortest path
   * @param {object} D_matrix
   * @private
   */
  _createL_matrix(e) {
    const t = this.body.nodeIndices, r = this.springLength;
    this.L_matrix = [];
    for (let n = 0; n < t.length; n++) {
      this.L_matrix[t[n]] = {};
      for (let o = 0; o < t.length; o++)
        this.L_matrix[t[n]][t[o]] = r * e[t[n]][t[o]];
    }
  }
  /**
   * Create the K matrix: spring constants times shortest path
   * @param {object} D_matrix
   * @private
   */
  _createK_matrix(e) {
    const t = this.body.nodeIndices, r = this.springConstant;
    this.K_matrix = [];
    for (let n = 0; n < t.length; n++) {
      this.K_matrix[t[n]] = {};
      for (let o = 0; o < t.length; o++)
        this.K_matrix[t[n]][t[o]] = r * e[t[n]][t[o]] ** -2;
    }
  }
  /**
   *  Create matrix with all energies between nodes
   *  @private
   */
  _createE_matrix() {
    const e = this.body.nodeIndices, t = this.body.nodes;
    this.E_matrix = {}, this.E_sums = {};
    for (let r = 0; r < e.length; r++)
      this.E_matrix[e[r]] = [];
    for (let r = 0; r < e.length; r++) {
      const n = e[r], o = t[n].x, s = t[n].y;
      let a = 0, l = 0;
      for (let d = r; d < e.length; d++) {
        const h = e[d];
        if (h !== n) {
          const c = t[h].x, u = t[h].y, f = 1 / Math.sqrt((o - c) ** 2 + (s - u) ** 2);
          this.E_matrix[n][d] = [this.K_matrix[n][h] * (o - c - this.L_matrix[n][h] * (o - c) * f), this.K_matrix[n][h] * (s - u - this.L_matrix[n][h] * (s - u) * f)], this.E_matrix[h][r] = this.E_matrix[n][d], a += this.E_matrix[n][d][0], l += this.E_matrix[n][d][1];
        }
      }
      this.E_sums[n] = [a, l];
    }
  }
  /**
   * Update method, just doing single column (rows are auto-updated) (update all sums)
   * @param {number} m
   * @private
   */
  _updateE_matrix(e) {
    const t = this.body.nodeIndices, r = this.body.nodes, n = this.E_matrix[e], o = this.K_matrix[e], s = this.L_matrix[e], a = r[e].x, l = r[e].y;
    let d = 0, h = 0;
    for (let c = 0; c < t.length; c++) {
      const u = t[c];
      if (u !== e) {
        const f = n[c], v = f[0], y = f[1], g = r[u].x, p = r[u].y, m = 1 / Math.sqrt((a - g) ** 2 + (l - p) ** 2), $ = o[u] * (a - g - s[u] * (a - g) * m), w = o[u] * (l - p - s[u] * (l - p) * m);
        n[c] = [$, w], d += $, h += w;
        const T = this.E_sums[u];
        T[0] += $ - v, T[1] += w - y;
      }
    }
    this.E_sums[e] = [d, h];
  }
}
function M(i, e, t) {
  var r, n, o, s;
  if (!(this instanceof M))
    throw new SyntaxError("Constructor must be called with the new operator");
  this.options = {}, this.defaultOptions = {
    locale: "en",
    locales: Yee,
    clickToUse: !1
  }, Ce(this.options, this.defaultOptions), this.body = {
    container: i,
    // See comment above for following fields
    nodes: {},
    nodeIndices: [],
    edges: {},
    edgeIndices: [],
    emitter: {
      on: S(r = this.on).call(r, this),
      off: S(n = this.off).call(n, this),
      emit: S(o = this.emit).call(o, this),
      once: S(s = this.once).call(s, this)
    },
    eventListeners: {
      onTap: function() {
      },
      onTouch: function() {
      },
      onDoubleTap: function() {
      },
      onHold: function() {
      },
      onDragStart: function() {
      },
      onDrag: function() {
      },
      onDragEnd: function() {
      },
      onMouseWheel: function() {
      },
      onPinch: function() {
      },
      onMouseMove: function() {
      },
      onRelease: function() {
      },
      onContext: function() {
      }
    },
    data: {
      nodes: null,
      // A DataSet or DataView
      edges: null
      // A DataSet or DataView
    },
    functions: {
      createNode: function() {
      },
      createEdge: function() {
      },
      getPointer: function() {
      }
    },
    modules: {},
    view: {
      scale: 1,
      translation: {
        x: 0,
        y: 0
      }
    },
    selectionBox: {
      show: !1,
      position: {
        start: {
          x: 0,
          y: 0
        },
        end: {
          x: 0,
          y: 0
        }
      }
    }
  }, this.bindEventListeners(), this.images = new Jee(() => this.body.emitter.emit("_requestRedraw")), this.groups = new Gre(), this.canvas = new oae(this.body), this.selectionHandler = new Uae(this.body, this.canvas), this.interactionHandler = new dae(this.body, this.canvas, this.selectionHandler), this.view = new aae(this.body, this.canvas), this.renderer = new eae(this.body, this.canvas), this.physics = new Kse(this.body), this.layoutEngine = new cde(this.body), this.clustering = new Qse(this.body), this.manipulation = new ude(this.body, this.canvas, this.selectionHandler, this.interactionHandler), this.nodesHandler = new yse(this.body, this.images, this.groups, this.layoutEngine), this.edgesHandler = new zse(this.body, this.images, this.groups), this.body.modules.kamadaKawai = new yde(this.body, 150, 0.05), this.body.modules.clustering = this.clustering, this.canvas._create(), this.setOptions(t), this.setData(e);
}
r_(M.prototype);
M.prototype.setOptions = function(i) {
  if (i === null && (i = void 0), i !== void 0) {
    if (Oee.validate(i, vde) === !0 && console.error("%cErrors have been found in the supplied options object.", BE), Xn(["locale", "locales", "clickToUse"], this.options, i), i.locale !== void 0 && (i.locale = qee(i.locales || this.options.locales, i.locale)), i = this.layoutEngine.setOptions(i.layout, i), this.canvas.setOptions(i), this.groups.setOptions(i.groups), this.nodesHandler.setOptions(i.nodes), this.edgesHandler.setOptions(i.edges), this.physics.setOptions(i.physics), this.manipulation.setOptions(i.manipulation, i, this.options), this.interactionHandler.setOptions(i.interaction), this.renderer.setOptions(i.interaction), this.selectionHandler.setOptions(i.interaction), i.groups !== void 0 && this.body.emitter.emit("refreshNodes"), "configure" in i && (this.configurator || (this.configurator = new Eee(this, this.body.container, FS, this.canvas.pixelRatio, pde)), this.configurator.setOptions(i.configure)), this.configurator && this.configurator.options.enabled === !0) {
      const r = {
        nodes: {},
        edges: {},
        layout: {},
        interaction: {},
        manipulation: {},
        physics: {},
        global: {}
      };
      le(r.nodes, this.nodesHandler.options), le(r.edges, this.edgesHandler.options), le(r.layout, this.layoutEngine.options), le(r.interaction, this.selectionHandler.options), le(r.interaction, this.renderer.options), le(r.interaction, this.interactionHandler.options), le(r.manipulation, this.manipulation.options), le(r.physics, this.physics.options), le(r.global, this.canvas.options), le(r.global, this.options), this.configurator.setModuleOptions(r);
    }
    i.clickToUse !== void 0 ? i.clickToUse === !0 ? this.activator === void 0 && (this.activator = new _ee(this.canvas.frame), this.activator.on("change", () => {
      this.body.emitter.emit("activate");
    })) : (this.activator !== void 0 && (this.activator.destroy(), delete this.activator), this.body.emitter.emit("activate")) : this.body.emitter.emit("activate"), this.canvas.setSize(), this.body.emitter.emit("startSimulation");
  }
};
M.prototype._updateVisibleIndices = function() {
  const i = this.body.nodes, e = this.body.edges;
  this.body.nodeIndices = [], this.body.edgeIndices = [];
  for (const t in i)
    Object.prototype.hasOwnProperty.call(i, t) && !this.clustering._isClusteredNode(t) && i[t].options.hidden === !1 && this.body.nodeIndices.push(i[t].id);
  for (const t in e)
    if (Object.prototype.hasOwnProperty.call(e, t)) {
      const r = e[t], n = i[r.fromId], o = i[r.toId], s = n !== void 0 && o !== void 0;
      !this.clustering._isClusteredEdge(t) && r.options.hidden === !1 && s && n.options.hidden === !1 && // Also hidden if any of its connecting nodes are hidden
      o.options.hidden === !1 && this.body.edgeIndices.push(r.id);
    }
};
M.prototype.bindEventListeners = function() {
  this.body.emitter.on("_dataChanged", () => {
    this.edgesHandler._updateState(), this.body.emitter.emit("_dataUpdated");
  }), this.body.emitter.on("_dataUpdated", () => {
    this.clustering._updateState(), this._updateVisibleIndices(), this._updateValueRange(this.body.nodes), this._updateValueRange(this.body.edges), this.body.emitter.emit("startSimulation"), this.body.emitter.emit("_requestRedraw");
  });
};
M.prototype.setData = function(i) {
  if (this.body.emitter.emit("resetPhysics"), this.body.emitter.emit("_resetData"), this.selectionHandler.unselectAll(), i && i.dot && (i.nodes || i.edges))
    throw new SyntaxError('Data must contain either parameter "dot" or  parameter pair "nodes" and "edges", but not both.');
  if (this.setOptions(i && i.options), i && i.dot) {
    console.warn("The dot property has been deprecated. Please use the static convertDot method to convert DOT into vis.network format and use the normal data format with nodes and edges. This converter is used like this: var data = vis.network.convertDot(dotString);");
    const e = Nee(i.dot);
    this.setData(e);
    return;
  } else if (i && i.gephi) {
    console.warn("The gephi property has been deprecated. Please use the static convertGephi method to convert gephi into vis.network format and use the normal data format with nodes and edges. This converter is used like this: var data = vis.network.convertGephi(gephiJson);");
    const e = Ree(i.gephi);
    this.setData(e);
    return;
  } else
    this.nodesHandler.setData(i && i.nodes, !0), this.edgesHandler.setData(i && i.edges, !0);
  this.body.emitter.emit("_dataChanged"), this.body.emitter.emit("_dataLoaded"), this.body.emitter.emit("initPhysics");
};
M.prototype.destroy = function() {
  this.body.emitter.emit("destroy"), this.body.emitter.off(), this.off(), delete this.groups, delete this.canvas, delete this.selectionHandler, delete this.interactionHandler, delete this.view, delete this.renderer, delete this.physics, delete this.layoutEngine, delete this.clustering, delete this.manipulation, delete this.nodesHandler, delete this.edgesHandler, delete this.configurator, delete this.images;
  for (const i in this.body.nodes)
    Object.prototype.hasOwnProperty.call(this.body.nodes, i) && delete this.body.nodes[i];
  for (const i in this.body.edges)
    Object.prototype.hasOwnProperty.call(this.body.edges, i) && delete this.body.edges[i];
  Sr(this.body.container);
};
M.prototype._updateValueRange = function(i) {
  let e, t, r, n = 0;
  for (e in i)
    if (Object.prototype.hasOwnProperty.call(i, e)) {
      const o = i[e].getValue();
      o !== void 0 && (t = t === void 0 ? o : Math.min(o, t), r = r === void 0 ? o : Math.max(o, r), n += o);
    }
  if (t !== void 0 && r !== void 0)
    for (e in i)
      Object.prototype.hasOwnProperty.call(i, e) && i[e].setValueRange(t, r, n);
};
M.prototype.isActive = function() {
  return !this.activator || this.activator.active;
};
M.prototype.setSize = function() {
  return this.canvas.setSize.apply(this.canvas, arguments);
};
M.prototype.canvasToDOM = function() {
  return this.canvas.canvasToDOM.apply(this.canvas, arguments);
};
M.prototype.DOMtoCanvas = function() {
  return this.canvas.DOMtoCanvas.apply(this.canvas, arguments);
};
M.prototype.findNode = function() {
  return this.clustering.findNode.apply(this.clustering, arguments);
};
M.prototype.isCluster = function() {
  return this.clustering.isCluster.apply(this.clustering, arguments);
};
M.prototype.openCluster = function() {
  return this.clustering.openCluster.apply(this.clustering, arguments);
};
M.prototype.cluster = function() {
  return this.clustering.cluster.apply(this.clustering, arguments);
};
M.prototype.getNodesInCluster = function() {
  return this.clustering.getNodesInCluster.apply(this.clustering, arguments);
};
M.prototype.clusterByConnection = function() {
  return this.clustering.clusterByConnection.apply(this.clustering, arguments);
};
M.prototype.clusterByHubsize = function() {
  return this.clustering.clusterByHubsize.apply(this.clustering, arguments);
};
M.prototype.updateClusteredNode = function() {
  return this.clustering.updateClusteredNode.apply(this.clustering, arguments);
};
M.prototype.getClusteredEdges = function() {
  return this.clustering.getClusteredEdges.apply(this.clustering, arguments);
};
M.prototype.getBaseEdge = function() {
  return this.clustering.getBaseEdge.apply(this.clustering, arguments);
};
M.prototype.getBaseEdges = function() {
  return this.clustering.getBaseEdges.apply(this.clustering, arguments);
};
M.prototype.updateEdge = function() {
  return this.clustering.updateEdge.apply(this.clustering, arguments);
};
M.prototype.clusterOutliers = function() {
  return this.clustering.clusterOutliers.apply(this.clustering, arguments);
};
M.prototype.getSeed = function() {
  return this.layoutEngine.getSeed.apply(this.layoutEngine, arguments);
};
M.prototype.enableEditMode = function() {
  return this.manipulation.enableEditMode.apply(this.manipulation, arguments);
};
M.prototype.disableEditMode = function() {
  return this.manipulation.disableEditMode.apply(this.manipulation, arguments);
};
M.prototype.addNodeMode = function() {
  return this.manipulation.addNodeMode.apply(this.manipulation, arguments);
};
M.prototype.editNode = function() {
  return this.manipulation.editNode.apply(this.manipulation, arguments);
};
M.prototype.editNodeMode = function() {
  return console.warn("Deprecated: Please use editNode instead of editNodeMode."), this.manipulation.editNode.apply(this.manipulation, arguments);
};
M.prototype.addEdgeMode = function() {
  return this.manipulation.addEdgeMode.apply(this.manipulation, arguments);
};
M.prototype.editEdgeMode = function() {
  return this.manipulation.editEdgeMode.apply(this.manipulation, arguments);
};
M.prototype.deleteSelected = function() {
  return this.manipulation.deleteSelected.apply(this.manipulation, arguments);
};
M.prototype.getPositions = function() {
  return this.nodesHandler.getPositions.apply(this.nodesHandler, arguments);
};
M.prototype.getPosition = function() {
  return this.nodesHandler.getPosition.apply(this.nodesHandler, arguments);
};
M.prototype.storePositions = function() {
  return this.nodesHandler.storePositions.apply(this.nodesHandler, arguments);
};
M.prototype.moveNode = function() {
  return this.nodesHandler.moveNode.apply(this.nodesHandler, arguments);
};
M.prototype.getBoundingBox = function() {
  return this.nodesHandler.getBoundingBox.apply(this.nodesHandler, arguments);
};
M.prototype.getConnectedNodes = function(i) {
  return this.body.nodes[i] !== void 0 ? this.nodesHandler.getConnectedNodes.apply(this.nodesHandler, arguments) : this.edgesHandler.getConnectedNodes.apply(this.edgesHandler, arguments);
};
M.prototype.getConnectedEdges = function() {
  return this.nodesHandler.getConnectedEdges.apply(this.nodesHandler, arguments);
};
M.prototype.startSimulation = function() {
  return this.physics.startSimulation.apply(this.physics, arguments);
};
M.prototype.stopSimulation = function() {
  return this.physics.stopSimulation.apply(this.physics, arguments);
};
M.prototype.stabilize = function() {
  return this.physics.stabilize.apply(this.physics, arguments);
};
M.prototype.getSelection = function() {
  return this.selectionHandler.getSelection.apply(this.selectionHandler, arguments);
};
M.prototype.setSelection = function() {
  return this.selectionHandler.setSelection.apply(this.selectionHandler, arguments);
};
M.prototype.getSelectedNodes = function() {
  return this.selectionHandler.getSelectedNodeIds.apply(this.selectionHandler, arguments);
};
M.prototype.getSelectedEdges = function() {
  return this.selectionHandler.getSelectedEdgeIds.apply(this.selectionHandler, arguments);
};
M.prototype.getNodeAt = function() {
  const i = this.selectionHandler.getNodeAt.apply(this.selectionHandler, arguments);
  return i !== void 0 && i.id !== void 0 ? i.id : i;
};
M.prototype.getEdgeAt = function() {
  const i = this.selectionHandler.getEdgeAt.apply(this.selectionHandler, arguments);
  return i !== void 0 && i.id !== void 0 ? i.id : i;
};
M.prototype.selectNodes = function() {
  return this.selectionHandler.selectNodes.apply(this.selectionHandler, arguments);
};
M.prototype.selectEdges = function() {
  return this.selectionHandler.selectEdges.apply(this.selectionHandler, arguments);
};
M.prototype.unselectAll = function() {
  this.selectionHandler.unselectAll.apply(this.selectionHandler, arguments), this.selectionHandler.commitWithoutEmitting.apply(this.selectionHandler), this.redraw();
};
M.prototype.redraw = function() {
  return this.renderer.redraw.apply(this.renderer, arguments);
};
M.prototype.getScale = function() {
  return this.view.getScale.apply(this.view, arguments);
};
M.prototype.getViewPosition = function() {
  return this.view.getViewPosition.apply(this.view, arguments);
};
M.prototype.fit = function() {
  return this.view.fit.apply(this.view, arguments);
};
M.prototype.moveTo = function() {
  return this.view.moveTo.apply(this.view, arguments);
};
M.prototype.focus = function() {
  return this.view.focus.apply(this.view, arguments);
};
M.prototype.releaseNode = function() {
  return this.view.releaseNode.apply(this.view, arguments);
};
M.prototype.getOptionsFromConfigurator = function() {
  let i = {};
  return this.configurator && (i = this.configurator.getOptions.apply(this.configurator)), i;
};
const mde = 500;
function bde(i, e, t) {
  const r = Object.keys(e.bus).length, n = r > mde;
  let o, s, a = /* @__PURE__ */ new Map();
  if (n) {
    const g = qS(e);
    o = g.nodes, s = g.edges, a = g.busAnnotations;
  } else {
    const g = KS(e);
    o = g.nodes, s = g.edges;
  }
  const l = n ? Math.max(5e3, r * 4) : 5e3, d = n ? Math.max(3e3, r * 2.5) : 3e3, c = Object.values(e.bus).some((g) => g.geo) ? QS(o, s, e, l, d) : t$(o, s, l, d), u = new bn(o.map((g) => {
    const p = c.get(g.id);
    return {
      id: g.id,
      label: n ? "" : g.label,
      title: g.title,
      x: p == null ? void 0 : p.x,
      y: p == null ? void 0 : p.y,
      color: {
        background: g.color,
        border: g.color,
        highlight: { background: q.highlight, border: q.highlight },
        hover: { background: q.hover, border: q.hover }
      },
      shape: g.shape,
      size: g.type === "ext_grid" ? 10 : 6,
      borderWidth: g.borderWidth,
      font: { color: "#fef6e9", size: n ? 0 : 12, strokeWidth: 0 },
      image: g.image
    };
  })), f = new bn(s.map((g) => ({
    id: g.id,
    from: g.from,
    to: g.to,
    label: n ? "" : g.label,
    title: g.title,
    color: {
      color: g.color.color,
      highlight: q.highlight,
      hover: q.hover
    },
    width: g.width,
    dashes: g.dashes,
    smooth: !1,
    font: { color: "#8b9a9d", size: n ? 0 : 10, strokeWidth: 0 }
  }))), v = {
    nodes: { font: { strokeWidth: 0 }, scaling: { label: { drawThreshold: 0 } } },
    edges: {
      smooth: !1,
      arrows: { to: { enabled: !1 }, from: { enabled: !1 } },
      font: { strokeWidth: 0 },
      scaling: { label: { drawThreshold: 0 } }
    },
    layout: { improvedLayout: !1, hierarchical: !1 },
    physics: { enabled: !1 },
    interaction: {
      hover: !n,
      tooltipDelay: 100,
      hideEdgesOnDrag: n,
      hideEdgesOnZoom: n,
      zoomView: !0,
      dragView: !0,
      dragNodes: !n
    }
  }, y = new M(i, { nodes: u, edges: f }, v);
  return y.on("click", (g) => {
    if (g.nodes.length > 0) {
      const p = g.nodes[0];
      let m;
      if (n && typeof p == "number")
        m = XS(p, e, a);
      else {
        const $ = o.find((w) => w.id === p || String(w.id) === String(p));
        $ && (m = sv($, e));
      }
      m && (t.innerHTML = `<div style="font-weight:600;margin-bottom:6px">${m.type}: ${m.name}</div>` + Object.entries(m.properties).map(
        ([$, w]) => `<div style="display:flex;justify-content:space-between;padding:2px 0;border-bottom:1px solid #333"><span style="color:#969696">${$}</span><span>${w}</span></div>`
      ).join(""), t.style.display = "block");
    } else if (g.edges.length > 0) {
      const p = s.find((m) => m.id === g.edges[0]);
      if (p) {
        const m = sv(p, e);
        t.innerHTML = `<div style="font-weight:600;margin-bottom:6px">${m.type}: ${m.name}</div>` + Object.entries(m.properties).map(
          ([$, w]) => `<div style="display:flex;justify-content:space-between;padding:2px 0;border-bottom:1px solid #333"><span style="color:#969696">${$}</span><span>${w}</span></div>`
        ).join(""), t.style.display = "block";
      }
    } else
      t.style.display = "none";
  }), setTimeout(() => {
    try {
      y.fit({ animation: !1 });
    } catch {
    }
  }, 100), y;
}
const xde = {
  render({ model: i, el: e }) {
    e.innerHTML = `
      <div style="display:flex;height:500px;background:#132026;border-radius:6px;overflow:hidden;font-family:'STIX Two Text',serif;font-size:13px;color:#fef6e9">
        <div id="ppviz-canvas" style="flex:1;position:relative"></div>
        <div id="ppviz-info" style="display:none;width:240px;padding:10px;overflow:auto;border-left:1px solid #2c3f48;background:#1a2a30"></div>
      </div>
      <div style="display:flex;justify-content:space-between;padding:4px 0;font-size:11px;color:#8b9a9d;font-family:'STIX Two Text',serif">
        <span id="ppviz-stats"></span>
        <span>pandapower-viz</span>
      </div>
    `;
    const t = e.querySelector("#ppviz-canvas"), r = e.querySelector("#ppviz-info"), n = e.querySelector("#ppviz-stats");
    let o = null;
    function s() {
      const a = i.get("network_json");
      if (a)
        try {
          const l = JSON.parse(a), d = GS(l), h = Object.keys(d.bus).length, c = Object.keys(d.line).length, u = Object.keys(d.trafo).length;
          n.textContent = `${h} buses · ${c} lines · ${u} trafos`, o && o.destroy(), o = bde(t, d, r);
        } catch (l) {
          t.innerHTML = `<div style="padding:20px;color:#ef4444">Error: ${l}</div>`;
        }
    }
    return i.on("change:network_json", s), s(), () => {
      o && o.destroy();
    };
  }
};
export {
  xde as default
};
