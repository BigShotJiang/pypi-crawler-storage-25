import logging
import os
import re
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path

import pdfplumber

logger = logging.getLogger(__name__)

MONTHS_FR = {
    "janvier": 1,
    "février": 2,
    "fevrier": 2,
    "mars": 3,
    "avril": 4,
    "mai": 5,
    "juin": 6,
    "juillet": 7,
    "août": 8,
    "aout": 8,
    "septembre": 9,
    "octobre": 10,
    "novembre": 11,
    "décembre": 12,
    "decembre": 12,
}

__all__ = ["extract_invoice_fields", "parse_many"]


def normalize(value: str) -> float:
    value = (
        value.replace("\u00a0", " ")  # NBSP → space
        .replace("\u202f", " ")  # narrow no-break space → space
        .replace("\n", "")  # PDF line-wrap artefact
        .replace(" ", "")  # remove thousand-separator spaces
        .replace(",", ".")
    )  # French decimal comma → point
    return float(value)


def parse_french_date(date_str: str) -> str | None:
    s = date_str.lower()
    s = (
        s.replace("é", "e")
        .replace("è", "e")
        .replace("ê", "e")
        .replace("à", "a")
        .replace("â", "a")
        .replace("î", "i")
        .replace("ï", "i")
        .replace("ô", "o")
        .replace("û", "u")
        .replace("ù", "u")
        .replace("ç", "c")
    )

    m = re.search(r"(\d{1,2})\s+([a-z]+)\s+(\d{4})", s)
    if not m:
        return None

    day, month_name, year = int(m.group(1)), m.group(2), int(m.group(3))
    month = MONTHS_FR.get(month_name)
    if not month:
        return None

    return datetime(year, month, day).strftime("%Y-%m-%d")


def extract_total_ttc(text: str) -> float | None:
    block = re.search(
        r"Total\s*€\s*HT.*?Total\s*€\s*TTC(.*)", text, flags=re.IGNORECASE | re.DOTALL
    )
    if not block:
        return None

    zone = block.group(1)
    amounts = re.findall(r"(\d{1,3}(?:[\s\u00A0\u202F]\d{3})*,\d{2})", zone)
    if len(amounts) < 3:
        return None

    return normalize(amounts[2])


def extract_invoice_fields(pdf_path: str) -> dict:
    name = Path(pdf_path).name
    logger.debug("Opening PDF: %s", pdf_path)

    try:
        with pdfplumber.open(pdf_path) as pdf:
            full_text = "\n".join((p.extract_text() or "") for p in pdf.pages)
    except Exception as exc:
        logger.error("Cannot open PDF %s — %s", name, exc, exc_info=True)
        raise

    ref_match = re.search(r"Référence\s*:\s*([^\r\n]+)", full_text, flags=re.IGNORECASE)
    reference_line = ref_match.group(1).strip() if ref_match else None
    reference = None
    if reference_line:
        reference = re.split(
            r"\s+\ble\s+\d{1,2}\s+[A-Za-zÀ-ÿ]+\s+\d{4}\b", reference_line, maxsplit=1
        )[0].strip()

    date_match = re.search(
        r"\ble\s+(\d{1,2}\s+[A-Za-zÀ-ÿ]+\s+\d{4})", full_text, flags=re.IGNORECASE
    )
    date_iso = parse_french_date(date_match.group(1)) if date_match else None

    total_ttc = extract_total_ttc(full_text)

    # Warn on every missing field so issues are immediately visible in logs
    if not reference:
        logger.warning("[%s] No client name found", name)
    if not date_iso:
        logger.warning("[%s] No date found", name)
    if total_ttc is None:
        logger.warning("[%s] No total TTC found", name)

    logger.info(
        "Parsed %-30s  client=%-15s  date=%s  ttc=%s",
        name,
        reference or "—",
        date_iso or "—",
        f"{total_ttc:.2f}" if total_ttc is not None else "—",
    )
    return {"Client": reference, "date": date_iso, "total_ttc": total_ttc}


_MAX_PARSE_WORKERS = max(
    1, (os.cpu_count() or 2) // 2
)  # half the cores — leaves headroom on laptops


LogRecord = tuple[int, str, str]  # (levelno, logger_name, message)


def _parse_one_worker(
    pdf_path: str,
) -> tuple[str, dict | Exception, list[LogRecord]]:
    """Top-level picklable function — runs in a worker process.

    Returns ``(pdf_path, result, log_records)`` where *result* is an invoice
    dict on success or the raised exception on failure.  *log_records* is a
    list of ``(levelno, logger_name, message)`` tuples collected during
    parsing — the caller is responsible for re-emitting them.
    """
    log_records: list[LogRecord] = []

    class _CollectHandler(logging.Handler):
        def emit(self, record: logging.LogRecord) -> None:
            try:
                log_records.append((record.levelno, record.name, record.getMessage()))
            except Exception:
                pass

    handler = _CollectHandler()
    handler.setLevel(logging.DEBUG)
    lg = logging.getLogger("ebia")
    lg.handlers.clear()
    lg.propagate = False
    lg.addHandler(handler)
    lg.setLevel(logging.DEBUG)

    try:
        return pdf_path, extract_invoice_fields(pdf_path), log_records
    except Exception as exc:
        return pdf_path, exc, log_records


def parse_many(
    pdf_paths: list[str],
    max_workers: int | None = None,
) -> list[tuple[str, dict | Exception, list[LogRecord]]]:
    """Parse multiple PDFs in parallel using worker processes.

    Returns a list of ``(pdf_path, result, log_records)`` triples in
    completion order, where *result* is either an invoice dict or the
    exception that was raised, and *log_records* are the logging calls made
    inside that worker (caller should re-emit them to get proper formatting).

    Args:
        pdf_paths: Absolute or relative paths to the PDF files to parse.
        max_workers: Maximum number of worker processes.  Defaults to
            ``min(_MAX_PARSE_WORKERS, os.cpu_count(), len(pdf_paths))``.
    """
    if not pdf_paths:
        return []

    n_workers = min(
        max_workers if max_workers is not None else _MAX_PARSE_WORKERS,
        os.cpu_count() or 1,
        len(pdf_paths),
    )

    results: list[tuple[str, dict | Exception, list[LogRecord]]] = []
    with ProcessPoolExecutor(max_workers=n_workers) as pool:
        futures = {pool.submit(_parse_one_worker, path): path for path in pdf_paths}
        for future in as_completed(futures):
            results.append(future.result())
    return results


def main(argv=None) -> int:  # pragma: no cover
    import argparse

    ap = argparse.ArgumentParser(prog="equipebaie-parse")
    ap.add_argument("pdf", help="Chemin vers la facture PDF")
    args = ap.parse_args(argv)

    print(extract_invoice_fields(args.pdf))
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
