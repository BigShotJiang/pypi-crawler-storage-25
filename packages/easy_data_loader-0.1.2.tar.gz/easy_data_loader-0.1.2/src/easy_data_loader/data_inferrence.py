from typing import Dict, Union, Optional
import pandas as pd
from sqlalchemy import types
import pyarrow as pa
import pyarrow.parquet as pq
import pyarrow.orc as orc
from pathlib import Path
import warnings

from .log import LoggedComponent


class SQLAlchemyDTypeInferrer(LoggedComponent):
    """
    Infers SQLAlchemy data types for DataFrame columns.

    On any error, logs the issue and returns empty dict to allow
    pandas/SQLAlchemy to use default type inference.

    Supported types:
    - SmallInteger: -32,768 to 32,767
    - Integer: -2,147,483,648 to 2,147,483,647
    - BigInteger: larger integers
    - Numeric: decimals with precision and scale
    - String: VARCHAR with length (max 4000)
    - Text: for strings > 4000 characters
    - DateTime: timestamp with optional timezone
    - Date: date only
    - Time: time only

    Boolean handling:
    - True/False strings → String
    - 1/0 integers → SmallInteger
    """

    # Static configuration
    STRING_LENGTH_BUFFER = 1.2  # 20% safety margin for character length
    BYTE_LENGTH_BUFFER = 2.0  # 2x for UTF-16 encoding (SQL Server NVARCHAR)
    MIN_STRING_LENGTH = 20  # Minimum VARCHAR length
    MAX_STRING_LENGTH = 4000  # Maximum VARCHAR before switching to Text

    DEFAULT_NUMERIC_PRECISION = 18  # Default precision for Numeric type
    DEFAULT_NUMERIC_SCALE = 6  # Default scale for Numeric type

    ASSUME_UNICODE = True  # Calculate lengths assuming Unicode encoding
    DETECT_DATETIME_STRINGS = True  # Try to detect datetime strings in object columns
    USE_UNICODE_STRINGS = (
        True  # If True, use Unicode types (e.g. NVARCHAR) for string columns
    )

    # Integer type ranges
    INT_RANGES = {
        "SmallInteger": (-32768, 32767),
        "Integer": (-2147483648, 2147483647),
        "BigInteger": (-9223372036854775808, 9223372036854775807),
    }

    def __init__(self):
        """Initialize with logging capability."""
        super().__init__()
        self.logger.info("SQLAlchemyDTypeInferrer initialized")

    def infer_from_dataframe(self, df: pd.DataFrame) -> Dict[str, types.TypeEngine]:
        """
        Infer SQLAlchemy types from DataFrame values.
        Analyzes all rows in the DataFrame.

        Args:
            df: pandas DataFrame

        Returns:
            Dictionary mapping column names to SQLAlchemy generic types.
            Returns empty dict on error (allows fallback to default inference).
        """
        try:
            self.logger.info(
                f"Starting dtype inference for DataFrame with {len(df)} rows and {len(df.columns)} columns"
            )

            dtype_dict = {}

            for col in df.columns:
                try:
                    self.logger.debug(f"Analyzing column: '{col}'")
                    dtype_dict[col] = self._infer_column_type(df[col], col)
                except Exception as e:
                    # Log error for this column but continue with others
                    self.logger.error(
                        f"Failed to infer dtype for column '{col}': {str(e)}. "
                        f"Column will use default inference.",
                        exc_info=self.is_debug_enabled,
                    )
                    # Skip this column - it will use default inference
                    continue

            if not dtype_dict:
                self.logger.warning(
                    "No dtypes were successfully inferred. "
                    "All columns will use default pandas/SQLAlchemy inference."
                )
                return {}

            self.logger.info(f"Dtype inference completed for {len(dtype_dict)} columns")

            # Log summary if debug enabled
            if self.is_debug_enabled:
                self._log_inference_summary(dtype_dict)

            return dtype_dict

        except Exception as e:
            # Catch-all for any unexpected errors
            self.logger.error(
                f"Dtype inference failed completely: {str(e)}. "
                f"Returning empty dict - will use default inference.",
                exc_info=True,
            )
            return {}

    def _infer_column_type(self, series: pd.Series, col_name: str) -> types.TypeEngine:
        """
        Infer SQLAlchemy type for a single column.

        Args:
            series: pandas Series
            col_name: column name for logging

        Returns:
            SQLAlchemy generic type

        Raises:
            Exception: Re-raises any exception to be caught by caller
        """
        # Remove null values for analysis
        non_null = series.dropna()
        null_count = len(series) - len(non_null)

        if null_count > 0:
            self.logger.debug(
                f"Column '{col_name}': {null_count} null values ({null_count / len(series) * 100:.1f}%)"
            )

        if len(non_null) == 0:
            # All nulls - default to String
            self.logger.warning(
                f"Column '{col_name}': All values are NULL, defaulting to String({self.MIN_STRING_LENGTH})"
            )
            return types.String(self.MIN_STRING_LENGTH)

        pandas_dtype = series.dtype
        self.logger.debug(f"Column '{col_name}': pandas dtype = {pandas_dtype}")

        # Check 1: Boolean dtype → SmallInteger (1/0)
        if pd.api.types.is_bool_dtype(series):
            self.logger.info(
                f"Column '{col_name}': Inferred as SmallInteger (boolean values as 1/0)"
            )
            return types.SmallInteger()

        # Check 2: Integer dtype
        elif pd.api.types.is_integer_dtype(series):
            return self._infer_integer_type(non_null, col_name)

        # Check 3: Float dtype → Numeric
        elif pd.api.types.is_float_dtype(series):
            return self._infer_numeric_type(non_null, col_name)

        # Check 4: Datetime64 dtype
        elif pd.api.types.is_datetime64_any_dtype(series):
            # Check if timezone-aware
            if hasattr(series.dtype, "tz") and series.dtype.tz is not None:
                self.logger.info(
                    f"Column '{col_name}': Inferred as DateTime (timezone-aware: {series.dtype.tz})"
                )
                return types.DateTime(timezone=True)
            self.logger.info(
                f"Column '{col_name}': Inferred as DateTime (timezone-naive)"
            )
            return types.DateTime(timezone=False)

        # Check 5: Timedelta64 dtype → BigInteger (microseconds)
        elif pd.api.types.is_timedelta64_dtype(series):
            self.logger.info(
                f"Column '{col_name}': Inferred as BigInteger (timedelta stored as microseconds)"
            )
            return types.BigInteger()

        # Check 6: Object dtype (requires value inspection)
        elif pd.api.types.is_object_dtype(series):
            self.logger.debug(
                f"Column '{col_name}': Object dtype detected, analyzing values"
            )
            return self._infer_object_type(non_null, col_name)

        # Check 7: String dtype (pandas StringDtype)
        elif pd.api.types.is_string_dtype(series):
            self.logger.debug(f"Column '{col_name}': String dtype detected")
            return self._infer_string_type(non_null, col_name)

        # Check 8: Fallback for unknown types
        else:
            self.logger.warning(
                f"Column '{col_name}': Unknown dtype {series.dtype}, converting to String"
            )
            return self._infer_string_type(non_null.astype(str), col_name)

    def _infer_integer_type(self, series: pd.Series, col_name: str) -> types.TypeEngine:
        """Infer the appropriate integer type based on value range."""
        min_val = series.min()
        max_val = series.max()

        self.logger.debug(
            f"Column '{col_name}': Integer range = [{min_val}, {max_val}]"
        )

        # Check if values fit in SmallInteger (-32,768 to 32,767)
        if (
            min_val >= self.INT_RANGES["SmallInteger"][0]
            and max_val <= self.INT_RANGES["SmallInteger"][1]
        ):
            self.logger.info(
                f"Column '{col_name}': Inferred as SmallInteger (range fits in -32,768 to 32,767)"
            )
            return types.SmallInteger()

        # Check if values fit in Integer (-2,147,483,648 to 2,147,483,647)
        elif (
            min_val >= self.INT_RANGES["Integer"][0]
            and max_val <= self.INT_RANGES["Integer"][1]
        ):
            self.logger.info(
                f"Column '{col_name}': Inferred as Integer (range fits in -2,147,483,648 to 2,147,483,647)"
            )
            return types.Integer()

        # Use BigInteger for larger values
        else:
            self.logger.info(
                f"Column '{col_name}': Inferred as BigInteger (values exceed Integer range)"
            )
            return types.BigInteger()

    def _infer_numeric_type(self, series: pd.Series, col_name: str) -> types.TypeEngine:
        """
        Infer the appropriate numeric type for a numeric column.
        Handles integers stored as float64 due to NaN values.
        """

        # Remove NaN values for analysis
        non_null_series = series.dropna()

        if len(non_null_series) == 0:
            self.logger.warning(
                f"Column '{col_name}': All values are NULL. Defaulting to Numeric."
            )
            return types.Numeric()

        # Check if values are actually integers (even if dtype is float)
        is_integer = (non_null_series == non_null_series.astype(int)).all()

        if is_integer:
            # Treat as integer type
            int_series = non_null_series.astype(int)
            min_val = int_series.min()
            max_val = int_series.max()

            if -32_768 <= min_val and max_val <= 32_767:
                self.logger.info(
                    f"Column '{col_name}': Inferred as SmallInteger "
                    f"(range: {min_val} to {max_val})"
                )
                return types.SmallInteger()
            elif -2_147_483_648 <= min_val and max_val <= 2_147_483_647:
                self.logger.info(
                    f"Column '{col_name}': Inferred as Integer "
                    f"(range: {min_val} to {max_val})"
                )
                return types.Integer()
            else:
                self.logger.info(
                    f"Column '{col_name}': Inferred as BigInteger "
                    f"(range: {min_val} to {max_val})"
                )
                return types.BigInteger()

        # Not integer - analyze as decimal/numeric
        str_series = non_null_series.astype(str)

        max_precision = 0
        max_scale = 0

        for value_str in str_series:
            if "." in value_str:
                parts = value_str.split(".")
                integer_part = parts[0].lstrip("-")
                decimal_part = parts[1] if len(parts) > 1 else ""

                precision = len(integer_part) + len(decimal_part)
                scale = len(decimal_part)
            else:
                precision = len(value_str.lstrip("-"))
                scale = 0

            max_precision = max(max_precision, precision)
            max_scale = max(max_scale, scale)

        # Add safety buffer
        safe_precision = max_precision + 2
        safe_scale = max_scale

        self.logger.info(
            f"Column '{col_name}': Inferred as Numeric({safe_precision}, {safe_scale}) "
            f"(detected: precision={max_precision}, scale={max_scale}, added safety buffer)"
        )

        return types.Numeric(precision=safe_precision, scale=safe_scale)

    def _infer_object_type(self, series: pd.Series, col_name: str) -> types.TypeEngine:
        """Infer type for object dtype columns."""
        # Get a sample for type checking
        sample = series.iloc[0] if len(series) > 0 else None

        if sample is None:
            self.logger.warning(
                f"Column '{col_name}': Object column with no valid sample, defaulting to String"
            )
            return types.String(self.MIN_STRING_LENGTH)

        sample_type = type(sample).__name__
        self.logger.debug(
            f"Column '{col_name}': Object column sample type = {sample_type}"
        )

        # Check 1: Python datetime objects
        if isinstance(sample, pd.Timestamp):
            self.logger.info(
                f"Column '{col_name}': Inferred as DateTime (contains pd.Timestamp objects)"
            )
            return types.DateTime()

        if hasattr(sample, "__class__"):
            class_name = sample.__class__.__name__

            # Check 2: Python date objects (datetime.date)
            if class_name == "date":
                self.logger.info(
                    f"Column '{col_name}': Inferred as Date (contains datetime.date objects)"
                )
                return types.Date()

            # Check 3: Python time objects (datetime.time)
            if class_name == "time":
                self.logger.info(
                    f"Column '{col_name}': Inferred as Time (contains datetime.time objects)"
                )
                return types.Time()

        # For string-like objects, try various detections
        if isinstance(sample, str):
            # Check 4: Datetime strings
            if self.DETECT_DATETIME_STRINGS:
                try:
                    if self._is_datetime_string(series, col_name):
                        return types.DateTime()

                    if self._is_date_string(series, col_name):
                        return types.Date()
                except Exception as e:
                    self.logger.debug(
                        f"Column '{col_name}': Date/datetime detection failed: {str(e)}"
                    )

            # Check 5: Numeric strings (integers or decimals)
            try:
                numeric_result = self._try_numeric_string(series, col_name)
                if numeric_result is not None:
                    return numeric_result
            except Exception as e:
                self.logger.debug(
                    f"Column '{col_name}': Numeric string detection failed: {str(e)}"
                )

        # Check 6: Default to String
        self.logger.debug(f"Column '{col_name}': Falling back to String type analysis")
        return self._infer_string_type(series.astype(str), col_name)

    def _is_datetime_string(self, series: pd.Series, col_name: str) -> bool:
        """Check if series contains datetime-like strings."""
        sample = series.dropna()
        if len(sample) == 0:
            return False

        with warnings.catch_warnings():
            warnings.simplefilter("ignore", UserWarning)
            parsed = pd.to_datetime(sample, errors="coerce")
        success_rate = parsed.notna().mean()

        self.logger.debug(
            f"Column '{col_name}': Datetime string detection - {success_rate * 100:.1f}% parseable"
        )

        if success_rate <= 0.9:
            return False

        # Check if any have non-midnight time component
        has_time = (parsed.dt.time != pd.Timestamp("00:00:00").time()).any()

        if has_time:
            self.logger.info(
                f"Column '{col_name}': Inferred as DateTime (detected datetime strings with time component)"
            )
            return True

        return False

    def _is_date_string(self, series: pd.Series, col_name: str) -> bool:
        """Check if series contains date-only strings."""
        sample = series.dropna()
        if len(sample) == 0:
            return False

        with warnings.catch_warnings():
            warnings.simplefilter("ignore", UserWarning)
            parsed = pd.to_datetime(sample, errors="coerce")
        success_rate = parsed.notna().mean()

        if success_rate <= 0.9:
            return False

        # All times should be midnight for date-only
        all_midnight = (parsed.dt.time == pd.Timestamp("00:00:00").time()).all()

        if all_midnight:
            self.logger.info(
                f"Column '{col_name}': Inferred as Date (detected date-only strings)"
            )
            return True

        return False

    def _try_numeric_string(
        self, series: pd.Series, col_name: str
    ) -> Optional[types.TypeEngine]:
        """Try to parse series as numeric strings."""
        sample = series.dropna()
        if len(sample) == 0:
            return None

        # Try to convert to numeric
        converted = pd.to_numeric(sample, errors="coerce")
        success_rate = converted.notna().mean()

        self.logger.debug(
            f"Column '{col_name}': Numeric string detection - {success_rate * 100:.1f}% parseable"
        )

        if success_rate <= 0.9:
            return None

        # Check if all are integers (no decimal points in strings)
        has_decimal = sample.astype(str).str.contains(r"\.", regex=True).any()

        if not has_decimal:
            # Integer strings - determine range
            int_series = converted.astype("int64")
            self.logger.info(
                f"Column '{col_name}': Detected as numeric strings (integers)"
            )
            return self._infer_integer_type(int_series, col_name)
        else:
            # Decimal strings - use Numeric
            self.logger.info(
                f"Column '{col_name}': Detected as numeric strings (decimals)"
            )
            return self._infer_numeric_type(converted, col_name)

    def _infer_string_type(self, series: pd.Series, col_name: str) -> types.TypeEngine:
        """Infer appropriate string type based on max length."""

        # Convert to string if not already (handle object dtype)
        if series.dtype != "object" and str(series.dtype) != "str":
            # Only warn if it's NOT object/str (which would be unusual)
            self.logger.warning(
                f"Column '{col_name}': Unexpected dtype {series.dtype}, converting to String"
            )
            series = series.astype(str)

        # Calculate character length
        char_lengths = series.str.len()
        max_char_length = char_lengths.max()

        if pd.isna(max_char_length):
            max_char_length = self.MIN_STRING_LENGTH
        else:
            max_char_length = int(max_char_length)

        self.logger.debug(
            f"Column '{col_name}': Max character length = {max_char_length}"
        )

        # Calculate byte length if assuming unicode
        if self.ASSUME_UNICODE:
            # Calculate byte length for all values
            byte_lengths = series.apply(lambda x: len(str(x).encode("utf-8")))
            max_byte_length = byte_lengths.max()

            if pd.isna(max_byte_length):
                max_byte_length = max_char_length

            self.logger.debug(
                f"Column '{col_name}': Max byte length (UTF-8) = {max_byte_length}"
            )

            # Use the larger of char-based or byte-based estimation
            char_based = int(max_char_length * self.BYTE_LENGTH_BUFFER)
            byte_based = int(max_byte_length * self.STRING_LENGTH_BUFFER)
            estimated_length = max(char_based, byte_based)

            self.logger.debug(
                f"Column '{col_name}': Estimated length = {estimated_length} "
                f"(char-based={char_based}, byte-based={byte_based})"
            )
        else:
            # Just use character length with buffer
            estimated_length = int(max_char_length * self.STRING_LENGTH_BUFFER)

        # Ensure minimum length
        estimated_length = max(estimated_length, self.MIN_STRING_LENGTH)

        # Use Text for strings > 4000 characters
        if estimated_length > self.MAX_STRING_LENGTH:
            self.logger.info(
                f"Column '{col_name}': Inferred as Text "
                f"(estimated length {estimated_length} exceeds max VARCHAR length {self.MAX_STRING_LENGTH})"
            )
            return types.Text()

        self.logger.info(
            f"Column '{col_name}': Inferred as String({estimated_length}) "
            f"(max char length={max_char_length}, with safety buffers)"
        )
        return (
            types.Unicode(estimated_length)
            if self.USE_UNICODE_STRINGS
            else types.String(estimated_length)
        )

    def infer_from_parquet(
        self, file_path: Union[str, Path]
    ) -> Dict[str, types.TypeEngine]:
        """
        Infer SQLAlchemy types from Parquet file metadata.

        Args:
            file_path: Path to Parquet file

        Returns:
            Dictionary mapping column names to SQLAlchemy generic types.
            Returns empty dict on error (allows fallback to default inference).
        """
        try:
            file_path = Path(file_path)
            self.logger.info(f"Starting dtype inference from Parquet file: {file_path}")

            parquet_file = pq.ParquetFile(file_path)
            schema = parquet_file.schema_arrow

            self.logger.info(f"Parquet file has {len(schema)} columns")

            dtype_dict = {}
            string_columns = []

            for i in range(len(schema)):
                try:
                    field = schema.field(i)
                    col_name = field.name
                    pa_type = field.type

                    self.logger.debug(f"Column '{col_name}': PyArrow type = {pa_type}")

                    sql_type = self._pyarrow_to_sqlalchemy(pa_type, col_name)

                    # If it's a String type without length, mark for length analysis
                    if isinstance(sql_type, types.String) and sql_type.length is None:
                        string_columns.append(col_name)
                        self.logger.debug(
                            f"Column '{col_name}': Marked for string length analysis"
                        )

                    dtype_dict[col_name] = sql_type

                except Exception as e:
                    self.logger.error(
                        f"Failed to infer dtype for column '{col_name}' from Parquet metadata: {str(e)}. "
                        f"Column will use default inference.",
                        exc_info=self.is_debug_enabled,
                    )
                    continue

            # Read string columns to determine proper lengths
            if string_columns:
                try:
                    self.logger.info(
                        f"Reading {len(string_columns)} string columns for length analysis"
                    )
                    df_strings = pq.read_table(
                        file_path, columns=string_columns
                    ).to_pandas()

                    for col in string_columns:
                        try:
                            dtype_dict[col] = self._infer_string_type(
                                df_strings[col].astype(str), col
                            )
                        except Exception as e:
                            self.logger.error(
                                f"Failed to analyze string length for column '{col}': {str(e)}. "
                                f"Column will use default inference.",
                                exc_info=self.is_debug_enabled,
                            )
                            # Remove from dict so it uses default
                            dtype_dict.pop(col, None)
                            continue

                except Exception as e:
                    self.logger.error(
                        f"Failed to read string columns from Parquet: {str(e)}. "
                        f"String columns will use default inference.",
                        exc_info=self.is_debug_enabled,
                    )
                    # Remove string columns from dict
                    for col in string_columns:
                        dtype_dict.pop(col, None)

            if not dtype_dict:
                self.logger.warning(
                    "No dtypes were successfully inferred from Parquet. "
                    "All columns will use default pandas/SQLAlchemy inference."
                )
                return {}

            self.logger.info(
                f"Parquet dtype inference completed for {len(dtype_dict)} columns"
            )

            if self.is_debug_enabled:
                self._log_inference_summary(dtype_dict)

            return dtype_dict

        except Exception as e:
            self.logger.error(
                f"Failed to infer dtypes from Parquet file '{file_path}': {str(e)}. "
                f"Returning empty dict - will use default inference.",
                exc_info=True,
            )
            return {}

    def infer_from_orc(
        self, file_path: Union[str, Path]
    ) -> Dict[str, types.TypeEngine]:
        """
        Infer SQLAlchemy types from ORC file metadata.

        Args:
            file_path: Path to ORC file

        Returns:
            Dictionary mapping column names to SQLAlchemy generic types.
            Returns empty dict on error (allows fallback to default inference).
        """
        try:
            file_path = Path(file_path)
            self.logger.info(f"Starting dtype inference from ORC file: {file_path}")

            orc_file = orc.ORCFile(file_path)
            schema = orc_file.schema

            self.logger.info(f"ORC file has {len(schema)} columns")

            dtype_dict = {}
            string_columns = []

            for i in range(len(schema)):
                try:
                    field = schema.field(i)
                    col_name = field.name
                    pa_type = field.type

                    self.logger.debug(f"Column '{col_name}': PyArrow type = {pa_type}")

                    sql_type = self._pyarrow_to_sqlalchemy(pa_type, col_name)

                    if isinstance(sql_type, types.String) and sql_type.length is None:
                        string_columns.append(col_name)
                        self.logger.debug(
                            f"Column '{col_name}': Marked for string length analysis"
                        )

                    dtype_dict[col_name] = sql_type

                except Exception as e:
                    self.logger.error(
                        f"Failed to infer dtype for column '{col_name}' from ORC metadata: {str(e)}. "
                        f"Column will use default inference.",
                        exc_info=self.is_debug_enabled,
                    )
                    continue

            # Read string columns for length analysis
            if string_columns:
                try:
                    self.logger.info(
                        f"Reading {len(string_columns)} string columns for length analysis"
                    )
                    df_strings = orc.read_table(
                        file_path, columns=string_columns
                    ).to_pandas()

                    for col in string_columns:
                        try:
                            dtype_dict[col] = self._infer_string_type(
                                df_strings[col].astype(str), col
                            )
                        except Exception as e:
                            self.logger.error(
                                f"Failed to analyze string length for column '{col}': {str(e)}. "
                                f"Column will use default inference.",
                                exc_info=self.is_debug_enabled,
                            )
                            dtype_dict.pop(col, None)
                            continue

                except Exception as e:
                    self.logger.error(
                        f"Failed to read string columns from ORC: {str(e)}. "
                        f"String columns will use default inference.",
                        exc_info=self.is_debug_enabled,
                    )
                    for col in string_columns:
                        dtype_dict.pop(col, None)

            if not dtype_dict:
                self.logger.warning(
                    "No dtypes were successfully inferred from ORC. "
                    "All columns will use default pandas/SQLAlchemy inference."
                )
                return {}

            self.logger.info(
                f"ORC dtype inference completed for {len(dtype_dict)} columns"
            )

            if self.is_debug_enabled:
                self._log_inference_summary(dtype_dict)

            return dtype_dict

        except Exception as e:
            self.logger.error(
                f"Failed to infer dtypes from ORC file '{file_path}': {str(e)}. "
                f"Returning empty dict - will use default inference.",
                exc_info=True,
            )
            return {}

    def _pyarrow_to_sqlalchemy(
        self, pa_type: pa.DataType, col_name: str
    ) -> types.TypeEngine:
        """Convert PyArrow type to SQLAlchemy generic type."""
        # Boolean → SmallInteger (1/0)
        if pa.types.is_boolean(pa_type):
            self.logger.debug(f"Column '{col_name}': PyArrow Boolean → SmallInteger")
            return types.SmallInteger()

        # Integer types
        elif pa.types.is_int8(pa_type) or pa.types.is_int16(pa_type):
            self.logger.debug(f"Column '{col_name}': PyArrow {pa_type} → SmallInteger")
            return types.SmallInteger()
        elif pa.types.is_int32(pa_type):
            self.logger.debug(f"Column '{col_name}': PyArrow Int32 → Integer")
            return types.Integer()
        elif pa.types.is_int64(pa_type):
            self.logger.debug(f"Column '{col_name}': PyArrow Int64 → BigInteger")
            return types.BigInteger()

        # Unsigned integers - use next larger signed type
        elif pa.types.is_uint8(pa_type):
            self.logger.debug(f"Column '{col_name}': PyArrow UInt8 → SmallInteger")
            return types.SmallInteger()
        elif pa.types.is_uint16(pa_type):
            self.logger.debug(f"Column '{col_name}': PyArrow UInt16 → Integer")
            return types.Integer()
        elif pa.types.is_uint32(pa_type):
            self.logger.debug(f"Column '{col_name}': PyArrow UInt32 → BigInteger")
            return types.BigInteger()
        elif pa.types.is_uint64(pa_type):
            self.logger.debug(f"Column '{col_name}': PyArrow UInt64 → Numeric(20, 0)")
            return types.Numeric(precision=20, scale=0)

        # Float types → Numeric
        elif pa.types.is_float32(pa_type) or pa.types.is_float64(pa_type):
            self.logger.debug(
                f"Column '{col_name}': PyArrow {pa_type} → "
                f"Numeric({self.DEFAULT_NUMERIC_PRECISION}, {self.DEFAULT_NUMERIC_SCALE})"
            )
            return types.Numeric(
                precision=self.DEFAULT_NUMERIC_PRECISION,
                scale=self.DEFAULT_NUMERIC_SCALE,
            )

        # Decimal → Numeric with exact precision
        elif pa.types.is_decimal(pa_type):
            self.logger.debug(
                f"Column '{col_name}': PyArrow Decimal → Numeric({pa_type.precision}, {pa_type.scale})"
            )
            return types.Numeric(precision=pa_type.precision, scale=pa_type.scale)

        # String types
        elif pa.types.is_string(pa_type) or pa.types.is_unicode(pa_type):
            self.logger.debug(
                f"Column '{col_name}': PyArrow String → String (length TBD)"
            )
            return types.String()  # Length will be determined by data
        elif pa.types.is_large_string(pa_type) or pa.types.is_large_unicode(pa_type):
            self.logger.debug(f"Column '{col_name}': PyArrow LargeString → Text")
            return types.Text()

        # Binary types → Text
        elif pa.types.is_binary(pa_type) or pa.types.is_large_binary(pa_type):
            self.logger.debug(f"Column '{col_name}': PyArrow Binary → Text")
            return types.Text()

        # Date and time types
        elif pa.types.is_date(pa_type):
            self.logger.debug(f"Column '{col_name}': PyArrow Date → Date")
            return types.Date()
        elif pa.types.is_time(pa_type):
            self.logger.debug(f"Column '{col_name}': PyArrow Time → Time")
            return types.Time()
        elif pa.types.is_timestamp(pa_type):
            if pa_type.tz is not None:
                self.logger.debug(
                    f"Column '{col_name}': PyArrow Timestamp → DateTime (timezone: {pa_type.tz})"
                )
                return types.DateTime(timezone=True)
            self.logger.debug(
                f"Column '{col_name}': PyArrow Timestamp → DateTime (no timezone)"
            )
            return types.DateTime(timezone=False)
        elif pa.types.is_duration(pa_type):
            self.logger.debug(
                f"Column '{col_name}': PyArrow Duration → BigInteger (microseconds)"
            )
            return types.BigInteger()

        # Complex types → Text
        elif (
            pa.types.is_list(pa_type)
            or pa.types.is_large_list(pa_type)
            or pa.types.is_struct(pa_type)
            or pa.types.is_map(pa_type)
        ):
            self.logger.info(
                f"Column '{col_name}': PyArrow complex type {pa_type} → Text (will be serialized as JSON)"
            )
            return types.Text()

        # Fallback for unknown types
        else:
            self.logger.warning(
                f"Column '{col_name}': Unknown PyArrow type {pa_type}, defaulting to Text"
            )
            return types.Text()

    def _log_inference_summary(self, dtype_dict: Dict[str, types.TypeEngine]):
        """Log a summary of inferred types (only in debug mode)."""
        type_counts: dict[str, list] = {}
        for col, dtype in dtype_dict.items():
            type_name = type(dtype).__name__
            if type_name not in type_counts:
                type_counts[type_name] = []
            type_counts[type_name].append(col)

        self.logger.debug("=== Dtype Inference Summary ===")
        for type_name, columns in sorted(type_counts.items()):
            self.logger.debug(f"{type_name}: {len(columns)} columns")
            for col in columns:
                dtype = dtype_dict[col]
                if hasattr(dtype, "length") and dtype.length:
                    self.logger.debug(f"  - {col}: {type_name}({dtype.length})")
                elif hasattr(dtype, "precision") and hasattr(dtype, "scale"):
                    self.logger.debug(
                        f"  - {col}: {type_name}({dtype.precision}, {dtype.scale})"
                    )
                else:
                    self.logger.debug(f"  - {col}: {type_name}")
