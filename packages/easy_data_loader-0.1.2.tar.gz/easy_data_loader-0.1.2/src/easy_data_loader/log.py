import logging
import logging.handlers
from pathlib import Path
from typing import NoReturn


class AppLogger:
    _instance = None
    _initialized = False

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        if not self._initialized:
            self._setup_logging()
            AppLogger._initialized = True

    def _setup_logging(self):
        Path("logs").mkdir(exist_ok=True)

        formatter = logging.Formatter(
            "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )

        root_logger = logging.getLogger()
        root_logger.setLevel(logging.INFO)
        root_logger.handlers.clear()

        # Console
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(formatter)
        root_logger.addHandler(console_handler)

        # File
        file_handler = logging.handlers.RotatingFileHandler(
            "logs/application.log", maxBytes=10 * 1024 * 1024, backupCount=5
        )
        file_handler.setFormatter(formatter)
        root_logger.addHandler(file_handler)

    def get_logger(self, name: str) -> logging.Logger:
        return logging.getLogger(name)

    def set_level(self, level: str):
        """Change log level (DEBUG, INFO, WARNING, ERROR, CRITICAL)"""

        log_level = getattr(logging, level.upper())
        logging.getLogger().setLevel(log_level)

        # Update all handlers
        for handler in logging.getLogger().handlers:
            handler.setLevel(log_level)

    @property
    def is_debug(self) -> bool:
        return logging.getLogger().isEnabledFor(logging.DEBUG)


class LoggedComponent:
    """Base class providing logging functionality to all components"""

    def __init__(self):
        self.log = AppLogger()
        self.logger = self.log.get_logger(self.__class__.__name__)

    def log_and_raise(self, exception_class, message: str = "", **context) -> NoReturn:
        """Log error message and raise exception with optional context"""
        if context:
            context_str = ", ".join(f"{k}={v}" for k, v in context.items())
            self.logger.error(f"{message} | Context: {context_str}")
        else:
            self.logger.error(message)

        raise exception_class(message)

    def log_exception(self, exc: Exception, message: str = "", **context):
        """Log a caught exception with optional context"""
        log_msg = message or f"Exception occurred: {str(exc)}"
        if context:
            context_str = ", ".join(f"{k}={v}" for k, v in context.items())
            log_msg += f" | Context: {context_str}"

        self.logger.error(log_msg, exc_info=True)

    @property
    def is_debug_enabled(self) -> bool:
        return self.log.is_debug
