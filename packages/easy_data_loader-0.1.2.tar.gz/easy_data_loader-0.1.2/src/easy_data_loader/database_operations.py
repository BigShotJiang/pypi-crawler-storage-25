from typing import Dict

import pandas as pd
from pandas import DataFrame
from sqlalchemy import Column, MetaData, Table, inspect, text
from sqlalchemy.engine import Engine
from sqlalchemy.types import TypeEngine
from sqlalchemy.schema import SchemaItem

from .log import LoggedComponent
from .models import AuditEntry


class DatabaseOperations(LoggedComponent):
    """Component responsible for all SQL interactions using SQLAlchemy engines"""

    def __init__(self, engine: Engine):
        super().__init__()
        self.engine = engine
        self._inspector = inspect(self.engine)

    def write_to_table(self, table_name: str, df: DataFrame, **kwargs) -> bool:
        """Write a dataframe to a specified table in the database"""

        self.logger.info(f"Writing {len(df)} rows to table: {table_name}")
        try:
            df.to_sql(table_name, con=self.engine, **kwargs)
            return True
        except Exception as e:
            self.log_exception(e, f"Failed to write to table {table_name}")
            raise

    def read_data(self, sql: str, **kwargs) -> DataFrame:
        """Read a specified table from the database into a dataframe"""

        self.logger.debug("Reading data.")
        try:
            return pd.read_sql(sql, con=self.engine, **kwargs)
        except Exception as e:
            self.log_exception(e, "Failed to read data")
            raise

    def inspect_table(self, table_name: str) -> dict:
        """Read the metadata (columns and types) of a specified table"""

        self.logger.debug(f"Inspecting metadata for table: {table_name}")
        try:
            columns = self._inspector.get_columns(table_name)
            if not columns:
                self.logger.warning(f"Table {table_name} not found or has no columns.")
                return {}

            return {col["name"]: str(col["type"]) for col in columns}
        except Exception as e:
            self.log_exception(e, f"Failed to inspect table {table_name}")
            return {}

    def create_table(self, table_name: str, schema: Dict[str, TypeEngine]) -> bool:
        """
        Create a table dynamically.
        schema: {'col_name': sqlalchemy_type}
        """
        self.logger.info(f"Creating table: {table_name}")
        try:
            metadata = MetaData()
            columns: list[SchemaItem] = [
                Column(name, col_type) for name, col_type in schema.items()
            ]
            Table(table_name, metadata, *columns)

            metadata.create_all(self.engine)
            return True
        except Exception as e:
            self.log_exception(e, f"Failed to create table {table_name}")
            return False

    def execute_stored_procedure(self, procedure_name: str, **kwargs) -> bool:
        """Execute a stored procedure using the engine connection"""
        self.logger.info(f"Executing stored procedure: {procedure_name}")
        try:
            params_str = ", ".join([f":{k}" for k in kwargs.keys()])
            sql = text(f"EXEC {procedure_name} {params_str}")

            with self.engine.begin() as conn:
                # self.engine.begin() is a context manager for the transaction
                # if no error occurs the transaction gets commited
                conn.execute(sql, kwargs)
            return True
        except Exception as e:
            self.log_exception(e, f"Failed to execute procedure {procedure_name}")
            raise

    def write_audit(self, table_name: str, entry: AuditEntry):
        """Write an audit entry to the database, ensuring the table exists first."""
        self.logger.debug(f"Writing audit entry for execution: {entry.execution_id}")

        try:
            from sqlalchemy import (
                BigInteger,
                Column,
                DateTime,
                Integer,
                MetaData,
                String,
                Table,
            )

            metadata = MetaData()

            columns: list[SchemaItem] = [
                Column("execution_id", String(50), primary_key=True),
                Column("pipeline_name", String(100)),
                Column("status", String(50)),
                Column("input_rows", Integer),
                Column("output_rows", Integer),
                Column("source_name", String(255)),
                Column("destination_name", String(255)),
                Column("file_name", String(255)),
                Column("file_path", String(500)),
                Column("file_size_bytes", BigInteger),
                Column("file_last_modified", DateTime),
                Column("sp_name", String(255)),
                Column("sp_parameters", String),
                Column("timestamp", DateTime),
                Column("error_details", String),
            ]

            Table(table_name, metadata, *columns)
            metadata.create_all(self.engine)

            data = entry.model_dump()
            # Serialize dictionary fields for storage
            if data.get("sp_parameters"):
                import json

                try:
                    data["sp_parameters"] = json.dumps(
                        data["sp_parameters"], default=str
                    )
                except Exception:
                    data["sp_parameters"] = str(data["sp_parameters"])
            df = pd.DataFrame([data])

            df.to_sql(table_name, con=self.engine, if_exists="append", index=False)

        except Exception as e:
            self.log_exception(e, f"Failed to write audit entry to {table_name}")
            raise
