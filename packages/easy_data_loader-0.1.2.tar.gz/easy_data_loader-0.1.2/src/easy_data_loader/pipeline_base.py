import uuid
from abc import ABC, abstractmethod
from typing import List, Optional, Union

import pandas as pd

from .config_loader import Configuration
from .database_connector import CONNECTOR_FACTORY, DatabaseConnector
from .database_operations import DatabaseOperations
from .log import LoggedComponent
from .models import (
    AuditEntry,
    BasePipelineDefinition,
    ProcedureDefinition,
    ServerType,
    ServerBasedConnectionSettings,
    FileBasedConnectionSettings,
)


class BasePipeline(LoggedComponent, ABC):
    """
    Abstract base class for all pipeline types.
    Handles:
    - Execution ID generation
    - Audit resource initialization
    - Shared resource cleanup
    """

    def __init__(self, definition: Union[BasePipelineDefinition, ProcedureDefinition]):
        super().__init__()
        self.definition = definition
        self.execution_id = str(uuid.uuid4())
        self.config = Configuration()

        self._active_connectors: List[DatabaseConnector] = []
        self.audit_db_ops: Optional[DatabaseOperations] = None

        # Metadata for auditing
        self.input_rows = 0
        self.output_rows = 0
        self.error_details: Optional[str] = None
        self.start_time = pd.Timestamp.now()

        self._initialize_audit_resource()

    def _initialize_audit_resource(self):
        """Initialize the database operations for auditing."""
        audit_resource_name = self.definition.audit

        if audit_resource_name:
            # External audit database
            resource = self.config.get_resource(audit_resource_name)
            if not isinstance(
                resource, (ServerBasedConnectionSettings, FileBasedConnectionSettings)
            ):
                self.log_and_raise(
                    ValueError,
                    f"Audit resource '{audit_resource_name}' must be a database connection.",
                )
            self.audit_db_ops = self._setup_db_operations(resource)
        else:
            # SQLite Fallback
            self.logger.info(
                "No audit resource defined. Falling back to SQLite audit.db"
            )
            sqlite_settings = FileBasedConnectionSettings(
                conn_server_type=ServerType.SQLITE,
                file_path="logs/audit.db",
            )
            self.audit_db_ops = self._setup_db_operations(sqlite_settings)

    def _setup_db_operations(
        self,
        settings: Union[ServerBasedConnectionSettings, FileBasedConnectionSettings],
    ) -> DatabaseOperations:
        """Helper to create the connector, store it for cleanup, and return the Ops."""
        server_type = settings.conn_server_type

        if server_type not in CONNECTOR_FACTORY:
            self.log_and_raise(ValueError, f"Unsupported server type: {server_type}")

        connector = CONNECTOR_FACTORY[server_type](settings)
        self._active_connectors.append(connector)
        return DatabaseOperations(connector.get_engine())

    def _cleanup(self):
        """Dispose of all active database connectors."""
        for connector in self._active_connectors:
            connector._dispose_engine()
        self.logger.debug("Pipeline cleanup completed.")

    def _log_audit(self, status: str):
        """Write the execution audit entry to the audit database."""
        if not self.audit_db_ops:
            return

        # Build file metadata dict before constructing the entry.
        # Pydantic v2 models are immutable by default, so we must pass
        # all fields at construction time rather than mutating afterward.
        file_meta = {}
        source_file = getattr(self, "source_file_path", None)
        if source_file:
            try:
                stat = source_file.stat()
                file_meta = {
                    "file_name": source_file.name,
                    "file_path": str(source_file),
                    "file_size_bytes": stat.st_size,
                    "file_last_modified": pd.Timestamp(stat.st_mtime, unit="s"),
                }
            except OSError as e:
                self.logger.warning(f"Could not read file metadata for audit: {e}")

        entry = AuditEntry(
            execution_id=self.execution_id,
            pipeline_name=self.definition.pipeline_name,
            status=status,
            input_rows=self.input_rows,
            output_rows=self.output_rows,
            source_name=getattr(self, "source_name", None),
            destination_name=getattr(self, "destination_name", None),
            sp_name=getattr(self, "sp_name", None),
            sp_parameters=getattr(self, "sp_parameters", None),
            timestamp=pd.Timestamp.now(),
            error_details=self.error_details,
            **file_meta,
        )

        try:
            self.audit_db_ops.write_audit("execution_audit", entry)
        except Exception as e:
            self.logger.error(f"Failed to write audit log: {str(e)}")

    @abstractmethod
    def run(self) -> bool:
        """Main execution logic to be implemented by child classes."""
        pass
