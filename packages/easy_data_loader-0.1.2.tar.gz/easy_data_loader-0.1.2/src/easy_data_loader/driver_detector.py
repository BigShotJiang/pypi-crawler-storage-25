from abc import ABC, abstractmethod

import pyodbc

from .custom_exceptions import DriverNotFoundException
from .log import LoggedComponent


class DriverDetector(ABC):
    @abstractmethod
    def get_available_drivers(self) -> list[str]:
        """Get list of available drivers."""
        pass

    @abstractmethod
    def select_preferred_driver(self) -> str:
        """Find the best available driver."""
        pass


class SqlServerDriverDetector(LoggedComponent, DriverDetector):
    def __init__(self):
        super().__init__()
        self._preferred_drivers = [
            "ODBC Driver 18 for SQL Server",
            "ODBC Driver 17 for SQL Server",
        ]

    def get_available_drivers(self) -> list[str]:
        """Get all available ODBC drivers."""
        drivers: list[str] = pyodbc.drivers()
        return drivers

    def select_preferred_driver(self) -> str:
        """Select first detected driver in order of preferrence."""

        available_drivers = self.get_available_drivers()

        for driver in self._preferred_drivers:
            if driver in available_drivers:
                return driver

        self.log_and_raise(
            DriverNotFoundException,
            available_drivers=available_drivers,
            preferred_drivers=self._preferred_drivers,
        )
