from pathlib import Path
from typing import Callable, Dict, Optional, Union
import pandas as pd
from sqlalchemy import types

from .log import LoggedComponent
from .models import FileSettings, FileType
from .data_inferrence import SQLAlchemyDTypeInferrer


class FileOperations(LoggedComponent):
    """Handles all file operations"""

    def __init__(self, settings: FileSettings):
        super().__init__()
        self.settings = settings
        self.file_type = self.settings.file_type
        self.file_path: Optional[Path] = None

        # mapping the file reader by extension
        self._readers: Dict[FileType, Callable] = {
            FileType.CSV: pd.read_csv,
            FileType.XLSX: pd.read_excel,
            FileType.PARQUET: pd.read_parquet,
            FileType.ORC: pd.read_orc,
        }

        # mapping the writters to FileType
        self._writers: Dict[FileType, Callable] = {
            FileType.CSV: self._write_csv,
            FileType.XLSX: self._write_excel,
            FileType.PARQUET: self._write_parquet,
            FileType.ORC: self._write_orc,
        }

        # mapping the file inferencers by extension
        self._inferencers: Dict[FileType, Callable] = {
            FileType.CSV: self._infer_dtypes_from_dataframe,
            FileType.XLSX: self._infer_dtypes_from_dataframe,
            FileType.PARQUET: self._infer_dtypes_from_parquet,
            FileType.ORC: self._infer_dtypes_from_orc,
        }

    def _find_file(self) -> Path:
        """
        Identifies the file based on pattern (latest) or explicit name.
        """
        if self.settings.file_pattern:
            files = list(self.settings.folder_path.glob(self.settings.file_pattern))
            if not files:
                self.log_and_raise(
                    ValueError,
                    f"No files found by pattern {self.settings.file_pattern} inside folder {self.settings.folder_path}",
                )
            latest_file = max(files, key=lambda f: f.stat().st_mtime)
            return latest_file
        elif self.settings.file_name:
            file = (self.settings.folder_path / self.settings.file_name).with_suffix(
                f".{self.settings.file_type.value.lower()}"
            )
            if not file.exists():
                self.log_and_raise(
                    ValueError, "Error finding file, please check the file definition."
                )
            return file
        self.log_and_raise(ValueError, "Error finding file by name or pattern")

    def read_file(self, **kwargs) -> pd.DataFrame:
        """
        Entrypoint for reading files to a pandas DataFrame.
        Depending on the file type it will delegate to the coresponding reader.
        """
        if not self.file_path:
            self.file_path = self._find_file()

        try:
            self.logger.info(f"Reading file: {self.file_path.name}")
            return self._readers[self.file_type](self.file_path, **kwargs)
        except Exception as e:
            self.log_exception(
                e, f"Failed to read {self.file_path.name} into a dataframe"
            )
            raise

    def write_file(self, df: pd.DataFrame, **kwargs) -> Path:
        """
        Ensures a valid path exists and writes the dataframe.
        If file_name is provided, it uses it (and overwrites).
        If file_pattern is provided, it constructs a name using the pattern and a timestamp.
        """

        output_path = self._construct_output_path()
        try:
            output_path.parent.mkdir(parents=True, exist_ok=True)

            self.logger.info(f"Writing to file: {output_path.name}")
            self._writers[self.file_type](df, output_path, **kwargs)

            return output_path
        except Exception as e:
            self.log_exception(e, f"Failed to write to: {output_path}")
            raise

    def _construct_output_path(self) -> Path:
        """
        Construct the output file path based on the settings.
        If the file name is defined the output path will be fixed,
        if the file pattern is defined the file name will have a timestamp appended.
        """
        timestamp = pd.Timestamp.now().strftime("%Y%m%d_%H%M%S")
        file_extension = f".{self.settings.file_type.value.lower()}"

        if self.settings.file_name:
            base_path: Path = self.settings.folder_path / self.settings.file_name
            return base_path.with_suffix(file_extension)
        return (
            self.settings.folder_path
            / f"{self.settings.file_pattern}_{timestamp}{file_extension}"
        )

    def _apply_file_preprocessor(self, preprocessor_func: Callable[[Path], Path]):
        """
        Executes a custom function passed from the BasePipelineDefinition
        and returns the new file path
        """

        current_path = self._find_file()
        self.logger.info(f"Current file path is: {current_path}")

        if preprocessor_func is None:
            self.file_path = current_path
            return

        try:
            self.logger.info(f"Running pre-processor on: {current_path}")
            # run pre-processor function and record the path - old or new
            processed_path = preprocessor_func(current_path)

            if isinstance(processed_path, Path):
                self.file_path = processed_path
                self.logger.debug(f"File path updated to: {self.file_path}")
            else:
                self.logger.warning("Pre-processor function did not return a new Path")
                self.file_path = current_path

        except Exception as e:
            self.log_exception(e, f"Pre-processor failed for : {current_path}")
            # In case of failure, keep the original path so the pipeline can try to proceed
            self.file_path = current_path

    def _write_csv(self, df: pd.DataFrame, file_path: Path, **kwargs):
        """Internal CSV writer"""
        df.to_csv(file_path, index=False, **kwargs)

    def _write_excel(self, df: pd.DataFrame, file_path: Path, **kwargs):
        """Internal Excel writer"""

        df.to_excel(file_path, index=False, **kwargs)

    def _write_parquet(self, df: pd.DataFrame, file_path: Path, **kwargs):
        """Internal Parquet writer"""

        df.to_parquet(file_path, index=False, **kwargs)

    def _write_orc(self, df: pd.DataFrame, file_path: Path, **kwargs):
        """Internal Orc writer"""
        df.to_orc(file_path, **kwargs)

    def _infer_dtypes_from_dataframe(
        self, df: pd.DataFrame
    ) -> Dict[str, types.TypeEngine]:
        """
        Infer SQLAlchemy types from DataFrame.

        Returns empty dict on error to allow fallback to default inference.
        """
        inferrer = SQLAlchemyDTypeInferrer()
        return inferrer.infer_from_dataframe(df)

    def _infer_dtypes_from_parquet(
        self,
        file_path: Union[str, Path],
    ) -> Dict[str, types.TypeEngine]:
        """
        Infer SQLAlchemy types from Parquet file.

        Returns empty dict on error to allow fallback to default inference.
        """
        inferrer = SQLAlchemyDTypeInferrer()
        return inferrer.infer_from_parquet(file_path)

    def _infer_dtypes_from_orc(
        self,
        file_path: Union[str, Path],
    ) -> Dict[str, types.TypeEngine]:
        """
        Infer SQLAlchemy types from ORC file.

        Returns empty dict on error to allow fallback to default inference.
        """
        inferrer = SQLAlchemyDTypeInferrer()
        return inferrer.infer_from_orc(file_path)
