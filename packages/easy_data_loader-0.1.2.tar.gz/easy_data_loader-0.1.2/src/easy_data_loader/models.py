from enum import Enum
from pathlib import Path
from typing import Annotated, Literal, Optional, TypeAlias, Union

import pandas as pd
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict
from sqlalchemy.types import TypeEngine
from typing_extensions import Any, Dict, List


class ServerType(Enum):
    MSSQL = "MSSQL"
    POSTGRESQL = "POSTGRESQL"
    SQLITE = "SQLITE"


class FileType(Enum):
    CSV = "CSV"
    XLSX = "XLSX"
    ORC = "ORC"
    PARQUET = "PARQUET"


class BaseConnectionSettings(BaseSettings):
    """Base class for all database connections"""

    model_config = SettingsConfigDict(extra="ignore")


class ServerBasedConnectionSettings(BaseConnectionSettings):
    """Model for server-based databases (MSSQL, PostgreSQL)"""

    conn_server_type: Literal[ServerType.MSSQL, ServerType.POSTGRESQL]

    @field_validator("conn_server_type", mode="before")
    @classmethod
    def coerce_server_type(cls, v: object) -> object:
        if isinstance(v, str):
            return ServerType(v)
        return v

    conn_server: str
    conn_database: str
    conn_username: str
    conn_password: str
    conn_port: Annotated[int, Field(default=1433, ge=1, le=65535)]

    model_config = SettingsConfigDict(extra="ignore")

    @model_validator(mode="after")
    def validate_connection(self) -> "ServerBasedConnectionSettings":

        # For DB servers: require server + database
        if not self.conn_server or not self.conn_database:
            raise ValueError("conn_server and conn_database are required")

        # Authentication must be both or neither
        if (self.conn_username and not self.conn_password) or (
            self.conn_password and not self.conn_username
        ):
            raise ValueError(
                "Both username and password must be provided for authentication"
            )
        return self


class FileBasedConnectionSettings(BaseConnectionSettings):
    """Model for file-based databases"""

    conn_server_type: Literal[ServerType.SQLITE]

    @field_validator("conn_server_type", mode="before")
    @classmethod
    def coerce_server_type(cls, v: object) -> object:
        if isinstance(v, str):
            return ServerType(v)
        return v

    file_path: str

    @property
    def conn_database(self) -> str:
        """Return the database name (file path) for consistency"""
        return self.file_path


class FileSettings(BaseSettings):
    """default model for all source file settings"""

    file_type: FileType = FileType.CSV
    folder_path: Path
    file_name: Optional[str] = None
    file_pattern: Optional[str] = None

    @model_validator(mode="after")
    def validate_model(self) -> "FileSettings":
        if not self.folder_path.exists():
            raise ValueError(f"Root folder path: {self.folder_path} - does not exist")

        # model needs to accept a file_name (we know the exact file name) or
        # a file_pattern (we know part of the file name)
        if self.file_pattern and self.file_name:
            raise ValueError(
                "Please define a specific file name or a file pattern, not both."
            )
        return self


class ColumnDefinition(BaseModel):
    """Default model representing a column in a database table"""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    target_name: Optional[str] = None  # name of the column in the Sql table
    data_type: Optional[TypeEngine] = None  # the SqlAlchemy data type


class BasePipelineDefinition(BaseModel):
    """Base pipeline definition"""

    model_config = ConfigDict(arbitrary_types_allowed=True, extra="allow")
    pipeline_name: str = "generic_pipeline"

    source: str
    source_sql: Optional[str] = None  # can be a table name or a sql query
    destination: str
    destination_table: Optional[str] = None
    audit: Optional[str] = None  # resource name for the audit database
    validator: Optional[Any] = None  # pydantic model class for validation

    # mapping of source columns to destination columns together with datatypes
    columns: Dict[str, ColumnDefinition] = Field(default_factory=dict)

    read_parameters: Dict[str, Any] = Field(default_factory=dict)
    write_parameters: Dict[str, Any] = Field(default_factory=dict)

    def file_pre_process(self, file_path: Path) -> Path:
        """
        Hook for preprocessing the file before reading.
        Ex: extract archive, rename file etc.
        """
        return file_path

    def transform(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Hook method that allows data transformation before upload.
        Can be overwritten by user in manual defined schema
        """
        return df

    def file_post_process(self, file_path: Path) -> Path:
        """
        Hook for postprocessing the file before reading.
        Ex: archive file, etc.
        """
        return file_path

    def get_sql_columns(self) -> Dict[str, ColumnDefinition]:
        """
        Return the sql column definition from the pipeline.
        If there is no column mapping defined then the values must be populated
        by reading the sql table columns.
        """
        return self.columns

    # Helper for getting the columns to rename in pandas if any
    def get_rename_map(self) -> Dict[str, str]:
        rename_map = {}
        for source, col_def in self.columns.items():
            if col_def.target_name:
                rename_map[source] = col_def.target_name
        return rename_map

    # Helper to get the sql columns data type
    def get_dtype_map(self) -> Dict[str, TypeEngine]:
        dtype_map = {}
        for source, col_def in self.columns.items():
            if col_def.data_type:
                key = col_def.target_name or source
                dtype_map[key] = col_def.data_type
        return dtype_map


class ProcedureDefinition(BaseModel):
    """Model representing a pipeline that executes stored procedures"""

    pipeline_name: str
    audit: Optional[str] = None
    resource: str  # database resource name
    # List of (procedure_name, parameter_dict)
    procedures: List[tuple[str, Optional[Dict[str, Any]]]]


class AuditEntry(BaseModel):
    """Model representing an entry in the audit table"""

    execution_id: str
    pipeline_name: str
    status: str
    input_rows: int = 0
    output_rows: int = 0
    source_name: Optional[str] = None
    destination_name: Optional[str] = None
    file_name: Optional[str] = None
    file_path: Optional[str] = None
    file_size_bytes: Optional[int] = None
    file_last_modified: Optional[pd.Timestamp] = None
    error_details: Optional[str] = None
    sp_name: Optional[str] = None
    sp_parameters: Optional[Dict[str, Any]] = None
    timestamp: pd.Timestamp = Field(default_factory=pd.Timestamp.now)

    model_config = ConfigDict(arbitrary_types_allowed=True)


class OrchestratorDefinition(BaseModel):
    """Model representing an orchestrator that chains multiple pipelines"""

    orchestrator_name: str
    pipelines: List[str]  # List of pipeline names to run in sequence
    fail_fast: bool = True  # Stop execution if a pipeline fails


ConnectionSettings = Annotated[
    Union[ServerBasedConnectionSettings, FileBasedConnectionSettings],
    Field(discriminator="conn_server_type"),
]

ResourceConfig: TypeAlias = Annotated[
    Union[ConnectionSettings, FileSettings],
    "Hybrid resource configuration: it can be a file or database to serve as a source or destination",
]

PipelineType: TypeAlias = Annotated[
    Union[BasePipelineDefinition, ProcedureDefinition, OrchestratorDefinition],
    "Hybrid pipeline definition",
]
