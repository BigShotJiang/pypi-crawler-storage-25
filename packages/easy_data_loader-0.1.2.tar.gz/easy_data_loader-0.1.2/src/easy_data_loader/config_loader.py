import importlib.util
from pathlib import Path
from types import ModuleType
from typing import Dict, Union

from .log import LoggedComponent
from .models import (
    BasePipelineDefinition,
    FileSettings,
    OrchestratorDefinition,
    ProcedureDefinition,
    ResourceConfig,
    PipelineType,
    ServerBasedConnectionSettings,
)


class Configuration(LoggedComponent):
    """
    Configuration manager with lazy loading capabilities.
    Resources and pipelines are loaded only when requested.
    This class implements the Singleton pattern.
    """

    _instance = None
    _initialized = False

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super(Configuration, cls).__new__(cls)
        return cls._instance

    def __init__(self, config_dir: str = "./config"):
        if not self._initialized:
            super().__init__()
            self.config_dir = Path(config_dir)
            self.resources: Dict[str, ResourceConfig] = {}
            self.pipelines: Dict[
                str,
                Union[
                    BasePipelineDefinition, ProcedureDefinition, OrchestratorDefinition
                ],
            ] = {}

            self.logger.debug(
                f"Initializing configuration from directory: {config_dir}"
            )
            self._initialized = True

    def _load_env_file(self, env_file: Path) -> ResourceConfig:
        """Load environment variables from a specific file"""
        self.logger.debug(f"Loading environment file: {env_file}")

        env_file_name = env_file.stem

        if env_file_name.startswith("database_"):
            # Peek at the env file to determine which connection class to use
            from dotenv import dotenv_values

            raw_values = dotenv_values(env_file)
            server_type_str = raw_values.get("CONN_SERVER_TYPE", "").upper()
            if server_type_str == "SQLITE":
                from .models import FileBasedConnectionSettings

                return FileBasedConnectionSettings(_env_file=[env_file])
            return ServerBasedConnectionSettings(_env_file=[env_file])
        if env_file_name.startswith("file_"):
            return FileSettings(_env_file=[env_file])

        self.log_and_raise(
            ValueError,
            f"Failed to load env file: {env_file.name}. "
            f"Resource files must start with 'database_' or 'file_' prefix.",
        )

    def _import_module(self, module_file: Path) -> ModuleType:
        """Dynamically import a Python module from a file path"""

        self.logger.debug(f"Importing configuration from {module_file}")

        spec = importlib.util.spec_from_file_location(module_file.stem, module_file)

        if spec is None:
            self.log_and_raise(
                ImportError,
                f"Could not create module spec for {module_file}",
                file_path=str(module_file),
            )

        if spec.loader is not None:
            module = importlib.util.module_from_spec(spec)

            spec.loader.exec_module(module)
            self.logger.debug(
                f"Succesfully imported configuration from {str(module_file)}"
            )
            return module
        else:
            self.log_and_raise(
                ImportError,
                f"Module spec has no loader {module_file}",
                file_path=str(module_file),
            )

    def get_resource(self, resource_name: str) -> ResourceConfig:
        """
        Retrieve a connection by name.
        Uses lazy loading: checks memory first, then attempts to load from file.
        """
        self.logger.debug(f"Retrieving connection by name: {resource_name}")

        # 1. Check if already loaded
        if resource_name in self.resources:
            return self.resources[resource_name]

        # 2. Try to load from file
        resource_file = self.config_dir / "resources" / f"{resource_name}.env"
        if resource_file.exists():
            try:
                resource = self._load_env_file(resource_file)
                self.resources[resource_name] = resource
                self.logger.info(f"Lazily loaded resource: {resource_name}")
                return resource
            except Exception as e:
                self.log_exception(e, f"Failed to load resource: {resource_name}")
                raise

        # 3. Not found
        self.log_and_raise(
            ValueError,
            f"Resource not found: {resource_name}. Checked path: {resource_file}",
        )

    def get_pipeline(self, pipeline_name: str) -> PipelineType:
        """
        Retrieve a pipeline definition by name.
        Uses lazy loading: checks memory first, then attempts to load from file.
        """
        self.logger.debug(f"Retriving pipeline definition by name: {pipeline_name}")

        # 1. Check if already loaded
        if pipeline_name in self.pipelines:
            return self.pipelines[pipeline_name]

        # 2. Try to load from file
        pipeline_file = self.config_dir / "pipelines" / f"{pipeline_name}.py"
        if pipeline_file.exists():
            try:
                config_module = self._import_module(pipeline_file)
                # Find the definition in the module
                for attr_name in dir(config_module):
                    attr = getattr(config_module, attr_name)
                    if isinstance(
                        attr,
                        (
                            BasePipelineDefinition,
                            ProcedureDefinition,
                            OrchestratorDefinition,
                        ),
                    ):
                        self.pipelines[pipeline_name] = attr
                        self.logger.info(f"Lazily loaded pipeline: {pipeline_name}")
                        return attr
            except Exception as e:
                self.log_exception(e, f"Failed to load pipeline: {pipeline_name}")
                raise

        # 3. Not found
        self.log_and_raise(
            ValueError,
            f"Pipeline not found: {pipeline_name}. Checked path: {pipeline_file}",
        )

    def get_all_resources(self) -> dict[str, ResourceConfig]:
        """
        Retrieve all connections.
        Scans the resources directory if not all loaded.
        """
        resources_dir = self.config_dir / "resources"
        if not resources_dir.exists():
            return self.resources

        # Discover all .env files
        for env_file in resources_dir.glob("*.env"):
            # Simple logging to debug discovery
            self.logger.debug(f"Found potential resource file: {env_file.name}")

            resource_name = env_file.stem
            if resource_name not in self.resources:
                try:
                    self.resources[resource_name] = self._load_env_file(env_file)
                except Exception as e:
                    self.logger.warning(f"Failed to load resource {resource_name}: {e}")

        return self.resources

    def get_all_pipelines(self) -> dict[str, PipelineType]:
        """
        Retrieve all pipelines.
        Scans the pipelines directory if not all loaded.
        """
        pipelines_dir = self.config_dir / "pipelines"
        if not pipelines_dir.exists():
            return self.pipelines

        for pipeline_file in pipelines_dir.glob("*.py"):
            self.logger.debug(f"Found potential pipeline file: {pipeline_file.name}")

            pipeline_name = pipeline_file.stem
            if pipeline_name not in self.pipelines:
                # Helper to trigger lazy load
                try:
                    self.get_pipeline(pipeline_name)
                except Exception as e:
                    self.logger.warning(f"Failed to load pipeline {pipeline_name}: {e}")

        return self.pipelines
