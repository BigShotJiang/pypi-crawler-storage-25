from pathlib import Path

import click

# Integrated templates
PIPELINE_TEMPLATE = """
from easy_data_loader.pipeline import LoadPipeline
from easy_data_loader.models import BasePipelineDefinition, ColumnDefinition
import pandas as pd
from sqlalchemy.types import DATETIME, INT, DECIMAL, NVARCHAR

example_pipeline = BasePipelineDefinition(
    pipeline_name="test_pipeline", # pipeline name to be used when initializing the Pipeline object

    # source name represented by the file having the source settings -> corresponds to a file in the config/resources folder
    source = "example_file",

    # "dbo.FactSales" ## if the source is a database then source sql defines the table name or a custom query to be executed
    # source_sql = "SELECT TOP 100 * FROM dbo.FactSales"

    # destination name represented by the file having the destination settings -> corresponds to a file in the config/resources folder
    destination="example_database",

    # if the destination is a database then here we define the destination table name
    destination_table="dbo.LargeSalesData",

    # columns definition if we are sending data to a database table
    columns={
        "transaction_id": ColumnDefinition(target_name="new_transaction_id", data_type=INT()),
        "date": ColumnDefinition(target_name="sales_date", data_type=DATETIME()),
        "customer_id": ColumnDefinition(target_name="id_customer", data_type=INT()),
        "product_category" : ColumnDefinition(target_name="category_of_product", data_type=NVARCHAR(100)),
        "units_sold" : ColumnDefinition(target_name="units", data_type=INT()),
        "unit_price" : ColumnDefinition(target_name="price", data_type=DECIMAL(6,2)),
        "raw_notes" : ColumnDefinition(target_name="notes", data_type=NVARCHAR(100))
    },

    # different parameters passed to the write functions
    write_parameters={"if_exists" : "replace", "index" : False},

    # different parameters passed to the read function
    read_parameters={"sep" : ";"}
)

def add_timestamp(df):
    # Adding an audit column during load
    df['insert_timestamp'] = pd.Timestamp.now()
    return df

example_pipeline.transform = add_timestamp
"""

PROCEDURE_TEMPLATE = """
from easy_data_loader.models import ProcedureDefinition

example_procedure = ProcedureDefinition(
    pipeline_name="example_procedure",
    resource="example_database",
    procedures=[
        ("dbo.sp_UpdateSales", {"year": 2024}),
        ("dbo.sp_ArchiveOldData", {})
    ]
)
"""

ORCHESTRATOR_TEMPLATE = """
from easy_data_loader.models import OrchestratorDefinition

example_orchestrator = OrchestratorDefinition(
    orchestrator_name="example_orchestrator",
    pipelines=[
        "example_pipeline",
        "example_procedure"
    ],
    fail_fast=True
)
"""


DATABASE_ENV = """
# database resource definition
CONN_SERVER_TYPE=MSSQL
CONN_SERVER=.
CONN_DATABASE=test_database
CONN_USERNAME=my_user
CONN_PASSWORD=my_password
CONN_PORT=1433
"""

FILE_ENV = """
# file resource definition
FILE_TYPE=CSV                # can also be XLSX, PARQUET, ORC
FOLDER_PATH=./data/imports   # source folder where the file is located
FILE_NAME=large_sales_data   # exact file name without extension
#FILE_PATTERN=large_sales    # file pattern to search in the source folder
"""

MAIN = """
from easy_data_loader import LoadPipeline, ProcedurePipeline

def main():
    # Run an ETL pipeline
    LoadPipeline(pipeline_name="example_pipeline").run()

    # Run a procedure pipeline
    ProcedurePipeline(pipeline_name="example_procedure").run()

if __name__ == "__main__":
    main()
"""


@click.group()
def main():
    """Easy Data Loader CLI - ETL instrument for files and databases"""
    pass


@main.command()
def init():
    """Initialize folder structure and sample files"""
    base_path = Path.cwd()

    # folders
    folders = ["config/resources", "config/pipelines"]
    for folder in folders:
        (base_path / folder).mkdir(parents=True, exist_ok=True)

    # Example files to create
    files = {
        "config/pipelines/pipeline_example.py": PIPELINE_TEMPLATE,
        "config/pipelines/procedure_example.py": PROCEDURE_TEMPLATE,
        "config/pipelines/orchestrator_example.py": ORCHESTRATOR_TEMPLATE,
        "config/resources/database_example.env": DATABASE_ENV,
        "config/resources/file_example.env": FILE_ENV,
        "main.py": MAIN,
    }

    for name, content in files.items():
        file_path = base_path / name
        if not file_path.exists():
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(content)
            click.echo(f"Created: {name}")
        else:
            click.echo(f"Skipped: {name} (already exists)")

    click.echo("\nProject initialized successfully!")


@main.command()
def list():
    """List all discovered resources and pipelines"""
    from .config_loader import Configuration

    config = Configuration()

    click.echo("--- Discovered Resources ---")
    for name in config.get_all_resources():
        click.echo(f" - {name}")

    click.echo("\n--- Discovered Pipelines ---")
    for name in config.get_all_pipelines():
        click.echo(f" - {name}")


@main.command()
@click.argument("resource_name")
@click.argument("table_name")
def inspect_db(resource_name, table_name):
    """Inspect a database table and generate ColumnDefinition code"""
    from .config_loader import Configuration
    from .database_connector import CONNECTOR_FACTORY
    from .database_operations import DatabaseOperations

    from .models import ServerBasedConnectionSettings, FileBasedConnectionSettings

    config = Configuration()
    resource = config.get_resource(resource_name)

    if not isinstance(
        resource, (ServerBasedConnectionSettings, FileBasedConnectionSettings)
    ):
        click.echo(f"Error: Resource '{resource_name}' is not a database connection.")
        return

    # Initialize connector and ops
    connector = CONNECTOR_FACTORY[resource.conn_server_type](resource)
    ops = DatabaseOperations(connector.get_engine())

    schema = ops.inspect_table(table_name)

    if not schema:
        click.echo(f"No columns found for table '{table_name}'.")
        return

    click.echo(f"\n# Suggested Column definitions for {table_name}:")
    click.echo("columns={")
    for col, dtype in schema.items():
        click.echo(
            f'    "{col}": ColumnDefinition(target_name="{col}", data_type={dtype}),'
        )
    click.echo("}")


@main.command()
def run_all():
    """Run all discovered pipelines and show status summary"""
    from .config_loader import Configuration
    from .models import (
        BasePipelineDefinition,
        OrchestratorDefinition,
        ProcedureDefinition,
    )
    from .pipeline import LoadPipeline
    from .procedure_pipeline import ProcedurePipeline

    config = Configuration()
    pipelines = config.get_all_pipelines()

    if not pipelines:
        click.echo("No pipelines discovered.")
        return

    results = {}

    click.echo(f"🚀 Running {len(pipelines)} discovered pipelines...\n")

    for name in pipelines:
        click.echo(f"Pipeline: {name} ... ", nl=False)
        try:
            definition = config.get_pipeline(name)
            if isinstance(definition, BasePipelineDefinition):
                success = LoadPipeline(name).run()
            elif isinstance(definition, ProcedureDefinition):
                success = ProcedurePipeline(name).run()
            elif isinstance(definition, OrchestratorDefinition):
                from .orchestrator import OrchestratorPipeline

                success = OrchestratorPipeline(name).run()
            else:
                success = False

            results[name] = "SUCCESS" if success else "FAILED"
        except Exception as e:
            results[name] = f"ERROR: {str(e)}"

        click.echo(results[name])

    click.echo("\n" + "=" * 40)
    click.echo(f"{'PIPELINE':<25} | {'STATUS'}")
    click.echo("-" * 40)
    for name, status in results.items():
        click.echo(f"{name:<25} | {status}")


@main.command()
@click.argument("orchestrator_name")
def run_orchestrator(orchestrator_name):
    """Run a specific orchestrator by name"""
    from .orchestrator import OrchestratorPipeline

    try:
        success = OrchestratorPipeline(orchestrator_name).run()
        if success:
            click.echo(f"✅ Orchestrator '{orchestrator_name}' completed successfully.")
        else:
            click.echo(f"❌ Orchestrator '{orchestrator_name}' failed.")
    except Exception as e:
        click.echo(f"💥 Error: {str(e)}")


@main.command()
def validate_resources():
    """Validate all configured resources"""
    from .config_loader import Configuration
    from .database_connector import CONNECTOR_FACTORY
    from .models import FileSettings

    config = Configuration()
    resources = config.get_all_resources()

    if not resources:
        click.echo("No resources found.")
        return

    click.echo(f"🔍 Validating {len(resources)} resources...\n")

    from .models import ServerBasedConnectionSettings, FileBasedConnectionSettings

    results = {}

    for name, resource in resources.items():
        click.echo(f"Resource: {name} ... ", nl=False)
        try:
            if isinstance(
                resource, (ServerBasedConnectionSettings, FileBasedConnectionSettings)
            ):
                # Validate Database Connection
                CONNECTOR_FACTORY[resource.conn_server_type](resource)
                # The connector tests connection in __init__, so if we are here it passed
                results[name] = "OK (Connected)"
            elif isinstance(resource, FileSettings):
                # Validate File Path
                if resource.folder_path.exists():
                    results[name] = "OK (Path Exists)"
                else:
                    raise ValueError(f"Path does not exist: {resource.folder_path}")
            else:
                results[name] = "UNKNOWN TYPE"

        except Exception as e:
            results[name] = f"FAILED: {str(e)}"

        click.echo(results[name])

    click.echo("\n" + "=" * 60)
    click.echo(f"{'RESOURCE':<30} | {'STATUS'}")
    click.echo("-" * 60)
    for name, status in results.items():
        click.echo(f"{name:<30} | {status}")


if __name__ == "__main__":
    main()
