class DriverNotFoundException(Exception):
    def __init__(self, message: str = "ODBC driver not available"):
        self.message = message
        super().__init__(self.message)


class EngineTestException(Exception):
    def __init__(self, message: str = "Engine has not passed connection test"):
        self.message = message
        super().__init__(self.message)


class DatabaseOperationException(Exception):
    def __init__(self, operation: str, message: str):
        self.message = message
        super().__init__(self.message)


class InvalidFileException(Exception):
    def __init__(self, message: str = "The provided file is invalid or corrupted"):
        self.message = message
        super().__init__(self.message)
