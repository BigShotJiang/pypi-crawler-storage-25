import uuid

from .config_loader import Configuration
from .log import LoggedComponent
from .models import (
    BasePipelineDefinition,
    OrchestratorDefinition,
    ProcedureDefinition,
    PipelineType,
)
from .pipeline import LoadPipeline
from .procedure_pipeline import ProcedurePipeline


class OrchestratorPipeline(LoggedComponent):
    """Executes a chain of pipelines defined by an OrchestratorDefinition"""

    def __init__(self, orchestrator_name: str):
        super().__init__()
        self.config = Configuration()
        definition = self.config.get_pipeline(orchestrator_name)

        if not isinstance(definition, OrchestratorDefinition):
            self.log_and_raise(
                ValueError, f"'{orchestrator_name}' is not an orchestrator."
            )

        self.definition: OrchestratorDefinition = definition
        self.batch_id = str(uuid.uuid4())

    def run(self) -> bool:
        self.logger.info(
            f"=== Starting Orchestrator: {self.definition.orchestrator_name} (Batch: {self.batch_id}) ==="
        )

        success = True
        for pipeline_name in self.definition.pipelines:
            self.logger.info(
                f"[{self.definition.orchestrator_name}] -> Triggering pipeline: {pipeline_name}"
            )

            p_def: PipelineType = self.config.get_pipeline(pipeline_name)
            p_success = False

            # Instantiate and run
            if isinstance(p_def, BasePipelineDefinition):
                p_success = LoadPipeline(pipeline_name).run()
            elif isinstance(p_def, ProcedureDefinition):
                p_success = ProcedurePipeline(pipeline_name).run()
            elif isinstance(p_def, OrchestratorDefinition):
                self.logger.error(
                    f"[{self.definition.orchestrator_name}] -> Nested orchestrators are not supported."
                )
                p_success = False
            else:
                self.logger.error(
                    f"[{self.definition.orchestrator_name}] -> Unknown pipeline type for '{pipeline_name}'"
                )
                p_success = False

            if not p_success:
                success = False
                self.logger.error(
                    f"[{self.definition.orchestrator_name}] -> Pipeline failed: {pipeline_name}"
                )
                if self.definition.fail_fast:
                    self.logger.error(
                        f"[{self.definition.orchestrator_name}] -> Fail fast enabled. Stopping orchestrator."
                    )
                    break
            else:
                self.logger.info(
                    f"[{self.definition.orchestrator_name}] -> Pipeline succeeded: {pipeline_name}"
                )

        status = "SUCCESS" if success else "FAILED"
        self.logger.info(
            f"=== Orchestrator {self.definition.orchestrator_name} finished with status: {status} ==="
        )
        return success
