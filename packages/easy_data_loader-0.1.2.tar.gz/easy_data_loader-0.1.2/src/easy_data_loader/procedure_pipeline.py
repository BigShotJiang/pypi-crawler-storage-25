from .config_loader import Configuration
from .models import (
    ProcedureDefinition,
    ServerBasedConnectionSettings,
    FileBasedConnectionSettings,
)
from .pipeline_base import BasePipeline


class ProcedurePipeline(BasePipeline):
    """
    Pipeline specialized in executing database stored procedures.
    """

    def __init__(self, pipeline_name: str):
        # Load definition from config
        definition = Configuration().get_pipeline(pipeline_name)
        if not isinstance(definition, ProcedureDefinition):
            raise ValueError(
                f"Pipeline '{pipeline_name}' is not a ProcedureDefinition."
            )

        super().__init__(definition)
        self.definition: ProcedureDefinition = definition

        # Set up primary database connection
        resource = self.config.get_resource(self.definition.resource)
        if not isinstance(
            resource, (ServerBasedConnectionSettings, FileBasedConnectionSettings)
        ):
            self.log_and_raise(
                ValueError,
                f"Resource '{self.definition.resource}' must be a database connection.",
            )

        self.db_ops = self._setup_db_operations(resource)

    def run(self) -> bool:
        """Execute all procedures in the definition."""
        self.logger.info(
            f">>> Starting Procedure Pipeline: {self.definition.pipeline_name} <<<"
        )

        try:
            for proc_name, params in self.definition.procedures:
                params = params or {}
                self.logger.info(
                    f"Running procedure: {proc_name} with params: {params}"
                )
                self.db_ops.execute_stored_procedure(proc_name, **params)

            # Set audit details
            self.sp_name = ", ".join([p[0] for p in self.definition.procedures])
            self.sp_parameters = {p[0]: p[1] for p in self.definition.procedures}

            self._log_audit("SUCCESS")
            self.logger.info(
                f">>> Procedure Pipeline {self.definition.pipeline_name} finished successfully <<<"
            )
            return True

        except Exception as e:
            self.error_details = str(e)
            self.log_exception(
                e, f"Error in Procedure Pipeline: {self.definition.pipeline_name}"
            )

            # Set audit details for failure too
            self.sp_name = ", ".join([p[0] for p in self.definition.procedures])
            self.sp_parameters = {p[0]: p[1] for p in self.definition.procedures}

            self._log_audit("FAILED")
            return False
        finally:
            self._cleanup()
