from pathlib import Path
from typing import Optional, Tuple, Dict

import pandas as pd
from sqlalchemy import types

from .config_loader import Configuration
from .database_operations import DatabaseOperations
from .file_operations import FileOperations
from .models import (
    BasePipelineDefinition,
    FileSettings,
    ServerBasedConnectionSettings,
    FileBasedConnectionSettings,
    FileType,
)
from .pipeline_base import BasePipeline


class LoadPipeline(BasePipeline):
    """
    Main orchestrator responsible for executing a specific ETL pipeline by name.
    It retrieves definitions and resources from the Configuration instance.
    Inherits shared logic from BasePipeline.
    """

    def __init__(self, pipeline_name: str):
        # Load definition from config
        definition = Configuration().get_pipeline(pipeline_name)
        if not isinstance(definition, BasePipelineDefinition):
            raise ValueError(
                f"Pipeline '{pipeline_name}' is not a LoadPipeline definition."
            )

        super().__init__(definition)
        self.definition: BasePipelineDefinition = definition

        # initialize components
        self.src_db_ops: Optional[DatabaseOperations] = None
        self.dst_db_ops: Optional[DatabaseOperations] = None
        self.src_file_ops: Optional[FileOperations] = None
        self.dst_file_ops: Optional[FileOperations] = None
        self.source_file_path: Optional[Path] = None  # For auditing

        self._initialize_components()

    def _initialize_components(self):
        """Dynamically initialize the components based on their type and definition"""

        source_resource = self.config.get_resource(self.definition.source)
        destination_resource = self.config.get_resource(self.definition.destination)

        # initialize source
        if isinstance(source_resource, FileSettings):
            self.src_file_ops = FileOperations(source_resource)
            # Store resource names for auditing
            self.source_name = source_resource.folder_path.name
        elif isinstance(
            source_resource,
            (ServerBasedConnectionSettings, FileBasedConnectionSettings),
        ):
            self.src_db_ops = self._setup_db_operations(source_resource)
            self.source_name = source_resource.conn_database
        else:
            raise ValueError(
                f"Unsupported source resource type: {type(source_resource)}"
            )

        # initialize destination
        if isinstance(destination_resource, FileSettings):
            self.dst_file_ops = FileOperations(destination_resource)
            self.destination_name = destination_resource.folder_path.name
        elif isinstance(
            destination_resource,
            (ServerBasedConnectionSettings, FileBasedConnectionSettings),
        ):
            self.dst_db_ops = self._setup_db_operations(destination_resource)
            self.destination_name = destination_resource.conn_database

    def run(self) -> bool:
        """Executes the entire ETL flow"""
        self.logger.info(
            f">>> Starting Load Pipeline: {self.definition.pipeline_name} <<<"
        )

        try:
            # 1. EXTRACT
            df, inferred_dtypes = self._extract_step()
            if df.empty:
                self.logger.warning("No data found! Pipeline will stop!")
                return False

            self.input_rows = len(df)

            # 2. TRANSFORM & VALIDATE
            df = self._transform_step(df)
            self.output_rows = len(df)

            # 3. LOAD
            load_success = self._load_step(df, inferred_dtypes)
            if not load_success:
                self.logger.error(
                    f">>> Pipeline {self.definition.pipeline_name} failed to load during the LOAD step."
                )
                self._log_audit("FAILED")
                return False

            self._log_audit("SUCCESS")
            self.logger.info(
                f">>> Pipeline {self.definition.pipeline_name} finished successfully <<<"
            )
            return True

        except Exception as e:
            self.error_details = str(e)
            self.log_exception(
                e, f"Critical pipeline error - {self.definition.pipeline_name}"
            )
            self._log_audit("FAILED")
            return False
        finally:
            self._cleanup()

    def _extract_step(self) -> Tuple[pd.DataFrame, Dict[str, types.TypeEngine]]:
        """
        Handles extraction logic based on source type.

        Returns:
            Tuple of (DataFrame, inferred_dtypes):
                - DataFrame: The extracted data
                - inferred_dtypes: Dictionary of inferred SQLAlchemy types (empty if not applicable)
        """
        try:
            if self.src_db_ops:  # DB source
                if self.definition.source_sql:
                    df = self.src_db_ops.read_data(
                        self.definition.source_sql, **self.definition.read_parameters
                    )
                    return df, {}  # No dtype inference for DB sources

            if self.src_file_ops:  # File source
                self.src_file_ops._apply_file_preprocessor(
                    self.definition.file_pre_process
                )
                df = self.src_file_ops.read_file(**self.definition.read_parameters)
                self.source_file_path = self.src_file_ops.file_path

                # Infer dtypes using the factory pattern if not already defined in the pipeline definition
                dtype_map = self.definition.get_dtype_map()
                if not dtype_map:
                    self.logger.info(
                        "No column definitions found. Running dtype inference."
                    )
                    inferred_dtypes = self.src_file_ops._inferencers[
                        self.src_file_ops.file_type
                    ](
                        df
                        if self.src_file_ops.file_type in [FileType.CSV, FileType.XLSX]
                        else self.src_file_ops.file_path
                    )
                else:
                    self.logger.info(
                        f"Using {len(dtype_map)} column definitions. Skipping inference."
                    )
                    inferred_dtypes = dtype_map

                return df, inferred_dtypes

            self.logger.error("No valid source configured for the Pipeline")

        except Exception as e:
            self.log_exception(e, "Extraction step failed")
            raise

        return pd.DataFrame(), {}

    def _transform_step(self, df: pd.DataFrame) -> pd.DataFrame:
        """Applies transformations and optional Pydantic validation."""

        # 1. Pipeline hook transformation
        df = self.definition.transform(df)

        # 2. Renaming columns (can also be handled by Pydantic aliases)
        rename_map = self.definition.get_rename_map()
        if rename_map:
            df.rename(columns=rename_map, inplace=True)
            self.logger.info(f"Columns renamed: {list(rename_map.values())}")

        # 3. Optional Pydantic Validation
        if self.definition.validator:
            self.logger.info(
                f"Starting data validation against model: {self.definition.validator.__name__}"
            )
            validated_rows = []

            # Optimization: iterrows is slow because it creates a Series for each row.
            # Converting to a list of dicts first is much faster for iteration.
            records = df.to_dict(orient="records")

            for i, record in enumerate(records):
                try:
                    # Use model_validate for individual row validation
                    model_inst = self.definition.validator.model_validate(record)
                    validated_rows.append(model_inst.model_dump())
                except Exception as e:
                    self.logger.warning(f"Row {i} failed validation: {str(e)}")

            df = pd.DataFrame(validated_rows)

        return df

    def _load_step(
        self, df: pd.DataFrame, dtype_map: Dict[str, types.TypeEngine]
    ) -> bool:
        """Handles loading logic based on destination type."""
        try:
            if self.dst_db_ops and self.definition.destination_table:  # DB destination
                self.dst_db_ops.write_to_table(
                    table_name=self.definition.destination_table,
                    df=df,
                    dtype=dtype_map,
                    **self.definition.write_parameters,
                )
                return True
            elif self.dst_file_ops:  # File destination
                self.dst_file_ops.write_file(df, **self.definition.write_parameters)
                return True
            return False
        except Exception as e:
            self.log_exception(e, "Error writing to destination")
            return False
