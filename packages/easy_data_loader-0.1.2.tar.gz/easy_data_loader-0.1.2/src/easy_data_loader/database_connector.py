import urllib.parse
from abc import ABC, abstractmethod

import pyodbc
from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine

from .custom_exceptions import EngineTestException
from .driver_detector import SqlServerDriverDetector
from .log import LoggedComponent
from .models import (
    ConnectionSettings,
    ServerType,
    ServerBasedConnectionSettings,
    FileBasedConnectionSettings,
)

pyodbc.pooling = False


class DatabaseConnector(ABC):
    """Abstract class that defines a database connector"""

    @abstractmethod
    def _build_connection_string(self) -> str:
        """define the connection string to use when creating the engine - database specific"""

    @abstractmethod
    def _create_engine(self, settings: ConnectionSettings) -> Engine:
        """Create an engine to interact with the database"""
        pass

    @abstractmethod
    def get_engine(self) -> Engine:
        """Get database engine by connection name"""
        pass

    @abstractmethod
    def _test_engine(self) -> bool:
        """Test a given connection by name"""
        pass

    @abstractmethod
    def _dispose_engine(self) -> None:
        pass


class SqlServerDatabaseConnector(LoggedComponent, DatabaseConnector):
    """Database connector to a Sql Server database"""

    def __init__(self, config: ConnectionSettings):
        super().__init__()
        self.driver_detector = SqlServerDriverDetector()
        self.config = config
        self.engine = self._create_engine(self.config)
        self._test_engine()

    def _build_connection_string(self) -> str:
        """Define the connection string from the given configuration"""
        # Type guard: ensure we have ServerBasedConnectionSettings
        if not isinstance(self.config, ServerBasedConnectionSettings):
            self.log_and_raise(
                ValueError,
                "SqlServerDatabaseConnector requires ServerBasedConnectionSettings",
            )

        driver = self.driver_detector.select_preferred_driver()

        if driver is not None and self.config.conn_database is not None:
            self.logger.debug(f"Sql driver found: {driver}")
            connection_string = f"DRIVER={driver};SERVER={self.config.conn_server},{self.config.conn_port};DATABASE={self.config.conn_database}"
        else:
            self.log_and_raise(ValueError, "Connection configuration is not valid")

        if (
            self.config.conn_username is not None
            and self.config.conn_password is not None
        ):
            connection_string += (
                f";UID={self.config.conn_username};PWD={self.config.conn_password}"
            )
        elif self.config.conn_username is None and self.config.conn_password is None:
            connection_string += ";Trusted_Connection=Yes"
        else:
            self.log_and_raise(
                ValueError,
                "Credentials definition is not valid. Please check username or password!",
            )

        if driver == "ODBC Driver 18 for SQL Server":
            connection_string += ";TrustServerCertificate=Yes"

        connection_string += ";APP=SqlDataLoader"
        params = urllib.parse.quote_plus(connection_string)

        return f"mssql+pyodbc:///?odbc_connect={params}"

    def _create_engine(self, settings: ConnectionSettings) -> Engine:
        """Create a sqlalchemy engine using the provided configuration"""
        connection_string = self._build_connection_string()
        if connection_string:
            try:
                engine = create_engine(
                    connection_string,
                    fast_executemany=True,
                    pool_size=5,
                    max_overflow=10,
                    pool_timeout=30,
                    pool_recycle=3600,
                    echo=self.is_debug_enabled,
                )
                return engine
            except Exception as e:
                self.log_exception(e, "Could not create engine from connection string")
                raise
        else:
            self.log_and_raise(
                ValueError, "Connection string could not be created from configuration"
            )

    def get_engine(self) -> Engine:
        """Return the engine to be used"""
        return self.engine

    def _test_engine(self) -> bool:
        """Test if the connection works"""
        if not isinstance(self.config, ServerBasedConnectionSettings):
            self.log_and_raise(
                ValueError,
                "SqlServerDatabaseConnector requires ServerBasedConnectionSettings",
            )

        try:
            with self.engine.connect() as conn:
                conn.execute(text("SELECT 1"))
            self.logger.debug(
                f"Connection test successful: {self.config.conn_server} - {self.config.conn_database}"
            )
            return True
        except Exception as e:
            self.log_and_raise(
                EngineTestException,
                "Connection test failed",
                exception=str(e),
            )
            return False

    def _dispose_engine(self) -> None:
        self.logger.debug("Disposing of engine")
        self.engine.dispose()


class SQLiteDatabaseConnector(LoggedComponent, DatabaseConnector):
    """Database connector to a SQLite database"""

    def __init__(self, config: ConnectionSettings):
        super().__init__()
        self.config = config
        self.engine = self._create_engine(self.config)
        self._test_engine()

    def _build_connection_string(self) -> str:
        """Define the connection string from the given configuration"""
        # Type guard: ensure we have FileBasedConnectionSettings
        if not isinstance(self.config, FileBasedConnectionSettings):
            self.log_and_raise(
                ValueError,
                "SQLiteDatabaseConnector requires FileBasedConnectionSettings",
            )

        if self.config.file_path:
            # For SQLite, conn_server is treated as the file path
            return f"sqlite:///{self.config.file_path}"
        self.log_and_raise(
            ValueError,
            "Connection configuration is not valid. SQLite requires a file path in file_path.",
        )

    def _create_engine(self, settings: ConnectionSettings) -> Engine:
        """Create a sqlalchemy engine using the provided configuration"""
        connection_string = self._build_connection_string()
        try:
            # SQLite specific engine creation
            engine = create_engine(
                connection_string,
                echo=self.is_debug_enabled,
            )
            return engine
        except Exception as e:
            self.log_exception(e, "Could not create engine from connection string")
            raise

    def get_engine(self) -> Engine:
        """Return the engine to be used"""
        return self.engine

    def _test_engine(self) -> bool:
        """Test if the connection works"""
        if not isinstance(self.config, FileBasedConnectionSettings):
            self.log_and_raise(
                ValueError,
                "SQLiteDatabaseConnector requires FileBasedConnectionSettings",
            )

        try:
            with self.engine.connect() as conn:
                conn.execute(text("SELECT 1"))
            self.logger.info(f"Connection test successful: {self.config.file_path}")
            return True
        except Exception as e:
            self.log_and_raise(
                EngineTestException,
                "Connection test failed",
                exception=str(e),
            )
            return False

    def _dispose_engine(self) -> None:
        self.logger.debug("Disposing of engine")
        self.engine.dispose()


CONNECTOR_FACTORY: dict[ServerType, type] = {
    ServerType.MSSQL: SqlServerDatabaseConnector,
    ServerType.SQLITE: SQLiteDatabaseConnector,
    # ServerType.POSTGRESQL: PostgresDatabaseConnector
}
