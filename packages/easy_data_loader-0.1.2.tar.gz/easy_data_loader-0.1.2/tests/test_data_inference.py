"""
Comprehensive test suite for SQLAlchemyDTypeInferrer.

Tests cover:
- Integer type inference (SmallInteger, Integer, BigInteger)
- Numeric/Decimal type inference with precision
- Unicode string handling with international characters
- Boolean, DateTime, and Timedelta types
- Edge cases (nulls, empty data, mixed types)
- File-based inference (Parquet, ORC)
- Real-world scenarios with hierarchical data
"""

import pytest
import pandas as pd
import numpy as np
from sqlalchemy import types
from io import StringIO
import tempfile
import os

from easy_data_loader.data_inferrence import SQLAlchemyDTypeInferrer


class TestSQLAlchemyDTypeInferrer:
    """Test suite for SQLAlchemyDTypeInferrer class."""

    @pytest.fixture
    def inferrer(self):
        """Create a fresh inferrer instance for each test."""
        return SQLAlchemyDTypeInferrer()

    @pytest.fixture
    def sample_subjects_data(self):
        """Generic sample data for testing hierarchical subject structure with various data types."""
        csv_data = """SubjectID|ParentsubjectID|SubjectTitle EN|SubjectTitle FR|DefaultLanguage|ParentSubjectTitle EN|ParentSubjectTitle FR
101|201|Engineering|Ingénierie|English (US)|Technology|Technologie
102|202|Customer Service|Service Client|English (US)|Operations|Opérations
103|202|Sales Support|Support des Ventes|English (US)|Operations|Opérations
104||Human Resources|Ressources Humaines|English (US)||
201||Technology|Technologie|English (US)||
202||Operations|Opérations|English (US)||
107|201|Quality Assurance|Assurance Qualité|English (US)|Technology|Technologie
105|104|Recruitment|Recrutement|English (US)|Human Resources|Ressources Humaines
106|104|Training & Development|Formation et Développement|English (US)|Human Resources|Ressources Humaines"""

        return pd.read_csv(StringIO(csv_data), sep="|")

    @pytest.fixture
    def comprehensive_test_data(self):
        """Comprehensive test data covering all supported data types."""
        return pd.DataFrame(
            {
                # Integer types - different ranges
                "tiny_int": [1, 5, 10, 50, 100],  # SmallInteger
                "small_int": [100, 500, 1000, 5000, 32000],  # SmallInteger
                "medium_int": [50000, 100000, 500000, 1000000, 2000000],  # Integer
                "big_int": [
                    3000000000,
                    5000000000,
                    8000000000,
                    9000000000,
                    9223372036854775807,
                ],  # BigInteger
                # Integer with nulls (tests nullable integer handling)
                "nullable_int": [100, 200, None, 400, np.nan],
                # Float stored as whole numbers (like ParentsubjectID scenario)
                "float_as_int": [101.0, 202.0, np.nan, 104.0, 201.0],
                # Numeric/Decimal types
                "price": [19.99, 100.50, 0.99, 1234.56, 9999.99],
                "percentage": [0.05, 0.125, 0.333, 0.5, 0.999],
                "high_precision": [
                    123.456789,
                    0.000001,
                    999.999999,
                    1.23456789,
                    0.123456,
                ],
                # String types - various lengths
                "short_string": ["A", "AB", "ABC", "ABCD", "ABCDE"],
                "medium_string": [
                    "Product Name",
                    "Customer Service",
                    "Engineering Team",
                    "Quality Assurance",
                    "Human Resources",
                ],
                "long_string": [
                    "This is a longer description that exceeds typical short string lengths"
                ]
                * 5,
                # Unicode with special characters
                "unicode_french": [
                    "Ingénierie",
                    "Service Client",
                    "Qualité",
                    "Développement",
                    "Opérations",
                ],
                "unicode_mixed": [
                    "Café ☕",
                    "Résumé 📄",
                    "Naïve approach",
                    "Zürich 🇨🇭",
                    "São Paulo 🇧🇷",
                ],
                # String with nulls
                "optional_string": ["Value 1", None, "Value 2", np.nan, "Value 3"],
                # Boolean types
                "is_active": [True, False, True, True, False],
                "is_enabled_clean": [True, False, True, True, False],
                # DateTime types
                "created_date": pd.to_datetime(
                    [
                        "2024-01-01",
                        "2024-02-15",
                        "2024-03-30",
                        "2024-06-15",
                        "2024-12-31",
                    ]
                ),
                "updated_timestamp": pd.to_datetime(
                    [
                        "2024-01-01 10:30:00",
                        "2024-02-15 14:45:30",
                        "2024-03-30 09:15:00",
                        "2024-06-15 16:20:45",
                        "2024-12-31 23:59:59",
                    ]
                ),
                # DateTime with timezone
                "created_utc": pd.to_datetime(
                    [
                        "2024-01-01",
                        "2024-02-15",
                        "2024-03-30",
                        "2024-06-15",
                        "2024-12-31",
                    ]
                ).tz_localize("UTC"),
                # Timedelta
                "duration": pd.to_timedelta(
                    ["1 days", "2 hours", "30 minutes", "45 seconds", "1 days 12 hours"]
                ),
                # Mixed types (should fall back to string)
                "mixed_type": [1, "text", 3.14, True, None],
            }
        )

    @pytest.fixture
    def edge_case_data(self):
        """Edge cases and boundary conditions."""
        return pd.DataFrame(
            {
                # All nulls
                "all_nulls": [None, np.nan, None, np.nan, None],
                # Single value
                "single_value": ["Only Value", None, None, None, None],
                # Empty strings
                "empty_strings": ["", "", "", "", ""],
                # Very long string (should trigger UnicodeText)
                "very_long": [
                    "A" * 5000,
                    "B" * 4500,
                    "C" * 6000,
                    "D" * 5500,
                    "E" * 4800,
                ],
                # Extreme integers
                "max_small_int": [
                    32767,
                    32766,
                    32765,
                    -32768,
                    -32767,
                ],  # SmallInteger boundaries
                "max_int": [
                    2147483647,
                    2147483646,
                    -2147483648,
                    -2147483647,
                    0,
                ],  # Integer boundaries
                # High precision decimals
                "many_decimals": [
                    0.123456789012345,
                    9.999999999999999,
                    0.000000000000001,
                    123456.789012345,
                    0.100000000000000,
                ],
                # Date edge cases
                "old_dates": pd.to_datetime(
                    [
                        "1900-01-01",
                        "1970-01-01",
                        "2000-01-01",
                        "2024-01-01",
                        "2099-12-31",
                    ]
                ),
                # Zero values
                "zeros": [0, 0, 0, 0, 0],
                "zero_decimals": [0.0, 0.00, 0.000, 0.0000, 0.00000],
            }
        )

    @pytest.fixture
    def real_world_scenario_data(self):
        """Realistic business scenario data."""
        return pd.DataFrame(
            {
                "employee_id": range(1001, 1021),  # SmallInteger
                "department_id": [
                    10,
                    20,
                    10,
                    30,
                    20,
                    10,
                    40,
                    30,
                    20,
                    10,
                    50,
                    40,
                    30,
                    20,
                    10,
                    60,
                    50,
                    40,
                    30,
                    20,
                ],  # SmallInteger
                "manager_id": [
                    None,
                    1001,
                    1001,
                    1002,
                    1002,
                    1003,
                    1003,
                    1004,
                    1004,
                    1005,
                    1005,
                    1006,
                    1006,
                    1007,
                    1007,
                    1008,
                    1008,
                    1009,
                    1009,
                    1010,
                ],  # Nullable SmallInteger
                "salary": [
                    45000.00,
                    52000.50,
                    48000.75,
                    65000.00,
                    58000.25,
                    51000.00,
                    72000.50,
                    61000.00,
                    55000.75,
                    49000.00,
                    68000.50,
                    59000.25,
                    53000.00,
                    71000.75,
                    62000.00,
                    56000.50,
                    75000.00,
                    64000.25,
                    58000.00,
                    52000.75,
                ],  # Numeric
                "bonus_percentage": [
                    0.05,
                    0.10,
                    0.075,
                    0.15,
                    0.12,
                    0.08,
                    0.18,
                    0.13,
                    0.11,
                    0.07,
                    0.16,
                    0.12,
                    0.09,
                    0.17,
                    0.14,
                    0.10,
                    0.20,
                    0.15,
                    0.11,
                    0.08,
                ],  # Numeric
                "first_name": [
                    "Alice",
                    "Bob",
                    "Charlie",
                    "Diana",
                    "Edward",
                    "Fiona",
                    "George",
                    "Hannah",
                    "Ivan",
                    "Julia",
                    "Kevin",
                    "Laura",
                    "Michael",
                    "Nina",
                    "Oscar",
                    "Paula",
                    "Quinn",
                    "Rachel",
                    "Steve",
                    "Tina",
                ],  # Unicode
                "last_name": [
                    "Smith",
                    "Johnson",
                    "Williams",
                    "Brown",
                    "Jones",
                    "García",
                    "Müller",
                    "O'Brien",
                    "Dubois",
                    "Rossi",
                    "Kowalski",
                    "Novák",
                    "Hansen",
                    "Andersson",
                    "Pérez",
                    "Lefèvre",
                    "Schmidt",
                    "Møller",
                    "Jørgensen",
                    "López",
                ],  # Unicode with special chars
                "email": [
                    f"employee{i}@company.com" for i in range(1001, 1021)
                ],  # Unicode
                "is_active": [True] * 18 + [False, False],  # Boolean
                "hire_date": pd.date_range(
                    "2020-01-01", periods=20, freq="2ME"
                ),  # DateTime
                "last_login": pd.date_range(
                    "2024-01-01", periods=20, freq="3D"
                ),  # DateTime
                "time_in_position": pd.to_timedelta(
                    [f"{i * 30} days" for i in range(1, 21)]
                ),  # Timedelta
                "notes": [
                    "New hire",
                    None,
                    "Promoted",
                    None,
                    "Transfer",
                    None,
                    "New hire",
                    "Promoted",
                    None,
                    "Transfer",
                    None,
                    None,
                    "New hire",
                    None,
                    "Promoted",
                    "Transfer",
                    None,
                    "New hire",
                    None,
                    None,
                ],  # Nullable Unicode
            }
        )

    # ==================== Integer Type Inference Tests ====================

    def test_infer_small_integer(self, inferrer):
        """Test inference of SmallInteger for values in range -32,768 to 32,767."""
        df = pd.DataFrame({"small_int": [1, 100, 500, 32000, -15000]})

        result = inferrer.infer_from_dataframe(df)

        assert isinstance(result["small_int"], types.SmallInteger)

    def test_infer_integer(self, inferrer):
        """Test inference of Integer for values exceeding SmallInteger range."""
        df = pd.DataFrame({"regular_int": [1, 100000, 500000, 2000000000]})

        result = inferrer.infer_from_dataframe(df)

        assert isinstance(result["regular_int"], types.Integer)

    def test_infer_big_integer(self, inferrer):
        """Test inference of BigInteger for values exceeding Integer range."""
        df = pd.DataFrame(
            {
                "big_int": [1, 3000000000, 9223372036854775807]  # Max int64
            }
        )

        result = inferrer.infer_from_dataframe(df)

        assert isinstance(result["big_int"], types.BigInteger)

    def test_infer_integer_with_nulls(self, inferrer):
        """Test integer inference when column contains NULL values."""
        df = pd.DataFrame({"int_with_nulls": [1, 100, None, 500, np.nan, 1000]})

        result = inferrer.infer_from_dataframe(df)

        assert isinstance(result["int_with_nulls"], types.SmallInteger)

    def test_infer_integer_from_float_dtype(self, inferrer):
        """Test that whole numbers stored as float64 are inferred as Integer."""
        # This tests the scenario where nullable integer columns become float64 in pandas
        df = pd.DataFrame({"parent_id": [201.0, 202.0, np.nan, 104.0, 201.0]})

        result = inferrer.infer_from_dataframe(df)

        # Should be SmallInteger, not Numeric
        assert isinstance(result["parent_id"], types.SmallInteger)

    # ==================== Numeric/Decimal Type Inference Tests ====================

    def test_infer_numeric_with_decimals(self, inferrer):
        """Test inference of Numeric for actual decimal values."""
        df = pd.DataFrame({"price": [19.99, 100.50, 0.99, 1234.56]})

        result = inferrer.infer_from_dataframe(df)

        assert isinstance(result["price"], types.Numeric)
        assert result["price"].precision >= 6
        assert result["price"].scale >= 2

    def test_infer_numeric_high_precision(self, inferrer):
        """Test Numeric inference with high precision requirements."""
        df = pd.DataFrame({"precise_value": [123.456789, 0.000001, 999.999999]})

        result = inferrer.infer_from_dataframe(df)

        assert isinstance(result["precise_value"], types.Numeric)
        assert result["precise_value"].scale >= 6

    # ==================== String/Unicode Type Inference Tests ====================

    def test_infer_unicode_string(self, inferrer):
        """Test inference of Unicode type for string columns."""
        df = pd.DataFrame({"title": ["Support", "Presales B2B", "Marketing"]})

        result = inferrer.infer_from_dataframe(df)

        assert isinstance(result["title"], types.Unicode)
        assert result["title"].length >= 12  # 'Presales B2B' = 12 chars

    def test_infer_unicode_with_french_characters(self, inferrer):
        """Test Unicode inference with French accented characters."""
        df = pd.DataFrame(
            {
                "title_fr": [
                    "Fonctions supports",
                    "Avant-vente Client BtoB",
                    "Responsabilité sociétale des entreprises",
                ]
            }
        )

        result = inferrer.infer_from_dataframe(df)

        assert isinstance(result["title_fr"], types.Unicode)
        # Should handle accented characters properly
        assert result["title_fr"].length >= 40

    def test_infer_unicode_with_safety_buffer(self, inferrer):
        """Test that Unicode length includes safety buffer."""
        df = pd.DataFrame(
            {"text": ["Short", "A bit longer text", "Maximum length string here"]}
        )

        result = inferrer.infer_from_dataframe(df)

        max_length = len("Maximum length string here")  # 27
        # Should be at least max_length * 1.2 (safety buffer)
        assert result["text"].length >= max_length * 1.2

    def test_infer_unicode_text_for_long_strings(self, inferrer):
        """Test that very long strings use Text instead of Unicode."""
        long_string = "A" * 5000  # Exceeds MAX_STRING_LENGTH (4000)
        df = pd.DataFrame({"long_text": [long_string, "Short", "Medium length"]})

        result = inferrer.infer_from_dataframe(df)

        assert isinstance(result["long_text"], types.Text)

    def test_infer_string_with_nulls(self, inferrer):
        """Test string inference with NULL values."""
        df = pd.DataFrame(
            {"optional_text": ["Value 1", None, "Value 2", np.nan, "Value 3"]}
        )

        result = inferrer.infer_from_dataframe(df)

        assert isinstance(result["optional_text"], types.Unicode)

    # ==================== Boolean Type Inference Tests ====================

    def test_infer_boolean_as_small_integer(self, inferrer):
        """Test that boolean columns are inferred as SmallInteger (1/0)."""
        df = pd.DataFrame({"is_active": [True, False, True, True, False]})

        result = inferrer.infer_from_dataframe(df)

        assert isinstance(result["is_active"], types.SmallInteger)

    def test_infer_boolean_with_nulls(self, inferrer):
        """Test boolean inference with NULL values."""
        df = pd.DataFrame({"is_enabled": [True, False, None, True, np.nan]})

        result = inferrer.infer_from_dataframe(df)

        assert isinstance(
            result["is_enabled"], (types.SmallInteger, types.Unicode, types.String)
        )

    # ==================== DateTime Type Inference Tests ====================

    def test_infer_datetime_naive(self, inferrer):
        """Test inference of timezone-naive DateTime."""
        df = pd.DataFrame(
            {"created_at": pd.to_datetime(["2024-01-01", "2024-06-15", "2024-12-31"])}
        )

        result = inferrer.infer_from_dataframe(df)

        assert isinstance(result["created_at"], types.DateTime)
        assert result["created_at"].timezone is False

    def test_infer_datetime_aware(self, inferrer):
        """Test inference of timezone-aware DateTime."""
        df = pd.DataFrame(
            {
                "created_at": pd.to_datetime(["2024-01-01", "2024-06-15"]).tz_localize(
                    "UTC"
                )
            }
        )

        result = inferrer.infer_from_dataframe(df)

        assert isinstance(result["created_at"], types.DateTime)
        assert result["created_at"].timezone is True

    def test_infer_datetime_from_string(self, inferrer):
        """Test datetime inference from string values (if DETECT_DATETIME_STRINGS=True)."""
        df = pd.DataFrame({"date_string": ["2024-01-01", "2024-06-15", "2024-12-31"]})

        # This depends on your DETECT_DATETIME_STRINGS setting
        result = inferrer.infer_from_dataframe(df)

        # Should either be DateTime or Unicode depending on configuration
        assert isinstance(
            result["date_string"], (types.DateTime, types.Date, types.Unicode)
        )

    # ==================== Timedelta Type Inference Tests ====================

    def test_infer_timedelta_as_big_integer(self, inferrer):
        """Test that timedelta is inferred as BigInteger (microseconds)."""
        df = pd.DataFrame(
            {"duration": pd.to_timedelta(["1 days", "2 hours", "30 minutes"])}
        )

        result = inferrer.infer_from_dataframe(df)

        assert isinstance(result["duration"], types.BigInteger)

    # ==================== Edge Cases and Error Handling ====================

    def test_infer_all_null_column(self, inferrer):
        """Test inference when all values are NULL."""
        df = pd.DataFrame({"all_nulls": [None, np.nan, None, np.nan]})

        result = inferrer.infer_from_dataframe(df)

        # Should default to String with minimum length
        assert isinstance(result["all_nulls"], types.String)
        assert result["all_nulls"].length == inferrer.MIN_STRING_LENGTH

    def test_infer_empty_dataframe(self, inferrer):
        """Test inference on empty DataFrame."""
        df = pd.DataFrame()

        result = inferrer.infer_from_dataframe(df)

        assert result == {}

    def test_infer_mixed_types_object_column(self, inferrer):
        """Test inference when object column has mixed types."""
        df = pd.DataFrame({"mixed": [1, "text", 3.14, True, None]})

        result = inferrer.infer_from_dataframe(df)

        # Should fall back to Unicode
        assert isinstance(result["mixed"], types.Unicode)

    # ==================== Comprehensive Data Type Tests ====================

    def test_comprehensive_data_types(self, inferrer, comprehensive_test_data):
        """Test inference across all supported data types."""
        result = inferrer.infer_from_dataframe(comprehensive_test_data)

        # Integer types
        assert isinstance(result["tiny_int"], types.SmallInteger)
        assert isinstance(result["small_int"], types.SmallInteger)
        assert isinstance(result["medium_int"], types.Integer)
        assert isinstance(result["big_int"], types.BigInteger)
        assert isinstance(result["nullable_int"], types.SmallInteger)
        assert isinstance(result["float_as_int"], types.SmallInteger)  # Key test!

        # Numeric types
        assert isinstance(result["price"], types.Numeric)
        assert isinstance(result["percentage"], types.Numeric)
        assert isinstance(result["high_precision"], types.Numeric)

        # String types
        assert isinstance(result["short_string"], (types.Unicode, types.String))
        assert isinstance(result["medium_string"], (types.Unicode, types.String))
        assert isinstance(result["long_string"], (types.Unicode, types.String))
        assert isinstance(result["unicode_french"], (types.Unicode, types.String))
        assert isinstance(result["unicode_mixed"], (types.Unicode, types.String))
        assert isinstance(result["optional_string"], (types.Unicode, types.String))

        # Boolean
        assert isinstance(result["is_active"], types.SmallInteger)
        assert isinstance(result["is_enabled_clean"], types.SmallInteger)

        # DateTime
        assert isinstance(result["created_date"], types.DateTime)
        assert isinstance(result["updated_timestamp"], types.DateTime)
        assert isinstance(result["created_utc"], types.DateTime)
        assert result["created_utc"].timezone is True

        # Timedelta
        assert isinstance(result["duration"], types.BigInteger)

        # Mixed type
        assert isinstance(result["mixed_type"], (types.Unicode, types.String))

    def test_edge_cases(self, inferrer, edge_case_data):
        """Test edge cases and boundary conditions."""
        result = inferrer.infer_from_dataframe(edge_case_data)

        # All nulls should default to String with MIN_STRING_LENGTH
        assert isinstance(result["all_nulls"], types.String)
        assert result["all_nulls"].length == inferrer.MIN_STRING_LENGTH

        # Single value
        assert isinstance(result["single_value"], (types.Unicode, types.String))

        # Empty strings
        assert isinstance(result["empty_strings"], (types.Unicode, types.String))

        # Very long string should be Text
        assert isinstance(result["very_long"], types.Text)

        # Integer boundaries
        assert isinstance(result["max_small_int"], types.SmallInteger)
        assert isinstance(result["max_int"], types.Integer)

        # High precision
        assert isinstance(result["many_decimals"], types.Numeric)
        assert result["many_decimals"].scale >= 10

        # Dates
        assert isinstance(result["old_dates"], types.DateTime)

        # Zeros
        assert isinstance(result["zeros"], types.SmallInteger)
        assert isinstance(result["zero_decimals"], (types.SmallInteger, types.Numeric))

    def test_real_world_scenario(self, inferrer, real_world_scenario_data):
        """Test realistic business scenario with employee data."""
        result = inferrer.infer_from_dataframe(real_world_scenario_data)

        # IDs
        assert isinstance(result["employee_id"], types.SmallInteger)
        assert isinstance(result["department_id"], types.SmallInteger)
        assert isinstance(result["manager_id"], types.SmallInteger)

        # Financial data
        assert isinstance(result["salary"], types.Numeric)
        assert isinstance(result["bonus_percentage"], types.Numeric)

        # Names with international characters
        assert isinstance(result["first_name"], types.Unicode)
        assert isinstance(result["last_name"], types.Unicode)
        assert isinstance(result["email"], types.Unicode)

        # Boolean
        assert isinstance(result["is_active"], types.SmallInteger)

        # Dates
        assert isinstance(result["hire_date"], types.DateTime)
        assert isinstance(result["last_login"], types.DateTime)

        # Duration
        assert isinstance(result["time_in_position"], types.BigInteger)

        # Optional field
        assert isinstance(result["notes"], types.Unicode)

    # ==================== Real-World Integration Tests ====================

    def test_infer_subjects_dataframe(self, inferrer, sample_subjects_data):
        """Test inference on hierarchical subject data with parent-child relationships."""
        result = inferrer.infer_from_dataframe(sample_subjects_data)

        # SubjectID: should be SmallInteger
        assert isinstance(result["SubjectID"], types.SmallInteger)

        # ParentsubjectID: should be SmallInteger (not Numeric!)
        assert isinstance(result["ParentsubjectID"], types.SmallInteger)

        # String columns: should be Unicode
        assert isinstance(result["SubjectTitle EN"], types.Unicode)
        assert isinstance(result["SubjectTitle FR"], types.Unicode)
        assert isinstance(result["DefaultLanguage"], types.Unicode)

        # Check French title has adequate length for accented characters
        assert (
            result["SubjectTitle FR"].length >= 30
        )  # 'Formation et Développement' = 27 chars

    # ==================== File-Based Inference Tests ====================

    def test_infer_from_parquet_file(self, inferrer, sample_subjects_data):
        """Test dtype inference from Parquet file."""
        with tempfile.NamedTemporaryFile(suffix=".parquet", delete=False) as tmp:
            sample_subjects_data.to_parquet(tmp.name, index=False)
            tmp_path = tmp.name

        try:
            result = inferrer.infer_from_parquet(tmp_path)

            assert isinstance(
                result["SubjectID"],
                (types.SmallInteger, types.Integer, types.BigInteger),
            )
            assert isinstance(result["SubjectTitle FR"], (types.Unicode, types.String))
        finally:
            os.unlink(tmp_path)

    def test_infer_from_orc_file(self, inferrer, sample_subjects_data):
        """Test dtype inference from ORC file."""
        pytest.importorskip("pyarrow")  # Skip if pyarrow not installed

        with tempfile.NamedTemporaryFile(suffix=".orc", delete=False) as tmp:
            sample_subjects_data.to_orc(tmp.name, index=False)
            tmp_path = tmp.name

        try:
            result = inferrer.infer_from_orc(tmp_path)

            assert isinstance(
                result["SubjectID"],
                (types.SmallInteger, types.Integer, types.BigInteger),
            )
        finally:
            os.unlink(tmp_path)

    # ==================== Parametrized Tests ====================

    @pytest.mark.parametrize(
        "value,expected_type",
        [
            (100, types.SmallInteger),
            (50000, types.Integer),
            (3000000000, types.BigInteger),
        ],
    )
    def test_integer_range_detection(self, inferrer, value, expected_type):
        """Parametrized test for integer range detection."""
        df = pd.DataFrame({"value": [value]})
        result = inferrer.infer_from_dataframe(df)

        assert isinstance(result["value"], expected_type)

    @pytest.mark.parametrize(
        "text,min_expected_length",
        [
            ("Short", 20),  # MIN_STRING_LENGTH
            ("A" * 50, 60),  # 50 * 1.2 buffer
            ("A" * 100, 120),  # 100 * 1.2 buffer
        ],
    )
    def test_string_length_calculation(self, inferrer, text, min_expected_length):
        """Parametrized test for string length calculation with buffer."""
        df = pd.DataFrame({"text": [text]})
        result = inferrer.infer_from_dataframe(df)

        assert result["text"].length >= min_expected_length

    @pytest.mark.parametrize(
        "dtype_str,expected_sqlalchemy_type",
        [
            ("int64", types.Integer),
            ("float64", types.Numeric),
            ("bool", types.SmallInteger),
            ("datetime64[ns]", types.DateTime),
            ("object", types.Unicode),
        ],
    )
    def test_pandas_dtype_mapping(self, inferrer, dtype_str, expected_sqlalchemy_type):
        """Parametrized test for pandas dtype to SQLAlchemy type mapping."""
        if dtype_str == "int64":
            df = pd.DataFrame({"col": pd.array([1, 2, 3], dtype="int64")})
            # Small values will be SmallInteger, not Integer
            expected_types = (types.SmallInteger, types.Integer)
        elif dtype_str == "float64":
            df = pd.DataFrame({"col": pd.array([1.5, 2.5, 3.5], dtype="float64")})
            expected_types = types.Numeric
        elif dtype_str == "bool":
            df = pd.DataFrame({"col": pd.array([True, False, True], dtype="bool")})
            expected_types = types.SmallInteger
        elif dtype_str == "datetime64[ns]":
            df = pd.DataFrame({"col": pd.to_datetime(["2024-01-01", "2024-01-02"])})
            expected_types = types.DateTime
        else:  # object
            df = pd.DataFrame({"col": ["a", "b", "c"]})
            expected_types = (types.Unicode, types.String)

        result = inferrer.infer_from_dataframe(df)

        # Check if result is instance of any expected type
        assert isinstance(result["col"], expected_types)
