def test_import_package():
    import easy_data_loader

    assert easy_data_loader.__version__ == "0.1.0"


def test_import_pipeline():
    from easy_data_loader.pipeline import LoadPipeline

    assert LoadPipeline is not None
