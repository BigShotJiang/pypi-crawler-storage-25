"""Version check and update-notification support for wxflywheel CLI.

This module implements the AI-Agent-facing version-notification system: every
CLI response carries a ``meta.cli`` field with the current version, the latest
version on PyPI, update availability, severity, and the commands an Agent
should run to upgrade. The background refresh mechanism uses a 24-hour local
cache and a fire-and-forget subprocess worker to avoid blocking the main
command on network I/O.

Design rules:

- **Never fail the main command**. Any exception in this module (network,
  file-system, parsing) is caught and downgraded to a null field. The user's
  actual CLI command MUST always succeed or fail on its own merits.
- **Always return the same meta schema**. Even when offline/cache-empty, the
  ``meta.cli`` object has the same 12 keys — some values are just ``None``.
  This lets Agents write deterministic JSON-parsing code without key-exists
  branches.
- **Worker-mode detection**. When running inside the background worker
  (triggered via ``python -m wxflywheel._version_check_worker``), we must NOT
  re-spawn another worker, otherwise we get an infinite fork loop.
- **Test-mode opt-out**. When ``WXFLYWHEEL_NO_META=1`` env var is set (used by
  pytest conftest), ``build_meta`` returns a minimal deterministic stub so
  unit tests are fast and hermetic.
"""

from __future__ import annotations

import contextlib
import json
import os
import re
import subprocess
import sys
import time
import warnings
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import requests
from packaging.version import InvalidVersion, Version

from wxflywheel import __version__

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

CACHE_TTL_SECONDS = 24 * 60 * 60  # 24 hours
PYPI_JSON_URL = "https://pypi.org/pypi/wxflywheel/json"
GITHUB_CHANGELOG_URL = (
    "https://raw.githubusercontent.com/vinsew/weixin/main/cli/CHANGELOG.md"
)
GITHUB_RELEASE_URL_TEMPLATE = (
    "https://github.com/vinsew/weixin/releases/tag/wxflywheel-v{version}"
)
UPDATE_COMMAND = "pip install --upgrade wxflywheel"
SELF_UPDATE_COMMAND = "wxflywheel self update"

BREAKING_PATTERNS: tuple[re.Pattern[str], ...] = (
    re.compile(r"###\s+Breaking", re.IGNORECASE),
    re.compile(r"\bBREAKING\s+CHANGE\b", re.IGNORECASE),
    # Case-sensitive prefix followed by whitespace, matches "BREAKING: text"
    # but not "abreaking:" or similar prose. No trailing \b because ':' is a
    # non-word char and \b would not match at the ':-to-whitespace' boundary.
    re.compile(r"\bBREAKING:\s"),
)

# Env vars (internal)
_ENV_WORKER_MODE = "WXFLYWHEEL_WORKER"
_ENV_NO_META = "WXFLYWHEEL_NO_META"


# ---------------------------------------------------------------------------
# Cache file I/O
# ---------------------------------------------------------------------------


def cache_dir() -> Path:
    """Return the cache directory path (not created here)."""
    override = os.environ.get("WXFLYWHEEL_CACHE_DIR")
    if override:
        return Path(override)
    return Path.home() / ".cache" / "wxflywheel"


def cache_file() -> Path:
    """Return the cache file path."""
    return cache_dir() / "version_check.json"


def load_cache() -> dict[str, Any] | None:
    """Load the version check cache; return None on any error (missing,
    permission denied, corrupted JSON, not a dict)."""
    try:
        path = cache_file()
        if not path.exists():
            return None
        with path.open("r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            return None
        return data
    except (OSError, ValueError):
        return None


def save_cache(cache: dict[str, Any]) -> bool:
    """Save the version check cache to disk. Return True on success, False on
    any filesystem error."""
    try:
        path = cache_file()
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("w", encoding="utf-8") as f:
            json.dump(cache, f, ensure_ascii=False, indent=2)
        return True
    except OSError:
        return False


def is_cache_expired(cache: dict[str, Any]) -> bool:
    """Return True if cache is older than CACHE_TTL_SECONDS or has no valid
    timestamp."""
    checked_at = cache.get("checked_at_epoch")
    if not isinstance(checked_at, (int, float)):
        return True
    return (time.time() - checked_at) > CACHE_TTL_SECONDS


def compute_cache_age_seconds(cache: dict[str, Any]) -> int | None:
    """Return cache age in seconds, or None if timestamp is invalid."""
    checked_at = cache.get("checked_at_epoch")
    if not isinstance(checked_at, (int, float)):
        return None
    return max(0, int(time.time() - checked_at))


# ---------------------------------------------------------------------------
# PyPI and GitHub CHANGELOG fetch
# ---------------------------------------------------------------------------


def fetch_pypi_latest(timeout: float = 5.0) -> tuple[str, str] | None:
    """Query PyPI JSON API for latest wxflywheel version.

    Returns (latest_version, upload_time_iso) tuple, or None on any failure.
    Upload time may be empty string if PyPI response lacks it.
    """
    try:
        resp = requests.get(PYPI_JSON_URL, timeout=timeout)
        resp.raise_for_status()
        data = resp.json()
    except (requests.RequestException, ValueError):
        return None

    if not isinstance(data, dict):
        return None

    info = data.get("info") or {}
    if not isinstance(info, dict):
        return None
    latest_version = info.get("version")
    if not isinstance(latest_version, str):
        return None

    # Upload time: pick first file in releases[latest_version]
    releases = data.get("releases") or {}
    upload_time: str = ""
    if isinstance(releases, dict):
        files = releases.get(latest_version) or []
        if isinstance(files, list) and files:
            first_file = files[0]
            if isinstance(first_file, dict):
                raw_time = first_file.get("upload_time_iso_8601") or first_file.get(
                    "upload_time"
                )
                if isinstance(raw_time, str):
                    upload_time = raw_time

    return latest_version, upload_time


def fetch_changelog_breaking(version: str, timeout: float = 5.0) -> bool:
    """Check if the CHANGELOG section for `version` contains any BREAKING
    marker. Returns False on fetch/parse failure.

    Supported markers (Keep a Changelog + Conventional Commits):
    - ``### Breaking`` section header
    - ``BREAKING CHANGE`` phrase
    - ``BREAKING:`` prefix (case sensitive, to avoid matching prose)
    """
    try:
        resp = requests.get(GITHUB_CHANGELOG_URL, timeout=timeout)
        resp.raise_for_status()
        text = resp.text
    except requests.RequestException:
        return False

    # Find the section for this version: ## [X.Y.Z] - YYYY-MM-DD
    section_start_match = re.search(
        rf"^##\s*\[{re.escape(version)}\]",
        text,
        re.MULTILINE,
    )
    if not section_start_match:
        return False

    # Find next section start (or EOF) to bound the current section body
    remaining = text[section_start_match.end() :]
    next_section_match = re.search(r"^##\s*\[", remaining, re.MULTILINE)
    section_body = (
        remaining[: next_section_match.start()] if next_section_match else remaining
    )

    # Check for breaking markers in this section
    return any(pattern.search(section_body) for pattern in BREAKING_PATTERNS)


def refresh_cache_from_pypi(timeout: float = 5.0) -> bool:
    """Query PyPI and (if an upgrade is available) the CHANGELOG, then write
    the cache file. Returns True on success."""
    result = fetch_pypi_latest(timeout=timeout)
    if result is None:
        return False

    latest_version, latest_release_date = result

    # Only check for breaking markers when there's actually an upgrade
    has_breaking = False
    try:
        current_v = Version(__version__)
        latest_v = Version(latest_version)
        if latest_v > current_v:
            has_breaking = fetch_changelog_breaking(latest_version, timeout=timeout)
    except InvalidVersion:
        pass

    cache = {
        "latest_version": latest_version,
        "latest_release_date": latest_release_date,
        "changelog_url": GITHUB_RELEASE_URL_TEMPLATE.format(version=latest_version),
        "has_breaking": has_breaking,
        "checked_at_epoch": time.time(),
        "checked_at_iso": datetime.now(timezone.utc).isoformat(),
        "cli_version_at_check": __version__,
    }
    return save_cache(cache)


# ---------------------------------------------------------------------------
# Version comparison and severity calculation
# ---------------------------------------------------------------------------


def compare_versions(current: str, latest: str) -> int:
    """Compare two version strings using PEP 440 semantics.
    Return -1 if current < latest, 0 if equal, 1 if current > latest.
    Returns 0 on any parse error (safest default: assume no update)."""
    try:
        c = Version(current)
        la = Version(latest)
    except InvalidVersion:
        return 0
    if c < la:
        return -1
    if c > la:
        return 1
    return 0


def compute_severity(current: str, latest: str, has_breaking: bool) -> str | None:
    """Compute update severity given current and latest version strings plus a
    flag indicating whether the CHANGELOG contains breaking markers.

    Returns one of ``"patch" / "minor" / "major" / "breaking"``, or None if
    no update is available or if versions cannot be parsed.
    """
    if compare_versions(current, latest) >= 0:
        return None
    if has_breaking:
        return "breaking"
    # compare_versions already guarded against InvalidVersion (returned 0
    # which >= 0 triggered early return above), so both Version() calls below
    # are guaranteed to succeed — no try/except needed.
    c = Version(current)
    la = Version(latest)

    c_release = c.release + (0, 0, 0)
    la_release = la.release + (0, 0, 0)
    if la_release[0] > c_release[0]:
        return "major"
    if la_release[1] > c_release[1]:
        return "minor"
    return "patch"


def compute_days_behind(release_date_iso: str | None) -> int | None:
    """Compute whole-day difference between `release_date_iso` and now.
    Returns None on parse error or empty string."""
    if not release_date_iso:
        return None
    try:
        dt = datetime.fromisoformat(release_date_iso.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        now = datetime.now(timezone.utc)
        delta = now - dt
        return max(0, delta.days)
    except (ValueError, AttributeError, TypeError):
        return None


# ---------------------------------------------------------------------------
# Background worker spawn (fire-and-forget) with sync fallback
# ---------------------------------------------------------------------------


def _in_worker_mode() -> bool:
    """Detect whether we're running inside the background worker subprocess.
    Used to prevent infinite worker spawn loops."""
    return os.environ.get(_ENV_WORKER_MODE) == "1"


def try_trigger_background_refresh() -> None:
    """Spawn a background worker subprocess to refresh the cache. Fire-and-
    forget (never blocks the caller, never raises).

    On platforms or environments where subprocess spawning fails (OSError —
    e.g., sandboxed containers that forbid fork), falls back to an inline
    synchronous refresh with a very short 500ms timeout. The fallback is still
    never allowed to raise.
    """
    if _in_worker_mode():
        # Safety: do not re-spawn from within the worker itself
        return

    try:
        kwargs: dict[str, Any] = {
            "stdout": subprocess.DEVNULL,
            "stderr": subprocess.DEVNULL,
            "stdin": subprocess.DEVNULL,
        }
        if sys.platform == "win32":
            # Windows: detach from parent console and suppress window
            DETACHED_PROCESS = 0x00000008
            CREATE_NO_WINDOW = 0x08000000
            kwargs["creationflags"] = DETACHED_PROCESS | CREATE_NO_WINDOW
        else:
            # POSIX: new session detaches from parent's process group
            kwargs["start_new_session"] = True

        # Intentional fire-and-forget: we never wait on or poll this Popen,
        # so its Python wrapper is GC'd while the child is still running. On
        # CPython 3.12+, Popen.__del__ emits a ResourceWarning in that case.
        # We suppress it locally because the child is detached (start_new_session
        # on POSIX, DETACHED_PROCESS | CREATE_NO_WINDOW on Windows) and has no
        # attached streams (all DEVNULL) — there is no real resource leak.
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", ResourceWarning)
            subprocess.Popen(
                [sys.executable, "-m", "wxflywheel._version_check_worker"],
                **kwargs,
            )
    except OSError:
        # Fallback: inline sync refresh with 500ms hard cap. Must never raise.
        with contextlib.suppress(Exception):
            refresh_cache_from_pypi(timeout=0.5)


# ---------------------------------------------------------------------------
# Meta envelope builder (the public entry point called by output.py)
# ---------------------------------------------------------------------------


def _empty_cli_meta() -> dict[str, Any]:
    """Return a fully-populated cli meta object with all 12 keys, some null.

    Keeping the schema stable (same keys every time, some values None) lets
    Agents write deterministic JSON-parsing code without branching on key
    existence — this is the Agent First expression rule applied to the meta
    field itself."""
    python_version = (
        f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    )
    return {
        "current_version": __version__,
        "python_version": python_version,
        "update_command": UPDATE_COMMAND,
        "self_update_command": SELF_UPDATE_COMMAND,
        "latest_version": None,
        "latest_release_date": None,
        "changelog_url": None,
        "update_available": None,
        "update_severity": None,
        "days_behind": None,
        "cache_age_seconds": None,
        "has_breaking": None,
    }


def build_meta() -> dict[str, Any]:
    """Build the top-level ``meta`` field injected into every JSON response.

    Returns a dict shaped as ``{"cli": { 12 keys }}``. All 12 keys are
    always present; unknown values are ``None``.

    This function is called by ``output.emit_payload``. It must never raise.
    """
    # Test-mode opt-out: pytest sets WXFLYWHEEL_NO_META=1 to avoid touching
    # network or filesystem during unit tests. Returns deterministic minimal
    # meta so assertions stay simple.
    if os.environ.get(_ENV_NO_META) == "1":
        return {"cli": {"current_version": __version__}}

    cli_meta = _empty_cli_meta()

    cache = load_cache()
    if cache is not None:
        latest = cache.get("latest_version")
        if isinstance(latest, str) and latest:
            cli_meta["latest_version"] = latest
            cli_meta["update_available"] = compare_versions(__version__, latest) < 0
            has_breaking = bool(cache.get("has_breaking", False))
            cli_meta["has_breaking"] = has_breaking
            cli_meta["update_severity"] = compute_severity(
                __version__, latest, has_breaking
            )

        release_date = cache.get("latest_release_date")
        if isinstance(release_date, str) and release_date:
            cli_meta["latest_release_date"] = release_date
            cli_meta["days_behind"] = compute_days_behind(release_date)

        changelog = cache.get("changelog_url")
        if isinstance(changelog, str) and changelog:
            cli_meta["changelog_url"] = changelog

        cli_meta["cache_age_seconds"] = compute_cache_age_seconds(cache)

    # Expired or missing cache → trigger background refresh for next call
    if cache is None or is_cache_expired(cache):
        try_trigger_background_refresh()

    return {"cli": cli_meta}
