from __future__ import annotations

import click

from wxflywheel.commands.common import require_client
from wxflywheel.config import RuntimeContext
from wxflywheel.output import JsonObject, json_command, success_payload


@click.group()
def search() -> None:
    """WeChat Search (微信搜一搜) — the in-app WeChat search engine that indexes official account articles, videos, mini-programs and more. These commands query WeChat Search's related-keywords aggregator used by the iOS/Android search suggestion box."""


@search.command()
@click.option("--seed", required=True, help="Seed keyword.")
@click.pass_obj
@json_command
def related(runtime: RuntimeContext, seed: str) -> JsonObject:
    """Get long-tail user-query related keywords for a seed term from WeChat Search (e.g. seed='咖啡' → ['附近咖啡店', '星巴克咖啡', '中国咖啡十大品牌']). These are phrase-level actual user queries from WeChat Search's suggestion aggregator, NOT short word associations — for short word-level terms use 'wxflywheel wxindex related' instead. Requires the WeChat account (identified by --key) to be online. Returns {seed, related[]}."""
    client = require_client(runtime)
    payload = client.post("/v1/Finder/RelatedKeywords", body={"KeyWord": seed})
    words = payload["data"]["words"]
    return success_payload({"seed": seed, "related": words}, payload["message"])
