from __future__ import annotations

from urllib.parse import quote

import click

from wxflywheel.commands.common import normalize_string_list, require_client
from wxflywheel.config import RuntimeContext
from wxflywheel.output import JsonObject, json_command, success_payload


@click.group()
def wxindex() -> None:
    """WeChat Index (微信指数 / wxindex) — WeChat's official search-volume trend data source. Returns short high-frequency terms that WeChat users frequently co-search with a given keyword."""


@wxindex.command()
@click.option("--keyword", required=True, help="WxIndex keyword.")
@click.pass_obj
@json_command
def related(runtime: RuntimeContext, keyword: str) -> JsonObject:
    """Get short high-frequency related terms for a keyword from WeChat Index (e.g. keyword='咖啡' → ['咖啡机', '咖啡色', '咖啡店']). These are short word-level associations reflecting WeChat's search trend dataset, NOT long-tail user queries — for long-tail use 'wxflywheel search related' instead. Does not require a logged-in WeChat account. Returns {keyword, related[]}."""
    client = require_client(runtime)
    payload = client.get(f"/api/wxindexsug/{quote(keyword, safe='')}")
    words = normalize_string_list(payload["data"])
    return success_payload({"keyword": keyword, "related": words}, payload["message"])
