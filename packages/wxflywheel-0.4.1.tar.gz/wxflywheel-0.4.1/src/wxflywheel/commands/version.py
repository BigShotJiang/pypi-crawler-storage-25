"""``wxflywheel version`` command group — version introspection and update check."""

from __future__ import annotations

import click

from wxflywheel.exceptions import WxflywheelError
from wxflywheel.output import JsonObject, json_command, success_payload


@click.group(name="version", invoke_without_command=True)
@click.pass_context
def version(ctx: click.Context) -> None:
    """wxflywheel version introspection and update check — display the currently installed CLI version, the latest available version on PyPI, update severity (patch/minor/major/breaking), and the exact commands an AI Agent should run to upgrade. The default subcommand reads the 24-hour local cache (fast, offline-tolerant); 'version check' forces a fresh synchronous PyPI query that bypasses the cache. When this group is invoked without a subcommand (just 'wxflywheel version'), it behaves identically to 'wxflywheel version show'. All subcommands emit the same 12-key cli meta schema as the meta.cli field on any other command's response, so Agents can use identical parsing code regardless of source."""
    if ctx.invoked_subcommand is None:
        ctx.invoke(show)


@version.command(name="show")
@json_command
def show() -> JsonObject:
    """Display wxflywheel version information from the local 24-hour cache without querying PyPI. This is a fast (<10ms), offline-tolerant operation suitable for every CLI invocation. Returns the same 12-field schema as meta.cli on any other command: {current_version, python_version, update_command, self_update_command, latest_version, latest_release_date, changelog_url, update_available, update_severity, days_behind, cache_age_seconds, has_breaking}. Fields that are unknown (cache empty or network never reached) are null — the schema stays stable for deterministic Agent parsing. For a forced fresh query that bypasses the cache, use 'wxflywheel version check' instead."""
    from wxflywheel.version_check import build_meta

    meta = build_meta()
    return success_payload(meta.get("cli", {}))


@version.command(name="check")
@json_command
def check() -> JsonObject:
    """Force a fresh version check by querying PyPI directly and, if an upgrade is detected, the GitHub CHANGELOG for breaking-change markers. This is a SYNCHRONOUS network call that may take 1-10 seconds depending on network latency; use sparingly. On success the local cache is updated and the refreshed 12-field cli meta is returned. On network failure the existing cache is NOT modified and an error with code -8 is emitted on stderr. Use this when you explicitly want to bypass the 24-hour cache (e.g., right after a user-triggered self update to confirm the new version registered on PyPI)."""
    from wxflywheel.version_check import build_meta, refresh_cache_from_pypi

    ok = refresh_cache_from_pypi(timeout=10.0)
    if not ok:
        raise WxflywheelError(
            -8,
            "Failed to query PyPI for latest wxflywheel version. Check network connectivity (https://pypi.org/pypi/wxflywheel/json must be reachable) and try again. The existing local cache (if any) was NOT modified by this failure.",
        )

    meta = build_meta()
    return success_payload(meta.get("cli", {}))
