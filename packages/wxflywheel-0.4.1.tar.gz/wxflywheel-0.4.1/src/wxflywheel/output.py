from __future__ import annotations

import json
from functools import wraps
from typing import Any, Callable, TypeVar

import click

from wxflywheel.exceptions import SUCCESS_CODE, WxflywheelError

JsonObject = dict[str, Any]
F = TypeVar("F", bound=Callable[..., JsonObject])


def success_payload(data: Any, message: str = "") -> JsonObject:
    return {"code": SUCCESS_CODE, "data": data, "message": message}


def error_payload(code: int, message: str, data: Any = None) -> JsonObject:
    """Build a standard error envelope and automatically attach a compact
    environment fingerprint under ``data._environment``.

    The fingerprint lets an Agent (or the upstream maintainer) diagnose
    platform-specific failures without having to round-trip "what OS are you
    on?" questions. If ``data`` is None we wrap it into a dict; if it is
    already a dict we add the key in-place. For non-dict data (list / str /
    primitive), we create a new dict ``{"details": original_data, "_environment": ...}``
    so the fingerprint always has a home. Environment collection is wrapped
    in a broad except — it must never cause an error response to fail."""
    enriched: Any = data
    try:
        from wxflywheel.environment import collect_environment

        env = collect_environment()
        if data is None:
            enriched = {"_environment": env}
        elif isinstance(data, dict):
            enriched = {**data, "_environment": env}
        else:
            enriched = {"details": data, "_environment": env}
    except Exception:
        # Environment collection must never break the error contract
        enriched = data
    return {"code": code, "data": enriched, "message": message}


def emit_payload(
    payload: JsonObject, *, err: bool = False, include_meta: bool = True
) -> None:
    """Emit a JSON payload to stdout (or stderr if ``err=True``).

    When ``include_meta=True`` (default), the payload is augmented with a
    top-level ``meta`` field containing version info and update-check status
    for AI Agents. Meta injection is wrapped in a broad except so that any
    failure in the version-check subsystem (network, filesystem, parsing) can
    never break the main command's output contract — the Agent always gets
    its primary ``code/data/message`` response even when ``meta`` is absent.
    """
    if include_meta:
        try:
            # Delayed import to avoid circular dependency with wxflywheel.__init__
            from wxflywheel.version_check import build_meta

            payload = {**payload, "meta": build_meta()}
        except Exception:
            # Meta injection must never fail the main command
            pass
    click.echo(json.dumps(payload, ensure_ascii=False, indent=2), err=err)


def emit_error_payload(code: int, message: str, data: Any = None, *, err: bool = True) -> None:
    emit_payload(error_payload(code, message, data), err=err)


def emit_error(error: WxflywheelError) -> None:
    emit_error_payload(error.code, error.message, error.data)
    raise SystemExit(1)


def json_command(func: F) -> F:
    @wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> None:
        try:
            payload = func(*args, **kwargs)
        except WxflywheelError as error:
            emit_error(error)
        else:
            emit_payload(payload)

    return wrapper  # type: ignore[return-value]
