"""Tests for the ``wxflywheel version`` command group."""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from click.testing import CliRunner

from wxflywheel import __version__, version_check
from wxflywheel.cli import cli


@pytest.fixture
def _version_env(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Enable real version_check behavior in an isolated cache dir."""
    monkeypatch.setenv("WXFLYWHEEL_CACHE_DIR", str(tmp_path / "cache"))
    monkeypatch.delenv("WXFLYWHEEL_NO_META", raising=False)
    # Prevent any real subprocess/network
    monkeypatch.setattr(version_check, "try_trigger_background_refresh", lambda: None)


def test_version_show_empty_cache_returns_stable_schema(_version_env: None) -> None:
    runner = CliRunner()
    result = runner.invoke(cli, ["version", "show"])
    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["code"] == 200
    cli_meta = payload["data"]
    assert cli_meta["current_version"] == __version__
    assert cli_meta["latest_version"] is None
    assert cli_meta["update_available"] is None
    assert cli_meta["update_command"] == version_check.UPDATE_COMMAND


def test_version_default_is_show(_version_env: None) -> None:
    runner = CliRunner()
    # Invoking just `wxflywheel version` with no subcommand
    result = runner.invoke(cli, ["version"])
    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["data"]["current_version"] == __version__


def test_version_check_success(
    _version_env: None, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr(
        version_check,
        "fetch_pypi_latest",
        lambda timeout=5.0: ("99.0.0", "2026-04-06T00:00:00Z"),
    )
    monkeypatch.setattr(
        version_check, "fetch_changelog_breaking", lambda v, timeout=5.0: False
    )
    runner = CliRunner()
    result = runner.invoke(cli, ["version", "check"])
    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["data"]["latest_version"] == "99.0.0"
    assert payload["data"]["update_available"] is True
    assert payload["data"]["update_severity"] == "major"


def test_version_check_failure_emits_error(
    _version_env: None, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr(version_check, "fetch_pypi_latest", lambda timeout=5.0: None)
    runner = CliRunner()
    result = runner.invoke(cli, ["version", "check"])
    assert result.exit_code == 1
    err_payload = json.loads(result.stderr)
    assert err_payload["code"] == -8
    assert "PyPI" in err_payload["message"]


def test_version_check_with_breaking_marker(
    _version_env: None, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr(
        version_check,
        "fetch_pypi_latest",
        lambda timeout=5.0: ("99.0.0", "2026-04-06T00:00:00Z"),
    )
    monkeypatch.setattr(
        version_check, "fetch_changelog_breaking", lambda v, timeout=5.0: True
    )
    runner = CliRunner()
    result = runner.invoke(cli, ["version", "check"])
    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["data"]["update_severity"] == "breaking"
    assert payload["data"]["has_breaking"] is True


def test_version_show_help_mentions_agents() -> None:
    runner = CliRunner()
    result = runner.invoke(cli, ["version", "show", "--help"])
    assert result.exit_code == 0
    # Agent First expression rule: help mentions Agents and schema
    assert "Agent" in result.output or "meta" in result.output
