import json
from unittest.mock import patch

from click.testing import CliRunner

from tests.conftest import MockRespFactory
from wxflywheel.cli import cli

ENV = {"WXFLYWHEEL_KEY": "test-key", "WXFLYWHEEL_HOST": "http://localhost:8011"}


def test_related_aggregate_outputs_cross_source_merge(mock_resp: MockRespFactory) -> None:
    runner = CliRunner()
    with patch(
        "wxflywheel.client.requests.request",
        side_effect=[
            mock_resp(
                {
                    "code": 200,
                    "data": {
                        "words": [
                            "社群运营工具",
                            "社群运营招聘",
                            "社群运营方案",
                            "社群运营工具",
                        ]
                    },
                    "message": "",
                }
            ),
            mock_resp(
                {
                    "code": 200,
                    "data": ["社群运营招聘", "社群运营课程", "社群运营", "社群运营课程"],
                    "message": "",
                }
            ),
        ],
    ):
        result = runner.invoke(
            cli,
            ["related", "aggregate", "--keyword", "社群运营"],
            env=ENV,
        )
    assert result.exit_code == 0
    data = json.loads(result.output)
    payload = data["data"]
    assert payload["keyword"] == "社群运营"
    assert payload["related"] == [
        "社群运营招聘",
        "社群运营工具",
        "社群运营方案",
        "社群运营课程",
        "社群运营",
    ]
    assert payload["both_sources"] == ["社群运营招聘"]
    assert payload["search_only"] == ["社群运营工具", "社群运营方案"]
    assert payload["wxindex_only"] == ["社群运营课程", "社群运营"]
    assert payload["errors"] == {}


def test_related_aggregate_returns_partial_success_when_one_source_fails(
    mock_resp: MockRespFactory,
) -> None:
    runner = CliRunner()
    with patch(
        "wxflywheel.client.requests.request",
        side_effect=[
            mock_resp(
                {
                    "code": 200,
                    "data": {"words": ["社群运营工具", "社群运营招聘"]},
                    "message": "",
                }
            ),
            mock_resp(
                {
                    "code": 300,
                    "data": None,
                    "message": "auth failed",
                }
            ),
        ],
    ):
        result = runner.invoke(
            cli,
            ["related", "aggregate", "--keyword", "社群运营"],
            env=ENV,
        )
    assert result.exit_code == 0
    data = json.loads(result.output)
    payload = data["data"]
    assert payload["related"] == ["社群运营工具", "社群运营招聘"]
    assert payload["from_wxindex"] == []
    assert payload["errors"] == {
        "wxindex": {"code": 300, "message": "auth failed"}
    }


def test_related_aggregate_keeps_partial_success_when_successful_source_is_empty(
    mock_resp: MockRespFactory,
) -> None:
    runner = CliRunner()
    with patch(
        "wxflywheel.client.requests.request",
        side_effect=[
            mock_resp({"code": 200, "data": {"words": []}, "message": ""}),
            mock_resp({"code": 300, "data": None, "message": "auth failed"}),
        ],
    ):
        result = runner.invoke(
            cli,
            ["related", "aggregate", "--keyword", "冷门词"],
            env=ENV,
        )
    assert result.exit_code == 0
    data = json.loads(result.output)
    payload = data["data"]
    assert payload["related"] == []
    assert payload["from_search"] == []
    assert payload["errors"] == {
        "wxindex": {"code": 300, "message": "auth failed"}
    }


def test_related_aggregate_normalizes_null_data_to_empty_lists(
    mock_resp: MockRespFactory,
) -> None:
    runner = CliRunner()
    with patch(
        "wxflywheel.client.requests.request",
        side_effect=[
            mock_resp({"code": 200, "data": {"words": None}, "message": ""}),
            mock_resp({"code": 200, "data": None, "message": ""}),
        ],
    ):
        result = runner.invoke(
            cli,
            ["related", "aggregate", "--keyword", "空词"],
            env=ENV,
        )
    assert result.exit_code == 0
    data = json.loads(result.output)
    payload = data["data"]
    assert payload["related"] == []
    assert payload["from_search"] == []
    assert payload["from_wxindex"] == []
    assert payload["errors"] == {}


def test_related_aggregate_handles_non_dict_search_payload_and_filters_non_string_items(
    mock_resp: MockRespFactory,
) -> None:
    runner = CliRunner()
    with patch(
        "wxflywheel.client.requests.request",
        side_effect=[
            mock_resp({"code": 200, "data": [], "message": ""}),
            mock_resp({"code": 200, "data": ["社群运营", 1, None], "message": ""}),
        ],
    ):
        result = runner.invoke(
            cli,
            ["related", "aggregate", "--keyword", "混合词"],
            env=ENV,
        )
    assert result.exit_code == 0
    data = json.loads(result.output)
    payload = data["data"]
    assert payload["from_search"] == []
    assert payload["from_wxindex"] == ["社群运营"]
    assert payload["related"] == ["社群运营"]


def test_related_aggregate_fails_when_both_sources_fail(mock_resp: MockRespFactory) -> None:
    runner = CliRunner()
    with patch(
        "wxflywheel.client.requests.request",
        side_effect=[
            mock_resp({"code": 300, "data": None, "message": "search failed"}),
            mock_resp({"code": 301, "data": None, "message": "wxindex failed"}),
        ],
    ):
        result = runner.invoke(
            cli,
            ["related", "aggregate", "--keyword", "社群运营"],
            env=ENV,
        )
    assert result.exit_code == 1
    err_data = json.loads(result.stderr)
    assert err_data["code"] == 300
    assert err_data["message"] == "Both related keyword sources failed."
    # v0.4.0: error responses now carry an _environment fingerprint under data.
    # Original keys (search, wxindex) must still be present with correct values.
    assert err_data["data"]["search"] == {"code": 300, "message": "search failed"}
    assert err_data["data"]["wxindex"] == {"code": 301, "message": "wxindex failed"}
    assert "_environment" in err_data["data"]


def test_related_aggregate_calls_both_endpoints_with_expected_paths(
    mock_resp: MockRespFactory,
) -> None:
    runner = CliRunner()
    with patch(
        "wxflywheel.client.requests.request",
        side_effect=[
            mock_resp({"code": 200, "data": {"words": []}, "message": ""}),
            mock_resp({"code": 200, "data": [], "message": ""}),
        ],
    ) as mock_request:
        result = runner.invoke(
            cli,
            ["related", "aggregate", "--keyword", "社群 运营"],
            env=ENV,
        )
    assert result.exit_code == 0
    first_call = mock_request.call_args_list[0]
    second_call = mock_request.call_args_list[1]
    assert first_call.args[0] == "POST"
    assert first_call.args[1] == "http://localhost:8011/v1/Finder/RelatedKeywords"
    assert first_call.kwargs["json"] == {"KeyWord": "社群 运营"}
    assert second_call.args[0] == "GET"
    assert second_call.args[1] == "http://localhost:8011/api/wxindexsug/%E7%A4%BE%E7%BE%A4%20%E8%BF%90%E8%90%A5"
