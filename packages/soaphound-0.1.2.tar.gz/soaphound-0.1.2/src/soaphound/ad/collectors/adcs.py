####################
#
# ADCS Collection logic for Bloodhound using pure ADWS
#
####################

import logging
from soaphound.ad.cache_gen import pull_all_ad_objects, _parse_aces, dedupe_aces, BH_TYPE_LABEL_MAP
from soaphound.lib.utils import ADUtils
from uuid import UUID
from impacket.ldap.ldaptypes import LDAP_SID

def collect_adcs(
    ip=None,
    domain=None,
    username=None,
    auth=None,
    base_dn_override=None,
    id_to_type_cache=None,
    objecttype_guid_map=None
):
    """
    Collects Certificate Authorities (pKIEnrollmentService) and Certificate Templates (pKICertificateTemplate)
    via ADWS and formats them for BloodHound ingestion.
    """
    logging.info("Starting ADCS data collection via ADWS...")

    ca_attributes = [
        "name", "distinguishedName", "objectGUID", "dNSHostName", 
        "cACertificate", "certificateTemplates", "nTSecurityDescriptor"
    ]
    template_attributes = [
        "name", "distinguishedName", "objectGUID", "displayName",
        "msPKI-Certificate-Name-Flag", "msPKI-Enrollment-Flag",
        "msPKI-Private-Key-Flag", "msPKI-RA-Signature", "msPKI-Template-Schema-Version",
        "msPKI-Template-Minor-Revision", "pKIExtendedKeyUsage", "pKIKeyUsage",
        "pKIMaxIssuingDepth", "nTSecurityDescriptor"
    ]

    ca_query = "(objectClass=pKIEnrollmentService)"
    template_query = "(objectClass=pKICertificateTemplate)"

    # Use Public Key Services configuration container if available, but search_base=config_dn works effectively
    config_container = base_dn_override if base_dn_override else ""

    logging.debug("Pulling Enterprise CAs...")
    raw_cas = pull_all_ad_objects(
        ip=ip, domain=domain, username=username, auth=auth,
        query=ca_query, attributes=ca_attributes, base_dn_override=config_container
    ).get("objects", [])

    logging.debug("Pulling Certificate Templates...")
    raw_templates = pull_all_ad_objects(
        ip=ip, domain=domain, username=username, auth=auth,
        query=template_query, attributes=template_attributes, base_dn_override=config_container
    ).get("objects", [])

    formatted_cas = format_cas(raw_cas, domain, id_to_type_cache, objecttype_guid_map)
    formatted_templates = format_templates(raw_templates, domain, id_to_type_cache, objecttype_guid_map)

    logging.info(f"Collected {len(formatted_cas)} Enterprise CAs and {len(formatted_templates)} Certificate Templates.")

    return {
        "cas": formatted_cas,
        "templates": formatted_templates
    }

def format_cas(raw_cas, domain, id_to_type_cache, objecttype_guid_map):
    """
    Format Enterprise CA objects for BH EnterpriseCA node representation.
    """
    cas = []
    for ca in raw_cas:
        guid_bytes = ADUtils.get_entry_property(ca, "objectGUID")
        ca_guid = str(UUID(bytes_le=guid_bytes)).upper() if isinstance(guid_bytes, bytes) else (guid_bytes.upper() if guid_bytes else "")
        
        dns_hostname = ADUtils.get_entry_property(ca, "dNSHostName", "")
        name = ADUtils.get_entry_property(ca, "name", "")
        
        # Determine CA fully qualified name for principal linkage
        principal_name = dns_hostname.upper() if dns_hostname else f"{name.upper()}.{domain.upper()}"

        properties = {
            "name": principal_name,
            "domain": domain.upper(),
            "distinguishedname": ADUtils.get_entry_property(ca, "distinguishedName", "").upper(),
            "certificatetemplates": ADUtils.get_entry_property(ca, "certificateTemplates", [])
        }

        # Handle cert arrays
        if not isinstance(properties["certificatetemplates"], list):
            properties["certificatetemplates"] = [properties["certificatetemplates"]] if properties["certificatetemplates"] else []

        aces, isaclprotected = _parse_aces(
            ca.get("nTSecurityDescriptor"),
            id_to_type_cache,
            ca_guid, # CA's are often tracked via guid in BH enterprise objects, or computer sid if bound
            "EnterpriseCA",
            object_type_guid_map=objecttype_guid_map
        )
        aces = dedupe_aces(aces)

        ca_entry = {
            "ObjectIdentifier": ca_guid,
            "Properties": properties,
            "Aces": aces,
            "IsDeleted": False
        }
        cas.append(ca_entry)

    return cas

def format_templates(raw_templates, domain, id_to_type_cache, objecttype_guid_map):
    """
    Format Certificate Template objects for BH CertTemplate node representation.
    """
    templates = []
    for tpl in raw_templates:
        guid_bytes = ADUtils.get_entry_property(tpl, "objectGUID")
        tpl_guid = str(UUID(bytes_le=guid_bytes)).upper() if isinstance(guid_bytes, bytes) else (guid_bytes.upper() if guid_bytes else "")
        
        name = ADUtils.get_entry_property(tpl, "name", "")
        display_name = ADUtils.get_entry_property(tpl, "displayName", "")

        properties = {
            "name": f"{name.upper()}@{domain.upper()}",
            "domain": domain.upper(),
            "distinguishedname": ADUtils.get_entry_property(tpl, "distinguishedName", "").upper(),
        }

        # Gather relevant msPKI-* properties
        int_props = {
            "mspki-certificate-name-flag": "msPKI-Certificate-Name-Flag",
            "mspki-enrollment-flag": "msPKI-Enrollment-Flag",
            "mspki-private-key-flag": "msPKI-Private-Key-Flag"
        }
        for bh_key, ad_key in int_props.items():
            val = ADUtils.get_entry_property(tpl, ad_key, 0)
            properties[bh_key] = int(val) if val else 0

        aces, isaclprotected = _parse_aces(
            tpl.get("nTSecurityDescriptor"),
            id_to_type_cache,
            tpl_guid,
            "CertTemplate",
            object_type_guid_map=objecttype_guid_map
        )
        aces = dedupe_aces(aces)

        tpl_entry = {
            "ObjectIdentifier": tpl_guid,
            "Properties": properties,
            "Aces": aces,
            "IsDeleted": False
        }
        templates.append(tpl_entry)

    return templates
