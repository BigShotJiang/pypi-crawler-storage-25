"""
sysvol_parser.py - SYSVOL GPO Policy Parser for Soaphound
Connects to SYSVOL share via SMB (impacket) to read GptTmpl.inf and Groups.xml
and build a gpo_changes_data dict for BloodHound GPOChanges population.

This module is ONLY used when collectionmethod != 'ADWSOnly'.
"""
import logging
import re
import io
import xml.etree.ElementTree as ET

from impacket.smbconnection import SMBConnection
from impacket.dcerpc.v5 import transport

log = logging.getLogger(__name__)

# Builtin group SID -> GPOChanges key
_LOCAL_GROUP_MAP = {
    "S-1-5-32-544": "LocalAdmins",           # Administrators
    "S-1-5-32-555": "RemoteDesktopUsers",     # Remote Desktop Users
    "S-1-5-32-562": "DcomUsers",              # Distributed COM Users
    "S-1-5-32-580": "PSRemoteUsers",          # Remote Management Users (WinRM)
}

# Privilege right name -> GPOChanges key
_PRIVILEGE_MAP = {
    "seinteractivelogonright":      "LocalAdmins",       # Local logon (admin-equivalent)
    "seremoteinteractivelogonright": "RemoteDesktopUsers",
    "senetworklogonright":           "PSRemoteUsers",     # WinRM/network logon
}


def _smb_connect(dc_ip, domain, username, password=None, nt_hash=None):
    """Establish an SMB connection to the DC using NTLM auth."""
    smb = SMBConnection(dc_ip, dc_ip, sess_port=445, timeout=10)
    lm_hash = "aad3b435b51404eeaad3b435b51404ee"
    if nt_hash:
        smb.login(username, "", domain, lmhash=lm_hash, nthash=nt_hash)
    else:
        smb.login(username, password or "", domain)
    return smb


def _read_smb_file(smb_conn, share, path):
    """Read a file from an SMB share. Returns raw bytes or None on failure."""
    buf = io.BytesIO()
    try:
        smb_conn.getFile(share, path, buf.write)
        return buf.getvalue()
    except Exception as e:
        log.debug(f"[SYSVOL] Could not read \\\\share\\{share}\\{path}: {e}")
        return None


def _decode(data):
    """Try multiple encodings (UTF-16-LE, UTF-8, Latin-1) for .inf files."""
    for enc in ("utf-16-le", "utf-8-sig", "utf-8", "latin-1"):
        try:
            return data.decode(enc)
        except Exception:
            continue
    return data.decode("latin-1", errors="replace")


# ────────────────────────────────────────────────────────────────────────────
# GptTmpl.inf parser
# ────────────────────────────────────────────────────────────────────────────

def _parse_inf_section(text, section_name):
    """Extract a single named section from an .inf file. Returns list of lines."""
    pattern = re.compile(
        r"\[" + re.escape(section_name) + r"\]\s*\n(.*?)(?=\n\[|\Z)",
        re.IGNORECASE | re.DOTALL,
    )
    m = pattern.search(text)
    if not m:
        return []
    return [l.strip() for l in m.group(1).splitlines() if l.strip() and not l.strip().startswith(";")]


def _extract_sids_from_value(raw_value):
    """
    Extract SIDs from a comma-separated INF value field.
    Values can be bare SIDs (*S-1-5-xxx) or account names.
    Returns list of uppercase SID strings (or names) without leading '*'.
    """
    sids = []
    for part in raw_value.split(","):
        part = part.strip()
        if not part:
            continue
        if part.startswith("*"):
            part = part[1:]  # strip leading *
        sids.append(part.upper())
    return sids


def parse_gpttmpl(data, id_to_type_cache, value_to_id_cache):
    """
    Parse GptTmpl.inf content. Returns a dict:
      { "LocalAdmins": [...TypedPrincipal...],
        "RemoteDesktopUsers": [...],
        "DcomUsers": [...],
        "PSRemoteUsers": [...] }
    """
    result = {k: [] for k in ["LocalAdmins", "RemoteDesktopUsers", "DcomUsers", "PSRemoteUsers"]}
    text = _decode(data)

    # ── [Privilege Rights] ──────────────────────────────────────────────────
    for line in _parse_inf_section(text, "Privilege Rights"):
        if "=" not in line:
            continue
        right, _, values = line.partition("=")
        right = right.strip().lower()
        category = _PRIVILEGE_MAP.get(right)
        if not category:
            continue
        for sid_or_name in _extract_sids_from_value(values):
            principal = _resolve_principal(sid_or_name, id_to_type_cache, value_to_id_cache)
            if principal:
                result[category].append(principal)

    # ── [Group Membership] ───────────────────────────────────────────────────
    # Format:  *S-1-5-32-544__Members = *S-1-5-21-...-1104,*S-1-5-21-...-512
    # Or:      *S-1-5-32-544__Memberof = ...  (which group is THIS added to — inverse, skip)
    for line in _parse_inf_section(text, "Group Membership"):
        if "=" not in line:
            continue
        lhs, _, rhs = line.partition("=")
        lhs = lhs.strip()
        # We care about __Members (who belongs to this group)
        if "__Members" not in lhs:
            continue
        group_sid_part = lhs.split("__")[0].strip()
        if group_sid_part.startswith("*"):
            group_sid_part = group_sid_part[1:]
        group_sid = group_sid_part.upper()
        category = _LOCAL_GROUP_MAP.get(group_sid)
        if not category:
            continue
        for sid_or_name in _extract_sids_from_value(rhs):
            if not sid_or_name:
                continue
            principal = _resolve_principal(sid_or_name, id_to_type_cache, value_to_id_cache)
            if principal:
                result[category].append(principal)

    return result


# ────────────────────────────────────────────────────────────────────────────
# Groups.xml (Group Policy Preferences) parser
# ────────────────────────────────────────────────────────────────────────────

def parse_groups_xml(data, id_to_type_cache, value_to_id_cache):
    """
    Parse Machine/Preferences/Groups/Groups.xml for local group membership.
    Returns same dict format as parse_gpttmpl.
    """
    result = {k: [] for k in ["LocalAdmins", "RemoteDesktopUsers", "DcomUsers", "PSRemoteUsers"]}
    try:
        root = ET.fromstring(_decode(data))
    except Exception as e:
        log.debug(f"[SYSVOL] Failed to parse Groups.xml: {e}")
        return result

    for group_elem in root.findall(".//Group"):
        # Identify target group
        props = group_elem.find("Properties")
        if props is None:
            continue
        group_sid = props.get("groupSid", "").upper()
        group_name = props.get("groupName", "").upper()

        # Match by SID or well-known name
        category = _LOCAL_GROUP_MAP.get(group_sid)
        if not category:
            # Try by common name fallback
            name_map = {
                "ADMINISTRATORS": "LocalAdmins",
                "REMOTE DESKTOP USERS": "RemoteDesktopUsers",
                "DISTRIBUTED COM USERS": "DcomUsers",
                "REMOTE MANAGEMENT USERS": "PSRemoteUsers",
            }
            category = name_map.get(group_name.rstrip())
        if not category:
            continue

        action = props.get("action", "").upper()
        # U=Update (add+remove), C=Create, R=Replace, D=Delete
        # We care about cases where members are being added (U, C, R)
        if action == "D":
            continue

        for member_elem in group_elem.findall(".//Member"):
            sid = member_elem.get("sid", "").upper()
            name = member_elem.get("name", "")
            action_m = member_elem.get("action", "ADD").upper()
            if action_m == "REMOVE":
                continue
            if sid:
                principal = _resolve_principal(sid, id_to_type_cache, value_to_id_cache)
            elif name:
                principal = _resolve_principal(name.upper(), id_to_type_cache, value_to_id_cache)
            else:
                continue
            if principal:
                result[category].append(principal)

    return result


# ────────────────────────────────────────────────────────────────────────────
# Principal resolution
# ────────────────────────────────────────────────────────────────────────────

_TYPE_NUM_TO_LABEL = {
    0: "User",
    1: "Group",
    2: "Computer",
    3: "GPO",
    4: "OU",
    5: "Domain",
    6: "Container",
}

def _resolve_principal(sid_or_name, id_to_type_cache, value_to_id_cache):
    """
    Try to resolve SID (or name) to a TypedPrincipal dict.
    Returns {"ObjectIdentifier": "...", "ObjectType": "..."} or None.
    """
    sid_or_name = sid_or_name.strip().upper()
    if not sid_or_name:
        return None

    # It's a raw SID string
    if sid_or_name.startswith("S-1-"):
        type_num = id_to_type_cache.get(sid_or_name)
        if type_num is not None:
            return {"ObjectIdentifier": sid_or_name, "ObjectType": _TYPE_NUM_TO_LABEL.get(type_num, "Base")}
        # Unknown SID but still return it as Base (BloodHound handles unknowns gracefully)
        return {"ObjectIdentifier": sid_or_name, "ObjectType": "Base"}

    # It's a name → try value_to_id_cache (DN or sAMAccountName lookup)
    obj_id = value_to_id_cache.get(sid_or_name)
    if obj_id:
        type_num = id_to_type_cache.get(obj_id)
        return {"ObjectIdentifier": obj_id, "ObjectType": _TYPE_NUM_TO_LABEL.get(type_num, "Base")}

    log.debug(f"[SYSVOL] Could not resolve principal: {sid_or_name}")
    return None


# ────────────────────────────────────────────────────────────────────────────
# GPOChanges merger
# ────────────────────────────────────────────────────────────────────────────

def _merge_gpo_results(base, extra):
    """Merge two GPO result dicts, deduplicating by ObjectIdentifier."""
    for key in base:
        existing_ids = {p["ObjectIdentifier"] for p in base[key]}
        for p in extra.get(key, []):
            if p["ObjectIdentifier"] not in existing_ids:
                base[key].append(p)
                existing_ids.add(p["ObjectIdentifier"])


# ────────────────────────────────────────────────────────────────────────────
# Main entry point
# ────────────────────────────────────────────────────────────────────────────

def collect_gpo_changes(
    dc_ip,
    domain,
    username,
    password=None,
    nt_hash=None,
    raw_gpos=None,
    id_to_type_cache=None,
    value_to_id_cache=None,
):
    """
    Connects to SYSVOL via SMB and parses all GPO policy files.

    Returns:
        gpo_changes_data: dict keyed by GPO GUID (uppercase, with braces) ->
            {
              "LocalAdmins":         [TypedPrincipal, ...],
              "RemoteDesktopUsers":  [...],
              "DcomUsers":           [...],
              "PSRemoteUsers":       [...],
            }
    """
    if id_to_type_cache is None:
        id_to_type_cache = {}
    if value_to_id_cache is None:
        value_to_id_cache = {}
    if not raw_gpos:
        return {}

    gpo_changes_data = {}

    log.info(f"[SYSVOL] Connecting to \\\\{dc_ip}\\SYSVOL ...")
    try:
        smb = _smb_connect(dc_ip, domain, username, password=password, nt_hash=nt_hash)
    except Exception as e:
        log.warning(f"[SYSVOL] SMB connection to {dc_ip} failed: {e} — GPOChanges will be empty.")
        return {}

    domain_upper = domain.upper()

    for gpo_obj in raw_gpos:
        # Get the gPCFileSysPath from ADWS-collected raw GPO object
        def _get_ci(d, k):
            k_low = k.lower()
            return next((v for key, v in d.items() if key.lower() == k_low), None)

        sysvol_path = _get_ci(gpo_obj, "gPCFileSysPath") or ""
        if isinstance(sysvol_path, list):
            sysvol_path = sysvol_path[0] if sysvol_path else ""
        sysvol_path = sysvol_path.strip()
        if not sysvol_path:
            continue

        # Convert UNC path to share-relative path
        # e.g. \\DC01\SYSVOL\pirate.htb\Policies\{GUID}
        # → share=SYSVOL, rel=pirate.htb\Policies\{GUID}
        parts = sysvol_path.replace("\\\\", "").split("\\")
        # parts[0]=DC01, parts[1]=SYSVOL, parts[2:]=rest
        if len(parts) < 3 or parts[1].upper() != "SYSVOL":
            log.debug(f"[SYSVOL] Unexpected path format: {sysvol_path}")
            continue

        share = "SYSVOL"
        rel_path = "\\".join(parts[2:])  # e.g. pirate.htb\Policies\{GUID}

        # Derive GPO GUID from the last component of the path (should be {GUID})
        guid_str = parts[-1].upper().strip("{}")
        gpo_guid_key = "{" + guid_str + "}"

        gpo_result = {k: [] for k in ["LocalAdmins", "RemoteDesktopUsers", "DcomUsers", "PSRemoteUsers"]}

        # ── Read GptTmpl.inf ──────────────────────────────────────────────
        inf_path = rel_path + "\\MACHINE\\MICROSOFT\\WINDOWS NT\\SECEDIT\\GPTTMPL.INF"
        inf_data = _read_smb_file(smb, share, inf_path)
        if inf_data:
            log.debug(f"[SYSVOL] Parsing GptTmpl.inf for GPO {gpo_guid_key}")
            inf_result = parse_gpttmpl(inf_data, id_to_type_cache, value_to_id_cache)
            _merge_gpo_results(gpo_result, inf_result)
        else:
            # Try case-sensitive alternate path (some DCs use different casing)
            inf_path2 = rel_path + "\\Machine\\Microsoft\\Windows NT\\SecEdit\\GptTmpl.inf"
            inf_data = _read_smb_file(smb, share, inf_path2)
            if inf_data:
                log.debug(f"[SYSVOL] Parsing GptTmpl.inf (alt path) for GPO {gpo_guid_key}")
                inf_result = parse_gpttmpl(inf_data, id_to_type_cache, value_to_id_cache)
                _merge_gpo_results(gpo_result, inf_result)

        # ── Read Groups.xml (GPP) ─────────────────────────────────────────
        xml_path = rel_path + "\\MACHINE\\PREFERENCES\\GROUPS\\GROUPS.XML"
        xml_data = _read_smb_file(smb, share, xml_path)
        if xml_data:
            log.debug(f"[SYSVOL] Parsing Groups.xml for GPO {gpo_guid_key}")
            xml_result = parse_groups_xml(xml_data, id_to_type_cache, value_to_id_cache)
            _merge_gpo_results(gpo_result, xml_result)
        else:
            xml_path2 = rel_path + "\\Machine\\Preferences\\Groups\\Groups.xml"
            xml_data = _read_smb_file(smb, share, xml_path2)
            if xml_data:
                log.debug(f"[SYSVOL] Parsing Groups.xml (alt path) for GPO {gpo_guid_key}")
                xml_result = parse_groups_xml(xml_data, id_to_type_cache, value_to_id_cache)
                _merge_gpo_results(gpo_result, xml_result)

        # Only store if there's something to record
        if any(gpo_result[k] for k in gpo_result):
            gpo_changes_data[gpo_guid_key] = gpo_result
            log.info(
                f"[SYSVOL] GPO {gpo_guid_key}: "
                f"LocalAdmins={len(gpo_result['LocalAdmins'])}, "
                f"RDP={len(gpo_result['RemoteDesktopUsers'])}, "
                f"DCOM={len(gpo_result['DcomUsers'])}, "
                f"PSRemote={len(gpo_result['PSRemoteUsers'])}"
            )

    try:
        smb.logoff()
    except Exception:
        pass

    log.info(f"[SYSVOL] Parsed {len(gpo_changes_data)} GPOs with policy members.")
    return gpo_changes_data
