####################
#
# Copyright (c) 2018 Fox-IT
# Modified for ADWS
#
####################
import logging
import threading

class ObjectResolver(object):
    """
    This class is responsible for resolving objects. This can be for example sAMAccountNames which
    should be resolved in the GC to see which domain they belong to, or SIDs which have to be
    resolved somewhere else. This resolver is thread-safe.
    """
    def __init__(self, addomain, addc):
        self.addomain = addomain
        self.addc = addc
        self.lock = threading.Lock()
        
    def _escape_filter_chars(self, text):
        """
        Escape characters special to LDAP filters.
        """
        escape_chars = {'*': '\\2a', '(': '\\28', ')': '\\29', '\\': '\\5c', '\x00': '\\00'}
        for char, escape in escape_chars.items():
            text = text.replace(char, escape)
        return text

    def resolve_distinguishedname(self, distinguishedname, use_gc=True):
        """
        Resolve a DistinguishedName in ADWS. This will use the GC by default
        Returns a single ADWS entry dictionary.
        """
        with self.lock:
            if use_gc and not getattr(self.addc, 'adws_gc', None):
                if not self.addc.adws_connect(use_gc=True):
                    return None
            if not use_gc and not getattr(self.addc, 'adws_enum', None):
                if not self.addc.adws_connect(use_gc=False):
                    return None

            if use_gc:
                logging.debug('Querying GC for DN %s', distinguishedname)
            else:
                logging.debug('Querying ADWS for DN %s', distinguishedname)
            
            entry = self.addc.ldap_get_single(distinguishedname,
                                              use_gc=use_gc,
                                              use_resolver=True,
                                              attributes=['sAMAccountName', 'distinguishedName', 'sAMAccountType', 'objectSid', 'name'])
            return entry

    def resolve_samname(self, samname, use_gc=True, allow_filter=False):
        """
        Resolve a SAM name in the GC. This can give multiple results.
        Returns a list of ADWS entry dictionaries.
        """
        out = []
        if not allow_filter:
            safename = self._escape_filter_chars(samname)
        else:
            safename = samname
            
        with self.lock:
            if use_gc:
                if not getattr(self.addc, 'adws_gc', None):
                    if not self.addc.adws_connect(use_gc=True):
                        return None
                logging.debug('Querying GC for SAM Name %s', samname)
            else:
                if not getattr(self.addc, 'adws_enum', None):
                    if not self.addc.adws_connect(use_gc=False):
                        return None
                logging.debug('Querying ADWS for SAM Name %s', samname)
                
            entries = self.addc.search(search_base="",
                                       search_filter=f'(sAMAccountName={safename})',
                                       use_gc=use_gc,
                                       attributes=['sAMAccountName', 'distinguishedName', 'sAMAccountType', 'objectSid', 'name'])
            for entry in entries:
                out.append(entry)

        return out

    def resolve_upn(self, upn):
        """
        Resolve a UserPrincipalName in the GC.
        Returns a single ADWS entry dictionary.
        """
        safename = self._escape_filter_chars(upn)
        with self.lock:
            if not getattr(self.addc, 'adws_gc', None):
                if not self.addc.adws_connect(use_gc=True):
                    return None
            logging.debug('Querying GC for UPN %s', upn)
            entries = self.addc.search(search_base="",
                                       search_filter=f'(&(objectClass=user)(userPrincipalName={safename}))',
                                       use_gc=True,
                                       attributes=['sAMAccountName', 'distinguishedName', 'sAMAccountType', 'objectSid', 'name'])
            for entry in entries:
                return entry

    def resolve_sid(self, sid, use_gc=True):
        """
        Resolve a SID in ADWS. This will use the GC by default
        Returns a single ADWS entry dictionary.
        """
        with self.lock:
            if use_gc and not getattr(self.addc, 'adws_gc', None):
                if not self.addc.adws_connect(use_gc=True):
                    return None
            if not use_gc and not getattr(self.addc, 'adws_enum', None):
                if not self.addc.adws_connect(use_gc=False):
                    return None
                    
            if use_gc:
                base = ""
                logging.debug('Querying GC for SID %s', sid)
            else:
                logging.debug('Querying ADWS for SID %s', sid)
                # Ensure we specify root dn here, or leave empty if your logic dictates
                base = getattr(self.addc.ad, 'baseDN', "")
                
            entries = self.addc.search(search_base=base,
                                       search_filter=f'(objectSid={sid})',
                                       use_gc=use_gc,
                                       use_resolver=True,
                                       attributes=['sAMAccountName', 'distinguishedName', 'sAMAccountType', 'name'])
            for entry in entries:
                return entry

    def gc_sam_lookup(self, samname):
        """
        This function attempts to resolve the SAM name returned in session enumeration to
        a user/domain combination by querying the Global Catalog.
        """
        output = []
        entries = self.resolve_samname(samname)
        if entries is None:
            return None
        if len(entries) > 0:
            for entry in entries:
                val = entry['attributes'].get('objectSid')
                if val:
                    output.append(val)
        else:
            logging.warning('Failed to resolve SAM name %s in current forest', samname)
        return output
