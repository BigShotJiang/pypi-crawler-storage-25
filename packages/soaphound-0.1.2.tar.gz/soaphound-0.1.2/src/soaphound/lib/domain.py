####################
#
# Copyright (c) 2018 Fox-IT
# Modified to use pure ADWS
#
####################
import logging
import traceback
import codecs
import json
from uuid import UUID
from dns import resolver

from .utils import ADUtils, DNSCache, SidCache, SamCache, CollectionException
from soaphound.ad.collectors.bh_rpc_computer import ADComputer
from .objectresolver import ObjectResolver
from soaphound.ad.adws import ADWSConnect, NTLMAuth
from soaphound.ad.cache_gen import pull_all_ad_objects


"""
Active Directory Domain Controller (ADWS Version)
"""
class ADDC(ADComputer):
    def __init__(self, hostname=None, ad=None):
        ADComputer.__init__(self, hostname)
        self.ad = ad
        # Core ADWS connection used for searches
        self.adws_enum: ADWSConnect | None = None
        self.adws_gc: ADWSConnect | None = None
        
        # Initialize GUID map
        self.objecttype_guid_map = dict()

    def adws_connect(self, use_gc=False):
        """
        Connect to ADWS service
        """
        if use_gc:
            server = self.ad.gcs()[0] if self.ad.gcs() else self.hostname
            logging.info('Connecting to GC ADWS server: %s' % server)
            # Find IP for server using DNS
            ip = server
            try:
                q = self.ad.dnsresolver.query(server, tcp=self.ad.dns_tcp)
                ip = q[0].address
            except Exception:
                pass
            # GC ADWS port is typically 9389, handled in ADWS Connect by endpoint GC
            try:
                self.adws_gc = ADWSConnect(ip, self.ad.domain, self.ad.auth.username, NTLMAuth(password=self.ad.auth.password, hashes=self.ad.auth.nt_hash), "Enumeration")
                return True
            except Exception as e:
                logging.error(f"Failed to connect to GC ADWS: {e}")
                return False
        else:
            logging.info('Connecting to ADWS server: %s' % self.hostname)
            # Convert hostname to IP
            ip = self.hostname
            try:
                q = self.ad.dnsresolver.query(self.hostname, tcp=self.ad.dns_tcp)
                ip = q[0].address
            except Exception:
                pass
            
            try:
                self.adws_enum = ADWSConnect(ip, self.ad.domain, self.ad.auth.username, NTLMAuth(password=self.ad.auth.password, hashes=self.ad.auth.nt_hash), "Enumeration")
                return True
            except Exception as e:
                logging.error(f"Failed to connect to ADWS: {e}")
                return False

    def search(self, search_filter='(objectClass=*)', attributes=None, search_base=None, generator=True, use_gc=False, use_resolver=False, query_sd=False, is_retry=False, search_scope=None):
        """
        Search for objects using ADWS pull_all_ad_objects format.
        Will yield items formatted as dictionaries to mimic original LDAP responses.
        """
        if attributes is None or attributes == []:
            attributes = ['distinguishedName', 'objectClass', 'name', 'objectSid'] # Bare minimum

        if query_sd and 'nTSecurityDescriptor' not in attributes:
            attributes.append('nTSecurityDescriptor')

        client = self.adws_gc if use_gc else self.adws_enum
        
        # Auto-connect if not established
        if client is None:
            if not self.adws_connect(use_gc=use_gc):
                return
            client = self.adws_gc if use_gc else self.adws_enum
            
        auth = NTLMAuth(password=self.ad.auth.password, hashes=self.ad.auth.nt_hash)

        try:
            # We use cache_gen's pull logic which formats to list of dicts mapped nicely.
            data = pull_all_ad_objects(
                client._fqdn, self.ad.domain, self.ad.auth.username, auth,
                query=search_filter, attributes=attributes, base_dn_override=search_base
            )
            objs = data.get('objects', [])
            
            # Generator output format adapting ADWS dict to mimic ldap3 for Bloodhound parsers
            for obj in objs:
                formatted_entry = {
                    'type': 'searchResEntry',
                    'attributes': obj,
                    'raw_attributes': obj # In ADWS text parses, we don't hold raw differently initially
                }
                yield formatted_entry

        except Exception as e:
            if is_retry:
                logging.error(f'Search query {search_filter} failed completely: {e}')
            else:
                logging.warning(f'Retrying connection and query: {search_filter}')
                if self.adws_connect(use_gc=use_gc):
                    yield from self.search(search_filter, attributes, search_base, generator, use_gc, use_resolver, query_sd, is_retry=True, search_scope=search_scope)

    def ldap_get_single(self, qobject, attributes=None, use_gc=False, use_resolver=False, is_retry=False):
        """
        Get a single object, mapped via search_filter matching the DistinguishedName.
        """
        escaped_dn = qobject.replace('\\', '\\\\').replace('(', '\\28').replace(')', '\\29')
        # This translates to looking for exact DN match which LDAP filter supports in ADWS.
        entries = self.search(f"(distinguishedName={escaped_dn})", attributes=attributes, search_base=qobject, use_gc=use_gc, is_retry=is_retry)
        for entry in entries:
            return entry
        return None

    def get_domain_controllers(self):
        entries = self.search('(userAccountControl:1.2.840.113556.1.4.803:=8192)',
                              ['dnshostname', 'samaccounttype', 'samaccountname',
                               'serviceprincipalname', 'objectSid'])
        return entries

    def get_netbios_name(self, context):
        try:
            entries = self.search(f'(ncname={context})',
                                  ['nETBIOSName'],
                                  search_base=f"CN=Partitions,{self.ad.config_dn}")
            return next(entries)
        except StopIteration:
            return None
        except Exception as e:
            logging.warning('Could not determine NetBiosname of the domain: %s', str(e))
            return None

    def get_objecttype(self):
        """
        Function to get objecttype GUID is handled primarily in soaphound.py adws_objecttype_guid_map now,
        we just pull it here if needed or it's passed down.
        """
        # Kept mostly for backward comp if not passed
        pass

    def get_domains(self, acl=False):
        entries = self.search('(objectClass=domain)',
                              ['distinguishedName', 'objectSid', 'name'],
                              generator=True,
                              query_sd=acl)

        entriesNum = 0
        for entry in entries:
            entriesNum += 1
            domain_object = ADDomain.fromADWS(entry['attributes'].get('distinguishedName', ''), entry['attributes'].get('objectSid'))
            self.ad.domain_object = domain_object
            self.ad.domains[entry['attributes']['distinguishedName']] = entry
            try:
                nbentry = self.get_netbios_name(entry['attributes']['distinguishedName'])
                if nbentry:
                    self.ad.nbdomains[nbentry['attributes']['nETBIOSName']] = entry
            except Exception:
                pass

        logging.info('Found %u domains', entriesNum)
        return entries

    def get_forest_domains(self):
        entries = self.search('(objectClass=crossRef)',
                              ['nETBIOSName', 'systemFlags', 'nCName', 'name'],
                              search_base=f"CN=Partitions,{self.ad.config_dn}",
                              generator=True)

        entriesNum = 0
        for entry in entries:
            if not entry['attributes'].get('systemFlags'):
                continue
            # Naming context, not a domain
            if not int(entry['attributes']['systemFlags']) & 2:
                continue
            entry['attributes']['distinguishedName'] = entry['attributes']['nCName']
            entriesNum += 1
            
            if entry['attributes']['nCName'] not in self.ad.domains:
                self.ad.domains[entry['attributes']['nCName']] = entry
                self.ad.nbdomains[entry['attributes']['nETBIOSName']] = entry

        self.ad.num_domains = entriesNum
        logging.info('Found %u domains in the forest', entriesNum)

    def get_groups(self, include_properties=False, acl=False):
        properties = ['distinguishedName', 'samaccountname', 'samaccounttype', 'objectsid', 'member']
        if include_properties:
            properties += ['adminCount', 'description', 'whencreated']
        if acl:
            properties += ['nTSecurityDescriptor']
        return self.search('(objectClass=group)', properties, generator=True, query_sd=acl)

    def get_gpos(self, include_properties=False, acl=False):
        properties = ['distinguishedName', 'name', 'objectGUID', 'gPCFileSysPath', 'displayName']
        if include_properties:
            properties += ['description', 'whencreated']
        if acl:
            properties += ['nTSecurityDescriptor']
        return self.search('(objectCategory=groupPolicyContainer)', properties, generator=True, query_sd=acl)

    def get_ous(self, include_properties=False, acl=False):
        properties = ['distinguishedName', 'name', 'objectGUID', 'gPLink', 'gPOptions']
        if include_properties:
            properties += ['description', 'whencreated']
        if acl:
            properties += ['nTSecurityDescriptor']
        return self.search('(objectCategory=organizationalUnit)', properties, generator=True, query_sd=acl)

    def get_containers(self, include_properties=False, acl=False, dn=''):
        properties = ['distinguishedName', 'name', 'objectGUID', 'isCriticalSystemObject','objectClass', 'objectCategory']
        if include_properties:
            properties += ['description', 'whencreated']
        if acl:
            properties += ['nTSecurityDescriptor']
        return self.search('(&(objectCategory=container)(objectClass=container))', properties, generator=True, query_sd=acl, search_base=dn)

    def get_users(self, include_properties=False, acl=False):
        properties = ['sAMAccountName', 'distinguishedName', 'sAMAccountType',
                      'objectSid', 'primaryGroupID', 'isDeleted', 'objectClass', 'msDS-GroupMSAMembership']

        if include_properties:
            properties += ['servicePrincipalName', 'userAccountControl', 'displayName',
                           'lastLogon', 'lastLogonTimestamp', 'pwdLastSet', 'mail', 'title', 'homeDirectory',
                           'description', 'userPassword', 'adminCount', 'msDS-AllowedToDelegateTo', 'sIDHistory',
                           'whencreated', 'unicodepwd', 'scriptpath']
        if acl:
            properties.append('nTSecurityDescriptor')

        query = '(|(&(objectCategory=person)(objectClass=user))(objectClass=msDS-GroupManagedServiceAccount)(objectClass=msDS-ManagedServiceAccount))'
        return self.search(query, properties, generator=True, query_sd=acl)


    def get_computers(self, include_properties=False, acl=False):
        properties = ['samaccountname', 'userAccountControl', 'distinguishedname',
                      'dnshostname', 'samaccounttype', 'objectSid', 'primaryGroupID',
                      'isDeleted']
        if include_properties:
            properties += ['servicePrincipalName', 'msDS-AllowedToDelegateTo', 'sIDHistory', 'whencreated',
                           'lastLogon', 'lastLogonTimestamp', 'pwdLastSet', 'operatingSystem', 'description',
                           'operatingSystemServicePack', 'msDS-AllowedToActOnBehalfOfOtherIdentity']
            # LAPS
            if getattr(self.ad, 'has_laps', False):
                properties.append('ms-mcs-admpwdexpirationtime')
            if getattr(self.ad, 'has_lapsv2', False):
                properties.append('mslaps-passwordexpirationtime')
        if acl:
            if getattr(self.ad, 'has_laps', False):
                properties.append('ms-mcs-admpwdexpirationtime')
            if getattr(self.ad, 'has_lapsv2', False):
                properties.append('mslaps-passwordexpirationtime')
            properties.append('nTSecurityDescriptor')

        query = '(&(sAMAccountType=805306369))'
        return self.search(query, properties, generator=True, query_sd=acl)

    def get_memberships(self):
        return self.search('(|(memberof=*)(primarygroupid=*))',
                           ['samaccountname', 'distinguishedname', 'dnshostname', 'samaccounttype', 'primarygroupid', 'memberof'],
                           generator=False)

    def get_sessions(self):
        return self.search('(&(samAccountType=805306368)(!(userAccountControl:1.2.840.113556.1.4.803:=2))(|(homedirectory=*)(scriptpath=*)(profilepath=*)))',
                           ['homedirectory', 'scriptpath', 'profilepath'])


"""
Active Directory data and cache
"""
class AD(object):

    def __init__(self, domain=None, auth=None, nameserver=None, dns_tcp=False, dns_timeout=3.0, config_dn=None):
        self.domain = domain
        self.domain_object = None
        self.auth = auth
        self._dcs = []
        self._kdcs = []
        self._gcs = []

        self.domains = {}
        self.nbdomains = {}
        self.groups = {}
        self.computers = {}
        self.users = {}

        self.dnsresolver = resolver.Resolver()
        if nameserver:
            self.dnsresolver.nameservers = [nameserver]
        self.dns_tcp = dns_tcp
        self.dnsresolver.cache = resolver.Cache()
        self.dnsresolver.timeout = float(dns_timeout)
        self.dnsresolver.lifetime = float(dns_timeout)
        self.dnscache = DNSCache()
        self.sidcache = SidCache()
        self.samcache = SamCache()
        
        # This will hold the root DN needed for searches
        self.baseDN = ADUtils.domain2ldap(domain) if domain else None
        self.config_dn = config_dn

    def override_dc(self, dcname):
        self._dcs = [dcname]

    def override_gc(self, gcname):
        self._gcs = [gcname]

    def dcs(self):
        return self._dcs

    def gcs(self):
        return self._gcs


"""
Active Directory Domain
"""
class ADDomain(object):
    def __init__(self, name=None, netbios_name=None, sid=None, distinguishedname=None):
        self.name = name
        self.netbios_name = netbios_name
        self.sid = sid
        self.distinguishedname = distinguishedname

    @staticmethod
    def fromADWS(identifier, sid=None):
        dns_name = ADUtils.ldap2domain(identifier)
        return ADDomain(name=dns_name, sid=sid, distinguishedname=identifier)
