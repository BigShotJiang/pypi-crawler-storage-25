####################
#
# Copyright (c) 2018 Fox-IT
# Modified for ADWS Concurrency Optimization
#
####################
import logging
import traceback
import codecs
import concurrent.futures
from impacket.dcerpc.v5.rpcrt import DCERPCException
from soaphound.lib.outputworker import OutputWorker
from soaphound.lib.memberships import MembershipEnumerator
from soaphound.ad.collectors.bh_rpc_computer import ADComputer
from soaphound.lib.utils import ADUtils
import queue
import threading

class ComputerEnumerator(MembershipEnumerator):
    """
    Class to enumerate computers in the domain.
    Re-engines the threading logic to use ThreadPoolExecutor.
    """
    def __init__(self, addomain, addc, collect, do_gc_lookup=True, computerfile="", exclude_dcs=False):
        self.addomain = addomain
        self.addc = addc
        self.blocklist = []
        self.allowlist = []
        self.do_gc_lookup = do_gc_lookup
        self.collect = collect
        self.exclude_dcs = exclude_dcs
        if computerfile:
            logging.info('Limiting enumeration to FQDNs in %s', computerfile)
            with codecs.open(computerfile, 'r', 'utf-8') as cfile:
                for line in cfile:
                    self.allowlist.append(line.strip().lower())

    def enumerate_computers(self, computers, num_workers=10, timestamp="", fileNamePrefix=""):
        """
            Enumerates the computers in the domain using ThreadPoolExecutor.
        """
        result_q = queue.Queue()
        if (fileNamePrefix != None):
            results_worker = threading.Thread(target=OutputWorker.write_worker, args=(result_q, fileNamePrefix + '_' + timestamp + 'computers.json'))
        else:
            results_worker = threading.Thread(target=OutputWorker.write_worker, args=(result_q, timestamp + 'computers.json'))
        results_worker.daemon = True
        results_worker.start()
        
        logging.info('Starting computer enumeration with ThreadPoolExecutor (%d workers)', num_workers)
        
        # Prepare workloads
        workloads = []
        for dn, computer in computers.items():
            if not 'attributes' in computer:
                continue

            hostname = ADUtils.get_entry_property(computer, 'dNSHostName')
            samname = ADUtils.get_entry_property(computer, 'sAMAccountName')
            objectsid = ADUtils.get_entry_property(computer, 'objectSid')
            
            if not hostname:
                logging.debug('Invalid computer object without hostname: %s', samname)
                hostname = ''

            # Check if filtering
            if hostname in self.blocklist:
                logging.info('Skipping computer: %s (blocklisted)', hostname)
                continue
            if len(self.allowlist) > 0 and hostname.lower() not in self.allowlist:
                logging.debug('Skipping computer: %s (not allowlisted)', hostname)
                continue

            workloads.append((hostname, samname, objectsid, computer))

        if len(workloads) > 0:
            all_sessions_users = {} # Shared dict 
            with concurrent.futures.ThreadPoolExecutor(max_workers=num_workers) as executor:
                futures = []
                for wl in workloads:
                    # Submit to pool
                    hostname, samname, objectsid, computer = wl
                    futures.append(executor.submit(self.process_computer, hostname, samname, objectsid, computer, result_q, all_sessions_users))
                
                # Wait for all to finish
                for future in concurrent.futures.as_completed(futures):
                    try:
                        future.result()
                    except Exception as exc:
                        logging.error('Computer processor generated an exception: %s' % exc)
        
        # Signal output worker to close
        result_q.put(None)
        results_worker.join()

    def process_computer(self, hostname, samname, objectsid, entry, results_q, all_sessions_users=None):
        """
            Processes a single computer, pushes the results of the computer to the given queue.
        """
        logging.debug('Querying computer: %s', hostname)

        # Replaces global with shared dictionary references passed properly
        session_users_by_machine = {}

        c = ADComputer(hostname=hostname, samname=samname, ad=self.addomain, addc=self.addc, objectsid=objectsid)
        c.primarygroup = MembershipEnumerator.get_primary_membership(entry)
        
        if hostname and (not self.exclude_dcs or not ADUtils.is_dc(entry)) and c.try_connect():
            try:
                sessions = []
                # SMB / RPC Collects based on args
                if 'localadmin' in self.collect:
                    unresolved = c.rpc_get_group_members(544, c.admins)
                    c.rpc_resolve_sids(unresolved, c.admins)
                if 'rdp' in self.collect:
                    unresolved = c.rpc_get_group_members(555, c.rdp)
                    c.rpc_resolve_sids(unresolved, c.rdp)
                if 'dcom' in self.collect:
                    unresolved = c.rpc_get_group_members(562, c.dcom)
                    c.rpc_resolve_sids(unresolved, c.dcom)
                if 'psremote' in self.collect:
                    unresolved = c.rpc_get_group_members(580, c.psremote)
                    c.rpc_resolve_sids(unresolved, c.psremote)
                if 'loggedon' in self.collect:
                    loggedon = c.rpc_get_loggedon()
                    if loggedon is None:
                        loggedon = []
                    registry_sessions = c.rpc_get_registry_sessions()
                    if registry_sessions is None:
                        registry_sessions = []
                    sessions += registry_sessions
                else:
                    loggedon = []
                    registry_sessions = []
                if 'experimental' in self.collect:
                    services = c.rpc_get_services()
                    if services is None:
                        services = []
                    tasks = c.rpc_get_schtasks()
                    if tasks is None:
                        tasks = []
                else:
                    services = []
                    tasks = []

                c.rpc_close()

                # Process found sessions
                for ses in sessions:
                    key = f"{hostname.lower()}_session_users"
                    if key not in session_users_by_machine:
                        session_users_by_machine[key] = []
                    user_sid = ses.get('user')
                    session_type = "RDP" if ses.get('session_name') == "Console" else "SMB"
                    if user_sid and user_sid not in session_users_by_machine[key]:
                        session_users_by_machine[key].append({
                            "session_type": session_type,
                            "usersid": user_sid,
                            "computersid": objectsid
                        })

                    use_gc = self.addomain.num_domains > 1 and self.do_gc_lookup
                    
                    try:
                        uname = ses.get('username')
                        if not uname: continue
                        users = self.addomain.samcache.get(uname)
                    except KeyError:
                        entries = self.addomain.objectresolver.resolve_samname(uname, use_gc=use_gc)
                        if entries and len(entries) > 0:
                            users = [user['attributes'].get('objectSid') for user in entries if user['attributes'].get('objectSid')]
                            self.addomain.samcache.put(uname, users)
                        else:
                            users = None

                    if not users:
                        continue

                    for user_sid in users:
                        session_users_by_machine[key].append({
                            "username": uname,
                            "session_type": session_type,
                            "usersid": user_sid,
                            "computersid": objectsid
                        })

                    # Resolve target hostname
                    try:
                        target = self.addomain.dnscache.get(ses.get('source', ''))
                    except KeyError:
                        target = ADUtils.ip2host(ses.get('source', ''), self.addomain.dnsresolver, self.addomain.dns_tcp)
                        if target == ses.get('source'):
                            target = ADUtils.get_ntlm_hostname(ses.get('source', ''))
                        self.addomain.dnscache.put_single(ses.get('source', ''), target)
                    if ':' in target:
                        continue
                    if '.' not in target:
                        domain = self.addomain.domain
                        target = '%s.%s' % (target, domain)
                    try:
                        hostsid = self.addomain.computersidcache.get(target.lower())
                    except KeyError:
                        continue

                    for user in (users or []):
                        c.sessions.append({
                            "UserSID": user,
                            "ComputerSID": hostsid,
                            "SessionFrom": ses.get('client') or ses.get('remote_ip') or "",
                            "SessionType": "RDP" if ses.get('session_name') == "Console" else "SMB"
                        })
                
                # Loggons processing
                for user, userdomain in loggedon:
                    fupn = '%s@%s' % (user.upper(), userdomain.upper())
                    try:
                        users = self.addomain.samcache.get(fupn)
                    except KeyError:
                        entries = self.addomain.objectresolver.resolve_samname(user, use_gc=use_gc)
                        if entries is not None:
                            if len(entries) > 1:
                                for resolved_user in entries:
                                    edn = ADUtils.get_entry_property(resolved_user, 'distinguishedName')
                                    edom = ADUtils.ldap2domain(edn).lower()
                                    if edom == userdomain.lower():
                                        users = [resolved_user['attributes']['objectSid']]
                                        break
                            else:
                                users = [resolved_user['attributes']['objectSid'] for resolved_user in entries]
                        if entries is None or not users:
                            continue
                        self.addomain.samcache.put(fupn, users)
                    for resultuser in users or []:
                        c.loggedon.append({'ComputerSID':objectsid, 'UserSID':resultuser})

                for ses in registry_sessions:
                    c.registry_sessions.append({'ComputerSID':objectsid, 'UserSID':ses.get('user')})

                for taskuser in tasks:
                    c.loggedon.append({'ComputerSID':objectsid, 'UserSID':taskuser})

                for serviceuser in services:
                    try:
                        user = self.addomain.sidcache.get(serviceuser)
                    except KeyError:
                        userentry = self.addomain.objectresolver.resolve_upn(serviceuser)
                        if userentry:
                            self.addomain.sidcache.put(serviceuser, userentry['attributes']['objectSid'])
                            user = userentry['attributes']['objectSid']
                        else:
                            continue
                    c.loggedon.append({'ComputerSID':objectsid, 'UserSID':user})

            except DCERPCException:
                logging.debug(traceback.format_exc())
                logging.warning('Querying computer failed: %s', hostname)
            except Exception as e:
                logging.error('Unhandled exception in computer %s processing: %s', hostname, str(e))
                logging.info(traceback.format_exc())
           
            if all_sessions_users is not None:
                host_key = f"{hostname.lower()}_session_users"
                all_sessions_users[host_key] = list(session_users_by_machine.get(host_key, []))

            results_q.put(('computer', c.get_bloodhound_data(entry, self.collect)))

    def work(self, process_queue, results_q):
        pass # Replaced by ThreadPoolExecutor logic above
