"""mokra - World tests for AI agents - intercept and mock HTTP requests across services."""

try:
    from mokra._version import __version__
except ImportError:
    __version__ = "0.0.0.dev0"

from mokra.config import AuthStyle, configure
from mokra.service_mapper import ServiceMapper
from mokra.world import State, World, mockworld

__all__ = [
    "__version__",
    "configure",
    "AuthStyle",
    "mockworld",
    "World",
    "State",
    "ServiceMapper",
]
