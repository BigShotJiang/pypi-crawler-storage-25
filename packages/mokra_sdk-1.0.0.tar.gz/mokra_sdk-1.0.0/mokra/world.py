"""World class for managing mock server interactions."""

from __future__ import annotations

import time
from contextlib import contextmanager
from typing import TYPE_CHECKING, Any, Callable, Iterator

import requests

from mokra.config import get_config

if TYPE_CHECKING:
    pass

# Thread-local storage for current world context
import threading

_current_context = threading.local()


def get_current_world() -> "World | None":
    """Get the currently active world (if any)."""
    return getattr(_current_context, "world", None)


def get_current_test_id() -> str | None:
    """Get the current test ID (if any)."""
    world = get_current_world()
    return world._test_id if world else None


def get_current_run_id() -> str | None:
    """Get the current run ID (if any)."""
    world = get_current_world()
    return world._run_id if world else None


class StateRecord:
    """A single record in the mock server state."""

    def __init__(self, data: dict[str, Any]) -> None:
        """Initialize a state record.

        Args:
            data: The record data from the API.
        """
        self._data = data

    @property
    def id(self) -> str | None:
        """Return the record ID."""
        return self._data.get("id")

    def __getitem__(self, key: str) -> Any:
        """Get a value from the record."""
        return self._data.get(key)

    def __repr__(self) -> str:
        """Return string representation."""
        return f"StateRecord({self._data!r})"


class ResourceState:
    """State for a specific resource type in a mock server."""

    def __init__(self, resource_type: str, records: list[dict[str, Any]]) -> None:
        """Initialize resource state.

        Args:
            resource_type: The resource type name (e.g., 'products', 'orders').
            records: List of record data.
        """
        self._resource_type = resource_type
        self._records = [StateRecord(r) for r in records]

    @property
    def count(self) -> int:
        """Return the number of records."""
        return len(self._records)

    @property
    def records(self) -> list[StateRecord]:
        """Return all records."""
        return self._records

    def find_by_id(self, record_id: str) -> StateRecord | None:
        """Find a record by ID.

        Args:
            record_id: The ID to search for.

        Returns:
            The matching record or None.
        """
        for record in self._records:
            if record.id == record_id:
                return record
        return None

    def __repr__(self) -> str:
        """Return string representation."""
        return f"ResourceState({self._resource_type!r}, count={self.count})"


class State:
    """State of a mock server."""

    def __init__(self, data: dict[str, Any]) -> None:
        """Initialize state from API response.

        Args:
            data: The state data from the API.
        """
        self._data = data
        self._resources: dict[str, ResourceState] = {}

        # Parse resources from state data
        for key, value in data.items():
            if isinstance(value, list):
                self._resources[key] = ResourceState(key, value)

    @property
    def total(self) -> int:
        """Return total number of records across all resources."""
        return sum(rs.count for rs in self._resources.values())

    @property
    def resource_types(self) -> list[str]:
        """Return list of resource type names."""
        return list(self._resources.keys())

    def __getitem__(self, key: str) -> ResourceState:
        """Get a resource state by name.

        Args:
            key: The resource type name.

        Returns:
            The resource state, or empty if not found.
        """
        if key in self._resources:
            return self._resources[key]
        return ResourceState(key, [])

    def __repr__(self) -> str:
        """Return string representation."""
        return f"State(total={self.total}, resources={self.resource_types})"


class ServiceSeeder:
    """Seeder for a specific service."""

    def __init__(self, service_id: str, world: World) -> None:
        """Initialize service seeder.

        Args:
            service_id: The service ID (e.g., 'shopify').
            world: The parent World instance.
        """
        self._service_id = service_id
        self._world = world

    def __getattr__(self, name: str) -> ResourceSeeder:
        """Get a resource seeder dynamically.

        Args:
            name: The resource type name (e.g., 'orders').

        Returns:
            A ResourceSeeder for the resource type.
        """
        return ResourceSeeder(self._service_id, name, self._world)


class ResourceSeeder:
    """Seeder for a specific resource type."""

    def __init__(self, service_id: str, resource_type: str, world: World) -> None:
        """Initialize resource seeder.

        Args:
            service_id: The service ID.
            resource_type: The resource type name.
            world: The parent World instance.
        """
        self._service_id = service_id
        self._resource_type = resource_type
        self._world = world

    def create(self, data: dict[str, Any]) -> dict[str, Any]:
        """Create a seed record.

        Args:
            data: The record data to seed.

        Returns:
            The created record from the API.
        """
        config = get_config()
        if not config.base_url:
            raise ValueError("base_url not configured")

        url = f"{config.base_url}/seed/{self._service_id}/{self._resource_type}"
        headers = config.get_auth_headers()
        headers["Content-Type"] = "application/json"

        response = requests.post(url, json=data, headers=headers)
        response.raise_for_status()
        return response.json()


class Seeder:
    """Seeder for pre-populating mock server state."""

    def __init__(self, world: World) -> None:
        """Initialize seeder.

        Args:
            world: The parent World instance.
        """
        self._world = world

    def __getattr__(self, name: str) -> ServiceSeeder:
        """Get a service seeder dynamically.

        Args:
            name: The service name (e.g., 'shopify').

        Returns:
            A ServiceSeeder for the service.
        """
        return ServiceSeeder(name, self._world)


class World:
    """A test world with mock services.

    Manages the lifecycle of a test scenario including HTTP interception,
    state management, observations, and assertions.
    """

    def __init__(self, name: str, services: list[dict[str, Any]]) -> None:
        """Initialize a World.

        Args:
            name: The name of this test world.
            services: List of service configurations.
        """
        self._name = name
        self._services = services
        self._test_id: str | None = None
        self._run_id: str | None = None
        self._run_start_time: float | None = None
        self._mock_servers: dict[str, str] = {}  # service_id -> server_id

        self._create_world()

    def _create_world(self) -> None:
        """Create the world on the mock server."""
        config = get_config()
        if not config.base_url:
            raise ValueError("base_url not configured")

        url = f"{config.base_url}/createMockworld"
        headers = config.get_auth_headers()
        headers["Content-Type"] = "application/json"

        payload = {
            "name": self._name,
            "services": self._services,
        }

        response = requests.post(url, json=payload, headers=headers)

        # Handle errors with better messages
        if not response.ok:
            try:
                error_data = response.json()
                error_msg = error_data.get("error", response.text)
            except Exception:
                error_msg = response.text
            raise ValueError(f"Failed to create mockworld: {error_msg}")

        data = response.json()

        # Extract test ID from mockworld response
        mockworld_data = data.get("mockworld", {})
        self._test_id = mockworld_data.get("id")

        # Map service names to mock server IDs
        # The response contains mockServers array with nested mockServer objects
        mock_servers = mockworld_data.get("mockServers", [])
        for ms in mock_servers:
            # The structure is: { mockServerId, mockServer: { id, service: { slug, name } } }
            mock_server = ms.get("mockServer", {})
            service_info = mock_server.get("service", {})
            service_slug = service_info.get("slug") or service_info.get("name")
            # Get mock server ID from either mockServerId or nested mockServer.id
            server_id = ms.get("mockServerId") or mock_server.get("id")
            if service_slug and server_id:
                self._mock_servers[service_slug] = server_id

    def _create_run(self) -> None:
        """Create a new run on the mock server."""
        config = get_config()
        if not config.base_url or not self._test_id:
            return

        url = f"{config.base_url}/tests/{self._test_id}/runs"
        headers = config.get_auth_headers()
        headers["Content-Type"] = "application/json"

        payload = {"status": "RUNNING"}

        response = requests.post(url, json=payload, headers=headers)
        if response.status_code in (200, 201):
            data = response.json()
            run_data = data.get("run", {})
            self._run_id = run_data.get("id")
            self._run_start_time = time.time()

    def _complete_run(self, status: str = "PASSED", error: str | None = None) -> None:
        """Complete the current run on the mock server."""
        config = get_config()
        if not config.base_url or not self._test_id or not self._run_id:
            return

        url = f"{config.base_url}/tests/{self._test_id}/runs/{self._run_id}"
        headers = config.get_auth_headers()
        headers["Content-Type"] = "application/json"

        duration = None
        if self._run_start_time:
            duration = int((time.time() - self._run_start_time) * 1000)

        payload: dict[str, Any] = {"status": status}
        if duration is not None:
            payload["duration"] = duration
        if error:
            payload["error"] = error

        requests.patch(url, json=payload, headers=headers)

    @property
    def id(self) -> str | None:
        """Return the test ID."""
        return self._test_id

    @property
    def services(self) -> dict[str, str]:
        """Return the service to mock server mapping."""
        return self._mock_servers.copy()

    def run(self, func: Callable[[dict[str, str]], Any] | None = None) -> Any:
        """Run agent code with HTTP interception.

        Can be used as a function call or as a context manager.

        All HTTP calls to configured services are intercepted and redirected
        to the mock server.

        Args:
            func: A callable that receives the services dict. If None, returns
                  a context manager.

        Returns:
            The return value of func, or a context manager if func is None.

        Example:
            >>> # Function style
            >>> world.run(lambda services: requests.post("https://api.stripe.com/v1/charges", ...))

            >>> # Context manager style
            >>> with world.run():
            ...     requests.post("https://api.stripe.com/v1/charges", ...)
        """
        if func is None:
            # Return context manager
            return self._run_context()

        # Function style - call immediately
        from mokra.interceptor import install_interceptor, uninstall_interceptor

        self._create_run()
        _current_context.world = self
        install_interceptor()
        error_msg = None
        try:
            result = func(self._mock_servers)
            self._complete_run("PASSED")
            return result
        except Exception as e:
            error_msg = str(e)
            self._complete_run("FAILED", error_msg)
            raise
        finally:
            uninstall_interceptor()
            _current_context.world = None

    @contextmanager
    def _run_context(self) -> Iterator[dict[str, str]]:
        """Context manager for running agent code with interception."""
        from mokra.interceptor import install_interceptor, uninstall_interceptor

        self._create_run()
        _current_context.world = self
        install_interceptor()
        error_msg = None
        try:
            yield self._mock_servers
            self._complete_run("PASSED")
        except Exception as e:
            error_msg = str(e)
            self._complete_run("FAILED", error_msg)
            raise
        finally:
            uninstall_interceptor()
            _current_context.world = None

    def observe(self, print_output: bool = True) -> list[dict[str, Any]]:
        """Display observations recorded by the mock server.

        Args:
            print_output: Whether to print observations to console.

        Returns:
            List of observations.
        """
        config = get_config()
        if not config.base_url or not self._test_id or not self._run_id:
            if print_output:
                print("No observations recorded.")
            return []

        url = f"{config.base_url}/tests/{self._test_id}/runs/{self._run_id}"
        headers = config.get_auth_headers()

        response = requests.get(url, headers=headers)
        if response.status_code != 200:
            if print_output:
                print("No observations recorded.")
            return []

        data = response.json()
        run_data = data.get("run", {})
        observations = run_data.get("observations", [])

        if print_output:
            if not observations:
                print("No observations recorded.")
            else:
                print(f"Observations for '{self._name}':")
                print("-" * 50)
                for i, obs in enumerate(observations, 1):
                    obs_type = obs.get("type", "UNKNOWN")
                    if obs_type == "HTTP_REQUEST":
                        method = obs.get("httpMethod", "?")
                        url_str = obs.get("httpUrl", "")
                        status = obs.get("httpStatus", "?")
                        # Color code status
                        status_str = str(status)
                        if 200 <= status < 300:
                            status_str = f"\033[32m{status}\033[0m"  # Green
                        elif 300 <= status < 400:
                            status_str = f"\033[33m{status}\033[0m"  # Yellow
                        elif status >= 400:
                            status_str = f"\033[31m{status}\033[0m"  # Red
                        print(f"  {i}. [{method}] {url_str} -> {status_str}")
                    elif obs_type == "STATE_CHANGE":
                        path = obs.get("resourcePath", "?")
                        print(f"  {i}. [STATE] {path} changed")
                    elif obs_type == "EVENT":
                        name = obs.get("eventName", "?")
                        message = obs.get("eventMessage", "")
                        print(f"  {i}. [EVENT] {name}: {message}")
                    else:
                        print(f"  {i}. [{obs_type}]")
                print("-" * 50)

        return observations

    def assert_(
        self,
        *assertions: str,
        service: str | None = None,
        mock_server_id: str | None = None,
        print_output: bool = True,
    ) -> list[dict[str, Any]]:
        """Assert conditions using natural language.

        Args:
            *assertions: Natural language assertions to evaluate.
            service: Optional service name to scope the assertion.
            mock_server_id: Optional mock server ID to scope the assertion.
            print_output: Whether to print results to console.

        Returns:
            List of assertion results.

        Raises:
            AssertionError: If any assertion fails.

        Example:
            >>> results = world.assert_(
            ...     "customer charged once",
            ...     "no refund issued"
            ... )

            >>> # Scope to a specific service
            >>> world.assert_("order was created", service="shopify")

            >>> # Scope to a specific mock server
            >>> world.assert_("request was made", mock_server_id="abc123")
        """
        config = get_config()
        if not config.base_url or not self._test_id:
            raise ValueError("World not properly initialized")

        if not self._run_id:
            raise ValueError("No run in progress. Call run() first.")

        url = f"{config.base_url}/tests/{self._test_id}/runs/{self._run_id}/assert"
        headers = config.get_auth_headers()
        headers["Content-Type"] = "application/json"

        payload: dict[str, Any] = {"assertions": list(assertions)}

        # Add optional scoping
        if service:
            payload["service"] = service
        if mock_server_id:
            payload["mockServerId"] = mock_server_id

        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()
        results = response.json().get("results", [])

        if print_output:
            passed = sum(1 for r in results if r.get("passed"))
            failed = len(results) - passed
            print(f"\nAssertions: {passed} passed, {failed} failed")
            print("-" * 50)
            for i, result in enumerate(results, 1):
                assertion_text = assertions[i - 1] if i <= len(assertions) else "?"
                if result.get("passed"):
                    print(f"  \033[32m✓\033[0m {assertion_text}")
                else:
                    print(f"  \033[31m✗\033[0m {assertion_text}")
                    if result.get("error"):
                        print(f"      Error: {result.get('error')}")
                    if result.get("expectedValue") and result.get("actualValue"):
                        print(f"      Expected: {result.get('expectedValue')}")
                        print(f"      Actual: {result.get('actualValue')}")
            print("-" * 50)

        # Raise AssertionError if any assertion failed
        failed_assertions = [
            assertions[i] for i, r in enumerate(results)
            if not r.get("passed") and i < len(assertions)
        ]
        if failed_assertions:
            raise AssertionError(f"Assertion(s) failed: {', '.join(failed_assertions)}")

        return results

    # Alias for assert_ since 'assert' is a Python keyword
    def check(
        self,
        *assertions: str,
        service: str | None = None,
        mock_server_id: str | None = None,
    ) -> list[dict[str, Any]]:
        """Alias for assert_. Assert conditions using natural language."""
        return self.assert_(*assertions, service=service, mock_server_id=mock_server_id)

    def seed(self, func: Callable[[Seeder], None]) -> None:
        """Pre-populate state before running the agent.

        Args:
            func: A callable that receives a Seeder and populates state.

        Example:
            >>> def setup(s):
            ...     s.shopify.orders.create({"id": "order-123", "total": 99.99})
            >>> world.seed(setup)
        """
        seeder = Seeder(self)
        func(seeder)

    def state(self, mock_server_id: str | None = None) -> State:
        """Get current state of a mock server.

        Args:
            mock_server_id: The mock server ID. If None, uses the first service.

        Returns:
            The mock server state.

        Example:
            >>> state = world.state()
            >>> state.total
            5
            >>> state.resource_types
            ['products', 'orders']
            >>> state['products'].count
            3
        """
        config = get_config()
        if not config.base_url:
            raise ValueError("base_url not configured")

        # If no server ID provided, use the first one
        if mock_server_id is None:
            if not self._mock_servers:
                return State({})
            mock_server_id = next(iter(self._mock_servers.values()))

        url = f"{config.base_url}/mock-servers/{mock_server_id}/state"
        headers = config.get_auth_headers()

        response = requests.get(url, headers=headers)
        if response.status_code != 200:
            return State({})

        return State(response.json())


def mockworld(
    name: str | None = None,
    *services: str | dict[str, Any],
    services_list: list[str | dict[str, Any]] | None = None,
) -> World:
    """Create a new world with specified services.

    Args:
        name: The name for this test world.
        *services: Service names as strings, or dicts with name and server_id.
        services_list: Alternative way to pass services as a list (for keyword style).

    Returns:
        A configured World instance.

    Example:
        >>> # Positional style
        >>> world = mockworld("my test", "stripe", "shopify", "loop")

        >>> # Keyword style
        >>> world = mockworld(name="my test", services_list=["stripe", "shopify"])

        >>> # Attach existing mock server
        >>> world = mockworld("my test",
        ...     "stripe",
        ...     {"name": "shopify", "server_id": "existing-ms-id"}
        ... )
    """
    if name is None:
        raise ValueError("name is required")

    # Combine services from positional args and keyword arg
    all_services: list[str | dict[str, Any]] = list(services)
    if services_list:
        all_services.extend(services_list)

    service_configs = []
    for svc in all_services:
        if isinstance(svc, str):
            service_configs.append({"name": svc})
        elif isinstance(svc, dict):
            # Normalize to use 'name' key (API expects 'name', not 'service_id')
            normalized = {}
            name_key = svc.get("name") or svc.get("service_id")
            if name_key:
                normalized["name"] = name_key
            server_id = svc.get("server_id") or svc.get("serverId")
            if server_id:
                normalized["serverId"] = server_id
            service_configs.append(normalized)
        else:
            service_configs.append({"name": str(svc)})

    return World(name, service_configs)
