"""Service mapping for URL to service slug conversion."""

from __future__ import annotations

import fnmatch
import re
from pathlib import Path
from typing import TYPE_CHECKING
from urllib.parse import urlparse

if TYPE_CHECKING:
    pass

# Global mappings storage: host pattern -> service slug
_mappings: dict[str, str] = {}


def _get_mappings_dir() -> Path:
    """Return the path to the mappings directory."""
    return Path(__file__).parent / "mappings"


def _load_yaml_file(path: Path) -> dict[str, str]:
    """Load a YAML file and return as dict.

    Simple YAML parser for key: value format.
    """
    mappings: dict[str, str] = {}
    if not path.exists():
        return mappings

    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if ":" in line:
                parts = line.split(":", 1)
                key = parts[0].strip()
                value = parts[1].strip()
                mappings[key] = value
    return mappings


def _load_default_mappings() -> None:
    """Load default mokra.ai mappings."""
    global _mappings
    mokra_path = _get_mappings_dir() / "mokra.yml"
    _mappings = _load_yaml_file(mokra_path)


def add_mapping(host_pattern: str, service_slug: str) -> None:
    """Add a single host to service mapping.

    Args:
        host_pattern: The host pattern (e.g., 'api.myservice.com' or '*.internal.mycompany.com').
        service_slug: The service slug (e.g., 'myservice').

    Example:
        >>> from mockworld import ServiceMapper
        >>> ServiceMapper.add_mapping("api.myservice.com", "myservice")
    """
    _mappings[host_pattern] = service_slug


def load_mappings(path: str, *, replace: bool = False) -> None:
    """Load mappings from a YAML file.

    Args:
        path: Path to the YAML file.
        replace: If True, replace all existing mappings. If False, merge with existing.

    Example:
        >>> from mockworld import ServiceMapper
        >>> ServiceMapper.load_mappings("path/to/custom.yml")
        >>> ServiceMapper.load_mappings("path/to/custom.yml", replace=True)
    """
    global _mappings
    new_mappings = _load_yaml_file(Path(path))
    if replace:
        _mappings = new_mappings
    else:
        _mappings.update(new_mappings)


def load_provider(provider: str) -> None:
    """Load mappings for a specific provider.

    Looks for a file named '{provider}.yml' in the mappings directory.

    Args:
        provider: The provider name (e.g., 'mokra', 'my_provider').

    Example:
        >>> from mockworld import ServiceMapper
        >>> ServiceMapper.load_provider("my_provider")
    """
    path = _get_mappings_dir() / f"{provider}.yml"
    if not path.exists():
        raise FileNotFoundError(f"No mapping file found for provider: {provider}")
    load_mappings(str(path))


def get_service_slug(url: str) -> str | None:
    """Get the service slug for a URL.

    Args:
        url: The full URL to look up.

    Returns:
        The service slug if found, None otherwise.
    """
    parsed = urlparse(url)
    host = parsed.netloc.lower()

    # Remove port if present
    if ":" in host:
        host = host.split(":")[0]

    # Try exact match first
    if host in _mappings:
        return _mappings[host]

    # Try wildcard patterns
    for pattern, slug in _mappings.items():
        if "*" in pattern:
            # Convert glob pattern to regex
            regex_pattern = fnmatch.translate(pattern)
            if re.match(regex_pattern, host, re.IGNORECASE):
                return slug

    return None


def get_mock_url(original_url: str, base_url: str) -> str:
    """Convert an original URL to a mock URL.

    Args:
        original_url: The original URL (e.g., 'https://api.stripe.com/v1/charges').
        base_url: The mock server base URL (e.g., 'https://api.mokra.ai/api').

    Returns:
        The mock URL (e.g., 'https://api.mokra.ai/api/mock/stripe/v1/charges').
    """
    service_slug = get_service_slug(original_url)
    if not service_slug:
        return original_url  # Don't redirect unknown services

    parsed = urlparse(original_url)
    path = parsed.path

    # Construct mock URL: base_url/mock/service_slug/original_path
    mock_url = f"{base_url.rstrip('/')}/mock/{service_slug}{path}"

    # Preserve query string
    if parsed.query:
        mock_url += f"?{parsed.query}"

    return mock_url


def clear_mappings() -> None:
    """Clear all mappings (mainly for testing)."""
    global _mappings
    _mappings = {}


def get_all_mappings() -> dict[str, str]:
    """Return a copy of all current mappings."""
    return _mappings.copy()


# Load default mappings on module import
_load_default_mappings()


class ServiceMapper:
    """Static class for service mapping operations.

    Provides a class-based interface matching the Ruby API.

    Example:
        >>> from mockworld import ServiceMapper
        >>> ServiceMapper.add_mapping("api.myservice.com", "myservice")
        >>> ServiceMapper.load_mappings("path/to/custom.yml")
        >>> ServiceMapper.load_provider("my_provider")
    """

    @staticmethod
    def add_mapping(host_pattern: str, service_slug: str) -> None:
        """Add a single host to service mapping."""
        add_mapping(host_pattern, service_slug)

    @staticmethod
    def load_mappings(path: str, *, replace: bool = False) -> None:
        """Load mappings from a YAML file."""
        load_mappings(path, replace=replace)

    @staticmethod
    def load_provider(provider: str) -> None:
        """Load mappings for a specific provider."""
        load_provider(provider)
