"""Configuration for mokra."""

from __future__ import annotations

import os
from enum import Enum
from typing import Any


class AuthStyle(Enum):
    """Authentication style for API requests."""

    API_KEY = "api_key"  # X-API-Key header (default for mokra.ai)
    BEARER = "bearer"  # Authorization: Bearer token
    CUSTOM = "custom"  # Custom header


class Configuration:
    """Mokra configuration.

    Attributes:
        base_url: The mock server base URL.
        api_key: The API key for authentication.
        auth_style: The authentication style to use.
        auth_header: Custom header name (only used with CUSTOM auth style).
    """

    def __init__(self) -> None:
        """Initialize configuration with defaults from environment."""
        self._base_url: str | None = os.environ.get("MOKRA_BASE_URL")
        self._api_key: str | None = os.environ.get("MOKRA_API_KEY")
        self._auth_style: AuthStyle = AuthStyle.API_KEY
        self._auth_header: str = "X-API-Key"

    @property
    def base_url(self) -> str | None:
        """Return the base URL."""
        return self._base_url

    @base_url.setter
    def base_url(self, value: str) -> None:
        """Set the base URL."""
        self._base_url = value.rstrip("/")

    @property
    def api_key(self) -> str | None:
        """Return the API key."""
        return self._api_key

    @api_key.setter
    def api_key(self, value: str) -> None:
        """Set the API key."""
        self._api_key = value

    @property
    def auth_style(self) -> AuthStyle:
        """Return the authentication style."""
        return self._auth_style

    @auth_style.setter
    def auth_style(self, value: AuthStyle | str) -> None:
        """Set the authentication style."""
        if isinstance(value, str):
            value = AuthStyle(value)
        self._auth_style = value

    @property
    def auth_header(self) -> str:
        """Return the custom auth header."""
        return self._auth_header

    @auth_header.setter
    def auth_header(self, value: str) -> None:
        """Set the custom auth header."""
        self._auth_header = value

    def get_auth_headers(self) -> dict[str, str]:
        """Return the authentication headers based on config.

        Returns:
            Dict with appropriate auth header.

        Raises:
            ValueError: If api_key is not configured.
        """
        if not self._api_key:
            raise ValueError("API key not configured. Set MOKRA_API_KEY or call configure().")

        if self._auth_style == AuthStyle.API_KEY:
            return {"X-API-Key": self._api_key}
        elif self._auth_style == AuthStyle.BEARER:
            return {"Authorization": f"Bearer {self._api_key}"}
        elif self._auth_style == AuthStyle.CUSTOM:
            return {self._auth_header: self._api_key}
        else:
            return {"X-API-Key": self._api_key}


# Global configuration instance
_config = Configuration()


def configure(**kwargs: Any) -> None:
    """Configure mokra/mockworld settings.

    Args:
        base_url: The mock server base URL.
        api_key: The API key for authentication.
        auth_style: The authentication style ('api_key', 'bearer', or 'custom').
        auth_header: Custom header name (only used with 'custom' auth style).

    Example:
        >>> import mokra
        >>> mokra.configure(
        ...     base_url="https://api.mokra.ai/api",
        ...     api_key="your-api-key"
        ... )

        >>> # Bearer token auth
        >>> mokra.configure(
        ...     api_key="your-token",
        ...     auth_style="bearer"
        ... )

        >>> # Custom header
        >>> mokra.configure(
        ...     api_key="your-key",
        ...     auth_style="custom",
        ...     auth_header="X-Custom-Auth"
        ... )
    """
    for key, value in kwargs.items():
        if hasattr(_config, key):
            setattr(_config, key, value)
        else:
            raise ValueError(f"Unknown configuration option: {key}")


def get_config() -> Configuration:
    """Return the global configuration instance."""
    return _config


def reset_config() -> None:
    """Reset configuration to defaults (mainly for testing)."""
    global _config
    _config = Configuration()
