"""HTTP interception for redirecting requests to mock server."""

from __future__ import annotations

import threading
from typing import TYPE_CHECKING, Any, Callable
from urllib.parse import urlparse

if TYPE_CHECKING:
    pass

from mokra.config import get_config
from mokra.service_mapper import get_mock_url, get_service_slug

_original_session_request: Callable[..., Any] | None = None
_original_httpx_request: Callable[..., Any] | None = None
_lock = threading.Lock()
_interceptor_active = False


def install_interceptor() -> None:
    """Install HTTP interceptors for requests and httpx."""
    global _interceptor_active
    with _lock:
        _interceptor_active = True
    _patch_requests()
    _patch_httpx()


def uninstall_interceptor() -> None:
    """Remove HTTP interceptors and restore original behavior."""
    global _interceptor_active
    _unpatch_requests()
    _unpatch_httpx()
    with _lock:
        _interceptor_active = False


def _should_intercept(url: str) -> bool:
    """Check if a URL should be intercepted.

    Args:
        url: The URL to check.

    Returns:
        True if the URL should be redirected to mock server.
    """
    if not _interceptor_active:
        return False

    config = get_config()
    if not config.base_url:
        return False

    # Don't intercept requests to the mock server itself
    parsed_url = urlparse(url)
    parsed_base = urlparse(config.base_url)
    if parsed_url.netloc == parsed_base.netloc:
        return False

    # Check if we have a mapping for this URL
    return get_service_slug(url) is not None


def _rewrite_url(url: str) -> str:
    """Rewrite a URL to point to the mock server.

    Args:
        url: The original URL.

    Returns:
        The mock server URL.
    """
    config = get_config()
    if not config.base_url:
        return url
    return get_mock_url(url, config.base_url)


def _add_auth_headers(
    headers: dict[str, str] | None,
    original_url: str | None = None,
) -> dict[str, str]:
    """Add authentication and context headers for mock server.

    Args:
        headers: The original headers.
        original_url: The original URL being intercepted.

    Returns:
        Headers with auth and context added.
    """
    from mokra.world import get_current_run_id, get_current_test_id, get_current_world

    result = dict(headers) if headers else {}
    config = get_config()

    # Add auth headers
    auth_headers = config.get_auth_headers()
    result.update(auth_headers)

    # Add context headers for mock server
    test_id = get_current_test_id()
    run_id = get_current_run_id()
    world = get_current_world()

    if test_id:
        result["X-Mockworld-Test-Id"] = test_id
    if run_id:
        result["X-Mockworld-Run-Id"] = run_id

    # Add original URL context
    if original_url:
        parsed = urlparse(original_url)
        result["X-Mockworld-Original-Host"] = parsed.netloc
        result["X-Mockworld-Original-URL"] = original_url

        # Find mock server ID for this service
        service_slug = get_service_slug(original_url)
        if service_slug and world:
            mock_server_id = world.services.get(service_slug)
            if mock_server_id:
                result["X-Mock-Server-Id"] = mock_server_id

    return result


def _patch_requests() -> None:
    """Patch requests.Session.request() to redirect HTTP traffic."""
    global _original_session_request
    try:
        import requests

        if _original_session_request is None:
            _original_session_request = requests.Session.request

        def patched_request(
            self: Any, method: str, url: str, **kwargs: Any
        ) -> Any:
            if _should_intercept(url):
                original_url = url
                # Rewrite URL to mock server
                url = _rewrite_url(url)
                # Add auth and context headers
                headers = kwargs.get("headers", {}) or {}
                kwargs["headers"] = _add_auth_headers(headers, original_url)

            return _original_session_request(self, method, url, **kwargs)

        requests.Session.request = patched_request  # type: ignore[method-assign]
    except ImportError:
        pass


def _unpatch_requests() -> None:
    """Restore original requests.Session.request() behavior."""
    global _original_session_request
    if _original_session_request is not None:
        try:
            import requests

            requests.Session.request = _original_session_request  # type: ignore[method-assign]
        except ImportError:
            pass
        _original_session_request = None


def _patch_httpx() -> None:
    """Patch the httpx library."""
    global _original_httpx_request
    try:
        import httpx

        if _original_httpx_request is None:
            _original_httpx_request = httpx.Client.request

        def patched_request(
            self: Any, method: str, url: str, *args: Any, **kwargs: Any
        ) -> Any:
            url_str = str(url)
            if _should_intercept(url_str):
                original_url = url_str
                # Rewrite URL to mock server
                url = _rewrite_url(url_str)
                # Add auth and context headers
                headers = kwargs.get("headers", {}) or {}
                kwargs["headers"] = _add_auth_headers(dict(headers), original_url)

            return _original_httpx_request(self, method, url, *args, **kwargs)

        httpx.Client.request = patched_request  # type: ignore[method-assign]
    except ImportError:
        pass


def _unpatch_httpx() -> None:
    """Restore original httpx behavior."""
    global _original_httpx_request
    if _original_httpx_request is not None:
        try:
            import httpx

            httpx.Client.request = _original_httpx_request  # type: ignore[method-assign]
        except ImportError:
            pass
        _original_httpx_request = None
