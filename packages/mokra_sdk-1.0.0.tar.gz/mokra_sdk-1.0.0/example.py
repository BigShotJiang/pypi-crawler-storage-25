#!/usr/bin/env python3
"""Example script to try out Mokra.

Usage:
    # Set your API key
    export MOKRA_API_KEY="your-api-key"

    # Run the example
    python example.py
"""

import os
from pathlib import Path

import requests

# Load .env file if present
env_file = Path(__file__).parent / ".env"
if env_file.exists():
    for line in env_file.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" in line:
            key, value = line.split("=", 1)
            os.environ[key] = value

import mokra

# Configure mokra (uses MOKRA_API_KEY env var by default)
mokra.configure(
    base_url="https://api.mokra.ai/api",
    # api_key is read from MOKRA_API_KEY env var automatically
)

print("=" * 60)
print("Example 1: Function style")
print("=" * 60)

# Create a world with services
world = mokra.mockworld("Stripe Charge Example", "stripe")


# Run your agent with function style
def agent_code(services):
    # Your agent code here - HTTP calls are automatically intercepted
    requests.post(
        "https://api.stripe.com/v1/charges",
        headers={"Authorization": "Bearer sk_test_xxx"},
        json={"amount": 1000, "currency": "usd"},
    )


world.run(agent_code)

# See what happened
world.observe()

# Assert outcomes
try:
    world.assert_("a charge was created")
except AssertionError as e:
    print(f"Assertion failed (expected in demo): {e}")

print("\n" + "=" * 60)
print("Example 2: Context manager style (recommended for pytest)")
print("=" * 60)

# Create a world with services using keyword style
world2 = mokra.mockworld(name="Refund Test", services_list=["stripe"])

# Run with context manager
with world2.run():
    requests.post(
        "https://api.stripe.com/v1/refunds",
        headers={"Authorization": "Bearer sk_test_xxx"},
        json={"charge": "ch_xxx", "amount": 500},
    )

# See what happened
world2.observe()

# Assert outcomes
try:
    world2.assert_("a refund was created")
except AssertionError as e:
    print(f"Assertion failed (expected in demo): {e}")

print("\nDone!")
