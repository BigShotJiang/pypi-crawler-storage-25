"""Tests for mockworld.service_mapper module."""

import tempfile
from pathlib import Path

import pytest

from mokra.service_mapper import (
    ServiceMapper,
    add_mapping,
    clear_mappings,
    get_all_mappings,
    get_mock_url,
    get_service_slug,
    load_mappings,
)


class TestGetServiceSlug:
    """Tests for get_service_slug() function."""

    def test_stripe_api(self):
        assert get_service_slug("https://api.stripe.com/v1/charges") == "stripe"

    def test_shopify_api(self):
        assert get_service_slug("https://api.shopify.com/admin/api/orders") == "shopify"

    def test_slack_api(self):
        assert get_service_slug("https://api.slack.com/api/chat.postMessage") == "slack"

    def test_github_api(self):
        assert get_service_slug("https://api.github.com/repos/user/repo") == "github"

    def test_openai_api(self):
        assert get_service_slug("https://api.openai.com/v1/chat/completions") == "openai"

    def test_unknown_host_returns_none(self):
        assert get_service_slug("https://unknown-api.example.com/endpoint") is None

    def test_host_with_port(self):
        add_mapping("localhost", "local")
        assert get_service_slug("http://localhost:8080/api/test") == "local"

    def test_case_insensitive(self):
        assert get_service_slug("https://API.STRIPE.COM/v1/charges") == "stripe"


class TestWildcardPatterns:
    """Tests for wildcard pattern matching."""

    def test_shopify_wildcard(self):
        # *.myshopify.com pattern from default mappings
        assert get_service_slug("https://mystore.myshopify.com/admin/api") == "shopify"
        assert get_service_slug("https://another-store.myshopify.com/products") == "shopify"

    def test_custom_wildcard(self):
        add_mapping("*.internal.company.com", "internal")
        assert get_service_slug("https://api.internal.company.com/users") == "internal"
        assert get_service_slug("https://service.internal.company.com/data") == "internal"


class TestAddMapping:
    """Tests for add_mapping() function."""

    def test_add_simple_mapping(self):
        add_mapping("api.myservice.com", "myservice")
        assert get_service_slug("https://api.myservice.com/endpoint") == "myservice"

    def test_add_mapping_overwrites_existing(self):
        add_mapping("api.test.com", "original")
        assert get_service_slug("https://api.test.com/test") == "original"
        add_mapping("api.test.com", "updated")
        assert get_service_slug("https://api.test.com/test") == "updated"


class TestLoadMappings:
    """Tests for load_mappings() function."""

    def test_load_mappings_from_file(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".yml", delete=False) as f:
            f.write("api.custom.com: custom\n")
            f.write("api.another.com: another\n")
            f.flush()

            load_mappings(f.name)
            assert get_service_slug("https://api.custom.com/test") == "custom"
            assert get_service_slug("https://api.another.com/test") == "another"

    def test_load_mappings_merge(self):
        # Default mappings should still work
        assert get_service_slug("https://api.stripe.com/v1/charges") == "stripe"

        with tempfile.NamedTemporaryFile(mode="w", suffix=".yml", delete=False) as f:
            f.write("api.custom.com: custom\n")
            f.flush()

            load_mappings(f.name)
            # Both should work
            assert get_service_slug("https://api.stripe.com/v1/charges") == "stripe"
            assert get_service_slug("https://api.custom.com/test") == "custom"

    def test_load_mappings_replace(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".yml", delete=False) as f:
            f.write("api.custom.com: custom\n")
            f.flush()

            load_mappings(f.name, replace=True)
            # Default mappings should be gone
            assert get_service_slug("https://api.stripe.com/v1/charges") is None
            assert get_service_slug("https://api.custom.com/test") == "custom"

    def test_load_mappings_skips_comments(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".yml", delete=False) as f:
            f.write("# This is a comment\n")
            f.write("api.service.com: service\n")
            f.write("# Another comment\n")
            f.flush()

            load_mappings(f.name)
            assert get_service_slug("https://api.service.com/test") == "service"


class TestClearMappings:
    """Tests for clear_mappings() function."""

    def test_clear_removes_all_mappings(self):
        assert get_service_slug("https://api.stripe.com/test") == "stripe"
        clear_mappings()
        assert get_service_slug("https://api.stripe.com/test") is None


class TestGetAllMappings:
    """Tests for get_all_mappings() function."""

    def test_returns_copy(self):
        mappings = get_all_mappings()
        assert isinstance(mappings, dict)
        assert "api.stripe.com" in mappings

        # Modifying returned dict shouldn't affect internal state
        mappings["api.test.com"] = "test"
        assert get_service_slug("https://api.test.com/endpoint") is None


class TestGetMockUrl:
    """Tests for get_mock_url() function."""

    def test_rewrite_stripe_url(self):
        original = "https://api.stripe.com/v1/charges"
        base_url = "https://api.mokra.ai/api"
        result = get_mock_url(original, base_url)
        assert result == "https://api.mokra.ai/api/mock/stripe/v1/charges"

    def test_rewrite_preserves_path(self):
        original = "https://api.github.com/repos/user/repo/issues"
        base_url = "https://mock.example.com"
        result = get_mock_url(original, base_url)
        assert result == "https://mock.example.com/mock/github/repos/user/repo/issues"

    def test_rewrite_preserves_query_string(self):
        original = "https://api.stripe.com/v1/charges?limit=10&offset=0"
        base_url = "https://api.mokra.ai/api"
        result = get_mock_url(original, base_url)
        assert result == "https://api.mokra.ai/api/mock/stripe/v1/charges?limit=10&offset=0"

    def test_unknown_service_returns_original(self):
        original = "https://unknown.example.com/api/test"
        base_url = "https://api.mokra.ai/api"
        result = get_mock_url(original, base_url)
        assert result == original

    def test_base_url_trailing_slash_handled(self):
        original = "https://api.stripe.com/v1/charges"
        base_url = "https://api.mokra.ai/api/"
        result = get_mock_url(original, base_url)
        assert result == "https://api.mokra.ai/api/mock/stripe/v1/charges"


class TestServiceMapperClass:
    """Tests for ServiceMapper static class interface."""

    def test_add_mapping(self):
        ServiceMapper.add_mapping("api.test.com", "test")
        assert get_service_slug("https://api.test.com/endpoint") == "test"

    def test_load_mappings(self):
        with tempfile.NamedTemporaryFile(mode="w", suffix=".yml", delete=False) as f:
            f.write("api.test.com: test\n")
            f.flush()

            ServiceMapper.load_mappings(f.name)
            assert get_service_slug("https://api.test.com/endpoint") == "test"
