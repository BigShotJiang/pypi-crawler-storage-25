"""Pytest configuration and fixtures for mockworld tests."""

import pytest

from mokra.config import reset_config
from mokra.service_mapper import clear_mappings, _load_default_mappings


@pytest.fixture(autouse=True)
def reset_state():
    """Reset global state before each test."""
    reset_config()
    clear_mappings()
    _load_default_mappings()
    yield
    reset_config()
    clear_mappings()
