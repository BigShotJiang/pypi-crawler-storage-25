"""Tests for mockworld.config module."""

import os
import pytest

from mokra.config import (
    AuthStyle,
    Configuration,
    configure,
    get_config,
    reset_config,
)


class TestAuthStyle:
    """Tests for AuthStyle enum."""

    def test_api_key_value(self):
        assert AuthStyle.API_KEY.value == "api_key"

    def test_bearer_value(self):
        assert AuthStyle.BEARER.value == "bearer"

    def test_custom_value(self):
        assert AuthStyle.CUSTOM.value == "custom"


class TestConfiguration:
    """Tests for Configuration class."""

    def test_default_values(self):
        config = Configuration()
        assert config.base_url is None
        assert config.api_key is None
        assert config.auth_style == AuthStyle.API_KEY
        assert config.auth_header == "X-API-Key"

    def test_set_base_url(self):
        config = Configuration()
        config.base_url = "https://api.example.com/api"
        assert config.base_url == "https://api.example.com/api"

    def test_base_url_strips_trailing_slash(self):
        config = Configuration()
        config.base_url = "https://api.example.com/api/"
        assert config.base_url == "https://api.example.com/api"

    def test_set_api_key(self):
        config = Configuration()
        config.api_key = "test-api-key"
        assert config.api_key == "test-api-key"

    def test_set_auth_style_with_enum(self):
        config = Configuration()
        config.auth_style = AuthStyle.BEARER
        assert config.auth_style == AuthStyle.BEARER

    def test_set_auth_style_with_string(self):
        config = Configuration()
        config.auth_style = "bearer"
        assert config.auth_style == AuthStyle.BEARER

    def test_set_auth_header(self):
        config = Configuration()
        config.auth_header = "X-Custom-Header"
        assert config.auth_header == "X-Custom-Header"

    def test_get_auth_headers_api_key(self):
        config = Configuration()
        config.api_key = "my-key"
        config.auth_style = AuthStyle.API_KEY
        headers = config.get_auth_headers()
        assert headers == {"X-API-Key": "my-key"}

    def test_get_auth_headers_bearer(self):
        config = Configuration()
        config.api_key = "my-token"
        config.auth_style = AuthStyle.BEARER
        headers = config.get_auth_headers()
        assert headers == {"Authorization": "Bearer my-token"}

    def test_get_auth_headers_custom(self):
        config = Configuration()
        config.api_key = "my-key"
        config.auth_style = AuthStyle.CUSTOM
        config.auth_header = "X-My-Auth"
        headers = config.get_auth_headers()
        assert headers == {"X-My-Auth": "my-key"}

    def test_get_auth_headers_raises_without_api_key(self):
        config = Configuration()
        with pytest.raises(ValueError, match="API key not configured"):
            config.get_auth_headers()

    def test_environment_variables(self, monkeypatch):
        monkeypatch.setenv("MOKRA_BASE_URL", "https://env.example.com")
        monkeypatch.setenv("MOKRA_API_KEY", "env-api-key")
        config = Configuration()
        assert config.base_url == "https://env.example.com"
        assert config.api_key == "env-api-key"


class TestConfigure:
    """Tests for configure() function."""

    def test_configure_base_url(self):
        configure(base_url="https://api.mokra.ai/api")
        config = get_config()
        assert config.base_url == "https://api.mokra.ai/api"

    def test_configure_api_key(self):
        configure(api_key="test-key")
        config = get_config()
        assert config.api_key == "test-key"

    def test_configure_auth_style(self):
        configure(auth_style="bearer")
        config = get_config()
        assert config.auth_style == AuthStyle.BEARER

    def test_configure_multiple_options(self):
        configure(
            base_url="https://api.example.com",
            api_key="my-key",
            auth_style="bearer",
        )
        config = get_config()
        assert config.base_url == "https://api.example.com"
        assert config.api_key == "my-key"
        assert config.auth_style == AuthStyle.BEARER

    def test_configure_unknown_option_raises(self):
        with pytest.raises(ValueError, match="Unknown configuration option"):
            configure(unknown_option="value")


class TestResetConfig:
    """Tests for reset_config() function."""

    def test_reset_clears_configuration(self):
        configure(base_url="https://api.example.com", api_key="my-key")
        reset_config()
        config = get_config()
        assert config.base_url is None
        assert config.api_key is None
